; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/source:Span" = type { i32, i32 }
%"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" = type { ptr, i64 }
%"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed" = type { i32, i64 }
%"compiler/names:Entry" = type { i32, %"compiler/source:Span", i32, i1, ptr }
%"compiler/names:Table" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"compiler/names:Ref" = type { i32, i64, i64 }
%"compiler/names:Resolver" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, i1, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, ptr, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/diagmsg:Msg" = type { i32, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/load:Import" = type { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, { i64, ptr }, i64, i64, { i64, ptr }, %"compiler/source:Span" }
%"compiler/ast:TopIf" = type { ptr, ptr, ptr, ptr }
%"compiler/ast:TypeDecl" = type { i32, { i64, ptr }, i1, ptr, i32, i1, ptr, i32 }
%"compiler/ast:MemberDecl" = type { ptr, i32, { i64, ptr }, ptr }
%"compiler/ast:VarDecl" = type { { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, i1, i1, i1 }
%"compiler/ast:CaseDecl" = type { %"compiler/source:Span", i32, { i64, ptr }, i1, ptr }
%"compiler/ast:Param" = type { %"compiler/source:Span", i32, ptr, ptr }
%"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba" = type { i64, %"compiler/source:Span" }
%"compiler/ast:TopBranch" = type { %"compiler/source:Span", { i64, ptr }, i64 }
%"compiler/ast:Branch" = type { %"compiler/source:Span", { i64, ptr }, i64 }
%"compiler/source:Source" = type { { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/cond:Consts" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1, i1, ptr, i32 }
%"compiler/cond:Decision" = type { i32, i1 }
%"compiler/cond:Eval" = type { { i64, ptr }, ptr, ptr, ptr, i1, i1, i1, %"compiler/source:Span", %"compiler/diagmsg:Msg", i64, i64, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/cond:Scope" = type { i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/names:raisedName" = type { i32, %"compiler/source:Span", i64, i1, i64, { i64, ptr } }
%"compiler/ast:If" = type { ptr, ptr, ptr }
%"compiler/ast:Chain" = type { { i64, ptr }, { i64, ptr } }
%"compiler/ast:Compr" = type { ptr, ptr, i32, i32, ptr, ptr, i1, i64 }
%"compiler/names:raised" = type { i32, %"compiler/source:Span", i1, { i64, ptr } }
%"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" = type { i64, i64 }
%"compiler/names:local" = type { i32, %"compiler/source:Span", i32, i1, i1, i1 }
%"compiler/ast:Multi" = type { { i64, ptr }, i1, { i64, ptr }, i1 }
%"compiler/token:Token" = type { i32, i8, i32, i32 }
%"compiler/scan:Tokens" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/ast:TypeParam" = type { %"compiler/source:Span", i32, ptr, { i64, ptr }, i1, ptr }
%"compiler/ast:Sig" = type { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, i1, i1, i1, { i64, ptr }, i1 }
%"compiler/ast:For3" = type { ptr, ptr, ptr, { i64, ptr } }
%"compiler/ast:ForIn" = type { i32, i32, ptr, i1, { i64, ptr }, { i64, ptr }, i1 }
%"compiler/ast:JoinS" = type { i1, { i64, ptr }, { i64, ptr } }
%"compiler/diag:Diagnostics" = type { i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, [3 x i64] }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/ast:Path" = type { %"compiler/source:Span", { i64, ptr } }
%"compiler/ast:StructBody" = type { { i64, ptr }, ptr, { i64, ptr }, %"compiler/source:Span", { i64, ptr }, { i64, ptr } }
%"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" = type { i32, i64 }
%"compiler/msgs:Nearest" = type { { i64, ptr }, { i64, ptr }, i64 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/diag:Said" = type { { i64, ptr }, i64, i64, { i64, ptr } }
%"compiler/fetch:Fetcher" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/source:Names" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
define dso_local i1 @compiler_2fnames_2eMentions(ptr %v0, ptr %v1, { i64, ptr } %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i1
  %l7 = alloca i1
  %l19 = alloca i64
  %l32 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l38 = alloca i1
  %l39 = alloca { i64, ptr }
  %l40 = alloca i64
  %l44 = alloca i64
  %l45 = alloca i64
  %l51 = alloca i1
  %l55 = alloca i1
  %l56 = alloca { i64, ptr }
  %l60 = alloca i1
  %l68 = alloca i1
  %l69 = alloca { i64, ptr }
  %l75 = alloca i1
  %l78 = alloca i1
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t9 = load i32, ptr %t8, !tbaa !23
  %t11 = sext i32 %t9 to i64
  store i64 %t11, ptr %l3, !tbaa !24
  %t13 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t14 = load i32, ptr %t13, !tbaa !23
  %t16 = sext i32 %t14 to i64
  %t17 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t17, 0
  %t22 = icmp sle i64 %t16, %t19
  br i1 %t22, label %bb4, label %bb5
bb4:
  %t24 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t25 = load i32, ptr %t24, !tbaa !23
  %t27 = sext i32 %t25 to i64
  store i64 %t27, ptr %l19, !tbaa !24
  br label %bb6
bb5:
  %t29 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t31 = extractvalue { i64, ptr } %t29, 0
  store i64 %t31, ptr %l19, !tbaa !24
  br label %bb6
bb6:
  %t33 = load i64, ptr %l19, !tbaa !24
  store i64 %t33, ptr %l4, !tbaa !24
  %t34 = load i64, ptr %l3, !tbaa !24
  store i64 %t34, ptr %l5, !tbaa !24
  br label %bb7
bb7:
  %t36 = load i64, ptr %l5, !tbaa !24
  %t37 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t37, 0
  %t42 = add i64 %t36, %t39
  %t43 = load i64, ptr %l4, !tbaa !24
  %t46 = icmp sle i64 %t42, %t43
  %t48 = xor i1 %t46, true
  br i1 %t48, label %bb8, label %bb9
bb8:
  br label %bb39
bb9:
  br label %bb10
bb10:
  %t50 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t50, ptr %l32, !tbaa !27
  %t51 = load i64, ptr %l5, !tbaa !24
  %t53 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !27
  %t55 = getelementptr i8, ptr %t54, i64 %t51
  %t56 = load i8, ptr %t55, !tbaa !32
  %t57 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t57, ptr %l35, !tbaa !27
  %t58 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = getelementptr i8, ptr %t59, i64 0
  %t61 = load i8, ptr %t60, !tbaa !32
  %t64 = icmp ne i8 %t56, %t61
  br i1 %t64, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l38, !tbaa !21
  br label %bb20
bb12:
  %t66 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t66, ptr %l39, !tbaa !27
  %t67 = load i64, ptr %l5, !tbaa !24
  store i64 %t67, ptr %l40, !tbaa !24
  %t68 = load i64, ptr %l5, !tbaa !24
  %t69 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t71 = extractvalue { i64, ptr } %t69, 0
  %t74 = add i64 %t68, %t71
  store i64 %t74, ptr %l44, !tbaa !24
  %t75 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t76 = extractvalue { i64, ptr } %t75, 0
  store i64 %t76, ptr %l45, !tbaa !24
  %t77 = load i64, ptr %l40, !tbaa !24
  %t78 = icmp sge i64 %t77, 0
  br i1 %t78, label %bb13, label %bb14
bb13:
  %t80 = load i64, ptr %l40, !tbaa !24
  %t81 = load i64, ptr %l44, !tbaa !24
  %t82 = icmp sle i64 %t80, %t81
  br i1 %t82, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_fb93c458ab7e801d_1c40062d0c03aab1)
  unreachable
bb15:
  %t84 = load i64, ptr %l44, !tbaa !24
  %t85 = load i64, ptr %l45, !tbaa !24
  %t86 = icmp sle i64 %t84, %t85
  br i1 %t86, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_fb93c458ab7e801d_1c40062d0c03aab1)
  unreachable
bb17:
  %t88 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !27
  %t90 = load i64, ptr %l40, !tbaa !24
  %t91 = load i64, ptr %l44, !tbaa !24
  %t92 = getelementptr i8, ptr %t89, i64 %t90
  %t93 = sub i64 %t91, %t90
  %t94 = insertvalue { i64, ptr } undef, i64 %t93, 0
  %t95 = insertvalue { i64, ptr } %t94, ptr %t92, 1
  %t96 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t99 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %t95, { i64, ptr } %t96)
  store i1 %t99, ptr %l51
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_fb93c458ab7e801d_1c40062d0c03aab1)
  unreachable
bb19:
  %t100 = load i1, ptr %l51, !tbaa !21
  %t101 = xor i1 %t100, true
  store i1 %t101, ptr %l38, !tbaa !21
  br label %bb20
bb20:
  %t103 = load i1, ptr %l38, !tbaa !21
  br i1 %t103, label %bb21, label %bb22
bb21:
  br label %bb38
bb22:
  br label %bb23
bb23:
  %t104 = load i64, ptr %l5, !tbaa !24
  %t106 = icmp sgt i64 %t104, 0
  br i1 %t106, label %bb24, label %bb25
bb24:
  %t108 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t108, ptr %l56, !tbaa !27
  %t109 = load i64, ptr %l5, !tbaa !24
  %t111 = sub i64 %t109, 1
  %t113 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !27
  %t115 = getelementptr i8, ptr %t114, i64 %t111
  %t116 = load i8, ptr %t115, !tbaa !32
  %t118 = call i1 @compiler_2fnames_2eidentChar(i8 %t116)
  store i1 %t118, ptr %l60
  br label %bb26
bb25:
  store i1 false, ptr %l55, !tbaa !21
  br label %bb27
bb26:
  %t119 = load i1, ptr %l60, !tbaa !21
  store i1 %t119, ptr %l55, !tbaa !21
  br label %bb27
bb27:
  %t120 = load i1, ptr %l55, !tbaa !21
  store i1 %t120, ptr %l6, !tbaa !21
  %t121 = load i64, ptr %l5, !tbaa !24
  %t122 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t124 = extractvalue { i64, ptr } %t122, 0
  %t127 = add i64 %t121, %t124
  %t128 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t130 = extractvalue { i64, ptr } %t128, 0
  %t133 = icmp slt i64 %t127, %t130
  br i1 %t133, label %bb28, label %bb29
bb28:
  %t135 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t135, ptr %l69, !tbaa !27
  %t136 = load i64, ptr %l5, !tbaa !24
  %t137 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t139 = extractvalue { i64, ptr } %t137, 0
  %t142 = add i64 %t136, %t139
  %t144 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t145 = load ptr, ptr %t144, !tbaa !27
  %t146 = getelementptr i8, ptr %t145, i64 %t142
  %t147 = load i8, ptr %t146, !tbaa !32
  %t149 = call i1 @compiler_2fnames_2eidentChar(i8 %t147)
  store i1 %t149, ptr %l75
  br label %bb30
bb29:
  store i1 false, ptr %l68, !tbaa !21
  br label %bb31
bb30:
  %t150 = load i1, ptr %l75, !tbaa !21
  store i1 %t150, ptr %l68, !tbaa !21
  br label %bb31
bb31:
  %t151 = load i1, ptr %l68, !tbaa !21
  store i1 %t151, ptr %l7, !tbaa !21
  %t152 = load i1, ptr %l6, !tbaa !21
  %t154 = xor i1 %t152, true
  br i1 %t154, label %bb32, label %bb33
bb32:
  %t156 = load i1, ptr %l7, !tbaa !21
  %t158 = xor i1 %t156, true
  store i1 %t158, ptr %l78, !tbaa !21
  br label %bb34
bb33:
  store i1 false, ptr %l78, !tbaa !21
  br label %bb34
bb34:
  %t160 = load i1, ptr %l78, !tbaa !21
  br i1 %t160, label %bb35, label %bb36
bb35:
  store i1 true, ptr %rv
  br label %ret
bb36:
  br label %bb37
bb37:
  br label %bb38
bb38:
  %t162 = load i64, ptr %l5, !tbaa !24
  %t165 = add i64 %t162, 1
  store i64 %t165, ptr %l5, !tbaa !24
  br label %bb7
bb39:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eResolve(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca i64
  %l16 = alloca { i64, ptr }
  %l17 = alloca %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l18 = alloca %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed"
  %l19 = alloca %"compiler/names:Entry"
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca ptr
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l48 = alloca i64
  %l52 = alloca i64
  %l55 = alloca i64
  %l74 = alloca ptr
  %l75 = alloca %"compiler/names:Table"
  %l83 = alloca i64
  %l87 = alloca i64
  %l90 = alloca i64
  %l112 = alloca ptr
  %l122 = alloca ptr
  %l125 = alloca i64
  %l127 = alloca i64
  %l132 = alloca { i64, ptr }
  %l133 = alloca { i64, ptr }
  %l135 = alloca i1
  %l137 = alloca ptr
  %l142 = alloca i32
  %l150 = alloca ptr
  %l153 = alloca %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l154 = alloca %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed"
  %l156 = alloca %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed"
  %l157 = alloca i32
  %l159 = alloca i1
  %l163 = alloca ptr
  %l167 = alloca %"compiler/names:Entry"
  %l170 = alloca i1
  %l173 = alloca i1
  %l176 = alloca { i64, ptr }
  %l177 = alloca { i64, ptr }
  %l179 = alloca i1
  %l181 = alloca ptr
  %l182 = alloca i32
  %l186 = alloca %"compiler/names:Ref"
  %l189 = alloca i1
  %l192 = alloca { i64, ptr }
  %l193 = alloca { i64, ptr }
  %l195 = alloca i1
  %l197 = alloca ptr
  %l198 = alloca i32
  %l202 = alloca %"compiler/names:Ref"
  %l209 = alloca i64
  %l213 = alloca i64
  %l216 = alloca i64
  %l238 = alloca ptr
  %l250 = alloca i64
  %l254 = alloca i64
  %l257 = alloca i64
  %l275 = alloca ptr
  %l276 = alloca i64
  %l281 = alloca ptr
  %l290 = alloca i64
  %l294 = alloca i64
  %l297 = alloca i64
  %l319 = alloca ptr
  %l334 = alloca i64
  %l338 = alloca i64
  %l341 = alloca i64
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %t59 = alloca %"compiler/names:Table", align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/names:Resolver", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/load:Loader", ptr %t4, i32 0, i32 10
  %t8 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %t6)
  store i64 %t8, ptr %l48
  br label %bb1
bb1:
  %t9 = load i64, ptr %l48, !tbaa !24
  store i64 %t9, ptr %l2, !tbaa !24
  store i64 1, ptr %l3, !tbaa !24
  %t10 = load i64, ptr %l2, !tbaa !24
  %t11 = load i64, ptr %l1, !tbaa !24
  %t14 = icmp sgt i64 %t10, %t11
  br i1 %t14, label %bb2, label %bb3
bb2:
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = icmp sgt i64 %t16, 0
  br i1 %t18, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l52, !tbaa !24
  br label %bb7
bb4:
  %t20 = load i64, ptr %l2, !tbaa !24
  %t21 = load i64, ptr %l1, !tbaa !24
  %t24 = sub i64 %t20, %t21
  %t25 = load i64, ptr %l3, !tbaa !24
  %t28 = add i64 %t24, %t25
  %t30 = sub i64 %t28, 1
  %t31 = load i64, ptr %l3, !tbaa !24
  %t34 = sdiv i64 %t30, %t31
  store i64 %t34, ptr %l55, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l55, !tbaa !24
  br label %bb6
bb6:
  %t36 = load i64, ptr %l55, !tbaa !24
  store i64 %t36, ptr %l52, !tbaa !24
  br label %bb7
bb7:
  %t37 = load i64, ptr %l52, !tbaa !24
  store i64 %t37, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb8
bb8:
  %t38 = load i64, ptr %l5, !tbaa !24
  %t39 = load i64, ptr %l4, !tbaa !24
  %t42 = icmp slt i64 %t38, %t39
  %t44 = xor i1 %t42, true
  br i1 %t44, label %bb9, label %bb10
bb9:
  br label %bb15
bb10:
  br label %bb11
bb11:
  %t46 = load i64, ptr %l1, !tbaa !24
  %t47 = load i64, ptr %l5, !tbaa !24
  %t48 = load i64, ptr %l3, !tbaa !24
  %t51 = mul i64 %t47, %t48
  %t54 = add i64 %t46, %t51
  store i64 %t54, ptr %l6, !tbaa !24
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/names:Resolver", ptr %t56, i32 0, i32 1
  store ptr %t58, ptr %l74, !tbaa !29
  call void @compiler_2fnames_3aTable_2ector(ptr %t59, ptr %v0)
  call void @llvm.memmove.p0.p0.i64(ptr %l75, ptr %t59, i64 320, i1 false)
  br label %bb12
bb12:
  %t60 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 320, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t60, ptr %l75, i64 320, i1 false)
  %t61 = load ptr, ptr %l74, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_H945cb5faf347f41d89f6885b75263baa(ptr %v0, ptr %v0, ptr %t61, ptr %t60)
  br label %bb13
bb13:
  br label %bb14
bb14:
  %t63 = load i64, ptr %l5, !tbaa !24
  %t66 = add i64 %t63, 1
  store i64 %t66, ptr %l5, !tbaa !24
  br label %bb8
bb15:
  store i64 0, ptr %l7, !tbaa !24
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/names:Resolver", ptr %t68, i32 0, i32 0
  %t71 = load ptr, ptr %t70, !tbaa !29
  %t73 = getelementptr %"compiler/load:Loader", ptr %t71, i32 0, i32 10
  %t75 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %t73)
  store i64 %t75, ptr %l83
  br label %bb16
bb16:
  %t76 = load i64, ptr %l83, !tbaa !24
  store i64 %t76, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t77 = load i64, ptr %l8, !tbaa !24
  %t78 = load i64, ptr %l7, !tbaa !24
  %t81 = icmp sgt i64 %t77, %t78
  br i1 %t81, label %bb17, label %bb18
bb17:
  %t83 = load i64, ptr %l9, !tbaa !24
  %t85 = icmp sgt i64 %t83, 0
  br i1 %t85, label %bb19, label %bb20
bb18:
  store i64 0, ptr %l87, !tbaa !24
  br label %bb22
bb19:
  %t87 = load i64, ptr %l8, !tbaa !24
  %t88 = load i64, ptr %l7, !tbaa !24
  %t91 = sub i64 %t87, %t88
  %t92 = load i64, ptr %l9, !tbaa !24
  %t95 = add i64 %t91, %t92
  %t97 = sub i64 %t95, 1
  %t98 = load i64, ptr %l9, !tbaa !24
  %t101 = sdiv i64 %t97, %t98
  store i64 %t101, ptr %l90, !tbaa !24
  br label %bb21
bb20:
  store i64 0, ptr %l90, !tbaa !24
  br label %bb21
bb21:
  %t103 = load i64, ptr %l90, !tbaa !24
  store i64 %t103, ptr %l87, !tbaa !24
  br label %bb22
bb22:
  %t104 = load i64, ptr %l87, !tbaa !24
  store i64 %t104, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb23
bb23:
  %t105 = load i64, ptr %l11, !tbaa !24
  %t106 = load i64, ptr %l10, !tbaa !24
  %t109 = icmp slt i64 %t105, %t106
  %t111 = xor i1 %t109, true
  br i1 %t111, label %bb24, label %bb25
bb24:
  br label %bb82
bb25:
  br label %bb26
bb26:
  %t113 = load i64, ptr %l7, !tbaa !24
  %t114 = load i64, ptr %l11, !tbaa !24
  %t115 = load i64, ptr %l9, !tbaa !24
  %t118 = mul i64 %t114, %t115
  %t121 = add i64 %t113, %t118
  store i64 %t121, ptr %l12, !tbaa !24
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"compiler/names:Resolver", ptr %t123, i32 0, i32 0
  %t126 = load ptr, ptr %t125, !tbaa !29
  %t128 = getelementptr %"compiler/load:Loader", ptr %t126, i32 0, i32 10
  %t129 = load i64, ptr %l12, !tbaa !24
  %t132 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t128, i64 %t129)
  store ptr %t132, ptr %l112
  br label %bb27
bb27:
  %t133 = load ptr, ptr %l112, !tbaa !29
  %t136 = getelementptr %"compiler/load:Module", ptr %t133, i32 0, i32 3
  %t137 = load i1, ptr %t136, !tbaa !21
  %t139 = xor i1 %t137, true
  br i1 %t139, label %bb28, label %bb29
bb28:
  br label %bb81
bb29:
  br label %bb30
bb30:
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t142 = load i64, ptr %l12, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etableOf(ptr %v0, ptr %t141, i64 %t142)
  br label %bb31
bb31:
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t147 = getelementptr %"compiler/names:Resolver", ptr %t145, i32 0, i32 0
  %t148 = load ptr, ptr %t147, !tbaa !29
  %t150 = getelementptr %"compiler/load:Loader", ptr %t148, i32 0, i32 10
  %t151 = load i64, ptr %l12, !tbaa !24
  %t154 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t150, i64 %t151)
  store ptr %t154, ptr %l122
  br label %bb32
bb32:
  %t155 = load ptr, ptr %l122, !tbaa !29
  %t157 = getelementptr %"compiler/load:Module", ptr %t155, i32 0, i32 9
  store ptr %t157, ptr %l14, !tbaa !29
  store i64 0, ptr %l15, !tbaa !24
  br label %bb33
bb33:
  %t159 = load i64, ptr %l15, !tbaa !24
  store i64 %t159, ptr %l125, !tbaa !24
  %t160 = load ptr, ptr %l14, !tbaa !29
  %t162 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t160)
  store i64 %t162, ptr %l127
  br label %bb34
bb34:
  %t163 = load i64, ptr %l125, !tbaa !24
  %t164 = load i64, ptr %l127, !tbaa !24
  %t165 = icmp slt i64 %t163, %t164
  %t167 = xor i1 %t165, true
  br i1 %t167, label %bb35, label %bb36
bb35:
  br label %bb46
bb36:
  br label %bb37
bb37:
  %t169 = load ptr, ptr %l14, !tbaa !29
  %t170 = load i64, ptr %l15, !tbaa !24
  %t173 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t169, i64 %t170)
  store { i64, ptr } %t173, ptr %l132
  br label %bb38
bb38:
  %t174 = load { i64, ptr }, ptr %l132, !tbaa !27
  store { i64, ptr } %t174, ptr %l16, !tbaa !27
  %t175 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t175, ptr %l133, !tbaa !27
  %t176 = getelementptr { i64, ptr }, ptr %l133, i32 0, i32 1
  %t177 = load ptr, ptr %t176, !tbaa !27
  %t178 = getelementptr i8, ptr %t177, i64 0
  %t179 = load i8, ptr %t178, !tbaa !32
  %t181 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %t179)
  store i1 %t181, ptr %l135
  br label %bb39
bb39:
  %t182 = load i1, ptr %l135, !tbaa !21
  br i1 %t182, label %bb40, label %bb41
bb40:
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t185 = getelementptr %"compiler/names:Resolver", ptr %t183, i32 0, i32 2
  store ptr %t185, ptr %l137, !tbaa !29
  %t186 = load ptr, ptr %l0, !tbaa !29
  %t188 = getelementptr %"compiler/names:Resolver", ptr %t186, i32 0, i32 0
  %t189 = load ptr, ptr %t188, !tbaa !29
  %t191 = getelementptr %"compiler/load:Loader", ptr %t189, i32 0, i32 3
  %t192 = load ptr, ptr %t191, !tbaa !29
  %t193 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t196 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v0, ptr %t192, { i64, ptr } %t193)
  store i32 %t196, ptr %l142
  br label %bb42
bb41:
  br label %bb44
bb42:
  %t197 = load i64, ptr %l12, !tbaa !24
  %t198 = load ptr, ptr %l137, !tbaa !29
  %t199 = load i32, ptr %l142, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H862756c16d115e5c03a79726209f69fa(ptr %v0, ptr %t198, i32 %t199, i64 %t197)
  br label %bb43
bb43:
  br label %bb44
bb44:
  br label %bb45
bb45:
  %t201 = load i64, ptr %l15, !tbaa !24
  %t204 = add i64 %t201, 1
  store i64 %t204, ptr %l15, !tbaa !24
  br label %bb33
bb46:
  %t206 = load ptr, ptr %l0, !tbaa !29
  %t208 = getelementptr %"compiler/names:Resolver", ptr %t206, i32 0, i32 1
  %t209 = load i64, ptr %l12, !tbaa !24
  %t212 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v0, ptr %t208, i64 %t209)
  store ptr %t212, ptr %l150
  br label %bb47
bb47:
  %t213 = load ptr, ptr %l150, !tbaa !29
  %t215 = getelementptr %"compiler/names:Table", ptr %t213, i32 0, i32 1
  %t217 = call %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_Hda627d7755eecb5b938ca977110d67b2(ptr %v0, ptr %v0, ptr %t215)
  store %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" %t217, ptr %l153
  br label %bb48
bb48:
  %t218 = load %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9", ptr %l153
  store %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" %t218, ptr %l17
  br label %bb49
bb49:
  store %olang.scope zeroinitializer, ptr %s12
  %t220 = call { i32, %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3ccompiler_2fsource_3aNameId_2c_20I6_Hd1b8e91149b724287340e79c8c928444(ptr %v0, ptr %l17)
  %t221 = extractvalue { i32, %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed" } %t220, 1
  %t222 = extractvalue { i32, %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed" } %t220, 0
  store i32 %t222, ptr %l157
  %t223 = icmp ne i32 %t222, 0
  br i1 %t223, label %bb51, label %ok.224, !prof !99
ok.224:
  store %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed" %t221, ptr %l156
  br label %bb50
bb50:
  %t225 = load %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed", ptr %l156
  store %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed" %t225, ptr %l154
  br label %bb53
bb51:
  %t226 = load i32, ptr %l157, !tbaa !23
  %t227 = ashr i32 %t226, 16
  %t229 = icmp eq i32 %t227, 1
  store i1 %t229, ptr %l159, !tbaa !21
  br label %bb52
bb52:
  call void @__olang_scope_close(ptr %s12)
  br label %bb80
bb53:
  %t230 = load %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed", ptr %l154
  store %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed" %t230, ptr %l18
  %t231 = load ptr, ptr %l0, !tbaa !29
  %t233 = getelementptr %"compiler/names:Resolver", ptr %t231, i32 0, i32 1
  %t234 = load i64, ptr %l12, !tbaa !24
  %t237 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v0, ptr %t233, i64 %t234)
  store ptr %t237, ptr %l163
  br label %bb54
bb54:
  %t238 = load ptr, ptr %l163, !tbaa !29
  %t240 = getelementptr %"compiler/names:Table", ptr %t238, i32 0, i32 0
  %t241 = getelementptr %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed", ptr %l18, i32 0, i32 1
  %t242 = load i64, ptr %t241, !tbaa !24
  %t245 = call %"compiler/names:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %v0, ptr %t240, i64 %t242)
  store %"compiler/names:Entry" %t245, ptr %l167
  br label %bb55
bb55:
  %t246 = load %"compiler/names:Entry", ptr %l167
  store %"compiler/names:Entry" %t246, ptr %l19
  %t247 = getelementptr %"compiler/names:Entry", ptr %l19, i32 0, i32 2
  %t248 = load i32, ptr %t247, !range !{i32 0, i32 9}
  %t250 = trunc i64 2 to i32
  %t251 = icmp eq i32 %t248, %t250
  br i1 %t251, label %bb56, label %bb57
bb56:
  %t253 = getelementptr %"compiler/names:Entry", ptr %l19, i32 0, i32 3
  %t254 = load i1, ptr %t253, !tbaa !21
  %t256 = xor i1 %t254, true
  store i1 %t256, ptr %l170, !tbaa !21
  br label %bb58
bb57:
  store i1 false, ptr %l170, !tbaa !21
  br label %bb58
bb58:
  %t258 = load i1, ptr %l170, !tbaa !21
  br i1 %t258, label %bb59, label %bb60
bb59:
  %t259 = load ptr, ptr %l0, !tbaa !29
  %t260 = getelementptr %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed", ptr %l18, i32 0, i32 0
  %t261 = load i32, ptr %t260, !tbaa !23
  %t264 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %s12, ptr %t259, i32 %t261)
  store { i64, ptr } %t264, ptr %l176
  br label %bb61
bb60:
  store i1 false, ptr %l173, !tbaa !21
  br label %bb63
bb61:
  %t265 = load { i64, ptr }, ptr %l176, !tbaa !27
  store { i64, ptr } %t265, ptr %l177, !tbaa !27
  %t266 = getelementptr { i64, ptr }, ptr %l177, i32 0, i32 1
  %t267 = load ptr, ptr %t266, !tbaa !27
  %t268 = getelementptr i8, ptr %t267, i64 0
  %t269 = load i8, ptr %t268, !tbaa !32
  %t271 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %t269)
  store i1 %t271, ptr %l179
  br label %bb62
bb62:
  %t272 = load i1, ptr %l179, !tbaa !21
  store i1 %t272, ptr %l173, !tbaa !21
  br label %bb63
bb63:
  %t273 = load i1, ptr %l173, !tbaa !21
  br i1 %t273, label %bb64, label %bb65
bb64:
  store %olang.scope zeroinitializer, ptr %s13
  %t274 = load ptr, ptr %l0, !tbaa !29
  %t276 = getelementptr %"compiler/names:Resolver", ptr %t274, i32 0, i32 3
  store ptr %t276, ptr %l181, !tbaa !29
  %t277 = getelementptr %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed", ptr %l18, i32 0, i32 0
  %t278 = load i32, ptr %t277, !tbaa !23
  store i32 %t278, ptr %l182, !tbaa !23
  %t279 = load i64, ptr %l12, !tbaa !24
  %t280 = getelementptr %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed", ptr %l18, i32 0, i32 1
  %t281 = load i64, ptr %t280, !tbaa !24
  %t285 = call %"compiler/names:Ref" @compiler_2fnames_3aRef_2ector(ptr %s13, i32 2, i64 %t279, i64 %t281)
  store %"compiler/names:Ref" %t285, ptr %l186
  br label %bb66
bb65:
  br label %bb68
bb66:
  %t286 = load ptr, ptr %l181, !tbaa !29
  %t287 = load i32, ptr %l182, !tbaa !23
  %t288 = load %"compiler/names:Ref", ptr %l186
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_H456f40e55a35e282608933ec0991ad61(ptr %v0, ptr %t286, i32 %t287, %"compiler/names:Ref" %t288)
  br label %bb67
bb67:
  call void @__olang_scope_close(ptr %s13)
  br label %bb68
bb68:
  %t289 = getelementptr %"compiler/names:Entry", ptr %l19, i32 0, i32 2
  %t290 = load i32, ptr %t289, !range !{i32 0, i32 9}
  %t292 = trunc i64 3 to i32
  %t293 = icmp eq i32 %t290, %t292
  br i1 %t293, label %bb69, label %bb70
bb69:
  %t295 = load ptr, ptr %l0, !tbaa !29
  %t296 = getelementptr %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed", ptr %l18, i32 0, i32 0
  %t297 = load i32, ptr %t296, !tbaa !23
  %t300 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %s12, ptr %t295, i32 %t297)
  store { i64, ptr } %t300, ptr %l192
  br label %bb71
bb70:
  store i1 false, ptr %l189, !tbaa !21
  br label %bb73
bb71:
  %t301 = load { i64, ptr }, ptr %l192, !tbaa !27
  store { i64, ptr } %t301, ptr %l193, !tbaa !27
  %t302 = getelementptr { i64, ptr }, ptr %l193, i32 0, i32 1
  %t303 = load ptr, ptr %t302, !tbaa !27
  %t304 = getelementptr i8, ptr %t303, i64 0
  %t305 = load i8, ptr %t304, !tbaa !32
  %t307 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %t305)
  store i1 %t307, ptr %l195
  br label %bb72
bb72:
  %t308 = load i1, ptr %l195, !tbaa !21
  store i1 %t308, ptr %l189, !tbaa !21
  br label %bb73
bb73:
  %t309 = load i1, ptr %l189, !tbaa !21
  br i1 %t309, label %bb74, label %bb75
bb74:
  store %olang.scope zeroinitializer, ptr %s14
  %t310 = load ptr, ptr %l0, !tbaa !29
  %t312 = getelementptr %"compiler/names:Resolver", ptr %t310, i32 0, i32 3
  store ptr %t312, ptr %l197, !tbaa !29
  %t313 = getelementptr %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed", ptr %l18, i32 0, i32 0
  %t314 = load i32, ptr %t313, !tbaa !23
  store i32 %t314, ptr %l198, !tbaa !23
  %t315 = load i64, ptr %l12, !tbaa !24
  %t316 = getelementptr %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed", ptr %l18, i32 0, i32 1
  %t317 = load i64, ptr %t316, !tbaa !24
  %t321 = call %"compiler/names:Ref" @compiler_2fnames_3aRef_2ector(ptr %s14, i32 3, i64 %t315, i64 %t317)
  store %"compiler/names:Ref" %t321, ptr %l202
  br label %bb76
bb75:
  br label %bb78
bb76:
  %t322 = load ptr, ptr %l197, !tbaa !29
  %t323 = load i32, ptr %l198, !tbaa !23
  %t324 = load %"compiler/names:Ref", ptr %l202
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_H456f40e55a35e282608933ec0991ad61(ptr %v0, ptr %t322, i32 %t323, %"compiler/names:Ref" %t324)
  br label %bb77
bb77:
  call void @__olang_scope_close(ptr %s14)
  br label %bb78
bb78:
  call void @__olang_scope_close(ptr %s12)
  br label %bb79
bb79:
  br label %bb49
bb80:
  br label %bb81
bb81:
  %t325 = load i64, ptr %l11, !tbaa !24
  %t328 = add i64 %t325, 1
  store i64 %t328, ptr %l11, !tbaa !24
  br label %bb23
bb82:
  store i64 0, ptr %l20, !tbaa !24
  %t330 = load ptr, ptr %l0, !tbaa !29
  %t332 = getelementptr %"compiler/names:Resolver", ptr %t330, i32 0, i32 0
  %t333 = load ptr, ptr %t332, !tbaa !29
  %t335 = getelementptr %"compiler/load:Loader", ptr %t333, i32 0, i32 10
  %t337 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %t335)
  store i64 %t337, ptr %l209
  br label %bb83
bb83:
  %t338 = load i64, ptr %l209, !tbaa !24
  store i64 %t338, ptr %l21, !tbaa !24
  store i64 1, ptr %l22, !tbaa !24
  %t339 = load i64, ptr %l21, !tbaa !24
  %t340 = load i64, ptr %l20, !tbaa !24
  %t343 = icmp sgt i64 %t339, %t340
  br i1 %t343, label %bb84, label %bb85
bb84:
  %t345 = load i64, ptr %l22, !tbaa !24
  %t347 = icmp sgt i64 %t345, 0
  br i1 %t347, label %bb86, label %bb87
bb85:
  store i64 0, ptr %l213, !tbaa !24
  br label %bb89
bb86:
  %t349 = load i64, ptr %l21, !tbaa !24
  %t350 = load i64, ptr %l20, !tbaa !24
  %t353 = sub i64 %t349, %t350
  %t354 = load i64, ptr %l22, !tbaa !24
  %t357 = add i64 %t353, %t354
  %t359 = sub i64 %t357, 1
  %t360 = load i64, ptr %l22, !tbaa !24
  %t363 = sdiv i64 %t359, %t360
  store i64 %t363, ptr %l216, !tbaa !24
  br label %bb88
bb87:
  store i64 0, ptr %l216, !tbaa !24
  br label %bb88
bb88:
  %t365 = load i64, ptr %l216, !tbaa !24
  store i64 %t365, ptr %l213, !tbaa !24
  br label %bb89
bb89:
  %t366 = load i64, ptr %l213, !tbaa !24
  store i64 %t366, ptr %l23, !tbaa !24
  store i64 0, ptr %l24, !tbaa !24
  br label %bb90
bb90:
  %t367 = load i64, ptr %l24, !tbaa !24
  %t368 = load i64, ptr %l23, !tbaa !24
  %t371 = icmp slt i64 %t367, %t368
  %t373 = xor i1 %t371, true
  br i1 %t373, label %bb91, label %bb92
bb91:
  br label %bb100
bb92:
  br label %bb93
bb93:
  %t375 = load i64, ptr %l20, !tbaa !24
  %t376 = load i64, ptr %l24, !tbaa !24
  %t377 = load i64, ptr %l22, !tbaa !24
  %t380 = mul i64 %t376, %t377
  %t383 = add i64 %t375, %t380
  store i64 %t383, ptr %l25, !tbaa !24
  %t385 = load ptr, ptr %l0, !tbaa !29
  %t387 = getelementptr %"compiler/names:Resolver", ptr %t385, i32 0, i32 0
  %t388 = load ptr, ptr %t387, !tbaa !29
  %t390 = getelementptr %"compiler/load:Loader", ptr %t388, i32 0, i32 10
  %t391 = load i64, ptr %l25, !tbaa !24
  %t394 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t390, i64 %t391)
  store ptr %t394, ptr %l238
  br label %bb94
bb94:
  %t395 = load ptr, ptr %l238, !tbaa !29
  %t397 = getelementptr %"compiler/load:Module", ptr %t395, i32 0, i32 3
  %t398 = load i1, ptr %t397, !tbaa !21
  %t400 = xor i1 %t398, true
  br i1 %t400, label %bb95, label %bb96
bb95:
  %t402 = load ptr, ptr %l0, !tbaa !29
  %t403 = load i64, ptr %l25, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etableOf(ptr %v0, ptr %t402, i64 %t403)
  br label %bb97
bb96:
  br label %bb98
bb97:
  br label %bb98
bb98:
  br label %bb99
bb99:
  %t406 = load i64, ptr %l24, !tbaa !24
  %t409 = add i64 %t406, 1
  store i64 %t409, ptr %l24, !tbaa !24
  br label %bb90
bb100:
  store i64 0, ptr %l26, !tbaa !24
  %t411 = load ptr, ptr %l0, !tbaa !29
  %t413 = getelementptr %"compiler/names:Resolver", ptr %t411, i32 0, i32 0
  %t414 = load ptr, ptr %t413, !tbaa !29
  %t416 = getelementptr %"compiler/load:Loader", ptr %t414, i32 0, i32 10
  %t418 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %t416)
  store i64 %t418, ptr %l250
  br label %bb101
bb101:
  %t419 = load i64, ptr %l250, !tbaa !24
  store i64 %t419, ptr %l27, !tbaa !24
  store i64 1, ptr %l28, !tbaa !24
  %t420 = load i64, ptr %l27, !tbaa !24
  %t421 = load i64, ptr %l26, !tbaa !24
  %t424 = icmp sgt i64 %t420, %t421
  br i1 %t424, label %bb102, label %bb103
bb102:
  %t426 = load i64, ptr %l28, !tbaa !24
  %t428 = icmp sgt i64 %t426, 0
  br i1 %t428, label %bb104, label %bb105
bb103:
  store i64 0, ptr %l254, !tbaa !24
  br label %bb107
bb104:
  %t430 = load i64, ptr %l27, !tbaa !24
  %t431 = load i64, ptr %l26, !tbaa !24
  %t434 = sub i64 %t430, %t431
  %t435 = load i64, ptr %l28, !tbaa !24
  %t438 = add i64 %t434, %t435
  %t440 = sub i64 %t438, 1
  %t441 = load i64, ptr %l28, !tbaa !24
  %t444 = sdiv i64 %t440, %t441
  store i64 %t444, ptr %l257, !tbaa !24
  br label %bb106
bb105:
  store i64 0, ptr %l257, !tbaa !24
  br label %bb106
bb106:
  %t446 = load i64, ptr %l257, !tbaa !24
  store i64 %t446, ptr %l254, !tbaa !24
  br label %bb107
bb107:
  %t447 = load i64, ptr %l254, !tbaa !24
  store i64 %t447, ptr %l29, !tbaa !24
  store i64 0, ptr %l30, !tbaa !24
  br label %bb108
bb108:
  %t448 = load i64, ptr %l30, !tbaa !24
  %t449 = load i64, ptr %l29, !tbaa !24
  %t452 = icmp slt i64 %t448, %t449
  %t454 = xor i1 %t452, true
  br i1 %t454, label %bb109, label %bb110
bb109:
  br label %bb115
bb110:
  br label %bb111
bb111:
  %t456 = load i64, ptr %l26, !tbaa !24
  %t457 = load i64, ptr %l30, !tbaa !24
  %t458 = load i64, ptr %l28, !tbaa !24
  %t461 = mul i64 %t457, %t458
  %t464 = add i64 %t456, %t461
  store i64 %t464, ptr %l31, !tbaa !24
  %t466 = load ptr, ptr %l0, !tbaa !29
  store ptr %t466, ptr %l275, !tbaa !29
  %t467 = load i64, ptr %l31, !tbaa !24
  store i64 %t467, ptr %l276, !tbaa !24
  %t468 = load ptr, ptr %l0, !tbaa !29
  %t470 = getelementptr %"compiler/names:Resolver", ptr %t468, i32 0, i32 0
  %t471 = load ptr, ptr %t470, !tbaa !29
  %t473 = getelementptr %"compiler/load:Loader", ptr %t471, i32 0, i32 10
  %t474 = load i64, ptr %l31, !tbaa !24
  %t477 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t473, i64 %t474)
  store ptr %t477, ptr %l281
  br label %bb112
bb112:
  %t478 = load ptr, ptr %l281, !tbaa !29
  %t480 = getelementptr %"compiler/load:Module", ptr %t478, i32 0, i32 8
  %t481 = load { i64, ptr }, ptr %t480, !tbaa !27
  %t482 = load ptr, ptr %l275, !tbaa !29
  %t483 = load i64, ptr %l276, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eraisedErrors(ptr %v0, ptr %v0, ptr %t482, i64 %t483, { i64, ptr } %t481)
  br label %bb113
bb113:
  br label %bb114
bb114:
  %t485 = load i64, ptr %l30, !tbaa !24
  %t488 = add i64 %t485, 1
  store i64 %t488, ptr %l30, !tbaa !24
  br label %bb108
bb115:
  store i64 0, ptr %l32, !tbaa !24
  %t490 = load ptr, ptr %l0, !tbaa !29
  %t492 = getelementptr %"compiler/names:Resolver", ptr %t490, i32 0, i32 0
  %t493 = load ptr, ptr %t492, !tbaa !29
  %t495 = getelementptr %"compiler/load:Loader", ptr %t493, i32 0, i32 10
  %t497 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %t495)
  store i64 %t497, ptr %l290
  br label %bb116
bb116:
  %t498 = load i64, ptr %l290, !tbaa !24
  store i64 %t498, ptr %l33, !tbaa !24
  store i64 1, ptr %l34, !tbaa !24
  %t499 = load i64, ptr %l33, !tbaa !24
  %t500 = load i64, ptr %l32, !tbaa !24
  %t503 = icmp sgt i64 %t499, %t500
  br i1 %t503, label %bb117, label %bb118
bb117:
  %t505 = load i64, ptr %l34, !tbaa !24
  %t507 = icmp sgt i64 %t505, 0
  br i1 %t507, label %bb119, label %bb120
bb118:
  store i64 0, ptr %l294, !tbaa !24
  br label %bb122
bb119:
  %t509 = load i64, ptr %l33, !tbaa !24
  %t510 = load i64, ptr %l32, !tbaa !24
  %t513 = sub i64 %t509, %t510
  %t514 = load i64, ptr %l34, !tbaa !24
  %t517 = add i64 %t513, %t514
  %t519 = sub i64 %t517, 1
  %t520 = load i64, ptr %l34, !tbaa !24
  %t523 = sdiv i64 %t519, %t520
  store i64 %t523, ptr %l297, !tbaa !24
  br label %bb121
bb120:
  store i64 0, ptr %l297, !tbaa !24
  br label %bb121
bb121:
  %t525 = load i64, ptr %l297, !tbaa !24
  store i64 %t525, ptr %l294, !tbaa !24
  br label %bb122
bb122:
  %t526 = load i64, ptr %l294, !tbaa !24
  store i64 %t526, ptr %l35, !tbaa !24
  store i64 0, ptr %l36, !tbaa !24
  br label %bb123
bb123:
  %t527 = load i64, ptr %l36, !tbaa !24
  %t528 = load i64, ptr %l35, !tbaa !24
  %t531 = icmp slt i64 %t527, %t528
  %t533 = xor i1 %t531, true
  br i1 %t533, label %bb124, label %bb125
bb124:
  br label %bb133
bb125:
  br label %bb126
bb126:
  %t535 = load i64, ptr %l32, !tbaa !24
  %t536 = load i64, ptr %l36, !tbaa !24
  %t537 = load i64, ptr %l34, !tbaa !24
  %t540 = mul i64 %t536, %t537
  %t543 = add i64 %t535, %t540
  store i64 %t543, ptr %l37, !tbaa !24
  %t545 = load ptr, ptr %l0, !tbaa !29
  %t547 = getelementptr %"compiler/names:Resolver", ptr %t545, i32 0, i32 0
  %t548 = load ptr, ptr %t547, !tbaa !29
  %t550 = getelementptr %"compiler/load:Loader", ptr %t548, i32 0, i32 10
  %t551 = load i64, ptr %l37, !tbaa !24
  %t554 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t550, i64 %t551)
  store ptr %t554, ptr %l319
  br label %bb127
bb127:
  %t555 = load ptr, ptr %l319, !tbaa !29
  store ptr %t555, ptr %l38, !tbaa !29
  %t556 = load ptr, ptr %l38, !tbaa !29
  %t558 = getelementptr %"compiler/load:Module", ptr %t556, i32 0, i32 8
  %t559 = load { i64, ptr }, ptr %t558, !tbaa !27
  %t561 = extractvalue { i64, ptr } %t559, 0
  %t563 = icmp sgt i64 %t561, 0
  br i1 %t563, label %bb128, label %bb129
bb128:
  %t565 = load ptr, ptr %l0, !tbaa !29
  %t566 = load i64, ptr %l37, !tbaa !24
  %t567 = load ptr, ptr %l38, !tbaa !29
  %t569 = getelementptr %"compiler/load:Module", ptr %t567, i32 0, i32 8
  %t570 = load { i64, ptr }, ptr %t569, !tbaa !27
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ebodies(ptr %v0, ptr %v0, ptr %t565, i64 %t566, { i64, ptr } %t570)
  br label %bb130
bb129:
  br label %bb131
bb130:
  br label %bb131
bb131:
  br label %bb132
bb132:
  %t574 = load i64, ptr %l36, !tbaa !24
  %t577 = add i64 %t574, 1
  store i64 %t577, ptr %l36, !tbaa !24
  br label %bb123
bb133:
  store i64 0, ptr %l39, !tbaa !24
  %t579 = load ptr, ptr %l0, !tbaa !29
  %t581 = getelementptr %"compiler/names:Resolver", ptr %t579, i32 0, i32 0
  %t582 = load ptr, ptr %t581, !tbaa !29
  %t584 = getelementptr %"compiler/load:Loader", ptr %t582, i32 0, i32 10
  %t586 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %t584)
  store i64 %t586, ptr %l334
  br label %bb134
bb134:
  %t587 = load i64, ptr %l334, !tbaa !24
  store i64 %t587, ptr %l40, !tbaa !24
  store i64 1, ptr %l41, !tbaa !24
  %t588 = load i64, ptr %l40, !tbaa !24
  %t589 = load i64, ptr %l39, !tbaa !24
  %t592 = icmp sgt i64 %t588, %t589
  br i1 %t592, label %bb135, label %bb136
bb135:
  %t594 = load i64, ptr %l41, !tbaa !24
  %t596 = icmp sgt i64 %t594, 0
  br i1 %t596, label %bb137, label %bb138
bb136:
  store i64 0, ptr %l338, !tbaa !24
  br label %bb140
bb137:
  %t598 = load i64, ptr %l40, !tbaa !24
  %t599 = load i64, ptr %l39, !tbaa !24
  %t602 = sub i64 %t598, %t599
  %t603 = load i64, ptr %l41, !tbaa !24
  %t606 = add i64 %t602, %t603
  %t608 = sub i64 %t606, 1
  %t609 = load i64, ptr %l41, !tbaa !24
  %t612 = sdiv i64 %t608, %t609
  store i64 %t612, ptr %l341, !tbaa !24
  br label %bb139
bb138:
  store i64 0, ptr %l341, !tbaa !24
  br label %bb139
bb139:
  %t614 = load i64, ptr %l341, !tbaa !24
  store i64 %t614, ptr %l338, !tbaa !24
  br label %bb140
bb140:
  %t615 = load i64, ptr %l338, !tbaa !24
  store i64 %t615, ptr %l42, !tbaa !24
  store i64 0, ptr %l43, !tbaa !24
  br label %bb141
bb141:
  %t616 = load i64, ptr %l43, !tbaa !24
  %t617 = load i64, ptr %l42, !tbaa !24
  %t620 = icmp slt i64 %t616, %t617
  %t622 = xor i1 %t620, true
  br i1 %t622, label %bb142, label %bb143
bb142:
  br label %bb147
bb143:
  br label %bb144
bb144:
  %t624 = load i64, ptr %l39, !tbaa !24
  %t625 = load i64, ptr %l43, !tbaa !24
  %t626 = load i64, ptr %l41, !tbaa !24
  %t629 = mul i64 %t625, %t626
  %t632 = add i64 %t624, %t629
  %t634 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eunusedImports(ptr %v0, ptr %t634, i64 %t632)
  br label %bb145
bb145:
  br label %bb146
bb146:
  %t638 = load i64, ptr %l43, !tbaa !24
  %t641 = add i64 %t638, 1
  store i64 %t641, ptr %l43, !tbaa !24
  br label %bb141
bb147:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eaddValue(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2, %"compiler/source:Span" %a3, i1 %a4, i1 %a5, i1 %a6, ptr %a7) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i1
  %l5 = alloca i1
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l11 = alloca i1
  %l12 = alloca i64
  %l19 = alloca ptr
  %l24 = alloca ptr
  %l27 = alloca { i64, ptr }
  %l29 = alloca i1
  %l32 = alloca ptr
  %l36 = alloca { i64, [3 x i64] }
  %l37 = alloca %"compiler/diagmsg:Msg"
  %l38 = alloca i64
  %l41 = alloca ptr
  %l45 = alloca %"compiler/names:Entry"
  %l50 = alloca i1
  %l53 = alloca i1
  %l54 = alloca i1
  %l58 = alloca i1
  %l60 = alloca i1
  %l65 = alloca i1
  %l69 = alloca ptr
  %l73 = alloca { i64, [3 x i64] }
  %l76 = alloca { i64, ptr }
  %l78 = alloca %"compiler/diagmsg:Msg"
  %l79 = alloca i64
  %l83 = alloca ptr
  %l87 = alloca { i64, [3 x i64] }
  %l90 = alloca { i64, ptr }
  %l92 = alloca %"compiler/diagmsg:Msg"
  %l93 = alloca i64
  %l99 = alloca i64
  %l103 = alloca i64
  %l104 = alloca i32
  %l109 = alloca ptr
  %l113 = alloca { i64, [3 x i64] }
  %l116 = alloca { i64, ptr }
  %l118 = alloca %"compiler/diagmsg:Msg"
  %l119 = alloca i64
  %l130 = alloca i1
  %l131 = alloca i1
  %l136 = alloca i1
  %l137 = alloca i1
  %l139 = alloca i1
  %l142 = alloca ptr
  %l146 = alloca { i64, [3 x i64] }
  %l149 = alloca { i64, ptr }
  %l151 = alloca %"compiler/diagmsg:Msg"
  %l152 = alloca i64
  %l156 = alloca i1
  %l161 = alloca i1
  %l167 = alloca ptr
  %l168 = alloca i32
  %l171 = alloca i64
  %l173 = alloca ptr
  %l174 = alloca i32
  %l175 = alloca %"compiler/source:Span"
  %l177 = alloca i32
  %l181 = alloca %"compiler/names:Entry"
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  store i1 %a4, ptr %l4
  store i1 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/names:Resolver", ptr %t1, i32 0, i32 1
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  store ptr %t7, ptr %l19
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l19, !tbaa !29
  store ptr %t8, ptr %l8, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/names:Resolver", ptr %t9, i32 0, i32 0
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = getelementptr %"compiler/load:Loader", ptr %t12, i32 0, i32 10
  %t15 = load i64, ptr %l1, !tbaa !24
  %t18 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t14, i64 %t15)
  store ptr %t18, ptr %l24
  br label %bb2
bb2:
  %t19 = load ptr, ptr %l24, !tbaa !29
  store ptr %t19, ptr %l9, !tbaa !29
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load i32, ptr %l2, !tbaa !23
  %t24 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %v0, ptr %t20, i32 %t21)
  store { i64, ptr } %t24, ptr %l27
  br label %bb3
bb3:
  %t25 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t25, ptr %l10, !tbaa !27
  %t26 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t28 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t26, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d0, i32 0, i32 1) })
  store i1 %t28, ptr %l29
  br label %bb4
bb4:
  %t29 = load i1, ptr %l29, !tbaa !21
  br i1 %t29, label %bb5, label %bb6
bb5:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/names:Resolver", ptr %t30, i32 0, i32 0
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t35 = getelementptr %"compiler/load:Loader", ptr %t33, i32 0, i32 4
  %t36 = load ptr, ptr %t35, !tbaa !29
  store ptr %t36, ptr %l32, !tbaa !29
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load i64, ptr %l1, !tbaa !24
  %t39 = load %"compiler/source:Span", ptr %l3
  %t43 = call { i64, [3 x i64] } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eat(ptr %v0, ptr %t37, i64 %t38, %"compiler/source:Span" %t39)
  store { i64, [3 x i64] } %t43, ptr %l36
  br label %bb7
bb6:
  br label %bb10
bb7:
  %t44 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eUnderscoreDeclared(ptr %v0)
  store %"compiler/diagmsg:Msg" %t44, ptr %l37
  br label %bb8
bb8:
  %t45 = load ptr, ptr %l32, !tbaa !29
  %t46 = load { i64, [3 x i64] }, ptr %l36
  %t47 = load %"compiler/diagmsg:Msg", ptr %l37
  %t48 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v0, ptr %t45, { i64, [3 x i64] } %t46, %"compiler/diagmsg:Msg" %t47)
  store i64 %t48, ptr %l38
  br label %bb9
bb9:
  br label %bb10
bb10:
  br i1 %a6, label %bb11, label %bb12
bb11:
  %t51 = load ptr, ptr %l8, !tbaa !29
  %t53 = getelementptr %"compiler/names:Table", ptr %t51, i32 0, i32 0
  store ptr %t53, ptr %l41, !tbaa !29
  %t54 = load i32, ptr %l2, !tbaa !23
  %t55 = load %"compiler/source:Span", ptr %l3
  %t59 = call %"compiler/names:Entry" @compiler_2fnames_3aEntry_2ector(ptr %v0, ptr %v0, i32 %t54, %"compiler/source:Span" %t55, i32 3, i1 false, ptr null)
  store %"compiler/names:Entry" %t59, ptr %l45
  br label %bb13
bb12:
  br label %bb15
bb13:
  %t60 = load ptr, ptr %l41, !tbaa !29
  %t61 = load %"compiler/names:Entry", ptr %l45
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2ePush_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %v0, ptr %t60, %"compiler/names:Entry" %t61)
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb15:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/names:Resolver", ptr %t62, i32 0, i32 0
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t67 = getelementptr %"compiler/load:Loader", ptr %t65, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !29
  %t69 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t72 = call i1 @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eHas(ptr %v0, ptr %v0, ptr %t68, { i64, ptr } %t69)
  store i1 %t72, ptr %l50
  br label %bb16
bb16:
  %t73 = load i1, ptr %l50, !tbaa !21
  br i1 %t73, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s3
  %t74 = load ptr, ptr %l9, !tbaa !29
  %t76 = getelementptr %"compiler/load:Module", ptr %t74, i32 0, i32 2
  %t77 = load { i64, ptr }, ptr %t76, !tbaa !27
  %t79 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s3, { i64, ptr } %t77, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d1, i32 0, i32 1) })
  store i1 %t79, ptr %l53
  br label %bb19
bb18:
  br label %bb45
bb19:
  %t80 = load i1, ptr %l53, !tbaa !21
  br i1 %t80, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l54, !tbaa !21
  br label %bb22
bb21:
  %t81 = load ptr, ptr %l9, !tbaa !29
  %t83 = getelementptr %"compiler/load:Module", ptr %t81, i32 0, i32 3
  %t84 = load i1, ptr %t83, !tbaa !21
  store i1 %t84, ptr %l54, !tbaa !21
  br label %bb22
bb22:
  %t86 = load i1, ptr %l54, !tbaa !21
  store i1 %t86, ptr %l11, !tbaa !21
  %t87 = load i1, ptr %l5, !tbaa !21
  br i1 %t87, label %bb23, label %bb24
bb23:
  store i1 true, ptr %l58, !tbaa !21
  br label %bb25
bb24:
  %t89 = load i1, ptr %l11, !tbaa !21
  store i1 %t89, ptr %l58, !tbaa !21
  br label %bb25
bb25:
  %t91 = load i1, ptr %l58, !tbaa !21
  br i1 %t91, label %bb26, label %bb27
bb26:
  store i1 true, ptr %l60, !tbaa !21
  br label %bb29
bb27:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/names:Resolver", ptr %t92, i32 0, i32 0
  %t95 = load ptr, ptr %t94, !tbaa !29
  %t97 = getelementptr %"compiler/load:Loader", ptr %t95, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !29
  %t99 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t102 = call i1 @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eDefined(ptr %v0, ptr %v0, ptr %t98, { i64, ptr } %t99)
  store i1 %t102, ptr %l65
  br label %bb28
bb28:
  %t103 = load i1, ptr %l65, !tbaa !21
  %t104 = xor i1 %t103, true
  store i1 %t104, ptr %l60, !tbaa !21
  br label %bb29
bb29:
  %t106 = load i1, ptr %l60, !tbaa !21
  br i1 %t106, label %bb30, label %bb31
bb30:
  store %olang.scope zeroinitializer, ptr %s4
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = getelementptr %"compiler/names:Resolver", ptr %t107, i32 0, i32 0
  %t110 = load ptr, ptr %t109, !tbaa !29
  %t112 = getelementptr %"compiler/load:Loader", ptr %t110, i32 0, i32 4
  %t113 = load ptr, ptr %t112, !tbaa !29
  store ptr %t113, ptr %l69, !tbaa !29
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t115 = load i64, ptr %l1, !tbaa !24
  %t116 = load %"compiler/source:Span", ptr %l3
  %t120 = call { i64, [3 x i64] } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eat(ptr %v0, ptr %t114, i64 %t115, %"compiler/source:Span" %t116)
  store { i64, [3 x i64] } %t120, ptr %l73
  br label %bb32
bb31:
  %t121 = load i1, ptr %l4, !tbaa !21
  br i1 %t121, label %bb36, label %bb37
bb32:
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t124 = load i32, ptr %l2, !tbaa !23
  %t127 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etok(ptr %v0, ptr %s4, ptr %t123, i32 %t124)
  store { i64, ptr } %t127, ptr %l76
  br label %bb33
bb33:
  %t128 = load { i64, ptr }, ptr %l76, !tbaa !27
  %t130 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eBuildConstRedeclared(ptr %s4, ptr %v0, { i64, ptr } %t128)
  store %"compiler/diagmsg:Msg" %t130, ptr %l78
  br label %bb34
bb34:
  %t131 = load ptr, ptr %l69, !tbaa !29
  %t132 = load { i64, [3 x i64] }, ptr %l73
  %t133 = load %"compiler/diagmsg:Msg", ptr %l78
  %t134 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v0, ptr %t131, { i64, [3 x i64] } %t132, %"compiler/diagmsg:Msg" %t133)
  store i64 %t134, ptr %l79
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s4)
  br label %bb44
bb36:
  store %olang.scope zeroinitializer, ptr %s6
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t137 = getelementptr %"compiler/names:Resolver", ptr %t135, i32 0, i32 0
  %t138 = load ptr, ptr %t137, !tbaa !29
  %t140 = getelementptr %"compiler/load:Loader", ptr %t138, i32 0, i32 4
  %t141 = load ptr, ptr %t140, !tbaa !29
  store ptr %t141, ptr %l83, !tbaa !29
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t143 = load i64, ptr %l1, !tbaa !24
  %t144 = load %"compiler/source:Span", ptr %l3
  %t148 = call { i64, [3 x i64] } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eat(ptr %v0, ptr %t142, i64 %t143, %"compiler/source:Span" %t144)
  store { i64, [3 x i64] } %t148, ptr %l87
  br label %bb38
bb37:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t150 = load i64, ptr %l1, !tbaa !24
  %t151 = load i32, ptr %l2, !tbaa !23
  %t152 = load %"compiler/source:Span", ptr %l3
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ebuildDefault(ptr %v0, ptr %v1, ptr %t149, i64 %t150, i32 %t151, %"compiler/source:Span" %t152, ptr %a7)
  br label %bb42
bb38:
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t160 = load i32, ptr %l2, !tbaa !23
  %t163 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etok(ptr %v0, ptr %s6, ptr %t159, i32 %t160)
  store { i64, ptr } %t163, ptr %l90
  br label %bb39
bb39:
  %t164 = load { i64, ptr }, ptr %l90, !tbaa !27
  %t166 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eBuildDefaultMut(ptr %s6, ptr %v0, { i64, ptr } %t164)
  store %"compiler/diagmsg:Msg" %t166, ptr %l92
  br label %bb40
bb40:
  %t167 = load ptr, ptr %l83, !tbaa !29
  %t168 = load { i64, [3 x i64] }, ptr %l87
  %t169 = load %"compiler/diagmsg:Msg", ptr %l92
  %t170 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v0, ptr %t167, { i64, [3 x i64] } %t168, %"compiler/diagmsg:Msg" %t169)
  store i64 %t170, ptr %l93
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s6)
  br label %bb43
bb42:
  br label %bb43
bb43:
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s3)
  br label %bb45
bb45:
  %t171 = load ptr, ptr %l8, !tbaa !29
  %t173 = getelementptr %"compiler/names:Table", ptr %t171, i32 0, i32 1
  %t174 = load i32, ptr %l2, !tbaa !23
  %t177 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %t173, i32 %t174)
  %t178 = extractvalue { i32, i64 } %t177, 1
  %t179 = extractvalue { i32, i64 } %t177, 0
  store i32 %t179, ptr %l104
  %t180 = icmp ne i32 %t179, 0
  br i1 %t180, label %bb47, label %ok.181, !prof !99
ok.181:
  store i64 %t178, ptr %l103
  br label %bb46
bb46:
  %t182 = load i64, ptr %l103, !tbaa !24
  store i64 %t182, ptr %l99, !tbaa !24
  br label %bb49
bb47:
  br label %bb48
bb48:
  store i64 -1, ptr %l99, !tbaa !24
  br label %bb49
bb49:
  %t183 = load i64, ptr %l99, !tbaa !24
  store i64 %t183, ptr %l12, !tbaa !24
  %t184 = load i64, ptr %l12, !tbaa !24
  %t186 = icmp sge i64 %t184, 0
  br i1 %t186, label %bb50, label %bb51
bb50:
  store %olang.scope zeroinitializer, ptr %s8
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t190 = getelementptr %"compiler/names:Resolver", ptr %t188, i32 0, i32 0
  %t191 = load ptr, ptr %t190, !tbaa !29
  %t193 = getelementptr %"compiler/load:Loader", ptr %t191, i32 0, i32 4
  %t194 = load ptr, ptr %t193, !tbaa !29
  store ptr %t194, ptr %l109, !tbaa !29
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t196 = load i64, ptr %l1, !tbaa !24
  %t197 = load %"compiler/source:Span", ptr %l3
  %t201 = call { i64, [3 x i64] } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eat(ptr %v0, ptr %t195, i64 %t196, %"compiler/source:Span" %t197)
  store { i64, [3 x i64] } %t201, ptr %l113
  br label %bb52
bb51:
  br label %bb56
bb52:
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t203 = load i32, ptr %l2, !tbaa !23
  %t206 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etok(ptr %v0, ptr %s8, ptr %t202, i32 %t203)
  store { i64, ptr } %t206, ptr %l116
  br label %bb53
bb53:
  %t207 = load { i64, ptr }, ptr %l116, !tbaa !27
  %t209 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNameInUse(ptr %s8, ptr %v0, { i64, ptr } %t207)
  store %"compiler/diagmsg:Msg" %t209, ptr %l118
  br label %bb54
bb54:
  %t210 = load ptr, ptr %l109, !tbaa !29
  %t211 = load { i64, [3 x i64] }, ptr %l113
  %t212 = load %"compiler/diagmsg:Msg", ptr %l118
  %t213 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v0, ptr %t210, { i64, [3 x i64] } %t211, %"compiler/diagmsg:Msg" %t212)
  store i64 %t213, ptr %l119
  br label %bb55
bb55:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb56:
  %t214 = load i64, ptr %l12, !tbaa !24
  %t216 = icmp slt i64 %t214, 0
  br i1 %t216, label %bb57, label %bb58
bb57:
  %t218 = load ptr, ptr %l0, !tbaa !29
  %t219 = load i64, ptr %l1, !tbaa !24
  %t220 = load i32, ptr %l2, !tbaa !23
  %t221 = load %"compiler/source:Span", ptr %l3
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2enoAliasClash(ptr %v0, ptr %t218, i64 %t219, i32 %t220, %"compiler/source:Span" %t221)
  br label %bb59
bb58:
  br label %bb86
bb59:
  %t226 = load i32, ptr %l2, !tbaa !23
  %t228 = load ptr, ptr %l8, !tbaa !29
  %t230 = getelementptr %"compiler/names:Table", ptr %t228, i32 0, i32 2
  %t234 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_Hf575c52a5a9e8993bae2b73c9c2548b3(ptr %v0, ptr %t230, i32 %t226)
  store i1 %t234, ptr %l130
  br label %bb60
bb60:
  %t235 = load i1, ptr %l130, !tbaa !21
  br i1 %t235, label %bb61, label %bb62
bb61:
  store i1 true, ptr %l131, !tbaa !21
  br label %bb64
bb62:
  %t236 = load i32, ptr %l2, !tbaa !23
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t240 = getelementptr %"compiler/names:Resolver", ptr %t238, i32 0, i32 2
  %t244 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_Hf575c52a5a9e8993bae2b73c9c2548b3(ptr %v0, ptr %t240, i32 %t236)
  store i1 %t244, ptr %l136
  br label %bb63
bb63:
  %t245 = load i1, ptr %l136, !tbaa !21
  store i1 %t245, ptr %l131, !tbaa !21
  br label %bb64
bb64:
  %t246 = load i1, ptr %l131, !tbaa !21
  br i1 %t246, label %bb65, label %bb66
bb65:
  store i1 true, ptr %l137, !tbaa !21
  br label %bb68
bb66:
  %t247 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t249 = call i1 @compiler_2fnames_2eBuiltinTypeName(ptr %v0, { i64, ptr } %t247)
  store i1 %t249, ptr %l139
  br label %bb67
bb67:
  %t250 = load i1, ptr %l139, !tbaa !21
  store i1 %t250, ptr %l137, !tbaa !21
  br label %bb68
bb68:
  %t251 = load i1, ptr %l137, !tbaa !21
  br i1 %t251, label %bb69, label %bb70
bb69:
  store %olang.scope zeroinitializer, ptr %s10
  %t252 = load ptr, ptr %l0, !tbaa !29
  %t254 = getelementptr %"compiler/names:Resolver", ptr %t252, i32 0, i32 0
  %t255 = load ptr, ptr %t254, !tbaa !29
  %t257 = getelementptr %"compiler/load:Loader", ptr %t255, i32 0, i32 4
  %t258 = load ptr, ptr %t257, !tbaa !29
  store ptr %t258, ptr %l142, !tbaa !29
  %t259 = load ptr, ptr %l0, !tbaa !29
  %t260 = load i64, ptr %l1, !tbaa !24
  %t261 = load %"compiler/source:Span", ptr %l3
  %t265 = call { i64, [3 x i64] } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eat(ptr %v0, ptr %t259, i64 %t260, %"compiler/source:Span" %t261)
  store { i64, [3 x i64] } %t265, ptr %l146
  br label %bb71
bb70:
  br label %bb75
bb71:
  %t266 = load ptr, ptr %l0, !tbaa !29
  %t267 = load i32, ptr %l2, !tbaa !23
  %t270 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etok(ptr %v0, ptr %s10, ptr %t266, i32 %t267)
  store { i64, ptr } %t270, ptr %l149
  br label %bb72
bb72:
  %t271 = load { i64, ptr }, ptr %l149, !tbaa !27
  %t273 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNameIsType(ptr %s10, ptr %v0, { i64, ptr } %t271)
  store %"compiler/diagmsg:Msg" %t273, ptr %l151
  br label %bb73
bb73:
  %t274 = load ptr, ptr %l142, !tbaa !29
  %t275 = load { i64, [3 x i64] }, ptr %l146
  %t276 = load %"compiler/diagmsg:Msg", ptr %l151
  %t277 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v0, ptr %t274, { i64, [3 x i64] } %t275, %"compiler/diagmsg:Msg" %t276)
  store i64 %t277, ptr %l152
  br label %bb74
bb74:
  call void @__olang_scope_close(ptr %s10)
  br label %bb75
bb75:
  %t278 = load ptr, ptr %l9, !tbaa !29
  %t280 = getelementptr %"compiler/load:Module", ptr %t278, i32 0, i32 3
  %t281 = load i1, ptr %t280, !tbaa !21
  %t283 = xor i1 %t281, true
  br i1 %t283, label %bb76, label %bb77
bb76:
  %t285 = load i32, ptr %l2, !tbaa !23
  %t287 = load ptr, ptr %l0, !tbaa !29
  %t289 = getelementptr %"compiler/names:Resolver", ptr %t287, i32 0, i32 3
  %t293 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_H6d33fbc050830e537410645e3c893b2c(ptr %v0, ptr %t289, i32 %t285)
  store i1 %t293, ptr %l161
  br label %bb78
bb77:
  store i1 false, ptr %l156, !tbaa !21
  br label %bb79
bb78:
  %t294 = load i1, ptr %l161, !tbaa !21
  store i1 %t294, ptr %l156, !tbaa !21
  br label %bb79
bb79:
  %t295 = load i1, ptr %l156, !tbaa !21
  br i1 %t295, label %bb80, label %bb81
bb80:
  %t296 = load ptr, ptr %l0, !tbaa !29
  %t297 = load i64, ptr %l1, !tbaa !24
  %t298 = load i32, ptr %l2, !tbaa !23
  %t299 = load %"compiler/source:Span", ptr %l3
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2epreludeTaken(ptr %v0, ptr %t296, i64 %t297, i32 %t298, %"compiler/source:Span" %t299)
  br label %bb82
bb81:
  br label %bb83
bb82:
  br label %bb83
bb83:
  %t304 = load ptr, ptr %l8, !tbaa !29
  %t306 = getelementptr %"compiler/names:Table", ptr %t304, i32 0, i32 1
  store ptr %t306, ptr %l167, !tbaa !29
  %t307 = load i32, ptr %l2, !tbaa !23
  store i32 %t307, ptr %l168, !tbaa !23
  %t308 = load ptr, ptr %l8, !tbaa !29
  %t310 = getelementptr %"compiler/names:Table", ptr %t308, i32 0, i32 0
  %t312 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eLen_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %t310)
  store i64 %t312, ptr %l171
  br label %bb84
bb84:
  %t313 = load ptr, ptr %l167, !tbaa !29
  %t314 = load i32, ptr %l168, !tbaa !23
  %t315 = load i64, ptr %l171, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H862756c16d115e5c03a79726209f69fa(ptr %v0, ptr %t313, i32 %t314, i64 %t315)
  br label %bb85
bb85:
  br label %bb86
bb86:
  %t316 = load ptr, ptr %l8, !tbaa !29
  %t318 = getelementptr %"compiler/names:Table", ptr %t316, i32 0, i32 0
  store ptr %t318, ptr %l173, !tbaa !29
  %t319 = load i32, ptr %l2, !tbaa !23
  store i32 %t319, ptr %l174, !tbaa !23
  %t320 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t320, ptr %l175
  %t321 = load i1, ptr %l5, !tbaa !21
  br i1 %t321, label %bb87, label %bb88
bb87:
  store i32 3, ptr %l177
  br label %bb89
bb88:
  store i32 2, ptr %l177
  br label %bb89
bb89:
  %t325 = load i1, ptr %l4, !tbaa !21
  %t326 = load i32, ptr %l174, !tbaa !23
  %t327 = load %"compiler/source:Span", ptr %l175
  %t328 = load i32, ptr %l177, !range !{i32 0, i32 9}
  %t330 = call %"compiler/names:Entry" @compiler_2fnames_3aEntry_2ector(ptr %v0, ptr %v0, i32 %t326, %"compiler/source:Span" %t327, i32 %t328, i1 %t325, ptr null)
  store %"compiler/names:Entry" %t330, ptr %l181
  br label %bb90
bb90:
  %t331 = load ptr, ptr %l173, !tbaa !29
  %t332 = load %"compiler/names:Entry", ptr %l181
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2ePush_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %v0, ptr %t331, %"compiler/names:Entry" %t332)
  br label %bb91
bb91:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ealiasModule(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l18 = alloca i64
  %l21 = alloca i64
  %l39 = alloca i64
  %l43 = alloca ptr
  %l46 = alloca { i64, ptr }
  %l49 = alloca i64
  %l50 = alloca i32
  %l57 = alloca ptr
  %l60 = alloca { i64, ptr }
  %l63 = alloca i64
  %l66 = alloca i1
  %l68 = alloca { i64, ptr }
  %l71 = alloca { i64, ptr }
  %l72 = alloca i1
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/names:Resolver", ptr %t1, i32 0, i32 7
  %t4 = load i64, ptr %t3, !tbaa !24
  store i64 %t4, ptr %l2, !tbaa !24
  store i64 0, ptr %l3, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  %t10 = sub i64 %t8, 1
  store i64 %t10, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t12 = load i64, ptr %l4, !tbaa !24
  %t13 = load i64, ptr %l3, !tbaa !24
  %t16 = icmp sgt i64 %t12, %t13
  br i1 %t16, label %bb1, label %bb2
bb1:
  %t18 = load i64, ptr %l5, !tbaa !24
  %t20 = icmp sgt i64 %t18, 0
  br i1 %t20, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l18, !tbaa !24
  br label %bb6
bb3:
  %t22 = load i64, ptr %l4, !tbaa !24
  %t23 = load i64, ptr %l3, !tbaa !24
  %t26 = sub i64 %t22, %t23
  %t27 = load i64, ptr %l5, !tbaa !24
  %t30 = add i64 %t26, %t27
  %t32 = sub i64 %t30, 1
  %t33 = load i64, ptr %l5, !tbaa !24
  %t36 = sdiv i64 %t32, %t33
  store i64 %t36, ptr %l21, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l21, !tbaa !24
  br label %bb5
bb5:
  %t38 = load i64, ptr %l21, !tbaa !24
  store i64 %t38, ptr %l18, !tbaa !24
  br label %bb6
bb6:
  %t39 = load i64, ptr %l18, !tbaa !24
  store i64 %t39, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb7
bb7:
  %t40 = load i64, ptr %l7, !tbaa !24
  %t41 = load i64, ptr %l6, !tbaa !24
  %t44 = icmp slt i64 %t40, %t41
  %t46 = xor i1 %t44, true
  br i1 %t46, label %bb8, label %bb9
bb8:
  br label %bb33
bb9:
  br label %bb10
bb10:
  %t48 = load i64, ptr %l3, !tbaa !24
  %t49 = load i64, ptr %l7, !tbaa !24
  %t50 = load i64, ptr %l5, !tbaa !24
  %t53 = mul i64 %t49, %t50
  %t56 = add i64 %t48, %t53
  store i64 %t56, ptr %l8, !tbaa !24
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/names:Resolver", ptr %t58, i32 0, i32 1
  %t61 = load i64, ptr %l2, !tbaa !24
  %t64 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v0, ptr %t60, i64 %t61)
  store ptr %t64, ptr %l43
  br label %bb11
bb11:
  %t65 = load ptr, ptr %l43, !tbaa !29
  %t67 = getelementptr %"compiler/names:Table", ptr %t65, i32 0, i32 3
  %t68 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t68, ptr %l46, !tbaa !27
  %t69 = load i64, ptr %l8, !tbaa !24
  %t71 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !27
  %t73 = getelementptr i32, ptr %t72, i64 %t69
  %t74 = load i32, ptr %t73, !tbaa !33
  %t77 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %t67, i32 %t74)
  %t78 = extractvalue { i32, i64 } %t77, 1
  %t79 = extractvalue { i32, i64 } %t77, 0
  store i32 %t79, ptr %l50
  %t80 = icmp ne i32 %t79, 0
  br i1 %t80, label %bb13, label %ok.81, !prof !99
ok.81:
  store i64 %t78, ptr %l49
  br label %bb12
bb12:
  %t82 = load i64, ptr %l49, !tbaa !24
  store i64 %t82, ptr %l39, !tbaa !24
  br label %bb15
bb13:
  br label %bb14
bb14:
  store i64 -1, ptr %l39, !tbaa !24
  br label %bb15
bb15:
  %t83 = load i64, ptr %l39, !tbaa !24
  store i64 %t83, ptr %l9, !tbaa !24
  %t84 = load i64, ptr %l9, !tbaa !24
  %t86 = icmp slt i64 %t84, 0
  br i1 %t86, label %bb16, label %bb17
bb16:
  store i64 -1, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  %t89 = load i64, ptr %l8, !tbaa !24
  %t91 = icmp eq i64 %t89, 0
  br i1 %t91, label %bb19, label %bb20
bb19:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/names:Resolver", ptr %t93, i32 0, i32 20
  store ptr %t95, ptr %l57, !tbaa !29
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/names:Resolver", ptr %t96, i32 0, i32 7
  %t99 = load i64, ptr %t98, !tbaa !24
  %t100 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t100, ptr %l60, !tbaa !27
  %t101 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !27
  %t103 = getelementptr i32, ptr %t102, i64 0
  %t104 = load i32, ptr %t103, !tbaa !33
  %t108 = call i64 @compiler_2fnames_2ekey(i64 %t99, i32 %t104)
  store i64 %t108, ptr %l63
  br label %bb21
bb20:
  br label %bb23
bb21:
  %t109 = load ptr, ptr %l57, !tbaa !29
  %t110 = load i64, ptr %l63, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t109, i64 %t110, i1 true)
  br label %bb22
bb22:
  br label %bb23
bb23:
  %t111 = load i64, ptr %l8, !tbaa !24
  %t113 = icmp sgt i64 %t111, 0
  br i1 %t113, label %bb24, label %bb25
bb24:
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t116 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t116, ptr %l68, !tbaa !27
  %t117 = load i64, ptr %l8, !tbaa !24
  %t119 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t120 = load ptr, ptr %t119, !tbaa !27
  %t121 = getelementptr i32, ptr %t120, i64 %t117
  %t122 = load i32, ptr %t121, !tbaa !33
  %t125 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %v0, ptr %t115, i32 %t122)
  store { i64, ptr } %t125, ptr %l71
  br label %bb26
bb25:
  store i1 false, ptr %l66, !tbaa !21
  br label %bb28
bb26:
  %t126 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t127 = call i1 @compiler_2fload_2ePublic(ptr %v0, { i64, ptr } %t126)
  store i1 %t127, ptr %l72
  br label %bb27
bb27:
  %t128 = load i1, ptr %l72, !tbaa !21
  %t129 = xor i1 %t128, true
  store i1 %t129, ptr %l66, !tbaa !21
  br label %bb28
bb28:
  %t131 = load i1, ptr %l66, !tbaa !21
  br i1 %t131, label %bb29, label %bb30
bb29:
  store i64 -1, ptr %rv
  br label %ret
bb30:
  br label %bb31
bb31:
  %t133 = load i64, ptr %l9, !tbaa !24
  store i64 %t133, ptr %l2, !tbaa !24
  br label %bb32
bb32:
  %t135 = load i64, ptr %l7, !tbaa !24
  %t138 = add i64 %t135, 1
  store i64 %t138, ptr %l7, !tbaa !24
  br label %bb7
bb33:
  %t140 = load i64, ptr %l2, !tbaa !24
  store i64 %t140, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ealiasedMember(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca %"compiler/names:Ref"
  %l17 = alloca i64
  %l21 = alloca ptr
  %l24 = alloca { i64, ptr }
  %l27 = alloca i64
  %l28 = alloca i32
  %l33 = alloca i1
  %l35 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l39 = alloca i1
  %l41 = alloca i32
  %l43 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l57 = alloca i1
  %l64 = alloca ptr
  %l67 = alloca { i64, ptr }
  %l70 = alloca i64
  %l73 = alloca { i64, ptr }
  %l76 = alloca %"compiler/names:Ref"
  %l80 = alloca i32
  %l82 = alloca { i64, ptr }
  %l85 = alloca { i64, ptr }
  %l89 = alloca ptr
  %l90 = alloca i64
  %l91 = alloca %"compiler/names:Ref"
  %l92 = alloca { i64, ptr }
  %l94 = alloca i32
  %l95 = alloca i32
  %l97 = alloca { i64, ptr }
  %l100 = alloca { i64, ptr }
  %l105 = alloca %"compiler/source:Span"
  %l107 = alloca ptr
  %l113 = alloca ptr
  %l117 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/names:Resolver", ptr %t1, i32 0, i32 7
  %t4 = load i64, ptr %t3, !tbaa !24
  store i64 %t4, ptr %l3, !tbaa !24
  store i64 0, ptr %l4, !tbaa !24
  %t6 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t7 = load i32, ptr %t6, !tbaa !23
  store i32 %t7, ptr %l5, !tbaa !23
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t9 = load i64, ptr %l4, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  %t14 = sub i64 %t12, 1
  %t17 = icmp slt i64 %t9, %t14
  %t19 = xor i1 %t17, true
  br i1 %t19, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s1)
  br label %bb23
bb3:
  br label %bb4
bb4:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/names:Resolver", ptr %t21, i32 0, i32 1
  %t24 = load i64, ptr %l3, !tbaa !24
  %t27 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v0, ptr %t23, i64 %t24)
  store ptr %t27, ptr %l21
  br label %bb5
bb5:
  %t28 = load ptr, ptr %l21, !tbaa !29
  %t30 = getelementptr %"compiler/names:Table", ptr %t28, i32 0, i32 3
  %t31 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t31, ptr %l24, !tbaa !27
  %t32 = load i64, ptr %l4, !tbaa !24
  %t34 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !27
  %t36 = getelementptr i32, ptr %t35, i64 %t32
  %t37 = load i32, ptr %t36, !tbaa !33
  %t40 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %t30, i32 %t37)
  %t41 = extractvalue { i32, i64 } %t40, 1
  %t42 = extractvalue { i32, i64 } %t40, 0
  store i32 %t42, ptr %l28
  %t43 = icmp ne i32 %t42, 0
  br i1 %t43, label %bb7, label %ok.44, !prof !99
ok.44:
  store i64 %t41, ptr %l27
  br label %bb6
bb6:
  %t45 = load i64, ptr %l27, !tbaa !24
  store i64 %t45, ptr %l17, !tbaa !24
  br label %bb9
bb7:
  br label %bb8
bb8:
  store i64 -1, ptr %l17, !tbaa !24
  br label %bb9
bb9:
  %t46 = load i64, ptr %l17, !tbaa !24
  store i64 %t46, ptr %l6, !tbaa !24
  %t47 = load i64, ptr %l6, !tbaa !24
  %t49 = icmp slt i64 %t47, 0
  br i1 %t49, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s1)
  br label %bb23
bb11:
  br label %bb12
bb12:
  %t51 = load i64, ptr %l4, !tbaa !24
  %t53 = icmp sgt i64 %t51, 0
  br i1 %t53, label %bb13, label %bb14
bb13:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t56, ptr %l35, !tbaa !27
  %t57 = load i64, ptr %l4, !tbaa !24
  %t59 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = getelementptr i32, ptr %t60, i64 %t57
  %t62 = load i32, ptr %t61, !tbaa !33
  %t65 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %v0, ptr %t55, i32 %t62)
  store { i64, ptr } %t65, ptr %l38
  br label %bb15
bb14:
  store i1 false, ptr %l33, !tbaa !21
  br label %bb17
bb15:
  %t66 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t67 = call i1 @compiler_2fload_2ePublic(ptr %v0, { i64, ptr } %t66)
  store i1 %t67, ptr %l39
  br label %bb16
bb16:
  %t68 = load i1, ptr %l39, !tbaa !21
  %t69 = xor i1 %t68, true
  store i1 %t69, ptr %l33, !tbaa !21
  br label %bb17
bb17:
  %t71 = load i1, ptr %l33, !tbaa !21
  br i1 %t71, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb19:
  br label %bb20
bb20:
  %t72 = load i32, ptr %l5, !tbaa !23
  store i32 %t72, ptr %l41, !tbaa !23
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t74 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t74, ptr %l43, !tbaa !27
  %t75 = load i64, ptr %l4, !tbaa !24
  %t77 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = getelementptr i32, ptr %t78, i64 %t75
  %t80 = load i32, ptr %t79, !tbaa !33
  %t83 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %s1, ptr %t73, i32 %t80)
  store { i64, ptr } %t83, ptr %l46
  br label %bb21
bb21:
  %t84 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t85 = extractvalue { i64, ptr } %t84, 0
  %t87 = trunc i64 %t85 to i32
  %t89 = add i32 %t87, 1
  %t90 = load i32, ptr %l41, !tbaa !23
  %t92 = add i32 %t90, %t89
  store i32 %t92, ptr %l5, !tbaa !23
  %t94 = load i64, ptr %l6, !tbaa !24
  store i64 %t94, ptr %l3, !tbaa !24
  %t96 = load i64, ptr %l4, !tbaa !24
  %t99 = add i64 %t96, 1
  store i64 %t99, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb22
bb22:
  br label %bb1
bb23:
  %t101 = load i64, ptr %l4, !tbaa !24
  %t103 = icmp eq i64 %t101, 0
  br i1 %t103, label %bb24, label %bb25
bb24:
  store i1 true, ptr %l57, !tbaa !21
  br label %bb26
bb25:
  %t105 = load i64, ptr %l4, !tbaa !24
  %t106 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t108 = extractvalue { i64, ptr } %t106, 0
  %t110 = sub i64 %t108, 1
  %t113 = icmp sge i64 %t105, %t110
  store i1 %t113, ptr %l57, !tbaa !21
  br label %bb26
bb26:
  %t115 = load i1, ptr %l57, !tbaa !21
  br i1 %t115, label %bb27, label %bb28
bb27:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb28:
  br label %bb29
bb29:
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t118 = getelementptr %"compiler/names:Resolver", ptr %t116, i32 0, i32 20
  store ptr %t118, ptr %l64, !tbaa !29
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t121 = getelementptr %"compiler/names:Resolver", ptr %t119, i32 0, i32 7
  %t122 = load i64, ptr %t121, !tbaa !24
  %t123 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t123, ptr %l67, !tbaa !27
  %t124 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !27
  %t126 = getelementptr i32, ptr %t125, i64 0
  %t127 = load i32, ptr %t126, !tbaa !33
  %t131 = call i64 @compiler_2fnames_2ekey(i64 %t122, i32 %t127)
  store i64 %t131, ptr %l70
  br label %bb30
bb30:
  %t132 = load ptr, ptr %l64, !tbaa !29
  %t133 = load i64, ptr %l70, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t132, i64 %t133, i1 true)
  br label %bb31
bb31:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t135 = load i64, ptr %l3, !tbaa !24
  %t136 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t136, ptr %l73, !tbaa !27
  %t137 = load i64, ptr %l4, !tbaa !24
  %t139 = getelementptr { i64, ptr }, ptr %l73, i32 0, i32 1
  %t140 = load ptr, ptr %t139, !tbaa !27
  %t141 = getelementptr i32, ptr %t140, i64 %t137
  %t142 = load i32, ptr %t141, !tbaa !33
  %t146 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ememberOf(ptr %v0, ptr %t134, i64 %t135, i32 %t142)
  store %"compiler/names:Ref" %t146, ptr %l76
  br label %bb32
bb32:
  %t147 = load %"compiler/names:Ref", ptr %l76
  store %"compiler/names:Ref" %t147, ptr %l7
  %t148 = getelementptr %"compiler/names:Ref", ptr %l7, i32 0, i32 0
  %t149 = load i32, ptr %t148, !range !{i32 0, i32 9}
  %t151 = trunc i64 4 to i32
  %t152 = icmp eq i32 %t149, %t151
  %t154 = xor i1 %t152, true
  br i1 %t154, label %bb33, label %bb34
bb33:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb34:
  br label %bb35
bb35:
  %t156 = load i32, ptr %l5, !tbaa !23
  store i32 %t156, ptr %l80, !tbaa !23
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t158 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t158, ptr %l82, !tbaa !27
  %t159 = load i64, ptr %l4, !tbaa !24
  %t161 = getelementptr { i64, ptr }, ptr %l82, i32 0, i32 1
  %t162 = load ptr, ptr %t161, !tbaa !27
  %t163 = getelementptr i32, ptr %t162, i64 %t159
  %t164 = load i32, ptr %t163, !tbaa !33
  %t167 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %s0, ptr %t157, i32 %t164)
  store { i64, ptr } %t167, ptr %l85
  br label %bb36
bb36:
  %t168 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t169 = extractvalue { i64, ptr } %t168, 0
  %t171 = trunc i64 %t169 to i32
  %t172 = load i32, ptr %l80, !tbaa !23
  %t174 = add i32 %t172, %t171
  store i32 %t174, ptr %l5, !tbaa !23
  %t176 = load ptr, ptr %l0, !tbaa !29
  store ptr %t176, ptr %l89, !tbaa !29
  %t177 = load i64, ptr %l3, !tbaa !24
  store i64 %t177, ptr %l90, !tbaa !24
  %t178 = load %"compiler/names:Ref", ptr %l7
  store %"compiler/names:Ref" %t178, ptr %l91
  %t179 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t179, ptr %l92, !tbaa !27
  %t180 = load i64, ptr %l4, !tbaa !24
  %t182 = getelementptr { i64, ptr }, ptr %l92, i32 0, i32 1
  %t183 = load ptr, ptr %t182, !tbaa !27
  %t184 = getelementptr i32, ptr %t183, i64 %t180
  %t185 = load i32, ptr %t184, !tbaa !33
  store i32 %t185, ptr %l94, !tbaa !23
  %t186 = load i32, ptr %l5, !tbaa !23
  store i32 %t186, ptr %l95, !tbaa !23
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t188 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t188, ptr %l97, !tbaa !27
  %t189 = load i64, ptr %l4, !tbaa !24
  %t191 = getelementptr { i64, ptr }, ptr %l97, i32 0, i32 1
  %t192 = load ptr, ptr %t191, !tbaa !27
  %t193 = getelementptr i32, ptr %t192, i64 %t189
  %t194 = load i32, ptr %t193, !tbaa !33
  %t197 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %s0, ptr %t187, i32 %t194)
  store { i64, ptr } %t197, ptr %l100
  br label %bb37
bb37:
  %t198 = load { i64, ptr }, ptr %l100, !tbaa !27
  %t199 = extractvalue { i64, ptr } %t198, 0
  %t201 = trunc i64 %t199 to i32
  %t202 = load i32, ptr %l95, !tbaa !23
  %t204 = sub i32 %t202, %t201
  %t205 = load i32, ptr %l5, !tbaa !23
  %t208 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %t204, i32 %t205)
  store %"compiler/source:Span" %t208, ptr %l105
  br label %bb38
bb38:
  %t209 = load ptr, ptr %l89, !tbaa !29
  %t210 = load i64, ptr %l90, !tbaa !24
  %t211 = load %"compiler/names:Ref", ptr %l91
  %t212 = load i32, ptr %l94, !tbaa !23
  %t213 = load %"compiler/source:Span", ptr %l105
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2enotPrivate(ptr %v0, ptr %t209, i64 %t210, %"compiler/names:Ref" %t211, i32 %t212, %"compiler/source:Span" %t213)
  br label %bb39
bb39:
  %t214 = load ptr, ptr %l0, !tbaa !29
  %t216 = getelementptr %"compiler/names:Resolver", ptr %t214, i32 0, i32 5
  store ptr %t216, ptr %l107, !tbaa !29
  %t217 = load ptr, ptr %l0, !tbaa !29
  %t219 = getelementptr %"compiler/names:Resolver", ptr %t217, i32 0, i32 0
  %t220 = load ptr, ptr %t219, !tbaa !29
  %t222 = getelementptr %"compiler/load:Loader", ptr %t220, i32 0, i32 10
  %t223 = load ptr, ptr %l0, !tbaa !29
  %t225 = getelementptr %"compiler/names:Resolver", ptr %t223, i32 0, i32 7
  %t226 = load i64, ptr %t225, !tbaa !24
  %t229 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t222, i64 %t226)
  store ptr %t229, ptr %l113
  br label %bb40
bb40:
  %t230 = load ptr, ptr %l113, !tbaa !29
  %t232 = getelementptr %"compiler/load:Module", ptr %t230, i32 0, i32 4
  %t233 = load i64, ptr %t232, !tbaa !24
  %t234 = load i32, ptr %l5, !tbaa !23
  %t237 = call i64 @compiler_2fnames_2ekey(i64 %t233, i32 %t234)
  store i64 %t237, ptr %l117
  br label %bb41
bb41:
  %t238 = load %"compiler/names:Ref", ptr %l7
  %t239 = load ptr, ptr %l107, !tbaa !29
  %t240 = load i64, ptr %l117, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fnames_3aRef_3e_2eP_Hb17c37756f956998a4fa74bcac088344(ptr %v0, ptr %t239, i64 %t240, %"compiler/names:Ref" %t238)
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ealiasesOf(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca %"compiler/load:Import"
  %l9 = alloca ptr
  %l14 = alloca ptr
  %l17 = alloca i64
  %l19 = alloca i64
  %l24 = alloca %"compiler/load:Import"
  %l28 = alloca ptr
  %l33 = alloca i32
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/names:Resolver", ptr %t1, i32 0, i32 1
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  store ptr %t7, ptr %l9
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l9, !tbaa !29
  store ptr %t8, ptr %l2, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/names:Resolver", ptr %t9, i32 0, i32 0
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = getelementptr %"compiler/load:Loader", ptr %t12, i32 0, i32 10
  %t15 = load i64, ptr %l1, !tbaa !24
  %t18 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t14, i64 %t15)
  store ptr %t18, ptr %l14
  br label %bb2
bb2:
  %t19 = load ptr, ptr %l14, !tbaa !29
  %t21 = getelementptr %"compiler/load:Module", ptr %t19, i32 0, i32 11
  store ptr %t21, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb3
bb3:
  %t23 = load i64, ptr %l4, !tbaa !24
  store i64 %t23, ptr %l17, !tbaa !24
  %t24 = load ptr, ptr %l3, !tbaa !29
  %t26 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fload_3aImport_3e_2eLen_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %t24)
  store i64 %t26, ptr %l19
  br label %bb4
bb4:
  %t27 = load i64, ptr %l17, !tbaa !24
  %t28 = load i64, ptr %l19, !tbaa !24
  %t29 = icmp slt i64 %t27, %t28
  %t31 = xor i1 %t29, true
  br i1 %t31, label %bb5, label %bb6
bb5:
  br label %bb15
bb6:
  br label %bb7
bb7:
  %t33 = load ptr, ptr %l3, !tbaa !29
  %t34 = load i64, ptr %l4, !tbaa !24
  %t37 = call %"compiler/load:Import" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fload_3aImport_3e_2eAt_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %v0, ptr %t33, i64 %t34)
  store %"compiler/load:Import" %t37, ptr %l24
  br label %bb8
bb8:
  %t38 = load %"compiler/load:Import", ptr %l24
  store %"compiler/load:Import" %t38, ptr %l5
  %t39 = getelementptr %"compiler/load:Import", ptr %l5, i32 0, i32 5
  %t40 = load i64, ptr %t39, !tbaa !24
  %t42 = icmp sge i64 %t40, 0
  br i1 %t42, label %bb9, label %bb10
bb9:
  %t44 = load ptr, ptr %l2, !tbaa !29
  %t46 = getelementptr %"compiler/names:Table", ptr %t44, i32 0, i32 3
  store ptr %t46, ptr %l28, !tbaa !29
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/names:Resolver", ptr %t47, i32 0, i32 0
  %t50 = load ptr, ptr %t49, !tbaa !29
  %t52 = getelementptr %"compiler/load:Loader", ptr %t50, i32 0, i32 3
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t54 = getelementptr %"compiler/load:Import", ptr %l5, i32 0, i32 2
  %t55 = load { i64, ptr }, ptr %t54, !tbaa !27
  %t58 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v0, ptr %t53, { i64, ptr } %t55)
  store i32 %t58, ptr %l33
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t59 = getelementptr %"compiler/load:Import", ptr %l5, i32 0, i32 5
  %t60 = load i64, ptr %t59, !tbaa !24
  %t61 = load ptr, ptr %l28, !tbaa !29
  %t62 = load i32, ptr %l33, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H862756c16d115e5c03a79726209f69fa(ptr %v0, ptr %t61, i32 %t62, i64 %t60)
  br label %bb12
bb12:
  br label %bb13
bb13:
  br label %bb14
bb14:
  %t64 = load i64, ptr %l4, !tbaa !24
  %t67 = add i64 %t64, 1
  store i64 %t67, ptr %l4, !tbaa !24
  br label %bb3
bb15:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ebodies(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca i64
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca i64
  %l33 = alloca { i64, ptr }
  %l34 = alloca i64
  %l35 = alloca i64
  %l37 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l48 = alloca ptr
  %l49 = alloca i1
  %l55 = alloca ptr
  %l56 = alloca i64
  %l62 = alloca %"compiler/source:Span"
  %l64 = alloca i64
  %l79 = alloca ptr
  %l80 = alloca i1
  %l89 = alloca ptr
  %l90 = alloca i1
  %l99 = alloca ptr
  %l100 = alloca i1
  %l117 = alloca ptr
  %l118 = alloca i1
  %l140 = alloca ptr
  %l141 = alloca i1
  %l164 = alloca { i64, ptr }
  %l173 = alloca ptr
  %l174 = alloca i1
  %l189 = alloca ptr
  %l190 = alloca i1
  %l204 = alloca ptr
  %l205 = alloca i1
  %l214 = alloca ptr
  %l215 = alloca i1
  %l231 = alloca { i64, ptr }
  %l247 = alloca { i64, ptr }
  %l258 = alloca { i64, ptr }
  %l270 = alloca ptr
  %l271 = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a2, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l5, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l4, !tbaa !24
  %t8 = load i64, ptr %l5, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb146
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t15, ptr %l45, !tbaa !27
  %t16 = load i64, ptr %l4, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  store ptr %t21, ptr %l6, !tbaa !29
  %t23 = load ptr, ptr %l6, !tbaa !29
  store ptr %t23, ptr %l48, !tbaa !29
  store i1 false, ptr %l49, !tbaa !21
  %t24 = load ptr, ptr %l48, !tbaa !29
  %t25 = icmp ne ptr %t24, null
  br i1 %t25, label %bb5, label %bb6
bb5:
  %t27 = load ptr, ptr %l48, !tbaa !29
  %t28 = load i64, ptr %t27, !range !{i64 0, i64 12}
  %t30 = icmp eq i64 %t28, 8
  store i1 %t30, ptr %l49, !tbaa !21
  br label %bb6
bb6:
  %t31 = load i1, ptr %l49, !tbaa !21
  br i1 %t31, label %bb7, label %bb8
bb7:
  %t32 = load ptr, ptr %l6, !tbaa !29
  %t34 = getelementptr { i64, [8 x i64] }, ptr %t32, i32 0, i32 1
  %t35 = getelementptr { %"compiler/source:Span", ptr }, ptr %t34, i32 0, i32 1
  %t36 = load ptr, ptr %t35
  store ptr %t36, ptr %l7, !tbaa !29
  br label %bb9
bb8:
  br label %bb22
bb9:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/names:Resolver", ptr %t38, i32 0, i32 0
  %t41 = load ptr, ptr %t40, !tbaa !29
  store ptr %t41, ptr %l55, !tbaa !29
  %t42 = load i64, ptr %l1, !tbaa !24
  store i64 %t42, ptr %l56, !tbaa !24
  %t43 = load ptr, ptr %l7, !tbaa !29
  %t45 = getelementptr %"compiler/ast:TopIf", ptr %t43, i32 0, i32 0
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t48 = icmp eq ptr %t46, null
  br i1 %t48, label %bb10, label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_3c4b516dc7f3c61f_40ef246315a2e453)
  unreachable
bb11:
  br label %bb12
bb12:
  %t50 = load ptr, ptr %l7, !tbaa !29
  %t52 = getelementptr %"compiler/ast:TopIf", ptr %t50, i32 0, i32 0
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t55 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t53)
  store %"compiler/source:Span" %t55, ptr %l62
  br label %bb13
bb13:
  %t56 = getelementptr %"compiler/source:Span", ptr %l62, i32 0, i32 0
  %t57 = load i32, ptr %t56, !tbaa !23
  %t58 = load ptr, ptr %l55, !tbaa !29
  %t59 = load i64, ptr %l56, !tbaa !24
  %t61 = call i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2eChosen(ptr %v0, ptr %t58, i64 %t59, i32 %t57)
  store i64 %t61, ptr %l64
  br label %bb14
bb14:
  %t62 = load i64, ptr %l64, !tbaa !24
  store i64 %t62, ptr %l8, !tbaa !24
  %t63 = load i64, ptr %l8, !tbaa !24
  %t64 = load i64, ptr @G_2ecompiler_2fload_2ePending, !tbaa !24
  %t67 = icmp eq i64 %t63, %t64
  br i1 %t67, label %bb15, label %bb16
bb15:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/names:Resolver", ptr %t69, i32 0, i32 22
  %t72 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t71, i64 %t72, i1 true)
  br label %bb17
bb16:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load i64, ptr %l1, !tbaa !24
  %t77 = load ptr, ptr %l7, !tbaa !29
  %t78 = load i64, ptr %l8, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ebodiesIf(ptr %v0, ptr %v1, ptr %t75, i64 %t76, ptr %t77, i64 %t78, i64 0)
  br label %bb20
bb17:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2estartItem(ptr %v0, ptr %t83, i64 %t84)
  br label %bb18
bb18:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t88 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etopConds(ptr %v0, ptr %v1, ptr %t87, ptr %t88)
  br label %bb19
bb19:
  br label %bb21
bb20:
  br label %bb21
bb21:
  br label %bb144
bb22:
  %t91 = load ptr, ptr %l6, !tbaa !29
  store ptr %t91, ptr %l79, !tbaa !29
  store i1 false, ptr %l80, !tbaa !21
  %t92 = load ptr, ptr %l79, !tbaa !29
  %t93 = icmp ne ptr %t92, null
  br i1 %t93, label %bb23, label %bb24
bb23:
  %t95 = load ptr, ptr %l79, !tbaa !29
  %t96 = load i64, ptr %t95, !range !{i64 0, i64 12}
  %t98 = icmp eq i64 %t96, 0
  store i1 %t98, ptr %l80, !tbaa !21
  br label %bb24
bb24:
  %t99 = load i1, ptr %l80, !tbaa !21
  br i1 %t99, label %bb25, label %bb26
bb25:
  %t100 = load ptr, ptr %l6, !tbaa !29
  %t102 = getelementptr { i64, [8 x i64] }, ptr %t100, i32 0, i32 1
  %t103 = getelementptr { ptr }, ptr %t102, i32 0, i32 0
  %t104 = load ptr, ptr %t103
  store ptr %t104, ptr %l9, !tbaa !29
  br label %bb27
bb26:
  br label %bb30
bb27:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t107 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2estartItem(ptr %v0, ptr %t106, i64 %t107)
  br label %bb28
bb28:
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t111 = load ptr, ptr %l9, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2efunc(ptr %v0, ptr %v1, ptr %t110, ptr %t111)
  br label %bb29
bb29:
  br label %bb144
bb30:
  %t114 = load ptr, ptr %l6, !tbaa !29
  store ptr %t114, ptr %l89, !tbaa !29
  store i1 false, ptr %l90, !tbaa !21
  %t115 = load ptr, ptr %l89, !tbaa !29
  %t116 = icmp ne ptr %t115, null
  br i1 %t116, label %bb31, label %bb32
bb31:
  %t118 = load ptr, ptr %l89, !tbaa !29
  %t119 = load i64, ptr %t118, !range !{i64 0, i64 12}
  %t121 = icmp eq i64 %t119, 1
  store i1 %t121, ptr %l90, !tbaa !21
  br label %bb32
bb32:
  %t122 = load i1, ptr %l90, !tbaa !21
  br i1 %t122, label %bb33, label %bb34
bb33:
  %t123 = load ptr, ptr %l6, !tbaa !29
  %t125 = getelementptr { i64, [8 x i64] }, ptr %t123, i32 0, i32 1
  %t126 = getelementptr { ptr }, ptr %t125, i32 0, i32 0
  %t127 = load ptr, ptr %t126
  store ptr %t127, ptr %l10, !tbaa !29
  br label %bb35
bb34:
  br label %bb38
bb35:
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t130 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2estartItem(ptr %v0, ptr %t129, i64 %t130)
  br label %bb36
bb36:
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t134 = load ptr, ptr %l10, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2esig(ptr %v0, ptr %v1, ptr %t133, ptr %t134, i1 false)
  br label %bb37
bb37:
  br label %bb144
bb38:
  %t137 = load ptr, ptr %l6, !tbaa !29
  store ptr %t137, ptr %l99, !tbaa !29
  store i1 false, ptr %l100, !tbaa !21
  %t138 = load ptr, ptr %l99, !tbaa !29
  %t139 = icmp ne ptr %t138, null
  br i1 %t139, label %bb39, label %bb40
bb39:
  %t141 = load ptr, ptr %l99, !tbaa !29
  %t142 = load i64, ptr %t141, !range !{i64 0, i64 12}
  %t144 = icmp eq i64 %t142, 2
  store i1 %t144, ptr %l100, !tbaa !21
  br label %bb40
bb40:
  %t145 = load i1, ptr %l100, !tbaa !21
  br i1 %t145, label %bb41, label %bb42
bb41:
  %t146 = load ptr, ptr %l6, !tbaa !29
  %t148 = getelementptr { i64, [8 x i64] }, ptr %t146, i32 0, i32 1
  %t149 = getelementptr { %"compiler/source:Span", ptr }, ptr %t148, i32 0, i32 1
  %t150 = load ptr, ptr %t149
  store ptr %t150, ptr %l11, !tbaa !29
  br label %bb43
bb42:
  br label %bb50
bb43:
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t153 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2estartItem(ptr %v0, ptr %t152, i64 %t153)
  br label %bb44
bb44:
  %t156 = load ptr, ptr %l11, !tbaa !29
  %t158 = getelementptr %"compiler/ast:TypeDecl", ptr %t156, i32 0, i32 6
  %t159 = load ptr, ptr %t158, !tbaa !29
  %t161 = icmp eq ptr %t159, null
  %t163 = xor i1 %t161, true
  br i1 %t163, label %bb45, label %bb46
bb45:
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t166 = load ptr, ptr %l11, !tbaa !29
  %t168 = getelementptr %"compiler/ast:TypeDecl", ptr %t166, i32 0, i32 6
  %t169 = load ptr, ptr %t168, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeRef(ptr %v0, ptr %v1, ptr %t165, ptr %t169)
  br label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb48
bb48:
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t174 = load ptr, ptr %l11, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeDecl(ptr %v0, ptr %v1, ptr %t173, ptr %t174)
  br label %bb49
bb49:
  br label %bb144
bb50:
  %t177 = load ptr, ptr %l6, !tbaa !29
  store ptr %t177, ptr %l117, !tbaa !29
  store i1 false, ptr %l118, !tbaa !21
  %t178 = load ptr, ptr %l117, !tbaa !29
  %t179 = icmp ne ptr %t178, null
  br i1 %t179, label %bb51, label %bb52
bb51:
  %t181 = load ptr, ptr %l117, !tbaa !29
  %t182 = load i64, ptr %t181, !range !{i64 0, i64 12}
  %t184 = icmp eq i64 %t182, 3
  store i1 %t184, ptr %l118, !tbaa !21
  br label %bb52
bb52:
  %t185 = load i1, ptr %l118, !tbaa !21
  br i1 %t185, label %bb53, label %bb54
bb53:
  %t186 = load ptr, ptr %l6, !tbaa !29
  %t188 = getelementptr { i64, [8 x i64] }, ptr %t186, i32 0, i32 1
  %t189 = getelementptr { %"compiler/source:Span", ptr }, ptr %t188, i32 0, i32 1
  %t190 = load ptr, ptr %t189
  store ptr %t190, ptr %l12, !tbaa !29
  br label %bb55
bb54:
  br label %bb61
bb55:
  %t192 = load ptr, ptr %l0, !tbaa !29
  %t193 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2estartItem(ptr %v0, ptr %t192, i64 %t193)
  br label %bb56
bb56:
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t197 = load ptr, ptr %l12, !tbaa !29
  %t199 = getelementptr %"compiler/ast:MemberDecl", ptr %t197, i32 0, i32 2
  %t200 = load { i64, ptr }, ptr %t199, !tbaa !27
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeParams(ptr %v0, ptr %v1, ptr %t196, { i64, ptr } %t200)
  br label %bb57
bb57:
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t204 = load ptr, ptr %l12, !tbaa !29
  %t206 = getelementptr %"compiler/ast:MemberDecl", ptr %t204, i32 0, i32 0
  %t207 = load ptr, ptr %t206, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ereceiverVars(ptr %v0, ptr %v1, ptr %t203, ptr %t207, i1 false)
  br label %bb58
bb58:
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t212 = load ptr, ptr %l12, !tbaa !29
  %t214 = getelementptr %"compiler/ast:MemberDecl", ptr %t212, i32 0, i32 0
  %t215 = load ptr, ptr %t214, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeRef(ptr %v0, ptr %v1, ptr %t211, ptr %t215)
  br label %bb59
bb59:
  %t219 = load ptr, ptr %l0, !tbaa !29
  %t220 = load ptr, ptr %l12, !tbaa !29
  %t222 = getelementptr %"compiler/ast:MemberDecl", ptr %t220, i32 0, i32 3
  %t223 = load ptr, ptr %t222, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeRef(ptr %v0, ptr %v1, ptr %t219, ptr %t223)
  br label %bb60
bb60:
  br label %bb144
bb61:
  %t227 = load ptr, ptr %l6, !tbaa !29
  store ptr %t227, ptr %l140, !tbaa !29
  store i1 false, ptr %l141, !tbaa !21
  %t228 = load ptr, ptr %l140, !tbaa !29
  %t229 = icmp ne ptr %t228, null
  br i1 %t229, label %bb62, label %bb63
bb62:
  %t231 = load ptr, ptr %l140, !tbaa !29
  %t232 = load i64, ptr %t231, !range !{i64 0, i64 12}
  %t234 = icmp eq i64 %t232, 4
  store i1 %t234, ptr %l141, !tbaa !21
  br label %bb63
bb63:
  %t235 = load i1, ptr %l141, !tbaa !21
  br i1 %t235, label %bb64, label %bb65
bb64:
  %t236 = load ptr, ptr %l6, !tbaa !29
  %t238 = getelementptr { i64, [8 x i64] }, ptr %t236, i32 0, i32 1
  %t239 = getelementptr { %"compiler/source:Span", ptr }, ptr %t238, i32 0, i32 1
  %t240 = load ptr, ptr %t239
  store ptr %t240, ptr %l13, !tbaa !29
  br label %bb66
bb65:
  br label %bb79
bb66:
  %t242 = load ptr, ptr %l0, !tbaa !29
  %t243 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2estartItem(ptr %v0, ptr %t242, i64 %t243)
  br label %bb67
bb67:
  %t246 = load ptr, ptr %l13, !tbaa !29
  %t248 = getelementptr %"compiler/ast:VarDecl", ptr %t246, i32 0, i32 2
  %t249 = load ptr, ptr %t248, !tbaa !29
  %t251 = icmp eq ptr %t249, null
  %t253 = xor i1 %t251, true
  br i1 %t253, label %bb68, label %bb69
bb68:
  %t255 = load ptr, ptr %l0, !tbaa !29
  %t256 = load ptr, ptr %l13, !tbaa !29
  %t258 = getelementptr %"compiler/ast:VarDecl", ptr %t256, i32 0, i32 2
  %t259 = load ptr, ptr %t258, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeRef(ptr %v0, ptr %v1, ptr %t255, ptr %t259)
  br label %bb70
bb69:
  br label %bb71
bb70:
  br label %bb71
bb71:
  %t263 = load ptr, ptr %l13, !tbaa !29
  %t265 = getelementptr %"compiler/ast:VarDecl", ptr %t263, i32 0, i32 3
  %t266 = load { i64, ptr }, ptr %t265, !tbaa !27
  store { i64, ptr } %t266, ptr %l14, !tbaa !27
  store i64 0, ptr %l15, !tbaa !24
  %t268 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t270 = extractvalue { i64, ptr } %t268, 0
  store i64 %t270, ptr %l16, !tbaa !24
  br label %bb72
bb72:
  %t272 = load i64, ptr %l15, !tbaa !24
  %t273 = load i64, ptr %l16, !tbaa !24
  %t276 = icmp slt i64 %t272, %t273
  %t278 = xor i1 %t276, true
  br i1 %t278, label %bb73, label %bb74
bb73:
  br label %bb78
bb74:
  br label %bb75
bb75:
  %t280 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t280, ptr %l164, !tbaa !27
  %t281 = load i64, ptr %l15, !tbaa !24
  %t283 = getelementptr { i64, ptr }, ptr %l164, i32 0, i32 1
  %t284 = load ptr, ptr %t283, !tbaa !27
  %t285 = getelementptr ptr, ptr %t284, i64 %t281
  %t286 = load ptr, ptr %t285, !tbaa !39
  %t288 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t288, ptr %t286)
  br label %bb76
bb76:
  br label %bb77
bb77:
  %t293 = load i64, ptr %l15, !tbaa !24
  %t296 = add i64 %t293, 1
  store i64 %t296, ptr %l15, !tbaa !24
  br label %bb72
bb78:
  br label %bb144
bb79:
  %t298 = load ptr, ptr %l6, !tbaa !29
  store ptr %t298, ptr %l173, !tbaa !29
  store i1 false, ptr %l174, !tbaa !21
  %t299 = load ptr, ptr %l173, !tbaa !29
  %t300 = icmp ne ptr %t299, null
  br i1 %t300, label %bb80, label %bb81
bb80:
  %t302 = load ptr, ptr %l173, !tbaa !29
  %t303 = load i64, ptr %t302, !range !{i64 0, i64 12}
  %t305 = icmp eq i64 %t303, 9
  store i1 %t305, ptr %l174, !tbaa !21
  br label %bb81
bb81:
  %t306 = load i1, ptr %l174, !tbaa !21
  br i1 %t306, label %bb82, label %bb83
bb82:
  %t307 = load ptr, ptr %l6, !tbaa !29
  %t309 = getelementptr { i64, [8 x i64] }, ptr %t307, i32 0, i32 1
  %t310 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t309, i32 0, i32 1
  %t311 = load ptr, ptr %t310
  store ptr %t311, ptr %l18, !tbaa !29
  %t313 = load ptr, ptr %l6, !tbaa !29
  %t315 = getelementptr { i64, [8 x i64] }, ptr %t313, i32 0, i32 1
  %t316 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t315, i32 0, i32 2
  %t317 = load ptr, ptr %t316
  store ptr %t317, ptr %l19, !tbaa !29
  br label %bb84
bb83:
  br label %bb88
bb84:
  %t319 = load ptr, ptr %l0, !tbaa !29
  %t320 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2estartItem(ptr %v0, ptr %t319, i64 %t320)
  br label %bb85
bb85:
  %t323 = load ptr, ptr %l0, !tbaa !29
  %t324 = load ptr, ptr %l18, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t323, ptr %t324)
  br label %bb86
bb86:
  %t328 = load ptr, ptr %l0, !tbaa !29
  %t329 = load ptr, ptr %l19, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t328, ptr %t329)
  br label %bb87
bb87:
  br label %bb144
bb88:
  %t333 = load ptr, ptr %l6, !tbaa !29
  store ptr %t333, ptr %l189, !tbaa !29
  store i1 false, ptr %l190, !tbaa !21
  %t334 = load ptr, ptr %l189, !tbaa !29
  %t335 = icmp ne ptr %t334, null
  br i1 %t335, label %bb89, label %bb90
bb89:
  %t337 = load ptr, ptr %l189, !tbaa !29
  %t338 = load i64, ptr %t337, !range !{i64 0, i64 12}
  %t340 = icmp eq i64 %t338, 10
  store i1 %t340, ptr %l190, !tbaa !21
  br label %bb90
bb90:
  %t341 = load i1, ptr %l190, !tbaa !21
  br i1 %t341, label %bb91, label %bb92
bb91:
  %t342 = load ptr, ptr %l6, !tbaa !29
  %t344 = getelementptr { i64, [8 x i64] }, ptr %t342, i32 0, i32 1
  %t345 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t344, i32 0, i32 1
  %t346 = load ptr, ptr %t345
  store ptr %t346, ptr %l20, !tbaa !29
  %t348 = load ptr, ptr %l6, !tbaa !29
  %t350 = getelementptr { i64, [8 x i64] }, ptr %t348, i32 0, i32 1
  %t351 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t350, i32 0, i32 2
  %t352 = load ptr, ptr %t351
  store ptr %t352, ptr %l21, !tbaa !29
  br label %bb93
bb92:
  br label %bb97
bb93:
  %t354 = load ptr, ptr %l0, !tbaa !29
  %t355 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2estartItem(ptr %v0, ptr %t354, i64 %t355)
  br label %bb94
bb94:
  %t358 = load ptr, ptr %l0, !tbaa !29
  %t359 = load ptr, ptr %l20, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t358, ptr %t359)
  br label %bb95
bb95:
  %t363 = load ptr, ptr %l0, !tbaa !29
  %t364 = load ptr, ptr %l21, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t363, ptr %t364)
  br label %bb96
bb96:
  br label %bb144
bb97:
  %t367 = load ptr, ptr %l6, !tbaa !29
  store ptr %t367, ptr %l204, !tbaa !29
  store i1 false, ptr %l205, !tbaa !21
  %t368 = load ptr, ptr %l204, !tbaa !29
  %t369 = icmp ne ptr %t368, null
  br i1 %t369, label %bb98, label %bb99
bb98:
  %t371 = load ptr, ptr %l204, !tbaa !29
  %t372 = load i64, ptr %t371, !range !{i64 0, i64 12}
  %t374 = icmp eq i64 %t372, 7
  store i1 %t374, ptr %l205, !tbaa !21
  br label %bb99
bb99:
  %t375 = load i1, ptr %l205, !tbaa !21
  br i1 %t375, label %bb100, label %bb101
bb100:
  %t376 = load ptr, ptr %l6, !tbaa !29
  %t378 = getelementptr { i64, [8 x i64] }, ptr %t376, i32 0, i32 1
  %t379 = getelementptr { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t378, i32 0, i32 2
  %t380 = load { i64, ptr }, ptr %t379
  store { i64, ptr } %t380, ptr %l22, !tbaa !27
  br label %bb102
bb101:
  br label %bb105
bb102:
  %t382 = load ptr, ptr %l0, !tbaa !29
  %t383 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2estartItem(ptr %v0, ptr %t382, i64 %t383)
  br label %bb103
bb103:
  %t386 = load ptr, ptr %l0, !tbaa !29
  %t387 = load { i64, ptr }, ptr %l22, !tbaa !27
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eblock(ptr %v0, ptr %v1, ptr %t386, { i64, ptr } %t387)
  br label %bb104
bb104:
  br label %bb144
bb105:
  %t390 = load ptr, ptr %l6, !tbaa !29
  store ptr %t390, ptr %l214, !tbaa !29
  store i1 false, ptr %l215, !tbaa !21
  %t391 = load ptr, ptr %l214, !tbaa !29
  %t392 = icmp ne ptr %t391, null
  br i1 %t392, label %bb106, label %bb107
bb106:
  %t394 = load ptr, ptr %l214, !tbaa !29
  %t395 = load i64, ptr %t394, !range !{i64 0, i64 12}
  %t397 = icmp eq i64 %t395, 6
  store i1 %t397, ptr %l215, !tbaa !21
  br label %bb107
bb107:
  %t398 = load i1, ptr %l215, !tbaa !21
  br i1 %t398, label %bb108, label %bb109
bb108:
  %t399 = load ptr, ptr %l6, !tbaa !29
  %t401 = getelementptr { i64, [8 x i64] }, ptr %t399, i32 0, i32 1
  %t402 = getelementptr { %"compiler/source:Span", i32, { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t401, i32 0, i32 3
  %t403 = load { i64, ptr }, ptr %t402
  store { i64, ptr } %t403, ptr %l23, !tbaa !27
  %t405 = load ptr, ptr %l6, !tbaa !29
  %t407 = getelementptr { i64, [8 x i64] }, ptr %t405, i32 0, i32 1
  %t408 = getelementptr { %"compiler/source:Span", i32, { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t407, i32 0, i32 4
  %t409 = load { i64, ptr }, ptr %t408
  store { i64, ptr } %t409, ptr %l24, !tbaa !27
  br label %bb110
bb109:
  br label %bb132
bb110:
  %t411 = load ptr, ptr %l0, !tbaa !29
  %t412 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2estartItem(ptr %v0, ptr %t411, i64 %t412)
  br label %bb111
bb111:
  %t415 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t415, ptr %l25, !tbaa !27
  store i64 0, ptr %l26, !tbaa !24
  %t417 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t419 = extractvalue { i64, ptr } %t417, 0
  store i64 %t419, ptr %l27, !tbaa !24
  br label %bb112
bb112:
  %t421 = load i64, ptr %l26, !tbaa !24
  %t422 = load i64, ptr %l27, !tbaa !24
  %t425 = icmp slt i64 %t421, %t422
  %t427 = xor i1 %t425, true
  br i1 %t427, label %bb113, label %bb114
bb113:
  br label %bb118
bb114:
  br label %bb115
bb115:
  %t429 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t429, ptr %l231, !tbaa !27
  %t430 = load i64, ptr %l26, !tbaa !24
  %t432 = getelementptr { i64, ptr }, ptr %l231, i32 0, i32 1
  %t433 = load ptr, ptr %t432, !tbaa !27
  %t434 = getelementptr ptr, ptr %t433, i64 %t430
  %t435 = load ptr, ptr %t434, !tbaa !39
  %t437 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2epath(ptr %v0, ptr %v1, ptr %t437, ptr %t435)
  br label %bb116
bb116:
  br label %bb117
bb117:
  %t442 = load i64, ptr %l26, !tbaa !24
  %t445 = add i64 %t442, 1
  store i64 %t445, ptr %l26, !tbaa !24
  br label %bb112
bb118:
  %t447 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t447, ptr %l29, !tbaa !27
  store i64 0, ptr %l30, !tbaa !24
  %t449 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t451 = extractvalue { i64, ptr } %t449, 0
  store i64 %t451, ptr %l31, !tbaa !24
  br label %bb119
bb119:
  %t453 = load i64, ptr %l30, !tbaa !24
  %t454 = load i64, ptr %l31, !tbaa !24
  %t457 = icmp slt i64 %t453, %t454
  %t459 = xor i1 %t457, true
  br i1 %t459, label %bb120, label %bb121
bb120:
  br label %bb131
bb121:
  br label %bb122
bb122:
  %t461 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t461, ptr %l247, !tbaa !27
  %t462 = load i64, ptr %l30, !tbaa !24
  %t464 = getelementptr { i64, ptr }, ptr %l247, i32 0, i32 1
  %t465 = load ptr, ptr %t464, !tbaa !27
  %t466 = getelementptr ptr, ptr %t465, i64 %t462
  %t467 = load ptr, ptr %t466, !tbaa !39
  %t471 = getelementptr %"compiler/ast:CaseDecl", ptr %t467, i32 0, i32 2
  %t472 = load { i64, ptr }, ptr %t471, !tbaa !27
  store { i64, ptr } %t472, ptr %l33, !tbaa !27
  store i64 0, ptr %l34, !tbaa !24
  %t474 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t476 = extractvalue { i64, ptr } %t474, 0
  store i64 %t476, ptr %l35, !tbaa !24
  br label %bb123
bb123:
  %t478 = load i64, ptr %l34, !tbaa !24
  %t479 = load i64, ptr %l35, !tbaa !24
  %t482 = icmp slt i64 %t478, %t479
  %t484 = xor i1 %t482, true
  br i1 %t484, label %bb124, label %bb125
bb124:
  br label %bb129
bb125:
  br label %bb126
bb126:
  %t486 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t486, ptr %l258, !tbaa !27
  %t487 = load i64, ptr %l34, !tbaa !24
  %t489 = getelementptr { i64, ptr }, ptr %l258, i32 0, i32 1
  %t490 = load ptr, ptr %t489, !tbaa !27
  %t491 = getelementptr ptr, ptr %t490, i64 %t487
  %t492 = load ptr, ptr %t491, !tbaa !39
  %t494 = load ptr, ptr %l0, !tbaa !29
  %t497 = getelementptr %"compiler/ast:Param", ptr %t492, i32 0, i32 2
  %t498 = load ptr, ptr %t497, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeRef(ptr %v0, ptr %v1, ptr %t494, ptr %t498)
  br label %bb127
bb127:
  br label %bb128
bb128:
  %t501 = load i64, ptr %l34, !tbaa !24
  %t504 = add i64 %t501, 1
  store i64 %t504, ptr %l34, !tbaa !24
  br label %bb123
bb129:
  br label %bb130
bb130:
  %t506 = load i64, ptr %l30, !tbaa !24
  %t509 = add i64 %t506, 1
  store i64 %t509, ptr %l30, !tbaa !24
  br label %bb119
bb131:
  br label %bb144
bb132:
  %t511 = load ptr, ptr %l6, !tbaa !29
  store ptr %t511, ptr %l270, !tbaa !29
  store i1 false, ptr %l271, !tbaa !21
  %t512 = load ptr, ptr %l270, !tbaa !29
  %t513 = icmp ne ptr %t512, null
  br i1 %t513, label %bb133, label %bb134
bb133:
  %t515 = load ptr, ptr %l270, !tbaa !29
  %t516 = load i64, ptr %t515, !range !{i64 0, i64 12}
  %t518 = icmp eq i64 %t516, 11
  store i1 %t518, ptr %l271, !tbaa !21
  br label %bb134
bb134:
  %t519 = load i1, ptr %l271, !tbaa !21
  br i1 %t519, label %bb135, label %bb136
bb135:
  %t520 = load ptr, ptr %l6, !tbaa !29
  %t522 = getelementptr { i64, [8 x i64] }, ptr %t520, i32 0, i32 1
  %t523 = getelementptr { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr } }, ptr %t522, i32 0, i32 2
  %t524 = load { i64, ptr }, ptr %t523
  store { i64, ptr } %t524, ptr %l37, !tbaa !27
  br label %bb137
bb136:
  br label %bb139
bb137:
  %t526 = load ptr, ptr %l0, !tbaa !29
  %t527 = load i64, ptr %l1, !tbaa !24
  %t528 = load { i64, ptr }, ptr %l37, !tbaa !27
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ebodies(ptr %v0, ptr %v1, ptr %t526, i64 %t527, { i64, ptr } %t528)
  br label %bb138
bb138:
  br label %bb144
bb139:
  br i1 true, label %bb140, label %bb141
bb140:
  br label %bb142
bb141:
  br label %bb143
bb142:
  br label %bb144
bb143:
  call void @__olang_check_failed(ptr @olang_loc_d2d926149e7406c7_ee094aa2e5a4afab)
  unreachable
bb144:
  br label %bb145
bb145:
  %t532 = load i64, ptr %l4, !tbaa !24
  %t535 = add i64 %t532, 1
  store i64 %t535, ptr %l4, !tbaa !24
  br label %bb1
bb146:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ebodiesIf(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, i64 %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i64
  %l18 = alloca %"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba"
  %l23 = alloca i1
  %l29 = alloca ptr
  %l30 = alloca i64
  %l38 = alloca %"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba"
  %l42 = alloca i1
  %l52 = alloca ptr
  %l53 = alloca i64
  %l65 = alloca ptr
  %l66 = alloca i64
  %l79 = alloca i1
  %l84 = alloca i1
  %l94 = alloca ptr
  %l95 = alloca i64
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i64 %a3, ptr %l3
  store i64 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l3, !tbaa !24
  %t2 = load i64, ptr %l4, !tbaa !24
  %t5 = icmp ne i64 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/names:Resolver", ptr %t7, i32 0, i32 21
  store ptr %t9, ptr %l9, !tbaa !29
  %t10 = load i64, ptr %l1, !tbaa !24
  store i64 %t10, ptr %l10, !tbaa !24
  %t11 = load ptr, ptr %l2, !tbaa !29
  %t13 = getelementptr %"compiler/ast:TopIf", ptr %t11, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t16 = icmp eq ptr %t14, null
  br i1 %t16, label %bb3, label %bb4
bb2:
  br label %bb8
bb3:
  call void @__olang_check_failed(ptr @olang_loc_68114e74278341f8_5424865478da1a14)
  unreachable
bb4:
  br label %bb5
bb5:
  %t18 = load ptr, ptr %l2, !tbaa !29
  %t20 = getelementptr %"compiler/ast:TopIf", ptr %t18, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t24 = getelementptr %"compiler/ast:TopBranch", ptr %t21, i32 0, i32 0
  %t25 = load %"compiler/source:Span", ptr %t24
  %t26 = load i64, ptr %l10, !tbaa !24
  %t28 = call %"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba" @std_2fpair_3aPair_3cI64_2c_20compiler_2fsource_3aSpan_3e_2ector(ptr %s1, i64 %t26, %"compiler/source:Span" %t25)
  store %"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba" %t28, ptr %l18
  br label %bb6
bb6:
  %t29 = load ptr, ptr %l9, !tbaa !29
  %t30 = load %"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba", ptr %l18
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20compiler__H2dfd829fbe4fa38977b46d00afbe1a06(ptr %v0, ptr %t29, %"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba" %t30)
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s1)
  br label %bb8
bb8:
  %t31 = load ptr, ptr %l2, !tbaa !29
  %t33 = getelementptr %"compiler/ast:TopIf", ptr %t31, i32 0, i32 3
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t36 = icmp eq ptr %t34, null
  %t38 = xor i1 %t36, true
  br i1 %t38, label %bb9, label %bb10
bb9:
  %t40 = load i64, ptr %l3, !tbaa !24
  %t41 = load i64, ptr %l4, !tbaa !24
  %t43 = add i64 %t41, 1
  %t46 = icmp ne i64 %t40, %t43
  store i1 %t46, ptr %l23, !tbaa !21
  br label %bb11
bb10:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb11
bb11:
  %t48 = load i1, ptr %l23, !tbaa !21
  br i1 %t48, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/names:Resolver", ptr %t49, i32 0, i32 21
  store ptr %t51, ptr %l29, !tbaa !29
  %t52 = load i64, ptr %l1, !tbaa !24
  store i64 %t52, ptr %l30, !tbaa !24
  %t53 = load ptr, ptr %l2, !tbaa !29
  %t55 = getelementptr %"compiler/ast:TopIf", ptr %t53, i32 0, i32 3
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t58 = icmp eq ptr %t56, null
  br i1 %t58, label %bb14, label %bb15
bb13:
  br label %bb19
bb14:
  call void @__olang_check_failed(ptr @olang_loc_3167f851ad930e17_101a5d4c5c826523)
  unreachable
bb15:
  br label %bb16
bb16:
  %t60 = load ptr, ptr %l2, !tbaa !29
  %t62 = getelementptr %"compiler/ast:TopIf", ptr %t60, i32 0, i32 3
  %t63 = load ptr, ptr %t62, !tbaa !29
  %t66 = getelementptr %"compiler/ast:TopBranch", ptr %t63, i32 0, i32 0
  %t67 = load %"compiler/source:Span", ptr %t66
  %t68 = load i64, ptr %l30, !tbaa !24
  %t70 = call %"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba" @std_2fpair_3aPair_3cI64_2c_20compiler_2fsource_3aSpan_3e_2ector(ptr %s2, i64 %t68, %"compiler/source:Span" %t67)
  store %"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba" %t70, ptr %l38
  br label %bb17
bb17:
  %t71 = load ptr, ptr %l29, !tbaa !29
  %t72 = load %"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba", ptr %l38
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20compiler__H2dfd829fbe4fa38977b46d00afbe1a06(ptr %v0, ptr %t71, %"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba" %t72)
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb19:
  %t73 = load i64, ptr %l3, !tbaa !24
  %t74 = load i64, ptr %l4, !tbaa !24
  %t77 = icmp eq i64 %t73, %t74
  br i1 %t77, label %bb20, label %bb21
bb20:
  %t79 = load ptr, ptr %l2, !tbaa !29
  %t81 = getelementptr %"compiler/ast:TopIf", ptr %t79, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t84 = icmp eq ptr %t82, null
  br i1 %t84, label %bb22, label %bb23
bb21:
  store i1 false, ptr %l42, !tbaa !21
  br label %bb25
bb22:
  call void @__olang_check_failed(ptr @olang_loc_10b7a8cdf1f86826_4c22b802d51640a2)
  unreachable
bb23:
  br label %bb24
bb24:
  %t86 = load ptr, ptr %l2, !tbaa !29
  %t88 = getelementptr %"compiler/ast:TopIf", ptr %t86, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !29
  %t92 = getelementptr %"compiler/ast:TopBranch", ptr %t89, i32 0, i32 1
  %t93 = load { i64, ptr }, ptr %t92, !tbaa !27
  %t95 = extractvalue { i64, ptr } %t93, 0
  %t97 = icmp sgt i64 %t95, 0
  store i1 %t97, ptr %l42, !tbaa !21
  br label %bb25
bb25:
  %t99 = load i1, ptr %l42, !tbaa !21
  br i1 %t99, label %bb26, label %bb27
bb26:
  %t100 = load ptr, ptr %l0, !tbaa !29
  store ptr %t100, ptr %l52, !tbaa !29
  %t101 = load i64, ptr %l1, !tbaa !24
  store i64 %t101, ptr %l53, !tbaa !24
  %t102 = load ptr, ptr %l2, !tbaa !29
  %t104 = getelementptr %"compiler/ast:TopIf", ptr %t102, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !29
  %t107 = icmp eq ptr %t105, null
  br i1 %t107, label %bb28, label %bb29
bb27:
  br label %bb32
bb28:
  call void @__olang_check_failed(ptr @olang_loc_10b7a8cdf1f86826_4c22b802d51640a2)
  unreachable
bb29:
  br label %bb30
bb30:
  %t109 = load ptr, ptr %l2, !tbaa !29
  %t111 = getelementptr %"compiler/ast:TopIf", ptr %t109, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !29
  %t115 = getelementptr %"compiler/ast:TopBranch", ptr %t112, i32 0, i32 1
  %t116 = load { i64, ptr }, ptr %t115, !tbaa !27
  %t117 = load ptr, ptr %l52, !tbaa !29
  %t118 = load i64, ptr %l53, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ebodies(ptr %v0, ptr %v1, ptr %t117, i64 %t118, { i64, ptr } %t116)
  br label %bb31
bb31:
  br label %bb32
bb32:
  %t120 = load ptr, ptr %l2, !tbaa !29
  %t122 = getelementptr %"compiler/ast:TopIf", ptr %t120, i32 0, i32 2
  %t123 = load ptr, ptr %t122, !tbaa !29
  %t125 = icmp eq ptr %t123, null
  %t127 = xor i1 %t125, true
  br i1 %t127, label %bb33, label %bb34
bb33:
  %t129 = load ptr, ptr %l0, !tbaa !29
  store ptr %t129, ptr %l65, !tbaa !29
  %t130 = load i64, ptr %l1, !tbaa !24
  store i64 %t130, ptr %l66, !tbaa !24
  %t131 = load ptr, ptr %l2, !tbaa !29
  %t133 = getelementptr %"compiler/ast:TopIf", ptr %t131, i32 0, i32 2
  %t134 = load ptr, ptr %t133, !tbaa !29
  %t136 = icmp eq ptr %t134, null
  br i1 %t136, label %bb35, label %bb36
bb34:
  br label %bb39
bb35:
  call void @__olang_check_failed(ptr @olang_loc_4f6a732ad110320d_928733cb84224b09)
  unreachable
bb36:
  br label %bb37
bb37:
  %t138 = load ptr, ptr %l2, !tbaa !29
  %t140 = getelementptr %"compiler/ast:TopIf", ptr %t138, i32 0, i32 2
  %t141 = load ptr, ptr %t140, !tbaa !29
  %t142 = load i64, ptr %l3, !tbaa !24
  %t143 = load i64, ptr %l4, !tbaa !24
  %t145 = add i64 %t143, 1
  %t146 = load ptr, ptr %l65, !tbaa !29
  %t147 = load i64, ptr %l66, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ebodiesIf(ptr %v0, ptr %v1, ptr %t146, i64 %t147, ptr %t141, i64 %t142, i64 %t145)
  br label %bb38
bb38:
  br label %bb39
bb39:
  %t151 = load ptr, ptr %l2, !tbaa !29
  %t153 = getelementptr %"compiler/ast:TopIf", ptr %t151, i32 0, i32 3
  %t154 = load ptr, ptr %t153, !tbaa !29
  %t156 = icmp eq ptr %t154, null
  %t158 = xor i1 %t156, true
  br i1 %t158, label %bb40, label %bb41
bb40:
  %t160 = load i64, ptr %l3, !tbaa !24
  %t161 = load i64, ptr %l4, !tbaa !24
  %t163 = add i64 %t161, 1
  %t166 = icmp eq i64 %t160, %t163
  store i1 %t166, ptr %l79, !tbaa !21
  br label %bb42
bb41:
  store i1 false, ptr %l79, !tbaa !21
  br label %bb42
bb42:
  %t168 = load i1, ptr %l79, !tbaa !21
  br i1 %t168, label %bb43, label %bb44
bb43:
  %t169 = load ptr, ptr %l2, !tbaa !29
  %t171 = getelementptr %"compiler/ast:TopIf", ptr %t169, i32 0, i32 3
  %t172 = load ptr, ptr %t171, !tbaa !29
  %t174 = icmp eq ptr %t172, null
  br i1 %t174, label %bb45, label %bb46
bb44:
  store i1 false, ptr %l84, !tbaa !21
  br label %bb48
bb45:
  call void @__olang_check_failed(ptr @olang_loc_3f10f26d81c7593c_51efd4b9807fb190)
  unreachable
bb46:
  br label %bb47
bb47:
  %t176 = load ptr, ptr %l2, !tbaa !29
  %t178 = getelementptr %"compiler/ast:TopIf", ptr %t176, i32 0, i32 3
  %t179 = load ptr, ptr %t178, !tbaa !29
  %t182 = getelementptr %"compiler/ast:TopBranch", ptr %t179, i32 0, i32 1
  %t183 = load { i64, ptr }, ptr %t182, !tbaa !27
  %t185 = extractvalue { i64, ptr } %t183, 0
  %t187 = icmp sgt i64 %t185, 0
  store i1 %t187, ptr %l84, !tbaa !21
  br label %bb48
bb48:
  %t189 = load i1, ptr %l84, !tbaa !21
  br i1 %t189, label %bb49, label %bb50
bb49:
  %t190 = load ptr, ptr %l0, !tbaa !29
  store ptr %t190, ptr %l94, !tbaa !29
  %t191 = load i64, ptr %l1, !tbaa !24
  store i64 %t191, ptr %l95, !tbaa !24
  %t192 = load ptr, ptr %l2, !tbaa !29
  %t194 = getelementptr %"compiler/ast:TopIf", ptr %t192, i32 0, i32 3
  %t195 = load ptr, ptr %t194, !tbaa !29
  %t197 = icmp eq ptr %t195, null
  br i1 %t197, label %bb51, label %bb52
bb50:
  br label %bb55
bb51:
  call void @__olang_check_failed(ptr @olang_loc_3f10f26d81c7593c_51efd4b9807fb190)
  unreachable
bb52:
  br label %bb53
bb53:
  %t199 = load ptr, ptr %l2, !tbaa !29
  %t201 = getelementptr %"compiler/ast:TopIf", ptr %t199, i32 0, i32 3
  %t202 = load ptr, ptr %t201, !tbaa !29
  %t205 = getelementptr %"compiler/ast:TopBranch", ptr %t202, i32 0, i32 1
  %t206 = load { i64, ptr }, ptr %t205, !tbaa !27
  %t207 = load ptr, ptr %l94, !tbaa !29
  %t208 = load i64, ptr %l95, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ebodies(ptr %v0, ptr %v1, ptr %t207, i64 %t208, { i64, ptr } %t206)
  br label %bb54
bb54:
  br label %bb55
bb55:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ebranch(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Branch", ptr %t1, i32 0, i32 2
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = icmp sge i64 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/names:Resolver", ptr %t8, i32 0, i32 0
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t13 = getelementptr %"compiler/load:Loader", ptr %t11, i32 0, i32 4
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr %"compiler/ast:Branch", ptr %t15, i32 0, i32 2
  %t18 = load i64, ptr %t17, !tbaa !24
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eReopen(ptr %v0, ptr %t14, i64 %t18)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr %"compiler/ast:Branch", ptr %t22, i32 0, i32 1
  %t25 = load { i64, ptr }, ptr %t24, !tbaa !27
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eblock(ptr %v0, ptr %v1, ptr %t21, { i64, ptr } %t25)
  br label %bb5
bb5:
  %t28 = load ptr, ptr %l1, !tbaa !29
  %t30 = getelementptr %"compiler/ast:Branch", ptr %t28, i32 0, i32 2
  %t31 = load i64, ptr %t30, !tbaa !24
  %t33 = icmp sge i64 %t31, 0
  br i1 %t33, label %bb6, label %bb7
bb6:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/names:Resolver", ptr %t35, i32 0, i32 0
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t40 = getelementptr %"compiler/load:Loader", ptr %t38, i32 0, i32 4
  %t41 = load ptr, ptr %t40, !tbaa !29
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eEndHold(ptr %v0, ptr %t41)
  br label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb9
bb9:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ebuildDefault(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2, %"compiler/source:Span" %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l16 = alloca i64
  %l22 = alloca ptr
  %l29 = alloca { i64, ptr }
  %l35 = alloca %"compiler/source:Span"
  %l37 = alloca i64
  %l43 = alloca %"compiler/source:Span"
  %l45 = alloca i64
  %l46 = alloca i64
  %l51 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %l61 = alloca i64
  %l64 = alloca { i64, ptr }
  %l66 = alloca { i64, ptr }
  %l67 = alloca { i64, ptr }
  %l71 = alloca { i64, ptr }
  %l74 = alloca i1
  %l76 = alloca i1
  %l78 = alloca i1
  %l80 = alloca i1
  %l82 = alloca i1
  %l84 = alloca i1
  %l86 = alloca i1
  %l88 = alloca i1
  %l90 = alloca i1
  %l92 = alloca i1
  %l94 = alloca i1
  %l96 = alloca i1
  %l100 = alloca ptr
  %l104 = alloca { i64, [3 x i64] }
  %l107 = alloca { i64, ptr }
  %l110 = alloca %"compiler/diagmsg:Msg"
  %l111 = alloca i64
  %l114 = alloca { i64, ptr }
  %l116 = alloca i1
  %l118 = alloca i1
  %l123 = alloca { i64, ptr }
  %l126 = alloca i1
  %l129 = alloca ptr
  %l133 = alloca { i64, [3 x i64] }
  %l134 = alloca { i64, ptr }
  %l137 = alloca { i64, ptr }
  %l140 = alloca %"compiler/diagmsg:Msg"
  %l141 = alloca i64
  %l147 = alloca i1
  %l151 = alloca ptr
  %l155 = alloca { i64, [3 x i64] }
  %l156 = alloca { i64, ptr }
  %l161 = alloca { i64, ptr }
  %l162 = alloca { i64, ptr }
  %l165 = alloca { i64, ptr }
  %l168 = alloca %"compiler/diagmsg:Msg"
  %l169 = alloca i64
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %t281 = alloca { { i64, ptr }, ptr }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb2:
  br label %bb3
bb3:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d2, i32 0, i32 1) }, ptr %l10, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t5, ptr %l5, !tbaa !27
  %t7 = load ptr, ptr %l4, !tbaa !29
  %t9 = getelementptr %"compiler/ast:VarDecl", ptr %t7, i32 0, i32 2
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = icmp eq ptr %t10, null
  %t14 = xor i1 %t12, true
  br i1 %t14, label %bb4, label %bb5
bb4:
  %t16 = call ptr @__olang_scope_hold(ptr %s0)
  %t17 = ptrtoint ptr %t16 to i64
  store i64 %t17, ptr %l16, !tbaa !24
  %t18 = load i1, ptr @olang_2esole_2ecompiler__2fnames__2ecompiler__2fnames__3aResolver__2ebuildDefault_2elocal_2e5
  br i1 %t18, label %bb6, label %bb7
bb5:
  %t20 = load ptr, ptr %l4, !tbaa !29
  %t22 = getelementptr %"compiler/ast:VarDecl", ptr %t20, i32 0, i32 3
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t23, 0
  %t27 = icmp eq i64 %t25, 1
  br i1 %t27, label %bb32, label %bb33
bb6:
  %t29 = call ptr @__olang_region_make(ptr %s0)
  %t30 = ptrtoint ptr %t29 to i64
  store i64 %t30, ptr %l16, !tbaa !24
  br label %bb7
bb7:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/names:Resolver", ptr %t31, i32 0, i32 0
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t36 = getelementptr %"compiler/load:Loader", ptr %t34, i32 0, i32 10
  %t37 = load i64, ptr %l1, !tbaa !24
  %t40 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t36, i64 %t37)
  store ptr %t40, ptr %l22
  br label %bb8
bb8:
  %t41 = load ptr, ptr %l22, !tbaa !29
  %t43 = getelementptr %"compiler/load:Module", ptr %t41, i32 0, i32 6
  %t44 = load ptr, ptr %t43, !tbaa !29
  store ptr %t44, ptr %l6, !tbaa !29
  %t46 = load ptr, ptr %l6, !tbaa !29
  %t48 = icmp eq ptr %t46, null
  br i1 %t48, label %bb9, label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_1073219c408bafd2_e24f73113d5a6ea6)
  unreachable
bb10:
  br label %bb11
bb11:
  %t50 = load ptr, ptr %l6, !tbaa !29
  %t53 = getelementptr %"compiler/source:Source", ptr %t50, i32 0, i32 1
  %t54 = load { i64, ptr }, ptr %t53, !tbaa !27
  store { i64, ptr } %t54, ptr %l29, !tbaa !27
  %t55 = load ptr, ptr %l4, !tbaa !29
  %t57 = getelementptr %"compiler/ast:VarDecl", ptr %t55, i32 0, i32 2
  %t58 = load ptr, ptr %t57, !tbaa !29
  %t60 = icmp eq ptr %t58, null
  br i1 %t60, label %bb12, label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_1073219c408bafd2_e24f73113d5a6ea6)
  unreachable
bb13:
  br label %bb14
bb14:
  %t62 = load ptr, ptr %l4, !tbaa !29
  %t64 = getelementptr %"compiler/ast:VarDecl", ptr %t62, i32 0, i32 2
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t67 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t65)
  store %"compiler/source:Span" %t67, ptr %l35
  br label %bb15
bb15:
  %t68 = getelementptr %"compiler/source:Span", ptr %l35, i32 0, i32 0
  %t69 = load i32, ptr %t68, !tbaa !23
  %t71 = sext i32 %t69 to i64
  store i64 %t71, ptr %l37, !tbaa !24
  %t72 = load ptr, ptr %l4, !tbaa !29
  %t74 = getelementptr %"compiler/ast:VarDecl", ptr %t72, i32 0, i32 2
  %t75 = load ptr, ptr %t74, !tbaa !29
  %t77 = icmp eq ptr %t75, null
  br i1 %t77, label %bb16, label %bb17
bb16:
  call void @__olang_check_failed(ptr @olang_loc_1073219c408bafd2_e24f73113d5a6ea6)
  unreachable
bb17:
  br label %bb18
bb18:
  %t79 = load ptr, ptr %l4, !tbaa !29
  %t81 = getelementptr %"compiler/ast:VarDecl", ptr %t79, i32 0, i32 2
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t84 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t82)
  store %"compiler/source:Span" %t84, ptr %l43
  br label %bb19
bb19:
  %t85 = getelementptr %"compiler/source:Span", ptr %l43, i32 0, i32 1
  %t86 = load i32, ptr %t85, !tbaa !23
  %t88 = sext i32 %t86 to i64
  store i64 %t88, ptr %l45, !tbaa !24
  %t89 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t90 = extractvalue { i64, ptr } %t89, 0
  store i64 %t90, ptr %l46, !tbaa !24
  %t91 = load i64, ptr %l37, !tbaa !24
  %t92 = icmp sge i64 %t91, 0
  br i1 %t92, label %bb20, label %bb21
bb20:
  %t94 = load i64, ptr %l37, !tbaa !24
  %t95 = load i64, ptr %l45, !tbaa !24
  %t96 = icmp sle i64 %t94, %t95
  br i1 %t96, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_f4b8a71cbdc10f47_ba6792d0a606e23b)
  unreachable
bb22:
  %t98 = load i64, ptr %l45, !tbaa !24
  %t99 = load i64, ptr %l46, !tbaa !24
  %t100 = icmp sle i64 %t98, %t99
  br i1 %t100, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_f4b8a71cbdc10f47_ba6792d0a606e23b)
  unreachable
bb24:
  %t102 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t103 = load ptr, ptr %t102, !tbaa !27
  %t104 = load i64, ptr %l37, !tbaa !24
  %t105 = load i64, ptr %l45, !tbaa !24
  %t106 = getelementptr i8, ptr %t103, i64 %t104
  %t107 = sub i64 %t105, %t104
  %t108 = insertvalue { i64, ptr } undef, i64 %t107, 0
  %t109 = insertvalue { i64, ptr } %t108, ptr %t106, 1
  %t111 = extractvalue { i64, ptr } %t109, 1
  %t112 = extractvalue { i64, ptr } %t109, 0
  %t113 = load i64, ptr %l16
  %t114 = inttoptr i64 %t113 to ptr
  %t115 = call ptr @__olang_held_alloc(ptr %t114, i64 %t112)
  call void @olang_textcopy(ptr %t115, ptr %t111, i64 %t112)
  %t116 = insertvalue { i64, ptr } undef, i64 %t112, 0
  %t117 = insertvalue { i64, ptr } %t116, ptr %t115, 1
  store { i64, ptr } %t117, ptr %l51, !tbaa !27
  %t118 = load i1, ptr @olang_2esole_2ecompiler__2fnames__2ecompiler__2fnames__3aResolver__2ebuildDefault_2elocal_2e5
  br i1 %t118, label %bb26, label %bb27
bb25:
  call void @__olang_check_failed(ptr @olang_loc_f4b8a71cbdc10f47_ba6792d0a606e23b)
  unreachable
bb26:
  %t120 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t121 = extractvalue { i64, ptr } %t120, 0
  %t123 = icmp eq i64 %t121, 0
  br i1 %t123, label %bb28, label %bb29
bb27:
  %t125 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t125, ptr %l55, !tbaa !27
  %t126 = load { i64, ptr }, ptr %l51, !tbaa !27
  store { i64, ptr } %t126, ptr %l5, !tbaa !27
  %t127 = load i1, ptr @olang_2esole_2ecompiler__2fnames__2ecompiler__2fnames__3aResolver__2ebuildDefault_2elocal_2e5
  br i1 %t127, label %bb30, label %bb31
bb28:
  store { i64, ptr } zeroinitializer, ptr %l51, !tbaa !27
  br label %bb29
bb29:
  %t129 = load i64, ptr %l16
  %t130 = inttoptr i64 %t129 to ptr
  %t131 = load { i64, ptr }, ptr %l51
  %t132 = extractvalue { i64, ptr } %t131, 1
  %t133 = call ptr @__olang_region_or(ptr %t132, ptr null)
  %t134 = icmp ne ptr %t133, null
  %t135 = select i1 %t134, ptr %t133, ptr null
  call void @__olang_region_settle_in(ptr %t130, ptr %t135)
  br label %bb27
bb30:
  %t136 = load { i64, ptr }, ptr %l55
  %t137 = extractvalue { i64, ptr } %t136, 1
  call void @__olang_region_release(ptr %t137)
  store { i64, ptr } zeroinitializer, ptr %l55
  br label %bb31
bb31:
  br label %bb44
bb32:
  store %olang.scope zeroinitializer, ptr %s5
  %t138 = call ptr @__olang_scope_hold(ptr %s0)
  %t139 = ptrtoint ptr %t138 to i64
  store i64 %t139, ptr %l61, !tbaa !24
  %t140 = load i1, ptr @olang_2esole_2ecompiler__2fnames__2ecompiler__2fnames__3aResolver__2ebuildDefault_2elocal_2e5
  br i1 %t140, label %bb34, label %bb35
bb33:
  br label %bb43
bb34:
  %t142 = call ptr @__olang_region_make(ptr %s0)
  %t143 = ptrtoint ptr %t142 to i64
  store i64 %t143, ptr %l61, !tbaa !24
  br label %bb35
bb35:
  %t144 = load ptr, ptr %l4, !tbaa !29
  %t146 = getelementptr %"compiler/ast:VarDecl", ptr %t144, i32 0, i32 3
  %t147 = load { i64, ptr }, ptr %t146, !tbaa !27
  store { i64, ptr } %t147, ptr %l64, !tbaa !27
  %t148 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t149 = load ptr, ptr %t148, !tbaa !27
  %t150 = getelementptr ptr, ptr %t149, i64 0
  %t151 = load ptr, ptr %t150, !tbaa !39
  %t153 = call { i64, ptr } @compiler_2fnames_2eliteralType(ptr %v1, ptr %s5, ptr %t151)
  store { i64, ptr } %t153, ptr %l66
  br label %bb36
bb36:
  %t154 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t155 = extractvalue { i64, ptr } %t154, 1
  %t156 = extractvalue { i64, ptr } %t154, 0
  %t157 = load i64, ptr %l61
  %t158 = inttoptr i64 %t157 to ptr
  %t159 = call ptr @__olang_held_alloc(ptr %t158, i64 %t156)
  call void @olang_textcopy(ptr %t159, ptr %t155, i64 %t156)
  %t160 = insertvalue { i64, ptr } undef, i64 %t156, 0
  %t161 = insertvalue { i64, ptr } %t160, ptr %t159, 1
  store { i64, ptr } %t161, ptr %l67, !tbaa !27
  %t162 = load i1, ptr @olang_2esole_2ecompiler__2fnames__2ecompiler__2fnames__3aResolver__2ebuildDefault_2elocal_2e5
  br i1 %t162, label %bb37, label %bb38
bb37:
  %t164 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t165 = extractvalue { i64, ptr } %t164, 0
  %t167 = icmp eq i64 %t165, 0
  br i1 %t167, label %bb39, label %bb40
bb38:
  %t169 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t169, ptr %l71, !tbaa !27
  %t170 = load { i64, ptr }, ptr %l67, !tbaa !27
  store { i64, ptr } %t170, ptr %l5, !tbaa !27
  %t171 = load i1, ptr @olang_2esole_2ecompiler__2fnames__2ecompiler__2fnames__3aResolver__2ebuildDefault_2elocal_2e5
  br i1 %t171, label %bb41, label %bb42
bb39:
  store { i64, ptr } zeroinitializer, ptr %l67, !tbaa !27
  br label %bb40
bb40:
  %t173 = load i64, ptr %l61
  %t174 = inttoptr i64 %t173 to ptr
  %t175 = load { i64, ptr }, ptr %l67
  %t176 = extractvalue { i64, ptr } %t175, 1
  %t177 = call ptr @__olang_region_or(ptr %t176, ptr null)
  %t178 = icmp ne ptr %t177, null
  %t179 = select i1 %t178, ptr %t177, ptr null
  call void @__olang_region_settle_in(ptr %t174, ptr %t179)
  br label %bb38
bb41:
  %t180 = load { i64, ptr }, ptr %l71
  %t181 = extractvalue { i64, ptr } %t180, 1
  call void @__olang_region_release(ptr %t181)
  store { i64, ptr } zeroinitializer, ptr %l71
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s5)
  br label %bb43
bb43:
  br label %bb44
bb44:
  %t182 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t184 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t182, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d3, i32 0, i32 1) })
  store i1 %t184, ptr %l74
  br label %bb45
bb45:
  %t185 = load i1, ptr %l74, !tbaa !21
  br i1 %t185, label %bb46, label %bb47
bb46:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb47:
  br label %bb48
bb48:
  %t186 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t188 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t186, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d4, i32 0, i32 1) })
  store i1 %t188, ptr %l76
  br label %bb49
bb49:
  %t189 = load i1, ptr %l76, !tbaa !21
  %t190 = xor i1 %t189, true
  br i1 %t190, label %bb50, label %bb51
bb50:
  %t192 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t194 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t192, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d5, i32 0, i32 1) })
  store i1 %t194, ptr %l80
  br label %bb52
bb51:
  store i1 false, ptr %l78, !tbaa !21
  br label %bb53
bb52:
  %t195 = load i1, ptr %l80, !tbaa !21
  %t196 = xor i1 %t195, true
  store i1 %t196, ptr %l78, !tbaa !21
  br label %bb53
bb53:
  %t198 = load i1, ptr %l78, !tbaa !21
  br i1 %t198, label %bb54, label %bb55
bb54:
  %t199 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t201 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t199, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d6, i32 0, i32 1) })
  store i1 %t201, ptr %l84
  br label %bb56
bb55:
  store i1 false, ptr %l82, !tbaa !21
  br label %bb57
bb56:
  %t202 = load i1, ptr %l84, !tbaa !21
  %t203 = xor i1 %t202, true
  store i1 %t203, ptr %l82, !tbaa !21
  br label %bb57
bb57:
  %t205 = load i1, ptr %l82, !tbaa !21
  br i1 %t205, label %bb58, label %bb59
bb58:
  %t206 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t208 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t206, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d7, i32 0, i32 1) })
  store i1 %t208, ptr %l88
  br label %bb60
bb59:
  store i1 false, ptr %l86, !tbaa !21
  br label %bb61
bb60:
  %t209 = load i1, ptr %l88, !tbaa !21
  %t210 = xor i1 %t209, true
  store i1 %t210, ptr %l86, !tbaa !21
  br label %bb61
bb61:
  %t212 = load i1, ptr %l86, !tbaa !21
  br i1 %t212, label %bb62, label %bb63
bb62:
  %t213 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t215 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t213, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d8, i32 0, i32 1) })
  store i1 %t215, ptr %l92
  br label %bb64
bb63:
  store i1 false, ptr %l90, !tbaa !21
  br label %bb65
bb64:
  %t216 = load i1, ptr %l92, !tbaa !21
  %t217 = xor i1 %t216, true
  store i1 %t217, ptr %l90, !tbaa !21
  br label %bb65
bb65:
  %t219 = load i1, ptr %l90, !tbaa !21
  br i1 %t219, label %bb66, label %bb67
bb66:
  %t220 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t222 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t220, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d9, i32 0, i32 1) })
  store i1 %t222, ptr %l96
  br label %bb68
bb67:
  store i1 false, ptr %l94, !tbaa !21
  br label %bb69
bb68:
  %t223 = load i1, ptr %l96, !tbaa !21
  %t224 = xor i1 %t223, true
  store i1 %t224, ptr %l94, !tbaa !21
  br label %bb69
bb69:
  %t226 = load i1, ptr %l94, !tbaa !21
  br i1 %t226, label %bb70, label %bb71
bb70:
  store %olang.scope zeroinitializer, ptr %s8
  %t227 = load ptr, ptr %l0, !tbaa !29
  %t229 = getelementptr %"compiler/names:Resolver", ptr %t227, i32 0, i32 0
  %t230 = load ptr, ptr %t229, !tbaa !29
  %t232 = getelementptr %"compiler/load:Loader", ptr %t230, i32 0, i32 4
  %t233 = load ptr, ptr %t232, !tbaa !29
  store ptr %t233, ptr %l100, !tbaa !29
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t235 = load i64, ptr %l1, !tbaa !24
  %t236 = load %"compiler/source:Span", ptr %l3
  %t240 = call { i64, [3 x i64] } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eat(ptr %v0, ptr %t234, i64 %t235, %"compiler/source:Span" %t236)
  store { i64, [3 x i64] } %t240, ptr %l104
  br label %bb72
bb71:
  br label %bb76
bb72:
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t242 = load i32, ptr %l2, !tbaa !23
  %t245 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etok(ptr %v0, ptr %s8, ptr %t241, i32 %t242)
  store { i64, ptr } %t245, ptr %l107
  br label %bb73
bb73:
  %t246 = load { i64, ptr }, ptr %l107, !tbaa !27
  %t247 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t250 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eBuildDefaultType(ptr %s8, ptr %s0, ptr %v0, { i64, ptr } %t246, { i64, ptr } %t247)
  store %"compiler/diagmsg:Msg" %t250, ptr %l110
  br label %bb74
bb74:
  %t251 = load ptr, ptr %l100, !tbaa !29
  %t252 = load { i64, [3 x i64] }, ptr %l104
  %t253 = load %"compiler/diagmsg:Msg", ptr %l110
  %t254 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v0, ptr %t251, { i64, [3 x i64] } %t252, %"compiler/diagmsg:Msg" %t253)
  store i64 %t254, ptr %l111
  br label %bb75
bb75:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb76:
  %t255 = load ptr, ptr %l0, !tbaa !29
  %t256 = load i32, ptr %l2, !tbaa !23
  %t259 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %v0, ptr %t255, i32 %t256)
  store { i64, ptr } %t259, ptr %l114
  br label %bb77
bb77:
  %t260 = load { i64, ptr }, ptr %l114, !tbaa !27
  store { i64, ptr } %t260, ptr %l7, !tbaa !27
  %t261 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t263 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t261, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d10, i32 0, i32 1) })
  store i1 %t263, ptr %l116
  br label %bb78
bb78:
  %t264 = load i1, ptr %l116, !tbaa !21
  %t265 = xor i1 %t264, true
  br i1 %t265, label %bb79, label %bb80
bb79:
  %t267 = load ptr, ptr %l0, !tbaa !29
  %t269 = getelementptr %"compiler/names:Resolver", ptr %t267, i32 0, i32 0
  %t270 = load ptr, ptr %t269, !tbaa !29
  %t272 = getelementptr %"compiler/load:Loader", ptr %t270, i32 0, i32 1
  %t273 = load ptr, ptr %t272, !tbaa !29
  %t275 = getelementptr %"compiler/cond:Consts", ptr %t273, i32 0, i32 7
  %t277 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %v0, ptr %v0, ptr %t275)
  store { i64, ptr } %t277, ptr %l123
  br label %bb81
bb80:
  store i1 false, ptr %l118, !tbaa !21
  br label %bb83
bb81:
  %t278 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t279 = getelementptr { { i64, ptr }, ptr }, ptr null, i32 1
  %t280 = ptrtoint ptr %t279 to i64
  %t282 = getelementptr { { i64, ptr }, ptr }, ptr %t281, i32 0, i32 0
  store { i64, ptr } %t278, ptr %t282, !tbaa !28
  call void @__olang_scope_escape(ptr %v0)
  %t284 = call ptr @__olang_scope_hold(ptr %v0)
  %t285 = getelementptr { { i64, ptr }, ptr }, ptr %t281, i32 0, i32 1
  store ptr %t284, ptr %t285, !tbaa !28
  %t286 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_11, 0
  %t287 = insertvalue { ptr, ptr } %t286, ptr %t281, 1
  %t288 = load { i64, ptr }, ptr %l123, !tbaa !27
  %t290 = extractvalue { ptr, ptr } %t287, 0
  %t291 = extractvalue { ptr, ptr } %t287, 1
  %t292 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2eSome_3cstd_2fprelu_H83fc947e980a7768a96047c3a0b10532(ptr %v0, ptr %s0, { i64, ptr } %t288, ptr %t290, ptr %t291)
  store i1 %t292, ptr %l126
  br label %bb82
bb82:
  %t293 = load i1, ptr %l126, !tbaa !21
  store i1 %t293, ptr %l118, !tbaa !21
  br label %bb83
bb83:
  %t294 = load i1, ptr %l118, !tbaa !21
  br i1 %t294, label %bb84, label %bb85
bb84:
  store %olang.scope zeroinitializer, ptr %s9
  %t295 = load ptr, ptr %l0, !tbaa !29
  %t297 = getelementptr %"compiler/names:Resolver", ptr %t295, i32 0, i32 0
  %t298 = load ptr, ptr %t297, !tbaa !29
  %t300 = getelementptr %"compiler/load:Loader", ptr %t298, i32 0, i32 4
  %t301 = load ptr, ptr %t300, !tbaa !29
  store ptr %t301, ptr %l129, !tbaa !29
  %t302 = load ptr, ptr %l0, !tbaa !29
  %t303 = load i64, ptr %l1, !tbaa !24
  %t304 = load %"compiler/source:Span", ptr %l3
  %t308 = call { i64, [3 x i64] } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eat(ptr %v0, ptr %t302, i64 %t303, %"compiler/source:Span" %t304)
  store { i64, [3 x i64] } %t308, ptr %l133
  br label %bb86
bb85:
  br label %bb90
bb86:
  %t309 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t309, ptr %l134, !tbaa !27
  %t310 = load ptr, ptr %l0, !tbaa !29
  %t311 = load i32, ptr %l2, !tbaa !23
  %t314 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etok(ptr %v0, ptr %s9, ptr %t310, i32 %t311)
  store { i64, ptr } %t314, ptr %l137
  br label %bb87
bb87:
  %t315 = load { i64, ptr }, ptr %l137, !tbaa !27
  %t316 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t317 = load { i64, ptr }, ptr %l134, !tbaa !27
  %t320 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eBuildDefaultBare(ptr %v0, ptr %s9, ptr %s0, ptr %v0, { i64, ptr } %t317, { i64, ptr } %t315, { i64, ptr } %t316)
  store %"compiler/diagmsg:Msg" %t320, ptr %l140
  br label %bb88
bb88:
  %t321 = load ptr, ptr %l129, !tbaa !29
  %t322 = load { i64, [3 x i64] }, ptr %l133
  %t323 = load %"compiler/diagmsg:Msg", ptr %l140
  %t324 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v0, ptr %t321, { i64, [3 x i64] } %t322, %"compiler/diagmsg:Msg" %t323)
  store i64 %t324, ptr %l141
  br label %bb89
bb89:
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb90:
  %t325 = load ptr, ptr %l0, !tbaa !29
  %t327 = getelementptr %"compiler/names:Resolver", ptr %t325, i32 0, i32 0
  %t328 = load ptr, ptr %t327, !tbaa !29
  %t330 = getelementptr %"compiler/load:Loader", ptr %t328, i32 0, i32 1
  %t331 = load ptr, ptr %t330, !tbaa !29
  %t332 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t333 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t337 = call i1 @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eFits(ptr %v0, ptr %v0, ptr %s0, ptr %t331, { i64, ptr } %t332, { i64, ptr } %t333)
  store i1 %t337, ptr %l147
  br label %bb91
bb91:
  %t338 = load i1, ptr %l147, !tbaa !21
  %t339 = xor i1 %t338, true
  br i1 %t339, label %bb92, label %bb93
bb92:
  store %olang.scope zeroinitializer, ptr %s10
  %t341 = load ptr, ptr %l0, !tbaa !29
  %t343 = getelementptr %"compiler/names:Resolver", ptr %t341, i32 0, i32 0
  %t344 = load ptr, ptr %t343, !tbaa !29
  %t346 = getelementptr %"compiler/load:Loader", ptr %t344, i32 0, i32 4
  %t347 = load ptr, ptr %t346, !tbaa !29
  store ptr %t347, ptr %l151, !tbaa !29
  %t348 = load ptr, ptr %l0, !tbaa !29
  %t349 = load i64, ptr %l1, !tbaa !24
  %t350 = load %"compiler/source:Span", ptr %l3
  %t354 = call { i64, [3 x i64] } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eat(ptr %v0, ptr %t348, i64 %t349, %"compiler/source:Span" %t350)
  store { i64, [3 x i64] } %t354, ptr %l155
  br label %bb94
bb93:
  br label %bb99
bb94:
  %t355 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t355, ptr %l156, !tbaa !27
  %t356 = load ptr, ptr %l0, !tbaa !29
  %t358 = getelementptr %"compiler/names:Resolver", ptr %t356, i32 0, i32 0
  %t359 = load ptr, ptr %t358, !tbaa !29
  %t361 = getelementptr %"compiler/load:Loader", ptr %t359, i32 0, i32 1
  %t362 = load ptr, ptr %t361, !tbaa !29
  %t363 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t366 = call { i64, ptr } @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eRaw(ptr %v0, ptr %v0, ptr %s10, ptr %t362, { i64, ptr } %t363)
  store { i64, ptr } %t366, ptr %l161
  br label %bb95
bb95:
  %t367 = load { i64, ptr }, ptr %l161, !tbaa !27
  store { i64, ptr } %t367, ptr %l162, !tbaa !27
  %t368 = load ptr, ptr %l0, !tbaa !29
  %t369 = load i32, ptr %l2, !tbaa !23
  %t372 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etok(ptr %v0, ptr %s10, ptr %t368, i32 %t369)
  store { i64, ptr } %t372, ptr %l165
  br label %bb96
bb96:
  %t373 = load { i64, ptr }, ptr %l165, !tbaa !27
  %t374 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t375 = load { i64, ptr }, ptr %l156, !tbaa !27
  %t376 = load { i64, ptr }, ptr %l162, !tbaa !27
  %t379 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eBuildDefaultFit(ptr %v0, ptr %s10, ptr %s10, ptr %s0, ptr %v0, { i64, ptr } %t375, { i64, ptr } %t376, { i64, ptr } %t373, { i64, ptr } %t374)
  store %"compiler/diagmsg:Msg" %t379, ptr %l168
  br label %bb97
bb97:
  %t380 = load ptr, ptr %l151, !tbaa !29
  %t381 = load { i64, [3 x i64] }, ptr %l155
  %t382 = load %"compiler/diagmsg:Msg", ptr %l168
  %t383 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v0, ptr %t380, { i64, [3 x i64] } %t381, %"compiler/diagmsg:Msg" %t382)
  store i64 %t383, ptr %l169
  br label %bb98
bb98:
  call void @__olang_scope_close(ptr %s10)
  br label %bb99
bb99:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2echoose(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2, i1 %a3, i1 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca i1
  %l9 = alloca i1
  %l29 = alloca i1
  %l35 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i1 %a2, ptr %l2
  store i1 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Branch", ptr %t1, i32 0, i32 2
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = icmp slt i64 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load i1, ptr %l2, !tbaa !21
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load i1, ptr %l3, !tbaa !21
  %t12 = xor i1 %t10, true
  store i1 %t12, ptr %l9, !tbaa !21
  br label %bb6
bb5:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb6
bb6:
  %t14 = load i1, ptr %l9, !tbaa !21
  br i1 %t14, label %bb7, label %bb8
bb7:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/names:Resolver", ptr %t15, i32 0, i32 18
  %t18 = load ptr, ptr %l1, !tbaa !29
  %t20 = getelementptr %"compiler/ast:Branch", ptr %t18, i32 0, i32 0
  %t21 = load %"compiler/source:Span", ptr %t20
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t17, %"compiler/source:Span" %t21)
  br label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb10
bb10:
  %t24 = load i1, ptr %l2, !tbaa !21
  br i1 %t24, label %bb11, label %bb12
bb11:
  %t26 = load i1, ptr %l3, !tbaa !21
  br i1 %t26, label %bb13, label %bb14
bb12:
  br i1 %a4, label %bb18, label %bb19
bb13:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/names:Resolver", ptr %t30, i32 0, i32 0
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t35 = getelementptr %"compiler/load:Loader", ptr %t33, i32 0, i32 4
  %t36 = load ptr, ptr %t35, !tbaa !29
  %t37 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr %"compiler/ast:Branch", ptr %t37, i32 0, i32 2
  %t40 = load i64, ptr %t39, !tbaa !24
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eChoose(ptr %v0, ptr %t36, i64 %t40)
  br label %bb15
bb14:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/names:Resolver", ptr %t43, i32 0, i32 0
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t48 = getelementptr %"compiler/load:Loader", ptr %t46, i32 0, i32 4
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t50 = load ptr, ptr %l1, !tbaa !29
  %t52 = getelementptr %"compiler/ast:Branch", ptr %t50, i32 0, i32 2
  %t53 = load i64, ptr %t52, !tbaa !24
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eDrop(ptr %v0, ptr %t49, i64 %t53)
  br label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb17
bb17:
  br label %bb26
bb18:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/names:Resolver", ptr %t56, i32 0, i32 0
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t61 = getelementptr %"compiler/load:Loader", ptr %t59, i32 0, i32 4
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t63 = load ptr, ptr %l1, !tbaa !29
  %t65 = getelementptr %"compiler/ast:Branch", ptr %t63, i32 0, i32 2
  %t66 = load i64, ptr %t65, !tbaa !24
  %t69 = call i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eHolds(ptr %v0, ptr %t62, i64 %t66)
  store i1 %t69, ptr %l35
  br label %bb20
bb19:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb21
bb20:
  %t70 = load i1, ptr %l35, !tbaa !21
  %t71 = xor i1 %t70, true
  store i1 %t71, ptr %l29, !tbaa !21
  br label %bb21
bb21:
  %t73 = load i1, ptr %l29, !tbaa !21
  br i1 %t73, label %bb22, label %bb23
bb22:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/names:Resolver", ptr %t74, i32 0, i32 0
  %t77 = load ptr, ptr %t76, !tbaa !29
  %t79 = getelementptr %"compiler/load:Loader", ptr %t77, i32 0, i32 4
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t81 = load ptr, ptr %l1, !tbaa !29
  %t83 = getelementptr %"compiler/ast:Branch", ptr %t81, i32 0, i32 2
  %t84 = load i64, ptr %t83, !tbaa !24
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eChoose(ptr %v0, ptr %t80, i64 %t84)
  br label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb25
bb25:
  br label %bb26
bb26:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ecollect(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca ptr
  %l11 = alloca %"compiler/source:Span"
  %l12 = alloca ptr
  %l13 = alloca %"compiler/source:Span"
  %l14 = alloca i32
  %l15 = alloca { i64, ptr }
  %l16 = alloca ptr
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l34 = alloca ptr
  %l35 = alloca i1
  %l41 = alloca ptr
  %l42 = alloca i64
  %l48 = alloca %"compiler/source:Span"
  %l50 = alloca i64
  %l61 = alloca ptr
  %l62 = alloca i1
  %l67 = alloca ptr
  %l68 = alloca i1
  %l74 = alloca i1
  %l75 = alloca ptr
  %l76 = alloca i64
  %l78 = alloca i32
  %l79 = alloca ptr
  %l80 = alloca i64
  %l86 = alloca %"compiler/source:Span"
  %l90 = alloca %"compiler/source:Span"
  %l95 = alloca i32
  %l105 = alloca ptr
  %l106 = alloca i64
  %l108 = alloca i32
  %l114 = alloca %"compiler/source:Span"
  %l119 = alloca ptr
  %l120 = alloca i1
  %l127 = alloca ptr
  %l128 = alloca i64
  %l130 = alloca i32
  %l136 = alloca %"compiler/source:Span"
  %l139 = alloca ptr
  %l140 = alloca i1
  %l149 = alloca ptr
  %l150 = alloca i64
  %l151 = alloca i32
  %l156 = alloca %"compiler/source:Span"
  %l162 = alloca ptr
  %l163 = alloca i1
  %l174 = alloca i64
  %l177 = alloca i64
  %l195 = alloca ptr
  %l196 = alloca i64
  %l198 = alloca { i64, ptr }
  %l200 = alloca i32
  %l202 = alloca { i64, ptr }
  %l204 = alloca %"compiler/source:Span"
  %l207 = alloca i1
  %l213 = alloca ptr
  %l214 = alloca i1
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a2, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l5, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l4, !tbaa !24
  %t8 = load i64, ptr %l5, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb99
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t15, ptr %l31, !tbaa !27
  %t16 = load i64, ptr %l4, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  store ptr %t21, ptr %l6, !tbaa !29
  %t23 = load ptr, ptr %l6, !tbaa !29
  store ptr %t23, ptr %l34, !tbaa !29
  store i1 false, ptr %l35, !tbaa !21
  %t24 = load ptr, ptr %l34, !tbaa !29
  %t25 = icmp ne ptr %t24, null
  br i1 %t25, label %bb5, label %bb6
bb5:
  %t27 = load ptr, ptr %l34, !tbaa !29
  %t28 = load i64, ptr %t27, !range !{i64 0, i64 12}
  %t30 = icmp eq i64 %t28, 8
  store i1 %t30, ptr %l35, !tbaa !21
  br label %bb6
bb6:
  %t31 = load i1, ptr %l35, !tbaa !21
  br i1 %t31, label %bb7, label %bb8
bb7:
  %t32 = load ptr, ptr %l6, !tbaa !29
  %t34 = getelementptr { i64, [8 x i64] }, ptr %t32, i32 0, i32 1
  %t35 = getelementptr { %"compiler/source:Span", ptr }, ptr %t34, i32 0, i32 1
  %t36 = load ptr, ptr %t35
  store ptr %t36, ptr %l7, !tbaa !29
  br label %bb9
bb8:
  br label %bb20
bb9:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/names:Resolver", ptr %t38, i32 0, i32 0
  %t41 = load ptr, ptr %t40, !tbaa !29
  store ptr %t41, ptr %l41, !tbaa !29
  %t42 = load i64, ptr %l1, !tbaa !24
  store i64 %t42, ptr %l42, !tbaa !24
  %t43 = load ptr, ptr %l7, !tbaa !29
  %t45 = getelementptr %"compiler/ast:TopIf", ptr %t43, i32 0, i32 0
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t48 = icmp eq ptr %t46, null
  br i1 %t48, label %bb10, label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_2f2d72e397ff9e11_581917560c7c3b1d)
  unreachable
bb11:
  br label %bb12
bb12:
  %t50 = load ptr, ptr %l7, !tbaa !29
  %t52 = getelementptr %"compiler/ast:TopIf", ptr %t50, i32 0, i32 0
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t55 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t53)
  store %"compiler/source:Span" %t55, ptr %l48
  br label %bb13
bb13:
  %t56 = getelementptr %"compiler/source:Span", ptr %l48, i32 0, i32 0
  %t57 = load i32, ptr %t56, !tbaa !23
  %t58 = load ptr, ptr %l41, !tbaa !29
  %t59 = load i64, ptr %l42, !tbaa !24
  %t61 = call i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2eChosen(ptr %v0, ptr %t58, i64 %t59, i32 %t57)
  store i64 %t61, ptr %l50
  br label %bb14
bb14:
  %t62 = load i64, ptr %l50, !tbaa !24
  store i64 %t62, ptr %l8, !tbaa !24
  %t63 = load i64, ptr %l8, !tbaa !24
  %t64 = load i64, ptr @G_2ecompiler_2fload_2ePending, !tbaa !24
  %t67 = icmp eq i64 %t63, %t64
  br i1 %t67, label %bb15, label %bb16
bb15:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load i64, ptr %l1, !tbaa !24
  %t71 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ewaitAside(ptr %v0, ptr %v1, ptr %t69, i64 %t70, ptr %t71)
  br label %bb17
bb16:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load i64, ptr %l1, !tbaa !24
  %t77 = load ptr, ptr %l7, !tbaa !29
  %t78 = load i64, ptr %l8, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ecollectIf(ptr %v0, ptr %v1, ptr %t75, i64 %t76, ptr %t77, i64 %t78, i64 0)
  br label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb19
bb19:
  br label %bb97
bb20:
  %t83 = load ptr, ptr %l6, !tbaa !29
  store ptr %t83, ptr %l61, !tbaa !29
  store i1 false, ptr %l62, !tbaa !21
  %t84 = load ptr, ptr %l61, !tbaa !29
  %t85 = icmp ne ptr %t84, null
  br i1 %t85, label %bb21, label %bb22
bb21:
  %t87 = load ptr, ptr %l61, !tbaa !29
  %t88 = load i64, ptr %t87, !range !{i64 0, i64 12}
  %t90 = icmp eq i64 %t88, 0
  store i1 %t90, ptr %l62, !tbaa !21
  br label %bb22
bb22:
  %t91 = load i1, ptr %l62, !tbaa !21
  br i1 %t91, label %bb23, label %bb24
bb23:
  %t92 = load ptr, ptr %l6, !tbaa !29
  %t94 = getelementptr { i64, [8 x i64] }, ptr %t92, i32 0, i32 1
  %t95 = getelementptr { ptr }, ptr %t94, i32 0, i32 0
  %t96 = load ptr, ptr %t95
  store ptr %t96, ptr %l9, !tbaa !29
  br label %bb29
bb24:
  %t98 = load ptr, ptr %l6, !tbaa !29
  store ptr %t98, ptr %l67, !tbaa !29
  store i1 false, ptr %l68, !tbaa !21
  %t99 = load ptr, ptr %l67, !tbaa !29
  %t100 = icmp ne ptr %t99, null
  br i1 %t100, label %bb25, label %bb26
bb25:
  %t102 = load ptr, ptr %l67, !tbaa !29
  %t103 = load i64, ptr %t102, !range !{i64 0, i64 12}
  %t105 = icmp eq i64 %t103, 1
  store i1 %t105, ptr %l68, !tbaa !21
  br label %bb26
bb26:
  %t106 = load i1, ptr %l68, !tbaa !21
  br i1 %t106, label %bb27, label %bb28
bb27:
  %t107 = load ptr, ptr %l6, !tbaa !29
  %t109 = getelementptr { i64, [8 x i64] }, ptr %t107, i32 0, i32 1
  %t110 = getelementptr { ptr }, ptr %t109, i32 0, i32 0
  %t111 = load ptr, ptr %t110
  store ptr %t111, ptr %l9, !tbaa !29
  br label %bb29
bb28:
  br label %bb48
bb29:
  store %olang.scope zeroinitializer, ptr %s6
  %t113 = load ptr, ptr %l9, !tbaa !29
  %t115 = call i1 @compiler_2fast_2ecompiler_2fast_3aFunc_2eIsBuilder(ptr %v1, ptr %t113)
  store i1 %t115, ptr %l74
  br label %bb30
bb30:
  %t116 = load i1, ptr %l74, !tbaa !21
  br i1 %t116, label %bb31, label %bb32
bb31:
  store %olang.scope zeroinitializer, ptr %s7
  %t117 = load ptr, ptr %l0, !tbaa !29
  store ptr %t117, ptr %l75, !tbaa !29
  %t118 = load i64, ptr %l1, !tbaa !24
  store i64 %t118, ptr %l76, !tbaa !24
  %t119 = load ptr, ptr %l9, !tbaa !29
  %t121 = getelementptr %"compiler/ast:Func", ptr %t119, i32 0, i32 2
  %t122 = load i32, ptr %t121, !tbaa !23
  store i32 %t122, ptr %l78, !tbaa !23
  %t123 = load ptr, ptr %l0, !tbaa !29
  store ptr %t123, ptr %l79, !tbaa !29
  %t124 = load i64, ptr %l1, !tbaa !24
  store i64 %t124, ptr %l80, !tbaa !24
  %t125 = load ptr, ptr %l9, !tbaa !29
  %t127 = getelementptr %"compiler/ast:Func", ptr %t125, i32 0, i32 8
  %t128 = load ptr, ptr %t127, !tbaa !29
  %t130 = icmp eq ptr %t128, null
  br i1 %t130, label %bb33, label %bb34
bb32:
  br label %bb39
bb33:
  call void @__olang_check_failed(ptr @olang_loc_217d72d4076f850a_92db47fb0f8e8bb6)
  unreachable
bb34:
  br label %bb35
bb35:
  %t132 = load ptr, ptr %l9, !tbaa !29
  %t134 = getelementptr %"compiler/ast:Func", ptr %t132, i32 0, i32 8
  %t135 = load ptr, ptr %t134, !tbaa !29
  %t137 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t135)
  store %"compiler/source:Span" %t137, ptr %l86
  br label %bb36
bb36:
  %t138 = getelementptr %"compiler/source:Span", ptr %l86, i32 0, i32 1
  %t139 = load i32, ptr %t138, !tbaa !23
  %t140 = load ptr, ptr %l9, !tbaa !29
  %t142 = getelementptr %"compiler/ast:Func", ptr %t140, i32 0, i32 9
  %t143 = load i32, ptr %t142, !tbaa !23
  %t144 = load ptr, ptr %l79, !tbaa !29
  %t145 = load i64, ptr %l80, !tbaa !24
  %t148 = call %"compiler/source:Span" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2enameSpan(ptr %v0, ptr %t144, i64 %t145, i32 %t139, i32 %t143)
  store %"compiler/source:Span" %t148, ptr %l90
  br label %bb37
bb37:
  %t149 = load ptr, ptr %l75, !tbaa !29
  %t150 = load i64, ptr %l76, !tbaa !24
  %t151 = load i32, ptr %l78, !tbaa !23
  %t152 = load %"compiler/source:Span", ptr %l90
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eaddValue(ptr %v0, ptr %s7, ptr %t149, i64 %t150, i32 %t151, %"compiler/source:Span" %t152, i1 false, i1 true, i1 true, ptr null)
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s6)
  br label %bb98
bb39:
  %t153 = load ptr, ptr %l9, !tbaa !29
  %t155 = getelementptr %"compiler/ast:Func", ptr %t153, i32 0, i32 1
  %t156 = load ptr, ptr %t155, !tbaa !29
  %t158 = icmp eq ptr %t156, null
  %t160 = xor i1 %t158, true
  br i1 %t160, label %bb40, label %bb41
bb40:
  %t162 = load ptr, ptr %l9, !tbaa !29
  %t164 = getelementptr %"compiler/ast:Func", ptr %t162, i32 0, i32 1
  %t165 = load ptr, ptr %t164, !tbaa !29
  %t167 = icmp eq ptr %t165, null
  br i1 %t167, label %bb42, label %bb43
bb41:
  %t169 = load ptr, ptr %l9, !tbaa !29
  %t171 = getelementptr %"compiler/ast:Func", ptr %t169, i32 0, i32 0
  %t172 = getelementptr %"compiler/source:Span", ptr %t171, i32 0, i32 0
  %t173 = load i32, ptr %t172, !tbaa !23
  store i32 %t173, ptr %l95, !tbaa !23
  br label %bb45
bb42:
  call void @__olang_check_failed(ptr @olang_loc_cbd8c9ec4d2c560b_31762469b8343a67)
  unreachable
bb43:
  br label %bb44
bb44:
  %t175 = load ptr, ptr %l9, !tbaa !29
  %t177 = getelementptr %"compiler/ast:Func", ptr %t175, i32 0, i32 1
  %t178 = load ptr, ptr %t177, !tbaa !29
  %t181 = getelementptr %"compiler/ast:Param", ptr %t178, i32 0, i32 0
  %t182 = getelementptr %"compiler/source:Span", ptr %t181, i32 0, i32 1
  %t183 = load i32, ptr %t182, !tbaa !23
  store i32 %t183, ptr %l95, !tbaa !23
  br label %bb45
bb45:
  %t185 = load i32, ptr %l95, !tbaa !23
  %t186 = load ptr, ptr %l0, !tbaa !29
  store ptr %t186, ptr %l105, !tbaa !29
  %t187 = load i64, ptr %l1, !tbaa !24
  store i64 %t187, ptr %l106, !tbaa !24
  %t188 = load ptr, ptr %l9, !tbaa !29
  %t190 = getelementptr %"compiler/ast:Func", ptr %t188, i32 0, i32 2
  %t191 = load i32, ptr %t190, !tbaa !23
  store i32 %t191, ptr %l108, !tbaa !23
  %t192 = load ptr, ptr %l0, !tbaa !29
  %t193 = load i64, ptr %l1, !tbaa !24
  %t195 = load ptr, ptr %l9, !tbaa !29
  %t197 = getelementptr %"compiler/ast:Func", ptr %t195, i32 0, i32 2
  %t198 = load i32, ptr %t197, !tbaa !23
  %t203 = call %"compiler/source:Span" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2enameSpan(ptr %v0, ptr %t192, i64 %t193, i32 %t185, i32 %t198)
  store %"compiler/source:Span" %t203, ptr %l114
  br label %bb46
bb46:
  %t204 = load ptr, ptr %l9, !tbaa !29
  %t206 = getelementptr %"compiler/ast:Func", ptr %t204, i32 0, i32 1
  %t207 = load ptr, ptr %t206, !tbaa !29
  %t209 = icmp eq ptr %t207, null
  %t211 = xor i1 %t209, true
  %t212 = load ptr, ptr %l105, !tbaa !29
  %t213 = load i64, ptr %l106, !tbaa !24
  %t214 = load i32, ptr %l108, !tbaa !23
  %t215 = load %"compiler/source:Span", ptr %l114
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eaddValue(ptr %v0, ptr %s6, ptr %t212, i64 %t213, i32 %t214, %"compiler/source:Span" %t215, i1 false, i1 true, i1 %t211, ptr null)
  br label %bb47
bb47:
  call void @__olang_scope_close(ptr %s6)
  br label %bb97
bb48:
  %t217 = load ptr, ptr %l6, !tbaa !29
  store ptr %t217, ptr %l119, !tbaa !29
  store i1 false, ptr %l120, !tbaa !21
  %t218 = load ptr, ptr %l119, !tbaa !29
  %t219 = icmp ne ptr %t218, null
  br i1 %t219, label %bb49, label %bb50
bb49:
  %t221 = load ptr, ptr %l119, !tbaa !29
  %t222 = load i64, ptr %t221, !range !{i64 0, i64 12}
  %t224 = icmp eq i64 %t222, 2
  store i1 %t224, ptr %l120, !tbaa !21
  br label %bb50
bb50:
  %t225 = load i1, ptr %l120, !tbaa !21
  br i1 %t225, label %bb51, label %bb52
bb51:
  %t226 = load ptr, ptr %l6, !tbaa !29
  %t228 = getelementptr { i64, [8 x i64] }, ptr %t226, i32 0, i32 1
  %t229 = getelementptr { %"compiler/source:Span", ptr }, ptr %t228, i32 0, i32 0
  %t230 = load %"compiler/source:Span", ptr %t229
  store %"compiler/source:Span" %t230, ptr %l11
  %t232 = load ptr, ptr %l6, !tbaa !29
  %t234 = getelementptr { i64, [8 x i64] }, ptr %t232, i32 0, i32 1
  %t235 = getelementptr { %"compiler/source:Span", ptr }, ptr %t234, i32 0, i32 1
  %t236 = load ptr, ptr %t235
  store ptr %t236, ptr %l12, !tbaa !29
  br label %bb53
bb52:
  br label %bb56
bb53:
  %t238 = load ptr, ptr %l0, !tbaa !29
  store ptr %t238, ptr %l127, !tbaa !29
  %t239 = load i64, ptr %l1, !tbaa !24
  store i64 %t239, ptr %l128, !tbaa !24
  %t240 = load ptr, ptr %l12, !tbaa !29
  %t242 = getelementptr %"compiler/ast:TypeDecl", ptr %t240, i32 0, i32 0
  %t243 = load i32, ptr %t242, !tbaa !23
  store i32 %t243, ptr %l130, !tbaa !23
  %t244 = load ptr, ptr %l0, !tbaa !29
  %t245 = load i64, ptr %l1, !tbaa !24
  %t246 = getelementptr %"compiler/source:Span", ptr %l11, i32 0, i32 0
  %t247 = load i32, ptr %t246, !tbaa !23
  %t248 = load ptr, ptr %l12, !tbaa !29
  %t250 = getelementptr %"compiler/ast:TypeDecl", ptr %t248, i32 0, i32 0
  %t251 = load i32, ptr %t250, !tbaa !23
  %t256 = call %"compiler/source:Span" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2enameSpan(ptr %v0, ptr %t244, i64 %t245, i32 %t247, i32 %t251)
  store %"compiler/source:Span" %t256, ptr %l136
  br label %bb54
bb54:
  %t257 = load ptr, ptr %l12, !tbaa !29
  %t259 = load ptr, ptr %l127, !tbaa !29
  %t260 = load i64, ptr %l128, !tbaa !24
  %t261 = load i32, ptr %l130, !tbaa !23
  %t262 = load %"compiler/source:Span", ptr %l136
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eaddType(ptr %v0, ptr %v1, ptr %t259, i64 %t260, i32 %t261, %"compiler/source:Span" %t262, ptr %t257)
  br label %bb55
bb55:
  br label %bb97
bb56:
  %t264 = load ptr, ptr %l6, !tbaa !29
  store ptr %t264, ptr %l139, !tbaa !29
  store i1 false, ptr %l140, !tbaa !21
  %t265 = load ptr, ptr %l139, !tbaa !29
  %t266 = icmp ne ptr %t265, null
  br i1 %t266, label %bb57, label %bb58
bb57:
  %t268 = load ptr, ptr %l139, !tbaa !29
  %t269 = load i64, ptr %t268, !range !{i64 0, i64 12}
  %t271 = icmp eq i64 %t269, 6
  store i1 %t271, ptr %l140, !tbaa !21
  br label %bb58
bb58:
  %t272 = load i1, ptr %l140, !tbaa !21
  br i1 %t272, label %bb59, label %bb60
bb59:
  %t273 = load ptr, ptr %l6, !tbaa !29
  %t275 = getelementptr { i64, [8 x i64] }, ptr %t273, i32 0, i32 1
  %t276 = getelementptr { %"compiler/source:Span", i32, { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t275, i32 0, i32 0
  %t277 = load %"compiler/source:Span", ptr %t276
  store %"compiler/source:Span" %t277, ptr %l13
  %t279 = load ptr, ptr %l6, !tbaa !29
  %t281 = getelementptr { i64, [8 x i64] }, ptr %t279, i32 0, i32 1
  %t282 = getelementptr { %"compiler/source:Span", i32, { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t281, i32 0, i32 1
  %t283 = load i32, ptr %t282
  store i32 %t283, ptr %l14, !tbaa !23
  %t285 = load ptr, ptr %l6, !tbaa !29
  %t287 = getelementptr { i64, [8 x i64] }, ptr %t285, i32 0, i32 1
  %t288 = getelementptr { %"compiler/source:Span", i32, { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t287, i32 0, i32 4
  %t289 = load { i64, ptr }, ptr %t288
  store { i64, ptr } %t289, ptr %l15, !tbaa !27
  br label %bb61
bb60:
  br label %bb65
bb61:
  %t291 = load ptr, ptr %l0, !tbaa !29
  store ptr %t291, ptr %l149, !tbaa !29
  %t292 = load i64, ptr %l1, !tbaa !24
  store i64 %t292, ptr %l150, !tbaa !24
  %t293 = load i32, ptr %l14, !tbaa !23
  store i32 %t293, ptr %l151, !tbaa !23
  %t294 = load ptr, ptr %l0, !tbaa !29
  %t295 = load i64, ptr %l1, !tbaa !24
  %t296 = getelementptr %"compiler/source:Span", ptr %l13, i32 0, i32 0
  %t297 = load i32, ptr %t296, !tbaa !23
  %t298 = load i32, ptr %l14, !tbaa !23
  %t303 = call %"compiler/source:Span" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2enameSpan(ptr %v0, ptr %t294, i64 %t295, i32 %t297, i32 %t298)
  store %"compiler/source:Span" %t303, ptr %l156
  br label %bb62
bb62:
  %t304 = load ptr, ptr %l149, !tbaa !29
  %t305 = load i64, ptr %l150, !tbaa !24
  %t306 = load i32, ptr %l151, !tbaa !23
  %t307 = load %"compiler/source:Span", ptr %l156
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eaddType(ptr %v0, ptr %v0, ptr %t304, i64 %t305, i32 %t306, %"compiler/source:Span" %t307, ptr null)
  br label %bb63
bb63:
  %t308 = load ptr, ptr %l0, !tbaa !29
  %t309 = load i64, ptr %l1, !tbaa !24
  %t310 = load %"compiler/source:Span", ptr %l13
  %t311 = load i32, ptr %l14, !tbaa !23
  %t312 = load { i64, ptr }, ptr %l15, !tbaa !27
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2epayloadEnum(ptr %v0, ptr %v1, ptr %t308, i64 %t309, %"compiler/source:Span" %t310, i32 %t311, { i64, ptr } %t312)
  br label %bb64
bb64:
  br label %bb97
bb65:
  %t318 = load ptr, ptr %l6, !tbaa !29
  store ptr %t318, ptr %l162, !tbaa !29
  store i1 false, ptr %l163, !tbaa !21
  %t319 = load ptr, ptr %l162, !tbaa !29
  %t320 = icmp ne ptr %t319, null
  br i1 %t320, label %bb66, label %bb67
bb66:
  %t322 = load ptr, ptr %l162, !tbaa !29
  %t323 = load i64, ptr %t322, !range !{i64 0, i64 12}
  %t325 = icmp eq i64 %t323, 4
  store i1 %t325, ptr %l163, !tbaa !21
  br label %bb67
bb67:
  %t326 = load i1, ptr %l163, !tbaa !21
  br i1 %t326, label %bb68, label %bb69
bb68:
  %t327 = load ptr, ptr %l6, !tbaa !29
  %t329 = getelementptr { i64, [8 x i64] }, ptr %t327, i32 0, i32 1
  %t330 = getelementptr { %"compiler/source:Span", ptr }, ptr %t329, i32 0, i32 1
  %t331 = load ptr, ptr %t330
  store ptr %t331, ptr %l16, !tbaa !29
  br label %bb70
bb69:
  br label %bb85
bb70:
  store i64 0, ptr %l17, !tbaa !24
  %t333 = load ptr, ptr %l16, !tbaa !29
  %t335 = getelementptr %"compiler/ast:VarDecl", ptr %t333, i32 0, i32 0
  %t336 = load { i64, ptr }, ptr %t335, !tbaa !27
  %t338 = extractvalue { i64, ptr } %t336, 0
  store i64 %t338, ptr %l18, !tbaa !24
  store i64 1, ptr %l19, !tbaa !24
  %t340 = load i64, ptr %l18, !tbaa !24
  %t341 = load i64, ptr %l17, !tbaa !24
  %t344 = icmp sgt i64 %t340, %t341
  br i1 %t344, label %bb71, label %bb72
bb71:
  %t346 = load i64, ptr %l19, !tbaa !24
  %t348 = icmp sgt i64 %t346, 0
  br i1 %t348, label %bb73, label %bb74
bb72:
  store i64 0, ptr %l174, !tbaa !24
  br label %bb76
bb73:
  %t350 = load i64, ptr %l18, !tbaa !24
  %t351 = load i64, ptr %l17, !tbaa !24
  %t354 = sub i64 %t350, %t351
  %t355 = load i64, ptr %l19, !tbaa !24
  %t358 = add i64 %t354, %t355
  %t360 = sub i64 %t358, 1
  %t361 = load i64, ptr %l19, !tbaa !24
  %t364 = sdiv i64 %t360, %t361
  store i64 %t364, ptr %l177, !tbaa !24
  br label %bb75
bb74:
  store i64 0, ptr %l177, !tbaa !24
  br label %bb75
bb75:
  %t366 = load i64, ptr %l177, !tbaa !24
  store i64 %t366, ptr %l174, !tbaa !24
  br label %bb76
bb76:
  %t367 = load i64, ptr %l174, !tbaa !24
  store i64 %t367, ptr %l20, !tbaa !24
  store i64 0, ptr %l21, !tbaa !24
  br label %bb77
bb77:
  %t368 = load i64, ptr %l21, !tbaa !24
  %t369 = load i64, ptr %l20, !tbaa !24
  %t372 = icmp slt i64 %t368, %t369
  %t374 = xor i1 %t372, true
  br i1 %t374, label %bb78, label %bb79
bb78:
  br label %bb84
bb79:
  br label %bb80
bb80:
  %t376 = load i64, ptr %l17, !tbaa !24
  %t377 = load i64, ptr %l21, !tbaa !24
  %t378 = load i64, ptr %l19, !tbaa !24
  %t381 = mul i64 %t377, %t378
  %t384 = add i64 %t376, %t381
  store i64 %t384, ptr %l22, !tbaa !24
  %t386 = load ptr, ptr %l0, !tbaa !29
  store ptr %t386, ptr %l195, !tbaa !29
  %t387 = load i64, ptr %l1, !tbaa !24
  store i64 %t387, ptr %l196, !tbaa !24
  %t388 = load ptr, ptr %l16, !tbaa !29
  %t390 = getelementptr %"compiler/ast:VarDecl", ptr %t388, i32 0, i32 0
  %t391 = load { i64, ptr }, ptr %t390, !tbaa !27
  store { i64, ptr } %t391, ptr %l198, !tbaa !27
  %t392 = load i64, ptr %l22, !tbaa !24
  %t394 = getelementptr { i64, ptr }, ptr %l198, i32 0, i32 1
  %t395 = load ptr, ptr %t394, !tbaa !27
  %t396 = getelementptr i32, ptr %t395, i64 %t392
  %t397 = load i32, ptr %t396, !tbaa !33
  store i32 %t397, ptr %l200, !tbaa !23
  %t398 = load ptr, ptr %l16, !tbaa !29
  %t400 = getelementptr %"compiler/ast:VarDecl", ptr %t398, i32 0, i32 1
  %t401 = load { i64, ptr }, ptr %t400, !tbaa !27
  store { i64, ptr } %t401, ptr %l202, !tbaa !27
  %t402 = load i64, ptr %l22, !tbaa !24
  %t404 = getelementptr { i64, ptr }, ptr %l202, i32 0, i32 1
  %t405 = load ptr, ptr %t404, !tbaa !27
  %t406 = getelementptr %"compiler/source:Span", ptr %t405, i64 %t402
  %t407 = load %"compiler/source:Span", ptr %t406
  store %"compiler/source:Span" %t407, ptr %l204
  %t408 = load ptr, ptr %l16, !tbaa !29
  %t410 = getelementptr %"compiler/ast:VarDecl", ptr %t408, i32 0, i32 2
  %t411 = load ptr, ptr %t410, !tbaa !29
  %t413 = call i1 @compiler_2fnames_2eWrittenMut(ptr %v1, ptr %t411)
  store i1 %t413, ptr %l207
  br label %bb81
bb81:
  %t414 = load ptr, ptr %l16, !tbaa !29
  %t416 = load ptr, ptr %l195, !tbaa !29
  %t417 = load i64, ptr %l196, !tbaa !24
  %t418 = load i32, ptr %l200, !tbaa !23
  %t419 = load %"compiler/source:Span", ptr %l204
  %t420 = load i1, ptr %l207, !tbaa !21
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eaddValue(ptr %v0, ptr %v1, ptr %t416, i64 %t417, i32 %t418, %"compiler/source:Span" %t419, i1 %t420, i1 false, i1 false, ptr %t414)
  br label %bb82
bb82:
  br label %bb83
bb83:
  %t422 = load i64, ptr %l21, !tbaa !24
  %t425 = add i64 %t422, 1
  store i64 %t425, ptr %l21, !tbaa !24
  br label %bb77
bb84:
  br label %bb97
bb85:
  %t427 = load ptr, ptr %l6, !tbaa !29
  store ptr %t427, ptr %l213, !tbaa !29
  store i1 false, ptr %l214, !tbaa !21
  %t428 = load ptr, ptr %l213, !tbaa !29
  %t429 = icmp ne ptr %t428, null
  br i1 %t429, label %bb86, label %bb87
bb86:
  %t431 = load ptr, ptr %l213, !tbaa !29
  %t432 = load i64, ptr %t431, !range !{i64 0, i64 12}
  %t434 = icmp eq i64 %t432, 11
  store i1 %t434, ptr %l214, !tbaa !21
  br label %bb87
bb87:
  %t435 = load i1, ptr %l214, !tbaa !21
  br i1 %t435, label %bb88, label %bb89
bb88:
  %t436 = load ptr, ptr %l6, !tbaa !29
  %t438 = getelementptr { i64, [8 x i64] }, ptr %t436, i32 0, i32 1
  %t439 = getelementptr { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr } }, ptr %t438, i32 0, i32 2
  %t440 = load { i64, ptr }, ptr %t439
  store { i64, ptr } %t440, ptr %l23, !tbaa !27
  br label %bb90
bb89:
  br label %bb92
bb90:
  %t442 = load ptr, ptr %l0, !tbaa !29
  %t443 = load i64, ptr %l1, !tbaa !24
  %t444 = load { i64, ptr }, ptr %l23, !tbaa !27
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ecollect(ptr %v0, ptr %v1, ptr %t442, i64 %t443, { i64, ptr } %t444)
  br label %bb91
bb91:
  br label %bb97
bb92:
  br i1 true, label %bb93, label %bb94
bb93:
  br label %bb95
bb94:
  br label %bb96
bb95:
  br label %bb97
bb96:
  call void @__olang_check_failed(ptr @olang_loc_40bcba17b2bf17b3_8a9927ec4a716c7f)
  unreachable
bb97:
  br label %bb98
bb98:
  %t448 = load i64, ptr %l4, !tbaa !24
  %t451 = add i64 %t448, 1
  store i64 %t451, ptr %l4, !tbaa !24
  br label %bb1
bb99:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ecollectIf(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, i64 %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l8 = alloca i1
  %l18 = alloca ptr
  %l19 = alloca i64
  %l31 = alloca ptr
  %l32 = alloca i64
  %l45 = alloca i1
  %l50 = alloca i1
  %l60 = alloca ptr
  %l61 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i64 %a3, ptr %l3
  store i64 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l3, !tbaa !24
  %t2 = load i64, ptr %l4, !tbaa !24
  %t5 = icmp eq i64 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load ptr, ptr %l2, !tbaa !29
  %t9 = getelementptr %"compiler/ast:TopIf", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = icmp eq ptr %t10, null
  br i1 %t12, label %bb3, label %bb4
bb2:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb6
bb3:
  call void @__olang_check_failed(ptr @olang_loc_60cefae456c43b96_68bed78927cbacfa)
  unreachable
bb4:
  br label %bb5
bb5:
  %t14 = load ptr, ptr %l2, !tbaa !29
  %t16 = getelementptr %"compiler/ast:TopIf", ptr %t14, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t20 = getelementptr %"compiler/ast:TopBranch", ptr %t17, i32 0, i32 1
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t25 = icmp sgt i64 %t23, 0
  store i1 %t25, ptr %l8, !tbaa !21
  br label %bb6
bb6:
  %t27 = load i1, ptr %l8, !tbaa !21
  br i1 %t27, label %bb7, label %bb8
bb7:
  %t28 = load ptr, ptr %l0, !tbaa !29
  store ptr %t28, ptr %l18, !tbaa !29
  %t29 = load i64, ptr %l1, !tbaa !24
  store i64 %t29, ptr %l19, !tbaa !24
  %t30 = load ptr, ptr %l2, !tbaa !29
  %t32 = getelementptr %"compiler/ast:TopIf", ptr %t30, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t35 = icmp eq ptr %t33, null
  br i1 %t35, label %bb9, label %bb10
bb8:
  br label %bb13
bb9:
  call void @__olang_check_failed(ptr @olang_loc_60cefae456c43b96_68bed78927cbacfa)
  unreachable
bb10:
  br label %bb11
bb11:
  %t37 = load ptr, ptr %l2, !tbaa !29
  %t39 = getelementptr %"compiler/ast:TopIf", ptr %t37, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t43 = getelementptr %"compiler/ast:TopBranch", ptr %t40, i32 0, i32 1
  %t44 = load { i64, ptr }, ptr %t43, !tbaa !27
  %t45 = load ptr, ptr %l18, !tbaa !29
  %t46 = load i64, ptr %l19, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ecollect(ptr %v0, ptr %v1, ptr %t45, i64 %t46, { i64, ptr } %t44)
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t48 = load ptr, ptr %l2, !tbaa !29
  %t50 = getelementptr %"compiler/ast:TopIf", ptr %t48, i32 0, i32 2
  %t51 = load ptr, ptr %t50, !tbaa !29
  %t53 = icmp eq ptr %t51, null
  %t55 = xor i1 %t53, true
  br i1 %t55, label %bb14, label %bb15
bb14:
  %t57 = load ptr, ptr %l0, !tbaa !29
  store ptr %t57, ptr %l31, !tbaa !29
  %t58 = load i64, ptr %l1, !tbaa !24
  store i64 %t58, ptr %l32, !tbaa !24
  %t59 = load ptr, ptr %l2, !tbaa !29
  %t61 = getelementptr %"compiler/ast:TopIf", ptr %t59, i32 0, i32 2
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = icmp eq ptr %t62, null
  br i1 %t64, label %bb16, label %bb17
bb15:
  br label %bb20
bb16:
  call void @__olang_check_failed(ptr @olang_loc_e46cc2517056eb7d_41b560901e6ccb81)
  unreachable
bb17:
  br label %bb18
bb18:
  %t66 = load ptr, ptr %l2, !tbaa !29
  %t68 = getelementptr %"compiler/ast:TopIf", ptr %t66, i32 0, i32 2
  %t69 = load ptr, ptr %t68, !tbaa !29
  %t70 = load i64, ptr %l3, !tbaa !24
  %t71 = load i64, ptr %l4, !tbaa !24
  %t73 = add i64 %t71, 1
  %t74 = load ptr, ptr %l31, !tbaa !29
  %t75 = load i64, ptr %l32, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ecollectIf(ptr %v0, ptr %v1, ptr %t74, i64 %t75, ptr %t69, i64 %t70, i64 %t73)
  br label %bb19
bb19:
  br label %bb20
bb20:
  %t79 = load ptr, ptr %l2, !tbaa !29
  %t81 = getelementptr %"compiler/ast:TopIf", ptr %t79, i32 0, i32 3
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t84 = icmp eq ptr %t82, null
  %t86 = xor i1 %t84, true
  br i1 %t86, label %bb21, label %bb22
bb21:
  %t88 = load i64, ptr %l3, !tbaa !24
  %t89 = load i64, ptr %l4, !tbaa !24
  %t91 = add i64 %t89, 1
  %t94 = icmp eq i64 %t88, %t91
  store i1 %t94, ptr %l45, !tbaa !21
  br label %bb23
bb22:
  store i1 false, ptr %l45, !tbaa !21
  br label %bb23
bb23:
  %t96 = load i1, ptr %l45, !tbaa !21
  br i1 %t96, label %bb24, label %bb25
bb24:
  %t97 = load ptr, ptr %l2, !tbaa !29
  %t99 = getelementptr %"compiler/ast:TopIf", ptr %t97, i32 0, i32 3
  %t100 = load ptr, ptr %t99, !tbaa !29
  %t102 = icmp eq ptr %t100, null
  br i1 %t102, label %bb26, label %bb27
bb25:
  store i1 false, ptr %l50, !tbaa !21
  br label %bb29
bb26:
  call void @__olang_check_failed(ptr @olang_loc_8bede4e7118dcaa8_b7291399ad78424c)
  unreachable
bb27:
  br label %bb28
bb28:
  %t104 = load ptr, ptr %l2, !tbaa !29
  %t106 = getelementptr %"compiler/ast:TopIf", ptr %t104, i32 0, i32 3
  %t107 = load ptr, ptr %t106, !tbaa !29
  %t110 = getelementptr %"compiler/ast:TopBranch", ptr %t107, i32 0, i32 1
  %t111 = load { i64, ptr }, ptr %t110, !tbaa !27
  %t113 = extractvalue { i64, ptr } %t111, 0
  %t115 = icmp sgt i64 %t113, 0
  store i1 %t115, ptr %l50, !tbaa !21
  br label %bb29
bb29:
  %t117 = load i1, ptr %l50, !tbaa !21
  br i1 %t117, label %bb30, label %bb31
bb30:
  %t118 = load ptr, ptr %l0, !tbaa !29
  store ptr %t118, ptr %l60, !tbaa !29
  %t119 = load i64, ptr %l1, !tbaa !24
  store i64 %t119, ptr %l61, !tbaa !24
  %t120 = load ptr, ptr %l2, !tbaa !29
  %t122 = getelementptr %"compiler/ast:TopIf", ptr %t120, i32 0, i32 3
  %t123 = load ptr, ptr %t122, !tbaa !29
  %t125 = icmp eq ptr %t123, null
  br i1 %t125, label %bb32, label %bb33
bb31:
  br label %bb36
bb32:
  call void @__olang_check_failed(ptr @olang_loc_8bede4e7118dcaa8_b7291399ad78424c)
  unreachable
bb33:
  br label %bb34
bb34:
  %t127 = load ptr, ptr %l2, !tbaa !29
  %t129 = getelementptr %"compiler/ast:TopIf", ptr %t127, i32 0, i32 3
  %t130 = load ptr, ptr %t129, !tbaa !29
  %t133 = getelementptr %"compiler/ast:TopBranch", ptr %t130, i32 0, i32 1
  %t134 = load { i64, ptr }, ptr %t133, !tbaa !27
  %t135 = load ptr, ptr %l60, !tbaa !29
  %t136 = load i64, ptr %l61, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ecollect(ptr %v0, ptr %v1, ptr %t135, i64 %t136, { i64, ptr } %t134)
  br label %bb35
bb35:
  br label %bb36
bb36:
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/cond:Decision" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2edecideLocal(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca i32
  %l15 = alloca ptr
  %l28 = alloca i64
  %l30 = alloca i64
  %l35 = alloca i32
  %l56 = alloca i64
  %l58 = alloca i64
  %l63 = alloca i32
  %l81 = alloca { i64, ptr }
  %l84 = alloca ptr
  %l93 = alloca %"compiler/cond:Eval"
  %l97 = alloca %"compiler/cond:Decision"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/cond:Decision"
  %t176 = alloca %"compiler/cond:Eval", align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/names:Resolver", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/load:Loader", ptr %t4, i32 0, i32 10
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/names:Resolver", ptr %t7, i32 0, i32 7
  %t10 = load i64, ptr %t9, !tbaa !24
  %t13 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t6, i64 %t10)
  store ptr %t13, ptr %l15
  br label %bb1
bb1:
  %t14 = load ptr, ptr %l15, !tbaa !29
  store ptr %t14, ptr %l2, !tbaa !29
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/names:Resolver", ptr %t15, i32 0, i32 0
  %t18 = load ptr, ptr %t17, !tbaa !29
  %t19 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fload_2ecompiler_2fload_3aLoader_2eCondParser(ptr %v0, ptr %v0, ptr %t18, ptr %t19)
  br label %bb2
bb2:
  %t22 = load ptr, ptr %l2, !tbaa !29
  %t24 = getelementptr %"compiler/load:Module", ptr %t22, i32 0, i32 26
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = icmp eq ptr %t25, null
  br i1 %t27, label %bb3, label %bb4
bb3:
  call void @__olang_check_failed(ptr @olang_loc_24d74d734bb1c47c_a76eb538bdec4e08)
  unreachable
bb4:
  br label %bb5
bb5:
  %t29 = load ptr, ptr %l2, !tbaa !29
  %t31 = getelementptr %"compiler/load:Module", ptr %t29, i32 0, i32 26
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t35 = getelementptr %"compiler/cond:Scope", ptr %t32, i32 0, i32 2
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eClear_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t35)
  br label %bb6
bb6:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/names:Resolver", ptr %t37, i32 0, i32 11
  store ptr %t39, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb7
bb7:
  %t41 = load i64, ptr %l4, !tbaa !24
  store i64 %t41, ptr %l28, !tbaa !24
  %t42 = load ptr, ptr %l3, !tbaa !29
  %t44 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t42)
  store i64 %t44, ptr %l30
  br label %bb8
bb8:
  %t45 = load i64, ptr %l28, !tbaa !24
  %t46 = load i64, ptr %l30, !tbaa !24
  %t47 = icmp slt i64 %t45, %t46
  %t49 = xor i1 %t47, true
  br i1 %t49, label %bb9, label %bb10
bb9:
  br label %bb18
bb10:
  br label %bb11
bb11:
  %t51 = load ptr, ptr %l3, !tbaa !29
  %t52 = load i64, ptr %l4, !tbaa !24
  %t55 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eAt_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t51, i64 %t52)
  store i32 %t55, ptr %l35
  br label %bb12
bb12:
  %t56 = load i32, ptr %l35, !tbaa !23
  store i32 %t56, ptr %l5, !tbaa !23
  %t57 = load ptr, ptr %l2, !tbaa !29
  %t59 = getelementptr %"compiler/load:Module", ptr %t57, i32 0, i32 26
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t62 = icmp eq ptr %t60, null
  br i1 %t62, label %bb13, label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_9d7678395160f3eb_aad45a645d2f7c27)
  unreachable
bb14:
  br label %bb15
bb15:
  %t64 = load ptr, ptr %l2, !tbaa !29
  %t66 = getelementptr %"compiler/load:Module", ptr %t64, i32 0, i32 26
  %t67 = load ptr, ptr %t66, !tbaa !29
  %t70 = getelementptr %"compiler/cond:Scope", ptr %t67, i32 0, i32 2
  %t71 = load i32, ptr %l5, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t70, i32 %t71)
  br label %bb16
bb16:
  br label %bb17
bb17:
  %t74 = load i64, ptr %l4, !tbaa !24
  %t77 = add i64 %t74, 1
  store i64 %t77, ptr %l4, !tbaa !24
  br label %bb7
bb18:
  %t79 = load ptr, ptr %l2, !tbaa !29
  %t81 = getelementptr %"compiler/load:Module", ptr %t79, i32 0, i32 26
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t84 = icmp eq ptr %t82, null
  br i1 %t84, label %bb19, label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_606655a3d6c9146a_8558b81c90083f76)
  unreachable
bb20:
  br label %bb21
bb21:
  %t86 = load ptr, ptr %l2, !tbaa !29
  %t88 = getelementptr %"compiler/load:Module", ptr %t86, i32 0, i32 26
  %t89 = load ptr, ptr %t88, !tbaa !29
  %t92 = getelementptr %"compiler/cond:Scope", ptr %t89, i32 0, i32 3
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eClear_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t92)
  br label %bb22
bb22:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/names:Resolver", ptr %t94, i32 0, i32 12
  store ptr %t96, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  br label %bb23
bb23:
  %t98 = load i64, ptr %l7, !tbaa !24
  store i64 %t98, ptr %l56, !tbaa !24
  %t99 = load ptr, ptr %l6, !tbaa !29
  %t101 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t99)
  store i64 %t101, ptr %l58
  br label %bb24
bb24:
  %t102 = load i64, ptr %l56, !tbaa !24
  %t103 = load i64, ptr %l58, !tbaa !24
  %t104 = icmp slt i64 %t102, %t103
  %t106 = xor i1 %t104, true
  br i1 %t106, label %bb25, label %bb26
bb25:
  br label %bb34
bb26:
  br label %bb27
bb27:
  %t108 = load ptr, ptr %l6, !tbaa !29
  %t109 = load i64, ptr %l7, !tbaa !24
  %t112 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eAt_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t108, i64 %t109)
  store i32 %t112, ptr %l63
  br label %bb28
bb28:
  %t113 = load i32, ptr %l63, !tbaa !23
  store i32 %t113, ptr %l8, !tbaa !23
  %t114 = load ptr, ptr %l2, !tbaa !29
  %t116 = getelementptr %"compiler/load:Module", ptr %t114, i32 0, i32 26
  %t117 = load ptr, ptr %t116, !tbaa !29
  %t119 = icmp eq ptr %t117, null
  br i1 %t119, label %bb29, label %bb30
bb29:
  call void @__olang_check_failed(ptr @olang_loc_ca6a9ef64ba15071_9b37ed8e39b0c3dd)
  unreachable
bb30:
  br label %bb31
bb31:
  %t121 = load ptr, ptr %l2, !tbaa !29
  %t123 = getelementptr %"compiler/load:Module", ptr %t121, i32 0, i32 26
  %t124 = load ptr, ptr %t123, !tbaa !29
  %t127 = getelementptr %"compiler/cond:Scope", ptr %t124, i32 0, i32 3
  %t128 = load i32, ptr %l8, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t127, i32 %t128)
  br label %bb32
bb32:
  br label %bb33
bb33:
  %t131 = load i64, ptr %l7, !tbaa !24
  %t134 = add i64 %t131, 1
  store i64 %t134, ptr %l7, !tbaa !24
  br label %bb23
bb34:
  %t136 = load ptr, ptr %l2, !tbaa !29
  %t138 = getelementptr %"compiler/load:Module", ptr %t136, i32 0, i32 6
  %t139 = load ptr, ptr %t138, !tbaa !29
  %t141 = icmp eq ptr %t139, null
  br i1 %t141, label %bb35, label %bb36
bb35:
  call void @__olang_check_failed(ptr @olang_loc_cbc626cb57e27c38_a58d4f769ca64c8c)
  unreachable
bb36:
  br label %bb37
bb37:
  %t143 = load ptr, ptr %l2, !tbaa !29
  %t145 = getelementptr %"compiler/load:Module", ptr %t143, i32 0, i32 6
  %t146 = load ptr, ptr %t145, !tbaa !29
  %t149 = getelementptr %"compiler/source:Source", ptr %t146, i32 0, i32 1
  %t150 = load { i64, ptr }, ptr %t149, !tbaa !27
  store { i64, ptr } %t150, ptr %l81, !tbaa !27
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t153 = getelementptr %"compiler/names:Resolver", ptr %t151, i32 0, i32 0
  %t154 = load ptr, ptr %t153, !tbaa !29
  %t156 = getelementptr %"compiler/load:Loader", ptr %t154, i32 0, i32 3
  %t157 = load ptr, ptr %t156, !tbaa !29
  store ptr %t157, ptr %l84, !tbaa !29
  %t158 = load ptr, ptr %l2, !tbaa !29
  %t160 = getelementptr %"compiler/load:Module", ptr %t158, i32 0, i32 26
  %t161 = load ptr, ptr %t160, !tbaa !29
  %t163 = icmp eq ptr %t161, null
  br i1 %t163, label %bb38, label %bb39
bb38:
  call void @__olang_check_failed(ptr @olang_loc_cbc626cb57e27c38_a58d4f769ca64c8c)
  unreachable
bb39:
  br label %bb40
bb40:
  %t165 = load ptr, ptr %l2, !tbaa !29
  %t167 = getelementptr %"compiler/load:Module", ptr %t165, i32 0, i32 26
  %t168 = load ptr, ptr %t167, !tbaa !29
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t171 = getelementptr %"compiler/names:Resolver", ptr %t169, i32 0, i32 0
  %t172 = load ptr, ptr %t171, !tbaa !29
  %t174 = getelementptr %"compiler/load:Loader", ptr %t172, i32 0, i32 1
  %t175 = load ptr, ptr %t174, !tbaa !29
  %t177 = load { i64, ptr }, ptr %l81, !tbaa !27
  %t178 = load ptr, ptr %l84, !tbaa !29
  call void @compiler_2fcond_3aEval_2ector(ptr %t176, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %s0, { i64, ptr } %t177, ptr %t178, ptr %t168, ptr %t175)
  call void @llvm.memmove.p0.p0.i64(ptr %l93, ptr %t176, i64 184, i1 false)
  br label %bb41
bb41:
  %t181 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 184, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t181, ptr %l93, i64 184, i1 false)
  %t187 = call %"compiler/cond:Decision" @compiler_2fcond_2ecompiler_2fcond_3aEval_2eLocal(ptr %s0, ptr %v1, ptr %t181, ptr %a1)
  store %"compiler/cond:Decision" %t187, ptr %l97
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s0)
  %t188 = load %"compiler/cond:Decision", ptr %l97
  store %"compiler/cond:Decision" %t188, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/cond:Decision", ptr %rv
  ret %"compiler/cond:Decision" %rr
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2edeclareRaised(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca %"compiler/names:raisedName"
  %lp11 = alloca ptr
  %l12 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l18 = alloca ptr
  %l27 = alloca { i64, ptr }
  %l36 = alloca i64
  %l38 = alloca i64
  %l43 = alloca %"compiler/names:raisedName"
  %l52 = alloca ptr
  %l54 = alloca ptr
  %l55 = alloca i64
  %l59 = alloca { i64, ptr }
  %l62 = alloca %"compiler/source:Span"
  %l63 = alloca i32
  %l67 = alloca { i64, ptr }
  %l68 = alloca %"compiler/ast:CaseDecl"
  %l71 = alloca ptr
  %l72 = alloca %"compiler/source:Span"
  %l73 = alloca i32
  %l74 = alloca i32
  %l77 = alloca { i64, ptr }
  %l98 = alloca ptr
  %l99 = alloca ptr
  %l101 = alloca { i64, ptr }
  %s5 = alloca %olang.scope
  %t150 = alloca i64
  %t171 = alloca { i64, [8 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aDecl_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l12
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l12
  %t3 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %t3
  store ptr %t3, ptr %l3, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/names:Resolver", ptr %t5, i32 0, i32 0
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = getelementptr %"compiler/load:Loader", ptr %t8, i32 0, i32 10
  %t11 = load i64, ptr %l1, !tbaa !24
  %t14 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t10, i64 %t11)
  store ptr %t14, ptr %l18
  br label %bb2
bb2:
  %t15 = load ptr, ptr %l18, !tbaa !29
  %t17 = getelementptr %"compiler/load:Module", ptr %t15, i32 0, i32 8
  %t18 = load { i64, ptr }, ptr %t17, !tbaa !27
  store { i64, ptr } %t18, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t20 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t20, 0
  store i64 %t22, ptr %l6, !tbaa !24
  br label %bb3
bb3:
  %t24 = load i64, ptr %l5, !tbaa !24
  %t25 = load i64, ptr %l6, !tbaa !24
  %t28 = icmp slt i64 %t24, %t25
  %t30 = xor i1 %t28, true
  br i1 %t30, label %bb4, label %bb5
bb4:
  br label %bb9
bb5:
  br label %bb6
bb6:
  %t32 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t32, ptr %l27, !tbaa !27
  %t33 = load i64, ptr %l5, !tbaa !24
  %t35 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !27
  %t37 = getelementptr ptr, ptr %t36, i64 %t33
  %t38 = load ptr, ptr %t37, !tbaa !39
  %t40 = load ptr, ptr %l3, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aDecl_26_3e_2ePush_3ccompiler_2fast_3aDecl_26_3e(ptr %v0, ptr %v0, ptr %t40, ptr %t38)
  br label %bb7
bb7:
  br label %bb8
bb8:
  %t44 = load i64, ptr %l5, !tbaa !24
  %t47 = add i64 %t44, 1
  store i64 %t47, ptr %l5, !tbaa !24
  br label %bb3
bb9:
  store ptr %a2, ptr %l8, !tbaa !29
  store i64 0, ptr %l9, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s5
  %t51 = load i64, ptr %l9, !tbaa !24
  store i64 %t51, ptr %l36, !tbaa !24
  %t52 = load ptr, ptr %l8, !tbaa !29
  %t54 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3araisedName_3e_2eLen_H9e36587759e47da85a29e6c0abff1d1c(ptr %v1, ptr %t52)
  store i64 %t54, ptr %l38
  br label %bb11
bb11:
  %t55 = load i64, ptr %l36, !tbaa !24
  %t56 = load i64, ptr %l38, !tbaa !24
  %t57 = icmp slt i64 %t55, %t56
  %t59 = xor i1 %t57, true
  br i1 %t59, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s5)
  br label %bb35
bb13:
  br label %bb14
bb14:
  %t61 = load ptr, ptr %l8, !tbaa !29
  %t62 = load i64, ptr %l9, !tbaa !24
  %t65 = call %"compiler/names:raisedName" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3araisedName_3e_2eAt__H16b49ab3dab0c5fe49005bf48ab18c1b(ptr %v1, ptr %v1, ptr %t61, i64 %t62)
  store %"compiler/names:raisedName" %t65, ptr %l43
  br label %bb15
bb15:
  %t66 = load %"compiler/names:raisedName", ptr %l43
  store %"compiler/names:raisedName" %t66, ptr %l10
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load i64, ptr %l1, !tbaa !24
  %t69 = getelementptr %"compiler/names:raisedName", ptr %l10, i32 0, i32 0
  %t70 = load i32, ptr %t69, !tbaa !23
  %t71 = getelementptr %"compiler/names:raisedName", ptr %l10, i32 0, i32 1
  %t72 = load %"compiler/source:Span", ptr %t71
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eaddType(ptr %v0, ptr %v0, ptr %t67, i64 %t68, i32 %t70, %"compiler/source:Span" %t72, ptr null)
  br label %bb16
bb16:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/names:Resolver", ptr %t77, i32 0, i32 0
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t82 = getelementptr %"compiler/load:Loader", ptr %t80, i32 0, i32 10
  %t83 = load i64, ptr %l1, !tbaa !24
  %t86 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t82, i64 %t83)
  store ptr %t86, ptr %l52
  br label %bb17
bb17:
  %t87 = load ptr, ptr %l52, !tbaa !29
  %t89 = getelementptr %"compiler/load:Module", ptr %t87, i32 0, i32 9
  store ptr %t89, ptr %l54, !tbaa !29
  %t90 = call ptr @__olang_scope_hold(ptr %v0)
  %t91 = ptrtoint ptr %t90 to i64
  store i64 %t91, ptr %l55, !tbaa !24
  %t92 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t92, label %bb18, label %bb19
bb18:
  %t94 = call ptr @__olang_region_make(ptr %v0)
  %t95 = ptrtoint ptr %t94 to i64
  store i64 %t95, ptr %l55, !tbaa !24
  br label %bb19
bb19:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr %"compiler/names:raisedName", ptr %l10, i32 0, i32 0
  %t98 = load i32, ptr %t97, !tbaa !23
  %t101 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %s5, ptr %t96, i32 %t98)
  store { i64, ptr } %t101, ptr %l59
  br label %bb20
bb20:
  %t102 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t103 = extractvalue { i64, ptr } %t102, 1
  %t104 = extractvalue { i64, ptr } %t102, 0
  %t105 = load i64, ptr %l55
  %t106 = inttoptr i64 %t105 to ptr
  %t107 = call ptr @__olang_held_alloc(ptr %t106, i64 %t104)
  call void @olang_textcopy(ptr %t107, ptr %t103, i64 %t104)
  %t108 = insertvalue { i64, ptr } undef, i64 %t104, 0
  %t109 = insertvalue { i64, ptr } %t108, ptr %t107, 1
  %t111 = load ptr, ptr %l54, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v0, ptr %t111, { i64, ptr } %t109)
  br label %bb21
bb21:
  %t113 = getelementptr %"compiler/names:raisedName", ptr %l10, i32 0, i32 1
  %t114 = load %"compiler/source:Span", ptr %t113
  store %"compiler/source:Span" %t114, ptr %l62
  %t115 = getelementptr %"compiler/names:raisedName", ptr %l10, i32 0, i32 0
  %t116 = load i32, ptr %t115, !tbaa !23
  store i32 %t116, ptr %l63, !tbaa !23
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t118 = load i64, ptr %l1, !tbaa !24
  %t119 = getelementptr %"compiler/names:raisedName", ptr %l10, i32 0, i32 5
  %t120 = load { i64, ptr }, ptr %t119, !tbaa !27
  %t124 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eraisedFields(ptr %v0, ptr %v1, ptr %v0, ptr %t117, i64 %t118, { i64, ptr } %t120)
  store { i64, ptr } %t124, ptr %l67
  br label %bb22
bb22:
  %t125 = load %"compiler/source:Span", ptr %l62
  %t126 = load i32, ptr %l63, !tbaa !23
  %t127 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t128 = call %"compiler/ast:CaseDecl" @compiler_2fast_3aCaseDecl_2ector(ptr %v0, ptr %v0, ptr %v0, %"compiler/source:Span" %t125, i32 %t126, { i64, ptr } %t127, i1 false, ptr null)
  store %"compiler/ast:CaseDecl" %t128, ptr %l68
  br label %bb23
bb23:
  %t129 = load %"compiler/ast:CaseDecl", ptr %l68
  %t130 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store %"compiler/ast:CaseDecl" %t129, ptr %t130
  %t132 = insertvalue [1 x ptr] undef, ptr %t130, 0
  %t133 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 8, i64 8)
  store ptr %t133, ptr %lp11
  %t135 = load ptr, ptr %lp11
  store [1 x ptr] %t132, ptr %t135
  %t136 = load ptr, ptr %l3, !tbaa !29
  store ptr %t136, ptr %l71, !tbaa !29
  %t137 = getelementptr %"compiler/names:raisedName", ptr %l10, i32 0, i32 1
  %t138 = load %"compiler/source:Span", ptr %t137
  store %"compiler/source:Span" %t138, ptr %l72
  %t139 = getelementptr %"compiler/names:raisedName", ptr %l10, i32 0, i32 0
  %t140 = load i32, ptr %t139, !tbaa !23
  store i32 %t140, ptr %l73, !tbaa !23
  %t141 = getelementptr %"compiler/names:raisedName", ptr %l10, i32 0, i32 0
  %t142 = load i32, ptr %t141, !tbaa !23
  store i32 %t142, ptr %l74, !tbaa !23
  %t143 = icmp sge i64 1, 0
  br i1 %t143, label %bb24, label %bb25
bb24:
  %t145 = icmp sle i64 1, 2305843009213693951
  br i1 %t145, label %bb26, label %bb27
bb25:
  call void @__olang_check_failed(ptr @olang_loc_a58fd8af443a076b_ecb4599a293195d7)
  unreachable
bb26:
  %t147 = mul i64 1, 4
  %t148 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t147)
  %t149 = load i32, ptr %l74, !tbaa !23
  store i64 0, ptr %t150
  br label %fill.151
fill.151:
  %t154 = load i64, ptr %t150
  %t155 = icmp slt i64 %t154, 1
  br i1 %t155, label %fillb.152, label %filld.153
fillb.152:
  %t156 = getelementptr i32, ptr %t148, i64 %t154
  store i32 %t149, ptr %t156
  %t157 = add i64 %t154, 1
  store i64 %t157, ptr %t150
  br label %fill.151
filld.153:
  %t158 = insertvalue { i64, ptr } undef, i64 1, 0
  %t159 = insertvalue { i64, ptr } %t158, ptr %t148, 1
  store { i64, ptr } %t159, ptr %l77, !tbaa !27
  %t160 = icmp sge i64 0, 0
  br i1 %t160, label %bb28, label %bb29
bb27:
  call void @__olang_check_failed(ptr @olang_loc_a58fd8af443a076b_ecb4599a293195d7)
  unreachable
bb28:
  %t162 = icmp sle i64 0, 1152921504606846975
  br i1 %t162, label %bb30, label %bb31
bb29:
  call void @__olang_check_failed(ptr @olang_loc_a58fd8af443a076b_ecb4599a293195d7)
  unreachable
bb30:
  %t164 = mul i64 0, 8
  %t165 = insertvalue { i64, ptr } undef, i64 0, 0
  %t166 = insertvalue { i64, ptr } %t165, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t167 = load ptr, ptr %lp11
  %t169 = insertvalue { i64, ptr } undef, i64 1, 0
  %t170 = insertvalue { i64, ptr } %t169, ptr %t167, 1
  store { i64, [8 x i64] } zeroinitializer, ptr %t171
  %t172 = getelementptr { i64, [8 x i64] }, ptr %t171, i32 0, i32 0
  store i64 6, ptr %t172
  %t173 = load %"compiler/source:Span", ptr %l72
  %t174 = insertvalue { %"compiler/source:Span", i32, { i64, ptr }, { i64, ptr }, { i64, ptr } } undef, %"compiler/source:Span" %t173, 0
  %t175 = load i32, ptr %l73, !tbaa !23
  %t176 = insertvalue { %"compiler/source:Span", i32, { i64, ptr }, { i64, ptr }, { i64, ptr } } %t174, i32 %t175, 1
  %t177 = load { i64, ptr }, ptr %l77, !tbaa !27
  %t178 = insertvalue { %"compiler/source:Span", i32, { i64, ptr }, { i64, ptr }, { i64, ptr } } %t176, { i64, ptr } %t177, 2
  %t180 = insertvalue { %"compiler/source:Span", i32, { i64, ptr }, { i64, ptr }, { i64, ptr } } %t178, { i64, ptr } %t166, 3
  %t182 = insertvalue { %"compiler/source:Span", i32, { i64, ptr }, { i64, ptr }, { i64, ptr } } %t180, { i64, ptr } %t170, 4
  %t183 = getelementptr { i64, [8 x i64] }, ptr %t171, i32 0, i32 1
  store { %"compiler/source:Span", i32, { i64, ptr }, { i64, ptr }, { i64, ptr } } %t182, ptr %t183
  %t184 = load { i64, [8 x i64] }, ptr %t171
  %t186 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 72, i64 8)
  store { i64, [8 x i64] } %t184, ptr %t186
  %t187 = load ptr, ptr %l71, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aDecl_26_3e_2ePush_3ccompiler_2fast_3aDecl_26_3e(ptr %v0, ptr %v0, ptr %t187, ptr %t186)
  br label %bb32
bb31:
  call void @__olang_check_failed(ptr @olang_loc_a58fd8af443a076b_ecb4599a293195d7)
  unreachable
bb32:
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t190 = load i64, ptr %l1, !tbaa !24
  %t191 = getelementptr %"compiler/names:raisedName", ptr %l10, i32 0, i32 1
  %t192 = load %"compiler/source:Span", ptr %t191
  %t193 = getelementptr %"compiler/names:raisedName", ptr %l10, i32 0, i32 0
  %t194 = load i32, ptr %t193, !tbaa !23
  %t195 = load ptr, ptr %lp11
  %t197 = insertvalue { i64, ptr } undef, i64 1, 0
  %t198 = insertvalue { i64, ptr } %t197, ptr %t195, 1
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2epayloadEnum(ptr %v0, ptr %v0, ptr %t189, i64 %t190, %"compiler/source:Span" %t192, i32 %t194, { i64, ptr } %t198)
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s5)
  br label %bb34
bb34:
  %t204 = load i64, ptr %l9, !tbaa !24
  %t207 = add i64 %t204, 1
  store i64 %t207, ptr %l9, !tbaa !24
  br label %bb10
bb35:
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t211 = getelementptr %"compiler/names:Resolver", ptr %t209, i32 0, i32 0
  %t212 = load ptr, ptr %t211, !tbaa !29
  %t214 = getelementptr %"compiler/load:Loader", ptr %t212, i32 0, i32 10
  %t215 = load i64, ptr %l1, !tbaa !24
  %t218 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t214, i64 %t215)
  store ptr %t218, ptr %l98
  br label %bb36
bb36:
  %t219 = load ptr, ptr %l98, !tbaa !29
  store ptr %t219, ptr %l99, !tbaa !29
  %t220 = load ptr, ptr %l3, !tbaa !29
  %t222 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aDecl_26_3e_2eToArray_3ccompiler_2fast_3aDecl_26_3e(ptr %v0, ptr %v0, ptr %t220)
  store { i64, ptr } %t222, ptr %l101
  br label %bb37
bb37:
  %t223 = load { i64, ptr }, ptr %l101, !tbaa !27
  %t224 = load ptr, ptr %l99, !tbaa !29
  %t225 = getelementptr %"compiler/load:Module", ptr %t224, i32 0, i32 8
  store { i64, ptr } %t223, ptr %t225, !tbaa !27
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2edropAll(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l5 = alloca ptr
  %l23 = alloca ptr
  %l36 = alloca ptr
  %l37 = alloca i1
  %l45 = alloca ptr
  %l51 = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/names:Resolver", ptr %t1, i32 0, i32 18
  store ptr %t3, ptr %l5, !tbaa !29
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t6 = getelementptr %"compiler/ast:If", ptr %t4, i32 0, i32 1
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = icmp eq ptr %t7, null
  br i1 %t9, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_aef4624c79a8a28b_a45312851bdbb01f)
  unreachable
bb2:
  br label %bb3
bb3:
  %t11 = load ptr, ptr %l1, !tbaa !29
  %t13 = getelementptr %"compiler/ast:If", ptr %t11, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t17 = getelementptr %"compiler/ast:Branch", ptr %t14, i32 0, i32 0
  %t18 = load %"compiler/source:Span", ptr %t17
  %t19 = load ptr, ptr %l5, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t19, %"compiler/source:Span" %t18)
  br label %bb4
bb4:
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr %"compiler/ast:If", ptr %t21, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t26 = icmp eq ptr %t24, null
  br i1 %t26, label %bb5, label %bb6
bb5:
  call void @__olang_check_failed(ptr @olang_loc_87cbb522e5e56b9c_2473c9b69de9380)
  unreachable
bb6:
  br label %bb7
bb7:
  %t28 = load ptr, ptr %l1, !tbaa !29
  %t30 = getelementptr %"compiler/ast:If", ptr %t28, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t34 = getelementptr %"compiler/ast:Branch", ptr %t31, i32 0, i32 2
  %t35 = load i64, ptr %t34, !tbaa !24
  %t37 = icmp sge i64 %t35, 0
  br i1 %t37, label %bb8, label %bb9
bb8:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/names:Resolver", ptr %t39, i32 0, i32 0
  %t42 = load ptr, ptr %t41, !tbaa !29
  %t44 = getelementptr %"compiler/load:Loader", ptr %t42, i32 0, i32 4
  %t45 = load ptr, ptr %t44, !tbaa !29
  store ptr %t45, ptr %l23, !tbaa !29
  %t46 = load ptr, ptr %l1, !tbaa !29
  %t48 = getelementptr %"compiler/ast:If", ptr %t46, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t51 = icmp eq ptr %t49, null
  br i1 %t51, label %bb10, label %bb11
bb9:
  br label %bb14
bb10:
  call void @__olang_check_failed(ptr @olang_loc_87cbb522e5e56b9c_2473c9b69de9380)
  unreachable
bb11:
  br label %bb12
bb12:
  %t53 = load ptr, ptr %l1, !tbaa !29
  %t55 = getelementptr %"compiler/ast:If", ptr %t53, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t59 = getelementptr %"compiler/ast:Branch", ptr %t56, i32 0, i32 2
  %t60 = load i64, ptr %t59, !tbaa !24
  %t61 = load ptr, ptr %l23, !tbaa !29
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCutOff(ptr %v0, ptr %t61, i64 %t60)
  br label %bb13
bb13:
  br label %bb14
bb14:
  %t63 = load ptr, ptr %l1, !tbaa !29
  %t65 = getelementptr %"compiler/ast:If", ptr %t63, i32 0, i32 2
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t68 = icmp eq ptr %t66, null
  br i1 %t68, label %bb15, label %bb16
bb15:
  br label %ret
bb16:
  br label %bb17
bb17:
  %t70 = load ptr, ptr %l1, !tbaa !29
  %t72 = getelementptr %"compiler/ast:If", ptr %t70, i32 0, i32 2
  %t73 = load ptr, ptr %t72, !tbaa !29
  store ptr %t73, ptr %l2, !tbaa !29
  %t75 = load ptr, ptr %l2, !tbaa !29
  store ptr %t75, ptr %l36, !tbaa !29
  store i1 false, ptr %l37, !tbaa !21
  %t76 = load ptr, ptr %l36, !tbaa !29
  %t77 = icmp ne ptr %t76, null
  br i1 %t77, label %bb18, label %bb19
bb18:
  %t79 = load ptr, ptr %l36, !tbaa !29
  %t80 = load i64, ptr %t79, !range !{i64 0, i64 22}
  %t82 = icmp eq i64 %t80, 5
  store i1 %t82, ptr %l37, !tbaa !21
  br label %bb19
bb19:
  %t83 = load i1, ptr %l37, !tbaa !21
  br i1 %t83, label %bb20, label %bb21
bb20:
  %t84 = load ptr, ptr %l2, !tbaa !29
  %t86 = getelementptr { i64, [4 x i64] }, ptr %t84, i32 0, i32 1
  %t87 = getelementptr { %"compiler/source:Span", ptr }, ptr %t86, i32 0, i32 1
  %t88 = load ptr, ptr %t87
  store ptr %t88, ptr %l3, !tbaa !29
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t91 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2edropAll(ptr %v0, ptr %v1, ptr %t90, ptr %t91)
  br label %bb23
bb23:
  br label %bb34
bb24:
  br i1 true, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb33
bb27:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/names:Resolver", ptr %t94, i32 0, i32 18
  store ptr %t96, ptr %l45, !tbaa !29
  %t97 = load ptr, ptr %l1, !tbaa !29
  %t99 = getelementptr %"compiler/ast:If", ptr %t97, i32 0, i32 2
  %t100 = load ptr, ptr %t99, !tbaa !29
  %t102 = icmp eq ptr %t100, null
  br i1 %t102, label %bb28, label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_12490b43c47bea91_b34a6c7dd92a3b95)
  unreachable
bb29:
  br label %bb30
bb30:
  %t104 = load ptr, ptr %l1, !tbaa !29
  %t106 = getelementptr %"compiler/ast:If", ptr %t104, i32 0, i32 2
  %t107 = load ptr, ptr %t106, !tbaa !29
  %t109 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aStmt_2eSpan(ptr %v1, ptr %t107)
  store %"compiler/source:Span" %t109, ptr %l51
  br label %bb31
bb31:
  %t110 = load ptr, ptr %l45, !tbaa !29
  %t111 = load %"compiler/source:Span", ptr %l51
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t110, %"compiler/source:Span" %t111)
  br label %bb32
bb32:
  br label %bb34
bb33:
  call void @__olang_check_failed(ptr @olang_loc_f9018996705a58e9_83925e810340c2fd)
  unreachable
bb34:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i64
  %l24 = alloca ptr
  %l25 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l27 = alloca i64
  %l28 = alloca i64
  %l30 = alloca %"compiler/source:Span"
  %l31 = alloca ptr
  %l32 = alloca i32
  %l33 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca i64
  %l39 = alloca ptr
  %l40 = alloca ptr
  %l41 = alloca ptr
  %l42 = alloca ptr
  %l43 = alloca ptr
  %l44 = alloca ptr
  %l45 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l47 = alloca i64
  %l48 = alloca i64
  %l50 = alloca { i64, ptr }
  %l51 = alloca { i64, ptr }
  %l52 = alloca i64
  %l53 = alloca i64
  %l55 = alloca %"compiler/source:Span"
  %l56 = alloca ptr
  %l57 = alloca i64
  %l58 = alloca ptr
  %l59 = alloca { i64, ptr }
  %l60 = alloca ptr
  %l61 = alloca i1
  %l62 = alloca i64
  %l63 = alloca ptr
  %l66 = alloca ptr
  %l67 = alloca i1
  %l77 = alloca ptr
  %l78 = alloca i1
  %l83 = alloca ptr
  %l84 = alloca i1
  %l89 = alloca ptr
  %l90 = alloca i1
  %l95 = alloca ptr
  %l96 = alloca i1
  %l101 = alloca ptr
  %l102 = alloca i1
  %l110 = alloca ptr
  %l111 = alloca i1
  %l118 = alloca ptr
  %l119 = alloca i1
  %l126 = alloca ptr
  %l127 = alloca i1
  %l140 = alloca ptr
  %l141 = alloca i1
  %l154 = alloca { i64, ptr }
  %l163 = alloca ptr
  %l164 = alloca i1
  %l182 = alloca ptr
  %l183 = alloca i1
  %l196 = alloca ptr
  %l197 = alloca i1
  %l214 = alloca { i64, ptr }
  %l223 = alloca ptr
  %l224 = alloca i1
  %l241 = alloca { i64, ptr }
  %l250 = alloca ptr
  %l251 = alloca i1
  %l264 = alloca ptr
  %l265 = alloca i1
  %l282 = alloca { i64, ptr }
  %l291 = alloca ptr
  %l292 = alloca i1
  %l308 = alloca ptr
  %l309 = alloca i1
  %l320 = alloca ptr
  %l321 = alloca i1
  %l341 = alloca { i64, ptr }
  %l350 = alloca ptr
  %l351 = alloca i1
  %l356 = alloca ptr
  %l357 = alloca i1
  %l369 = alloca { i64, ptr }
  %l378 = alloca ptr
  %l379 = alloca i1
  %l399 = alloca i64
  %l415 = alloca ptr
  %l416 = alloca i1
  %l428 = alloca ptr
  %l429 = alloca i1
  %l438 = alloca i64
  %l458 = alloca ptr
  %l459 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %l66, !tbaa !29
  store i1 false, ptr %l67, !tbaa !21
  %t6 = load ptr, ptr %l66, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l66, !tbaa !29
  %t10 = load i64, ptr %t9, !range !{i64 0, i64 28}
  %t12 = icmp eq i64 %t10, 0
  store i1 %t12, ptr %l67, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l67, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr { i64, [4 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", i32 }, ptr %t16, i32 0, i32 0
  %t18 = load %"compiler/source:Span", ptr %t17
  store %"compiler/source:Span" %t18, ptr %l2
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t22 = getelementptr { i64, [4 x i64] }, ptr %t20, i32 0, i32 1
  %t23 = getelementptr { %"compiler/source:Span", i32 }, ptr %t22, i32 0, i32 1
  %t24 = load i32, ptr %t23
  store i32 %t24, ptr %l3, !tbaa !23
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load %"compiler/source:Span", ptr %l2
  %t28 = load i32, ptr %l3, !tbaa !23
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ename(ptr %v0, ptr %t26, %"compiler/source:Span" %t27, i32 %t28)
  br label %bb9
bb9:
  br label %bb233
bb10:
  %t32 = load ptr, ptr %l1, !tbaa !29
  store ptr %t32, ptr %l77, !tbaa !29
  store i1 false, ptr %l78, !tbaa !21
  %t33 = load ptr, ptr %l77, !tbaa !29
  %t34 = icmp ne ptr %t33, null
  br i1 %t34, label %bb11, label %bb12
bb11:
  %t36 = load ptr, ptr %l77, !tbaa !29
  %t37 = load i64, ptr %t36, !range !{i64 0, i64 28}
  %t39 = icmp eq i64 %t37, 2
  store i1 %t39, ptr %l78, !tbaa !21
  br label %bb12
bb12:
  %t40 = load i1, ptr %l78, !tbaa !21
  br i1 %t40, label %bb13, label %bb14
bb13:
  %t41 = load ptr, ptr %l1, !tbaa !29
  %t43 = getelementptr { i64, [4 x i64] }, ptr %t41, i32 0, i32 1
  %t44 = getelementptr { %"compiler/source:Span", ptr }, ptr %t43, i32 0, i32 1
  %t45 = load ptr, ptr %t44
  store ptr %t45, ptr %l4, !tbaa !29
  br label %bb31
bb14:
  %t47 = load ptr, ptr %l1, !tbaa !29
  store ptr %t47, ptr %l83, !tbaa !29
  store i1 false, ptr %l84, !tbaa !21
  %t48 = load ptr, ptr %l83, !tbaa !29
  %t49 = icmp ne ptr %t48, null
  br i1 %t49, label %bb15, label %bb16
bb15:
  %t51 = load ptr, ptr %l83, !tbaa !29
  %t52 = load i64, ptr %t51, !range !{i64 0, i64 28}
  %t54 = icmp eq i64 %t52, 24
  store i1 %t54, ptr %l84, !tbaa !21
  br label %bb16
bb16:
  %t55 = load i1, ptr %l84, !tbaa !21
  br i1 %t55, label %bb17, label %bb18
bb17:
  %t56 = load ptr, ptr %l1, !tbaa !29
  %t58 = getelementptr { i64, [4 x i64] }, ptr %t56, i32 0, i32 1
  %t59 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t58, i32 0, i32 2
  %t60 = load ptr, ptr %t59
  store ptr %t60, ptr %l4, !tbaa !29
  br label %bb31
bb18:
  %t62 = load ptr, ptr %l1, !tbaa !29
  store ptr %t62, ptr %l89, !tbaa !29
  store i1 false, ptr %l90, !tbaa !21
  %t63 = load ptr, ptr %l89, !tbaa !29
  %t64 = icmp ne ptr %t63, null
  br i1 %t64, label %bb19, label %bb20
bb19:
  %t66 = load ptr, ptr %l89, !tbaa !29
  %t67 = load i64, ptr %t66, !range !{i64 0, i64 28}
  %t69 = icmp eq i64 %t67, 26
  store i1 %t69, ptr %l90, !tbaa !21
  br label %bb20
bb20:
  %t70 = load i1, ptr %l90, !tbaa !21
  br i1 %t70, label %bb21, label %bb22
bb21:
  %t71 = load ptr, ptr %l1, !tbaa !29
  %t73 = getelementptr { i64, [4 x i64] }, ptr %t71, i32 0, i32 1
  %t74 = getelementptr { %"compiler/source:Span", ptr }, ptr %t73, i32 0, i32 1
  %t75 = load ptr, ptr %t74
  store ptr %t75, ptr %l4, !tbaa !29
  br label %bb31
bb22:
  %t77 = load ptr, ptr %l1, !tbaa !29
  store ptr %t77, ptr %l95, !tbaa !29
  store i1 false, ptr %l96, !tbaa !21
  %t78 = load ptr, ptr %l95, !tbaa !29
  %t79 = icmp ne ptr %t78, null
  br i1 %t79, label %bb23, label %bb24
bb23:
  %t81 = load ptr, ptr %l95, !tbaa !29
  %t82 = load i64, ptr %t81, !range !{i64 0, i64 28}
  %t84 = icmp eq i64 %t82, 3
  store i1 %t84, ptr %l96, !tbaa !21
  br label %bb24
bb24:
  %t85 = load i1, ptr %l96, !tbaa !21
  br i1 %t85, label %bb25, label %bb26
bb25:
  %t86 = load ptr, ptr %l1, !tbaa !29
  %t88 = getelementptr { i64, [4 x i64] }, ptr %t86, i32 0, i32 1
  %t89 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t88, i32 0, i32 2
  %t90 = load ptr, ptr %t89
  store ptr %t90, ptr %l4, !tbaa !29
  br label %bb31
bb26:
  %t92 = load ptr, ptr %l1, !tbaa !29
  store ptr %t92, ptr %l101, !tbaa !29
  store i1 false, ptr %l102, !tbaa !21
  %t93 = load ptr, ptr %l101, !tbaa !29
  %t94 = icmp ne ptr %t93, null
  br i1 %t94, label %bb27, label %bb28
bb27:
  %t96 = load ptr, ptr %l101, !tbaa !29
  %t97 = load i64, ptr %t96, !range !{i64 0, i64 28}
  %t99 = icmp eq i64 %t97, 4
  store i1 %t99, ptr %l102, !tbaa !21
  br label %bb28
bb28:
  %t100 = load i1, ptr %l102, !tbaa !21
  br i1 %t100, label %bb29, label %bb30
bb29:
  %t101 = load ptr, ptr %l1, !tbaa !29
  %t103 = getelementptr { i64, [4 x i64] }, ptr %t101, i32 0, i32 1
  %t104 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t103, i32 0, i32 2
  %t105 = load ptr, ptr %t104
  store ptr %t105, ptr %l4, !tbaa !29
  br label %bb31
bb30:
  br label %bb33
bb31:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t108 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t107, ptr %t108)
  br label %bb32
bb32:
  br label %bb233
bb33:
  %t112 = load ptr, ptr %l1, !tbaa !29
  store ptr %t112, ptr %l110, !tbaa !29
  store i1 false, ptr %l111, !tbaa !21
  %t113 = load ptr, ptr %l110, !tbaa !29
  %t114 = icmp ne ptr %t113, null
  br i1 %t114, label %bb34, label %bb35
bb34:
  %t116 = load ptr, ptr %l110, !tbaa !29
  %t117 = load i64, ptr %t116, !range !{i64 0, i64 28}
  %t119 = icmp eq i64 %t117, 25
  store i1 %t119, ptr %l111, !tbaa !21
  br label %bb35
bb35:
  %t120 = load i1, ptr %l111, !tbaa !21
  br i1 %t120, label %bb36, label %bb37
bb36:
  %t121 = load ptr, ptr %l1, !tbaa !29
  %t123 = getelementptr { i64, [4 x i64] }, ptr %t121, i32 0, i32 1
  %t124 = getelementptr { %"compiler/source:Span", ptr }, ptr %t123, i32 0, i32 1
  %t125 = load ptr, ptr %t124
  store ptr %t125, ptr %l5, !tbaa !29
  br label %bb38
bb37:
  br label %bb40
bb38:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t128 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t127, ptr %t128)
  br label %bb39
bb39:
  br label %bb233
bb40:
  %t131 = load ptr, ptr %l1, !tbaa !29
  store ptr %t131, ptr %l118, !tbaa !29
  store i1 false, ptr %l119, !tbaa !21
  %t132 = load ptr, ptr %l118, !tbaa !29
  %t133 = icmp ne ptr %t132, null
  br i1 %t133, label %bb41, label %bb42
bb41:
  %t135 = load ptr, ptr %l118, !tbaa !29
  %t136 = load i64, ptr %t135, !range !{i64 0, i64 28}
  %t138 = icmp eq i64 %t136, 5
  store i1 %t138, ptr %l119, !tbaa !21
  br label %bb42
bb42:
  %t139 = load i1, ptr %l119, !tbaa !21
  br i1 %t139, label %bb43, label %bb44
bb43:
  %t140 = load ptr, ptr %l1, !tbaa !29
  %t142 = getelementptr { i64, [4 x i64] }, ptr %t140, i32 0, i32 1
  %t143 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t142, i32 0, i32 2
  %t144 = load ptr, ptr %t143
  store ptr %t144, ptr %l6, !tbaa !29
  %t146 = load ptr, ptr %l1, !tbaa !29
  %t148 = getelementptr { i64, [4 x i64] }, ptr %t146, i32 0, i32 1
  %t149 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t148, i32 0, i32 3
  %t150 = load ptr, ptr %t149
  store ptr %t150, ptr %l7, !tbaa !29
  br label %bb49
bb44:
  %t152 = load ptr, ptr %l1, !tbaa !29
  store ptr %t152, ptr %l126, !tbaa !29
  store i1 false, ptr %l127, !tbaa !21
  %t153 = load ptr, ptr %l126, !tbaa !29
  %t154 = icmp ne ptr %t153, null
  br i1 %t154, label %bb45, label %bb46
bb45:
  %t156 = load ptr, ptr %l126, !tbaa !29
  %t157 = load i64, ptr %t156, !range !{i64 0, i64 28}
  %t159 = icmp eq i64 %t157, 6
  store i1 %t159, ptr %l127, !tbaa !21
  br label %bb46
bb46:
  %t160 = load i1, ptr %l127, !tbaa !21
  br i1 %t160, label %bb47, label %bb48
bb47:
  %t161 = load ptr, ptr %l1, !tbaa !29
  %t163 = getelementptr { i64, [4 x i64] }, ptr %t161, i32 0, i32 1
  %t164 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t163, i32 0, i32 1
  %t165 = load ptr, ptr %t164
  store ptr %t165, ptr %l6, !tbaa !29
  %t167 = load ptr, ptr %l1, !tbaa !29
  %t169 = getelementptr { i64, [4 x i64] }, ptr %t167, i32 0, i32 1
  %t170 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t169, i32 0, i32 2
  %t171 = load ptr, ptr %t170
  store ptr %t171, ptr %l7, !tbaa !29
  br label %bb49
bb48:
  br label %bb52
bb49:
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t174 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t173, ptr %t174)
  br label %bb50
bb50:
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t179 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t178, ptr %t179)
  br label %bb51
bb51:
  br label %bb233
bb52:
  %t183 = load ptr, ptr %l1, !tbaa !29
  store ptr %t183, ptr %l140, !tbaa !29
  store i1 false, ptr %l141, !tbaa !21
  %t184 = load ptr, ptr %l140, !tbaa !29
  %t185 = icmp ne ptr %t184, null
  br i1 %t185, label %bb53, label %bb54
bb53:
  %t187 = load ptr, ptr %l140, !tbaa !29
  %t188 = load i64, ptr %t187, !range !{i64 0, i64 28}
  %t190 = icmp eq i64 %t188, 7
  store i1 %t190, ptr %l141, !tbaa !21
  br label %bb54
bb54:
  %t191 = load i1, ptr %l141, !tbaa !21
  br i1 %t191, label %bb55, label %bb56
bb55:
  %t192 = load ptr, ptr %l1, !tbaa !29
  %t194 = getelementptr { i64, [4 x i64] }, ptr %t192, i32 0, i32 1
  %t195 = getelementptr { %"compiler/source:Span", ptr }, ptr %t194, i32 0, i32 1
  %t196 = load ptr, ptr %t195
  store ptr %t196, ptr %l8, !tbaa !29
  br label %bb57
bb56:
  br label %bb65
bb57:
  %t198 = load ptr, ptr %l8, !tbaa !29
  %t200 = getelementptr %"compiler/ast:Chain", ptr %t198, i32 0, i32 1
  %t201 = load { i64, ptr }, ptr %t200, !tbaa !27
  store { i64, ptr } %t201, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t203 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t205 = extractvalue { i64, ptr } %t203, 0
  store i64 %t205, ptr %l11, !tbaa !24
  br label %bb58
bb58:
  %t207 = load i64, ptr %l10, !tbaa !24
  %t208 = load i64, ptr %l11, !tbaa !24
  %t211 = icmp slt i64 %t207, %t208
  %t213 = xor i1 %t211, true
  br i1 %t213, label %bb59, label %bb60
bb59:
  br label %bb64
bb60:
  br label %bb61
bb61:
  %t215 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t215, ptr %l154, !tbaa !27
  %t216 = load i64, ptr %l10, !tbaa !24
  %t218 = getelementptr { i64, ptr }, ptr %l154, i32 0, i32 1
  %t219 = load ptr, ptr %t218, !tbaa !27
  %t220 = getelementptr ptr, ptr %t219, i64 %t216
  %t221 = load ptr, ptr %t220, !tbaa !39
  %t223 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t223, ptr %t221)
  br label %bb62
bb62:
  br label %bb63
bb63:
  %t228 = load i64, ptr %l10, !tbaa !24
  %t231 = add i64 %t228, 1
  store i64 %t231, ptr %l10, !tbaa !24
  br label %bb58
bb64:
  br label %bb233
bb65:
  %t233 = load ptr, ptr %l1, !tbaa !29
  store ptr %t233, ptr %l163, !tbaa !29
  store i1 false, ptr %l164, !tbaa !21
  %t234 = load ptr, ptr %l163, !tbaa !29
  %t235 = icmp ne ptr %t234, null
  br i1 %t235, label %bb66, label %bb67
bb66:
  %t237 = load ptr, ptr %l163, !tbaa !29
  %t238 = load i64, ptr %t237, !range !{i64 0, i64 28}
  %t240 = icmp eq i64 %t238, 8
  store i1 %t240, ptr %l164, !tbaa !21
  br label %bb67
bb67:
  %t241 = load i1, ptr %l164, !tbaa !21
  br i1 %t241, label %bb68, label %bb69
bb68:
  %t242 = load ptr, ptr %l1, !tbaa !29
  %t244 = getelementptr { i64, [4 x i64] }, ptr %t242, i32 0, i32 1
  %t245 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t244, i32 0, i32 1
  %t246 = load ptr, ptr %t245
  store ptr %t246, ptr %l13, !tbaa !29
  %t248 = load ptr, ptr %l1, !tbaa !29
  %t250 = getelementptr { i64, [4 x i64] }, ptr %t248, i32 0, i32 1
  %t251 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t250, i32 0, i32 2
  %t252 = load ptr, ptr %t251
  store ptr %t252, ptr %l14, !tbaa !29
  %t254 = load ptr, ptr %l1, !tbaa !29
  %t256 = getelementptr { i64, [4 x i64] }, ptr %t254, i32 0, i32 1
  %t257 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t256, i32 0, i32 3
  %t258 = load ptr, ptr %t257
  store ptr %t258, ptr %l15, !tbaa !29
  br label %bb70
bb69:
  br label %bb74
bb70:
  %t260 = load ptr, ptr %l0, !tbaa !29
  %t261 = load ptr, ptr %l13, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t260, ptr %t261)
  br label %bb71
bb71:
  %t265 = load ptr, ptr %l0, !tbaa !29
  %t266 = load ptr, ptr %l14, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t265, ptr %t266)
  br label %bb72
bb72:
  %t270 = load ptr, ptr %l0, !tbaa !29
  %t271 = load ptr, ptr %l15, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t270, ptr %t271)
  br label %bb73
bb73:
  br label %bb233
bb74:
  %t275 = load ptr, ptr %l1, !tbaa !29
  store ptr %t275, ptr %l182, !tbaa !29
  store i1 false, ptr %l183, !tbaa !21
  %t276 = load ptr, ptr %l182, !tbaa !29
  %t277 = icmp ne ptr %t276, null
  br i1 %t277, label %bb75, label %bb76
bb75:
  %t279 = load ptr, ptr %l182, !tbaa !29
  %t280 = load i64, ptr %t279, !range !{i64 0, i64 28}
  %t282 = icmp eq i64 %t280, 9
  store i1 %t282, ptr %l183, !tbaa !21
  br label %bb76
bb76:
  %t283 = load i1, ptr %l183, !tbaa !21
  br i1 %t283, label %bb77, label %bb78
bb77:
  %t284 = load ptr, ptr %l1, !tbaa !29
  %t286 = getelementptr { i64, [4 x i64] }, ptr %t284, i32 0, i32 1
  %t287 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t286, i32 0, i32 1
  %t288 = load ptr, ptr %t287
  store ptr %t288, ptr %l16, !tbaa !29
  %t290 = load ptr, ptr %l1, !tbaa !29
  %t292 = getelementptr { i64, [4 x i64] }, ptr %t290, i32 0, i32 1
  %t293 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t292, i32 0, i32 2
  %t294 = load ptr, ptr %t293
  store ptr %t294, ptr %l17, !tbaa !29
  br label %bb79
bb78:
  br label %bb82
bb79:
  %t296 = load ptr, ptr %l0, !tbaa !29
  %t297 = load ptr, ptr %l16, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t296, ptr %t297)
  br label %bb80
bb80:
  %t301 = load ptr, ptr %l0, !tbaa !29
  %t302 = load ptr, ptr %l17, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeRef(ptr %v0, ptr %v1, ptr %t301, ptr %t302)
  br label %bb81
bb81:
  br label %bb233
bb82:
  %t306 = load ptr, ptr %l1, !tbaa !29
  store ptr %t306, ptr %l196, !tbaa !29
  store i1 false, ptr %l197, !tbaa !21
  %t307 = load ptr, ptr %l196, !tbaa !29
  %t308 = icmp ne ptr %t307, null
  br i1 %t308, label %bb83, label %bb84
bb83:
  %t310 = load ptr, ptr %l196, !tbaa !29
  %t311 = load i64, ptr %t310, !range !{i64 0, i64 28}
  %t313 = icmp eq i64 %t311, 10
  store i1 %t313, ptr %l197, !tbaa !21
  br label %bb84
bb84:
  %t314 = load i1, ptr %l197, !tbaa !21
  br i1 %t314, label %bb85, label %bb86
bb85:
  %t315 = load ptr, ptr %l1, !tbaa !29
  %t317 = getelementptr { i64, [4 x i64] }, ptr %t315, i32 0, i32 1
  %t318 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t317, i32 0, i32 1
  %t319 = load ptr, ptr %t318
  store ptr %t319, ptr %l18, !tbaa !29
  %t321 = load ptr, ptr %l1, !tbaa !29
  %t323 = getelementptr { i64, [4 x i64] }, ptr %t321, i32 0, i32 1
  %t324 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t323, i32 0, i32 2
  %t325 = load { i64, ptr }, ptr %t324
  store { i64, ptr } %t325, ptr %l19, !tbaa !27
  br label %bb87
bb86:
  br label %bb96
bb87:
  %t327 = load ptr, ptr %l0, !tbaa !29
  %t328 = load ptr, ptr %l18, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t327, ptr %t328)
  br label %bb88
bb88:
  %t332 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t332, ptr %l20, !tbaa !27
  store i64 0, ptr %l21, !tbaa !24
  %t334 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t336 = extractvalue { i64, ptr } %t334, 0
  store i64 %t336, ptr %l22, !tbaa !24
  br label %bb89
bb89:
  %t338 = load i64, ptr %l21, !tbaa !24
  %t339 = load i64, ptr %l22, !tbaa !24
  %t342 = icmp slt i64 %t338, %t339
  %t344 = xor i1 %t342, true
  br i1 %t344, label %bb90, label %bb91
bb90:
  br label %bb95
bb91:
  br label %bb92
bb92:
  %t346 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t346, ptr %l214, !tbaa !27
  %t347 = load i64, ptr %l21, !tbaa !24
  %t349 = getelementptr { i64, ptr }, ptr %l214, i32 0, i32 1
  %t350 = load ptr, ptr %t349, !tbaa !27
  %t351 = getelementptr ptr, ptr %t350, i64 %t347
  %t352 = load ptr, ptr %t351, !tbaa !39
  %t354 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t354, ptr %t352)
  br label %bb93
bb93:
  br label %bb94
bb94:
  %t359 = load i64, ptr %l21, !tbaa !24
  %t362 = add i64 %t359, 1
  store i64 %t362, ptr %l21, !tbaa !24
  br label %bb89
bb95:
  br label %bb233
bb96:
  %t364 = load ptr, ptr %l1, !tbaa !29
  store ptr %t364, ptr %l223, !tbaa !29
  store i1 false, ptr %l224, !tbaa !21
  %t365 = load ptr, ptr %l223, !tbaa !29
  %t366 = icmp ne ptr %t365, null
  br i1 %t366, label %bb97, label %bb98
bb97:
  %t368 = load ptr, ptr %l223, !tbaa !29
  %t369 = load i64, ptr %t368, !range !{i64 0, i64 28}
  %t371 = icmp eq i64 %t369, 11
  store i1 %t371, ptr %l224, !tbaa !21
  br label %bb98
bb98:
  %t372 = load i1, ptr %l224, !tbaa !21
  br i1 %t372, label %bb99, label %bb100
bb99:
  %t373 = load ptr, ptr %l1, !tbaa !29
  %t375 = getelementptr { i64, [4 x i64] }, ptr %t373, i32 0, i32 1
  %t376 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t375, i32 0, i32 1
  %t377 = load ptr, ptr %t376
  store ptr %t377, ptr %l24, !tbaa !29
  %t379 = load ptr, ptr %l1, !tbaa !29
  %t381 = getelementptr { i64, [4 x i64] }, ptr %t379, i32 0, i32 1
  %t382 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t381, i32 0, i32 2
  %t383 = load { i64, ptr }, ptr %t382
  store { i64, ptr } %t383, ptr %l25, !tbaa !27
  br label %bb101
bb100:
  br label %bb110
bb101:
  %t385 = load ptr, ptr %l0, !tbaa !29
  %t386 = load ptr, ptr %l24, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t385, ptr %t386)
  br label %bb102
bb102:
  %t390 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t390, ptr %l26, !tbaa !27
  store i64 0, ptr %l27, !tbaa !24
  %t392 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t394 = extractvalue { i64, ptr } %t392, 0
  store i64 %t394, ptr %l28, !tbaa !24
  br label %bb103
bb103:
  %t396 = load i64, ptr %l27, !tbaa !24
  %t397 = load i64, ptr %l28, !tbaa !24
  %t400 = icmp slt i64 %t396, %t397
  %t402 = xor i1 %t400, true
  br i1 %t402, label %bb104, label %bb105
bb104:
  br label %bb109
bb105:
  br label %bb106
bb106:
  %t404 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t404, ptr %l241, !tbaa !27
  %t405 = load i64, ptr %l27, !tbaa !24
  %t407 = getelementptr { i64, ptr }, ptr %l241, i32 0, i32 1
  %t408 = load ptr, ptr %t407, !tbaa !27
  %t409 = getelementptr ptr, ptr %t408, i64 %t405
  %t410 = load ptr, ptr %t409, !tbaa !39
  %t412 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeRef(ptr %v0, ptr %v1, ptr %t412, ptr %t410)
  br label %bb107
bb107:
  br label %bb108
bb108:
  %t417 = load i64, ptr %l27, !tbaa !24
  %t420 = add i64 %t417, 1
  store i64 %t420, ptr %l27, !tbaa !24
  br label %bb103
bb109:
  br label %bb233
bb110:
  %t422 = load ptr, ptr %l1, !tbaa !29
  store ptr %t422, ptr %l250, !tbaa !29
  store i1 false, ptr %l251, !tbaa !21
  %t423 = load ptr, ptr %l250, !tbaa !29
  %t424 = icmp ne ptr %t423, null
  br i1 %t424, label %bb111, label %bb112
bb111:
  %t426 = load ptr, ptr %l250, !tbaa !29
  %t427 = load i64, ptr %t426, !range !{i64 0, i64 28}
  %t429 = icmp eq i64 %t427, 12
  store i1 %t429, ptr %l251, !tbaa !21
  br label %bb112
bb112:
  %t430 = load i1, ptr %l251, !tbaa !21
  br i1 %t430, label %bb113, label %bb114
bb113:
  %t431 = load ptr, ptr %l1, !tbaa !29
  %t433 = getelementptr { i64, [4 x i64] }, ptr %t431, i32 0, i32 1
  %t434 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t433, i32 0, i32 0
  %t435 = load %"compiler/source:Span", ptr %t434
  store %"compiler/source:Span" %t435, ptr %l30
  %t437 = load ptr, ptr %l1, !tbaa !29
  %t439 = getelementptr { i64, [4 x i64] }, ptr %t437, i32 0, i32 1
  %t440 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t439, i32 0, i32 1
  %t441 = load ptr, ptr %t440
  store ptr %t441, ptr %l31, !tbaa !29
  %t443 = load ptr, ptr %l1, !tbaa !29
  %t445 = getelementptr { i64, [4 x i64] }, ptr %t443, i32 0, i32 1
  %t446 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t445, i32 0, i32 2
  %t447 = load i32, ptr %t446
  store i32 %t447, ptr %l32, !tbaa !23
  br label %bb115
bb114:
  br label %bb117
bb115:
  %t449 = load ptr, ptr %l0, !tbaa !29
  %t450 = load %"compiler/source:Span", ptr %l30
  %t451 = load ptr, ptr %l31, !tbaa !29
  %t452 = load i32, ptr %l32, !tbaa !23
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2emember(ptr %v0, ptr %v1, ptr %t449, %"compiler/source:Span" %t450, ptr %t451, i32 %t452)
  br label %bb116
bb116:
  br label %bb233
bb117:
  %t457 = load ptr, ptr %l1, !tbaa !29
  store ptr %t457, ptr %l264, !tbaa !29
  store i1 false, ptr %l265, !tbaa !21
  %t458 = load ptr, ptr %l264, !tbaa !29
  %t459 = icmp ne ptr %t458, null
  br i1 %t459, label %bb118, label %bb119
bb118:
  %t461 = load ptr, ptr %l264, !tbaa !29
  %t462 = load i64, ptr %t461, !range !{i64 0, i64 28}
  %t464 = icmp eq i64 %t462, 13
  store i1 %t464, ptr %l265, !tbaa !21
  br label %bb119
bb119:
  %t465 = load i1, ptr %l265, !tbaa !21
  br i1 %t465, label %bb120, label %bb121
bb120:
  %t466 = load ptr, ptr %l1, !tbaa !29
  %t468 = getelementptr { i64, [4 x i64] }, ptr %t466, i32 0, i32 1
  %t469 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t468, i32 0, i32 1
  %t470 = load ptr, ptr %t469
  store ptr %t470, ptr %l33, !tbaa !29
  %t472 = load ptr, ptr %l1, !tbaa !29
  %t474 = getelementptr { i64, [4 x i64] }, ptr %t472, i32 0, i32 1
  %t475 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t474, i32 0, i32 2
  %t476 = load { i64, ptr }, ptr %t475
  store { i64, ptr } %t476, ptr %l34, !tbaa !27
  br label %bb122
bb121:
  br label %bb131
bb122:
  %t478 = load ptr, ptr %l0, !tbaa !29
  %t479 = load ptr, ptr %l33, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t478, ptr %t479)
  br label %bb123
bb123:
  %t483 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t483, ptr %l35, !tbaa !27
  store i64 0, ptr %l36, !tbaa !24
  %t485 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t487 = extractvalue { i64, ptr } %t485, 0
  store i64 %t487, ptr %l37, !tbaa !24
  br label %bb124
bb124:
  %t489 = load i64, ptr %l36, !tbaa !24
  %t490 = load i64, ptr %l37, !tbaa !24
  %t493 = icmp slt i64 %t489, %t490
  %t495 = xor i1 %t493, true
  br i1 %t495, label %bb125, label %bb126
bb125:
  br label %bb130
bb126:
  br label %bb127
bb127:
  %t497 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t497, ptr %l282, !tbaa !27
  %t498 = load i64, ptr %l36, !tbaa !24
  %t500 = getelementptr { i64, ptr }, ptr %l282, i32 0, i32 1
  %t501 = load ptr, ptr %t500, !tbaa !27
  %t502 = getelementptr ptr, ptr %t501, i64 %t498
  %t503 = load ptr, ptr %t502, !tbaa !39
  %t505 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t505, ptr %t503)
  br label %bb128
bb128:
  br label %bb129
bb129:
  %t510 = load i64, ptr %l36, !tbaa !24
  %t513 = add i64 %t510, 1
  store i64 %t513, ptr %l36, !tbaa !24
  br label %bb124
bb130:
  br label %bb233
bb131:
  %t515 = load ptr, ptr %l1, !tbaa !29
  store ptr %t515, ptr %l291, !tbaa !29
  store i1 false, ptr %l292, !tbaa !21
  %t516 = load ptr, ptr %l291, !tbaa !29
  %t517 = icmp ne ptr %t516, null
  br i1 %t517, label %bb132, label %bb133
bb132:
  %t519 = load ptr, ptr %l291, !tbaa !29
  %t520 = load i64, ptr %t519, !range !{i64 0, i64 28}
  %t522 = icmp eq i64 %t520, 14
  store i1 %t522, ptr %l292, !tbaa !21
  br label %bb133
bb133:
  %t523 = load i1, ptr %l292, !tbaa !21
  br i1 %t523, label %bb134, label %bb135
bb134:
  %t524 = load ptr, ptr %l1, !tbaa !29
  %t526 = getelementptr { i64, [4 x i64] }, ptr %t524, i32 0, i32 1
  %t527 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t526, i32 0, i32 1
  %t528 = load ptr, ptr %t527
  store ptr %t528, ptr %l39, !tbaa !29
  %t530 = load ptr, ptr %l1, !tbaa !29
  %t532 = getelementptr { i64, [4 x i64] }, ptr %t530, i32 0, i32 1
  %t533 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t532, i32 0, i32 2
  %t534 = load ptr, ptr %t533
  store ptr %t534, ptr %l40, !tbaa !29
  %t536 = load ptr, ptr %l1, !tbaa !29
  %t538 = getelementptr { i64, [4 x i64] }, ptr %t536, i32 0, i32 1
  %t539 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t538, i32 0, i32 3
  %t540 = load ptr, ptr %t539
  store ptr %t540, ptr %l41, !tbaa !29
  br label %bb136
bb135:
  br label %bb140
bb136:
  %t542 = load ptr, ptr %l0, !tbaa !29
  %t543 = load ptr, ptr %l39, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t542, ptr %t543)
  br label %bb137
bb137:
  %t547 = load ptr, ptr %l0, !tbaa !29
  %t548 = load ptr, ptr %l40, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t547, ptr %t548)
  br label %bb138
bb138:
  %t551 = load ptr, ptr %l0, !tbaa !29
  %t552 = load ptr, ptr %l41, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t551, ptr %t552)
  br label %bb139
bb139:
  br label %bb233
bb140:
  %t555 = load ptr, ptr %l1, !tbaa !29
  store ptr %t555, ptr %l308, !tbaa !29
  store i1 false, ptr %l309, !tbaa !21
  %t556 = load ptr, ptr %l308, !tbaa !29
  %t557 = icmp ne ptr %t556, null
  br i1 %t557, label %bb141, label %bb142
bb141:
  %t559 = load ptr, ptr %l308, !tbaa !29
  %t560 = load i64, ptr %t559, !range !{i64 0, i64 28}
  %t562 = icmp eq i64 %t560, 15
  store i1 %t562, ptr %l309, !tbaa !21
  br label %bb142
bb142:
  %t563 = load i1, ptr %l309, !tbaa !21
  br i1 %t563, label %bb143, label %bb144
bb143:
  %t564 = load ptr, ptr %l1, !tbaa !29
  %t566 = getelementptr { i64, [4 x i64] }, ptr %t564, i32 0, i32 1
  %t567 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t566, i32 0, i32 1
  %t568 = load ptr, ptr %t567
  store ptr %t568, ptr %l42, !tbaa !29
  %t570 = load ptr, ptr %l1, !tbaa !29
  %t572 = getelementptr { i64, [4 x i64] }, ptr %t570, i32 0, i32 1
  %t573 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t572, i32 0, i32 2
  %t574 = load ptr, ptr %t573
  store ptr %t574, ptr %l43, !tbaa !29
  br label %bb145
bb144:
  br label %bb148
bb145:
  %t576 = load ptr, ptr %l0, !tbaa !29
  %t577 = load ptr, ptr %l42, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t576, ptr %t577)
  br label %bb146
bb146:
  %t580 = load ptr, ptr %l0, !tbaa !29
  %t581 = load ptr, ptr %l43, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t580, ptr %t581)
  br label %bb147
bb147:
  br label %bb233
bb148:
  %t584 = load ptr, ptr %l1, !tbaa !29
  store ptr %t584, ptr %l320, !tbaa !29
  store i1 false, ptr %l321, !tbaa !21
  %t585 = load ptr, ptr %l320, !tbaa !29
  %t586 = icmp ne ptr %t585, null
  br i1 %t586, label %bb149, label %bb150
bb149:
  %t588 = load ptr, ptr %l320, !tbaa !29
  %t589 = load i64, ptr %t588, !range !{i64 0, i64 28}
  %t591 = icmp eq i64 %t589, 16
  store i1 %t591, ptr %l321, !tbaa !21
  br label %bb150
bb150:
  %t592 = load i1, ptr %l321, !tbaa !21
  br i1 %t592, label %bb151, label %bb152
bb151:
  %t593 = load ptr, ptr %l1, !tbaa !29
  %t595 = getelementptr { i64, [4 x i64] }, ptr %t593, i32 0, i32 1
  %t596 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t595, i32 0, i32 1
  %t597 = load ptr, ptr %t596
  store ptr %t597, ptr %l44, !tbaa !29
  %t599 = load ptr, ptr %l1, !tbaa !29
  %t601 = getelementptr { i64, [4 x i64] }, ptr %t599, i32 0, i32 1
  %t602 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t601, i32 0, i32 2
  %t603 = load { i64, ptr }, ptr %t602
  store { i64, ptr } %t603, ptr %l45, !tbaa !27
  br label %bb153
bb152:
  br label %bb165
bb153:
  %t605 = load ptr, ptr %l44, !tbaa !29
  %t607 = icmp eq ptr %t605, null
  %t609 = xor i1 %t607, true
  br i1 %t609, label %bb154, label %bb155
bb154:
  %t611 = load ptr, ptr %l0, !tbaa !29
  %t612 = load ptr, ptr %l44, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeRef(ptr %v0, ptr %v1, ptr %t611, ptr %t612)
  br label %bb156
bb155:
  br label %bb157
bb156:
  br label %bb157
bb157:
  %t616 = load { i64, ptr }, ptr %l45, !tbaa !27
  store { i64, ptr } %t616, ptr %l46, !tbaa !27
  store i64 0, ptr %l47, !tbaa !24
  %t618 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t620 = extractvalue { i64, ptr } %t618, 0
  store i64 %t620, ptr %l48, !tbaa !24
  br label %bb158
bb158:
  %t622 = load i64, ptr %l47, !tbaa !24
  %t623 = load i64, ptr %l48, !tbaa !24
  %t626 = icmp slt i64 %t622, %t623
  %t628 = xor i1 %t626, true
  br i1 %t628, label %bb159, label %bb160
bb159:
  br label %bb164
bb160:
  br label %bb161
bb161:
  %t630 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t630, ptr %l341, !tbaa !27
  %t631 = load i64, ptr %l47, !tbaa !24
  %t633 = getelementptr { i64, ptr }, ptr %l341, i32 0, i32 1
  %t634 = load ptr, ptr %t633, !tbaa !27
  %t635 = getelementptr ptr, ptr %t634, i64 %t631
  %t636 = load ptr, ptr %t635, !tbaa !39
  %t638 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t638, ptr %t636)
  br label %bb162
bb162:
  br label %bb163
bb163:
  %t643 = load i64, ptr %l47, !tbaa !24
  %t646 = add i64 %t643, 1
  store i64 %t646, ptr %l47, !tbaa !24
  br label %bb158
bb164:
  br label %bb233
bb165:
  %t648 = load ptr, ptr %l1, !tbaa !29
  store ptr %t648, ptr %l350, !tbaa !29
  store i1 false, ptr %l351, !tbaa !21
  %t649 = load ptr, ptr %l350, !tbaa !29
  %t650 = icmp ne ptr %t649, null
  br i1 %t650, label %bb166, label %bb167
bb166:
  %t652 = load ptr, ptr %l350, !tbaa !29
  %t653 = load i64, ptr %t652, !range !{i64 0, i64 28}
  %t655 = icmp eq i64 %t653, 17
  store i1 %t655, ptr %l351, !tbaa !21
  br label %bb167
bb167:
  %t656 = load i1, ptr %l351, !tbaa !21
  br i1 %t656, label %bb168, label %bb169
bb168:
  %t657 = load ptr, ptr %l1, !tbaa !29
  %t659 = getelementptr { i64, [4 x i64] }, ptr %t657, i32 0, i32 1
  %t660 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t659, i32 0, i32 1
  %t661 = load { i64, ptr }, ptr %t660
  store { i64, ptr } %t661, ptr %l50, !tbaa !27
  br label %bb174
bb169:
  %t663 = load ptr, ptr %l1, !tbaa !29
  store ptr %t663, ptr %l356, !tbaa !29
  store i1 false, ptr %l357, !tbaa !21
  %t664 = load ptr, ptr %l356, !tbaa !29
  %t665 = icmp ne ptr %t664, null
  br i1 %t665, label %bb170, label %bb171
bb170:
  %t667 = load ptr, ptr %l356, !tbaa !29
  %t668 = load i64, ptr %t667, !range !{i64 0, i64 28}
  %t670 = icmp eq i64 %t668, 22
  store i1 %t670, ptr %l357, !tbaa !21
  br label %bb171
bb171:
  %t671 = load i1, ptr %l357, !tbaa !21
  br i1 %t671, label %bb172, label %bb173
bb172:
  %t672 = load ptr, ptr %l1, !tbaa !29
  %t674 = getelementptr { i64, [4 x i64] }, ptr %t672, i32 0, i32 1
  %t675 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t674, i32 0, i32 1
  %t676 = load { i64, ptr }, ptr %t675
  store { i64, ptr } %t676, ptr %l50, !tbaa !27
  br label %bb174
bb173:
  br label %bb182
bb174:
  %t678 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t678, ptr %l51, !tbaa !27
  store i64 0, ptr %l52, !tbaa !24
  %t680 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t682 = extractvalue { i64, ptr } %t680, 0
  store i64 %t682, ptr %l53, !tbaa !24
  br label %bb175
bb175:
  %t684 = load i64, ptr %l52, !tbaa !24
  %t685 = load i64, ptr %l53, !tbaa !24
  %t688 = icmp slt i64 %t684, %t685
  %t690 = xor i1 %t688, true
  br i1 %t690, label %bb176, label %bb177
bb176:
  br label %bb181
bb177:
  br label %bb178
bb178:
  %t692 = load { i64, ptr }, ptr %l51, !tbaa !27
  store { i64, ptr } %t692, ptr %l369, !tbaa !27
  %t693 = load i64, ptr %l52, !tbaa !24
  %t695 = getelementptr { i64, ptr }, ptr %l369, i32 0, i32 1
  %t696 = load ptr, ptr %t695, !tbaa !27
  %t697 = getelementptr ptr, ptr %t696, i64 %t693
  %t698 = load ptr, ptr %t697, !tbaa !39
  %t700 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t700, ptr %t698)
  br label %bb179
bb179:
  br label %bb180
bb180:
  %t705 = load i64, ptr %l52, !tbaa !24
  %t708 = add i64 %t705, 1
  store i64 %t708, ptr %l52, !tbaa !24
  br label %bb175
bb181:
  br label %bb233
bb182:
  %t710 = load ptr, ptr %l1, !tbaa !29
  store ptr %t710, ptr %l378, !tbaa !29
  store i1 false, ptr %l379, !tbaa !21
  %t711 = load ptr, ptr %l378, !tbaa !29
  %t712 = icmp ne ptr %t711, null
  br i1 %t712, label %bb183, label %bb184
bb183:
  %t714 = load ptr, ptr %l378, !tbaa !29
  %t715 = load i64, ptr %t714, !range !{i64 0, i64 28}
  %t717 = icmp eq i64 %t715, 18
  store i1 %t717, ptr %l379, !tbaa !21
  br label %bb184
bb184:
  %t718 = load i1, ptr %l379, !tbaa !21
  br i1 %t718, label %bb185, label %bb186
bb185:
  %t719 = load ptr, ptr %l1, !tbaa !29
  %t721 = getelementptr { i64, [4 x i64] }, ptr %t719, i32 0, i32 1
  %t722 = getelementptr { %"compiler/source:Span", ptr }, ptr %t721, i32 0, i32 0
  %t723 = load %"compiler/source:Span", ptr %t722
  store %"compiler/source:Span" %t723, ptr %l55
  %t725 = load ptr, ptr %l1, !tbaa !29
  %t727 = getelementptr { i64, [4 x i64] }, ptr %t725, i32 0, i32 1
  %t728 = getelementptr { %"compiler/source:Span", ptr }, ptr %t727, i32 0, i32 1
  %t729 = load ptr, ptr %t728
  store ptr %t729, ptr %l56, !tbaa !29
  br label %bb187
bb186:
  br label %bb198
bb187:
  %t731 = load ptr, ptr %l56, !tbaa !29
  %t733 = getelementptr %"compiler/ast:Compr", ptr %t731, i32 0, i32 0
  %t734 = load ptr, ptr %t733, !tbaa !29
  %t736 = icmp eq ptr %t734, null
  %t738 = xor i1 %t736, true
  br i1 %t738, label %bb188, label %bb189
bb188:
  %t740 = load ptr, ptr %l0, !tbaa !29
  %t741 = load ptr, ptr %l56, !tbaa !29
  %t743 = getelementptr %"compiler/ast:Compr", ptr %t741, i32 0, i32 0
  %t744 = load ptr, ptr %t743, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeRef(ptr %v0, ptr %v1, ptr %t740, ptr %t744)
  br label %bb190
bb189:
  br label %bb191
bb190:
  br label %bb191
bb191:
  %t748 = load ptr, ptr %l0, !tbaa !29
  %t749 = load ptr, ptr %l56, !tbaa !29
  %t751 = getelementptr %"compiler/ast:Compr", ptr %t749, i32 0, i32 4
  %t752 = load ptr, ptr %t751, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t748, ptr %t752)
  br label %bb192
bb192:
  %t756 = load ptr, ptr %l0, !tbaa !29
  %t758 = call i64 @compiler_2fnames_2ecompiler_2fnames_3aResolver_2emark(ptr %v0, ptr %t756)
  store i64 %t758, ptr %l399
  br label %bb193
bb193:
  %t759 = load i64, ptr %l399, !tbaa !24
  store i64 %t759, ptr %l57, !tbaa !24
  %t760 = load ptr, ptr %l0, !tbaa !29
  %t761 = getelementptr %"compiler/source:Span", ptr %l55, i32 0, i32 0
  %t762 = load i32, ptr %t761, !tbaa !23
  %t763 = load ptr, ptr %l56, !tbaa !29
  %t765 = getelementptr %"compiler/ast:Compr", ptr %t763, i32 0, i32 2
  %t766 = load i32, ptr %t765, !tbaa !23
  %t767 = load ptr, ptr %l56, !tbaa !29
  %t769 = getelementptr %"compiler/ast:Compr", ptr %t767, i32 0, i32 3
  %t770 = load i32, ptr %t769, !tbaa !23
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eforNames(ptr %v0, ptr %t760, i32 %t762, i32 %t766, i32 %t770)
  br label %bb194
bb194:
  %t775 = load ptr, ptr %l0, !tbaa !29
  %t776 = load ptr, ptr %l56, !tbaa !29
  %t778 = getelementptr %"compiler/ast:Compr", ptr %t776, i32 0, i32 1
  %t779 = load ptr, ptr %t778, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t775, ptr %t779)
  br label %bb195
bb195:
  %t783 = load ptr, ptr %l0, !tbaa !29
  %t784 = load ptr, ptr %l56, !tbaa !29
  %t786 = getelementptr %"compiler/ast:Compr", ptr %t784, i32 0, i32 5
  %t787 = load ptr, ptr %t786, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t783, ptr %t787)
  br label %bb196
bb196:
  %t790 = load ptr, ptr %l0, !tbaa !29
  %t791 = load i64, ptr %l57, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2epopTo(ptr %v0, ptr %t790, i64 %t791)
  br label %bb197
bb197:
  br label %bb233
bb198:
  %t794 = load ptr, ptr %l1, !tbaa !29
  store ptr %t794, ptr %l415, !tbaa !29
  store i1 false, ptr %l416, !tbaa !21
  %t795 = load ptr, ptr %l415, !tbaa !29
  %t796 = icmp ne ptr %t795, null
  br i1 %t796, label %bb199, label %bb200
bb199:
  %t798 = load ptr, ptr %l415, !tbaa !29
  %t799 = load i64, ptr %t798, !range !{i64 0, i64 28}
  %t801 = icmp eq i64 %t799, 19
  store i1 %t801, ptr %l416, !tbaa !21
  br label %bb200
bb200:
  %t802 = load i1, ptr %l416, !tbaa !21
  br i1 %t802, label %bb201, label %bb202
bb201:
  %t803 = load ptr, ptr %l1, !tbaa !29
  %t805 = getelementptr { i64, [4 x i64] }, ptr %t803, i32 0, i32 1
  %t806 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t805, i32 0, i32 1
  %t807 = load ptr, ptr %t806
  store ptr %t807, ptr %l58, !tbaa !29
  %t809 = load ptr, ptr %l1, !tbaa !29
  %t811 = getelementptr { i64, [4 x i64] }, ptr %t809, i32 0, i32 1
  %t812 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t811, i32 0, i32 2
  %t813 = load { i64, ptr }, ptr %t812
  store { i64, ptr } %t813, ptr %l59, !tbaa !27
  br label %bb203
bb202:
  br label %bb206
bb203:
  %t815 = load ptr, ptr %l0, !tbaa !29
  %t816 = load ptr, ptr %l58, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t815, ptr %t816)
  br label %bb204
bb204:
  %t820 = load ptr, ptr %l0, !tbaa !29
  %t821 = load { i64, ptr }, ptr %l59, !tbaa !27
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eclauses(ptr %v0, ptr %v1, ptr %t820, { i64, ptr } %t821)
  br label %bb205
bb205:
  br label %bb233
bb206:
  %t824 = load ptr, ptr %l1, !tbaa !29
  store ptr %t824, ptr %l428, !tbaa !29
  store i1 false, ptr %l429, !tbaa !21
  %t825 = load ptr, ptr %l428, !tbaa !29
  %t826 = icmp ne ptr %t825, null
  br i1 %t826, label %bb207, label %bb208
bb207:
  %t828 = load ptr, ptr %l428, !tbaa !29
  %t829 = load i64, ptr %t828, !range !{i64 0, i64 28}
  %t831 = icmp eq i64 %t829, 20
  store i1 %t831, ptr %l429, !tbaa !21
  br label %bb208
bb208:
  %t832 = load i1, ptr %l429, !tbaa !21
  br i1 %t832, label %bb209, label %bb210
bb209:
  %t833 = load ptr, ptr %l1, !tbaa !29
  %t835 = getelementptr { i64, [4 x i64] }, ptr %t833, i32 0, i32 1
  %t836 = getelementptr { %"compiler/source:Span", ptr }, ptr %t835, i32 0, i32 1
  %t837 = load ptr, ptr %t836
  store ptr %t837, ptr %l60, !tbaa !29
  br label %bb211
bb210:
  br label %bb221
bb211:
  %t839 = load ptr, ptr %l0, !tbaa !29
  %t841 = getelementptr %"compiler/names:Resolver", ptr %t839, i32 0, i32 13
  %t842 = load i1, ptr %t841, !tbaa !21
  store i1 %t842, ptr %l61, !tbaa !21
  %t844 = load ptr, ptr %l0, !tbaa !29
  %t846 = getelementptr %"compiler/names:Resolver", ptr %t844, i32 0, i32 13
  store i1 false, ptr %t846, !tbaa !21
  %t847 = load ptr, ptr %l0, !tbaa !29
  %t849 = call i64 @compiler_2fnames_2ecompiler_2fnames_3aResolver_2emark(ptr %v0, ptr %t847)
  store i64 %t849, ptr %l438
  br label %bb212
bb212:
  %t850 = load i64, ptr %l438, !tbaa !24
  store i64 %t850, ptr %l62, !tbaa !24
  %t851 = load ptr, ptr %l0, !tbaa !29
  %t853 = getelementptr %"compiler/names:Resolver", ptr %t851, i32 0, i32 14
  store i1 true, ptr %t853, !tbaa !21
  %t854 = load ptr, ptr %l0, !tbaa !29
  %t855 = load ptr, ptr %l60, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2esig(ptr %v0, ptr %v1, ptr %t854, ptr %t855, i1 true)
  br label %bb213
bb213:
  %t858 = load ptr, ptr %l0, !tbaa !29
  %t860 = getelementptr %"compiler/names:Resolver", ptr %t858, i32 0, i32 14
  store i1 false, ptr %t860, !tbaa !21
  %t861 = load ptr, ptr %l0, !tbaa !29
  %t862 = load ptr, ptr %l60, !tbaa !29
  %t864 = getelementptr %"compiler/ast:Func", ptr %t862, i32 0, i32 3
  %t865 = load ptr, ptr %t864, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2epushSig(ptr %v0, ptr %v1, ptr %t861, ptr %t865)
  br label %bb214
bb214:
  %t868 = load ptr, ptr %l60, !tbaa !29
  %t870 = getelementptr %"compiler/ast:Func", ptr %t868, i32 0, i32 4
  %t871 = load { i64, ptr }, ptr %t870, !tbaa !27
  %t873 = extractvalue { i64, ptr } %t871, 0
  %t875 = icmp sgt i64 %t873, 0
  br i1 %t875, label %bb215, label %bb216
bb215:
  %t877 = load ptr, ptr %l0, !tbaa !29
  %t878 = load ptr, ptr %l60, !tbaa !29
  %t880 = getelementptr %"compiler/ast:Func", ptr %t878, i32 0, i32 4
  %t881 = load { i64, ptr }, ptr %t880, !tbaa !27
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eblock(ptr %v0, ptr %v1, ptr %t877, { i64, ptr } %t881)
  br label %bb217
bb216:
  br label %bb218
bb217:
  br label %bb218
bb218:
  %t884 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2epopSig(ptr %v0, ptr %t884)
  br label %bb219
bb219:
  %t886 = load ptr, ptr %l0, !tbaa !29
  %t887 = load i64, ptr %l62, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2epopTo(ptr %v0, ptr %t886, i64 %t887)
  br label %bb220
bb220:
  %t890 = load ptr, ptr %l0, !tbaa !29
  %t891 = load i1, ptr %l61, !tbaa !21
  %t894 = getelementptr %"compiler/names:Resolver", ptr %t890, i32 0, i32 13
  store i1 %t891, ptr %t894, !tbaa !21
  br label %bb233
bb221:
  %t895 = load ptr, ptr %l1, !tbaa !29
  store ptr %t895, ptr %l458, !tbaa !29
  store i1 false, ptr %l459, !tbaa !21
  %t896 = load ptr, ptr %l458, !tbaa !29
  %t897 = icmp ne ptr %t896, null
  br i1 %t897, label %bb222, label %bb223
bb222:
  %t899 = load ptr, ptr %l458, !tbaa !29
  %t900 = load i64, ptr %t899, !range !{i64 0, i64 28}
  %t902 = icmp eq i64 %t900, 21
  store i1 %t902, ptr %l459, !tbaa !21
  br label %bb223
bb223:
  %t903 = load i1, ptr %l459, !tbaa !21
  br i1 %t903, label %bb224, label %bb225
bb224:
  %t904 = load ptr, ptr %l1, !tbaa !29
  %t906 = getelementptr { i64, [4 x i64] }, ptr %t904, i32 0, i32 1
  %t907 = getelementptr { %"compiler/source:Span", ptr }, ptr %t906, i32 0, i32 1
  %t908 = load ptr, ptr %t907
  store ptr %t908, ptr %l63, !tbaa !29
  br label %bb226
bb225:
  br label %bb228
bb226:
  %t910 = load ptr, ptr %l0, !tbaa !29
  %t911 = load ptr, ptr %l63, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ematchOf(ptr %v0, ptr %v1, ptr %t910, ptr %t911)
  br label %bb227
bb227:
  br label %bb233
bb228:
  br i1 true, label %bb229, label %bb230
bb229:
  br label %bb231
bb230:
  br label %bb232
bb231:
  br label %bb233
bb232:
  call void @__olang_check_failed(ptr @olang_loc_eb7a002d6449973_70bfc0171de666c7)
  unreachable
bb233:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexprStmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca i1
  %l22 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 28}
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13, !range !{i32 0, i32 116}
  store i32 %t14, ptr %l2
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [4 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t18, i32 0, i32 2
  %t20 = load ptr, ptr %t19
  store ptr %t20, ptr %l3, !tbaa !29
  br label %bb9
bb4:
  %t22 = load ptr, ptr %l1, !tbaa !29
  store ptr %t22, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t23 = load ptr, ptr %l12, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb5, label %bb6
bb5:
  %t26 = load ptr, ptr %l12, !tbaa !29
  %t27 = load i64, ptr %t26, !range !{i64 0, i64 28}
  %t29 = icmp eq i64 %t27, 4
  store i1 %t29, ptr %l13, !tbaa !21
  br label %bb6
bb6:
  %t30 = load i1, ptr %l13, !tbaa !21
  br i1 %t30, label %bb7, label %bb8
bb7:
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr { i64, [4 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t33, i32 0, i32 1
  %t35 = load i32, ptr %t34, !range !{i32 0, i32 116}
  store i32 %t35, ptr %l2
  %t37 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr { i64, [4 x i64] }, ptr %t37, i32 0, i32 1
  %t40 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t39, i32 0, i32 2
  %t41 = load ptr, ptr %t40
  store ptr %t41, ptr %l3, !tbaa !29
  br label %bb9
bb8:
  br label %bb18
bb9:
  %t43 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t45 = trunc i64 93 to i32
  %t46 = icmp eq i32 %t43, %t45
  br i1 %t46, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l22, !tbaa !21
  br label %bb12
bb11:
  %t48 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t50 = trunc i64 94 to i32
  %t51 = icmp eq i32 %t48, %t50
  store i1 %t51, ptr %l22, !tbaa !21
  br label %bb12
bb12:
  %t53 = load i1, ptr %l22, !tbaa !21
  br i1 %t53, label %bb13, label %bb14
bb13:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etarget(ptr %v0, ptr %v1, ptr %t54, ptr %t55)
  br label %bb15
bb14:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t58, ptr %t59)
  br label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb17
bb17:
  br label %bb24
bb18:
  br i1 true, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb23
bb21:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t63, ptr %t64)
  br label %bb22
bb22:
  br label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_d0841cbd4b51f07d_335a00002a32b699)
  unreachable
bb24:
  br label %ret
ret:
  ret void
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2efirstRaises(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %lp1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %lp8 = alloca ptr
  %l9 = alloca i64
  %lp10 = alloca ptr
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l14 = alloca i64
  %l18 = alloca i64
  %l21 = alloca i64
  %l42 = alloca %"compiler/names:raised"
  %l45 = alloca i64
  %l48 = alloca ptr
  %l49 = alloca i32
  %l50 = alloca %"compiler/source:Span"
  %l51 = alloca i1
  %l53 = alloca i64
  %l55 = alloca %"compiler/names:raisedName"
  %l58 = alloca %"compiler/names:raisedName"
  %l59 = alloca ptr
  %l60 = alloca i64
  %l61 = alloca i32
  %l62 = alloca %"compiler/source:Span"
  %l64 = alloca i64
  %l66 = alloca i1
  %l70 = alloca %"compiler/names:raisedName"
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3araisedName_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l11
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store ptr %t2, ptr %lp1
  %t3 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l11
  %t4 = load ptr, ptr %lp1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %t4
  store i64 0, ptr %l2, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/names:Resolver", ptr %t5, i32 0, i32 24
  %t9 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3araised_3e_2eLen_3ccompiler_2fnames_3araised_3e(ptr %v0, ptr %t7)
  store i64 %t9, ptr %l14
  br label %bb2
bb2:
  %t10 = load i64, ptr %l14, !tbaa !24
  store i64 %t10, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t11 = load i64, ptr %l3, !tbaa !24
  %t12 = load i64, ptr %l2, !tbaa !24
  %t15 = icmp sgt i64 %t11, %t12
  br i1 %t15, label %bb3, label %bb4
bb3:
  %t17 = load i64, ptr %l4, !tbaa !24
  %t19 = icmp sgt i64 %t17, 0
  br i1 %t19, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l18, !tbaa !24
  br label %bb8
bb5:
  %t21 = load i64, ptr %l3, !tbaa !24
  %t22 = load i64, ptr %l2, !tbaa !24
  %t25 = sub i64 %t21, %t22
  %t26 = load i64, ptr %l4, !tbaa !24
  %t29 = add i64 %t25, %t26
  %t31 = sub i64 %t29, 1
  %t32 = load i64, ptr %l4, !tbaa !24
  %t35 = sdiv i64 %t31, %t32
  store i64 %t35, ptr %l21, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l21, !tbaa !24
  br label %bb7
bb7:
  %t37 = load i64, ptr %l21, !tbaa !24
  store i64 %t37, ptr %l18, !tbaa !24
  br label %bb8
bb8:
  %t38 = load i64, ptr %l18, !tbaa !24
  store i64 %t38, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb9
bb9:
  %t39 = load i64, ptr %l6, !tbaa !24
  %t40 = load i64, ptr %l5, !tbaa !24
  %t43 = icmp slt i64 %t39, %t40
  %t45 = xor i1 %t43, true
  br i1 %t45, label %bb10, label %bb11
bb10:
  br label %bb28
bb11:
  br label %bb12
bb12:
  %t47 = load i64, ptr %l2, !tbaa !24
  %t48 = load i64, ptr %l6, !tbaa !24
  %t49 = load i64, ptr %l4, !tbaa !24
  %t52 = mul i64 %t48, %t49
  %t55 = add i64 %t47, %t52
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/names:Resolver", ptr %t57, i32 0, i32 24
  %t63 = call %"compiler/names:raised" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3araised_3e_2eAt_3ccompiler_2fnames_3araised_3e(ptr %v0, ptr %v1, ptr %t59, i64 %t55)
  store %"compiler/names:raised" %t63, ptr %l42
  br label %bb13
bb13:
  %t64 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store ptr %t64, ptr %lp8
  %t65 = load %"compiler/names:raised", ptr %l42
  %t66 = load ptr, ptr %lp8
  store %"compiler/names:raised" %t65, ptr %t66
  %t67 = load ptr, ptr %lp1
  %t68 = load ptr, ptr %lp8
  %t69 = getelementptr %"compiler/names:raised", ptr %t68, i32 0, i32 0
  %t70 = load i32, ptr %t69, !tbaa !23
  %t73 = call i64 @compiler_2fnames_2eindexOfRaised(ptr %v1, ptr %t67, i32 %t70)
  store i64 %t73, ptr %l45
  br label %bb14
bb14:
  %t74 = load i64, ptr %l45, !tbaa !24
  store i64 %t74, ptr %l9, !tbaa !24
  %t75 = load i64, ptr %l9, !tbaa !24
  %t77 = icmp slt i64 %t75, 0
  br i1 %t77, label %bb15, label %bb16
bb15:
  %t79 = load ptr, ptr %lp1
  store ptr %t79, ptr %l48, !tbaa !29
  %t80 = load ptr, ptr %lp8
  %t81 = getelementptr %"compiler/names:raised", ptr %t80, i32 0, i32 0
  %t82 = load i32, ptr %t81, !tbaa !23
  store i32 %t82, ptr %l49, !tbaa !23
  %t83 = load ptr, ptr %lp8
  %t84 = getelementptr %"compiler/names:raised", ptr %t83, i32 0, i32 1
  %t85 = load %"compiler/source:Span", ptr %t84
  store %"compiler/source:Span" %t85, ptr %l50
  %t86 = load ptr, ptr %lp8
  %t87 = getelementptr %"compiler/names:raised", ptr %t86, i32 0, i32 2
  %t88 = load i1, ptr %t87, !tbaa !21
  store i1 %t88, ptr %l51, !tbaa !21
  %t89 = load ptr, ptr %lp1
  %t91 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3araisedName_3e_2eLen_H9e36587759e47da85a29e6c0abff1d1c(ptr %v1, ptr %t89)
  store i64 %t91, ptr %l53
  br label %bb17
bb16:
  br label %bb20
bb17:
  %t92 = load ptr, ptr %lp8
  %t93 = getelementptr %"compiler/names:raised", ptr %t92, i32 0, i32 3
  %t94 = load { i64, ptr }, ptr %t93, !tbaa !27
  %t95 = load i32, ptr %l49, !tbaa !23
  %t96 = load %"compiler/source:Span", ptr %l50
  %t97 = load i1, ptr %l51, !tbaa !21
  %t98 = load i64, ptr %l53, !tbaa !24
  %t100 = call %"compiler/names:raisedName" @compiler_2fnames_3araisedName_2ector(ptr %v1, ptr %v1, i32 %t95, %"compiler/source:Span" %t96, i64 1, i1 %t97, i64 %t98, { i64, ptr } %t94)
  store %"compiler/names:raisedName" %t100, ptr %l55
  br label %bb18
bb18:
  %t101 = load ptr, ptr %l48, !tbaa !29
  %t102 = load %"compiler/names:raisedName", ptr %l55
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3araisedName_3e_2ePus_Hd55e6ab57c5af931645f87a55858e9a4(ptr %v1, ptr %v1, ptr %t101, %"compiler/names:raisedName" %t102)
  br label %bb19
bb19:
  br label %bb27
bb20:
  %t103 = load ptr, ptr %lp1
  %t104 = load i64, ptr %l9, !tbaa !24
  %t107 = call %"compiler/names:raisedName" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3araisedName_3e_2eAt__H16b49ab3dab0c5fe49005bf48ab18c1b(ptr %v1, ptr %v1, ptr %t103, i64 %t104)
  store %"compiler/names:raisedName" %t107, ptr %l58
  br label %bb21
bb21:
  %t108 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 56, i64 8)
  store ptr %t108, ptr %lp10
  %t109 = load %"compiler/names:raisedName", ptr %l58
  %t110 = load ptr, ptr %lp10
  store %"compiler/names:raisedName" %t109, ptr %t110
  %t111 = load ptr, ptr %lp1
  store ptr %t111, ptr %l59, !tbaa !29
  %t112 = load i64, ptr %l9, !tbaa !24
  store i64 %t112, ptr %l60, !tbaa !24
  %t113 = load ptr, ptr %lp10
  %t114 = getelementptr %"compiler/names:raisedName", ptr %t113, i32 0, i32 0
  %t115 = load i32, ptr %t114, !tbaa !23
  store i32 %t115, ptr %l61, !tbaa !23
  %t116 = load ptr, ptr %lp10
  %t117 = getelementptr %"compiler/names:raisedName", ptr %t116, i32 0, i32 1
  %t118 = load %"compiler/source:Span", ptr %t117
  store %"compiler/source:Span" %t118, ptr %l62
  %t119 = load ptr, ptr %lp10
  %t120 = getelementptr %"compiler/names:raisedName", ptr %t119, i32 0, i32 2
  %t121 = load i64, ptr %t120, !tbaa !24
  %t123 = add i64 %t121, 1
  store i64 %t123, ptr %l64, !tbaa !24
  %t124 = load ptr, ptr %lp10
  %t125 = getelementptr %"compiler/names:raisedName", ptr %t124, i32 0, i32 3
  %t126 = load i1, ptr %t125, !tbaa !21
  br i1 %t126, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l66, !tbaa !21
  br label %bb24
bb23:
  %t128 = load ptr, ptr %lp8
  %t129 = getelementptr %"compiler/names:raised", ptr %t128, i32 0, i32 2
  %t130 = load i1, ptr %t129, !tbaa !21
  store i1 %t130, ptr %l66, !tbaa !21
  br label %bb24
bb24:
  %t132 = load ptr, ptr %lp10
  %t133 = getelementptr %"compiler/names:raisedName", ptr %t132, i32 0, i32 4
  %t134 = load i64, ptr %t133, !tbaa !24
  %t135 = load ptr, ptr %lp10
  %t136 = getelementptr %"compiler/names:raisedName", ptr %t135, i32 0, i32 5
  %t137 = load { i64, ptr }, ptr %t136, !tbaa !27
  %t138 = load i32, ptr %l61, !tbaa !23
  %t139 = load %"compiler/source:Span", ptr %l62
  %t140 = load i64, ptr %l64, !tbaa !24
  %t141 = load i1, ptr %l66, !tbaa !21
  %t144 = call %"compiler/names:raisedName" @compiler_2fnames_3araisedName_2ector(ptr %v1, ptr %v1, i32 %t138, %"compiler/source:Span" %t139, i64 %t140, i1 %t141, i64 %t134, { i64, ptr } %t137)
  store %"compiler/names:raisedName" %t144, ptr %l70
  br label %bb25
bb25:
  %t145 = load ptr, ptr %l59, !tbaa !29
  %t146 = load i64, ptr %l60, !tbaa !24
  %t147 = load %"compiler/names:raisedName", ptr %l70
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3araisedName_3e_2eSet_H6810983465e8cb9e88422e8fd071646d(ptr %v1, ptr %v1, ptr %t145, i64 %t146, %"compiler/names:raisedName" %t147)
  br label %bb26
bb26:
  br label %bb27
bb27:
  %t148 = load i64, ptr %l6, !tbaa !24
  %t151 = add i64 %t148, 1
  store i64 %t151, ptr %l6, !tbaa !24
  br label %bb9
bb28:
  %t153 = load ptr, ptr %lp1
  %t154 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t153
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t154, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eifStmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/cond:Decision"
  %l3 = alloca i32
  %l4 = alloca i1
  %l5 = alloca i1
  %l6 = alloca i1
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l16 = alloca ptr
  %l28 = alloca ptr
  %l34 = alloca %"compiler/cond:Decision"
  %l40 = alloca ptr
  %l46 = alloca ptr
  %l48 = alloca i64
  %l54 = alloca %"compiler/source:Span"
  %l57 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l63 = alloca ptr
  %l72 = alloca ptr
  %l83 = alloca ptr
  %l84 = alloca i1
  %l92 = alloca ptr
  %l102 = alloca ptr
  %l109 = alloca i1
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/names:Resolver", ptr %t1, i32 0, i32 23
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2esurveyIf(ptr %v0, ptr %v1, ptr %t6, ptr %t7)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %ret
bb4:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr %"compiler/ast:If", ptr %t10, i32 0, i32 0
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = icmp eq ptr %t13, null
  br i1 %t15, label %bb5, label %bb6
bb5:
  %t17 = load ptr, ptr %l0, !tbaa !29
  store ptr %t17, ptr %l16, !tbaa !29
  %t18 = load ptr, ptr %l1, !tbaa !29
  %t20 = getelementptr %"compiler/ast:If", ptr %t18, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t23 = icmp eq ptr %t21, null
  br i1 %t23, label %bb7, label %bb8
bb6:
  br label %bb11
bb7:
  call void @__olang_check_failed(ptr @olang_loc_886f7d48bba75e1e_e325b650ab06e3ea)
  unreachable
bb8:
  br label %bb9
bb9:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr %"compiler/ast:If", ptr %t25, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !29
  %t29 = load ptr, ptr %l16, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ebranch(ptr %v0, ptr %v1, ptr %t29, ptr %t28)
  br label %bb10
bb10:
  br label %ret
bb11:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/names:Resolver", ptr %t31, i32 0, i32 13
  store i1 true, ptr %t33, !tbaa !21
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load ptr, ptr %l1, !tbaa !29
  %t37 = getelementptr %"compiler/ast:If", ptr %t35, i32 0, i32 0
  %t38 = load ptr, ptr %t37, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t34, ptr %t38)
  br label %bb12
bb12:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/names:Resolver", ptr %t42, i32 0, i32 13
  store i1 false, ptr %t44, !tbaa !21
  %t45 = load ptr, ptr %l0, !tbaa !29
  store ptr %t45, ptr %l28, !tbaa !29
  %t46 = load ptr, ptr %l1, !tbaa !29
  %t48 = getelementptr %"compiler/ast:If", ptr %t46, i32 0, i32 0
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t51 = icmp eq ptr %t49, null
  br i1 %t51, label %bb13, label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_dbd61287de33a2c5_4d29ffa31fdf1ff1)
  unreachable
bb14:
  br label %bb15
bb15:
  %t53 = load ptr, ptr %l1, !tbaa !29
  %t55 = getelementptr %"compiler/ast:If", ptr %t53, i32 0, i32 0
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t57 = load ptr, ptr %l28, !tbaa !29
  %t59 = call %"compiler/cond:Decision" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2edecideLocal(ptr %v0, ptr %v1, ptr %t57, ptr %t56)
  store %"compiler/cond:Decision" %t59, ptr %l34
  br label %bb16
bb16:
  %t60 = load %"compiler/cond:Decision", ptr %l34
  store %"compiler/cond:Decision" %t60, ptr %l2
  %t61 = getelementptr %"compiler/cond:Decision", ptr %l2, i32 0, i32 0
  %t62 = load i32, ptr %t61, !range !{i32 0, i32 5}
  store i32 %t62, ptr %l3
  %t64 = getelementptr %"compiler/cond:Decision", ptr %l2, i32 0, i32 1
  %t65 = load i1, ptr %t64, !tbaa !21
  store i1 %t65, ptr %l4, !tbaa !21
  %t67 = load i32, ptr %l3, !range !{i32 0, i32 5}
  %t69 = trunc i64 4 to i32
  %t70 = icmp eq i32 %t67, %t69
  br i1 %t70, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s3
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr %"compiler/names:Resolver", ptr %t72, i32 0, i32 17
  store ptr %t74, ptr %l40, !tbaa !29
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/names:Resolver", ptr %t75, i32 0, i32 0
  %t78 = load ptr, ptr %t77, !tbaa !29
  %t80 = getelementptr %"compiler/load:Loader", ptr %t78, i32 0, i32 10
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/names:Resolver", ptr %t81, i32 0, i32 7
  %t84 = load i64, ptr %t83, !tbaa !24
  %t87 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t80, i64 %t84)
  store ptr %t87, ptr %l46
  br label %bb19
bb18:
  br label %bb26
bb19:
  %t88 = load ptr, ptr %l46, !tbaa !29
  %t90 = getelementptr %"compiler/load:Module", ptr %t88, i32 0, i32 4
  %t91 = load i64, ptr %t90, !tbaa !24
  store i64 %t91, ptr %l48, !tbaa !24
  %t92 = load ptr, ptr %l1, !tbaa !29
  %t94 = getelementptr %"compiler/ast:If", ptr %t92, i32 0, i32 0
  %t95 = load ptr, ptr %t94, !tbaa !29
  %t97 = icmp eq ptr %t95, null
  br i1 %t97, label %bb20, label %bb21
bb20:
  call void @__olang_check_failed(ptr @olang_loc_bee2df1b257c0b70_a796ae201fef93fc)
  unreachable
bb21:
  br label %bb22
bb22:
  %t99 = load ptr, ptr %l1, !tbaa !29
  %t101 = getelementptr %"compiler/ast:If", ptr %t99, i32 0, i32 0
  %t102 = load ptr, ptr %t101, !tbaa !29
  %t104 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t102)
  store %"compiler/source:Span" %t104, ptr %l54
  br label %bb23
bb23:
  %t105 = getelementptr %"compiler/source:Span", ptr %l54, i32 0, i32 0
  %t106 = load i32, ptr %t105, !tbaa !23
  %t108 = sext i32 %t106 to i64
  %t109 = load i64, ptr %l48, !tbaa !24
  %t111 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s3, i64 %t109, i64 %t108)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t111, ptr %l57
  br label %bb24
bb24:
  %t112 = load ptr, ptr %l40, !tbaa !29
  %t113 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l57
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %t112, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t113, i1 true)
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s3)
  br label %bb26
bb26:
  %t114 = load i32, ptr %l3, !range !{i32 0, i32 5}
  %t116 = trunc i64 0 to i32
  %t117 = icmp eq i32 %t114, %t116
  store i1 %t117, ptr %l5, !tbaa !21
  %t119 = load i32, ptr %l3, !range !{i32 0, i32 5}
  %t121 = trunc i64 1 to i32
  %t122 = icmp eq i32 %t119, %t121
  %t124 = xor i1 %t122, true
  store i1 %t124, ptr %l6, !tbaa !21
  %t126 = load ptr, ptr %l0, !tbaa !29
  store ptr %t126, ptr %l63, !tbaa !29
  %t127 = load ptr, ptr %l1, !tbaa !29
  %t129 = getelementptr %"compiler/ast:If", ptr %t127, i32 0, i32 1
  %t130 = load ptr, ptr %t129, !tbaa !29
  %t132 = icmp eq ptr %t130, null
  br i1 %t132, label %bb27, label %bb28
bb27:
  call void @__olang_check_failed(ptr @olang_loc_f74f5c810fb1384f_2035d8e6259ec36b)
  unreachable
bb28:
  br label %bb29
bb29:
  %t134 = load ptr, ptr %l1, !tbaa !29
  %t136 = getelementptr %"compiler/ast:If", ptr %t134, i32 0, i32 1
  %t137 = load ptr, ptr %t136, !tbaa !29
  %t138 = load i1, ptr %l5, !tbaa !21
  %t139 = load i1, ptr %l4, !tbaa !21
  %t140 = load i1, ptr %l6, !tbaa !21
  %t141 = load ptr, ptr %l63, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2echoose(ptr %v0, ptr %v1, ptr %t141, ptr %t137, i1 %t138, i1 %t139, i1 %t140)
  br label %bb30
bb30:
  %t146 = load ptr, ptr %l0, !tbaa !29
  store ptr %t146, ptr %l72, !tbaa !29
  %t147 = load ptr, ptr %l1, !tbaa !29
  %t149 = getelementptr %"compiler/ast:If", ptr %t147, i32 0, i32 1
  %t150 = load ptr, ptr %t149, !tbaa !29
  %t152 = icmp eq ptr %t150, null
  br i1 %t152, label %bb31, label %bb32
bb31:
  call void @__olang_check_failed(ptr @olang_loc_9a3445d364d03a02_c72e8fada9365de6)
  unreachable
bb32:
  br label %bb33
bb33:
  %t154 = load ptr, ptr %l1, !tbaa !29
  %t156 = getelementptr %"compiler/ast:If", ptr %t154, i32 0, i32 1
  %t157 = load ptr, ptr %t156, !tbaa !29
  %t158 = load ptr, ptr %l72, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ebranch(ptr %v0, ptr %v1, ptr %t158, ptr %t157)
  br label %bb34
bb34:
  %t160 = load ptr, ptr %l1, !tbaa !29
  %t162 = getelementptr %"compiler/ast:If", ptr %t160, i32 0, i32 2
  %t163 = load ptr, ptr %t162, !tbaa !29
  %t165 = icmp eq ptr %t163, null
  br i1 %t165, label %bb35, label %bb36
bb35:
  br label %ret
bb36:
  br label %bb37
bb37:
  %t167 = load ptr, ptr %l1, !tbaa !29
  %t169 = getelementptr %"compiler/ast:If", ptr %t167, i32 0, i32 2
  %t170 = load ptr, ptr %t169, !tbaa !29
  store ptr %t170, ptr %l7, !tbaa !29
  %t172 = load ptr, ptr %l7, !tbaa !29
  store ptr %t172, ptr %l83, !tbaa !29
  store i1 false, ptr %l84, !tbaa !21
  %t173 = load ptr, ptr %l83, !tbaa !29
  %t174 = icmp ne ptr %t173, null
  br i1 %t174, label %bb38, label %bb39
bb38:
  %t176 = load ptr, ptr %l83, !tbaa !29
  %t177 = load i64, ptr %t176, !range !{i64 0, i64 22}
  %t179 = icmp eq i64 %t177, 5
  store i1 %t179, ptr %l84, !tbaa !21
  br label %bb39
bb39:
  %t180 = load i1, ptr %l84, !tbaa !21
  br i1 %t180, label %bb40, label %bb41
bb40:
  %t181 = load ptr, ptr %l7, !tbaa !29
  %t183 = getelementptr { i64, [4 x i64] }, ptr %t181, i32 0, i32 1
  %t184 = getelementptr { %"compiler/source:Span", ptr }, ptr %t183, i32 0, i32 1
  %t185 = load ptr, ptr %t184
  store ptr %t185, ptr %l8, !tbaa !29
  br label %bb42
bb41:
  br label %bb62
bb42:
  %t187 = load ptr, ptr %l8, !tbaa !29
  %t189 = getelementptr %"compiler/ast:If", ptr %t187, i32 0, i32 0
  %t190 = load ptr, ptr %t189, !tbaa !29
  %t192 = icmp eq ptr %t190, null
  br i1 %t192, label %bb43, label %bb44
bb43:
  %t194 = load ptr, ptr %l0, !tbaa !29
  store ptr %t194, ptr %l92, !tbaa !29
  %t195 = load ptr, ptr %l8, !tbaa !29
  %t197 = getelementptr %"compiler/ast:If", ptr %t195, i32 0, i32 1
  %t198 = load ptr, ptr %t197, !tbaa !29
  %t200 = icmp eq ptr %t198, null
  br i1 %t200, label %bb45, label %bb46
bb44:
  %t202 = load i1, ptr %l5, !tbaa !21
  br i1 %t202, label %bb53, label %bb54
bb45:
  call void @__olang_check_failed(ptr @olang_loc_f2359f321711c0e9_83213f8b98ca37cd)
  unreachable
bb46:
  br label %bb47
bb47:
  %t204 = load ptr, ptr %l8, !tbaa !29
  %t206 = getelementptr %"compiler/ast:If", ptr %t204, i32 0, i32 1
  %t207 = load ptr, ptr %t206, !tbaa !29
  %t208 = load i1, ptr %l5, !tbaa !21
  %t209 = load i1, ptr %l4, !tbaa !21
  %t211 = xor i1 %t209, true
  %t212 = load i1, ptr %l6, !tbaa !21
  %t213 = load ptr, ptr %l92, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2echoose(ptr %v0, ptr %v1, ptr %t213, ptr %t207, i1 %t208, i1 %t211, i1 %t212)
  br label %bb48
bb48:
  %t218 = load ptr, ptr %l0, !tbaa !29
  store ptr %t218, ptr %l102, !tbaa !29
  %t219 = load ptr, ptr %l8, !tbaa !29
  %t221 = getelementptr %"compiler/ast:If", ptr %t219, i32 0, i32 1
  %t222 = load ptr, ptr %t221, !tbaa !29
  %t224 = icmp eq ptr %t222, null
  br i1 %t224, label %bb49, label %bb50
bb49:
  call void @__olang_check_failed(ptr @olang_loc_530cce065f124df4_4e8587782c204bb8)
  unreachable
bb50:
  br label %bb51
bb51:
  %t226 = load ptr, ptr %l8, !tbaa !29
  %t228 = getelementptr %"compiler/ast:If", ptr %t226, i32 0, i32 1
  %t229 = load ptr, ptr %t228, !tbaa !29
  %t230 = load ptr, ptr %l102, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ebranch(ptr %v0, ptr %v1, ptr %t230, ptr %t229)
  br label %bb52
bb52:
  br label %bb61
bb53:
  %t232 = load i1, ptr %l4, !tbaa !21
  store i1 %t232, ptr %l109, !tbaa !21
  br label %bb55
bb54:
  store i1 false, ptr %l109, !tbaa !21
  br label %bb55
bb55:
  %t234 = load i1, ptr %l109, !tbaa !21
  br i1 %t234, label %bb56, label %bb57
bb56:
  %t235 = load ptr, ptr %l0, !tbaa !29
  %t236 = load ptr, ptr %l8, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2edropAll(ptr %v0, ptr %v1, ptr %t235, ptr %t236)
  br label %bb58
bb57:
  %t239 = load ptr, ptr %l0, !tbaa !29
  %t240 = load ptr, ptr %l8, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eifStmt(ptr %v0, ptr %v1, ptr %t239, ptr %t240)
  br label %bb59
bb58:
  br label %bb60
bb59:
  br label %bb60
bb60:
  br label %bb61
bb61:
  br label %bb68
bb62:
  br i1 true, label %bb63, label %bb64
bb63:
  br label %bb65
bb64:
  br label %bb67
bb65:
  %t243 = load ptr, ptr %l0, !tbaa !29
  %t244 = load ptr, ptr %l1, !tbaa !29
  %t246 = getelementptr %"compiler/ast:If", ptr %t244, i32 0, i32 2
  %t247 = load ptr, ptr %t246, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2estmt(ptr %v0, ptr %v1, ptr %t243, ptr %t247)
  br label %bb66
bb66:
  br label %bb68
bb67:
  call void @__olang_check_failed(ptr @olang_loc_13e109869e44451a_84e972cbfcb81dee)
  unreachable
bb68:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eimportedType(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca %"compiler/load:Import"
  %l5 = alloca i32
  %l11 = alloca ptr
  %l14 = alloca i64
  %l16 = alloca i64
  %l21 = alloca %"compiler/load:Import"
  %l28 = alloca ptr
  %l32 = alloca i1
  %l33 = alloca i1
  %l36 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l39 = alloca i1
  %l40 = alloca i1
  %l45 = alloca ptr
  %l52 = alloca %"compiler/names:Ref"
  %s2 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/names:Resolver", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/load:Loader", ptr %t4, i32 0, i32 10
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/names:Resolver", ptr %t7, i32 0, i32 7
  %t10 = load i64, ptr %t9, !tbaa !24
  %t13 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t6, i64 %t10)
  store ptr %t13, ptr %l11
  br label %bb1
bb1:
  %t14 = load ptr, ptr %l11, !tbaa !29
  %t16 = getelementptr %"compiler/load:Module", ptr %t14, i32 0, i32 11
  store ptr %t16, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t18 = load i64, ptr %l3, !tbaa !24
  store i64 %t18, ptr %l14, !tbaa !24
  %t19 = load ptr, ptr %l2, !tbaa !29
  %t21 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fload_3aImport_3e_2eLen_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %t19)
  store i64 %t21, ptr %l16
  br label %bb3
bb3:
  %t22 = load i64, ptr %l14, !tbaa !24
  %t23 = load i64, ptr %l16, !tbaa !24
  %t24 = icmp slt i64 %t22, %t23
  %t26 = xor i1 %t24, true
  br i1 %t26, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s2)
  br label %bb30
bb5:
  br label %bb6
bb6:
  %t28 = load ptr, ptr %l2, !tbaa !29
  %t29 = load i64, ptr %l3, !tbaa !24
  %t32 = call %"compiler/load:Import" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fload_3aImport_3e_2eAt_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %v0, ptr %t28, i64 %t29)
  store %"compiler/load:Import" %t32, ptr %l21
  br label %bb7
bb7:
  %t33 = load %"compiler/load:Import", ptr %l21
  store %"compiler/load:Import" %t33, ptr %l4
  %t34 = getelementptr %"compiler/load:Import", ptr %l4, i32 0, i32 5
  %t35 = load i64, ptr %t34, !tbaa !24
  %t37 = icmp slt i64 %t35, 0
  br i1 %t37, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb29
bb9:
  br label %bb10
bb10:
  %t39 = load i32, ptr %l1, !tbaa !23
  store i32 %t39, ptr %l5, !tbaa !23
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/names:Resolver", ptr %t41, i32 0, i32 1
  %t44 = getelementptr %"compiler/load:Import", ptr %l4, i32 0, i32 5
  %t45 = load i64, ptr %t44, !tbaa !24
  %t48 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v0, ptr %t43, i64 %t45)
  store ptr %t48, ptr %l28
  br label %bb11
bb11:
  %t49 = load ptr, ptr %l28, !tbaa !29
  %t51 = getelementptr %"compiler/names:Table", ptr %t49, i32 0, i32 2
  %t52 = load i32, ptr %l5, !tbaa !23
  %t55 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_Hf575c52a5a9e8993bae2b73c9c2548b3(ptr %v0, ptr %t51, i32 %t52)
  store i1 %t55, ptr %l32
  br label %bb12
bb12:
  %t56 = load i1, ptr %l32, !tbaa !21
  br i1 %t56, label %bb13, label %bb14
bb13:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t58 = load i32, ptr %l1, !tbaa !23
  %t61 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %s2, ptr %t57, i32 %t58)
  store { i64, ptr } %t61, ptr %l36
  br label %bb15
bb14:
  store i1 false, ptr %l33, !tbaa !21
  br label %bb21
bb15:
  %t62 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t62, ptr %l37, !tbaa !27
  %t63 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !27
  %t65 = getelementptr i8, ptr %t64, i64 0
  %t66 = load i8, ptr %t65, !tbaa !32
  %t68 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %t66)
  store i1 %t68, ptr %l39
  br label %bb16
bb16:
  %t69 = load i1, ptr %l39, !tbaa !21
  br i1 %t69, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l40, !tbaa !21
  br label %bb20
bb18:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/names:Resolver", ptr %t70, i32 0, i32 0
  %t73 = load ptr, ptr %t72, !tbaa !29
  %t75 = getelementptr %"compiler/load:Loader", ptr %t73, i32 0, i32 10
  %t76 = getelementptr %"compiler/load:Import", ptr %l4, i32 0, i32 5
  %t77 = load i64, ptr %t76, !tbaa !24
  %t80 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t75, i64 %t77)
  store ptr %t80, ptr %l45
  br label %bb19
bb19:
  %t81 = load ptr, ptr %l45, !tbaa !29
  %t83 = getelementptr %"compiler/load:Module", ptr %t81, i32 0, i32 33
  %t84 = load i1, ptr %t83, !tbaa !21
  store i1 %t84, ptr %l40, !tbaa !21
  br label %bb20
bb20:
  %t86 = load i1, ptr %l40, !tbaa !21
  store i1 %t86, ptr %l33, !tbaa !21
  br label %bb21
bb21:
  %t87 = load i1, ptr %l33, !tbaa !21
  br i1 %t87, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %rv
  br label %ret
bb23:
  br label %bb24
bb24:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/load:Import", ptr %l4, i32 0, i32 5
  %t91 = load i64, ptr %t90, !tbaa !24
  %t92 = load i32, ptr %l1, !tbaa !23
  %t96 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2esharedType(ptr %v0, ptr %t89, i64 %t91, i32 %t92)
  store %"compiler/names:Ref" %t96, ptr %l52
  br label %bb25
bb25:
  %t97 = getelementptr %"compiler/names:Ref", ptr %l52, i32 0, i32 0
  %t98 = load i32, ptr %t97, !range !{i32 0, i32 9}
  %t100 = trunc i64 0 to i32
  %t101 = icmp eq i32 %t98, %t100
  %t103 = xor i1 %t101, true
  br i1 %t103, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %rv
  br label %ret
bb27:
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s2)
  br label %bb29
bb29:
  %t106 = load i64, ptr %l3, !tbaa !24
  %t109 = add i64 %t106, 1
  store i64 %t109, ptr %l3, !tbaa !24
  br label %bb2
bb30:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2elookup(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca %"compiler/names:Ref"
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca %"compiler/names:Ref"
  %l10 = alloca i64
  %l11 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i32
  %l22 = alloca %"compiler/names:local"
  %l27 = alloca %"compiler/names:Ref"
  %l32 = alloca ptr
  %l33 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i32
  %l44 = alloca %"compiler/names:Entry"
  %l49 = alloca %"compiler/names:Ref"
  %l50 = alloca i64
  %l54 = alloca i64
  %l55 = alloca i32
  %l62 = alloca %"compiler/names:Ref"
  %l67 = alloca %"compiler/names:Ref"
  %l72 = alloca i64
  %l76 = alloca i64
  %l77 = alloca i32
  %l84 = alloca ptr
  %l89 = alloca i64
  %l92 = alloca %"compiler/names:Ref"
  %l95 = alloca { i64, ptr }
  %l100 = alloca i1
  %l102 = alloca %"compiler/names:Ref"
  %l103 = alloca %"compiler/names:Ref"
  %l107 = alloca %"compiler/names:Ref"
  %l108 = alloca i32
  %l110 = alloca %"compiler/names:Ref"
  %l115 = alloca i64
  %l119 = alloca i64
  %l120 = alloca i32
  %l123 = alloca i32
  %l124 = alloca i64
  %l125 = alloca i64
  %l129 = alloca ptr
  %l133 = alloca i64
  %l134 = alloca i32
  %l135 = alloca %"compiler/names:Ref"
  %l137 = alloca i1
  %l139 = alloca %"compiler/names:Ref"
  %l141 = alloca %"compiler/names:Ref"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %rv = alloca %"compiler/names:Ref"
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/names:Resolver", ptr %t1, i32 0, i32 9
  %t4 = load i32, ptr %l1, !tbaa !23
  %t7 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %t3, i32 %t4)
  %t8 = extractvalue { i32, i64 } %t7, 1
  %t9 = extractvalue { i32, i64 } %t7, 0
  store i32 %t9, ptr %l16
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11, !prof !99
ok.11:
  store i64 %t8, ptr %l15
  br label %bb1
bb1:
  %t12 = load i64, ptr %l15, !tbaa !24
  store i64 %t12, ptr %l11, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  store i64 -1, ptr %l11, !tbaa !24
  br label %bb4
bb4:
  %t13 = load i64, ptr %l11, !tbaa !24
  store i64 %t13, ptr %l2, !tbaa !24
  %t14 = load i64, ptr %l2, !tbaa !24
  %t16 = icmp sge i64 %t14, 0
  br i1 %t16, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/names:Resolver", ptr %t18, i32 0, i32 8
  %t21 = load i64, ptr %l2, !tbaa !24
  %t24 = call %"compiler/names:local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3alocal_3e_2eAt_3ccompiler_2fnames_3alocal_3e(ptr %v0, ptr %t20, i64 %t21)
  store %"compiler/names:local" %t24, ptr %l22
  br label %bb7
bb6:
  br label %bb9
bb7:
  %t25 = getelementptr %"compiler/names:local", ptr %l22, i32 0, i32 2
  %t26 = load i32, ptr %t25, !range !{i32 0, i32 9}
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/names:Resolver", ptr %t27, i32 0, i32 7
  %t30 = load i64, ptr %t29, !tbaa !24
  %t31 = load i64, ptr %l2, !tbaa !24
  %t35 = call %"compiler/names:Ref" @compiler_2fnames_3aRef_2ector(ptr %s1, i32 %t26, i64 %t30, i64 %t31)
  store %"compiler/names:Ref" %t35, ptr %l27
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t36 = load %"compiler/names:Ref", ptr %l27
  store %"compiler/names:Ref" %t36, ptr %rv
  br label %ret
bb9:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/names:Resolver", ptr %t37, i32 0, i32 1
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/names:Resolver", ptr %t40, i32 0, i32 7
  %t43 = load i64, ptr %t42, !tbaa !24
  %t46 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v0, ptr %t39, i64 %t43)
  store ptr %t46, ptr %l32
  br label %bb10
bb10:
  %t47 = load ptr, ptr %l32, !tbaa !29
  store ptr %t47, ptr %l3, !tbaa !29
  %t48 = load ptr, ptr %l3, !tbaa !29
  %t50 = getelementptr %"compiler/names:Table", ptr %t48, i32 0, i32 1
  %t51 = load i32, ptr %l1, !tbaa !23
  %t54 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %t50, i32 %t51)
  %t55 = extractvalue { i32, i64 } %t54, 1
  %t56 = extractvalue { i32, i64 } %t54, 0
  store i32 %t56, ptr %l38
  %t57 = icmp ne i32 %t56, 0
  br i1 %t57, label %bb12, label %ok.58, !prof !99
ok.58:
  store i64 %t55, ptr %l37
  br label %bb11
bb11:
  %t59 = load i64, ptr %l37, !tbaa !24
  store i64 %t59, ptr %l33, !tbaa !24
  br label %bb14
bb12:
  br label %bb13
bb13:
  store i64 -1, ptr %l33, !tbaa !24
  br label %bb14
bb14:
  %t60 = load i64, ptr %l33, !tbaa !24
  store i64 %t60, ptr %l4, !tbaa !24
  %t61 = load i64, ptr %l4, !tbaa !24
  %t63 = icmp sge i64 %t61, 0
  br i1 %t63, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s2
  %t65 = load ptr, ptr %l3, !tbaa !29
  %t67 = getelementptr %"compiler/names:Table", ptr %t65, i32 0, i32 0
  %t68 = load i64, ptr %l4, !tbaa !24
  %t71 = call %"compiler/names:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %s2, ptr %t67, i64 %t68)
  store %"compiler/names:Entry" %t71, ptr %l44
  br label %bb17
bb16:
  br label %bb19
bb17:
  %t72 = getelementptr %"compiler/names:Entry", ptr %l44, i32 0, i32 2
  %t73 = load i32, ptr %t72, !range !{i32 0, i32 9}
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/names:Resolver", ptr %t74, i32 0, i32 7
  %t77 = load i64, ptr %t76, !tbaa !24
  %t78 = load i64, ptr %l4, !tbaa !24
  %t82 = call %"compiler/names:Ref" @compiler_2fnames_3aRef_2ector(ptr %s2, i32 %t73, i64 %t77, i64 %t78)
  store %"compiler/names:Ref" %t82, ptr %l49
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t83 = load %"compiler/names:Ref", ptr %l49
  store %"compiler/names:Ref" %t83, ptr %rv
  br label %ret
bb19:
  %t84 = load ptr, ptr %l3, !tbaa !29
  %t86 = getelementptr %"compiler/names:Table", ptr %t84, i32 0, i32 2
  %t87 = load i32, ptr %l1, !tbaa !23
  %t90 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %t86, i32 %t87)
  %t91 = extractvalue { i32, i64 } %t90, 1
  %t92 = extractvalue { i32, i64 } %t90, 0
  store i32 %t92, ptr %l55
  %t93 = icmp ne i32 %t92, 0
  br i1 %t93, label %bb21, label %ok.94, !prof !99
ok.94:
  store i64 %t91, ptr %l54
  br label %bb20
bb20:
  %t95 = load i64, ptr %l54, !tbaa !24
  store i64 %t95, ptr %l50, !tbaa !24
  br label %bb23
bb21:
  br label %bb22
bb22:
  store i64 -1, ptr %l50, !tbaa !24
  br label %bb23
bb23:
  %t96 = load i64, ptr %l50, !tbaa !24
  store i64 %t96, ptr %l5, !tbaa !24
  %t97 = load i64, ptr %l5, !tbaa !24
  %t99 = icmp sge i64 %t97, 0
  br i1 %t99, label %bb24, label %bb25
bb24:
  store %olang.scope zeroinitializer, ptr %s3
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr %"compiler/names:Resolver", ptr %t101, i32 0, i32 7
  %t104 = load i64, ptr %t103, !tbaa !24
  %t105 = load i64, ptr %l5, !tbaa !24
  %t109 = call %"compiler/names:Ref" @compiler_2fnames_3aRef_2ector(ptr %s3, i32 4, i64 %t104, i64 %t105)
  store %"compiler/names:Ref" %t109, ptr %l62
  br label %bb26
bb25:
  br label %bb27
bb26:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t110 = load %"compiler/names:Ref", ptr %l62
  store %"compiler/names:Ref" %t110, ptr %rv
  br label %ret
bb27:
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t114 = getelementptr %"compiler/names:Resolver", ptr %t112, i32 0, i32 7
  %t115 = load i64, ptr %t114, !tbaa !24
  %t116 = load i32, ptr %l1, !tbaa !23
  %t120 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2esharedType(ptr %v0, ptr %t111, i64 %t115, i32 %t116)
  store %"compiler/names:Ref" %t120, ptr %l67
  br label %bb28
bb28:
  %t121 = load %"compiler/names:Ref", ptr %l67
  store %"compiler/names:Ref" %t121, ptr %l6
  %t122 = getelementptr %"compiler/names:Ref", ptr %l6, i32 0, i32 0
  %t123 = load i32, ptr %t122, !range !{i32 0, i32 9}
  %t125 = trunc i64 0 to i32
  %t126 = icmp eq i32 %t123, %t125
  %t128 = xor i1 %t126, true
  br i1 %t128, label %bb29, label %bb30
bb29:
  %t130 = load %"compiler/names:Ref", ptr %l6
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/names:Ref" %t130, ptr %rv
  br label %ret
bb30:
  br label %bb31
bb31:
  %t132 = load ptr, ptr %l3, !tbaa !29
  %t134 = getelementptr %"compiler/names:Table", ptr %t132, i32 0, i32 3
  %t135 = load i32, ptr %l1, !tbaa !23
  %t138 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %t134, i32 %t135)
  %t139 = extractvalue { i32, i64 } %t138, 1
  %t140 = extractvalue { i32, i64 } %t138, 0
  store i32 %t140, ptr %l77
  %t141 = icmp ne i32 %t140, 0
  br i1 %t141, label %bb33, label %ok.142, !prof !99
ok.142:
  store i64 %t139, ptr %l76
  br label %bb32
bb32:
  %t143 = load i64, ptr %l76, !tbaa !24
  store i64 %t143, ptr %l72, !tbaa !24
  br label %bb35
bb33:
  br label %bb34
bb34:
  store i64 -1, ptr %l72, !tbaa !24
  br label %bb35
bb35:
  %t144 = load i64, ptr %l72, !tbaa !24
  store i64 %t144, ptr %l7, !tbaa !24
  %t145 = load i64, ptr %l7, !tbaa !24
  %t147 = icmp sge i64 %t145, 0
  br i1 %t147, label %bb36, label %bb37
bb36:
  store %olang.scope zeroinitializer, ptr %s5
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t151 = getelementptr %"compiler/names:Resolver", ptr %t149, i32 0, i32 23
  %t152 = load i1, ptr %t151, !tbaa !21
  %t154 = xor i1 %t152, true
  br i1 %t154, label %bb38, label %bb39
bb37:
  br label %bb44
bb38:
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t158 = getelementptr %"compiler/names:Resolver", ptr %t156, i32 0, i32 20
  store ptr %t158, ptr %l84, !tbaa !29
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t161 = getelementptr %"compiler/names:Resolver", ptr %t159, i32 0, i32 7
  %t162 = load i64, ptr %t161, !tbaa !24
  %t163 = load i32, ptr %l1, !tbaa !23
  %t167 = call i64 @compiler_2fnames_2ekey(i64 %t162, i32 %t163)
  store i64 %t167, ptr %l89
  br label %bb40
bb39:
  br label %bb42
bb40:
  %t168 = load ptr, ptr %l84, !tbaa !29
  %t169 = load i64, ptr %l89, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t168, i64 %t169, i1 true)
  br label %bb41
bb41:
  br label %bb42
bb42:
  %t170 = load i64, ptr %l7, !tbaa !24
  %t173 = call %"compiler/names:Ref" @compiler_2fnames_3aRef_2ector(ptr %s5, i32 5, i64 %t170, i64 -1)
  store %"compiler/names:Ref" %t173, ptr %l92
  br label %bb43
bb43:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t174 = load %"compiler/names:Ref", ptr %l92
  store %"compiler/names:Ref" %t174, ptr %rv
  br label %ret
bb44:
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t176 = load i32, ptr %l1, !tbaa !23
  %t179 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %v0, ptr %t175, i32 %t176)
  store { i64, ptr } %t179, ptr %l95
  br label %bb45
bb45:
  %t180 = load { i64, ptr }, ptr %l95, !tbaa !27
  store { i64, ptr } %t180, ptr %l8, !tbaa !27
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t183 = getelementptr %"compiler/names:Resolver", ptr %t181, i32 0, i32 0
  %t184 = load ptr, ptr %t183, !tbaa !29
  %t186 = getelementptr %"compiler/load:Loader", ptr %t184, i32 0, i32 1
  %t187 = load ptr, ptr %t186, !tbaa !29
  %t188 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t191 = call i1 @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eHas(ptr %v0, ptr %v0, ptr %t187, { i64, ptr } %t188)
  store i1 %t191, ptr %l100
  br label %bb46
bb46:
  %t192 = load i1, ptr %l100, !tbaa !21
  br i1 %t192, label %bb47, label %bb48
bb47:
  store %olang.scope zeroinitializer, ptr %s7
  %t194 = call %"compiler/names:Ref" @compiler_2fnames_3aRef_2ector(ptr %s7, i32 6, i64 -1, i64 -1)
  store %"compiler/names:Ref" %t194, ptr %l102
  br label %bb49
bb48:
  br label %bb50
bb49:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  %t195 = load %"compiler/names:Ref", ptr %l102
  store %"compiler/names:Ref" %t195, ptr %rv
  br label %ret
bb50:
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t198 = getelementptr %"compiler/names:Resolver", ptr %t196, i32 0, i32 3
  %t199 = load i32, ptr %l1, !tbaa !23
  %t202 = call { i32, %"compiler/names:Ref" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_H678d1b43e8b98a171ffdea8f28643d28(ptr %v0, ptr %t198, i32 %t199)
  %t203 = extractvalue { i32, %"compiler/names:Ref" } %t202, 1
  %t204 = extractvalue { i32, %"compiler/names:Ref" } %t202, 0
  store i32 %t204, ptr %l108
  %t205 = icmp ne i32 %t204, 0
  br i1 %t205, label %bb52, label %ok.206, !prof !99
ok.206:
  store %"compiler/names:Ref" %t203, ptr %l107
  br label %bb51
bb51:
  %t207 = load %"compiler/names:Ref", ptr %l107
  store %"compiler/names:Ref" %t207, ptr %l103
  br label %bb55
bb52:
  br label %bb53
bb53:
  %t209 = call %"compiler/names:Ref" @compiler_2fnames_3aRef_2ector(ptr %s0, i32 0, i64 -1, i64 -1)
  store %"compiler/names:Ref" %t209, ptr %l110
  br label %bb54
bb54:
  %t210 = load %"compiler/names:Ref", ptr %l110
  store %"compiler/names:Ref" %t210, ptr %l103
  br label %bb55
bb55:
  %t211 = load %"compiler/names:Ref", ptr %l103
  store %"compiler/names:Ref" %t211, ptr %l9
  %t212 = getelementptr %"compiler/names:Ref", ptr %l9, i32 0, i32 0
  %t213 = load i32, ptr %t212, !range !{i32 0, i32 9}
  %t215 = trunc i64 0 to i32
  %t216 = icmp eq i32 %t213, %t215
  %t218 = xor i1 %t216, true
  br i1 %t218, label %bb56, label %bb57
bb56:
  %t220 = load %"compiler/names:Ref", ptr %l9
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/names:Ref" %t220, ptr %rv
  br label %ret
bb57:
  br label %bb58
bb58:
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t224 = getelementptr %"compiler/names:Resolver", ptr %t222, i32 0, i32 2
  %t225 = load i32, ptr %l1, !tbaa !23
  %t228 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %t224, i32 %t225)
  %t229 = extractvalue { i32, i64 } %t228, 1
  %t230 = extractvalue { i32, i64 } %t228, 0
  store i32 %t230, ptr %l120
  %t231 = icmp ne i32 %t230, 0
  br i1 %t231, label %bb60, label %ok.232, !prof !99
ok.232:
  store i64 %t229, ptr %l119
  br label %bb59
bb59:
  %t233 = load i64, ptr %l119, !tbaa !24
  store i64 %t233, ptr %l115, !tbaa !24
  br label %bb62
bb60:
  br label %bb61
bb61:
  store i64 -1, ptr %l115, !tbaa !24
  br label %bb62
bb62:
  %t234 = load i64, ptr %l115, !tbaa !24
  store i64 %t234, ptr %l10, !tbaa !24
  %t235 = load i64, ptr %l10, !tbaa !24
  %t237 = icmp sge i64 %t235, 0
  br i1 %t237, label %bb63, label %bb64
bb63:
  store %olang.scope zeroinitializer, ptr %s9
  store i32 4, ptr %l123
  %t239 = load i64, ptr %l10, !tbaa !24
  store i64 %t239, ptr %l124, !tbaa !24
  %t240 = load ptr, ptr %l0, !tbaa !29
  %t242 = getelementptr %"compiler/names:Resolver", ptr %t240, i32 0, i32 1
  %t243 = load i64, ptr %l10, !tbaa !24
  %t246 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v0, ptr %t242, i64 %t243)
  store ptr %t246, ptr %l129
  br label %bb65
bb64:
  br label %bb71
bb65:
  %t247 = load ptr, ptr %l129, !tbaa !29
  %t249 = getelementptr %"compiler/names:Table", ptr %t247, i32 0, i32 2
  %t250 = load i32, ptr %l1, !tbaa !23
  %t253 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %t249, i32 %t250)
  %t254 = extractvalue { i32, i64 } %t253, 1
  %t255 = extractvalue { i32, i64 } %t253, 0
  store i32 %t255, ptr %l134
  %t256 = icmp ne i32 %t255, 0
  br i1 %t256, label %bb67, label %ok.257, !prof !99
ok.257:
  store i64 %t254, ptr %l133
  br label %bb66
bb66:
  %t258 = load i64, ptr %l133, !tbaa !24
  store i64 %t258, ptr %l125, !tbaa !24
  br label %bb69
bb67:
  br label %bb68
bb68:
  store i64 -1, ptr %l125, !tbaa !24
  br label %bb69
bb69:
  %t259 = load i32, ptr %l123, !range !{i32 0, i32 9}
  %t260 = load i64, ptr %l124, !tbaa !24
  %t261 = load i64, ptr %l125, !tbaa !24
  %t262 = call %"compiler/names:Ref" @compiler_2fnames_3aRef_2ector(ptr %s9, i32 %t259, i64 %t260, i64 %t261)
  store %"compiler/names:Ref" %t262, ptr %l135
  br label %bb70
bb70:
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s0)
  %t263 = load %"compiler/names:Ref", ptr %l135
  store %"compiler/names:Ref" %t263, ptr %rv
  br label %ret
bb71:
  %t264 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t266 = call i1 @compiler_2fnames_2eBuiltinTypeName(ptr %v0, { i64, ptr } %t264)
  store i1 %t266, ptr %l137
  br label %bb72
bb72:
  %t267 = load i1, ptr %l137, !tbaa !21
  br i1 %t267, label %bb73, label %bb74
bb73:
  store %olang.scope zeroinitializer, ptr %s10
  %t269 = call %"compiler/names:Ref" @compiler_2fnames_3aRef_2ector(ptr %s10, i32 7, i64 -1, i64 -1)
  store %"compiler/names:Ref" %t269, ptr %l139
  br label %bb75
bb74:
  br label %bb76
bb75:
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s0)
  %t270 = load %"compiler/names:Ref", ptr %l139
  store %"compiler/names:Ref" %t270, ptr %rv
  br label %ret
bb76:
  %t272 = call %"compiler/names:Ref" @compiler_2fnames_3aRef_2ector(ptr %s0, i32 0, i64 -1, i64 -1)
  store %"compiler/names:Ref" %t272, ptr %l141
  br label %bb77
bb77:
  call void @__olang_scope_close(ptr %s0)
  %t273 = load %"compiler/names:Ref", ptr %l141
  store %"compiler/names:Ref" %t273, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/names:Ref", ptr %rv
  ret %"compiler/names:Ref" %rr
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2emember(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca %"compiler/names:Ref"
  %l8 = alloca i64
  %l14 = alloca %"compiler/names:Ref"
  %l18 = alloca ptr
  %l19 = alloca i64
  %l20 = alloca %"compiler/names:Ref"
  %l21 = alloca i32
  %l22 = alloca i32
  %l25 = alloca { i64, ptr }
  %l30 = alloca %"compiler/source:Span"
  %l32 = alloca ptr
  %l38 = alloca ptr
  %l42 = alloca i64
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t5 = call i64 @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ealiasTarget(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  store i64 %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load i64, ptr %l8, !tbaa !24
  store i64 %t6, ptr %l4, !tbaa !24
  %t7 = load i64, ptr %l4, !tbaa !24
  %t9 = icmp sge i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load i64, ptr %l4, !tbaa !24
  %t13 = load i32, ptr %l3, !tbaa !23
  %t17 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ememberOf(ptr %v0, ptr %t11, i64 %t12, i32 %t13)
  store %"compiler/names:Ref" %t17, ptr %l14
  br label %bb4
bb3:
  br label %bb14
bb4:
  %t18 = load %"compiler/names:Ref", ptr %l14
  store %"compiler/names:Ref" %t18, ptr %l5
  %t19 = getelementptr %"compiler/names:Ref", ptr %l5, i32 0, i32 0
  %t20 = load i32, ptr %t19, !range !{i32 0, i32 9}
  %t22 = trunc i64 0 to i32
  %t23 = icmp eq i32 %t20, %t22
  %t25 = xor i1 %t23, true
  br i1 %t25, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s2
  %t27 = load ptr, ptr %l0, !tbaa !29
  store ptr %t27, ptr %l18, !tbaa !29
  %t28 = load i64, ptr %l4, !tbaa !24
  store i64 %t28, ptr %l19, !tbaa !24
  %t29 = load %"compiler/names:Ref", ptr %l5
  store %"compiler/names:Ref" %t29, ptr %l20
  %t30 = load i32, ptr %l3, !tbaa !23
  store i32 %t30, ptr %l21, !tbaa !23
  %t31 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t32 = load i32, ptr %t31, !tbaa !23
  store i32 %t32, ptr %l22, !tbaa !23
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load i32, ptr %l3, !tbaa !23
  %t37 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %s2, ptr %t33, i32 %t34)
  store { i64, ptr } %t37, ptr %l25
  br label %bb7
bb6:
  br label %bb13
bb7:
  %t38 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t38, 0
  %t41 = trunc i64 %t39 to i32
  %t42 = load i32, ptr %l22, !tbaa !23
  %t44 = sub i32 %t42, %t41
  %t45 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t46 = load i32, ptr %t45, !tbaa !23
  %t49 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s2, i32 %t44, i32 %t46)
  store %"compiler/source:Span" %t49, ptr %l30
  br label %bb8
bb8:
  %t50 = load ptr, ptr %l18, !tbaa !29
  %t51 = load i64, ptr %l19, !tbaa !24
  %t52 = load %"compiler/names:Ref", ptr %l20
  %t53 = load i32, ptr %l21, !tbaa !23
  %t54 = load %"compiler/source:Span", ptr %l30
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2enotPrivate(ptr %v0, ptr %t50, i64 %t51, %"compiler/names:Ref" %t52, i32 %t53, %"compiler/source:Span" %t54)
  br label %bb9
bb9:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/names:Resolver", ptr %t55, i32 0, i32 5
  store ptr %t57, ptr %l32, !tbaa !29
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/names:Resolver", ptr %t58, i32 0, i32 0
  %t61 = load ptr, ptr %t60, !tbaa !29
  %t63 = getelementptr %"compiler/load:Loader", ptr %t61, i32 0, i32 10
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/names:Resolver", ptr %t64, i32 0, i32 7
  %t67 = load i64, ptr %t66, !tbaa !24
  %t70 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t63, i64 %t67)
  store ptr %t70, ptr %l38
  br label %bb10
bb10:
  %t71 = load ptr, ptr %l38, !tbaa !29
  %t73 = getelementptr %"compiler/load:Module", ptr %t71, i32 0, i32 4
  %t74 = load i64, ptr %t73, !tbaa !24
  %t75 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t76 = load i32, ptr %t75, !tbaa !23
  %t79 = call i64 @compiler_2fnames_2ekey(i64 %t74, i32 %t76)
  store i64 %t79, ptr %l42
  br label %bb11
bb11:
  %t80 = load %"compiler/names:Ref", ptr %l5
  %t81 = load ptr, ptr %l32, !tbaa !29
  %t82 = load i64, ptr %l42, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fnames_3aRef_3e_2eP_Hb17c37756f956998a4fa74bcac088344(ptr %v0, ptr %t81, i64 %t82, %"compiler/names:Ref" %t80)
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %bb13
bb13:
  br label %ret
bb14:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t85 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t84, ptr %t85)
  br label %bb15
bb15:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fnames_2ecompiler_2fnames_3aResolver_2emethodsNamed(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l12 = alloca ptr
  %l21 = alloca { i64, ptr }
  %l24 = alloca ptr
  %l25 = alloca i1
  %l33 = alloca i1
  %l41 = alloca i1
  %l43 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l48 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/names:Resolver", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/load:Loader", ptr %t4, i32 0, i32 10
  %t10 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t6, i64 %a2)
  store ptr %t10, ptr %l12
  br label %bb1
bb1:
  %t11 = load ptr, ptr %l12, !tbaa !29
  %t13 = getelementptr %"compiler/load:Module", ptr %t11, i32 0, i32 8
  %t14 = load { i64, ptr }, ptr %t13, !tbaa !27
  store { i64, ptr } %t14, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t16 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t16, 0
  store i64 %t18, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t20 = load i64, ptr %l4, !tbaa !24
  %t21 = load i64, ptr %l5, !tbaa !24
  %t24 = icmp slt i64 %t20, %t21
  %t26 = xor i1 %t24, true
  br i1 %t26, label %bb3, label %bb4
bb3:
  br label %bb33
bb4:
  br label %bb5
bb5:
  %t28 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t28, ptr %l21, !tbaa !27
  %t29 = load i64, ptr %l4, !tbaa !24
  %t31 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = getelementptr ptr, ptr %t32, i64 %t29
  %t34 = load ptr, ptr %t33, !tbaa !39
  store ptr %t34, ptr %l6, !tbaa !29
  %t36 = load ptr, ptr %l6, !tbaa !29
  store ptr %t36, ptr %l24, !tbaa !29
  store i1 false, ptr %l25, !tbaa !21
  %t37 = load ptr, ptr %l24, !tbaa !29
  %t38 = icmp ne ptr %t37, null
  br i1 %t38, label %bb6, label %bb7
bb6:
  %t40 = load ptr, ptr %l24, !tbaa !29
  %t41 = load i64, ptr %t40, !range !{i64 0, i64 12}
  %t43 = icmp eq i64 %t41, 0
  store i1 %t43, ptr %l25, !tbaa !21
  br label %bb7
bb7:
  %t44 = load i1, ptr %l25, !tbaa !21
  br i1 %t44, label %bb8, label %bb9
bb8:
  %t45 = load ptr, ptr %l6, !tbaa !29
  %t47 = getelementptr { i64, [8 x i64] }, ptr %t45, i32 0, i32 1
  %t48 = getelementptr { ptr }, ptr %t47, i32 0, i32 0
  %t49 = load ptr, ptr %t48
  store ptr %t49, ptr %l7, !tbaa !29
  br label %bb10
bb9:
  br label %bb26
bb10:
  %t51 = load ptr, ptr %l7, !tbaa !29
  %t53 = getelementptr %"compiler/ast:Func", ptr %t51, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !29
  %t56 = icmp eq ptr %t54, null
  br i1 %t56, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l33, !tbaa !21
  br label %bb17
bb12:
  %t58 = load ptr, ptr %l7, !tbaa !29
  %t60 = getelementptr %"compiler/ast:Func", ptr %t58, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !29
  %t63 = icmp eq ptr %t61, null
  br i1 %t63, label %bb13, label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_80db847ecdc1ab20_b5fcfe3f659aa7a4)
  unreachable
bb14:
  br label %bb15
bb15:
  %t65 = load ptr, ptr %l7, !tbaa !29
  %t67 = getelementptr %"compiler/ast:Func", ptr %t65, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !29
  %t71 = getelementptr %"compiler/ast:Param", ptr %t68, i32 0, i32 2
  %t72 = load ptr, ptr %t71, !tbaa !29
  %t74 = call i1 @compiler_2fnames_2eforeignRecv(ptr %v0, ptr %t72)
  store i1 %t74, ptr %l41
  br label %bb16
bb16:
  %t75 = load i1, ptr %l41, !tbaa !21
  %t76 = xor i1 %t75, true
  store i1 %t76, ptr %l33, !tbaa !21
  br label %bb17
bb17:
  %t78 = load i1, ptr %l33, !tbaa !21
  br i1 %t78, label %bb18, label %bb19
bb18:
  br label %bb32
bb19:
  br label %bb20
bb20:
  store { i64, ptr } %a1, ptr %l43, !tbaa !27
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load ptr, ptr %l7, !tbaa !29
  %t83 = getelementptr %"compiler/ast:Func", ptr %t81, i32 0, i32 2
  %t84 = load i32, ptr %t83, !tbaa !23
  %t87 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %v0, ptr %t80, i32 %t84)
  store { i64, ptr } %t87, ptr %l47
  br label %bb21
bb21:
  %t88 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t89 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t90 = call i1 @compiler_2fnames_2ementionsMember(ptr %v1, ptr %v0, { i64, ptr } %t88, { i64, ptr } %t89)
  store i1 %t90, ptr %l48
  br label %bb22
bb22:
  %t91 = load i1, ptr %l48, !tbaa !21
  br i1 %t91, label %bb23, label %bb24
bb23:
  store i1 true, ptr %rv
  br label %ret
bb24:
  br label %bb25
bb25:
  br label %bb31
bb26:
  br i1 true, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb31
bb30:
  call void @__olang_check_failed(ptr @olang_loc_7d53eb57251aa886_389a79dd3a03050a)
  unreachable
bb31:
  br label %bb32
bb32:
  %t93 = load i64, ptr %l4, !tbaa !24
  %t96 = add i64 %t93, 1
  store i64 %t96, ptr %l4, !tbaa !24
  br label %bb2
bb33:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2emulti(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca %"compiler/source:Span"
  %l11 = alloca i32
  %l20 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l40 = alloca ptr
  %l41 = alloca i1
  %l50 = alloca i1
  %l53 = alloca { i64, ptr }
  %l54 = alloca i1
  %l59 = alloca ptr
  %l60 = alloca i1
  %s5 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Multi", ptr %t1, i32 0, i32 2
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  br label %bb7
bb3:
  br label %bb4
bb4:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %l20, !tbaa !27
  %t19 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr ptr, ptr %t22, i64 %t19
  %t24 = load ptr, ptr %t23, !tbaa !39
  %t26 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t26, ptr %t24)
  br label %bb5
bb5:
  br label %bb6
bb6:
  %t31 = load i64, ptr %l3, !tbaa !24
  %t34 = add i64 %t31, 1
  store i64 %t34, ptr %l3, !tbaa !24
  br label %bb1
bb7:
  %t36 = load ptr, ptr %l1, !tbaa !29
  %t38 = getelementptr %"compiler/ast:Multi", ptr %t36, i32 0, i32 0
  %t39 = load { i64, ptr }, ptr %t38, !tbaa !27
  store { i64, ptr } %t39, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t41 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t41, 0
  store i64 %t43, ptr %l8, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s5
  %t45 = load i64, ptr %l7, !tbaa !24
  %t46 = load i64, ptr %l8, !tbaa !24
  %t49 = icmp slt i64 %t45, %t46
  %t51 = xor i1 %t49, true
  br i1 %t51, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s5)
  br label %bb41
bb10:
  br label %bb11
bb11:
  %t53 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t53, ptr %l37, !tbaa !27
  %t54 = load i64, ptr %l7, !tbaa !24
  %t56 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !27
  %t58 = getelementptr ptr, ptr %t57, i64 %t54
  %t59 = load ptr, ptr %t58, !tbaa !39
  store ptr %t59, ptr %l9, !tbaa !29
  %t61 = load ptr, ptr %l9, !tbaa !29
  store ptr %t61, ptr %l40, !tbaa !29
  store i1 false, ptr %l41, !tbaa !21
  %t62 = load ptr, ptr %l40, !tbaa !29
  %t63 = icmp ne ptr %t62, null
  br i1 %t63, label %bb12, label %bb13
bb12:
  %t65 = load ptr, ptr %l40, !tbaa !29
  %t66 = load i64, ptr %t65, !range !{i64 0, i64 28}
  %t68 = icmp eq i64 %t66, 0
  store i1 %t68, ptr %l41, !tbaa !21
  br label %bb13
bb13:
  %t69 = load i1, ptr %l41, !tbaa !21
  br i1 %t69, label %bb14, label %bb15
bb14:
  %t70 = load ptr, ptr %l9, !tbaa !29
  %t72 = getelementptr { i64, [4 x i64] }, ptr %t70, i32 0, i32 1
  %t73 = getelementptr { %"compiler/source:Span", i32 }, ptr %t72, i32 0, i32 0
  %t74 = load %"compiler/source:Span", ptr %t73
  store %"compiler/source:Span" %t74, ptr %l10
  %t76 = load ptr, ptr %l9, !tbaa !29
  %t78 = getelementptr { i64, [4 x i64] }, ptr %t76, i32 0, i32 1
  %t79 = getelementptr { %"compiler/source:Span", i32 }, ptr %t78, i32 0, i32 1
  %t80 = load i32, ptr %t79
  store i32 %t80, ptr %l11, !tbaa !23
  br label %bb16
bb15:
  br label %bb25
bb16:
  %t82 = load ptr, ptr %l1, !tbaa !29
  %t84 = getelementptr %"compiler/ast:Multi", ptr %t82, i32 0, i32 1
  %t85 = load i1, ptr %t84, !tbaa !21
  br i1 %t85, label %bb17, label %bb18
bb17:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t88 = load i32, ptr %l11, !tbaa !23
  %t91 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %v0, ptr %t87, i32 %t88)
  store { i64, ptr } %t91, ptr %l53
  br label %bb19
bb18:
  store i1 false, ptr %l50, !tbaa !21
  br label %bb21
bb19:
  %t92 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t93 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s5, { i64, ptr } %t92, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d12, i32 0, i32 1) })
  store i1 %t93, ptr %l54
  br label %bb20
bb20:
  %t94 = load i1, ptr %l54, !tbaa !21
  %t95 = xor i1 %t94, true
  store i1 %t95, ptr %l50, !tbaa !21
  br label %bb21
bb21:
  %t97 = load i1, ptr %l50, !tbaa !21
  br i1 %t97, label %bb22, label %bb23
bb22:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t99 = load i32, ptr %l11, !tbaa !23
  %t100 = load %"compiler/source:Span", ptr %l10
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2edeclareRead(ptr %v0, ptr %t98, i32 %t99, %"compiler/source:Span" %t100, i1 true)
  br label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb39
bb25:
  %t104 = load ptr, ptr %l9, !tbaa !29
  store ptr %t104, ptr %l59, !tbaa !29
  store i1 false, ptr %l60, !tbaa !21
  %t105 = load ptr, ptr %l59, !tbaa !29
  %t106 = icmp ne ptr %t105, null
  br i1 %t106, label %bb26, label %bb27
bb26:
  %t108 = load ptr, ptr %l59, !tbaa !29
  %t109 = load i64, ptr %t108, !range !{i64 0, i64 28}
  %t111 = icmp eq i64 %t109, 0
  store i1 %t111, ptr %l60, !tbaa !21
  br label %bb27
bb27:
  %t112 = load i1, ptr %l60, !tbaa !21
  br i1 %t112, label %bb28, label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb33
bb30:
  %t113 = load ptr, ptr %l1, !tbaa !29
  %t115 = getelementptr %"compiler/ast:Multi", ptr %t113, i32 0, i32 1
  %t116 = load i1, ptr %t115, !tbaa !21
  br i1 %t116, label %bb31, label %bb32
bb31:
  br label %bb39
bb32:
  br label %bb33
bb33:
  br i1 true, label %bb34, label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb38
bb36:
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t119 = load ptr, ptr %l9, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etarget(ptr %v0, ptr %v1, ptr %t118, ptr %t119)
  br label %bb37
bb37:
  br label %bb39
bb38:
  call void @__olang_check_failed(ptr @olang_loc_9ceebceeac4e7745_86123446739d71b9)
  unreachable
bb39:
  call void @__olang_scope_close(ptr %s5)
  br label %bb40
bb40:
  %t122 = load i64, ptr %l7, !tbaa !24
  %t125 = add i64 %t122, 1
  store i64 %t125, ptr %l7, !tbaa !24
  br label %bb8
bb41:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ename(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l3 = alloca %"compiler/names:Ref"
  %l6 = alloca %"compiler/names:Ref"
  %l14 = alloca i1
  %l17 = alloca i1
  %l20 = alloca { i64, ptr }
  %l21 = alloca i1
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  %t5 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2elookup(ptr %v0, ptr %t1, i32 %t2)
  store %"compiler/names:Ref" %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load %"compiler/names:Ref", ptr %l6
  store %"compiler/names:Ref" %t6, ptr %l3
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load %"compiler/source:Span", ptr %l1
  %t9 = load %"compiler/names:Ref", ptr %l3
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2erecord(ptr %v0, ptr %t7, %"compiler/source:Span" %t8, %"compiler/names:Ref" %t9)
  br label %bb2
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load %"compiler/names:Ref", ptr %l3
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eread(ptr %v0, ptr %t13, %"compiler/names:Ref" %t14)
  br label %bb3
bb3:
  %t17 = getelementptr %"compiler/names:Ref", ptr %l3, i32 0, i32 0
  %t18 = load i32, ptr %t17, !range !{i32 0, i32 9}
  %t20 = trunc i64 0 to i32
  %t21 = icmp eq i32 %t18, %t20
  br i1 %t21, label %bb4, label %bb5
bb4:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/names:Resolver", ptr %t23, i32 0, i32 13
  %t26 = load i1, ptr %t25, !tbaa !21
  store i1 %t26, ptr %l14, !tbaa !21
  br label %bb6
bb5:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb6
bb6:
  %t28 = load i1, ptr %l14, !tbaa !21
  br i1 %t28, label %bb7, label %bb8
bb7:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t30 = load i32, ptr %l2, !tbaa !23
  %t33 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %v0, ptr %t29, i32 %t30)
  store { i64, ptr } %t33, ptr %l20
  br label %bb9
bb8:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb11
bb9:
  %t34 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t35 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t34, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d13, i32 0, i32 1) })
  store i1 %t35, ptr %l21
  br label %bb10
bb10:
  %t36 = load i1, ptr %l21, !tbaa !21
  %t37 = xor i1 %t36, true
  store i1 %t37, ptr %l17, !tbaa !21
  br label %bb11
bb11:
  %t39 = load i1, ptr %l17, !tbaa !21
  br i1 %t39, label %bb12, label %bb13
bb12:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load %"compiler/source:Span", ptr %l1
  %t42 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eunknownInCond(ptr %v0, ptr %t40, %"compiler/source:Span" %t41, i32 %t42)
  br label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/source:Span" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2enameSpan(ptr %v0, ptr %a0, i64 %a1, i32 %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca %"compiler/token:Token"
  %l21 = alloca ptr
  %l39 = alloca { i64, ptr }
  %l49 = alloca { i64, ptr }
  %l56 = alloca i64
  %l59 = alloca i64
  %l77 = alloca { i64, ptr }
  %l82 = alloca i1
  %l89 = alloca i1
  %l96 = alloca { i64, ptr }
  %l98 = alloca i64
  %l100 = alloca i64
  %l101 = alloca i64
  %l107 = alloca i1
  %l110 = alloca %"compiler/source:Span"
  %l116 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/names:Resolver", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/load:Loader", ptr %t4, i32 0, i32 10
  %t10 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t6, i64 %a1)
  store ptr %t10, ptr %l21
  br label %bb1
bb1:
  %t11 = load ptr, ptr %l21, !tbaa !29
  store ptr %t11, ptr %l4, !tbaa !29
  %t12 = load ptr, ptr %l4, !tbaa !29
  %t14 = getelementptr %"compiler/load:Module", ptr %t12, i32 0, i32 7
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = icmp eq ptr %t15, null
  br i1 %t17, label %bb2, label %bb3
bb2:
  call void @__olang_check_failed(ptr @olang_loc_8d565d6672144814_e400a405fc887290)
  unreachable
bb3:
  br label %bb4
bb4:
  %t19 = load ptr, ptr %l4, !tbaa !29
  %t21 = getelementptr %"compiler/load:Module", ptr %t19, i32 0, i32 7
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t25 = getelementptr %"compiler/scan:Tokens", ptr %t22, i32 0, i32 0
  %t26 = load { i64, ptr }, ptr %t25, !tbaa !27
  store { i64, ptr } %t26, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t28 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t28, 0
  store i64 %t30, ptr %l7, !tbaa !24
  br label %bb5
bb5:
  %t32 = load i64, ptr %l6, !tbaa !24
  %t33 = load i64, ptr %l7, !tbaa !24
  %t36 = icmp slt i64 %t32, %t33
  %t38 = xor i1 %t36, true
  br i1 %t38, label %bb6, label %bb7
bb6:
  br label %bb13
bb7:
  br label %bb8
bb8:
  %t40 = load i64, ptr %l6, !tbaa !24
  %t41 = load i64, ptr %l7, !tbaa !24
  %t44 = add i64 %t40, %t41
  %t46 = sdiv i64 %t44, 2
  store i64 %t46, ptr %l8, !tbaa !24
  %t48 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t48, ptr %l39, !tbaa !27
  %t49 = load i64, ptr %l8, !tbaa !24
  %t51 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !27
  %t53 = getelementptr %"compiler/token:Token", ptr %t52, i64 %t49
  %t54 = getelementptr %"compiler/token:Token", ptr %t53, i32 0, i32 2
  %t55 = load i32, ptr %t54, !tbaa !23
  %t56 = load i32, ptr %l2, !tbaa !23
  %t59 = icmp slt i32 %t55, %t56
  br i1 %t59, label %bb9, label %bb10
bb9:
  %t61 = load i64, ptr %l8, !tbaa !24
  %t63 = add i64 %t61, 1
  store i64 %t63, ptr %l6, !tbaa !24
  br label %bb11
bb10:
  %t65 = load i64, ptr %l8, !tbaa !24
  store i64 %t65, ptr %l7, !tbaa !24
  br label %bb11
bb11:
  br label %bb12
bb12:
  br label %bb5
bb13:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t71 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %v0, ptr %t67, i32 %a3)
  store { i64, ptr } %t71, ptr %l49
  br label %bb14
bb14:
  %t72 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t72, ptr %l9, !tbaa !27
  %t73 = load i64, ptr %l6, !tbaa !24
  store i64 %t73, ptr %l10, !tbaa !24
  %t75 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t77 = extractvalue { i64, ptr } %t75, 0
  store i64 %t77, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t79 = load i64, ptr %l11, !tbaa !24
  %t80 = load i64, ptr %l10, !tbaa !24
  %t83 = icmp sgt i64 %t79, %t80
  br i1 %t83, label %bb15, label %bb16
bb15:
  %t85 = load i64, ptr %l12, !tbaa !24
  %t87 = icmp sgt i64 %t85, 0
  br i1 %t87, label %bb17, label %bb18
bb16:
  store i64 0, ptr %l56, !tbaa !24
  br label %bb20
bb17:
  %t89 = load i64, ptr %l11, !tbaa !24
  %t90 = load i64, ptr %l10, !tbaa !24
  %t93 = sub i64 %t89, %t90
  %t94 = load i64, ptr %l12, !tbaa !24
  %t97 = add i64 %t93, %t94
  %t99 = sub i64 %t97, 1
  %t100 = load i64, ptr %l12, !tbaa !24
  %t103 = sdiv i64 %t99, %t100
  store i64 %t103, ptr %l59, !tbaa !24
  br label %bb19
bb18:
  store i64 0, ptr %l59, !tbaa !24
  br label %bb19
bb19:
  %t105 = load i64, ptr %l59, !tbaa !24
  store i64 %t105, ptr %l56, !tbaa !24
  br label %bb20
bb20:
  %t106 = load i64, ptr %l56, !tbaa !24
  store i64 %t106, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb21
bb21:
  %t107 = load i64, ptr %l14, !tbaa !24
  %t108 = load i64, ptr %l13, !tbaa !24
  %t111 = icmp slt i64 %t107, %t108
  %t113 = xor i1 %t111, true
  br i1 %t113, label %bb22, label %bb23
bb22:
  br label %bb49
bb23:
  br label %bb24
bb24:
  %t115 = load i64, ptr %l10, !tbaa !24
  %t116 = load i64, ptr %l14, !tbaa !24
  %t117 = load i64, ptr %l12, !tbaa !24
  %t120 = mul i64 %t116, %t117
  %t123 = add i64 %t115, %t120
  store i64 %t123, ptr %l15, !tbaa !24
  %t125 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t125, ptr %l77, !tbaa !27
  %t126 = load i64, ptr %l15, !tbaa !24
  %t128 = getelementptr { i64, ptr }, ptr %l77, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !27
  %t130 = getelementptr %"compiler/token:Token", ptr %t129, i64 %t126
  %t131 = load %"compiler/token:Token", ptr %t130
  store %"compiler/token:Token" %t131, ptr %l16
  %t133 = getelementptr %"compiler/token:Token", ptr %l16, i32 0, i32 0
  %t134 = load i32, ptr %t133, !range !{i32 0, i32 116}
  %t136 = trunc i64 0 to i32
  %t137 = icmp eq i32 %t134, %t136
  br i1 %t137, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l82, !tbaa !21
  br label %bb27
bb26:
  %t139 = load i64, ptr %l15, !tbaa !24
  %t140 = load i64, ptr %l6, !tbaa !24
  %t143 = sub i64 %t139, %t140
  %t145 = icmp sgt i64 %t143, 256
  store i1 %t145, ptr %l82, !tbaa !21
  br label %bb27
bb27:
  %t147 = load i1, ptr %l82, !tbaa !21
  br i1 %t147, label %bb28, label %bb29
bb28:
  br label %bb49
bb29:
  br label %bb30
bb30:
  %t148 = getelementptr %"compiler/token:Token", ptr %l16, i32 0, i32 0
  %t149 = load i32, ptr %t148, !range !{i32 0, i32 116}
  %t151 = trunc i64 1 to i32
  %t152 = icmp eq i32 %t149, %t151
  br i1 %t152, label %bb31, label %bb32
bb31:
  %t154 = load ptr, ptr %l4, !tbaa !29
  %t156 = getelementptr %"compiler/load:Module", ptr %t154, i32 0, i32 6
  %t157 = load ptr, ptr %t156, !tbaa !29
  %t159 = icmp eq ptr %t157, null
  br i1 %t159, label %bb33, label %bb34
bb32:
  store i1 false, ptr %l89, !tbaa !21
  br label %bb43
bb33:
  call void @__olang_check_failed(ptr @olang_loc_494c345e55bc9323_650b6e4eb2f730ef)
  unreachable
bb34:
  br label %bb35
bb35:
  %t161 = load ptr, ptr %l4, !tbaa !29
  %t163 = getelementptr %"compiler/load:Module", ptr %t161, i32 0, i32 6
  %t164 = load ptr, ptr %t163, !tbaa !29
  %t167 = getelementptr %"compiler/source:Source", ptr %t164, i32 0, i32 1
  %t168 = load { i64, ptr }, ptr %t167, !tbaa !27
  store { i64, ptr } %t168, ptr %l96, !tbaa !27
  %t169 = getelementptr %"compiler/token:Token", ptr %l16, i32 0, i32 2
  %t170 = load i32, ptr %t169, !tbaa !23
  %t172 = sext i32 %t170 to i64
  store i64 %t172, ptr %l98, !tbaa !24
  %t173 = getelementptr %"compiler/token:Token", ptr %l16, i32 0, i32 3
  %t174 = load i32, ptr %t173, !tbaa !23
  %t176 = sext i32 %t174 to i64
  store i64 %t176, ptr %l100, !tbaa !24
  %t177 = load { i64, ptr }, ptr %l96, !tbaa !27
  %t178 = extractvalue { i64, ptr } %t177, 0
  store i64 %t178, ptr %l101, !tbaa !24
  %t179 = load i64, ptr %l98, !tbaa !24
  %t180 = icmp sge i64 %t179, 0
  br i1 %t180, label %bb36, label %bb37
bb36:
  %t182 = load i64, ptr %l98, !tbaa !24
  %t183 = load i64, ptr %l100, !tbaa !24
  %t184 = icmp sle i64 %t182, %t183
  br i1 %t184, label %bb38, label %bb39
bb37:
  call void @__olang_check_failed(ptr @olang_loc_9c997e82162b9a5a_f5a213d30049e536)
  unreachable
bb38:
  %t186 = load i64, ptr %l100, !tbaa !24
  %t187 = load i64, ptr %l101, !tbaa !24
  %t188 = icmp sle i64 %t186, %t187
  br i1 %t188, label %bb40, label %bb41
bb39:
  call void @__olang_check_failed(ptr @olang_loc_9c997e82162b9a5a_f5a213d30049e536)
  unreachable
bb40:
  %t190 = getelementptr { i64, ptr }, ptr %l96, i32 0, i32 1
  %t191 = load ptr, ptr %t190, !tbaa !27
  %t192 = load i64, ptr %l98, !tbaa !24
  %t193 = load i64, ptr %l100, !tbaa !24
  %t194 = getelementptr i8, ptr %t191, i64 %t192
  %t195 = sub i64 %t193, %t192
  %t196 = insertvalue { i64, ptr } undef, i64 %t195, 0
  %t197 = insertvalue { i64, ptr } %t196, ptr %t194, 1
  %t198 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t201 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v0, { i64, ptr } %t197, { i64, ptr } %t198)
  store i1 %t201, ptr %l107
  br label %bb42
bb41:
  call void @__olang_check_failed(ptr @olang_loc_9c997e82162b9a5a_f5a213d30049e536)
  unreachable
bb42:
  %t202 = load i1, ptr %l107, !tbaa !21
  store i1 %t202, ptr %l89, !tbaa !21
  br label %bb43
bb43:
  %t203 = load i1, ptr %l89, !tbaa !21
  br i1 %t203, label %bb44, label %bb45
bb44:
  store %olang.scope zeroinitializer, ptr %s7
  %t204 = getelementptr %"compiler/token:Token", ptr %l16, i32 0, i32 2
  %t205 = load i32, ptr %t204, !tbaa !23
  %t206 = getelementptr %"compiler/token:Token", ptr %l16, i32 0, i32 3
  %t207 = load i32, ptr %t206, !tbaa !23
  %t210 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s7, i32 %t205, i32 %t207)
  store %"compiler/source:Span" %t210, ptr %l110
  br label %bb46
bb45:
  br label %bb47
bb46:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  %t211 = load %"compiler/source:Span", ptr %l110
  store %"compiler/source:Span" %t211, ptr %rv
  br label %ret
bb47:
  br label %bb48
bb48:
  %t212 = load i64, ptr %l14, !tbaa !24
  %t215 = add i64 %t212, 1
  store i64 %t215, ptr %l14, !tbaa !24
  br label %bb21
bb49:
  %t217 = load i32, ptr %l2, !tbaa !23
  %t218 = load i32, ptr %l2, !tbaa !23
  %t221 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %t217, i32 %t218)
  store %"compiler/source:Span" %t221, ptr %l116
  br label %bb50
bb50:
  call void @__olang_scope_close(ptr %s0)
  %t222 = load %"compiler/source:Span", ptr %l116
  store %"compiler/source:Span" %t222, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2enearRaise(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, %"compiler/names:raisedName" %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"compiler/names:raisedName"
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca %"compiler/names:Entry"
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca i64
  %l15 = alloca %"compiler/names:raised"
  %l19 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l25 = alloca ptr
  %l28 = alloca i64
  %l30 = alloca i64
  %l35 = alloca %"compiler/names:Entry"
  %l39 = alloca i1
  %l43 = alloca i1
  %l49 = alloca i64
  %l52 = alloca i1
  %l55 = alloca %"compiler/names:raisedName"
  %l57 = alloca i1
  %l59 = alloca { i64, ptr }
  %l62 = alloca { i64, ptr }
  %l63 = alloca i64
  %l67 = alloca i1
  %l70 = alloca i1
  %l71 = alloca i64
  %l75 = alloca { i64, ptr }
  %l76 = alloca { i64, ptr }
  %l80 = alloca { i64, ptr }
  %l91 = alloca i64
  %l93 = alloca i64
  %l98 = alloca %"compiler/names:raised"
  %l104 = alloca ptr
  %l108 = alloca { i64, [3 x i64] }
  %l111 = alloca { i64, ptr }
  %l112 = alloca { i64, ptr }
  %l114 = alloca { i64, ptr }
  %l116 = alloca %"compiler/diagmsg:Msg"
  %l117 = alloca i64
  %s0 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s12 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store %"compiler/names:raisedName" %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = getelementptr %"compiler/names:raisedName", ptr %l2, i32 0, i32 3
  %t2 = load i1, ptr %t1, !tbaa !21
  br i1 %t2, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb2:
  br label %bb3
bb3:
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/names:raisedName", ptr %l2, i32 0, i32 0
  %t6 = load i32, ptr %t5, !tbaa !23
  %t9 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %v0, ptr %t4, i32 %t6)
  store { i64, ptr } %t9, ptr %l19
  br label %bb4
bb4:
  %t10 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t10, ptr %l4, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d14, i32 0, i32 1) }, ptr %l20, !tbaa !27
  %t11 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t11, ptr %l5, !tbaa !27
  store i64 2, ptr %l6, !tbaa !24
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/names:Resolver", ptr %t13, i32 0, i32 1
  %t16 = load i64, ptr %l1, !tbaa !24
  %t19 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v0, ptr %t15, i64 %t16)
  store ptr %t19, ptr %l25
  br label %bb5
bb5:
  %t20 = load ptr, ptr %l25, !tbaa !29
  %t23 = getelementptr %"compiler/names:Table", ptr %t20, i32 0, i32 0
  store ptr %t23, ptr %l8, !tbaa !29
  store i64 0, ptr %l9, !tbaa !24
  br label %bb6
bb6:
  %t25 = load i64, ptr %l9, !tbaa !24
  store i64 %t25, ptr %l28, !tbaa !24
  %t26 = load ptr, ptr %l8, !tbaa !29
  %t28 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eLen_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %t26)
  store i64 %t28, ptr %l30
  br label %bb7
bb7:
  %t29 = load i64, ptr %l28, !tbaa !24
  %t30 = load i64, ptr %l30, !tbaa !24
  %t31 = icmp slt i64 %t29, %t30
  %t33 = xor i1 %t31, true
  br i1 %t33, label %bb8, label %bb9
bb8:
  br label %bb49
bb9:
  br label %bb10
bb10:
  %t35 = load ptr, ptr %l8, !tbaa !29
  %t36 = load i64, ptr %l9, !tbaa !24
  %t39 = call %"compiler/names:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %v0, ptr %t35, i64 %t36)
  store %"compiler/names:Entry" %t39, ptr %l35
  br label %bb11
bb11:
  %t40 = load %"compiler/names:Entry", ptr %l35
  store %"compiler/names:Entry" %t40, ptr %l10
  %t41 = getelementptr %"compiler/names:Entry", ptr %l10, i32 0, i32 2
  %t42 = load i32, ptr %t41, !range !{i32 0, i32 9}
  %t44 = trunc i64 4 to i32
  %t45 = icmp eq i32 %t42, %t44
  %t47 = xor i1 %t45, true
  br i1 %t47, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l39, !tbaa !21
  br label %bb14
bb13:
  %t49 = getelementptr %"compiler/names:Entry", ptr %l10, i32 0, i32 4
  %t50 = load ptr, ptr %t49, !tbaa !29
  %t52 = icmp eq ptr %t50, null
  %t54 = xor i1 %t52, true
  store i1 %t54, ptr %l39, !tbaa !21
  br label %bb14
bb14:
  %t56 = load i1, ptr %l39, !tbaa !21
  br i1 %t56, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l43, !tbaa !21
  br label %bb17
bb16:
  %t57 = getelementptr %"compiler/names:Entry", ptr %l10, i32 0, i32 0
  %t58 = load i32, ptr %t57, !tbaa !23
  %t59 = getelementptr %"compiler/names:raisedName", ptr %l2, i32 0, i32 0
  %t60 = load i32, ptr %t59, !tbaa !23
  %t63 = icmp eq i32 %t58, %t60
  store i1 %t63, ptr %l43, !tbaa !21
  br label %bb17
bb17:
  %t65 = load i1, ptr %l43, !tbaa !21
  br i1 %t65, label %bb18, label %bb19
bb18:
  br label %bb48
bb19:
  br label %bb20
bb20:
  %t66 = load ptr, ptr %l3, !tbaa !29
  %t67 = getelementptr %"compiler/names:Entry", ptr %l10, i32 0, i32 0
  %t68 = load i32, ptr %t67, !tbaa !23
  %t71 = call i64 @compiler_2fnames_2eindexOfRaised(ptr %v2, ptr %t66, i32 %t68)
  store i64 %t71, ptr %l49
  br label %bb21
bb21:
  %t72 = load i64, ptr %l49, !tbaa !24
  store i64 %t72, ptr %l11, !tbaa !24
  %t73 = load i64, ptr %l11, !tbaa !24
  %t75 = icmp sge i64 %t73, 0
  br i1 %t75, label %bb22, label %bb23
bb22:
  %t77 = load ptr, ptr %l3, !tbaa !29
  %t78 = load i64, ptr %l11, !tbaa !24
  %t81 = call %"compiler/names:raisedName" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3araisedName_3e_2eAt__H16b49ab3dab0c5fe49005bf48ab18c1b(ptr %v2, ptr %v2, ptr %t77, i64 %t78)
  store %"compiler/names:raisedName" %t81, ptr %l55
  br label %bb24
bb23:
  store i1 false, ptr %l52, !tbaa !21
  br label %bb26
bb24:
  %t82 = load %"compiler/names:raisedName", ptr %l2
  %t83 = load %"compiler/names:raisedName", ptr %l55
  %t85 = call i1 @compiler_2fnames_2eoutranks(ptr %v2, ptr %v1, %"compiler/names:raisedName" %t83, %"compiler/names:raisedName" %t82)
  store i1 %t85, ptr %l57
  br label %bb25
bb25:
  %t86 = load i1, ptr %l57, !tbaa !21
  %t87 = xor i1 %t86, true
  store i1 %t87, ptr %l52, !tbaa !21
  br label %bb26
bb26:
  %t89 = load i1, ptr %l52, !tbaa !21
  br i1 %t89, label %bb27, label %bb28
bb27:
  br label %bb48
bb28:
  br label %bb29
bb29:
  %t90 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t90, ptr %l59, !tbaa !27
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/names:Entry", ptr %l10, i32 0, i32 0
  %t93 = load i32, ptr %t92, !tbaa !23
  %t96 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %v0, ptr %t91, i32 %t93)
  store { i64, ptr } %t96, ptr %l62
  br label %bb30
bb30:
  %t97 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t98 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t99 = call i64 @compiler_2fmsgs_2eDistance(ptr %v0, ptr %v0, { i64, ptr } %t97, { i64, ptr } %t98)
  store i64 %t99, ptr %l63
  br label %bb31
bb31:
  %t100 = load i64, ptr %l63, !tbaa !24
  store i64 %t100, ptr %l12, !tbaa !24
  %t101 = load i64, ptr %l12, !tbaa !24
  %t102 = load i64, ptr %l6, !tbaa !24
  %t105 = icmp slt i64 %t101, %t102
  br i1 %t105, label %bb32, label %bb33
bb32:
  %t107 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t108 = load i64, ptr %l12, !tbaa !24
  %t111 = call i1 @compiler_2fmsgs_2eNear(ptr %v0, { i64, ptr } %t107, i64 %t108)
  store i1 %t111, ptr %l70
  br label %bb34
bb33:
  store i1 false, ptr %l67, !tbaa !21
  br label %bb35
bb34:
  %t112 = load i1, ptr %l70, !tbaa !21
  store i1 %t112, ptr %l67, !tbaa !21
  br label %bb35
bb35:
  %t113 = load i1, ptr %l67, !tbaa !21
  br i1 %t113, label %bb36, label %bb37
bb36:
  store %olang.scope zeroinitializer, ptr %s6
  %t114 = call ptr @__olang_scope_hold(ptr %s0)
  %t115 = ptrtoint ptr %t114 to i64
  store i64 %t115, ptr %l71, !tbaa !24
  %t116 = load i1, ptr @olang_2esole_2ecompiler__2fnames__2ecompiler__2fnames__3aResolver__2enearRaise_2elocal_2e5
  br i1 %t116, label %bb38, label %bb39
bb37:
  br label %bb47
bb38:
  %t118 = call ptr @__olang_region_make(ptr %s0)
  %t119 = ptrtoint ptr %t118 to i64
  store i64 %t119, ptr %l71, !tbaa !24
  br label %bb39
bb39:
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t121 = getelementptr %"compiler/names:Entry", ptr %l10, i32 0, i32 0
  %t122 = load i32, ptr %t121, !tbaa !23
  %t125 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %s6, ptr %t120, i32 %t122)
  store { i64, ptr } %t125, ptr %l75
  br label %bb40
bb40:
  %t126 = load { i64, ptr }, ptr %l75, !tbaa !27
  %t127 = extractvalue { i64, ptr } %t126, 1
  %t128 = extractvalue { i64, ptr } %t126, 0
  %t129 = load i64, ptr %l71
  %t130 = inttoptr i64 %t129 to ptr
  %t131 = call ptr @__olang_held_alloc(ptr %t130, i64 %t128)
  call void @olang_textcopy(ptr %t131, ptr %t127, i64 %t128)
  %t132 = insertvalue { i64, ptr } undef, i64 %t128, 0
  %t133 = insertvalue { i64, ptr } %t132, ptr %t131, 1
  store { i64, ptr } %t133, ptr %l76, !tbaa !27
  %t134 = load i1, ptr @olang_2esole_2ecompiler__2fnames__2ecompiler__2fnames__3aResolver__2enearRaise_2elocal_2e5
  br i1 %t134, label %bb41, label %bb42
bb41:
  %t136 = load { i64, ptr }, ptr %l76, !tbaa !27
  %t137 = extractvalue { i64, ptr } %t136, 0
  %t139 = icmp eq i64 %t137, 0
  br i1 %t139, label %bb43, label %bb44
bb42:
  %t141 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t141, ptr %l80, !tbaa !27
  %t142 = load { i64, ptr }, ptr %l76, !tbaa !27
  store { i64, ptr } %t142, ptr %l5, !tbaa !27
  %t143 = load i1, ptr @olang_2esole_2ecompiler__2fnames__2ecompiler__2fnames__3aResolver__2enearRaise_2elocal_2e5
  br i1 %t143, label %bb45, label %bb46
bb43:
  store { i64, ptr } zeroinitializer, ptr %l76, !tbaa !27
  br label %bb44
bb44:
  %t145 = load i64, ptr %l71
  %t146 = inttoptr i64 %t145 to ptr
  %t147 = load { i64, ptr }, ptr %l76
  %t148 = extractvalue { i64, ptr } %t147, 1
  %t149 = call ptr @__olang_region_or(ptr %t148, ptr null)
  %t150 = icmp ne ptr %t149, null
  %t151 = select i1 %t150, ptr %t149, ptr null
  call void @__olang_region_settle_in(ptr %t146, ptr %t151)
  br label %bb42
bb45:
  %t152 = load { i64, ptr }, ptr %l80
  %t153 = extractvalue { i64, ptr } %t152, 1
  call void @__olang_region_release(ptr %t153)
  store { i64, ptr } zeroinitializer, ptr %l80
  br label %bb46
bb46:
  %t154 = load i64, ptr %l12, !tbaa !24
  store i64 %t154, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s6)
  br label %bb47
bb47:
  br label %bb48
bb48:
  %t156 = load i64, ptr %l9, !tbaa !24
  %t159 = add i64 %t156, 1
  store i64 %t159, ptr %l9, !tbaa !24
  br label %bb6
bb49:
  %t161 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t163 = extractvalue { i64, ptr } %t161, 0
  %t165 = icmp eq i64 %t163, 0
  br i1 %t165, label %bb50, label %bb51
bb50:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb51:
  br label %bb52
bb52:
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t169 = getelementptr %"compiler/names:Resolver", ptr %t167, i32 0, i32 24
  store ptr %t169, ptr %l13, !tbaa !29
  store i64 0, ptr %l14, !tbaa !24
  br label %bb53
bb53:
  %t171 = load i64, ptr %l14, !tbaa !24
  store i64 %t171, ptr %l91, !tbaa !24
  %t172 = load ptr, ptr %l13, !tbaa !29
  %t174 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3araised_3e_2eLen_3ccompiler_2fnames_3araised_3e(ptr %v0, ptr %t172)
  store i64 %t174, ptr %l93
  br label %bb54
bb54:
  %t175 = load i64, ptr %l91, !tbaa !24
  %t176 = load i64, ptr %l93, !tbaa !24
  %t177 = icmp slt i64 %t175, %t176
  %t179 = xor i1 %t177, true
  br i1 %t179, label %bb55, label %bb56
bb55:
  br label %bb68
bb56:
  br label %bb57
bb57:
  %t181 = load ptr, ptr %l13, !tbaa !29
  %t182 = load i64, ptr %l14, !tbaa !24
  %t185 = call %"compiler/names:raised" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3araised_3e_2eAt_3ccompiler_2fnames_3araised_3e(ptr %v0, ptr %v0, ptr %t181, i64 %t182)
  store %"compiler/names:raised" %t185, ptr %l98
  br label %bb58
bb58:
  %t186 = load %"compiler/names:raised", ptr %l98
  store %"compiler/names:raised" %t186, ptr %l15
  %t187 = getelementptr %"compiler/names:raised", ptr %l15, i32 0, i32 0
  %t188 = load i32, ptr %t187, !tbaa !23
  %t189 = getelementptr %"compiler/names:raisedName", ptr %l2, i32 0, i32 0
  %t190 = load i32, ptr %t189, !tbaa !23
  %t193 = icmp eq i32 %t188, %t190
  br i1 %t193, label %bb59, label %bb60
bb59:
  store %olang.scope zeroinitializer, ptr %s12
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t197 = getelementptr %"compiler/names:Resolver", ptr %t195, i32 0, i32 0
  %t198 = load ptr, ptr %t197, !tbaa !29
  %t200 = getelementptr %"compiler/load:Loader", ptr %t198, i32 0, i32 4
  %t201 = load ptr, ptr %t200, !tbaa !29
  store ptr %t201, ptr %l104, !tbaa !29
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t203 = load i64, ptr %l1, !tbaa !24
  %t204 = getelementptr %"compiler/names:raised", ptr %l15, i32 0, i32 1
  %t205 = load %"compiler/source:Span", ptr %t204
  %t209 = call { i64, [3 x i64] } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eat(ptr %v0, ptr %t202, i64 %t203, %"compiler/source:Span" %t205)
  store { i64, [3 x i64] } %t209, ptr %l108
  br label %bb61
bb60:
  br label %bb66
bb61:
  %t210 = load ptr, ptr %l0, !tbaa !29
  %t211 = getelementptr %"compiler/names:raisedName", ptr %l2, i32 0, i32 0
  %t212 = load i32, ptr %t211, !tbaa !23
  %t215 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etok(ptr %v0, ptr %s12, ptr %t210, i32 %t212)
  store { i64, ptr } %t215, ptr %l111
  br label %bb62
bb62:
  %t216 = load { i64, ptr }, ptr %l111, !tbaa !27
  store { i64, ptr } %t216, ptr %l112, !tbaa !27
  %t217 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t219 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %s0, ptr %s12, { i64, ptr } %t217)
  store { i64, ptr } %t219, ptr %l114
  br label %bb63
bb63:
  %t220 = load { i64, ptr }, ptr %l114, !tbaa !27
  %t221 = load { i64, ptr }, ptr %l112, !tbaa !27
  %t223 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eRaiseNearError(ptr %s12, ptr %s12, ptr %v0, { i64, ptr } %t221, { i64, ptr } %t220)
  store %"compiler/diagmsg:Msg" %t223, ptr %l116
  br label %bb64
bb64:
  %t224 = load ptr, ptr %l104, !tbaa !29
  %t225 = load { i64, [3 x i64] }, ptr %l108
  %t226 = load %"compiler/diagmsg:Msg", ptr %l116
  %t227 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v0, ptr %t224, { i64, [3 x i64] } %t225, %"compiler/diagmsg:Msg" %t226)
  store i64 %t227, ptr %l117
  br label %bb65
bb65:
  call void @__olang_scope_close(ptr %s12)
  br label %bb66
bb66:
  br label %bb67
bb67:
  %t228 = load i64, ptr %l14, !tbaa !24
  %t231 = add i64 %t228, 1
  store i64 %t231, ptr %l14, !tbaa !24
  br label %bb53
bb68:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2enoShadow(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l7 = alloca %"compiler/names:Entry"
  %l12 = alloca i64
  %l17 = alloca ptr
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i32
  %l29 = alloca i1
  %l36 = alloca i1
  %l42 = alloca i1
  %l48 = alloca %"compiler/names:Entry"
  %l51 = alloca ptr
  %l56 = alloca { i64, [3 x i64] }
  %l59 = alloca %"compiler/diagmsg:Msg"
  %l62 = alloca { i64, ptr }
  %l64 = alloca %"compiler/diagmsg:Msg"
  %l67 = alloca { i64, ptr }
  %l69 = alloca %"compiler/diagmsg:Msg"
  %l70 = alloca i64
  %l73 = alloca ptr
  %l74 = alloca i64
  %l79 = alloca { i64, [3 x i64] }
  %l82 = alloca { i64, ptr }
  %l84 = alloca %"compiler/diagmsg:Msg"
  %l89 = alloca i1
  %l92 = alloca ptr
  %l97 = alloca { i64, [3 x i64] }
  %l100 = alloca { i64, ptr }
  %l102 = alloca %"compiler/diagmsg:Msg"
  %l103 = alloca i64
  %l108 = alloca i1
  %l118 = alloca i1
  %l119 = alloca i1
  %l124 = alloca i1
  %l125 = alloca i1
  %l127 = alloca i1
  %l130 = alloca ptr
  %l135 = alloca { i64, [3 x i64] }
  %l138 = alloca { i64, ptr }
  %l140 = alloca %"compiler/diagmsg:Msg"
  %l141 = alloca i64
  %l142 = alloca i64
  %l146 = alloca i64
  %l147 = alloca i32
  %l150 = alloca i1
  %l154 = alloca %"compiler/names:local"
  %l159 = alloca ptr
  %l164 = alloca { i64, [3 x i64] }
  %l167 = alloca { i64, ptr }
  %l169 = alloca %"compiler/diagmsg:Msg"
  %l170 = alloca i64
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/names:Resolver", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/names:Resolver", ptr %t4, i32 0, i32 7
  %t7 = load i64, ptr %t6, !tbaa !24
  %t10 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v0, ptr %t3, i64 %t7)
  store ptr %t10, ptr %l17
  br label %bb1
bb1:
  %t11 = load ptr, ptr %l17, !tbaa !29
  store ptr %t11, ptr %l3, !tbaa !29
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load i32, ptr %l1, !tbaa !23
  %t16 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %v0, ptr %t12, i32 %t13)
  store { i64, ptr } %t16, ptr %l20
  br label %bb2
bb2:
  %t17 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t17, ptr %l4, !tbaa !27
  %t18 = load ptr, ptr %l3, !tbaa !29
  %t20 = getelementptr %"compiler/names:Table", ptr %t18, i32 0, i32 1
  %t21 = load i32, ptr %l1, !tbaa !23
  %t24 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %t20, i32 %t21)
  %t25 = extractvalue { i32, i64 } %t24, 1
  %t26 = extractvalue { i32, i64 } %t24, 0
  store i32 %t26, ptr %l26
  %t27 = icmp ne i32 %t26, 0
  br i1 %t27, label %bb4, label %ok.28, !prof !99
ok.28:
  store i64 %t25, ptr %l25
  br label %bb3
bb3:
  %t29 = load i64, ptr %l25, !tbaa !24
  store i64 %t29, ptr %l21, !tbaa !24
  br label %bb6
bb4:
  br label %bb5
bb5:
  store i64 -1, ptr %l21, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l21, !tbaa !24
  store i64 %t30, ptr %l5, !tbaa !24
  %t31 = load i64, ptr %l5, !tbaa !24
  %t33 = icmp sge i64 %t31, 0
  br i1 %t33, label %bb7, label %bb8
bb7:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/names:Resolver", ptr %t35, i32 0, i32 7
  %t38 = load i64, ptr %t37, !tbaa !24
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/names:Resolver", ptr %t39, i32 0, i32 0
  %t42 = load ptr, ptr %t41, !tbaa !29
  %t44 = getelementptr %"compiler/load:Loader", ptr %t42, i32 0, i32 12
  %t45 = load i64, ptr %t44, !tbaa !24
  %t48 = icmp eq i64 %t38, %t45
  store i1 %t48, ptr %l29, !tbaa !21
  br label %bb9
bb8:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb9
bb9:
  %t50 = load i1, ptr %l29, !tbaa !21
  br i1 %t50, label %bb10, label %bb11
bb10:
  %t51 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/names:Resolver", ptr %t53, i32 0, i32 0
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t58 = getelementptr %"compiler/load:Loader", ptr %t56, i32 0, i32 14
  %t62 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6b5ccacad8db807339a3579aa8c82ff8(ptr %v0, ptr %v0, ptr %t58, { i64, ptr } %t51)
  store i1 %t62, ptr %l42
  br label %bb12
bb11:
  store i1 false, ptr %l36, !tbaa !21
  br label %bb13
bb12:
  %t63 = load i1, ptr %l42, !tbaa !21
  store i1 %t63, ptr %l36, !tbaa !21
  br label %bb13
bb13:
  %t64 = load i1, ptr %l36, !tbaa !21
  br i1 %t64, label %bb14, label %bb15
bb14:
  br label %ret
bb15:
  br label %bb16
bb16:
  %t65 = load i64, ptr %l5, !tbaa !24
  %t67 = icmp sge i64 %t65, 0
  br i1 %t67, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s2
  %t69 = load ptr, ptr %l3, !tbaa !29
  %t71 = getelementptr %"compiler/names:Table", ptr %t69, i32 0, i32 0
  %t72 = load i64, ptr %l5, !tbaa !24
  %t75 = call %"compiler/names:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %v0, ptr %t71, i64 %t72)
  store %"compiler/names:Entry" %t75, ptr %l48
  br label %bb19
bb18:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/names:Resolver", ptr %t76, i32 0, i32 0
  %t79 = load ptr, ptr %t78, !tbaa !29
  %t81 = getelementptr %"compiler/load:Loader", ptr %t79, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t83 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t86 = call i1 @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eHas(ptr %v0, ptr %v0, ptr %t82, { i64, ptr } %t83)
  store i1 %t86, ptr %l89
  br label %bb33
bb19:
  %t87 = load %"compiler/names:Entry", ptr %l48
  store %"compiler/names:Entry" %t87, ptr %l7
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/names:Resolver", ptr %t88, i32 0, i32 0
  %t91 = load ptr, ptr %t90, !tbaa !29
  %t93 = getelementptr %"compiler/load:Loader", ptr %t91, i32 0, i32 4
  %t94 = load ptr, ptr %t93, !tbaa !29
  store ptr %t94, ptr %l51, !tbaa !29
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/names:Resolver", ptr %t96, i32 0, i32 7
  %t99 = load i64, ptr %t98, !tbaa !24
  %t100 = load %"compiler/source:Span", ptr %l2
  %t104 = call { i64, [3 x i64] } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eat(ptr %v0, ptr %t95, i64 %t99, %"compiler/source:Span" %t100)
  store { i64, [3 x i64] } %t104, ptr %l56
  br label %bb20
bb20:
  %t105 = getelementptr %"compiler/names:Entry", ptr %l7, i32 0, i32 2
  %t106 = load i32, ptr %t105, !range !{i32 0, i32 9}
  %t108 = trunc i64 3 to i32
  %t109 = icmp eq i32 %t106, %t108
  br i1 %t109, label %bb21, label %bb22
bb21:
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t112 = load i32, ptr %l1, !tbaa !23
  %t115 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etok(ptr %v0, ptr %s2, ptr %t111, i32 %t112)
  store { i64, ptr } %t115, ptr %l62
  br label %bb23
bb22:
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t117 = load i32, ptr %l1, !tbaa !23
  %t120 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etok(ptr %v0, ptr %s2, ptr %t116, i32 %t117)
  store { i64, ptr } %t120, ptr %l67
  br label %bb25
bb23:
  %t121 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t123 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eShadowsFunction(ptr %s2, ptr %v0, { i64, ptr } %t121)
  store %"compiler/diagmsg:Msg" %t123, ptr %l64
  br label %bb24
bb24:
  %t124 = load %"compiler/diagmsg:Msg", ptr %l64
  store %"compiler/diagmsg:Msg" %t124, ptr %l59
  br label %bb27
bb25:
  %t125 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t127 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eShadowsGlobal(ptr %s2, ptr %v0, { i64, ptr } %t125)
  store %"compiler/diagmsg:Msg" %t127, ptr %l69
  br label %bb26
bb26:
  %t128 = load %"compiler/diagmsg:Msg", ptr %l69
  store %"compiler/diagmsg:Msg" %t128, ptr %l59
  br label %bb27
bb27:
  %t129 = load ptr, ptr %l51, !tbaa !29
  %t130 = load { i64, [3 x i64] }, ptr %l56
  %t131 = load %"compiler/diagmsg:Msg", ptr %l59
  %t132 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v0, ptr %t129, { i64, [3 x i64] } %t130, %"compiler/diagmsg:Msg" %t131)
  store i64 %t132, ptr %l70
  br label %bb28
bb28:
  %t133 = load i64, ptr %l70, !tbaa !24
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr %"compiler/names:Resolver", ptr %t134, i32 0, i32 0
  %t137 = load ptr, ptr %t136, !tbaa !29
  %t139 = getelementptr %"compiler/load:Loader", ptr %t137, i32 0, i32 4
  %t140 = load ptr, ptr %t139, !tbaa !29
  store ptr %t140, ptr %l73, !tbaa !29
  store i64 %t133, ptr %l74, !tbaa !24
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t145 = getelementptr %"compiler/names:Resolver", ptr %t143, i32 0, i32 7
  %t146 = load i64, ptr %t145, !tbaa !24
  %t147 = getelementptr %"compiler/names:Entry", ptr %l7, i32 0, i32 1
  %t148 = load %"compiler/source:Span", ptr %t147
  %t152 = call { i64, [3 x i64] } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eat(ptr %v0, ptr %t142, i64 %t146, %"compiler/source:Span" %t148)
  store { i64, [3 x i64] } %t152, ptr %l79
  br label %bb29
bb29:
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t154 = load i32, ptr %l1, !tbaa !23
  %t157 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etok(ptr %v0, ptr %s2, ptr %t153, i32 %t154)
  store { i64, ptr } %t157, ptr %l82
  br label %bb30
bb30:
  %t158 = load { i64, ptr }, ptr %l82, !tbaa !27
  %t160 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoteDeclaredHere(ptr %s2, ptr %v0, { i64, ptr } %t158)
  store %"compiler/diagmsg:Msg" %t160, ptr %l84
  br label %bb31
bb31:
  %t161 = load ptr, ptr %l73, !tbaa !29
  %t162 = load i64, ptr %l74, !tbaa !24
  %t163 = load { i64, [3 x i64] }, ptr %l79
  %t164 = load %"compiler/diagmsg:Msg", ptr %l84
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %v0, ptr %t161, i64 %t162, { i64, [3 x i64] } %t163, %"compiler/diagmsg:Msg" %t164)
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s2)
  br label %bb77
bb33:
  %t165 = load i1, ptr %l89, !tbaa !21
  br i1 %t165, label %bb34, label %bb35
bb34:
  store %olang.scope zeroinitializer, ptr %s4
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t168 = getelementptr %"compiler/names:Resolver", ptr %t166, i32 0, i32 0
  %t169 = load ptr, ptr %t168, !tbaa !29
  %t171 = getelementptr %"compiler/load:Loader", ptr %t169, i32 0, i32 4
  %t172 = load ptr, ptr %t171, !tbaa !29
  store ptr %t172, ptr %l92, !tbaa !29
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t176 = getelementptr %"compiler/names:Resolver", ptr %t174, i32 0, i32 7
  %t177 = load i64, ptr %t176, !tbaa !24
  %t178 = load %"compiler/source:Span", ptr %l2
  %t182 = call { i64, [3 x i64] } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eat(ptr %v0, ptr %t173, i64 %t177, %"compiler/source:Span" %t178)
  store { i64, [3 x i64] } %t182, ptr %l97
  br label %bb36
bb35:
  %t183 = load i32, ptr %l1, !tbaa !23
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t187 = getelementptr %"compiler/names:Resolver", ptr %t185, i32 0, i32 3
  %t191 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_H6d33fbc050830e537410645e3c893b2c(ptr %v0, ptr %t187, i32 %t183)
  store i1 %t191, ptr %l108
  br label %bb40
bb36:
  %t192 = load ptr, ptr %l0, !tbaa !29
  %t193 = load i32, ptr %l1, !tbaa !23
  %t196 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etok(ptr %v0, ptr %s4, ptr %t192, i32 %t193)
  store { i64, ptr } %t196, ptr %l100
  br label %bb37
bb37:
  %t197 = load { i64, ptr }, ptr %l100, !tbaa !27
  %t199 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eShadowsBuildConst(ptr %s4, ptr %v0, { i64, ptr } %t197)
  store %"compiler/diagmsg:Msg" %t199, ptr %l102
  br label %bb38
bb38:
  %t200 = load ptr, ptr %l92, !tbaa !29
  %t201 = load { i64, [3 x i64] }, ptr %l97
  %t202 = load %"compiler/diagmsg:Msg", ptr %l102
  %t203 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v0, ptr %t200, { i64, [3 x i64] } %t201, %"compiler/diagmsg:Msg" %t202)
  store i64 %t203, ptr %l103
  br label %bb39
bb39:
  call void @__olang_scope_close(ptr %s4)
  br label %bb76
bb40:
  %t204 = load i1, ptr %l108, !tbaa !21
  br i1 %t204, label %bb41, label %bb42
bb41:
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t206 = load ptr, ptr %l0, !tbaa !29
  %t208 = getelementptr %"compiler/names:Resolver", ptr %t206, i32 0, i32 7
  %t209 = load i64, ptr %t208, !tbaa !24
  %t210 = load i32, ptr %l1, !tbaa !23
  %t211 = load %"compiler/source:Span", ptr %l2
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2epreludeTaken(ptr %v0, ptr %t205, i64 %t209, i32 %t210, %"compiler/source:Span" %t211)
  br label %bb43
bb42:
  %t216 = load i32, ptr %l1, !tbaa !23
  %t218 = load ptr, ptr %l3, !tbaa !29
  %t220 = getelementptr %"compiler/names:Table", ptr %t218, i32 0, i32 2
  %t224 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_Hf575c52a5a9e8993bae2b73c9c2548b3(ptr %v0, ptr %t220, i32 %t216)
  store i1 %t224, ptr %l118
  br label %bb44
bb43:
  br label %bb75
bb44:
  %t225 = load i1, ptr %l118, !tbaa !21
  br i1 %t225, label %bb45, label %bb46
bb45:
  store i1 true, ptr %l119, !tbaa !21
  br label %bb48
bb46:
  %t226 = load i32, ptr %l1, !tbaa !23
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t230 = getelementptr %"compiler/names:Resolver", ptr %t228, i32 0, i32 2
  %t234 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_Hf575c52a5a9e8993bae2b73c9c2548b3(ptr %v0, ptr %t230, i32 %t226)
  store i1 %t234, ptr %l124
  br label %bb47
bb47:
  %t235 = load i1, ptr %l124, !tbaa !21
  store i1 %t235, ptr %l119, !tbaa !21
  br label %bb48
bb48:
  %t236 = load i1, ptr %l119, !tbaa !21
  br i1 %t236, label %bb49, label %bb50
bb49:
  store i1 true, ptr %l125, !tbaa !21
  br label %bb52
bb50:
  %t237 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t239 = call i1 @compiler_2fnames_2eBuiltinTypeName(ptr %v0, { i64, ptr } %t237)
  store i1 %t239, ptr %l127
  br label %bb51
bb51:
  %t240 = load i1, ptr %l127, !tbaa !21
  store i1 %t240, ptr %l125, !tbaa !21
  br label %bb52
bb52:
  %t241 = load i1, ptr %l125, !tbaa !21
  br i1 %t241, label %bb53, label %bb54
bb53:
  store %olang.scope zeroinitializer, ptr %s8
  %t242 = load ptr, ptr %l0, !tbaa !29
  %t244 = getelementptr %"compiler/names:Resolver", ptr %t242, i32 0, i32 0
  %t245 = load ptr, ptr %t244, !tbaa !29
  %t247 = getelementptr %"compiler/load:Loader", ptr %t245, i32 0, i32 4
  %t248 = load ptr, ptr %t247, !tbaa !29
  store ptr %t248, ptr %l130, !tbaa !29
  %t249 = load ptr, ptr %l0, !tbaa !29
  %t250 = load ptr, ptr %l0, !tbaa !29
  %t252 = getelementptr %"compiler/names:Resolver", ptr %t250, i32 0, i32 7
  %t253 = load i64, ptr %t252, !tbaa !24
  %t254 = load %"compiler/source:Span", ptr %l2
  %t258 = call { i64, [3 x i64] } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eat(ptr %v0, ptr %t249, i64 %t253, %"compiler/source:Span" %t254)
  store { i64, [3 x i64] } %t258, ptr %l135
  br label %bb55
bb54:
  %t259 = load ptr, ptr %l0, !tbaa !29
  %t261 = getelementptr %"compiler/names:Resolver", ptr %t259, i32 0, i32 9
  %t262 = load i32, ptr %l1, !tbaa !23
  %t265 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %t261, i32 %t262)
  %t266 = extractvalue { i32, i64 } %t265, 1
  %t267 = extractvalue { i32, i64 } %t265, 0
  store i32 %t267, ptr %l147
  %t268 = icmp ne i32 %t267, 0
  br i1 %t268, label %bb60, label %ok.269, !prof !99
ok.269:
  store i64 %t266, ptr %l146
  br label %bb59
bb55:
  %t270 = load ptr, ptr %l0, !tbaa !29
  %t271 = load i32, ptr %l1, !tbaa !23
  %t274 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etok(ptr %v0, ptr %s8, ptr %t270, i32 %t271)
  store { i64, ptr } %t274, ptr %l138
  br label %bb56
bb56:
  %t275 = load { i64, ptr }, ptr %l138, !tbaa !27
  %t277 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eShadowsType(ptr %s8, ptr %v0, { i64, ptr } %t275)
  store %"compiler/diagmsg:Msg" %t277, ptr %l140
  br label %bb57
bb57:
  %t278 = load ptr, ptr %l130, !tbaa !29
  %t279 = load { i64, [3 x i64] }, ptr %l135
  %t280 = load %"compiler/diagmsg:Msg", ptr %l140
  %t281 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v0, ptr %t278, { i64, [3 x i64] } %t279, %"compiler/diagmsg:Msg" %t280)
  store i64 %t281, ptr %l141
  br label %bb58
bb58:
  call void @__olang_scope_close(ptr %s8)
  br label %bb74
bb59:
  %t282 = load i64, ptr %l146, !tbaa !24
  store i64 %t282, ptr %l142, !tbaa !24
  br label %bb62
bb60:
  br label %bb61
bb61:
  store i64 -1, ptr %l142, !tbaa !24
  br label %bb62
bb62:
  %t283 = load i64, ptr %l142, !tbaa !24
  store i64 %t283, ptr %l12, !tbaa !24
  %t284 = load i64, ptr %l12, !tbaa !24
  %t286 = icmp sge i64 %t284, 0
  br i1 %t286, label %bb63, label %bb64
bb63:
  %t288 = load ptr, ptr %l0, !tbaa !29
  %t290 = getelementptr %"compiler/names:Resolver", ptr %t288, i32 0, i32 8
  %t291 = load i64, ptr %l12, !tbaa !24
  %t294 = call %"compiler/names:local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3alocal_3e_2eAt_3ccompiler_2fnames_3alocal_3e(ptr %v0, ptr %t290, i64 %t291)
  store %"compiler/names:local" %t294, ptr %l154
  br label %bb65
bb64:
  store i1 false, ptr %l150, !tbaa !21
  br label %bb66
bb65:
  %t295 = getelementptr %"compiler/names:local", ptr %l154, i32 0, i32 2
  %t296 = load i32, ptr %t295, !range !{i32 0, i32 9}
  %t298 = trunc i64 8 to i32
  %t299 = icmp eq i32 %t296, %t298
  store i1 %t299, ptr %l150, !tbaa !21
  br label %bb66
bb66:
  %t301 = load i1, ptr %l150, !tbaa !21
  br i1 %t301, label %bb67, label %bb68
bb67:
  store %olang.scope zeroinitializer, ptr %s10
  %t302 = load ptr, ptr %l0, !tbaa !29
  %t304 = getelementptr %"compiler/names:Resolver", ptr %t302, i32 0, i32 0
  %t305 = load ptr, ptr %t304, !tbaa !29
  %t307 = getelementptr %"compiler/load:Loader", ptr %t305, i32 0, i32 4
  %t308 = load ptr, ptr %t307, !tbaa !29
  store ptr %t308, ptr %l159, !tbaa !29
  %t309 = load ptr, ptr %l0, !tbaa !29
  %t310 = load ptr, ptr %l0, !tbaa !29
  %t312 = getelementptr %"compiler/names:Resolver", ptr %t310, i32 0, i32 7
  %t313 = load i64, ptr %t312, !tbaa !24
  %t314 = load %"compiler/source:Span", ptr %l2
  %t318 = call { i64, [3 x i64] } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eat(ptr %v0, ptr %t309, i64 %t313, %"compiler/source:Span" %t314)
  store { i64, [3 x i64] } %t318, ptr %l164
  br label %bb69
bb68:
  br label %bb73
bb69:
  %t319 = load ptr, ptr %l0, !tbaa !29
  %t320 = load i32, ptr %l1, !tbaa !23
  %t323 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etok(ptr %v0, ptr %s10, ptr %t319, i32 %t320)
  store { i64, ptr } %t323, ptr %l167
  br label %bb70
bb70:
  %t324 = load { i64, ptr }, ptr %l167, !tbaa !27
  %t326 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eShadowsType(ptr %s10, ptr %v0, { i64, ptr } %t324)
  store %"compiler/diagmsg:Msg" %t326, ptr %l169
  br label %bb71
bb71:
  %t327 = load ptr, ptr %l159, !tbaa !29
  %t328 = load { i64, [3 x i64] }, ptr %l164
  %t329 = load %"compiler/diagmsg:Msg", ptr %l169
  %t330 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v0, ptr %t327, { i64, [3 x i64] } %t328, %"compiler/diagmsg:Msg" %t329)
  store i64 %t330, ptr %l170
  br label %bb72
bb72:
  call void @__olang_scope_close(ptr %s10)
  br label %bb73
bb73:
  br label %bb74
bb74:
  br label %bb75
bb75:
  br label %bb76
bb76:
  br label %bb77
bb77:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eparamStart(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l5 = alloca i64
  %l9 = alloca i64
  %l14 = alloca %"compiler/names:local"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/names:Resolver", ptr %t1, i32 0, i32 8
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3alocal_3e_2eLen_3ccompiler_2fnames_3alocal_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i64, ptr %l5, !tbaa !24
  %t7 = icmp eq i64 %t6, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  br label %ret
bb3:
  br label %bb4
bb4:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/names:Resolver", ptr %t9, i32 0, i32 8
  %t13 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3alocal_3e_2eLen_3ccompiler_2fnames_3alocal_3e(ptr %v0, ptr %t11)
  store i64 %t13, ptr %l9
  br label %bb5
bb5:
  %t14 = load i64, ptr %l9, !tbaa !24
  %t15 = sub i64 %t14, 1
  store i64 %t15, ptr %l2, !tbaa !24
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/names:Resolver", ptr %t17, i32 0, i32 8
  %t20 = load i64, ptr %l2, !tbaa !24
  %t23 = call %"compiler/names:local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3alocal_3e_2eAt_3ccompiler_2fnames_3alocal_3e(ptr %v0, ptr %t19, i64 %t20)
  store %"compiler/names:local" %t23, ptr %l14
  br label %bb6
bb6:
  %t24 = getelementptr %"compiler/names:local", ptr %l14, i32 0, i32 0
  %t25 = load i32, ptr %t24, !tbaa !23
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t28 = getelementptr %"compiler/ast:Param", ptr %t26, i32 0, i32 1
  %t29 = load i32, ptr %t28, !tbaa !23
  %t32 = icmp eq i32 %t25, %t29
  br i1 %t32, label %bb7, label %bb8
bb7:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/names:Resolver", ptr %t34, i32 0, i32 27
  %t37 = load i64, ptr %l2, !tbaa !24
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t40 = getelementptr %"compiler/ast:Param", ptr %t38, i32 0, i32 0
  %t41 = getelementptr %"compiler/source:Span", ptr %t40, i32 0, i32 0
  %t42 = load i32, ptr %t41, !tbaa !23
  %t44 = sext i32 %t42 to i64
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t36, i64 %t37, i64 %t44)
  br label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb10
bb10:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eraisedErrors(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca ptr
  %l6 = alloca i64
  %l12 = alloca ptr
  %l15 = alloca i1
  %l18 = alloca i1
  %l27 = alloca i64
  %l30 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l35 = alloca i64
  %l37 = alloca i64
  %l42 = alloca %"compiler/names:raisedName"
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/names:Resolver", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/load:Loader", ptr %t4, i32 0, i32 10
  %t7 = load i64, ptr %l1, !tbaa !24
  %t10 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t6, i64 %t7)
  store ptr %t10, ptr %l12
  br label %bb1
bb1:
  %t11 = load ptr, ptr %l12, !tbaa !29
  store ptr %t11, ptr %l3, !tbaa !29
  %t12 = load ptr, ptr %l3, !tbaa !29
  %t14 = getelementptr %"compiler/load:Module", ptr %t12, i32 0, i32 3
  %t15 = load i1, ptr %t14, !tbaa !21
  br i1 %t15, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb4
bb3:
  %t17 = load ptr, ptr %l3, !tbaa !29
  %t19 = getelementptr %"compiler/load:Module", ptr %t17, i32 0, i32 33
  %t20 = load i1, ptr %t19, !tbaa !21
  store i1 %t20, ptr %l15, !tbaa !21
  br label %bb4
bb4:
  %t22 = load i1, ptr %l15, !tbaa !21
  br i1 %t22, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb7
bb6:
  %t23 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t23, 0
  %t27 = icmp eq i64 %t25, 0
  store i1 %t27, ptr %l18, !tbaa !21
  br label %bb7
bb7:
  %t29 = load i1, ptr %l18, !tbaa !21
  br i1 %t29, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb9:
  br label %bb10
bb10:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load i64, ptr %l1, !tbaa !24
  %t32 = load { i64, ptr }, ptr %l2, !tbaa !27
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2esurveyBodies(ptr %v0, ptr %v1, ptr %t30, i64 %t31, { i64, ptr } %t32)
  br label %bb11
bb11:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/names:Resolver", ptr %t36, i32 0, i32 24
  %t40 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3araised_3e_2eLen_3ccompiler_2fnames_3araised_3e(ptr %v0, ptr %t38)
  store i64 %t40, ptr %l27
  br label %bb12
bb12:
  %t41 = load i64, ptr %l27, !tbaa !24
  %t42 = icmp eq i64 %t41, 0
  br i1 %t42, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb14:
  br label %bb15
bb15:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2efirstRaises(ptr %v0, ptr %s0, ptr %t44)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t46, ptr %l30
  br label %bb16
bb16:
  %t47 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l30
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t47, ptr %l4
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2edeclareRaised(ptr %v0, ptr %s0, ptr %t48, i64 %t49, ptr %l4)
  br label %bb17
bb17:
  store ptr %l4, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb18
bb18:
  %t54 = load i64, ptr %l6, !tbaa !24
  store i64 %t54, ptr %l35, !tbaa !24
  %t55 = load ptr, ptr %l5, !tbaa !29
  %t57 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3araisedName_3e_2eLen_H9e36587759e47da85a29e6c0abff1d1c(ptr %s0, ptr %t55)
  store i64 %t57, ptr %l37
  br label %bb19
bb19:
  %t58 = load i64, ptr %l35, !tbaa !24
  %t59 = load i64, ptr %l37, !tbaa !24
  %t60 = icmp slt i64 %t58, %t59
  %t62 = xor i1 %t60, true
  br i1 %t62, label %bb20, label %bb21
bb20:
  br label %bb26
bb21:
  br label %bb22
bb22:
  %t64 = load ptr, ptr %l5, !tbaa !29
  %t65 = load i64, ptr %l6, !tbaa !24
  %t68 = call %"compiler/names:raisedName" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3araisedName_3e_2eAt__H16b49ab3dab0c5fe49005bf48ab18c1b(ptr %s0, ptr %s0, ptr %t64, i64 %t65)
  store %"compiler/names:raisedName" %t68, ptr %l42
  br label %bb23
bb23:
  %t69 = load %"compiler/names:raisedName", ptr %l42
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2enearRaise(ptr %v0, ptr %s0, ptr %s0, ptr %t70, i64 %t71, %"compiler/names:raisedName" %t69, ptr %l4)
  br label %bb24
bb24:
  br label %bb25
bb25:
  %t77 = load i64, ptr %l6, !tbaa !24
  %t80 = add i64 %t77, 1
  store i64 %t80, ptr %l6, !tbaa !24
  br label %bb18
bb26:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/names:Resolver", ptr %t82, i32 0, i32 24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3araised_3e_2eClear_3ccompiler_2fnames_3araised_3e(ptr %v0, ptr %t84)
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eraisedFields(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %lp3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca %"compiler/source:Span"
  %l9 = alloca i32
  %l10 = alloca %"compiler/source:Span"
  %l11 = alloca i32
  %l17 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l25 = alloca { i64, ptr }
  %l28 = alloca ptr
  %l29 = alloca i1
  %l36 = alloca ptr
  %l39 = alloca %"compiler/ast:Param"
  %l41 = alloca ptr
  %l42 = alloca i1
  %l49 = alloca ptr
  %l52 = alloca %"compiler/ast:Param"
  %l56 = alloca ptr
  %l57 = alloca ptr
  %l58 = alloca i64
  %l60 = alloca %"compiler/source:Span"
  %l61 = alloca { i64, [3 x i64] }
  %l62 = alloca %"compiler/diagmsg:Msg"
  %l63 = alloca i64
  %l64 = alloca ptr
  %l66 = alloca %"compiler/source:Span"
  %l67 = alloca %"compiler/ast:Param"
  %l73 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t4 = extractvalue { i64, ptr } { i64 -1, ptr null }, 0
  %t5 = icmp eq i64 %t3, %t4
  %t6 = extractvalue { i64, ptr } %t1, 1
  %t7 = extractvalue { i64, ptr } { i64 -1, ptr null }, 1
  %t8 = icmp eq ptr %t6, %t7
  %t9 = and i1 %t5, %t8
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = icmp sge i64 0, 0
  br i1 %t11, label %bb3, label %bb4
bb2:
  br label %bb7
bb3:
  %t13 = icmp sle i64 0, 1152921504606846975
  br i1 %t13, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_fd3c9d14e235dbbe_bd11dfc23075d8e2)
  unreachable
bb5:
  %t15 = mul i64 0, 8
  %t16 = insertvalue { i64, ptr } undef, i64 0, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t17, ptr %rv
  br label %ret
bb6:
  call void @__olang_check_failed(ptr @olang_loc_fd3c9d14e235dbbe_bd11dfc23075d8e2)
  unreachable
bb7:
  %t19 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aParam_26_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t19, ptr %l17
  br label %bb8
bb8:
  %t20 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store ptr %t20, ptr %lp3
  %t21 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l17
  %t22 = load ptr, ptr %lp3
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t21, ptr %t22
  %t23 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t23, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t25 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t27 = extractvalue { i64, ptr } %t25, 0
  store i64 %t27, ptr %l6, !tbaa !24
  br label %bb9
bb9:
  %t29 = load i64, ptr %l5, !tbaa !24
  %t30 = load i64, ptr %l6, !tbaa !24
  %t33 = icmp slt i64 %t29, %t30
  %t35 = xor i1 %t33, true
  br i1 %t35, label %bb10, label %bb11
bb10:
  br label %bb42
bb11:
  br label %bb12
bb12:
  %t37 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t37, ptr %l25, !tbaa !27
  %t38 = load i64, ptr %l5, !tbaa !24
  %t40 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = getelementptr ptr, ptr %t41, i64 %t38
  %t43 = load ptr, ptr %t42, !tbaa !39
  store ptr %t43, ptr %l7, !tbaa !29
  %t45 = load ptr, ptr %l7, !tbaa !29
  store ptr %t45, ptr %l28, !tbaa !29
  store i1 false, ptr %l29, !tbaa !21
  %t46 = load ptr, ptr %l28, !tbaa !29
  %t47 = icmp ne ptr %t46, null
  br i1 %t47, label %bb13, label %bb14
bb13:
  %t49 = load ptr, ptr %l28, !tbaa !29
  %t50 = load i64, ptr %t49, !range !{i64 0, i64 28}
  %t52 = icmp eq i64 %t50, 0
  store i1 %t52, ptr %l29, !tbaa !21
  br label %bb14
bb14:
  %t53 = load i1, ptr %l29, !tbaa !21
  br i1 %t53, label %bb15, label %bb16
bb15:
  %t54 = load ptr, ptr %l7, !tbaa !29
  %t56 = getelementptr { i64, [4 x i64] }, ptr %t54, i32 0, i32 1
  %t57 = getelementptr { %"compiler/source:Span", i32 }, ptr %t56, i32 0, i32 0
  %t58 = load %"compiler/source:Span", ptr %t57
  store %"compiler/source:Span" %t58, ptr %l8
  %t60 = load ptr, ptr %l7, !tbaa !29
  %t62 = getelementptr { i64, [4 x i64] }, ptr %t60, i32 0, i32 1
  %t63 = getelementptr { %"compiler/source:Span", i32 }, ptr %t62, i32 0, i32 1
  %t64 = load i32, ptr %t63
  store i32 %t64, ptr %l9, !tbaa !23
  br label %bb17
bb16:
  br label %bb20
bb17:
  %t66 = load ptr, ptr %lp3
  store ptr %t66, ptr %l36, !tbaa !29
  %t67 = load %"compiler/source:Span", ptr %l8
  %t68 = load i32, ptr %l9, !tbaa !23
  %t71 = call %"compiler/ast:Param" @compiler_2fast_3aParam_2ector(ptr %v2, ptr %v2, ptr %v2, %"compiler/source:Span" %t67, i32 %t68, ptr null, ptr null)
  store %"compiler/ast:Param" %t71, ptr %l39
  br label %bb18
bb18:
  %t72 = load %"compiler/ast:Param", ptr %l39
  %t73 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store %"compiler/ast:Param" %t72, ptr %t73
  %t74 = load ptr, ptr %l36, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aParam_26_3e_2ePush_3ccompiler_2fast_3aParam_26_3e(ptr %v2, ptr %v2, ptr %t74, ptr %t73)
  br label %bb19
bb19:
  br label %bb40
bb20:
  %t76 = load ptr, ptr %l7, !tbaa !29
  store ptr %t76, ptr %l41, !tbaa !29
  store i1 false, ptr %l42, !tbaa !21
  %t77 = load ptr, ptr %l41, !tbaa !29
  %t78 = icmp ne ptr %t77, null
  br i1 %t78, label %bb21, label %bb22
bb21:
  %t80 = load ptr, ptr %l41, !tbaa !29
  %t81 = load i64, ptr %t80, !range !{i64 0, i64 28}
  %t83 = icmp eq i64 %t81, 24
  store i1 %t83, ptr %l42, !tbaa !21
  br label %bb22
bb22:
  %t84 = load i1, ptr %l42, !tbaa !21
  br i1 %t84, label %bb23, label %bb24
bb23:
  %t85 = load ptr, ptr %l7, !tbaa !29
  %t87 = getelementptr { i64, [4 x i64] }, ptr %t85, i32 0, i32 1
  %t88 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t87, i32 0, i32 0
  %t89 = load %"compiler/source:Span", ptr %t88
  store %"compiler/source:Span" %t89, ptr %l10
  %t91 = load ptr, ptr %l7, !tbaa !29
  %t93 = getelementptr { i64, [4 x i64] }, ptr %t91, i32 0, i32 1
  %t94 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t93, i32 0, i32 1
  %t95 = load i32, ptr %t94
  store i32 %t95, ptr %l11, !tbaa !23
  br label %bb25
bb24:
  br label %bb28
bb25:
  %t97 = load ptr, ptr %lp3
  store ptr %t97, ptr %l49, !tbaa !29
  %t98 = load %"compiler/source:Span", ptr %l10
  %t99 = load i32, ptr %l11, !tbaa !23
  %t102 = call %"compiler/ast:Param" @compiler_2fast_3aParam_2ector(ptr %v2, ptr %v2, ptr %v2, %"compiler/source:Span" %t98, i32 %t99, ptr null, ptr null)
  store %"compiler/ast:Param" %t102, ptr %l52
  br label %bb26
bb26:
  %t103 = load %"compiler/ast:Param", ptr %l52
  %t104 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store %"compiler/ast:Param" %t103, ptr %t104
  %t105 = load ptr, ptr %l49, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aParam_26_3e_2ePush_3ccompiler_2fast_3aParam_26_3e(ptr %v2, ptr %v2, ptr %t105, ptr %t104)
  br label %bb27
bb27:
  br label %bb40
bb28:
  br i1 true, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb39
bb31:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = getelementptr %"compiler/names:Resolver", ptr %t107, i32 0, i32 0
  %t110 = load ptr, ptr %t109, !tbaa !29
  %t112 = getelementptr %"compiler/load:Loader", ptr %t110, i32 0, i32 4
  %t113 = load ptr, ptr %t112, !tbaa !29
  store ptr %t113, ptr %l56, !tbaa !29
  %t114 = load ptr, ptr %l0, !tbaa !29
  store ptr %t114, ptr %l57, !tbaa !29
  store i64 %a1, ptr %l58, !tbaa !24
  %t116 = load ptr, ptr %l7, !tbaa !29
  %t118 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t116)
  store %"compiler/source:Span" %t118, ptr %l60
  br label %bb32
bb32:
  %t119 = load ptr, ptr %l57, !tbaa !29
  %t120 = load i64, ptr %l58, !tbaa !24
  %t121 = load %"compiler/source:Span", ptr %l60
  %t122 = call { i64, [3 x i64] } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eat(ptr %v0, ptr %t119, i64 %t120, %"compiler/source:Span" %t121)
  store { i64, [3 x i64] } %t122, ptr %l61
  br label %bb33
bb33:
  %t123 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eRaisedFieldUnnamed(ptr %v0)
  store %"compiler/diagmsg:Msg" %t123, ptr %l62
  br label %bb34
bb34:
  %t124 = load ptr, ptr %l56, !tbaa !29
  %t125 = load { i64, [3 x i64] }, ptr %l61
  %t126 = load %"compiler/diagmsg:Msg", ptr %l62
  %t127 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v0, ptr %t124, { i64, [3 x i64] } %t125, %"compiler/diagmsg:Msg" %t126)
  store i64 %t127, ptr %l63
  br label %bb35
bb35:
  %t128 = load ptr, ptr %lp3
  store ptr %t128, ptr %l64, !tbaa !29
  %t129 = load ptr, ptr %l7, !tbaa !29
  %t131 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t129)
  store %"compiler/source:Span" %t131, ptr %l66
  br label %bb36
bb36:
  %t132 = load %"compiler/source:Span", ptr %l66
  %t133 = call %"compiler/ast:Param" @compiler_2fast_3aParam_2ector(ptr %v2, ptr %v2, ptr %v2, %"compiler/source:Span" %t132, i32 0, ptr null, ptr null)
  store %"compiler/ast:Param" %t133, ptr %l67
  br label %bb37
bb37:
  %t134 = load %"compiler/ast:Param", ptr %l67
  %t135 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store %"compiler/ast:Param" %t134, ptr %t135
  %t136 = load ptr, ptr %l64, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aParam_26_3e_2ePush_3ccompiler_2fast_3aParam_26_3e(ptr %v2, ptr %v2, ptr %t136, ptr %t135)
  br label %bb38
bb38:
  br label %bb40
bb39:
  call void @__olang_check_failed(ptr @olang_loc_f7896ae45faa6454_3785f9c9b8d393e0)
  unreachable
bb40:
  br label %bb41
bb41:
  %t138 = load i64, ptr %l5, !tbaa !24
  %t141 = add i64 %t138, 1
  store i64 %t141, ptr %l5, !tbaa !24
  br label %bb9
bb42:
  %t143 = load ptr, ptr %lp3
  %t145 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aParam_26_3e_2eToArray_3ccompiler_2fast_3aParam_26_3e(ptr %v2, ptr %v2, ptr %t143)
  store { i64, ptr } %t145, ptr %l73
  br label %bb43
bb43:
  %t146 = load { i64, ptr }, ptr %l73, !tbaa !27
  store { i64, ptr } %t146, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2esig(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca ptr
  %l24 = alloca { i64, ptr }
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca ptr
  %l37 = alloca i1
  %l47 = alloca ptr
  %l55 = alloca ptr
  %l82 = alloca { i64, ptr }
  %l99 = alloca { i64, ptr }
  %l116 = alloca { i64, ptr }
  %l133 = alloca { i64, ptr }
  %l150 = alloca { i64, ptr }
  %l168 = alloca i1
  %l177 = alloca ptr
  %l185 = alloca ptr
  %l199 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i1 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Func", ptr %t1, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load ptr, ptr %l1, !tbaa !29
  %t9 = getelementptr %"compiler/ast:Func", ptr %t7, i32 0, i32 5
  %t10 = load { i64, ptr }, ptr %t9, !tbaa !27
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeParams(ptr %v0, ptr %v1, ptr %t6, { i64, ptr } %t10)
  br label %bb1
bb1:
  %t13 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr %"compiler/ast:Func", ptr %t13, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t18 = icmp eq ptr %t16, null
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb2, label %bb3
bb2:
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr %"compiler/ast:Func", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = icmp eq ptr %t25, null
  br i1 %t27, label %bb4, label %bb5
bb3:
  store i1 false, ptr %l37, !tbaa !21
  br label %bb7
bb4:
  call void @__olang_check_failed(ptr @olang_loc_f7af4f17da675e9e_7adee505b4454aba)
  unreachable
bb5:
  br label %bb6
bb6:
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t31 = getelementptr %"compiler/ast:Func", ptr %t29, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t35 = getelementptr %"compiler/ast:Param", ptr %t32, i32 0, i32 2
  %t36 = load ptr, ptr %t35, !tbaa !29
  %t38 = icmp eq ptr %t36, null
  %t40 = xor i1 %t38, true
  store i1 %t40, ptr %l37, !tbaa !21
  br label %bb7
bb7:
  %t42 = load i1, ptr %l37, !tbaa !21
  br i1 %t42, label %bb8, label %bb9
bb8:
  %t43 = load ptr, ptr %l0, !tbaa !29
  store ptr %t43, ptr %l47, !tbaa !29
  %t44 = load ptr, ptr %l1, !tbaa !29
  %t46 = getelementptr %"compiler/ast:Func", ptr %t44, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t49 = icmp eq ptr %t47, null
  br i1 %t49, label %bb10, label %bb11
bb9:
  br label %bb18
bb10:
  call void @__olang_check_failed(ptr @olang_loc_4b15e456fcf3a345_7adab712aa943e41)
  unreachable
bb11:
  br label %bb12
bb12:
  %t51 = load ptr, ptr %l1, !tbaa !29
  %t53 = getelementptr %"compiler/ast:Func", ptr %t51, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !29
  %t57 = getelementptr %"compiler/ast:Param", ptr %t54, i32 0, i32 2
  %t58 = load ptr, ptr %t57, !tbaa !29
  %t59 = load ptr, ptr %l47, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ereceiverVars(ptr %v0, ptr %v1, ptr %t59, ptr %t58, i1 false)
  br label %bb13
bb13:
  %t61 = load ptr, ptr %l0, !tbaa !29
  store ptr %t61, ptr %l55, !tbaa !29
  %t62 = load ptr, ptr %l1, !tbaa !29
  %t64 = getelementptr %"compiler/ast:Func", ptr %t62, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t67 = icmp eq ptr %t65, null
  br i1 %t67, label %bb14, label %bb15
bb14:
  call void @__olang_check_failed(ptr @olang_loc_2e22b0ea443c0bf0_cc72b894f0b6250c)
  unreachable
bb15:
  br label %bb16
bb16:
  %t69 = load ptr, ptr %l1, !tbaa !29
  %t71 = getelementptr %"compiler/ast:Func", ptr %t69, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !29
  %t75 = getelementptr %"compiler/ast:Param", ptr %t72, i32 0, i32 2
  %t76 = load ptr, ptr %t75, !tbaa !29
  %t77 = load ptr, ptr %l55, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeRef(ptr %v0, ptr %v1, ptr %t77, ptr %t76)
  br label %bb17
bb17:
  br label %bb18
bb18:
  %t79 = load ptr, ptr %l1, !tbaa !29
  %t81 = getelementptr %"compiler/ast:Func", ptr %t79, i32 0, i32 8
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t84 = icmp eq ptr %t82, null
  %t86 = xor i1 %t84, true
  br i1 %t86, label %bb19, label %bb20
bb19:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t89 = load ptr, ptr %l1, !tbaa !29
  %t91 = getelementptr %"compiler/ast:Func", ptr %t89, i32 0, i32 8
  %t92 = load ptr, ptr %t91, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ereceiverVars(ptr %v0, ptr %v1, ptr %t88, ptr %t92, i1 false)
  br label %bb21
bb20:
  br label %bb23
bb21:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t97 = load ptr, ptr %l1, !tbaa !29
  %t99 = getelementptr %"compiler/ast:Func", ptr %t97, i32 0, i32 8
  %t100 = load ptr, ptr %t99, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeRef(ptr %v0, ptr %v1, ptr %t96, ptr %t100)
  br label %bb22
bb22:
  br label %bb23
bb23:
  %t103 = load ptr, ptr %l1, !tbaa !29
  %t105 = getelementptr %"compiler/ast:Func", ptr %t103, i32 0, i32 5
  %t106 = load { i64, ptr }, ptr %t105, !tbaa !27
  store { i64, ptr } %t106, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t108 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t110 = extractvalue { i64, ptr } %t108, 0
  store i64 %t110, ptr %l6, !tbaa !24
  br label %bb24
bb24:
  %t112 = load i64, ptr %l5, !tbaa !24
  %t113 = load i64, ptr %l6, !tbaa !24
  %t116 = icmp slt i64 %t112, %t113
  %t118 = xor i1 %t116, true
  br i1 %t118, label %bb25, label %bb26
bb25:
  br label %bb30
bb26:
  br label %bb27
bb27:
  %t120 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t120, ptr %l82, !tbaa !27
  %t121 = load i64, ptr %l5, !tbaa !24
  %t123 = getelementptr { i64, ptr }, ptr %l82, i32 0, i32 1
  %t124 = load ptr, ptr %t123, !tbaa !27
  %t125 = getelementptr ptr, ptr %t124, i64 %t121
  %t126 = load ptr, ptr %t125, !tbaa !39
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t131 = getelementptr %"compiler/ast:TypeParam", ptr %t126, i32 0, i32 5
  %t132 = load ptr, ptr %t131, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeRef(ptr %v0, ptr %v1, ptr %t128, ptr %t132)
  br label %bb28
bb28:
  br label %bb29
bb29:
  %t135 = load i64, ptr %l5, !tbaa !24
  %t138 = add i64 %t135, 1
  store i64 %t138, ptr %l5, !tbaa !24
  br label %bb24
bb30:
  %t140 = load ptr, ptr %l3, !tbaa !29
  %t142 = getelementptr %"compiler/ast:Sig", ptr %t140, i32 0, i32 0
  %t143 = load { i64, ptr }, ptr %t142, !tbaa !27
  store { i64, ptr } %t143, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t145 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t147 = extractvalue { i64, ptr } %t145, 0
  store i64 %t147, ptr %l10, !tbaa !24
  br label %bb31
bb31:
  %t149 = load i64, ptr %l9, !tbaa !24
  %t150 = load i64, ptr %l10, !tbaa !24
  %t153 = icmp slt i64 %t149, %t150
  %t155 = xor i1 %t153, true
  br i1 %t155, label %bb32, label %bb33
bb32:
  br label %bb37
bb33:
  br label %bb34
bb34:
  %t157 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t157, ptr %l99, !tbaa !27
  %t158 = load i64, ptr %l9, !tbaa !24
  %t160 = getelementptr { i64, ptr }, ptr %l99, i32 0, i32 1
  %t161 = load ptr, ptr %t160, !tbaa !27
  %t162 = getelementptr ptr, ptr %t161, i64 %t158
  %t163 = load ptr, ptr %t162, !tbaa !39
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t168 = getelementptr %"compiler/ast:Param", ptr %t163, i32 0, i32 2
  %t169 = load ptr, ptr %t168, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeRef(ptr %v0, ptr %v1, ptr %t165, ptr %t169)
  br label %bb35
bb35:
  br label %bb36
bb36:
  %t172 = load i64, ptr %l9, !tbaa !24
  %t175 = add i64 %t172, 1
  store i64 %t175, ptr %l9, !tbaa !24
  br label %bb31
bb37:
  %t177 = load ptr, ptr %l3, !tbaa !29
  %t179 = getelementptr %"compiler/ast:Sig", ptr %t177, i32 0, i32 1
  %t180 = load { i64, ptr }, ptr %t179, !tbaa !27
  store { i64, ptr } %t180, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t182 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t184 = extractvalue { i64, ptr } %t182, 0
  store i64 %t184, ptr %l14, !tbaa !24
  br label %bb38
bb38:
  %t186 = load i64, ptr %l13, !tbaa !24
  %t187 = load i64, ptr %l14, !tbaa !24
  %t190 = icmp slt i64 %t186, %t187
  %t192 = xor i1 %t190, true
  br i1 %t192, label %bb39, label %bb40
bb39:
  br label %bb44
bb40:
  br label %bb41
bb41:
  %t194 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t194, ptr %l116, !tbaa !27
  %t195 = load i64, ptr %l13, !tbaa !24
  %t197 = getelementptr { i64, ptr }, ptr %l116, i32 0, i32 1
  %t198 = load ptr, ptr %t197, !tbaa !27
  %t199 = getelementptr ptr, ptr %t198, i64 %t195
  %t200 = load ptr, ptr %t199, !tbaa !39
  %t202 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeRef(ptr %v0, ptr %v1, ptr %t202, ptr %t200)
  br label %bb42
bb42:
  br label %bb43
bb43:
  %t207 = load i64, ptr %l13, !tbaa !24
  %t210 = add i64 %t207, 1
  store i64 %t210, ptr %l13, !tbaa !24
  br label %bb38
bb44:
  %t212 = load ptr, ptr %l3, !tbaa !29
  %t214 = getelementptr %"compiler/ast:Sig", ptr %t212, i32 0, i32 3
  %t215 = load { i64, ptr }, ptr %t214, !tbaa !27
  store { i64, ptr } %t215, ptr %l16, !tbaa !27
  store i64 0, ptr %l17, !tbaa !24
  %t217 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t219 = extractvalue { i64, ptr } %t217, 0
  store i64 %t219, ptr %l18, !tbaa !24
  br label %bb45
bb45:
  %t221 = load i64, ptr %l17, !tbaa !24
  %t222 = load i64, ptr %l18, !tbaa !24
  %t225 = icmp slt i64 %t221, %t222
  %t227 = xor i1 %t225, true
  br i1 %t227, label %bb46, label %bb47
bb46:
  br label %bb51
bb47:
  br label %bb48
bb48:
  %t229 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t229, ptr %l133, !tbaa !27
  %t230 = load i64, ptr %l17, !tbaa !24
  %t232 = getelementptr { i64, ptr }, ptr %l133, i32 0, i32 1
  %t233 = load ptr, ptr %t232, !tbaa !27
  %t234 = getelementptr ptr, ptr %t233, i64 %t230
  %t235 = load ptr, ptr %t234, !tbaa !39
  %t237 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2epath(ptr %v0, ptr %v1, ptr %t237, ptr %t235)
  br label %bb49
bb49:
  br label %bb50
bb50:
  %t242 = load i64, ptr %l17, !tbaa !24
  %t245 = add i64 %t242, 1
  store i64 %t245, ptr %l17, !tbaa !24
  br label %bb45
bb51:
  %t247 = load ptr, ptr %l3, !tbaa !29
  %t249 = getelementptr %"compiler/ast:Sig", ptr %t247, i32 0, i32 0
  %t250 = load { i64, ptr }, ptr %t249, !tbaa !27
  store { i64, ptr } %t250, ptr %l20, !tbaa !27
  store i64 0, ptr %l21, !tbaa !24
  %t252 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t254 = extractvalue { i64, ptr } %t252, 0
  store i64 %t254, ptr %l22, !tbaa !24
  br label %bb52
bb52:
  %t256 = load i64, ptr %l21, !tbaa !24
  %t257 = load i64, ptr %l22, !tbaa !24
  %t260 = icmp slt i64 %t256, %t257
  %t262 = xor i1 %t260, true
  br i1 %t262, label %bb53, label %bb54
bb53:
  br label %bb61
bb54:
  br label %bb55
bb55:
  %t264 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t264, ptr %l150, !tbaa !27
  %t265 = load i64, ptr %l21, !tbaa !24
  %t267 = getelementptr { i64, ptr }, ptr %l150, i32 0, i32 1
  %t268 = load ptr, ptr %t267, !tbaa !27
  %t269 = getelementptr ptr, ptr %t268, i64 %t265
  %t270 = load ptr, ptr %t269, !tbaa !39
  store ptr %t270, ptr %l23, !tbaa !29
  %t272 = load ptr, ptr %l23, !tbaa !29
  %t274 = getelementptr %"compiler/ast:Param", ptr %t272, i32 0, i32 3
  %t275 = load ptr, ptr %t274, !tbaa !29
  %t277 = icmp eq ptr %t275, null
  %t279 = xor i1 %t277, true
  br i1 %t279, label %bb56, label %bb57
bb56:
  %t281 = load ptr, ptr %l0, !tbaa !29
  %t282 = load ptr, ptr %l23, !tbaa !29
  %t284 = getelementptr %"compiler/ast:Param", ptr %t282, i32 0, i32 3
  %t285 = load ptr, ptr %t284, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t281, ptr %t285)
  br label %bb58
bb57:
  br label %bb59
bb58:
  br label %bb59
bb59:
  br label %bb60
bb60:
  %t289 = load i64, ptr %l21, !tbaa !24
  %t292 = add i64 %t289, 1
  store i64 %t292, ptr %l21, !tbaa !24
  br label %bb52
bb61:
  %t294 = load ptr, ptr %l1, !tbaa !29
  %t296 = getelementptr %"compiler/ast:Func", ptr %t294, i32 0, i32 1
  %t297 = load ptr, ptr %t296, !tbaa !29
  %t299 = icmp eq ptr %t297, null
  %t301 = xor i1 %t299, true
  br i1 %t301, label %bb62, label %bb63
bb62:
  %t303 = load ptr, ptr %l1, !tbaa !29
  %t305 = getelementptr %"compiler/ast:Func", ptr %t303, i32 0, i32 1
  %t306 = load ptr, ptr %t305, !tbaa !29
  %t308 = icmp eq ptr %t306, null
  br i1 %t308, label %bb64, label %bb65
bb63:
  store i1 false, ptr %l168, !tbaa !21
  br label %bb67
bb64:
  call void @__olang_check_failed(ptr @olang_loc_668f2e502e7138cf_4506733ced80a77b)
  unreachable
bb65:
  br label %bb66
bb66:
  %t310 = load ptr, ptr %l1, !tbaa !29
  %t312 = getelementptr %"compiler/ast:Func", ptr %t310, i32 0, i32 1
  %t313 = load ptr, ptr %t312, !tbaa !29
  %t316 = getelementptr %"compiler/ast:Param", ptr %t313, i32 0, i32 1
  %t317 = load i32, ptr %t316, !tbaa !23
  %t319 = icmp ne i32 %t317, 0
  store i1 %t319, ptr %l168, !tbaa !21
  br label %bb67
bb67:
  %t321 = load i1, ptr %l168, !tbaa !21
  br i1 %t321, label %bb68, label %bb69
bb68:
  %t322 = load ptr, ptr %l0, !tbaa !29
  store ptr %t322, ptr %l177, !tbaa !29
  %t323 = load ptr, ptr %l1, !tbaa !29
  %t325 = getelementptr %"compiler/ast:Func", ptr %t323, i32 0, i32 1
  %t326 = load ptr, ptr %t325, !tbaa !29
  %t328 = icmp eq ptr %t326, null
  br i1 %t328, label %bb70, label %bb71
bb69:
  br label %bb81
bb70:
  call void @__olang_check_failed(ptr @olang_loc_97417a283903a82_ac3e213ae41817f6)
  unreachable
bb71:
  br label %bb72
bb72:
  %t330 = load ptr, ptr %l1, !tbaa !29
  %t332 = getelementptr %"compiler/ast:Func", ptr %t330, i32 0, i32 1
  %t333 = load ptr, ptr %t332, !tbaa !29
  %t334 = load i1, ptr %l2, !tbaa !21
  %t335 = load ptr, ptr %l177, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eparam(ptr %v0, ptr %v1, ptr %t335, ptr %t333, i1 %t334)
  br label %bb73
bb73:
  %t338 = load i1, ptr %l2, !tbaa !21
  br i1 %t338, label %bb74, label %bb75
bb74:
  %t340 = load ptr, ptr %l0, !tbaa !29
  store ptr %t340, ptr %l185, !tbaa !29
  %t341 = load ptr, ptr %l1, !tbaa !29
  %t343 = getelementptr %"compiler/ast:Func", ptr %t341, i32 0, i32 1
  %t344 = load ptr, ptr %t343, !tbaa !29
  %t346 = icmp eq ptr %t344, null
  br i1 %t346, label %bb76, label %bb77
bb75:
  br label %bb80
bb76:
  call void @__olang_check_failed(ptr @olang_loc_6175710135d1c169_c21d56ac8dc09c5d)
  unreachable
bb77:
  br label %bb78
bb78:
  %t348 = load ptr, ptr %l1, !tbaa !29
  %t350 = getelementptr %"compiler/ast:Func", ptr %t348, i32 0, i32 1
  %t351 = load ptr, ptr %t350, !tbaa !29
  %t352 = load ptr, ptr %l185, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eparamStart(ptr %v0, ptr %v1, ptr %t352, ptr %t351)
  br label %bb79
bb79:
  br label %bb80
bb80:
  br label %bb81
bb81:
  %t354 = load ptr, ptr %l3, !tbaa !29
  %t356 = getelementptr %"compiler/ast:Sig", ptr %t354, i32 0, i32 0
  %t357 = load { i64, ptr }, ptr %t356, !tbaa !27
  store { i64, ptr } %t357, ptr %l24, !tbaa !27
  store i64 0, ptr %l25, !tbaa !24
  %t359 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t361 = extractvalue { i64, ptr } %t359, 0
  store i64 %t361, ptr %l26, !tbaa !24
  br label %bb82
bb82:
  %t363 = load i64, ptr %l25, !tbaa !24
  %t364 = load i64, ptr %l26, !tbaa !24
  %t367 = icmp slt i64 %t363, %t364
  %t369 = xor i1 %t367, true
  br i1 %t369, label %bb83, label %bb84
bb83:
  br label %bb92
bb84:
  br label %bb85
bb85:
  %t371 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t371, ptr %l199, !tbaa !27
  %t372 = load i64, ptr %l25, !tbaa !24
  %t374 = getelementptr { i64, ptr }, ptr %l199, i32 0, i32 1
  %t375 = load ptr, ptr %t374, !tbaa !27
  %t376 = getelementptr ptr, ptr %t375, i64 %t372
  %t377 = load ptr, ptr %t376, !tbaa !39
  store ptr %t377, ptr %l27, !tbaa !29
  %t379 = load ptr, ptr %l0, !tbaa !29
  %t380 = load ptr, ptr %l27, !tbaa !29
  %t381 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eparam(ptr %v0, ptr %v1, ptr %t379, ptr %t380, i1 %t381)
  br label %bb86
bb86:
  %t385 = load i1, ptr %l2, !tbaa !21
  br i1 %t385, label %bb87, label %bb88
bb87:
  %t387 = load ptr, ptr %l0, !tbaa !29
  %t388 = load ptr, ptr %l27, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eparamStart(ptr %v0, ptr %v1, ptr %t387, ptr %t388)
  br label %bb89
bb88:
  br label %bb90
bb89:
  br label %bb90
bb90:
  br label %bb91
bb91:
  %t391 = load i64, ptr %l25, !tbaa !24
  %t394 = add i64 %t391, 1
  store i64 %t394, ptr %l25, !tbaa !24
  br label %bb82
bb92:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2estartItem(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l19 = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/names:Resolver", ptr %t1, i32 0, i32 7
  store i64 %a1, ptr %t5, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/names:Resolver", ptr %t6, i32 0, i32 8
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3alocal_3e_2eClear_3ccompiler_2fnames_3alocal_3e(ptr %v0, ptr %t8)
  br label %bb1
bb1:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/names:Resolver", ptr %t10, i32 0, i32 27
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eClear_3cI64_2c_20I64_3e(ptr %v0, ptr %t12)
  br label %bb2
bb2:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/names:Resolver", ptr %t14, i32 0, i32 9
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_Hb7e448baed1c9668005f7dc6325e5707(ptr %v0, ptr %t16)
  br label %bb3
bb3:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/names:Resolver", ptr %t18, i32 0, i32 10
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fsource__H263d9150b58237aac70cb39b886b10bb(ptr %v0, ptr %t20)
  br label %bb4
bb4:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/names:Resolver", ptr %t22, i32 0, i32 11
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eClear_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t24)
  br label %bb5
bb5:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/names:Resolver", ptr %t26, i32 0, i32 12
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eClear_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t28)
  br label %bb6
bb6:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/names:Resolver", ptr %t30, i32 0, i32 18
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eClear_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t32)
  br label %bb7
bb7:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/names:Resolver", ptr %t34, i32 0, i32 13
  store i1 false, ptr %t36, !tbaa !21
  %t37 = load ptr, ptr %l0, !tbaa !29
  store ptr %t37, ptr %l19, !tbaa !29
  %t38 = load ptr, ptr %l19, !tbaa !29
  %t39 = getelementptr %"compiler/names:Resolver", ptr %t38, i32 0, i32 15
  %t40 = load i64, ptr %t39, !tbaa !24
  %t43 = add i64 %t40, 1
  %t45 = load ptr, ptr %l19, !tbaa !29
  %t46 = getelementptr %"compiler/names:Resolver", ptr %t45, i32 0, i32 15
  store i64 %t43, ptr %t46, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l11 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l13 = alloca ptr
  %l14 = alloca i64
  %l15 = alloca %"compiler/source:Span"
  %l16 = alloca ptr
  %l17 = alloca i64
  %l18 = alloca { i64, ptr }
  %l19 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca i64
  %l26 = alloca ptr
  %l27 = alloca ptr
  %l28 = alloca ptr
  %l29 = alloca ptr
  %l30 = alloca ptr
  %l31 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l33 = alloca i64
  %l34 = alloca i64
  %l36 = alloca { i64, ptr }
  %l37 = alloca ptr
  %l38 = alloca { i64, ptr }
  %l39 = alloca i64
  %l40 = alloca i64
  %l42 = alloca ptr
  %l43 = alloca ptr
  %l44 = alloca i64
  %l45 = alloca { i64, ptr }
  %l48 = alloca ptr
  %l49 = alloca i1
  %l56 = alloca ptr
  %l57 = alloca i1
  %l64 = alloca ptr
  %l65 = alloca i1
  %l72 = alloca ptr
  %l73 = alloca i1
  %l85 = alloca ptr
  %l86 = alloca i1
  %l98 = alloca ptr
  %l99 = alloca i1
  %l106 = alloca ptr
  %l107 = alloca i1
  %l114 = alloca ptr
  %l115 = alloca i1
  %l127 = alloca ptr
  %l128 = alloca i1
  %l134 = alloca i64
  %l156 = alloca ptr
  %l157 = alloca i1
  %l169 = alloca i64
  %l184 = alloca ptr
  %l185 = alloca i1
  %l197 = alloca ptr
  %l198 = alloca i1
  %l205 = alloca ptr
  %l206 = alloca i1
  %l218 = alloca { i64, ptr }
  %l227 = alloca ptr
  %l228 = alloca i1
  %l233 = alloca ptr
  %l234 = alloca i1
  %l242 = alloca ptr
  %l243 = alloca i1
  %l259 = alloca ptr
  %l260 = alloca i1
  %l271 = alloca ptr
  %l272 = alloca i1
  %l296 = alloca { i64, ptr }
  %l305 = alloca ptr
  %l306 = alloca i1
  %l320 = alloca { i64, ptr }
  %l331 = alloca ptr
  %l332 = alloca i1
  %l343 = alloca ptr
  %l344 = alloca i1
  %l350 = alloca i64
  %l356 = alloca ptr
  %l357 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %l48, !tbaa !29
  store i1 false, ptr %l49, !tbaa !21
  %t6 = load ptr, ptr %l48, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l48, !tbaa !29
  %t10 = load i64, ptr %t9, !range !{i64 0, i64 22}
  %t12 = icmp eq i64 %t10, 0
  store i1 %t12, ptr %l49, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l49, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr { i64, [4 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", ptr }, ptr %t16, i32 0, i32 1
  %t18 = load ptr, ptr %t17
  store ptr %t18, ptr %l2, !tbaa !29
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexprStmt(ptr %v0, ptr %v1, ptr %t20, ptr %t21)
  br label %bb9
bb9:
  br label %bb213
bb10:
  %t24 = load ptr, ptr %l1, !tbaa !29
  store ptr %t24, ptr %l56, !tbaa !29
  store i1 false, ptr %l57, !tbaa !21
  %t25 = load ptr, ptr %l56, !tbaa !29
  %t26 = icmp ne ptr %t25, null
  br i1 %t26, label %bb11, label %bb12
bb11:
  %t28 = load ptr, ptr %l56, !tbaa !29
  %t29 = load i64, ptr %t28, !range !{i64 0, i64 22}
  %t31 = icmp eq i64 %t29, 1
  store i1 %t31, ptr %l57, !tbaa !21
  br label %bb12
bb12:
  %t32 = load i1, ptr %l57, !tbaa !21
  br i1 %t32, label %bb13, label %bb14
bb13:
  %t33 = load ptr, ptr %l1, !tbaa !29
  %t35 = getelementptr { i64, [4 x i64] }, ptr %t33, i32 0, i32 1
  %t36 = getelementptr { %"compiler/source:Span", ptr }, ptr %t35, i32 0, i32 1
  %t37 = load ptr, ptr %t36
  store ptr %t37, ptr %l3, !tbaa !29
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2evarDecl(ptr %v0, ptr %v1, ptr %t39, ptr %t40)
  br label %bb16
bb16:
  br label %bb213
bb17:
  %t43 = load ptr, ptr %l1, !tbaa !29
  store ptr %t43, ptr %l64, !tbaa !29
  store i1 false, ptr %l65, !tbaa !21
  %t44 = load ptr, ptr %l64, !tbaa !29
  %t45 = icmp ne ptr %t44, null
  br i1 %t45, label %bb18, label %bb19
bb18:
  %t47 = load ptr, ptr %l64, !tbaa !29
  %t48 = load i64, ptr %t47, !range !{i64 0, i64 22}
  %t50 = icmp eq i64 %t48, 2
  store i1 %t50, ptr %l65, !tbaa !21
  br label %bb19
bb19:
  %t51 = load i1, ptr %l65, !tbaa !21
  br i1 %t51, label %bb20, label %bb21
bb20:
  %t52 = load ptr, ptr %l1, !tbaa !29
  %t54 = getelementptr { i64, [4 x i64] }, ptr %t52, i32 0, i32 1
  %t55 = getelementptr { %"compiler/source:Span", ptr }, ptr %t54, i32 0, i32 1
  %t56 = load ptr, ptr %t55
  store ptr %t56, ptr %l4, !tbaa !29
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2emulti(ptr %v0, ptr %v1, ptr %t58, ptr %t59)
  br label %bb23
bb23:
  br label %bb213
bb24:
  %t62 = load ptr, ptr %l1, !tbaa !29
  store ptr %t62, ptr %l72, !tbaa !29
  store i1 false, ptr %l73, !tbaa !21
  %t63 = load ptr, ptr %l72, !tbaa !29
  %t64 = icmp ne ptr %t63, null
  br i1 %t64, label %bb25, label %bb26
bb25:
  %t66 = load ptr, ptr %l72, !tbaa !29
  %t67 = load i64, ptr %t66, !range !{i64 0, i64 22}
  %t69 = icmp eq i64 %t67, 3
  store i1 %t69, ptr %l73, !tbaa !21
  br label %bb26
bb26:
  %t70 = load i1, ptr %l73, !tbaa !21
  br i1 %t70, label %bb27, label %bb28
bb27:
  %t71 = load ptr, ptr %l1, !tbaa !29
  %t73 = getelementptr { i64, [4 x i64] }, ptr %t71, i32 0, i32 1
  %t74 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t73, i32 0, i32 2
  %t75 = load ptr, ptr %t74
  store ptr %t75, ptr %l5, !tbaa !29
  %t77 = load ptr, ptr %l1, !tbaa !29
  %t79 = getelementptr { i64, [4 x i64] }, ptr %t77, i32 0, i32 1
  %t80 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t79, i32 0, i32 3
  %t81 = load ptr, ptr %t80
  store ptr %t81, ptr %l6, !tbaa !29
  br label %bb29
bb28:
  br label %bb32
bb29:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etarget(ptr %v0, ptr %v1, ptr %t83, ptr %t84)
  br label %bb30
bb30:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t88 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t87, ptr %t88)
  br label %bb31
bb31:
  br label %bb213
bb32:
  %t92 = load ptr, ptr %l1, !tbaa !29
  store ptr %t92, ptr %l85, !tbaa !29
  store i1 false, ptr %l86, !tbaa !21
  %t93 = load ptr, ptr %l85, !tbaa !29
  %t94 = icmp ne ptr %t93, null
  br i1 %t94, label %bb33, label %bb34
bb33:
  %t96 = load ptr, ptr %l85, !tbaa !29
  %t97 = load i64, ptr %t96, !range !{i64 0, i64 22}
  %t99 = icmp eq i64 %t97, 4
  store i1 %t99, ptr %l86, !tbaa !21
  br label %bb34
bb34:
  %t100 = load i1, ptr %l86, !tbaa !21
  br i1 %t100, label %bb35, label %bb36
bb35:
  %t101 = load ptr, ptr %l1, !tbaa !29
  %t103 = getelementptr { i64, [4 x i64] }, ptr %t101, i32 0, i32 1
  %t104 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t103, i32 0, i32 1
  %t105 = load ptr, ptr %t104
  store ptr %t105, ptr %l7, !tbaa !29
  %t107 = load ptr, ptr %l1, !tbaa !29
  %t109 = getelementptr { i64, [4 x i64] }, ptr %t107, i32 0, i32 1
  %t110 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t109, i32 0, i32 2
  %t111 = load { i64, ptr }, ptr %t110
  store { i64, ptr } %t111, ptr %l8, !tbaa !27
  br label %bb37
bb36:
  br label %bb40
bb37:
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t114 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2estmt(ptr %v0, ptr %v1, ptr %t113, ptr %t114)
  br label %bb38
bb38:
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t119 = load { i64, ptr }, ptr %l8, !tbaa !27
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eclauses(ptr %v0, ptr %v1, ptr %t118, { i64, ptr } %t119)
  br label %bb39
bb39:
  br label %bb213
bb40:
  %t122 = load ptr, ptr %l1, !tbaa !29
  store ptr %t122, ptr %l98, !tbaa !29
  store i1 false, ptr %l99, !tbaa !21
  %t123 = load ptr, ptr %l98, !tbaa !29
  %t124 = icmp ne ptr %t123, null
  br i1 %t124, label %bb41, label %bb42
bb41:
  %t126 = load ptr, ptr %l98, !tbaa !29
  %t127 = load i64, ptr %t126, !range !{i64 0, i64 22}
  %t129 = icmp eq i64 %t127, 5
  store i1 %t129, ptr %l99, !tbaa !21
  br label %bb42
bb42:
  %t130 = load i1, ptr %l99, !tbaa !21
  br i1 %t130, label %bb43, label %bb44
bb43:
  %t131 = load ptr, ptr %l1, !tbaa !29
  %t133 = getelementptr { i64, [4 x i64] }, ptr %t131, i32 0, i32 1
  %t134 = getelementptr { %"compiler/source:Span", ptr }, ptr %t133, i32 0, i32 1
  %t135 = load ptr, ptr %t134
  store ptr %t135, ptr %l9, !tbaa !29
  br label %bb45
bb44:
  br label %bb47
bb45:
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t138 = load ptr, ptr %l9, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eifStmt(ptr %v0, ptr %v1, ptr %t137, ptr %t138)
  br label %bb46
bb46:
  br label %bb213
bb47:
  %t141 = load ptr, ptr %l1, !tbaa !29
  store ptr %t141, ptr %l106, !tbaa !29
  store i1 false, ptr %l107, !tbaa !21
  %t142 = load ptr, ptr %l106, !tbaa !29
  %t143 = icmp ne ptr %t142, null
  br i1 %t143, label %bb48, label %bb49
bb48:
  %t145 = load ptr, ptr %l106, !tbaa !29
  %t146 = load i64, ptr %t145, !range !{i64 0, i64 22}
  %t148 = icmp eq i64 %t146, 6
  store i1 %t148, ptr %l107, !tbaa !21
  br label %bb49
bb49:
  %t149 = load i1, ptr %l107, !tbaa !21
  br i1 %t149, label %bb50, label %bb51
bb50:
  %t150 = load ptr, ptr %l1, !tbaa !29
  %t152 = getelementptr { i64, [4 x i64] }, ptr %t150, i32 0, i32 1
  %t153 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t152, i32 0, i32 1
  %t154 = load { i64, ptr }, ptr %t153
  store { i64, ptr } %t154, ptr %l10, !tbaa !27
  br label %bb52
bb51:
  br label %bb54
bb52:
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t157 = load { i64, ptr }, ptr %l10, !tbaa !27
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eblock(ptr %v0, ptr %v1, ptr %t156, { i64, ptr } %t157)
  br label %bb53
bb53:
  br label %bb213
bb54:
  %t160 = load ptr, ptr %l1, !tbaa !29
  store ptr %t160, ptr %l114, !tbaa !29
  store i1 false, ptr %l115, !tbaa !21
  %t161 = load ptr, ptr %l114, !tbaa !29
  %t162 = icmp ne ptr %t161, null
  br i1 %t162, label %bb55, label %bb56
bb55:
  %t164 = load ptr, ptr %l114, !tbaa !29
  %t165 = load i64, ptr %t164, !range !{i64 0, i64 22}
  %t167 = icmp eq i64 %t165, 7
  store i1 %t167, ptr %l115, !tbaa !21
  br label %bb56
bb56:
  %t168 = load i1, ptr %l115, !tbaa !21
  br i1 %t168, label %bb57, label %bb58
bb57:
  %t169 = load ptr, ptr %l1, !tbaa !29
  %t171 = getelementptr { i64, [4 x i64] }, ptr %t169, i32 0, i32 1
  %t172 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t171, i32 0, i32 1
  %t173 = load ptr, ptr %t172
  store ptr %t173, ptr %l11, !tbaa !29
  %t175 = load ptr, ptr %l1, !tbaa !29
  %t177 = getelementptr { i64, [4 x i64] }, ptr %t175, i32 0, i32 1
  %t178 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t177, i32 0, i32 2
  %t179 = load { i64, ptr }, ptr %t178
  store { i64, ptr } %t179, ptr %l12, !tbaa !27
  br label %bb59
bb58:
  br label %bb62
bb59:
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t182 = load ptr, ptr %l11, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t181, ptr %t182)
  br label %bb60
bb60:
  %t186 = load ptr, ptr %l0, !tbaa !29
  %t187 = load { i64, ptr }, ptr %l12, !tbaa !27
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eblock(ptr %v0, ptr %v1, ptr %t186, { i64, ptr } %t187)
  br label %bb61
bb61:
  br label %bb213
bb62:
  %t190 = load ptr, ptr %l1, !tbaa !29
  store ptr %t190, ptr %l127, !tbaa !29
  store i1 false, ptr %l128, !tbaa !21
  %t191 = load ptr, ptr %l127, !tbaa !29
  %t192 = icmp ne ptr %t191, null
  br i1 %t192, label %bb63, label %bb64
bb63:
  %t194 = load ptr, ptr %l127, !tbaa !29
  %t195 = load i64, ptr %t194, !range !{i64 0, i64 22}
  %t197 = icmp eq i64 %t195, 8
  store i1 %t197, ptr %l128, !tbaa !21
  br label %bb64
bb64:
  %t198 = load i1, ptr %l128, !tbaa !21
  br i1 %t198, label %bb65, label %bb66
bb65:
  %t199 = load ptr, ptr %l1, !tbaa !29
  %t201 = getelementptr { i64, [4 x i64] }, ptr %t199, i32 0, i32 1
  %t202 = getelementptr { %"compiler/source:Span", ptr }, ptr %t201, i32 0, i32 1
  %t203 = load ptr, ptr %t202
  store ptr %t203, ptr %l13, !tbaa !29
  br label %bb67
bb66:
  br label %bb77
bb67:
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t207 = call i64 @compiler_2fnames_2ecompiler_2fnames_3aResolver_2emark(ptr %v0, ptr %t205)
  store i64 %t207, ptr %l134
  br label %bb68
bb68:
  %t208 = load i64, ptr %l134, !tbaa !24
  store i64 %t208, ptr %l14, !tbaa !24
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t210 = load ptr, ptr %l13, !tbaa !29
  %t212 = getelementptr %"compiler/ast:For3", ptr %t210, i32 0, i32 0
  %t213 = load ptr, ptr %t212, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2estmt(ptr %v0, ptr %v1, ptr %t209, ptr %t213)
  br label %bb69
bb69:
  %t217 = load ptr, ptr %l13, !tbaa !29
  %t219 = getelementptr %"compiler/ast:For3", ptr %t217, i32 0, i32 1
  %t220 = load ptr, ptr %t219, !tbaa !29
  %t222 = icmp eq ptr %t220, null
  %t224 = xor i1 %t222, true
  br i1 %t224, label %bb70, label %bb71
bb70:
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t227 = load ptr, ptr %l13, !tbaa !29
  %t229 = getelementptr %"compiler/ast:For3", ptr %t227, i32 0, i32 1
  %t230 = load ptr, ptr %t229, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t226, ptr %t230)
  br label %bb72
bb71:
  br label %bb73
bb72:
  br label %bb73
bb73:
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t235 = load ptr, ptr %l13, !tbaa !29
  %t237 = getelementptr %"compiler/ast:For3", ptr %t235, i32 0, i32 2
  %t238 = load ptr, ptr %t237, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2estmt(ptr %v0, ptr %v1, ptr %t234, ptr %t238)
  br label %bb74
bb74:
  %t242 = load ptr, ptr %l0, !tbaa !29
  %t243 = load ptr, ptr %l13, !tbaa !29
  %t245 = getelementptr %"compiler/ast:For3", ptr %t243, i32 0, i32 3
  %t246 = load { i64, ptr }, ptr %t245, !tbaa !27
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eblock(ptr %v0, ptr %v1, ptr %t242, { i64, ptr } %t246)
  br label %bb75
bb75:
  %t249 = load ptr, ptr %l0, !tbaa !29
  %t250 = load i64, ptr %l14, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2epopTo(ptr %v0, ptr %t249, i64 %t250)
  br label %bb76
bb76:
  br label %bb213
bb77:
  %t253 = load ptr, ptr %l1, !tbaa !29
  store ptr %t253, ptr %l156, !tbaa !29
  store i1 false, ptr %l157, !tbaa !21
  %t254 = load ptr, ptr %l156, !tbaa !29
  %t255 = icmp ne ptr %t254, null
  br i1 %t255, label %bb78, label %bb79
bb78:
  %t257 = load ptr, ptr %l156, !tbaa !29
  %t258 = load i64, ptr %t257, !range !{i64 0, i64 22}
  %t260 = icmp eq i64 %t258, 9
  store i1 %t260, ptr %l157, !tbaa !21
  br label %bb79
bb79:
  %t261 = load i1, ptr %l157, !tbaa !21
  br i1 %t261, label %bb80, label %bb81
bb80:
  %t262 = load ptr, ptr %l1, !tbaa !29
  %t264 = getelementptr { i64, [4 x i64] }, ptr %t262, i32 0, i32 1
  %t265 = getelementptr { %"compiler/source:Span", ptr }, ptr %t264, i32 0, i32 0
  %t266 = load %"compiler/source:Span", ptr %t265
  store %"compiler/source:Span" %t266, ptr %l15
  %t268 = load ptr, ptr %l1, !tbaa !29
  %t270 = getelementptr { i64, [4 x i64] }, ptr %t268, i32 0, i32 1
  %t271 = getelementptr { %"compiler/source:Span", ptr }, ptr %t270, i32 0, i32 1
  %t272 = load ptr, ptr %t271
  store ptr %t272, ptr %l16, !tbaa !29
  br label %bb82
bb81:
  br label %bb89
bb82:
  %t274 = load ptr, ptr %l0, !tbaa !29
  %t275 = load ptr, ptr %l16, !tbaa !29
  %t277 = getelementptr %"compiler/ast:ForIn", ptr %t275, i32 0, i32 2
  %t278 = load ptr, ptr %t277, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t274, ptr %t278)
  br label %bb83
bb83:
  %t282 = load ptr, ptr %l0, !tbaa !29
  %t284 = call i64 @compiler_2fnames_2ecompiler_2fnames_3aResolver_2emark(ptr %v0, ptr %t282)
  store i64 %t284, ptr %l169
  br label %bb84
bb84:
  %t285 = load i64, ptr %l169, !tbaa !24
  store i64 %t285, ptr %l17, !tbaa !24
  %t286 = load ptr, ptr %l0, !tbaa !29
  %t287 = getelementptr %"compiler/source:Span", ptr %l15, i32 0, i32 0
  %t288 = load i32, ptr %t287, !tbaa !23
  %t289 = load ptr, ptr %l16, !tbaa !29
  %t291 = getelementptr %"compiler/ast:ForIn", ptr %t289, i32 0, i32 0
  %t292 = load i32, ptr %t291, !tbaa !23
  %t293 = load ptr, ptr %l16, !tbaa !29
  %t295 = getelementptr %"compiler/ast:ForIn", ptr %t293, i32 0, i32 1
  %t296 = load i32, ptr %t295, !tbaa !23
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eforNames(ptr %v0, ptr %t286, i32 %t288, i32 %t292, i32 %t296)
  br label %bb85
bb85:
  %t301 = load ptr, ptr %l0, !tbaa !29
  %t302 = load ptr, ptr %l16, !tbaa !29
  %t304 = getelementptr %"compiler/ast:ForIn", ptr %t302, i32 0, i32 4
  %t305 = load { i64, ptr }, ptr %t304, !tbaa !27
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eblock(ptr %v0, ptr %v1, ptr %t301, { i64, ptr } %t305)
  br label %bb86
bb86:
  %t308 = load ptr, ptr %l0, !tbaa !29
  %t309 = load i64, ptr %l17, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2epopTo(ptr %v0, ptr %t308, i64 %t309)
  br label %bb87
bb87:
  %t312 = load ptr, ptr %l0, !tbaa !29
  %t313 = load ptr, ptr %l16, !tbaa !29
  %t315 = getelementptr %"compiler/ast:ForIn", ptr %t313, i32 0, i32 5
  %t316 = load { i64, ptr }, ptr %t315, !tbaa !27
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eclauses(ptr %v0, ptr %v1, ptr %t312, { i64, ptr } %t316)
  br label %bb88
bb88:
  br label %bb213
bb89:
  %t319 = load ptr, ptr %l1, !tbaa !29
  store ptr %t319, ptr %l184, !tbaa !29
  store i1 false, ptr %l185, !tbaa !21
  %t320 = load ptr, ptr %l184, !tbaa !29
  %t321 = icmp ne ptr %t320, null
  br i1 %t321, label %bb90, label %bb91
bb90:
  %t323 = load ptr, ptr %l184, !tbaa !29
  %t324 = load i64, ptr %t323, !range !{i64 0, i64 22}
  %t326 = icmp eq i64 %t324, 10
  store i1 %t326, ptr %l185, !tbaa !21
  br label %bb91
bb91:
  %t327 = load i1, ptr %l185, !tbaa !21
  br i1 %t327, label %bb92, label %bb93
bb92:
  %t328 = load ptr, ptr %l1, !tbaa !29
  %t330 = getelementptr { i64, [4 x i64] }, ptr %t328, i32 0, i32 1
  %t331 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t330, i32 0, i32 1
  %t332 = load { i64, ptr }, ptr %t331
  store { i64, ptr } %t332, ptr %l18, !tbaa !27
  %t334 = load ptr, ptr %l1, !tbaa !29
  %t336 = getelementptr { i64, [4 x i64] }, ptr %t334, i32 0, i32 1
  %t337 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t336, i32 0, i32 2
  %t338 = load ptr, ptr %t337
  store ptr %t338, ptr %l19, !tbaa !29
  br label %bb94
bb93:
  br label %bb97
bb94:
  %t340 = load ptr, ptr %l0, !tbaa !29
  %t341 = load { i64, ptr }, ptr %l18, !tbaa !27
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eblock(ptr %v0, ptr %v1, ptr %t340, { i64, ptr } %t341)
  br label %bb95
bb95:
  %t344 = load ptr, ptr %l0, !tbaa !29
  %t345 = load ptr, ptr %l19, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t344, ptr %t345)
  br label %bb96
bb96:
  br label %bb213
bb97:
  %t349 = load ptr, ptr %l1, !tbaa !29
  store ptr %t349, ptr %l197, !tbaa !29
  store i1 false, ptr %l198, !tbaa !21
  %t350 = load ptr, ptr %l197, !tbaa !29
  %t351 = icmp ne ptr %t350, null
  br i1 %t351, label %bb98, label %bb99
bb98:
  %t353 = load ptr, ptr %l197, !tbaa !29
  %t354 = load i64, ptr %t353, !range !{i64 0, i64 22}
  %t356 = icmp eq i64 %t354, 11
  store i1 %t356, ptr %l198, !tbaa !21
  br label %bb99
bb99:
  %t357 = load i1, ptr %l198, !tbaa !21
  br i1 %t357, label %bb100, label %bb101
bb100:
  %t358 = load ptr, ptr %l1, !tbaa !29
  %t360 = getelementptr { i64, [4 x i64] }, ptr %t358, i32 0, i32 1
  %t361 = getelementptr { %"compiler/source:Span", ptr }, ptr %t360, i32 0, i32 1
  %t362 = load ptr, ptr %t361
  store ptr %t362, ptr %l20, !tbaa !29
  br label %bb102
bb101:
  br label %bb104
bb102:
  %t364 = load ptr, ptr %l0, !tbaa !29
  %t365 = load ptr, ptr %l20, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ematchOf(ptr %v0, ptr %v1, ptr %t364, ptr %t365)
  br label %bb103
bb103:
  br label %bb213
bb104:
  %t368 = load ptr, ptr %l1, !tbaa !29
  store ptr %t368, ptr %l205, !tbaa !29
  store i1 false, ptr %l206, !tbaa !21
  %t369 = load ptr, ptr %l205, !tbaa !29
  %t370 = icmp ne ptr %t369, null
  br i1 %t370, label %bb105, label %bb106
bb105:
  %t372 = load ptr, ptr %l205, !tbaa !29
  %t373 = load i64, ptr %t372, !range !{i64 0, i64 22}
  %t375 = icmp eq i64 %t373, 12
  store i1 %t375, ptr %l206, !tbaa !21
  br label %bb106
bb106:
  %t376 = load i1, ptr %l206, !tbaa !21
  br i1 %t376, label %bb107, label %bb108
bb107:
  %t377 = load ptr, ptr %l1, !tbaa !29
  %t379 = getelementptr { i64, [4 x i64] }, ptr %t377, i32 0, i32 1
  %t380 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t379, i32 0, i32 1
  %t381 = load { i64, ptr }, ptr %t380
  store { i64, ptr } %t381, ptr %l21, !tbaa !27
  br label %bb109
bb108:
  br label %bb117
bb109:
  %t383 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t383, ptr %l22, !tbaa !27
  store i64 0, ptr %l23, !tbaa !24
  %t385 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t387 = extractvalue { i64, ptr } %t385, 0
  store i64 %t387, ptr %l24, !tbaa !24
  br label %bb110
bb110:
  %t389 = load i64, ptr %l23, !tbaa !24
  %t390 = load i64, ptr %l24, !tbaa !24
  %t393 = icmp slt i64 %t389, %t390
  %t395 = xor i1 %t393, true
  br i1 %t395, label %bb111, label %bb112
bb111:
  br label %bb116
bb112:
  br label %bb113
bb113:
  %t397 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t397, ptr %l218, !tbaa !27
  %t398 = load i64, ptr %l23, !tbaa !24
  %t400 = getelementptr { i64, ptr }, ptr %l218, i32 0, i32 1
  %t401 = load ptr, ptr %t400, !tbaa !27
  %t402 = getelementptr ptr, ptr %t401, i64 %t398
  %t403 = load ptr, ptr %t402, !tbaa !39
  %t405 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t405, ptr %t403)
  br label %bb114
bb114:
  br label %bb115
bb115:
  %t410 = load i64, ptr %l23, !tbaa !24
  %t413 = add i64 %t410, 1
  store i64 %t413, ptr %l23, !tbaa !24
  br label %bb110
bb116:
  br label %bb213
bb117:
  %t415 = load ptr, ptr %l1, !tbaa !29
  store ptr %t415, ptr %l227, !tbaa !29
  store i1 false, ptr %l228, !tbaa !21
  %t416 = load ptr, ptr %l227, !tbaa !29
  %t417 = icmp ne ptr %t416, null
  br i1 %t417, label %bb118, label %bb119
bb118:
  %t419 = load ptr, ptr %l227, !tbaa !29
  %t420 = load i64, ptr %t419, !range !{i64 0, i64 22}
  %t422 = icmp eq i64 %t420, 21
  store i1 %t422, ptr %l228, !tbaa !21
  br label %bb119
bb119:
  %t423 = load i1, ptr %l228, !tbaa !21
  br i1 %t423, label %bb120, label %bb121
bb120:
  %t424 = load ptr, ptr %l1, !tbaa !29
  %t426 = getelementptr { i64, [4 x i64] }, ptr %t424, i32 0, i32 1
  %t427 = getelementptr { %"compiler/source:Span", ptr }, ptr %t426, i32 0, i32 1
  %t428 = load ptr, ptr %t427
  store ptr %t428, ptr %l26, !tbaa !29
  br label %bb126
bb121:
  %t430 = load ptr, ptr %l1, !tbaa !29
  store ptr %t430, ptr %l233, !tbaa !29
  store i1 false, ptr %l234, !tbaa !21
  %t431 = load ptr, ptr %l233, !tbaa !29
  %t432 = icmp ne ptr %t431, null
  br i1 %t432, label %bb122, label %bb123
bb122:
  %t434 = load ptr, ptr %l233, !tbaa !29
  %t435 = load i64, ptr %t434, !range !{i64 0, i64 22}
  %t437 = icmp eq i64 %t435, 15
  store i1 %t437, ptr %l234, !tbaa !21
  br label %bb123
bb123:
  %t438 = load i1, ptr %l234, !tbaa !21
  br i1 %t438, label %bb124, label %bb125
bb124:
  %t439 = load ptr, ptr %l1, !tbaa !29
  %t441 = getelementptr { i64, [4 x i64] }, ptr %t439, i32 0, i32 1
  %t442 = getelementptr { %"compiler/source:Span", ptr }, ptr %t441, i32 0, i32 1
  %t443 = load ptr, ptr %t442
  store ptr %t443, ptr %l26, !tbaa !29
  br label %bb126
bb125:
  br label %bb128
bb126:
  %t445 = load ptr, ptr %l0, !tbaa !29
  %t446 = load ptr, ptr %l26, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t445, ptr %t446)
  br label %bb127
bb127:
  br label %bb213
bb128:
  %t450 = load ptr, ptr %l1, !tbaa !29
  store ptr %t450, ptr %l242, !tbaa !29
  store i1 false, ptr %l243, !tbaa !21
  %t451 = load ptr, ptr %l242, !tbaa !29
  %t452 = icmp ne ptr %t451, null
  br i1 %t452, label %bb129, label %bb130
bb129:
  %t454 = load ptr, ptr %l242, !tbaa !29
  %t455 = load i64, ptr %t454, !range !{i64 0, i64 22}
  %t457 = icmp eq i64 %t455, 14
  store i1 %t457, ptr %l243, !tbaa !21
  br label %bb130
bb130:
  %t458 = load i1, ptr %l243, !tbaa !21
  br i1 %t458, label %bb131, label %bb132
bb131:
  %t459 = load ptr, ptr %l1, !tbaa !29
  %t461 = getelementptr { i64, [4 x i64] }, ptr %t459, i32 0, i32 1
  %t462 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t461, i32 0, i32 1
  %t463 = load ptr, ptr %t462
  store ptr %t463, ptr %l27, !tbaa !29
  %t465 = load ptr, ptr %l1, !tbaa !29
  %t467 = getelementptr { i64, [4 x i64] }, ptr %t465, i32 0, i32 1
  %t468 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t467, i32 0, i32 2
  %t469 = load ptr, ptr %t468
  store ptr %t469, ptr %l28, !tbaa !29
  br label %bb133
bb132:
  br label %bb139
bb133:
  %t471 = load ptr, ptr %l0, !tbaa !29
  %t472 = load ptr, ptr %l27, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t471, ptr %t472)
  br label %bb134
bb134:
  %t476 = load ptr, ptr %l28, !tbaa !29
  %t478 = icmp eq ptr %t476, null
  %t480 = xor i1 %t478, true
  br i1 %t480, label %bb135, label %bb136
bb135:
  %t482 = load ptr, ptr %l0, !tbaa !29
  %t483 = load ptr, ptr %l28, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t482, ptr %t483)
  br label %bb137
bb136:
  br label %bb138
bb137:
  br label %bb138
bb138:
  br label %bb213
bb139:
  %t487 = load ptr, ptr %l1, !tbaa !29
  store ptr %t487, ptr %l259, !tbaa !29
  store i1 false, ptr %l260, !tbaa !21
  %t488 = load ptr, ptr %l259, !tbaa !29
  %t489 = icmp ne ptr %t488, null
  br i1 %t489, label %bb140, label %bb141
bb140:
  %t491 = load ptr, ptr %l259, !tbaa !29
  %t492 = load i64, ptr %t491, !range !{i64 0, i64 22}
  %t494 = icmp eq i64 %t492, 13
  store i1 %t494, ptr %l260, !tbaa !21
  br label %bb141
bb141:
  %t495 = load i1, ptr %l260, !tbaa !21
  br i1 %t495, label %bb142, label %bb143
bb142:
  %t496 = load ptr, ptr %l1, !tbaa !29
  %t498 = getelementptr { i64, [4 x i64] }, ptr %t496, i32 0, i32 1
  %t499 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t498, i32 0, i32 2
  %t500 = load ptr, ptr %t499
  store ptr %t500, ptr %l29, !tbaa !29
  br label %bb144
bb143:
  br label %bb149
bb144:
  %t502 = load ptr, ptr %l29, !tbaa !29
  %t504 = icmp eq ptr %t502, null
  %t506 = xor i1 %t504, true
  br i1 %t506, label %bb145, label %bb146
bb145:
  %t508 = load ptr, ptr %l0, !tbaa !29
  %t509 = load ptr, ptr %l29, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t508, ptr %t509)
  br label %bb147
bb146:
  br label %bb148
bb147:
  br label %bb148
bb148:
  br label %bb213
bb149:
  %t513 = load ptr, ptr %l1, !tbaa !29
  store ptr %t513, ptr %l271, !tbaa !29
  store i1 false, ptr %l272, !tbaa !21
  %t514 = load ptr, ptr %l271, !tbaa !29
  %t515 = icmp ne ptr %t514, null
  br i1 %t515, label %bb150, label %bb151
bb150:
  %t517 = load ptr, ptr %l271, !tbaa !29
  %t518 = load i64, ptr %t517, !range !{i64 0, i64 22}
  %t520 = icmp eq i64 %t518, 16
  store i1 %t520, ptr %l272, !tbaa !21
  br label %bb151
bb151:
  %t521 = load i1, ptr %l272, !tbaa !21
  br i1 %t521, label %bb152, label %bb153
bb152:
  %t522 = load ptr, ptr %l1, !tbaa !29
  %t524 = getelementptr { i64, [4 x i64] }, ptr %t522, i32 0, i32 1
  %t525 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t524, i32 0, i32 1
  %t526 = load ptr, ptr %t525
  store ptr %t526, ptr %l30, !tbaa !29
  %t528 = load ptr, ptr %l1, !tbaa !29
  %t530 = getelementptr { i64, [4 x i64] }, ptr %t528, i32 0, i32 1
  %t531 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t530, i32 0, i32 2
  %t532 = load { i64, ptr }, ptr %t531
  store { i64, ptr } %t532, ptr %l31, !tbaa !27
  br label %bb154
bb153:
  br label %bb170
bb154:
  %t534 = load ptr, ptr %l0, !tbaa !29
  %t536 = getelementptr %"compiler/names:Resolver", ptr %t534, i32 0, i32 23
  %t537 = load i1, ptr %t536, !tbaa !21
  br i1 %t537, label %bb155, label %bb156
bb155:
  %t539 = load ptr, ptr %l0, !tbaa !29
  %t540 = load ptr, ptr %l30, !tbaa !29
  %t541 = load { i64, ptr }, ptr %l31, !tbaa !27
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2esurveyRaise(ptr %v0, ptr %v1, ptr %v1, ptr %t539, ptr %t540, { i64, ptr } %t541)
  br label %bb157
bb156:
  %t545 = load ptr, ptr %l0, !tbaa !29
  %t546 = load ptr, ptr %l30, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2epath(ptr %v0, ptr %v1, ptr %t545, ptr %t546)
  br label %bb158
bb157:
  br label %bb159
bb158:
  br label %bb159
bb159:
  %t549 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t551 = extractvalue { i64, ptr } %t549, 0
  %t552 = extractvalue { i64, ptr } { i64 -1, ptr null }, 0
  %t553 = icmp eq i64 %t551, %t552
  %t554 = extractvalue { i64, ptr } %t549, 1
  %t555 = extractvalue { i64, ptr } { i64 -1, ptr null }, 1
  %t556 = icmp eq ptr %t554, %t555
  %t557 = and i1 %t553, %t556
  %t559 = xor i1 %t557, true
  br i1 %t559, label %bb160, label %bb161
bb160:
  %t561 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t561, ptr %l32, !tbaa !27
  store i64 0, ptr %l33, !tbaa !24
  %t563 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t565 = extractvalue { i64, ptr } %t563, 0
  store i64 %t565, ptr %l34, !tbaa !24
  br label %bb162
bb161:
  br label %bb169
bb162:
  %t567 = load i64, ptr %l33, !tbaa !24
  %t568 = load i64, ptr %l34, !tbaa !24
  %t571 = icmp slt i64 %t567, %t568
  %t573 = xor i1 %t571, true
  br i1 %t573, label %bb163, label %bb164
bb163:
  br label %bb168
bb164:
  br label %bb165
bb165:
  %t575 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t575, ptr %l296, !tbaa !27
  %t576 = load i64, ptr %l33, !tbaa !24
  %t578 = getelementptr { i64, ptr }, ptr %l296, i32 0, i32 1
  %t579 = load ptr, ptr %t578, !tbaa !27
  %t580 = getelementptr ptr, ptr %t579, i64 %t576
  %t581 = load ptr, ptr %t580, !tbaa !39
  %t583 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t583, ptr %t581)
  br label %bb166
bb166:
  br label %bb167
bb167:
  %t588 = load i64, ptr %l33, !tbaa !24
  %t591 = add i64 %t588, 1
  store i64 %t591, ptr %l33, !tbaa !24
  br label %bb162
bb168:
  br label %bb169
bb169:
  br label %bb213
bb170:
  %t593 = load ptr, ptr %l1, !tbaa !29
  store ptr %t593, ptr %l305, !tbaa !29
  store i1 false, ptr %l306, !tbaa !21
  %t594 = load ptr, ptr %l305, !tbaa !29
  %t595 = icmp ne ptr %t594, null
  br i1 %t595, label %bb171, label %bb172
bb171:
  %t597 = load ptr, ptr %l305, !tbaa !29
  %t598 = load i64, ptr %t597, !range !{i64 0, i64 22}
  %t600 = icmp eq i64 %t598, 17
  store i1 %t600, ptr %l306, !tbaa !21
  br label %bb172
bb172:
  %t601 = load i1, ptr %l306, !tbaa !21
  br i1 %t601, label %bb173, label %bb174
bb173:
  %t602 = load ptr, ptr %l1, !tbaa !29
  %t604 = getelementptr { i64, [4 x i64] }, ptr %t602, i32 0, i32 1
  %t605 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t604, i32 0, i32 1
  %t606 = load { i64, ptr }, ptr %t605
  store { i64, ptr } %t606, ptr %l36, !tbaa !27
  %t608 = load ptr, ptr %l1, !tbaa !29
  %t610 = getelementptr { i64, [4 x i64] }, ptr %t608, i32 0, i32 1
  %t611 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t610, i32 0, i32 2
  %t612 = load ptr, ptr %t611
  store ptr %t612, ptr %l37, !tbaa !29
  br label %bb175
bb174:
  br label %bb184
bb175:
  %t614 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t614, ptr %l38, !tbaa !27
  store i64 0, ptr %l39, !tbaa !24
  %t616 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t618 = extractvalue { i64, ptr } %t616, 0
  store i64 %t618, ptr %l40, !tbaa !24
  br label %bb176
bb176:
  %t620 = load i64, ptr %l39, !tbaa !24
  %t621 = load i64, ptr %l40, !tbaa !24
  %t624 = icmp slt i64 %t620, %t621
  %t626 = xor i1 %t624, true
  br i1 %t626, label %bb177, label %bb178
bb177:
  br label %bb182
bb178:
  br label %bb179
bb179:
  %t628 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t628, ptr %l320, !tbaa !27
  %t629 = load i64, ptr %l39, !tbaa !24
  %t631 = getelementptr { i64, ptr }, ptr %l320, i32 0, i32 1
  %t632 = load ptr, ptr %t631, !tbaa !27
  %t633 = getelementptr ptr, ptr %t632, i64 %t629
  %t634 = load ptr, ptr %t633, !tbaa !39
  %t636 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etarget(ptr %v0, ptr %v1, ptr %t636, ptr %t634)
  br label %bb180
bb180:
  br label %bb181
bb181:
  %t640 = load i64, ptr %l39, !tbaa !24
  %t643 = add i64 %t640, 1
  store i64 %t643, ptr %l39, !tbaa !24
  br label %bb176
bb182:
  %t645 = load ptr, ptr %l0, !tbaa !29
  %t646 = load ptr, ptr %l37, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t645, ptr %t646)
  br label %bb183
bb183:
  br label %bb213
bb184:
  %t650 = load ptr, ptr %l1, !tbaa !29
  store ptr %t650, ptr %l331, !tbaa !29
  store i1 false, ptr %l332, !tbaa !21
  %t651 = load ptr, ptr %l331, !tbaa !29
  %t652 = icmp ne ptr %t651, null
  br i1 %t652, label %bb185, label %bb186
bb185:
  %t654 = load ptr, ptr %l331, !tbaa !29
  %t655 = load i64, ptr %t654, !range !{i64 0, i64 22}
  %t657 = icmp eq i64 %t655, 18
  store i1 %t657, ptr %l332, !tbaa !21
  br label %bb186
bb186:
  %t658 = load i1, ptr %l332, !tbaa !21
  br i1 %t658, label %bb187, label %bb188
bb187:
  %t659 = load ptr, ptr %l1, !tbaa !29
  %t661 = getelementptr { i64, [4 x i64] }, ptr %t659, i32 0, i32 1
  %t662 = getelementptr { %"compiler/source:Span", ptr }, ptr %t661, i32 0, i32 1
  %t663 = load ptr, ptr %t662
  store ptr %t663, ptr %l42, !tbaa !29
  br label %bb189
bb188:
  br label %bb192
bb189:
  %t665 = load ptr, ptr %l0, !tbaa !29
  %t666 = load ptr, ptr %l42, !tbaa !29
  %t668 = getelementptr %"compiler/ast:JoinS", ptr %t666, i32 0, i32 1
  %t669 = load { i64, ptr }, ptr %t668, !tbaa !27
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eblock(ptr %v0, ptr %v1, ptr %t665, { i64, ptr } %t669)
  br label %bb190
bb190:
  %t672 = load ptr, ptr %l0, !tbaa !29
  %t673 = load ptr, ptr %l42, !tbaa !29
  %t675 = getelementptr %"compiler/ast:JoinS", ptr %t673, i32 0, i32 2
  %t676 = load { i64, ptr }, ptr %t675, !tbaa !27
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eclauses(ptr %v0, ptr %v1, ptr %t672, { i64, ptr } %t676)
  br label %bb191
bb191:
  br label %bb213
bb192:
  %t679 = load ptr, ptr %l1, !tbaa !29
  store ptr %t679, ptr %l343, !tbaa !29
  store i1 false, ptr %l344, !tbaa !21
  %t680 = load ptr, ptr %l343, !tbaa !29
  %t681 = icmp ne ptr %t680, null
  br i1 %t681, label %bb193, label %bb194
bb193:
  %t683 = load ptr, ptr %l343, !tbaa !29
  %t684 = load i64, ptr %t683, !range !{i64 0, i64 22}
  %t686 = icmp eq i64 %t684, 19
  store i1 %t686, ptr %l344, !tbaa !21
  br label %bb194
bb194:
  %t687 = load i1, ptr %l344, !tbaa !21
  br i1 %t687, label %bb195, label %bb196
bb195:
  %t688 = load ptr, ptr %l1, !tbaa !29
  %t690 = getelementptr { i64, [4 x i64] }, ptr %t688, i32 0, i32 1
  %t691 = getelementptr { %"compiler/source:Span", ptr, i1 }, ptr %t690, i32 0, i32 1
  %t692 = load ptr, ptr %t691
  store ptr %t692, ptr %l43, !tbaa !29
  br label %bb197
bb196:
  br label %bb201
bb197:
  %t694 = load ptr, ptr %l0, !tbaa !29
  %t696 = call i64 @compiler_2fnames_2ecompiler_2fnames_3aResolver_2emark(ptr %v0, ptr %t694)
  store i64 %t696, ptr %l350
  br label %bb198
bb198:
  %t697 = load i64, ptr %l350, !tbaa !24
  store i64 %t697, ptr %l44, !tbaa !24
  %t698 = load ptr, ptr %l0, !tbaa !29
  %t699 = load ptr, ptr %l43, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2estmt(ptr %v0, ptr %v1, ptr %t698, ptr %t699)
  br label %bb199
bb199:
  %t703 = load ptr, ptr %l0, !tbaa !29
  %t704 = load i64, ptr %l44, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2epopTo(ptr %v0, ptr %t703, i64 %t704)
  br label %bb200
bb200:
  br label %bb213
bb201:
  %t707 = load ptr, ptr %l1, !tbaa !29
  store ptr %t707, ptr %l356, !tbaa !29
  store i1 false, ptr %l357, !tbaa !21
  %t708 = load ptr, ptr %l356, !tbaa !29
  %t709 = icmp ne ptr %t708, null
  br i1 %t709, label %bb202, label %bb203
bb202:
  %t711 = load ptr, ptr %l356, !tbaa !29
  %t712 = load i64, ptr %t711, !range !{i64 0, i64 22}
  %t714 = icmp eq i64 %t712, 20
  store i1 %t714, ptr %l357, !tbaa !21
  br label %bb203
bb203:
  %t715 = load i1, ptr %l357, !tbaa !21
  br i1 %t715, label %bb204, label %bb205
bb204:
  %t716 = load ptr, ptr %l1, !tbaa !29
  %t718 = getelementptr { i64, [4 x i64] }, ptr %t716, i32 0, i32 1
  %t719 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t718, i32 0, i32 1
  %t720 = load { i64, ptr }, ptr %t719
  store { i64, ptr } %t720, ptr %l45, !tbaa !27
  br label %bb206
bb205:
  br label %bb208
bb206:
  %t722 = load ptr, ptr %l0, !tbaa !29
  %t723 = load { i64, ptr }, ptr %l45, !tbaa !27
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eblock(ptr %v0, ptr %v1, ptr %t722, { i64, ptr } %t723)
  br label %bb207
bb207:
  br label %bb213
bb208:
  br i1 true, label %bb209, label %bb210
bb209:
  br label %bb211
bb210:
  br label %bb212
bb211:
  br label %bb213
bb212:
  call void @__olang_check_failed(ptr @olang_loc_6855615fe1bb2138_9d7c9db084b0e41c)
  unreachable
bb213:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fnames_2ecompiler_2fnames_3aResolver_2esuggests(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca %"compiler/names:Entry"
  %l11 = alloca ptr
  %l12 = alloca i64
  %l14 = alloca %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l15 = alloca %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed"
  %l19 = alloca i1
  %l20 = alloca { i64, ptr }
  %l25 = alloca i1
  %l30 = alloca i1
  %l31 = alloca { i64, ptr }
  %l35 = alloca i1
  %l45 = alloca i1
  %l46 = alloca { i64, ptr }
  %l47 = alloca i64
  %l52 = alloca { i64, ptr }
  %l53 = alloca { i64, ptr }
  %l54 = alloca i64
  %l57 = alloca i64
  %l58 = alloca i64
  %l65 = alloca i1
  %l68 = alloca i1
  %l73 = alloca i64
  %l74 = alloca [14 x { i64, ptr }]
  %l87 = alloca i64
  %l98 = alloca ptr
  %l101 = alloca i64
  %l103 = alloca i64
  %l108 = alloca %"compiler/names:Entry"
  %l109 = alloca { i64, ptr }
  %l112 = alloca { i64, ptr }
  %l113 = alloca i64
  %l125 = alloca ptr
  %l128 = alloca i64
  %l130 = alloca i64
  %l135 = alloca { i64, ptr }
  %l138 = alloca i64
  %l147 = alloca %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l148 = alloca %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed"
  %l150 = alloca %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed"
  %l151 = alloca i32
  %l153 = alloca i1
  %l154 = alloca { i64, ptr }
  %l157 = alloca { i64, ptr }
  %l158 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp sge i64 %t3, 2
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t7, ptr %l20, !tbaa !27
  %t8 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t8, 0
  %t12 = sub i64 %t10, 1
  %t14 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr i8, ptr %t15, i64 %t12
  %t17 = load i8, ptr %t16, !tbaa !32
  %t19 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t17)
  store i1 %t19, ptr %l25
  br label %bb3
bb2:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb4
bb3:
  %t20 = load i1, ptr %l25, !tbaa !21
  store i1 %t20, ptr %l19, !tbaa !21
  br label %bb4
bb4:
  %t21 = load i1, ptr %l19, !tbaa !21
  br i1 %t21, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t22 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t22, 0
  store i64 %t24, ptr %l2, !tbaa !24
  br label %bb7
bb6:
  br label %bb37
bb7:
  %t26 = load i64, ptr %l2, !tbaa !24
  %t28 = icmp sgt i64 %t26, 0
  br i1 %t28, label %bb8, label %bb9
bb8:
  %t30 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t30, ptr %l31, !tbaa !27
  %t31 = load i64, ptr %l2, !tbaa !24
  %t33 = sub i64 %t31, 1
  %t35 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !27
  %t37 = getelementptr i8, ptr %t36, i64 %t33
  %t38 = load i8, ptr %t37, !tbaa !32
  %t40 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t38)
  store i1 %t40, ptr %l35
  br label %bb10
bb9:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb11
bb10:
  %t41 = load i1, ptr %l35, !tbaa !21
  store i1 %t41, ptr %l30, !tbaa !21
  br label %bb11
bb11:
  %t42 = load i1, ptr %l30, !tbaa !21
  %t43 = xor i1 %t42, true
  br i1 %t43, label %bb12, label %bb13
bb12:
  br label %bb16
bb13:
  br label %bb14
bb14:
  %t45 = load i64, ptr %l2, !tbaa !24
  %t48 = sub i64 %t45, 1
  store i64 %t48, ptr %l2, !tbaa !24
  br label %bb15
bb15:
  br label %bb7
bb16:
  %t50 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t52 = extractvalue { i64, ptr } %t50, 0
  %t53 = load i64, ptr %l2, !tbaa !24
  %t56 = sub i64 %t52, %t53
  %t58 = icmp slt i64 %t56, 8
  br i1 %t58, label %bb17, label %bb18
bb17:
  %t60 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t60, ptr %l46, !tbaa !27
  %t61 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t62 = extractvalue { i64, ptr } %t61, 0
  store i64 %t62, ptr %l47, !tbaa !24
  %t63 = icmp sge i64 0, 0
  br i1 %t63, label %bb19, label %bb20
bb18:
  store i1 false, ptr %l45, !tbaa !21
  br label %bb33
bb19:
  %t65 = icmp sle i64 0, 1
  br i1 %t65, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_f16fd081e6fbed18_62e1963dfff5da0c)
  unreachable
bb21:
  %t67 = load i64, ptr %l47, !tbaa !24
  %t68 = icmp sle i64 1, %t67
  br i1 %t68, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_f16fd081e6fbed18_62e1963dfff5da0c)
  unreachable
bb23:
  %t70 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !27
  %t72 = getelementptr i8, ptr %t71, i64 0
  %t73 = sub i64 1, 0
  %t74 = insertvalue { i64, ptr } undef, i64 %t73, 0
  %t75 = insertvalue { i64, ptr } %t74, ptr %t72, 1
  %t77 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eToUpper(ptr %v1, ptr %s1, { i64, ptr } %t75)
  store { i64, ptr } %t77, ptr %l52
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_f16fd081e6fbed18_62e1963dfff5da0c)
  unreachable
bb25:
  %t78 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t78, ptr %l53, !tbaa !27
  %t79 = load i64, ptr %l2, !tbaa !24
  store i64 %t79, ptr %l54, !tbaa !24
  %t80 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t83 = extractvalue { i64, ptr } %t80, 0
  store i64 %t83, ptr %l57, !tbaa !24
  %t84 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t85 = extractvalue { i64, ptr } %t84, 0
  store i64 %t85, ptr %l58, !tbaa !24
  %t86 = load i64, ptr %l54, !tbaa !24
  %t87 = icmp sge i64 %t86, 0
  br i1 %t87, label %bb26, label %bb27
bb26:
  %t89 = load i64, ptr %l54, !tbaa !24
  %t90 = load i64, ptr %l57, !tbaa !24
  %t91 = icmp sle i64 %t89, %t90
  br i1 %t91, label %bb28, label %bb29
bb27:
  call void @__olang_check_failed(ptr @olang_loc_f16fd081e6fbed18_62e1963dfff5da0c)
  unreachable
bb28:
  %t93 = load i64, ptr %l57, !tbaa !24
  %t94 = load i64, ptr %l58, !tbaa !24
  %t95 = icmp sle i64 %t93, %t94
  br i1 %t95, label %bb30, label %bb31
bb29:
  call void @__olang_check_failed(ptr @olang_loc_f16fd081e6fbed18_62e1963dfff5da0c)
  unreachable
bb30:
  %t97 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !27
  %t99 = load i64, ptr %l54, !tbaa !24
  %t100 = load i64, ptr %l57, !tbaa !24
  %t101 = getelementptr i8, ptr %t98, i64 %t99
  %t102 = sub i64 %t100, %t99
  %t103 = insertvalue { i64, ptr } undef, i64 %t102, 0
  %t104 = insertvalue { i64, ptr } %t103, ptr %t101, 1
  %t105 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t106 = extractvalue { i64, ptr } %t105, 1
  %t107 = extractvalue { i64, ptr } %t105, 0
  %t109 = extractvalue { i64, ptr } %t104, 1
  %t110 = extractvalue { i64, ptr } %t104, 0
  %t111 = add i64 %t107, %t110
  %t112 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t111)
  call void @olang_textcopy(ptr %t112, ptr %t106, i64 %t107)
  %t113 = getelementptr i8, ptr %t112, i64 %t107
  call void @olang_textcopy(ptr %t113, ptr %t109, i64 %t110)
  %t114 = insertvalue { i64, ptr } undef, i64 %t111, 0
  %t115 = insertvalue { i64, ptr } %t114, ptr %t112, 1
  %t118 = call i1 @compiler_2fnames_2eBuiltinTypeName(ptr %s1, { i64, ptr } %t115)
  store i1 %t118, ptr %l65
  br label %bb32
bb31:
  call void @__olang_check_failed(ptr @olang_loc_f16fd081e6fbed18_62e1963dfff5da0c)
  unreachable
bb32:
  %t119 = load i1, ptr %l65, !tbaa !21
  store i1 %t119, ptr %l45, !tbaa !21
  br label %bb33
bb33:
  %t120 = load i1, ptr %l45, !tbaa !21
  br i1 %t120, label %bb34, label %bb35
bb34:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb35:
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s1)
  br label %bb37
bb37:
  %t122 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t124 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t122, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d15, i32 0, i32 1) })
  store i1 %t124, ptr %l68
  br label %bb38
bb38:
  %t125 = load i1, ptr %l68, !tbaa !21
  br i1 %t125, label %bb39, label %bb40
bb39:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb40:
  br label %bb41
bb41:
  %t127 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t129 = extractvalue { i64, ptr } %t127, 0
  %t131 = icmp sle i64 %t129, 4
  br i1 %t131, label %bb42, label %bb43
bb42:
  store i64 2, ptr %l73, !tbaa !24
  br label %bb44
bb43:
  store i64 3, ptr %l73, !tbaa !24
  br label %bb44
bb44:
  %t133 = load i64, ptr %l73, !tbaa !24
  store i64 %t133, ptr %l3, !tbaa !24
  store %olang.scope zeroinitializer, ptr %s6
  %t134 = getelementptr [14 x { i64, ptr }], ptr %l74, i64 0, i64 0
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d16, i32 0, i32 1) }, ptr %t134, !tbaa !37
  %t135 = getelementptr [14 x { i64, ptr }], ptr %l74, i64 0, i64 1
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d17, i32 0, i32 1) }, ptr %t135, !tbaa !37
  %t136 = getelementptr [14 x { i64, ptr }], ptr %l74, i64 0, i64 2
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d18, i32 0, i32 1) }, ptr %t136, !tbaa !37
  %t137 = getelementptr [14 x { i64, ptr }], ptr %l74, i64 0, i64 3
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d19, i32 0, i32 1) }, ptr %t137, !tbaa !37
  %t138 = getelementptr [14 x { i64, ptr }], ptr %l74, i64 0, i64 4
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d20, i32 0, i32 1) }, ptr %t138, !tbaa !37
  %t139 = getelementptr [14 x { i64, ptr }], ptr %l74, i64 0, i64 5
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d21, i32 0, i32 1) }, ptr %t139, !tbaa !37
  %t140 = getelementptr [14 x { i64, ptr }], ptr %l74, i64 0, i64 6
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d22, i32 0, i32 1) }, ptr %t140, !tbaa !37
  %t141 = getelementptr [14 x { i64, ptr }], ptr %l74, i64 0, i64 7
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d23, i32 0, i32 1) }, ptr %t141, !tbaa !37
  %t142 = getelementptr [14 x { i64, ptr }], ptr %l74, i64 0, i64 8
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d24, i32 0, i32 1) }, ptr %t142, !tbaa !37
  %t143 = getelementptr [14 x { i64, ptr }], ptr %l74, i64 0, i64 9
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d25, i32 0, i32 1) }, ptr %t143, !tbaa !37
  %t144 = getelementptr [14 x { i64, ptr }], ptr %l74, i64 0, i64 10
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d26, i32 0, i32 1) }, ptr %t144, !tbaa !37
  %t145 = getelementptr [14 x { i64, ptr }], ptr %l74, i64 0, i64 11
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d27, i32 0, i32 1) }, ptr %t145, !tbaa !37
  %t146 = getelementptr [14 x { i64, ptr }], ptr %l74, i64 0, i64 12
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d28, i32 0, i32 1) }, ptr %t146, !tbaa !37
  %t147 = getelementptr [14 x { i64, ptr }], ptr %l74, i64 0, i64 13
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d29, i32 0, i32 1) }, ptr %t147, !tbaa !37
  %t148 = call ptr @__olang_scope_alloc_a(ptr %s6, i64 224, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t148, ptr %l74, i64 224, i1 false)
  store ptr %t148, ptr %l4
  store i64 0, ptr %l5, !tbaa !24
  %t150 = load ptr, ptr %l4
  store i64 14, ptr %l6, !tbaa !24
  br label %bb45
bb45:
  %t153 = load i64, ptr %l5, !tbaa !24
  %t154 = load i64, ptr %l6, !tbaa !24
  %t157 = icmp slt i64 %t153, %t154
  %t159 = xor i1 %t157, true
  br i1 %t159, label %bb46, label %bb47
bb46:
  br label %bb54
bb47:
  br label %bb48
bb48:
  %t161 = load ptr, ptr %l4
  %t162 = load i64, ptr %l5, !tbaa !24
  %t165 = getelementptr [14 x { i64, ptr }], ptr %t161, i64 0, i64 %t162
  %t166 = load { i64, ptr }, ptr %t165, !tbaa !37
  %t168 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t170 = load ptr, ptr @__olang_prog_scope
  %t173 = call i64 @compiler_2fmsgs_2eDistance(ptr %v1, ptr %t170, { i64, ptr } %t168, { i64, ptr } %t166)
  store i64 %t173, ptr %l87
  br label %bb49
bb49:
  %t174 = load i64, ptr %l3, !tbaa !24
  %t175 = load i64, ptr %l87, !tbaa !24
  %t177 = icmp slt i64 %t175, %t174
  br i1 %t177, label %bb50, label %bb51
bb50:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb51:
  br label %bb52
bb52:
  br label %bb53
bb53:
  %t180 = load i64, ptr %l5, !tbaa !24
  %t183 = add i64 %t180, 1
  store i64 %t183, ptr %l5, !tbaa !24
  br label %bb45
bb54:
  call void @__olang_scope_close(ptr %s6)
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t187 = getelementptr %"compiler/names:Resolver", ptr %t185, i32 0, i32 1
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t190 = getelementptr %"compiler/names:Resolver", ptr %t188, i32 0, i32 7
  %t191 = load i64, ptr %t190, !tbaa !24
  %t194 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v0, ptr %t187, i64 %t191)
  store ptr %t194, ptr %l98
  br label %bb55
bb55:
  %t195 = load ptr, ptr %l98, !tbaa !29
  %t197 = getelementptr %"compiler/names:Table", ptr %t195, i32 0, i32 0
  store ptr %t197, ptr %l8, !tbaa !29
  store i64 0, ptr %l9, !tbaa !24
  br label %bb56
bb56:
  %t199 = load i64, ptr %l9, !tbaa !24
  store i64 %t199, ptr %l101, !tbaa !24
  %t200 = load ptr, ptr %l8, !tbaa !29
  %t202 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eLen_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %t200)
  store i64 %t202, ptr %l103
  br label %bb57
bb57:
  %t203 = load i64, ptr %l101, !tbaa !24
  %t204 = load i64, ptr %l103, !tbaa !24
  %t205 = icmp slt i64 %t203, %t204
  %t207 = xor i1 %t205, true
  br i1 %t207, label %bb58, label %bb59
bb58:
  br label %bb68
bb59:
  br label %bb60
bb60:
  %t209 = load ptr, ptr %l8, !tbaa !29
  %t210 = load i64, ptr %l9, !tbaa !24
  %t213 = call %"compiler/names:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %v0, ptr %t209, i64 %t210)
  store %"compiler/names:Entry" %t213, ptr %l108
  br label %bb61
bb61:
  %t214 = load %"compiler/names:Entry", ptr %l108
  store %"compiler/names:Entry" %t214, ptr %l10
  %t215 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t215, ptr %l109, !tbaa !27
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t217 = getelementptr %"compiler/names:Entry", ptr %l10, i32 0, i32 0
  %t218 = load i32, ptr %t217, !tbaa !23
  %t221 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %v0, ptr %t216, i32 %t218)
  store { i64, ptr } %t221, ptr %l112
  br label %bb62
bb62:
  %t222 = load { i64, ptr }, ptr %l109, !tbaa !27
  %t223 = load { i64, ptr }, ptr %l112, !tbaa !27
  %t224 = call i64 @compiler_2fmsgs_2eDistance(ptr %v1, ptr %v0, { i64, ptr } %t222, { i64, ptr } %t223)
  store i64 %t224, ptr %l113
  br label %bb63
bb63:
  %t225 = load i64, ptr %l3, !tbaa !24
  %t226 = load i64, ptr %l113, !tbaa !24
  %t228 = icmp slt i64 %t226, %t225
  br i1 %t228, label %bb64, label %bb65
bb64:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb65:
  br label %bb66
bb66:
  br label %bb67
bb67:
  %t231 = load i64, ptr %l9, !tbaa !24
  %t234 = add i64 %t231, 1
  store i64 %t234, ptr %l9, !tbaa !24
  br label %bb56
bb68:
  %t236 = load ptr, ptr %l0, !tbaa !29
  %t238 = getelementptr %"compiler/names:Resolver", ptr %t236, i32 0, i32 0
  %t239 = load ptr, ptr %t238, !tbaa !29
  %t241 = getelementptr %"compiler/load:Loader", ptr %t239, i32 0, i32 10
  %t242 = load ptr, ptr %l0, !tbaa !29
  %t244 = getelementptr %"compiler/names:Resolver", ptr %t242, i32 0, i32 7
  %t245 = load i64, ptr %t244, !tbaa !24
  %t248 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t241, i64 %t245)
  store ptr %t248, ptr %l125
  br label %bb69
bb69:
  %t249 = load ptr, ptr %l125, !tbaa !29
  %t251 = getelementptr %"compiler/load:Module", ptr %t249, i32 0, i32 9
  store ptr %t251, ptr %l11, !tbaa !29
  store i64 0, ptr %l12, !tbaa !24
  br label %bb70
bb70:
  %t253 = load i64, ptr %l12, !tbaa !24
  store i64 %t253, ptr %l128, !tbaa !24
  %t254 = load ptr, ptr %l11, !tbaa !29
  %t256 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t254)
  store i64 %t256, ptr %l130
  br label %bb71
bb71:
  %t257 = load i64, ptr %l128, !tbaa !24
  %t258 = load i64, ptr %l130, !tbaa !24
  %t259 = icmp slt i64 %t257, %t258
  %t261 = xor i1 %t259, true
  br i1 %t261, label %bb72, label %bb73
bb72:
  br label %bb81
bb73:
  br label %bb74
bb74:
  %t263 = load ptr, ptr %l11, !tbaa !29
  %t264 = load i64, ptr %l12, !tbaa !24
  %t267 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t263, i64 %t264)
  store { i64, ptr } %t267, ptr %l135
  br label %bb75
bb75:
  %t268 = load { i64, ptr }, ptr %l135, !tbaa !27
  %t269 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t273 = call i64 @compiler_2fmsgs_2eDistance(ptr %v1, ptr %v0, { i64, ptr } %t269, { i64, ptr } %t268)
  store i64 %t273, ptr %l138
  br label %bb76
bb76:
  %t274 = load i64, ptr %l3, !tbaa !24
  %t275 = load i64, ptr %l138, !tbaa !24
  %t277 = icmp slt i64 %t275, %t274
  br i1 %t277, label %bb77, label %bb78
bb77:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb78:
  br label %bb79
bb79:
  br label %bb80
bb80:
  %t280 = load i64, ptr %l12, !tbaa !24
  %t283 = add i64 %t280, 1
  store i64 %t283, ptr %l12, !tbaa !24
  br label %bb70
bb81:
  %t285 = load ptr, ptr %l0, !tbaa !29
  %t287 = getelementptr %"compiler/names:Resolver", ptr %t285, i32 0, i32 2
  %t289 = call %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_Hda627d7755eecb5b938ca977110d67b2(ptr %v0, ptr %v0, ptr %t287)
  store %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" %t289, ptr %l147
  br label %bb82
bb82:
  %t290 = load %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9", ptr %l147
  store %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" %t290, ptr %l14
  br label %bb83
bb83:
  %t292 = call { i32, %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3ccompiler_2fsource_3aNameId_2c_20I6_Hd1b8e91149b724287340e79c8c928444(ptr %v0, ptr %l14)
  %t293 = extractvalue { i32, %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed" } %t292, 1
  %t294 = extractvalue { i32, %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed" } %t292, 0
  store i32 %t294, ptr %l151
  %t295 = icmp ne i32 %t294, 0
  br i1 %t295, label %bb85, label %ok.296, !prof !99
ok.296:
  store %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed" %t293, ptr %l150
  br label %bb84
bb84:
  %t297 = load %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed", ptr %l150
  store %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed" %t297, ptr %l148
  br label %bb87
bb85:
  %t298 = load i32, ptr %l151, !tbaa !23
  %t299 = ashr i32 %t298, 16
  %t301 = icmp eq i32 %t299, 1
  store i1 %t301, ptr %l153, !tbaa !21
  br label %bb86
bb86:
  br label %bb94
bb87:
  %t302 = load %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed", ptr %l148
  store %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed" %t302, ptr %l15
  %t303 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t303, ptr %l154, !tbaa !27
  %t304 = load ptr, ptr %l0, !tbaa !29
  %t305 = getelementptr %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed", ptr %l15, i32 0, i32 0
  %t306 = load i32, ptr %t305, !tbaa !23
  %t309 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %v0, ptr %t304, i32 %t306)
  store { i64, ptr } %t309, ptr %l157
  br label %bb88
bb88:
  %t310 = load { i64, ptr }, ptr %l154, !tbaa !27
  %t311 = load { i64, ptr }, ptr %l157, !tbaa !27
  %t312 = call i64 @compiler_2fmsgs_2eDistance(ptr %v1, ptr %v0, { i64, ptr } %t310, { i64, ptr } %t311)
  store i64 %t312, ptr %l158
  br label %bb89
bb89:
  %t313 = load i64, ptr %l3, !tbaa !24
  %t314 = load i64, ptr %l158, !tbaa !24
  %t316 = icmp slt i64 %t314, %t313
  br i1 %t316, label %bb90, label %bb91
bb90:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb91:
  br label %bb92
bb92:
  br label %bb93
bb93:
  br label %bb83
bb94:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2esurveyBodies(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l8 = alloca i64
  %l11 = alloca i64
  %l14 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/names:Resolver", ptr %t1, i32 0, i32 19
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aUnread_3e_2eLen_3ccompiler_2fnames_3aUnread_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load i64, ptr %l8, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/names:Resolver", ptr %t7, i32 0, i32 16
  %t11 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fsource__H04f1a4a88576bd1070c12151a5c28d38(ptr %v0, ptr %t9)
  store i64 %t11, ptr %l11
  br label %bb2
bb2:
  %t12 = load i64, ptr %l11, !tbaa !24
  store i64 %t12, ptr %l4, !tbaa !24
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/names:Resolver", ptr %t13, i32 0, i32 21
  %t17 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20compiler__H5ec116bb82f5a234bb19cb32db1efc81(ptr %v0, ptr %t15)
  store i64 %t17, ptr %l14
  br label %bb3
bb3:
  %t18 = load i64, ptr %l14, !tbaa !24
  store i64 %t18, ptr %l5, !tbaa !24
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/names:Resolver", ptr %t19, i32 0, i32 23
  store i1 true, ptr %t21, !tbaa !21
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/names:Resolver", ptr %t22, i32 0, i32 0
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/load:Loader", ptr %t25, i32 0, i32 4
  %t28 = load ptr, ptr %t27, !tbaa !29
  %t30 = getelementptr %"compiler/diag:Diagnostics", ptr %t28, i32 0, i32 24
  store i1 true, ptr %t30, !tbaa !21
  %t31 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ebodies(ptr %v0, ptr %v1, ptr %t31, i64 %a1, { i64, ptr } %a2)
  br label %bb4
bb4:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/names:Resolver", ptr %t37, i32 0, i32 0
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t42 = getelementptr %"compiler/load:Loader", ptr %t40, i32 0, i32 4
  %t43 = load ptr, ptr %t42, !tbaa !29
  %t45 = getelementptr %"compiler/diag:Diagnostics", ptr %t43, i32 0, i32 24
  store i1 false, ptr %t45, !tbaa !21
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/names:Resolver", ptr %t46, i32 0, i32 23
  store i1 false, ptr %t48, !tbaa !21
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/names:Resolver", ptr %t49, i32 0, i32 19
  %t52 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aUnread_3e_2eTruncate_3ccompiler_2fnames_3aUnread_3e(ptr %v0, ptr %t51, i64 %t52)
  br label %bb5
bb5:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/names:Resolver", ptr %t55, i32 0, i32 16
  %t58 = load i64, ptr %l4, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fsource__H30ad8836952c6f4772e34a804c6491c6(ptr %v0, ptr %t57, i64 %t58)
  br label %bb6
bb6:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/names:Resolver", ptr %t61, i32 0, i32 21
  %t64 = load i64, ptr %l5, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20compiler__H73edf45b0858a6ff3702d25efc23fa6e(ptr %v0, ptr %t63, i64 %t64)
  br label %bb7
bb7:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2esurveyIf(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l12 = alloca ptr
  %l25 = alloca ptr
  %l26 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:If", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  %t8 = xor i1 %t6, true
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load ptr, ptr %l1, !tbaa !29
  %t13 = getelementptr %"compiler/ast:If", ptr %t11, i32 0, i32 0
  %t14 = load ptr, ptr %t13, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t10, ptr %t14)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t18 = load ptr, ptr %l0, !tbaa !29
  store ptr %t18, ptr %l12, !tbaa !29
  %t19 = load ptr, ptr %l1, !tbaa !29
  %t21 = getelementptr %"compiler/ast:If", ptr %t19, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t24 = icmp eq ptr %t22, null
  br i1 %t24, label %bb5, label %bb6
bb5:
  call void @__olang_check_failed(ptr @olang_loc_1b8bfcf5c54b80a6_f112f6c40c79d862)
  unreachable
bb6:
  br label %bb7
bb7:
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t28 = getelementptr %"compiler/ast:If", ptr %t26, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t32 = getelementptr %"compiler/ast:Branch", ptr %t29, i32 0, i32 1
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !27
  %t34 = load ptr, ptr %l12, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eblock(ptr %v0, ptr %v1, ptr %t34, { i64, ptr } %t33)
  br label %bb8
bb8:
  %t36 = load ptr, ptr %l1, !tbaa !29
  %t38 = getelementptr %"compiler/ast:If", ptr %t36, i32 0, i32 2
  %t39 = load ptr, ptr %t38, !tbaa !29
  %t41 = icmp eq ptr %t39, null
  br i1 %t41, label %bb9, label %bb10
bb9:
  br label %ret
bb10:
  br label %bb11
bb11:
  %t43 = load ptr, ptr %l1, !tbaa !29
  %t45 = getelementptr %"compiler/ast:If", ptr %t43, i32 0, i32 2
  %t46 = load ptr, ptr %t45, !tbaa !29
  store ptr %t46, ptr %l2, !tbaa !29
  %t48 = load ptr, ptr %l2, !tbaa !29
  store ptr %t48, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t49 = load ptr, ptr %l25, !tbaa !29
  %t50 = icmp ne ptr %t49, null
  br i1 %t50, label %bb12, label %bb13
bb12:
  %t52 = load ptr, ptr %l25, !tbaa !29
  %t53 = load i64, ptr %t52, !range !{i64 0, i64 22}
  %t55 = icmp eq i64 %t53, 5
  store i1 %t55, ptr %l26, !tbaa !21
  br label %bb13
bb13:
  %t56 = load i1, ptr %l26, !tbaa !21
  br i1 %t56, label %bb14, label %bb15
bb14:
  %t57 = load ptr, ptr %l2, !tbaa !29
  %t59 = getelementptr { i64, [4 x i64] }, ptr %t57, i32 0, i32 1
  %t60 = getelementptr { %"compiler/source:Span", ptr }, ptr %t59, i32 0, i32 1
  %t61 = load ptr, ptr %t60
  store ptr %t61, ptr %l3, !tbaa !29
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2esurveyIf(ptr %v0, ptr %v1, ptr %t63, ptr %t64)
  br label %bb17
bb17:
  br label %bb24
bb18:
  br i1 true, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb23
bb21:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load ptr, ptr %l1, !tbaa !29
  %t70 = getelementptr %"compiler/ast:If", ptr %t68, i32 0, i32 2
  %t71 = load ptr, ptr %t70, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2estmt(ptr %v0, ptr %v1, ptr %t67, ptr %t71)
  br label %bb22
bb22:
  br label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_c04d895388279f34_2b6890ee7e2f3280)
  unreachable
bb24:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2esurveyRaise(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i1
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l15 = alloca i1
  %l21 = alloca { i64, ptr }
  %l25 = alloca %"compiler/names:Ref"
  %l29 = alloca i1
  %l35 = alloca ptr
  %l39 = alloca i1
  %l40 = alloca i1
  %l43 = alloca { i64, ptr }
  %l44 = alloca i1
  %l47 = alloca i64
  %l49 = alloca i64
  %l51 = alloca ptr
  %l54 = alloca i64
  %l56 = alloca i64
  %l59 = alloca i64
  %l63 = alloca i64
  %l67 = alloca i64
  %l70 = alloca i64
  %l91 = alloca i32
  %l98 = alloca ptr
  %l104 = alloca %"compiler/names:raised"
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb3
bb2:
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = getelementptr %"compiler/ast:Path", ptr %t5, i32 0, i32 1
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t8, 0
  %t12 = icmp ne i64 %t10, 1
  store i1 %t12, ptr %l15, !tbaa !21
  br label %bb3
bb3:
  %t14 = load i1, ptr %l15, !tbaa !21
  br i1 %t14, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb5:
  br label %bb6
bb6:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr %"compiler/ast:Path", ptr %t15, i32 0, i32 1
  %t18 = load { i64, ptr }, ptr %t17, !tbaa !27
  store { i64, ptr } %t18, ptr %l21, !tbaa !27
  %t19 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !27
  %t21 = getelementptr i32, ptr %t20, i64 0
  %t22 = load i32, ptr %t21, !tbaa !33
  store i32 %t22, ptr %l3, !tbaa !23
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load i32, ptr %l3, !tbaa !23
  %t28 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2elookup(ptr %v0, ptr %t24, i32 %t25)
  store %"compiler/names:Ref" %t28, ptr %l25
  br label %bb7
bb7:
  %t29 = getelementptr %"compiler/names:Ref", ptr %l25, i32 0, i32 0
  %t30 = load i32, ptr %t29, !range !{i32 0, i32 9}
  %t32 = trunc i64 0 to i32
  %t33 = icmp eq i32 %t30, %t32
  %t35 = xor i1 %t33, true
  br i1 %t35, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l29, !tbaa !21
  br label %bb12
bb9:
  %t37 = load i32, ptr %l3, !tbaa !23
  store i32 %t37, ptr %l4, !tbaa !23
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/names:Resolver", ptr %t39, i32 0, i32 1
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/names:Resolver", ptr %t42, i32 0, i32 7
  %t45 = load i64, ptr %t44, !tbaa !24
  %t48 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v0, ptr %t41, i64 %t45)
  store ptr %t48, ptr %l35
  br label %bb10
bb10:
  %t49 = load ptr, ptr %l35, !tbaa !29
  %t51 = getelementptr %"compiler/names:Table", ptr %t49, i32 0, i32 4
  %t52 = load i32, ptr %l4, !tbaa !23
  %t55 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H8da9376267bda3f76393292be0e507b2(ptr %v0, ptr %t51, i32 %t52)
  store i1 %t55, ptr %l39
  br label %bb11
bb11:
  %t56 = load i1, ptr %l39, !tbaa !21
  store i1 %t56, ptr %l29, !tbaa !21
  br label %bb12
bb12:
  %t57 = load i1, ptr %l29, !tbaa !21
  br i1 %t57, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l40, !tbaa !21
  br label %bb17
bb14:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load i32, ptr %l3, !tbaa !23
  %t62 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %v0, ptr %t58, i32 %t59)
  store { i64, ptr } %t62, ptr %l43
  br label %bb15
bb15:
  %t63 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t64 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t63, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d30, i32 0, i32 1) })
  store i1 %t64, ptr %l44
  br label %bb16
bb16:
  %t65 = load i1, ptr %l44, !tbaa !21
  store i1 %t65, ptr %l40, !tbaa !21
  br label %bb17
bb17:
  %t66 = load i1, ptr %l40, !tbaa !21
  br i1 %t66, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb19:
  br label %bb20
bb20:
  store i1 false, ptr %l5, !tbaa !21
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/names:Resolver", ptr %t67, i32 0, i32 26
  %t71 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t69)
  store i64 %t71, ptr %l47
  br label %bb21
bb21:
  %t72 = load i64, ptr %l47, !tbaa !24
  %t73 = icmp sgt i64 %t72, 0
  br i1 %t73, label %bb22, label %bb23
bb22:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/names:Resolver", ptr %t75, i32 0, i32 26
  store ptr %t77, ptr %l51, !tbaa !29
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/names:Resolver", ptr %t78, i32 0, i32 26
  %t82 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t80)
  store i64 %t82, ptr %l54
  br label %bb24
bb23:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/names:Resolver", ptr %t83, i32 0, i32 25
  %t87 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t85)
  store i64 %t87, ptr %l59
  br label %bb26
bb24:
  %t88 = load i64, ptr %l54, !tbaa !24
  %t89 = sub i64 %t88, 1
  %t90 = load ptr, ptr %l51, !tbaa !29
  %t92 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t90, i64 %t89)
  store i64 %t92, ptr %l56
  br label %bb25
bb25:
  %t93 = load i64, ptr %l56, !tbaa !24
  store i64 %t93, ptr %l49, !tbaa !24
  br label %bb27
bb26:
  %t94 = load i64, ptr %l59, !tbaa !24
  store i64 %t94, ptr %l49, !tbaa !24
  br label %bb27
bb27:
  %t95 = load i64, ptr %l49, !tbaa !24
  store i64 %t95, ptr %l7, !tbaa !24
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/names:Resolver", ptr %t98, i32 0, i32 25
  %t102 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t100)
  store i64 %t102, ptr %l63
  br label %bb28
bb28:
  %t103 = load i64, ptr %l63, !tbaa !24
  store i64 %t103, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t104 = load i64, ptr %l8, !tbaa !24
  %t105 = load i64, ptr %l7, !tbaa !24
  %t108 = icmp sgt i64 %t104, %t105
  br i1 %t108, label %bb29, label %bb30
bb29:
  %t110 = load i64, ptr %l9, !tbaa !24
  %t112 = icmp sgt i64 %t110, 0
  br i1 %t112, label %bb31, label %bb32
bb30:
  store i64 0, ptr %l67, !tbaa !24
  br label %bb34
bb31:
  %t114 = load i64, ptr %l8, !tbaa !24
  %t115 = load i64, ptr %l7, !tbaa !24
  %t118 = sub i64 %t114, %t115
  %t119 = load i64, ptr %l9, !tbaa !24
  %t122 = add i64 %t118, %t119
  %t124 = sub i64 %t122, 1
  %t125 = load i64, ptr %l9, !tbaa !24
  %t128 = sdiv i64 %t124, %t125
  store i64 %t128, ptr %l70, !tbaa !24
  br label %bb33
bb32:
  store i64 0, ptr %l70, !tbaa !24
  br label %bb33
bb33:
  %t130 = load i64, ptr %l70, !tbaa !24
  store i64 %t130, ptr %l67, !tbaa !24
  br label %bb34
bb34:
  %t131 = load i64, ptr %l67, !tbaa !24
  store i64 %t131, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb35
bb35:
  %t132 = load i64, ptr %l11, !tbaa !24
  %t133 = load i64, ptr %l10, !tbaa !24
  %t136 = icmp slt i64 %t132, %t133
  %t138 = xor i1 %t136, true
  br i1 %t138, label %bb36, label %bb37
bb36:
  br label %bb44
bb37:
  br label %bb38
bb38:
  %t140 = load i64, ptr %l7, !tbaa !24
  %t141 = load i64, ptr %l11, !tbaa !24
  %t142 = load i64, ptr %l9, !tbaa !24
  %t145 = mul i64 %t141, %t142
  %t148 = add i64 %t140, %t145
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t152 = getelementptr %"compiler/names:Resolver", ptr %t150, i32 0, i32 25
  %t156 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eAt_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t152, i64 %t148)
  store i32 %t156, ptr %l91
  br label %bb39
bb39:
  %t157 = load i32, ptr %l3, !tbaa !23
  %t158 = load i32, ptr %l91, !tbaa !23
  %t160 = icmp eq i32 %t158, %t157
  br i1 %t160, label %bb40, label %bb41
bb40:
  store i1 true, ptr %l5, !tbaa !21
  br label %bb42
bb41:
  br label %bb42
bb42:
  br label %bb43
bb43:
  %t162 = load i64, ptr %l11, !tbaa !24
  %t165 = add i64 %t162, 1
  store i64 %t165, ptr %l11, !tbaa !24
  br label %bb35
bb44:
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t169 = getelementptr %"compiler/names:Resolver", ptr %t167, i32 0, i32 24
  store ptr %t169, ptr %l98, !tbaa !29
  %t170 = load i32, ptr %l3, !tbaa !23
  %t171 = load ptr, ptr %l1, !tbaa !29
  %t173 = getelementptr %"compiler/ast:Path", ptr %t171, i32 0, i32 0
  %t174 = load %"compiler/source:Span", ptr %t173
  %t175 = load i1, ptr %l5, !tbaa !21
  %t181 = call %"compiler/names:raised" @compiler_2fnames_3araised_2ector(ptr %v2, ptr %v0, i32 %t170, %"compiler/source:Span" %t174, i1 %t175, { i64, ptr } %a2)
  store %"compiler/names:raised" %t181, ptr %l104
  br label %bb45
bb45:
  %t182 = load ptr, ptr %l98, !tbaa !29
  %t183 = load %"compiler/names:raised", ptr %l104
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3araised_3e_2ePush_3ccompiler_2fnames_3araised_3e(ptr %v0, ptr %v0, ptr %t182, %"compiler/names:raised" %t183)
  br label %bb46
bb46:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etableOf(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l9 = alloca ptr
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ealiasesOf(ptr %v0, ptr %t1, i64 %t2)
  br label %bb1
bb1:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/names:Resolver", ptr %t5, i32 0, i32 0
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = getelementptr %"compiler/load:Loader", ptr %t8, i32 0, i32 10
  %t11 = load i64, ptr %l1, !tbaa !24
  %t14 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t10, i64 %t11)
  store ptr %t14, ptr %l9
  br label %bb2
bb2:
  %t15 = load ptr, ptr %l9, !tbaa !29
  store ptr %t15, ptr %l2, !tbaa !29
  %t16 = load ptr, ptr %l2, !tbaa !29
  %t18 = getelementptr %"compiler/load:Module", ptr %t16, i32 0, i32 8
  %t19 = load { i64, ptr }, ptr %t18, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t19, 0
  %t23 = icmp sgt i64 %t21, 0
  br i1 %t23, label %bb3, label %bb4
bb3:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load i64, ptr %l1, !tbaa !24
  %t27 = load ptr, ptr %l2, !tbaa !29
  %t29 = getelementptr %"compiler/load:Module", ptr %t27, i32 0, i32 8
  %t30 = load { i64, ptr }, ptr %t29, !tbaa !27
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ecollect(ptr %v0, ptr %v0, ptr %t25, i64 %t26, { i64, ptr } %t30)
  br label %bb5
bb4:
  br label %bb6
bb5:
  br label %bb6
bb6:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etopConds(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l11 = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/names:Resolver", ptr %t1, i32 0, i32 13
  store i1 true, ptr %t3, !tbaa !21
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = getelementptr %"compiler/ast:TopIf", ptr %t5, i32 0, i32 0
  %t8 = load ptr, ptr %t7, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t4, ptr %t8)
  br label %bb1
bb1:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/names:Resolver", ptr %t11, i32 0, i32 13
  store i1 false, ptr %t13, !tbaa !21
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr %"compiler/ast:TopIf", ptr %t14, i32 0, i32 2
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t19 = icmp eq ptr %t17, null
  %t21 = xor i1 %t19, true
  br i1 %t21, label %bb2, label %bb3
bb2:
  %t23 = load ptr, ptr %l0, !tbaa !29
  store ptr %t23, ptr %l11, !tbaa !29
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t26 = getelementptr %"compiler/ast:TopIf", ptr %t24, i32 0, i32 2
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t29 = icmp eq ptr %t27, null
  br i1 %t29, label %bb4, label %bb5
bb3:
  br label %bb8
bb4:
  call void @__olang_check_failed(ptr @olang_loc_e6063e0110b31a73_71b4269b957cfb57)
  unreachable
bb5:
  br label %bb6
bb6:
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr %"compiler/ast:TopIf", ptr %t31, i32 0, i32 2
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t35 = load ptr, ptr %l11, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etopConds(ptr %v0, ptr %v1, ptr %t35, ptr %t34)
  br label %bb7
bb7:
  br label %bb8
bb8:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeDecl(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca i64
  %l25 = alloca i64
  %l26 = alloca { i64, ptr }
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca ptr
  %l30 = alloca i64
  %l31 = alloca ptr
  %l32 = alloca i64
  %l34 = alloca { i64, ptr }
  %l35 = alloca ptr
  %l36 = alloca { i64, ptr }
  %l37 = alloca i64
  %l38 = alloca i64
  %l40 = alloca { i64, ptr }
  %l41 = alloca i64
  %l42 = alloca i64
  %l44 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l48 = alloca i64
  %l49 = alloca i64
  %l51 = alloca { i64, ptr }
  %l52 = alloca i64
  %l53 = alloca i64
  %l55 = alloca { i64, ptr }
  %l56 = alloca i64
  %l57 = alloca i64
  %l58 = alloca ptr
  %l59 = alloca i64
  %l60 = alloca ptr
  %l61 = alloca ptr
  %l74 = alloca { i64, ptr }
  %l88 = alloca { i64, ptr }
  %l114 = alloca ptr
  %l115 = alloca i1
  %l121 = alloca i64
  %l133 = alloca { i64, ptr }
  %l150 = alloca { i64, ptr }
  %l176 = alloca { i64, ptr }
  %l186 = alloca i64
  %l195 = alloca { i64, ptr }
  %l227 = alloca i64
  %l229 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l231 = alloca i64
  %l233 = alloca i64
  %l238 = alloca i32
  %l239 = alloca ptr
  %l240 = alloca i32
  %l241 = alloca %"compiler/source:Span"
  %l251 = alloca ptr
  %l252 = alloca i1
  %l272 = alloca { i64, ptr }
  %l283 = alloca { i64, ptr }
  %l295 = alloca ptr
  %l296 = alloca i1
  %l312 = alloca { i64, ptr }
  %l328 = alloca { i64, ptr }
  %l344 = alloca { i64, ptr }
  %l348 = alloca i64
  %l356 = alloca ptr
  %l357 = alloca i1
  %l372 = alloca ptr
  %l373 = alloca i1
  %s26 = alloca %olang.scope
  %s27 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:TypeDecl", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp sgt i64 %t6, 0
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr %"compiler/ast:TypeDecl", ptr %t10, i32 0, i32 1
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  store { i64, ptr } %t13, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  store i64 %t17, ptr %l4, !tbaa !24
  br label %bb3
bb2:
  br label %bb19
bb3:
  %t19 = load i64, ptr %l3, !tbaa !24
  %t20 = load i64, ptr %l4, !tbaa !24
  %t23 = icmp slt i64 %t19, %t20
  %t25 = xor i1 %t23, true
  br i1 %t25, label %bb4, label %bb5
bb4:
  br label %bb18
bb5:
  br label %bb6
bb6:
  %t27 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t27, ptr %l74, !tbaa !27
  %t28 = load i64, ptr %l3, !tbaa !24
  %t30 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !27
  %t32 = getelementptr ptr, ptr %t31, i64 %t28
  %t33 = load ptr, ptr %t32, !tbaa !39
  store ptr %t33, ptr %l5, !tbaa !29
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load ptr, ptr %l5, !tbaa !29
  %t38 = getelementptr %"compiler/ast:TypeParam", ptr %t36, i32 0, i32 2
  %t39 = load ptr, ptr %t38, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeRef(ptr %v0, ptr %v1, ptr %t35, ptr %t39)
  br label %bb7
bb7:
  %t42 = load ptr, ptr %l5, !tbaa !29
  %t44 = getelementptr %"compiler/ast:TypeParam", ptr %t42, i32 0, i32 3
  %t45 = load { i64, ptr }, ptr %t44, !tbaa !27
  store { i64, ptr } %t45, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t47 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t47, 0
  store i64 %t49, ptr %l8, !tbaa !24
  br label %bb8
bb8:
  %t51 = load i64, ptr %l7, !tbaa !24
  %t52 = load i64, ptr %l8, !tbaa !24
  %t55 = icmp slt i64 %t51, %t52
  %t57 = xor i1 %t55, true
  br i1 %t57, label %bb9, label %bb10
bb9:
  br label %bb14
bb10:
  br label %bb11
bb11:
  %t59 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t59, ptr %l88, !tbaa !27
  %t60 = load i64, ptr %l7, !tbaa !24
  %t62 = getelementptr { i64, ptr }, ptr %l88, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !27
  %t64 = getelementptr ptr, ptr %t63, i64 %t60
  %t65 = load ptr, ptr %t64, !tbaa !39
  %t67 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeRef(ptr %v0, ptr %v1, ptr %t67, ptr %t65)
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t72 = load i64, ptr %l7, !tbaa !24
  %t75 = add i64 %t72, 1
  store i64 %t75, ptr %l7, !tbaa !24
  br label %bb8
bb14:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t78 = load ptr, ptr %l5, !tbaa !29
  %t80 = getelementptr %"compiler/ast:TypeParam", ptr %t78, i32 0, i32 5
  %t81 = load ptr, ptr %t80, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeRef(ptr %v0, ptr %v1, ptr %t77, ptr %t81)
  br label %bb15
bb15:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t85 = load ptr, ptr %l5, !tbaa !29
  %t87 = getelementptr %"compiler/ast:TypeParam", ptr %t85, i32 0, i32 1
  %t88 = load i32, ptr %t87, !tbaa !23
  %t89 = load ptr, ptr %l5, !tbaa !29
  %t91 = getelementptr %"compiler/ast:TypeParam", ptr %t89, i32 0, i32 0
  %t92 = load %"compiler/source:Span", ptr %t91
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ebind(ptr %v0, ptr %t84, i32 %t88, %"compiler/source:Span" %t92, i32 8)
  br label %bb16
bb16:
  br label %bb17
bb17:
  %t97 = load i64, ptr %l3, !tbaa !24
  %t100 = add i64 %t97, 1
  store i64 %t100, ptr %l3, !tbaa !24
  br label %bb3
bb18:
  br label %bb19
bb19:
  %t102 = load ptr, ptr %l1, !tbaa !29
  %t104 = getelementptr %"compiler/ast:TypeDecl", ptr %t102, i32 0, i32 3
  %t105 = load ptr, ptr %t104, !tbaa !29
  %t107 = icmp eq ptr %t105, null
  br i1 %t107, label %bb20, label %bb21
bb20:
  br label %ret
bb21:
  br label %bb22
bb22:
  %t109 = load ptr, ptr %l1, !tbaa !29
  %t111 = getelementptr %"compiler/ast:TypeDecl", ptr %t109, i32 0, i32 3
  %t112 = load ptr, ptr %t111, !tbaa !29
  store ptr %t112, ptr %l10, !tbaa !29
  %t114 = load ptr, ptr %l10, !tbaa !29
  store ptr %t114, ptr %l114, !tbaa !29
  store i1 false, ptr %l115, !tbaa !21
  %t115 = load ptr, ptr %l114, !tbaa !29
  %t116 = icmp ne ptr %t115, null
  br i1 %t116, label %bb23, label %bb24
bb23:
  %t118 = load ptr, ptr %l114, !tbaa !29
  %t119 = load i64, ptr %t118, !range !{i64 0, i64 5}
  %t121 = icmp eq i64 %t119, 0
  store i1 %t121, ptr %l115, !tbaa !21
  br label %bb24
bb24:
  %t122 = load i1, ptr %l115, !tbaa !21
  br i1 %t122, label %bb25, label %bb26
bb25:
  %t123 = load ptr, ptr %l10, !tbaa !29
  %t125 = getelementptr { i64, [6 x i64] }, ptr %t123, i32 0, i32 1
  %t126 = getelementptr { ptr }, ptr %t125, i32 0, i32 0
  %t127 = load ptr, ptr %t126
  store ptr %t127, ptr %l11, !tbaa !29
  br label %bb27
bb26:
  br label %bb92
bb27:
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t131 = call i64 @compiler_2fnames_2ecompiler_2fnames_3aResolver_2emark(ptr %v0, ptr %t129)
  store i64 %t131, ptr %l121
  br label %bb28
bb28:
  %t132 = load i64, ptr %l121, !tbaa !24
  store i64 %t132, ptr %l12, !tbaa !24
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t134 = load ptr, ptr %l11, !tbaa !29
  %t136 = getelementptr %"compiler/ast:StructBody", ptr %t134, i32 0, i32 5
  %t137 = load { i64, ptr }, ptr %t136, !tbaa !27
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeParams(ptr %v0, ptr %v1, ptr %t133, { i64, ptr } %t137)
  br label %bb29
bb29:
  %t140 = load ptr, ptr %l11, !tbaa !29
  %t142 = getelementptr %"compiler/ast:StructBody", ptr %t140, i32 0, i32 5
  %t143 = load { i64, ptr }, ptr %t142, !tbaa !27
  store { i64, ptr } %t143, ptr %l13, !tbaa !27
  store i64 0, ptr %l14, !tbaa !24
  %t145 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t147 = extractvalue { i64, ptr } %t145, 0
  store i64 %t147, ptr %l15, !tbaa !24
  br label %bb30
bb30:
  %t149 = load i64, ptr %l14, !tbaa !24
  %t150 = load i64, ptr %l15, !tbaa !24
  %t153 = icmp slt i64 %t149, %t150
  %t155 = xor i1 %t153, true
  br i1 %t155, label %bb31, label %bb32
bb31:
  br label %bb36
bb32:
  br label %bb33
bb33:
  %t157 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t157, ptr %l133, !tbaa !27
  %t158 = load i64, ptr %l14, !tbaa !24
  %t160 = getelementptr { i64, ptr }, ptr %l133, i32 0, i32 1
  %t161 = load ptr, ptr %t160, !tbaa !27
  %t162 = getelementptr ptr, ptr %t161, i64 %t158
  %t163 = load ptr, ptr %t162, !tbaa !39
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t168 = getelementptr %"compiler/ast:TypeParam", ptr %t163, i32 0, i32 5
  %t169 = load ptr, ptr %t168, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeRef(ptr %v0, ptr %v1, ptr %t165, ptr %t169)
  br label %bb34
bb34:
  br label %bb35
bb35:
  %t172 = load i64, ptr %l14, !tbaa !24
  %t175 = add i64 %t172, 1
  store i64 %t175, ptr %l14, !tbaa !24
  br label %bb30
bb36:
  %t177 = load ptr, ptr %l11, !tbaa !29
  %t179 = getelementptr %"compiler/ast:StructBody", ptr %t177, i32 0, i32 0
  %t180 = load { i64, ptr }, ptr %t179, !tbaa !27
  store { i64, ptr } %t180, ptr %l17, !tbaa !27
  store i64 0, ptr %l18, !tbaa !24
  %t182 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t184 = extractvalue { i64, ptr } %t182, 0
  store i64 %t184, ptr %l19, !tbaa !24
  br label %bb37
bb37:
  %t186 = load i64, ptr %l18, !tbaa !24
  %t187 = load i64, ptr %l19, !tbaa !24
  %t190 = icmp slt i64 %t186, %t187
  %t192 = xor i1 %t190, true
  br i1 %t192, label %bb38, label %bb39
bb38:
  br label %bb43
bb39:
  br label %bb40
bb40:
  %t194 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t194, ptr %l150, !tbaa !27
  %t195 = load i64, ptr %l18, !tbaa !24
  %t197 = getelementptr { i64, ptr }, ptr %l150, i32 0, i32 1
  %t198 = load ptr, ptr %t197, !tbaa !27
  %t199 = getelementptr ptr, ptr %t198, i64 %t195
  %t200 = load ptr, ptr %t199, !tbaa !39
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t205 = getelementptr %"compiler/ast:Param", ptr %t200, i32 0, i32 2
  %t206 = load ptr, ptr %t205, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeRef(ptr %v0, ptr %v1, ptr %t202, ptr %t206)
  br label %bb41
bb41:
  br label %bb42
bb42:
  %t209 = load i64, ptr %l18, !tbaa !24
  %t212 = add i64 %t209, 1
  store i64 %t212, ptr %l18, !tbaa !24
  br label %bb37
bb43:
  %t214 = load ptr, ptr %l11, !tbaa !29
  %t216 = getelementptr %"compiler/ast:StructBody", ptr %t214, i32 0, i32 1
  %t217 = load ptr, ptr %t216, !tbaa !29
  %t219 = icmp eq ptr %t217, null
  %t221 = xor i1 %t219, true
  br i1 %t221, label %bb44, label %bb45
bb44:
  %t223 = load ptr, ptr %l11, !tbaa !29
  %t225 = getelementptr %"compiler/ast:StructBody", ptr %t223, i32 0, i32 1
  %t226 = load ptr, ptr %t225, !tbaa !29
  %t228 = icmp eq ptr %t226, null
  br i1 %t228, label %bb46, label %bb47
bb45:
  br label %bb56
bb46:
  call void @__olang_check_failed(ptr @olang_loc_6e82bb982de183d3_df58ae24de93c697)
  unreachable
bb47:
  br label %bb48
bb48:
  %t230 = load ptr, ptr %l11, !tbaa !29
  %t232 = getelementptr %"compiler/ast:StructBody", ptr %t230, i32 0, i32 1
  %t233 = load ptr, ptr %t232, !tbaa !29
  %t236 = getelementptr %"compiler/ast:Sig", ptr %t233, i32 0, i32 3
  %t237 = load { i64, ptr }, ptr %t236, !tbaa !27
  store { i64, ptr } %t237, ptr %l21, !tbaa !27
  store i64 0, ptr %l22, !tbaa !24
  %t239 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t241 = extractvalue { i64, ptr } %t239, 0
  store i64 %t241, ptr %l23, !tbaa !24
  br label %bb49
bb49:
  %t243 = load i64, ptr %l22, !tbaa !24
  %t244 = load i64, ptr %l23, !tbaa !24
  %t247 = icmp slt i64 %t243, %t244
  %t249 = xor i1 %t247, true
  br i1 %t249, label %bb50, label %bb51
bb50:
  br label %bb55
bb51:
  br label %bb52
bb52:
  %t251 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t251, ptr %l176, !tbaa !27
  %t252 = load i64, ptr %l22, !tbaa !24
  %t254 = getelementptr { i64, ptr }, ptr %l176, i32 0, i32 1
  %t255 = load ptr, ptr %t254, !tbaa !27
  %t256 = getelementptr ptr, ptr %t255, i64 %t252
  %t257 = load ptr, ptr %t256, !tbaa !39
  %t259 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2epath(ptr %v0, ptr %v1, ptr %t259, ptr %t257)
  br label %bb53
bb53:
  br label %bb54
bb54:
  %t264 = load i64, ptr %l22, !tbaa !24
  %t267 = add i64 %t264, 1
  store i64 %t267, ptr %l22, !tbaa !24
  br label %bb49
bb55:
  br label %bb56
bb56:
  %t269 = load ptr, ptr %l0, !tbaa !29
  %t271 = call i64 @compiler_2fnames_2ecompiler_2fnames_3aResolver_2emark(ptr %v0, ptr %t269)
  store i64 %t271, ptr %l186
  br label %bb57
bb57:
  %t272 = load i64, ptr %l186, !tbaa !24
  store i64 %t272, ptr %l25, !tbaa !24
  %t273 = load ptr, ptr %l11, !tbaa !29
  %t275 = getelementptr %"compiler/ast:StructBody", ptr %t273, i32 0, i32 0
  %t276 = load { i64, ptr }, ptr %t275, !tbaa !27
  store { i64, ptr } %t276, ptr %l26, !tbaa !27
  store i64 0, ptr %l27, !tbaa !24
  %t278 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t280 = extractvalue { i64, ptr } %t278, 0
  store i64 %t280, ptr %l28, !tbaa !24
  br label %bb58
bb58:
  %t282 = load i64, ptr %l27, !tbaa !24
  %t283 = load i64, ptr %l28, !tbaa !24
  %t286 = icmp slt i64 %t282, %t283
  %t288 = xor i1 %t286, true
  br i1 %t288, label %bb59, label %bb60
bb59:
  br label %bb68
bb60:
  br label %bb61
bb61:
  %t290 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t290, ptr %l195, !tbaa !27
  %t291 = load i64, ptr %l27, !tbaa !24
  %t293 = getelementptr { i64, ptr }, ptr %l195, i32 0, i32 1
  %t294 = load ptr, ptr %t293, !tbaa !27
  %t295 = getelementptr ptr, ptr %t294, i64 %t291
  %t296 = load ptr, ptr %t295, !tbaa !39
  store ptr %t296, ptr %l29, !tbaa !29
  %t298 = load ptr, ptr %l29, !tbaa !29
  %t300 = getelementptr %"compiler/ast:Param", ptr %t298, i32 0, i32 3
  %t301 = load ptr, ptr %t300, !tbaa !29
  %t303 = icmp eq ptr %t301, null
  %t305 = xor i1 %t303, true
  br i1 %t305, label %bb62, label %bb63
bb62:
  %t307 = load ptr, ptr %l0, !tbaa !29
  %t308 = load ptr, ptr %l29, !tbaa !29
  %t310 = getelementptr %"compiler/ast:Param", ptr %t308, i32 0, i32 3
  %t311 = load ptr, ptr %t310, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t307, ptr %t311)
  br label %bb64
bb63:
  br label %bb65
bb64:
  br label %bb65
bb65:
  %t315 = load ptr, ptr %l0, !tbaa !29
  %t316 = load ptr, ptr %l29, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eparam(ptr %v0, ptr %v1, ptr %t315, ptr %t316, i1 true)
  br label %bb66
bb66:
  br label %bb67
bb67:
  %t319 = load i64, ptr %l27, !tbaa !24
  %t322 = add i64 %t319, 1
  store i64 %t322, ptr %l27, !tbaa !24
  br label %bb58
bb68:
  %t324 = load ptr, ptr %l11, !tbaa !29
  %t326 = getelementptr %"compiler/ast:StructBody", ptr %t324, i32 0, i32 2
  %t327 = load { i64, ptr }, ptr %t326, !tbaa !27
  %t329 = extractvalue { i64, ptr } %t327, 0
  %t331 = icmp sgt i64 %t329, 0
  br i1 %t331, label %bb69, label %bb70
bb69:
  %t333 = load ptr, ptr %l0, !tbaa !29
  %t334 = load ptr, ptr %l11, !tbaa !29
  %t336 = getelementptr %"compiler/ast:StructBody", ptr %t334, i32 0, i32 2
  %t337 = load { i64, ptr }, ptr %t336, !tbaa !27
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eblock(ptr %v0, ptr %v1, ptr %t333, { i64, ptr } %t337)
  br label %bb71
bb70:
  br label %bb72
bb71:
  br label %bb72
bb72:
  %t340 = load ptr, ptr %l0, !tbaa !29
  %t341 = load i64, ptr %l25, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2epopTo(ptr %v0, ptr %t340, i64 %t341)
  br label %bb73
bb73:
  %t344 = load ptr, ptr %l0, !tbaa !29
  %t345 = load i64, ptr %l12, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2epopTo(ptr %v0, ptr %t344, i64 %t345)
  br label %bb74
bb74:
  %t348 = load ptr, ptr %l11, !tbaa !29
  %t350 = getelementptr %"compiler/ast:StructBody", ptr %t348, i32 0, i32 4
  %t351 = load { i64, ptr }, ptr %t350, !tbaa !27
  %t353 = extractvalue { i64, ptr } %t351, 0
  %t355 = icmp sgt i64 %t353, 0
  br i1 %t355, label %bb75, label %bb76
bb75:
  %t357 = load ptr, ptr %l0, !tbaa !29
  %t359 = call i64 @compiler_2fnames_2ecompiler_2fnames_3aResolver_2emark(ptr %v0, ptr %t357)
  store i64 %t359, ptr %l227
  br label %bb77
bb76:
  br label %bb91
bb77:
  %t360 = load i64, ptr %l227, !tbaa !24
  store i64 %t360, ptr %l30, !tbaa !24
  store %olang.scope zeroinitializer, ptr %s26
  %t361 = load ptr, ptr %l11, !tbaa !29
  %t363 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fnames_2efieldNames(ptr %v1, ptr %s26, ptr %t361)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t363, ptr %l229
  br label %bb78
bb78:
  %t364 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l229
  %t365 = call ptr @__olang_scope_alloc_a(ptr %s26, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t364, ptr %t365
  store ptr %t365, ptr %l31, !tbaa !29
  store i64 0, ptr %l32, !tbaa !24
  br label %bb79
bb79:
  store %olang.scope zeroinitializer, ptr %s27
  %t367 = load i64, ptr %l32, !tbaa !24
  store i64 %t367, ptr %l231, !tbaa !24
  %t368 = load ptr, ptr %l31, !tbaa !29
  %t370 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %s26, ptr %t368)
  store i64 %t370, ptr %l233
  br label %bb80
bb80:
  %t371 = load i64, ptr %l231, !tbaa !24
  %t372 = load i64, ptr %l233, !tbaa !24
  %t373 = icmp slt i64 %t371, %t372
  %t375 = xor i1 %t373, true
  br i1 %t375, label %bb81, label %bb82
bb81:
  call void @__olang_scope_close(ptr %s27)
  br label %bb88
bb82:
  br label %bb83
bb83:
  %t377 = load ptr, ptr %l31, !tbaa !29
  %t378 = load i64, ptr %l32, !tbaa !24
  %t381 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eAt_3ccompiler_2fsource_3aNameId_3e(ptr %s26, ptr %t377, i64 %t378)
  store i32 %t381, ptr %l238
  br label %bb84
bb84:
  %t382 = load i32, ptr %l238, !tbaa !23
  %t383 = load ptr, ptr %l0, !tbaa !29
  store ptr %t383, ptr %l239, !tbaa !29
  store i32 %t382, ptr %l240, !tbaa !23
  %t385 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s27, i32 0, i32 0)
  store %"compiler/source:Span" %t385, ptr %l241
  br label %bb85
bb85:
  %t386 = load ptr, ptr %l239, !tbaa !29
  %t387 = load i32, ptr %l240, !tbaa !23
  %t388 = load %"compiler/source:Span", ptr %l241
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ebind(ptr %v0, ptr %t386, i32 %t387, %"compiler/source:Span" %t388, i32 1)
  br label %bb86
bb86:
  call void @__olang_scope_close(ptr %s27)
  br label %bb87
bb87:
  %t390 = load i64, ptr %l32, !tbaa !24
  %t393 = add i64 %t390, 1
  store i64 %t393, ptr %l32, !tbaa !24
  br label %bb79
bb88:
  call void @__olang_scope_close(ptr %s26)
  %t395 = load ptr, ptr %l0, !tbaa !29
  %t396 = load ptr, ptr %l11, !tbaa !29
  %t398 = getelementptr %"compiler/ast:StructBody", ptr %t396, i32 0, i32 4
  %t399 = load { i64, ptr }, ptr %t398, !tbaa !27
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eblock(ptr %v0, ptr %v1, ptr %t395, { i64, ptr } %t399)
  br label %bb89
bb89:
  %t402 = load ptr, ptr %l0, !tbaa !29
  %t403 = load i64, ptr %l30, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2epopTo(ptr %v0, ptr %t402, i64 %t403)
  br label %bb90
bb90:
  br label %bb91
bb91:
  br label %bb162
bb92:
  %t406 = load ptr, ptr %l10, !tbaa !29
  store ptr %t406, ptr %l251, !tbaa !29
  store i1 false, ptr %l252, !tbaa !21
  %t407 = load ptr, ptr %l251, !tbaa !29
  %t408 = icmp ne ptr %t407, null
  br i1 %t408, label %bb93, label %bb94
bb93:
  %t410 = load ptr, ptr %l251, !tbaa !29
  %t411 = load i64, ptr %t410, !range !{i64 0, i64 5}
  %t413 = icmp eq i64 %t411, 1
  store i1 %t413, ptr %l252, !tbaa !21
  br label %bb94
bb94:
  %t414 = load i1, ptr %l252, !tbaa !21
  br i1 %t414, label %bb95, label %bb96
bb95:
  %t415 = load ptr, ptr %l10, !tbaa !29
  %t417 = getelementptr { i64, [6 x i64] }, ptr %t415, i32 0, i32 1
  %t418 = getelementptr { { i64, ptr }, ptr }, ptr %t417, i32 0, i32 0
  %t419 = load { i64, ptr }, ptr %t418
  store { i64, ptr } %t419, ptr %l34, !tbaa !27
  %t421 = load ptr, ptr %l10, !tbaa !29
  %t423 = getelementptr { i64, [6 x i64] }, ptr %t421, i32 0, i32 1
  %t424 = getelementptr { { i64, ptr }, ptr }, ptr %t423, i32 0, i32 1
  %t425 = load ptr, ptr %t424
  store ptr %t425, ptr %l35, !tbaa !29
  br label %bb97
bb96:
  br label %bb115
bb97:
  %t427 = load ptr, ptr %l35, !tbaa !29
  %t429 = icmp eq ptr %t427, null
  %t431 = xor i1 %t429, true
  br i1 %t431, label %bb98, label %bb99
bb98:
  %t433 = load ptr, ptr %l0, !tbaa !29
  %t434 = load ptr, ptr %l35, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeRef(ptr %v0, ptr %v1, ptr %t433, ptr %t434)
  br label %bb100
bb99:
  br label %bb101
bb100:
  br label %bb101
bb101:
  %t438 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t438, ptr %l36, !tbaa !27
  store i64 0, ptr %l37, !tbaa !24
  %t440 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t442 = extractvalue { i64, ptr } %t440, 0
  store i64 %t442, ptr %l38, !tbaa !24
  br label %bb102
bb102:
  %t444 = load i64, ptr %l37, !tbaa !24
  %t445 = load i64, ptr %l38, !tbaa !24
  %t448 = icmp slt i64 %t444, %t445
  %t450 = xor i1 %t448, true
  br i1 %t450, label %bb103, label %bb104
bb103:
  br label %bb114
bb104:
  br label %bb105
bb105:
  %t452 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t452, ptr %l272, !tbaa !27
  %t453 = load i64, ptr %l37, !tbaa !24
  %t455 = getelementptr { i64, ptr }, ptr %l272, i32 0, i32 1
  %t456 = load ptr, ptr %t455, !tbaa !27
  %t457 = getelementptr ptr, ptr %t456, i64 %t453
  %t458 = load ptr, ptr %t457, !tbaa !39
  %t462 = getelementptr %"compiler/ast:CaseDecl", ptr %t458, i32 0, i32 2
  %t463 = load { i64, ptr }, ptr %t462, !tbaa !27
  store { i64, ptr } %t463, ptr %l40, !tbaa !27
  store i64 0, ptr %l41, !tbaa !24
  %t465 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t467 = extractvalue { i64, ptr } %t465, 0
  store i64 %t467, ptr %l42, !tbaa !24
  br label %bb106
bb106:
  %t469 = load i64, ptr %l41, !tbaa !24
  %t470 = load i64, ptr %l42, !tbaa !24
  %t473 = icmp slt i64 %t469, %t470
  %t475 = xor i1 %t473, true
  br i1 %t475, label %bb107, label %bb108
bb107:
  br label %bb112
bb108:
  br label %bb109
bb109:
  %t477 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t477, ptr %l283, !tbaa !27
  %t478 = load i64, ptr %l41, !tbaa !24
  %t480 = getelementptr { i64, ptr }, ptr %l283, i32 0, i32 1
  %t481 = load ptr, ptr %t480, !tbaa !27
  %t482 = getelementptr ptr, ptr %t481, i64 %t478
  %t483 = load ptr, ptr %t482, !tbaa !39
  %t485 = load ptr, ptr %l0, !tbaa !29
  %t488 = getelementptr %"compiler/ast:Param", ptr %t483, i32 0, i32 2
  %t489 = load ptr, ptr %t488, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeRef(ptr %v0, ptr %v1, ptr %t485, ptr %t489)
  br label %bb110
bb110:
  br label %bb111
bb111:
  %t492 = load i64, ptr %l41, !tbaa !24
  %t495 = add i64 %t492, 1
  store i64 %t495, ptr %l41, !tbaa !24
  br label %bb106
bb112:
  br label %bb113
bb113:
  %t497 = load i64, ptr %l37, !tbaa !24
  %t500 = add i64 %t497, 1
  store i64 %t500, ptr %l37, !tbaa !24
  br label %bb102
bb114:
  br label %bb162
bb115:
  %t502 = load ptr, ptr %l10, !tbaa !29
  store ptr %t502, ptr %l295, !tbaa !29
  store i1 false, ptr %l296, !tbaa !21
  %t503 = load ptr, ptr %l295, !tbaa !29
  %t504 = icmp ne ptr %t503, null
  br i1 %t504, label %bb116, label %bb117
bb116:
  %t506 = load ptr, ptr %l295, !tbaa !29
  %t507 = load i64, ptr %t506, !range !{i64 0, i64 5}
  %t509 = icmp eq i64 %t507, 2
  store i1 %t509, ptr %l296, !tbaa !21
  br label %bb117
bb117:
  %t510 = load i1, ptr %l296, !tbaa !21
  br i1 %t510, label %bb118, label %bb119
bb118:
  %t511 = load ptr, ptr %l10, !tbaa !29
  %t513 = getelementptr { i64, [6 x i64] }, ptr %t511, i32 0, i32 1
  %t514 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t513, i32 0, i32 0
  %t515 = load { i64, ptr }, ptr %t514
  store { i64, ptr } %t515, ptr %l44, !tbaa !27
  %t517 = load ptr, ptr %l10, !tbaa !29
  %t519 = getelementptr { i64, [6 x i64] }, ptr %t517, i32 0, i32 1
  %t520 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t519, i32 0, i32 1
  %t521 = load { i64, ptr }, ptr %t520
  store { i64, ptr } %t521, ptr %l45, !tbaa !27
  %t523 = load ptr, ptr %l10, !tbaa !29
  %t525 = getelementptr { i64, [6 x i64] }, ptr %t523, i32 0, i32 1
  %t526 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t525, i32 0, i32 2
  %t527 = load { i64, ptr }, ptr %t526
  store { i64, ptr } %t527, ptr %l46, !tbaa !27
  br label %bb120
bb119:
  br label %bb144
bb120:
  %t529 = load { i64, ptr }, ptr %l45, !tbaa !27
  store { i64, ptr } %t529, ptr %l47, !tbaa !27
  store i64 0, ptr %l48, !tbaa !24
  %t531 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t533 = extractvalue { i64, ptr } %t531, 0
  store i64 %t533, ptr %l49, !tbaa !24
  br label %bb121
bb121:
  %t535 = load i64, ptr %l48, !tbaa !24
  %t536 = load i64, ptr %l49, !tbaa !24
  %t539 = icmp slt i64 %t535, %t536
  %t541 = xor i1 %t539, true
  br i1 %t541, label %bb122, label %bb123
bb122:
  br label %bb127
bb123:
  br label %bb124
bb124:
  %t543 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t543, ptr %l312, !tbaa !27
  %t544 = load i64, ptr %l48, !tbaa !24
  %t546 = getelementptr { i64, ptr }, ptr %l312, i32 0, i32 1
  %t547 = load ptr, ptr %t546, !tbaa !27
  %t548 = getelementptr ptr, ptr %t547, i64 %t544
  %t549 = load ptr, ptr %t548, !tbaa !39
  %t551 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeRef(ptr %v0, ptr %v1, ptr %t551, ptr %t549)
  br label %bb125
bb125:
  br label %bb126
bb126:
  %t556 = load i64, ptr %l48, !tbaa !24
  %t559 = add i64 %t556, 1
  store i64 %t559, ptr %l48, !tbaa !24
  br label %bb121
bb127:
  %t561 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t561, ptr %l51, !tbaa !27
  store i64 0, ptr %l52, !tbaa !24
  %t563 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t565 = extractvalue { i64, ptr } %t563, 0
  store i64 %t565, ptr %l53, !tbaa !24
  br label %bb128
bb128:
  %t567 = load i64, ptr %l52, !tbaa !24
  %t568 = load i64, ptr %l53, !tbaa !24
  %t571 = icmp slt i64 %t567, %t568
  %t573 = xor i1 %t571, true
  br i1 %t573, label %bb129, label %bb130
bb129:
  br label %bb134
bb130:
  br label %bb131
bb131:
  %t575 = load { i64, ptr }, ptr %l51, !tbaa !27
  store { i64, ptr } %t575, ptr %l328, !tbaa !27
  %t576 = load i64, ptr %l52, !tbaa !24
  %t578 = getelementptr { i64, ptr }, ptr %l328, i32 0, i32 1
  %t579 = load ptr, ptr %t578, !tbaa !27
  %t580 = getelementptr ptr, ptr %t579, i64 %t576
  %t581 = load ptr, ptr %t580, !tbaa !39
  %t583 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeRef(ptr %v0, ptr %v1, ptr %t583, ptr %t581)
  br label %bb132
bb132:
  br label %bb133
bb133:
  %t588 = load i64, ptr %l52, !tbaa !24
  %t591 = add i64 %t588, 1
  store i64 %t591, ptr %l52, !tbaa !24
  br label %bb128
bb134:
  %t593 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t593, ptr %l55, !tbaa !27
  store i64 0, ptr %l56, !tbaa !24
  %t595 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t597 = extractvalue { i64, ptr } %t595, 0
  store i64 %t597, ptr %l57, !tbaa !24
  br label %bb135
bb135:
  %t599 = load i64, ptr %l56, !tbaa !24
  %t600 = load i64, ptr %l57, !tbaa !24
  %t603 = icmp slt i64 %t599, %t600
  %t605 = xor i1 %t603, true
  br i1 %t605, label %bb136, label %bb137
bb136:
  br label %bb143
bb137:
  br label %bb138
bb138:
  %t607 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t607, ptr %l344, !tbaa !27
  %t608 = load i64, ptr %l56, !tbaa !24
  %t610 = getelementptr { i64, ptr }, ptr %l344, i32 0, i32 1
  %t611 = load ptr, ptr %t610, !tbaa !27
  %t612 = getelementptr ptr, ptr %t611, i64 %t608
  %t613 = load ptr, ptr %t612, !tbaa !39
  store ptr %t613, ptr %l58, !tbaa !29
  %t615 = load ptr, ptr %l0, !tbaa !29
  %t617 = call i64 @compiler_2fnames_2ecompiler_2fnames_3aResolver_2emark(ptr %v0, ptr %t615)
  store i64 %t617, ptr %l348
  br label %bb139
bb139:
  %t618 = load i64, ptr %l348, !tbaa !24
  store i64 %t618, ptr %l59, !tbaa !24
  %t619 = load ptr, ptr %l0, !tbaa !29
  %t620 = load ptr, ptr %l58, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2esig(ptr %v0, ptr %v1, ptr %t619, ptr %t620, i1 false)
  br label %bb140
bb140:
  %t623 = load ptr, ptr %l0, !tbaa !29
  %t624 = load i64, ptr %l59, !tbaa !24
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2epopTo(ptr %v0, ptr %t623, i64 %t624)
  br label %bb141
bb141:
  br label %bb142
bb142:
  %t627 = load i64, ptr %l56, !tbaa !24
  %t630 = add i64 %t627, 1
  store i64 %t630, ptr %l56, !tbaa !24
  br label %bb135
bb143:
  br label %bb162
bb144:
  %t632 = load ptr, ptr %l10, !tbaa !29
  store ptr %t632, ptr %l356, !tbaa !29
  store i1 false, ptr %l357, !tbaa !21
  %t633 = load ptr, ptr %l356, !tbaa !29
  %t634 = icmp ne ptr %t633, null
  br i1 %t634, label %bb145, label %bb146
bb145:
  %t636 = load ptr, ptr %l356, !tbaa !29
  %t637 = load i64, ptr %t636, !range !{i64 0, i64 5}
  %t639 = icmp eq i64 %t637, 3
  store i1 %t639, ptr %l357, !tbaa !21
  br label %bb146
bb146:
  %t640 = load i1, ptr %l357, !tbaa !21
  br i1 %t640, label %bb147, label %bb148
bb147:
  %t641 = load ptr, ptr %l10, !tbaa !29
  %t643 = getelementptr { i64, [6 x i64] }, ptr %t641, i32 0, i32 1
  %t644 = getelementptr { ptr, ptr }, ptr %t643, i32 0, i32 0
  %t645 = load ptr, ptr %t644
  store ptr %t645, ptr %l60, !tbaa !29
  %t647 = load ptr, ptr %l10, !tbaa !29
  %t649 = getelementptr { i64, [6 x i64] }, ptr %t647, i32 0, i32 1
  %t650 = getelementptr { ptr, ptr }, ptr %t649, i32 0, i32 1
  %t651 = load ptr, ptr %t650
  store ptr %t651, ptr %l61, !tbaa !29
  br label %bb149
bb148:
  br label %bb155
bb149:
  %t653 = load ptr, ptr %l0, !tbaa !29
  %t654 = load ptr, ptr %l60, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeRef(ptr %v0, ptr %v1, ptr %t653, ptr %t654)
  br label %bb150
bb150:
  %t658 = load ptr, ptr %l61, !tbaa !29
  %t660 = icmp eq ptr %t658, null
  %t662 = xor i1 %t660, true
  br i1 %t662, label %bb151, label %bb152
bb151:
  %t664 = load ptr, ptr %l0, !tbaa !29
  %t665 = load ptr, ptr %l61, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2efunc(ptr %v0, ptr %v1, ptr %t664, ptr %t665)
  br label %bb153
bb152:
  br label %bb154
bb153:
  br label %bb154
bb154:
  br label %bb162
bb155:
  %t668 = load ptr, ptr %l10, !tbaa !29
  store ptr %t668, ptr %l372, !tbaa !29
  store i1 false, ptr %l373, !tbaa !21
  %t669 = load ptr, ptr %l372, !tbaa !29
  %t670 = icmp ne ptr %t669, null
  br i1 %t670, label %bb156, label %bb157
bb156:
  %t672 = load ptr, ptr %l372, !tbaa !29
  %t673 = load i64, ptr %t672, !range !{i64 0, i64 5}
  %t675 = icmp eq i64 %t673, 4
  store i1 %t675, ptr %l373, !tbaa !21
  br label %bb157
bb157:
  %t676 = load i1, ptr %l373, !tbaa !21
  br i1 %t676, label %bb158, label %bb159
bb158:
  br label %bb160
bb159:
  br label %bb161
bb160:
  br label %bb162
bb161:
  call void @__olang_check_failed(ptr @olang_loc_2a287a06f88e222b_c77af2bce9e1616f)
  unreachable
bb162:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypePath(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca %"compiler/names:Ref"
  %l7 = alloca %"compiler/source:Span"
  %l8 = alloca i64
  %l9 = alloca i32
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca %"compiler/load:Import"
  %l14 = alloca i64
  %l15 = alloca i32
  %l16 = alloca %"compiler/names:Ref"
  %l20 = alloca { i64, ptr }
  %l22 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i32
  %l30 = alloca i1
  %l34 = alloca %"compiler/names:local"
  %l37 = alloca ptr
  %l38 = alloca %"compiler/source:Span"
  %l43 = alloca %"compiler/names:Ref"
  %l44 = alloca ptr
  %l45 = alloca %"compiler/source:Span"
  %l50 = alloca %"compiler/names:Ref"
  %l51 = alloca { i64, ptr }
  %l53 = alloca i64
  %l58 = alloca ptr
  %l62 = alloca i64
  %l63 = alloca i32
  %l67 = alloca %"compiler/names:Ref"
  %l73 = alloca %"compiler/source:Span"
  %l78 = alloca i64
  %l84 = alloca i64
  %l87 = alloca i1
  %l90 = alloca { i64, ptr }
  %l93 = alloca { i64, ptr }
  %l96 = alloca i1
  %l98 = alloca i1
  %l104 = alloca ptr
  %l108 = alloca i1
  %l110 = alloca i1
  %l113 = alloca i1
  %l116 = alloca ptr
  %l118 = alloca %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed"
  %l121 = alloca { i64, ptr }
  %l122 = alloca %"compiler/msgs:Nearest"
  %l129 = alloca ptr
  %l132 = alloca i64
  %l134 = alloca i64
  %l139 = alloca %"compiler/load:Import"
  %l149 = alloca ptr
  %l154 = alloca { i64, [3 x i64] }
  %l157 = alloca { i64, ptr }
  %l158 = alloca { i64, ptr }
  %l160 = alloca { i64, ptr }
  %l162 = alloca %"compiler/diagmsg:Msg"
  %l163 = alloca i64
  %l168 = alloca i1
  %l172 = alloca ptr
  %l178 = alloca ptr
  %l182 = alloca i64
  %l186 = alloca i64
  %l189 = alloca { i64, ptr }
  %l197 = alloca %"compiler/names:Ref"
  %l198 = alloca ptr
  %l199 = alloca i64
  %l200 = alloca %"compiler/names:Ref"
  %l201 = alloca i32
  %l202 = alloca i32
  %l205 = alloca { i64, ptr }
  %l210 = alloca %"compiler/source:Span"
  %l213 = alloca i1
  %l218 = alloca ptr
  %l224 = alloca ptr
  %l228 = alloca i64
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s12 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 1
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t7, ptr %l20, !tbaa !27
  %t8 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !27
  %t10 = getelementptr i32, ptr %t9, i64 0
  %t11 = load i32, ptr %t10, !tbaa !33
  store i32 %t11, ptr %l3, !tbaa !23
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/names:Resolver", ptr %t13, i32 0, i32 9
  %t16 = load i32, ptr %l3, !tbaa !23
  %t19 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %t15, i32 %t16)
  %t20 = extractvalue { i32, i64 } %t19, 1
  %t21 = extractvalue { i32, i64 } %t19, 0
  store i32 %t21, ptr %l27
  %t22 = icmp ne i32 %t21, 0
  br i1 %t22, label %bb4, label %ok.23, !prof !99
ok.23:
  store i64 %t20, ptr %l26
  br label %bb3
bb2:
  br label %bb18
bb3:
  %t24 = load i64, ptr %l26, !tbaa !24
  store i64 %t24, ptr %l22, !tbaa !24
  br label %bb6
bb4:
  br label %bb5
bb5:
  store i64 -1, ptr %l22, !tbaa !24
  br label %bb6
bb6:
  %t25 = load i64, ptr %l22, !tbaa !24
  store i64 %t25, ptr %l4, !tbaa !24
  %t26 = load i64, ptr %l4, !tbaa !24
  %t28 = icmp sge i64 %t26, 0
  br i1 %t28, label %bb7, label %bb8
bb7:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/names:Resolver", ptr %t30, i32 0, i32 8
  %t33 = load i64, ptr %l4, !tbaa !24
  %t36 = call %"compiler/names:local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3alocal_3e_2eAt_3ccompiler_2fnames_3alocal_3e(ptr %v0, ptr %t32, i64 %t33)
  store %"compiler/names:local" %t36, ptr %l34
  br label %bb9
bb8:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb10
bb9:
  %t37 = getelementptr %"compiler/names:local", ptr %l34, i32 0, i32 2
  %t38 = load i32, ptr %t37, !range !{i32 0, i32 9}
  %t40 = trunc i64 8 to i32
  %t41 = icmp eq i32 %t38, %t40
  store i1 %t41, ptr %l30, !tbaa !21
  br label %bb10
bb10:
  %t43 = load i1, ptr %l30, !tbaa !21
  br i1 %t43, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s2
  %t44 = load ptr, ptr %l0, !tbaa !29
  store ptr %t44, ptr %l37, !tbaa !29
  %t45 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t45, ptr %l38
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/names:Resolver", ptr %t46, i32 0, i32 7
  %t49 = load i64, ptr %t48, !tbaa !24
  %t50 = load i64, ptr %l4, !tbaa !24
  %t54 = call %"compiler/names:Ref" @compiler_2fnames_3aRef_2ector(ptr %s2, i32 8, i64 %t49, i64 %t50)
  store %"compiler/names:Ref" %t54, ptr %l43
  br label %bb13
bb12:
  br label %bb15
bb13:
  %t55 = load ptr, ptr %l37, !tbaa !29
  %t56 = load %"compiler/source:Span", ptr %l38
  %t57 = load %"compiler/names:Ref", ptr %l43
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2erecord(ptr %v0, ptr %t55, %"compiler/source:Span" %t56, %"compiler/names:Ref" %t57)
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb15:
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l44, !tbaa !29
  %t59 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t59, ptr %l45
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/names:Resolver", ptr %t61, i32 0, i32 7
  %t64 = load i64, ptr %t63, !tbaa !24
  %t65 = load i32, ptr %l3, !tbaa !23
  %t69 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeIn(ptr %v0, ptr %t60, i64 %t64, i32 %t65)
  store %"compiler/names:Ref" %t69, ptr %l50
  br label %bb16
bb16:
  %t70 = load ptr, ptr %l44, !tbaa !29
  %t71 = load %"compiler/source:Span", ptr %l45
  %t72 = load %"compiler/names:Ref", ptr %l50
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2erecord(ptr %v0, ptr %t70, %"compiler/source:Span" %t71, %"compiler/names:Ref" %t72)
  br label %bb17
bb17:
  br label %ret
bb18:
  %t73 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t73, ptr %l51, !tbaa !27
  %t74 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t75 = load ptr, ptr %t74, !tbaa !27
  %t76 = getelementptr i32, ptr %t75, i64 0
  %t77 = load i32, ptr %t76, !tbaa !33
  store i32 %t77, ptr %l5, !tbaa !23
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/names:Resolver", ptr %t79, i32 0, i32 1
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/names:Resolver", ptr %t82, i32 0, i32 7
  %t85 = load i64, ptr %t84, !tbaa !24
  %t88 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v0, ptr %t81, i64 %t85)
  store ptr %t88, ptr %l58
  br label %bb19
bb19:
  %t89 = load ptr, ptr %l58, !tbaa !29
  %t91 = getelementptr %"compiler/names:Table", ptr %t89, i32 0, i32 3
  %t92 = load i32, ptr %l5, !tbaa !23
  %t95 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %t91, i32 %t92)
  %t96 = extractvalue { i32, i64 } %t95, 1
  %t97 = extractvalue { i32, i64 } %t95, 0
  store i32 %t97, ptr %l63
  %t98 = icmp ne i32 %t97, 0
  br i1 %t98, label %bb21, label %ok.99, !prof !99
ok.99:
  store i64 %t96, ptr %l62
  br label %bb20
bb20:
  %t100 = load i64, ptr %l62, !tbaa !24
  store i64 %t100, ptr %l53, !tbaa !24
  br label %bb23
bb21:
  br label %bb22
bb22:
  store i64 -1, ptr %l53, !tbaa !24
  br label %bb23
bb23:
  %t101 = load i64, ptr %l53, !tbaa !24
  %t102 = icmp slt i64 %t101, 0
  br i1 %t102, label %bb24, label %bb25
bb24:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t105 = load i32, ptr %l5, !tbaa !23
  %t108 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2elookup(ptr %v0, ptr %t104, i32 %t105)
  store %"compiler/names:Ref" %t108, ptr %l67
  br label %bb26
bb25:
  br label %bb83
bb26:
  %t109 = load %"compiler/names:Ref", ptr %l67
  store %"compiler/names:Ref" %t109, ptr %l6
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr %"compiler/names:Resolver", ptr %t111, i32 0, i32 7
  %t114 = load i64, ptr %t113, !tbaa !24
  %t115 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t116 = load i32, ptr %t115, !tbaa !23
  %t117 = load i32, ptr %l5, !tbaa !23
  %t122 = call %"compiler/source:Span" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2enameSpan(ptr %v0, ptr %t110, i64 %t114, i32 %t116, i32 %t117)
  store %"compiler/source:Span" %t122, ptr %l73
  br label %bb27
bb27:
  %t123 = load %"compiler/source:Span", ptr %l73
  store %"compiler/source:Span" %t123, ptr %l7
  %t124 = getelementptr %"compiler/names:Ref", ptr %l6, i32 0, i32 0
  %t125 = load i32, ptr %t124, !range !{i32 0, i32 9}
  %t127 = trunc i64 0 to i32
  %t128 = icmp eq i32 %t125, %t127
  br i1 %t128, label %bb28, label %bb29
bb28:
  store %olang.scope zeroinitializer, ptr %s4
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr %"compiler/names:Resolver", ptr %t130, i32 0, i32 16
  %t134 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fsource__H04f1a4a88576bd1070c12151a5c28d38(ptr %v0, ptr %t132)
  store i64 %t134, ptr %l78
  br label %bb30
bb29:
  br label %bb72
bb30:
  %t135 = load i64, ptr %l78, !tbaa !24
  store i64 %t135, ptr %l8, !tbaa !24
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t137 = load %"compiler/source:Span", ptr %l7
  %t138 = load i32, ptr %l5, !tbaa !23
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eunknownHead(ptr %v0, ptr %t136, %"compiler/source:Span" %t137, i32 %t138)
  br label %bb31
bb31:
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t144 = getelementptr %"compiler/names:Resolver", ptr %t142, i32 0, i32 16
  %t146 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fsource__H04f1a4a88576bd1070c12151a5c28d38(ptr %v0, ptr %t144)
  store i64 %t146, ptr %l84
  br label %bb32
bb32:
  %t147 = load i64, ptr %l8, !tbaa !24
  %t148 = load i64, ptr %l84, !tbaa !24
  %t150 = icmp eq i64 %t148, %t147
  br i1 %t150, label %bb33, label %bb34
bb33:
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t154 = getelementptr %"compiler/names:Resolver", ptr %t152, i32 0, i32 0
  %t155 = load ptr, ptr %t154, !tbaa !29
  %t157 = getelementptr %"compiler/load:Loader", ptr %t155, i32 0, i32 0
  %t158 = load { i64, ptr }, ptr %t157, !tbaa !27
  store { i64, ptr } %t158, ptr %l90, !tbaa !27
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t160 = load i32, ptr %l5, !tbaa !23
  %t163 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %s4, ptr %t159, i32 %t160)
  store { i64, ptr } %t163, ptr %l93
  br label %bb35
bb34:
  store i1 false, ptr %l87, !tbaa !21
  br label %bb37
bb35:
  %t164 = load { i64, ptr }, ptr %l90, !tbaa !27
  %t165 = extractvalue { i64, ptr } %t164, 1
  %t166 = extractvalue { i64, ptr } %t164, 0
  %t167 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d31, i32 0, i32 1) }, 1
  %t168 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d31, i32 0, i32 1) }, 0
  %t169 = add i64 %t166, %t168
  %t170 = load { i64, ptr }, ptr %l93, !tbaa !27
  %t171 = extractvalue { i64, ptr } %t170, 1
  %t172 = extractvalue { i64, ptr } %t170, 0
  %t173 = add i64 %t169, %t172
  %t174 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d32, i32 0, i32 1) }, 1
  %t175 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d32, i32 0, i32 1) }, 0
  %t176 = add i64 %t173, %t175
  %t177 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t176)
  call void @olang_textcopy(ptr %t177, ptr %t165, i64 %t166)
  %t178 = getelementptr i8, ptr %t177, i64 %t166
  call void @olang_textcopy(ptr %t178, ptr %t167, i64 %t168)
  %t179 = getelementptr i8, ptr %t178, i64 %t168
  call void @olang_textcopy(ptr %t179, ptr %t171, i64 %t172)
  %t180 = getelementptr i8, ptr %t179, i64 %t172
  call void @olang_textcopy(ptr %t180, ptr %t174, i64 %t175)
  %t181 = insertvalue { i64, ptr } undef, i64 %t176, 0
  %t182 = insertvalue { i64, ptr } %t181, ptr %t177, 1
  %t185 = call i1 @std_2fos_2eExists(ptr %s4, { i64, ptr } %t182)
  store i1 %t185, ptr %l96
  br label %bb36
bb36:
  %t186 = load i1, ptr %l96, !tbaa !21
  %t187 = xor i1 %t186, true
  store i1 %t187, ptr %l87, !tbaa !21
  br label %bb37
bb37:
  %t189 = load i1, ptr %l87, !tbaa !21
  br i1 %t189, label %bb38, label %bb39
bb38:
  %t190 = load i32, ptr %l5, !tbaa !23
  store i32 %t190, ptr %l9, !tbaa !23
  %t192 = load ptr, ptr %l0, !tbaa !29
  %t194 = getelementptr %"compiler/names:Resolver", ptr %t192, i32 0, i32 1
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t197 = getelementptr %"compiler/names:Resolver", ptr %t195, i32 0, i32 7
  %t198 = load i64, ptr %t197, !tbaa !24
  %t201 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v0, ptr %t194, i64 %t198)
  store ptr %t201, ptr %l104
  br label %bb40
bb39:
  store i1 false, ptr %l98, !tbaa !21
  br label %bb42
bb40:
  %t202 = load ptr, ptr %l104, !tbaa !29
  %t204 = getelementptr %"compiler/names:Table", ptr %t202, i32 0, i32 4
  %t205 = load i32, ptr %l9, !tbaa !23
  %t208 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H8da9376267bda3f76393292be0e507b2(ptr %v0, ptr %t204, i32 %t205)
  store i1 %t208, ptr %l108
  br label %bb41
bb41:
  %t209 = load i1, ptr %l108, !tbaa !21
  %t210 = xor i1 %t209, true
  store i1 %t210, ptr %l98, !tbaa !21
  br label %bb42
bb42:
  %t212 = load i1, ptr %l98, !tbaa !21
  br i1 %t212, label %bb43, label %bb44
bb43:
  %t213 = load ptr, ptr %l0, !tbaa !29
  %t214 = load i32, ptr %l5, !tbaa !23
  %t217 = call i1 @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eImportSaid(ptr %v0, ptr %t213, i32 %t214)
  store i1 %t217, ptr %l113
  br label %bb45
bb44:
  store i1 false, ptr %l110, !tbaa !21
  br label %bb46
bb45:
  %t218 = load i1, ptr %l113, !tbaa !21
  %t219 = xor i1 %t218, true
  store i1 %t219, ptr %l110, !tbaa !21
  br label %bb46
bb46:
  %t221 = load i1, ptr %l110, !tbaa !21
  br i1 %t221, label %bb47, label %bb48
bb47:
  store %olang.scope zeroinitializer, ptr %s6
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t224 = getelementptr %"compiler/names:Resolver", ptr %t222, i32 0, i32 16
  store ptr %t224, ptr %l116, !tbaa !29
  %t225 = load i32, ptr %l5, !tbaa !23
  %t227 = call %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" @std_2fpair_3aPair_3ccompiler_2fsource_3aNameId_2c_20I64_3e_2ector(ptr %s6, i32 %t225, i64 -1)
  store %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" %t227, ptr %l118
  br label %bb49
bb48:
  br label %bb71
bb49:
  %t228 = load ptr, ptr %l116, !tbaa !29
  %t229 = load %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed", ptr %l118
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fsource__H6d3eea1e3a905a651c612011755d5d17(ptr %v0, ptr %t228, %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" %t229)
  br label %bb50
bb50:
  %t230 = load ptr, ptr %l0, !tbaa !29
  %t231 = load i32, ptr %l5, !tbaa !23
  %t234 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %v0, ptr %t230, i32 %t231)
  store { i64, ptr } %t234, ptr %l121
  br label %bb51
bb51:
  %t235 = load { i64, ptr }, ptr %l121, !tbaa !27
  %t236 = call %"compiler/msgs:Nearest" @compiler_2fmsgs_3aNearest_2ector(ptr %v0, ptr %s6, { i64, ptr } %t235)
  store %"compiler/msgs:Nearest" %t236, ptr %l122
  br label %bb52
bb52:
  %t237 = load %"compiler/msgs:Nearest", ptr %l122
  %t238 = call ptr @__olang_scope_alloc_a(ptr %s6, i64 40, i64 8)
  store %"compiler/msgs:Nearest" %t237, ptr %t238
  store ptr %t238, ptr %l10, !tbaa !29
  %t240 = load ptr, ptr %l0, !tbaa !29
  %t242 = getelementptr %"compiler/names:Resolver", ptr %t240, i32 0, i32 0
  %t243 = load ptr, ptr %t242, !tbaa !29
  %t245 = getelementptr %"compiler/load:Loader", ptr %t243, i32 0, i32 10
  %t246 = load ptr, ptr %l0, !tbaa !29
  %t248 = getelementptr %"compiler/names:Resolver", ptr %t246, i32 0, i32 7
  %t249 = load i64, ptr %t248, !tbaa !24
  %t252 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t245, i64 %t249)
  store ptr %t252, ptr %l129
  br label %bb53
bb53:
  %t253 = load ptr, ptr %l129, !tbaa !29
  %t255 = getelementptr %"compiler/load:Module", ptr %t253, i32 0, i32 11
  store ptr %t255, ptr %l11, !tbaa !29
  store i64 0, ptr %l12, !tbaa !24
  br label %bb54
bb54:
  %t257 = load i64, ptr %l12, !tbaa !24
  store i64 %t257, ptr %l132, !tbaa !24
  %t258 = load ptr, ptr %l11, !tbaa !29
  %t260 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fload_3aImport_3e_2eLen_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %t258)
  store i64 %t260, ptr %l134
  br label %bb55
bb55:
  %t261 = load i64, ptr %l132, !tbaa !24
  %t262 = load i64, ptr %l134, !tbaa !24
  %t263 = icmp slt i64 %t261, %t262
  %t265 = xor i1 %t263, true
  br i1 %t265, label %bb56, label %bb57
bb56:
  br label %bb65
bb57:
  br label %bb58
bb58:
  %t267 = load ptr, ptr %l11, !tbaa !29
  %t268 = load i64, ptr %l12, !tbaa !24
  %t271 = call %"compiler/load:Import" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fload_3aImport_3e_2eAt_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %v0, ptr %t267, i64 %t268)
  store %"compiler/load:Import" %t271, ptr %l139
  br label %bb59
bb59:
  %t272 = load %"compiler/load:Import", ptr %l139
  store %"compiler/load:Import" %t272, ptr %l13
  %t273 = getelementptr %"compiler/load:Import", ptr %l13, i32 0, i32 5
  %t274 = load i64, ptr %t273, !tbaa !24
  %t276 = icmp sge i64 %t274, 0
  br i1 %t276, label %bb60, label %bb61
bb60:
  %t278 = load ptr, ptr %l10, !tbaa !29
  %t279 = getelementptr %"compiler/load:Import", ptr %l13, i32 0, i32 2
  %t280 = load { i64, ptr }, ptr %t279, !tbaa !27
  call void @compiler_2fmsgs_2ecompiler_2fmsgs_3aNearest_2eOffer(ptr %s6, ptr %v0, ptr %t278, { i64, ptr } %t280)
  br label %bb62
bb61:
  br label %bb63
bb62:
  br label %bb63
bb63:
  br label %bb64
bb64:
  %t283 = load i64, ptr %l12, !tbaa !24
  %t286 = add i64 %t283, 1
  store i64 %t286, ptr %l12, !tbaa !24
  br label %bb54
bb65:
  %t288 = load ptr, ptr %l0, !tbaa !29
  %t290 = getelementptr %"compiler/names:Resolver", ptr %t288, i32 0, i32 0
  %t291 = load ptr, ptr %t290, !tbaa !29
  %t293 = getelementptr %"compiler/load:Loader", ptr %t291, i32 0, i32 4
  %t294 = load ptr, ptr %t293, !tbaa !29
  store ptr %t294, ptr %l149, !tbaa !29
  %t295 = load ptr, ptr %l0, !tbaa !29
  %t296 = load ptr, ptr %l0, !tbaa !29
  %t298 = getelementptr %"compiler/names:Resolver", ptr %t296, i32 0, i32 7
  %t299 = load i64, ptr %t298, !tbaa !24
  %t300 = load %"compiler/source:Span", ptr %l7
  %t304 = call { i64, [3 x i64] } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eat(ptr %v0, ptr %t295, i64 %t299, %"compiler/source:Span" %t300)
  store { i64, [3 x i64] } %t304, ptr %l154
  br label %bb66
bb66:
  %t305 = load ptr, ptr %l0, !tbaa !29
  %t306 = load i32, ptr %l5, !tbaa !23
  %t309 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etok(ptr %v0, ptr %s6, ptr %t305, i32 %t306)
  store { i64, ptr } %t309, ptr %l157
  br label %bb67
bb67:
  %t310 = load { i64, ptr }, ptr %l157, !tbaa !27
  store { i64, ptr } %t310, ptr %l158, !tbaa !27
  %t311 = load ptr, ptr %l10, !tbaa !29
  %t313 = call { i64, ptr } @compiler_2fmsgs_2ecompiler_2fmsgs_3aNearest_2eHint(ptr %s6, ptr %s6, ptr %t311)
  store { i64, ptr } %t313, ptr %l160
  br label %bb68
bb68:
  %t314 = load { i64, ptr }, ptr %l160, !tbaa !27
  %t315 = load { i64, ptr }, ptr %l158, !tbaa !27
  %t317 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eUnknownImport(ptr %s6, ptr %s6, ptr %v0, { i64, ptr } %t315, { i64, ptr } %t314)
  store %"compiler/diagmsg:Msg" %t317, ptr %l162
  br label %bb69
bb69:
  %t318 = load ptr, ptr %l149, !tbaa !29
  %t319 = load { i64, [3 x i64] }, ptr %l154
  %t320 = load %"compiler/diagmsg:Msg", ptr %l162
  %t321 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v0, ptr %t318, { i64, [3 x i64] } %t319, %"compiler/diagmsg:Msg" %t320)
  store i64 %t321, ptr %l163
  br label %bb70
bb70:
  call void @__olang_scope_close(ptr %s6)
  br label %bb71
bb71:
  call void @__olang_scope_close(ptr %s4)
  br label %ret
bb72:
  %t322 = load ptr, ptr %l0, !tbaa !29
  %t323 = load %"compiler/names:Ref", ptr %l6
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eread(ptr %v0, ptr %t322, %"compiler/names:Ref" %t323)
  br label %bb73
bb73:
  %t326 = getelementptr %"compiler/names:Ref", ptr %l6, i32 0, i32 0
  %t327 = load i32, ptr %t326, !range !{i32 0, i32 9}
  %t329 = trunc i64 4 to i32
  %t330 = icmp eq i32 %t327, %t329
  br i1 %t330, label %bb74, label %bb75
bb74:
  store i1 true, ptr %l168, !tbaa !21
  br label %bb76
bb75:
  %t332 = getelementptr %"compiler/names:Ref", ptr %l6, i32 0, i32 0
  %t333 = load i32, ptr %t332, !range !{i32 0, i32 9}
  %t335 = trunc i64 7 to i32
  %t336 = icmp eq i32 %t333, %t335
  store i1 %t336, ptr %l168, !tbaa !21
  br label %bb76
bb76:
  %t338 = load i1, ptr %l168, !tbaa !21
  br i1 %t338, label %bb77, label %bb78
bb77:
  %t339 = load ptr, ptr %l0, !tbaa !29
  %t341 = getelementptr %"compiler/names:Resolver", ptr %t339, i32 0, i32 5
  store ptr %t341, ptr %l172, !tbaa !29
  %t342 = load ptr, ptr %l0, !tbaa !29
  %t344 = getelementptr %"compiler/names:Resolver", ptr %t342, i32 0, i32 0
  %t345 = load ptr, ptr %t344, !tbaa !29
  %t347 = getelementptr %"compiler/load:Loader", ptr %t345, i32 0, i32 10
  %t348 = load ptr, ptr %l0, !tbaa !29
  %t350 = getelementptr %"compiler/names:Resolver", ptr %t348, i32 0, i32 7
  %t351 = load i64, ptr %t350, !tbaa !24
  %t354 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t347, i64 %t351)
  store ptr %t354, ptr %l178
  br label %bb79
bb78:
  br label %bb82
bb79:
  %t355 = load ptr, ptr %l178, !tbaa !29
  %t357 = getelementptr %"compiler/load:Module", ptr %t355, i32 0, i32 4
  %t358 = load i64, ptr %t357, !tbaa !24
  %t359 = getelementptr %"compiler/source:Span", ptr %l7, i32 0, i32 1
  %t360 = load i32, ptr %t359, !tbaa !23
  %t363 = call i64 @compiler_2fnames_2ekey(i64 %t358, i32 %t360)
  store i64 %t363, ptr %l182
  br label %bb80
bb80:
  %t364 = load %"compiler/names:Ref", ptr %l6
  %t365 = load ptr, ptr %l172, !tbaa !29
  %t366 = load i64, ptr %l182, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fnames_3aRef_3e_2eP_Hb17c37756f956998a4fa74bcac088344(ptr %v0, ptr %t365, i64 %t366, %"compiler/names:Ref" %t364)
  br label %bb81
bb81:
  br label %bb82
bb82:
  br label %ret
bb83:
  %t368 = load ptr, ptr %l0, !tbaa !29
  %t369 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t372 = call i64 @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ealiasModule(ptr %v0, ptr %v1, ptr %t368, { i64, ptr } %t369)
  store i64 %t372, ptr %l186
  br label %bb84
bb84:
  %t373 = load i64, ptr %l186, !tbaa !24
  store i64 %t373, ptr %l14, !tbaa !24
  %t374 = load i64, ptr %l14, !tbaa !24
  %t376 = icmp sge i64 %t374, 0
  br i1 %t376, label %bb85, label %bb86
bb85:
  store %olang.scope zeroinitializer, ptr %s12
  %t378 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t378, ptr %l189, !tbaa !27
  %t379 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t381 = extractvalue { i64, ptr } %t379, 0
  %t383 = sub i64 %t381, 1
  %t385 = getelementptr { i64, ptr }, ptr %l189, i32 0, i32 1
  %t386 = load ptr, ptr %t385, !tbaa !27
  %t387 = getelementptr i32, ptr %t386, i64 %t383
  %t388 = load i32, ptr %t387, !tbaa !33
  store i32 %t388, ptr %l15, !tbaa !23
  %t390 = load ptr, ptr %l0, !tbaa !29
  %t391 = load i64, ptr %l14, !tbaa !24
  %t392 = load i32, ptr %l15, !tbaa !23
  %t396 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ememberOf(ptr %v0, ptr %t390, i64 %t391, i32 %t392)
  store %"compiler/names:Ref" %t396, ptr %l197
  br label %bb87
bb86:
  br label %bb101
bb87:
  %t397 = load %"compiler/names:Ref", ptr %l197
  store %"compiler/names:Ref" %t397, ptr %l16
  %t398 = load ptr, ptr %l0, !tbaa !29
  store ptr %t398, ptr %l198, !tbaa !29
  %t399 = load i64, ptr %l14, !tbaa !24
  store i64 %t399, ptr %l199, !tbaa !24
  %t400 = load %"compiler/names:Ref", ptr %l16
  store %"compiler/names:Ref" %t400, ptr %l200
  %t401 = load i32, ptr %l15, !tbaa !23
  store i32 %t401, ptr %l201, !tbaa !23
  %t402 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t403 = load i32, ptr %t402, !tbaa !23
  store i32 %t403, ptr %l202, !tbaa !23
  %t404 = load ptr, ptr %l0, !tbaa !29
  %t405 = load i32, ptr %l15, !tbaa !23
  %t408 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %s12, ptr %t404, i32 %t405)
  store { i64, ptr } %t408, ptr %l205
  br label %bb88
bb88:
  %t409 = load { i64, ptr }, ptr %l205, !tbaa !27
  %t410 = extractvalue { i64, ptr } %t409, 0
  %t412 = trunc i64 %t410 to i32
  %t413 = load i32, ptr %l202, !tbaa !23
  %t415 = sub i32 %t413, %t412
  %t416 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t417 = load i32, ptr %t416, !tbaa !23
  %t420 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s12, i32 %t415, i32 %t417)
  store %"compiler/source:Span" %t420, ptr %l210
  br label %bb89
bb89:
  %t421 = load ptr, ptr %l198, !tbaa !29
  %t422 = load i64, ptr %l199, !tbaa !24
  %t423 = load %"compiler/names:Ref", ptr %l200
  %t424 = load i32, ptr %l201, !tbaa !23
  %t425 = load %"compiler/source:Span", ptr %l210
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2enotPrivate(ptr %v0, ptr %t421, i64 %t422, %"compiler/names:Ref" %t423, i32 %t424, %"compiler/source:Span" %t425)
  br label %bb90
bb90:
  %t426 = getelementptr %"compiler/names:Ref", ptr %l16, i32 0, i32 0
  %t427 = load i32, ptr %t426, !range !{i32 0, i32 9}
  %t429 = trunc i64 0 to i32
  %t430 = icmp eq i32 %t427, %t429
  br i1 %t430, label %bb91, label %bb92
bb91:
  %t432 = load ptr, ptr %l0, !tbaa !29
  %t434 = getelementptr %"compiler/names:Resolver", ptr %t432, i32 0, i32 23
  %t435 = load i1, ptr %t434, !tbaa !21
  %t437 = xor i1 %t435, true
  store i1 %t437, ptr %l213, !tbaa !21
  br label %bb93
bb92:
  store i1 false, ptr %l213, !tbaa !21
  br label %bb93
bb93:
  %t439 = load i1, ptr %l213, !tbaa !21
  br i1 %t439, label %bb94, label %bb95
bb94:
  %t440 = load ptr, ptr %l0, !tbaa !29
  %t442 = getelementptr %"compiler/names:Resolver", ptr %t440, i32 0, i32 6
  store ptr %t442, ptr %l218, !tbaa !29
  %t443 = load ptr, ptr %l0, !tbaa !29
  %t445 = getelementptr %"compiler/names:Resolver", ptr %t443, i32 0, i32 0
  %t446 = load ptr, ptr %t445, !tbaa !29
  %t448 = getelementptr %"compiler/load:Loader", ptr %t446, i32 0, i32 10
  %t449 = load ptr, ptr %l0, !tbaa !29
  %t451 = getelementptr %"compiler/names:Resolver", ptr %t449, i32 0, i32 7
  %t452 = load i64, ptr %t451, !tbaa !24
  %t455 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t448, i64 %t452)
  store ptr %t455, ptr %l224
  br label %bb96
bb95:
  br label %bb99
bb96:
  %t456 = load ptr, ptr %l224, !tbaa !29
  %t458 = getelementptr %"compiler/load:Module", ptr %t456, i32 0, i32 4
  %t459 = load i64, ptr %t458, !tbaa !24
  %t460 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t461 = load i32, ptr %t460, !tbaa !23
  %t464 = call i64 @compiler_2fnames_2ekey(i64 %t459, i32 %t461)
  store i64 %t464, ptr %l228
  br label %bb97
bb97:
  %t465 = load i64, ptr %l14, !tbaa !24
  %t466 = load ptr, ptr %l218, !tbaa !29
  %t467 = load i64, ptr %l228, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t466, i64 %t467, i64 %t465)
  br label %bb98
bb98:
  br label %bb99
bb99:
  %t469 = load ptr, ptr %l0, !tbaa !29
  %t470 = load %"compiler/source:Span", ptr %l1
  %t471 = load %"compiler/names:Ref", ptr %l16
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2erecord(ptr %v0, ptr %t469, %"compiler/source:Span" %t470, %"compiler/names:Ref" %t471)
  br label %bb100
bb100:
  call void @__olang_scope_close(ptr %s12)
  br label %ret
bb101:
  %t475 = load ptr, ptr %l0, !tbaa !29
  %t476 = load %"compiler/source:Span", ptr %l1
  %t477 = load { i64, ptr }, ptr %l2, !tbaa !27
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ealiasedMember(ptr %v0, ptr %v1, ptr %t475, %"compiler/source:Span" %t476, { i64, ptr } %t477)
  br label %bb102
bb102:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeRef(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca i64
  %l26 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l28 = alloca i64
  %l29 = alloca i64
  %l31 = alloca { i64, ptr }
  %l32 = alloca i64
  %l33 = alloca i64
  %l35 = alloca ptr
  %l36 = alloca { i64, ptr }
  %l37 = alloca i64
  %l38 = alloca i64
  %l40 = alloca ptr
  %l41 = alloca ptr
  %l42 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l44 = alloca i64
  %l45 = alloca i64
  %l49 = alloca ptr
  %l50 = alloca i1
  %l69 = alloca { i64, ptr }
  %l78 = alloca ptr
  %l79 = alloca i1
  %l92 = alloca { i64, ptr }
  %l109 = alloca { i64, ptr }
  %l131 = alloca { i64, ptr }
  %l148 = alloca { i64, ptr }
  %l157 = alloca ptr
  %l158 = alloca i1
  %l161 = alloca i1
  %l163 = alloca ptr
  %l164 = alloca i1
  %l177 = alloca { i64, ptr }
  %l188 = alloca { i64, ptr }
  %l200 = alloca ptr
  %l201 = alloca i1
  %l204 = alloca i1
  %l206 = alloca ptr
  %l207 = alloca i1
  %l221 = alloca { i64, ptr }
  %l230 = alloca ptr
  %l231 = alloca i1
  %l234 = alloca ptr
  %l235 = alloca i1
  %l240 = alloca ptr
  %l241 = alloca i1
  %l248 = alloca ptr
  %l249 = alloca i1
  %l254 = alloca ptr
  %l255 = alloca i1
  %l263 = alloca ptr
  %l264 = alloca i1
  %l276 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %l49, !tbaa !29
  store i1 false, ptr %l50, !tbaa !21
  %t6 = load ptr, ptr %l49, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l49, !tbaa !29
  %t10 = load i64, ptr %t9, !range !{i64 0, i64 8}
  %t12 = icmp eq i64 %t10, 0
  store i1 %t12, ptr %l50, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l50, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr { i64, [5 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t16, i32 0, i32 0
  %t18 = load %"compiler/source:Span", ptr %t17
  store %"compiler/source:Span" %t18, ptr %l2
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t22 = getelementptr { i64, [5 x i64] }, ptr %t20, i32 0, i32 1
  %t23 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t22, i32 0, i32 1
  %t24 = load { i64, ptr }, ptr %t23
  store { i64, ptr } %t24, ptr %l3, !tbaa !27
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t28 = getelementptr { i64, [5 x i64] }, ptr %t26, i32 0, i32 1
  %t29 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t28, i32 0, i32 2
  %t30 = load { i64, ptr }, ptr %t29
  store { i64, ptr } %t30, ptr %l4, !tbaa !27
  br label %bb8
bb7:
  br label %bb17
bb8:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load %"compiler/source:Span", ptr %l2
  %t34 = load { i64, ptr }, ptr %l3, !tbaa !27
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypePath(ptr %v0, ptr %v1, ptr %t32, %"compiler/source:Span" %t33, { i64, ptr } %t34)
  br label %bb9
bb9:
  %t38 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t38, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t40 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t42 = extractvalue { i64, ptr } %t40, 0
  store i64 %t42, ptr %l7, !tbaa !24
  br label %bb10
bb10:
  %t44 = load i64, ptr %l6, !tbaa !24
  %t45 = load i64, ptr %l7, !tbaa !24
  %t48 = icmp slt i64 %t44, %t45
  %t50 = xor i1 %t48, true
  br i1 %t50, label %bb11, label %bb12
bb11:
  br label %bb16
bb12:
  br label %bb13
bb13:
  %t52 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t52, ptr %l69, !tbaa !27
  %t53 = load i64, ptr %l6, !tbaa !24
  %t55 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !27
  %t57 = getelementptr ptr, ptr %t56, i64 %t53
  %t58 = load ptr, ptr %t57, !tbaa !39
  %t60 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeRef(ptr %v0, ptr %v1, ptr %t60, ptr %t58)
  br label %bb14
bb14:
  br label %bb15
bb15:
  %t65 = load i64, ptr %l6, !tbaa !24
  %t68 = add i64 %t65, 1
  store i64 %t68, ptr %l6, !tbaa !24
  br label %bb10
bb16:
  br label %bb138
bb17:
  %t70 = load ptr, ptr %l1, !tbaa !29
  store ptr %t70, ptr %l78, !tbaa !29
  store i1 false, ptr %l79, !tbaa !21
  %t71 = load ptr, ptr %l78, !tbaa !29
  %t72 = icmp ne ptr %t71, null
  br i1 %t72, label %bb18, label %bb19
bb18:
  %t74 = load ptr, ptr %l78, !tbaa !29
  %t75 = load i64, ptr %t74, !range !{i64 0, i64 8}
  %t77 = icmp eq i64 %t75, 1
  store i1 %t77, ptr %l79, !tbaa !21
  br label %bb19
bb19:
  %t78 = load i1, ptr %l79, !tbaa !21
  br i1 %t78, label %bb20, label %bb21
bb20:
  %t79 = load ptr, ptr %l1, !tbaa !29
  %t81 = getelementptr { i64, [5 x i64] }, ptr %t79, i32 0, i32 1
  %t82 = getelementptr { %"compiler/source:Span", ptr }, ptr %t81, i32 0, i32 1
  %t83 = load ptr, ptr %t82
  store ptr %t83, ptr %l9, !tbaa !29
  br label %bb22
bb21:
  br label %bb54
bb22:
  %t85 = load ptr, ptr %l9, !tbaa !29
  %t87 = getelementptr %"compiler/ast:Sig", ptr %t85, i32 0, i32 0
  %t88 = load { i64, ptr }, ptr %t87, !tbaa !27
  store { i64, ptr } %t88, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t90 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t92 = extractvalue { i64, ptr } %t90, 0
  store i64 %t92, ptr %l12, !tbaa !24
  br label %bb23
bb23:
  %t94 = load i64, ptr %l11, !tbaa !24
  %t95 = load i64, ptr %l12, !tbaa !24
  %t98 = icmp slt i64 %t94, %t95
  %t100 = xor i1 %t98, true
  br i1 %t100, label %bb24, label %bb25
bb24:
  br label %bb29
bb25:
  br label %bb26
bb26:
  %t102 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t102, ptr %l92, !tbaa !27
  %t103 = load i64, ptr %l11, !tbaa !24
  %t105 = getelementptr { i64, ptr }, ptr %l92, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !27
  %t107 = getelementptr ptr, ptr %t106, i64 %t103
  %t108 = load ptr, ptr %t107, !tbaa !39
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr %"compiler/ast:Param", ptr %t108, i32 0, i32 2
  %t114 = load ptr, ptr %t113, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeRef(ptr %v0, ptr %v1, ptr %t110, ptr %t114)
  br label %bb27
bb27:
  br label %bb28
bb28:
  %t117 = load i64, ptr %l11, !tbaa !24
  %t120 = add i64 %t117, 1
  store i64 %t120, ptr %l11, !tbaa !24
  br label %bb23
bb29:
  %t122 = load ptr, ptr %l9, !tbaa !29
  %t124 = getelementptr %"compiler/ast:Sig", ptr %t122, i32 0, i32 0
  %t125 = load { i64, ptr }, ptr %t124, !tbaa !27
  store { i64, ptr } %t125, ptr %l14, !tbaa !27
  store i64 0, ptr %l15, !tbaa !24
  %t127 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t129 = extractvalue { i64, ptr } %t127, 0
  store i64 %t129, ptr %l16, !tbaa !24
  br label %bb30
bb30:
  %t131 = load i64, ptr %l15, !tbaa !24
  %t132 = load i64, ptr %l16, !tbaa !24
  %t135 = icmp slt i64 %t131, %t132
  %t137 = xor i1 %t135, true
  br i1 %t137, label %bb31, label %bb32
bb31:
  br label %bb39
bb32:
  br label %bb33
bb33:
  %t139 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t139, ptr %l109, !tbaa !27
  %t140 = load i64, ptr %l15, !tbaa !24
  %t142 = getelementptr { i64, ptr }, ptr %l109, i32 0, i32 1
  %t143 = load ptr, ptr %t142, !tbaa !27
  %t144 = getelementptr ptr, ptr %t143, i64 %t140
  %t145 = load ptr, ptr %t144, !tbaa !39
  store ptr %t145, ptr %l17, !tbaa !29
  %t147 = load ptr, ptr %l17, !tbaa !29
  %t149 = getelementptr %"compiler/ast:Param", ptr %t147, i32 0, i32 3
  %t150 = load ptr, ptr %t149, !tbaa !29
  %t152 = icmp eq ptr %t150, null
  %t154 = xor i1 %t152, true
  br i1 %t154, label %bb34, label %bb35
bb34:
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t157 = load ptr, ptr %l17, !tbaa !29
  %t159 = getelementptr %"compiler/ast:Param", ptr %t157, i32 0, i32 3
  %t160 = load ptr, ptr %t159, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t156, ptr %t160)
  br label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb37
bb37:
  br label %bb38
bb38:
  %t164 = load i64, ptr %l15, !tbaa !24
  %t167 = add i64 %t164, 1
  store i64 %t167, ptr %l15, !tbaa !24
  br label %bb30
bb39:
  %t169 = load ptr, ptr %l9, !tbaa !29
  %t171 = getelementptr %"compiler/ast:Sig", ptr %t169, i32 0, i32 1
  %t172 = load { i64, ptr }, ptr %t171, !tbaa !27
  store { i64, ptr } %t172, ptr %l18, !tbaa !27
  store i64 0, ptr %l19, !tbaa !24
  %t174 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t176 = extractvalue { i64, ptr } %t174, 0
  store i64 %t176, ptr %l20, !tbaa !24
  br label %bb40
bb40:
  %t178 = load i64, ptr %l19, !tbaa !24
  %t179 = load i64, ptr %l20, !tbaa !24
  %t182 = icmp slt i64 %t178, %t179
  %t184 = xor i1 %t182, true
  br i1 %t184, label %bb41, label %bb42
bb41:
  br label %bb46
bb42:
  br label %bb43
bb43:
  %t186 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t186, ptr %l131, !tbaa !27
  %t187 = load i64, ptr %l19, !tbaa !24
  %t189 = getelementptr { i64, ptr }, ptr %l131, i32 0, i32 1
  %t190 = load ptr, ptr %t189, !tbaa !27
  %t191 = getelementptr ptr, ptr %t190, i64 %t187
  %t192 = load ptr, ptr %t191, !tbaa !39
  %t194 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeRef(ptr %v0, ptr %v1, ptr %t194, ptr %t192)
  br label %bb44
bb44:
  br label %bb45
bb45:
  %t199 = load i64, ptr %l19, !tbaa !24
  %t202 = add i64 %t199, 1
  store i64 %t202, ptr %l19, !tbaa !24
  br label %bb40
bb46:
  %t204 = load ptr, ptr %l9, !tbaa !29
  %t206 = getelementptr %"compiler/ast:Sig", ptr %t204, i32 0, i32 3
  %t207 = load { i64, ptr }, ptr %t206, !tbaa !27
  store { i64, ptr } %t207, ptr %l22, !tbaa !27
  store i64 0, ptr %l23, !tbaa !24
  %t209 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t211 = extractvalue { i64, ptr } %t209, 0
  store i64 %t211, ptr %l24, !tbaa !24
  br label %bb47
bb47:
  %t213 = load i64, ptr %l23, !tbaa !24
  %t214 = load i64, ptr %l24, !tbaa !24
  %t217 = icmp slt i64 %t213, %t214
  %t219 = xor i1 %t217, true
  br i1 %t219, label %bb48, label %bb49
bb48:
  br label %bb53
bb49:
  br label %bb50
bb50:
  %t221 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t221, ptr %l148, !tbaa !27
  %t222 = load i64, ptr %l23, !tbaa !24
  %t224 = getelementptr { i64, ptr }, ptr %l148, i32 0, i32 1
  %t225 = load ptr, ptr %t224, !tbaa !27
  %t226 = getelementptr ptr, ptr %t225, i64 %t222
  %t227 = load ptr, ptr %t226, !tbaa !39
  %t229 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2epath(ptr %v0, ptr %v1, ptr %t229, ptr %t227)
  br label %bb51
bb51:
  br label %bb52
bb52:
  %t234 = load i64, ptr %l23, !tbaa !24
  %t237 = add i64 %t234, 1
  store i64 %t237, ptr %l23, !tbaa !24
  br label %bb47
bb53:
  br label %bb138
bb54:
  %t239 = load ptr, ptr %l1, !tbaa !29
  store ptr %t239, ptr %l157, !tbaa !29
  store i1 false, ptr %l158, !tbaa !21
  %t240 = load ptr, ptr %l157, !tbaa !29
  %t241 = icmp ne ptr %t240, null
  br i1 %t241, label %bb55, label %bb56
bb55:
  %t243 = load ptr, ptr %l157, !tbaa !29
  %t244 = load i64, ptr %t243, !range !{i64 0, i64 8}
  %t246 = icmp eq i64 %t244, 2
  store i1 %t246, ptr %l158, !tbaa !21
  br label %bb56
bb56:
  %t247 = load i1, ptr %l158, !tbaa !21
  br i1 %t247, label %bb57, label %bb58
bb57:
  %t248 = load ptr, ptr %l1, !tbaa !29
  %t250 = getelementptr { i64, [5 x i64] }, ptr %t248, i32 0, i32 1
  %t251 = getelementptr { %"compiler/source:Span", ptr }, ptr %t250, i32 0, i32 1
  %t252 = load ptr, ptr %t251
  store ptr %t252, ptr %l163, !tbaa !29
  store i1 false, ptr %l164, !tbaa !21
  %t253 = load ptr, ptr %l163, !tbaa !29
  %t254 = icmp ne ptr %t253, null
  br i1 %t254, label %bb59, label %bb60
bb58:
  store i1 false, ptr %l161, !tbaa !21
  br label %bb61
bb59:
  %t256 = load ptr, ptr %l163, !tbaa !29
  %t257 = load i64, ptr %t256, !range !{i64 0, i64 5}
  %t259 = icmp eq i64 %t257, 1
  store i1 %t259, ptr %l164, !tbaa !21
  br label %bb60
bb60:
  %t260 = load i1, ptr %l164, !tbaa !21
  store i1 %t260, ptr %l161, !tbaa !21
  br label %bb61
bb61:
  %t261 = load i1, ptr %l161, !tbaa !21
  br i1 %t261, label %bb62, label %bb63
bb62:
  %t262 = load ptr, ptr %l1, !tbaa !29
  %t264 = getelementptr { i64, [5 x i64] }, ptr %t262, i32 0, i32 1
  %t265 = getelementptr { %"compiler/source:Span", ptr }, ptr %t264, i32 0, i32 1
  %t266 = load ptr, ptr %t265
  %t268 = getelementptr { i64, [6 x i64] }, ptr %t266, i32 0, i32 1
  %t269 = getelementptr { { i64, ptr }, ptr }, ptr %t268, i32 0, i32 0
  %t270 = load { i64, ptr }, ptr %t269
  store { i64, ptr } %t270, ptr %l26, !tbaa !27
  br label %bb64
bb63:
  br label %bb78
bb64:
  %t272 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t272, ptr %l27, !tbaa !27
  store i64 0, ptr %l28, !tbaa !24
  %t274 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t276 = extractvalue { i64, ptr } %t274, 0
  store i64 %t276, ptr %l29, !tbaa !24
  br label %bb65
bb65:
  %t278 = load i64, ptr %l28, !tbaa !24
  %t279 = load i64, ptr %l29, !tbaa !24
  %t282 = icmp slt i64 %t278, %t279
  %t284 = xor i1 %t282, true
  br i1 %t284, label %bb66, label %bb67
bb66:
  br label %bb77
bb67:
  br label %bb68
bb68:
  %t286 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t286, ptr %l177, !tbaa !27
  %t287 = load i64, ptr %l28, !tbaa !24
  %t289 = getelementptr { i64, ptr }, ptr %l177, i32 0, i32 1
  %t290 = load ptr, ptr %t289, !tbaa !27
  %t291 = getelementptr ptr, ptr %t290, i64 %t287
  %t292 = load ptr, ptr %t291, !tbaa !39
  %t296 = getelementptr %"compiler/ast:CaseDecl", ptr %t292, i32 0, i32 2
  %t297 = load { i64, ptr }, ptr %t296, !tbaa !27
  store { i64, ptr } %t297, ptr %l31, !tbaa !27
  store i64 0, ptr %l32, !tbaa !24
  %t299 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t301 = extractvalue { i64, ptr } %t299, 0
  store i64 %t301, ptr %l33, !tbaa !24
  br label %bb69
bb69:
  %t303 = load i64, ptr %l32, !tbaa !24
  %t304 = load i64, ptr %l33, !tbaa !24
  %t307 = icmp slt i64 %t303, %t304
  %t309 = xor i1 %t307, true
  br i1 %t309, label %bb70, label %bb71
bb70:
  br label %bb75
bb71:
  br label %bb72
bb72:
  %t311 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t311, ptr %l188, !tbaa !27
  %t312 = load i64, ptr %l32, !tbaa !24
  %t314 = getelementptr { i64, ptr }, ptr %l188, i32 0, i32 1
  %t315 = load ptr, ptr %t314, !tbaa !27
  %t316 = getelementptr ptr, ptr %t315, i64 %t312
  %t317 = load ptr, ptr %t316, !tbaa !39
  %t319 = load ptr, ptr %l0, !tbaa !29
  %t322 = getelementptr %"compiler/ast:Param", ptr %t317, i32 0, i32 2
  %t323 = load ptr, ptr %t322, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeRef(ptr %v0, ptr %v1, ptr %t319, ptr %t323)
  br label %bb73
bb73:
  br label %bb74
bb74:
  %t326 = load i64, ptr %l32, !tbaa !24
  %t329 = add i64 %t326, 1
  store i64 %t329, ptr %l32, !tbaa !24
  br label %bb69
bb75:
  br label %bb76
bb76:
  %t331 = load i64, ptr %l28, !tbaa !24
  %t334 = add i64 %t331, 1
  store i64 %t334, ptr %l28, !tbaa !24
  br label %bb65
bb77:
  br label %bb138
bb78:
  %t336 = load ptr, ptr %l1, !tbaa !29
  store ptr %t336, ptr %l200, !tbaa !29
  store i1 false, ptr %l201, !tbaa !21
  %t337 = load ptr, ptr %l200, !tbaa !29
  %t338 = icmp ne ptr %t337, null
  br i1 %t338, label %bb79, label %bb80
bb79:
  %t340 = load ptr, ptr %l200, !tbaa !29
  %t341 = load i64, ptr %t340, !range !{i64 0, i64 8}
  %t343 = icmp eq i64 %t341, 2
  store i1 %t343, ptr %l201, !tbaa !21
  br label %bb80
bb80:
  %t344 = load i1, ptr %l201, !tbaa !21
  br i1 %t344, label %bb81, label %bb82
bb81:
  %t345 = load ptr, ptr %l1, !tbaa !29
  %t347 = getelementptr { i64, [5 x i64] }, ptr %t345, i32 0, i32 1
  %t348 = getelementptr { %"compiler/source:Span", ptr }, ptr %t347, i32 0, i32 1
  %t349 = load ptr, ptr %t348
  store ptr %t349, ptr %l206, !tbaa !29
  store i1 false, ptr %l207, !tbaa !21
  %t350 = load ptr, ptr %l206, !tbaa !29
  %t351 = icmp ne ptr %t350, null
  br i1 %t351, label %bb83, label %bb84
bb82:
  store i1 false, ptr %l204, !tbaa !21
  br label %bb85
bb83:
  %t353 = load ptr, ptr %l206, !tbaa !29
  %t354 = load i64, ptr %t353, !range !{i64 0, i64 5}
  %t356 = icmp eq i64 %t354, 0
  store i1 %t356, ptr %l207, !tbaa !21
  br label %bb84
bb84:
  %t357 = load i1, ptr %l207, !tbaa !21
  store i1 %t357, ptr %l204, !tbaa !21
  br label %bb85
bb85:
  %t358 = load i1, ptr %l204, !tbaa !21
  br i1 %t358, label %bb86, label %bb87
bb86:
  %t359 = load ptr, ptr %l1, !tbaa !29
  %t361 = getelementptr { i64, [5 x i64] }, ptr %t359, i32 0, i32 1
  %t362 = getelementptr { %"compiler/source:Span", ptr }, ptr %t361, i32 0, i32 1
  %t363 = load ptr, ptr %t362
  %t365 = getelementptr { i64, [6 x i64] }, ptr %t363, i32 0, i32 1
  %t366 = getelementptr { ptr }, ptr %t365, i32 0, i32 0
  %t367 = load ptr, ptr %t366
  store ptr %t367, ptr %l35, !tbaa !29
  br label %bb88
bb87:
  br label %bb96
bb88:
  %t369 = load ptr, ptr %l35, !tbaa !29
  %t371 = getelementptr %"compiler/ast:StructBody", ptr %t369, i32 0, i32 0
  %t372 = load { i64, ptr }, ptr %t371, !tbaa !27
  store { i64, ptr } %t372, ptr %l36, !tbaa !27
  store i64 0, ptr %l37, !tbaa !24
  %t374 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t376 = extractvalue { i64, ptr } %t374, 0
  store i64 %t376, ptr %l38, !tbaa !24
  br label %bb89
bb89:
  %t378 = load i64, ptr %l37, !tbaa !24
  %t379 = load i64, ptr %l38, !tbaa !24
  %t382 = icmp slt i64 %t378, %t379
  %t384 = xor i1 %t382, true
  br i1 %t384, label %bb90, label %bb91
bb90:
  br label %bb95
bb91:
  br label %bb92
bb92:
  %t386 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t386, ptr %l221, !tbaa !27
  %t387 = load i64, ptr %l37, !tbaa !24
  %t389 = getelementptr { i64, ptr }, ptr %l221, i32 0, i32 1
  %t390 = load ptr, ptr %t389, !tbaa !27
  %t391 = getelementptr ptr, ptr %t390, i64 %t387
  %t392 = load ptr, ptr %t391, !tbaa !39
  %t394 = load ptr, ptr %l0, !tbaa !29
  %t397 = getelementptr %"compiler/ast:Param", ptr %t392, i32 0, i32 2
  %t398 = load ptr, ptr %t397, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeRef(ptr %v0, ptr %v1, ptr %t394, ptr %t398)
  br label %bb93
bb93:
  br label %bb94
bb94:
  %t401 = load i64, ptr %l37, !tbaa !24
  %t404 = add i64 %t401, 1
  store i64 %t404, ptr %l37, !tbaa !24
  br label %bb89
bb95:
  br label %bb138
bb96:
  %t406 = load ptr, ptr %l1, !tbaa !29
  store ptr %t406, ptr %l230, !tbaa !29
  store i1 false, ptr %l231, !tbaa !21
  %t407 = load ptr, ptr %l230, !tbaa !29
  %t408 = icmp ne ptr %t407, null
  br i1 %t408, label %bb97, label %bb98
bb97:
  %t410 = load ptr, ptr %l230, !tbaa !29
  %t411 = load i64, ptr %t410, !range !{i64 0, i64 8}
  %t413 = icmp eq i64 %t411, 2
  store i1 %t413, ptr %l231, !tbaa !21
  br label %bb98
bb98:
  %t414 = load i1, ptr %l231, !tbaa !21
  br i1 %t414, label %bb99, label %bb100
bb99:
  br label %bb101
bb100:
  br label %bb102
bb101:
  br label %bb138
bb102:
  %t415 = load ptr, ptr %l1, !tbaa !29
  store ptr %t415, ptr %l234, !tbaa !29
  store i1 false, ptr %l235, !tbaa !21
  %t416 = load ptr, ptr %l234, !tbaa !29
  %t417 = icmp ne ptr %t416, null
  br i1 %t417, label %bb103, label %bb104
bb103:
  %t419 = load ptr, ptr %l234, !tbaa !29
  %t420 = load i64, ptr %t419, !range !{i64 0, i64 8}
  %t422 = icmp eq i64 %t420, 3
  store i1 %t422, ptr %l235, !tbaa !21
  br label %bb104
bb104:
  %t423 = load i1, ptr %l235, !tbaa !21
  br i1 %t423, label %bb105, label %bb106
bb105:
  %t424 = load ptr, ptr %l1, !tbaa !29
  %t426 = getelementptr { i64, [5 x i64] }, ptr %t424, i32 0, i32 1
  %t427 = getelementptr { %"compiler/source:Span", ptr, i1, i1 }, ptr %t426, i32 0, i32 1
  %t428 = load ptr, ptr %t427
  store ptr %t428, ptr %l40, !tbaa !29
  br label %bb111
bb106:
  %t430 = load ptr, ptr %l1, !tbaa !29
  store ptr %t430, ptr %l240, !tbaa !29
  store i1 false, ptr %l241, !tbaa !21
  %t431 = load ptr, ptr %l240, !tbaa !29
  %t432 = icmp ne ptr %t431, null
  br i1 %t432, label %bb107, label %bb108
bb107:
  %t434 = load ptr, ptr %l240, !tbaa !29
  %t435 = load i64, ptr %t434, !range !{i64 0, i64 8}
  %t437 = icmp eq i64 %t435, 4
  store i1 %t437, ptr %l241, !tbaa !21
  br label %bb108
bb108:
  %t438 = load i1, ptr %l241, !tbaa !21
  br i1 %t438, label %bb109, label %bb110
bb109:
  %t439 = load ptr, ptr %l1, !tbaa !29
  %t441 = getelementptr { i64, [5 x i64] }, ptr %t439, i32 0, i32 1
  %t442 = getelementptr { %"compiler/source:Span", ptr, i1 }, ptr %t441, i32 0, i32 1
  %t443 = load ptr, ptr %t442
  store ptr %t443, ptr %l40, !tbaa !29
  br label %bb111
bb110:
  br label %bb113
bb111:
  %t445 = load ptr, ptr %l0, !tbaa !29
  %t446 = load ptr, ptr %l40, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeRef(ptr %v0, ptr %v1, ptr %t445, ptr %t446)
  br label %bb112
bb112:
  br label %bb138
bb113:
  %t449 = load ptr, ptr %l1, !tbaa !29
  store ptr %t449, ptr %l248, !tbaa !29
  store i1 false, ptr %l249, !tbaa !21
  %t450 = load ptr, ptr %l248, !tbaa !29
  %t451 = icmp ne ptr %t450, null
  br i1 %t451, label %bb114, label %bb115
bb114:
  %t453 = load ptr, ptr %l248, !tbaa !29
  %t454 = load i64, ptr %t453, !range !{i64 0, i64 8}
  %t456 = icmp eq i64 %t454, 5
  store i1 %t456, ptr %l249, !tbaa !21
  br label %bb115
bb115:
  %t457 = load i1, ptr %l249, !tbaa !21
  br i1 %t457, label %bb116, label %bb117
bb116:
  %t458 = load ptr, ptr %l1, !tbaa !29
  %t460 = getelementptr { i64, [5 x i64] }, ptr %t458, i32 0, i32 1
  %t461 = getelementptr { %"compiler/source:Span", ptr }, ptr %t460, i32 0, i32 1
  %t462 = load ptr, ptr %t461
  store ptr %t462, ptr %l41, !tbaa !29
  br label %bb122
bb117:
  %t464 = load ptr, ptr %l1, !tbaa !29
  store ptr %t464, ptr %l254, !tbaa !29
  store i1 false, ptr %l255, !tbaa !21
  %t465 = load ptr, ptr %l254, !tbaa !29
  %t466 = icmp ne ptr %t465, null
  br i1 %t466, label %bb118, label %bb119
bb118:
  %t468 = load ptr, ptr %l254, !tbaa !29
  %t469 = load i64, ptr %t468, !range !{i64 0, i64 8}
  %t471 = icmp eq i64 %t469, 7
  store i1 %t471, ptr %l255, !tbaa !21
  br label %bb119
bb119:
  %t472 = load i1, ptr %l255, !tbaa !21
  br i1 %t472, label %bb120, label %bb121
bb120:
  %t473 = load ptr, ptr %l1, !tbaa !29
  %t475 = getelementptr { i64, [5 x i64] }, ptr %t473, i32 0, i32 1
  %t476 = getelementptr { %"compiler/source:Span", ptr }, ptr %t475, i32 0, i32 1
  %t477 = load ptr, ptr %t476
  store ptr %t477, ptr %l41, !tbaa !29
  br label %bb122
bb121:
  br label %bb124
bb122:
  %t479 = load ptr, ptr %l0, !tbaa !29
  %t480 = load ptr, ptr %l41, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeRef(ptr %v0, ptr %v1, ptr %t479, ptr %t480)
  br label %bb123
bb123:
  br label %bb138
bb124:
  %t484 = load ptr, ptr %l1, !tbaa !29
  store ptr %t484, ptr %l263, !tbaa !29
  store i1 false, ptr %l264, !tbaa !21
  %t485 = load ptr, ptr %l263, !tbaa !29
  %t486 = icmp ne ptr %t485, null
  br i1 %t486, label %bb125, label %bb126
bb125:
  %t488 = load ptr, ptr %l263, !tbaa !29
  %t489 = load i64, ptr %t488, !range !{i64 0, i64 8}
  %t491 = icmp eq i64 %t489, 6
  store i1 %t491, ptr %l264, !tbaa !21
  br label %bb126
bb126:
  %t492 = load i1, ptr %l264, !tbaa !21
  br i1 %t492, label %bb127, label %bb128
bb127:
  %t493 = load ptr, ptr %l1, !tbaa !29
  %t495 = getelementptr { i64, [5 x i64] }, ptr %t493, i32 0, i32 1
  %t496 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t495, i32 0, i32 1
  %t497 = load { i64, ptr }, ptr %t496
  store { i64, ptr } %t497, ptr %l42, !tbaa !27
  br label %bb129
bb128:
  br label %bb137
bb129:
  %t499 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t499, ptr %l43, !tbaa !27
  store i64 0, ptr %l44, !tbaa !24
  %t501 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t503 = extractvalue { i64, ptr } %t501, 0
  store i64 %t503, ptr %l45, !tbaa !24
  br label %bb130
bb130:
  %t505 = load i64, ptr %l44, !tbaa !24
  %t506 = load i64, ptr %l45, !tbaa !24
  %t509 = icmp slt i64 %t505, %t506
  %t511 = xor i1 %t509, true
  br i1 %t511, label %bb131, label %bb132
bb131:
  br label %bb136
bb132:
  br label %bb133
bb133:
  %t513 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t513, ptr %l276, !tbaa !27
  %t514 = load i64, ptr %l44, !tbaa !24
  %t516 = getelementptr { i64, ptr }, ptr %l276, i32 0, i32 1
  %t517 = load ptr, ptr %t516, !tbaa !27
  %t518 = getelementptr ptr, ptr %t517, i64 %t514
  %t519 = load ptr, ptr %t518, !tbaa !39
  %t521 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2epath(ptr %v0, ptr %v1, ptr %t521, ptr %t519)
  br label %bb134
bb134:
  br label %bb135
bb135:
  %t526 = load i64, ptr %l44, !tbaa !24
  %t529 = add i64 %t526, 1
  store i64 %t529, ptr %l44, !tbaa !24
  br label %bb130
bb136:
  br label %bb138
bb137:
  call void @__olang_check_failed(ptr @olang_loc_3ee91b253925870d_db61affc9a997151)
  unreachable
bb138:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eunknownInCond(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed"
  %l13 = alloca ptr
  %l17 = alloca i1
  %l20 = alloca { i64, ptr }
  %l23 = alloca i1
  %l24 = alloca i1
  %l27 = alloca i1
  %l30 = alloca i64
  %l32 = alloca i64
  %l37 = alloca %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed"
  %l41 = alloca i1
  %l50 = alloca ptr
  %l54 = alloca %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed"
  %l57 = alloca ptr
  %l62 = alloca { i64, [3 x i64] }
  %l65 = alloca { i64, ptr }
  %l68 = alloca %"compiler/diagmsg:Msg"
  %l69 = alloca i64
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l2, !tbaa !23
  store i32 %t1, ptr %l3, !tbaa !23
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/names:Resolver", ptr %t3, i32 0, i32 1
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/names:Resolver", ptr %t6, i32 0, i32 7
  %t9 = load i64, ptr %t8, !tbaa !24
  %t12 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v0, ptr %t5, i64 %t9)
  store ptr %t12, ptr %l13
  br label %bb1
bb1:
  %t13 = load ptr, ptr %l13, !tbaa !29
  %t15 = getelementptr %"compiler/names:Table", ptr %t13, i32 0, i32 4
  %t16 = load i32, ptr %l3, !tbaa !23
  %t19 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H8da9376267bda3f76393292be0e507b2(ptr %v0, ptr %t15, i32 %t16)
  store i1 %t19, ptr %l17
  br label %bb2
bb2:
  %t20 = load i1, ptr %l17, !tbaa !21
  br i1 %t20, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb4:
  br label %bb5
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load i32, ptr %l2, !tbaa !23
  %t25 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %v0, ptr %t21, i32 %t22)
  store { i64, ptr } %t25, ptr %l20
  br label %bb6
bb6:
  %t26 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t26, ptr %l4, !tbaa !27
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t31 = call i1 @compiler_2fnames_2ecompiler_2fnames_3aResolver_2esuggests(ptr %v0, ptr %v0, ptr %t27, { i64, ptr } %t28)
  store i1 %t31, ptr %l23
  br label %bb7
bb7:
  %t32 = load i1, ptr %l23, !tbaa !21
  br i1 %t32, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l24, !tbaa !21
  br label %bb11
bb9:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load i32, ptr %l2, !tbaa !23
  %t37 = call i1 @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eimportedType(ptr %v0, ptr %t33, i32 %t34)
  store i1 %t37, ptr %l27
  br label %bb10
bb10:
  %t38 = load i1, ptr %l27, !tbaa !21
  store i1 %t38, ptr %l24, !tbaa !21
  br label %bb11
bb11:
  %t39 = load i1, ptr %l24, !tbaa !21
  br i1 %t39, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb13:
  br label %bb14
bb14:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/names:Resolver", ptr %t40, i32 0, i32 16
  store ptr %t42, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb15
bb15:
  %t44 = load i64, ptr %l6, !tbaa !24
  store i64 %t44, ptr %l30, !tbaa !24
  %t45 = load ptr, ptr %l5, !tbaa !29
  %t47 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fsource__H04f1a4a88576bd1070c12151a5c28d38(ptr %v0, ptr %t45)
  store i64 %t47, ptr %l32
  br label %bb16
bb16:
  %t48 = load i64, ptr %l30, !tbaa !24
  %t49 = load i64, ptr %l32, !tbaa !24
  %t50 = icmp slt i64 %t48, %t49
  %t52 = xor i1 %t50, true
  br i1 %t52, label %bb17, label %bb18
bb17:
  br label %bb28
bb18:
  br label %bb19
bb19:
  %t54 = load ptr, ptr %l5, !tbaa !29
  %t55 = load i64, ptr %l6, !tbaa !24
  %t58 = call %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fsource__Hd32f6fdf378a1d4c0e47f8552643012d(ptr %v0, ptr %t54, i64 %t55)
  store %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" %t58, ptr %l37
  br label %bb20
bb20:
  %t59 = load %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed", ptr %l37
  store %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" %t59, ptr %l7
  %t60 = getelementptr %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed", ptr %l7, i32 0, i32 0
  %t61 = load i32, ptr %t60, !tbaa !23
  %t62 = load i32, ptr %l2, !tbaa !23
  %t65 = icmp eq i32 %t61, %t62
  br i1 %t65, label %bb21, label %bb22
bb21:
  %t67 = getelementptr %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed", ptr %l7, i32 0, i32 1
  %t68 = load i64, ptr %t67, !tbaa !24
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/names:Resolver", ptr %t69, i32 0, i32 15
  %t72 = load i64, ptr %t71, !tbaa !24
  %t75 = icmp eq i64 %t68, %t72
  store i1 %t75, ptr %l41, !tbaa !21
  br label %bb23
bb22:
  store i1 false, ptr %l41, !tbaa !21
  br label %bb23
bb23:
  %t77 = load i1, ptr %l41, !tbaa !21
  br i1 %t77, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb25:
  br label %bb26
bb26:
  br label %bb27
bb27:
  %t78 = load i64, ptr %l6, !tbaa !24
  %t81 = add i64 %t78, 1
  store i64 %t81, ptr %l6, !tbaa !24
  br label %bb15
bb28:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/names:Resolver", ptr %t83, i32 0, i32 16
  store ptr %t85, ptr %l50, !tbaa !29
  %t86 = load i32, ptr %l2, !tbaa !23
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/names:Resolver", ptr %t87, i32 0, i32 15
  %t90 = load i64, ptr %t89, !tbaa !24
  %t93 = call %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" @std_2fpair_3aPair_3ccompiler_2fsource_3aNameId_2c_20I64_3e_2ector(ptr %s0, i32 %t86, i64 %t90)
  store %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" %t93, ptr %l54
  br label %bb29
bb29:
  %t94 = load ptr, ptr %l50, !tbaa !29
  %t95 = load %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed", ptr %l54
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fsource__H6d3eea1e3a905a651c612011755d5d17(ptr %v0, ptr %t94, %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" %t95)
  br label %bb30
bb30:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/names:Resolver", ptr %t96, i32 0, i32 0
  %t99 = load ptr, ptr %t98, !tbaa !29
  %t101 = getelementptr %"compiler/load:Loader", ptr %t99, i32 0, i32 4
  %t102 = load ptr, ptr %t101, !tbaa !29
  store ptr %t102, ptr %l57, !tbaa !29
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = getelementptr %"compiler/names:Resolver", ptr %t104, i32 0, i32 7
  %t107 = load i64, ptr %t106, !tbaa !24
  %t112 = call { i64, [3 x i64] } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eat(ptr %v0, ptr %t103, i64 %t107, %"compiler/source:Span" %a1)
  store { i64, [3 x i64] } %t112, ptr %l62
  br label %bb31
bb31:
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t114 = load i32, ptr %l2, !tbaa !23
  %t117 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etok(ptr %v0, ptr %s0, ptr %t113, i32 %t114)
  store { i64, ptr } %t117, ptr %l65
  br label %bb32
bb32:
  %t118 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t119 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t122 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eUnknownBuildName(ptr %s0, ptr %v0, ptr %v0, { i64, ptr } %t118, { i64, ptr } %t119)
  store %"compiler/diagmsg:Msg" %t122, ptr %l68
  br label %bb33
bb33:
  %t123 = load ptr, ptr %l57, !tbaa !29
  %t124 = load { i64, [3 x i64] }, ptr %l62
  %t125 = load %"compiler/diagmsg:Msg", ptr %l68
  %t126 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v0, ptr %t123, { i64, [3 x i64] } %t124, %"compiler/diagmsg:Msg" %t125)
  store i64 %t126, ptr %l69
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eunusedImports(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca %"compiler/load:Import"
  %l6 = alloca i32
  %l7 = alloca i1
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca %"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba"
  %l15 = alloca ptr
  %l18 = alloca i1
  %l22 = alloca i1
  %l26 = alloca i1
  %l29 = alloca i64
  %l31 = alloca i64
  %l36 = alloca %"compiler/load:Import"
  %l39 = alloca i1
  %l41 = alloca i1
  %l42 = alloca i1
  %l44 = alloca i1
  %l49 = alloca i32
  %l51 = alloca ptr
  %l55 = alloca i64
  %l56 = alloca i1
  %l59 = alloca i64
  %l61 = alloca i64
  %l66 = alloca %"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba"
  %l70 = alloca i1
  %l80 = alloca i1
  %l85 = alloca i1
  %l86 = alloca ptr
  %l95 = alloca i1
  %l98 = alloca ptr
  %l102 = alloca { i64, [3 x i64] }
  %l105 = alloca { i64, ptr }
  %l108 = alloca %"compiler/diagmsg:Msg"
  %l109 = alloca i64
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/names:Resolver", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/load:Loader", ptr %t4, i32 0, i32 10
  %t7 = load i64, ptr %l1, !tbaa !24
  %t10 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t6, i64 %t7)
  store ptr %t10, ptr %l15
  br label %bb1
bb1:
  %t11 = load ptr, ptr %l15, !tbaa !29
  store ptr %t11, ptr %l2, !tbaa !29
  %t12 = load ptr, ptr %l2, !tbaa !29
  %t14 = getelementptr %"compiler/load:Module", ptr %t12, i32 0, i32 33
  %t15 = load i1, ptr %t14, !tbaa !21
  br i1 %t15, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb4
bb3:
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t19 = getelementptr %"compiler/load:Module", ptr %t17, i32 0, i32 6
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t22 = icmp eq ptr %t20, null
  store i1 %t22, ptr %l18, !tbaa !21
  br label %bb4
bb4:
  %t24 = load i1, ptr %l18, !tbaa !21
  br i1 %t24, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l22, !tbaa !21
  br label %bb8
bb6:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/names:Resolver", ptr %t25, i32 0, i32 22
  %t28 = load i64, ptr %l1, !tbaa !24
  %t31 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t27, i64 %t28)
  store i1 %t31, ptr %l26
  br label %bb7
bb7:
  %t32 = load i1, ptr %l26, !tbaa !21
  store i1 %t32, ptr %l22, !tbaa !21
  br label %bb8
bb8:
  %t33 = load i1, ptr %l22, !tbaa !21
  br i1 %t33, label %bb9, label %bb10
bb9:
  br label %ret
bb10:
  br label %bb11
bb11:
  %t34 = load ptr, ptr %l2, !tbaa !29
  %t36 = getelementptr %"compiler/load:Module", ptr %t34, i32 0, i32 11
  store ptr %t36, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s3
  %t38 = load i64, ptr %l4, !tbaa !24
  store i64 %t38, ptr %l29, !tbaa !24
  %t39 = load ptr, ptr %l3, !tbaa !29
  %t41 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fload_3aImport_3e_2eLen_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %t39)
  store i64 %t41, ptr %l31
  br label %bb13
bb13:
  %t42 = load i64, ptr %l29, !tbaa !24
  %t43 = load i64, ptr %l31, !tbaa !24
  %t44 = icmp slt i64 %t42, %t43
  %t46 = xor i1 %t44, true
  br i1 %t46, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s3)
  br label %bb68
bb15:
  br label %bb16
bb16:
  %t48 = load ptr, ptr %l3, !tbaa !29
  %t49 = load i64, ptr %l4, !tbaa !24
  %t52 = call %"compiler/load:Import" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fload_3aImport_3e_2eAt_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %v0, ptr %t48, i64 %t49)
  store %"compiler/load:Import" %t52, ptr %l36
  br label %bb17
bb17:
  %t53 = load %"compiler/load:Import", ptr %l36
  store %"compiler/load:Import" %t53, ptr %l5
  %t54 = getelementptr %"compiler/load:Import", ptr %l5, i32 0, i32 5
  %t55 = load i64, ptr %t54, !tbaa !24
  %t57 = icmp slt i64 %t55, 0
  br i1 %t57, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l39, !tbaa !21
  br label %bb21
bb19:
  %t59 = getelementptr %"compiler/load:Import", ptr %l5, i32 0, i32 2
  %t60 = load { i64, ptr }, ptr %t59, !tbaa !27
  %t62 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s3, { i64, ptr } %t60, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d33, i32 0, i32 1) })
  store i1 %t62, ptr %l41
  br label %bb20
bb20:
  %t63 = load i1, ptr %l41, !tbaa !21
  store i1 %t63, ptr %l39, !tbaa !21
  br label %bb21
bb21:
  %t64 = load i1, ptr %l39, !tbaa !21
  br i1 %t64, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l42, !tbaa !21
  br label %bb25
bb23:
  %t65 = getelementptr %"compiler/load:Import", ptr %l5, i32 0, i32 2
  %t66 = load { i64, ptr }, ptr %t65, !tbaa !27
  %t68 = call i1 @compiler_2fload_2ePublic(ptr %v0, { i64, ptr } %t66)
  store i1 %t68, ptr %l44
  br label %bb24
bb24:
  %t69 = load i1, ptr %l44, !tbaa !21
  store i1 %t69, ptr %l42, !tbaa !21
  br label %bb25
bb25:
  %t70 = load i1, ptr %l42, !tbaa !21
  br i1 %t70, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s3)
  br label %bb67
bb27:
  br label %bb28
bb28:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/names:Resolver", ptr %t71, i32 0, i32 0
  %t74 = load ptr, ptr %t73, !tbaa !29
  %t76 = getelementptr %"compiler/load:Loader", ptr %t74, i32 0, i32 3
  %t77 = load ptr, ptr %t76, !tbaa !29
  %t78 = getelementptr %"compiler/load:Import", ptr %l5, i32 0, i32 2
  %t79 = load { i64, ptr }, ptr %t78, !tbaa !27
  %t82 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v0, ptr %t77, { i64, ptr } %t79)
  store i32 %t82, ptr %l49
  br label %bb29
bb29:
  %t83 = load i32, ptr %l49, !tbaa !23
  store i32 %t83, ptr %l6, !tbaa !23
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/names:Resolver", ptr %t84, i32 0, i32 20
  store ptr %t86, ptr %l51, !tbaa !29
  %t87 = load i64, ptr %l1, !tbaa !24
  %t88 = load i32, ptr %l6, !tbaa !23
  %t92 = call i64 @compiler_2fnames_2ekey(i64 %t87, i32 %t88)
  store i64 %t92, ptr %l55
  br label %bb30
bb30:
  %t93 = load ptr, ptr %l51, !tbaa !29
  %t94 = load i64, ptr %l55, !tbaa !24
  %t95 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t93, i64 %t94)
  store i1 %t95, ptr %l56
  br label %bb31
bb31:
  %t96 = load i1, ptr %l56, !tbaa !21
  br i1 %t96, label %bb32, label %bb33
bb32:
  call void @__olang_scope_close(ptr %s3)
  br label %bb67
bb33:
  br label %bb34
bb34:
  store i1 false, ptr %l7, !tbaa !21
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/names:Resolver", ptr %t97, i32 0, i32 21
  store ptr %t99, ptr %l8, !tbaa !29
  store i64 0, ptr %l9, !tbaa !24
  br label %bb35
bb35:
  %t101 = load i64, ptr %l9, !tbaa !24
  store i64 %t101, ptr %l59, !tbaa !24
  %t102 = load ptr, ptr %l8, !tbaa !29
  %t104 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20compiler__H5ec116bb82f5a234bb19cb32db1efc81(ptr %v0, ptr %t102)
  store i64 %t104, ptr %l61
  br label %bb36
bb36:
  %t105 = load i64, ptr %l59, !tbaa !24
  %t106 = load i64, ptr %l61, !tbaa !24
  %t107 = icmp slt i64 %t105, %t106
  %t109 = xor i1 %t107, true
  br i1 %t109, label %bb37, label %bb38
bb37:
  br label %bb52
bb38:
  br label %bb39
bb39:
  %t111 = load ptr, ptr %l8, !tbaa !29
  %t112 = load i64, ptr %l9, !tbaa !24
  %t115 = call %"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20compiler__H1a77801a5ab3ea58cbf0ff15b43ff2de(ptr %v0, ptr %t111, i64 %t112)
  store %"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba" %t115, ptr %l66
  br label %bb40
bb40:
  %t116 = load %"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba", ptr %l66
  store %"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba" %t116, ptr %l10
  %t117 = getelementptr %"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba", ptr %l10, i32 0, i32 0
  %t118 = load i64, ptr %t117, !tbaa !24
  %t119 = load i64, ptr %l1, !tbaa !24
  %t122 = icmp eq i64 %t118, %t119
  br i1 %t122, label %bb41, label %bb42
bb41:
  %t124 = load ptr, ptr %l2, !tbaa !29
  %t126 = getelementptr %"compiler/load:Module", ptr %t124, i32 0, i32 6
  %t127 = load ptr, ptr %t126, !tbaa !29
  %t129 = icmp eq ptr %t127, null
  br i1 %t129, label %bb43, label %bb44
bb42:
  store i1 false, ptr %l70, !tbaa !21
  br label %bb47
bb43:
  call void @__olang_check_failed(ptr @olang_loc_9053a89eb2ebe36f_9971388257a6393)
  unreachable
bb44:
  br label %bb45
bb45:
  %t131 = load ptr, ptr %l2, !tbaa !29
  %t133 = getelementptr %"compiler/load:Module", ptr %t131, i32 0, i32 6
  %t134 = load ptr, ptr %t133, !tbaa !29
  %t137 = getelementptr %"compiler/source:Source", ptr %t134, i32 0, i32 1
  %t138 = load { i64, ptr }, ptr %t137, !tbaa !27
  %t139 = getelementptr %"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba", ptr %l10, i32 0, i32 1
  %t140 = load %"compiler/source:Span", ptr %t139
  %t141 = getelementptr %"compiler/load:Import", ptr %l5, i32 0, i32 2
  %t142 = load { i64, ptr }, ptr %t141, !tbaa !27
  %t146 = call i1 @compiler_2fnames_2eMentions(ptr %v0, ptr %v0, { i64, ptr } %t138, %"compiler/source:Span" %t140, { i64, ptr } %t142)
  store i1 %t146, ptr %l80
  br label %bb46
bb46:
  %t147 = load i1, ptr %l80, !tbaa !21
  store i1 %t147, ptr %l70, !tbaa !21
  br label %bb47
bb47:
  %t148 = load i1, ptr %l70, !tbaa !21
  br i1 %t148, label %bb48, label %bb49
bb48:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb50
bb49:
  br label %bb50
bb50:
  br label %bb51
bb51:
  %t149 = load i64, ptr %l9, !tbaa !24
  %t152 = add i64 %t149, 1
  store i64 %t152, ptr %l9, !tbaa !24
  br label %bb35
bb52:
  %t154 = load i1, ptr %l7, !tbaa !21
  br i1 %t154, label %bb53, label %bb54
bb53:
  store i1 true, ptr %l85, !tbaa !21
  br label %bb59
bb54:
  %t156 = load ptr, ptr %l0, !tbaa !29
  store ptr %t156, ptr %l86, !tbaa !29
  %t157 = load ptr, ptr %l2, !tbaa !29
  %t159 = getelementptr %"compiler/load:Module", ptr %t157, i32 0, i32 6
  %t160 = load ptr, ptr %t159, !tbaa !29
  %t162 = icmp eq ptr %t160, null
  br i1 %t162, label %bb55, label %bb56
bb55:
  call void @__olang_check_failed(ptr @olang_loc_f48de55fc7d2510_3851ef0ac8d7efc4)
  unreachable
bb56:
  br label %bb57
bb57:
  %t164 = load ptr, ptr %l2, !tbaa !29
  %t166 = getelementptr %"compiler/load:Module", ptr %t164, i32 0, i32 6
  %t167 = load ptr, ptr %t166, !tbaa !29
  %t170 = getelementptr %"compiler/source:Source", ptr %t167, i32 0, i32 1
  %t171 = load { i64, ptr }, ptr %t170, !tbaa !27
  %t172 = getelementptr %"compiler/load:Import", ptr %l5, i32 0, i32 5
  %t173 = load i64, ptr %t172, !tbaa !24
  %t174 = load ptr, ptr %l86, !tbaa !29
  %t177 = call i1 @compiler_2fnames_2ecompiler_2fnames_3aResolver_2emethodsNamed(ptr %v0, ptr %v0, ptr %t174, { i64, ptr } %t171, i64 %t173)
  store i1 %t177, ptr %l95
  br label %bb58
bb58:
  %t178 = load i1, ptr %l95, !tbaa !21
  store i1 %t178, ptr %l85, !tbaa !21
  br label %bb59
bb59:
  %t179 = load i1, ptr %l85, !tbaa !21
  br i1 %t179, label %bb60, label %bb61
bb60:
  call void @__olang_scope_close(ptr %s3)
  br label %bb67
bb61:
  br label %bb62
bb62:
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t182 = getelementptr %"compiler/names:Resolver", ptr %t180, i32 0, i32 0
  %t183 = load ptr, ptr %t182, !tbaa !29
  %t185 = getelementptr %"compiler/load:Loader", ptr %t183, i32 0, i32 4
  %t186 = load ptr, ptr %t185, !tbaa !29
  store ptr %t186, ptr %l98, !tbaa !29
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t188 = load i64, ptr %l1, !tbaa !24
  %t189 = getelementptr %"compiler/load:Import", ptr %l5, i32 0, i32 0
  %t190 = load %"compiler/source:Span", ptr %t189
  %t194 = call { i64, [3 x i64] } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eat(ptr %v0, ptr %t187, i64 %t188, %"compiler/source:Span" %t190)
  store { i64, [3 x i64] } %t194, ptr %l102
  br label %bb63
bb63:
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t196 = load i32, ptr %l6, !tbaa !23
  %t199 = call { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etok(ptr %v0, ptr %s3, ptr %t195, i32 %t196)
  store { i64, ptr } %t199, ptr %l105
  br label %bb64
bb64:
  %t200 = load { i64, ptr }, ptr %l105, !tbaa !27
  %t201 = getelementptr %"compiler/load:Import", ptr %l5, i32 0, i32 3
  %t202 = load { i64, ptr }, ptr %t201, !tbaa !27
  %t205 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eImportUnused(ptr %s3, ptr %v0, ptr %v0, { i64, ptr } %t200, { i64, ptr } %t202)
  store %"compiler/diagmsg:Msg" %t205, ptr %l108
  br label %bb65
bb65:
  %t206 = load ptr, ptr %l98, !tbaa !29
  %t207 = load { i64, [3 x i64] }, ptr %l102
  %t208 = load %"compiler/diagmsg:Msg", ptr %l108
  %t209 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v0, ptr %t206, { i64, [3 x i64] } %t207, %"compiler/diagmsg:Msg" %t208)
  store i64 %t209, ptr %l109
  br label %bb66
bb66:
  call void @__olang_scope_close(ptr %s3)
  br label %bb67
bb67:
  %t210 = load i64, ptr %l4, !tbaa !24
  %t213 = add i64 %t210, 1
  store i64 %t213, ptr %l4, !tbaa !24
  br label %bb12
bb68:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2evarDecl(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i32
  %l33 = alloca { i64, ptr }
  %l44 = alloca i1
  %l48 = alloca i1
  %l53 = alloca i1
  %l63 = alloca i64
  %l66 = alloca i64
  %l88 = alloca { i64, ptr }
  %l92 = alloca { i64, ptr }
  %l97 = alloca { i64, ptr }
  %l101 = alloca { i64, ptr }
  %l110 = alloca i1
  %l126 = alloca { i64, ptr }
  %l133 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:VarDecl", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  %t8 = xor i1 %t6, true
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load ptr, ptr %l1, !tbaa !29
  %t13 = getelementptr %"compiler/ast:VarDecl", ptr %t11, i32 0, i32 2
  %t14 = load ptr, ptr %t13, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeRef(ptr %v0, ptr %v1, ptr %t10, ptr %t14)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t18 = load ptr, ptr %l1, !tbaa !29
  %t20 = getelementptr %"compiler/ast:VarDecl", ptr %t18, i32 0, i32 3
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !27
  store { i64, ptr } %t21, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t23 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t23, 0
  store i64 %t25, ptr %l4, !tbaa !24
  br label %bb5
bb5:
  %t27 = load i64, ptr %l3, !tbaa !24
  %t28 = load i64, ptr %l4, !tbaa !24
  %t31 = icmp slt i64 %t27, %t28
  %t33 = xor i1 %t31, true
  br i1 %t33, label %bb6, label %bb7
bb6:
  br label %bb11
bb7:
  br label %bb8
bb8:
  %t35 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t35, ptr %l33, !tbaa !27
  %t36 = load i64, ptr %l3, !tbaa !24
  %t38 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !27
  %t40 = getelementptr ptr, ptr %t39, i64 %t36
  %t41 = load ptr, ptr %t40, !tbaa !39
  %t43 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eexpr(ptr %v0, ptr %v1, ptr %t43, ptr %t41)
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t48 = load i64, ptr %l3, !tbaa !24
  %t51 = add i64 %t48, 1
  store i64 %t51, ptr %l3, !tbaa !24
  br label %bb5
bb11:
  %t53 = load ptr, ptr %l1, !tbaa !29
  %t55 = getelementptr %"compiler/ast:VarDecl", ptr %t53, i32 0, i32 5
  %t56 = load i1, ptr %t55, !tbaa !21
  br i1 %t56, label %bb12, label %bb13
bb12:
  %t58 = load ptr, ptr %l1, !tbaa !29
  %t60 = getelementptr %"compiler/ast:VarDecl", ptr %t58, i32 0, i32 2
  %t61 = load ptr, ptr %t60, !tbaa !29
  %t63 = icmp eq ptr %t61, null
  store i1 %t63, ptr %l44, !tbaa !21
  br label %bb14
bb13:
  store i1 false, ptr %l44, !tbaa !21
  br label %bb14
bb14:
  %t65 = load i1, ptr %l44, !tbaa !21
  br i1 %t65, label %bb15, label %bb16
bb15:
  %t66 = load ptr, ptr %l1, !tbaa !29
  %t68 = getelementptr %"compiler/ast:VarDecl", ptr %t66, i32 0, i32 3
  %t69 = load { i64, ptr }, ptr %t68, !tbaa !27
  %t71 = extractvalue { i64, ptr } %t69, 0
  %t73 = icmp eq i64 %t71, 0
  store i1 %t73, ptr %l48, !tbaa !21
  br label %bb17
bb16:
  store i1 false, ptr %l48, !tbaa !21
  br label %bb17
bb17:
  %t75 = load i1, ptr %l48, !tbaa !21
  br i1 %t75, label %bb18, label %bb19
bb18:
  %t76 = load ptr, ptr %l1, !tbaa !29
  %t78 = getelementptr %"compiler/ast:VarDecl", ptr %t76, i32 0, i32 4
  %t79 = load i1, ptr %t78, !tbaa !21
  %t81 = xor i1 %t79, true
  store i1 %t81, ptr %l53, !tbaa !21
  br label %bb20
bb19:
  store i1 false, ptr %l53, !tbaa !21
  br label %bb20
bb20:
  %t83 = load i1, ptr %l53, !tbaa !21
  br i1 %t83, label %bb21, label %bb22
bb21:
  br label %ret
bb22:
  br label %bb23
bb23:
  store i64 0, ptr %l6, !tbaa !24
  %t84 = load ptr, ptr %l1, !tbaa !29
  %t86 = getelementptr %"compiler/ast:VarDecl", ptr %t84, i32 0, i32 0
  %t87 = load { i64, ptr }, ptr %t86, !tbaa !27
  %t89 = extractvalue { i64, ptr } %t87, 0
  store i64 %t89, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t91 = load i64, ptr %l7, !tbaa !24
  %t92 = load i64, ptr %l6, !tbaa !24
  %t95 = icmp sgt i64 %t91, %t92
  br i1 %t95, label %bb24, label %bb25
bb24:
  %t97 = load i64, ptr %l8, !tbaa !24
  %t99 = icmp sgt i64 %t97, 0
  br i1 %t99, label %bb26, label %bb27
bb25:
  store i64 0, ptr %l63, !tbaa !24
  br label %bb29
bb26:
  %t101 = load i64, ptr %l7, !tbaa !24
  %t102 = load i64, ptr %l6, !tbaa !24
  %t105 = sub i64 %t101, %t102
  %t106 = load i64, ptr %l8, !tbaa !24
  %t109 = add i64 %t105, %t106
  %t111 = sub i64 %t109, 1
  %t112 = load i64, ptr %l8, !tbaa !24
  %t115 = sdiv i64 %t111, %t112
  store i64 %t115, ptr %l66, !tbaa !24
  br label %bb28
bb27:
  store i64 0, ptr %l66, !tbaa !24
  br label %bb28
bb28:
  %t117 = load i64, ptr %l66, !tbaa !24
  store i64 %t117, ptr %l63, !tbaa !24
  br label %bb29
bb29:
  %t118 = load i64, ptr %l63, !tbaa !24
  store i64 %t118, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb30
bb30:
  %t119 = load i64, ptr %l10, !tbaa !24
  %t120 = load i64, ptr %l9, !tbaa !24
  %t123 = icmp slt i64 %t119, %t120
  %t125 = xor i1 %t123, true
  br i1 %t125, label %bb31, label %bb32
bb31:
  br label %bb40
bb32:
  br label %bb33
bb33:
  %t127 = load i64, ptr %l6, !tbaa !24
  %t128 = load i64, ptr %l10, !tbaa !24
  %t129 = load i64, ptr %l8, !tbaa !24
  %t132 = mul i64 %t128, %t129
  %t135 = add i64 %t127, %t132
  store i64 %t135, ptr %l11, !tbaa !24
  %t137 = load ptr, ptr %l1, !tbaa !29
  %t139 = getelementptr %"compiler/ast:VarDecl", ptr %t137, i32 0, i32 5
  %t140 = load i1, ptr %t139, !tbaa !21
  br i1 %t140, label %bb34, label %bb35
bb34:
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t143 = load ptr, ptr %l1, !tbaa !29
  %t145 = getelementptr %"compiler/ast:VarDecl", ptr %t143, i32 0, i32 0
  %t146 = load { i64, ptr }, ptr %t145, !tbaa !27
  store { i64, ptr } %t146, ptr %l88, !tbaa !27
  %t147 = load i64, ptr %l11, !tbaa !24
  %t149 = getelementptr { i64, ptr }, ptr %l88, i32 0, i32 1
  %t150 = load ptr, ptr %t149, !tbaa !27
  %t151 = getelementptr i32, ptr %t150, i64 %t147
  %t152 = load i32, ptr %t151, !tbaa !33
  %t153 = load ptr, ptr %l1, !tbaa !29
  %t155 = getelementptr %"compiler/ast:VarDecl", ptr %t153, i32 0, i32 1
  %t156 = load { i64, ptr }, ptr %t155, !tbaa !27
  store { i64, ptr } %t156, ptr %l92, !tbaa !27
  %t157 = load i64, ptr %l11, !tbaa !24
  %t159 = getelementptr { i64, ptr }, ptr %l92, i32 0, i32 1
  %t160 = load ptr, ptr %t159, !tbaa !27
  %t161 = getelementptr %"compiler/source:Span", ptr %t160, i64 %t157
  %t162 = load %"compiler/source:Span", ptr %t161
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2edeclare(ptr %v0, ptr %t142, i32 %t152, %"compiler/source:Span" %t162, i1 true)
  br label %bb36
bb35:
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t167 = load ptr, ptr %l1, !tbaa !29
  %t169 = getelementptr %"compiler/ast:VarDecl", ptr %t167, i32 0, i32 0
  %t170 = load { i64, ptr }, ptr %t169, !tbaa !27
  store { i64, ptr } %t170, ptr %l97, !tbaa !27
  %t171 = load i64, ptr %l11, !tbaa !24
  %t173 = getelementptr { i64, ptr }, ptr %l97, i32 0, i32 1
  %t174 = load ptr, ptr %t173, !tbaa !27
  %t175 = getelementptr i32, ptr %t174, i64 %t171
  %t176 = load i32, ptr %t175, !tbaa !33
  %t177 = load ptr, ptr %l1, !tbaa !29
  %t179 = getelementptr %"compiler/ast:VarDecl", ptr %t177, i32 0, i32 1
  %t180 = load { i64, ptr }, ptr %t179, !tbaa !27
  store { i64, ptr } %t180, ptr %l101, !tbaa !27
  %t181 = load i64, ptr %l11, !tbaa !24
  %t183 = getelementptr { i64, ptr }, ptr %l101, i32 0, i32 1
  %t184 = load ptr, ptr %t183, !tbaa !27
  %t185 = getelementptr %"compiler/source:Span", ptr %t184, i64 %t181
  %t186 = load %"compiler/source:Span", ptr %t185
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2edeclareRead(ptr %v0, ptr %t166, i32 %t176, %"compiler/source:Span" %t186, i1 false)
  br label %bb37
bb36:
  br label %bb38
bb37:
  br label %bb38
bb38:
  br label %bb39
bb39:
  %t190 = load i64, ptr %l10, !tbaa !24
  %t193 = add i64 %t190, 1
  store i64 %t193, ptr %l10, !tbaa !24
  br label %bb30
bb40:
  %t195 = load ptr, ptr %l1, !tbaa !29
  %t197 = getelementptr %"compiler/ast:VarDecl", ptr %t195, i32 0, i32 5
  %t198 = load i1, ptr %t197, !tbaa !21
  %t200 = xor i1 %t198, true
  br i1 %t200, label %bb41, label %bb42
bb41:
  %t202 = load ptr, ptr %l1, !tbaa !29
  %t204 = getelementptr %"compiler/ast:VarDecl", ptr %t202, i32 0, i32 3
  %t205 = load { i64, ptr }, ptr %t204, !tbaa !27
  %t207 = extractvalue { i64, ptr } %t205, 0
  %t208 = load ptr, ptr %l1, !tbaa !29
  %t210 = getelementptr %"compiler/ast:VarDecl", ptr %t208, i32 0, i32 0
  %t211 = load { i64, ptr }, ptr %t210, !tbaa !27
  %t213 = extractvalue { i64, ptr } %t211, 0
  %t216 = icmp eq i64 %t207, %t213
  store i1 %t216, ptr %l110, !tbaa !21
  br label %bb43
bb42:
  store i1 false, ptr %l110, !tbaa !21
  br label %bb43
bb43:
  %t218 = load i1, ptr %l110, !tbaa !21
  br i1 %t218, label %bb44, label %bb45
bb44:
  %t219 = load ptr, ptr %l1, !tbaa !29
  %t221 = getelementptr %"compiler/ast:VarDecl", ptr %t219, i32 0, i32 0
  %t222 = load { i64, ptr }, ptr %t221, !tbaa !27
  store { i64, ptr } %t222, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t224 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t226 = extractvalue { i64, ptr } %t224, 0
  store i64 %t226, ptr %l14, !tbaa !24
  br label %bb46
bb45:
  br label %bb57
bb46:
  %t228 = load i64, ptr %l13, !tbaa !24
  %t229 = load i64, ptr %l14, !tbaa !24
  %t232 = icmp slt i64 %t228, %t229
  %t234 = xor i1 %t232, true
  br i1 %t234, label %bb47, label %bb48
bb47:
  br label %bb56
bb48:
  br label %bb49
bb49:
  %t236 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t236, ptr %l126, !tbaa !27
  %t237 = load i64, ptr %l13, !tbaa !24
  %t239 = getelementptr { i64, ptr }, ptr %l126, i32 0, i32 1
  %t240 = load ptr, ptr %t239, !tbaa !27
  %t241 = getelementptr i32, ptr %t240, i64 %t237
  %t242 = load i32, ptr %t241, !tbaa !33
  store i32 %t242, ptr %l15, !tbaa !23
  %t244 = load i32, ptr %l15, !tbaa !23
  %t246 = load ptr, ptr %l0, !tbaa !29
  %t248 = getelementptr %"compiler/names:Resolver", ptr %t246, i32 0, i32 12
  %t252 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eHas_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t248, i32 %t244)
  store i1 %t252, ptr %l133
  br label %bb50
bb50:
  %t253 = load i1, ptr %l133, !tbaa !21
  %t254 = xor i1 %t253, true
  br i1 %t254, label %bb51, label %bb52
bb51:
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t258 = getelementptr %"compiler/names:Resolver", ptr %t256, i32 0, i32 12
  %t259 = load i32, ptr %l15, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t258, i32 %t259)
  br label %bb53
bb52:
  br label %bb54
bb53:
  br label %bb54
bb54:
  br label %bb55
bb55:
  %t262 = load i64, ptr %l13, !tbaa !24
  %t265 = add i64 %t262, 1
  store i64 %t265, ptr %l13, !tbaa !24
  br label %bb46
bb56:
  br label %bb57
bb57:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ewaitBranch(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca i32
  %l12 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l22 = alloca i32
  %l23 = alloca i32
  %l24 = alloca %"compiler/source:Span"
  %l25 = alloca i32
  %l26 = alloca ptr
  %l35 = alloca ptr
  %l44 = alloca { i64, ptr }
  %l47 = alloca ptr
  %l48 = alloca i1
  %l56 = alloca ptr
  %l57 = alloca i1
  %l62 = alloca ptr
  %l63 = alloca i1
  %l72 = alloca ptr
  %l73 = alloca i1
  %l82 = alloca ptr
  %l83 = alloca i1
  %l91 = alloca ptr
  %l92 = alloca i1
  %l105 = alloca { i64, ptr }
  %l114 = alloca ptr
  %l115 = alloca i1
  %l127 = alloca { i64, ptr }
  %l131 = alloca i32
  %l140 = alloca ptr
  %l141 = alloca i1
  %l155 = alloca ptr
  %l162 = alloca { i64, ptr }
  %l164 = alloca i64
  %l166 = alloca i64
  %l167 = alloca i64
  %l172 = alloca { i64, ptr }
  %l175 = alloca ptr
  %l177 = alloca { i64, ptr }
  %l178 = alloca i32
  %s18 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/ast:TopBranch", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp eq i64 %t6, 0
  br i1 %t8, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/names:Resolver", ptr %t10, i32 0, i32 1
  %t13 = load i64, ptr %l1, !tbaa !24
  %t16 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v0, ptr %t12, i64 %t13)
  store ptr %t16, ptr %l35
  br label %bb4
bb4:
  %t17 = load ptr, ptr %l35, !tbaa !29
  store ptr %t17, ptr %l3, !tbaa !29
  %t18 = load ptr, ptr %l2, !tbaa !29
  %t20 = getelementptr %"compiler/ast:TopBranch", ptr %t18, i32 0, i32 1
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !27
  store { i64, ptr } %t21, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t23 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t23, 0
  store i64 %t25, ptr %l6, !tbaa !24
  br label %bb5
bb5:
  %t27 = load i64, ptr %l5, !tbaa !24
  %t28 = load i64, ptr %l6, !tbaa !24
  %t31 = icmp slt i64 %t27, %t28
  %t33 = xor i1 %t31, true
  br i1 %t33, label %bb6, label %bb7
bb6:
  br label %bb100
bb7:
  br label %bb8
bb8:
  %t35 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t35, ptr %l44, !tbaa !27
  %t36 = load i64, ptr %l5, !tbaa !24
  %t38 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !27
  %t40 = getelementptr ptr, ptr %t39, i64 %t36
  %t41 = load ptr, ptr %t40, !tbaa !39
  store ptr %t41, ptr %l7, !tbaa !29
  %t43 = load ptr, ptr %l7, !tbaa !29
  store ptr %t43, ptr %l47, !tbaa !29
  store i1 false, ptr %l48, !tbaa !21
  %t44 = load ptr, ptr %l47, !tbaa !29
  %t45 = icmp ne ptr %t44, null
  br i1 %t45, label %bb9, label %bb10
bb9:
  %t47 = load ptr, ptr %l47, !tbaa !29
  %t48 = load i64, ptr %t47, !range !{i64 0, i64 12}
  %t50 = icmp eq i64 %t48, 8
  store i1 %t50, ptr %l48, !tbaa !21
  br label %bb10
bb10:
  %t51 = load i1, ptr %l48, !tbaa !21
  br i1 %t51, label %bb11, label %bb12
bb11:
  %t52 = load ptr, ptr %l7, !tbaa !29
  %t54 = getelementptr { i64, [8 x i64] }, ptr %t52, i32 0, i32 1
  %t55 = getelementptr { %"compiler/source:Span", ptr }, ptr %t54, i32 0, i32 1
  %t56 = load ptr, ptr %t55
  store ptr %t56, ptr %l8, !tbaa !29
  br label %bb13
bb12:
  br label %bb15
bb13:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load i64, ptr %l1, !tbaa !24
  %t60 = load ptr, ptr %l8, !tbaa !29
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ewaitAside(ptr %v0, ptr %v1, ptr %t58, i64 %t59, ptr %t60)
  br label %bb14
bb14:
  br label %bb98
bb15:
  %t64 = load ptr, ptr %l7, !tbaa !29
  store ptr %t64, ptr %l56, !tbaa !29
  store i1 false, ptr %l57, !tbaa !21
  %t65 = load ptr, ptr %l56, !tbaa !29
  %t66 = icmp ne ptr %t65, null
  br i1 %t66, label %bb16, label %bb17
bb16:
  %t68 = load ptr, ptr %l56, !tbaa !29
  %t69 = load i64, ptr %t68, !range !{i64 0, i64 12}
  %t71 = icmp eq i64 %t69, 0
  store i1 %t71, ptr %l57, !tbaa !21
  br label %bb17
bb17:
  %t72 = load i1, ptr %l57, !tbaa !21
  br i1 %t72, label %bb18, label %bb19
bb18:
  %t73 = load ptr, ptr %l7, !tbaa !29
  %t75 = getelementptr { i64, [8 x i64] }, ptr %t73, i32 0, i32 1
  %t76 = getelementptr { ptr }, ptr %t75, i32 0, i32 0
  %t77 = load ptr, ptr %t76
  store ptr %t77, ptr %l9, !tbaa !29
  br label %bb24
bb19:
  %t79 = load ptr, ptr %l7, !tbaa !29
  store ptr %t79, ptr %l62, !tbaa !29
  store i1 false, ptr %l63, !tbaa !21
  %t80 = load ptr, ptr %l62, !tbaa !29
  %t81 = icmp ne ptr %t80, null
  br i1 %t81, label %bb20, label %bb21
bb20:
  %t83 = load ptr, ptr %l62, !tbaa !29
  %t84 = load i64, ptr %t83, !range !{i64 0, i64 12}
  %t86 = icmp eq i64 %t84, 1
  store i1 %t86, ptr %l63, !tbaa !21
  br label %bb21
bb21:
  %t87 = load i1, ptr %l63, !tbaa !21
  br i1 %t87, label %bb22, label %bb23
bb22:
  %t88 = load ptr, ptr %l7, !tbaa !29
  %t90 = getelementptr { i64, [8 x i64] }, ptr %t88, i32 0, i32 1
  %t91 = getelementptr { ptr }, ptr %t90, i32 0, i32 0
  %t92 = load ptr, ptr %t91
  store ptr %t92, ptr %l9, !tbaa !29
  br label %bb24
bb23:
  br label %bb26
bb24:
  %t94 = load ptr, ptr %l3, !tbaa !29
  %t96 = getelementptr %"compiler/names:Table", ptr %t94, i32 0, i32 4
  %t97 = load ptr, ptr %l9, !tbaa !29
  %t99 = getelementptr %"compiler/ast:Func", ptr %t97, i32 0, i32 2
  %t100 = load i32, ptr %t99, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H96b7de74ba8f33ba996281c879dd113a(ptr %v0, ptr %t96, i32 %t100, i1 true)
  br label %bb25
bb25:
  br label %bb98
bb26:
  %t103 = load ptr, ptr %l7, !tbaa !29
  store ptr %t103, ptr %l72, !tbaa !29
  store i1 false, ptr %l73, !tbaa !21
  %t104 = load ptr, ptr %l72, !tbaa !29
  %t105 = icmp ne ptr %t104, null
  br i1 %t105, label %bb27, label %bb28
bb27:
  %t107 = load ptr, ptr %l72, !tbaa !29
  %t108 = load i64, ptr %t107, !range !{i64 0, i64 12}
  %t110 = icmp eq i64 %t108, 2
  store i1 %t110, ptr %l73, !tbaa !21
  br label %bb28
bb28:
  %t111 = load i1, ptr %l73, !tbaa !21
  br i1 %t111, label %bb29, label %bb30
bb29:
  %t112 = load ptr, ptr %l7, !tbaa !29
  %t114 = getelementptr { i64, [8 x i64] }, ptr %t112, i32 0, i32 1
  %t115 = getelementptr { %"compiler/source:Span", ptr }, ptr %t114, i32 0, i32 1
  %t116 = load ptr, ptr %t115
  store ptr %t116, ptr %l10, !tbaa !29
  br label %bb31
bb30:
  br label %bb33
bb31:
  %t118 = load ptr, ptr %l3, !tbaa !29
  %t120 = getelementptr %"compiler/names:Table", ptr %t118, i32 0, i32 4
  %t121 = load ptr, ptr %l10, !tbaa !29
  %t123 = getelementptr %"compiler/ast:TypeDecl", ptr %t121, i32 0, i32 0
  %t124 = load i32, ptr %t123, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H96b7de74ba8f33ba996281c879dd113a(ptr %v0, ptr %t120, i32 %t124, i1 true)
  br label %bb32
bb32:
  br label %bb98
bb33:
  %t127 = load ptr, ptr %l7, !tbaa !29
  store ptr %t127, ptr %l82, !tbaa !29
  store i1 false, ptr %l83, !tbaa !21
  %t128 = load ptr, ptr %l82, !tbaa !29
  %t129 = icmp ne ptr %t128, null
  br i1 %t129, label %bb34, label %bb35
bb34:
  %t131 = load ptr, ptr %l82, !tbaa !29
  %t132 = load i64, ptr %t131, !range !{i64 0, i64 12}
  %t134 = icmp eq i64 %t132, 6
  store i1 %t134, ptr %l83, !tbaa !21
  br label %bb35
bb35:
  %t135 = load i1, ptr %l83, !tbaa !21
  br i1 %t135, label %bb36, label %bb37
bb36:
  %t136 = load ptr, ptr %l7, !tbaa !29
  %t138 = getelementptr { i64, [8 x i64] }, ptr %t136, i32 0, i32 1
  %t139 = getelementptr { %"compiler/source:Span", i32, { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t138, i32 0, i32 1
  %t140 = load i32, ptr %t139
  store i32 %t140, ptr %l11, !tbaa !23
  br label %bb38
bb37:
  br label %bb40
bb38:
  %t142 = load ptr, ptr %l3, !tbaa !29
  %t144 = getelementptr %"compiler/names:Table", ptr %t142, i32 0, i32 4
  %t145 = load i32, ptr %l11, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H96b7de74ba8f33ba996281c879dd113a(ptr %v0, ptr %t144, i32 %t145, i1 true)
  br label %bb39
bb39:
  br label %bb98
bb40:
  %t148 = load ptr, ptr %l7, !tbaa !29
  store ptr %t148, ptr %l91, !tbaa !29
  store i1 false, ptr %l92, !tbaa !21
  %t149 = load ptr, ptr %l91, !tbaa !29
  %t150 = icmp ne ptr %t149, null
  br i1 %t150, label %bb41, label %bb42
bb41:
  %t152 = load ptr, ptr %l91, !tbaa !29
  %t153 = load i64, ptr %t152, !range !{i64 0, i64 12}
  %t155 = icmp eq i64 %t153, 4
  store i1 %t155, ptr %l92, !tbaa !21
  br label %bb42
bb42:
  %t156 = load i1, ptr %l92, !tbaa !21
  br i1 %t156, label %bb43, label %bb44
bb43:
  %t157 = load ptr, ptr %l7, !tbaa !29
  %t159 = getelementptr { i64, [8 x i64] }, ptr %t157, i32 0, i32 1
  %t160 = getelementptr { %"compiler/source:Span", ptr }, ptr %t159, i32 0, i32 1
  %t161 = load ptr, ptr %t160
  store ptr %t161, ptr %l12, !tbaa !29
  br label %bb45
bb44:
  br label %bb53
bb45:
  %t163 = load ptr, ptr %l12, !tbaa !29
  %t165 = getelementptr %"compiler/ast:VarDecl", ptr %t163, i32 0, i32 0
  %t166 = load { i64, ptr }, ptr %t165, !tbaa !27
  store { i64, ptr } %t166, ptr %l13, !tbaa !27
  store i64 0, ptr %l14, !tbaa !24
  %t168 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t170 = extractvalue { i64, ptr } %t168, 0
  store i64 %t170, ptr %l15, !tbaa !24
  br label %bb46
bb46:
  %t172 = load i64, ptr %l14, !tbaa !24
  %t173 = load i64, ptr %l15, !tbaa !24
  %t176 = icmp slt i64 %t172, %t173
  %t178 = xor i1 %t176, true
  br i1 %t178, label %bb47, label %bb48
bb47:
  br label %bb52
bb48:
  br label %bb49
bb49:
  %t180 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t180, ptr %l105, !tbaa !27
  %t181 = load i64, ptr %l14, !tbaa !24
  %t183 = getelementptr { i64, ptr }, ptr %l105, i32 0, i32 1
  %t184 = load ptr, ptr %t183, !tbaa !27
  %t185 = getelementptr i32, ptr %t184, i64 %t181
  %t186 = load i32, ptr %t185, !tbaa !33
  %t188 = load ptr, ptr %l3, !tbaa !29
  %t190 = getelementptr %"compiler/names:Table", ptr %t188, i32 0, i32 4
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H96b7de74ba8f33ba996281c879dd113a(ptr %v0, ptr %t190, i32 %t186, i1 true)
  br label %bb50
bb50:
  br label %bb51
bb51:
  %t194 = load i64, ptr %l14, !tbaa !24
  %t197 = add i64 %t194, 1
  store i64 %t197, ptr %l14, !tbaa !24
  br label %bb46
bb52:
  br label %bb98
bb53:
  %t199 = load ptr, ptr %l7, !tbaa !29
  store ptr %t199, ptr %l114, !tbaa !29
  store i1 false, ptr %l115, !tbaa !21
  %t200 = load ptr, ptr %l114, !tbaa !29
  %t201 = icmp ne ptr %t200, null
  br i1 %t201, label %bb54, label %bb55
bb54:
  %t203 = load ptr, ptr %l114, !tbaa !29
  %t204 = load i64, ptr %t203, !range !{i64 0, i64 12}
  %t206 = icmp eq i64 %t204, 11
  store i1 %t206, ptr %l115, !tbaa !21
  br label %bb55
bb55:
  %t207 = load i1, ptr %l115, !tbaa !21
  br i1 %t207, label %bb56, label %bb57
bb56:
  %t208 = load ptr, ptr %l7, !tbaa !29
  %t210 = getelementptr { i64, [8 x i64] }, ptr %t208, i32 0, i32 1
  %t211 = getelementptr { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr } }, ptr %t210, i32 0, i32 2
  %t212 = load { i64, ptr }, ptr %t211
  store { i64, ptr } %t212, ptr %l17, !tbaa !27
  br label %bb58
bb57:
  br label %bb70
bb58:
  %t214 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t214, ptr %l18, !tbaa !27
  store i64 0, ptr %l19, !tbaa !24
  %t216 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t218 = extractvalue { i64, ptr } %t216, 0
  store i64 %t218, ptr %l20, !tbaa !24
  br label %bb59
bb59:
  %t220 = load i64, ptr %l19, !tbaa !24
  %t221 = load i64, ptr %l20, !tbaa !24
  %t224 = icmp slt i64 %t220, %t221
  %t226 = xor i1 %t224, true
  br i1 %t226, label %bb60, label %bb61
bb60:
  br label %bb69
bb61:
  br label %bb62
bb62:
  %t228 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t228, ptr %l127, !tbaa !27
  %t229 = load i64, ptr %l19, !tbaa !24
  %t231 = getelementptr { i64, ptr }, ptr %l127, i32 0, i32 1
  %t232 = load ptr, ptr %t231, !tbaa !27
  %t233 = getelementptr ptr, ptr %t232, i64 %t229
  %t234 = load ptr, ptr %t233, !tbaa !39
  %t238 = call i32 @compiler_2fnames_2eexternDeclName(ptr %v1, ptr %t234)
  store i32 %t238, ptr %l131
  br label %bb63
bb63:
  %t239 = load i32, ptr %l131, !tbaa !23
  store i32 %t239, ptr %l22, !tbaa !23
  %t240 = load i32, ptr %l22, !tbaa !23
  %t242 = icmp ne i32 %t240, 0
  br i1 %t242, label %bb64, label %bb65
bb64:
  %t244 = load ptr, ptr %l3, !tbaa !29
  %t246 = getelementptr %"compiler/names:Table", ptr %t244, i32 0, i32 4
  %t247 = load i32, ptr %l22, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H96b7de74ba8f33ba996281c879dd113a(ptr %v0, ptr %t246, i32 %t247, i1 true)
  br label %bb66
bb65:
  br label %bb67
bb66:
  br label %bb67
bb67:
  br label %bb68
bb68:
  %t250 = load i64, ptr %l19, !tbaa !24
  %t253 = add i64 %t250, 1
  store i64 %t253, ptr %l19, !tbaa !24
  br label %bb59
bb69:
  br label %bb98
bb70:
  %t255 = load ptr, ptr %l7, !tbaa !29
  store ptr %t255, ptr %l140, !tbaa !29
  store i1 false, ptr %l141, !tbaa !21
  %t256 = load ptr, ptr %l140, !tbaa !29
  %t257 = icmp ne ptr %t256, null
  br i1 %t257, label %bb71, label %bb72
bb71:
  %t259 = load ptr, ptr %l140, !tbaa !29
  %t260 = load i64, ptr %t259, !range !{i64 0, i64 12}
  %t262 = icmp eq i64 %t260, 5
  store i1 %t262, ptr %l141, !tbaa !21
  br label %bb72
bb72:
  %t263 = load i1, ptr %l141, !tbaa !21
  br i1 %t263, label %bb73, label %bb74
bb73:
  %t264 = load ptr, ptr %l7, !tbaa !29
  %t266 = getelementptr { i64, [8 x i64] }, ptr %t264, i32 0, i32 1
  %t267 = getelementptr { %"compiler/source:Span", i32, %"compiler/source:Span", %"compiler/source:Span" }, ptr %t266, i32 0, i32 1
  %t268 = load i32, ptr %t267
  store i32 %t268, ptr %l23, !tbaa !23
  %t270 = load ptr, ptr %l7, !tbaa !29
  %t272 = getelementptr { i64, [8 x i64] }, ptr %t270, i32 0, i32 1
  %t273 = getelementptr { %"compiler/source:Span", i32, %"compiler/source:Span", %"compiler/source:Span" }, ptr %t272, i32 0, i32 2
  %t274 = load %"compiler/source:Span", ptr %t273
  store %"compiler/source:Span" %t274, ptr %l24
  br label %bb75
bb74:
  br label %bb93
bb75:
  %t276 = load i32, ptr %l23, !tbaa !23
  store i32 %t276, ptr %l25, !tbaa !23
  %t278 = load i32, ptr %l25, !tbaa !23
  %t280 = icmp eq i32 %t278, 0
  br i1 %t280, label %bb76, label %bb77
bb76:
  store %olang.scope zeroinitializer, ptr %s18
  %t282 = load ptr, ptr %l0, !tbaa !29
  %t284 = getelementptr %"compiler/names:Resolver", ptr %t282, i32 0, i32 0
  %t285 = load ptr, ptr %t284, !tbaa !29
  %t287 = getelementptr %"compiler/load:Loader", ptr %t285, i32 0, i32 10
  %t288 = load i64, ptr %l1, !tbaa !24
  %t291 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t287, i64 %t288)
  store ptr %t291, ptr %l155
  br label %bb78
bb77:
  br label %bb91
bb78:
  %t292 = load ptr, ptr %l155, !tbaa !29
  %t294 = getelementptr %"compiler/load:Module", ptr %t292, i32 0, i32 6
  %t295 = load ptr, ptr %t294, !tbaa !29
  store ptr %t295, ptr %l26, !tbaa !29
  %t297 = load ptr, ptr %l26, !tbaa !29
  %t299 = icmp eq ptr %t297, null
  br i1 %t299, label %bb79, label %bb80
bb79:
  call void @__olang_check_failed(ptr @olang_loc_2e44b04c90256572_e4b951cec3f82206)
  unreachable
bb80:
  br label %bb81
bb81:
  %t301 = load ptr, ptr %l26, !tbaa !29
  %t304 = getelementptr %"compiler/source:Source", ptr %t301, i32 0, i32 1
  %t305 = load { i64, ptr }, ptr %t304, !tbaa !27
  store { i64, ptr } %t305, ptr %l162, !tbaa !27
  %t306 = getelementptr %"compiler/source:Span", ptr %l24, i32 0, i32 0
  %t307 = load i32, ptr %t306, !tbaa !23
  %t309 = sext i32 %t307 to i64
  store i64 %t309, ptr %l164, !tbaa !24
  %t310 = getelementptr %"compiler/source:Span", ptr %l24, i32 0, i32 1
  %t311 = load i32, ptr %t310, !tbaa !23
  %t313 = sext i32 %t311 to i64
  store i64 %t313, ptr %l166, !tbaa !24
  %t314 = load { i64, ptr }, ptr %l162, !tbaa !27
  %t315 = extractvalue { i64, ptr } %t314, 0
  store i64 %t315, ptr %l167, !tbaa !24
  %t316 = load i64, ptr %l164, !tbaa !24
  %t317 = icmp sge i64 %t316, 0
  br i1 %t317, label %bb82, label %bb83
bb82:
  %t319 = load i64, ptr %l164, !tbaa !24
  %t320 = load i64, ptr %l166, !tbaa !24
  %t321 = icmp sle i64 %t319, %t320
  br i1 %t321, label %bb84, label %bb85
bb83:
  call void @__olang_check_failed(ptr @olang_loc_c27b9afc6f9460e7_c1ce40693c6669b)
  unreachable
bb84:
  %t323 = load i64, ptr %l166, !tbaa !24
  %t324 = load i64, ptr %l167, !tbaa !24
  %t325 = icmp sle i64 %t323, %t324
  br i1 %t325, label %bb86, label %bb87
bb85:
  call void @__olang_check_failed(ptr @olang_loc_c27b9afc6f9460e7_c1ce40693c6669b)
  unreachable
bb86:
  %t327 = getelementptr { i64, ptr }, ptr %l162, i32 0, i32 1
  %t328 = load ptr, ptr %t327, !tbaa !27
  %t329 = load i64, ptr %l164, !tbaa !24
  %t330 = load i64, ptr %l166, !tbaa !24
  %t331 = getelementptr i8, ptr %t328, i64 %t329
  %t332 = sub i64 %t330, %t329
  %t333 = insertvalue { i64, ptr } undef, i64 %t332, 0
  %t334 = insertvalue { i64, ptr } %t333, ptr %t331, 1
  %t336 = call { i64, ptr } @compiler_2fscan_2eLiteralText(ptr %v0, ptr %s18, { i64, ptr } %t334)
  store { i64, ptr } %t336, ptr %l172
  br label %bb88
bb87:
  call void @__olang_check_failed(ptr @olang_loc_c27b9afc6f9460e7_c1ce40693c6669b)
  unreachable
bb88:
  %t337 = load { i64, ptr }, ptr %l172, !tbaa !27
  %t338 = load ptr, ptr %l0, !tbaa !29
  %t340 = getelementptr %"compiler/names:Resolver", ptr %t338, i32 0, i32 0
  %t341 = load ptr, ptr %t340, !tbaa !29
  %t343 = getelementptr %"compiler/load:Loader", ptr %t341, i32 0, i32 3
  %t344 = load ptr, ptr %t343, !tbaa !29
  store ptr %t344, ptr %l175, !tbaa !29
  %t347 = call { i64, ptr } @compiler_2fload_2eDeriveAlias(ptr %s18, ptr %s18, { i64, ptr } %t337)
  store { i64, ptr } %t347, ptr %l177
  br label %bb89
bb89:
  %t348 = load ptr, ptr %l175, !tbaa !29
  %t349 = load { i64, ptr }, ptr %l177, !tbaa !27
  %t350 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %s18, ptr %t348, { i64, ptr } %t349)
  store i32 %t350, ptr %l178
  br label %bb90
bb90:
  %t351 = load i32, ptr %l178, !tbaa !23
  store i32 %t351, ptr %l25, !tbaa !23
  call void @__olang_scope_close(ptr %s18)
  br label %bb91
bb91:
  %t352 = load ptr, ptr %l3, !tbaa !29
  %t354 = getelementptr %"compiler/names:Table", ptr %t352, i32 0, i32 4
  %t355 = load i32, ptr %l25, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H96b7de74ba8f33ba996281c879dd113a(ptr %v0, ptr %t354, i32 %t355, i1 true)
  br label %bb92
bb92:
  br label %bb98
bb93:
  br i1 true, label %bb94, label %bb95
bb94:
  br label %bb96
bb95:
  br label %bb97
bb96:
  br label %bb98
bb97:
  call void @__olang_check_failed(ptr @olang_loc_34778adaa3b7f78b_cd6f80cc1b0739cf)
  unreachable
bb98:
  br label %bb99
bb99:
  %t358 = load i64, ptr %l5, !tbaa !24
  %t361 = add i64 %t358, 1
  store i64 %t361, ptr %l5, !tbaa !24
  br label %bb5
bb100:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fnames_2eexternDeclName(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca i1
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 12}
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [8 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { ptr }, ptr %t12, i32 0, i32 0
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr %"compiler/ast:Func", ptr %t16, i32 0, i32 2
  %t19 = load i32, ptr %t18, !tbaa !23
  store i32 %t19, ptr %l3, !tbaa !23
  br label %bb17
bb6:
  %t21 = load ptr, ptr %l0, !tbaa !29
  store ptr %t21, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t22 = load ptr, ptr %l12, !tbaa !29
  %t23 = icmp ne ptr %t22, null
  br i1 %t23, label %bb7, label %bb8
bb7:
  %t25 = load ptr, ptr %l12, !tbaa !29
  %t26 = load i64, ptr %t25, !range !{i64 0, i64 12}
  %t28 = icmp eq i64 %t26, 2
  store i1 %t28, ptr %l13, !tbaa !21
  br label %bb8
bb8:
  %t29 = load i1, ptr %l13, !tbaa !21
  br i1 %t29, label %bb9, label %bb10
bb9:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr { i64, [8 x i64] }, ptr %t30, i32 0, i32 1
  %t33 = getelementptr { %"compiler/source:Span", ptr }, ptr %t32, i32 0, i32 1
  %t34 = load ptr, ptr %t33
  store ptr %t34, ptr %l2, !tbaa !29
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t36 = load ptr, ptr %l2, !tbaa !29
  %t38 = getelementptr %"compiler/ast:TypeDecl", ptr %t36, i32 0, i32 0
  %t39 = load i32, ptr %t38, !tbaa !23
  store i32 %t39, ptr %l3, !tbaa !23
  br label %bb17
bb12:
  br i1 true, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store i32 0, ptr %l3, !tbaa !23
  br label %bb17
bb16:
  call void @__olang_check_failed(ptr @olang_loc_e6f5afeb81d3c728_e8c5c2420d9193ac)
  unreachable
bb17:
  %t41 = load i32, ptr %l3, !tbaa !23
  store i32 %t41, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fnames_2efieldNames(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l15 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l24 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l49 = alloca ptr
  %l50 = alloca i1
  %l63 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l15
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l15
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/ast:StructBody", ptr %t3, i32 0, i32 0
  %t6 = load { i64, ptr }, ptr %t5, !tbaa !27
  store { i64, ptr } %t6, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t8 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t8, 0
  store i64 %t10, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  %t12 = load i64, ptr %l3, !tbaa !24
  %t13 = load i64, ptr %l4, !tbaa !24
  %t16 = icmp slt i64 %t12, %t13
  %t18 = xor i1 %t16, true
  br i1 %t18, label %bb3, label %bb4
bb3:
  br label %bb8
bb4:
  br label %bb5
bb5:
  %t20 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t20, ptr %l24, !tbaa !27
  %t21 = load i64, ptr %l3, !tbaa !24
  %t23 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = getelementptr ptr, ptr %t24, i64 %t21
  %t26 = load ptr, ptr %t25, !tbaa !39
  %t30 = getelementptr %"compiler/ast:Param", ptr %t26, i32 0, i32 1
  %t31 = load i32, ptr %t30, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %v1, ptr %l1, i32 %t31)
  br label %bb6
bb6:
  br label %bb7
bb7:
  %t34 = load i64, ptr %l3, !tbaa !24
  %t37 = add i64 %t34, 1
  store i64 %t37, ptr %l3, !tbaa !24
  br label %bb2
bb8:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/ast:StructBody", ptr %t39, i32 0, i32 2
  %t42 = load { i64, ptr }, ptr %t41, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t42, 0
  %t46 = icmp eq i64 %t44, 0
  br i1 %t46, label %bb9, label %bb10
bb9:
  %t48 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t48, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/ast:StructBody", ptr %t50, i32 0, i32 2
  %t53 = load { i64, ptr }, ptr %t52, !tbaa !27
  store { i64, ptr } %t53, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t55 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t57 = extractvalue { i64, ptr } %t55, 0
  store i64 %t57, ptr %l8, !tbaa !24
  br label %bb12
bb12:
  %t59 = load i64, ptr %l7, !tbaa !24
  %t60 = load i64, ptr %l8, !tbaa !24
  %t63 = icmp slt i64 %t59, %t60
  %t65 = xor i1 %t63, true
  br i1 %t65, label %bb13, label %bb14
bb13:
  br label %bb35
bb14:
  br label %bb15
bb15:
  %t67 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t67, ptr %l46, !tbaa !27
  %t68 = load i64, ptr %l7, !tbaa !24
  %t70 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !27
  %t72 = getelementptr ptr, ptr %t71, i64 %t68
  %t73 = load ptr, ptr %t72, !tbaa !39
  store ptr %t73, ptr %l9, !tbaa !29
  %t75 = load ptr, ptr %l9, !tbaa !29
  store ptr %t75, ptr %l49, !tbaa !29
  store i1 false, ptr %l50, !tbaa !21
  %t76 = load ptr, ptr %l49, !tbaa !29
  %t77 = icmp ne ptr %t76, null
  br i1 %t77, label %bb16, label %bb17
bb16:
  %t79 = load ptr, ptr %l49, !tbaa !29
  %t80 = load i64, ptr %t79, !range !{i64 0, i64 22}
  %t82 = icmp eq i64 %t80, 1
  store i1 %t82, ptr %l50, !tbaa !21
  br label %bb17
bb17:
  %t83 = load i1, ptr %l50, !tbaa !21
  br i1 %t83, label %bb18, label %bb19
bb18:
  %t84 = load ptr, ptr %l9, !tbaa !29
  %t86 = getelementptr { i64, [4 x i64] }, ptr %t84, i32 0, i32 1
  %t87 = getelementptr { %"compiler/source:Span", ptr }, ptr %t86, i32 0, i32 1
  %t88 = load ptr, ptr %t87
  store ptr %t88, ptr %l10, !tbaa !29
  br label %bb20
bb19:
  br label %bb28
bb20:
  %t90 = load ptr, ptr %l10, !tbaa !29
  %t92 = getelementptr %"compiler/ast:VarDecl", ptr %t90, i32 0, i32 0
  %t93 = load { i64, ptr }, ptr %t92, !tbaa !27
  store { i64, ptr } %t93, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t95 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t97 = extractvalue { i64, ptr } %t95, 0
  store i64 %t97, ptr %l13, !tbaa !24
  br label %bb21
bb21:
  %t99 = load i64, ptr %l12, !tbaa !24
  %t100 = load i64, ptr %l13, !tbaa !24
  %t103 = icmp slt i64 %t99, %t100
  %t105 = xor i1 %t103, true
  br i1 %t105, label %bb22, label %bb23
bb22:
  br label %bb27
bb23:
  br label %bb24
bb24:
  %t107 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t107, ptr %l63, !tbaa !27
  %t108 = load i64, ptr %l12, !tbaa !24
  %t110 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !27
  %t112 = getelementptr i32, ptr %t111, i64 %t108
  %t113 = load i32, ptr %t112, !tbaa !33
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %v1, ptr %l1, i32 %t113)
  br label %bb25
bb25:
  br label %bb26
bb26:
  %t118 = load i64, ptr %l12, !tbaa !24
  %t121 = add i64 %t118, 1
  store i64 %t121, ptr %l12, !tbaa !24
  br label %bb21
bb27:
  br label %bb33
bb28:
  br i1 true, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb33
bb32:
  call void @__olang_check_failed(ptr @olang_loc_6dee9be1cc02e387_998545862ea10f93)
  unreachable
bb33:
  br label %bb34
bb34:
  %t123 = load i64, ptr %l7, !tbaa !24
  %t126 = add i64 %t123, 1
  store i64 %t126, ptr %l7, !tbaa !24
  br label %bb12
bb35:
  %t128 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t128, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local i1 @compiler_2fnames_2eforeignRecv(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l7 = alloca i1
  %l8 = alloca ptr
  %l9 = alloca i1
  %l17 = alloca ptr
  %l18 = alloca i1
  %l25 = alloca i1
  %l26 = alloca ptr
  %l27 = alloca i1
  %l33 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  store ptr %t6, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t7 = load ptr, ptr %l8, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l8, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 8}
  %t13 = icmp eq i64 %t11, 0
  store i1 %t13, ptr %l9, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l9, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr { i64, [5 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t17, i32 0, i32 1
  %t19 = load { i64, ptr }, ptr %t18
  store { i64, ptr } %t19, ptr %l1, !tbaa !27
  br label %bb8
bb7:
  br label %bb9
bb8:
  %t21 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t25 = icmp sgt i64 %t23, 1
  store i1 %t25, ptr %l7, !tbaa !21
  br label %bb28
bb9:
  %t27 = load ptr, ptr %l0, !tbaa !29
  store ptr %t27, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t28 = load ptr, ptr %l17, !tbaa !29
  %t29 = icmp ne ptr %t28, null
  br i1 %t29, label %bb10, label %bb11
bb10:
  %t31 = load ptr, ptr %l17, !tbaa !29
  %t32 = load i64, ptr %t31, !range !{i64 0, i64 8}
  %t34 = icmp eq i64 %t32, 3
  store i1 %t34, ptr %l18, !tbaa !21
  br label %bb11
bb11:
  %t35 = load i1, ptr %l18, !tbaa !21
  br i1 %t35, label %bb12, label %bb13
bb12:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr { i64, [5 x i64] }, ptr %t36, i32 0, i32 1
  %t39 = getelementptr { %"compiler/source:Span", ptr, i1, i1 }, ptr %t38, i32 0, i32 1
  %t40 = load ptr, ptr %t39
  store ptr %t40, ptr %l2, !tbaa !29
  br label %bb14
bb13:
  br label %bb16
bb14:
  %t42 = load ptr, ptr %l2, !tbaa !29
  %t45 = call i1 @compiler_2fnames_2eforeignRecv(ptr %v0, ptr %t42)
  store i1 %t45, ptr %l25
  br label %bb15
bb15:
  %t46 = load i1, ptr %l25, !tbaa !21
  store i1 %t46, ptr %l7, !tbaa !21
  br label %bb28
bb16:
  %t47 = load ptr, ptr %l0, !tbaa !29
  store ptr %t47, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t48 = load ptr, ptr %l26, !tbaa !29
  %t49 = icmp ne ptr %t48, null
  br i1 %t49, label %bb17, label %bb18
bb17:
  %t51 = load ptr, ptr %l26, !tbaa !29
  %t52 = load i64, ptr %t51, !range !{i64 0, i64 8}
  %t54 = icmp eq i64 %t52, 4
  store i1 %t54, ptr %l27, !tbaa !21
  br label %bb18
bb18:
  %t55 = load i1, ptr %l27, !tbaa !21
  br i1 %t55, label %bb19, label %bb20
bb19:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr { i64, [5 x i64] }, ptr %t56, i32 0, i32 1
  %t59 = getelementptr { %"compiler/source:Span", ptr, i1 }, ptr %t58, i32 0, i32 1
  %t60 = load ptr, ptr %t59
  store ptr %t60, ptr %l3, !tbaa !29
  br label %bb21
bb20:
  br label %bb23
bb21:
  %t62 = load ptr, ptr %l3, !tbaa !29
  %t64 = call i1 @compiler_2fnames_2eforeignRecv(ptr %v0, ptr %t62)
  store i1 %t64, ptr %l33
  br label %bb22
bb22:
  %t65 = load i1, ptr %l33, !tbaa !21
  store i1 %t65, ptr %l7, !tbaa !21
  br label %bb28
bb23:
  br i1 true, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb27
bb26:
  store i1 false, ptr %l7, !tbaa !21
  br label %bb28
bb27:
  call void @__olang_check_failed(ptr @olang_loc_b132f661075442d5_ae99d36a98b51df9)
  unreachable
bb28:
  %t66 = load i1, ptr %l7, !tbaa !21
  store i1 %t66, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, i64 } @compiler_2fnames_2elineCol(ptr %v0, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l14 = alloca i64
  %l17 = alloca i64
  %l26 = alloca i64
  %l29 = alloca i1
  %l39 = alloca { i64, ptr }
  %rv = alloca { i64, i64 }
  br label %start
start:
  br label %bb0
bb0:
  store i64 1, ptr %l2, !tbaa !24
  store i64 1, ptr %l3, !tbaa !24
  store i64 0, ptr %l4, !tbaa !24
  store i64 %a1, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t3 = load i64, ptr %l5, !tbaa !24
  %t4 = load i64, ptr %l4, !tbaa !24
  %t7 = icmp sgt i64 %t3, %t4
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = load i64, ptr %l6, !tbaa !24
  %t11 = icmp sgt i64 %t9, 0
  br i1 %t11, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l14, !tbaa !24
  br label %bb6
bb3:
  %t13 = load i64, ptr %l5, !tbaa !24
  %t14 = load i64, ptr %l4, !tbaa !24
  %t17 = sub i64 %t13, %t14
  %t18 = load i64, ptr %l6, !tbaa !24
  %t21 = add i64 %t17, %t18
  %t23 = sub i64 %t21, 1
  %t24 = load i64, ptr %l6, !tbaa !24
  %t27 = sdiv i64 %t23, %t24
  store i64 %t27, ptr %l17, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb5
bb5:
  %t29 = load i64, ptr %l17, !tbaa !24
  store i64 %t29, ptr %l14, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l14, !tbaa !24
  store i64 %t30, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  %t31 = load i64, ptr %l7, !tbaa !24
  %t32 = sub i64 %t31, 1
  store i64 %t32, ptr %l26, !tbaa !24
  %t33 = load i64, ptr %l7, !tbaa !24
  %t34 = icmp slt i64 %t33, 2147483648
  %t35 = load i64, ptr %l8, !tbaa !24
  %t36 = icmp sge i64 %t35, 0
  %t39 = and i1 %t34, %t36
  store i1 %t39, ptr %l29, !tbaa !21
  br label %bb7
bb7:
  %t40 = load i64, ptr %l8, !tbaa !24
  %t41 = load i64, ptr %l7, !tbaa !24
  %t44 = icmp slt i64 %t40, %t41
  %t46 = xor i1 %t44, true
  br i1 %t46, label %bb8, label %bb9
bb8:
  br label %bb15
bb9:
  br label %bb10
bb10:
  %t48 = load i64, ptr %l4, !tbaa !24
  %t49 = load i64, ptr %l8, !tbaa !24
  %t50 = load i64, ptr %l6, !tbaa !24
  %t53 = mul i64 %t49, %t50
  %t56 = add i64 %t48, %t53
  store { i64, ptr } %a0, ptr %l39, !tbaa !27
  %t61 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !27
  %t63 = getelementptr i8, ptr %t62, i64 %t56
  %t64 = load i8, ptr %t63, !tbaa !32
  %t66 = icmp eq i8 %t64, 10
  br i1 %t66, label %bb11, label %bb12
bb11:
  %t68 = load i64, ptr %l2, !tbaa !24
  %t71 = add i64 %t68, 1
  store i64 %t71, ptr %l2, !tbaa !24
  store i64 1, ptr %l3, !tbaa !24
  br label %bb13
bb12:
  %t73 = load i64, ptr %l3, !tbaa !24
  %t76 = add i64 %t73, 1
  store i64 %t76, ptr %l3, !tbaa !24
  br label %bb13
bb13:
  br label %bb14
bb14:
  %t78 = load i64, ptr %l8, !tbaa !24
  %t81 = add i64 %t78, 1
  store i64 %t81, ptr %l8, !tbaa !24
  br label %bb7
bb15:
  %t83 = load i64, ptr %l2, !tbaa !24
  %t84 = load i64, ptr %l3, !tbaa !24
  %t86 = insertvalue { i64, i64 } undef, i64 %t83, 0
  %t88 = insertvalue { i64, i64 } %t86, i64 %t84, 1
  store { i64, i64 } %t88, ptr %rv
  br label %ret
ret:
  %rr = load { i64, i64 }, ptr %rv
  ret { i64, i64 } %rr
}

define dso_local { i64, ptr } @compiler_2fnames_2eliteralType(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca ptr
  %l7 = alloca i1
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l30 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l34 = alloca ptr
  %l35 = alloca i1
  %l44 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l49 = alloca ptr
  %l50 = alloca i1
  %l56 = alloca { i64, ptr }
  %l57 = alloca { i64, ptr }
  %l59 = alloca i64
  %l60 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t2 = load ptr, ptr %l6, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l6, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 28}
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l7, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l7, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13, !range !{i32 0, i32 116}
  store i32 %t14, ptr %l1
  br label %bb5
bb4:
  br label %bb18
bb5:
  %t16 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t18 = trunc i64 2 to i32
  %t19 = icmp eq i32 %t16, %t18
  br i1 %t19, label %bb6, label %bb7
bb6:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d34, i32 0, i32 1) }, ptr %l15, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t21, ptr %l14, !tbaa !27
  br label %bb17
bb7:
  %t23 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t25 = trunc i64 3 to i32
  %t26 = icmp eq i32 %t23, %t25
  br i1 %t26, label %bb8, label %bb9
bb8:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d35, i32 0, i32 1) }, ptr %l20, !tbaa !27
  %t28 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t28, ptr %l19, !tbaa !27
  br label %bb16
bb9:
  %t30 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t32 = trunc i64 6 to i32
  %t33 = icmp eq i32 %t30, %t32
  br i1 %t33, label %bb10, label %bb11
bb10:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d36, i32 0, i32 1) }, ptr %l25, !tbaa !27
  %t35 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t35, ptr %l24, !tbaa !27
  br label %bb15
bb11:
  %t37 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t39 = trunc i64 5 to i32
  %t40 = icmp eq i32 %t37, %t39
  br i1 %t40, label %bb12, label %bb13
bb12:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d37, i32 0, i32 1) }, ptr %l30, !tbaa !27
  %t42 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t42, ptr %l29, !tbaa !27
  br label %bb14
bb13:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d38, i32 0, i32 1) }, ptr %l32, !tbaa !27
  %t44 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t44, ptr %l29, !tbaa !27
  br label %bb14
bb14:
  %t46 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t46, ptr %l24, !tbaa !27
  br label %bb15
bb15:
  %t47 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t47, ptr %l19, !tbaa !27
  br label %bb16
bb16:
  %t48 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t48, ptr %l14, !tbaa !27
  br label %bb17
bb17:
  %t49 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t49, ptr %l5, !tbaa !27
  br label %bb40
bb18:
  %t50 = load ptr, ptr %l0, !tbaa !29
  store ptr %t50, ptr %l34, !tbaa !29
  store i1 false, ptr %l35, !tbaa !21
  %t51 = load ptr, ptr %l34, !tbaa !29
  %t52 = icmp ne ptr %t51, null
  br i1 %t52, label %bb19, label %bb20
bb19:
  %t54 = load ptr, ptr %l34, !tbaa !29
  %t55 = load i64, ptr %t54, !range !{i64 0, i64 28}
  %t57 = icmp eq i64 %t55, 3
  store i1 %t57, ptr %l35, !tbaa !21
  br label %bb20
bb20:
  %t58 = load i1, ptr %l35, !tbaa !21
  br i1 %t58, label %bb21, label %bb22
bb21:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr { i64, [4 x i64] }, ptr %t59, i32 0, i32 1
  %t62 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t61, i32 0, i32 1
  %t63 = load i32, ptr %t62, !range !{i32 0, i32 116}
  store i32 %t63, ptr %l2
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr { i64, [4 x i64] }, ptr %t65, i32 0, i32 1
  %t68 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t67, i32 0, i32 2
  %t69 = load ptr, ptr %t68
  store ptr %t69, ptr %l3, !tbaa !29
  br label %bb23
bb22:
  br label %bb28
bb23:
  %t71 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t73 = trunc i64 69 to i32
  %t74 = icmp eq i32 %t71, %t73
  br i1 %t74, label %bb24, label %bb25
bb24:
  %t76 = load ptr, ptr %l3, !tbaa !29
  %t78 = call { i64, ptr } @compiler_2fnames_2eliteralType(ptr %v0, ptr %v1, ptr %t76)
  store { i64, ptr } %t78, ptr %l46
  br label %bb26
bb25:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d39, i32 0, i32 1) }, ptr %l47, !tbaa !27
  %t79 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t79, ptr %l44, !tbaa !27
  br label %bb27
bb26:
  %t81 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t81, ptr %l44, !tbaa !27
  br label %bb27
bb27:
  %t82 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t82, ptr %l5, !tbaa !27
  br label %bb40
bb28:
  %t83 = load ptr, ptr %l0, !tbaa !29
  store ptr %t83, ptr %l49, !tbaa !29
  store i1 false, ptr %l50, !tbaa !21
  %t84 = load ptr, ptr %l49, !tbaa !29
  %t85 = icmp ne ptr %t84, null
  br i1 %t85, label %bb29, label %bb30
bb29:
  %t87 = load ptr, ptr %l49, !tbaa !29
  %t88 = load i64, ptr %t87, !range !{i64 0, i64 28}
  %t90 = icmp eq i64 %t88, 2
  store i1 %t90, ptr %l50, !tbaa !21
  br label %bb30
bb30:
  %t91 = load i1, ptr %l50, !tbaa !21
  br i1 %t91, label %bb31, label %bb32
bb31:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr { i64, [4 x i64] }, ptr %t92, i32 0, i32 1
  %t95 = getelementptr { %"compiler/source:Span", ptr }, ptr %t94, i32 0, i32 1
  %t96 = load ptr, ptr %t95
  store ptr %t96, ptr %l4, !tbaa !29
  br label %bb33
bb32:
  br label %bb35
bb33:
  %t98 = load ptr, ptr %l4, !tbaa !29
  %t100 = call { i64, ptr } @compiler_2fnames_2eliteralType(ptr %v0, ptr %v1, ptr %t98)
  store { i64, ptr } %t100, ptr %l56
  br label %bb34
bb34:
  %t101 = load { i64, ptr }, ptr %l56, !tbaa !27
  store { i64, ptr } %t101, ptr %l5, !tbaa !27
  br label %bb40
bb35:
  br i1 true, label %bb36, label %bb37
bb36:
  br label %bb38
bb37:
  br label %bb39
bb38:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d40, i32 0, i32 1) }, ptr %l57, !tbaa !27
  %t102 = load { i64, ptr }, ptr %l57, !tbaa !27
  store { i64, ptr } %t102, ptr %l5, !tbaa !27
  br label %bb40
bb39:
  call void @__olang_check_failed(ptr @olang_loc_69822c0cac48a014_4fc53fd0a2f89a60)
  unreachable
bb40:
  %t104 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t105 = extractvalue { i64, ptr } %t104, 0
  store i64 %t105, ptr %l59, !tbaa !24
  %t106 = load i64, ptr %l59, !tbaa !24
  %t107 = mul i64 %t106, 1
  %t108 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t107)
  %t109 = insertvalue { i64, ptr } undef, i64 %t106, 0
  %t110 = insertvalue { i64, ptr } %t109, ptr %t108, 1
  store { i64, ptr } %t110, ptr %l60, !tbaa !27
  %t111 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !27
  %t113 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !27
  %t115 = load i64, ptr %l59, !tbaa !24
  %t116 = mul i64 %t115, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t112, ptr %t114, i64 %t116, i1 false)
  %t117 = load { i64, ptr }, ptr %l60, !tbaa !27
  store { i64, ptr } %t117, ptr %l5, !tbaa !27
  %t118 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t118, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fnames_2ementionsMember(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l15 = alloca { i64, ptr }
  %l20 = alloca i1
  %l21 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l27 = alloca i1
  %l28 = alloca { i64, ptr }
  %l29 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l40 = alloca i1
  %l49 = alloca i1
  %l50 = alloca { i64, ptr }
  %l56 = alloca i1
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  store i64 1, ptr %l2, !tbaa !24
  br label %bb4
bb4:
  %t8 = load i64, ptr %l2, !tbaa !24
  %t9 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  %t14 = add i64 %t8, %t11
  %t15 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t20 = icmp sle i64 %t14, %t17
  %t22 = xor i1 %t20, true
  br i1 %t22, label %bb5, label %bb6
bb5:
  br label %bb32
bb6:
  br label %bb7
bb7:
  %t24 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t24, ptr %l15, !tbaa !27
  %t25 = load i64, ptr %l2, !tbaa !24
  %t27 = sub i64 %t25, 1
  %t29 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = getelementptr i8, ptr %t30, i64 %t27
  %t32 = load i8, ptr %t31, !tbaa !32
  %t34 = icmp ne i8 %t32, 46
  br i1 %t34, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb10
bb9:
  %t36 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t36, ptr %l21, !tbaa !27
  %t37 = load i64, ptr %l2, !tbaa !24
  %t39 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !27
  %t41 = getelementptr i8, ptr %t40, i64 %t37
  %t42 = load i8, ptr %t41, !tbaa !32
  %t43 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t43, ptr %l24, !tbaa !27
  %t44 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = getelementptr i8, ptr %t45, i64 0
  %t47 = load i8, ptr %t46, !tbaa !32
  %t50 = icmp ne i8 %t42, %t47
  store i1 %t50, ptr %l20, !tbaa !21
  br label %bb10
bb10:
  %t52 = load i1, ptr %l20, !tbaa !21
  br i1 %t52, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb20
bb12:
  %t53 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t53, ptr %l28, !tbaa !27
  %t54 = load i64, ptr %l2, !tbaa !24
  store i64 %t54, ptr %l29, !tbaa !24
  %t55 = load i64, ptr %l2, !tbaa !24
  %t56 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t58 = extractvalue { i64, ptr } %t56, 0
  %t61 = add i64 %t55, %t58
  store i64 %t61, ptr %l33, !tbaa !24
  %t62 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t63 = extractvalue { i64, ptr } %t62, 0
  store i64 %t63, ptr %l34, !tbaa !24
  %t64 = load i64, ptr %l29, !tbaa !24
  %t65 = icmp sge i64 %t64, 0
  br i1 %t65, label %bb13, label %bb14
bb13:
  %t67 = load i64, ptr %l29, !tbaa !24
  %t68 = load i64, ptr %l33, !tbaa !24
  %t69 = icmp sle i64 %t67, %t68
  br i1 %t69, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_37678c01af633453_98b92ef1312e36f7)
  unreachable
bb15:
  %t71 = load i64, ptr %l33, !tbaa !24
  %t72 = load i64, ptr %l34, !tbaa !24
  %t73 = icmp sle i64 %t71, %t72
  br i1 %t73, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_37678c01af633453_98b92ef1312e36f7)
  unreachable
bb17:
  %t75 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = load i64, ptr %l29, !tbaa !24
  %t78 = load i64, ptr %l33, !tbaa !24
  %t79 = getelementptr i8, ptr %t76, i64 %t77
  %t80 = sub i64 %t78, %t77
  %t81 = insertvalue { i64, ptr } undef, i64 %t80, 0
  %t82 = insertvalue { i64, ptr } %t81, ptr %t79, 1
  %t83 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t86 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %t82, { i64, ptr } %t83)
  store i1 %t86, ptr %l40
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_37678c01af633453_98b92ef1312e36f7)
  unreachable
bb19:
  %t87 = load i1, ptr %l40, !tbaa !21
  %t88 = xor i1 %t87, true
  store i1 %t88, ptr %l27, !tbaa !21
  br label %bb20
bb20:
  %t90 = load i1, ptr %l27, !tbaa !21
  br i1 %t90, label %bb21, label %bb22
bb21:
  br label %bb31
bb22:
  br label %bb23
bb23:
  %t91 = load i64, ptr %l2, !tbaa !24
  %t92 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t94 = extractvalue { i64, ptr } %t92, 0
  %t97 = add i64 %t91, %t94
  %t98 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t100 = extractvalue { i64, ptr } %t98, 0
  %t103 = icmp eq i64 %t97, %t100
  br i1 %t103, label %bb24, label %bb25
bb24:
  store i1 true, ptr %l49, !tbaa !21
  br label %bb27
bb25:
  %t105 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t105, ptr %l50, !tbaa !27
  %t106 = load i64, ptr %l2, !tbaa !24
  %t107 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t109 = extractvalue { i64, ptr } %t107, 0
  %t112 = add i64 %t106, %t109
  %t114 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !27
  %t116 = getelementptr i8, ptr %t115, i64 %t112
  %t117 = load i8, ptr %t116, !tbaa !32
  %t119 = call i1 @compiler_2fnames_2eidentChar(i8 %t117)
  store i1 %t119, ptr %l56
  br label %bb26
bb26:
  %t120 = load i1, ptr %l56, !tbaa !21
  %t121 = xor i1 %t120, true
  store i1 %t121, ptr %l49, !tbaa !21
  br label %bb27
bb27:
  %t123 = load i1, ptr %l49, !tbaa !21
  br i1 %t123, label %bb28, label %bb29
bb28:
  store i1 true, ptr %rv
  br label %ret
bb29:
  br label %bb30
bb30:
  br label %bb31
bb31:
  %t125 = load i64, ptr %l2, !tbaa !24
  %t128 = add i64 %t125, 1
  store i64 %t128, ptr %l2, !tbaa !24
  br label %bb4
bb32:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fnames_2eoutranks(ptr %v0, ptr %v1, %"compiler/names:raisedName" %a0, %"compiler/names:raisedName" %a1) #0 {
entry:
  %l0 = alloca %"compiler/names:raisedName"
  %l1 = alloca %"compiler/names:raisedName"
  %l5 = alloca i1
  %l9 = alloca i1
  %rv = alloca i1
  store %"compiler/names:raisedName" %a0, ptr %l0
  store %"compiler/names:raisedName" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/names:raisedName", ptr %l0, i32 0, i32 2
  %t2 = load i64, ptr %t1, !tbaa !24
  %t3 = getelementptr %"compiler/names:raisedName", ptr %l1, i32 0, i32 2
  %t4 = load i64, ptr %t3, !tbaa !24
  %t7 = icmp sgt i64 %t2, %t4
  br i1 %t7, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l5, !tbaa !21
  br label %bb6
bb2:
  %t9 = getelementptr %"compiler/names:raisedName", ptr %l0, i32 0, i32 2
  %t10 = load i64, ptr %t9, !tbaa !24
  %t11 = getelementptr %"compiler/names:raisedName", ptr %l1, i32 0, i32 2
  %t12 = load i64, ptr %t11, !tbaa !24
  %t15 = icmp eq i64 %t10, %t12
  br i1 %t15, label %bb3, label %bb4
bb3:
  %t17 = getelementptr %"compiler/names:raisedName", ptr %l0, i32 0, i32 4
  %t18 = load i64, ptr %t17, !tbaa !24
  %t19 = getelementptr %"compiler/names:raisedName", ptr %l1, i32 0, i32 4
  %t20 = load i64, ptr %t19, !tbaa !24
  %t23 = icmp slt i64 %t18, %t20
  store i1 %t23, ptr %l9, !tbaa !21
  br label %bb5
bb4:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb5
bb5:
  %t25 = load i1, ptr %l9, !tbaa !21
  store i1 %t25, ptr %l5, !tbaa !21
  br label %bb6
bb6:
  %t26 = load i1, ptr %l5, !tbaa !21
  store i1 %t26, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fnames_2etestRules(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca %"compiler/cond:Consts"
  %l10 = alloca %"compiler/diag:Diagnostics"
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l15 = alloca %"compiler/load:Loader"
  %l16 = alloca %"compiler/names:Resolver"
  %l17 = alloca %"std/prelude/text:StringBuilder"
  %l18 = alloca ptr
  %l19 = alloca i64
  %l20 = alloca %"compiler/diag:Said"
  %l21 = alloca { i64, i64 }
  %l24 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca i32
  %l28 = alloca i1
  %l36 = alloca i64
  %l39 = alloca i64
  %l58 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %l68 = alloca i32
  %l70 = alloca i1
  %l76 = alloca %"compiler/cond:Consts"
  %l78 = alloca %"compiler/diag:Diagnostics"
  %l86 = alloca { i64, ptr }
  %l92 = alloca i32
  %l96 = alloca ptr
  %l97 = alloca i64
  %l99 = alloca i64
  %l103 = alloca { i64, ptr }
  %l104 = alloca i64
  %l109 = alloca %"compiler/fetch:Fetcher"
  %l110 = alloca ptr
  %l111 = alloca i64
  %l113 = alloca %"compiler/source:Names"
  %l116 = alloca %"compiler/load:Loader"
  %l117 = alloca ptr
  %l118 = alloca i64
  %l121 = alloca { i64, ptr }
  %l125 = alloca i64
  %l127 = alloca %"compiler/names:Resolver"
  %l129 = alloca %"std/prelude/text:StringBuilder"
  %l131 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l133 = alloca i64
  %l135 = alloca i64
  %l140 = alloca %"compiler/diag:Said"
  %l141 = alloca { i64, ptr }
  %l144 = alloca { i64, i64 }
  %l157 = alloca { i64, ptr }
  %l159 = alloca i32
  %l161 = alloca i1
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t120 = alloca %"compiler/cond:Consts", align 8
  %t122 = alloca %"compiler/diag:Diagnostics", align 8
  %t211 = alloca %"compiler/fetch:Fetcher", align 8
  %t236 = alloca %"compiler/load:Loader", align 8
  %t274 = alloca %"compiler/names:Resolver", align 8
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call { i32, { i64, ptr } } @std_2fos_2eMkTemp(ptr %s0, ptr %s0, ptr %s0, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d41, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d42, i32 0, i32 1) })
  %t2 = extractvalue { i32, { i64, ptr } } %t1, 1
  %t3 = extractvalue { i32, { i64, ptr } } %t1, 0
  store i32 %t3, ptr %l26
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5, !prof !99
ok.5:
  store { i64, ptr } %t2, ptr %l25
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t6, ptr %l24, !tbaa !27
  br label %bb6
bb2:
  %t7 = load i32, ptr %l26, !tbaa !23
  %t8 = ashr i32 %t7, 16
  %t10 = icmp eq i32 %t8, 1
  store i1 %t10, ptr %l28, !tbaa !21
  %t11 = load i32, ptr %l26, !tbaa !23
  %t12 = ashr i32 %t11, 16
  %t14 = icmp eq i32 %t12, 1
  br i1 %t14, label %bb3, label %bb4
bb3:
  call void @__olang_errpay_pop()
  br label %bb4
bb4:
  br label %bb5
bb5:
  call void @__olang_check_failed(ptr @olang_loc_7d6219e827f558e0_eeca058e7ab150ac)
  unreachable
bb6:
  %t16 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t16, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t17 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t17, 0
  store i64 %t19, ptr %l4, !tbaa !24
  store i64 2, ptr %l5, !tbaa !24
  %t21 = load i64, ptr %l4, !tbaa !24
  %t22 = load i64, ptr %l3, !tbaa !24
  %t25 = icmp sgt i64 %t21, %t22
  br i1 %t25, label %bb7, label %bb8
bb7:
  %t27 = load i64, ptr %l5, !tbaa !24
  %t29 = icmp sgt i64 %t27, 0
  br i1 %t29, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l36, !tbaa !24
  br label %bb12
bb9:
  %t31 = load i64, ptr %l4, !tbaa !24
  %t32 = load i64, ptr %l3, !tbaa !24
  %t35 = sub i64 %t31, %t32
  %t36 = load i64, ptr %l5, !tbaa !24
  %t39 = add i64 %t35, %t36
  %t41 = sub i64 %t39, 1
  %t42 = load i64, ptr %l5, !tbaa !24
  %t45 = sdiv i64 %t41, %t42
  store i64 %t45, ptr %l39, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l39, !tbaa !24
  br label %bb11
bb11:
  %t47 = load i64, ptr %l39, !tbaa !24
  store i64 %t47, ptr %l36, !tbaa !24
  br label %bb12
bb12:
  %t48 = load i64, ptr %l36, !tbaa !24
  store i64 %t48, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb13
bb13:
  store %olang.scope zeroinitializer, ptr %s3
  %t49 = load i64, ptr %l7, !tbaa !24
  %t50 = load i64, ptr %l6, !tbaa !24
  %t53 = icmp slt i64 %t49, %t50
  %t55 = xor i1 %t53, true
  br i1 %t55, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s3)
  br label %bb24
bb15:
  br label %bb16
bb16:
  %t57 = load i64, ptr %l3, !tbaa !24
  %t58 = load i64, ptr %l7, !tbaa !24
  %t59 = load i64, ptr %l5, !tbaa !24
  %t62 = mul i64 %t58, %t59
  %t65 = add i64 %t57, %t62
  store i64 %t65, ptr %l8, !tbaa !24
  %t67 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t68 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t68, ptr %l58, !tbaa !27
  %t69 = load i64, ptr %l8, !tbaa !24
  %t71 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !27
  %t73 = getelementptr { i64, ptr }, ptr %t72, i64 %t69
  %t74 = load { i64, ptr }, ptr %t73, !tbaa !37
  %t76 = extractvalue { i64, ptr } %t67, 1
  %t77 = extractvalue { i64, ptr } %t67, 0
  %t78 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d43, i32 0, i32 1) }, 1
  %t79 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d43, i32 0, i32 1) }, 0
  %t80 = add i64 %t77, %t79
  %t82 = extractvalue { i64, ptr } %t74, 1
  %t83 = extractvalue { i64, ptr } %t74, 0
  %t84 = add i64 %t80, %t83
  %t85 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t84)
  call void @olang_textcopy(ptr %t85, ptr %t76, i64 %t77)
  %t86 = getelementptr i8, ptr %t85, i64 %t77
  call void @olang_textcopy(ptr %t86, ptr %t78, i64 %t79)
  %t87 = getelementptr i8, ptr %t86, i64 %t79
  call void @olang_textcopy(ptr %t87, ptr %t82, i64 %t83)
  %t88 = insertvalue { i64, ptr } undef, i64 %t84, 0
  %t89 = insertvalue { i64, ptr } %t88, ptr %t85, 1
  %t91 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t91, ptr %l63, !tbaa !27
  %t92 = load i64, ptr %l8, !tbaa !24
  %t94 = add i64 %t92, 1
  %t96 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !27
  %t98 = getelementptr { i64, ptr }, ptr %t97, i64 %t94
  %t99 = load { i64, ptr }, ptr %t98, !tbaa !37
  %t103 = call i32 @std_2fos_2eWriteFile(ptr %s3, ptr %v0, { i64, ptr } %t89, { i64, ptr } %t99)
  store i32 %t103, ptr %l68
  %t104 = icmp ne i32 %t103, 0
  br i1 %t104, label %bb18, label %ok.105, !prof !99
ok.105:
  br label %bb17
bb17:
  br label %bb22
bb18:
  %t106 = load i32, ptr %l68, !tbaa !23
  %t107 = ashr i32 %t106, 16
  %t109 = icmp eq i32 %t107, 1
  store i1 %t109, ptr %l70, !tbaa !21
  %t110 = load i32, ptr %l68, !tbaa !23
  %t111 = ashr i32 %t110, 16
  %t113 = icmp eq i32 %t111, 1
  br i1 %t113, label %bb19, label %bb20
bb19:
  call void @__olang_errpay_pop()
  br label %bb20
bb20:
  br label %bb21
bb21:
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s3)
  br label %bb23
bb23:
  %t115 = load i64, ptr %l7, !tbaa !24
  %t118 = add i64 %t115, 1
  store i64 %t118, ptr %l7, !tbaa !24
  br label %bb13
bb24:
  call void @compiler_2fcond_3aConsts_2ector(ptr %t120, ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %l76, ptr %t120, i64 256, i1 false)
  br label %bb25
bb25:
  call void @llvm.memmove.p0.p0.i64(ptr %l9, ptr %l76, i64 256, i1 false)
  call void @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eBuiltins(ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %l9, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d44, i32 0, i32 1) }, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d45, i32 0, i32 1) }, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d46, i32 0, i32 1) }, i64 128, i64 0, i1 false, i1 false, i1 false, i64 0)
  br label %bb26
bb26:
  call void @compiler_2fdiag_3aDiagnostics_2ector(ptr %t122, ptr %s0, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l78, ptr %t122, i64 704, i1 false)
  br label %bb27
bb27:
  call void @llvm.memmove.p0.p0.i64(ptr %l10, ptr %l78, i64 704, i1 false)
  store { i64, ptr } %a1, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t125 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t127 = extractvalue { i64, ptr } %t125, 0
  store i64 %t127, ptr %l13, !tbaa !24
  br label %bb28
bb28:
  %t129 = load i64, ptr %l12, !tbaa !24
  %t130 = load i64, ptr %l13, !tbaa !24
  %t133 = icmp slt i64 %t129, %t130
  %t135 = xor i1 %t133, true
  br i1 %t135, label %bb29, label %bb30
bb29:
  br label %bb37
bb30:
  br label %bb31
bb31:
  %t137 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t137, ptr %l86, !tbaa !27
  %t138 = load i64, ptr %l12, !tbaa !24
  %t140 = getelementptr { i64, ptr }, ptr %l86, i32 0, i32 1
  %t141 = load ptr, ptr %t140, !tbaa !27
  %t142 = getelementptr { i64, ptr }, ptr %t141, i64 %t138
  %t143 = load { i64, ptr }, ptr %t142, !tbaa !37
  %t149 = call i32 @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eDefine(ptr %s0, ptr %v1, ptr %s0, ptr %l9, { i64, ptr } %t143, ptr %l10)
  store i32 %t149, ptr %l92
  %t150 = icmp ne i32 %t149, 0
  br i1 %t150, label %bb33, label %ok.151, !prof !99
ok.151:
  br label %bb32
bb32:
  br label %bb35
bb33:
  br label %bb34
bb34:
  br label %bb35
bb35:
  br label %bb36
bb36:
  %t152 = load i64, ptr %l12, !tbaa !24
  %t155 = add i64 %t152, 1
  store i64 %t155, ptr %l12, !tbaa !24
  br label %bb28
bb37:
  store ptr %l9, ptr %l96, !tbaa !29
  %t157 = call ptr @__olang_scope_hold(ptr %s0)
  %t158 = ptrtoint ptr %t157 to i64
  store i64 %t158, ptr %l97, !tbaa !24
  %t159 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aLoader_2e2
  br i1 %t159, label %bb38, label %bb39
bb38:
  %t161 = call ptr @__olang_region_make(ptr %s0)
  %t162 = ptrtoint ptr %t161 to i64
  store i64 %t162, ptr %l97, !tbaa !24
  br label %bb39
bb39:
  %t163 = load i64, ptr %l97
  %t164 = inttoptr i64 %t163 to ptr
  %t165 = call ptr @__olang_scope_hold(ptr %t164)
  %t166 = ptrtoint ptr %t165 to i64
  store i64 %t166, ptr %l99, !tbaa !24
  %t167 = load i1, ptr @olang_2esole_2ecompiler_2ffetch_3aFetcher_2e0
  br i1 %t167, label %bb40, label %bb41
bb40:
  %t169 = load i64, ptr %l97
  %t170 = inttoptr i64 %t169 to ptr
  %t171 = call ptr @__olang_region_make(ptr %t170)
  %t172 = ptrtoint ptr %t171 to i64
  store i64 %t172, ptr %l99, !tbaa !24
  br label %bb41
bb41:
  %t173 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t175 = extractvalue { i64, ptr } %t173, 1
  %t176 = extractvalue { i64, ptr } %t173, 0
  %t177 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d47, i32 0, i32 1) }, 1
  %t178 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d47, i32 0, i32 1) }, 0
  %t179 = add i64 %t176, %t178
  %t180 = load i64, ptr %l99
  %t181 = inttoptr i64 %t180 to ptr
  %t182 = call ptr @__olang_held_alloc(ptr %t181, i64 %t179)
  call void @olang_textcopy(ptr %t182, ptr %t175, i64 %t176)
  %t183 = getelementptr i8, ptr %t182, i64 %t176
  call void @olang_textcopy(ptr %t183, ptr %t177, i64 %t178)
  %t184 = insertvalue { i64, ptr } undef, i64 %t179, 0
  %t185 = insertvalue { i64, ptr } %t184, ptr %t182, 1
  store { i64, ptr } %t185, ptr %l103, !tbaa !27
  %t187 = load i64, ptr %l97
  %t188 = inttoptr i64 %t187 to ptr
  %t189 = call ptr @__olang_scope_hold(ptr %t188)
  %t190 = ptrtoint ptr %t189 to i64
  store i64 %t190, ptr %l104, !tbaa !24
  %t191 = load i1, ptr @olang_2esole_2ecompiler_2ffetch_3aFetcher_2e1
  br i1 %t191, label %bb42, label %bb43
bb42:
  %t193 = load i64, ptr %l97
  %t194 = inttoptr i64 %t193 to ptr
  %t195 = call ptr @__olang_region_make(ptr %t194)
  %t196 = ptrtoint ptr %t195 to i64
  store i64 %t196, ptr %l104, !tbaa !24
  br label %bb43
bb43:
  %t197 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t199 = extractvalue { i64, ptr } %t197, 1
  %t200 = extractvalue { i64, ptr } %t197, 0
  %t201 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d48, i32 0, i32 1) }, 1
  %t202 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d48, i32 0, i32 1) }, 0
  %t203 = add i64 %t200, %t202
  %t204 = load i64, ptr %l104
  %t205 = inttoptr i64 %t204 to ptr
  %t206 = call ptr @__olang_held_alloc(ptr %t205, i64 %t203)
  call void @olang_textcopy(ptr %t206, ptr %t199, i64 %t200)
  %t207 = getelementptr i8, ptr %t206, i64 %t200
  call void @olang_textcopy(ptr %t207, ptr %t201, i64 %t202)
  %t208 = insertvalue { i64, ptr } undef, i64 %t203, 0
  %t209 = insertvalue { i64, ptr } %t208, ptr %t206, 1
  %t212 = load i64, ptr %l97
  %t213 = inttoptr i64 %t212 to ptr
  %t214 = load i64, ptr %l97
  %t215 = inttoptr i64 %t214 to ptr
  %t216 = load i64, ptr %l97
  %t217 = inttoptr i64 %t216 to ptr
  %t218 = load { i64, ptr }, ptr %l103, !tbaa !27
  call void @compiler_2ffetch_3aFetcher_2ector(ptr %t211, ptr %t213, ptr %t215, ptr %s0, ptr %t217, { i64, ptr } %t218, { i64, ptr } %t209, { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d49, i32 0, i32 1) }, i1 false, i1 true)
  call void @llvm.memmove.p0.p0.i64(ptr %l109, ptr %t211, i64 184, i1 false)
  br label %bb44
bb44:
  %t220 = load i64, ptr %l97
  %t221 = inttoptr i64 %t220 to ptr
  %t222 = call ptr @__olang_scope_alloc_a(ptr %t221, i64 184, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t222, ptr %l109, i64 184, i1 false)
  store ptr %t222, ptr %l110, !tbaa !29
  %t223 = call ptr @__olang_scope_hold(ptr %s0)
  %t224 = ptrtoint ptr %t223 to i64
  store i64 %t224, ptr %l111, !tbaa !24
  %t225 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aLoader_2e3
  br i1 %t225, label %bb45, label %bb46
bb45:
  %t227 = call ptr @__olang_region_make(ptr %s0)
  %t228 = ptrtoint ptr %t227 to i64
  store i64 %t228, ptr %l111, !tbaa !24
  br label %bb46
bb46:
  %t229 = load i64, ptr %l111
  %t230 = inttoptr i64 %t229 to ptr
  %t231 = call %"compiler/source:Names" @compiler_2fsource_3aNames_2ector(ptr %t230)
  store %"compiler/source:Names" %t231, ptr %l113
  br label %bb47
bb47:
  %t232 = load %"compiler/source:Names", ptr %l113
  %t233 = load i64, ptr %l111
  %t234 = inttoptr i64 %t233 to ptr
  %t235 = call ptr @__olang_scope_alloc_a(ptr %t234, i64 104, i64 8)
  store %"compiler/source:Names" %t232, ptr %t235
  %t237 = load ptr, ptr %l96, !tbaa !29
  %t238 = load ptr, ptr %l110, !tbaa !29
  call void @compiler_2fload_3aLoader_2ector(ptr %t236, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d50, i32 0, i32 1) }, ptr %t237, ptr %t238, ptr %t235, ptr %l10)
  call void @llvm.memmove.p0.p0.i64(ptr %l116, ptr %t236, i64 864, i1 false)
  br label %bb48
bb48:
  call void @llvm.memmove.p0.p0.i64(ptr %l15, ptr %l116, i64 864, i1 false)
  store ptr %l15, ptr %l117, !tbaa !29
  %t241 = call ptr @__olang_scope_hold(ptr %s0)
  %t242 = ptrtoint ptr %t241 to i64
  store i64 %t242, ptr %l118, !tbaa !24
  %t243 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aModule_2e0
  br i1 %t243, label %bb49, label %bb50
bb49:
  %t245 = call ptr @__olang_region_make(ptr %s0)
  %t246 = ptrtoint ptr %t245 to i64
  store i64 %t246, ptr %l118, !tbaa !24
  br label %bb50
bb50:
  %t247 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t248 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t248, ptr %l121, !tbaa !27
  %t249 = getelementptr { i64, ptr }, ptr %l121, i32 0, i32 1
  %t250 = load ptr, ptr %t249, !tbaa !27
  %t251 = getelementptr { i64, ptr }, ptr %t250, i64 0
  %t252 = load { i64, ptr }, ptr %t251, !tbaa !37
  %t254 = extractvalue { i64, ptr } %t247, 1
  %t255 = extractvalue { i64, ptr } %t247, 0
  %t256 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d51, i32 0, i32 1) }, 1
  %t257 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d51, i32 0, i32 1) }, 0
  %t258 = add i64 %t255, %t257
  %t260 = extractvalue { i64, ptr } %t252, 1
  %t261 = extractvalue { i64, ptr } %t252, 0
  %t262 = add i64 %t258, %t261
  %t263 = load i64, ptr %l118
  %t264 = inttoptr i64 %t263 to ptr
  %t265 = call ptr @__olang_held_alloc(ptr %t264, i64 %t262)
  call void @olang_textcopy(ptr %t265, ptr %t254, i64 %t255)
  %t266 = getelementptr i8, ptr %t265, i64 %t255
  call void @olang_textcopy(ptr %t266, ptr %t256, i64 %t257)
  %t267 = getelementptr i8, ptr %t266, i64 %t257
  call void @olang_textcopy(ptr %t267, ptr %t260, i64 %t261)
  %t268 = insertvalue { i64, ptr } undef, i64 %t262, 0
  %t269 = insertvalue { i64, ptr } %t268, ptr %t265, 1
  %t271 = load ptr, ptr %l117, !tbaa !29
  %t273 = call i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2eLoad(ptr %s0, ptr %s0, ptr %t271, { i64, ptr } %t269)
  store i64 %t273, ptr %l125
  br label %bb51
bb51:
  call void @compiler_2fnames_3aResolver_2ector(ptr %t274, ptr %s0, ptr %s0, ptr %l15)
  call void @llvm.memmove.p0.p0.i64(ptr %l127, ptr %t274, i64 1144, i1 false)
  br label %bb52
bb52:
  call void @llvm.memmove.p0.p0.i64(ptr %l16, ptr %l127, i64 1144, i1 false)
  call void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eResolve(ptr %s0, ptr %l16)
  br label %bb53
bb53:
  %t277 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t277, ptr %l129
  br label %bb54
bb54:
  %t278 = load %"std/prelude/text:StringBuilder", ptr %l129
  store %"std/prelude/text:StringBuilder" %t278, ptr %l17
  store %olang.scope zeroinitializer, ptr %s14
  %t280 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eAllSaid(ptr %s0, ptr %s14, ptr %l10)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t280, ptr %l131
  br label %bb55
bb55:
  %t281 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l131
  %t282 = call ptr @__olang_scope_alloc_a(ptr %s14, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t281, ptr %t282
  store ptr %t282, ptr %l18, !tbaa !29
  store i64 0, ptr %l19, !tbaa !24
  br label %bb56
bb56:
  store %olang.scope zeroinitializer, ptr %s15
  %t284 = load i64, ptr %l19, !tbaa !24
  store i64 %t284, ptr %l133, !tbaa !24
  %t285 = load ptr, ptr %l18, !tbaa !29
  %t287 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3aSaid_3e_2eLen_3ccompiler_2fdiag_3aSaid_3e(ptr %s14, ptr %t285)
  store i64 %t287, ptr %l135
  br label %bb57
bb57:
  %t288 = load i64, ptr %l133, !tbaa !24
  %t289 = load i64, ptr %l135, !tbaa !24
  %t290 = icmp slt i64 %t288, %t289
  %t292 = xor i1 %t290, true
  br i1 %t292, label %bb58, label %bb59
bb58:
  call void @__olang_scope_close(ptr %s15)
  br label %bb65
bb59:
  br label %bb60
bb60:
  %t294 = load ptr, ptr %l18, !tbaa !29
  %t295 = load i64, ptr %l19, !tbaa !24
  %t298 = call %"compiler/diag:Said" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3aSaid_3e_2eAt_3ccompiler_2fdiag_3aSaid_3e(ptr %s14, ptr %s14, ptr %t294, i64 %t295)
  store %"compiler/diag:Said" %t298, ptr %l140
  br label %bb61
bb61:
  %t299 = load %"compiler/diag:Said", ptr %l140
  store %"compiler/diag:Said" %t299, ptr %l20
  %t300 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t300, ptr %l141, !tbaa !27
  %t301 = getelementptr { i64, ptr }, ptr %l141, i32 0, i32 1
  %t302 = load ptr, ptr %t301, !tbaa !27
  %t303 = getelementptr { i64, ptr }, ptr %t302, i64 1
  %t304 = load { i64, ptr }, ptr %t303, !tbaa !37
  %t305 = getelementptr %"compiler/diag:Said", ptr %l20, i32 0, i32 2
  %t306 = load i64, ptr %t305, !tbaa !24
  %t309 = call { i64, i64 } @compiler_2fnames_2elineCol(ptr %v0, { i64, ptr } %t304, i64 %t306)
  store { i64, i64 } %t309, ptr %l144
  br label %bb62
bb62:
  %t310 = load { i64, i64 }, ptr %l144
  store { i64, i64 } %t310, ptr %l21
  %t311 = getelementptr { i64, i64 }, ptr %l21, i32 0, i32 0
  %t312 = load i64, ptr %t311, !tbaa !24
  %t314 = getelementptr { i64, i64 }, ptr %l21, i32 0, i32 1
  %t315 = load i64, ptr %t314, !tbaa !24
  %t317 = getelementptr %"compiler/diag:Said", ptr %l20, i32 0, i32 0
  %t318 = load { i64, ptr }, ptr %t317, !tbaa !27
  %t322 = extractvalue { i64, ptr } %t318, 1
  %t323 = extractvalue { i64, ptr } %t318, 0
  %t324 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d52, i32 0, i32 1) }, 1
  %t325 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d52, i32 0, i32 1) }, 0
  %t326 = add i64 %t323, %t325
  %t328 = call i64 @__olang_fmt_i64(ptr null, i64 %t312)
  %t329 = add i64 %t326, %t328
  %t330 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d53, i32 0, i32 1) }, 1
  %t331 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d53, i32 0, i32 1) }, 0
  %t332 = add i64 %t329, %t331
  %t334 = call i64 @__olang_fmt_i64(ptr null, i64 %t315)
  %t335 = add i64 %t332, %t334
  %t336 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d54, i32 0, i32 1) }, 1
  %t337 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d54, i32 0, i32 1) }, 0
  %t338 = add i64 %t335, %t337
  %t339 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t338)
  call void @olang_textcopy(ptr %t339, ptr %t322, i64 %t323)
  %t340 = getelementptr i8, ptr %t339, i64 %t323
  call void @olang_textcopy(ptr %t340, ptr %t324, i64 %t325)
  %t341 = getelementptr i8, ptr %t340, i64 %t325
  %t342 = call i64 @__olang_fmt_i64(ptr %t341, i64 %t312)
  %t343 = getelementptr i8, ptr %t341, i64 %t328
  call void @olang_textcopy(ptr %t343, ptr %t330, i64 %t331)
  %t344 = getelementptr i8, ptr %t343, i64 %t331
  %t345 = call i64 @__olang_fmt_i64(ptr %t344, i64 %t315)
  %t346 = getelementptr i8, ptr %t344, i64 %t334
  call void @olang_textcopy(ptr %t346, ptr %t336, i64 %t337)
  %t347 = insertvalue { i64, ptr } undef, i64 %t338, 0
  %t348 = insertvalue { i64, ptr } %t347, ptr %t339, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s15, ptr %l17, { i64, ptr } %t348)
  br label %bb63
bb63:
  call void @__olang_scope_close(ptr %s15)
  br label %bb64
bb64:
  %t352 = load i64, ptr %l19, !tbaa !24
  %t355 = add i64 %t352, 1
  store i64 %t355, ptr %l19, !tbaa !24
  br label %bb56
bb65:
  call void @__olang_scope_close(ptr %s14)
  %t358 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l17)
  store { i64, ptr } %t358, ptr %l157
  br label %bb66
bb66:
  %t359 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t361 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t359)
  store i32 %t361, ptr %l159
  %t362 = icmp ne i32 %t361, 0
  br i1 %t362, label %bb68, label %ok.363, !prof !99
ok.363:
  br label %bb67
bb67:
  br label %bb72
bb68:
  %t364 = load i32, ptr %l159, !tbaa !23
  %t365 = ashr i32 %t364, 16
  %t367 = icmp eq i32 %t365, 1
  store i1 %t367, ptr %l161, !tbaa !21
  %t368 = load i32, ptr %l159, !tbaa !23
  %t369 = ashr i32 %t368, 16
  %t371 = icmp eq i32 %t369, 1
  br i1 %t371, label %bb69, label %bb70
bb69:
  call void @__olang_errpay_pop()
  br label %bb70
bb70:
  br label %bb71
bb71:
  br label %bb72
bb72:
  call void @__olang_scope_close(ptr %s0)
  %t373 = load { i64, ptr }, ptr %l157, !tbaa !27
  store { i64, ptr } %t373, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fnames_3aResolver_2ector(ptr %out, ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l4 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l5 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l6 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l7 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l8 = alloca i64
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l10 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l12 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l14 = alloca i1
  %l15 = alloca i1
  %l16 = alloca i64
  %l17 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l18 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l19 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l20 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l21 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l22 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l23 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l24 = alloca i1
  %l25 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l26 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l27 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l30 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l31 = alloca i64
  %l33 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l35 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l36 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l37 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l38 = alloca i64
  %l40 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l42 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l43 = alloca i64
  %l45 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l47 = alloca i64
  %l49 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l51 = alloca i64
  %l53 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l55 = alloca i64
  %l57 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l59 = alloca i64
  %l61 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l63 = alloca i64
  %l65 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l67 = alloca i64
  %l69 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l71 = alloca i64
  %l73 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l75 = alloca i64
  %l77 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l79 = alloca i64
  %l81 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l83 = alloca i64
  %l85 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l87 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l88 = alloca i64
  %l90 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l92 = alloca i64
  %l94 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l96 = alloca i64
  %l98 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l100 = alloca %"compiler/names:Resolver"
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l1, !tbaa !29
  %t3 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %l30
  br label %bb1
bb1:
  %t4 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l30
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %l2
  %t5 = call ptr @__olang_scope_hold(ptr %v1)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l31, !tbaa !24
  %t7 = load i1, ptr @olang_2esole_2ecompiler_2fnames_3aResolver_2e2
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = call ptr @__olang_region_make(ptr %v1)
  %t10 = ptrtoint ptr %t9 to i64
  store i64 %t10, ptr %l31, !tbaa !24
  br label %bb3
bb3:
  %t11 = load i64, ptr %l31
  %t12 = inttoptr i64 %t11 to ptr
  %t13 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e(ptr %t12)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t13, ptr %l33
  br label %bb4
bb4:
  %t14 = load i1, ptr @olang_2esole_2ecompiler_2fnames_3aResolver_2e2
  br i1 %t14, label %bb5, label %bb6
bb5:
  %t16 = load i64, ptr %l31
  %t17 = inttoptr i64 %t16 to ptr
  %t18 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l33, i32 0, i32 2
  %t19 = load { i64, ptr }, ptr %t18
  %t20 = extractvalue { i64, ptr } %t19, 1
  %t21 = call ptr @__olang_region_or(ptr %t20, ptr null)
  %t22 = call ptr @__olang_region_home(ptr %t21)
  %t23 = icmp ne ptr %t22, null
  %t24 = select i1 %t23, ptr %t22, ptr null
  %t25 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l33, i32 0, i32 1
  %t26 = load { i64, ptr }, ptr %t25
  %t27 = extractvalue { i64, ptr } %t26, 1
  %t28 = call ptr @__olang_region_or(ptr %t27, ptr null)
  %t29 = call ptr @__olang_region_home(ptr %t28)
  %t30 = icmp ne ptr %t29, null
  %t31 = select i1 %t30, ptr %t29, ptr %t24
  %t32 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l33, i32 0, i32 0
  %t33 = load { i64, ptr }, ptr %t32
  %t34 = extractvalue { i64, ptr } %t33, 1
  %t35 = call ptr @__olang_region_or(ptr %t34, ptr null)
  %t36 = call ptr @__olang_region_home(ptr %t35)
  %t37 = icmp ne ptr %t36, null
  %t38 = select i1 %t37, ptr %t36, ptr %t31
  call void @__olang_region_settle_in(ptr %t17, ptr %t38)
  br label %bb6
bb6:
  %t39 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l33
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t39, ptr %l3
  %t40 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2fnames_3aRef_3e(ptr %v1)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t40, ptr %l35
  br label %bb7
bb7:
  %t41 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l35
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t41, ptr %l4
  %t42 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fnames_3aRef_3e(ptr %v1)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t42, ptr %l36
  br label %bb8
bb8:
  %t43 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l36
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t43, ptr %l5
  %t44 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fnames_3aRef_3e(ptr %v1)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t44, ptr %l37
  br label %bb9
bb9:
  %t45 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l37
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t45, ptr %l6
  %t46 = call ptr @__olang_scope_hold(ptr %v1)
  %t47 = ptrtoint ptr %t46 to i64
  store i64 %t47, ptr %l38, !tbaa !24
  %t48 = load i1, ptr @olang_2esole_2ecompiler_2fnames_3aResolver_2e6
  br i1 %t48, label %bb10, label %bb11
bb10:
  %t50 = call ptr @__olang_region_make(ptr %v1)
  %t51 = ptrtoint ptr %t50 to i64
  store i64 %t51, ptr %l38, !tbaa !24
  br label %bb11
bb11:
  %t52 = load i64, ptr %l38
  %t53 = inttoptr i64 %t52 to ptr
  %t54 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %t53)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t54, ptr %l40
  br label %bb12
bb12:
  %t55 = load i1, ptr @olang_2esole_2ecompiler_2fnames_3aResolver_2e6
  br i1 %t55, label %bb13, label %bb14
bb13:
  %t57 = load i64, ptr %l38
  %t58 = inttoptr i64 %t57 to ptr
  %t59 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l40, i32 0, i32 2
  %t60 = load { i64, ptr }, ptr %t59
  %t61 = extractvalue { i64, ptr } %t60, 1
  %t62 = call ptr @__olang_region_or(ptr %t61, ptr null)
  %t63 = call ptr @__olang_region_home(ptr %t62)
  %t64 = icmp ne ptr %t63, null
  %t65 = select i1 %t64, ptr %t63, ptr null
  %t66 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l40, i32 0, i32 1
  %t67 = load { i64, ptr }, ptr %t66
  %t68 = extractvalue { i64, ptr } %t67, 1
  %t69 = call ptr @__olang_region_or(ptr %t68, ptr null)
  %t70 = call ptr @__olang_region_home(ptr %t69)
  %t71 = icmp ne ptr %t70, null
  %t72 = select i1 %t71, ptr %t70, ptr %t65
  %t73 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l40, i32 0, i32 0
  %t74 = load { i64, ptr }, ptr %t73
  %t75 = extractvalue { i64, ptr } %t74, 1
  %t76 = call ptr @__olang_region_or(ptr %t75, ptr null)
  %t77 = call ptr @__olang_region_home(ptr %t76)
  %t78 = icmp ne ptr %t77, null
  %t79 = select i1 %t78, ptr %t77, ptr %t72
  call void @__olang_region_settle_in(ptr %t58, ptr %t79)
  br label %bb14
bb14:
  %t80 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l40
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t80, ptr %l7
  store i64 -1, ptr %l8, !tbaa !24
  %t81 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3alocal_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t81, ptr %l42
  br label %bb15
bb15:
  %t82 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l42
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t82, ptr %l9
  %t83 = call ptr @__olang_scope_hold(ptr %v1)
  %t84 = ptrtoint ptr %t83 to i64
  store i64 %t84, ptr %l43, !tbaa !24
  %t85 = load i1, ptr @olang_2esole_2ecompiler_2fnames_3aResolver_2e9
  br i1 %t85, label %bb16, label %bb17
bb16:
  %t87 = call ptr @__olang_region_make(ptr %v1)
  %t88 = ptrtoint ptr %t87 to i64
  store i64 %t88, ptr %l43, !tbaa !24
  br label %bb17
bb17:
  %t89 = load i64, ptr %l43
  %t90 = inttoptr i64 %t89 to ptr
  %t91 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e(ptr %t90)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t91, ptr %l45
  br label %bb18
bb18:
  %t92 = load i1, ptr @olang_2esole_2ecompiler_2fnames_3aResolver_2e9
  br i1 %t92, label %bb19, label %bb20
bb19:
  %t94 = load i64, ptr %l43
  %t95 = inttoptr i64 %t94 to ptr
  %t96 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l45, i32 0, i32 2
  %t97 = load { i64, ptr }, ptr %t96
  %t98 = extractvalue { i64, ptr } %t97, 1
  %t99 = call ptr @__olang_region_or(ptr %t98, ptr null)
  %t100 = call ptr @__olang_region_home(ptr %t99)
  %t101 = icmp ne ptr %t100, null
  %t102 = select i1 %t101, ptr %t100, ptr null
  %t103 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l45, i32 0, i32 1
  %t104 = load { i64, ptr }, ptr %t103
  %t105 = extractvalue { i64, ptr } %t104, 1
  %t106 = call ptr @__olang_region_or(ptr %t105, ptr null)
  %t107 = call ptr @__olang_region_home(ptr %t106)
  %t108 = icmp ne ptr %t107, null
  %t109 = select i1 %t108, ptr %t107, ptr %t102
  %t110 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l45, i32 0, i32 0
  %t111 = load { i64, ptr }, ptr %t110
  %t112 = extractvalue { i64, ptr } %t111, 1
  %t113 = call ptr @__olang_region_or(ptr %t112, ptr null)
  %t114 = call ptr @__olang_region_home(ptr %t113)
  %t115 = icmp ne ptr %t114, null
  %t116 = select i1 %t115, ptr %t114, ptr %t109
  call void @__olang_region_settle_in(ptr %t95, ptr %t116)
  br label %bb20
bb20:
  %t117 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l45
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t117, ptr %l10
  %t118 = call ptr @__olang_scope_hold(ptr %v1)
  %t119 = ptrtoint ptr %t118 to i64
  store i64 %t119, ptr %l47, !tbaa !24
  %t120 = load i1, ptr @olang_2esole_2ecompiler_2fnames_3aResolver_2e10
  br i1 %t120, label %bb21, label %bb22
bb21:
  %t122 = call ptr @__olang_region_make(ptr %v1)
  %t123 = ptrtoint ptr %t122 to i64
  store i64 %t123, ptr %l47, !tbaa !24
  br label %bb22
bb22:
  %t124 = load i64, ptr %l47
  %t125 = inttoptr i64 %t124 to ptr
  %t126 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fsource_3aNameId_2c_20I64_3e_3e_2ector(ptr %t125, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t126, ptr %l49
  br label %bb23
bb23:
  %t127 = load i1, ptr @olang_2esole_2ecompiler_2fnames_3aResolver_2e10
  br i1 %t127, label %bb24, label %bb25
bb24:
  %t129 = load i64, ptr %l47
  %t130 = inttoptr i64 %t129 to ptr
  %t131 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l49, i32 0, i32 0
  %t132 = load { i64, ptr }, ptr %t131
  %t133 = extractvalue { i64, ptr } %t132, 1
  %t134 = call ptr @__olang_region_or(ptr %t133, ptr null)
  %t135 = call ptr @__olang_region_home(ptr %t134)
  %t136 = icmp ne ptr %t135, null
  %t137 = select i1 %t136, ptr %t135, ptr null
  call void @__olang_region_settle_in(ptr %t130, ptr %t137)
  br label %bb25
bb25:
  %t138 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l49
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t138, ptr %l11
  %t139 = call ptr @__olang_scope_hold(ptr %v1)
  %t140 = ptrtoint ptr %t139 to i64
  store i64 %t140, ptr %l51, !tbaa !24
  %t141 = load i1, ptr @olang_2esole_2ecompiler_2fnames_3aResolver_2e11
  br i1 %t141, label %bb26, label %bb27
bb26:
  %t143 = call ptr @__olang_region_make(ptr %v1)
  %t144 = ptrtoint ptr %t143 to i64
  store i64 %t144, ptr %l51, !tbaa !24
  br label %bb27
bb27:
  %t145 = load i64, ptr %l51
  %t146 = inttoptr i64 %t145 to ptr
  %t147 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %t146, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t147, ptr %l53
  br label %bb28
bb28:
  %t148 = load i1, ptr @olang_2esole_2ecompiler_2fnames_3aResolver_2e11
  br i1 %t148, label %bb29, label %bb30
bb29:
  %t150 = load i64, ptr %l51
  %t151 = inttoptr i64 %t150 to ptr
  %t152 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l53, i32 0, i32 0
  %t153 = load { i64, ptr }, ptr %t152
  %t154 = extractvalue { i64, ptr } %t153, 1
  %t155 = call ptr @__olang_region_or(ptr %t154, ptr null)
  %t156 = call ptr @__olang_region_home(ptr %t155)
  %t157 = icmp ne ptr %t156, null
  %t158 = select i1 %t157, ptr %t156, ptr null
  call void @__olang_region_settle_in(ptr %t151, ptr %t158)
  br label %bb30
bb30:
  %t159 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l53
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t159, ptr %l12
  %t160 = call ptr @__olang_scope_hold(ptr %v1)
  %t161 = ptrtoint ptr %t160 to i64
  store i64 %t161, ptr %l55, !tbaa !24
  %t162 = load i1, ptr @olang_2esole_2ecompiler_2fnames_3aResolver_2e12
  br i1 %t162, label %bb31, label %bb32
bb31:
  %t164 = call ptr @__olang_region_make(ptr %v1)
  %t165 = ptrtoint ptr %t164 to i64
  store i64 %t165, ptr %l55, !tbaa !24
  br label %bb32
bb32:
  %t166 = load i64, ptr %l55
  %t167 = inttoptr i64 %t166 to ptr
  %t168 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %t167, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t168, ptr %l57
  br label %bb33
bb33:
  %t169 = load i1, ptr @olang_2esole_2ecompiler_2fnames_3aResolver_2e12
  br i1 %t169, label %bb34, label %bb35
bb34:
  %t171 = load i64, ptr %l55
  %t172 = inttoptr i64 %t171 to ptr
  %t173 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l57, i32 0, i32 0
  %t174 = load { i64, ptr }, ptr %t173
  %t175 = extractvalue { i64, ptr } %t174, 1
  %t176 = call ptr @__olang_region_or(ptr %t175, ptr null)
  %t177 = call ptr @__olang_region_home(ptr %t176)
  %t178 = icmp ne ptr %t177, null
  %t179 = select i1 %t178, ptr %t177, ptr null
  call void @__olang_region_settle_in(ptr %t172, ptr %t179)
  br label %bb35
bb35:
  %t180 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l57
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t180, ptr %l13
  store i1 false, ptr %l14, !tbaa !21
  store i1 false, ptr %l15, !tbaa !21
  store i64 0, ptr %l16, !tbaa !24
  %t181 = call ptr @__olang_scope_hold(ptr %v1)
  %t182 = ptrtoint ptr %t181 to i64
  store i64 %t182, ptr %l59, !tbaa !24
  %t183 = load i1, ptr @olang_2esole_2ecompiler_2fnames_3aResolver_2e16
  br i1 %t183, label %bb36, label %bb37
bb36:
  %t185 = call ptr @__olang_region_make(ptr %v1)
  %t186 = ptrtoint ptr %t185 to i64
  store i64 %t186, ptr %l59, !tbaa !24
  br label %bb37
bb37:
  %t187 = load i64, ptr %l59
  %t188 = inttoptr i64 %t187 to ptr
  %t189 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fsource_3aNameId_2c_20I64_3e_3e_2ector(ptr %t188, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t189, ptr %l61
  br label %bb38
bb38:
  %t190 = load i1, ptr @olang_2esole_2ecompiler_2fnames_3aResolver_2e16
  br i1 %t190, label %bb39, label %bb40
bb39:
  %t192 = load i64, ptr %l59
  %t193 = inttoptr i64 %t192 to ptr
  %t194 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l61, i32 0, i32 0
  %t195 = load { i64, ptr }, ptr %t194
  %t196 = extractvalue { i64, ptr } %t195, 1
  %t197 = call ptr @__olang_region_or(ptr %t196, ptr null)
  %t198 = call ptr @__olang_region_home(ptr %t197)
  %t199 = icmp ne ptr %t198, null
  %t200 = select i1 %t199, ptr %t198, ptr null
  call void @__olang_region_settle_in(ptr %t193, ptr %t200)
  br label %bb40
bb40:
  %t201 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l61
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t201, ptr %l17
  %t202 = call ptr @__olang_scope_hold(ptr %v1)
  %t203 = ptrtoint ptr %t202 to i64
  store i64 %t203, ptr %l63, !tbaa !24
  %t204 = load i1, ptr @olang_2esole_2ecompiler_2fnames_3aResolver_2e17
  br i1 %t204, label %bb41, label %bb42
bb41:
  %t206 = call ptr @__olang_region_make(ptr %v1)
  %t207 = ptrtoint ptr %t206 to i64
  store i64 %t207, ptr %l63, !tbaa !24
  br label %bb42
bb42:
  %t208 = load i64, ptr %l63
  %t209 = inttoptr i64 %t208 to ptr
  %t210 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e(ptr %t209)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t210, ptr %l65
  br label %bb43
bb43:
  %t211 = load i1, ptr @olang_2esole_2ecompiler_2fnames_3aResolver_2e17
  br i1 %t211, label %bb44, label %bb45
bb44:
  %t213 = load i64, ptr %l63
  %t214 = inttoptr i64 %t213 to ptr
  %t215 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l65, i32 0, i32 2
  %t216 = load { i64, ptr }, ptr %t215
  %t217 = extractvalue { i64, ptr } %t216, 1
  %t218 = call ptr @__olang_region_or(ptr %t217, ptr null)
  %t219 = call ptr @__olang_region_home(ptr %t218)
  %t220 = icmp ne ptr %t219, null
  %t221 = select i1 %t220, ptr %t219, ptr null
  %t222 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l65, i32 0, i32 1
  %t223 = load { i64, ptr }, ptr %t222
  %t224 = extractvalue { i64, ptr } %t223, 1
  %t225 = call ptr @__olang_region_or(ptr %t224, ptr null)
  %t226 = call ptr @__olang_region_home(ptr %t225)
  %t227 = icmp ne ptr %t226, null
  %t228 = select i1 %t227, ptr %t226, ptr %t221
  %t229 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l65, i32 0, i32 0
  %t230 = load { i64, ptr }, ptr %t229
  %t231 = extractvalue { i64, ptr } %t230, 1
  %t232 = call ptr @__olang_region_or(ptr %t231, ptr null)
  %t233 = call ptr @__olang_region_home(ptr %t232)
  %t234 = icmp ne ptr %t233, null
  %t235 = select i1 %t234, ptr %t233, ptr %t228
  call void @__olang_region_settle_in(ptr %t214, ptr %t235)
  br label %bb45
bb45:
  %t236 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l65
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t236, ptr %l18
  %t237 = call ptr @__olang_scope_hold(ptr %v1)
  %t238 = ptrtoint ptr %t237 to i64
  store i64 %t238, ptr %l67, !tbaa !24
  %t239 = load i1, ptr @olang_2esole_2ecompiler_2fnames_3aResolver_2e18
  br i1 %t239, label %bb46, label %bb47
bb46:
  %t241 = call ptr @__olang_region_make(ptr %v1)
  %t242 = ptrtoint ptr %t241 to i64
  store i64 %t242, ptr %l67, !tbaa !24
  br label %bb47
bb47:
  %t243 = load i64, ptr %l67
  %t244 = inttoptr i64 %t243 to ptr
  %t245 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ector(ptr %t244, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t245, ptr %l69
  br label %bb48
bb48:
  %t246 = load i1, ptr @olang_2esole_2ecompiler_2fnames_3aResolver_2e18
  br i1 %t246, label %bb49, label %bb50
bb49:
  %t248 = load i64, ptr %l67
  %t249 = inttoptr i64 %t248 to ptr
  %t250 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l69, i32 0, i32 0
  %t251 = load { i64, ptr }, ptr %t250
  %t252 = extractvalue { i64, ptr } %t251, 1
  %t253 = call ptr @__olang_region_or(ptr %t252, ptr null)
  %t254 = call ptr @__olang_region_home(ptr %t253)
  %t255 = icmp ne ptr %t254, null
  %t256 = select i1 %t255, ptr %t254, ptr null
  call void @__olang_region_settle_in(ptr %t249, ptr %t256)
  br label %bb50
bb50:
  %t257 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l69
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t257, ptr %l19
  %t258 = call ptr @__olang_scope_hold(ptr %v1)
  %t259 = ptrtoint ptr %t258 to i64
  store i64 %t259, ptr %l71, !tbaa !24
  %t260 = load i1, ptr @olang_2esole_2ecompiler_2fnames_3aResolver_2e19
  br i1 %t260, label %bb51, label %bb52
bb51:
  %t262 = call ptr @__olang_region_make(ptr %v1)
  %t263 = ptrtoint ptr %t262 to i64
  store i64 %t263, ptr %l71, !tbaa !24
  br label %bb52
bb52:
  %t264 = load i64, ptr %l71
  %t265 = inttoptr i64 %t264 to ptr
  %t266 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aUnread_3e_2ector(ptr %t265, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t266, ptr %l73
  br label %bb53
bb53:
  %t267 = load i1, ptr @olang_2esole_2ecompiler_2fnames_3aResolver_2e19
  br i1 %t267, label %bb54, label %bb55
bb54:
  %t269 = load i64, ptr %l71
  %t270 = inttoptr i64 %t269 to ptr
  %t271 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l73, i32 0, i32 0
  %t272 = load { i64, ptr }, ptr %t271
  %t273 = extractvalue { i64, ptr } %t272, 1
  %t274 = call ptr @__olang_region_or(ptr %t273, ptr null)
  %t275 = call ptr @__olang_region_home(ptr %t274)
  %t276 = icmp ne ptr %t275, null
  %t277 = select i1 %t276, ptr %t275, ptr null
  call void @__olang_region_settle_in(ptr %t270, ptr %t277)
  br label %bb55
bb55:
  %t278 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l73
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t278, ptr %l20
  %t279 = call ptr @__olang_scope_hold(ptr %v1)
  %t280 = ptrtoint ptr %t279 to i64
  store i64 %t280, ptr %l75, !tbaa !24
  %t281 = load i1, ptr @olang_2esole_2ecompiler_2fnames_3aResolver_2e20
  br i1 %t281, label %bb56, label %bb57
bb56:
  %t283 = call ptr @__olang_region_make(ptr %v1)
  %t284 = ptrtoint ptr %t283 to i64
  store i64 %t284, ptr %l75, !tbaa !24
  br label %bb57
bb57:
  %t285 = load i64, ptr %l75
  %t286 = inttoptr i64 %t285 to ptr
  %t287 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %t286)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t287, ptr %l77
  br label %bb58
bb58:
  %t288 = load i1, ptr @olang_2esole_2ecompiler_2fnames_3aResolver_2e20
  br i1 %t288, label %bb59, label %bb60
bb59:
  %t290 = load i64, ptr %l75
  %t291 = inttoptr i64 %t290 to ptr
  %t292 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l77, i32 0, i32 2
  %t293 = load { i64, ptr }, ptr %t292
  %t294 = extractvalue { i64, ptr } %t293, 1
  %t295 = call ptr @__olang_region_or(ptr %t294, ptr null)
  %t296 = call ptr @__olang_region_home(ptr %t295)
  %t297 = icmp ne ptr %t296, null
  %t298 = select i1 %t297, ptr %t296, ptr null
  %t299 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l77, i32 0, i32 1
  %t300 = load { i64, ptr }, ptr %t299
  %t301 = extractvalue { i64, ptr } %t300, 1
  %t302 = call ptr @__olang_region_or(ptr %t301, ptr null)
  %t303 = call ptr @__olang_region_home(ptr %t302)
  %t304 = icmp ne ptr %t303, null
  %t305 = select i1 %t304, ptr %t303, ptr %t298
  %t306 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l77, i32 0, i32 0
  %t307 = load { i64, ptr }, ptr %t306
  %t308 = extractvalue { i64, ptr } %t307, 1
  %t309 = call ptr @__olang_region_or(ptr %t308, ptr null)
  %t310 = call ptr @__olang_region_home(ptr %t309)
  %t311 = icmp ne ptr %t310, null
  %t312 = select i1 %t311, ptr %t310, ptr %t305
  call void @__olang_region_settle_in(ptr %t291, ptr %t312)
  br label %bb60
bb60:
  %t313 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l77
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t313, ptr %l21
  %t314 = call ptr @__olang_scope_hold(ptr %v1)
  %t315 = ptrtoint ptr %t314 to i64
  store i64 %t315, ptr %l79, !tbaa !24
  %t316 = load i1, ptr @olang_2esole_2ecompiler_2fnames_3aResolver_2e21
  br i1 %t316, label %bb61, label %bb62
bb61:
  %t318 = call ptr @__olang_region_make(ptr %v1)
  %t319 = ptrtoint ptr %t318 to i64
  store i64 %t319, ptr %l79, !tbaa !24
  br label %bb62
bb62:
  %t320 = load i64, ptr %l79
  %t321 = inttoptr i64 %t320 to ptr
  %t322 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20compiler_2fsource_3aSpan_3e_3e_2ector(ptr %t321, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t322, ptr %l81
  br label %bb63
bb63:
  %t323 = load i1, ptr @olang_2esole_2ecompiler_2fnames_3aResolver_2e21
  br i1 %t323, label %bb64, label %bb65
bb64:
  %t325 = load i64, ptr %l79
  %t326 = inttoptr i64 %t325 to ptr
  %t327 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l81, i32 0, i32 0
  %t328 = load { i64, ptr }, ptr %t327
  %t329 = extractvalue { i64, ptr } %t328, 1
  %t330 = call ptr @__olang_region_or(ptr %t329, ptr null)
  %t331 = call ptr @__olang_region_home(ptr %t330)
  %t332 = icmp ne ptr %t331, null
  %t333 = select i1 %t332, ptr %t331, ptr null
  call void @__olang_region_settle_in(ptr %t326, ptr %t333)
  br label %bb65
bb65:
  %t334 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l81
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t334, ptr %l22
  %t335 = call ptr @__olang_scope_hold(ptr %v1)
  %t336 = ptrtoint ptr %t335 to i64
  store i64 %t336, ptr %l83, !tbaa !24
  %t337 = load i1, ptr @olang_2esole_2ecompiler_2fnames_3aResolver_2e22
  br i1 %t337, label %bb66, label %bb67
bb66:
  %t339 = call ptr @__olang_region_make(ptr %v1)
  %t340 = ptrtoint ptr %t339 to i64
  store i64 %t340, ptr %l83, !tbaa !24
  br label %bb67
bb67:
  %t341 = load i64, ptr %l83
  %t342 = inttoptr i64 %t341 to ptr
  %t343 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %t342)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t343, ptr %l85
  br label %bb68
bb68:
  %t344 = load i1, ptr @olang_2esole_2ecompiler_2fnames_3aResolver_2e22
  br i1 %t344, label %bb69, label %bb70
bb69:
  %t346 = load i64, ptr %l83
  %t347 = inttoptr i64 %t346 to ptr
  %t348 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l85, i32 0, i32 2
  %t349 = load { i64, ptr }, ptr %t348
  %t350 = extractvalue { i64, ptr } %t349, 1
  %t351 = call ptr @__olang_region_or(ptr %t350, ptr null)
  %t352 = call ptr @__olang_region_home(ptr %t351)
  %t353 = icmp ne ptr %t352, null
  %t354 = select i1 %t353, ptr %t352, ptr null
  %t355 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l85, i32 0, i32 1
  %t356 = load { i64, ptr }, ptr %t355
  %t357 = extractvalue { i64, ptr } %t356, 1
  %t358 = call ptr @__olang_region_or(ptr %t357, ptr null)
  %t359 = call ptr @__olang_region_home(ptr %t358)
  %t360 = icmp ne ptr %t359, null
  %t361 = select i1 %t360, ptr %t359, ptr %t354
  %t362 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l85, i32 0, i32 0
  %t363 = load { i64, ptr }, ptr %t362
  %t364 = extractvalue { i64, ptr } %t363, 1
  %t365 = call ptr @__olang_region_or(ptr %t364, ptr null)
  %t366 = call ptr @__olang_region_home(ptr %t365)
  %t367 = icmp ne ptr %t366, null
  %t368 = select i1 %t367, ptr %t366, ptr %t361
  call void @__olang_region_settle_in(ptr %t347, ptr %t368)
  br label %bb70
bb70:
  %t369 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l85
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t369, ptr %l23
  store i1 false, ptr %l24, !tbaa !21
  %t370 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3araised_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t370, ptr %l87
  br label %bb71
bb71:
  %t371 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l87
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t371, ptr %l25
  %t372 = call ptr @__olang_scope_hold(ptr %v1)
  %t373 = ptrtoint ptr %t372 to i64
  store i64 %t373, ptr %l88, !tbaa !24
  %t374 = load i1, ptr @olang_2esole_2ecompiler_2fnames_3aResolver_2e25
  br i1 %t374, label %bb72, label %bb73
bb72:
  %t376 = call ptr @__olang_region_make(ptr %v1)
  %t377 = ptrtoint ptr %t376 to i64
  store i64 %t377, ptr %l88, !tbaa !24
  br label %bb73
bb73:
  %t378 = load i64, ptr %l88
  %t379 = inttoptr i64 %t378 to ptr
  %t380 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %t379, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t380, ptr %l90
  br label %bb74
bb74:
  %t381 = load i1, ptr @olang_2esole_2ecompiler_2fnames_3aResolver_2e25
  br i1 %t381, label %bb75, label %bb76
bb75:
  %t383 = load i64, ptr %l88
  %t384 = inttoptr i64 %t383 to ptr
  %t385 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l90, i32 0, i32 0
  %t386 = load { i64, ptr }, ptr %t385
  %t387 = extractvalue { i64, ptr } %t386, 1
  %t388 = call ptr @__olang_region_or(ptr %t387, ptr null)
  %t389 = call ptr @__olang_region_home(ptr %t388)
  %t390 = icmp ne ptr %t389, null
  %t391 = select i1 %t390, ptr %t389, ptr null
  call void @__olang_region_settle_in(ptr %t384, ptr %t391)
  br label %bb76
bb76:
  %t392 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l90
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t392, ptr %l26
  %t393 = call ptr @__olang_scope_hold(ptr %v1)
  %t394 = ptrtoint ptr %t393 to i64
  store i64 %t394, ptr %l92, !tbaa !24
  %t395 = load i1, ptr @olang_2esole_2ecompiler_2fnames_3aResolver_2e26
  br i1 %t395, label %bb77, label %bb78
bb77:
  %t397 = call ptr @__olang_region_make(ptr %v1)
  %t398 = ptrtoint ptr %t397 to i64
  store i64 %t398, ptr %l92, !tbaa !24
  br label %bb78
bb78:
  %t399 = load i64, ptr %l92
  %t400 = inttoptr i64 %t399 to ptr
  %t401 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t400, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t401, ptr %l94
  br label %bb79
bb79:
  %t402 = load i1, ptr @olang_2esole_2ecompiler_2fnames_3aResolver_2e26
  br i1 %t402, label %bb80, label %bb81
bb80:
  %t404 = load i64, ptr %l92
  %t405 = inttoptr i64 %t404 to ptr
  %t406 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l94, i32 0, i32 0
  %t407 = load { i64, ptr }, ptr %t406
  %t408 = extractvalue { i64, ptr } %t407, 1
  %t409 = call ptr @__olang_region_or(ptr %t408, ptr null)
  %t410 = call ptr @__olang_region_home(ptr %t409)
  %t411 = icmp ne ptr %t410, null
  %t412 = select i1 %t411, ptr %t410, ptr null
  call void @__olang_region_settle_in(ptr %t405, ptr %t412)
  br label %bb81
bb81:
  %t413 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l94
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t413, ptr %l27
  %t414 = call ptr @__olang_scope_hold(ptr %v1)
  %t415 = ptrtoint ptr %t414 to i64
  store i64 %t415, ptr %l96, !tbaa !24
  %t416 = load i1, ptr @olang_2esole_2ecompiler_2fnames_3aResolver_2e27
  br i1 %t416, label %bb82, label %bb83
bb82:
  %t418 = call ptr @__olang_region_make(ptr %v1)
  %t419 = ptrtoint ptr %t418 to i64
  store i64 %t419, ptr %l96, !tbaa !24
  br label %bb83
bb83:
  %t420 = load i64, ptr %l96
  %t421 = inttoptr i64 %t420 to ptr
  %t422 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %t421)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t422, ptr %l98
  br label %bb84
bb84:
  %t423 = load i1, ptr @olang_2esole_2ecompiler_2fnames_3aResolver_2e27
  br i1 %t423, label %bb85, label %bb86
bb85:
  %t425 = load i64, ptr %l96
  %t426 = inttoptr i64 %t425 to ptr
  %t427 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l98, i32 0, i32 2
  %t428 = load { i64, ptr }, ptr %t427
  %t429 = extractvalue { i64, ptr } %t428, 1
  %t430 = call ptr @__olang_region_or(ptr %t429, ptr null)
  %t431 = call ptr @__olang_region_home(ptr %t430)
  %t432 = icmp ne ptr %t431, null
  %t433 = select i1 %t432, ptr %t431, ptr null
  %t434 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l98, i32 0, i32 1
  %t435 = load { i64, ptr }, ptr %t434
  %t436 = extractvalue { i64, ptr } %t435, 1
  %t437 = call ptr @__olang_region_or(ptr %t436, ptr null)
  %t438 = call ptr @__olang_region_home(ptr %t437)
  %t439 = icmp ne ptr %t438, null
  %t440 = select i1 %t439, ptr %t438, ptr %t433
  %t441 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l98, i32 0, i32 0
  %t442 = load { i64, ptr }, ptr %t441
  %t443 = extractvalue { i64, ptr } %t442, 1
  %t444 = call ptr @__olang_region_or(ptr %t443, ptr null)
  %t445 = call ptr @__olang_region_home(ptr %t444)
  %t446 = icmp ne ptr %t445, null
  %t447 = select i1 %t446, ptr %t445, ptr %t440
  call void @__olang_region_settle_in(ptr %t426, ptr %t447)
  br label %bb86
bb86:
  %t448 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l98
  %t449 = getelementptr %"compiler/names:Resolver", ptr %l100, i32 0, i32 0
  %t450 = load ptr, ptr %l1, !tbaa !29
  store ptr %t450, ptr %t449, !tbaa !29
  %t451 = getelementptr %"compiler/names:Resolver", ptr %l100, i32 0, i32 1
  %t452 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t452, ptr %t451
  %t453 = getelementptr %"compiler/names:Resolver", ptr %l100, i32 0, i32 2
  %t454 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l3
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t454, ptr %t453
  %t455 = getelementptr %"compiler/names:Resolver", ptr %l100, i32 0, i32 3
  %t456 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l4
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t456, ptr %t455
  %t457 = getelementptr %"compiler/names:Resolver", ptr %l100, i32 0, i32 4
  %t458 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l5
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t458, ptr %t457
  %t459 = getelementptr %"compiler/names:Resolver", ptr %l100, i32 0, i32 5
  %t460 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l6
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t460, ptr %t459
  %t461 = getelementptr %"compiler/names:Resolver", ptr %l100, i32 0, i32 6
  %t462 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l7
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t462, ptr %t461
  %t463 = getelementptr %"compiler/names:Resolver", ptr %l100, i32 0, i32 7
  %t464 = load i64, ptr %l8, !tbaa !24
  store i64 %t464, ptr %t463, !tbaa !24
  %t465 = getelementptr %"compiler/names:Resolver", ptr %l100, i32 0, i32 8
  %t466 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l9
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t466, ptr %t465
  %t467 = getelementptr %"compiler/names:Resolver", ptr %l100, i32 0, i32 9
  %t468 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l10
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t468, ptr %t467
  %t469 = getelementptr %"compiler/names:Resolver", ptr %l100, i32 0, i32 10
  %t470 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l11
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t470, ptr %t469
  %t471 = getelementptr %"compiler/names:Resolver", ptr %l100, i32 0, i32 11
  %t472 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l12
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t472, ptr %t471
  %t473 = getelementptr %"compiler/names:Resolver", ptr %l100, i32 0, i32 12
  %t474 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l13
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t474, ptr %t473
  %t475 = getelementptr %"compiler/names:Resolver", ptr %l100, i32 0, i32 13
  %t476 = load i1, ptr %l14, !tbaa !21
  store i1 %t476, ptr %t475, !tbaa !21
  %t477 = getelementptr %"compiler/names:Resolver", ptr %l100, i32 0, i32 14
  %t478 = load i1, ptr %l15, !tbaa !21
  store i1 %t478, ptr %t477, !tbaa !21
  %t479 = getelementptr %"compiler/names:Resolver", ptr %l100, i32 0, i32 15
  %t480 = load i64, ptr %l16, !tbaa !24
  store i64 %t480, ptr %t479, !tbaa !24
  %t481 = getelementptr %"compiler/names:Resolver", ptr %l100, i32 0, i32 16
  %t482 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l17
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t482, ptr %t481
  %t483 = getelementptr %"compiler/names:Resolver", ptr %l100, i32 0, i32 17
  %t484 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l18
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t484, ptr %t483
  %t485 = getelementptr %"compiler/names:Resolver", ptr %l100, i32 0, i32 18
  %t486 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l19
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t486, ptr %t485
  %t487 = getelementptr %"compiler/names:Resolver", ptr %l100, i32 0, i32 19
  %t488 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l20
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t488, ptr %t487
  %t489 = getelementptr %"compiler/names:Resolver", ptr %l100, i32 0, i32 20
  %t490 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l21
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t490, ptr %t489
  %t491 = getelementptr %"compiler/names:Resolver", ptr %l100, i32 0, i32 21
  %t492 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l22
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t492, ptr %t491
  %t493 = getelementptr %"compiler/names:Resolver", ptr %l100, i32 0, i32 22
  %t494 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l23
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t494, ptr %t493
  %t495 = getelementptr %"compiler/names:Resolver", ptr %l100, i32 0, i32 23
  %t496 = load i1, ptr %l24, !tbaa !21
  store i1 %t496, ptr %t495, !tbaa !21
  %t497 = getelementptr %"compiler/names:Resolver", ptr %l100, i32 0, i32 24
  %t498 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l25
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t498, ptr %t497
  %t499 = getelementptr %"compiler/names:Resolver", ptr %l100, i32 0, i32 25
  %t500 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l26
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t500, ptr %t499
  %t501 = getelementptr %"compiler/names:Resolver", ptr %l100, i32 0, i32 26
  %t502 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l27
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t502, ptr %t501
  %t503 = getelementptr %"compiler/names:Resolver", ptr %l100, i32 0, i32 27
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t448, ptr %t503
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l100, i64 1144, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fnames_3aTable_2ector(ptr %out, ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l1 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l2 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l3 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca i64
  %l8 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l10 = alloca i64
  %l12 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l14 = alloca i64
  %l16 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l18 = alloca i64
  %l20 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l22 = alloca %"compiler/names:Table"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l5
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l0
  %t3 = call ptr @__olang_scope_hold(ptr %v0)
  %t4 = ptrtoint ptr %t3 to i64
  store i64 %t4, ptr %l6, !tbaa !24
  %t5 = load i1, ptr @olang_2esole_2ecompiler_2fnames_3aTable_2e1
  br i1 %t5, label %bb2, label %bb3
bb2:
  %t7 = call ptr @__olang_region_make(ptr %v0)
  %t8 = ptrtoint ptr %t7 to i64
  store i64 %t8, ptr %l6, !tbaa !24
  br label %bb3
bb3:
  %t9 = load i64, ptr %l6
  %t10 = inttoptr i64 %t9 to ptr
  %t11 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e(ptr %t10)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t11, ptr %l8
  br label %bb4
bb4:
  %t12 = load i1, ptr @olang_2esole_2ecompiler_2fnames_3aTable_2e1
  br i1 %t12, label %bb5, label %bb6
bb5:
  %t14 = load i64, ptr %l6
  %t15 = inttoptr i64 %t14 to ptr
  %t16 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l8, i32 0, i32 2
  %t17 = load { i64, ptr }, ptr %t16
  %t18 = extractvalue { i64, ptr } %t17, 1
  %t19 = call ptr @__olang_region_or(ptr %t18, ptr null)
  %t20 = call ptr @__olang_region_home(ptr %t19)
  %t21 = icmp ne ptr %t20, null
  %t22 = select i1 %t21, ptr %t20, ptr null
  %t23 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l8, i32 0, i32 1
  %t24 = load { i64, ptr }, ptr %t23
  %t25 = extractvalue { i64, ptr } %t24, 1
  %t26 = call ptr @__olang_region_or(ptr %t25, ptr null)
  %t27 = call ptr @__olang_region_home(ptr %t26)
  %t28 = icmp ne ptr %t27, null
  %t29 = select i1 %t28, ptr %t27, ptr %t22
  %t30 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l8, i32 0, i32 0
  %t31 = load { i64, ptr }, ptr %t30
  %t32 = extractvalue { i64, ptr } %t31, 1
  %t33 = call ptr @__olang_region_or(ptr %t32, ptr null)
  %t34 = call ptr @__olang_region_home(ptr %t33)
  %t35 = icmp ne ptr %t34, null
  %t36 = select i1 %t35, ptr %t34, ptr %t29
  call void @__olang_region_settle_in(ptr %t15, ptr %t36)
  br label %bb6
bb6:
  %t37 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l8
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t37, ptr %l1
  %t38 = call ptr @__olang_scope_hold(ptr %v0)
  %t39 = ptrtoint ptr %t38 to i64
  store i64 %t39, ptr %l10, !tbaa !24
  %t40 = load i1, ptr @olang_2esole_2ecompiler_2fnames_3aTable_2e2
  br i1 %t40, label %bb7, label %bb8
bb7:
  %t42 = call ptr @__olang_region_make(ptr %v0)
  %t43 = ptrtoint ptr %t42 to i64
  store i64 %t43, ptr %l10, !tbaa !24
  br label %bb8
bb8:
  %t44 = load i64, ptr %l10
  %t45 = inttoptr i64 %t44 to ptr
  %t46 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e(ptr %t45)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t46, ptr %l12
  br label %bb9
bb9:
  %t47 = load i1, ptr @olang_2esole_2ecompiler_2fnames_3aTable_2e2
  br i1 %t47, label %bb10, label %bb11
bb10:
  %t49 = load i64, ptr %l10
  %t50 = inttoptr i64 %t49 to ptr
  %t51 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l12, i32 0, i32 2
  %t52 = load { i64, ptr }, ptr %t51
  %t53 = extractvalue { i64, ptr } %t52, 1
  %t54 = call ptr @__olang_region_or(ptr %t53, ptr null)
  %t55 = call ptr @__olang_region_home(ptr %t54)
  %t56 = icmp ne ptr %t55, null
  %t57 = select i1 %t56, ptr %t55, ptr null
  %t58 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l12, i32 0, i32 1
  %t59 = load { i64, ptr }, ptr %t58
  %t60 = extractvalue { i64, ptr } %t59, 1
  %t61 = call ptr @__olang_region_or(ptr %t60, ptr null)
  %t62 = call ptr @__olang_region_home(ptr %t61)
  %t63 = icmp ne ptr %t62, null
  %t64 = select i1 %t63, ptr %t62, ptr %t57
  %t65 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l12, i32 0, i32 0
  %t66 = load { i64, ptr }, ptr %t65
  %t67 = extractvalue { i64, ptr } %t66, 1
  %t68 = call ptr @__olang_region_or(ptr %t67, ptr null)
  %t69 = call ptr @__olang_region_home(ptr %t68)
  %t70 = icmp ne ptr %t69, null
  %t71 = select i1 %t70, ptr %t69, ptr %t64
  call void @__olang_region_settle_in(ptr %t50, ptr %t71)
  br label %bb11
bb11:
  %t72 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l12
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t72, ptr %l2
  %t73 = call ptr @__olang_scope_hold(ptr %v0)
  %t74 = ptrtoint ptr %t73 to i64
  store i64 %t74, ptr %l14, !tbaa !24
  %t75 = load i1, ptr @olang_2esole_2ecompiler_2fnames_3aTable_2e3
  br i1 %t75, label %bb12, label %bb13
bb12:
  %t77 = call ptr @__olang_region_make(ptr %v0)
  %t78 = ptrtoint ptr %t77 to i64
  store i64 %t78, ptr %l14, !tbaa !24
  br label %bb13
bb13:
  %t79 = load i64, ptr %l14
  %t80 = inttoptr i64 %t79 to ptr
  %t81 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e(ptr %t80)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t81, ptr %l16
  br label %bb14
bb14:
  %t82 = load i1, ptr @olang_2esole_2ecompiler_2fnames_3aTable_2e3
  br i1 %t82, label %bb15, label %bb16
bb15:
  %t84 = load i64, ptr %l14
  %t85 = inttoptr i64 %t84 to ptr
  %t86 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l16, i32 0, i32 2
  %t87 = load { i64, ptr }, ptr %t86
  %t88 = extractvalue { i64, ptr } %t87, 1
  %t89 = call ptr @__olang_region_or(ptr %t88, ptr null)
  %t90 = call ptr @__olang_region_home(ptr %t89)
  %t91 = icmp ne ptr %t90, null
  %t92 = select i1 %t91, ptr %t90, ptr null
  %t93 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l16, i32 0, i32 1
  %t94 = load { i64, ptr }, ptr %t93
  %t95 = extractvalue { i64, ptr } %t94, 1
  %t96 = call ptr @__olang_region_or(ptr %t95, ptr null)
  %t97 = call ptr @__olang_region_home(ptr %t96)
  %t98 = icmp ne ptr %t97, null
  %t99 = select i1 %t98, ptr %t97, ptr %t92
  %t100 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l16, i32 0, i32 0
  %t101 = load { i64, ptr }, ptr %t100
  %t102 = extractvalue { i64, ptr } %t101, 1
  %t103 = call ptr @__olang_region_or(ptr %t102, ptr null)
  %t104 = call ptr @__olang_region_home(ptr %t103)
  %t105 = icmp ne ptr %t104, null
  %t106 = select i1 %t105, ptr %t104, ptr %t99
  call void @__olang_region_settle_in(ptr %t85, ptr %t106)
  br label %bb16
bb16:
  %t107 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l16
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t107, ptr %l3
  %t108 = call ptr @__olang_scope_hold(ptr %v0)
  %t109 = ptrtoint ptr %t108 to i64
  store i64 %t109, ptr %l18, !tbaa !24
  %t110 = load i1, ptr @olang_2esole_2ecompiler_2fnames_3aTable_2e4
  br i1 %t110, label %bb17, label %bb18
bb17:
  %t112 = call ptr @__olang_region_make(ptr %v0)
  %t113 = ptrtoint ptr %t112 to i64
  store i64 %t113, ptr %l18, !tbaa !24
  br label %bb18
bb18:
  %t114 = load i64, ptr %l18
  %t115 = inttoptr i64 %t114 to ptr
  %t116 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3e(ptr %t115)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t116, ptr %l20
  br label %bb19
bb19:
  %t117 = load i1, ptr @olang_2esole_2ecompiler_2fnames_3aTable_2e4
  br i1 %t117, label %bb20, label %bb21
bb20:
  %t119 = load i64, ptr %l18
  %t120 = inttoptr i64 %t119 to ptr
  %t121 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l20, i32 0, i32 2
  %t122 = load { i64, ptr }, ptr %t121
  %t123 = extractvalue { i64, ptr } %t122, 1
  %t124 = call ptr @__olang_region_or(ptr %t123, ptr null)
  %t125 = call ptr @__olang_region_home(ptr %t124)
  %t126 = icmp ne ptr %t125, null
  %t127 = select i1 %t126, ptr %t125, ptr null
  %t128 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l20, i32 0, i32 1
  %t129 = load { i64, ptr }, ptr %t128
  %t130 = extractvalue { i64, ptr } %t129, 1
  %t131 = call ptr @__olang_region_or(ptr %t130, ptr null)
  %t132 = call ptr @__olang_region_home(ptr %t131)
  %t133 = icmp ne ptr %t132, null
  %t134 = select i1 %t133, ptr %t132, ptr %t127
  %t135 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l20, i32 0, i32 0
  %t136 = load { i64, ptr }, ptr %t135
  %t137 = extractvalue { i64, ptr } %t136, 1
  %t138 = call ptr @__olang_region_or(ptr %t137, ptr null)
  %t139 = call ptr @__olang_region_home(ptr %t138)
  %t140 = icmp ne ptr %t139, null
  %t141 = select i1 %t140, ptr %t139, ptr %t134
  call void @__olang_region_settle_in(ptr %t120, ptr %t141)
  br label %bb21
bb21:
  %t142 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l20
  %t143 = getelementptr %"compiler/names:Table", ptr %l22, i32 0, i32 0
  %t144 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t144, ptr %t143
  %t145 = getelementptr %"compiler/names:Table", ptr %l22, i32 0, i32 1
  %t146 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t146, ptr %t145
  %t147 = getelementptr %"compiler/names:Table", ptr %l22, i32 0, i32 2
  %t148 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l2
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t148, ptr %t147
  %t149 = getelementptr %"compiler/names:Table", ptr %l22, i32 0, i32 3
  %t150 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l3
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t150, ptr %t149
  %t151 = getelementptr %"compiler/names:Table", ptr %l22, i32 0, i32 4
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t142, ptr %t151
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l22, i64 320, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/names:raisedName" @compiler_2fnames_3araisedName_2ector(ptr %v0, ptr %v1, i32 %a0, %"compiler/source:Span" %a1, i64 %a2, i1 %a3, i64 %a4, { i64, ptr } %a5) #0 {
entry:
  %rv = alloca %"compiler/names:raisedName"
  br label %start
start:
  br label %bb0
bb0:
  %t14 = insertvalue %"compiler/names:raisedName" undef, i32 %a0, 0
  %t16 = insertvalue %"compiler/names:raisedName" %t14, %"compiler/source:Span" %a1, 1
  %t18 = insertvalue %"compiler/names:raisedName" %t16, i64 %a2, 2
  %t20 = insertvalue %"compiler/names:raisedName" %t18, i1 %a3, 3
  %t22 = insertvalue %"compiler/names:raisedName" %t20, i64 %a4, 4
  %t24 = insertvalue %"compiler/names:raisedName" %t22, { i64, ptr } %a5, 5
  store %"compiler/names:raisedName" %t24, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/names:raisedName", ptr %rv
  ret %"compiler/names:raisedName" %rr
}

define dso_local %"compiler/names:raised" @compiler_2fnames_3araised_2ector(ptr %v0, ptr %v1, i32 %a0, %"compiler/source:Span" %a1, i1 %a2, { i64, ptr } %a3) #0 {
entry:
  %rv = alloca %"compiler/names:raised"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/names:raised" undef, i32 %a0, 0
  %t12 = insertvalue %"compiler/names:raised" %t10, %"compiler/source:Span" %a1, 1
  %t14 = insertvalue %"compiler/names:raised" %t12, i1 %a2, 2
  %t16 = insertvalue %"compiler/names:raised" %t14, { i64, ptr } %a3, 3
  store %"compiler/names:raised" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/names:raised", ptr %rv
  ret %"compiler/names:raised" %rr
}

declare void @__olang_check_failed(ptr) cold noreturn
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %dh = load ptr, ptr %dheadptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  %hasd = icmp ne ptr %dh, null
  %owns = or i1 %hasf, %hasd
  br i1 %owns, label %owned, label %chunks
owned:
  call void @__olang_scope_close_owned(ptr %scope)
  br label %chunks
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d0 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
@.d1 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"std/" }>, align 8
@.d2 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define available_externally ptr @__olang_scope_hold(ptr %s) alwaysinline {
entry:
  %none = icmp eq ptr %s, null
  br i1 %none, label %plain, label %look
look:
  ; atomic: on a scope that is no stand-in this word is its parts list, which other threads push onto (__olang_scope_part)
  %mp = getelementptr %olang.scope, ptr %s, i32 0, i32 4
  %m = load atomic ptr, ptr %mp monotonic, align 8
  %fresh = icmp eq ptr %m, @__olang_standin_mark
  br i1 %fresh, label %make, label %kept
kept:
  %mi = ptrtoint ptr %m to i64
  %bit = and i64 %mi, 1
  %has = icmp ne i64 %bit, 0
  br i1 %has, label %keeper, label %plain
keeper:
  %ki = and i64 %mi, -2
  %k = inttoptr i64 %ki to ptr
  ret ptr %k
make:
  %f = call ptr @__olang_standin_keeper(ptr %s)
  ret ptr %f
plain:
  ret ptr %s
}
@olang_2esole_2ecompiler__2fnames__2ecompiler__2fnames__3aResolver__2ebuildDefault_2elocal_2e5 = weak hidden constant i1 false
declare ptr @__olang_region_make(ptr) noinline
define available_externally noalias ptr @__olang_held_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare ptr @__olang_region_or(ptr, ptr)
declare void @__olang_region_settle_in(ptr, ptr)
declare void @__olang_region_release(ptr) noinline
@.d3 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d4 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Bool" }>, align 8
@.d5 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I32" }>, align 8
@.d6 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I64" }>, align 8
@.d7 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"U64" }>, align 8
@.d8 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"F64" }>, align 8
@.d9 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"String" }>, align 8
@.d10 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Bool" }>, align 8
define available_externally void @__olang_scope_escape(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %un = icmp eq ptr %o, null
  br i1 %un, label %claim, label %done
claim:
  %me = load ptr, ptr @__olang_self
  store atomic ptr %me, ptr %op monotonic, align 8
  br label %done
done:
  ret void
}
define internal i1 @olang_lambda_11(ptr %env, ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l4 = alloca i1
  %rv = alloca i1
  %cp0 = getelementptr { { i64, ptr }, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load { i64, ptr }, ptr %cp0, !tbaa !28
  %vq0 = getelementptr { { i64, ptr }, ptr }, ptr %env, i32 0, i32 1
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %vc0, { i64, ptr } %a0, { i64, ptr } %cv0)
  store i1 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i1, ptr %l4, !tbaa !21
  store i1 %t6, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1 = weak hidden constant i1 false
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
@__olang_empty_array = external constant [16 x i64]
@.d12 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
@.d13 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
@.d14 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler__2fnames__2ecompiler__2fnames__3aResolver__2enearRaise_2elocal_2e5 = weak hidden constant i1 false
@.d15 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Byte" }>, align 8
@.d16 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"I8" }>, align 8
@.d17 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I16" }>, align 8
@.d18 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I32" }>, align 8
@.d19 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I64" }>, align 8
@.d20 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"U8" }>, align 8
@.d21 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"U16" }>, align 8
@.d22 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"U32" }>, align 8
@.d23 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"U64" }>, align 8
@.d24 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"F16" }>, align 8
@.d25 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"BF16" }>, align 8
@.d26 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"F32" }>, align 8
@.d27 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"F64" }>, align 8
@.d28 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Bool" }>, align 8
@.d29 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"Array" }>, align 8
@__olang_prog_scope = external thread_local(initialexec) global ptr
@.d30 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
@.d31 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d32 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c".olang" }>, align 8
@.d33 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d34 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I64" }>, align 8
@.d35 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"F64" }>, align 8
@.d36 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Bool" }>, align 8
@.d37 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"String" }>, align 8
@.d38 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d39 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d40 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d41 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d42 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare void @__olang_errpay_pop()
@.d43 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d44 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"linux" }>, align 8
@.d45 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"x86_64" }>, align 8
@.d46 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"x86-64" }>, align 8
@olang_2esole_2ecompiler_2fload_3aLoader_2e2 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ffetch_3aFetcher_2e0 = weak hidden constant i1 false
@.d47 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"/olang.lock" }>, align 8
@olang_2esole_2ecompiler_2ffetch_3aFetcher_2e1 = weak hidden constant i1 false
@.d48 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"/cache" }>, align 8
@.d49 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"file:///nowhere/" }>, align 8
@olang_2esole_2ecompiler_2fload_3aLoader_2e3 = weak hidden constant i1 false
@.d50 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"std" }>, align 8
@olang_2esole_2ecompiler_2fload_3aModule_2e0 = weak hidden constant i1 false
@.d51 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d52 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d53 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
@.d54 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@olang_2esole_2ecompiler_2fnames_3aResolver_2e2 = weak hidden constant i1 false
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

declare ptr @__olang_region_home(ptr)
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2fnames_3aRef_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2fnames_3aRef_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fnames_3aRef_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fnames_3aRef_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@olang_2esole_2ecompiler_2fnames_3aResolver_2e6 = weak hidden constant i1 false
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@olang_2esole_2ecompiler_2fnames_3aResolver_2e9 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fnames_3aResolver_2e10 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fnames_3aResolver_2e11 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fnames_3aResolver_2e12 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fnames_3aResolver_2e16 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fnames_3aResolver_2e17 = weak hidden constant i1 false
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@olang_2esole_2ecompiler_2fnames_3aResolver_2e18 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fnames_3aResolver_2e19 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fnames_3aResolver_2e20 = weak hidden constant i1 false
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@olang_2esole_2ecompiler_2fnames_3aResolver_2e21 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fnames_3aResolver_2e22 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fnames_3aResolver_2e25 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fnames_3aResolver_2e26 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fnames_3aResolver_2e27 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fnames_3aTable_2e1 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fnames_3aTable_2e2 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fnames_3aTable_2e3 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fnames_3aTable_2e4 = weak hidden constant i1 false
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
declare void @__olang_scope_close_owned(ptr) noinline
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@__olang_standin_mark = external global i64
declare ptr @__olang_standin_keeper(ptr) noinline
define available_externally noalias ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  %head = load ptr, ptr %scope, !tbaa !59
  %isslot = icmp eq ptr %head, @__olang_slot_chunk
  br i1 %isslot, label %slot, label %plain
slot:
  %s = call ptr @__olang_slot_alloc(ptr %scope, i64 %rawsize)
  ret ptr %s
plain:
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@__olang_self = external thread_local(initialexec) global ptr
define available_externally ptr @__olang_capture_scope(ptr %s) alwaysinline {
entry:
  %isprog = icmp eq ptr %s, null
  br i1 %isprog, label %prog, label %mine
prog:
  %p = load ptr, ptr @__olang_prog_scope
  ret ptr %p
mine:
  %m = call ptr @__olang_scope_mine(ptr %s)
  ret ptr %m
}
@__olang_slot_chunk = external global %olang.chunk
declare noalias ptr @__olang_slot_alloc(ptr, i64) noinline
define available_externally ptr @__olang_scope_mine(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %me = load ptr, ptr @__olang_self
  %own = icmp eq ptr %o, %me
  br i1 %own, label %mine, label %slow
mine:
  ret ptr %s
slow:
  %r = call ptr @__olang_scope_mine_slow(ptr %s)
  ret ptr %r
}
declare ptr @__olang_scope_mine_slow(ptr) noinline
@olang_loc_fb93c458ab7e801d_1c40062d0c03aab1 = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2fnames_2eidentChar(i8 %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_H945cb5faf347f41d89f6885b75263baa(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %a0)
declare i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H862756c16d115e5c03a79726209f69fa(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_Hda627d7755eecb5b938ca977110d67b2(ptr %v0, ptr %v1, ptr %a0)
declare { i32, %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3ccompiler_2fsource_3aNameId_2c_20I6_Hd1b8e91149b724287340e79c8c928444(ptr %v0, ptr %a0)
declare %"compiler/names:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etext(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/names:Ref" @compiler_2fnames_3aRef_2ector(ptr %v0, i32 %a0, i64 %a1, i64 %a2)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_H456f40e55a35e282608933ec0991ad61(ptr %v0, ptr %a0, i32 %a1, %"compiler/names:Ref" %a2)
declare { i64, [3 x i64] } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eat(ptr %v0, ptr %a0, i64 %a1, %"compiler/source:Span" %a2)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eUnderscoreDeclared(ptr %v0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/diagmsg:Msg" %a2)
declare %"compiler/names:Entry" @compiler_2fnames_3aEntry_2ector(ptr %v0, ptr %v1, i32 %a0, %"compiler/source:Span" %a1, i32 %a2, i1 %a3, ptr %a4)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2ePush_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/names:Entry" %a1)
declare i1 @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eHas(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eDefined(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etok(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eBuildConstRedeclared(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eBuildDefaultMut(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNameInUse(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2enoAliasClash(ptr %v0, ptr %a0, i64 %a1, i32 %a2, %"compiler/source:Span" %a3)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_Hf575c52a5a9e8993bae2b73c9c2548b3(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fnames_2eBuiltinTypeName(ptr %v0, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNameIsType(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_H6d33fbc050830e537410645e3c893b2c(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2epreludeTaken(ptr %v0, ptr %a0, i64 %a1, i32 %a2, %"compiler/source:Span" %a3)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eLen_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %a0)
declare i64 @compiler_2fnames_2ekey(i64 %a0, i32 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare i1 @compiler_2fload_2ePublic(ptr %v0, { i64, ptr } %a0)
declare %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ememberOf(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2enotPrivate(ptr %v0, ptr %a0, i64 %a1, %"compiler/names:Ref" %a2, i32 %a3, %"compiler/source:Span" %a4)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fnames_3aRef_3e_2eP_Hb17c37756f956998a4fa74bcac088344(ptr %v0, ptr %a0, i64 %a1, %"compiler/names:Ref" %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fload_3aImport_3e_2eLen_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %a0)
declare %"compiler/load:Import" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fload_3aImport_3e_2eAt_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_3c4b516dc7f3c61f_40ef246315a2e453 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2eChosen(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
@G_2ecompiler_2fload_2ePending = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FD\FF\FF\FF\FF\FF\FF\FF" }>, align 8
declare void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2efunc(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeParams(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ereceiverVars(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2)
declare void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eblock(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2epath(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_d2d926149e7406c7_ee094aa2e5a4afab = external constant [0 x i8]
@olang_loc_68114e74278341f8_5424865478da1a14 = external constant [0 x i8]
declare %"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba" @std_2fpair_3aPair_3cI64_2c_20compiler_2fsource_3aSpan_3e_2ector(ptr %v0, i64 %a0, %"compiler/source:Span" %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20compiler__H2dfd829fbe4fa38977b46d00afbe1a06(ptr %v0, ptr %a0, %"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba" %a1)
@olang_loc_3167f851ad930e17_101a5d4c5c826523 = external constant [0 x i8]
@olang_loc_10b7a8cdf1f86826_4c22b802d51640a2 = external constant [0 x i8]
@olang_loc_4f6a732ad110320d_928733cb84224b09 = external constant [0 x i8]
@olang_loc_3f10f26d81c7593c_51efd4b9807fb190 = external constant [0 x i8]
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eReopen(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eEndHold(ptr %v0, ptr %a0)
@olang_loc_1073219c408bafd2_e24f73113d5a6ea6 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v0, ptr %a0)
@olang_loc_f4b8a71cbdc10f47_ba6792d0a606e23b = external constant [0 x i8]
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eBuildDefaultType(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %v0, ptr %v1, ptr %a0)
declare i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2eSome_3cstd_2fprelu_H83fc947e980a7768a96047c3a0b10532(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1c, ptr %a1e)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eBuildDefaultBare(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i1 @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eFits(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare { i64, ptr } @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eRaw(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eBuildDefaultFit(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eChoose(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eDrop(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eHolds(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_2f2d72e397ff9e11_581917560c7c3b1d = external constant [0 x i8]
declare void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ewaitAside(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare i1 @compiler_2fast_2ecompiler_2fast_3aFunc_2eIsBuilder(ptr %v0, ptr %a0)
@olang_loc_217d72d4076f850a_92db47fb0f8e8bb6 = external constant [0 x i8]
@olang_loc_cbd8c9ec4d2c560b_31762469b8343a67 = external constant [0 x i8]
declare void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eaddType(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2, %"compiler/source:Span" %a3, ptr %a4)
declare void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2epayloadEnum(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/source:Span" %a2, i32 %a3, { i64, ptr } %a4)
declare i1 @compiler_2fnames_2eWrittenMut(ptr %v0, ptr %a0)
@olang_loc_40bcba17b2bf17b3_8a9927ec4a716c7f = external constant [0 x i8]
@olang_loc_60cefae456c43b96_68bed78927cbacfa = external constant [0 x i8]
@olang_loc_e46cc2517056eb7d_41b560901e6ccb81 = external constant [0 x i8]
@olang_loc_8bede4e7118dcaa8_b7291399ad78424c = external constant [0 x i8]
declare void @compiler_2fload_2ecompiler_2fload_3aLoader_2eCondParser(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_24d74d734bb1c47c_a76eb538bdec4e08 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eClear_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eAt_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_9d7678395160f3eb_aad45a645d2f7c27 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_606655a3d6c9146a_8558b81c90083f76 = external constant [0 x i8]
@olang_loc_ca6a9ef64ba15071_9b37ed8e39b0c3dd = external constant [0 x i8]
@olang_loc_cbc626cb57e27c38_a58d4f769ca64c8c = external constant [0 x i8]
declare void @compiler_2fcond_3aEval_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, ptr %a1, ptr %a2, ptr %a3)
declare %"compiler/cond:Decision" @compiler_2fcond_2ecompiler_2fcond_3aEval_2eLocal(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aDecl_26_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aDecl_26_3e_2ePush_3ccompiler_2fast_3aDecl_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3araisedName_3e_2eLen_H9e36587759e47da85a29e6c0abff1d1c(ptr %v0, ptr %a0)
declare %"compiler/names:raisedName" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3araisedName_3e_2eAt__H16b49ab3dab0c5fe49005bf48ab18c1b(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"compiler/ast:CaseDecl" @compiler_2fast_3aCaseDecl_2ector(ptr %v0, ptr %v1, ptr %v2, %"compiler/source:Span" %a0, i32 %a1, { i64, ptr } %a2, i1 %a3, ptr %a4)
@olang_loc_a58fd8af443a076b_ecb4599a293195d7 = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aDecl_26_3e_2eToArray_3ccompiler_2fast_3aDecl_26_3e(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_aef4624c79a8a28b_a45312851bdbb01f = external constant [0 x i8]
@olang_loc_87cbb522e5e56b9c_2473c9b69de9380 = external constant [0 x i8]
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCutOff(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_12490b43c47bea91_b34a6c7dd92a3b95 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aStmt_2eSpan(ptr %v0, ptr %a0)
@olang_loc_f9018996705a58e9_83925e810340c2fd = external constant [0 x i8]
declare i64 @compiler_2fnames_2ecompiler_2fnames_3aResolver_2emark(ptr %v0, ptr %a0)
declare void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eforNames(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i32 %a3)
declare void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2epopTo(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eclauses(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2epushSig(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2epopSig(ptr %v0, ptr %a0)
declare void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ematchOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_eb7a002d6449973_70bfc0171de666c7 = external constant [0 x i8]
declare void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etarget(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_d0841cbd4b51f07d_335a00002a32b699 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3araisedName_3e_2ector(ptr %v0, i64 %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3araised_3e_2eLen_3ccompiler_2fnames_3araised_3e(ptr %v0, ptr %a0)
declare %"compiler/names:raised" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3araised_3e_2eAt_3ccompiler_2fnames_3araised_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @compiler_2fnames_2eindexOfRaised(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3araisedName_3e_2ePus_Hd55e6ab57c5af931645f87a55858e9a4(ptr %v0, ptr %v1, ptr %a0, %"compiler/names:raisedName" %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3araisedName_3e_2eSet_H6810983465e8cb9e88422e8fd071646d(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/names:raisedName" %a2)
@olang_loc_886f7d48bba75e1e_e325b650ab06e3ea = external constant [0 x i8]
@olang_loc_dbd61287de33a2c5_4d29ffa31fdf1ff1 = external constant [0 x i8]
@olang_loc_bee2df1b257c0b70_a796ae201fef93fc = external constant [0 x i8]
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %v0, i64 %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, i1 %a2)
@olang_loc_f74f5c810fb1384f_2035d8e6259ec36b = external constant [0 x i8]
@olang_loc_9a3445d364d03a02_c72e8fada9365de6 = external constant [0 x i8]
@olang_loc_f2359f321711c0e9_83213f8b98ca37cd = external constant [0 x i8]
@olang_loc_530cce065f124df4_4e8587782c204bb8 = external constant [0 x i8]
@olang_loc_13e109869e44451a_84e972cbfcb81dee = external constant [0 x i8]
declare %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2esharedType(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare %"compiler/names:local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3alocal_3e_2eAt_3ccompiler_2fnames_3alocal_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i32, %"compiler/names:Ref" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_H678d1b43e8b98a171ffdea8f28643d28(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ealiasTarget(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_80db847ecdc1ab20_b5fcfe3f659aa7a4 = external constant [0 x i8]
@olang_loc_7d53eb57251aa886_389a79dd3a03050a = external constant [0 x i8]
declare void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2edeclareRead(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, i1 %a3)
@olang_loc_9ceebceeac4e7745_86123446739d71b9 = external constant [0 x i8]
declare void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2erecord(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, %"compiler/names:Ref" %a2)
declare void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eread(ptr %v0, ptr %a0, %"compiler/names:Ref" %a1)
@olang_loc_8d565d6672144814_e400a405fc887290 = external constant [0 x i8]
@olang_loc_494c345e55bc9323_650b6e4eb2f730ef = external constant [0 x i8]
@olang_loc_9c997e82162b9a5a_f5a213d30049e536 = external constant [0 x i8]
declare i64 @compiler_2fmsgs_2eDistance(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2fmsgs_2eNear(ptr %v0, { i64, ptr } %a0, i64 %a1)
declare { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eRaiseNearError(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6b5ccacad8db807339a3579aa8c82ff8(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eShadowsFunction(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eShadowsGlobal(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoteDeclaredHere(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, [3 x i64] } %a2, %"compiler/diagmsg:Msg" %a3)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eShadowsBuildConst(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eShadowsType(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3alocal_3e_2eLen_3ccompiler_2fnames_3alocal_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3araised_3e_2eClear_3ccompiler_2fnames_3araised_3e(ptr %v0, ptr %a0)
@olang_loc_fd3c9d14e235dbbe_bd11dfc23075d8e2 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aParam_26_3e_2ector(ptr %v0, i64 %a0)
declare %"compiler/ast:Param" @compiler_2fast_3aParam_2ector(ptr %v0, ptr %v1, ptr %v2, %"compiler/source:Span" %a0, i32 %a1, ptr %a2, ptr %a3)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aParam_26_3e_2ePush_3ccompiler_2fast_3aParam_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eRaisedFieldUnnamed(ptr %v0)
@olang_loc_f7896ae45faa6454_3785f9c9b8d393e0 = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aParam_26_3e_2eToArray_3ccompiler_2fast_3aParam_26_3e(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_f7af4f17da675e9e_7adee505b4454aba = external constant [0 x i8]
@olang_loc_4b15e456fcf3a345_7adab712aa943e41 = external constant [0 x i8]
@olang_loc_2e22b0ea443c0bf0_cc72b894f0b6250c = external constant [0 x i8]
@olang_loc_668f2e502e7138cf_4506733ced80a77b = external constant [0 x i8]
@olang_loc_97417a283903a82_ac3e213ae41817f6 = external constant [0 x i8]
declare void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eparam(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2)
@olang_loc_6175710135d1c169_c21d56ac8dc09c5d = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3alocal_3e_2eClear_3ccompiler_2fnames_3alocal_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eClear_3cI64_2c_20I64_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_Hb7e448baed1c9668005f7dc6325e5707(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fsource__H263d9150b58237aac70cb39b886b10bb(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eClear_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0)
@olang_loc_6855615fe1bb2138_9d7c9db084b0e41c = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %a0)
@olang_loc_f16fd081e6fbed18_62e1963dfff5da0c = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eToUpper(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aUnread_3e_2eLen_3ccompiler_2fnames_3aUnread_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fsource__H04f1a4a88576bd1070c12151a5c28d38(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20compiler__H5ec116bb82f5a234bb19cb32db1efc81(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aUnread_3e_2eTruncate_3ccompiler_2fnames_3aUnread_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fsource__H30ad8836952c6f4772e34a804c6491c6(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20compiler__H73edf45b0858a6ff3702d25efc23fa6e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_1b8bfcf5c54b80a6_f112f6c40c79d862 = external constant [0 x i8]
@olang_loc_c04d895388279f34_2b6890ee7e2f3280 = external constant [0 x i8]
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H8da9376267bda3f76393292be0e507b2(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3araised_3e_2ePush_3ccompiler_2fnames_3araised_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/names:raised" %a1)
@olang_loc_e6063e0110b31a73_71b4269b957cfb57 = external constant [0 x i8]
declare void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2ebind(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, i32 %a3)
@olang_loc_6e82bb982de183d3_df58ae24de93c697 = external constant [0 x i8]
@olang_loc_2a287a06f88e222b_c77af2bce9e1616f = external constant [0 x i8]
declare %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2etypeIn(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eunknownHead(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2)
declare i1 @std_2fos_2eExists(ptr %v0, { i64, ptr } %a0)
declare i1 @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eImportSaid(ptr %v0, ptr %a0, i32 %a1)
declare %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" @std_2fpair_3aPair_3ccompiler_2fsource_3aNameId_2c_20I64_3e_2ector(ptr %v0, i32 %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fsource__H6d3eea1e3a905a651c612011755d5d17(ptr %v0, ptr %a0, %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" %a1)
declare %"compiler/msgs:Nearest" @compiler_2fmsgs_3aNearest_2ector(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fmsgs_2ecompiler_2fmsgs_3aNearest_2eOffer(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fmsgs_2ecompiler_2fmsgs_3aNearest_2eHint(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eUnknownImport(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_3ee91b253925870d_db61affc9a997151 = external constant [0 x i8]
declare %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fsource__Hd32f6fdf378a1d4c0e47f8552643012d(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eUnknownBuildName(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20compiler__H1a77801a5ab3ea58cbf0ff15b43ff2de(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_9053a89eb2ebe36f_9971388257a6393 = external constant [0 x i8]
@olang_loc_f48de55fc7d2510_3851ef0ac8d7efc4 = external constant [0 x i8]
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eImportUnused(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @compiler_2fnames_2ecompiler_2fnames_3aResolver_2edeclare(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, i1 %a3)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eHas_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H96b7de74ba8f33ba996281c879dd113a(ptr %v0, ptr %a0, i32 %a1, i1 %a2)
@olang_loc_2e44b04c90256572_e4b951cec3f82206 = external constant [0 x i8]
@olang_loc_c27b9afc6f9460e7_c1ce40693c6669b = external constant [0 x i8]
declare { i64, ptr } @compiler_2fscan_2eLiteralText(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fload_2eDeriveAlias(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_34778adaa3b7f78b_cd6f80cc1b0739cf = external constant [0 x i8]
@olang_loc_e6f5afeb81d3c728_e8c5c2420d9193ac = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %v0, i64 %a0)
@olang_loc_6dee9be1cc02e387_998545862ea10f93 = external constant [0 x i8]
@olang_loc_b132f661075442d5_ae99d36a98b51df9 = external constant [0 x i8]
@olang_loc_69822c0cac48a014_4fc53fd0a2f89a60 = external constant [0 x i8]
@olang_loc_37678c01af633453_98b92ef1312e36f7 = external constant [0 x i8]
declare { i32, { i64, ptr } } @std_2fos_2eMkTemp(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_7d6219e827f558e0_eeca058e7ab150ac = external constant [0 x i8]
declare i32 @std_2fos_2eWriteFile(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @compiler_2fcond_3aConsts_2ector(ptr %out, ptr %v0)
declare void @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eBuiltins(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, i64 %a4, i64 %a5, i1 %a6, i1 %a7, i1 %a8, i64 %a9)
declare void @compiler_2fdiag_3aDiagnostics_2ector(ptr %out, ptr %v0, i1 %a0)
declare i32 @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eDefine(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, ptr %a2)
declare void @compiler_2ffetch_3aFetcher_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, i1 %a3, i1 %a4)
declare %"compiler/source:Names" @compiler_2fsource_3aNames_2ector(ptr %v0)
declare void @compiler_2fload_3aLoader_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, { i64, ptr } %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4)
declare i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2eLoad(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eAllSaid(ptr %v0, ptr %v1, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3aSaid_3e_2eLen_3ccompiler_2fdiag_3aSaid_3e(ptr %v0, ptr %a0)
declare %"compiler/diag:Said" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3aSaid_3e_2eAt_3ccompiler_2fdiag_3aSaid_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare i32 @std_2fos_2eRemoveAll(ptr %v0, { i64, ptr } %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3alocal_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fsource_3aNameId_2c_20I64_3e_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aUnread_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20compiler_2fsource_3aSpan_3e_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3araised_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2fnames_3aRef_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fnames_3aRef_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
