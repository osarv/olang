; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"compiler/diag:note" = type { i64, { i64, [3 x i64] }, { i64, ptr }, i1, i1 }
%"compiler/diag:Diagnostics" = type { i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, [3 x i64] }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/diag:record" = type { { i64, [3 x i64] }, { i64, ptr }, { i64, ptr }, i32, i64, i1 }
%"compiler/diag:context" = type { { i64, [3 x i64] }, { i64, ptr } }
%"compiler/diagmsg:Msg" = type { i32, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr } }
define dso_local { i32, { i64, ptr } } @compiler_2fdiag_2eExplain(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l7 = alloca i8
  %l8 = alloca { i64, ptr }
  %l9 = alloca %"std/prelude/text:StringBuilder"
  %l10 = alloca { i64, ptr }
  %l11 = alloca i1
  %l12 = alloca i1
  %l13 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i1
  %l19 = alloca i64
  %l20 = alloca %"std/prelude/text:StringBuilder"
  %l29 = alloca { i64, ptr }
  %l32 = alloca ptr
  %l35 = alloca i8
  %l37 = alloca i8
  %l43 = alloca { i64, ptr }
  %l44 = alloca %"std/prelude/text:StringBuilder"
  %l45 = alloca { i64, ptr }
  %l46 = alloca i64
  %l51 = alloca { i64, ptr }
  %l54 = alloca i64
  %l55 = alloca i64
  %l64 = alloca i64
  %l67 = alloca i64
  %l68 = alloca i32
  %l72 = alloca { i64, ptr }
  %l74 = alloca i64
  %l75 = alloca i64
  %l80 = alloca { i64, ptr }
  %l82 = alloca i64
  %l85 = alloca i64
  %l86 = alloca i64
  %l92 = alloca { i64, ptr }
  %l93 = alloca { i64, ptr }
  %l97 = alloca i1
  %l101 = alloca i1
  %l107 = alloca i1
  %l110 = alloca i1
  %l115 = alloca i1
  %l116 = alloca { i64, ptr }
  %l120 = alloca i1
  %l121 = alloca { i64, ptr }
  %l136 = alloca i1
  %l137 = alloca { i64, ptr }
  %l140 = alloca i1
  %l141 = alloca ptr
  %l142 = alloca { i64, ptr }
  %l144 = alloca ptr
  %l145 = alloca { i64, ptr }
  %l146 = alloca i64
  %l149 = alloca i64
  %l150 = alloca i64
  %l159 = alloca i1
  %l176 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l20
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l20
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  store { i64, ptr } %a1, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t5 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  store i64 %t7, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t9 = load i64, ptr %l4, !tbaa !24
  %t10 = load i64, ptr %l5, !tbaa !24
  %t13 = icmp slt i64 %t9, %t10
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb3, label %bb4
bb3:
  br label %bb12
bb4:
  br label %bb5
bb5:
  %t17 = load i64, ptr %l4, !tbaa !24
  %t19 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t19, ptr %l29, !tbaa !27
  %t20 = load i64, ptr %l4, !tbaa !24
  %t22 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = getelementptr i8, ptr %t23, i64 %t20
  %t25 = load i8, ptr %t24, !tbaa !32
  store i8 %t25, ptr %l7, !tbaa !22
  store ptr %l2, ptr %l32, !tbaa !29
  %t29 = icmp eq i64 %t17, 0
  br i1 %t29, label %bb6, label %bb7
bb6:
  %t31 = load i8, ptr %l7, !tbaa !22
  %t33 = call i8 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eToUpper(i8 %t31)
  store i8 %t33, ptr %l37
  br label %bb8
bb7:
  %t34 = load i8, ptr %l7, !tbaa !22
  store i8 %t34, ptr %l35, !tbaa !22
  br label %bb9
bb8:
  %t36 = load i8, ptr %l37, !tbaa !22
  store i8 %t36, ptr %l35, !tbaa !22
  br label %bb9
bb9:
  %t37 = load ptr, ptr %l32, !tbaa !29
  %t38 = load i8, ptr %l35, !tbaa !22
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %t37, i8 %t38)
  br label %bb10
bb10:
  br label %bb11
bb11:
  %t39 = load i64, ptr %l4, !tbaa !24
  %t42 = add i64 %t39, 1
  store i64 %t42, ptr %l4, !tbaa !24
  br label %bb2
bb12:
  %t45 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l2)
  store { i64, ptr } %t45, ptr %l43
  br label %bb13
bb13:
  %t46 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t46, ptr %l8, !tbaa !27
  %t47 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t47, ptr %l44
  br label %bb14
bb14:
  %t48 = load %"std/prelude/text:StringBuilder", ptr %l44
  store %"std/prelude/text:StringBuilder" %t48, ptr %l9
  %t49 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t49, ptr %l45, !tbaa !27
  %t50 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t51 = extractvalue { i64, ptr } %t50, 0
  store i64 %t51, ptr %l46, !tbaa !24
  %t52 = icmp sge i64 0, 0
  br i1 %t52, label %bb15, label %bb16
bb15:
  %t54 = icmp sle i64 0, 0
  br i1 %t54, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_c5879cd561f524a8_9a69d9d7af5b002c)
  unreachable
bb17:
  %t56 = load i64, ptr %l46, !tbaa !24
  %t57 = icmp sle i64 0, %t56
  br i1 %t57, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_c5879cd561f524a8_9a69d9d7af5b002c)
  unreachable
bb19:
  %t59 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = getelementptr i8, ptr %t60, i64 0
  %t62 = sub i64 0, 0
  %t63 = insertvalue { i64, ptr } undef, i64 %t62, 0
  %t64 = insertvalue { i64, ptr } %t63, ptr %t61, 1
  store { i64, ptr } %t64, ptr %l10, !tbaa !27
  store i1 false, ptr %l11, !tbaa !21
  store i1 false, ptr %l12, !tbaa !21
  store i64 0, ptr %l13, !tbaa !24
  %t66 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t66, ptr %l51, !tbaa !27
  %t67 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t70 = extractvalue { i64, ptr } %t67, 0
  store i64 %t70, ptr %l54, !tbaa !24
  %t71 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t72 = extractvalue { i64, ptr } %t71, 0
  store i64 %t72, ptr %l55, !tbaa !24
  %t73 = icmp sge i64 0, 0
  br i1 %t73, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_c5879cd561f524a8_9a69d9d7af5b002c)
  unreachable
bb21:
  %t75 = load i64, ptr %l54, !tbaa !24
  %t76 = icmp sle i64 0, %t75
  br i1 %t76, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_278b8075a2f80085_5f77718140d89fd9)
  unreachable
bb23:
  %t78 = load i64, ptr %l54, !tbaa !24
  %t79 = load i64, ptr %l55, !tbaa !24
  %t80 = icmp sle i64 %t78, %t79
  br i1 %t80, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_278b8075a2f80085_5f77718140d89fd9)
  unreachable
bb25:
  %t82 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !27
  %t84 = load i64, ptr %l54, !tbaa !24
  %t85 = getelementptr i8, ptr %t83, i64 0
  %t86 = sub i64 %t84, 0
  %t87 = insertvalue { i64, ptr } undef, i64 %t86, 0
  %t88 = insertvalue { i64, ptr } %t87, ptr %t85, 1
  store { i64, ptr } %t88, ptr %l14, !tbaa !27
  br label %bb27
bb26:
  call void @__olang_check_failed(ptr @olang_loc_278b8075a2f80085_5f77718140d89fd9)
  unreachable
bb27:
  store %olang.scope zeroinitializer, ptr %s4
  %t90 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t92 = extractvalue { i64, ptr } %t90, 0
  %t94 = icmp sgt i64 %t92, 0
  %t96 = xor i1 %t94, true
  br i1 %t96, label %bb28, label %bb29
bb28:
  call void @__olang_scope_close(ptr %s4)
  br label %bb115
bb29:
  br label %bb30
bb30:
  %t98 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t101 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %v0, { i64, ptr } %t98, i8 10)
  %t102 = extractvalue { i32, i64 } %t101, 1
  %t103 = extractvalue { i32, i64 } %t101, 0
  store i32 %t103, ptr %l68
  %t104 = icmp ne i32 %t103, 0
  br i1 %t104, label %bb32, label %ok.105, !prof !99
ok.105:
  store i64 %t102, ptr %l67
  br label %bb31
bb31:
  %t106 = load i64, ptr %l67, !tbaa !24
  store i64 %t106, ptr %l64, !tbaa !24
  br label %bb34
bb32:
  br label %bb33
bb33:
  %t107 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t109 = extractvalue { i64, ptr } %t107, 0
  %t111 = sub i64 %t109, 1
  store i64 %t111, ptr %l64, !tbaa !24
  br label %bb34
bb34:
  %t113 = load i64, ptr %l64, !tbaa !24
  store i64 %t113, ptr %l15, !tbaa !24
  %t114 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t114, ptr %l72, !tbaa !27
  %t115 = load i64, ptr %l15, !tbaa !24
  %t117 = add i64 %t115, 1
  store i64 %t117, ptr %l74, !tbaa !24
  %t118 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t119 = extractvalue { i64, ptr } %t118, 0
  store i64 %t119, ptr %l75, !tbaa !24
  %t120 = icmp sge i64 0, 0
  br i1 %t120, label %bb35, label %bb36
bb35:
  %t122 = load i64, ptr %l74, !tbaa !24
  %t123 = icmp sle i64 0, %t122
  br i1 %t123, label %bb37, label %bb38
bb36:
  call void @__olang_check_failed(ptr @olang_loc_5357591f61d3ec66_4083edcb137c28ba)
  unreachable
bb37:
  %t125 = load i64, ptr %l74, !tbaa !24
  %t126 = load i64, ptr %l75, !tbaa !24
  %t127 = icmp sle i64 %t125, %t126
  br i1 %t127, label %bb39, label %bb40
bb38:
  call void @__olang_check_failed(ptr @olang_loc_5357591f61d3ec66_4083edcb137c28ba)
  unreachable
bb39:
  %t129 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t130 = load ptr, ptr %t129, !tbaa !27
  %t131 = load i64, ptr %l74, !tbaa !24
  %t132 = getelementptr i8, ptr %t130, i64 0
  %t133 = sub i64 %t131, 0
  %t134 = insertvalue { i64, ptr } undef, i64 %t133, 0
  %t135 = insertvalue { i64, ptr } %t134, ptr %t132, 1
  store { i64, ptr } %t135, ptr %l16, !tbaa !27
  %t137 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t137, ptr %l80, !tbaa !27
  %t138 = load i64, ptr %l15, !tbaa !24
  %t140 = add i64 %t138, 1
  store i64 %t140, ptr %l82, !tbaa !24
  %t141 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t144 = extractvalue { i64, ptr } %t141, 0
  store i64 %t144, ptr %l85, !tbaa !24
  %t145 = load { i64, ptr }, ptr %l80, !tbaa !27
  %t146 = extractvalue { i64, ptr } %t145, 0
  store i64 %t146, ptr %l86, !tbaa !24
  %t147 = load i64, ptr %l82, !tbaa !24
  %t148 = icmp sge i64 %t147, 0
  br i1 %t148, label %bb41, label %bb42
bb40:
  call void @__olang_check_failed(ptr @olang_loc_5357591f61d3ec66_4083edcb137c28ba)
  unreachable
bb41:
  %t150 = load i64, ptr %l82, !tbaa !24
  %t151 = load i64, ptr %l85, !tbaa !24
  %t152 = icmp sle i64 %t150, %t151
  br i1 %t152, label %bb43, label %bb44
bb42:
  call void @__olang_check_failed(ptr @olang_loc_40a6fbbd452759c3_7354b3156286cb97)
  unreachable
bb43:
  %t154 = load i64, ptr %l85, !tbaa !24
  %t155 = load i64, ptr %l86, !tbaa !24
  %t156 = icmp sle i64 %t154, %t155
  br i1 %t156, label %bb45, label %bb46
bb44:
  call void @__olang_check_failed(ptr @olang_loc_40a6fbbd452759c3_7354b3156286cb97)
  unreachable
bb45:
  %t158 = getelementptr { i64, ptr }, ptr %l80, i32 0, i32 1
  %t159 = load ptr, ptr %t158, !tbaa !27
  %t160 = load i64, ptr %l82, !tbaa !24
  %t161 = load i64, ptr %l85, !tbaa !24
  %t162 = getelementptr i8, ptr %t159, i64 %t160
  %t163 = sub i64 %t161, %t160
  %t164 = insertvalue { i64, ptr } undef, i64 %t163, 0
  %t165 = insertvalue { i64, ptr } %t164, ptr %t162, 1
  store { i64, ptr } %t165, ptr %l14, !tbaa !27
  %t167 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t169 = call { i64, ptr } @compiler_2fdiag_2eruleIdAt(ptr %v0, ptr %v0, { i64, ptr } %t167)
  store { i64, ptr } %t169, ptr %l92
  br label %bb47
bb46:
  call void @__olang_check_failed(ptr @olang_loc_40a6fbbd452759c3_7354b3156286cb97)
  unreachable
bb47:
  %t170 = load { i64, ptr }, ptr %l92, !tbaa !27
  store { i64, ptr } %t170, ptr %l17, !tbaa !27
  %t171 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t171, ptr %l93, !tbaa !27
  %t172 = getelementptr { i64, ptr }, ptr %l93, i32 0, i32 1
  %t173 = load ptr, ptr %t172, !tbaa !27
  %t174 = getelementptr i8, ptr %t173, i64 0
  %t175 = load i8, ptr %t174, !tbaa !32
  %t177 = icmp eq i8 %t175, 35
  store i1 %t177, ptr %l18, !tbaa !21
  %t179 = load i1, ptr %l11, !tbaa !21
  br i1 %t179, label %bb48, label %bb49
bb48:
  %t181 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t183 = extractvalue { i64, ptr } %t181, 0
  %t185 = icmp sgt i64 %t183, 0
  br i1 %t185, label %bb50, label %bb51
bb49:
  store i1 false, ptr %l97, !tbaa !21
  br label %bb53
bb50:
  store i1 true, ptr %l101, !tbaa !21
  br label %bb52
bb51:
  %t187 = load i1, ptr %l18, !tbaa !21
  store i1 %t187, ptr %l101, !tbaa !21
  br label %bb52
bb52:
  %t189 = load i1, ptr %l101, !tbaa !21
  store i1 %t189, ptr %l97, !tbaa !21
  br label %bb53
bb53:
  %t190 = load i1, ptr %l97, !tbaa !21
  br i1 %t190, label %bb54, label %bb55
bb54:
  call void @__olang_scope_close(ptr %s4)
  br label %bb115
bb55:
  br label %bb56
bb56:
  %t191 = load i1, ptr %l18, !tbaa !21
  br i1 %t191, label %bb57, label %bb58
bb57:
  %t193 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t193, ptr %l10, !tbaa !27
  call void @__olang_scope_close(ptr %s4)
  br label %bb114
bb58:
  br label %bb59
bb59:
  %t195 = load i1, ptr %l11, !tbaa !21
  %t197 = xor i1 %t195, true
  br i1 %t197, label %bb60, label %bb61
bb60:
  %t199 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t200 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t203 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t199, { i64, ptr } %t200)
  store i1 %t203, ptr %l110
  br label %bb62
bb61:
  store i1 false, ptr %l107, !tbaa !21
  br label %bb63
bb62:
  %t204 = load i1, ptr %l110, !tbaa !21
  store i1 %t204, ptr %l107, !tbaa !21
  br label %bb63
bb63:
  %t205 = load i1, ptr %l107, !tbaa !21
  br i1 %t205, label %bb64, label %bb65
bb64:
  store i1 true, ptr %l11, !tbaa !21
  store i1 true, ptr %l12, !tbaa !21
  store i64 0, ptr %l19, !tbaa !24
  br label %bb66
bb65:
  br label %bb98
bb66:
  %t206 = load i64, ptr %l19, !tbaa !24
  %t207 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t209 = extractvalue { i64, ptr } %t207, 0
  %t212 = icmp slt i64 %t206, %t209
  br i1 %t212, label %bb67, label %bb68
bb67:
  %t214 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t214, ptr %l116, !tbaa !27
  %t215 = load i64, ptr %l19, !tbaa !24
  %t217 = getelementptr { i64, ptr }, ptr %l116, i32 0, i32 1
  %t218 = load ptr, ptr %t217, !tbaa !27
  %t219 = getelementptr i8, ptr %t218, i64 %t215
  %t220 = load i8, ptr %t219, !tbaa !32
  %t222 = icmp eq i8 %t220, 35
  br i1 %t222, label %bb69, label %bb70
bb68:
  store i1 false, ptr %l115, !tbaa !21
  br label %bb72
bb69:
  store i1 true, ptr %l120, !tbaa !21
  br label %bb71
bb70:
  %t224 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t224, ptr %l121, !tbaa !27
  %t225 = load i64, ptr %l19, !tbaa !24
  %t227 = getelementptr { i64, ptr }, ptr %l121, i32 0, i32 1
  %t228 = load ptr, ptr %t227, !tbaa !27
  %t229 = getelementptr i8, ptr %t228, i64 %t225
  %t230 = load i8, ptr %t229, !tbaa !32
  %t232 = icmp eq i8 %t230, 32
  store i1 %t232, ptr %l120, !tbaa !21
  br label %bb71
bb71:
  %t234 = load i1, ptr %l120, !tbaa !21
  store i1 %t234, ptr %l115, !tbaa !21
  br label %bb72
bb72:
  %t235 = load i1, ptr %l115, !tbaa !21
  %t236 = xor i1 %t235, true
  br i1 %t236, label %bb73, label %bb74
bb73:
  br label %bb77
bb74:
  br label %bb75
bb75:
  %t238 = load i64, ptr %l19, !tbaa !24
  %t241 = add i64 %t238, 1
  store i64 %t241, ptr %l19, !tbaa !24
  br label %bb76
bb76:
  br label %bb66
bb77:
  %t243 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t245 = extractvalue { i64, ptr } %t243, 0
  %t247 = icmp sgt i64 %t245, 0
  br i1 %t247, label %bb78, label %bb79
bb78:
  %t249 = load i64, ptr %l19, !tbaa !24
  %t250 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t252 = extractvalue { i64, ptr } %t250, 0
  %t255 = icmp slt i64 %t249, %t252
  br i1 %t255, label %bb80, label %bb81
bb79:
  br label %bb97
bb80:
  %t257 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t257, ptr %l137, !tbaa !27
  %t258 = load i64, ptr %l19, !tbaa !24
  %t260 = getelementptr { i64, ptr }, ptr %l137, i32 0, i32 1
  %t261 = load ptr, ptr %t260, !tbaa !27
  %t262 = getelementptr i8, ptr %t261, i64 %t258
  %t263 = load i8, ptr %t262, !tbaa !32
  %t265 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t263)
  store i1 %t265, ptr %l140
  br label %bb82
bb81:
  store i1 false, ptr %l136, !tbaa !21
  br label %bb83
bb82:
  %t266 = load i1, ptr %l140, !tbaa !21
  store i1 %t266, ptr %l136, !tbaa !21
  br label %bb83
bb83:
  %t267 = load i1, ptr %l136, !tbaa !21
  br i1 %t267, label %bb84, label %bb85
bb84:
  store %olang.scope zeroinitializer, ptr %s10
  store ptr %l9, ptr %l141, !tbaa !29
  %t268 = call { i64, ptr } @compiler_2fdiag_2esection(ptr %s10)
  store { i64, ptr } %t268, ptr %l142
  br label %bb86
bb85:
  br label %bb88
bb86:
  %t269 = load { i64, ptr }, ptr %l142, !tbaa !27
  %t270 = load ptr, ptr %l141, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s10, ptr %t270, { i64, ptr } %t269)
  br label %bb87
bb87:
  call void @__olang_scope_close(ptr %s10)
  br label %bb88
bb88:
  store ptr %l9, ptr %l144, !tbaa !29
  %t272 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t272, ptr %l145, !tbaa !27
  %t273 = load i64, ptr %l19, !tbaa !24
  store i64 %t273, ptr %l146, !tbaa !24
  %t274 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t277 = extractvalue { i64, ptr } %t274, 0
  store i64 %t277, ptr %l149, !tbaa !24
  %t278 = load { i64, ptr }, ptr %l145, !tbaa !27
  %t279 = extractvalue { i64, ptr } %t278, 0
  store i64 %t279, ptr %l150, !tbaa !24
  %t280 = load i64, ptr %l146, !tbaa !24
  %t281 = icmp sge i64 %t280, 0
  br i1 %t281, label %bb89, label %bb90
bb89:
  %t283 = load i64, ptr %l146, !tbaa !24
  %t284 = load i64, ptr %l149, !tbaa !24
  %t285 = icmp sle i64 %t283, %t284
  br i1 %t285, label %bb91, label %bb92
bb90:
  call void @__olang_check_failed(ptr @olang_loc_eb08610c80fa023c_21bad482e9cc9598)
  unreachable
bb91:
  %t287 = load i64, ptr %l149, !tbaa !24
  %t288 = load i64, ptr %l150, !tbaa !24
  %t289 = icmp sle i64 %t287, %t288
  br i1 %t289, label %bb93, label %bb94
bb92:
  call void @__olang_check_failed(ptr @olang_loc_eb08610c80fa023c_21bad482e9cc9598)
  unreachable
bb93:
  %t291 = getelementptr { i64, ptr }, ptr %l145, i32 0, i32 1
  %t292 = load ptr, ptr %t291, !tbaa !27
  %t293 = load i64, ptr %l146, !tbaa !24
  %t294 = load i64, ptr %l149, !tbaa !24
  %t295 = getelementptr i8, ptr %t292, i64 %t293
  %t296 = sub i64 %t294, %t293
  %t297 = insertvalue { i64, ptr } undef, i64 %t296, 0
  %t298 = insertvalue { i64, ptr } %t297, ptr %t295, 1
  %t299 = load ptr, ptr %l144, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t299, { i64, ptr } %t298)
  br label %bb95
bb94:
  call void @__olang_check_failed(ptr @olang_loc_eb08610c80fa023c_21bad482e9cc9598)
  unreachable
bb95:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l9, i8 10)
  br label %bb96
bb96:
  br label %bb97
bb97:
  br label %bb98
bb98:
  %t302 = load i1, ptr %l11, !tbaa !21
  %t304 = xor i1 %t302, true
  br i1 %t304, label %bb99, label %bb100
bb99:
  call void @__olang_scope_close(ptr %s4)
  br label %bb114
bb100:
  br label %bb101
bb101:
  %t306 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t308 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s4, { i64, ptr } %t306, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d0, i32 0, i32 1) })
  store i1 %t308, ptr %l159
  br label %bb102
bb102:
  %t309 = load i1, ptr %l159, !tbaa !21
  br i1 %t309, label %bb103, label %bb104
bb103:
  %t310 = load i64, ptr %l13, !tbaa !24
  %t313 = add i64 %t310, 1
  store i64 %t313, ptr %l13, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  br label %bb114
bb104:
  br label %bb105
bb105:
  br label %bb106
bb106:
  %t315 = load i64, ptr %l13, !tbaa !24
  %t317 = icmp sgt i64 %t315, 0
  %t319 = xor i1 %t317, true
  br i1 %t319, label %bb107, label %bb108
bb107:
  br label %bb112
bb108:
  br label %bb109
bb109:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l9, i8 10)
  br label %bb110
bb110:
  %t322 = load i64, ptr %l13, !tbaa !24
  %t325 = sub i64 %t322, 1
  store i64 %t325, ptr %l13, !tbaa !24
  br label %bb111
bb111:
  br label %bb106
bb112:
  %t327 = load { i64, ptr }, ptr %l16, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %l9, { i64, ptr } %t327)
  br label %bb113
bb113:
  call void @__olang_scope_close(ptr %s4)
  br label %bb114
bb114:
  br label %bb27
bb115:
  %t330 = load i1, ptr %l12, !tbaa !21
  %t332 = xor i1 %t330, true
  br i1 %t332, label %bb116, label %bb117
bb116:
  call void @__olang_scope_close(ptr %s0)
  %t335 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t335, ptr %rv
  br label %ret
bb117:
  br label %bb118
bb118:
  %t337 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l9)
  store { i64, ptr } %t337, ptr %l176
  br label %bb119
bb119:
  call void @__olang_scope_close(ptr %s0)
  %t338 = load { i64, ptr }, ptr %l176, !tbaa !27
  %t339 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t338, 1
  store { i32, { i64, ptr } } %t339, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local i1 @compiler_2fdiag_2eScripting(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca i1
  %l3 = alloca i1
  %l5 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call i1 @compiler_2fdiag_2eUntidy(ptr %v0, { i64, ptr } %t1)
  store i1 %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load i1, ptr %l2, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb5
bb3:
  %t5 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t7 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t5, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d1, i32 0, i32 1) })
  store i1 %t7, ptr %l5
  br label %bb4
bb4:
  %t8 = load i1, ptr %l5, !tbaa !21
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  %t9 = load i1, ptr %l3, !tbaa !21
  store i1 %t9, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eForget(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l26 = alloca i1
  %l27 = alloca i64
  %l30 = alloca i64
  %l35 = alloca i64
  %l38 = alloca i64
  %l45 = alloca i64
  %l49 = alloca i64
  %l52 = alloca i64
  %l73 = alloca %"compiler/diag:note"
  %l78 = alloca ptr
  %l79 = alloca i64
  %l83 = alloca %"compiler/diag:note"
  %l95 = alloca i64
  %l99 = alloca i64
  %l102 = alloca i64
  %l123 = alloca i64
  %l127 = alloca ptr
  %l128 = alloca i64
  %l132 = alloca i64
  %l144 = alloca i64
  %l148 = alloca i64
  %l151 = alloca i64
  %l172 = alloca i64
  %l176 = alloca ptr
  %l177 = alloca i64
  %l181 = alloca i64
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp sge i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i64, ptr %l2, !tbaa !24
  store i64 %t5, ptr %l27, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/diag:Diagnostics", ptr %t6, i32 0, i32 26
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3arecord_3e_2eLen_3ccompiler_2fdiag_3arecord_3e(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l30
  br label %bb3
bb2:
  store i1 false, ptr %l26, !tbaa !21
  br label %bb4
bb3:
  %t11 = load i64, ptr %l27, !tbaa !24
  %t12 = load i64, ptr %l30, !tbaa !24
  %t13 = icmp slt i64 %t11, %t12
  store i1 %t13, ptr %l26, !tbaa !21
  br label %bb4
bb4:
  %t15 = load i1, ptr %l26, !tbaa !21
  br i1 %t15, label %bb5, label %bb6
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/diag:Diagnostics", ptr %t16, i32 0, i32 26
  %t19 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3arecord_3e_2eTruncate_3ccompiler_2fdiag_3arecord_3e(ptr %v0, ptr %t18, i64 %t19)
  br label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb8
bb8:
  %t22 = load i64, ptr %l1, !tbaa !24
  store i64 %t22, ptr %l35, !tbaa !24
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/diag:Diagnostics", ptr %t23, i32 0, i32 7
  %t27 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3arecord_3e_2eLen_3ccompiler_2fdiag_3arecord_3e(ptr %v0, ptr %t25)
  store i64 %t27, ptr %l38
  br label %bb9
bb9:
  %t28 = load i64, ptr %l35, !tbaa !24
  %t29 = load i64, ptr %l38, !tbaa !24
  %t30 = icmp sge i64 %t28, %t29
  br i1 %t30, label %bb10, label %bb11
bb10:
  br label %ret
bb11:
  br label %bb12
bb12:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/diag:Diagnostics", ptr %t32, i32 0, i32 7
  %t35 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3arecord_3e_2eTruncate_3ccompiler_2fdiag_3arecord_3e(ptr %v0, ptr %t34, i64 %t35)
  br label %bb13
bb13:
  store i64 0, ptr %l3, !tbaa !24
  store i64 0, ptr %l4, !tbaa !24
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/diag:Diagnostics", ptr %t38, i32 0, i32 8
  %t42 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3anote_3e_2eLen_3ccompiler_2fdiag_3anote_3e(ptr %v0, ptr %t40)
  store i64 %t42, ptr %l45
  br label %bb14
bb14:
  %t43 = load i64, ptr %l45, !tbaa !24
  store i64 %t43, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t44 = load i64, ptr %l5, !tbaa !24
  %t45 = load i64, ptr %l4, !tbaa !24
  %t48 = icmp sgt i64 %t44, %t45
  br i1 %t48, label %bb15, label %bb16
bb15:
  %t50 = load i64, ptr %l6, !tbaa !24
  %t52 = icmp sgt i64 %t50, 0
  br i1 %t52, label %bb17, label %bb18
bb16:
  store i64 0, ptr %l49, !tbaa !24
  br label %bb20
bb17:
  %t54 = load i64, ptr %l5, !tbaa !24
  %t55 = load i64, ptr %l4, !tbaa !24
  %t58 = sub i64 %t54, %t55
  %t59 = load i64, ptr %l6, !tbaa !24
  %t62 = add i64 %t58, %t59
  %t64 = sub i64 %t62, 1
  %t65 = load i64, ptr %l6, !tbaa !24
  %t68 = sdiv i64 %t64, %t65
  store i64 %t68, ptr %l52, !tbaa !24
  br label %bb19
bb18:
  store i64 0, ptr %l52, !tbaa !24
  br label %bb19
bb19:
  %t70 = load i64, ptr %l52, !tbaa !24
  store i64 %t70, ptr %l49, !tbaa !24
  br label %bb20
bb20:
  %t71 = load i64, ptr %l49, !tbaa !24
  store i64 %t71, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb21
bb21:
  store %olang.scope zeroinitializer, ptr %s4
  %t72 = load i64, ptr %l8, !tbaa !24
  %t73 = load i64, ptr %l7, !tbaa !24
  %t76 = icmp slt i64 %t72, %t73
  %t78 = xor i1 %t76, true
  br i1 %t78, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s4)
  br label %bb32
bb23:
  br label %bb24
bb24:
  %t80 = load i64, ptr %l4, !tbaa !24
  %t81 = load i64, ptr %l8, !tbaa !24
  %t82 = load i64, ptr %l6, !tbaa !24
  %t85 = mul i64 %t81, %t82
  %t88 = add i64 %t80, %t85
  store i64 %t88, ptr %l9, !tbaa !24
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/diag:Diagnostics", ptr %t90, i32 0, i32 8
  %t93 = load i64, ptr %l9, !tbaa !24
  %t96 = call %"compiler/diag:note" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3anote_3e_2eAt_3ccompiler_2fdiag_3anote_3e(ptr %v0, ptr %s4, ptr %t92, i64 %t93)
  store %"compiler/diag:note" %t96, ptr %l73
  br label %bb25
bb25:
  %t97 = getelementptr %"compiler/diag:note", ptr %l73, i32 0, i32 0
  %t98 = load i64, ptr %t97, !tbaa !24
  %t99 = load i64, ptr %l1, !tbaa !24
  %t102 = icmp slt i64 %t98, %t99
  br i1 %t102, label %bb26, label %bb27
bb26:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = getelementptr %"compiler/diag:Diagnostics", ptr %t104, i32 0, i32 8
  store ptr %t106, ptr %l78, !tbaa !29
  %t107 = load i64, ptr %l3, !tbaa !24
  store i64 %t107, ptr %l79, !tbaa !24
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/diag:Diagnostics", ptr %t108, i32 0, i32 8
  %t111 = load i64, ptr %l9, !tbaa !24
  %t114 = call %"compiler/diag:note" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3anote_3e_2eAt_3ccompiler_2fdiag_3anote_3e(ptr %v0, ptr %v0, ptr %t110, i64 %t111)
  store %"compiler/diag:note" %t114, ptr %l83
  br label %bb28
bb27:
  br label %bb30
bb28:
  %t115 = load ptr, ptr %l78, !tbaa !29
  %t116 = load i64, ptr %l79, !tbaa !24
  %t117 = load %"compiler/diag:note", ptr %l83
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3anote_3e_2eSetAt_3ccompiler_2fdiag_3anote_3e(ptr %v0, ptr %v0, ptr %t115, i64 %t116, %"compiler/diag:note" %t117)
  br label %bb29
bb29:
  %t118 = load i64, ptr %l3, !tbaa !24
  %t121 = add i64 %t118, 1
  store i64 %t121, ptr %l3, !tbaa !24
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s4)
  br label %bb31
bb31:
  %t123 = load i64, ptr %l8, !tbaa !24
  %t126 = add i64 %t123, 1
  store i64 %t126, ptr %l8, !tbaa !24
  br label %bb21
bb32:
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t130 = getelementptr %"compiler/diag:Diagnostics", ptr %t128, i32 0, i32 8
  %t131 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3anote_3e_2eTruncate_3ccompiler_2fdiag_3anote_3e(ptr %v0, ptr %t130, i64 %t131)
  br label %bb33
bb33:
  store i64 0, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr %"compiler/diag:Diagnostics", ptr %t134, i32 0, i32 16
  %t138 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t136)
  store i64 %t138, ptr %l95
  br label %bb34
bb34:
  %t139 = load i64, ptr %l95, !tbaa !24
  store i64 %t139, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t140 = load i64, ptr %l12, !tbaa !24
  %t141 = load i64, ptr %l11, !tbaa !24
  %t144 = icmp sgt i64 %t140, %t141
  br i1 %t144, label %bb35, label %bb36
bb35:
  %t146 = load i64, ptr %l13, !tbaa !24
  %t148 = icmp sgt i64 %t146, 0
  br i1 %t148, label %bb37, label %bb38
bb36:
  store i64 0, ptr %l99, !tbaa !24
  br label %bb40
bb37:
  %t150 = load i64, ptr %l12, !tbaa !24
  %t151 = load i64, ptr %l11, !tbaa !24
  %t154 = sub i64 %t150, %t151
  %t155 = load i64, ptr %l13, !tbaa !24
  %t158 = add i64 %t154, %t155
  %t160 = sub i64 %t158, 1
  %t161 = load i64, ptr %l13, !tbaa !24
  %t164 = sdiv i64 %t160, %t161
  store i64 %t164, ptr %l102, !tbaa !24
  br label %bb39
bb38:
  store i64 0, ptr %l102, !tbaa !24
  br label %bb39
bb39:
  %t166 = load i64, ptr %l102, !tbaa !24
  store i64 %t166, ptr %l99, !tbaa !24
  br label %bb40
bb40:
  %t167 = load i64, ptr %l99, !tbaa !24
  store i64 %t167, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb41
bb41:
  %t168 = load i64, ptr %l15, !tbaa !24
  %t169 = load i64, ptr %l14, !tbaa !24
  %t172 = icmp slt i64 %t168, %t169
  %t174 = xor i1 %t172, true
  br i1 %t174, label %bb42, label %bb43
bb42:
  br label %bb52
bb43:
  br label %bb44
bb44:
  %t176 = load i64, ptr %l11, !tbaa !24
  %t177 = load i64, ptr %l15, !tbaa !24
  %t178 = load i64, ptr %l13, !tbaa !24
  %t181 = mul i64 %t177, %t178
  %t184 = add i64 %t176, %t181
  store i64 %t184, ptr %l16, !tbaa !24
  %t186 = load ptr, ptr %l0, !tbaa !29
  %t188 = getelementptr %"compiler/diag:Diagnostics", ptr %t186, i32 0, i32 16
  %t189 = load i64, ptr %l16, !tbaa !24
  %t192 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t188, i64 %t189)
  store i64 %t192, ptr %l123
  br label %bb45
bb45:
  %t193 = load i64, ptr %l1, !tbaa !24
  %t194 = load i64, ptr %l123, !tbaa !24
  %t196 = icmp slt i64 %t194, %t193
  br i1 %t196, label %bb46, label %bb47
bb46:
  %t198 = load ptr, ptr %l0, !tbaa !29
  %t200 = getelementptr %"compiler/diag:Diagnostics", ptr %t198, i32 0, i32 16
  store ptr %t200, ptr %l127, !tbaa !29
  %t201 = load i64, ptr %l10, !tbaa !24
  store i64 %t201, ptr %l128, !tbaa !24
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t204 = getelementptr %"compiler/diag:Diagnostics", ptr %t202, i32 0, i32 16
  %t205 = load i64, ptr %l16, !tbaa !24
  %t208 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t204, i64 %t205)
  store i64 %t208, ptr %l132
  br label %bb48
bb47:
  br label %bb50
bb48:
  %t209 = load ptr, ptr %l127, !tbaa !29
  %t210 = load i64, ptr %l128, !tbaa !24
  %t211 = load i64, ptr %l132, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t209, i64 %t210, i64 %t211)
  br label %bb49
bb49:
  %t212 = load i64, ptr %l10, !tbaa !24
  %t215 = add i64 %t212, 1
  store i64 %t215, ptr %l10, !tbaa !24
  br label %bb50
bb50:
  br label %bb51
bb51:
  %t217 = load i64, ptr %l15, !tbaa !24
  %t220 = add i64 %t217, 1
  store i64 %t220, ptr %l15, !tbaa !24
  br label %bb41
bb52:
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t224 = getelementptr %"compiler/diag:Diagnostics", ptr %t222, i32 0, i32 16
  %t225 = load i64, ptr %l10, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eTruncate_3cI64_3e(ptr %v0, ptr %t224, i64 %t225)
  br label %bb53
bb53:
  store i64 0, ptr %l17, !tbaa !24
  store i64 0, ptr %l18, !tbaa !24
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t230 = getelementptr %"compiler/diag:Diagnostics", ptr %t228, i32 0, i32 17
  %t232 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t230)
  store i64 %t232, ptr %l144
  br label %bb54
bb54:
  %t233 = load i64, ptr %l144, !tbaa !24
  store i64 %t233, ptr %l19, !tbaa !24
  store i64 1, ptr %l20, !tbaa !24
  %t234 = load i64, ptr %l19, !tbaa !24
  %t235 = load i64, ptr %l18, !tbaa !24
  %t238 = icmp sgt i64 %t234, %t235
  br i1 %t238, label %bb55, label %bb56
bb55:
  %t240 = load i64, ptr %l20, !tbaa !24
  %t242 = icmp sgt i64 %t240, 0
  br i1 %t242, label %bb57, label %bb58
bb56:
  store i64 0, ptr %l148, !tbaa !24
  br label %bb60
bb57:
  %t244 = load i64, ptr %l19, !tbaa !24
  %t245 = load i64, ptr %l18, !tbaa !24
  %t248 = sub i64 %t244, %t245
  %t249 = load i64, ptr %l20, !tbaa !24
  %t252 = add i64 %t248, %t249
  %t254 = sub i64 %t252, 1
  %t255 = load i64, ptr %l20, !tbaa !24
  %t258 = sdiv i64 %t254, %t255
  store i64 %t258, ptr %l151, !tbaa !24
  br label %bb59
bb58:
  store i64 0, ptr %l151, !tbaa !24
  br label %bb59
bb59:
  %t260 = load i64, ptr %l151, !tbaa !24
  store i64 %t260, ptr %l148, !tbaa !24
  br label %bb60
bb60:
  %t261 = load i64, ptr %l148, !tbaa !24
  store i64 %t261, ptr %l21, !tbaa !24
  store i64 0, ptr %l22, !tbaa !24
  br label %bb61
bb61:
  %t262 = load i64, ptr %l22, !tbaa !24
  %t263 = load i64, ptr %l21, !tbaa !24
  %t266 = icmp slt i64 %t262, %t263
  %t268 = xor i1 %t266, true
  br i1 %t268, label %bb62, label %bb63
bb62:
  br label %bb72
bb63:
  br label %bb64
bb64:
  %t270 = load i64, ptr %l18, !tbaa !24
  %t271 = load i64, ptr %l22, !tbaa !24
  %t272 = load i64, ptr %l20, !tbaa !24
  %t275 = mul i64 %t271, %t272
  %t278 = add i64 %t270, %t275
  store i64 %t278, ptr %l23, !tbaa !24
  %t280 = load ptr, ptr %l0, !tbaa !29
  %t282 = getelementptr %"compiler/diag:Diagnostics", ptr %t280, i32 0, i32 17
  %t283 = load i64, ptr %l23, !tbaa !24
  %t286 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t282, i64 %t283)
  store i64 %t286, ptr %l172
  br label %bb65
bb65:
  %t287 = load i64, ptr %l1, !tbaa !24
  %t288 = load i64, ptr %l172, !tbaa !24
  %t290 = icmp slt i64 %t288, %t287
  br i1 %t290, label %bb66, label %bb67
bb66:
  %t292 = load ptr, ptr %l0, !tbaa !29
  %t294 = getelementptr %"compiler/diag:Diagnostics", ptr %t292, i32 0, i32 17
  store ptr %t294, ptr %l176, !tbaa !29
  %t295 = load i64, ptr %l17, !tbaa !24
  store i64 %t295, ptr %l177, !tbaa !24
  %t296 = load ptr, ptr %l0, !tbaa !29
  %t298 = getelementptr %"compiler/diag:Diagnostics", ptr %t296, i32 0, i32 17
  %t299 = load i64, ptr %l23, !tbaa !24
  %t302 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t298, i64 %t299)
  store i64 %t302, ptr %l181
  br label %bb68
bb67:
  br label %bb70
bb68:
  %t303 = load ptr, ptr %l176, !tbaa !29
  %t304 = load i64, ptr %l177, !tbaa !24
  %t305 = load i64, ptr %l181, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t303, i64 %t304, i64 %t305)
  br label %bb69
bb69:
  %t306 = load i64, ptr %l17, !tbaa !24
  %t309 = add i64 %t306, 1
  store i64 %t309, ptr %l17, !tbaa !24
  br label %bb70
bb70:
  br label %bb71
bb71:
  %t311 = load i64, ptr %l22, !tbaa !24
  %t314 = add i64 %t311, 1
  store i64 %t314, ptr %l22, !tbaa !24
  br label %bb61
bb72:
  %t316 = load ptr, ptr %l0, !tbaa !29
  %t318 = getelementptr %"compiler/diag:Diagnostics", ptr %t316, i32 0, i32 17
  %t319 = load i64, ptr %l17, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eTruncate_3cI64_3e(ptr %v0, ptr %t318, i64 %t319)
  br label %bb73
bb73:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eRender(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca %"compiler/diag:record"
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca %"compiler/diag:note"
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca %"compiler/diag:note"
  %l13 = alloca %"std/prelude/text:StringBuilder"
  %l15 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l29 = alloca %"compiler/diag:record"
  %l37 = alloca i64
  %l39 = alloca i64
  %l44 = alloca %"compiler/diag:note"
  %l48 = alloca i1
  %l59 = alloca i64
  %l61 = alloca i64
  %l66 = alloca %"compiler/diag:note"
  %l70 = alloca i1
  %l87 = alloca ptr
  %l91 = alloca { i64, ptr }
  %l118 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l13
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l13
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  store %olang.scope zeroinitializer, ptr %s1
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2ewritten(ptr %v0, ptr %s1, ptr %t3)
  store { i64, ptr } %t5, ptr %l15
  br label %bb2
bb2:
  %t6 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t6, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t8 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t8, 0
  store i64 %t10, ptr %l4, !tbaa !24
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t12 = load i64, ptr %l3, !tbaa !24
  %t13 = load i64, ptr %l4, !tbaa !24
  %t16 = icmp slt i64 %t12, %t13
  %t18 = xor i1 %t16, true
  br i1 %t18, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s2)
  br label %bb40
bb5:
  br label %bb6
bb6:
  %t20 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t20, ptr %l23, !tbaa !27
  %t21 = load i64, ptr %l3, !tbaa !24
  %t23 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = getelementptr i64, ptr %t24, i64 %t21
  %t26 = load i64, ptr %t25, !tbaa !34
  store i64 %t26, ptr %l5, !tbaa !24
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/diag:Diagnostics", ptr %t28, i32 0, i32 7
  %t31 = load i64, ptr %l5, !tbaa !24
  %t34 = call %"compiler/diag:record" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3arecord_3e_2eAt_3ccompiler_2fdiag_3arecord_3e(ptr %v0, ptr %v0, ptr %t30, i64 %t31)
  store %"compiler/diag:record" %t34, ptr %l29
  br label %bb7
bb7:
  %t35 = load %"compiler/diag:record", ptr %l29
  store %"compiler/diag:record" %t35, ptr %l6
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/diag:record", ptr %l6, i32 0, i32 0
  %t38 = load { i64, [3 x i64] }, ptr %t37
  %t39 = getelementptr %"compiler/diag:record", ptr %l6, i32 0, i32 1
  %t40 = load { i64, ptr }, ptr %t39, !tbaa !27
  %t41 = getelementptr %"compiler/diag:record", ptr %l6, i32 0, i32 2
  %t42 = load { i64, ptr }, ptr %t41, !tbaa !27
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eputRow(ptr %v0, ptr %s0, ptr %s2, ptr %v0, ptr %v0, ptr %t36, ptr %l1, { i64, [3 x i64] } %t38, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d2, i32 0, i32 1) }, { i64, ptr } %t40, { i64, ptr } %t42)
  br label %bb8
bb8:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/diag:Diagnostics", ptr %t48, i32 0, i32 8
  store ptr %t50, ptr %l7, !tbaa !29
  store i64 0, ptr %l8, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s4
  %t52 = load i64, ptr %l8, !tbaa !24
  store i64 %t52, ptr %l37, !tbaa !24
  %t53 = load ptr, ptr %l7, !tbaa !29
  %t55 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3anote_3e_2eLen_3ccompiler_2fdiag_3anote_3e(ptr %v0, ptr %t53)
  store i64 %t55, ptr %l39
  br label %bb10
bb10:
  %t56 = load i64, ptr %l37, !tbaa !24
  %t57 = load i64, ptr %l39, !tbaa !24
  %t58 = icmp slt i64 %t56, %t57
  %t60 = xor i1 %t58, true
  br i1 %t60, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s4)
  br label %bb23
bb12:
  br label %bb13
bb13:
  %t62 = load ptr, ptr %l7, !tbaa !29
  %t63 = load i64, ptr %l8, !tbaa !24
  %t66 = call %"compiler/diag:note" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3anote_3e_2eAt_3ccompiler_2fdiag_3anote_3e(ptr %v0, ptr %v0, ptr %t62, i64 %t63)
  store %"compiler/diag:note" %t66, ptr %l44
  br label %bb14
bb14:
  %t67 = load %"compiler/diag:note", ptr %l44
  store %"compiler/diag:note" %t67, ptr %l9
  %t68 = getelementptr %"compiler/diag:note", ptr %l9, i32 0, i32 0
  %t69 = load i64, ptr %t68, !tbaa !24
  %t70 = load i64, ptr %l5, !tbaa !24
  %t73 = icmp eq i64 %t69, %t70
  br i1 %t73, label %bb15, label %bb16
bb15:
  %t75 = getelementptr %"compiler/diag:note", ptr %l9, i32 0, i32 3
  %t76 = load i1, ptr %t75, !tbaa !21
  %t78 = xor i1 %t76, true
  store i1 %t78, ptr %l48, !tbaa !21
  br label %bb17
bb16:
  store i1 false, ptr %l48, !tbaa !21
  br label %bb17
bb17:
  %t80 = load i1, ptr %l48, !tbaa !21
  br i1 %t80, label %bb18, label %bb19
bb18:
  %t81 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eputNote(ptr %v0, ptr %s0, ptr %s4, ptr %t81, ptr %l1, ptr %l9)
  br label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s4)
  br label %bb22
bb22:
  %t85 = load i64, ptr %l8, !tbaa !24
  %t88 = add i64 %t85, 1
  store i64 %t88, ptr %l8, !tbaa !24
  br label %bb9
bb23:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/diag:Diagnostics", ptr %t90, i32 0, i32 8
  store ptr %t92, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  br label %bb24
bb24:
  store %olang.scope zeroinitializer, ptr %s8
  %t94 = load i64, ptr %l11, !tbaa !24
  store i64 %t94, ptr %l59, !tbaa !24
  %t95 = load ptr, ptr %l10, !tbaa !29
  %t97 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3anote_3e_2eLen_3ccompiler_2fdiag_3anote_3e(ptr %v0, ptr %t95)
  store i64 %t97, ptr %l61
  br label %bb25
bb25:
  %t98 = load i64, ptr %l59, !tbaa !24
  %t99 = load i64, ptr %l61, !tbaa !24
  %t100 = icmp slt i64 %t98, %t99
  %t102 = xor i1 %t100, true
  br i1 %t102, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s8)
  br label %bb38
bb27:
  br label %bb28
bb28:
  %t104 = load ptr, ptr %l10, !tbaa !29
  %t105 = load i64, ptr %l11, !tbaa !24
  %t108 = call %"compiler/diag:note" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3anote_3e_2eAt_3ccompiler_2fdiag_3anote_3e(ptr %v0, ptr %v0, ptr %t104, i64 %t105)
  store %"compiler/diag:note" %t108, ptr %l66
  br label %bb29
bb29:
  %t109 = load %"compiler/diag:note", ptr %l66
  store %"compiler/diag:note" %t109, ptr %l12
  %t110 = getelementptr %"compiler/diag:note", ptr %l12, i32 0, i32 0
  %t111 = load i64, ptr %t110, !tbaa !24
  %t112 = load i64, ptr %l5, !tbaa !24
  %t115 = icmp eq i64 %t111, %t112
  br i1 %t115, label %bb30, label %bb31
bb30:
  %t117 = getelementptr %"compiler/diag:note", ptr %l12, i32 0, i32 3
  %t118 = load i1, ptr %t117, !tbaa !21
  store i1 %t118, ptr %l70, !tbaa !21
  br label %bb32
bb31:
  store i1 false, ptr %l70, !tbaa !21
  br label %bb32
bb32:
  %t120 = load i1, ptr %l70, !tbaa !21
  br i1 %t120, label %bb33, label %bb34
bb33:
  %t121 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eputNote(ptr %v0, ptr %s0, ptr %s8, ptr %t121, ptr %l1, ptr %l12)
  br label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s8)
  br label %bb37
bb37:
  %t125 = load i64, ptr %l11, !tbaa !24
  %t128 = add i64 %t125, 1
  store i64 %t128, ptr %l11, !tbaa !24
  br label %bb24
bb38:
  call void @__olang_scope_close(ptr %s2)
  br label %bb39
bb39:
  %t130 = load i64, ptr %l3, !tbaa !24
  %t133 = add i64 %t130, 1
  store i64 %t133, ptr %l3, !tbaa !24
  br label %bb3
bb40:
  call void @__olang_scope_close(ptr %s1)
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t137 = getelementptr %"compiler/diag:Diagnostics", ptr %t135, i32 0, i32 23
  %t138 = load i1, ptr %t137, !tbaa !21
  br i1 %t138, label %bb41, label %bb42
bb41:
  store %olang.scope zeroinitializer, ptr %s12
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t143 = getelementptr %"compiler/diag:Diagnostics", ptr %t141, i32 0, i32 18
  %t144 = load { i64, [3 x i64] }, ptr %t143
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eputLocation(ptr %v0, ptr %s0, ptr %t140, ptr %l1, { i64, [3 x i64] } %t144)
  br label %bb43
bb42:
  br label %bb56
bb43:
  store ptr %l1, ptr %l87, !tbaa !29
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t151 = getelementptr %"compiler/diag:Diagnostics", ptr %t149, i32 0, i32 19
  %t152 = load { i64, ptr }, ptr %t151, !tbaa !27
  %t155 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eerrorWord(ptr %v0, ptr %v0, ptr %s12, ptr %t148, { i64, ptr } %t152)
  store { i64, ptr } %t155, ptr %l91
  br label %bb44
bb44:
  %t156 = load { i64, ptr }, ptr %l91, !tbaa !27
  %t157 = load ptr, ptr %l87, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s12, ptr %t157, { i64, ptr } %t156)
  br label %bb45
bb45:
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t161 = getelementptr %"compiler/diag:Diagnostics", ptr %t159, i32 0, i32 20
  %t162 = load { i64, ptr }, ptr %t161, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %l1, { i64, ptr } %t162)
  br label %bb46
bb46:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 10)
  br label %bb47
bb47:
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t168 = getelementptr %"compiler/diag:Diagnostics", ptr %t166, i32 0, i32 21
  %t169 = load { i64, ptr }, ptr %t168, !tbaa !27
  %t171 = extractvalue { i64, ptr } %t169, 0
  %t173 = icmp sgt i64 %t171, 0
  br i1 %t173, label %bb48, label %bb49
bb48:
  store %olang.scope zeroinitializer, ptr %s13
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t178 = getelementptr %"compiler/diag:Diagnostics", ptr %t176, i32 0, i32 18
  %t179 = load { i64, [3 x i64] }, ptr %t178
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t182 = getelementptr %"compiler/diag:Diagnostics", ptr %t180, i32 0, i32 21
  %t183 = load { i64, ptr }, ptr %t182, !tbaa !27
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eputPlain(ptr %v0, ptr %s0, ptr %s13, ptr %v0, ptr %t175, ptr %l1, { i64, [3 x i64] } %t179, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d3, i32 0, i32 1) }, { i64, ptr } %t183)
  br label %bb50
bb49:
  br label %bb51
bb50:
  call void @__olang_scope_close(ptr %s13)
  br label %bb51
bb51:
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t190 = getelementptr %"compiler/diag:Diagnostics", ptr %t188, i32 0, i32 22
  %t191 = load { i64, ptr }, ptr %t190, !tbaa !27
  %t193 = extractvalue { i64, ptr } %t191, 0
  %t195 = icmp sgt i64 %t193, 0
  br i1 %t195, label %bb52, label %bb53
bb52:
  store %olang.scope zeroinitializer, ptr %s14
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t198 = load ptr, ptr %l0, !tbaa !29
  %t200 = getelementptr %"compiler/diag:Diagnostics", ptr %t198, i32 0, i32 18
  %t201 = load { i64, [3 x i64] }, ptr %t200
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t204 = getelementptr %"compiler/diag:Diagnostics", ptr %t202, i32 0, i32 22
  %t205 = load { i64, ptr }, ptr %t204, !tbaa !27
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eputPlain(ptr %v0, ptr %s0, ptr %s14, ptr %v0, ptr %t197, ptr %l1, { i64, [3 x i64] } %t201, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d4, i32 0, i32 1) }, { i64, ptr } %t205)
  br label %bb54
bb53:
  br label %bb55
bb54:
  call void @__olang_scope_close(ptr %s14)
  br label %bb55
bb55:
  call void @__olang_scope_close(ptr %s12)
  br label %bb56
bb56:
  %t211 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t211, ptr %l118
  br label %bb57
bb57:
  call void @__olang_scope_close(ptr %s0)
  %t212 = load { i64, ptr }, ptr %l118, !tbaa !27
  store { i64, ptr } %t212, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eSetFrom(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca ptr
  %l9 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca i64
  %l20 = alloca ptr
  %l21 = alloca i64
  %l22 = alloca %"compiler/diag:record"
  %l23 = alloca ptr
  %l24 = alloca i64
  %l25 = alloca %"compiler/diag:note"
  %l26 = alloca ptr
  %l27 = alloca i64
  %l29 = alloca ptr
  %l30 = alloca i64
  %l32 = alloca ptr
  %l33 = alloca i64
  %l35 = alloca ptr
  %l36 = alloca i64
  %l37 = alloca %"compiler/diag:context"
  %l38 = alloca ptr
  %l39 = alloca i64
  %l41 = alloca ptr
  %l42 = alloca i64
  %l44 = alloca ptr
  %l45 = alloca i64
  %l46 = alloca %"compiler/diag:record"
  %l47 = alloca ptr
  %l48 = alloca i64
  %l50 = alloca ptr
  %l51 = alloca i64
  %l52 = alloca { i64, ptr }
  %l53 = alloca ptr
  %l54 = alloca i64
  %l65 = alloca i64
  %l67 = alloca i64
  %l72 = alloca { i64, ptr }
  %l74 = alloca ptr
  %l75 = alloca i64
  %l85 = alloca i64
  %l87 = alloca i64
  %l92 = alloca { i64, ptr }
  %l94 = alloca ptr
  %l95 = alloca i64
  %l113 = alloca i64
  %l115 = alloca i64
  %l120 = alloca i1
  %l129 = alloca i64
  %l131 = alloca i64
  %l136 = alloca i64
  %l145 = alloca i64
  %l147 = alloca i64
  %l152 = alloca i64
  %l161 = alloca i64
  %l163 = alloca i64
  %l168 = alloca i64
  %l181 = alloca i64
  %l183 = alloca i64
  %l188 = alloca %"compiler/diag:record"
  %l190 = alloca ptr
  %l191 = alloca { i64, [3 x i64] }
  %l192 = alloca i64
  %l196 = alloca { i64, ptr }
  %l197 = alloca i64
  %l205 = alloca %"compiler/diag:record"
  %l211 = alloca i64
  %l213 = alloca i64
  %l218 = alloca %"compiler/diag:note"
  %l220 = alloca ptr
  %l221 = alloca i64
  %l222 = alloca { i64, [3 x i64] }
  %l223 = alloca i64
  %l230 = alloca %"compiler/diag:note"
  %l242 = alloca i64
  %l244 = alloca i64
  %l249 = alloca i64
  %l258 = alloca i64
  %l260 = alloca i64
  %l265 = alloca i64
  %l274 = alloca i64
  %l276 = alloca i64
  %l281 = alloca i64
  %l292 = alloca i64
  %l294 = alloca i64
  %l299 = alloca %"compiler/diag:context"
  %l301 = alloca ptr
  %l302 = alloca { i64, [3 x i64] }
  %l303 = alloca i64
  %l308 = alloca %"compiler/diag:context"
  %l327 = alloca i64
  %l329 = alloca i64
  %l334 = alloca i64
  %l343 = alloca i64
  %l345 = alloca i64
  %l350 = alloca i64
  %l360 = alloca ptr
  %l361 = alloca i64
  %l367 = alloca { i64, ptr }
  %l369 = alloca ptr
  %l370 = alloca i64
  %l376 = alloca { i64, ptr }
  %l378 = alloca ptr
  %l379 = alloca i64
  %l385 = alloca { i64, ptr }
  %l387 = alloca ptr
  %l388 = alloca i64
  %l394 = alloca { i64, ptr }
  %l409 = alloca i64
  %l411 = alloca i64
  %l416 = alloca %"compiler/diag:record"
  %l418 = alloca ptr
  %l419 = alloca { i64, [3 x i64] }
  %l420 = alloca i64
  %l424 = alloca { i64, ptr }
  %l425 = alloca i64
  %l433 = alloca %"compiler/diag:record"
  %l445 = alloca i64
  %l447 = alloca i64
  %l452 = alloca i64
  %l461 = alloca i64
  %l463 = alloca i64
  %l468 = alloca { i64, ptr }
  %l470 = alloca ptr
  %l471 = alloca i64
  %l481 = alloca i64
  %l483 = alloca i64
  %l488 = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t4 = getelementptr %"compiler/diag:Diagnostics", ptr %t2, i32 0, i32 0
  %t5 = load i1, ptr %t4, !tbaa !21
  %t8 = getelementptr %"compiler/diag:Diagnostics", ptr %t1, i32 0, i32 0
  store i1 %t5, ptr %t8, !tbaa !21
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/diag:Diagnostics", ptr %t9, i32 0, i32 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H075fcab2d197e70ad987ab163aa86164(ptr %v0, ptr %t11)
  br label %bb1
bb1:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/diag:Diagnostics", ptr %t13, i32 0, i32 2
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H075fcab2d197e70ad987ab163aa86164(ptr %v0, ptr %t15)
  br label %bb2
bb2:
  %t17 = load ptr, ptr %l1, !tbaa !29
  %t19 = getelementptr %"compiler/diag:Diagnostics", ptr %t17, i32 0, i32 1
  store ptr %t19, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb3
bb3:
  %t21 = load i64, ptr %l3, !tbaa !24
  store i64 %t21, ptr %l65, !tbaa !24
  %t22 = load ptr, ptr %l2, !tbaa !29
  %t24 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v1, ptr %t22)
  store i64 %t24, ptr %l67
  br label %bb4
bb4:
  %t25 = load i64, ptr %l65, !tbaa !24
  %t26 = load i64, ptr %l67, !tbaa !24
  %t27 = icmp slt i64 %t25, %t26
  %t29 = xor i1 %t27, true
  br i1 %t29, label %bb5, label %bb6
bb5:
  br label %bb13
bb6:
  br label %bb7
bb7:
  %t31 = load ptr, ptr %l2, !tbaa !29
  %t32 = load i64, ptr %l3, !tbaa !24
  %t35 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v1, ptr %v1, ptr %t31, i64 %t32)
  store { i64, ptr } %t35, ptr %l72
  br label %bb8
bb8:
  %t36 = load { i64, ptr }, ptr %l72, !tbaa !27
  store { i64, ptr } %t36, ptr %l4, !tbaa !27
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/diag:Diagnostics", ptr %t37, i32 0, i32 1
  store ptr %t39, ptr %l74, !tbaa !29
  %t40 = call ptr @__olang_scope_hold(ptr %v0)
  %t41 = ptrtoint ptr %t40 to i64
  store i64 %t41, ptr %l75, !tbaa !24
  %t42 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t42, label %bb9, label %bb10
bb9:
  %t44 = call ptr @__olang_region_make(ptr %v0)
  %t45 = ptrtoint ptr %t44 to i64
  store i64 %t45, ptr %l75, !tbaa !24
  br label %bb10
bb10:
  %t46 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t48 = extractvalue { i64, ptr } %t46, 1
  %t49 = extractvalue { i64, ptr } %t46, 0
  %t50 = load i64, ptr %l75
  %t51 = inttoptr i64 %t50 to ptr
  %t52 = call ptr @__olang_held_alloc(ptr %t51, i64 %t49)
  call void @olang_textcopy(ptr %t52, ptr %t48, i64 %t49)
  %t53 = insertvalue { i64, ptr } undef, i64 %t49, 0
  %t54 = insertvalue { i64, ptr } %t53, ptr %t52, 1
  %t56 = load ptr, ptr %l74, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v0, ptr %t56, { i64, ptr } %t54)
  br label %bb11
bb11:
  br label %bb12
bb12:
  %t58 = load i64, ptr %l3, !tbaa !24
  %t61 = add i64 %t58, 1
  store i64 %t61, ptr %l3, !tbaa !24
  br label %bb3
bb13:
  %t63 = load ptr, ptr %l1, !tbaa !29
  %t65 = getelementptr %"compiler/diag:Diagnostics", ptr %t63, i32 0, i32 2
  store ptr %t65, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb14
bb14:
  %t67 = load i64, ptr %l6, !tbaa !24
  store i64 %t67, ptr %l85, !tbaa !24
  %t68 = load ptr, ptr %l5, !tbaa !29
  %t70 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v1, ptr %t68)
  store i64 %t70, ptr %l87
  br label %bb15
bb15:
  %t71 = load i64, ptr %l85, !tbaa !24
  %t72 = load i64, ptr %l87, !tbaa !24
  %t73 = icmp slt i64 %t71, %t72
  %t75 = xor i1 %t73, true
  br i1 %t75, label %bb16, label %bb17
bb16:
  br label %bb24
bb17:
  br label %bb18
bb18:
  %t77 = load ptr, ptr %l5, !tbaa !29
  %t78 = load i64, ptr %l6, !tbaa !24
  %t81 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v1, ptr %v1, ptr %t77, i64 %t78)
  store { i64, ptr } %t81, ptr %l92
  br label %bb19
bb19:
  %t82 = load { i64, ptr }, ptr %l92, !tbaa !27
  store { i64, ptr } %t82, ptr %l7, !tbaa !27
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/diag:Diagnostics", ptr %t83, i32 0, i32 2
  store ptr %t85, ptr %l94, !tbaa !29
  %t86 = call ptr @__olang_scope_hold(ptr %v0)
  %t87 = ptrtoint ptr %t86 to i64
  store i64 %t87, ptr %l95, !tbaa !24
  %t88 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t88, label %bb20, label %bb21
bb20:
  %t90 = call ptr @__olang_region_make(ptr %v0)
  %t91 = ptrtoint ptr %t90 to i64
  store i64 %t91, ptr %l95, !tbaa !24
  br label %bb21
bb21:
  %t92 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t94 = extractvalue { i64, ptr } %t92, 1
  %t95 = extractvalue { i64, ptr } %t92, 0
  %t96 = load i64, ptr %l95
  %t97 = inttoptr i64 %t96 to ptr
  %t98 = call ptr @__olang_held_alloc(ptr %t97, i64 %t95)
  call void @olang_textcopy(ptr %t98, ptr %t94, i64 %t95)
  %t99 = insertvalue { i64, ptr } undef, i64 %t95, 0
  %t100 = insertvalue { i64, ptr } %t99, ptr %t98, 1
  %t102 = load ptr, ptr %l94, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v0, ptr %t102, { i64, ptr } %t100)
  br label %bb22
bb22:
  br label %bb23
bb23:
  %t104 = load i64, ptr %l6, !tbaa !24
  %t107 = add i64 %t104, 1
  store i64 %t107, ptr %l6, !tbaa !24
  br label %bb14
bb24:
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = getelementptr %"compiler/diag:Diagnostics", ptr %t109, i32 0, i32 3
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eClear_3cBool_3e(ptr %v0, ptr %t111)
  br label %bb25
bb25:
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t115 = getelementptr %"compiler/diag:Diagnostics", ptr %t113, i32 0, i32 4
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t115)
  br label %bb26
bb26:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"compiler/diag:Diagnostics", ptr %t117, i32 0, i32 5
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t119)
  br label %bb27
bb27:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"compiler/diag:Diagnostics", ptr %t121, i32 0, i32 6
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t123)
  br label %bb28
bb28:
  %t125 = load ptr, ptr %l1, !tbaa !29
  %t127 = getelementptr %"compiler/diag:Diagnostics", ptr %t125, i32 0, i32 3
  store ptr %t127, ptr %l8, !tbaa !29
  store i64 0, ptr %l9, !tbaa !24
  br label %bb29
bb29:
  %t129 = load i64, ptr %l9, !tbaa !24
  store i64 %t129, ptr %l113, !tbaa !24
  %t130 = load ptr, ptr %l8, !tbaa !29
  %t132 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v1, ptr %t130)
  store i64 %t132, ptr %l115
  br label %bb30
bb30:
  %t133 = load i64, ptr %l113, !tbaa !24
  %t134 = load i64, ptr %l115, !tbaa !24
  %t135 = icmp slt i64 %t133, %t134
  %t137 = xor i1 %t135, true
  br i1 %t137, label %bb31, label %bb32
bb31:
  br label %bb37
bb32:
  br label %bb33
bb33:
  %t139 = load ptr, ptr %l8, !tbaa !29
  %t140 = load i64, ptr %l9, !tbaa !24
  %t143 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v1, ptr %t139, i64 %t140)
  store i1 %t143, ptr %l120
  br label %bb34
bb34:
  %t144 = load i1, ptr %l120, !tbaa !21
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t147 = getelementptr %"compiler/diag:Diagnostics", ptr %t145, i32 0, i32 3
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t147, i1 %t144)
  br label %bb35
bb35:
  br label %bb36
bb36:
  %t151 = load i64, ptr %l9, !tbaa !24
  %t154 = add i64 %t151, 1
  store i64 %t154, ptr %l9, !tbaa !24
  br label %bb29
bb37:
  %t156 = load ptr, ptr %l1, !tbaa !29
  %t158 = getelementptr %"compiler/diag:Diagnostics", ptr %t156, i32 0, i32 4
  store ptr %t158, ptr %l11, !tbaa !29
  store i64 0, ptr %l12, !tbaa !24
  br label %bb38
bb38:
  %t160 = load i64, ptr %l12, !tbaa !24
  store i64 %t160, ptr %l129, !tbaa !24
  %t161 = load ptr, ptr %l11, !tbaa !29
  %t163 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t161)
  store i64 %t163, ptr %l131
  br label %bb39
bb39:
  %t164 = load i64, ptr %l129, !tbaa !24
  %t165 = load i64, ptr %l131, !tbaa !24
  %t166 = icmp slt i64 %t164, %t165
  %t168 = xor i1 %t166, true
  br i1 %t168, label %bb40, label %bb41
bb40:
  br label %bb46
bb41:
  br label %bb42
bb42:
  %t170 = load ptr, ptr %l11, !tbaa !29
  %t171 = load i64, ptr %l12, !tbaa !24
  %t174 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t170, i64 %t171)
  store i64 %t174, ptr %l136
  br label %bb43
bb43:
  %t175 = load i64, ptr %l136, !tbaa !24
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t178 = getelementptr %"compiler/diag:Diagnostics", ptr %t176, i32 0, i32 4
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t178, i64 %t175)
  br label %bb44
bb44:
  br label %bb45
bb45:
  %t182 = load i64, ptr %l12, !tbaa !24
  %t185 = add i64 %t182, 1
  store i64 %t185, ptr %l12, !tbaa !24
  br label %bb38
bb46:
  %t187 = load ptr, ptr %l1, !tbaa !29
  %t189 = getelementptr %"compiler/diag:Diagnostics", ptr %t187, i32 0, i32 5
  store ptr %t189, ptr %l14, !tbaa !29
  store i64 0, ptr %l15, !tbaa !24
  br label %bb47
bb47:
  %t191 = load i64, ptr %l15, !tbaa !24
  store i64 %t191, ptr %l145, !tbaa !24
  %t192 = load ptr, ptr %l14, !tbaa !29
  %t194 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t192)
  store i64 %t194, ptr %l147
  br label %bb48
bb48:
  %t195 = load i64, ptr %l145, !tbaa !24
  %t196 = load i64, ptr %l147, !tbaa !24
  %t197 = icmp slt i64 %t195, %t196
  %t199 = xor i1 %t197, true
  br i1 %t199, label %bb49, label %bb50
bb49:
  br label %bb55
bb50:
  br label %bb51
bb51:
  %t201 = load ptr, ptr %l14, !tbaa !29
  %t202 = load i64, ptr %l15, !tbaa !24
  %t205 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t201, i64 %t202)
  store i64 %t205, ptr %l152
  br label %bb52
bb52:
  %t206 = load i64, ptr %l152, !tbaa !24
  %t207 = load ptr, ptr %l0, !tbaa !29
  %t209 = getelementptr %"compiler/diag:Diagnostics", ptr %t207, i32 0, i32 5
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t209, i64 %t206)
  br label %bb53
bb53:
  br label %bb54
bb54:
  %t213 = load i64, ptr %l15, !tbaa !24
  %t216 = add i64 %t213, 1
  store i64 %t216, ptr %l15, !tbaa !24
  br label %bb47
bb55:
  %t218 = load ptr, ptr %l1, !tbaa !29
  %t220 = getelementptr %"compiler/diag:Diagnostics", ptr %t218, i32 0, i32 6
  store ptr %t220, ptr %l17, !tbaa !29
  store i64 0, ptr %l18, !tbaa !24
  br label %bb56
bb56:
  %t222 = load i64, ptr %l18, !tbaa !24
  store i64 %t222, ptr %l161, !tbaa !24
  %t223 = load ptr, ptr %l17, !tbaa !29
  %t225 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t223)
  store i64 %t225, ptr %l163
  br label %bb57
bb57:
  %t226 = load i64, ptr %l161, !tbaa !24
  %t227 = load i64, ptr %l163, !tbaa !24
  %t228 = icmp slt i64 %t226, %t227
  %t230 = xor i1 %t228, true
  br i1 %t230, label %bb58, label %bb59
bb58:
  br label %bb64
bb59:
  br label %bb60
bb60:
  %t232 = load ptr, ptr %l17, !tbaa !29
  %t233 = load i64, ptr %l18, !tbaa !24
  %t236 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t232, i64 %t233)
  store i64 %t236, ptr %l168
  br label %bb61
bb61:
  %t237 = load i64, ptr %l168, !tbaa !24
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t240 = getelementptr %"compiler/diag:Diagnostics", ptr %t238, i32 0, i32 6
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t240, i64 %t237)
  br label %bb62
bb62:
  br label %bb63
bb63:
  %t244 = load i64, ptr %l18, !tbaa !24
  %t247 = add i64 %t244, 1
  store i64 %t247, ptr %l18, !tbaa !24
  br label %bb56
bb64:
  %t249 = load ptr, ptr %l0, !tbaa !29
  %t251 = getelementptr %"compiler/diag:Diagnostics", ptr %t249, i32 0, i32 7
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3arecord_3e_2eClear_3ccompiler_2fdiag_3arecord_3e(ptr %v0, ptr %t251)
  br label %bb65
bb65:
  %t253 = load ptr, ptr %l0, !tbaa !29
  %t255 = getelementptr %"compiler/diag:Diagnostics", ptr %t253, i32 0, i32 8
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3anote_3e_2eClear_3ccompiler_2fdiag_3anote_3e(ptr %v0, ptr %t255)
  br label %bb66
bb66:
  %t257 = load ptr, ptr %l1, !tbaa !29
  %t259 = getelementptr %"compiler/diag:Diagnostics", ptr %t257, i32 0, i32 7
  store ptr %t259, ptr %l20, !tbaa !29
  store i64 0, ptr %l21, !tbaa !24
  br label %bb67
bb67:
  %t261 = load i64, ptr %l21, !tbaa !24
  store i64 %t261, ptr %l181, !tbaa !24
  %t262 = load ptr, ptr %l20, !tbaa !29
  %t264 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3arecord_3e_2eLen_3ccompiler_2fdiag_3arecord_3e(ptr %v1, ptr %t262)
  store i64 %t264, ptr %l183
  br label %bb68
bb68:
  %t265 = load i64, ptr %l181, !tbaa !24
  %t266 = load i64, ptr %l183, !tbaa !24
  %t267 = icmp slt i64 %t265, %t266
  %t269 = xor i1 %t267, true
  br i1 %t269, label %bb69, label %bb70
bb69:
  br label %bb80
bb70:
  br label %bb71
bb71:
  %t271 = load ptr, ptr %l20, !tbaa !29
  %t272 = load i64, ptr %l21, !tbaa !24
  %t275 = call %"compiler/diag:record" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3arecord_3e_2eAt_3ccompiler_2fdiag_3arecord_3e(ptr %v1, ptr %v1, ptr %t271, i64 %t272)
  store %"compiler/diag:record" %t275, ptr %l188
  br label %bb72
bb72:
  %t276 = load %"compiler/diag:record", ptr %l188
  store %"compiler/diag:record" %t276, ptr %l22
  %t277 = load ptr, ptr %l0, !tbaa !29
  %t279 = getelementptr %"compiler/diag:Diagnostics", ptr %t277, i32 0, i32 7
  store ptr %t279, ptr %l190, !tbaa !29
  %t280 = getelementptr %"compiler/diag:record", ptr %l22, i32 0, i32 0
  %t281 = load { i64, [3 x i64] }, ptr %t280
  store { i64, [3 x i64] } %t281, ptr %l191
  %t282 = call ptr @__olang_scope_hold(ptr %v0)
  %t283 = ptrtoint ptr %t282 to i64
  store i64 %t283, ptr %l192, !tbaa !24
  %t284 = load i1, ptr @olang_2esole_2ecompiler_2fdiag_3arecord_2e1
  br i1 %t284, label %bb73, label %bb74
bb73:
  %t286 = call ptr @__olang_region_make(ptr %v0)
  %t287 = ptrtoint ptr %t286 to i64
  store i64 %t287, ptr %l192, !tbaa !24
  br label %bb74
bb74:
  %t288 = getelementptr %"compiler/diag:record", ptr %l22, i32 0, i32 1
  %t289 = load { i64, ptr }, ptr %t288, !tbaa !27
  %t291 = extractvalue { i64, ptr } %t289, 1
  %t292 = extractvalue { i64, ptr } %t289, 0
  %t293 = load i64, ptr %l192
  %t294 = inttoptr i64 %t293 to ptr
  %t295 = call ptr @__olang_held_alloc(ptr %t294, i64 %t292)
  call void @olang_textcopy(ptr %t295, ptr %t291, i64 %t292)
  %t296 = insertvalue { i64, ptr } undef, i64 %t292, 0
  %t297 = insertvalue { i64, ptr } %t296, ptr %t295, 1
  store { i64, ptr } %t297, ptr %l196, !tbaa !27
  %t299 = call ptr @__olang_scope_hold(ptr %v0)
  %t300 = ptrtoint ptr %t299 to i64
  store i64 %t300, ptr %l197, !tbaa !24
  %t301 = load i1, ptr @olang_2esole_2ecompiler_2fdiag_3arecord_2e2
  br i1 %t301, label %bb75, label %bb76
bb75:
  %t303 = call ptr @__olang_region_make(ptr %v0)
  %t304 = ptrtoint ptr %t303 to i64
  store i64 %t304, ptr %l197, !tbaa !24
  br label %bb76
bb76:
  %t305 = getelementptr %"compiler/diag:record", ptr %l22, i32 0, i32 2
  %t306 = load { i64, ptr }, ptr %t305, !tbaa !27
  %t308 = extractvalue { i64, ptr } %t306, 1
  %t309 = extractvalue { i64, ptr } %t306, 0
  %t310 = load i64, ptr %l197
  %t311 = inttoptr i64 %t310 to ptr
  %t312 = call ptr @__olang_held_alloc(ptr %t311, i64 %t309)
  call void @olang_textcopy(ptr %t312, ptr %t308, i64 %t309)
  %t313 = insertvalue { i64, ptr } undef, i64 %t309, 0
  %t314 = insertvalue { i64, ptr } %t313, ptr %t312, 1
  %t316 = getelementptr %"compiler/diag:record", ptr %l22, i32 0, i32 3
  %t317 = load i32, ptr %t316, !range !{i32 0, i32 949}
  %t318 = getelementptr %"compiler/diag:record", ptr %l22, i32 0, i32 4
  %t319 = load i64, ptr %t318, !tbaa !24
  %t320 = getelementptr %"compiler/diag:record", ptr %l22, i32 0, i32 5
  %t321 = load i1, ptr %t320, !tbaa !21
  %t322 = load { i64, [3 x i64] }, ptr %l191
  %t323 = load { i64, ptr }, ptr %l196, !tbaa !27
  %t328 = call %"compiler/diag:record" @compiler_2fdiag_3arecord_2ector(ptr %v0, ptr %v0, ptr %v0, { i64, [3 x i64] } %t322, { i64, ptr } %t323, { i64, ptr } %t314, i32 %t317, i64 %t319, i1 %t321)
  store %"compiler/diag:record" %t328, ptr %l205
  br label %bb77
bb77:
  %t329 = load ptr, ptr %l190, !tbaa !29
  %t330 = load %"compiler/diag:record", ptr %l205
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3arecord_3e_2ePush_3ccompiler_2fdiag_3arecord_3e(ptr %v0, ptr %v0, ptr %t329, %"compiler/diag:record" %t330)
  br label %bb78
bb78:
  br label %bb79
bb79:
  %t331 = load i64, ptr %l21, !tbaa !24
  %t334 = add i64 %t331, 1
  store i64 %t334, ptr %l21, !tbaa !24
  br label %bb67
bb80:
  %t336 = load ptr, ptr %l1, !tbaa !29
  %t338 = getelementptr %"compiler/diag:Diagnostics", ptr %t336, i32 0, i32 8
  store ptr %t338, ptr %l23, !tbaa !29
  store i64 0, ptr %l24, !tbaa !24
  br label %bb81
bb81:
  %t340 = load i64, ptr %l24, !tbaa !24
  store i64 %t340, ptr %l211, !tbaa !24
  %t341 = load ptr, ptr %l23, !tbaa !29
  %t343 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3anote_3e_2eLen_3ccompiler_2fdiag_3anote_3e(ptr %v1, ptr %t341)
  store i64 %t343, ptr %l213
  br label %bb82
bb82:
  %t344 = load i64, ptr %l211, !tbaa !24
  %t345 = load i64, ptr %l213, !tbaa !24
  %t346 = icmp slt i64 %t344, %t345
  %t348 = xor i1 %t346, true
  br i1 %t348, label %bb83, label %bb84
bb83:
  br label %bb92
bb84:
  br label %bb85
bb85:
  %t350 = load ptr, ptr %l23, !tbaa !29
  %t351 = load i64, ptr %l24, !tbaa !24
  %t354 = call %"compiler/diag:note" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3anote_3e_2eAt_3ccompiler_2fdiag_3anote_3e(ptr %v1, ptr %v1, ptr %t350, i64 %t351)
  store %"compiler/diag:note" %t354, ptr %l218
  br label %bb86
bb86:
  %t355 = load %"compiler/diag:note", ptr %l218
  store %"compiler/diag:note" %t355, ptr %l25
  %t356 = load ptr, ptr %l0, !tbaa !29
  %t358 = getelementptr %"compiler/diag:Diagnostics", ptr %t356, i32 0, i32 8
  store ptr %t358, ptr %l220, !tbaa !29
  %t359 = getelementptr %"compiler/diag:note", ptr %l25, i32 0, i32 0
  %t360 = load i64, ptr %t359, !tbaa !24
  store i64 %t360, ptr %l221, !tbaa !24
  %t361 = getelementptr %"compiler/diag:note", ptr %l25, i32 0, i32 1
  %t362 = load { i64, [3 x i64] }, ptr %t361
  store { i64, [3 x i64] } %t362, ptr %l222
  %t363 = call ptr @__olang_scope_hold(ptr %v0)
  %t364 = ptrtoint ptr %t363 to i64
  store i64 %t364, ptr %l223, !tbaa !24
  %t365 = load i1, ptr @olang_2esole_2ecompiler_2fdiag_3anote_2e2
  br i1 %t365, label %bb87, label %bb88
bb87:
  %t367 = call ptr @__olang_region_make(ptr %v0)
  %t368 = ptrtoint ptr %t367 to i64
  store i64 %t368, ptr %l223, !tbaa !24
  br label %bb88
bb88:
  %t369 = getelementptr %"compiler/diag:note", ptr %l25, i32 0, i32 2
  %t370 = load { i64, ptr }, ptr %t369, !tbaa !27
  %t372 = extractvalue { i64, ptr } %t370, 1
  %t373 = extractvalue { i64, ptr } %t370, 0
  %t374 = load i64, ptr %l223
  %t375 = inttoptr i64 %t374 to ptr
  %t376 = call ptr @__olang_held_alloc(ptr %t375, i64 %t373)
  call void @olang_textcopy(ptr %t376, ptr %t372, i64 %t373)
  %t377 = insertvalue { i64, ptr } undef, i64 %t373, 0
  %t378 = insertvalue { i64, ptr } %t377, ptr %t376, 1
  %t380 = getelementptr %"compiler/diag:note", ptr %l25, i32 0, i32 3
  %t381 = load i1, ptr %t380, !tbaa !21
  %t382 = getelementptr %"compiler/diag:note", ptr %l25, i32 0, i32 4
  %t383 = load i1, ptr %t382, !tbaa !21
  %t384 = load i64, ptr %l221, !tbaa !24
  %t385 = load { i64, [3 x i64] }, ptr %l222
  %t389 = call %"compiler/diag:note" @compiler_2fdiag_3anote_2ector(ptr %v0, ptr %v0, i64 %t384, { i64, [3 x i64] } %t385, { i64, ptr } %t378, i1 %t381, i1 %t383)
  store %"compiler/diag:note" %t389, ptr %l230
  br label %bb89
bb89:
  %t390 = load ptr, ptr %l220, !tbaa !29
  %t391 = load %"compiler/diag:note", ptr %l230
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3anote_3e_2ePush_3ccompiler_2fdiag_3anote_3e(ptr %v0, ptr %v0, ptr %t390, %"compiler/diag:note" %t391)
  br label %bb90
bb90:
  br label %bb91
bb91:
  %t392 = load i64, ptr %l24, !tbaa !24
  %t395 = add i64 %t392, 1
  store i64 %t395, ptr %l24, !tbaa !24
  br label %bb81
bb92:
  %t397 = load ptr, ptr %l0, !tbaa !29
  %t399 = getelementptr %"compiler/diag:Diagnostics", ptr %t397, i32 0, i32 9
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t399)
  br label %bb93
bb93:
  %t401 = load ptr, ptr %l0, !tbaa !29
  %t403 = getelementptr %"compiler/diag:Diagnostics", ptr %t401, i32 0, i32 10
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t403)
  br label %bb94
bb94:
  %t405 = load ptr, ptr %l0, !tbaa !29
  %t407 = getelementptr %"compiler/diag:Diagnostics", ptr %t405, i32 0, i32 11
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t407)
  br label %bb95
bb95:
  %t409 = load ptr, ptr %l1, !tbaa !29
  %t411 = getelementptr %"compiler/diag:Diagnostics", ptr %t409, i32 0, i32 9
  store ptr %t411, ptr %l26, !tbaa !29
  store i64 0, ptr %l27, !tbaa !24
  br label %bb96
bb96:
  %t413 = load i64, ptr %l27, !tbaa !24
  store i64 %t413, ptr %l242, !tbaa !24
  %t414 = load ptr, ptr %l26, !tbaa !29
  %t416 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t414)
  store i64 %t416, ptr %l244
  br label %bb97
bb97:
  %t417 = load i64, ptr %l242, !tbaa !24
  %t418 = load i64, ptr %l244, !tbaa !24
  %t419 = icmp slt i64 %t417, %t418
  %t421 = xor i1 %t419, true
  br i1 %t421, label %bb98, label %bb99
bb98:
  br label %bb104
bb99:
  br label %bb100
bb100:
  %t423 = load ptr, ptr %l26, !tbaa !29
  %t424 = load i64, ptr %l27, !tbaa !24
  %t427 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t423, i64 %t424)
  store i64 %t427, ptr %l249
  br label %bb101
bb101:
  %t428 = load i64, ptr %l249, !tbaa !24
  %t429 = load ptr, ptr %l0, !tbaa !29
  %t431 = getelementptr %"compiler/diag:Diagnostics", ptr %t429, i32 0, i32 9
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t431, i64 %t428)
  br label %bb102
bb102:
  br label %bb103
bb103:
  %t435 = load i64, ptr %l27, !tbaa !24
  %t438 = add i64 %t435, 1
  store i64 %t438, ptr %l27, !tbaa !24
  br label %bb96
bb104:
  %t440 = load ptr, ptr %l1, !tbaa !29
  %t442 = getelementptr %"compiler/diag:Diagnostics", ptr %t440, i32 0, i32 10
  store ptr %t442, ptr %l29, !tbaa !29
  store i64 0, ptr %l30, !tbaa !24
  br label %bb105
bb105:
  %t444 = load i64, ptr %l30, !tbaa !24
  store i64 %t444, ptr %l258, !tbaa !24
  %t445 = load ptr, ptr %l29, !tbaa !29
  %t447 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t445)
  store i64 %t447, ptr %l260
  br label %bb106
bb106:
  %t448 = load i64, ptr %l258, !tbaa !24
  %t449 = load i64, ptr %l260, !tbaa !24
  %t450 = icmp slt i64 %t448, %t449
  %t452 = xor i1 %t450, true
  br i1 %t452, label %bb107, label %bb108
bb107:
  br label %bb113
bb108:
  br label %bb109
bb109:
  %t454 = load ptr, ptr %l29, !tbaa !29
  %t455 = load i64, ptr %l30, !tbaa !24
  %t458 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t454, i64 %t455)
  store i64 %t458, ptr %l265
  br label %bb110
bb110:
  %t459 = load i64, ptr %l265, !tbaa !24
  %t460 = load ptr, ptr %l0, !tbaa !29
  %t462 = getelementptr %"compiler/diag:Diagnostics", ptr %t460, i32 0, i32 10
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t462, i64 %t459)
  br label %bb111
bb111:
  br label %bb112
bb112:
  %t466 = load i64, ptr %l30, !tbaa !24
  %t469 = add i64 %t466, 1
  store i64 %t469, ptr %l30, !tbaa !24
  br label %bb105
bb113:
  %t471 = load ptr, ptr %l1, !tbaa !29
  %t473 = getelementptr %"compiler/diag:Diagnostics", ptr %t471, i32 0, i32 11
  store ptr %t473, ptr %l32, !tbaa !29
  store i64 0, ptr %l33, !tbaa !24
  br label %bb114
bb114:
  %t475 = load i64, ptr %l33, !tbaa !24
  store i64 %t475, ptr %l274, !tbaa !24
  %t476 = load ptr, ptr %l32, !tbaa !29
  %t478 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t476)
  store i64 %t478, ptr %l276
  br label %bb115
bb115:
  %t479 = load i64, ptr %l274, !tbaa !24
  %t480 = load i64, ptr %l276, !tbaa !24
  %t481 = icmp slt i64 %t479, %t480
  %t483 = xor i1 %t481, true
  br i1 %t483, label %bb116, label %bb117
bb116:
  br label %bb122
bb117:
  br label %bb118
bb118:
  %t485 = load ptr, ptr %l32, !tbaa !29
  %t486 = load i64, ptr %l33, !tbaa !24
  %t489 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t485, i64 %t486)
  store i64 %t489, ptr %l281
  br label %bb119
bb119:
  %t490 = load i64, ptr %l281, !tbaa !24
  %t491 = load ptr, ptr %l0, !tbaa !29
  %t493 = getelementptr %"compiler/diag:Diagnostics", ptr %t491, i32 0, i32 11
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t493, i64 %t490)
  br label %bb120
bb120:
  br label %bb121
bb121:
  %t497 = load i64, ptr %l33, !tbaa !24
  %t500 = add i64 %t497, 1
  store i64 %t500, ptr %l33, !tbaa !24
  br label %bb114
bb122:
  %t502 = load ptr, ptr %l0, !tbaa !29
  %t504 = getelementptr %"compiler/diag:Diagnostics", ptr %t502, i32 0, i32 12
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3acontext_3e_2eClear_3ccompiler_2fdiag_3acontext_3e(ptr %v0, ptr %t504)
  br label %bb123
bb123:
  %t506 = load ptr, ptr %l1, !tbaa !29
  %t508 = getelementptr %"compiler/diag:Diagnostics", ptr %t506, i32 0, i32 12
  store ptr %t508, ptr %l35, !tbaa !29
  store i64 0, ptr %l36, !tbaa !24
  br label %bb124
bb124:
  %t510 = load i64, ptr %l36, !tbaa !24
  store i64 %t510, ptr %l292, !tbaa !24
  %t511 = load ptr, ptr %l35, !tbaa !29
  %t513 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3acontext_3e_2eLen_3ccompiler_2fdiag_3acontext_3e(ptr %v1, ptr %t511)
  store i64 %t513, ptr %l294
  br label %bb125
bb125:
  %t514 = load i64, ptr %l292, !tbaa !24
  %t515 = load i64, ptr %l294, !tbaa !24
  %t516 = icmp slt i64 %t514, %t515
  %t518 = xor i1 %t516, true
  br i1 %t518, label %bb126, label %bb127
bb126:
  br label %bb135
bb127:
  br label %bb128
bb128:
  %t520 = load ptr, ptr %l35, !tbaa !29
  %t521 = load i64, ptr %l36, !tbaa !24
  %t524 = call %"compiler/diag:context" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3acontext_3e_2eAt_3ccompiler_2fdiag_3acontext_3e(ptr %v1, ptr %v1, ptr %t520, i64 %t521)
  store %"compiler/diag:context" %t524, ptr %l299
  br label %bb129
bb129:
  %t525 = load %"compiler/diag:context", ptr %l299
  store %"compiler/diag:context" %t525, ptr %l37
  %t526 = load ptr, ptr %l0, !tbaa !29
  %t528 = getelementptr %"compiler/diag:Diagnostics", ptr %t526, i32 0, i32 12
  store ptr %t528, ptr %l301, !tbaa !29
  %t529 = getelementptr %"compiler/diag:context", ptr %l37, i32 0, i32 0
  %t530 = load { i64, [3 x i64] }, ptr %t529
  store { i64, [3 x i64] } %t530, ptr %l302
  %t531 = call ptr @__olang_scope_hold(ptr %v0)
  %t532 = ptrtoint ptr %t531 to i64
  store i64 %t532, ptr %l303, !tbaa !24
  %t533 = load i1, ptr @olang_2esole_2ecompiler_2fdiag_3acontext_2e1
  br i1 %t533, label %bb130, label %bb131
bb130:
  %t535 = call ptr @__olang_region_make(ptr %v0)
  %t536 = ptrtoint ptr %t535 to i64
  store i64 %t536, ptr %l303, !tbaa !24
  br label %bb131
bb131:
  %t537 = getelementptr %"compiler/diag:context", ptr %l37, i32 0, i32 1
  %t538 = load { i64, ptr }, ptr %t537, !tbaa !27
  %t540 = extractvalue { i64, ptr } %t538, 1
  %t541 = extractvalue { i64, ptr } %t538, 0
  %t542 = load i64, ptr %l303
  %t543 = inttoptr i64 %t542 to ptr
  %t544 = call ptr @__olang_held_alloc(ptr %t543, i64 %t541)
  call void @olang_textcopy(ptr %t544, ptr %t540, i64 %t541)
  %t545 = insertvalue { i64, ptr } undef, i64 %t541, 0
  %t546 = insertvalue { i64, ptr } %t545, ptr %t544, 1
  %t548 = load { i64, [3 x i64] }, ptr %l302
  %t550 = call %"compiler/diag:context" @compiler_2fdiag_3acontext_2ector(ptr %v0, ptr %v0, { i64, [3 x i64] } %t548, { i64, ptr } %t546)
  store %"compiler/diag:context" %t550, ptr %l308
  br label %bb132
bb132:
  %t551 = load ptr, ptr %l301, !tbaa !29
  %t552 = load %"compiler/diag:context", ptr %l308
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3acontext_3e_2ePush_3ccompiler_2fdiag_3acontext_3e(ptr %v0, ptr %v0, ptr %t551, %"compiler/diag:context" %t552)
  br label %bb133
bb133:
  br label %bb134
bb134:
  %t553 = load i64, ptr %l36, !tbaa !24
  %t556 = add i64 %t553, 1
  store i64 %t556, ptr %l36, !tbaa !24
  br label %bb124
bb135:
  %t558 = load ptr, ptr %l0, !tbaa !29
  %t559 = load ptr, ptr %l1, !tbaa !29
  %t561 = getelementptr %"compiler/diag:Diagnostics", ptr %t559, i32 0, i32 13
  %t562 = load i64, ptr %t561, !tbaa !24
  %t565 = getelementptr %"compiler/diag:Diagnostics", ptr %t558, i32 0, i32 13
  store i64 %t562, ptr %t565, !tbaa !24
  %t566 = load ptr, ptr %l0, !tbaa !29
  %t567 = load ptr, ptr %l1, !tbaa !29
  %t569 = getelementptr %"compiler/diag:Diagnostics", ptr %t567, i32 0, i32 14
  %t570 = load i1, ptr %t569, !tbaa !21
  %t573 = getelementptr %"compiler/diag:Diagnostics", ptr %t566, i32 0, i32 14
  store i1 %t570, ptr %t573, !tbaa !21
  %t574 = load ptr, ptr %l0, !tbaa !29
  %t575 = load ptr, ptr %l1, !tbaa !29
  %t577 = getelementptr %"compiler/diag:Diagnostics", ptr %t575, i32 0, i32 15
  %t578 = load i1, ptr %t577, !tbaa !21
  %t581 = getelementptr %"compiler/diag:Diagnostics", ptr %t574, i32 0, i32 15
  store i1 %t578, ptr %t581, !tbaa !21
  %t582 = load ptr, ptr %l0, !tbaa !29
  %t584 = getelementptr %"compiler/diag:Diagnostics", ptr %t582, i32 0, i32 16
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t584)
  br label %bb136
bb136:
  %t586 = load ptr, ptr %l0, !tbaa !29
  %t588 = getelementptr %"compiler/diag:Diagnostics", ptr %t586, i32 0, i32 17
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t588)
  br label %bb137
bb137:
  %t590 = load ptr, ptr %l1, !tbaa !29
  %t592 = getelementptr %"compiler/diag:Diagnostics", ptr %t590, i32 0, i32 16
  store ptr %t592, ptr %l38, !tbaa !29
  store i64 0, ptr %l39, !tbaa !24
  br label %bb138
bb138:
  %t594 = load i64, ptr %l39, !tbaa !24
  store i64 %t594, ptr %l327, !tbaa !24
  %t595 = load ptr, ptr %l38, !tbaa !29
  %t597 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t595)
  store i64 %t597, ptr %l329
  br label %bb139
bb139:
  %t598 = load i64, ptr %l327, !tbaa !24
  %t599 = load i64, ptr %l329, !tbaa !24
  %t600 = icmp slt i64 %t598, %t599
  %t602 = xor i1 %t600, true
  br i1 %t602, label %bb140, label %bb141
bb140:
  br label %bb146
bb141:
  br label %bb142
bb142:
  %t604 = load ptr, ptr %l38, !tbaa !29
  %t605 = load i64, ptr %l39, !tbaa !24
  %t608 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t604, i64 %t605)
  store i64 %t608, ptr %l334
  br label %bb143
bb143:
  %t609 = load i64, ptr %l334, !tbaa !24
  %t610 = load ptr, ptr %l0, !tbaa !29
  %t612 = getelementptr %"compiler/diag:Diagnostics", ptr %t610, i32 0, i32 16
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t612, i64 %t609)
  br label %bb144
bb144:
  br label %bb145
bb145:
  %t616 = load i64, ptr %l39, !tbaa !24
  %t619 = add i64 %t616, 1
  store i64 %t619, ptr %l39, !tbaa !24
  br label %bb138
bb146:
  %t621 = load ptr, ptr %l1, !tbaa !29
  %t623 = getelementptr %"compiler/diag:Diagnostics", ptr %t621, i32 0, i32 17
  store ptr %t623, ptr %l41, !tbaa !29
  store i64 0, ptr %l42, !tbaa !24
  br label %bb147
bb147:
  %t625 = load i64, ptr %l42, !tbaa !24
  store i64 %t625, ptr %l343, !tbaa !24
  %t626 = load ptr, ptr %l41, !tbaa !29
  %t628 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t626)
  store i64 %t628, ptr %l345
  br label %bb148
bb148:
  %t629 = load i64, ptr %l343, !tbaa !24
  %t630 = load i64, ptr %l345, !tbaa !24
  %t631 = icmp slt i64 %t629, %t630
  %t633 = xor i1 %t631, true
  br i1 %t633, label %bb149, label %bb150
bb149:
  br label %bb155
bb150:
  br label %bb151
bb151:
  %t635 = load ptr, ptr %l41, !tbaa !29
  %t636 = load i64, ptr %l42, !tbaa !24
  %t639 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t635, i64 %t636)
  store i64 %t639, ptr %l350
  br label %bb152
bb152:
  %t640 = load i64, ptr %l350, !tbaa !24
  %t641 = load ptr, ptr %l0, !tbaa !29
  %t643 = getelementptr %"compiler/diag:Diagnostics", ptr %t641, i32 0, i32 17
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t643, i64 %t640)
  br label %bb153
bb153:
  br label %bb154
bb154:
  %t647 = load i64, ptr %l42, !tbaa !24
  %t650 = add i64 %t647, 1
  store i64 %t650, ptr %l42, !tbaa !24
  br label %bb147
bb155:
  %t652 = load ptr, ptr %l0, !tbaa !29
  %t653 = load ptr, ptr %l1, !tbaa !29
  %t655 = getelementptr %"compiler/diag:Diagnostics", ptr %t653, i32 0, i32 18
  %t656 = load { i64, [3 x i64] }, ptr %t655
  %t659 = getelementptr %"compiler/diag:Diagnostics", ptr %t652, i32 0, i32 18
  store { i64, [3 x i64] } %t656, ptr %t659
  %t660 = load ptr, ptr %l0, !tbaa !29
  store ptr %t660, ptr %l360, !tbaa !29
  %t661 = call ptr @__olang_scope_hold(ptr %v0)
  %t662 = ptrtoint ptr %t661 to i64
  store i64 %t662, ptr %l361, !tbaa !24
  %t663 = load i1, ptr @olang_2esole_2ecompiler_2fdiag_3aDiagnostics_2e19
  br i1 %t663, label %bb156, label %bb157
bb156:
  %t665 = call ptr @__olang_region_make(ptr %v0)
  %t666 = ptrtoint ptr %t665 to i64
  store i64 %t666, ptr %l361, !tbaa !24
  br label %bb157
bb157:
  %t667 = load ptr, ptr %l1, !tbaa !29
  %t669 = getelementptr %"compiler/diag:Diagnostics", ptr %t667, i32 0, i32 19
  %t670 = load { i64, ptr }, ptr %t669, !tbaa !27
  %t672 = extractvalue { i64, ptr } %t670, 1
  %t673 = extractvalue { i64, ptr } %t670, 0
  %t674 = load i64, ptr %l361
  %t675 = inttoptr i64 %t674 to ptr
  %t676 = call ptr @__olang_held_alloc(ptr %t675, i64 %t673)
  call void @olang_textcopy(ptr %t676, ptr %t672, i64 %t673)
  %t677 = insertvalue { i64, ptr } undef, i64 %t673, 0
  %t678 = insertvalue { i64, ptr } %t677, ptr %t676, 1
  %t680 = load ptr, ptr %l360, !tbaa !29
  %t681 = getelementptr %"compiler/diag:Diagnostics", ptr %t680, i32 0, i32 19
  %t682 = load { i64, ptr }, ptr %t681, !tbaa !27
  store { i64, ptr } %t682, ptr %l367, !tbaa !27
  %t684 = load ptr, ptr %l360, !tbaa !29
  %t685 = getelementptr %"compiler/diag:Diagnostics", ptr %t684, i32 0, i32 19
  store { i64, ptr } %t678, ptr %t685, !tbaa !27
  %t686 = load i1, ptr @olang_2esole_2ecompiler_2fdiag_3aDiagnostics_2e19
  br i1 %t686, label %bb158, label %bb159
bb158:
  %t688 = load { i64, ptr }, ptr %l367
  %t689 = extractvalue { i64, ptr } %t688, 1
  call void @__olang_region_release(ptr %t689)
  store { i64, ptr } zeroinitializer, ptr %l367
  br label %bb159
bb159:
  %t690 = load ptr, ptr %l0, !tbaa !29
  store ptr %t690, ptr %l369, !tbaa !29
  %t691 = call ptr @__olang_scope_hold(ptr %v0)
  %t692 = ptrtoint ptr %t691 to i64
  store i64 %t692, ptr %l370, !tbaa !24
  %t693 = load i1, ptr @olang_2esole_2ecompiler_2fdiag_3aDiagnostics_2e20
  br i1 %t693, label %bb160, label %bb161
bb160:
  %t695 = call ptr @__olang_region_make(ptr %v0)
  %t696 = ptrtoint ptr %t695 to i64
  store i64 %t696, ptr %l370, !tbaa !24
  br label %bb161
bb161:
  %t697 = load ptr, ptr %l1, !tbaa !29
  %t699 = getelementptr %"compiler/diag:Diagnostics", ptr %t697, i32 0, i32 20
  %t700 = load { i64, ptr }, ptr %t699, !tbaa !27
  %t702 = extractvalue { i64, ptr } %t700, 1
  %t703 = extractvalue { i64, ptr } %t700, 0
  %t704 = load i64, ptr %l370
  %t705 = inttoptr i64 %t704 to ptr
  %t706 = call ptr @__olang_held_alloc(ptr %t705, i64 %t703)
  call void @olang_textcopy(ptr %t706, ptr %t702, i64 %t703)
  %t707 = insertvalue { i64, ptr } undef, i64 %t703, 0
  %t708 = insertvalue { i64, ptr } %t707, ptr %t706, 1
  %t710 = load ptr, ptr %l369, !tbaa !29
  %t711 = getelementptr %"compiler/diag:Diagnostics", ptr %t710, i32 0, i32 20
  %t712 = load { i64, ptr }, ptr %t711, !tbaa !27
  store { i64, ptr } %t712, ptr %l376, !tbaa !27
  %t714 = load ptr, ptr %l369, !tbaa !29
  %t715 = getelementptr %"compiler/diag:Diagnostics", ptr %t714, i32 0, i32 20
  store { i64, ptr } %t708, ptr %t715, !tbaa !27
  %t716 = load i1, ptr @olang_2esole_2ecompiler_2fdiag_3aDiagnostics_2e20
  br i1 %t716, label %bb162, label %bb163
bb162:
  %t718 = load { i64, ptr }, ptr %l376
  %t719 = extractvalue { i64, ptr } %t718, 1
  call void @__olang_region_release(ptr %t719)
  store { i64, ptr } zeroinitializer, ptr %l376
  br label %bb163
bb163:
  %t720 = load ptr, ptr %l0, !tbaa !29
  store ptr %t720, ptr %l378, !tbaa !29
  %t721 = call ptr @__olang_scope_hold(ptr %v0)
  %t722 = ptrtoint ptr %t721 to i64
  store i64 %t722, ptr %l379, !tbaa !24
  %t723 = load i1, ptr @olang_2esole_2ecompiler_2fdiag_3aDiagnostics_2e21
  br i1 %t723, label %bb164, label %bb165
bb164:
  %t725 = call ptr @__olang_region_make(ptr %v0)
  %t726 = ptrtoint ptr %t725 to i64
  store i64 %t726, ptr %l379, !tbaa !24
  br label %bb165
bb165:
  %t727 = load ptr, ptr %l1, !tbaa !29
  %t729 = getelementptr %"compiler/diag:Diagnostics", ptr %t727, i32 0, i32 21
  %t730 = load { i64, ptr }, ptr %t729, !tbaa !27
  %t732 = extractvalue { i64, ptr } %t730, 1
  %t733 = extractvalue { i64, ptr } %t730, 0
  %t734 = load i64, ptr %l379
  %t735 = inttoptr i64 %t734 to ptr
  %t736 = call ptr @__olang_held_alloc(ptr %t735, i64 %t733)
  call void @olang_textcopy(ptr %t736, ptr %t732, i64 %t733)
  %t737 = insertvalue { i64, ptr } undef, i64 %t733, 0
  %t738 = insertvalue { i64, ptr } %t737, ptr %t736, 1
  %t740 = load ptr, ptr %l378, !tbaa !29
  %t741 = getelementptr %"compiler/diag:Diagnostics", ptr %t740, i32 0, i32 21
  %t742 = load { i64, ptr }, ptr %t741, !tbaa !27
  store { i64, ptr } %t742, ptr %l385, !tbaa !27
  %t744 = load ptr, ptr %l378, !tbaa !29
  %t745 = getelementptr %"compiler/diag:Diagnostics", ptr %t744, i32 0, i32 21
  store { i64, ptr } %t738, ptr %t745, !tbaa !27
  %t746 = load i1, ptr @olang_2esole_2ecompiler_2fdiag_3aDiagnostics_2e21
  br i1 %t746, label %bb166, label %bb167
bb166:
  %t748 = load { i64, ptr }, ptr %l385
  %t749 = extractvalue { i64, ptr } %t748, 1
  call void @__olang_region_release(ptr %t749)
  store { i64, ptr } zeroinitializer, ptr %l385
  br label %bb167
bb167:
  %t750 = load ptr, ptr %l0, !tbaa !29
  store ptr %t750, ptr %l387, !tbaa !29
  %t751 = call ptr @__olang_scope_hold(ptr %v0)
  %t752 = ptrtoint ptr %t751 to i64
  store i64 %t752, ptr %l388, !tbaa !24
  %t753 = load i1, ptr @olang_2esole_2ecompiler_2fdiag_3aDiagnostics_2e22
  br i1 %t753, label %bb168, label %bb169
bb168:
  %t755 = call ptr @__olang_region_make(ptr %v0)
  %t756 = ptrtoint ptr %t755 to i64
  store i64 %t756, ptr %l388, !tbaa !24
  br label %bb169
bb169:
  %t757 = load ptr, ptr %l1, !tbaa !29
  %t759 = getelementptr %"compiler/diag:Diagnostics", ptr %t757, i32 0, i32 22
  %t760 = load { i64, ptr }, ptr %t759, !tbaa !27
  %t762 = extractvalue { i64, ptr } %t760, 1
  %t763 = extractvalue { i64, ptr } %t760, 0
  %t764 = load i64, ptr %l388
  %t765 = inttoptr i64 %t764 to ptr
  %t766 = call ptr @__olang_held_alloc(ptr %t765, i64 %t763)
  call void @olang_textcopy(ptr %t766, ptr %t762, i64 %t763)
  %t767 = insertvalue { i64, ptr } undef, i64 %t763, 0
  %t768 = insertvalue { i64, ptr } %t767, ptr %t766, 1
  %t770 = load ptr, ptr %l387, !tbaa !29
  %t771 = getelementptr %"compiler/diag:Diagnostics", ptr %t770, i32 0, i32 22
  %t772 = load { i64, ptr }, ptr %t771, !tbaa !27
  store { i64, ptr } %t772, ptr %l394, !tbaa !27
  %t774 = load ptr, ptr %l387, !tbaa !29
  %t775 = getelementptr %"compiler/diag:Diagnostics", ptr %t774, i32 0, i32 22
  store { i64, ptr } %t768, ptr %t775, !tbaa !27
  %t776 = load i1, ptr @olang_2esole_2ecompiler_2fdiag_3aDiagnostics_2e22
  br i1 %t776, label %bb170, label %bb171
bb170:
  %t778 = load { i64, ptr }, ptr %l394
  %t779 = extractvalue { i64, ptr } %t778, 1
  call void @__olang_region_release(ptr %t779)
  store { i64, ptr } zeroinitializer, ptr %l394
  br label %bb171
bb171:
  %t780 = load ptr, ptr %l0, !tbaa !29
  %t781 = load ptr, ptr %l1, !tbaa !29
  %t783 = getelementptr %"compiler/diag:Diagnostics", ptr %t781, i32 0, i32 23
  %t784 = load i1, ptr %t783, !tbaa !21
  %t787 = getelementptr %"compiler/diag:Diagnostics", ptr %t780, i32 0, i32 23
  store i1 %t784, ptr %t787, !tbaa !21
  %t788 = load ptr, ptr %l0, !tbaa !29
  %t789 = load ptr, ptr %l1, !tbaa !29
  %t791 = getelementptr %"compiler/diag:Diagnostics", ptr %t789, i32 0, i32 24
  %t792 = load i1, ptr %t791, !tbaa !21
  %t795 = getelementptr %"compiler/diag:Diagnostics", ptr %t788, i32 0, i32 24
  store i1 %t792, ptr %t795, !tbaa !21
  %t796 = load ptr, ptr %l0, !tbaa !29
  %t797 = load ptr, ptr %l1, !tbaa !29
  %t799 = getelementptr %"compiler/diag:Diagnostics", ptr %t797, i32 0, i32 25
  %t800 = load i1, ptr %t799, !tbaa !21
  %t803 = getelementptr %"compiler/diag:Diagnostics", ptr %t796, i32 0, i32 25
  store i1 %t800, ptr %t803, !tbaa !21
  %t804 = load ptr, ptr %l0, !tbaa !29
  %t806 = getelementptr %"compiler/diag:Diagnostics", ptr %t804, i32 0, i32 26
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3arecord_3e_2eClear_3ccompiler_2fdiag_3arecord_3e(ptr %v0, ptr %t806)
  br label %bb172
bb172:
  %t808 = load ptr, ptr %l1, !tbaa !29
  %t810 = getelementptr %"compiler/diag:Diagnostics", ptr %t808, i32 0, i32 26
  store ptr %t810, ptr %l44, !tbaa !29
  store i64 0, ptr %l45, !tbaa !24
  br label %bb173
bb173:
  %t812 = load i64, ptr %l45, !tbaa !24
  store i64 %t812, ptr %l409, !tbaa !24
  %t813 = load ptr, ptr %l44, !tbaa !29
  %t815 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3arecord_3e_2eLen_3ccompiler_2fdiag_3arecord_3e(ptr %v1, ptr %t813)
  store i64 %t815, ptr %l411
  br label %bb174
bb174:
  %t816 = load i64, ptr %l409, !tbaa !24
  %t817 = load i64, ptr %l411, !tbaa !24
  %t818 = icmp slt i64 %t816, %t817
  %t820 = xor i1 %t818, true
  br i1 %t820, label %bb175, label %bb176
bb175:
  br label %bb186
bb176:
  br label %bb177
bb177:
  %t822 = load ptr, ptr %l44, !tbaa !29
  %t823 = load i64, ptr %l45, !tbaa !24
  %t826 = call %"compiler/diag:record" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3arecord_3e_2eAt_3ccompiler_2fdiag_3arecord_3e(ptr %v1, ptr %v1, ptr %t822, i64 %t823)
  store %"compiler/diag:record" %t826, ptr %l416
  br label %bb178
bb178:
  %t827 = load %"compiler/diag:record", ptr %l416
  store %"compiler/diag:record" %t827, ptr %l46
  %t828 = load ptr, ptr %l0, !tbaa !29
  %t830 = getelementptr %"compiler/diag:Diagnostics", ptr %t828, i32 0, i32 26
  store ptr %t830, ptr %l418, !tbaa !29
  %t831 = getelementptr %"compiler/diag:record", ptr %l46, i32 0, i32 0
  %t832 = load { i64, [3 x i64] }, ptr %t831
  store { i64, [3 x i64] } %t832, ptr %l419
  %t833 = call ptr @__olang_scope_hold(ptr %v0)
  %t834 = ptrtoint ptr %t833 to i64
  store i64 %t834, ptr %l420, !tbaa !24
  %t835 = load i1, ptr @olang_2esole_2ecompiler_2fdiag_3arecord_2e1
  br i1 %t835, label %bb179, label %bb180
bb179:
  %t837 = call ptr @__olang_region_make(ptr %v0)
  %t838 = ptrtoint ptr %t837 to i64
  store i64 %t838, ptr %l420, !tbaa !24
  br label %bb180
bb180:
  %t839 = getelementptr %"compiler/diag:record", ptr %l46, i32 0, i32 1
  %t840 = load { i64, ptr }, ptr %t839, !tbaa !27
  %t842 = extractvalue { i64, ptr } %t840, 1
  %t843 = extractvalue { i64, ptr } %t840, 0
  %t844 = load i64, ptr %l420
  %t845 = inttoptr i64 %t844 to ptr
  %t846 = call ptr @__olang_held_alloc(ptr %t845, i64 %t843)
  call void @olang_textcopy(ptr %t846, ptr %t842, i64 %t843)
  %t847 = insertvalue { i64, ptr } undef, i64 %t843, 0
  %t848 = insertvalue { i64, ptr } %t847, ptr %t846, 1
  store { i64, ptr } %t848, ptr %l424, !tbaa !27
  %t850 = call ptr @__olang_scope_hold(ptr %v0)
  %t851 = ptrtoint ptr %t850 to i64
  store i64 %t851, ptr %l425, !tbaa !24
  %t852 = load i1, ptr @olang_2esole_2ecompiler_2fdiag_3arecord_2e2
  br i1 %t852, label %bb181, label %bb182
bb181:
  %t854 = call ptr @__olang_region_make(ptr %v0)
  %t855 = ptrtoint ptr %t854 to i64
  store i64 %t855, ptr %l425, !tbaa !24
  br label %bb182
bb182:
  %t856 = getelementptr %"compiler/diag:record", ptr %l46, i32 0, i32 2
  %t857 = load { i64, ptr }, ptr %t856, !tbaa !27
  %t859 = extractvalue { i64, ptr } %t857, 1
  %t860 = extractvalue { i64, ptr } %t857, 0
  %t861 = load i64, ptr %l425
  %t862 = inttoptr i64 %t861 to ptr
  %t863 = call ptr @__olang_held_alloc(ptr %t862, i64 %t860)
  call void @olang_textcopy(ptr %t863, ptr %t859, i64 %t860)
  %t864 = insertvalue { i64, ptr } undef, i64 %t860, 0
  %t865 = insertvalue { i64, ptr } %t864, ptr %t863, 1
  %t867 = getelementptr %"compiler/diag:record", ptr %l46, i32 0, i32 3
  %t868 = load i32, ptr %t867, !range !{i32 0, i32 949}
  %t869 = getelementptr %"compiler/diag:record", ptr %l46, i32 0, i32 4
  %t870 = load i64, ptr %t869, !tbaa !24
  %t871 = getelementptr %"compiler/diag:record", ptr %l46, i32 0, i32 5
  %t872 = load i1, ptr %t871, !tbaa !21
  %t873 = load { i64, [3 x i64] }, ptr %l419
  %t874 = load { i64, ptr }, ptr %l424, !tbaa !27
  %t879 = call %"compiler/diag:record" @compiler_2fdiag_3arecord_2ector(ptr %v0, ptr %v0, ptr %v0, { i64, [3 x i64] } %t873, { i64, ptr } %t874, { i64, ptr } %t865, i32 %t868, i64 %t870, i1 %t872)
  store %"compiler/diag:record" %t879, ptr %l433
  br label %bb183
bb183:
  %t880 = load ptr, ptr %l418, !tbaa !29
  %t881 = load %"compiler/diag:record", ptr %l433
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3arecord_3e_2ePush_3ccompiler_2fdiag_3arecord_3e(ptr %v0, ptr %v0, ptr %t880, %"compiler/diag:record" %t881)
  br label %bb184
bb184:
  br label %bb185
bb185:
  %t882 = load i64, ptr %l45, !tbaa !24
  %t885 = add i64 %t882, 1
  store i64 %t885, ptr %l45, !tbaa !24
  br label %bb173
bb186:
  %t887 = load ptr, ptr %l0, !tbaa !29
  %t889 = getelementptr %"compiler/diag:Diagnostics", ptr %t887, i32 0, i32 27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t889)
  br label %bb187
bb187:
  %t891 = load ptr, ptr %l0, !tbaa !29
  %t893 = getelementptr %"compiler/diag:Diagnostics", ptr %t891, i32 0, i32 28
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H075fcab2d197e70ad987ab163aa86164(ptr %v0, ptr %t893)
  br label %bb188
bb188:
  %t895 = load ptr, ptr %l0, !tbaa !29
  %t897 = getelementptr %"compiler/diag:Diagnostics", ptr %t895, i32 0, i32 29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t897)
  br label %bb189
bb189:
  %t899 = load ptr, ptr %l1, !tbaa !29
  %t901 = getelementptr %"compiler/diag:Diagnostics", ptr %t899, i32 0, i32 27
  store ptr %t901, ptr %l47, !tbaa !29
  store i64 0, ptr %l48, !tbaa !24
  br label %bb190
bb190:
  %t903 = load i64, ptr %l48, !tbaa !24
  store i64 %t903, ptr %l445, !tbaa !24
  %t904 = load ptr, ptr %l47, !tbaa !29
  %t906 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t904)
  store i64 %t906, ptr %l447
  br label %bb191
bb191:
  %t907 = load i64, ptr %l445, !tbaa !24
  %t908 = load i64, ptr %l447, !tbaa !24
  %t909 = icmp slt i64 %t907, %t908
  %t911 = xor i1 %t909, true
  br i1 %t911, label %bb192, label %bb193
bb192:
  br label %bb198
bb193:
  br label %bb194
bb194:
  %t913 = load ptr, ptr %l47, !tbaa !29
  %t914 = load i64, ptr %l48, !tbaa !24
  %t917 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t913, i64 %t914)
  store i64 %t917, ptr %l452
  br label %bb195
bb195:
  %t918 = load i64, ptr %l452, !tbaa !24
  %t919 = load ptr, ptr %l0, !tbaa !29
  %t921 = getelementptr %"compiler/diag:Diagnostics", ptr %t919, i32 0, i32 27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t921, i64 %t918)
  br label %bb196
bb196:
  br label %bb197
bb197:
  %t925 = load i64, ptr %l48, !tbaa !24
  %t928 = add i64 %t925, 1
  store i64 %t928, ptr %l48, !tbaa !24
  br label %bb190
bb198:
  %t930 = load ptr, ptr %l1, !tbaa !29
  %t932 = getelementptr %"compiler/diag:Diagnostics", ptr %t930, i32 0, i32 28
  store ptr %t932, ptr %l50, !tbaa !29
  store i64 0, ptr %l51, !tbaa !24
  br label %bb199
bb199:
  %t934 = load i64, ptr %l51, !tbaa !24
  store i64 %t934, ptr %l461, !tbaa !24
  %t935 = load ptr, ptr %l50, !tbaa !29
  %t937 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v1, ptr %t935)
  store i64 %t937, ptr %l463
  br label %bb200
bb200:
  %t938 = load i64, ptr %l461, !tbaa !24
  %t939 = load i64, ptr %l463, !tbaa !24
  %t940 = icmp slt i64 %t938, %t939
  %t942 = xor i1 %t940, true
  br i1 %t942, label %bb201, label %bb202
bb201:
  br label %bb209
bb202:
  br label %bb203
bb203:
  %t944 = load ptr, ptr %l50, !tbaa !29
  %t945 = load i64, ptr %l51, !tbaa !24
  %t948 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v1, ptr %v1, ptr %t944, i64 %t945)
  store { i64, ptr } %t948, ptr %l468
  br label %bb204
bb204:
  %t949 = load { i64, ptr }, ptr %l468, !tbaa !27
  store { i64, ptr } %t949, ptr %l52, !tbaa !27
  %t950 = load ptr, ptr %l0, !tbaa !29
  %t952 = getelementptr %"compiler/diag:Diagnostics", ptr %t950, i32 0, i32 28
  store ptr %t952, ptr %l470, !tbaa !29
  %t953 = call ptr @__olang_scope_hold(ptr %v0)
  %t954 = ptrtoint ptr %t953 to i64
  store i64 %t954, ptr %l471, !tbaa !24
  %t955 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t955, label %bb205, label %bb206
bb205:
  %t957 = call ptr @__olang_region_make(ptr %v0)
  %t958 = ptrtoint ptr %t957 to i64
  store i64 %t958, ptr %l471, !tbaa !24
  br label %bb206
bb206:
  %t959 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t961 = extractvalue { i64, ptr } %t959, 1
  %t962 = extractvalue { i64, ptr } %t959, 0
  %t963 = load i64, ptr %l471
  %t964 = inttoptr i64 %t963 to ptr
  %t965 = call ptr @__olang_held_alloc(ptr %t964, i64 %t962)
  call void @olang_textcopy(ptr %t965, ptr %t961, i64 %t962)
  %t966 = insertvalue { i64, ptr } undef, i64 %t962, 0
  %t967 = insertvalue { i64, ptr } %t966, ptr %t965, 1
  %t969 = load ptr, ptr %l470, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v0, ptr %t969, { i64, ptr } %t967)
  br label %bb207
bb207:
  br label %bb208
bb208:
  %t971 = load i64, ptr %l51, !tbaa !24
  %t974 = add i64 %t971, 1
  store i64 %t974, ptr %l51, !tbaa !24
  br label %bb199
bb209:
  %t976 = load ptr, ptr %l1, !tbaa !29
  %t978 = getelementptr %"compiler/diag:Diagnostics", ptr %t976, i32 0, i32 29
  store ptr %t978, ptr %l53, !tbaa !29
  store i64 0, ptr %l54, !tbaa !24
  br label %bb210
bb210:
  %t980 = load i64, ptr %l54, !tbaa !24
  store i64 %t980, ptr %l481, !tbaa !24
  %t981 = load ptr, ptr %l53, !tbaa !29
  %t983 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t981)
  store i64 %t983, ptr %l483
  br label %bb211
bb211:
  %t984 = load i64, ptr %l481, !tbaa !24
  %t985 = load i64, ptr %l483, !tbaa !24
  %t986 = icmp slt i64 %t984, %t985
  %t988 = xor i1 %t986, true
  br i1 %t988, label %bb212, label %bb213
bb212:
  br label %bb218
bb213:
  br label %bb214
bb214:
  %t990 = load ptr, ptr %l53, !tbaa !29
  %t991 = load i64, ptr %l54, !tbaa !24
  %t994 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t990, i64 %t991)
  store i64 %t994, ptr %l488
  br label %bb215
bb215:
  %t995 = load i64, ptr %l488, !tbaa !24
  %t996 = load ptr, ptr %l0, !tbaa !29
  %t998 = getelementptr %"compiler/diag:Diagnostics", ptr %t996, i32 0, i32 29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t998, i64 %t995)
  br label %bb216
bb216:
  br label %bb217
bb217:
  %t1002 = load i64, ptr %l54, !tbaa !24
  %t1005 = add i64 %t1002, 1
  store i64 %t1005, ptr %l54, !tbaa !24
  br label %bb210
bb218:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eSummary(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i64
  %l7 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l16 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v0, ptr %t1)
  store i64 %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load i64, ptr %l3, !tbaa !24
  store i64 %t4, ptr %l1, !tbaa !24
  %t5 = load i64, ptr %l1, !tbaa !24
  %t7 = icmp eq i64 %t5, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2esgr(ptr %v0, ptr %s1, ptr %s1, ptr %t9, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d5, i32 0, i32 1) })
  store { i64, ptr } %t11, ptr %l7
  br label %bb4
bb3:
  br label %bb6
bb4:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2esgr(ptr %v0, ptr %s1, ptr %s1, ptr %t12, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d6, i32 0, i32 1) })
  store { i64, ptr } %t14, ptr %l9
  br label %bb5
bb5:
  %t15 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t15, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d7, i32 0, i32 1) }, 1
  %t19 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d7, i32 0, i32 1) }, 0
  %t20 = add i64 %t17, %t19
  %t21 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t21, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = add i64 %t20, %t23
  %t25 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d8, i32 0, i32 1) }, 1
  %t26 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d8, i32 0, i32 1) }, 0
  %t27 = add i64 %t24, %t26
  %t28 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t27)
  call void @olang_textcopy(ptr %t28, ptr %t16, i64 %t17)
  %t29 = getelementptr i8, ptr %t28, i64 %t17
  call void @olang_textcopy(ptr %t29, ptr %t18, i64 %t19)
  %t30 = getelementptr i8, ptr %t29, i64 %t19
  call void @olang_textcopy(ptr %t30, ptr %t22, i64 %t23)
  %t31 = getelementptr i8, ptr %t30, i64 %t23
  call void @olang_textcopy(ptr %t31, ptr %t25, i64 %t26)
  %t32 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t28, 1
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t33, ptr %rv
  br label %ret
bb6:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2esgr(ptr %v0, ptr %s0, ptr %s0, ptr %t35, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d9, i32 0, i32 1) })
  store { i64, ptr } %t37, ptr %l12
  br label %bb7
bb7:
  %t38 = load i64, ptr %l1, !tbaa !24
  store i64 %t38, ptr %l13, !tbaa !24
  %t39 = load i64, ptr %l1, !tbaa !24
  %t41 = icmp eq i64 %t39, 1
  br i1 %t41, label %bb8, label %bb9
bb8:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d10, i32 0, i32 1) }, ptr %l16, !tbaa !27
  br label %bb10
bb9:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d11, i32 0, i32 1) }, ptr %l16, !tbaa !27
  br label %bb10
bb10:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2esgr(ptr %v0, ptr %s0, ptr %s0, ptr %t43, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d12, i32 0, i32 1) })
  store { i64, ptr } %t45, ptr %l18
  br label %bb11
bb11:
  %t46 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t47 = extractvalue { i64, ptr } %t46, 1
  %t48 = extractvalue { i64, ptr } %t46, 0
  %t49 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d13, i32 0, i32 1) }, 1
  %t50 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d13, i32 0, i32 1) }, 0
  %t51 = add i64 %t48, %t50
  %t52 = load i64, ptr %l13, !tbaa !24
  %t53 = call i64 @__olang_fmt_i64(ptr null, i64 %t52)
  %t54 = add i64 %t51, %t53
  %t55 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d14, i32 0, i32 1) }, 1
  %t56 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d14, i32 0, i32 1) }, 0
  %t57 = add i64 %t54, %t56
  %t58 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t59 = extractvalue { i64, ptr } %t58, 1
  %t60 = extractvalue { i64, ptr } %t58, 0
  %t61 = add i64 %t57, %t60
  %t62 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t63 = extractvalue { i64, ptr } %t62, 1
  %t64 = extractvalue { i64, ptr } %t62, 0
  %t65 = add i64 %t61, %t64
  %t66 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 1
  %t67 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 0
  %t68 = add i64 %t65, %t67
  %t69 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t68)
  call void @olang_textcopy(ptr %t69, ptr %t47, i64 %t48)
  %t70 = getelementptr i8, ptr %t69, i64 %t48
  call void @olang_textcopy(ptr %t70, ptr %t49, i64 %t50)
  %t71 = getelementptr i8, ptr %t70, i64 %t50
  %t72 = call i64 @__olang_fmt_i64(ptr %t71, i64 %t52)
  %t73 = getelementptr i8, ptr %t71, i64 %t53
  call void @olang_textcopy(ptr %t73, ptr %t55, i64 %t56)
  %t74 = getelementptr i8, ptr %t73, i64 %t56
  call void @olang_textcopy(ptr %t74, ptr %t59, i64 %t60)
  %t75 = getelementptr i8, ptr %t74, i64 %t60
  call void @olang_textcopy(ptr %t75, ptr %t63, i64 %t64)
  %t76 = getelementptr i8, ptr %t75, i64 %t64
  call void @olang_textcopy(ptr %t76, ptr %t66, i64 %t67)
  %t77 = insertvalue { i64, ptr } undef, i64 %t68, 0
  %t78 = insertvalue { i64, ptr } %t77, ptr %t69, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t78, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2echosen(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l10 = alloca i64
  %l17 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 %a1, ptr %l2, !tbaa !24
  br label %bb1
bb1:
  %t3 = load i64, ptr %l2, !tbaa !24
  %t5 = icmp sge i64 %t3, 0
  %t7 = xor i1 %t5, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  br label %bb11
bb3:
  br label %bb4
bb4:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/diag:Diagnostics", ptr %t9, i32 0, i32 10
  %t12 = load i64, ptr %l2, !tbaa !24
  %t15 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t11, i64 %t12)
  store i64 %t15, ptr %l10
  br label %bb5
bb5:
  %t16 = load i64, ptr @G_2ecompiler_2fdiag_2eChosen, !tbaa !24
  %t17 = load i64, ptr %l10, !tbaa !24
  %t19 = icmp ne i64 %t17, %t16
  br i1 %t19, label %bb6, label %bb7
bb6:
  store i1 false, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/diag:Diagnostics", ptr %t22, i32 0, i32 9
  %t25 = load i64, ptr %l2, !tbaa !24
  %t28 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t24, i64 %t25)
  store i64 %t28, ptr %l17
  br label %bb9
bb9:
  %t29 = load i64, ptr %l17, !tbaa !24
  store i64 %t29, ptr %l2, !tbaa !24
  br label %bb10
bb10:
  br label %bb1
bb11:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eerrorWord(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2esgr(ptr %v0, ptr %s1, ptr %s1, ptr %t7, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d16, i32 0, i32 1) })
  store { i64, ptr } %t9, ptr %l6
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2esgr(ptr %v0, ptr %s1, ptr %s1, ptr %t10, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d17, i32 0, i32 1) })
  store { i64, ptr } %t12, ptr %l8
  br label %bb4
bb4:
  %t13 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t13, 1
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t16 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d18, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d18, i32 0, i32 1) }, 0
  %t18 = add i64 %t15, %t17
  %t19 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t19, 1
  %t21 = extractvalue { i64, ptr } %t19, 0
  %t22 = add i64 %t18, %t21
  %t23 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d19, i32 0, i32 1) }, 1
  %t24 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d19, i32 0, i32 1) }, 0
  %t25 = add i64 %t22, %t24
  %t26 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t25)
  call void @olang_textcopy(ptr %t26, ptr %t14, i64 %t15)
  %t27 = getelementptr i8, ptr %t26, i64 %t15
  call void @olang_textcopy(ptr %t27, ptr %t16, i64 %t17)
  %t28 = getelementptr i8, ptr %t27, i64 %t17
  call void @olang_textcopy(ptr %t28, ptr %t20, i64 %t21)
  %t29 = getelementptr i8, ptr %t28, i64 %t21
  call void @olang_textcopy(ptr %t29, ptr %t23, i64 %t24)
  %t30 = insertvalue { i64, ptr } undef, i64 %t25, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t26, 1
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t31, ptr %rv
  br label %ret
bb5:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2esgr(ptr %v0, ptr %s0, ptr %s0, ptr %t33, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d20, i32 0, i32 1) })
  store { i64, ptr } %t35, ptr %l11
  br label %bb6
bb6:
  %t36 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t36, ptr %l12, !tbaa !27
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2esgr(ptr %v0, ptr %s0, ptr %s0, ptr %t37, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d21, i32 0, i32 1) })
  store { i64, ptr } %t39, ptr %l14
  br label %bb7
bb7:
  %t40 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t40, 1
  %t42 = extractvalue { i64, ptr } %t40, 0
  %t43 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d22, i32 0, i32 1) }, 1
  %t44 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d22, i32 0, i32 1) }, 0
  %t45 = add i64 %t42, %t44
  %t46 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t47 = extractvalue { i64, ptr } %t46, 1
  %t48 = extractvalue { i64, ptr } %t46, 0
  %t49 = add i64 %t45, %t48
  %t50 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d23, i32 0, i32 1) }, 1
  %t51 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d23, i32 0, i32 1) }, 0
  %t52 = add i64 %t49, %t51
  %t53 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t54 = extractvalue { i64, ptr } %t53, 1
  %t55 = extractvalue { i64, ptr } %t53, 0
  %t56 = add i64 %t52, %t55
  %t57 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d24, i32 0, i32 1) }, 1
  %t58 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d24, i32 0, i32 1) }, 0
  %t59 = add i64 %t56, %t58
  %t60 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t59)
  call void @olang_textcopy(ptr %t60, ptr %t41, i64 %t42)
  %t61 = getelementptr i8, ptr %t60, i64 %t42
  call void @olang_textcopy(ptr %t61, ptr %t43, i64 %t44)
  %t62 = getelementptr i8, ptr %t61, i64 %t44
  call void @olang_textcopy(ptr %t62, ptr %t47, i64 %t48)
  %t63 = getelementptr i8, ptr %t62, i64 %t48
  call void @olang_textcopy(ptr %t63, ptr %t50, i64 %t51)
  %t64 = getelementptr i8, ptr %t63, i64 %t51
  call void @olang_textcopy(ptr %t64, ptr %t54, i64 %t55)
  %t65 = getelementptr i8, ptr %t64, i64 %t55
  call void @olang_textcopy(ptr %t65, ptr %t57, i64 %t58)
  %t66 = insertvalue { i64, ptr } undef, i64 %t59, 0
  %t67 = insertvalue { i64, ptr } %t66, ptr %t60, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t67, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eputExcerpt(ptr %v0, ptr %v1, ptr %a0, ptr %a1, { i64, [3 x i64] } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, [3 x i64] }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, i64 }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i1
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca { { i64, ptr }, i64 }
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l33 = alloca i64
  %l45 = alloca { i64, ptr }
  %l49 = alloca { i64, i64 }
  %l57 = alloca i1
  %l58 = alloca { i64, ptr }
  %l71 = alloca i64
  %l74 = alloca i64
  %l83 = alloca i64
  %l86 = alloca i1
  %l96 = alloca { i64, ptr }
  %l100 = alloca i1
  %l101 = alloca { i64, ptr }
  %l105 = alloca i1
  %l106 = alloca { i64, ptr }
  %l117 = alloca i64
  %l141 = alloca i64
  %l155 = alloca { { i64, ptr }, i64 }
  %l157 = alloca ptr
  %l159 = alloca { i64, ptr }
  %l171 = alloca i64
  %l174 = alloca i64
  %l192 = alloca ptr
  %l193 = alloca { i64, ptr }
  %l196 = alloca i8
  %l213 = alloca i1
  %l218 = alloca { i64, ptr }
  %l221 = alloca i1
  %l223 = alloca ptr
  %l224 = alloca { i64, ptr }
  %l228 = alloca i8
  %l232 = alloca ptr
  %l234 = alloca { i64, ptr }
  %l242 = alloca i1
  %l247 = alloca { i64, ptr }
  %l250 = alloca i1
  %l256 = alloca ptr
  %l258 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, [3 x i64] } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 0, ptr %l3, !tbaa !24
  store i64 0, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  %t1 = load { i64, [3 x i64] }, ptr %l2
  %t3 = extractvalue { i64, [3 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 3
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [3 x i64] }, ptr %l2, i32 0, i32 1
  %t7 = getelementptr { i64, i64, i64 }, ptr %t6, i32 0, i32 0
  %t8 = load i64, ptr %t7
  store i64 %t8, ptr %l6, !tbaa !24
  %t10 = getelementptr { i64, [3 x i64] }, ptr %l2, i32 0, i32 1
  %t11 = getelementptr { i64, i64, i64 }, ptr %t10, i32 0, i32 1
  %t12 = load i64, ptr %t11
  store i64 %t12, ptr %l7, !tbaa !24
  %t14 = getelementptr { i64, [3 x i64] }, ptr %l2, i32 0, i32 1
  %t15 = getelementptr { i64, i64, i64 }, ptr %t14, i32 0, i32 2
  %t16 = load i64, ptr %t15
  store i64 %t16, ptr %l8, !tbaa !24
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t18 = load i64, ptr %l6, !tbaa !24
  store i64 %t18, ptr %l3, !tbaa !24
  %t20 = load i64, ptr %l7, !tbaa !24
  store i64 %t20, ptr %l4, !tbaa !24
  %t22 = load i64, ptr %l8, !tbaa !24
  store i64 %t22, ptr %l5, !tbaa !24
  br label %bb9
bb4:
  br i1 true, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb8:
  call void @__olang_check_failed(ptr @olang_loc_c64be6b7d7a3c96a_e11c2151589de926)
  unreachable
bb9:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/diag:Diagnostics", ptr %t24, i32 0, i32 2
  %t27 = load i64, ptr %l3, !tbaa !24
  %t30 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t26, i64 %t27)
  store { i64, ptr } %t30, ptr %l45
  br label %bb10
bb10:
  %t31 = load { i64, ptr }, ptr %l45, !tbaa !27
  store { i64, ptr } %t31, ptr %l9, !tbaa !27
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load i64, ptr %l3, !tbaa !24
  %t34 = load i64, ptr %l4, !tbaa !24
  %t38 = call { i64, i64 } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2elineOf(ptr %v0, ptr %t32, i64 %t33, i64 %t34)
  store { i64, i64 } %t38, ptr %l49
  br label %bb11
bb11:
  %t39 = load { i64, i64 }, ptr %l49
  store { i64, i64 } %t39, ptr %l10
  %t40 = getelementptr { i64, i64 }, ptr %l10, i32 0, i32 0
  %t41 = load i64, ptr %t40, !tbaa !24
  store i64 %t41, ptr %l11, !tbaa !24
  %t43 = getelementptr { i64, i64 }, ptr %l10, i32 0, i32 1
  %t44 = load i64, ptr %t43, !tbaa !24
  store i64 %t44, ptr %l12, !tbaa !24
  %t46 = load i64, ptr %l4, !tbaa !24
  store i64 %t46, ptr %l13, !tbaa !24
  br label %bb12
bb12:
  %t48 = load i64, ptr %l13, !tbaa !24
  %t49 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t51 = extractvalue { i64, ptr } %t49, 0
  %t54 = icmp slt i64 %t48, %t51
  br i1 %t54, label %bb13, label %bb14
bb13:
  %t56 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t56, ptr %l58, !tbaa !27
  %t57 = load i64, ptr %l13, !tbaa !24
  %t59 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = getelementptr i8, ptr %t60, i64 %t57
  %t62 = load i8, ptr %t61, !tbaa !32
  %t64 = icmp ne i8 %t62, 10
  store i1 %t64, ptr %l57, !tbaa !21
  br label %bb15
bb14:
  store i1 false, ptr %l57, !tbaa !21
  br label %bb15
bb15:
  %t66 = load i1, ptr %l57, !tbaa !21
  %t67 = xor i1 %t66, true
  br i1 %t67, label %bb16, label %bb17
bb16:
  br label %bb20
bb17:
  br label %bb18
bb18:
  %t69 = load i64, ptr %l13, !tbaa !24
  %t72 = add i64 %t69, 1
  store i64 %t72, ptr %l13, !tbaa !24
  br label %bb19
bb19:
  br label %bb12
bb20:
  store i1 true, ptr %l14, !tbaa !21
  %t74 = load i64, ptr %l12, !tbaa !24
  store i64 %t74, ptr %l15, !tbaa !24
  %t76 = load i64, ptr %l13, !tbaa !24
  store i64 %t76, ptr %l16, !tbaa !24
  store i64 1, ptr %l17, !tbaa !24
  %t78 = load i64, ptr %l16, !tbaa !24
  %t79 = load i64, ptr %l15, !tbaa !24
  %t82 = icmp sgt i64 %t78, %t79
  br i1 %t82, label %bb21, label %bb22
bb21:
  %t84 = load i64, ptr %l17, !tbaa !24
  %t86 = icmp sgt i64 %t84, 0
  br i1 %t86, label %bb23, label %bb24
bb22:
  store i64 0, ptr %l71, !tbaa !24
  br label %bb26
bb23:
  %t88 = load i64, ptr %l16, !tbaa !24
  %t89 = load i64, ptr %l15, !tbaa !24
  %t92 = sub i64 %t88, %t89
  %t93 = load i64, ptr %l17, !tbaa !24
  %t96 = add i64 %t92, %t93
  %t98 = sub i64 %t96, 1
  %t99 = load i64, ptr %l17, !tbaa !24
  %t102 = sdiv i64 %t98, %t99
  store i64 %t102, ptr %l74, !tbaa !24
  br label %bb25
bb24:
  store i64 0, ptr %l74, !tbaa !24
  br label %bb25
bb25:
  %t104 = load i64, ptr %l74, !tbaa !24
  store i64 %t104, ptr %l71, !tbaa !24
  br label %bb26
bb26:
  %t105 = load i64, ptr %l71, !tbaa !24
  store i64 %t105, ptr %l18, !tbaa !24
  store i64 0, ptr %l19, !tbaa !24
  %t106 = load i64, ptr %l18, !tbaa !24
  %t107 = sub i64 %t106, 1
  store i64 %t107, ptr %l83, !tbaa !24
  %t108 = load i64, ptr %l18, !tbaa !24
  %t109 = icmp slt i64 %t108, 2147483648
  %t110 = load i64, ptr %l19, !tbaa !24
  %t111 = icmp sge i64 %t110, 0
  %t114 = and i1 %t109, %t111
  store i1 %t114, ptr %l86, !tbaa !21
  br label %bb27
bb27:
  %t115 = load i64, ptr %l19, !tbaa !24
  %t116 = load i64, ptr %l18, !tbaa !24
  %t119 = icmp slt i64 %t115, %t116
  %t121 = xor i1 %t119, true
  br i1 %t121, label %bb28, label %bb29
bb28:
  br label %bb41
bb29:
  br label %bb30
bb30:
  %t123 = load i64, ptr %l15, !tbaa !24
  %t124 = load i64, ptr %l19, !tbaa !24
  %t125 = load i64, ptr %l17, !tbaa !24
  %t128 = mul i64 %t124, %t125
  %t131 = add i64 %t123, %t128
  store i64 %t131, ptr %l20, !tbaa !24
  %t133 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t133, ptr %l96, !tbaa !27
  %t134 = load i64, ptr %l20, !tbaa !24
  %t136 = getelementptr { i64, ptr }, ptr %l96, i32 0, i32 1
  %t137 = load ptr, ptr %t136, !tbaa !27
  %t138 = getelementptr i8, ptr %t137, i64 %t134
  %t139 = load i8, ptr %t138, !tbaa !32
  %t141 = icmp ne i8 %t139, 32
  br i1 %t141, label %bb31, label %bb32
bb31:
  %t143 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t143, ptr %l101, !tbaa !27
  %t144 = load i64, ptr %l20, !tbaa !24
  %t146 = getelementptr { i64, ptr }, ptr %l101, i32 0, i32 1
  %t147 = load ptr, ptr %t146, !tbaa !27
  %t148 = getelementptr i8, ptr %t147, i64 %t144
  %t149 = load i8, ptr %t148, !tbaa !32
  %t151 = icmp ne i8 %t149, 9
  store i1 %t151, ptr %l100, !tbaa !21
  br label %bb33
bb32:
  store i1 false, ptr %l100, !tbaa !21
  br label %bb33
bb33:
  %t153 = load i1, ptr %l100, !tbaa !21
  br i1 %t153, label %bb34, label %bb35
bb34:
  %t154 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t154, ptr %l106, !tbaa !27
  %t155 = load i64, ptr %l20, !tbaa !24
  %t157 = getelementptr { i64, ptr }, ptr %l106, i32 0, i32 1
  %t158 = load ptr, ptr %t157, !tbaa !27
  %t159 = getelementptr i8, ptr %t158, i64 %t155
  %t160 = load i8, ptr %t159, !tbaa !32
  %t162 = icmp ne i8 %t160, 13
  store i1 %t162, ptr %l105, !tbaa !21
  br label %bb36
bb35:
  store i1 false, ptr %l105, !tbaa !21
  br label %bb36
bb36:
  %t164 = load i1, ptr %l105, !tbaa !21
  br i1 %t164, label %bb37, label %bb38
bb37:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb39
bb38:
  br label %bb39
bb39:
  br label %bb40
bb40:
  %t165 = load i64, ptr %l19, !tbaa !24
  %t168 = add i64 %t165, 1
  store i64 %t168, ptr %l19, !tbaa !24
  br label %bb27
bb41:
  %t170 = load i1, ptr %l14, !tbaa !21
  br i1 %t170, label %bb42, label %bb43
bb42:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb43:
  br label %bb44
bb44:
  %t172 = load i64, ptr %l5, !tbaa !24
  %t173 = load i64, ptr %l4, !tbaa !24
  %t176 = icmp sgt i64 %t172, %t173
  br i1 %t176, label %bb45, label %bb46
bb45:
  %t178 = load i64, ptr %l5, !tbaa !24
  store i64 %t178, ptr %l117, !tbaa !24
  br label %bb47
bb46:
  %t180 = load i64, ptr %l4, !tbaa !24
  %t182 = add i64 %t180, 1
  store i64 %t182, ptr %l117, !tbaa !24
  br label %bb47
bb47:
  %t184 = load i64, ptr %l117, !tbaa !24
  store i64 %t184, ptr %l21, !tbaa !24
  %t185 = load i64, ptr %l12, !tbaa !24
  store i64 %t185, ptr %l22, !tbaa !24
  %t187 = load i64, ptr %l13, !tbaa !24
  store i64 %t187, ptr %l23, !tbaa !24
  %t189 = load i64, ptr %l13, !tbaa !24
  %t190 = load i64, ptr %l12, !tbaa !24
  %t193 = sub i64 %t189, %t190
  %t194 = load i64, ptr @G_2ecompiler_2fdiag_2eExcerptMax, !tbaa !24
  %t197 = icmp sgt i64 %t193, %t194
  br i1 %t197, label %bb48, label %bb49
bb48:
  %t199 = load i64, ptr %l4, !tbaa !24
  %t200 = load i64, ptr @G_2ecompiler_2fdiag_2eExcerptAround, !tbaa !24
  %t203 = sub i64 %t199, %t200
  %t204 = load i64, ptr %l22, !tbaa !24
  %t207 = icmp sgt i64 %t203, %t204
  br i1 %t207, label %bb50, label %bb51
bb49:
  br label %bb59
bb50:
  %t209 = load i64, ptr %l4, !tbaa !24
  %t210 = load i64, ptr @G_2ecompiler_2fdiag_2eExcerptAround, !tbaa !24
  %t213 = sub i64 %t209, %t210
  store i64 %t213, ptr %l22, !tbaa !24
  br label %bb52
bb51:
  br label %bb52
bb52:
  %t215 = load i64, ptr %l21, !tbaa !24
  %t216 = load i64, ptr %l4, !tbaa !24
  %t217 = load i64, ptr @G_2ecompiler_2fdiag_2eExcerptAround, !tbaa !24
  %t220 = add i64 %t216, %t217
  %t223 = icmp slt i64 %t215, %t220
  br i1 %t223, label %bb53, label %bb54
bb53:
  %t225 = load i64, ptr %l21, !tbaa !24
  store i64 %t225, ptr %l141, !tbaa !24
  br label %bb55
bb54:
  %t227 = load i64, ptr %l4, !tbaa !24
  %t228 = load i64, ptr @G_2ecompiler_2fdiag_2eExcerptAround, !tbaa !24
  %t231 = add i64 %t227, %t228
  store i64 %t231, ptr %l141, !tbaa !24
  br label %bb55
bb55:
  %t233 = load i64, ptr @G_2ecompiler_2fdiag_2eExcerptAround, !tbaa !24
  %t234 = load i64, ptr %l141, !tbaa !24
  %t236 = add i64 %t234, %t233
  store i64 %t236, ptr %l24, !tbaa !24
  %t238 = load i64, ptr %l24, !tbaa !24
  %t239 = load i64, ptr %l23, !tbaa !24
  %t242 = icmp slt i64 %t238, %t239
  br i1 %t242, label %bb56, label %bb57
bb56:
  %t244 = load i64, ptr %l24, !tbaa !24
  store i64 %t244, ptr %l23, !tbaa !24
  br label %bb58
bb57:
  br label %bb58
bb58:
  br label %bb59
bb59:
  %t246 = load ptr, ptr %l0, !tbaa !29
  %t247 = load i64, ptr %l3, !tbaa !24
  %t248 = load i64, ptr %l11, !tbaa !24
  %t252 = call { { i64, ptr }, i64 } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eshown(ptr %v0, ptr %s0, ptr %t246, i64 %t247, i64 %t248)
  store { { i64, ptr }, i64 } %t252, ptr %l155
  br label %bb60
bb60:
  %t253 = load { { i64, ptr }, i64 }, ptr %l155
  store { { i64, ptr }, i64 } %t253, ptr %l25
  %t254 = getelementptr { { i64, ptr }, i64 }, ptr %l25, i32 0, i32 1
  %t255 = load i64, ptr %t254, !tbaa !24
  %t257 = load ptr, ptr %l1, !tbaa !29
  store ptr %t257, ptr %l157, !tbaa !29
  %t260 = call { i64, ptr } @std_2fprelude_2ftext_2eI64_2ePadStart(ptr %s0, i64 %t255, i64 5, i8 32)
  store { i64, ptr } %t260, ptr %l159
  br label %bb61
bb61:
  %t261 = load { i64, ptr }, ptr %l159, !tbaa !27
  %t262 = extractvalue { i64, ptr } %t261, 1
  %t263 = extractvalue { i64, ptr } %t261, 0
  %t264 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d25, i32 0, i32 1) }, 1
  %t265 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d25, i32 0, i32 1) }, 0
  %t266 = add i64 %t263, %t265
  %t267 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t266)
  call void @olang_textcopy(ptr %t267, ptr %t262, i64 %t263)
  %t268 = getelementptr i8, ptr %t267, i64 %t263
  call void @olang_textcopy(ptr %t268, ptr %t264, i64 %t265)
  %t269 = insertvalue { i64, ptr } undef, i64 %t266, 0
  %t270 = insertvalue { i64, ptr } %t269, ptr %t267, 1
  %t272 = load ptr, ptr %l157, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s0, ptr %t272, { i64, ptr } %t270)
  br label %bb62
bb62:
  %t274 = load i64, ptr %l22, !tbaa !24
  %t275 = load i64, ptr %l12, !tbaa !24
  %t278 = icmp sgt i64 %t274, %t275
  br i1 %t278, label %bb63, label %bb64
bb63:
  store %olang.scope zeroinitializer, ptr %s13
  %t280 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s13, ptr %t280, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d26, i32 0, i32 1) })
  br label %bb65
bb64:
  br label %bb66
bb65:
  call void @__olang_scope_close(ptr %s13)
  br label %bb66
bb66:
  %t282 = load i64, ptr %l22, !tbaa !24
  store i64 %t282, ptr %l27, !tbaa !24
  %t284 = load i64, ptr %l23, !tbaa !24
  store i64 %t284, ptr %l28, !tbaa !24
  store i64 1, ptr %l29, !tbaa !24
  %t286 = load i64, ptr %l28, !tbaa !24
  %t287 = load i64, ptr %l27, !tbaa !24
  %t290 = icmp sgt i64 %t286, %t287
  br i1 %t290, label %bb67, label %bb68
bb67:
  %t292 = load i64, ptr %l29, !tbaa !24
  %t294 = icmp sgt i64 %t292, 0
  br i1 %t294, label %bb69, label %bb70
bb68:
  store i64 0, ptr %l171, !tbaa !24
  br label %bb72
bb69:
  %t296 = load i64, ptr %l28, !tbaa !24
  %t297 = load i64, ptr %l27, !tbaa !24
  %t300 = sub i64 %t296, %t297
  %t301 = load i64, ptr %l29, !tbaa !24
  %t304 = add i64 %t300, %t301
  %t306 = sub i64 %t304, 1
  %t307 = load i64, ptr %l29, !tbaa !24
  %t310 = sdiv i64 %t306, %t307
  store i64 %t310, ptr %l174, !tbaa !24
  br label %bb71
bb70:
  store i64 0, ptr %l174, !tbaa !24
  br label %bb71
bb71:
  %t312 = load i64, ptr %l174, !tbaa !24
  store i64 %t312, ptr %l171, !tbaa !24
  br label %bb72
bb72:
  %t313 = load i64, ptr %l171, !tbaa !24
  store i64 %t313, ptr %l30, !tbaa !24
  store i64 0, ptr %l31, !tbaa !24
  br label %bb73
bb73:
  %t314 = load i64, ptr %l31, !tbaa !24
  %t315 = load i64, ptr %l30, !tbaa !24
  %t318 = icmp slt i64 %t314, %t315
  %t320 = xor i1 %t318, true
  br i1 %t320, label %bb74, label %bb75
bb74:
  br label %bb80
bb75:
  br label %bb76
bb76:
  %t322 = load i64, ptr %l27, !tbaa !24
  %t323 = load i64, ptr %l31, !tbaa !24
  %t324 = load i64, ptr %l29, !tbaa !24
  %t327 = mul i64 %t323, %t324
  %t330 = add i64 %t322, %t327
  %t332 = load ptr, ptr %l1, !tbaa !29
  store ptr %t332, ptr %l192, !tbaa !29
  %t333 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t333, ptr %l193, !tbaa !27
  %t336 = getelementptr { i64, ptr }, ptr %l193, i32 0, i32 1
  %t337 = load ptr, ptr %t336, !tbaa !27
  %t338 = getelementptr i8, ptr %t337, i64 %t330
  %t339 = load i8, ptr %t338, !tbaa !32
  %t341 = call i8 @compiler_2fdiag_2eprintable(i8 %t339)
  store i8 %t341, ptr %l196
  br label %bb77
bb77:
  %t342 = load ptr, ptr %l192, !tbaa !29
  %t343 = load i8, ptr %l196, !tbaa !22
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t342, i8 %t343)
  br label %bb78
bb78:
  br label %bb79
bb79:
  %t344 = load i64, ptr %l31, !tbaa !24
  %t347 = add i64 %t344, 1
  store i64 %t347, ptr %l31, !tbaa !24
  br label %bb73
bb80:
  %t349 = load i64, ptr %l23, !tbaa !24
  %t350 = load i64, ptr %l13, !tbaa !24
  %t353 = icmp slt i64 %t349, %t350
  br i1 %t353, label %bb81, label %bb82
bb81:
  store %olang.scope zeroinitializer, ptr %s17
  %t355 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s17, ptr %t355, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d27, i32 0, i32 1) })
  br label %bb83
bb82:
  br label %bb84
bb83:
  call void @__olang_scope_close(ptr %s17)
  br label %bb84
bb84:
  %t357 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s0, ptr %t357, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d28, i32 0, i32 1) })
  br label %bb85
bb85:
  %t359 = load i64, ptr %l22, !tbaa !24
  %t360 = load i64, ptr %l12, !tbaa !24
  %t363 = icmp sgt i64 %t359, %t360
  br i1 %t363, label %bb86, label %bb87
bb86:
  store %olang.scope zeroinitializer, ptr %s18
  %t365 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s18, ptr %t365, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d29, i32 0, i32 1) })
  br label %bb88
bb87:
  br label %bb89
bb88:
  call void @__olang_scope_close(ptr %s18)
  br label %bb89
bb89:
  %t367 = load i64, ptr %l22, !tbaa !24
  store i64 %t367, ptr %l33, !tbaa !24
  br label %bb90
bb90:
  %t369 = load i64, ptr %l33, !tbaa !24
  %t370 = load i64, ptr %l4, !tbaa !24
  %t373 = icmp slt i64 %t369, %t370
  br i1 %t373, label %bb91, label %bb92
bb91:
  %t375 = load i64, ptr %l33, !tbaa !24
  %t376 = load i64, ptr %l23, !tbaa !24
  %t379 = icmp slt i64 %t375, %t376
  store i1 %t379, ptr %l213, !tbaa !21
  br label %bb93
bb92:
  store i1 false, ptr %l213, !tbaa !21
  br label %bb93
bb93:
  %t381 = load i1, ptr %l213, !tbaa !21
  %t382 = xor i1 %t381, true
  br i1 %t382, label %bb94, label %bb95
bb94:
  br label %bb106
bb95:
  br label %bb96
bb96:
  %t384 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t384, ptr %l218, !tbaa !27
  %t385 = load i64, ptr %l33, !tbaa !24
  %t387 = getelementptr { i64, ptr }, ptr %l218, i32 0, i32 1
  %t388 = load ptr, ptr %t387, !tbaa !27
  %t389 = getelementptr i8, ptr %t388, i64 %t385
  %t390 = load i8, ptr %t389, !tbaa !32
  %t392 = call i1 @compiler_2fdiag_2econtinues(i8 %t390)
  store i1 %t392, ptr %l221
  br label %bb97
bb97:
  %t393 = load i1, ptr %l221, !tbaa !21
  %t394 = xor i1 %t393, true
  br i1 %t394, label %bb98, label %bb99
bb98:
  %t396 = load ptr, ptr %l1, !tbaa !29
  store ptr %t396, ptr %l223, !tbaa !29
  %t397 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t397, ptr %l224, !tbaa !27
  %t398 = load i64, ptr %l33, !tbaa !24
  %t400 = getelementptr { i64, ptr }, ptr %l224, i32 0, i32 1
  %t401 = load ptr, ptr %t400, !tbaa !27
  %t402 = getelementptr i8, ptr %t401, i64 %t398
  %t403 = load i8, ptr %t402, !tbaa !32
  %t405 = icmp eq i8 %t403, 9
  br i1 %t405, label %bb100, label %bb101
bb99:
  br label %bb104
bb100:
  store i8 9, ptr %l228, !tbaa !22
  br label %bb102
bb101:
  store i8 32, ptr %l228, !tbaa !22
  br label %bb102
bb102:
  %t407 = load ptr, ptr %l223, !tbaa !29
  %t408 = load i8, ptr %l228, !tbaa !22
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t407, i8 %t408)
  br label %bb103
bb103:
  br label %bb104
bb104:
  %t409 = load i64, ptr %l33, !tbaa !24
  %t412 = add i64 %t409, 1
  store i64 %t412, ptr %l33, !tbaa !24
  br label %bb105
bb105:
  br label %bb90
bb106:
  %t414 = load ptr, ptr %l1, !tbaa !29
  store ptr %t414, ptr %l232, !tbaa !29
  %t415 = load ptr, ptr %l0, !tbaa !29
  %t417 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2esgr(ptr %v0, ptr %s0, ptr %s0, ptr %t415, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d30, i32 0, i32 1) })
  store { i64, ptr } %t417, ptr %l234
  br label %bb107
bb107:
  %t418 = load { i64, ptr }, ptr %l234, !tbaa !27
  %t419 = load ptr, ptr %l232, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s0, ptr %t419, { i64, ptr } %t418)
  br label %bb108
bb108:
  %t421 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t421, i8 94)
  br label %bb109
bb109:
  %t423 = load i64, ptr %l4, !tbaa !24
  %t425 = add i64 %t423, 1
  store i64 %t425, ptr %l33, !tbaa !24
  br label %bb110
bb110:
  %t427 = load i64, ptr %l33, !tbaa !24
  %t428 = load i64, ptr %l21, !tbaa !24
  %t431 = icmp slt i64 %t427, %t428
  br i1 %t431, label %bb111, label %bb112
bb111:
  %t433 = load i64, ptr %l33, !tbaa !24
  %t434 = load i64, ptr %l23, !tbaa !24
  %t437 = icmp slt i64 %t433, %t434
  store i1 %t437, ptr %l242, !tbaa !21
  br label %bb113
bb112:
  store i1 false, ptr %l242, !tbaa !21
  br label %bb113
bb113:
  %t439 = load i1, ptr %l242, !tbaa !21
  %t440 = xor i1 %t439, true
  br i1 %t440, label %bb114, label %bb115
bb114:
  br label %bb123
bb115:
  br label %bb116
bb116:
  %t442 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t442, ptr %l247, !tbaa !27
  %t443 = load i64, ptr %l33, !tbaa !24
  %t445 = getelementptr { i64, ptr }, ptr %l247, i32 0, i32 1
  %t446 = load ptr, ptr %t445, !tbaa !27
  %t447 = getelementptr i8, ptr %t446, i64 %t443
  %t448 = load i8, ptr %t447, !tbaa !32
  %t450 = call i1 @compiler_2fdiag_2econtinues(i8 %t448)
  store i1 %t450, ptr %l250
  br label %bb117
bb117:
  %t451 = load i1, ptr %l250, !tbaa !21
  %t452 = xor i1 %t451, true
  br i1 %t452, label %bb118, label %bb119
bb118:
  %t454 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t454, i8 126)
  br label %bb120
bb119:
  br label %bb121
bb120:
  br label %bb121
bb121:
  %t456 = load i64, ptr %l33, !tbaa !24
  %t459 = add i64 %t456, 1
  store i64 %t459, ptr %l33, !tbaa !24
  br label %bb122
bb122:
  br label %bb110
bb123:
  %t461 = load ptr, ptr %l1, !tbaa !29
  store ptr %t461, ptr %l256, !tbaa !29
  %t462 = load ptr, ptr %l0, !tbaa !29
  %t464 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2esgr(ptr %v0, ptr %s0, ptr %s0, ptr %t462, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d31, i32 0, i32 1) })
  store { i64, ptr } %t464, ptr %l258
  br label %bb124
bb124:
  %t465 = load { i64, ptr }, ptr %l258, !tbaa !27
  %t466 = load ptr, ptr %l256, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s0, ptr %t466, { i64, ptr } %t465)
  br label %bb125
bb125:
  %t468 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t468, i8 10)
  br label %bb126
bb126:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eputLocation(ptr %v0, ptr %v1, ptr %a0, ptr %a1, { i64, [3 x i64] } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, [3 x i64] }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { { i64, ptr }, i64 }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca { i64, i64 }
  %l13 = alloca i64
  %l14 = alloca { { i64, ptr }, i64 }
  %l17 = alloca ptr
  %l19 = alloca { i64, ptr }
  %l27 = alloca ptr
  %l31 = alloca { i64, ptr }
  %l39 = alloca { { i64, ptr }, i64 }
  %l54 = alloca { i64, i64 }
  %l60 = alloca { { i64, ptr }, i64 }
  %l73 = alloca ptr
  %l75 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, [3 x i64] } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l17, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2esgr(ptr %v0, ptr %s0, ptr %s0, ptr %t2, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d32, i32 0, i32 1) })
  store { i64, ptr } %t4, ptr %l19
  br label %bb1
bb1:
  %t5 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t6 = load ptr, ptr %l17, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s0, ptr %t6, { i64, ptr } %t5)
  br label %bb2
bb2:
  %t8 = load { i64, [3 x i64] }, ptr %l2
  %t10 = extractvalue { i64, [3 x i64] } %t8, 0
  %t11 = icmp eq i64 %t10, 0
  br i1 %t11, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb7
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t13 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s1, ptr %t13, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d33, i32 0, i32 1) })
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s1)
  br label %bb27
bb7:
  %t15 = load { i64, [3 x i64] }, ptr %l2
  %t17 = extractvalue { i64, [3 x i64] } %t15, 0
  %t18 = icmp eq i64 %t17, 1
  br i1 %t18, label %bb8, label %bb9
bb8:
  %t20 = getelementptr { i64, [3 x i64] }, ptr %l2, i32 0, i32 1
  %t21 = getelementptr { i64 }, ptr %t20, i32 0, i32 0
  %t22 = load i64, ptr %t21
  store i64 %t22, ptr %l3, !tbaa !24
  br label %bb10
bb9:
  br label %bb13
bb10:
  %t24 = load ptr, ptr %l1, !tbaa !29
  store ptr %t24, ptr %l27, !tbaa !29
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/diag:Diagnostics", ptr %t25, i32 0, i32 1
  %t28 = load i64, ptr %l3, !tbaa !24
  %t31 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t27, i64 %t28)
  store { i64, ptr } %t31, ptr %l31
  br label %bb11
bb11:
  %t32 = load ptr, ptr %l27, !tbaa !29
  %t33 = load { i64, ptr }, ptr %l31, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %v0, ptr %t32, { i64, ptr } %t33)
  br label %bb12
bb12:
  br label %bb27
bb13:
  %t34 = load { i64, [3 x i64] }, ptr %l2
  %t36 = extractvalue { i64, [3 x i64] } %t34, 0
  %t37 = icmp eq i64 %t36, 2
  br i1 %t37, label %bb14, label %bb15
bb14:
  %t39 = getelementptr { i64, [3 x i64] }, ptr %l2, i32 0, i32 1
  %t40 = getelementptr { i64, i64 }, ptr %t39, i32 0, i32 0
  %t41 = load i64, ptr %t40
  store i64 %t41, ptr %l4, !tbaa !24
  %t43 = getelementptr { i64, [3 x i64] }, ptr %l2, i32 0, i32 1
  %t44 = getelementptr { i64, i64 }, ptr %t43, i32 0, i32 1
  %t45 = load i64, ptr %t44
  store i64 %t45, ptr %l5, !tbaa !24
  br label %bb16
bb15:
  br label %bb19
bb16:
  store %olang.scope zeroinitializer, ptr %s3
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load i64, ptr %l4, !tbaa !24
  %t49 = load i64, ptr %l5, !tbaa !24
  %t53 = call { { i64, ptr }, i64 } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eshown(ptr %v0, ptr %s3, ptr %t47, i64 %t48, i64 %t49)
  store { { i64, ptr }, i64 } %t53, ptr %l39
  br label %bb17
bb17:
  %t54 = load { { i64, ptr }, i64 }, ptr %l39
  store { { i64, ptr }, i64 } %t54, ptr %l6
  %t55 = getelementptr { { i64, ptr }, i64 }, ptr %l6, i32 0, i32 0
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  %t58 = getelementptr { { i64, ptr }, i64 }, ptr %l6, i32 0, i32 1
  %t59 = load i64, ptr %t58, !tbaa !24
  %t61 = load ptr, ptr %l1, !tbaa !29
  %t65 = extractvalue { i64, ptr } %t56, 1
  %t66 = extractvalue { i64, ptr } %t56, 0
  %t67 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d34, i32 0, i32 1) }, 1
  %t68 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d34, i32 0, i32 1) }, 0
  %t69 = add i64 %t66, %t68
  %t71 = call i64 @__olang_fmt_i64(ptr null, i64 %t59)
  %t72 = add i64 %t69, %t71
  %t73 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t72)
  call void @olang_textcopy(ptr %t73, ptr %t65, i64 %t66)
  %t74 = getelementptr i8, ptr %t73, i64 %t66
  call void @olang_textcopy(ptr %t74, ptr %t67, i64 %t68)
  %t75 = getelementptr i8, ptr %t74, i64 %t68
  %t76 = call i64 @__olang_fmt_i64(ptr %t75, i64 %t59)
  %t77 = insertvalue { i64, ptr } undef, i64 %t72, 0
  %t78 = insertvalue { i64, ptr } %t77, ptr %t73, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s3, ptr %t61, { i64, ptr } %t78)
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s3)
  br label %bb27
bb19:
  %t82 = load { i64, [3 x i64] }, ptr %l2
  %t84 = extractvalue { i64, [3 x i64] } %t82, 0
  %t85 = icmp eq i64 %t84, 3
  br i1 %t85, label %bb20, label %bb21
bb20:
  %t87 = getelementptr { i64, [3 x i64] }, ptr %l2, i32 0, i32 1
  %t88 = getelementptr { i64, i64, i64 }, ptr %t87, i32 0, i32 0
  %t89 = load i64, ptr %t88
  store i64 %t89, ptr %l9, !tbaa !24
  %t91 = getelementptr { i64, [3 x i64] }, ptr %l2, i32 0, i32 1
  %t92 = getelementptr { i64, i64, i64 }, ptr %t91, i32 0, i32 1
  %t93 = load i64, ptr %t92
  store i64 %t93, ptr %l10, !tbaa !24
  br label %bb22
bb21:
  br label %bb26
bb22:
  store %olang.scope zeroinitializer, ptr %s5
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t96 = load i64, ptr %l9, !tbaa !24
  %t97 = load i64, ptr %l10, !tbaa !24
  %t101 = call { i64, i64 } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2elineOf(ptr %v0, ptr %t95, i64 %t96, i64 %t97)
  store { i64, i64 } %t101, ptr %l54
  br label %bb23
bb23:
  %t102 = load { i64, i64 }, ptr %l54
  store { i64, i64 } %t102, ptr %l11
  %t103 = getelementptr { i64, i64 }, ptr %l11, i32 0, i32 0
  %t104 = load i64, ptr %t103, !tbaa !24
  %t106 = getelementptr { i64, i64 }, ptr %l11, i32 0, i32 1
  %t107 = load i64, ptr %t106, !tbaa !24
  store i64 %t107, ptr %l13, !tbaa !24
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t110 = load i64, ptr %l9, !tbaa !24
  %t115 = call { { i64, ptr }, i64 } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eshown(ptr %v0, ptr %s5, ptr %t109, i64 %t110, i64 %t104)
  store { { i64, ptr }, i64 } %t115, ptr %l60
  br label %bb24
bb24:
  %t116 = load { { i64, ptr }, i64 }, ptr %l60
  store { { i64, ptr }, i64 } %t116, ptr %l14
  %t117 = getelementptr { { i64, ptr }, i64 }, ptr %l14, i32 0, i32 0
  %t118 = load { i64, ptr }, ptr %t117, !tbaa !27
  %t120 = getelementptr { { i64, ptr }, i64 }, ptr %l14, i32 0, i32 1
  %t121 = load i64, ptr %t120, !tbaa !24
  %t123 = load ptr, ptr %l1, !tbaa !29
  %t126 = load i64, ptr %l10, !tbaa !24
  %t127 = load i64, ptr %l13, !tbaa !24
  %t130 = sub i64 %t126, %t127
  %t132 = add i64 %t130, 1
  %t134 = extractvalue { i64, ptr } %t118, 1
  %t135 = extractvalue { i64, ptr } %t118, 0
  %t136 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d35, i32 0, i32 1) }, 1
  %t137 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d35, i32 0, i32 1) }, 0
  %t138 = add i64 %t135, %t137
  %t140 = call i64 @__olang_fmt_i64(ptr null, i64 %t121)
  %t141 = add i64 %t138, %t140
  %t142 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d35, i32 0, i32 1) }, 1
  %t143 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d35, i32 0, i32 1) }, 0
  %t144 = add i64 %t141, %t143
  %t146 = call i64 @__olang_fmt_i64(ptr null, i64 %t132)
  %t147 = add i64 %t144, %t146
  %t148 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t147)
  call void @olang_textcopy(ptr %t148, ptr %t134, i64 %t135)
  %t149 = getelementptr i8, ptr %t148, i64 %t135
  call void @olang_textcopy(ptr %t149, ptr %t136, i64 %t137)
  %t150 = getelementptr i8, ptr %t149, i64 %t137
  %t151 = call i64 @__olang_fmt_i64(ptr %t150, i64 %t121)
  %t152 = getelementptr i8, ptr %t150, i64 %t140
  call void @olang_textcopy(ptr %t152, ptr %t142, i64 %t143)
  %t153 = getelementptr i8, ptr %t152, i64 %t143
  %t154 = call i64 @__olang_fmt_i64(ptr %t153, i64 %t132)
  %t155 = insertvalue { i64, ptr } undef, i64 %t147, 0
  %t156 = insertvalue { i64, ptr } %t155, ptr %t148, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s5, ptr %t123, { i64, ptr } %t156)
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s5)
  br label %bb27
bb26:
  call void @__olang_check_failed(ptr @olang_loc_63cbd536ec427bfa_9ebcb75929bac85e)
  unreachable
bb27:
  %t160 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s0, ptr %t160, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d36, i32 0, i32 1) })
  br label %bb28
bb28:
  %t162 = load ptr, ptr %l1, !tbaa !29
  store ptr %t162, ptr %l73, !tbaa !29
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t165 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2esgr(ptr %v0, ptr %s0, ptr %s0, ptr %t163, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d37, i32 0, i32 1) })
  store { i64, ptr } %t165, ptr %l75
  br label %bb29
bb29:
  %t166 = load { i64, ptr }, ptr %l75, !tbaa !27
  %t167 = load ptr, ptr %l73, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s0, ptr %t167, { i64, ptr } %t166)
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eputNote(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l8 = alloca { i64, [3 x i64] }
  %l11 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/diag:note", ptr %t1, i32 0, i32 4
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t6 = load ptr, ptr %l0, !tbaa !29
  store ptr %t6, ptr %l5, !tbaa !29
  %t7 = load ptr, ptr %l1, !tbaa !29
  store ptr %t7, ptr %l6, !tbaa !29
  %t8 = load ptr, ptr %l2, !tbaa !29
  %t10 = getelementptr %"compiler/diag:note", ptr %t8, i32 0, i32 1
  %t11 = load { i64, [3 x i64] }, ptr %t10
  store { i64, [3 x i64] } %t11, ptr %l8
  %t12 = load ptr, ptr %l2, !tbaa !29
  %t14 = getelementptr %"compiler/diag:note", ptr %t12, i32 0, i32 3
  %t15 = load i1, ptr %t14, !tbaa !21
  br i1 %t15, label %bb3, label %bb4
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t18 = load ptr, ptr %l1, !tbaa !29
  %t19 = load ptr, ptr %l2, !tbaa !29
  %t21 = getelementptr %"compiler/diag:note", ptr %t19, i32 0, i32 1
  %t22 = load { i64, [3 x i64] }, ptr %t21
  %t23 = load ptr, ptr %l2, !tbaa !29
  %t25 = getelementptr %"compiler/diag:note", ptr %t23, i32 0, i32 2
  %t26 = load { i64, ptr }, ptr %t25, !tbaa !27
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eputRow(ptr %v0, ptr %v1, ptr %s2, ptr %s2, ptr %v2, ptr %t17, ptr %t18, { i64, [3 x i64] } %t22, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d38, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d39, i32 0, i32 1) }, { i64, ptr } %t26)
  br label %bb7
bb3:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d40, i32 0, i32 1) }, ptr %l11, !tbaa !27
  br label %bb5
bb4:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d41, i32 0, i32 1) }, ptr %l11, !tbaa !27
  br label %bb5
bb5:
  %t31 = load ptr, ptr %l2, !tbaa !29
  %t33 = getelementptr %"compiler/diag:note", ptr %t31, i32 0, i32 2
  %t34 = load { i64, ptr }, ptr %t33, !tbaa !27
  %t35 = load ptr, ptr %l5, !tbaa !29
  %t36 = load ptr, ptr %l6, !tbaa !29
  %t37 = load { i64, [3 x i64] }, ptr %l8
  %t38 = load { i64, ptr }, ptr %l11, !tbaa !27
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eputPlain(ptr %v0, ptr %v1, ptr %s1, ptr %v2, ptr %t35, ptr %t36, { i64, [3 x i64] } %t37, { i64, ptr } %t38, { i64, ptr } %t34)
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s1)
  br label %bb8
bb7:
  call void @__olang_scope_close(ptr %s2)
  br label %bb8
bb8:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eputRow(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, { i64, [3 x i64] } %a2, { i64, ptr } %a3, { i64, ptr } %a4, { i64, ptr } %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, [3 x i64] }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l10 = alloca i1
  %l11 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l17 = alloca i1
  %l18 = alloca ptr
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l26 = alloca ptr
  %l28 = alloca { i64, ptr }
  %l30 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, [3 x i64] } %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t3 = load { i64, [3 x i64] }, ptr %l2
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eputLocation(ptr %v0, ptr %v1, ptr %t1, ptr %t2, { i64, [3 x i64] } %t3)
  br label %bb1
bb1:
  %t7 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t9 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t7, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d42, i32 0, i32 1) })
  store i1 %t9, ptr %l10
  br label %bb2
bb2:
  %t10 = load i1, ptr %l10, !tbaa !21
  br i1 %t10, label %bb3, label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t11 = load ptr, ptr %l1, !tbaa !29
  store ptr %t11, ptr %l11, !tbaa !29
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t16 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eerrorWord(ptr %v0, ptr %v3, ptr %s1, ptr %t12, { i64, ptr } %t13)
  store { i64, ptr } %t16, ptr %l14
  br label %bb5
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t17 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t19 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s2, { i64, ptr } %t17, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d43, i32 0, i32 1) })
  store i1 %t19, ptr %l17
  br label %bb7
bb5:
  %t20 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t21 = load ptr, ptr %l11, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s1, ptr %t21, { i64, ptr } %t20)
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s1)
  br label %bb17
bb7:
  %t23 = load i1, ptr %l17, !tbaa !21
  br i1 %t23, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t24 = load ptr, ptr %l1, !tbaa !29
  store ptr %t24, ptr %l18, !tbaa !29
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2esgr(ptr %v0, ptr %s3, ptr %s3, ptr %t25, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d44, i32 0, i32 1) })
  store { i64, ptr } %t27, ptr %l20
  br label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s5
  %t28 = load ptr, ptr %l1, !tbaa !29
  store ptr %t28, ptr %l26, !tbaa !29
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2esgr(ptr %v0, ptr %s5, ptr %s5, ptr %t29, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d45, i32 0, i32 1) })
  store { i64, ptr } %t31, ptr %l28
  br label %bb13
bb10:
  %t32 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t32, ptr %l21, !tbaa !27
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2esgr(ptr %v0, ptr %s3, ptr %s3, ptr %t33, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d46, i32 0, i32 1) })
  store { i64, ptr } %t35, ptr %l23
  br label %bb11
bb11:
  %t36 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t36, 1
  %t38 = extractvalue { i64, ptr } %t36, 0
  %t39 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d47, i32 0, i32 1) }, 1
  %t40 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d47, i32 0, i32 1) }, 0
  %t41 = add i64 %t38, %t40
  %t42 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t42, 1
  %t44 = extractvalue { i64, ptr } %t42, 0
  %t45 = add i64 %t41, %t44
  %t46 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d48, i32 0, i32 1) }, 1
  %t47 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d48, i32 0, i32 1) }, 0
  %t48 = add i64 %t45, %t47
  %t49 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t49, 1
  %t51 = extractvalue { i64, ptr } %t49, 0
  %t52 = add i64 %t48, %t51
  %t53 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d49, i32 0, i32 1) }, 1
  %t54 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d49, i32 0, i32 1) }, 0
  %t55 = add i64 %t52, %t54
  %t56 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t55)
  call void @olang_textcopy(ptr %t56, ptr %t37, i64 %t38)
  %t57 = getelementptr i8, ptr %t56, i64 %t38
  call void @olang_textcopy(ptr %t57, ptr %t39, i64 %t40)
  %t58 = getelementptr i8, ptr %t57, i64 %t40
  call void @olang_textcopy(ptr %t58, ptr %t43, i64 %t44)
  %t59 = getelementptr i8, ptr %t58, i64 %t44
  call void @olang_textcopy(ptr %t59, ptr %t46, i64 %t47)
  %t60 = getelementptr i8, ptr %t59, i64 %t47
  call void @olang_textcopy(ptr %t60, ptr %t50, i64 %t51)
  %t61 = getelementptr i8, ptr %t60, i64 %t51
  call void @olang_textcopy(ptr %t61, ptr %t53, i64 %t54)
  %t62 = insertvalue { i64, ptr } undef, i64 %t55, 0
  %t63 = insertvalue { i64, ptr } %t62, ptr %t56, 1
  %t65 = load ptr, ptr %l18, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s3, ptr %t65, { i64, ptr } %t63)
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s3)
  br label %bb16
bb13:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2esgr(ptr %v0, ptr %s5, ptr %s5, ptr %t67, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d50, i32 0, i32 1) })
  store { i64, ptr } %t69, ptr %l30
  br label %bb14
bb14:
  %t70 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t71 = extractvalue { i64, ptr } %t70, 1
  %t72 = extractvalue { i64, ptr } %t70, 0
  %t73 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d51, i32 0, i32 1) }, 1
  %t74 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d51, i32 0, i32 1) }, 0
  %t75 = add i64 %t72, %t74
  %t76 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t77 = extractvalue { i64, ptr } %t76, 1
  %t78 = extractvalue { i64, ptr } %t76, 0
  %t79 = add i64 %t75, %t78
  %t80 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d52, i32 0, i32 1) }, 1
  %t81 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d52, i32 0, i32 1) }, 0
  %t82 = add i64 %t79, %t81
  %t83 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t82)
  call void @olang_textcopy(ptr %t83, ptr %t71, i64 %t72)
  %t84 = getelementptr i8, ptr %t83, i64 %t72
  call void @olang_textcopy(ptr %t84, ptr %t73, i64 %t74)
  %t85 = getelementptr i8, ptr %t84, i64 %t74
  call void @olang_textcopy(ptr %t85, ptr %t77, i64 %t78)
  %t86 = getelementptr i8, ptr %t85, i64 %t78
  call void @olang_textcopy(ptr %t86, ptr %t80, i64 %t81)
  %t87 = insertvalue { i64, ptr } undef, i64 %t82, 0
  %t88 = insertvalue { i64, ptr } %t87, ptr %t83, 1
  %t90 = load ptr, ptr %l26, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s5, ptr %t90, { i64, ptr } %t88)
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s5)
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb17:
  %t92 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %v4, ptr %t92, { i64, ptr } %a5)
  br label %bb18
bb18:
  %t96 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t96, i8 10)
  br label %bb19
bb19:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t99 = load ptr, ptr %l1, !tbaa !29
  %t100 = load { i64, [3 x i64] }, ptr %l2
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eputExcerpt(ptr %v0, ptr %v1, ptr %t98, ptr %t99, { i64, [3 x i64] } %t100)
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2ereport(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/diagmsg:Msg" %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [3 x i64] }
  %l2 = alloca %"compiler/diagmsg:Msg"
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca %"compiler/diag:record"
  %l7 = alloca i64
  %l8 = alloca { i64, [3 x i64] }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l28 = alloca i1
  %l30 = alloca i1
  %l33 = alloca i64
  %l35 = alloca i64
  %l40 = alloca %"compiler/diag:record"
  %l43 = alloca i1
  %l44 = alloca i1
  %l45 = alloca { i64, [3 x i64] }
  %l47 = alloca { i64, [3 x i64] }
  %l49 = alloca i1
  %l55 = alloca ptr
  %l60 = alloca %"compiler/diag:record"
  %l64 = alloca i1
  %l66 = alloca i1
  %l73 = alloca i64
  %l76 = alloca { i64, [3 x i64] }
  %l81 = alloca %"compiler/diag:context"
  %l85 = alloca i64
  %l87 = alloca i64
  %l89 = alloca ptr
  %l92 = alloca i64
  %l94 = alloca i64
  %l96 = alloca ptr
  %l103 = alloca %"compiler/diag:record"
  %l106 = alloca i64
  %l114 = alloca i64
  %l118 = alloca ptr
  %l119 = alloca i64
  %l120 = alloca { i64, [3 x i64] }
  %l121 = alloca i64
  %l123 = alloca %"compiler/diagmsg:Msg"
  %l127 = alloca %"compiler/diag:note"
  %l136 = alloca i64
  %l139 = alloca i64
  %l160 = alloca %"compiler/diag:context"
  %l175 = alloca i64
  %l182 = alloca i1
  %l190 = alloca %"compiler/diag:context"
  %l197 = alloca i1
  %l201 = alloca ptr
  %l202 = alloca i64
  %l206 = alloca %"compiler/diag:context"
  %l207 = alloca { i64, [3 x i64] }
  %l208 = alloca i64
  %l213 = alloca %"compiler/diag:context"
  %l217 = alloca %"compiler/diag:note"
  %l227 = alloca ptr
  %l228 = alloca i64
  %l232 = alloca %"compiler/diag:context"
  %l233 = alloca { i64, [3 x i64] }
  %l234 = alloca i64
  %l239 = alloca %"compiler/diag:context"
  %l243 = alloca %"compiler/diag:note"
  %s0 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store { i64, [3 x i64] } %a1, ptr %l1
  store %"compiler/diagmsg:Msg" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/diag:Diagnostics", ptr %t1, i32 0, i32 24
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/diag:Diagnostics", ptr %t7, i32 0, i32 25
  %t10 = load i1, ptr %t9, !tbaa !21
  br i1 %t10, label %bb4, label %bb5
bb4:
  %t12 = getelementptr %"compiler/diagmsg:Msg", ptr %l2, i32 0, i32 1
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = call i1 @compiler_2fdiag_2eScripting(ptr %v1, { i64, ptr } %t13)
  store i1 %t15, ptr %l30
  br label %bb6
bb5:
  store i1 false, ptr %l28, !tbaa !21
  br label %bb7
bb6:
  %t16 = load i1, ptr %l30, !tbaa !21
  store i1 %t16, ptr %l28, !tbaa !21
  br label %bb7
bb7:
  %t17 = load i1, ptr %l28, !tbaa !21
  br i1 %t17, label %bb8, label %bb9
bb8:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/diag:Diagnostics", ptr %t18, i32 0, i32 26
  store ptr %t20, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb10
bb9:
  br label %bb28
bb10:
  %t22 = load i64, ptr %l5, !tbaa !24
  store i64 %t22, ptr %l33, !tbaa !24
  %t23 = load ptr, ptr %l4, !tbaa !29
  %t25 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3arecord_3e_2eLen_3ccompiler_2fdiag_3arecord_3e(ptr %v0, ptr %t23)
  store i64 %t25, ptr %l35
  br label %bb11
bb11:
  %t26 = load i64, ptr %l33, !tbaa !24
  %t27 = load i64, ptr %l35, !tbaa !24
  %t28 = icmp slt i64 %t26, %t27
  %t30 = xor i1 %t28, true
  br i1 %t30, label %bb12, label %bb13
bb12:
  br label %bb25
bb13:
  br label %bb14
bb14:
  %t32 = load ptr, ptr %l4, !tbaa !29
  %t33 = load i64, ptr %l5, !tbaa !24
  %t36 = call %"compiler/diag:record" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3arecord_3e_2eAt_3ccompiler_2fdiag_3arecord_3e(ptr %v0, ptr %v0, ptr %t32, i64 %t33)
  store %"compiler/diag:record" %t36, ptr %l40
  br label %bb15
bb15:
  %t37 = load %"compiler/diag:record", ptr %l40
  store %"compiler/diag:record" %t37, ptr %l6
  %t38 = getelementptr %"compiler/diag:record", ptr %l6, i32 0, i32 2
  %t39 = load { i64, ptr }, ptr %t38, !tbaa !27
  %t40 = getelementptr %"compiler/diagmsg:Msg", ptr %l2, i32 0, i32 2
  %t41 = load { i64, ptr }, ptr %t40, !tbaa !27
  %t44 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %t39, { i64, ptr } %t41)
  store i1 %t44, ptr %l43
  br label %bb16
bb16:
  %t45 = load i1, ptr %l43, !tbaa !21
  br i1 %t45, label %bb17, label %bb18
bb17:
  %t46 = getelementptr %"compiler/diag:record", ptr %l6, i32 0, i32 0
  %t47 = load { i64, [3 x i64] }, ptr %t46
  store { i64, [3 x i64] } %t47, ptr %l45
  %t48 = load { i64, [3 x i64] }, ptr %l1
  store { i64, [3 x i64] } %t48, ptr %l47
  %t51 = call i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2fdiag_3aWhere(ptr %l45, ptr %l47)
  store i1 %t51, ptr %l49
  br label %bb19
bb18:
  store i1 false, ptr %l44, !tbaa !21
  br label %bb20
bb19:
  %t52 = load i1, ptr %l49, !tbaa !21
  store i1 %t52, ptr %l44, !tbaa !21
  br label %bb20
bb20:
  %t53 = load i1, ptr %l44, !tbaa !21
  br i1 %t53, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  br label %bb24
bb24:
  %t55 = load i64, ptr %l5, !tbaa !24
  %t58 = add i64 %t55, 1
  store i64 %t58, ptr %l5, !tbaa !24
  br label %bb10
bb25:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/diag:Diagnostics", ptr %t60, i32 0, i32 26
  store ptr %t62, ptr %l55, !tbaa !29
  %t63 = load { i64, [3 x i64] }, ptr %l1
  %t64 = getelementptr %"compiler/diagmsg:Msg", ptr %l2, i32 0, i32 1
  %t65 = load { i64, ptr }, ptr %t64, !tbaa !27
  %t66 = getelementptr %"compiler/diagmsg:Msg", ptr %l2, i32 0, i32 2
  %t67 = load { i64, ptr }, ptr %t66, !tbaa !27
  %t68 = getelementptr %"compiler/diagmsg:Msg", ptr %l2, i32 0, i32 0
  %t69 = load i32, ptr %t68, !range !{i32 0, i32 949}
  %t74 = call %"compiler/diag:record" @compiler_2fdiag_3arecord_2ector(ptr %v1, ptr %v1, ptr %v0, { i64, [3 x i64] } %t63, { i64, ptr } %t65, { i64, ptr } %t67, i32 %t69, i64 -1, i1 false)
  store %"compiler/diag:record" %t74, ptr %l60
  br label %bb26
bb26:
  %t75 = load ptr, ptr %l55, !tbaa !29
  %t76 = load %"compiler/diag:record", ptr %l60
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3arecord_3e_2ePush_3ccompiler_2fdiag_3arecord_3e(ptr %v0, ptr %v0, ptr %t75, %"compiler/diag:record" %t76)
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb28:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/diag:Diagnostics", ptr %t78, i32 0, i32 14
  %t81 = load i1, ptr %t80, !tbaa !21
  br i1 %t81, label %bb29, label %bb30
bb29:
  %t83 = getelementptr %"compiler/diagmsg:Msg", ptr %l2, i32 0, i32 1
  %t84 = load { i64, ptr }, ptr %t83, !tbaa !27
  %t86 = call i1 @compiler_2fdiag_2eisScopeRule(ptr %v1, { i64, ptr } %t84)
  store i1 %t86, ptr %l66
  br label %bb31
bb30:
  store i1 false, ptr %l64, !tbaa !21
  br label %bb32
bb31:
  %t87 = load i1, ptr %l66, !tbaa !21
  store i1 %t87, ptr %l64, !tbaa !21
  br label %bb32
bb32:
  %t88 = load i1, ptr %l64, !tbaa !21
  br i1 %t88, label %bb33, label %bb34
bb33:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"compiler/diag:Diagnostics", ptr %t89, i32 0, i32 15
  %t92 = load i1, ptr %t91, !tbaa !21
  br i1 %t92, label %bb35, label %bb36
bb34:
  br label %bb38
bb35:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb36:
  br label %bb37
bb37:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr %"compiler/diag:Diagnostics", ptr %t95, i32 0, i32 15
  store i1 true, ptr %t97, !tbaa !21
  br label %bb38
bb38:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t99 = load { i64, [3 x i64] }, ptr %l1
  %t102 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eprogramUse(ptr %v0, ptr %t98, { i64, [3 x i64] } %t99)
  store i64 %t102, ptr %l73
  br label %bb39
bb39:
  %t103 = load i64, ptr %l73, !tbaa !24
  store i64 %t103, ptr %l7, !tbaa !24
  %t104 = load i64, ptr %l7, !tbaa !24
  %t106 = icmp slt i64 %t104, 0
  br i1 %t106, label %bb40, label %bb41
bb40:
  %t108 = load { i64, [3 x i64] }, ptr %l1
  store { i64, [3 x i64] } %t108, ptr %l76
  br label %bb43
bb41:
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = getelementptr %"compiler/diag:Diagnostics", ptr %t110, i32 0, i32 12
  %t113 = load i64, ptr %l7, !tbaa !24
  %t116 = call %"compiler/diag:context" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3acontext_3e_2eAt_3ccompiler_2fdiag_3acontext_3e(ptr %v0, ptr %s0, ptr %t112, i64 %t113)
  store %"compiler/diag:context" %t116, ptr %l81
  br label %bb42
bb42:
  %t117 = getelementptr %"compiler/diag:context", ptr %l81, i32 0, i32 0
  %t118 = load { i64, [3 x i64] }, ptr %t117
  store { i64, [3 x i64] } %t118, ptr %l76
  br label %bb43
bb43:
  %t120 = load { i64, [3 x i64] }, ptr %l76
  store { i64, [3 x i64] } %t120, ptr %l8
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"compiler/diag:Diagnostics", ptr %t121, i32 0, i32 11
  %t125 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t123)
  store i64 %t125, ptr %l85
  br label %bb44
bb44:
  %t126 = load i64, ptr %l85, !tbaa !24
  %t127 = icmp eq i64 %t126, 0
  br i1 %t127, label %bb45, label %bb46
bb45:
  store i64 -1, ptr %l87, !tbaa !24
  br label %bb49
bb46:
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t131 = getelementptr %"compiler/diag:Diagnostics", ptr %t129, i32 0, i32 11
  store ptr %t131, ptr %l89, !tbaa !29
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t134 = getelementptr %"compiler/diag:Diagnostics", ptr %t132, i32 0, i32 11
  %t136 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t134)
  store i64 %t136, ptr %l92
  br label %bb47
bb47:
  %t137 = load i64, ptr %l92, !tbaa !24
  %t138 = sub i64 %t137, 1
  %t139 = load ptr, ptr %l89, !tbaa !29
  %t141 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t139, i64 %t138)
  store i64 %t141, ptr %l94
  br label %bb48
bb48:
  %t142 = load i64, ptr %l94, !tbaa !24
  store i64 %t142, ptr %l87, !tbaa !24
  br label %bb49
bb49:
  %t143 = load i64, ptr %l87, !tbaa !24
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t146 = getelementptr %"compiler/diag:Diagnostics", ptr %t144, i32 0, i32 7
  store ptr %t146, ptr %l96, !tbaa !29
  %t147 = load { i64, [3 x i64] }, ptr %l8
  %t148 = getelementptr %"compiler/diagmsg:Msg", ptr %l2, i32 0, i32 1
  %t149 = load { i64, ptr }, ptr %t148, !tbaa !27
  %t150 = getelementptr %"compiler/diagmsg:Msg", ptr %l2, i32 0, i32 2
  %t151 = load { i64, ptr }, ptr %t150, !tbaa !27
  %t152 = getelementptr %"compiler/diagmsg:Msg", ptr %l2, i32 0, i32 0
  %t153 = load i32, ptr %t152, !range !{i32 0, i32 949}
  %t162 = call %"compiler/diag:record" @compiler_2fdiag_3arecord_2ector(ptr %v1, ptr %v1, ptr %v0, { i64, [3 x i64] } %t147, { i64, ptr } %t149, { i64, ptr } %t151, i32 %t153, i64 %t143, i1 %a3)
  store %"compiler/diag:record" %t162, ptr %l103
  br label %bb50
bb50:
  %t163 = load ptr, ptr %l96, !tbaa !29
  %t164 = load %"compiler/diag:record", ptr %l103
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3arecord_3e_2ePush_3ccompiler_2fdiag_3arecord_3e(ptr %v0, ptr %v0, ptr %t163, %"compiler/diag:record" %t164)
  br label %bb51
bb51:
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t167 = getelementptr %"compiler/diag:Diagnostics", ptr %t165, i32 0, i32 7
  %t169 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3arecord_3e_2eLen_3ccompiler_2fdiag_3arecord_3e(ptr %v0, ptr %t167)
  store i64 %t169, ptr %l106
  br label %bb52
bb52:
  %t170 = load i64, ptr %l106, !tbaa !24
  %t171 = sub i64 %t170, 1
  store i64 %t171, ptr %l10, !tbaa !24
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t174 = load i64, ptr %l10, !tbaa !24
  %t175 = load { i64, [3 x i64] }, ptr %l8
  %t176 = load %"compiler/diagmsg:Msg", ptr %l2
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2epushOwn(ptr %v0, ptr %v1, ptr %t173, i64 %t174, { i64, [3 x i64] } %t175, %"compiler/diagmsg:Msg" %t176)
  br label %bb53
bb53:
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t183 = getelementptr %"compiler/diag:Diagnostics", ptr %t181, i32 0, i32 12
  %t185 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3acontext_3e_2eLen_3ccompiler_2fdiag_3acontext_3e(ptr %v0, ptr %t183)
  store i64 %t185, ptr %l114
  br label %bb54
bb54:
  %t186 = load i64, ptr %l114, !tbaa !24
  store i64 %t186, ptr %l11, !tbaa !24
  %t187 = load i64, ptr %l7, !tbaa !24
  %t189 = icmp sge i64 %t187, 0
  br i1 %t189, label %bb55, label %bb56
bb55:
  store %olang.scope zeroinitializer, ptr %s9
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t193 = getelementptr %"compiler/diag:Diagnostics", ptr %t191, i32 0, i32 8
  store ptr %t193, ptr %l118, !tbaa !29
  %t194 = load i64, ptr %l10, !tbaa !24
  store i64 %t194, ptr %l119, !tbaa !24
  %t195 = load { i64, [3 x i64] }, ptr %l1
  store { i64, [3 x i64] } %t195, ptr %l120
  %t196 = call ptr @__olang_scope_hold(ptr %v0)
  %t197 = ptrtoint ptr %t196 to i64
  store i64 %t197, ptr %l121, !tbaa !24
  %t198 = load i1, ptr @olang_2esole_2ecompiler_2fdiag_3anote_2e2
  br i1 %t198, label %bb57, label %bb58
bb56:
  br label %bb62
bb57:
  %t200 = call ptr @__olang_region_make(ptr %v0)
  %t201 = ptrtoint ptr %t200 to i64
  store i64 %t201, ptr %l121, !tbaa !24
  br label %bb58
bb58:
  %t202 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoteInLibrary(ptr %s9)
  store %"compiler/diagmsg:Msg" %t202, ptr %l123
  br label %bb59
bb59:
  %t203 = getelementptr %"compiler/diagmsg:Msg", ptr %l123, i32 0, i32 2
  %t204 = load { i64, ptr }, ptr %t203, !tbaa !27
  %t206 = extractvalue { i64, ptr } %t204, 1
  %t207 = extractvalue { i64, ptr } %t204, 0
  %t208 = load i64, ptr %l121
  %t209 = inttoptr i64 %t208 to ptr
  %t210 = call ptr @__olang_held_alloc(ptr %t209, i64 %t207)
  call void @olang_textcopy(ptr %t210, ptr %t206, i64 %t207)
  %t211 = insertvalue { i64, ptr } undef, i64 %t207, 0
  %t212 = insertvalue { i64, ptr } %t211, ptr %t210, 1
  %t214 = load i64, ptr %l119, !tbaa !24
  %t215 = load { i64, [3 x i64] }, ptr %l120
  %t217 = call %"compiler/diag:note" @compiler_2fdiag_3anote_2ector(ptr %v0, ptr %v0, i64 %t214, { i64, [3 x i64] } %t215, { i64, ptr } %t212, i1 false, i1 false)
  store %"compiler/diag:note" %t217, ptr %l127
  br label %bb60
bb60:
  %t218 = load ptr, ptr %l118, !tbaa !29
  %t219 = load %"compiler/diag:note", ptr %l127
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3anote_3e_2ePush_3ccompiler_2fdiag_3anote_3e(ptr %v0, ptr %v0, ptr %t218, %"compiler/diag:note" %t219)
  br label %bb61
bb61:
  %t220 = load i64, ptr %l7, !tbaa !24
  %t222 = add i64 %t220, 1
  store i64 %t222, ptr %l11, !tbaa !24
  call void @__olang_scope_close(ptr %s9)
  br label %bb62
bb62:
  store i64 -1, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  %t224 = load ptr, ptr %l0, !tbaa !29
  %t226 = getelementptr %"compiler/diag:Diagnostics", ptr %t224, i32 0, i32 13
  %t227 = load i64, ptr %t226, !tbaa !24
  store i64 %t227, ptr %l14, !tbaa !24
  %t229 = load i64, ptr %l11, !tbaa !24
  store i64 %t229, ptr %l15, !tbaa !24
  store i64 1, ptr %l16, !tbaa !24
  %t231 = load i64, ptr %l15, !tbaa !24
  %t232 = load i64, ptr %l14, !tbaa !24
  %t235 = icmp sgt i64 %t231, %t232
  br i1 %t235, label %bb63, label %bb64
bb63:
  %t237 = load i64, ptr %l16, !tbaa !24
  %t239 = icmp sgt i64 %t237, 0
  br i1 %t239, label %bb65, label %bb66
bb64:
  store i64 0, ptr %l136, !tbaa !24
  br label %bb68
bb65:
  %t241 = load i64, ptr %l15, !tbaa !24
  %t242 = load i64, ptr %l14, !tbaa !24
  %t245 = sub i64 %t241, %t242
  %t246 = load i64, ptr %l16, !tbaa !24
  %t249 = add i64 %t245, %t246
  %t251 = sub i64 %t249, 1
  %t252 = load i64, ptr %l16, !tbaa !24
  %t255 = sdiv i64 %t251, %t252
  store i64 %t255, ptr %l139, !tbaa !24
  br label %bb67
bb66:
  store i64 0, ptr %l139, !tbaa !24
  br label %bb67
bb67:
  %t257 = load i64, ptr %l139, !tbaa !24
  store i64 %t257, ptr %l136, !tbaa !24
  br label %bb68
bb68:
  %t258 = load i64, ptr %l136, !tbaa !24
  store i64 %t258, ptr %l17, !tbaa !24
  store i64 0, ptr %l18, !tbaa !24
  br label %bb69
bb69:
  %t259 = load i64, ptr %l18, !tbaa !24
  %t260 = load i64, ptr %l17, !tbaa !24
  %t263 = icmp slt i64 %t259, %t260
  %t265 = xor i1 %t263, true
  br i1 %t265, label %bb70, label %bb71
bb70:
  br label %bb81
bb71:
  br label %bb72
bb72:
  %t267 = load i64, ptr %l14, !tbaa !24
  %t268 = load i64, ptr %l18, !tbaa !24
  %t269 = load i64, ptr %l16, !tbaa !24
  %t272 = mul i64 %t268, %t269
  %t275 = add i64 %t267, %t272
  store i64 %t275, ptr %l19, !tbaa !24
  %t277 = load ptr, ptr %l0, !tbaa !29
  %t279 = getelementptr %"compiler/diag:Diagnostics", ptr %t277, i32 0, i32 12
  %t280 = load i64, ptr %l19, !tbaa !24
  %t283 = call %"compiler/diag:context" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3acontext_3e_2eAt_3ccompiler_2fdiag_3acontext_3e(ptr %v0, ptr %v0, ptr %t279, i64 %t280)
  store %"compiler/diag:context" %t283, ptr %l160
  br label %bb73
bb73:
  %t284 = getelementptr %"compiler/diag:context", ptr %l160, i32 0, i32 1
  %t285 = load { i64, ptr }, ptr %t284, !tbaa !27
  %t287 = extractvalue { i64, ptr } %t285, 0
  %t289 = icmp eq i64 %t287, 0
  br i1 %t289, label %bb74, label %bb75
bb74:
  br label %bb80
bb75:
  br label %bb76
bb76:
  %t291 = load i64, ptr %l12, !tbaa !24
  %t293 = icmp slt i64 %t291, 0
  br i1 %t293, label %bb77, label %bb78
bb77:
  %t295 = load i64, ptr %l19, !tbaa !24
  store i64 %t295, ptr %l12, !tbaa !24
  br label %bb79
bb78:
  br label %bb79
bb79:
  %t297 = load i64, ptr %l13, !tbaa !24
  %t300 = add i64 %t297, 1
  store i64 %t300, ptr %l13, !tbaa !24
  br label %bb80
bb80:
  %t302 = load i64, ptr %l18, !tbaa !24
  %t305 = add i64 %t302, 1
  store i64 %t305, ptr %l18, !tbaa !24
  br label %bb69
bb81:
  %t307 = load i64, ptr %l13, !tbaa !24
  %t309 = icmp sgt i64 %t307, 3
  br i1 %t309, label %bb82, label %bb83
bb82:
  store i64 2, ptr %l175, !tbaa !24
  br label %bb84
bb83:
  store i64 3, ptr %l175, !tbaa !24
  br label %bb84
bb84:
  %t311 = load i64, ptr %l175, !tbaa !24
  store i64 %t311, ptr %l20, !tbaa !24
  store i64 0, ptr %l21, !tbaa !24
  %t312 = load i64, ptr %l11, !tbaa !24
  %t314 = sub i64 %t312, 1
  store i64 %t314, ptr %l22, !tbaa !24
  br label %bb85
bb85:
  %t316 = load i64, ptr %l22, !tbaa !24
  %t317 = load ptr, ptr %l0, !tbaa !29
  %t319 = getelementptr %"compiler/diag:Diagnostics", ptr %t317, i32 0, i32 13
  %t320 = load i64, ptr %t319, !tbaa !24
  %t323 = icmp sge i64 %t316, %t320
  br i1 %t323, label %bb86, label %bb87
bb86:
  %t325 = load i64, ptr %l21, !tbaa !24
  %t326 = load i64, ptr %l20, !tbaa !24
  %t329 = icmp slt i64 %t325, %t326
  store i1 %t329, ptr %l182, !tbaa !21
  br label %bb88
bb87:
  store i1 false, ptr %l182, !tbaa !21
  br label %bb88
bb88:
  %t331 = load i1, ptr %l182, !tbaa !21
  %t332 = xor i1 %t331, true
  br i1 %t332, label %bb89, label %bb90
bb89:
  br label %bb109
bb90:
  br label %bb91
bb91:
  %t334 = load ptr, ptr %l0, !tbaa !29
  %t336 = getelementptr %"compiler/diag:Diagnostics", ptr %t334, i32 0, i32 12
  %t337 = load i64, ptr %l22, !tbaa !24
  %t340 = call %"compiler/diag:context" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3acontext_3e_2eAt_3ccompiler_2fdiag_3acontext_3e(ptr %v0, ptr %v0, ptr %t336, i64 %t337)
  store %"compiler/diag:context" %t340, ptr %l190
  br label %bb92
bb92:
  %t341 = getelementptr %"compiler/diag:context", ptr %l190, i32 0, i32 1
  %t342 = load { i64, ptr }, ptr %t341, !tbaa !27
  %t344 = extractvalue { i64, ptr } %t342, 0
  %t346 = icmp sgt i64 %t344, 0
  br i1 %t346, label %bb93, label %bb94
bb93:
  store %olang.scope zeroinitializer, ptr %s17
  %t348 = load i64, ptr %l22, !tbaa !24
  %t349 = load i64, ptr %l12, !tbaa !24
  %t352 = icmp eq i64 %t348, %t349
  br i1 %t352, label %bb95, label %bb96
bb94:
  br label %bb107
bb95:
  %t354 = load i64, ptr %l13, !tbaa !24
  %t356 = icmp sgt i64 %t354, 3
  store i1 %t356, ptr %l197, !tbaa !21
  br label %bb97
bb96:
  store i1 false, ptr %l197, !tbaa !21
  br label %bb97
bb97:
  %t358 = load i1, ptr %l197, !tbaa !21
  br i1 %t358, label %bb98, label %bb99
bb98:
  call void @__olang_scope_close(ptr %s17)
  br label %bb109
bb99:
  br label %bb100
bb100:
  %t359 = load ptr, ptr %l0, !tbaa !29
  %t361 = getelementptr %"compiler/diag:Diagnostics", ptr %t359, i32 0, i32 8
  store ptr %t361, ptr %l201, !tbaa !29
  %t362 = load i64, ptr %l10, !tbaa !24
  store i64 %t362, ptr %l202, !tbaa !24
  %t363 = load ptr, ptr %l0, !tbaa !29
  %t365 = getelementptr %"compiler/diag:Diagnostics", ptr %t363, i32 0, i32 12
  %t366 = load i64, ptr %l22, !tbaa !24
  %t369 = call %"compiler/diag:context" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3acontext_3e_2eAt_3ccompiler_2fdiag_3acontext_3e(ptr %v0, ptr %s17, ptr %t365, i64 %t366)
  store %"compiler/diag:context" %t369, ptr %l206
  br label %bb101
bb101:
  %t370 = getelementptr %"compiler/diag:context", ptr %l206, i32 0, i32 0
  %t371 = load { i64, [3 x i64] }, ptr %t370
  store { i64, [3 x i64] } %t371, ptr %l207
  %t372 = call ptr @__olang_scope_hold(ptr %v0)
  %t373 = ptrtoint ptr %t372 to i64
  store i64 %t373, ptr %l208, !tbaa !24
  %t374 = load i1, ptr @olang_2esole_2ecompiler_2fdiag_3anote_2e2
  br i1 %t374, label %bb102, label %bb103
bb102:
  %t376 = call ptr @__olang_region_make(ptr %v0)
  %t377 = ptrtoint ptr %t376 to i64
  store i64 %t377, ptr %l208, !tbaa !24
  br label %bb103
bb103:
  %t378 = load ptr, ptr %l0, !tbaa !29
  %t380 = getelementptr %"compiler/diag:Diagnostics", ptr %t378, i32 0, i32 12
  %t381 = load i64, ptr %l22, !tbaa !24
  %t384 = call %"compiler/diag:context" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3acontext_3e_2eAt_3ccompiler_2fdiag_3acontext_3e(ptr %v0, ptr %v0, ptr %t380, i64 %t381)
  store %"compiler/diag:context" %t384, ptr %l213
  br label %bb104
bb104:
  %t385 = getelementptr %"compiler/diag:context", ptr %l213, i32 0, i32 1
  %t386 = load { i64, ptr }, ptr %t385, !tbaa !27
  %t388 = extractvalue { i64, ptr } %t386, 1
  %t389 = extractvalue { i64, ptr } %t386, 0
  %t390 = load i64, ptr %l208
  %t391 = inttoptr i64 %t390 to ptr
  %t392 = call ptr @__olang_held_alloc(ptr %t391, i64 %t389)
  call void @olang_textcopy(ptr %t392, ptr %t388, i64 %t389)
  %t393 = insertvalue { i64, ptr } undef, i64 %t389, 0
  %t394 = insertvalue { i64, ptr } %t393, ptr %t392, 1
  %t396 = load i64, ptr %l202, !tbaa !24
  %t397 = load { i64, [3 x i64] }, ptr %l207
  %t399 = call %"compiler/diag:note" @compiler_2fdiag_3anote_2ector(ptr %v0, ptr %v0, i64 %t396, { i64, [3 x i64] } %t397, { i64, ptr } %t394, i1 false, i1 false)
  store %"compiler/diag:note" %t399, ptr %l217
  br label %bb105
bb105:
  %t400 = load ptr, ptr %l201, !tbaa !29
  %t401 = load %"compiler/diag:note", ptr %l217
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3anote_3e_2ePush_3ccompiler_2fdiag_3anote_3e(ptr %v0, ptr %v0, ptr %t400, %"compiler/diag:note" %t401)
  br label %bb106
bb106:
  %t402 = load i64, ptr %l21, !tbaa !24
  %t405 = add i64 %t402, 1
  store i64 %t405, ptr %l21, !tbaa !24
  call void @__olang_scope_close(ptr %s17)
  br label %bb107
bb107:
  %t407 = load i64, ptr %l22, !tbaa !24
  %t410 = sub i64 %t407, 1
  store i64 %t410, ptr %l22, !tbaa !24
  br label %bb108
bb108:
  br label %bb85
bb109:
  %t412 = load i64, ptr %l13, !tbaa !24
  %t414 = icmp sgt i64 %t412, 3
  br i1 %t414, label %bb110, label %bb111
bb110:
  store %olang.scope zeroinitializer, ptr %s20
  %t416 = load ptr, ptr %l0, !tbaa !29
  %t418 = getelementptr %"compiler/diag:Diagnostics", ptr %t416, i32 0, i32 8
  store ptr %t418, ptr %l227, !tbaa !29
  %t419 = load i64, ptr %l10, !tbaa !24
  store i64 %t419, ptr %l228, !tbaa !24
  %t420 = load ptr, ptr %l0, !tbaa !29
  %t422 = getelementptr %"compiler/diag:Diagnostics", ptr %t420, i32 0, i32 12
  %t423 = load i64, ptr %l12, !tbaa !24
  %t426 = call %"compiler/diag:context" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3acontext_3e_2eAt_3ccompiler_2fdiag_3acontext_3e(ptr %v0, ptr %s20, ptr %t422, i64 %t423)
  store %"compiler/diag:context" %t426, ptr %l232
  br label %bb112
bb111:
  br label %bb118
bb112:
  %t427 = getelementptr %"compiler/diag:context", ptr %l232, i32 0, i32 0
  %t428 = load { i64, [3 x i64] }, ptr %t427
  store { i64, [3 x i64] } %t428, ptr %l233
  %t429 = call ptr @__olang_scope_hold(ptr %v0)
  %t430 = ptrtoint ptr %t429 to i64
  store i64 %t430, ptr %l234, !tbaa !24
  %t431 = load i1, ptr @olang_2esole_2ecompiler_2fdiag_3anote_2e2
  br i1 %t431, label %bb113, label %bb114
bb113:
  %t433 = call ptr @__olang_region_make(ptr %v0)
  %t434 = ptrtoint ptr %t433 to i64
  store i64 %t434, ptr %l234, !tbaa !24
  br label %bb114
bb114:
  %t435 = load ptr, ptr %l0, !tbaa !29
  %t437 = getelementptr %"compiler/diag:Diagnostics", ptr %t435, i32 0, i32 12
  %t438 = load i64, ptr %l12, !tbaa !24
  %t441 = call %"compiler/diag:context" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3acontext_3e_2eAt_3ccompiler_2fdiag_3acontext_3e(ptr %v0, ptr %v0, ptr %t437, i64 %t438)
  store %"compiler/diag:context" %t441, ptr %l239
  br label %bb115
bb115:
  %t442 = getelementptr %"compiler/diag:context", ptr %l239, i32 0, i32 1
  %t443 = load { i64, ptr }, ptr %t442, !tbaa !27
  %t445 = extractvalue { i64, ptr } %t443, 1
  %t446 = extractvalue { i64, ptr } %t443, 0
  %t447 = load i64, ptr %l234
  %t448 = inttoptr i64 %t447 to ptr
  %t449 = call ptr @__olang_held_alloc(ptr %t448, i64 %t446)
  call void @olang_textcopy(ptr %t449, ptr %t445, i64 %t446)
  %t450 = insertvalue { i64, ptr } undef, i64 %t446, 0
  %t451 = insertvalue { i64, ptr } %t450, ptr %t449, 1
  %t453 = load i64, ptr %l228, !tbaa !24
  %t454 = load { i64, [3 x i64] }, ptr %l233
  %t456 = call %"compiler/diag:note" @compiler_2fdiag_3anote_2ector(ptr %v0, ptr %v0, i64 %t453, { i64, [3 x i64] } %t454, { i64, ptr } %t451, i1 false, i1 false)
  store %"compiler/diag:note" %t456, ptr %l243
  br label %bb116
bb116:
  %t457 = load ptr, ptr %l227, !tbaa !29
  %t458 = load %"compiler/diag:note", ptr %l243
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3anote_3e_2ePush_3ccompiler_2fdiag_3anote_3e(ptr %v0, ptr %v0, ptr %t457, %"compiler/diag:note" %t458)
  br label %bb117
bb117:
  call void @__olang_scope_close(ptr %s20)
  br label %bb118
bb118:
  %t459 = load i64, ptr %l10, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t459, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { { i64, ptr }, i64 } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eshown(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l8 = alloca i64
  %l14 = alloca { i64, ptr }
  %l24 = alloca i1
  %l25 = alloca i64
  %l28 = alloca i64
  %l30 = alloca i1
  %l34 = alloca { i64, ptr }
  %l35 = alloca i1
  %l39 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l51 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { { i64, ptr }, i64 }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/diag:Diagnostics", ptr %t1, i32 0, i32 27
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t3, i64 %t4)
  store i64 %t7, ptr %l8
  br label %bb1
bb1:
  %t8 = load i64, ptr %l8, !tbaa !24
  store i64 %t8, ptr %l3, !tbaa !24
  %t9 = load i64, ptr %l3, !tbaa !24
  %t11 = icmp slt i64 %t9, 0
  br i1 %t11, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/diag:Diagnostics", ptr %t13, i32 0, i32 1
  %t16 = load i64, ptr %l1, !tbaa !24
  %t19 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %s1, ptr %t15, i64 %t16)
  store { i64, ptr } %t19, ptr %l14
  br label %bb4
bb3:
  br label %bb5
bb4:
  %t20 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t20, 1
  %t22 = extractvalue { i64, ptr } %t20, 0
  %t23 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t22)
  call void @olang_textcopy(ptr %t23, ptr %t21, i64 %t22)
  %t24 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t23, 1
  %t26 = load i64, ptr %l2, !tbaa !24
  %t28 = insertvalue { { i64, ptr }, i64 } undef, { i64, ptr } %t25, 0
  %t30 = insertvalue { { i64, ptr }, i64 } %t28, i64 %t26, 1
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store { { i64, ptr }, i64 } %t30, ptr %rv
  br label %ret
bb5:
  %t32 = load i64, ptr %l3, !tbaa !24
  %t33 = load i64, ptr %l2, !tbaa !24
  %t36 = add i64 %t32, %t33
  %t38 = sub i64 %t36, 1
  store i64 %t38, ptr %l4, !tbaa !24
  %t40 = load i64, ptr %l2, !tbaa !24
  %t42 = icmp slt i64 %t40, 1
  br i1 %t42, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l24, !tbaa !21
  br label %bb9
bb7:
  %t44 = load i64, ptr %l4, !tbaa !24
  store i64 %t44, ptr %l25, !tbaa !24
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/diag:Diagnostics", ptr %t45, i32 0, i32 28
  %t49 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t47)
  store i64 %t49, ptr %l28
  br label %bb8
bb8:
  %t50 = load i64, ptr %l25, !tbaa !24
  %t51 = load i64, ptr %l28, !tbaa !24
  %t52 = icmp sge i64 %t50, %t51
  store i1 %t52, ptr %l24, !tbaa !21
  br label %bb9
bb9:
  %t54 = load i1, ptr %l24, !tbaa !21
  br i1 %t54, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb14
bb11:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/diag:Diagnostics", ptr %t55, i32 0, i32 28
  %t58 = load i64, ptr %l4, !tbaa !24
  %t61 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t57, i64 %t58)
  store { i64, ptr } %t61, ptr %l34
  br label %bb12
bb12:
  %t62 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t63 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t62, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d53, i32 0, i32 1) })
  store i1 %t63, ptr %l35
  br label %bb13
bb13:
  %t64 = load i1, ptr %l35, !tbaa !21
  store i1 %t64, ptr %l30, !tbaa !21
  br label %bb14
bb14:
  %t65 = load i1, ptr %l30, !tbaa !21
  br i1 %t65, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s3
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/diag:Diagnostics", ptr %t66, i32 0, i32 1
  %t69 = load i64, ptr %l1, !tbaa !24
  %t72 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %s3, ptr %t68, i64 %t69)
  store { i64, ptr } %t72, ptr %l39
  br label %bb17
bb16:
  br label %bb18
bb17:
  %t73 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t74 = extractvalue { i64, ptr } %t73, 1
  %t75 = extractvalue { i64, ptr } %t73, 0
  %t76 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t75)
  call void @olang_textcopy(ptr %t76, ptr %t74, i64 %t75)
  %t77 = insertvalue { i64, ptr } undef, i64 %t75, 0
  %t78 = insertvalue { i64, ptr } %t77, ptr %t76, 1
  %t79 = load i64, ptr %l2, !tbaa !24
  %t81 = insertvalue { { i64, ptr }, i64 } undef, { i64, ptr } %t78, 0
  %t83 = insertvalue { { i64, ptr }, i64 } %t81, i64 %t79, 1
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store { { i64, ptr }, i64 } %t83, ptr %rv
  br label %ret
bb18:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/diag:Diagnostics", ptr %t85, i32 0, i32 28
  %t88 = load i64, ptr %l4, !tbaa !24
  %t91 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %s0, ptr %t87, i64 %t88)
  store { i64, ptr } %t91, ptr %l46
  br label %bb19
bb19:
  %t92 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t93 = extractvalue { i64, ptr } %t92, 1
  %t94 = extractvalue { i64, ptr } %t92, 0
  %t95 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t94)
  call void @olang_textcopy(ptr %t95, ptr %t93, i64 %t94)
  %t96 = insertvalue { i64, ptr } undef, i64 %t94, 0
  %t97 = insertvalue { i64, ptr } %t96, ptr %t95, 1
  store { i64, ptr } %t97, ptr %l47, !tbaa !27
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/diag:Diagnostics", ptr %t98, i32 0, i32 29
  %t101 = load i64, ptr %l4, !tbaa !24
  %t104 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t100, i64 %t101)
  store i64 %t104, ptr %l51
  br label %bb20
bb20:
  %t105 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t106 = insertvalue { { i64, ptr }, i64 } undef, { i64, ptr } %t105, 0
  %t107 = load i64, ptr %l51, !tbaa !24
  %t108 = insertvalue { { i64, ptr }, i64 } %t106, i64 %t107, 1
  call void @__olang_scope_close(ptr %s0)
  store { { i64, ptr }, i64 } %t108, ptr %rv
  br label %ret
ret:
  %rr = load { { i64, ptr }, i64 }, ptr %rv
  ret { { i64, ptr }, i64 } %rr
}

define dso_local { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2ewritten(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca %"compiler/diag:record"
  %l13 = alloca { i64, [3 x i64] }
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca { i64, i64 }
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i1
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca %"compiler/diag:record"
  %l33 = alloca i1
  %l34 = alloca ptr
  %l35 = alloca i64
  %l36 = alloca i64
  %lp38 = alloca ptr
  %l39 = alloca ptr
  %l40 = alloca i64
  %l41 = alloca i64
  %l43 = alloca { i64, ptr }
  %l44 = alloca i64
  %l45 = alloca ptr
  %l46 = alloca i64
  %l47 = alloca i64
  %l48 = alloca { i64, ptr }
  %l51 = alloca i64
  %l52 = alloca i64
  %l56 = alloca i64
  %l60 = alloca i64
  %l64 = alloca i64
  %l66 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l72 = alloca i64
  %l75 = alloca i64
  %l96 = alloca %"compiler/diag:record"
  %l109 = alloca { i64, i64 }
  %l134 = alloca i1
  %l137 = alloca i64
  %l141 = alloca i64
  %l144 = alloca i64
  %l164 = alloca i64
  %l168 = alloca %"compiler/diag:record"
  %l174 = alloca i1
  %l180 = alloca i1
  %l186 = alloca i1
  %l189 = alloca i1
  %l194 = alloca i1
  %l195 = alloca i1
  %l200 = alloca i1
  %l206 = alloca i1
  %l208 = alloca i1
  %l209 = alloca i32
  %l211 = alloca i32
  %l213 = alloca i1
  %l214 = alloca i1
  %l220 = alloca i1
  %l238 = alloca i64
  %l241 = alloca i64
  %l243 = alloca i64
  %l248 = alloca i64
  %l250 = alloca i1
  %l255 = alloca i1
  %l261 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l263 = alloca i64
  %l265 = alloca i64
  %l270 = alloca i64
  %l275 = alloca i1
  %l282 = alloca i64
  %l285 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l286 = alloca i64
  %l288 = alloca { i64, ptr }
  %l289 = alloca i64
  %l290 = alloca { i64, ptr }
  %l295 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l300 = alloca i64
  %l301 = alloca i64
  %l306 = alloca i64
  %l308 = alloca i64
  %l313 = alloca i64
  %l330 = alloca { i64, ptr }
  %l337 = alloca { i64, ptr }
  %l338 = alloca i64
  %l339 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t646 = alloca i64
  %t723 = alloca { { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/diag:Diagnostics", ptr %t1, i32 0, i32 7
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3arecord_3e_2eLen_3ccompiler_2fdiag_3arecord_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l51
  br label %bb1
bb1:
  %t6 = load i64, ptr %l51, !tbaa !24
  store i64 %t6, ptr %l1, !tbaa !24
  %t7 = load i64, ptr %l1, !tbaa !24
  store i64 %t7, ptr %l52, !tbaa !24
  %t8 = load i64, ptr %l52, !tbaa !24
  %t9 = icmp sge i64 %t8, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load i64, ptr %l52, !tbaa !24
  %t12 = icmp sle i64 %t11, 1152921504606846975
  br i1 %t12, label %bb4, label %bb5
bb3:
  call void @__olang_check_failed(ptr @olang_loc_4dcb4d0a5bf00c4a_ab355dfc0aa866a6)
  unreachable
bb4:
  %t14 = load i64, ptr %l52, !tbaa !24
  %t15 = mul i64 %t14, 8
  %t16 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t15)
  %t17 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  store { i64, ptr } %t18, ptr %l2, !tbaa !27
  %t20 = load i64, ptr %l1, !tbaa !24
  store i64 %t20, ptr %l56, !tbaa !24
  %t21 = load i64, ptr %l56, !tbaa !24
  %t22 = icmp sge i64 %t21, 0
  br i1 %t22, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_4dcb4d0a5bf00c4a_ab355dfc0aa866a6)
  unreachable
bb6:
  %t24 = load i64, ptr %l56, !tbaa !24
  %t25 = icmp sle i64 %t24, 1152921504606846975
  br i1 %t25, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_661de3b27f7b1d1f_a886f9f6d8c58a3b)
  unreachable
bb8:
  %t27 = load i64, ptr %l56, !tbaa !24
  %t28 = mul i64 %t27, 8
  %t29 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t28)
  %t30 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t29, 1
  store { i64, ptr } %t31, ptr %l3, !tbaa !27
  %t33 = load i64, ptr %l1, !tbaa !24
  store i64 %t33, ptr %l60, !tbaa !24
  %t34 = load i64, ptr %l60, !tbaa !24
  %t35 = icmp sge i64 %t34, 0
  br i1 %t35, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_661de3b27f7b1d1f_a886f9f6d8c58a3b)
  unreachable
bb10:
  %t37 = load i64, ptr %l60, !tbaa !24
  %t38 = icmp sle i64 %t37, 1152921504606846975
  br i1 %t38, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_7549250239c3dfbc_e6bed168a21d4f58)
  unreachable
bb12:
  %t40 = load i64, ptr %l60, !tbaa !24
  %t41 = mul i64 %t40, 8
  %t42 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t41)
  %t43 = insertvalue { i64, ptr } undef, i64 %t40, 0
  %t44 = insertvalue { i64, ptr } %t43, ptr %t42, 1
  store { i64, ptr } %t44, ptr %l4, !tbaa !27
  %t46 = call ptr @__olang_scope_hold(ptr %s0)
  %t47 = ptrtoint ptr %t46 to i64
  store i64 %t47, ptr %l64, !tbaa !24
  %t48 = load i1, ptr @olang_2esole_2ecompiler__2fdiag__2ecompiler__2fdiag__3aDiagnostics__2ewritten_2elocal_2e5
  br i1 %t48, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_7549250239c3dfbc_e6bed168a21d4f58)
  unreachable
bb14:
  %t50 = call ptr @__olang_region_make(ptr %s0)
  %t51 = ptrtoint ptr %t50 to i64
  store i64 %t51, ptr %l64, !tbaa !24
  br label %bb15
bb15:
  %t52 = load i64, ptr %l64
  %t53 = inttoptr i64 %t52 to ptr
  %t54 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t53, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t54, ptr %l66
  br label %bb16
bb16:
  %t55 = load i1, ptr @olang_2esole_2ecompiler__2fdiag__2ecompiler__2fdiag__3aDiagnostics__2ewritten_2elocal_2e5
  br i1 %t55, label %bb17, label %bb18
bb17:
  %t57 = load i64, ptr %l64
  %t58 = inttoptr i64 %t57 to ptr
  %t59 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l66, i32 0, i32 0
  %t60 = load { i64, ptr }, ptr %t59
  %t61 = extractvalue { i64, ptr } %t60, 1
  %t62 = call ptr @__olang_region_or(ptr %t61, ptr null)
  %t63 = call ptr @__olang_region_home(ptr %t62)
  %t64 = icmp ne ptr %t63, null
  %t65 = select i1 %t64, ptr %t63, ptr null
  call void @__olang_region_settle_in(ptr %t58, ptr %t65)
  br label %bb18
bb18:
  %t66 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l66
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t66, ptr %l5
  store i64 0, ptr %l6, !tbaa !24
  %t67 = load i64, ptr %l1, !tbaa !24
  store i64 %t67, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t69 = load i64, ptr %l7, !tbaa !24
  %t70 = load i64, ptr %l6, !tbaa !24
  %t73 = icmp sgt i64 %t69, %t70
  br i1 %t73, label %bb19, label %bb20
bb19:
  %t75 = load i64, ptr %l8, !tbaa !24
  %t77 = icmp sgt i64 %t75, 0
  br i1 %t77, label %bb21, label %bb22
bb20:
  store i64 0, ptr %l72, !tbaa !24
  br label %bb24
bb21:
  %t79 = load i64, ptr %l7, !tbaa !24
  %t80 = load i64, ptr %l6, !tbaa !24
  %t83 = sub i64 %t79, %t80
  %t84 = load i64, ptr %l8, !tbaa !24
  %t87 = add i64 %t83, %t84
  %t89 = sub i64 %t87, 1
  %t90 = load i64, ptr %l8, !tbaa !24
  %t93 = sdiv i64 %t89, %t90
  store i64 %t93, ptr %l75, !tbaa !24
  br label %bb23
bb22:
  store i64 0, ptr %l75, !tbaa !24
  br label %bb23
bb23:
  %t95 = load i64, ptr %l75, !tbaa !24
  store i64 %t95, ptr %l72, !tbaa !24
  br label %bb24
bb24:
  %t96 = load i64, ptr %l72, !tbaa !24
  store i64 %t96, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb25
bb25:
  %t97 = load i64, ptr %l10, !tbaa !24
  %t98 = load i64, ptr %l9, !tbaa !24
  %t101 = icmp slt i64 %t97, %t98
  %t103 = xor i1 %t101, true
  br i1 %t103, label %bb26, label %bb27
bb26:
  br label %bb110
bb27:
  br label %bb28
bb28:
  %t105 = load i64, ptr %l6, !tbaa !24
  %t106 = load i64, ptr %l10, !tbaa !24
  %t107 = load i64, ptr %l8, !tbaa !24
  %t110 = mul i64 %t106, %t107
  %t113 = add i64 %t105, %t110
  store i64 %t113, ptr %l11, !tbaa !24
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"compiler/diag:Diagnostics", ptr %t115, i32 0, i32 7
  %t118 = load i64, ptr %l11, !tbaa !24
  %t121 = call %"compiler/diag:record" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3arecord_3e_2eAt_3ccompiler_2fdiag_3arecord_3e(ptr %v0, ptr %v0, ptr %t117, i64 %t118)
  store %"compiler/diag:record" %t121, ptr %l96
  br label %bb29
bb29:
  %t122 = load %"compiler/diag:record", ptr %l96
  store %"compiler/diag:record" %t122, ptr %l12
  %t123 = load i64, ptr %l11, !tbaa !24
  %t125 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t126 = load ptr, ptr %t125, !tbaa !27
  %t127 = getelementptr i64, ptr %t126, i64 %t123
  store i64 -1, ptr %t127, !tbaa !34
  %t128 = load i64, ptr %l11, !tbaa !24
  %t130 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !27
  %t132 = getelementptr i64, ptr %t131, i64 %t128
  store i64 9223372036854775807, ptr %t132, !tbaa !34
  %t133 = getelementptr %"compiler/diag:record", ptr %l12, i32 0, i32 0
  %t134 = load { i64, [3 x i64] }, ptr %t133
  store { i64, [3 x i64] } %t134, ptr %l13
  %t136 = load { i64, [3 x i64] }, ptr %l13
  %t138 = extractvalue { i64, [3 x i64] } %t136, 0
  %t139 = icmp eq i64 %t138, 3
  br i1 %t139, label %bb30, label %bb31
bb30:
  %t141 = getelementptr { i64, [3 x i64] }, ptr %l13, i32 0, i32 1
  %t142 = getelementptr { i64, i64, i64 }, ptr %t141, i32 0, i32 0
  %t143 = load i64, ptr %t142
  store i64 %t143, ptr %l14, !tbaa !24
  %t145 = getelementptr { i64, [3 x i64] }, ptr %l13, i32 0, i32 1
  %t146 = getelementptr { i64, i64, i64 }, ptr %t145, i32 0, i32 1
  %t147 = load i64, ptr %t146
  store i64 %t147, ptr %l15, !tbaa !24
  br label %bb32
bb31:
  br label %bb34
bb32:
  %t149 = load i64, ptr %l11, !tbaa !24
  %t150 = load i64, ptr %l14, !tbaa !24
  %t153 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t154 = load ptr, ptr %t153, !tbaa !27
  %t155 = getelementptr i64, ptr %t154, i64 %t149
  store i64 %t150, ptr %t155, !tbaa !34
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t157 = load i64, ptr %l14, !tbaa !24
  %t158 = load i64, ptr %l15, !tbaa !24
  %t162 = call { i64, i64 } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2elineOf(ptr %v0, ptr %t156, i64 %t157, i64 %t158)
  store { i64, i64 } %t162, ptr %l109
  br label %bb33
bb33:
  %t163 = load { i64, i64 }, ptr %l109
  store { i64, i64 } %t163, ptr %l16
  %t164 = getelementptr { i64, i64 }, ptr %l16, i32 0, i32 0
  %t165 = load i64, ptr %t164, !tbaa !24
  %t167 = getelementptr { i64, i64 }, ptr %l16, i32 0, i32 1
  %t168 = load i64, ptr %t167, !tbaa !24
  %t170 = load i64, ptr %l11, !tbaa !24
  %t174 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t175 = load ptr, ptr %t174, !tbaa !27
  %t176 = getelementptr i64, ptr %t175, i64 %t170
  store i64 %t165, ptr %t176, !tbaa !34
  %t177 = load i64, ptr %l11, !tbaa !24
  %t178 = load i64, ptr %l15, !tbaa !24
  %t182 = sub i64 %t178, %t168
  %t184 = add i64 %t182, 1
  %t187 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t188 = load ptr, ptr %t187, !tbaa !27
  %t189 = getelementptr i64, ptr %t188, i64 %t177
  store i64 %t184, ptr %t189, !tbaa !34
  br label %bb47
bb34:
  %t190 = load { i64, [3 x i64] }, ptr %l13
  %t192 = extractvalue { i64, [3 x i64] } %t190, 0
  %t193 = icmp eq i64 %t192, 2
  br i1 %t193, label %bb35, label %bb36
bb35:
  %t195 = getelementptr { i64, [3 x i64] }, ptr %l13, i32 0, i32 1
  %t196 = getelementptr { i64, i64 }, ptr %t195, i32 0, i32 0
  %t197 = load i64, ptr %t196
  store i64 %t197, ptr %l19, !tbaa !24
  %t199 = getelementptr { i64, [3 x i64] }, ptr %l13, i32 0, i32 1
  %t200 = getelementptr { i64, i64 }, ptr %t199, i32 0, i32 1
  %t201 = load i64, ptr %t200
  store i64 %t201, ptr %l20, !tbaa !24
  br label %bb37
bb36:
  br label %bb38
bb37:
  %t203 = load i64, ptr %l11, !tbaa !24
  %t204 = load i64, ptr %l19, !tbaa !24
  %t207 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t208 = load ptr, ptr %t207, !tbaa !27
  %t209 = getelementptr i64, ptr %t208, i64 %t203
  store i64 %t204, ptr %t209, !tbaa !34
  %t210 = load i64, ptr %l11, !tbaa !24
  %t211 = load i64, ptr %l20, !tbaa !24
  %t214 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t215 = load ptr, ptr %t214, !tbaa !27
  %t216 = getelementptr i64, ptr %t215, i64 %t210
  store i64 %t211, ptr %t216, !tbaa !34
  br label %bb47
bb38:
  %t217 = load { i64, [3 x i64] }, ptr %l13
  %t219 = extractvalue { i64, [3 x i64] } %t217, 0
  %t220 = icmp eq i64 %t219, 1
  br i1 %t220, label %bb39, label %bb40
bb39:
  %t222 = getelementptr { i64, [3 x i64] }, ptr %l13, i32 0, i32 1
  %t223 = getelementptr { i64 }, ptr %t222, i32 0, i32 0
  %t224 = load i64, ptr %t223
  store i64 %t224, ptr %l21, !tbaa !24
  br label %bb41
bb40:
  br label %bb42
bb41:
  %t226 = load i64, ptr %l11, !tbaa !24
  %t227 = load i64, ptr %l21, !tbaa !24
  %t230 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t231 = load ptr, ptr %t230, !tbaa !27
  %t232 = getelementptr i64, ptr %t231, i64 %t226
  store i64 %t227, ptr %t232, !tbaa !34
  br label %bb47
bb42:
  br i1 true, label %bb43, label %bb44
bb43:
  br label %bb45
bb44:
  br label %bb46
bb45:
  br label %bb47
bb46:
  call void @__olang_check_failed(ptr @olang_loc_cc4d2c1e8d3adf92_7a1efbc027515c6)
  unreachable
bb47:
  %t233 = load ptr, ptr %l0, !tbaa !29
  %t234 = getelementptr %"compiler/diag:record", ptr %l12, i32 0, i32 4
  %t235 = load i64, ptr %t234, !tbaa !24
  %t238 = call i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2echosen(ptr %v0, ptr %t233, i64 %t235)
  store i1 %t238, ptr %l134
  br label %bb48
bb48:
  %t239 = load i1, ptr %l134, !tbaa !21
  %t240 = xor i1 %t239, true
  br i1 %t240, label %bb49, label %bb50
bb49:
  br label %bb109
bb50:
  br label %bb51
bb51:
  store i1 false, ptr %l22, !tbaa !21
  store i64 0, ptr %l23, !tbaa !24
  %t243 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l5)
  store i64 %t243, ptr %l137
  br label %bb52
bb52:
  %t244 = load i64, ptr %l137, !tbaa !24
  store i64 %t244, ptr %l24, !tbaa !24
  store i64 1, ptr %l25, !tbaa !24
  %t245 = load i64, ptr %l24, !tbaa !24
  %t246 = load i64, ptr %l23, !tbaa !24
  %t249 = icmp sgt i64 %t245, %t246
  br i1 %t249, label %bb53, label %bb54
bb53:
  %t251 = load i64, ptr %l25, !tbaa !24
  %t253 = icmp sgt i64 %t251, 0
  br i1 %t253, label %bb55, label %bb56
bb54:
  store i64 0, ptr %l141, !tbaa !24
  br label %bb58
bb55:
  %t255 = load i64, ptr %l24, !tbaa !24
  %t256 = load i64, ptr %l23, !tbaa !24
  %t259 = sub i64 %t255, %t256
  %t260 = load i64, ptr %l25, !tbaa !24
  %t263 = add i64 %t259, %t260
  %t265 = sub i64 %t263, 1
  %t266 = load i64, ptr %l25, !tbaa !24
  %t269 = sdiv i64 %t265, %t266
  store i64 %t269, ptr %l144, !tbaa !24
  br label %bb57
bb56:
  store i64 0, ptr %l144, !tbaa !24
  br label %bb57
bb57:
  %t271 = load i64, ptr %l144, !tbaa !24
  store i64 %t271, ptr %l141, !tbaa !24
  br label %bb58
bb58:
  %t272 = load i64, ptr %l141, !tbaa !24
  store i64 %t272, ptr %l26, !tbaa !24
  store i64 0, ptr %l27, !tbaa !24
  br label %bb59
bb59:
  %t273 = load i64, ptr %l27, !tbaa !24
  %t274 = load i64, ptr %l26, !tbaa !24
  %t277 = icmp slt i64 %t273, %t274
  %t279 = xor i1 %t277, true
  br i1 %t279, label %bb60, label %bb61
bb60:
  br label %bb104
bb61:
  br label %bb62
bb62:
  %t281 = load i64, ptr %l23, !tbaa !24
  %t282 = load i64, ptr %l27, !tbaa !24
  %t283 = load i64, ptr %l25, !tbaa !24
  %t286 = mul i64 %t282, %t283
  %t289 = add i64 %t281, %t286
  store i64 %t289, ptr %l28, !tbaa !24
  %t291 = load i64, ptr %l28, !tbaa !24
  %t294 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l5, i64 %t291)
  store i64 %t294, ptr %l164
  br label %bb63
bb63:
  %t295 = load i64, ptr %l164, !tbaa !24
  store i64 %t295, ptr %l29, !tbaa !24
  %t296 = load ptr, ptr %l0, !tbaa !29
  %t298 = getelementptr %"compiler/diag:Diagnostics", ptr %t296, i32 0, i32 7
  %t299 = load i64, ptr %l29, !tbaa !24
  %t302 = call %"compiler/diag:record" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3arecord_3e_2eAt_3ccompiler_2fdiag_3arecord_3e(ptr %v0, ptr %v0, ptr %t298, i64 %t299)
  store %"compiler/diag:record" %t302, ptr %l168
  br label %bb64
bb64:
  %t303 = load %"compiler/diag:record", ptr %l168
  store %"compiler/diag:record" %t303, ptr %l30
  %t304 = load i64, ptr %l29, !tbaa !24
  %t306 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t307 = load ptr, ptr %t306, !tbaa !27
  %t308 = getelementptr i64, ptr %t307, i64 %t304
  %t309 = load i64, ptr %t308, !tbaa !34
  %t310 = load i64, ptr %l11, !tbaa !24
  %t312 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t313 = load ptr, ptr %t312, !tbaa !27
  %t314 = getelementptr i64, ptr %t313, i64 %t310
  %t315 = load i64, ptr %t314, !tbaa !34
  %t318 = icmp eq i64 %t309, %t315
  br i1 %t318, label %bb65, label %bb66
bb65:
  %t320 = load i64, ptr %l29, !tbaa !24
  %t322 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t323 = load ptr, ptr %t322, !tbaa !27
  %t324 = getelementptr i64, ptr %t323, i64 %t320
  %t325 = load i64, ptr %t324, !tbaa !34
  %t326 = load i64, ptr %l11, !tbaa !24
  %t328 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t329 = load ptr, ptr %t328, !tbaa !27
  %t330 = getelementptr i64, ptr %t329, i64 %t326
  %t331 = load i64, ptr %t330, !tbaa !34
  %t334 = icmp eq i64 %t325, %t331
  store i1 %t334, ptr %l174, !tbaa !21
  br label %bb67
bb66:
  store i1 false, ptr %l174, !tbaa !21
  br label %bb67
bb67:
  %t336 = load i1, ptr %l174, !tbaa !21
  br i1 %t336, label %bb68, label %bb69
bb68:
  %t337 = load i64, ptr %l29, !tbaa !24
  %t339 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t340 = load ptr, ptr %t339, !tbaa !27
  %t341 = getelementptr i64, ptr %t340, i64 %t337
  %t342 = load i64, ptr %t341, !tbaa !34
  %t343 = load i64, ptr %l11, !tbaa !24
  %t345 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t346 = load ptr, ptr %t345, !tbaa !27
  %t347 = getelementptr i64, ptr %t346, i64 %t343
  %t348 = load i64, ptr %t347, !tbaa !34
  %t351 = icmp eq i64 %t342, %t348
  store i1 %t351, ptr %l180, !tbaa !21
  br label %bb70
bb69:
  store i1 false, ptr %l180, !tbaa !21
  br label %bb70
bb70:
  %t353 = load i1, ptr %l180, !tbaa !21
  br i1 %t353, label %bb71, label %bb72
bb71:
  %t354 = getelementptr %"compiler/diag:record", ptr %l30, i32 0, i32 2
  %t355 = load { i64, ptr }, ptr %t354, !tbaa !27
  %t356 = getelementptr %"compiler/diag:record", ptr %l12, i32 0, i32 2
  %t357 = load { i64, ptr }, ptr %t356, !tbaa !27
  %t360 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v0, { i64, ptr } %t355, { i64, ptr } %t357)
  store i1 %t360, ptr %l189
  br label %bb73
bb72:
  store i1 false, ptr %l186, !tbaa !21
  br label %bb74
bb73:
  %t361 = load i1, ptr %l189, !tbaa !21
  store i1 %t361, ptr %l186, !tbaa !21
  br label %bb74
bb74:
  %t362 = load i1, ptr %l186, !tbaa !21
  br i1 %t362, label %bb75, label %bb76
bb75:
  store i1 true, ptr %l22, !tbaa !21
  %t363 = load i64, ptr %l29, !tbaa !24
  %t365 = load ptr, ptr %l0, !tbaa !29
  %t367 = getelementptr %"compiler/diag:Diagnostics", ptr %t365, i32 0, i32 16
  %t371 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %v0, ptr %t367, i64 %t363)
  store i1 %t371, ptr %l194
  br label %bb77
bb76:
  br label %bb86
bb77:
  %t372 = load i1, ptr %l194, !tbaa !21
  br i1 %t372, label %bb78, label %bb79
bb78:
  %t373 = load i64, ptr %l11, !tbaa !24
  %t375 = load ptr, ptr %l0, !tbaa !29
  %t377 = getelementptr %"compiler/diag:Diagnostics", ptr %t375, i32 0, i32 16
  %t381 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %v0, ptr %t377, i64 %t373)
  store i1 %t381, ptr %l200
  br label %bb80
bb79:
  store i1 false, ptr %l195, !tbaa !21
  br label %bb81
bb80:
  %t382 = load i1, ptr %l200, !tbaa !21
  %t383 = xor i1 %t382, true
  store i1 %t383, ptr %l195, !tbaa !21
  br label %bb81
bb81:
  %t385 = load i1, ptr %l195, !tbaa !21
  br i1 %t385, label %bb82, label %bb83
bb82:
  %t386 = load i64, ptr %l28, !tbaa !24
  %t387 = load i64, ptr %l11, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %s0, ptr %l5, i64 %t386, i64 %t387)
  br label %bb84
bb83:
  br label %bb85
bb84:
  br label %bb85
bb85:
  br label %bb86
bb86:
  %t391 = getelementptr %"compiler/diag:record", ptr %l12, i32 0, i32 5
  %t392 = load i1, ptr %t391, !tbaa !21
  br i1 %t392, label %bb87, label %bb88
bb87:
  %t394 = getelementptr %"compiler/diag:record", ptr %l30, i32 0, i32 5
  %t395 = load i1, ptr %t394, !tbaa !21
  store i1 %t395, ptr %l206, !tbaa !21
  br label %bb89
bb88:
  store i1 false, ptr %l206, !tbaa !21
  br label %bb89
bb89:
  %t397 = load i1, ptr %l206, !tbaa !21
  br i1 %t397, label %bb90, label %bb91
bb90:
  %t398 = getelementptr %"compiler/diag:record", ptr %l30, i32 0, i32 3
  %t399 = load i32, ptr %t398, !range !{i32 0, i32 949}
  store i32 %t399, ptr %l209
  %t400 = getelementptr %"compiler/diag:record", ptr %l12, i32 0, i32 3
  %t401 = load i32, ptr %t400, !range !{i32 0, i32 949}
  store i32 %t401, ptr %l211
  %t404 = call i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2fmsgs_3aDiag(ptr %l209, ptr %l211)
  store i1 %t404, ptr %l213
  br label %bb92
bb91:
  store i1 false, ptr %l208, !tbaa !21
  br label %bb93
bb92:
  %t405 = load i1, ptr %l213, !tbaa !21
  store i1 %t405, ptr %l208, !tbaa !21
  br label %bb93
bb93:
  %t406 = load i1, ptr %l208, !tbaa !21
  br i1 %t406, label %bb94, label %bb95
bb94:
  %t407 = load i64, ptr %l29, !tbaa !24
  %t409 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t410 = load ptr, ptr %t409, !tbaa !27
  %t411 = getelementptr i64, ptr %t410, i64 %t407
  %t412 = load i64, ptr %t411, !tbaa !34
  %t413 = load i64, ptr %l11, !tbaa !24
  %t415 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t416 = load ptr, ptr %t415, !tbaa !27
  %t417 = getelementptr i64, ptr %t416, i64 %t413
  %t418 = load i64, ptr %t417, !tbaa !34
  %t421 = icmp eq i64 %t412, %t418
  store i1 %t421, ptr %l214, !tbaa !21
  br label %bb96
bb95:
  store i1 false, ptr %l214, !tbaa !21
  br label %bb96
bb96:
  %t423 = load i1, ptr %l214, !tbaa !21
  br i1 %t423, label %bb97, label %bb98
bb97:
  %t424 = load i64, ptr %l29, !tbaa !24
  %t426 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t427 = load ptr, ptr %t426, !tbaa !27
  %t428 = getelementptr i64, ptr %t427, i64 %t424
  %t429 = load i64, ptr %t428, !tbaa !34
  %t430 = load i64, ptr %l11, !tbaa !24
  %t432 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t433 = load ptr, ptr %t432, !tbaa !27
  %t434 = getelementptr i64, ptr %t433, i64 %t430
  %t435 = load i64, ptr %t434, !tbaa !34
  %t438 = icmp eq i64 %t429, %t435
  store i1 %t438, ptr %l220, !tbaa !21
  br label %bb99
bb98:
  store i1 false, ptr %l220, !tbaa !21
  br label %bb99
bb99:
  %t440 = load i1, ptr %l220, !tbaa !21
  br i1 %t440, label %bb100, label %bb101
bb100:
  store i1 true, ptr %l22, !tbaa !21
  br label %bb102
bb101:
  br label %bb102
bb102:
  br label %bb103
bb103:
  %t441 = load i64, ptr %l27, !tbaa !24
  %t444 = add i64 %t441, 1
  store i64 %t444, ptr %l27, !tbaa !24
  br label %bb59
bb104:
  %t446 = load i1, ptr %l22, !tbaa !21
  %t448 = xor i1 %t446, true
  br i1 %t448, label %bb105, label %bb106
bb105:
  %t450 = load i64, ptr %l11, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l5, i64 %t450)
  br label %bb107
bb106:
  br label %bb108
bb107:
  br label %bb108
bb108:
  br label %bb109
bb109:
  %t453 = load i64, ptr %l10, !tbaa !24
  %t456 = add i64 %t453, 1
  store i64 %t456, ptr %l10, !tbaa !24
  br label %bb25
bb110:
  %t458 = load ptr, ptr %l0, !tbaa !29
  %t460 = getelementptr %"compiler/diag:Diagnostics", ptr %t458, i32 0, i32 17
  %t462 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t460)
  store i64 %t462, ptr %l238
  br label %bb111
bb111:
  %t463 = load i64, ptr %l238, !tbaa !24
  %t464 = icmp sgt i64 %t463, 0
  br i1 %t464, label %bb112, label %bb113
bb112:
  store i1 false, ptr %l33, !tbaa !21
  store ptr %l5, ptr %l34, !tbaa !29
  store i64 0, ptr %l35, !tbaa !24
  br label %bb114
bb113:
  br label %bb157
bb114:
  %t467 = load i64, ptr %l35, !tbaa !24
  store i64 %t467, ptr %l241, !tbaa !24
  %t468 = load ptr, ptr %l34, !tbaa !29
  %t470 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t468)
  store i64 %t470, ptr %l243
  br label %bb115
bb115:
  %t471 = load i64, ptr %l241, !tbaa !24
  %t472 = load i64, ptr %l243, !tbaa !24
  %t473 = icmp slt i64 %t471, %t472
  %t475 = xor i1 %t473, true
  br i1 %t475, label %bb116, label %bb117
bb116:
  br label %bb125
bb117:
  br label %bb118
bb118:
  %t477 = load ptr, ptr %l34, !tbaa !29
  %t478 = load i64, ptr %l35, !tbaa !24
  %t481 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t477, i64 %t478)
  store i64 %t481, ptr %l248
  br label %bb119
bb119:
  %t482 = load i64, ptr %l248, !tbaa !24
  store i64 %t482, ptr %l36, !tbaa !24
  %t483 = load i1, ptr %l33, !tbaa !21
  br i1 %t483, label %bb120, label %bb121
bb120:
  store i1 true, ptr %l250, !tbaa !21
  br label %bb123
bb121:
  %t485 = load i64, ptr %l36, !tbaa !24
  %t487 = load ptr, ptr %l0, !tbaa !29
  %t489 = getelementptr %"compiler/diag:Diagnostics", ptr %t487, i32 0, i32 17
  %t493 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %v0, ptr %t489, i64 %t485)
  store i1 %t493, ptr %l255
  br label %bb122
bb122:
  %t494 = load i1, ptr %l255, !tbaa !21
  %t495 = xor i1 %t494, true
  store i1 %t495, ptr %l250, !tbaa !21
  br label %bb123
bb123:
  %t497 = load i1, ptr %l250, !tbaa !21
  store i1 %t497, ptr %l33, !tbaa !21
  br label %bb124
bb124:
  %t498 = load i64, ptr %l35, !tbaa !24
  %t501 = add i64 %t498, 1
  store i64 %t501, ptr %l35, !tbaa !24
  br label %bb114
bb125:
  %t503 = load i1, ptr %l33, !tbaa !21
  br i1 %t503, label %bb126, label %bb127
bb126:
  %t505 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t505, ptr %l261
  br label %bb128
bb127:
  br label %bb156
bb128:
  %t506 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 32, i64 8)
  store ptr %t506, ptr %lp38
  %t507 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l261
  %t508 = load ptr, ptr %lp38
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t507, ptr %t508
  store ptr %l5, ptr %l39, !tbaa !29
  store i64 0, ptr %l40, !tbaa !24
  br label %bb129
bb129:
  %t510 = load i64, ptr %l40, !tbaa !24
  store i64 %t510, ptr %l263, !tbaa !24
  %t511 = load ptr, ptr %l39, !tbaa !29
  %t513 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t511)
  store i64 %t513, ptr %l265
  br label %bb130
bb130:
  %t514 = load i64, ptr %l263, !tbaa !24
  %t515 = load i64, ptr %l265, !tbaa !24
  %t516 = icmp slt i64 %t514, %t515
  %t518 = xor i1 %t516, true
  br i1 %t518, label %bb131, label %bb132
bb131:
  br label %bb141
bb132:
  br label %bb133
bb133:
  %t520 = load ptr, ptr %l39, !tbaa !29
  %t521 = load i64, ptr %l40, !tbaa !24
  %t524 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t520, i64 %t521)
  store i64 %t524, ptr %l270
  br label %bb134
bb134:
  %t525 = load i64, ptr %l270, !tbaa !24
  store i64 %t525, ptr %l41, !tbaa !24
  %t526 = load i64, ptr %l41, !tbaa !24
  %t528 = load ptr, ptr %l0, !tbaa !29
  %t530 = getelementptr %"compiler/diag:Diagnostics", ptr %t528, i32 0, i32 17
  %t534 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %v0, ptr %t530, i64 %t526)
  store i1 %t534, ptr %l275
  br label %bb135
bb135:
  %t535 = load i1, ptr %l275, !tbaa !21
  %t536 = xor i1 %t535, true
  br i1 %t536, label %bb136, label %bb137
bb136:
  %t538 = load ptr, ptr %lp38
  %t539 = load i64, ptr %l41, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %t538, i64 %t539)
  br label %bb138
bb137:
  br label %bb139
bb138:
  br label %bb139
bb139:
  br label %bb140
bb140:
  %t542 = load i64, ptr %l40, !tbaa !24
  %t545 = add i64 %t542, 1
  store i64 %t545, ptr %l40, !tbaa !24
  br label %bb129
bb141:
  %t547 = call ptr @__olang_scope_hold(ptr %s0)
  %t548 = ptrtoint ptr %t547 to i64
  store i64 %t548, ptr %l282, !tbaa !24
  %t549 = load i1, ptr @olang_2esole_2ecompiler__2fdiag__2ecompiler__2fdiag__3aDiagnostics__2ewritten_2elocal_2e5
  br i1 %t549, label %bb142, label %bb143
bb142:
  %t551 = call ptr @__olang_region_make(ptr %s0)
  %t552 = ptrtoint ptr %t551 to i64
  store i64 %t552, ptr %l282, !tbaa !24
  br label %bb143
bb143:
  %t553 = load ptr, ptr %lp38
  %t554 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t553
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t554, ptr %l285
  %t556 = load i64, ptr %l282
  %t557 = inttoptr i64 %t556 to ptr
  %t558 = call ptr @__olang_scope_hold(ptr %t557)
  %t559 = ptrtoint ptr %t558 to i64
  store i64 %t559, ptr %l286, !tbaa !24
  %t560 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t560, label %bb144, label %bb145
bb144:
  %t562 = load i64, ptr %l282
  %t563 = inttoptr i64 %t562 to ptr
  %t564 = call ptr @__olang_region_make_part(ptr %t563)
  %t565 = ptrtoint ptr %t564 to i64
  store i64 %t565, ptr %l286, !tbaa !24
  br label %bb145
bb145:
  %t566 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l285, i32 0, i32 0
  %t567 = load { i64, ptr }, ptr %t566, !tbaa !27
  store { i64, ptr } %t567, ptr %l288, !tbaa !27
  %t568 = load { i64, ptr }, ptr %l288, !tbaa !27
  %t569 = extractvalue { i64, ptr } %t568, 0
  store i64 %t569, ptr %l289, !tbaa !24
  %t570 = load i64, ptr %l289, !tbaa !24
  %t571 = mul i64 %t570, 8
  %t572 = load i64, ptr %l286
  %t573 = inttoptr i64 %t572 to ptr
  %t574 = call ptr @__olang_held_alloc(ptr %t573, i64 %t571)
  %t575 = insertvalue { i64, ptr } undef, i64 %t570, 0
  %t576 = insertvalue { i64, ptr } %t575, ptr %t574, 1
  store { i64, ptr } %t576, ptr %l290, !tbaa !27
  %t577 = getelementptr { i64, ptr }, ptr %l290, i32 0, i32 1
  %t578 = load ptr, ptr %t577, !tbaa !27
  %t579 = getelementptr { i64, ptr }, ptr %l288, i32 0, i32 1
  %t580 = load ptr, ptr %t579, !tbaa !27
  %t581 = load i64, ptr %l289, !tbaa !24
  %t582 = mul i64 %t581, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t578, ptr %t580, i64 %t582, i1 false)
  %t583 = load { i64, ptr }, ptr %l290, !tbaa !27
  %t584 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l285, i32 0, i32 0
  store { i64, ptr } %t583, ptr %t584, !tbaa !27
  %t585 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t585, label %bb146, label %bb147
bb146:
  %t587 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l285, i32 0, i32 0
  %t588 = load { i64, ptr }, ptr %t587, !tbaa !27
  %t589 = extractvalue { i64, ptr } %t588, 0
  %t591 = icmp eq i64 %t589, 0
  br i1 %t591, label %bb148, label %bb149
bb147:
  %t593 = load i1, ptr @olang_2esole_2ecompiler__2fdiag__2ecompiler__2fdiag__3aDiagnostics__2ewritten_2elocal_2e5
  br i1 %t593, label %bb150, label %bb151
bb148:
  %t595 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l285, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t595, !tbaa !27
  br label %bb149
bb149:
  %t596 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l285, i32 0, i32 0
  %t597 = load i64, ptr %l286
  %t598 = inttoptr i64 %t597 to ptr
  %t599 = load { i64, ptr }, ptr %t596
  %t600 = extractvalue { i64, ptr } %t599, 1
  %t601 = call ptr @__olang_region_or(ptr %t600, ptr null)
  %t602 = icmp ne ptr %t601, null
  %t603 = select i1 %t602, ptr %t601, ptr null
  call void @__olang_region_settle_in(ptr %t598, ptr %t603)
  br label %bb147
bb150:
  %t604 = load i64, ptr %l282
  %t605 = inttoptr i64 %t604 to ptr
  %t606 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l285, i32 0, i32 0
  %t607 = load { i64, ptr }, ptr %t606
  %t608 = extractvalue { i64, ptr } %t607, 1
  %t609 = call ptr @__olang_region_or(ptr %t608, ptr null)
  %t610 = call ptr @__olang_region_home(ptr %t609)
  %t611 = icmp ne ptr %t610, null
  %t612 = select i1 %t611, ptr %t610, ptr null
  call void @__olang_region_settle_in(ptr %t605, ptr %t612)
  br label %bb151
bb151:
  %t613 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t613, ptr %l295
  %t614 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l285
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t614, ptr %l5
  %t615 = load i1, ptr @olang_2esole_2ecompiler__2fdiag__2ecompiler__2fdiag__3aDiagnostics__2ewritten_2elocal_2e5
  br i1 %t615, label %bb152, label %bb153
bb152:
  %t617 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l295, i32 0, i32 0
  %t618 = load { i64, ptr }, ptr %t617
  %t619 = extractvalue { i64, ptr } %t618, 1
  %t620 = call ptr @__olang_region_or(ptr %t619, ptr null)
  %t621 = call ptr @__olang_region_home(ptr %t620)
  %t622 = icmp ne ptr %t621, null
  %t623 = select i1 %t622, ptr %t621, ptr null
  call void @__olang_region_drop(ptr %t623)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %l295
  br label %bb153
bb153:
  %t624 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t624, label %bb154, label %bb155
bb154:
  %t626 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l295, i32 0, i32 0
  %t627 = load { i64, ptr }, ptr %t626
  %t628 = extractvalue { i64, ptr } %t627, 0
  %t629 = extractvalue { i64, ptr } %t627, 1
  call void @__olang_region_release_part(ptr %t629, i64 %t628)
  store { i64, ptr } zeroinitializer, ptr %t626
  br label %bb155
bb155:
  br label %bb156
bb156:
  br label %bb157
bb157:
  %t630 = load ptr, ptr %l0, !tbaa !29
  %t632 = getelementptr %"compiler/diag:Diagnostics", ptr %t630, i32 0, i32 1
  %t634 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t632)
  store i64 %t634, ptr %l300
  br label %bb158
bb158:
  %t635 = load i64, ptr %l300, !tbaa !24
  %t636 = add i64 %t635, 1
  store i64 %t636, ptr %l301, !tbaa !24
  %t637 = load i64, ptr %l301, !tbaa !24
  %t638 = icmp sge i64 %t637, 0
  br i1 %t638, label %bb159, label %bb160
bb159:
  %t640 = load i64, ptr %l301, !tbaa !24
  %t641 = icmp sle i64 %t640, 1152921504606846975
  br i1 %t641, label %bb161, label %bb162
bb160:
  call void @__olang_check_failed(ptr @olang_loc_c2f4506e7327945e_f97af0abefd7d9d2)
  unreachable
bb161:
  %t643 = load i64, ptr %l301, !tbaa !24
  %t644 = mul i64 %t643, 8
  %t645 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t644)
  store i64 0, ptr %t646
  br label %fill.647
fill.647:
  %t650 = load i64, ptr %t646
  %t651 = icmp slt i64 %t650, %t643
  br i1 %t651, label %fillb.648, label %filld.649
fillb.648:
  %t652 = getelementptr i64, ptr %t645, i64 %t650
  store i64 -1, ptr %t652
  %t653 = add i64 %t650, 1
  store i64 %t653, ptr %t646
  br label %fill.647
filld.649:
  %t654 = insertvalue { i64, ptr } undef, i64 %t643, 0
  %t655 = insertvalue { i64, ptr } %t654, ptr %t645, 1
  store { i64, ptr } %t655, ptr %l43, !tbaa !27
  store i64 0, ptr %l44, !tbaa !24
  store ptr %l5, ptr %l45, !tbaa !29
  store i64 0, ptr %l46, !tbaa !24
  br label %bb163
bb162:
  call void @__olang_check_failed(ptr @olang_loc_c2f4506e7327945e_f97af0abefd7d9d2)
  unreachable
bb163:
  %t658 = load i64, ptr %l46, !tbaa !24
  store i64 %t658, ptr %l306, !tbaa !24
  %t659 = load ptr, ptr %l45, !tbaa !29
  %t661 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t659)
  store i64 %t661, ptr %l308
  br label %bb164
bb164:
  %t662 = load i64, ptr %l306, !tbaa !24
  %t663 = load i64, ptr %l308, !tbaa !24
  %t664 = icmp slt i64 %t662, %t663
  %t666 = xor i1 %t664, true
  br i1 %t666, label %bb165, label %bb166
bb165:
  br label %bb173
bb166:
  br label %bb167
bb167:
  %t668 = load ptr, ptr %l45, !tbaa !29
  %t669 = load i64, ptr %l46, !tbaa !24
  %t672 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t668, i64 %t669)
  store i64 %t672, ptr %l313
  br label %bb168
bb168:
  %t673 = load i64, ptr %l313, !tbaa !24
  store i64 %t673, ptr %l47, !tbaa !24
  %t674 = load i64, ptr %l47, !tbaa !24
  %t676 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t677 = load ptr, ptr %t676, !tbaa !27
  %t678 = getelementptr i64, ptr %t677, i64 %t674
  %t679 = load i64, ptr %t678, !tbaa !34
  %t681 = add i64 %t679, 1
  %t683 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t684 = load ptr, ptr %t683, !tbaa !27
  %t685 = getelementptr i64, ptr %t684, i64 %t681
  %t686 = load i64, ptr %t685, !tbaa !34
  %t688 = icmp slt i64 %t686, 0
  br i1 %t688, label %bb169, label %bb170
bb169:
  %t690 = load i64, ptr %l47, !tbaa !24
  %t692 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t693 = load ptr, ptr %t692, !tbaa !27
  %t694 = getelementptr i64, ptr %t693, i64 %t690
  %t695 = load i64, ptr %t694, !tbaa !34
  %t697 = add i64 %t695, 1
  %t698 = load i64, ptr %l44, !tbaa !24
  %t701 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t702 = load ptr, ptr %t701, !tbaa !27
  %t703 = getelementptr i64, ptr %t702, i64 %t697
  store i64 %t698, ptr %t703, !tbaa !34
  %t704 = load i64, ptr %l44, !tbaa !24
  %t707 = add i64 %t704, 1
  store i64 %t707, ptr %l44, !tbaa !24
  br label %bb171
bb170:
  br label %bb171
bb171:
  br label %bb172
bb172:
  %t709 = load i64, ptr %l46, !tbaa !24
  %t712 = add i64 %t709, 1
  store i64 %t712, ptr %l46, !tbaa !24
  br label %bb163
bb173:
  %t715 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %s0, ptr %s0, ptr %l5)
  store { i64, ptr } %t715, ptr %l330
  br label %bb174
bb174:
  %t716 = load { i64, ptr }, ptr %l330, !tbaa !27
  store { i64, ptr } %t716, ptr %l48, !tbaa !27
  %t717 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t718 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t719 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t720 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t721 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr }, ptr null, i32 1
  %t722 = ptrtoint ptr %t721 to i64
  %t724 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr }, ptr %t723, i32 0, i32 0
  store { i64, ptr } %t718, ptr %t724, !tbaa !28
  %t726 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr }, ptr %t723, i32 0, i32 1
  store { i64, ptr } %t719, ptr %t726, !tbaa !28
  %t728 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr }, ptr %t723, i32 0, i32 2
  store { i64, ptr } %t720, ptr %t728, !tbaa !28
  call void @__olang_scope_escape(ptr %s0)
  %t730 = call ptr @__olang_scope_hold(ptr %s0)
  %t731 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr }, ptr %t723, i32 0, i32 3
  store ptr %t730, ptr %t731, !tbaa !28
  call void @__olang_scope_escape(ptr %s0)
  %t732 = call ptr @__olang_scope_hold(ptr %s0)
  %t733 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr }, ptr %t723, i32 0, i32 4
  store ptr %t732, ptr %t733, !tbaa !28
  call void @__olang_scope_escape(ptr %s0)
  %t734 = call ptr @__olang_scope_hold(ptr %s0)
  %t735 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr }, ptr %t723, i32 0, i32 5
  store ptr %t734, ptr %t735, !tbaa !28
  %t736 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_54, 0
  %t737 = insertvalue { ptr, ptr } %t736, ptr %t723, 1
  %t740 = extractvalue { ptr, ptr } %t737, 0
  %t741 = extractvalue { ptr, ptr } %t737, 1
  call void @std_2fprelude_2farray_2eArray_3cI64_3e_2eSort_3cI64_2c_20_3f_3e(ptr %s0, ptr %s0, { i64, ptr } %t717, ptr %t740, ptr %t741)
  br label %bb175
bb175:
  %t742 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t742, ptr %l337, !tbaa !27
  %t744 = load { i64, ptr }, ptr %l337, !tbaa !27
  %t745 = extractvalue { i64, ptr } %t744, 0
  store i64 %t745, ptr %l338, !tbaa !24
  %t746 = load i64, ptr %l338, !tbaa !24
  %t747 = mul i64 %t746, 8
  %t748 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t747)
  %t749 = insertvalue { i64, ptr } undef, i64 %t746, 0
  %t750 = insertvalue { i64, ptr } %t749, ptr %t748, 1
  store { i64, ptr } %t750, ptr %l339, !tbaa !27
  %t751 = getelementptr { i64, ptr }, ptr %l339, i32 0, i32 1
  %t752 = load ptr, ptr %t751, !tbaa !27
  %t753 = getelementptr { i64, ptr }, ptr %l337, i32 0, i32 1
  %t754 = load ptr, ptr %t753, !tbaa !27
  %t755 = load i64, ptr %l338, !tbaa !24
  %t756 = mul i64 %t755, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t752, ptr %t754, i64 %t756, i1 false)
  %t757 = load { i64, ptr }, ptr %l339, !tbaa !27
  store { i64, ptr } %t757, ptr %l337, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t758 = load { i64, ptr }, ptr %l337, !tbaa !27
  store { i64, ptr } %t758, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fdiag_2econtinues(i8 %a0) #0 {
entry:
  %l0 = alloca i8
  %l4 = alloca i1
  %rv = alloca i1
  store i8 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i8, ptr %l0, !tbaa !22
  %t4 = icmp uge i8 %t1, -128
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = load i8, ptr %l0, !tbaa !22
  %t9 = icmp ult i8 %t6, -64
  store i1 %t9, ptr %l4, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l4, !tbaa !21
  store i1 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fdiag_2eisScopeRule(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l4 = alloca i1
  %l5 = alloca { i64, ptr }
  %l8 = alloca i1
  %l9 = alloca { i64, ptr }
  %l11 = alloca i1
  %l14 = alloca i1
  %l15 = alloca i1
  %l17 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp sge i64 %t3, 2
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t7, ptr %l5, !tbaa !27
  %t8 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !27
  %t10 = getelementptr i8, ptr %t9, i64 0
  %t11 = load i8, ptr %t10, !tbaa !32
  %t13 = icmp eq i8 %t11, 79
  store i1 %t13, ptr %l4, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb3
bb3:
  %t15 = load i1, ptr %l4, !tbaa !21
  br i1 %t15, label %bb4, label %bb5
bb4:
  %t16 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t16, ptr %l9, !tbaa !27
  %t17 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !27
  %t19 = getelementptr i8, ptr %t18, i64 1
  %t20 = load i8, ptr %t19, !tbaa !32
  %t22 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t20)
  store i1 %t22, ptr %l11
  br label %bb6
bb5:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb7
bb6:
  %t23 = load i1, ptr %l11, !tbaa !21
  store i1 %t23, ptr %l8, !tbaa !21
  br label %bb7
bb7:
  %t24 = load i1, ptr %l8, !tbaa !21
  br i1 %t24, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t26 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t28 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t26, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d55, i32 0, i32 1) })
  store i1 %t28, ptr %l14
  br label %bb11
bb11:
  %t29 = load i1, ptr %l14, !tbaa !21
  br i1 %t29, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb15
bb13:
  %t30 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t32 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t30, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d56, i32 0, i32 1) })
  store i1 %t32, ptr %l17
  br label %bb14
bb14:
  %t33 = load i1, ptr %l17, !tbaa !21
  store i1 %t33, ptr %l15, !tbaa !21
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s0)
  %t34 = load i1, ptr %l15, !tbaa !21
  store i1 %t34, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i8 @compiler_2fdiag_2eprintable(i8 %a0) #0 {
entry:
  %l0 = alloca i8
  %l7 = alloca i1
  %rv = alloca i8
  store i8 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i8, ptr %l0, !tbaa !22
  %t3 = icmp eq i8 %t1, 9
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i8, ptr %l0, !tbaa !22
  store i8 %t5, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t7 = load i8, ptr %l0, !tbaa !22
  %t10 = icmp ult i8 %t7, 32
  br i1 %t10, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb6
bb5:
  %t12 = load i8, ptr %l0, !tbaa !22
  %t15 = icmp eq i8 %t12, 127
  store i1 %t15, ptr %l7, !tbaa !21
  br label %bb6
bb6:
  %t17 = load i1, ptr %l7, !tbaa !21
  br i1 %t17, label %bb7, label %bb8
bb7:
  store i8 63, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t19 = load i8, ptr %l0, !tbaa !22
  store i8 %t19, ptr %rv
  br label %ret
ret:
  %rr = load i8, ptr %rv
  ret i8 %rr
}

define dso_local { i64, ptr } @compiler_2fdiag_2eruleIdAt(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l4 = alloca i1
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l15 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %l27 = alloca i1
  %l29 = alloca i1
  %l31 = alloca i1
  %l32 = alloca { i64, ptr }
  %l34 = alloca i1
  %l36 = alloca i1
  %l37 = alloca { i64, ptr }
  %l39 = alloca i1
  %l41 = alloca { i64, ptr }
  %l42 = alloca i64
  %l51 = alloca i1
  %l52 = alloca { i64, ptr }
  %l55 = alloca i1
  %l64 = alloca i1
  %l65 = alloca { i64, ptr }
  %l68 = alloca i1
  %l73 = alloca { i64, ptr }
  %l74 = alloca i64
  %l77 = alloca i64
  %l78 = alloca i64
  %l83 = alloca i1
  %l85 = alloca i1
  %l86 = alloca { i64, ptr }
  %l87 = alloca i64
  %l90 = alloca i64
  %l91 = alloca i64
  %l96 = alloca i1
  %l98 = alloca { i64, ptr }
  %l99 = alloca i64
  %l104 = alloca { i64, ptr }
  %l105 = alloca i64
  %l106 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d57, i32 0, i32 1) })
  store i1 %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = load i1, ptr %l4, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  %t5 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t5, ptr %l6, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t6, 0
  store i64 %t9, ptr %l9, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t10, 0
  store i64 %t11, ptr %l10, !tbaa !24
  %t12 = icmp sge i64 2, 0
  br i1 %t12, label %bb4, label %bb5
bb3:
  %t14 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t14, ptr %l15, !tbaa !27
  %t15 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t15, 0
  store i64 %t18, ptr %l18, !tbaa !24
  %t19 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t19, 0
  store i64 %t20, ptr %l19, !tbaa !24
  %t21 = icmp sge i64 0, 0
  br i1 %t21, label %bb10, label %bb11
bb4:
  %t23 = load i64, ptr %l9, !tbaa !24
  %t24 = icmp sle i64 2, %t23
  br i1 %t24, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_122ae7ff15fe68f_4bf017428e5c5a9b)
  unreachable
bb6:
  %t26 = load i64, ptr %l9, !tbaa !24
  %t27 = load i64, ptr %l10, !tbaa !24
  %t28 = icmp sle i64 %t26, %t27
  br i1 %t28, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_122ae7ff15fe68f_4bf017428e5c5a9b)
  unreachable
bb8:
  %t30 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !27
  %t32 = load i64, ptr %l9, !tbaa !24
  %t33 = getelementptr i8, ptr %t31, i64 2
  %t34 = sub i64 %t32, 2
  %t35 = insertvalue { i64, ptr } undef, i64 %t34, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr %t33, 1
  store { i64, ptr } %t36, ptr %l5, !tbaa !27
  br label %bb16
bb9:
  call void @__olang_check_failed(ptr @olang_loc_122ae7ff15fe68f_4bf017428e5c5a9b)
  unreachable
bb10:
  %t38 = load i64, ptr %l18, !tbaa !24
  %t39 = icmp sle i64 0, %t38
  br i1 %t39, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_122ae7ff15fe68f_4bf017428e5c5a9b)
  unreachable
bb12:
  %t41 = load i64, ptr %l18, !tbaa !24
  %t42 = load i64, ptr %l19, !tbaa !24
  %t43 = icmp sle i64 %t41, %t42
  br i1 %t43, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_122ae7ff15fe68f_4bf017428e5c5a9b)
  unreachable
bb14:
  %t45 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !27
  %t47 = load i64, ptr %l18, !tbaa !24
  %t48 = getelementptr i8, ptr %t46, i64 0
  %t49 = sub i64 %t47, 0
  %t50 = insertvalue { i64, ptr } undef, i64 %t49, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t48, 1
  store { i64, ptr } %t51, ptr %l5, !tbaa !27
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_122ae7ff15fe68f_4bf017428e5c5a9b)
  unreachable
bb16:
  %t53 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t53, ptr %l1, !tbaa !27
  %t54 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t56 = extractvalue { i64, ptr } %t54, 0
  %t58 = icmp slt i64 %t56, 4
  br i1 %t58, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb20
bb18:
  %t60 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t62 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t60, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d58, i32 0, i32 1) })
  store i1 %t62, ptr %l29
  br label %bb19
bb19:
  %t63 = load i1, ptr %l29, !tbaa !21
  %t64 = xor i1 %t63, true
  store i1 %t64, ptr %l27, !tbaa !21
  br label %bb20
bb20:
  %t66 = load i1, ptr %l27, !tbaa !21
  br i1 %t66, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l31, !tbaa !21
  br label %bb24
bb22:
  %t67 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t67, ptr %l32, !tbaa !27
  %t68 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !27
  %t70 = getelementptr i8, ptr %t69, i64 2
  %t71 = load i8, ptr %t70, !tbaa !32
  %t73 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %t71)
  store i1 %t73, ptr %l34
  br label %bb23
bb23:
  %t74 = load i1, ptr %l34, !tbaa !21
  %t75 = xor i1 %t74, true
  store i1 %t75, ptr %l31, !tbaa !21
  br label %bb24
bb24:
  %t77 = load i1, ptr %l31, !tbaa !21
  br i1 %t77, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l36, !tbaa !21
  br label %bb28
bb26:
  %t78 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t78, ptr %l37, !tbaa !27
  %t79 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = getelementptr i8, ptr %t80, i64 3
  %t82 = load i8, ptr %t81, !tbaa !32
  %t84 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t82)
  store i1 %t84, ptr %l39
  br label %bb27
bb27:
  %t85 = load i1, ptr %l39, !tbaa !21
  %t86 = xor i1 %t85, true
  store i1 %t86, ptr %l36, !tbaa !21
  br label %bb28
bb28:
  %t88 = load i1, ptr %l36, !tbaa !21
  br i1 %t88, label %bb29, label %bb30
bb29:
  %t89 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t89, ptr %l41, !tbaa !27
  %t90 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t91 = extractvalue { i64, ptr } %t90, 0
  store i64 %t91, ptr %l42, !tbaa !24
  %t92 = icmp sge i64 0, 0
  br i1 %t92, label %bb31, label %bb32
bb30:
  br label %bb37
bb31:
  %t94 = icmp sle i64 0, 0
  br i1 %t94, label %bb33, label %bb34
bb32:
  call void @__olang_check_failed(ptr @olang_loc_f601f9616f628c92_63c657ce4b964a9e)
  unreachable
bb33:
  %t96 = load i64, ptr %l42, !tbaa !24
  %t97 = icmp sle i64 0, %t96
  br i1 %t97, label %bb35, label %bb36
bb34:
  call void @__olang_check_failed(ptr @olang_loc_f601f9616f628c92_63c657ce4b964a9e)
  unreachable
bb35:
  %t99 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !27
  %t101 = getelementptr i8, ptr %t100, i64 0
  %t102 = sub i64 0, 0
  %t103 = insertvalue { i64, ptr } undef, i64 %t102, 0
  %t104 = insertvalue { i64, ptr } %t103, ptr %t101, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t104, ptr %rv
  br label %ret
bb36:
  call void @__olang_check_failed(ptr @olang_loc_f601f9616f628c92_63c657ce4b964a9e)
  unreachable
bb37:
  store i64 3, ptr %l2, !tbaa !24
  br label %bb38
bb38:
  %t106 = load i64, ptr %l2, !tbaa !24
  %t107 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t109 = extractvalue { i64, ptr } %t107, 0
  %t112 = icmp slt i64 %t106, %t109
  br i1 %t112, label %bb39, label %bb40
bb39:
  %t114 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t114, ptr %l52, !tbaa !27
  %t115 = load i64, ptr %l2, !tbaa !24
  %t117 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t118 = load ptr, ptr %t117, !tbaa !27
  %t119 = getelementptr i8, ptr %t118, i64 %t115
  %t120 = load i8, ptr %t119, !tbaa !32
  %t122 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t120)
  store i1 %t122, ptr %l55
  br label %bb41
bb40:
  store i1 false, ptr %l51, !tbaa !21
  br label %bb42
bb41:
  %t123 = load i1, ptr %l55, !tbaa !21
  store i1 %t123, ptr %l51, !tbaa !21
  br label %bb42
bb42:
  %t124 = load i1, ptr %l51, !tbaa !21
  %t125 = xor i1 %t124, true
  br i1 %t125, label %bb43, label %bb44
bb43:
  br label %bb47
bb44:
  br label %bb45
bb45:
  %t127 = load i64, ptr %l2, !tbaa !24
  %t130 = add i64 %t127, 1
  store i64 %t130, ptr %l2, !tbaa !24
  br label %bb46
bb46:
  br label %bb38
bb47:
  br label %bb48
bb48:
  %t132 = load i64, ptr %l2, !tbaa !24
  %t133 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t135 = extractvalue { i64, ptr } %t133, 0
  %t138 = icmp slt i64 %t132, %t135
  br i1 %t138, label %bb49, label %bb50
bb49:
  %t140 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t140, ptr %l65, !tbaa !27
  %t141 = load i64, ptr %l2, !tbaa !24
  %t143 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t144 = load ptr, ptr %t143, !tbaa !27
  %t145 = getelementptr i8, ptr %t144, i64 %t141
  %t146 = load i8, ptr %t145, !tbaa !32
  %t148 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLower(i8 %t146)
  store i1 %t148, ptr %l68
  br label %bb51
bb50:
  store i1 false, ptr %l64, !tbaa !21
  br label %bb52
bb51:
  %t149 = load i1, ptr %l68, !tbaa !21
  store i1 %t149, ptr %l64, !tbaa !21
  br label %bb52
bb52:
  %t150 = load i1, ptr %l64, !tbaa !21
  %t151 = xor i1 %t150, true
  br i1 %t151, label %bb53, label %bb54
bb53:
  br label %bb57
bb54:
  br label %bb55
bb55:
  %t153 = load i64, ptr %l2, !tbaa !24
  %t156 = add i64 %t153, 1
  store i64 %t156, ptr %l2, !tbaa !24
  br label %bb56
bb56:
  br label %bb48
bb57:
  %t158 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t158, ptr %l73, !tbaa !27
  %t159 = load i64, ptr %l2, !tbaa !24
  store i64 %t159, ptr %l74, !tbaa !24
  %t160 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t163 = extractvalue { i64, ptr } %t160, 0
  store i64 %t163, ptr %l77, !tbaa !24
  %t164 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t165 = extractvalue { i64, ptr } %t164, 0
  store i64 %t165, ptr %l78, !tbaa !24
  %t166 = load i64, ptr %l74, !tbaa !24
  %t167 = icmp sge i64 %t166, 0
  br i1 %t167, label %bb58, label %bb59
bb58:
  %t169 = load i64, ptr %l74, !tbaa !24
  %t170 = load i64, ptr %l77, !tbaa !24
  %t171 = icmp sle i64 %t169, %t170
  br i1 %t171, label %bb60, label %bb61
bb59:
  call void @__olang_check_failed(ptr @olang_loc_34cb3e047b5a9691_df78e9c71a0d19fd)
  unreachable
bb60:
  %t173 = load i64, ptr %l77, !tbaa !24
  %t174 = load i64, ptr %l78, !tbaa !24
  %t175 = icmp sle i64 %t173, %t174
  br i1 %t175, label %bb62, label %bb63
bb61:
  call void @__olang_check_failed(ptr @olang_loc_34cb3e047b5a9691_df78e9c71a0d19fd)
  unreachable
bb62:
  %t177 = getelementptr { i64, ptr }, ptr %l73, i32 0, i32 1
  %t178 = load ptr, ptr %t177, !tbaa !27
  %t179 = load i64, ptr %l74, !tbaa !24
  %t180 = load i64, ptr %l77, !tbaa !24
  %t181 = getelementptr i8, ptr %t178, i64 %t179
  %t182 = sub i64 %t180, %t179
  %t183 = insertvalue { i64, ptr } undef, i64 %t182, 0
  %t184 = insertvalue { i64, ptr } %t183, ptr %t181, 1
  %t186 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t184, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d59, i32 0, i32 1) })
  store i1 %t186, ptr %l83
  br label %bb64
bb63:
  call void @__olang_check_failed(ptr @olang_loc_34cb3e047b5a9691_df78e9c71a0d19fd)
  unreachable
bb64:
  %t187 = load i1, ptr %l83, !tbaa !21
  %t188 = xor i1 %t187, true
  br i1 %t188, label %bb65, label %bb66
bb65:
  %t190 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t190, ptr %l86, !tbaa !27
  %t191 = load i64, ptr %l2, !tbaa !24
  store i64 %t191, ptr %l87, !tbaa !24
  %t192 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t195 = extractvalue { i64, ptr } %t192, 0
  store i64 %t195, ptr %l90, !tbaa !24
  %t196 = load { i64, ptr }, ptr %l86, !tbaa !27
  %t197 = extractvalue { i64, ptr } %t196, 0
  store i64 %t197, ptr %l91, !tbaa !24
  %t198 = load i64, ptr %l87, !tbaa !24
  %t199 = icmp sge i64 %t198, 0
  br i1 %t199, label %bb67, label %bb68
bb66:
  store i1 false, ptr %l85, !tbaa !21
  br label %bb74
bb67:
  %t201 = load i64, ptr %l87, !tbaa !24
  %t202 = load i64, ptr %l90, !tbaa !24
  %t203 = icmp sle i64 %t201, %t202
  br i1 %t203, label %bb69, label %bb70
bb68:
  call void @__olang_check_failed(ptr @olang_loc_34cb3e047b5a9691_df78e9c71a0d19fd)
  unreachable
bb69:
  %t205 = load i64, ptr %l90, !tbaa !24
  %t206 = load i64, ptr %l91, !tbaa !24
  %t207 = icmp sle i64 %t205, %t206
  br i1 %t207, label %bb71, label %bb72
bb70:
  call void @__olang_check_failed(ptr @olang_loc_34cb3e047b5a9691_df78e9c71a0d19fd)
  unreachable
bb71:
  %t209 = getelementptr { i64, ptr }, ptr %l86, i32 0, i32 1
  %t210 = load ptr, ptr %t209, !tbaa !27
  %t211 = load i64, ptr %l87, !tbaa !24
  %t212 = load i64, ptr %l90, !tbaa !24
  %t213 = getelementptr i8, ptr %t210, i64 %t211
  %t214 = sub i64 %t212, %t211
  %t215 = insertvalue { i64, ptr } undef, i64 %t214, 0
  %t216 = insertvalue { i64, ptr } %t215, ptr %t213, 1
  %t218 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t216, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d60, i32 0, i32 1) })
  store i1 %t218, ptr %l96
  br label %bb73
bb72:
  call void @__olang_check_failed(ptr @olang_loc_34cb3e047b5a9691_df78e9c71a0d19fd)
  unreachable
bb73:
  %t219 = load i1, ptr %l96, !tbaa !21
  %t220 = xor i1 %t219, true
  store i1 %t220, ptr %l85, !tbaa !21
  br label %bb74
bb74:
  %t222 = load i1, ptr %l85, !tbaa !21
  br i1 %t222, label %bb75, label %bb76
bb75:
  %t223 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t223, ptr %l98, !tbaa !27
  %t224 = load { i64, ptr }, ptr %l98, !tbaa !27
  %t225 = extractvalue { i64, ptr } %t224, 0
  store i64 %t225, ptr %l99, !tbaa !24
  %t226 = icmp sge i64 0, 0
  br i1 %t226, label %bb77, label %bb78
bb76:
  br label %bb83
bb77:
  %t228 = icmp sle i64 0, 0
  br i1 %t228, label %bb79, label %bb80
bb78:
  call void @__olang_check_failed(ptr @olang_loc_34cb3e047b5a9691_df78e9c71a0d19fd)
  unreachable
bb79:
  %t230 = load i64, ptr %l99, !tbaa !24
  %t231 = icmp sle i64 0, %t230
  br i1 %t231, label %bb81, label %bb82
bb80:
  call void @__olang_check_failed(ptr @olang_loc_34cb3e047b5a9691_df78e9c71a0d19fd)
  unreachable
bb81:
  %t233 = getelementptr { i64, ptr }, ptr %l98, i32 0, i32 1
  %t234 = load ptr, ptr %t233, !tbaa !27
  %t235 = getelementptr i8, ptr %t234, i64 0
  %t236 = sub i64 0, 0
  %t237 = insertvalue { i64, ptr } undef, i64 %t236, 0
  %t238 = insertvalue { i64, ptr } %t237, ptr %t235, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t238, ptr %rv
  br label %ret
bb82:
  call void @__olang_check_failed(ptr @olang_loc_34cb3e047b5a9691_df78e9c71a0d19fd)
  unreachable
bb83:
  %t240 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t240, ptr %l104, !tbaa !27
  %t241 = load i64, ptr %l2, !tbaa !24
  store i64 %t241, ptr %l105, !tbaa !24
  %t242 = load { i64, ptr }, ptr %l104, !tbaa !27
  %t243 = extractvalue { i64, ptr } %t242, 0
  store i64 %t243, ptr %l106, !tbaa !24
  %t244 = icmp sge i64 2, 0
  br i1 %t244, label %bb84, label %bb85
bb84:
  %t246 = load i64, ptr %l105, !tbaa !24
  %t247 = icmp sle i64 2, %t246
  br i1 %t247, label %bb86, label %bb87
bb85:
  call void @__olang_check_failed(ptr @olang_loc_44be31be33a055a4_da5ef357ed133fa0)
  unreachable
bb86:
  %t249 = load i64, ptr %l105, !tbaa !24
  %t250 = load i64, ptr %l106, !tbaa !24
  %t251 = icmp sle i64 %t249, %t250
  br i1 %t251, label %bb88, label %bb89
bb87:
  call void @__olang_check_failed(ptr @olang_loc_44be31be33a055a4_da5ef357ed133fa0)
  unreachable
bb88:
  %t253 = getelementptr { i64, ptr }, ptr %l104, i32 0, i32 1
  %t254 = load ptr, ptr %t253, !tbaa !27
  %t255 = load i64, ptr %l105, !tbaa !24
  %t256 = getelementptr i8, ptr %t254, i64 2
  %t257 = sub i64 %t255, 2
  %t258 = insertvalue { i64, ptr } undef, i64 %t257, 0
  %t259 = insertvalue { i64, ptr } %t258, ptr %t256, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t259, ptr %rv
  br label %ret
bb89:
  call void @__olang_check_failed(ptr @olang_loc_44be31be33a055a4_da5ef357ed133fa0)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fdiag_2esection(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/text:StringBuilder"
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l5 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l1
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l1
  store %"std/prelude/text:StringBuilder" %t2, ptr %l0
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l0, i8 -62)
  br label %bb2
bb2:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l0, i8 -89)
  br label %bb3
bb3:
  %t6 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v0, ptr %l0)
  store { i64, ptr } %t6, ptr %l5
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s0)
  %t7 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t7, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fdiag_3aDiagnostics_2ector(ptr %out, ptr %v0, i1 %a0) #0 {
entry:
  %l1 = alloca i1
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l8 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l10 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l12 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l14 = alloca i64
  %l15 = alloca i1
  %l16 = alloca i1
  %l17 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l18 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l19 = alloca { i64, [3 x i64] }
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l24 = alloca i1
  %l25 = alloca i1
  %l26 = alloca i1
  %l27 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l28 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l29 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l32 = alloca i64
  %l34 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l36 = alloca i64
  %l38 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l40 = alloca i64
  %l42 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l44 = alloca i64
  %l46 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l48 = alloca i64
  %l50 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l52 = alloca i64
  %l54 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l56 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l57 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l58 = alloca i64
  %l60 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l62 = alloca i64
  %l64 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l66 = alloca i64
  %l68 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l70 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l71 = alloca i64
  %l73 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l75 = alloca i64
  %l77 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l80 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l81 = alloca i64
  %l83 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l85 = alloca i64
  %l87 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l89 = alloca i64
  %l91 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l93 = alloca %"compiler/diag:Diagnostics"
  %t240 = alloca { i64, [3 x i64] }, align 8
  br label %start
start:
  br label %bb0
bb0:
  store i1 %a0, ptr %l1, !tbaa !21
  %t3 = call ptr @__olang_scope_hold(ptr %v0)
  %t4 = ptrtoint ptr %t3 to i64
  store i64 %t4, ptr %l32, !tbaa !24
  %t5 = load i1, ptr @olang_2esole_2ecompiler_2fdiag_3aDiagnostics_2e1
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = call ptr @__olang_region_make(ptr %v0)
  %t8 = ptrtoint ptr %t7 to i64
  store i64 %t8, ptr %l32, !tbaa !24
  br label %bb2
bb2:
  %t9 = load i64, ptr %l32
  %t10 = inttoptr i64 %t9 to ptr
  %t11 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t10, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t11, ptr %l34
  br label %bb3
bb3:
  %t12 = load i1, ptr @olang_2esole_2ecompiler_2fdiag_3aDiagnostics_2e1
  br i1 %t12, label %bb4, label %bb5
bb4:
  %t14 = load i64, ptr %l32
  %t15 = inttoptr i64 %t14 to ptr
  %t16 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l34, i32 0, i32 0
  %t17 = load { i64, ptr }, ptr %t16
  %t18 = extractvalue { i64, ptr } %t17, 1
  %t19 = call ptr @__olang_region_or(ptr %t18, ptr null)
  %t20 = call ptr @__olang_region_home(ptr %t19)
  %t21 = icmp ne ptr %t20, null
  %t22 = select i1 %t21, ptr %t20, ptr null
  call void @__olang_region_settle_in(ptr %t15, ptr %t22)
  br label %bb5
bb5:
  %t23 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l34
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t23, ptr %l2
  %t24 = call ptr @__olang_scope_hold(ptr %v0)
  %t25 = ptrtoint ptr %t24 to i64
  store i64 %t25, ptr %l36, !tbaa !24
  %t26 = load i1, ptr @olang_2esole_2ecompiler_2fdiag_3aDiagnostics_2e2
  br i1 %t26, label %bb6, label %bb7
bb6:
  %t28 = call ptr @__olang_region_make(ptr %v0)
  %t29 = ptrtoint ptr %t28 to i64
  store i64 %t29, ptr %l36, !tbaa !24
  br label %bb7
bb7:
  %t30 = load i64, ptr %l36
  %t31 = inttoptr i64 %t30 to ptr
  %t32 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t31, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t32, ptr %l38
  br label %bb8
bb8:
  %t33 = load i1, ptr @olang_2esole_2ecompiler_2fdiag_3aDiagnostics_2e2
  br i1 %t33, label %bb9, label %bb10
bb9:
  %t35 = load i64, ptr %l36
  %t36 = inttoptr i64 %t35 to ptr
  %t37 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l38, i32 0, i32 0
  %t38 = load { i64, ptr }, ptr %t37
  %t39 = extractvalue { i64, ptr } %t38, 1
  %t40 = call ptr @__olang_region_or(ptr %t39, ptr null)
  %t41 = call ptr @__olang_region_home(ptr %t40)
  %t42 = icmp ne ptr %t41, null
  %t43 = select i1 %t42, ptr %t41, ptr null
  call void @__olang_region_settle_in(ptr %t36, ptr %t43)
  br label %bb10
bb10:
  %t44 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l38
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t44, ptr %l3
  %t45 = call ptr @__olang_scope_hold(ptr %v0)
  %t46 = ptrtoint ptr %t45 to i64
  store i64 %t46, ptr %l40, !tbaa !24
  %t47 = load i1, ptr @olang_2esole_2ecompiler_2fdiag_3aDiagnostics_2e3
  br i1 %t47, label %bb11, label %bb12
bb11:
  %t49 = call ptr @__olang_region_make(ptr %v0)
  %t50 = ptrtoint ptr %t49 to i64
  store i64 %t50, ptr %l40, !tbaa !24
  br label %bb12
bb12:
  %t51 = load i64, ptr %l40
  %t52 = inttoptr i64 %t51 to ptr
  %t53 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %t52, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t53, ptr %l42
  br label %bb13
bb13:
  %t54 = load i1, ptr @olang_2esole_2ecompiler_2fdiag_3aDiagnostics_2e3
  br i1 %t54, label %bb14, label %bb15
bb14:
  %t56 = load i64, ptr %l40
  %t57 = inttoptr i64 %t56 to ptr
  %t58 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l42, i32 0, i32 0
  %t59 = load { i64, ptr }, ptr %t58
  %t60 = extractvalue { i64, ptr } %t59, 1
  %t61 = call ptr @__olang_region_or(ptr %t60, ptr null)
  %t62 = call ptr @__olang_region_home(ptr %t61)
  %t63 = icmp ne ptr %t62, null
  %t64 = select i1 %t63, ptr %t62, ptr null
  call void @__olang_region_settle_in(ptr %t57, ptr %t64)
  br label %bb15
bb15:
  %t65 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l42
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t65, ptr %l4
  %t66 = call ptr @__olang_scope_hold(ptr %v0)
  %t67 = ptrtoint ptr %t66 to i64
  store i64 %t67, ptr %l44, !tbaa !24
  %t68 = load i1, ptr @olang_2esole_2ecompiler_2fdiag_3aDiagnostics_2e4
  br i1 %t68, label %bb16, label %bb17
bb16:
  %t70 = call ptr @__olang_region_make(ptr %v0)
  %t71 = ptrtoint ptr %t70 to i64
  store i64 %t71, ptr %l44, !tbaa !24
  br label %bb17
bb17:
  %t72 = load i64, ptr %l44
  %t73 = inttoptr i64 %t72 to ptr
  %t74 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t73, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t74, ptr %l46
  br label %bb18
bb18:
  %t75 = load i1, ptr @olang_2esole_2ecompiler_2fdiag_3aDiagnostics_2e4
  br i1 %t75, label %bb19, label %bb20
bb19:
  %t77 = load i64, ptr %l44
  %t78 = inttoptr i64 %t77 to ptr
  %t79 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l46, i32 0, i32 0
  %t80 = load { i64, ptr }, ptr %t79
  %t81 = extractvalue { i64, ptr } %t80, 1
  %t82 = call ptr @__olang_region_or(ptr %t81, ptr null)
  %t83 = call ptr @__olang_region_home(ptr %t82)
  %t84 = icmp ne ptr %t83, null
  %t85 = select i1 %t84, ptr %t83, ptr null
  call void @__olang_region_settle_in(ptr %t78, ptr %t85)
  br label %bb20
bb20:
  %t86 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l46
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t86, ptr %l5
  %t87 = call ptr @__olang_scope_hold(ptr %v0)
  %t88 = ptrtoint ptr %t87 to i64
  store i64 %t88, ptr %l48, !tbaa !24
  %t89 = load i1, ptr @olang_2esole_2ecompiler_2fdiag_3aDiagnostics_2e5
  br i1 %t89, label %bb21, label %bb22
bb21:
  %t91 = call ptr @__olang_region_make(ptr %v0)
  %t92 = ptrtoint ptr %t91 to i64
  store i64 %t92, ptr %l48, !tbaa !24
  br label %bb22
bb22:
  %t93 = load i64, ptr %l48
  %t94 = inttoptr i64 %t93 to ptr
  %t95 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t94, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t95, ptr %l50
  br label %bb23
bb23:
  %t96 = load i1, ptr @olang_2esole_2ecompiler_2fdiag_3aDiagnostics_2e5
  br i1 %t96, label %bb24, label %bb25
bb24:
  %t98 = load i64, ptr %l48
  %t99 = inttoptr i64 %t98 to ptr
  %t100 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l50, i32 0, i32 0
  %t101 = load { i64, ptr }, ptr %t100
  %t102 = extractvalue { i64, ptr } %t101, 1
  %t103 = call ptr @__olang_region_or(ptr %t102, ptr null)
  %t104 = call ptr @__olang_region_home(ptr %t103)
  %t105 = icmp ne ptr %t104, null
  %t106 = select i1 %t105, ptr %t104, ptr null
  call void @__olang_region_settle_in(ptr %t99, ptr %t106)
  br label %bb25
bb25:
  %t107 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l50
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t107, ptr %l6
  %t108 = call ptr @__olang_scope_hold(ptr %v0)
  %t109 = ptrtoint ptr %t108 to i64
  store i64 %t109, ptr %l52, !tbaa !24
  %t110 = load i1, ptr @olang_2esole_2ecompiler_2fdiag_3aDiagnostics_2e6
  br i1 %t110, label %bb26, label %bb27
bb26:
  %t112 = call ptr @__olang_region_make(ptr %v0)
  %t113 = ptrtoint ptr %t112 to i64
  store i64 %t113, ptr %l52, !tbaa !24
  br label %bb27
bb27:
  %t114 = load i64, ptr %l52
  %t115 = inttoptr i64 %t114 to ptr
  %t116 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t115, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t116, ptr %l54
  br label %bb28
bb28:
  %t117 = load i1, ptr @olang_2esole_2ecompiler_2fdiag_3aDiagnostics_2e6
  br i1 %t117, label %bb29, label %bb30
bb29:
  %t119 = load i64, ptr %l52
  %t120 = inttoptr i64 %t119 to ptr
  %t121 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l54, i32 0, i32 0
  %t122 = load { i64, ptr }, ptr %t121
  %t123 = extractvalue { i64, ptr } %t122, 1
  %t124 = call ptr @__olang_region_or(ptr %t123, ptr null)
  %t125 = call ptr @__olang_region_home(ptr %t124)
  %t126 = icmp ne ptr %t125, null
  %t127 = select i1 %t126, ptr %t125, ptr null
  call void @__olang_region_settle_in(ptr %t120, ptr %t127)
  br label %bb30
bb30:
  %t128 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l54
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t128, ptr %l7
  %t129 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3arecord_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t129, ptr %l56
  br label %bb31
bb31:
  %t130 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l56
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t130, ptr %l8
  %t131 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3anote_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t131, ptr %l57
  br label %bb32
bb32:
  %t132 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l57
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t132, ptr %l9
  %t133 = call ptr @__olang_scope_hold(ptr %v0)
  %t134 = ptrtoint ptr %t133 to i64
  store i64 %t134, ptr %l58, !tbaa !24
  %t135 = load i1, ptr @olang_2esole_2ecompiler_2fdiag_3aDiagnostics_2e9
  br i1 %t135, label %bb33, label %bb34
bb33:
  %t137 = call ptr @__olang_region_make(ptr %v0)
  %t138 = ptrtoint ptr %t137 to i64
  store i64 %t138, ptr %l58, !tbaa !24
  br label %bb34
bb34:
  %t139 = load i64, ptr %l58
  %t140 = inttoptr i64 %t139 to ptr
  %t141 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t140, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t141, ptr %l60
  br label %bb35
bb35:
  %t142 = load i1, ptr @olang_2esole_2ecompiler_2fdiag_3aDiagnostics_2e9
  br i1 %t142, label %bb36, label %bb37
bb36:
  %t144 = load i64, ptr %l58
  %t145 = inttoptr i64 %t144 to ptr
  %t146 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l60, i32 0, i32 0
  %t147 = load { i64, ptr }, ptr %t146
  %t148 = extractvalue { i64, ptr } %t147, 1
  %t149 = call ptr @__olang_region_or(ptr %t148, ptr null)
  %t150 = call ptr @__olang_region_home(ptr %t149)
  %t151 = icmp ne ptr %t150, null
  %t152 = select i1 %t151, ptr %t150, ptr null
  call void @__olang_region_settle_in(ptr %t145, ptr %t152)
  br label %bb37
bb37:
  %t153 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l60
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t153, ptr %l10
  %t154 = call ptr @__olang_scope_hold(ptr %v0)
  %t155 = ptrtoint ptr %t154 to i64
  store i64 %t155, ptr %l62, !tbaa !24
  %t156 = load i1, ptr @olang_2esole_2ecompiler_2fdiag_3aDiagnostics_2e10
  br i1 %t156, label %bb38, label %bb39
bb38:
  %t158 = call ptr @__olang_region_make(ptr %v0)
  %t159 = ptrtoint ptr %t158 to i64
  store i64 %t159, ptr %l62, !tbaa !24
  br label %bb39
bb39:
  %t160 = load i64, ptr %l62
  %t161 = inttoptr i64 %t160 to ptr
  %t162 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t161, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t162, ptr %l64
  br label %bb40
bb40:
  %t163 = load i1, ptr @olang_2esole_2ecompiler_2fdiag_3aDiagnostics_2e10
  br i1 %t163, label %bb41, label %bb42
bb41:
  %t165 = load i64, ptr %l62
  %t166 = inttoptr i64 %t165 to ptr
  %t167 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l64, i32 0, i32 0
  %t168 = load { i64, ptr }, ptr %t167
  %t169 = extractvalue { i64, ptr } %t168, 1
  %t170 = call ptr @__olang_region_or(ptr %t169, ptr null)
  %t171 = call ptr @__olang_region_home(ptr %t170)
  %t172 = icmp ne ptr %t171, null
  %t173 = select i1 %t172, ptr %t171, ptr null
  call void @__olang_region_settle_in(ptr %t166, ptr %t173)
  br label %bb42
bb42:
  %t174 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l64
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t174, ptr %l11
  %t175 = call ptr @__olang_scope_hold(ptr %v0)
  %t176 = ptrtoint ptr %t175 to i64
  store i64 %t176, ptr %l66, !tbaa !24
  %t177 = load i1, ptr @olang_2esole_2ecompiler_2fdiag_3aDiagnostics_2e11
  br i1 %t177, label %bb43, label %bb44
bb43:
  %t179 = call ptr @__olang_region_make(ptr %v0)
  %t180 = ptrtoint ptr %t179 to i64
  store i64 %t180, ptr %l66, !tbaa !24
  br label %bb44
bb44:
  %t181 = load i64, ptr %l66
  %t182 = inttoptr i64 %t181 to ptr
  %t183 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t182, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t183, ptr %l68
  br label %bb45
bb45:
  %t184 = load i1, ptr @olang_2esole_2ecompiler_2fdiag_3aDiagnostics_2e11
  br i1 %t184, label %bb46, label %bb47
bb46:
  %t186 = load i64, ptr %l66
  %t187 = inttoptr i64 %t186 to ptr
  %t188 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l68, i32 0, i32 0
  %t189 = load { i64, ptr }, ptr %t188
  %t190 = extractvalue { i64, ptr } %t189, 1
  %t191 = call ptr @__olang_region_or(ptr %t190, ptr null)
  %t192 = call ptr @__olang_region_home(ptr %t191)
  %t193 = icmp ne ptr %t192, null
  %t194 = select i1 %t193, ptr %t192, ptr null
  call void @__olang_region_settle_in(ptr %t187, ptr %t194)
  br label %bb47
bb47:
  %t195 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l68
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t195, ptr %l12
  %t196 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3acontext_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t196, ptr %l70
  br label %bb48
bb48:
  %t197 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l70
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t197, ptr %l13
  store i64 0, ptr %l14, !tbaa !24
  store i1 false, ptr %l15, !tbaa !21
  store i1 false, ptr %l16, !tbaa !21
  %t198 = call ptr @__olang_scope_hold(ptr %v0)
  %t199 = ptrtoint ptr %t198 to i64
  store i64 %t199, ptr %l71, !tbaa !24
  %t200 = load i1, ptr @olang_2esole_2ecompiler_2fdiag_3aDiagnostics_2e16
  br i1 %t200, label %bb49, label %bb50
bb49:
  %t202 = call ptr @__olang_region_make(ptr %v0)
  %t203 = ptrtoint ptr %t202 to i64
  store i64 %t203, ptr %l71, !tbaa !24
  br label %bb50
bb50:
  %t204 = load i64, ptr %l71
  %t205 = inttoptr i64 %t204 to ptr
  %t206 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t205, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t206, ptr %l73
  br label %bb51
bb51:
  %t207 = load i1, ptr @olang_2esole_2ecompiler_2fdiag_3aDiagnostics_2e16
  br i1 %t207, label %bb52, label %bb53
bb52:
  %t209 = load i64, ptr %l71
  %t210 = inttoptr i64 %t209 to ptr
  %t211 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l73, i32 0, i32 0
  %t212 = load { i64, ptr }, ptr %t211
  %t213 = extractvalue { i64, ptr } %t212, 1
  %t214 = call ptr @__olang_region_or(ptr %t213, ptr null)
  %t215 = call ptr @__olang_region_home(ptr %t214)
  %t216 = icmp ne ptr %t215, null
  %t217 = select i1 %t216, ptr %t215, ptr null
  call void @__olang_region_settle_in(ptr %t210, ptr %t217)
  br label %bb53
bb53:
  %t218 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l73
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t218, ptr %l17
  %t219 = call ptr @__olang_scope_hold(ptr %v0)
  %t220 = ptrtoint ptr %t219 to i64
  store i64 %t220, ptr %l75, !tbaa !24
  %t221 = load i1, ptr @olang_2esole_2ecompiler_2fdiag_3aDiagnostics_2e17
  br i1 %t221, label %bb54, label %bb55
bb54:
  %t223 = call ptr @__olang_region_make(ptr %v0)
  %t224 = ptrtoint ptr %t223 to i64
  store i64 %t224, ptr %l75, !tbaa !24
  br label %bb55
bb55:
  %t225 = load i64, ptr %l75
  %t226 = inttoptr i64 %t225 to ptr
  %t227 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t226, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t227, ptr %l77
  br label %bb56
bb56:
  %t228 = load i1, ptr @olang_2esole_2ecompiler_2fdiag_3aDiagnostics_2e17
  br i1 %t228, label %bb57, label %bb58
bb57:
  %t230 = load i64, ptr %l75
  %t231 = inttoptr i64 %t230 to ptr
  %t232 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l77, i32 0, i32 0
  %t233 = load { i64, ptr }, ptr %t232
  %t234 = extractvalue { i64, ptr } %t233, 1
  %t235 = call ptr @__olang_region_or(ptr %t234, ptr null)
  %t236 = call ptr @__olang_region_home(ptr %t235)
  %t237 = icmp ne ptr %t236, null
  %t238 = select i1 %t237, ptr %t236, ptr null
  call void @__olang_region_settle_in(ptr %t231, ptr %t238)
  br label %bb58
bb58:
  %t239 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l77
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t239, ptr %l18
  store { i64, [3 x i64] } zeroinitializer, ptr %t240
  %t241 = getelementptr { i64, [3 x i64] }, ptr %t240, i32 0, i32 0
  store i64 0, ptr %t241
  %t242 = load { i64, [3 x i64] }, ptr %t240
  store { i64, [3 x i64] } %t242, ptr %l19
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d61, i32 0, i32 1) }, ptr %l20, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d62, i32 0, i32 1) }, ptr %l21, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d63, i32 0, i32 1) }, ptr %l22, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d64, i32 0, i32 1) }, ptr %l23, !tbaa !27
  store i1 false, ptr %l24, !tbaa !21
  store i1 false, ptr %l25, !tbaa !21
  store i1 false, ptr %l26, !tbaa !21
  %t244 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3arecord_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t244, ptr %l80
  br label %bb59
bb59:
  %t245 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l80
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t245, ptr %l27
  %t246 = call ptr @__olang_scope_hold(ptr %v0)
  %t247 = ptrtoint ptr %t246 to i64
  store i64 %t247, ptr %l81, !tbaa !24
  %t248 = load i1, ptr @olang_2esole_2ecompiler_2fdiag_3aDiagnostics_2e27
  br i1 %t248, label %bb60, label %bb61
bb60:
  %t250 = call ptr @__olang_region_make(ptr %v0)
  %t251 = ptrtoint ptr %t250 to i64
  store i64 %t251, ptr %l81, !tbaa !24
  br label %bb61
bb61:
  %t252 = load i64, ptr %l81
  %t253 = inttoptr i64 %t252 to ptr
  %t254 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t253, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t254, ptr %l83
  br label %bb62
bb62:
  %t255 = load i1, ptr @olang_2esole_2ecompiler_2fdiag_3aDiagnostics_2e27
  br i1 %t255, label %bb63, label %bb64
bb63:
  %t257 = load i64, ptr %l81
  %t258 = inttoptr i64 %t257 to ptr
  %t259 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l83, i32 0, i32 0
  %t260 = load { i64, ptr }, ptr %t259
  %t261 = extractvalue { i64, ptr } %t260, 1
  %t262 = call ptr @__olang_region_or(ptr %t261, ptr null)
  %t263 = call ptr @__olang_region_home(ptr %t262)
  %t264 = icmp ne ptr %t263, null
  %t265 = select i1 %t264, ptr %t263, ptr null
  call void @__olang_region_settle_in(ptr %t258, ptr %t265)
  br label %bb64
bb64:
  %t266 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l83
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t266, ptr %l28
  %t267 = call ptr @__olang_scope_hold(ptr %v0)
  %t268 = ptrtoint ptr %t267 to i64
  store i64 %t268, ptr %l85, !tbaa !24
  %t269 = load i1, ptr @olang_2esole_2ecompiler_2fdiag_3aDiagnostics_2e28
  br i1 %t269, label %bb65, label %bb66
bb65:
  %t271 = call ptr @__olang_region_make(ptr %v0)
  %t272 = ptrtoint ptr %t271 to i64
  store i64 %t272, ptr %l85, !tbaa !24
  br label %bb66
bb66:
  %t273 = load i64, ptr %l85
  %t274 = inttoptr i64 %t273 to ptr
  %t275 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t274, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t275, ptr %l87
  br label %bb67
bb67:
  %t276 = load i1, ptr @olang_2esole_2ecompiler_2fdiag_3aDiagnostics_2e28
  br i1 %t276, label %bb68, label %bb69
bb68:
  %t278 = load i64, ptr %l85
  %t279 = inttoptr i64 %t278 to ptr
  %t280 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l87, i32 0, i32 0
  %t281 = load { i64, ptr }, ptr %t280
  %t282 = extractvalue { i64, ptr } %t281, 1
  %t283 = call ptr @__olang_region_or(ptr %t282, ptr null)
  %t284 = call ptr @__olang_region_home(ptr %t283)
  %t285 = icmp ne ptr %t284, null
  %t286 = select i1 %t285, ptr %t284, ptr null
  call void @__olang_region_settle_in(ptr %t279, ptr %t286)
  br label %bb69
bb69:
  %t287 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l87
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t287, ptr %l29
  %t288 = call ptr @__olang_scope_hold(ptr %v0)
  %t289 = ptrtoint ptr %t288 to i64
  store i64 %t289, ptr %l89, !tbaa !24
  %t290 = load i1, ptr @olang_2esole_2ecompiler_2fdiag_3aDiagnostics_2e29
  br i1 %t290, label %bb70, label %bb71
bb70:
  %t292 = call ptr @__olang_region_make(ptr %v0)
  %t293 = ptrtoint ptr %t292 to i64
  store i64 %t293, ptr %l89, !tbaa !24
  br label %bb71
bb71:
  %t294 = load i64, ptr %l89
  %t295 = inttoptr i64 %t294 to ptr
  %t296 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t295, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t296, ptr %l91
  br label %bb72
bb72:
  %t297 = load i1, ptr @olang_2esole_2ecompiler_2fdiag_3aDiagnostics_2e29
  br i1 %t297, label %bb73, label %bb74
bb73:
  %t299 = load i64, ptr %l89
  %t300 = inttoptr i64 %t299 to ptr
  %t301 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l91, i32 0, i32 0
  %t302 = load { i64, ptr }, ptr %t301
  %t303 = extractvalue { i64, ptr } %t302, 1
  %t304 = call ptr @__olang_region_or(ptr %t303, ptr null)
  %t305 = call ptr @__olang_region_home(ptr %t304)
  %t306 = icmp ne ptr %t305, null
  %t307 = select i1 %t306, ptr %t305, ptr null
  call void @__olang_region_settle_in(ptr %t300, ptr %t307)
  br label %bb74
bb74:
  %t308 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l91
  %t309 = getelementptr %"compiler/diag:Diagnostics", ptr %l93, i32 0, i32 0
  %t310 = load i1, ptr %l1, !tbaa !21
  store i1 %t310, ptr %t309, !tbaa !21
  %t311 = getelementptr %"compiler/diag:Diagnostics", ptr %l93, i32 0, i32 1
  %t312 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t312, ptr %t311
  %t313 = getelementptr %"compiler/diag:Diagnostics", ptr %l93, i32 0, i32 2
  %t314 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t314, ptr %t313
  %t315 = getelementptr %"compiler/diag:Diagnostics", ptr %l93, i32 0, i32 3
  %t316 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t316, ptr %t315
  %t317 = getelementptr %"compiler/diag:Diagnostics", ptr %l93, i32 0, i32 4
  %t318 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t318, ptr %t317
  %t319 = getelementptr %"compiler/diag:Diagnostics", ptr %l93, i32 0, i32 5
  %t320 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l6
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t320, ptr %t319
  %t321 = getelementptr %"compiler/diag:Diagnostics", ptr %l93, i32 0, i32 6
  %t322 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l7
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t322, ptr %t321
  %t323 = getelementptr %"compiler/diag:Diagnostics", ptr %l93, i32 0, i32 7
  %t324 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l8
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t324, ptr %t323
  %t325 = getelementptr %"compiler/diag:Diagnostics", ptr %l93, i32 0, i32 8
  %t326 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l9
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t326, ptr %t325
  %t327 = getelementptr %"compiler/diag:Diagnostics", ptr %l93, i32 0, i32 9
  %t328 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l10
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t328, ptr %t327
  %t329 = getelementptr %"compiler/diag:Diagnostics", ptr %l93, i32 0, i32 10
  %t330 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l11
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t330, ptr %t329
  %t331 = getelementptr %"compiler/diag:Diagnostics", ptr %l93, i32 0, i32 11
  %t332 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l12
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t332, ptr %t331
  %t333 = getelementptr %"compiler/diag:Diagnostics", ptr %l93, i32 0, i32 12
  %t334 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l13
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t334, ptr %t333
  %t335 = getelementptr %"compiler/diag:Diagnostics", ptr %l93, i32 0, i32 13
  %t336 = load i64, ptr %l14, !tbaa !24
  store i64 %t336, ptr %t335, !tbaa !24
  %t337 = getelementptr %"compiler/diag:Diagnostics", ptr %l93, i32 0, i32 14
  %t338 = load i1, ptr %l15, !tbaa !21
  store i1 %t338, ptr %t337, !tbaa !21
  %t339 = getelementptr %"compiler/diag:Diagnostics", ptr %l93, i32 0, i32 15
  %t340 = load i1, ptr %l16, !tbaa !21
  store i1 %t340, ptr %t339, !tbaa !21
  %t341 = getelementptr %"compiler/diag:Diagnostics", ptr %l93, i32 0, i32 16
  %t342 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l17
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t342, ptr %t341
  %t343 = getelementptr %"compiler/diag:Diagnostics", ptr %l93, i32 0, i32 17
  %t344 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l18
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t344, ptr %t343
  %t345 = getelementptr %"compiler/diag:Diagnostics", ptr %l93, i32 0, i32 18
  %t346 = load { i64, [3 x i64] }, ptr %l19
  store { i64, [3 x i64] } %t346, ptr %t345
  %t347 = getelementptr %"compiler/diag:Diagnostics", ptr %l93, i32 0, i32 19
  %t348 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t348, ptr %t347, !tbaa !27
  %t349 = getelementptr %"compiler/diag:Diagnostics", ptr %l93, i32 0, i32 20
  %t350 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t350, ptr %t349, !tbaa !27
  %t351 = getelementptr %"compiler/diag:Diagnostics", ptr %l93, i32 0, i32 21
  %t352 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t352, ptr %t351, !tbaa !27
  %t353 = getelementptr %"compiler/diag:Diagnostics", ptr %l93, i32 0, i32 22
  %t354 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t354, ptr %t353, !tbaa !27
  %t355 = getelementptr %"compiler/diag:Diagnostics", ptr %l93, i32 0, i32 23
  %t356 = load i1, ptr %l24, !tbaa !21
  store i1 %t356, ptr %t355, !tbaa !21
  %t357 = getelementptr %"compiler/diag:Diagnostics", ptr %l93, i32 0, i32 24
  %t358 = load i1, ptr %l25, !tbaa !21
  store i1 %t358, ptr %t357, !tbaa !21
  %t359 = getelementptr %"compiler/diag:Diagnostics", ptr %l93, i32 0, i32 25
  %t360 = load i1, ptr %l26, !tbaa !21
  store i1 %t360, ptr %t359, !tbaa !21
  %t361 = getelementptr %"compiler/diag:Diagnostics", ptr %l93, i32 0, i32 26
  %t362 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l27
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t362, ptr %t361
  %t363 = getelementptr %"compiler/diag:Diagnostics", ptr %l93, i32 0, i32 27
  %t364 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l28
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t364, ptr %t363
  %t365 = getelementptr %"compiler/diag:Diagnostics", ptr %l93, i32 0, i32 28
  %t366 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l29
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t366, ptr %t365
  %t367 = getelementptr %"compiler/diag:Diagnostics", ptr %l93, i32 0, i32 29
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t308, ptr %t367
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l93, i64 704, i1 false)
  br label %ret
ret:
  ret void
}

declare void @__olang_check_failed(ptr) cold noreturn
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %dh = load ptr, ptr %dheadptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  %hasd = icmp ne ptr %dh, null
  %owns = or i1 %hasf, %hasd
  br i1 %owns, label %owned, label %chunks
owned:
  call void @__olang_scope_close_owned(ptr %scope)
  br label %chunks
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d0 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d1 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"S8a" }>, align 8
@.d2 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"error" }>, align 8
@.d3 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"note" }>, align 8
@.d4 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"help" }>, align 8
define available_externally ptr @__olang_scope_hold(ptr %s) alwaysinline {
entry:
  %none = icmp eq ptr %s, null
  br i1 %none, label %plain, label %look
look:
  ; atomic: on a scope that is no stand-in this word is its parts list, which other threads push onto (__olang_scope_part)
  %mp = getelementptr %olang.scope, ptr %s, i32 0, i32 4
  %m = load atomic ptr, ptr %mp monotonic, align 8
  %fresh = icmp eq ptr %m, @__olang_standin_mark
  br i1 %fresh, label %make, label %kept
kept:
  %mi = ptrtoint ptr %m to i64
  %bit = and i64 %mi, 1
  %has = icmp ne i64 %bit, 0
  br i1 %has, label %keeper, label %plain
keeper:
  %ki = and i64 %mi, -2
  %k = inttoptr i64 %ki to ptr
  ret ptr %k
make:
  %f = call ptr @__olang_standin_keeper(ptr %s)
  ret ptr %f
plain:
  ret ptr %s
}
@olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1 = weak hidden constant i1 false
declare ptr @__olang_region_make(ptr) noinline
define available_externally noalias ptr @__olang_held_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@olang_2esole_2ecompiler_2fdiag_3arecord_2e1 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fdiag_3arecord_2e2 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fdiag_3anote_2e2 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fdiag_3acontext_2e1 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fdiag_3aDiagnostics_2e19 = weak hidden constant i1 false
declare void @__olang_region_release(ptr) noinline
@olang_2esole_2ecompiler_2fdiag_3aDiagnostics_2e20 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fdiag_3aDiagnostics_2e21 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fdiag_3aDiagnostics_2e22 = weak hidden constant i1 false
@.d5 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"1" }>, align 8
@.d6 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"0" }>, align 8
@.d7 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"compilation successful" }>, align 8
@.d8 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
@.d9 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"1;31" }>, align 8
@.d10 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d11 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"s" }>, align 8
@.d12 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"0" }>, align 8
@.d13 = private constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c"compilation failed with " }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d14 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" error" }>, align 8
@.d15 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d16 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"1;31" }>, align 8
@.d17 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"0" }>, align 8
@.d18 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"error:" }>, align 8
@.d19 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d20 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"1;31" }>, align 8
@.d21 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"0" }>, align 8
@.d22 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"error[" }>, align 8
@.d23 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"]:" }>, align 8
@.d24 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d25 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" | " }>, align 8
@.d26 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"..." }>, align 8
@.d27 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"..." }>, align 8
@.d28 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"\0A      | " }>, align 8
@.d29 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"   " }>, align 8
@.d30 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"1;32" }>, align 8
@.d31 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"0" }>, align 8
@.d32 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"1" }>, align 8
@.d33 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"olang" }>, align 8
@.d34 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
@.d35 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
@.d36 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
@.d37 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"0" }>, align 8
@.d38 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"note" }>, align 8
@.d39 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d40 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"help" }>, align 8
@.d41 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"note" }>, align 8
@.d42 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"error" }>, align 8
@.d43 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"warning" }>, align 8
@.d44 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"1;35" }>, align 8
@.d45 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"1;36" }>, align 8
@.d46 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"0" }>, align 8
@.d47 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"warning[" }>, align 8
@.d48 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"]:" }>, align 8
@.d49 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d50 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"0" }>, align 8
@.d51 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"note:" }>, align 8
@.d52 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
define linkonce_odr i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2fdiag_3aWhere(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %t1, !range !{i64 0, i64 4}
  store i64 %t2, ptr %l3, !tbaa !24
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t4 = load i64, ptr %t3, !range !{i64 0, i64 4}
  %t5 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp eq i64 %t5, %t4
  br i1 %t7, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb13
bb2:
  %t9 = load i64, ptr %l3, !tbaa !24
  switch i64 %t9, label %bb3 [ i64 1, label %bb4 i64 2, label %bb5 i64 3, label %bb6 ]
bb3:
  br label %bb13
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr { i64, [3 x i64] }, ptr %t10, i32 0, i32 1
  %t12 = getelementptr { i64 }, ptr %t11, i32 0, i32 0
  %t13 = load i64, ptr %t12
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr { i64, [3 x i64] }, ptr %t14, i32 0, i32 1
  %t16 = getelementptr { i64 }, ptr %t15, i32 0, i32 0
  %t17 = load i64, ptr %t16
  %t20 = icmp eq i64 %t13, %t17
  br i1 %t20, label %bb7, label %bb1
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr { i64, [3 x i64] }, ptr %t22, i32 0, i32 1
  %t24 = getelementptr { i64, i64 }, ptr %t23, i32 0, i32 0
  %t25 = load i64, ptr %t24
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [3 x i64] }, ptr %t26, i32 0, i32 1
  %t28 = getelementptr { i64, i64 }, ptr %t27, i32 0, i32 0
  %t29 = load i64, ptr %t28
  %t32 = icmp eq i64 %t25, %t29
  br i1 %t32, label %bb8, label %bb1
bb6:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr { i64, [3 x i64] }, ptr %t34, i32 0, i32 1
  %t36 = getelementptr { i64, i64, i64 }, ptr %t35, i32 0, i32 0
  %t37 = load i64, ptr %t36
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr { i64, [3 x i64] }, ptr %t38, i32 0, i32 1
  %t40 = getelementptr { i64, i64, i64 }, ptr %t39, i32 0, i32 0
  %t41 = load i64, ptr %t40
  %t44 = icmp eq i64 %t37, %t41
  br i1 %t44, label %bb10, label %bb1
bb7:
  br label %bb3
bb8:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr { i64, [3 x i64] }, ptr %t46, i32 0, i32 1
  %t48 = getelementptr { i64, i64 }, ptr %t47, i32 0, i32 1
  %t49 = load i64, ptr %t48
  %t50 = load ptr, ptr %l1, !tbaa !29
  %t51 = getelementptr { i64, [3 x i64] }, ptr %t50, i32 0, i32 1
  %t52 = getelementptr { i64, i64 }, ptr %t51, i32 0, i32 1
  %t53 = load i64, ptr %t52
  %t56 = icmp eq i64 %t49, %t53
  br i1 %t56, label %bb9, label %bb1
bb9:
  br label %bb3
bb10:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr { i64, [3 x i64] }, ptr %t58, i32 0, i32 1
  %t60 = getelementptr { i64, i64, i64 }, ptr %t59, i32 0, i32 1
  %t61 = load i64, ptr %t60
  %t62 = load ptr, ptr %l1, !tbaa !29
  %t63 = getelementptr { i64, [3 x i64] }, ptr %t62, i32 0, i32 1
  %t64 = getelementptr { i64, i64, i64 }, ptr %t63, i32 0, i32 1
  %t65 = load i64, ptr %t64
  %t68 = icmp eq i64 %t61, %t65
  br i1 %t68, label %bb11, label %bb1
bb11:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr { i64, [3 x i64] }, ptr %t70, i32 0, i32 1
  %t72 = getelementptr { i64, i64, i64 }, ptr %t71, i32 0, i32 2
  %t73 = load i64, ptr %t72
  %t74 = load ptr, ptr %l1, !tbaa !29
  %t75 = getelementptr { i64, [3 x i64] }, ptr %t74, i32 0, i32 1
  %t76 = getelementptr { i64, i64, i64 }, ptr %t75, i32 0, i32 2
  %t77 = load i64, ptr %t76
  %t80 = icmp eq i64 %t73, %t77
  br i1 %t80, label %bb12, label %bb1
bb12:
  br label %bb3
bb13:
  %t82 = load i1, ptr %l2, !tbaa !21
  store i1 %t82, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d53 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@olang_2esole_2ecompiler__2fdiag__2ecompiler__2fdiag__3aDiagnostics__2ewritten_2elocal_2e5 = weak hidden constant i1 false
declare ptr @__olang_region_or(ptr, ptr)
declare ptr @__olang_region_home(ptr)
declare void @__olang_region_settle_in(ptr, ptr)
define linkonce_odr i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2fmsgs_3aDiag(ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t2 = load i32, ptr %a0, !range !{i32 0, i32 949}
  %t3 = sext i32 %t2 to i64
  %t5 = load i32, ptr %a1, !range !{i32 0, i32 949}
  %t6 = sext i32 %t5 to i64
  %t9 = icmp eq i64 %t3, %t6
  br i1 %t9, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb3
bb2:
  br label %bb3
bb3:
  %t11 = load i1, ptr %l2, !tbaa !21
  store i1 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
@olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0 = weak hidden constant i1 false
declare ptr @__olang_region_make_part(ptr) noinline
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @__olang_region_drop(ptr) noinline
declare void @__olang_region_release_part(ptr, i64) noinline
define available_externally void @__olang_scope_escape(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %un = icmp eq ptr %o, null
  br i1 %un, label %claim, label %done
claim:
  %me = load ptr, ptr @__olang_self
  store atomic ptr %me, ptr %op monotonic, align 8
  br label %done
done:
  ret void
}
define internal i1 @olang_lambda_54(ptr %env, i64 %a0, i64 %a1) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %rv = alloca i1
  store i64 %a0, ptr %l0
  store i64 %a1, ptr %l1
  %cp0 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load { i64, ptr }, ptr %cp0, !tbaa !28
  store { i64, ptr } %cv0, ptr %l2
  %cp1 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr }, ptr %env, i32 0, i32 1
  %cv1 = load { i64, ptr }, ptr %cp1, !tbaa !28
  store { i64, ptr } %cv1, ptr %l3
  %cp2 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr }, ptr %env, i32 0, i32 2
  %cv2 = load { i64, ptr }, ptr %cp2, !tbaa !28
  store { i64, ptr } %cv2, ptr %l4
  %vq0 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr }, ptr %env, i32 0, i32 3
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  %vq1 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr }, ptr %env, i32 0, i32 4
  %vr1 = load ptr, ptr %vq1, !tbaa !28
  %vc1 = call ptr @__olang_capture_scope(ptr %vr1)
  %vq2 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr }, ptr %env, i32 0, i32 5
  %vr2 = load ptr, ptr %vq2, !tbaa !28
  %vc2 = call ptr @__olang_capture_scope(ptr %vr2)
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t1, ptr %l5, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t2, ptr %l6, !tbaa !27
  %t3 = load i64, ptr %l0, !tbaa !24
  %t5 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t6 = load ptr, ptr %t5, !tbaa !27
  %t7 = getelementptr i64, ptr %t6, i64 %t3
  %t8 = load i64, ptr %t7, !tbaa !34
  %t10 = add i64 %t8, 1
  %t12 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr i64, ptr %t13, i64 %t10
  %t15 = load i64, ptr %t14, !tbaa !34
  %t16 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t16, ptr %l11, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t17, ptr %l12, !tbaa !27
  %t18 = load i64, ptr %l1, !tbaa !24
  %t20 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr i64, ptr %t21, i64 %t18
  %t23 = load i64, ptr %t22, !tbaa !34
  %t25 = add i64 %t23, 1
  %t27 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = getelementptr i64, ptr %t28, i64 %t25
  %t30 = load i64, ptr %t29, !tbaa !34
  %t33 = icmp ne i64 %t15, %t30
  br i1 %t33, label %bb1, label %bb2
bb1:
  %t35 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t35, ptr %l18, !tbaa !27
  %t36 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t36, ptr %l19, !tbaa !27
  %t37 = load i64, ptr %l0, !tbaa !24
  %t39 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !27
  %t41 = getelementptr i64, ptr %t40, i64 %t37
  %t42 = load i64, ptr %t41, !tbaa !34
  %t44 = add i64 %t42, 1
  %t46 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = getelementptr i64, ptr %t47, i64 %t44
  %t49 = load i64, ptr %t48, !tbaa !34
  %t50 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t50, ptr %l24, !tbaa !27
  %t51 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t51, ptr %l25, !tbaa !27
  %t52 = load i64, ptr %l1, !tbaa !24
  %t54 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = getelementptr i64, ptr %t55, i64 %t52
  %t57 = load i64, ptr %t56, !tbaa !34
  %t59 = add i64 %t57, 1
  %t61 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !27
  %t63 = getelementptr i64, ptr %t62, i64 %t59
  %t64 = load i64, ptr %t63, !tbaa !34
  %t67 = icmp slt i64 %t49, %t64
  store i1 %t67, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t69 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t69, ptr %l31, !tbaa !27
  %t70 = load i64, ptr %l0, !tbaa !24
  %t72 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = getelementptr i64, ptr %t73, i64 %t70
  %t75 = load i64, ptr %t74, !tbaa !34
  %t76 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t76, ptr %l34, !tbaa !27
  %t77 = load i64, ptr %l1, !tbaa !24
  %t79 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = getelementptr i64, ptr %t80, i64 %t77
  %t82 = load i64, ptr %t81, !tbaa !34
  %t85 = icmp ne i64 %t75, %t82
  br i1 %t85, label %bb4, label %bb5
bb4:
  %t87 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t87, ptr %l38, !tbaa !27
  %t88 = load i64, ptr %l0, !tbaa !24
  %t90 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t91 = load ptr, ptr %t90, !tbaa !27
  %t92 = getelementptr i64, ptr %t91, i64 %t88
  %t93 = load i64, ptr %t92, !tbaa !34
  %t94 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t94, ptr %l41, !tbaa !27
  %t95 = load i64, ptr %l1, !tbaa !24
  %t97 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !27
  %t99 = getelementptr i64, ptr %t98, i64 %t95
  %t100 = load i64, ptr %t99, !tbaa !34
  %t103 = icmp slt i64 %t93, %t100
  store i1 %t103, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t105 = load i64, ptr %l0, !tbaa !24
  %t106 = load i64, ptr %l1, !tbaa !24
  %t109 = icmp slt i64 %t105, %t106
  store i1 %t109, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d55 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"C2d" }>, align 8
@.d56 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"T17c" }>, align 8
@.d57 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"- " }>, align 8
@.d58 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"**" }>, align 8
@.d59 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c".**" }>, align 8
@.d60 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" (" }>, align 8
@olang_2esole_2ecompiler_2fdiag_3aDiagnostics_2e1 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fdiag_3aDiagnostics_2e2 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fdiag_3aDiagnostics_2e3 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fdiag_3aDiagnostics_2e4 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fdiag_3aDiagnostics_2e5 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fdiag_3aDiagnostics_2e6 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fdiag_3aDiagnostics_2e9 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fdiag_3aDiagnostics_2e10 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fdiag_3aDiagnostics_2e11 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fdiag_3aDiagnostics_2e16 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fdiag_3aDiagnostics_2e17 = weak hidden constant i1 false
@.d61 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d62 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d63 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d64 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler_2fdiag_3aDiagnostics_2e27 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fdiag_3aDiagnostics_2e28 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fdiag_3aDiagnostics_2e29 = weak hidden constant i1 false
declare void @__olang_scope_close_owned(ptr) noinline
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@__olang_standin_mark = external global i64
declare ptr @__olang_standin_keeper(ptr) noinline
define available_externally noalias ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  %head = load ptr, ptr %scope, !tbaa !59
  %isslot = icmp eq ptr %head, @__olang_slot_chunk
  br i1 %isslot, label %slot, label %plain
slot:
  %s = call ptr @__olang_slot_alloc(ptr %scope, i64 %rawsize)
  ret ptr %s
plain:
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
@__olang_self = external thread_local(initialexec) global ptr
define available_externally ptr @__olang_capture_scope(ptr %s) alwaysinline {
entry:
  %isprog = icmp eq ptr %s, null
  br i1 %isprog, label %prog, label %mine
prog:
  %p = load ptr, ptr @__olang_prog_scope
  ret ptr %p
mine:
  %m = call ptr @__olang_scope_mine(ptr %s)
  ret ptr %m
}
@__olang_slot_chunk = external global %olang.chunk
declare noalias ptr @__olang_slot_alloc(ptr, i64) noinline
@__olang_prog_scope = external thread_local(initialexec) global ptr
define available_externally ptr @__olang_scope_mine(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %me = load ptr, ptr @__olang_self
  %own = icmp eq ptr %o, %me
  br i1 %own, label %mine, label %slow
mine:
  ret ptr %s
slow:
  %r = call ptr @__olang_scope_mine_slow(ptr %s)
  ret ptr %r
}
declare ptr @__olang_scope_mine_slow(ptr) noinline
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare i8 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eToUpper(i8 %a0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_c5879cd561f524a8_9a69d9d7af5b002c = external constant [0 x i8]
@olang_loc_278b8075a2f80085_5f77718140d89fd9 = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %v0, { i64, ptr } %a0, i8 %a1)
@olang_loc_5357591f61d3ec66_4083edcb137c28ba = external constant [0 x i8]
@olang_loc_40a6fbbd452759c3_7354b3156286cb97 = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %a0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_eb08610c80fa023c_21bad482e9cc9598 = external constant [0 x i8]
declare i1 @compiler_2fdiag_2eUntidy(ptr %v0, { i64, ptr } %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3arecord_3e_2eLen_3ccompiler_2fdiag_3arecord_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3arecord_3e_2eTruncate_3ccompiler_2fdiag_3arecord_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3anote_3e_2eLen_3ccompiler_2fdiag_3anote_3e(ptr %v0, ptr %a0)
declare %"compiler/diag:note" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3anote_3e_2eAt_3ccompiler_2fdiag_3anote_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3anote_3e_2eSetAt_3ccompiler_2fdiag_3anote_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/diag:note" %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3anote_3e_2eTruncate_3ccompiler_2fdiag_3anote_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eTruncate_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/diag:record" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3arecord_3e_2eAt_3ccompiler_2fdiag_3arecord_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eputPlain(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, [3 x i64] } %a2, { i64, ptr } %a3, { i64, ptr } %a4)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H075fcab2d197e70ad987ab163aa86164(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eClear_3cBool_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %a0)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %a0, i1 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3arecord_3e_2eClear_3ccompiler_2fdiag_3arecord_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3anote_3e_2eClear_3ccompiler_2fdiag_3anote_3e(ptr %v0, ptr %a0)
declare %"compiler/diag:record" @compiler_2fdiag_3arecord_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, [3 x i64] } %a0, { i64, ptr } %a1, { i64, ptr } %a2, i32 %a3, i64 %a4, i1 %a5)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3arecord_3e_2ePush_3ccompiler_2fdiag_3arecord_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/diag:record" %a1)
declare %"compiler/diag:note" @compiler_2fdiag_3anote_2ector(ptr %v0, ptr %v1, i64 %a0, { i64, [3 x i64] } %a1, { i64, ptr } %a2, i1 %a3, i1 %a4)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3anote_3e_2ePush_3ccompiler_2fdiag_3anote_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/diag:note" %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3acontext_3e_2eClear_3ccompiler_2fdiag_3acontext_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3acontext_3e_2eLen_3ccompiler_2fdiag_3acontext_3e(ptr %v0, ptr %a0)
declare %"compiler/diag:context" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3acontext_3e_2eAt_3ccompiler_2fdiag_3acontext_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/diag:context" @compiler_2fdiag_3acontext_2ector(ptr %v0, ptr %v1, { i64, [3 x i64] } %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3acontext_3e_2ePush_3ccompiler_2fdiag_3acontext_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/diag:context" %a1)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2esgr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
@G_2ecompiler_2fdiag_2eChosen = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@olang_loc_c64be6b7d7a3c96a_e11c2151589de926 = external constant [0 x i8]
declare { i64, i64 } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2elineOf(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
@G_2ecompiler_2fdiag_2eExcerptMax = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\A0\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fdiag_2eExcerptAround = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\46\00\00\00\00\00\00\00" }>, align 8
declare { i64, ptr } @std_2fprelude_2ftext_2eI64_2ePadStart(ptr %v0, i64 %a0, i64 %a1, i8 %a2)
@olang_loc_63cbd536ec427bfa_9ebcb75929bac85e = external constant [0 x i8]
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eprogramUse(ptr %v0, ptr %a0, { i64, [3 x i64] } %a1)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2epushOwn(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, [3 x i64] } %a2, %"compiler/diagmsg:Msg" %a3)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoteInLibrary(ptr %v0)
@olang_loc_4dcb4d0a5bf00c4a_ab355dfc0aa866a6 = external constant [0 x i8]
@olang_loc_661de3b27f7b1d1f_a886f9f6d8c58a3b = external constant [0 x i8]
@olang_loc_7549250239c3dfbc_e6bed168a21d4f58 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
@olang_loc_cc4d2c1e8d3adf92_7a1efbc027515c6 = external constant [0 x i8]
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_c2f4506e7327945e_f97af0abefd7d9d2 = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %v0, ptr %v1, ptr %a0)
declare void @std_2fprelude_2farray_2eArray_3cI64_3e_2eSort_3cI64_2c_20_3f_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1c, ptr %a1e)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_122ae7ff15fe68f_4bf017428e5c5a9b = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %a0)
@olang_loc_f601f9616f628c92_63c657ce4b964a9e = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLower(i8 %a0)
@olang_loc_34cb3e047b5a9691_df78e9c71a0d19fd = external constant [0 x i8]
@olang_loc_44be31be33a055a4_da5ef357ed133fa0 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3arecord_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3anote_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3acontext_3e_2ector(ptr %v0, i64 %a0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
