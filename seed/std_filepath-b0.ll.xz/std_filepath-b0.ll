; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
define dso_local { i64, ptr } @std_2ffilepath_2eClean(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i1
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i1
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %lp14 = alloca ptr
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l29 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l44 = alloca { i64, ptr }
  %l48 = alloca i1
  %l53 = alloca i1
  %l54 = alloca { i64, ptr }
  %l62 = alloca { i64, ptr }
  %l66 = alloca i1
  %l67 = alloca { i64, ptr }
  %l72 = alloca i1
  %l77 = alloca i1
  %l78 = alloca { i64, ptr }
  %l95 = alloca i1
  %l119 = alloca i1
  %l122 = alloca i1
  %l125 = alloca i1
  %l135 = alloca i1
  %l136 = alloca { i64, ptr }
  %l142 = alloca { i64, ptr }
  %l153 = alloca { i64, ptr }
  %l158 = alloca i64
  %l161 = alloca i64
  %l170 = alloca i64
  %l173 = alloca i1
  %l185 = alloca { i64, ptr }
  %l193 = alloca { i64, ptr }
  %l194 = alloca i64
  %l195 = alloca i64
  %l200 = alloca i64
  %l207 = alloca i64
  %l210 = alloca i64
  %l219 = alloca i64
  %l222 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l1, !tbaa !24
  %t5 = load i64, ptr %l1, !tbaa !24
  %t7 = icmp eq i64 %t5, 0
  br i1 %t7, label %bb1, label %bb2
bb1:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d0, i32 0, i32 1) }, ptr %l25, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t9 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t9, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t10 = load i64, ptr %l1, !tbaa !24
  store i64 %t10, ptr %l26, !tbaa !24
  %t11 = load i64, ptr %l26, !tbaa !24
  %t12 = icmp sge i64 %t11, 0
  br i1 %t12, label %bb4, label %bb5
bb4:
  %t14 = load i64, ptr %l26, !tbaa !24
  %t15 = mul i64 %t14, 1
  %t16 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t15)
  %t17 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  store { i64, ptr } %t18, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t20 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t20, ptr %l29, !tbaa !27
  %t21 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr i8, ptr %t22, i64 0
  %t24 = load i8, ptr %t23, !tbaa !32
  %t26 = icmp eq i8 %t24, 47
  store i1 %t26, ptr %l4, !tbaa !21
  store i64 0, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  %t28 = load i1, ptr %l4, !tbaa !21
  br i1 %t28, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_71a6929ab52159a_17fdf02a3251bece)
  unreachable
bb6:
  %t30 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !27
  %t32 = getelementptr i8, ptr %t31, i64 0
  store i8 47, ptr %t32, !tbaa !32
  store i64 1, ptr %l3, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  br label %bb8
bb7:
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t33 = load i64, ptr %l5, !tbaa !24
  %t34 = load i64, ptr %l1, !tbaa !24
  %t37 = icmp slt i64 %t33, %t34
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb10, label %bb11
bb10:
  br label %bb77
bb11:
  br label %bb12
bb12:
  %t41 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t41, ptr %l37, !tbaa !27
  %t42 = load i64, ptr %l5, !tbaa !24
  %t44 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = getelementptr i8, ptr %t45, i64 %t42
  %t47 = load i8, ptr %t46, !tbaa !32
  %t49 = icmp eq i8 %t47, 47
  br i1 %t49, label %bb13, label %bb14
bb13:
  %t51 = load i64, ptr %l5, !tbaa !24
  %t54 = add i64 %t51, 1
  store i64 %t54, ptr %l5, !tbaa !24
  br label %bb75
bb14:
  %t56 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t56, ptr %l44, !tbaa !27
  %t57 = load i64, ptr %l5, !tbaa !24
  %t59 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = getelementptr i8, ptr %t60, i64 %t57
  %t62 = load i8, ptr %t61, !tbaa !32
  %t64 = icmp eq i8 %t62, 46
  br i1 %t64, label %bb15, label %bb16
bb15:
  %t66 = load i64, ptr %l5, !tbaa !24
  %t68 = add i64 %t66, 1
  %t69 = load i64, ptr %l1, !tbaa !24
  %t72 = icmp eq i64 %t68, %t69
  br i1 %t72, label %bb17, label %bb18
bb16:
  store i1 false, ptr %l48, !tbaa !21
  br label %bb20
bb17:
  store i1 true, ptr %l53, !tbaa !21
  br label %bb19
bb18:
  %t74 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t74, ptr %l54, !tbaa !27
  %t75 = load i64, ptr %l5, !tbaa !24
  %t77 = add i64 %t75, 1
  %t79 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = getelementptr i8, ptr %t80, i64 %t77
  %t82 = load i8, ptr %t81, !tbaa !32
  %t84 = icmp eq i8 %t82, 47
  store i1 %t84, ptr %l53, !tbaa !21
  br label %bb19
bb19:
  %t86 = load i1, ptr %l53, !tbaa !21
  store i1 %t86, ptr %l48, !tbaa !21
  br label %bb20
bb20:
  %t87 = load i1, ptr %l48, !tbaa !21
  br i1 %t87, label %bb21, label %bb22
bb21:
  %t88 = load i64, ptr %l5, !tbaa !24
  %t91 = add i64 %t88, 1
  store i64 %t91, ptr %l5, !tbaa !24
  br label %bb74
bb22:
  %t93 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t93, ptr %l62, !tbaa !27
  %t94 = load i64, ptr %l5, !tbaa !24
  %t96 = getelementptr { i64, ptr }, ptr %l62, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !27
  %t98 = getelementptr i8, ptr %t97, i64 %t94
  %t99 = load i8, ptr %t98, !tbaa !32
  %t101 = icmp eq i8 %t99, 46
  br i1 %t101, label %bb23, label %bb24
bb23:
  %t103 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t103, ptr %l67, !tbaa !27
  %t104 = load i64, ptr %l5, !tbaa !24
  %t106 = add i64 %t104, 1
  %t108 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !27
  %t110 = getelementptr i8, ptr %t109, i64 %t106
  %t111 = load i8, ptr %t110, !tbaa !32
  %t113 = icmp eq i8 %t111, 46
  store i1 %t113, ptr %l66, !tbaa !21
  br label %bb25
bb24:
  store i1 false, ptr %l66, !tbaa !21
  br label %bb25
bb25:
  %t115 = load i1, ptr %l66, !tbaa !21
  br i1 %t115, label %bb26, label %bb27
bb26:
  %t116 = load i64, ptr %l5, !tbaa !24
  %t118 = add i64 %t116, 2
  %t119 = load i64, ptr %l1, !tbaa !24
  %t122 = icmp eq i64 %t118, %t119
  br i1 %t122, label %bb28, label %bb29
bb27:
  store i1 false, ptr %l72, !tbaa !21
  br label %bb31
bb28:
  store i1 true, ptr %l77, !tbaa !21
  br label %bb30
bb29:
  %t124 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t124, ptr %l78, !tbaa !27
  %t125 = load i64, ptr %l5, !tbaa !24
  %t127 = add i64 %t125, 2
  %t129 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t130 = load ptr, ptr %t129, !tbaa !27
  %t131 = getelementptr i8, ptr %t130, i64 %t127
  %t132 = load i8, ptr %t131, !tbaa !32
  %t134 = icmp eq i8 %t132, 47
  store i1 %t134, ptr %l77, !tbaa !21
  br label %bb30
bb30:
  %t136 = load i1, ptr %l77, !tbaa !21
  store i1 %t136, ptr %l72, !tbaa !21
  br label %bb31
bb31:
  %t137 = load i1, ptr %l72, !tbaa !21
  br i1 %t137, label %bb32, label %bb33
bb32:
  %t138 = load i64, ptr %l5, !tbaa !24
  %t141 = add i64 %t138, 2
  store i64 %t141, ptr %l5, !tbaa !24
  %t143 = load i64, ptr %l3, !tbaa !24
  %t144 = load i64, ptr %l6, !tbaa !24
  %t147 = icmp sgt i64 %t143, %t144
  br i1 %t147, label %bb34, label %bb35
bb33:
  %t149 = load i1, ptr %l4, !tbaa !21
  br i1 %t149, label %bb52, label %bb53
bb34:
  %t151 = load i64, ptr %l3, !tbaa !24
  %t154 = sub i64 %t151, 1
  store i64 %t154, ptr %l3, !tbaa !24
  br label %bb36
bb35:
  %t156 = load i1, ptr %l4, !tbaa !21
  %t158 = xor i1 %t156, true
  br i1 %t158, label %bb45, label %bb46
bb36:
  %t160 = load i64, ptr %l3, !tbaa !24
  %t161 = load i64, ptr %l6, !tbaa !24
  %t164 = icmp sgt i64 %t160, %t161
  br i1 %t164, label %bb37, label %bb38
bb37:
  %t166 = load i64, ptr %l3, !tbaa !24
  %t168 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t169 = load ptr, ptr %t168, !tbaa !27
  %t170 = getelementptr i8, ptr %t169, i64 %t166
  %t171 = load i8, ptr %t170, !tbaa !32
  %t173 = icmp ne i8 %t171, 47
  store i1 %t173, ptr %l95, !tbaa !21
  br label %bb39
bb38:
  store i1 false, ptr %l95, !tbaa !21
  br label %bb39
bb39:
  %t175 = load i1, ptr %l95, !tbaa !21
  %t176 = xor i1 %t175, true
  br i1 %t176, label %bb40, label %bb41
bb40:
  br label %bb44
bb41:
  br label %bb42
bb42:
  %t178 = load i64, ptr %l3, !tbaa !24
  %t181 = sub i64 %t178, 1
  store i64 %t181, ptr %l3, !tbaa !24
  br label %bb43
bb43:
  br label %bb36
bb44:
  br label %bb51
bb45:
  %t183 = load i64, ptr %l3, !tbaa !24
  %t185 = icmp sgt i64 %t183, 0
  br i1 %t185, label %bb47, label %bb48
bb46:
  br label %bb50
bb47:
  %t187 = load i64, ptr %l3, !tbaa !24
  %t189 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t190 = load ptr, ptr %t189, !tbaa !27
  %t191 = getelementptr i8, ptr %t190, i64 %t187
  store i8 47, ptr %t191, !tbaa !32
  %t192 = load i64, ptr %l3, !tbaa !24
  %t195 = add i64 %t192, 1
  store i64 %t195, ptr %l3, !tbaa !24
  br label %bb49
bb48:
  br label %bb49
bb49:
  %t197 = load i64, ptr %l3, !tbaa !24
  %t199 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t200 = load ptr, ptr %t199, !tbaa !27
  %t201 = getelementptr i8, ptr %t200, i64 %t197
  store i8 46, ptr %t201, !tbaa !32
  %t202 = load i64, ptr %l3, !tbaa !24
  %t204 = add i64 %t202, 1
  %t206 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t207 = load ptr, ptr %t206, !tbaa !27
  %t208 = getelementptr i8, ptr %t207, i64 %t204
  store i8 46, ptr %t208, !tbaa !32
  %t209 = load i64, ptr %l3, !tbaa !24
  %t212 = add i64 %t209, 2
  store i64 %t212, ptr %l3, !tbaa !24
  %t214 = load i64, ptr %l3, !tbaa !24
  store i64 %t214, ptr %l6, !tbaa !24
  br label %bb50
bb50:
  br label %bb51
bb51:
  br label %bb73
bb52:
  %t216 = load i64, ptr %l3, !tbaa !24
  %t218 = icmp ne i64 %t216, 1
  store i1 %t218, ptr %l119, !tbaa !21
  br label %bb54
bb53:
  store i1 false, ptr %l119, !tbaa !21
  br label %bb54
bb54:
  %t220 = load i1, ptr %l119, !tbaa !21
  br i1 %t220, label %bb55, label %bb56
bb55:
  store i1 true, ptr %l122, !tbaa !21
  br label %bb60
bb56:
  %t221 = load i1, ptr %l4, !tbaa !21
  %t223 = xor i1 %t221, true
  br i1 %t223, label %bb57, label %bb58
bb57:
  %t225 = load i64, ptr %l3, !tbaa !24
  %t227 = icmp ne i64 %t225, 0
  store i1 %t227, ptr %l125, !tbaa !21
  br label %bb59
bb58:
  store i1 false, ptr %l125, !tbaa !21
  br label %bb59
bb59:
  %t229 = load i1, ptr %l125, !tbaa !21
  store i1 %t229, ptr %l122, !tbaa !21
  br label %bb60
bb60:
  %t230 = load i1, ptr %l122, !tbaa !21
  br i1 %t230, label %bb61, label %bb62
bb61:
  %t231 = load i64, ptr %l3, !tbaa !24
  %t233 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t234 = load ptr, ptr %t233, !tbaa !27
  %t235 = getelementptr i8, ptr %t234, i64 %t231
  store i8 47, ptr %t235, !tbaa !32
  %t236 = load i64, ptr %l3, !tbaa !24
  %t239 = add i64 %t236, 1
  store i64 %t239, ptr %l3, !tbaa !24
  br label %bb63
bb62:
  br label %bb63
bb63:
  br label %bb64
bb64:
  %t241 = load i64, ptr %l5, !tbaa !24
  %t242 = load i64, ptr %l1, !tbaa !24
  %t245 = icmp slt i64 %t241, %t242
  br i1 %t245, label %bb65, label %bb66
bb65:
  %t247 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t247, ptr %l136, !tbaa !27
  %t248 = load i64, ptr %l5, !tbaa !24
  %t250 = getelementptr { i64, ptr }, ptr %l136, i32 0, i32 1
  %t251 = load ptr, ptr %t250, !tbaa !27
  %t252 = getelementptr i8, ptr %t251, i64 %t248
  %t253 = load i8, ptr %t252, !tbaa !32
  %t255 = icmp ne i8 %t253, 47
  store i1 %t255, ptr %l135, !tbaa !21
  br label %bb67
bb66:
  store i1 false, ptr %l135, !tbaa !21
  br label %bb67
bb67:
  %t257 = load i1, ptr %l135, !tbaa !21
  %t258 = xor i1 %t257, true
  br i1 %t258, label %bb68, label %bb69
bb68:
  br label %bb72
bb69:
  br label %bb70
bb70:
  %t260 = load i64, ptr %l3, !tbaa !24
  %t261 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t261, ptr %l142, !tbaa !27
  %t262 = load i64, ptr %l5, !tbaa !24
  %t264 = getelementptr { i64, ptr }, ptr %l142, i32 0, i32 1
  %t265 = load ptr, ptr %t264, !tbaa !27
  %t266 = getelementptr i8, ptr %t265, i64 %t262
  %t267 = load i8, ptr %t266, !tbaa !32
  %t270 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t271 = load ptr, ptr %t270, !tbaa !27
  %t272 = getelementptr i8, ptr %t271, i64 %t260
  store i8 %t267, ptr %t272, !tbaa !32
  %t273 = load i64, ptr %l3, !tbaa !24
  %t276 = add i64 %t273, 1
  store i64 %t276, ptr %l3, !tbaa !24
  %t278 = load i64, ptr %l5, !tbaa !24
  %t281 = add i64 %t278, 1
  store i64 %t281, ptr %l5, !tbaa !24
  br label %bb71
bb71:
  br label %bb64
bb72:
  br label %bb73
bb73:
  br label %bb74
bb74:
  br label %bb75
bb75:
  br label %bb76
bb76:
  br label %bb9
bb77:
  %t283 = load i64, ptr %l3, !tbaa !24
  %t285 = icmp eq i64 %t283, 0
  br i1 %t285, label %bb78, label %bb79
bb78:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d1, i32 0, i32 1) }, ptr %l153, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t287 = load { i64, ptr }, ptr %l153, !tbaa !27
  store { i64, ptr } %t287, ptr %rv
  br label %ret
bb79:
  br label %bb80
bb80:
  store i1 true, ptr %l7, !tbaa !21
  store i64 0, ptr %l8, !tbaa !24
  %t288 = load i64, ptr %l3, !tbaa !24
  store i64 %t288, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t290 = load i64, ptr %l9, !tbaa !24
  %t291 = load i64, ptr %l8, !tbaa !24
  %t294 = icmp sgt i64 %t290, %t291
  br i1 %t294, label %bb81, label %bb82
bb81:
  %t296 = load i64, ptr %l10, !tbaa !24
  %t298 = icmp sgt i64 %t296, 0
  br i1 %t298, label %bb83, label %bb84
bb82:
  store i64 0, ptr %l158, !tbaa !24
  br label %bb86
bb83:
  %t300 = load i64, ptr %l9, !tbaa !24
  %t301 = load i64, ptr %l8, !tbaa !24
  %t304 = sub i64 %t300, %t301
  %t305 = load i64, ptr %l10, !tbaa !24
  %t308 = add i64 %t304, %t305
  %t310 = sub i64 %t308, 1
  %t311 = load i64, ptr %l10, !tbaa !24
  %t314 = sdiv i64 %t310, %t311
  store i64 %t314, ptr %l161, !tbaa !24
  br label %bb85
bb84:
  store i64 0, ptr %l161, !tbaa !24
  br label %bb85
bb85:
  %t316 = load i64, ptr %l161, !tbaa !24
  store i64 %t316, ptr %l158, !tbaa !24
  br label %bb86
bb86:
  %t317 = load i64, ptr %l158, !tbaa !24
  store i64 %t317, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  %t318 = load i64, ptr %l11, !tbaa !24
  %t319 = sub i64 %t318, 1
  store i64 %t319, ptr %l170, !tbaa !24
  %t320 = load i64, ptr %l11, !tbaa !24
  %t321 = icmp slt i64 %t320, 2147483648
  %t322 = load i64, ptr %l12, !tbaa !24
  %t323 = icmp sge i64 %t322, 0
  %t326 = and i1 %t321, %t323
  store i1 %t326, ptr %l173, !tbaa !21
  br label %bb87
bb87:
  %t327 = load i64, ptr %l12, !tbaa !24
  %t328 = load i64, ptr %l11, !tbaa !24
  %t331 = icmp slt i64 %t327, %t328
  %t333 = xor i1 %t331, true
  br i1 %t333, label %bb88, label %bb89
bb88:
  br label %bb95
bb89:
  br label %bb90
bb90:
  %t335 = load i64, ptr %l8, !tbaa !24
  %t336 = load i64, ptr %l12, !tbaa !24
  %t337 = load i64, ptr %l10, !tbaa !24
  %t340 = mul i64 %t336, %t337
  %t343 = add i64 %t335, %t340
  store i64 %t343, ptr %l13, !tbaa !24
  %t345 = load i64, ptr %l13, !tbaa !24
  %t347 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t348 = load ptr, ptr %t347, !tbaa !27
  %t349 = getelementptr i8, ptr %t348, i64 %t345
  %t350 = load i8, ptr %t349, !tbaa !32
  %t351 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t351, ptr %l185, !tbaa !27
  %t352 = load i64, ptr %l13, !tbaa !24
  %t354 = getelementptr { i64, ptr }, ptr %l185, i32 0, i32 1
  %t355 = load ptr, ptr %t354, !tbaa !27
  %t356 = getelementptr i8, ptr %t355, i64 %t352
  %t357 = load i8, ptr %t356, !tbaa !32
  %t360 = icmp ne i8 %t350, %t357
  br i1 %t360, label %bb91, label %bb92
bb91:
  store i1 false, ptr %l7, !tbaa !21
  br label %bb95
bb92:
  br label %bb93
bb93:
  br label %bb94
bb94:
  %t362 = load i64, ptr %l12, !tbaa !24
  %t365 = add i64 %t362, 1
  store i64 %t365, ptr %l12, !tbaa !24
  br label %bb87
bb95:
  %t367 = load i1, ptr %l7, !tbaa !21
  br i1 %t367, label %bb96, label %bb97
bb96:
  %t369 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t369, ptr %l193, !tbaa !27
  %t370 = load i64, ptr %l3, !tbaa !24
  store i64 %t370, ptr %l194, !tbaa !24
  %t371 = load { i64, ptr }, ptr %l193, !tbaa !27
  %t372 = extractvalue { i64, ptr } %t371, 0
  store i64 %t372, ptr %l195, !tbaa !24
  %t373 = icmp sge i64 0, 0
  br i1 %t373, label %bb98, label %bb99
bb97:
  br label %bb104
bb98:
  %t375 = load i64, ptr %l194, !tbaa !24
  %t376 = icmp sle i64 0, %t375
  br i1 %t376, label %bb100, label %bb101
bb99:
  call void @__olang_check_failed(ptr @olang_loc_a602995b964ddbcf_b078a441454e17cb)
  unreachable
bb100:
  %t378 = load i64, ptr %l194, !tbaa !24
  %t379 = load i64, ptr %l195, !tbaa !24
  %t380 = icmp sle i64 %t378, %t379
  br i1 %t380, label %bb102, label %bb103
bb101:
  call void @__olang_check_failed(ptr @olang_loc_a602995b964ddbcf_b078a441454e17cb)
  unreachable
bb102:
  %t382 = getelementptr { i64, ptr }, ptr %l193, i32 0, i32 1
  %t383 = load ptr, ptr %t382, !tbaa !27
  %t384 = load i64, ptr %l194, !tbaa !24
  %t385 = getelementptr i8, ptr %t383, i64 0
  %t386 = sub i64 %t384, 0
  %t387 = insertvalue { i64, ptr } undef, i64 %t386, 0
  %t388 = insertvalue { i64, ptr } %t387, ptr %t385, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t388, ptr %rv
  br label %ret
bb103:
  call void @__olang_check_failed(ptr @olang_loc_a602995b964ddbcf_b078a441454e17cb)
  unreachable
bb104:
  %t390 = load i64, ptr %l3, !tbaa !24
  store i64 %t390, ptr %l200, !tbaa !24
  %t391 = load i64, ptr %l200, !tbaa !24
  %t392 = icmp sge i64 %t391, 0
  br i1 %t392, label %bb105, label %bb106
bb105:
  %t394 = load i64, ptr %l200, !tbaa !24
  %t395 = mul i64 %t394, 1
  %t396 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t395)
  %t397 = insertvalue { i64, ptr } undef, i64 %t394, 0
  %t398 = insertvalue { i64, ptr } %t397, ptr %t396, 1
  %t399 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t399, ptr %lp14
  %t401 = load ptr, ptr %lp14
  store { i64, ptr } %t398, ptr %t401, !tbaa !27
  store i64 0, ptr %l15, !tbaa !24
  %t402 = load i64, ptr %l3, !tbaa !24
  store i64 %t402, ptr %l16, !tbaa !24
  store i64 1, ptr %l17, !tbaa !24
  %t404 = load i64, ptr %l16, !tbaa !24
  %t405 = load i64, ptr %l15, !tbaa !24
  %t408 = icmp sgt i64 %t404, %t405
  br i1 %t408, label %bb107, label %bb108
bb106:
  call void @__olang_check_failed(ptr @olang_loc_a7ca1e4a4409b00c_ac64874c39ec6a0)
  unreachable
bb107:
  %t410 = load i64, ptr %l17, !tbaa !24
  %t412 = icmp sgt i64 %t410, 0
  br i1 %t412, label %bb109, label %bb110
bb108:
  store i64 0, ptr %l207, !tbaa !24
  br label %bb112
bb109:
  %t414 = load i64, ptr %l16, !tbaa !24
  %t415 = load i64, ptr %l15, !tbaa !24
  %t418 = sub i64 %t414, %t415
  %t419 = load i64, ptr %l17, !tbaa !24
  %t422 = add i64 %t418, %t419
  %t424 = sub i64 %t422, 1
  %t425 = load i64, ptr %l17, !tbaa !24
  %t428 = sdiv i64 %t424, %t425
  store i64 %t428, ptr %l210, !tbaa !24
  br label %bb111
bb110:
  store i64 0, ptr %l210, !tbaa !24
  br label %bb111
bb111:
  %t430 = load i64, ptr %l210, !tbaa !24
  store i64 %t430, ptr %l207, !tbaa !24
  br label %bb112
bb112:
  %t431 = load i64, ptr %l207, !tbaa !24
  store i64 %t431, ptr %l18, !tbaa !24
  store i64 0, ptr %l19, !tbaa !24
  %t432 = load i64, ptr %l18, !tbaa !24
  %t433 = sub i64 %t432, 1
  store i64 %t433, ptr %l219, !tbaa !24
  %t434 = load i64, ptr %l18, !tbaa !24
  %t435 = icmp slt i64 %t434, 2147483648
  %t436 = load i64, ptr %l19, !tbaa !24
  %t437 = icmp sge i64 %t436, 0
  %t440 = and i1 %t435, %t437
  store i1 %t440, ptr %l222, !tbaa !21
  br label %bb113
bb113:
  %t441 = load i64, ptr %l19, !tbaa !24
  %t442 = load i64, ptr %l18, !tbaa !24
  %t445 = icmp slt i64 %t441, %t442
  %t447 = xor i1 %t445, true
  br i1 %t447, label %bb114, label %bb115
bb114:
  br label %bb118
bb115:
  br label %bb116
bb116:
  %t449 = load i64, ptr %l15, !tbaa !24
  %t450 = load i64, ptr %l19, !tbaa !24
  %t451 = load i64, ptr %l17, !tbaa !24
  %t454 = mul i64 %t450, %t451
  %t457 = add i64 %t449, %t454
  store i64 %t457, ptr %l20, !tbaa !24
  %t459 = load i64, ptr %l20, !tbaa !24
  %t460 = load i64, ptr %l20, !tbaa !24
  %t462 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t463 = load ptr, ptr %t462, !tbaa !27
  %t464 = getelementptr i8, ptr %t463, i64 %t460
  %t465 = load i8, ptr %t464, !tbaa !32
  %t467 = load ptr, ptr %lp14
  %t469 = getelementptr { i64, ptr }, ptr %t467, i32 0, i32 1
  %t470 = load ptr, ptr %t469, !tbaa !27
  %t471 = getelementptr i8, ptr %t470, i64 %t459
  store i8 %t465, ptr %t471, !tbaa !32
  br label %bb117
bb117:
  %t472 = load i64, ptr %l19, !tbaa !24
  %t475 = add i64 %t472, 1
  store i64 %t475, ptr %l19, !tbaa !24
  br label %bb113
bb118:
  %t477 = load ptr, ptr %lp14
  %t478 = load { i64, ptr }, ptr %t477, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t478, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @std_2ffilepath_2eJoin(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l19 = alloca i64
  %l22 = alloca i1
  %l27 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l49 = alloca i64
  %l50 = alloca { i64, ptr }
  %l51 = alloca i64
  %l57 = alloca i64
  %l60 = alloca i1
  %l65 = alloca { i64, ptr }
  %l80 = alloca i64
  %l83 = alloca i1
  %l88 = alloca { i64, ptr }
  %l105 = alloca { i64, ptr }
  %l106 = alloca { i64, ptr }
  %l107 = alloca i64
  %l108 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 0, ptr %l1, !tbaa !24
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l4, !tbaa !24
  %t7 = load i64, ptr %l4, !tbaa !24
  %t8 = sub i64 %t7, 1
  store i64 %t8, ptr %l19, !tbaa !24
  %t9 = load i64, ptr %l4, !tbaa !24
  %t10 = icmp slt i64 %t9, 2147483648
  %t11 = load i64, ptr %l3, !tbaa !24
  %t12 = icmp sge i64 %t11, 0
  %t15 = and i1 %t10, %t12
  store i1 %t15, ptr %l22, !tbaa !21
  br label %bb1
bb1:
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = load i64, ptr %l4, !tbaa !24
  %t20 = icmp slt i64 %t16, %t17
  %t22 = xor i1 %t20, true
  br i1 %t22, label %bb2, label %bb3
bb2:
  br label %bb12
bb3:
  br label %bb4
bb4:
  %t24 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t24, ptr %l27, !tbaa !27
  %t25 = load i64, ptr %l3, !tbaa !24
  %t27 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = getelementptr { i64, ptr }, ptr %t28, i64 %t25
  %t30 = load { i64, ptr }, ptr %t29, !tbaa !37
  store { i64, ptr } %t30, ptr %l5, !tbaa !27
  %t32 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t32, 0
  %t36 = icmp sgt i64 %t34, 0
  br i1 %t36, label %bb5, label %bb6
bb5:
  %t38 = load i64, ptr %l1, !tbaa !24
  %t40 = icmp sgt i64 %t38, 0
  br i1 %t40, label %bb7, label %bb8
bb6:
  br label %bb10
bb7:
  %t42 = load i64, ptr %l1, !tbaa !24
  %t45 = add i64 %t42, 1
  store i64 %t45, ptr %l1, !tbaa !24
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t47 = load i64, ptr %l1, !tbaa !24
  %t48 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t48, 0
  %t53 = add i64 %t47, %t50
  store i64 %t53, ptr %l1, !tbaa !24
  br label %bb10
bb10:
  br label %bb11
bb11:
  %t55 = load i64, ptr %l3, !tbaa !24
  %t58 = add i64 %t55, 1
  store i64 %t58, ptr %l3, !tbaa !24
  br label %bb1
bb12:
  %t60 = load i64, ptr %l1, !tbaa !24
  %t62 = icmp eq i64 %t60, 0
  br i1 %t62, label %bb13, label %bb14
bb13:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d2, i32 0, i32 1) }, ptr %l47, !tbaa !27
  %t64 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t64, ptr %l48, !tbaa !27
  %t65 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t66 = extractvalue { i64, ptr } %t65, 0
  store i64 %t66, ptr %l49, !tbaa !24
  %t67 = load i64, ptr %l49, !tbaa !24
  %t68 = mul i64 %t67, 1
  %t69 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t68)
  %t70 = insertvalue { i64, ptr } undef, i64 %t67, 0
  %t71 = insertvalue { i64, ptr } %t70, ptr %t69, 1
  store { i64, ptr } %t71, ptr %l50, !tbaa !27
  %t72 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t75 = load ptr, ptr %t74, !tbaa !27
  %t76 = load i64, ptr %l49, !tbaa !24
  %t77 = mul i64 %t76, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t73, ptr %t75, i64 %t77, i1 false)
  %t78 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t78, ptr %l48, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t79 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t79, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t80 = load i64, ptr %l1, !tbaa !24
  store i64 %t80, ptr %l51, !tbaa !24
  %t81 = load i64, ptr %l51, !tbaa !24
  %t82 = icmp sge i64 %t81, 0
  br i1 %t82, label %bb16, label %bb17
bb16:
  %t84 = load i64, ptr %l51, !tbaa !24
  %t85 = mul i64 %t84, 1
  %t86 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t85)
  %t87 = insertvalue { i64, ptr } undef, i64 %t84, 0
  %t88 = insertvalue { i64, ptr } %t87, ptr %t86, 1
  store { i64, ptr } %t88, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t90 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t90, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t92 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t94 = extractvalue { i64, ptr } %t92, 0
  store i64 %t94, ptr %l10, !tbaa !24
  %t96 = load i64, ptr %l10, !tbaa !24
  %t97 = sub i64 %t96, 1
  store i64 %t97, ptr %l57, !tbaa !24
  %t98 = load i64, ptr %l10, !tbaa !24
  %t99 = icmp slt i64 %t98, 2147483648
  %t100 = load i64, ptr %l9, !tbaa !24
  %t101 = icmp sge i64 %t100, 0
  %t104 = and i1 %t99, %t101
  store i1 %t104, ptr %l60, !tbaa !21
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_88514958f43ac5a5_71c1ca98982dfa9)
  unreachable
bb18:
  %t105 = load i64, ptr %l9, !tbaa !24
  %t106 = load i64, ptr %l10, !tbaa !24
  %t109 = icmp slt i64 %t105, %t106
  %t111 = xor i1 %t109, true
  br i1 %t111, label %bb19, label %bb20
bb19:
  br label %bb35
bb20:
  br label %bb21
bb21:
  %t113 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t113, ptr %l65, !tbaa !27
  %t114 = load i64, ptr %l9, !tbaa !24
  %t116 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t117 = load ptr, ptr %t116, !tbaa !27
  %t118 = getelementptr { i64, ptr }, ptr %t117, i64 %t114
  %t119 = load { i64, ptr }, ptr %t118, !tbaa !37
  store { i64, ptr } %t119, ptr %l11, !tbaa !27
  %t121 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t123 = extractvalue { i64, ptr } %t121, 0
  %t125 = icmp eq i64 %t123, 0
  br i1 %t125, label %bb22, label %bb23
bb22:
  br label %bb34
bb23:
  br label %bb24
bb24:
  %t127 = load i64, ptr %l7, !tbaa !24
  %t129 = icmp sgt i64 %t127, 0
  br i1 %t129, label %bb25, label %bb26
bb25:
  %t131 = load i64, ptr %l7, !tbaa !24
  %t133 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t134 = load ptr, ptr %t133, !tbaa !27
  %t135 = getelementptr i8, ptr %t134, i64 %t131
  store i8 47, ptr %t135, !tbaa !32
  %t136 = load i64, ptr %l7, !tbaa !24
  %t139 = add i64 %t136, 1
  store i64 %t139, ptr %l7, !tbaa !24
  br label %bb27
bb26:
  br label %bb27
bb27:
  %t141 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t141, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t143 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t145 = extractvalue { i64, ptr } %t143, 0
  store i64 %t145, ptr %l14, !tbaa !24
  %t147 = load i64, ptr %l14, !tbaa !24
  %t148 = sub i64 %t147, 1
  store i64 %t148, ptr %l80, !tbaa !24
  %t149 = load i64, ptr %l14, !tbaa !24
  %t150 = icmp slt i64 %t149, 2147483648
  %t151 = load i64, ptr %l13, !tbaa !24
  %t152 = icmp sge i64 %t151, 0
  %t155 = and i1 %t150, %t152
  store i1 %t155, ptr %l83, !tbaa !21
  br label %bb28
bb28:
  %t156 = load i64, ptr %l13, !tbaa !24
  %t157 = load i64, ptr %l14, !tbaa !24
  %t160 = icmp slt i64 %t156, %t157
  %t162 = xor i1 %t160, true
  br i1 %t162, label %bb29, label %bb30
bb29:
  br label %bb33
bb30:
  br label %bb31
bb31:
  %t164 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t164, ptr %l88, !tbaa !27
  %t165 = load i64, ptr %l13, !tbaa !24
  %t167 = getelementptr { i64, ptr }, ptr %l88, i32 0, i32 1
  %t168 = load ptr, ptr %t167, !tbaa !27
  %t169 = getelementptr i8, ptr %t168, i64 %t165
  %t170 = load i8, ptr %t169, !tbaa !32
  %t172 = load i64, ptr %l7, !tbaa !24
  %t176 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t177 = load ptr, ptr %t176, !tbaa !27
  %t178 = getelementptr i8, ptr %t177, i64 %t172
  store i8 %t170, ptr %t178, !tbaa !32
  %t179 = load i64, ptr %l7, !tbaa !24
  %t182 = add i64 %t179, 1
  store i64 %t182, ptr %l7, !tbaa !24
  br label %bb32
bb32:
  %t184 = load i64, ptr %l13, !tbaa !24
  %t187 = add i64 %t184, 1
  store i64 %t187, ptr %l13, !tbaa !24
  br label %bb28
bb33:
  br label %bb34
bb34:
  %t189 = load i64, ptr %l9, !tbaa !24
  %t192 = add i64 %t189, 1
  store i64 %t192, ptr %l9, !tbaa !24
  br label %bb18
bb35:
  %t194 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t198 = call { i64, ptr } @std_2ffilepath_2eClean(ptr %s0, ptr %s0, { i64, ptr } %t194)
  store { i64, ptr } %t198, ptr %l105
  br label %bb36
bb36:
  %t199 = load { i64, ptr }, ptr %l105, !tbaa !27
  store { i64, ptr } %t199, ptr %l106, !tbaa !27
  %t200 = load { i64, ptr }, ptr %l106, !tbaa !27
  %t201 = extractvalue { i64, ptr } %t200, 0
  store i64 %t201, ptr %l107, !tbaa !24
  %t202 = load i64, ptr %l107, !tbaa !24
  %t203 = mul i64 %t202, 1
  %t204 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t203)
  %t205 = insertvalue { i64, ptr } undef, i64 %t202, 0
  %t206 = insertvalue { i64, ptr } %t205, ptr %t204, 1
  store { i64, ptr } %t206, ptr %l108, !tbaa !27
  %t207 = getelementptr { i64, ptr }, ptr %l108, i32 0, i32 1
  %t208 = load ptr, ptr %t207, !tbaa !27
  %t209 = getelementptr { i64, ptr }, ptr %l106, i32 0, i32 1
  %t210 = load ptr, ptr %t209, !tbaa !27
  %t211 = load i64, ptr %l107, !tbaa !24
  %t212 = mul i64 %t211, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t208, ptr %t210, i64 %t212, i1 false)
  %t213 = load { i64, ptr }, ptr %l108, !tbaa !27
  store { i64, ptr } %t213, ptr %l106, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t214 = load { i64, ptr }, ptr %l106, !tbaa !27
  store { i64, ptr } %t214, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i32, { i64, ptr } } @std_2ffilepath_2eRel(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l17 = alloca { i64, ptr }
  %lp18 = alloca ptr
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l26 = alloca { i64, ptr }
  %l27 = alloca i64
  %l28 = alloca i64
  %l31 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l36 = alloca i1
  %l37 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l39 = alloca i64
  %l40 = alloca { i64, ptr }
  %l42 = alloca i1
  %l43 = alloca { i64, ptr }
  %l44 = alloca i64
  %l50 = alloca i1
  %l52 = alloca i1
  %l62 = alloca i1
  %l63 = alloca { i64, ptr }
  %l74 = alloca i1
  %l75 = alloca { i64, ptr }
  %l83 = alloca { i64, ptr }
  %l84 = alloca i64
  %l85 = alloca i64
  %l86 = alloca i64
  %l90 = alloca { i64, ptr }
  %l91 = alloca { i64, ptr }
  %l92 = alloca i64
  %l93 = alloca i64
  %l94 = alloca i64
  %l99 = alloca i1
  %l115 = alloca { i64, ptr }
  %l116 = alloca i64
  %l117 = alloca i64
  %l118 = alloca i64
  %l123 = alloca i1
  %l128 = alloca { i64, ptr }
  %l129 = alloca i64
  %l132 = alloca i64
  %l133 = alloca i64
  %l138 = alloca { i64, ptr }
  %l139 = alloca i64
  %l140 = alloca { i64, ptr }
  %l146 = alloca i64
  %l149 = alloca i64
  %l158 = alloca i64
  %l161 = alloca i1
  %l171 = alloca { i64, ptr }
  %l181 = alloca { i64, ptr }
  %l182 = alloca i64
  %l185 = alloca i64
  %l186 = alloca i64
  %l193 = alloca i64
  %l197 = alloca i64
  %l201 = alloca i64
  %l208 = alloca i64
  %l211 = alloca i64
  %l220 = alloca i64
  %l223 = alloca i1
  %l258 = alloca i64
  %l261 = alloca i1
  %l266 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call { i64, ptr } @std_2ffilepath_2eClean(ptr %v0, ptr %s0, { i64, ptr } %a0)
  store { i64, ptr } %t3, ptr %l31
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t7 = call { i64, ptr } @std_2ffilepath_2eClean(ptr %v1, ptr %s0, { i64, ptr } %a1)
  store { i64, ptr } %t7, ptr %l33
  br label %bb2
bb2:
  %t8 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t8, ptr %l3, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t13 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t9, { i64, ptr } %t10)
  store i1 %t13, ptr %l36
  br label %bb3
bb3:
  %t14 = load i1, ptr %l36, !tbaa !21
  br i1 %t14, label %bb4, label %bb5
bb4:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d3, i32 0, i32 1) }, ptr %l37, !tbaa !27
  %t15 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t15, ptr %l38, !tbaa !27
  %t16 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t16, 0
  store i64 %t17, ptr %l39, !tbaa !24
  %t18 = load i64, ptr %l39, !tbaa !24
  %t19 = mul i64 %t18, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t19)
  %t21 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  store { i64, ptr } %t22, ptr %l40, !tbaa !27
  %t23 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = load i64, ptr %l39, !tbaa !24
  %t28 = mul i64 %t27, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t24, ptr %t26, i64 %t28, i1 false)
  %t29 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t29, ptr %l38, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t30 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t31 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t30, 1
  store { i32, { i64, ptr } } %t31, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t32 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t34 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t32, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d4, i32 0, i32 1) })
  store i1 %t34, ptr %l42
  br label %bb7
bb7:
  %t35 = load i1, ptr %l42, !tbaa !21
  br i1 %t35, label %bb8, label %bb9
bb8:
  %t36 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t36, ptr %l43, !tbaa !27
  %t37 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t37, 0
  store i64 %t38, ptr %l44, !tbaa !24
  %t39 = icmp sge i64 0, 0
  br i1 %t39, label %bb10, label %bb11
bb9:
  br label %bb16
bb10:
  %t41 = icmp sle i64 0, 0
  br i1 %t41, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_d061c7e25d631130_ed41ebaf937312b4)
  unreachable
bb12:
  %t43 = load i64, ptr %l44, !tbaa !24
  %t44 = icmp sle i64 0, %t43
  br i1 %t44, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_d061c7e25d631130_ed41ebaf937312b4)
  unreachable
bb14:
  %t46 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = getelementptr i8, ptr %t47, i64 0
  %t49 = sub i64 0, 0
  %t50 = insertvalue { i64, ptr } undef, i64 %t49, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t48, 1
  store { i64, ptr } %t51, ptr %l2, !tbaa !27
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_d061c7e25d631130_ed41ebaf937312b4)
  unreachable
bb16:
  %t53 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t55 = call i1 @std_2ffilepath_2eIsAbs(ptr %s0, { i64, ptr } %t53)
  store i1 %t55, ptr %l50
  br label %bb17
bb17:
  %t56 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t58 = call i1 @std_2ffilepath_2eIsAbs(ptr %s0, { i64, ptr } %t56)
  store i1 %t58, ptr %l52
  br label %bb18
bb18:
  %t59 = load i1, ptr %l50, !tbaa !21
  %t60 = load i1, ptr %l52, !tbaa !21
  %t61 = icmp ne i1 %t59, %t60
  br i1 %t61, label %bb19, label %bb20
bb19:
  call void @__olang_scope_close(ptr %s0)
  %t64 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t64, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t65 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t67 = extractvalue { i64, ptr } %t65, 0
  store i64 %t67, ptr %l4, !tbaa !24
  %t69 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t71 = extractvalue { i64, ptr } %t69, 0
  store i64 %t71, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb22
bb22:
  br label %bb23
bb23:
  %t73 = load i64, ptr %l7, !tbaa !24
  %t74 = load i64, ptr %l4, !tbaa !24
  %t77 = icmp slt i64 %t73, %t74
  br i1 %t77, label %bb24, label %bb25
bb24:
  %t79 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t79, ptr %l63, !tbaa !27
  %t80 = load i64, ptr %l7, !tbaa !24
  %t82 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !27
  %t84 = getelementptr i8, ptr %t83, i64 %t80
  %t85 = load i8, ptr %t84, !tbaa !32
  %t87 = icmp ne i8 %t85, 47
  store i1 %t87, ptr %l62, !tbaa !21
  br label %bb26
bb25:
  store i1 false, ptr %l62, !tbaa !21
  br label %bb26
bb26:
  %t89 = load i1, ptr %l62, !tbaa !21
  %t90 = xor i1 %t89, true
  br i1 %t90, label %bb27, label %bb28
bb27:
  br label %bb31
bb28:
  br label %bb29
bb29:
  %t92 = load i64, ptr %l7, !tbaa !24
  %t95 = add i64 %t92, 1
  store i64 %t95, ptr %l7, !tbaa !24
  br label %bb30
bb30:
  br label %bb23
bb31:
  br label %bb32
bb32:
  %t97 = load i64, ptr %l9, !tbaa !24
  %t98 = load i64, ptr %l5, !tbaa !24
  %t101 = icmp slt i64 %t97, %t98
  br i1 %t101, label %bb33, label %bb34
bb33:
  %t103 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t103, ptr %l75, !tbaa !27
  %t104 = load i64, ptr %l9, !tbaa !24
  %t106 = getelementptr { i64, ptr }, ptr %l75, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !27
  %t108 = getelementptr i8, ptr %t107, i64 %t104
  %t109 = load i8, ptr %t108, !tbaa !32
  %t111 = icmp ne i8 %t109, 47
  store i1 %t111, ptr %l74, !tbaa !21
  br label %bb35
bb34:
  store i1 false, ptr %l74, !tbaa !21
  br label %bb35
bb35:
  %t113 = load i1, ptr %l74, !tbaa !21
  %t114 = xor i1 %t113, true
  br i1 %t114, label %bb36, label %bb37
bb36:
  br label %bb40
bb37:
  br label %bb38
bb38:
  %t116 = load i64, ptr %l9, !tbaa !24
  %t119 = add i64 %t116, 1
  store i64 %t119, ptr %l9, !tbaa !24
  br label %bb39
bb39:
  br label %bb32
bb40:
  %t121 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t121, ptr %l83, !tbaa !27
  %t122 = load i64, ptr %l8, !tbaa !24
  store i64 %t122, ptr %l84, !tbaa !24
  %t123 = load i64, ptr %l9, !tbaa !24
  store i64 %t123, ptr %l85, !tbaa !24
  %t124 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t125 = extractvalue { i64, ptr } %t124, 0
  store i64 %t125, ptr %l86, !tbaa !24
  %t126 = load i64, ptr %l84, !tbaa !24
  %t127 = icmp sge i64 %t126, 0
  br i1 %t127, label %bb41, label %bb42
bb41:
  %t129 = load i64, ptr %l84, !tbaa !24
  %t130 = load i64, ptr %l85, !tbaa !24
  %t131 = icmp sle i64 %t129, %t130
  br i1 %t131, label %bb43, label %bb44
bb42:
  call void @__olang_check_failed(ptr @olang_loc_668000db62bcfe0d_fbc758d8da0c96a1)
  unreachable
bb43:
  %t133 = load i64, ptr %l85, !tbaa !24
  %t134 = load i64, ptr %l86, !tbaa !24
  %t135 = icmp sle i64 %t133, %t134
  br i1 %t135, label %bb45, label %bb46
bb44:
  call void @__olang_check_failed(ptr @olang_loc_668000db62bcfe0d_fbc758d8da0c96a1)
  unreachable
bb45:
  %t137 = getelementptr { i64, ptr }, ptr %l83, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !27
  %t139 = load i64, ptr %l84, !tbaa !24
  %t140 = load i64, ptr %l85, !tbaa !24
  %t141 = getelementptr i8, ptr %t138, i64 %t139
  %t142 = sub i64 %t140, %t139
  %t143 = insertvalue { i64, ptr } undef, i64 %t142, 0
  %t144 = insertvalue { i64, ptr } %t143, ptr %t141, 1
  store { i64, ptr } %t144, ptr %l90, !tbaa !27
  %t145 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t145, ptr %l91, !tbaa !27
  %t146 = load i64, ptr %l6, !tbaa !24
  store i64 %t146, ptr %l92, !tbaa !24
  %t147 = load i64, ptr %l7, !tbaa !24
  store i64 %t147, ptr %l93, !tbaa !24
  %t148 = load { i64, ptr }, ptr %l91, !tbaa !27
  %t149 = extractvalue { i64, ptr } %t148, 0
  store i64 %t149, ptr %l94, !tbaa !24
  %t150 = load i64, ptr %l92, !tbaa !24
  %t151 = icmp sge i64 %t150, 0
  br i1 %t151, label %bb47, label %bb48
bb46:
  call void @__olang_check_failed(ptr @olang_loc_668000db62bcfe0d_fbc758d8da0c96a1)
  unreachable
bb47:
  %t153 = load i64, ptr %l92, !tbaa !24
  %t154 = load i64, ptr %l93, !tbaa !24
  %t155 = icmp sle i64 %t153, %t154
  br i1 %t155, label %bb49, label %bb50
bb48:
  call void @__olang_check_failed(ptr @olang_loc_668000db62bcfe0d_fbc758d8da0c96a1)
  unreachable
bb49:
  %t157 = load i64, ptr %l93, !tbaa !24
  %t158 = load i64, ptr %l94, !tbaa !24
  %t159 = icmp sle i64 %t157, %t158
  br i1 %t159, label %bb51, label %bb52
bb50:
  call void @__olang_check_failed(ptr @olang_loc_668000db62bcfe0d_fbc758d8da0c96a1)
  unreachable
bb51:
  %t161 = getelementptr { i64, ptr }, ptr %l91, i32 0, i32 1
  %t162 = load ptr, ptr %t161, !tbaa !27
  %t163 = load i64, ptr %l92, !tbaa !24
  %t164 = load i64, ptr %l93, !tbaa !24
  %t165 = getelementptr i8, ptr %t162, i64 %t163
  %t166 = sub i64 %t164, %t163
  %t167 = insertvalue { i64, ptr } undef, i64 %t166, 0
  %t168 = insertvalue { i64, ptr } %t167, ptr %t165, 1
  %t169 = load { i64, ptr }, ptr %l90, !tbaa !27
  %t171 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t169, { i64, ptr } %t168)
  store i1 %t171, ptr %l99
  br label %bb53
bb52:
  call void @__olang_check_failed(ptr @olang_loc_668000db62bcfe0d_fbc758d8da0c96a1)
  unreachable
bb53:
  %t172 = load i1, ptr %l99, !tbaa !21
  %t173 = xor i1 %t172, true
  br i1 %t173, label %bb54, label %bb55
bb54:
  br label %bb64
bb55:
  br label %bb56
bb56:
  %t175 = load i64, ptr %l7, !tbaa !24
  %t176 = load i64, ptr %l4, !tbaa !24
  %t179 = icmp slt i64 %t175, %t176
  br i1 %t179, label %bb57, label %bb58
bb57:
  %t181 = load i64, ptr %l7, !tbaa !24
  %t184 = add i64 %t181, 1
  store i64 %t184, ptr %l7, !tbaa !24
  br label %bb59
bb58:
  br label %bb59
bb59:
  %t186 = load i64, ptr %l9, !tbaa !24
  %t187 = load i64, ptr %l5, !tbaa !24
  %t190 = icmp slt i64 %t186, %t187
  br i1 %t190, label %bb60, label %bb61
bb60:
  %t192 = load i64, ptr %l9, !tbaa !24
  %t195 = add i64 %t192, 1
  store i64 %t195, ptr %l9, !tbaa !24
  br label %bb62
bb61:
  br label %bb62
bb62:
  %t197 = load i64, ptr %l7, !tbaa !24
  store i64 %t197, ptr %l6, !tbaa !24
  %t199 = load i64, ptr %l9, !tbaa !24
  store i64 %t199, ptr %l8, !tbaa !24
  br label %bb63
bb63:
  br label %bb22
bb64:
  %t201 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t201, ptr %l115, !tbaa !27
  %t202 = load i64, ptr %l6, !tbaa !24
  store i64 %t202, ptr %l116, !tbaa !24
  %t203 = load i64, ptr %l7, !tbaa !24
  store i64 %t203, ptr %l117, !tbaa !24
  %t204 = load { i64, ptr }, ptr %l115, !tbaa !27
  %t205 = extractvalue { i64, ptr } %t204, 0
  store i64 %t205, ptr %l118, !tbaa !24
  %t206 = load i64, ptr %l116, !tbaa !24
  %t207 = icmp sge i64 %t206, 0
  br i1 %t207, label %bb65, label %bb66
bb65:
  %t209 = load i64, ptr %l116, !tbaa !24
  %t210 = load i64, ptr %l117, !tbaa !24
  %t211 = icmp sle i64 %t209, %t210
  br i1 %t211, label %bb67, label %bb68
bb66:
  call void @__olang_check_failed(ptr @olang_loc_25fb20074e4b49ae_c59224b0534d5022)
  unreachable
bb67:
  %t213 = load i64, ptr %l117, !tbaa !24
  %t214 = load i64, ptr %l118, !tbaa !24
  %t215 = icmp sle i64 %t213, %t214
  br i1 %t215, label %bb69, label %bb70
bb68:
  call void @__olang_check_failed(ptr @olang_loc_25fb20074e4b49ae_c59224b0534d5022)
  unreachable
bb69:
  %t217 = getelementptr { i64, ptr }, ptr %l115, i32 0, i32 1
  %t218 = load ptr, ptr %t217, !tbaa !27
  %t219 = load i64, ptr %l116, !tbaa !24
  %t220 = load i64, ptr %l117, !tbaa !24
  %t221 = getelementptr i8, ptr %t218, i64 %t219
  %t222 = sub i64 %t220, %t219
  %t223 = insertvalue { i64, ptr } undef, i64 %t222, 0
  %t224 = insertvalue { i64, ptr } %t223, ptr %t221, 1
  %t226 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t224, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d5, i32 0, i32 1) })
  store i1 %t226, ptr %l123
  br label %bb71
bb70:
  call void @__olang_check_failed(ptr @olang_loc_25fb20074e4b49ae_c59224b0534d5022)
  unreachable
bb71:
  %t227 = load i1, ptr %l123, !tbaa !21
  br i1 %t227, label %bb72, label %bb73
bb72:
  call void @__olang_scope_close(ptr %s0)
  %t229 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t229, ptr %rv
  br label %ret
bb73:
  br label %bb74
bb74:
  %t230 = load i64, ptr %l6, !tbaa !24
  %t231 = load i64, ptr %l4, !tbaa !24
  %t234 = icmp eq i64 %t230, %t231
  br i1 %t234, label %bb75, label %bb76
bb75:
  %t236 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t236, ptr %l128, !tbaa !27
  %t237 = load i64, ptr %l8, !tbaa !24
  store i64 %t237, ptr %l129, !tbaa !24
  %t238 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t241 = extractvalue { i64, ptr } %t238, 0
  store i64 %t241, ptr %l132, !tbaa !24
  %t242 = load { i64, ptr }, ptr %l128, !tbaa !27
  %t243 = extractvalue { i64, ptr } %t242, 0
  store i64 %t243, ptr %l133, !tbaa !24
  %t244 = load i64, ptr %l129, !tbaa !24
  %t245 = icmp sge i64 %t244, 0
  br i1 %t245, label %bb77, label %bb78
bb76:
  br label %bb83
bb77:
  %t247 = load i64, ptr %l129, !tbaa !24
  %t248 = load i64, ptr %l132, !tbaa !24
  %t249 = icmp sle i64 %t247, %t248
  br i1 %t249, label %bb79, label %bb80
bb78:
  call void @__olang_check_failed(ptr @olang_loc_3fc5cad3648832ab_e217ea960297dd9f)
  unreachable
bb79:
  %t251 = load i64, ptr %l132, !tbaa !24
  %t252 = load i64, ptr %l133, !tbaa !24
  %t253 = icmp sle i64 %t251, %t252
  br i1 %t253, label %bb81, label %bb82
bb80:
  call void @__olang_check_failed(ptr @olang_loc_3fc5cad3648832ab_e217ea960297dd9f)
  unreachable
bb81:
  %t255 = getelementptr { i64, ptr }, ptr %l128, i32 0, i32 1
  %t256 = load ptr, ptr %t255, !tbaa !27
  %t257 = load i64, ptr %l129, !tbaa !24
  %t258 = load i64, ptr %l132, !tbaa !24
  %t259 = getelementptr i8, ptr %t256, i64 %t257
  %t260 = sub i64 %t258, %t257
  %t261 = insertvalue { i64, ptr } undef, i64 %t260, 0
  %t262 = insertvalue { i64, ptr } %t261, ptr %t259, 1
  store { i64, ptr } %t262, ptr %l138, !tbaa !27
  %t264 = load { i64, ptr }, ptr %l138, !tbaa !27
  %t265 = extractvalue { i64, ptr } %t264, 0
  store i64 %t265, ptr %l139, !tbaa !24
  %t266 = load i64, ptr %l139, !tbaa !24
  %t267 = mul i64 %t266, 1
  %t268 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t267)
  %t269 = insertvalue { i64, ptr } undef, i64 %t266, 0
  %t270 = insertvalue { i64, ptr } %t269, ptr %t268, 1
  store { i64, ptr } %t270, ptr %l140, !tbaa !27
  %t271 = getelementptr { i64, ptr }, ptr %l140, i32 0, i32 1
  %t272 = load ptr, ptr %t271, !tbaa !27
  %t273 = getelementptr { i64, ptr }, ptr %l138, i32 0, i32 1
  %t274 = load ptr, ptr %t273, !tbaa !27
  %t275 = load i64, ptr %l139, !tbaa !24
  %t276 = mul i64 %t275, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t272, ptr %t274, i64 %t276, i1 false)
  %t277 = load { i64, ptr }, ptr %l140, !tbaa !27
  store { i64, ptr } %t277, ptr %l138, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t278 = load { i64, ptr }, ptr %l138, !tbaa !27
  %t279 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t278, 1
  store { i32, { i64, ptr } } %t279, ptr %rv
  br label %ret
bb82:
  call void @__olang_check_failed(ptr @olang_loc_3fc5cad3648832ab_e217ea960297dd9f)
  unreachable
bb83:
  store i64 1, ptr %l10, !tbaa !24
  %t280 = load i64, ptr %l6, !tbaa !24
  store i64 %t280, ptr %l11, !tbaa !24
  %t282 = load i64, ptr %l4, !tbaa !24
  store i64 %t282, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t284 = load i64, ptr %l12, !tbaa !24
  %t285 = load i64, ptr %l11, !tbaa !24
  %t288 = icmp sgt i64 %t284, %t285
  br i1 %t288, label %bb84, label %bb85
bb84:
  %t290 = load i64, ptr %l13, !tbaa !24
  %t292 = icmp sgt i64 %t290, 0
  br i1 %t292, label %bb86, label %bb87
bb85:
  store i64 0, ptr %l146, !tbaa !24
  br label %bb89
bb86:
  %t294 = load i64, ptr %l12, !tbaa !24
  %t295 = load i64, ptr %l11, !tbaa !24
  %t298 = sub i64 %t294, %t295
  %t299 = load i64, ptr %l13, !tbaa !24
  %t302 = add i64 %t298, %t299
  %t304 = sub i64 %t302, 1
  %t305 = load i64, ptr %l13, !tbaa !24
  %t308 = sdiv i64 %t304, %t305
  store i64 %t308, ptr %l149, !tbaa !24
  br label %bb88
bb87:
  store i64 0, ptr %l149, !tbaa !24
  br label %bb88
bb88:
  %t310 = load i64, ptr %l149, !tbaa !24
  store i64 %t310, ptr %l146, !tbaa !24
  br label %bb89
bb89:
  %t311 = load i64, ptr %l146, !tbaa !24
  store i64 %t311, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  %t312 = load i64, ptr %l14, !tbaa !24
  %t313 = sub i64 %t312, 1
  store i64 %t313, ptr %l158, !tbaa !24
  %t314 = load i64, ptr %l14, !tbaa !24
  %t315 = icmp slt i64 %t314, 2147483648
  %t316 = load i64, ptr %l15, !tbaa !24
  %t317 = icmp sge i64 %t316, 0
  %t320 = and i1 %t315, %t317
  store i1 %t320, ptr %l161, !tbaa !21
  br label %bb90
bb90:
  %t321 = load i64, ptr %l15, !tbaa !24
  %t322 = load i64, ptr %l14, !tbaa !24
  %t325 = icmp slt i64 %t321, %t322
  %t327 = xor i1 %t325, true
  br i1 %t327, label %bb91, label %bb92
bb91:
  br label %bb98
bb92:
  br label %bb93
bb93:
  %t329 = load i64, ptr %l11, !tbaa !24
  %t330 = load i64, ptr %l15, !tbaa !24
  %t331 = load i64, ptr %l13, !tbaa !24
  %t334 = mul i64 %t330, %t331
  %t337 = add i64 %t329, %t334
  %t339 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t339, ptr %l171, !tbaa !27
  %t342 = getelementptr { i64, ptr }, ptr %l171, i32 0, i32 1
  %t343 = load ptr, ptr %t342, !tbaa !27
  %t344 = getelementptr i8, ptr %t343, i64 %t337
  %t345 = load i8, ptr %t344, !tbaa !32
  %t347 = icmp eq i8 %t345, 47
  br i1 %t347, label %bb94, label %bb95
bb94:
  %t349 = load i64, ptr %l10, !tbaa !24
  %t352 = add i64 %t349, 1
  store i64 %t352, ptr %l10, !tbaa !24
  br label %bb96
bb95:
  br label %bb96
bb96:
  br label %bb97
bb97:
  %t354 = load i64, ptr %l15, !tbaa !24
  %t357 = add i64 %t354, 1
  store i64 %t357, ptr %l15, !tbaa !24
  br label %bb90
bb98:
  %t359 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t359, ptr %l181, !tbaa !27
  %t360 = load i64, ptr %l8, !tbaa !24
  store i64 %t360, ptr %l182, !tbaa !24
  %t361 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t364 = extractvalue { i64, ptr } %t361, 0
  store i64 %t364, ptr %l185, !tbaa !24
  %t365 = load { i64, ptr }, ptr %l181, !tbaa !27
  %t366 = extractvalue { i64, ptr } %t365, 0
  store i64 %t366, ptr %l186, !tbaa !24
  %t367 = load i64, ptr %l182, !tbaa !24
  %t368 = icmp sge i64 %t367, 0
  br i1 %t368, label %bb99, label %bb100
bb99:
  %t370 = load i64, ptr %l182, !tbaa !24
  %t371 = load i64, ptr %l185, !tbaa !24
  %t372 = icmp sle i64 %t370, %t371
  br i1 %t372, label %bb101, label %bb102
bb100:
  call void @__olang_check_failed(ptr @olang_loc_6975e58e775568a4_668b7bdd2238b9c0)
  unreachable
bb101:
  %t374 = load i64, ptr %l185, !tbaa !24
  %t375 = load i64, ptr %l186, !tbaa !24
  %t376 = icmp sle i64 %t374, %t375
  br i1 %t376, label %bb103, label %bb104
bb102:
  call void @__olang_check_failed(ptr @olang_loc_6975e58e775568a4_668b7bdd2238b9c0)
  unreachable
bb103:
  %t378 = getelementptr { i64, ptr }, ptr %l181, i32 0, i32 1
  %t379 = load ptr, ptr %t378, !tbaa !27
  %t380 = load i64, ptr %l182, !tbaa !24
  %t381 = load i64, ptr %l185, !tbaa !24
  %t382 = getelementptr i8, ptr %t379, i64 %t380
  %t383 = sub i64 %t381, %t380
  %t384 = insertvalue { i64, ptr } undef, i64 %t383, 0
  %t385 = insertvalue { i64, ptr } %t384, ptr %t382, 1
  store { i64, ptr } %t385, ptr %l17, !tbaa !27
  %t387 = load i64, ptr %l10, !tbaa !24
  %t389 = mul i64 %t387, 3
  %t391 = sub i64 %t389, 1
  store i64 %t391, ptr %l193, !tbaa !24
  %t392 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t394 = extractvalue { i64, ptr } %t392, 0
  %t396 = icmp sgt i64 %t394, 0
  br i1 %t396, label %bb105, label %bb106
bb104:
  call void @__olang_check_failed(ptr @olang_loc_6975e58e775568a4_668b7bdd2238b9c0)
  unreachable
bb105:
  %t398 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t400 = extractvalue { i64, ptr } %t398, 0
  %t402 = add i64 %t400, 1
  store i64 %t402, ptr %l197, !tbaa !24
  br label %bb107
bb106:
  store i64 0, ptr %l197, !tbaa !24
  br label %bb107
bb107:
  %t404 = load i64, ptr %l193, !tbaa !24
  %t405 = load i64, ptr %l197, !tbaa !24
  %t406 = add i64 %t404, %t405
  store i64 %t406, ptr %l201, !tbaa !24
  %t407 = load i64, ptr %l201, !tbaa !24
  %t408 = icmp sge i64 %t407, 0
  br i1 %t408, label %bb108, label %bb109
bb108:
  %t410 = load i64, ptr %l201, !tbaa !24
  %t411 = mul i64 %t410, 1
  %t412 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t411)
  %t413 = insertvalue { i64, ptr } undef, i64 %t410, 0
  %t414 = insertvalue { i64, ptr } %t413, ptr %t412, 1
  %t415 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t415, ptr %lp18
  %t417 = load ptr, ptr %lp18
  store { i64, ptr } %t414, ptr %t417, !tbaa !27
  store i64 0, ptr %l19, !tbaa !24
  store i64 0, ptr %l20, !tbaa !24
  %t418 = load i64, ptr %l10, !tbaa !24
  store i64 %t418, ptr %l21, !tbaa !24
  store i64 1, ptr %l22, !tbaa !24
  %t420 = load i64, ptr %l21, !tbaa !24
  %t421 = load i64, ptr %l20, !tbaa !24
  %t424 = icmp sgt i64 %t420, %t421
  br i1 %t424, label %bb110, label %bb111
bb109:
  call void @__olang_check_failed(ptr @olang_loc_1fc14433466d7ed9_4c0c0b85aca7f45d)
  unreachable
bb110:
  %t426 = load i64, ptr %l22, !tbaa !24
  %t428 = icmp sgt i64 %t426, 0
  br i1 %t428, label %bb112, label %bb113
bb111:
  store i64 0, ptr %l208, !tbaa !24
  br label %bb115
bb112:
  %t430 = load i64, ptr %l21, !tbaa !24
  %t431 = load i64, ptr %l20, !tbaa !24
  %t434 = sub i64 %t430, %t431
  %t435 = load i64, ptr %l22, !tbaa !24
  %t438 = add i64 %t434, %t435
  %t440 = sub i64 %t438, 1
  %t441 = load i64, ptr %l22, !tbaa !24
  %t444 = sdiv i64 %t440, %t441
  store i64 %t444, ptr %l211, !tbaa !24
  br label %bb114
bb113:
  store i64 0, ptr %l211, !tbaa !24
  br label %bb114
bb114:
  %t446 = load i64, ptr %l211, !tbaa !24
  store i64 %t446, ptr %l208, !tbaa !24
  br label %bb115
bb115:
  %t447 = load i64, ptr %l208, !tbaa !24
  store i64 %t447, ptr %l23, !tbaa !24
  store i64 0, ptr %l24, !tbaa !24
  %t448 = load i64, ptr %l23, !tbaa !24
  %t449 = sub i64 %t448, 1
  store i64 %t449, ptr %l220, !tbaa !24
  %t450 = load i64, ptr %l23, !tbaa !24
  %t451 = icmp slt i64 %t450, 2147483648
  %t452 = load i64, ptr %l24, !tbaa !24
  %t453 = icmp sge i64 %t452, 0
  %t456 = and i1 %t451, %t453
  store i1 %t456, ptr %l223, !tbaa !21
  br label %bb116
bb116:
  %t457 = load i64, ptr %l24, !tbaa !24
  %t458 = load i64, ptr %l23, !tbaa !24
  %t461 = icmp slt i64 %t457, %t458
  %t463 = xor i1 %t461, true
  br i1 %t463, label %bb117, label %bb118
bb117:
  br label %bb124
bb118:
  br label %bb119
bb119:
  %t465 = load i64, ptr %l20, !tbaa !24
  %t466 = load i64, ptr %l24, !tbaa !24
  %t467 = load i64, ptr %l22, !tbaa !24
  %t470 = mul i64 %t466, %t467
  %t473 = add i64 %t465, %t470
  %t477 = icmp sgt i64 %t473, 0
  br i1 %t477, label %bb120, label %bb121
bb120:
  %t479 = load i64, ptr %l19, !tbaa !24
  %t480 = load ptr, ptr %lp18
  %t482 = getelementptr { i64, ptr }, ptr %t480, i32 0, i32 1
  %t483 = load ptr, ptr %t482, !tbaa !27
  %t484 = getelementptr i8, ptr %t483, i64 %t479
  store i8 47, ptr %t484, !tbaa !32
  %t485 = load i64, ptr %l19, !tbaa !24
  %t488 = add i64 %t485, 1
  store i64 %t488, ptr %l19, !tbaa !24
  br label %bb122
bb121:
  br label %bb122
bb122:
  %t490 = load i64, ptr %l19, !tbaa !24
  %t491 = load ptr, ptr %lp18
  %t493 = getelementptr { i64, ptr }, ptr %t491, i32 0, i32 1
  %t494 = load ptr, ptr %t493, !tbaa !27
  %t495 = getelementptr i8, ptr %t494, i64 %t490
  store i8 46, ptr %t495, !tbaa !32
  %t496 = load i64, ptr %l19, !tbaa !24
  %t498 = add i64 %t496, 1
  %t499 = load ptr, ptr %lp18
  %t501 = getelementptr { i64, ptr }, ptr %t499, i32 0, i32 1
  %t502 = load ptr, ptr %t501, !tbaa !27
  %t503 = getelementptr i8, ptr %t502, i64 %t498
  store i8 46, ptr %t503, !tbaa !32
  %t504 = load i64, ptr %l19, !tbaa !24
  %t507 = add i64 %t504, 2
  store i64 %t507, ptr %l19, !tbaa !24
  br label %bb123
bb123:
  %t509 = load i64, ptr %l24, !tbaa !24
  %t512 = add i64 %t509, 1
  store i64 %t512, ptr %l24, !tbaa !24
  br label %bb116
bb124:
  %t514 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t516 = extractvalue { i64, ptr } %t514, 0
  %t518 = icmp sgt i64 %t516, 0
  br i1 %t518, label %bb125, label %bb126
bb125:
  %t520 = load i64, ptr %l19, !tbaa !24
  %t521 = load ptr, ptr %lp18
  %t523 = getelementptr { i64, ptr }, ptr %t521, i32 0, i32 1
  %t524 = load ptr, ptr %t523, !tbaa !27
  %t525 = getelementptr i8, ptr %t524, i64 %t520
  store i8 47, ptr %t525, !tbaa !32
  %t526 = load i64, ptr %l19, !tbaa !24
  %t529 = add i64 %t526, 1
  store i64 %t529, ptr %l19, !tbaa !24
  %t531 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t531, ptr %l26, !tbaa !27
  store i64 0, ptr %l27, !tbaa !24
  %t533 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t535 = extractvalue { i64, ptr } %t533, 0
  store i64 %t535, ptr %l28, !tbaa !24
  %t537 = load i64, ptr %l28, !tbaa !24
  %t538 = sub i64 %t537, 1
  store i64 %t538, ptr %l258, !tbaa !24
  %t539 = load i64, ptr %l28, !tbaa !24
  %t540 = icmp slt i64 %t539, 2147483648
  %t541 = load i64, ptr %l27, !tbaa !24
  %t542 = icmp sge i64 %t541, 0
  %t545 = and i1 %t540, %t542
  store i1 %t545, ptr %l261, !tbaa !21
  br label %bb127
bb126:
  br label %bb133
bb127:
  %t546 = load i64, ptr %l27, !tbaa !24
  %t547 = load i64, ptr %l28, !tbaa !24
  %t550 = icmp slt i64 %t546, %t547
  %t552 = xor i1 %t550, true
  br i1 %t552, label %bb128, label %bb129
bb128:
  br label %bb132
bb129:
  br label %bb130
bb130:
  %t554 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t554, ptr %l266, !tbaa !27
  %t555 = load i64, ptr %l27, !tbaa !24
  %t557 = getelementptr { i64, ptr }, ptr %l266, i32 0, i32 1
  %t558 = load ptr, ptr %t557, !tbaa !27
  %t559 = getelementptr i8, ptr %t558, i64 %t555
  %t560 = load i8, ptr %t559, !tbaa !32
  %t562 = load i64, ptr %l19, !tbaa !24
  %t565 = load ptr, ptr %lp18
  %t567 = getelementptr { i64, ptr }, ptr %t565, i32 0, i32 1
  %t568 = load ptr, ptr %t567, !tbaa !27
  %t569 = getelementptr i8, ptr %t568, i64 %t562
  store i8 %t560, ptr %t569, !tbaa !32
  %t570 = load i64, ptr %l19, !tbaa !24
  %t573 = add i64 %t570, 1
  store i64 %t573, ptr %l19, !tbaa !24
  br label %bb131
bb131:
  %t575 = load i64, ptr %l27, !tbaa !24
  %t578 = add i64 %t575, 1
  store i64 %t578, ptr %l27, !tbaa !24
  br label %bb127
bb132:
  br label %bb133
bb133:
  %t580 = load ptr, ptr %lp18
  %t581 = load { i64, ptr }, ptr %t580, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t584 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t581, 1
  store { i32, { i64, ptr } } %t584, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i64, ptr } @std_2ffilepath_2ecleanMisses(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/text:StringBuilder"
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca %"std/prelude/text:StringBuilder"
  %l10 = alloca [76 x { i64, ptr }]
  %l15 = alloca i64
  %l18 = alloca i64
  %l38 = alloca { i64, ptr }
  %l43 = alloca i1
  %l52 = alloca { i64, ptr }
  %l55 = alloca i1
  %l66 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l9
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l9
  store %"std/prelude/text:StringBuilder" %t2, ptr %l0
  store i64 0, ptr %l1, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %l10, ptr @G_2estd_2ffilepath_2ecleanCases, i64 1216, i1 false)
  %t3 = load [76 x { i64, ptr }], ptr %l10
  store i64 76, ptr %l2, !tbaa !24
  store i64 2, ptr %l3, !tbaa !24
  %t5 = load i64, ptr %l2, !tbaa !24
  %t6 = load i64, ptr %l1, !tbaa !24
  %t9 = icmp sgt i64 %t5, %t6
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load i64, ptr %l3, !tbaa !24
  %t13 = icmp sgt i64 %t11, 0
  br i1 %t13, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l15, !tbaa !24
  br label %bb7
bb4:
  %t15 = load i64, ptr %l2, !tbaa !24
  %t16 = load i64, ptr %l1, !tbaa !24
  %t19 = sub i64 %t15, %t16
  %t20 = load i64, ptr %l3, !tbaa !24
  %t23 = add i64 %t19, %t20
  %t25 = sub i64 %t23, 1
  %t26 = load i64, ptr %l3, !tbaa !24
  %t29 = sdiv i64 %t25, %t26
  store i64 %t29, ptr %l18, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l18, !tbaa !24
  br label %bb6
bb6:
  %t31 = load i64, ptr %l18, !tbaa !24
  store i64 %t31, ptr %l15, !tbaa !24
  br label %bb7
bb7:
  %t32 = load i64, ptr %l15, !tbaa !24
  store i64 %t32, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t33 = load i64, ptr %l5, !tbaa !24
  %t34 = load i64, ptr %l4, !tbaa !24
  %t37 = icmp slt i64 %t33, %t34
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb25
bb10:
  br label %bb11
bb11:
  %t41 = load i64, ptr %l1, !tbaa !24
  %t42 = load i64, ptr %l5, !tbaa !24
  %t43 = load i64, ptr %l3, !tbaa !24
  %t46 = mul i64 %t42, %t43
  %t49 = add i64 %t41, %t46
  store i64 %t49, ptr %l6, !tbaa !24
  %t51 = load i64, ptr %l6, !tbaa !24
  %t53 = getelementptr [76 x { i64, ptr }], ptr @G_2estd_2ffilepath_2ecleanCases, i64 0, i64 %t51
  %t54 = load { i64, ptr }, ptr %t53, !tbaa !37
  %t55 = load ptr, ptr @__olang_prog_scope
  %t57 = call { i64, ptr } @std_2ffilepath_2eClean(ptr %t55, ptr %s2, { i64, ptr } %t54)
  store { i64, ptr } %t57, ptr %l38
  br label %bb12
bb12:
  %t58 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t58, ptr %l7, !tbaa !27
  %t59 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t60 = load i64, ptr %l6, !tbaa !24
  %t62 = add i64 %t60, 1
  %t64 = getelementptr [76 x { i64, ptr }], ptr @G_2estd_2ffilepath_2ecleanCases, i64 0, i64 %t62
  %t65 = load { i64, ptr }, ptr %t64, !tbaa !37
  %t66 = load ptr, ptr @__olang_prog_scope
  %t69 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s2, ptr %t66, { i64, ptr } %t59, { i64, ptr } %t65)
  store i1 %t69, ptr %l43
  br label %bb13
bb13:
  %t70 = load i1, ptr %l43, !tbaa !21
  %t71 = xor i1 %t70, true
  br i1 %t71, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s3
  %t73 = load i64, ptr %l6, !tbaa !24
  %t75 = getelementptr [76 x { i64, ptr }], ptr @G_2estd_2ffilepath_2ecleanCases, i64 0, i64 %t73
  %t76 = load { i64, ptr }, ptr %t75, !tbaa !37
  %t77 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t79 = extractvalue { i64, ptr } %t76, 1
  %t80 = extractvalue { i64, ptr } %t76, 0
  %t81 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d6, i32 0, i32 1) }, 1
  %t82 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d6, i32 0, i32 1) }, 0
  %t83 = add i64 %t80, %t82
  %t85 = extractvalue { i64, ptr } %t77, 1
  %t86 = extractvalue { i64, ptr } %t77, 0
  %t87 = add i64 %t83, %t86
  %t88 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d7, i32 0, i32 1) }, 1
  %t89 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d7, i32 0, i32 1) }, 0
  %t90 = add i64 %t87, %t89
  %t91 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t90)
  call void @olang_textcopy(ptr %t91, ptr %t79, i64 %t80)
  %t92 = getelementptr i8, ptr %t91, i64 %t80
  call void @olang_textcopy(ptr %t92, ptr %t81, i64 %t82)
  %t93 = getelementptr i8, ptr %t92, i64 %t82
  call void @olang_textcopy(ptr %t93, ptr %t85, i64 %t86)
  %t94 = getelementptr i8, ptr %t93, i64 %t86
  call void @olang_textcopy(ptr %t94, ptr %t88, i64 %t89)
  %t95 = insertvalue { i64, ptr } undef, i64 %t90, 0
  %t96 = insertvalue { i64, ptr } %t95, ptr %t91, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s3, ptr %l0, { i64, ptr } %t96)
  br label %bb16
bb15:
  br label %bb17
bb16:
  call void @__olang_scope_close(ptr %s3)
  br label %bb17
bb17:
  %t100 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t102 = call { i64, ptr } @std_2ffilepath_2eClean(ptr %s2, ptr %s2, { i64, ptr } %t100)
  store { i64, ptr } %t102, ptr %l52
  br label %bb18
bb18:
  %t103 = load { i64, ptr }, ptr %l52, !tbaa !27
  store { i64, ptr } %t103, ptr %l8, !tbaa !27
  %t104 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t105 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t108 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s2, ptr %s2, { i64, ptr } %t104, { i64, ptr } %t105)
  store i1 %t108, ptr %l55
  br label %bb19
bb19:
  %t109 = load i1, ptr %l55, !tbaa !21
  %t110 = xor i1 %t109, true
  br i1 %t110, label %bb20, label %bb21
bb20:
  store %olang.scope zeroinitializer, ptr %s5
  %t112 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t113 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t115 = extractvalue { i64, ptr } %t112, 1
  %t116 = extractvalue { i64, ptr } %t112, 0
  %t117 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d8, i32 0, i32 1) }, 1
  %t118 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d8, i32 0, i32 1) }, 0
  %t119 = add i64 %t116, %t118
  %t121 = extractvalue { i64, ptr } %t113, 1
  %t122 = extractvalue { i64, ptr } %t113, 0
  %t123 = add i64 %t119, %t122
  %t124 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d9, i32 0, i32 1) }, 1
  %t125 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d9, i32 0, i32 1) }, 0
  %t126 = add i64 %t123, %t125
  %t127 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t126)
  call void @olang_textcopy(ptr %t127, ptr %t115, i64 %t116)
  %t128 = getelementptr i8, ptr %t127, i64 %t116
  call void @olang_textcopy(ptr %t128, ptr %t117, i64 %t118)
  %t129 = getelementptr i8, ptr %t128, i64 %t118
  call void @olang_textcopy(ptr %t129, ptr %t121, i64 %t122)
  %t130 = getelementptr i8, ptr %t129, i64 %t122
  call void @olang_textcopy(ptr %t130, ptr %t124, i64 %t125)
  %t131 = insertvalue { i64, ptr } undef, i64 %t126, 0
  %t132 = insertvalue { i64, ptr } %t131, ptr %t127, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s5, ptr %l0, { i64, ptr } %t132)
  br label %bb22
bb21:
  br label %bb23
bb22:
  call void @__olang_scope_close(ptr %s5)
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s2)
  br label %bb24
bb24:
  %t136 = load i64, ptr %l5, !tbaa !24
  %t139 = add i64 %t136, 1
  store i64 %t139, ptr %l5, !tbaa !24
  br label %bb8
bb25:
  %t142 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v0, ptr %l0)
  store { i64, ptr } %t142, ptr %l66
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s0)
  %t143 = load { i64, ptr }, ptr %l66, !tbaa !27
  store { i64, ptr } %t143, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @std_2ffilepath_2epartMisses(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/text:StringBuilder"
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca %"std/prelude/text:StringBuilder"
  %l9 = alloca [57 x { i64, ptr }]
  %l14 = alloca i64
  %l17 = alloca i64
  %l38 = alloca { i64, ptr }
  %l42 = alloca i1
  %l44 = alloca ptr
  %l45 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l51 = alloca { i64, ptr }
  %l55 = alloca i1
  %l57 = alloca ptr
  %l58 = alloca { i64, ptr }
  %l60 = alloca { i64, ptr }
  %l67 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l8
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l8
  store %"std/prelude/text:StringBuilder" %t2, ptr %l0
  store i64 0, ptr %l1, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %l9, ptr @G_2estd_2ffilepath_2epartCases, i64 912, i1 false)
  %t3 = load [57 x { i64, ptr }], ptr %l9
  store i64 57, ptr %l2, !tbaa !24
  store i64 3, ptr %l3, !tbaa !24
  %t5 = load i64, ptr %l2, !tbaa !24
  %t6 = load i64, ptr %l1, !tbaa !24
  %t9 = icmp sgt i64 %t5, %t6
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load i64, ptr %l3, !tbaa !24
  %t13 = icmp sgt i64 %t11, 0
  br i1 %t13, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l14, !tbaa !24
  br label %bb7
bb4:
  %t15 = load i64, ptr %l2, !tbaa !24
  %t16 = load i64, ptr %l1, !tbaa !24
  %t19 = sub i64 %t15, %t16
  %t20 = load i64, ptr %l3, !tbaa !24
  %t23 = add i64 %t19, %t20
  %t25 = sub i64 %t23, 1
  %t26 = load i64, ptr %l3, !tbaa !24
  %t29 = sdiv i64 %t25, %t26
  store i64 %t29, ptr %l17, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb6
bb6:
  %t31 = load i64, ptr %l17, !tbaa !24
  store i64 %t31, ptr %l14, !tbaa !24
  br label %bb7
bb7:
  %t32 = load i64, ptr %l14, !tbaa !24
  store i64 %t32, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t33 = load i64, ptr %l5, !tbaa !24
  %t34 = load i64, ptr %l4, !tbaa !24
  %t37 = icmp slt i64 %t33, %t34
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb27
bb10:
  br label %bb11
bb11:
  %t41 = load i64, ptr %l1, !tbaa !24
  %t42 = load i64, ptr %l5, !tbaa !24
  %t43 = load i64, ptr %l3, !tbaa !24
  %t46 = mul i64 %t42, %t43
  %t49 = add i64 %t41, %t46
  store i64 %t49, ptr %l6, !tbaa !24
  %t51 = load i64, ptr %l6, !tbaa !24
  %t53 = getelementptr [57 x { i64, ptr }], ptr @G_2estd_2ffilepath_2epartCases, i64 0, i64 %t51
  %t54 = load { i64, ptr }, ptr %t53, !tbaa !37
  store { i64, ptr } %t54, ptr %l7, !tbaa !27
  %t56 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t57 = load ptr, ptr @__olang_prog_scope
  %t58 = load ptr, ptr @__olang_prog_scope
  %t60 = call { i64, ptr } @std_2ffilepath_2eBase(ptr %t57, ptr %t58, { i64, ptr } %t56)
  store { i64, ptr } %t60, ptr %l38
  br label %bb12
bb12:
  %t61 = load i64, ptr %l6, !tbaa !24
  %t63 = add i64 %t61, 1
  %t65 = getelementptr [57 x { i64, ptr }], ptr @G_2estd_2ffilepath_2epartCases, i64 0, i64 %t63
  %t66 = load { i64, ptr }, ptr %t65, !tbaa !37
  %t67 = load ptr, ptr @__olang_prog_scope
  %t68 = load ptr, ptr @__olang_prog_scope
  %t69 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t71 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %t67, ptr %t68, { i64, ptr } %t69, { i64, ptr } %t66)
  store i1 %t71, ptr %l42
  br label %bb13
bb13:
  %t72 = load i1, ptr %l42, !tbaa !21
  %t73 = xor i1 %t72, true
  br i1 %t73, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s3
  store ptr %l0, ptr %l44, !tbaa !29
  %t75 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t75, ptr %l45, !tbaa !27
  %t76 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t77 = load ptr, ptr @__olang_prog_scope
  %t79 = call { i64, ptr } @std_2ffilepath_2eBase(ptr %t77, ptr %s3, { i64, ptr } %t76)
  store { i64, ptr } %t79, ptr %l47
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t80 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d10, i32 0, i32 1) }, 1
  %t81 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d10, i32 0, i32 1) }, 0
  %t82 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t83 = extractvalue { i64, ptr } %t82, 1
  %t84 = extractvalue { i64, ptr } %t82, 0
  %t85 = add i64 %t81, %t84
  %t86 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d11, i32 0, i32 1) }, 1
  %t87 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d11, i32 0, i32 1) }, 0
  %t88 = add i64 %t85, %t87
  %t89 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t90 = extractvalue { i64, ptr } %t89, 1
  %t91 = extractvalue { i64, ptr } %t89, 0
  %t92 = add i64 %t88, %t91
  %t93 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d12, i32 0, i32 1) }, 1
  %t94 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d12, i32 0, i32 1) }, 0
  %t95 = add i64 %t92, %t94
  %t96 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t95)
  call void @olang_textcopy(ptr %t96, ptr %t80, i64 %t81)
  %t97 = getelementptr i8, ptr %t96, i64 %t81
  call void @olang_textcopy(ptr %t97, ptr %t83, i64 %t84)
  %t98 = getelementptr i8, ptr %t97, i64 %t84
  call void @olang_textcopy(ptr %t98, ptr %t86, i64 %t87)
  %t99 = getelementptr i8, ptr %t98, i64 %t87
  call void @olang_textcopy(ptr %t99, ptr %t90, i64 %t91)
  %t100 = getelementptr i8, ptr %t99, i64 %t91
  call void @olang_textcopy(ptr %t100, ptr %t93, i64 %t94)
  %t101 = insertvalue { i64, ptr } undef, i64 %t95, 0
  %t102 = insertvalue { i64, ptr } %t101, ptr %t96, 1
  %t104 = load ptr, ptr %l44, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s3, ptr %t104, { i64, ptr } %t102)
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s3)
  br label %bb18
bb18:
  %t106 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t107 = load ptr, ptr @__olang_prog_scope
  %t109 = call { i64, ptr } @std_2ffilepath_2eDir(ptr %t107, ptr %s2, { i64, ptr } %t106)
  store { i64, ptr } %t109, ptr %l51
  br label %bb19
bb19:
  %t110 = load i64, ptr %l6, !tbaa !24
  %t112 = add i64 %t110, 2
  %t114 = getelementptr [57 x { i64, ptr }], ptr @G_2estd_2ffilepath_2epartCases, i64 0, i64 %t112
  %t115 = load { i64, ptr }, ptr %t114, !tbaa !37
  %t116 = load ptr, ptr @__olang_prog_scope
  %t117 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t119 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s2, ptr %t116, { i64, ptr } %t117, { i64, ptr } %t115)
  store i1 %t119, ptr %l55
  br label %bb20
bb20:
  %t120 = load i1, ptr %l55, !tbaa !21
  %t121 = xor i1 %t120, true
  br i1 %t121, label %bb21, label %bb22
bb21:
  store %olang.scope zeroinitializer, ptr %s5
  store ptr %l0, ptr %l57, !tbaa !29
  %t123 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t123, ptr %l58, !tbaa !27
  %t124 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t125 = load ptr, ptr @__olang_prog_scope
  %t127 = call { i64, ptr } @std_2ffilepath_2eDir(ptr %t125, ptr %s5, { i64, ptr } %t124)
  store { i64, ptr } %t127, ptr %l60
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t128 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d13, i32 0, i32 1) }, 1
  %t129 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d13, i32 0, i32 1) }, 0
  %t130 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t131 = extractvalue { i64, ptr } %t130, 1
  %t132 = extractvalue { i64, ptr } %t130, 0
  %t133 = add i64 %t129, %t132
  %t134 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d14, i32 0, i32 1) }, 1
  %t135 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d14, i32 0, i32 1) }, 0
  %t136 = add i64 %t133, %t135
  %t137 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t138 = extractvalue { i64, ptr } %t137, 1
  %t139 = extractvalue { i64, ptr } %t137, 0
  %t140 = add i64 %t136, %t139
  %t141 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d15, i32 0, i32 1) }, 1
  %t142 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d15, i32 0, i32 1) }, 0
  %t143 = add i64 %t140, %t142
  %t144 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t143)
  call void @olang_textcopy(ptr %t144, ptr %t128, i64 %t129)
  %t145 = getelementptr i8, ptr %t144, i64 %t129
  call void @olang_textcopy(ptr %t145, ptr %t131, i64 %t132)
  %t146 = getelementptr i8, ptr %t145, i64 %t132
  call void @olang_textcopy(ptr %t146, ptr %t134, i64 %t135)
  %t147 = getelementptr i8, ptr %t146, i64 %t135
  call void @olang_textcopy(ptr %t147, ptr %t138, i64 %t139)
  %t148 = getelementptr i8, ptr %t147, i64 %t139
  call void @olang_textcopy(ptr %t148, ptr %t141, i64 %t142)
  %t149 = insertvalue { i64, ptr } undef, i64 %t143, 0
  %t150 = insertvalue { i64, ptr } %t149, ptr %t144, 1
  %t152 = load ptr, ptr %l57, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s5, ptr %t152, { i64, ptr } %t150)
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s5)
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s2)
  br label %bb26
bb26:
  %t154 = load i64, ptr %l5, !tbaa !24
  %t157 = add i64 %t154, 1
  store i64 %t157, ptr %l5, !tbaa !24
  br label %bb8
bb27:
  %t160 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v0, ptr %l0)
  store { i64, ptr } %t160, ptr %l67
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s0)
  %t161 = load { i64, ptr }, ptr %l67, !tbaa !27
  store { i64, ptr } %t161, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @std_2ffilepath_2erelMisses(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/text:StringBuilder"
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca %"std/prelude/text:StringBuilder"
  %l9 = alloca [117 x { i64, ptr }]
  %l14 = alloca i64
  %l17 = alloca i64
  %l35 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l42 = alloca i32
  %l43 = alloca { i64, ptr }
  %l45 = alloca i64
  %l46 = alloca { i64, ptr }
  %l51 = alloca i1
  %l66 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l8
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l8
  store %"std/prelude/text:StringBuilder" %t2, ptr %l0
  store i64 0, ptr %l1, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %l9, ptr @G_2estd_2ffilepath_2erelCases, i64 1872, i1 false)
  %t3 = load [117 x { i64, ptr }], ptr %l9
  store i64 117, ptr %l2, !tbaa !24
  store i64 3, ptr %l3, !tbaa !24
  %t5 = load i64, ptr %l2, !tbaa !24
  %t6 = load i64, ptr %l1, !tbaa !24
  %t9 = icmp sgt i64 %t5, %t6
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load i64, ptr %l3, !tbaa !24
  %t13 = icmp sgt i64 %t11, 0
  br i1 %t13, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l14, !tbaa !24
  br label %bb7
bb4:
  %t15 = load i64, ptr %l2, !tbaa !24
  %t16 = load i64, ptr %l1, !tbaa !24
  %t19 = sub i64 %t15, %t16
  %t20 = load i64, ptr %l3, !tbaa !24
  %t23 = add i64 %t19, %t20
  %t25 = sub i64 %t23, 1
  %t26 = load i64, ptr %l3, !tbaa !24
  %t29 = sdiv i64 %t25, %t26
  store i64 %t29, ptr %l17, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb6
bb6:
  %t31 = load i64, ptr %l17, !tbaa !24
  store i64 %t31, ptr %l14, !tbaa !24
  br label %bb7
bb7:
  %t32 = load i64, ptr %l14, !tbaa !24
  store i64 %t32, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t33 = load i64, ptr %l5, !tbaa !24
  %t34 = load i64, ptr %l4, !tbaa !24
  %t37 = icmp slt i64 %t33, %t34
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb22
bb10:
  br label %bb11
bb11:
  %t41 = load i64, ptr %l1, !tbaa !24
  %t42 = load i64, ptr %l5, !tbaa !24
  %t43 = load i64, ptr %l3, !tbaa !24
  %t46 = mul i64 %t42, %t43
  %t49 = add i64 %t41, %t46
  store i64 %t49, ptr %l6, !tbaa !24
  %t51 = load i64, ptr %l6, !tbaa !24
  %t53 = getelementptr [117 x { i64, ptr }], ptr @G_2estd_2ffilepath_2erelCases, i64 0, i64 %t51
  %t54 = load { i64, ptr }, ptr %t53, !tbaa !37
  %t55 = load i64, ptr %l6, !tbaa !24
  %t57 = add i64 %t55, 1
  %t59 = getelementptr [117 x { i64, ptr }], ptr @G_2estd_2ffilepath_2erelCases, i64 0, i64 %t57
  %t60 = load { i64, ptr }, ptr %t59, !tbaa !37
  %t61 = load ptr, ptr @__olang_prog_scope
  %t62 = load ptr, ptr @__olang_prog_scope
  %t65 = call { i32, { i64, ptr } } @std_2ffilepath_2eRel(ptr %t61, ptr %t62, ptr %s2, { i64, ptr } %t54, { i64, ptr } %t60)
  %t66 = extractvalue { i32, { i64, ptr } } %t65, 1
  %t67 = extractvalue { i32, { i64, ptr } } %t65, 0
  store i32 %t67, ptr %l42
  %t68 = icmp ne i32 %t67, 0
  br i1 %t68, label %bb13, label %ok.69, !prof !99
ok.69:
  store { i64, ptr } %t66, ptr %l41
  br label %bb12
bb12:
  %t70 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t70, ptr %l35, !tbaa !27
  br label %bb15
bb13:
  br label %bb14
bb14:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d16, i32 0, i32 1) }, ptr %l43, !tbaa !27
  %t71 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t71, ptr %l35, !tbaa !27
  br label %bb15
bb15:
  %t73 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t74 = extractvalue { i64, ptr } %t73, 0
  store i64 %t74, ptr %l45, !tbaa !24
  %t75 = load i64, ptr %l45, !tbaa !24
  %t76 = mul i64 %t75, 1
  %t77 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t76)
  %t78 = insertvalue { i64, ptr } undef, i64 %t75, 0
  %t79 = insertvalue { i64, ptr } %t78, ptr %t77, 1
  store { i64, ptr } %t79, ptr %l46, !tbaa !27
  %t80 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t81 = load ptr, ptr %t80, !tbaa !27
  %t82 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !27
  %t84 = load i64, ptr %l45, !tbaa !24
  %t85 = mul i64 %t84, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t81, ptr %t83, i64 %t85, i1 false)
  %t86 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t86, ptr %l7, !tbaa !27
  %t87 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t88 = load i64, ptr %l6, !tbaa !24
  %t90 = add i64 %t88, 2
  %t92 = getelementptr [117 x { i64, ptr }], ptr @G_2estd_2ffilepath_2erelCases, i64 0, i64 %t90
  %t93 = load { i64, ptr }, ptr %t92, !tbaa !37
  %t94 = load ptr, ptr @__olang_prog_scope
  %t97 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s2, ptr %t94, { i64, ptr } %t87, { i64, ptr } %t93)
  store i1 %t97, ptr %l51
  br label %bb16
bb16:
  %t98 = load i1, ptr %l51, !tbaa !21
  %t99 = xor i1 %t98, true
  br i1 %t99, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s3
  %t101 = load i64, ptr %l6, !tbaa !24
  %t103 = getelementptr [117 x { i64, ptr }], ptr @G_2estd_2ffilepath_2erelCases, i64 0, i64 %t101
  %t104 = load { i64, ptr }, ptr %t103, !tbaa !37
  %t105 = load i64, ptr %l6, !tbaa !24
  %t107 = add i64 %t105, 1
  %t109 = getelementptr [117 x { i64, ptr }], ptr @G_2estd_2ffilepath_2erelCases, i64 0, i64 %t107
  %t110 = load { i64, ptr }, ptr %t109, !tbaa !37
  %t111 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t112 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d17, i32 0, i32 1) }, 1
  %t113 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d17, i32 0, i32 1) }, 0
  %t115 = extractvalue { i64, ptr } %t104, 1
  %t116 = extractvalue { i64, ptr } %t104, 0
  %t117 = add i64 %t113, %t116
  %t118 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d18, i32 0, i32 1) }, 1
  %t119 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d18, i32 0, i32 1) }, 0
  %t120 = add i64 %t117, %t119
  %t122 = extractvalue { i64, ptr } %t110, 1
  %t123 = extractvalue { i64, ptr } %t110, 0
  %t124 = add i64 %t120, %t123
  %t125 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d19, i32 0, i32 1) }, 1
  %t126 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d19, i32 0, i32 1) }, 0
  %t127 = add i64 %t124, %t126
  %t129 = extractvalue { i64, ptr } %t111, 1
  %t130 = extractvalue { i64, ptr } %t111, 0
  %t131 = add i64 %t127, %t130
  %t132 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d20, i32 0, i32 1) }, 1
  %t133 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d20, i32 0, i32 1) }, 0
  %t134 = add i64 %t131, %t133
  %t135 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t134)
  call void @olang_textcopy(ptr %t135, ptr %t112, i64 %t113)
  %t136 = getelementptr i8, ptr %t135, i64 %t113
  call void @olang_textcopy(ptr %t136, ptr %t115, i64 %t116)
  %t137 = getelementptr i8, ptr %t136, i64 %t116
  call void @olang_textcopy(ptr %t137, ptr %t118, i64 %t119)
  %t138 = getelementptr i8, ptr %t137, i64 %t119
  call void @olang_textcopy(ptr %t138, ptr %t122, i64 %t123)
  %t139 = getelementptr i8, ptr %t138, i64 %t123
  call void @olang_textcopy(ptr %t139, ptr %t125, i64 %t126)
  %t140 = getelementptr i8, ptr %t139, i64 %t126
  call void @olang_textcopy(ptr %t140, ptr %t129, i64 %t130)
  %t141 = getelementptr i8, ptr %t140, i64 %t130
  call void @olang_textcopy(ptr %t141, ptr %t132, i64 %t133)
  %t142 = insertvalue { i64, ptr } undef, i64 %t134, 0
  %t143 = insertvalue { i64, ptr } %t142, ptr %t135, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s3, ptr %l0, { i64, ptr } %t143)
  br label %bb19
bb18:
  br label %bb20
bb19:
  call void @__olang_scope_close(ptr %s3)
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s2)
  br label %bb21
bb21:
  %t147 = load i64, ptr %l5, !tbaa !24
  %t150 = add i64 %t147, 1
  store i64 %t150, ptr %l5, !tbaa !24
  br label %bb8
bb22:
  %t153 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v0, ptr %l0)
  store { i64, ptr } %t153, ptr %l66
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s0)
  %t154 = load { i64, ptr }, ptr %l66, !tbaa !27
  store { i64, ptr } %t154, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

@.d0 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %dh = load ptr, ptr %dheadptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  %hasd = icmp ne ptr %dh, null
  %owns = or i1 %hasf, %hasd
  br i1 %owns, label %owned, label %chunks
owned:
  call void @__olang_scope_close_owned(ptr %scope)
  br label %chunks
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
declare void @__olang_check_failed(ptr) cold noreturn
@.d1 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
@.d2 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d3 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d4 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d5 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c".." }>, align 8
@__olang_prog_scope = external thread_local(initialexec) global ptr
@.d6 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" -> " }>, align 8
@.d7 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"; " }>, align 8
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d8 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c" again -> " }>, align 8
@.d9 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"; " }>, align 8
@.d10 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"Base(" }>, align 8
@.d11 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c") = " }>, align 8
@.d12 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"; " }>, align 8
@.d13 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Dir(" }>, align 8
@.d14 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c") = " }>, align 8
@.d15 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"; " }>, align 8
@.d16 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"!" }>, align 8
@.d17 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Rel(" }>, align 8
@.d18 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d19 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c") = " }>, align 8
@.d20 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"; " }>, align 8
declare void @__olang_scope_close_owned(ptr) noinline
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@olang_loc_71a6929ab52159a_17fdf02a3251bece = external constant [0 x i8]
@olang_loc_a602995b964ddbcf_b078a441454e17cb = external constant [0 x i8]
@olang_loc_a7ca1e4a4409b00c_ac64874c39ec6a0 = external constant [0 x i8]
@olang_loc_88514958f43ac5a5_71c1ca98982dfa9 = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_d061c7e25d631130_ed41ebaf937312b4 = external constant [0 x i8]
declare i1 @std_2ffilepath_2eIsAbs(ptr %v0, { i64, ptr } %a0)
@olang_loc_668000db62bcfe0d_fbc758d8da0c96a1 = external constant [0 x i8]
@olang_loc_25fb20074e4b49ae_c59224b0534d5022 = external constant [0 x i8]
@olang_loc_3fc5cad3648832ab_e217ea960297dd9f = external constant [0 x i8]
@olang_loc_6975e58e775568a4_668b7bdd2238b9c0 = external constant [0 x i8]
@olang_loc_1fc14433466d7ed9_4c0c0b85aca7f45d = external constant [0 x i8]
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
@G_2estd_2ffilepath_2ecleanCases = external constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }>
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
@G_2estd_2ffilepath_2epartCases = external constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }>
declare { i64, ptr } @std_2ffilepath_2eBase(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @std_2ffilepath_2eDir(ptr %v0, ptr %v1, { i64, ptr } %a0)
@G_2estd_2ffilepath_2erelCases = external constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }>

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
