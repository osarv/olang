; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/lower:Lowerer" = type { ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i32, i32 }
%"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1 }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/generic:AnyTable" = type { i32, i32, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/lower:pl" = type { { i64, [2 x i64] }, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/mir:Fn" = type { { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i64 }
%"compiler/lower:lowering" = type { ptr, ptr, ptr, %"compiler/mir:Fn", i64, { i64, [4 x i64] }, i32, i1, i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i32, { i64, [1 x i64] }, %"compiler/typed:Plan", i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64 }
%"compiler/typed:Plan" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/mir:Place" = type { { i64, [2 x i64] }, %"compiler/mir:Range" }
%"compiler/mir:Range" = type { i32, i32 }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/types:Table" = type { ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64 }
%"compiler/typed:Promote" = type { ptr, i32 }
%"compiler/typed:Make" = type { i32, i64, { i64, ptr }, ptr, i32, i32 }
%"compiler/typed:Call" = type { ptr, { i64, ptr }, { i64, [2 x i64] }, i32, i1 }
%"compiler/lower:level" = type { i32, i32, i32 }
%"compiler/typed:BlockInfo" = type { i32, i32, %"compiler/source:Span" }
%"compiler/typed:Block" = type { i32, { i64, ptr } }
%"compiler/mir:Call" = type { { i64, [7 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Place", i1, i32, i32, i32 }
%"compiler/lower:tryCtx" = type { i64, { i64, ptr }, i1, i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/typed:Clause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr, { i64, ptr }, i64, i32 }
%"compiler/lower:collectCtx" = type { i32, i32, i32, i32, { i64, [1 x i64] }, i1, i1 }
%"compiler/typed:Collect" = type { ptr, ptr, i32, i32, i1 }
%"compiler/typed:Cond" = type { ptr, ptr, ptr }
%"compiler/typed:Join" = type { ptr, i1, { i64, ptr } }
%"compiler/lower:loopCtx" = type { i32, i64, i32, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/typed:Text" = type { { i64, ptr }, i32 }
%"compiler/typed:Slice" = type { ptr, ptr, ptr, i32 }
%"compiler/mir:Local" = type { i32, %"compiler/source:Span", i32, i32, { i64, [1 x i64] } }
%"compiler/typed:Local" = type { i32, %"compiler/source:Span", i32, i32, i32, { i64, [2 x i64] } }
%"compiler/lower:Gap" = type { i64, %"compiler/source:Span", { i64, ptr } }
define dso_local void @compiler_2flower_2eContract_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 4, ptr @G_2ecompiler_2flower_2eContract, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flower_2eEmpty_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 5, ptr @G_2ecompiler_2flower_2eEmpty, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flower_2eFailIds_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  %t1 = insertvalue [6 x { i64, ptr }] undef, { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d0, i32 0, i32 1) }, 0
  %t2 = insertvalue [6 x { i64, ptr }] %t1, { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d1, i32 0, i32 1) }, 1
  %t3 = insertvalue [6 x { i64, ptr }] %t2, { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d2, i32 0, i32 1) }, 2
  %t4 = insertvalue [6 x { i64, ptr }] %t3, { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d3, i32 0, i32 1) }, 3
  %t5 = insertvalue [6 x { i64, ptr }] %t4, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d4, i32 0, i32 1) }, 4
  %t6 = insertvalue [6 x { i64, ptr }] %t5, { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d5, i32 0, i32 1) }, 5
  store [6 x { i64, ptr }] %t6, ptr @G_2ecompiler_2flower_2eFailIds
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flower_2eFailTypes_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  %t1 = insertvalue [6 x { i64, ptr }] undef, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d6, i32 0, i32 1) }, 0
  %t2 = insertvalue [6 x { i64, ptr }] %t1, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d7, i32 0, i32 1) }, 1
  %t3 = insertvalue [6 x { i64, ptr }] %t2, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d8, i32 0, i32 1) }, 2
  %t4 = insertvalue [6 x { i64, ptr }] %t3, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d9, i32 0, i32 1) }, 3
  %t5 = insertvalue [6 x { i64, ptr }] %t4, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d10, i32 0, i32 1) }, 4
  %t6 = insertvalue [6 x { i64, ptr }] %t5, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d11, i32 0, i32 1) }, 5
  store [6 x { i64, ptr }] %t6, ptr @G_2ecompiler_2flower_2eFailTypes
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flower_2eOverflow_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 1, ptr @G_2ecompiler_2flower_2eOverflow, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3aLowerer_2eHasCode(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l7 = alloca ptr
  %l14 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/lower:Lowerer", ptr %a0, i32 0, i32 1
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store ptr %t7, ptr %l7
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l7, !tbaa !29
  store ptr %t8, ptr %l2, !tbaa !29
  %t9 = load ptr, ptr %l2, !tbaa !29
  %t11 = getelementptr %"compiler/typed:Body", ptr %t9, i32 0, i32 11
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = icmp eq ptr %t12, null
  br i1 %t14, label %bb2, label %bb3
bb2:
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t19 = getelementptr %"compiler/typed:Body", ptr %t17, i32 0, i32 1
  %t20 = load { i64, [2 x i64] }, ptr %t19
  %t24 = extractvalue { i64, [2 x i64] } %t20, 0
  %t25 = icmp eq i64 %t24, 2
  br i1 %t25, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb13
bb8:
  br i1 true, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_daa9f23a83841987_24921124063ad36b)
  unreachable
bb13:
  %t27 = load i1, ptr %l14, !tbaa !21
  store i1 %t27, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3aLowerer_2eWant(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [2 x i64] }
  %l5 = alloca i1
  store ptr %a0, ptr %l0
  store { i64, [2 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:Lowerer", ptr %t1, i32 0, i32 9
  %t4 = load { i64, [2 x i64] }, ptr %l1
  %t7 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e_2e_Hf0a5beca6f8aee4731a76bd327ae0a99(ptr %v0, ptr %t3, { i64, [2 x i64] } %t4)
  store i1 %t7, ptr %l5
  br label %bb1
bb1:
  %t8 = load i1, ptr %l5, !tbaa !21
  br i1 %t8, label %bb2, label %bb3
bb2:
  br label %ret
bb3:
  br label %bb4
bb4:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/lower:Lowerer", ptr %t9, i32 0, i32 9
  %t12 = load { i64, [2 x i64] }, ptr %l1
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e_2e_He6968003b8dd5762fa82ec44b4ee1fc9(ptr %v0, ptr %t11, { i64, [2 x i64] } %t12, i1 true)
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/lower:Lowerer", ptr %t15, i32 0, i32 8
  %t18 = load { i64, [2 x i64] }, ptr %l1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFnKey_3e_2ePush_3ccompiler_2fmir_3aFnKey_3e(ptr %v0, ptr %t17, { i64, [2 x i64] } %t18)
  br label %bb6
bb6:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3aLowerer_2eanyRender(ptr %out, ptr %v0, ptr %v1, ptr %a0, i64 %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i1
  %l3 = alloca %"compiler/generic:AnyTable"
  %l4 = alloca i32
  %lp5 = alloca ptr
  %lp6 = alloca ptr
  %l7 = alloca %"compiler/source:Span"
  %l8 = alloca %"compiler/lower:pl"
  %l13 = alloca %"compiler/generic:AnyTable"
  %l19 = alloca i32
  %l21 = alloca %"compiler/typed:Body"
  %l22 = alloca ptr
  %l23 = alloca ptr
  %l26 = alloca ptr
  %l32 = alloca %"compiler/mir:Fn"
  %l34 = alloca %"compiler/lower:lowering"
  %l35 = alloca %"compiler/source:Span"
  %l38 = alloca { i64, ptr }
  %l39 = alloca %"compiler/mir:Place"
  %l42 = alloca %"compiler/lower:pl"
  %l49 = alloca %"compiler/lower:pl"
  %l51 = alloca ptr
  %l52 = alloca { i64, [1 x i64] }
  %l55 = alloca %"compiler/mir:Place"
  %l68 = alloca %"compiler/mir:Fn"
  %s0 = alloca %olang.scope
  %t26 = alloca %"compiler/typed:Body", align 8
  %t41 = alloca { i64, [2 x i64] }, align 8
  %t50 = alloca %"compiler/mir:Fn", align 8
  %t55 = alloca %"compiler/lower:lowering", align 8
  %t65 = alloca { i64, [1 x i64] }, align 8
  %t79 = alloca { i64, [4 x i64] }, align 8
  %t102 = alloca { i64, [1 x i64] }, align 8
  %t115 = alloca { i64, [1 x i64] }, align 8
  %t129 = alloca { i64, [1 x i64] }, align 8
  %t140 = alloca { i64, [4 x i64] }, align 8
  %t155 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i1 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:Lowerer", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 42
  %t7 = load i64, ptr %l1, !tbaa !24
  %t10 = call %"compiler/generic:AnyTable" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aAnyTable_3e_2eAt__He9601a52fe5cfa5abe1b41d520aed001(ptr %v0, ptr %v0, ptr %t6, i64 %t7)
  store %"compiler/generic:AnyTable" %t10, ptr %l13
  br label %bb1
bb1:
  %t11 = load %"compiler/generic:AnyTable", ptr %l13
  store %"compiler/generic:AnyTable" %t11, ptr %l3
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/lower:Lowerer", ptr %t12, i32 0, i32 0
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = getelementptr %"compiler/generic:Program", ptr %t15, i32 0, i32 2
  %t18 = getelementptr %"compiler/generic:AnyTable", ptr %l3, i32 0, i32 2
  %t19 = load i32, ptr %t18, !tbaa !23
  %t23 = call i32 @compiler_2fmir_2eHelperType(ptr %v0, ptr %t17, i32 0, i32 %t19)
  store i32 %t23, ptr %l19
  br label %bb2
bb2:
  %t24 = load i32, ptr %l19, !tbaa !23
  store i32 %t24, ptr %l4, !tbaa !23
  %t25 = load i32, ptr %l4, !tbaa !23
  call void @compiler_2flower_2estandIn(ptr %t26, ptr %v1, i32 %t25)
  call void @llvm.memmove.p0.p0.i64(ptr %l21, ptr %t26, i64 144, i1 false)
  br label %bb3
bb3:
  %t28 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 144, i64 8)
  store ptr %t28, ptr %lp5
  %t29 = load ptr, ptr %lp5
  call void @llvm.memmove.p0.p0.i64(ptr %t29, ptr %l21, i64 144, i1 false)
  %t30 = load ptr, ptr %l0, !tbaa !29
  store ptr %t30, ptr %l22, !tbaa !29
  %t31 = load ptr, ptr %lp5
  store ptr %t31, ptr %l23, !tbaa !29
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/lower:Lowerer", ptr %t32, i32 0, i32 0
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t37 = getelementptr %"compiler/generic:Program", ptr %t35, i32 0, i32 2
  store ptr %t37, ptr %l26, !tbaa !29
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load i64, ptr %l1, !tbaa !24
  %t40 = load i1, ptr %l2, !tbaa !21
  store { i64, [2 x i64] } zeroinitializer, ptr %t41
  %t42 = getelementptr { i64, [2 x i64] }, ptr %t41, i32 0, i32 0
  store i64 4, ptr %t42
  %t44 = insertvalue { i64, i1 } undef, i64 %t39, 0
  %t46 = insertvalue { i64, i1 } %t44, i1 %t40, 1
  %t47 = getelementptr { i64, [2 x i64] }, ptr %t41, i32 0, i32 1
  store { i64, i1 } %t46, ptr %t47
  %t48 = load { i64, [2 x i64] }, ptr %t41
  %t49 = load i32, ptr %l4, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3aLowerer_2ebare(ptr %t50, ptr %v0, ptr %v1, ptr %t38, { i64, [2 x i64] } %t48, i32 %t49)
  call void @llvm.memmove.p0.p0.i64(ptr %l32, ptr %t50, i64 232, i1 false)
  br label %bb4
bb4:
  %t54 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 232, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t54, ptr %l32, i64 232, i1 false)
  %t56 = load ptr, ptr %l22, !tbaa !29
  %t57 = load ptr, ptr %l23, !tbaa !29
  %t58 = load ptr, ptr %l26, !tbaa !29
  call void @compiler_2flower_3alowering_2ector(ptr %t55, ptr %v0, ptr %v1, ptr %v0, ptr %v1, ptr %v1, ptr %t56, ptr %t57, ptr %t58, ptr %t54)
  call void @llvm.memmove.p0.p0.i64(ptr %l34, ptr %t55, i64 584, i1 false)
  br label %bb5
bb5:
  %t60 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 584, i64 8)
  store ptr %t60, ptr %lp6
  %t61 = load ptr, ptr %lp6
  call void @llvm.memmove.p0.p0.i64(ptr %t61, ptr %l34, i64 584, i1 false)
  %t62 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 0, i32 0)
  store %"compiler/source:Span" %t62, ptr %l35
  br label %bb6
bb6:
  %t63 = load %"compiler/source:Span", ptr %l35
  store %"compiler/source:Span" %t63, ptr %l7
  %t64 = load ptr, ptr %lp6
  store { i64, [1 x i64] } zeroinitializer, ptr %t65
  %t66 = getelementptr { i64, [1 x i64] }, ptr %t65, i32 0, i32 0
  store i64 5, ptr %t66
  %t67 = load { i64, [1 x i64] }, ptr %t65
  %t68 = mul i64 1, 16
  %t69 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t68)
  %t70 = insertvalue { i64, ptr } undef, i64 1, 0
  %t71 = insertvalue { i64, ptr } %t70, ptr %t69, 1
  store { i64, ptr } %t71, ptr %l38, !tbaa !27
  %t73 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !27
  %t75 = getelementptr { i64, [1 x i64] }, ptr %t74, i64 0
  store { i64, [1 x i64] } %t67, ptr %t75
  %t77 = load { i64, ptr }, ptr %l38, !tbaa !27
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eprologue(ptr %v1, ptr %s0, ptr %t64, { i64, ptr } %t77)
  br label %bb7
bb7:
  %t78 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 1)
  store %"compiler/mir:Place" %t78, ptr %l39
  br label %bb8
bb8:
  store { i64, [4 x i64] } zeroinitializer, ptr %t79
  %t80 = getelementptr { i64, [4 x i64] }, ptr %t79, i32 0, i32 0
  store i64 1, ptr %t80
  %t81 = load %"compiler/mir:Place", ptr %l39
  %t82 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t81, 0
  %t83 = getelementptr { i64, [4 x i64] }, ptr %t79, i32 0, i32 1
  store { %"compiler/mir:Place" } %t82, ptr %t83
  %t84 = load { i64, [4 x i64] }, ptr %t79
  %t86 = load ptr, ptr %lp6
  %t87 = getelementptr %"compiler/lower:lowering", ptr %t86, i32 0, i32 5
  store { i64, [4 x i64] } %t84, ptr %t87
  %t88 = load ptr, ptr %lp6
  %t90 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2eat(ptr %v1, ptr %s0, ptr %t88, i32 0)
  store %"compiler/lower:pl" %t90, ptr %l42
  br label %bb9
bb9:
  %t91 = load %"compiler/lower:pl", ptr %l42
  store %"compiler/lower:pl" %t91, ptr %l8
  %t92 = getelementptr %"compiler/generic:AnyTable", ptr %l3, i32 0, i32 2
  %t93 = load i32, ptr %t92, !tbaa !23
  %t94 = getelementptr %"compiler/generic:AnyTable", ptr %l3, i32 0, i32 0
  %t95 = load i32, ptr %t94, !tbaa !23
  %t98 = icmp ne i32 %t93, %t95
  br i1 %t98, label %bb10, label %bb11
bb10:
  %t100 = load ptr, ptr %lp6
  %t101 = load %"compiler/lower:pl", ptr %l8
  store { i64, [1 x i64] } zeroinitializer, ptr %t102
  %t103 = getelementptr { i64, [1 x i64] }, ptr %t102, i32 0, i32 0
  store i64 0, ptr %t103
  %t104 = insertvalue { i64 } undef, i64 0, 0
  %t105 = getelementptr { i64, [1 x i64] }, ptr %t102, i32 0, i32 1
  store { i64 } %t104, ptr %t105
  %t106 = load { i64, [1 x i64] }, ptr %t102
  %t110 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2ewith(ptr %v1, ptr %s0, ptr %s0, ptr %t100, %"compiler/lower:pl" %t101, { i64, [1 x i64] } %t106)
  store %"compiler/lower:pl" %t110, ptr %l49
  br label %bb12
bb11:
  br label %bb13
bb12:
  %t111 = load %"compiler/lower:pl", ptr %l49
  store %"compiler/lower:pl" %t111, ptr %l8
  br label %bb13
bb13:
  %t112 = load i1, ptr %l2, !tbaa !21
  br i1 %t112, label %bb14, label %bb15
bb14:
  %t114 = load ptr, ptr %lp6
  store ptr %t114, ptr %l51, !tbaa !29
  store { i64, [1 x i64] } zeroinitializer, ptr %t115
  %t116 = getelementptr { i64, [1 x i64] }, ptr %t115, i32 0, i32 0
  store i64 1, ptr %t116
  %t117 = insertvalue { i64 } undef, i64 0, 0
  %t118 = getelementptr { i64, [1 x i64] }, ptr %t115, i32 0, i32 1
  store { i64 } %t117, ptr %t118
  %t119 = load { i64, [1 x i64] }, ptr %t115
  store { i64, [1 x i64] } %t119, ptr %l52
  %t120 = load ptr, ptr %lp6
  %t121 = load %"compiler/lower:pl", ptr %l8
  %t124 = call %"compiler/mir:Place" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v1, ptr %s0, ptr %t120, %"compiler/lower:pl" %t121)
  store %"compiler/mir:Place" %t124, ptr %l55
  br label %bb16
bb15:
  %t125 = load ptr, ptr %lp6
  %t126 = load %"compiler/lower:pl", ptr %l8
  %t127 = getelementptr %"compiler/generic:AnyTable", ptr %l3, i32 0, i32 0
  %t128 = load i32, ptr %t127, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t129
  %t130 = getelementptr { i64, [1 x i64] }, ptr %t129, i32 0, i32 0
  store i64 1, ptr %t130
  %t131 = insertvalue { i64 } undef, i64 0, 0
  %t132 = getelementptr { i64, [1 x i64] }, ptr %t129, i32 0, i32 1
  store { i64 } %t131, ptr %t132
  %t133 = load { i64, [1 x i64] }, ptr %t129
  %t134 = load %"compiler/source:Span", ptr %l7
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2einner(ptr %v1, ptr %s0, ptr %t125, %"compiler/lower:pl" %t126, i32 %t128, { i64, [1 x i64] } %t133, %"compiler/source:Span" %t134)
  br label %bb18
bb16:
  store { i64, [4 x i64] } zeroinitializer, ptr %t140
  %t141 = getelementptr { i64, [4 x i64] }, ptr %t140, i32 0, i32 0
  store i64 1, ptr %t141
  %t142 = load %"compiler/mir:Place", ptr %l55
  %t143 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t142, 0
  %t144 = getelementptr { i64, [4 x i64] }, ptr %t140, i32 0, i32 1
  store { %"compiler/mir:Place" } %t143, ptr %t144
  %t145 = load { i64, [4 x i64] }, ptr %t140
  %t146 = getelementptr %"compiler/generic:AnyTable", ptr %l3, i32 0, i32 0
  %t147 = load i32, ptr %t146, !tbaa !23
  %t148 = load %"compiler/source:Span", ptr %l7
  %t149 = load ptr, ptr %l51, !tbaa !29
  %t150 = load { i64, [1 x i64] }, ptr %l52
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2erender(ptr %v1, ptr %t149, { i64, [1 x i64] } %t150, { i64, [4 x i64] } %t145, i32 %t147, %"compiler/source:Span" %t148)
  br label %bb17
bb17:
  br label %bb19
bb18:
  br label %bb19
bb19:
  %t154 = load ptr, ptr %lp6
  store { i64, [4 x i64] } zeroinitializer, ptr %t155
  %t156 = getelementptr { i64, [4 x i64] }, ptr %t155, i32 0, i32 0
  store i64 0, ptr %t156
  %t157 = load { i64, [4 x i64] }, ptr %t155
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eepilogue(ptr %v1, ptr %t154, { i64, [4 x i64] } %t157)
  br label %bb20
bb20:
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t161 = load ptr, ptr %lp6
  %t162 = getelementptr %"compiler/lower:lowering", ptr %t161, i32 0, i32 8
  %t163 = load i1, ptr %t162, !tbaa !21
  %t166 = getelementptr %"compiler/lower:Lowerer", ptr %t160, i32 0, i32 5
  store i1 %t163, ptr %t166, !tbaa !21
  %t167 = load ptr, ptr %lp6
  %t168 = getelementptr %"compiler/lower:lowering", ptr %t167, i32 0, i32 3
  call void @llvm.memmove.p0.p0.i64(ptr %l68, ptr %t168, i64 232, i1 false)
  call void @__olang_scope_close(ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l68, i64 232, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3aLowerer_2ehelper(ptr %out, ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i32
  %lp4 = alloca ptr
  %lp5 = alloca ptr
  %l11 = alloca i32
  %l13 = alloca %"compiler/typed:Body"
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l18 = alloca ptr
  %l24 = alloca %"compiler/mir:Fn"
  %l26 = alloca %"compiler/lower:lowering"
  %l32 = alloca %"compiler/mir:Fn"
  %t15 = alloca %"compiler/typed:Body", align 8
  %t30 = alloca { i64, [2 x i64] }, align 8
  %t39 = alloca %"compiler/mir:Fn", align 8
  %t44 = alloca %"compiler/lower:lowering", align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:Lowerer", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t7 = load i32, ptr %l1
  %t8 = load i32, ptr %l2, !tbaa !23
  %t12 = call i32 @compiler_2fmir_2eHelperType(ptr %v0, ptr %t6, i32 %t7, i32 %t8)
  store i32 %t12, ptr %l11
  br label %bb1
bb1:
  %t13 = load i32, ptr %l11, !tbaa !23
  store i32 %t13, ptr %l3, !tbaa !23
  %t14 = load i32, ptr %l3, !tbaa !23
  call void @compiler_2flower_2estandIn(ptr %t15, ptr %v1, i32 %t14)
  call void @llvm.memmove.p0.p0.i64(ptr %l13, ptr %t15, i64 144, i1 false)
  br label %bb2
bb2:
  %t17 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 144, i64 8)
  store ptr %t17, ptr %lp4
  %t18 = load ptr, ptr %lp4
  call void @llvm.memmove.p0.p0.i64(ptr %t18, ptr %l13, i64 144, i1 false)
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l14, !tbaa !29
  %t20 = load ptr, ptr %lp4
  store ptr %t20, ptr %l15, !tbaa !29
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/lower:Lowerer", ptr %t21, i32 0, i32 0
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t26 = getelementptr %"compiler/generic:Program", ptr %t24, i32 0, i32 2
  store ptr %t26, ptr %l18, !tbaa !29
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load i32, ptr %l1
  %t29 = load i32, ptr %l2, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t30
  %t31 = getelementptr { i64, [2 x i64] }, ptr %t30, i32 0, i32 0
  store i64 2, ptr %t31
  %t33 = insertvalue { i32, i32 } undef, i32 %t28, 0
  %t35 = insertvalue { i32, i32 } %t33, i32 %t29, 1
  %t36 = getelementptr { i64, [2 x i64] }, ptr %t30, i32 0, i32 1
  store { i32, i32 } %t35, ptr %t36
  %t37 = load { i64, [2 x i64] }, ptr %t30
  %t38 = load i32, ptr %l3, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3aLowerer_2ebare(ptr %t39, ptr %v0, ptr %v1, ptr %t27, { i64, [2 x i64] } %t37, i32 %t38)
  call void @llvm.memmove.p0.p0.i64(ptr %l24, ptr %t39, i64 232, i1 false)
  br label %bb3
bb3:
  %t43 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 232, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t43, ptr %l24, i64 232, i1 false)
  %t45 = load ptr, ptr %l14, !tbaa !29
  %t46 = load ptr, ptr %l15, !tbaa !29
  %t47 = load ptr, ptr %l18, !tbaa !29
  call void @compiler_2flower_3alowering_2ector(ptr %t44, ptr %v0, ptr %v1, ptr %v0, ptr %v1, ptr %v1, ptr %t45, ptr %t46, ptr %t47, ptr %t43)
  call void @llvm.memmove.p0.p0.i64(ptr %l26, ptr %t44, i64 584, i1 false)
  br label %bb4
bb4:
  %t49 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 584, i64 8)
  store ptr %t49, ptr %lp5
  %t50 = load ptr, ptr %lp5
  call void @llvm.memmove.p0.p0.i64(ptr %t50, ptr %l26, i64 584, i1 false)
  %t51 = load ptr, ptr %lp5
  %t52 = load i32, ptr %l1
  %t53 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ehelper(ptr %v1, ptr %t51, i32 %t52, i32 %t53)
  br label %bb5
bb5:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t58 = load ptr, ptr %lp5
  %t59 = getelementptr %"compiler/lower:lowering", ptr %t58, i32 0, i32 8
  %t60 = load i1, ptr %t59, !tbaa !21
  %t63 = getelementptr %"compiler/lower:Lowerer", ptr %t57, i32 0, i32 5
  store i1 %t60, ptr %t63, !tbaa !21
  %t64 = load ptr, ptr %lp5
  %t65 = getelementptr %"compiler/lower:lowering", ptr %t64, i32 0, i32 3
  call void @llvm.memmove.p0.p0.i64(ptr %l32, ptr %t65, i64 232, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l32, i64 232, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eanyMake(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca %"compiler/source:Span"
  %l10 = alloca i32
  %l11 = alloca ptr
  %l12 = alloca { i64, [1 x i64] }
  %l13 = alloca ptr
  %l14 = alloca { i64, [4 x i64] }
  %l17 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l22 = alloca ptr
  %l23 = alloca i1
  %l32 = alloca ptr
  %l33 = alloca i1
  %l45 = alloca i1
  %l50 = alloca i1
  %l51 = alloca ptr
  %l53 = alloca { i64, ptr }
  %l55 = alloca i32
  %l56 = alloca i1
  %l60 = alloca { i64, [1 x i64] }
  %l62 = alloca { i64, ptr }
  %l67 = alloca { i64, [4 x i64] }
  %l75 = alloca i1
  %l77 = alloca ptr
  %l78 = alloca { i64, [4 x i64] }
  %l80 = alloca i32
  %l83 = alloca { i64, [4 x i64] }
  %l84 = alloca ptr
  %l85 = alloca i32
  %l86 = alloca i32
  %l90 = alloca { i64, ptr }
  %l91 = alloca %"compiler/mir:Range"
  %l94 = alloca { i64, [4 x i64] }
  %l102 = alloca { i64, [4 x i64] }
  %l103 = alloca ptr
  %l104 = alloca i32
  %l105 = alloca i32
  %l106 = alloca { i64, [4 x i64] }
  %l108 = alloca { i64, ptr }
  %l111 = alloca { i64, [4 x i64] }
  %l112 = alloca { i64, ptr }
  %l114 = alloca { i64, [4 x i64] }
  %l117 = alloca { i64, ptr }
  %l126 = alloca { i64, [4 x i64] }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { i64, [4 x i64] }
  %t129 = alloca { i64, [4 x i64] }, align 8
  %t177 = alloca { i64, [15 x i64] }, align 8
  %t198 = alloca { i64, [15 x i64] }, align 8
  %t259 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t6, ptr %l20, !tbaa !27
  %t7 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !27
  %t9 = getelementptr ptr, ptr %t8, i64 0
  %t10 = load ptr, ptr %t9, !tbaa !39
  store ptr %t10, ptr %l5, !tbaa !29
  %t12 = load ptr, ptr %l5, !tbaa !29
  store ptr %t12, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t13 = load ptr, ptr %l22, !tbaa !29
  %t14 = icmp ne ptr %t13, null
  br i1 %t14, label %bb1, label %bb2
bb1:
  %t16 = load ptr, ptr %l22, !tbaa !29
  %t17 = load i64, ptr %t16
  %t19 = icmp eq i64 %t17, 5
  store i1 %t19, ptr %l23, !tbaa !21
  br label %bb2
bb2:
  %t20 = load i1, ptr %l23, !tbaa !21
  br i1 %t20, label %bb3, label %bb4
bb3:
  %t21 = load ptr, ptr %l5, !tbaa !29
  %t23 = getelementptr { i64, [5 x i64] }, ptr %t21, i32 0, i32 1
  %t24 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t23, i32 0, i32 1
  %t25 = load i32, ptr %t24
  store i32 %t25, ptr %l6, !tbaa !23
  %t27 = load ptr, ptr %l5, !tbaa !29
  %t29 = getelementptr { i64, [5 x i64] }, ptr %t27, i32 0, i32 1
  %t30 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t29, i32 0, i32 2
  %t31 = load ptr, ptr %t30
  store ptr %t31, ptr %l7, !tbaa !29
  br label %bb5
bb4:
  br label %bb44
bb5:
  %t33 = load ptr, ptr %l7, !tbaa !29
  %t35 = getelementptr %"compiler/typed:Promote", ptr %t33, i32 0, i32 0
  %t36 = load ptr, ptr %t35, !tbaa !29
  store ptr %t36, ptr %l8, !tbaa !29
  %t38 = load ptr, ptr %l8, !tbaa !29
  store ptr %t38, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t39 = load ptr, ptr %l32, !tbaa !29
  %t40 = icmp ne ptr %t39, null
  br i1 %t40, label %bb6, label %bb7
bb6:
  %t42 = load ptr, ptr %l32, !tbaa !29
  %t43 = load i64, ptr %t42
  %t45 = icmp eq i64 %t43, 7
  store i1 %t45, ptr %l33, !tbaa !21
  br label %bb7
bb7:
  %t46 = load i1, ptr %l33, !tbaa !21
  br i1 %t46, label %bb8, label %bb9
bb8:
  %t47 = load ptr, ptr %l8, !tbaa !29
  %t49 = getelementptr { i64, [5 x i64] }, ptr %t47, i32 0, i32 1
  %t50 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t49, i32 0, i32 0
  %t51 = load %"compiler/source:Span", ptr %t50
  store %"compiler/source:Span" %t51, ptr %l9
  %t53 = load ptr, ptr %l8, !tbaa !29
  %t55 = getelementptr { i64, [5 x i64] }, ptr %t53, i32 0, i32 1
  %t56 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t55, i32 0, i32 1
  %t57 = load i32, ptr %t56
  store i32 %t57, ptr %l10, !tbaa !23
  %t59 = load ptr, ptr %l8, !tbaa !29
  %t61 = getelementptr { i64, [5 x i64] }, ptr %t59, i32 0, i32 1
  %t62 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t61, i32 0, i32 2
  %t63 = load ptr, ptr %t62
  store ptr %t63, ptr %l11, !tbaa !29
  br label %bb10
bb9:
  br label %bb38
bb10:
  %t65 = load ptr, ptr %l11, !tbaa !29
  %t67 = getelementptr %"compiler/typed:Make", ptr %t65, i32 0, i32 0
  %t68 = load i32, ptr %t67
  %t70 = trunc i64 0 to i32
  %t71 = icmp eq i32 %t68, %t70
  br i1 %t71, label %bb11, label %bb12
bb11:
  %t73 = load ptr, ptr %l11, !tbaa !29
  %t75 = getelementptr %"compiler/typed:Make", ptr %t73, i32 0, i32 2
  %t76 = load { i64, ptr }, ptr %t75, !tbaa !27
  %t78 = extractvalue { i64, ptr } %t76, 0
  %t80 = icmp eq i64 %t78, 1
  store i1 %t80, ptr %l45, !tbaa !21
  br label %bb13
bb12:
  store i1 false, ptr %l45, !tbaa !21
  br label %bb13
bb13:
  %t82 = load i1, ptr %l45, !tbaa !21
  br i1 %t82, label %bb14, label %bb15
bb14:
  %t83 = load ptr, ptr %l0, !tbaa !29
  store ptr %t83, ptr %l51, !tbaa !29
  %t84 = load ptr, ptr %l11, !tbaa !29
  %t86 = getelementptr %"compiler/typed:Make", ptr %t84, i32 0, i32 2
  %t87 = load { i64, ptr }, ptr %t86, !tbaa !27
  store { i64, ptr } %t87, ptr %l53, !tbaa !27
  %t88 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !27
  %t90 = getelementptr ptr, ptr %t89, i64 0
  %t91 = load ptr, ptr %t90, !tbaa !39
  %t93 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t91)
  store i32 %t93, ptr %l55
  br label %bb16
bb15:
  store i1 false, ptr %l50, !tbaa !21
  br label %bb18
bb16:
  %t94 = load ptr, ptr %l51, !tbaa !29
  %t95 = load i32, ptr %l55, !tbaa !23
  %t96 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2evalueArray(ptr %v0, ptr %t94, i32 %t95)
  store i1 %t96, ptr %l56
  br label %bb17
bb17:
  %t97 = load i1, ptr %l56, !tbaa !21
  store i1 %t97, ptr %l50, !tbaa !21
  br label %bb18
bb18:
  %t98 = load i1, ptr %l50, !tbaa !21
  br i1 %t98, label %bb19, label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s3
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t100 = load ptr, ptr %l7, !tbaa !29
  %t102 = getelementptr %"compiler/typed:Promote", ptr %t100, i32 0, i32 1
  %t103 = load i32, ptr %t102, !tbaa !23
  %t106 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ebuilt(ptr %v0, ptr %t99, i32 %t103)
  store { i64, [1 x i64] } %t106, ptr %l60
  br label %bb21
bb20:
  br label %bb37
bb21:
  %t107 = load { i64, [1 x i64] }, ptr %l60
  store { i64, [1 x i64] } %t107, ptr %l12
  %t108 = load ptr, ptr %l11, !tbaa !29
  %t110 = getelementptr %"compiler/typed:Make", ptr %t108, i32 0, i32 2
  %t111 = load { i64, ptr }, ptr %t110, !tbaa !27
  store { i64, ptr } %t111, ptr %l62, !tbaa !27
  %t112 = getelementptr { i64, ptr }, ptr %l62, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !27
  %t114 = getelementptr ptr, ptr %t113, i64 0
  %t115 = load ptr, ptr %t114, !tbaa !39
  store ptr %t115, ptr %l13, !tbaa !29
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t118 = load ptr, ptr %l13, !tbaa !29
  %t122 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %t117, ptr %t118)
  store { i64, [4 x i64] } %t122, ptr %l67
  br label %bb22
bb22:
  %t123 = load { i64, [4 x i64] }, ptr %l67
  store { i64, [4 x i64] } %t123, ptr %l14
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t126 = getelementptr %"compiler/lower:lowering", ptr %t124, i32 0, i32 7
  %t127 = load i1, ptr %t126, !tbaa !21
  br i1 %t127, label %bb23, label %bb24
bb23:
  store { i64, [4 x i64] } zeroinitializer, ptr %t129
  %t130 = getelementptr { i64, [4 x i64] }, ptr %t129, i32 0, i32 0
  store i64 0, ptr %t130
  %t131 = load { i64, [4 x i64] }, ptr %t129
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t131, ptr %rv
  br label %ret
bb24:
  br label %bb25
bb25:
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t135 = getelementptr %"compiler/lower:lowering", ptr %t133, i32 0, i32 2
  %t136 = load ptr, ptr %t135, !tbaa !29
  %t137 = load ptr, ptr %l13, !tbaa !29
  %t141 = call i1 @compiler_2ftyped_2eAnyItemNew(ptr %v0, ptr %v1, ptr %t136, ptr %t137)
  store i1 %t141, ptr %l75
  br label %bb26
bb26:
  %t142 = load i1, ptr %l75, !tbaa !21
  %t143 = xor i1 %t142, true
  br i1 %t143, label %bb27, label %bb28
bb27:
  %t145 = load ptr, ptr %l0, !tbaa !29
  store ptr %t145, ptr %l77, !tbaa !29
  %t146 = load { i64, [4 x i64] }, ptr %l14
  store { i64, [4 x i64] } %t146, ptr %l78
  %t147 = load ptr, ptr %l13, !tbaa !29
  %t149 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t147)
  store i32 %t149, ptr %l80
  br label %bb29
bb28:
  br label %bb31
bb29:
  %t150 = load %"compiler/source:Span", ptr %l3
  %t151 = load { i64, [1 x i64] }, ptr %l12
  %t152 = load ptr, ptr %l77, !tbaa !29
  %t153 = load { i64, [4 x i64] }, ptr %l78
  %t154 = load i32, ptr %l80, !tbaa !23
  %t157 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2earrayCopy(ptr %v0, ptr %t152, { i64, [4 x i64] } %t153, i32 %t154, %"compiler/source:Span" %t150, { i64, [1 x i64] } %t151)
  store { i64, [4 x i64] } %t157, ptr %l83
  br label %bb30
bb30:
  %t158 = load { i64, [4 x i64] }, ptr %l83
  store { i64, [4 x i64] } %t158, ptr %l14
  br label %bb31
bb31:
  %t159 = load ptr, ptr %l0, !tbaa !29
  store ptr %t159, ptr %l84, !tbaa !29
  %t160 = load i32, ptr %l10, !tbaa !23
  store i32 %t160, ptr %l85, !tbaa !23
  %t161 = load i32, ptr %l10, !tbaa !23
  store i32 %t161, ptr %l86, !tbaa !23
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t164 = getelementptr %"compiler/lower:lowering", ptr %t162, i32 0, i32 3
  %t165 = load { i64, [4 x i64] }, ptr %l14
  %t166 = mul i64 1, 40
  %t167 = call ptr @__olang_scope_alloc_zeroed(ptr %s3, i64 %t166)
  %t168 = insertvalue { i64, ptr } undef, i64 1, 0
  %t169 = insertvalue { i64, ptr } %t168, ptr %t167, 1
  store { i64, ptr } %t169, ptr %l90, !tbaa !27
  %t171 = getelementptr { i64, ptr }, ptr %l90, i32 0, i32 1
  %t172 = load ptr, ptr %t171, !tbaa !27
  %t173 = getelementptr { i64, [4 x i64] }, ptr %t172, i64 0
  store { i64, [4 x i64] } %t165, ptr %t173
  %t175 = load { i64, ptr }, ptr %l90, !tbaa !27
  %t176 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v0, ptr %s3, ptr %t164, { i64, ptr } %t175)
  store %"compiler/mir:Range" %t176, ptr %l91
  br label %bb32
bb32:
  store { i64, [15 x i64] } zeroinitializer, ptr %t177
  %t178 = getelementptr { i64, [15 x i64] }, ptr %t177, i32 0, i32 0
  store i64 6, ptr %t178
  %t179 = load i32, ptr %l86, !tbaa !23
  %t180 = insertvalue { i32, i64, %"compiler/mir:Range" } undef, i32 %t179, 0
  %t181 = insertvalue { i32, i64, %"compiler/mir:Range" } %t180, i64 0, 1
  %t182 = load %"compiler/mir:Range", ptr %l91
  %t183 = insertvalue { i32, i64, %"compiler/mir:Range" } %t181, %"compiler/mir:Range" %t182, 2
  %t184 = getelementptr { i64, [15 x i64] }, ptr %t177, i32 0, i32 1
  store { i32, i64, %"compiler/mir:Range" } %t183, ptr %t184
  %t185 = load { i64, [15 x i64] }, ptr %t177
  %t186 = load %"compiler/source:Span", ptr %l9
  %t187 = load ptr, ptr %l84, !tbaa !29
  %t188 = load i32, ptr %l85, !tbaa !23
  %t191 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t187, i32 %t188, { i64, [15 x i64] } %t185, %"compiler/source:Span" %t186)
  store { i64, [4 x i64] } %t191, ptr %l94
  br label %bb33
bb33:
  %t192 = load { i64, [4 x i64] }, ptr %l94
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t194 = load i32, ptr %l6, !tbaa !23
  %t195 = load { i64, [1 x i64] }, ptr %l12
  %t197 = load i32, ptr %l6, !tbaa !23
  store { i64, [15 x i64] } zeroinitializer, ptr %t198
  %t199 = getelementptr { i64, [15 x i64] }, ptr %t198, i32 0, i32 0
  store i64 7, ptr %t199
  %t201 = insertvalue { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 } undef, { i64, [1 x i64] } %t195, 0
  %t203 = insertvalue { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 } %t201, { i64, [4 x i64] } %t192, 1
  %t205 = insertvalue { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 } %t203, i32 %t197, 2
  %t206 = getelementptr { i64, [15 x i64] }, ptr %t198, i32 0, i32 1
  store { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 } %t205, ptr %t206
  %t207 = load { i64, [15 x i64] }, ptr %t198
  %t208 = load %"compiler/source:Span", ptr %l3
  %t213 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t193, i32 %t194, { i64, [15 x i64] } %t207, %"compiler/source:Span" %t208)
  store { i64, [4 x i64] } %t213, ptr %l102
  br label %bb34
bb34:
  %t214 = load { i64, [4 x i64] }, ptr %l102
  %t215 = load ptr, ptr %l0, !tbaa !29
  store ptr %t215, ptr %l103, !tbaa !29
  store i32 40, ptr %l104
  %t216 = load i32, ptr %l2, !tbaa !23
  store i32 %t216, ptr %l105, !tbaa !23
  store { i64, [4 x i64] } %t214, ptr %l106
  %t218 = load ptr, ptr %l0, !tbaa !29
  %t219 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t219, ptr %l108, !tbaa !27
  %t220 = getelementptr { i64, ptr }, ptr %l108, i32 0, i32 1
  %t221 = load ptr, ptr %t220, !tbaa !27
  %t222 = getelementptr ptr, ptr %t221, i64 1
  %t223 = load ptr, ptr %t222, !tbaa !39
  %t227 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %t218, ptr %t223)
  store { i64, [4 x i64] } %t227, ptr %l111
  br label %bb35
bb35:
  %t228 = mul i64 2, 40
  %t229 = call ptr @__olang_scope_alloc_zeroed(ptr %s3, i64 %t228)
  %t230 = insertvalue { i64, ptr } undef, i64 2, 0
  %t231 = insertvalue { i64, ptr } %t230, ptr %t229, 1
  store { i64, ptr } %t231, ptr %l112, !tbaa !27
  %t232 = load { i64, [4 x i64] }, ptr %l106
  %t233 = getelementptr { i64, ptr }, ptr %l112, i32 0, i32 1
  %t234 = load ptr, ptr %t233, !tbaa !27
  %t235 = getelementptr { i64, [4 x i64] }, ptr %t234, i64 0
  store { i64, [4 x i64] } %t232, ptr %t235
  %t236 = load { i64, [4 x i64] }, ptr %l111
  %t237 = getelementptr { i64, ptr }, ptr %l112, i32 0, i32 1
  %t238 = load ptr, ptr %t237, !tbaa !27
  %t239 = getelementptr { i64, [4 x i64] }, ptr %t238, i64 1
  store { i64, [4 x i64] } %t236, ptr %t239
  %t240 = load %"compiler/source:Span", ptr %l3
  %t241 = load ptr, ptr %l103, !tbaa !29
  %t242 = load i32, ptr %l104
  %t243 = load i32, ptr %l105, !tbaa !23
  %t244 = load { i64, ptr }, ptr %l112, !tbaa !27
  %t246 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s3, ptr %t241, i32 %t242, i32 %t243, { i64, ptr } %t244, %"compiler/source:Span" %t240)
  store { i64, [4 x i64] } %t246, ptr %l114
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t247 = load { i64, [4 x i64] }, ptr %l114
  store { i64, [4 x i64] } %t247, ptr %rv
  br label %ret
bb37:
  br label %bb43
bb38:
  br i1 true, label %bb39, label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb42
bb41:
  br label %bb43
bb42:
  call void @__olang_check_failed(ptr @olang_loc_95894c0b36292ffb_c517f6bdfd218a6f)
  unreachable
bb43:
  br label %bb49
bb44:
  br i1 true, label %bb45, label %bb46
bb45:
  br label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb49
bb48:
  call void @__olang_check_failed(ptr @olang_loc_e6eae32e21930b7a_6f5872ba2e210dae)
  unreachable
bb49:
  %t248 = load ptr, ptr %l0, !tbaa !29
  %t249 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t252 = call { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2evals(ptr %v0, ptr %v1, ptr %s0, ptr %t248, { i64, ptr } %t249)
  store { i64, ptr } %t252, ptr %l117
  br label %bb50
bb50:
  %t253 = load { i64, ptr }, ptr %l117, !tbaa !27
  store { i64, ptr } %t253, ptr %l17, !tbaa !27
  %t254 = load ptr, ptr %l0, !tbaa !29
  %t256 = getelementptr %"compiler/lower:lowering", ptr %t254, i32 0, i32 7
  %t257 = load i1, ptr %t256, !tbaa !21
  br i1 %t257, label %bb51, label %bb52
bb51:
  store { i64, [4 x i64] } zeroinitializer, ptr %t259
  %t260 = getelementptr { i64, [4 x i64] }, ptr %t259, i32 0, i32 0
  store i64 0, ptr %t260
  %t261 = load { i64, [4 x i64] }, ptr %t259
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t261, ptr %rv
  br label %ret
bb52:
  br label %bb53
bb53:
  %t263 = load ptr, ptr %l0, !tbaa !29
  %t264 = load i32, ptr %l2, !tbaa !23
  %t265 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t266 = load %"compiler/source:Span", ptr %l3
  %t272 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s0, ptr %t263, i32 40, i32 %t264, { i64, ptr } %t265, %"compiler/source:Span" %t266)
  store { i64, [4 x i64] } %t272, ptr %l126
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s0)
  %t273 = load { i64, [4 x i64] }, ptr %l126
  store { i64, [4 x i64] } %t273, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local %"compiler/mir:Range" @compiler_2flower_2ecompiler_2flower_3alowering_2eargs(ptr %v0, ptr %v1, ptr %a0, ptr %a1, { i64, [7 x i64] } %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, [7 x i64] }
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i1
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca { i64, [4 x i64] }
  %l16 = alloca i1
  %l20 = alloca ptr
  %l23 = alloca i32
  %l24 = alloca { i64, ptr }
  %l25 = alloca i1
  %l28 = alloca i1
  %l33 = alloca i64
  %l43 = alloca i64
  %l46 = alloca i64
  %l65 = alloca { i64, ptr }
  %l71 = alloca { i64, [4 x i64] }
  %l76 = alloca ptr
  %l77 = alloca { i64, [4 x i64] }
  %l79 = alloca ptr
  %l80 = alloca { i64, ptr }
  %l82 = alloca i32
  %l84 = alloca %"compiler/source:Span"
  %l85 = alloca { i64, [4 x i64] }
  %l90 = alloca i1
  %l92 = alloca { i64, ptr }
  %l95 = alloca i1
  %l96 = alloca i1
  %l97 = alloca ptr
  %l99 = alloca i32
  %l100 = alloca i1
  %l101 = alloca i1
  %l102 = alloca ptr
  %l103 = alloca ptr
  %l104 = alloca ptr
  %l106 = alloca i32
  %l107 = alloca i32
  %l108 = alloca i32
  %l109 = alloca ptr
  %l111 = alloca { i64, ptr }
  %l114 = alloca i32
  %l115 = alloca i32
  %l116 = alloca i1
  %l118 = alloca i1
  %l123 = alloca i1
  %l125 = alloca { i64, ptr }
  %l128 = alloca i1
  %l129 = alloca i1
  %l132 = alloca ptr
  %l133 = alloca { i64, [4 x i64] }
  %l135 = alloca i32
  %l137 = alloca %"compiler/source:Span"
  %l138 = alloca i32
  %l139 = alloca ptr
  %l140 = alloca { i64, ptr }
  %l142 = alloca i32
  %l144 = alloca %"compiler/mir:Place"
  %l145 = alloca { i64, ptr }
  %l148 = alloca { i64, [15 x i64] }
  %l150 = alloca %"compiler/source:Span"
  %l151 = alloca { i64, [4 x i64] }
  %l159 = alloca %"compiler/mir:Range"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/mir:Range"
  %t272 = alloca { i64, [15 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, [7 x i64] } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = load ptr, ptr %l4, !tbaa !29
  store ptr %t6, ptr %l20, !tbaa !29
  %t7 = load ptr, ptr %l4, !tbaa !29
  %t11 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t7, i32 %a3)
  store i32 %t11, ptr %l23
  br label %bb1
bb1:
  %t12 = load ptr, ptr %l20, !tbaa !29
  %t13 = load i32, ptr %l23, !tbaa !23
  %t14 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t12, i32 %t13)
  store { i64, ptr } %t14, ptr %l24
  br label %bb2
bb2:
  %t15 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t15, ptr %l5, !tbaa !27
  %t16 = load { i64, [7 x i64] }, ptr %l2
  %t18 = extractvalue { i64, [7 x i64] } %t16, 0
  %t19 = icmp eq i64 %t18, 0
  br i1 %t19, label %bb3, label %bb4
bb3:
  %t21 = getelementptr { i64, [7 x i64] }, ptr %l2, i32 0, i32 1
  %t22 = getelementptr { { i64, [2 x i64] }, i32 }, ptr %t21, i32 0, i32 0
  %t23 = load { i64, [2 x i64] }, ptr %t22
  %t25 = extractvalue { i64, [2 x i64] } %t23, 0
  %t26 = icmp eq i64 %t25, 2
  store i1 %t26, ptr %l28, !tbaa !21
  br label %bb5
bb4:
  store i1 false, ptr %l28, !tbaa !21
  br label %bb5
bb5:
  %t28 = load i1, ptr %l28, !tbaa !21
  br i1 %t28, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb9
bb8:
  store i1 true, ptr %l25, !tbaa !21
  br label %bb14
bb9:
  br i1 true, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  store i1 false, ptr %l25, !tbaa !21
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_e4b18f7db400c6ba_98b68b17576d276)
  unreachable
bb14:
  %t29 = load i1, ptr %l25, !tbaa !21
  store i1 %t29, ptr %l6, !tbaa !21
  %t30 = load ptr, ptr %l1, !tbaa !29
  %t32 = getelementptr %"compiler/typed:Call", ptr %t30, i32 0, i32 1
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t33, 0
  store i64 %t35, ptr %l33, !tbaa !24
  %t36 = load i64, ptr %l33, !tbaa !24
  %t37 = icmp sge i64 %t36, 0
  br i1 %t37, label %bb15, label %bb16
bb15:
  %t39 = load i64, ptr %l33, !tbaa !24
  %t40 = icmp sle i64 %t39, 230584300921369395
  br i1 %t40, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_1f81b40d868fb2d4_a735c8b3105ef948)
  unreachable
bb17:
  %t42 = load i64, ptr %l33, !tbaa !24
  %t43 = mul i64 %t42, 40
  %t44 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t43)
  %t45 = insertvalue { i64, ptr } undef, i64 %t42, 0
  %t46 = insertvalue { i64, ptr } %t45, ptr %t44, 1
  store { i64, ptr } %t46, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t48 = load ptr, ptr %l1, !tbaa !29
  %t50 = getelementptr %"compiler/typed:Call", ptr %t48, i32 0, i32 1
  %t51 = load { i64, ptr }, ptr %t50, !tbaa !27
  %t53 = extractvalue { i64, ptr } %t51, 0
  store i64 %t53, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t55 = load i64, ptr %l9, !tbaa !24
  %t56 = load i64, ptr %l8, !tbaa !24
  %t59 = icmp sgt i64 %t55, %t56
  br i1 %t59, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_1f81b40d868fb2d4_a735c8b3105ef948)
  unreachable
bb19:
  %t61 = load i64, ptr %l10, !tbaa !24
  %t63 = icmp sgt i64 %t61, 0
  br i1 %t63, label %bb21, label %bb22
bb20:
  store i64 0, ptr %l43, !tbaa !24
  br label %bb24
bb21:
  %t65 = load i64, ptr %l9, !tbaa !24
  %t66 = load i64, ptr %l8, !tbaa !24
  %t69 = sub i64 %t65, %t66
  %t70 = load i64, ptr %l10, !tbaa !24
  %t73 = add i64 %t69, %t70
  %t75 = sub i64 %t73, 1
  %t76 = load i64, ptr %l10, !tbaa !24
  %t79 = sdiv i64 %t75, %t76
  store i64 %t79, ptr %l46, !tbaa !24
  br label %bb23
bb22:
  store i64 0, ptr %l46, !tbaa !24
  br label %bb23
bb23:
  %t81 = load i64, ptr %l46, !tbaa !24
  store i64 %t81, ptr %l43, !tbaa !24
  br label %bb24
bb24:
  %t82 = load i64, ptr %l43, !tbaa !24
  store i64 %t82, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb25
bb25:
  %t83 = load i64, ptr %l12, !tbaa !24
  %t84 = load i64, ptr %l11, !tbaa !24
  %t87 = icmp slt i64 %t83, %t84
  %t89 = xor i1 %t87, true
  br i1 %t89, label %bb26, label %bb27
bb26:
  br label %bb73
bb27:
  br label %bb28
bb28:
  %t91 = load i64, ptr %l8, !tbaa !24
  %t92 = load i64, ptr %l12, !tbaa !24
  %t93 = load i64, ptr %l10, !tbaa !24
  %t96 = mul i64 %t92, %t93
  %t99 = add i64 %t91, %t96
  store i64 %t99, ptr %l13, !tbaa !24
  %t101 = load ptr, ptr %l1, !tbaa !29
  %t103 = getelementptr %"compiler/typed:Call", ptr %t101, i32 0, i32 1
  %t104 = load { i64, ptr }, ptr %t103, !tbaa !27
  store { i64, ptr } %t104, ptr %l65, !tbaa !27
  %t105 = load i64, ptr %l13, !tbaa !24
  %t107 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t108 = load ptr, ptr %t107, !tbaa !27
  %t109 = getelementptr ptr, ptr %t108, i64 %t105
  %t110 = load ptr, ptr %t109, !tbaa !39
  store ptr %t110, ptr %l14, !tbaa !29
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t113 = load ptr, ptr %l14, !tbaa !29
  %t117 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %t112, ptr %t113)
  store { i64, [4 x i64] } %t117, ptr %l71
  br label %bb29
bb29:
  %t118 = load { i64, [4 x i64] }, ptr %l71
  store { i64, [4 x i64] } %t118, ptr %l15
  %t119 = load i64, ptr %l13, !tbaa !24
  %t120 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t122 = extractvalue { i64, ptr } %t120, 0
  %t125 = icmp slt i64 %t119, %t122
  br i1 %t125, label %bb30, label %bb31
bb30:
  %t127 = load ptr, ptr %l0, !tbaa !29
  store ptr %t127, ptr %l76, !tbaa !29
  %t128 = load { i64, [4 x i64] }, ptr %l15
  store { i64, [4 x i64] } %t128, ptr %l77
  %t129 = load ptr, ptr %l14, !tbaa !29
  store ptr %t129, ptr %l79, !tbaa !29
  %t131 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t131, ptr %l80, !tbaa !27
  %t132 = load i64, ptr %l13, !tbaa !24
  %t134 = getelementptr { i64, ptr }, ptr %l80, i32 0, i32 1
  %t135 = load ptr, ptr %t134, !tbaa !27
  %t136 = getelementptr i32, ptr %t135, i64 %t132
  %t137 = load i32, ptr %t136, !tbaa !33
  store i32 %t137, ptr %l82, !tbaa !23
  %t138 = load ptr, ptr %l14, !tbaa !29
  %t140 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t138)
  store %"compiler/source:Span" %t140, ptr %l84
  br label %bb32
bb31:
  br label %bb34
bb32:
  %t141 = load ptr, ptr %l76, !tbaa !29
  %t142 = load { i64, [4 x i64] }, ptr %l77
  %t143 = load ptr, ptr %l79, !tbaa !29
  %t144 = load i32, ptr %l82, !tbaa !23
  %t145 = load %"compiler/source:Span", ptr %l84
  %t146 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2efit(ptr %v0, ptr %v1, ptr %t141, { i64, [4 x i64] } %t142, ptr %t143, i32 %t144, %"compiler/source:Span" %t145)
  store { i64, [4 x i64] } %t146, ptr %l85
  br label %bb33
bb33:
  %t147 = load { i64, [4 x i64] }, ptr %l85
  store { i64, [4 x i64] } %t147, ptr %l15
  br label %bb34
bb34:
  %t148 = load i64, ptr %l13, !tbaa !24
  %t149 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t151 = extractvalue { i64, ptr } %t149, 0
  %t154 = icmp slt i64 %t148, %t151
  br i1 %t154, label %bb35, label %bb36
bb35:
  %t156 = load ptr, ptr %l4, !tbaa !29
  %t157 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t157, ptr %l92, !tbaa !27
  %t158 = load i64, ptr %l13, !tbaa !24
  %t160 = getelementptr { i64, ptr }, ptr %l92, i32 0, i32 1
  %t161 = load ptr, ptr %t160, !tbaa !27
  %t162 = getelementptr i32, ptr %t161, i64 %t158
  %t163 = load i32, ptr %t162, !tbaa !33
  %t166 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t156, i32 %t163)
  store i1 %t166, ptr %l95
  br label %bb37
bb36:
  store i1 false, ptr %l90, !tbaa !21
  br label %bb38
bb37:
  %t167 = load i1, ptr %l95, !tbaa !21
  store i1 %t167, ptr %l90, !tbaa !21
  br label %bb38
bb38:
  %t168 = load i1, ptr %l90, !tbaa !21
  br i1 %t168, label %bb39, label %bb40
bb39:
  %t169 = load ptr, ptr %l4, !tbaa !29
  store ptr %t169, ptr %l97, !tbaa !29
  %t170 = load ptr, ptr %l14, !tbaa !29
  %t172 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t170)
  store i32 %t172, ptr %l99
  br label %bb41
bb40:
  store i1 true, ptr %l96, !tbaa !21
  br label %bb52
bb41:
  %t173 = load ptr, ptr %l97, !tbaa !29
  %t174 = load i32, ptr %l99, !tbaa !23
  %t175 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t173, i32 %t174)
  store i1 %t175, ptr %l100
  br label %bb42
bb42:
  %t176 = load i1, ptr %l100, !tbaa !21
  br i1 %t176, label %bb43, label %bb44
bb43:
  %t177 = load ptr, ptr %l4, !tbaa !29
  store ptr %t177, ptr %l102, !tbaa !29
  %t178 = load ptr, ptr %l4, !tbaa !29
  store ptr %t178, ptr %l103, !tbaa !29
  %t179 = load ptr, ptr %l4, !tbaa !29
  store ptr %t179, ptr %l104, !tbaa !29
  %t180 = load ptr, ptr %l14, !tbaa !29
  %t182 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t180)
  store i32 %t182, ptr %l106
  br label %bb45
bb44:
  store i1 false, ptr %l101, !tbaa !21
  br label %bb51
bb45:
  %t183 = load ptr, ptr %l104, !tbaa !29
  %t184 = load i32, ptr %l106, !tbaa !23
  %t185 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t183, i32 %t184)
  store i32 %t185, ptr %l107
  br label %bb46
bb46:
  %t186 = load ptr, ptr %l103, !tbaa !29
  %t187 = load i32, ptr %l107, !tbaa !23
  %t188 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t186, i32 %t187)
  store i32 %t188, ptr %l108
  br label %bb47
bb47:
  %t189 = load ptr, ptr %l4, !tbaa !29
  store ptr %t189, ptr %l109, !tbaa !29
  %t190 = load ptr, ptr %l4, !tbaa !29
  %t191 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t191, ptr %l111, !tbaa !27
  %t192 = load i64, ptr %l13, !tbaa !24
  %t194 = getelementptr { i64, ptr }, ptr %l111, i32 0, i32 1
  %t195 = load ptr, ptr %t194, !tbaa !27
  %t196 = getelementptr i32, ptr %t195, i64 %t192
  %t197 = load i32, ptr %t196, !tbaa !33
  %t200 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t190, i32 %t197)
  store i32 %t200, ptr %l114
  br label %bb48
bb48:
  %t201 = load ptr, ptr %l109, !tbaa !29
  %t202 = load i32, ptr %l114, !tbaa !23
  %t203 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t201, i32 %t202)
  store i32 %t203, ptr %l115
  br label %bb49
bb49:
  %t204 = load ptr, ptr %l102, !tbaa !29
  %t205 = load i32, ptr %l108, !tbaa !23
  %t206 = load i32, ptr %l115, !tbaa !23
  %t207 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t204, i32 %t205, i32 %t206)
  store i1 %t207, ptr %l116
  br label %bb50
bb50:
  %t208 = load i1, ptr %l116, !tbaa !21
  store i1 %t208, ptr %l101, !tbaa !21
  br label %bb51
bb51:
  %t209 = load i1, ptr %l101, !tbaa !21
  store i1 %t209, ptr %l96, !tbaa !21
  br label %bb52
bb52:
  %t210 = load i1, ptr %l96, !tbaa !21
  store i1 %t210, ptr %l16, !tbaa !21
  %t211 = load i1, ptr %l6, !tbaa !21
  br i1 %t211, label %bb53, label %bb54
bb53:
  %t213 = load i64, ptr %l13, !tbaa !24
  %t214 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t216 = extractvalue { i64, ptr } %t214, 0
  %t219 = icmp slt i64 %t213, %t216
  store i1 %t219, ptr %l118, !tbaa !21
  br label %bb55
bb54:
  store i1 false, ptr %l118, !tbaa !21
  br label %bb55
bb55:
  %t221 = load i1, ptr %l118, !tbaa !21
  br i1 %t221, label %bb56, label %bb57
bb56:
  %t222 = load ptr, ptr %l4, !tbaa !29
  %t223 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t223, ptr %l125, !tbaa !27
  %t224 = load i64, ptr %l13, !tbaa !24
  %t226 = getelementptr { i64, ptr }, ptr %l125, i32 0, i32 1
  %t227 = load ptr, ptr %t226, !tbaa !27
  %t228 = getelementptr i32, ptr %t227, i64 %t224
  %t229 = load i32, ptr %t228, !tbaa !33
  %t232 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t222, i32 %t229)
  store i1 %t232, ptr %l128
  br label %bb58
bb57:
  store i1 false, ptr %l123, !tbaa !21
  br label %bb59
bb58:
  %t233 = load i1, ptr %l128, !tbaa !21
  store i1 %t233, ptr %l123, !tbaa !21
  br label %bb59
bb59:
  %t234 = load i1, ptr %l123, !tbaa !21
  br i1 %t234, label %bb60, label %bb61
bb60:
  %t235 = load i1, ptr %l16, !tbaa !21
  %t237 = xor i1 %t235, true
  store i1 %t237, ptr %l129, !tbaa !21
  br label %bb62
bb61:
  store i1 false, ptr %l129, !tbaa !21
  br label %bb62
bb62:
  %t239 = load i1, ptr %l129, !tbaa !21
  br i1 %t239, label %bb63, label %bb64
bb63:
  %t240 = load ptr, ptr %l0, !tbaa !29
  store ptr %t240, ptr %l132, !tbaa !29
  %t241 = load { i64, [4 x i64] }, ptr %l15
  store { i64, [4 x i64] } %t241, ptr %l133
  %t242 = load ptr, ptr %l14, !tbaa !29
  %t244 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t242)
  store i32 %t244, ptr %l135
  br label %bb65
bb64:
  br label %bb71
bb65:
  %t245 = load ptr, ptr %l14, !tbaa !29
  %t247 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t245)
  store %"compiler/source:Span" %t247, ptr %l137
  br label %bb66
bb66:
  %t248 = load ptr, ptr %l132, !tbaa !29
  %t249 = load { i64, [4 x i64] }, ptr %l133
  %t250 = load i32, ptr %l135, !tbaa !23
  %t251 = load %"compiler/source:Span", ptr %l137
  %t252 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2elocal(ptr %v0, ptr %t248, { i64, [4 x i64] } %t249, i32 %t250, %"compiler/source:Span" %t251)
  store i32 %t252, ptr %l138
  br label %bb67
bb67:
  %t253 = load i32, ptr %l138, !tbaa !23
  %t254 = load ptr, ptr %l0, !tbaa !29
  store ptr %t254, ptr %l139, !tbaa !29
  %t255 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t255, ptr %l140, !tbaa !27
  %t256 = load i64, ptr %l13, !tbaa !24
  %t258 = getelementptr { i64, ptr }, ptr %l140, i32 0, i32 1
  %t259 = load ptr, ptr %t258, !tbaa !27
  %t260 = getelementptr i32, ptr %t259, i64 %t256
  %t261 = load i32, ptr %t260, !tbaa !33
  store i32 %t261, ptr %l142, !tbaa !23
  %t264 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t253)
  store %"compiler/mir:Place" %t264, ptr %l144
  br label %bb68
bb68:
  %t265 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t265, ptr %l145, !tbaa !27
  %t266 = load i64, ptr %l13, !tbaa !24
  %t268 = getelementptr { i64, ptr }, ptr %l145, i32 0, i32 1
  %t269 = load ptr, ptr %t268, !tbaa !27
  %t270 = getelementptr i32, ptr %t269, i64 %t266
  %t271 = load i32, ptr %t270, !tbaa !33
  store { i64, [15 x i64] } zeroinitializer, ptr %t272
  %t273 = getelementptr { i64, [15 x i64] }, ptr %t272, i32 0, i32 0
  store i64 1, ptr %t273
  %t274 = load %"compiler/mir:Place", ptr %l144
  %t275 = insertvalue { %"compiler/mir:Place", i32 } undef, %"compiler/mir:Place" %t274, 0
  %t277 = insertvalue { %"compiler/mir:Place", i32 } %t275, i32 %t271, 1
  %t278 = getelementptr { i64, [15 x i64] }, ptr %t272, i32 0, i32 1
  store { %"compiler/mir:Place", i32 } %t277, ptr %t278
  %t279 = load { i64, [15 x i64] }, ptr %t272
  store { i64, [15 x i64] } %t279, ptr %l148
  %t280 = load ptr, ptr %l14, !tbaa !29
  %t282 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t280)
  store %"compiler/source:Span" %t282, ptr %l150
  br label %bb69
bb69:
  %t283 = load ptr, ptr %l139, !tbaa !29
  %t284 = load i32, ptr %l142, !tbaa !23
  %t285 = load { i64, [15 x i64] }, ptr %l148
  %t286 = load %"compiler/source:Span", ptr %l150
  %t287 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t283, i32 %t284, { i64, [15 x i64] } %t285, %"compiler/source:Span" %t286)
  store { i64, [4 x i64] } %t287, ptr %l151
  br label %bb70
bb70:
  %t288 = load { i64, [4 x i64] }, ptr %l151
  store { i64, [4 x i64] } %t288, ptr %l15
  br label %bb71
bb71:
  %t289 = load i64, ptr %l13, !tbaa !24
  %t290 = load { i64, [4 x i64] }, ptr %l15
  %t293 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t294 = load ptr, ptr %t293, !tbaa !27
  %t295 = getelementptr { i64, [4 x i64] }, ptr %t294, i64 %t289
  store { i64, [4 x i64] } %t290, ptr %t295
  br label %bb72
bb72:
  %t296 = load i64, ptr %l12, !tbaa !24
  %t298 = add i64 %t296, 1
  store i64 %t298, ptr %l12, !tbaa !24
  br label %bb25
bb73:
  %t300 = load ptr, ptr %l0, !tbaa !29
  %t302 = getelementptr %"compiler/lower:lowering", ptr %t300, i32 0, i32 3
  %t303 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t306 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v0, ptr %s0, ptr %t302, { i64, ptr } %t303)
  store %"compiler/mir:Range" %t306, ptr %l159
  br label %bb74
bb74:
  call void @__olang_scope_close(ptr %s0)
  %t307 = load %"compiler/mir:Range", ptr %l159
  store %"compiler/mir:Range" %t307, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/mir:Range", ptr %rv
  ret %"compiler/mir:Range" %rr
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2earrayCopy(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1, i32 %a2, %"compiler/source:Span" %a3, { i64, [1 x i64] } %a4) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca { i64, [4 x i64] }
  %l8 = alloca i32
  %l9 = alloca i32
  %l16 = alloca i32
  %l17 = alloca ptr
  %l18 = alloca i32
  %l19 = alloca i32
  %l21 = alloca %"compiler/mir:Place"
  %l23 = alloca { i64, ptr }
  %l25 = alloca { i64, [4 x i64] }
  %l29 = alloca i32
  %l30 = alloca ptr
  %l33 = alloca i32
  %l34 = alloca i32
  %l35 = alloca ptr
  %l36 = alloca %"compiler/source:Span"
  %l38 = alloca %"compiler/mir:Place"
  %l47 = alloca ptr
  %l48 = alloca %"compiler/source:Span"
  %l50 = alloca %"compiler/mir:Place"
  %l52 = alloca %"compiler/mir:Place"
  %l57 = alloca %"compiler/mir:Place"
  %s0 = alloca %olang.scope
  %rv = alloca { i64, [4 x i64] }
  %t21 = alloca { i64, [4 x i64] }, align 8
  %t70 = alloca { i64, [4 x i64] }, align 8
  %t77 = alloca { i64, [15 x i64] }, align 8
  %t89 = alloca { i64, [21 x i64] }, align 8
  %t112 = alloca { i64, [21 x i64] }, align 8
  %t131 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l5, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l2, !tbaa !23
  %t9 = load %"compiler/source:Span", ptr %l3
  %t14 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2elocal(ptr %v0, ptr %t6, { i64, [4 x i64] } %a1, i32 %t8, %"compiler/source:Span" %t9)
  store i32 %t14, ptr %l16
  br label %bb1
bb1:
  %t15 = load i32, ptr %l16, !tbaa !23
  store i32 %t15, ptr %l6, !tbaa !23
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l17, !tbaa !29
  store i32 22, ptr %l18
  %t17 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  store i32 %t17, ptr %l19, !tbaa !23
  %t18 = load i32, ptr %l6, !tbaa !23
  %t20 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t18)
  store %"compiler/mir:Place" %t20, ptr %l21
  br label %bb2
bb2:
  store { i64, [4 x i64] } zeroinitializer, ptr %t21
  %t22 = getelementptr { i64, [4 x i64] }, ptr %t21, i32 0, i32 0
  store i64 1, ptr %t22
  %t23 = load %"compiler/mir:Place", ptr %l21
  %t24 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t23, 0
  %t25 = getelementptr { i64, [4 x i64] }, ptr %t21, i32 0, i32 1
  store { %"compiler/mir:Place" } %t24, ptr %t25
  %t26 = load { i64, [4 x i64] }, ptr %t21
  %t27 = mul i64 1, 40
  %t28 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t27)
  %t29 = insertvalue { i64, ptr } undef, i64 1, 0
  %t30 = insertvalue { i64, ptr } %t29, ptr %t28, 1
  store { i64, ptr } %t30, ptr %l23, !tbaa !27
  %t32 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !27
  %t34 = getelementptr { i64, [4 x i64] }, ptr %t33, i64 0
  store { i64, [4 x i64] } %t26, ptr %t34
  %t35 = load %"compiler/source:Span", ptr %l3
  %t36 = load ptr, ptr %l17, !tbaa !29
  %t37 = load i32, ptr %l18
  %t38 = load i32, ptr %l19, !tbaa !23
  %t39 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t41 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s0, ptr %t36, i32 %t37, i32 %t38, { i64, ptr } %t39, %"compiler/source:Span" %t35)
  store { i64, [4 x i64] } %t41, ptr %l25
  br label %bb3
bb3:
  %t42 = load { i64, [4 x i64] }, ptr %l25
  store { i64, [4 x i64] } %t42, ptr %l7
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = load i32, ptr %l2, !tbaa !23
  %t45 = load %"compiler/source:Span", ptr %l3
  %t49 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etemp(ptr %v0, ptr %t43, i32 %t44, %"compiler/source:Span" %t45)
  store i32 %t49, ptr %l29
  br label %bb4
bb4:
  %t50 = load i32, ptr %l29, !tbaa !23
  store i32 %t50, ptr %l8, !tbaa !23
  %t51 = load ptr, ptr %l5, !tbaa !29
  store ptr %t51, ptr %l30, !tbaa !29
  %t52 = load ptr, ptr %l5, !tbaa !29
  %t53 = load i32, ptr %l2, !tbaa !23
  %t56 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t52, i32 %t53)
  store i32 %t56, ptr %l33
  br label %bb5
bb5:
  %t57 = load ptr, ptr %l30, !tbaa !29
  %t58 = load i32, ptr %l33, !tbaa !23
  %t59 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t57, i32 %t58)
  store i32 %t59, ptr %l34
  br label %bb6
bb6:
  %t60 = load i32, ptr %l34, !tbaa !23
  store i32 %t60, ptr %l9, !tbaa !23
  %t61 = load ptr, ptr %l0, !tbaa !29
  store ptr %t61, ptr %l35, !tbaa !29
  %t62 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t62, ptr %l36
  %t63 = load i32, ptr %l8, !tbaa !23
  %t65 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t63)
  store %"compiler/mir:Place" %t65, ptr %l38
  br label %bb7
bb7:
  %t67 = load i32, ptr %l2, !tbaa !23
  %t68 = load { i64, [4 x i64] }, ptr %l7
  %t69 = load i32, ptr %l9, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t70
  %t71 = getelementptr { i64, [4 x i64] }, ptr %t70, i32 0, i32 0
  store i64 2, ptr %t71
  %t73 = insertvalue { i32, i64 } undef, i32 %t69, 0
  %t74 = insertvalue { i32, i64 } %t73, i64 0, 1
  %t75 = getelementptr { i64, [4 x i64] }, ptr %t70, i32 0, i32 1
  store { i32, i64 } %t74, ptr %t75
  %t76 = load { i64, [4 x i64] }, ptr %t70
  store { i64, [15 x i64] } zeroinitializer, ptr %t77
  %t78 = getelementptr { i64, [15 x i64] }, ptr %t77, i32 0, i32 0
  store i64 8, ptr %t78
  %t80 = insertvalue { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } undef, { i64, [1 x i64] } %a4, 0
  %t82 = insertvalue { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } %t80, i32 %t67, 1
  %t84 = insertvalue { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } %t82, { i64, [4 x i64] } %t68, 2
  %t86 = insertvalue { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } %t84, { i64, [4 x i64] } %t76, 3
  %t87 = getelementptr { i64, [15 x i64] }, ptr %t77, i32 0, i32 1
  store { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } %t86, ptr %t87
  %t88 = load { i64, [15 x i64] }, ptr %t77
  store { i64, [21 x i64] } zeroinitializer, ptr %t89
  %t90 = getelementptr { i64, [21 x i64] }, ptr %t89, i32 0, i32 0
  store i64 0, ptr %t90
  %t91 = load %"compiler/source:Span", ptr %l36
  %t92 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t91, 0
  %t93 = load %"compiler/mir:Place", ptr %l38
  %t94 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t92, %"compiler/mir:Place" %t93, 1
  %t96 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t94, { i64, [15 x i64] } %t88, 2
  %t97 = getelementptr { i64, [21 x i64] }, ptr %t89, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t96, ptr %t97
  %t98 = load { i64, [21 x i64] }, ptr %t89
  %t100 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t98, ptr %t100
  %t101 = load ptr, ptr %l35, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %t101, ptr %t100)
  br label %bb8
bb8:
  %t103 = load ptr, ptr %l0, !tbaa !29
  store ptr %t103, ptr %l47, !tbaa !29
  %t104 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t104, ptr %l48
  %t105 = load i32, ptr %l8, !tbaa !23
  %t107 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t105)
  store %"compiler/mir:Place" %t107, ptr %l50
  br label %bb9
bb9:
  %t108 = load i32, ptr %l6, !tbaa !23
  %t110 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t108)
  store %"compiler/mir:Place" %t110, ptr %l52
  br label %bb10
bb10:
  %t111 = load { i64, [4 x i64] }, ptr %l7
  store { i64, [21 x i64] } zeroinitializer, ptr %t112
  %t113 = getelementptr { i64, [21 x i64] }, ptr %t112, i32 0, i32 0
  store i64 10, ptr %t113
  %t114 = load %"compiler/source:Span", ptr %l48
  %t115 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", %"compiler/mir:Place", { i64, [4 x i64] } } undef, %"compiler/source:Span" %t114, 0
  %t116 = load %"compiler/mir:Place", ptr %l50
  %t117 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", %"compiler/mir:Place", { i64, [4 x i64] } } %t115, %"compiler/mir:Place" %t116, 1
  %t118 = load %"compiler/mir:Place", ptr %l52
  %t119 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", %"compiler/mir:Place", { i64, [4 x i64] } } %t117, %"compiler/mir:Place" %t118, 2
  %t121 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", %"compiler/mir:Place", { i64, [4 x i64] } } %t119, { i64, [4 x i64] } %t111, 3
  %t122 = getelementptr { i64, [21 x i64] }, ptr %t112, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Place", %"compiler/mir:Place", { i64, [4 x i64] } } %t121, ptr %t122
  %t123 = load { i64, [21 x i64] }, ptr %t112
  %t125 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t123, ptr %t125
  %t126 = load ptr, ptr %l47, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %t126, ptr %t125)
  br label %bb11
bb11:
  %t128 = load i32, ptr %l8, !tbaa !23
  %t130 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t128)
  store %"compiler/mir:Place" %t130, ptr %l57
  br label %bb12
bb12:
  store { i64, [4 x i64] } zeroinitializer, ptr %t131
  %t132 = getelementptr { i64, [4 x i64] }, ptr %t131, i32 0, i32 0
  store i64 1, ptr %t132
  %t133 = load %"compiler/mir:Place", ptr %l57
  %t134 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t133, 0
  %t135 = getelementptr { i64, [4 x i64] }, ptr %t131, i32 0, i32 1
  store { %"compiler/mir:Place" } %t134, ptr %t135
  %t136 = load { i64, [4 x i64] }, ptr %t131
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t136, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2earrayLit(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3, i1 %a4, { i64, [1 x i64] } %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l6 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, [4 x i64] }
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i1
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l24 = alloca i32
  %l34 = alloca { i64, ptr }
  %l40 = alloca i64
  %l42 = alloca ptr
  %l43 = alloca i32
  %l44 = alloca i32
  %l48 = alloca %"compiler/mir:Range"
  %l51 = alloca { i64, [4 x i64] }
  %l52 = alloca ptr
  %l55 = alloca i32
  %l56 = alloca i1
  %l59 = alloca ptr
  %l60 = alloca i32
  %l64 = alloca { i64, [1 x i64] }
  %l69 = alloca { i64, [4 x i64] }
  %l72 = alloca i32
  %l76 = alloca i32
  %l77 = alloca ptr
  %l78 = alloca %"compiler/source:Span"
  %l80 = alloca %"compiler/mir:Place"
  %l82 = alloca { i64, [1 x i64] }
  %l87 = alloca { i64, [1 x i64] }
  %l88 = alloca i32
  %l92 = alloca { i64, [4 x i64] }
  %l98 = alloca ptr
  %l101 = alloca i32
  %l102 = alloca i1
  %l108 = alloca i64
  %l111 = alloca i64
  %l130 = alloca ptr
  %l132 = alloca { i64, [2 x i64] }
  %l134 = alloca { i64, ptr }
  %l138 = alloca { i64, ptr }
  %l141 = alloca { i64, ptr }
  %l142 = alloca %"compiler/mir:Place"
  %l154 = alloca %"compiler/mir:Place"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca { i64, [4 x i64] }
  %t22 = alloca { i64, [4 x i64] }, align 8
  %t40 = alloca { i64, [4 x i64] }, align 8
  %t62 = alloca { i64, [15 x i64] }, align 8
  %t104 = alloca { i64, [15 x i64] }, align 8
  %t162 = alloca { i64, [4 x i64] }, align 8
  %t169 = alloca { i64, [15 x i64] }, align 8
  %t181 = alloca { i64, [21 x i64] }, align 8
  %t259 = alloca { i64, [2 x i64] }, align 8
  %t267 = alloca { i64, [1 x i64] }, align 8
  %t271 = alloca { i64, [1 x i64] }, align 8
  %t291 = alloca { i64, [1 x i64] }, align 8
  %t320 = alloca { i64, [15 x i64] }, align 8
  %t326 = alloca { i64, [21 x i64] }, align 8
  %t347 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l6, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load i32, ptr %l2, !tbaa !23
  %t10 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2earrayOf(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t10, ptr %l24
  br label %bb1
bb1:
  %t11 = load i32, ptr %l24, !tbaa !23
  store i32 %t11, ptr %l7, !tbaa !23
  %t12 = load i32, ptr %l7, !tbaa !23
  %t13 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t16 = icmp eq i32 %t12, %t13
  br i1 %t16, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load %"compiler/source:Span", ptr %l3
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2egap(ptr %v0, ptr %s1, ptr %t18, %"compiler/source:Span" %t19, { i64, ptr } { i64 43, ptr getelementptr inbounds (<{ i64, [43 x i8] }>, ptr @.d12, i32 0, i32 1) })
  br label %bb4
bb3:
  br label %bb5
bb4:
  store { i64, [4 x i64] } zeroinitializer, ptr %t22
  %t23 = getelementptr { i64, [4 x i64] }, ptr %t22, i32 0, i32 0
  store i64 0, ptr %t23
  %t24 = load { i64, [4 x i64] }, ptr %t22
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t24, ptr %rv
  br label %ret
bb5:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load ptr, ptr %l1, !tbaa !29
  %t29 = getelementptr %"compiler/typed:Make", ptr %t27, i32 0, i32 2
  %t30 = load { i64, ptr }, ptr %t29, !tbaa !27
  %t33 = call { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2evals(ptr %v0, ptr %v1, ptr %s0, ptr %t26, { i64, ptr } %t30)
  store { i64, ptr } %t33, ptr %l34
  br label %bb6
bb6:
  %t34 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t34, ptr %l8, !tbaa !27
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/lower:lowering", ptr %t35, i32 0, i32 7
  %t38 = load i1, ptr %t37, !tbaa !21
  br i1 %t38, label %bb7, label %bb8
bb7:
  store { i64, [4 x i64] } zeroinitializer, ptr %t40
  %t41 = getelementptr { i64, [4 x i64] }, ptr %t40, i32 0, i32 0
  store i64 0, ptr %t41
  %t42 = load { i64, [4 x i64] }, ptr %t40
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t42, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = load i32, ptr %l7, !tbaa !23
  %t48 = call i64 @compiler_2flower_2ecompiler_2flower_3alowering_2efixedLen(ptr %v0, ptr %t44, i32 %t45)
  store i64 %t48, ptr %l40
  br label %bb10
bb10:
  %t49 = load i64, ptr %l40, !tbaa !24
  %t50 = icmp sge i64 %t49, 0
  br i1 %t50, label %bb11, label %bb12
bb11:
  %t52 = load ptr, ptr %l0, !tbaa !29
  store ptr %t52, ptr %l42, !tbaa !29
  %t53 = load i32, ptr %l7, !tbaa !23
  store i32 %t53, ptr %l43, !tbaa !23
  %t54 = load i32, ptr %l7, !tbaa !23
  store i32 %t54, ptr %l44, !tbaa !23
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/lower:lowering", ptr %t55, i32 0, i32 3
  %t58 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t61 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v0, ptr %s0, ptr %t57, { i64, ptr } %t58)
  store %"compiler/mir:Range" %t61, ptr %l48
  br label %bb13
bb12:
  br label %bb22
bb13:
  store { i64, [15 x i64] } zeroinitializer, ptr %t62
  %t63 = getelementptr { i64, [15 x i64] }, ptr %t62, i32 0, i32 0
  store i64 6, ptr %t63
  %t64 = load i32, ptr %l44, !tbaa !23
  %t65 = insertvalue { i32, i64, %"compiler/mir:Range" } undef, i32 %t64, 0
  %t66 = insertvalue { i32, i64, %"compiler/mir:Range" } %t65, i64 0, 1
  %t67 = load %"compiler/mir:Range", ptr %l48
  %t68 = insertvalue { i32, i64, %"compiler/mir:Range" } %t66, %"compiler/mir:Range" %t67, 2
  %t69 = getelementptr { i64, [15 x i64] }, ptr %t62, i32 0, i32 1
  store { i32, i64, %"compiler/mir:Range" } %t68, ptr %t69
  %t70 = load { i64, [15 x i64] }, ptr %t62
  %t71 = load %"compiler/source:Span", ptr %l3
  %t72 = load ptr, ptr %l42, !tbaa !29
  %t73 = load i32, ptr %l43, !tbaa !23
  %t76 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t72, i32 %t73, { i64, [15 x i64] } %t70, %"compiler/source:Span" %t71)
  store { i64, [4 x i64] } %t76, ptr %l51
  br label %bb14
bb14:
  %t77 = load { i64, [4 x i64] }, ptr %l51
  store { i64, [4 x i64] } %t77, ptr %l9
  %t78 = load ptr, ptr %l6, !tbaa !29
  store ptr %t78, ptr %l52, !tbaa !29
  %t79 = load ptr, ptr %l6, !tbaa !29
  %t80 = load i32, ptr %l2, !tbaa !23
  %t83 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t79, i32 %t80)
  store i32 %t83, ptr %l55
  br label %bb15
bb15:
  %t84 = load ptr, ptr %l52, !tbaa !29
  %t85 = load i32, ptr %l55, !tbaa !23
  %t86 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t84, i32 %t85)
  store i1 %t86, ptr %l56
  br label %bb16
bb16:
  %t87 = load i1, ptr %l56, !tbaa !21
  %t88 = xor i1 %t87, true
  br i1 %t88, label %bb17, label %bb18
bb17:
  %t90 = load { i64, [4 x i64] }, ptr %l9
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t90, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  %t92 = load ptr, ptr %l0, !tbaa !29
  store ptr %t92, ptr %l59, !tbaa !29
  %t93 = load i32, ptr %l2, !tbaa !23
  store i32 %t93, ptr %l60, !tbaa !23
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t95 = load ptr, ptr %l1, !tbaa !29
  %t97 = getelementptr %"compiler/typed:Make", ptr %t95, i32 0, i32 4
  %t98 = load i32, ptr %t97, !tbaa !23
  %t101 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ebuilt(ptr %v0, ptr %t94, i32 %t98)
  store { i64, [1 x i64] } %t101, ptr %l64
  br label %bb20
bb20:
  %t102 = load { i64, [4 x i64] }, ptr %l9
  %t103 = load i32, ptr %l2, !tbaa !23
  store { i64, [15 x i64] } zeroinitializer, ptr %t104
  %t105 = getelementptr { i64, [15 x i64] }, ptr %t104, i32 0, i32 0
  store i64 7, ptr %t105
  %t106 = load { i64, [1 x i64] }, ptr %l64
  %t107 = insertvalue { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 } undef, { i64, [1 x i64] } %t106, 0
  %t109 = insertvalue { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 } %t107, { i64, [4 x i64] } %t102, 1
  %t111 = insertvalue { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 } %t109, i32 %t103, 2
  %t112 = getelementptr { i64, [15 x i64] }, ptr %t104, i32 0, i32 1
  store { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 } %t111, ptr %t112
  %t113 = load { i64, [15 x i64] }, ptr %t104
  %t114 = load %"compiler/source:Span", ptr %l3
  %t115 = load ptr, ptr %l59, !tbaa !29
  %t116 = load i32, ptr %l60, !tbaa !23
  %t119 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t115, i32 %t116, { i64, [15 x i64] } %t113, %"compiler/source:Span" %t114)
  store { i64, [4 x i64] } %t119, ptr %l69
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s0)
  %t120 = load { i64, [4 x i64] }, ptr %l69
  store { i64, [4 x i64] } %t120, ptr %rv
  br label %ret
bb22:
  %t121 = load ptr, ptr %l6, !tbaa !29
  %t122 = load i32, ptr %l7, !tbaa !23
  %t125 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t121, i32 %t122)
  store i32 %t125, ptr %l72
  br label %bb23
bb23:
  %t126 = load i32, ptr %l72, !tbaa !23
  store i32 %t126, ptr %l10, !tbaa !23
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t128 = load i32, ptr %l2, !tbaa !23
  %t129 = load %"compiler/source:Span", ptr %l3
  %t133 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etemp(ptr %v0, ptr %t127, i32 %t128, %"compiler/source:Span" %t129)
  store i32 %t133, ptr %l76
  br label %bb24
bb24:
  %t134 = load i32, ptr %l76, !tbaa !23
  store i32 %t134, ptr %l11, !tbaa !23
  %t135 = load ptr, ptr %l0, !tbaa !29
  store ptr %t135, ptr %l77, !tbaa !29
  %t136 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t136, ptr %l78
  %t137 = load i32, ptr %l11, !tbaa !23
  %t139 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t137)
  store %"compiler/mir:Place" %t139, ptr %l80
  br label %bb25
bb25:
  br i1 %a4, label %bb26, label %bb27
bb26:
  store { i64, [1 x i64] } %a5, ptr %l82
  br label %bb29
bb27:
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t145 = load ptr, ptr %l1, !tbaa !29
  %t147 = getelementptr %"compiler/typed:Make", ptr %t145, i32 0, i32 4
  %t148 = load i32, ptr %t147, !tbaa !23
  %t151 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2emadeAt(ptr %v0, ptr %t144, i32 %t148)
  store { i64, [1 x i64] } %t151, ptr %l87
  br label %bb28
bb28:
  %t152 = load { i64, [1 x i64] }, ptr %l87
  store { i64, [1 x i64] } %t152, ptr %l82
  br label %bb29
bb29:
  %t153 = load i32, ptr %l2, !tbaa !23
  store i32 %t153, ptr %l88, !tbaa !23
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t155 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t157 = extractvalue { i64, ptr } %t155, 0
  %t160 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2econstI64(ptr %v0, ptr %t154, i64 %t157)
  store { i64, [4 x i64] } %t160, ptr %l92
  br label %bb30
bb30:
  %t161 = load i32, ptr %l10, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t162
  %t163 = getelementptr { i64, [4 x i64] }, ptr %t162, i32 0, i32 0
  store i64 2, ptr %t163
  %t165 = insertvalue { i32, i64 } undef, i32 %t161, 0
  %t166 = insertvalue { i32, i64 } %t165, i64 0, 1
  %t167 = getelementptr { i64, [4 x i64] }, ptr %t162, i32 0, i32 1
  store { i32, i64 } %t166, ptr %t167
  %t168 = load { i64, [4 x i64] }, ptr %t162
  store { i64, [15 x i64] } zeroinitializer, ptr %t169
  %t170 = getelementptr { i64, [15 x i64] }, ptr %t169, i32 0, i32 0
  store i64 8, ptr %t170
  %t171 = load { i64, [1 x i64] }, ptr %l82
  %t172 = insertvalue { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } undef, { i64, [1 x i64] } %t171, 0
  %t173 = load i32, ptr %l88, !tbaa !23
  %t174 = insertvalue { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } %t172, i32 %t173, 1
  %t175 = load { i64, [4 x i64] }, ptr %l92
  %t176 = insertvalue { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } %t174, { i64, [4 x i64] } %t175, 2
  %t178 = insertvalue { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } %t176, { i64, [4 x i64] } %t168, 3
  %t179 = getelementptr { i64, [15 x i64] }, ptr %t169, i32 0, i32 1
  store { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } %t178, ptr %t179
  %t180 = load { i64, [15 x i64] }, ptr %t169
  store { i64, [21 x i64] } zeroinitializer, ptr %t181
  %t182 = getelementptr { i64, [21 x i64] }, ptr %t181, i32 0, i32 0
  store i64 0, ptr %t182
  %t183 = load %"compiler/source:Span", ptr %l78
  %t184 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t183, 0
  %t185 = load %"compiler/mir:Place", ptr %l80
  %t186 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t184, %"compiler/mir:Place" %t185, 1
  %t188 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t186, { i64, [15 x i64] } %t180, 2
  %t189 = getelementptr { i64, [21 x i64] }, ptr %t181, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t188, ptr %t189
  %t190 = load { i64, [21 x i64] }, ptr %t181
  %t192 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t190, ptr %t192
  %t193 = load ptr, ptr %l77, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %t193, ptr %t192)
  br label %bb31
bb31:
  %t195 = load ptr, ptr %l6, !tbaa !29
  store ptr %t195, ptr %l98, !tbaa !29
  %t196 = load ptr, ptr %l6, !tbaa !29
  %t197 = load i32, ptr %l2, !tbaa !23
  %t200 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t196, i32 %t197)
  store i32 %t200, ptr %l101
  br label %bb32
bb32:
  %t201 = load ptr, ptr %l98, !tbaa !29
  %t202 = load i32, ptr %l101, !tbaa !23
  %t203 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t201, i32 %t202)
  store i1 %t203, ptr %l102
  br label %bb33
bb33:
  %t204 = load i1, ptr %l102, !tbaa !21
  store i1 %t204, ptr %l12, !tbaa !21
  store i64 0, ptr %l13, !tbaa !24
  %t205 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t207 = extractvalue { i64, ptr } %t205, 0
  store i64 %t207, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t209 = load i64, ptr %l14, !tbaa !24
  %t210 = load i64, ptr %l13, !tbaa !24
  %t213 = icmp sgt i64 %t209, %t210
  br i1 %t213, label %bb34, label %bb35
bb34:
  %t215 = load i64, ptr %l15, !tbaa !24
  %t217 = icmp sgt i64 %t215, 0
  br i1 %t217, label %bb36, label %bb37
bb35:
  store i64 0, ptr %l108, !tbaa !24
  br label %bb39
bb36:
  %t219 = load i64, ptr %l14, !tbaa !24
  %t220 = load i64, ptr %l13, !tbaa !24
  %t223 = sub i64 %t219, %t220
  %t224 = load i64, ptr %l15, !tbaa !24
  %t227 = add i64 %t223, %t224
  %t229 = sub i64 %t227, 1
  %t230 = load i64, ptr %l15, !tbaa !24
  %t233 = sdiv i64 %t229, %t230
  store i64 %t233, ptr %l111, !tbaa !24
  br label %bb38
bb37:
  store i64 0, ptr %l111, !tbaa !24
  br label %bb38
bb38:
  %t235 = load i64, ptr %l111, !tbaa !24
  store i64 %t235, ptr %l108, !tbaa !24
  br label %bb39
bb39:
  %t236 = load i64, ptr %l108, !tbaa !24
  store i64 %t236, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb40
bb40:
  store %olang.scope zeroinitializer, ptr %s6
  %t237 = load i64, ptr %l17, !tbaa !24
  %t238 = load i64, ptr %l16, !tbaa !24
  %t241 = icmp slt i64 %t237, %t238
  %t243 = xor i1 %t241, true
  br i1 %t243, label %bb41, label %bb42
bb41:
  call void @__olang_scope_close(ptr %s6)
  br label %bb50
bb42:
  br label %bb43
bb43:
  %t245 = load i64, ptr %l13, !tbaa !24
  %t246 = load i64, ptr %l17, !tbaa !24
  %t247 = load i64, ptr %l15, !tbaa !24
  %t250 = mul i64 %t246, %t247
  %t253 = add i64 %t245, %t250
  store i64 %t253, ptr %l18, !tbaa !24
  %t255 = load ptr, ptr %l0, !tbaa !29
  %t257 = getelementptr %"compiler/lower:lowering", ptr %t255, i32 0, i32 3
  store ptr %t257, ptr %l130, !tbaa !29
  %t258 = load i32, ptr %l11, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t259
  %t260 = getelementptr { i64, [2 x i64] }, ptr %t259, i32 0, i32 0
  store i64 1, ptr %t260
  %t262 = insertvalue { i32 } undef, i32 %t258, 0
  %t263 = getelementptr { i64, [2 x i64] }, ptr %t259, i32 0, i32 1
  store { i32 } %t262, ptr %t263
  %t264 = load { i64, [2 x i64] }, ptr %t259
  store { i64, [2 x i64] } %t264, ptr %l132
  %t265 = load i1, ptr %l12, !tbaa !21
  br i1 %t265, label %bb44, label %bb45
bb44:
  store { i64, [1 x i64] } zeroinitializer, ptr %t267
  %t268 = getelementptr { i64, [1 x i64] }, ptr %t267, i32 0, i32 0
  store i64 3, ptr %t268
  %t269 = load { i64, [1 x i64] }, ptr %t267
  %t270 = load i64, ptr %l18, !tbaa !24
  store { i64, [1 x i64] } zeroinitializer, ptr %t271
  %t272 = getelementptr { i64, [1 x i64] }, ptr %t271, i32 0, i32 0
  store i64 2, ptr %t272
  %t274 = insertvalue { i64 } undef, i64 %t270, 0
  %t275 = getelementptr { i64, [1 x i64] }, ptr %t271, i32 0, i32 1
  store { i64 } %t274, ptr %t275
  %t276 = load { i64, [1 x i64] }, ptr %t271
  %t277 = mul i64 2, 16
  %t278 = call ptr @__olang_scope_alloc_zeroed(ptr %s6, i64 %t277)
  %t279 = insertvalue { i64, ptr } undef, i64 2, 0
  %t280 = insertvalue { i64, ptr } %t279, ptr %t278, 1
  store { i64, ptr } %t280, ptr %l138, !tbaa !27
  %t282 = getelementptr { i64, ptr }, ptr %l138, i32 0, i32 1
  %t283 = load ptr, ptr %t282, !tbaa !27
  %t284 = getelementptr { i64, [1 x i64] }, ptr %t283, i64 0
  store { i64, [1 x i64] } %t269, ptr %t284
  %t286 = getelementptr { i64, ptr }, ptr %l138, i32 0, i32 1
  %t287 = load ptr, ptr %t286, !tbaa !27
  %t288 = getelementptr { i64, [1 x i64] }, ptr %t287, i64 1
  store { i64, [1 x i64] } %t276, ptr %t288
  %t289 = load { i64, ptr }, ptr %l138, !tbaa !27
  store { i64, ptr } %t289, ptr %l134, !tbaa !27
  br label %bb46
bb45:
  %t290 = load i64, ptr %l18, !tbaa !24
  store { i64, [1 x i64] } zeroinitializer, ptr %t291
  %t292 = getelementptr { i64, [1 x i64] }, ptr %t291, i32 0, i32 0
  store i64 2, ptr %t292
  %t294 = insertvalue { i64 } undef, i64 %t290, 0
  %t295 = getelementptr { i64, [1 x i64] }, ptr %t291, i32 0, i32 1
  store { i64 } %t294, ptr %t295
  %t296 = load { i64, [1 x i64] }, ptr %t291
  %t297 = mul i64 1, 16
  %t298 = call ptr @__olang_scope_alloc_zeroed(ptr %s6, i64 %t297)
  %t299 = insertvalue { i64, ptr } undef, i64 1, 0
  %t300 = insertvalue { i64, ptr } %t299, ptr %t298, 1
  store { i64, ptr } %t300, ptr %l141, !tbaa !27
  %t302 = getelementptr { i64, ptr }, ptr %l141, i32 0, i32 1
  %t303 = load ptr, ptr %t302, !tbaa !27
  %t304 = getelementptr { i64, [1 x i64] }, ptr %t303, i64 0
  store { i64, [1 x i64] } %t296, ptr %t304
  %t305 = load { i64, ptr }, ptr %l141, !tbaa !27
  store { i64, ptr } %t305, ptr %l134, !tbaa !27
  br label %bb46
bb46:
  %t306 = load ptr, ptr %l130, !tbaa !29
  %t307 = load { i64, [2 x i64] }, ptr %l132
  %t308 = load { i64, ptr }, ptr %l134, !tbaa !27
  %t309 = call %"compiler/mir:Place" @compiler_2fmir_2ecompiler_2fmir_3aFn_2ePlace(ptr %v0, ptr %s6, ptr %t306, { i64, [2 x i64] } %t307, { i64, ptr } %t308)
  store %"compiler/mir:Place" %t309, ptr %l142
  br label %bb47
bb47:
  %t310 = load %"compiler/mir:Place", ptr %l142
  %t311 = load ptr, ptr %l0, !tbaa !29
  %t312 = load %"compiler/source:Span", ptr %l3
  %t314 = load i64, ptr %l18, !tbaa !24
  %t316 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t317 = load ptr, ptr %t316, !tbaa !27
  %t318 = getelementptr { i64, [4 x i64] }, ptr %t317, i64 %t314
  %t319 = load { i64, [4 x i64] }, ptr %t318
  store { i64, [15 x i64] } zeroinitializer, ptr %t320
  %t321 = getelementptr { i64, [15 x i64] }, ptr %t320, i32 0, i32 0
  store i64 0, ptr %t321
  %t323 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t319, 0
  %t324 = getelementptr { i64, [15 x i64] }, ptr %t320, i32 0, i32 1
  store { { i64, [4 x i64] } } %t323, ptr %t324
  %t325 = load { i64, [15 x i64] }, ptr %t320
  store { i64, [21 x i64] } zeroinitializer, ptr %t326
  %t327 = getelementptr { i64, [21 x i64] }, ptr %t326, i32 0, i32 0
  store i64 0, ptr %t327
  %t329 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t312, 0
  %t331 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t329, %"compiler/mir:Place" %t310, 1
  %t333 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t331, { i64, [15 x i64] } %t325, 2
  %t334 = getelementptr { i64, [21 x i64] }, ptr %t326, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t333, ptr %t334
  %t335 = load { i64, [21 x i64] }, ptr %t326
  %t337 = call ptr @__olang_scope_alloc_a(ptr %s6, i64 176, i64 8)
  store { i64, [21 x i64] } %t335, ptr %t337
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s6, ptr %t311, ptr %t337)
  br label %bb48
bb48:
  call void @__olang_scope_close(ptr %s6)
  br label %bb49
bb49:
  %t340 = load i64, ptr %l17, !tbaa !24
  %t342 = add i64 %t340, 1
  store i64 %t342, ptr %l17, !tbaa !24
  br label %bb40
bb50:
  %t344 = load i32, ptr %l11, !tbaa !23
  %t346 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t344)
  store %"compiler/mir:Place" %t346, ptr %l154
  br label %bb51
bb51:
  store { i64, [4 x i64] } zeroinitializer, ptr %t347
  %t348 = getelementptr { i64, [4 x i64] }, ptr %t347, i32 0, i32 0
  store i64 1, ptr %t348
  %t349 = load %"compiler/mir:Place", ptr %l154
  %t350 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t349, 0
  %t351 = getelementptr { i64, [4 x i64] }, ptr %t347, i32 0, i32 1
  store { %"compiler/mir:Place" } %t350, ptr %t351
  %t352 = load { i64, [4 x i64] }, ptr %t347
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t352, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local i32 @compiler_2flower_2ecompiler_2flower_3alowering_2earrayOf(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca i32
  %l8 = alloca i32
  %l11 = alloca i1
  %l12 = alloca ptr
  %l15 = alloca i32
  %l16 = alloca i32
  %l19 = alloca i32
  %l22 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/lower:lowering", ptr %a0, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t6, i32 %a1)
  store i32 %t10, ptr %l8
  br label %bb1
bb1:
  %t11 = load i32, ptr %l8, !tbaa !23
  store i32 %t11, ptr %l3, !tbaa !23
  %t12 = load ptr, ptr %l2, !tbaa !29
  %t13 = load i32, ptr %l3, !tbaa !23
  %t16 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t12, i32 %t13)
  store i1 %t16, ptr %l11
  br label %bb2
bb2:
  %t17 = load i1, ptr %l11, !tbaa !21
  br i1 %t17, label %bb3, label %bb4
bb3:
  %t18 = load ptr, ptr %l2, !tbaa !29
  store ptr %t18, ptr %l12, !tbaa !29
  %t19 = load ptr, ptr %l2, !tbaa !29
  %t20 = load i32, ptr %l3, !tbaa !23
  %t23 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t19, i32 %t20)
  store i32 %t23, ptr %l15
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t24 = load ptr, ptr %l12, !tbaa !29
  %t25 = load i32, ptr %l15, !tbaa !23
  %t26 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t24, i32 %t25)
  store i32 %t26, ptr %l16
  br label %bb6
bb6:
  %t27 = load i32, ptr %l16, !tbaa !23
  store i32 %t27, ptr %l3, !tbaa !23
  br label %bb7
bb7:
  %t28 = load ptr, ptr %l2, !tbaa !29
  %t29 = load i32, ptr %l3, !tbaa !23
  %t32 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t28, i32 %t29)
  store i32 %t32, ptr %l19
  br label %bb8
bb8:
  %t33 = load i32, ptr %l19
  %t35 = trunc i64 19 to i32
  %t36 = icmp eq i32 %t33, %t35
  br i1 %t36, label %bb9, label %bb10
bb9:
  %t38 = load i32, ptr %l3, !tbaa !23
  store i32 %t38, ptr %l22, !tbaa !23
  br label %bb11
bb10:
  %t40 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t40, ptr %l22, !tbaa !23
  br label %bb11
bb11:
  %t42 = load i32, ptr %l22, !tbaa !23
  store i32 %t42, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2earrayStore(ptr %v0, ptr %a0, %"compiler/mir:Place" %a1, { i64, [4 x i64] } %a2, i32 %a3, i1 %a4, %"compiler/source:Span" %a5, { i64, [1 x i64] } %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/mir:Place"
  %l3 = alloca i32
  %l5 = alloca %"compiler/source:Span"
  %l7 = alloca i32
  %l8 = alloca { i64, [4 x i64] }
  %l9 = alloca { i64, [4 x i64] }
  %l10 = alloca { i64, [4 x i64] }
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca i32
  %l19 = alloca i32
  %l25 = alloca { i64, ptr }
  %l27 = alloca { i64, [4 x i64] }
  %l28 = alloca ptr
  %l29 = alloca i32
  %l30 = alloca i32
  %l32 = alloca %"compiler/mir:Place"
  %l34 = alloca { i64, ptr }
  %l36 = alloca { i64, [4 x i64] }
  %l42 = alloca { i64, ptr }
  %l44 = alloca { i64, [4 x i64] }
  %l47 = alloca i32
  %l50 = alloca i32
  %l53 = alloca i32
  %l61 = alloca ptr
  %l62 = alloca %"compiler/source:Span"
  %l63 = alloca %"compiler/mir:Place"
  %l65 = alloca %"compiler/mir:Place"
  %l74 = alloca { i64, [4 x i64] }
  %l75 = alloca ptr
  %l77 = alloca %"compiler/mir:Place"
  %l82 = alloca { i64, [4 x i64] }
  %l84 = alloca %"compiler/mir:Place"
  %s0 = alloca %olang.scope
  %t14 = alloca { i64, [4 x i64] }, align 8
  %t41 = alloca { i64, [4 x i64] }, align 8
  %t109 = alloca { i64, [8 x i64] }, align 8
  %t132 = alloca { i64, [21 x i64] }, align 8
  %t165 = alloca { i64, [4 x i64] }, align 8
  %t181 = alloca { i64, [4 x i64] }, align 8
  %t193 = alloca { i64, [15 x i64] }, align 8
  %t199 = alloca { i64, [21 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/mir:Place" %a1, ptr %l1
  store i32 %a3, ptr %l3
  store %"compiler/source:Span" %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = load i32, ptr %l3, !tbaa !23
  %t4 = load %"compiler/source:Span", ptr %l5
  %t9 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2elocal(ptr %v0, ptr %t1, { i64, [4 x i64] } %a2, i32 %t3, %"compiler/source:Span" %t4)
  store i32 %t9, ptr %l19
  br label %bb1
bb1:
  %t10 = load i32, ptr %l19, !tbaa !23
  store i32 %t10, ptr %l7, !tbaa !23
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  %t13 = load %"compiler/mir:Place", ptr %l1
  store { i64, [4 x i64] } zeroinitializer, ptr %t14
  %t15 = getelementptr { i64, [4 x i64] }, ptr %t14, i32 0, i32 0
  store i64 1, ptr %t15
  %t17 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t13, 0
  %t18 = getelementptr { i64, [4 x i64] }, ptr %t14, i32 0, i32 1
  store { %"compiler/mir:Place" } %t17, ptr %t18
  %t19 = load { i64, [4 x i64] }, ptr %t14
  %t20 = mul i64 1, 40
  %t21 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t20)
  %t22 = insertvalue { i64, ptr } undef, i64 1, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t21, 1
  store { i64, ptr } %t23, ptr %l25, !tbaa !27
  %t25 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr { i64, [4 x i64] }, ptr %t26, i64 0
  store { i64, [4 x i64] } %t19, ptr %t27
  %t28 = load %"compiler/source:Span", ptr %l5
  %t32 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t34 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s0, ptr %t11, i32 22, i32 %t12, { i64, ptr } %t32, %"compiler/source:Span" %t28)
  store { i64, [4 x i64] } %t34, ptr %l27
  br label %bb2
bb2:
  %t35 = load { i64, [4 x i64] }, ptr %l27
  store { i64, [4 x i64] } %t35, ptr %l8
  %t36 = load ptr, ptr %l0, !tbaa !29
  store ptr %t36, ptr %l28, !tbaa !29
  store i32 22, ptr %l29
  %t37 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  store i32 %t37, ptr %l30, !tbaa !23
  %t38 = load i32, ptr %l7, !tbaa !23
  %t40 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t38)
  store %"compiler/mir:Place" %t40, ptr %l32
  br label %bb3
bb3:
  store { i64, [4 x i64] } zeroinitializer, ptr %t41
  %t42 = getelementptr { i64, [4 x i64] }, ptr %t41, i32 0, i32 0
  store i64 1, ptr %t42
  %t43 = load %"compiler/mir:Place", ptr %l32
  %t44 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t43, 0
  %t45 = getelementptr { i64, [4 x i64] }, ptr %t41, i32 0, i32 1
  store { %"compiler/mir:Place" } %t44, ptr %t45
  %t46 = load { i64, [4 x i64] }, ptr %t41
  %t47 = mul i64 1, 40
  %t48 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t47)
  %t49 = insertvalue { i64, ptr } undef, i64 1, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t48, 1
  store { i64, ptr } %t50, ptr %l34, !tbaa !27
  %t52 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !27
  %t54 = getelementptr { i64, [4 x i64] }, ptr %t53, i64 0
  store { i64, [4 x i64] } %t46, ptr %t54
  %t55 = load %"compiler/source:Span", ptr %l5
  %t56 = load ptr, ptr %l28, !tbaa !29
  %t57 = load i32, ptr %l29
  %t58 = load i32, ptr %l30, !tbaa !23
  %t59 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t61 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s0, ptr %t56, i32 %t57, i32 %t58, { i64, ptr } %t59, %"compiler/source:Span" %t55)
  store { i64, [4 x i64] } %t61, ptr %l36
  br label %bb4
bb4:
  %t62 = load { i64, [4 x i64] }, ptr %l36
  store { i64, [4 x i64] } %t62, ptr %l9
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t65 = load { i64, [4 x i64] }, ptr %l8
  %t66 = load { i64, [4 x i64] }, ptr %l9
  %t67 = mul i64 2, 40
  %t68 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t67)
  %t69 = insertvalue { i64, ptr } undef, i64 2, 0
  %t70 = insertvalue { i64, ptr } %t69, ptr %t68, 1
  store { i64, ptr } %t70, ptr %l42, !tbaa !27
  %t72 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = getelementptr { i64, [4 x i64] }, ptr %t73, i64 0
  store { i64, [4 x i64] } %t65, ptr %t74
  %t76 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !27
  %t78 = getelementptr { i64, [4 x i64] }, ptr %t77, i64 1
  store { i64, [4 x i64] } %t66, ptr %t78
  %t79 = load %"compiler/source:Span", ptr %l5
  %t83 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t85 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s0, ptr %t63, i32 13, i32 %t64, { i64, ptr } %t83, %"compiler/source:Span" %t79)
  store { i64, [4 x i64] } %t85, ptr %l44
  br label %bb5
bb5:
  %t86 = load { i64, [4 x i64] }, ptr %l44
  store { i64, [4 x i64] } %t86, ptr %l10
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/lower:lowering", ptr %t87, i32 0, i32 3
  %t91 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t89)
  store i32 %t91, ptr %l47
  br label %bb6
bb6:
  %t92 = load i32, ptr %l47, !tbaa !23
  store i32 %t92, ptr %l11, !tbaa !23
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/lower:lowering", ptr %t93, i32 0, i32 3
  %t97 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t95)
  store i32 %t97, ptr %l50
  br label %bb7
bb7:
  %t98 = load i32, ptr %l50, !tbaa !23
  store i32 %t98, ptr %l12, !tbaa !23
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/lower:lowering", ptr %t99, i32 0, i32 3
  %t103 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t101)
  store i32 %t103, ptr %l53
  br label %bb8
bb8:
  %t104 = load i32, ptr %l53, !tbaa !23
  store i32 %t104, ptr %l13, !tbaa !23
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t106 = load { i64, [4 x i64] }, ptr %l10
  %t107 = load i32, ptr %l11, !tbaa !23
  %t108 = load i32, ptr %l12, !tbaa !23
  store { i64, [8 x i64] } zeroinitializer, ptr %t109
  %t110 = getelementptr { i64, [8 x i64] }, ptr %t109, i32 0, i32 0
  store i64 2, ptr %t110
  %t112 = insertvalue { { i64, [4 x i64] }, i32, i32 } undef, { i64, [4 x i64] } %t106, 0
  %t114 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t112, i32 %t107, 1
  %t116 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t114, i32 %t108, 2
  %t117 = getelementptr { i64, [8 x i64] }, ptr %t109, i32 0, i32 1
  store { { i64, [4 x i64] }, i32, i32 } %t116, ptr %t117
  %t118 = load { i64, [8 x i64] }, ptr %t109
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t105, { i64, [8 x i64] } %t118)
  br label %bb9
bb9:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t122 = load i32, ptr %l11, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t121, i32 %t122)
  br label %bb10
bb10:
  %t125 = load ptr, ptr %l0, !tbaa !29
  store ptr %t125, ptr %l61, !tbaa !29
  %t126 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t126, ptr %l62
  %t127 = load %"compiler/mir:Place", ptr %l1
  store %"compiler/mir:Place" %t127, ptr %l63
  %t128 = load i32, ptr %l7, !tbaa !23
  %t130 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t128)
  store %"compiler/mir:Place" %t130, ptr %l65
  br label %bb11
bb11:
  %t131 = load { i64, [4 x i64] }, ptr %l9
  store { i64, [21 x i64] } zeroinitializer, ptr %t132
  %t133 = getelementptr { i64, [21 x i64] }, ptr %t132, i32 0, i32 0
  store i64 10, ptr %t133
  %t134 = load %"compiler/source:Span", ptr %l62
  %t135 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", %"compiler/mir:Place", { i64, [4 x i64] } } undef, %"compiler/source:Span" %t134, 0
  %t136 = load %"compiler/mir:Place", ptr %l63
  %t137 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", %"compiler/mir:Place", { i64, [4 x i64] } } %t135, %"compiler/mir:Place" %t136, 1
  %t138 = load %"compiler/mir:Place", ptr %l65
  %t139 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", %"compiler/mir:Place", { i64, [4 x i64] } } %t137, %"compiler/mir:Place" %t138, 2
  %t141 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", %"compiler/mir:Place", { i64, [4 x i64] } } %t139, { i64, [4 x i64] } %t131, 3
  %t142 = getelementptr { i64, [21 x i64] }, ptr %t132, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Place", %"compiler/mir:Place", { i64, [4 x i64] } } %t141, ptr %t142
  %t143 = load { i64, [21 x i64] }, ptr %t132
  %t145 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t143, ptr %t145
  %t146 = load ptr, ptr %l61, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %t146, ptr %t145)
  br label %bb12
bb12:
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t149 = load i32, ptr %l13, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2egoto(ptr %v0, ptr %t148, i32 %t149)
  br label %bb13
bb13:
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t153 = load i32, ptr %l12, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t152, i32 %t153)
  br label %bb14
bb14:
  br i1 %a4, label %bb15, label %bb16
bb15:
  %t158 = load ptr, ptr %l0, !tbaa !29
  store ptr %t158, ptr %l75, !tbaa !29
  %t159 = load i32, ptr %l7, !tbaa !23
  %t161 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t159)
  store %"compiler/mir:Place" %t161, ptr %l77
  br label %bb17
bb16:
  %t162 = load i32, ptr %l7, !tbaa !23
  %t164 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t162)
  store %"compiler/mir:Place" %t164, ptr %l84
  br label %bb19
bb17:
  store { i64, [4 x i64] } zeroinitializer, ptr %t165
  %t166 = getelementptr { i64, [4 x i64] }, ptr %t165, i32 0, i32 0
  store i64 1, ptr %t166
  %t167 = load %"compiler/mir:Place", ptr %l77
  %t168 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t167, 0
  %t169 = getelementptr { i64, [4 x i64] }, ptr %t165, i32 0, i32 1
  store { %"compiler/mir:Place" } %t168, ptr %t169
  %t170 = load { i64, [4 x i64] }, ptr %t165
  %t171 = load i32, ptr %l3, !tbaa !23
  %t172 = load %"compiler/source:Span", ptr %l5
  %t174 = load ptr, ptr %l75, !tbaa !29
  %t179 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2earrayCopy(ptr %v0, ptr %t174, { i64, [4 x i64] } %t170, i32 %t171, %"compiler/source:Span" %t172, { i64, [1 x i64] } %a6)
  store { i64, [4 x i64] } %t179, ptr %l82
  br label %bb18
bb18:
  %t180 = load { i64, [4 x i64] }, ptr %l82
  store { i64, [4 x i64] } %t180, ptr %l74
  br label %bb20
bb19:
  store { i64, [4 x i64] } zeroinitializer, ptr %t181
  %t182 = getelementptr { i64, [4 x i64] }, ptr %t181, i32 0, i32 0
  store i64 1, ptr %t182
  %t183 = load %"compiler/mir:Place", ptr %l84
  %t184 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t183, 0
  %t185 = getelementptr { i64, [4 x i64] }, ptr %t181, i32 0, i32 1
  store { %"compiler/mir:Place" } %t184, ptr %t185
  %t186 = load { i64, [4 x i64] }, ptr %t181
  store { i64, [4 x i64] } %t186, ptr %l74
  br label %bb20
bb20:
  %t188 = load { i64, [4 x i64] }, ptr %l74
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t190 = load %"compiler/source:Span", ptr %l5
  %t191 = load %"compiler/mir:Place", ptr %l1
  store { i64, [15 x i64] } zeroinitializer, ptr %t193
  %t194 = getelementptr { i64, [15 x i64] }, ptr %t193, i32 0, i32 0
  store i64 0, ptr %t194
  %t196 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t188, 0
  %t197 = getelementptr { i64, [15 x i64] }, ptr %t193, i32 0, i32 1
  store { { i64, [4 x i64] } } %t196, ptr %t197
  %t198 = load { i64, [15 x i64] }, ptr %t193
  store { i64, [21 x i64] } zeroinitializer, ptr %t199
  %t200 = getelementptr { i64, [21 x i64] }, ptr %t199, i32 0, i32 0
  store i64 0, ptr %t200
  %t202 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t190, 0
  %t204 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t202, %"compiler/mir:Place" %t191, 1
  %t206 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t204, { i64, [15 x i64] } %t198, 2
  %t207 = getelementptr { i64, [21 x i64] }, ptr %t199, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t206, ptr %t207
  %t208 = load { i64, [21 x i64] }, ptr %t199
  %t210 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t208, ptr %t210
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %t189, ptr %t210)
  br label %bb21
bb21:
  %t213 = load ptr, ptr %l0, !tbaa !29
  %t214 = load i32, ptr %l13, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2egoto(ptr %v0, ptr %t213, i32 %t214)
  br label %bb22
bb22:
  %t217 = load ptr, ptr %l0, !tbaa !29
  %t218 = load i32, ptr %l13, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t217, i32 %t218)
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2ebang(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1, i32 %a2, %"compiler/source:Span" %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i32
  %l13 = alloca i32
  %l18 = alloca { i64, ptr }
  %l24 = alloca i64
  %l27 = alloca i64
  %l47 = alloca i32
  %l50 = alloca i32
  %l55 = alloca { i64, ptr }
  %l58 = alloca { i64, ptr }
  %l60 = alloca { i64, [4 x i64] }
  %l71 = alloca { i64, ptr }
  %l80 = alloca ptr
  %l81 = alloca %"compiler/source:Span"
  %l82 = alloca i32
  %l85 = alloca { i64, [4 x i64] }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %t105 = alloca { i64, [8 x i64] }, align 8
  %t133 = alloca { i64, [8 x i64] }, align 8
  %t161 = alloca { i64, [8 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a3, ptr %l3
  store i32 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = load %"compiler/source:Span", ptr %l3
  %t7 = call { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2ebangNames(ptr %v0, ptr %s0, ptr %t1, i32 %a2, %"compiler/source:Span" %t3)
  store { i64, ptr } %t7, ptr %l18
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t8, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t9 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  store i64 %t11, ptr %l7, !tbaa !24
  store i64 2, ptr %l8, !tbaa !24
  %t13 = load i64, ptr %l7, !tbaa !24
  %t14 = load i64, ptr %l6, !tbaa !24
  %t17 = icmp sgt i64 %t13, %t14
  br i1 %t17, label %bb2, label %bb3
bb2:
  %t19 = load i64, ptr %l8, !tbaa !24
  %t21 = icmp sgt i64 %t19, 0
  br i1 %t21, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l24, !tbaa !24
  br label %bb7
bb4:
  %t23 = load i64, ptr %l7, !tbaa !24
  %t24 = load i64, ptr %l6, !tbaa !24
  %t27 = sub i64 %t23, %t24
  %t28 = load i64, ptr %l8, !tbaa !24
  %t31 = add i64 %t27, %t28
  %t33 = sub i64 %t31, 1
  %t34 = load i64, ptr %l8, !tbaa !24
  %t37 = sdiv i64 %t33, %t34
  store i64 %t37, ptr %l27, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l27, !tbaa !24
  br label %bb6
bb6:
  %t39 = load i64, ptr %l27, !tbaa !24
  store i64 %t39, ptr %l24, !tbaa !24
  br label %bb7
bb7:
  %t40 = load i64, ptr %l24, !tbaa !24
  store i64 %t40, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t41 = load i64, ptr %l10, !tbaa !24
  %t42 = load i64, ptr %l9, !tbaa !24
  %t45 = icmp slt i64 %t41, %t42
  %t47 = xor i1 %t45, true
  br i1 %t47, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb20
bb10:
  br label %bb11
bb11:
  %t49 = load i64, ptr %l6, !tbaa !24
  %t50 = load i64, ptr %l10, !tbaa !24
  %t51 = load i64, ptr %l8, !tbaa !24
  %t54 = mul i64 %t50, %t51
  %t57 = add i64 %t49, %t54
  store i64 %t57, ptr %l11, !tbaa !24
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/lower:lowering", ptr %t59, i32 0, i32 3
  %t63 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t61)
  store i32 %t63, ptr %l47
  br label %bb12
bb12:
  %t64 = load i32, ptr %l47, !tbaa !23
  store i32 %t64, ptr %l12, !tbaa !23
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/lower:lowering", ptr %t65, i32 0, i32 3
  %t69 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t67)
  store i32 %t69, ptr %l50
  br label %bb13
bb13:
  %t70 = load i32, ptr %l50, !tbaa !23
  store i32 %t70, ptr %l13, !tbaa !23
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t74 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t74, ptr %l55, !tbaa !27
  %t75 = load i64, ptr %l11, !tbaa !24
  %t77 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = getelementptr { i64, [4 x i64] }, ptr %t78, i64 %t75
  %t80 = load { i64, [4 x i64] }, ptr %t79
  %t81 = mul i64 2, 40
  %t82 = call ptr @__olang_scope_alloc_zeroed(ptr %s2, i64 %t81)
  %t83 = insertvalue { i64, ptr } undef, i64 2, 0
  %t84 = insertvalue { i64, ptr } %t83, ptr %t82, 1
  store { i64, ptr } %t84, ptr %l58, !tbaa !27
  %t86 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t87 = load ptr, ptr %t86, !tbaa !27
  %t88 = getelementptr { i64, [4 x i64] }, ptr %t87, i64 0
  store { i64, [4 x i64] } %a1, ptr %t88
  %t90 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t91 = load ptr, ptr %t90, !tbaa !27
  %t92 = getelementptr { i64, [4 x i64] }, ptr %t91, i64 1
  store { i64, [4 x i64] } %t80, ptr %t92
  %t93 = load %"compiler/source:Span", ptr %l3
  %t97 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t99 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s2, ptr %t71, i32 13, i32 %t72, { i64, ptr } %t97, %"compiler/source:Span" %t93)
  store { i64, [4 x i64] } %t99, ptr %l60
  br label %bb14
bb14:
  %t100 = load { i64, [4 x i64] }, ptr %l60
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = load i32, ptr %l12, !tbaa !23
  %t104 = load i32, ptr %l13, !tbaa !23
  store { i64, [8 x i64] } zeroinitializer, ptr %t105
  %t106 = getelementptr { i64, [8 x i64] }, ptr %t105, i32 0, i32 0
  store i64 2, ptr %t106
  %t108 = insertvalue { { i64, [4 x i64] }, i32, i32 } undef, { i64, [4 x i64] } %t100, 0
  %t110 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t108, i32 %t103, 1
  %t112 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t110, i32 %t104, 2
  %t113 = getelementptr { i64, [8 x i64] }, ptr %t105, i32 0, i32 1
  store { { i64, [4 x i64] }, i32, i32 } %t112, ptr %t113
  %t114 = load { i64, [8 x i64] }, ptr %t105
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t101, { i64, [8 x i64] } %t114)
  br label %bb15
bb15:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t118 = load i32, ptr %l12, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t117, i32 %t118)
  br label %bb16
bb16:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t122 = load %"compiler/source:Span", ptr %l3
  %t123 = load i32, ptr %l4
  %t124 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t124, ptr %l71, !tbaa !27
  %t125 = load i64, ptr %l11, !tbaa !24
  %t127 = add i64 %t125, 1
  %t129 = getelementptr { i64, ptr }, ptr %l71, i32 0, i32 1
  %t130 = load ptr, ptr %t129, !tbaa !27
  %t131 = getelementptr { i64, [4 x i64] }, ptr %t130, i64 %t127
  %t132 = load { i64, [4 x i64] }, ptr %t131
  store { i64, [8 x i64] } zeroinitializer, ptr %t133
  %t134 = getelementptr { i64, [8 x i64] }, ptr %t133, i32 0, i32 0
  store i64 8, ptr %t134
  %t136 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } undef, %"compiler/source:Span" %t122, 0
  %t138 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t136, i32 %t123, 1
  %t140 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t138, { i64, [4 x i64] } %t132, 2
  %t141 = getelementptr { i64, [8 x i64] }, ptr %t133, i32 0, i32 1
  store { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t140, ptr %t141
  %t142 = load { i64, [8 x i64] }, ptr %t133
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t121, { i64, [8 x i64] } %t142)
  br label %bb17
bb17:
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t146 = load i32, ptr %l13, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t145, i32 %t146)
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb19:
  %t149 = load i64, ptr %l10, !tbaa !24
  %t151 = add i64 %t149, 1
  store i64 %t151, ptr %l10, !tbaa !24
  br label %bb8
bb20:
  %t153 = load ptr, ptr %l0, !tbaa !29
  store ptr %t153, ptr %l80, !tbaa !29
  %t154 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t154, ptr %l81
  %t155 = load i32, ptr %l4
  store i32 %t155, ptr %l82
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t157 = load %"compiler/source:Span", ptr %l3
  %t160 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2etextData(ptr %v0, ptr %s0, ptr %t156, { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d13, i32 0, i32 1) }, %"compiler/source:Span" %t157)
  store { i64, [4 x i64] } %t160, ptr %l85
  br label %bb21
bb21:
  store { i64, [8 x i64] } zeroinitializer, ptr %t161
  %t162 = getelementptr { i64, [8 x i64] }, ptr %t161, i32 0, i32 0
  store i64 8, ptr %t162
  %t163 = load %"compiler/source:Span", ptr %l81
  %t164 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } undef, %"compiler/source:Span" %t163, 0
  %t165 = load i32, ptr %l82
  %t166 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t164, i32 %t165, 1
  %t167 = load { i64, [4 x i64] }, ptr %l85
  %t168 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t166, { i64, [4 x i64] } %t167, 2
  %t169 = getelementptr { i64, [8 x i64] }, ptr %t161, i32 0, i32 1
  store { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t168, ptr %t169
  %t170 = load { i64, [8 x i64] }, ptr %t161
  %t171 = load ptr, ptr %l80, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t171, { i64, [8 x i64] } %t170)
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2eblock(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l6 = alloca i32
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l16 = alloca i64
  %l18 = alloca i1
  %l20 = alloca %"compiler/lower:level"
  %l33 = alloca { i64, ptr }
  %l46 = alloca %"compiler/typed:BlockInfo"
  %l48 = alloca i32
  %l67 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 7
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/lower:lowering", ptr %t6, i32 0, i32 9
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e_2eLen_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l16
  br label %bb4
bb4:
  %t11 = load i64, ptr %l16, !tbaa !24
  %t12 = icmp sgt i64 %t11, 0
  br i1 %t12, label %bb5, label %bb6
bb5:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = call %"compiler/lower:level" @compiler_2flower_2ecompiler_2flower_3alowering_2etop(ptr %v0, ptr %t14)
  store %"compiler/lower:level" %t16, ptr %l20
  br label %bb7
bb6:
  store i1 false, ptr %l18, !tbaa !21
  br label %bb8
bb7:
  %t17 = getelementptr %"compiler/lower:level", ptr %l20, i32 0, i32 1
  %t18 = load i32, ptr %t17, !tbaa !23
  %t19 = load ptr, ptr %l1, !tbaa !29
  %t21 = getelementptr %"compiler/typed:Block", ptr %t19, i32 0, i32 0
  %t22 = load i32, ptr %t21, !tbaa !23
  %t25 = icmp eq i32 %t18, %t22
  store i1 %t25, ptr %l18, !tbaa !21
  br label %bb8
bb8:
  %t27 = load i1, ptr %l18, !tbaa !21
  br i1 %t27, label %bb9, label %bb10
bb9:
  %t28 = load ptr, ptr %l1, !tbaa !29
  %t30 = getelementptr %"compiler/typed:Block", ptr %t28, i32 0, i32 1
  %t31 = load { i64, ptr }, ptr %t30, !tbaa !27
  store { i64, ptr } %t31, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t33 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t33, 0
  store i64 %t35, ptr %l4, !tbaa !24
  br label %bb11
bb10:
  br label %bb18
bb11:
  %t37 = load i64, ptr %l3, !tbaa !24
  %t38 = load i64, ptr %l4, !tbaa !24
  %t41 = icmp slt i64 %t37, %t38
  %t43 = xor i1 %t41, true
  br i1 %t43, label %bb12, label %bb13
bb12:
  br label %bb17
bb13:
  br label %bb14
bb14:
  %t45 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t45, ptr %l33, !tbaa !27
  %t46 = load i64, ptr %l3, !tbaa !24
  %t48 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = getelementptr ptr, ptr %t49, i64 %t46
  %t51 = load ptr, ptr %t50, !tbaa !39
  %t53 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estmt(ptr %v0, ptr %v1, ptr %t53, ptr %t51)
  br label %bb15
bb15:
  br label %bb16
bb16:
  %t57 = load i64, ptr %l3, !tbaa !24
  %t59 = add i64 %t57, 1
  store i64 %t59, ptr %l3, !tbaa !24
  br label %bb11
bb17:
  br label %ret
bb18:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/lower:lowering", ptr %t61, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !29
  %t66 = getelementptr %"compiler/typed:Body", ptr %t64, i32 0, i32 8
  %t67 = load ptr, ptr %l1, !tbaa !29
  %t69 = getelementptr %"compiler/typed:Block", ptr %t67, i32 0, i32 0
  %t70 = load i32, ptr %t69, !tbaa !23
  %t72 = sext i32 %t70 to i64
  %t75 = call %"compiler/typed:BlockInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockInfo_3e_2eAt_3ccompiler_2ftyped_3aBlockInfo_3e(ptr %v0, ptr %t66, i64 %t72)
  store %"compiler/typed:BlockInfo" %t75, ptr %l46
  br label %bb19
bb19:
  %t76 = getelementptr %"compiler/typed:BlockInfo", ptr %l46, i32 0, i32 1
  %t77 = load i32, ptr %t76
  store i32 %t77, ptr %l6
  %t79 = load i32, ptr %l6
  %t81 = trunc i64 2 to i32
  %t82 = icmp eq i32 %t79, %t81
  br i1 %t82, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb23
bb22:
  store i32 2, ptr %l48
  br label %bb32
bb23:
  %t85 = load i32, ptr %l6
  %t87 = trunc i64 5 to i32
  %t88 = icmp eq i32 %t85, %t87
  br i1 %t88, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb27
bb26:
  store i32 3, ptr %l48
  br label %bb32
bb27:
  br i1 true, label %bb28, label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb31
bb30:
  store i32 1, ptr %l48
  br label %bb32
bb31:
  call void @__olang_check_failed(ptr @olang_loc_97232cd54c6d63ec_e5d7df8d53aaa998)
  unreachable
bb32:
  %t92 = load i32, ptr %l48
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t94 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eopenBlock(ptr %v0, ptr %v1, ptr %t93, ptr %t94, i32 %t92, i32 0)
  br label %bb33
bb33:
  %t99 = load ptr, ptr %l1, !tbaa !29
  %t101 = getelementptr %"compiler/typed:Block", ptr %t99, i32 0, i32 1
  %t102 = load { i64, ptr }, ptr %t101, !tbaa !27
  store { i64, ptr } %t102, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t104 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t106 = extractvalue { i64, ptr } %t104, 0
  store i64 %t106, ptr %l10, !tbaa !24
  br label %bb34
bb34:
  %t108 = load i64, ptr %l9, !tbaa !24
  %t109 = load i64, ptr %l10, !tbaa !24
  %t112 = icmp slt i64 %t108, %t109
  %t114 = xor i1 %t112, true
  br i1 %t114, label %bb35, label %bb36
bb35:
  br label %bb40
bb36:
  br label %bb37
bb37:
  %t116 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t116, ptr %l67, !tbaa !27
  %t117 = load i64, ptr %l9, !tbaa !24
  %t119 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t120 = load ptr, ptr %t119, !tbaa !27
  %t121 = getelementptr ptr, ptr %t120, i64 %t117
  %t122 = load ptr, ptr %t121, !tbaa !39
  %t124 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estmt(ptr %v0, ptr %v1, ptr %t124, ptr %t122)
  br label %bb38
bb38:
  br label %bb39
bb39:
  %t128 = load i64, ptr %l9, !tbaa !24
  %t130 = add i64 %t128, 1
  store i64 %t130, ptr %l9, !tbaa !24
  br label %bb34
bb40:
  %t132 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ecloseBlock(ptr %v0, ptr %t132)
  br label %bb41
bb41:
  br label %ret
ret:
  ret void
}

define dso_local { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ebuilt(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l5 = alloca i1
  %l8 = alloca i1
  %l18 = alloca { i64, ptr }
  %l22 = alloca { i64, [1 x i64] }
  %rv = alloca { i64, [1 x i64] }
  %t28 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 19
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l5, !tbaa !21
  br label %bb3
bb2:
  %t8 = load i32, ptr %l1, !tbaa !23
  %t10 = icmp slt i32 %t8, 0
  store i1 %t10, ptr %l5, !tbaa !21
  br label %bb3
bb3:
  %t12 = load i1, ptr %l5, !tbaa !21
  br i1 %t12, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb6
bb5:
  %t13 = load i32, ptr %l1, !tbaa !23
  %t15 = sext i32 %t13 to i64
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/lower:lowering", ptr %t16, i32 0, i32 22
  %t19 = getelementptr %"compiler/typed:Plan", ptr %t18, i32 0, i32 0
  %t20 = load { i64, ptr }, ptr %t19, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t20, 0
  %t25 = icmp sge i64 %t15, %t22
  store i1 %t25, ptr %l8, !tbaa !21
  br label %bb6
bb6:
  %t27 = load i1, ptr %l8, !tbaa !21
  br i1 %t27, label %bb7, label %bb8
bb7:
  store { i64, [1 x i64] } zeroinitializer, ptr %t28
  %t29 = getelementptr { i64, [1 x i64] }, ptr %t28, i32 0, i32 0
  store i64 2, ptr %t29
  %t30 = load { i64, [1 x i64] }, ptr %t28
  store { i64, [1 x i64] } %t30, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/lower:lowering", ptr %t33, i32 0, i32 22
  %t36 = getelementptr %"compiler/typed:Plan", ptr %t35, i32 0, i32 0
  %t37 = load { i64, ptr }, ptr %t36, !tbaa !27
  store { i64, ptr } %t37, ptr %l18, !tbaa !27
  %t38 = load i32, ptr %l1, !tbaa !23
  %t40 = sext i32 %t38 to i64
  %t42 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = getelementptr { i64, [1 x i64] }, ptr %t43, i64 %t40
  %t45 = load { i64, [1 x i64] }, ptr %t44
  %t48 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2escopeRef(ptr %v0, ptr %t32, { i64, [1 x i64] } %t45)
  store { i64, [1 x i64] } %t48, ptr %l22
  br label %bb10
bb10:
  %t49 = load { i64, [1 x i64] }, ptr %l22
  store { i64, [1 x i64] } %t49, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [1 x i64] }, ptr %rv
  ret { i64, [1 x i64] } %rr
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ecall(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca { { i64, [7 x i64] }, i32 }
  %l6 = alloca { i64, [7 x i64] }
  %l7 = alloca i32
  %l8 = alloca %"compiler/mir:Range"
  %l9 = alloca i64
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca %"compiler/mir:Range"
  %l13 = alloca i32
  %l14 = alloca i32
  %l15 = alloca i32
  %l16 = alloca i32
  %l17 = alloca i32
  %l23 = alloca i1
  %l33 = alloca { i64, [4 x i64] }
  %l38 = alloca { { i64, [7 x i64] }, i32 }
  %l48 = alloca %"compiler/mir:Range"
  %l60 = alloca { i64, [4 x i64] }
  %l66 = alloca i32
  %l67 = alloca ptr
  %l71 = alloca i64
  %l74 = alloca %"compiler/mir:Range"
  %l77 = alloca i32
  %l82 = alloca i1
  %l86 = alloca ptr
  %l90 = alloca i32
  %l94 = alloca i32
  %l97 = alloca i32
  %l102 = alloca { i64, ptr }
  %l108 = alloca i32
  %l111 = alloca i32
  %l113 = alloca ptr
  %l114 = alloca { i64, [7 x i64] }
  %l115 = alloca %"compiler/mir:Range"
  %l116 = alloca %"compiler/mir:Range"
  %l120 = alloca %"compiler/mir:Place"
  %l122 = alloca %"compiler/mir:Place"
  %l130 = alloca %"compiler/mir:Call"
  %l131 = alloca i32
  %l141 = alloca ptr
  %l143 = alloca %"compiler/mir:Place"
  %l163 = alloca %"compiler/mir:Place"
  %s0 = alloca %olang.scope
  %rv = alloca { i64, [4 x i64] }
  %t56 = alloca { i64, [4 x i64] }, align 8
  %t75 = alloca { i64, [4 x i64] }, align 8
  %t105 = alloca { i64, [7 x i64] }, align 8
  %t253 = alloca { i64, [8 x i64] }, align 8
  %t277 = alloca { i64, [4 x i64] }, align 8
  %t301 = alloca { i64, [4 x i64] }, align 8
  %t304 = alloca { i64, [8 x i64] }, align 8
  %t316 = alloca { i64, [4 x i64] }, align 8
  %t326 = alloca { i64, [4 x i64] }, align 8
  %t333 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = getelementptr %"compiler/typed:Call", ptr %t6, i32 0, i32 4
  %t9 = load i1, ptr %t8, !tbaa !21
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load ptr, ptr %l1, !tbaa !29
  %t13 = getelementptr %"compiler/typed:Call", ptr %t11, i32 0, i32 1
  %t14 = load { i64, ptr }, ptr %t13, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t14, 0
  %t18 = icmp eq i64 %t16, 0
  store i1 %t18, ptr %l23, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb3
bb3:
  %t20 = load i1, ptr %l23, !tbaa !21
  br i1 %t20, label %bb4, label %bb5
bb4:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load i32, ptr %l2, !tbaa !23
  %t23 = load %"compiler/source:Span", ptr %l3
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t26 = getelementptr %"compiler/typed:Call", ptr %t24, i32 0, i32 3
  %t27 = load i32, ptr %t26, !tbaa !23
  %t32 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ezero(ptr %v0, ptr %t21, i32 %t22, %"compiler/source:Span" %t23, i32 %t27)
  store { i64, [4 x i64] } %t32, ptr %l33
  br label %bb6
bb5:
  br label %bb7
bb6:
  call void @__olang_scope_close(ptr %s0)
  %t33 = load { i64, [4 x i64] }, ptr %l33
  store { i64, [4 x i64] } %t33, ptr %rv
  br label %ret
bb7:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load ptr, ptr %l1, !tbaa !29
  %t37 = getelementptr %"compiler/typed:Call", ptr %t35, i32 0, i32 0
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t39 = load %"compiler/source:Span", ptr %l3
  %t43 = call { { i64, [7 x i64] }, i32 } @compiler_2flower_2ecompiler_2flower_3alowering_2ecallee(ptr %v0, ptr %v1, ptr %t34, ptr %t38, %"compiler/source:Span" %t39)
  store { { i64, [7 x i64] }, i32 } %t43, ptr %l38
  br label %bb8
bb8:
  %t44 = load { { i64, [7 x i64] }, i32 }, ptr %l38
  store { { i64, [7 x i64] }, i32 } %t44, ptr %l5
  %t45 = getelementptr { { i64, [7 x i64] }, i32 }, ptr %l5, i32 0, i32 0
  %t46 = load { i64, [7 x i64] }, ptr %t45
  store { i64, [7 x i64] } %t46, ptr %l6
  %t48 = getelementptr { { i64, [7 x i64] }, i32 }, ptr %l5, i32 0, i32 1
  %t49 = load i32, ptr %t48, !tbaa !23
  store i32 %t49, ptr %l7, !tbaa !23
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/lower:lowering", ptr %t51, i32 0, i32 7
  %t54 = load i1, ptr %t53, !tbaa !21
  br i1 %t54, label %bb9, label %bb10
bb9:
  store { i64, [4 x i64] } zeroinitializer, ptr %t56
  %t57 = getelementptr { i64, [4 x i64] }, ptr %t56, i32 0, i32 0
  store i64 0, ptr %t57
  %t58 = load { i64, [4 x i64] }, ptr %t56
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t58, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load ptr, ptr %l1, !tbaa !29
  %t62 = load { i64, [7 x i64] }, ptr %l6
  %t63 = load i32, ptr %l7, !tbaa !23
  %t68 = call %"compiler/mir:Range" @compiler_2flower_2ecompiler_2flower_3alowering_2eargs(ptr %v0, ptr %v1, ptr %t60, ptr %t61, { i64, [7 x i64] } %t62, i32 %t63)
  store %"compiler/mir:Range" %t68, ptr %l48
  br label %bb12
bb12:
  %t69 = load %"compiler/mir:Range", ptr %l48
  store %"compiler/mir:Range" %t69, ptr %l8
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/lower:lowering", ptr %t70, i32 0, i32 7
  %t73 = load i1, ptr %t72, !tbaa !21
  br i1 %t73, label %bb13, label %bb14
bb13:
  store { i64, [4 x i64] } zeroinitializer, ptr %t75
  %t76 = getelementptr { i64, [4 x i64] }, ptr %t75, i32 0, i32 0
  store i64 0, ptr %t76
  %t77 = load { i64, [4 x i64] }, ptr %t75
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t77, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t79 = load { i64, [7 x i64] }, ptr %l6
  %t81 = extractvalue { i64, [7 x i64] } %t79, 0
  %t82 = icmp eq i64 %t81, 3
  br i1 %t82, label %bb16, label %bb17
bb16:
  %t84 = getelementptr { i64, [7 x i64] }, ptr %l6, i32 0, i32 1
  %t85 = getelementptr { { i64, [4 x i64] }, i64, i32 }, ptr %t84, i32 0, i32 1
  %t86 = load i64, ptr %t85
  store i64 %t86, ptr %l9, !tbaa !24
  %t88 = getelementptr { i64, [7 x i64] }, ptr %l6, i32 0, i32 1
  %t89 = getelementptr { { i64, [4 x i64] }, i64, i32 }, ptr %t88, i32 0, i32 2
  %t90 = load i32, ptr %t89
  store i32 %t90, ptr %l10, !tbaa !23
  br label %bb18
bb17:
  br label %bb20
bb18:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/lower:lowering", ptr %t92, i32 0, i32 3
  %t95 = getelementptr %"compiler/mir:Fn", ptr %t94, i32 0, i32 11
  %t96 = getelementptr %"compiler/mir:Range", ptr %l8, i32 0, i32 0
  %t97 = load i32, ptr %t96, !tbaa !23
  %t99 = sext i32 %t97 to i64
  %t102 = call { i64, [4 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2eAt_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %t95, i64 %t99)
  store { i64, [4 x i64] } %t102, ptr %l60
  br label %bb19
bb19:
  %t103 = load i64, ptr %l9, !tbaa !24
  %t104 = load i32, ptr %l10, !tbaa !23
  store { i64, [7 x i64] } zeroinitializer, ptr %t105
  %t106 = getelementptr { i64, [7 x i64] }, ptr %t105, i32 0, i32 0
  store i64 3, ptr %t106
  %t107 = load { i64, [4 x i64] }, ptr %l60
  %t108 = insertvalue { { i64, [4 x i64] }, i64, i32 } undef, { i64, [4 x i64] } %t107, 0
  %t110 = insertvalue { { i64, [4 x i64] }, i64, i32 } %t108, i64 %t103, 1
  %t112 = insertvalue { { i64, [4 x i64] }, i64, i32 } %t110, i32 %t104, 2
  %t113 = getelementptr { i64, [7 x i64] }, ptr %t105, i32 0, i32 1
  store { { i64, [4 x i64] }, i64, i32 } %t112, ptr %t113
  %t114 = load { i64, [7 x i64] }, ptr %t105
  store { i64, [7 x i64] } %t114, ptr %l6
  br label %bb25
bb20:
  br i1 true, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_b0754b7649fd7859_91d9947d7b887e0d)
  unreachable
bb25:
  %t116 = load ptr, ptr %l4, !tbaa !29
  %t117 = load i32, ptr %l7, !tbaa !23
  %t120 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t116, i32 %t117)
  store i32 %t120, ptr %l66
  br label %bb26
bb26:
  %t121 = load i32, ptr %l66, !tbaa !23
  store i32 %t121, ptr %l11, !tbaa !23
  %t122 = load ptr, ptr %l0, !tbaa !29
  store ptr %t122, ptr %l67, !tbaa !29
  %t123 = load ptr, ptr %l4, !tbaa !29
  %t124 = load { i64, [7 x i64] }, ptr %l6
  %t125 = load i32, ptr %l7, !tbaa !23
  %t129 = call i64 @compiler_2fmir_2ePassedCount(ptr %v0, ptr %t123, { i64, [7 x i64] } %t124, i32 %t125)
  store i64 %t129, ptr %l71
  br label %bb27
bb27:
  %t130 = load ptr, ptr %l1, !tbaa !29
  %t132 = getelementptr %"compiler/typed:Call", ptr %t130, i32 0, i32 3
  %t133 = load i32, ptr %t132, !tbaa !23
  %t134 = load ptr, ptr %l67, !tbaa !29
  %t135 = load i64, ptr %l71, !tbaa !24
  %t137 = call %"compiler/mir:Range" @compiler_2flower_2ecompiler_2flower_3alowering_2epassed(ptr %v0, ptr %t134, i64 %t135, i32 %t133)
  store %"compiler/mir:Range" %t137, ptr %l74
  br label %bb28
bb28:
  %t138 = load %"compiler/mir:Range", ptr %l74
  store %"compiler/mir:Range" %t138, ptr %l12
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t141 = getelementptr %"compiler/lower:lowering", ptr %t139, i32 0, i32 3
  %t143 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t141)
  store i32 %t143, ptr %l77
  br label %bb29
bb29:
  %t144 = load i32, ptr %l77, !tbaa !23
  store i32 %t144, ptr %l13, !tbaa !23
  %t145 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  store i32 %t145, ptr %l14, !tbaa !23
  %t147 = load i32, ptr %l11, !tbaa !23
  %t148 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t151 = icmp ne i32 %t147, %t148
  br i1 %t151, label %bb30, label %bb31
bb30:
  %t153 = load i32, ptr %l11, !tbaa !23
  %t154 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t157 = icmp ne i32 %t153, %t154
  store i1 %t157, ptr %l82, !tbaa !21
  br label %bb32
bb31:
  store i1 false, ptr %l82, !tbaa !21
  br label %bb32
bb32:
  %t159 = load i1, ptr %l82, !tbaa !21
  br i1 %t159, label %bb33, label %bb34
bb33:
  %t160 = load ptr, ptr %l0, !tbaa !29
  store ptr %t160, ptr %l86, !tbaa !29
  %t161 = load i32, ptr %l2, !tbaa !23
  %t162 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t165 = icmp ne i32 %t161, %t162
  br i1 %t165, label %bb35, label %bb36
bb34:
  br label %bb39
bb35:
  %t167 = load i32, ptr %l2, !tbaa !23
  store i32 %t167, ptr %l90, !tbaa !23
  br label %bb37
bb36:
  %t169 = load i32, ptr %l11, !tbaa !23
  store i32 %t169, ptr %l90, !tbaa !23
  br label %bb37
bb37:
  %t171 = load %"compiler/source:Span", ptr %l3
  %t172 = load ptr, ptr %l86, !tbaa !29
  %t173 = load i32, ptr %l90, !tbaa !23
  %t175 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etemp(ptr %v0, ptr %t172, i32 %t173, %"compiler/source:Span" %t171)
  store i32 %t175, ptr %l94
  br label %bb38
bb38:
  %t176 = load i32, ptr %l94, !tbaa !23
  store i32 %t176, ptr %l14, !tbaa !23
  br label %bb39
bb39:
  %t177 = load ptr, ptr %l4, !tbaa !29
  %t178 = load i32, ptr %l7, !tbaa !23
  %t181 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t177, i32 %t178)
  store i32 %t181, ptr %l97
  br label %bb40
bb40:
  %t182 = load i32, ptr %l97, !tbaa !23
  store i32 %t182, ptr %l15, !tbaa !23
  %t183 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  store i32 %t183, ptr %l16, !tbaa !23
  %t185 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  store i32 %t185, ptr %l17, !tbaa !23
  %t187 = load ptr, ptr %l4, !tbaa !29
  %t188 = load i32, ptr %l15, !tbaa !23
  %t191 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t187, i32 %t188)
  store { i64, ptr } %t191, ptr %l102
  br label %bb41
bb41:
  %t192 = load { i64, ptr }, ptr %l102, !tbaa !27
  %t193 = extractvalue { i64, ptr } %t192, 0
  %t195 = icmp sgt i64 %t193, 0
  br i1 %t195, label %bb42, label %bb43
bb42:
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t198 = load i32, ptr @G_2ecompiler_2fmir_2eI32T, !tbaa !23
  %t199 = load %"compiler/source:Span", ptr %l3
  %t203 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etemp(ptr %v0, ptr %t197, i32 %t198, %"compiler/source:Span" %t199)
  store i32 %t203, ptr %l108
  br label %bb44
bb43:
  br label %bb46
bb44:
  %t204 = load i32, ptr %l108, !tbaa !23
  store i32 %t204, ptr %l16, !tbaa !23
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t207 = getelementptr %"compiler/lower:lowering", ptr %t205, i32 0, i32 3
  %t209 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t207)
  store i32 %t209, ptr %l111
  br label %bb45
bb45:
  %t210 = load i32, ptr %l111, !tbaa !23
  store i32 %t210, ptr %l17, !tbaa !23
  br label %bb46
bb46:
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t213 = getelementptr %"compiler/lower:lowering", ptr %t211, i32 0, i32 3
  store ptr %t213, ptr %l113, !tbaa !29
  %t214 = load { i64, [7 x i64] }, ptr %l6
  store { i64, [7 x i64] } %t214, ptr %l114
  %t215 = load %"compiler/mir:Range", ptr %l8
  store %"compiler/mir:Range" %t215, ptr %l115
  %t216 = load %"compiler/mir:Range", ptr %l12
  store %"compiler/mir:Range" %t216, ptr %l116
  %t217 = load i32, ptr %l14, !tbaa !23
  %t218 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  %t221 = icmp ne i32 %t217, %t218
  br i1 %t221, label %bb47, label %bb48
bb47:
  %t223 = load i32, ptr %l14, !tbaa !23
  %t225 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t223)
  store %"compiler/mir:Place" %t225, ptr %l122
  br label %bb49
bb48:
  %t226 = load %"compiler/mir:Place", ptr @G_2ecompiler_2fmir_2eNoPlace
  store %"compiler/mir:Place" %t226, ptr %l120
  br label %bb50
bb49:
  %t228 = load %"compiler/mir:Place", ptr %l122
  store %"compiler/mir:Place" %t228, ptr %l120
  br label %bb50
bb50:
  %t229 = load i32, ptr %l14, !tbaa !23
  %t230 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  %t233 = icmp ne i32 %t229, %t230
  %t234 = load i32, ptr %l13, !tbaa !23
  %t235 = load i32, ptr %l16, !tbaa !23
  %t236 = load i32, ptr %l17, !tbaa !23
  %t237 = load { i64, [7 x i64] }, ptr %l114
  %t238 = load %"compiler/mir:Range", ptr %l115
  %t239 = load %"compiler/mir:Range", ptr %l116
  %t240 = load %"compiler/mir:Place", ptr %l120
  %t245 = call %"compiler/mir:Call" @compiler_2fmir_3aCall_2ector(ptr %s0, { i64, [7 x i64] } %t237, %"compiler/mir:Range" %t238, %"compiler/mir:Range" %t239, %"compiler/mir:Place" %t240, i1 %t233, i32 %t234, i32 %t235, i32 %t236)
  store %"compiler/mir:Call" %t245, ptr %l130
  br label %bb51
bb51:
  %t246 = load ptr, ptr %l113, !tbaa !29
  %t247 = load %"compiler/mir:Call", ptr %l130
  %t248 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddCall(ptr %v0, ptr %t246, %"compiler/mir:Call" %t247)
  store i32 %t248, ptr %l131
  br label %bb52
bb52:
  %t249 = load i32, ptr %l131, !tbaa !23
  %t250 = load ptr, ptr %l0, !tbaa !29
  %t251 = load %"compiler/source:Span", ptr %l3
  store { i64, [8 x i64] } zeroinitializer, ptr %t253
  %t254 = getelementptr { i64, [8 x i64] }, ptr %t253, i32 0, i32 0
  store i64 4, ptr %t254
  %t256 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t251, 0
  %t258 = insertvalue { %"compiler/source:Span", i32 } %t256, i32 %t249, 1
  %t259 = getelementptr { i64, [8 x i64] }, ptr %t253, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t258, ptr %t259
  %t260 = load { i64, [8 x i64] }, ptr %t253
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t250, { i64, [8 x i64] } %t260)
  br label %bb53
bb53:
  %t263 = load i32, ptr %l17, !tbaa !23
  %t264 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t267 = icmp ne i32 %t263, %t264
  br i1 %t267, label %bb54, label %bb55
bb54:
  %t269 = load ptr, ptr %l0, !tbaa !29
  %t270 = load i32, ptr %l17, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t269, i32 %t270)
  br label %bb56
bb55:
  br label %bb59
bb56:
  %t273 = load ptr, ptr %l0, !tbaa !29
  store ptr %t273, ptr %l141, !tbaa !29
  %t274 = load i32, ptr %l16, !tbaa !23
  %t276 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t274)
  store %"compiler/mir:Place" %t276, ptr %l143
  br label %bb57
bb57:
  store { i64, [4 x i64] } zeroinitializer, ptr %t277
  %t278 = getelementptr { i64, [4 x i64] }, ptr %t277, i32 0, i32 0
  store i64 1, ptr %t278
  %t279 = load %"compiler/mir:Place", ptr %l143
  %t280 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t279, 0
  %t281 = getelementptr { i64, [4 x i64] }, ptr %t277, i32 0, i32 1
  store { %"compiler/mir:Place" } %t280, ptr %t281
  %t282 = load { i64, [4 x i64] }, ptr %t277
  %t283 = load i32, ptr %l15, !tbaa !23
  %t284 = load %"compiler/source:Span", ptr %l3
  %t285 = load ptr, ptr %l141, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2edispatch(ptr %v0, ptr %t285, { i64, [4 x i64] } %t282, i32 %t283, %"compiler/source:Span" %t284, i1 false)
  br label %bb58
bb58:
  br label %bb59
bb59:
  %t289 = load ptr, ptr %l0, !tbaa !29
  %t290 = load i32, ptr %l13, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t289, i32 %t290)
  br label %bb60
bb60:
  %t293 = load i32, ptr %l11, !tbaa !23
  %t294 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t297 = icmp eq i32 %t293, %t294
  br i1 %t297, label %bb61, label %bb62
bb61:
  %t299 = load ptr, ptr %l0, !tbaa !29
  %t300 = load %"compiler/source:Span", ptr %l3
  store { i64, [4 x i64] } zeroinitializer, ptr %t301
  %t302 = getelementptr { i64, [4 x i64] }, ptr %t301, i32 0, i32 0
  store i64 0, ptr %t302
  %t303 = load { i64, [4 x i64] }, ptr %t301
  store { i64, [8 x i64] } zeroinitializer, ptr %t304
  %t305 = getelementptr { i64, [8 x i64] }, ptr %t304, i32 0, i32 0
  store i64 8, ptr %t305
  %t307 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } undef, %"compiler/source:Span" %t300, 0
  %t309 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t307, i32 3, 1
  %t311 = insertvalue { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t309, { i64, [4 x i64] } %t303, 2
  %t312 = getelementptr { i64, [8 x i64] }, ptr %t304, i32 0, i32 1
  store { %"compiler/source:Span", i32, { i64, [4 x i64] } } %t311, ptr %t312
  %t313 = load { i64, [8 x i64] }, ptr %t304
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t299, { i64, [8 x i64] } %t313)
  br label %bb63
bb62:
  br label %bb64
bb63:
  store { i64, [4 x i64] } zeroinitializer, ptr %t316
  %t317 = getelementptr { i64, [4 x i64] }, ptr %t316, i32 0, i32 0
  store i64 0, ptr %t317
  %t318 = load { i64, [4 x i64] }, ptr %t316
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t318, ptr %rv
  br label %ret
bb64:
  %t320 = load i32, ptr %l14, !tbaa !23
  %t321 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  %t324 = icmp eq i32 %t320, %t321
  br i1 %t324, label %bb65, label %bb66
bb65:
  store { i64, [4 x i64] } zeroinitializer, ptr %t326
  %t327 = getelementptr { i64, [4 x i64] }, ptr %t326, i32 0, i32 0
  store i64 0, ptr %t327
  %t328 = load { i64, [4 x i64] }, ptr %t326
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t328, ptr %rv
  br label %ret
bb66:
  br label %bb67
bb67:
  %t330 = load i32, ptr %l14, !tbaa !23
  %t332 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t330)
  store %"compiler/mir:Place" %t332, ptr %l163
  br label %bb68
bb68:
  store { i64, [4 x i64] } zeroinitializer, ptr %t333
  %t334 = getelementptr { i64, [4 x i64] }, ptr %t333, i32 0, i32 0
  store i64 1, ptr %t334
  %t335 = load %"compiler/mir:Place", ptr %l163
  %t336 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t335, 0
  %t337 = getelementptr { i64, [4 x i64] }, ptr %t333, i32 0, i32 1
  store { %"compiler/mir:Place" } %t336, ptr %t337
  %t338 = load { i64, [4 x i64] }, ptr %t333
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t338, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local { { i64, [7 x i64] }, i32 } @compiler_2flower_2ecompiler_2flower_3alowering_2ecallee(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i64
  %l10 = alloca i32
  %l11 = alloca ptr
  %l12 = alloca i1
  %l19 = alloca { { i64, [7 x i64] }, i32 }
  %l20 = alloca ptr
  %l21 = alloca i1
  %l30 = alloca i32
  %l36 = alloca ptr
  %l37 = alloca i1
  %l44 = alloca { { i64, [7 x i64] }, i32 }
  %l45 = alloca ptr
  %l46 = alloca i1
  %l56 = alloca { { i64, [7 x i64] }, i32 }
  %l57 = alloca ptr
  %l58 = alloca i1
  %rv = alloca { { i64, [7 x i64] }, i32 }
  %t51 = alloca { i64, [7 x i64] }, align 8
  %t136 = alloca { i64, [4 x i64] }, align 8
  %t141 = alloca { i64, [7 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t2 = load ptr, ptr %l11, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l11, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l12, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l12, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [3 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { i32 }, ptr %t12, i32 0, i32 0
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l3, !tbaa !23
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load i32, ptr %l3, !tbaa !23
  %t20 = call { { i64, [7 x i64] }, i32 } @compiler_2flower_2ecompiler_2flower_3alowering_2ebodyCallee(ptr %v0, ptr %t16, i32 %t17)
  store { { i64, [7 x i64] }, i32 } %t20, ptr %l19
  br label %bb6
bb6:
  %t21 = load { { i64, [7 x i64] }, i32 }, ptr %l19
  store { { i64, [7 x i64] }, i32 } %t21, ptr %rv
  br label %ret
bb7:
  %t22 = load ptr, ptr %l1, !tbaa !29
  store ptr %t22, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t23 = load ptr, ptr %l20, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t26 = load ptr, ptr %l20, !tbaa !29
  %t27 = load i64, ptr %t26
  %t29 = icmp eq i64 %t27, 1
  store i1 %t29, ptr %l21, !tbaa !21
  br label %bb9
bb9:
  %t30 = load i1, ptr %l21, !tbaa !21
  br i1 %t30, label %bb10, label %bb11
bb10:
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr { i64, [3 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { i64 }, ptr %t33, i32 0, i32 0
  %t35 = load i64, ptr %t34
  store i64 %t35, ptr %l4, !tbaa !24
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/lower:lowering", ptr %t37, i32 0, i32 0
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t42 = getelementptr %"compiler/lower:Lowerer", ptr %t40, i32 0, i32 0
  %t43 = load ptr, ptr %t42, !tbaa !29
  %t44 = load i64, ptr %l4, !tbaa !24
  %t47 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t43, i64 %t44)
  store i32 %t47, ptr %l30
  br label %bb13
bb13:
  %t48 = load i32, ptr %l30, !tbaa !23
  store i32 %t48, ptr %l5, !tbaa !23
  %t49 = load i64, ptr %l4, !tbaa !24
  %t50 = load i32, ptr %l5, !tbaa !23
  store { i64, [7 x i64] } zeroinitializer, ptr %t51
  %t52 = getelementptr { i64, [7 x i64] }, ptr %t51, i32 0, i32 0
  store i64 1, ptr %t52
  %t54 = insertvalue { i64, i32 } undef, i64 %t49, 0
  %t56 = insertvalue { i64, i32 } %t54, i32 %t50, 1
  %t57 = getelementptr { i64, [7 x i64] }, ptr %t51, i32 0, i32 1
  store { i64, i32 } %t56, ptr %t57
  %t58 = load { i64, [7 x i64] }, ptr %t51
  %t59 = load i32, ptr %l5, !tbaa !23
  %t61 = insertvalue { { i64, [7 x i64] }, i32 } undef, { i64, [7 x i64] } %t58, 0
  %t63 = insertvalue { { i64, [7 x i64] }, i32 } %t61, i32 %t59, 1
  store { { i64, [7 x i64] }, i32 } %t63, ptr %rv
  br label %ret
bb14:
  %t65 = load ptr, ptr %l1, !tbaa !29
  store ptr %t65, ptr %l36, !tbaa !29
  store i1 false, ptr %l37, !tbaa !21
  %t66 = load ptr, ptr %l36, !tbaa !29
  %t67 = icmp ne ptr %t66, null
  br i1 %t67, label %bb15, label %bb16
bb15:
  %t69 = load ptr, ptr %l36, !tbaa !29
  %t70 = load i64, ptr %t69
  %t72 = icmp eq i64 %t70, 2
  store i1 %t72, ptr %l37, !tbaa !21
  br label %bb16
bb16:
  %t73 = load i1, ptr %l37, !tbaa !21
  br i1 %t73, label %bb17, label %bb18
bb17:
  %t74 = load ptr, ptr %l1, !tbaa !29
  %t76 = getelementptr { i64, [3 x i64] }, ptr %t74, i32 0, i32 1
  %t77 = getelementptr { ptr }, ptr %t76, i32 0, i32 0
  %t78 = load ptr, ptr %t77
  store ptr %t78, ptr %l6, !tbaa !29
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load ptr, ptr %l6, !tbaa !29
  %t84 = call { { i64, [7 x i64] }, i32 } @compiler_2flower_2ecompiler_2flower_3alowering_2evalueCallee(ptr %v0, ptr %v1, ptr %t80, ptr %t81)
  store { { i64, [7 x i64] }, i32 } %t84, ptr %l44
  br label %bb20
bb20:
  %t85 = load { { i64, [7 x i64] }, i32 }, ptr %l44
  store { { i64, [7 x i64] }, i32 } %t85, ptr %rv
  br label %ret
bb21:
  %t86 = load ptr, ptr %l1, !tbaa !29
  store ptr %t86, ptr %l45, !tbaa !29
  store i1 false, ptr %l46, !tbaa !21
  %t87 = load ptr, ptr %l45, !tbaa !29
  %t88 = icmp ne ptr %t87, null
  br i1 %t88, label %bb22, label %bb23
bb22:
  %t90 = load ptr, ptr %l45, !tbaa !29
  %t91 = load i64, ptr %t90
  %t93 = icmp eq i64 %t91, 4
  store i1 %t93, ptr %l46, !tbaa !21
  br label %bb23
bb23:
  %t94 = load i1, ptr %l46, !tbaa !21
  br i1 %t94, label %bb24, label %bb25
bb24:
  %t95 = load ptr, ptr %l1, !tbaa !29
  %t97 = getelementptr { i64, [3 x i64] }, ptr %t95, i32 0, i32 1
  %t98 = getelementptr { i32, i32 }, ptr %t97, i32 0, i32 0
  %t99 = load i32, ptr %t98
  store i32 %t99, ptr %l7
  %t101 = load ptr, ptr %l1, !tbaa !29
  %t103 = getelementptr { i64, [3 x i64] }, ptr %t101, i32 0, i32 1
  %t104 = getelementptr { i32, i32 }, ptr %t103, i32 0, i32 1
  %t105 = load i32, ptr %t104
  store i32 %t105, ptr %l8, !tbaa !23
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t108 = load i32, ptr %l7
  %t109 = load i32, ptr %l8, !tbaa !23
  %t113 = call { { i64, [7 x i64] }, i32 } @compiler_2flower_2ecompiler_2flower_3alowering_2ehelperCallee(ptr %v0, ptr %t107, i32 %t108, i32 %t109)
  store { { i64, [7 x i64] }, i32 } %t113, ptr %l56
  br label %bb27
bb27:
  %t114 = load { { i64, [7 x i64] }, i32 }, ptr %l56
  store { { i64, [7 x i64] }, i32 } %t114, ptr %rv
  br label %ret
bb28:
  %t115 = load ptr, ptr %l1, !tbaa !29
  store ptr %t115, ptr %l57, !tbaa !29
  store i1 false, ptr %l58, !tbaa !21
  %t116 = load ptr, ptr %l57, !tbaa !29
  %t117 = icmp ne ptr %t116, null
  br i1 %t117, label %bb29, label %bb30
bb29:
  %t119 = load ptr, ptr %l57, !tbaa !29
  %t120 = load i64, ptr %t119
  %t122 = icmp eq i64 %t120, 3
  store i1 %t122, ptr %l58, !tbaa !21
  br label %bb30
bb30:
  %t123 = load i1, ptr %l58, !tbaa !21
  br i1 %t123, label %bb31, label %bb32
bb31:
  %t124 = load ptr, ptr %l1, !tbaa !29
  %t126 = getelementptr { i64, [3 x i64] }, ptr %t124, i32 0, i32 1
  %t127 = getelementptr { i32, i64, i32 }, ptr %t126, i32 0, i32 1
  %t128 = load i64, ptr %t127
  store i64 %t128, ptr %l9, !tbaa !24
  %t130 = load ptr, ptr %l1, !tbaa !29
  %t132 = getelementptr { i64, [3 x i64] }, ptr %t130, i32 0, i32 1
  %t133 = getelementptr { i32, i64, i32 }, ptr %t132, i32 0, i32 2
  %t134 = load i32, ptr %t133
  store i32 %t134, ptr %l10, !tbaa !23
  br label %bb33
bb32:
  br label %bb34
bb33:
  store { i64, [4 x i64] } zeroinitializer, ptr %t136
  %t137 = getelementptr { i64, [4 x i64] }, ptr %t136, i32 0, i32 0
  store i64 0, ptr %t137
  %t138 = load { i64, [4 x i64] }, ptr %t136
  %t139 = load i64, ptr %l9, !tbaa !24
  %t140 = load i32, ptr %l10, !tbaa !23
  store { i64, [7 x i64] } zeroinitializer, ptr %t141
  %t142 = getelementptr { i64, [7 x i64] }, ptr %t141, i32 0, i32 0
  store i64 3, ptr %t142
  %t144 = insertvalue { { i64, [4 x i64] }, i64, i32 } undef, { i64, [4 x i64] } %t138, 0
  %t146 = insertvalue { { i64, [4 x i64] }, i64, i32 } %t144, i64 %t139, 1
  %t148 = insertvalue { { i64, [4 x i64] }, i64, i32 } %t146, i32 %t140, 2
  %t149 = getelementptr { i64, [7 x i64] }, ptr %t141, i32 0, i32 1
  store { { i64, [4 x i64] }, i64, i32 } %t148, ptr %t149
  %t150 = load { i64, [7 x i64] }, ptr %t141
  %t151 = load i32, ptr %l10, !tbaa !23
  %t153 = insertvalue { { i64, [7 x i64] }, i32 } undef, { i64, [7 x i64] } %t150, 0
  %t155 = insertvalue { { i64, [7 x i64] }, i32 } %t153, i32 %t151, 1
  store { { i64, [7 x i64] }, i32 } %t155, ptr %rv
  br label %ret
bb34:
  call void @__olang_check_failed(ptr @olang_loc_21e9da82ebd620c7_b6074e807b9f75fb)
  unreachable
ret:
  %rr = load { { i64, [7 x i64] }, i32 }, ptr %rv
  ret { { i64, [7 x i64] }, i32 } %rr
}

define dso_local %"compiler/mir:Range" @compiler_2flower_2ecompiler_2flower_3alowering_2ecapScopes(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l3 = alloca i64
  %l7 = alloca i1
  %l10 = alloca i1
  %l18 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l23 = alloca { i64, [1 x i64] }
  %l28 = alloca ptr
  %l29 = alloca ptr
  %l34 = alloca { i64, [1 x i64] }
  %l35 = alloca { i64, [1 x i64] }
  %l39 = alloca ptr
  %l41 = alloca { i64, ptr }
  %l42 = alloca %"compiler/mir:Range"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/mir:Range"
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 19
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb3
bb2:
  %t8 = load i32, ptr %l1, !tbaa !23
  %t10 = icmp slt i32 %t8, 0
  store i1 %t10, ptr %l7, !tbaa !21
  br label %bb3
bb3:
  %t12 = load i1, ptr %l7, !tbaa !21
  br i1 %t12, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb6
bb5:
  %t13 = load i32, ptr %l1, !tbaa !23
  %t15 = sext i32 %t13 to i64
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/lower:lowering", ptr %t16, i32 0, i32 22
  %t19 = getelementptr %"compiler/typed:Plan", ptr %t18, i32 0, i32 0
  %t20 = load { i64, ptr }, ptr %t19, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t20, 0
  %t25 = icmp sge i64 %t15, %t22
  store i1 %t25, ptr %l10, !tbaa !21
  br label %bb6
bb6:
  %t27 = load i1, ptr %l10, !tbaa !21
  br i1 %t27, label %bb7, label %bb8
bb7:
  %t28 = load %"compiler/mir:Range", ptr @G_2ecompiler_2fmir_2eEmpty
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/mir:Range" %t28, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t30 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t30, ptr %l18
  br label %bb10
bb10:
  %t31 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l18
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t31, ptr %l2
  store i64 0, ptr %l3, !tbaa !24
  br label %bb11
bb11:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/lower:lowering", ptr %t32, i32 0, i32 22
  %t35 = load i32, ptr %l1, !tbaa !23
  %t36 = load i64, ptr %l3, !tbaa !24
  %t40 = call { i64, [1 x i64] } @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2ePassed(ptr %v0, ptr %t34, i32 %t35, i64 %t36)
  store { i64, [1 x i64] } %t40, ptr %l23
  br label %bb12
bb12:
  %t41 = load { i64, [1 x i64] }, ptr %l23
  %t43 = extractvalue { i64, [1 x i64] } %t41, 0
  %t44 = icmp eq i64 %t43, 0
  %t46 = xor i1 %t44, true
  %t48 = xor i1 %t46, true
  br i1 %t48, label %bb13, label %bb14
bb13:
  br label %bb20
bb14:
  br label %bb15
bb15:
  store ptr %l2, ptr %l28, !tbaa !29
  %t50 = load ptr, ptr %l0, !tbaa !29
  store ptr %t50, ptr %l29, !tbaa !29
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/lower:lowering", ptr %t51, i32 0, i32 22
  %t54 = load i32, ptr %l1, !tbaa !23
  %t55 = load i64, ptr %l3, !tbaa !24
  %t59 = call { i64, [1 x i64] } @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2ePassed(ptr %v0, ptr %t53, i32 %t54, i64 %t55)
  store { i64, [1 x i64] } %t59, ptr %l34
  br label %bb16
bb16:
  %t60 = load ptr, ptr %l29, !tbaa !29
  %t61 = load { i64, [1 x i64] }, ptr %l34
  %t62 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2escopeRef(ptr %v0, ptr %t60, { i64, [1 x i64] } %t61)
  store { i64, [1 x i64] } %t62, ptr %l35
  br label %bb17
bb17:
  %t63 = load ptr, ptr %l28, !tbaa !29
  %t64 = load { i64, [1 x i64] }, ptr %l35
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e_2ePush_3ccompiler_2fmir_3aScopeRef_3e(ptr %s0, ptr %t63, { i64, [1 x i64] } %t64)
  br label %bb18
bb18:
  br label %bb19
bb19:
  %t65 = load i64, ptr %l3, !tbaa !24
  %t67 = add i64 %t65, 1
  store i64 %t67, ptr %l3, !tbaa !24
  br label %bb11
bb20:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/lower:lowering", ptr %t69, i32 0, i32 3
  store ptr %t71, ptr %l39, !tbaa !29
  %t73 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e_2eToArray_3ccompiler_2fmir_3aScopeRef_3e(ptr %s0, ptr %s0, ptr %l2)
  store { i64, ptr } %t73, ptr %l41
  br label %bb21
bb21:
  %t74 = load ptr, ptr %l39, !tbaa !29
  %t75 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t76 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eScopeRefs(ptr %v0, ptr %s0, ptr %t74, { i64, ptr } %t75)
  store %"compiler/mir:Range" %t76, ptr %l42
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s0)
  %t77 = load %"compiler/mir:Range", ptr %l42
  store %"compiler/mir:Range" %t77, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/mir:Range", ptr %rv
  ret %"compiler/mir:Range" %rr
}

define dso_local { { i64, ptr }, i1 } @compiler_2flower_2ecompiler_2flower_3alowering_2ecasesOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l8 = alloca i32
  %l11 = alloca i32
  %l14 = alloca ptr
  %l17 = alloca i32
  %l18 = alloca { i64, ptr }
  %l22 = alloca i32
  %l25 = alloca i1
  %l26 = alloca ptr
  %l29 = alloca i32
  %l30 = alloca i32
  %l33 = alloca i1
  %l36 = alloca i1
  %l37 = alloca ptr
  %l40 = alloca i32
  %l41 = alloca { i64, ptr }
  %rv = alloca { { i64, ptr }, i1 }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t6, i32 %a1)
  store i32 %t10, ptr %l8
  br label %bb1
bb1:
  %t11 = load i32, ptr %l8, !tbaa !23
  store i32 %t11, ptr %l3, !tbaa !23
  %t12 = load ptr, ptr %l2, !tbaa !29
  %t13 = load i32, ptr %l3, !tbaa !23
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t16, ptr %l11
  br label %bb2
bb2:
  %t17 = load i32, ptr %l11
  %t19 = trunc i64 24 to i32
  %t20 = icmp eq i32 %t17, %t19
  br i1 %t20, label %bb3, label %bb4
bb3:
  %t22 = load ptr, ptr %l0, !tbaa !29
  store ptr %t22, ptr %l14, !tbaa !29
  %t23 = load ptr, ptr %l2, !tbaa !29
  %t24 = load i32, ptr %l3, !tbaa !23
  %t27 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %t23, i32 %t24)
  store i32 %t27, ptr %l17
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t28 = load ptr, ptr %l14, !tbaa !29
  %t29 = load i32, ptr %l17, !tbaa !23
  %t30 = call { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2eitems(ptr %v0, ptr %v1, ptr %t28, i32 %t29)
  store { i64, ptr } %t30, ptr %l18
  br label %bb6
bb6:
  %t31 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t32 = insertvalue { { i64, ptr }, i1 } undef, { i64, ptr } %t31, 0
  %t33 = insertvalue { { i64, ptr }, i1 } %t32, i1 true, 1
  store { { i64, ptr }, i1 } %t33, ptr %rv
  br label %ret
bb7:
  %t35 = load ptr, ptr %l2, !tbaa !29
  %t36 = load i32, ptr %l3, !tbaa !23
  %t39 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t35, i32 %t36)
  store i32 %t39, ptr %l22
  br label %bb8
bb8:
  %t40 = load i32, ptr %l22
  %t42 = trunc i64 18 to i32
  %t43 = icmp eq i32 %t40, %t42
  br i1 %t43, label %bb9, label %bb10
bb9:
  %t45 = load ptr, ptr %l2, !tbaa !29
  store ptr %t45, ptr %l26, !tbaa !29
  %t46 = load ptr, ptr %l2, !tbaa !29
  %t47 = load i32, ptr %l3, !tbaa !23
  %t50 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t46, i32 %t47)
  store i32 %t50, ptr %l29
  br label %bb11
bb10:
  store i1 false, ptr %l25, !tbaa !21
  br label %bb13
bb11:
  %t51 = load ptr, ptr %l26, !tbaa !29
  %t52 = load i32, ptr %l29, !tbaa !23
  %t53 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t51, i32 %t52)
  store i32 %t53, ptr %l30
  br label %bb12
bb12:
  %t54 = load i32, ptr %l30
  %t56 = trunc i64 1 to i32
  %t57 = icmp eq i32 %t54, %t56
  store i1 %t57, ptr %l25, !tbaa !21
  br label %bb13
bb13:
  %t59 = load i1, ptr %l25, !tbaa !21
  br i1 %t59, label %bb14, label %bb15
bb14:
  %t60 = load ptr, ptr %l2, !tbaa !29
  %t61 = load i32, ptr %l3, !tbaa !23
  %t64 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t60, i32 %t61)
  store i1 %t64, ptr %l36
  br label %bb16
bb15:
  store i1 false, ptr %l33, !tbaa !21
  br label %bb17
bb16:
  %t65 = load i1, ptr %l36, !tbaa !21
  store i1 %t65, ptr %l33, !tbaa !21
  br label %bb17
bb17:
  %t66 = load i1, ptr %l33, !tbaa !21
  br i1 %t66, label %bb18, label %bb19
bb18:
  %t67 = load ptr, ptr %l0, !tbaa !29
  store ptr %t67, ptr %l37, !tbaa !29
  %t68 = load ptr, ptr %l2, !tbaa !29
  %t69 = load i32, ptr %l3, !tbaa !23
  %t72 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t68, i32 %t69)
  store i32 %t72, ptr %l40
  br label %bb20
bb19:
  br label %bb22
bb20:
  %t73 = load ptr, ptr %l37, !tbaa !29
  %t74 = load i32, ptr %l40, !tbaa !23
  %t75 = call { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2eitems(ptr %v0, ptr %v1, ptr %t73, i32 %t74)
  store { i64, ptr } %t75, ptr %l41
  br label %bb21
bb21:
  %t76 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t77 = insertvalue { { i64, ptr }, i1 } undef, { i64, ptr } %t76, 0
  %t78 = insertvalue { { i64, ptr }, i1 } %t77, i1 true, 1
  store { { i64, ptr }, i1 } %t78, ptr %rv
  br label %ret
bb22:
  %t80 = icmp sge i64 0, 0
  br i1 %t80, label %bb23, label %bb24
bb23:
  %t82 = icmp sle i64 0, 2305843009213693951
  br i1 %t82, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_3b8f4ce72bb8c828_c6f22e3cb9711da4)
  unreachable
bb25:
  %t84 = mul i64 0, 4
  %t85 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t84)
  %t86 = insertvalue { i64, ptr } undef, i64 0, 0
  %t87 = insertvalue { i64, ptr } %t86, ptr %t85, 1
  %t89 = insertvalue { { i64, ptr }, i1 } undef, { i64, ptr } %t87, 0
  %t90 = insertvalue { { i64, ptr }, i1 } %t89, i1 false, 1
  store { { i64, ptr }, i1 } %t90, ptr %rv
  br label %ret
bb26:
  call void @__olang_check_failed(ptr @olang_loc_3b8f4ce72bb8c828_c6f22e3cb9711da4)
  unreachable
ret:
  %rr = load { { i64, ptr }, i1 }, ptr %rv
  ret { { i64, ptr }, i1 } %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2eclauses(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/lower:tryCtx" %a1, { i64, ptr } %a2, i32 %a3, i32 %a4, ptr %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/lower:tryCtx"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i32
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca { i64, [4 x i64] }
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l26 = alloca i64
  %l29 = alloca i64
  %l49 = alloca i32
  %l52 = alloca { i64, ptr }
  %l55 = alloca ptr
  %l58 = alloca i32
  %l60 = alloca ptr
  %l63 = alloca i32
  %l68 = alloca ptr
  %l77 = alloca i1
  %l81 = alloca i1
  %l92 = alloca { i64, ptr }
  %l95 = alloca { i64, [4 x i64] }
  %l96 = alloca ptr
  %l98 = alloca %"compiler/source:Span"
  %l100 = alloca %"compiler/mir:Place"
  %l107 = alloca i64
  %l117 = alloca i64
  %l120 = alloca i64
  %l138 = alloca i64
  %l141 = alloca { i64, ptr }
  %l145 = alloca { i64, [4 x i64] }
  %l148 = alloca ptr
  %l150 = alloca %"compiler/source:Span"
  %l152 = alloca %"compiler/mir:Place"
  %l153 = alloca i32
  %l157 = alloca %"compiler/mir:Range"
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %t176 = alloca { i64, [15 x i64] }, align 8
  %t182 = alloca { i64, [21 x i64] }, align 8
  %t299 = alloca { i64, [15 x i64] }, align 8
  %t308 = alloca { i64, [21 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/lower:tryCtx" %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l6, !tbaa !24
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t5 = load i64, ptr %l7, !tbaa !24
  %t6 = load i64, ptr %l6, !tbaa !24
  %t9 = icmp sgt i64 %t5, %t6
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load i64, ptr %l8, !tbaa !24
  %t13 = icmp sgt i64 %t11, 0
  br i1 %t13, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l26, !tbaa !24
  br label %bb6
bb3:
  %t15 = load i64, ptr %l7, !tbaa !24
  %t16 = load i64, ptr %l6, !tbaa !24
  %t19 = sub i64 %t15, %t16
  %t20 = load i64, ptr %l8, !tbaa !24
  %t23 = add i64 %t19, %t20
  %t25 = sub i64 %t23, 1
  %t26 = load i64, ptr %l8, !tbaa !24
  %t29 = sdiv i64 %t25, %t26
  store i64 %t29, ptr %l29, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l29, !tbaa !24
  br label %bb5
bb5:
  %t31 = load i64, ptr %l29, !tbaa !24
  store i64 %t31, ptr %l26, !tbaa !24
  br label %bb6
bb6:
  %t32 = load i64, ptr %l26, !tbaa !24
  store i64 %t32, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb7
bb7:
  %t33 = load i64, ptr %l10, !tbaa !24
  %t34 = load i64, ptr %l9, !tbaa !24
  %t37 = icmp slt i64 %t33, %t34
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb8, label %bb9
bb8:
  br label %bb63
bb9:
  br label %bb10
bb10:
  %t41 = load i64, ptr %l6, !tbaa !24
  %t42 = load i64, ptr %l10, !tbaa !24
  %t43 = load i64, ptr %l8, !tbaa !24
  %t46 = mul i64 %t42, %t43
  %t49 = add i64 %t41, %t46
  store i64 %t49, ptr %l11, !tbaa !24
  %t51 = getelementptr %"compiler/lower:tryCtx", ptr %l1, i32 0, i32 4
  %t52 = load i64, ptr %l11, !tbaa !24
  %t55 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2eAt_3ccompiler_2fmir_3aBlockId_3e(ptr %v1, ptr %t51, i64 %t52)
  store i32 %t55, ptr %l49
  br label %bb11
bb11:
  %t56 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t57 = load i32, ptr %l49, !tbaa !23
  %t59 = icmp eq i32 %t57, %t56
  br i1 %t59, label %bb12, label %bb13
bb12:
  br label %bb62
bb13:
  br label %bb14
bb14:
  %t61 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t61, ptr %l52, !tbaa !27
  %t62 = load i64, ptr %l11, !tbaa !24
  %t64 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !27
  %t66 = getelementptr ptr, ptr %t65, i64 %t62
  %t67 = load ptr, ptr %t66, !tbaa !39
  store ptr %t67, ptr %l12, !tbaa !29
  %t69 = load ptr, ptr %l0, !tbaa !29
  store ptr %t69, ptr %l55, !tbaa !29
  %t70 = getelementptr %"compiler/lower:tryCtx", ptr %l1, i32 0, i32 4
  %t71 = load i64, ptr %l11, !tbaa !24
  %t74 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2eAt_3ccompiler_2fmir_3aBlockId_3e(ptr %v1, ptr %t70, i64 %t71)
  store i32 %t74, ptr %l58
  br label %bb15
bb15:
  %t75 = load ptr, ptr %l55, !tbaa !29
  %t76 = load i32, ptr %l58, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t75, i32 %t76)
  br label %bb16
bb16:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/lower:lowering", ptr %t77, i32 0, i32 3
  %t80 = getelementptr %"compiler/mir:Fn", ptr %t79, i32 0, i32 22
  store ptr %t80, ptr %l60, !tbaa !29
  %t81 = getelementptr %"compiler/lower:tryCtx", ptr %l1, i32 0, i32 4
  %t82 = load i64, ptr %l11, !tbaa !24
  %t85 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2eAt_3ccompiler_2fmir_3aBlockId_3e(ptr %v1, ptr %t81, i64 %t82)
  store i32 %t85, ptr %l63
  br label %bb17
bb17:
  %t86 = load ptr, ptr %l60, !tbaa !29
  %t87 = load i32, ptr %l63, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2ePush_3ccompiler_2fmir_3aBlockId_3e(ptr %v0, ptr %t86, i32 %t87)
  br label %bb18
bb18:
  %t88 = load ptr, ptr %l12, !tbaa !29
  %t90 = getelementptr %"compiler/typed:Clause", ptr %t88, i32 0, i32 3
  %t91 = load ptr, ptr %t90, !tbaa !29
  %t93 = icmp eq ptr %t91, null
  %t95 = xor i1 %t93, true
  br i1 %t95, label %bb19, label %bb20
bb19:
  %t97 = load ptr, ptr %l0, !tbaa !29
  store ptr %t97, ptr %l68, !tbaa !29
  %t98 = load ptr, ptr %l12, !tbaa !29
  %t100 = getelementptr %"compiler/typed:Clause", ptr %t98, i32 0, i32 3
  %t101 = load ptr, ptr %t100, !tbaa !29
  %t103 = icmp eq ptr %t101, null
  br i1 %t103, label %bb21, label %bb22
bb20:
  br label %bb25
bb21:
  call void @__olang_check_failed(ptr @olang_loc_ed4966d7257d1cce_314b285230575e82)
  unreachable
bb22:
  br label %bb23
bb23:
  %t105 = load ptr, ptr %l12, !tbaa !29
  %t107 = getelementptr %"compiler/typed:Clause", ptr %t105, i32 0, i32 3
  %t108 = load ptr, ptr %t107, !tbaa !29
  %t109 = load ptr, ptr %l68, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eblock(ptr %v0, ptr %v2, ptr %t109, ptr %t108)
  br label %bb24
bb24:
  br label %bb25
bb25:
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr %"compiler/lower:lowering", ptr %t111, i32 0, i32 7
  %t114 = load i1, ptr %t113, !tbaa !21
  %t116 = xor i1 %t114, true
  br i1 %t116, label %bb26, label %bb27
bb26:
  %t118 = load i32, ptr %l3, !tbaa !23
  %t119 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  %t122 = icmp ne i32 %t118, %t119
  store i1 %t122, ptr %l77, !tbaa !21
  br label %bb28
bb27:
  store i1 false, ptr %l77, !tbaa !21
  br label %bb28
bb28:
  %t124 = load i1, ptr %l77, !tbaa !21
  br i1 %t124, label %bb29, label %bb30
bb29:
  %t125 = load ptr, ptr %l12, !tbaa !29
  %t127 = getelementptr %"compiler/typed:Clause", ptr %t125, i32 0, i32 4
  %t128 = load { i64, ptr }, ptr %t127, !tbaa !27
  %t130 = extractvalue { i64, ptr } %t128, 0
  %t132 = icmp sgt i64 %t130, 0
  store i1 %t132, ptr %l81, !tbaa !21
  br label %bb31
bb30:
  store i1 false, ptr %l81, !tbaa !21
  br label %bb31
bb31:
  %t134 = load i1, ptr %l81, !tbaa !21
  br i1 %t134, label %bb32, label %bb33
bb32:
  %t135 = load ptr, ptr %l12, !tbaa !29
  %t137 = getelementptr %"compiler/typed:Clause", ptr %t135, i32 0, i32 4
  %t138 = load { i64, ptr }, ptr %t137, !tbaa !27
  %t140 = extractvalue { i64, ptr } %t138, 0
  %t142 = icmp eq i64 %t140, 1
  br i1 %t142, label %bb34, label %bb35
bb33:
  br label %bb60
bb34:
  store %olang.scope zeroinitializer, ptr %s6
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t145 = load ptr, ptr %l12, !tbaa !29
  %t147 = getelementptr %"compiler/typed:Clause", ptr %t145, i32 0, i32 4
  %t148 = load { i64, ptr }, ptr %t147, !tbaa !27
  store { i64, ptr } %t148, ptr %l92, !tbaa !27
  %t149 = getelementptr { i64, ptr }, ptr %l92, i32 0, i32 1
  %t150 = load ptr, ptr %t149, !tbaa !27
  %t151 = getelementptr ptr, ptr %t150, i64 0
  %t152 = load ptr, ptr %t151, !tbaa !39
  %t156 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v2, ptr %t144, ptr %t152)
  store { i64, [4 x i64] } %t156, ptr %l95
  br label %bb36
bb35:
  store %olang.scope zeroinitializer, ptr %s7
  %t157 = load ptr, ptr %l12, !tbaa !29
  %t159 = getelementptr %"compiler/typed:Clause", ptr %t157, i32 0, i32 4
  %t160 = load { i64, ptr }, ptr %t159, !tbaa !27
  %t162 = extractvalue { i64, ptr } %t160, 0
  store i64 %t162, ptr %l107, !tbaa !24
  %t163 = load i64, ptr %l107, !tbaa !24
  %t164 = icmp sge i64 %t163, 0
  br i1 %t164, label %bb39, label %bb40
bb36:
  %t166 = load { i64, [4 x i64] }, ptr %l95
  store { i64, [4 x i64] } %t166, ptr %l13
  %t167 = load ptr, ptr %l0, !tbaa !29
  store ptr %t167, ptr %l96, !tbaa !29
  %t168 = load ptr, ptr %l12, !tbaa !29
  %t170 = getelementptr %"compiler/typed:Clause", ptr %t168, i32 0, i32 0
  %t171 = load %"compiler/source:Span", ptr %t170
  store %"compiler/source:Span" %t171, ptr %l98
  %t172 = load i32, ptr %l3, !tbaa !23
  %t174 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t172)
  store %"compiler/mir:Place" %t174, ptr %l100
  br label %bb37
bb37:
  %t175 = load { i64, [4 x i64] }, ptr %l13
  store { i64, [15 x i64] } zeroinitializer, ptr %t176
  %t177 = getelementptr { i64, [15 x i64] }, ptr %t176, i32 0, i32 0
  store i64 0, ptr %t177
  %t179 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t175, 0
  %t180 = getelementptr { i64, [15 x i64] }, ptr %t176, i32 0, i32 1
  store { { i64, [4 x i64] } } %t179, ptr %t180
  %t181 = load { i64, [15 x i64] }, ptr %t176
  store { i64, [21 x i64] } zeroinitializer, ptr %t182
  %t183 = getelementptr { i64, [21 x i64] }, ptr %t182, i32 0, i32 0
  store i64 0, ptr %t183
  %t184 = load %"compiler/source:Span", ptr %l98
  %t185 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t184, 0
  %t186 = load %"compiler/mir:Place", ptr %l100
  %t187 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t185, %"compiler/mir:Place" %t186, 1
  %t189 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t187, { i64, [15 x i64] } %t181, 2
  %t190 = getelementptr { i64, [21 x i64] }, ptr %t182, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t189, ptr %t190
  %t191 = load { i64, [21 x i64] }, ptr %t182
  %t193 = call ptr @__olang_scope_alloc_a(ptr %s6, i64 176, i64 8)
  store { i64, [21 x i64] } %t191, ptr %t193
  %t194 = load ptr, ptr %l96, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s6, ptr %t194, ptr %t193)
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s6)
  br label %bb59
bb39:
  %t196 = load i64, ptr %l107, !tbaa !24
  %t197 = icmp sle i64 %t196, 230584300921369395
  br i1 %t197, label %bb41, label %bb42
bb40:
  call void @__olang_check_failed(ptr @olang_loc_4fc14cddf040b63b_d4edc892d8598fd7)
  unreachable
bb41:
  %t199 = load i64, ptr %l107, !tbaa !24
  %t200 = mul i64 %t199, 40
  %t201 = call ptr @__olang_scope_alloc_zeroed(ptr %s7, i64 %t200)
  %t202 = insertvalue { i64, ptr } undef, i64 %t199, 0
  %t203 = insertvalue { i64, ptr } %t202, ptr %t201, 1
  store { i64, ptr } %t203, ptr %l14, !tbaa !27
  store i64 0, ptr %l15, !tbaa !24
  %t205 = load ptr, ptr %l12, !tbaa !29
  %t207 = getelementptr %"compiler/typed:Clause", ptr %t205, i32 0, i32 4
  %t208 = load { i64, ptr }, ptr %t207, !tbaa !27
  %t210 = extractvalue { i64, ptr } %t208, 0
  store i64 %t210, ptr %l16, !tbaa !24
  store i64 1, ptr %l17, !tbaa !24
  %t212 = load i64, ptr %l16, !tbaa !24
  %t213 = load i64, ptr %l15, !tbaa !24
  %t216 = icmp sgt i64 %t212, %t213
  br i1 %t216, label %bb43, label %bb44
bb42:
  call void @__olang_check_failed(ptr @olang_loc_4fc14cddf040b63b_d4edc892d8598fd7)
  unreachable
bb43:
  %t218 = load i64, ptr %l17, !tbaa !24
  %t220 = icmp sgt i64 %t218, 0
  br i1 %t220, label %bb45, label %bb46
bb44:
  store i64 0, ptr %l117, !tbaa !24
  br label %bb48
bb45:
  %t222 = load i64, ptr %l16, !tbaa !24
  %t223 = load i64, ptr %l15, !tbaa !24
  %t226 = sub i64 %t222, %t223
  %t227 = load i64, ptr %l17, !tbaa !24
  %t230 = add i64 %t226, %t227
  %t232 = sub i64 %t230, 1
  %t233 = load i64, ptr %l17, !tbaa !24
  %t236 = sdiv i64 %t232, %t233
  store i64 %t236, ptr %l120, !tbaa !24
  br label %bb47
bb46:
  store i64 0, ptr %l120, !tbaa !24
  br label %bb47
bb47:
  %t238 = load i64, ptr %l120, !tbaa !24
  store i64 %t238, ptr %l117, !tbaa !24
  br label %bb48
bb48:
  %t239 = load i64, ptr %l117, !tbaa !24
  store i64 %t239, ptr %l18, !tbaa !24
  store i64 0, ptr %l19, !tbaa !24
  br label %bb49
bb49:
  %t240 = load i64, ptr %l19, !tbaa !24
  %t241 = load i64, ptr %l18, !tbaa !24
  %t244 = icmp slt i64 %t240, %t241
  %t246 = xor i1 %t244, true
  br i1 %t246, label %bb50, label %bb51
bb50:
  br label %bb55
bb51:
  br label %bb52
bb52:
  %t248 = load i64, ptr %l15, !tbaa !24
  %t249 = load i64, ptr %l19, !tbaa !24
  %t250 = load i64, ptr %l17, !tbaa !24
  %t253 = mul i64 %t249, %t250
  %t256 = add i64 %t248, %t253
  store i64 %t256, ptr %l20, !tbaa !24
  %t258 = load i64, ptr %l20, !tbaa !24
  store i64 %t258, ptr %l138, !tbaa !24
  %t259 = load ptr, ptr %l0, !tbaa !29
  %t260 = load ptr, ptr %l12, !tbaa !29
  %t262 = getelementptr %"compiler/typed:Clause", ptr %t260, i32 0, i32 4
  %t263 = load { i64, ptr }, ptr %t262, !tbaa !27
  store { i64, ptr } %t263, ptr %l141, !tbaa !27
  %t264 = load i64, ptr %l20, !tbaa !24
  %t266 = getelementptr { i64, ptr }, ptr %l141, i32 0, i32 1
  %t267 = load ptr, ptr %t266, !tbaa !27
  %t268 = getelementptr ptr, ptr %t267, i64 %t264
  %t269 = load ptr, ptr %t268, !tbaa !39
  %t273 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v2, ptr %t259, ptr %t269)
  store { i64, [4 x i64] } %t273, ptr %l145
  br label %bb53
bb53:
  %t274 = load { i64, [4 x i64] }, ptr %l145
  %t275 = load i64, ptr %l138, !tbaa !24
  %t276 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t277 = load ptr, ptr %t276, !tbaa !27
  %t278 = getelementptr { i64, [4 x i64] }, ptr %t277, i64 %t275
  store { i64, [4 x i64] } %t274, ptr %t278
  br label %bb54
bb54:
  %t279 = load i64, ptr %l19, !tbaa !24
  %t281 = add i64 %t279, 1
  store i64 %t281, ptr %l19, !tbaa !24
  br label %bb49
bb55:
  %t283 = load ptr, ptr %l0, !tbaa !29
  store ptr %t283, ptr %l148, !tbaa !29
  %t284 = load ptr, ptr %l12, !tbaa !29
  %t286 = getelementptr %"compiler/typed:Clause", ptr %t284, i32 0, i32 0
  %t287 = load %"compiler/source:Span", ptr %t286
  store %"compiler/source:Span" %t287, ptr %l150
  %t288 = load i32, ptr %l3, !tbaa !23
  %t290 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t288)
  store %"compiler/mir:Place" %t290, ptr %l152
  br label %bb56
bb56:
  store i32 %a4, ptr %l153, !tbaa !23
  %t292 = load ptr, ptr %l0, !tbaa !29
  %t294 = getelementptr %"compiler/lower:lowering", ptr %t292, i32 0, i32 3
  %t295 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t298 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v0, ptr %s7, ptr %t294, { i64, ptr } %t295)
  store %"compiler/mir:Range" %t298, ptr %l157
  br label %bb57
bb57:
  store { i64, [15 x i64] } zeroinitializer, ptr %t299
  %t300 = getelementptr { i64, [15 x i64] }, ptr %t299, i32 0, i32 0
  store i64 6, ptr %t300
  %t301 = load i32, ptr %l153, !tbaa !23
  %t302 = insertvalue { i32, i64, %"compiler/mir:Range" } undef, i32 %t301, 0
  %t303 = insertvalue { i32, i64, %"compiler/mir:Range" } %t302, i64 0, 1
  %t304 = load %"compiler/mir:Range", ptr %l157
  %t305 = insertvalue { i32, i64, %"compiler/mir:Range" } %t303, %"compiler/mir:Range" %t304, 2
  %t306 = getelementptr { i64, [15 x i64] }, ptr %t299, i32 0, i32 1
  store { i32, i64, %"compiler/mir:Range" } %t305, ptr %t306
  %t307 = load { i64, [15 x i64] }, ptr %t299
  store { i64, [21 x i64] } zeroinitializer, ptr %t308
  %t309 = getelementptr { i64, [21 x i64] }, ptr %t308, i32 0, i32 0
  store i64 0, ptr %t309
  %t310 = load %"compiler/source:Span", ptr %l150
  %t311 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t310, 0
  %t312 = load %"compiler/mir:Place", ptr %l152
  %t313 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t311, %"compiler/mir:Place" %t312, 1
  %t315 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t313, { i64, [15 x i64] } %t307, 2
  %t316 = getelementptr { i64, [21 x i64] }, ptr %t308, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t315, ptr %t316
  %t317 = load { i64, [21 x i64] }, ptr %t308
  %t319 = call ptr @__olang_scope_alloc_a(ptr %s7, i64 176, i64 8)
  store { i64, [21 x i64] } %t317, ptr %t319
  %t320 = load ptr, ptr %l148, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s7, ptr %t320, ptr %t319)
  br label %bb58
bb58:
  call void @__olang_scope_close(ptr %s7)
  br label %bb59
bb59:
  br label %bb60
bb60:
  %t322 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eleaveOpen(ptr %v0, ptr %v3, ptr %t322, ptr %a5)
  br label %bb61
bb61:
  br label %bb62
bb62:
  %t326 = load i64, ptr %l10, !tbaa !24
  %t328 = add i64 %t326, 1
  store i64 %t328, ptr %l10, !tbaa !24
  br label %bb7
bb63:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2ecloseBlock(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 9
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e_2eLen_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i64, ptr %l4, !tbaa !24
  %t7 = sub i64 %t6, 1
  store i64 %t7, ptr %l1, !tbaa !24
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/lower:lowering", ptr %t9, i32 0, i32 7
  %t12 = load i1, ptr %t11, !tbaa !21
  %t14 = xor i1 %t12, true
  br i1 %t14, label %bb2, label %bb3
bb2:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eexitLevel(ptr %v0, ptr %t16, i64 %t17)
  br label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb5
bb5:
  %t20 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2epopLevel(ptr %v0, ptr %t20)
  br label %bb6
bb6:
  br label %ret
ret:
  ret void
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ecollect(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca { i64, [4 x i64] }
  %l11 = alloca { i64, [1 x i64] }
  %l12 = alloca i32
  %l13 = alloca i32
  %l14 = alloca i32
  %l15 = alloca { i64, [1 x i64] }
  %l16 = alloca i32
  %l17 = alloca i32
  %l23 = alloca i32
  %l27 = alloca i1
  %l30 = alloca i64
  %l37 = alloca i32
  %l38 = alloca ptr
  %l41 = alloca i32
  %l43 = alloca i32
  %l45 = alloca { i64, [4 x i64] }
  %l53 = alloca { i64, [4 x i64] }
  %l54 = alloca ptr
  %l55 = alloca { i64, [4 x i64] }
  %l61 = alloca i32
  %l63 = alloca { i64, [4 x i64] }
  %l68 = alloca ptr
  %l69 = alloca i32
  %l70 = alloca i32
  %l71 = alloca { i64, [4 x i64] }
  %l73 = alloca { i64, [4 x i64] }
  %l74 = alloca { i64, ptr }
  %l76 = alloca { i64, [4 x i64] }
  %l89 = alloca i1
  %l97 = alloca { i64, [1 x i64] }
  %l101 = alloca i32
  %l102 = alloca ptr
  %l103 = alloca %"compiler/source:Span"
  %l105 = alloca %"compiler/mir:Place"
  %l116 = alloca i32
  %l117 = alloca ptr
  %l118 = alloca %"compiler/source:Span"
  %l120 = alloca %"compiler/mir:Place"
  %l122 = alloca { i64, [4 x i64] }
  %l127 = alloca ptr
  %l128 = alloca i32
  %l129 = alloca i32
  %l130 = alloca i32
  %l131 = alloca i32
  %l132 = alloca { i64, [1 x i64] }
  %l133 = alloca ptr
  %l136 = alloca i32
  %l137 = alloca i1
  %l138 = alloca %"compiler/lower:collectCtx"
  %l142 = alloca %"compiler/lower:collectCtx"
  %l145 = alloca %"compiler/lower:collectCtx"
  %l146 = alloca i32
  %l151 = alloca %"compiler/mir:Place"
  %l156 = alloca i32
  %l160 = alloca { i64, [1 x i64] }
  %l161 = alloca ptr
  %l162 = alloca %"compiler/source:Span"
  %l164 = alloca %"compiler/mir:Place"
  %l176 = alloca i32
  %l177 = alloca ptr
  %l178 = alloca %"compiler/source:Span"
  %l180 = alloca %"compiler/mir:Place"
  %l182 = alloca { i64, [4 x i64] }
  %l187 = alloca ptr
  %l193 = alloca %"compiler/lower:collectCtx"
  %l197 = alloca %"compiler/lower:collectCtx"
  %l200 = alloca %"compiler/lower:collectCtx"
  %l201 = alloca i32
  %l208 = alloca i32
  %l209 = alloca ptr
  %l210 = alloca %"compiler/source:Span"
  %l212 = alloca %"compiler/mir:Place"
  %l216 = alloca { i64, [1 x i64] }
  %l217 = alloca i32
  %l219 = alloca %"compiler/mir:Place"
  %l227 = alloca ptr
  %l229 = alloca { i64, [2 x i64] }
  %l230 = alloca ptr
  %l233 = alloca i32
  %l234 = alloca i1
  %l235 = alloca { i64, ptr }
  %l237 = alloca { i64, ptr }
  %l239 = alloca %"compiler/mir:Place"
  %l240 = alloca ptr
  %l241 = alloca %"compiler/source:Span"
  %l242 = alloca %"compiler/mir:Place"
  %l248 = alloca { i64, ptr }
  %l249 = alloca %"compiler/mir:Place"
  %l251 = alloca %"compiler/mir:Place"
  %l256 = alloca %"compiler/mir:Place"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca { i64, [4 x i64] }
  %t31 = alloca { i64, [4 x i64] }, align 8
  %t152 = alloca { i64, [4 x i64] }, align 8
  %t196 = alloca { i64, [4 x i64] }, align 8
  %t199 = alloca { i64, [15 x i64] }, align 8
  %t211 = alloca { i64, [21 x i64] }, align 8
  %t241 = alloca { i64, [15 x i64] }, align 8
  %t247 = alloca { i64, [21 x i64] }, align 8
  %t309 = alloca { i64, [4 x i64] }, align 8
  %t316 = alloca { i64, [4 x i64] }, align 8
  %t349 = alloca { i64, [4 x i64] }, align 8
  %t356 = alloca { i64, [15 x i64] }, align 8
  %t368 = alloca { i64, [21 x i64] }, align 8
  %t398 = alloca { i64, [15 x i64] }, align 8
  %t404 = alloca { i64, [21 x i64] }, align 8
  %t456 = alloca { i64, [4 x i64] }, align 8
  %t485 = alloca { i64, [4 x i64] }, align 8
  %t492 = alloca { i64, [4 x i64] }, align 8
  %t499 = alloca { i64, [15 x i64] }, align 8
  %t511 = alloca { i64, [21 x i64] }, align 8
  %t529 = alloca { i64, [2 x i64] }, align 8
  %t545 = alloca { i64, [1 x i64] }, align 8
  %t574 = alloca { i64, [2 x i64] }, align 8
  %t580 = alloca { i64, [1 x i64] }, align 8
  %t598 = alloca { i64, [4 x i64] }, align 8
  %t604 = alloca { i64, [21 x i64] }, align 8
  %t623 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load i32, ptr %l2, !tbaa !23
  %t10 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2earrayOf(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t10, ptr %l23
  br label %bb1
bb1:
  %t11 = load i32, ptr %l23, !tbaa !23
  store i32 %t11, ptr %l5, !tbaa !23
  %t12 = load i32, ptr %l5, !tbaa !23
  %t13 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t16 = icmp eq i32 %t12, %t13
  br i1 %t16, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb5
bb3:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load i32, ptr %l5, !tbaa !23
  %t22 = call i64 @compiler_2flower_2ecompiler_2flower_3alowering_2efixedLen(ptr %v0, ptr %t18, i32 %t19)
  store i64 %t22, ptr %l30
  br label %bb4
bb4:
  %t23 = load i64, ptr %l30, !tbaa !24
  %t24 = icmp sge i64 %t23, 0
  store i1 %t24, ptr %l27, !tbaa !21
  br label %bb5
bb5:
  %t26 = load i1, ptr %l27, !tbaa !21
  br i1 %t26, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s1
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load %"compiler/source:Span", ptr %l3
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2egap(ptr %v0, ptr %s1, ptr %t27, %"compiler/source:Span" %t28, { i64, ptr } { i64 51, ptr getelementptr inbounds (<{ i64, [51 x i8] }>, ptr @.d14, i32 0, i32 1) })
  br label %bb8
bb7:
  br label %bb9
bb8:
  store { i64, [4 x i64] } zeroinitializer, ptr %t31
  %t32 = getelementptr { i64, [4 x i64] }, ptr %t31, i32 0, i32 0
  store i64 0, ptr %t32
  %t33 = load { i64, [4 x i64] }, ptr %t31
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t33, ptr %rv
  br label %ret
bb9:
  %t35 = load ptr, ptr %l4, !tbaa !29
  %t36 = load i32, ptr %l5, !tbaa !23
  %t39 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t35, i32 %t36)
  store i32 %t39, ptr %l37
  br label %bb10
bb10:
  %t40 = load i32, ptr %l37, !tbaa !23
  store i32 %t40, ptr %l6, !tbaa !23
  %t41 = load ptr, ptr %l4, !tbaa !29
  store ptr %t41, ptr %l38, !tbaa !29
  %t42 = load ptr, ptr %l4, !tbaa !29
  %t43 = load i32, ptr %l6, !tbaa !23
  %t46 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %t42, i32 %t43, i32 0)
  store i32 %t46, ptr %l41
  br label %bb11
bb11:
  %t47 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t48 = load ptr, ptr %l38, !tbaa !29
  %t49 = load i32, ptr %l41, !tbaa !23
  %t51 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t48, i32 %t49, i64 %t47)
  store i32 %t51, ptr %l43
  br label %bb12
bb12:
  %t52 = load i32, ptr %l43, !tbaa !23
  store i32 %t52, ptr %l7, !tbaa !23
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2econstI64(ptr %v0, ptr %t53, i64 100)
  store { i64, [4 x i64] } %t55, ptr %l45
  br label %bb13
bb13:
  %t56 = load { i64, [4 x i64] }, ptr %l45
  store { i64, [4 x i64] } %t56, ptr %l8
  %t57 = load ptr, ptr %l1, !tbaa !29
  %t59 = getelementptr %"compiler/typed:Collect", ptr %t57, i32 0, i32 0
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t62 = icmp eq ptr %t60, null
  %t64 = xor i1 %t62, true
  br i1 %t64, label %bb14, label %bb15
bb14:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load ptr, ptr %l1, !tbaa !29
  %t69 = getelementptr %"compiler/typed:Collect", ptr %t67, i32 0, i32 0
  %t70 = load ptr, ptr %t69, !tbaa !29
  %t73 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %t66, ptr %t70)
  store { i64, [4 x i64] } %t73, ptr %l53
  br label %bb16
bb15:
  br label %bb28
bb16:
  %t74 = load { i64, [4 x i64] }, ptr %l53
  %t75 = load ptr, ptr %l0, !tbaa !29
  store ptr %t75, ptr %l54, !tbaa !29
  store { i64, [4 x i64] } %t74, ptr %l55
  %t77 = load ptr, ptr %l1, !tbaa !29
  %t79 = getelementptr %"compiler/typed:Collect", ptr %t77, i32 0, i32 0
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t82 = icmp eq ptr %t80, null
  br i1 %t82, label %bb17, label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_162f2c5d450ff5be_60a02040feb29ca2)
  unreachable
bb18:
  br label %bb19
bb19:
  %t84 = load ptr, ptr %l1, !tbaa !29
  %t86 = getelementptr %"compiler/typed:Collect", ptr %t84, i32 0, i32 0
  %t87 = load ptr, ptr %t86, !tbaa !29
  %t89 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t87)
  store i32 %t89, ptr %l61
  br label %bb20
bb20:
  %t90 = load %"compiler/source:Span", ptr %l3
  %t91 = load ptr, ptr %l54, !tbaa !29
  %t92 = load { i64, [4 x i64] }, ptr %l55
  %t93 = load i32, ptr %l61, !tbaa !23
  %t95 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2easI64(ptr %v0, ptr %t91, { i64, [4 x i64] } %t92, i32 %t93, %"compiler/source:Span" %t90)
  store { i64, [4 x i64] } %t95, ptr %l63
  br label %bb21
bb21:
  %t96 = load { i64, [4 x i64] }, ptr %l63
  store { i64, [4 x i64] } %t96, ptr %l8
  %t97 = load ptr, ptr %l1, !tbaa !29
  %t99 = getelementptr %"compiler/typed:Collect", ptr %t97, i32 0, i32 3
  %t100 = load i32, ptr %t99
  %t102 = trunc i64 0 to i32
  %t103 = icmp eq i32 %t100, %t102
  %t105 = xor i1 %t103, true
  br i1 %t105, label %bb22, label %bb23
bb22:
  store %olang.scope zeroinitializer, ptr %s3
  %t107 = load ptr, ptr %l0, !tbaa !29
  store ptr %t107, ptr %l68, !tbaa !29
  store i32 18, ptr %l69
  %t108 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t108, ptr %l70, !tbaa !23
  %t109 = load { i64, [4 x i64] }, ptr %l8
  store { i64, [4 x i64] } %t109, ptr %l71
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2econstI64(ptr %v0, ptr %t110, i64 0)
  store { i64, [4 x i64] } %t112, ptr %l73
  br label %bb24
bb23:
  br label %bb27
bb24:
  %t113 = mul i64 2, 40
  %t114 = call ptr @__olang_scope_alloc_zeroed(ptr %s3, i64 %t113)
  %t115 = insertvalue { i64, ptr } undef, i64 2, 0
  %t116 = insertvalue { i64, ptr } %t115, ptr %t114, 1
  store { i64, ptr } %t116, ptr %l74, !tbaa !27
  %t117 = load { i64, [4 x i64] }, ptr %l71
  %t118 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t119 = load ptr, ptr %t118, !tbaa !27
  %t120 = getelementptr { i64, [4 x i64] }, ptr %t119, i64 0
  store { i64, [4 x i64] } %t117, ptr %t120
  %t121 = load { i64, [4 x i64] }, ptr %l73
  %t122 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t123 = load ptr, ptr %t122, !tbaa !27
  %t124 = getelementptr { i64, [4 x i64] }, ptr %t123, i64 1
  store { i64, [4 x i64] } %t121, ptr %t124
  %t125 = load %"compiler/source:Span", ptr %l3
  %t126 = load ptr, ptr %l68, !tbaa !29
  %t127 = load i32, ptr %l69
  %t128 = load i32, ptr %l70, !tbaa !23
  %t129 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t131 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s3, ptr %t126, i32 %t127, i32 %t128, { i64, ptr } %t129, %"compiler/source:Span" %t125)
  store { i64, [4 x i64] } %t131, ptr %l76
  br label %bb25
bb25:
  %t132 = load { i64, [4 x i64] }, ptr %l76
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t135 = load ptr, ptr %l1, !tbaa !29
  %t137 = getelementptr %"compiler/typed:Collect", ptr %t135, i32 0, i32 3
  %t138 = load i32, ptr %t137
  %t139 = load i64, ptr @G_2ecompiler_2flower_2eOutOfBounds, !tbaa !24
  %t140 = load %"compiler/source:Span", ptr %l3
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2echeck(ptr %v0, ptr %t133, { i64, [4 x i64] } %t132, i32 %t138, i32 7, i64 %t139, %"compiler/source:Span" %t140)
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s3)
  br label %bb27
bb27:
  br label %bb28
bb28:
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t149 = getelementptr %"compiler/lower:lowering", ptr %t147, i32 0, i32 7
  %t150 = load i1, ptr %t149, !tbaa !21
  br i1 %t150, label %bb29, label %bb30
bb29:
  store { i64, [4 x i64] } zeroinitializer, ptr %t152
  %t153 = getelementptr { i64, [4 x i64] }, ptr %t152, i32 0, i32 0
  store i64 0, ptr %t153
  %t154 = load { i64, [4 x i64] }, ptr %t152
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t154, ptr %rv
  br label %ret
bb30:
  br label %bb31
bb31:
  %t156 = load ptr, ptr %l1, !tbaa !29
  %t158 = getelementptr %"compiler/typed:Collect", ptr %t156, i32 0, i32 4
  %t159 = load i1, ptr %t158, !tbaa !21
  br i1 %t159, label %bb32, label %bb33
bb32:
  %t161 = load ptr, ptr %l1, !tbaa !29
  %t163 = getelementptr %"compiler/typed:Collect", ptr %t161, i32 0, i32 0
  %t164 = load ptr, ptr %t163, !tbaa !29
  %t166 = icmp eq ptr %t164, null
  %t168 = xor i1 %t166, true
  store i1 %t168, ptr %l89, !tbaa !21
  br label %bb34
bb33:
  store i1 false, ptr %l89, !tbaa !21
  br label %bb34
bb34:
  %t170 = load i1, ptr %l89, !tbaa !21
  br i1 %t170, label %bb35, label %bb36
bb35:
  store %olang.scope zeroinitializer, ptr %s5
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t172 = load ptr, ptr %l1, !tbaa !29
  %t174 = getelementptr %"compiler/typed:Collect", ptr %t172, i32 0, i32 2
  %t175 = load i32, ptr %t174, !tbaa !23
  %t178 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2emadeAt(ptr %v0, ptr %t171, i32 %t175)
  store { i64, [1 x i64] } %t178, ptr %l97
  br label %bb37
bb36:
  br label %bb58
bb37:
  %t179 = load { i64, [1 x i64] }, ptr %l97
  store { i64, [1 x i64] } %t179, ptr %l11
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t181 = load i32, ptr %l2, !tbaa !23
  %t182 = load %"compiler/source:Span", ptr %l3
  %t186 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etemp(ptr %v0, ptr %t180, i32 %t181, %"compiler/source:Span" %t182)
  store i32 %t186, ptr %l101
  br label %bb38
bb38:
  %t187 = load i32, ptr %l101, !tbaa !23
  store i32 %t187, ptr %l12, !tbaa !23
  %t188 = load ptr, ptr %l0, !tbaa !29
  store ptr %t188, ptr %l102, !tbaa !29
  %t189 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t189, ptr %l103
  %t190 = load i32, ptr %l12, !tbaa !23
  %t192 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t190)
  store %"compiler/mir:Place" %t192, ptr %l105
  br label %bb39
bb39:
  %t193 = load { i64, [1 x i64] }, ptr %l11
  %t194 = load i32, ptr %l2, !tbaa !23
  %t195 = load { i64, [4 x i64] }, ptr %l8
  store { i64, [4 x i64] } zeroinitializer, ptr %t196
  %t197 = getelementptr { i64, [4 x i64] }, ptr %t196, i32 0, i32 0
  store i64 0, ptr %t197
  %t198 = load { i64, [4 x i64] }, ptr %t196
  store { i64, [15 x i64] } zeroinitializer, ptr %t199
  %t200 = getelementptr { i64, [15 x i64] }, ptr %t199, i32 0, i32 0
  store i64 8, ptr %t200
  %t202 = insertvalue { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } undef, { i64, [1 x i64] } %t193, 0
  %t204 = insertvalue { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } %t202, i32 %t194, 1
  %t206 = insertvalue { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } %t204, { i64, [4 x i64] } %t195, 2
  %t208 = insertvalue { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } %t206, { i64, [4 x i64] } %t198, 3
  %t209 = getelementptr { i64, [15 x i64] }, ptr %t199, i32 0, i32 1
  store { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } %t208, ptr %t209
  %t210 = load { i64, [15 x i64] }, ptr %t199
  store { i64, [21 x i64] } zeroinitializer, ptr %t211
  %t212 = getelementptr { i64, [21 x i64] }, ptr %t211, i32 0, i32 0
  store i64 0, ptr %t212
  %t213 = load %"compiler/source:Span", ptr %l103
  %t214 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t213, 0
  %t215 = load %"compiler/mir:Place", ptr %l105
  %t216 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t214, %"compiler/mir:Place" %t215, 1
  %t218 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t216, { i64, [15 x i64] } %t210, 2
  %t219 = getelementptr { i64, [21 x i64] }, ptr %t211, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t218, ptr %t219
  %t220 = load { i64, [21 x i64] }, ptr %t211
  %t222 = call ptr @__olang_scope_alloc_a(ptr %s5, i64 176, i64 8)
  store { i64, [21 x i64] } %t220, ptr %t222
  %t223 = load ptr, ptr %l102, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s5, ptr %t223, ptr %t222)
  br label %bb40
bb40:
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t226 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  %t227 = load %"compiler/source:Span", ptr %l3
  %t231 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etemp(ptr %v0, ptr %t225, i32 %t226, %"compiler/source:Span" %t227)
  store i32 %t231, ptr %l116
  br label %bb41
bb41:
  %t232 = load i32, ptr %l116, !tbaa !23
  store i32 %t232, ptr %l13, !tbaa !23
  %t233 = load ptr, ptr %l0, !tbaa !29
  store ptr %t233, ptr %l117, !tbaa !29
  %t234 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t234, ptr %l118
  %t235 = load i32, ptr %l13, !tbaa !23
  %t237 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t235)
  store %"compiler/mir:Place" %t237, ptr %l120
  br label %bb42
bb42:
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t240 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2econstI64(ptr %v0, ptr %t238, i64 0)
  store { i64, [4 x i64] } %t240, ptr %l122
  br label %bb43
bb43:
  store { i64, [15 x i64] } zeroinitializer, ptr %t241
  %t242 = getelementptr { i64, [15 x i64] }, ptr %t241, i32 0, i32 0
  store i64 0, ptr %t242
  %t243 = load { i64, [4 x i64] }, ptr %l122
  %t244 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t243, 0
  %t245 = getelementptr { i64, [15 x i64] }, ptr %t241, i32 0, i32 1
  store { { i64, [4 x i64] } } %t244, ptr %t245
  %t246 = load { i64, [15 x i64] }, ptr %t241
  store { i64, [21 x i64] } zeroinitializer, ptr %t247
  %t248 = getelementptr { i64, [21 x i64] }, ptr %t247, i32 0, i32 0
  store i64 0, ptr %t248
  %t249 = load %"compiler/source:Span", ptr %l118
  %t250 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t249, 0
  %t251 = load %"compiler/mir:Place", ptr %l120
  %t252 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t250, %"compiler/mir:Place" %t251, 1
  %t254 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t252, { i64, [15 x i64] } %t246, 2
  %t255 = getelementptr { i64, [21 x i64] }, ptr %t247, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t254, ptr %t255
  %t256 = load { i64, [21 x i64] }, ptr %t247
  %t258 = call ptr @__olang_scope_alloc_a(ptr %s5, i64 176, i64 8)
  store { i64, [21 x i64] } %t256, ptr %t258
  %t259 = load ptr, ptr %l117, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s5, ptr %t259, ptr %t258)
  br label %bb44
bb44:
  %t261 = load ptr, ptr %l0, !tbaa !29
  %t263 = getelementptr %"compiler/lower:lowering", ptr %t261, i32 0, i32 14
  store ptr %t263, ptr %l127, !tbaa !29
  %t264 = load i32, ptr %l12, !tbaa !23
  store i32 %t264, ptr %l128, !tbaa !23
  %t265 = load i32, ptr %l13, !tbaa !23
  store i32 %t265, ptr %l129, !tbaa !23
  %t266 = load i32, ptr %l6, !tbaa !23
  store i32 %t266, ptr %l130, !tbaa !23
  %t267 = load i32, ptr %l2, !tbaa !23
  store i32 %t267, ptr %l131, !tbaa !23
  %t268 = load { i64, [1 x i64] }, ptr %l11
  store { i64, [1 x i64] } %t268, ptr %l132
  %t269 = load ptr, ptr %l4, !tbaa !29
  store ptr %t269, ptr %l133, !tbaa !29
  %t270 = load ptr, ptr %l4, !tbaa !29
  %t271 = load i32, ptr %l2, !tbaa !23
  %t274 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t270, i32 %t271)
  store i32 %t274, ptr %l136
  br label %bb45
bb45:
  %t275 = load ptr, ptr %l133, !tbaa !29
  %t276 = load i32, ptr %l136, !tbaa !23
  %t277 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t275, i32 %t276)
  store i1 %t277, ptr %l137
  br label %bb46
bb46:
  %t278 = load i32, ptr %l128, !tbaa !23
  %t279 = load i32, ptr %l129, !tbaa !23
  %t280 = load i32, ptr %l130, !tbaa !23
  %t281 = load i32, ptr %l131, !tbaa !23
  %t282 = load { i64, [1 x i64] }, ptr %l132
  %t283 = load i1, ptr %l137, !tbaa !21
  %t284 = call %"compiler/lower:collectCtx" @compiler_2flower_3acollectCtx_2ector(ptr %s5, i32 %t278, i32 %t279, i32 %t280, i32 %t281, { i64, [1 x i64] } %t282, i1 true, i1 %t283)
  store %"compiler/lower:collectCtx" %t284, ptr %l138
  br label %bb47
bb47:
  %t285 = load ptr, ptr %l127, !tbaa !29
  %t286 = load %"compiler/lower:collectCtx", ptr %l138
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3acollectCtx_3e_2ePus_Hd0ab7b9373bf150d973fdf7c33c4c364(ptr %v0, ptr %t285, %"compiler/lower:collectCtx" %t286)
  br label %bb48
bb48:
  %t287 = load ptr, ptr %l0, !tbaa !29
  %t288 = load ptr, ptr %l1, !tbaa !29
  %t290 = getelementptr %"compiler/typed:Collect", ptr %t288, i32 0, i32 1
  %t291 = load ptr, ptr %t290, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eblock(ptr %v0, ptr %v1, ptr %t287, ptr %t291)
  br label %bb49
bb49:
  %t294 = load ptr, ptr %l0, !tbaa !29
  %t296 = getelementptr %"compiler/lower:lowering", ptr %t294, i32 0, i32 14
  %t298 = call { i32, %"compiler/lower:collectCtx" } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3acollectCtx_3e_2ePop_He1200c0c51a1e2029459d9d8221d233c(ptr %v0, ptr %t296)
  %t299 = extractvalue { i32, %"compiler/lower:collectCtx" } %t298, 1
  %t300 = extractvalue { i32, %"compiler/lower:collectCtx" } %t298, 0
  store i32 %t300, ptr %l146
  %t301 = icmp ne i32 %t300, 0
  br i1 %t301, label %bb51, label %ok.302
ok.302:
  store %"compiler/lower:collectCtx" %t299, ptr %l145
  br label %bb50
bb50:
  %t303 = load %"compiler/lower:collectCtx", ptr %l145
  store %"compiler/lower:collectCtx" %t303, ptr %l142
  br label %bb53
bb51:
  br label %bb52
bb52:
  call void @__olang_ert_req_clear()
  br label %bb53
bb53:
  %t304 = load ptr, ptr %l0, !tbaa !29
  %t306 = getelementptr %"compiler/lower:lowering", ptr %t304, i32 0, i32 7
  %t307 = load i1, ptr %t306, !tbaa !21
  br i1 %t307, label %bb54, label %bb55
bb54:
  store { i64, [4 x i64] } zeroinitializer, ptr %t309
  %t310 = getelementptr { i64, [4 x i64] }, ptr %t309, i32 0, i32 0
  store i64 0, ptr %t310
  %t311 = load { i64, [4 x i64] }, ptr %t309
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t311, ptr %rv
  br label %ret
bb55:
  br label %bb56
bb56:
  %t313 = load i32, ptr %l12, !tbaa !23
  %t315 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t313)
  store %"compiler/mir:Place" %t315, ptr %l151
  br label %bb57
bb57:
  store { i64, [4 x i64] } zeroinitializer, ptr %t316
  %t317 = getelementptr { i64, [4 x i64] }, ptr %t316, i32 0, i32 0
  store i64 1, ptr %t317
  %t318 = load %"compiler/mir:Place", ptr %l151
  %t319 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t318, 0
  %t320 = getelementptr { i64, [4 x i64] }, ptr %t316, i32 0, i32 1
  store { %"compiler/mir:Place" } %t319, ptr %t320
  %t321 = load { i64, [4 x i64] }, ptr %t316
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t321, ptr %rv
  br label %ret
bb58:
  %t323 = load ptr, ptr %l0, !tbaa !29
  %t324 = load i32, ptr %l7, !tbaa !23
  %t325 = load %"compiler/source:Span", ptr %l3
  %t329 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etemp(ptr %v0, ptr %t323, i32 %t324, %"compiler/source:Span" %t325)
  store i32 %t329, ptr %l156
  br label %bb59
bb59:
  %t330 = load i32, ptr %l156, !tbaa !23
  store i32 %t330, ptr %l14, !tbaa !23
  %t331 = load ptr, ptr %l0, !tbaa !29
  %t332 = load ptr, ptr %l1, !tbaa !29
  %t334 = getelementptr %"compiler/typed:Collect", ptr %t332, i32 0, i32 2
  %t335 = load i32, ptr %t334, !tbaa !23
  %t338 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ebuilt(ptr %v0, ptr %t331, i32 %t335)
  store { i64, [1 x i64] } %t338, ptr %l160
  br label %bb60
bb60:
  %t339 = load { i64, [1 x i64] }, ptr %l160
  store { i64, [1 x i64] } %t339, ptr %l15
  %t340 = load ptr, ptr %l0, !tbaa !29
  store ptr %t340, ptr %l161, !tbaa !29
  %t341 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t341, ptr %l162
  %t342 = load i32, ptr %l14, !tbaa !23
  %t344 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t342)
  store %"compiler/mir:Place" %t344, ptr %l164
  br label %bb61
bb61:
  %t345 = load { i64, [1 x i64] }, ptr %l15
  %t346 = load i32, ptr %l7, !tbaa !23
  %t347 = load { i64, [4 x i64] }, ptr %l8
  %t348 = load i32, ptr %l6, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t349
  %t350 = getelementptr { i64, [4 x i64] }, ptr %t349, i32 0, i32 0
  store i64 2, ptr %t350
  %t352 = insertvalue { i32, i64 } undef, i32 %t348, 0
  %t353 = insertvalue { i32, i64 } %t352, i64 0, 1
  %t354 = getelementptr { i64, [4 x i64] }, ptr %t349, i32 0, i32 1
  store { i32, i64 } %t353, ptr %t354
  %t355 = load { i64, [4 x i64] }, ptr %t349
  store { i64, [15 x i64] } zeroinitializer, ptr %t356
  %t357 = getelementptr { i64, [15 x i64] }, ptr %t356, i32 0, i32 0
  store i64 8, ptr %t357
  %t359 = insertvalue { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } undef, { i64, [1 x i64] } %t345, 0
  %t361 = insertvalue { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } %t359, i32 %t346, 1
  %t363 = insertvalue { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } %t361, { i64, [4 x i64] } %t347, 2
  %t365 = insertvalue { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } %t363, { i64, [4 x i64] } %t355, 3
  %t366 = getelementptr { i64, [15 x i64] }, ptr %t356, i32 0, i32 1
  store { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } %t365, ptr %t366
  %t367 = load { i64, [15 x i64] }, ptr %t356
  store { i64, [21 x i64] } zeroinitializer, ptr %t368
  %t369 = getelementptr { i64, [21 x i64] }, ptr %t368, i32 0, i32 0
  store i64 0, ptr %t369
  %t370 = load %"compiler/source:Span", ptr %l162
  %t371 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t370, 0
  %t372 = load %"compiler/mir:Place", ptr %l164
  %t373 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t371, %"compiler/mir:Place" %t372, 1
  %t375 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t373, { i64, [15 x i64] } %t367, 2
  %t376 = getelementptr { i64, [21 x i64] }, ptr %t368, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t375, ptr %t376
  %t377 = load { i64, [21 x i64] }, ptr %t368
  %t379 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t377, ptr %t379
  %t380 = load ptr, ptr %l161, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %t380, ptr %t379)
  br label %bb62
bb62:
  %t382 = load ptr, ptr %l0, !tbaa !29
  %t383 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  %t384 = load %"compiler/source:Span", ptr %l3
  %t388 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etemp(ptr %v0, ptr %t382, i32 %t383, %"compiler/source:Span" %t384)
  store i32 %t388, ptr %l176
  br label %bb63
bb63:
  %t389 = load i32, ptr %l176, !tbaa !23
  store i32 %t389, ptr %l16, !tbaa !23
  %t390 = load ptr, ptr %l0, !tbaa !29
  store ptr %t390, ptr %l177, !tbaa !29
  %t391 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t391, ptr %l178
  %t392 = load i32, ptr %l16, !tbaa !23
  %t394 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t392)
  store %"compiler/mir:Place" %t394, ptr %l180
  br label %bb64
bb64:
  %t395 = load ptr, ptr %l0, !tbaa !29
  %t397 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2econstI64(ptr %v0, ptr %t395, i64 0)
  store { i64, [4 x i64] } %t397, ptr %l182
  br label %bb65
bb65:
  store { i64, [15 x i64] } zeroinitializer, ptr %t398
  %t399 = getelementptr { i64, [15 x i64] }, ptr %t398, i32 0, i32 0
  store i64 0, ptr %t399
  %t400 = load { i64, [4 x i64] }, ptr %l182
  %t401 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t400, 0
  %t402 = getelementptr { i64, [15 x i64] }, ptr %t398, i32 0, i32 1
  store { { i64, [4 x i64] } } %t401, ptr %t402
  %t403 = load { i64, [15 x i64] }, ptr %t398
  store { i64, [21 x i64] } zeroinitializer, ptr %t404
  %t405 = getelementptr { i64, [21 x i64] }, ptr %t404, i32 0, i32 0
  store i64 0, ptr %t405
  %t406 = load %"compiler/source:Span", ptr %l178
  %t407 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t406, 0
  %t408 = load %"compiler/mir:Place", ptr %l180
  %t409 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t407, %"compiler/mir:Place" %t408, 1
  %t411 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t409, { i64, [15 x i64] } %t403, 2
  %t412 = getelementptr { i64, [21 x i64] }, ptr %t404, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t411, ptr %t412
  %t413 = load { i64, [21 x i64] }, ptr %t404
  %t415 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t413, ptr %t415
  %t416 = load ptr, ptr %l177, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %t416, ptr %t415)
  br label %bb66
bb66:
  %t418 = load ptr, ptr %l0, !tbaa !29
  %t420 = getelementptr %"compiler/lower:lowering", ptr %t418, i32 0, i32 14
  store ptr %t420, ptr %l187, !tbaa !29
  %t421 = load i32, ptr %l14, !tbaa !23
  %t422 = load i32, ptr %l16, !tbaa !23
  %t423 = load i32, ptr %l6, !tbaa !23
  %t424 = load i32, ptr %l7, !tbaa !23
  %t425 = load { i64, [1 x i64] }, ptr %l15
  %t431 = call %"compiler/lower:collectCtx" @compiler_2flower_3acollectCtx_2ector(ptr %s0, i32 %t421, i32 %t422, i32 %t423, i32 %t424, { i64, [1 x i64] } %t425, i1 false, i1 true)
  store %"compiler/lower:collectCtx" %t431, ptr %l193
  br label %bb67
bb67:
  %t432 = load ptr, ptr %l187, !tbaa !29
  %t433 = load %"compiler/lower:collectCtx", ptr %l193
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3acollectCtx_3e_2ePus_Hd0ab7b9373bf150d973fdf7c33c4c364(ptr %v0, ptr %t432, %"compiler/lower:collectCtx" %t433)
  br label %bb68
bb68:
  %t434 = load ptr, ptr %l0, !tbaa !29
  %t435 = load ptr, ptr %l1, !tbaa !29
  %t437 = getelementptr %"compiler/typed:Collect", ptr %t435, i32 0, i32 1
  %t438 = load ptr, ptr %t437, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eblock(ptr %v0, ptr %v1, ptr %t434, ptr %t438)
  br label %bb69
bb69:
  %t441 = load ptr, ptr %l0, !tbaa !29
  %t443 = getelementptr %"compiler/lower:lowering", ptr %t441, i32 0, i32 14
  %t445 = call { i32, %"compiler/lower:collectCtx" } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3acollectCtx_3e_2ePop_He1200c0c51a1e2029459d9d8221d233c(ptr %v0, ptr %t443)
  %t446 = extractvalue { i32, %"compiler/lower:collectCtx" } %t445, 1
  %t447 = extractvalue { i32, %"compiler/lower:collectCtx" } %t445, 0
  store i32 %t447, ptr %l201
  %t448 = icmp ne i32 %t447, 0
  br i1 %t448, label %bb71, label %ok.449
ok.449:
  store %"compiler/lower:collectCtx" %t446, ptr %l200
  br label %bb70
bb70:
  %t450 = load %"compiler/lower:collectCtx", ptr %l200
  store %"compiler/lower:collectCtx" %t450, ptr %l197
  br label %bb73
bb71:
  br label %bb72
bb72:
  call void @__olang_ert_req_clear()
  br label %bb73
bb73:
  %t451 = load ptr, ptr %l0, !tbaa !29
  %t453 = getelementptr %"compiler/lower:lowering", ptr %t451, i32 0, i32 7
  %t454 = load i1, ptr %t453, !tbaa !21
  br i1 %t454, label %bb74, label %bb75
bb74:
  store { i64, [4 x i64] } zeroinitializer, ptr %t456
  %t457 = getelementptr { i64, [4 x i64] }, ptr %t456, i32 0, i32 0
  store i64 0, ptr %t457
  %t458 = load { i64, [4 x i64] }, ptr %t456
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t458, ptr %rv
  br label %ret
bb75:
  br label %bb76
bb76:
  %t460 = load ptr, ptr %l0, !tbaa !29
  %t461 = load i32, ptr %l2, !tbaa !23
  %t462 = load %"compiler/source:Span", ptr %l3
  %t466 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etemp(ptr %v0, ptr %t460, i32 %t461, %"compiler/source:Span" %t462)
  store i32 %t466, ptr %l208
  br label %bb77
bb77:
  %t467 = load i32, ptr %l208, !tbaa !23
  store i32 %t467, ptr %l17, !tbaa !23
  %t468 = load ptr, ptr %l0, !tbaa !29
  store ptr %t468, ptr %l209, !tbaa !29
  %t469 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t469, ptr %l210
  %t470 = load i32, ptr %l17, !tbaa !23
  %t472 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t470)
  store %"compiler/mir:Place" %t472, ptr %l212
  br label %bb78
bb78:
  %t473 = load ptr, ptr %l0, !tbaa !29
  %t474 = load ptr, ptr %l1, !tbaa !29
  %t476 = getelementptr %"compiler/typed:Collect", ptr %t474, i32 0, i32 2
  %t477 = load i32, ptr %t476, !tbaa !23
  %t480 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2emadeAt(ptr %v0, ptr %t473, i32 %t477)
  store { i64, [1 x i64] } %t480, ptr %l216
  br label %bb79
bb79:
  %t481 = load i32, ptr %l2, !tbaa !23
  store i32 %t481, ptr %l217, !tbaa !23
  %t482 = load i32, ptr %l16, !tbaa !23
  %t484 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t482)
  store %"compiler/mir:Place" %t484, ptr %l219
  br label %bb80
bb80:
  store { i64, [4 x i64] } zeroinitializer, ptr %t485
  %t486 = getelementptr { i64, [4 x i64] }, ptr %t485, i32 0, i32 0
  store i64 1, ptr %t486
  %t487 = load %"compiler/mir:Place", ptr %l219
  %t488 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t487, 0
  %t489 = getelementptr { i64, [4 x i64] }, ptr %t485, i32 0, i32 1
  store { %"compiler/mir:Place" } %t488, ptr %t489
  %t490 = load { i64, [4 x i64] }, ptr %t485
  %t491 = load i32, ptr %l6, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t492
  %t493 = getelementptr { i64, [4 x i64] }, ptr %t492, i32 0, i32 0
  store i64 2, ptr %t493
  %t495 = insertvalue { i32, i64 } undef, i32 %t491, 0
  %t496 = insertvalue { i32, i64 } %t495, i64 0, 1
  %t497 = getelementptr { i64, [4 x i64] }, ptr %t492, i32 0, i32 1
  store { i32, i64 } %t496, ptr %t497
  %t498 = load { i64, [4 x i64] }, ptr %t492
  store { i64, [15 x i64] } zeroinitializer, ptr %t499
  %t500 = getelementptr { i64, [15 x i64] }, ptr %t499, i32 0, i32 0
  store i64 8, ptr %t500
  %t501 = load { i64, [1 x i64] }, ptr %l216
  %t502 = insertvalue { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } undef, { i64, [1 x i64] } %t501, 0
  %t503 = load i32, ptr %l217, !tbaa !23
  %t504 = insertvalue { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } %t502, i32 %t503, 1
  %t506 = insertvalue { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } %t504, { i64, [4 x i64] } %t490, 2
  %t508 = insertvalue { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } %t506, { i64, [4 x i64] } %t498, 3
  %t509 = getelementptr { i64, [15 x i64] }, ptr %t499, i32 0, i32 1
  store { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } %t508, ptr %t509
  %t510 = load { i64, [15 x i64] }, ptr %t499
  store { i64, [21 x i64] } zeroinitializer, ptr %t511
  %t512 = getelementptr { i64, [21 x i64] }, ptr %t511, i32 0, i32 0
  store i64 0, ptr %t512
  %t513 = load %"compiler/source:Span", ptr %l210
  %t514 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t513, 0
  %t515 = load %"compiler/mir:Place", ptr %l212
  %t516 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t514, %"compiler/mir:Place" %t515, 1
  %t518 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t516, { i64, [15 x i64] } %t510, 2
  %t519 = getelementptr { i64, [21 x i64] }, ptr %t511, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t518, ptr %t519
  %t520 = load { i64, [21 x i64] }, ptr %t511
  %t522 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t520, ptr %t522
  %t523 = load ptr, ptr %l209, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %t523, ptr %t522)
  br label %bb81
bb81:
  %t525 = load ptr, ptr %l0, !tbaa !29
  %t527 = getelementptr %"compiler/lower:lowering", ptr %t525, i32 0, i32 3
  store ptr %t527, ptr %l227, !tbaa !29
  %t528 = load i32, ptr %l17, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t529
  %t530 = getelementptr { i64, [2 x i64] }, ptr %t529, i32 0, i32 0
  store i64 1, ptr %t530
  %t532 = insertvalue { i32 } undef, i32 %t528, 0
  %t533 = getelementptr { i64, [2 x i64] }, ptr %t529, i32 0, i32 1
  store { i32 } %t532, ptr %t533
  %t534 = load { i64, [2 x i64] }, ptr %t529
  store { i64, [2 x i64] } %t534, ptr %l229
  %t535 = load ptr, ptr %l4, !tbaa !29
  store ptr %t535, ptr %l230, !tbaa !29
  %t536 = load ptr, ptr %l4, !tbaa !29
  %t537 = load i32, ptr %l2, !tbaa !23
  %t540 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t536, i32 %t537)
  store i32 %t540, ptr %l233
  br label %bb82
bb82:
  %t541 = load ptr, ptr %l230, !tbaa !29
  %t542 = load i32, ptr %l233, !tbaa !23
  %t543 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t541, i32 %t542)
  store i1 %t543, ptr %l234
  br label %bb83
bb83:
  %t544 = load i1, ptr %l234, !tbaa !21
  br i1 %t544, label %bb84, label %bb85
bb84:
  store { i64, [1 x i64] } zeroinitializer, ptr %t545
  %t546 = getelementptr { i64, [1 x i64] }, ptr %t545, i32 0, i32 0
  store i64 3, ptr %t546
  %t547 = load { i64, [1 x i64] }, ptr %t545
  %t548 = mul i64 1, 16
  %t549 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t548)
  %t550 = insertvalue { i64, ptr } undef, i64 1, 0
  %t551 = insertvalue { i64, ptr } %t550, ptr %t549, 1
  store { i64, ptr } %t551, ptr %l237, !tbaa !27
  %t553 = getelementptr { i64, ptr }, ptr %l237, i32 0, i32 1
  %t554 = load ptr, ptr %t553, !tbaa !27
  %t555 = getelementptr { i64, [1 x i64] }, ptr %t554, i64 0
  store { i64, [1 x i64] } %t547, ptr %t555
  %t556 = load { i64, ptr }, ptr %l237, !tbaa !27
  store { i64, ptr } %t556, ptr %l235, !tbaa !27
  br label %bb86
bb85:
  %t557 = mul i64 0, 16
  %t558 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t557)
  %t559 = insertvalue { i64, ptr } undef, i64 0, 0
  %t560 = insertvalue { i64, ptr } %t559, ptr %t558, 1
  store { i64, ptr } %t560, ptr %l235, !tbaa !27
  br label %bb86
bb86:
  %t562 = load ptr, ptr %l227, !tbaa !29
  %t563 = load { i64, [2 x i64] }, ptr %l229
  %t564 = load { i64, ptr }, ptr %l235, !tbaa !27
  %t565 = call %"compiler/mir:Place" @compiler_2fmir_2ecompiler_2fmir_3aFn_2ePlace(ptr %v0, ptr %s0, ptr %t562, { i64, [2 x i64] } %t563, { i64, ptr } %t564)
  store %"compiler/mir:Place" %t565, ptr %l239
  br label %bb87
bb87:
  %t566 = load %"compiler/mir:Place", ptr %l239
  %t567 = load ptr, ptr %l0, !tbaa !29
  store ptr %t567, ptr %l240, !tbaa !29
  %t568 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t568, ptr %l241
  store %"compiler/mir:Place" %t566, ptr %l242
  %t570 = load ptr, ptr %l0, !tbaa !29
  %t572 = getelementptr %"compiler/lower:lowering", ptr %t570, i32 0, i32 3
  %t573 = load i32, ptr %l14, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t574
  %t575 = getelementptr { i64, [2 x i64] }, ptr %t574, i32 0, i32 0
  store i64 1, ptr %t575
  %t577 = insertvalue { i32 } undef, i32 %t573, 0
  %t578 = getelementptr { i64, [2 x i64] }, ptr %t574, i32 0, i32 1
  store { i32 } %t577, ptr %t578
  %t579 = load { i64, [2 x i64] }, ptr %t574
  store { i64, [1 x i64] } zeroinitializer, ptr %t580
  %t581 = getelementptr { i64, [1 x i64] }, ptr %t580, i32 0, i32 0
  store i64 3, ptr %t581
  %t582 = load { i64, [1 x i64] }, ptr %t580
  %t583 = mul i64 1, 16
  %t584 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t583)
  %t585 = insertvalue { i64, ptr } undef, i64 1, 0
  %t586 = insertvalue { i64, ptr } %t585, ptr %t584, 1
  store { i64, ptr } %t586, ptr %l248, !tbaa !27
  %t588 = getelementptr { i64, ptr }, ptr %l248, i32 0, i32 1
  %t589 = load ptr, ptr %t588, !tbaa !27
  %t590 = getelementptr { i64, [1 x i64] }, ptr %t589, i64 0
  store { i64, [1 x i64] } %t582, ptr %t590
  %t593 = load { i64, ptr }, ptr %l248, !tbaa !27
  %t594 = call %"compiler/mir:Place" @compiler_2fmir_2ecompiler_2fmir_3aFn_2ePlace(ptr %v0, ptr %s0, ptr %t572, { i64, [2 x i64] } %t579, { i64, ptr } %t593)
  store %"compiler/mir:Place" %t594, ptr %l249
  br label %bb88
bb88:
  %t595 = load i32, ptr %l16, !tbaa !23
  %t597 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t595)
  store %"compiler/mir:Place" %t597, ptr %l251
  br label %bb89
bb89:
  store { i64, [4 x i64] } zeroinitializer, ptr %t598
  %t599 = getelementptr { i64, [4 x i64] }, ptr %t598, i32 0, i32 0
  store i64 1, ptr %t599
  %t600 = load %"compiler/mir:Place", ptr %l251
  %t601 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t600, 0
  %t602 = getelementptr { i64, [4 x i64] }, ptr %t598, i32 0, i32 1
  store { %"compiler/mir:Place" } %t601, ptr %t602
  %t603 = load { i64, [4 x i64] }, ptr %t598
  store { i64, [21 x i64] } zeroinitializer, ptr %t604
  %t605 = getelementptr { i64, [21 x i64] }, ptr %t604, i32 0, i32 0
  store i64 10, ptr %t605
  %t606 = load %"compiler/source:Span", ptr %l241
  %t607 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", %"compiler/mir:Place", { i64, [4 x i64] } } undef, %"compiler/source:Span" %t606, 0
  %t608 = load %"compiler/mir:Place", ptr %l242
  %t609 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", %"compiler/mir:Place", { i64, [4 x i64] } } %t607, %"compiler/mir:Place" %t608, 1
  %t610 = load %"compiler/mir:Place", ptr %l249
  %t611 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", %"compiler/mir:Place", { i64, [4 x i64] } } %t609, %"compiler/mir:Place" %t610, 2
  %t613 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", %"compiler/mir:Place", { i64, [4 x i64] } } %t611, { i64, [4 x i64] } %t603, 3
  %t614 = getelementptr { i64, [21 x i64] }, ptr %t604, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Place", %"compiler/mir:Place", { i64, [4 x i64] } } %t613, ptr %t614
  %t615 = load { i64, [21 x i64] }, ptr %t604
  %t617 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t615, ptr %t617
  %t618 = load ptr, ptr %l240, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %t618, ptr %t617)
  br label %bb90
bb90:
  %t620 = load i32, ptr %l17, !tbaa !23
  %t622 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t620)
  store %"compiler/mir:Place" %t622, ptr %l256
  br label %bb91
bb91:
  store { i64, [4 x i64] } zeroinitializer, ptr %t623
  %t624 = getelementptr { i64, [4 x i64] }, ptr %t623, i32 0, i32 0
  store i64 1, ptr %t624
  %t625 = load %"compiler/mir:Place", ptr %l256
  %t626 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t625, 0
  %t627 = getelementptr { i64, [4 x i64] }, ptr %t623, i32 0, i32 1
  store { %"compiler/mir:Place" } %t626, ptr %t627
  %t628 = load { i64, [4 x i64] }, ptr %t623
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t628, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2econd(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca { i64, [4 x i64] }
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l9 = alloca { i64, [4 x i64] }
  %l10 = alloca { i64, [4 x i64] }
  %l15 = alloca { i64, [4 x i64] }
  %l22 = alloca i32
  %l25 = alloca i32
  %l28 = alloca i32
  %l34 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l40 = alloca { i64, [4 x i64] }
  %l41 = alloca ptr
  %l42 = alloca %"compiler/source:Span"
  %l44 = alloca %"compiler/mir:Place"
  %l57 = alloca { i64, [4 x i64] }
  %l58 = alloca ptr
  %l59 = alloca %"compiler/source:Span"
  %l61 = alloca %"compiler/mir:Place"
  %l71 = alloca %"compiler/mir:Place"
  %s0 = alloca %olang.scope
  %rv = alloca { i64, [4 x i64] }
  %t16 = alloca { i64, [4 x i64] }, align 8
  %t44 = alloca { i64, [8 x i64] }, align 8
  %t77 = alloca { i64, [15 x i64] }, align 8
  %t83 = alloca { i64, [21 x i64] }, align 8
  %t120 = alloca { i64, [15 x i64] }, align 8
  %t126 = alloca { i64, [21 x i64] }, align 8
  %t150 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t4 = getelementptr %"compiler/typed:Cond", ptr %t2, i32 0, i32 0
  %t5 = load ptr, ptr %t4, !tbaa !29
  %t9 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %t1, ptr %t5)
  store { i64, [4 x i64] } %t9, ptr %l15
  br label %bb1
bb1:
  %t10 = load { i64, [4 x i64] }, ptr %l15
  store { i64, [4 x i64] } %t10, ptr %l4
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/lower:lowering", ptr %t11, i32 0, i32 7
  %t14 = load i1, ptr %t13, !tbaa !21
  br i1 %t14, label %bb2, label %bb3
bb2:
  store { i64, [4 x i64] } zeroinitializer, ptr %t16
  %t17 = getelementptr { i64, [4 x i64] }, ptr %t16, i32 0, i32 0
  store i64 0, ptr %t17
  %t18 = load { i64, [4 x i64] }, ptr %t16
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t18, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = load %"compiler/source:Span", ptr %l3
  %t26 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etemp(ptr %v0, ptr %t20, i32 %a2, %"compiler/source:Span" %t22)
  store i32 %t26, ptr %l22
  br label %bb5
bb5:
  %t27 = load i32, ptr %l22, !tbaa !23
  store i32 %t27, ptr %l5, !tbaa !23
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/lower:lowering", ptr %t28, i32 0, i32 3
  %t32 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t30)
  store i32 %t32, ptr %l25
  br label %bb6
bb6:
  %t33 = load i32, ptr %l25, !tbaa !23
  store i32 %t33, ptr %l6, !tbaa !23
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/lower:lowering", ptr %t34, i32 0, i32 3
  %t38 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t36)
  store i32 %t38, ptr %l28
  br label %bb7
bb7:
  %t39 = load i32, ptr %l28, !tbaa !23
  store i32 %t39, ptr %l7, !tbaa !23
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load { i64, [4 x i64] }, ptr %l4
  %t42 = load i32, ptr %l6, !tbaa !23
  %t43 = load i32, ptr %l7, !tbaa !23
  store { i64, [8 x i64] } zeroinitializer, ptr %t44
  %t45 = getelementptr { i64, [8 x i64] }, ptr %t44, i32 0, i32 0
  store i64 2, ptr %t45
  %t47 = insertvalue { { i64, [4 x i64] }, i32, i32 } undef, { i64, [4 x i64] } %t41, 0
  %t49 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t47, i32 %t42, 1
  %t51 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t49, i32 %t43, 2
  %t52 = getelementptr { i64, [8 x i64] }, ptr %t44, i32 0, i32 1
  store { { i64, [4 x i64] }, i32, i32 } %t51, ptr %t52
  %t53 = load { i64, [8 x i64] }, ptr %t44
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t40, { i64, [8 x i64] } %t53)
  br label %bb8
bb8:
  %t56 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t56, ptr %l34
  br label %bb9
bb9:
  %t57 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l34
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t57, ptr %l8
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load i32, ptr %l6, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t58, i32 %t59)
  br label %bb10
bb10:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load ptr, ptr %l1, !tbaa !29
  %t65 = getelementptr %"compiler/typed:Cond", ptr %t63, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t69 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %t62, ptr %t66)
  store { i64, [4 x i64] } %t69, ptr %l40
  br label %bb11
bb11:
  %t70 = load { i64, [4 x i64] }, ptr %l40
  store { i64, [4 x i64] } %t70, ptr %l9
  %t71 = load ptr, ptr %l0, !tbaa !29
  store ptr %t71, ptr %l41, !tbaa !29
  %t72 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t72, ptr %l42
  %t73 = load i32, ptr %l5, !tbaa !23
  %t75 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t73)
  store %"compiler/mir:Place" %t75, ptr %l44
  br label %bb12
bb12:
  %t76 = load { i64, [4 x i64] }, ptr %l9
  store { i64, [15 x i64] } zeroinitializer, ptr %t77
  %t78 = getelementptr { i64, [15 x i64] }, ptr %t77, i32 0, i32 0
  store i64 0, ptr %t78
  %t80 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t76, 0
  %t81 = getelementptr { i64, [15 x i64] }, ptr %t77, i32 0, i32 1
  store { { i64, [4 x i64] } } %t80, ptr %t81
  %t82 = load { i64, [15 x i64] }, ptr %t77
  store { i64, [21 x i64] } zeroinitializer, ptr %t83
  %t84 = getelementptr { i64, [21 x i64] }, ptr %t83, i32 0, i32 0
  store i64 0, ptr %t84
  %t85 = load %"compiler/source:Span", ptr %l42
  %t86 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t85, 0
  %t87 = load %"compiler/mir:Place", ptr %l44
  %t88 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t86, %"compiler/mir:Place" %t87, 1
  %t90 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t88, { i64, [15 x i64] } %t82, 2
  %t91 = getelementptr { i64, [21 x i64] }, ptr %t83, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t90, ptr %t91
  %t92 = load { i64, [21 x i64] }, ptr %t83
  %t94 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t92, ptr %t94
  %t95 = load ptr, ptr %l41, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %t95, ptr %t94)
  br label %bb13
bb13:
  %t97 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eleaveOpen(ptr %v0, ptr %s0, ptr %t97, ptr %l8)
  br label %bb14
bb14:
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t101 = load i32, ptr %l7, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t100, i32 %t101)
  br label %bb15
bb15:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t105 = load ptr, ptr %l1, !tbaa !29
  %t107 = getelementptr %"compiler/typed:Cond", ptr %t105, i32 0, i32 2
  %t108 = load ptr, ptr %t107, !tbaa !29
  %t112 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %t104, ptr %t108)
  store { i64, [4 x i64] } %t112, ptr %l57
  br label %bb16
bb16:
  %t113 = load { i64, [4 x i64] }, ptr %l57
  store { i64, [4 x i64] } %t113, ptr %l10
  %t114 = load ptr, ptr %l0, !tbaa !29
  store ptr %t114, ptr %l58, !tbaa !29
  %t115 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t115, ptr %l59
  %t116 = load i32, ptr %l5, !tbaa !23
  %t118 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t116)
  store %"compiler/mir:Place" %t118, ptr %l61
  br label %bb17
bb17:
  %t119 = load { i64, [4 x i64] }, ptr %l10
  store { i64, [15 x i64] } zeroinitializer, ptr %t120
  %t121 = getelementptr { i64, [15 x i64] }, ptr %t120, i32 0, i32 0
  store i64 0, ptr %t121
  %t123 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t119, 0
  %t124 = getelementptr { i64, [15 x i64] }, ptr %t120, i32 0, i32 1
  store { { i64, [4 x i64] } } %t123, ptr %t124
  %t125 = load { i64, [15 x i64] }, ptr %t120
  store { i64, [21 x i64] } zeroinitializer, ptr %t126
  %t127 = getelementptr { i64, [21 x i64] }, ptr %t126, i32 0, i32 0
  store i64 0, ptr %t127
  %t128 = load %"compiler/source:Span", ptr %l59
  %t129 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t128, 0
  %t130 = load %"compiler/mir:Place", ptr %l61
  %t131 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t129, %"compiler/mir:Place" %t130, 1
  %t133 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t131, { i64, [15 x i64] } %t125, 2
  %t134 = getelementptr { i64, [21 x i64] }, ptr %t126, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t133, ptr %t134
  %t135 = load { i64, [21 x i64] }, ptr %t126
  %t137 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t135, ptr %t137
  %t138 = load ptr, ptr %l58, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %t138, ptr %t137)
  br label %bb18
bb18:
  %t140 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eleaveOpen(ptr %v0, ptr %s0, ptr %t140, ptr %l8)
  br label %bb19
bb19:
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t144 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l8
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2epatch(ptr %v0, ptr %s0, ptr %t143, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t144)
  br label %bb20
bb20:
  %t147 = load i32, ptr %l5, !tbaa !23
  %t149 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t147)
  store %"compiler/mir:Place" %t149, ptr %l71
  br label %bb21
bb21:
  store { i64, [4 x i64] } zeroinitializer, ptr %t150
  %t151 = getelementptr { i64, [4 x i64] }, ptr %t150, i32 0, i32 0
  store i64 1, ptr %t151
  %t152 = load %"compiler/mir:Place", ptr %l71
  %t153 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t152, 0
  %t154 = getelementptr { i64, [4 x i64] }, ptr %t150, i32 0, i32 1
  store { %"compiler/mir:Place" } %t153, ptr %t154
  %t155 = load { i64, [4 x i64] }, ptr %t150
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t155, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2econstBool(ptr %v0, ptr %a0, i1 %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l5 = alloca i64
  %rv = alloca { i64, [4 x i64] }
  %t4 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t1, ptr %l3, !tbaa !23
  br i1 %a1, label %bb1, label %bb2
bb1:
  store i64 1, ptr %l5, !tbaa !24
  br label %bb3
bb2:
  store i64 0, ptr %l5, !tbaa !24
  br label %bb3
bb3:
  store { i64, [4 x i64] } zeroinitializer, ptr %t4
  %t5 = getelementptr { i64, [4 x i64] }, ptr %t4, i32 0, i32 0
  store i64 2, ptr %t5
  %t6 = load i32, ptr %l3, !tbaa !23
  %t7 = insertvalue { i32, i64 } undef, i32 %t6, 0
  %t8 = load i64, ptr %l5, !tbaa !24
  %t9 = insertvalue { i32, i64 } %t7, i64 %t8, 1
  %t10 = getelementptr { i64, [4 x i64] }, ptr %t4, i32 0, i32 1
  store { i32, i64 } %t9, ptr %t10
  %t11 = load { i64, [4 x i64] }, ptr %t4
  store { i64, [4 x i64] } %t11, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2eeachIndex(ptr %v0, ptr %v1, ptr %a0, { i64, [4 x i64] } %a1, %"compiler/source:Span" %a2, ptr %a3c, ptr %a3e) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l12 = alloca i32
  %l13 = alloca ptr
  %l14 = alloca %"compiler/source:Span"
  %l16 = alloca %"compiler/mir:Place"
  %l18 = alloca { i64, [4 x i64] }
  %l24 = alloca i32
  %l27 = alloca i32
  %l30 = alloca i32
  %l35 = alloca ptr
  %l36 = alloca i32
  %l37 = alloca i32
  %l39 = alloca %"compiler/mir:Place"
  %l42 = alloca { i64, ptr }
  %l44 = alloca { i64, [4 x i64] }
  %l54 = alloca ptr
  %l55 = alloca %"compiler/source:Span"
  %l57 = alloca %"compiler/mir:Place"
  %l58 = alloca i32
  %l59 = alloca i32
  %l61 = alloca ptr
  %l63 = alloca %"compiler/mir:Place"
  %l64 = alloca { i64, [4 x i64] }
  %l66 = alloca { i64, [4 x i64] }
  %l67 = alloca { i64, ptr }
  %l68 = alloca %"compiler/mir:Range"
  %s0 = alloca %olang.scope
  %t17 = alloca { i64, [15 x i64] }, align 8
  %t23 = alloca { i64, [21 x i64] }, align 8
  %t68 = alloca { i64, [4 x i64] }, align 8
  %t99 = alloca { i64, [8 x i64] }, align 8
  %t133 = alloca { i64, [4 x i64] }, align 8
  %t157 = alloca { i64, [15 x i64] }, align 8
  %t167 = alloca { i64, [21 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a2, ptr %l2
  %pf3 = insertvalue { ptr, ptr } undef, ptr %a3c, 0
  %pg3 = insertvalue { ptr, ptr } %pf3, ptr %a3e, 1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  %t3 = load %"compiler/source:Span", ptr %l2
  %t7 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etemp(ptr %v0, ptr %t1, i32 %t2, %"compiler/source:Span" %t3)
  store i32 %t7, ptr %l12
  br label %bb1
bb1:
  %t8 = load i32, ptr %l12, !tbaa !23
  store i32 %t8, ptr %l4, !tbaa !23
  %t9 = load ptr, ptr %l0, !tbaa !29
  store ptr %t9, ptr %l13, !tbaa !29
  %t10 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t10, ptr %l14
  %t11 = load i32, ptr %l4, !tbaa !23
  %t13 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t11)
  store %"compiler/mir:Place" %t13, ptr %l16
  br label %bb2
bb2:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2econstI64(ptr %v0, ptr %t14, i64 0)
  store { i64, [4 x i64] } %t16, ptr %l18
  br label %bb3
bb3:
  store { i64, [15 x i64] } zeroinitializer, ptr %t17
  %t18 = getelementptr { i64, [15 x i64] }, ptr %t17, i32 0, i32 0
  store i64 0, ptr %t18
  %t19 = load { i64, [4 x i64] }, ptr %l18
  %t20 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t19, 0
  %t21 = getelementptr { i64, [15 x i64] }, ptr %t17, i32 0, i32 1
  store { { i64, [4 x i64] } } %t20, ptr %t21
  %t22 = load { i64, [15 x i64] }, ptr %t17
  store { i64, [21 x i64] } zeroinitializer, ptr %t23
  %t24 = getelementptr { i64, [21 x i64] }, ptr %t23, i32 0, i32 0
  store i64 0, ptr %t24
  %t25 = load %"compiler/source:Span", ptr %l14
  %t26 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t25, 0
  %t27 = load %"compiler/mir:Place", ptr %l16
  %t28 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t26, %"compiler/mir:Place" %t27, 1
  %t30 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t28, { i64, [15 x i64] } %t22, 2
  %t31 = getelementptr { i64, [21 x i64] }, ptr %t23, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t30, ptr %t31
  %t32 = load { i64, [21 x i64] }, ptr %t23
  %t34 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t32, ptr %t34
  %t35 = load ptr, ptr %l13, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %t35, ptr %t34)
  br label %bb4
bb4:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/lower:lowering", ptr %t37, i32 0, i32 3
  %t41 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t39)
  store i32 %t41, ptr %l24
  br label %bb5
bb5:
  %t42 = load i32, ptr %l24, !tbaa !23
  store i32 %t42, ptr %l5, !tbaa !23
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/lower:lowering", ptr %t43, i32 0, i32 3
  %t47 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t45)
  store i32 %t47, ptr %l27
  br label %bb6
bb6:
  %t48 = load i32, ptr %l27, !tbaa !23
  store i32 %t48, ptr %l6, !tbaa !23
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/lower:lowering", ptr %t49, i32 0, i32 3
  %t53 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t51)
  store i32 %t53, ptr %l30
  br label %bb7
bb7:
  %t54 = load i32, ptr %l30, !tbaa !23
  store i32 %t54, ptr %l7, !tbaa !23
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = load i32, ptr %l5, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2egoto(ptr %v0, ptr %t55, i32 %t56)
  br label %bb8
bb8:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = load i32, ptr %l5, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t59, i32 %t60)
  br label %bb9
bb9:
  %t63 = load ptr, ptr %l0, !tbaa !29
  store ptr %t63, ptr %l35, !tbaa !29
  store i32 15, ptr %l36
  %t64 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t64, ptr %l37, !tbaa !23
  %t65 = load i32, ptr %l4, !tbaa !23
  %t67 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t65)
  store %"compiler/mir:Place" %t67, ptr %l39
  br label %bb10
bb10:
  store { i64, [4 x i64] } zeroinitializer, ptr %t68
  %t69 = getelementptr { i64, [4 x i64] }, ptr %t68, i32 0, i32 0
  store i64 1, ptr %t69
  %t70 = load %"compiler/mir:Place", ptr %l39
  %t71 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t70, 0
  %t72 = getelementptr { i64, [4 x i64] }, ptr %t68, i32 0, i32 1
  store { %"compiler/mir:Place" } %t71, ptr %t72
  %t73 = load { i64, [4 x i64] }, ptr %t68
  %t75 = mul i64 2, 40
  %t76 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t75)
  %t77 = insertvalue { i64, ptr } undef, i64 2, 0
  %t78 = insertvalue { i64, ptr } %t77, ptr %t76, 1
  store { i64, ptr } %t78, ptr %l42, !tbaa !27
  %t80 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t81 = load ptr, ptr %t80, !tbaa !27
  %t82 = getelementptr { i64, [4 x i64] }, ptr %t81, i64 0
  store { i64, [4 x i64] } %t73, ptr %t82
  %t84 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !27
  %t86 = getelementptr { i64, [4 x i64] }, ptr %t85, i64 1
  store { i64, [4 x i64] } %a1, ptr %t86
  %t87 = load %"compiler/source:Span", ptr %l2
  %t88 = load ptr, ptr %l35, !tbaa !29
  %t89 = load i32, ptr %l36
  %t90 = load i32, ptr %l37, !tbaa !23
  %t91 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t93 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s0, ptr %t88, i32 %t89, i32 %t90, { i64, ptr } %t91, %"compiler/source:Span" %t87)
  store { i64, [4 x i64] } %t93, ptr %l44
  br label %bb11
bb11:
  %t94 = load { i64, [4 x i64] }, ptr %l44
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = load i32, ptr %l6, !tbaa !23
  %t98 = load i32, ptr %l7, !tbaa !23
  store { i64, [8 x i64] } zeroinitializer, ptr %t99
  %t100 = getelementptr { i64, [8 x i64] }, ptr %t99, i32 0, i32 0
  store i64 2, ptr %t100
  %t102 = insertvalue { { i64, [4 x i64] }, i32, i32 } undef, { i64, [4 x i64] } %t94, 0
  %t104 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t102, i32 %t97, 1
  %t106 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t104, i32 %t98, 2
  %t107 = getelementptr { i64, [8 x i64] }, ptr %t99, i32 0, i32 1
  store { { i64, [4 x i64] }, i32, i32 } %t106, ptr %t107
  %t108 = load { i64, [8 x i64] }, ptr %t99
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t95, { i64, [8 x i64] } %t108)
  br label %bb12
bb12:
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t112 = load i32, ptr %l6, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t111, i32 %t112)
  br label %bb13
bb13:
  %t116 = load i32, ptr %l4, !tbaa !23
  %t118 = extractvalue { ptr, ptr } %pg3, 0
  %t119 = extractvalue { ptr, ptr } %pg3, 1
  call void %t118(ptr %t119, i32 %t116)
  br label %bb14
bb14:
  %t121 = load ptr, ptr %l0, !tbaa !29
  store ptr %t121, ptr %l54, !tbaa !29
  %t122 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t122, ptr %l55
  %t123 = load i32, ptr %l4, !tbaa !23
  %t125 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t123)
  store %"compiler/mir:Place" %t125, ptr %l57
  br label %bb15
bb15:
  store i32 3, ptr %l58
  %t126 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  store i32 %t126, ptr %l59, !tbaa !23
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t129 = getelementptr %"compiler/lower:lowering", ptr %t127, i32 0, i32 3
  store ptr %t129, ptr %l61, !tbaa !29
  %t130 = load i32, ptr %l4, !tbaa !23
  %t132 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t130)
  store %"compiler/mir:Place" %t132, ptr %l63
  br label %bb16
bb16:
  store { i64, [4 x i64] } zeroinitializer, ptr %t133
  %t134 = getelementptr { i64, [4 x i64] }, ptr %t133, i32 0, i32 0
  store i64 1, ptr %t134
  %t135 = load %"compiler/mir:Place", ptr %l63
  %t136 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t135, 0
  %t137 = getelementptr { i64, [4 x i64] }, ptr %t133, i32 0, i32 1
  store { %"compiler/mir:Place" } %t136, ptr %t137
  %t138 = load { i64, [4 x i64] }, ptr %t133
  store { i64, [4 x i64] } %t138, ptr %l64
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t141 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2econstI64(ptr %v0, ptr %t139, i64 1)
  store { i64, [4 x i64] } %t141, ptr %l66
  br label %bb17
bb17:
  %t142 = mul i64 2, 40
  %t143 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t142)
  %t144 = insertvalue { i64, ptr } undef, i64 2, 0
  %t145 = insertvalue { i64, ptr } %t144, ptr %t143, 1
  store { i64, ptr } %t145, ptr %l67, !tbaa !27
  %t146 = load { i64, [4 x i64] }, ptr %l64
  %t147 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t148 = load ptr, ptr %t147, !tbaa !27
  %t149 = getelementptr { i64, [4 x i64] }, ptr %t148, i64 0
  store { i64, [4 x i64] } %t146, ptr %t149
  %t150 = load { i64, [4 x i64] }, ptr %l66
  %t151 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t152 = load ptr, ptr %t151, !tbaa !27
  %t153 = getelementptr { i64, [4 x i64] }, ptr %t152, i64 1
  store { i64, [4 x i64] } %t150, ptr %t153
  %t154 = load ptr, ptr %l61, !tbaa !29
  %t155 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t156 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v0, ptr %s0, ptr %t154, { i64, ptr } %t155)
  store %"compiler/mir:Range" %t156, ptr %l68
  br label %bb18
bb18:
  store { i64, [15 x i64] } zeroinitializer, ptr %t157
  %t158 = getelementptr { i64, [15 x i64] }, ptr %t157, i32 0, i32 0
  store i64 3, ptr %t158
  %t159 = load i32, ptr %l58
  %t160 = insertvalue { i32, i32, %"compiler/mir:Range" } undef, i32 %t159, 0
  %t161 = load i32, ptr %l59, !tbaa !23
  %t162 = insertvalue { i32, i32, %"compiler/mir:Range" } %t160, i32 %t161, 1
  %t163 = load %"compiler/mir:Range", ptr %l68
  %t164 = insertvalue { i32, i32, %"compiler/mir:Range" } %t162, %"compiler/mir:Range" %t163, 2
  %t165 = getelementptr { i64, [15 x i64] }, ptr %t157, i32 0, i32 1
  store { i32, i32, %"compiler/mir:Range" } %t164, ptr %t165
  %t166 = load { i64, [15 x i64] }, ptr %t157
  store { i64, [21 x i64] } zeroinitializer, ptr %t167
  %t168 = getelementptr { i64, [21 x i64] }, ptr %t167, i32 0, i32 0
  store i64 0, ptr %t168
  %t169 = load %"compiler/source:Span", ptr %l55
  %t170 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t169, 0
  %t171 = load %"compiler/mir:Place", ptr %l57
  %t172 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t170, %"compiler/mir:Place" %t171, 1
  %t174 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t172, { i64, [15 x i64] } %t166, 2
  %t175 = getelementptr { i64, [21 x i64] }, ptr %t167, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t174, ptr %t175
  %t176 = load { i64, [21 x i64] }, ptr %t167
  %t178 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t176, ptr %t178
  %t179 = load ptr, ptr %l54, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %t179, ptr %t178)
  br label %bb19
bb19:
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t182 = load i32, ptr %l5, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2egoto(ptr %v0, ptr %t181, i32 %t182)
  br label %bb20
bb20:
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t186 = load i32, ptr %l7, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t185, i32 %t186)
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2eevalStmt(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i1
  %l8 = alloca { i64, [4 x i64] }
  %l10 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l11 = alloca ptr
  %l12 = alloca i1
  %l19 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l21 = alloca ptr
  %l24 = alloca i1
  %l36 = alloca i64
  %l39 = alloca i1
  %l48 = alloca i1
  %l51 = alloca i1
  %l53 = alloca i1
  %l54 = alloca ptr
  %l56 = alloca i64
  %l60 = alloca { i64, [4 x i64] }
  %l63 = alloca ptr
  %l65 = alloca { i64, ptr }
  %l66 = alloca { i64, ptr }
  %l74 = alloca { i64, [4 x i64] }
  %l76 = alloca i64
  %l78 = alloca i1
  %l81 = alloca ptr
  %l82 = alloca { i64, [4 x i64] }
  %l84 = alloca i32
  %l86 = alloca i32
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l10
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l10
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l3
  %t3 = load ptr, ptr %l2, !tbaa !29
  store ptr %t3, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t4 = load ptr, ptr %l11, !tbaa !29
  %t5 = icmp ne ptr %t4, null
  br i1 %t5, label %bb2, label %bb3
bb2:
  %t7 = load ptr, ptr %l11, !tbaa !29
  %t8 = load i64, ptr %t7
  %t10 = icmp eq i64 %t8, 4
  store i1 %t10, ptr %l12, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l12, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  %t12 = load ptr, ptr %l2, !tbaa !29
  %t14 = getelementptr { i64, [5 x i64] }, ptr %t12, i32 0, i32 1
  %t15 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t14, i32 0, i32 2
  %t16 = load ptr, ptr %t15
  store ptr %t16, ptr %l4, !tbaa !29
  br label %bb6
bb5:
  br label %bb8
bb6:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load ptr, ptr %l4, !tbaa !29
  %t22 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2flower_2ecompiler_2flower_3alowering_2ereleases(ptr %v0, ptr %v1, ptr %s0, ptr %t18, ptr %t19, i1 false)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t22, ptr %l19
  br label %bb7
bb7:
  %t23 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l19
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t23, ptr %l3
  br label %bb53
bb8:
  br i1 true, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb52
bb11:
  %t24 = load ptr, ptr %l2, !tbaa !29
  %t26 = call ptr @compiler_2flower_2ecallOfExpr(ptr %v1, ptr %t24)
  store ptr %t26, ptr %l21
  br label %bb12
bb12:
  %t27 = load ptr, ptr %l21, !tbaa !29
  store ptr %t27, ptr %l5, !tbaa !29
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/lower:lowering", ptr %t28, i32 0, i32 23
  %t31 = load i1, ptr %t30, !tbaa !21
  br i1 %t31, label %bb13, label %bb14
bb13:
  %t33 = load ptr, ptr %l5, !tbaa !29
  %t35 = icmp eq ptr %t33, null
  %t37 = xor i1 %t35, true
  store i1 %t37, ptr %l24, !tbaa !21
  br label %bb15
bb14:
  store i1 false, ptr %l24, !tbaa !21
  br label %bb15
bb15:
  %t39 = load i1, ptr %l24, !tbaa !21
  br i1 %t39, label %bb16, label %bb17
bb16:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/lower:lowering", ptr %t40, i32 0, i32 0
  %t43 = load ptr, ptr %t42, !tbaa !29
  %t45 = getelementptr %"compiler/lower:Lowerer", ptr %t43, i32 0, i32 3
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t48 = icmp eq ptr %t46, null
  br i1 %t48, label %bb18, label %bb19
bb17:
  br label %bb51
bb18:
  call void @__olang_check_failed(ptr @olang_loc_190a01ede4622abe_5dffdf8c82030ba2)
  unreachable
bb19:
  br label %bb20
bb20:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/lower:lowering", ptr %t50, i32 0, i32 0
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t55 = getelementptr %"compiler/lower:Lowerer", ptr %t53, i32 0, i32 3
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t57 = load ptr, ptr %l5, !tbaa !29
  %t60 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eDroppedMove(ptr %v0, ptr %v1, ptr %t56, ptr %t57)
  store i64 %t60, ptr %l36
  br label %bb21
bb21:
  %t61 = load i64, ptr %l36, !tbaa !24
  store i64 %t61, ptr %l6, !tbaa !24
  %t62 = load i64, ptr %l6, !tbaa !24
  %t64 = icmp sge i64 %t62, 0
  br i1 %t64, label %bb22, label %bb23
bb22:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/lower:lowering", ptr %t66, i32 0, i32 0
  %t69 = load ptr, ptr %t68, !tbaa !29
  %t71 = getelementptr %"compiler/lower:Lowerer", ptr %t69, i32 0, i32 3
  %t72 = load ptr, ptr %t71, !tbaa !29
  %t74 = icmp eq ptr %t72, null
  br i1 %t74, label %bb24, label %bb25
bb23:
  store i1 false, ptr %l39, !tbaa !21
  br label %bb28
bb24:
  call void @__olang_check_failed(ptr @olang_loc_dbd01c2d9a53cc65_a4645b55310f1609)
  unreachable
bb25:
  br label %bb26
bb26:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/lower:lowering", ptr %t76, i32 0, i32 0
  %t79 = load ptr, ptr %t78, !tbaa !29
  %t81 = getelementptr %"compiler/lower:Lowerer", ptr %t79, i32 0, i32 3
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t83 = load i64, ptr %l6, !tbaa !24
  %t86 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eIsHandle(ptr %v0, ptr %t82, i64 %t83)
  store i1 %t86, ptr %l48
  br label %bb27
bb27:
  %t87 = load i1, ptr %l48, !tbaa !21
  store i1 %t87, ptr %l39, !tbaa !21
  br label %bb28
bb28:
  %t88 = load i1, ptr %l39, !tbaa !21
  store i1 %t88, ptr %l7, !tbaa !21
  %t89 = load i64, ptr %l6, !tbaa !24
  %t91 = icmp sge i64 %t89, 0
  br i1 %t91, label %bb29, label %bb30
bb29:
  %t93 = load ptr, ptr %l2, !tbaa !29
  %t95 = call i1 @compiler_2flower_2eclausedTry(ptr %v1, ptr %t93)
  store i1 %t95, ptr %l53
  br label %bb31
bb30:
  store i1 false, ptr %l51, !tbaa !21
  br label %bb32
bb31:
  %t96 = load i1, ptr %l53, !tbaa !21
  store i1 %t96, ptr %l51, !tbaa !21
  br label %bb32
bb32:
  %t97 = load i1, ptr %l51, !tbaa !21
  br i1 %t97, label %bb33, label %bb34
bb33:
  %t98 = load ptr, ptr %l0, !tbaa !29
  store ptr %t98, ptr %l54, !tbaa !29
  %t99 = load i1, ptr %l7, !tbaa !21
  br i1 %t99, label %bb35, label %bb36
bb34:
  br label %bb39
bb35:
  store i64 1, ptr %l56, !tbaa !24
  br label %bb37
bb36:
  store i64 0, ptr %l56, !tbaa !24
  br label %bb37
bb37:
  %t101 = load i64, ptr %l56, !tbaa !24
  %t102 = load ptr, ptr %l54, !tbaa !29
  %t103 = getelementptr %"compiler/lower:lowering", ptr %t102, i32 0, i32 25
  store i64 %t101, ptr %t103, !tbaa !24
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t105 = load ptr, ptr %l2, !tbaa !29
  %t109 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %t104, ptr %t105)
  store { i64, [4 x i64] } %t109, ptr %l60
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb39:
  %t110 = load i64, ptr %l6, !tbaa !24
  %t112 = icmp sge i64 %t110, 0
  br i1 %t112, label %bb40, label %bb41
bb40:
  store ptr %l3, ptr %l63, !tbaa !29
  %t114 = load i1, ptr %l7, !tbaa !21
  br i1 %t114, label %bb42, label %bb43
bb41:
  br label %bb50
bb42:
  %t116 = mul i64 1, 8
  %t117 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t116)
  %t118 = insertvalue { i64, ptr } undef, i64 1, 0
  %t119 = insertvalue { i64, ptr } %t118, ptr %t117, 1
  store { i64, ptr } %t119, ptr %l66, !tbaa !27
  %t120 = getelementptr { i64, ptr }, ptr %l66, i32 0, i32 1
  %t121 = load ptr, ptr %t120, !tbaa !27
  %t122 = getelementptr i64, ptr %t121, i64 0
  store i64 0, ptr %t122, !tbaa !34
  %t123 = load { i64, ptr }, ptr %l66, !tbaa !27
  store { i64, ptr } %t123, ptr %l65, !tbaa !27
  br label %bb48
bb43:
  %t124 = icmp sge i64 0, 0
  br i1 %t124, label %bb44, label %bb45
bb44:
  %t126 = icmp sle i64 0, 1152921504606846975
  br i1 %t126, label %bb46, label %bb47
bb45:
  call void @__olang_check_failed(ptr @olang_loc_950864b62af76d08_da7578d9dc40a3d4)
  unreachable
bb46:
  %t128 = mul i64 0, 8
  %t129 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t128)
  %t130 = insertvalue { i64, ptr } undef, i64 0, 0
  %t131 = insertvalue { i64, ptr } %t130, ptr %t129, 1
  store { i64, ptr } %t131, ptr %l65, !tbaa !27
  br label %bb48
bb47:
  call void @__olang_check_failed(ptr @olang_loc_950864b62af76d08_da7578d9dc40a3d4)
  unreachable
bb48:
  %t133 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t134 = extractvalue { i64, ptr } %t133, 0
  %t135 = extractvalue { i64, ptr } %t133, 1
  %t136 = mul i64 %t134, 8
  %t137 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t136)
  call void @llvm.memcpy.p0.p0.i64(ptr %t137, ptr %t135, i64 %t136, i1 false)
  %t138 = insertvalue { i64, ptr } undef, i64 %t134, 0
  %t139 = insertvalue { i64, ptr } %t138, ptr %t137, 1
  %t140 = load ptr, ptr %l63, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2ePush_3cArray_3cI64_3e_26_3e(ptr %s0, ptr %s0, ptr %t140, { i64, ptr } %t139)
  br label %bb49
bb49:
  br label %bb50
bb50:
  br label %bb51
bb51:
  br label %bb53
bb52:
  call void @__olang_check_failed(ptr @olang_loc_f1e39541941081b6_a7c200b33b013fba)
  unreachable
bb53:
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t143 = load ptr, ptr %l2, !tbaa !29
  %t147 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %t142, ptr %t143)
  store { i64, [4 x i64] } %t147, ptr %l74
  br label %bb54
bb54:
  %t148 = load { i64, [4 x i64] }, ptr %l74
  store { i64, [4 x i64] } %t148, ptr %l8
  %t150 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2eLen_3cArray_3cI64_3e_26_3e(ptr %s0, ptr %l3)
  store i64 %t150, ptr %l76
  br label %bb55
bb55:
  %t151 = load i64, ptr %l76, !tbaa !24
  %t152 = icmp eq i64 %t151, 0
  br i1 %t152, label %bb56, label %bb57
bb56:
  store i1 true, ptr %l78, !tbaa !21
  br label %bb58
bb57:
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t156 = getelementptr %"compiler/lower:lowering", ptr %t154, i32 0, i32 7
  %t157 = load i1, ptr %t156, !tbaa !21
  store i1 %t157, ptr %l78, !tbaa !21
  br label %bb58
bb58:
  %t159 = load i1, ptr %l78, !tbaa !21
  br i1 %t159, label %bb59, label %bb60
bb59:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb60:
  br label %bb61
bb61:
  %t160 = load ptr, ptr %l0, !tbaa !29
  store ptr %t160, ptr %l81, !tbaa !29
  %t161 = load { i64, [4 x i64] }, ptr %l8
  store { i64, [4 x i64] } %t161, ptr %l82
  %t162 = load ptr, ptr %l2, !tbaa !29
  %t164 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t162)
  store i32 %t164, ptr %l84
  br label %bb62
bb62:
  %t165 = load %"compiler/source:Span", ptr %l1
  %t166 = load ptr, ptr %l81, !tbaa !29
  %t167 = load { i64, [4 x i64] }, ptr %l82
  %t168 = load i32, ptr %l84, !tbaa !23
  %t170 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2elocal(ptr %v0, ptr %t166, { i64, [4 x i64] } %t167, i32 %t168, %"compiler/source:Span" %t165)
  store i32 %t170, ptr %l86
  br label %bb63
bb63:
  %t171 = load i32, ptr %l86, !tbaa !23
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t174 = load %"compiler/source:Span", ptr %l1
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ereleaseAt(ptr %v0, ptr %s0, ptr %t172, i32 %t171, ptr %l3, %"compiler/source:Span" %t174)
  br label %bb64
bb64:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2efill(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3, i1 %a4, { i64, [1 x i64] } %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l6 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca { i64, [4 x i64] }
  %l10 = alloca { i64, [4 x i64] }
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l14 = alloca i32
  %l15 = alloca { i64, [4 x i64] }
  %l16 = alloca i32
  %l17 = alloca i32
  %l18 = alloca { i64, [4 x i64] }
  %l19 = alloca i64
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l27 = alloca { i64, [4 x i64] }
  %l28 = alloca { i64, [4 x i64] }
  %l30 = alloca i64
  %l36 = alloca i32
  %l45 = alloca i32
  %l54 = alloca { i64, [4 x i64] }
  %l62 = alloca { i64, ptr }
  %l64 = alloca i1
  %l65 = alloca ptr
  %l66 = alloca i1
  %l74 = alloca i1
  %l78 = alloca i1
  %l85 = alloca i32
  %l86 = alloca ptr
  %l87 = alloca %"compiler/source:Span"
  %l89 = alloca %"compiler/mir:Place"
  %l94 = alloca ptr
  %l95 = alloca i32
  %l96 = alloca i32
  %l97 = alloca ptr
  %l98 = alloca { i64, [4 x i64] }
  %l104 = alloca i32
  %l106 = alloca { i64, [4 x i64] }
  %l108 = alloca { i64, [4 x i64] }
  %l109 = alloca { i64, ptr }
  %l111 = alloca { i64, [4 x i64] }
  %l114 = alloca i32
  %l117 = alloca i32
  %l127 = alloca { i64, ptr }
  %l130 = alloca { i64, [4 x i64] }
  %l134 = alloca ptr
  %l135 = alloca %"compiler/source:Span"
  %l137 = alloca %"compiler/mir:Place"
  %l147 = alloca %"compiler/mir:Place"
  %l151 = alloca { i64, ptr }
  %l154 = alloca { i64, [4 x i64] }
  %l160 = alloca i64
  %l163 = alloca i64
  %l171 = alloca i64
  %l174 = alloca i64
  %l196 = alloca ptr
  %l197 = alloca i32
  %l198 = alloca i32
  %l202 = alloca %"compiler/mir:Range"
  %l205 = alloca { i64, [4 x i64] }
  %l206 = alloca ptr
  %l209 = alloca i32
  %l210 = alloca i1
  %l213 = alloca ptr
  %l214 = alloca i32
  %l218 = alloca { i64, [1 x i64] }
  %l223 = alloca { i64, [4 x i64] }
  %l229 = alloca ptr
  %l230 = alloca { i64, [4 x i64] }
  %l236 = alloca i32
  %l238 = alloca { i64, [4 x i64] }
  %l243 = alloca ptr
  %l244 = alloca i32
  %l245 = alloca i32
  %l246 = alloca { i64, [4 x i64] }
  %l248 = alloca { i64, [4 x i64] }
  %l249 = alloca { i64, ptr }
  %l251 = alloca { i64, [4 x i64] }
  %l263 = alloca i1
  %l266 = alloca i64
  %l269 = alloca ptr
  %l270 = alloca i32
  %l271 = alloca i32
  %l272 = alloca { i64, [4 x i64] }
  %l276 = alloca { i64, [4 x i64] }
  %l277 = alloca { i64, ptr }
  %l279 = alloca { i64, [4 x i64] }
  %l287 = alloca ptr
  %l288 = alloca i32
  %l290 = alloca { i64, [1 x i64] }
  %l295 = alloca { i64, [1 x i64] }
  %l301 = alloca { i64, [4 x i64] }
  %s1 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %rv = alloca { i64, [4 x i64] }
  %t22 = alloca { i64, [4 x i64] }, align 8
  %t32 = alloca { i64, [4 x i64] }, align 8
  %t55 = alloca { i64, [4 x i64] }, align 8
  %t147 = alloca { i64, [15 x i64] }, align 8
  %t153 = alloca { i64, [21 x i64] }, align 8
  %t229 = alloca { i64, [8 x i64] }, align 8
  %t272 = alloca { i64, [15 x i64] }, align 8
  %t278 = alloca { i64, [21 x i64] }, align 8
  %t303 = alloca { i64, [4 x i64] }, align 8
  %t316 = alloca { i64, [4 x i64] }, align 8
  %t412 = alloca { i64, [15 x i64] }, align 8
  %t454 = alloca { i64, [15 x i64] }, align 8
  %t480 = alloca { i64, [4 x i64] }, align 8
  %t639 = alloca { i64, [15 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l6, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load i32, ptr %l2, !tbaa !23
  %t10 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2earrayOf(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t10, ptr %l36
  br label %bb1
bb1:
  %t11 = load i32, ptr %l36, !tbaa !23
  store i32 %t11, ptr %l7, !tbaa !23
  %t12 = load i32, ptr %l7, !tbaa !23
  %t13 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t16 = icmp eq i32 %t12, %t13
  br i1 %t16, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load %"compiler/source:Span", ptr %l3
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2egap(ptr %v0, ptr %s1, ptr %t18, %"compiler/source:Span" %t19, { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d15, i32 0, i32 1) })
  br label %bb4
bb3:
  br label %bb5
bb4:
  store { i64, [4 x i64] } zeroinitializer, ptr %t22
  %t23 = getelementptr { i64, [4 x i64] }, ptr %t22, i32 0, i32 0
  store i64 0, ptr %t23
  %t24 = load { i64, [4 x i64] }, ptr %t22
  call void @__olang_scope_close(ptr %s1)
  store { i64, [4 x i64] } %t24, ptr %rv
  br label %ret
bb5:
  %t26 = load ptr, ptr %l6, !tbaa !29
  %t27 = load i32, ptr %l7, !tbaa !23
  %t30 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t26, i32 %t27)
  store i32 %t30, ptr %l45
  br label %bb6
bb6:
  %t31 = load i32, ptr %l45, !tbaa !23
  store i32 %t31, ptr %l8, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t32
  %t33 = getelementptr { i64, [4 x i64] }, ptr %t32, i32 0, i32 0
  store i64 0, ptr %t33
  %t34 = load { i64, [4 x i64] }, ptr %t32
  store { i64, [4 x i64] } %t34, ptr %l9
  %t36 = load ptr, ptr %l1, !tbaa !29
  %t38 = getelementptr %"compiler/typed:Make", ptr %t36, i32 0, i32 3
  %t39 = load ptr, ptr %t38, !tbaa !29
  %t41 = icmp eq ptr %t39, null
  %t43 = xor i1 %t41, true
  br i1 %t43, label %bb7, label %bb8
bb7:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t46 = load ptr, ptr %l1, !tbaa !29
  %t48 = getelementptr %"compiler/typed:Make", ptr %t46, i32 0, i32 3
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t52 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %t45, ptr %t49)
  store { i64, [4 x i64] } %t52, ptr %l54
  br label %bb9
bb8:
  br label %bb10
bb9:
  %t53 = load { i64, [4 x i64] }, ptr %l54
  store { i64, [4 x i64] } %t53, ptr %l9
  br label %bb10
bb10:
  %t54 = load i32, ptr %l8, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t55
  %t56 = getelementptr { i64, [4 x i64] }, ptr %t55, i32 0, i32 0
  store i64 2, ptr %t56
  %t58 = insertvalue { i32, i64 } undef, i32 %t54, 0
  %t59 = insertvalue { i32, i64 } %t58, i64 0, 1
  %t60 = getelementptr { i64, [4 x i64] }, ptr %t55, i32 0, i32 1
  store { i32, i64 } %t59, ptr %t60
  %t61 = load { i64, [4 x i64] }, ptr %t55
  store { i64, [4 x i64] } %t61, ptr %l10
  %t63 = load ptr, ptr %l1, !tbaa !29
  %t65 = getelementptr %"compiler/typed:Make", ptr %t63, i32 0, i32 2
  %t66 = load { i64, ptr }, ptr %t65, !tbaa !27
  %t68 = extractvalue { i64, ptr } %t66, 0
  %t70 = icmp sgt i64 %t68, 0
  br i1 %t70, label %bb11, label %bb12
bb11:
  %t72 = load ptr, ptr %l1, !tbaa !29
  %t74 = getelementptr %"compiler/typed:Make", ptr %t72, i32 0, i32 2
  %t75 = load { i64, ptr }, ptr %t74, !tbaa !27
  store { i64, ptr } %t75, ptr %l62, !tbaa !27
  %t76 = getelementptr { i64, ptr }, ptr %l62, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !27
  %t78 = getelementptr ptr, ptr %t77, i64 0
  %t79 = load ptr, ptr %t78, !tbaa !39
  store ptr %t79, ptr %l11, !tbaa !29
  %t81 = load ptr, ptr %l11, !tbaa !29
  store ptr %t81, ptr %l65, !tbaa !29
  store i1 false, ptr %l66, !tbaa !21
  %t82 = load ptr, ptr %l65, !tbaa !29
  %t83 = icmp ne ptr %t82, null
  br i1 %t83, label %bb13, label %bb14
bb12:
  br label %bb57
bb13:
  %t85 = load ptr, ptr %l65, !tbaa !29
  %t86 = load i64, ptr %t85
  %t88 = icmp eq i64 %t86, 6
  store i1 %t88, ptr %l66, !tbaa !21
  br label %bb14
bb14:
  %t89 = load i1, ptr %l66, !tbaa !21
  br i1 %t89, label %bb15, label %bb16
bb15:
  %t90 = load ptr, ptr %l11, !tbaa !29
  %t92 = getelementptr { i64, [5 x i64] }, ptr %t90, i32 0, i32 1
  %t93 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t92, i32 0, i32 2
  %t94 = load ptr, ptr %t93
  store ptr %t94, ptr %l12, !tbaa !29
  br label %bb17
bb16:
  br label %bb18
bb17:
  %t96 = load ptr, ptr %l12, !tbaa !29
  %t98 = getelementptr %"compiler/typed:Call", ptr %t96, i32 0, i32 4
  %t99 = load i1, ptr %t98, !tbaa !21
  store i1 %t99, ptr %l64, !tbaa !21
  br label %bb23
bb18:
  br i1 true, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  store i1 false, ptr %l64, !tbaa !21
  br label %bb23
bb22:
  call void @__olang_check_failed(ptr @olang_loc_8d285e9a6f8d174e_3f8421b20b21070a)
  unreachable
bb23:
  %t101 = load i1, ptr %l64, !tbaa !21
  br i1 %t101, label %bb24, label %bb25
bb24:
  %t104 = load { i64, [4 x i64] }, ptr %l9
  %t106 = extractvalue { i64, [4 x i64] } %t104, 0
  %t107 = icmp eq i64 %t106, 0
  %t109 = xor i1 %t107, true
  store i1 %t109, ptr %l74, !tbaa !21
  br label %bb26
bb25:
  store i1 false, ptr %l74, !tbaa !21
  br label %bb26
bb26:
  %t111 = load i1, ptr %l74, !tbaa !21
  br i1 %t111, label %bb27, label %bb28
bb27:
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t114 = getelementptr %"compiler/lower:lowering", ptr %t112, i32 0, i32 7
  %t115 = load i1, ptr %t114, !tbaa !21
  %t117 = xor i1 %t115, true
  store i1 %t117, ptr %l78, !tbaa !21
  br label %bb29
bb28:
  store i1 false, ptr %l78, !tbaa !21
  br label %bb29
bb29:
  %t119 = load i1, ptr %l78, !tbaa !21
  br i1 %t119, label %bb30, label %bb31
bb30:
  store %olang.scope zeroinitializer, ptr %s6
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t121 = load i32, ptr %l8, !tbaa !23
  %t122 = load %"compiler/source:Span", ptr %l3
  %t126 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etemp(ptr %v0, ptr %t120, i32 %t121, %"compiler/source:Span" %t122)
  store i32 %t126, ptr %l85
  br label %bb32
bb31:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t128 = load ptr, ptr %l1, !tbaa !29
  %t130 = getelementptr %"compiler/typed:Make", ptr %t128, i32 0, i32 2
  %t131 = load { i64, ptr }, ptr %t130, !tbaa !27
  store { i64, ptr } %t131, ptr %l151, !tbaa !27
  %t132 = getelementptr { i64, ptr }, ptr %l151, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !27
  %t134 = getelementptr ptr, ptr %t133, i64 0
  %t135 = load ptr, ptr %t134, !tbaa !39
  %t139 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %t127, ptr %t135)
  store { i64, [4 x i64] } %t139, ptr %l154
  br label %bb55
bb32:
  %t140 = load i32, ptr %l85, !tbaa !23
  store i32 %t140, ptr %l14, !tbaa !23
  %t141 = load ptr, ptr %l0, !tbaa !29
  store ptr %t141, ptr %l86, !tbaa !29
  %t142 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t142, ptr %l87
  %t143 = load i32, ptr %l14, !tbaa !23
  %t145 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t143)
  store %"compiler/mir:Place" %t145, ptr %l89
  br label %bb33
bb33:
  %t146 = load { i64, [4 x i64] }, ptr %l10
  store { i64, [15 x i64] } zeroinitializer, ptr %t147
  %t148 = getelementptr { i64, [15 x i64] }, ptr %t147, i32 0, i32 0
  store i64 0, ptr %t148
  %t150 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t146, 0
  %t151 = getelementptr { i64, [15 x i64] }, ptr %t147, i32 0, i32 1
  store { { i64, [4 x i64] } } %t150, ptr %t151
  %t152 = load { i64, [15 x i64] }, ptr %t147
  store { i64, [21 x i64] } zeroinitializer, ptr %t153
  %t154 = getelementptr { i64, [21 x i64] }, ptr %t153, i32 0, i32 0
  store i64 0, ptr %t154
  %t155 = load %"compiler/source:Span", ptr %l87
  %t156 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t155, 0
  %t157 = load %"compiler/mir:Place", ptr %l89
  %t158 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t156, %"compiler/mir:Place" %t157, 1
  %t160 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t158, { i64, [15 x i64] } %t152, 2
  %t161 = getelementptr { i64, [21 x i64] }, ptr %t153, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t160, ptr %t161
  %t162 = load { i64, [21 x i64] }, ptr %t153
  %t164 = call ptr @__olang_scope_alloc_a(ptr %s6, i64 176, i64 8)
  store { i64, [21 x i64] } %t162, ptr %t164
  %t165 = load ptr, ptr %l86, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s6, ptr %t165, ptr %t164)
  br label %bb34
bb34:
  %t167 = load ptr, ptr %l0, !tbaa !29
  store ptr %t167, ptr %l94, !tbaa !29
  store i32 17, ptr %l95
  %t168 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t168, ptr %l96, !tbaa !23
  %t169 = load ptr, ptr %l0, !tbaa !29
  store ptr %t169, ptr %l97, !tbaa !29
  %t170 = load { i64, [4 x i64] }, ptr %l9
  store { i64, [4 x i64] } %t170, ptr %l98
  %t171 = load ptr, ptr %l1, !tbaa !29
  %t173 = getelementptr %"compiler/typed:Make", ptr %t171, i32 0, i32 3
  %t174 = load ptr, ptr %t173, !tbaa !29
  %t176 = icmp eq ptr %t174, null
  br i1 %t176, label %bb35, label %bb36
bb35:
  call void @__olang_check_failed(ptr @olang_loc_f5af5833f64caf98_602ac3538c074da4)
  unreachable
bb36:
  br label %bb37
bb37:
  %t178 = load ptr, ptr %l1, !tbaa !29
  %t180 = getelementptr %"compiler/typed:Make", ptr %t178, i32 0, i32 3
  %t181 = load ptr, ptr %t180, !tbaa !29
  %t183 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t181)
  store i32 %t183, ptr %l104
  br label %bb38
bb38:
  %t184 = load %"compiler/source:Span", ptr %l3
  %t185 = load ptr, ptr %l97, !tbaa !29
  %t186 = load { i64, [4 x i64] }, ptr %l98
  %t187 = load i32, ptr %l104, !tbaa !23
  %t189 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2easI64(ptr %v0, ptr %t185, { i64, [4 x i64] } %t186, i32 %t187, %"compiler/source:Span" %t184)
  store { i64, [4 x i64] } %t189, ptr %l106
  br label %bb39
bb39:
  %t190 = load ptr, ptr %l0, !tbaa !29
  %t192 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2econstI64(ptr %v0, ptr %t190, i64 0)
  store { i64, [4 x i64] } %t192, ptr %l108
  br label %bb40
bb40:
  %t193 = mul i64 2, 40
  %t194 = call ptr @__olang_scope_alloc_zeroed(ptr %s6, i64 %t193)
  %t195 = insertvalue { i64, ptr } undef, i64 2, 0
  %t196 = insertvalue { i64, ptr } %t195, ptr %t194, 1
  store { i64, ptr } %t196, ptr %l109, !tbaa !27
  %t197 = load { i64, [4 x i64] }, ptr %l106
  %t198 = getelementptr { i64, ptr }, ptr %l109, i32 0, i32 1
  %t199 = load ptr, ptr %t198, !tbaa !27
  %t200 = getelementptr { i64, [4 x i64] }, ptr %t199, i64 0
  store { i64, [4 x i64] } %t197, ptr %t200
  %t201 = load { i64, [4 x i64] }, ptr %l108
  %t202 = getelementptr { i64, ptr }, ptr %l109, i32 0, i32 1
  %t203 = load ptr, ptr %t202, !tbaa !27
  %t204 = getelementptr { i64, [4 x i64] }, ptr %t203, i64 1
  store { i64, [4 x i64] } %t201, ptr %t204
  %t205 = load %"compiler/source:Span", ptr %l3
  %t206 = load ptr, ptr %l94, !tbaa !29
  %t207 = load i32, ptr %l95
  %t208 = load i32, ptr %l96, !tbaa !23
  %t209 = load { i64, ptr }, ptr %l109, !tbaa !27
  %t211 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s6, ptr %t206, i32 %t207, i32 %t208, { i64, ptr } %t209, %"compiler/source:Span" %t205)
  store { i64, [4 x i64] } %t211, ptr %l111
  br label %bb41
bb41:
  %t212 = load { i64, [4 x i64] }, ptr %l111
  store { i64, [4 x i64] } %t212, ptr %l15
  %t213 = load ptr, ptr %l0, !tbaa !29
  %t215 = getelementptr %"compiler/lower:lowering", ptr %t213, i32 0, i32 3
  %t217 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t215)
  store i32 %t217, ptr %l114
  br label %bb42
bb42:
  %t218 = load i32, ptr %l114, !tbaa !23
  store i32 %t218, ptr %l16, !tbaa !23
  %t219 = load ptr, ptr %l0, !tbaa !29
  %t221 = getelementptr %"compiler/lower:lowering", ptr %t219, i32 0, i32 3
  %t223 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t221)
  store i32 %t223, ptr %l117
  br label %bb43
bb43:
  %t224 = load i32, ptr %l117, !tbaa !23
  store i32 %t224, ptr %l17, !tbaa !23
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t226 = load { i64, [4 x i64] }, ptr %l15
  %t227 = load i32, ptr %l16, !tbaa !23
  %t228 = load i32, ptr %l17, !tbaa !23
  store { i64, [8 x i64] } zeroinitializer, ptr %t229
  %t230 = getelementptr { i64, [8 x i64] }, ptr %t229, i32 0, i32 0
  store i64 2, ptr %t230
  %t232 = insertvalue { { i64, [4 x i64] }, i32, i32 } undef, { i64, [4 x i64] } %t226, 0
  %t234 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t232, i32 %t227, 1
  %t236 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t234, i32 %t228, 2
  %t237 = getelementptr { i64, [8 x i64] }, ptr %t229, i32 0, i32 1
  store { { i64, [4 x i64] }, i32, i32 } %t236, ptr %t237
  %t238 = load { i64, [8 x i64] }, ptr %t229
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t225, { i64, [8 x i64] } %t238)
  br label %bb44
bb44:
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t242 = load i32, ptr %l16, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t241, i32 %t242)
  br label %bb45
bb45:
  %t245 = load ptr, ptr %l0, !tbaa !29
  %t246 = load ptr, ptr %l1, !tbaa !29
  %t248 = getelementptr %"compiler/typed:Make", ptr %t246, i32 0, i32 2
  %t249 = load { i64, ptr }, ptr %t248, !tbaa !27
  store { i64, ptr } %t249, ptr %l127, !tbaa !27
  %t250 = getelementptr { i64, ptr }, ptr %l127, i32 0, i32 1
  %t251 = load ptr, ptr %t250, !tbaa !27
  %t252 = getelementptr ptr, ptr %t251, i64 0
  %t253 = load ptr, ptr %t252, !tbaa !39
  %t257 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %t245, ptr %t253)
  store { i64, [4 x i64] } %t257, ptr %l130
  br label %bb46
bb46:
  %t258 = load { i64, [4 x i64] }, ptr %l130
  store { i64, [4 x i64] } %t258, ptr %l18
  %t259 = load ptr, ptr %l0, !tbaa !29
  %t261 = getelementptr %"compiler/lower:lowering", ptr %t259, i32 0, i32 7
  %t262 = load i1, ptr %t261, !tbaa !21
  %t264 = xor i1 %t262, true
  br i1 %t264, label %bb47, label %bb48
bb47:
  store %olang.scope zeroinitializer, ptr %s7
  %t266 = load ptr, ptr %l0, !tbaa !29
  store ptr %t266, ptr %l134, !tbaa !29
  %t267 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t267, ptr %l135
  %t268 = load i32, ptr %l14, !tbaa !23
  %t270 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t268)
  store %"compiler/mir:Place" %t270, ptr %l137
  br label %bb49
bb48:
  br label %bb51
bb49:
  %t271 = load { i64, [4 x i64] }, ptr %l18
  store { i64, [15 x i64] } zeroinitializer, ptr %t272
  %t273 = getelementptr { i64, [15 x i64] }, ptr %t272, i32 0, i32 0
  store i64 0, ptr %t273
  %t275 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t271, 0
  %t276 = getelementptr { i64, [15 x i64] }, ptr %t272, i32 0, i32 1
  store { { i64, [4 x i64] } } %t275, ptr %t276
  %t277 = load { i64, [15 x i64] }, ptr %t272
  store { i64, [21 x i64] } zeroinitializer, ptr %t278
  %t279 = getelementptr { i64, [21 x i64] }, ptr %t278, i32 0, i32 0
  store i64 0, ptr %t279
  %t280 = load %"compiler/source:Span", ptr %l135
  %t281 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t280, 0
  %t282 = load %"compiler/mir:Place", ptr %l137
  %t283 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t281, %"compiler/mir:Place" %t282, 1
  %t285 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t283, { i64, [15 x i64] } %t277, 2
  %t286 = getelementptr { i64, [21 x i64] }, ptr %t278, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t285, ptr %t286
  %t287 = load { i64, [21 x i64] }, ptr %t278
  %t289 = call ptr @__olang_scope_alloc_a(ptr %s7, i64 176, i64 8)
  store { i64, [21 x i64] } %t287, ptr %t289
  %t290 = load ptr, ptr %l134, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s7, ptr %t290, ptr %t289)
  br label %bb50
bb50:
  call void @__olang_scope_close(ptr %s7)
  br label %bb51
bb51:
  %t292 = load ptr, ptr %l0, !tbaa !29
  %t293 = load i32, ptr %l17, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2egoto(ptr %v0, ptr %t292, i32 %t293)
  br label %bb52
bb52:
  %t296 = load ptr, ptr %l0, !tbaa !29
  %t297 = load i32, ptr %l17, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t296, i32 %t297)
  br label %bb53
bb53:
  %t300 = load i32, ptr %l14, !tbaa !23
  %t302 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t300)
  store %"compiler/mir:Place" %t302, ptr %l147
  br label %bb54
bb54:
  store { i64, [4 x i64] } zeroinitializer, ptr %t303
  %t304 = getelementptr { i64, [4 x i64] }, ptr %t303, i32 0, i32 0
  store i64 1, ptr %t304
  %t305 = load %"compiler/mir:Place", ptr %l147
  %t306 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t305, 0
  %t307 = getelementptr { i64, [4 x i64] }, ptr %t303, i32 0, i32 1
  store { %"compiler/mir:Place" } %t306, ptr %t307
  %t308 = load { i64, [4 x i64] }, ptr %t303
  store { i64, [4 x i64] } %t308, ptr %l10
  call void @__olang_scope_close(ptr %s6)
  br label %bb56
bb55:
  %t310 = load { i64, [4 x i64] }, ptr %l154
  store { i64, [4 x i64] } %t310, ptr %l10
  br label %bb56
bb56:
  br label %bb57
bb57:
  %t311 = load ptr, ptr %l0, !tbaa !29
  %t313 = getelementptr %"compiler/lower:lowering", ptr %t311, i32 0, i32 7
  %t314 = load i1, ptr %t313, !tbaa !21
  br i1 %t314, label %bb58, label %bb59
bb58:
  store { i64, [4 x i64] } zeroinitializer, ptr %t316
  %t317 = getelementptr { i64, [4 x i64] }, ptr %t316, i32 0, i32 0
  store i64 0, ptr %t317
  %t318 = load { i64, [4 x i64] }, ptr %t316
  store { i64, [4 x i64] } %t318, ptr %rv
  br label %ret
bb59:
  br label %bb60
bb60:
  %t320 = load ptr, ptr %l0, !tbaa !29
  %t321 = load i32, ptr %l7, !tbaa !23
  %t324 = call i64 @compiler_2flower_2ecompiler_2flower_3alowering_2efixedLen(ptr %v0, ptr %t320, i32 %t321)
  store i64 %t324, ptr %l160
  br label %bb61
bb61:
  %t325 = load i64, ptr %l160, !tbaa !24
  store i64 %t325, ptr %l19, !tbaa !24
  %t326 = load i64, ptr %l19, !tbaa !24
  %t328 = icmp sge i64 %t326, 0
  br i1 %t328, label %bb62, label %bb63
bb62:
  store %olang.scope zeroinitializer, ptr %s10
  %t330 = load i64, ptr %l19, !tbaa !24
  store i64 %t330, ptr %l163, !tbaa !24
  %t331 = load i64, ptr %l163, !tbaa !24
  %t332 = icmp sge i64 %t331, 0
  br i1 %t332, label %bb64, label %bb65
bb63:
  br label %bb89
bb64:
  %t334 = load i64, ptr %l163, !tbaa !24
  %t335 = icmp sle i64 %t334, 230584300921369395
  br i1 %t335, label %bb66, label %bb67
bb65:
  call void @__olang_check_failed(ptr @olang_loc_1e1698b45a1b0cf3_495e2913f4118f47)
  unreachable
bb66:
  %t337 = load i64, ptr %l163, !tbaa !24
  %t338 = mul i64 %t337, 40
  %t339 = call ptr @__olang_scope_alloc_zeroed(ptr %s10, i64 %t338)
  %t340 = insertvalue { i64, ptr } undef, i64 %t337, 0
  %t341 = insertvalue { i64, ptr } %t340, ptr %t339, 1
  store { i64, ptr } %t341, ptr %l20, !tbaa !27
  store i64 0, ptr %l21, !tbaa !24
  %t343 = load i64, ptr %l19, !tbaa !24
  store i64 %t343, ptr %l22, !tbaa !24
  store i64 1, ptr %l23, !tbaa !24
  %t345 = load i64, ptr %l22, !tbaa !24
  %t346 = load i64, ptr %l21, !tbaa !24
  %t349 = icmp sgt i64 %t345, %t346
  br i1 %t349, label %bb68, label %bb69
bb67:
  call void @__olang_check_failed(ptr @olang_loc_1e1698b45a1b0cf3_495e2913f4118f47)
  unreachable
bb68:
  %t351 = load i64, ptr %l23, !tbaa !24
  %t353 = icmp sgt i64 %t351, 0
  br i1 %t353, label %bb70, label %bb71
bb69:
  store i64 0, ptr %l171, !tbaa !24
  br label %bb73
bb70:
  %t355 = load i64, ptr %l22, !tbaa !24
  %t356 = load i64, ptr %l21, !tbaa !24
  %t359 = sub i64 %t355, %t356
  %t360 = load i64, ptr %l23, !tbaa !24
  %t363 = add i64 %t359, %t360
  %t365 = sub i64 %t363, 1
  %t366 = load i64, ptr %l23, !tbaa !24
  %t369 = sdiv i64 %t365, %t366
  store i64 %t369, ptr %l174, !tbaa !24
  br label %bb72
bb71:
  store i64 0, ptr %l174, !tbaa !24
  br label %bb72
bb72:
  %t371 = load i64, ptr %l174, !tbaa !24
  store i64 %t371, ptr %l171, !tbaa !24
  br label %bb73
bb73:
  %t372 = load i64, ptr %l171, !tbaa !24
  store i64 %t372, ptr %l24, !tbaa !24
  store i64 0, ptr %l25, !tbaa !24
  br label %bb74
bb74:
  %t373 = load i64, ptr %l25, !tbaa !24
  %t374 = load i64, ptr %l24, !tbaa !24
  %t377 = icmp slt i64 %t373, %t374
  %t379 = xor i1 %t377, true
  br i1 %t379, label %bb75, label %bb76
bb75:
  br label %bb79
bb76:
  br label %bb77
bb77:
  %t381 = load i64, ptr %l21, !tbaa !24
  %t382 = load i64, ptr %l25, !tbaa !24
  %t383 = load i64, ptr %l23, !tbaa !24
  %t386 = mul i64 %t382, %t383
  %t389 = add i64 %t381, %t386
  %t392 = load { i64, [4 x i64] }, ptr %l10
  %t395 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t396 = load ptr, ptr %t395, !tbaa !27
  %t397 = getelementptr { i64, [4 x i64] }, ptr %t396, i64 %t389
  store { i64, [4 x i64] } %t392, ptr %t397
  br label %bb78
bb78:
  %t398 = load i64, ptr %l25, !tbaa !24
  %t400 = add i64 %t398, 1
  store i64 %t400, ptr %l25, !tbaa !24
  br label %bb74
bb79:
  %t402 = load ptr, ptr %l0, !tbaa !29
  store ptr %t402, ptr %l196, !tbaa !29
  %t403 = load i32, ptr %l7, !tbaa !23
  store i32 %t403, ptr %l197, !tbaa !23
  %t404 = load i32, ptr %l7, !tbaa !23
  store i32 %t404, ptr %l198, !tbaa !23
  %t405 = load ptr, ptr %l0, !tbaa !29
  %t407 = getelementptr %"compiler/lower:lowering", ptr %t405, i32 0, i32 3
  %t408 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t411 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v0, ptr %s10, ptr %t407, { i64, ptr } %t408)
  store %"compiler/mir:Range" %t411, ptr %l202
  br label %bb80
bb80:
  store { i64, [15 x i64] } zeroinitializer, ptr %t412
  %t413 = getelementptr { i64, [15 x i64] }, ptr %t412, i32 0, i32 0
  store i64 6, ptr %t413
  %t414 = load i32, ptr %l198, !tbaa !23
  %t415 = insertvalue { i32, i64, %"compiler/mir:Range" } undef, i32 %t414, 0
  %t416 = insertvalue { i32, i64, %"compiler/mir:Range" } %t415, i64 0, 1
  %t417 = load %"compiler/mir:Range", ptr %l202
  %t418 = insertvalue { i32, i64, %"compiler/mir:Range" } %t416, %"compiler/mir:Range" %t417, 2
  %t419 = getelementptr { i64, [15 x i64] }, ptr %t412, i32 0, i32 1
  store { i32, i64, %"compiler/mir:Range" } %t418, ptr %t419
  %t420 = load { i64, [15 x i64] }, ptr %t412
  %t421 = load %"compiler/source:Span", ptr %l3
  %t422 = load ptr, ptr %l196, !tbaa !29
  %t423 = load i32, ptr %l197, !tbaa !23
  %t426 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t422, i32 %t423, { i64, [15 x i64] } %t420, %"compiler/source:Span" %t421)
  store { i64, [4 x i64] } %t426, ptr %l205
  br label %bb81
bb81:
  %t427 = load { i64, [4 x i64] }, ptr %l205
  store { i64, [4 x i64] } %t427, ptr %l27
  %t428 = load ptr, ptr %l6, !tbaa !29
  store ptr %t428, ptr %l206, !tbaa !29
  %t429 = load ptr, ptr %l6, !tbaa !29
  %t430 = load i32, ptr %l2, !tbaa !23
  %t433 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t429, i32 %t430)
  store i32 %t433, ptr %l209
  br label %bb82
bb82:
  %t434 = load ptr, ptr %l206, !tbaa !29
  %t435 = load i32, ptr %l209, !tbaa !23
  %t436 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t434, i32 %t435)
  store i1 %t436, ptr %l210
  br label %bb83
bb83:
  %t437 = load i1, ptr %l210, !tbaa !21
  %t438 = xor i1 %t437, true
  br i1 %t438, label %bb84, label %bb85
bb84:
  %t440 = load { i64, [4 x i64] }, ptr %l27
  call void @__olang_scope_close(ptr %s10)
  store { i64, [4 x i64] } %t440, ptr %rv
  br label %ret
bb85:
  br label %bb86
bb86:
  %t442 = load ptr, ptr %l0, !tbaa !29
  store ptr %t442, ptr %l213, !tbaa !29
  %t443 = load i32, ptr %l2, !tbaa !23
  store i32 %t443, ptr %l214, !tbaa !23
  %t444 = load ptr, ptr %l0, !tbaa !29
  %t445 = load ptr, ptr %l1, !tbaa !29
  %t447 = getelementptr %"compiler/typed:Make", ptr %t445, i32 0, i32 4
  %t448 = load i32, ptr %t447, !tbaa !23
  %t451 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ebuilt(ptr %v0, ptr %t444, i32 %t448)
  store { i64, [1 x i64] } %t451, ptr %l218
  br label %bb87
bb87:
  %t452 = load { i64, [4 x i64] }, ptr %l27
  %t453 = load i32, ptr %l2, !tbaa !23
  store { i64, [15 x i64] } zeroinitializer, ptr %t454
  %t455 = getelementptr { i64, [15 x i64] }, ptr %t454, i32 0, i32 0
  store i64 7, ptr %t455
  %t456 = load { i64, [1 x i64] }, ptr %l218
  %t457 = insertvalue { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 } undef, { i64, [1 x i64] } %t456, 0
  %t459 = insertvalue { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 } %t457, { i64, [4 x i64] } %t452, 1
  %t461 = insertvalue { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 } %t459, i32 %t453, 2
  %t462 = getelementptr { i64, [15 x i64] }, ptr %t454, i32 0, i32 1
  store { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 } %t461, ptr %t462
  %t463 = load { i64, [15 x i64] }, ptr %t454
  %t464 = load %"compiler/source:Span", ptr %l3
  %t465 = load ptr, ptr %l213, !tbaa !29
  %t466 = load i32, ptr %l214, !tbaa !23
  %t469 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t465, i32 %t466, { i64, [15 x i64] } %t463, %"compiler/source:Span" %t464)
  store { i64, [4 x i64] } %t469, ptr %l223
  br label %bb88
bb88:
  call void @__olang_scope_close(ptr %s10)
  %t470 = load { i64, [4 x i64] }, ptr %l223
  store { i64, [4 x i64] } %t470, ptr %rv
  br label %ret
bb89:
  %t471 = load { i64, [4 x i64] }, ptr %l9
  %t473 = extractvalue { i64, [4 x i64] } %t471, 0
  %t474 = icmp eq i64 %t473, 0
  br i1 %t474, label %bb90, label %bb91
bb90:
  store %olang.scope zeroinitializer, ptr %s15
  %t476 = load ptr, ptr %l0, !tbaa !29
  %t477 = load %"compiler/source:Span", ptr %l3
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2egap(ptr %v0, ptr %s15, ptr %t476, %"compiler/source:Span" %t477, { i64, ptr } { i64 38, ptr getelementptr inbounds (<{ i64, [38 x i8] }>, ptr @.d16, i32 0, i32 1) })
  br label %bb92
bb91:
  br label %bb93
bb92:
  store { i64, [4 x i64] } zeroinitializer, ptr %t480
  %t481 = getelementptr { i64, [4 x i64] }, ptr %t480, i32 0, i32 0
  store i64 0, ptr %t481
  %t482 = load { i64, [4 x i64] }, ptr %t480
  call void @__olang_scope_close(ptr %s15)
  store { i64, [4 x i64] } %t482, ptr %rv
  br label %ret
bb93:
  %t484 = load ptr, ptr %l0, !tbaa !29
  store ptr %t484, ptr %l229, !tbaa !29
  %t485 = load { i64, [4 x i64] }, ptr %l9
  store { i64, [4 x i64] } %t485, ptr %l230
  %t486 = load ptr, ptr %l1, !tbaa !29
  %t488 = getelementptr %"compiler/typed:Make", ptr %t486, i32 0, i32 3
  %t489 = load ptr, ptr %t488, !tbaa !29
  %t491 = icmp eq ptr %t489, null
  br i1 %t491, label %bb94, label %bb95
bb94:
  call void @__olang_check_failed(ptr @olang_loc_4345db1597b95ac6_216be31f80f17832)
  unreachable
bb95:
  br label %bb96
bb96:
  %t493 = load ptr, ptr %l1, !tbaa !29
  %t495 = getelementptr %"compiler/typed:Make", ptr %t493, i32 0, i32 3
  %t496 = load ptr, ptr %t495, !tbaa !29
  %t498 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t496)
  store i32 %t498, ptr %l236
  br label %bb97
bb97:
  %t499 = load %"compiler/source:Span", ptr %l3
  %t500 = load ptr, ptr %l229, !tbaa !29
  %t501 = load { i64, [4 x i64] }, ptr %l230
  %t502 = load i32, ptr %l236, !tbaa !23
  %t504 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2easI64(ptr %v0, ptr %t500, { i64, [4 x i64] } %t501, i32 %t502, %"compiler/source:Span" %t499)
  store { i64, [4 x i64] } %t504, ptr %l238
  br label %bb98
bb98:
  %t505 = load { i64, [4 x i64] }, ptr %l238
  store { i64, [4 x i64] } %t505, ptr %l28
  %t506 = load ptr, ptr %l1, !tbaa !29
  %t508 = getelementptr %"compiler/typed:Make", ptr %t506, i32 0, i32 5
  %t509 = load i32, ptr %t508
  %t511 = trunc i64 0 to i32
  %t512 = icmp eq i32 %t509, %t511
  %t514 = xor i1 %t512, true
  br i1 %t514, label %bb99, label %bb100
bb99:
  store %olang.scope zeroinitializer, ptr %s16
  %t516 = load ptr, ptr %l0, !tbaa !29
  store ptr %t516, ptr %l243, !tbaa !29
  store i32 18, ptr %l244
  %t517 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t517, ptr %l245, !tbaa !23
  %t518 = load { i64, [4 x i64] }, ptr %l28
  store { i64, [4 x i64] } %t518, ptr %l246
  %t519 = load ptr, ptr %l0, !tbaa !29
  %t521 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2econstI64(ptr %v0, ptr %t519, i64 0)
  store { i64, [4 x i64] } %t521, ptr %l248
  br label %bb101
bb100:
  br label %bb112
bb101:
  %t522 = mul i64 2, 40
  %t523 = call ptr @__olang_scope_alloc_zeroed(ptr %s16, i64 %t522)
  %t524 = insertvalue { i64, ptr } undef, i64 2, 0
  %t525 = insertvalue { i64, ptr } %t524, ptr %t523, 1
  store { i64, ptr } %t525, ptr %l249, !tbaa !27
  %t526 = load { i64, [4 x i64] }, ptr %l246
  %t527 = getelementptr { i64, ptr }, ptr %l249, i32 0, i32 1
  %t528 = load ptr, ptr %t527, !tbaa !27
  %t529 = getelementptr { i64, [4 x i64] }, ptr %t528, i64 0
  store { i64, [4 x i64] } %t526, ptr %t529
  %t530 = load { i64, [4 x i64] }, ptr %l248
  %t531 = getelementptr { i64, ptr }, ptr %l249, i32 0, i32 1
  %t532 = load ptr, ptr %t531, !tbaa !27
  %t533 = getelementptr { i64, [4 x i64] }, ptr %t532, i64 1
  store { i64, [4 x i64] } %t530, ptr %t533
  %t534 = load %"compiler/source:Span", ptr %l3
  %t535 = load ptr, ptr %l243, !tbaa !29
  %t536 = load i32, ptr %l244
  %t537 = load i32, ptr %l245, !tbaa !23
  %t538 = load { i64, ptr }, ptr %l249, !tbaa !27
  %t540 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s16, ptr %t535, i32 %t536, i32 %t537, { i64, ptr } %t538, %"compiler/source:Span" %t534)
  store { i64, [4 x i64] } %t540, ptr %l251
  br label %bb102
bb102:
  %t541 = load { i64, [4 x i64] }, ptr %l251
  %t542 = load ptr, ptr %l0, !tbaa !29
  %t544 = load ptr, ptr %l1, !tbaa !29
  %t546 = getelementptr %"compiler/typed:Make", ptr %t544, i32 0, i32 5
  %t547 = load i32, ptr %t546
  %t548 = load i64, ptr @G_2ecompiler_2flower_2eOutOfBounds, !tbaa !24
  %t549 = load %"compiler/source:Span", ptr %l3
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2echeck(ptr %v0, ptr %t542, { i64, [4 x i64] } %t541, i32 %t547, i32 7, i64 %t548, %"compiler/source:Span" %t549)
  br label %bb103
bb103:
  %t556 = load ptr, ptr %l0, !tbaa !29
  %t558 = getelementptr %"compiler/lower:lowering", ptr %t556, i32 0, i32 0
  %t559 = load ptr, ptr %t558, !tbaa !29
  %t561 = getelementptr %"compiler/lower:Lowerer", ptr %t559, i32 0, i32 0
  %t562 = load ptr, ptr %t561, !tbaa !29
  %t563 = load i32, ptr %l8, !tbaa !23
  %t566 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLayout(ptr %v0, ptr %t562, i32 %t563)
  store i1 %t566, ptr %l263
  br label %bb104
bb104:
  %t567 = load ptr, ptr %l6, !tbaa !29
  %t568 = load i32, ptr %l8, !tbaa !23
  %t571 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSize(ptr %v0, ptr %t567, i32 %t568)
  store i64 %t571, ptr %l266
  br label %bb105
bb105:
  %t572 = load i64, ptr %l266, !tbaa !24
  store i64 %t572, ptr %l30, !tbaa !24
  %t573 = load i64, ptr %l30, !tbaa !24
  %t575 = icmp sgt i64 %t573, 1
  br i1 %t575, label %bb106, label %bb107
bb106:
  store %olang.scope zeroinitializer, ptr %s17
  %t577 = load ptr, ptr %l0, !tbaa !29
  store ptr %t577, ptr %l269, !tbaa !29
  store i32 16, ptr %l270
  %t578 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t578, ptr %l271, !tbaa !23
  %t579 = load { i64, [4 x i64] }, ptr %l28
  store { i64, [4 x i64] } %t579, ptr %l272
  %t580 = load ptr, ptr %l0, !tbaa !29
  %t581 = load i64, ptr %l30, !tbaa !24
  %t583 = sdiv i64 9223372036854775807, %t581
  %t586 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2econstI64(ptr %v0, ptr %t580, i64 %t583)
  store { i64, [4 x i64] } %t586, ptr %l276
  br label %bb108
bb107:
  br label %bb111
bb108:
  %t587 = mul i64 2, 40
  %t588 = call ptr @__olang_scope_alloc_zeroed(ptr %s17, i64 %t587)
  %t589 = insertvalue { i64, ptr } undef, i64 2, 0
  %t590 = insertvalue { i64, ptr } %t589, ptr %t588, 1
  store { i64, ptr } %t590, ptr %l277, !tbaa !27
  %t591 = load { i64, [4 x i64] }, ptr %l272
  %t592 = getelementptr { i64, ptr }, ptr %l277, i32 0, i32 1
  %t593 = load ptr, ptr %t592, !tbaa !27
  %t594 = getelementptr { i64, [4 x i64] }, ptr %t593, i64 0
  store { i64, [4 x i64] } %t591, ptr %t594
  %t595 = load { i64, [4 x i64] }, ptr %l276
  %t596 = getelementptr { i64, ptr }, ptr %l277, i32 0, i32 1
  %t597 = load ptr, ptr %t596, !tbaa !27
  %t598 = getelementptr { i64, [4 x i64] }, ptr %t597, i64 1
  store { i64, [4 x i64] } %t595, ptr %t598
  %t599 = load %"compiler/source:Span", ptr %l3
  %t600 = load ptr, ptr %l269, !tbaa !29
  %t601 = load i32, ptr %l270
  %t602 = load i32, ptr %l271, !tbaa !23
  %t603 = load { i64, ptr }, ptr %l277, !tbaa !27
  %t605 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s17, ptr %t600, i32 %t601, i32 %t602, { i64, ptr } %t603, %"compiler/source:Span" %t599)
  store { i64, [4 x i64] } %t605, ptr %l279
  br label %bb109
bb109:
  %t606 = load { i64, [4 x i64] }, ptr %l279
  %t607 = load ptr, ptr %l0, !tbaa !29
  %t609 = load ptr, ptr %l1, !tbaa !29
  %t611 = getelementptr %"compiler/typed:Make", ptr %t609, i32 0, i32 5
  %t612 = load i32, ptr %t611
  %t613 = load i64, ptr @G_2ecompiler_2flower_2eOutOfBounds, !tbaa !24
  %t614 = load %"compiler/source:Span", ptr %l3
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2echeck(ptr %v0, ptr %t607, { i64, [4 x i64] } %t606, i32 %t612, i32 7, i64 %t613, %"compiler/source:Span" %t614)
  br label %bb110
bb110:
  call void @__olang_scope_close(ptr %s17)
  br label %bb111
bb111:
  call void @__olang_scope_close(ptr %s16)
  br label %bb112
bb112:
  %t621 = load ptr, ptr %l0, !tbaa !29
  store ptr %t621, ptr %l287, !tbaa !29
  %t622 = load i32, ptr %l2, !tbaa !23
  store i32 %t622, ptr %l288, !tbaa !23
  br i1 %a4, label %bb113, label %bb114
bb113:
  store { i64, [1 x i64] } %a5, ptr %l290
  br label %bb116
bb114:
  %t627 = load ptr, ptr %l0, !tbaa !29
  %t628 = load ptr, ptr %l1, !tbaa !29
  %t630 = getelementptr %"compiler/typed:Make", ptr %t628, i32 0, i32 4
  %t631 = load i32, ptr %t630, !tbaa !23
  %t634 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2emadeAt(ptr %v0, ptr %t627, i32 %t631)
  store { i64, [1 x i64] } %t634, ptr %l295
  br label %bb115
bb115:
  %t635 = load { i64, [1 x i64] }, ptr %l295
  store { i64, [1 x i64] } %t635, ptr %l290
  br label %bb116
bb116:
  %t636 = load i32, ptr %l2, !tbaa !23
  %t637 = load { i64, [4 x i64] }, ptr %l28
  %t638 = load { i64, [4 x i64] }, ptr %l10
  store { i64, [15 x i64] } zeroinitializer, ptr %t639
  %t640 = getelementptr { i64, [15 x i64] }, ptr %t639, i32 0, i32 0
  store i64 8, ptr %t640
  %t641 = load { i64, [1 x i64] }, ptr %l290
  %t642 = insertvalue { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } undef, { i64, [1 x i64] } %t641, 0
  %t644 = insertvalue { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } %t642, i32 %t636, 1
  %t646 = insertvalue { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } %t644, { i64, [4 x i64] } %t637, 2
  %t648 = insertvalue { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } %t646, { i64, [4 x i64] } %t638, 3
  %t649 = getelementptr { i64, [15 x i64] }, ptr %t639, i32 0, i32 1
  store { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } %t648, ptr %t649
  %t650 = load { i64, [15 x i64] }, ptr %t639
  %t651 = load %"compiler/source:Span", ptr %l3
  %t652 = load ptr, ptr %l287, !tbaa !29
  %t653 = load i32, ptr %l288, !tbaa !23
  %t656 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t652, i32 %t653, { i64, [15 x i64] } %t650, %"compiler/source:Span" %t651)
  store { i64, [4 x i64] } %t656, ptr %l301
  br label %bb117
bb117:
  %t657 = load { i64, [4 x i64] }, ptr %l301
  store { i64, [4 x i64] } %t657, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local i32 @compiler_2flower_2ecompiler_2flower_3alowering_2eflag(ptr %v0, ptr %a0, i1 %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca %"compiler/source:Span"
  %l11 = alloca %"compiler/mir:Place"
  %l15 = alloca { i64, [4 x i64] }
  %s0 = alloca %olang.scope
  %rv = alloca i32
  %t21 = alloca { i64, [15 x i64] }, align 8
  %t27 = alloca { i64, [21 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t3 = load %"compiler/source:Span", ptr %l2
  %t7 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etemp(ptr %v0, ptr %t1, i32 %t2, %"compiler/source:Span" %t3)
  store i32 %t7, ptr %l7
  br label %bb1
bb1:
  %t8 = load i32, ptr %l7, !tbaa !23
  store i32 %t8, ptr %l3, !tbaa !23
  %t9 = load ptr, ptr %l0, !tbaa !29
  store ptr %t9, ptr %l8, !tbaa !29
  %t10 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t10, ptr %l9
  %t11 = load i32, ptr %l3, !tbaa !23
  %t13 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t11)
  store %"compiler/mir:Place" %t13, ptr %l11
  br label %bb2
bb2:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = load %"compiler/source:Span", ptr %l2
  %t20 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2econstBool(ptr %v0, ptr %t14, i1 %a1, %"compiler/source:Span" %t16)
  store { i64, [4 x i64] } %t20, ptr %l15
  br label %bb3
bb3:
  store { i64, [15 x i64] } zeroinitializer, ptr %t21
  %t22 = getelementptr { i64, [15 x i64] }, ptr %t21, i32 0, i32 0
  store i64 0, ptr %t22
  %t23 = load { i64, [4 x i64] }, ptr %l15
  %t24 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t23, 0
  %t25 = getelementptr { i64, [15 x i64] }, ptr %t21, i32 0, i32 1
  store { { i64, [4 x i64] } } %t24, ptr %t25
  %t26 = load { i64, [15 x i64] }, ptr %t21
  store { i64, [21 x i64] } zeroinitializer, ptr %t27
  %t28 = getelementptr { i64, [21 x i64] }, ptr %t27, i32 0, i32 0
  store i64 0, ptr %t28
  %t29 = load %"compiler/source:Span", ptr %l9
  %t30 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t29, 0
  %t31 = load %"compiler/mir:Place", ptr %l11
  %t32 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t30, %"compiler/mir:Place" %t31, 1
  %t34 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t32, { i64, [15 x i64] } %t26, 2
  %t35 = getelementptr { i64, [21 x i64] }, ptr %t27, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t34, ptr %t35
  %t36 = load { i64, [21 x i64] }, ptr %t27
  %t38 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t36, ptr %t38
  %t39 = load ptr, ptr %l8, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %t39, ptr %t38)
  br label %bb4
bb4:
  %t41 = load i32, ptr %l3, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t41, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2ehelper(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca %"compiler/lower:pl"
  %l7 = alloca { i64, ptr }
  %l18 = alloca %"compiler/lower:pl"
  %l20 = alloca %"compiler/lower:pl"
  %l21 = alloca ptr
  %l27 = alloca { i64, [4 x i64] }
  %l32 = alloca ptr
  %l33 = alloca ptr
  %l35 = alloca %"compiler/lower:pl"
  %l38 = alloca { i64, [4 x i64] }
  %l44 = alloca { i64, ptr }
  %l45 = alloca ptr
  %l49 = alloca { i64, ptr }
  %l51 = alloca { i64, ptr }
  %l53 = alloca ptr
  %l60 = alloca { i64, [4 x i64] }
  %l65 = alloca { i64, ptr }
  %l66 = alloca ptr
  %l67 = alloca %"compiler/mir:Place"
  %l69 = alloca ptr
  %l71 = alloca %"compiler/lower:pl"
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %t96 = alloca { i64, [1 x i64] }, align 8
  %t137 = alloca { i64, [1 x i64] }, align 8
  %t152 = alloca { i64, [4 x i64] }, align 8
  %t166 = alloca { i64, [1 x i64] }, align 8
  %t178 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/lower:lowering", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = getelementptr %"compiler/typed:Body", ptr %t9, i32 0, i32 4
  %t12 = load %"compiler/source:Span", ptr %t11
  store %"compiler/source:Span" %t12, ptr %l4
  %t14 = load i32, ptr %l1
  %t16 = trunc i64 1 to i32
  %t17 = icmp eq i32 %t14, %t16
  br i1 %t17, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb9
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t20 = mul i64 0, 16
  %t21 = call ptr @__olang_scope_alloc_zeroed(ptr %s1, i64 %t20)
  %t22 = insertvalue { i64, ptr } undef, i64 0, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t21, 1
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eprologue(ptr %v0, ptr %s1, ptr %t19, { i64, ptr } %t23)
  br label %bb4
bb4:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2eat(ptr %v0, ptr %s1, ptr %t26, i32 0)
  store %"compiler/lower:pl" %t28, ptr %l18
  br label %bb5
bb5:
  %t29 = load %"compiler/lower:pl", ptr %l18
  store %"compiler/lower:pl" %t29, ptr %l5
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2eat(ptr %v0, ptr %s1, ptr %t30, i32 1)
  store %"compiler/lower:pl" %t32, ptr %l20
  br label %bb6
bb6:
  %t33 = load %"compiler/lower:pl", ptr %l20
  %t34 = load ptr, ptr %l0, !tbaa !29
  store ptr %t34, ptr %l21, !tbaa !29
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load %"compiler/lower:pl", ptr %l5
  %t38 = load i32, ptr %l2, !tbaa !23
  %t39 = load %"compiler/source:Span", ptr %l4
  %t45 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eequalAt(ptr %v0, ptr %s1, ptr %s1, ptr %t35, %"compiler/lower:pl" %t36, %"compiler/lower:pl" %t33, i32 %t38, %"compiler/source:Span" %t39, i1 true)
  store { i64, [4 x i64] } %t45, ptr %l27
  br label %bb7
bb7:
  %t46 = load ptr, ptr %l21, !tbaa !29
  %t47 = load { i64, [4 x i64] }, ptr %l27
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eepilogue(ptr %v0, ptr %t46, { i64, [4 x i64] } %t47)
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s1)
  br label %bb38
bb9:
  %t48 = load i32, ptr %l1
  %t50 = trunc i64 2 to i32
  %t51 = icmp eq i32 %t48, %t50
  br i1 %t51, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb17
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = mul i64 0, 16
  %t55 = call ptr @__olang_scope_alloc_zeroed(ptr %s2, i64 %t54)
  %t56 = insertvalue { i64, ptr } undef, i64 0, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t55, 1
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eprologue(ptr %v0, ptr %s2, ptr %t53, { i64, ptr } %t57)
  br label %bb13
bb13:
  %t60 = load ptr, ptr %l0, !tbaa !29
  store ptr %t60, ptr %l32, !tbaa !29
  %t61 = load ptr, ptr %l0, !tbaa !29
  store ptr %t61, ptr %l33, !tbaa !29
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2eat(ptr %v0, ptr %s2, ptr %t62, i32 0)
  store %"compiler/lower:pl" %t64, ptr %l35
  br label %bb14
bb14:
  %t65 = load i32, ptr %l2, !tbaa !23
  %t66 = load %"compiler/source:Span", ptr %l4
  %t67 = load ptr, ptr %l33, !tbaa !29
  %t68 = load %"compiler/lower:pl", ptr %l35
  %t71 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ehashAt(ptr %v0, ptr %s2, ptr %t67, %"compiler/lower:pl" %t68, i32 %t65, %"compiler/source:Span" %t66, i1 true)
  store { i64, [4 x i64] } %t71, ptr %l38
  br label %bb15
bb15:
  %t72 = load ptr, ptr %l32, !tbaa !29
  %t73 = load { i64, [4 x i64] }, ptr %l38
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eepilogue(ptr %v0, ptr %t72, { i64, [4 x i64] } %t73)
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s2)
  br label %bb38
bb17:
  %t74 = load i32, ptr %l1
  %t76 = trunc i64 3 to i32
  %t77 = icmp eq i32 %t74, %t76
  br i1 %t77, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb28
bb20:
  store %olang.scope zeroinitializer, ptr %s3
  %t79 = load ptr, ptr %l3, !tbaa !29
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/lower:lowering", ptr %t80, i32 0, i32 3
  %t83 = getelementptr %"compiler/mir:Fn", ptr %t82, i32 0, i32 1
  %t84 = load i32, ptr %t83, !tbaa !23
  %t87 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopeVarsOf(ptr %v0, ptr %s3, ptr %t79, i32 %t84)
  store { i64, ptr } %t87, ptr %l44
  br label %bb21
bb21:
  %t88 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t88, ptr %l7, !tbaa !27
  %t89 = load ptr, ptr %l0, !tbaa !29
  store ptr %t89, ptr %l45, !tbaa !29
  %t90 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t92 = extractvalue { i64, ptr } %t90, 0
  %t94 = icmp sgt i64 %t92, 0
  br i1 %t94, label %bb22, label %bb23
bb22:
  store { i64, [1 x i64] } zeroinitializer, ptr %t96
  %t97 = getelementptr { i64, [1 x i64] }, ptr %t96, i32 0, i32 0
  store i64 1, ptr %t97
  %t98 = load { i64, [1 x i64] }, ptr %t96
  %t99 = mul i64 1, 16
  %t100 = call ptr @__olang_scope_alloc_zeroed(ptr %s3, i64 %t99)
  %t101 = insertvalue { i64, ptr } undef, i64 1, 0
  %t102 = insertvalue { i64, ptr } %t101, ptr %t100, 1
  store { i64, ptr } %t102, ptr %l51, !tbaa !27
  %t104 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !27
  %t106 = getelementptr { i64, [1 x i64] }, ptr %t105, i64 0
  store { i64, [1 x i64] } %t98, ptr %t106
  %t107 = load { i64, ptr }, ptr %l51, !tbaa !27
  store { i64, ptr } %t107, ptr %l49, !tbaa !27
  br label %bb24
bb23:
  %t108 = mul i64 0, 16
  %t109 = call ptr @__olang_scope_alloc_zeroed(ptr %s3, i64 %t108)
  %t110 = insertvalue { i64, ptr } undef, i64 0, 0
  %t111 = insertvalue { i64, ptr } %t110, ptr %t109, 1
  store { i64, ptr } %t111, ptr %l49, !tbaa !27
  br label %bb24
bb24:
  %t113 = load ptr, ptr %l45, !tbaa !29
  %t114 = load { i64, ptr }, ptr %l49, !tbaa !27
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eprologue(ptr %v0, ptr %s3, ptr %t113, { i64, ptr } %t114)
  br label %bb25
bb25:
  %t115 = load ptr, ptr %l0, !tbaa !29
  store ptr %t115, ptr %l53, !tbaa !29
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t117 = load i32, ptr %l2, !tbaa !23
  %t118 = load %"compiler/source:Span", ptr %l4
  %t119 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t121 = extractvalue { i64, ptr } %t119, 0
  %t123 = icmp sgt i64 %t121, 0
  %t128 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ezeroOf(ptr %v0, ptr %t116, i32 %t117, %"compiler/source:Span" %t118, i1 %t123)
  store { i64, [4 x i64] } %t128, ptr %l60
  br label %bb26
bb26:
  %t129 = load ptr, ptr %l53, !tbaa !29
  %t130 = load { i64, [4 x i64] }, ptr %l60
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eepilogue(ptr %v0, ptr %t129, { i64, [4 x i64] } %t130)
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s3)
  br label %bb38
bb28:
  %t131 = load i32, ptr %l1
  %t133 = trunc i64 0 to i32
  %t134 = icmp eq i32 %t131, %t133
  br i1 %t134, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb37
bb31:
  store %olang.scope zeroinitializer, ptr %s4
  %t136 = load ptr, ptr %l0, !tbaa !29
  store { i64, [1 x i64] } zeroinitializer, ptr %t137
  %t138 = getelementptr { i64, [1 x i64] }, ptr %t137, i32 0, i32 0
  store i64 5, ptr %t138
  %t139 = load { i64, [1 x i64] }, ptr %t137
  %t140 = mul i64 1, 16
  %t141 = call ptr @__olang_scope_alloc_zeroed(ptr %s4, i64 %t140)
  %t142 = insertvalue { i64, ptr } undef, i64 1, 0
  %t143 = insertvalue { i64, ptr } %t142, ptr %t141, 1
  store { i64, ptr } %t143, ptr %l65, !tbaa !27
  %t145 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !27
  %t147 = getelementptr { i64, [1 x i64] }, ptr %t146, i64 0
  store { i64, [1 x i64] } %t139, ptr %t147
  %t149 = load { i64, ptr }, ptr %l65, !tbaa !27
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eprologue(ptr %v0, ptr %s4, ptr %t136, { i64, ptr } %t149)
  br label %bb32
bb32:
  %t150 = load ptr, ptr %l0, !tbaa !29
  store ptr %t150, ptr %l66, !tbaa !29
  %t151 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 1)
  store %"compiler/mir:Place" %t151, ptr %l67
  br label %bb33
bb33:
  store { i64, [4 x i64] } zeroinitializer, ptr %t152
  %t153 = getelementptr { i64, [4 x i64] }, ptr %t152, i32 0, i32 0
  store i64 1, ptr %t153
  %t154 = load %"compiler/mir:Place", ptr %l67
  %t155 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t154, 0
  %t156 = getelementptr { i64, [4 x i64] }, ptr %t152, i32 0, i32 1
  store { %"compiler/mir:Place" } %t155, ptr %t156
  %t157 = load { i64, [4 x i64] }, ptr %t152
  %t159 = load ptr, ptr %l66, !tbaa !29
  %t160 = getelementptr %"compiler/lower:lowering", ptr %t159, i32 0, i32 5
  store { i64, [4 x i64] } %t157, ptr %t160
  %t161 = load ptr, ptr %l0, !tbaa !29
  store ptr %t161, ptr %l69, !tbaa !29
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t164 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2eat(ptr %v0, ptr %s4, ptr %t162, i32 0)
  store %"compiler/lower:pl" %t164, ptr %l71
  br label %bb34
bb34:
  %t165 = load i32, ptr %l2, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t166
  %t167 = getelementptr { i64, [1 x i64] }, ptr %t166, i32 0, i32 0
  store i64 1, ptr %t167
  %t168 = insertvalue { i64 } undef, i64 0, 0
  %t169 = getelementptr { i64, [1 x i64] }, ptr %t166, i32 0, i32 1
  store { i64 } %t168, ptr %t169
  %t170 = load { i64, [1 x i64] }, ptr %t166
  %t171 = load %"compiler/source:Span", ptr %l4
  %t172 = load ptr, ptr %l69, !tbaa !29
  %t173 = load %"compiler/lower:pl", ptr %l71
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2erenderAt(ptr %v0, ptr %s4, ptr %t172, %"compiler/lower:pl" %t173, i32 %t165, { i64, [1 x i64] } %t170, %"compiler/source:Span" %t171, i1 true)
  br label %bb35
bb35:
  %t177 = load ptr, ptr %l0, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t178
  %t179 = getelementptr { i64, [4 x i64] }, ptr %t178, i32 0, i32 0
  store i64 0, ptr %t179
  %t180 = load { i64, [4 x i64] }, ptr %t178
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eepilogue(ptr %v0, ptr %t177, { i64, [4 x i64] } %t180)
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s4)
  br label %bb38
bb37:
  call void @__olang_check_failed(ptr @olang_loc_30767a805df234bd_503f920f410b6239)
  unreachable
bb38:
  br label %ret
ret:
  ret void
}

define dso_local { { i64, [7 x i64] }, i32 } @compiler_2flower_2ecompiler_2flower_3alowering_2ehelperCallee(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i32
  %l7 = alloca i32
  %l14 = alloca i32
  %l19 = alloca i32
  %rv = alloca { { i64, [7 x i64] }, i32 }
  %t37 = alloca { i64, [2 x i64] }, align 8
  %t49 = alloca { i64, [2 x i64] }, align 8
  %t58 = alloca { i64, [7 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t3 = trunc i64 0 to i32
  %t4 = icmp eq i32 %a1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i32 1, ptr %l7
  br label %bb3
bb2:
  store i32 2, ptr %l7
  br label %bb3
bb3:
  %t8 = load i32, ptr %l7
  store i32 %t8, ptr %l3
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/lower:lowering", ptr %t9, i32 0, i32 0
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t13 = load i32, ptr %l3
  %t14 = load i32, ptr %l2, !tbaa !23
  %t18 = call i32 @compiler_2flower_2ecompiler_2flower_3aLowerer_2ehelperTy(ptr %v0, ptr %t12, i32 %t13, i32 %t14)
  store i32 %t18, ptr %l14
  br label %bb4
bb4:
  %t19 = load i32, ptr %l14, !tbaa !23
  store i32 %t19, ptr %l2, !tbaa !23
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/lower:lowering", ptr %t20, i32 0, i32 2
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t24 = load i32, ptr %l3
  %t25 = load i32, ptr %l2, !tbaa !23
  %t29 = call i32 @compiler_2fmir_2eHelperType(ptr %v0, ptr %t23, i32 %t24, i32 %t25)
  store i32 %t29, ptr %l19
  br label %bb5
bb5:
  %t30 = load i32, ptr %l19, !tbaa !23
  store i32 %t30, ptr %l4, !tbaa !23
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/lower:lowering", ptr %t31, i32 0, i32 0
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t35 = load i32, ptr %l3
  %t36 = load i32, ptr %l2, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t37
  %t38 = getelementptr { i64, [2 x i64] }, ptr %t37, i32 0, i32 0
  store i64 2, ptr %t38
  %t40 = insertvalue { i32, i32 } undef, i32 %t35, 0
  %t42 = insertvalue { i32, i32 } %t40, i32 %t36, 1
  %t43 = getelementptr { i64, [2 x i64] }, ptr %t37, i32 0, i32 1
  store { i32, i32 } %t42, ptr %t43
  %t44 = load { i64, [2 x i64] }, ptr %t37
  call void @compiler_2flower_2ecompiler_2flower_3aLowerer_2eWant(ptr %v0, ptr %t34, { i64, [2 x i64] } %t44)
  br label %bb6
bb6:
  %t47 = load i32, ptr %l3
  %t48 = load i32, ptr %l2, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t49
  %t50 = getelementptr { i64, [2 x i64] }, ptr %t49, i32 0, i32 0
  store i64 2, ptr %t50
  %t52 = insertvalue { i32, i32 } undef, i32 %t47, 0
  %t54 = insertvalue { i32, i32 } %t52, i32 %t48, 1
  %t55 = getelementptr { i64, [2 x i64] }, ptr %t49, i32 0, i32 1
  store { i32, i32 } %t54, ptr %t55
  %t56 = load { i64, [2 x i64] }, ptr %t49
  %t57 = load i32, ptr %l4, !tbaa !23
  store { i64, [7 x i64] } zeroinitializer, ptr %t58
  %t59 = getelementptr { i64, [7 x i64] }, ptr %t58, i32 0, i32 0
  store i64 0, ptr %t59
  %t61 = insertvalue { { i64, [2 x i64] }, i32 } undef, { i64, [2 x i64] } %t56, 0
  %t63 = insertvalue { { i64, [2 x i64] }, i32 } %t61, i32 %t57, 1
  %t64 = getelementptr { i64, [7 x i64] }, ptr %t58, i32 0, i32 1
  store { { i64, [2 x i64] }, i32 } %t63, ptr %t64
  %t65 = load { i64, [7 x i64] }, ptr %t58
  %t66 = load i32, ptr %l4, !tbaa !23
  %t68 = insertvalue { { i64, [7 x i64] }, i32 } undef, { i64, [7 x i64] } %t65, 0
  %t70 = insertvalue { { i64, [7 x i64] }, i32 } %t68, i32 %t66, 1
  store { { i64, [7 x i64] }, i32 } %t70, ptr %rv
  br label %ret
ret:
  %rr = load { { i64, [7 x i64] }, i32 }, ptr %rv
  ret { { i64, [7 x i64] }, i32 } %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2einner(ptr %v0, ptr %v1, ptr %a0, %"compiler/lower:pl" %a1, i32 %a2, { i64, [1 x i64] } %a3, %"compiler/source:Span" %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/lower:pl"
  %l2 = alloca i32
  %l3 = alloca { i64, [1 x i64] }
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca i32
  %l12 = alloca i32
  %l15 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca %"compiler/source:Span"
  %l18 = alloca { i64, [1 x i64] }
  %l19 = alloca i32
  %l20 = alloca ptr
  %l21 = alloca i32
  %l24 = alloca %"compiler/mir:Place"
  %l28 = alloca { i64, [4 x i64] }
  %l33 = alloca i1
  %l34 = alloca i1
  %l37 = alloca i1
  %l39 = alloca ptr
  %l40 = alloca %"compiler/source:Span"
  %l41 = alloca { i64, [1 x i64] }
  %l42 = alloca i32
  %l43 = alloca ptr
  %l44 = alloca i32
  %l47 = alloca %"compiler/mir:Place"
  %l51 = alloca { i64, [4 x i64] }
  %l56 = alloca i1
  %l60 = alloca i1
  %l64 = alloca i1
  %l68 = alloca i1
  %l70 = alloca ptr
  %l71 = alloca %"compiler/source:Span"
  %l72 = alloca { i64, [1 x i64] }
  %l73 = alloca i32
  %l74 = alloca ptr
  %l75 = alloca i32
  %l78 = alloca %"compiler/mir:Place"
  %l82 = alloca { i64, [4 x i64] }
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %t28 = alloca { i64, [4 x i64] }, align 8
  %t34 = alloca { i64, [15 x i64] }, align 8
  %t46 = alloca { i64, [21 x i64] }, align 8
  %t87 = alloca { i64, [4 x i64] }, align 8
  %t93 = alloca { i64, [15 x i64] }, align 8
  %t105 = alloca { i64, [21 x i64] }, align 8
  %t160 = alloca { i64, [4 x i64] }, align 8
  %t166 = alloca { i64, [15 x i64] }, align 8
  %t178 = alloca { i64, [21 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/lower:pl" %a1, ptr %l1
  store i32 %a2, ptr %l2
  store { i64, [1 x i64] } %a3, ptr %l3
  store %"compiler/source:Span" %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l5, !tbaa !29
  %t6 = load ptr, ptr %l5, !tbaa !29
  %t7 = load i32, ptr %l2, !tbaa !23
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t10, ptr %l12
  br label %bb1
bb1:
  %t11 = load i32, ptr %l12, !tbaa !23
  store i32 %t11, ptr %l6, !tbaa !23
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load i32, ptr %l2, !tbaa !23
  %t16 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eisChar(ptr %v0, ptr %t12, i32 %t13)
  store i1 %t16, ptr %l15
  br label %bb2
bb2:
  %t17 = load i1, ptr %l15, !tbaa !21
  br i1 %t17, label %bb3, label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t18 = load ptr, ptr %l0, !tbaa !29
  store ptr %t18, ptr %l16, !tbaa !29
  %t19 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t19, ptr %l17
  %t20 = load { i64, [1 x i64] }, ptr %l3
  store { i64, [1 x i64] } %t20, ptr %l18
  store i32 3, ptr %l19
  %t21 = load ptr, ptr %l0, !tbaa !29
  store ptr %t21, ptr %l20, !tbaa !29
  %t22 = load i32, ptr %l2, !tbaa !23
  store i32 %t22, ptr %l21, !tbaa !23
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load %"compiler/lower:pl", ptr %l1
  %t27 = call %"compiler/mir:Place" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %v1, ptr %t23, %"compiler/lower:pl" %t24)
  store %"compiler/mir:Place" %t27, ptr %l24
  br label %bb5
bb4:
  br label %bb8
bb5:
  store { i64, [4 x i64] } zeroinitializer, ptr %t28
  %t29 = getelementptr { i64, [4 x i64] }, ptr %t28, i32 0, i32 0
  store i64 1, ptr %t29
  %t30 = load %"compiler/mir:Place", ptr %l24
  %t31 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t30, 0
  %t32 = getelementptr { i64, [4 x i64] }, ptr %t28, i32 0, i32 1
  store { %"compiler/mir:Place" } %t31, ptr %t32
  %t33 = load { i64, [4 x i64] }, ptr %t28
  store { i64, [15 x i64] } zeroinitializer, ptr %t34
  %t35 = getelementptr { i64, [15 x i64] }, ptr %t34, i32 0, i32 0
  store i64 0, ptr %t35
  %t37 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t33, 0
  %t38 = getelementptr { i64, [15 x i64] }, ptr %t34, i32 0, i32 1
  store { { i64, [4 x i64] } } %t37, ptr %t38
  %t39 = load { i64, [15 x i64] }, ptr %t34
  %t40 = load %"compiler/source:Span", ptr %l4
  %t41 = load ptr, ptr %l20, !tbaa !29
  %t42 = load i32, ptr %l21, !tbaa !23
  %t45 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t41, i32 %t42, { i64, [15 x i64] } %t39, %"compiler/source:Span" %t40)
  store { i64, [4 x i64] } %t45, ptr %l28
  br label %bb6
bb6:
  store { i64, [21 x i64] } zeroinitializer, ptr %t46
  %t47 = getelementptr { i64, [21 x i64] }, ptr %t46, i32 0, i32 0
  store i64 9, ptr %t47
  %t48 = load %"compiler/source:Span", ptr %l17
  %t49 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } undef, %"compiler/source:Span" %t48, 0
  %t50 = load { i64, [1 x i64] }, ptr %l18
  %t51 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t49, { i64, [1 x i64] } %t50, 1
  %t52 = load i32, ptr %l19
  %t53 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t51, i32 %t52, 2
  %t54 = load { i64, [4 x i64] }, ptr %l28
  %t55 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t53, { i64, [4 x i64] } %t54, 3
  %t56 = getelementptr { i64, [21 x i64] }, ptr %t46, i32 0, i32 1
  store { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t55, ptr %t56
  %t57 = load { i64, [21 x i64] }, ptr %t46
  %t59 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 176, i64 8)
  store { i64, [21 x i64] } %t57, ptr %t59
  %t60 = load ptr, ptr %l16, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s1, ptr %t60, ptr %t59)
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s1)
  br label %ret
bb8:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load i32, ptr %l2, !tbaa !23
  %t66 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eisText(ptr %v0, ptr %t62, i32 %t63)
  store i1 %t66, ptr %l33
  br label %bb9
bb9:
  %t67 = load i1, ptr %l33, !tbaa !21
  br i1 %t67, label %bb10, label %bb11
bb10:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load i32, ptr %l2, !tbaa !23
  %t72 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ehasStr(ptr %v0, ptr %t68, i32 %t69)
  store i1 %t72, ptr %l37
  br label %bb12
bb11:
  store i1 false, ptr %l34, !tbaa !21
  br label %bb13
bb12:
  %t73 = load i1, ptr %l37, !tbaa !21
  %t74 = xor i1 %t73, true
  store i1 %t74, ptr %l34, !tbaa !21
  br label %bb13
bb13:
  %t76 = load i1, ptr %l34, !tbaa !21
  br i1 %t76, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s2
  %t77 = load ptr, ptr %l0, !tbaa !29
  store ptr %t77, ptr %l39, !tbaa !29
  %t78 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t78, ptr %l40
  %t79 = load { i64, [1 x i64] }, ptr %l3
  store { i64, [1 x i64] } %t79, ptr %l41
  store i32 1, ptr %l42
  %t80 = load ptr, ptr %l0, !tbaa !29
  store ptr %t80, ptr %l43, !tbaa !29
  %t81 = load i32, ptr %l2, !tbaa !23
  store i32 %t81, ptr %l44, !tbaa !23
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t83 = load %"compiler/lower:pl", ptr %l1
  %t86 = call %"compiler/mir:Place" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %v1, ptr %t82, %"compiler/lower:pl" %t83)
  store %"compiler/mir:Place" %t86, ptr %l47
  br label %bb16
bb15:
  br label %bb19
bb16:
  store { i64, [4 x i64] } zeroinitializer, ptr %t87
  %t88 = getelementptr { i64, [4 x i64] }, ptr %t87, i32 0, i32 0
  store i64 1, ptr %t88
  %t89 = load %"compiler/mir:Place", ptr %l47
  %t90 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t89, 0
  %t91 = getelementptr { i64, [4 x i64] }, ptr %t87, i32 0, i32 1
  store { %"compiler/mir:Place" } %t90, ptr %t91
  %t92 = load { i64, [4 x i64] }, ptr %t87
  store { i64, [15 x i64] } zeroinitializer, ptr %t93
  %t94 = getelementptr { i64, [15 x i64] }, ptr %t93, i32 0, i32 0
  store i64 0, ptr %t94
  %t96 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t92, 0
  %t97 = getelementptr { i64, [15 x i64] }, ptr %t93, i32 0, i32 1
  store { { i64, [4 x i64] } } %t96, ptr %t97
  %t98 = load { i64, [15 x i64] }, ptr %t93
  %t99 = load %"compiler/source:Span", ptr %l4
  %t100 = load ptr, ptr %l43, !tbaa !29
  %t101 = load i32, ptr %l44, !tbaa !23
  %t104 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t100, i32 %t101, { i64, [15 x i64] } %t98, %"compiler/source:Span" %t99)
  store { i64, [4 x i64] } %t104, ptr %l51
  br label %bb17
bb17:
  store { i64, [21 x i64] } zeroinitializer, ptr %t105
  %t106 = getelementptr { i64, [21 x i64] }, ptr %t105, i32 0, i32 0
  store i64 9, ptr %t106
  %t107 = load %"compiler/source:Span", ptr %l40
  %t108 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } undef, %"compiler/source:Span" %t107, 0
  %t109 = load { i64, [1 x i64] }, ptr %l41
  %t110 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t108, { i64, [1 x i64] } %t109, 1
  %t111 = load i32, ptr %l42
  %t112 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t110, i32 %t111, 2
  %t113 = load { i64, [4 x i64] }, ptr %l51
  %t114 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t112, { i64, [4 x i64] } %t113, 3
  %t115 = getelementptr { i64, [21 x i64] }, ptr %t105, i32 0, i32 1
  store { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t114, ptr %t115
  %t116 = load { i64, [21 x i64] }, ptr %t105
  %t118 = call ptr @__olang_scope_alloc_a(ptr %s2, i64 176, i64 8)
  store { i64, [21 x i64] } %t116, ptr %t118
  %t119 = load ptr, ptr %l39, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s2, ptr %t119, ptr %t118)
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb19:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t122 = load i32, ptr %l2, !tbaa !23
  %t125 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2escalar(ptr %v0, ptr %t121, i32 %t122)
  store i1 %t125, ptr %l56
  br label %bb20
bb20:
  %t126 = load i1, ptr %l56, !tbaa !21
  br i1 %t126, label %bb21, label %bb22
bb21:
  store %olang.scope zeroinitializer, ptr %s3
  store i32 7, ptr %l7
  %t128 = load ptr, ptr %l5, !tbaa !29
  %t129 = load i32, ptr %l6, !tbaa !23
  %t132 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %t128, i32 %t129)
  store i1 %t132, ptr %l60
  br label %bb23
bb22:
  br label %bb38
bb23:
  %t133 = load i1, ptr %l60, !tbaa !21
  br i1 %t133, label %bb24, label %bb25
bb24:
  store i32 5, ptr %l7
  br label %bb34
bb25:
  %t135 = load ptr, ptr %l5, !tbaa !29
  %t136 = load i32, ptr %l6, !tbaa !23
  %t139 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %t135, i32 %t136)
  store i1 %t139, ptr %l64
  br label %bb26
bb26:
  %t140 = load i1, ptr %l64, !tbaa !21
  br i1 %t140, label %bb27, label %bb28
bb27:
  store i32 4, ptr %l7
  br label %bb33
bb28:
  %t142 = load ptr, ptr %l5, !tbaa !29
  %t143 = load i32, ptr %l6, !tbaa !23
  %t146 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t142, i32 %t143)
  store i1 %t146, ptr %l68
  br label %bb29
bb29:
  %t147 = load i1, ptr %l68, !tbaa !21
  br i1 %t147, label %bb30, label %bb31
bb30:
  store i32 6, ptr %l7
  br label %bb32
bb31:
  br label %bb32
bb32:
  br label %bb33
bb33:
  br label %bb34
bb34:
  %t149 = load ptr, ptr %l0, !tbaa !29
  store ptr %t149, ptr %l70, !tbaa !29
  %t150 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t150, ptr %l71
  %t151 = load { i64, [1 x i64] }, ptr %l3
  store { i64, [1 x i64] } %t151, ptr %l72
  %t152 = load i32, ptr %l7
  store i32 %t152, ptr %l73
  %t153 = load ptr, ptr %l0, !tbaa !29
  store ptr %t153, ptr %l74, !tbaa !29
  %t154 = load i32, ptr %l2, !tbaa !23
  store i32 %t154, ptr %l75, !tbaa !23
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t156 = load %"compiler/lower:pl", ptr %l1
  %t159 = call %"compiler/mir:Place" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %v1, ptr %t155, %"compiler/lower:pl" %t156)
  store %"compiler/mir:Place" %t159, ptr %l78
  br label %bb35
bb35:
  store { i64, [4 x i64] } zeroinitializer, ptr %t160
  %t161 = getelementptr { i64, [4 x i64] }, ptr %t160, i32 0, i32 0
  store i64 1, ptr %t161
  %t162 = load %"compiler/mir:Place", ptr %l78
  %t163 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t162, 0
  %t164 = getelementptr { i64, [4 x i64] }, ptr %t160, i32 0, i32 1
  store { %"compiler/mir:Place" } %t163, ptr %t164
  %t165 = load { i64, [4 x i64] }, ptr %t160
  store { i64, [15 x i64] } zeroinitializer, ptr %t166
  %t167 = getelementptr { i64, [15 x i64] }, ptr %t166, i32 0, i32 0
  store i64 0, ptr %t167
  %t169 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t165, 0
  %t170 = getelementptr { i64, [15 x i64] }, ptr %t166, i32 0, i32 1
  store { { i64, [4 x i64] } } %t169, ptr %t170
  %t171 = load { i64, [15 x i64] }, ptr %t166
  %t172 = load %"compiler/source:Span", ptr %l4
  %t173 = load ptr, ptr %l74, !tbaa !29
  %t174 = load i32, ptr %l75, !tbaa !23
  %t177 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t173, i32 %t174, { i64, [15 x i64] } %t171, %"compiler/source:Span" %t172)
  store { i64, [4 x i64] } %t177, ptr %l82
  br label %bb36
bb36:
  store { i64, [21 x i64] } zeroinitializer, ptr %t178
  %t179 = getelementptr { i64, [21 x i64] }, ptr %t178, i32 0, i32 0
  store i64 9, ptr %t179
  %t180 = load %"compiler/source:Span", ptr %l71
  %t181 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } undef, %"compiler/source:Span" %t180, 0
  %t182 = load { i64, [1 x i64] }, ptr %l72
  %t183 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t181, { i64, [1 x i64] } %t182, 1
  %t184 = load i32, ptr %l73
  %t185 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t183, i32 %t184, 2
  %t186 = load { i64, [4 x i64] }, ptr %l82
  %t187 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t185, { i64, [4 x i64] } %t186, 3
  %t188 = getelementptr { i64, [21 x i64] }, ptr %t178, i32 0, i32 1
  store { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t187, ptr %t188
  %t189 = load { i64, [21 x i64] }, ptr %t178
  %t191 = call ptr @__olang_scope_alloc_a(ptr %s3, i64 176, i64 8)
  store { i64, [21 x i64] } %t189, ptr %t191
  %t192 = load ptr, ptr %l70, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s3, ptr %t192, ptr %t191)
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s3)
  br label %ret
bb38:
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t195 = load %"compiler/lower:pl", ptr %l1
  %t196 = load i32, ptr %l2, !tbaa !23
  %t197 = load { i64, [1 x i64] }, ptr %l3
  %t198 = load %"compiler/source:Span", ptr %l4
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2erenderAt(ptr %v0, ptr %v1, ptr %t194, %"compiler/lower:pl" %t195, i32 %t196, { i64, [1 x i64] } %t197, %"compiler/source:Span" %t198, i1 false)
  br label %bb39
bb39:
  br label %ret
ret:
  ret void
}

define dso_local { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einnermost(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l9 = alloca i64
  %l17 = alloca %"compiler/lower:level"
  %l21 = alloca i1
  %l24 = alloca i1
  %l27 = alloca i1
  %l33 = alloca %"compiler/lower:level"
  %rv = alloca { i64, [1 x i64] }
  %t8 = alloca { i64, [1 x i64] }, align 8
  %t68 = alloca { i64, [1 x i64] }, align 8
  %t79 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 19
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  store { i64, [1 x i64] } zeroinitializer, ptr %t8
  %t9 = getelementptr { i64, [1 x i64] }, ptr %t8, i32 0, i32 0
  store i64 2, ptr %t9
  %t10 = load { i64, [1 x i64] }, ptr %t8
  store { i64, [1 x i64] } %t10, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/lower:lowering", ptr %t12, i32 0, i32 9
  %t16 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e_2eLen_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %t14)
  store i64 %t16, ptr %l9
  br label %bb4
bb4:
  %t17 = load i64, ptr %l9, !tbaa !24
  %t18 = sub i64 %t17, 1
  store i64 %t18, ptr %l1, !tbaa !24
  br label %bb5
bb5:
  %t20 = load i64, ptr %l1, !tbaa !24
  %t22 = icmp sge i64 %t20, 0
  %t24 = xor i1 %t22, true
  br i1 %t24, label %bb6, label %bb7
bb6:
  br label %bb24
bb7:
  br label %bb8
bb8:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/lower:lowering", ptr %t26, i32 0, i32 9
  %t29 = load i64, ptr %l1, !tbaa !24
  %t32 = call %"compiler/lower:level" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e_2eAt_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %t28, i64 %t29)
  store %"compiler/lower:level" %t32, ptr %l17
  br label %bb9
bb9:
  %t33 = getelementptr %"compiler/lower:level", ptr %l17, i32 0, i32 2
  %t34 = load i32, ptr %t33
  store i32 %t34, ptr %l2
  %t36 = load i32, ptr %l2
  %t38 = trunc i64 1 to i32
  %t39 = icmp eq i32 %t36, %t38
  br i1 %t39, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb12
bb11:
  %t41 = load i32, ptr %l2
  %t43 = trunc i64 2 to i32
  %t44 = icmp eq i32 %t41, %t43
  store i1 %t44, ptr %l21, !tbaa !21
  br label %bb12
bb12:
  %t46 = load i1, ptr %l21, !tbaa !21
  br i1 %t46, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l24, !tbaa !21
  br label %bb15
bb14:
  %t47 = load i32, ptr %l2
  %t49 = trunc i64 3 to i32
  %t50 = icmp eq i32 %t47, %t49
  store i1 %t50, ptr %l24, !tbaa !21
  br label %bb15
bb15:
  %t52 = load i1, ptr %l24, !tbaa !21
  br i1 %t52, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb18
bb17:
  %t53 = load i32, ptr %l2
  %t55 = trunc i64 0 to i32
  %t56 = icmp eq i32 %t53, %t55
  store i1 %t56, ptr %l27, !tbaa !21
  br label %bb18
bb18:
  %t58 = load i1, ptr %l27, !tbaa !21
  br i1 %t58, label %bb19, label %bb20
bb19:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/lower:lowering", ptr %t59, i32 0, i32 9
  %t62 = load i64, ptr %l1, !tbaa !24
  %t65 = call %"compiler/lower:level" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e_2eAt_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %t61, i64 %t62)
  store %"compiler/lower:level" %t65, ptr %l33
  br label %bb21
bb20:
  br label %bb22
bb21:
  %t66 = getelementptr %"compiler/lower:level", ptr %l33, i32 0, i32 0
  %t67 = load i32, ptr %t66, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t68
  %t69 = getelementptr { i64, [1 x i64] }, ptr %t68, i32 0, i32 0
  store i64 0, ptr %t69
  %t71 = insertvalue { i32 } undef, i32 %t67, 0
  %t72 = getelementptr { i64, [1 x i64] }, ptr %t68, i32 0, i32 1
  store { i32 } %t71, ptr %t72
  %t73 = load { i64, [1 x i64] }, ptr %t68
  store { i64, [1 x i64] } %t73, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  %t75 = load i64, ptr %l1, !tbaa !24
  %t77 = sub i64 %t75, 1
  store i64 %t77, ptr %l1, !tbaa !24
  br label %bb5
bb24:
  store { i64, [1 x i64] } zeroinitializer, ptr %t79
  %t80 = getelementptr { i64, [1 x i64] }, ptr %t79, i32 0, i32 0
  store i64 2, ptr %t80
  %t81 = load { i64, [1 x i64] }, ptr %t79
  store { i64, [1 x i64] } %t81, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [1 x i64] }, ptr %rv
  ret { i64, [1 x i64] } %rr
}

define dso_local { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einstance(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l14 = alloca i64
  %l18 = alloca i64
  %l21 = alloca i64
  %l43 = alloca { i64, [1 x i64] }
  %rv = alloca { i64, [1 x i64] }
  %t8 = alloca { i64, [1 x i64] }, align 8
  %t83 = alloca { i64, [1 x i64] }, align 8
  %t94 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 19
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  store { i64, [1 x i64] } zeroinitializer, ptr %t8
  %t9 = getelementptr { i64, [1 x i64] }, ptr %t8, i32 0, i32 0
  store i64 2, ptr %t9
  %t10 = load { i64, [1 x i64] }, ptr %t8
  store { i64, [1 x i64] } %t10, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  store i64 0, ptr %l1, !tbaa !24
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/lower:lowering", ptr %t12, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = getelementptr %"compiler/typed:Body", ptr %t15, i32 0, i32 6
  %t19 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2eLen_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0, ptr %t17)
  store i64 %t19, ptr %l14
  br label %bb4
bb4:
  %t20 = load i64, ptr %l14, !tbaa !24
  store i64 %t20, ptr %l2, !tbaa !24
  store i64 1, ptr %l3, !tbaa !24
  %t21 = load i64, ptr %l2, !tbaa !24
  %t22 = load i64, ptr %l1, !tbaa !24
  %t25 = icmp sgt i64 %t21, %t22
  br i1 %t25, label %bb5, label %bb6
bb5:
  %t27 = load i64, ptr %l3, !tbaa !24
  %t29 = icmp sgt i64 %t27, 0
  br i1 %t29, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l18, !tbaa !24
  br label %bb10
bb7:
  %t31 = load i64, ptr %l2, !tbaa !24
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = sub i64 %t31, %t32
  %t36 = load i64, ptr %l3, !tbaa !24
  %t39 = add i64 %t35, %t36
  %t41 = sub i64 %t39, 1
  %t42 = load i64, ptr %l3, !tbaa !24
  %t45 = sdiv i64 %t41, %t42
  store i64 %t45, ptr %l21, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l21, !tbaa !24
  br label %bb9
bb9:
  %t47 = load i64, ptr %l21, !tbaa !24
  store i64 %t47, ptr %l18, !tbaa !24
  br label %bb10
bb10:
  %t48 = load i64, ptr %l18, !tbaa !24
  store i64 %t48, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb11
bb11:
  %t49 = load i64, ptr %l5, !tbaa !24
  %t50 = load i64, ptr %l4, !tbaa !24
  %t53 = icmp slt i64 %t49, %t50
  %t55 = xor i1 %t53, true
  br i1 %t55, label %bb12, label %bb13
bb12:
  br label %bb20
bb13:
  br label %bb14
bb14:
  %t57 = load i64, ptr %l1, !tbaa !24
  %t58 = load i64, ptr %l5, !tbaa !24
  %t59 = load i64, ptr %l3, !tbaa !24
  %t62 = mul i64 %t58, %t59
  %t65 = add i64 %t57, %t62
  store i64 %t65, ptr %l6, !tbaa !24
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/lower:lowering", ptr %t67, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !29
  %t72 = getelementptr %"compiler/typed:Body", ptr %t70, i32 0, i32 6
  %t73 = load i64, ptr %l6, !tbaa !24
  %t76 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2eAt_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0, ptr %t72, i64 %t73)
  store { i64, [1 x i64] } %t76, ptr %l43
  br label %bb15
bb15:
  %t77 = load { i64, [1 x i64] }, ptr %l43
  %t79 = extractvalue { i64, [1 x i64] } %t77, 0
  %t80 = icmp eq i64 %t79, 2
  br i1 %t80, label %bb16, label %bb17
bb16:
  %t82 = load i64, ptr %l6, !tbaa !24
  store { i64, [1 x i64] } zeroinitializer, ptr %t83
  %t84 = getelementptr { i64, [1 x i64] }, ptr %t83, i32 0, i32 0
  store i64 1, ptr %t84
  %t86 = insertvalue { i64 } undef, i64 %t82, 0
  %t87 = getelementptr { i64, [1 x i64] }, ptr %t83, i32 0, i32 1
  store { i64 } %t86, ptr %t87
  %t88 = load { i64, [1 x i64] }, ptr %t83
  store { i64, [1 x i64] } %t88, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  br label %bb19
bb19:
  %t90 = load i64, ptr %l5, !tbaa !24
  %t92 = add i64 %t90, 1
  store i64 %t92, ptr %l5, !tbaa !24
  br label %bb11
bb20:
  store { i64, [1 x i64] } zeroinitializer, ptr %t94
  %t95 = getelementptr { i64, [1 x i64] }, ptr %t94, i32 0, i32 0
  store i64 2, ptr %t95
  %t96 = load { i64, [1 x i64] }, ptr %t94
  store { i64, [1 x i64] } %t96, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [1 x i64] }, ptr %rv
  ret { i64, [1 x i64] } %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2ejoin(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l13 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l17 = alloca i32
  %l20 = alloca i64
  %l23 = alloca %"compiler/lower:tryCtx"
  %l33 = alloca { i64, ptr }
  %l51 = alloca ptr
  %l53 = alloca %"compiler/lower:level"
  %l64 = alloca { i64, ptr }
  %l72 = alloca %"compiler/lower:tryCtx"
  %l75 = alloca %"compiler/lower:tryCtx"
  %l76 = alloca i32
  %l77 = alloca i32
  %l80 = alloca i32
  %l81 = alloca i32
  %l82 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t4 = getelementptr %"compiler/typed:Join", ptr %t2, i32 0, i32 0
  %t5 = load ptr, ptr %t4, !tbaa !29
  %t8 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2ejoinErrors(ptr %v0, ptr %v1, ptr %t1, ptr %t5)
  store i32 %t8, ptr %l17
  br label %bb1
bb1:
  %t9 = load i32, ptr %l17, !tbaa !23
  store i32 %t9, ptr %l3, !tbaa !23
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/lower:lowering", ptr %t10, i32 0, i32 9
  %t14 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e_2eLen_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %t12)
  store i64 %t14, ptr %l20
  br label %bb2
bb2:
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t17 = getelementptr %"compiler/typed:Join", ptr %t15, i32 0, i32 2
  %t18 = load { i64, ptr }, ptr %t17, !tbaa !27
  %t19 = load i64, ptr %l20, !tbaa !24
  %t21 = call %"compiler/lower:tryCtx" @compiler_2flower_3atryCtx_2ector(ptr %v1, ptr %v0, i64 %t19, { i64, ptr } %t18, i1 false, i1 false)
  store %"compiler/lower:tryCtx" %t21, ptr %l23
  br label %bb3
bb3:
  %t22 = load %"compiler/lower:tryCtx", ptr %l23
  %t23 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store %"compiler/lower:tryCtx" %t22, ptr %t23
  store ptr %t23, ptr %l4, !tbaa !29
  %t25 = load ptr, ptr %l2, !tbaa !29
  %t27 = getelementptr %"compiler/typed:Join", ptr %t25, i32 0, i32 2
  %t28 = load { i64, ptr }, ptr %t27, !tbaa !27
  store { i64, ptr } %t28, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t30 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t30, 0
  store i64 %t32, ptr %l7, !tbaa !24
  br label %bb4
bb4:
  %t34 = load i64, ptr %l6, !tbaa !24
  %t35 = load i64, ptr %l7, !tbaa !24
  %t38 = icmp slt i64 %t34, %t35
  %t40 = xor i1 %t38, true
  br i1 %t40, label %bb5, label %bb6
bb5:
  br label %bb10
bb6:
  br label %bb7
bb7:
  %t42 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t42, ptr %l33, !tbaa !27
  %t43 = load i64, ptr %l6, !tbaa !24
  %t45 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !27
  %t47 = getelementptr ptr, ptr %t46, i64 %t43
  %t48 = load ptr, ptr %t47, !tbaa !39
  store ptr %t48, ptr %l8, !tbaa !29
  %t50 = load ptr, ptr %l4, !tbaa !29
  %t52 = getelementptr %"compiler/lower:tryCtx", ptr %t50, i32 0, i32 4
  %t53 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2ePush_3ccompiler_2fmir_3aBlockId_3e(ptr %v0, ptr %t52, i32 %t53)
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t56 = load i64, ptr %l6, !tbaa !24
  %t58 = add i64 %t56, 1
  store i64 %t58, ptr %l6, !tbaa !24
  br label %bb4
bb10:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load ptr, ptr %l2, !tbaa !29
  %t63 = getelementptr %"compiler/typed:Join", ptr %t61, i32 0, i32 0
  %t64 = load ptr, ptr %t63, !tbaa !29
  %t65 = load i32, ptr %l3, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eopenBlock(ptr %v0, ptr %v1, ptr %t60, ptr %t64, i32 3, i32 %t65)
  br label %bb11
bb11:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/lower:lowering", ptr %t70, i32 0, i32 16
  %t73 = load ptr, ptr %l4, !tbaa !29
  %t75 = load %"compiler/lower:tryCtx", ptr %t73
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3atryCtx_3e_2ePush_3ccompiler_2flower_3atryCtx_3e(ptr %v0, ptr %v0, ptr %t72, %"compiler/lower:tryCtx" %t75)
  br label %bb12
bb12:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/lower:lowering", ptr %t78, i32 0, i32 17
  store ptr %t80, ptr %l51, !tbaa !29
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = call %"compiler/lower:level" @compiler_2flower_2ecompiler_2flower_3alowering_2etop(ptr %v0, ptr %t81)
  store %"compiler/lower:level" %t83, ptr %l53
  br label %bb13
bb13:
  %t84 = getelementptr %"compiler/lower:level", ptr %l53, i32 0, i32 0
  %t85 = load i32, ptr %t84, !tbaa !23
  %t86 = load ptr, ptr %l51, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2ePush_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t86, i32 %t85)
  br label %bb14
bb14:
  %t88 = load ptr, ptr %l2, !tbaa !29
  %t90 = getelementptr %"compiler/typed:Join", ptr %t88, i32 0, i32 0
  %t91 = load ptr, ptr %t90, !tbaa !29
  %t93 = getelementptr %"compiler/typed:Block", ptr %t91, i32 0, i32 1
  %t94 = load { i64, ptr }, ptr %t93, !tbaa !27
  store { i64, ptr } %t94, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t96 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t98 = extractvalue { i64, ptr } %t96, 0
  store i64 %t98, ptr %l11, !tbaa !24
  br label %bb15
bb15:
  %t100 = load i64, ptr %l10, !tbaa !24
  %t101 = load i64, ptr %l11, !tbaa !24
  %t104 = icmp slt i64 %t100, %t101
  %t106 = xor i1 %t104, true
  br i1 %t106, label %bb16, label %bb17
bb16:
  br label %bb21
bb17:
  br label %bb18
bb18:
  %t108 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t108, ptr %l64, !tbaa !27
  %t109 = load i64, ptr %l10, !tbaa !24
  %t111 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !27
  %t113 = getelementptr ptr, ptr %t112, i64 %t109
  %t114 = load ptr, ptr %t113, !tbaa !39
  %t116 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estmt(ptr %v0, ptr %v1, ptr %t116, ptr %t114)
  br label %bb19
bb19:
  br label %bb20
bb20:
  %t120 = load i64, ptr %l10, !tbaa !24
  %t122 = add i64 %t120, 1
  store i64 %t122, ptr %l10, !tbaa !24
  br label %bb15
bb21:
  %t124 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2ecloseBlock(ptr %v0, ptr %t124)
  br label %bb22
bb22:
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t128 = getelementptr %"compiler/lower:lowering", ptr %t126, i32 0, i32 16
  %t130 = call { i32, %"compiler/lower:tryCtx" } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3atryCtx_3e_2ePop_3ccompiler_2flower_3atryCtx_3e(ptr %v0, ptr %v0, ptr %t128)
  %t131 = extractvalue { i32, %"compiler/lower:tryCtx" } %t130, 1
  %t132 = extractvalue { i32, %"compiler/lower:tryCtx" } %t130, 0
  store i32 %t132, ptr %l76
  %t133 = icmp ne i32 %t132, 0
  br i1 %t133, label %bb24, label %ok.134
ok.134:
  store %"compiler/lower:tryCtx" %t131, ptr %l75
  br label %bb23
bb23:
  %t135 = load %"compiler/lower:tryCtx", ptr %l75
  store %"compiler/lower:tryCtx" %t135, ptr %l72
  br label %bb26
bb24:
  br label %bb25
bb25:
  call void @__olang_ert_req_clear()
  br label %bb26
bb26:
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t138 = getelementptr %"compiler/lower:lowering", ptr %t136, i32 0, i32 17
  %t140 = call { i32, i32 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2ePop_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t138)
  %t141 = extractvalue { i32, i32 } %t140, 1
  %t142 = extractvalue { i32, i32 } %t140, 0
  store i32 %t142, ptr %l81
  %t143 = icmp ne i32 %t142, 0
  br i1 %t143, label %bb28, label %ok.144
ok.144:
  store i32 %t141, ptr %l80
  br label %bb27
bb27:
  %t145 = load i32, ptr %l80, !tbaa !23
  store i32 %t145, ptr %l77, !tbaa !23
  br label %bb30
bb28:
  br label %bb29
bb29:
  call void @__olang_ert_req_clear()
  br label %bb30
bb30:
  %t146 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t146, ptr %l82
  br label %bb31
bb31:
  %t147 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l82
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t147, ptr %l13
  %t148 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eleaveOpen(ptr %v0, ptr %s0, ptr %t148, ptr %l13)
  br label %bb32
bb32:
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t152 = load ptr, ptr %l4, !tbaa !29
  %t154 = load %"compiler/lower:tryCtx", ptr %t152
  %t155 = load ptr, ptr %l2, !tbaa !29
  %t157 = getelementptr %"compiler/typed:Join", ptr %t155, i32 0, i32 2
  %t158 = load { i64, ptr }, ptr %t157, !tbaa !27
  %t159 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  %t160 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eclauses(ptr %v0, ptr %v0, ptr %v1, ptr %s0, ptr %t151, %"compiler/lower:tryCtx" %t154, { i64, ptr } %t158, i32 %t159, i32 %t160, ptr %l13)
  br label %bb33
bb33:
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t168 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l13
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2epatch(ptr %v0, ptr %s0, ptr %t167, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t168)
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2flower_2ecompiler_2flower_3alowering_2elocal(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [4 x i64] }
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca %"compiler/mir:Place"
  %l5 = alloca { i64, [2 x i64] }
  %l6 = alloca i32
  %l7 = alloca i32
  %l21 = alloca i32
  %l22 = alloca ptr
  %l23 = alloca %"compiler/source:Span"
  %l25 = alloca %"compiler/mir:Place"
  %s0 = alloca %olang.scope
  %rv = alloca i32
  %t44 = alloca { i64, [15 x i64] }, align 8
  %t50 = alloca { i64, [21 x i64] }, align 8
  store ptr %a0, ptr %l0
  store { i64, [4 x i64] } %a1, ptr %l1
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, [4 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [4 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 1
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [4 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { %"compiler/mir:Place" }, ptr %t6, i32 0, i32 0
  %t8 = load %"compiler/mir:Place", ptr %t7
  store %"compiler/mir:Place" %t8, ptr %l4
  br label %bb3
bb2:
  br label %bb16
bb3:
  %t10 = getelementptr %"compiler/mir:Place", ptr %l4, i32 0, i32 1
  %t11 = getelementptr %"compiler/mir:Range", ptr %t10, i32 0, i32 1
  %t12 = load i32, ptr %t11, !tbaa !23
  %t14 = icmp eq i32 %t12, 0
  br i1 %t14, label %bb4, label %bb5
bb4:
  %t16 = getelementptr %"compiler/mir:Place", ptr %l4, i32 0, i32 0
  %t17 = load { i64, [2 x i64] }, ptr %t16
  store { i64, [2 x i64] } %t17, ptr %l5
  %t19 = load { i64, [2 x i64] }, ptr %l5
  %t21 = extractvalue { i64, [2 x i64] } %t19, 0
  %t22 = icmp eq i64 %t21, 1
  br i1 %t22, label %bb6, label %bb7
bb5:
  br label %bb15
bb6:
  %t24 = getelementptr { i64, [2 x i64] }, ptr %l5, i32 0, i32 1
  %t25 = getelementptr { i32 }, ptr %t24, i32 0, i32 0
  %t26 = load i32, ptr %t25
  store i32 %t26, ptr %l6, !tbaa !23
  br label %bb8
bb7:
  br label %bb9
bb8:
  %t28 = load i32, ptr %l6, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t28, ptr %rv
  br label %ret
bb9:
  br i1 true, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_40374e6b733808a6_53e83bc62823fc4a)
  unreachable
bb14:
  br label %bb15
bb15:
  br label %bb21
bb16:
  br i1 true, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  call void @__olang_check_failed(ptr @olang_loc_71c3518922ec6807_c916f3e3052668b)
  unreachable
bb21:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = load %"compiler/source:Span", ptr %l3
  %t36 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etemp(ptr %v0, ptr %t30, i32 %a2, %"compiler/source:Span" %t32)
  store i32 %t36, ptr %l21
  br label %bb22
bb22:
  %t37 = load i32, ptr %l21, !tbaa !23
  store i32 %t37, ptr %l7, !tbaa !23
  %t38 = load ptr, ptr %l0, !tbaa !29
  store ptr %t38, ptr %l22, !tbaa !29
  %t39 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t39, ptr %l23
  %t40 = load i32, ptr %l7, !tbaa !23
  %t42 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t40)
  store %"compiler/mir:Place" %t42, ptr %l25
  br label %bb23
bb23:
  %t43 = load { i64, [4 x i64] }, ptr %l1
  store { i64, [15 x i64] } zeroinitializer, ptr %t44
  %t45 = getelementptr { i64, [15 x i64] }, ptr %t44, i32 0, i32 0
  store i64 0, ptr %t45
  %t47 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t43, 0
  %t48 = getelementptr { i64, [15 x i64] }, ptr %t44, i32 0, i32 1
  store { { i64, [4 x i64] } } %t47, ptr %t48
  %t49 = load { i64, [15 x i64] }, ptr %t44
  store { i64, [21 x i64] } zeroinitializer, ptr %t50
  %t51 = getelementptr { i64, [21 x i64] }, ptr %t50, i32 0, i32 0
  store i64 0, ptr %t51
  %t52 = load %"compiler/source:Span", ptr %l23
  %t53 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t52, 0
  %t54 = load %"compiler/mir:Place", ptr %l25
  %t55 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t53, %"compiler/mir:Place" %t54, 1
  %t57 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t55, { i64, [15 x i64] } %t49, 2
  %t58 = getelementptr { i64, [21 x i64] }, ptr %t50, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t57, ptr %t58
  %t59 = load { i64, [21 x i64] }, ptr %t50
  %t61 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t59, ptr %t61
  %t62 = load ptr, ptr %l22, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %t62, ptr %t61)
  br label %bb24
bb24:
  %t64 = load i32, ptr %l7, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t64, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2eloop(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca %"compiler/lower:loopCtx"
  %l8 = alloca i32
  %l14 = alloca ptr
  %l16 = alloca i32
  %l19 = alloca i64
  %l20 = alloca %"compiler/lower:loopCtx"
  %l24 = alloca ptr
  %l27 = alloca i64
  %l29 = alloca %"compiler/lower:loopCtx"
  %l33 = alloca i64
  %l44 = alloca %"compiler/lower:loopCtx"
  %l47 = alloca %"compiler/lower:loopCtx"
  %l48 = alloca i32
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 3
  %t5 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t3)
  store i32 %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load i32, ptr %l8, !tbaa !23
  store i32 %t6, ptr %l4, !tbaa !23
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l4, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2egoto(ptr %v0, ptr %t7, i32 %t8)
  br label %bb2
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load i32, ptr %l4, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t11, i32 %t12)
  br label %bb3
bb3:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/lower:lowering", ptr %t15, i32 0, i32 12
  store ptr %t17, ptr %l14, !tbaa !29
  %t18 = load ptr, ptr %l2, !tbaa !29
  %t20 = getelementptr %"compiler/typed:Block", ptr %t18, i32 0, i32 0
  %t21 = load i32, ptr %t20, !tbaa !23
  store i32 %t21, ptr %l16, !tbaa !23
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/lower:lowering", ptr %t22, i32 0, i32 9
  %t26 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e_2eLen_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %t24)
  store i64 %t26, ptr %l19
  br label %bb4
bb4:
  %t27 = load i32, ptr %l16, !tbaa !23
  %t28 = load i64, ptr %l19, !tbaa !24
  %t29 = call %"compiler/lower:loopCtx" @compiler_2flower_3aloopCtx_2ector(ptr %v0, i32 %t27, i64 %t28)
  store %"compiler/lower:loopCtx" %t29, ptr %l20
  br label %bb5
bb5:
  %t30 = load ptr, ptr %l14, !tbaa !29
  %t31 = load %"compiler/lower:loopCtx", ptr %l20
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3aloopCtx_3e_2ePush_3ccompiler_2flower_3aloopCtx_3e(ptr %v0, ptr %v0, ptr %t30, %"compiler/lower:loopCtx" %t31)
  br label %bb6
bb6:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eblock(ptr %v0, ptr %v1, ptr %t32, ptr %t33)
  br label %bb7
bb7:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/lower:lowering", ptr %t36, i32 0, i32 12
  store ptr %t38, ptr %l24, !tbaa !29
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/lower:lowering", ptr %t39, i32 0, i32 12
  %t43 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3aloopCtx_3e_2eLen_3ccompiler_2flower_3aloopCtx_3e(ptr %v0, ptr %t41)
  store i64 %t43, ptr %l27
  br label %bb8
bb8:
  %t44 = load i64, ptr %l27, !tbaa !24
  %t45 = sub i64 %t44, 1
  %t46 = load ptr, ptr %l24, !tbaa !29
  %t48 = call %"compiler/lower:loopCtx" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3aloopCtx_3e_2eAt_3ccompiler_2flower_3aloopCtx_3e(ptr %v0, ptr %v0, ptr %t46, i64 %t45)
  store %"compiler/lower:loopCtx" %t48, ptr %l29
  br label %bb9
bb9:
  %t49 = load %"compiler/lower:loopCtx", ptr %l29
  store %"compiler/lower:loopCtx" %t49, ptr %l5
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/lower:loopCtx", ptr %l5, i32 0, i32 4
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eleaveOpen(ptr %v0, ptr %v0, ptr %t50, ptr %t51)
  br label %bb10
bb10:
  %t54 = getelementptr %"compiler/lower:loopCtx", ptr %l5, i32 0, i32 4
  %t56 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2eLen_3ccompiler_2fmir_3aBlockId_3e(ptr %v0, ptr %t54)
  store i64 %t56, ptr %l33
  br label %bb11
bb11:
  %t57 = load i64, ptr %l33, !tbaa !24
  %t58 = icmp sgt i64 %t57, 0
  br i1 %t58, label %bb12, label %bb13
bb12:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/lower:loopCtx", ptr %l5, i32 0, i32 4
  %t62 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t61
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2epatch(ptr %v0, ptr %v0, ptr %t60, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t62)
  br label %bb14
bb13:
  br label %bb20
bb14:
  %t65 = load ptr, ptr %l3, !tbaa !29
  %t67 = icmp eq ptr %t65, null
  %t69 = xor i1 %t67, true
  br i1 %t69, label %bb15, label %bb16
bb15:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eblock(ptr %v0, ptr %v2, ptr %t71, ptr %t72)
  br label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb18
bb18:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load i32, ptr %l4, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2egoto(ptr %v0, ptr %t75, i32 %t76)
  br label %bb19
bb19:
  br label %bb20
bb20:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/lower:lowering", ptr %t79, i32 0, i32 12
  %t83 = call { i32, %"compiler/lower:loopCtx" } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3aloopCtx_3e_2ePop_3ccompiler_2flower_3aloopCtx_3e(ptr %v0, ptr %v0, ptr %t81)
  %t84 = extractvalue { i32, %"compiler/lower:loopCtx" } %t83, 1
  %t85 = extractvalue { i32, %"compiler/lower:loopCtx" } %t83, 0
  store i32 %t85, ptr %l48
  %t86 = icmp ne i32 %t85, 0
  br i1 %t86, label %bb22, label %ok.87
ok.87:
  store %"compiler/lower:loopCtx" %t84, ptr %l47
  br label %bb21
bb21:
  %t88 = load %"compiler/lower:loopCtx", ptr %l47
  store %"compiler/lower:loopCtx" %t88, ptr %l44
  br label %bb24
bb22:
  br label %bb23
bb23:
  call void @__olang_ert_req_clear()
  br label %bb24
bb24:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/lower:loopCtx", ptr %l5, i32 0, i32 3
  %t91 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t90
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2epatch(ptr %v0, ptr %v0, ptr %t89, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t91)
  br label %bb25
bb25:
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/mir:Place" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %v1, ptr %a0, %"compiler/lower:pl" %a1) #0 {
entry:
  %l1 = alloca %"compiler/lower:pl"
  %l3 = alloca ptr
  %l4 = alloca { i64, [2 x i64] }
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/mir:Place"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/mir:Place"
  store %"compiler/lower:pl" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"compiler/lower:lowering", ptr %a0, i32 0, i32 3
  store ptr %t3, ptr %l3, !tbaa !29
  %t4 = getelementptr %"compiler/lower:pl", ptr %l1, i32 0, i32 0
  %t5 = load { i64, [2 x i64] }, ptr %t4
  store { i64, [2 x i64] } %t5, ptr %l4
  %t6 = getelementptr %"compiler/lower:pl", ptr %l1, i32 0, i32 1
  %t8 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e_2eToArray_3ccompiler_2fmir_3aProj_3e(ptr %v1, ptr %s0, ptr %t6)
  store { i64, ptr } %t8, ptr %l6
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l3, !tbaa !29
  %t10 = load { i64, [2 x i64] }, ptr %l4
  %t11 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t12 = call %"compiler/mir:Place" @compiler_2fmir_2ecompiler_2fmir_3aFn_2ePlace(ptr %v0, ptr %s0, ptr %t9, { i64, [2 x i64] } %t10, { i64, ptr } %t11)
  store %"compiler/mir:Place" %t12, ptr %l7
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  %t13 = load %"compiler/mir:Place", ptr %l7
  store %"compiler/mir:Place" %t13, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/mir:Place", ptr %rv
  ret %"compiler/mir:Place" %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2eopenBlock(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l4 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca i32
  %l9 = alloca %"compiler/lower:level"
  %l10 = alloca i32
  %l12 = alloca i32
  %l19 = alloca %"compiler/typed:BlockInfo"
  %l22 = alloca i32
  %l23 = alloca ptr
  %l30 = alloca %"compiler/typed:BlockInfo"
  %l36 = alloca ptr
  %l41 = alloca %"compiler/lower:level"
  %s0 = alloca %olang.scope
  %t59 = alloca { i64, [21 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 3
  store ptr %t3, ptr %l6, !tbaa !29
  %t4 = load i32, ptr %l2
  store i32 %t4, ptr %l7
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = call %"compiler/lower:level" @compiler_2flower_2ecompiler_2flower_3alowering_2etop(ptr %v0, ptr %t5)
  store %"compiler/lower:level" %t7, ptr %l9
  br label %bb1
bb1:
  %t8 = getelementptr %"compiler/lower:level", ptr %l9, i32 0, i32 0
  %t9 = load i32, ptr %t8, !tbaa !23
  store i32 %t9, ptr %l10, !tbaa !23
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr %"compiler/typed:Block", ptr %t10, i32 0, i32 0
  %t13 = load i32, ptr %t12, !tbaa !23
  store i32 %t13, ptr %l12, !tbaa !23
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/lower:lowering", ptr %t14, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t19 = getelementptr %"compiler/typed:Body", ptr %t17, i32 0, i32 8
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t22 = getelementptr %"compiler/typed:Block", ptr %t20, i32 0, i32 0
  %t23 = load i32, ptr %t22, !tbaa !23
  %t25 = sext i32 %t23 to i64
  %t28 = call %"compiler/typed:BlockInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockInfo_3e_2eAt_3ccompiler_2ftyped_3aBlockInfo_3e(ptr %v0, ptr %t19, i64 %t25)
  store %"compiler/typed:BlockInfo" %t28, ptr %l19
  br label %bb2
bb2:
  %t29 = getelementptr %"compiler/typed:BlockInfo", ptr %l19, i32 0, i32 2
  %t30 = load %"compiler/source:Span", ptr %t29
  %t32 = load ptr, ptr %l6, !tbaa !29
  %t33 = load i32, ptr %l7
  %t34 = load i32, ptr %l10, !tbaa !23
  %t35 = load i32, ptr %l12, !tbaa !23
  %t38 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddScope(ptr %v0, ptr %t32, i32 %t33, i32 %t34, i32 %t35, %"compiler/source:Span" %t30, i32 %a3)
  store i32 %t38, ptr %l22
  br label %bb3
bb3:
  %t39 = load i32, ptr %l22, !tbaa !23
  store i32 %t39, ptr %l4, !tbaa !23
  %t40 = load ptr, ptr %l0, !tbaa !29
  store ptr %t40, ptr %l23, !tbaa !29
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/lower:lowering", ptr %t41, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !29
  %t46 = getelementptr %"compiler/typed:Body", ptr %t44, i32 0, i32 8
  %t47 = load ptr, ptr %l1, !tbaa !29
  %t49 = getelementptr %"compiler/typed:Block", ptr %t47, i32 0, i32 0
  %t50 = load i32, ptr %t49, !tbaa !23
  %t52 = sext i32 %t50 to i64
  %t55 = call %"compiler/typed:BlockInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockInfo_3e_2eAt_3ccompiler_2ftyped_3aBlockInfo_3e(ptr %v0, ptr %t46, i64 %t52)
  store %"compiler/typed:BlockInfo" %t55, ptr %l30
  br label %bb4
bb4:
  %t56 = getelementptr %"compiler/typed:BlockInfo", ptr %l30, i32 0, i32 2
  %t57 = load %"compiler/source:Span", ptr %t56
  %t58 = load i32, ptr %l4, !tbaa !23
  store { i64, [21 x i64] } zeroinitializer, ptr %t59
  %t60 = getelementptr { i64, [21 x i64] }, ptr %t59, i32 0, i32 0
  store i64 3, ptr %t60
  %t62 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t57, 0
  %t64 = insertvalue { %"compiler/source:Span", i32 } %t62, i32 %t58, 1
  %t65 = getelementptr { i64, [21 x i64] }, ptr %t59, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t64, ptr %t65
  %t66 = load { i64, [21 x i64] }, ptr %t59
  %t68 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t66, ptr %t68
  %t69 = load ptr, ptr %l23, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %t69, ptr %t68)
  br label %bb5
bb5:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/lower:lowering", ptr %t71, i32 0, i32 9
  store ptr %t73, ptr %l36, !tbaa !29
  %t74 = load i32, ptr %l4, !tbaa !23
  %t75 = load ptr, ptr %l1, !tbaa !29
  %t77 = getelementptr %"compiler/typed:Block", ptr %t75, i32 0, i32 0
  %t78 = load i32, ptr %t77, !tbaa !23
  %t79 = load i32, ptr %l2
  %t83 = call %"compiler/lower:level" @compiler_2flower_3alevel_2ector(ptr %s0, i32 %t74, i32 %t78, i32 %t79)
  store %"compiler/lower:level" %t83, ptr %l41
  br label %bb6
bb6:
  %t84 = load ptr, ptr %l36, !tbaa !29
  %t85 = load %"compiler/lower:level", ptr %l41
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e_2ePush_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %t84, %"compiler/lower:level" %t85)
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { { i64, [4 x i64] }, i32 } @compiler_2flower_2ecompiler_2flower_3alowering_2epiece(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca %"compiler/lower:pl"
  %l8 = alloca i32
  %l12 = alloca i32
  %l15 = alloca i32
  %l16 = alloca ptr
  %l19 = alloca i32
  %l20 = alloca i1
  %l22 = alloca i1
  %l26 = alloca i1
  %l29 = alloca i64
  %l31 = alloca ptr
  %l32 = alloca i1
  %l40 = alloca %"compiler/lower:pl"
  %l49 = alloca i32
  %l50 = alloca ptr
  %l51 = alloca i32
  %l54 = alloca %"compiler/mir:Place"
  %l58 = alloca { i64, [4 x i64] }
  %l64 = alloca { i64, [4 x i64] }
  %rv = alloca { { i64, [4 x i64] }, i32 }
  %t71 = alloca { i64, [4 x i64] }, align 8
  %t96 = alloca { i64, [15 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t6)
  store i32 %t8, ptr %l12
  br label %bb1
bb1:
  %t9 = load i32, ptr %l12, !tbaa !23
  store i32 %t9, ptr %l4, !tbaa !23
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load i32, ptr %l4, !tbaa !23
  %t14 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2earrayOf(ptr %v0, ptr %t10, i32 %t11)
  store i32 %t14, ptr %l15
  br label %bb2
bb2:
  %t15 = load i32, ptr %l15, !tbaa !23
  store i32 %t15, ptr %l5, !tbaa !23
  %t16 = load ptr, ptr %l3, !tbaa !29
  store ptr %t16, ptr %l16, !tbaa !29
  %t17 = load ptr, ptr %l3, !tbaa !29
  %t18 = load i32, ptr %l4, !tbaa !23
  %t21 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t17, i32 %t18)
  store i32 %t21, ptr %l19
  br label %bb3
bb3:
  %t22 = load ptr, ptr %l16, !tbaa !29
  %t23 = load i32, ptr %l19, !tbaa !23
  %t24 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t22, i32 %t23)
  store i1 %t24, ptr %l20
  br label %bb4
bb4:
  %t25 = load i1, ptr %l20, !tbaa !21
  %t26 = xor i1 %t25, true
  br i1 %t26, label %bb5, label %bb6
bb5:
  %t28 = load i32, ptr %l5, !tbaa !23
  %t29 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t32 = icmp ne i32 %t28, %t29
  store i1 %t32, ptr %l22, !tbaa !21
  br label %bb7
bb6:
  store i1 false, ptr %l22, !tbaa !21
  br label %bb7
bb7:
  %t34 = load i1, ptr %l22, !tbaa !21
  br i1 %t34, label %bb8, label %bb9
bb8:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load i32, ptr %l5, !tbaa !23
  %t39 = call i64 @compiler_2flower_2ecompiler_2flower_3alowering_2efixedLen(ptr %v0, ptr %t35, i32 %t36)
  store i64 %t39, ptr %l29
  br label %bb10
bb9:
  store i1 false, ptr %l26, !tbaa !21
  br label %bb11
bb10:
  %t40 = load i64, ptr %l29, !tbaa !24
  %t41 = icmp sge i64 %t40, 0
  store i1 %t41, ptr %l26, !tbaa !21
  br label %bb11
bb11:
  %t43 = load i1, ptr %l26, !tbaa !21
  br i1 %t43, label %bb12, label %bb13
bb12:
  %t44 = load ptr, ptr %l1, !tbaa !29
  store ptr %t44, ptr %l31, !tbaa !29
  store i1 false, ptr %l32, !tbaa !21
  %t45 = load ptr, ptr %l31, !tbaa !29
  %t46 = icmp ne ptr %t45, null
  br i1 %t46, label %bb14, label %bb15
bb13:
  br label %bb32
bb14:
  %t48 = load ptr, ptr %l31, !tbaa !29
  %t49 = load i64, ptr %t48
  %t51 = icmp eq i64 %t49, 2
  store i1 %t51, ptr %l32, !tbaa !21
  br label %bb15
bb15:
  %t52 = load i1, ptr %l32, !tbaa !21
  br i1 %t52, label %bb16, label %bb17
bb16:
  %t53 = load ptr, ptr %l1, !tbaa !29
  %t55 = getelementptr { i64, [5 x i64] }, ptr %t53, i32 0, i32 1
  %t56 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t55, i32 0, i32 2
  %t57 = load ptr, ptr %t56
  store ptr %t57, ptr %l6, !tbaa !29
  br label %bb18
bb17:
  br label %bb26
bb18:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = load ptr, ptr %l6, !tbaa !29
  %t64 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2eplace(ptr %v0, ptr %v1, ptr %v0, ptr %t59, ptr %t60)
  store %"compiler/lower:pl" %t64, ptr %l40
  br label %bb19
bb19:
  %t65 = load %"compiler/lower:pl", ptr %l40
  store %"compiler/lower:pl" %t65, ptr %l7
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/lower:lowering", ptr %t66, i32 0, i32 7
  %t69 = load i1, ptr %t68, !tbaa !21
  br i1 %t69, label %bb20, label %bb21
bb20:
  store { i64, [4 x i64] } zeroinitializer, ptr %t71
  %t72 = getelementptr { i64, [4 x i64] }, ptr %t71, i32 0, i32 0
  store i64 0, ptr %t72
  %t73 = load { i64, [4 x i64] }, ptr %t71
  %t74 = load i32, ptr %l4, !tbaa !23
  %t76 = insertvalue { { i64, [4 x i64] }, i32 } undef, { i64, [4 x i64] } %t73, 0
  %t78 = insertvalue { { i64, [4 x i64] }, i32 } %t76, i32 %t74, 1
  store { { i64, [4 x i64] }, i32 } %t78, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  %t80 = load ptr, ptr %l3, !tbaa !29
  %t81 = load i32, ptr %l4, !tbaa !23
  %t82 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t86 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t80, i32 %t81, i64 %t82)
  store i32 %t86, ptr %l49
  br label %bb23
bb23:
  %t87 = load i32, ptr %l49, !tbaa !23
  store i32 %t87, ptr %l8, !tbaa !23
  %t88 = load ptr, ptr %l0, !tbaa !29
  store ptr %t88, ptr %l50, !tbaa !29
  %t89 = load i32, ptr %l8, !tbaa !23
  store i32 %t89, ptr %l51, !tbaa !23
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t91 = load %"compiler/lower:pl", ptr %l7
  %t94 = call %"compiler/mir:Place" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %v0, ptr %t90, %"compiler/lower:pl" %t91)
  store %"compiler/mir:Place" %t94, ptr %l54
  br label %bb24
bb24:
  %t95 = load i32, ptr %l8, !tbaa !23
  store { i64, [15 x i64] } zeroinitializer, ptr %t96
  %t97 = getelementptr { i64, [15 x i64] }, ptr %t96, i32 0, i32 0
  store i64 1, ptr %t97
  %t98 = load %"compiler/mir:Place", ptr %l54
  %t99 = insertvalue { %"compiler/mir:Place", i32 } undef, %"compiler/mir:Place" %t98, 0
  %t101 = insertvalue { %"compiler/mir:Place", i32 } %t99, i32 %t95, 1
  %t102 = getelementptr { i64, [15 x i64] }, ptr %t96, i32 0, i32 1
  store { %"compiler/mir:Place", i32 } %t101, ptr %t102
  %t103 = load { i64, [15 x i64] }, ptr %t96
  %t105 = load ptr, ptr %l50, !tbaa !29
  %t106 = load i32, ptr %l51, !tbaa !23
  %t109 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t105, i32 %t106, { i64, [15 x i64] } %t103, %"compiler/source:Span" %a2)
  store { i64, [4 x i64] } %t109, ptr %l58
  br label %bb25
bb25:
  %t110 = load i32, ptr %l8, !tbaa !23
  %t111 = load { i64, [4 x i64] }, ptr %l58
  %t112 = insertvalue { { i64, [4 x i64] }, i32 } undef, { i64, [4 x i64] } %t111, 0
  %t114 = insertvalue { { i64, [4 x i64] }, i32 } %t112, i32 %t110, 1
  store { { i64, [4 x i64] }, i32 } %t114, ptr %rv
  br label %ret
bb26:
  br i1 true, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb31
bb30:
  call void @__olang_check_failed(ptr @olang_loc_eff9370fb6cf39b1_ff4f9c232720af7d)
  unreachable
bb31:
  br label %bb32
bb32:
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t117 = load ptr, ptr %l1, !tbaa !29
  %t121 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %t116, ptr %t117)
  store { i64, [4 x i64] } %t121, ptr %l64
  br label %bb33
bb33:
  %t122 = load i32, ptr %l4, !tbaa !23
  %t123 = load { i64, [4 x i64] }, ptr %l64
  %t124 = insertvalue { { i64, [4 x i64] }, i32 } undef, { i64, [4 x i64] } %t123, 0
  %t126 = insertvalue { { i64, [4 x i64] }, i32 } %t124, i32 %t122, 1
  store { { i64, [4 x i64] }, i32 } %t126, ptr %rv
  br label %ret
ret:
  %rr = load { { i64, [4 x i64] }, i32 }, ptr %rv
  ret { { i64, [4 x i64] }, i32 } %rr
}

define dso_local { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eplaceStorage(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca { i64, [1 x i64] }
  %l4 = alloca ptr
  %l5 = alloca i1
  %l12 = alloca { i64, [1 x i64] }
  %rv = alloca { i64, [1 x i64] }
  %t22 = alloca { i64, [1 x i64] }, align 8
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t17 = load i32, ptr %l2, !tbaa !23
  %t20 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2estorageOf(ptr %v0, ptr %a0, i32 %t17)
  store { i64, [1 x i64] } %t20, ptr %l12
  br label %bb6
bb6:
  %t21 = load { i64, [1 x i64] }, ptr %l12
  store { i64, [1 x i64] } %t21, ptr %l3
  br label %bb12
bb7:
  br i1 true, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  store { i64, [1 x i64] } zeroinitializer, ptr %t22
  %t23 = getelementptr { i64, [1 x i64] }, ptr %t22, i32 0, i32 0
  store i64 2, ptr %t23
  %t24 = load { i64, [1 x i64] }, ptr %t22
  store { i64, [1 x i64] } %t24, ptr %l3
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_4fc653f117519a1d_d526ff90513f5371)
  unreachable
bb12:
  %t26 = load { i64, [1 x i64] }, ptr %l3
  store { i64, [1 x i64] } %t26, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [1 x i64] }, ptr %rv
  ret { i64, [1 x i64] } %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2epopLevel(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca %"compiler/lower:level"
  %l7 = alloca i64
  %l9 = alloca i1
  %l11 = alloca ptr
  %l14 = alloca i64
  %l16 = alloca i32
  %l20 = alloca i32
  %l23 = alloca i32
  %l24 = alloca i32
  %l25 = alloca ptr
  %l28 = alloca ptr
  %l29 = alloca i32
  %l30 = alloca %"compiler/lower:level"
  %l33 = alloca %"compiler/lower:level"
  %l34 = alloca i32
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call %"compiler/lower:level" @compiler_2flower_2ecompiler_2flower_3alowering_2etop(ptr %v0, ptr %t1)
  store %"compiler/lower:level" %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = getelementptr %"compiler/lower:level", ptr %l3, i32 0, i32 0
  %t5 = load i32, ptr %t4, !tbaa !23
  store i32 %t5, ptr %l1, !tbaa !23
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/lower:lowering", ptr %t7, i32 0, i32 11
  %t11 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eLen_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t9)
  store i64 %t11, ptr %l7
  br label %bb3
bb3:
  %t12 = load i64, ptr %l7, !tbaa !24
  %t13 = icmp sgt i64 %t12, 0
  br i1 %t13, label %bb4, label %bb5
bb4:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/lower:lowering", ptr %t15, i32 0, i32 11
  store ptr %t17, ptr %l11, !tbaa !29
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/lower:lowering", ptr %t18, i32 0, i32 11
  %t22 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eLen_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t20)
  store i64 %t22, ptr %l14
  br label %bb6
bb5:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb8
bb6:
  %t23 = load i64, ptr %l14, !tbaa !24
  %t24 = sub i64 %t23, 1
  %t25 = load ptr, ptr %l11, !tbaa !29
  %t27 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eAt_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t25, i64 %t24)
  store i32 %t27, ptr %l16
  br label %bb7
bb7:
  %t28 = load i32, ptr %l1, !tbaa !23
  %t29 = load i32, ptr %l16, !tbaa !23
  %t31 = icmp eq i32 %t29, %t28
  store i1 %t31, ptr %l9, !tbaa !21
  br label %bb8
bb8:
  %t33 = load i1, ptr %l9, !tbaa !21
  %t34 = xor i1 %t33, true
  br i1 %t34, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s1)
  br label %bb21
bb10:
  br label %bb11
bb11:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/lower:lowering", ptr %t36, i32 0, i32 11
  %t40 = call { i32, i32 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2ePop_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t38)
  %t41 = extractvalue { i32, i32 } %t40, 1
  %t42 = extractvalue { i32, i32 } %t40, 0
  store i32 %t42, ptr %l24
  %t43 = icmp ne i32 %t42, 0
  br i1 %t43, label %bb13, label %ok.44
ok.44:
  store i32 %t41, ptr %l23
  br label %bb12
bb12:
  %t45 = load i32, ptr %l23, !tbaa !23
  store i32 %t45, ptr %l20, !tbaa !23
  br label %bb15
bb13:
  br label %bb14
bb14:
  call void @__olang_ert_req_clear()
  br label %bb15
bb15:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/lower:lowering", ptr %t46, i32 0, i32 10
  %t50 = call { i32, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlock_26_3e_2ePop_3ccompiler_2ftyped_3aBlock_26_3e(ptr %v0, ptr %s1, ptr %t48)
  %t51 = extractvalue { i32, ptr } %t50, 1
  %t52 = extractvalue { i32, ptr } %t50, 0
  store i32 %t52, ptr %l29
  %t53 = icmp ne i32 %t52, 0
  br i1 %t53, label %bb17, label %ok.54
ok.54:
  store ptr %t51, ptr %l28
  br label %bb16
bb16:
  %t55 = load ptr, ptr %l28, !tbaa !29
  store ptr %t55, ptr %l25, !tbaa !29
  br label %bb19
bb17:
  br label %bb18
bb18:
  call void @__olang_ert_req_clear()
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s1)
  br label %bb20
bb20:
  br label %bb2
bb21:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/lower:lowering", ptr %t56, i32 0, i32 9
  %t60 = call { i32, %"compiler/lower:level" } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e_2ePop_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %t58)
  %t61 = extractvalue { i32, %"compiler/lower:level" } %t60, 1
  %t62 = extractvalue { i32, %"compiler/lower:level" } %t60, 0
  store i32 %t62, ptr %l34
  %t63 = icmp ne i32 %t62, 0
  br i1 %t63, label %bb23, label %ok.64
ok.64:
  store %"compiler/lower:level" %t61, ptr %l33
  br label %bb22
bb22:
  %t65 = load %"compiler/lower:level", ptr %l33
  store %"compiler/lower:level" %t65, ptr %l30
  br label %bb25
bb23:
  br label %bb24
bb24:
  call void @__olang_ert_req_clear()
  br label %bb25
bb25:
  br label %ret
ret:
  ret void
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, { i64, ptr } %a3, %"compiler/source:Span" %a4) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l12 = alloca %"compiler/mir:Range"
  %l15 = alloca { i64, [4 x i64] }
  %rv = alloca { i64, [4 x i64] }
  %t12 = alloca { i64, [15 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  store i32 %t2, ptr %l6, !tbaa !23
  store i32 %a1, ptr %l7
  %t4 = load i32, ptr %l2, !tbaa !23
  store i32 %t4, ptr %l8, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/lower:lowering", ptr %t5, i32 0, i32 3
  %t11 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v0, ptr %v1, ptr %t7, { i64, ptr } %a3)
  store %"compiler/mir:Range" %t11, ptr %l12
  br label %bb1
bb1:
  store { i64, [15 x i64] } zeroinitializer, ptr %t12
  %t13 = getelementptr { i64, [15 x i64] }, ptr %t12, i32 0, i32 0
  store i64 3, ptr %t13
  %t14 = load i32, ptr %l7
  %t15 = insertvalue { i32, i32, %"compiler/mir:Range" } undef, i32 %t14, 0
  %t16 = load i32, ptr %l8, !tbaa !23
  %t17 = insertvalue { i32, i32, %"compiler/mir:Range" } %t15, i32 %t16, 1
  %t18 = load %"compiler/mir:Range", ptr %l12
  %t19 = insertvalue { i32, i32, %"compiler/mir:Range" } %t17, %"compiler/mir:Range" %t18, 2
  %t20 = getelementptr { i64, [15 x i64] }, ptr %t12, i32 0, i32 1
  store { i32, i32, %"compiler/mir:Range" } %t19, ptr %t20
  %t21 = load { i64, [15 x i64] }, ptr %t12
  %t23 = load ptr, ptr %l5, !tbaa !29
  %t24 = load i32, ptr %l6, !tbaa !23
  %t27 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t23, i32 %t24, { i64, [15 x i64] } %t21, %"compiler/source:Span" %a4)
  store { i64, [4 x i64] } %t27, ptr %l15
  br label %bb2
bb2:
  %t28 = load { i64, [4 x i64] }, ptr %l15
  store { i64, [4 x i64] } %t28, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2eprimChecks(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, i32 %a2, { i64, ptr } %a3, { i64, ptr } %a4, i32 %a5, %"compiler/source:Span" %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i32
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i32
  %l18 = alloca { i64, [4 x i64] }
  %l20 = alloca { i64, [4 x i64] }
  %l25 = alloca ptr
  %l26 = alloca { i64, ptr }
  %l28 = alloca i32
  %l29 = alloca i32
  %l32 = alloca i32
  %l38 = alloca i32
  %l39 = alloca ptr
  %l40 = alloca { i64, ptr }
  %l42 = alloca i32
  %l43 = alloca i32
  %l47 = alloca i1
  %l51 = alloca i1
  %l54 = alloca i64
  %l56 = alloca i1
  %l59 = alloca i64
  %l64 = alloca { i64, ptr }
  %l66 = alloca { i64, ptr }
  %l68 = alloca { i64, [4 x i64] }
  %l69 = alloca ptr
  %l70 = alloca i32
  %l71 = alloca i32
  %l72 = alloca { i64, [4 x i64] }
  %l73 = alloca i32
  %l76 = alloca i64
  %l78 = alloca { i64, ptr }
  %l80 = alloca { i64, [4 x i64] }
  %l89 = alloca i1
  %l90 = alloca i1
  %l93 = alloca i1
  %l94 = alloca i1
  %l97 = alloca i1
  %l100 = alloca i1
  %l101 = alloca ptr
  %l102 = alloca i32
  %l103 = alloca { i64, ptr }
  %l105 = alloca i32
  %l106 = alloca { i64, ptr }
  %l108 = alloca { i64, ptr }
  %l110 = alloca { i64, ptr }
  %l112 = alloca { i64, [4 x i64] }
  %l113 = alloca ptr
  %l114 = alloca i32
  %l115 = alloca i32
  %l116 = alloca { i64, [4 x i64] }
  %l117 = alloca { i64, ptr }
  %l119 = alloca i32
  %l121 = alloca { i64, ptr }
  %l123 = alloca { i64, [4 x i64] }
  %l130 = alloca ptr
  %l131 = alloca i32
  %l132 = alloca i32
  %l133 = alloca i32
  %l137 = alloca %"compiler/mir:Range"
  %l140 = alloca { i64, [4 x i64] }
  %l149 = alloca i1
  %l155 = alloca { i64, [4 x i64] }
  %l161 = alloca { i64, ptr }
  %l163 = alloca { i64, [4 x i64] }
  %l170 = alloca { i64, ptr }
  %l172 = alloca { i64, [4 x i64] }
  %l173 = alloca ptr
  %l174 = alloca i32
  %l175 = alloca i32
  %l176 = alloca { i64, [4 x i64] }
  %l182 = alloca { i64, ptr }
  %l184 = alloca { i64, [4 x i64] }
  %l185 = alloca { i64, ptr }
  %l187 = alloca { i64, [4 x i64] }
  %l190 = alloca i1
  %l191 = alloca ptr
  %l192 = alloca i32
  %l193 = alloca { i64, ptr }
  %l195 = alloca i32
  %l196 = alloca { i64, ptr }
  %l198 = alloca { i64, ptr }
  %l200 = alloca { i64, ptr }
  %l202 = alloca { i64, [4 x i64] }
  %l203 = alloca ptr
  %l204 = alloca i32
  %l205 = alloca i32
  %l206 = alloca { i64, [4 x i64] }
  %l207 = alloca { i64, ptr }
  %l209 = alloca i32
  %l211 = alloca { i64, ptr }
  %l213 = alloca { i64, [4 x i64] }
  %l214 = alloca ptr
  %l215 = alloca i32
  %l216 = alloca i32
  %l217 = alloca { i64, [4 x i64] }
  %l222 = alloca { i64, ptr }
  %l224 = alloca { i64, [4 x i64] }
  %l225 = alloca { i64, ptr }
  %l227 = alloca { i64, [4 x i64] }
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %t111 = alloca { i64, [4 x i64] }, align 8
  %t229 = alloca { i64, [4 x i64] }, align 8
  %t279 = alloca { i64, [15 x i64] }, align 8
  %t349 = alloca { i64, [4 x i64] }, align 8
  %t476 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  store i32 %a5, ptr %l5
  store %"compiler/source:Span" %a6, ptr %l6
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l7, !tbaa !29
  %t6 = load ptr, ptr %l7, !tbaa !29
  store ptr %t6, ptr %l25, !tbaa !29
  %t7 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t7, ptr %l26, !tbaa !27
  %t8 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !27
  %t10 = getelementptr ptr, ptr %t9, i64 0
  %t11 = load ptr, ptr %t10, !tbaa !39
  %t13 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v2, ptr %t11)
  store i32 %t13, ptr %l28
  br label %bb1
bb1:
  %t14 = load ptr, ptr %l25, !tbaa !29
  %t15 = load i32, ptr %l28, !tbaa !23
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t14, i32 %t15)
  store i32 %t16, ptr %l29
  br label %bb2
bb2:
  %t17 = load i32, ptr %l29, !tbaa !23
  store i32 %t17, ptr %l8, !tbaa !23
  %t18 = load ptr, ptr %l7, !tbaa !29
  %t19 = load i32, ptr %l5, !tbaa !23
  %t22 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t18, i32 %t19)
  store i32 %t22, ptr %l32
  br label %bb3
bb3:
  %t23 = load i32, ptr %l32, !tbaa !23
  store i32 %t23, ptr %l9, !tbaa !23
  store i32 2, ptr %l10
  %t25 = load i32, ptr %l1
  %t27 = trunc i64 20 to i32
  %t28 = icmp eq i32 %t25, %t27
  br i1 %t28, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  br label %bb72
bb6:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load i32, ptr %l5, !tbaa !23
  %t34 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2earrayOf(ptr %v0, ptr %t30, i32 %t31)
  store i32 %t34, ptr %l38
  br label %bb7
bb7:
  %t35 = load i32, ptr %l38, !tbaa !23
  store i32 %t35, ptr %l11, !tbaa !23
  %t36 = load ptr, ptr %l0, !tbaa !29
  store ptr %t36, ptr %l39, !tbaa !29
  %t37 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t37, ptr %l40, !tbaa !27
  %t38 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !27
  %t40 = getelementptr ptr, ptr %t39, i64 0
  %t41 = load ptr, ptr %t40, !tbaa !39
  %t43 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v2, ptr %t41)
  store i32 %t43, ptr %l42
  br label %bb8
bb8:
  %t44 = load ptr, ptr %l39, !tbaa !29
  %t45 = load i32, ptr %l42, !tbaa !23
  %t46 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2earrayOf(ptr %v0, ptr %t44, i32 %t45)
  store i32 %t46, ptr %l43
  br label %bb9
bb9:
  %t47 = load i32, ptr %l43, !tbaa !23
  store i32 %t47, ptr %l12, !tbaa !23
  %t48 = load i32, ptr %l11, !tbaa !23
  %t49 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t52 = icmp ne i32 %t48, %t49
  br i1 %t52, label %bb10, label %bb11
bb10:
  %t54 = load i32, ptr %l12, !tbaa !23
  %t55 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t58 = icmp ne i32 %t54, %t55
  store i1 %t58, ptr %l47, !tbaa !21
  br label %bb12
bb11:
  store i1 false, ptr %l47, !tbaa !21
  br label %bb12
bb12:
  %t60 = load i1, ptr %l47, !tbaa !21
  br i1 %t60, label %bb13, label %bb14
bb13:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = load i32, ptr %l11, !tbaa !23
  %t65 = call i64 @compiler_2flower_2ecompiler_2flower_3alowering_2efixedLen(ptr %v0, ptr %t61, i32 %t62)
  store i64 %t65, ptr %l54
  br label %bb15
bb14:
  store i1 false, ptr %l51, !tbaa !21
  br label %bb16
bb15:
  %t66 = load i64, ptr %l54, !tbaa !24
  %t67 = icmp sge i64 %t66, 0
  store i1 %t67, ptr %l51, !tbaa !21
  br label %bb16
bb16:
  %t69 = load i1, ptr %l51, !tbaa !21
  br i1 %t69, label %bb17, label %bb18
bb17:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = load i32, ptr %l12, !tbaa !23
  %t74 = call i64 @compiler_2flower_2ecompiler_2flower_3alowering_2efixedLen(ptr %v0, ptr %t70, i32 %t71)
  store i64 %t74, ptr %l59
  br label %bb19
bb18:
  store i1 false, ptr %l56, !tbaa !21
  br label %bb20
bb19:
  %t75 = load i64, ptr %l59, !tbaa !24
  %t76 = icmp slt i64 %t75, 0
  store i1 %t76, ptr %l56, !tbaa !21
  br label %bb20
bb20:
  %t78 = load i1, ptr %l56, !tbaa !21
  br i1 %t78, label %bb21, label %bb22
bb21:
  store %olang.scope zeroinitializer, ptr %s2
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t80 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  %t81 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t81, ptr %l64, !tbaa !27
  %t82 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !27
  %t84 = getelementptr { i64, [4 x i64] }, ptr %t83, i64 0
  %t85 = load { i64, [4 x i64] }, ptr %t84
  %t86 = mul i64 1, 40
  %t87 = call ptr @__olang_scope_alloc_zeroed(ptr %s2, i64 %t86)
  %t88 = insertvalue { i64, ptr } undef, i64 1, 0
  %t89 = insertvalue { i64, ptr } %t88, ptr %t87, 1
  store { i64, ptr } %t89, ptr %l66, !tbaa !27
  %t91 = getelementptr { i64, ptr }, ptr %l66, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !27
  %t93 = getelementptr { i64, [4 x i64] }, ptr %t92, i64 0
  store { i64, [4 x i64] } %t85, ptr %t93
  %t94 = load %"compiler/source:Span", ptr %l6
  %t98 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t100 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s2, ptr %t79, i32 22, i32 %t80, { i64, ptr } %t98, %"compiler/source:Span" %t94)
  store { i64, [4 x i64] } %t100, ptr %l68
  br label %bb23
bb22:
  br label %bb27
bb23:
  %t101 = load { i64, [4 x i64] }, ptr %l68
  %t102 = load ptr, ptr %l0, !tbaa !29
  store ptr %t102, ptr %l69, !tbaa !29
  store i32 13, ptr %l70
  %t103 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t103, ptr %l71, !tbaa !23
  store { i64, [4 x i64] } %t101, ptr %l72
  %t105 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  store i32 %t105, ptr %l73, !tbaa !23
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t107 = load i32, ptr %l11, !tbaa !23
  %t110 = call i64 @compiler_2flower_2ecompiler_2flower_3alowering_2efixedLen(ptr %v0, ptr %t106, i32 %t107)
  store i64 %t110, ptr %l76
  br label %bb24
bb24:
  store { i64, [4 x i64] } zeroinitializer, ptr %t111
  %t112 = getelementptr { i64, [4 x i64] }, ptr %t111, i32 0, i32 0
  store i64 2, ptr %t112
  %t113 = load i32, ptr %l73, !tbaa !23
  %t114 = insertvalue { i32, i64 } undef, i32 %t113, 0
  %t115 = load i64, ptr %l76, !tbaa !24
  %t116 = insertvalue { i32, i64 } %t114, i64 %t115, 1
  %t117 = getelementptr { i64, [4 x i64] }, ptr %t111, i32 0, i32 1
  store { i32, i64 } %t116, ptr %t117
  %t118 = load { i64, [4 x i64] }, ptr %t111
  %t119 = mul i64 2, 40
  %t120 = call ptr @__olang_scope_alloc_zeroed(ptr %s2, i64 %t119)
  %t121 = insertvalue { i64, ptr } undef, i64 2, 0
  %t122 = insertvalue { i64, ptr } %t121, ptr %t120, 1
  store { i64, ptr } %t122, ptr %l78, !tbaa !27
  %t123 = load { i64, [4 x i64] }, ptr %l72
  %t124 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !27
  %t126 = getelementptr { i64, [4 x i64] }, ptr %t125, i64 0
  store { i64, [4 x i64] } %t123, ptr %t126
  %t128 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !27
  %t130 = getelementptr { i64, [4 x i64] }, ptr %t129, i64 1
  store { i64, [4 x i64] } %t118, ptr %t130
  %t131 = load %"compiler/source:Span", ptr %l6
  %t132 = load ptr, ptr %l69, !tbaa !29
  %t133 = load i32, ptr %l70
  %t134 = load i32, ptr %l71, !tbaa !23
  %t135 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t137 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s2, ptr %t132, i32 %t133, i32 %t134, { i64, ptr } %t135, %"compiler/source:Span" %t131)
  store { i64, [4 x i64] } %t137, ptr %l80
  br label %bb25
bb25:
  %t138 = load { i64, [4 x i64] }, ptr %l80
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t141 = load i32, ptr %l2
  %t142 = load i64, ptr @G_2ecompiler_2flower_2eOutOfBounds, !tbaa !24
  %t143 = load %"compiler/source:Span", ptr %l6
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2echeck(ptr %v0, ptr %t139, { i64, [4 x i64] } %t138, i32 %t141, i32 9, i64 %t142, %"compiler/source:Span" %t143)
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb27:
  %t150 = load ptr, ptr %l7, !tbaa !29
  %t151 = load i32, ptr %l9, !tbaa !23
  %t154 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %t150, i32 %t151)
  store i1 %t154, ptr %l89
  br label %bb28
bb28:
  %t155 = load i1, ptr %l89, !tbaa !21
  br i1 %t155, label %bb29, label %bb30
bb29:
  %t156 = load ptr, ptr %l7, !tbaa !29
  %t157 = load i32, ptr %l8, !tbaa !23
  %t160 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %t156, i32 %t157)
  store i1 %t160, ptr %l93
  br label %bb31
bb30:
  store i1 false, ptr %l90, !tbaa !21
  br label %bb36
bb31:
  %t161 = load i1, ptr %l93, !tbaa !21
  br i1 %t161, label %bb32, label %bb33
bb32:
  store i1 true, ptr %l94, !tbaa !21
  br label %bb35
bb33:
  %t162 = load ptr, ptr %l7, !tbaa !29
  %t163 = load i32, ptr %l8, !tbaa !23
  %t166 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t162, i32 %t163)
  store i1 %t166, ptr %l97
  br label %bb34
bb34:
  %t167 = load i1, ptr %l97, !tbaa !21
  store i1 %t167, ptr %l94, !tbaa !21
  br label %bb35
bb35:
  %t168 = load i1, ptr %l94, !tbaa !21
  store i1 %t168, ptr %l90, !tbaa !21
  br label %bb36
bb36:
  %t169 = load i1, ptr %l90, !tbaa !21
  br i1 %t169, label %bb37, label %bb38
bb37:
  %t170 = load ptr, ptr %l7, !tbaa !29
  %t171 = load i32, ptr %l8, !tbaa !23
  %t174 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t170, i32 %t171)
  store i1 %t174, ptr %l100
  br label %bb39
bb38:
  %t175 = load ptr, ptr %l7, !tbaa !29
  %t176 = load i32, ptr %l9, !tbaa !23
  %t179 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t175, i32 %t176)
  store i1 %t179, ptr %l149
  br label %bb51
bb39:
  %t180 = load i1, ptr %l100, !tbaa !21
  br i1 %t180, label %bb40, label %bb41
bb40:
  store %olang.scope zeroinitializer, ptr %s4
  %t181 = load ptr, ptr %l0, !tbaa !29
  store ptr %t181, ptr %l101, !tbaa !29
  store i32 4, ptr %l102
  %t182 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t182, ptr %l103, !tbaa !27
  %t183 = getelementptr { i64, ptr }, ptr %l103, i32 0, i32 1
  %t184 = load ptr, ptr %t183, !tbaa !27
  %t185 = getelementptr ptr, ptr %t184, i64 0
  %t186 = load ptr, ptr %t185, !tbaa !39
  %t188 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v2, ptr %t186)
  store i32 %t188, ptr %l105
  br label %bb42
bb41:
  br label %bb47
bb42:
  %t189 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t189, ptr %l106, !tbaa !27
  %t190 = getelementptr { i64, ptr }, ptr %l106, i32 0, i32 1
  %t191 = load ptr, ptr %t190, !tbaa !27
  %t192 = getelementptr { i64, [4 x i64] }, ptr %t191, i64 0
  %t193 = load { i64, [4 x i64] }, ptr %t192
  %t194 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t194, ptr %l108, !tbaa !27
  %t195 = getelementptr { i64, ptr }, ptr %l108, i32 0, i32 1
  %t196 = load ptr, ptr %t195, !tbaa !27
  %t197 = getelementptr { i64, [4 x i64] }, ptr %t196, i64 0
  %t198 = load { i64, [4 x i64] }, ptr %t197
  %t199 = mul i64 2, 40
  %t200 = call ptr @__olang_scope_alloc_zeroed(ptr %s4, i64 %t199)
  %t201 = insertvalue { i64, ptr } undef, i64 2, 0
  %t202 = insertvalue { i64, ptr } %t201, ptr %t200, 1
  store { i64, ptr } %t202, ptr %l110, !tbaa !27
  %t204 = getelementptr { i64, ptr }, ptr %l110, i32 0, i32 1
  %t205 = load ptr, ptr %t204, !tbaa !27
  %t206 = getelementptr { i64, [4 x i64] }, ptr %t205, i64 0
  store { i64, [4 x i64] } %t193, ptr %t206
  %t208 = getelementptr { i64, ptr }, ptr %l110, i32 0, i32 1
  %t209 = load ptr, ptr %t208, !tbaa !27
  %t210 = getelementptr { i64, [4 x i64] }, ptr %t209, i64 1
  store { i64, [4 x i64] } %t198, ptr %t210
  %t211 = load %"compiler/source:Span", ptr %l6
  %t212 = load ptr, ptr %l101, !tbaa !29
  %t213 = load i32, ptr %l102
  %t214 = load i32, ptr %l105, !tbaa !23
  %t215 = load { i64, ptr }, ptr %l110, !tbaa !27
  %t217 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s4, ptr %t212, i32 %t213, i32 %t214, { i64, ptr } %t215, %"compiler/source:Span" %t211)
  store { i64, [4 x i64] } %t217, ptr %l112
  br label %bb43
bb43:
  %t218 = load { i64, [4 x i64] }, ptr %l112
  %t219 = load ptr, ptr %l0, !tbaa !29
  store ptr %t219, ptr %l113, !tbaa !29
  store i32 13, ptr %l114
  %t220 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t220, ptr %l115, !tbaa !23
  store { i64, [4 x i64] } %t218, ptr %l116
  %t222 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t222, ptr %l117, !tbaa !27
  %t223 = getelementptr { i64, ptr }, ptr %l117, i32 0, i32 1
  %t224 = load ptr, ptr %t223, !tbaa !27
  %t225 = getelementptr ptr, ptr %t224, i64 0
  %t226 = load ptr, ptr %t225, !tbaa !39
  %t228 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v2, ptr %t226)
  store i32 %t228, ptr %l119
  br label %bb44
bb44:
  store { i64, [4 x i64] } zeroinitializer, ptr %t229
  %t230 = getelementptr { i64, [4 x i64] }, ptr %t229, i32 0, i32 0
  store i64 2, ptr %t230
  %t231 = load i32, ptr %l119, !tbaa !23
  %t232 = insertvalue { i32, i64 } undef, i32 %t231, 0
  %t233 = insertvalue { i32, i64 } %t232, i64 0, 1
  %t234 = getelementptr { i64, [4 x i64] }, ptr %t229, i32 0, i32 1
  store { i32, i64 } %t233, ptr %t234
  %t235 = load { i64, [4 x i64] }, ptr %t229
  %t236 = mul i64 2, 40
  %t237 = call ptr @__olang_scope_alloc_zeroed(ptr %s4, i64 %t236)
  %t238 = insertvalue { i64, ptr } undef, i64 2, 0
  %t239 = insertvalue { i64, ptr } %t238, ptr %t237, 1
  store { i64, ptr } %t239, ptr %l121, !tbaa !27
  %t240 = load { i64, [4 x i64] }, ptr %l116
  %t241 = getelementptr { i64, ptr }, ptr %l121, i32 0, i32 1
  %t242 = load ptr, ptr %t241, !tbaa !27
  %t243 = getelementptr { i64, [4 x i64] }, ptr %t242, i64 0
  store { i64, [4 x i64] } %t240, ptr %t243
  %t245 = getelementptr { i64, ptr }, ptr %l121, i32 0, i32 1
  %t246 = load ptr, ptr %t245, !tbaa !27
  %t247 = getelementptr { i64, [4 x i64] }, ptr %t246, i64 1
  store { i64, [4 x i64] } %t235, ptr %t247
  %t248 = load %"compiler/source:Span", ptr %l6
  %t249 = load ptr, ptr %l113, !tbaa !29
  %t250 = load i32, ptr %l114
  %t251 = load i32, ptr %l115, !tbaa !23
  %t252 = load { i64, ptr }, ptr %l121, !tbaa !27
  %t254 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s4, ptr %t249, i32 %t250, i32 %t251, { i64, ptr } %t252, %"compiler/source:Span" %t248)
  store { i64, [4 x i64] } %t254, ptr %l123
  br label %bb45
bb45:
  %t255 = load { i64, [4 x i64] }, ptr %l123
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t258 = load i32, ptr %l2
  %t259 = load i32, ptr %l10
  %t260 = load i64, ptr @G_2ecompiler_2flower_2eInvalid, !tbaa !24
  %t261 = load %"compiler/source:Span", ptr %l6
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2echeck(ptr %v0, ptr %t256, { i64, [4 x i64] } %t255, i32 %t258, i32 %t259, i64 %t260, %"compiler/source:Span" %t261)
  br label %bb46
bb46:
  call void @__olang_scope_close(ptr %s4)
  br label %bb47
bb47:
  %t268 = load ptr, ptr %l0, !tbaa !29
  store ptr %t268, ptr %l130, !tbaa !29
  %t269 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t269, ptr %l131, !tbaa !23
  %t270 = load i32, ptr %l1
  store i32 %t270, ptr %l132
  %t271 = load i32, ptr %l5, !tbaa !23
  store i32 %t271, ptr %l133, !tbaa !23
  %t272 = load ptr, ptr %l0, !tbaa !29
  %t274 = getelementptr %"compiler/lower:lowering", ptr %t272, i32 0, i32 3
  %t275 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t278 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v0, ptr %v1, ptr %t274, { i64, ptr } %t275)
  store %"compiler/mir:Range" %t278, ptr %l137
  br label %bb48
bb48:
  store { i64, [15 x i64] } zeroinitializer, ptr %t279
  %t280 = getelementptr { i64, [15 x i64] }, ptr %t279, i32 0, i32 0
  store i64 4, ptr %t280
  %t281 = load i32, ptr %l132
  %t282 = insertvalue { i32, i32, %"compiler/mir:Range" } undef, i32 %t281, 0
  %t283 = load i32, ptr %l133, !tbaa !23
  %t284 = insertvalue { i32, i32, %"compiler/mir:Range" } %t282, i32 %t283, 1
  %t285 = load %"compiler/mir:Range", ptr %l137
  %t286 = insertvalue { i32, i32, %"compiler/mir:Range" } %t284, %"compiler/mir:Range" %t285, 2
  %t287 = getelementptr { i64, [15 x i64] }, ptr %t279, i32 0, i32 1
  store { i32, i32, %"compiler/mir:Range" } %t286, ptr %t287
  %t288 = load { i64, [15 x i64] }, ptr %t279
  %t289 = load %"compiler/source:Span", ptr %l6
  %t290 = load ptr, ptr %l130, !tbaa !29
  %t291 = load i32, ptr %l131, !tbaa !23
  %t294 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t290, i32 %t291, { i64, [15 x i64] } %t288, %"compiler/source:Span" %t289)
  store { i64, [4 x i64] } %t294, ptr %l140
  br label %bb49
bb49:
  %t295 = load { i64, [4 x i64] }, ptr %l140
  %t296 = load ptr, ptr %l0, !tbaa !29
  %t298 = load i32, ptr %l2
  %t299 = load i32, ptr %l10
  %t300 = load i64, ptr @G_2ecompiler_2flower_2eOverflow, !tbaa !24
  %t301 = load %"compiler/source:Span", ptr %l6
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2efails(ptr %v0, ptr %t296, { i64, [4 x i64] } %t295, i32 %t298, i32 %t299, i64 %t300, %"compiler/source:Span" %t301)
  br label %bb50
bb50:
  br label %bb71
bb51:
  %t308 = load i1, ptr %l149, !tbaa !21
  br i1 %t308, label %bb52, label %bb53
bb52:
  store %olang.scope zeroinitializer, ptr %s6
  %t309 = load ptr, ptr %l0, !tbaa !29
  %t310 = load i32, ptr %l1
  %t311 = load i32, ptr %l5, !tbaa !23
  %t312 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t313 = load %"compiler/source:Span", ptr %l6
  %t319 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %v1, ptr %t309, i32 %t310, i32 %t311, { i64, ptr } %t312, %"compiler/source:Span" %t313)
  store { i64, [4 x i64] } %t319, ptr %l155
  br label %bb54
bb53:
  br label %bb70
bb54:
  %t320 = load { i64, [4 x i64] }, ptr %l155
  store { i64, [4 x i64] } %t320, ptr %l18
  %t321 = load ptr, ptr %l0, !tbaa !29
  %t322 = load i32, ptr %l5, !tbaa !23
  %t323 = load { i64, [4 x i64] }, ptr %l18
  %t324 = load { i64, [4 x i64] }, ptr %l18
  %t325 = mul i64 2, 40
  %t326 = call ptr @__olang_scope_alloc_zeroed(ptr %s6, i64 %t325)
  %t327 = insertvalue { i64, ptr } undef, i64 2, 0
  %t328 = insertvalue { i64, ptr } %t327, ptr %t326, 1
  store { i64, ptr } %t328, ptr %l161, !tbaa !27
  %t330 = getelementptr { i64, ptr }, ptr %l161, i32 0, i32 1
  %t331 = load ptr, ptr %t330, !tbaa !27
  %t332 = getelementptr { i64, [4 x i64] }, ptr %t331, i64 0
  store { i64, [4 x i64] } %t323, ptr %t332
  %t334 = getelementptr { i64, ptr }, ptr %l161, i32 0, i32 1
  %t335 = load ptr, ptr %t334, !tbaa !27
  %t336 = getelementptr { i64, [4 x i64] }, ptr %t335, i64 1
  store { i64, [4 x i64] } %t324, ptr %t336
  %t337 = load %"compiler/source:Span", ptr %l6
  %t341 = load { i64, ptr }, ptr %l161, !tbaa !27
  %t343 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s6, ptr %t321, i32 4, i32 %t322, { i64, ptr } %t341, %"compiler/source:Span" %t337)
  store { i64, [4 x i64] } %t343, ptr %l163
  br label %bb55
bb55:
  %t344 = load { i64, [4 x i64] }, ptr %l163
  %t345 = load ptr, ptr %l0, !tbaa !29
  %t346 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t348 = load i32, ptr %l5, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t349
  %t350 = getelementptr { i64, [4 x i64] }, ptr %t349, i32 0, i32 0
  store i64 2, ptr %t350
  %t352 = insertvalue { i32, i64 } undef, i32 %t348, 0
  %t353 = insertvalue { i32, i64 } %t352, i64 0, 1
  %t354 = getelementptr { i64, [4 x i64] }, ptr %t349, i32 0, i32 1
  store { i32, i64 } %t353, ptr %t354
  %t355 = load { i64, [4 x i64] }, ptr %t349
  %t356 = mul i64 2, 40
  %t357 = call ptr @__olang_scope_alloc_zeroed(ptr %s6, i64 %t356)
  %t358 = insertvalue { i64, ptr } undef, i64 2, 0
  %t359 = insertvalue { i64, ptr } %t358, ptr %t357, 1
  store { i64, ptr } %t359, ptr %l170, !tbaa !27
  %t361 = getelementptr { i64, ptr }, ptr %l170, i32 0, i32 1
  %t362 = load ptr, ptr %t361, !tbaa !27
  %t363 = getelementptr { i64, [4 x i64] }, ptr %t362, i64 0
  store { i64, [4 x i64] } %t344, ptr %t363
  %t365 = getelementptr { i64, ptr }, ptr %l170, i32 0, i32 1
  %t366 = load ptr, ptr %t365, !tbaa !27
  %t367 = getelementptr { i64, [4 x i64] }, ptr %t366, i64 1
  store { i64, [4 x i64] } %t355, ptr %t367
  %t368 = load %"compiler/source:Span", ptr %l6
  %t372 = load { i64, ptr }, ptr %l170, !tbaa !27
  %t374 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s6, ptr %t345, i32 13, i32 %t346, { i64, ptr } %t372, %"compiler/source:Span" %t368)
  store { i64, [4 x i64] } %t374, ptr %l172
  br label %bb56
bb56:
  %t375 = load { i64, [4 x i64] }, ptr %l172
  store { i64, [4 x i64] } %t375, ptr %l20
  %t376 = load ptr, ptr %l0, !tbaa !29
  store ptr %t376, ptr %l173, !tbaa !29
  store i32 11, ptr %l174
  %t377 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t377, ptr %l175, !tbaa !23
  %t378 = load { i64, [4 x i64] }, ptr %l20
  store { i64, [4 x i64] } %t378, ptr %l176
  %t379 = load ptr, ptr %l0, !tbaa !29
  %t380 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t381 = load { i64, [4 x i64] }, ptr %l18
  %t382 = load { i64, [4 x i64] }, ptr %l18
  %t383 = mul i64 2, 40
  %t384 = call ptr @__olang_scope_alloc_zeroed(ptr %s6, i64 %t383)
  %t385 = insertvalue { i64, ptr } undef, i64 2, 0
  %t386 = insertvalue { i64, ptr } %t385, ptr %t384, 1
  store { i64, ptr } %t386, ptr %l182, !tbaa !27
  %t388 = getelementptr { i64, ptr }, ptr %l182, i32 0, i32 1
  %t389 = load ptr, ptr %t388, !tbaa !27
  %t390 = getelementptr { i64, [4 x i64] }, ptr %t389, i64 0
  store { i64, [4 x i64] } %t381, ptr %t390
  %t392 = getelementptr { i64, ptr }, ptr %l182, i32 0, i32 1
  %t393 = load ptr, ptr %t392, !tbaa !27
  %t394 = getelementptr { i64, [4 x i64] }, ptr %t393, i64 1
  store { i64, [4 x i64] } %t382, ptr %t394
  %t395 = load %"compiler/source:Span", ptr %l6
  %t399 = load { i64, ptr }, ptr %l182, !tbaa !27
  %t401 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s6, ptr %t379, i32 14, i32 %t380, { i64, ptr } %t399, %"compiler/source:Span" %t395)
  store { i64, [4 x i64] } %t401, ptr %l184
  br label %bb57
bb57:
  %t402 = mul i64 2, 40
  %t403 = call ptr @__olang_scope_alloc_zeroed(ptr %s6, i64 %t402)
  %t404 = insertvalue { i64, ptr } undef, i64 2, 0
  %t405 = insertvalue { i64, ptr } %t404, ptr %t403, 1
  store { i64, ptr } %t405, ptr %l185, !tbaa !27
  %t406 = load { i64, [4 x i64] }, ptr %l176
  %t407 = getelementptr { i64, ptr }, ptr %l185, i32 0, i32 1
  %t408 = load ptr, ptr %t407, !tbaa !27
  %t409 = getelementptr { i64, [4 x i64] }, ptr %t408, i64 0
  store { i64, [4 x i64] } %t406, ptr %t409
  %t410 = load { i64, [4 x i64] }, ptr %l184
  %t411 = getelementptr { i64, ptr }, ptr %l185, i32 0, i32 1
  %t412 = load ptr, ptr %t411, !tbaa !27
  %t413 = getelementptr { i64, [4 x i64] }, ptr %t412, i64 1
  store { i64, [4 x i64] } %t410, ptr %t413
  %t414 = load %"compiler/source:Span", ptr %l6
  %t415 = load ptr, ptr %l173, !tbaa !29
  %t416 = load i32, ptr %l174
  %t417 = load i32, ptr %l175, !tbaa !23
  %t418 = load { i64, ptr }, ptr %l185, !tbaa !27
  %t420 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s6, ptr %t415, i32 %t416, i32 %t417, { i64, ptr } %t418, %"compiler/source:Span" %t414)
  store { i64, [4 x i64] } %t420, ptr %l187
  br label %bb58
bb58:
  %t421 = load { i64, [4 x i64] }, ptr %l187
  store { i64, [4 x i64] } %t421, ptr %l20
  %t422 = load ptr, ptr %l7, !tbaa !29
  %t423 = load i32, ptr %l8, !tbaa !23
  %t426 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t422, i32 %t423)
  store i1 %t426, ptr %l190
  br label %bb59
bb59:
  %t427 = load i1, ptr %l190, !tbaa !21
  br i1 %t427, label %bb60, label %bb61
bb60:
  store %olang.scope zeroinitializer, ptr %s7
  %t428 = load ptr, ptr %l0, !tbaa !29
  store ptr %t428, ptr %l191, !tbaa !29
  store i32 4, ptr %l192
  %t429 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t429, ptr %l193, !tbaa !27
  %t430 = getelementptr { i64, ptr }, ptr %l193, i32 0, i32 1
  %t431 = load ptr, ptr %t430, !tbaa !27
  %t432 = getelementptr ptr, ptr %t431, i64 0
  %t433 = load ptr, ptr %t432, !tbaa !39
  %t435 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v2, ptr %t433)
  store i32 %t435, ptr %l195
  br label %bb62
bb61:
  br label %bb68
bb62:
  %t436 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t436, ptr %l196, !tbaa !27
  %t437 = getelementptr { i64, ptr }, ptr %l196, i32 0, i32 1
  %t438 = load ptr, ptr %t437, !tbaa !27
  %t439 = getelementptr { i64, [4 x i64] }, ptr %t438, i64 0
  %t440 = load { i64, [4 x i64] }, ptr %t439
  %t441 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t441, ptr %l198, !tbaa !27
  %t442 = getelementptr { i64, ptr }, ptr %l198, i32 0, i32 1
  %t443 = load ptr, ptr %t442, !tbaa !27
  %t444 = getelementptr { i64, [4 x i64] }, ptr %t443, i64 0
  %t445 = load { i64, [4 x i64] }, ptr %t444
  %t446 = mul i64 2, 40
  %t447 = call ptr @__olang_scope_alloc_zeroed(ptr %s7, i64 %t446)
  %t448 = insertvalue { i64, ptr } undef, i64 2, 0
  %t449 = insertvalue { i64, ptr } %t448, ptr %t447, 1
  store { i64, ptr } %t449, ptr %l200, !tbaa !27
  %t451 = getelementptr { i64, ptr }, ptr %l200, i32 0, i32 1
  %t452 = load ptr, ptr %t451, !tbaa !27
  %t453 = getelementptr { i64, [4 x i64] }, ptr %t452, i64 0
  store { i64, [4 x i64] } %t440, ptr %t453
  %t455 = getelementptr { i64, ptr }, ptr %l200, i32 0, i32 1
  %t456 = load ptr, ptr %t455, !tbaa !27
  %t457 = getelementptr { i64, [4 x i64] }, ptr %t456, i64 1
  store { i64, [4 x i64] } %t445, ptr %t457
  %t458 = load %"compiler/source:Span", ptr %l6
  %t459 = load ptr, ptr %l191, !tbaa !29
  %t460 = load i32, ptr %l192
  %t461 = load i32, ptr %l195, !tbaa !23
  %t462 = load { i64, ptr }, ptr %l200, !tbaa !27
  %t464 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s7, ptr %t459, i32 %t460, i32 %t461, { i64, ptr } %t462, %"compiler/source:Span" %t458)
  store { i64, [4 x i64] } %t464, ptr %l202
  br label %bb63
bb63:
  %t465 = load { i64, [4 x i64] }, ptr %l202
  %t466 = load ptr, ptr %l0, !tbaa !29
  store ptr %t466, ptr %l203, !tbaa !29
  store i32 13, ptr %l204
  %t467 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t467, ptr %l205, !tbaa !23
  store { i64, [4 x i64] } %t465, ptr %l206
  %t469 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t469, ptr %l207, !tbaa !27
  %t470 = getelementptr { i64, ptr }, ptr %l207, i32 0, i32 1
  %t471 = load ptr, ptr %t470, !tbaa !27
  %t472 = getelementptr ptr, ptr %t471, i64 0
  %t473 = load ptr, ptr %t472, !tbaa !39
  %t475 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v2, ptr %t473)
  store i32 %t475, ptr %l209
  br label %bb64
bb64:
  store { i64, [4 x i64] } zeroinitializer, ptr %t476
  %t477 = getelementptr { i64, [4 x i64] }, ptr %t476, i32 0, i32 0
  store i64 2, ptr %t477
  %t478 = load i32, ptr %l209, !tbaa !23
  %t479 = insertvalue { i32, i64 } undef, i32 %t478, 0
  %t480 = insertvalue { i32, i64 } %t479, i64 0, 1
  %t481 = getelementptr { i64, [4 x i64] }, ptr %t476, i32 0, i32 1
  store { i32, i64 } %t480, ptr %t481
  %t482 = load { i64, [4 x i64] }, ptr %t476
  %t483 = mul i64 2, 40
  %t484 = call ptr @__olang_scope_alloc_zeroed(ptr %s7, i64 %t483)
  %t485 = insertvalue { i64, ptr } undef, i64 2, 0
  %t486 = insertvalue { i64, ptr } %t485, ptr %t484, 1
  store { i64, ptr } %t486, ptr %l211, !tbaa !27
  %t487 = load { i64, [4 x i64] }, ptr %l206
  %t488 = getelementptr { i64, ptr }, ptr %l211, i32 0, i32 1
  %t489 = load ptr, ptr %t488, !tbaa !27
  %t490 = getelementptr { i64, [4 x i64] }, ptr %t489, i64 0
  store { i64, [4 x i64] } %t487, ptr %t490
  %t492 = getelementptr { i64, ptr }, ptr %l211, i32 0, i32 1
  %t493 = load ptr, ptr %t492, !tbaa !27
  %t494 = getelementptr { i64, [4 x i64] }, ptr %t493, i64 1
  store { i64, [4 x i64] } %t482, ptr %t494
  %t495 = load %"compiler/source:Span", ptr %l6
  %t496 = load ptr, ptr %l203, !tbaa !29
  %t497 = load i32, ptr %l204
  %t498 = load i32, ptr %l205, !tbaa !23
  %t499 = load { i64, ptr }, ptr %l211, !tbaa !27
  %t501 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s7, ptr %t496, i32 %t497, i32 %t498, { i64, ptr } %t499, %"compiler/source:Span" %t495)
  store { i64, [4 x i64] } %t501, ptr %l213
  br label %bb65
bb65:
  %t502 = load { i64, [4 x i64] }, ptr %l213
  %t503 = load ptr, ptr %l0, !tbaa !29
  store ptr %t503, ptr %l214, !tbaa !29
  store i32 11, ptr %l215
  %t504 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t504, ptr %l216, !tbaa !23
  %t505 = load { i64, [4 x i64] }, ptr %l20
  store { i64, [4 x i64] } %t505, ptr %l217
  %t506 = load ptr, ptr %l0, !tbaa !29
  %t507 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t509 = mul i64 1, 40
  %t510 = call ptr @__olang_scope_alloc_zeroed(ptr %s7, i64 %t509)
  %t511 = insertvalue { i64, ptr } undef, i64 1, 0
  %t512 = insertvalue { i64, ptr } %t511, ptr %t510, 1
  store { i64, ptr } %t512, ptr %l222, !tbaa !27
  %t514 = getelementptr { i64, ptr }, ptr %l222, i32 0, i32 1
  %t515 = load ptr, ptr %t514, !tbaa !27
  %t516 = getelementptr { i64, [4 x i64] }, ptr %t515, i64 0
  store { i64, [4 x i64] } %t502, ptr %t516
  %t517 = load %"compiler/source:Span", ptr %l6
  %t521 = load { i64, ptr }, ptr %l222, !tbaa !27
  %t523 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s7, ptr %t506, i32 2, i32 %t507, { i64, ptr } %t521, %"compiler/source:Span" %t517)
  store { i64, [4 x i64] } %t523, ptr %l224
  br label %bb66
bb66:
  %t524 = mul i64 2, 40
  %t525 = call ptr @__olang_scope_alloc_zeroed(ptr %s7, i64 %t524)
  %t526 = insertvalue { i64, ptr } undef, i64 2, 0
  %t527 = insertvalue { i64, ptr } %t526, ptr %t525, 1
  store { i64, ptr } %t527, ptr %l225, !tbaa !27
  %t528 = load { i64, [4 x i64] }, ptr %l217
  %t529 = getelementptr { i64, ptr }, ptr %l225, i32 0, i32 1
  %t530 = load ptr, ptr %t529, !tbaa !27
  %t531 = getelementptr { i64, [4 x i64] }, ptr %t530, i64 0
  store { i64, [4 x i64] } %t528, ptr %t531
  %t532 = load { i64, [4 x i64] }, ptr %l224
  %t533 = getelementptr { i64, ptr }, ptr %l225, i32 0, i32 1
  %t534 = load ptr, ptr %t533, !tbaa !27
  %t535 = getelementptr { i64, [4 x i64] }, ptr %t534, i64 1
  store { i64, [4 x i64] } %t532, ptr %t535
  %t536 = load %"compiler/source:Span", ptr %l6
  %t537 = load ptr, ptr %l214, !tbaa !29
  %t538 = load i32, ptr %l215
  %t539 = load i32, ptr %l216, !tbaa !23
  %t540 = load { i64, ptr }, ptr %l225, !tbaa !27
  %t542 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s7, ptr %t537, i32 %t538, i32 %t539, { i64, ptr } %t540, %"compiler/source:Span" %t536)
  store { i64, [4 x i64] } %t542, ptr %l227
  br label %bb67
bb67:
  %t543 = load { i64, [4 x i64] }, ptr %l227
  store { i64, [4 x i64] } %t543, ptr %l20
  call void @__olang_scope_close(ptr %s7)
  br label %bb68
bb68:
  %t544 = load ptr, ptr %l0, !tbaa !29
  %t545 = load { i64, [4 x i64] }, ptr %l20
  %t546 = load i32, ptr %l2
  %t547 = load i32, ptr %l10
  %t548 = load i64, ptr @G_2ecompiler_2flower_2eOverflow, !tbaa !24
  %t549 = load %"compiler/source:Span", ptr %l6
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2echeck(ptr %v0, ptr %t544, { i64, [4 x i64] } %t545, i32 %t546, i32 %t547, i64 %t548, %"compiler/source:Span" %t549)
  br label %bb69
bb69:
  call void @__olang_scope_close(ptr %s6)
  br label %bb70
bb70:
  br label %bb71
bb71:
  br label %bb77
bb72:
  br i1 true, label %bb73, label %bb74
bb73:
  br label %bb75
bb74:
  br label %bb76
bb75:
  br label %bb77
bb76:
  call void @__olang_check_failed(ptr @olang_loc_13d147f9f542fef2_ebbeb5a175072836)
  unreachable
bb77:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2eprologue(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l11 = alloca i32
  %l14 = alloca ptr
  %l18 = alloca i32
  %l19 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l35 = alloca i32
  %l45 = alloca { i64, ptr }
  %l55 = alloca i32
  %l63 = alloca i32
  %l72 = alloca ptr
  %l75 = alloca %"compiler/lower:level"
  %s0 = alloca %olang.scope
  %t123 = alloca { i64, [21 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  store ptr %t6, ptr %l14, !tbaa !29
  %t7 = load ptr, ptr %l2, !tbaa !29
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/lower:lowering", ptr %t8, i32 0, i32 3
  %t11 = getelementptr %"compiler/mir:Fn", ptr %t10, i32 0, i32 1
  %t12 = load i32, ptr %t11, !tbaa !23
  %t15 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t7, i32 %t12)
  store i32 %t15, ptr %l18
  br label %bb1
bb1:
  %t16 = load ptr, ptr %l14, !tbaa !29
  %t17 = load i32, ptr %l18, !tbaa !23
  %t18 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t16, i32 %t17)
  store { i64, ptr } %t18, ptr %l19
  br label %bb2
bb2:
  %t19 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t19, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t20 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t20, 0
  store i64 %t22, ptr %l5, !tbaa !24
  br label %bb3
bb3:
  %t24 = load i64, ptr %l4, !tbaa !24
  %t25 = load i64, ptr %l5, !tbaa !24
  %t28 = icmp slt i64 %t24, %t25
  %t30 = xor i1 %t28, true
  br i1 %t30, label %bb4, label %bb5
bb4:
  br label %bb9
bb5:
  br label %bb6
bb6:
  %t32 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t32, ptr %l26, !tbaa !27
  %t33 = load i64, ptr %l4, !tbaa !24
  %t35 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !27
  %t37 = getelementptr i32, ptr %t36, i64 %t33
  %t38 = load i32, ptr %t37, !tbaa !33
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/lower:lowering", ptr %t40, i32 0, i32 3
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/lower:lowering", ptr %t43, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t48 = getelementptr %"compiler/typed:Body", ptr %t46, i32 0, i32 4
  %t49 = load %"compiler/source:Span", ptr %t48
  %t54 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddParam(ptr %v0, ptr %t42, i32 0, %"compiler/source:Span" %t49, i32 %t38)
  store i32 %t54, ptr %l35
  br label %bb7
bb7:
  br label %bb8
bb8:
  %t55 = load i64, ptr %l4, !tbaa !24
  %t57 = add i64 %t55, 1
  store i64 %t57, ptr %l4, !tbaa !24
  br label %bb3
bb9:
  store { i64, ptr } %a1, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t61 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t63 = extractvalue { i64, ptr } %t61, 0
  store i64 %t63, ptr %l9, !tbaa !24
  br label %bb10
bb10:
  %t65 = load i64, ptr %l8, !tbaa !24
  %t66 = load i64, ptr %l9, !tbaa !24
  %t69 = icmp slt i64 %t65, %t66
  %t71 = xor i1 %t69, true
  br i1 %t71, label %bb11, label %bb12
bb11:
  br label %bb16
bb12:
  br label %bb13
bb13:
  %t73 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t73, ptr %l45, !tbaa !27
  %t74 = load i64, ptr %l8, !tbaa !24
  %t76 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !27
  %t78 = getelementptr { i64, [1 x i64] }, ptr %t77, i64 %t74
  %t79 = load { i64, [1 x i64] }, ptr %t78
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/lower:lowering", ptr %t81, i32 0, i32 3
  %t84 = getelementptr %"compiler/mir:Fn", ptr %t83, i32 0, i32 6
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aVarKind_3e_2ePush_3ccompiler_2fmir_3aVarKind_3e(ptr %v0, ptr %t84, { i64, [1 x i64] } %t79)
  br label %bb14
bb14:
  br label %bb15
bb15:
  %t88 = load i64, ptr %l8, !tbaa !24
  %t90 = add i64 %t88, 1
  store i64 %t90, ptr %l8, !tbaa !24
  br label %bb10
bb16:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/lower:lowering", ptr %t92, i32 0, i32 3
  %t96 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t94)
  store i32 %t96, ptr %l55
  br label %bb17
bb17:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/lower:lowering", ptr %t97, i32 0, i32 3
  %t100 = load i32, ptr @G_2ecompiler_2fmir_2eNoScope, !tbaa !23
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr %"compiler/lower:lowering", ptr %t101, i32 0, i32 1
  %t104 = load ptr, ptr %t103, !tbaa !29
  %t106 = getelementptr %"compiler/typed:Body", ptr %t104, i32 0, i32 4
  %t107 = load %"compiler/source:Span", ptr %t106
  %t112 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddScope(ptr %v0, ptr %t99, i32 0, i32 %t100, i32 -1, %"compiler/source:Span" %t107, i32 0)
  store i32 %t112, ptr %l63
  br label %bb18
bb18:
  %t113 = load i32, ptr %l63, !tbaa !23
  store i32 %t113, ptr %l11, !tbaa !23
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"compiler/lower:lowering", ptr %t115, i32 0, i32 1
  %t118 = load ptr, ptr %t117, !tbaa !29
  %t120 = getelementptr %"compiler/typed:Body", ptr %t118, i32 0, i32 4
  %t121 = load %"compiler/source:Span", ptr %t120
  %t122 = load i32, ptr %l11, !tbaa !23
  store { i64, [21 x i64] } zeroinitializer, ptr %t123
  %t124 = getelementptr { i64, [21 x i64] }, ptr %t123, i32 0, i32 0
  store i64 3, ptr %t124
  %t126 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t121, 0
  %t128 = insertvalue { %"compiler/source:Span", i32 } %t126, i32 %t122, 1
  %t129 = getelementptr { i64, [21 x i64] }, ptr %t123, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t128, ptr %t129
  %t130 = load { i64, [21 x i64] }, ptr %t123
  %t132 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t130, ptr %t132
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %t114, ptr %t132)
  br label %bb19
bb19:
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t137 = getelementptr %"compiler/lower:lowering", ptr %t135, i32 0, i32 9
  store ptr %t137, ptr %l72, !tbaa !29
  %t138 = load i32, ptr %l11, !tbaa !23
  %t141 = call %"compiler/lower:level" @compiler_2flower_3alevel_2ector(ptr %s0, i32 %t138, i32 -1, i32 0)
  store %"compiler/lower:level" %t141, ptr %l75
  br label %bb20
bb20:
  %t142 = load ptr, ptr %l72, !tbaa !29
  %t143 = load %"compiler/lower:level", ptr %l75
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e_2ePush_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %t142, %"compiler/lower:level" %t143)
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2erefTo(ptr %v0, ptr %v1, ptr %a0, %"compiler/lower:pl" %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca i32
  %l9 = alloca i32
  %l10 = alloca ptr
  %l11 = alloca i32
  %l14 = alloca %"compiler/mir:Place"
  %l18 = alloca { i64, [4 x i64] }
  %rv = alloca { i64, [4 x i64] }
  %t20 = alloca { i64, [15 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t4, i32 %a2, i64 %t6)
  store i32 %t10, ptr %l9
  br label %bb1
bb1:
  %t11 = load i32, ptr %l9, !tbaa !23
  store i32 %t11, ptr %l4, !tbaa !23
  %t12 = load ptr, ptr %l0, !tbaa !29
  store ptr %t12, ptr %l10, !tbaa !29
  %t13 = load i32, ptr %l4, !tbaa !23
  store i32 %t13, ptr %l11, !tbaa !23
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t18 = call %"compiler/mir:Place" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %v1, ptr %t14, %"compiler/lower:pl" %a1)
  store %"compiler/mir:Place" %t18, ptr %l14
  br label %bb2
bb2:
  %t19 = load i32, ptr %l4, !tbaa !23
  store { i64, [15 x i64] } zeroinitializer, ptr %t20
  %t21 = getelementptr { i64, [15 x i64] }, ptr %t20, i32 0, i32 0
  store i64 1, ptr %t21
  %t22 = load %"compiler/mir:Place", ptr %l14
  %t23 = insertvalue { %"compiler/mir:Place", i32 } undef, %"compiler/mir:Place" %t22, 0
  %t25 = insertvalue { %"compiler/mir:Place", i32 } %t23, i32 %t19, 1
  %t26 = getelementptr { i64, [15 x i64] }, ptr %t20, i32 0, i32 1
  store { %"compiler/mir:Place", i32 } %t25, ptr %t26
  %t27 = load { i64, [15 x i64] }, ptr %t20
  %t29 = load ptr, ptr %l10, !tbaa !29
  %t30 = load i32, ptr %l11, !tbaa !23
  %t33 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t29, i32 %t30, { i64, [15 x i64] } %t27, %"compiler/source:Span" %a3)
  store { i64, [4 x i64] } %t33, ptr %l18
  br label %bb3
bb3:
  %t34 = load { i64, [4 x i64] }, ptr %l18
  store { i64, [4 x i64] } %t34, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local i64 @compiler_2flower_2ecompiler_2flower_3alowering_2eregionSite(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i64
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca i1
  %l31 = alloca ptr
  %l32 = alloca i1
  %l40 = alloca ptr
  %l41 = alloca i1
  %l49 = alloca ptr
  %l50 = alloca i1
  %l60 = alloca i1
  %l66 = alloca i1
  %l68 = alloca { i64, ptr }
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 19
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  store i64 -1, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t9 = load ptr, ptr %l1, !tbaa !29
  store ptr %t9, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t10 = load ptr, ptr %l13, !tbaa !29
  %t11 = icmp ne ptr %t10, null
  br i1 %t11, label %bb4, label %bb5
bb4:
  %t13 = load ptr, ptr %l13, !tbaa !29
  %t14 = load i64, ptr %t13
  %t16 = icmp eq i64 %t14, 5
  store i1 %t16, ptr %l14, !tbaa !21
  br label %bb5
bb5:
  %t17 = load i1, ptr %l14, !tbaa !21
  br i1 %t17, label %bb6, label %bb7
bb6:
  %t18 = load ptr, ptr %l1, !tbaa !29
  %t20 = getelementptr { i64, [5 x i64] }, ptr %t18, i32 0, i32 1
  %t21 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t20, i32 0, i32 2
  %t22 = load ptr, ptr %t21
  store ptr %t22, ptr %l2, !tbaa !29
  br label %bb8
bb7:
  br label %bb9
bb8:
  %t24 = load ptr, ptr %l2, !tbaa !29
  %t26 = getelementptr %"compiler/typed:Promote", ptr %t24, i32 0, i32 1
  %t27 = load i32, ptr %t26, !tbaa !23
  %t29 = sext i32 %t27 to i64
  store i64 %t29, ptr %l12, !tbaa !24
  br label %bb38
bb9:
  %t31 = load ptr, ptr %l1, !tbaa !29
  store ptr %t31, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t32 = load ptr, ptr %l22, !tbaa !29
  %t33 = icmp ne ptr %t32, null
  br i1 %t33, label %bb10, label %bb11
bb10:
  %t35 = load ptr, ptr %l22, !tbaa !29
  %t36 = load i64, ptr %t35
  %t38 = icmp eq i64 %t36, 7
  store i1 %t38, ptr %l23, !tbaa !21
  br label %bb11
bb11:
  %t39 = load i1, ptr %l23, !tbaa !21
  br i1 %t39, label %bb12, label %bb13
bb12:
  %t40 = load ptr, ptr %l1, !tbaa !29
  %t42 = getelementptr { i64, [5 x i64] }, ptr %t40, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t42, i32 0, i32 2
  %t44 = load ptr, ptr %t43
  store ptr %t44, ptr %l3, !tbaa !29
  br label %bb14
bb13:
  br label %bb15
bb14:
  %t46 = load ptr, ptr %l3, !tbaa !29
  %t48 = getelementptr %"compiler/typed:Make", ptr %t46, i32 0, i32 4
  %t49 = load i32, ptr %t48, !tbaa !23
  %t51 = sext i32 %t49 to i64
  store i64 %t51, ptr %l12, !tbaa !24
  br label %bb38
bb15:
  %t53 = load ptr, ptr %l1, !tbaa !29
  store ptr %t53, ptr %l31, !tbaa !29
  store i1 false, ptr %l32, !tbaa !21
  %t54 = load ptr, ptr %l31, !tbaa !29
  %t55 = icmp ne ptr %t54, null
  br i1 %t55, label %bb16, label %bb17
bb16:
  %t57 = load ptr, ptr %l31, !tbaa !29
  %t58 = load i64, ptr %t57
  %t60 = icmp eq i64 %t58, 16
  store i1 %t60, ptr %l32, !tbaa !21
  br label %bb17
bb17:
  %t61 = load i1, ptr %l32, !tbaa !21
  br i1 %t61, label %bb18, label %bb19
bb18:
  %t62 = load ptr, ptr %l1, !tbaa !29
  %t64 = getelementptr { i64, [5 x i64] }, ptr %t62, i32 0, i32 1
  %t65 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t64, i32 0, i32 2
  %t66 = load ptr, ptr %t65
  store ptr %t66, ptr %l4, !tbaa !29
  br label %bb20
bb19:
  br label %bb21
bb20:
  %t68 = load ptr, ptr %l4, !tbaa !29
  %t70 = getelementptr %"compiler/typed:Text", ptr %t68, i32 0, i32 1
  %t71 = load i32, ptr %t70, !tbaa !23
  %t73 = sext i32 %t71 to i64
  store i64 %t73, ptr %l12, !tbaa !24
  br label %bb38
bb21:
  %t75 = load ptr, ptr %l1, !tbaa !29
  store ptr %t75, ptr %l40, !tbaa !29
  store i1 false, ptr %l41, !tbaa !21
  %t76 = load ptr, ptr %l40, !tbaa !29
  %t77 = icmp ne ptr %t76, null
  br i1 %t77, label %bb22, label %bb23
bb22:
  %t79 = load ptr, ptr %l40, !tbaa !29
  %t80 = load i64, ptr %t79
  %t82 = icmp eq i64 %t80, 8
  store i1 %t82, ptr %l41, !tbaa !21
  br label %bb23
bb23:
  %t83 = load i1, ptr %l41, !tbaa !21
  br i1 %t83, label %bb24, label %bb25
bb24:
  %t84 = load ptr, ptr %l1, !tbaa !29
  %t86 = getelementptr { i64, [5 x i64] }, ptr %t84, i32 0, i32 1
  %t87 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t86, i32 0, i32 2
  %t88 = load ptr, ptr %t87
  store ptr %t88, ptr %l5, !tbaa !29
  br label %bb26
bb25:
  br label %bb27
bb26:
  %t90 = load ptr, ptr %l5, !tbaa !29
  %t92 = getelementptr %"compiler/typed:Collect", ptr %t90, i32 0, i32 2
  %t93 = load i32, ptr %t92, !tbaa !23
  %t95 = sext i32 %t93 to i64
  store i64 %t95, ptr %l12, !tbaa !24
  br label %bb38
bb27:
  %t97 = load ptr, ptr %l1, !tbaa !29
  store ptr %t97, ptr %l49, !tbaa !29
  store i1 false, ptr %l50, !tbaa !21
  %t98 = load ptr, ptr %l49, !tbaa !29
  %t99 = icmp ne ptr %t98, null
  br i1 %t99, label %bb28, label %bb29
bb28:
  %t101 = load ptr, ptr %l49, !tbaa !29
  %t102 = load i64, ptr %t101
  %t104 = icmp eq i64 %t102, 6
  store i1 %t104, ptr %l50, !tbaa !21
  br label %bb29
bb29:
  %t105 = load i1, ptr %l50, !tbaa !21
  br i1 %t105, label %bb30, label %bb31
bb30:
  %t106 = load ptr, ptr %l1, !tbaa !29
  %t108 = getelementptr { i64, [5 x i64] }, ptr %t106, i32 0, i32 1
  %t109 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t108, i32 0, i32 2
  %t110 = load ptr, ptr %t109
  store ptr %t110, ptr %l6, !tbaa !29
  br label %bb32
bb31:
  br label %bb33
bb32:
  %t112 = load ptr, ptr %l6, !tbaa !29
  %t114 = getelementptr %"compiler/typed:Call", ptr %t112, i32 0, i32 3
  %t115 = load i32, ptr %t114, !tbaa !23
  %t117 = sext i32 %t115 to i64
  store i64 %t117, ptr %l12, !tbaa !24
  br label %bb38
bb33:
  br i1 true, label %bb34, label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb37
bb36:
  store i64 -1, ptr %l12, !tbaa !24
  br label %bb38
bb37:
  call void @__olang_check_failed(ptr @olang_loc_5f06e436ba25f30_8078c3a4dcac4c4)
  unreachable
bb38:
  %t119 = load i64, ptr %l12, !tbaa !24
  store i64 %t119, ptr %l7, !tbaa !24
  %t120 = load i64, ptr %l7, !tbaa !24
  %t122 = icmp slt i64 %t120, 0
  br i1 %t122, label %bb39, label %bb40
bb39:
  store i1 true, ptr %l60, !tbaa !21
  br label %bb41
bb40:
  %t124 = load i64, ptr %l7, !tbaa !24
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t127 = getelementptr %"compiler/lower:lowering", ptr %t125, i32 0, i32 22
  %t128 = getelementptr %"compiler/typed:Plan", ptr %t127, i32 0, i32 4
  %t129 = load { i64, ptr }, ptr %t128, !tbaa !27
  %t131 = extractvalue { i64, ptr } %t129, 0
  %t134 = icmp sge i64 %t124, %t131
  store i1 %t134, ptr %l60, !tbaa !21
  br label %bb41
bb41:
  %t136 = load i1, ptr %l60, !tbaa !21
  br i1 %t136, label %bb42, label %bb43
bb42:
  store i1 true, ptr %l66, !tbaa !21
  br label %bb44
bb43:
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t139 = getelementptr %"compiler/lower:lowering", ptr %t137, i32 0, i32 22
  %t140 = getelementptr %"compiler/typed:Plan", ptr %t139, i32 0, i32 4
  %t141 = load { i64, ptr }, ptr %t140, !tbaa !27
  store { i64, ptr } %t141, ptr %l68, !tbaa !27
  %t142 = load i64, ptr %l7, !tbaa !24
  %t144 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t145 = load ptr, ptr %t144, !tbaa !27
  %t146 = getelementptr i64, ptr %t145, i64 %t142
  %t147 = load i64, ptr %t146, !tbaa !34
  %t149 = icmp eq i64 %t147, 0
  store i1 %t149, ptr %l66, !tbaa !21
  br label %bb44
bb44:
  %t151 = load i1, ptr %l66, !tbaa !21
  br i1 %t151, label %bb45, label %bb46
bb45:
  store i64 -1, ptr %rv
  br label %ret
bb46:
  br label %bb47
bb47:
  %t153 = load i64, ptr %l7, !tbaa !24
  store i64 %t153, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2erunDefers(ptr %v0, ptr %a0, i64 %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i1
  %l3 = alloca %"compiler/lower:level"
  %l4 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l5 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i64
  %l16 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca i64
  %l23 = alloca %"compiler/lower:level"
  %l24 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l27 = alloca i64
  %l32 = alloca ptr
  %l33 = alloca %"compiler/lower:level"
  %l36 = alloca %"compiler/lower:level"
  %l37 = alloca i32
  %l38 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l41 = alloca i64
  %l45 = alloca i64
  %l48 = alloca i64
  %l69 = alloca i32
  %l74 = alloca i1
  %l76 = alloca i1
  %l79 = alloca i1
  %l81 = alloca i1
  %l84 = alloca i1
  %l92 = alloca i64
  %l94 = alloca i64
  %l99 = alloca i64
  %l106 = alloca i64
  %l114 = alloca i1
  %l115 = alloca ptr
  %l118 = alloca i64
  %l119 = alloca i1
  %l121 = alloca ptr
  %l124 = alloca ptr
  %l126 = alloca ptr
  %l129 = alloca i64
  %l130 = alloca ptr
  %l134 = alloca %"compiler/typed:BlockInfo"
  %l140 = alloca ptr
  %l142 = alloca ptr
  %l145 = alloca i64
  %l146 = alloca ptr
  %l150 = alloca i64
  %l152 = alloca i64
  %l157 = alloca i64
  %l165 = alloca i64
  %l169 = alloca ptr
  %l170 = alloca %"compiler/lower:level"
  %l172 = alloca %"compiler/lower:level"
  %l173 = alloca i32
  %s0 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %t227 = alloca { i64, [21 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i1 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 9
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call %"compiler/lower:level" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e_2eAt_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %t3, i64 %t4)
  store %"compiler/lower:level" %t7, ptr %l23
  br label %bb1
bb1:
  %t8 = load %"compiler/lower:level", ptr %l23
  store %"compiler/lower:level" %t8, ptr %l3
  %t9 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t9, ptr %l24
  br label %bb2
bb2:
  %t10 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l24
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t10, ptr %l4
  br label %bb3
bb3:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/lower:lowering", ptr %t11, i32 0, i32 9
  %t15 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e_2eLen_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %t13)
  store i64 %t15, ptr %l27
  br label %bb4
bb4:
  %t16 = load i64, ptr %l1, !tbaa !24
  %t18 = add i64 %t16, 1
  %t19 = load i64, ptr %l27, !tbaa !24
  %t21 = icmp sgt i64 %t19, %t18
  %t23 = xor i1 %t21, true
  br i1 %t23, label %bb5, label %bb6
bb5:
  br label %bb14
bb6:
  br label %bb7
bb7:
  store ptr %l4, ptr %l32, !tbaa !29
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/lower:lowering", ptr %t25, i32 0, i32 9
  %t29 = call { i32, %"compiler/lower:level" } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e_2ePop_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %t27)
  %t30 = extractvalue { i32, %"compiler/lower:level" } %t29, 1
  %t31 = extractvalue { i32, %"compiler/lower:level" } %t29, 0
  store i32 %t31, ptr %l37
  %t32 = icmp ne i32 %t31, 0
  br i1 %t32, label %bb9, label %ok.33
ok.33:
  store %"compiler/lower:level" %t30, ptr %l36
  br label %bb8
bb8:
  %t34 = load %"compiler/lower:level", ptr %l36
  store %"compiler/lower:level" %t34, ptr %l33
  br label %bb11
bb9:
  br label %bb10
bb10:
  call void @__olang_ert_req_clear()
  call void @__olang_check_failed(ptr @olang_loc_3ef62952ecee62f3_777b4c56ce2caf3f)
  unreachable
bb11:
  %t35 = load ptr, ptr %l32, !tbaa !29
  %t36 = load %"compiler/lower:level", ptr %l33
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e_2ePush_3ccompiler_2flower_3alevel_3e(ptr %s0, ptr %t35, %"compiler/lower:level" %t36)
  br label %bb12
bb12:
  br label %bb13
bb13:
  br label %bb3
bb14:
  %t37 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t37, ptr %l38
  br label %bb15
bb15:
  %t38 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l38
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t38, ptr %l5
  store i64 0, ptr %l6, !tbaa !24
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/lower:lowering", ptr %t39, i32 0, i32 10
  %t43 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlock_26_3e_2eLen_3ccompiler_2ftyped_3aBlock_26_3e(ptr %v0, ptr %t41)
  store i64 %t43, ptr %l41
  br label %bb16
bb16:
  %t44 = load i64, ptr %l41, !tbaa !24
  store i64 %t44, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t45 = load i64, ptr %l7, !tbaa !24
  %t46 = load i64, ptr %l6, !tbaa !24
  %t49 = icmp sgt i64 %t45, %t46
  br i1 %t49, label %bb17, label %bb18
bb17:
  %t51 = load i64, ptr %l8, !tbaa !24
  %t53 = icmp sgt i64 %t51, 0
  br i1 %t53, label %bb19, label %bb20
bb18:
  store i64 0, ptr %l45, !tbaa !24
  br label %bb22
bb19:
  %t55 = load i64, ptr %l7, !tbaa !24
  %t56 = load i64, ptr %l6, !tbaa !24
  %t59 = sub i64 %t55, %t56
  %t60 = load i64, ptr %l8, !tbaa !24
  %t63 = add i64 %t59, %t60
  %t65 = sub i64 %t63, 1
  %t66 = load i64, ptr %l8, !tbaa !24
  %t69 = sdiv i64 %t65, %t66
  store i64 %t69, ptr %l48, !tbaa !24
  br label %bb21
bb20:
  store i64 0, ptr %l48, !tbaa !24
  br label %bb21
bb21:
  %t71 = load i64, ptr %l48, !tbaa !24
  store i64 %t71, ptr %l45, !tbaa !24
  br label %bb22
bb22:
  %t72 = load i64, ptr %l45, !tbaa !24
  store i64 %t72, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb23
bb23:
  %t73 = load i64, ptr %l10, !tbaa !24
  %t74 = load i64, ptr %l9, !tbaa !24
  %t77 = icmp slt i64 %t73, %t74
  %t79 = xor i1 %t77, true
  br i1 %t79, label %bb24, label %bb25
bb24:
  br label %bb49
bb25:
  br label %bb26
bb26:
  %t81 = load i64, ptr %l6, !tbaa !24
  %t82 = load i64, ptr %l10, !tbaa !24
  %t83 = load i64, ptr %l8, !tbaa !24
  %t86 = mul i64 %t82, %t83
  %t89 = add i64 %t81, %t86
  store i64 %t89, ptr %l11, !tbaa !24
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"compiler/lower:lowering", ptr %t91, i32 0, i32 11
  %t94 = load i64, ptr %l11, !tbaa !24
  %t97 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eAt_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t93, i64 %t94)
  store i32 %t97, ptr %l69
  br label %bb27
bb27:
  %t98 = getelementptr %"compiler/lower:level", ptr %l3, i32 0, i32 0
  %t99 = load i32, ptr %t98, !tbaa !23
  %t100 = load i32, ptr %l69, !tbaa !23
  %t102 = icmp ne i32 %t100, %t99
  br i1 %t102, label %bb28, label %bb29
bb28:
  br label %bb48
bb29:
  br label %bb30
bb30:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t105 = load i64, ptr %l11, !tbaa !24
  %t108 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eonError(ptr %v0, ptr %t104, i64 %t105)
  store i1 %t108, ptr %l74
  br label %bb31
bb31:
  %t109 = load i1, ptr %l74, !tbaa !21
  store i1 %t109, ptr %l12, !tbaa !21
  %t110 = load i1, ptr %l12, !tbaa !21
  br i1 %t110, label %bb32, label %bb33
bb32:
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t114 = getelementptr %"compiler/lower:lowering", ptr %t112, i32 0, i32 18
  %t115 = load i1, ptr %t114, !tbaa !21
  br i1 %t115, label %bb34, label %bb35
bb33:
  store i1 false, ptr %l76, !tbaa !21
  br label %bb37
bb34:
  store i1 true, ptr %l79, !tbaa !21
  br label %bb36
bb35:
  %t117 = load i1, ptr %l2, !tbaa !21
  store i1 %t117, ptr %l79, !tbaa !21
  br label %bb36
bb36:
  %t119 = load i1, ptr %l79, !tbaa !21
  store i1 %t119, ptr %l76, !tbaa !21
  br label %bb37
bb37:
  %t120 = load i1, ptr %l76, !tbaa !21
  br i1 %t120, label %bb38, label %bb39
bb38:
  store i1 true, ptr %l81, !tbaa !21
  br label %bb43
bb39:
  %t121 = load i1, ptr %l12, !tbaa !21
  %t123 = xor i1 %t121, true
  br i1 %t123, label %bb40, label %bb41
bb40:
  %t125 = load i1, ptr %l2, !tbaa !21
  %t127 = xor i1 %t125, true
  store i1 %t127, ptr %l84, !tbaa !21
  br label %bb42
bb41:
  store i1 false, ptr %l84, !tbaa !21
  br label %bb42
bb42:
  %t129 = load i1, ptr %l84, !tbaa !21
  store i1 %t129, ptr %l81, !tbaa !21
  br label %bb43
bb43:
  %t130 = load i1, ptr %l81, !tbaa !21
  br i1 %t130, label %bb44, label %bb45
bb44:
  %t131 = load i64, ptr %l11, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l5, i64 %t131)
  br label %bb46
bb45:
  br label %bb47
bb46:
  br label %bb47
bb47:
  br label %bb48
bb48:
  %t134 = load i64, ptr %l10, !tbaa !24
  %t136 = add i64 %t134, 1
  store i64 %t136, ptr %l10, !tbaa !24
  br label %bb23
bb49:
  store ptr %l5, ptr %l13, !tbaa !29
  store i64 0, ptr %l14, !tbaa !24
  br label %bb50
bb50:
  %t139 = load i64, ptr %l14, !tbaa !24
  store i64 %t139, ptr %l92, !tbaa !24
  %t140 = load ptr, ptr %l13, !tbaa !29
  %t142 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t140)
  store i64 %t142, ptr %l94
  br label %bb51
bb51:
  %t143 = load i64, ptr %l92, !tbaa !24
  %t144 = load i64, ptr %l94, !tbaa !24
  %t145 = icmp slt i64 %t143, %t144
  %t147 = xor i1 %t145, true
  br i1 %t147, label %bb52, label %bb53
bb52:
  br label %bb58
bb53:
  br label %bb54
bb54:
  %t149 = load ptr, ptr %l13, !tbaa !29
  %t150 = load i64, ptr %l14, !tbaa !24
  %t153 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t149, i64 %t150)
  store i64 %t153, ptr %l99
  br label %bb55
bb55:
  %t154 = load i64, ptr %l99, !tbaa !24
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t157 = getelementptr %"compiler/lower:lowering", ptr %t155, i32 0, i32 11
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eSetAt_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t157, i64 %t154, i32 -1)
  br label %bb56
bb56:
  br label %bb57
bb57:
  %t161 = load i64, ptr %l14, !tbaa !24
  %t163 = add i64 %t161, 1
  store i64 %t163, ptr %l14, !tbaa !24
  br label %bb50
bb58:
  %t166 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l5)
  store i64 %t166, ptr %l106
  br label %bb59
bb59:
  %t167 = load i64, ptr %l106, !tbaa !24
  %t168 = sub i64 %t167, 1
  store i64 %t168, ptr %l16, !tbaa !24
  br label %bb60
bb60:
  %t170 = load i64, ptr %l16, !tbaa !24
  %t172 = icmp sge i64 %t170, 0
  %t174 = xor i1 %t172, true
  br i1 %t174, label %bb61, label %bb62
bb61:
  br label %bb80
bb62:
  br label %bb63
bb63:
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t178 = getelementptr %"compiler/lower:lowering", ptr %t176, i32 0, i32 0
  %t179 = load ptr, ptr %t178, !tbaa !29
  %t181 = getelementptr %"compiler/lower:Lowerer", ptr %t179, i32 0, i32 6
  %t182 = load i1, ptr %t181, !tbaa !21
  br i1 %t182, label %bb64, label %bb65
bb64:
  %t184 = load ptr, ptr %l0, !tbaa !29
  store ptr %t184, ptr %l115, !tbaa !29
  %t185 = load i64, ptr %l16, !tbaa !24
  %t188 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l5, i64 %t185)
  store i64 %t188, ptr %l118
  br label %bb66
bb65:
  store i1 false, ptr %l114, !tbaa !21
  br label %bb68
bb66:
  %t189 = load ptr, ptr %l115, !tbaa !29
  %t190 = load i64, ptr %l118, !tbaa !24
  %t191 = call i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eonError(ptr %v0, ptr %t189, i64 %t190)
  store i1 %t191, ptr %l119
  br label %bb67
bb67:
  %t192 = load i1, ptr %l119, !tbaa !21
  %t193 = xor i1 %t192, true
  store i1 %t193, ptr %l114, !tbaa !21
  br label %bb68
bb68:
  %t195 = load i1, ptr %l114, !tbaa !21
  br i1 %t195, label %bb69, label %bb70
bb69:
  store %olang.scope zeroinitializer, ptr %s13
  %t196 = load ptr, ptr %l0, !tbaa !29
  store ptr %t196, ptr %l121, !tbaa !29
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t199 = getelementptr %"compiler/lower:lowering", ptr %t197, i32 0, i32 1
  %t200 = load ptr, ptr %t199, !tbaa !29
  %t202 = getelementptr %"compiler/typed:Body", ptr %t200, i32 0, i32 8
  store ptr %t202, ptr %l124, !tbaa !29
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t205 = getelementptr %"compiler/lower:lowering", ptr %t203, i32 0, i32 10
  store ptr %t205, ptr %l126, !tbaa !29
  %t206 = load i64, ptr %l16, !tbaa !24
  %t209 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l5, i64 %t206)
  store i64 %t209, ptr %l129
  br label %bb71
bb70:
  br label %bb75
bb71:
  %t210 = load ptr, ptr %l126, !tbaa !29
  %t211 = load i64, ptr %l129, !tbaa !24
  %t212 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlock_26_3e_2eAt_3ccompiler_2ftyped_3aBlock_26_3e(ptr %v0, ptr %s13, ptr %t210, i64 %t211)
  store ptr %t212, ptr %l130
  br label %bb72
bb72:
  %t213 = load ptr, ptr %l130, !tbaa !29
  %t215 = getelementptr %"compiler/typed:Block", ptr %t213, i32 0, i32 0
  %t216 = load i32, ptr %t215, !tbaa !23
  %t218 = sext i32 %t216 to i64
  %t219 = load ptr, ptr %l124, !tbaa !29
  %t221 = call %"compiler/typed:BlockInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockInfo_3e_2eAt_3ccompiler_2ftyped_3aBlockInfo_3e(ptr %v0, ptr %t219, i64 %t218)
  store %"compiler/typed:BlockInfo" %t221, ptr %l134
  br label %bb73
bb73:
  %t222 = getelementptr %"compiler/typed:BlockInfo", ptr %l134, i32 0, i32 2
  %t223 = load %"compiler/source:Span", ptr %t222
  %t224 = getelementptr %"compiler/lower:level", ptr %l3, i32 0, i32 0
  %t225 = load i32, ptr %t224, !tbaa !23
  %t226 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  store { i64, [21 x i64] } zeroinitializer, ptr %t227
  %t228 = getelementptr { i64, [21 x i64] }, ptr %t227, i32 0, i32 0
  store i64 13, ptr %t228
  %t230 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t223, 0
  %t232 = insertvalue { %"compiler/source:Span", i32, i32 } %t230, i32 %t225, 1
  %t234 = insertvalue { %"compiler/source:Span", i32, i32 } %t232, i32 %t226, 2
  %t235 = getelementptr { i64, [21 x i64] }, ptr %t227, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t234, ptr %t235
  %t236 = load { i64, [21 x i64] }, ptr %t227
  %t238 = call ptr @__olang_scope_alloc_a(ptr %s13, i64 176, i64 8)
  store { i64, [21 x i64] } %t236, ptr %t238
  %t239 = load ptr, ptr %l121, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s13, ptr %t239, ptr %t238)
  br label %bb74
bb74:
  call void @__olang_scope_close(ptr %s13)
  br label %bb75
bb75:
  %t241 = load ptr, ptr %l0, !tbaa !29
  store ptr %t241, ptr %l140, !tbaa !29
  %t242 = load ptr, ptr %l0, !tbaa !29
  %t244 = getelementptr %"compiler/lower:lowering", ptr %t242, i32 0, i32 10
  store ptr %t244, ptr %l142, !tbaa !29
  %t245 = load i64, ptr %l16, !tbaa !24
  %t248 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l5, i64 %t245)
  store i64 %t248, ptr %l145
  br label %bb76
bb76:
  %t249 = load ptr, ptr %l142, !tbaa !29
  %t250 = load i64, ptr %l145, !tbaa !24
  %t251 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlock_26_3e_2eAt_3ccompiler_2ftyped_3aBlock_26_3e(ptr %v0, ptr %v0, ptr %t249, i64 %t250)
  store ptr %t251, ptr %l146
  br label %bb77
bb77:
  %t252 = load ptr, ptr %l140, !tbaa !29
  %t253 = load ptr, ptr %l146, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eblock(ptr %v0, ptr %v0, ptr %t252, ptr %t253)
  br label %bb78
bb78:
  br label %bb79
bb79:
  %t254 = load i64, ptr %l16, !tbaa !24
  %t256 = sub i64 %t254, 1
  store i64 %t256, ptr %l16, !tbaa !24
  br label %bb60
bb80:
  store ptr %l5, ptr %l17, !tbaa !29
  store i64 0, ptr %l18, !tbaa !24
  br label %bb81
bb81:
  %t259 = load i64, ptr %l18, !tbaa !24
  store i64 %t259, ptr %l150, !tbaa !24
  %t260 = load ptr, ptr %l17, !tbaa !29
  %t262 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t260)
  store i64 %t262, ptr %l152
  br label %bb82
bb82:
  %t263 = load i64, ptr %l150, !tbaa !24
  %t264 = load i64, ptr %l152, !tbaa !24
  %t265 = icmp slt i64 %t263, %t264
  %t267 = xor i1 %t265, true
  br i1 %t267, label %bb83, label %bb84
bb83:
  br label %bb89
bb84:
  br label %bb85
bb85:
  %t269 = load ptr, ptr %l17, !tbaa !29
  %t270 = load i64, ptr %l18, !tbaa !24
  %t273 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t269, i64 %t270)
  store i64 %t273, ptr %l157
  br label %bb86
bb86:
  %t274 = load i64, ptr %l157, !tbaa !24
  %t275 = load ptr, ptr %l0, !tbaa !29
  %t277 = getelementptr %"compiler/lower:lowering", ptr %t275, i32 0, i32 11
  %t279 = getelementptr %"compiler/lower:level", ptr %l3, i32 0, i32 0
  %t280 = load i32, ptr %t279, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eSetAt_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %t277, i64 %t274, i32 %t280)
  br label %bb87
bb87:
  br label %bb88
bb88:
  %t284 = load i64, ptr %l18, !tbaa !24
  %t286 = add i64 %t284, 1
  store i64 %t286, ptr %l18, !tbaa !24
  br label %bb81
bb89:
  br label %bb90
bb90:
  %t289 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e_2eLen_3ccompiler_2flower_3alevel_3e(ptr %s0, ptr %l4)
  store i64 %t289, ptr %l165
  br label %bb91
bb91:
  %t290 = load i64, ptr %l165, !tbaa !24
  %t291 = icmp sgt i64 %t290, 0
  %t293 = xor i1 %t291, true
  br i1 %t293, label %bb92, label %bb93
bb92:
  br label %bb101
bb93:
  br label %bb94
bb94:
  %t295 = load ptr, ptr %l0, !tbaa !29
  %t297 = getelementptr %"compiler/lower:lowering", ptr %t295, i32 0, i32 9
  store ptr %t297, ptr %l169, !tbaa !29
  %t299 = call { i32, %"compiler/lower:level" } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e_2ePop_3ccompiler_2flower_3alevel_3e(ptr %s0, ptr %l4)
  %t300 = extractvalue { i32, %"compiler/lower:level" } %t299, 1
  %t301 = extractvalue { i32, %"compiler/lower:level" } %t299, 0
  store i32 %t301, ptr %l173
  %t302 = icmp ne i32 %t301, 0
  br i1 %t302, label %bb96, label %ok.303
ok.303:
  store %"compiler/lower:level" %t300, ptr %l172
  br label %bb95
bb95:
  %t304 = load %"compiler/lower:level", ptr %l172
  store %"compiler/lower:level" %t304, ptr %l170
  br label %bb98
bb96:
  br label %bb97
bb97:
  call void @__olang_ert_req_clear()
  call void @__olang_check_failed(ptr @olang_loc_de8dc91cd31c6e72_d86f27d9b5b5bc3e)
  unreachable
bb98:
  %t305 = load ptr, ptr %l169, !tbaa !29
  %t306 = load %"compiler/lower:level", ptr %l170
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e_2ePush_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %t305, %"compiler/lower:level" %t306)
  br label %bb99
bb99:
  br label %bb100
bb100:
  br label %bb90
bb101:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2flower_2ecompiler_2flower_3alowering_2escalar(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l6 = alloca i32
  %l10 = alloca i1
  %l14 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t8 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t4, i32 %a1)
  store i32 %t8, ptr %l6
  br label %bb1
bb1:
  %t9 = load i32, ptr %l6, !tbaa !23
  store i32 %t9, ptr %l2, !tbaa !23
  %t10 = load i32, ptr %l2, !tbaa !23
  %t11 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t14 = icmp eq i32 %t10, %t11
  br i1 %t14, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb5
bb3:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/lower:lowering", ptr %t16, i32 0, i32 2
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t20 = load i32, ptr %l2, !tbaa !23
  %t23 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNumber(ptr %v0, ptr %t19, i32 %t20)
  store i1 %t23, ptr %l14
  br label %bb4
bb4:
  %t24 = load i1, ptr %l14, !tbaa !21
  store i1 %t24, ptr %l10, !tbaa !21
  br label %bb5
bb5:
  %t25 = load i1, ptr %l10, !tbaa !21
  store i1 %t25, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2escopeRef(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [1 x i64] }
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca i32
  %l13 = alloca i64
  %l21 = alloca %"compiler/lower:level"
  %l28 = alloca %"compiler/lower:level"
  %l35 = alloca i64
  %l43 = alloca %"compiler/lower:level"
  %l47 = alloca i1
  %l52 = alloca i1
  %l56 = alloca %"compiler/lower:level"
  %l76 = alloca { i64, [1 x i64] }
  %rv = alloca { i64, [1 x i64] }
  %t47 = alloca { i64, [1 x i64] }, align 8
  %t107 = alloca { i64, [1 x i64] }, align 8
  %t118 = alloca { i64, [1 x i64] }, align 8
  %t132 = alloca { i64, [1 x i64] }, align 8
  %t144 = alloca { i64, [1 x i64] }, align 8
  %t165 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store { i64, [1 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [1 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [1 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 1
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [1 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { i32 }, ptr %t6, i32 0, i32 0
  %t8 = load i32, ptr %t7
  store i32 %t8, ptr %l2, !tbaa !23
  br label %bb3
bb2:
  br label %bb32
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/lower:lowering", ptr %t10, i32 0, i32 9
  %t14 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e_2eLen_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %t12)
  store i64 %t14, ptr %l13
  br label %bb4
bb4:
  %t15 = load i64, ptr %l13, !tbaa !24
  %t16 = sub i64 %t15, 1
  store i64 %t16, ptr %l3, !tbaa !24
  br label %bb5
bb5:
  %t18 = load i64, ptr %l3, !tbaa !24
  %t20 = icmp sge i64 %t18, 0
  %t22 = xor i1 %t20, true
  br i1 %t22, label %bb6, label %bb7
bb6:
  br label %bb15
bb7:
  br label %bb8
bb8:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/lower:lowering", ptr %t24, i32 0, i32 9
  %t27 = load i64, ptr %l3, !tbaa !24
  %t30 = call %"compiler/lower:level" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e_2eAt_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %t26, i64 %t27)
  store %"compiler/lower:level" %t30, ptr %l21
  br label %bb9
bb9:
  %t31 = getelementptr %"compiler/lower:level", ptr %l21, i32 0, i32 1
  %t32 = load i32, ptr %t31, !tbaa !23
  %t33 = load i32, ptr %l2, !tbaa !23
  %t36 = icmp eq i32 %t32, %t33
  br i1 %t36, label %bb10, label %bb11
bb10:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/lower:lowering", ptr %t38, i32 0, i32 9
  %t41 = load i64, ptr %l3, !tbaa !24
  %t44 = call %"compiler/lower:level" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e_2eAt_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %t40, i64 %t41)
  store %"compiler/lower:level" %t44, ptr %l28
  br label %bb12
bb11:
  br label %bb13
bb12:
  %t45 = getelementptr %"compiler/lower:level", ptr %l28, i32 0, i32 0
  %t46 = load i32, ptr %t45, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t47
  %t48 = getelementptr { i64, [1 x i64] }, ptr %t47, i32 0, i32 0
  store i64 0, ptr %t48
  %t50 = insertvalue { i32 } undef, i32 %t46, 0
  %t51 = getelementptr { i64, [1 x i64] }, ptr %t47, i32 0, i32 1
  store { i32 } %t50, ptr %t51
  %t52 = load { i64, [1 x i64] }, ptr %t47
  store { i64, [1 x i64] } %t52, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t54 = load i64, ptr %l3, !tbaa !24
  %t56 = sub i64 %t54, 1
  store i64 %t56, ptr %l3, !tbaa !24
  br label %bb5
bb15:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/lower:lowering", ptr %t58, i32 0, i32 9
  %t62 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e_2eLen_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %t60)
  store i64 %t62, ptr %l35
  br label %bb16
bb16:
  %t63 = load i64, ptr %l35, !tbaa !24
  %t64 = sub i64 %t63, 1
  store i64 %t64, ptr %l4, !tbaa !24
  br label %bb17
bb17:
  %t66 = load i64, ptr %l4, !tbaa !24
  %t68 = icmp sge i64 %t66, 0
  %t70 = xor i1 %t68, true
  br i1 %t70, label %bb18, label %bb19
bb18:
  br label %bb31
bb19:
  br label %bb20
bb20:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr %"compiler/lower:lowering", ptr %t72, i32 0, i32 9
  %t75 = load i64, ptr %l4, !tbaa !24
  %t78 = call %"compiler/lower:level" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e_2eAt_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %t74, i64 %t75)
  store %"compiler/lower:level" %t78, ptr %l43
  br label %bb21
bb21:
  %t79 = getelementptr %"compiler/lower:level", ptr %l43, i32 0, i32 1
  %t80 = load i32, ptr %t79, !tbaa !23
  store i32 %t80, ptr %l5, !tbaa !23
  %t82 = load i32, ptr %l5, !tbaa !23
  %t84 = icmp sge i32 %t82, 0
  br i1 %t84, label %bb22, label %bb23
bb22:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/lower:lowering", ptr %t86, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !29
  %t90 = load i32, ptr %l5, !tbaa !23
  %t91 = load i32, ptr %l2, !tbaa !23
  %t95 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eEncloses(ptr %v0, ptr %t89, i32 %t90, i32 %t91)
  store i1 %t95, ptr %l52
  br label %bb24
bb23:
  store i1 false, ptr %l47, !tbaa !21
  br label %bb25
bb24:
  %t96 = load i1, ptr %l52, !tbaa !21
  store i1 %t96, ptr %l47, !tbaa !21
  br label %bb25
bb25:
  %t97 = load i1, ptr %l47, !tbaa !21
  br i1 %t97, label %bb26, label %bb27
bb26:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/lower:lowering", ptr %t98, i32 0, i32 9
  %t101 = load i64, ptr %l4, !tbaa !24
  %t104 = call %"compiler/lower:level" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e_2eAt_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %t100, i64 %t101)
  store %"compiler/lower:level" %t104, ptr %l56
  br label %bb28
bb27:
  br label %bb29
bb28:
  %t105 = getelementptr %"compiler/lower:level", ptr %l56, i32 0, i32 0
  %t106 = load i32, ptr %t105, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t107
  %t108 = getelementptr { i64, [1 x i64] }, ptr %t107, i32 0, i32 0
  store i64 0, ptr %t108
  %t110 = insertvalue { i32 } undef, i32 %t106, 0
  %t111 = getelementptr { i64, [1 x i64] }, ptr %t107, i32 0, i32 1
  store { i32 } %t110, ptr %t111
  %t112 = load { i64, [1 x i64] }, ptr %t107
  store { i64, [1 x i64] } %t112, ptr %rv
  br label %ret
bb29:
  br label %bb30
bb30:
  %t114 = load i64, ptr %l4, !tbaa !24
  %t116 = sub i64 %t114, 1
  store i64 %t116, ptr %l4, !tbaa !24
  br label %bb17
bb31:
  store { i64, [1 x i64] } zeroinitializer, ptr %t118
  %t119 = getelementptr { i64, [1 x i64] }, ptr %t118, i32 0, i32 0
  store i64 2, ptr %t119
  %t120 = load { i64, [1 x i64] }, ptr %t118
  store { i64, [1 x i64] } %t120, ptr %rv
  br label %ret
bb32:
  %t122 = load { i64, [1 x i64] }, ptr %l1
  %t124 = extractvalue { i64, [1 x i64] } %t122, 0
  %t125 = icmp eq i64 %t124, 2
  br i1 %t125, label %bb33, label %bb34
bb33:
  %t127 = getelementptr { i64, [1 x i64] }, ptr %l1, i32 0, i32 1
  %t128 = getelementptr { i64 }, ptr %t127, i32 0, i32 0
  %t129 = load i64, ptr %t128
  store i64 %t129, ptr %l6, !tbaa !24
  br label %bb35
bb34:
  br label %bb36
bb35:
  %t131 = load i64, ptr %l6, !tbaa !24
  store { i64, [1 x i64] } zeroinitializer, ptr %t132
  %t133 = getelementptr { i64, [1 x i64] }, ptr %t132, i32 0, i32 0
  store i64 1, ptr %t133
  %t135 = insertvalue { i64 } undef, i64 %t131, 0
  %t136 = getelementptr { i64, [1 x i64] }, ptr %t132, i32 0, i32 1
  store { i64 } %t135, ptr %t136
  %t137 = load { i64, [1 x i64] }, ptr %t132
  store { i64, [1 x i64] } %t137, ptr %rv
  br label %ret
bb36:
  %t139 = load { i64, [1 x i64] }, ptr %l1
  %t141 = extractvalue { i64, [1 x i64] } %t139, 0
  %t142 = icmp eq i64 %t141, 5
  br i1 %t142, label %bb37, label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb40
bb39:
  store { i64, [1 x i64] } zeroinitializer, ptr %t144
  %t145 = getelementptr { i64, [1 x i64] }, ptr %t144, i32 0, i32 0
  store i64 3, ptr %t145
  %t146 = load { i64, [1 x i64] }, ptr %t144
  store { i64, [1 x i64] } %t146, ptr %rv
  br label %ret
bb40:
  %t148 = load { i64, [1 x i64] }, ptr %l1
  %t150 = extractvalue { i64, [1 x i64] } %t148, 0
  %t151 = icmp eq i64 %t150, 4
  br i1 %t151, label %bb41, label %bb42
bb41:
  %t153 = getelementptr { i64, [1 x i64] }, ptr %l1, i32 0, i32 1
  %t154 = getelementptr { i32 }, ptr %t153, i32 0, i32 0
  %t155 = load i32, ptr %t154
  store i32 %t155, ptr %l7, !tbaa !23
  br label %bb43
bb42:
  br label %bb45
bb43:
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t158 = load i32, ptr %l7, !tbaa !23
  %t160 = sext i32 %t158 to i64
  %t163 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eregionOf(ptr %v0, ptr %t157, i64 %t160)
  store { i64, [1 x i64] } %t163, ptr %l76
  br label %bb44
bb44:
  %t164 = load { i64, [1 x i64] }, ptr %l76
  store { i64, [1 x i64] } %t164, ptr %rv
  br label %ret
bb45:
  br i1 true, label %bb46, label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb49
bb48:
  store { i64, [1 x i64] } zeroinitializer, ptr %t165
  %t166 = getelementptr { i64, [1 x i64] }, ptr %t165, i32 0, i32 0
  store i64 2, ptr %t166
  %t167 = load { i64, [1 x i64] }, ptr %t165
  store { i64, [1 x i64] } %t167, ptr %rv
  br label %ret
bb49:
  call void @__olang_check_failed(ptr @olang_loc_a3e3ce1f266a1e3a_904ea2ee4ca5797e)
  unreachable
ret:
  %rr = load { i64, [1 x i64] }, ptr %rv
  ret { i64, [1 x i64] } %rr
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eslice(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca %"compiler/lower:pl"
  %l5 = alloca { i64, [4 x i64] }
  %l6 = alloca { i64, [4 x i64] }
  %l7 = alloca { i64, [4 x i64] }
  %l8 = alloca { i64, [4 x i64] }
  %l9 = alloca { i64, [4 x i64] }
  %l17 = alloca %"compiler/lower:pl"
  %l22 = alloca { i64, [4 x i64] }
  %l27 = alloca { i64, [4 x i64] }
  %l31 = alloca ptr
  %l32 = alloca { i64, [4 x i64] }
  %l35 = alloca i32
  %l37 = alloca { i64, [4 x i64] }
  %l38 = alloca ptr
  %l39 = alloca { i64, [4 x i64] }
  %l42 = alloca i32
  %l44 = alloca { i64, [4 x i64] }
  %l49 = alloca ptr
  %l50 = alloca i32
  %l51 = alloca i32
  %l54 = alloca %"compiler/mir:Place"
  %l56 = alloca { i64, ptr }
  %l58 = alloca { i64, [4 x i64] }
  %l59 = alloca ptr
  %l60 = alloca i32
  %l61 = alloca i32
  %l62 = alloca { i64, [4 x i64] }
  %l64 = alloca { i64, [4 x i64] }
  %l65 = alloca { i64, ptr }
  %l67 = alloca { i64, [4 x i64] }
  %l80 = alloca { i64, ptr }
  %l82 = alloca { i64, [4 x i64] }
  %l95 = alloca { i64, ptr }
  %l97 = alloca { i64, [4 x i64] }
  %l105 = alloca ptr
  %l106 = alloca i32
  %l109 = alloca %"compiler/mir:Place"
  %l115 = alloca { i64, [4 x i64] }
  %s2 = alloca %olang.scope
  %rv = alloca { i64, [4 x i64] }
  %t36 = alloca { i64, [4 x i64] }, align 8
  %t87 = alloca { i64, [4 x i64] }, align 8
  %t235 = alloca { i64, [15 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t4 = getelementptr %"compiler/typed:Slice", ptr %t2, i32 0, i32 0
  %t5 = load ptr, ptr %t4, !tbaa !29
  %t9 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2eplace(ptr %v0, ptr %v1, ptr %v0, ptr %t1, ptr %t5)
  store %"compiler/lower:pl" %t9, ptr %l17
  br label %bb1
bb1:
  %t10 = load %"compiler/lower:pl", ptr %l17
  store %"compiler/lower:pl" %t10, ptr %l4
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load ptr, ptr %l1, !tbaa !29
  %t14 = getelementptr %"compiler/typed:Slice", ptr %t12, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t19 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %t11, ptr %t15)
  store { i64, [4 x i64] } %t19, ptr %l22
  br label %bb2
bb2:
  %t20 = load { i64, [4 x i64] }, ptr %l22
  store { i64, [4 x i64] } %t20, ptr %l5
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr %"compiler/typed:Slice", ptr %t22, i32 0, i32 2
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t29 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %t21, ptr %t25)
  store { i64, [4 x i64] } %t29, ptr %l27
  br label %bb3
bb3:
  %t30 = load { i64, [4 x i64] }, ptr %l27
  store { i64, [4 x i64] } %t30, ptr %l6
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/lower:lowering", ptr %t31, i32 0, i32 7
  %t34 = load i1, ptr %t33, !tbaa !21
  br i1 %t34, label %bb4, label %bb5
bb4:
  store { i64, [4 x i64] } zeroinitializer, ptr %t36
  %t37 = getelementptr { i64, [4 x i64] }, ptr %t36, i32 0, i32 0
  store i64 0, ptr %t37
  %t38 = load { i64, [4 x i64] }, ptr %t36
  store { i64, [4 x i64] } %t38, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t40 = load ptr, ptr %l0, !tbaa !29
  store ptr %t40, ptr %l31, !tbaa !29
  %t41 = load { i64, [4 x i64] }, ptr %l5
  store { i64, [4 x i64] } %t41, ptr %l32
  %t42 = load ptr, ptr %l1, !tbaa !29
  %t44 = getelementptr %"compiler/typed:Slice", ptr %t42, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !29
  %t47 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t45)
  store i32 %t47, ptr %l35
  br label %bb7
bb7:
  %t48 = load %"compiler/source:Span", ptr %l3
  %t49 = load ptr, ptr %l31, !tbaa !29
  %t50 = load { i64, [4 x i64] }, ptr %l32
  %t51 = load i32, ptr %l35, !tbaa !23
  %t53 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2easI64(ptr %v0, ptr %t49, { i64, [4 x i64] } %t50, i32 %t51, %"compiler/source:Span" %t48)
  store { i64, [4 x i64] } %t53, ptr %l37
  br label %bb8
bb8:
  %t54 = load { i64, [4 x i64] }, ptr %l37
  store { i64, [4 x i64] } %t54, ptr %l7
  %t55 = load ptr, ptr %l0, !tbaa !29
  store ptr %t55, ptr %l38, !tbaa !29
  %t56 = load { i64, [4 x i64] }, ptr %l6
  store { i64, [4 x i64] } %t56, ptr %l39
  %t57 = load ptr, ptr %l1, !tbaa !29
  %t59 = getelementptr %"compiler/typed:Slice", ptr %t57, i32 0, i32 2
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t62 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t60)
  store i32 %t62, ptr %l42
  br label %bb9
bb9:
  %t63 = load %"compiler/source:Span", ptr %l3
  %t64 = load ptr, ptr %l38, !tbaa !29
  %t65 = load { i64, [4 x i64] }, ptr %l39
  %t66 = load i32, ptr %l42, !tbaa !23
  %t68 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2easI64(ptr %v0, ptr %t64, { i64, [4 x i64] } %t65, i32 %t66, %"compiler/source:Span" %t63)
  store { i64, [4 x i64] } %t68, ptr %l44
  br label %bb10
bb10:
  %t69 = load { i64, [4 x i64] }, ptr %l44
  store { i64, [4 x i64] } %t69, ptr %l8
  %t70 = load ptr, ptr %l1, !tbaa !29
  %t72 = getelementptr %"compiler/typed:Slice", ptr %t70, i32 0, i32 3
  %t73 = load i32, ptr %t72
  %t75 = trunc i64 0 to i32
  %t76 = icmp eq i32 %t73, %t75
  %t78 = xor i1 %t76, true
  br i1 %t78, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s2
  %t80 = load ptr, ptr %l0, !tbaa !29
  store ptr %t80, ptr %l49, !tbaa !29
  store i32 22, ptr %l50
  %t81 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  store i32 %t81, ptr %l51, !tbaa !23
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t83 = load %"compiler/lower:pl", ptr %l4
  %t86 = call %"compiler/mir:Place" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %v0, ptr %t82, %"compiler/lower:pl" %t83)
  store %"compiler/mir:Place" %t86, ptr %l54
  br label %bb13
bb12:
  br label %bb22
bb13:
  store { i64, [4 x i64] } zeroinitializer, ptr %t87
  %t88 = getelementptr { i64, [4 x i64] }, ptr %t87, i32 0, i32 0
  store i64 1, ptr %t88
  %t89 = load %"compiler/mir:Place", ptr %l54
  %t90 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t89, 0
  %t91 = getelementptr { i64, [4 x i64] }, ptr %t87, i32 0, i32 1
  store { %"compiler/mir:Place" } %t90, ptr %t91
  %t92 = load { i64, [4 x i64] }, ptr %t87
  %t93 = mul i64 1, 40
  %t94 = call ptr @__olang_scope_alloc_zeroed(ptr %s2, i64 %t93)
  %t95 = insertvalue { i64, ptr } undef, i64 1, 0
  %t96 = insertvalue { i64, ptr } %t95, ptr %t94, 1
  store { i64, ptr } %t96, ptr %l56, !tbaa !27
  %t98 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !27
  %t100 = getelementptr { i64, [4 x i64] }, ptr %t99, i64 0
  store { i64, [4 x i64] } %t92, ptr %t100
  %t101 = load %"compiler/source:Span", ptr %l3
  %t102 = load ptr, ptr %l49, !tbaa !29
  %t103 = load i32, ptr %l50
  %t104 = load i32, ptr %l51, !tbaa !23
  %t105 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t107 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s2, ptr %t102, i32 %t103, i32 %t104, { i64, ptr } %t105, %"compiler/source:Span" %t101)
  store { i64, [4 x i64] } %t107, ptr %l58
  br label %bb14
bb14:
  %t108 = load { i64, [4 x i64] }, ptr %l58
  store { i64, [4 x i64] } %t108, ptr %l9
  %t109 = load ptr, ptr %l0, !tbaa !29
  store ptr %t109, ptr %l59, !tbaa !29
  store i32 18, ptr %l60
  %t110 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t110, ptr %l61, !tbaa !23
  %t111 = load { i64, [4 x i64] }, ptr %l7
  store { i64, [4 x i64] } %t111, ptr %l62
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t114 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2econstI64(ptr %v0, ptr %t112, i64 0)
  store { i64, [4 x i64] } %t114, ptr %l64
  br label %bb15
bb15:
  %t115 = mul i64 2, 40
  %t116 = call ptr @__olang_scope_alloc_zeroed(ptr %s2, i64 %t115)
  %t117 = insertvalue { i64, ptr } undef, i64 2, 0
  %t118 = insertvalue { i64, ptr } %t117, ptr %t116, 1
  store { i64, ptr } %t118, ptr %l65, !tbaa !27
  %t119 = load { i64, [4 x i64] }, ptr %l62
  %t120 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t121 = load ptr, ptr %t120, !tbaa !27
  %t122 = getelementptr { i64, [4 x i64] }, ptr %t121, i64 0
  store { i64, [4 x i64] } %t119, ptr %t122
  %t123 = load { i64, [4 x i64] }, ptr %l64
  %t124 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !27
  %t126 = getelementptr { i64, [4 x i64] }, ptr %t125, i64 1
  store { i64, [4 x i64] } %t123, ptr %t126
  %t127 = load %"compiler/source:Span", ptr %l3
  %t128 = load ptr, ptr %l59, !tbaa !29
  %t129 = load i32, ptr %l60
  %t130 = load i32, ptr %l61, !tbaa !23
  %t131 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t133 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s2, ptr %t128, i32 %t129, i32 %t130, { i64, ptr } %t131, %"compiler/source:Span" %t127)
  store { i64, [4 x i64] } %t133, ptr %l67
  br label %bb16
bb16:
  %t134 = load { i64, [4 x i64] }, ptr %l67
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t137 = load ptr, ptr %l1, !tbaa !29
  %t139 = getelementptr %"compiler/typed:Slice", ptr %t137, i32 0, i32 3
  %t140 = load i32, ptr %t139
  %t141 = load i64, ptr @G_2ecompiler_2flower_2eOutOfBounds, !tbaa !24
  %t142 = load %"compiler/source:Span", ptr %l3
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2echeck(ptr %v0, ptr %t135, { i64, [4 x i64] } %t134, i32 %t140, i32 6, i64 %t141, %"compiler/source:Span" %t142)
  br label %bb17
bb17:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t150 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t151 = load { i64, [4 x i64] }, ptr %l7
  %t152 = load { i64, [4 x i64] }, ptr %l8
  %t153 = mul i64 2, 40
  %t154 = call ptr @__olang_scope_alloc_zeroed(ptr %s2, i64 %t153)
  %t155 = insertvalue { i64, ptr } undef, i64 2, 0
  %t156 = insertvalue { i64, ptr } %t155, ptr %t154, 1
  store { i64, ptr } %t156, ptr %l80, !tbaa !27
  %t158 = getelementptr { i64, ptr }, ptr %l80, i32 0, i32 1
  %t159 = load ptr, ptr %t158, !tbaa !27
  %t160 = getelementptr { i64, [4 x i64] }, ptr %t159, i64 0
  store { i64, [4 x i64] } %t151, ptr %t160
  %t162 = getelementptr { i64, ptr }, ptr %l80, i32 0, i32 1
  %t163 = load ptr, ptr %t162, !tbaa !27
  %t164 = getelementptr { i64, [4 x i64] }, ptr %t163, i64 1
  store { i64, [4 x i64] } %t152, ptr %t164
  %t165 = load %"compiler/source:Span", ptr %l3
  %t169 = load { i64, ptr }, ptr %l80, !tbaa !27
  %t171 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s2, ptr %t149, i32 16, i32 %t150, { i64, ptr } %t169, %"compiler/source:Span" %t165)
  store { i64, [4 x i64] } %t171, ptr %l82
  br label %bb18
bb18:
  %t172 = load { i64, [4 x i64] }, ptr %l82
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t175 = load ptr, ptr %l1, !tbaa !29
  %t177 = getelementptr %"compiler/typed:Slice", ptr %t175, i32 0, i32 3
  %t178 = load i32, ptr %t177
  %t179 = load i64, ptr @G_2ecompiler_2flower_2eOutOfBounds, !tbaa !24
  %t180 = load %"compiler/source:Span", ptr %l3
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2echeck(ptr %v0, ptr %t173, { i64, [4 x i64] } %t172, i32 %t178, i32 6, i64 %t179, %"compiler/source:Span" %t180)
  br label %bb19
bb19:
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t188 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t189 = load { i64, [4 x i64] }, ptr %l8
  %t190 = load { i64, [4 x i64] }, ptr %l9
  %t191 = mul i64 2, 40
  %t192 = call ptr @__olang_scope_alloc_zeroed(ptr %s2, i64 %t191)
  %t193 = insertvalue { i64, ptr } undef, i64 2, 0
  %t194 = insertvalue { i64, ptr } %t193, ptr %t192, 1
  store { i64, ptr } %t194, ptr %l95, !tbaa !27
  %t196 = getelementptr { i64, ptr }, ptr %l95, i32 0, i32 1
  %t197 = load ptr, ptr %t196, !tbaa !27
  %t198 = getelementptr { i64, [4 x i64] }, ptr %t197, i64 0
  store { i64, [4 x i64] } %t189, ptr %t198
  %t200 = getelementptr { i64, ptr }, ptr %l95, i32 0, i32 1
  %t201 = load ptr, ptr %t200, !tbaa !27
  %t202 = getelementptr { i64, [4 x i64] }, ptr %t201, i64 1
  store { i64, [4 x i64] } %t190, ptr %t202
  %t203 = load %"compiler/source:Span", ptr %l3
  %t207 = load { i64, ptr }, ptr %l95, !tbaa !27
  %t209 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s2, ptr %t187, i32 16, i32 %t188, { i64, ptr } %t207, %"compiler/source:Span" %t203)
  store { i64, [4 x i64] } %t209, ptr %l97
  br label %bb20
bb20:
  %t210 = load { i64, [4 x i64] }, ptr %l97
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t213 = load ptr, ptr %l1, !tbaa !29
  %t215 = getelementptr %"compiler/typed:Slice", ptr %t213, i32 0, i32 3
  %t216 = load i32, ptr %t215
  %t217 = load i64, ptr @G_2ecompiler_2flower_2eOutOfBounds, !tbaa !24
  %t218 = load %"compiler/source:Span", ptr %l3
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2echeck(ptr %v0, ptr %t211, { i64, [4 x i64] } %t210, i32 %t216, i32 6, i64 %t217, %"compiler/source:Span" %t218)
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s2)
  br label %bb22
bb22:
  %t225 = load ptr, ptr %l0, !tbaa !29
  store ptr %t225, ptr %l105, !tbaa !29
  %t226 = load i32, ptr %l2, !tbaa !23
  store i32 %t226, ptr %l106, !tbaa !23
  %t227 = load ptr, ptr %l0, !tbaa !29
  %t228 = load %"compiler/lower:pl", ptr %l4
  %t231 = call %"compiler/mir:Place" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %v0, ptr %t227, %"compiler/lower:pl" %t228)
  store %"compiler/mir:Place" %t231, ptr %l109
  br label %bb23
bb23:
  %t232 = load { i64, [4 x i64] }, ptr %l7
  %t233 = load { i64, [4 x i64] }, ptr %l8
  %t234 = load i32, ptr %l2, !tbaa !23
  store { i64, [15 x i64] } zeroinitializer, ptr %t235
  %t236 = getelementptr { i64, [15 x i64] }, ptr %t235, i32 0, i32 0
  store i64 9, ptr %t236
  %t237 = load %"compiler/mir:Place", ptr %l109
  %t238 = insertvalue { %"compiler/mir:Place", { i64, [4 x i64] }, { i64, [4 x i64] }, i32 } undef, %"compiler/mir:Place" %t237, 0
  %t240 = insertvalue { %"compiler/mir:Place", { i64, [4 x i64] }, { i64, [4 x i64] }, i32 } %t238, { i64, [4 x i64] } %t232, 1
  %t242 = insertvalue { %"compiler/mir:Place", { i64, [4 x i64] }, { i64, [4 x i64] }, i32 } %t240, { i64, [4 x i64] } %t233, 2
  %t244 = insertvalue { %"compiler/mir:Place", { i64, [4 x i64] }, { i64, [4 x i64] }, i32 } %t242, i32 %t234, 3
  %t245 = getelementptr { i64, [15 x i64] }, ptr %t235, i32 0, i32 1
  store { %"compiler/mir:Place", { i64, [4 x i64] }, { i64, [4 x i64] }, i32 } %t244, ptr %t245
  %t246 = load { i64, [15 x i64] }, ptr %t235
  %t247 = load %"compiler/source:Span", ptr %l3
  %t248 = load ptr, ptr %l105, !tbaa !29
  %t249 = load i32, ptr %l106, !tbaa !23
  %t252 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t248, i32 %t249, { i64, [15 x i64] } %t246, %"compiler/source:Span" %t247)
  store { i64, [4 x i64] } %t252, ptr %l115
  br label %bb24
bb24:
  %t253 = load { i64, [4 x i64] }, ptr %l115
  store { i64, [4 x i64] } %t253, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2estorageOf(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, [1 x i64] }
  %l11 = alloca %"compiler/mir:Local"
  %l17 = alloca ptr
  %l23 = alloca %"compiler/typed:Local"
  %l26 = alloca { i64, [1 x i64] }
  %rv = alloca { i64, [1 x i64] }
  %t8 = alloca { i64, [1 x i64] }, align 8
  %t49 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 19
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  store { i64, [1 x i64] } zeroinitializer, ptr %t8
  %t9 = getelementptr { i64, [1 x i64] }, ptr %t8, i32 0, i32 0
  store i64 2, ptr %t9
  %t10 = load { i64, [1 x i64] }, ptr %t8
  store { i64, [1 x i64] } %t10, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/lower:lowering", ptr %t12, i32 0, i32 3
  %t15 = getelementptr %"compiler/mir:Fn", ptr %t14, i32 0, i32 7
  %t16 = load i32, ptr %l1, !tbaa !23
  %t18 = sext i32 %t16 to i64
  %t21 = call %"compiler/mir:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %t15, i64 %t18)
  store %"compiler/mir:Local" %t21, ptr %l11
  br label %bb4
bb4:
  %t22 = getelementptr %"compiler/mir:Local", ptr %l11, i32 0, i32 4
  %t23 = load { i64, [1 x i64] }, ptr %t22
  store { i64, [1 x i64] } %t23, ptr %l2
  %t25 = load { i64, [1 x i64] }, ptr %l2
  %t27 = extractvalue { i64, [1 x i64] } %t25, 0
  %t28 = icmp eq i64 %t27, 3
  %t30 = xor i1 %t28, true
  br i1 %t30, label %bb5, label %bb6
bb5:
  %t32 = load { i64, [1 x i64] }, ptr %l2
  store { i64, [1 x i64] } %t32, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t34 = load ptr, ptr %l0, !tbaa !29
  store ptr %t34, ptr %l17, !tbaa !29
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/lower:lowering", ptr %t35, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t40 = getelementptr %"compiler/typed:Body", ptr %t38, i32 0, i32 7
  %t41 = load i32, ptr %l1, !tbaa !23
  %t43 = sext i32 %t41 to i64
  %t46 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t40, i64 %t43)
  store %"compiler/typed:Local" %t46, ptr %l23
  br label %bb8
bb8:
  %t47 = getelementptr %"compiler/typed:Local", ptr %l23, i32 0, i32 3
  %t48 = load i32, ptr %t47, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t49
  %t50 = getelementptr { i64, [1 x i64] }, ptr %t49, i32 0, i32 0
  store i64 1, ptr %t50
  %t52 = insertvalue { i32 } undef, i32 %t48, 0
  %t53 = getelementptr { i64, [1 x i64] }, ptr %t49, i32 0, i32 1
  store { i32 } %t52, ptr %t53
  %t54 = load { i64, [1 x i64] }, ptr %t49
  %t55 = load ptr, ptr %l17, !tbaa !29
  %t57 = call { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2escopeRef(ptr %v0, ptr %t55, { i64, [1 x i64] } %t54)
  store { i64, [1 x i64] } %t57, ptr %l26
  br label %bb9
bb9:
  %t58 = load { i64, [1 x i64] }, ptr %l26
  store { i64, [1 x i64] } %t58, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [1 x i64] }, ptr %rv
  ret { i64, [1 x i64] } %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2esuspend(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca { i64, [4 x i64] }
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i32
  %l19 = alloca i32
  %l20 = alloca ptr
  %l24 = alloca { i64, [4 x i64] }
  %l29 = alloca { i64, [4 x i64] }
  %l36 = alloca i32
  %l44 = alloca i64
  %l45 = alloca { i64, [1 x i64] }
  %l51 = alloca i64
  %l55 = alloca i64
  %l58 = alloca i64
  %l76 = alloca i64
  %l78 = alloca ptr
  %l81 = alloca i64
  %l85 = alloca %"compiler/lower:level"
  %l92 = alloca i32
  %l93 = alloca ptr
  %l94 = alloca %"compiler/source:Span"
  %l96 = alloca %"compiler/mir:Place"
  %l97 = alloca { i64, [4 x i64] }
  %l98 = alloca i32
  %l102 = alloca %"compiler/mir:Range"
  %s0 = alloca %olang.scope
  %t64 = alloca { i64, [1 x i64] }, align 8
  %t77 = alloca i64
  %t160 = alloca { i64, [1 x i64] }, align 8
  %t186 = alloca { i64, [4 x i64] }, align 8
  %t200 = alloca { i64, [8 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/lower:lowering", ptr %t5, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = getelementptr %"compiler/typed:Body", ptr %t8, i32 0, i32 2
  %t11 = load i32, ptr %t10, !tbaa !23
  %t14 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t4, i32 %t11)
  store i32 %t14, ptr %l19
  br label %bb1
bb1:
  %t15 = load i32, ptr %l19, !tbaa !23
  store i32 %t15, ptr %l3, !tbaa !23
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l20, !tbaa !29
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t18 = load ptr, ptr %l2, !tbaa !29
  %t22 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %t17, ptr %t18)
  store { i64, [4 x i64] } %t22, ptr %l24
  br label %bb2
bb2:
  %t23 = load ptr, ptr %l2, !tbaa !29
  %t25 = load i32, ptr %l3, !tbaa !23
  %t26 = load %"compiler/source:Span", ptr %l1
  %t27 = load ptr, ptr %l20, !tbaa !29
  %t28 = load { i64, [4 x i64] }, ptr %l24
  %t32 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2efit(ptr %v0, ptr %v1, ptr %t27, { i64, [4 x i64] } %t28, ptr %t23, i32 %t25, %"compiler/source:Span" %t26)
  store { i64, [4 x i64] } %t32, ptr %l29
  br label %bb3
bb3:
  %t33 = load { i64, [4 x i64] }, ptr %l29
  store { i64, [4 x i64] } %t33, ptr %l4
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/lower:lowering", ptr %t34, i32 0, i32 7
  %t37 = load i1, ptr %t36, !tbaa !21
  br i1 %t37, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb5:
  br label %bb6
bb6:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load { i64, [4 x i64] }, ptr %l4
  %t41 = load i32, ptr %l3, !tbaa !23
  %t42 = load %"compiler/source:Span", ptr %l1
  %t47 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2elocal(ptr %v0, ptr %t39, { i64, [4 x i64] } %t40, i32 %t41, %"compiler/source:Span" %t42)
  store i32 %t47, ptr %l36
  br label %bb7
bb7:
  %t48 = load i32, ptr %l36, !tbaa !23
  store i32 %t48, ptr %l5, !tbaa !23
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load i32, ptr %l5, !tbaa !23
  %t51 = load i32, ptr %l3, !tbaa !23
  %t52 = load ptr, ptr %l2, !tbaa !29
  %t53 = load %"compiler/source:Span", ptr %l1
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eretArrays(ptr %v0, ptr %v1, ptr %t49, i32 %t50, i32 %t51, ptr %t52, %"compiler/source:Span" %t53)
  br label %bb8
bb8:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/lower:lowering", ptr %t59, i32 0, i32 9
  %t63 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e_2eLen_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %t61)
  store i64 %t63, ptr %l44
  br label %bb9
bb9:
  store { i64, [1 x i64] } zeroinitializer, ptr %t64
  %t65 = getelementptr { i64, [1 x i64] }, ptr %t64, i32 0, i32 0
  store i64 3, ptr %t65
  %t66 = load { i64, [1 x i64] }, ptr %t64
  store { i64, [1 x i64] } %t66, ptr %l45
  %t67 = load i64, ptr %l44, !tbaa !24
  %t68 = icmp sge i64 %t67, 0
  br i1 %t68, label %bb10, label %bb11
bb10:
  %t70 = load i64, ptr %l44, !tbaa !24
  %t71 = icmp sle i64 %t70, 576460752303423487
  br i1 %t71, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_c2ea6282af4907c_77e331cc54ab44a0)
  unreachable
bb12:
  %t73 = load i64, ptr %l44, !tbaa !24
  %t74 = mul i64 %t73, 16
  %t75 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t74)
  %t76 = load { i64, [1 x i64] }, ptr %l45
  store i64 0, ptr %t77
  br label %fill.78
fill.78:
  %t81 = load i64, ptr %t77
  %t82 = icmp slt i64 %t81, %t73
  br i1 %t82, label %fillb.79, label %filld.80
fillb.79:
  %t83 = getelementptr { i64, [1 x i64] }, ptr %t75, i64 %t81
  store { i64, [1 x i64] } %t76, ptr %t83
  %t84 = add i64 %t81, 1
  store i64 %t84, ptr %t77
  br label %fill.78
filld.80:
  %t85 = insertvalue { i64, ptr } undef, i64 %t73, 0
  %t86 = insertvalue { i64, ptr } %t85, ptr %t75, 1
  store { i64, ptr } %t86, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/lower:lowering", ptr %t88, i32 0, i32 9
  %t92 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e_2eLen_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %t90)
  store i64 %t92, ptr %l51
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_c2ea6282af4907c_77e331cc54ab44a0)
  unreachable
bb14:
  %t93 = load i64, ptr %l51, !tbaa !24
  store i64 %t93, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t94 = load i64, ptr %l8, !tbaa !24
  %t95 = load i64, ptr %l7, !tbaa !24
  %t98 = icmp sgt i64 %t94, %t95
  br i1 %t98, label %bb15, label %bb16
bb15:
  %t100 = load i64, ptr %l9, !tbaa !24
  %t102 = icmp sgt i64 %t100, 0
  br i1 %t102, label %bb17, label %bb18
bb16:
  store i64 0, ptr %l55, !tbaa !24
  br label %bb20
bb17:
  %t104 = load i64, ptr %l8, !tbaa !24
  %t105 = load i64, ptr %l7, !tbaa !24
  %t108 = sub i64 %t104, %t105
  %t109 = load i64, ptr %l9, !tbaa !24
  %t112 = add i64 %t108, %t109
  %t114 = sub i64 %t112, 1
  %t115 = load i64, ptr %l9, !tbaa !24
  %t118 = sdiv i64 %t114, %t115
  store i64 %t118, ptr %l58, !tbaa !24
  br label %bb19
bb18:
  store i64 0, ptr %l58, !tbaa !24
  br label %bb19
bb19:
  %t120 = load i64, ptr %l58, !tbaa !24
  store i64 %t120, ptr %l55, !tbaa !24
  br label %bb20
bb20:
  %t121 = load i64, ptr %l55, !tbaa !24
  store i64 %t121, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb21
bb21:
  %t122 = load i64, ptr %l11, !tbaa !24
  %t123 = load i64, ptr %l10, !tbaa !24
  %t126 = icmp slt i64 %t122, %t123
  %t128 = xor i1 %t126, true
  br i1 %t128, label %bb22, label %bb23
bb22:
  br label %bb28
bb23:
  br label %bb24
bb24:
  %t130 = load i64, ptr %l7, !tbaa !24
  %t131 = load i64, ptr %l11, !tbaa !24
  %t132 = load i64, ptr %l9, !tbaa !24
  %t135 = mul i64 %t131, %t132
  %t138 = add i64 %t130, %t135
  store i64 %t138, ptr %l12, !tbaa !24
  %t140 = load i64, ptr %l12, !tbaa !24
  store i64 %t140, ptr %l76, !tbaa !24
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t143 = getelementptr %"compiler/lower:lowering", ptr %t141, i32 0, i32 9
  store ptr %t143, ptr %l78, !tbaa !29
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t146 = getelementptr %"compiler/lower:lowering", ptr %t144, i32 0, i32 9
  %t148 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e_2eLen_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %t146)
  store i64 %t148, ptr %l81
  br label %bb25
bb25:
  %t149 = load i64, ptr %l81, !tbaa !24
  %t150 = sub i64 %t149, 1
  %t151 = load i64, ptr %l12, !tbaa !24
  %t154 = sub i64 %t150, %t151
  %t155 = load ptr, ptr %l78, !tbaa !29
  %t157 = call %"compiler/lower:level" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e_2eAt_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %t155, i64 %t154)
  store %"compiler/lower:level" %t157, ptr %l85
  br label %bb26
bb26:
  %t158 = getelementptr %"compiler/lower:level", ptr %l85, i32 0, i32 0
  %t159 = load i32, ptr %t158, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t160
  %t161 = getelementptr { i64, [1 x i64] }, ptr %t160, i32 0, i32 0
  store i64 0, ptr %t161
  %t163 = insertvalue { i32 } undef, i32 %t159, 0
  %t164 = getelementptr { i64, [1 x i64] }, ptr %t160, i32 0, i32 1
  store { i32 } %t163, ptr %t164
  %t165 = load { i64, [1 x i64] }, ptr %t160
  %t167 = load i64, ptr %l76, !tbaa !24
  %t168 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t169 = load ptr, ptr %t168, !tbaa !27
  %t170 = getelementptr { i64, [1 x i64] }, ptr %t169, i64 %t167
  store { i64, [1 x i64] } %t165, ptr %t170
  br label %bb27
bb27:
  %t171 = load i64, ptr %l11, !tbaa !24
  %t173 = add i64 %t171, 1
  store i64 %t173, ptr %l11, !tbaa !24
  br label %bb21
bb28:
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t177 = getelementptr %"compiler/lower:lowering", ptr %t175, i32 0, i32 3
  %t179 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t177)
  store i32 %t179, ptr %l92
  br label %bb29
bb29:
  %t180 = load i32, ptr %l92, !tbaa !23
  store i32 %t180, ptr %l13, !tbaa !23
  %t181 = load ptr, ptr %l0, !tbaa !29
  store ptr %t181, ptr %l93, !tbaa !29
  %t182 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t182, ptr %l94
  %t183 = load i32, ptr %l5, !tbaa !23
  %t185 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t183)
  store %"compiler/mir:Place" %t185, ptr %l96
  br label %bb30
bb30:
  store { i64, [4 x i64] } zeroinitializer, ptr %t186
  %t187 = getelementptr { i64, [4 x i64] }, ptr %t186, i32 0, i32 0
  store i64 1, ptr %t187
  %t188 = load %"compiler/mir:Place", ptr %l96
  %t189 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t188, 0
  %t190 = getelementptr { i64, [4 x i64] }, ptr %t186, i32 0, i32 1
  store { %"compiler/mir:Place" } %t189, ptr %t190
  %t191 = load { i64, [4 x i64] }, ptr %t186
  store { i64, [4 x i64] } %t191, ptr %l97
  %t192 = load i32, ptr %l13, !tbaa !23
  store i32 %t192, ptr %l98, !tbaa !23
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t195 = getelementptr %"compiler/lower:lowering", ptr %t193, i32 0, i32 3
  %t196 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t199 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eScopeRefs(ptr %v0, ptr %s0, ptr %t195, { i64, ptr } %t196)
  store %"compiler/mir:Range" %t199, ptr %l102
  br label %bb31
bb31:
  store { i64, [8 x i64] } zeroinitializer, ptr %t200
  %t201 = getelementptr { i64, [8 x i64] }, ptr %t200, i32 0, i32 0
  store i64 10, ptr %t201
  %t202 = load %"compiler/source:Span", ptr %l94
  %t203 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] }, i32, %"compiler/mir:Range" } undef, %"compiler/source:Span" %t202, 0
  %t204 = load { i64, [4 x i64] }, ptr %l97
  %t205 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] }, i32, %"compiler/mir:Range" } %t203, { i64, [4 x i64] } %t204, 1
  %t206 = load i32, ptr %l98, !tbaa !23
  %t207 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] }, i32, %"compiler/mir:Range" } %t205, i32 %t206, 2
  %t208 = load %"compiler/mir:Range", ptr %l102
  %t209 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] }, i32, %"compiler/mir:Range" } %t207, %"compiler/mir:Range" %t208, 3
  %t210 = getelementptr { i64, [8 x i64] }, ptr %t200, i32 0, i32 1
  store { %"compiler/source:Span", { i64, [4 x i64] }, i32, %"compiler/mir:Range" } %t209, ptr %t210
  %t211 = load { i64, [8 x i64] }, ptr %t200
  %t212 = load ptr, ptr %l93, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t212, { i64, [8 x i64] } %t211)
  br label %bb32
bb32:
  %t214 = load ptr, ptr %l0, !tbaa !29
  %t215 = load i32, ptr %l13, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t214, i32 %t215)
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2etake(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca %"compiler/lower:pl"
  %l7 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l9 = alloca i64
  %l14 = alloca %"compiler/lower:pl"
  %l18 = alloca ptr
  %l19 = alloca i32
  %l22 = alloca %"compiler/mir:Place"
  %l25 = alloca { i64, [4 x i64] }
  %l30 = alloca { i64, [4 x i64] }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, [4 x i64] }
  %t25 = alloca { i64, [4 x i64] }, align 8
  %t36 = alloca { i64, [15 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t5 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2flower_2ecompiler_2flower_3alowering_2ereleases(ptr %v0, ptr %v1, ptr %v0, ptr %t1, ptr %t2, i1 false)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t5, ptr %l7
  br label %bb1
bb1:
  %t6 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l7
  %t7 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 8, i64 8)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t6, ptr %t7
  %t9 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2eLen_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %t7)
  store i64 %t9, ptr %l9
  br label %bb2
bb2:
  %t10 = load i64, ptr %l9, !tbaa !24
  %t11 = icmp sgt i64 %t10, 0
  br i1 %t11, label %bb3, label %bb4
bb3:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t18 = call %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2eplace(ptr %v0, ptr %v1, ptr %v0, ptr %t13, ptr %t14)
  store %"compiler/lower:pl" %t18, ptr %l14
  br label %bb5
bb4:
  br label %bb11
bb5:
  %t19 = load %"compiler/lower:pl", ptr %l14
  store %"compiler/lower:pl" %t19, ptr %l4
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/lower:lowering", ptr %t20, i32 0, i32 7
  %t23 = load i1, ptr %t22, !tbaa !21
  br i1 %t23, label %bb6, label %bb7
bb6:
  store { i64, [4 x i64] } zeroinitializer, ptr %t25
  %t26 = getelementptr { i64, [4 x i64] }, ptr %t25, i32 0, i32 0
  store i64 0, ptr %t26
  %t27 = load { i64, [4 x i64] }, ptr %t25
  call void @__olang_scope_close(ptr %s0)
  store { i64, [4 x i64] } %t27, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l18, !tbaa !29
  %t30 = load i32, ptr %l2, !tbaa !23
  store i32 %t30, ptr %l19, !tbaa !23
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load %"compiler/lower:pl", ptr %l4
  %t35 = call %"compiler/mir:Place" @compiler_2flower_2ecompiler_2flower_3alowering_2emk(ptr %v0, ptr %v0, ptr %t31, %"compiler/lower:pl" %t32)
  store %"compiler/mir:Place" %t35, ptr %l22
  br label %bb9
bb9:
  store { i64, [15 x i64] } zeroinitializer, ptr %t36
  %t37 = getelementptr { i64, [15 x i64] }, ptr %t36, i32 0, i32 0
  store i64 2, ptr %t37
  %t38 = load %"compiler/mir:Place", ptr %l22
  %t39 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t38, 0
  %t40 = getelementptr { i64, [15 x i64] }, ptr %t36, i32 0, i32 1
  store { %"compiler/mir:Place" } %t39, ptr %t40
  %t41 = load { i64, [15 x i64] }, ptr %t36
  %t42 = load %"compiler/source:Span", ptr %l3
  %t43 = load ptr, ptr %l18, !tbaa !29
  %t44 = load i32, ptr %l19, !tbaa !23
  %t47 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %t43, i32 %t44, { i64, [15 x i64] } %t41, %"compiler/source:Span" %t42)
  store { i64, [4 x i64] } %t47, ptr %l25
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s0)
  %t48 = load { i64, [4 x i64] }, ptr %l25
  store { i64, [4 x i64] } %t48, ptr %rv
  br label %ret
bb11:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load ptr, ptr %l1, !tbaa !29
  %t51 = load i32, ptr %l2, !tbaa !23
  %t52 = load %"compiler/source:Span", ptr %l3
  %t57 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eread(ptr %v0, ptr %v1, ptr %t49, ptr %t50, i32 %t51, %"compiler/source:Span" %t52)
  store { i64, [4 x i64] } %t57, ptr %l30
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s0)
  %t58 = load { i64, [4 x i64] }, ptr %l30
  store { i64, [4 x i64] } %t58, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etaskType(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca { { i64, [7 x i64] }, i32 }
  %l11 = alloca i32
  %l12 = alloca ptr
  %l13 = alloca i1
  %l20 = alloca ptr
  %l21 = alloca i1
  %l31 = alloca ptr
  %l34 = alloca ptr
  %l35 = alloca i1
  %l44 = alloca i32
  %l45 = alloca ptr
  %l46 = alloca i1
  %l52 = alloca i32
  %l53 = alloca ptr
  %l54 = alloca i1
  %l64 = alloca { { i64, [7 x i64] }, i32 }
  %l67 = alloca ptr
  %l68 = alloca i1
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t2 = load ptr, ptr %l12, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l12, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 6
  store i1 %t8, ptr %l13, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l13, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb40
bb5:
  %t16 = load ptr, ptr %l2, !tbaa !29
  %t18 = getelementptr %"compiler/typed:Call", ptr %t16, i32 0, i32 0
  %t19 = load ptr, ptr %t18, !tbaa !29
  store ptr %t19, ptr %l3, !tbaa !29
  %t21 = load ptr, ptr %l3, !tbaa !29
  store ptr %t21, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t22 = load ptr, ptr %l20, !tbaa !29
  %t23 = icmp ne ptr %t22, null
  br i1 %t23, label %bb6, label %bb7
bb6:
  %t25 = load ptr, ptr %l20, !tbaa !29
  %t26 = load i64, ptr %t25
  %t28 = icmp eq i64 %t26, 0
  store i1 %t28, ptr %l21, !tbaa !21
  br label %bb7
bb7:
  %t29 = load i1, ptr %l21, !tbaa !21
  br i1 %t29, label %bb8, label %bb9
bb8:
  %t30 = load ptr, ptr %l3, !tbaa !29
  %t32 = getelementptr { i64, [3 x i64] }, ptr %t30, i32 0, i32 1
  %t33 = getelementptr { i32 }, ptr %t32, i32 0, i32 0
  %t34 = load i32, ptr %t33
  store i32 %t34, ptr %l4, !tbaa !23
  br label %bb10
bb9:
  br label %bb12
bb10:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/lower:lowering", ptr %t36, i32 0, i32 0
  %t39 = load ptr, ptr %t38, !tbaa !29
  %t41 = getelementptr %"compiler/lower:Lowerer", ptr %t39, i32 0, i32 1
  %t42 = load i32, ptr %l4, !tbaa !23
  %t44 = sext i32 %t42 to i64
  %t47 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t41, i64 %t44)
  store ptr %t47, ptr %l31
  br label %bb11
bb11:
  %t48 = load ptr, ptr %l31, !tbaa !29
  %t50 = getelementptr %"compiler/typed:Body", ptr %t48, i32 0, i32 2
  %t51 = load i32, ptr %t50, !tbaa !23
  store i32 %t51, ptr %rv
  br label %ret
bb12:
  %t53 = load ptr, ptr %l3, !tbaa !29
  store ptr %t53, ptr %l34, !tbaa !29
  store i1 false, ptr %l35, !tbaa !21
  %t54 = load ptr, ptr %l34, !tbaa !29
  %t55 = icmp ne ptr %t54, null
  br i1 %t55, label %bb13, label %bb14
bb13:
  %t57 = load ptr, ptr %l34, !tbaa !29
  %t58 = load i64, ptr %t57
  %t60 = icmp eq i64 %t58, 1
  store i1 %t60, ptr %l35, !tbaa !21
  br label %bb14
bb14:
  %t61 = load i1, ptr %l35, !tbaa !21
  br i1 %t61, label %bb15, label %bb16
bb15:
  %t62 = load ptr, ptr %l3, !tbaa !29
  %t64 = getelementptr { i64, [3 x i64] }, ptr %t62, i32 0, i32 1
  %t65 = getelementptr { i64 }, ptr %t64, i32 0, i32 0
  %t66 = load i64, ptr %t65
  store i64 %t66, ptr %l5, !tbaa !24
  br label %bb17
bb16:
  br label %bb19
bb17:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/lower:lowering", ptr %t68, i32 0, i32 0
  %t71 = load ptr, ptr %t70, !tbaa !29
  %t73 = getelementptr %"compiler/lower:Lowerer", ptr %t71, i32 0, i32 0
  %t74 = load ptr, ptr %t73, !tbaa !29
  %t75 = load i64, ptr %l5, !tbaa !24
  %t78 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t74, i64 %t75)
  store i32 %t78, ptr %l44
  br label %bb18
bb18:
  %t79 = load i32, ptr %l44, !tbaa !23
  store i32 %t79, ptr %rv
  br label %ret
bb19:
  %t80 = load ptr, ptr %l3, !tbaa !29
  store ptr %t80, ptr %l45, !tbaa !29
  store i1 false, ptr %l46, !tbaa !21
  %t81 = load ptr, ptr %l45, !tbaa !29
  %t82 = icmp ne ptr %t81, null
  br i1 %t82, label %bb20, label %bb21
bb20:
  %t84 = load ptr, ptr %l45, !tbaa !29
  %t85 = load i64, ptr %t84
  %t87 = icmp eq i64 %t85, 2
  store i1 %t87, ptr %l46, !tbaa !21
  br label %bb21
bb21:
  %t88 = load i1, ptr %l46, !tbaa !21
  br i1 %t88, label %bb22, label %bb23
bb22:
  %t89 = load ptr, ptr %l3, !tbaa !29
  %t91 = getelementptr { i64, [3 x i64] }, ptr %t89, i32 0, i32 1
  %t92 = getelementptr { ptr }, ptr %t91, i32 0, i32 0
  %t93 = load ptr, ptr %t92
  store ptr %t93, ptr %l6, !tbaa !29
  br label %bb24
bb23:
  br label %bb26
bb24:
  %t95 = load ptr, ptr %l6, !tbaa !29
  %t97 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t95)
  store i32 %t97, ptr %l52
  br label %bb25
bb25:
  %t98 = load i32, ptr %l52, !tbaa !23
  store i32 %t98, ptr %rv
  br label %ret
bb26:
  %t99 = load ptr, ptr %l3, !tbaa !29
  store ptr %t99, ptr %l53, !tbaa !29
  store i1 false, ptr %l54, !tbaa !21
  %t100 = load ptr, ptr %l53, !tbaa !29
  %t101 = icmp ne ptr %t100, null
  br i1 %t101, label %bb27, label %bb28
bb27:
  %t103 = load ptr, ptr %l53, !tbaa !29
  %t104 = load i64, ptr %t103
  %t106 = icmp eq i64 %t104, 4
  store i1 %t106, ptr %l54, !tbaa !21
  br label %bb28
bb28:
  %t107 = load i1, ptr %l54, !tbaa !21
  br i1 %t107, label %bb29, label %bb30
bb29:
  %t108 = load ptr, ptr %l3, !tbaa !29
  %t110 = getelementptr { i64, [3 x i64] }, ptr %t108, i32 0, i32 1
  %t111 = getelementptr { i32, i32 }, ptr %t110, i32 0, i32 0
  %t112 = load i32, ptr %t111
  store i32 %t112, ptr %l7
  %t114 = load ptr, ptr %l3, !tbaa !29
  %t116 = getelementptr { i64, [3 x i64] }, ptr %t114, i32 0, i32 1
  %t117 = getelementptr { i32, i32 }, ptr %t116, i32 0, i32 1
  %t118 = load i32, ptr %t117
  store i32 %t118, ptr %l8, !tbaa !23
  br label %bb31
bb30:
  br label %bb33
bb31:
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t121 = load i32, ptr %l7
  %t122 = load i32, ptr %l8, !tbaa !23
  %t126 = call { { i64, [7 x i64] }, i32 } @compiler_2flower_2ecompiler_2flower_3alowering_2ehelperCallee(ptr %v0, ptr %t120, i32 %t121, i32 %t122)
  store { { i64, [7 x i64] }, i32 } %t126, ptr %l64
  br label %bb32
bb32:
  %t127 = load { { i64, [7 x i64] }, i32 }, ptr %l64
  store { { i64, [7 x i64] }, i32 } %t127, ptr %l9
  %t128 = getelementptr { { i64, [7 x i64] }, i32 }, ptr %l9, i32 0, i32 1
  %t129 = load i32, ptr %t128, !tbaa !23
  store i32 %t129, ptr %rv
  br label %ret
bb33:
  %t133 = load ptr, ptr %l3, !tbaa !29
  store ptr %t133, ptr %l67, !tbaa !29
  store i1 false, ptr %l68, !tbaa !21
  %t134 = load ptr, ptr %l67, !tbaa !29
  %t135 = icmp ne ptr %t134, null
  br i1 %t135, label %bb34, label %bb35
bb34:
  %t137 = load ptr, ptr %l67, !tbaa !29
  %t138 = load i64, ptr %t137
  %t140 = icmp eq i64 %t138, 3
  store i1 %t140, ptr %l68, !tbaa !21
  br label %bb35
bb35:
  %t141 = load i1, ptr %l68, !tbaa !21
  br i1 %t141, label %bb36, label %bb37
bb36:
  %t142 = load ptr, ptr %l3, !tbaa !29
  %t144 = getelementptr { i64, [3 x i64] }, ptr %t142, i32 0, i32 1
  %t145 = getelementptr { i32, i64, i32 }, ptr %t144, i32 0, i32 2
  %t146 = load i32, ptr %t145
  store i32 %t146, ptr %l11, !tbaa !23
  br label %bb38
bb37:
  br label %bb39
bb38:
  %t148 = load i32, ptr %l11, !tbaa !23
  store i32 %t148, ptr %rv
  br label %ret
bb39:
  call void @__olang_check_failed(ptr @olang_loc_3b3f675a7fcfa09e_a6d8609e08455d8a)
  unreachable
bb40:
  br i1 true, label %bb41, label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb44
bb43:
  br label %bb45
bb44:
  call void @__olang_check_failed(ptr @olang_loc_a39e67f1cd7c0b1f_e499cc399c2ba1cb)
  unreachable
bb45:
  %t150 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t150, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2etoClause(ptr %v0, ptr %v1, ptr %a0, %"compiler/lower:tryCtx" %a1, i64 %a2, { i64, [4 x i64] } %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/lower:tryCtx"
  %l2 = alloca i64
  %l5 = alloca ptr
  %l7 = alloca i1
  %l8 = alloca { i64, ptr }
  %l18 = alloca %"compiler/mir:Place"
  %l41 = alloca i32
  %l44 = alloca ptr
  %l45 = alloca i64
  %l48 = alloca i32
  %l49 = alloca ptr
  %l52 = alloca i32
  %s1 = alloca %olang.scope
  %t39 = alloca { i64, [15 x i64] }, align 8
  %t49 = alloca { i64, [21 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/lower:tryCtx" %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/lower:tryCtx", ptr %l1, i32 0, i32 1
  %t2 = load { i64, ptr }, ptr %t1, !tbaa !27
  store { i64, ptr } %t2, ptr %l8, !tbaa !27
  %t3 = load i64, ptr %l2, !tbaa !24
  %t5 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t6 = load ptr, ptr %t5, !tbaa !27
  %t7 = getelementptr ptr, ptr %t6, i64 %t3
  %t8 = load ptr, ptr %t7, !tbaa !39
  store ptr %t8, ptr %l5, !tbaa !29
  %t10 = load ptr, ptr %l5, !tbaa !29
  %t12 = getelementptr %"compiler/typed:Clause", ptr %t10, i32 0, i32 5
  %t13 = load i64, ptr %t12, !tbaa !24
  %t15 = icmp sge i64 %t13, 0
  br i1 %t15, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t17 = load ptr, ptr %l5, !tbaa !29
  %t19 = getelementptr %"compiler/typed:Clause", ptr %t17, i32 0, i32 5
  %t20 = load i64, ptr %t19, !tbaa !24
  %t22 = trunc i64 %t20 to i32
  %t25 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t22)
  store %"compiler/mir:Place" %t25, ptr %l18
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t26 = load %"compiler/mir:Place", ptr %l18
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load ptr, ptr %l5, !tbaa !29
  %t30 = getelementptr %"compiler/typed:Clause", ptr %t28, i32 0, i32 0
  %t31 = load %"compiler/source:Span", ptr %t30
  %t35 = load ptr, ptr %l5, !tbaa !29
  %t37 = getelementptr %"compiler/typed:Clause", ptr %t35, i32 0, i32 6
  %t38 = load i32, ptr %t37, !tbaa !23
  store { i64, [15 x i64] } zeroinitializer, ptr %t39
  %t40 = getelementptr { i64, [15 x i64] }, ptr %t39, i32 0, i32 0
  store i64 11, ptr %t40
  %t42 = insertvalue { { i64, [4 x i64] }, i32, i32 } undef, { i64, [4 x i64] } %a3, 0
  %t44 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t42, i32 %a4, 1
  %t46 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t44, i32 %t38, 2
  %t47 = getelementptr { i64, [15 x i64] }, ptr %t39, i32 0, i32 1
  store { { i64, [4 x i64] }, i32, i32 } %t46, ptr %t47
  %t48 = load { i64, [15 x i64] }, ptr %t39
  store { i64, [21 x i64] } zeroinitializer, ptr %t49
  %t50 = getelementptr { i64, [21 x i64] }, ptr %t49, i32 0, i32 0
  store i64 0, ptr %t50
  %t52 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t31, 0
  %t54 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t52, %"compiler/mir:Place" %t26, 1
  %t56 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t54, { i64, [15 x i64] } %t48, 2
  %t57 = getelementptr { i64, [21 x i64] }, ptr %t49, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t56, ptr %t57
  %t58 = load { i64, [21 x i64] }, ptr %t49
  %t60 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 176, i64 8)
  store { i64, [21 x i64] } %t58, ptr %t60
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s1, ptr %t27, ptr %t60)
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s1)
  br label %bb5
bb5:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/lower:lowering", ptr %t63, i32 0, i32 18
  %t66 = load i1, ptr %t65, !tbaa !21
  store i1 %t66, ptr %l7, !tbaa !21
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/lower:lowering", ptr %t68, i32 0, i32 18
  store i1 true, ptr %t70, !tbaa !21
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/lower:tryCtx", ptr %l1, i32 0, i32 0
  %t73 = load i64, ptr %t72, !tbaa !24
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eleave(ptr %v0, ptr %t71, i64 %t73)
  br label %bb6
bb6:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t77 = load i1, ptr %l7, !tbaa !21
  %t80 = getelementptr %"compiler/lower:lowering", ptr %t76, i32 0, i32 18
  store i1 %t77, ptr %t80, !tbaa !21
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/lower:lowering", ptr %t81, i32 0, i32 7
  %t84 = load i1, ptr %t83, !tbaa !21
  br i1 %t84, label %bb7, label %bb8
bb7:
  br label %ret
bb8:
  br label %bb9
bb9:
  %t86 = getelementptr %"compiler/lower:tryCtx", ptr %l1, i32 0, i32 4
  %t87 = load i64, ptr %l2, !tbaa !24
  %t90 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2eAt_3ccompiler_2fmir_3aBlockId_3e(ptr %v1, ptr %t86, i64 %t87)
  store i32 %t90, ptr %l41
  br label %bb10
bb10:
  %t91 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t92 = load i32, ptr %l41, !tbaa !23
  %t94 = icmp eq i32 %t92, %t91
  br i1 %t94, label %bb11, label %bb12
bb11:
  %t96 = getelementptr %"compiler/lower:tryCtx", ptr %l1, i32 0, i32 4
  store ptr %t96, ptr %l44, !tbaa !29
  %t97 = load i64, ptr %l2, !tbaa !24
  store i64 %t97, ptr %l45, !tbaa !24
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/lower:lowering", ptr %t98, i32 0, i32 3
  %t102 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t100)
  store i32 %t102, ptr %l48
  br label %bb13
bb12:
  br label %bb15
bb13:
  %t103 = load ptr, ptr %l44, !tbaa !29
  %t104 = load i64, ptr %l45, !tbaa !24
  %t105 = load i32, ptr %l48, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2eSetAt_3ccompiler_2fmir_3aBlockId_3e(ptr %v1, ptr %t103, i64 %t104, i32 %t105)
  br label %bb14
bb14:
  br label %bb15
bb15:
  %t106 = load ptr, ptr %l0, !tbaa !29
  store ptr %t106, ptr %l49, !tbaa !29
  %t107 = getelementptr %"compiler/lower:tryCtx", ptr %l1, i32 0, i32 4
  %t108 = load i64, ptr %l2, !tbaa !24
  %t111 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2eAt_3ccompiler_2fmir_3aBlockId_3e(ptr %v1, ptr %t107, i64 %t108)
  store i32 %t111, ptr %l52
  br label %bb16
bb16:
  %t112 = load ptr, ptr %l49, !tbaa !29
  %t113 = load i32, ptr %l52, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2egoto(ptr %v0, ptr %t112, i32 %t113)
  br label %bb17
bb17:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2eword(ptr %v0, ptr %v1, ptr %a0, { i64, [1 x i64] } %a1, { i64, ptr } %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l12 = alloca i32
  %l15 = alloca i64
  %l23 = alloca i64
  %l26 = alloca i64
  %l45 = alloca { i64, ptr }
  %l53 = alloca i32
  %l55 = alloca ptr
  %l59 = alloca i32
  %l61 = alloca i32
  %l67 = alloca i32
  %s0 = alloca %olang.scope
  %t110 = alloca { i64, [2 x i64] }, align 8
  %t132 = alloca { i64, [4 x i64] }, align 8
  %t144 = alloca { i64, [21 x i64] }, align 8
  store ptr %a0, ptr %l0
  store { i64, ptr } %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l15, !tbaa !24
  %t4 = load i64, ptr %l15, !tbaa !24
  %t5 = icmp sge i64 %t4, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load i64, ptr %l15, !tbaa !24
  %t8 = mul i64 %t7, 1
  %t9 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t13 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  store i64 %t15, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t17 = load i64, ptr %l6, !tbaa !24
  %t18 = load i64, ptr %l5, !tbaa !24
  %t21 = icmp sgt i64 %t17, %t18
  br i1 %t21, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_683e5e170631bc0e_4d1425fdf2d9aa22)
  unreachable
bb3:
  %t23 = load i64, ptr %l7, !tbaa !24
  %t25 = icmp sgt i64 %t23, 0
  br i1 %t25, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb8
bb5:
  %t27 = load i64, ptr %l6, !tbaa !24
  %t28 = load i64, ptr %l5, !tbaa !24
  %t31 = sub i64 %t27, %t28
  %t32 = load i64, ptr %l7, !tbaa !24
  %t35 = add i64 %t31, %t32
  %t37 = sub i64 %t35, 1
  %t38 = load i64, ptr %l7, !tbaa !24
  %t41 = sdiv i64 %t37, %t38
  store i64 %t41, ptr %l26, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l26, !tbaa !24
  br label %bb7
bb7:
  %t43 = load i64, ptr %l26, !tbaa !24
  store i64 %t43, ptr %l23, !tbaa !24
  br label %bb8
bb8:
  %t44 = load i64, ptr %l23, !tbaa !24
  store i64 %t44, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb9
bb9:
  %t45 = load i64, ptr %l9, !tbaa !24
  %t46 = load i64, ptr %l8, !tbaa !24
  %t49 = icmp slt i64 %t45, %t46
  %t51 = xor i1 %t49, true
  br i1 %t51, label %bb10, label %bb11
bb10:
  br label %bb14
bb11:
  br label %bb12
bb12:
  %t53 = load i64, ptr %l5, !tbaa !24
  %t54 = load i64, ptr %l9, !tbaa !24
  %t55 = load i64, ptr %l7, !tbaa !24
  %t58 = mul i64 %t54, %t55
  %t61 = add i64 %t53, %t58
  store i64 %t61, ptr %l10, !tbaa !24
  %t63 = load i64, ptr %l10, !tbaa !24
  %t64 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t64, ptr %l45, !tbaa !27
  %t65 = load i64, ptr %l10, !tbaa !24
  %t67 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !27
  %t69 = getelementptr i8, ptr %t68, i64 %t65
  %t70 = load i8, ptr %t69, !tbaa !32
  %t74 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t75 = load ptr, ptr %t74, !tbaa !27
  %t76 = getelementptr i8, ptr %t75, i64 %t63
  store i8 %t70, ptr %t76, !tbaa !32
  br label %bb13
bb13:
  %t77 = load i64, ptr %l9, !tbaa !24
  %t79 = add i64 %t77, 1
  store i64 %t79, ptr %l9, !tbaa !24
  br label %bb9
bb14:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/lower:lowering", ptr %t81, i32 0, i32 2
  %t84 = load ptr, ptr %t83, !tbaa !29
  %t86 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s0, ptr %t84, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d17, i32 0, i32 1) })
  store i32 %t86, ptr %l53
  br label %bb15
bb15:
  %t87 = load i32, ptr %l53, !tbaa !23
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/lower:lowering", ptr %t88, i32 0, i32 2
  %t91 = load ptr, ptr %t90, !tbaa !29
  store ptr %t91, ptr %l55, !tbaa !29
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/lower:lowering", ptr %t92, i32 0, i32 2
  %t95 = load ptr, ptr %t94, !tbaa !29
  %t99 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %t95, i32 %t87, i32 0)
  store i32 %t99, ptr %l59
  br label %bb16
bb16:
  %t100 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t101 = load ptr, ptr %l55, !tbaa !29
  %t102 = load i32, ptr %l59, !tbaa !23
  %t104 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t101, i32 %t102, i64 %t100)
  store i32 %t104, ptr %l61
  br label %bb17
bb17:
  %t105 = load i32, ptr %l61, !tbaa !23
  store i32 %t105, ptr %l12, !tbaa !23
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = getelementptr %"compiler/lower:lowering", ptr %t106, i32 0, i32 3
  %t109 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, [2 x i64] } zeroinitializer, ptr %t110
  %t111 = getelementptr { i64, [2 x i64] }, ptr %t110, i32 0, i32 0
  store i64 1, ptr %t111
  %t113 = insertvalue { { i64, ptr } } undef, { i64, ptr } %t109, 0
  %t114 = getelementptr { i64, [2 x i64] }, ptr %t110, i32 0, i32 1
  store { { i64, ptr } } %t113, ptr %t114
  %t115 = load { i64, [2 x i64] }, ptr %t110
  %t117 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 24, i64 8)
  store { i64, [2 x i64] } %t115, ptr %t117
  %t120 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddConst(ptr %v0, ptr %s0, ptr %t108, ptr %t117)
  store i32 %t120, ptr %l67
  br label %bb18
bb18:
  %t121 = load i32, ptr %l67, !tbaa !23
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t123 = load %"compiler/source:Span", ptr %l3
  %t125 = load i32, ptr %l12, !tbaa !23
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t129 = getelementptr %"compiler/lower:lowering", ptr %t127, i32 0, i32 4
  %t130 = load i64, ptr %t129, !tbaa !24
  %t131 = load %"compiler/source:Span", ptr %l3
  store { i64, [4 x i64] } zeroinitializer, ptr %t132
  %t133 = getelementptr { i64, [4 x i64] }, ptr %t132, i32 0, i32 0
  store i64 3, ptr %t133
  %t135 = insertvalue { i32, i32, i64, %"compiler/source:Span" } undef, i32 %t125, 0
  %t137 = insertvalue { i32, i32, i64, %"compiler/source:Span" } %t135, i32 %t121, 1
  %t139 = insertvalue { i32, i32, i64, %"compiler/source:Span" } %t137, i64 %t130, 2
  %t141 = insertvalue { i32, i32, i64, %"compiler/source:Span" } %t139, %"compiler/source:Span" %t131, 3
  %t142 = getelementptr { i64, [4 x i64] }, ptr %t132, i32 0, i32 1
  store { i32, i32, i64, %"compiler/source:Span" } %t141, ptr %t142
  %t143 = load { i64, [4 x i64] }, ptr %t132
  store { i64, [21 x i64] } zeroinitializer, ptr %t144
  %t145 = getelementptr { i64, [21 x i64] }, ptr %t144, i32 0, i32 0
  store i64 9, ptr %t145
  %t147 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } undef, %"compiler/source:Span" %t123, 0
  %t149 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t147, { i64, [1 x i64] } %a1, 1
  %t151 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t149, i32 0, 2
  %t153 = insertvalue { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t151, { i64, [4 x i64] } %t143, 3
  %t154 = getelementptr { i64, [21 x i64] }, ptr %t144, i32 0, i32 1
  store { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } } %t153, ptr %t154
  %t155 = load { i64, [21 x i64] }, ptr %t144
  %t157 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t155, ptr %t157
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %t122, ptr %t157)
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flower_2ecompiler_2flower_3alowering_2eyield(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l3 = alloca %"compiler/lower:collectCtx"
  %l4 = alloca { i64, [4 x i64] }
  %l5 = alloca ptr
  %l6 = alloca { i64, [4 x i64] }
  %l8 = alloca %"compiler/mir:Place"
  %l9 = alloca { i64, [4 x i64] }
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca { i64, [4 x i64] }
  %l13 = alloca i32
  %l16 = alloca i64
  %l21 = alloca ptr
  %l24 = alloca i64
  %l26 = alloca %"compiler/lower:collectCtx"
  %l30 = alloca { i64, [4 x i64] }
  %l36 = alloca %"compiler/mir:Place"
  %l40 = alloca ptr
  %l42 = alloca { i64, [2 x i64] }
  %l44 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l51 = alloca { i64, ptr }
  %l52 = alloca %"compiler/mir:Place"
  %l60 = alloca ptr
  %l61 = alloca %"compiler/source:Span"
  %l63 = alloca %"compiler/mir:Place"
  %l64 = alloca i32
  %l65 = alloca i32
  %l67 = alloca ptr
  %l68 = alloca { i64, [4 x i64] }
  %l70 = alloca { i64, [4 x i64] }
  %l71 = alloca { i64, ptr }
  %l72 = alloca %"compiler/mir:Range"
  %l81 = alloca { i64, ptr }
  %l82 = alloca %"compiler/mir:Place"
  %l83 = alloca ptr
  %l84 = alloca i32
  %l85 = alloca i32
  %l86 = alloca { i64, [4 x i64] }
  %l87 = alloca ptr
  %l88 = alloca i32
  %l89 = alloca i32
  %l91 = alloca %"compiler/mir:Place"
  %l93 = alloca { i64, ptr }
  %l95 = alloca { i64, [4 x i64] }
  %l96 = alloca { i64, ptr }
  %l98 = alloca { i64, [4 x i64] }
  %l101 = alloca i32
  %l104 = alloca i32
  %l112 = alloca ptr
  %l113 = alloca i32
  %l114 = alloca i32
  %l115 = alloca ptr
  %l116 = alloca i32
  %l117 = alloca i32
  %l118 = alloca { i64, [4 x i64] }
  %l120 = alloca { i64, [4 x i64] }
  %l121 = alloca { i64, ptr }
  %l123 = alloca { i64, [4 x i64] }
  %l125 = alloca { i64, [4 x i64] }
  %l126 = alloca { i64, ptr }
  %l128 = alloca { i64, [4 x i64] }
  %l132 = alloca i32
  %l133 = alloca ptr
  %l134 = alloca %"compiler/source:Span"
  %l136 = alloca %"compiler/mir:Place"
  %l145 = alloca ptr
  %l146 = alloca %"compiler/source:Span"
  %l152 = alloca { i64, ptr }
  %l153 = alloca %"compiler/mir:Place"
  %l158 = alloca ptr
  %l159 = alloca %"compiler/source:Span"
  %l161 = alloca %"compiler/mir:Place"
  %l163 = alloca %"compiler/mir:Place"
  %l172 = alloca ptr
  %l173 = alloca %"compiler/source:Span"
  %l181 = alloca { i64, ptr }
  %l182 = alloca %"compiler/mir:Place"
  %l187 = alloca ptr
  %l188 = alloca %"compiler/source:Span"
  %l190 = alloca %"compiler/mir:Place"
  %l191 = alloca i32
  %l192 = alloca i32
  %l194 = alloca ptr
  %l195 = alloca { i64, [4 x i64] }
  %l197 = alloca { i64, [4 x i64] }
  %l198 = alloca { i64, ptr }
  %l199 = alloca %"compiler/mir:Range"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %t48 = alloca { i64, [4 x i64] }, align 8
  %t63 = alloca { i64, [2 x i64] }, align 8
  %t72 = alloca { i64, [1 x i64] }, align 8
  %t77 = alloca { i64, [1 x i64] }, align 8
  %t98 = alloca { i64, [1 x i64] }, align 8
  %t122 = alloca { i64, [15 x i64] }, align 8
  %t128 = alloca { i64, [21 x i64] }, align 8
  %t171 = alloca { i64, [15 x i64] }, align 8
  %t181 = alloca { i64, [21 x i64] }, align 8
  %t200 = alloca { i64, [2 x i64] }, align 8
  %t206 = alloca { i64, [1 x i64] }, align 8
  %t231 = alloca { i64, [4 x i64] }, align 8
  %t288 = alloca { i64, [8 x i64] }, align 8
  %t375 = alloca { i64, [4 x i64] }, align 8
  %t382 = alloca { i64, [15 x i64] }, align 8
  %t394 = alloca { i64, [21 x i64] }, align 8
  %t414 = alloca { i64, [2 x i64] }, align 8
  %t420 = alloca { i64, [1 x i64] }, align 8
  %t437 = alloca { i64, [21 x i64] }, align 8
  %t462 = alloca { i64, [4 x i64] }, align 8
  %t468 = alloca { i64, [15 x i64] }, align 8
  %t474 = alloca { i64, [21 x i64] }, align 8
  %t503 = alloca { i64, [2 x i64] }, align 8
  %t509 = alloca { i64, [1 x i64] }, align 8
  %t514 = alloca { i64, [1 x i64] }, align 8
  %t537 = alloca { i64, [15 x i64] }, align 8
  %t543 = alloca { i64, [21 x i64] }, align 8
  %t586 = alloca { i64, [15 x i64] }, align 8
  %t596 = alloca { i64, [21 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lower:lowering", ptr %t1, i32 0, i32 14
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3acollectCtx_3e_2eLen_H6eade83fd48a7a0e84be67fdfc468e69(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l16
  br label %bb1
bb1:
  %t6 = load i64, ptr %l16, !tbaa !24
  %t7 = icmp eq i64 %t6, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load %"compiler/source:Span", ptr %l1
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2egap(ptr %v0, ptr %s1, ptr %t9, %"compiler/source:Span" %t10, { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d18, i32 0, i32 1) })
  br label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb5:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/lower:lowering", ptr %t13, i32 0, i32 14
  store ptr %t15, ptr %l21, !tbaa !29
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/lower:lowering", ptr %t16, i32 0, i32 14
  %t20 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3acollectCtx_3e_2eLen_H6eade83fd48a7a0e84be67fdfc468e69(ptr %v0, ptr %t18)
  store i64 %t20, ptr %l24
  br label %bb6
bb6:
  %t21 = load i64, ptr %l24, !tbaa !24
  %t22 = sub i64 %t21, 1
  %t23 = load ptr, ptr %l21, !tbaa !29
  %t25 = call %"compiler/lower:collectCtx" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3acollectCtx_3e_2eAt__Hce97d3b6a95327627873f207e844a422(ptr %v0, ptr %t23, i64 %t22)
  store %"compiler/lower:collectCtx" %t25, ptr %l26
  br label %bb7
bb7:
  %t26 = load %"compiler/lower:collectCtx", ptr %l26
  store %"compiler/lower:collectCtx" %t26, ptr %l3
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t32 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %t27, ptr %a2)
  store { i64, [4 x i64] } %t32, ptr %l30
  br label %bb8
bb8:
  %t33 = load { i64, [4 x i64] }, ptr %l30
  store { i64, [4 x i64] } %t33, ptr %l4
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/lower:lowering", ptr %t34, i32 0, i32 7
  %t37 = load i1, ptr %t36, !tbaa !21
  br i1 %t37, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb10:
  br label %bb11
bb11:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/lower:lowering", ptr %t39, i32 0, i32 2
  %t42 = load ptr, ptr %t41, !tbaa !29
  store ptr %t42, ptr %l5, !tbaa !29
  %t44 = getelementptr %"compiler/lower:collectCtx", ptr %l3, i32 0, i32 1
  %t45 = load i32, ptr %t44, !tbaa !23
  %t47 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t45)
  store %"compiler/mir:Place" %t47, ptr %l36
  br label %bb12
bb12:
  store { i64, [4 x i64] } zeroinitializer, ptr %t48
  %t49 = getelementptr { i64, [4 x i64] }, ptr %t48, i32 0, i32 0
  store i64 1, ptr %t49
  %t50 = load %"compiler/mir:Place", ptr %l36
  %t51 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t50, 0
  %t52 = getelementptr { i64, [4 x i64] }, ptr %t48, i32 0, i32 1
  store { %"compiler/mir:Place" } %t51, ptr %t52
  %t53 = load { i64, [4 x i64] }, ptr %t48
  store { i64, [4 x i64] } %t53, ptr %l6
  %t55 = getelementptr %"compiler/lower:collectCtx", ptr %l3, i32 0, i32 5
  %t56 = load i1, ptr %t55, !tbaa !21
  br i1 %t56, label %bb13, label %bb14
bb13:
  store %olang.scope zeroinitializer, ptr %s3
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/lower:lowering", ptr %t58, i32 0, i32 3
  store ptr %t60, ptr %l40, !tbaa !29
  %t61 = getelementptr %"compiler/lower:collectCtx", ptr %l3, i32 0, i32 0
  %t62 = load i32, ptr %t61, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t63
  %t64 = getelementptr { i64, [2 x i64] }, ptr %t63, i32 0, i32 0
  store i64 1, ptr %t64
  %t66 = insertvalue { i32 } undef, i32 %t62, 0
  %t67 = getelementptr { i64, [2 x i64] }, ptr %t63, i32 0, i32 1
  store { i32 } %t66, ptr %t67
  %t68 = load { i64, [2 x i64] }, ptr %t63
  store { i64, [2 x i64] } %t68, ptr %l42
  %t69 = getelementptr %"compiler/lower:collectCtx", ptr %l3, i32 0, i32 6
  %t70 = load i1, ptr %t69, !tbaa !21
  br i1 %t70, label %bb15, label %bb16
bb14:
  br label %bb24
bb15:
  store { i64, [1 x i64] } zeroinitializer, ptr %t72
  %t73 = getelementptr { i64, [1 x i64] }, ptr %t72, i32 0, i32 0
  store i64 3, ptr %t73
  %t74 = load { i64, [1 x i64] }, ptr %t72
  %t75 = getelementptr %"compiler/lower:collectCtx", ptr %l3, i32 0, i32 1
  %t76 = load i32, ptr %t75, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t77
  %t78 = getelementptr { i64, [1 x i64] }, ptr %t77, i32 0, i32 0
  store i64 1, ptr %t78
  %t80 = insertvalue { i32 } undef, i32 %t76, 0
  %t81 = getelementptr { i64, [1 x i64] }, ptr %t77, i32 0, i32 1
  store { i32 } %t80, ptr %t81
  %t82 = load { i64, [1 x i64] }, ptr %t77
  %t83 = mul i64 2, 16
  %t84 = call ptr @__olang_scope_alloc_zeroed(ptr %s3, i64 %t83)
  %t85 = insertvalue { i64, ptr } undef, i64 2, 0
  %t86 = insertvalue { i64, ptr } %t85, ptr %t84, 1
  store { i64, ptr } %t86, ptr %l48, !tbaa !27
  %t88 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !27
  %t90 = getelementptr { i64, [1 x i64] }, ptr %t89, i64 0
  store { i64, [1 x i64] } %t74, ptr %t90
  %t92 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !27
  %t94 = getelementptr { i64, [1 x i64] }, ptr %t93, i64 1
  store { i64, [1 x i64] } %t82, ptr %t94
  %t95 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t95, ptr %l44, !tbaa !27
  br label %bb17
bb16:
  %t96 = getelementptr %"compiler/lower:collectCtx", ptr %l3, i32 0, i32 1
  %t97 = load i32, ptr %t96, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t98
  %t99 = getelementptr { i64, [1 x i64] }, ptr %t98, i32 0, i32 0
  store i64 1, ptr %t99
  %t101 = insertvalue { i32 } undef, i32 %t97, 0
  %t102 = getelementptr { i64, [1 x i64] }, ptr %t98, i32 0, i32 1
  store { i32 } %t101, ptr %t102
  %t103 = load { i64, [1 x i64] }, ptr %t98
  %t104 = mul i64 1, 16
  %t105 = call ptr @__olang_scope_alloc_zeroed(ptr %s3, i64 %t104)
  %t106 = insertvalue { i64, ptr } undef, i64 1, 0
  %t107 = insertvalue { i64, ptr } %t106, ptr %t105, 1
  store { i64, ptr } %t107, ptr %l51, !tbaa !27
  %t109 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t110 = load ptr, ptr %t109, !tbaa !27
  %t111 = getelementptr { i64, [1 x i64] }, ptr %t110, i64 0
  store { i64, [1 x i64] } %t103, ptr %t111
  %t112 = load { i64, ptr }, ptr %l51, !tbaa !27
  store { i64, ptr } %t112, ptr %l44, !tbaa !27
  br label %bb17
bb17:
  %t113 = load ptr, ptr %l40, !tbaa !29
  %t114 = load { i64, [2 x i64] }, ptr %l42
  %t115 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t116 = call %"compiler/mir:Place" @compiler_2fmir_2ecompiler_2fmir_3aFn_2ePlace(ptr %v0, ptr %s3, ptr %t113, { i64, [2 x i64] } %t114, { i64, ptr } %t115)
  store %"compiler/mir:Place" %t116, ptr %l52
  br label %bb18
bb18:
  %t117 = load %"compiler/mir:Place", ptr %l52
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t119 = load %"compiler/source:Span", ptr %l1
  %t121 = load { i64, [4 x i64] }, ptr %l4
  store { i64, [15 x i64] } zeroinitializer, ptr %t122
  %t123 = getelementptr { i64, [15 x i64] }, ptr %t122, i32 0, i32 0
  store i64 0, ptr %t123
  %t125 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t121, 0
  %t126 = getelementptr { i64, [15 x i64] }, ptr %t122, i32 0, i32 1
  store { { i64, [4 x i64] } } %t125, ptr %t126
  %t127 = load { i64, [15 x i64] }, ptr %t122
  store { i64, [21 x i64] } zeroinitializer, ptr %t128
  %t129 = getelementptr { i64, [21 x i64] }, ptr %t128, i32 0, i32 0
  store i64 0, ptr %t129
  %t131 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t119, 0
  %t133 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t131, %"compiler/mir:Place" %t117, 1
  %t135 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t133, { i64, [15 x i64] } %t127, 2
  %t136 = getelementptr { i64, [21 x i64] }, ptr %t128, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t135, ptr %t136
  %t137 = load { i64, [21 x i64] }, ptr %t128
  %t139 = call ptr @__olang_scope_alloc_a(ptr %s3, i64 176, i64 8)
  store { i64, [21 x i64] } %t137, ptr %t139
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s3, ptr %t118, ptr %t139)
  br label %bb19
bb19:
  %t142 = load ptr, ptr %l0, !tbaa !29
  store ptr %t142, ptr %l60, !tbaa !29
  %t143 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t143, ptr %l61
  %t144 = getelementptr %"compiler/lower:collectCtx", ptr %l3, i32 0, i32 1
  %t145 = load i32, ptr %t144, !tbaa !23
  %t147 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t145)
  store %"compiler/mir:Place" %t147, ptr %l63
  br label %bb20
bb20:
  store i32 3, ptr %l64
  %t148 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  store i32 %t148, ptr %l65, !tbaa !23
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t151 = getelementptr %"compiler/lower:lowering", ptr %t149, i32 0, i32 3
  store ptr %t151, ptr %l67, !tbaa !29
  %t152 = load { i64, [4 x i64] }, ptr %l6
  store { i64, [4 x i64] } %t152, ptr %l68
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t155 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2econstI64(ptr %v0, ptr %t153, i64 1)
  store { i64, [4 x i64] } %t155, ptr %l70
  br label %bb21
bb21:
  %t156 = mul i64 2, 40
  %t157 = call ptr @__olang_scope_alloc_zeroed(ptr %s3, i64 %t156)
  %t158 = insertvalue { i64, ptr } undef, i64 2, 0
  %t159 = insertvalue { i64, ptr } %t158, ptr %t157, 1
  store { i64, ptr } %t159, ptr %l71, !tbaa !27
  %t160 = load { i64, [4 x i64] }, ptr %l68
  %t161 = getelementptr { i64, ptr }, ptr %l71, i32 0, i32 1
  %t162 = load ptr, ptr %t161, !tbaa !27
  %t163 = getelementptr { i64, [4 x i64] }, ptr %t162, i64 0
  store { i64, [4 x i64] } %t160, ptr %t163
  %t164 = load { i64, [4 x i64] }, ptr %l70
  %t165 = getelementptr { i64, ptr }, ptr %l71, i32 0, i32 1
  %t166 = load ptr, ptr %t165, !tbaa !27
  %t167 = getelementptr { i64, [4 x i64] }, ptr %t166, i64 1
  store { i64, [4 x i64] } %t164, ptr %t167
  %t168 = load ptr, ptr %l67, !tbaa !29
  %t169 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t170 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v0, ptr %s3, ptr %t168, { i64, ptr } %t169)
  store %"compiler/mir:Range" %t170, ptr %l72
  br label %bb22
bb22:
  store { i64, [15 x i64] } zeroinitializer, ptr %t171
  %t172 = getelementptr { i64, [15 x i64] }, ptr %t171, i32 0, i32 0
  store i64 3, ptr %t172
  %t173 = load i32, ptr %l64
  %t174 = insertvalue { i32, i32, %"compiler/mir:Range" } undef, i32 %t173, 0
  %t175 = load i32, ptr %l65, !tbaa !23
  %t176 = insertvalue { i32, i32, %"compiler/mir:Range" } %t174, i32 %t175, 1
  %t177 = load %"compiler/mir:Range", ptr %l72
  %t178 = insertvalue { i32, i32, %"compiler/mir:Range" } %t176, %"compiler/mir:Range" %t177, 2
  %t179 = getelementptr { i64, [15 x i64] }, ptr %t171, i32 0, i32 1
  store { i32, i32, %"compiler/mir:Range" } %t178, ptr %t179
  %t180 = load { i64, [15 x i64] }, ptr %t171
  store { i64, [21 x i64] } zeroinitializer, ptr %t181
  %t182 = getelementptr { i64, [21 x i64] }, ptr %t181, i32 0, i32 0
  store i64 0, ptr %t182
  %t183 = load %"compiler/source:Span", ptr %l61
  %t184 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t183, 0
  %t185 = load %"compiler/mir:Place", ptr %l63
  %t186 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t184, %"compiler/mir:Place" %t185, 1
  %t188 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t186, { i64, [15 x i64] } %t180, 2
  %t189 = getelementptr { i64, [21 x i64] }, ptr %t181, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t188, ptr %t189
  %t190 = load { i64, [21 x i64] }, ptr %t181
  %t192 = call ptr @__olang_scope_alloc_a(ptr %s3, i64 176, i64 8)
  store { i64, [21 x i64] } %t190, ptr %t192
  %t193 = load ptr, ptr %l60, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s3, ptr %t193, ptr %t192)
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb24:
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t197 = getelementptr %"compiler/lower:lowering", ptr %t195, i32 0, i32 3
  %t198 = getelementptr %"compiler/lower:collectCtx", ptr %l3, i32 0, i32 0
  %t199 = load i32, ptr %t198, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t200
  %t201 = getelementptr { i64, [2 x i64] }, ptr %t200, i32 0, i32 0
  store i64 1, ptr %t201
  %t203 = insertvalue { i32 } undef, i32 %t199, 0
  %t204 = getelementptr { i64, [2 x i64] }, ptr %t200, i32 0, i32 1
  store { i32 } %t203, ptr %t204
  %t205 = load { i64, [2 x i64] }, ptr %t200
  store { i64, [1 x i64] } zeroinitializer, ptr %t206
  %t207 = getelementptr { i64, [1 x i64] }, ptr %t206, i32 0, i32 0
  store i64 3, ptr %t207
  %t208 = load { i64, [1 x i64] }, ptr %t206
  %t209 = mul i64 1, 16
  %t210 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t209)
  %t211 = insertvalue { i64, ptr } undef, i64 1, 0
  %t212 = insertvalue { i64, ptr } %t211, ptr %t210, 1
  store { i64, ptr } %t212, ptr %l81, !tbaa !27
  %t214 = getelementptr { i64, ptr }, ptr %l81, i32 0, i32 1
  %t215 = load ptr, ptr %t214, !tbaa !27
  %t216 = getelementptr { i64, [1 x i64] }, ptr %t215, i64 0
  store { i64, [1 x i64] } %t208, ptr %t216
  %t219 = load { i64, ptr }, ptr %l81, !tbaa !27
  %t220 = call %"compiler/mir:Place" @compiler_2fmir_2ecompiler_2fmir_3aFn_2ePlace(ptr %v0, ptr %s0, ptr %t197, { i64, [2 x i64] } %t205, { i64, ptr } %t219)
  store %"compiler/mir:Place" %t220, ptr %l82
  br label %bb25
bb25:
  %t221 = load %"compiler/mir:Place", ptr %l82
  store %"compiler/mir:Place" %t221, ptr %l8
  %t222 = load ptr, ptr %l0, !tbaa !29
  store ptr %t222, ptr %l83, !tbaa !29
  store i32 13, ptr %l84
  %t223 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t223, ptr %l85, !tbaa !23
  %t224 = load { i64, [4 x i64] }, ptr %l6
  store { i64, [4 x i64] } %t224, ptr %l86
  %t225 = load ptr, ptr %l0, !tbaa !29
  store ptr %t225, ptr %l87, !tbaa !29
  store i32 22, ptr %l88
  %t226 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  store i32 %t226, ptr %l89, !tbaa !23
  %t227 = getelementptr %"compiler/lower:collectCtx", ptr %l3, i32 0, i32 0
  %t228 = load i32, ptr %t227, !tbaa !23
  %t230 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t228)
  store %"compiler/mir:Place" %t230, ptr %l91
  br label %bb26
bb26:
  store { i64, [4 x i64] } zeroinitializer, ptr %t231
  %t232 = getelementptr { i64, [4 x i64] }, ptr %t231, i32 0, i32 0
  store i64 1, ptr %t232
  %t233 = load %"compiler/mir:Place", ptr %l91
  %t234 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t233, 0
  %t235 = getelementptr { i64, [4 x i64] }, ptr %t231, i32 0, i32 1
  store { %"compiler/mir:Place" } %t234, ptr %t235
  %t236 = load { i64, [4 x i64] }, ptr %t231
  %t237 = mul i64 1, 40
  %t238 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t237)
  %t239 = insertvalue { i64, ptr } undef, i64 1, 0
  %t240 = insertvalue { i64, ptr } %t239, ptr %t238, 1
  store { i64, ptr } %t240, ptr %l93, !tbaa !27
  %t242 = getelementptr { i64, ptr }, ptr %l93, i32 0, i32 1
  %t243 = load ptr, ptr %t242, !tbaa !27
  %t244 = getelementptr { i64, [4 x i64] }, ptr %t243, i64 0
  store { i64, [4 x i64] } %t236, ptr %t244
  %t245 = load %"compiler/source:Span", ptr %l1
  %t246 = load ptr, ptr %l87, !tbaa !29
  %t247 = load i32, ptr %l88
  %t248 = load i32, ptr %l89, !tbaa !23
  %t249 = load { i64, ptr }, ptr %l93, !tbaa !27
  %t251 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s0, ptr %t246, i32 %t247, i32 %t248, { i64, ptr } %t249, %"compiler/source:Span" %t245)
  store { i64, [4 x i64] } %t251, ptr %l95
  br label %bb27
bb27:
  %t252 = mul i64 2, 40
  %t253 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t252)
  %t254 = insertvalue { i64, ptr } undef, i64 2, 0
  %t255 = insertvalue { i64, ptr } %t254, ptr %t253, 1
  store { i64, ptr } %t255, ptr %l96, !tbaa !27
  %t256 = load { i64, [4 x i64] }, ptr %l86
  %t257 = getelementptr { i64, ptr }, ptr %l96, i32 0, i32 1
  %t258 = load ptr, ptr %t257, !tbaa !27
  %t259 = getelementptr { i64, [4 x i64] }, ptr %t258, i64 0
  store { i64, [4 x i64] } %t256, ptr %t259
  %t260 = load { i64, [4 x i64] }, ptr %l95
  %t261 = getelementptr { i64, ptr }, ptr %l96, i32 0, i32 1
  %t262 = load ptr, ptr %t261, !tbaa !27
  %t263 = getelementptr { i64, [4 x i64] }, ptr %t262, i64 1
  store { i64, [4 x i64] } %t260, ptr %t263
  %t264 = load %"compiler/source:Span", ptr %l1
  %t265 = load ptr, ptr %l83, !tbaa !29
  %t266 = load i32, ptr %l84
  %t267 = load i32, ptr %l85, !tbaa !23
  %t268 = load { i64, ptr }, ptr %l96, !tbaa !27
  %t270 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s0, ptr %t265, i32 %t266, i32 %t267, { i64, ptr } %t268, %"compiler/source:Span" %t264)
  store { i64, [4 x i64] } %t270, ptr %l98
  br label %bb28
bb28:
  %t271 = load { i64, [4 x i64] }, ptr %l98
  store { i64, [4 x i64] } %t271, ptr %l9
  %t272 = load ptr, ptr %l0, !tbaa !29
  %t274 = getelementptr %"compiler/lower:lowering", ptr %t272, i32 0, i32 3
  %t276 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t274)
  store i32 %t276, ptr %l101
  br label %bb29
bb29:
  %t277 = load i32, ptr %l101, !tbaa !23
  store i32 %t277, ptr %l10, !tbaa !23
  %t278 = load ptr, ptr %l0, !tbaa !29
  %t280 = getelementptr %"compiler/lower:lowering", ptr %t278, i32 0, i32 3
  %t282 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %t280)
  store i32 %t282, ptr %l104
  br label %bb30
bb30:
  %t283 = load i32, ptr %l104, !tbaa !23
  store i32 %t283, ptr %l11, !tbaa !23
  %t284 = load ptr, ptr %l0, !tbaa !29
  %t285 = load { i64, [4 x i64] }, ptr %l9
  %t286 = load i32, ptr %l10, !tbaa !23
  %t287 = load i32, ptr %l11, !tbaa !23
  store { i64, [8 x i64] } zeroinitializer, ptr %t288
  %t289 = getelementptr { i64, [8 x i64] }, ptr %t288, i32 0, i32 0
  store i64 2, ptr %t289
  %t291 = insertvalue { { i64, [4 x i64] }, i32, i32 } undef, { i64, [4 x i64] } %t285, 0
  %t293 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t291, i32 %t286, 1
  %t295 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t293, i32 %t287, 2
  %t296 = getelementptr { i64, [8 x i64] }, ptr %t288, i32 0, i32 1
  store { { i64, [4 x i64] }, i32, i32 } %t295, ptr %t296
  %t297 = load { i64, [8 x i64] }, ptr %t288
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %t284, { i64, [8 x i64] } %t297)
  br label %bb31
bb31:
  %t300 = load ptr, ptr %l0, !tbaa !29
  %t301 = load i32, ptr %l10, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t300, i32 %t301)
  br label %bb32
bb32:
  %t304 = load ptr, ptr %l0, !tbaa !29
  store ptr %t304, ptr %l112, !tbaa !29
  store i32 3, ptr %l113
  %t305 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  store i32 %t305, ptr %l114, !tbaa !23
  %t306 = load ptr, ptr %l0, !tbaa !29
  store ptr %t306, ptr %l115, !tbaa !29
  store i32 5, ptr %l116
  %t307 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  store i32 %t307, ptr %l117, !tbaa !23
  %t308 = load { i64, [4 x i64] }, ptr %l6
  store { i64, [4 x i64] } %t308, ptr %l118
  %t309 = load ptr, ptr %l0, !tbaa !29
  %t311 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2econstI64(ptr %v0, ptr %t309, i64 2)
  store { i64, [4 x i64] } %t311, ptr %l120
  br label %bb33
bb33:
  %t312 = mul i64 2, 40
  %t313 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t312)
  %t314 = insertvalue { i64, ptr } undef, i64 2, 0
  %t315 = insertvalue { i64, ptr } %t314, ptr %t313, 1
  store { i64, ptr } %t315, ptr %l121, !tbaa !27
  %t316 = load { i64, [4 x i64] }, ptr %l118
  %t317 = getelementptr { i64, ptr }, ptr %l121, i32 0, i32 1
  %t318 = load ptr, ptr %t317, !tbaa !27
  %t319 = getelementptr { i64, [4 x i64] }, ptr %t318, i64 0
  store { i64, [4 x i64] } %t316, ptr %t319
  %t320 = load { i64, [4 x i64] }, ptr %l120
  %t321 = getelementptr { i64, ptr }, ptr %l121, i32 0, i32 1
  %t322 = load ptr, ptr %t321, !tbaa !27
  %t323 = getelementptr { i64, [4 x i64] }, ptr %t322, i64 1
  store { i64, [4 x i64] } %t320, ptr %t323
  %t324 = load %"compiler/source:Span", ptr %l1
  %t325 = load ptr, ptr %l115, !tbaa !29
  %t326 = load i32, ptr %l116
  %t327 = load i32, ptr %l117, !tbaa !23
  %t328 = load { i64, ptr }, ptr %l121, !tbaa !27
  %t330 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s0, ptr %t325, i32 %t326, i32 %t327, { i64, ptr } %t328, %"compiler/source:Span" %t324)
  store { i64, [4 x i64] } %t330, ptr %l123
  br label %bb34
bb34:
  %t331 = load ptr, ptr %l0, !tbaa !29
  %t333 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2econstI64(ptr %v0, ptr %t331, i64 1)
  store { i64, [4 x i64] } %t333, ptr %l125
  br label %bb35
bb35:
  %t334 = mul i64 2, 40
  %t335 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t334)
  %t336 = insertvalue { i64, ptr } undef, i64 2, 0
  %t337 = insertvalue { i64, ptr } %t336, ptr %t335, 1
  store { i64, ptr } %t337, ptr %l126, !tbaa !27
  %t338 = load { i64, [4 x i64] }, ptr %l123
  %t339 = getelementptr { i64, ptr }, ptr %l126, i32 0, i32 1
  %t340 = load ptr, ptr %t339, !tbaa !27
  %t341 = getelementptr { i64, [4 x i64] }, ptr %t340, i64 0
  store { i64, [4 x i64] } %t338, ptr %t341
  %t342 = load { i64, [4 x i64] }, ptr %l125
  %t343 = getelementptr { i64, ptr }, ptr %l126, i32 0, i32 1
  %t344 = load ptr, ptr %t343, !tbaa !27
  %t345 = getelementptr { i64, [4 x i64] }, ptr %t344, i64 1
  store { i64, [4 x i64] } %t342, ptr %t345
  %t346 = load %"compiler/source:Span", ptr %l1
  %t347 = load ptr, ptr %l112, !tbaa !29
  %t348 = load i32, ptr %l113
  %t349 = load i32, ptr %l114, !tbaa !23
  %t350 = load { i64, ptr }, ptr %l126, !tbaa !27
  %t352 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eprim(ptr %v0, ptr %s0, ptr %t347, i32 %t348, i32 %t349, { i64, ptr } %t350, %"compiler/source:Span" %t346)
  store { i64, [4 x i64] } %t352, ptr %l128
  br label %bb36
bb36:
  %t353 = load { i64, [4 x i64] }, ptr %l128
  store { i64, [4 x i64] } %t353, ptr %l12
  %t354 = load ptr, ptr %l0, !tbaa !29
  %t355 = getelementptr %"compiler/lower:collectCtx", ptr %l3, i32 0, i32 3
  %t356 = load i32, ptr %t355, !tbaa !23
  %t357 = load %"compiler/source:Span", ptr %l1
  %t361 = call i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etemp(ptr %v0, ptr %t354, i32 %t356, %"compiler/source:Span" %t357)
  store i32 %t361, ptr %l132
  br label %bb37
bb37:
  %t362 = load i32, ptr %l132, !tbaa !23
  store i32 %t362, ptr %l13, !tbaa !23
  %t363 = load ptr, ptr %l0, !tbaa !29
  store ptr %t363, ptr %l133, !tbaa !29
  %t364 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t364, ptr %l134
  %t365 = load i32, ptr %l13, !tbaa !23
  %t367 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t365)
  store %"compiler/mir:Place" %t367, ptr %l136
  br label %bb38
bb38:
  %t368 = getelementptr %"compiler/lower:collectCtx", ptr %l3, i32 0, i32 4
  %t369 = load { i64, [1 x i64] }, ptr %t368
  %t370 = getelementptr %"compiler/lower:collectCtx", ptr %l3, i32 0, i32 3
  %t371 = load i32, ptr %t370, !tbaa !23
  %t372 = load { i64, [4 x i64] }, ptr %l12
  %t373 = getelementptr %"compiler/lower:collectCtx", ptr %l3, i32 0, i32 2
  %t374 = load i32, ptr %t373, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t375
  %t376 = getelementptr { i64, [4 x i64] }, ptr %t375, i32 0, i32 0
  store i64 2, ptr %t376
  %t378 = insertvalue { i32, i64 } undef, i32 %t374, 0
  %t379 = insertvalue { i32, i64 } %t378, i64 0, 1
  %t380 = getelementptr { i64, [4 x i64] }, ptr %t375, i32 0, i32 1
  store { i32, i64 } %t379, ptr %t380
  %t381 = load { i64, [4 x i64] }, ptr %t375
  store { i64, [15 x i64] } zeroinitializer, ptr %t382
  %t383 = getelementptr { i64, [15 x i64] }, ptr %t382, i32 0, i32 0
  store i64 8, ptr %t383
  %t385 = insertvalue { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } undef, { i64, [1 x i64] } %t369, 0
  %t387 = insertvalue { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } %t385, i32 %t371, 1
  %t389 = insertvalue { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } %t387, { i64, [4 x i64] } %t372, 2
  %t391 = insertvalue { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } %t389, { i64, [4 x i64] } %t381, 3
  %t392 = getelementptr { i64, [15 x i64] }, ptr %t382, i32 0, i32 1
  store { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } %t391, ptr %t392
  %t393 = load { i64, [15 x i64] }, ptr %t382
  store { i64, [21 x i64] } zeroinitializer, ptr %t394
  %t395 = getelementptr { i64, [21 x i64] }, ptr %t394, i32 0, i32 0
  store i64 0, ptr %t395
  %t396 = load %"compiler/source:Span", ptr %l134
  %t397 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t396, 0
  %t398 = load %"compiler/mir:Place", ptr %l136
  %t399 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t397, %"compiler/mir:Place" %t398, 1
  %t401 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t399, { i64, [15 x i64] } %t393, 2
  %t402 = getelementptr { i64, [21 x i64] }, ptr %t394, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t401, ptr %t402
  %t403 = load { i64, [21 x i64] }, ptr %t394
  %t405 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t403, ptr %t405
  %t406 = load ptr, ptr %l133, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %t406, ptr %t405)
  br label %bb39
bb39:
  %t408 = load ptr, ptr %l0, !tbaa !29
  store ptr %t408, ptr %l145, !tbaa !29
  %t409 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t409, ptr %l146
  %t410 = load ptr, ptr %l0, !tbaa !29
  %t412 = getelementptr %"compiler/lower:lowering", ptr %t410, i32 0, i32 3
  %t413 = load i32, ptr %l13, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t414
  %t415 = getelementptr { i64, [2 x i64] }, ptr %t414, i32 0, i32 0
  store i64 1, ptr %t415
  %t417 = insertvalue { i32 } undef, i32 %t413, 0
  %t418 = getelementptr { i64, [2 x i64] }, ptr %t414, i32 0, i32 1
  store { i32 } %t417, ptr %t418
  %t419 = load { i64, [2 x i64] }, ptr %t414
  store { i64, [1 x i64] } zeroinitializer, ptr %t420
  %t421 = getelementptr { i64, [1 x i64] }, ptr %t420, i32 0, i32 0
  store i64 3, ptr %t421
  %t422 = load { i64, [1 x i64] }, ptr %t420
  %t423 = mul i64 1, 16
  %t424 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t423)
  %t425 = insertvalue { i64, ptr } undef, i64 1, 0
  %t426 = insertvalue { i64, ptr } %t425, ptr %t424, 1
  store { i64, ptr } %t426, ptr %l152, !tbaa !27
  %t428 = getelementptr { i64, ptr }, ptr %l152, i32 0, i32 1
  %t429 = load ptr, ptr %t428, !tbaa !27
  %t430 = getelementptr { i64, [1 x i64] }, ptr %t429, i64 0
  store { i64, [1 x i64] } %t422, ptr %t430
  %t433 = load { i64, ptr }, ptr %l152, !tbaa !27
  %t434 = call %"compiler/mir:Place" @compiler_2fmir_2ecompiler_2fmir_3aFn_2ePlace(ptr %v0, ptr %s0, ptr %t412, { i64, [2 x i64] } %t419, { i64, ptr } %t433)
  store %"compiler/mir:Place" %t434, ptr %l153
  br label %bb40
bb40:
  %t435 = load %"compiler/mir:Place", ptr %l8
  %t436 = load { i64, [4 x i64] }, ptr %l6
  store { i64, [21 x i64] } zeroinitializer, ptr %t437
  %t438 = getelementptr { i64, [21 x i64] }, ptr %t437, i32 0, i32 0
  store i64 10, ptr %t438
  %t439 = load %"compiler/source:Span", ptr %l146
  %t440 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", %"compiler/mir:Place", { i64, [4 x i64] } } undef, %"compiler/source:Span" %t439, 0
  %t441 = load %"compiler/mir:Place", ptr %l153
  %t442 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", %"compiler/mir:Place", { i64, [4 x i64] } } %t440, %"compiler/mir:Place" %t441, 1
  %t444 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", %"compiler/mir:Place", { i64, [4 x i64] } } %t442, %"compiler/mir:Place" %t435, 2
  %t446 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", %"compiler/mir:Place", { i64, [4 x i64] } } %t444, { i64, [4 x i64] } %t436, 3
  %t447 = getelementptr { i64, [21 x i64] }, ptr %t437, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Place", %"compiler/mir:Place", { i64, [4 x i64] } } %t446, ptr %t447
  %t448 = load { i64, [21 x i64] }, ptr %t437
  %t450 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t448, ptr %t450
  %t451 = load ptr, ptr %l145, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %t451, ptr %t450)
  br label %bb41
bb41:
  %t453 = load ptr, ptr %l0, !tbaa !29
  store ptr %t453, ptr %l158, !tbaa !29
  %t454 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t454, ptr %l159
  %t455 = getelementptr %"compiler/lower:collectCtx", ptr %l3, i32 0, i32 0
  %t456 = load i32, ptr %t455, !tbaa !23
  %t458 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t456)
  store %"compiler/mir:Place" %t458, ptr %l161
  br label %bb42
bb42:
  %t459 = load i32, ptr %l13, !tbaa !23
  %t461 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t459)
  store %"compiler/mir:Place" %t461, ptr %l163
  br label %bb43
bb43:
  store { i64, [4 x i64] } zeroinitializer, ptr %t462
  %t463 = getelementptr { i64, [4 x i64] }, ptr %t462, i32 0, i32 0
  store i64 1, ptr %t463
  %t464 = load %"compiler/mir:Place", ptr %l163
  %t465 = insertvalue { %"compiler/mir:Place" } undef, %"compiler/mir:Place" %t464, 0
  %t466 = getelementptr { i64, [4 x i64] }, ptr %t462, i32 0, i32 1
  store { %"compiler/mir:Place" } %t465, ptr %t466
  %t467 = load { i64, [4 x i64] }, ptr %t462
  store { i64, [15 x i64] } zeroinitializer, ptr %t468
  %t469 = getelementptr { i64, [15 x i64] }, ptr %t468, i32 0, i32 0
  store i64 0, ptr %t469
  %t471 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t467, 0
  %t472 = getelementptr { i64, [15 x i64] }, ptr %t468, i32 0, i32 1
  store { { i64, [4 x i64] } } %t471, ptr %t472
  %t473 = load { i64, [15 x i64] }, ptr %t468
  store { i64, [21 x i64] } zeroinitializer, ptr %t474
  %t475 = getelementptr { i64, [21 x i64] }, ptr %t474, i32 0, i32 0
  store i64 0, ptr %t475
  %t476 = load %"compiler/source:Span", ptr %l159
  %t477 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t476, 0
  %t478 = load %"compiler/mir:Place", ptr %l161
  %t479 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t477, %"compiler/mir:Place" %t478, 1
  %t481 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t479, { i64, [15 x i64] } %t473, 2
  %t482 = getelementptr { i64, [21 x i64] }, ptr %t474, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t481, ptr %t482
  %t483 = load { i64, [21 x i64] }, ptr %t474
  %t485 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t483, ptr %t485
  %t486 = load ptr, ptr %l158, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %t486, ptr %t485)
  br label %bb44
bb44:
  %t488 = load ptr, ptr %l0, !tbaa !29
  %t489 = load i32, ptr %l11, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2egoto(ptr %v0, ptr %t488, i32 %t489)
  br label %bb45
bb45:
  %t492 = load ptr, ptr %l0, !tbaa !29
  %t493 = load i32, ptr %l11, !tbaa !23
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %t492, i32 %t493)
  br label %bb46
bb46:
  %t496 = load ptr, ptr %l0, !tbaa !29
  store ptr %t496, ptr %l172, !tbaa !29
  %t497 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t497, ptr %l173
  %t498 = load ptr, ptr %l0, !tbaa !29
  %t500 = getelementptr %"compiler/lower:lowering", ptr %t498, i32 0, i32 3
  %t501 = getelementptr %"compiler/lower:collectCtx", ptr %l3, i32 0, i32 0
  %t502 = load i32, ptr %t501, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t503
  %t504 = getelementptr { i64, [2 x i64] }, ptr %t503, i32 0, i32 0
  store i64 1, ptr %t504
  %t506 = insertvalue { i32 } undef, i32 %t502, 0
  %t507 = getelementptr { i64, [2 x i64] }, ptr %t503, i32 0, i32 1
  store { i32 } %t506, ptr %t507
  %t508 = load { i64, [2 x i64] }, ptr %t503
  store { i64, [1 x i64] } zeroinitializer, ptr %t509
  %t510 = getelementptr { i64, [1 x i64] }, ptr %t509, i32 0, i32 0
  store i64 3, ptr %t510
  %t511 = load { i64, [1 x i64] }, ptr %t509
  %t512 = getelementptr %"compiler/lower:collectCtx", ptr %l3, i32 0, i32 1
  %t513 = load i32, ptr %t512, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t514
  %t515 = getelementptr { i64, [1 x i64] }, ptr %t514, i32 0, i32 0
  store i64 1, ptr %t515
  %t517 = insertvalue { i32 } undef, i32 %t513, 0
  %t518 = getelementptr { i64, [1 x i64] }, ptr %t514, i32 0, i32 1
  store { i32 } %t517, ptr %t518
  %t519 = load { i64, [1 x i64] }, ptr %t514
  %t520 = mul i64 2, 16
  %t521 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t520)
  %t522 = insertvalue { i64, ptr } undef, i64 2, 0
  %t523 = insertvalue { i64, ptr } %t522, ptr %t521, 1
  store { i64, ptr } %t523, ptr %l181, !tbaa !27
  %t525 = getelementptr { i64, ptr }, ptr %l181, i32 0, i32 1
  %t526 = load ptr, ptr %t525, !tbaa !27
  %t527 = getelementptr { i64, [1 x i64] }, ptr %t526, i64 0
  store { i64, [1 x i64] } %t511, ptr %t527
  %t529 = getelementptr { i64, ptr }, ptr %l181, i32 0, i32 1
  %t530 = load ptr, ptr %t529, !tbaa !27
  %t531 = getelementptr { i64, [1 x i64] }, ptr %t530, i64 1
  store { i64, [1 x i64] } %t519, ptr %t531
  %t534 = load { i64, ptr }, ptr %l181, !tbaa !27
  %t535 = call %"compiler/mir:Place" @compiler_2fmir_2ecompiler_2fmir_3aFn_2ePlace(ptr %v0, ptr %s0, ptr %t500, { i64, [2 x i64] } %t508, { i64, ptr } %t534)
  store %"compiler/mir:Place" %t535, ptr %l182
  br label %bb47
bb47:
  %t536 = load { i64, [4 x i64] }, ptr %l4
  store { i64, [15 x i64] } zeroinitializer, ptr %t537
  %t538 = getelementptr { i64, [15 x i64] }, ptr %t537, i32 0, i32 0
  store i64 0, ptr %t538
  %t540 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t536, 0
  %t541 = getelementptr { i64, [15 x i64] }, ptr %t537, i32 0, i32 1
  store { { i64, [4 x i64] } } %t540, ptr %t541
  %t542 = load { i64, [15 x i64] }, ptr %t537
  store { i64, [21 x i64] } zeroinitializer, ptr %t543
  %t544 = getelementptr { i64, [21 x i64] }, ptr %t543, i32 0, i32 0
  store i64 0, ptr %t544
  %t545 = load %"compiler/source:Span", ptr %l173
  %t546 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t545, 0
  %t547 = load %"compiler/mir:Place", ptr %l182
  %t548 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t546, %"compiler/mir:Place" %t547, 1
  %t550 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t548, { i64, [15 x i64] } %t542, 2
  %t551 = getelementptr { i64, [21 x i64] }, ptr %t543, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t550, ptr %t551
  %t552 = load { i64, [21 x i64] }, ptr %t543
  %t554 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t552, ptr %t554
  %t555 = load ptr, ptr %l172, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %t555, ptr %t554)
  br label %bb48
bb48:
  %t557 = load ptr, ptr %l0, !tbaa !29
  store ptr %t557, ptr %l187, !tbaa !29
  %t558 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t558, ptr %l188
  %t559 = getelementptr %"compiler/lower:collectCtx", ptr %l3, i32 0, i32 1
  %t560 = load i32, ptr %t559, !tbaa !23
  %t562 = call %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %t560)
  store %"compiler/mir:Place" %t562, ptr %l190
  br label %bb49
bb49:
  store i32 3, ptr %l191
  %t563 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  store i32 %t563, ptr %l192, !tbaa !23
  %t564 = load ptr, ptr %l0, !tbaa !29
  %t566 = getelementptr %"compiler/lower:lowering", ptr %t564, i32 0, i32 3
  store ptr %t566, ptr %l194, !tbaa !29
  %t567 = load { i64, [4 x i64] }, ptr %l6
  store { i64, [4 x i64] } %t567, ptr %l195
  %t568 = load ptr, ptr %l0, !tbaa !29
  %t570 = call { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2econstI64(ptr %v0, ptr %t568, i64 1)
  store { i64, [4 x i64] } %t570, ptr %l197
  br label %bb50
bb50:
  %t571 = mul i64 2, 40
  %t572 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t571)
  %t573 = insertvalue { i64, ptr } undef, i64 2, 0
  %t574 = insertvalue { i64, ptr } %t573, ptr %t572, 1
  store { i64, ptr } %t574, ptr %l198, !tbaa !27
  %t575 = load { i64, [4 x i64] }, ptr %l195
  %t576 = getelementptr { i64, ptr }, ptr %l198, i32 0, i32 1
  %t577 = load ptr, ptr %t576, !tbaa !27
  %t578 = getelementptr { i64, [4 x i64] }, ptr %t577, i64 0
  store { i64, [4 x i64] } %t575, ptr %t578
  %t579 = load { i64, [4 x i64] }, ptr %l197
  %t580 = getelementptr { i64, ptr }, ptr %l198, i32 0, i32 1
  %t581 = load ptr, ptr %t580, !tbaa !27
  %t582 = getelementptr { i64, [4 x i64] }, ptr %t581, i64 1
  store { i64, [4 x i64] } %t579, ptr %t582
  %t583 = load ptr, ptr %l194, !tbaa !29
  %t584 = load { i64, ptr }, ptr %l198, !tbaa !27
  %t585 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v0, ptr %s0, ptr %t583, { i64, ptr } %t584)
  store %"compiler/mir:Range" %t585, ptr %l199
  br label %bb51
bb51:
  store { i64, [15 x i64] } zeroinitializer, ptr %t586
  %t587 = getelementptr { i64, [15 x i64] }, ptr %t586, i32 0, i32 0
  store i64 3, ptr %t587
  %t588 = load i32, ptr %l191
  %t589 = insertvalue { i32, i32, %"compiler/mir:Range" } undef, i32 %t588, 0
  %t590 = load i32, ptr %l192, !tbaa !23
  %t591 = insertvalue { i32, i32, %"compiler/mir:Range" } %t589, i32 %t590, 1
  %t592 = load %"compiler/mir:Range", ptr %l199
  %t593 = insertvalue { i32, i32, %"compiler/mir:Range" } %t591, %"compiler/mir:Range" %t592, 2
  %t594 = getelementptr { i64, [15 x i64] }, ptr %t586, i32 0, i32 1
  store { i32, i32, %"compiler/mir:Range" } %t593, ptr %t594
  %t595 = load { i64, [15 x i64] }, ptr %t586
  store { i64, [21 x i64] } zeroinitializer, ptr %t596
  %t597 = getelementptr { i64, [21 x i64] }, ptr %t596, i32 0, i32 0
  store i64 0, ptr %t597
  %t598 = load %"compiler/source:Span", ptr %l188
  %t599 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t598, 0
  %t600 = load %"compiler/mir:Place", ptr %l190
  %t601 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t599, %"compiler/mir:Place" %t600, 1
  %t603 = insertvalue { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t601, { i64, [15 x i64] } %t595, 2
  %t604 = getelementptr { i64, [21 x i64] }, ptr %t596, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } } %t603, ptr %t604
  %t605 = load { i64, [21 x i64] }, ptr %t596
  %t607 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t605, ptr %t607
  %t608 = load ptr, ptr %l187, !tbaa !29
  call void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %s0, ptr %t608, ptr %t607)
  br label %bb52
bb52:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flower_2estandIn(ptr %out, ptr %v0, i32 %a0) #0 {
entry:
  %l1 = alloca { i64, [2 x i64] }
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca %"compiler/typed:Body"
  %s0 = alloca %olang.scope
  %t1 = alloca { i64, [2 x i64] }, align 8
  %t8 = alloca %"compiler/typed:Body", align 8
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store { i64, [2 x i64] } zeroinitializer, ptr %t1
  %t2 = getelementptr { i64, [2 x i64] }, ptr %t1, i32 0, i32 0
  store i64 5, ptr %t2
  %t3 = insertvalue { i64 } undef, i64 -1, 0
  %t4 = getelementptr { i64, [2 x i64] }, ptr %t1, i32 0, i32 1
  store { i64 } %t3, ptr %t4
  %t5 = load { i64, [2 x i64] }, ptr %t1
  store { i64, [2 x i64] } %t5, ptr %l1
  store i32 %a0, ptr %l2, !tbaa !23
  %t7 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 0, i32 0)
  store %"compiler/source:Span" %t7, ptr %l3
  br label %bb1
bb1:
  %t9 = load { i64, [2 x i64] }, ptr %l1
  %t10 = load i32, ptr %l2, !tbaa !23
  %t11 = load %"compiler/source:Span", ptr %l3
  call void @compiler_2ftyped_3aBody_2ector(ptr %t8, ptr %v0, i32 -1, { i64, [2 x i64] } %t9, i32 %t10, i64 0, %"compiler/source:Span" %t11)
  call void @llvm.memmove.p0.p0.i64(ptr %l4, ptr %t8, i64 144, i1 false)
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l4, i64 144, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/lower:Gap" @compiler_2flower_3aGap_2ector(ptr %v0, ptr %v1, i64 %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2) #0 {
entry:
  %rv = alloca %"compiler/lower:Gap"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/lower:Gap" undef, i64 %a0, 0
  %t10 = insertvalue %"compiler/lower:Gap" %t8, %"compiler/source:Span" %a1, 1
  %t12 = insertvalue %"compiler/lower:Gap" %t10, { i64, ptr } %a2, 2
  store %"compiler/lower:Gap" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/lower:Gap", ptr %rv
  ret %"compiler/lower:Gap" %rr
}

define dso_local %"compiler/lower:Lowerer" @compiler_2flower_3aLowerer_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l4 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l5 = alloca ptr
  %l6 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l7 = alloca i1
  %l8 = alloca i1
  %l9 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l10 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l11 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l12 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l13 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l14 = alloca i1
  %l15 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l21 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l22 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l23 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l24 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l25 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l26 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l27 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l28 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l29 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"compiler/lower:Lowerer"
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l2, !tbaa !29
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %a1, ptr %l3
  %t5 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t5, ptr %l21
  br label %bb1
bb1:
  %t6 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l21
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t6, ptr %l4
  store ptr null, ptr %l5, !tbaa !29
  %t7 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2flower_3aGap_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t7, ptr %l22
  br label %bb2
bb2:
  %t8 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l22
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t8, ptr %l6
  store i1 false, ptr %l7, !tbaa !21
  store i1 false, ptr %l8, !tbaa !21
  %t9 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e(ptr %v2)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t9, ptr %l23
  br label %bb3
bb3:
  %t10 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l23
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t10, ptr %l9
  %t11 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFnKey_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t11, ptr %l24
  br label %bb4
bb4:
  %t12 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l24
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t12, ptr %l10
  %t13 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e(ptr %v2)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t13, ptr %l25
  br label %bb5
bb5:
  %t14 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l25
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t14, ptr %l11
  %t15 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e(ptr %v2)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t15, ptr %l26
  br label %bb6
bb6:
  %t16 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l26
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t16, ptr %l12
  %t17 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e(ptr %v2)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t17, ptr %l27
  br label %bb7
bb7:
  %t18 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l27
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t18, ptr %l13
  store i1 false, ptr %l14, !tbaa !21
  %t19 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t19, ptr %l28
  br label %bb8
bb8:
  %t20 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l28
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t20, ptr %l15
  %t21 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t21, ptr %l29
  br label %bb9
bb9:
  %t22 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l29
  %t23 = load ptr, ptr %l2, !tbaa !29
  %t24 = insertvalue %"compiler/lower:Lowerer" undef, ptr %t23, 0
  %t25 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l3
  %t26 = insertvalue %"compiler/lower:Lowerer" %t24, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t25, 1
  %t27 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l4
  %t28 = insertvalue %"compiler/lower:Lowerer" %t26, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t27, 2
  %t29 = load ptr, ptr %l5, !tbaa !29
  %t30 = insertvalue %"compiler/lower:Lowerer" %t28, ptr %t29, 3
  %t31 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l6
  %t32 = insertvalue %"compiler/lower:Lowerer" %t30, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t31, 4
  %t33 = load i1, ptr %l7, !tbaa !21
  %t34 = insertvalue %"compiler/lower:Lowerer" %t32, i1 %t33, 5
  %t35 = load i1, ptr %l8, !tbaa !21
  %t36 = insertvalue %"compiler/lower:Lowerer" %t34, i1 %t35, 6
  %t37 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l9
  %t38 = insertvalue %"compiler/lower:Lowerer" %t36, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t37, 7
  %t39 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l10
  %t40 = insertvalue %"compiler/lower:Lowerer" %t38, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t39, 8
  %t41 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l11
  %t42 = insertvalue %"compiler/lower:Lowerer" %t40, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t41, 9
  %t43 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l12
  %t44 = insertvalue %"compiler/lower:Lowerer" %t42, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t43, 10
  %t45 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l13
  %t46 = insertvalue %"compiler/lower:Lowerer" %t44, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t45, 11
  %t47 = load i1, ptr %l14, !tbaa !21
  %t48 = insertvalue %"compiler/lower:Lowerer" %t46, i1 %t47, 12
  %t49 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l15
  %t50 = insertvalue %"compiler/lower:Lowerer" %t48, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t49, 13
  %t52 = insertvalue %"compiler/lower:Lowerer" %t50, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t22, 14
  %t54 = insertvalue %"compiler/lower:Lowerer" %t52, i32 -1, 15
  %t56 = insertvalue %"compiler/lower:Lowerer" %t54, i32 -1, 16
  store %"compiler/lower:Lowerer" %t56, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/lower:Lowerer", ptr %rv
  ret %"compiler/lower:Lowerer" %rr
}

define dso_local void @compiler_2flower_3alowering_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca %"compiler/mir:Fn"
  %l8 = alloca i64
  %l9 = alloca { i64, [4 x i64] }
  %l10 = alloca i32
  %l11 = alloca i1
  %l12 = alloca i1
  %l13 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l14 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l15 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l16 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l17 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l18 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l19 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l20 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l21 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l22 = alloca i1
  %l23 = alloca i1
  %l24 = alloca i32
  %l25 = alloca { i64, [1 x i64] }
  %l26 = alloca %"compiler/typed:Plan"
  %l27 = alloca i1
  %l34 = alloca %"compiler/mir:Fn"
  %l36 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l37 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l38 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l39 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l40 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l41 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l42 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l43 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l44 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l46 = alloca %"compiler/typed:Plan"
  %l47 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l48 = alloca %"compiler/lower:lowering"
  %t9 = alloca { i64, [4 x i64] }, align 8
  %t31 = alloca { i64, [1 x i64] }, align 8
  %t35 = alloca %"compiler/typed:Plan", align 8
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l4, !tbaa !29
  store ptr %a1, ptr %l5, !tbaa !29
  store ptr %a2, ptr %l6, !tbaa !29
  call void @llvm.memmove.p0.p0.i64(ptr %l34, ptr %a3, i64 232, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l7, ptr %l34, i64 232, i1 false)
  store i64 0, ptr %l8, !tbaa !24
  store { i64, [4 x i64] } zeroinitializer, ptr %t9
  %t10 = getelementptr { i64, [4 x i64] }, ptr %t9, i32 0, i32 0
  store i64 0, ptr %t10
  %t11 = load { i64, [4 x i64] }, ptr %t9
  store { i64, [4 x i64] } %t11, ptr %l9
  store i32 0, ptr %l10, !tbaa !23
  store i1 false, ptr %l11, !tbaa !21
  store i1 false, ptr %l12, !tbaa !21
  %t13 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e_2ector(ptr %v4, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t13, ptr %l36
  br label %bb1
bb1:
  %t14 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l36
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t14, ptr %l13
  %t15 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlock_26_3e_2ector(ptr %v4, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t15, ptr %l37
  br label %bb2
bb2:
  %t16 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l37
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t16, ptr %l14
  %t17 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2ector(ptr %v4, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t17, ptr %l38
  br label %bb3
bb3:
  %t18 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l38
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t18, ptr %l15
  %t19 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2flower_3aloopCtx_3e_2ector(ptr %v4, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t19, ptr %l39
  br label %bb4
bb4:
  %t20 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l39
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t20, ptr %l16
  %t21 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2flower_3atryCtx_3e_2ector(ptr %v4, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t21, ptr %l40
  br label %bb5
bb5:
  %t22 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l40
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t22, ptr %l17
  %t23 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2flower_3acollectCtx_3e_2ector(ptr %v4, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t23, ptr %l41
  br label %bb6
bb6:
  %t24 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l41
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t24, ptr %l18
  %t25 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2flower_3apl_3e_2ector(ptr %v4, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t25, ptr %l42
  br label %bb7
bb7:
  %t26 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l42
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t26, ptr %l19
  %t27 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2flower_3atryCtx_3e_2ector(ptr %v4, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t27, ptr %l43
  br label %bb8
bb8:
  %t28 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l43
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t28, ptr %l20
  %t29 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2ector(ptr %v4, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t29, ptr %l44
  br label %bb9
bb9:
  %t30 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l44
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t30, ptr %l21
  store i1 false, ptr %l22, !tbaa !21
  store i1 false, ptr %l23, !tbaa !21
  store i32 -1, ptr %l24, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t31
  %t32 = getelementptr { i64, [1 x i64] }, ptr %t31, i32 0, i32 0
  store i64 2, ptr %t32
  %t33 = load { i64, [1 x i64] }, ptr %t31
  store { i64, [1 x i64] } %t33, ptr %l25
  call void @compiler_2ftyped_3aPlan_2ector(ptr %t35, ptr %v4, i64 0, i64 0, i64 0)
  call void @llvm.memmove.p0.p0.i64(ptr %l46, ptr %t35, i64 152, i1 false)
  br label %bb10
bb10:
  call void @llvm.memmove.p0.p0.i64(ptr %l26, ptr %l46, i64 152, i1 false)
  store i1 false, ptr %l27, !tbaa !21
  %t36 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fmir_3aLocalId_3e(ptr %v4)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t36, ptr %l47
  br label %bb11
bb11:
  %t37 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l47
  %t38 = getelementptr %"compiler/lower:lowering", ptr %l48, i32 0, i32 0
  %t39 = load ptr, ptr %l4, !tbaa !29
  store ptr %t39, ptr %t38, !tbaa !29
  %t40 = getelementptr %"compiler/lower:lowering", ptr %l48, i32 0, i32 1
  %t41 = load ptr, ptr %l5, !tbaa !29
  store ptr %t41, ptr %t40, !tbaa !29
  %t42 = getelementptr %"compiler/lower:lowering", ptr %l48, i32 0, i32 2
  %t43 = load ptr, ptr %l6, !tbaa !29
  store ptr %t43, ptr %t42, !tbaa !29
  %t44 = getelementptr %"compiler/lower:lowering", ptr %l48, i32 0, i32 3
  call void @llvm.memmove.p0.p0.i64(ptr %t44, ptr %l7, i64 232, i1 false)
  %t45 = getelementptr %"compiler/lower:lowering", ptr %l48, i32 0, i32 4
  %t46 = load i64, ptr %l8, !tbaa !24
  store i64 %t46, ptr %t45, !tbaa !24
  %t47 = getelementptr %"compiler/lower:lowering", ptr %l48, i32 0, i32 5
  %t48 = load { i64, [4 x i64] }, ptr %l9
  store { i64, [4 x i64] } %t48, ptr %t47
  %t49 = getelementptr %"compiler/lower:lowering", ptr %l48, i32 0, i32 6
  %t50 = load i32, ptr %l10, !tbaa !23
  store i32 %t50, ptr %t49, !tbaa !23
  %t51 = getelementptr %"compiler/lower:lowering", ptr %l48, i32 0, i32 7
  %t52 = load i1, ptr %l11, !tbaa !21
  store i1 %t52, ptr %t51, !tbaa !21
  %t53 = getelementptr %"compiler/lower:lowering", ptr %l48, i32 0, i32 8
  %t54 = load i1, ptr %l12, !tbaa !21
  store i1 %t54, ptr %t53, !tbaa !21
  %t55 = getelementptr %"compiler/lower:lowering", ptr %l48, i32 0, i32 9
  %t56 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l13
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t56, ptr %t55
  %t57 = getelementptr %"compiler/lower:lowering", ptr %l48, i32 0, i32 10
  %t58 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l14
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t58, ptr %t57
  %t59 = getelementptr %"compiler/lower:lowering", ptr %l48, i32 0, i32 11
  %t60 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l15
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t60, ptr %t59
  %t61 = getelementptr %"compiler/lower:lowering", ptr %l48, i32 0, i32 12
  %t62 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l16
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t62, ptr %t61
  %t63 = getelementptr %"compiler/lower:lowering", ptr %l48, i32 0, i32 13
  %t64 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l17
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t64, ptr %t63
  %t65 = getelementptr %"compiler/lower:lowering", ptr %l48, i32 0, i32 14
  %t66 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l18
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t66, ptr %t65
  %t67 = getelementptr %"compiler/lower:lowering", ptr %l48, i32 0, i32 15
  %t68 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l19
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t68, ptr %t67
  %t69 = getelementptr %"compiler/lower:lowering", ptr %l48, i32 0, i32 16
  %t70 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l20
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t70, ptr %t69
  %t71 = getelementptr %"compiler/lower:lowering", ptr %l48, i32 0, i32 17
  %t72 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l21
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t72, ptr %t71
  %t73 = getelementptr %"compiler/lower:lowering", ptr %l48, i32 0, i32 18
  %t74 = load i1, ptr %l22, !tbaa !21
  store i1 %t74, ptr %t73, !tbaa !21
  %t75 = getelementptr %"compiler/lower:lowering", ptr %l48, i32 0, i32 19
  %t76 = load i1, ptr %l23, !tbaa !21
  store i1 %t76, ptr %t75, !tbaa !21
  %t77 = getelementptr %"compiler/lower:lowering", ptr %l48, i32 0, i32 20
  %t78 = load i32, ptr %l24, !tbaa !23
  store i32 %t78, ptr %t77, !tbaa !23
  %t79 = getelementptr %"compiler/lower:lowering", ptr %l48, i32 0, i32 21
  %t80 = load { i64, [1 x i64] }, ptr %l25
  store { i64, [1 x i64] } %t80, ptr %t79
  %t81 = getelementptr %"compiler/lower:lowering", ptr %l48, i32 0, i32 22
  call void @llvm.memmove.p0.p0.i64(ptr %t81, ptr %l26, i64 152, i1 false)
  %t82 = getelementptr %"compiler/lower:lowering", ptr %l48, i32 0, i32 23
  %t83 = load i1, ptr %l27, !tbaa !21
  store i1 %t83, ptr %t82, !tbaa !21
  %t84 = getelementptr %"compiler/lower:lowering", ptr %l48, i32 0, i32 24
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t37, ptr %t84
  %t86 = getelementptr %"compiler/lower:lowering", ptr %l48, i32 0, i32 25
  store i64 -1, ptr %t86, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l48, i64 584, i1 false)
  br label %ret
ret:
  ret void
}

@.d0 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"std/prelude/array" }>, align 8
@.d1 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"std/prelude/number" }>, align 8
@.d2 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"std/prelude/number" }>, align 8
@.d3 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"std/prelude/enums" }>, align 8
@.d4 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"std/prelude/argument" }>, align 8
@.d5 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"std/prelude/array" }>, align 8
@.d6 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"ArrayError" }>, align 8
@.d7 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"NumberError" }>, align 8
@.d8 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"NumberError" }>, align 8
@.d9 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"CaseError" }>, align 8
@.d10 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"ArgumentError" }>, align 8
@.d11 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"ArrayError" }>, align 8
declare void @__olang_check_failed(ptr)
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d12 = private constant <{ i64, [43 x i8] }> <{ i64 0, [43 x i8] c"an array literal of a type that is no array" }>, align 8
@.d13 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"unhandled error" }>, align 8
@.d14 = private constant <{ i64, [51 x i8] }> <{ i64 0, [51 x i8] c"a comprehension of a type that is no run-time array" }>, align 8
declare void @__olang_ert_req_clear()
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d15 = private constant <{ i64, [33 x i8] }> <{ i64 0, [33 x i8] c"a fill of a type that is no array" }>, align 8
@.d16 = private constant <{ i64, [38 x i8] }> <{ i64 0, [38 x i8] c"a run-time array's fill with no length" }>, align 8
@.d17 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"U8" }>, align 8
@.d18 = private constant <{ i64, [31 x i8] }> <{ i64 0, [31 x i8] c"a yield outside a comprehension" }>, align 8
define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fmir_3aLocalId_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fmir_3aLocalId_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@G_2ecompiler_2flower_2eContract = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2flower_2eEmpty = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2flower_2eFailIds = external constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }>
@G_2ecompiler_2flower_2eFailTypes = external constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }>
@G_2ecompiler_2flower_2eOverflow = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_daa9f23a83841987_24921124063ad36b = external constant [0 x i8]
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e_2e_Hf0a5beca6f8aee4731a76bd327ae0a99(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e_2e_He6968003b8dd5762fa82ec44b4ee1fc9(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, i1 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFnKey_3e_2ePush_3ccompiler_2fmir_3aFnKey_3e(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
declare %"compiler/generic:AnyTable" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aAnyTable_3e_2eAt__He9601a52fe5cfa5abe1b41d520aed001(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2fmir_2eHelperType(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare void @compiler_2flower_2ecompiler_2flower_3aLowerer_2ebare(ptr %out, ptr %v0, ptr %v1, ptr %a0, { i64, [2 x i64] } %a1, i32 %a2)
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare %"compiler/mir:Place" @compiler_2fmir_2eL(i32 %a0)
declare %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2eat(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2ewith(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/lower:pl" %a1, { i64, [1 x i64] } %a2)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2erender(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1, { i64, [4 x i64] } %a2, i32 %a3, %"compiler/source:Span" %a4)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2eepilogue(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v0, ptr %a0)
declare i1 @compiler_2flower_2ecompiler_2flower_3alowering_2evalueArray(ptr %v0, ptr %a0, i32 %a1)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eval(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2ftyped_2eAnyItemNew(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2einto(ptr %v0, ptr %a0, i32 %a1, { i64, [15 x i64] } %a2, %"compiler/source:Span" %a3)
@olang_loc_95894c0b36292ffb_c517f6bdfd218a6f = external constant [0 x i8]
@olang_loc_e6eae32e21930b7a_6f5872ba2e210dae = external constant [0 x i8]
declare { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2evals(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_e4b18f7db400c6ba_98b68b17576d276 = external constant [0 x i8]
@olang_loc_1f81b40d868fb2d4_a735c8b3105ef948 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2efit(ptr %v0, ptr %v1, ptr %a0, { i64, [4 x i64] } %a1, ptr %a2, i32 %a3, %"compiler/source:Span" %a4)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
@G_2ecompiler_2fmir_2eI64T = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\06\00\00\00" }>, align 8
declare i32 @compiler_2flower_2ecompiler_2flower_3alowering_2etemp(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2eemit(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2egap(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2)
declare i64 @compiler_2flower_2ecompiler_2flower_3alowering_2efixedLen(ptr %v0, ptr %a0, i32 %a1)
declare { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2emadeAt(ptr %v0, ptr %a0, i32 %a1)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2econstI64(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/mir:Place" @compiler_2fmir_2ecompiler_2fmir_3aFn_2ePlace(ptr %v0, ptr %v1, ptr %a0, { i64, [2 x i64] } %a1, { i64, ptr } %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eBoolT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
declare i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %a0)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2eend(ptr %v0, ptr %a0, { i64, [8 x i64] } %a1)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2estart(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2egoto(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2ebangNames(ptr %v0, ptr %v1, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2etextData(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, %"compiler/source:Span" %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e_2eLen_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %a0)
declare %"compiler/lower:level" @compiler_2flower_2ecompiler_2flower_3alowering_2etop(ptr %v0, ptr %a0)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/typed:BlockInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockInfo_3e_2eAt_3ccompiler_2ftyped_3aBlockInfo_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_97232cd54c6d63ec_e5d7df8d53aaa998 = external constant [0 x i8]
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ezero(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, i32 %a3)
declare { i64, [4 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2eAt_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_b0754b7649fd7859_91d9947d7b887e0d = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fmir_2ePassedCount(ptr %v0, ptr %a0, { i64, [7 x i64] } %a1, i32 %a2)
declare %"compiler/mir:Range" @compiler_2flower_2ecompiler_2flower_3alowering_2epassed(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
@G_2ecompiler_2fmir_2eNoLocal = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\FF\FF\FF\FF" }>, align 8
@G_2ecompiler_2ftypes_2eVoidT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eNoreturnT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\11\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2fmir_2eNoBlock = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\FF\FF\FF\FF" }>, align 8
@G_2ecompiler_2fmir_2eI32T = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\05\00\00\00" }>, align 8
@G_2ecompiler_2fmir_2eNoPlace = available_externally constant <{ [32 x i8] }> <{ [32 x i8] c"\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00" }>, align 32
declare %"compiler/mir:Call" @compiler_2fmir_3aCall_2ector(ptr %v0, { i64, [7 x i64] } %a0, %"compiler/mir:Range" %a1, %"compiler/mir:Range" %a2, %"compiler/mir:Place" %a3, i1 %a4, i32 %a5, i32 %a6, i32 %a7)
declare i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddCall(ptr %v0, ptr %a0, %"compiler/mir:Call" %a1)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2edispatch(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1, i32 %a2, %"compiler/source:Span" %a3, i1 %a4)
declare { { i64, [7 x i64] }, i32 } @compiler_2flower_2ecompiler_2flower_3alowering_2ebodyCallee(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %a0, i64 %a1)
declare { { i64, [7 x i64] }, i32 } @compiler_2flower_2ecompiler_2flower_3alowering_2evalueCallee(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_21e9da82ebd620c7_b6074e807b9f75fb = external constant [0 x i8]
@G_2ecompiler_2fmir_2eEmpty = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e_2ector(ptr %v0, i64 %a0)
declare { i64, [1 x i64] } @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2ePassed(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e_2ePush_3ccompiler_2fmir_3aScopeRef_3e(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e_2eToArray_3ccompiler_2fmir_3aScopeRef_3e(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eScopeRefs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2flower_2ecompiler_2flower_3alowering_2eitems(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_3b8f4ce72bb8c828_c6f22e3cb9711da4 = external constant [0 x i8]
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2eAt_3ccompiler_2fmir_3aBlockId_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2ePush_3ccompiler_2fmir_3aBlockId_3e(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_ed4966d7257d1cce_314b285230575e82 = external constant [0 x i8]
@olang_loc_4fc14cddf040b63b_d4edc892d8598fd7 = external constant [0 x i8]
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2eleaveOpen(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2eexitLevel(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
@G_2ecompiler_2ftypes_2eWritable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
@olang_loc_162f2c5d450ff5be_60a02040feb29ca2 = external constant [0 x i8]
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2easI64(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1, i32 %a2, %"compiler/source:Span" %a3)
@G_2ecompiler_2flower_2eOutOfBounds = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2echeck(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1, i32 %a2, i32 %a3, i64 %a4, %"compiler/source:Span" %a5)
declare %"compiler/lower:collectCtx" @compiler_2flower_3acollectCtx_2ector(ptr %v0, i32 %a0, i32 %a1, i32 %a2, i32 %a3, { i64, [1 x i64] } %a4, i1 %a5, i1 %a6)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3acollectCtx_3e_2ePus_Hd0ab7b9373bf150d973fdf7c33c4c364(ptr %v0, ptr %a0, %"compiler/lower:collectCtx" %a1)
declare { i32, %"compiler/lower:collectCtx" } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3acollectCtx_3e_2ePop_He1200c0c51a1e2029459d9d8221d233c(ptr %v0, ptr %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2ector(ptr %v0, i64 %a0)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2epatch(ptr %v0, ptr %v1, ptr %a0, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %a1)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2flower_2ecompiler_2flower_3alowering_2ereleases(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i1 %a2)
declare ptr @compiler_2flower_2ecallOfExpr(ptr %v0, ptr %a0)
@olang_loc_190a01ede4622abe_5dffdf8c82030ba2 = external constant [0 x i8]
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eDroppedMove(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_dbd01c2d9a53cc65_a4645b55310f1609 = external constant [0 x i8]
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eIsHandle(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2flower_2eclausedTry(ptr %v0, ptr %a0)
@olang_loc_950864b62af76d08_da7578d9dc40a3d4 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2ePush_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_f1e39541941081b6_a7c200b33b013fba = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2eLen_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %a0)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2ereleaseAt(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2, %"compiler/source:Span" %a3)
@olang_loc_8d285e9a6f8d174e_3f8421b20b21070a = external constant [0 x i8]
@olang_loc_f5af5833f64caf98_602ac3538c074da4 = external constant [0 x i8]
@olang_loc_1e1698b45a1b0cf3_495e2913f4118f47 = external constant [0 x i8]
@olang_loc_4345db1597b95ac6_216be31f80f17832 = external constant [0 x i8]
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLayout(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSize(ptr %v0, ptr %a0, i32 %a1)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eequalAt(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/lower:pl" %a1, %"compiler/lower:pl" %a2, i32 %a3, %"compiler/source:Span" %a4, i1 %a5)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ehashAt(ptr %v0, ptr %v1, ptr %a0, %"compiler/lower:pl" %a1, i32 %a2, %"compiler/source:Span" %a3, i1 %a4)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopeVarsOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2ezeroOf(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, i1 %a3)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2erenderAt(ptr %v0, ptr %v1, ptr %a0, %"compiler/lower:pl" %a1, i32 %a2, { i64, [1 x i64] } %a3, %"compiler/source:Span" %a4, i1 %a5)
@olang_loc_30767a805df234bd_503f920f410b6239 = external constant [0 x i8]
declare i32 @compiler_2flower_2ecompiler_2flower_3aLowerer_2ehelperTy(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eisChar(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eisText(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2flower_2ecompiler_2flower_3alowering_2ehasStr(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/lower:level" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e_2eAt_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2eLen_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0, ptr %a0)
declare { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2eAt_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2flower_2ecompiler_2flower_3alowering_2ejoinErrors(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/lower:tryCtx" @compiler_2flower_3atryCtx_2ector(ptr %v0, ptr %v1, i64 %a0, { i64, ptr } %a1, i1 %a2, i1 %a3)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3atryCtx_3e_2ePush_3ccompiler_2flower_3atryCtx_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/lower:tryCtx" %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2ePush_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %a0, i32 %a1)
declare { i32, %"compiler/lower:tryCtx" } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3atryCtx_3e_2ePop_3ccompiler_2flower_3atryCtx_3e(ptr %v0, ptr %v1, ptr %a0)
declare { i32, i32 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2ePop_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %a0)
@olang_loc_40374e6b733808a6_53e83bc62823fc4a = external constant [0 x i8]
@olang_loc_71c3518922ec6807_c916f3e3052668b = external constant [0 x i8]
declare %"compiler/lower:loopCtx" @compiler_2flower_3aloopCtx_2ector(ptr %v0, i32 %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3aloopCtx_3e_2ePush_3ccompiler_2flower_3aloopCtx_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/lower:loopCtx" %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3aloopCtx_3e_2eLen_3ccompiler_2flower_3aloopCtx_3e(ptr %v0, ptr %a0)
declare %"compiler/lower:loopCtx" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3aloopCtx_3e_2eAt_3ccompiler_2flower_3aloopCtx_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2eLen_3ccompiler_2fmir_3aBlockId_3e(ptr %v0, ptr %a0)
declare { i32, %"compiler/lower:loopCtx" } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3aloopCtx_3e_2ePop_3ccompiler_2flower_3aloopCtx_3e(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e_2eToArray_3ccompiler_2fmir_3aProj_3e(ptr %v0, ptr %v1, ptr %a0)
declare i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddScope(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i32 %a3, %"compiler/source:Span" %a4, i32 %a5)
declare %"compiler/lower:level" @compiler_2flower_3alevel_2ector(ptr %v0, i32 %a0, i32 %a1, i32 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e_2ePush_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %a0, %"compiler/lower:level" %a1)
declare %"compiler/lower:pl" @compiler_2flower_2ecompiler_2flower_3alowering_2eplace(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
@G_2ecompiler_2ftypes_2eReadOnly = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@olang_loc_eff9370fb6cf39b1_ff4f9c232720af7d = external constant [0 x i8]
@olang_loc_4fc653f117519a1d_d526ff90513f5371 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eLen_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eAt_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i32, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlock_26_3e_2ePop_3ccompiler_2ftyped_3aBlock_26_3e(ptr %v0, ptr %v1, ptr %a0)
declare { i32, %"compiler/lower:level" } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e_2ePop_3ccompiler_2flower_3alevel_3e(ptr %v0, ptr %a0)
@G_2ecompiler_2flower_2eInvalid = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2efails(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1, i32 %a2, i32 %a3, i64 %a4, %"compiler/source:Span" %a5)
@olang_loc_13d147f9f542fef2_ebbeb5a175072836 = external constant [0 x i8]
declare i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddParam(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, i32 %a3)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aVarKind_3e_2ePush_3ccompiler_2fmir_3aVarKind_3e(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1)
@G_2ecompiler_2fmir_2eNoScope = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\FF\FF\FF\FF" }>, align 8
@olang_loc_5f06e436ba25f30_8078c3a4dcac4c4 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2flower_3alevel_3e_2ector(ptr %v0, i64 %a0)
@olang_loc_3ef62952ecee62f3_777b4c56ce2caf3f = external constant [0 x i8]
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlock_26_3e_2eLen_3ccompiler_2ftyped_3aBlock_26_3e(ptr %v0, ptr %a0)
declare i1 @compiler_2flower_2ecompiler_2flower_3alowering_2eonError(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2eSetAt_3ccompiler_2fmir_3aScopeId_3e(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlock_26_3e_2eAt_3ccompiler_2ftyped_3aBlock_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_de8dc91cd31c6e72_d86f27d9b5b5bc3e = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNumber(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eEncloses(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare { i64, [1 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eregionOf(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_a3e3ce1f266a1e3a_904ea2ee4ca5797e = external constant [0 x i8]
declare %"compiler/mir:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2eretArrays(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, ptr %a3, %"compiler/source:Span" %a4)
@olang_loc_c2ea6282af4907c_77e331cc54ab44a0 = external constant [0 x i8]
declare { i64, [4 x i64] } @compiler_2flower_2ecompiler_2flower_3alowering_2eread(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3)
@olang_loc_3b3f675a7fcfa09e_a6d8609e08455d8a = external constant [0 x i8]
@olang_loc_a39e67f1cd7c0b1f_e499cc399c2ba1cb = external constant [0 x i8]
declare void @compiler_2flower_2ecompiler_2flower_3alowering_2eleave(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBlockId_3e_2eSetAt_3ccompiler_2fmir_3aBlockId_3e(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
@olang_loc_683e5e170631bc0e_4d1425fdf2d9aa22 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddConst(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3acollectCtx_3e_2eLen_H6eade83fd48a7a0e84be67fdfc468e69(ptr %v0, ptr %a0)
declare %"compiler/lower:collectCtx" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3acollectCtx_3e_2eAt__Hce97d3b6a95327627873f207e844a422(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2ftyped_3aBody_2ector(ptr %out, ptr %v0, i32 %a0, { i64, [2 x i64] } %a1, i32 %a2, i64 %a3, %"compiler/source:Span" %a4)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2flower_3aGap_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFnKey_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlock_26_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeId_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2flower_3aloopCtx_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2flower_3atryCtx_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2flower_3acollectCtx_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2flower_3apl_3e_2ector(ptr %v0, i64 %a0)
declare void @compiler_2ftyped_3aPlan_2ector(ptr %out, ptr %v0, i64 %a0, i64 %a1, i64 %a2)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fmir_3aLocalId_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
