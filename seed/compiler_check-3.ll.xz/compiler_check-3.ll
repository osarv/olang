; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/source:Span" = type { i32, i32 }
%"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" = type { i64, i64 }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"compiler/check:Checker" = type { ptr, ptr, i1, i1, i1, i1, i64, i64, i1, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, { i64, [3 x i64] }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i32, i64, %"compiler/source:Span", i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/source:Span", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i64, i32, i1, i1, %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, i32, i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64, i64, i64, i64, i64, i64, i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/text:StringBuilder", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/types:Table" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64 }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i32, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/generic:AnySlot" = type { i32, i32, i64, i64, i1, i32 }
%"compiler/msgs:Msg" = type { i32, { i64, ptr }, { i64, ptr } }
%"compiler/msgs:Nearest" = type { { i64, ptr }, { i64, ptr }, i64 }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1, i1, { i64, ptr } }
%"compiler/ast:Sig" = type { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, i1, ptr, i1, i1 }
%"compiler/check:frame" = type { i64, i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/generic:Context", i32, i32, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i32, i64, i64, i64, i1, i64, i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, i64, i64, i64, i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/source:Span", i64, i1 }
%"compiler/generic:Context" = type { i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, ptr, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/source:Source" = type { { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/names:Ref" = type { i32, i64, i64 }
%"compiler/ast:Branch" = type { %"compiler/source:Span", { i64, ptr }, i64 }
%"compiler/ast:If" = type { ptr, ptr, ptr }
%"compiler/ast:Match" = type { %"compiler/source:Span", ptr, i1, { i64, ptr } }
%"compiler/ast:Case" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, ptr }
%"compiler/check:errBind" = type { i32, i64, i32, %"compiler/source:Span" }
%"compiler/typed:Cond" = type { ptr, ptr, ptr }
%"compiler/typed:Item" = type { i32, i64 }
%"compiler/typed:Clause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr, { i64, ptr }, i64, i32 }
%"compiler/ast:Catch" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i32, %"compiler/source:Span" }
%"compiler/typed:Block" = type { i32, { i64, ptr } }
%"compiler/check:ContractAsk" = type { i64, i64, %"compiler/source:Span", i64, %"compiler/source:Span", { i64, ptr }, { i64, ptr }, { i64, [3 x i64] }, { i64, ptr }, { i64, ptr } }
%"compiler/ast:Path" = type { %"compiler/source:Span", { i64, ptr } }
%"compiler/ast:Param" = type { %"compiler/source:Span", i32, ptr, ptr, { i64, ptr } }
%"compiler/check:opShape" = type { { i64, ptr }, i64, i1, i1 }
%"compiler/ast:For3" = type { ptr, ptr, ptr, { i64, ptr } }
%"compiler/check:laneNode" = type { i64, i32, %"compiler/source:Span", %"compiler/source:Span", i64, i64, i64, ptr, i32, i64, i32 }
%"compiler/generic:Binding" = type { i64, i64, { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/typed:Seq" = type { { i64, ptr }, ptr }
%"compiler/typed:Local" = type { i32, %"compiler/source:Span", i32, i32, i32, { i64, [2 x i64] }, i1 }
%"compiler/ast:VarDecl" = type { { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, i1, i1, { i64, ptr }, i1 }
%"compiler/typed:Elem" = type { ptr, ptr, i32 }
%"compiler/typed:Payload" = type { ptr, i64, i32 }
%"compiler/check:reflVal" = type { i1, i64, i64, { i64, ptr }, i32 }
%"compiler/typed:Call" = type { ptr, { i64, ptr }, { i64, [2 x i64] }, i32, i1, i1 }
%"compiler/typed:Match" = type { { i64, ptr }, { i64, ptr }, ptr, i1 }
%"compiler/typed:Arm" = type { %"compiler/source:Span", { i64, ptr }, ptr, ptr, ptr }
%"compiler/check:roOrigin" = type { ptr, i1 }
%"compiler/typed:Slice" = type { ptr, ptr, ptr, i32 }
%"compiler/check:elemsShape" = type { { i64, ptr }, i64 }
%"compiler/check:TopAssertAsk" = type { i64, %"compiler/source:Span", %"compiler/source:Span", i64, i64 }
%"compiler/ast:TopIf" = type { ptr, ptr, ptr, ptr }
%"compiler/ast:TypeDecl" = type { i32, { i64, ptr }, i1, ptr, { i64, ptr } }
%"compiler/ast:ForIn" = type { i32, i32, ptr, i1, { i64, ptr }, { i64, ptr }, i1 }
%"compiler/check:narrowed" = type { i64, i64, i32, i64, i64, i1 }
%"compiler/check:litv" = type { i1, i1, i1, i64, double, i1, i1, i1, i128 }
%"compiler/typed:If" = type { ptr, ptr, ptr }
%"compiler/typed:Join" = type { ptr, i1, { i64, ptr } }
%"compiler/ast:Chain" = type { { i64, ptr }, { i64, ptr } }
%"compiler/ast:Compr" = type { ptr, ptr, i32, i32, ptr, ptr, i1, i64 }
%"compiler/ast:Multi" = type { { i64, ptr }, i1, { i64, ptr } }
%"compiler/ast:JoinS" = type { i1, { i64, ptr }, { i64, ptr } }
%"compiler/check:tailAsk" = type { i64, i64, %"compiler/source:Span", i64 }
define dso_local i1 @compiler_2fcheck_2eassignsAll(ptr %v0, { i64, ptr } %a0, i32 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l19 = alloca { i64, ptr }
  %l22 = alloca ptr
  %l23 = alloca i1
  %l29 = alloca i32
  %l33 = alloca ptr
  %l34 = alloca i1
  %l41 = alloca i1
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t8, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t14 = load i64, ptr %l3, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb34
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t22, ptr %l19, !tbaa !27
  %t23 = load i64, ptr %l3, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  store ptr %t28, ptr %l5, !tbaa !29
  %t30 = load ptr, ptr %l5, !tbaa !29
  store ptr %t30, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t31 = load ptr, ptr %l22, !tbaa !29
  %t32 = icmp ne ptr %t31, null
  br i1 %t32, label %bb8, label %bb9
bb8:
  %t34 = load ptr, ptr %l22, !tbaa !29
  %t35 = load i64, ptr %t34, !range !{i64 0, i64 11}
  %t37 = icmp eq i64 %t35, 8
  store i1 %t37, ptr %l23, !tbaa !21
  br label %bb9
bb9:
  %t38 = load i1, ptr %l23, !tbaa !21
  br i1 %t38, label %bb10, label %bb11
bb10:
  %t39 = load ptr, ptr %l5, !tbaa !29
  %t41 = getelementptr { i64, [6 x i64] }, ptr %t39, i32 0, i32 1
  %t42 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t41, i32 0, i32 1
  %t43 = load ptr, ptr %t42
  store ptr %t43, ptr %l6, !tbaa !29
  br label %bb12
bb11:
  br label %bb17
bb12:
  %t45 = load ptr, ptr %l6, !tbaa !29
  %t47 = call i32 @compiler_2fcheck_2esetName(ptr %v0, ptr %t45)
  store i32 %t47, ptr %l29
  br label %bb13
bb13:
  %t48 = load i32, ptr %l1, !tbaa !23
  %t49 = load i32, ptr %l29, !tbaa !23
  %t51 = icmp eq i32 %t49, %t48
  br i1 %t51, label %bb14, label %bb15
bb14:
  store i1 true, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  br label %bb32
bb17:
  %t54 = load ptr, ptr %l5, !tbaa !29
  store ptr %t54, ptr %l33, !tbaa !29
  store i1 false, ptr %l34, !tbaa !21
  %t55 = load ptr, ptr %l33, !tbaa !29
  %t56 = icmp ne ptr %t55, null
  br i1 %t56, label %bb18, label %bb19
bb18:
  %t58 = load ptr, ptr %l33, !tbaa !29
  %t59 = load i64, ptr %t58, !range !{i64 0, i64 11}
  %t61 = icmp eq i64 %t59, 7
  store i1 %t61, ptr %l34, !tbaa !21
  br label %bb19
bb19:
  %t62 = load i1, ptr %l34, !tbaa !21
  br i1 %t62, label %bb20, label %bb21
bb20:
  %t63 = load ptr, ptr %l5, !tbaa !29
  %t65 = getelementptr { i64, [6 x i64] }, ptr %t63, i32 0, i32 1
  %t66 = getelementptr { %"compiler/source:Span", ptr }, ptr %t65, i32 0, i32 1
  %t67 = load ptr, ptr %t66
  store ptr %t67, ptr %l7, !tbaa !29
  br label %bb22
bb21:
  br label %bb27
bb22:
  %t69 = load ptr, ptr %l7, !tbaa !29
  %t70 = load i32, ptr %l1, !tbaa !23
  %t73 = call i1 @compiler_2fcheck_2echainAssignsAll(ptr %v0, ptr %t69, i32 %t70)
  store i1 %t73, ptr %l41
  br label %bb23
bb23:
  %t74 = load i1, ptr %l41, !tbaa !21
  br i1 %t74, label %bb24, label %bb25
bb24:
  store i1 true, ptr %rv
  br label %ret
bb25:
  br label %bb26
bb26:
  br label %bb32
bb27:
  br i1 true, label %bb28, label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  call void @__olang_check_failed(ptr @olang_loc_fcbb335a6871d594_96c5adf6eb865188)
  unreachable
bb32:
  br label %bb33
bb33:
  %t76 = load i64, ptr %l3, !tbaa !24
  %t78 = add i64 %t76, 1
  store i64 %t78, ptr %l3, !tbaa !24
  br label %bb4
bb34:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ebangOf(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i8
  %l13 = alloca { i64, ptr }
  %l18 = alloca i1
  %l25 = alloca i1
  %l32 = alloca i1
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb24
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t15, ptr %l13, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr i8, ptr %t19, i64 %t16
  %t21 = load i8, ptr %t20, !tbaa !32
  store i8 %t21, ptr %l5, !tbaa !22
  %t23 = load i8, ptr %l5, !tbaa !22
  %t25 = icmp eq i8 %t23, 40
  br i1 %t25, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb7
bb6:
  %t27 = load i8, ptr %l5, !tbaa !22
  %t29 = icmp eq i8 %t27, 91
  store i1 %t29, ptr %l18, !tbaa !21
  br label %bb7
bb7:
  %t31 = load i1, ptr %l18, !tbaa !21
  br i1 %t31, label %bb8, label %bb9
bb8:
  %t32 = load i64, ptr %l1, !tbaa !24
  %t34 = add i64 %t32, 1
  store i64 %t34, ptr %l1, !tbaa !24
  br label %bb10
bb9:
  br label %bb10
bb10:
  %t36 = load i8, ptr %l5, !tbaa !22
  %t38 = icmp eq i8 %t36, 41
  br i1 %t38, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l25, !tbaa !21
  br label %bb13
bb12:
  %t40 = load i8, ptr %l5, !tbaa !22
  %t42 = icmp eq i8 %t40, 93
  store i1 %t42, ptr %l25, !tbaa !21
  br label %bb13
bb13:
  %t44 = load i1, ptr %l25, !tbaa !21
  br i1 %t44, label %bb14, label %bb15
bb14:
  %t45 = load i64, ptr %l1, !tbaa !24
  %t47 = sub i64 %t45, 1
  store i64 %t47, ptr %l1, !tbaa !24
  br label %bb16
bb15:
  br label %bb16
bb16:
  %t49 = load i8, ptr %l5, !tbaa !22
  %t51 = icmp eq i8 %t49, 32
  br i1 %t51, label %bb17, label %bb18
bb17:
  %t53 = load i64, ptr %l1, !tbaa !24
  %t55 = icmp eq i64 %t53, 0
  store i1 %t55, ptr %l32, !tbaa !21
  br label %bb19
bb18:
  store i1 false, ptr %l32, !tbaa !21
  br label %bb19
bb19:
  %t57 = load i1, ptr %l32, !tbaa !21
  br i1 %t57, label %bb20, label %bb21
bb20:
  %t58 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t59 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d0, i32 0, i32 1) }, 1
  %t60 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d0, i32 0, i32 1) }, 0
  %t62 = extractvalue { i64, ptr } %t58, 1
  %t63 = extractvalue { i64, ptr } %t58, 0
  %t64 = add i64 %t60, %t63
  %t65 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d1, i32 0, i32 1) }, 1
  %t66 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d1, i32 0, i32 1) }, 0
  %t67 = add i64 %t64, %t66
  %t68 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t67)
  call void @olang_textcopy(ptr %t68, ptr %t59, i64 %t60)
  %t69 = getelementptr i8, ptr %t68, i64 %t60
  call void @olang_textcopy(ptr %t69, ptr %t62, i64 %t63)
  %t70 = getelementptr i8, ptr %t69, i64 %t63
  call void @olang_textcopy(ptr %t70, ptr %t65, i64 %t66)
  %t71 = insertvalue { i64, ptr } undef, i64 %t67, 0
  %t72 = insertvalue { i64, ptr } %t71, ptr %t68, 1
  store { i64, ptr } %t72, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  br label %bb23
bb23:
  %t74 = load i64, ptr %l3, !tbaa !24
  %t76 = add i64 %t74, 1
  store i64 %t76, ptr %l3, !tbaa !24
  br label %bb1
bb24:
  %t78 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t80 = extractvalue { i64, ptr } %t78, 1
  %t81 = extractvalue { i64, ptr } %t78, 0
  %t82 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t81)
  call void @olang_textcopy(ptr %t82, ptr %t80, i64 %t81)
  %t83 = insertvalue { i64, ptr } undef, i64 %t81, 0
  %t84 = insertvalue { i64, ptr } %t83, ptr %t82, 1
  store { i64, ptr } %t84, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2fcheck_2ebinaryOp(i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca i32
  %rv = alloca i32
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t3 = trunc i64 52 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  store i32 3, ptr %l1
  br label %bb71
bb4:
  %t7 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t9 = trunc i64 53 to i32
  %t10 = icmp eq i32 %t7, %t9
  br i1 %t10, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store i32 4, ptr %l1
  br label %bb71
bb8:
  %t13 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t15 = trunc i64 54 to i32
  %t16 = icmp eq i32 %t13, %t15
  br i1 %t16, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store i32 5, ptr %l1
  br label %bb71
bb12:
  %t19 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t21 = trunc i64 56 to i32
  %t22 = icmp eq i32 %t19, %t21
  br i1 %t22, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store i32 6, ptr %l1
  br label %bb71
bb16:
  %t25 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t27 = trunc i64 57 to i32
  %t28 = icmp eq i32 %t25, %t27
  br i1 %t28, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  store i32 7, ptr %l1
  br label %bb71
bb20:
  %t31 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t33 = trunc i64 90 to i32
  %t34 = icmp eq i32 %t31, %t33
  br i1 %t34, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  store i32 8, ptr %l1
  br label %bb71
bb24:
  %t37 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t39 = trunc i64 91 to i32
  %t40 = icmp eq i32 %t37, %t39
  br i1 %t40, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  store i32 9, ptr %l1
  br label %bb71
bb28:
  %t43 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t45 = trunc i64 85 to i32
  %t46 = icmp eq i32 %t43, %t45
  br i1 %t46, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  store i32 10, ptr %l1
  br label %bb71
bb32:
  %t49 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t51 = trunc i64 86 to i32
  %t52 = icmp eq i32 %t49, %t51
  br i1 %t52, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb36
bb35:
  store i32 11, ptr %l1
  br label %bb71
bb36:
  %t55 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t57 = trunc i64 87 to i32
  %t58 = icmp eq i32 %t55, %t57
  br i1 %t58, label %bb37, label %bb38
bb37:
  br label %bb41
bb38:
  %t60 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t62 = trunc i64 47 to i32
  %t63 = icmp eq i32 %t60, %t62
  br i1 %t63, label %bb39, label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb42
bb41:
  store i32 12, ptr %l1
  br label %bb71
bb42:
  %t66 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t68 = trunc i64 78 to i32
  %t69 = icmp eq i32 %t66, %t68
  br i1 %t69, label %bb43, label %bb44
bb43:
  br label %bb45
bb44:
  br label %bb46
bb45:
  store i32 13, ptr %l1
  br label %bb71
bb46:
  %t72 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t74 = trunc i64 79 to i32
  %t75 = icmp eq i32 %t72, %t74
  br i1 %t75, label %bb47, label %bb48
bb47:
  br label %bb49
bb48:
  br label %bb50
bb49:
  store i32 14, ptr %l1
  br label %bb71
bb50:
  %t78 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t80 = trunc i64 81 to i32
  %t81 = icmp eq i32 %t78, %t80
  br i1 %t81, label %bb51, label %bb52
bb51:
  br label %bb53
bb52:
  br label %bb54
bb53:
  store i32 15, ptr %l1
  br label %bb71
bb54:
  %t84 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t86 = trunc i64 82 to i32
  %t87 = icmp eq i32 %t84, %t86
  br i1 %t87, label %bb55, label %bb56
bb55:
  br label %bb57
bb56:
  br label %bb58
bb57:
  store i32 16, ptr %l1
  br label %bb71
bb58:
  %t90 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t92 = trunc i64 83 to i32
  %t93 = icmp eq i32 %t90, %t92
  br i1 %t93, label %bb59, label %bb60
bb59:
  br label %bb61
bb60:
  br label %bb62
bb61:
  store i32 17, ptr %l1
  br label %bb71
bb62:
  %t96 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t98 = trunc i64 84 to i32
  %t99 = icmp eq i32 %t96, %t98
  br i1 %t99, label %bb63, label %bb64
bb63:
  br label %bb65
bb64:
  br label %bb66
bb65:
  store i32 18, ptr %l1
  br label %bb71
bb66:
  br i1 true, label %bb67, label %bb68
bb67:
  br label %bb69
bb68:
  br label %bb70
bb69:
  store i32 3, ptr %l1
  br label %bb71
bb70:
  call void @__olang_check_failed(ptr @olang_loc_b418a15f1455a8e1_40cdd11b1c753e15)
  unreachable
bb71:
  %t103 = load i32, ptr %l1, !range !{i32 0, i32 43}
  store i32 %t103, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fcheck_2ecommutative(i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l3 = alloca i1
  %l6 = alloca i1
  %l9 = alloca i1
  %l12 = alloca i1
  %rv = alloca i1
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t3 = trunc i64 52 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb3
bb2:
  %t6 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t8 = trunc i64 54 to i32
  %t9 = icmp eq i32 %t6, %t8
  store i1 %t9, ptr %l3, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l3, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb6
bb5:
  %t12 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t14 = trunc i64 85 to i32
  %t15 = icmp eq i32 %t12, %t14
  store i1 %t15, ptr %l6, !tbaa !21
  br label %bb6
bb6:
  %t17 = load i1, ptr %l6, !tbaa !21
  br i1 %t17, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb9
bb8:
  %t18 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t20 = trunc i64 86 to i32
  %t21 = icmp eq i32 %t18, %t20
  store i1 %t21, ptr %l9, !tbaa !21
  br label %bb9
bb9:
  %t23 = load i1, ptr %l9, !tbaa !21
  br i1 %t23, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb12
bb11:
  %t24 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t26 = trunc i64 87 to i32
  %t27 = icmp eq i32 %t24, %t26
  store i1 %t27, ptr %l12, !tbaa !21
  br label %bb12
bb12:
  %t29 = load i1, ptr %l12, !tbaa !21
  store i1 %t29, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eCheckProgram(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i1
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l12 = alloca i1
  %l17 = alloca i64
  %l21 = alloca i64
  %l24 = alloca i64
  %l45 = alloca i32
  %l51 = alloca ptr
  %l56 = alloca i64
  %l57 = alloca ptr
  %l64 = alloca i64
  %l72 = alloca i64
  %l74 = alloca i64
  %l79 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l82 = alloca ptr
  %l83 = alloca i32
  %l87 = alloca i32
  %l88 = alloca i32
  %l89 = alloca { i64, ptr }
  %l96 = alloca i1
  %l99 = alloca i1
  %l102 = alloca i1
  %l113 = alloca ptr
  %l115 = alloca i1
  %l116 = alloca { i64, ptr }
  %l117 = alloca { i64, ptr }
  %l118 = alloca i32
  %l119 = alloca { i64, ptr }
  %l122 = alloca i1
  %l130 = alloca ptr
  %l132 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l134 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %s7 = alloca %olang.scope
  %s10 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAllFns(ptr %v0, ptr %t4)
  br label %bb1
bb1:
  store i64 0, ptr %l1, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnCount(ptr %v0, ptr %t9)
  store i64 %t11, ptr %l17
  br label %bb2
bb2:
  %t12 = load i64, ptr %l17, !tbaa !24
  store i64 %t12, ptr %l2, !tbaa !24
  store i64 1, ptr %l3, !tbaa !24
  %t13 = load i64, ptr %l2, !tbaa !24
  %t14 = load i64, ptr %l1, !tbaa !24
  %t17 = icmp sgt i64 %t13, %t14
  br i1 %t17, label %bb3, label %bb4
bb3:
  %t19 = load i64, ptr %l3, !tbaa !24
  %t21 = icmp sgt i64 %t19, 0
  br i1 %t21, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l21, !tbaa !24
  br label %bb8
bb5:
  %t23 = load i64, ptr %l2, !tbaa !24
  %t24 = load i64, ptr %l1, !tbaa !24
  %t27 = sub i64 %t23, %t24
  %t28 = load i64, ptr %l3, !tbaa !24
  %t31 = add i64 %t27, %t28
  %t33 = sub i64 %t31, 1
  %t34 = load i64, ptr %l3, !tbaa !24
  %t37 = sdiv i64 %t33, %t34
  store i64 %t37, ptr %l24, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l24, !tbaa !24
  br label %bb7
bb7:
  %t39 = load i64, ptr %l24, !tbaa !24
  store i64 %t39, ptr %l21, !tbaa !24
  br label %bb8
bb8:
  %t40 = load i64, ptr %l21, !tbaa !24
  store i64 %t40, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb9
bb9:
  %t41 = load i64, ptr %l5, !tbaa !24
  %t42 = load i64, ptr %l4, !tbaa !24
  %t45 = icmp slt i64 %t41, %t42
  %t47 = xor i1 %t45, true
  br i1 %t47, label %bb10, label %bb11
bb10:
  br label %bb15
bb11:
  br label %bb12
bb12:
  %t49 = load i64, ptr %l1, !tbaa !24
  %t50 = load i64, ptr %l5, !tbaa !24
  %t51 = load i64, ptr %l3, !tbaa !24
  %t54 = mul i64 %t50, %t51
  %t57 = add i64 %t49, %t54
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/check:Checker", ptr %t59, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t66 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t62, i64 %t57)
  store i32 %t66, ptr %l45
  br label %bb13
bb13:
  br label %bb14
bb14:
  %t67 = load i64, ptr %l5, !tbaa !24
  %t69 = add i64 %t67, 1
  store i64 %t69, ptr %l5, !tbaa !24
  br label %bb9
bb15:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/check:Checker", ptr %t71, i32 0, i32 84
  %t74 = load i64, ptr %t73, !tbaa !24
  %t76 = icmp slt i64 %t74, 0
  br i1 %t76, label %bb16, label %bb17
bb16:
  %t78 = load ptr, ptr %l0, !tbaa !29
  store ptr %t78, ptr %l51, !tbaa !29
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/check:Checker", ptr %t79, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t84 = getelementptr %"compiler/generic:Program", ptr %t82, i32 0, i32 0
  %t85 = load ptr, ptr %t84, !tbaa !29
  %t87 = getelementptr %"compiler/load:Loader", ptr %t85, i32 0, i32 4
  %t88 = load ptr, ptr %t87, !tbaa !29
  %t90 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eRecordCount(ptr %v0, ptr %t88)
  store i64 %t90, ptr %l56
  br label %bb18
bb17:
  br label %bb19
bb18:
  %t91 = load i64, ptr %l56, !tbaa !24
  %t92 = load ptr, ptr %l51, !tbaa !29
  %t93 = getelementptr %"compiler/check:Checker", ptr %t92, i32 0, i32 84
  store i64 %t91, ptr %t93, !tbaa !24
  br label %bb19
bb19:
  br label %bb20
bb20:
  %t94 = load ptr, ptr %l0, !tbaa !29
  store ptr %t94, ptr %l57, !tbaa !29
  %t95 = load ptr, ptr %l57, !tbaa !29
  %t96 = getelementptr %"compiler/check:Checker", ptr %t95, i32 0, i32 62
  %t97 = load i64, ptr %t96, !tbaa !24
  %t99 = add i64 %t97, 1
  %t101 = load ptr, ptr %l57, !tbaa !29
  %t102 = getelementptr %"compiler/check:Checker", ptr %t101, i32 0, i32 62
  store i64 %t99, ptr %t102, !tbaa !24
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t105 = getelementptr %"compiler/check:Checker", ptr %t103, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !29
  %t108 = getelementptr %"compiler/generic:Program", ptr %t106, i32 0, i32 0
  %t109 = load ptr, ptr %t108, !tbaa !29
  %t111 = getelementptr %"compiler/load:Loader", ptr %t109, i32 0, i32 4
  %t112 = load ptr, ptr %t111, !tbaa !29
  %t114 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCount(ptr %v0, ptr %t112)
  store i64 %t114, ptr %l64
  br label %bb21
bb21:
  %t115 = load i64, ptr %l64, !tbaa !24
  store i64 %t115, ptr %l7, !tbaa !24
  %t116 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eattempt(ptr %v0, ptr %t116)
  br label %bb22
bb22:
  %t118 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esettleUnset(ptr %v0, ptr %t118)
  br label %bb23
bb23:
  %t120 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esettleHeldWalks(ptr %v0, ptr %t120)
  br label %bb24
bb24:
  %t122 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esettleIdle(ptr %v0, ptr %t122)
  br label %bb25
bb25:
  %t124 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esettleUnread(ptr %v0, ptr %t124)
  br label %bb26
bb26:
  store i1 false, ptr %l8, !tbaa !21
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t128 = getelementptr %"compiler/check:Checker", ptr %t126, i32 0, i32 56
  store ptr %t128, ptr %l9, !tbaa !29
  store i64 0, ptr %l10, !tbaa !24
  br label %bb27
bb27:
  store %olang.scope zeroinitializer, ptr %s7
  %t130 = load i64, ptr %l10, !tbaa !24
  store i64 %t130, ptr %l72, !tbaa !24
  %t131 = load ptr, ptr %l9, !tbaa !29
  %t133 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_3e_Hda4ef06466535e66801340e999dad217(ptr %v0, ptr %t131)
  store i64 %t133, ptr %l74
  br label %bb28
bb28:
  %t134 = load i64, ptr %l72, !tbaa !24
  %t135 = load i64, ptr %l74, !tbaa !24
  %t136 = icmp slt i64 %t134, %t135
  %t138 = xor i1 %t136, true
  br i1 %t138, label %bb29, label %bb30
bb29:
  call void @__olang_scope_close(ptr %s7)
  br label %bb42
bb30:
  br label %bb31
bb31:
  %t140 = load ptr, ptr %l9, !tbaa !29
  %t141 = load i64, ptr %l10, !tbaa !24
  %t144 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_3e_H87a29777ccf22aa2985fa9d3c61f9cd3(ptr %v0, ptr %t140, i64 %t141)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t144, ptr %l79
  br label %bb32
bb32:
  %t145 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l79
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t145, ptr %l11
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t148 = getelementptr %"compiler/check:Checker", ptr %t146, i32 0, i32 1
  %t149 = load ptr, ptr %t148, !tbaa !29
  %t151 = getelementptr %"compiler/generic:Program", ptr %t149, i32 0, i32 2
  store ptr %t151, ptr %l82, !tbaa !29
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t154 = getelementptr %"compiler/check:Checker", ptr %t152, i32 0, i32 55
  %t155 = getelementptr %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l11, i32 0, i32 0
  %t156 = load i64, ptr %t155, !tbaa !24
  %t159 = call { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftypes_3aListId_3e__H9cb5d99387f926677a92c13412f9a8b2(ptr %v0, ptr %t154, i64 %t156)
  %t160 = extractvalue { i32, i32 } %t159, 1
  %t161 = extractvalue { i32, i32 } %t159, 0
  store i32 %t161, ptr %l88
  %t162 = icmp ne i32 %t161, 0
  br i1 %t162, label %bb34, label %ok.163, !prof !99
ok.163:
  store i32 %t160, ptr %l87
  br label %bb33
bb33:
  %t164 = load i32, ptr %l87, !tbaa !23
  store i32 %t164, ptr %l83, !tbaa !23
  br label %bb36
bb34:
  br label %bb35
bb35:
  call void @__olang_ert_req_clear()
  store i32 0, ptr %l83, !tbaa !23
  br label %bb36
bb36:
  %t165 = load ptr, ptr %l82, !tbaa !29
  %t166 = load i32, ptr %l83, !tbaa !23
  %t167 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s7, ptr %t165, i32 %t166)
  store { i64, ptr } %t167, ptr %l89
  br label %bb37
bb37:
  %t168 = load { i64, ptr }, ptr %l89, !tbaa !27
  %t169 = extractvalue { i64, ptr } %t168, 0
  %t170 = getelementptr %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l11, i32 0, i32 1
  %t171 = load i64, ptr %t170, !tbaa !24
  %t174 = icmp ne i64 %t169, %t171
  br i1 %t174, label %bb38, label %bb39
bb38:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb40
bb39:
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s7)
  br label %bb41
bb41:
  %t176 = load i64, ptr %l10, !tbaa !24
  %t178 = add i64 %t176, 1
  store i64 %t178, ptr %l10, !tbaa !24
  br label %bb27
bb42:
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t182 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esettleFacts(ptr %v0, ptr %t180)
  store i1 %t182, ptr %l96
  br label %bb43
bb43:
  %t183 = load i1, ptr %l96, !tbaa !21
  store i1 %t183, ptr %l12, !tbaa !21
  %t184 = load i1, ptr %l8, !tbaa !21
  %t186 = xor i1 %t184, true
  br i1 %t186, label %bb44, label %bb45
bb44:
  %t188 = load i1, ptr %l12, !tbaa !21
  %t190 = xor i1 %t188, true
  store i1 %t190, ptr %l99, !tbaa !21
  br label %bb46
bb45:
  store i1 false, ptr %l99, !tbaa !21
  br label %bb46
bb46:
  %t192 = load i1, ptr %l99, !tbaa !21
  br i1 %t192, label %bb47, label %bb48
bb47:
  store i1 true, ptr %l102, !tbaa !21
  br label %bb49
bb48:
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t195 = getelementptr %"compiler/check:Checker", ptr %t193, i32 0, i32 62
  %t196 = load i64, ptr %t195, !tbaa !24
  %t198 = icmp sge i64 %t196, 20
  store i1 %t198, ptr %l102, !tbaa !21
  br label %bb49
bb49:
  %t200 = load i1, ptr %l102, !tbaa !21
  br i1 %t200, label %bb50, label %bb51
bb50:
  store %olang.scope zeroinitializer, ptr %s10
  %t201 = load i1, ptr %l12, !tbaa !21
  br i1 %t201, label %bb52, label %bb53
bb51:
  br label %bb69
bb52:
  %t203 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efactsUndecided(ptr %v0, ptr %t203)
  br label %bb54
bb53:
  br label %bb55
bb54:
  br label %bb55
bb55:
  %t205 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esettleFixed(ptr %v0, ptr %t205)
  br label %bb56
bb56:
  %t207 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eorderGlobals(ptr %v0, ptr %t207)
  br label %bb57
bb57:
  %t209 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esettleAllViews(ptr %v0, ptr %t209)
  br label %bb58
bb58:
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t213 = getelementptr %"compiler/check:Checker", ptr %t211, i32 0, i32 1
  %t214 = load ptr, ptr %t213, !tbaa !29
  %t216 = getelementptr %"compiler/generic:Program", ptr %t214, i32 0, i32 0
  %t217 = load ptr, ptr %t216, !tbaa !29
  store ptr %t217, ptr %l113, !tbaa !29
  %t218 = load ptr, ptr %l0, !tbaa !29
  %t220 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emutStorage(ptr %v0, ptr %t218)
  store i1 %t220, ptr %l115
  br label %bb59
bb59:
  %t221 = load i1, ptr %l115, !tbaa !21
  %t222 = load ptr, ptr %l113, !tbaa !29
  %t223 = getelementptr %"compiler/load:Loader", ptr %t222, i32 0, i32 8
  store i1 %t221, ptr %t223, !tbaa !21
  %t224 = call { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %s10, ptr %s10, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d2, i32 0, i32 1) })
  %t225 = extractvalue { i32, { i64, ptr } } %t224, 1
  %t226 = extractvalue { i32, { i64, ptr } } %t224, 0
  store i32 %t226, ptr %l118
  %t227 = icmp ne i32 %t226, 0
  br i1 %t227, label %bb61, label %ok.228, !prof !99
ok.228:
  store { i64, ptr } %t225, ptr %l117
  br label %bb60
bb60:
  %t229 = load { i64, ptr }, ptr %l117, !tbaa !27
  store { i64, ptr } %t229, ptr %l116, !tbaa !27
  br label %bb63
bb61:
  br label %bb62
bb62:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d3, i32 0, i32 1) }, ptr %l119, !tbaa !27
  %t230 = load { i64, ptr }, ptr %l119, !tbaa !27
  %t232 = extractvalue { i64, ptr } %t230, 0
  %t233 = extractvalue { i64, ptr } %t230, 1
  %t234 = mul i64 %t232, 1
  %t235 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t234)
  call void @llvm.memcpy.p0.p0.i64(ptr %t235, ptr %t233, i64 %t234, i1 false)
  %t236 = insertvalue { i64, ptr } undef, i64 %t232, 0
  %t237 = insertvalue { i64, ptr } %t236, ptr %t235, 1
  store { i64, ptr } %t237, ptr %l116, !tbaa !27
  br label %bb63
bb63:
  %t239 = load { i64, ptr }, ptr %l116, !tbaa !27
  %t240 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s10, ptr %s10, { i64, ptr } %t239, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d4, i32 0, i32 1) })
  store i1 %t240, ptr %l122
  br label %bb64
bb64:
  %t241 = load i1, ptr %l122, !tbaa !21
  %t242 = xor i1 %t241, true
  br i1 %t242, label %bb65, label %bb66
bb65:
  %t244 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehandleReport(ptr %v0, ptr %t244)
  br label %bb67
bb66:
  br label %bb68
bb67:
  br label %bb68
bb68:
  call void @__olang_scope_close(ptr %s10)
  br label %ret
bb69:
  %t246 = load ptr, ptr %l0, !tbaa !29
  %t248 = getelementptr %"compiler/check:Checker", ptr %t246, i32 0, i32 1
  %t249 = load ptr, ptr %t248, !tbaa !29
  %t251 = getelementptr %"compiler/generic:Program", ptr %t249, i32 0, i32 0
  %t252 = load ptr, ptr %t251, !tbaa !29
  %t254 = getelementptr %"compiler/load:Loader", ptr %t252, i32 0, i32 4
  %t255 = load ptr, ptr %t254, !tbaa !29
  %t256 = load i64, ptr %l7, !tbaa !24
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eForget(ptr %v0, ptr %t255, i64 %t256)
  br label %bb70
bb70:
  %t259 = load ptr, ptr %l0, !tbaa !29
  store ptr %t259, ptr %l130, !tbaa !29
  %t260 = load ptr, ptr %l0, !tbaa !29
  %t262 = getelementptr %"compiler/check:Checker", ptr %t260, i32 0, i32 59
  %t263 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t262
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t263, ptr %l132
  %t265 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_H7f6fc75342dba0a5a8ac6e31960b7ffa(ptr %v0, ptr %l132)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t265, ptr %l134
  br label %bb71
bb71:
  %t266 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l134
  %t267 = load ptr, ptr %l130, !tbaa !29
  %t268 = getelementptr %"compiler/check:Checker", ptr %t267, i32 0, i32 58
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t266, ptr %t268
  %t269 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereset(ptr %v0, ptr %t269)
  br label %bb72
bb72:
  br label %bb73
bb73:
  br label %bb20
ret:
  ret void
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eCondBody(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l7 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t4 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t9 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eExprBody(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, i32 %t4)
  store i64 %t9, ptr %l7
  br label %bb1
bb1:
  %t10 = load i64, ptr %l7, !tbaa !24
  store i64 %t10, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eInfersErrors(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einfersErrs(ptr %v0, ptr %a0, i32 %a1)
  store i1 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i1, ptr %l4, !tbaa !21
  store i1 %t6, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eViewsOf(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, [2 x i64] }
  %l5 = alloca i64
  %l9 = alloca i1
  %l11 = alloca i64
  %l14 = alloca i64
  %l21 = alloca ptr
  %l24 = alloca i64
  %l27 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i32
  %l37 = alloca i64
  %l41 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i32
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1, !tbaa !23
  %t3 = sext i32 %t1 to i64
  %t5 = icmp slt i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb4
bb2:
  %t7 = load i32, ptr %l1, !tbaa !23
  %t9 = sext i32 %t7 to i64
  store i64 %t9, ptr %l11, !tbaa !24
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 14
  %t14 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t12)
  store i64 %t14, ptr %l14
  br label %bb3
bb3:
  %t15 = load i64, ptr %l11, !tbaa !24
  %t16 = load i64, ptr %l14, !tbaa !24
  %t17 = icmp sge i64 %t15, %t16
  store i1 %t17, ptr %l9, !tbaa !21
  br label %bb4
bb4:
  %t19 = load i1, ptr %l9, !tbaa !21
  br i1 %t19, label %bb5, label %bb6
bb5:
  store i64 0, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/check:Checker", ptr %t21, i32 0, i32 14
  %t24 = load i32, ptr %l1, !tbaa !23
  %t26 = sext i32 %t24 to i64
  %t29 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t23, i64 %t26)
  store ptr %t29, ptr %l21
  br label %bb8
bb8:
  %t30 = load ptr, ptr %l21, !tbaa !29
  store ptr %t30, ptr %l2, !tbaa !29
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load ptr, ptr %l2, !tbaa !29
  %t35 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorViewKey(ptr %v0, ptr %v0, ptr %t31, ptr %t32)
  store i64 %t35, ptr %l24
  br label %bb9
bb9:
  %t36 = load i64, ptr %l24, !tbaa !24
  store i64 %t36, ptr %l3, !tbaa !24
  %t37 = load i64, ptr %l3, !tbaa !24
  %t39 = icmp sge i64 %t37, 0
  br i1 %t39, label %bb10, label %bb11
bb10:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/check:Checker", ptr %t41, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !29
  %t46 = getelementptr %"compiler/generic:Program", ptr %t44, i32 0, i32 0
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t49 = getelementptr %"compiler/load:Loader", ptr %t47, i32 0, i32 7
  %t50 = load i64, ptr %l3, !tbaa !24
  %t53 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t49, i64 %t50)
  %t54 = extractvalue { i32, i64 } %t53, 1
  %t55 = extractvalue { i32, i64 } %t53, 0
  store i32 %t55, ptr %l34
  %t56 = icmp ne i32 %t55, 0
  br i1 %t56, label %bb13, label %ok.57, !prof !99
ok.57:
  store i64 %t54, ptr %l33
  br label %bb12
bb11:
  br label %bb16
bb12:
  %t58 = load i64, ptr %l33, !tbaa !24
  store i64 %t58, ptr %l27, !tbaa !24
  br label %bb15
bb13:
  br label %bb14
bb14:
  call void @__olang_ert_req_clear()
  store i64 0, ptr %l27, !tbaa !24
  br label %bb15
bb15:
  %t59 = load i64, ptr %l27, !tbaa !24
  store i64 %t59, ptr %rv
  br label %ret
bb16:
  %t60 = load ptr, ptr %l2, !tbaa !29
  %t62 = getelementptr %"compiler/typed:Body", ptr %t60, i32 0, i32 1
  %t63 = load { i64, [2 x i64] }, ptr %t62
  store { i64, [2 x i64] } %t63, ptr %l4
  %t65 = load { i64, [2 x i64] }, ptr %l4
  %t67 = extractvalue { i64, [2 x i64] } %t65, 0
  %t68 = icmp eq i64 %t67, 0
  br i1 %t68, label %bb17, label %bb18
bb17:
  %t70 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t71 = getelementptr { i64 }, ptr %t70, i32 0, i32 0
  %t72 = load i64, ptr %t71
  store i64 %t72, ptr %l5, !tbaa !24
  br label %bb19
bb18:
  br label %bb24
bb19:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/check:Checker", ptr %t74, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !29
  %t79 = getelementptr %"compiler/generic:Program", ptr %t77, i32 0, i32 0
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t82 = getelementptr %"compiler/load:Loader", ptr %t80, i32 0, i32 6
  %t83 = load i64, ptr %l5, !tbaa !24
  %t86 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t82, i64 %t83)
  %t87 = extractvalue { i32, i64 } %t86, 1
  %t88 = extractvalue { i32, i64 } %t86, 0
  store i32 %t88, ptr %l48
  %t89 = icmp ne i32 %t88, 0
  br i1 %t89, label %bb21, label %ok.90, !prof !99
ok.90:
  store i64 %t87, ptr %l47
  br label %bb20
bb20:
  %t91 = load i64, ptr %l47, !tbaa !24
  store i64 %t91, ptr %l41, !tbaa !24
  br label %bb23
bb21:
  br label %bb22
bb22:
  call void @__olang_ert_req_clear()
  store i64 0, ptr %l41, !tbaa !24
  br label %bb23
bb23:
  %t92 = load i64, ptr %l41, !tbaa !24
  store i64 %t92, ptr %l37, !tbaa !24
  br label %bb29
bb24:
  br i1 true, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  store i64 0, ptr %l37, !tbaa !24
  br label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_f6ac6f37bd028998_7777cf96519f6a94)
  unreachable
bb29:
  %t93 = load i64, ptr %l37, !tbaa !24
  store i64 %t93, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eallFixed(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l17 = alloca { i64, ptr }
  %l23 = alloca i1
  %rv = alloca i1
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 true, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t8, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t14 = load i64, ptr %l3, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb13
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t22, ptr %l17, !tbaa !27
  %t23 = load i64, ptr %l3, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  %t35 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadsFixed(ptr %v0, ptr %v1, ptr %a0, ptr %t28)
  store i1 %t35, ptr %l23
  br label %bb8
bb8:
  %t36 = load i1, ptr %l23, !tbaa !21
  %t37 = xor i1 %t36, true
  br i1 %t37, label %bb9, label %bb10
bb9:
  store i1 false, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  br label %bb12
bb12:
  %t40 = load i64, ptr %l3, !tbaa !24
  %t42 = add i64 %t40, 1
  store i64 %t42, ptr %l3, !tbaa !24
  br label %bb4
bb13:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyCall(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, i32 %a4, %"compiler/source:Span" %a5, { i64, ptr } %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca { i64, ptr }
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca %"compiler/generic:AnySlot"
  %l25 = alloca i32
  %l30 = alloca i1
  %l31 = alloca ptr
  %l33 = alloca %"compiler/source:Span"
  %l34 = alloca ptr
  %l36 = alloca %"compiler/source:Span"
  %l37 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l42 = alloca ptr
  %l44 = alloca %"compiler/source:Span"
  %l45 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l48 = alloca %"compiler/msgs:Msg"
  %l49 = alloca i64
  %l50 = alloca ptr
  %l51 = alloca %"compiler/source:Span"
  %l52 = alloca ptr
  %l57 = alloca i32
  %l58 = alloca ptr
  %l61 = alloca i32
  %l66 = alloca i32
  %l70 = alloca { i64, ptr }
  %l76 = alloca i64
  %l79 = alloca i64
  %l97 = alloca { i64, ptr }
  %l107 = alloca { i64, ptr }
  %l110 = alloca ptr
  %l114 = alloca i1
  %l116 = alloca i1
  %l117 = alloca ptr
  %l120 = alloca { i64, ptr }
  %l121 = alloca { i64, ptr }
  %l124 = alloca { i64, ptr }
  %l125 = alloca { i64, ptr }
  %l133 = alloca ptr
  %l134 = alloca ptr
  %l135 = alloca %"compiler/source:Span"
  %l136 = alloca %"compiler/source:Span"
  %l137 = alloca { i64, ptr }
  %l139 = alloca i32
  %l142 = alloca { i64, ptr }
  %l146 = alloca ptr
  %l148 = alloca ptr
  %l149 = alloca { i64, ptr }
  %l153 = alloca ptr
  %l160 = alloca i64
  %l163 = alloca i1
  %l166 = alloca i1
  %l167 = alloca ptr
  %l168 = alloca %"compiler/source:Span"
  %l171 = alloca { i64, ptr }
  %l172 = alloca { i64, ptr }
  %l175 = alloca { i64, ptr }
  %l177 = alloca %"compiler/msgs:Msg"
  %l178 = alloca i64
  %l183 = alloca ptr
  %l186 = alloca ptr
  %l187 = alloca %"compiler/source:Span"
  %l188 = alloca %"compiler/source:Span"
  %l189 = alloca i64
  %l191 = alloca ptr
  %l192 = alloca { i64, ptr }
  %l195 = alloca { i64, ptr }
  %l199 = alloca ptr
  %l202 = alloca { i64, ptr }
  %l203 = alloca %"compiler/msgs:Nearest"
  %l212 = alloca { i64, ptr }
  %l215 = alloca ptr
  %l218 = alloca { i64, ptr }
  %l221 = alloca ptr
  %l222 = alloca %"compiler/source:Span"
  %l225 = alloca { i64, ptr }
  %l226 = alloca { i64, ptr }
  %l229 = alloca { i64, ptr }
  %l230 = alloca { i64, ptr }
  %l232 = alloca { i64, ptr }
  %l234 = alloca %"compiler/msgs:Msg"
  %l235 = alloca i64
  %l240 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca ptr
  %t261 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  store i32 %a4, ptr %l4
  store %"compiler/source:Span" %a5, ptr %l5
  store { i64, ptr } %a6, ptr %l6
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l3, !tbaa !29
  %t4 = call i32 @compiler_2fcheck_2etypeOf(ptr %v2, ptr %t1)
  store i32 %t4, ptr %l25
  br label %bb1
bb1:
  %t5 = load i32, ptr %l25, !tbaa !23
  store i32 %t5, ptr %l7, !tbaa !23
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = getelementptr %"compiler/generic:Program", ptr %t9, i32 0, i32 2
  %t12 = load i32, ptr %l7, !tbaa !23
  %t15 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %t11, i32 %t12)
  store i1 %t15, ptr %l30
  br label %bb2
bb2:
  %t16 = load i1, ptr %l30, !tbaa !21
  br i1 %t16, label %bb3, label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t17 = load ptr, ptr %l0, !tbaa !29
  store ptr %t17, ptr %l31, !tbaa !29
  %t18 = load ptr, ptr %l2, !tbaa !29
  %t20 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t18)
  store %"compiler/source:Span" %t20, ptr %l33
  br label %bb5
bb4:
  br label %bb17
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  store ptr %t21, ptr %l34, !tbaa !29
  %t22 = load ptr, ptr %l2, !tbaa !29
  %t24 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t22)
  store %"compiler/source:Span" %t24, ptr %l36
  br label %bb6
bb6:
  %t25 = load ptr, ptr %l34, !tbaa !29
  %t26 = load %"compiler/source:Span", ptr %l36
  %t27 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v0, ptr %t25, %"compiler/source:Span" %t26)
  store { i64, ptr } %t27, ptr %l37
  br label %bb7
bb7:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load i32, ptr %l7, !tbaa !23
  %t32 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s1, ptr %t28, i32 %t29)
  store { i64, ptr } %t32, ptr %l40
  br label %bb8
bb8:
  %t33 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t33, 0
  %t35 = extractvalue { i64, ptr } %t33, 1
  %t36 = mul i64 %t34, 1
  %t37 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t36)
  call void @llvm.memcpy.p0.p0.i64(ptr %t37, ptr %t35, i64 %t36, i1 false)
  %t38 = insertvalue { i64, ptr } undef, i64 %t34, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t37, 1
  store { i64, ptr } %t39, ptr %l41, !tbaa !27
  %t40 = load ptr, ptr %l0, !tbaa !29
  store ptr %t40, ptr %l42, !tbaa !29
  %t41 = load ptr, ptr %l2, !tbaa !29
  %t43 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t41)
  store %"compiler/source:Span" %t43, ptr %l44
  br label %bb9
bb9:
  %t44 = load ptr, ptr %l42, !tbaa !29
  %t45 = load %"compiler/source:Span", ptr %l44
  %t46 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v0, ptr %t44, %"compiler/source:Span" %t45)
  store { i64, ptr } %t46, ptr %l45
  br label %bb10
bb10:
  %t47 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t48 = call { i64, ptr } @compiler_2fcheck_2ebangOf(ptr %v0, ptr %s1, { i64, ptr } %t47)
  store { i64, ptr } %t48, ptr %l46
  br label %bb11
bb11:
  %t49 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t49, 0
  %t51 = extractvalue { i64, ptr } %t49, 1
  %t52 = mul i64 %t50, 1
  %t53 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t52)
  call void @llvm.memcpy.p0.p0.i64(ptr %t53, ptr %t51, i64 %t52, i1 false)
  %t54 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t55 = insertvalue { i64, ptr } %t54, ptr %t53, 1
  %t56 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t57 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t59 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eReadMaybeNull(ptr %v0, ptr %s1, ptr %s1, ptr %s1, { i64, ptr } %t56, { i64, ptr } %t57, { i64, ptr } %t55)
  store %"compiler/msgs:Msg" %t59, ptr %l48
  br label %bb12
bb12:
  %t60 = load ptr, ptr %l31, !tbaa !29
  %t61 = load %"compiler/source:Span", ptr %l33
  %t62 = load %"compiler/msgs:Msg", ptr %l48
  %t63 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s1, ptr %t60, %"compiler/source:Span" %t61, %"compiler/msgs:Msg" %t62)
  store i64 %t63, ptr %l49
  br label %bb13
bb13:
  %t64 = load ptr, ptr %l0, !tbaa !29
  store ptr %t64, ptr %l50, !tbaa !29
  %t65 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t65, ptr %l51
  %t66 = load ptr, ptr %l3, !tbaa !29
  store ptr %t66, ptr %l52, !tbaa !29
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/check:Checker", ptr %t67, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !29
  %t72 = getelementptr %"compiler/generic:Program", ptr %t70, i32 0, i32 2
  %t73 = load i32, ptr %l7, !tbaa !23
  %t76 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNonNull(ptr %v0, ptr %t72, i32 %t73)
  store i32 %t76, ptr %l57
  br label %bb14
bb14:
  %t77 = load ptr, ptr %l50, !tbaa !29
  %t78 = load %"compiler/source:Span", ptr %l51
  %t79 = load ptr, ptr %l52, !tbaa !29
  %t80 = load i32, ptr %l57, !tbaa !23
  %t81 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %v2, ptr %v2, ptr %t77, %"compiler/source:Span" %t78, ptr %t79, i32 %t80)
  store ptr %t81, ptr %l58
  br label %bb15
bb15:
  %t82 = load ptr, ptr %l58, !tbaa !29
  store ptr %t82, ptr %l3, !tbaa !29
  %t83 = load ptr, ptr %l3, !tbaa !29
  %t86 = call i32 @compiler_2fcheck_2etypeOf(ptr %v2, ptr %t83)
  store i32 %t86, ptr %l61
  br label %bb16
bb16:
  %t87 = load i32, ptr %l61, !tbaa !23
  store i32 %t87, ptr %l7, !tbaa !23
  call void @__olang_scope_close(ptr %s1)
  br label %bb17
bb17:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/check:Checker", ptr %t88, i32 0, i32 1
  %t91 = load ptr, ptr %t90, !tbaa !29
  %t93 = getelementptr %"compiler/generic:Program", ptr %t91, i32 0, i32 2
  %t94 = load i32, ptr %l7, !tbaa !23
  %t97 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnyTrait(ptr %v0, ptr %t93, i32 %t94)
  store i32 %t97, ptr %l66
  br label %bb18
bb18:
  %t98 = load i32, ptr %l66, !tbaa !23
  store i32 %t98, ptr %l8, !tbaa !23
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/check:Checker", ptr %t99, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !29
  %t103 = load i32, ptr %l8, !tbaa !23
  %t106 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnySlots(ptr %v0, ptr %v0, ptr %t102, i32 %t103)
  store { i64, ptr } %t106, ptr %l70
  br label %bb19
bb19:
  %t107 = load { i64, ptr }, ptr %l70, !tbaa !27
  store { i64, ptr } %t107, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t108 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t110 = extractvalue { i64, ptr } %t108, 0
  store i64 %t110, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t112 = load i64, ptr %l11, !tbaa !24
  %t113 = load i64, ptr %l10, !tbaa !24
  %t116 = icmp sgt i64 %t112, %t113
  br i1 %t116, label %bb20, label %bb21
bb20:
  %t118 = load i64, ptr %l12, !tbaa !24
  %t120 = icmp sgt i64 %t118, 0
  br i1 %t120, label %bb22, label %bb23
bb21:
  store i64 0, ptr %l76, !tbaa !24
  br label %bb25
bb22:
  %t122 = load i64, ptr %l11, !tbaa !24
  %t123 = load i64, ptr %l10, !tbaa !24
  %t126 = sub i64 %t122, %t123
  %t127 = load i64, ptr %l12, !tbaa !24
  %t130 = add i64 %t126, %t127
  %t132 = sub i64 %t130, 1
  %t133 = load i64, ptr %l12, !tbaa !24
  %t136 = sdiv i64 %t132, %t133
  store i64 %t136, ptr %l79, !tbaa !24
  br label %bb24
bb23:
  store i64 0, ptr %l79, !tbaa !24
  br label %bb24
bb24:
  %t138 = load i64, ptr %l79, !tbaa !24
  store i64 %t138, ptr %l76, !tbaa !24
  br label %bb25
bb25:
  %t139 = load i64, ptr %l76, !tbaa !24
  store i64 %t139, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb26
bb26:
  %t140 = load i64, ptr %l14, !tbaa !24
  %t141 = load i64, ptr %l13, !tbaa !24
  %t144 = icmp slt i64 %t140, %t141
  %t146 = xor i1 %t144, true
  br i1 %t146, label %bb27, label %bb28
bb27:
  br label %bb55
bb28:
  br label %bb29
bb29:
  %t148 = load i64, ptr %l10, !tbaa !24
  %t149 = load i64, ptr %l14, !tbaa !24
  %t150 = load i64, ptr %l12, !tbaa !24
  %t153 = mul i64 %t149, %t150
  %t156 = add i64 %t148, %t153
  store i64 %t156, ptr %l15, !tbaa !24
  %t158 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t158, ptr %l97, !tbaa !27
  %t159 = load i64, ptr %l15, !tbaa !24
  %t161 = getelementptr { i64, ptr }, ptr %l97, i32 0, i32 1
  %t162 = load ptr, ptr %t161, !tbaa !27
  %t163 = getelementptr %"compiler/generic:AnySlot", ptr %t162, i64 %t159
  %t164 = getelementptr %"compiler/generic:AnySlot", ptr %t163, i32 0, i32 0
  %t165 = load i32, ptr %t164, !tbaa !23
  %t166 = load i32, ptr %l4, !tbaa !23
  %t169 = icmp ne i32 %t165, %t166
  br i1 %t169, label %bb30, label %bb31
bb30:
  br label %bb54
bb31:
  br label %bb32
bb32:
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t172 = load i32, ptr %l8, !tbaa !23
  %t173 = load i64, ptr %l15, !tbaa !24
  %t174 = load %"compiler/source:Span", ptr %l5
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eslotCall(ptr %v0, ptr %t171, i32 %t172, i64 %t173, %"compiler/source:Span" %t174)
  br label %bb33
bb33:
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t180 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t180, ptr %l107, !tbaa !27
  %t181 = load i64, ptr %l15, !tbaa !24
  %t183 = getelementptr { i64, ptr }, ptr %l107, i32 0, i32 1
  %t184 = load ptr, ptr %t183, !tbaa !27
  %t185 = getelementptr %"compiler/generic:AnySlot", ptr %t184, i64 %t181
  %t186 = load %"compiler/generic:AnySlot", ptr %t185
  %t189 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etraitMethod(ptr %v0, ptr %v0, ptr %t179, %"compiler/generic:AnySlot" %t186)
  store ptr %t189, ptr %l110
  br label %bb34
bb34:
  %t190 = load ptr, ptr %l110, !tbaa !29
  store ptr %t190, ptr %l16, !tbaa !29
  %t191 = load ptr, ptr %l16, !tbaa !29
  %t193 = icmp eq ptr %t191, null
  %t195 = xor i1 %t193, true
  br i1 %t195, label %bb35, label %bb36
bb35:
  %t197 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t199 = call i1 @compiler_2fcheck_2ehasNamed(ptr %v3, { i64, ptr } %t197)
  store i1 %t199, ptr %l116
  br label %bb37
bb36:
  store i1 false, ptr %l114, !tbaa !21
  br label %bb38
bb37:
  %t200 = load i1, ptr %l116, !tbaa !21
  store i1 %t200, ptr %l114, !tbaa !21
  br label %bb38
bb38:
  %t201 = load i1, ptr %l114, !tbaa !21
  br i1 %t201, label %bb39, label %bb40
bb39:
  %t202 = load ptr, ptr %l0, !tbaa !29
  store ptr %t202, ptr %l117, !tbaa !29
  %t203 = load ptr, ptr %l16, !tbaa !29
  %t205 = getelementptr %"compiler/ast:Func", ptr %t203, i32 0, i32 3
  %t206 = load ptr, ptr %t205, !tbaa !29
  %t208 = getelementptr %"compiler/ast:Sig", ptr %t206, i32 0, i32 0
  %t209 = load { i64, ptr }, ptr %t208, !tbaa !27
  store { i64, ptr } %t209, ptr %l120, !tbaa !27
  %t210 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t210, ptr %l121, !tbaa !27
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t212 = load i32, ptr %l4, !tbaa !23
  %t215 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t211, i32 %t212)
  store { i64, ptr } %t215, ptr %l124
  br label %bb41
bb40:
  br label %bb48
bb41:
  %t216 = load ptr, ptr %l117, !tbaa !29
  %t217 = load { i64, ptr }, ptr %l120, !tbaa !27
  %t218 = load { i64, ptr }, ptr %l121, !tbaa !27
  %t219 = load { i64, ptr }, ptr %l124, !tbaa !27
  %t220 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enamedArgs(ptr %v0, ptr %v0, ptr %v3, ptr %v0, ptr %v3, ptr %t216, { i64, ptr } %t217, { i64, ptr } %t218, { i64, ptr } %t219)
  store { i64, ptr } %t220, ptr %l125
  br label %bb42
bb42:
  %t221 = load { i64, ptr }, ptr %l125, !tbaa !27
  store { i64, ptr } %t221, ptr %l6, !tbaa !27
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t224 = getelementptr %"compiler/check:Checker", ptr %t222, i32 0, i32 131
  %t225 = load i1, ptr %t224, !tbaa !21
  br i1 %t225, label %bb43, label %bb44
bb43:
  %t227 = load ptr, ptr %l0, !tbaa !29
  %t229 = getelementptr %"compiler/check:Checker", ptr %t227, i32 0, i32 131
  store i1 false, ptr %t229, !tbaa !21
  %t230 = load ptr, ptr %l0, !tbaa !29
  %t231 = load { i64, ptr }, ptr %l6, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v3, ptr %t230, { i64, ptr } %t231)
  br label %bb45
bb44:
  br label %bb47
bb45:
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t235 = load %"compiler/source:Span", ptr %l1
  %t238 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v4, ptr %t234, %"compiler/source:Span" %t235)
  store ptr %t238, ptr %l133
  br label %bb46
bb46:
  call void @__olang_scope_close(ptr %s0)
  %t239 = load ptr, ptr %l133, !tbaa !29
  store ptr %t239, ptr %rv
  br label %ret
bb47:
  br label %bb48
bb48:
  %t240 = load ptr, ptr %l0, !tbaa !29
  store ptr %t240, ptr %l134, !tbaa !29
  %t241 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t241, ptr %l135
  %t242 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t242, ptr %l136
  %t243 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t243, ptr %l137, !tbaa !27
  %t244 = load i64, ptr %l15, !tbaa !24
  %t246 = getelementptr { i64, ptr }, ptr %l137, i32 0, i32 1
  %t247 = load ptr, ptr %t246, !tbaa !27
  %t248 = getelementptr %"compiler/generic:AnySlot", ptr %t247, i64 %t244
  %t249 = getelementptr %"compiler/generic:AnySlot", ptr %t248, i32 0, i32 5
  %t250 = load i32, ptr %t249, !tbaa !23
  store i32 %t250, ptr %l139, !tbaa !23
  %t251 = load i32, ptr %l8, !tbaa !23
  %t252 = load i64, ptr %l15, !tbaa !24
  %t253 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t253, ptr %l142, !tbaa !27
  %t254 = load i64, ptr %l15, !tbaa !24
  %t256 = getelementptr { i64, ptr }, ptr %l142, i32 0, i32 1
  %t257 = load ptr, ptr %t256, !tbaa !27
  %t258 = getelementptr %"compiler/generic:AnySlot", ptr %t257, i64 %t254
  %t259 = getelementptr %"compiler/generic:AnySlot", ptr %t258, i32 0, i32 5
  %t260 = load i32, ptr %t259, !tbaa !23
  store { i64, [3 x i64] } zeroinitializer, ptr %t261
  %t262 = getelementptr { i64, [3 x i64] }, ptr %t261, i32 0, i32 0
  store i64 3, ptr %t262
  %t264 = insertvalue { i32, i64, i32 } undef, i32 %t251, 0
  %t266 = insertvalue { i32, i64, i32 } %t264, i64 %t252, 1
  %t268 = insertvalue { i32, i64, i32 } %t266, i32 %t260, 2
  %t269 = getelementptr { i64, [3 x i64] }, ptr %t261, i32 0, i32 1
  store { i32, i64, i32 } %t268, ptr %t269
  %t270 = load { i64, [3 x i64] }, ptr %t261
  %t272 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 32, i64 8)
  store { i64, [3 x i64] } %t270, ptr %t272
  store ptr %t272, ptr %l146, !tbaa !29
  %t273 = load ptr, ptr %l3, !tbaa !29
  store ptr %t273, ptr %l148, !tbaa !29
  %t275 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t275, ptr %l149, !tbaa !27
  %t276 = icmp sge i64 0, 0
  br i1 %t276, label %bb49, label %bb50
bb49:
  %t278 = icmp sle i64 0, 1152921504606846975
  br i1 %t278, label %bb51, label %bb52
bb50:
  call void @__olang_check_failed(ptr @olang_loc_e1138a3bee8dfd28_1d9c93b07a3bbf3c)
  unreachable
bb51:
  %t280 = mul i64 0, 8
  %t281 = insertvalue { i64, ptr } undef, i64 0, 0
  %t282 = insertvalue { i64, ptr } %t281, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t283 = load ptr, ptr %l134, !tbaa !29
  %t284 = load %"compiler/source:Span", ptr %l135
  %t285 = load %"compiler/source:Span", ptr %l136
  %t286 = load i32, ptr %l139, !tbaa !23
  %t287 = load ptr, ptr %l146, !tbaa !29
  %t288 = load ptr, ptr %l148, !tbaa !29
  %t289 = load { i64, ptr }, ptr %l149, !tbaa !27
  %t291 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallBody(ptr %v0, ptr %v4, ptr %v2, ptr %v3, ptr %v0, ptr %v4, ptr %t283, %"compiler/source:Span" %t284, %"compiler/source:Span" %t285, i32 %t286, ptr %t287, i64 -1, ptr %t288, { i64, ptr } %t289, { i64, ptr } %t282)
  store ptr %t291, ptr %l153
  br label %bb53
bb52:
  call void @__olang_check_failed(ptr @olang_loc_e1138a3bee8dfd28_1d9c93b07a3bbf3c)
  unreachable
bb53:
  call void @__olang_scope_close(ptr %s0)
  %t292 = load ptr, ptr %l153, !tbaa !29
  store ptr %t292, ptr %rv
  br label %ret
bb54:
  %t293 = load i64, ptr %l14, !tbaa !24
  %t295 = add i64 %t293, 1
  store i64 %t295, ptr %l14, !tbaa !24
  br label %bb26
bb55:
  %t297 = load ptr, ptr %l0, !tbaa !29
  %t299 = getelementptr %"compiler/check:Checker", ptr %t297, i32 0, i32 1
  %t300 = load ptr, ptr %t299, !tbaa !29
  %t301 = load i32, ptr %l8, !tbaa !23
  %t302 = load i32, ptr %l4, !tbaa !23
  %t306 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnyDefault(ptr %v0, ptr %t300, i32 %t301, i32 %t302)
  store i64 %t306, ptr %l160
  br label %bb56
bb56:
  %t307 = load i64, ptr %l160, !tbaa !24
  store i64 %t307, ptr %l17, !tbaa !24
  %t308 = load i64, ptr %l17, !tbaa !24
  %t310 = icmp sge i64 %t308, 0
  br i1 %t310, label %bb57, label %bb58
bb57:
  %t312 = load ptr, ptr %l0, !tbaa !29
  %t313 = load i64, ptr %l17, !tbaa !24
  %t316 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edefaultCopiesRecv(ptr %v0, ptr %t312, i64 %t313)
  store i1 %t316, ptr %l166
  br label %bb59
bb58:
  store i1 false, ptr %l163, !tbaa !21
  br label %bb60
bb59:
  %t317 = load i1, ptr %l166, !tbaa !21
  store i1 %t317, ptr %l163, !tbaa !21
  br label %bb60
bb60:
  %t318 = load i1, ptr %l163, !tbaa !21
  br i1 %t318, label %bb61, label %bb62
bb61:
  store %olang.scope zeroinitializer, ptr %s8
  %t319 = load ptr, ptr %l0, !tbaa !29
  store ptr %t319, ptr %l167, !tbaa !29
  %t320 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t320, ptr %l168
  %t321 = load ptr, ptr %l0, !tbaa !29
  %t322 = load i32, ptr %l4, !tbaa !23
  %t325 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s8, ptr %t321, i32 %t322)
  store { i64, ptr } %t325, ptr %l171
  br label %bb63
bb62:
  br label %bb69
bb63:
  %t326 = load { i64, ptr }, ptr %l171, !tbaa !27
  %t327 = extractvalue { i64, ptr } %t326, 0
  %t328 = extractvalue { i64, ptr } %t326, 1
  %t329 = mul i64 %t327, 1
  %t330 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t329)
  call void @llvm.memcpy.p0.p0.i64(ptr %t330, ptr %t328, i64 %t329, i1 false)
  %t331 = insertvalue { i64, ptr } undef, i64 %t327, 0
  %t332 = insertvalue { i64, ptr } %t331, ptr %t330, 1
  store { i64, ptr } %t332, ptr %l172, !tbaa !27
  %t333 = load ptr, ptr %l0, !tbaa !29
  %t334 = load i32, ptr %l7, !tbaa !23
  %t337 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s8, ptr %t333, i32 %t334)
  store { i64, ptr } %t337, ptr %l175
  br label %bb64
bb64:
  %t338 = load { i64, ptr }, ptr %l175, !tbaa !27
  %t339 = extractvalue { i64, ptr } %t338, 0
  %t340 = extractvalue { i64, ptr } %t338, 1
  %t341 = mul i64 %t339, 1
  %t342 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t341)
  call void @llvm.memcpy.p0.p0.i64(ptr %t342, ptr %t340, i64 %t341, i1 false)
  %t343 = insertvalue { i64, ptr } undef, i64 %t339, 0
  %t344 = insertvalue { i64, ptr } %t343, ptr %t342, 1
  %t345 = load { i64, ptr }, ptr %l172, !tbaa !27
  %t347 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eAnyNoCopy(ptr %s8, ptr %s8, ptr %s8, { i64, ptr } %t345, { i64, ptr } %t344)
  store %"compiler/msgs:Msg" %t347, ptr %l177
  br label %bb65
bb65:
  %t348 = load ptr, ptr %l167, !tbaa !29
  %t349 = load %"compiler/source:Span", ptr %l168
  %t350 = load %"compiler/msgs:Msg", ptr %l177
  %t351 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s8, ptr %t348, %"compiler/source:Span" %t349, %"compiler/msgs:Msg" %t350)
  store i64 %t351, ptr %l178
  br label %bb66
bb66:
  %t352 = load ptr, ptr %l0, !tbaa !29
  %t353 = load { i64, ptr }, ptr %l6, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v3, ptr %t352, { i64, ptr } %t353)
  br label %bb67
bb67:
  %t356 = load ptr, ptr %l0, !tbaa !29
  %t357 = load %"compiler/source:Span", ptr %l1
  %t360 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v4, ptr %t356, %"compiler/source:Span" %t357)
  store ptr %t360, ptr %l183
  br label %bb68
bb68:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  %t361 = load ptr, ptr %l183, !tbaa !29
  store ptr %t361, ptr %rv
  br label %ret
bb69:
  %t362 = load i64, ptr %l17, !tbaa !24
  %t364 = icmp sge i64 %t362, 0
  br i1 %t364, label %bb70, label %bb71
bb70:
  %t366 = load ptr, ptr %l0, !tbaa !29
  store ptr %t366, ptr %l186, !tbaa !29
  %t367 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t367, ptr %l187
  %t368 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t368, ptr %l188
  %t369 = load i64, ptr %l17, !tbaa !24
  store i64 %t369, ptr %l189, !tbaa !24
  %t370 = load ptr, ptr %l3, !tbaa !29
  store ptr %t370, ptr %l191, !tbaa !29
  %t372 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t372, ptr %l192, !tbaa !27
  %t373 = icmp sge i64 0, 0
  br i1 %t373, label %bb72, label %bb73
bb71:
  br label %bb81
bb72:
  %t375 = icmp sle i64 0, 1152921504606846975
  br i1 %t375, label %bb74, label %bb75
bb73:
  call void @__olang_check_failed(ptr @olang_loc_ecdebd42147a0915_28ece6113815da89)
  unreachable
bb74:
  %t377 = mul i64 0, 8
  %t378 = insertvalue { i64, ptr } undef, i64 0, 0
  %t379 = insertvalue { i64, ptr } %t378, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t379, ptr %l195, !tbaa !27
  %t380 = icmp sge i64 0, 0
  br i1 %t380, label %bb76, label %bb77
bb75:
  call void @__olang_check_failed(ptr @olang_loc_ecdebd42147a0915_28ece6113815da89)
  unreachable
bb76:
  %t382 = icmp sle i64 0, 2305843009213693951
  br i1 %t382, label %bb78, label %bb79
bb77:
  call void @__olang_check_failed(ptr @olang_loc_b35cdd4155941ff6_f61ebbb89c67ebca)
  unreachable
bb78:
  %t384 = mul i64 0, 4
  %t385 = insertvalue { i64, ptr } undef, i64 0, 0
  %t386 = insertvalue { i64, ptr } %t385, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t387 = load ptr, ptr %l186, !tbaa !29
  %t388 = load %"compiler/source:Span", ptr %l187
  %t389 = load %"compiler/source:Span", ptr %l188
  %t390 = load i64, ptr %l189, !tbaa !24
  %t391 = load ptr, ptr %l191, !tbaa !29
  %t392 = load { i64, ptr }, ptr %l192, !tbaa !27
  %t393 = load { i64, ptr }, ptr %l195, !tbaa !27
  %t395 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v2, ptr %v3, ptr %v0, ptr %v4, ptr %v4, ptr %t387, %"compiler/source:Span" %t388, %"compiler/source:Span" %t389, i64 %t390, ptr %t391, { i64, ptr } %t392, { i64, ptr } %t393, { i64, ptr } %t386)
  store ptr %t395, ptr %l199
  br label %bb80
bb79:
  call void @__olang_check_failed(ptr @olang_loc_b35cdd4155941ff6_f61ebbb89c67ebca)
  unreachable
bb80:
  call void @__olang_scope_close(ptr %s0)
  %t396 = load ptr, ptr %l199, !tbaa !29
  store ptr %t396, ptr %rv
  br label %ret
bb81:
  %t397 = load ptr, ptr %l0, !tbaa !29
  %t398 = load i32, ptr %l4, !tbaa !23
  %t401 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t397, i32 %t398)
  store { i64, ptr } %t401, ptr %l202
  br label %bb82
bb82:
  %t402 = load { i64, ptr }, ptr %l202, !tbaa !27
  %t403 = call %"compiler/msgs:Nearest" @compiler_2fmsgs_3aNearest_2ector(ptr %v0, ptr %s0, { i64, ptr } %t402)
  store %"compiler/msgs:Nearest" %t403, ptr %l203
  br label %bb83
bb83:
  %t404 = load %"compiler/msgs:Nearest", ptr %l203
  %t405 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 40, i64 8)
  store %"compiler/msgs:Nearest" %t404, ptr %t405
  store ptr %t405, ptr %l18, !tbaa !29
  %t407 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t407, ptr %l19, !tbaa !27
  store i64 0, ptr %l20, !tbaa !24
  %t409 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t411 = extractvalue { i64, ptr } %t409, 0
  store i64 %t411, ptr %l21, !tbaa !24
  br label %bb84
bb84:
  %t413 = load i64, ptr %l20, !tbaa !24
  %t414 = load i64, ptr %l21, !tbaa !24
  %t417 = icmp slt i64 %t413, %t414
  %t419 = xor i1 %t417, true
  br i1 %t419, label %bb85, label %bb86
bb85:
  br label %bb91
bb86:
  br label %bb87
bb87:
  %t421 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t421, ptr %l212, !tbaa !27
  %t422 = load i64, ptr %l20, !tbaa !24
  %t424 = getelementptr { i64, ptr }, ptr %l212, i32 0, i32 1
  %t425 = load ptr, ptr %t424, !tbaa !27
  %t426 = getelementptr %"compiler/generic:AnySlot", ptr %t425, i64 %t422
  %t427 = load %"compiler/generic:AnySlot", ptr %t426
  store %"compiler/generic:AnySlot" %t427, ptr %l22
  %t429 = load ptr, ptr %l18, !tbaa !29
  store ptr %t429, ptr %l215, !tbaa !29
  %t430 = load ptr, ptr %l0, !tbaa !29
  %t431 = getelementptr %"compiler/generic:AnySlot", ptr %l22, i32 0, i32 0
  %t432 = load i32, ptr %t431, !tbaa !23
  %t435 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t430, i32 %t432)
  store { i64, ptr } %t435, ptr %l218
  br label %bb88
bb88:
  %t436 = load ptr, ptr %l215, !tbaa !29
  %t437 = load { i64, ptr }, ptr %l218, !tbaa !27
  call void @compiler_2fmsgs_2ecompiler_2fmsgs_3aNearest_2eOffer(ptr %s0, ptr %v0, ptr %t436, { i64, ptr } %t437)
  br label %bb89
bb89:
  br label %bb90
bb90:
  %t438 = load i64, ptr %l20, !tbaa !24
  %t440 = add i64 %t438, 1
  store i64 %t440, ptr %l20, !tbaa !24
  br label %bb84
bb91:
  %t442 = load ptr, ptr %l0, !tbaa !29
  store ptr %t442, ptr %l221, !tbaa !29
  %t443 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t443, ptr %l222
  %t444 = load ptr, ptr %l0, !tbaa !29
  %t445 = load i32, ptr %l7, !tbaa !23
  %t448 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t444, i32 %t445)
  store { i64, ptr } %t448, ptr %l225
  br label %bb92
bb92:
  %t449 = load { i64, ptr }, ptr %l225, !tbaa !27
  %t450 = extractvalue { i64, ptr } %t449, 0
  %t451 = extractvalue { i64, ptr } %t449, 1
  %t452 = mul i64 %t450, 1
  %t453 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t452)
  call void @llvm.memcpy.p0.p0.i64(ptr %t453, ptr %t451, i64 %t452, i1 false)
  %t454 = insertvalue { i64, ptr } undef, i64 %t450, 0
  %t455 = insertvalue { i64, ptr } %t454, ptr %t453, 1
  store { i64, ptr } %t455, ptr %l226, !tbaa !27
  %t456 = load ptr, ptr %l0, !tbaa !29
  %t457 = load i32, ptr %l4, !tbaa !23
  %t460 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s0, ptr %t456, i32 %t457)
  store { i64, ptr } %t460, ptr %l229
  br label %bb93
bb93:
  %t461 = load { i64, ptr }, ptr %l229, !tbaa !27
  %t462 = extractvalue { i64, ptr } %t461, 0
  %t463 = extractvalue { i64, ptr } %t461, 1
  %t464 = mul i64 %t462, 1
  %t465 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t464)
  call void @llvm.memcpy.p0.p0.i64(ptr %t465, ptr %t463, i64 %t464, i1 false)
  %t466 = insertvalue { i64, ptr } undef, i64 %t462, 0
  %t467 = insertvalue { i64, ptr } %t466, ptr %t465, 1
  store { i64, ptr } %t467, ptr %l230, !tbaa !27
  %t468 = load ptr, ptr %l18, !tbaa !29
  %t470 = call { i64, ptr } @compiler_2fmsgs_2ecompiler_2fmsgs_3aNearest_2eHint(ptr %s0, ptr %s0, ptr %t468)
  store { i64, ptr } %t470, ptr %l232
  br label %bb94
bb94:
  %t471 = load { i64, ptr }, ptr %l232, !tbaa !27
  %t472 = extractvalue { i64, ptr } %t471, 0
  %t473 = extractvalue { i64, ptr } %t471, 1
  %t474 = mul i64 %t472, 1
  %t475 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t474)
  call void @llvm.memcpy.p0.p0.i64(ptr %t475, ptr %t473, i64 %t474, i1 false)
  %t476 = insertvalue { i64, ptr } undef, i64 %t472, 0
  %t477 = insertvalue { i64, ptr } %t476, ptr %t475, 1
  %t478 = load { i64, ptr }, ptr %l226, !tbaa !27
  %t479 = load { i64, ptr }, ptr %l230, !tbaa !27
  %t481 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eAnyNoMethod(ptr %s0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t478, { i64, ptr } %t479, { i64, ptr } %t477)
  store %"compiler/msgs:Msg" %t481, ptr %l234
  br label %bb95
bb95:
  %t482 = load ptr, ptr %l221, !tbaa !29
  %t483 = load %"compiler/source:Span", ptr %l222
  %t484 = load %"compiler/msgs:Msg", ptr %l234
  %t485 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s0, ptr %t482, %"compiler/source:Span" %t483, %"compiler/msgs:Msg" %t484)
  store i64 %t485, ptr %l235
  br label %bb96
bb96:
  %t486 = load ptr, ptr %l0, !tbaa !29
  %t487 = load { i64, ptr }, ptr %l6, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v3, ptr %t486, { i64, ptr } %t487)
  br label %bb97
bb97:
  %t490 = load ptr, ptr %l0, !tbaa !29
  %t491 = load %"compiler/source:Span", ptr %l1
  %t494 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v4, ptr %t490, %"compiler/source:Span" %t491)
  store ptr %t494, ptr %l240
  br label %bb98
bb98:
  call void @__olang_scope_close(ptr %s0)
  %t495 = load ptr, ptr %l240, !tbaa !29
  store ptr %t495, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eattrHolder(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l5 = alloca i32
  %l11 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t5 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edescTypeOf(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  store i32 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i32, ptr %l5, !tbaa !23
  store i32 %t6, ptr %l2, !tbaa !23
  %t7 = load i32, ptr %l2, !tbaa !23
  %t9 = icmp sge i32 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load i32, ptr %l2, !tbaa !23
  store i32 %t11, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t17 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflType(ptr %v0, ptr %v1, ptr %t13, ptr %t14)
  store i32 %t17, ptr %l11
  br label %bb5
bb5:
  %t18 = load i32, ptr %l11, !tbaa !23
  store i32 %t18, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eblockOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca { i64, i64, i64 }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l11 = alloca i64
  %l15 = alloca { i64, i64, i64 }
  %l26 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 37
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l11
  br label %bb1
bb1:
  %t6 = load i64, ptr %l11, !tbaa !24
  store i64 %t6, ptr %l4, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t13 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t7, i32 %a2, %"compiler/source:Span" %a3)
  store { i64, i64, i64 } %t13, ptr %l15
  br label %bb2
bb2:
  %t14 = load { i64, i64, i64 }, ptr %l15
  store { i64, i64, i64 } %t14, ptr %l5
  %t15 = getelementptr { i64, i64, i64 }, ptr %l5, i32 0, i32 0
  %t16 = load i64, ptr %t15, !tbaa !24
  store i64 %t16, ptr %l6, !tbaa !24
  %t18 = getelementptr { i64, i64, i64 }, ptr %l5, i32 0, i32 1
  %t19 = load i64, ptr %t18, !tbaa !24
  store i64 %t19, ptr %l7, !tbaa !24
  %t21 = getelementptr { i64, i64, i64 }, ptr %l5, i32 0, i32 2
  %t22 = load i64, ptr %t21, !tbaa !24
  store i64 %t22, ptr %l8, !tbaa !24
  %t24 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmtsOf(ptr %v0, ptr %v1, ptr %t24, { i64, ptr } %a1)
  br label %bb3
bb3:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load i64, ptr %l6, !tbaa !24
  %t30 = load i64, ptr %l7, !tbaa !24
  %t31 = load i64, ptr %l8, !tbaa !24
  %t32 = load i64, ptr %l4, !tbaa !24
  %t38 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %v2, ptr %t28, i64 %t29, i64 %t30, i64 %t31, i64 %t32)
  store ptr %t38, ptr %l26
  br label %bb4
bb4:
  %t39 = load ptr, ptr %l26, !tbaa !29
  store ptr %t39, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eborrowedSource(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca ptr
  %l9 = alloca i32
  %l12 = alloca i1
  %l13 = alloca i32
  %l20 = alloca i32
  %l23 = alloca i1
  %l24 = alloca i1
  %l29 = alloca i64
  %l33 = alloca i1
  %l37 = alloca i1
  %l40 = alloca ptr
  %l45 = alloca i32
  %l50 = alloca i64
  %l53 = alloca i32
  %l57 = alloca i64
  %l59 = alloca ptr
  %l62 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l65 = alloca i1
  %l66 = alloca i1
  %l70 = alloca i1
  %l71 = alloca ptr
  %l73 = alloca ptr
  %l74 = alloca i1
  %l79 = alloca ptr
  %rv = alloca i64
  %t159 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t4 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t1)
  store i32 %t4, ptr %l9
  br label %bb1
bb1:
  %t5 = load i32, ptr %l9, !tbaa !23
  store i32 %t5, ptr %l3, !tbaa !23
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load i32, ptr %l3, !tbaa !23
  %t10 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t6, i32 %t7)
  store i1 %t10, ptr %l12
  br label %bb2
bb2:
  %t11 = load i1, ptr %l12, !tbaa !21
  br i1 %t11, label %bb3, label %bb4
bb3:
  %t12 = load i32, ptr %l3, !tbaa !23
  store i32 %t12, ptr %l13, !tbaa !23
  br label %bb6
bb4:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/check:Checker", ptr %t14, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t19 = getelementptr %"compiler/generic:Program", ptr %t17, i32 0, i32 2
  %t20 = load i32, ptr %l3, !tbaa !23
  %t21 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t25 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t19, i32 %t20, i64 %t21)
  store i32 %t25, ptr %l20
  br label %bb5
bb5:
  %t26 = load i32, ptr %l20, !tbaa !23
  store i32 %t26, ptr %l13, !tbaa !23
  br label %bb6
bb6:
  %t27 = load i32, ptr %l13, !tbaa !23
  store i32 %t27, ptr %l4, !tbaa !23
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load i32, ptr %l3, !tbaa !23
  %t32 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t28, i32 %t29)
  store i1 %t32, ptr %l23
  br label %bb7
bb7:
  %t33 = load i1, ptr %l23, !tbaa !21
  br i1 %t33, label %bb8, label %bb9
bb8:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/check:Checker", ptr %t34, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t39 = getelementptr %"compiler/generic:Program", ptr %t37, i32 0, i32 2
  %t40 = load i32, ptr %l3, !tbaa !23
  %t43 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t39, i32 %t40)
  store i64 %t43, ptr %l29
  br label %bb10
bb9:
  store i1 false, ptr %l24, !tbaa !21
  br label %bb11
bb10:
  %t44 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t45 = load i64, ptr %l29, !tbaa !24
  %t47 = and i64 %t45, %t44
  %t49 = icmp ne i64 %t47, 0
  store i1 %t49, ptr %l24, !tbaa !21
  br label %bb11
bb11:
  %t51 = load i1, ptr %l24, !tbaa !21
  br i1 %t51, label %bb12, label %bb13
bb12:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load ptr, ptr %l2, !tbaa !29
  %t57 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroRef(ptr %v0, ptr %v1, ptr %t52, ptr %t53)
  store i1 %t57, ptr %l37
  br label %bb14
bb13:
  store i1 false, ptr %l33, !tbaa !21
  br label %bb15
bb14:
  %t58 = load i1, ptr %l37, !tbaa !21
  store i1 %t58, ptr %l33, !tbaa !21
  br label %bb15
bb15:
  %t59 = load i1, ptr %l33, !tbaa !21
  br i1 %t59, label %bb16, label %bb17
bb16:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/check:Checker", ptr %t60, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !29
  %t65 = getelementptr %"compiler/generic:Program", ptr %t63, i32 0, i32 2
  store ptr %t65, ptr %l40, !tbaa !29
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/check:Checker", ptr %t66, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !29
  %t71 = getelementptr %"compiler/generic:Program", ptr %t69, i32 0, i32 2
  %t72 = load i32, ptr %l3, !tbaa !23
  %t75 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t71, i32 %t72)
  store i32 %t75, ptr %l45
  br label %bb18
bb17:
  br label %bb21
bb18:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/check:Checker", ptr %t76, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !29
  %t81 = getelementptr %"compiler/generic:Program", ptr %t79, i32 0, i32 2
  %t82 = load i32, ptr %l3, !tbaa !23
  %t85 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t81, i32 %t82)
  store i64 %t85, ptr %l50
  br label %bb19
bb19:
  %t86 = load i64, ptr @G_2ecompiler_2ftypes_2eOwning, !tbaa !24
  %t87 = load i64, ptr %l50, !tbaa !24
  %t89 = and i64 %t87, %t86
  %t90 = load ptr, ptr %l40, !tbaa !29
  %t91 = load i32, ptr %l45, !tbaa !23
  %t93 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t90, i32 %t91, i64 %t89)
  store i32 %t93, ptr %l53
  br label %bb20
bb20:
  %t94 = load i32, ptr %l53, !tbaa !23
  store i32 %t94, ptr %l4, !tbaa !23
  br label %bb21
bb21:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t96 = load %"compiler/source:Span", ptr %l1
  %t97 = load i32, ptr %l4, !tbaa !23
  %t101 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t95, %"compiler/source:Span" %t96, i32 %t97)
  store i64 %t101, ptr %l57
  br label %bb22
bb22:
  %t102 = load i64, ptr %l57, !tbaa !24
  store i64 %t102, ptr %l5, !tbaa !24
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t105 = getelementptr %"compiler/check:Checker", ptr %t103, i32 0, i32 68
  store ptr %t105, ptr %l59, !tbaa !29
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t107 = load i64, ptr %l5, !tbaa !24
  %t110 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroKey(ptr %v0, ptr %t106, i64 %t107)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t110, ptr %l62
  br label %bb23
bb23:
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t112 = load i32, ptr %l3, !tbaa !23
  %t115 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t111, i32 %t112)
  store i1 %t115, ptr %l65
  br label %bb24
bb24:
  %t116 = load i1, ptr %l65, !tbaa !21
  br i1 %t116, label %bb25, label %bb26
bb25:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t118 = load ptr, ptr %l2, !tbaa !29
  %t122 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroRef(ptr %v0, ptr %v1, ptr %t117, ptr %t118)
  store i1 %t122, ptr %l70
  br label %bb27
bb26:
  %t123 = load ptr, ptr %l0, !tbaa !29
  store ptr %t123, ptr %l71, !tbaa !29
  %t124 = load ptr, ptr %l2, !tbaa !29
  %t126 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v1, ptr %v1, ptr %t124)
  store ptr %t126, ptr %l73
  br label %bb28
bb27:
  %t127 = load i1, ptr %l70, !tbaa !21
  store i1 %t127, ptr %l66, !tbaa !21
  br label %bb30
bb28:
  %t128 = load ptr, ptr %l71, !tbaa !29
  %t129 = load ptr, ptr %l73, !tbaa !29
  %t130 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroPlace(ptr %v0, ptr %v1, ptr %t128, ptr %t129)
  store i1 %t130, ptr %l74
  br label %bb29
bb29:
  %t131 = load i1, ptr %l74, !tbaa !21
  store i1 %t131, ptr %l66, !tbaa !21
  br label %bb30
bb30:
  %t132 = load ptr, ptr %l59, !tbaa !29
  %t133 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l62
  %t134 = load i1, ptr %l66, !tbaa !21
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %t132, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t133, i1 %t134)
  br label %bb31
bb31:
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t136 = load ptr, ptr %l2, !tbaa !29
  %t137 = load i32, ptr %l4, !tbaa !23
  %t138 = load %"compiler/source:Span", ptr %l1
  %t143 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v1, ptr %v0, ptr %t135, ptr %t136, i32 %t137, %"compiler/source:Span" %t138)
  store ptr %t143, ptr %l79
  br label %bb32
bb32:
  %t144 = load ptr, ptr %l79, !tbaa !29
  store ptr %t144, ptr %l6, !tbaa !29
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t146 = load i64, ptr %l5, !tbaa !24
  %t147 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroTrack(ptr %v0, ptr %v0, ptr %t145, i64 %t146, ptr %t147)
  br label %bb33
bb33:
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t153 = load %"compiler/source:Span", ptr %l1
  %t154 = load i64, ptr %l5, !tbaa !24
  %t156 = trunc i64 %t154 to i32
  %t158 = load ptr, ptr %l6, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t159
  %t160 = getelementptr { i64, [3 x i64] }, ptr %t159, i32 0, i32 0
  store i64 0, ptr %t160
  %t162 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t153, 0
  %t164 = insertvalue { %"compiler/source:Span", i32, ptr } %t162, i32 %t156, 1
  %t166 = insertvalue { %"compiler/source:Span", i32, ptr } %t164, ptr %t158, 2
  %t167 = getelementptr { i64, [3 x i64] }, ptr %t159, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t166, ptr %t167
  %t168 = load { i64, [3 x i64] }, ptr %t159
  %t170 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t168, ptr %t170
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t152, ptr %t170)
  br label %bb34
bb34:
  %t173 = load i64, ptr %l5, !tbaa !24
  store i64 %t173, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallValue(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, ptr %a3, { i64, ptr } %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l12 = alloca i32
  %l20 = alloca ptr
  %l25 = alloca i32
  %l28 = alloca ptr
  %l29 = alloca %"compiler/source:Span"
  %l30 = alloca %"compiler/source:Span"
  %l31 = alloca i32
  %l34 = alloca ptr
  %l35 = alloca { i64, ptr }
  %l39 = alloca ptr
  %l41 = alloca ptr
  %l44 = alloca i32
  %l49 = alloca i32
  %l50 = alloca i64
  %l54 = alloca ptr
  %l57 = alloca i32
  %l62 = alloca i32
  %l63 = alloca i64
  %l64 = alloca ptr
  %l65 = alloca i64
  %l66 = alloca i32
  %l67 = alloca %"compiler/source:Span"
  %l70 = alloca { i64, ptr }
  %l71 = alloca { i64, ptr }
  %l73 = alloca i1
  %l76 = alloca ptr
  %l77 = alloca %"compiler/source:Span"
  %l78 = alloca %"compiler/source:Span"
  %l79 = alloca i64
  %l81 = alloca ptr
  %l82 = alloca { i64, ptr }
  %l85 = alloca { i64, ptr }
  %l89 = alloca ptr
  %l93 = alloca ptr
  %l95 = alloca ptr
  %l98 = alloca ptr
  %l111 = alloca i1
  %l112 = alloca { i64, ptr }
  %l121 = alloca i1
  %l122 = alloca { i64, ptr }
  %l127 = alloca i1
  %l128 = alloca { i64, ptr }
  %l132 = alloca ptr
  %l136 = alloca %"compiler/source:Span"
  %l137 = alloca %"compiler/msgs:Msg"
  %l138 = alloca i64
  %l143 = alloca ptr
  %l146 = alloca i1
  %l147 = alloca { i64, ptr }
  %l153 = alloca i1
  %l156 = alloca i32
  %l158 = alloca i32
  %l160 = alloca i1
  %l161 = alloca { i64, ptr }
  %l166 = alloca ptr
  %l169 = alloca %"compiler/source:Span"
  %l170 = alloca %"compiler/msgs:Msg"
  %l171 = alloca i64
  %l176 = alloca ptr
  %l177 = alloca ptr
  %l178 = alloca %"compiler/source:Span"
  %l181 = alloca { i64, ptr }
  %l183 = alloca %"compiler/msgs:Msg"
  %l184 = alloca i64
  %l189 = alloca ptr
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca ptr
  %t42 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  store ptr %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l3, !tbaa !29
  %t4 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t1)
  store i32 %t4, ptr %l12
  br label %bb1
bb1:
  %t5 = load i32, ptr %l12, !tbaa !23
  store i32 %t5, ptr %l5, !tbaa !23
  %t6 = load i32, ptr %l5, !tbaa !23
  %t7 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t10 = icmp eq i32 %t6, %t7
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load { i64, ptr }, ptr %l4, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v2, ptr %t12, { i64, ptr } %t13)
  br label %bb4
bb3:
  br label %bb6
bb4:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load %"compiler/source:Span", ptr %l1
  %t20 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v3, ptr %t16, %"compiler/source:Span" %t17)
  store ptr %t20, ptr %l20
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  %t21 = load ptr, ptr %l20, !tbaa !29
  store ptr %t21, ptr %rv
  br label %ret
bb6:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/check:Checker", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/generic:Program", ptr %t25, i32 0, i32 2
  %t28 = load i32, ptr %l5, !tbaa !23
  %t31 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t27, i32 %t28)
  store i32 %t31, ptr %l25
  br label %bb7
bb7:
  %t32 = load i32, ptr %l25, !range !{i32 0, i32 33}
  %t34 = trunc i64 21 to i32
  %t35 = icmp eq i32 %t32, %t34
  br i1 %t35, label %bb8, label %bb9
bb8:
  %t37 = load ptr, ptr %l0, !tbaa !29
  store ptr %t37, ptr %l28, !tbaa !29
  %t38 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t38, ptr %l29
  %t39 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t39, ptr %l30
  %t40 = load i32, ptr %l5, !tbaa !23
  store i32 %t40, ptr %l31, !tbaa !23
  %t41 = load ptr, ptr %l3, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t42
  %t43 = getelementptr { i64, [3 x i64] }, ptr %t42, i32 0, i32 0
  store i64 2, ptr %t43
  %t45 = insertvalue { ptr } undef, ptr %t41, 0
  %t46 = getelementptr { i64, [3 x i64] }, ptr %t42, i32 0, i32 1
  store { ptr } %t45, ptr %t46
  %t47 = load { i64, [3 x i64] }, ptr %t42
  %t49 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 32, i64 8)
  store { i64, [3 x i64] } %t47, ptr %t49
  store ptr %t49, ptr %l34, !tbaa !29
  %t50 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t50, ptr %l35, !tbaa !27
  %t51 = icmp sge i64 0, 0
  br i1 %t51, label %bb10, label %bb11
bb9:
  br label %bb15
bb10:
  %t53 = icmp sle i64 0, 1152921504606846975
  br i1 %t53, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_c23231398495940d_3184fca2d3133de9)
  unreachable
bb12:
  %t55 = mul i64 0, 8
  %t56 = insertvalue { i64, ptr } undef, i64 0, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t58 = load ptr, ptr %l28, !tbaa !29
  %t59 = load %"compiler/source:Span", ptr %l29
  %t60 = load %"compiler/source:Span", ptr %l30
  %t61 = load i32, ptr %l31, !tbaa !23
  %t62 = load ptr, ptr %l34, !tbaa !29
  %t63 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t65 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallBody(ptr %v0, ptr %v3, ptr %v0, ptr %v2, ptr %v0, ptr %v3, ptr %t58, %"compiler/source:Span" %t59, %"compiler/source:Span" %t60, i32 %t61, ptr %t62, i64 -1, ptr null, { i64, ptr } %t63, { i64, ptr } %t57)
  store ptr %t65, ptr %l39
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_c23231398495940d_3184fca2d3133de9)
  unreachable
bb14:
  call void @__olang_scope_close(ptr %s0)
  %t66 = load ptr, ptr %l39, !tbaa !29
  store ptr %t66, ptr %rv
  br label %ret
bb15:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/check:Checker", ptr %t67, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !29
  store ptr %t70, ptr %l41, !tbaa !29
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = load i32, ptr %l5, !tbaa !23
  %t75 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t71, i32 %t72)
  store i32 %t75, ptr %l44
  br label %bb16
bb16:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/check:Checker", ptr %t76, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !29
  %t81 = getelementptr %"compiler/generic:Program", ptr %t79, i32 0, i32 0
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t84 = getelementptr %"compiler/load:Loader", ptr %t82, i32 0, i32 3
  %t85 = load ptr, ptr %t84, !tbaa !29
  %t87 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %s0, ptr %t85, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d5, i32 0, i32 1) })
  store i32 %t87, ptr %l49
  br label %bb17
bb17:
  %t88 = load ptr, ptr %l41, !tbaa !29
  %t89 = load i32, ptr %l44, !tbaa !23
  %t90 = load i32, ptr %l49, !tbaa !23
  %t91 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t88, i32 %t89, i32 %t90)
  store i64 %t91, ptr %l50
  br label %bb18
bb18:
  %t92 = load i64, ptr %l50, !tbaa !24
  store i64 %t92, ptr %l6, !tbaa !24
  %t93 = load i64, ptr %l6, !tbaa !24
  %t95 = icmp slt i64 %t93, 0
  br i1 %t95, label %bb19, label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s3
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/check:Checker", ptr %t97, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !29
  store ptr %t100, ptr %l54, !tbaa !29
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t102 = load i32, ptr %l5, !tbaa !23
  %t105 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t101, i32 %t102)
  store i32 %t105, ptr %l57
  br label %bb21
bb20:
  br label %bb24
bb21:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = getelementptr %"compiler/check:Checker", ptr %t106, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !29
  %t111 = getelementptr %"compiler/generic:Program", ptr %t109, i32 0, i32 0
  %t112 = load ptr, ptr %t111, !tbaa !29
  %t114 = getelementptr %"compiler/load:Loader", ptr %t112, i32 0, i32 3
  %t115 = load ptr, ptr %t114, !tbaa !29
  %t117 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %s3, ptr %t115, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d6, i32 0, i32 1) })
  store i32 %t117, ptr %l62
  br label %bb22
bb22:
  %t118 = load ptr, ptr %l54, !tbaa !29
  %t119 = load i32, ptr %l57, !tbaa !23
  %t120 = load i32, ptr %l62, !tbaa !23
  %t121 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t118, i32 %t119, i32 %t120)
  store i64 %t121, ptr %l63
  br label %bb23
bb23:
  %t122 = load i64, ptr %l63, !tbaa !24
  store i64 %t122, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb24
bb24:
  %t123 = load ptr, ptr %l0, !tbaa !29
  store ptr %t123, ptr %l64, !tbaa !29
  %t124 = load i64, ptr %l6, !tbaa !24
  store i64 %t124, ptr %l65, !tbaa !24
  %t125 = load i32, ptr %l5, !tbaa !23
  store i32 %t125, ptr %l66, !tbaa !23
  %t126 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t126, ptr %l67
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t128 = load %"compiler/source:Span", ptr %l2
  %t131 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v0, ptr %t127, %"compiler/source:Span" %t128)
  store { i64, ptr } %t131, ptr %l70
  br label %bb25
bb25:
  %t132 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t133 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %s0, { i64, ptr } %t132)
  store { i64, ptr } %t133, ptr %l71
  br label %bb26
bb26:
  %t134 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t135 = extractvalue { i64, ptr } %t134, 0
  %t136 = extractvalue { i64, ptr } %t134, 1
  %t137 = mul i64 %t135, 1
  %t138 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t137)
  call void @llvm.memcpy.p0.p0.i64(ptr %t138, ptr %t136, i64 %t137, i1 false)
  %t139 = insertvalue { i64, ptr } undef, i64 %t135, 0
  %t140 = insertvalue { i64, ptr } %t139, ptr %t138, 1
  %t141 = load ptr, ptr %l64, !tbaa !29
  %t142 = load i64, ptr %l65, !tbaa !24
  %t143 = load i32, ptr %l66, !tbaa !23
  %t144 = load %"compiler/source:Span", ptr %l67
  %t146 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprivateRole(ptr %v0, ptr %s0, ptr %s0, ptr %t141, i64 %t142, i32 %t143, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d7, i32 0, i32 1) }, %"compiler/source:Span" %t144, { i64, ptr } %t140)
  store i1 %t146, ptr %l73
  br label %bb27
bb27:
  %t147 = load i64, ptr %l6, !tbaa !24
  %t149 = icmp sge i64 %t147, 0
  br i1 %t149, label %bb28, label %bb29
bb28:
  %t151 = load ptr, ptr %l0, !tbaa !29
  store ptr %t151, ptr %l76, !tbaa !29
  %t152 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t152, ptr %l77
  %t153 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t153, ptr %l78
  %t154 = load i64, ptr %l6, !tbaa !24
  store i64 %t154, ptr %l79, !tbaa !24
  %t155 = load ptr, ptr %l3, !tbaa !29
  store ptr %t155, ptr %l81, !tbaa !29
  %t157 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t157, ptr %l82, !tbaa !27
  %t158 = icmp sge i64 0, 0
  br i1 %t158, label %bb30, label %bb31
bb29:
  br label %bb39
bb30:
  %t160 = icmp sle i64 0, 1152921504606846975
  br i1 %t160, label %bb32, label %bb33
bb31:
  call void @__olang_check_failed(ptr @olang_loc_dec816aeadd109e0_adcbe0bcced90c1c)
  unreachable
bb32:
  %t162 = mul i64 0, 8
  %t163 = insertvalue { i64, ptr } undef, i64 0, 0
  %t164 = insertvalue { i64, ptr } %t163, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t164, ptr %l85, !tbaa !27
  %t165 = icmp sge i64 0, 0
  br i1 %t165, label %bb34, label %bb35
bb33:
  call void @__olang_check_failed(ptr @olang_loc_dec816aeadd109e0_adcbe0bcced90c1c)
  unreachable
bb34:
  %t167 = icmp sle i64 0, 2305843009213693951
  br i1 %t167, label %bb36, label %bb37
bb35:
  call void @__olang_check_failed(ptr @olang_loc_98ffdf46f6e43303_7907d8ed59f5817f)
  unreachable
bb36:
  %t169 = mul i64 0, 4
  %t170 = insertvalue { i64, ptr } undef, i64 0, 0
  %t171 = insertvalue { i64, ptr } %t170, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t172 = load ptr, ptr %l76, !tbaa !29
  %t173 = load %"compiler/source:Span", ptr %l77
  %t174 = load %"compiler/source:Span", ptr %l78
  %t175 = load i64, ptr %l79, !tbaa !24
  %t176 = load ptr, ptr %l81, !tbaa !29
  %t177 = load { i64, ptr }, ptr %l82, !tbaa !27
  %t178 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t180 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v1, ptr %v2, ptr %v0, ptr %v3, ptr %v3, ptr %t172, %"compiler/source:Span" %t173, %"compiler/source:Span" %t174, i64 %t175, ptr %t176, { i64, ptr } %t177, { i64, ptr } %t178, { i64, ptr } %t171)
  store ptr %t180, ptr %l89
  br label %bb38
bb37:
  call void @__olang_check_failed(ptr @olang_loc_98ffdf46f6e43303_7907d8ed59f5817f)
  unreachable
bb38:
  call void @__olang_scope_close(ptr %s0)
  %t181 = load ptr, ptr %l89, !tbaa !29
  store ptr %t181, ptr %rv
  br label %ret
bb39:
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t184 = getelementptr %"compiler/check:Checker", ptr %t182, i32 0, i32 1
  %t185 = load ptr, ptr %t184, !tbaa !29
  %t187 = getelementptr %"compiler/generic:Program", ptr %t185, i32 0, i32 0
  %t188 = load ptr, ptr %t187, !tbaa !29
  %t190 = getelementptr %"compiler/load:Loader", ptr %t188, i32 0, i32 10
  store ptr %t190, ptr %l93, !tbaa !29
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t193 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t191)
  store ptr %t193, ptr %l95
  br label %bb40
bb40:
  %t194 = load ptr, ptr %l95, !tbaa !29
  %t196 = getelementptr %"compiler/check:frame", ptr %t194, i32 0, i32 1
  %t197 = load i64, ptr %t196, !tbaa !24
  %t198 = load ptr, ptr %l93, !tbaa !29
  %t200 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t198, i64 %t197)
  store ptr %t200, ptr %l98
  br label %bb41
bb41:
  %t201 = load ptr, ptr %l98, !tbaa !29
  %t203 = getelementptr %"compiler/load:Module", ptr %t201, i32 0, i32 6
  %t204 = load ptr, ptr %t203, !tbaa !29
  store ptr %t204, ptr %l7, !tbaa !29
  %t206 = load ptr, ptr %l7, !tbaa !29
  %t208 = icmp eq ptr %t206, null
  br i1 %t208, label %bb42, label %bb43
bb42:
  call void @__olang_check_failed(ptr @olang_loc_4b3a1421aaa5396_3ffde41a88bcce4a)
  unreachable
bb43:
  br label %bb44
bb44:
  %t210 = load ptr, ptr %l7, !tbaa !29
  %t213 = getelementptr %"compiler/source:Source", ptr %t210, i32 0, i32 1
  %t214 = load { i64, ptr }, ptr %t213, !tbaa !27
  store { i64, ptr } %t214, ptr %l8, !tbaa !27
  %t216 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t217 = load i32, ptr %t216, !tbaa !23
  %t219 = sext i32 %t217 to i64
  %t221 = sub i64 %t219, 1
  store i64 %t221, ptr %l9, !tbaa !24
  br label %bb45
bb45:
  %t223 = load i64, ptr %l9, !tbaa !24
  %t225 = icmp sgt i64 %t223, 0
  br i1 %t225, label %bb46, label %bb47
bb46:
  %t227 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t227, ptr %l112, !tbaa !27
  %t228 = load i64, ptr %l9, !tbaa !24
  %t230 = getelementptr { i64, ptr }, ptr %l112, i32 0, i32 1
  %t231 = load ptr, ptr %t230, !tbaa !27
  %t232 = getelementptr i8, ptr %t231, i64 %t228
  %t233 = load i8, ptr %t232, !tbaa !32
  %t235 = icmp eq i8 %t233, 32
  store i1 %t235, ptr %l111, !tbaa !21
  br label %bb48
bb47:
  store i1 false, ptr %l111, !tbaa !21
  br label %bb48
bb48:
  %t237 = load i1, ptr %l111, !tbaa !21
  %t238 = xor i1 %t237, true
  br i1 %t238, label %bb49, label %bb50
bb49:
  br label %bb53
bb50:
  br label %bb51
bb51:
  %t240 = load i64, ptr %l9, !tbaa !24
  %t242 = sub i64 %t240, 1
  store i64 %t242, ptr %l9, !tbaa !24
  br label %bb52
bb52:
  br label %bb45
bb53:
  %t244 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t245 = load i32, ptr %t244, !tbaa !23
  %t247 = icmp sgt i32 %t245, 0
  br i1 %t247, label %bb54, label %bb55
bb54:
  %t249 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t249, ptr %l122, !tbaa !27
  %t250 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t251 = load i32, ptr %t250, !tbaa !23
  %t253 = sext i32 %t251 to i64
  %t255 = getelementptr { i64, ptr }, ptr %l122, i32 0, i32 1
  %t256 = load ptr, ptr %t255, !tbaa !27
  %t257 = getelementptr i8, ptr %t256, i64 %t253
  %t258 = load i8, ptr %t257, !tbaa !32
  %t260 = icmp eq i8 %t258, 40
  store i1 %t260, ptr %l121, !tbaa !21
  br label %bb56
bb55:
  store i1 false, ptr %l121, !tbaa !21
  br label %bb56
bb56:
  %t262 = load i1, ptr %l121, !tbaa !21
  br i1 %t262, label %bb57, label %bb58
bb57:
  %t263 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t263, ptr %l128, !tbaa !27
  %t264 = load i64, ptr %l9, !tbaa !24
  %t266 = getelementptr { i64, ptr }, ptr %l128, i32 0, i32 1
  %t267 = load ptr, ptr %t266, !tbaa !27
  %t268 = getelementptr i8, ptr %t267, i64 %t264
  %t269 = load i8, ptr %t268, !tbaa !32
  %t271 = icmp eq i8 %t269, 34
  store i1 %t271, ptr %l127, !tbaa !21
  br label %bb59
bb58:
  store i1 false, ptr %l127, !tbaa !21
  br label %bb59
bb59:
  %t273 = load i1, ptr %l127, !tbaa !21
  br i1 %t273, label %bb60, label %bb61
bb60:
  store %olang.scope zeroinitializer, ptr %s6
  %t274 = load ptr, ptr %l0, !tbaa !29
  store ptr %t274, ptr %l132, !tbaa !29
  %t275 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t276 = load i32, ptr %t275, !tbaa !23
  %t277 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t278 = load i32, ptr %t277, !tbaa !23
  %t280 = add i32 %t278, 1
  %t283 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s6, i32 %t276, i32 %t280)
  store %"compiler/source:Span" %t283, ptr %l136
  br label %bb62
bb61:
  br label %bb67
bb62:
  %t284 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eJoinPieceCalled(ptr %s6)
  store %"compiler/msgs:Msg" %t284, ptr %l137
  br label %bb63
bb63:
  %t285 = load ptr, ptr %l132, !tbaa !29
  %t286 = load %"compiler/source:Span", ptr %l136
  %t287 = load %"compiler/msgs:Msg", ptr %l137
  %t288 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s6, ptr %t285, %"compiler/source:Span" %t286, %"compiler/msgs:Msg" %t287)
  store i64 %t288, ptr %l138
  br label %bb64
bb64:
  %t289 = load ptr, ptr %l0, !tbaa !29
  %t290 = load { i64, ptr }, ptr %l4, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v2, ptr %t289, { i64, ptr } %t290)
  br label %bb65
bb65:
  %t293 = load ptr, ptr %l0, !tbaa !29
  %t294 = load %"compiler/source:Span", ptr %l1
  %t297 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v3, ptr %t293, %"compiler/source:Span" %t294)
  store ptr %t297, ptr %l143
  br label %bb66
bb66:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t298 = load ptr, ptr %l143, !tbaa !29
  store ptr %t298, ptr %rv
  br label %ret
bb67:
  %t299 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t300 = load i32, ptr %t299, !tbaa !23
  %t302 = icmp sgt i32 %t300, 0
  br i1 %t302, label %bb68, label %bb69
bb68:
  %t304 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t304, ptr %l147, !tbaa !27
  %t305 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t306 = load i32, ptr %t305, !tbaa !23
  %t308 = sext i32 %t306 to i64
  %t310 = sub i64 %t308, 1
  %t312 = getelementptr { i64, ptr }, ptr %l147, i32 0, i32 1
  %t313 = load ptr, ptr %t312, !tbaa !27
  %t314 = getelementptr i8, ptr %t313, i64 %t310
  %t315 = load i8, ptr %t314, !tbaa !32
  %t317 = icmp eq i8 %t315, 36
  br i1 %t317, label %bb70, label %bb71
bb69:
  store i1 false, ptr %l146, !tbaa !21
  br label %bb78
bb70:
  %t319 = load ptr, ptr %l0, !tbaa !29
  %t320 = load i32, ptr %l5, !tbaa !23
  %t323 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t319, i32 %t320)
  store i32 %t323, ptr %l156
  br label %bb72
bb71:
  store i1 false, ptr %l153, !tbaa !21
  br label %bb74
bb72:
  %t324 = load ptr, ptr %l0, !tbaa !29
  %t326 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %t324)
  store i32 %t326, ptr %l158
  br label %bb73
bb73:
  %t327 = load i32, ptr %l156, !tbaa !23
  %t328 = load i32, ptr %l158, !tbaa !23
  %t329 = icmp eq i32 %t327, %t328
  store i1 %t329, ptr %l153, !tbaa !21
  br label %bb74
bb74:
  %t331 = load i1, ptr %l153, !tbaa !21
  br i1 %t331, label %bb75, label %bb76
bb75:
  store i1 true, ptr %l160, !tbaa !21
  br label %bb77
bb76:
  %t332 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t332, ptr %l161, !tbaa !27
  %t333 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t334 = load i32, ptr %t333, !tbaa !23
  %t336 = sext i32 %t334 to i64
  %t338 = getelementptr { i64, ptr }, ptr %l161, i32 0, i32 1
  %t339 = load ptr, ptr %t338, !tbaa !27
  %t340 = getelementptr i8, ptr %t339, i64 %t336
  %t341 = load i8, ptr %t340, !tbaa !32
  %t343 = icmp eq i8 %t341, 34
  store i1 %t343, ptr %l160, !tbaa !21
  br label %bb77
bb77:
  %t345 = load i1, ptr %l160, !tbaa !21
  store i1 %t345, ptr %l146, !tbaa !21
  br label %bb78
bb78:
  %t346 = load i1, ptr %l146, !tbaa !21
  br i1 %t346, label %bb79, label %bb80
bb79:
  store %olang.scope zeroinitializer, ptr %s7
  %t347 = load ptr, ptr %l0, !tbaa !29
  store ptr %t347, ptr %l166, !tbaa !29
  %t348 = load ptr, ptr %l0, !tbaa !29
  %t349 = load %"compiler/source:Span", ptr %l2
  %t352 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopAfter(ptr %v0, ptr %t348, %"compiler/source:Span" %t349, i64 1)
  store %"compiler/source:Span" %t352, ptr %l169
  br label %bb81
bb80:
  br label %bb86
bb81:
  %t353 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eJoinPieceCalled(ptr %s7)
  store %"compiler/msgs:Msg" %t353, ptr %l170
  br label %bb82
bb82:
  %t354 = load ptr, ptr %l166, !tbaa !29
  %t355 = load %"compiler/source:Span", ptr %l169
  %t356 = load %"compiler/msgs:Msg", ptr %l170
  %t357 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s7, ptr %t354, %"compiler/source:Span" %t355, %"compiler/msgs:Msg" %t356)
  store i64 %t357, ptr %l171
  br label %bb83
bb83:
  %t358 = load ptr, ptr %l0, !tbaa !29
  %t359 = load { i64, ptr }, ptr %l4, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v2, ptr %t358, { i64, ptr } %t359)
  br label %bb84
bb84:
  %t362 = load ptr, ptr %l0, !tbaa !29
  %t363 = load %"compiler/source:Span", ptr %l1
  %t366 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v3, ptr %t362, %"compiler/source:Span" %t363)
  store ptr %t366, ptr %l176
  br label %bb85
bb85:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  %t367 = load ptr, ptr %l176, !tbaa !29
  store ptr %t367, ptr %rv
  br label %ret
bb86:
  %t368 = load ptr, ptr %l0, !tbaa !29
  store ptr %t368, ptr %l177, !tbaa !29
  %t369 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t369, ptr %l178
  %t370 = load ptr, ptr %l0, !tbaa !29
  %t371 = load i32, ptr %l5, !tbaa !23
  %t374 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t370, i32 %t371)
  store { i64, ptr } %t374, ptr %l181
  br label %bb87
bb87:
  %t375 = load { i64, ptr }, ptr %l181, !tbaa !27
  %t376 = extractvalue { i64, ptr } %t375, 0
  %t377 = extractvalue { i64, ptr } %t375, 1
  %t378 = mul i64 %t376, 1
  %t379 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t378)
  call void @llvm.memcpy.p0.p0.i64(ptr %t379, ptr %t377, i64 %t378, i1 false)
  %t380 = insertvalue { i64, ptr } undef, i64 %t376, 0
  %t381 = insertvalue { i64, ptr } %t380, ptr %t379, 1
  %t383 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotCallable(ptr %s0, ptr %s0, { i64, ptr } %t381)
  store %"compiler/msgs:Msg" %t383, ptr %l183
  br label %bb88
bb88:
  %t384 = load ptr, ptr %l177, !tbaa !29
  %t385 = load %"compiler/source:Span", ptr %l178
  %t386 = load %"compiler/msgs:Msg", ptr %l183
  %t387 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s0, ptr %t384, %"compiler/source:Span" %t385, %"compiler/msgs:Msg" %t386)
  store i64 %t387, ptr %l184
  br label %bb89
bb89:
  %t388 = load ptr, ptr %l0, !tbaa !29
  %t389 = load { i64, ptr }, ptr %l4, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v2, ptr %t388, { i64, ptr } %t389)
  br label %bb90
bb90:
  %t392 = load ptr, ptr %l0, !tbaa !29
  %t393 = load %"compiler/source:Span", ptr %l1
  %t396 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v3, ptr %t392, %"compiler/source:Span" %t393)
  store ptr %t396, ptr %l189
  br label %bb91
bb91:
  call void @__olang_scope_close(ptr %s0)
  %t397 = load ptr, ptr %l189, !tbaa !29
  store ptr %t397, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseTypeWritten(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca %"compiler/names:Ref"
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca i1
  %l20 = alloca ptr
  %l22 = alloca ptr
  %l26 = alloca %"compiler/names:Ref"
  %l30 = alloca i1
  %l35 = alloca ptr
  %l37 = alloca ptr
  %l41 = alloca %"compiler/names:Ref"
  %l44 = alloca i1
  %l51 = alloca { i64, ptr }
  %l56 = alloca i1
  %l63 = alloca i32
  %l68 = alloca i1
  %l71 = alloca ptr
  %l73 = alloca %"compiler/source:Span"
  %l75 = alloca { i64, ptr }
  %l80 = alloca { i64, ptr }
  %l84 = alloca i64
  %l86 = alloca i64
  %l87 = alloca %"compiler/msgs:Msg"
  %l88 = alloca i64
  %s7 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i1 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l3
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t18, i32 0, i32 1
  %t20 = load { i64, ptr }, ptr %t19
  store { i64, ptr } %t20, ptr %l4, !tbaa !27
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr { i64, [5 x i64] }, ptr %t22, i32 0, i32 1
  %t25 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t24, i32 0, i32 2
  %t26 = load { i64, ptr }, ptr %t25
  store { i64, ptr } %t26, ptr %l5, !tbaa !27
  br label %bb5
bb4:
  br label %bb46
bb5:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/check:Checker", ptr %t28, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t33 = getelementptr %"compiler/generic:Program", ptr %t31, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !29
  store ptr %t34, ptr %l20, !tbaa !29
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t35)
  store ptr %t37, ptr %l22
  br label %bb6
bb6:
  %t38 = load ptr, ptr %l22, !tbaa !29
  %t40 = getelementptr %"compiler/check:frame", ptr %t38, i32 0, i32 2
  %t41 = load i64, ptr %t40, !tbaa !24
  %t42 = getelementptr %"compiler/source:Span", ptr %l3, i32 0, i32 0
  %t43 = load i32, ptr %t42, !tbaa !23
  %t44 = load ptr, ptr %l20, !tbaa !29
  %t47 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t44, i64 %t41, i32 %t43)
  store %"compiler/names:Ref" %t47, ptr %l26
  br label %bb7
bb7:
  %t48 = load %"compiler/names:Ref", ptr %l26
  store %"compiler/names:Ref" %t48, ptr %l6
  %t49 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t51 = extractvalue { i64, ptr } %t49, 0
  %t53 = icmp sgt i64 %t51, 1
  br i1 %t53, label %bb8, label %bb9
bb8:
  %t55 = getelementptr %"compiler/names:Ref", ptr %l6, i32 0, i32 0
  %t56 = load i32, ptr %t55, !range !{i32 0, i32 9}
  %t58 = trunc i64 0 to i32
  %t59 = icmp eq i32 %t56, %t58
  store i1 %t59, ptr %l30, !tbaa !21
  br label %bb10
bb9:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb10
bb10:
  %t61 = load i1, ptr %l30, !tbaa !21
  br i1 %t61, label %bb11, label %bb12
bb11:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/check:Checker", ptr %t62, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t67 = getelementptr %"compiler/generic:Program", ptr %t65, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !29
  store ptr %t68, ptr %l35, !tbaa !29
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t69)
  store ptr %t71, ptr %l37
  br label %bb13
bb12:
  br label %bb15
bb13:
  %t72 = load ptr, ptr %l37, !tbaa !29
  %t74 = getelementptr %"compiler/check:frame", ptr %t72, i32 0, i32 2
  %t75 = load i64, ptr %t74, !tbaa !24
  %t76 = getelementptr %"compiler/source:Span", ptr %l3, i32 0, i32 1
  %t77 = load i32, ptr %t76, !tbaa !23
  %t78 = load ptr, ptr %l35, !tbaa !29
  %t81 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eMember(ptr %v0, ptr %t78, i64 %t75, i32 %t77)
  store %"compiler/names:Ref" %t81, ptr %l41
  br label %bb14
bb14:
  %t82 = load %"compiler/names:Ref", ptr %l41
  store %"compiler/names:Ref" %t82, ptr %l6
  br label %bb15
bb15:
  %t83 = getelementptr %"compiler/names:Ref", ptr %l6, i32 0, i32 0
  %t84 = load i32, ptr %t83, !range !{i32 0, i32 9}
  %t86 = trunc i64 0 to i32
  %t87 = icmp eq i32 %t84, %t86
  br i1 %t87, label %bb16, label %bb17
bb16:
  %t89 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t91 = extractvalue { i64, ptr } %t89, 0
  %t93 = icmp eq i64 %t91, 1
  store i1 %t93, ptr %l44, !tbaa !21
  br label %bb18
bb17:
  store i1 false, ptr %l44, !tbaa !21
  br label %bb18
bb18:
  %t95 = load i1, ptr %l44, !tbaa !21
  br i1 %t95, label %bb19, label %bb20
bb19:
  %t96 = load i1, ptr %l2, !tbaa !21
  br i1 %t96, label %bb21, label %bb22
bb20:
  br label %bb25
bb21:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t99 = load %"compiler/source:Span", ptr %l3
  %t100 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t100, ptr %l51, !tbaa !27
  %t101 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !27
  %t103 = getelementptr i32, ptr %t102, i64 0
  %t104 = load i32, ptr %t103, !tbaa !33
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknownType(ptr %v0, ptr %t98, %"compiler/source:Span" %t99, i32 %t104)
  br label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb24
bb24:
  store i1 false, ptr %rv
  br label %ret
bb25:
  %t109 = getelementptr %"compiler/names:Ref", ptr %l6, i32 0, i32 0
  %t110 = load i32, ptr %t109, !range !{i32 0, i32 9}
  %t112 = trunc i64 4 to i32
  %t113 = icmp eq i32 %t110, %t112
  br i1 %t113, label %bb26, label %bb27
bb26:
  %t115 = getelementptr %"compiler/names:Ref", ptr %l6, i32 0, i32 2
  %t116 = load i64, ptr %t115, !tbaa !24
  %t118 = icmp sge i64 %t116, 0
  store i1 %t118, ptr %l56, !tbaa !21
  br label %bb28
bb27:
  store i1 false, ptr %l56, !tbaa !21
  br label %bb28
bb28:
  %t120 = load i1, ptr %l56, !tbaa !21
  br i1 %t120, label %bb29, label %bb30
bb29:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"compiler/check:Checker", ptr %t121, i32 0, i32 1
  %t124 = load ptr, ptr %t123, !tbaa !29
  %t125 = getelementptr %"compiler/names:Ref", ptr %l6, i32 0, i32 1
  %t126 = load i64, ptr %t125, !tbaa !24
  %t127 = getelementptr %"compiler/names:Ref", ptr %l6, i32 0, i32 2
  %t128 = load i64, ptr %t127, !tbaa !24
  %t132 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %t124, i64 %t126, i64 %t128)
  store i32 %t132, ptr %l63
  br label %bb31
bb30:
  br label %bb45
bb31:
  %t133 = load i32, ptr %l63, !tbaa !23
  store i32 %t133, ptr %l7, !tbaa !23
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr %"compiler/check:Checker", ptr %t134, i32 0, i32 1
  %t137 = load ptr, ptr %t136, !tbaa !29
  %t138 = load i32, ptr %l7, !tbaa !23
  %t139 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t143 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eArgsFit(ptr %v0, ptr %v1, ptr %t137, i32 %t138, { i64, ptr } %t139)
  store i1 %t143, ptr %l68
  br label %bb32
bb32:
  %t144 = load i1, ptr %l68, !tbaa !21
  %t145 = xor i1 %t144, true
  br i1 %t145, label %bb33, label %bb34
bb33:
  %t147 = load i1, ptr %l2, !tbaa !21
  br i1 %t147, label %bb35, label %bb36
bb34:
  br label %bb44
bb35:
  store %olang.scope zeroinitializer, ptr %s7
  %t149 = load ptr, ptr %l0, !tbaa !29
  store ptr %t149, ptr %l71, !tbaa !29
  %t150 = load ptr, ptr %l1, !tbaa !29
  %t152 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t150)
  store %"compiler/source:Span" %t152, ptr %l73
  br label %bb37
bb36:
  br label %bb43
bb37:
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t154 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t154, ptr %l75, !tbaa !27
  %t155 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t157 = extractvalue { i64, ptr } %t155, 0
  %t159 = sub i64 %t157, 1
  %t161 = getelementptr { i64, ptr }, ptr %l75, i32 0, i32 1
  %t162 = load ptr, ptr %t161, !tbaa !27
  %t163 = getelementptr i32, ptr %t162, i64 %t159
  %t164 = load i32, ptr %t163, !tbaa !33
  %t167 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t153, i32 %t164)
  store { i64, ptr } %t167, ptr %l80
  br label %bb38
bb38:
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t170 = getelementptr %"compiler/check:Checker", ptr %t168, i32 0, i32 1
  %t171 = load ptr, ptr %t170, !tbaa !29
  %t172 = load i32, ptr %l7, !tbaa !23
  %t175 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eWrittenArity(ptr %v0, ptr %t171, i32 %t172)
  store i64 %t175, ptr %l84
  br label %bb39
bb39:
  %t176 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t178 = call i64 @compiler_2fgeneric_2eWrittenTypes(ptr %v1, { i64, ptr } %t176)
  store i64 %t178, ptr %l86
  br label %bb40
bb40:
  %t179 = load { i64, ptr }, ptr %l80, !tbaa !27
  %t180 = load i64, ptr %l84, !tbaa !24
  %t181 = load i64, ptr %l86, !tbaa !24
  %t182 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeArgCount(ptr %v0, ptr %s7, { i64, ptr } %t179, i64 %t180, i64 %t181)
  store %"compiler/msgs:Msg" %t182, ptr %l87
  br label %bb41
bb41:
  %t183 = load ptr, ptr %l71, !tbaa !29
  %t184 = load %"compiler/source:Span", ptr %l73
  %t185 = load %"compiler/msgs:Msg", ptr %l87
  %t186 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s7, ptr %t183, %"compiler/source:Span" %t184, %"compiler/msgs:Msg" %t185)
  store i64 %t186, ptr %l88
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s7)
  br label %bb43
bb43:
  store i1 false, ptr %rv
  br label %ret
bb44:
  br label %bb45
bb45:
  store i1 true, ptr %rv
  br label %ret
bb46:
  br i1 true, label %bb47, label %bb48
bb47:
  br label %bb49
bb48:
  br label %bb50
bb49:
  store i1 true, ptr %rv
  br label %ret
bb50:
  call void @__olang_check_failed(ptr @olang_loc_cf2e89857dc93528_274c4670bc5b9eac)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtMatch(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l12 = alloca ptr
  %l16 = alloca ptr
  %l21 = alloca i1
  %l23 = alloca i1
  %l27 = alloca i1
  %l28 = alloca i32
  %l30 = alloca i1
  %l37 = alloca i64
  %l46 = alloca { i64, ptr }
  %l53 = alloca %"compiler/ast:Branch"
  %l59 = alloca %"compiler/source:Span"
  %l62 = alloca %"compiler/ast:If"
  %l67 = alloca %"compiler/source:Span"
  %l71 = alloca ptr
  %l76 = alloca %"compiler/ast:If"
  %t112 = alloca { i64, [4 x i64] }, align 8
  %t144 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l12
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l12, !tbaa !29
  %t6 = getelementptr %"compiler/check:frame", ptr %t4, i32 0, i32 58
  %t7 = load %"compiler/source:Span", ptr %t6
  store %"compiler/source:Span" %t7, ptr %l3
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t9)
  store ptr %t11, ptr %l16
  br label %bb2
bb2:
  %t12 = load ptr, ptr %l16, !tbaa !29
  %t14 = getelementptr %"compiler/check:frame", ptr %t12, i32 0, i32 59
  %t15 = load i64, ptr %t14, !tbaa !24
  store i64 %t15, ptr %l4, !tbaa !24
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t18 = load ptr, ptr %l2, !tbaa !29
  %t21 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrPinned(ptr %v0, ptr %v1, ptr %t17, ptr %t18)
  store i1 %t21, ptr %l21
  br label %bb3
bb3:
  %t22 = load i1, ptr %l21, !tbaa !21
  %t23 = xor i1 %t22, true
  br i1 %t23, label %bb4, label %bb5
bb4:
  br label %ret
bb5:
  br label %bb6
bb6:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = load ptr, ptr %l2, !tbaa !29
  %t31 = call { i32, i1 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtCases(ptr %v0, ptr %v1, ptr %t25, %"compiler/source:Span" %a1, ptr %t27)
  %t32 = extractvalue { i32, i1 } %t31, 1
  %t33 = extractvalue { i32, i1 } %t31, 0
  store i32 %t33, ptr %l28
  %t34 = icmp ne i32 %t33, 0
  br i1 %t34, label %bb8, label %ok.35, !prof !99
ok.35:
  store i1 %t32, ptr %l27
  br label %bb7
bb7:
  %t36 = load i1, ptr %l27, !tbaa !21
  store i1 %t36, ptr %l23, !tbaa !21
  br label %bb11
bb8:
  %t37 = load i32, ptr %l28, !tbaa !23
  %t38 = ashr i32 %t37, 16
  %t40 = icmp eq i32 %t38, 1
  store i1 %t40, ptr %l30, !tbaa !21
  br label %bb9
bb9:
  call void @__olang_ert_req_clear()
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load %"compiler/source:Span", ptr %l3
  %t43 = load i64, ptr %l4, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunpin(ptr %v0, ptr %t41, %"compiler/source:Span" %t42, i64 %t43)
  br label %bb10
bb10:
  br label %ret
bb11:
  %t47 = load i1, ptr %l23, !tbaa !21
  store ptr null, ptr %l6, !tbaa !29
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = load ptr, ptr %l2, !tbaa !29
  %t54 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtLast(ptr %v0, ptr %v1, ptr %t48, ptr %t49, i1 %t47)
  store i64 %t54, ptr %l37
  br label %bb12
bb12:
  %t55 = load i64, ptr %l37, !tbaa !24
  store i64 %t55, ptr %l7, !tbaa !24
  %t56 = load ptr, ptr %l2, !tbaa !29
  %t58 = getelementptr %"compiler/ast:Match", ptr %t56, i32 0, i32 3
  %t59 = load { i64, ptr }, ptr %t58, !tbaa !27
  %t61 = extractvalue { i64, ptr } %t59, 0
  %t63 = sub i64 %t61, 1
  store i64 %t63, ptr %l8, !tbaa !24
  br label %bb13
bb13:
  %t65 = load i64, ptr %l8, !tbaa !24
  %t67 = icmp sge i64 %t65, 0
  %t69 = xor i1 %t67, true
  br i1 %t69, label %bb14, label %bb15
bb14:
  br label %bb25
bb15:
  br label %bb16
bb16:
  %t71 = load ptr, ptr %l2, !tbaa !29
  %t73 = getelementptr %"compiler/ast:Match", ptr %t71, i32 0, i32 3
  %t74 = load { i64, ptr }, ptr %t73, !tbaa !27
  store { i64, ptr } %t74, ptr %l46, !tbaa !27
  %t75 = load i64, ptr %l8, !tbaa !24
  %t77 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = getelementptr ptr, ptr %t78, i64 %t75
  %t80 = load ptr, ptr %t79, !tbaa !39
  store ptr %t80, ptr %l9, !tbaa !29
  %t82 = load ptr, ptr %l9, !tbaa !29
  %t84 = getelementptr %"compiler/ast:Case", ptr %t82, i32 0, i32 0
  %t85 = load %"compiler/source:Span", ptr %t84
  %t86 = load ptr, ptr %l9, !tbaa !29
  %t88 = getelementptr %"compiler/ast:Case", ptr %t86, i32 0, i32 4
  %t89 = load { i64, ptr }, ptr %t88, !tbaa !27
  %t92 = call %"compiler/ast:Branch" @compiler_2fast_3aBranch_2ector(ptr %v1, ptr %v0, %"compiler/source:Span" %t85, { i64, ptr } %t89, i64 -1)
  store %"compiler/ast:Branch" %t92, ptr %l53
  br label %bb17
bb17:
  %t93 = load %"compiler/ast:Branch", ptr %l53
  %t94 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"compiler/ast:Branch" %t93, ptr %t94
  store ptr %t94, ptr %l10, !tbaa !29
  %t96 = load i64, ptr %l8, !tbaa !24
  %t97 = load i64, ptr %l7, !tbaa !24
  %t100 = icmp eq i64 %t96, %t97
  br i1 %t100, label %bb18, label %bb19
bb18:
  %t102 = load ptr, ptr %l9, !tbaa !29
  %t104 = getelementptr %"compiler/ast:Case", ptr %t102, i32 0, i32 0
  %t105 = load %"compiler/source:Span", ptr %t104
  store %"compiler/source:Span" %t105, ptr %l59
  %t106 = load ptr, ptr %l10, !tbaa !29
  %t109 = call %"compiler/ast:If" @compiler_2fast_3aIf_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr null, ptr %t106, ptr null)
  store %"compiler/ast:If" %t109, ptr %l62
  br label %bb20
bb19:
  br label %bb21
bb20:
  %t110 = load %"compiler/ast:If", ptr %l62
  %t111 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/ast:If" %t110, ptr %t111
  store { i64, [4 x i64] } zeroinitializer, ptr %t112
  %t113 = getelementptr { i64, [4 x i64] }, ptr %t112, i32 0, i32 0
  store i64 5, ptr %t113
  %t114 = load %"compiler/source:Span", ptr %l59
  %t115 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t114, 0
  %t117 = insertvalue { %"compiler/source:Span", ptr } %t115, ptr %t111, 1
  %t118 = getelementptr { i64, [4 x i64] }, ptr %t112, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t117, ptr %t118
  %t119 = load { i64, [4 x i64] }, ptr %t112
  %t121 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t119, ptr %t121
  store ptr %t121, ptr %l6, !tbaa !29
  br label %bb24
bb21:
  %t123 = load ptr, ptr %l9, !tbaa !29
  %t125 = getelementptr %"compiler/ast:Case", ptr %t123, i32 0, i32 0
  %t126 = load %"compiler/source:Span", ptr %t125
  store %"compiler/source:Span" %t126, ptr %l67
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t128 = load ptr, ptr %l2, !tbaa !29
  %t129 = load ptr, ptr %l9, !tbaa !29
  %t133 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtCaseTest(ptr %v0, ptr %v1, ptr %v1, ptr %v0, ptr %t127, ptr %t128, ptr %t129)
  store ptr %t133, ptr %l71
  br label %bb22
bb22:
  %t134 = load ptr, ptr %l71, !tbaa !29
  %t135 = load ptr, ptr %l10, !tbaa !29
  %t137 = load ptr, ptr %l6, !tbaa !29
  %t141 = call %"compiler/ast:If" @compiler_2fast_3aIf_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t134, ptr %t135, ptr %t137)
  store %"compiler/ast:If" %t141, ptr %l76
  br label %bb23
bb23:
  %t142 = load %"compiler/ast:If", ptr %l76
  %t143 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/ast:If" %t142, ptr %t143
  store { i64, [4 x i64] } zeroinitializer, ptr %t144
  %t145 = getelementptr { i64, [4 x i64] }, ptr %t144, i32 0, i32 0
  store i64 5, ptr %t145
  %t146 = load %"compiler/source:Span", ptr %l67
  %t147 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t146, 0
  %t149 = insertvalue { %"compiler/source:Span", ptr } %t147, ptr %t143, 1
  %t150 = getelementptr { i64, [4 x i64] }, ptr %t144, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t149, ptr %t150
  %t151 = load { i64, [4 x i64] }, ptr %t144
  %t153 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t151, ptr %t153
  store ptr %t153, ptr %l6, !tbaa !29
  br label %bb24
bb24:
  %t155 = load i64, ptr %l8, !tbaa !24
  %t157 = sub i64 %t155, 1
  store i64 %t157, ptr %l8, !tbaa !24
  br label %bb13
bb25:
  %t159 = load ptr, ptr %l6, !tbaa !29
  %t161 = icmp eq ptr %t159, null
  %t163 = xor i1 %t161, true
  br i1 %t163, label %bb26, label %bb27
bb26:
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t166 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmt(ptr %v0, ptr %v0, ptr %t165, ptr %t166)
  br label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb29
bb29:
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t171 = load %"compiler/source:Span", ptr %l3
  %t172 = load i64, ptr %l4, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunpin(ptr %v0, ptr %t170, %"compiler/source:Span" %t171, i64 %t172)
  br label %bb30
bb30:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtUsed(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i64
  %l7 = alloca i64
  %l15 = alloca ptr
  %l18 = alloca i64
  %l26 = alloca %"compiler/check:errBind"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 16
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_H2251bc8fca359ca0394d0bb11af7ba0a(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l7
  br label %bb1
bb1:
  %t6 = load i64, ptr %l7, !tbaa !24
  %t7 = sub i64 %t6, 1
  store i64 %t7, ptr %l2, !tbaa !24
  br label %bb2
bb2:
  %t9 = load i64, ptr %l2, !tbaa !24
  %t11 = icmp sge i64 %t9, 0
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb3, label %bb4
bb3:
  br label %bb20
bb4:
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/check:Checker", ptr %t15, i32 0, i32 16
  %t18 = load i64, ptr %l2, !tbaa !24
  %t21 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_Hc8503b2b20cde402cc7bde6f68d96fc0(ptr %v0, ptr %v0, ptr %t17, i64 %t18)
  store ptr %t21, ptr %l15
  br label %bb6
bb6:
  %t22 = load ptr, ptr %l15, !tbaa !29
  store ptr %t22, ptr %l3, !tbaa !29
  %t23 = load ptr, ptr %l3, !tbaa !29
  %t25 = getelementptr %"compiler/check:frame", ptr %t23, i32 0, i32 55
  %t27 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrBind_3e_2eLen_3ccompiler_2fcheck_3aerrBind_3e(ptr %v0, ptr %t25)
  store i64 %t27, ptr %l18
  br label %bb7
bb7:
  %t28 = load i64, ptr %l18, !tbaa !24
  %t29 = sub i64 %t28, 1
  store i64 %t29, ptr %l4, !tbaa !24
  br label %bb8
bb8:
  %t31 = load i64, ptr %l4, !tbaa !24
  %t33 = icmp sge i64 %t31, 0
  %t35 = xor i1 %t33, true
  br i1 %t35, label %bb9, label %bb10
bb9:
  br label %bb18
bb10:
  br label %bb11
bb11:
  %t37 = load ptr, ptr %l3, !tbaa !29
  %t39 = getelementptr %"compiler/check:frame", ptr %t37, i32 0, i32 55
  %t40 = load i64, ptr %l4, !tbaa !24
  %t43 = call %"compiler/check:errBind" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrBind_3e_2eAt_3ccompiler_2fcheck_3aerrBind_3e(ptr %v0, ptr %t39, i64 %t40)
  store %"compiler/check:errBind" %t43, ptr %l26
  br label %bb12
bb12:
  %t44 = getelementptr %"compiler/check:errBind", ptr %l26, i32 0, i32 0
  %t45 = load i32, ptr %t44, !tbaa !23
  %t49 = icmp eq i32 %t45, %a1
  br i1 %t49, label %bb13, label %bb14
bb13:
  %t51 = load ptr, ptr %l3, !tbaa !29
  %t53 = getelementptr %"compiler/check:frame", ptr %t51, i32 0, i32 56
  %t54 = load i64, ptr %l4, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t53, i64 %t54, i1 true)
  br label %bb15
bb14:
  br label %bb16
bb15:
  br label %ret
bb16:
  br label %bb17
bb17:
  %t57 = load i64, ptr %l4, !tbaa !24
  %t59 = sub i64 %t57, 1
  store i64 %t59, ptr %l4, !tbaa !24
  br label %bb8
bb18:
  %t61 = load ptr, ptr %l3, !tbaa !29
  %t63 = getelementptr %"compiler/check:frame", ptr %t61, i32 0, i32 19
  %t64 = load i64, ptr %t63, !tbaa !24
  store i64 %t64, ptr %l2, !tbaa !24
  br label %bb19
bb19:
  br label %bb2
bb20:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echarType(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca ptr
  %l7 = alloca i32
  %s1 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 52
  %t4 = load i32, ptr %t3, !tbaa !23
  %t6 = icmp slt i32 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t8 = load ptr, ptr %l0, !tbaa !29
  store ptr %t8, ptr %l4, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/check:Checker", ptr %t9, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePreludeType(ptr %v0, ptr %s1, ptr %s1, ptr %t12, { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d8, i32 0, i32 1) }, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d9, i32 0, i32 1) })
  store i32 %t14, ptr %l7
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t15 = load i32, ptr %l7, !tbaa !23
  %t16 = load ptr, ptr %l4, !tbaa !29
  %t17 = getelementptr %"compiler/check:Checker", ptr %t16, i32 0, i32 52
  store i32 %t15, ptr %t17, !tbaa !23
  call void @__olang_scope_close(ptr %s1)
  br label %bb4
bb4:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/check:Checker", ptr %t18, i32 0, i32 52
  %t21 = load i32, ptr %t20, !tbaa !23
  store i32 %t21, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echarValue(ptr %v0, ptr %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l10 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t5 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
  store { i64, ptr } %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t7 = call { i64, ptr } @compiler_2fscan_2eLiteralBytes(ptr %v0, ptr %s0, { i64, ptr } %t6)
  store { i64, ptr } %t7, ptr %l6
  br label %bb2
bb2:
  %t8 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t8, ptr %l2, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  %t13 = icmp sgt i64 %t11, 0
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t15 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !27
  %t17 = getelementptr i8, ptr %t16, i64 0
  %t18 = load i8, ptr %t17, !tbaa !32
  %t20 = zext i8 %t18 to i64
  store i64 %t20, ptr %l10, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l10, !tbaa !24
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  %t22 = load i64, ptr %l10, !tbaa !24
  store i64 %t22, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echosenAt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca ptr
  %l6 = alloca i1
  %l17 = alloca i1
  %l23 = alloca %"compiler/source:Span"
  %l27 = alloca i1
  %l33 = alloca %"compiler/source:Span"
  %l37 = alloca ptr
  %l43 = alloca %"compiler/source:Span"
  %l44 = alloca %"compiler/source:Span"
  %l45 = alloca ptr
  %l46 = alloca i1
  %l54 = alloca %"compiler/source:Span"
  %l55 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 11
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l2
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t18, i32 0, i32 2
  %t20 = load ptr, ptr %t19
  store ptr %t20, ptr %l3, !tbaa !29
  br label %bb5
bb4:
  br label %bb28
bb5:
  %t22 = load ptr, ptr %l3, !tbaa !29
  %t24 = getelementptr %"compiler/typed:Cond", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = icmp eq ptr %t25, null
  %t29 = xor i1 %t27, true
  br i1 %t29, label %bb6, label %bb7
bb6:
  %t31 = load ptr, ptr %l3, !tbaa !29
  %t33 = getelementptr %"compiler/typed:Cond", ptr %t31, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t36 = icmp eq ptr %t34, null
  br i1 %t36, label %bb8, label %bb9
bb7:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb12
bb8:
  call void @__olang_check_failed(ptr @olang_loc_d9d408bf8806a5b7_73d051fbfd3f3593)
  unreachable
bb9:
  br label %bb10
bb10:
  %t38 = load ptr, ptr %l3, !tbaa !29
  %t40 = getelementptr %"compiler/typed:Cond", ptr %t38, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t43 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t41)
  store %"compiler/source:Span" %t43, ptr %l23
  br label %bb11
bb11:
  %t44 = getelementptr %"compiler/source:Span", ptr %l23, i32 0, i32 1
  %t45 = load i32, ptr %t44, !tbaa !23
  %t46 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 1
  %t47 = load i32, ptr %t46, !tbaa !23
  %t50 = icmp sle i32 %t45, %t47
  store i1 %t50, ptr %l17, !tbaa !21
  br label %bb12
bb12:
  %t52 = load i1, ptr %l17, !tbaa !21
  br i1 %t52, label %bb13, label %bb14
bb13:
  %t53 = load ptr, ptr %l3, !tbaa !29
  %t55 = getelementptr %"compiler/typed:Cond", ptr %t53, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t58 = icmp eq ptr %t56, null
  br i1 %t58, label %bb15, label %bb16
bb14:
  store i1 false, ptr %l27, !tbaa !21
  br label %bb19
bb15:
  call void @__olang_check_failed(ptr @olang_loc_d9d408bf8806a5b7_73d051fbfd3f3593)
  unreachable
bb16:
  br label %bb17
bb17:
  %t60 = load ptr, ptr %l3, !tbaa !29
  %t62 = getelementptr %"compiler/typed:Cond", ptr %t60, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !29
  %t65 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t63)
  store %"compiler/source:Span" %t65, ptr %l33
  br label %bb18
bb18:
  %t66 = getelementptr %"compiler/source:Span", ptr %l33, i32 0, i32 0
  %t67 = load i32, ptr %t66, !tbaa !23
  %t68 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t69 = load i32, ptr %t68, !tbaa !23
  %t72 = icmp eq i32 %t67, %t69
  store i1 %t72, ptr %l27, !tbaa !21
  br label %bb19
bb19:
  %t74 = load i1, ptr %l27, !tbaa !21
  br i1 %t74, label %bb20, label %bb21
bb20:
  store ptr %a0, ptr %l37, !tbaa !29
  %t76 = load ptr, ptr %l3, !tbaa !29
  %t78 = getelementptr %"compiler/typed:Cond", ptr %t76, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !29
  %t81 = icmp eq ptr %t79, null
  br i1 %t81, label %bb22, label %bb23
bb21:
  br label %bb27
bb22:
  call void @__olang_check_failed(ptr @olang_loc_d9d408bf8806a5b7_73d051fbfd3f3593)
  unreachable
bb23:
  br label %bb24
bb24:
  %t83 = load ptr, ptr %l3, !tbaa !29
  %t85 = getelementptr %"compiler/typed:Cond", ptr %t83, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !29
  %t88 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t86)
  store %"compiler/source:Span" %t88, ptr %l43
  br label %bb25
bb25:
  %t89 = load ptr, ptr %l37, !tbaa !29
  %t90 = load %"compiler/source:Span", ptr %l43
  %t91 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopAfter(ptr %v0, ptr %t89, %"compiler/source:Span" %t90, i64 2)
  store %"compiler/source:Span" %t91, ptr %l44
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s0)
  %t92 = load %"compiler/source:Span", ptr %l44
  store %"compiler/source:Span" %t92, ptr %rv
  br label %ret
bb27:
  br label %bb40
bb28:
  %t93 = load ptr, ptr %l1, !tbaa !29
  store ptr %t93, ptr %l45, !tbaa !29
  store i1 false, ptr %l46, !tbaa !21
  %t94 = load ptr, ptr %l45, !tbaa !29
  %t95 = icmp ne ptr %t94, null
  br i1 %t95, label %bb29, label %bb30
bb29:
  %t97 = load ptr, ptr %l45, !tbaa !29
  %t98 = load i64, ptr %t97, !range !{i64 0, i64 18}
  %t100 = icmp eq i64 %t98, 13
  store i1 %t100, ptr %l46, !tbaa !21
  br label %bb30
bb30:
  %t101 = load i1, ptr %l46, !tbaa !21
  br i1 %t101, label %bb31, label %bb32
bb31:
  %t102 = load ptr, ptr %l1, !tbaa !29
  %t104 = getelementptr { i64, [5 x i64] }, ptr %t102, i32 0, i32 1
  %t105 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t104, i32 0, i32 0
  %t106 = load %"compiler/source:Span", ptr %t105
  store %"compiler/source:Span" %t106, ptr %l4
  br label %bb33
bb32:
  br label %bb35
bb33:
  store %olang.scope zeroinitializer, ptr %s3
  %t108 = getelementptr %"compiler/source:Span", ptr %l4, i32 0, i32 0
  %t109 = load i32, ptr %t108, !tbaa !23
  %t110 = getelementptr %"compiler/source:Span", ptr %l4, i32 0, i32 0
  %t111 = load i32, ptr %t110, !tbaa !23
  %t113 = add i32 %t111, 5
  %t116 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s3, i32 %t109, i32 %t113)
  store %"compiler/source:Span" %t116, ptr %l54
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t117 = load %"compiler/source:Span", ptr %l54
  store %"compiler/source:Span" %t117, ptr %rv
  br label %ret
bb35:
  br i1 true, label %bb36, label %bb37
bb36:
  br label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb40
bb39:
  call void @__olang_check_failed(ptr @olang_loc_c9813818497de78f_1a6747489dcf36eb)
  unreachable
bb40:
  %t118 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 -1, i32 -1)
  store %"compiler/source:Span" %t118, ptr %l55
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s0)
  %t119 = load %"compiler/source:Span", ptr %l55
  store %"compiler/source:Span" %t119, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclauseRules(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, ptr %a2, i1 %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l20 = alloca i1
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca %"compiler/typed:Item"
  %l26 = alloca i1
  %l27 = alloca i1
  %l28 = alloca i64
  %l38 = alloca i64
  %l41 = alloca i64
  %l59 = alloca { i64, ptr }
  %l64 = alloca ptr
  %l67 = alloca i1
  %l72 = alloca ptr
  %l75 = alloca ptr
  %l78 = alloca %"compiler/source:Span"
  %l79 = alloca %"compiler/msgs:Msg"
  %l80 = alloca i64
  %l84 = alloca i1
  %l88 = alloca i1
  %l93 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l98 = alloca i64
  %l101 = alloca i64
  %l119 = alloca ptr
  %l122 = alloca ptr
  %l133 = alloca { i64, ptr }
  %l138 = alloca i1
  %l141 = alloca i32
  %l147 = alloca i64
  %l149 = alloca i32
  %l153 = alloca i32
  %l159 = alloca ptr
  %l162 = alloca %"compiler/source:Span"
  %l163 = alloca %"compiler/msgs:Msg"
  %l164 = alloca i64
  %l173 = alloca ptr
  %l176 = alloca %"compiler/source:Span"
  %l177 = alloca %"compiler/msgs:Msg"
  %l178 = alloca i64
  %l184 = alloca ptr
  %l187 = alloca %"compiler/source:Span"
  %l188 = alloca %"compiler/msgs:Msg"
  %l189 = alloca i64
  %l195 = alloca i1
  %l201 = alloca i1
  %l203 = alloca i1
  %l205 = alloca ptr
  %l208 = alloca %"compiler/source:Span"
  %l209 = alloca %"compiler/msgs:Msg"
  %l210 = alloca i64
  %l214 = alloca i1
  %l221 = alloca i1
  %l224 = alloca i1
  %l225 = alloca ptr
  %l228 = alloca %"compiler/source:Span"
  %l229 = alloca %"compiler/msgs:Msg"
  %l230 = alloca i64
  %l233 = alloca i1
  %l238 = alloca i32
  %l243 = alloca ptr
  %l248 = alloca i32
  %l249 = alloca { i64, ptr }
  %l256 = alloca ptr
  %l259 = alloca %"compiler/source:Span"
  %l264 = alloca %"compiler/msgs:Msg"
  %l265 = alloca i64
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i32 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  store i64 0, ptr %l5, !tbaa !24
  %t8 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t8, 0
  store i64 %t10, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t12 = load i64, ptr %l6, !tbaa !24
  %t13 = load i64, ptr %l5, !tbaa !24
  %t16 = icmp sgt i64 %t12, %t13
  br i1 %t16, label %bb4, label %bb5
bb4:
  %t18 = load i64, ptr %l7, !tbaa !24
  %t20 = icmp sgt i64 %t18, 0
  br i1 %t20, label %bb6, label %bb7
bb5:
  store i64 0, ptr %l38, !tbaa !24
  br label %bb9
bb6:
  %t22 = load i64, ptr %l6, !tbaa !24
  %t23 = load i64, ptr %l5, !tbaa !24
  %t26 = sub i64 %t22, %t23
  %t27 = load i64, ptr %l7, !tbaa !24
  %t30 = add i64 %t26, %t27
  %t32 = sub i64 %t30, 1
  %t33 = load i64, ptr %l7, !tbaa !24
  %t36 = sdiv i64 %t32, %t33
  store i64 %t36, ptr %l41, !tbaa !24
  br label %bb8
bb7:
  store i64 0, ptr %l41, !tbaa !24
  br label %bb8
bb8:
  %t38 = load i64, ptr %l41, !tbaa !24
  store i64 %t38, ptr %l38, !tbaa !24
  br label %bb9
bb9:
  %t39 = load i64, ptr %l38, !tbaa !24
  store i64 %t39, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s3
  %t40 = load i64, ptr %l9, !tbaa !24
  %t41 = load i64, ptr %l8, !tbaa !24
  %t44 = icmp slt i64 %t40, %t41
  %t46 = xor i1 %t44, true
  br i1 %t46, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s3)
  br label %bb138
bb12:
  br label %bb13
bb13:
  %t48 = load i64, ptr %l5, !tbaa !24
  %t49 = load i64, ptr %l9, !tbaa !24
  %t50 = load i64, ptr %l7, !tbaa !24
  %t53 = mul i64 %t49, %t50
  %t56 = add i64 %t48, %t53
  store i64 %t56, ptr %l10, !tbaa !24
  %t58 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t58, ptr %l59, !tbaa !27
  %t59 = load i64, ptr %l10, !tbaa !24
  %t61 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !27
  %t63 = getelementptr ptr, ptr %t62, i64 %t59
  %t64 = load ptr, ptr %t63, !tbaa !39
  store ptr %t64, ptr %l11, !tbaa !29
  %t66 = load ptr, ptr %l2, !tbaa !29
  %t67 = load i64, ptr %l10, !tbaa !24
  %t70 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aClause_26_3e_2eAt_3ccompiler_2ftyped_3aClause_26_3e(ptr %v2, ptr %v2, ptr %t66, i64 %t67)
  store ptr %t70, ptr %l64
  br label %bb14
bb14:
  %t71 = load ptr, ptr %l64, !tbaa !29
  store ptr %t71, ptr %l12, !tbaa !29
  %t72 = load i64, ptr %l10, !tbaa !24
  %t74 = icmp sgt i64 %t72, 0
  br i1 %t74, label %bb15, label %bb16
bb15:
  %t76 = load ptr, ptr %l2, !tbaa !29
  %t78 = load i64, ptr %l10, !tbaa !24
  %t80 = sub i64 %t78, 1
  %t83 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aClause_26_3e_2eAt_3ccompiler_2ftyped_3aClause_26_3e(ptr %v2, ptr %s3, ptr %t76, i64 %t80)
  store ptr %t83, ptr %l72
  br label %bb17
bb16:
  store i1 false, ptr %l67, !tbaa !21
  br label %bb18
bb17:
  %t84 = load ptr, ptr %l72, !tbaa !29
  %t86 = getelementptr %"compiler/typed:Clause", ptr %t84, i32 0, i32 2
  %t87 = load i1, ptr %t86, !tbaa !21
  store i1 %t87, ptr %l67, !tbaa !21
  br label %bb18
bb18:
  %t89 = load i1, ptr %l67, !tbaa !21
  br i1 %t89, label %bb19, label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s4
  %t90 = load ptr, ptr %l0, !tbaa !29
  store ptr %t90, ptr %l75, !tbaa !29
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load ptr, ptr %l11, !tbaa !29
  %t95 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecatchSpan(ptr %v0, ptr %v1, ptr %t91, ptr %t92)
  store %"compiler/source:Span" %t95, ptr %l78
  br label %bb21
bb20:
  br label %bb24
bb21:
  %t96 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCatchAfterCatchAll(ptr %s4)
  store %"compiler/msgs:Msg" %t96, ptr %l79
  br label %bb22
bb22:
  %t97 = load ptr, ptr %l75, !tbaa !29
  %t98 = load %"compiler/source:Span", ptr %l78
  %t99 = load %"compiler/msgs:Msg", ptr %l79
  %t100 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s4, ptr %t97, %"compiler/source:Span" %t98, %"compiler/msgs:Msg" %t99)
  store i64 %t100, ptr %l80
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  store i1 true, ptr %rv
  br label %ret
bb24:
  %t102 = load i64, ptr %l10, !tbaa !24
  %t104 = icmp sgt i64 %t102, 0
  br i1 %t104, label %bb25, label %bb26
bb25:
  %t106 = load ptr, ptr %l12, !tbaa !29
  %t108 = getelementptr %"compiler/typed:Clause", ptr %t106, i32 0, i32 2
  %t109 = load i1, ptr %t108, !tbaa !21
  %t111 = xor i1 %t109, true
  store i1 %t111, ptr %l84, !tbaa !21
  br label %bb27
bb26:
  store i1 false, ptr %l84, !tbaa !21
  br label %bb27
bb27:
  %t113 = load i1, ptr %l84, !tbaa !21
  br i1 %t113, label %bb28, label %bb29
bb28:
  %t114 = load ptr, ptr %l12, !tbaa !29
  %t116 = getelementptr %"compiler/typed:Clause", ptr %t114, i32 0, i32 1
  %t117 = load { i64, ptr }, ptr %t116, !tbaa !27
  %t119 = extractvalue { i64, ptr } %t117, 0
  %t121 = icmp sgt i64 %t119, 0
  store i1 %t121, ptr %l88, !tbaa !21
  br label %bb30
bb29:
  store i1 false, ptr %l88, !tbaa !21
  br label %bb30
bb30:
  %t123 = load i1, ptr %l88, !tbaa !21
  br i1 %t123, label %bb31, label %bb32
bb31:
  store %olang.scope zeroinitializer, ptr %s5
  %t124 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aClause_26_3e_2ector(ptr %s5, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t124, ptr %l93
  br label %bb33
bb32:
  br label %bb71
bb33:
  %t125 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l93
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t125, ptr %l13
  store i64 0, ptr %l14, !tbaa !24
  %t126 = load i64, ptr %l10, !tbaa !24
  store i64 %t126, ptr %l15, !tbaa !24
  store i64 1, ptr %l16, !tbaa !24
  %t128 = load i64, ptr %l15, !tbaa !24
  %t129 = load i64, ptr %l14, !tbaa !24
  %t132 = icmp sgt i64 %t128, %t129
  br i1 %t132, label %bb34, label %bb35
bb34:
  %t134 = load i64, ptr %l16, !tbaa !24
  %t136 = icmp sgt i64 %t134, 0
  br i1 %t136, label %bb36, label %bb37
bb35:
  store i64 0, ptr %l98, !tbaa !24
  br label %bb39
bb36:
  %t138 = load i64, ptr %l15, !tbaa !24
  %t139 = load i64, ptr %l14, !tbaa !24
  %t142 = sub i64 %t138, %t139
  %t143 = load i64, ptr %l16, !tbaa !24
  %t146 = add i64 %t142, %t143
  %t148 = sub i64 %t146, 1
  %t149 = load i64, ptr %l16, !tbaa !24
  %t152 = sdiv i64 %t148, %t149
  store i64 %t152, ptr %l101, !tbaa !24
  br label %bb38
bb37:
  store i64 0, ptr %l101, !tbaa !24
  br label %bb38
bb38:
  %t154 = load i64, ptr %l101, !tbaa !24
  store i64 %t154, ptr %l98, !tbaa !24
  br label %bb39
bb39:
  %t155 = load i64, ptr %l98, !tbaa !24
  store i64 %t155, ptr %l17, !tbaa !24
  store i64 0, ptr %l18, !tbaa !24
  br label %bb40
bb40:
  %t156 = load i64, ptr %l18, !tbaa !24
  %t157 = load i64, ptr %l17, !tbaa !24
  %t160 = icmp slt i64 %t156, %t157
  %t162 = xor i1 %t160, true
  br i1 %t162, label %bb41, label %bb42
bb41:
  br label %bb47
bb42:
  br label %bb43
bb43:
  %t164 = load i64, ptr %l14, !tbaa !24
  %t165 = load i64, ptr %l18, !tbaa !24
  %t166 = load i64, ptr %l16, !tbaa !24
  %t169 = mul i64 %t165, %t166
  %t172 = add i64 %t164, %t169
  store ptr %l13, ptr %l119, !tbaa !29
  %t174 = load ptr, ptr %l2, !tbaa !29
  %t178 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aClause_26_3e_2eAt_3ccompiler_2ftyped_3aClause_26_3e(ptr %v2, ptr %v2, ptr %t174, i64 %t172)
  store ptr %t178, ptr %l122
  br label %bb44
bb44:
  %t179 = load ptr, ptr %l119, !tbaa !29
  %t180 = load ptr, ptr %l122, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aClause_26_3e_2ePush_Hc64f4d0e64077a33423ff9c4e583894f(ptr %s5, ptr %v2, ptr %t179, ptr %t180)
  br label %bb45
bb45:
  br label %bb46
bb46:
  %t181 = load i64, ptr %l18, !tbaa !24
  %t183 = add i64 %t181, 1
  store i64 %t183, ptr %l18, !tbaa !24
  br label %bb40
bb47:
  store i1 true, ptr %l20, !tbaa !21
  %t185 = load ptr, ptr %l12, !tbaa !29
  %t187 = getelementptr %"compiler/typed:Clause", ptr %t185, i32 0, i32 1
  %t188 = load { i64, ptr }, ptr %t187, !tbaa !27
  store { i64, ptr } %t188, ptr %l21, !tbaa !27
  store i64 0, ptr %l22, !tbaa !24
  %t190 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t192 = extractvalue { i64, ptr } %t190, 0
  store i64 %t192, ptr %l23, !tbaa !24
  br label %bb48
bb48:
  %t194 = load i64, ptr %l22, !tbaa !24
  %t195 = load i64, ptr %l23, !tbaa !24
  %t198 = icmp slt i64 %t194, %t195
  %t200 = xor i1 %t198, true
  br i1 %t200, label %bb49, label %bb50
bb49:
  br label %bb64
bb50:
  br label %bb51
bb51:
  %t202 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t202, ptr %l133, !tbaa !27
  %t203 = load i64, ptr %l22, !tbaa !24
  %t205 = getelementptr { i64, ptr }, ptr %l133, i32 0, i32 1
  %t206 = load ptr, ptr %t205, !tbaa !27
  %t207 = getelementptr %"compiler/typed:Item", ptr %t206, i64 %t203
  %t208 = load %"compiler/typed:Item", ptr %t207
  store %"compiler/typed:Item" %t208, ptr %l24
  %t210 = getelementptr %"compiler/typed:Item", ptr %l24, i32 0, i32 1
  %t211 = load i64, ptr %t210, !tbaa !24
  %t213 = icmp slt i64 %t211, 0
  br i1 %t213, label %bb52, label %bb53
bb52:
  store i1 true, ptr %l138, !tbaa !21
  br label %bb54
bb53:
  %t215 = getelementptr %"compiler/typed:Item", ptr %l24, i32 0, i32 1
  %t216 = load i64, ptr %t215, !tbaa !24
  %t218 = icmp sge i64 %t216, 64
  store i1 %t218, ptr %l138, !tbaa !21
  br label %bb54
bb54:
  %t220 = load i1, ptr %l138, !tbaa !21
  br i1 %t220, label %bb55, label %bb56
bb55:
  %t221 = getelementptr %"compiler/typed:Item", ptr %l24, i32 0, i32 0
  %t222 = load i32, ptr %t221, !tbaa !23
  store i32 %t222, ptr %l141, !tbaa !23
  br label %bb58
bb56:
  %t224 = load ptr, ptr %l0, !tbaa !29
  %t226 = getelementptr %"compiler/check:Checker", ptr %t224, i32 0, i32 1
  %t227 = load ptr, ptr %t226, !tbaa !29
  %t229 = getelementptr %"compiler/generic:Program", ptr %t227, i32 0, i32 2
  %t230 = getelementptr %"compiler/typed:Item", ptr %l24, i32 0, i32 0
  %t231 = load i32, ptr %t230, !tbaa !23
  %t232 = getelementptr %"compiler/typed:Item", ptr %l24, i32 0, i32 1
  %t233 = load i64, ptr %t232, !tbaa !24
  store i64 %t233, ptr %l147, !tbaa !24
  %t234 = load i64, ptr %l147, !tbaa !24
  %t235 = load i64, ptr %l147, !tbaa !24
  %t236 = shl i64 1, %t235
  %t240 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrWords(ptr %v0, ptr %t229, i32 %t231, i64 %t236)
  store i32 %t240, ptr %l149
  br label %bb57
bb57:
  %t241 = load i32, ptr %l149, !tbaa !23
  store i32 %t241, ptr %l141, !tbaa !23
  br label %bb58
bb58:
  %t242 = load i32, ptr %l141, !tbaa !23
  %t243 = load ptr, ptr %l0, !tbaa !29
  %t248 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleft(ptr %v0, ptr %s5, ptr %t243, i32 %t242, ptr %l13)
  store i32 %t248, ptr %l153
  br label %bb59
bb59:
  %t249 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t250 = load i32, ptr %l153, !tbaa !23
  %t252 = icmp ne i32 %t250, %t249
  br i1 %t252, label %bb60, label %bb61
bb60:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb62
bb61:
  br label %bb62
bb62:
  br label %bb63
bb63:
  %t254 = load i64, ptr %l22, !tbaa !24
  %t256 = add i64 %t254, 1
  store i64 %t256, ptr %l22, !tbaa !24
  br label %bb48
bb64:
  %t258 = load i1, ptr %l20, !tbaa !21
  br i1 %t258, label %bb65, label %bb66
bb65:
  store %olang.scope zeroinitializer, ptr %s13
  %t260 = load ptr, ptr %l0, !tbaa !29
  store ptr %t260, ptr %l159, !tbaa !29
  %t261 = load ptr, ptr %l0, !tbaa !29
  %t262 = load ptr, ptr %l11, !tbaa !29
  %t265 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecatchSpan(ptr %v0, ptr %v1, ptr %t261, ptr %t262)
  store %"compiler/source:Span" %t265, ptr %l162
  br label %bb67
bb66:
  br label %bb70
bb67:
  %t266 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCatchUnreachable(ptr %s13)
  store %"compiler/msgs:Msg" %t266, ptr %l163
  br label %bb68
bb68:
  %t267 = load ptr, ptr %l159, !tbaa !29
  %t268 = load %"compiler/source:Span", ptr %l162
  %t269 = load %"compiler/msgs:Msg", ptr %l163
  %t270 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s13, ptr %t267, %"compiler/source:Span" %t268, %"compiler/msgs:Msg" %t269)
  store i64 %t270, ptr %l164
  br label %bb69
bb69:
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s3)
  store i1 true, ptr %rv
  br label %ret
bb70:
  call void @__olang_scope_close(ptr %s5)
  br label %bb71
bb71:
  %t272 = load ptr, ptr %l11, !tbaa !29
  %t274 = getelementptr %"compiler/ast:Catch", ptr %t272, i32 0, i32 3
  %t275 = load { i64, ptr }, ptr %t274, !tbaa !27
  %t277 = extractvalue { i64, ptr } %t275, 0
  %t279 = icmp sgt i64 %t277, 0
  store i1 %t279, ptr %l26, !tbaa !21
  %t283 = xor i1 %a3, true
  br i1 %t283, label %bb72, label %bb73
bb72:
  %t285 = load i1, ptr %l26, !tbaa !21
  br i1 %t285, label %bb74, label %bb75
bb73:
  br label %bb80
bb74:
  store %olang.scope zeroinitializer, ptr %s15
  %t287 = load ptr, ptr %l0, !tbaa !29
  store ptr %t287, ptr %l173, !tbaa !29
  %t288 = load ptr, ptr %l0, !tbaa !29
  %t289 = load ptr, ptr %l11, !tbaa !29
  %t292 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edefaultSpan(ptr %v0, ptr %v1, ptr %t288, ptr %t289)
  store %"compiler/source:Span" %t292, ptr %l176
  br label %bb76
bb75:
  br label %bb79
bb76:
  %t293 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefaultInStatement(ptr %s15)
  store %"compiler/msgs:Msg" %t293, ptr %l177
  br label %bb77
bb77:
  %t294 = load ptr, ptr %l173, !tbaa !29
  %t295 = load %"compiler/source:Span", ptr %l176
  %t296 = load %"compiler/msgs:Msg", ptr %l177
  %t297 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s15, ptr %t294, %"compiler/source:Span" %t295, %"compiler/msgs:Msg" %t296)
  store i64 %t297, ptr %l178
  br label %bb78
bb78:
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s3)
  store i1 true, ptr %rv
  br label %ret
bb79:
  call void @__olang_scope_close(ptr %s3)
  br label %bb137
bb80:
  %t299 = load i32, ptr %l4, !tbaa !23
  %t300 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t303 = icmp eq i32 %t299, %t300
  br i1 %t303, label %bb81, label %bb82
bb81:
  %t305 = load i1, ptr %l26, !tbaa !21
  br i1 %t305, label %bb83, label %bb84
bb82:
  br label %bb89
bb83:
  store %olang.scope zeroinitializer, ptr %s17
  %t307 = load ptr, ptr %l0, !tbaa !29
  store ptr %t307, ptr %l184, !tbaa !29
  %t308 = load ptr, ptr %l0, !tbaa !29
  %t309 = load ptr, ptr %l11, !tbaa !29
  %t312 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecatchSpan(ptr %v0, ptr %v1, ptr %t308, ptr %t309)
  store %"compiler/source:Span" %t312, ptr %l187
  br label %bb85
bb84:
  br label %bb88
bb85:
  %t313 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefaultNoValue(ptr %s17)
  store %"compiler/msgs:Msg" %t313, ptr %l188
  br label %bb86
bb86:
  %t314 = load ptr, ptr %l184, !tbaa !29
  %t315 = load %"compiler/source:Span", ptr %l187
  %t316 = load %"compiler/msgs:Msg", ptr %l188
  %t317 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s17, ptr %t314, %"compiler/source:Span" %t315, %"compiler/msgs:Msg" %t316)
  store i64 %t317, ptr %l189
  br label %bb87
bb87:
  call void @__olang_scope_close(ptr %s17)
  call void @__olang_scope_close(ptr %s3)
  store i1 true, ptr %rv
  br label %ret
bb88:
  call void @__olang_scope_close(ptr %s3)
  br label %bb137
bb89:
  %t319 = load ptr, ptr %l12, !tbaa !29
  %t321 = getelementptr %"compiler/typed:Clause", ptr %t319, i32 0, i32 3
  %t322 = load ptr, ptr %t321, !tbaa !29
  %t324 = icmp eq ptr %t322, null
  %t326 = xor i1 %t324, true
  br i1 %t326, label %bb90, label %bb91
bb90:
  %t328 = load ptr, ptr %l12, !tbaa !29
  %t330 = getelementptr %"compiler/typed:Clause", ptr %t328, i32 0, i32 3
  %t331 = load ptr, ptr %t330, !tbaa !29
  %t333 = icmp eq ptr %t331, null
  br i1 %t333, label %bb92, label %bb93
bb91:
  store i1 false, ptr %l195, !tbaa !21
  br label %bb96
bb92:
  call void @__olang_check_failed(ptr @olang_loc_20fb2e81a5b7d68a_7759df49ce89a9e)
  unreachable
bb93:
  br label %bb94
bb94:
  %t335 = load ptr, ptr %l12, !tbaa !29
  %t337 = getelementptr %"compiler/typed:Clause", ptr %t335, i32 0, i32 3
  %t338 = load ptr, ptr %t337, !tbaa !29
  %t340 = call i1 @compiler_2fcheck_2eleavesValue(ptr %v2, ptr %t338)
  store i1 %t340, ptr %l201
  br label %bb95
bb95:
  %t341 = load i1, ptr %l201, !tbaa !21
  store i1 %t341, ptr %l195, !tbaa !21
  br label %bb96
bb96:
  %t342 = load i1, ptr %l195, !tbaa !21
  store i1 %t342, ptr %l27, !tbaa !21
  %t343 = load i1, ptr %l27, !tbaa !21
  br i1 %t343, label %bb97, label %bb98
bb97:
  %t345 = load i1, ptr %l26, !tbaa !21
  store i1 %t345, ptr %l203, !tbaa !21
  br label %bb99
bb98:
  store i1 false, ptr %l203, !tbaa !21
  br label %bb99
bb99:
  %t347 = load i1, ptr %l203, !tbaa !21
  br i1 %t347, label %bb100, label %bb101
bb100:
  store %olang.scope zeroinitializer, ptr %s18
  %t348 = load ptr, ptr %l0, !tbaa !29
  store ptr %t348, ptr %l205, !tbaa !29
  %t349 = load ptr, ptr %l0, !tbaa !29
  %t350 = load ptr, ptr %l11, !tbaa !29
  %t353 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edefaultSpan(ptr %v0, ptr %v1, ptr %t349, ptr %t350)
  store %"compiler/source:Span" %t353, ptr %l208
  br label %bb102
bb101:
  br label %bb105
bb102:
  %t354 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefaultDead(ptr %s18)
  store %"compiler/msgs:Msg" %t354, ptr %l209
  br label %bb103
bb103:
  %t355 = load ptr, ptr %l205, !tbaa !29
  %t356 = load %"compiler/source:Span", ptr %l208
  %t357 = load %"compiler/msgs:Msg", ptr %l209
  %t358 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s18, ptr %t355, %"compiler/source:Span" %t356, %"compiler/msgs:Msg" %t357)
  store i64 %t358, ptr %l210
  br label %bb104
bb104:
  call void @__olang_scope_close(ptr %s18)
  call void @__olang_scope_close(ptr %s3)
  store i1 true, ptr %rv
  br label %ret
bb105:
  %t360 = load i1, ptr %l27, !tbaa !21
  %t362 = xor i1 %t360, true
  br i1 %t362, label %bb106, label %bb107
bb106:
  %t364 = load i1, ptr %l26, !tbaa !21
  %t366 = xor i1 %t364, true
  store i1 %t366, ptr %l214, !tbaa !21
  br label %bb108
bb107:
  store i1 false, ptr %l214, !tbaa !21
  br label %bb108
bb108:
  %t368 = load i1, ptr %l214, !tbaa !21
  br i1 %t368, label %bb109, label %bb110
bb109:
  store %olang.scope zeroinitializer, ptr %s19
  %t369 = load ptr, ptr %l11, !tbaa !29
  %t371 = getelementptr %"compiler/ast:Catch", ptr %t369, i32 0, i32 2
  %t372 = load { i64, ptr }, ptr %t371, !tbaa !27
  %t374 = extractvalue { i64, ptr } %t372, 0
  %t376 = icmp sgt i64 %t374, 0
  br i1 %t376, label %bb111, label %bb112
bb110:
  br label %bb121
bb111:
  %t378 = load ptr, ptr %l11, !tbaa !29
  %t380 = getelementptr %"compiler/ast:Catch", ptr %t378, i32 0, i32 2
  %t381 = load { i64, ptr }, ptr %t380, !tbaa !27
  %t383 = call i1 @compiler_2fcheck_2elastIsValue(ptr %v1, { i64, ptr } %t381)
  store i1 %t383, ptr %l224
  br label %bb113
bb112:
  store i1 false, ptr %l221, !tbaa !21
  br label %bb114
bb113:
  %t384 = load i1, ptr %l224, !tbaa !21
  store i1 %t384, ptr %l221, !tbaa !21
  br label %bb114
bb114:
  %t385 = load i1, ptr %l221, !tbaa !21
  br i1 %t385, label %bb115, label %bb116
bb115:
  call void @__olang_scope_close(ptr %s19)
  call void @__olang_scope_close(ptr %s3)
  br label %bb137
bb116:
  br label %bb117
bb117:
  %t386 = load ptr, ptr %l0, !tbaa !29
  store ptr %t386, ptr %l225, !tbaa !29
  %t387 = load ptr, ptr %l0, !tbaa !29
  %t388 = load ptr, ptr %l11, !tbaa !29
  %t391 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecatchSpan(ptr %v0, ptr %v1, ptr %t387, ptr %t388)
  store %"compiler/source:Span" %t391, ptr %l228
  br label %bb118
bb118:
  %t392 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCatchMustLeave(ptr %s19)
  store %"compiler/msgs:Msg" %t392, ptr %l229
  br label %bb119
bb119:
  %t393 = load ptr, ptr %l225, !tbaa !29
  %t394 = load %"compiler/source:Span", ptr %l228
  %t395 = load %"compiler/msgs:Msg", ptr %l229
  %t396 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s19, ptr %t393, %"compiler/source:Span" %t394, %"compiler/msgs:Msg" %t395)
  store i64 %t396, ptr %l230
  br label %bb120
bb120:
  call void @__olang_scope_close(ptr %s19)
  call void @__olang_scope_close(ptr %s3)
  store i1 true, ptr %rv
  br label %ret
bb121:
  %t398 = load i1, ptr %l26, !tbaa !21
  br i1 %t398, label %bb122, label %bb123
bb122:
  %t400 = load ptr, ptr %l0, !tbaa !29
  %t402 = getelementptr %"compiler/check:Checker", ptr %t400, i32 0, i32 1
  %t403 = load ptr, ptr %t402, !tbaa !29
  %t405 = getelementptr %"compiler/generic:Program", ptr %t403, i32 0, i32 2
  %t406 = load i32, ptr %l4, !tbaa !23
  %t409 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t405, i32 %t406)
  store i32 %t409, ptr %l238
  br label %bb124
bb123:
  store i1 false, ptr %l233, !tbaa !21
  br label %bb125
bb124:
  %t410 = load i32, ptr %l238, !range !{i32 0, i32 33}
  %t412 = trunc i64 22 to i32
  %t413 = icmp eq i32 %t410, %t412
  store i1 %t413, ptr %l233, !tbaa !21
  br label %bb125
bb125:
  %t415 = load i1, ptr %l233, !tbaa !21
  br i1 %t415, label %bb126, label %bb127
bb126:
  store %olang.scope zeroinitializer, ptr %s21
  %t416 = load ptr, ptr %l0, !tbaa !29
  %t418 = getelementptr %"compiler/check:Checker", ptr %t416, i32 0, i32 1
  %t419 = load ptr, ptr %t418, !tbaa !29
  %t421 = getelementptr %"compiler/generic:Program", ptr %t419, i32 0, i32 2
  store ptr %t421, ptr %l243, !tbaa !29
  %t422 = load ptr, ptr %l0, !tbaa !29
  %t424 = getelementptr %"compiler/check:Checker", ptr %t422, i32 0, i32 1
  %t425 = load ptr, ptr %t424, !tbaa !29
  %t427 = getelementptr %"compiler/generic:Program", ptr %t425, i32 0, i32 2
  %t428 = load i32, ptr %l4, !tbaa !23
  %t431 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t427, i32 %t428)
  store i32 %t431, ptr %l248
  br label %bb128
bb127:
  br label %bb136
bb128:
  %t432 = load ptr, ptr %l243, !tbaa !29
  %t433 = load i32, ptr %l248, !tbaa !23
  %t434 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s21, ptr %t432, i32 %t433)
  store { i64, ptr } %t434, ptr %l249
  br label %bb129
bb129:
  %t435 = load { i64, ptr }, ptr %l249, !tbaa !27
  %t436 = extractvalue { i64, ptr } %t435, 0
  store i64 %t436, ptr %l28, !tbaa !24
  %t438 = load ptr, ptr %l11, !tbaa !29
  %t440 = getelementptr %"compiler/ast:Catch", ptr %t438, i32 0, i32 3
  %t441 = load { i64, ptr }, ptr %t440, !tbaa !27
  %t443 = extractvalue { i64, ptr } %t441, 0
  %t444 = load i64, ptr %l28, !tbaa !24
  %t447 = icmp ne i64 %t443, %t444
  br i1 %t447, label %bb130, label %bb131
bb130:
  store %olang.scope zeroinitializer, ptr %s22
  %t449 = load ptr, ptr %l0, !tbaa !29
  store ptr %t449, ptr %l256, !tbaa !29
  %t450 = load ptr, ptr %l0, !tbaa !29
  %t451 = load ptr, ptr %l11, !tbaa !29
  %t454 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edefaultSpan(ptr %v0, ptr %v1, ptr %t450, ptr %t451)
  store %"compiler/source:Span" %t454, ptr %l259
  br label %bb132
bb131:
  br label %bb135
bb132:
  %t455 = load i64, ptr %l28, !tbaa !24
  %t456 = load ptr, ptr %l11, !tbaa !29
  %t458 = getelementptr %"compiler/ast:Catch", ptr %t456, i32 0, i32 3
  %t459 = load { i64, ptr }, ptr %t458, !tbaa !27
  %t461 = extractvalue { i64, ptr } %t459, 0
  %t464 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefaultCount(ptr %s22, i64 %t455, i64 %t461)
  store %"compiler/msgs:Msg" %t464, ptr %l264
  br label %bb133
bb133:
  %t465 = load ptr, ptr %l256, !tbaa !29
  %t466 = load %"compiler/source:Span", ptr %l259
  %t467 = load %"compiler/msgs:Msg", ptr %l264
  %t468 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s22, ptr %t465, %"compiler/source:Span" %t466, %"compiler/msgs:Msg" %t467)
  store i64 %t468, ptr %l265
  br label %bb134
bb134:
  call void @__olang_scope_close(ptr %s22)
  call void @__olang_scope_close(ptr %s21)
  call void @__olang_scope_close(ptr %s3)
  store i1 true, ptr %rv
  br label %ret
bb135:
  call void @__olang_scope_close(ptr %s21)
  br label %bb136
bb136:
  call void @__olang_scope_close(ptr %s3)
  br label %bb137
bb137:
  %t470 = load i64, ptr %l9, !tbaa !24
  %t472 = add i64 %t470, 1
  store i64 %t472, ptr %l9, !tbaa !24
  br label %bb10
bb138:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecommutesRule(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l5 = alloca %"compiler/source:Span"
  %l7 = alloca { i64, ptr }
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i64
  %l17 = alloca i64
  %l21 = alloca ptr
  %l24 = alloca %"compiler/source:Span"
  %l28 = alloca i32
  %l31 = alloca ptr
  %l36 = alloca i32
  %l37 = alloca { i64, ptr }
  %l39 = alloca i1
  %l40 = alloca i1
  %l42 = alloca i1
  %l43 = alloca i1
  %l45 = alloca i1
  %l46 = alloca i1
  %l48 = alloca i1
  %l49 = alloca i1
  %l51 = alloca i1
  %l54 = alloca i1
  %l58 = alloca i1
  %l62 = alloca ptr
  %l63 = alloca %"compiler/source:Span"
  %l67 = alloca { i64, ptr }
  %l69 = alloca %"compiler/msgs:Msg"
  %l70 = alloca i64
  %l74 = alloca ptr
  %l76 = alloca { i64, ptr }
  %l78 = alloca i32
  %l79 = alloca i32
  %l82 = alloca ptr
  %l84 = alloca { i64, ptr }
  %l86 = alloca i32
  %l87 = alloca i32
  %l93 = alloca i1
  %l94 = alloca ptr
  %l95 = alloca %"compiler/source:Span"
  %l99 = alloca { i64, ptr }
  %l100 = alloca { i64, ptr }
  %l103 = alloca { i64, ptr }
  %l105 = alloca %"compiler/msgs:Msg"
  %l106 = alloca i64
  %l110 = alloca i1
  %l116 = alloca i64
  %l119 = alloca i1
  %l126 = alloca ptr
  %l129 = alloca ptr
  %l133 = alloca i32
  %l134 = alloca i32
  %l135 = alloca { i64, ptr }
  %l138 = alloca ptr
  %l141 = alloca ptr
  %l143 = alloca { i64, ptr }
  %l145 = alloca i32
  %l146 = alloca i32
  %l148 = alloca i1
  %l154 = alloca ptr
  %l158 = alloca i1
  %l164 = alloca i1
  %l165 = alloca { i64, ptr }
  %l167 = alloca i1
  %l168 = alloca { i64, ptr }
  %l170 = alloca i1
  %l171 = alloca { i64, ptr }
  %l173 = alloca i1
  %l174 = alloca { i64, ptr }
  %l175 = alloca ptr
  %l176 = alloca %"compiler/source:Span"
  %l177 = alloca { i64, ptr }
  %l180 = alloca { i64, ptr }
  %l181 = alloca { i64, ptr }
  %l184 = alloca { i64, ptr }
  %l185 = alloca { i64, ptr }
  %l188 = alloca { i64, ptr }
  %l189 = alloca ptr
  %l193 = alloca ptr
  %l196 = alloca { i64, ptr }
  %l199 = alloca %"compiler/msgs:Msg"
  %l200 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i64, ptr %l1, !tbaa !24
  %t8 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t4, i64 %t5)
  store i64 %t8, ptr %l17
  br label %bb1
bb1:
  %t9 = load i64, ptr %l17, !tbaa !24
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t16 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %v0, ptr %t10, i64 -1, i64 %t9, i32 %t12, i32 0)
  store ptr %t16, ptr %l21
  br label %bb2
bb2:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t18 = load ptr, ptr %l2, !tbaa !29
  %t21 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enameSpan(ptr %v0, ptr %v1, ptr %t17, ptr %t18)
  store %"compiler/source:Span" %t21, ptr %l24
  br label %bb3
bb3:
  %t22 = load %"compiler/source:Span", ptr %l24
  store %"compiler/source:Span" %t22, ptr %l5
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/check:Checker", ptr %t23, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t27 = load i64, ptr %l1, !tbaa !24
  %t30 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t26, i64 %t27)
  store i32 %t30, ptr %l28
  br label %bb4
bb4:
  %t31 = load i32, ptr %l28, !tbaa !23
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/check:Checker", ptr %t32, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t37 = getelementptr %"compiler/generic:Program", ptr %t35, i32 0, i32 2
  store ptr %t37, ptr %l31, !tbaa !29
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/check:Checker", ptr %t38, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t43 = getelementptr %"compiler/generic:Program", ptr %t41, i32 0, i32 2
  %t47 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t43, i32 %t31)
  store i32 %t47, ptr %l36
  br label %bb5
bb5:
  %t48 = load ptr, ptr %l31, !tbaa !29
  %t49 = load i32, ptr %l36, !tbaa !23
  %t50 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t48, i32 %t49)
  store { i64, ptr } %t50, ptr %l37
  br label %bb6
bb6:
  %t51 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t51, ptr %l7, !tbaa !27
  %t52 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t54 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t52, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d10, i32 0, i32 1) })
  store i1 %t54, ptr %l39
  br label %bb7
bb7:
  %t55 = load i1, ptr %l39, !tbaa !21
  br i1 %t55, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l40, !tbaa !21
  br label %bb11
bb9:
  %t56 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t58 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t56, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d11, i32 0, i32 1) })
  store i1 %t58, ptr %l42
  br label %bb10
bb10:
  %t59 = load i1, ptr %l42, !tbaa !21
  store i1 %t59, ptr %l40, !tbaa !21
  br label %bb11
bb11:
  %t60 = load i1, ptr %l40, !tbaa !21
  br i1 %t60, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l43, !tbaa !21
  br label %bb15
bb13:
  %t61 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t63 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t61, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d12, i32 0, i32 1) })
  store i1 %t63, ptr %l45
  br label %bb14
bb14:
  %t64 = load i1, ptr %l45, !tbaa !21
  store i1 %t64, ptr %l43, !tbaa !21
  br label %bb15
bb15:
  %t65 = load i1, ptr %l43, !tbaa !21
  br i1 %t65, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l46, !tbaa !21
  br label %bb19
bb17:
  %t66 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t68 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t66, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d13, i32 0, i32 1) })
  store i1 %t68, ptr %l48
  br label %bb18
bb18:
  %t69 = load i1, ptr %l48, !tbaa !21
  store i1 %t69, ptr %l46, !tbaa !21
  br label %bb19
bb19:
  %t70 = load i1, ptr %l46, !tbaa !21
  br i1 %t70, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l49, !tbaa !21
  br label %bb23
bb21:
  %t71 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t73 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t71, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d14, i32 0, i32 1) })
  store i1 %t73, ptr %l51
  br label %bb22
bb22:
  %t74 = load i1, ptr %l51, !tbaa !21
  store i1 %t74, ptr %l49, !tbaa !21
  br label %bb23
bb23:
  %t75 = load i1, ptr %l49, !tbaa !21
  %t78 = xor i1 %t75, true
  br i1 %t78, label %bb24, label %bb25
bb24:
  store i1 true, ptr %l54, !tbaa !21
  br label %bb26
bb25:
  %t80 = load ptr, ptr %l2, !tbaa !29
  %t82 = getelementptr %"compiler/ast:Func", ptr %t80, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !29
  %t85 = icmp eq ptr %t83, null
  store i1 %t85, ptr %l54, !tbaa !21
  br label %bb26
bb26:
  %t87 = load i1, ptr %l54, !tbaa !21
  br i1 %t87, label %bb27, label %bb28
bb27:
  store i1 true, ptr %l58, !tbaa !21
  br label %bb29
bb28:
  %t88 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t90 = extractvalue { i64, ptr } %t88, 0
  %t92 = icmp ne i64 %t90, 2
  store i1 %t92, ptr %l58, !tbaa !21
  br label %bb29
bb29:
  %t94 = load i1, ptr %l58, !tbaa !21
  br i1 %t94, label %bb30, label %bb31
bb30:
  store %olang.scope zeroinitializer, ptr %s1
  %t95 = load ptr, ptr %l0, !tbaa !29
  store ptr %t95, ptr %l62, !tbaa !29
  %t96 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t96, ptr %l63
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t98 = load ptr, ptr %l2, !tbaa !29
  %t100 = getelementptr %"compiler/ast:Func", ptr %t98, i32 0, i32 2
  %t101 = load i32, ptr %t100, !tbaa !23
  %t104 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s1, ptr %t97, i32 %t101)
  store { i64, ptr } %t104, ptr %l67
  br label %bb32
bb31:
  br label %bb36
bb32:
  %t105 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t106 = extractvalue { i64, ptr } %t105, 0
  %t107 = extractvalue { i64, ptr } %t105, 1
  %t108 = mul i64 %t106, 1
  %t109 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t108)
  call void @llvm.memcpy.p0.p0.i64(ptr %t109, ptr %t107, i64 %t108, i1 false)
  %t110 = insertvalue { i64, ptr } undef, i64 %t106, 0
  %t111 = insertvalue { i64, ptr } %t110, ptr %t109, 1
  %t113 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCommutesNotHere(ptr %s1, ptr %s1, { i64, ptr } %t111)
  store %"compiler/msgs:Msg" %t113, ptr %l69
  br label %bb33
bb33:
  %t114 = load ptr, ptr %l62, !tbaa !29
  %t115 = load %"compiler/source:Span", ptr %l63
  %t116 = load %"compiler/msgs:Msg", ptr %l69
  %t117 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s1, ptr %t114, %"compiler/source:Span" %t115, %"compiler/msgs:Msg" %t116)
  store i64 %t117, ptr %l70
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s1)
  %t118 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t118)
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb36:
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t122 = getelementptr %"compiler/check:Checker", ptr %t120, i32 0, i32 1
  %t123 = load ptr, ptr %t122, !tbaa !29
  %t125 = getelementptr %"compiler/generic:Program", ptr %t123, i32 0, i32 2
  store ptr %t125, ptr %l74, !tbaa !29
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t127 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t127, ptr %l76, !tbaa !27
  %t128 = getelementptr { i64, ptr }, ptr %l76, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !27
  %t130 = getelementptr i32, ptr %t129, i64 0
  %t131 = load i32, ptr %t130, !tbaa !33
  %t134 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t126, i32 %t131)
  store i32 %t134, ptr %l78
  br label %bb37
bb37:
  %t135 = load ptr, ptr %l74, !tbaa !29
  %t136 = load i32, ptr %l78, !tbaa !23
  %t137 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t135, i32 %t136)
  store i32 %t137, ptr %l79
  br label %bb38
bb38:
  %t138 = load i32, ptr %l79, !tbaa !23
  store i32 %t138, ptr %l9, !tbaa !23
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t141 = getelementptr %"compiler/check:Checker", ptr %t139, i32 0, i32 1
  %t142 = load ptr, ptr %t141, !tbaa !29
  %t144 = getelementptr %"compiler/generic:Program", ptr %t142, i32 0, i32 2
  store ptr %t144, ptr %l82, !tbaa !29
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t146 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t146, ptr %l84, !tbaa !27
  %t147 = getelementptr { i64, ptr }, ptr %l84, i32 0, i32 1
  %t148 = load ptr, ptr %t147, !tbaa !27
  %t149 = getelementptr i32, ptr %t148, i64 1
  %t150 = load i32, ptr %t149, !tbaa !33
  %t153 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t145, i32 %t150)
  store i32 %t153, ptr %l86
  br label %bb39
bb39:
  %t154 = load ptr, ptr %l82, !tbaa !29
  %t155 = load i32, ptr %l86, !tbaa !23
  %t156 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t154, i32 %t155)
  store i32 %t156, ptr %l87
  br label %bb40
bb40:
  %t157 = load i32, ptr %l87, !tbaa !23
  store i32 %t157, ptr %l10, !tbaa !23
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t160 = getelementptr %"compiler/check:Checker", ptr %t158, i32 0, i32 1
  %t161 = load ptr, ptr %t160, !tbaa !29
  %t163 = getelementptr %"compiler/generic:Program", ptr %t161, i32 0, i32 2
  %t164 = load i32, ptr %l9, !tbaa !23
  %t165 = load i32, ptr %l10, !tbaa !23
  %t169 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t163, i32 %t164, i32 %t165)
  store i1 %t169, ptr %l93
  br label %bb41
bb41:
  %t170 = load i1, ptr %l93, !tbaa !21
  br i1 %t170, label %bb42, label %bb43
bb42:
  store %olang.scope zeroinitializer, ptr %s3
  %t171 = load ptr, ptr %l0, !tbaa !29
  store ptr %t171, ptr %l94, !tbaa !29
  %t172 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t172, ptr %l95
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t174 = load ptr, ptr %l2, !tbaa !29
  %t176 = getelementptr %"compiler/ast:Func", ptr %t174, i32 0, i32 2
  %t177 = load i32, ptr %t176, !tbaa !23
  %t180 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s3, ptr %t173, i32 %t177)
  store { i64, ptr } %t180, ptr %l99
  br label %bb44
bb43:
  br label %bb49
bb44:
  %t181 = load { i64, ptr }, ptr %l99, !tbaa !27
  %t182 = extractvalue { i64, ptr } %t181, 0
  %t183 = extractvalue { i64, ptr } %t181, 1
  %t184 = mul i64 %t182, 1
  %t185 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t184)
  call void @llvm.memcpy.p0.p0.i64(ptr %t185, ptr %t183, i64 %t184, i1 false)
  %t186 = insertvalue { i64, ptr } undef, i64 %t182, 0
  %t187 = insertvalue { i64, ptr } %t186, ptr %t185, 1
  store { i64, ptr } %t187, ptr %l100, !tbaa !27
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t189 = load i32, ptr %l10, !tbaa !23
  %t192 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s3, ptr %t188, i32 %t189)
  store { i64, ptr } %t192, ptr %l103
  br label %bb45
bb45:
  %t193 = load { i64, ptr }, ptr %l103, !tbaa !27
  %t194 = extractvalue { i64, ptr } %t193, 0
  %t195 = extractvalue { i64, ptr } %t193, 1
  %t196 = mul i64 %t194, 1
  %t197 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t196)
  call void @llvm.memcpy.p0.p0.i64(ptr %t197, ptr %t195, i64 %t196, i1 false)
  %t198 = insertvalue { i64, ptr } undef, i64 %t194, 0
  %t199 = insertvalue { i64, ptr } %t198, ptr %t197, 1
  %t200 = load { i64, ptr }, ptr %l100, !tbaa !27
  %t202 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCommutesSameType(ptr %s3, ptr %s3, ptr %s3, { i64, ptr } %t200, { i64, ptr } %t199)
  store %"compiler/msgs:Msg" %t202, ptr %l105
  br label %bb46
bb46:
  %t203 = load ptr, ptr %l94, !tbaa !29
  %t204 = load %"compiler/source:Span", ptr %l95
  %t205 = load %"compiler/msgs:Msg", ptr %l105
  %t206 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s3, ptr %t203, %"compiler/source:Span" %t204, %"compiler/msgs:Msg" %t205)
  store i64 %t206, ptr %l106
  br label %bb47
bb47:
  call void @__olang_scope_close(ptr %s3)
  %t207 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t207)
  br label %bb48
bb48:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb49:
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t210 = load i32, ptr %l10, !tbaa !23
  %t213 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t209, i32 %t210)
  store i1 %t213, ptr %l110
  br label %bb50
bb50:
  %t214 = load i1, ptr %l110, !tbaa !21
  %t215 = xor i1 %t214, true
  br i1 %t215, label %bb51, label %bb52
bb51:
  %t217 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t217)
  br label %bb53
bb52:
  br label %bb54
bb53:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb54:
  %t219 = load ptr, ptr %l0, !tbaa !29
  %t220 = load i32, ptr %l10, !tbaa !23
  %t221 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t225 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %v2, ptr %t219, i32 %t220, { i64, ptr } %t221, i64 1)
  store i64 %t225, ptr %l116
  br label %bb55
bb55:
  %t226 = load i64, ptr %l116, !tbaa !24
  store i64 %t226, ptr %l11, !tbaa !24
  %t227 = load i64, ptr %l11, !tbaa !24
  %t229 = icmp slt i64 %t227, 0
  br i1 %t229, label %bb56, label %bb57
bb56:
  store i1 true, ptr %l119, !tbaa !21
  br label %bb58
bb57:
  %t231 = load i64, ptr %l11, !tbaa !24
  %t232 = load i64, ptr %l1, !tbaa !24
  %t235 = icmp eq i64 %t231, %t232
  store i1 %t235, ptr %l119, !tbaa !21
  br label %bb58
bb58:
  %t237 = load i1, ptr %l119, !tbaa !21
  br i1 %t237, label %bb59, label %bb60
bb59:
  %t238 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t238)
  br label %bb61
bb60:
  br label %bb62
bb61:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb62:
  %t240 = load ptr, ptr %l0, !tbaa !29
  %t242 = getelementptr %"compiler/check:Checker", ptr %t240, i32 0, i32 1
  %t243 = load ptr, ptr %t242, !tbaa !29
  %t245 = getelementptr %"compiler/generic:Program", ptr %t243, i32 0, i32 2
  store ptr %t245, ptr %l126, !tbaa !29
  %t246 = load ptr, ptr %l0, !tbaa !29
  %t248 = getelementptr %"compiler/check:Checker", ptr %t246, i32 0, i32 1
  %t249 = load ptr, ptr %t248, !tbaa !29
  %t251 = getelementptr %"compiler/generic:Program", ptr %t249, i32 0, i32 2
  store ptr %t251, ptr %l129, !tbaa !29
  %t252 = load ptr, ptr %l0, !tbaa !29
  %t254 = getelementptr %"compiler/check:Checker", ptr %t252, i32 0, i32 1
  %t255 = load ptr, ptr %t254, !tbaa !29
  %t256 = load i64, ptr %l11, !tbaa !24
  %t259 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t255, i64 %t256)
  store i32 %t259, ptr %l133
  br label %bb63
bb63:
  %t260 = load ptr, ptr %l129, !tbaa !29
  %t261 = load i32, ptr %l133, !tbaa !23
  %t262 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t260, i32 %t261)
  store i32 %t262, ptr %l134
  br label %bb64
bb64:
  %t263 = load ptr, ptr %l126, !tbaa !29
  %t264 = load i32, ptr %l134, !tbaa !23
  %t265 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t263, i32 %t264)
  store { i64, ptr } %t265, ptr %l135
  br label %bb65
bb65:
  %t266 = load { i64, ptr }, ptr %l135, !tbaa !27
  %t267 = load ptr, ptr %l0, !tbaa !29
  %t269 = getelementptr %"compiler/check:Checker", ptr %t267, i32 0, i32 1
  %t270 = load ptr, ptr %t269, !tbaa !29
  %t272 = getelementptr %"compiler/generic:Program", ptr %t270, i32 0, i32 2
  store ptr %t272, ptr %l138, !tbaa !29
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t275 = getelementptr %"compiler/check:Checker", ptr %t273, i32 0, i32 1
  %t276 = load ptr, ptr %t275, !tbaa !29
  %t278 = getelementptr %"compiler/generic:Program", ptr %t276, i32 0, i32 2
  store ptr %t278, ptr %l141, !tbaa !29
  %t279 = load ptr, ptr %l0, !tbaa !29
  store { i64, ptr } %t266, ptr %l143, !tbaa !27
  %t281 = getelementptr { i64, ptr }, ptr %l143, i32 0, i32 1
  %t282 = load ptr, ptr %t281, !tbaa !27
  %t283 = getelementptr i32, ptr %t282, i64 1
  %t284 = load i32, ptr %t283, !tbaa !33
  %t287 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t279, i32 %t284)
  store i32 %t287, ptr %l145
  br label %bb66
bb66:
  %t288 = load ptr, ptr %l141, !tbaa !29
  %t289 = load i32, ptr %l145, !tbaa !23
  %t290 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t288, i32 %t289)
  store i32 %t290, ptr %l146
  br label %bb67
bb67:
  %t291 = load i32, ptr %l9, !tbaa !23
  %t292 = load ptr, ptr %l138, !tbaa !29
  %t293 = load i32, ptr %l146, !tbaa !23
  %t295 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t292, i32 %t293, i32 %t291)
  store i1 %t295, ptr %l148
  br label %bb68
bb68:
  %t296 = load i1, ptr %l148, !tbaa !21
  %t297 = xor i1 %t296, true
  br i1 %t297, label %bb69, label %bb70
bb69:
  %t299 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t299)
  br label %bb71
bb70:
  br label %bb72
bb71:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb72:
  %t301 = load ptr, ptr %l0, !tbaa !29
  %t303 = getelementptr %"compiler/check:Checker", ptr %t301, i32 0, i32 1
  %t304 = load ptr, ptr %t303, !tbaa !29
  %t305 = load i64, ptr %l11, !tbaa !24
  %t308 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %s0, ptr %t304, i64 %t305)
  store ptr %t308, ptr %l154
  br label %bb73
bb73:
  %t309 = load ptr, ptr %l154, !tbaa !29
  %t311 = getelementptr %"compiler/ast:Func", ptr %t309, i32 0, i32 3
  %t312 = load ptr, ptr %t311, !tbaa !29
  %t314 = getelementptr %"compiler/ast:Sig", ptr %t312, i32 0, i32 6
  %t315 = load i1, ptr %t314, !tbaa !21
  br i1 %t315, label %bb74, label %bb75
bb74:
  %t317 = load i64, ptr %l11, !tbaa !24
  %t318 = load i64, ptr %l1, !tbaa !24
  %t321 = icmp sgt i64 %t317, %t318
  store i1 %t321, ptr %l158, !tbaa !21
  br label %bb76
bb75:
  store i1 false, ptr %l158, !tbaa !21
  br label %bb76
bb76:
  %t323 = load i1, ptr %l158, !tbaa !21
  br i1 %t323, label %bb77, label %bb78
bb77:
  %t324 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t324)
  br label %bb79
bb78:
  br label %bb80
bb79:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb80:
  %t326 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t328 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t326, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d15, i32 0, i32 1) })
  store i1 %t328, ptr %l164
  br label %bb81
bb81:
  %t329 = load i1, ptr %l164, !tbaa !21
  br i1 %t329, label %bb82, label %bb83
bb82:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d16, i32 0, i32 1) }, ptr %l165, !tbaa !27
  br label %bb96
bb83:
  %t330 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t332 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t330, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d17, i32 0, i32 1) })
  store i1 %t332, ptr %l167
  br label %bb84
bb84:
  %t333 = load i1, ptr %l167, !tbaa !21
  br i1 %t333, label %bb85, label %bb86
bb85:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d18, i32 0, i32 1) }, ptr %l168, !tbaa !27
  br label %bb95
bb86:
  %t334 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t336 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t334, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d19, i32 0, i32 1) })
  store i1 %t336, ptr %l170
  br label %bb87
bb87:
  %t337 = load i1, ptr %l170, !tbaa !21
  br i1 %t337, label %bb88, label %bb89
bb88:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d20, i32 0, i32 1) }, ptr %l171, !tbaa !27
  br label %bb94
bb89:
  %t338 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t340 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t338, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d21, i32 0, i32 1) })
  store i1 %t340, ptr %l173
  br label %bb90
bb90:
  %t341 = load i1, ptr %l173, !tbaa !21
  br i1 %t341, label %bb91, label %bb92
bb91:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d22, i32 0, i32 1) }, ptr %l174, !tbaa !27
  br label %bb93
bb92:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d23, i32 0, i32 1) }, ptr %l174, !tbaa !27
  br label %bb93
bb93:
  %t342 = load { i64, ptr }, ptr %l174, !tbaa !27
  store { i64, ptr } %t342, ptr %l171, !tbaa !27
  br label %bb94
bb94:
  %t343 = load { i64, ptr }, ptr %l171, !tbaa !27
  store { i64, ptr } %t343, ptr %l168, !tbaa !27
  br label %bb95
bb95:
  %t344 = load { i64, ptr }, ptr %l168, !tbaa !27
  store { i64, ptr } %t344, ptr %l165, !tbaa !27
  br label %bb96
bb96:
  %t345 = load { i64, ptr }, ptr %l165, !tbaa !27
  %t346 = load ptr, ptr %l0, !tbaa !29
  store ptr %t346, ptr %l175, !tbaa !29
  %t347 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t347, ptr %l176
  store { i64, ptr } %t345, ptr %l177, !tbaa !27
  %t349 = load ptr, ptr %l0, !tbaa !29
  %t350 = load i32, ptr %l9, !tbaa !23
  %t353 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t349, i32 %t350)
  store { i64, ptr } %t353, ptr %l180
  br label %bb97
bb97:
  %t354 = load { i64, ptr }, ptr %l180, !tbaa !27
  %t355 = extractvalue { i64, ptr } %t354, 0
  %t356 = extractvalue { i64, ptr } %t354, 1
  %t357 = mul i64 %t355, 1
  %t358 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t357)
  call void @llvm.memcpy.p0.p0.i64(ptr %t358, ptr %t356, i64 %t357, i1 false)
  %t359 = insertvalue { i64, ptr } undef, i64 %t355, 0
  %t360 = insertvalue { i64, ptr } %t359, ptr %t358, 1
  store { i64, ptr } %t360, ptr %l181, !tbaa !27
  %t361 = load ptr, ptr %l0, !tbaa !29
  %t362 = load i32, ptr %l10, !tbaa !23
  %t365 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t361, i32 %t362)
  store { i64, ptr } %t365, ptr %l184
  br label %bb98
bb98:
  %t366 = load { i64, ptr }, ptr %l184, !tbaa !27
  %t367 = extractvalue { i64, ptr } %t366, 0
  %t368 = extractvalue { i64, ptr } %t366, 1
  %t369 = mul i64 %t367, 1
  %t370 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t369)
  call void @llvm.memcpy.p0.p0.i64(ptr %t370, ptr %t368, i64 %t369, i1 false)
  %t371 = insertvalue { i64, ptr } undef, i64 %t367, 0
  %t372 = insertvalue { i64, ptr } %t371, ptr %t370, 1
  store { i64, ptr } %t372, ptr %l185, !tbaa !27
  %t373 = load ptr, ptr %l0, !tbaa !29
  %t374 = load i32, ptr %l10, !tbaa !23
  %t377 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t373, i32 %t374)
  store { i64, ptr } %t377, ptr %l188
  br label %bb99
bb99:
  %t378 = load ptr, ptr %l0, !tbaa !29
  store ptr %t378, ptr %l189, !tbaa !29
  %t379 = load ptr, ptr %l0, !tbaa !29
  %t381 = getelementptr %"compiler/check:Checker", ptr %t379, i32 0, i32 1
  %t382 = load ptr, ptr %t381, !tbaa !29
  %t383 = load i64, ptr %l11, !tbaa !24
  %t386 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %s0, ptr %t382, i64 %t383)
  store ptr %t386, ptr %l193
  br label %bb100
bb100:
  %t387 = load ptr, ptr %l193, !tbaa !29
  %t389 = getelementptr %"compiler/ast:Func", ptr %t387, i32 0, i32 2
  %t390 = load i32, ptr %t389, !tbaa !23
  %t391 = load ptr, ptr %l189, !tbaa !29
  %t393 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %s0, ptr %t391, i32 %t390)
  store { i64, ptr } %t393, ptr %l196
  br label %bb101
bb101:
  %t394 = load { i64, ptr }, ptr %l188, !tbaa !27
  %t395 = extractvalue { i64, ptr } %t394, 1
  %t396 = extractvalue { i64, ptr } %t394, 0
  %t397 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d24, i32 0, i32 1) }, 1
  %t398 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d24, i32 0, i32 1) }, 0
  %t399 = add i64 %t396, %t398
  %t400 = load { i64, ptr }, ptr %l196, !tbaa !27
  %t401 = extractvalue { i64, ptr } %t400, 1
  %t402 = extractvalue { i64, ptr } %t400, 0
  %t403 = add i64 %t399, %t402
  %t404 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t403)
  call void @olang_textcopy(ptr %t404, ptr %t395, i64 %t396)
  %t405 = getelementptr i8, ptr %t404, i64 %t396
  call void @olang_textcopy(ptr %t405, ptr %t397, i64 %t398)
  %t406 = getelementptr i8, ptr %t405, i64 %t398
  call void @olang_textcopy(ptr %t406, ptr %t401, i64 %t402)
  %t407 = insertvalue { i64, ptr } undef, i64 %t403, 0
  %t408 = insertvalue { i64, ptr } %t407, ptr %t404, 1
  %t410 = extractvalue { i64, ptr } %t408, 0
  %t411 = extractvalue { i64, ptr } %t408, 1
  %t412 = mul i64 %t410, 1
  %t413 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t412)
  call void @llvm.memcpy.p0.p0.i64(ptr %t413, ptr %t411, i64 %t412, i1 false)
  %t414 = insertvalue { i64, ptr } undef, i64 %t410, 0
  %t415 = insertvalue { i64, ptr } %t414, ptr %t413, 1
  %t416 = load ptr, ptr @__olang_prog_scope
  %t417 = load { i64, ptr }, ptr %l177, !tbaa !27
  %t418 = load { i64, ptr }, ptr %l181, !tbaa !27
  %t419 = load { i64, ptr }, ptr %l185, !tbaa !27
  %t421 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCommutesClash(ptr %t416, ptr %s0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t417, { i64, ptr } %t418, { i64, ptr } %t419, { i64, ptr } %t415)
  store %"compiler/msgs:Msg" %t421, ptr %l199
  br label %bb102
bb102:
  %t422 = load ptr, ptr %l175, !tbaa !29
  %t423 = load %"compiler/source:Span", ptr %l176
  %t424 = load %"compiler/msgs:Msg", ptr %l199
  %t425 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s0, ptr %t422, %"compiler/source:Span" %t423, %"compiler/msgs:Msg" %t424)
  store i64 %t425, ptr %l200
  br label %bb103
bb103:
  %t426 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t426)
  br label %bb104
bb104:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econd1(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l9 = alloca ptr
  %l11 = alloca %"compiler/source:Span"
  %l12 = alloca ptr
  %l15 = alloca i32
  %l19 = alloca i1
  %l23 = alloca ptr
  %l25 = alloca %"compiler/source:Span"
  %l28 = alloca { i64, ptr }
  %l30 = alloca %"compiler/msgs:Msg"
  %l31 = alloca i64
  %l32 = alloca ptr
  %l34 = alloca %"compiler/source:Span"
  %l35 = alloca ptr
  %s1 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t5 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t9 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v0, ptr %t2, ptr %t3, i32 %t5)
  store ptr %t9, ptr %l9
  br label %bb1
bb1:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t10)
  store %"compiler/source:Span" %t12, ptr %l11
  br label %bb2
bb2:
  %t13 = load ptr, ptr %l4, !tbaa !29
  %t14 = load ptr, ptr %l9, !tbaa !29
  %t15 = load %"compiler/source:Span", ptr %l11
  %t16 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %v0, ptr %v2, ptr %t13, ptr %t14, %"compiler/source:Span" %t15)
  store ptr %t16, ptr %l12
  br label %bb3
bb3:
  %t17 = load ptr, ptr %l12, !tbaa !29
  store ptr %t17, ptr %l2, !tbaa !29
  %t18 = load ptr, ptr %l2, !tbaa !29
  %t21 = call i32 @compiler_2fcheck_2etypeOf(ptr %v2, ptr %t18)
  store i32 %t21, ptr %l15
  br label %bb4
bb4:
  %t22 = load i32, ptr %l15, !tbaa !23
  store i32 %t22, ptr %l3, !tbaa !23
  %t23 = load i32, ptr %l3, !tbaa !23
  %t24 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t27 = icmp ne i32 %t23, %t24
  br i1 %t27, label %bb5, label %bb6
bb5:
  %t29 = load i32, ptr %l3, !tbaa !23
  %t30 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t33 = icmp ne i32 %t29, %t30
  store i1 %t33, ptr %l19, !tbaa !21
  br label %bb7
bb6:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb7
bb7:
  %t35 = load i1, ptr %l19, !tbaa !21
  br i1 %t35, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s1
  %t36 = load ptr, ptr %l0, !tbaa !29
  store ptr %t36, ptr %l23, !tbaa !29
  %t37 = load ptr, ptr %l1, !tbaa !29
  %t39 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t37)
  store %"compiler/source:Span" %t39, ptr %l25
  br label %bb10
bb9:
  br label %bb16
bb10:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load i32, ptr %l3, !tbaa !23
  %t44 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s1, ptr %t40, i32 %t41)
  store { i64, ptr } %t44, ptr %l28
  br label %bb11
bb11:
  %t45 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t45, 0
  %t47 = extractvalue { i64, ptr } %t45, 1
  %t48 = mul i64 %t46, 1
  %t49 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t48)
  call void @llvm.memcpy.p0.p0.i64(ptr %t49, ptr %t47, i64 %t48, i1 false)
  %t50 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t49, 1
  %t53 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCondNotBoolType(ptr %s1, ptr %s1, { i64, ptr } %t51)
  store %"compiler/msgs:Msg" %t53, ptr %l30
  br label %bb12
bb12:
  %t54 = load ptr, ptr %l23, !tbaa !29
  %t55 = load %"compiler/source:Span", ptr %l25
  %t56 = load %"compiler/msgs:Msg", ptr %l30
  %t57 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s1, ptr %t54, %"compiler/source:Span" %t55, %"compiler/msgs:Msg" %t56)
  store i64 %t57, ptr %l31
  br label %bb13
bb13:
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l32, !tbaa !29
  %t59 = load ptr, ptr %l1, !tbaa !29
  %t61 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t59)
  store %"compiler/source:Span" %t61, ptr %l34
  br label %bb14
bb14:
  %t62 = load ptr, ptr %l32, !tbaa !29
  %t63 = load %"compiler/source:Span", ptr %l34
  %t64 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t62, %"compiler/source:Span" %t63)
  store ptr %t64, ptr %l35
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s1)
  %t65 = load ptr, ptr %l35, !tbaa !29
  store ptr %t65, ptr %rv
  br label %ret
bb16:
  %t66 = load ptr, ptr %l2, !tbaa !29
  store ptr %t66, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econdReads(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/source:Span" %a2, { i64, ptr } %a3) #0 {
entry:
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i1
  %l9 = alloca i1
  %l10 = alloca i64
  %l11 = alloca i1
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l20 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l33 = alloca { i64, ptr }
  %l42 = alloca i1
  %l50 = alloca i1
  %l51 = alloca { i64, ptr }
  %l52 = alloca i64
  %l56 = alloca i64
  %l57 = alloca i64
  %l63 = alloca i1
  %l66 = alloca i1
  %l67 = alloca { i64, ptr }
  %l71 = alloca i1
  %l72 = alloca i1
  %l73 = alloca { i64, ptr }
  %l77 = alloca i1
  %l78 = alloca i1
  %l79 = alloca { i64, ptr }
  %l84 = alloca i1
  %l85 = alloca { i64, ptr }
  %l99 = alloca i1
  %l100 = alloca { i64, ptr }
  %l103 = alloca i1
  %l104 = alloca i1
  %l105 = alloca { i64, ptr }
  %l108 = alloca i1
  %l109 = alloca i1
  %l110 = alloca { i64, ptr }
  %l116 = alloca i1
  %rv = alloca i1
  store %"compiler/source:Span" %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/check:Checker", ptr %a0, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 4
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t14 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eTextOf(ptr %v0, ptr %v0, ptr %t10, i64 %a1)
  store { i64, ptr } %t14, ptr %l17
  br label %bb1
bb1:
  %t15 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t15, ptr %l18, !tbaa !27
  %t17 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t18 = load i32, ptr %t17, !tbaa !23
  %t20 = sext i32 %t18 to i64
  store i64 %t20, ptr %l20, !tbaa !24
  %t21 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 1
  %t22 = load i32, ptr %t21, !tbaa !23
  %t24 = sext i32 %t22 to i64
  store i64 %t24, ptr %l22, !tbaa !24
  %t25 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t25, 0
  store i64 %t26, ptr %l23, !tbaa !24
  %t27 = load i64, ptr %l20, !tbaa !24
  %t28 = icmp sge i64 %t27, 0
  br i1 %t28, label %bb2, label %bb3
bb2:
  %t30 = load i64, ptr %l20, !tbaa !24
  %t31 = load i64, ptr %l22, !tbaa !24
  %t32 = icmp sle i64 %t30, %t31
  br i1 %t32, label %bb4, label %bb5
bb3:
  call void @__olang_check_failed(ptr @olang_loc_f259f6ca06e66809_b1ef05920a904ef5)
  unreachable
bb4:
  %t34 = load i64, ptr %l22, !tbaa !24
  %t35 = load i64, ptr %l23, !tbaa !24
  %t36 = icmp sle i64 %t34, %t35
  br i1 %t36, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_f259f6ca06e66809_b1ef05920a904ef5)
  unreachable
bb6:
  %t38 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !27
  %t40 = load i64, ptr %l20, !tbaa !24
  %t41 = load i64, ptr %l22, !tbaa !24
  %t42 = getelementptr i8, ptr %t39, i64 %t40
  %t43 = sub i64 %t41, %t40
  %t44 = insertvalue { i64, ptr } undef, i64 %t43, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t42, 1
  store { i64, ptr } %t45, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  store i1 false, ptr %l7, !tbaa !21
  br label %bb8
bb7:
  call void @__olang_check_failed(ptr @olang_loc_f259f6ca06e66809_b1ef05920a904ef5)
  unreachable
bb8:
  %t47 = load i64, ptr %l6, !tbaa !24
  %t48 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t48, 0
  %t53 = icmp slt i64 %t47, %t50
  %t55 = xor i1 %t53, true
  br i1 %t55, label %bb9, label %bb10
bb9:
  br label %bb63
bb10:
  br label %bb11
bb11:
  %t57 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t57, ptr %l33, !tbaa !27
  %t58 = load i64, ptr %l6, !tbaa !24
  %t60 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !27
  %t62 = getelementptr i8, ptr %t61, i64 %t58
  %t63 = load i8, ptr %t62, !tbaa !32
  %t67 = icmp eq i8 %t63, 34
  br i1 %t67, label %bb12, label %bb13
bb12:
  %t69 = load i1, ptr %l7, !tbaa !21
  %t71 = xor i1 %t69, true
  store i1 %t71, ptr %l7, !tbaa !21
  br label %bb14
bb13:
  br label %bb14
bb14:
  %t73 = load i1, ptr %l7, !tbaa !21
  %t75 = xor i1 %t73, true
  br i1 %t75, label %bb15, label %bb16
bb15:
  %t77 = load i64, ptr %l6, !tbaa !24
  %t78 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t80 = extractvalue { i64, ptr } %t78, 0
  %t83 = add i64 %t77, %t80
  %t84 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t84, 0
  %t89 = icmp sle i64 %t83, %t86
  store i1 %t89, ptr %l42, !tbaa !21
  br label %bb17
bb16:
  store i1 false, ptr %l42, !tbaa !21
  br label %bb17
bb17:
  %t91 = load i1, ptr %l42, !tbaa !21
  br i1 %t91, label %bb18, label %bb19
bb18:
  %t92 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t92, ptr %l51, !tbaa !27
  %t93 = load i64, ptr %l6, !tbaa !24
  store i64 %t93, ptr %l52, !tbaa !24
  %t94 = load i64, ptr %l6, !tbaa !24
  %t95 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t97 = extractvalue { i64, ptr } %t95, 0
  %t100 = add i64 %t94, %t97
  store i64 %t100, ptr %l56, !tbaa !24
  %t101 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t102 = extractvalue { i64, ptr } %t101, 0
  store i64 %t102, ptr %l57, !tbaa !24
  %t103 = load i64, ptr %l52, !tbaa !24
  %t104 = icmp sge i64 %t103, 0
  br i1 %t104, label %bb20, label %bb21
bb19:
  store i1 false, ptr %l50, !tbaa !21
  br label %bb27
bb20:
  %t106 = load i64, ptr %l52, !tbaa !24
  %t107 = load i64, ptr %l56, !tbaa !24
  %t108 = icmp sle i64 %t106, %t107
  br i1 %t108, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_67410fc9d6566a9c_b1c73ab5a8b03798)
  unreachable
bb22:
  %t110 = load i64, ptr %l56, !tbaa !24
  %t111 = load i64, ptr %l57, !tbaa !24
  %t112 = icmp sle i64 %t110, %t111
  br i1 %t112, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_67410fc9d6566a9c_b1c73ab5a8b03798)
  unreachable
bb24:
  %t114 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !27
  %t116 = load i64, ptr %l52, !tbaa !24
  %t117 = load i64, ptr %l56, !tbaa !24
  %t118 = getelementptr i8, ptr %t115, i64 %t116
  %t119 = sub i64 %t117, %t116
  %t120 = insertvalue { i64, ptr } undef, i64 %t119, 0
  %t121 = insertvalue { i64, ptr } %t120, ptr %t118, 1
  %t122 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t125 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %t121, { i64, ptr } %t122)
  store i1 %t125, ptr %l63
  br label %bb26
bb25:
  call void @__olang_check_failed(ptr @olang_loc_67410fc9d6566a9c_b1c73ab5a8b03798)
  unreachable
bb26:
  %t126 = load i1, ptr %l63, !tbaa !21
  store i1 %t126, ptr %l50, !tbaa !21
  br label %bb27
bb27:
  %t127 = load i1, ptr %l50, !tbaa !21
  br i1 %t127, label %bb28, label %bb29
bb28:
  %t128 = load i64, ptr %l6, !tbaa !24
  %t130 = icmp eq i64 %t128, 0
  br i1 %t130, label %bb30, label %bb31
bb29:
  br label %bb61
bb30:
  store i1 true, ptr %l66, !tbaa !21
  br label %bb43
bb31:
  %t132 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t132, ptr %l67, !tbaa !27
  %t133 = load i64, ptr %l6, !tbaa !24
  %t135 = sub i64 %t133, 1
  %t137 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !27
  %t139 = getelementptr i8, ptr %t138, i64 %t135
  %t140 = load i8, ptr %t139, !tbaa !32
  %t142 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t140)
  store i1 %t142, ptr %l71
  br label %bb32
bb32:
  %t143 = load i1, ptr %l71, !tbaa !21
  br i1 %t143, label %bb33, label %bb34
bb33:
  store i1 true, ptr %l72, !tbaa !21
  br label %bb36
bb34:
  %t144 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t144, ptr %l73, !tbaa !27
  %t145 = load i64, ptr %l6, !tbaa !24
  %t147 = sub i64 %t145, 1
  %t149 = getelementptr { i64, ptr }, ptr %l73, i32 0, i32 1
  %t150 = load ptr, ptr %t149, !tbaa !27
  %t151 = getelementptr i8, ptr %t150, i64 %t147
  %t152 = load i8, ptr %t151, !tbaa !32
  %t154 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t152)
  store i1 %t154, ptr %l77
  br label %bb35
bb35:
  %t155 = load i1, ptr %l77, !tbaa !21
  store i1 %t155, ptr %l72, !tbaa !21
  br label %bb36
bb36:
  %t156 = load i1, ptr %l72, !tbaa !21
  br i1 %t156, label %bb37, label %bb38
bb37:
  store i1 true, ptr %l78, !tbaa !21
  br label %bb39
bb38:
  %t157 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t157, ptr %l79, !tbaa !27
  %t158 = load i64, ptr %l6, !tbaa !24
  %t160 = sub i64 %t158, 1
  %t162 = getelementptr { i64, ptr }, ptr %l79, i32 0, i32 1
  %t163 = load ptr, ptr %t162, !tbaa !27
  %t164 = getelementptr i8, ptr %t163, i64 %t160
  %t165 = load i8, ptr %t164, !tbaa !32
  %t167 = icmp eq i8 %t165, 95
  store i1 %t167, ptr %l78, !tbaa !21
  br label %bb39
bb39:
  %t169 = load i1, ptr %l78, !tbaa !21
  br i1 %t169, label %bb40, label %bb41
bb40:
  store i1 true, ptr %l84, !tbaa !21
  br label %bb42
bb41:
  %t170 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t170, ptr %l85, !tbaa !27
  %t171 = load i64, ptr %l6, !tbaa !24
  %t173 = sub i64 %t171, 1
  %t175 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t176 = load ptr, ptr %t175, !tbaa !27
  %t177 = getelementptr i8, ptr %t176, i64 %t173
  %t178 = load i8, ptr %t177, !tbaa !32
  %t180 = icmp eq i8 %t178, 46
  store i1 %t180, ptr %l84, !tbaa !21
  br label %bb42
bb42:
  %t182 = load i1, ptr %l84, !tbaa !21
  %t183 = xor i1 %t182, true
  store i1 %t183, ptr %l66, !tbaa !21
  br label %bb43
bb43:
  %t185 = load i1, ptr %l66, !tbaa !21
  store i1 %t185, ptr %l9, !tbaa !21
  %t186 = load i64, ptr %l6, !tbaa !24
  %t187 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t189 = extractvalue { i64, ptr } %t187, 0
  %t192 = add i64 %t186, %t189
  store i64 %t192, ptr %l10, !tbaa !24
  %t194 = load i64, ptr %l10, !tbaa !24
  %t195 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t197 = extractvalue { i64, ptr } %t195, 0
  %t200 = icmp sge i64 %t194, %t197
  br i1 %t200, label %bb44, label %bb45
bb44:
  store i1 true, ptr %l99, !tbaa !21
  br label %bb54
bb45:
  %t202 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t202, ptr %l100, !tbaa !27
  %t203 = load i64, ptr %l10, !tbaa !24
  %t205 = getelementptr { i64, ptr }, ptr %l100, i32 0, i32 1
  %t206 = load ptr, ptr %t205, !tbaa !27
  %t207 = getelementptr i8, ptr %t206, i64 %t203
  %t208 = load i8, ptr %t207, !tbaa !32
  %t210 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t208)
  store i1 %t210, ptr %l103
  br label %bb46
bb46:
  %t211 = load i1, ptr %l103, !tbaa !21
  br i1 %t211, label %bb47, label %bb48
bb47:
  store i1 true, ptr %l104, !tbaa !21
  br label %bb50
bb48:
  %t212 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t212, ptr %l105, !tbaa !27
  %t213 = load i64, ptr %l10, !tbaa !24
  %t215 = getelementptr { i64, ptr }, ptr %l105, i32 0, i32 1
  %t216 = load ptr, ptr %t215, !tbaa !27
  %t217 = getelementptr i8, ptr %t216, i64 %t213
  %t218 = load i8, ptr %t217, !tbaa !32
  %t220 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t218)
  store i1 %t220, ptr %l108
  br label %bb49
bb49:
  %t221 = load i1, ptr %l108, !tbaa !21
  store i1 %t221, ptr %l104, !tbaa !21
  br label %bb50
bb50:
  %t222 = load i1, ptr %l104, !tbaa !21
  br i1 %t222, label %bb51, label %bb52
bb51:
  store i1 true, ptr %l109, !tbaa !21
  br label %bb53
bb52:
  %t223 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t223, ptr %l110, !tbaa !27
  %t224 = load i64, ptr %l10, !tbaa !24
  %t226 = getelementptr { i64, ptr }, ptr %l110, i32 0, i32 1
  %t227 = load ptr, ptr %t226, !tbaa !27
  %t228 = getelementptr i8, ptr %t227, i64 %t224
  %t229 = load i8, ptr %t228, !tbaa !32
  %t231 = icmp eq i8 %t229, 95
  store i1 %t231, ptr %l109, !tbaa !21
  br label %bb53
bb53:
  %t233 = load i1, ptr %l109, !tbaa !21
  %t234 = xor i1 %t233, true
  store i1 %t234, ptr %l99, !tbaa !21
  br label %bb54
bb54:
  %t236 = load i1, ptr %l99, !tbaa !21
  store i1 %t236, ptr %l11, !tbaa !21
  %t237 = load i1, ptr %l9, !tbaa !21
  br i1 %t237, label %bb55, label %bb56
bb55:
  %t239 = load i1, ptr %l11, !tbaa !21
  store i1 %t239, ptr %l116, !tbaa !21
  br label %bb57
bb56:
  store i1 false, ptr %l116, !tbaa !21
  br label %bb57
bb57:
  %t241 = load i1, ptr %l116, !tbaa !21
  br i1 %t241, label %bb58, label %bb59
bb58:
  store i1 true, ptr %rv
  br label %ret
bb59:
  br label %bb60
bb60:
  br label %bb61
bb61:
  %t243 = load i64, ptr %l6, !tbaa !24
  %t245 = add i64 %t243, 1
  store i64 %t245, ptr %l6, !tbaa !24
  br label %bb62
bb62:
  br label %bb8
bb63:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econversionAt(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, ptr %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l12 = alloca i64
  %l13 = alloca { { i64, [3 x i64] }, { i64, ptr } }
  %l17 = alloca ptr
  %l21 = alloca i1
  %l25 = alloca i1
  %l27 = alloca i1
  %l28 = alloca i1
  %l30 = alloca i1
  %l40 = alloca { i64, ptr }
  %l43 = alloca ptr
  %l46 = alloca { i64, [2 x i64] }
  %l51 = alloca i32
  %l54 = alloca i64
  %l62 = alloca ptr
  %l63 = alloca ptr
  %l65 = alloca %"compiler/generic:Context"
  %l67 = alloca ptr
  %l70 = alloca i32
  %l73 = alloca i64
  %l75 = alloca ptr
  %l76 = alloca %"compiler/source:Span"
  %l77 = alloca ptr
  %l78 = alloca %"compiler/source:Span"
  %l82 = alloca ptr
  %l84 = alloca ptr
  %l89 = alloca ptr
  %l90 = alloca ptr
  %l94 = alloca { i64, ptr }
  %l95 = alloca %"compiler/typed:Block"
  %l105 = alloca { { i64, [3 x i64] }, { i64, ptr } }
  %l109 = alloca ptr
  %l110 = alloca i64
  %l111 = alloca i64
  %l112 = alloca %"compiler/source:Span"
  %l113 = alloca i64
  %l114 = alloca %"compiler/source:Span"
  %l115 = alloca { i64, ptr }
  %l116 = alloca { i64, [3 x i64] }
  %l119 = alloca { i64, ptr }
  %l122 = alloca { i64, ptr }
  %l125 = alloca %"compiler/check:ContractAsk"
  %s0 = alloca %olang.scope
  %t70 = alloca { i64, [2 x i64] }, align 8
  %t115 = alloca %"compiler/generic:Context", align 8
  %t153 = alloca { i64, [3 x i64] }, align 8
  %t252 = alloca %"compiler/check:ContractAsk", align 8
  %t263 = alloca %"compiler/check:ContractAsk", align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  store ptr %a3, ptr %l3
  store i32 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l17
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l17, !tbaa !29
  store ptr %t4, ptr %l5, !tbaa !29
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t7 = getelementptr %"compiler/check:frame", ptr %t5, i32 0, i32 51
  %t8 = load i64, ptr %t7, !tbaa !24
  %t10 = icmp ne i64 %t8, 0
  br i1 %t10, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb4
bb3:
  %t12 = load ptr, ptr %l5, !tbaa !29
  %t14 = getelementptr %"compiler/check:frame", ptr %t12, i32 0, i32 0
  %t15 = load i64, ptr %t14, !tbaa !24
  %t17 = icmp slt i64 %t15, 0
  store i1 %t17, ptr %l21, !tbaa !21
  br label %bb4
bb4:
  %t19 = load i1, ptr %l21, !tbaa !21
  br i1 %t19, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l25, !tbaa !21
  br label %bb8
bb6:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eevalOnly(ptr %v0, ptr %t20)
  store i1 %t22, ptr %l27
  br label %bb7
bb7:
  %t23 = load i1, ptr %l27, !tbaa !21
  store i1 %t23, ptr %l25, !tbaa !21
  br label %bb8
bb8:
  %t24 = load i1, ptr %l25, !tbaa !21
  br i1 %t24, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l28, !tbaa !21
  br label %bb12
bb10:
  %t25 = load ptr, ptr %l3, !tbaa !29
  %t27 = call i1 @compiler_2fcheck_2eclosedExpr(ptr %v1, ptr %t25)
  store i1 %t27, ptr %l30
  br label %bb11
bb11:
  %t28 = load i1, ptr %l30, !tbaa !21
  %t29 = xor i1 %t28, true
  store i1 %t29, ptr %l28, !tbaa !21
  br label %bb12
bb12:
  %t31 = load i1, ptr %l28, !tbaa !21
  br i1 %t31, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb14:
  br label %bb15
bb15:
  %t32 = load ptr, ptr %l5, !tbaa !29
  %t34 = getelementptr %"compiler/check:frame", ptr %t32, i32 0, i32 1
  %t35 = load i64, ptr %t34, !tbaa !24
  store i64 %t35, ptr %l6, !tbaa !24
  %t37 = load ptr, ptr %l5, !tbaa !29
  %t39 = getelementptr %"compiler/check:frame", ptr %t37, i32 0, i32 2
  %t40 = load i64, ptr %t39, !tbaa !24
  store i64 %t40, ptr %l7, !tbaa !24
  %t42 = load ptr, ptr %l5, !tbaa !29
  %t44 = getelementptr %"compiler/check:frame", ptr %t42, i32 0, i32 0
  %t45 = load i64, ptr %t44, !tbaa !24
  store i64 %t45, ptr %l8, !tbaa !24
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load %"compiler/source:Span", ptr %l2
  %t51 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %s0, ptr %t47, %"compiler/source:Span" %t48)
  store { i64, ptr } %t51, ptr %l40
  br label %bb16
bb16:
  %t52 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t53 = extractvalue { i64, ptr } %t52, 1
  %t54 = extractvalue { i64, ptr } %t52, 0
  %t55 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t54)
  call void @olang_textcopy(ptr %t55, ptr %t53, i64 %t54)
  %t56 = insertvalue { i64, ptr } undef, i64 %t54, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t55, 1
  %t59 = extractvalue { i64, ptr } %t57, 0
  %t60 = extractvalue { i64, ptr } %t57, 1
  %t61 = mul i64 %t59, 1
  %t62 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t61)
  call void @llvm.memcpy.p0.p0.i64(ptr %t62, ptr %t60, i64 %t61, i1 false)
  %t63 = insertvalue { i64, ptr } undef, i64 %t59, 0
  %t64 = insertvalue { i64, ptr } %t63, ptr %t62, 1
  store { i64, ptr } %t64, ptr %l9, !tbaa !27
  %t66 = load ptr, ptr %l0, !tbaa !29
  store ptr %t66, ptr %l43, !tbaa !29
  %t67 = load i64, ptr %l6, !tbaa !24
  %t68 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t69 = load i32, ptr %t68, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t70
  %t71 = getelementptr { i64, [2 x i64] }, ptr %t70, i32 0, i32 0
  store i64 7, ptr %t71
  %t73 = insertvalue { i64, i32 } undef, i64 %t67, 0
  %t75 = insertvalue { i64, i32 } %t73, i32 %t69, 1
  %t76 = getelementptr { i64, [2 x i64] }, ptr %t70, i32 0, i32 1
  store { i64, i32 } %t75, ptr %t76
  %t77 = load { i64, [2 x i64] }, ptr %t70
  store { i64, [2 x i64] } %t77, ptr %l46
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/check:Checker", ptr %t78, i32 0, i32 1
  %t81 = load ptr, ptr %t80, !tbaa !29
  %t83 = getelementptr %"compiler/generic:Program", ptr %t81, i32 0, i32 2
  %t84 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t87 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t83, i32 0, i32 %t84, i32 0, i32 0, i64 0)
  store i32 %t87, ptr %l51
  br label %bb17
bb17:
  %t88 = load i64, ptr %l6, !tbaa !24
  %t89 = load %"compiler/source:Span", ptr %l1
  %t90 = load ptr, ptr %l43, !tbaa !29
  %t91 = load { i64, [2 x i64] }, ptr %l46
  %t92 = load i32, ptr %l51, !tbaa !23
  %t95 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enewBody(ptr %v0, ptr %t90, { i64, [2 x i64] } %t91, i32 %t92, i64 %t88, %"compiler/source:Span" %t89)
  store i64 %t95, ptr %l54
  br label %bb18
bb18:
  %t96 = load i64, ptr %l54, !tbaa !24
  store i64 %t96, ptr %l10, !tbaa !24
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/check:Checker", ptr %t97, i32 0, i32 19
  %t100 = load i64, ptr %l10, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t99, i64 %t100, i64 1)
  br label %bb19
bb19:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t104 = load i64, ptr %l10, !tbaa !24
  %t105 = load i64, ptr %l6, !tbaa !24
  %t106 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t111 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %v0, ptr %t103, i64 %t104, i64 %t105, i32 %t106, i32 0)
  store ptr %t111, ptr %l62
  br label %bb20
bb20:
  %t112 = load ptr, ptr %l62, !tbaa !29
  store ptr %t112, ptr %l63, !tbaa !29
  %t114 = load i64, ptr %l6, !tbaa !24
  call void @compiler_2fgeneric_3aContext_2ector(ptr %t115, ptr %v0, i64 %t114, i64 -1)
  call void @llvm.memmove.p0.p0.i64(ptr %l65, ptr %t115, i64 160, i1 false)
  br label %bb21
bb21:
  %t117 = load ptr, ptr %l63, !tbaa !29
  %t118 = getelementptr %"compiler/check:frame", ptr %t117, i32 0, i32 4
  call void @llvm.memmove.p0.p0.i64(ptr %t118, ptr %l65, i64 160, i1 false)
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t121 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t119)
  store ptr %t121, ptr %l67
  br label %bb22
bb22:
  %t122 = load %"compiler/source:Span", ptr %l1
  %t123 = load ptr, ptr %l67, !tbaa !29
  %t126 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddBlock(ptr %v0, ptr %t123, i32 -1, i32 0, %"compiler/source:Span" %t122)
  store i32 %t126, ptr %l70
  br label %bb23
bb23:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t129 = getelementptr %"compiler/check:Checker", ptr %t127, i32 0, i32 37
  %t131 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t129)
  store i64 %t131, ptr %l73
  br label %bb24
bb24:
  %t132 = load i64, ptr %l73, !tbaa !24
  store i64 %t132, ptr %l12, !tbaa !24
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t135 = getelementptr %"compiler/check:Checker", ptr %t133, i32 0, i32 37
  store ptr %t135, ptr %l75, !tbaa !29
  %t136 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t136, ptr %l76
  %t137 = load ptr, ptr %l0, !tbaa !29
  store ptr %t137, ptr %l77, !tbaa !29
  %t138 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t138, ptr %l78
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t140 = load ptr, ptr %l3, !tbaa !29
  %t141 = load i64, ptr %l8, !tbaa !24
  %t145 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopyExpr(ptr %v0, ptr %v1, ptr %v0, ptr %t139, ptr %t140, i64 %t141)
  store ptr %t145, ptr %l82
  br label %bb25
bb25:
  %t146 = load i32, ptr %l4, !tbaa !23
  %t147 = load ptr, ptr %l77, !tbaa !29
  %t148 = load %"compiler/source:Span", ptr %l78
  %t149 = load ptr, ptr %l82, !tbaa !29
  %t151 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efitsTest(ptr %v0, ptr %v0, ptr %v0, ptr %t147, %"compiler/source:Span" %t148, ptr %t149, i32 %t146)
  store ptr %t151, ptr %l84
  br label %bb26
bb26:
  %t152 = load ptr, ptr %l84, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t153
  %t154 = getelementptr { i64, [3 x i64] }, ptr %t153, i32 0, i32 0
  store i64 6, ptr %t154
  %t155 = load %"compiler/source:Span", ptr %l76
  %t156 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t155, 0
  %t158 = insertvalue { %"compiler/source:Span", ptr } %t156, ptr %t152, 1
  %t159 = getelementptr { i64, [3 x i64] }, ptr %t153, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t158, ptr %t159
  %t160 = load { i64, [3 x i64] }, ptr %t153
  %t162 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t160, ptr %t162
  %t163 = load ptr, ptr %l75, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t163, ptr %t162)
  br label %bb27
bb27:
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t167 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t165)
  store ptr %t167, ptr %l89
  br label %bb28
bb28:
  %t168 = load ptr, ptr %l89, !tbaa !29
  store ptr %t168, ptr %l90, !tbaa !29
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t171 = getelementptr %"compiler/check:Checker", ptr %t169, i32 0, i32 37
  %t172 = load i64, ptr %l12, !tbaa !24
  %t175 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t171, i64 %t172)
  store { i64, ptr } %t175, ptr %l94
  br label %bb29
bb29:
  %t176 = load { i64, ptr }, ptr %l94, !tbaa !27
  %t177 = call %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v0, i32 0, { i64, ptr } %t176)
  store %"compiler/typed:Block" %t177, ptr %l95
  br label %bb30
bb30:
  %t178 = load %"compiler/typed:Block", ptr %l95
  %t179 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Block" %t178, ptr %t179
  %t181 = load ptr, ptr %l90, !tbaa !29
  %t182 = getelementptr %"compiler/typed:Body", ptr %t181, i32 0, i32 11
  store ptr %t179, ptr %t182, !tbaa !29
  %t183 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t183)
  br label %bb31
bb31:
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t187 = getelementptr %"compiler/check:Checker", ptr %t185, i32 0, i32 19
  %t188 = load i64, ptr %l10, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t187, i64 %t188, i64 2)
  br label %bb32
bb32:
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t193 = getelementptr %"compiler/check:Checker", ptr %t191, i32 0, i32 1
  %t194 = load ptr, ptr %t193, !tbaa !29
  %t196 = getelementptr %"compiler/generic:Program", ptr %t194, i32 0, i32 0
  %t197 = load ptr, ptr %t196, !tbaa !29
  %t199 = getelementptr %"compiler/load:Loader", ptr %t197, i32 0, i32 4
  %t200 = load ptr, ptr %t199, !tbaa !29
  %t202 = call { { i64, [3 x i64] }, { i64, ptr } } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eTopContext(ptr %v0, ptr %s0, ptr %t200)
  store { { i64, [3 x i64] }, { i64, ptr } } %t202, ptr %l105
  br label %bb33
bb33:
  %t203 = load { { i64, [3 x i64] }, { i64, ptr } }, ptr %l105
  store { { i64, [3 x i64] }, { i64, ptr } } %t203, ptr %l13
  %t204 = getelementptr { { i64, [3 x i64] }, { i64, ptr } }, ptr %l13, i32 0, i32 0
  %t205 = load { i64, [3 x i64] }, ptr %t204
  %t207 = getelementptr { { i64, [3 x i64] }, { i64, ptr } }, ptr %l13, i32 0, i32 1
  %t208 = load { i64, ptr }, ptr %t207, !tbaa !27
  %t210 = load ptr, ptr %l0, !tbaa !29
  %t212 = getelementptr %"compiler/check:Checker", ptr %t210, i32 0, i32 108
  store ptr %t212, ptr %l109, !tbaa !29
  %t213 = load i64, ptr %l10, !tbaa !24
  store i64 %t213, ptr %l110, !tbaa !24
  %t214 = load i64, ptr %l7, !tbaa !24
  store i64 %t214, ptr %l111, !tbaa !24
  %t215 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t215, ptr %l112
  %t216 = load i64, ptr %l7, !tbaa !24
  store i64 %t216, ptr %l113, !tbaa !24
  %t217 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t217, ptr %l114
  %t218 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t218, ptr %l115, !tbaa !27
  store { i64, [3 x i64] } %t205, ptr %l116
  %t222 = extractvalue { i64, ptr } %t208, 1
  %t223 = extractvalue { i64, ptr } %t208, 0
  %t224 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t223)
  call void @olang_textcopy(ptr %t224, ptr %t222, i64 %t223)
  %t225 = insertvalue { i64, ptr } undef, i64 %t223, 0
  %t226 = insertvalue { i64, ptr } %t225, ptr %t224, 1
  %t228 = extractvalue { i64, ptr } %t226, 0
  %t229 = extractvalue { i64, ptr } %t226, 1
  %t230 = mul i64 %t228, 1
  %t231 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t230)
  call void @llvm.memcpy.p0.p0.i64(ptr %t231, ptr %t229, i64 %t230, i1 false)
  %t232 = insertvalue { i64, ptr } undef, i64 %t228, 0
  %t233 = insertvalue { i64, ptr } %t232, ptr %t231, 1
  store { i64, ptr } %t233, ptr %l119, !tbaa !27
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t235 = load i32, ptr %l4, !tbaa !23
  %t238 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t234, i32 %t235)
  store { i64, ptr } %t238, ptr %l122
  br label %bb34
bb34:
  %t239 = load { i64, ptr }, ptr %l122, !tbaa !27
  %t240 = extractvalue { i64, ptr } %t239, 1
  %t241 = extractvalue { i64, ptr } %t239, 0
  %t242 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t241)
  call void @olang_textcopy(ptr %t242, ptr %t240, i64 %t241)
  %t243 = insertvalue { i64, ptr } undef, i64 %t241, 0
  %t244 = insertvalue { i64, ptr } %t243, ptr %t242, 1
  %t246 = extractvalue { i64, ptr } %t244, 0
  %t247 = extractvalue { i64, ptr } %t244, 1
  %t248 = mul i64 %t246, 1
  %t249 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t248)
  call void @llvm.memcpy.p0.p0.i64(ptr %t249, ptr %t247, i64 %t248, i1 false)
  %t250 = insertvalue { i64, ptr } undef, i64 %t246, 0
  %t251 = insertvalue { i64, ptr } %t250, ptr %t249, 1
  %t253 = load i64, ptr %l110, !tbaa !24
  %t254 = load i64, ptr %l111, !tbaa !24
  %t255 = load %"compiler/source:Span", ptr %l112
  %t256 = load i64, ptr %l113, !tbaa !24
  %t257 = load %"compiler/source:Span", ptr %l114
  %t258 = load { i64, ptr }, ptr %l115, !tbaa !27
  %t259 = load { i64, [3 x i64] }, ptr %l116
  %t260 = load { i64, ptr }, ptr %l119, !tbaa !27
  call void @compiler_2fcheck_3aContractAsk_2ector(ptr %t252, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, i64 %t253, i64 %t254, %"compiler/source:Span" %t255, i64 %t256, %"compiler/source:Span" %t257, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d25, i32 0, i32 1) }, { i64, ptr } %t258, { i64, [3 x i64] } %t259, { i64, ptr } %t260, { i64, ptr } %t251)
  call void @llvm.memmove.p0.p0.i64(ptr %l125, ptr %t252, i64 136, i1 false)
  br label %bb35
bb35:
  %t262 = load ptr, ptr %l109, !tbaa !29
  call void @llvm.memmove.p0.p0.i64(ptr %t263, ptr %l125, i64 136, i1 false)
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aContractAsk_3e_2ePu_H286c5e5dcd81788bf1de6ef6fc9774a9(ptr %v0, ptr %v0, ptr %t262, ptr %t263)
  br label %bb36
bb36:
  %t264 = load ptr, ptr %l0, !tbaa !29
  %t266 = getelementptr %"compiler/check:Checker", ptr %t264, i32 0, i32 109
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t266, i64 -1)
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectContext(ptr %out, ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i64
  %l11 = alloca ptr
  %l18 = alloca ptr
  %l22 = alloca i64
  %l26 = alloca i32
  %l27 = alloca %"compiler/generic:Context"
  %l36 = alloca %"compiler/generic:Context"
  %l42 = alloca ptr
  %l46 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l50 = alloca %"compiler/generic:Context"
  %l52 = alloca ptr
  %l55 = alloca %"compiler/generic:Context"
  %t42 = alloca %"compiler/generic:Context", align 8
  %t65 = alloca %"compiler/generic:Context", align 8
  %t102 = alloca %"compiler/generic:Context", align 8
  %t112 = alloca %"compiler/generic:Context", align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 14
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store ptr %t7, ptr %l11
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l11, !tbaa !29
  %t10 = getelementptr %"compiler/typed:Body", ptr %t8, i32 0, i32 1
  %t11 = load { i64, [2 x i64] }, ptr %t10
  store { i64, [2 x i64] } %t11, ptr %l2
  %t13 = load { i64, [2 x i64] }, ptr %l2
  %t15 = extractvalue { i64, [2 x i64] } %t13, 0
  %t16 = icmp eq i64 %t15, 0
  br i1 %t16, label %bb2, label %bb3
bb2:
  %t18 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t19 = getelementptr { i64 }, ptr %t18, i32 0, i32 0
  %t20 = load i64, ptr %t19
  store i64 %t20, ptr %l3, !tbaa !24
  br label %bb4
bb3:
  br label %bb8
bb4:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/check:Checker", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  store ptr %t25, ptr %l18, !tbaa !29
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/check:Checker", ptr %t26, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t30 = load i64, ptr %l3, !tbaa !24
  %t33 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t29, i64 %t30)
  store i64 %t33, ptr %l22
  br label %bb5
bb5:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/check:Checker", ptr %t34, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t38 = load i64, ptr %l3, !tbaa !24
  %t41 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceArgs(ptr %v0, ptr %t37, i64 %t38)
  store i32 %t41, ptr %l26
  br label %bb6
bb6:
  %t43 = load ptr, ptr %l18, !tbaa !29
  %t44 = load i64, ptr %l22, !tbaa !24
  %t45 = load i32, ptr %l26, !tbaa !23
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnContext(ptr %t42, ptr %v0, ptr %v1, ptr %t43, i64 %t44, i32 %t45)
  call void @llvm.memmove.p0.p0.i64(ptr %l27, ptr %t42, i64 160, i1 false)
  br label %bb7
bb7:
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l27, i64 160, i1 false)
  br label %ret
bb8:
  %t46 = load { i64, [2 x i64] }, ptr %l2
  %t48 = extractvalue { i64, [2 x i64] } %t46, 0
  %t49 = icmp eq i64 %t48, 1
  br i1 %t49, label %bb9, label %bb10
bb9:
  %t51 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t52 = getelementptr { i32, i32 }, ptr %t51, i32 0, i32 0
  %t53 = load i32, ptr %t52
  store i32 %t53, ptr %l4, !tbaa !23
  %t55 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t56 = getelementptr { i32, i32 }, ptr %t55, i32 0, i32 1
  %t57 = load i32, ptr %t56
  store i32 %t57, ptr %l5, !tbaa !23
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/check:Checker", ptr %t59, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t63 = load i32, ptr %l4, !tbaa !23
  %t64 = load i32, ptr %l5, !tbaa !23
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorContext(ptr %t65, ptr %v0, ptr %v1, ptr %t62, i32 %t63, i32 %t64)
  call void @llvm.memmove.p0.p0.i64(ptr %l36, ptr %t65, i64 160, i1 false)
  br label %bb12
bb12:
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l36, i64 160, i1 false)
  br label %ret
bb13:
  %t69 = load { i64, [2 x i64] }, ptr %l2
  %t71 = extractvalue { i64, [2 x i64] } %t69, 0
  %t72 = icmp eq i64 %t71, 10
  br i1 %t72, label %bb14, label %bb15
bb14:
  %t74 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t75 = getelementptr { i32, i64 }, ptr %t74, i32 0, i32 0
  %t76 = load i32, ptr %t75
  store i32 %t76, ptr %l6, !tbaa !23
  %t78 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t79 = getelementptr { i32, i64 }, ptr %t78, i32 0, i32 1
  %t80 = load i64, ptr %t79
  store i64 %t80, ptr %l7, !tbaa !24
  br label %bb16
bb15:
  br label %bb19
bb16:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/check:Checker", ptr %t82, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !29
  store ptr %t85, ptr %l42, !tbaa !29
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/check:Checker", ptr %t86, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !29
  %t90 = load i32, ptr %l6, !tbaa !23
  %t93 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnySlots(ptr %v0, ptr %v0, ptr %t89, i32 %t90)
  store { i64, ptr } %t93, ptr %l46
  br label %bb17
bb17:
  %t94 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t94, ptr %l47, !tbaa !27
  %t95 = load i64, ptr %l7, !tbaa !24
  %t97 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !27
  %t99 = getelementptr %"compiler/generic:AnySlot", ptr %t98, i64 %t95
  %t100 = getelementptr %"compiler/generic:AnySlot", ptr %t99, i32 0, i32 1
  %t101 = load i32, ptr %t100, !tbaa !23
  %t103 = load ptr, ptr %l42, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceContext(ptr %t102, ptr %v0, ptr %v1, ptr %t103, i32 %t101)
  call void @llvm.memmove.p0.p0.i64(ptr %l50, ptr %t102, i64 160, i1 false)
  br label %bb18
bb18:
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l50, i64 160, i1 false)
  br label %ret
bb19:
  br i1 true, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb25
bb22:
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t105)
  store ptr %t107, ptr %l52
  br label %bb23
bb23:
  %t108 = load ptr, ptr %l52, !tbaa !29
  %t110 = getelementptr %"compiler/check:frame", ptr %t108, i32 0, i32 1
  %t111 = load i64, ptr %t110, !tbaa !24
  call void @compiler_2fgeneric_3aContext_2ector(ptr %t112, ptr %v1, i64 %t111, i64 -1)
  call void @llvm.memmove.p0.p0.i64(ptr %l55, ptr %t112, i64 160, i1 false)
  br label %bb24
bb24:
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l55, i64 160, i1 false)
  br label %ret
bb25:
  call void @__olang_check_failed(ptr @olang_loc_f494bb64cf9470cb_fc1fe1776461b86f)
  unreachable
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclareUnknown(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca i1
  %l18 = alloca { i64, ptr }
  %l19 = alloca i1
  %l27 = alloca i64
  %l28 = alloca ptr
  %l29 = alloca %"compiler/source:Span"
  %l32 = alloca i32
  %l35 = alloca ptr
  %s2 = alloca %olang.scope
  %t40 = alloca { i64, [2 x i64] }, align 8
  %t62 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = xor i1 %a2, true
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t6 = load ptr, ptr %l8, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l8, !tbaa !29
  %t10 = load i64, ptr %t9, !range !{i64 0, i64 30}
  %t12 = icmp eq i64 %t10, 0
  store i1 %t12, ptr %l9, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l9, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr { i64, [4 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", i32 }, ptr %t16, i32 0, i32 0
  %t18 = load %"compiler/source:Span", ptr %t17
  store %"compiler/source:Span" %t18, ptr %l3
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t22 = getelementptr { i64, [4 x i64] }, ptr %t20, i32 0, i32 1
  %t23 = getelementptr { %"compiler/source:Span", i32 }, ptr %t22, i32 0, i32 1
  %t24 = load i32, ptr %t23
  store i32 %t24, ptr %l4, !tbaa !23
  br label %bb8
bb7:
  br label %bb17
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load i32, ptr %l4, !tbaa !23
  %t30 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t26, i32 %t27)
  store { i64, ptr } %t30, ptr %l18
  br label %bb9
bb9:
  %t31 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t32 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t31, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d26, i32 0, i32 1) })
  store i1 %t32, ptr %l19
  br label %bb10
bb10:
  %t33 = load i1, ptr %l19, !tbaa !21
  %t34 = xor i1 %t33, true
  br i1 %t34, label %bb11, label %bb12
bb11:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load i32, ptr %l4, !tbaa !23
  %t38 = load %"compiler/source:Span", ptr %l3
  %t39 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t40
  %t41 = getelementptr { i64, [2 x i64] }, ptr %t40, i32 0, i32 0
  store i64 5, ptr %t41
  %t42 = load { i64, [2 x i64] }, ptr %t40
  %t49 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %t36, i32 %t37, %"compiler/source:Span" %t38, i32 %t39, i32 1, { i64, [2 x i64] } %t42)
  store i64 %t49, ptr %l27
  br label %bb13
bb12:
  br label %bb16
bb13:
  %t50 = load i64, ptr %l27, !tbaa !24
  %t51 = load ptr, ptr %l0, !tbaa !29
  store ptr %t51, ptr %l28, !tbaa !29
  %t52 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t52, ptr %l29
  %t55 = trunc i64 %t50 to i32
  store i32 %t55, ptr %l32, !tbaa !23
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t58 = load %"compiler/source:Span", ptr %l3
  %t61 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v0, ptr %t57, %"compiler/source:Span" %t58)
  store ptr %t61, ptr %l35
  br label %bb14
bb14:
  store { i64, [3 x i64] } zeroinitializer, ptr %t62
  %t63 = getelementptr { i64, [3 x i64] }, ptr %t62, i32 0, i32 0
  store i64 0, ptr %t63
  %t64 = load %"compiler/source:Span", ptr %l29
  %t65 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t64, 0
  %t66 = load i32, ptr %l32, !tbaa !23
  %t67 = insertvalue { %"compiler/source:Span", i32, ptr } %t65, i32 %t66, 1
  %t68 = load ptr, ptr %l35, !tbaa !29
  %t69 = insertvalue { %"compiler/source:Span", i32, ptr } %t67, ptr %t68, 2
  %t70 = getelementptr { i64, [3 x i64] }, ptr %t62, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t69, ptr %t70
  %t71 = load { i64, [3 x i64] }, ptr %t62
  %t73 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t71, ptr %t73
  %t74 = load ptr, ptr %l28, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t74, ptr %t73)
  br label %bb15
bb15:
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s2)
  br label %bb22
bb17:
  br i1 true, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_7e44f5428cde099f_6973e730479eef7b)
  unreachable
bb22:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeqShaped(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca { i64, ptr }
  %l6 = alloca ptr
  %l9 = alloca ptr
  %l13 = alloca i32
  %l14 = alloca i32
  %l15 = alloca { i64, ptr }
  %l19 = alloca i1
  %l22 = alloca ptr
  %l24 = alloca { i64, ptr }
  %l26 = alloca i32
  %l27 = alloca i32
  %l30 = alloca i1
  %l33 = alloca ptr
  %l36 = alloca ptr
  %l38 = alloca { i64, ptr }
  %l40 = alloca i32
  %l41 = alloca i32
  %l46 = alloca i32
  %l47 = alloca i1
  %l48 = alloca i1
  %l51 = alloca ptr
  %l53 = alloca { i64, ptr }
  %l55 = alloca i32
  %l56 = alloca i32
  %l61 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  store ptr %t6, ptr %l6, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  store ptr %t12, ptr %l9, !tbaa !29
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/check:Checker", ptr %t13, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t20 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t16, i64 %a2)
  store i32 %t20, ptr %l13
  br label %bb1
bb1:
  %t21 = load ptr, ptr %l9, !tbaa !29
  %t22 = load i32, ptr %l13, !tbaa !23
  %t23 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t21, i32 %t22)
  store i32 %t23, ptr %l14
  br label %bb2
bb2:
  %t24 = load ptr, ptr %l6, !tbaa !29
  %t25 = load i32, ptr %l14, !tbaa !23
  %t26 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t24, i32 %t25)
  store { i64, ptr } %t26, ptr %l15
  br label %bb3
bb3:
  %t27 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t27, ptr %l3, !tbaa !27
  %t28 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t28, 0
  %t32 = icmp eq i64 %t30, 2
  br i1 %t32, label %bb4, label %bb5
bb4:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/check:Checker", ptr %t34, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t39 = getelementptr %"compiler/generic:Program", ptr %t37, i32 0, i32 2
  store ptr %t39, ptr %l22, !tbaa !29
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t41, ptr %l24, !tbaa !27
  %t42 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = getelementptr i32, ptr %t43, i64 1
  %t45 = load i32, ptr %t44, !tbaa !33
  %t48 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t40, i32 %t45)
  store i32 %t48, ptr %l26
  br label %bb6
bb5:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb21
bb6:
  %t49 = load ptr, ptr %l22, !tbaa !29
  %t50 = load i32, ptr %l26, !tbaa !23
  %t51 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t49, i32 %t50)
  store i32 %t51, ptr %l27
  br label %bb7
bb7:
  %t52 = load i32, ptr %l27, !range !{i32 0, i32 33}
  %t54 = trunc i64 25 to i32
  %t55 = icmp eq i32 %t52, %t54
  br i1 %t55, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb14
bb9:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/check:Checker", ptr %t57, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t62 = getelementptr %"compiler/generic:Program", ptr %t60, i32 0, i32 2
  store ptr %t62, ptr %l33, !tbaa !29
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/check:Checker", ptr %t63, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t68 = getelementptr %"compiler/generic:Program", ptr %t66, i32 0, i32 2
  store ptr %t68, ptr %l36, !tbaa !29
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t70, ptr %l38, !tbaa !27
  %t71 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !27
  %t73 = getelementptr i32, ptr %t72, i64 1
  %t74 = load i32, ptr %t73, !tbaa !33
  %t77 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t69, i32 %t74)
  store i32 %t77, ptr %l40
  br label %bb10
bb10:
  %t78 = load ptr, ptr %l36, !tbaa !29
  %t79 = load i32, ptr %l40, !tbaa !23
  %t80 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t78, i32 %t79)
  store i32 %t80, ptr %l41
  br label %bb11
bb11:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/check:Checker", ptr %t81, i32 0, i32 1
  %t84 = load ptr, ptr %t83, !tbaa !29
  %t86 = getelementptr %"compiler/generic:Program", ptr %t84, i32 0, i32 2
  %t87 = load i32, ptr %l1, !tbaa !23
  %t90 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t86, i32 %t87)
  store i32 %t90, ptr %l46
  br label %bb12
bb12:
  %t91 = load ptr, ptr %l33, !tbaa !29
  %t92 = load i32, ptr %l41, !tbaa !23
  %t93 = load i32, ptr %l46, !tbaa !23
  %t94 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t91, i32 %t92, i32 %t93)
  store i1 %t94, ptr %l47
  br label %bb13
bb13:
  %t95 = load i1, ptr %l47, !tbaa !21
  store i1 %t95, ptr %l30, !tbaa !21
  br label %bb14
bb14:
  %t96 = load i1, ptr %l30, !tbaa !21
  br i1 %t96, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l48, !tbaa !21
  br label %bb20
bb16:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/check:Checker", ptr %t97, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !29
  %t102 = getelementptr %"compiler/generic:Program", ptr %t100, i32 0, i32 2
  store ptr %t102, ptr %l51, !tbaa !29
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t104 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t104, ptr %l53, !tbaa !27
  %t105 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !27
  %t107 = getelementptr i32, ptr %t106, i64 1
  %t108 = load i32, ptr %t107, !tbaa !33
  %t111 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t103, i32 %t108)
  store i32 %t111, ptr %l55
  br label %bb17
bb17:
  %t112 = load ptr, ptr %l51, !tbaa !29
  %t113 = load i32, ptr %l55, !tbaa !23
  %t114 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t112, i32 %t113)
  store i32 %t114, ptr %l56
  br label %bb18
bb18:
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"compiler/check:Checker", ptr %t115, i32 0, i32 1
  %t118 = load ptr, ptr %t117, !tbaa !29
  %t120 = getelementptr %"compiler/generic:Program", ptr %t118, i32 0, i32 2
  %t121 = load i32, ptr %l1, !tbaa !23
  %t124 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t120, i32 %t121)
  store i32 %t124, ptr %l61
  br label %bb19
bb19:
  %t125 = load i32, ptr %l56, !tbaa !23
  %t126 = load i32, ptr %l61, !tbaa !23
  %t127 = icmp eq i32 %t125, %t126
  store i1 %t127, ptr %l48, !tbaa !21
  br label %bb20
bb20:
  %t129 = load i1, ptr %l48, !tbaa !21
  store i1 %t129, ptr %l19, !tbaa !21
  br label %bb21
bb21:
  %t130 = load i1, ptr %l19, !tbaa !21
  store i1 %t130, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrItemPath(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l6 = alloca ptr
  %l12 = alloca ptr
  %l14 = alloca ptr
  %l19 = alloca %"compiler/names:Ref"
  %l24 = alloca i1
  %l30 = alloca ptr
  %l32 = alloca ptr
  %l36 = alloca i32
  %l46 = alloca ptr
  %l48 = alloca ptr
  %l50 = alloca ptr
  %l52 = alloca %"compiler/source:Span"
  %l54 = alloca { i64, ptr }
  %l58 = alloca i64
  %l59 = alloca i64
  %l64 = alloca %"compiler/ast:Path"
  %l66 = alloca i32
  %l71 = alloca ptr
  %l76 = alloca i32
  %l78 = alloca { i64, ptr }
  %l84 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call ptr @compiler_2fcheck_2eexprPath(ptr %v1, ptr %s0, ptr %a1)
  store ptr %t3, ptr %l6
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l6, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t7 = icmp eq ptr %t5, null
  br i1 %t7, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = getelementptr %"compiler/generic:Program", ptr %t13, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !29
  store ptr %t16, ptr %l12, !tbaa !29
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t17)
  store ptr %t19, ptr %l14
  br label %bb5
bb5:
  %t20 = load ptr, ptr %l14, !tbaa !29
  %t22 = getelementptr %"compiler/check:frame", ptr %t20, i32 0, i32 2
  %t23 = load i64, ptr %t22, !tbaa !24
  %t24 = load ptr, ptr %l2, !tbaa !29
  %t26 = getelementptr %"compiler/ast:Path", ptr %t24, i32 0, i32 0
  %t27 = getelementptr %"compiler/source:Span", ptr %t26, i32 0, i32 0
  %t28 = load i32, ptr %t27, !tbaa !23
  %t29 = load ptr, ptr %l12, !tbaa !29
  %t32 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t29, i64 %t23, i32 %t28)
  store %"compiler/names:Ref" %t32, ptr %l19
  br label %bb6
bb6:
  %t33 = getelementptr %"compiler/names:Ref", ptr %l19, i32 0, i32 0
  %t34 = load i32, ptr %t33, !range !{i32 0, i32 9}
  store i32 %t34, ptr %l3
  %t36 = load i32, ptr %l3, !range !{i32 0, i32 9}
  %t38 = trunc i64 4 to i32
  %t39 = icmp eq i32 %t36, %t38
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb7, label %bb8
bb7:
  %t43 = load i32, ptr %l3, !range !{i32 0, i32 9}
  %t45 = trunc i64 5 to i32
  %t46 = icmp eq i32 %t43, %t45
  %t48 = xor i1 %t46, true
  store i1 %t48, ptr %l24, !tbaa !21
  br label %bb9
bb8:
  store i1 false, ptr %l24, !tbaa !21
  br label %bb9
bb9:
  %t50 = load i1, ptr %l24, !tbaa !21
  br i1 %t50, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/check:Checker", ptr %t52, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !29
  store ptr %t55, ptr %l30, !tbaa !29
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t56)
  store ptr %t58, ptr %l32
  br label %bb13
bb13:
  %t59 = load ptr, ptr %l32, !tbaa !29
  %t61 = getelementptr %"compiler/check:frame", ptr %t59, i32 0, i32 4
  %t62 = load ptr, ptr %l2, !tbaa !29
  %t63 = load ptr, ptr %l30, !tbaa !29
  %t66 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorType(ptr %v0, ptr %v0, ptr %s0, ptr %t63, ptr %t61, ptr %t62)
  store i32 %t66, ptr %l36
  br label %bb14
bb14:
  %t67 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t68 = load i32, ptr %l36, !tbaa !23
  %t70 = icmp ne i32 %t68, %t67
  br i1 %t70, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t73 = load ptr, ptr %l2, !tbaa !29
  %t75 = getelementptr %"compiler/ast:Path", ptr %t73, i32 0, i32 1
  %t76 = load { i64, ptr }, ptr %t75, !tbaa !27
  %t78 = extractvalue { i64, ptr } %t76, 0
  %t80 = icmp slt i64 %t78, 2
  br i1 %t80, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/check:Checker", ptr %t83, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !29
  store ptr %t86, ptr %l46, !tbaa !29
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t87)
  store ptr %t89, ptr %l48
  br label %bb21
bb21:
  %t90 = load ptr, ptr %l48, !tbaa !29
  %t92 = getelementptr %"compiler/check:frame", ptr %t90, i32 0, i32 4
  store ptr %t92, ptr %l50, !tbaa !29
  %t93 = load ptr, ptr %l2, !tbaa !29
  %t95 = getelementptr %"compiler/ast:Path", ptr %t93, i32 0, i32 0
  %t96 = load %"compiler/source:Span", ptr %t95
  store %"compiler/source:Span" %t96, ptr %l52
  %t97 = load ptr, ptr %l2, !tbaa !29
  %t99 = getelementptr %"compiler/ast:Path", ptr %t97, i32 0, i32 1
  %t100 = load { i64, ptr }, ptr %t99, !tbaa !27
  store { i64, ptr } %t100, ptr %l54, !tbaa !27
  %t101 = load ptr, ptr %l2, !tbaa !29
  %t103 = getelementptr %"compiler/ast:Path", ptr %t101, i32 0, i32 1
  %t104 = load { i64, ptr }, ptr %t103, !tbaa !27
  %t106 = extractvalue { i64, ptr } %t104, 0
  %t108 = sub i64 %t106, 1
  store i64 %t108, ptr %l58, !tbaa !24
  %t109 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t110 = extractvalue { i64, ptr } %t109, 0
  store i64 %t110, ptr %l59, !tbaa !24
  %t111 = icmp sge i64 0, 0
  br i1 %t111, label %bb22, label %bb23
bb22:
  %t113 = load i64, ptr %l58, !tbaa !24
  %t114 = icmp sle i64 0, %t113
  br i1 %t114, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_21bd7d1c01cb29ff_7bd6b7239395673b)
  unreachable
bb24:
  %t116 = load i64, ptr %l58, !tbaa !24
  %t117 = load i64, ptr %l59, !tbaa !24
  %t118 = icmp sle i64 %t116, %t117
  br i1 %t118, label %bb26, label %bb27
bb25:
  call void @__olang_check_failed(ptr @olang_loc_21bd7d1c01cb29ff_7bd6b7239395673b)
  unreachable
bb26:
  %t120 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t121 = load ptr, ptr %t120, !tbaa !27
  %t122 = load i64, ptr %l58, !tbaa !24
  %t123 = getelementptr i32, ptr %t121, i64 0
  %t124 = sub i64 %t122, 0
  %t125 = insertvalue { i64, ptr } undef, i64 %t124, 0
  %t126 = insertvalue { i64, ptr } %t125, ptr %t123, 1
  %t127 = load %"compiler/source:Span", ptr %l52
  %t129 = call %"compiler/ast:Path" @compiler_2fast_3aPath_2ector(ptr %s0, ptr %s0, %"compiler/source:Span" %t127, { i64, ptr } %t126)
  store %"compiler/ast:Path" %t129, ptr %l64
  br label %bb28
bb27:
  call void @__olang_check_failed(ptr @olang_loc_21bd7d1c01cb29ff_7bd6b7239395673b)
  unreachable
bb28:
  %t130 = load %"compiler/ast:Path", ptr %l64
  %t131 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 24, i64 8)
  store %"compiler/ast:Path" %t130, ptr %t131
  %t132 = load ptr, ptr %l46, !tbaa !29
  %t133 = load ptr, ptr %l50, !tbaa !29
  %t135 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorType(ptr %v0, ptr %v0, ptr %s0, ptr %t132, ptr %t133, ptr %t131)
  store i32 %t135, ptr %l66
  br label %bb29
bb29:
  %t136 = load i32, ptr %l66, !tbaa !23
  store i32 %t136, ptr %l4, !tbaa !23
  %t137 = load i32, ptr %l4, !tbaa !23
  %t138 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t141 = icmp eq i32 %t137, %t138
  br i1 %t141, label %bb30, label %bb31
bb30:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb31:
  br label %bb32
bb32:
  %t144 = load ptr, ptr %l0, !tbaa !29
  store ptr %t144, ptr %l71, !tbaa !29
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t147 = getelementptr %"compiler/check:Checker", ptr %t145, i32 0, i32 1
  %t148 = load ptr, ptr %t147, !tbaa !29
  %t150 = getelementptr %"compiler/generic:Program", ptr %t148, i32 0, i32 2
  %t151 = load i32, ptr %l4, !tbaa !23
  %t154 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t150, i32 %t151)
  store i32 %t154, ptr %l76
  br label %bb33
bb33:
  %t155 = load ptr, ptr %l2, !tbaa !29
  %t157 = getelementptr %"compiler/ast:Path", ptr %t155, i32 0, i32 1
  %t158 = load { i64, ptr }, ptr %t157, !tbaa !27
  store { i64, ptr } %t158, ptr %l78, !tbaa !27
  %t159 = load ptr, ptr %l2, !tbaa !29
  %t161 = getelementptr %"compiler/ast:Path", ptr %t159, i32 0, i32 1
  %t162 = load { i64, ptr }, ptr %t161, !tbaa !27
  %t164 = extractvalue { i64, ptr } %t162, 0
  %t166 = sub i64 %t164, 1
  %t168 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t169 = load ptr, ptr %t168, !tbaa !27
  %t170 = getelementptr i32, ptr %t169, i64 %t166
  %t171 = load i32, ptr %t170, !tbaa !33
  %t172 = load ptr, ptr %l71, !tbaa !29
  %t173 = load i32, ptr %l76, !tbaa !23
  %t175 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewordIndex(ptr %v0, ptr %t172, i32 %t173, i32 %t171)
  store i64 %t175, ptr %l84
  br label %bb34
bb34:
  %t176 = load i64, ptr %l84, !tbaa !24
  %t177 = icmp sge i64 %t176, 0
  call void @__olang_scope_close(ptr %s0)
  store i1 %t177, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexternRules(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca i1
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i32
  %l15 = alloca %"compiler/source:Span"
  %l16 = alloca i32
  %l20 = alloca ptr
  %l24 = alloca i64
  %l28 = alloca i32
  %l31 = alloca ptr
  %l36 = alloca i32
  %l37 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l42 = alloca i1
  %l48 = alloca ptr
  %l58 = alloca i64
  %l61 = alloca i64
  %l83 = alloca { i64, ptr }
  %l89 = alloca i1
  %l92 = alloca i1
  %l95 = alloca i1
  %l98 = alloca i1
  %l100 = alloca i1
  %l105 = alloca i32
  %l108 = alloca i1
  %l111 = alloca ptr
  %l116 = alloca i32
  %l117 = alloca { i64, ptr }
  %l120 = alloca i1
  %l125 = alloca i32
  %l128 = alloca i1
  %l131 = alloca ptr
  %l136 = alloca i32
  %l137 = alloca { i64, ptr }
  %l142 = alloca { i64, ptr }
  %l149 = alloca ptr
  %l150 = alloca i64
  %l152 = alloca i64
  %l154 = alloca i64
  %l158 = alloca { i64, ptr }
  %l162 = alloca { i64, ptr }
  %l165 = alloca { i64, [3 x i64] }
  %l168 = alloca { i64, ptr }
  %l170 = alloca %"compiler/msgs:Msg"
  %l171 = alloca i64
  %l178 = alloca i32
  %l182 = alloca i1
  %l186 = alloca i1
  %l190 = alloca i1
  %l201 = alloca i1
  %l204 = alloca i1
  %l209 = alloca ptr
  %l210 = alloca i64
  %l213 = alloca { i64, ptr }
  %l215 = alloca %"compiler/source:Span"
  %l217 = alloca i64
  %l220 = alloca { i64, ptr }
  %l227 = alloca %"compiler/source:Span"
  %l230 = alloca { i64, [3 x i64] }
  %l233 = alloca { i64, ptr }
  %l235 = alloca %"compiler/msgs:Msg"
  %l236 = alloca i64
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %t318 = alloca { i64, [3 x i64] }, align 8
  %t472 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i64, ptr %l1, !tbaa !24
  %t8 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t4, i64 %t5)
  store ptr %t8, ptr %l20
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l20, !tbaa !29
  store ptr %t9, ptr %l2, !tbaa !29
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t14 = load i64, ptr %l1, !tbaa !24
  %t17 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t13, i64 %t14)
  store i64 %t17, ptr %l24
  br label %bb2
bb2:
  %t18 = load i64, ptr %l24, !tbaa !24
  store i64 %t18, ptr %l3, !tbaa !24
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/check:Checker", ptr %t19, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t23 = load i64, ptr %l1, !tbaa !24
  %t26 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t22, i64 %t23)
  store i32 %t26, ptr %l28
  br label %bb3
bb3:
  %t27 = load i32, ptr %l28, !tbaa !23
  store i32 %t27, ptr %l4, !tbaa !23
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/check:Checker", ptr %t28, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t33 = getelementptr %"compiler/generic:Program", ptr %t31, i32 0, i32 2
  store ptr %t33, ptr %l31, !tbaa !29
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/check:Checker", ptr %t34, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t39 = getelementptr %"compiler/generic:Program", ptr %t37, i32 0, i32 2
  %t40 = load i32, ptr %l4, !tbaa !23
  %t43 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t39, i32 %t40)
  store i32 %t43, ptr %l36
  br label %bb4
bb4:
  %t44 = load ptr, ptr %l31, !tbaa !29
  %t45 = load i32, ptr %l36, !tbaa !23
  %t46 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t44, i32 %t45)
  store { i64, ptr } %t46, ptr %l37
  br label %bb5
bb5:
  %t47 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t47, ptr %l5, !tbaa !27
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = load ptr, ptr %l2, !tbaa !29
  %t51 = getelementptr %"compiler/ast:Func", ptr %t49, i32 0, i32 2
  %t52 = load i32, ptr %t51, !tbaa !23
  %t55 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t48, i32 %t52)
  store { i64, ptr } %t55, ptr %l41
  br label %bb6
bb6:
  %t56 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t57 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t56, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d27, i32 0, i32 1) })
  store i1 %t57, ptr %l42
  br label %bb7
bb7:
  %t58 = load i1, ptr %l42, !tbaa !21
  store i1 %t58, ptr %l6, !tbaa !21
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/check:Checker", ptr %t59, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = getelementptr %"compiler/generic:Program", ptr %t62, i32 0, i32 0
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t67 = getelementptr %"compiler/load:Loader", ptr %t65, i32 0, i32 10
  %t68 = load i64, ptr %l3, !tbaa !24
  %t71 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t67, i64 %t68)
  store ptr %t71, ptr %l48
  br label %bb8
bb8:
  %t72 = load ptr, ptr %l48, !tbaa !29
  %t74 = getelementptr %"compiler/load:Module", ptr %t72, i32 0, i32 4
  %t75 = load i64, ptr %t74, !tbaa !24
  store i64 %t75, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  %t77 = load ptr, ptr %l2, !tbaa !29
  %t79 = getelementptr %"compiler/ast:Func", ptr %t77, i32 0, i32 3
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t82 = getelementptr %"compiler/ast:Sig", ptr %t80, i32 0, i32 0
  %t83 = load { i64, ptr }, ptr %t82, !tbaa !27
  %t85 = extractvalue { i64, ptr } %t83, 0
  store i64 %t85, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t87 = load i64, ptr %l9, !tbaa !24
  %t88 = load i64, ptr %l8, !tbaa !24
  %t91 = icmp sgt i64 %t87, %t88
  br i1 %t91, label %bb9, label %bb10
bb9:
  %t93 = load i64, ptr %l10, !tbaa !24
  %t95 = icmp sgt i64 %t93, 0
  br i1 %t95, label %bb11, label %bb12
bb10:
  store i64 0, ptr %l58, !tbaa !24
  br label %bb14
bb11:
  %t97 = load i64, ptr %l9, !tbaa !24
  %t98 = load i64, ptr %l8, !tbaa !24
  %t101 = sub i64 %t97, %t98
  %t102 = load i64, ptr %l10, !tbaa !24
  %t105 = add i64 %t101, %t102
  %t107 = sub i64 %t105, 1
  %t108 = load i64, ptr %l10, !tbaa !24
  %t111 = sdiv i64 %t107, %t108
  store i64 %t111, ptr %l61, !tbaa !24
  br label %bb13
bb12:
  store i64 0, ptr %l61, !tbaa !24
  br label %bb13
bb13:
  %t113 = load i64, ptr %l61, !tbaa !24
  store i64 %t113, ptr %l58, !tbaa !24
  br label %bb14
bb14:
  %t114 = load i64, ptr %l58, !tbaa !24
  store i64 %t114, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s2
  %t115 = load i64, ptr %l12, !tbaa !24
  %t116 = load i64, ptr %l11, !tbaa !24
  %t119 = icmp slt i64 %t115, %t116
  %t121 = xor i1 %t119, true
  br i1 %t121, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s2)
  br label %bb62
bb17:
  br label %bb18
bb18:
  %t123 = load i64, ptr %l8, !tbaa !24
  %t124 = load i64, ptr %l12, !tbaa !24
  %t125 = load i64, ptr %l10, !tbaa !24
  %t128 = mul i64 %t124, %t125
  %t131 = add i64 %t123, %t128
  store i64 %t131, ptr %l13, !tbaa !24
  %t133 = load i64, ptr %l13, !tbaa !24
  %t134 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t136 = extractvalue { i64, ptr } %t134, 0
  %t139 = icmp sge i64 %t133, %t136
  br i1 %t139, label %bb19, label %bb20
bb19:
  call void @__olang_scope_close(ptr %s2)
  br label %bb62
bb20:
  br label %bb21
bb21:
  %t141 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t141, ptr %l83, !tbaa !27
  %t142 = load i64, ptr %l13, !tbaa !24
  %t144 = getelementptr { i64, ptr }, ptr %l83, i32 0, i32 1
  %t145 = load ptr, ptr %t144, !tbaa !27
  %t146 = getelementptr i32, ptr %t145, i64 %t142
  %t147 = load i32, ptr %t146, !tbaa !33
  store i32 %t147, ptr %l14, !tbaa !23
  %t149 = load i32, ptr %l14, !tbaa !23
  %t150 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t153 = icmp eq i32 %t149, %t150
  br i1 %t153, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l89, !tbaa !21
  br label %bb25
bb23:
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t156 = load i32, ptr %l14, !tbaa !23
  %t159 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexternParam(ptr %v0, ptr %t155, i32 %t156)
  store i1 %t159, ptr %l92
  br label %bb24
bb24:
  %t160 = load i1, ptr %l92, !tbaa !21
  store i1 %t160, ptr %l89, !tbaa !21
  br label %bb25
bb25:
  %t161 = load i1, ptr %l89, !tbaa !21
  br i1 %t161, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s2)
  br label %bb61
bb27:
  br label %bb28
bb28:
  %t162 = load i1, ptr %l6, !tbaa !21
  %t164 = xor i1 %t162, true
  br i1 %t164, label %bb29, label %bb30
bb29:
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t167 = load i32, ptr %l14, !tbaa !23
  %t170 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallbackType(ptr %v0, ptr %t166, i32 %t167)
  store i1 %t170, ptr %l98
  br label %bb31
bb30:
  store i1 false, ptr %l95, !tbaa !21
  br label %bb32
bb31:
  %t171 = load i1, ptr %l98, !tbaa !21
  store i1 %t171, ptr %l95, !tbaa !21
  br label %bb32
bb32:
  %t172 = load i1, ptr %l95, !tbaa !21
  br i1 %t172, label %bb33, label %bb34
bb33:
  call void @__olang_scope_close(ptr %s2)
  br label %bb61
bb34:
  br label %bb35
bb35:
  %t173 = load i1, ptr %l6, !tbaa !21
  br i1 %t173, label %bb36, label %bb37
bb36:
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t177 = getelementptr %"compiler/check:Checker", ptr %t175, i32 0, i32 1
  %t178 = load ptr, ptr %t177, !tbaa !29
  %t180 = getelementptr %"compiler/generic:Program", ptr %t178, i32 0, i32 2
  %t181 = load i32, ptr %l14, !tbaa !23
  %t184 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t180, i32 %t181)
  store i32 %t184, ptr %l105
  br label %bb38
bb37:
  store i1 false, ptr %l100, !tbaa !21
  br label %bb39
bb38:
  %t185 = load i32, ptr %l105, !range !{i32 0, i32 33}
  %t187 = trunc i64 21 to i32
  %t188 = icmp eq i32 %t185, %t187
  store i1 %t188, ptr %l100, !tbaa !21
  br label %bb39
bb39:
  %t190 = load i1, ptr %l100, !tbaa !21
  br i1 %t190, label %bb40, label %bb41
bb40:
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t193 = getelementptr %"compiler/check:Checker", ptr %t191, i32 0, i32 1
  %t194 = load ptr, ptr %t193, !tbaa !29
  %t196 = getelementptr %"compiler/generic:Program", ptr %t194, i32 0, i32 2
  store ptr %t196, ptr %l111, !tbaa !29
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t199 = getelementptr %"compiler/check:Checker", ptr %t197, i32 0, i32 1
  %t200 = load ptr, ptr %t199, !tbaa !29
  %t202 = getelementptr %"compiler/generic:Program", ptr %t200, i32 0, i32 2
  %t203 = load i32, ptr %l14, !tbaa !23
  %t206 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t202, i32 %t203)
  store i32 %t206, ptr %l116
  br label %bb42
bb41:
  store i1 false, ptr %l108, !tbaa !21
  br label %bb44
bb42:
  %t207 = load ptr, ptr %l111, !tbaa !29
  %t208 = load i32, ptr %l116, !tbaa !23
  %t209 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s2, ptr %t207, i32 %t208)
  store { i64, ptr } %t209, ptr %l117
  br label %bb43
bb43:
  %t210 = load { i64, ptr }, ptr %l117, !tbaa !27
  %t211 = extractvalue { i64, ptr } %t210, 0
  %t213 = icmp eq i64 %t211, 0
  store i1 %t213, ptr %l108, !tbaa !21
  br label %bb44
bb44:
  %t215 = load i1, ptr %l108, !tbaa !21
  br i1 %t215, label %bb45, label %bb46
bb45:
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t218 = getelementptr %"compiler/check:Checker", ptr %t216, i32 0, i32 1
  %t219 = load ptr, ptr %t218, !tbaa !29
  %t221 = getelementptr %"compiler/generic:Program", ptr %t219, i32 0, i32 2
  %t222 = load i32, ptr %l14, !tbaa !23
  %t225 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t221, i32 %t222)
  store i32 %t225, ptr %l125
  br label %bb47
bb46:
  store i1 false, ptr %l120, !tbaa !21
  br label %bb48
bb47:
  %t226 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t227 = load i32, ptr %l125, !tbaa !23
  %t229 = icmp eq i32 %t227, %t226
  store i1 %t229, ptr %l120, !tbaa !21
  br label %bb48
bb48:
  %t231 = load i1, ptr %l120, !tbaa !21
  br i1 %t231, label %bb49, label %bb50
bb49:
  %t232 = load ptr, ptr %l0, !tbaa !29
  %t234 = getelementptr %"compiler/check:Checker", ptr %t232, i32 0, i32 1
  %t235 = load ptr, ptr %t234, !tbaa !29
  %t237 = getelementptr %"compiler/generic:Program", ptr %t235, i32 0, i32 2
  store ptr %t237, ptr %l131, !tbaa !29
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t240 = getelementptr %"compiler/check:Checker", ptr %t238, i32 0, i32 1
  %t241 = load ptr, ptr %t240, !tbaa !29
  %t243 = getelementptr %"compiler/generic:Program", ptr %t241, i32 0, i32 2
  %t244 = load i32, ptr %l14, !tbaa !23
  %t247 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t243, i32 %t244)
  store i32 %t247, ptr %l136
  br label %bb51
bb50:
  store i1 false, ptr %l128, !tbaa !21
  br label %bb53
bb51:
  %t248 = load ptr, ptr %l131, !tbaa !29
  %t249 = load i32, ptr %l136, !tbaa !23
  %t250 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s2, ptr %t248, i32 %t249)
  store { i64, ptr } %t250, ptr %l137
  br label %bb52
bb52:
  %t251 = load { i64, ptr }, ptr %l137, !tbaa !27
  %t252 = extractvalue { i64, ptr } %t251, 0
  %t254 = icmp eq i64 %t252, 0
  store i1 %t254, ptr %l128, !tbaa !21
  br label %bb53
bb53:
  %t256 = load i1, ptr %l128, !tbaa !21
  br i1 %t256, label %bb54, label %bb55
bb54:
  call void @__olang_scope_close(ptr %s2)
  br label %bb61
bb55:
  br label %bb56
bb56:
  %t257 = load ptr, ptr %l2, !tbaa !29
  %t259 = getelementptr %"compiler/ast:Func", ptr %t257, i32 0, i32 3
  %t260 = load ptr, ptr %t259, !tbaa !29
  %t262 = getelementptr %"compiler/ast:Sig", ptr %t260, i32 0, i32 0
  %t263 = load { i64, ptr }, ptr %t262, !tbaa !27
  store { i64, ptr } %t263, ptr %l142, !tbaa !27
  %t264 = load i64, ptr %l13, !tbaa !24
  %t266 = getelementptr { i64, ptr }, ptr %l142, i32 0, i32 1
  %t267 = load ptr, ptr %t266, !tbaa !27
  %t268 = getelementptr ptr, ptr %t267, i64 %t264
  %t269 = load ptr, ptr %t268, !tbaa !39
  %t271 = getelementptr %"compiler/ast:Param", ptr %t269, i32 0, i32 0
  %t272 = load %"compiler/source:Span", ptr %t271
  store %"compiler/source:Span" %t272, ptr %l15
  %t274 = load ptr, ptr %l0, !tbaa !29
  %t276 = getelementptr %"compiler/check:Checker", ptr %t274, i32 0, i32 1
  %t277 = load ptr, ptr %t276, !tbaa !29
  %t279 = getelementptr %"compiler/generic:Program", ptr %t277, i32 0, i32 0
  %t280 = load ptr, ptr %t279, !tbaa !29
  %t282 = getelementptr %"compiler/load:Loader", ptr %t280, i32 0, i32 4
  %t283 = load ptr, ptr %t282, !tbaa !29
  store ptr %t283, ptr %l149, !tbaa !29
  %t284 = load i64, ptr %l7, !tbaa !24
  store i64 %t284, ptr %l150, !tbaa !24
  %t285 = getelementptr %"compiler/source:Span", ptr %l15, i32 0, i32 0
  %t286 = load i32, ptr %t285, !tbaa !23
  %t288 = sext i32 %t286 to i64
  store i64 %t288, ptr %l152, !tbaa !24
  %t289 = getelementptr %"compiler/source:Span", ptr %l15, i32 0, i32 0
  %t290 = load i32, ptr %t289, !tbaa !23
  %t292 = sext i32 %t290 to i64
  store i64 %t292, ptr %l154, !tbaa !24
  %t293 = load ptr, ptr %l0, !tbaa !29
  %t294 = load ptr, ptr %l2, !tbaa !29
  %t296 = getelementptr %"compiler/ast:Func", ptr %t294, i32 0, i32 3
  %t297 = load ptr, ptr %t296, !tbaa !29
  %t299 = getelementptr %"compiler/ast:Sig", ptr %t297, i32 0, i32 0
  %t300 = load { i64, ptr }, ptr %t299, !tbaa !27
  store { i64, ptr } %t300, ptr %l158, !tbaa !27
  %t301 = load i64, ptr %l13, !tbaa !24
  %t303 = getelementptr { i64, ptr }, ptr %l158, i32 0, i32 1
  %t304 = load ptr, ptr %t303, !tbaa !27
  %t305 = getelementptr ptr, ptr %t304, i64 %t301
  %t306 = load ptr, ptr %t305, !tbaa !39
  %t308 = getelementptr %"compiler/ast:Param", ptr %t306, i32 0, i32 1
  %t309 = load i32, ptr %t308, !tbaa !23
  %t312 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %s2, ptr %t293, i32 %t309)
  store { i64, ptr } %t312, ptr %l162
  br label %bb57
bb57:
  %t313 = load { i64, ptr }, ptr %l162, !tbaa !27
  %t314 = extractvalue { i64, ptr } %t313, 0
  %t315 = load i64, ptr %l154, !tbaa !24
  %t317 = add i64 %t315, %t314
  store { i64, [3 x i64] } zeroinitializer, ptr %t318
  %t319 = getelementptr { i64, [3 x i64] }, ptr %t318, i32 0, i32 0
  store i64 3, ptr %t319
  %t320 = load i64, ptr %l150, !tbaa !24
  %t321 = insertvalue { i64, i64, i64 } undef, i64 %t320, 0
  %t322 = load i64, ptr %l152, !tbaa !24
  %t323 = insertvalue { i64, i64, i64 } %t321, i64 %t322, 1
  %t325 = insertvalue { i64, i64, i64 } %t323, i64 %t317, 2
  %t326 = getelementptr { i64, [3 x i64] }, ptr %t318, i32 0, i32 1
  store { i64, i64, i64 } %t325, ptr %t326
  %t327 = load { i64, [3 x i64] }, ptr %t318
  store { i64, [3 x i64] } %t327, ptr %l165
  %t328 = load ptr, ptr %l0, !tbaa !29
  %t329 = load i32, ptr %l14, !tbaa !23
  %t332 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s2, ptr %t328, i32 %t329)
  store { i64, ptr } %t332, ptr %l168
  br label %bb58
bb58:
  %t333 = load { i64, ptr }, ptr %l168, !tbaa !27
  %t334 = extractvalue { i64, ptr } %t333, 0
  %t335 = extractvalue { i64, ptr } %t333, 1
  %t336 = mul i64 %t334, 1
  %t337 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t336)
  call void @llvm.memcpy.p0.p0.i64(ptr %t337, ptr %t335, i64 %t336, i1 false)
  %t338 = insertvalue { i64, ptr } undef, i64 %t334, 0
  %t339 = insertvalue { i64, ptr } %t338, ptr %t337, 1
  %t341 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eExternType(ptr %s2, ptr %s2, { i64, ptr } %t339)
  store %"compiler/msgs:Msg" %t341, ptr %l170
  br label %bb59
bb59:
  %t342 = load ptr, ptr %l149, !tbaa !29
  %t343 = load { i64, [3 x i64] }, ptr %l165
  %t344 = load %"compiler/msgs:Msg", ptr %l170
  %t345 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s2, ptr %t342, { i64, [3 x i64] } %t343, %"compiler/msgs:Msg" %t344)
  store i64 %t345, ptr %l171
  br label %bb60
bb60:
  call void @__olang_scope_close(ptr %s2)
  br label %bb61
bb61:
  %t346 = load i64, ptr %l12, !tbaa !24
  %t348 = add i64 %t346, 1
  store i64 %t348, ptr %l12, !tbaa !24
  br label %bb15
bb62:
  %t350 = load ptr, ptr %l0, !tbaa !29
  %t352 = getelementptr %"compiler/check:Checker", ptr %t350, i32 0, i32 1
  %t353 = load ptr, ptr %t352, !tbaa !29
  %t355 = getelementptr %"compiler/generic:Program", ptr %t353, i32 0, i32 2
  %t356 = load i32, ptr %l4, !tbaa !23
  %t359 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t355, i32 %t356)
  store i32 %t359, ptr %l178
  br label %bb63
bb63:
  %t360 = load i32, ptr %l178, !tbaa !23
  store i32 %t360, ptr %l16, !tbaa !23
  %t361 = load i32, ptr %l16, !tbaa !23
  %t362 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t365 = icmp eq i32 %t361, %t362
  br i1 %t365, label %bb64, label %bb65
bb64:
  store i1 true, ptr %l182, !tbaa !21
  br label %bb66
bb65:
  %t367 = load i32, ptr %l16, !tbaa !23
  %t368 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t371 = icmp eq i32 %t367, %t368
  store i1 %t371, ptr %l182, !tbaa !21
  br label %bb66
bb66:
  %t373 = load i1, ptr %l182, !tbaa !21
  br i1 %t373, label %bb67, label %bb68
bb67:
  store i1 true, ptr %l186, !tbaa !21
  br label %bb69
bb68:
  %t374 = load i32, ptr %l16, !tbaa !23
  %t375 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t378 = icmp eq i32 %t374, %t375
  store i1 %t378, ptr %l186, !tbaa !21
  br label %bb69
bb69:
  %t380 = load i1, ptr %l186, !tbaa !21
  br i1 %t380, label %bb70, label %bb71
bb70:
  store i1 true, ptr %l190, !tbaa !21
  br label %bb72
bb71:
  %t381 = load ptr, ptr %l2, !tbaa !29
  %t383 = getelementptr %"compiler/ast:Func", ptr %t381, i32 0, i32 3
  %t384 = load ptr, ptr %t383, !tbaa !29
  %t386 = getelementptr %"compiler/ast:Sig", ptr %t384, i32 0, i32 1
  %t387 = load { i64, ptr }, ptr %t386, !tbaa !27
  %t389 = extractvalue { i64, ptr } %t387, 0
  %t391 = icmp eq i64 %t389, 0
  store i1 %t391, ptr %l190, !tbaa !21
  br label %bb72
bb72:
  %t393 = load i1, ptr %l190, !tbaa !21
  br i1 %t393, label %bb73, label %bb74
bb73:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb74:
  br label %bb75
bb75:
  %t394 = load ptr, ptr %l2, !tbaa !29
  %t396 = getelementptr %"compiler/ast:Func", ptr %t394, i32 0, i32 3
  %t397 = load ptr, ptr %t396, !tbaa !29
  %t399 = getelementptr %"compiler/ast:Sig", ptr %t397, i32 0, i32 1
  %t400 = load { i64, ptr }, ptr %t399, !tbaa !27
  %t402 = extractvalue { i64, ptr } %t400, 0
  %t404 = icmp sgt i64 %t402, 1
  br i1 %t404, label %bb76, label %bb77
bb76:
  store i1 true, ptr %l201, !tbaa !21
  br label %bb79
bb77:
  %t406 = load ptr, ptr %l0, !tbaa !29
  %t407 = load i32, ptr %l16, !tbaa !23
  %t410 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexternValue(ptr %v0, ptr %t406, i32 %t407)
  store i1 %t410, ptr %l204
  br label %bb78
bb78:
  %t411 = load i1, ptr %l204, !tbaa !21
  %t412 = xor i1 %t411, true
  store i1 %t412, ptr %l201, !tbaa !21
  br label %bb79
bb79:
  %t414 = load i1, ptr %l201, !tbaa !21
  br i1 %t414, label %bb80, label %bb81
bb80:
  store %olang.scope zeroinitializer, ptr %s9
  %t415 = load ptr, ptr %l0, !tbaa !29
  %t417 = getelementptr %"compiler/check:Checker", ptr %t415, i32 0, i32 1
  %t418 = load ptr, ptr %t417, !tbaa !29
  %t420 = getelementptr %"compiler/generic:Program", ptr %t418, i32 0, i32 0
  %t421 = load ptr, ptr %t420, !tbaa !29
  %t423 = getelementptr %"compiler/load:Loader", ptr %t421, i32 0, i32 4
  %t424 = load ptr, ptr %t423, !tbaa !29
  store ptr %t424, ptr %l209, !tbaa !29
  %t425 = load i64, ptr %l7, !tbaa !24
  store i64 %t425, ptr %l210, !tbaa !24
  %t426 = load ptr, ptr %l2, !tbaa !29
  %t428 = getelementptr %"compiler/ast:Func", ptr %t426, i32 0, i32 3
  %t429 = load ptr, ptr %t428, !tbaa !29
  %t431 = getelementptr %"compiler/ast:Sig", ptr %t429, i32 0, i32 1
  %t432 = load { i64, ptr }, ptr %t431, !tbaa !27
  store { i64, ptr } %t432, ptr %l213, !tbaa !27
  %t433 = getelementptr { i64, ptr }, ptr %l213, i32 0, i32 1
  %t434 = load ptr, ptr %t433, !tbaa !27
  %t435 = getelementptr ptr, ptr %t434, i64 0
  %t436 = load ptr, ptr %t435, !tbaa !39
  %t438 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v0, ptr %t436)
  store %"compiler/source:Span" %t438, ptr %l215
  br label %bb82
bb81:
  br label %bb87
bb82:
  %t439 = getelementptr %"compiler/source:Span", ptr %l215, i32 0, i32 0
  %t440 = load i32, ptr %t439, !tbaa !23
  %t442 = sext i32 %t440 to i64
  store i64 %t442, ptr %l217, !tbaa !24
  %t443 = load ptr, ptr %l2, !tbaa !29
  %t445 = getelementptr %"compiler/ast:Func", ptr %t443, i32 0, i32 3
  %t446 = load ptr, ptr %t445, !tbaa !29
  %t448 = getelementptr %"compiler/ast:Sig", ptr %t446, i32 0, i32 1
  %t449 = load { i64, ptr }, ptr %t448, !tbaa !27
  store { i64, ptr } %t449, ptr %l220, !tbaa !27
  %t450 = load ptr, ptr %l2, !tbaa !29
  %t452 = getelementptr %"compiler/ast:Func", ptr %t450, i32 0, i32 3
  %t453 = load ptr, ptr %t452, !tbaa !29
  %t455 = getelementptr %"compiler/ast:Sig", ptr %t453, i32 0, i32 1
  %t456 = load { i64, ptr }, ptr %t455, !tbaa !27
  %t458 = extractvalue { i64, ptr } %t456, 0
  %t460 = sub i64 %t458, 1
  %t462 = getelementptr { i64, ptr }, ptr %l220, i32 0, i32 1
  %t463 = load ptr, ptr %t462, !tbaa !27
  %t464 = getelementptr ptr, ptr %t463, i64 %t460
  %t465 = load ptr, ptr %t464, !tbaa !39
  %t467 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v0, ptr %t465)
  store %"compiler/source:Span" %t467, ptr %l227
  br label %bb83
bb83:
  %t468 = getelementptr %"compiler/source:Span", ptr %l227, i32 0, i32 1
  %t469 = load i32, ptr %t468, !tbaa !23
  %t471 = sext i32 %t469 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t472
  %t473 = getelementptr { i64, [3 x i64] }, ptr %t472, i32 0, i32 0
  store i64 3, ptr %t473
  %t474 = load i64, ptr %l210, !tbaa !24
  %t475 = insertvalue { i64, i64, i64 } undef, i64 %t474, 0
  %t476 = load i64, ptr %l217, !tbaa !24
  %t477 = insertvalue { i64, i64, i64 } %t475, i64 %t476, 1
  %t479 = insertvalue { i64, i64, i64 } %t477, i64 %t471, 2
  %t480 = getelementptr { i64, [3 x i64] }, ptr %t472, i32 0, i32 1
  store { i64, i64, i64 } %t479, ptr %t480
  %t481 = load { i64, [3 x i64] }, ptr %t472
  store { i64, [3 x i64] } %t481, ptr %l230
  %t482 = load ptr, ptr %l0, !tbaa !29
  %t483 = load i32, ptr %l16, !tbaa !23
  %t486 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s9, ptr %t482, i32 %t483)
  store { i64, ptr } %t486, ptr %l233
  br label %bb84
bb84:
  %t487 = load { i64, ptr }, ptr %l233, !tbaa !27
  %t488 = extractvalue { i64, ptr } %t487, 0
  %t489 = extractvalue { i64, ptr } %t487, 1
  %t490 = mul i64 %t488, 1
  %t491 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t490)
  call void @llvm.memcpy.p0.p0.i64(ptr %t491, ptr %t489, i64 %t490, i1 false)
  %t492 = insertvalue { i64, ptr } undef, i64 %t488, 0
  %t493 = insertvalue { i64, ptr } %t492, ptr %t491, 1
  %t495 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eExternResult(ptr %s9, ptr %s9, { i64, ptr } %t493)
  store %"compiler/msgs:Msg" %t495, ptr %l235
  br label %bb85
bb85:
  %t496 = load ptr, ptr %l209, !tbaa !29
  %t497 = load { i64, [3 x i64] }, ptr %l230
  %t498 = load %"compiler/msgs:Msg", ptr %l235
  %t499 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s9, ptr %t496, { i64, [3 x i64] } %t497, %"compiler/msgs:Msg" %t498)
  store i64 %t499, ptr %l236
  br label %bb86
bb86:
  call void @__olang_scope_close(ptr %s9)
  br label %bb87
bb87:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efailForms(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l13 = alloca i64
  %l17 = alloca i64
  %l20 = alloca i64
  %l41 = alloca ptr
  %l45 = alloca i1
  %l49 = alloca i1
  %l50 = alloca i1
  %l52 = alloca ptr
  %l54 = alloca i64
  %l55 = alloca i64
  %l59 = alloca i1
  %l63 = alloca i64
  %l72 = alloca { i64, ptr }
  %l78 = alloca { i64, ptr }
  %l80 = alloca i64
  %l83 = alloca i1
  %l89 = alloca i32
  %l92 = alloca i1
  %l93 = alloca i1
  %l96 = alloca ptr
  %l99 = alloca i32
  %l100 = alloca { i64, ptr }
  %l103 = alloca ptr
  %l107 = alloca i64
  %l109 = alloca ptr
  %l110 = alloca ptr
  %l113 = alloca %"compiler/source:Span"
  %l116 = alloca { i64, ptr }
  %l118 = alloca %"compiler/msgs:Msg"
  %l119 = alloca i64
  %s2 = alloca %olang.scope
  %s7 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnCount(ptr %v0, ptr %t4)
  store i64 %t6, ptr %l13
  br label %bb1
bb1:
  %t7 = load i64, ptr %l13, !tbaa !24
  store i64 %t7, ptr %l2, !tbaa !24
  store i64 1, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l2, !tbaa !24
  %t9 = load i64, ptr %l1, !tbaa !24
  %t12 = icmp sgt i64 %t8, %t9
  br i1 %t12, label %bb2, label %bb3
bb2:
  %t14 = load i64, ptr %l3, !tbaa !24
  %t16 = icmp sgt i64 %t14, 0
  br i1 %t16, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb7
bb4:
  %t18 = load i64, ptr %l2, !tbaa !24
  %t19 = load i64, ptr %l1, !tbaa !24
  %t22 = sub i64 %t18, %t19
  %t23 = load i64, ptr %l3, !tbaa !24
  %t26 = add i64 %t22, %t23
  %t28 = sub i64 %t26, 1
  %t29 = load i64, ptr %l3, !tbaa !24
  %t32 = sdiv i64 %t28, %t29
  store i64 %t32, ptr %l20, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l20, !tbaa !24
  br label %bb6
bb6:
  %t34 = load i64, ptr %l20, !tbaa !24
  store i64 %t34, ptr %l17, !tbaa !24
  br label %bb7
bb7:
  %t35 = load i64, ptr %l17, !tbaa !24
  store i64 %t35, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t36 = load i64, ptr %l5, !tbaa !24
  %t37 = load i64, ptr %l4, !tbaa !24
  %t40 = icmp slt i64 %t36, %t37
  %t42 = xor i1 %t40, true
  br i1 %t42, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb62
bb10:
  br label %bb11
bb11:
  %t44 = load i64, ptr %l1, !tbaa !24
  %t45 = load i64, ptr %l5, !tbaa !24
  %t46 = load i64, ptr %l3, !tbaa !24
  %t49 = mul i64 %t45, %t46
  %t52 = add i64 %t44, %t49
  store i64 %t52, ptr %l6, !tbaa !24
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/check:Checker", ptr %t54, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !29
  %t58 = load i64, ptr %l6, !tbaa !24
  %t61 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t57, i64 %t58)
  store ptr %t61, ptr %l41
  br label %bb12
bb12:
  %t62 = load ptr, ptr %l41, !tbaa !29
  store ptr %t62, ptr %l7, !tbaa !29
  %t63 = load ptr, ptr %l7, !tbaa !29
  %t65 = getelementptr %"compiler/ast:Func", ptr %t63, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t68 = icmp eq ptr %t66, null
  br i1 %t68, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l45, !tbaa !21
  br label %bb16
bb14:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/check:Checker", ptr %t70, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !29
  %t74 = load i64, ptr %l6, !tbaa !24
  %t77 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnIsExtern(ptr %v0, ptr %t73, i64 %t74)
  store i1 %t77, ptr %l49
  br label %bb15
bb15:
  %t78 = load i1, ptr %l49, !tbaa !21
  store i1 %t78, ptr %l45, !tbaa !21
  br label %bb16
bb16:
  %t79 = load i1, ptr %l45, !tbaa !21
  br i1 %t79, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l50, !tbaa !21
  br label %bb21
bb18:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/check:Checker", ptr %t80, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !29
  store ptr %t83, ptr %l52, !tbaa !29
  %t84 = load i64, ptr %l6, !tbaa !24
  %t86 = call i64 @compiler_2fgeneric_2eFnOwner(i64 %t84)
  store i64 %t86, ptr %l54
  br label %bb19
bb19:
  %t87 = load ptr, ptr %l52, !tbaa !29
  %t88 = load i64, ptr %l54, !tbaa !24
  %t89 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %t87, i64 %t88)
  store i64 %t89, ptr %l55
  br label %bb20
bb20:
  %t90 = load i64, ptr %l55, !tbaa !24
  %t91 = icmp sgt i64 %t90, 0
  store i1 %t91, ptr %l50, !tbaa !21
  br label %bb21
bb21:
  %t93 = load i1, ptr %l50, !tbaa !21
  br i1 %t93, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s2)
  br label %bb61
bb23:
  br label %bb24
bb24:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/check:Checker", ptr %t94, i32 0, i32 3
  %t97 = load i1, ptr %t96, !tbaa !21
  br i1 %t97, label %bb25, label %bb26
bb25:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/check:Checker", ptr %t99, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !29
  %t103 = load i64, ptr %l6, !tbaa !24
  %t106 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t102, i64 %t103)
  store i64 %t106, ptr %l63
  br label %bb27
bb26:
  store i1 false, ptr %l59, !tbaa !21
  br label %bb28
bb27:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = getelementptr %"compiler/check:Checker", ptr %t107, i32 0, i32 1
  %t110 = load ptr, ptr %t109, !tbaa !29
  %t112 = getelementptr %"compiler/generic:Program", ptr %t110, i32 0, i32 0
  %t113 = load ptr, ptr %t112, !tbaa !29
  %t115 = getelementptr %"compiler/load:Loader", ptr %t113, i32 0, i32 12
  %t116 = load i64, ptr %t115, !tbaa !24
  %t117 = load i64, ptr %l63, !tbaa !24
  %t119 = icmp ne i64 %t117, %t116
  store i1 %t119, ptr %l59, !tbaa !21
  br label %bb28
bb28:
  %t121 = load i1, ptr %l59, !tbaa !21
  br i1 %t121, label %bb29, label %bb30
bb29:
  call void @__olang_scope_close(ptr %s2)
  br label %bb61
bb30:
  br label %bb31
bb31:
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t123 = load ptr, ptr %l7, !tbaa !29
  %t125 = getelementptr %"compiler/ast:Func", ptr %t123, i32 0, i32 2
  %t126 = load i32, ptr %t125, !tbaa !23
  %t129 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t122, i32 %t126)
  store { i64, ptr } %t129, ptr %l72
  br label %bb32
bb32:
  %t130 = load { i64, ptr }, ptr %l72, !tbaa !27
  store { i64, ptr } %t130, ptr %l8, !tbaa !27
  %t131 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t133 = extractvalue { i64, ptr } %t131, 0
  %t135 = icmp eq i64 %t133, 0
  br i1 %t135, label %bb33, label %bb34
bb33:
  call void @__olang_scope_close(ptr %s2)
  br label %bb61
bb34:
  br label %bb35
bb35:
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t138 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t141 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoperatorRole(ptr %v0, ptr %v0, ptr %s2, ptr %t137, { i64, ptr } %t138)
  store { i64, ptr } %t141, ptr %l78
  br label %bb36
bb36:
  %t142 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t143 = extractvalue { i64, ptr } %t142, 0
  %t144 = extractvalue { i64, ptr } %t142, 1
  %t145 = mul i64 %t143, 1
  %t146 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t145)
  call void @llvm.memcpy.p0.p0.i64(ptr %t146, ptr %t144, i64 %t145, i1 false)
  %t147 = insertvalue { i64, ptr } undef, i64 %t143, 0
  %t148 = insertvalue { i64, ptr } %t147, ptr %t146, 1
  %t150 = call i64 @compiler_2fcheck_2eopShapeOf(ptr %s2, { i64, ptr } %t148)
  store i64 %t150, ptr %l80
  br label %bb37
bb37:
  %t151 = load i64, ptr %l80, !tbaa !24
  store i64 %t151, ptr %l9, !tbaa !24
  %t152 = load i64, ptr %l9, !tbaa !24
  %t154 = icmp slt i64 %t152, 0
  br i1 %t154, label %bb38, label %bb39
bb38:
  store i1 true, ptr %l83, !tbaa !21
  br label %bb40
bb39:
  %t156 = load i64, ptr %l9, !tbaa !24
  %t158 = getelementptr [23 x %"compiler/check:opShape"], ptr @G_2ecompiler_2fcheck_2eOpShapes, i64 0, i64 %t156
  %t159 = getelementptr %"compiler/check:opShape", ptr %t158, i32 0, i32 3
  %t160 = load i1, ptr %t159, !tbaa !21
  store i1 %t160, ptr %l83, !tbaa !21
  br label %bb40
bb40:
  %t162 = load i1, ptr %l83, !tbaa !21
  br i1 %t162, label %bb41, label %bb42
bb41:
  call void @__olang_scope_close(ptr %s2)
  br label %bb61
bb42:
  br label %bb43
bb43:
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t165 = getelementptr %"compiler/check:Checker", ptr %t163, i32 0, i32 1
  %t166 = load ptr, ptr %t165, !tbaa !29
  %t167 = load i64, ptr %l6, !tbaa !24
  %t170 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t166, i64 %t167)
  store i32 %t170, ptr %l89
  br label %bb44
bb44:
  %t171 = load i32, ptr %l89, !tbaa !23
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t176 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einfersErrs(ptr %v0, ptr %t172, i32 %t171)
  store i1 %t176, ptr %l92
  br label %bb45
bb45:
  %t177 = load i1, ptr %l92, !tbaa !21
  br i1 %t177, label %bb46, label %bb47
bb46:
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t180 = getelementptr %"compiler/check:Checker", ptr %t178, i32 0, i32 1
  %t181 = load ptr, ptr %t180, !tbaa !29
  %t183 = getelementptr %"compiler/generic:Program", ptr %t181, i32 0, i32 2
  store ptr %t183, ptr %l96, !tbaa !29
  %t184 = load ptr, ptr %l0, !tbaa !29
  %t185 = load i64, ptr %l6, !tbaa !24
  %t188 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efnErrors(ptr %v0, ptr %t184, i64 %t185)
  store i32 %t188, ptr %l99
  br label %bb48
bb47:
  store i1 false, ptr %l93, !tbaa !21
  br label %bb50
bb48:
  %t189 = load ptr, ptr %l96, !tbaa !29
  %t190 = load i32, ptr %l99, !tbaa !23
  %t191 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s2, ptr %t189, i32 %t190)
  store { i64, ptr } %t191, ptr %l100
  br label %bb49
bb49:
  %t192 = load { i64, ptr }, ptr %l100, !tbaa !27
  %t193 = extractvalue { i64, ptr } %t192, 0
  %t195 = icmp sgt i64 %t193, 0
  store i1 %t195, ptr %l93, !tbaa !21
  br label %bb50
bb50:
  %t197 = load i1, ptr %l93, !tbaa !21
  br i1 %t197, label %bb51, label %bb52
bb51:
  store %olang.scope zeroinitializer, ptr %s7
  %t198 = load ptr, ptr %l0, !tbaa !29
  store ptr %t198, ptr %l103, !tbaa !29
  %t199 = load ptr, ptr %l0, !tbaa !29
  %t201 = getelementptr %"compiler/check:Checker", ptr %t199, i32 0, i32 1
  %t202 = load ptr, ptr %t201, !tbaa !29
  %t203 = load i64, ptr %l6, !tbaa !24
  %t206 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t202, i64 %t203)
  store i64 %t206, ptr %l107
  br label %bb53
bb52:
  br label %bb60
bb53:
  %t207 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t208 = load ptr, ptr %l103, !tbaa !29
  %t209 = load i64, ptr %l107, !tbaa !24
  %t211 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %v0, ptr %t208, i64 -1, i64 %t209, i32 %t207, i32 0)
  store ptr %t211, ptr %l109
  br label %bb54
bb54:
  %t212 = load ptr, ptr %l0, !tbaa !29
  store ptr %t212, ptr %l110, !tbaa !29
  %t213 = load ptr, ptr %l0, !tbaa !29
  %t214 = load ptr, ptr %l7, !tbaa !29
  %t217 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enameSpan(ptr %v0, ptr %v0, ptr %t213, ptr %t214)
  store %"compiler/source:Span" %t217, ptr %l113
  br label %bb55
bb55:
  %t218 = load ptr, ptr %l0, !tbaa !29
  %t219 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t222 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoperatorRole(ptr %v0, ptr %v0, ptr %s7, ptr %t218, { i64, ptr } %t219)
  store { i64, ptr } %t222, ptr %l116
  br label %bb56
bb56:
  %t223 = load { i64, ptr }, ptr %l116, !tbaa !27
  %t224 = extractvalue { i64, ptr } %t223, 0
  %t225 = extractvalue { i64, ptr } %t223, 1
  %t226 = mul i64 %t224, 1
  %t227 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t226)
  call void @llvm.memcpy.p0.p0.i64(ptr %t227, ptr %t225, i64 %t226, i1 false)
  %t228 = insertvalue { i64, ptr } undef, i64 %t224, 0
  %t229 = insertvalue { i64, ptr } %t228, ptr %t227, 1
  %t231 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eMethodCannotFail(ptr %s7, ptr %s7, { i64, ptr } %t229)
  store %"compiler/msgs:Msg" %t231, ptr %l118
  br label %bb57
bb57:
  %t232 = load ptr, ptr %l110, !tbaa !29
  %t233 = load %"compiler/source:Span", ptr %l113
  %t234 = load %"compiler/msgs:Msg", ptr %l118
  %t235 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s7, ptr %t232, %"compiler/source:Span" %t233, %"compiler/msgs:Msg" %t234)
  store i64 %t235, ptr %l119
  br label %bb58
bb58:
  %t236 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t236)
  br label %bb59
bb59:
  call void @__olang_scope_close(ptr %s7)
  br label %bb60
bb60:
  call void @__olang_scope_close(ptr %s2)
  br label %bb61
bb61:
  %t238 = load i64, ptr %l5, !tbaa !24
  %t240 = add i64 %t238, 1
  store i64 %t240, ptr %l5, !tbaa !24
  br label %bb8
bb62:
  %t242 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edrain(ptr %v0, ptr %t242)
  br label %bb63
bb63:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efor3(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, i64, i64 }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l11 = alloca i64
  %l15 = alloca { i64, i64, i64 }
  %l37 = alloca ptr
  %t66 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 37
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l11
  br label %bb1
bb1:
  %t6 = load i64, ptr %l11, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load %"compiler/source:Span", ptr %l1
  %t12 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t7, i32 1, %"compiler/source:Span" %t8)
  store { i64, i64, i64 } %t12, ptr %l15
  br label %bb2
bb2:
  %t13 = load { i64, i64, i64 }, ptr %l15
  store { i64, i64, i64 } %t13, ptr %l4
  %t14 = getelementptr { i64, i64, i64 }, ptr %l4, i32 0, i32 0
  %t15 = load i64, ptr %t14, !tbaa !24
  store i64 %t15, ptr %l5, !tbaa !24
  %t17 = getelementptr { i64, i64, i64 }, ptr %l4, i32 0, i32 1
  %t18 = load i64, ptr %t17, !tbaa !24
  store i64 %t18, ptr %l6, !tbaa !24
  %t20 = getelementptr { i64, i64, i64 }, ptr %l4, i32 0, i32 2
  %t21 = load i64, ptr %t20, !tbaa !24
  store i64 %t21, ptr %l7, !tbaa !24
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load ptr, ptr %l2, !tbaa !29
  %t26 = getelementptr %"compiler/ast:For3", ptr %t24, i32 0, i32 0
  %t27 = load ptr, ptr %t26, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmt(ptr %v0, ptr %v1, ptr %t23, ptr %t27)
  br label %bb3
bb3:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load %"compiler/source:Span", ptr %l1
  %t33 = load ptr, ptr %l2, !tbaa !29
  %t35 = getelementptr %"compiler/ast:For3", ptr %t33, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !29
  %t37 = load ptr, ptr %l2, !tbaa !29
  %t39 = getelementptr %"compiler/ast:For3", ptr %t37, i32 0, i32 3
  %t40 = load { i64, ptr }, ptr %t39, !tbaa !27
  %t41 = load ptr, ptr %l2, !tbaa !29
  %t43 = getelementptr %"compiler/ast:For3", ptr %t41, i32 0, i32 2
  %t44 = load ptr, ptr %t43, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eloop(ptr %v0, ptr %v1, ptr %v1, ptr %v1, ptr %t31, %"compiler/source:Span" %t32, ptr %t36, { i64, ptr } %t40, ptr %t44)
  br label %bb4
bb4:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t52 = load i64, ptr %l5, !tbaa !24
  %t53 = load i64, ptr %l6, !tbaa !24
  %t54 = load i64, ptr %l7, !tbaa !24
  %t55 = load i64, ptr %l3, !tbaa !24
  %t61 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %v0, ptr %t51, i64 %t52, i64 %t53, i64 %t54, i64 %t55)
  store ptr %t61, ptr %l37
  br label %bb5
bb5:
  %t62 = load ptr, ptr %l37, !tbaa !29
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = load %"compiler/source:Span", ptr %l1
  store { i64, [3 x i64] } zeroinitializer, ptr %t66
  %t67 = getelementptr { i64, [3 x i64] }, ptr %t66, i32 0, i32 0
  store i64 11, ptr %t67
  %t69 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t64, 0
  %t71 = insertvalue { %"compiler/source:Span", ptr } %t69, ptr %t62, 1
  %t72 = getelementptr { i64, [3 x i64] }, ptr %t66, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t71, ptr %t72
  %t73 = load { i64, [3 x i64] }, ptr %t66
  %t75 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t73, ptr %t75
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t63, ptr %t75)
  br label %bb6
bb6:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eheldArg(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, ptr %a2, i64 %a3) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca ptr
  %l3 = alloca i64
  %l6 = alloca i64
  %l8 = alloca { i64, ptr }
  %l11 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l15 = alloca %"compiler/source:Span"
  %l18 = alloca i64
  %l19 = alloca ptr
  %rv = alloca ptr
  store { i64, ptr } %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t2 = load i64, ptr %l3, !tbaa !24
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v2, ptr %t1, i64 %t2)
  store i64 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i64, ptr %l6, !tbaa !24
  %t7 = icmp slt i64 %t6, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t9, ptr %l8, !tbaa !27
  %t10 = load i64, ptr %l3, !tbaa !24
  %t12 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr ptr, ptr %t13, i64 %t10
  %t15 = load ptr, ptr %t14, !tbaa !39
  store ptr %t15, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  store ptr %a0, ptr %l11, !tbaa !29
  %t18 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t18, ptr %l12, !tbaa !27
  %t19 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr ptr, ptr %t22, i64 %t19
  %t24 = load ptr, ptr %t23, !tbaa !39
  %t26 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t24)
  store %"compiler/source:Span" %t26, ptr %l15
  br label %bb5
bb5:
  %t27 = load ptr, ptr %l2, !tbaa !29
  %t28 = load i64, ptr %l3, !tbaa !24
  %t31 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v2, ptr %t27, i64 %t28)
  store i64 %t31, ptr %l18
  br label %bb6
bb6:
  %t32 = load ptr, ptr %l11, !tbaa !29
  %t33 = load %"compiler/source:Span", ptr %l15
  %t34 = load i64, ptr %l18, !tbaa !24
  %t35 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v3, ptr %t32, %"compiler/source:Span" %t33, i64 %t34)
  store ptr %t35, ptr %l19
  br label %bb7
bb7:
  %t36 = load ptr, ptr %l19, !tbaa !29
  store ptr %t36, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eheldResult(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l7 = alloca i32
  %l10 = alloca i1
  %l12 = alloca i1
  %l17 = alloca i64
  %l23 = alloca ptr
  %l28 = alloca i32
  %l33 = alloca i64
  %l36 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t7 = load i32, ptr %l1, !tbaa !23
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t10, ptr %l7
  br label %bb1
bb1:
  %t11 = load i32, ptr %l7, !tbaa !23
  store i32 %t11, ptr %l2, !tbaa !23
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load i32, ptr %l2, !tbaa !23
  %t16 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t12, i32 %t13)
  store i1 %t16, ptr %l10
  br label %bb2
bb2:
  %t17 = load i1, ptr %l10, !tbaa !21
  %t18 = xor i1 %t17, true
  br i1 %t18, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb6
bb4:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/check:Checker", ptr %t20, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t25 = getelementptr %"compiler/generic:Program", ptr %t23, i32 0, i32 2
  %t26 = load i32, ptr %l1, !tbaa !23
  %t29 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRole(ptr %v0, ptr %t25, i32 %t26)
  store i64 %t29, ptr %l17
  br label %bb5
bb5:
  %t30 = load i64, ptr @G_2ecompiler_2ftypes_2eRoleCtor, !tbaa !24
  %t31 = load i64, ptr %l17, !tbaa !24
  %t33 = icmp ne i64 %t31, %t30
  store i1 %t33, ptr %l12, !tbaa !21
  br label %bb6
bb6:
  %t35 = load i1, ptr %l12, !tbaa !21
  br i1 %t35, label %bb7, label %bb8
bb7:
  %t36 = load i32, ptr %l2, !tbaa !23
  store i32 %t36, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/check:Checker", ptr %t38, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t43 = getelementptr %"compiler/generic:Program", ptr %t41, i32 0, i32 2
  store ptr %t43, ptr %l23, !tbaa !29
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/check:Checker", ptr %t44, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t49 = getelementptr %"compiler/generic:Program", ptr %t47, i32 0, i32 2
  %t50 = load i32, ptr %l2, !tbaa !23
  %t53 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t49, i32 %t50)
  store i32 %t53, ptr %l28
  br label %bb10
bb10:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/check:Checker", ptr %t54, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !29
  %t59 = getelementptr %"compiler/generic:Program", ptr %t57, i32 0, i32 2
  %t60 = load i32, ptr %l2, !tbaa !23
  %t63 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t59, i32 %t60)
  store i64 %t63, ptr %l33
  br label %bb11
bb11:
  %t64 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t65 = load i64, ptr %l33, !tbaa !24
  %t67 = or i64 %t65, %t64
  %t68 = load ptr, ptr %l23, !tbaa !29
  %t69 = load i32, ptr %l28, !tbaa !23
  %t71 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t68, i32 %t69, i64 %t67)
  store i32 %t71, ptr %l36
  br label %bb12
bb12:
  %t72 = load i32, ptr %l36, !tbaa !23
  store i32 %t72, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsWritable(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsWritableAt(ptr %v0, ptr %a0, i32 %a1, i64 0)
  store i1 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i1, ptr %l4, !tbaa !21
  store i1 %t6, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %a0) #0 {
entry:
  %l4 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"compiler/check:Checker", ptr %a0, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t8 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s0, ptr %t6, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d28, i32 0, i32 1) })
  store i32 %t8, ptr %l4
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t9 = load i32, ptr %l4, !tbaa !23
  store i32 %t9, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einWrittenOrder(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i1
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca %"compiler/source:Span"
  %l23 = alloca i64
  %l31 = alloca { i64, ptr }
  %l48 = alloca i64
  %l51 = alloca i64
  %l74 = alloca i64
  %l77 = alloca i64
  %l95 = alloca { i64, ptr }
  %l100 = alloca i1
  %l103 = alloca i64
  %l106 = alloca i64
  %l113 = alloca ptr
  %l114 = alloca ptr
  %l115 = alloca i1
  %l119 = alloca %"compiler/source:Span"
  %l120 = alloca ptr
  %l121 = alloca %"compiler/source:Span"
  %l124 = alloca i32
  %l125 = alloca i64
  %l136 = alloca ptr
  %l139 = alloca i64
  %l143 = alloca ptr
  %t213 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store i64 -1, ptr %l3, !tbaa !24
  store i1 true, ptr %l4, !tbaa !21
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t1, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l7, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l6, !tbaa !24
  %t8 = load i64, ptr %l7, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb12
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t15, ptr %l31, !tbaa !27
  %t16 = load i64, ptr %l6, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr i64, ptr %t19, i64 %t16
  %t21 = load i64, ptr %t20, !tbaa !34
  store i64 %t21, ptr %l8, !tbaa !24
  %t23 = load i64, ptr %l8, !tbaa !24
  %t25 = icmp slt i64 %t23, 0
  br i1 %t25, label %bb5, label %bb6
bb5:
  br label %bb11
bb6:
  br label %bb7
bb7:
  %t27 = load i64, ptr %l8, !tbaa !24
  %t28 = load i64, ptr %l3, !tbaa !24
  %t31 = icmp slt i64 %t27, %t28
  br i1 %t31, label %bb8, label %bb9
bb8:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb10
bb9:
  br label %bb10
bb10:
  %t33 = load i64, ptr %l8, !tbaa !24
  store i64 %t33, ptr %l3, !tbaa !24
  br label %bb11
bb11:
  %t35 = load i64, ptr %l6, !tbaa !24
  %t37 = add i64 %t35, 1
  store i64 %t37, ptr %l6, !tbaa !24
  br label %bb1
bb12:
  %t39 = load i1, ptr %l4, !tbaa !21
  br i1 %t39, label %bb13, label %bb14
bb13:
  br label %ret
bb14:
  br label %bb15
bb15:
  store i64 0, ptr %l9, !tbaa !24
  %t41 = load i64, ptr %l3, !tbaa !24
  %t43 = add i64 %t41, 1
  store i64 %t43, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t45 = load i64, ptr %l10, !tbaa !24
  %t46 = load i64, ptr %l9, !tbaa !24
  %t49 = icmp sgt i64 %t45, %t46
  br i1 %t49, label %bb16, label %bb17
bb16:
  %t51 = load i64, ptr %l11, !tbaa !24
  %t53 = icmp sgt i64 %t51, 0
  br i1 %t53, label %bb18, label %bb19
bb17:
  store i64 0, ptr %l48, !tbaa !24
  br label %bb21
bb18:
  %t55 = load i64, ptr %l10, !tbaa !24
  %t56 = load i64, ptr %l9, !tbaa !24
  %t59 = sub i64 %t55, %t56
  %t60 = load i64, ptr %l11, !tbaa !24
  %t63 = add i64 %t59, %t60
  %t65 = sub i64 %t63, 1
  %t66 = load i64, ptr %l11, !tbaa !24
  %t69 = sdiv i64 %t65, %t66
  store i64 %t69, ptr %l51, !tbaa !24
  br label %bb20
bb19:
  store i64 0, ptr %l51, !tbaa !24
  br label %bb20
bb20:
  %t71 = load i64, ptr %l51, !tbaa !24
  store i64 %t71, ptr %l48, !tbaa !24
  br label %bb21
bb21:
  %t72 = load i64, ptr %l48, !tbaa !24
  store i64 %t72, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb22
bb22:
  %t73 = load i64, ptr %l13, !tbaa !24
  %t74 = load i64, ptr %l12, !tbaa !24
  %t77 = icmp slt i64 %t73, %t74
  %t79 = xor i1 %t77, true
  br i1 %t79, label %bb23, label %bb24
bb23:
  br label %bb64
bb24:
  br label %bb25
bb25:
  %t81 = load i64, ptr %l9, !tbaa !24
  %t82 = load i64, ptr %l13, !tbaa !24
  %t83 = load i64, ptr %l11, !tbaa !24
  %t86 = mul i64 %t82, %t83
  %t89 = add i64 %t81, %t86
  store i64 %t89, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  %t91 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t93 = extractvalue { i64, ptr } %t91, 0
  store i64 %t93, ptr %l16, !tbaa !24
  store i64 1, ptr %l17, !tbaa !24
  %t95 = load i64, ptr %l16, !tbaa !24
  %t96 = load i64, ptr %l15, !tbaa !24
  %t99 = icmp sgt i64 %t95, %t96
  br i1 %t99, label %bb26, label %bb27
bb26:
  %t101 = load i64, ptr %l17, !tbaa !24
  %t103 = icmp sgt i64 %t101, 0
  br i1 %t103, label %bb28, label %bb29
bb27:
  store i64 0, ptr %l74, !tbaa !24
  br label %bb31
bb28:
  %t105 = load i64, ptr %l16, !tbaa !24
  %t106 = load i64, ptr %l15, !tbaa !24
  %t109 = sub i64 %t105, %t106
  %t110 = load i64, ptr %l17, !tbaa !24
  %t113 = add i64 %t109, %t110
  %t115 = sub i64 %t113, 1
  %t116 = load i64, ptr %l17, !tbaa !24
  %t119 = sdiv i64 %t115, %t116
  store i64 %t119, ptr %l77, !tbaa !24
  br label %bb30
bb29:
  store i64 0, ptr %l77, !tbaa !24
  br label %bb30
bb30:
  %t121 = load i64, ptr %l77, !tbaa !24
  store i64 %t121, ptr %l74, !tbaa !24
  br label %bb31
bb31:
  %t122 = load i64, ptr %l74, !tbaa !24
  store i64 %t122, ptr %l18, !tbaa !24
  store i64 0, ptr %l19, !tbaa !24
  br label %bb32
bb32:
  %t123 = load i64, ptr %l19, !tbaa !24
  %t124 = load i64, ptr %l18, !tbaa !24
  %t127 = icmp slt i64 %t123, %t124
  %t129 = xor i1 %t127, true
  br i1 %t129, label %bb33, label %bb34
bb33:
  br label %bb62
bb34:
  br label %bb35
bb35:
  %t131 = load i64, ptr %l15, !tbaa !24
  %t132 = load i64, ptr %l19, !tbaa !24
  %t133 = load i64, ptr %l17, !tbaa !24
  %t136 = mul i64 %t132, %t133
  %t139 = add i64 %t131, %t136
  store i64 %t139, ptr %l20, !tbaa !24
  %t141 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t141, ptr %l95, !tbaa !27
  %t142 = load i64, ptr %l20, !tbaa !24
  %t144 = getelementptr { i64, ptr }, ptr %l95, i32 0, i32 1
  %t145 = load ptr, ptr %t144, !tbaa !27
  %t146 = getelementptr i64, ptr %t145, i64 %t142
  %t147 = load i64, ptr %t146, !tbaa !34
  %t148 = load i64, ptr %l14, !tbaa !24
  %t151 = icmp ne i64 %t147, %t148
  br i1 %t151, label %bb36, label %bb37
bb36:
  store i1 true, ptr %l100, !tbaa !21
  br label %bb39
bb37:
  %t153 = load i64, ptr %l2, !tbaa !24
  %t154 = load i64, ptr %l20, !tbaa !24
  %t157 = add i64 %t153, %t154
  store i64 %t157, ptr %l103, !tbaa !24
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t160 = getelementptr %"compiler/check:Checker", ptr %t158, i32 0, i32 36
  %t162 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t160)
  store i64 %t162, ptr %l106
  br label %bb38
bb38:
  %t163 = load i64, ptr %l103, !tbaa !24
  %t164 = load i64, ptr %l106, !tbaa !24
  %t165 = icmp sge i64 %t163, %t164
  store i1 %t165, ptr %l100, !tbaa !21
  br label %bb39
bb39:
  %t167 = load i1, ptr %l100, !tbaa !21
  br i1 %t167, label %bb40, label %bb41
bb40:
  br label %bb61
bb41:
  br label %bb42
bb42:
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t170 = getelementptr %"compiler/check:Checker", ptr %t168, i32 0, i32 36
  %t171 = load i64, ptr %l2, !tbaa !24
  %t172 = load i64, ptr %l20, !tbaa !24
  %t175 = add i64 %t171, %t172
  %t178 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t170, i64 %t175)
  store ptr %t178, ptr %l113
  br label %bb43
bb43:
  %t179 = load ptr, ptr %l113, !tbaa !29
  store ptr %t179, ptr %l21, !tbaa !29
  %t180 = load ptr, ptr %l21, !tbaa !29
  store ptr %t180, ptr %l114, !tbaa !29
  store i1 false, ptr %l115, !tbaa !21
  %t181 = load ptr, ptr %l114, !tbaa !29
  %t182 = icmp ne ptr %t181, null
  br i1 %t182, label %bb44, label %bb45
bb44:
  %t184 = load ptr, ptr %l114, !tbaa !29
  %t185 = load i64, ptr %t184, !range !{i64 0, i64 18}
  %t187 = icmp eq i64 %t185, 0
  store i1 %t187, ptr %l115, !tbaa !21
  br label %bb45
bb45:
  %t188 = load i1, ptr %l115, !tbaa !21
  br i1 %t188, label %bb46, label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb49
bb48:
  br label %bb61
bb49:
  br i1 true, label %bb50, label %bb51
bb50:
  br label %bb52
bb51:
  br label %bb53
bb52:
  br label %bb54
bb53:
  call void @__olang_check_failed(ptr @olang_loc_862846f5a5002b51_69e64f75e4a124a5)
  unreachable
bb54:
  %t189 = load ptr, ptr %l21, !tbaa !29
  %t191 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %t189)
  store %"compiler/source:Span" %t191, ptr %l119
  br label %bb55
bb55:
  %t192 = load %"compiler/source:Span", ptr %l119
  store %"compiler/source:Span" %t192, ptr %l22
  %t193 = load ptr, ptr %l0, !tbaa !29
  store ptr %t193, ptr %l120, !tbaa !29
  %t194 = load %"compiler/source:Span", ptr %l22
  store %"compiler/source:Span" %t194, ptr %l121
  %t195 = load ptr, ptr %l21, !tbaa !29
  %t198 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t195)
  store i32 %t198, ptr %l124
  br label %bb56
bb56:
  %t199 = load ptr, ptr %l120, !tbaa !29
  %t200 = load %"compiler/source:Span", ptr %l121
  %t201 = load i32, ptr %l124, !tbaa !23
  %t202 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t199, %"compiler/source:Span" %t200, i32 %t201)
  store i64 %t202, ptr %l125
  br label %bb57
bb57:
  %t203 = load i64, ptr %l125, !tbaa !24
  store i64 %t203, ptr %l23, !tbaa !24
  %t204 = load ptr, ptr %l0, !tbaa !29
  %t206 = getelementptr %"compiler/check:Checker", ptr %t204, i32 0, i32 37
  %t207 = load %"compiler/source:Span", ptr %l22
  %t208 = load i64, ptr %l23, !tbaa !24
  %t210 = trunc i64 %t208 to i32
  %t212 = load ptr, ptr %l21, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t213
  %t214 = getelementptr { i64, [3 x i64] }, ptr %t213, i32 0, i32 0
  store i64 0, ptr %t214
  %t216 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t207, 0
  %t218 = insertvalue { %"compiler/source:Span", i32, ptr } %t216, i32 %t210, 1
  %t220 = insertvalue { %"compiler/source:Span", i32, ptr } %t218, ptr %t212, 2
  %t221 = getelementptr { i64, [3 x i64] }, ptr %t213, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t220, ptr %t221
  %t222 = load { i64, [3 x i64] }, ptr %t213
  %t224 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t222, ptr %t224
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t206, ptr %t224)
  br label %bb58
bb58:
  %t227 = load ptr, ptr %l0, !tbaa !29
  %t229 = getelementptr %"compiler/check:Checker", ptr %t227, i32 0, i32 36
  store ptr %t229, ptr %l136, !tbaa !29
  %t230 = load i64, ptr %l2, !tbaa !24
  %t231 = load i64, ptr %l20, !tbaa !24
  %t234 = add i64 %t230, %t231
  store i64 %t234, ptr %l139, !tbaa !24
  %t235 = load ptr, ptr %l0, !tbaa !29
  %t236 = load %"compiler/source:Span", ptr %l22
  %t237 = load i64, ptr %l23, !tbaa !24
  %t241 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t235, %"compiler/source:Span" %t236, i64 %t237)
  store ptr %t241, ptr %l143
  br label %bb59
bb59:
  %t242 = load ptr, ptr %l136, !tbaa !29
  %t243 = load i64, ptr %l139, !tbaa !24
  %t244 = load ptr, ptr %l143, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eSetAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t242, i64 %t243, ptr %t244)
  br label %bb60
bb60:
  br label %bb61
bb61:
  %t245 = load i64, ptr %l19, !tbaa !24
  %t247 = add i64 %t245, 1
  store i64 %t247, ptr %l19, !tbaa !24
  br label %bb32
bb62:
  br label %bb63
bb63:
  %t249 = load i64, ptr %l13, !tbaa !24
  %t251 = add i64 %t249, 1
  store i64 %t251, ptr %l13, !tbaa !24
  br label %bb22
bb64:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisStruct(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i1
  %l5 = alloca i1
  %l8 = alloca i32
  %l11 = alloca i1
  %l15 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i1, ptr %l4, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l1, !tbaa !23
  %t11 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %t7, i32 %t8)
  store i32 %t11, ptr %l8
  br label %bb4
bb3:
  store i1 false, ptr %l5, !tbaa !21
  br label %bb5
bb4:
  %t12 = load i32, ptr %l8, !range !{i32 0, i32 6}
  %t14 = trunc i64 0 to i32
  %t15 = icmp eq i32 %t12, %t14
  store i1 %t15, ptr %l5, !tbaa !21
  br label %bb5
bb5:
  %t17 = load i1, ptr %l5, !tbaa !21
  br i1 %t17, label %bb6, label %bb7
bb6:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/check:Checker", ptr %t18, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t22 = load i32, ptr %l1, !tbaa !23
  %t25 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t21, i32 %t22)
  store i1 %t25, ptr %l15
  br label %bb8
bb7:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb9
bb8:
  %t26 = load i1, ptr %l15, !tbaa !21
  store i1 %t26, ptr %l11, !tbaa !21
  br label %bb9
bb9:
  %t27 = load i1, ptr %l11, !tbaa !21
  store i1 %t27, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ejumpText(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l5 = alloca ptr
  %l10 = alloca i32
  %l15 = alloca i32
  %l16 = alloca i32
  %l17 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"compiler/check:Checker", ptr %t2, i32 0, i32 1
  %t5 = load ptr, ptr %t4, !tbaa !29
  %t7 = getelementptr %"compiler/generic:Program", ptr %t5, i32 0, i32 2
  store ptr %t7, ptr %l5, !tbaa !29
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/check:Checker", ptr %t8, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t13 = getelementptr %"compiler/generic:Program", ptr %t11, i32 0, i32 2
  %t14 = load i32, ptr %l1, !tbaa !23
  %t17 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t13, i32 %t14)
  store i32 %t17, ptr %l10
  br label %bb1
bb1:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/check:Checker", ptr %t18, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t23 = getelementptr %"compiler/generic:Program", ptr %t21, i32 0, i32 2
  %t24 = load i32, ptr %l1, !tbaa !23
  %t27 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t23, i32 %t24)
  store i32 %t27, ptr %l15
  br label %bb2
bb2:
  %t28 = load ptr, ptr %l5, !tbaa !29
  %t29 = load i32, ptr %l10, !tbaa !23
  %t30 = load i32, ptr %l15, !tbaa !23
  %t31 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t28, i32 %t29, i32 %t30, i32 0, i32 0, i64 0)
  store i32 %t31, ptr %l16
  br label %bb3
bb3:
  %t32 = load ptr, ptr %l2, !tbaa !29
  %t33 = load i32, ptr %l16, !tbaa !23
  %t34 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v1, ptr %t32, i32 %t33)
  store { i64, ptr } %t34, ptr %l17
  br label %bb4
bb4:
  %t35 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t35, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneBool(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, %"compiler/source:Span" %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca i32
  %l7 = alloca i32
  %l11 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca %"compiler/source:Span"
  %l18 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l23 = alloca %"compiler/msgs:Msg"
  %l24 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t4 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %a1)
  store i32 %t4, ptr %l7
  br label %bb1
bb1:
  %t5 = load i32, ptr %l7, !tbaa !23
  store i32 %t5, ptr %l4, !tbaa !23
  %t6 = load i32, ptr %l4, !tbaa !23
  %t7 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t10 = icmp eq i32 %t6, %t7
  br i1 %t10, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l11, !tbaa !21
  br label %bb4
bb3:
  %t12 = load i32, ptr %l4, !tbaa !23
  %t13 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t16 = icmp eq i32 %t12, %t13
  store i1 %t16, ptr %l11, !tbaa !21
  br label %bb4
bb4:
  %t18 = load i1, ptr %l11, !tbaa !21
  br i1 %t18, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t20 = load ptr, ptr %l0, !tbaa !29
  store ptr %t20, ptr %l16, !tbaa !29
  store %"compiler/source:Span" %a2, ptr %l17
  store { i64, ptr } %a3, ptr %l18, !tbaa !27
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load i32, ptr %l4, !tbaa !23
  %t27 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t23, i32 %t24)
  store { i64, ptr } %t27, ptr %l21
  br label %bb8
bb8:
  %t28 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t28, 0
  %t30 = extractvalue { i64, ptr } %t28, 1
  %t31 = mul i64 %t29, 1
  %t32 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t31)
  call void @llvm.memcpy.p0.p0.i64(ptr %t32, ptr %t30, i64 %t31, i1 false)
  %t33 = insertvalue { i64, ptr } undef, i64 %t29, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t32, 1
  %t35 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t37 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eOperandNotBool(ptr %v2, ptr %s0, ptr %s0, { i64, ptr } %t35, { i64, ptr } %t34)
  store %"compiler/msgs:Msg" %t37, ptr %l23
  br label %bb9
bb9:
  %t38 = load ptr, ptr %l16, !tbaa !29
  %t39 = load %"compiler/source:Span", ptr %l17
  %t40 = load %"compiler/msgs:Msg", ptr %l23
  %t41 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s0, ptr %t38, %"compiler/source:Span" %t39, %"compiler/msgs:Msg" %t40)
  store i64 %t41, ptr %l24
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneElemType(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i32
  %l9 = alloca i64
  %l15 = alloca %"compiler/check:laneNode"
  %l19 = alloca i32
  %l22 = alloca i1
  %l23 = alloca i32
  %l26 = alloca i32
  %s2 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t5, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load ptr, ptr %l1, !tbaa !29
  %t11 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneOf(ptr %v0, ptr %v1, ptr %t7, ptr %t8)
  store i64 %t11, ptr %l9
  br label %bb4
bb4:
  %t12 = load i64, ptr %l9, !tbaa !24
  store i64 %t12, ptr %l2, !tbaa !24
  %t13 = load i64, ptr %l2, !tbaa !24
  %t15 = icmp sge i64 %t13, 0
  br i1 %t15, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s2
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/check:Checker", ptr %t17, i32 0, i32 39
  %t20 = load i64, ptr %l2, !tbaa !24
  %t23 = call %"compiler/check:laneNode" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alaneNode_3e_2eAt_3ccompiler_2fcheck_3alaneNode_3e(ptr %v0, ptr %s2, ptr %t19, i64 %t20)
  store %"compiler/check:laneNode" %t23, ptr %l15
  br label %bb7
bb6:
  br label %bb8
bb7:
  %t24 = getelementptr %"compiler/check:laneNode", ptr %l15, i32 0, i32 8
  %t25 = load i32, ptr %t24, !tbaa !23
  call void @__olang_scope_close(ptr %s2)
  store i32 %t25, ptr %rv
  br label %ret
bb8:
  %t27 = load ptr, ptr %l1, !tbaa !29
  %t30 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t27)
  store i32 %t30, ptr %l19
  br label %bb9
bb9:
  %t31 = load i32, ptr %l19, !tbaa !23
  store i32 %t31, ptr %l3, !tbaa !23
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load i32, ptr %l3, !tbaa !23
  %t36 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneArray(ptr %v0, ptr %t32, i32 %t33)
  store i1 %t36, ptr %l22
  br label %bb10
bb10:
  %t37 = load i1, ptr %l22, !tbaa !21
  br i1 %t37, label %bb11, label %bb12
bb11:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load i32, ptr %l3, !tbaa !23
  %t42 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneElemOf(ptr %v0, ptr %t38, i32 %t39)
  store i32 %t42, ptr %l26
  br label %bb13
bb12:
  %t43 = load i32, ptr %l3, !tbaa !23
  store i32 %t43, ptr %l23, !tbaa !23
  br label %bb14
bb13:
  %t45 = load i32, ptr %l26, !tbaa !23
  store i32 %t45, ptr %l23, !tbaa !23
  br label %bb14
bb14:
  %t46 = load i32, ptr %l23, !tbaa !23
  store i32 %t46, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneUnType(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i64
  %l13 = alloca i32
  %l18 = alloca i1
  %l19 = alloca i1
  %l22 = alloca i1
  %l23 = alloca i1
  %l27 = alloca i1
  %l29 = alloca ptr
  %l30 = alloca i32
  %l33 = alloca { i64, ptr }
  %l34 = alloca i64
  %l37 = alloca i32
  %l41 = alloca i32
  %l47 = alloca i1
  %l48 = alloca i32
  %l53 = alloca i1
  %l54 = alloca i32
  %s3 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l2, !tbaa !23
  %t2 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t5 = icmp eq i32 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load i32, ptr %l2, !tbaa !23
  store i32 %t7, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t9 = load i32, ptr %l1, !range !{i32 0, i32 98}
  %t11 = trunc i64 48 to i32
  %t12 = icmp eq i32 %t9, %t11
  br i1 %t12, label %bb4, label %bb5
bb4:
  %t14 = load i32, ptr %l2, !tbaa !23
  %t15 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t18 = icmp eq i32 %t14, %t15
  br i1 %t18, label %bb6, label %bb7
bb5:
  br label %bb9
bb6:
  %t20 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t20, ptr %l13, !tbaa !23
  br label %bb8
bb7:
  %t22 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t22, ptr %l13, !tbaa !23
  br label %bb8
bb8:
  %t24 = load i32, ptr %l13, !tbaa !23
  store i32 %t24, ptr %rv
  br label %ret
bb9:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load i32, ptr %l2, !tbaa !23
  %t29 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t25, i32 %t26)
  store i1 %t29, ptr %l18
  br label %bb10
bb10:
  %t30 = load i1, ptr %l18, !tbaa !21
  br i1 %t30, label %bb11, label %bb12
bb11:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load i32, ptr %l2, !tbaa !23
  %t35 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t31, i32 %t32)
  store i1 %t35, ptr %l22
  br label %bb13
bb12:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb18
bb13:
  %t36 = load i1, ptr %l22, !tbaa !21
  br i1 %t36, label %bb14, label %bb15
bb14:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/check:Checker", ptr %t37, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t41 = load i32, ptr %l2, !tbaa !23
  %t44 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eExtends(ptr %v0, ptr %t40, i32 %t41)
  store i1 %t44, ptr %l27
  br label %bb16
bb15:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb17
bb16:
  %t45 = load i1, ptr %l27, !tbaa !21
  store i1 %t45, ptr %l23, !tbaa !21
  br label %bb17
bb17:
  %t46 = load i1, ptr %l23, !tbaa !21
  %t47 = xor i1 %t46, true
  store i1 %t47, ptr %l19, !tbaa !21
  br label %bb18
bb18:
  %t49 = load i1, ptr %l19, !tbaa !21
  br i1 %t49, label %bb19, label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s3
  %t50 = load ptr, ptr %l0, !tbaa !29
  store ptr %t50, ptr %l29, !tbaa !29
  %t51 = load i32, ptr %l2, !tbaa !23
  store i32 %t51, ptr %l30, !tbaa !23
  %t52 = load i32, ptr %l1, !range !{i32 0, i32 98}
  %t54 = trunc i64 53 to i32
  %t55 = icmp eq i32 %t52, %t54
  br i1 %t55, label %bb21, label %bb22
bb20:
  br label %bb29
bb21:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d29, i32 0, i32 1) }, ptr %l33, !tbaa !27
  br label %bb23
bb22:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d30, i32 0, i32 1) }, ptr %l33, !tbaa !27
  br label %bb23
bb23:
  %t57 = load ptr, ptr %l29, !tbaa !29
  %t58 = load i32, ptr %l30, !tbaa !23
  %t59 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t60 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %s3, ptr %t57, i32 %t58, { i64, ptr } %t59, i64 0)
  store i64 %t60, ptr %l34
  br label %bb24
bb24:
  %t61 = load i64, ptr %l34, !tbaa !24
  store i64 %t61, ptr %l3, !tbaa !24
  %t62 = load i64, ptr %l3, !tbaa !24
  %t64 = icmp sge i64 %t62, 0
  br i1 %t64, label %bb25, label %bb26
bb25:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load i64, ptr %l3, !tbaa !24
  %t68 = load i32, ptr %l2, !tbaa !23
  %t72 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneResult(ptr %v0, ptr %t66, i64 %t67, i32 %t68)
  store i32 %t72, ptr %l41
  br label %bb27
bb26:
  %t73 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t73, ptr %l37, !tbaa !23
  br label %bb28
bb27:
  %t75 = load i32, ptr %l41, !tbaa !23
  store i32 %t75, ptr %l37, !tbaa !23
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s3)
  %t76 = load i32, ptr %l37, !tbaa !23
  store i32 %t76, ptr %rv
  br label %ret
bb29:
  %t77 = load i32, ptr %l1, !range !{i32 0, i32 98}
  %t79 = trunc i64 53 to i32
  %t80 = icmp eq i32 %t77, %t79
  br i1 %t80, label %bb30, label %bb31
bb30:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t83 = load i32, ptr %l2, !tbaa !23
  %t86 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t82, i32 %t83)
  store i1 %t86, ptr %l47
  br label %bb32
bb31:
  br label %bb36
bb32:
  %t87 = load i1, ptr %l47, !tbaa !21
  br i1 %t87, label %bb33, label %bb34
bb33:
  %t88 = load i32, ptr %l2, !tbaa !23
  store i32 %t88, ptr %l48, !tbaa !23
  br label %bb35
bb34:
  %t90 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t90, ptr %l48, !tbaa !23
  br label %bb35
bb35:
  %t92 = load i32, ptr %l48, !tbaa !23
  store i32 %t92, ptr %rv
  br label %ret
bb36:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t94 = load i32, ptr %l2, !tbaa !23
  %t97 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisInt(ptr %v0, ptr %t93, i32 %t94)
  store i1 %t97, ptr %l53
  br label %bb37
bb37:
  %t98 = load i1, ptr %l53, !tbaa !21
  br i1 %t98, label %bb38, label %bb39
bb38:
  %t99 = load i32, ptr %l2, !tbaa !23
  store i32 %t99, ptr %l54, !tbaa !23
  br label %bb40
bb39:
  %t101 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t101, ptr %l54, !tbaa !23
  br label %bb40
bb40:
  %t103 = load i32, ptr %l54, !tbaa !23
  store i32 %t103, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleaksBetween(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l14 = alloca ptr
  %l20 = alloca i64
  %l23 = alloca i64
  %l41 = alloca ptr
  %l45 = alloca i32
  %l49 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l11
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l11
  %t3 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %t3
  store ptr %t3, ptr %l3, !tbaa !29
  %t7 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %a0)
  store ptr %t7, ptr %l14
  br label %bb2
bb2:
  %t8 = load ptr, ptr %l14, !tbaa !29
  store ptr %t8, ptr %l4, !tbaa !29
  store i64 %a1, ptr %l5, !tbaa !24
  store i64 %a2, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t13 = load i64, ptr %l6, !tbaa !24
  %t14 = load i64, ptr %l5, !tbaa !24
  %t17 = icmp sgt i64 %t13, %t14
  br i1 %t17, label %bb3, label %bb4
bb3:
  %t19 = load i64, ptr %l7, !tbaa !24
  %t21 = icmp sgt i64 %t19, 0
  br i1 %t21, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l20, !tbaa !24
  br label %bb8
bb5:
  %t23 = load i64, ptr %l6, !tbaa !24
  %t24 = load i64, ptr %l5, !tbaa !24
  %t27 = sub i64 %t23, %t24
  %t28 = load i64, ptr %l7, !tbaa !24
  %t31 = add i64 %t27, %t28
  %t33 = sub i64 %t31, 1
  %t34 = load i64, ptr %l7, !tbaa !24
  %t37 = sdiv i64 %t33, %t34
  store i64 %t37, ptr %l23, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb7
bb7:
  %t39 = load i64, ptr %l23, !tbaa !24
  store i64 %t39, ptr %l20, !tbaa !24
  br label %bb8
bb8:
  %t40 = load i64, ptr %l20, !tbaa !24
  store i64 %t40, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb9
bb9:
  %t41 = load i64, ptr %l9, !tbaa !24
  %t42 = load i64, ptr %l8, !tbaa !24
  %t45 = icmp slt i64 %t41, %t42
  %t47 = xor i1 %t45, true
  br i1 %t47, label %bb10, label %bb11
bb10:
  br label %bb16
bb11:
  br label %bb12
bb12:
  %t49 = load i64, ptr %l5, !tbaa !24
  %t50 = load i64, ptr %l9, !tbaa !24
  %t51 = load i64, ptr %l7, !tbaa !24
  %t54 = mul i64 %t50, %t51
  %t57 = add i64 %t49, %t54
  %t59 = load ptr, ptr %l3, !tbaa !29
  store ptr %t59, ptr %l41, !tbaa !29
  %t60 = load ptr, ptr %l4, !tbaa !29
  %t62 = getelementptr %"compiler/check:frame", ptr %t60, i32 0, i32 26
  %t66 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t62, i64 %t57)
  store i32 %t66, ptr %l45
  br label %bb13
bb13:
  %t67 = load ptr, ptr %l41, !tbaa !29
  %t68 = load i32, ptr %l45, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t67, i32 %t68)
  br label %bb14
bb14:
  br label %bb15
bb15:
  %t69 = load i64, ptr %l9, !tbaa !24
  %t71 = add i64 %t69, 1
  store i64 %t71, ptr %l9, !tbaa !24
  br label %bb9
bb16:
  %t73 = load ptr, ptr %l3, !tbaa !29
  %t75 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eToArray_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %v1, ptr %t73)
  store { i64, ptr } %t75, ptr %l49
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s0)
  %t76 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t76, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalNamed(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca i64
  %l4 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca i32
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %a0)
  store ptr %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l4, !tbaa !29
  %t6 = getelementptr %"compiler/check:frame", ptr %t4, i32 0, i32 8
  %t10 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %t6, i32 %a1)
  %t11 = extractvalue { i32, i64 } %t10, 1
  %t12 = extractvalue { i32, i64 } %t10, 0
  store i32 %t12, ptr %l9
  %t13 = icmp ne i32 %t12, 0
  br i1 %t13, label %bb3, label %ok.14, !prof !99
ok.14:
  store i64 %t11, ptr %l8
  br label %bb2
bb2:
  %t15 = load i64, ptr %l8, !tbaa !24
  store i64 %t15, ptr %l2, !tbaa !24
  br label %bb5
bb3:
  br label %bb4
bb4:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l2, !tbaa !24
  br label %bb5
bb5:
  %t16 = load i64, ptr %l2, !tbaa !24
  store i64 %t16, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalOrCapture(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i64
  %l7 = alloca i64
  %l12 = alloca i64
  %l15 = alloca i64
  %l18 = alloca ptr
  %l21 = alloca i64
  %l25 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalNamed(ptr %v0, ptr %t1, i32 %t2)
  store i64 %t5, ptr %l7
  br label %bb1
bb1:
  %t6 = load i64, ptr %l7, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t9 = icmp sge i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load i64, ptr %l3, !tbaa !24
  %t15 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewholeNarrowed(ptr %v0, ptr %t11, i64 %t12)
  store i64 %t15, ptr %l12
  br label %bb4
bb3:
  br label %bb8
bb4:
  %t16 = load i64, ptr %l12, !tbaa !24
  store i64 %t16, ptr %l4, !tbaa !24
  %t17 = load i64, ptr %l4, !tbaa !24
  %t19 = icmp sge i64 %t17, 0
  br i1 %t19, label %bb5, label %bb6
bb5:
  %t21 = load i64, ptr %l4, !tbaa !24
  store i64 %t21, ptr %l15, !tbaa !24
  br label %bb7
bb6:
  %t23 = load i64, ptr %l3, !tbaa !24
  store i64 %t23, ptr %l15, !tbaa !24
  br label %bb7
bb7:
  %t25 = load i64, ptr %l15, !tbaa !24
  store i64 %t25, ptr %rv
  br label %ret
bb8:
  %t26 = load ptr, ptr %l0, !tbaa !29
  store ptr %t26, ptr %l18, !tbaa !29
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/check:Checker", ptr %t27, i32 0, i32 16
  %t31 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_H2251bc8fca359ca0394d0bb11af7ba0a(ptr %v0, ptr %t29)
  store i64 %t31, ptr %l21
  br label %bb9
bb9:
  %t32 = load i64, ptr %l21, !tbaa !24
  %t33 = sub i64 %t32, 1
  %t34 = load i32, ptr %l1, !tbaa !23
  %t36 = load ptr, ptr %l18, !tbaa !29
  %t40 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaptureIn(ptr %v0, ptr %t36, i64 %t33, i32 %t34, %"compiler/source:Span" %a2)
  store i64 %t40, ptr %l25
  br label %bb10
bb10:
  %t41 = load i64, ptr %l25, !tbaa !24
  store i64 %t41, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eloneBinding(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l5 = alloca i1
  %l10 = alloca i1
  %l12 = alloca { i64, ptr }
  %l18 = alloca ptr
  %l21 = alloca ptr
  %l23 = alloca ptr
  %l27 = alloca { i64, ptr }
  %l30 = alloca %"compiler/names:Ref"
  %l32 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Catch", ptr %t1, i32 0, i32 5
  %t4 = load i32, ptr %t3, !tbaa !23
  %t6 = icmp ne i32 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l5, !tbaa !21
  br label %bb3
bb2:
  %t8 = load ptr, ptr %l1, !tbaa !29
  %t10 = getelementptr %"compiler/ast:Catch", ptr %t8, i32 0, i32 1
  %t11 = load { i64, ptr }, ptr %t10, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t15 = icmp ne i64 %t13, 1
  store i1 %t15, ptr %l5, !tbaa !21
  br label %bb3
bb3:
  %t17 = load i1, ptr %l5, !tbaa !21
  br i1 %t17, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb6
bb5:
  %t18 = load ptr, ptr %l1, !tbaa !29
  %t20 = getelementptr %"compiler/ast:Catch", ptr %t18, i32 0, i32 1
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !27
  store { i64, ptr } %t21, ptr %l12, !tbaa !27
  %t22 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = getelementptr ptr, ptr %t23, i64 0
  %t25 = load ptr, ptr %t24, !tbaa !39
  %t27 = getelementptr %"compiler/ast:Path", ptr %t25, i32 0, i32 1
  %t28 = load { i64, ptr }, ptr %t27, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t28, 0
  %t32 = icmp ne i64 %t30, 1
  store i1 %t32, ptr %l10, !tbaa !21
  br label %bb6
bb6:
  %t34 = load i1, ptr %l10, !tbaa !21
  br i1 %t34, label %bb7, label %bb8
bb7:
  store i1 false, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t36 = load ptr, ptr %l1, !tbaa !29
  store ptr %t36, ptr %l18, !tbaa !29
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/check:Checker", ptr %t37, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t42 = getelementptr %"compiler/generic:Program", ptr %t40, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !29
  store ptr %t43, ptr %l21, !tbaa !29
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t44)
  store ptr %t46, ptr %l23
  br label %bb10
bb10:
  %t47 = load ptr, ptr %l23, !tbaa !29
  %t49 = getelementptr %"compiler/check:frame", ptr %t47, i32 0, i32 2
  %t50 = load i64, ptr %t49, !tbaa !24
  %t51 = load ptr, ptr %l1, !tbaa !29
  %t53 = getelementptr %"compiler/ast:Catch", ptr %t51, i32 0, i32 1
  %t54 = load { i64, ptr }, ptr %t53, !tbaa !27
  store { i64, ptr } %t54, ptr %l27, !tbaa !27
  %t55 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !27
  %t57 = getelementptr ptr, ptr %t56, i64 0
  %t58 = load ptr, ptr %t57, !tbaa !39
  %t60 = getelementptr %"compiler/ast:Path", ptr %t58, i32 0, i32 0
  %t61 = getelementptr %"compiler/source:Span", ptr %t60, i32 0, i32 0
  %t62 = load i32, ptr %t61, !tbaa !23
  %t63 = load ptr, ptr %l21, !tbaa !29
  %t66 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t63, i64 %t50, i32 %t62)
  store %"compiler/names:Ref" %t66, ptr %l30
  br label %bb11
bb11:
  %t67 = getelementptr %"compiler/names:Ref", ptr %l30, i32 0, i32 0
  %t68 = load i32, ptr %t67, !range !{i32 0, i32 9}
  %t69 = load ptr, ptr %l18, !tbaa !29
  %t71 = call i1 @compiler_2fnames_2eLoneCatchName(ptr %v1, ptr %t69, i32 %t68)
  store i1 %t71, ptr %l32
  br label %bb12
bb12:
  %t72 = load i1, ptr %l32, !tbaa !21
  store i1 %t72, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emembership(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca %"compiler/generic:Binding"
  %l13 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca ptr
  %l27 = alloca i32
  %l28 = alloca i32
  %l36 = alloca ptr
  %l40 = alloca ptr
  %l43 = alloca i32
  %l47 = alloca i32
  %l52 = alloca i32
  %l57 = alloca ptr
  %l58 = alloca i32
  %l59 = alloca ptr
  %l61 = alloca %"compiler/source:Span"
  %l63 = alloca %"compiler/source:Span"
  %l64 = alloca %"compiler/source:Span"
  %l65 = alloca i64
  %l70 = alloca ptr
  %l73 = alloca ptr
  %l77 = alloca i32
  %l78 = alloca i32
  %l79 = alloca { i64, ptr }
  %l81 = alloca i64
  %l85 = alloca i64
  %l91 = alloca { i64, ptr }
  %l93 = alloca i32
  %l98 = alloca { i64, ptr }
  %l100 = alloca i32
  %l106 = alloca %"compiler/generic:Binding"
  %l107 = alloca ptr
  %l108 = alloca { i64, ptr }
  %l109 = alloca i32
  %l112 = alloca i32
  %l117 = alloca i32
  %l122 = alloca ptr
  %l125 = alloca ptr
  %l126 = alloca ptr
  %l129 = alloca i32
  %l130 = alloca i32
  %l132 = alloca i1
  %l133 = alloca { i64, ptr }
  %l134 = alloca ptr
  %l135 = alloca i32
  %l136 = alloca { i64, ptr }
  %l137 = alloca ptr
  %l139 = alloca %"compiler/source:Span"
  %l141 = alloca %"compiler/source:Span"
  %l142 = alloca %"compiler/source:Span"
  %l143 = alloca i64
  %l146 = alloca i1
  %l147 = alloca ptr
  %l148 = alloca i32
  %l149 = alloca { i64, ptr }
  %l150 = alloca ptr
  %l152 = alloca %"compiler/source:Span"
  %l154 = alloca %"compiler/source:Span"
  %l155 = alloca %"compiler/source:Span"
  %l156 = alloca i1
  %l160 = alloca ptr
  %l163 = alloca ptr
  %l164 = alloca ptr
  %l166 = alloca %"compiler/source:Span"
  %l168 = alloca %"compiler/source:Span"
  %l169 = alloca %"compiler/source:Span"
  %l170 = alloca i32
  %l173 = alloca { i64, ptr }
  %l174 = alloca { i64, ptr }
  %l177 = alloca { i64, ptr }
  %l179 = alloca %"compiler/msgs:Msg"
  %l180 = alloca i64
  %l184 = alloca ptr
  %l185 = alloca ptr
  %l186 = alloca ptr
  %l190 = alloca ptr
  %l193 = alloca { i64, ptr }
  %l194 = alloca ptr
  %l195 = alloca ptr
  %l197 = alloca %"compiler/source:Span"
  %l199 = alloca %"compiler/source:Span"
  %l200 = alloca %"compiler/source:Span"
  %l201 = alloca ptr
  %l202 = alloca %"compiler/source:Span"
  %l205 = alloca i32
  %l206 = alloca i64
  %l209 = alloca i64
  %l219 = alloca ptr
  %l220 = alloca %"compiler/source:Span"
  %l221 = alloca %"compiler/source:Span"
  %l222 = alloca i64
  %l224 = alloca ptr
  %l227 = alloca { i64, ptr }
  %l228 = alloca ptr
  %l232 = alloca ptr
  %l233 = alloca { i64, ptr }
  %l237 = alloca ptr
  %l238 = alloca %"compiler/source:Span"
  %l241 = alloca i32
  %l245 = alloca { i64, ptr }
  %l248 = alloca %"compiler/typed:Seq"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %rv = alloca ptr
  %t415 = alloca { i64, [3 x i64] }, align 8
  %t489 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t4 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t8 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v2, ptr %v3, ptr %t1, ptr %t2, i32 %t4)
  store ptr %t8, ptr %l23
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l23, !tbaa !29
  store ptr %t9, ptr %l4, !tbaa !29
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l24, !tbaa !29
  %t11 = load ptr, ptr %l4, !tbaa !29
  %t14 = call i32 @compiler_2fcheck_2etypeOf(ptr %v3, ptr %t11)
  store i32 %t14, ptr %l27
  br label %bb2
bb2:
  %t15 = load ptr, ptr %l24, !tbaa !29
  %t16 = load i32, ptr %l27, !tbaa !23
  %t17 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t15, i32 %t16)
  store i32 %t17, ptr %l28
  br label %bb3
bb3:
  %t18 = load i32, ptr %l28, !tbaa !23
  store i32 %t18, ptr %l5, !tbaa !23
  %t19 = load i32, ptr %l5, !tbaa !23
  %t20 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t23 = icmp eq i32 %t19, %t20
  br i1 %t23, label %bb4, label %bb5
bb4:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load ptr, ptr %l2, !tbaa !29
  %t28 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t32 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v0, ptr %t25, ptr %t26, i32 %t28)
  store ptr %t32, ptr %l36
  br label %bb6
bb5:
  br label %bb8
bb6:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load %"compiler/source:Span", ptr %l1
  %t35 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t39 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v3, ptr %t33, %"compiler/source:Span" %t34, i32 %t35, i64 0)
  store ptr %t39, ptr %l40
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s0)
  %t40 = load ptr, ptr %l40, !tbaa !29
  store ptr %t40, ptr %rv
  br label %ret
bb8:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load i32, ptr %l5, !tbaa !23
  %t45 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayOf(ptr %v0, ptr %t41, i32 %t42)
  store i32 %t45, ptr %l43
  br label %bb9
bb9:
  %t46 = load i32, ptr %l43, !tbaa !23
  store i32 %t46, ptr %l6, !tbaa !23
  %t47 = load i32, ptr %l6, !tbaa !23
  %t48 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t51 = icmp ne i32 %t47, %t48
  br i1 %t51, label %bb10, label %bb11
bb10:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/check:Checker", ptr %t53, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t58 = getelementptr %"compiler/generic:Program", ptr %t56, i32 0, i32 2
  %t59 = load i32, ptr %l6, !tbaa !23
  %t62 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t58, i32 %t59)
  store i32 %t62, ptr %l52
  br label %bb12
bb11:
  %t63 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t63, ptr %l47, !tbaa !23
  br label %bb13
bb12:
  %t65 = load i32, ptr %l52, !tbaa !23
  store i32 %t65, ptr %l47, !tbaa !23
  br label %bb13
bb13:
  %t66 = load i32, ptr %l47, !tbaa !23
  store i32 %t66, ptr %l7, !tbaa !23
  %t67 = load i32, ptr %l6, !tbaa !23
  %t68 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t71 = icmp eq i32 %t67, %t68
  br i1 %t71, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s2
  %t73 = load ptr, ptr %l0, !tbaa !29
  store ptr %t73, ptr %l57, !tbaa !29
  %t74 = load i32, ptr %l5, !tbaa !23
  store i32 %t74, ptr %l58, !tbaa !23
  %t75 = load ptr, ptr %l0, !tbaa !29
  store ptr %t75, ptr %l59, !tbaa !29
  %t76 = load ptr, ptr %l2, !tbaa !29
  %t78 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t76)
  store %"compiler/source:Span" %t78, ptr %l61
  br label %bb16
bb15:
  br label %bb43
bb16:
  %t79 = load ptr, ptr %l3, !tbaa !29
  %t81 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t79)
  store %"compiler/source:Span" %t81, ptr %l63
  br label %bb17
bb17:
  %t82 = load ptr, ptr %l59, !tbaa !29
  %t83 = load %"compiler/source:Span", ptr %l61
  %t84 = load %"compiler/source:Span", ptr %l63
  %t85 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebetween(ptr %v0, ptr %t82, %"compiler/source:Span" %t83, %"compiler/source:Span" %t84, i64 2)
  store %"compiler/source:Span" %t85, ptr %l64
  br label %bb18
bb18:
  %t86 = load ptr, ptr %l57, !tbaa !29
  %t87 = load i32, ptr %l58, !tbaa !23
  %t88 = load %"compiler/source:Span", ptr %l64
  %t89 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleUse(ptr %v0, ptr %s2, ptr %s2, ptr %t86, i32 %t87, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d31, i32 0, i32 1) }, i64 1, %"compiler/source:Span" %t88, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d32, i32 0, i32 1) })
  store i64 %t89, ptr %l65
  br label %bb19
bb19:
  %t90 = load i64, ptr %l65, !tbaa !24
  store i64 %t90, ptr %l8, !tbaa !24
  %t91 = load i64, ptr %l8, !tbaa !24
  %t93 = icmp sge i64 %t91, 0
  br i1 %t93, label %bb20, label %bb21
bb20:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr %"compiler/check:Checker", ptr %t95, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !29
  %t100 = getelementptr %"compiler/generic:Program", ptr %t98, i32 0, i32 2
  store ptr %t100, ptr %l70, !tbaa !29
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr %"compiler/check:Checker", ptr %t101, i32 0, i32 1
  %t104 = load ptr, ptr %t103, !tbaa !29
  %t106 = getelementptr %"compiler/generic:Program", ptr %t104, i32 0, i32 2
  store ptr %t106, ptr %l73, !tbaa !29
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = getelementptr %"compiler/check:Checker", ptr %t107, i32 0, i32 1
  %t110 = load ptr, ptr %t109, !tbaa !29
  %t111 = load i64, ptr %l8, !tbaa !24
  %t114 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t110, i64 %t111)
  store i32 %t114, ptr %l77
  br label %bb22
bb21:
  br label %bb42
bb22:
  %t115 = load ptr, ptr %l73, !tbaa !29
  %t116 = load i32, ptr %l77, !tbaa !23
  %t117 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t115, i32 %t116)
  store i32 %t117, ptr %l78
  br label %bb23
bb23:
  %t118 = load ptr, ptr %l70, !tbaa !29
  %t119 = load i32, ptr %l78, !tbaa !23
  %t120 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t118, i32 %t119)
  store { i64, ptr } %t120, ptr %l79
  br label %bb24
bb24:
  %t121 = load { i64, ptr }, ptr %l79, !tbaa !27
  store { i64, ptr } %t121, ptr %l9, !tbaa !27
  %t122 = load i64, ptr %l8, !tbaa !24
  %t124 = call i64 @compiler_2fgeneric_2eFnOwner(i64 %t122)
  store i64 %t124, ptr %l81
  br label %bb25
bb25:
  %t125 = load i64, ptr %l81, !tbaa !24
  store i64 %t125, ptr %l10, !tbaa !24
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t128 = getelementptr %"compiler/check:Checker", ptr %t126, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !29
  %t130 = load i64, ptr %l10, !tbaa !24
  %t133 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %t129, i64 %t130)
  store i64 %t133, ptr %l85
  br label %bb26
bb26:
  %t134 = load i64, ptr %l85, !tbaa !24
  store i64 %t134, ptr %l11, !tbaa !24
  %t135 = load i64, ptr %l11, !tbaa !24
  %t137 = icmp eq i64 %t135, 0
  br i1 %t137, label %bb27, label %bb28
bb27:
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t141 = getelementptr %"compiler/check:Checker", ptr %t139, i32 0, i32 1
  %t142 = load ptr, ptr %t141, !tbaa !29
  %t144 = getelementptr %"compiler/generic:Program", ptr %t142, i32 0, i32 2
  %t145 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t145, ptr %l91, !tbaa !27
  %t146 = getelementptr { i64, ptr }, ptr %l91, i32 0, i32 1
  %t147 = load ptr, ptr %t146, !tbaa !27
  %t148 = getelementptr i32, ptr %t147, i64 1
  %t149 = load i32, ptr %t148, !tbaa !33
  %t152 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t144, i32 %t149)
  store i32 %t152, ptr %l93
  br label %bb29
bb28:
  %t153 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t155 = extractvalue { i64, ptr } %t153, 0
  %t157 = icmp sgt i64 %t155, 1
  br i1 %t157, label %bb34, label %bb35
bb29:
  %t159 = load i32, ptr %l93, !range !{i32 0, i32 33}
  %t161 = trunc i64 25 to i32
  %t162 = icmp eq i32 %t159, %t161
  %t164 = xor i1 %t162, true
  br i1 %t164, label %bb30, label %bb31
bb30:
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t167 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t167, ptr %l98, !tbaa !27
  %t168 = getelementptr { i64, ptr }, ptr %l98, i32 0, i32 1
  %t169 = load ptr, ptr %t168, !tbaa !27
  %t170 = getelementptr i32, ptr %t169, i64 1
  %t171 = load i32, ptr %t170, !tbaa !33
  %t174 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t166, i32 %t171)
  store i32 %t174, ptr %l100
  br label %bb32
bb31:
  br label %bb33
bb32:
  %t175 = load i32, ptr %l100, !tbaa !23
  store i32 %t175, ptr %l7, !tbaa !23
  br label %bb33
bb33:
  br label %bb41
bb34:
  store %olang.scope zeroinitializer, ptr %s7
  %t176 = load i64, ptr %l10, !tbaa !24
  %t177 = load i64, ptr %l11, !tbaa !24
  %t180 = call %"compiler/generic:Binding" @compiler_2fgeneric_3aBinding_2ector(ptr %s7, i64 %t176, i64 %t177)
  store %"compiler/generic:Binding" %t180, ptr %l106
  br label %bb36
bb35:
  br label %bb40
bb36:
  %t181 = load %"compiler/generic:Binding", ptr %l106
  store %"compiler/generic:Binding" %t181, ptr %l12
  %t182 = load ptr, ptr %l0, !tbaa !29
  store ptr %t182, ptr %l107, !tbaa !29
  %t183 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t183, ptr %l108, !tbaa !27
  %t184 = getelementptr { i64, ptr }, ptr %l108, i32 0, i32 1
  %t185 = load ptr, ptr %t184, !tbaa !27
  %t186 = getelementptr i32, ptr %t185, i64 0
  %t187 = load i32, ptr %t186, !tbaa !33
  store i32 %t187, ptr %l109, !tbaa !23
  %t188 = load ptr, ptr %l4, !tbaa !29
  %t191 = call i32 @compiler_2fcheck_2etypeOf(ptr %v3, ptr %t188)
  store i32 %t191, ptr %l112
  br label %bb37
bb37:
  %t192 = load ptr, ptr %l107, !tbaa !29
  %t193 = load i32, ptr %l109, !tbaa !23
  %t194 = load i32, ptr %l112, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunify(ptr %v0, ptr %s7, ptr %t192, i32 %t193, i32 %t194, ptr %l12, i1 false, i1 true)
  br label %bb38
bb38:
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t197 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t201 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eboundParam(ptr %v0, ptr %v0, ptr %s7, ptr %t196, { i64, ptr } %t197, i64 1, ptr %l12)
  store i32 %t201, ptr %l117
  br label %bb39
bb39:
  %t202 = load i32, ptr %l117, !tbaa !23
  store i32 %t202, ptr %l7, !tbaa !23
  call void @__olang_scope_close(ptr %s7)
  br label %bb40
bb40:
  br label %bb41
bb41:
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s2)
  br label %bb43
bb43:
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t204 = load ptr, ptr %l2, !tbaa !29
  %t206 = load i32, ptr %l7, !tbaa !23
  %t210 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v3, ptr %t203, ptr %t204, i32 %t206)
  store ptr %t210, ptr %l122
  br label %bb44
bb44:
  %t211 = load ptr, ptr %l122, !tbaa !29
  store ptr %t211, ptr %l13, !tbaa !29
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t214 = getelementptr %"compiler/check:Checker", ptr %t212, i32 0, i32 1
  %t215 = load ptr, ptr %t214, !tbaa !29
  %t217 = getelementptr %"compiler/generic:Program", ptr %t215, i32 0, i32 2
  store ptr %t217, ptr %l125, !tbaa !29
  %t218 = load ptr, ptr %l0, !tbaa !29
  store ptr %t218, ptr %l126, !tbaa !29
  %t219 = load ptr, ptr %l13, !tbaa !29
  %t222 = call i32 @compiler_2fcheck_2etypeOf(ptr %v3, ptr %t219)
  store i32 %t222, ptr %l129
  br label %bb45
bb45:
  %t223 = load ptr, ptr %l126, !tbaa !29
  %t224 = load i32, ptr %l129, !tbaa !23
  %t225 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t223, i32 %t224)
  store i32 %t225, ptr %l130
  br label %bb46
bb46:
  %t226 = load i32, ptr %l5, !tbaa !23
  %t227 = load ptr, ptr %l125, !tbaa !29
  %t228 = load i32, ptr %l130, !tbaa !23
  %t230 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t227, i32 %t228, i32 %t226)
  store i1 %t230, ptr %l132
  br label %bb47
bb47:
  %t231 = load i1, ptr %l132, !tbaa !21
  br i1 %t231, label %bb48, label %bb49
bb48:
  store { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d33, i32 0, i32 1) }, ptr %l133, !tbaa !27
  br label %bb50
bb49:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d34, i32 0, i32 1) }, ptr %l133, !tbaa !27
  br label %bb50
bb50:
  %t232 = load { i64, ptr }, ptr %l133, !tbaa !27
  store { i64, ptr } %t232, ptr %l14, !tbaa !27
  %t233 = load ptr, ptr %l0, !tbaa !29
  store ptr %t233, ptr %l134, !tbaa !29
  %t234 = load i32, ptr %l5, !tbaa !23
  store i32 %t234, ptr %l135, !tbaa !23
  %t235 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t235, ptr %l136, !tbaa !27
  %t236 = load ptr, ptr %l0, !tbaa !29
  store ptr %t236, ptr %l137, !tbaa !29
  %t237 = load ptr, ptr %l2, !tbaa !29
  %t239 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t237)
  store %"compiler/source:Span" %t239, ptr %l139
  br label %bb51
bb51:
  %t240 = load ptr, ptr %l3, !tbaa !29
  %t242 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t240)
  store %"compiler/source:Span" %t242, ptr %l141
  br label %bb52
bb52:
  %t243 = load ptr, ptr %l137, !tbaa !29
  %t244 = load %"compiler/source:Span", ptr %l139
  %t245 = load %"compiler/source:Span", ptr %l141
  %t246 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebetween(ptr %v0, ptr %t243, %"compiler/source:Span" %t244, %"compiler/source:Span" %t245, i64 2)
  store %"compiler/source:Span" %t246, ptr %l142
  br label %bb53
bb53:
  %t247 = load ptr, ptr @__olang_prog_scope
  %t248 = load ptr, ptr %l134, !tbaa !29
  %t249 = load i32, ptr %l135, !tbaa !23
  %t250 = load { i64, ptr }, ptr %l136, !tbaa !27
  %t251 = load %"compiler/source:Span", ptr %l142
  %t252 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleUse(ptr %v0, ptr %t247, ptr %s0, ptr %t248, i32 %t249, { i64, ptr } %t250, i64 1, %"compiler/source:Span" %t251, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d35, i32 0, i32 1) })
  store i64 %t252, ptr %l143
  br label %bb54
bb54:
  %t253 = load i64, ptr %l143, !tbaa !24
  store i64 %t253, ptr %l15, !tbaa !24
  %t254 = load i64, ptr %l15, !tbaa !24
  %t256 = icmp slt i64 %t254, 0
  br i1 %t256, label %bb55, label %bb56
bb55:
  %t258 = load ptr, ptr %l0, !tbaa !29
  store ptr %t258, ptr %l147, !tbaa !29
  %t259 = load i32, ptr %l5, !tbaa !23
  store i32 %t259, ptr %l148, !tbaa !23
  %t260 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t260, ptr %l149, !tbaa !27
  %t261 = load ptr, ptr %l0, !tbaa !29
  store ptr %t261, ptr %l150, !tbaa !29
  %t262 = load ptr, ptr %l2, !tbaa !29
  %t264 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t262)
  store %"compiler/source:Span" %t264, ptr %l152
  br label %bb57
bb56:
  store i1 false, ptr %l146, !tbaa !21
  br label %bb61
bb57:
  %t265 = load ptr, ptr %l3, !tbaa !29
  %t267 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t265)
  store %"compiler/source:Span" %t267, ptr %l154
  br label %bb58
bb58:
  %t268 = load ptr, ptr %l150, !tbaa !29
  %t269 = load %"compiler/source:Span", ptr %l152
  %t270 = load %"compiler/source:Span", ptr %l154
  %t271 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebetween(ptr %v0, ptr %t268, %"compiler/source:Span" %t269, %"compiler/source:Span" %t270, i64 2)
  store %"compiler/source:Span" %t271, ptr %l155
  br label %bb59
bb59:
  %t272 = load ptr, ptr @__olang_prog_scope
  %t273 = load ptr, ptr %l147, !tbaa !29
  %t274 = load i32, ptr %l148, !tbaa !23
  %t275 = load { i64, ptr }, ptr %l149, !tbaa !27
  %t276 = load %"compiler/source:Span", ptr %l155
  %t277 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotOperator(ptr %v0, ptr %t272, ptr %s0, ptr %t273, i32 %t274, { i64, ptr } %t275, %"compiler/source:Span" %t276, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d36, i32 0, i32 1) }, i64 1, i1 false)
  store i1 %t277, ptr %l156
  br label %bb60
bb60:
  %t278 = load i1, ptr %l156, !tbaa !21
  store i1 %t278, ptr %l146, !tbaa !21
  br label %bb61
bb61:
  %t279 = load i1, ptr %l146, !tbaa !21
  br i1 %t279, label %bb62, label %bb63
bb62:
  %t280 = load ptr, ptr %l0, !tbaa !29
  %t281 = load %"compiler/source:Span", ptr %l1
  %t282 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t286 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v3, ptr %t280, %"compiler/source:Span" %t281, i32 %t282, i64 0)
  store ptr %t286, ptr %l160
  br label %bb64
bb63:
  br label %bb65
bb64:
  call void @__olang_scope_close(ptr %s0)
  %t287 = load ptr, ptr %l160, !tbaa !29
  store ptr %t287, ptr %rv
  br label %ret
bb65:
  %t288 = load i64, ptr %l15, !tbaa !24
  %t290 = icmp slt i64 %t288, 0
  br i1 %t290, label %bb66, label %bb67
bb66:
  store %olang.scope zeroinitializer, ptr %s9
  %t292 = load ptr, ptr %l0, !tbaa !29
  store ptr %t292, ptr %l163, !tbaa !29
  %t293 = load ptr, ptr %l0, !tbaa !29
  store ptr %t293, ptr %l164, !tbaa !29
  %t294 = load ptr, ptr %l2, !tbaa !29
  %t296 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t294)
  store %"compiler/source:Span" %t296, ptr %l166
  br label %bb68
bb67:
  br label %bb75
bb68:
  %t297 = load ptr, ptr %l3, !tbaa !29
  %t299 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t297)
  store %"compiler/source:Span" %t299, ptr %l168
  br label %bb69
bb69:
  %t300 = load ptr, ptr %l164, !tbaa !29
  %t301 = load %"compiler/source:Span", ptr %l166
  %t302 = load %"compiler/source:Span", ptr %l168
  %t303 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebetween(ptr %v0, ptr %t300, %"compiler/source:Span" %t301, %"compiler/source:Span" %t302, i64 2)
  store %"compiler/source:Span" %t303, ptr %l169
  br label %bb70
bb70:
  %t304 = load i32, ptr %l5, !tbaa !23
  store i32 %t304, ptr %l170, !tbaa !23
  %t305 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t307 = extractvalue { i64, ptr } %t305, 1
  %t308 = extractvalue { i64, ptr } %t305, 0
  %t309 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d37, i32 0, i32 1) }, 1
  %t310 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d37, i32 0, i32 1) }, 0
  %t311 = add i64 %t308, %t310
  %t312 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t311)
  call void @olang_textcopy(ptr %t312, ptr %t307, i64 %t308)
  %t313 = getelementptr i8, ptr %t312, i64 %t308
  call void @olang_textcopy(ptr %t313, ptr %t309, i64 %t310)
  %t314 = insertvalue { i64, ptr } undef, i64 %t311, 0
  %t315 = insertvalue { i64, ptr } %t314, ptr %t312, 1
  %t317 = extractvalue { i64, ptr } %t315, 0
  %t318 = extractvalue { i64, ptr } %t315, 1
  %t319 = mul i64 %t317, 1
  %t320 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t319)
  call void @llvm.memcpy.p0.p0.i64(ptr %t320, ptr %t318, i64 %t319, i1 false)
  %t321 = insertvalue { i64, ptr } undef, i64 %t317, 0
  %t322 = insertvalue { i64, ptr } %t321, ptr %t320, 1
  store { i64, ptr } %t322, ptr %l173, !tbaa !27
  %t323 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t323, ptr %l174, !tbaa !27
  %t324 = load ptr, ptr %l0, !tbaa !29
  %t325 = load i32, ptr %l5, !tbaa !23
  %t328 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s9, ptr %t324, i32 %t325)
  store { i64, ptr } %t328, ptr %l177
  br label %bb71
bb71:
  %t329 = load { i64, ptr }, ptr %l177, !tbaa !27
  %t330 = extractvalue { i64, ptr } %t329, 0
  %t331 = extractvalue { i64, ptr } %t329, 1
  %t332 = mul i64 %t330, 1
  %t333 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t332)
  call void @llvm.memcpy.p0.p0.i64(ptr %t333, ptr %t331, i64 %t332, i1 false)
  %t334 = insertvalue { i64, ptr } undef, i64 %t330, 0
  %t335 = insertvalue { i64, ptr } %t334, ptr %t333, 1
  %t336 = load ptr, ptr @__olang_prog_scope
  %t337 = load { i64, ptr }, ptr %l174, !tbaa !27
  %t339 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eMembershipNoMethod(ptr %t336, ptr %s9, ptr %s9, { i64, ptr } %t337, { i64, ptr } %t335)
  store %"compiler/msgs:Msg" %t339, ptr %l179
  br label %bb72
bb72:
  %t340 = load ptr, ptr %l163, !tbaa !29
  %t341 = load %"compiler/source:Span", ptr %l169
  %t342 = load i32, ptr %l170, !tbaa !23
  %t343 = load { i64, ptr }, ptr %l173, !tbaa !27
  %t344 = load %"compiler/msgs:Msg", ptr %l179
  %t345 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eneedErr(ptr %v0, ptr %s9, ptr %s9, ptr %t340, %"compiler/source:Span" %t341, i32 %t342, { i64, ptr } %t343, %"compiler/msgs:Msg" %t344)
  store i64 %t345, ptr %l180
  br label %bb73
bb73:
  %t346 = load ptr, ptr %l0, !tbaa !29
  %t347 = load %"compiler/source:Span", ptr %l1
  %t348 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t352 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v3, ptr %t346, %"compiler/source:Span" %t347, i32 %t348, i64 0)
  store ptr %t352, ptr %l184
  br label %bb74
bb74:
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s0)
  %t353 = load ptr, ptr %l184, !tbaa !29
  store ptr %t353, ptr %rv
  br label %ret
bb75:
  %t354 = load ptr, ptr %l0, !tbaa !29
  store ptr %t354, ptr %l185, !tbaa !29
  %t355 = load ptr, ptr %l0, !tbaa !29
  store ptr %t355, ptr %l186, !tbaa !29
  %t356 = load ptr, ptr %l0, !tbaa !29
  %t358 = getelementptr %"compiler/check:Checker", ptr %t356, i32 0, i32 1
  %t359 = load ptr, ptr %t358, !tbaa !29
  %t360 = load i64, ptr %l15, !tbaa !24
  %t363 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %s0, ptr %t359, i64 %t360)
  store ptr %t363, ptr %l190
  br label %bb76
bb76:
  %t364 = load ptr, ptr %l190, !tbaa !29
  %t366 = getelementptr %"compiler/ast:Func", ptr %t364, i32 0, i32 2
  %t367 = load i32, ptr %t366, !tbaa !23
  %t368 = load ptr, ptr %l186, !tbaa !29
  %t370 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t368, i32 %t367)
  store { i64, ptr } %t370, ptr %l193
  br label %bb77
bb77:
  %t371 = load { i64, ptr }, ptr %l193, !tbaa !27
  %t372 = load ptr, ptr %l185, !tbaa !29
  %t373 = getelementptr %"compiler/check:Checker", ptr %t372, i32 0, i32 50
  store { i64, ptr } %t371, ptr %t373, !tbaa !27
  %t374 = load ptr, ptr %l0, !tbaa !29
  store ptr %t374, ptr %l194, !tbaa !29
  %t375 = load ptr, ptr %l0, !tbaa !29
  store ptr %t375, ptr %l195, !tbaa !29
  %t376 = load ptr, ptr %l2, !tbaa !29
  %t378 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t376)
  store %"compiler/source:Span" %t378, ptr %l197
  br label %bb78
bb78:
  %t379 = load ptr, ptr %l3, !tbaa !29
  %t381 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t379)
  store %"compiler/source:Span" %t381, ptr %l199
  br label %bb79
bb79:
  %t382 = load ptr, ptr %l195, !tbaa !29
  %t383 = load %"compiler/source:Span", ptr %l197
  %t384 = load %"compiler/source:Span", ptr %l199
  %t385 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebetween(ptr %v0, ptr %t382, %"compiler/source:Span" %t383, %"compiler/source:Span" %t384, i64 2)
  store %"compiler/source:Span" %t385, ptr %l200
  br label %bb80
bb80:
  %t386 = load %"compiler/source:Span", ptr %l200
  %t387 = load ptr, ptr %l194, !tbaa !29
  %t388 = getelementptr %"compiler/check:Checker", ptr %t387, i32 0, i32 49
  store %"compiler/source:Span" %t386, ptr %t388
  %t389 = load ptr, ptr %l0, !tbaa !29
  store ptr %t389, ptr %l201, !tbaa !29
  %t390 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t390, ptr %l202
  %t391 = load ptr, ptr %l13, !tbaa !29
  %t394 = call i32 @compiler_2fcheck_2etypeOf(ptr %v3, ptr %t391)
  store i32 %t394, ptr %l205
  br label %bb81
bb81:
  %t395 = load ptr, ptr %l201, !tbaa !29
  %t396 = load %"compiler/source:Span", ptr %l202
  %t397 = load i32, ptr %l205, !tbaa !23
  %t398 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t395, %"compiler/source:Span" %t396, i32 %t397)
  store i64 %t398, ptr %l206
  br label %bb82
bb82:
  %t399 = load i64, ptr %l206, !tbaa !24
  store i64 %t399, ptr %l16, !tbaa !24
  %t400 = load ptr, ptr %l0, !tbaa !29
  %t402 = getelementptr %"compiler/check:Checker", ptr %t400, i32 0, i32 37
  %t404 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t402)
  store i64 %t404, ptr %l209
  br label %bb83
bb83:
  %t405 = load i64, ptr %l209, !tbaa !24
  store i64 %t405, ptr %l17, !tbaa !24
  %t406 = load ptr, ptr %l0, !tbaa !29
  %t408 = getelementptr %"compiler/check:Checker", ptr %t406, i32 0, i32 37
  %t409 = load %"compiler/source:Span", ptr %l1
  %t410 = load i64, ptr %l16, !tbaa !24
  %t412 = trunc i64 %t410 to i32
  %t414 = load ptr, ptr %l13, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t415
  %t416 = getelementptr { i64, [3 x i64] }, ptr %t415, i32 0, i32 0
  store i64 0, ptr %t416
  %t418 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t409, 0
  %t420 = insertvalue { %"compiler/source:Span", i32, ptr } %t418, i32 %t412, 1
  %t422 = insertvalue { %"compiler/source:Span", i32, ptr } %t420, ptr %t414, 2
  %t423 = getelementptr { i64, [3 x i64] }, ptr %t415, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t422, ptr %t423
  %t424 = load { i64, [3 x i64] }, ptr %t415
  %t426 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t424, ptr %t426
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t408, ptr %t426)
  br label %bb84
bb84:
  %t429 = load ptr, ptr %l0, !tbaa !29
  store ptr %t429, ptr %l219, !tbaa !29
  %t430 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t430, ptr %l220
  %t431 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t431, ptr %l221
  %t432 = load i64, ptr %l15, !tbaa !24
  store i64 %t432, ptr %l222, !tbaa !24
  %t433 = load ptr, ptr %l4, !tbaa !29
  store ptr %t433, ptr %l224, !tbaa !29
  %t435 = icmp sge i64 0, 0
  br i1 %t435, label %bb85, label %bb86
bb85:
  %t437 = icmp sle i64 0, 1152921504606846975
  br i1 %t437, label %bb87, label %bb88
bb86:
  call void @__olang_check_failed(ptr @olang_loc_1fa90a145069ae20_a62c963c9e2d6294)
  unreachable
bb87:
  %t439 = mul i64 0, 8
  %t440 = insertvalue { i64, ptr } undef, i64 0, 0
  %t441 = insertvalue { i64, ptr } %t440, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t441, ptr %l227, !tbaa !27
  %t442 = load ptr, ptr %l0, !tbaa !29
  store ptr %t442, ptr %l228, !tbaa !29
  %t443 = load ptr, ptr %l0, !tbaa !29
  %t444 = load %"compiler/source:Span", ptr %l1
  %t445 = load i64, ptr %l16, !tbaa !24
  %t449 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t443, %"compiler/source:Span" %t444, i64 %t445)
  store ptr %t449, ptr %l232
  br label %bb89
bb88:
  call void @__olang_check_failed(ptr @olang_loc_1fa90a145069ae20_a62c963c9e2d6294)
  unreachable
bb89:
  %t450 = load ptr, ptr %l228, !tbaa !29
  %t451 = load ptr, ptr %l232, !tbaa !29
  %t452 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eone(ptr %v0, ptr %v0, ptr %v0, ptr %t450, ptr %t451)
  store { i64, ptr } %t452, ptr %l233
  br label %bb90
bb90:
  %t453 = icmp sge i64 0, 0
  br i1 %t453, label %bb91, label %bb92
bb91:
  %t455 = icmp sle i64 0, 2305843009213693951
  br i1 %t455, label %bb93, label %bb94
bb92:
  call void @__olang_check_failed(ptr @olang_loc_e5386246bf71864d_e9422de20f0d1fa1)
  unreachable
bb93:
  %t457 = mul i64 0, 4
  %t458 = insertvalue { i64, ptr } undef, i64 0, 0
  %t459 = insertvalue { i64, ptr } %t458, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t460 = load ptr, ptr %l219, !tbaa !29
  %t461 = load %"compiler/source:Span", ptr %l220
  %t462 = load %"compiler/source:Span", ptr %l221
  %t463 = load i64, ptr %l222, !tbaa !24
  %t464 = load ptr, ptr %l224, !tbaa !29
  %t465 = load { i64, ptr }, ptr %l227, !tbaa !27
  %t466 = load { i64, ptr }, ptr %l233, !tbaa !27
  %t468 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v3, ptr %v0, ptr %v0, ptr %v3, ptr %v3, ptr %t460, %"compiler/source:Span" %t461, %"compiler/source:Span" %t462, i64 %t463, ptr %t464, { i64, ptr } %t465, { i64, ptr } %t466, { i64, ptr } %t459)
  store ptr %t468, ptr %l237
  br label %bb95
bb94:
  call void @__olang_check_failed(ptr @olang_loc_e5386246bf71864d_e9422de20f0d1fa1)
  unreachable
bb95:
  %t469 = load ptr, ptr %l237, !tbaa !29
  store ptr %t469, ptr %l18, !tbaa !29
  %t470 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t470, ptr %l238
  %t471 = load ptr, ptr %l18, !tbaa !29
  %t474 = call i32 @compiler_2fcheck_2etypeOf(ptr %v3, ptr %t471)
  store i32 %t474, ptr %l241
  br label %bb96
bb96:
  %t475 = load ptr, ptr %l0, !tbaa !29
  %t477 = getelementptr %"compiler/check:Checker", ptr %t475, i32 0, i32 37
  %t478 = load i64, ptr %l17, !tbaa !24
  %t481 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t477, i64 %t478)
  store { i64, ptr } %t481, ptr %l245
  br label %bb97
bb97:
  %t482 = load ptr, ptr %l18, !tbaa !29
  %t484 = load { i64, ptr }, ptr %l245, !tbaa !27
  %t486 = call %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v3, ptr %v3, { i64, ptr } %t484, ptr %t482)
  store %"compiler/typed:Seq" %t486, ptr %l248
  br label %bb98
bb98:
  %t487 = load %"compiler/typed:Seq", ptr %l248
  %t488 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 24, i64 8)
  store %"compiler/typed:Seq" %t487, ptr %t488
  store { i64, [5 x i64] } zeroinitializer, ptr %t489
  %t490 = getelementptr { i64, [5 x i64] }, ptr %t489, i32 0, i32 0
  store i64 12, ptr %t490
  %t491 = load %"compiler/source:Span", ptr %l238
  %t492 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t491, 0
  %t493 = load i32, ptr %l241, !tbaa !23
  %t494 = insertvalue { %"compiler/source:Span", i32, ptr } %t492, i32 %t493, 1
  %t496 = insertvalue { %"compiler/source:Span", i32, ptr } %t494, ptr %t488, 2
  %t497 = getelementptr { i64, [5 x i64] }, ptr %t489, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t496, ptr %t497
  %t498 = load { i64, [5 x i64] }, ptr %t489
  %t500 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 48, i64 8)
  store { i64, [5 x i64] } %t498, ptr %t500
  call void @__olang_scope_close(ptr %s0)
  store ptr %t500, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emethodCall(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3, %"compiler/source:Span" %a4, { i64, ptr } %a5, { i64, ptr } %a6, %"compiler/source:Span" %a7) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l8 = alloca i1
  %l9 = alloca ptr
  %l10 = alloca i32
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca i1
  %l17 = alloca i64
  %l18 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l19 = alloca ptr
  %l20 = alloca i32
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l26 = alloca i1
  %l29 = alloca { i64, ptr }
  %l32 = alloca i1
  %l39 = alloca ptr
  %l42 = alloca i32
  %l50 = alloca ptr
  %l52 = alloca i1
  %l55 = alloca i64
  %l57 = alloca i1
  %l60 = alloca i1
  %l63 = alloca { i64, ptr }
  %l66 = alloca i64
  %l68 = alloca i1
  %l70 = alloca ptr
  %l73 = alloca i32
  %l75 = alloca i64
  %l77 = alloca i1
  %l79 = alloca i1
  %l80 = alloca i1
  %l82 = alloca i1
  %l89 = alloca ptr
  %l94 = alloca ptr
  %l97 = alloca i32
  %l99 = alloca i64
  %l103 = alloca ptr
  %l106 = alloca i32
  %l108 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l110 = alloca i64
  %l113 = alloca i64
  %l116 = alloca i1
  %l119 = alloca { i64, ptr }
  %l120 = alloca i1
  %l121 = alloca i1
  %l122 = alloca ptr
  %l125 = alloca i32
  %l126 = alloca i1
  %l133 = alloca ptr
  %l136 = alloca i1
  %l139 = alloca ptr
  %l142 = alloca i32
  %l143 = alloca i32
  %l146 = alloca ptr
  %l147 = alloca { i64, ptr }
  %l149 = alloca %"compiler/source:Span"
  %l152 = alloca { i64, ptr }
  %l154 = alloca %"compiler/msgs:Msg"
  %l155 = alloca i64
  %l160 = alloca ptr
  %l165 = alloca { i64, ptr }
  %l173 = alloca ptr
  %l176 = alloca { i64, ptr }
  %l177 = alloca { i64, ptr }
  %l179 = alloca i1
  %l181 = alloca i1
  %l185 = alloca i64
  %l187 = alloca ptr
  %l191 = alloca ptr
  %l192 = alloca %"compiler/source:Span"
  %l195 = alloca { i64, ptr }
  %l197 = alloca %"compiler/msgs:Msg"
  %l198 = alloca i64
  %l199 = alloca ptr
  %l200 = alloca %"compiler/source:Span"
  %l201 = alloca %"compiler/source:Span"
  %l202 = alloca i64
  %l204 = alloca ptr
  %l205 = alloca { i64, ptr }
  %l210 = alloca ptr
  %l213 = alloca { i64, ptr }
  %l215 = alloca i1
  %l216 = alloca i1
  %l220 = alloca i1
  %l224 = alloca ptr
  %l226 = alloca ptr
  %l229 = alloca ptr
  %l234 = alloca ptr
  %l237 = alloca i32
  %l238 = alloca i32
  %l241 = alloca i1
  %l251 = alloca ptr
  %l253 = alloca ptr
  %l256 = alloca i32
  %l258 = alloca i64
  %l262 = alloca ptr
  %l265 = alloca i32
  %l267 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l269 = alloca i64
  %l271 = alloca ptr
  %l272 = alloca %"compiler/source:Span"
  %l273 = alloca ptr
  %l276 = alloca i32
  %l277 = alloca { i64, ptr }
  %l278 = alloca { i64, ptr }
  %l281 = alloca { i64, ptr }
  %l283 = alloca %"compiler/msgs:Msg"
  %l284 = alloca i64
  %l289 = alloca ptr
  %l291 = alloca i64
  %l294 = alloca i64
  %l297 = alloca i1
  %l300 = alloca i1
  %l301 = alloca i1
  %l306 = alloca i1
  %l307 = alloca i1
  %l310 = alloca ptr
  %l312 = alloca %"compiler/source:Span"
  %l313 = alloca ptr
  %l315 = alloca %"compiler/source:Span"
  %l316 = alloca { i64, ptr }
  %l319 = alloca { i64, ptr }
  %l320 = alloca { i64, ptr }
  %l321 = alloca ptr
  %l323 = alloca %"compiler/source:Span"
  %l324 = alloca { i64, ptr }
  %l325 = alloca { i64, ptr }
  %l327 = alloca %"compiler/msgs:Msg"
  %l328 = alloca i64
  %l333 = alloca i32
  %l336 = alloca i1
  %l338 = alloca i1
  %l339 = alloca i1
  %l343 = alloca i1
  %l346 = alloca i32
  %l349 = alloca ptr
  %l350 = alloca %"compiler/source:Span"
  %l352 = alloca i32
  %l355 = alloca ptr
  %l358 = alloca i1
  %l361 = alloca i32
  %l364 = alloca i1
  %l365 = alloca ptr
  %l368 = alloca i32
  %l369 = alloca i1
  %l374 = alloca ptr
  %l377 = alloca i1
  %l379 = alloca i1
  %l381 = alloca i1
  %l382 = alloca ptr
  %l385 = alloca i32
  %l386 = alloca i1
  %l387 = alloca i1
  %l388 = alloca ptr
  %l391 = alloca i32
  %l392 = alloca i1
  %l393 = alloca i1
  %l395 = alloca ptr
  %l398 = alloca i32
  %l399 = alloca i1
  %l401 = alloca i1
  %l402 = alloca ptr
  %l405 = alloca i32
  %l407 = alloca i1
  %l408 = alloca ptr
  %l409 = alloca %"compiler/source:Span"
  %l410 = alloca ptr
  %l413 = alloca i32
  %l414 = alloca { i64, ptr }
  %l415 = alloca { i64, ptr }
  %l418 = alloca { i64, ptr }
  %l420 = alloca %"compiler/msgs:Msg"
  %l421 = alloca i64
  %l426 = alloca ptr
  %l436 = alloca ptr
  %l443 = alloca i32
  %l446 = alloca i1
  %l447 = alloca i1
  %l451 = alloca i64
  %l454 = alloca ptr
  %l458 = alloca %"compiler/source:Span"
  %l459 = alloca i32
  %l460 = alloca ptr
  %l461 = alloca ptr
  %l462 = alloca i32
  %l464 = alloca %"compiler/source:Span"
  %l465 = alloca i32
  %l468 = alloca ptr
  %l469 = alloca %"compiler/source:Span"
  %l470 = alloca %"compiler/source:Span"
  %l475 = alloca ptr
  %l479 = alloca ptr
  %l480 = alloca %"compiler/source:Span"
  %l481 = alloca %"compiler/source:Span"
  %l485 = alloca ptr
  %l487 = alloca ptr
  %l490 = alloca i1
  %l491 = alloca i1
  %l494 = alloca i32
  %l501 = alloca ptr
  %l503 = alloca i1
  %l504 = alloca i1
  %l506 = alloca i1
  %l509 = alloca i32
  %l511 = alloca i32
  %l513 = alloca i1
  %l515 = alloca i1
  %l516 = alloca i1
  %l518 = alloca i1
  %l519 = alloca ptr
  %l520 = alloca %"compiler/source:Span"
  %l523 = alloca { i64, ptr }
  %l526 = alloca %"compiler/msgs:Msg"
  %l527 = alloca i64
  %l528 = alloca ptr
  %l529 = alloca %"compiler/source:Span"
  %l530 = alloca i32
  %l533 = alloca { i64, ptr }
  %l535 = alloca { i64, ptr }
  %l538 = alloca { i64, ptr }
  %l539 = alloca { i64, ptr }
  %l542 = alloca { i64, ptr }
  %l543 = alloca { i64, ptr }
  %l547 = alloca { i64, ptr }
  %l549 = alloca %"compiler/msgs:Msg"
  %l550 = alloca i64
  %l555 = alloca ptr
  %l556 = alloca { i64, ptr }
  %l558 = alloca i1
  %l560 = alloca i1
  %l564 = alloca i64
  %l566 = alloca ptr
  %l570 = alloca ptr
  %l571 = alloca %"compiler/source:Span"
  %l574 = alloca { i64, ptr }
  %l576 = alloca %"compiler/msgs:Msg"
  %l577 = alloca i64
  %l578 = alloca ptr
  %l579 = alloca %"compiler/source:Span"
  %l580 = alloca ptr
  %l581 = alloca %"compiler/source:Span"
  %l582 = alloca %"compiler/source:Span"
  %l583 = alloca i64
  %l585 = alloca ptr
  %l586 = alloca { i64, ptr }
  %l589 = alloca { i64, ptr }
  %l593 = alloca ptr
  %l594 = alloca ptr
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %s30 = alloca %olang.scope
  %rv = alloca ptr
  %t900 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i32 %a3, ptr %l3
  store %"compiler/source:Span" %a4, ptr %l4
  store { i64, ptr } %a5, ptr %l5
  store { i64, ptr } %a6, ptr %l6
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l3, !tbaa !23
  %t11 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t7, i32 %t8)
  store { i64, ptr } %t11, ptr %l29
  br label %bb3
bb2:
  store i1 false, ptr %l26, !tbaa !21
  br label %bb5
bb3:
  %t12 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t12, 0
  %t15 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t17 = call i1 @compiler_2fcheck_2elaneMethodName(ptr %v0, { i64, ptr } %t15, i64 %t14)
  store i1 %t17, ptr %l32
  br label %bb4
bb4:
  %t18 = load i1, ptr %l32, !tbaa !21
  store i1 %t18, ptr %l26, !tbaa !21
  br label %bb5
bb5:
  %t19 = load i1, ptr %l26, !tbaa !21
  store i1 %t19, ptr %l8, !tbaa !21
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load i1, ptr %l8, !tbaa !21
  %t24 = getelementptr %"compiler/check:Checker", ptr %t20, i32 0, i32 40
  store i1 %t21, ptr %t24, !tbaa !21
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load ptr, ptr %l2, !tbaa !29
  %t28 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t32 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v4, ptr %t25, ptr %t26, i32 %t28)
  store ptr %t32, ptr %l39
  br label %bb6
bb6:
  %t33 = load ptr, ptr %l39, !tbaa !29
  store ptr %t33, ptr %l9, !tbaa !29
  %t34 = load ptr, ptr %l9, !tbaa !29
  %t37 = call i32 @compiler_2fcheck_2etypeOf(ptr %v4, ptr %t34)
  store i32 %t37, ptr %l42
  br label %bb7
bb7:
  %t38 = load i32, ptr %l42, !tbaa !23
  store i32 %t38, ptr %l10, !tbaa !23
  %t39 = load i32, ptr %l10, !tbaa !23
  %t40 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t43 = icmp eq i32 %t39, %t40
  br i1 %t43, label %bb8, label %bb9
bb8:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t46 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v2, ptr %t45, { i64, ptr } %t46)
  br label %bb10
bb9:
  br label %bb12
bb10:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load %"compiler/source:Span", ptr %l1
  %t53 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v4, ptr %t49, %"compiler/source:Span" %t50)
  store ptr %t53, ptr %l50
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s0)
  %t54 = load ptr, ptr %l50, !tbaa !29
  store ptr %t54, ptr %rv
  br label %ret
bb12:
  %t55 = load i1, ptr %l8, !tbaa !21
  br i1 %t55, label %bb13, label %bb14
bb13:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t58 = load ptr, ptr %l9, !tbaa !29
  %t61 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneOf(ptr %v0, ptr %v4, ptr %t57, ptr %t58)
  store i64 %t61, ptr %l55
  br label %bb15
bb14:
  store i1 false, ptr %l52, !tbaa !21
  br label %bb20
bb15:
  %t62 = load i64, ptr %l55, !tbaa !24
  %t63 = icmp sge i64 %t62, 0
  br i1 %t63, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l57, !tbaa !21
  br label %bb19
bb17:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load i32, ptr %l10, !tbaa !23
  %t69 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneArray(ptr %v0, ptr %t65, i32 %t66)
  store i1 %t69, ptr %l60
  br label %bb18
bb18:
  %t70 = load i1, ptr %l60, !tbaa !21
  store i1 %t70, ptr %l57, !tbaa !21
  br label %bb19
bb19:
  %t71 = load i1, ptr %l57, !tbaa !21
  store i1 %t71, ptr %l52, !tbaa !21
  br label %bb20
bb20:
  %t72 = load i1, ptr %l52, !tbaa !21
  br i1 %t72, label %bb21, label %bb22
bb21:
  store %olang.scope zeroinitializer, ptr %s2
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t74 = load i32, ptr %l3, !tbaa !23
  %t77 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v4, ptr %t73, i32 %t74)
  store { i64, ptr } %t77, ptr %l63
  br label %bb23
bb22:
  br label %bb42
bb23:
  %t78 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t78, ptr %l11, !tbaa !27
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t80 = load ptr, ptr %l9, !tbaa !29
  %t83 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneOf(ptr %v0, ptr %v4, ptr %t79, ptr %t80)
  store i64 %t83, ptr %l66
  br label %bb24
bb24:
  %t84 = load i64, ptr %l66, !tbaa !24
  %t85 = icmp sge i64 %t84, 0
  br i1 %t85, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l68, !tbaa !21
  br label %bb29
bb26:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/check:Checker", ptr %t87, i32 0, i32 1
  %t90 = load ptr, ptr %t89, !tbaa !29
  store ptr %t90, ptr %l70, !tbaa !29
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load i32, ptr %l10, !tbaa !23
  %t95 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t91, i32 %t92)
  store i32 %t95, ptr %l73
  br label %bb27
bb27:
  %t96 = load i32, ptr %l3, !tbaa !23
  %t97 = load ptr, ptr %l70, !tbaa !29
  %t98 = load i32, ptr %l73, !tbaa !23
  %t100 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t97, i32 %t98, i32 %t96)
  store i64 %t100, ptr %l75
  br label %bb28
bb28:
  %t101 = load i64, ptr %l75, !tbaa !24
  %t102 = icmp slt i64 %t101, 0
  store i1 %t102, ptr %l68, !tbaa !21
  br label %bb29
bb29:
  %t104 = load i1, ptr %l68, !tbaa !21
  br i1 %t104, label %bb30, label %bb31
bb30:
  store i1 true, ptr %l77, !tbaa !21
  br label %bb33
bb31:
  %t105 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t107 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v4, ptr %s2, { i64, ptr } %t105, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d38, i32 0, i32 1) })
  store i1 %t107, ptr %l79
  br label %bb32
bb32:
  %t108 = load i1, ptr %l79, !tbaa !21
  store i1 %t108, ptr %l77, !tbaa !21
  br label %bb33
bb33:
  %t109 = load i1, ptr %l77, !tbaa !21
  br i1 %t109, label %bb34, label %bb35
bb34:
  store i1 true, ptr %l80, !tbaa !21
  br label %bb37
bb35:
  %t110 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t112 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v4, ptr %s2, { i64, ptr } %t110, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d39, i32 0, i32 1) })
  store i1 %t112, ptr %l82
  br label %bb36
bb36:
  %t113 = load i1, ptr %l82, !tbaa !21
  store i1 %t113, ptr %l80, !tbaa !21
  br label %bb37
bb37:
  %t114 = load i1, ptr %l80, !tbaa !21
  br i1 %t114, label %bb38, label %bb39
bb38:
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t116 = load %"compiler/source:Span", ptr %l1
  %t117 = load %"compiler/source:Span", ptr %l4
  %t118 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t119 = load ptr, ptr %l9, !tbaa !29
  %t120 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t127 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneMethod(ptr %v0, ptr %v4, ptr %v4, ptr %v2, ptr %v4, ptr %t115, %"compiler/source:Span" %t116, %"compiler/source:Span" %t117, { i64, ptr } %t118, ptr %t119, { i64, ptr } %t120)
  store ptr %t127, ptr %l89
  br label %bb40
bb39:
  br label %bb41
bb40:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t128 = load ptr, ptr %l89, !tbaa !29
  store ptr %t128, ptr %rv
  br label %ret
bb41:
  call void @__olang_scope_close(ptr %s2)
  br label %bb42
bb42:
  %t129 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t131 = extractvalue { i64, ptr } %t129, 0
  %t133 = icmp sgt i64 %t131, 0
  br i1 %t133, label %bb43, label %bb44
bb43:
  store %olang.scope zeroinitializer, ptr %s4
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t137 = getelementptr %"compiler/check:Checker", ptr %t135, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !29
  store ptr %t138, ptr %l94, !tbaa !29
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t140 = load i32, ptr %l10, !tbaa !23
  %t143 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t139, i32 %t140)
  store i32 %t143, ptr %l97
  br label %bb45
bb44:
  br label %bb109
bb45:
  %t144 = load i32, ptr %l3, !tbaa !23
  %t145 = load ptr, ptr %l94, !tbaa !29
  %t146 = load i32, ptr %l97, !tbaa !23
  %t148 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t145, i32 %t146, i32 %t144)
  store i64 %t148, ptr %l99
  br label %bb46
bb46:
  %t149 = load i64, ptr %l99, !tbaa !24
  store i64 %t149, ptr %l12, !tbaa !24
  %t150 = load i64, ptr %l12, !tbaa !24
  %t152 = icmp slt i64 %t150, 0
  br i1 %t152, label %bb47, label %bb48
bb47:
  store %olang.scope zeroinitializer, ptr %s5
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t156 = getelementptr %"compiler/check:Checker", ptr %t154, i32 0, i32 1
  %t157 = load ptr, ptr %t156, !tbaa !29
  store ptr %t157, ptr %l103, !tbaa !29
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t159 = load i32, ptr %l10, !tbaa !23
  %t162 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t158, i32 %t159)
  store i32 %t162, ptr %l106
  br label %bb49
bb48:
  br label %bb56
bb49:
  %t163 = load i32, ptr %l3, !tbaa !23
  %t164 = load ptr, ptr %l103, !tbaa !29
  %t165 = load i32, ptr %l106, !tbaa !23
  %t167 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDefaultMethods(ptr %v0, ptr %s5, ptr %t164, i32 %t165, i32 %t163)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t167, ptr %l108
  br label %bb50
bb50:
  %t168 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l108
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t168, ptr %l13
  %t170 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s5, ptr %l13)
  store i64 %t170, ptr %l110
  br label %bb51
bb51:
  %t171 = load i64, ptr %l110, !tbaa !24
  %t172 = icmp eq i64 %t171, 1
  br i1 %t172, label %bb52, label %bb53
bb52:
  %t175 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s5, ptr %l13, i64 0)
  store i64 %t175, ptr %l113
  br label %bb54
bb53:
  br label %bb55
bb54:
  %t176 = load i64, ptr %l113, !tbaa !24
  store i64 %t176, ptr %l12, !tbaa !24
  br label %bb55
bb55:
  call void @__olang_scope_close(ptr %s5)
  br label %bb56
bb56:
  %t177 = load i64, ptr %l12, !tbaa !24
  %t179 = icmp slt i64 %t177, 0
  br i1 %t179, label %bb57, label %bb58
bb57:
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t182 = load i32, ptr %l3, !tbaa !23
  %t185 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t181, i32 %t182)
  store { i64, ptr } %t185, ptr %l119
  br label %bb59
bb58:
  store i1 false, ptr %l116, !tbaa !21
  br label %bb61
bb59:
  %t186 = load { i64, ptr }, ptr %l119, !tbaa !27
  %t187 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s4, { i64, ptr } %t186, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d40, i32 0, i32 1) })
  store i1 %t187, ptr %l120
  br label %bb60
bb60:
  %t188 = load i1, ptr %l120, !tbaa !21
  store i1 %t188, ptr %l116, !tbaa !21
  br label %bb61
bb61:
  %t189 = load i1, ptr %l116, !tbaa !21
  br i1 %t189, label %bb62, label %bb63
bb62:
  %t190 = load ptr, ptr %l0, !tbaa !29
  store ptr %t190, ptr %l122, !tbaa !29
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t192 = load i32, ptr %l10, !tbaa !23
  %t195 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t191, i32 %t192)
  store i32 %t195, ptr %l125
  br label %bb64
bb63:
  store i1 false, ptr %l121, !tbaa !21
  br label %bb66
bb64:
  %t196 = load ptr, ptr %l122, !tbaa !29
  %t197 = load i32, ptr %l125, !tbaa !23
  %t198 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t196, i32 %t197)
  store i1 %t198, ptr %l126
  br label %bb65
bb65:
  %t199 = load i1, ptr %l126, !tbaa !21
  store i1 %t199, ptr %l121, !tbaa !21
  br label %bb66
bb66:
  %t200 = load i1, ptr %l121, !tbaa !21
  br i1 %t200, label %bb67, label %bb68
bb67:
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t202 = load %"compiler/source:Span", ptr %l1
  %t203 = load %"compiler/source:Span", ptr %l4
  %t204 = load ptr, ptr %l9, !tbaa !29
  %t205 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t206 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t213 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrowCall(ptr %v0, ptr %v4, ptr %v3, ptr %v2, ptr %v4, ptr %t201, %"compiler/source:Span" %t202, %"compiler/source:Span" %t203, ptr %t204, { i64, ptr } %t205, { i64, ptr } %t206)
  store ptr %t213, ptr %l133
  br label %bb69
bb68:
  br label %bb70
bb69:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t214 = load ptr, ptr %l133, !tbaa !29
  store ptr %t214, ptr %rv
  br label %ret
bb70:
  %t215 = load i64, ptr %l12, !tbaa !24
  %t217 = icmp slt i64 %t215, 0
  br i1 %t217, label %bb71, label %bb72
bb71:
  store i1 true, ptr %l136, !tbaa !21
  br label %bb75
bb72:
  %t219 = load ptr, ptr %l0, !tbaa !29
  %t221 = getelementptr %"compiler/check:Checker", ptr %t219, i32 0, i32 1
  %t222 = load ptr, ptr %t221, !tbaa !29
  %t224 = getelementptr %"compiler/generic:Program", ptr %t222, i32 0, i32 2
  store ptr %t224, ptr %l139, !tbaa !29
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t226 = load i32, ptr %l10, !tbaa !23
  %t229 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t225, i32 %t226)
  store i32 %t229, ptr %l142
  br label %bb73
bb73:
  %t230 = load ptr, ptr %l139, !tbaa !29
  %t231 = load i32, ptr %l142, !tbaa !23
  %t232 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t230, i32 %t231)
  store i32 %t232, ptr %l143
  br label %bb74
bb74:
  %t233 = load i32, ptr %l143, !range !{i32 0, i32 33}
  %t235 = trunc i64 29 to i32
  %t236 = icmp eq i32 %t233, %t235
  store i1 %t236, ptr %l136, !tbaa !21
  br label %bb75
bb75:
  %t238 = load i1, ptr %l136, !tbaa !21
  br i1 %t238, label %bb76, label %bb77
bb76:
  store %olang.scope zeroinitializer, ptr %s8
  %t239 = load ptr, ptr %l0, !tbaa !29
  store ptr %t239, ptr %l146, !tbaa !29
  %t240 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t240, ptr %l147, !tbaa !27
  %t241 = getelementptr { i64, ptr }, ptr %l147, i32 0, i32 1
  %t242 = load ptr, ptr %t241, !tbaa !27
  %t243 = getelementptr ptr, ptr %t242, i64 0
  %t244 = load ptr, ptr %t243, !tbaa !39
  %t246 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v3, ptr %t244)
  store %"compiler/source:Span" %t246, ptr %l149
  br label %bb78
bb77:
  br label %bb84
bb78:
  %t247 = load ptr, ptr %l0, !tbaa !29
  %t248 = load i32, ptr %l3, !tbaa !23
  %t251 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s8, ptr %t247, i32 %t248)
  store { i64, ptr } %t251, ptr %l152
  br label %bb79
bb79:
  %t252 = load { i64, ptr }, ptr %l152, !tbaa !27
  %t253 = extractvalue { i64, ptr } %t252, 0
  %t254 = extractvalue { i64, ptr } %t252, 1
  %t255 = mul i64 %t253, 1
  %t256 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t255)
  call void @llvm.memcpy.p0.p0.i64(ptr %t256, ptr %t254, i64 %t255, i1 false)
  %t257 = insertvalue { i64, ptr } undef, i64 %t253, 0
  %t258 = insertvalue { i64, ptr } %t257, ptr %t256, 1
  %t260 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeArgsOnNonGeneric(ptr %s8, ptr %s8, { i64, ptr } %t258)
  store %"compiler/msgs:Msg" %t260, ptr %l154
  br label %bb80
bb80:
  %t261 = load ptr, ptr %l146, !tbaa !29
  %t262 = load %"compiler/source:Span", ptr %l149
  %t263 = load %"compiler/msgs:Msg", ptr %l154
  %t264 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s8, ptr %t261, %"compiler/source:Span" %t262, %"compiler/msgs:Msg" %t263)
  store i64 %t264, ptr %l155
  br label %bb81
bb81:
  %t265 = load ptr, ptr %l0, !tbaa !29
  %t266 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v2, ptr %t265, { i64, ptr } %t266)
  br label %bb82
bb82:
  %t269 = load ptr, ptr %l0, !tbaa !29
  %t270 = load %"compiler/source:Span", ptr %l1
  %t273 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v4, ptr %t269, %"compiler/source:Span" %t270)
  store ptr %t273, ptr %l160
  br label %bb83
bb83:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t274 = load ptr, ptr %l160, !tbaa !29
  store ptr %t274, ptr %rv
  br label %ret
bb84:
  %t275 = load ptr, ptr %l0, !tbaa !29
  %t276 = load i64, ptr %l12, !tbaa !24
  %t277 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t283 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexplicitArgs(ptr %v0, ptr %v3, ptr %v4, ptr %t275, i64 %t276, { i64, ptr } %t277, %"compiler/source:Span" %a7)
  store { i64, ptr } %t283, ptr %l165
  br label %bb85
bb85:
  %t284 = load { i64, ptr }, ptr %l165, !tbaa !27
  store { i64, ptr } %t284, ptr %l14, !tbaa !27
  %t285 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t287 = extractvalue { i64, ptr } %t285, 0
  %t289 = icmp eq i64 %t287, 0
  br i1 %t289, label %bb86, label %bb87
bb86:
  %t291 = load ptr, ptr %l0, !tbaa !29
  %t292 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v2, ptr %t291, { i64, ptr } %t292)
  br label %bb88
bb87:
  br label %bb90
bb88:
  %t295 = load ptr, ptr %l0, !tbaa !29
  %t296 = load %"compiler/source:Span", ptr %l1
  %t299 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v4, ptr %t295, %"compiler/source:Span" %t296)
  store ptr %t299, ptr %l173
  br label %bb89
bb89:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t300 = load ptr, ptr %l173, !tbaa !29
  store ptr %t300, ptr %rv
  br label %ret
bb90:
  %t301 = load ptr, ptr %l0, !tbaa !29
  %t302 = load i32, ptr %l3, !tbaa !23
  %t305 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %s4, ptr %t301, i32 %t302)
  store { i64, ptr } %t305, ptr %l176
  br label %bb91
bb91:
  %t306 = load { i64, ptr }, ptr %l176, !tbaa !27
  store { i64, ptr } %t306, ptr %l177, !tbaa !27
  %t307 = getelementptr { i64, ptr }, ptr %l177, i32 0, i32 1
  %t308 = load ptr, ptr %t307, !tbaa !27
  %t309 = getelementptr i8, ptr %t308, i64 0
  %t310 = load i8, ptr %t309, !tbaa !32
  %t312 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %t310)
  store i1 %t312, ptr %l179
  br label %bb92
bb92:
  %t313 = load i1, ptr %l179, !tbaa !21
  %t314 = xor i1 %t313, true
  br i1 %t314, label %bb93, label %bb94
bb93:
  %t316 = load ptr, ptr %l0, !tbaa !29
  %t318 = getelementptr %"compiler/check:Checker", ptr %t316, i32 0, i32 1
  %t319 = load ptr, ptr %t318, !tbaa !29
  %t320 = load i64, ptr %l12, !tbaa !24
  %t323 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t319, i64 %t320)
  store i64 %t323, ptr %l185
  br label %bb95
bb94:
  store i1 false, ptr %l181, !tbaa !21
  br label %bb97
bb95:
  %t324 = load ptr, ptr %l0, !tbaa !29
  %t326 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t324)
  store ptr %t326, ptr %l187
  br label %bb96
bb96:
  %t327 = load ptr, ptr %l187, !tbaa !29
  %t329 = getelementptr %"compiler/check:frame", ptr %t327, i32 0, i32 1
  %t330 = load i64, ptr %t329, !tbaa !24
  %t331 = load i64, ptr %l185, !tbaa !24
  %t333 = icmp ne i64 %t331, %t330
  store i1 %t333, ptr %l181, !tbaa !21
  br label %bb97
bb97:
  %t335 = load i1, ptr %l181, !tbaa !21
  br i1 %t335, label %bb98, label %bb99
bb98:
  store %olang.scope zeroinitializer, ptr %s10
  %t336 = load ptr, ptr %l0, !tbaa !29
  store ptr %t336, ptr %l191, !tbaa !29
  %t337 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t337, ptr %l192
  %t338 = load ptr, ptr %l0, !tbaa !29
  %t339 = load i32, ptr %l3, !tbaa !23
  %t342 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s10, ptr %t338, i32 %t339)
  store { i64, ptr } %t342, ptr %l195
  br label %bb100
bb99:
  br label %bb103
bb100:
  %t343 = load { i64, ptr }, ptr %l195, !tbaa !27
  %t344 = extractvalue { i64, ptr } %t343, 0
  %t345 = extractvalue { i64, ptr } %t343, 1
  %t346 = mul i64 %t344, 1
  %t347 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t346)
  call void @llvm.memcpy.p0.p0.i64(ptr %t347, ptr %t345, i64 %t346, i1 false)
  %t348 = insertvalue { i64, ptr } undef, i64 %t344, 0
  %t349 = insertvalue { i64, ptr } %t348, ptr %t347, 1
  %t351 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eMethodIsPrivate(ptr %s10, ptr %s10, { i64, ptr } %t349)
  store %"compiler/msgs:Msg" %t351, ptr %l197
  br label %bb101
bb101:
  %t352 = load ptr, ptr %l191, !tbaa !29
  %t353 = load %"compiler/source:Span", ptr %l192
  %t354 = load %"compiler/msgs:Msg", ptr %l197
  %t355 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s10, ptr %t352, %"compiler/source:Span" %t353, %"compiler/msgs:Msg" %t354)
  store i64 %t355, ptr %l198
  br label %bb102
bb102:
  call void @__olang_scope_close(ptr %s10)
  br label %bb103
bb103:
  %t356 = load ptr, ptr %l0, !tbaa !29
  store ptr %t356, ptr %l199, !tbaa !29
  %t357 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t357, ptr %l200
  %t358 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t358, ptr %l201
  %t359 = load i64, ptr %l12, !tbaa !24
  store i64 %t359, ptr %l202, !tbaa !24
  %t360 = load ptr, ptr %l9, !tbaa !29
  store ptr %t360, ptr %l204, !tbaa !29
  %t362 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t362, ptr %l205, !tbaa !27
  %t363 = icmp sge i64 0, 0
  br i1 %t363, label %bb104, label %bb105
bb104:
  %t365 = icmp sle i64 0, 1152921504606846975
  br i1 %t365, label %bb106, label %bb107
bb105:
  call void @__olang_check_failed(ptr @olang_loc_d23330c3ef7ea91b_34477ea00961dc87)
  unreachable
bb106:
  %t367 = mul i64 0, 8
  %t368 = insertvalue { i64, ptr } undef, i64 0, 0
  %t369 = insertvalue { i64, ptr } %t368, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t370 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t371 = load ptr, ptr %l199, !tbaa !29
  %t372 = load %"compiler/source:Span", ptr %l200
  %t373 = load %"compiler/source:Span", ptr %l201
  %t374 = load i64, ptr %l202, !tbaa !24
  %t375 = load ptr, ptr %l204, !tbaa !29
  %t376 = load { i64, ptr }, ptr %l205, !tbaa !27
  %t379 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v4, ptr %v2, ptr %v0, ptr %v4, ptr %v4, ptr %t371, %"compiler/source:Span" %t372, %"compiler/source:Span" %t373, i64 %t374, ptr %t375, { i64, ptr } %t376, { i64, ptr } %t369, { i64, ptr } %t370)
  store ptr %t379, ptr %l210
  br label %bb108
bb107:
  call void @__olang_check_failed(ptr @olang_loc_d23330c3ef7ea91b_34477ea00961dc87)
  unreachable
bb108:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t380 = load ptr, ptr %l210, !tbaa !29
  store ptr %t380, ptr %rv
  br label %ret
bb109:
  %t381 = load ptr, ptr %l0, !tbaa !29
  %t382 = load i32, ptr %l3, !tbaa !23
  %t385 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v4, ptr %t381, i32 %t382)
  store { i64, ptr } %t385, ptr %l213
  br label %bb110
bb110:
  %t386 = load { i64, ptr }, ptr %l213, !tbaa !27
  store { i64, ptr } %t386, ptr %l15, !tbaa !27
  %t387 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t389 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v4, ptr %s0, { i64, ptr } %t387, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d41, i32 0, i32 1) })
  store i1 %t389, ptr %l215
  br label %bb111
bb111:
  %t390 = load i1, ptr %l215, !tbaa !21
  br i1 %t390, label %bb112, label %bb113
bb112:
  %t391 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t393 = extractvalue { i64, ptr } %t391, 0
  %t395 = icmp eq i64 %t393, 0
  store i1 %t395, ptr %l216, !tbaa !21
  br label %bb114
bb113:
  store i1 false, ptr %l216, !tbaa !21
  br label %bb114
bb114:
  %t397 = load i1, ptr %l216, !tbaa !21
  br i1 %t397, label %bb115, label %bb116
bb115:
  %t398 = load ptr, ptr %l0, !tbaa !29
  %t400 = getelementptr %"compiler/check:Checker", ptr %t398, i32 0, i32 1
  %t401 = load ptr, ptr %t400, !tbaa !29
  %t403 = getelementptr %"compiler/generic:Program", ptr %t401, i32 0, i32 0
  %t404 = load ptr, ptr %t403, !tbaa !29
  %t406 = getelementptr %"compiler/load:Loader", ptr %t404, i32 0, i32 10
  store ptr %t406, ptr %l224, !tbaa !29
  %t407 = load ptr, ptr %l0, !tbaa !29
  %t409 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t407)
  store ptr %t409, ptr %l226
  br label %bb117
bb116:
  store i1 false, ptr %l220, !tbaa !21
  br label %bb119
bb117:
  %t410 = load ptr, ptr %l226, !tbaa !29
  %t412 = getelementptr %"compiler/check:frame", ptr %t410, i32 0, i32 1
  %t413 = load i64, ptr %t412, !tbaa !24
  %t414 = load ptr, ptr %l224, !tbaa !29
  %t416 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t414, i64 %t413)
  store ptr %t416, ptr %l229
  br label %bb118
bb118:
  %t417 = load ptr, ptr %l229, !tbaa !29
  %t419 = getelementptr %"compiler/load:Module", ptr %t417, i32 0, i32 3
  %t420 = load i1, ptr %t419, !tbaa !21
  store i1 %t420, ptr %l220, !tbaa !21
  br label %bb119
bb119:
  %t422 = load i1, ptr %l220, !tbaa !21
  store i1 %t422, ptr %l16, !tbaa !21
  %t423 = load ptr, ptr %l0, !tbaa !29
  %t425 = getelementptr %"compiler/check:Checker", ptr %t423, i32 0, i32 1
  %t426 = load ptr, ptr %t425, !tbaa !29
  %t428 = getelementptr %"compiler/generic:Program", ptr %t426, i32 0, i32 2
  store ptr %t428, ptr %l234, !tbaa !29
  %t429 = load ptr, ptr %l0, !tbaa !29
  %t430 = load i32, ptr %l10, !tbaa !23
  %t433 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t429, i32 %t430)
  store i32 %t433, ptr %l237
  br label %bb120
bb120:
  %t434 = load ptr, ptr %l234, !tbaa !29
  %t435 = load i32, ptr %l237, !tbaa !23
  %t436 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t434, i32 %t435)
  store i32 %t436, ptr %l238
  br label %bb121
bb121:
  %t437 = load i32, ptr %l238, !range !{i32 0, i32 33}
  %t439 = trunc i64 29 to i32
  %t440 = icmp eq i32 %t437, %t439
  br i1 %t440, label %bb122, label %bb123
bb122:
  %t442 = load i1, ptr %l16, !tbaa !21
  %t444 = xor i1 %t442, true
  store i1 %t444, ptr %l241, !tbaa !21
  br label %bb124
bb123:
  store i1 false, ptr %l241, !tbaa !21
  br label %bb124
bb124:
  %t446 = load i1, ptr %l241, !tbaa !21
  br i1 %t446, label %bb125, label %bb126
bb125:
  %t447 = load ptr, ptr %l0, !tbaa !29
  %t448 = load %"compiler/source:Span", ptr %l1
  %t449 = load ptr, ptr %l2, !tbaa !29
  %t450 = load ptr, ptr %l9, !tbaa !29
  %t451 = load i32, ptr %l3, !tbaa !23
  %t452 = load %"compiler/source:Span", ptr %l4
  %t453 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t461 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyCall(ptr %v0, ptr %v1, ptr %v4, ptr %v2, ptr %v4, ptr %t447, %"compiler/source:Span" %t448, ptr %t449, ptr %t450, i32 %t451, %"compiler/source:Span" %t452, { i64, ptr } %t453)
  store ptr %t461, ptr %l251
  br label %bb127
bb126:
  br label %bb128
bb127:
  call void @__olang_scope_close(ptr %s0)
  %t462 = load ptr, ptr %l251, !tbaa !29
  store ptr %t462, ptr %rv
  br label %ret
bb128:
  %t463 = load ptr, ptr %l0, !tbaa !29
  %t465 = getelementptr %"compiler/check:Checker", ptr %t463, i32 0, i32 1
  %t466 = load ptr, ptr %t465, !tbaa !29
  store ptr %t466, ptr %l253, !tbaa !29
  %t467 = load ptr, ptr %l0, !tbaa !29
  %t468 = load i32, ptr %l10, !tbaa !23
  %t471 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t467, i32 %t468)
  store i32 %t471, ptr %l256
  br label %bb129
bb129:
  %t472 = load i32, ptr %l3, !tbaa !23
  %t473 = load ptr, ptr %l253, !tbaa !29
  %t474 = load i32, ptr %l256, !tbaa !23
  %t476 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t473, i32 %t474, i32 %t472)
  store i64 %t476, ptr %l258
  br label %bb130
bb130:
  %t477 = load i64, ptr %l258, !tbaa !24
  store i64 %t477, ptr %l17, !tbaa !24
  %t478 = load i64, ptr %l17, !tbaa !24
  %t480 = icmp slt i64 %t478, 0
  br i1 %t480, label %bb131, label %bb132
bb131:
  store %olang.scope zeroinitializer, ptr %s12
  %t482 = load ptr, ptr %l0, !tbaa !29
  %t484 = getelementptr %"compiler/check:Checker", ptr %t482, i32 0, i32 1
  %t485 = load ptr, ptr %t484, !tbaa !29
  store ptr %t485, ptr %l262, !tbaa !29
  %t486 = load ptr, ptr %l0, !tbaa !29
  %t487 = load i32, ptr %l10, !tbaa !23
  %t490 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t486, i32 %t487)
  store i32 %t490, ptr %l265
  br label %bb133
bb132:
  br label %bb151
bb133:
  %t491 = load i32, ptr %l3, !tbaa !23
  %t492 = load ptr, ptr %l262, !tbaa !29
  %t493 = load i32, ptr %l265, !tbaa !23
  %t495 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDefaultMethods(ptr %v0, ptr %s12, ptr %t492, i32 %t493, i32 %t491)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t495, ptr %l267
  br label %bb134
bb134:
  %t496 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l267
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t496, ptr %l18
  %t498 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s12, ptr %l18)
  store i64 %t498, ptr %l269
  br label %bb135
bb135:
  %t499 = load i64, ptr %l269, !tbaa !24
  %t500 = icmp sgt i64 %t499, 1
  br i1 %t500, label %bb136, label %bb137
bb136:
  store %olang.scope zeroinitializer, ptr %s13
  %t502 = load ptr, ptr %l0, !tbaa !29
  store ptr %t502, ptr %l271, !tbaa !29
  %t503 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t503, ptr %l272
  %t504 = load ptr, ptr %l0, !tbaa !29
  store ptr %t504, ptr %l273, !tbaa !29
  %t505 = load ptr, ptr %l0, !tbaa !29
  %t506 = load i32, ptr %l10, !tbaa !23
  %t509 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t505, i32 %t506)
  store i32 %t509, ptr %l276
  br label %bb138
bb137:
  br label %bb145
bb138:
  %t510 = load ptr, ptr %l273, !tbaa !29
  %t511 = load i32, ptr %l276, !tbaa !23
  %t512 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s13, ptr %t510, i32 %t511)
  store { i64, ptr } %t512, ptr %l277
  br label %bb139
bb139:
  %t513 = load { i64, ptr }, ptr %l277, !tbaa !27
  %t514 = extractvalue { i64, ptr } %t513, 0
  %t515 = extractvalue { i64, ptr } %t513, 1
  %t516 = mul i64 %t514, 1
  %t517 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t516)
  call void @llvm.memcpy.p0.p0.i64(ptr %t517, ptr %t515, i64 %t516, i1 false)
  %t518 = insertvalue { i64, ptr } undef, i64 %t514, 0
  %t519 = insertvalue { i64, ptr } %t518, ptr %t517, 1
  store { i64, ptr } %t519, ptr %l278, !tbaa !27
  %t520 = load ptr, ptr %l0, !tbaa !29
  %t521 = load i32, ptr %l3, !tbaa !23
  %t524 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s13, ptr %t520, i32 %t521)
  store { i64, ptr } %t524, ptr %l281
  br label %bb140
bb140:
  %t525 = load { i64, ptr }, ptr %l281, !tbaa !27
  %t526 = extractvalue { i64, ptr } %t525, 0
  %t527 = extractvalue { i64, ptr } %t525, 1
  %t528 = mul i64 %t526, 1
  %t529 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t528)
  call void @llvm.memcpy.p0.p0.i64(ptr %t529, ptr %t527, i64 %t528, i1 false)
  %t530 = insertvalue { i64, ptr } undef, i64 %t526, 0
  %t531 = insertvalue { i64, ptr } %t530, ptr %t529, 1
  %t532 = load { i64, ptr }, ptr %l278, !tbaa !27
  %t534 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefaultAmbiguous(ptr %s13, ptr %s13, ptr %s13, { i64, ptr } %t532, { i64, ptr } %t531)
  store %"compiler/msgs:Msg" %t534, ptr %l283
  br label %bb141
bb141:
  %t535 = load ptr, ptr %l271, !tbaa !29
  %t536 = load %"compiler/source:Span", ptr %l272
  %t537 = load %"compiler/msgs:Msg", ptr %l283
  %t538 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s13, ptr %t535, %"compiler/source:Span" %t536, %"compiler/msgs:Msg" %t537)
  store i64 %t538, ptr %l284
  br label %bb142
bb142:
  %t539 = load ptr, ptr %l0, !tbaa !29
  %t540 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v2, ptr %t539, { i64, ptr } %t540)
  br label %bb143
bb143:
  %t543 = load ptr, ptr %l0, !tbaa !29
  %t544 = load %"compiler/source:Span", ptr %l1
  %t547 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v4, ptr %t543, %"compiler/source:Span" %t544)
  store ptr %t547, ptr %l289
  br label %bb144
bb144:
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s0)
  %t548 = load ptr, ptr %l289, !tbaa !29
  store ptr %t548, ptr %rv
  br label %ret
bb145:
  %t550 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s12, ptr %l18)
  store i64 %t550, ptr %l291
  br label %bb146
bb146:
  %t551 = load i64, ptr %l291, !tbaa !24
  %t552 = icmp eq i64 %t551, 1
  br i1 %t552, label %bb147, label %bb148
bb147:
  %t555 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s12, ptr %l18, i64 0)
  store i64 %t555, ptr %l294
  br label %bb149
bb148:
  br label %bb150
bb149:
  %t556 = load i64, ptr %l294, !tbaa !24
  store i64 %t556, ptr %l17, !tbaa !24
  br label %bb150
bb150:
  call void @__olang_scope_close(ptr %s12)
  br label %bb151
bb151:
  %t557 = load i64, ptr %l17, !tbaa !24
  %t559 = icmp slt i64 %t557, 0
  br i1 %t559, label %bb152, label %bb153
bb152:
  %t561 = load ptr, ptr %l0, !tbaa !29
  %t562 = load i32, ptr %l10, !tbaa !23
  %t565 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t561, i32 %t562)
  store i1 %t565, ptr %l300
  br label %bb154
bb153:
  store i1 false, ptr %l297, !tbaa !21
  br label %bb155
bb154:
  %t566 = load i1, ptr %l300, !tbaa !21
  store i1 %t566, ptr %l297, !tbaa !21
  br label %bb155
bb155:
  %t567 = load i1, ptr %l297, !tbaa !21
  br i1 %t567, label %bb156, label %bb157
bb156:
  %t568 = load ptr, ptr %l0, !tbaa !29
  %t570 = getelementptr %"compiler/check:Checker", ptr %t568, i32 0, i32 1
  %t571 = load ptr, ptr %t570, !tbaa !29
  %t573 = getelementptr %"compiler/generic:Program", ptr %t571, i32 0, i32 2
  %t574 = load i32, ptr %l10, !tbaa !23
  %t577 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %t573, i32 %t574)
  store i1 %t577, ptr %l306
  br label %bb158
bb157:
  store i1 false, ptr %l301, !tbaa !21
  br label %bb159
bb158:
  %t578 = load i1, ptr %l306, !tbaa !21
  store i1 %t578, ptr %l301, !tbaa !21
  br label %bb159
bb159:
  %t579 = load i1, ptr %l301, !tbaa !21
  br i1 %t579, label %bb160, label %bb161
bb160:
  %t580 = load i1, ptr %l16, !tbaa !21
  %t582 = xor i1 %t580, true
  store i1 %t582, ptr %l307, !tbaa !21
  br label %bb162
bb161:
  store i1 false, ptr %l307, !tbaa !21
  br label %bb162
bb162:
  %t584 = load i1, ptr %l307, !tbaa !21
  br i1 %t584, label %bb163, label %bb164
bb163:
  store %olang.scope zeroinitializer, ptr %s15
  %t585 = load ptr, ptr %l0, !tbaa !29
  store ptr %t585, ptr %l310, !tbaa !29
  %t586 = load ptr, ptr %l2, !tbaa !29
  %t588 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t586)
  store %"compiler/source:Span" %t588, ptr %l312
  br label %bb165
bb164:
  br label %bb175
bb165:
  %t589 = load ptr, ptr %l0, !tbaa !29
  store ptr %t589, ptr %l313, !tbaa !29
  %t590 = load ptr, ptr %l2, !tbaa !29
  %t592 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t590)
  store %"compiler/source:Span" %t592, ptr %l315
  br label %bb166
bb166:
  %t593 = load ptr, ptr %l313, !tbaa !29
  %t594 = load %"compiler/source:Span", ptr %l315
  %t595 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v0, ptr %t593, %"compiler/source:Span" %t594)
  store { i64, ptr } %t595, ptr %l316
  br label %bb167
bb167:
  %t596 = load ptr, ptr %l0, !tbaa !29
  %t597 = load i32, ptr %l10, !tbaa !23
  %t600 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s15, ptr %t596, i32 %t597)
  store { i64, ptr } %t600, ptr %l319
  br label %bb168
bb168:
  %t601 = load { i64, ptr }, ptr %l319, !tbaa !27
  %t602 = extractvalue { i64, ptr } %t601, 0
  %t603 = extractvalue { i64, ptr } %t601, 1
  %t604 = mul i64 %t602, 1
  %t605 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t604)
  call void @llvm.memcpy.p0.p0.i64(ptr %t605, ptr %t603, i64 %t604, i1 false)
  %t606 = insertvalue { i64, ptr } undef, i64 %t602, 0
  %t607 = insertvalue { i64, ptr } %t606, ptr %t605, 1
  store { i64, ptr } %t607, ptr %l320, !tbaa !27
  %t608 = load ptr, ptr %l0, !tbaa !29
  store ptr %t608, ptr %l321, !tbaa !29
  %t609 = load ptr, ptr %l2, !tbaa !29
  %t611 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t609)
  store %"compiler/source:Span" %t611, ptr %l323
  br label %bb169
bb169:
  %t612 = load ptr, ptr %l321, !tbaa !29
  %t613 = load %"compiler/source:Span", ptr %l323
  %t614 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v0, ptr %t612, %"compiler/source:Span" %t613)
  store { i64, ptr } %t614, ptr %l324
  br label %bb170
bb170:
  %t615 = load { i64, ptr }, ptr %l324, !tbaa !27
  %t616 = call { i64, ptr } @compiler_2fcheck_2ebangOf(ptr %v0, ptr %s15, { i64, ptr } %t615)
  store { i64, ptr } %t616, ptr %l325
  br label %bb171
bb171:
  %t617 = load { i64, ptr }, ptr %l325, !tbaa !27
  %t618 = extractvalue { i64, ptr } %t617, 0
  %t619 = extractvalue { i64, ptr } %t617, 1
  %t620 = mul i64 %t618, 1
  %t621 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t620)
  call void @llvm.memcpy.p0.p0.i64(ptr %t621, ptr %t619, i64 %t620, i1 false)
  %t622 = insertvalue { i64, ptr } undef, i64 %t618, 0
  %t623 = insertvalue { i64, ptr } %t622, ptr %t621, 1
  %t624 = load { i64, ptr }, ptr %l316, !tbaa !27
  %t625 = load { i64, ptr }, ptr %l320, !tbaa !27
  %t627 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eReadMaybeNull(ptr %v0, ptr %s15, ptr %s15, ptr %s15, { i64, ptr } %t624, { i64, ptr } %t625, { i64, ptr } %t623)
  store %"compiler/msgs:Msg" %t627, ptr %l327
  br label %bb172
bb172:
  %t628 = load ptr, ptr %l310, !tbaa !29
  %t629 = load %"compiler/source:Span", ptr %l312
  %t630 = load %"compiler/msgs:Msg", ptr %l327
  %t631 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s15, ptr %t628, %"compiler/source:Span" %t629, %"compiler/msgs:Msg" %t630)
  store i64 %t631, ptr %l328
  br label %bb173
bb173:
  %t632 = load ptr, ptr %l0, !tbaa !29
  %t634 = getelementptr %"compiler/check:Checker", ptr %t632, i32 0, i32 1
  %t635 = load ptr, ptr %t634, !tbaa !29
  %t637 = getelementptr %"compiler/generic:Program", ptr %t635, i32 0, i32 2
  %t638 = load i32, ptr %l10, !tbaa !23
  %t641 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNonNull(ptr %v0, ptr %t637, i32 %t638)
  store i32 %t641, ptr %l333
  br label %bb174
bb174:
  %t642 = load i32, ptr %l333, !tbaa !23
  store i32 %t642, ptr %l10, !tbaa !23
  call void @__olang_scope_close(ptr %s15)
  br label %bb175
bb175:
  %t643 = load i64, ptr %l17, !tbaa !24
  %t645 = icmp slt i64 %t643, 0
  br i1 %t645, label %bb176, label %bb177
bb176:
  %t647 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t649 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v4, ptr %s0, { i64, ptr } %t647, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d42, i32 0, i32 1) })
  store i1 %t649, ptr %l338
  br label %bb178
bb177:
  store i1 false, ptr %l336, !tbaa !21
  br label %bb179
bb178:
  %t650 = load i1, ptr %l338, !tbaa !21
  store i1 %t650, ptr %l336, !tbaa !21
  br label %bb179
bb179:
  %t651 = load i1, ptr %l336, !tbaa !21
  br i1 %t651, label %bb180, label %bb181
bb180:
  %t652 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t654 = extractvalue { i64, ptr } %t652, 0
  %t656 = icmp eq i64 %t654, 0
  store i1 %t656, ptr %l339, !tbaa !21
  br label %bb182
bb181:
  store i1 false, ptr %l339, !tbaa !21
  br label %bb182
bb182:
  %t658 = load i1, ptr %l339, !tbaa !21
  br i1 %t658, label %bb183, label %bb184
bb183:
  %t659 = load ptr, ptr %l0, !tbaa !29
  %t660 = load i32, ptr %l10, !tbaa !23
  %t663 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayOf(ptr %v0, ptr %t659, i32 %t660)
  store i32 %t663, ptr %l346
  br label %bb185
bb184:
  store i1 false, ptr %l343, !tbaa !21
  br label %bb186
bb185:
  %t664 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t665 = load i32, ptr %l346, !tbaa !23
  %t667 = icmp ne i32 %t665, %t664
  store i1 %t667, ptr %l343, !tbaa !21
  br label %bb186
bb186:
  %t669 = load i1, ptr %l343, !tbaa !21
  br i1 %t669, label %bb187, label %bb188
bb187:
  %t670 = load ptr, ptr %l0, !tbaa !29
  store ptr %t670, ptr %l349, !tbaa !29
  %t671 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t671, ptr %l350
  %t672 = load ptr, ptr %l0, !tbaa !29
  %t674 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t672)
  store i32 %t674, ptr %l352
  br label %bb189
bb188:
  br label %bb191
bb189:
  %t675 = load ptr, ptr %l9, !tbaa !29
  %t676 = load ptr, ptr %l349, !tbaa !29
  %t677 = load %"compiler/source:Span", ptr %l350
  %t678 = load i32, ptr %l352, !tbaa !23
  %t681 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v4, ptr %v0, ptr %v4, ptr %t676, %"compiler/source:Span" %t677, i32 %t678, i32 22, ptr %t675, ptr null)
  store ptr %t681, ptr %l355
  br label %bb190
bb190:
  call void @__olang_scope_close(ptr %s0)
  %t682 = load ptr, ptr %l355, !tbaa !29
  store ptr %t682, ptr %rv
  br label %ret
bb191:
  %t683 = load i64, ptr %l17, !tbaa !24
  %t685 = icmp slt i64 %t683, 0
  br i1 %t685, label %bb192, label %bb193
bb192:
  %t687 = load ptr, ptr %l0, !tbaa !29
  %t688 = load i32, ptr %l10, !tbaa !23
  %t691 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t687, i32 %t688)
  store i32 %t691, ptr %l361
  br label %bb194
bb193:
  store i1 false, ptr %l358, !tbaa !21
  br label %bb200
bb194:
  %t692 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t693 = load i32, ptr %l361, !tbaa !23
  %t695 = icmp eq i32 %t693, %t692
  br i1 %t695, label %bb195, label %bb196
bb195:
  store i1 true, ptr %l364, !tbaa !21
  br label %bb199
bb196:
  %t697 = load ptr, ptr %l0, !tbaa !29
  store ptr %t697, ptr %l365, !tbaa !29
  %t698 = load ptr, ptr %l0, !tbaa !29
  %t699 = load i32, ptr %l10, !tbaa !23
  %t702 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t698, i32 %t699)
  store i32 %t702, ptr %l368
  br label %bb197
bb197:
  %t703 = load ptr, ptr %l365, !tbaa !29
  %t704 = load i32, ptr %l368, !tbaa !23
  %t705 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebadOver(ptr %v0, ptr %t703, i32 %t704)
  store i1 %t705, ptr %l369
  br label %bb198
bb198:
  %t706 = load i1, ptr %l369, !tbaa !21
  store i1 %t706, ptr %l364, !tbaa !21
  br label %bb199
bb199:
  %t707 = load i1, ptr %l364, !tbaa !21
  store i1 %t707, ptr %l358, !tbaa !21
  br label %bb200
bb200:
  %t708 = load i1, ptr %l358, !tbaa !21
  br i1 %t708, label %bb201, label %bb202
bb201:
  %t709 = load ptr, ptr %l0, !tbaa !29
  %t710 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v2, ptr %t709, { i64, ptr } %t710)
  br label %bb203
bb202:
  br label %bb205
bb203:
  %t713 = load ptr, ptr %l0, !tbaa !29
  %t714 = load %"compiler/source:Span", ptr %l1
  %t717 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v4, ptr %t713, %"compiler/source:Span" %t714)
  store ptr %t717, ptr %l374
  br label %bb204
bb204:
  call void @__olang_scope_close(ptr %s0)
  %t718 = load ptr, ptr %l374, !tbaa !29
  store ptr %t718, ptr %rv
  br label %ret
bb205:
  %t719 = load i64, ptr %l17, !tbaa !24
  %t721 = icmp slt i64 %t719, 0
  br i1 %t721, label %bb206, label %bb207
bb206:
  %t723 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t725 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v4, ptr %s0, { i64, ptr } %t723, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d43, i32 0, i32 1) })
  store i1 %t725, ptr %l379
  br label %bb208
bb207:
  store i1 false, ptr %l377, !tbaa !21
  br label %bb209
bb208:
  %t726 = load i1, ptr %l379, !tbaa !21
  %t727 = xor i1 %t726, true
  store i1 %t727, ptr %l377, !tbaa !21
  br label %bb209
bb209:
  %t729 = load i1, ptr %l377, !tbaa !21
  br i1 %t729, label %bb210, label %bb211
bb210:
  %t730 = load ptr, ptr %l0, !tbaa !29
  store ptr %t730, ptr %l382, !tbaa !29
  %t731 = load ptr, ptr %l0, !tbaa !29
  %t732 = load i32, ptr %l10, !tbaa !23
  %t735 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t731, i32 %t732)
  store i32 %t735, ptr %l385
  br label %bb212
bb211:
  store i1 false, ptr %l381, !tbaa !21
  br label %bb214
bb212:
  %t736 = load ptr, ptr %l382, !tbaa !29
  %t737 = load i32, ptr %l385, !tbaa !23
  %t738 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t736, i32 %t737)
  store i1 %t738, ptr %l386
  br label %bb213
bb213:
  %t739 = load i1, ptr %l386, !tbaa !21
  store i1 %t739, ptr %l381, !tbaa !21
  br label %bb214
bb214:
  %t740 = load i1, ptr %l381, !tbaa !21
  br i1 %t740, label %bb215, label %bb216
bb215:
  %t741 = load ptr, ptr %l0, !tbaa !29
  store ptr %t741, ptr %l388, !tbaa !29
  %t742 = load ptr, ptr %l0, !tbaa !29
  %t743 = load i32, ptr %l10, !tbaa !23
  %t746 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t742, i32 %t743)
  store i32 %t746, ptr %l391
  br label %bb217
bb216:
  store i1 false, ptr %l387, !tbaa !21
  br label %bb219
bb217:
  %t747 = load ptr, ptr %l388, !tbaa !29
  %t748 = load i32, ptr %l391, !tbaa !23
  %t749 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisOver(ptr %v0, ptr %t747, i32 %t748)
  store i1 %t749, ptr %l392
  br label %bb218
bb218:
  %t750 = load i1, ptr %l392, !tbaa !21
  store i1 %t750, ptr %l387, !tbaa !21
  br label %bb219
bb219:
  %t751 = load i1, ptr %l387, !tbaa !21
  br i1 %t751, label %bb220, label %bb221
bb220:
  %t752 = load ptr, ptr %l0, !tbaa !29
  %t754 = getelementptr %"compiler/check:Checker", ptr %t752, i32 0, i32 1
  %t755 = load ptr, ptr %t754, !tbaa !29
  store ptr %t755, ptr %l395, !tbaa !29
  %t756 = load ptr, ptr %l0, !tbaa !29
  %t757 = load i32, ptr %l10, !tbaa !23
  %t760 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t756, i32 %t757)
  store i32 %t760, ptr %l398
  br label %bb222
bb221:
  store i1 false, ptr %l393, !tbaa !21
  br label %bb224
bb222:
  %t761 = load ptr, ptr %l395, !tbaa !29
  %t762 = load i32, ptr %l398, !tbaa !23
  %t763 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eExtends(ptr %v0, ptr %t761, i32 %t762)
  store i1 %t763, ptr %l399
  br label %bb223
bb223:
  %t764 = load i1, ptr %l399, !tbaa !21
  %t765 = xor i1 %t764, true
  store i1 %t765, ptr %l393, !tbaa !21
  br label %bb224
bb224:
  %t767 = load i1, ptr %l393, !tbaa !21
  br i1 %t767, label %bb225, label %bb226
bb225:
  %t768 = load ptr, ptr %l0, !tbaa !29
  store ptr %t768, ptr %l402, !tbaa !29
  %t769 = load ptr, ptr %l0, !tbaa !29
  %t770 = load i32, ptr %l10, !tbaa !23
  %t773 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t769, i32 %t770)
  store i32 %t773, ptr %l405
  br label %bb227
bb226:
  store i1 false, ptr %l401, !tbaa !21
  br label %bb229
bb227:
  %t774 = load i32, ptr %l3, !tbaa !23
  %t775 = load ptr, ptr %l402, !tbaa !29
  %t776 = load i32, ptr %l405, !tbaa !23
  %t778 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebaseHas(ptr %v0, ptr %t775, i32 %t776, i32 %t774)
  store i1 %t778, ptr %l407
  br label %bb228
bb228:
  %t779 = load i1, ptr %l407, !tbaa !21
  store i1 %t779, ptr %l401, !tbaa !21
  br label %bb229
bb229:
  %t780 = load i1, ptr %l401, !tbaa !21
  br i1 %t780, label %bb230, label %bb231
bb230:
  store %olang.scope zeroinitializer, ptr %s18
  %t781 = load ptr, ptr %l0, !tbaa !29
  store ptr %t781, ptr %l408, !tbaa !29
  %t782 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t782, ptr %l409
  %t783 = load ptr, ptr %l0, !tbaa !29
  store ptr %t783, ptr %l410, !tbaa !29
  %t784 = load ptr, ptr %l0, !tbaa !29
  %t785 = load i32, ptr %l10, !tbaa !23
  %t788 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t784, i32 %t785)
  store i32 %t788, ptr %l413
  br label %bb232
bb231:
  br label %bb239
bb232:
  %t789 = load ptr, ptr %l410, !tbaa !29
  %t790 = load i32, ptr %l413, !tbaa !23
  %t791 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s18, ptr %t789, i32 %t790)
  store { i64, ptr } %t791, ptr %l414
  br label %bb233
bb233:
  %t792 = load { i64, ptr }, ptr %l414, !tbaa !27
  %t793 = extractvalue { i64, ptr } %t792, 0
  %t794 = extractvalue { i64, ptr } %t792, 1
  %t795 = mul i64 %t793, 1
  %t796 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t795)
  call void @llvm.memcpy.p0.p0.i64(ptr %t796, ptr %t794, i64 %t795, i1 false)
  %t797 = insertvalue { i64, ptr } undef, i64 %t793, 0
  %t798 = insertvalue { i64, ptr } %t797, ptr %t796, 1
  store { i64, ptr } %t798, ptr %l415, !tbaa !27
  %t799 = load ptr, ptr %l0, !tbaa !29
  %t800 = load i32, ptr %l3, !tbaa !23
  %t803 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s18, ptr %t799, i32 %t800)
  store { i64, ptr } %t803, ptr %l418
  br label %bb234
bb234:
  %t804 = load { i64, ptr }, ptr %l418, !tbaa !27
  %t805 = extractvalue { i64, ptr } %t804, 0
  %t806 = extractvalue { i64, ptr } %t804, 1
  %t807 = mul i64 %t805, 1
  %t808 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t807)
  call void @llvm.memcpy.p0.p0.i64(ptr %t808, ptr %t806, i64 %t807, i1 false)
  %t809 = insertvalue { i64, ptr } undef, i64 %t805, 0
  %t810 = insertvalue { i64, ptr } %t809, ptr %t808, 1
  %t811 = load { i64, ptr }, ptr %l415, !tbaa !27
  %t813 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eMethodNotInherited(ptr %s18, ptr %s18, ptr %s18, { i64, ptr } %t811, { i64, ptr } %t810)
  store %"compiler/msgs:Msg" %t813, ptr %l420
  br label %bb235
bb235:
  %t814 = load ptr, ptr %l408, !tbaa !29
  %t815 = load %"compiler/source:Span", ptr %l409
  %t816 = load %"compiler/msgs:Msg", ptr %l420
  %t817 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s18, ptr %t814, %"compiler/source:Span" %t815, %"compiler/msgs:Msg" %t816)
  store i64 %t817, ptr %l421
  br label %bb236
bb236:
  %t818 = load ptr, ptr %l0, !tbaa !29
  %t819 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v2, ptr %t818, { i64, ptr } %t819)
  br label %bb237
bb237:
  %t822 = load ptr, ptr %l0, !tbaa !29
  %t823 = load %"compiler/source:Span", ptr %l1
  %t826 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v4, ptr %t822, %"compiler/source:Span" %t823)
  store ptr %t826, ptr %l426
  br label %bb238
bb238:
  call void @__olang_scope_close(ptr %s18)
  call void @__olang_scope_close(ptr %s0)
  %t827 = load ptr, ptr %l426, !tbaa !29
  store ptr %t827, ptr %rv
  br label %ret
bb239:
  %t828 = load i64, ptr %l17, !tbaa !24
  %t830 = icmp slt i64 %t828, 0
  br i1 %t830, label %bb240, label %bb241
bb240:
  store %olang.scope zeroinitializer, ptr %s19
  %t832 = load ptr, ptr %l0, !tbaa !29
  %t833 = load %"compiler/source:Span", ptr %l1
  %t834 = load %"compiler/source:Span", ptr %l4
  %t835 = load ptr, ptr %l2, !tbaa !29
  %t836 = load ptr, ptr %l9, !tbaa !29
  %t837 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t838 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t846 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esuppliedCall(ptr %v0, ptr %v1, ptr %v4, ptr %v4, ptr %v2, ptr %v4, ptr %t832, %"compiler/source:Span" %t833, %"compiler/source:Span" %t834, ptr %t835, ptr %t836, { i64, ptr } %t837, { i64, ptr } %t838)
  store ptr %t846, ptr %l436
  br label %bb242
bb241:
  br label %bb313
bb242:
  %t847 = load ptr, ptr %l436, !tbaa !29
  store ptr %t847, ptr %l19, !tbaa !29
  %t848 = load ptr, ptr %l19, !tbaa !29
  %t850 = icmp eq ptr %t848, null
  %t852 = xor i1 %t850, true
  br i1 %t852, label %bb243, label %bb244
bb243:
  %t854 = load ptr, ptr %l19, !tbaa !29
  call void @__olang_scope_close(ptr %s19)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t854, ptr %rv
  br label %ret
bb244:
  br label %bb245
bb245:
  %t856 = load ptr, ptr %l0, !tbaa !29
  %t857 = load i32, ptr %l10, !tbaa !23
  %t860 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t856, i32 %t857)
  store i32 %t860, ptr %l443
  br label %bb246
bb246:
  %t861 = load i32, ptr %l443, !tbaa !23
  store i32 %t861, ptr %l20, !tbaa !23
  %t862 = load ptr, ptr %l0, !tbaa !29
  %t863 = load i32, ptr %l20, !tbaa !23
  %t866 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisStruct(ptr %v0, ptr %t862, i32 %t863)
  store i1 %t866, ptr %l446
  br label %bb247
bb247:
  %t867 = load i1, ptr %l446, !tbaa !21
  br i1 %t867, label %bb248, label %bb249
bb248:
  %t868 = load ptr, ptr %l0, !tbaa !29
  %t869 = load i32, ptr %l20, !tbaa !23
  %t870 = load i32, ptr %l3, !tbaa !23
  %t874 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efieldIndex(ptr %v0, ptr %t868, i32 %t869, i32 %t870)
  store i64 %t874, ptr %l451
  br label %bb250
bb249:
  store i1 false, ptr %l447, !tbaa !21
  br label %bb251
bb250:
  %t875 = load i64, ptr %l451, !tbaa !24
  %t876 = icmp sge i64 %t875, 0
  store i1 %t876, ptr %l447, !tbaa !21
  br label %bb251
bb251:
  %t878 = load i1, ptr %l447, !tbaa !21
  br i1 %t878, label %bb252, label %bb253
bb252:
  %t879 = load ptr, ptr %l9, !tbaa !29
  %t881 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v4, ptr %v4, ptr %t879)
  store ptr %t881, ptr %l454
  br label %bb254
bb253:
  br label %bb270
bb254:
  %t882 = load ptr, ptr %l454, !tbaa !29
  store ptr %t882, ptr %l21, !tbaa !29
  %t883 = load ptr, ptr %l21, !tbaa !29
  %t885 = icmp eq ptr %t883, null
  br i1 %t885, label %bb255, label %bb256
bb255:
  %t887 = load ptr, ptr %l2, !tbaa !29
  %t889 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t887)
  store %"compiler/source:Span" %t889, ptr %l458
  br label %bb257
bb256:
  br label %bb260
bb257:
  %t890 = load i32, ptr %l10, !tbaa !23
  store i32 %t890, ptr %l459, !tbaa !23
  %t891 = load ptr, ptr %l9, !tbaa !29
  store ptr %t891, ptr %l460, !tbaa !29
  %t892 = load ptr, ptr %l0, !tbaa !29
  store ptr %t892, ptr %l461, !tbaa !29
  store i32 8, ptr %l462
  %t893 = load ptr, ptr %l2, !tbaa !29
  %t895 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t893)
  store %"compiler/source:Span" %t895, ptr %l464
  br label %bb258
bb258:
  %t896 = load ptr, ptr %l461, !tbaa !29
  %t897 = load i32, ptr %l462, !range !{i32 0, i32 9}
  %t898 = load %"compiler/source:Span", ptr %l464
  %t899 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %t896, i32 %t897, %"compiler/source:Span" %t898)
  store i32 %t899, ptr %l465
  br label %bb259
bb259:
  store { i64, [4 x i64] } zeroinitializer, ptr %t900
  %t901 = getelementptr { i64, [4 x i64] }, ptr %t900, i32 0, i32 0
  store i64 6, ptr %t901
  %t902 = load %"compiler/source:Span", ptr %l458
  %t903 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } undef, %"compiler/source:Span" %t902, 0
  %t904 = load i32, ptr %l459, !tbaa !23
  %t905 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t903, i32 %t904, 1
  %t906 = load ptr, ptr %l460, !tbaa !29
  %t907 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t905, ptr %t906, 2
  %t908 = load i32, ptr %l465, !tbaa !23
  %t909 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t907, i32 %t908, 3
  %t910 = getelementptr { i64, [4 x i64] }, ptr %t900, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i32 } %t909, ptr %t910
  %t911 = load { i64, [4 x i64] }, ptr %t900
  %t913 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 40, i64 8)
  store { i64, [4 x i64] } %t911, ptr %t913
  store ptr %t913, ptr %l21, !tbaa !29
  br label %bb260
bb260:
  %t915 = load ptr, ptr %l0, !tbaa !29
  store ptr %t915, ptr %l468, !tbaa !29
  %t916 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t916, ptr %l469
  %t917 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t917, ptr %l470
  %t918 = load ptr, ptr %l21, !tbaa !29
  %t920 = icmp eq ptr %t918, null
  br i1 %t920, label %bb261, label %bb262
bb261:
  call void @__olang_check_failed(ptr @olang_loc_897998a95b9e5e2e_e7f90bd867c953f2)
  unreachable
bb262:
  br label %bb263
bb263:
  %t922 = load ptr, ptr %l21, !tbaa !29
  %t923 = load i32, ptr %l3, !tbaa !23
  %t924 = load ptr, ptr %l468, !tbaa !29
  %t925 = load %"compiler/source:Span", ptr %l469
  %t926 = load %"compiler/source:Span", ptr %l470
  %t929 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efield(ptr %v0, ptr %v4, ptr %v4, ptr %t924, %"compiler/source:Span" %t925, %"compiler/source:Span" %t926, ptr %t922, i32 %t923)
  store ptr %t929, ptr %l475
  br label %bb264
bb264:
  %t930 = load ptr, ptr %l475, !tbaa !29
  store ptr %t930, ptr %l22, !tbaa !29
  %t931 = load ptr, ptr %l22, !tbaa !29
  %t933 = icmp eq ptr %t931, null
  %t935 = xor i1 %t933, true
  br i1 %t935, label %bb265, label %bb266
bb265:
  %t937 = load ptr, ptr %l0, !tbaa !29
  store ptr %t937, ptr %l479, !tbaa !29
  %t938 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t938, ptr %l480
  %t939 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t939, ptr %l481
  %t940 = load ptr, ptr %l0, !tbaa !29
  %t941 = load %"compiler/source:Span", ptr %l1
  %t942 = load ptr, ptr %l22, !tbaa !29
  %t946 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v4, ptr %v4, ptr %t940, %"compiler/source:Span" %t941, ptr %t942)
  store ptr %t946, ptr %l485
  br label %bb267
bb266:
  br label %bb269
bb267:
  %t947 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t948 = load ptr, ptr %l479, !tbaa !29
  %t949 = load %"compiler/source:Span", ptr %l480
  %t950 = load %"compiler/source:Span", ptr %l481
  %t951 = load ptr, ptr %l485, !tbaa !29
  %t953 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallValue(ptr %v0, ptr %v4, ptr %v2, ptr %v4, ptr %t948, %"compiler/source:Span" %t949, %"compiler/source:Span" %t950, ptr %t951, { i64, ptr } %t947)
  store ptr %t953, ptr %l487
  br label %bb268
bb268:
  call void @__olang_scope_close(ptr %s19)
  call void @__olang_scope_close(ptr %s0)
  %t954 = load ptr, ptr %l487, !tbaa !29
  store ptr %t954, ptr %rv
  br label %ret
bb269:
  br label %bb270
bb270:
  %t955 = load ptr, ptr %l0, !tbaa !29
  %t956 = load i32, ptr %l20, !tbaa !23
  %t959 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t955, i32 %t956)
  store i1 %t959, ptr %l490
  br label %bb271
bb271:
  %t960 = load i1, ptr %l490, !tbaa !21
  br i1 %t960, label %bb272, label %bb273
bb272:
  %t961 = load ptr, ptr %l0, !tbaa !29
  %t962 = load i32, ptr %l20, !tbaa !23
  %t965 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %t961, i32 %t962)
  store i32 %t965, ptr %l494
  br label %bb274
bb273:
  store i1 false, ptr %l491, !tbaa !21
  br label %bb275
bb274:
  %t966 = load i32, ptr %l494, !range !{i32 0, i32 6}
  %t968 = trunc i64 3 to i32
  %t969 = icmp eq i32 %t966, %t968
  store i1 %t969, ptr %l491, !tbaa !21
  br label %bb275
bb275:
  %t971 = load i1, ptr %l491, !tbaa !21
  br i1 %t971, label %bb276, label %bb277
bb276:
  %t972 = load ptr, ptr %l0, !tbaa !29
  %t973 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v2, ptr %t972, { i64, ptr } %t973)
  br label %bb278
bb277:
  br label %bb280
bb278:
  %t976 = load ptr, ptr %l0, !tbaa !29
  %t977 = load %"compiler/source:Span", ptr %l1
  %t980 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v4, ptr %t976, %"compiler/source:Span" %t977)
  store ptr %t980, ptr %l501
  br label %bb279
bb279:
  call void @__olang_scope_close(ptr %s19)
  call void @__olang_scope_close(ptr %s0)
  %t981 = load ptr, ptr %l501, !tbaa !29
  store ptr %t981, ptr %rv
  br label %ret
bb280:
  %t982 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t984 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v4, ptr %s19, { i64, ptr } %t982, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d44, i32 0, i32 1) })
  store i1 %t984, ptr %l503
  br label %bb281
bb281:
  %t985 = load i1, ptr %l503, !tbaa !21
  br i1 %t985, label %bb282, label %bb283
bb282:
  store i1 true, ptr %l504, !tbaa !21
  br label %bb285
bb283:
  %t986 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t988 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v4, ptr %s19, { i64, ptr } %t986, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d45, i32 0, i32 1) })
  store i1 %t988, ptr %l506
  br label %bb284
bb284:
  %t989 = load i1, ptr %l506, !tbaa !21
  store i1 %t989, ptr %l504, !tbaa !21
  br label %bb285
bb285:
  %t990 = load i1, ptr %l504, !tbaa !21
  br i1 %t990, label %bb286, label %bb287
bb286:
  store %olang.scope zeroinitializer, ptr %s25
  %t991 = load ptr, ptr %l0, !tbaa !29
  %t992 = load %"compiler/source:Span", ptr %l4
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %s25, ptr %t991, %"compiler/source:Span" %t992, { i64, ptr } { i64 43, ptr getelementptr inbounds (<{ i64, [43 x i8] }>, ptr @.d46, i32 0, i32 1) })
  br label %bb288
bb287:
  store %olang.scope zeroinitializer, ptr %s26
  %t995 = load i32, ptr %l20, !tbaa !23
  store i32 %t995, ptr %l509, !tbaa !23
  %t996 = load ptr, ptr %l0, !tbaa !29
  %t998 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echarType(ptr %v0, ptr %t996)
  store i32 %t998, ptr %l511
  br label %bb289
bb288:
  call void @__olang_scope_close(ptr %s25)
  br label %bb310
bb289:
  %t999 = load i32, ptr %l509, !tbaa !23
  %t1000 = load i32, ptr %l511, !tbaa !23
  %t1001 = icmp eq i32 %t999, %t1000
  br i1 %t1001, label %bb290, label %bb291
bb290:
  %t1003 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t1005 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v4, ptr %s26, { i64, ptr } %t1003, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d47, i32 0, i32 1) })
  store i1 %t1005, ptr %l515
  br label %bb292
bb291:
  store i1 false, ptr %l513, !tbaa !21
  br label %bb297
bb292:
  %t1006 = load i1, ptr %l515, !tbaa !21
  br i1 %t1006, label %bb293, label %bb294
bb293:
  store i1 true, ptr %l516, !tbaa !21
  br label %bb296
bb294:
  %t1007 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t1009 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v4, ptr %s26, { i64, ptr } %t1007, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d48, i32 0, i32 1) })
  store i1 %t1009, ptr %l518
  br label %bb295
bb295:
  %t1010 = load i1, ptr %l518, !tbaa !21
  store i1 %t1010, ptr %l516, !tbaa !21
  br label %bb296
bb296:
  %t1011 = load i1, ptr %l516, !tbaa !21
  store i1 %t1011, ptr %l513, !tbaa !21
  br label %bb297
bb297:
  %t1012 = load i1, ptr %l513, !tbaa !21
  br i1 %t1012, label %bb298, label %bb299
bb298:
  store %olang.scope zeroinitializer, ptr %s27
  %t1013 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1013, ptr %l519, !tbaa !29
  %t1014 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t1014, ptr %l520
  %t1015 = load ptr, ptr %l0, !tbaa !29
  %t1016 = load i32, ptr %l3, !tbaa !23
  %t1019 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s27, ptr %t1015, i32 %t1016)
  store { i64, ptr } %t1019, ptr %l523
  br label %bb300
bb299:
  store %olang.scope zeroinitializer, ptr %s28
  %t1020 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1020, ptr %l528, !tbaa !29
  %t1021 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t1021, ptr %l529
  %t1022 = load i32, ptr %l10, !tbaa !23
  store i32 %t1022, ptr %l530, !tbaa !23
  %t1023 = load ptr, ptr %l0, !tbaa !29
  %t1024 = load i32, ptr %l3, !tbaa !23
  %t1027 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %s28, ptr %t1023, i32 %t1024)
  store { i64, ptr } %t1027, ptr %l533
  br label %bb303
bb300:
  %t1028 = load { i64, ptr }, ptr %l523, !tbaa !27
  %t1029 = extractvalue { i64, ptr } %t1028, 0
  %t1030 = extractvalue { i64, ptr } %t1028, 1
  %t1031 = mul i64 %t1029, 1
  %t1032 = call ptr @__olang_scope_alloc(ptr %s27, i64 %t1031)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1032, ptr %t1030, i64 %t1031, i1 false)
  %t1033 = insertvalue { i64, ptr } undef, i64 %t1029, 0
  %t1034 = insertvalue { i64, ptr } %t1033, ptr %t1032, 1
  %t1035 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t1038 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCharNoPad(ptr %s27, ptr %v4, ptr %s27, { i64, ptr } %t1034, { i64, ptr } %t1035)
  store %"compiler/msgs:Msg" %t1038, ptr %l526
  br label %bb301
bb301:
  %t1039 = load ptr, ptr %l519, !tbaa !29
  %t1040 = load %"compiler/source:Span", ptr %l520
  %t1041 = load %"compiler/msgs:Msg", ptr %l526
  %t1042 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s27, ptr %t1039, %"compiler/source:Span" %t1040, %"compiler/msgs:Msg" %t1041)
  store i64 %t1042, ptr %l527
  br label %bb302
bb302:
  call void @__olang_scope_close(ptr %s27)
  br label %bb309
bb303:
  %t1043 = load { i64, ptr }, ptr %l533, !tbaa !27
  %t1044 = extractvalue { i64, ptr } %t1043, 1
  %t1045 = extractvalue { i64, ptr } %t1043, 0
  %t1046 = call ptr @__olang_scope_alloc(ptr %s28, i64 %t1045)
  call void @olang_textcopy(ptr %t1046, ptr %t1044, i64 %t1045)
  %t1047 = insertvalue { i64, ptr } undef, i64 %t1045, 0
  %t1048 = insertvalue { i64, ptr } %t1047, ptr %t1046, 1
  %t1050 = extractvalue { i64, ptr } %t1048, 0
  %t1051 = extractvalue { i64, ptr } %t1048, 1
  %t1052 = mul i64 %t1050, 1
  %t1053 = call ptr @__olang_scope_alloc(ptr %s28, i64 %t1052)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1053, ptr %t1051, i64 %t1052, i1 false)
  %t1054 = insertvalue { i64, ptr } undef, i64 %t1050, 0
  %t1055 = insertvalue { i64, ptr } %t1054, ptr %t1053, 1
  store { i64, ptr } %t1055, ptr %l535, !tbaa !27
  %t1056 = load ptr, ptr %l0, !tbaa !29
  %t1057 = load i32, ptr %l10, !tbaa !23
  %t1060 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s28, ptr %t1056, i32 %t1057)
  store { i64, ptr } %t1060, ptr %l538
  br label %bb304
bb304:
  %t1061 = load { i64, ptr }, ptr %l538, !tbaa !27
  %t1062 = extractvalue { i64, ptr } %t1061, 0
  %t1063 = extractvalue { i64, ptr } %t1061, 1
  %t1064 = mul i64 %t1062, 1
  %t1065 = call ptr @__olang_scope_alloc(ptr %s28, i64 %t1064)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1065, ptr %t1063, i64 %t1064, i1 false)
  %t1066 = insertvalue { i64, ptr } undef, i64 %t1062, 0
  %t1067 = insertvalue { i64, ptr } %t1066, ptr %t1065, 1
  store { i64, ptr } %t1067, ptr %l539, !tbaa !27
  %t1068 = load ptr, ptr %l0, !tbaa !29
  %t1069 = load i32, ptr %l3, !tbaa !23
  %t1072 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s28, ptr %t1068, i32 %t1069)
  store { i64, ptr } %t1072, ptr %l542
  br label %bb305
bb305:
  %t1073 = load { i64, ptr }, ptr %l542, !tbaa !27
  %t1074 = extractvalue { i64, ptr } %t1073, 0
  %t1075 = extractvalue { i64, ptr } %t1073, 1
  %t1076 = mul i64 %t1074, 1
  %t1077 = call ptr @__olang_scope_alloc(ptr %s28, i64 %t1076)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1077, ptr %t1075, i64 %t1076, i1 false)
  %t1078 = insertvalue { i64, ptr } undef, i64 %t1074, 0
  %t1079 = insertvalue { i64, ptr } %t1078, ptr %t1077, 1
  store { i64, ptr } %t1079, ptr %l543, !tbaa !27
  %t1080 = load ptr, ptr %l0, !tbaa !29
  %t1081 = load i32, ptr %l10, !tbaa !23
  %t1082 = load i32, ptr %l3, !tbaa !23
  %t1086 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ememberHint(ptr %v0, ptr %s28, ptr %t1080, i32 %t1081, i32 %t1082, i1 true)
  store { i64, ptr } %t1086, ptr %l547
  br label %bb306
bb306:
  %t1087 = load { i64, ptr }, ptr %l547, !tbaa !27
  %t1088 = extractvalue { i64, ptr } %t1087, 0
  %t1089 = extractvalue { i64, ptr } %t1087, 1
  %t1090 = mul i64 %t1088, 1
  %t1091 = call ptr @__olang_scope_alloc(ptr %s28, i64 %t1090)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1091, ptr %t1089, i64 %t1090, i1 false)
  %t1092 = insertvalue { i64, ptr } undef, i64 %t1088, 0
  %t1093 = insertvalue { i64, ptr } %t1092, ptr %t1091, 1
  %t1094 = load { i64, ptr }, ptr %l539, !tbaa !27
  %t1095 = load { i64, ptr }, ptr %l543, !tbaa !27
  %t1097 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnknownMethod(ptr %s28, ptr %s28, ptr %s28, ptr %s28, { i64, ptr } %t1094, { i64, ptr } %t1095, { i64, ptr } %t1093)
  store %"compiler/msgs:Msg" %t1097, ptr %l549
  br label %bb307
bb307:
  %t1098 = load ptr, ptr %l528, !tbaa !29
  %t1099 = load %"compiler/source:Span", ptr %l529
  %t1100 = load i32, ptr %l530, !tbaa !23
  %t1101 = load { i64, ptr }, ptr %l535, !tbaa !27
  %t1102 = load %"compiler/msgs:Msg", ptr %l549
  %t1103 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eneedErr(ptr %v0, ptr %s28, ptr %s28, ptr %t1098, %"compiler/source:Span" %t1099, i32 %t1100, { i64, ptr } %t1101, %"compiler/msgs:Msg" %t1102)
  store i64 %t1103, ptr %l550
  br label %bb308
bb308:
  call void @__olang_scope_close(ptr %s28)
  br label %bb309
bb309:
  call void @__olang_scope_close(ptr %s26)
  br label %bb310
bb310:
  %t1104 = load ptr, ptr %l0, !tbaa !29
  %t1105 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v2, ptr %t1104, { i64, ptr } %t1105)
  br label %bb311
bb311:
  %t1108 = load ptr, ptr %l0, !tbaa !29
  %t1109 = load %"compiler/source:Span", ptr %l1
  %t1112 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v4, ptr %t1108, %"compiler/source:Span" %t1109)
  store ptr %t1112, ptr %l555
  br label %bb312
bb312:
  call void @__olang_scope_close(ptr %s19)
  call void @__olang_scope_close(ptr %s0)
  %t1113 = load ptr, ptr %l555, !tbaa !29
  store ptr %t1113, ptr %rv
  br label %ret
bb313:
  %t1114 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t1114, ptr %l556, !tbaa !27
  %t1115 = getelementptr { i64, ptr }, ptr %l556, i32 0, i32 1
  %t1116 = load ptr, ptr %t1115, !tbaa !27
  %t1117 = getelementptr i8, ptr %t1116, i64 0
  %t1118 = load i8, ptr %t1117, !tbaa !32
  %t1120 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %t1118)
  store i1 %t1120, ptr %l558
  br label %bb314
bb314:
  %t1121 = load i1, ptr %l558, !tbaa !21
  %t1122 = xor i1 %t1121, true
  br i1 %t1122, label %bb315, label %bb316
bb315:
  %t1124 = load ptr, ptr %l0, !tbaa !29
  %t1126 = getelementptr %"compiler/check:Checker", ptr %t1124, i32 0, i32 1
  %t1127 = load ptr, ptr %t1126, !tbaa !29
  %t1128 = load i64, ptr %l17, !tbaa !24
  %t1131 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t1127, i64 %t1128)
  store i64 %t1131, ptr %l564
  br label %bb317
bb316:
  store i1 false, ptr %l560, !tbaa !21
  br label %bb319
bb317:
  %t1132 = load ptr, ptr %l0, !tbaa !29
  %t1134 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t1132)
  store ptr %t1134, ptr %l566
  br label %bb318
bb318:
  %t1135 = load ptr, ptr %l566, !tbaa !29
  %t1137 = getelementptr %"compiler/check:frame", ptr %t1135, i32 0, i32 1
  %t1138 = load i64, ptr %t1137, !tbaa !24
  %t1139 = load i64, ptr %l564, !tbaa !24
  %t1141 = icmp ne i64 %t1139, %t1138
  store i1 %t1141, ptr %l560, !tbaa !21
  br label %bb319
bb319:
  %t1143 = load i1, ptr %l560, !tbaa !21
  br i1 %t1143, label %bb320, label %bb321
bb320:
  store %olang.scope zeroinitializer, ptr %s30
  %t1144 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1144, ptr %l570, !tbaa !29
  %t1145 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t1145, ptr %l571
  %t1146 = load ptr, ptr %l0, !tbaa !29
  %t1147 = load i32, ptr %l3, !tbaa !23
  %t1150 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s30, ptr %t1146, i32 %t1147)
  store { i64, ptr } %t1150, ptr %l574
  br label %bb322
bb321:
  br label %bb325
bb322:
  %t1151 = load { i64, ptr }, ptr %l574, !tbaa !27
  %t1152 = extractvalue { i64, ptr } %t1151, 0
  %t1153 = extractvalue { i64, ptr } %t1151, 1
  %t1154 = mul i64 %t1152, 1
  %t1155 = call ptr @__olang_scope_alloc(ptr %s30, i64 %t1154)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1155, ptr %t1153, i64 %t1154, i1 false)
  %t1156 = insertvalue { i64, ptr } undef, i64 %t1152, 0
  %t1157 = insertvalue { i64, ptr } %t1156, ptr %t1155, 1
  %t1159 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eMethodIsPrivate(ptr %s30, ptr %s30, { i64, ptr } %t1157)
  store %"compiler/msgs:Msg" %t1159, ptr %l576
  br label %bb323
bb323:
  %t1160 = load ptr, ptr %l570, !tbaa !29
  %t1161 = load %"compiler/source:Span", ptr %l571
  %t1162 = load %"compiler/msgs:Msg", ptr %l576
  %t1163 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s30, ptr %t1160, %"compiler/source:Span" %t1161, %"compiler/msgs:Msg" %t1162)
  store i64 %t1163, ptr %l577
  br label %bb324
bb324:
  call void @__olang_scope_close(ptr %s30)
  br label %bb325
bb325:
  %t1164 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1164, ptr %l578, !tbaa !29
  %t1165 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1165, ptr %l579
  %t1166 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1166, ptr %l580, !tbaa !29
  %t1167 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1167, ptr %l581
  %t1168 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t1168, ptr %l582
  %t1169 = load i64, ptr %l17, !tbaa !24
  store i64 %t1169, ptr %l583, !tbaa !24
  %t1170 = load ptr, ptr %l9, !tbaa !29
  store ptr %t1170, ptr %l585, !tbaa !29
  %t1172 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t1172, ptr %l586, !tbaa !27
  %t1173 = icmp sge i64 0, 0
  br i1 %t1173, label %bb326, label %bb327
bb326:
  %t1175 = icmp sle i64 0, 1152921504606846975
  br i1 %t1175, label %bb328, label %bb329
bb327:
  call void @__olang_check_failed(ptr @olang_loc_97297cf958301a5_897be3a3c1a33231)
  unreachable
bb328:
  %t1177 = mul i64 0, 8
  %t1178 = insertvalue { i64, ptr } undef, i64 0, 0
  %t1179 = insertvalue { i64, ptr } %t1178, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t1179, ptr %l589, !tbaa !27
  %t1180 = icmp sge i64 0, 0
  br i1 %t1180, label %bb330, label %bb331
bb329:
  call void @__olang_check_failed(ptr @olang_loc_97297cf958301a5_897be3a3c1a33231)
  unreachable
bb330:
  %t1182 = icmp sle i64 0, 2305843009213693951
  br i1 %t1182, label %bb332, label %bb333
bb331:
  call void @__olang_check_failed(ptr @olang_loc_f4ec2e4bc4870738_831a294d3dfd1224)
  unreachable
bb332:
  %t1184 = mul i64 0, 4
  %t1185 = insertvalue { i64, ptr } undef, i64 0, 0
  %t1186 = insertvalue { i64, ptr } %t1185, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t1187 = load ptr, ptr %l580, !tbaa !29
  %t1188 = load %"compiler/source:Span", ptr %l581
  %t1189 = load %"compiler/source:Span", ptr %l582
  %t1190 = load i64, ptr %l583, !tbaa !24
  %t1191 = load ptr, ptr %l585, !tbaa !29
  %t1192 = load { i64, ptr }, ptr %l586, !tbaa !27
  %t1193 = load { i64, ptr }, ptr %l589, !tbaa !27
  %t1195 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v4, ptr %v2, ptr %v0, ptr %v0, ptr %v0, ptr %t1187, %"compiler/source:Span" %t1188, %"compiler/source:Span" %t1189, i64 %t1190, ptr %t1191, { i64, ptr } %t1192, { i64, ptr } %t1193, { i64, ptr } %t1186)
  store ptr %t1195, ptr %l593
  br label %bb334
bb333:
  call void @__olang_check_failed(ptr @olang_loc_f4ec2e4bc4870738_831a294d3dfd1224)
  unreachable
bb334:
  %t1196 = load ptr, ptr %l578, !tbaa !29
  %t1197 = load %"compiler/source:Span", ptr %l579
  %t1198 = load ptr, ptr %l593, !tbaa !29
  %t1199 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einPlaceCall(ptr %v0, ptr %v0, ptr %v4, ptr %t1196, %"compiler/source:Span" %t1197, ptr %t1198)
  store ptr %t1199, ptr %l594
  br label %bb335
bb335:
  call void @__olang_scope_close(ptr %s0)
  %t1200 = load ptr, ptr %l594, !tbaa !29
  store ptr %t1200, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enegate(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l8 = alloca ptr
  %rv = alloca ptr
  br label %start
start:
  br label %bb0
bb0:
  %t3 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t10 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v1, ptr %v0, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, i32 %t3, i32 2, ptr %a2, ptr null)
  store ptr %t10, ptr %l8
  br label %bb1
bb1:
  %t11 = load ptr, ptr %l8, !tbaa !29
  store ptr %t11, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoperatorCall(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, ptr %a4, ptr %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i32
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l14 = alloca i1
  %l16 = alloca ptr
  %l19 = alloca i32
  %l20 = alloca i32
  %l23 = alloca i1
  %l26 = alloca ptr
  %l27 = alloca i32
  %l28 = alloca { i64, ptr }
  %l29 = alloca %"compiler/source:Span"
  %l31 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l34 = alloca i64
  %l38 = alloca ptr
  %l39 = alloca ptr
  %l43 = alloca ptr
  %l46 = alloca { i64, ptr }
  %l49 = alloca i1
  %l52 = alloca ptr
  %l53 = alloca %"compiler/source:Span"
  %l54 = alloca %"compiler/source:Span"
  %l55 = alloca i64
  %l57 = alloca ptr
  %l60 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %l67 = alloca ptr
  %l70 = alloca ptr
  %l74 = alloca ptr
  %l78 = alloca ptr
  %l79 = alloca %"compiler/source:Span"
  %l80 = alloca %"compiler/source:Span"
  %l81 = alloca i64
  %l83 = alloca ptr
  %l86 = alloca { i64, ptr }
  %l89 = alloca { i64, ptr }
  %l93 = alloca ptr
  %l96 = alloca ptr
  %l100 = alloca ptr
  %s0 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  store i32 %a3, ptr %l3
  store ptr %a4, ptr %l4
  store ptr %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t3 = call { i64, ptr } @compiler_2fcheck_2eoperatorName(ptr %s0, i32 %t1)
  store { i64, ptr } %t3, ptr %l12
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t4, ptr %l6, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t7 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t5, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d49, i32 0, i32 1) })
  store i1 %t7, ptr %l14
  br label %bb2
bb2:
  %t8 = load i1, ptr %l14, !tbaa !21
  br i1 %t8, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l16, !tbaa !29
  %t11 = load ptr, ptr %l4, !tbaa !29
  %t14 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t11)
  store i32 %t14, ptr %l19
  br label %bb6
bb6:
  %t15 = load ptr, ptr %l16, !tbaa !29
  %t16 = load i32, ptr %l19, !tbaa !23
  %t17 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t15, i32 %t16)
  store i32 %t17, ptr %l20
  br label %bb7
bb7:
  %t18 = load i32, ptr %l20, !tbaa !23
  store i32 %t18, ptr %l7, !tbaa !23
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t20 = load i32, ptr %l7, !tbaa !23
  %t23 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t19, i32 %t20)
  store i1 %t23, ptr %l23
  br label %bb8
bb8:
  %t24 = load i1, ptr %l23, !tbaa !21
  %t25 = xor i1 %t24, true
  br i1 %t25, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t28 = load ptr, ptr %l0, !tbaa !29
  store ptr %t28, ptr %l26, !tbaa !29
  %t29 = load i32, ptr %l7, !tbaa !23
  store i32 %t29, ptr %l27, !tbaa !23
  %t30 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t30, ptr %l28, !tbaa !27
  %t31 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t31, ptr %l29
  %t32 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t34 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s0, i32 %t32)
  store { i64, ptr } %t34, ptr %l31
  br label %bb12
bb12:
  %t35 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t36 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %s0, ptr %s0, { i64, ptr } %t35)
  store { i64, ptr } %t36, ptr %l32
  br label %bb13
bb13:
  %t37 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t37, 0
  %t39 = extractvalue { i64, ptr } %t37, 1
  %t40 = mul i64 %t38, 1
  %t41 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t40)
  call void @llvm.memcpy.p0.p0.i64(ptr %t41, ptr %t39, i64 %t40, i1 false)
  %t42 = insertvalue { i64, ptr } undef, i64 %t38, 0
  %t43 = insertvalue { i64, ptr } %t42, ptr %t41, 1
  %t44 = load ptr, ptr %l26, !tbaa !29
  %t45 = load i32, ptr %l27, !tbaa !23
  %t46 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t47 = load %"compiler/source:Span", ptr %l29
  %t49 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleUse(ptr %v0, ptr %s0, ptr %s0, ptr %t44, i32 %t45, { i64, ptr } %t46, i64 1, %"compiler/source:Span" %t47, { i64, ptr } %t43)
  store i64 %t49, ptr %l34
  br label %bb14
bb14:
  %t50 = load i64, ptr %l34, !tbaa !24
  store i64 %t50, ptr %l8, !tbaa !24
  %t51 = load i64, ptr %l8, !tbaa !24
  %t53 = icmp slt i64 %t51, 0
  br i1 %t53, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t56 = load ptr, ptr %l0, !tbaa !29
  store ptr %t56, ptr %l38, !tbaa !29
  %t57 = load ptr, ptr %l0, !tbaa !29
  store ptr %t57, ptr %l39, !tbaa !29
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/check:Checker", ptr %t58, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !29
  %t62 = load i64, ptr %l8, !tbaa !24
  %t65 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %s0, ptr %t61, i64 %t62)
  store ptr %t65, ptr %l43
  br label %bb18
bb18:
  %t66 = load ptr, ptr %l43, !tbaa !29
  %t68 = getelementptr %"compiler/ast:Func", ptr %t66, i32 0, i32 2
  %t69 = load i32, ptr %t68, !tbaa !23
  %t70 = load ptr, ptr %l39, !tbaa !29
  %t72 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t70, i32 %t69)
  store { i64, ptr } %t72, ptr %l46
  br label %bb19
bb19:
  %t73 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t74 = load ptr, ptr %l38, !tbaa !29
  %t75 = getelementptr %"compiler/check:Checker", ptr %t74, i32 0, i32 50
  store { i64, ptr } %t73, ptr %t75, !tbaa !27
  %t76 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t78 = trunc i64 83 to i32
  %t79 = icmp eq i32 %t76, %t78
  br i1 %t79, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l49, !tbaa !21
  br label %bb22
bb21:
  %t81 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t83 = trunc i64 82 to i32
  %t84 = icmp eq i32 %t81, %t83
  store i1 %t84, ptr %l49, !tbaa !21
  br label %bb22
bb22:
  %t86 = load i1, ptr %l49, !tbaa !21
  br i1 %t86, label %bb23, label %bb24
bb23:
  %t87 = load ptr, ptr %l0, !tbaa !29
  store ptr %t87, ptr %l52, !tbaa !29
  %t88 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t88, ptr %l53
  %t89 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t89, ptr %l54
  %t90 = load i64, ptr %l8, !tbaa !24
  store i64 %t90, ptr %l55, !tbaa !24
  %t91 = load ptr, ptr %l5, !tbaa !29
  store ptr %t91, ptr %l57, !tbaa !29
  %t93 = icmp sge i64 0, 0
  br i1 %t93, label %bb25, label %bb26
bb24:
  br label %bb39
bb25:
  %t95 = icmp sle i64 0, 1152921504606846975
  br i1 %t95, label %bb27, label %bb28
bb26:
  call void @__olang_check_failed(ptr @olang_loc_9311a1fdea965308_123228c6f8b4663c)
  unreachable
bb27:
  %t97 = mul i64 0, 8
  %t98 = insertvalue { i64, ptr } undef, i64 0, 0
  %t99 = insertvalue { i64, ptr } %t98, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t99, ptr %l60, !tbaa !27
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t101 = load ptr, ptr %l4, !tbaa !29
  %t104 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eone(ptr %v0, ptr %v1, ptr %v0, ptr %t100, ptr %t101)
  store { i64, ptr } %t104, ptr %l63
  br label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_9311a1fdea965308_123228c6f8b4663c)
  unreachable
bb29:
  %t105 = icmp sge i64 0, 0
  br i1 %t105, label %bb30, label %bb31
bb30:
  %t107 = icmp sle i64 0, 2305843009213693951
  br i1 %t107, label %bb32, label %bb33
bb31:
  call void @__olang_check_failed(ptr @olang_loc_6fa6db75017b9575_1d827b27b68e8189)
  unreachable
bb32:
  %t109 = mul i64 0, 4
  %t110 = insertvalue { i64, ptr } undef, i64 0, 0
  %t111 = insertvalue { i64, ptr } %t110, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t112 = load ptr, ptr %l52, !tbaa !29
  %t113 = load %"compiler/source:Span", ptr %l53
  %t114 = load %"compiler/source:Span", ptr %l54
  %t115 = load i64, ptr %l55, !tbaa !24
  %t116 = load ptr, ptr %l57, !tbaa !29
  %t117 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t118 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t120 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v2, ptr %v0, ptr %v0, ptr %v3, ptr %v3, ptr %t112, %"compiler/source:Span" %t113, %"compiler/source:Span" %t114, i64 %t115, ptr %t116, { i64, ptr } %t117, { i64, ptr } %t118, { i64, ptr } %t111)
  store ptr %t120, ptr %l67
  br label %bb34
bb33:
  call void @__olang_check_failed(ptr @olang_loc_6fa6db75017b9575_1d827b27b68e8189)
  unreachable
bb34:
  %t121 = load ptr, ptr %l67, !tbaa !29
  store ptr %t121, ptr %l9, !tbaa !29
  %t122 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t124 = trunc i64 82 to i32
  %t125 = icmp eq i32 %t122, %t124
  br i1 %t125, label %bb35, label %bb36
bb35:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t128 = load %"compiler/source:Span", ptr %l1
  %t129 = load ptr, ptr %l9, !tbaa !29
  %t133 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enegate(ptr %v0, ptr %v3, ptr %v3, ptr %t127, %"compiler/source:Span" %t128, ptr %t129)
  store ptr %t133, ptr %l74
  br label %bb37
bb36:
  %t134 = load ptr, ptr %l9, !tbaa !29
  store ptr %t134, ptr %l70, !tbaa !29
  br label %bb38
bb37:
  %t137 = load ptr, ptr %l74, !tbaa !29
  store ptr %t137, ptr %l70, !tbaa !29
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s0)
  %t139 = load ptr, ptr %l70, !tbaa !29
  store ptr %t139, ptr %rv
  br label %ret
bb39:
  %t140 = load ptr, ptr %l0, !tbaa !29
  store ptr %t140, ptr %l78, !tbaa !29
  %t141 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t141, ptr %l79
  %t142 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t142, ptr %l80
  %t143 = load i64, ptr %l8, !tbaa !24
  store i64 %t143, ptr %l81, !tbaa !24
  %t144 = load ptr, ptr %l4, !tbaa !29
  store ptr %t144, ptr %l83, !tbaa !29
  %t146 = icmp sge i64 0, 0
  br i1 %t146, label %bb40, label %bb41
bb40:
  %t148 = icmp sle i64 0, 1152921504606846975
  br i1 %t148, label %bb42, label %bb43
bb41:
  call void @__olang_check_failed(ptr @olang_loc_53860b63ce2a3756_eab450cf1ae092ca)
  unreachable
bb42:
  %t150 = mul i64 0, 8
  %t151 = insertvalue { i64, ptr } undef, i64 0, 0
  %t152 = insertvalue { i64, ptr } %t151, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t152, ptr %l86, !tbaa !27
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t154 = load ptr, ptr %l5, !tbaa !29
  %t157 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eone(ptr %v0, ptr %v2, ptr %v0, ptr %t153, ptr %t154)
  store { i64, ptr } %t157, ptr %l89
  br label %bb44
bb43:
  call void @__olang_check_failed(ptr @olang_loc_53860b63ce2a3756_eab450cf1ae092ca)
  unreachable
bb44:
  %t158 = icmp sge i64 0, 0
  br i1 %t158, label %bb45, label %bb46
bb45:
  %t160 = icmp sle i64 0, 2305843009213693951
  br i1 %t160, label %bb47, label %bb48
bb46:
  call void @__olang_check_failed(ptr @olang_loc_6fa6db75017b9575_1d827b27b68e8189)
  unreachable
bb47:
  %t162 = mul i64 0, 4
  %t163 = insertvalue { i64, ptr } undef, i64 0, 0
  %t164 = insertvalue { i64, ptr } %t163, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t165 = load ptr, ptr %l78, !tbaa !29
  %t166 = load %"compiler/source:Span", ptr %l79
  %t167 = load %"compiler/source:Span", ptr %l80
  %t168 = load i64, ptr %l81, !tbaa !24
  %t169 = load ptr, ptr %l83, !tbaa !29
  %t170 = load { i64, ptr }, ptr %l86, !tbaa !27
  %t171 = load { i64, ptr }, ptr %l89, !tbaa !27
  %t173 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v1, ptr %v0, ptr %v0, ptr %v3, ptr %v3, ptr %t165, %"compiler/source:Span" %t166, %"compiler/source:Span" %t167, i64 %t168, ptr %t169, { i64, ptr } %t170, { i64, ptr } %t171, { i64, ptr } %t164)
  store ptr %t173, ptr %l93
  br label %bb49
bb48:
  call void @__olang_check_failed(ptr @olang_loc_6fa6db75017b9575_1d827b27b68e8189)
  unreachable
bb49:
  %t174 = load ptr, ptr %l93, !tbaa !29
  store ptr %t174, ptr %l10, !tbaa !29
  %t175 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t177 = trunc i64 84 to i32
  %t178 = icmp eq i32 %t175, %t177
  br i1 %t178, label %bb50, label %bb51
bb50:
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t181 = load %"compiler/source:Span", ptr %l1
  %t182 = load ptr, ptr %l10, !tbaa !29
  %t186 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enegate(ptr %v0, ptr %v3, ptr %v3, ptr %t180, %"compiler/source:Span" %t181, ptr %t182)
  store ptr %t186, ptr %l100
  br label %bb52
bb51:
  %t187 = load ptr, ptr %l10, !tbaa !29
  store ptr %t187, ptr %l96, !tbaa !29
  br label %bb53
bb52:
  %t190 = load ptr, ptr %l100, !tbaa !29
  store ptr %t190, ptr %l96, !tbaa !29
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s0)
  %t192 = load ptr, ptr %l96, !tbaa !29
  store ptr %t192, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparamWritten(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l1 = alloca ptr
  %l3 = alloca ptr
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l3, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t4 = getelementptr %"compiler/ast:Param", ptr %t2, i32 0, i32 2
  %t5 = load ptr, ptr %t4, !tbaa !29
  %t7 = icmp eq ptr %t5, null
  br i1 %t7, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_70239da7d97117f8_be3796eb66d568d4)
  unreachable
bb2:
  br label %bb3
bb3:
  %t9 = load ptr, ptr %l1, !tbaa !29
  %t11 = getelementptr %"compiler/ast:Param", ptr %t9, i32 0, i32 2
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emutParam(ptr %v0, ptr %v1, ptr %t14, ptr %t12, i32 %a2)
  br label %bb4
bb4:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplaceName(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i1
  %l12 = alloca ptr
  %l14 = alloca %"compiler/typed:Local"
  %l16 = alloca ptr
  %l17 = alloca i1
  %rv = alloca i32
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb8
bb5:
  %t18 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %a0)
  store ptr %t18, ptr %l12
  br label %bb6
bb6:
  %t19 = load i32, ptr %l2, !tbaa !23
  %t20 = load ptr, ptr %l12, !tbaa !29
  %t22 = call %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %t20, i32 %t19)
  store %"compiler/typed:Local" %t22, ptr %l14
  br label %bb7
bb7:
  %t23 = getelementptr %"compiler/typed:Local", ptr %l14, i32 0, i32 0
  %t24 = load i32, ptr %t23, !tbaa !23
  store i32 %t24, ptr %l4, !tbaa !23
  br label %bb19
bb8:
  %t26 = load ptr, ptr %l1, !tbaa !29
  store ptr %t26, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t27 = load ptr, ptr %l16, !tbaa !29
  %t28 = icmp ne ptr %t27, null
  br i1 %t28, label %bb9, label %bb10
bb9:
  %t30 = load ptr, ptr %l16, !tbaa !29
  %t31 = load i64, ptr %t30, !range !{i64 0, i64 8}
  %t33 = icmp eq i64 %t31, 1
  store i1 %t33, ptr %l17, !tbaa !21
  br label %bb10
bb10:
  %t34 = load i1, ptr %l17, !tbaa !21
  br i1 %t34, label %bb11, label %bb12
bb11:
  %t35 = load ptr, ptr %l1, !tbaa !29
  %t37 = getelementptr { i64, [4 x i64] }, ptr %t35, i32 0, i32 1
  %t38 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t37, i32 0, i32 3
  %t39 = load i32, ptr %t38
  store i32 %t39, ptr %l3, !tbaa !23
  br label %bb13
bb12:
  br label %bb14
bb13:
  %t41 = load i32, ptr %l3, !tbaa !23
  store i32 %t41, ptr %l4, !tbaa !23
  br label %bb19
bb14:
  br i1 true, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  store i32 0, ptr %l4, !tbaa !23
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_1f453287a90ee701_f75bf1e5be6f432d)
  unreachable
bb19:
  %t43 = load i32, ptr %l4, !tbaa !23
  store i32 %t43, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplaceWritable(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i1
  %l11 = alloca ptr
  %l12 = alloca i1
  %l18 = alloca ptr
  %l20 = alloca %"compiler/typed:Local"
  %l23 = alloca i1
  %l24 = alloca ptr
  %l26 = alloca ptr
  %l28 = alloca %"compiler/typed:Local"
  %l30 = alloca i1
  %l33 = alloca i1
  %l37 = alloca i1
  %l39 = alloca ptr
  %l40 = alloca i1
  %l51 = alloca ptr
  %l53 = alloca i1
  %l58 = alloca ptr
  %l64 = alloca i1
  %l65 = alloca ptr
  %l66 = alloca i1
  %l73 = alloca ptr
  %l76 = alloca i32
  %l77 = alloca i64
  %l81 = alloca ptr
  %l82 = alloca i1
  %l89 = alloca i1
  %l90 = alloca ptr
  %l91 = alloca i1
  %l99 = alloca i1
  %l100 = alloca ptr
  %l101 = alloca i1
  %l109 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t2 = load ptr, ptr %l11, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l11, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l12, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l12, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb18
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t16)
  store ptr %t18, ptr %l18
  br label %bb6
bb6:
  %t19 = load i32, ptr %l2, !tbaa !23
  %t20 = load ptr, ptr %l18, !tbaa !29
  %t22 = call %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %t20, i32 %t19)
  store %"compiler/typed:Local" %t22, ptr %l20
  br label %bb7
bb7:
  %t23 = getelementptr %"compiler/typed:Local", ptr %l20, i32 0, i32 4
  %t24 = load i32, ptr %t23, !range !{i32 0, i32 7}
  %t26 = trunc i64 5 to i32
  %t27 = icmp eq i32 %t24, %t26
  br i1 %t27, label %bb8, label %bb9
bb8:
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l24, !tbaa !29
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t30)
  store ptr %t32, ptr %l26
  br label %bb10
bb9:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb13
bb10:
  %t33 = load i32, ptr %l2, !tbaa !23
  %t34 = load ptr, ptr %l26, !tbaa !29
  %t36 = call %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %t34, i32 %t33)
  store %"compiler/typed:Local" %t36, ptr %l28
  br label %bb11
bb11:
  %t37 = getelementptr %"compiler/typed:Local", ptr %l28, i32 0, i32 2
  %t38 = load i32, ptr %t37, !tbaa !23
  %t39 = load ptr, ptr %l24, !tbaa !29
  %t41 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t39, i32 %t38)
  store i1 %t41, ptr %l30
  br label %bb12
bb12:
  %t42 = load i1, ptr %l30, !tbaa !21
  %t43 = xor i1 %t42, true
  store i1 %t43, ptr %l23, !tbaa !21
  br label %bb13
bb13:
  %t45 = load i1, ptr %l23, !tbaa !21
  %t46 = xor i1 %t45, true
  br i1 %t46, label %bb14, label %bb15
bb14:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = load i32, ptr %l2, !tbaa !23
  %t51 = sext i32 %t49 to i64
  %t54 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroLocal(ptr %v0, ptr %t48, i64 %t51)
  store i1 %t54, ptr %l37
  br label %bb16
bb15:
  store i1 false, ptr %l33, !tbaa !21
  br label %bb17
bb16:
  %t55 = load i1, ptr %l37, !tbaa !21
  %t56 = xor i1 %t55, true
  store i1 %t56, ptr %l33, !tbaa !21
  br label %bb17
bb17:
  %t58 = load i1, ptr %l33, !tbaa !21
  store i1 %t58, ptr %l10, !tbaa !21
  br label %bb67
bb18:
  %t59 = load ptr, ptr %l1, !tbaa !29
  store ptr %t59, ptr %l39, !tbaa !29
  store i1 false, ptr %l40, !tbaa !21
  %t60 = load ptr, ptr %l39, !tbaa !29
  %t61 = icmp ne ptr %t60, null
  br i1 %t61, label %bb19, label %bb20
bb19:
  %t63 = load ptr, ptr %l39, !tbaa !29
  %t64 = load i64, ptr %t63, !range !{i64 0, i64 8}
  %t66 = icmp eq i64 %t64, 1
  store i1 %t66, ptr %l40, !tbaa !21
  br label %bb20
bb20:
  %t67 = load i1, ptr %l40, !tbaa !21
  br i1 %t67, label %bb21, label %bb22
bb21:
  %t68 = load ptr, ptr %l1, !tbaa !29
  %t70 = getelementptr { i64, [4 x i64] }, ptr %t68, i32 0, i32 1
  %t71 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t70, i32 0, i32 2
  %t72 = load i64, ptr %t71
  store i64 %t72, ptr %l3, !tbaa !24
  %t74 = load ptr, ptr %l1, !tbaa !29
  %t76 = getelementptr { i64, [4 x i64] }, ptr %t74, i32 0, i32 1
  %t77 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t76, i32 0, i32 3
  %t78 = load i32, ptr %t77
  store i32 %t78, ptr %l4, !tbaa !23
  br label %bb23
bb22:
  br label %bb33
bb23:
  store %olang.scope zeroinitializer, ptr %s2
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/check:Checker", ptr %t80, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !29
  %t84 = load i64, ptr %l3, !tbaa !24
  %t85 = load i32, ptr %l4, !tbaa !23
  %t89 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eGlobalDecl(ptr %v0, ptr %s2, ptr %t83, i64 %t84, i32 %t85)
  store ptr %t89, ptr %l51
  br label %bb24
bb24:
  %t90 = load ptr, ptr %l51, !tbaa !29
  %t91 = icmp eq ptr %t90, null
  br i1 %t91, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l53, !tbaa !21
  br label %bb32
bb26:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/check:Checker", ptr %t93, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !29
  %t97 = load i64, ptr %l3, !tbaa !24
  %t98 = load i32, ptr %l4, !tbaa !23
  %t102 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eGlobalDecl(ptr %v0, ptr %v0, ptr %t96, i64 %t97, i32 %t98)
  store ptr %t102, ptr %l58
  br label %bb27
bb27:
  %t103 = load ptr, ptr %l58, !tbaa !29
  store ptr %t103, ptr %l5, !tbaa !29
  %t104 = load ptr, ptr %l5, !tbaa !29
  %t106 = icmp eq ptr %t104, null
  br i1 %t106, label %bb28, label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_24dda45681d8cee1_6133aaee564c4ee5)
  unreachable
bb29:
  br label %bb30
bb30:
  %t108 = load ptr, ptr %l5, !tbaa !29
  %t111 = getelementptr %"compiler/ast:VarDecl", ptr %t108, i32 0, i32 2
  %t112 = load ptr, ptr %t111, !tbaa !29
  %t114 = call i1 @compiler_2fcheck_2ewrittenMut(ptr %v0, ptr %t112)
  store i1 %t114, ptr %l64
  br label %bb31
bb31:
  %t115 = load i1, ptr %l64, !tbaa !21
  store i1 %t115, ptr %l53, !tbaa !21
  br label %bb32
bb32:
  %t116 = load i1, ptr %l53, !tbaa !21
  store i1 %t116, ptr %l10, !tbaa !21
  call void @__olang_scope_close(ptr %s2)
  br label %bb67
bb33:
  %t117 = load ptr, ptr %l1, !tbaa !29
  store ptr %t117, ptr %l65, !tbaa !29
  store i1 false, ptr %l66, !tbaa !21
  %t118 = load ptr, ptr %l65, !tbaa !29
  %t119 = icmp ne ptr %t118, null
  br i1 %t119, label %bb34, label %bb35
bb34:
  %t121 = load ptr, ptr %l65, !tbaa !29
  %t122 = load i64, ptr %t121, !range !{i64 0, i64 8}
  %t124 = icmp eq i64 %t122, 2
  store i1 %t124, ptr %l66, !tbaa !21
  br label %bb35
bb35:
  %t125 = load i1, ptr %l66, !tbaa !21
  br i1 %t125, label %bb36, label %bb37
bb36:
  %t126 = load ptr, ptr %l1, !tbaa !29
  %t128 = getelementptr { i64, [4 x i64] }, ptr %t126, i32 0, i32 1
  %t129 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t128, i32 0, i32 2
  %t130 = load ptr, ptr %t129
  store ptr %t130, ptr %l6, !tbaa !29
  br label %bb38
bb37:
  br label %bb41
bb38:
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t134 = getelementptr %"compiler/check:Checker", ptr %t132, i32 0, i32 1
  %t135 = load ptr, ptr %t134, !tbaa !29
  %t137 = getelementptr %"compiler/generic:Program", ptr %t135, i32 0, i32 2
  store ptr %t137, ptr %l73, !tbaa !29
  %t138 = load ptr, ptr %l6, !tbaa !29
  %t141 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t138)
  store i32 %t141, ptr %l76
  br label %bb39
bb39:
  %t142 = load ptr, ptr %l73, !tbaa !29
  %t143 = load i32, ptr %l76, !tbaa !23
  %t144 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t142, i32 %t143)
  store i64 %t144, ptr %l77
  br label %bb40
bb40:
  %t145 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t146 = load i64, ptr %l77, !tbaa !24
  %t148 = and i64 %t146, %t145
  %t150 = icmp ne i64 %t148, 0
  store i1 %t150, ptr %l10, !tbaa !21
  br label %bb67
bb41:
  %t152 = load ptr, ptr %l1, !tbaa !29
  store ptr %t152, ptr %l81, !tbaa !29
  store i1 false, ptr %l82, !tbaa !21
  %t153 = load ptr, ptr %l81, !tbaa !29
  %t154 = icmp ne ptr %t153, null
  br i1 %t154, label %bb42, label %bb43
bb42:
  %t156 = load ptr, ptr %l81, !tbaa !29
  %t157 = load i64, ptr %t156, !range !{i64 0, i64 8}
  %t159 = icmp eq i64 %t157, 3
  store i1 %t159, ptr %l82, !tbaa !21
  br label %bb43
bb43:
  %t160 = load i1, ptr %l82, !tbaa !21
  br i1 %t160, label %bb44, label %bb45
bb44:
  %t161 = load ptr, ptr %l1, !tbaa !29
  %t163 = getelementptr { i64, [4 x i64] }, ptr %t161, i32 0, i32 1
  %t164 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t163, i32 0, i32 2
  %t165 = load ptr, ptr %t164
  store ptr %t165, ptr %l7, !tbaa !29
  br label %bb46
bb45:
  br label %bb48
bb46:
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t168 = load ptr, ptr %l7, !tbaa !29
  %t171 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplaceWritable(ptr %v0, ptr %v1, ptr %t167, ptr %t168)
  store i1 %t171, ptr %l89
  br label %bb47
bb47:
  %t172 = load i1, ptr %l89, !tbaa !21
  store i1 %t172, ptr %l10, !tbaa !21
  br label %bb67
bb48:
  %t173 = load ptr, ptr %l1, !tbaa !29
  store ptr %t173, ptr %l90, !tbaa !29
  store i1 false, ptr %l91, !tbaa !21
  %t174 = load ptr, ptr %l90, !tbaa !29
  %t175 = icmp ne ptr %t174, null
  br i1 %t175, label %bb49, label %bb50
bb49:
  %t177 = load ptr, ptr %l90, !tbaa !29
  %t178 = load i64, ptr %t177, !range !{i64 0, i64 8}
  %t180 = icmp eq i64 %t178, 4
  store i1 %t180, ptr %l91, !tbaa !21
  br label %bb50
bb50:
  %t181 = load i1, ptr %l91, !tbaa !21
  br i1 %t181, label %bb51, label %bb52
bb51:
  %t182 = load ptr, ptr %l1, !tbaa !29
  %t184 = getelementptr { i64, [4 x i64] }, ptr %t182, i32 0, i32 1
  %t185 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t184, i32 0, i32 2
  %t186 = load ptr, ptr %t185
  store ptr %t186, ptr %l8, !tbaa !29
  br label %bb53
bb52:
  br label %bb55
bb53:
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t189 = load ptr, ptr %l8, !tbaa !29
  %t191 = getelementptr %"compiler/typed:Elem", ptr %t189, i32 0, i32 0
  %t192 = load ptr, ptr %t191, !tbaa !29
  %t195 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplaceWritable(ptr %v0, ptr %v1, ptr %t188, ptr %t192)
  store i1 %t195, ptr %l99
  br label %bb54
bb54:
  %t196 = load i1, ptr %l99, !tbaa !21
  store i1 %t196, ptr %l10, !tbaa !21
  br label %bb67
bb55:
  %t197 = load ptr, ptr %l1, !tbaa !29
  store ptr %t197, ptr %l100, !tbaa !29
  store i1 false, ptr %l101, !tbaa !21
  %t198 = load ptr, ptr %l100, !tbaa !29
  %t199 = icmp ne ptr %t198, null
  br i1 %t199, label %bb56, label %bb57
bb56:
  %t201 = load ptr, ptr %l100, !tbaa !29
  %t202 = load i64, ptr %t201, !range !{i64 0, i64 8}
  %t204 = icmp eq i64 %t202, 5
  store i1 %t204, ptr %l101, !tbaa !21
  br label %bb57
bb57:
  %t205 = load i1, ptr %l101, !tbaa !21
  br i1 %t205, label %bb58, label %bb59
bb58:
  %t206 = load ptr, ptr %l1, !tbaa !29
  %t208 = getelementptr { i64, [4 x i64] }, ptr %t206, i32 0, i32 1
  %t209 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t208, i32 0, i32 2
  %t210 = load ptr, ptr %t209
  store ptr %t210, ptr %l9, !tbaa !29
  br label %bb60
bb59:
  br label %bb62
bb60:
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t213 = load ptr, ptr %l9, !tbaa !29
  %t215 = getelementptr %"compiler/typed:Payload", ptr %t213, i32 0, i32 0
  %t216 = load ptr, ptr %t215, !tbaa !29
  %t219 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplaceWritable(ptr %v0, ptr %v1, ptr %t212, ptr %t216)
  store i1 %t219, ptr %l109
  br label %bb61
bb61:
  %t220 = load i1, ptr %l109, !tbaa !21
  store i1 %t220, ptr %l10, !tbaa !21
  br label %bb67
bb62:
  br i1 true, label %bb63, label %bb64
bb63:
  br label %bb65
bb64:
  br label %bb66
bb65:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb67
bb66:
  call void @__olang_check_failed(ptr @olang_loc_f10316e290a7e1b9_b7814005b7d82bcd)
  unreachable
bb67:
  %t221 = load i1, ptr %l10, !tbaa !21
  store i1 %t221, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca ptr
  %l11 = alloca i1
  %l14 = alloca i1
  %l19 = alloca i64
  %l27 = alloca ptr
  %l30 = alloca ptr
  %l31 = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l3, !tbaa !29
  store ptr %t4, ptr %l1, !tbaa !29
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = getelementptr %"compiler/check:frame", ptr %t5, i32 0, i32 25
  %t8 = load i1, ptr %t7, !tbaa !21
  br i1 %t8, label %bb2, label %bb3
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esettle(ptr %v0, ptr %v0, ptr %t10, ptr %t11)
  br label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb5
bb5:
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr %"compiler/check:frame", ptr %t14, i32 0, i32 0
  %t17 = load i64, ptr %t16, !tbaa !24
  %t19 = icmp sge i64 %t17, 0
  br i1 %t19, label %bb6, label %bb7
bb6:
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr %"compiler/check:frame", ptr %t21, i32 0, i32 18
  %t24 = load i1, ptr %t23, !tbaa !21
  br i1 %t24, label %bb8, label %bb9
bb7:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb12
bb8:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb11
bb9:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/check:Checker", ptr %t26, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t31 = getelementptr %"compiler/generic:Program", ptr %t29, i32 0, i32 0
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t34 = getelementptr %"compiler/load:Loader", ptr %t32, i32 0, i32 4
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t37 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCount(ptr %v0, ptr %t35)
  store i64 %t37, ptr %l19
  br label %bb10
bb10:
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t40 = getelementptr %"compiler/check:frame", ptr %t38, i32 0, i32 40
  %t41 = load i64, ptr %t40, !tbaa !24
  %t42 = load i64, ptr %l19, !tbaa !24
  %t44 = icmp sgt i64 %t42, %t41
  store i1 %t44, ptr %l14, !tbaa !21
  br label %bb11
bb11:
  %t46 = load i1, ptr %l14, !tbaa !21
  store i1 %t46, ptr %l11, !tbaa !21
  br label %bb12
bb12:
  %t47 = load i1, ptr %l11, !tbaa !21
  br i1 %t47, label %bb13, label %bb14
bb13:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/check:Checker", ptr %t48, i32 0, i32 118
  %t51 = load ptr, ptr %l1, !tbaa !29
  %t53 = getelementptr %"compiler/check:frame", ptr %t51, i32 0, i32 0
  %t54 = load i64, ptr %t53, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t50, i64 %t54, i1 true)
  br label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb16
bb16:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/check:Checker", ptr %t57, i32 0, i32 16
  %t61 = call { i32, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_Hc78234e963d75e4843d79dfd3cff7b8f(ptr %v0, ptr %v0, ptr %t59)
  %t62 = extractvalue { i32, ptr } %t61, 1
  %t63 = extractvalue { i32, ptr } %t61, 0
  store i32 %t63, ptr %l31
  %t64 = icmp ne i32 %t63, 0
  br i1 %t64, label %bb18, label %ok.65, !prof !99
ok.65:
  store ptr %t62, ptr %l30
  br label %bb17
bb17:
  %t66 = load ptr, ptr %l30, !tbaa !29
  store ptr %t66, ptr %l27, !tbaa !29
  br label %bb20
bb18:
  br label %bb19
bb19:
  call void @__olang_ert_req_clear()
  br label %bb20
bb20:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epower(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca i32
  %l7 = alloca ptr
  %l10 = alloca ptr
  %l12 = alloca %"compiler/source:Span"
  %l14 = alloca %"compiler/source:Span"
  %l15 = alloca %"compiler/source:Span"
  %l19 = alloca i32
  %l22 = alloca i32
  %l24 = alloca ptr
  %l25 = alloca ptr
  %l27 = alloca ptr
  %l30 = alloca i1
  %l31 = alloca i1
  %l34 = alloca i1
  %l35 = alloca i32
  %l38 = alloca i32
  %l40 = alloca ptr
  %l42 = alloca %"compiler/source:Span"
  %l43 = alloca ptr
  %l46 = alloca i32
  %l53 = alloca ptr
  %l56 = alloca ptr
  %l59 = alloca i64
  %l61 = alloca i1
  %l62 = alloca ptr
  %l65 = alloca i32
  %l66 = alloca i1
  %l67 = alloca ptr
  %l68 = alloca ptr
  %l69 = alloca ptr
  %l73 = alloca i32
  %l74 = alloca i32
  %l75 = alloca ptr
  %l82 = alloca ptr
  %l83 = alloca ptr
  %l84 = alloca ptr
  %l86 = alloca ptr
  %l87 = alloca ptr
  %l90 = alloca i32
  %l91 = alloca i32
  %l92 = alloca ptr
  %l94 = alloca %"compiler/source:Span"
  %l95 = alloca ptr
  %l101 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  store i32 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l10, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t4 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t2)
  store %"compiler/source:Span" %t4, ptr %l12
  br label %bb1
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t7 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t5)
  store %"compiler/source:Span" %t7, ptr %l14
  br label %bb2
bb2:
  %t8 = load ptr, ptr %l10, !tbaa !29
  %t9 = load %"compiler/source:Span", ptr %l12
  %t10 = load %"compiler/source:Span", ptr %l14
  %t11 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebetween(ptr %v0, ptr %t8, %"compiler/source:Span" %t9, %"compiler/source:Span" %t10, i64 2)
  store %"compiler/source:Span" %t11, ptr %l15
  br label %bb3
bb3:
  %t12 = load %"compiler/source:Span", ptr %l15
  store %"compiler/source:Span" %t12, ptr %l5
  %t13 = load i32, ptr %l4, !tbaa !23
  %t14 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t17 = icmp ne i32 %t13, %t14
  br i1 %t17, label %bb4, label %bb5
bb4:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t20 = load i32, ptr %l4, !tbaa !23
  %t23 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t19, i32 %t20)
  store i32 %t23, ptr %l22
  br label %bb6
bb5:
  %t24 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t24, ptr %l19, !tbaa !23
  br label %bb7
bb6:
  %t26 = load i32, ptr %l22, !tbaa !23
  store i32 %t26, ptr %l19, !tbaa !23
  br label %bb7
bb7:
  %t27 = load i32, ptr %l19, !tbaa !23
  store i32 %t27, ptr %l6, !tbaa !23
  %t28 = load ptr, ptr %l0, !tbaa !29
  store ptr %t28, ptr %l24, !tbaa !29
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l25, !tbaa !29
  %t30 = load ptr, ptr %l2, !tbaa !29
  store ptr %t30, ptr %l27, !tbaa !29
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load ptr, ptr %l2, !tbaa !29
  %t36 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v1, ptr %t32, ptr %t33)
  store i1 %t36, ptr %l30
  br label %bb8
bb8:
  %t37 = load i1, ptr %l30, !tbaa !21
  br i1 %t37, label %bb9, label %bb10
bb9:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load i32, ptr %l6, !tbaa !23
  %t42 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t38, i32 %t39)
  store i1 %t42, ptr %l34
  br label %bb11
bb10:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb12
bb11:
  %t43 = load i1, ptr %l34, !tbaa !21
  store i1 %t43, ptr %l31, !tbaa !21
  br label %bb12
bb12:
  %t44 = load i1, ptr %l31, !tbaa !21
  br i1 %t44, label %bb13, label %bb14
bb13:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t46 = load i32, ptr %l6, !tbaa !23
  %t49 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eliteralBeside(ptr %v0, ptr %t45, i32 %t46)
  store i32 %t49, ptr %l38
  br label %bb15
bb14:
  %t50 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t50, ptr %l35, !tbaa !23
  br label %bb16
bb15:
  %t52 = load i32, ptr %l38, !tbaa !23
  store i32 %t52, ptr %l35, !tbaa !23
  br label %bb16
bb16:
  %t53 = load ptr, ptr %l25, !tbaa !29
  %t54 = load ptr, ptr %l27, !tbaa !29
  %t55 = load i32, ptr %l35, !tbaa !23
  %t56 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v0, ptr %t53, ptr %t54, i32 %t55)
  store ptr %t56, ptr %l40
  br label %bb17
bb17:
  %t57 = load ptr, ptr %l2, !tbaa !29
  %t59 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t57)
  store %"compiler/source:Span" %t59, ptr %l42
  br label %bb18
bb18:
  %t60 = load ptr, ptr %l24, !tbaa !29
  %t61 = load ptr, ptr %l40, !tbaa !29
  %t62 = load %"compiler/source:Span", ptr %l42
  %t63 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %v0, ptr %v3, ptr %t60, ptr %t61, %"compiler/source:Span" %t62)
  store ptr %t63, ptr %l43
  br label %bb19
bb19:
  %t64 = load ptr, ptr %l43, !tbaa !29
  store ptr %t64, ptr %l7, !tbaa !29
  %t65 = load ptr, ptr %l7, !tbaa !29
  %t68 = call i32 @compiler_2fcheck_2etypeOf(ptr %v3, ptr %t65)
  store i32 %t68, ptr %l46
  br label %bb20
bb20:
  %t69 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t70 = load i32, ptr %l46, !tbaa !23
  %t72 = icmp eq i32 %t70, %t69
  br i1 %t72, label %bb21, label %bb22
bb21:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load ptr, ptr %l3, !tbaa !29
  %t77 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t81 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v2, ptr %v0, ptr %t74, ptr %t75, i32 %t77)
  store ptr %t81, ptr %l53
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t83 = load %"compiler/source:Span", ptr %l1
  %t86 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v3, ptr %t82, %"compiler/source:Span" %t83)
  store ptr %t86, ptr %l56
  br label %bb24
bb24:
  %t87 = load ptr, ptr %l56, !tbaa !29
  store ptr %t87, ptr %rv
  br label %ret
bb25:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t89 = load ptr, ptr %l7, !tbaa !29
  %t92 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneOf(ptr %v0, ptr %v3, ptr %t88, ptr %t89)
  store i64 %t92, ptr %l59
  br label %bb26
bb26:
  %t93 = load i64, ptr %l59, !tbaa !24
  %t94 = icmp sge i64 %t93, 0
  br i1 %t94, label %bb27, label %bb28
bb27:
  store i1 true, ptr %l61, !tbaa !21
  br label %bb31
bb28:
  %t96 = load ptr, ptr %l0, !tbaa !29
  store ptr %t96, ptr %l62, !tbaa !29
  %t97 = load ptr, ptr %l7, !tbaa !29
  %t100 = call i32 @compiler_2fcheck_2etypeOf(ptr %v3, ptr %t97)
  store i32 %t100, ptr %l65
  br label %bb29
bb29:
  %t101 = load ptr, ptr %l62, !tbaa !29
  %t102 = load i32, ptr %l65, !tbaa !23
  %t103 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneArray(ptr %v0, ptr %t101, i32 %t102)
  store i1 %t103, ptr %l66
  br label %bb30
bb30:
  %t104 = load i1, ptr %l66, !tbaa !21
  store i1 %t104, ptr %l61, !tbaa !21
  br label %bb31
bb31:
  %t105 = load i1, ptr %l61, !tbaa !21
  br i1 %t105, label %bb32, label %bb33
bb32:
  %t106 = load ptr, ptr %l0, !tbaa !29
  store ptr %t106, ptr %l67, !tbaa !29
  %t107 = load ptr, ptr %l3, !tbaa !29
  store ptr %t107, ptr %l68, !tbaa !29
  %t108 = load ptr, ptr %l0, !tbaa !29
  store ptr %t108, ptr %l69, !tbaa !29
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t110 = load ptr, ptr %l7, !tbaa !29
  %t114 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneElemType(ptr %v0, ptr %v3, ptr %t109, ptr %t110)
  store i32 %t114, ptr %l73
  br label %bb34
bb33:
  br label %bb38
bb34:
  %t115 = load ptr, ptr %l69, !tbaa !29
  %t116 = load i32, ptr %l73, !tbaa !23
  %t117 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epowExponent(ptr %v0, ptr %t115, i32 %t116)
  store i32 %t117, ptr %l74
  br label %bb35
bb35:
  %t118 = load ptr, ptr %l67, !tbaa !29
  %t119 = load ptr, ptr %l68, !tbaa !29
  %t120 = load i32, ptr %l74, !tbaa !23
  %t121 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneArg(ptr %v0, ptr %v2, ptr %v3, ptr %t118, ptr %t119, i32 %t120)
  store ptr %t121, ptr %l75
  br label %bb36
bb36:
  %t122 = load ptr, ptr %l75, !tbaa !29
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t124 = load %"compiler/source:Span", ptr %l1
  %t125 = load %"compiler/source:Span", ptr %l5
  %t126 = load ptr, ptr %l7, !tbaa !29
  %t134 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneBinary(ptr %v0, ptr %v3, ptr %v3, ptr %v3, ptr %t123, %"compiler/source:Span" %t124, %"compiler/source:Span" %t125, i32 55, ptr %t126, ptr %t122)
  store ptr %t134, ptr %l82
  br label %bb37
bb37:
  %t135 = load ptr, ptr %l82, !tbaa !29
  store ptr %t135, ptr %rv
  br label %ret
bb38:
  %t136 = load ptr, ptr %l0, !tbaa !29
  store ptr %t136, ptr %l83, !tbaa !29
  %t137 = load ptr, ptr %l0, !tbaa !29
  store ptr %t137, ptr %l84, !tbaa !29
  %t138 = load ptr, ptr %l3, !tbaa !29
  store ptr %t138, ptr %l86, !tbaa !29
  %t140 = load ptr, ptr %l0, !tbaa !29
  store ptr %t140, ptr %l87, !tbaa !29
  %t141 = load ptr, ptr %l7, !tbaa !29
  %t144 = call i32 @compiler_2fcheck_2etypeOf(ptr %v3, ptr %t141)
  store i32 %t144, ptr %l90
  br label %bb39
bb39:
  %t145 = load ptr, ptr %l87, !tbaa !29
  %t146 = load i32, ptr %l90, !tbaa !23
  %t147 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epowExponent(ptr %v0, ptr %t145, i32 %t146)
  store i32 %t147, ptr %l91
  br label %bb40
bb40:
  %t148 = load ptr, ptr %l84, !tbaa !29
  %t149 = load ptr, ptr %l86, !tbaa !29
  %t150 = load i32, ptr %l91, !tbaa !23
  %t151 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v2, ptr %v0, ptr %t148, ptr %t149, i32 %t150)
  store ptr %t151, ptr %l92
  br label %bb41
bb41:
  %t152 = load ptr, ptr %l3, !tbaa !29
  %t154 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t152)
  store %"compiler/source:Span" %t154, ptr %l94
  br label %bb42
bb42:
  %t155 = load ptr, ptr %l83, !tbaa !29
  %t156 = load ptr, ptr %l92, !tbaa !29
  %t157 = load %"compiler/source:Span", ptr %l94
  %t158 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %v0, ptr %v3, ptr %t155, ptr %t156, %"compiler/source:Span" %t157)
  store ptr %t158, ptr %l95
  br label %bb43
bb43:
  %t159 = load ptr, ptr %l95, !tbaa !29
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t161 = load %"compiler/source:Span", ptr %l1
  %t162 = load %"compiler/source:Span", ptr %l5
  %t163 = load ptr, ptr %l7, !tbaa !29
  %t170 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epowValues(ptr %v0, ptr %v3, ptr %v3, ptr %v3, ptr %t160, %"compiler/source:Span" %t161, %"compiler/source:Span" %t162, ptr %t163, ptr %t159)
  store ptr %t170, ptr %l101
  br label %bb44
bb44:
  %t171 = load ptr, ptr %l101, !tbaa !29
  store ptr %t171, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprivateRole(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, i32 %a2, { i64, ptr } %a3, %"compiler/source:Span" %a4, { i64, ptr } %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l9 = alloca i1
  %l12 = alloca i64
  %l15 = alloca ptr
  %l19 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l25 = alloca i1
  %l26 = alloca i1
  %l30 = alloca i64
  %l32 = alloca ptr
  %l40 = alloca ptr
  %l43 = alloca { i64, [3 x i64] }
  %l44 = alloca { i64, ptr }
  %l45 = alloca ptr
  %l48 = alloca i32
  %l49 = alloca { i64, ptr }
  %l53 = alloca %"compiler/msgs:Msg"
  %l54 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb4
bb2:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/check:Checker", ptr %t5, i32 0, i32 16
  %t9 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_H2251bc8fca359ca0394d0bb11af7ba0a(ptr %v0, ptr %t7)
  store i64 %t9, ptr %l12
  br label %bb3
bb3:
  %t10 = load i64, ptr %l12, !tbaa !24
  %t11 = icmp eq i64 %t10, 0
  store i1 %t11, ptr %l9, !tbaa !21
  br label %bb4
bb4:
  %t13 = load i1, ptr %l9, !tbaa !21
  br i1 %t13, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t15 = load ptr, ptr %l0, !tbaa !29
  store ptr %t15, ptr %l15, !tbaa !29
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/check:Checker", ptr %t16, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t20 = load i64, ptr %l1, !tbaa !24
  %t23 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %s0, ptr %t19, i64 %t20)
  store ptr %t23, ptr %l19
  br label %bb8
bb8:
  %t24 = load ptr, ptr %l19, !tbaa !29
  %t26 = getelementptr %"compiler/ast:Func", ptr %t24, i32 0, i32 2
  %t27 = load i32, ptr %t26, !tbaa !23
  %t28 = load ptr, ptr %l15, !tbaa !29
  %t30 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t28, i32 %t27)
  store { i64, ptr } %t30, ptr %l22
  br label %bb9
bb9:
  %t31 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t31, ptr %l6, !tbaa !27
  %t32 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t33 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t36 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %t32, { i64, ptr } %t33)
  store i1 %t36, ptr %l25
  br label %bb10
bb10:
  %t37 = load i1, ptr %l25, !tbaa !21
  br i1 %t37, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb15
bb12:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/check:Checker", ptr %t38, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t42 = load i64, ptr %l1, !tbaa !24
  %t45 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t41, i64 %t42)
  store i64 %t45, ptr %l30
  br label %bb13
bb13:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t46)
  store ptr %t48, ptr %l32
  br label %bb14
bb14:
  %t49 = load ptr, ptr %l32, !tbaa !29
  %t51 = getelementptr %"compiler/check:frame", ptr %t49, i32 0, i32 1
  %t52 = load i64, ptr %t51, !tbaa !24
  %t53 = load i64, ptr %l30, !tbaa !24
  %t55 = icmp eq i64 %t53, %t52
  store i1 %t55, ptr %l26, !tbaa !21
  br label %bb15
bb15:
  %t57 = load i1, ptr %l26, !tbaa !21
  br i1 %t57, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/check:Checker", ptr %t59, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = getelementptr %"compiler/generic:Program", ptr %t62, i32 0, i32 0
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t67 = getelementptr %"compiler/load:Loader", ptr %t65, i32 0, i32 4
  %t68 = load ptr, ptr %t67, !tbaa !29
  store ptr %t68, ptr %l40, !tbaa !29
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t73 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %t69, %"compiler/source:Span" %a4)
  store { i64, [3 x i64] } %t73, ptr %l43
  br label %bb19
bb19:
  store { i64, ptr } %a5, ptr %l44, !tbaa !27
  %t75 = load ptr, ptr %l0, !tbaa !29
  store ptr %t75, ptr %l45, !tbaa !29
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t80 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t76, i32 %a2)
  store i32 %t80, ptr %l48
  br label %bb20
bb20:
  %t81 = load ptr, ptr %l45, !tbaa !29
  %t82 = load i32, ptr %l48, !tbaa !23
  %t83 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t81, i32 %t82)
  store { i64, ptr } %t83, ptr %l49
  br label %bb21
bb21:
  %t84 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t85 = extractvalue { i64, ptr } %t84, 0
  %t86 = extractvalue { i64, ptr } %t84, 1
  %t87 = mul i64 %t85, 1
  %t88 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t87)
  call void @llvm.memcpy.p0.p0.i64(ptr %t88, ptr %t86, i64 %t87, i1 false)
  %t89 = insertvalue { i64, ptr } undef, i64 %t85, 0
  %t90 = insertvalue { i64, ptr } %t89, ptr %t88, 1
  %t91 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t92 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t93 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t97 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eProtocolPrivate(ptr %v2, ptr %s0, ptr %v0, ptr %v1, ptr %s0, { i64, ptr } %t93, { i64, ptr } %t90, { i64, ptr } %t91, { i64, ptr } %t92)
  store %"compiler/msgs:Msg" %t97, ptr %l53
  br label %bb22
bb22:
  %t98 = load ptr, ptr %l40, !tbaa !29
  %t99 = load { i64, [3 x i64] }, ptr %l43
  %t100 = load %"compiler/msgs:Msg", ptr %l53
  %t101 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrorOncePerLine(ptr %v0, ptr %s0, ptr %t98, { i64, [3 x i64] } %t99, %"compiler/msgs:Msg" %t100)
  store i64 %t101, ptr %l54
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflDecide(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca %"compiler/check:reflVal"
  %l13 = alloca %"compiler/check:reflVal"
  %l20 = alloca i1
  %l23 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 126
  %t9 = load i1, ptr %t8, !tbaa !21
  store i1 %t9, ptr %l2, !tbaa !21
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/check:Checker", ptr %t11, i32 0, i32 126
  store i1 false, ptr %t13, !tbaa !21
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t18 = call %"compiler/check:reflVal" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflFold(ptr %v0, ptr %v1, ptr %s0, ptr %t14, ptr %t15)
  store %"compiler/check:reflVal" %t18, ptr %l13
  br label %bb4
bb4:
  %t19 = load %"compiler/check:reflVal", ptr %l13
  store %"compiler/check:reflVal" %t19, ptr %l3
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/check:Checker", ptr %t20, i32 0, i32 126
  %t23 = load i1, ptr %t22, !tbaa !21
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load i1, ptr %l2, !tbaa !21
  %t29 = getelementptr %"compiler/check:Checker", ptr %t25, i32 0, i32 126
  store i1 %t26, ptr %t29, !tbaa !21
  %t32 = xor i1 %t23, true
  br i1 %t32, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb7
bb6:
  %t34 = getelementptr %"compiler/check:reflVal", ptr %l3, i32 0, i32 0
  %t35 = load i1, ptr %t34, !tbaa !21
  %t37 = xor i1 %t35, true
  store i1 %t37, ptr %l20, !tbaa !21
  br label %bb7
bb7:
  %t39 = load i1, ptr %l20, !tbaa !21
  br i1 %t39, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb10
bb9:
  %t40 = getelementptr %"compiler/check:reflVal", ptr %l3, i32 0, i32 1
  %t41 = load i64, ptr %t40, !tbaa !24
  %t42 = load i64, ptr @G_2ecompiler_2fcheck_2eRvBool, !tbaa !24
  %t45 = icmp ne i64 %t41, %t42
  store i1 %t45, ptr %l23, !tbaa !21
  br label %bb10
bb10:
  %t47 = load i1, ptr %l23, !tbaa !21
  br i1 %t47, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t49 = getelementptr %"compiler/check:reflVal", ptr %l3, i32 0, i32 2
  %t50 = load i64, ptr %t49, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t50, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflExpr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, %"compiler/check:reflVal" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/check:reflVal"
  %l11 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca %"compiler/source:Span"
  %l18 = alloca i32
  %l20 = alloca ptr
  %l24 = alloca %"compiler/source:Span"
  %l27 = alloca ptr
  %l29 = alloca i32
  %l31 = alloca i32
  %l33 = alloca ptr
  %l44 = alloca i1
  %l49 = alloca { i64, ptr }
  %l50 = alloca ptr
  %l51 = alloca %"compiler/source:Span"
  %l52 = alloca %"compiler/source:Span"
  %l53 = alloca i32
  %l54 = alloca { i64, ptr }
  %l56 = alloca i32
  %l59 = alloca { i64, ptr }
  %l63 = alloca ptr
  %s0 = alloca %olang.scope
  %rv = alloca ptr
  %t71 = alloca { i64, [2 x i64] }, align 8
  %t79 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store %"compiler/check:reflVal" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = getelementptr %"compiler/check:reflVal", ptr %l2, i32 0, i32 1
  %t2 = load i64, ptr %t1, !tbaa !24
  %t3 = load i64, ptr @G_2ecompiler_2fcheck_2eRvBool, !tbaa !24
  %t6 = icmp eq i64 %t2, %t3
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t9 = load %"compiler/source:Span", ptr %l1
  %t10 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t11 = getelementptr %"compiler/check:reflVal", ptr %l2, i32 0, i32 2
  %t12 = load i64, ptr %t11, !tbaa !24
  %t17 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v2, ptr %t8, %"compiler/source:Span" %t9, i32 %t10, i64 %t12)
  store ptr %t17, ptr %l11
  br label %bb3
bb2:
  br label %bb4
bb3:
  call void @__olang_scope_close(ptr %s0)
  %t18 = load ptr, ptr %l11, !tbaa !29
  store ptr %t18, ptr %rv
  br label %ret
bb4:
  %t19 = getelementptr %"compiler/check:reflVal", ptr %l2, i32 0, i32 1
  %t20 = load i64, ptr %t19, !tbaa !24
  %t21 = load i64, ptr @G_2ecompiler_2fcheck_2eRvInt, !tbaa !24
  %t24 = icmp eq i64 %t20, %t21
  br i1 %t24, label %bb5, label %bb6
bb5:
  %t26 = load ptr, ptr %l0, !tbaa !29
  store ptr %t26, ptr %l15, !tbaa !29
  %t27 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t27, ptr %l16
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t28)
  store i32 %t30, ptr %l18
  br label %bb7
bb6:
  br label %bb9
bb7:
  %t31 = getelementptr %"compiler/check:reflVal", ptr %l2, i32 0, i32 2
  %t32 = load i64, ptr %t31, !tbaa !24
  %t33 = load ptr, ptr %l15, !tbaa !29
  %t34 = load %"compiler/source:Span", ptr %l16
  %t35 = load i32, ptr %l18, !tbaa !23
  %t37 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v2, ptr %t33, %"compiler/source:Span" %t34, i32 %t35, i64 %t32)
  store ptr %t37, ptr %l20
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s0)
  %t38 = load ptr, ptr %l20, !tbaa !29
  store ptr %t38, ptr %rv
  br label %ret
bb9:
  %t39 = getelementptr %"compiler/check:reflVal", ptr %l2, i32 0, i32 1
  %t40 = load i64, ptr %t39, !tbaa !24
  %t41 = load i64, ptr @G_2ecompiler_2fcheck_2eRvText, !tbaa !24
  %t44 = icmp eq i64 %t40, %t41
  br i1 %t44, label %bb10, label %bb11
bb10:
  %t46 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v2, i32 0, i32 0)
  store %"compiler/source:Span" %t46, ptr %l24
  br label %bb12
bb11:
  br label %bb16
bb12:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/check:Checker", ptr %t47, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !29
  %t52 = getelementptr %"compiler/generic:Program", ptr %t50, i32 0, i32 2
  store ptr %t52, ptr %l27, !tbaa !29
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %t53)
  store i32 %t55, ptr %l29
  br label %bb13
bb13:
  %t56 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t57 = load ptr, ptr %l27, !tbaa !29
  %t58 = load i32, ptr %l29, !tbaa !23
  %t60 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t57, i32 %t58, i64 %t56)
  store i32 %t60, ptr %l31
  br label %bb14
bb14:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t61)
  store ptr %t63, ptr %l33
  br label %bb15
bb15:
  %t64 = load ptr, ptr %l33, !tbaa !29
  %t66 = getelementptr %"compiler/check:frame", ptr %t64, i32 0, i32 2
  %t67 = load i64, ptr %t66, !tbaa !24
  %t68 = getelementptr %"compiler/check:reflVal", ptr %l2, i32 0, i32 3
  %t69 = load { i64, ptr }, ptr %t68, !tbaa !27
  store { i64, [2 x i64] } zeroinitializer, ptr %t71
  %t72 = getelementptr { i64, [2 x i64] }, ptr %t71, i32 0, i32 0
  store i64 1, ptr %t72
  %t74 = insertvalue { { i64, ptr } } undef, { i64, ptr } %t69, 0
  %t75 = getelementptr { i64, [2 x i64] }, ptr %t71, i32 0, i32 1
  store { { i64, ptr } } %t74, ptr %t75
  %t76 = load { i64, [2 x i64] }, ptr %t71
  %t78 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 24, i64 8)
  store { i64, [2 x i64] } %t76, ptr %t78
  store { i64, [5 x i64] } zeroinitializer, ptr %t79
  %t80 = getelementptr { i64, [5 x i64] }, ptr %t79, i32 0, i32 0
  store i64 1, ptr %t80
  %t81 = load %"compiler/source:Span", ptr %l24
  %t82 = insertvalue { %"compiler/source:Span", i32, i64, ptr } undef, %"compiler/source:Span" %t81, 0
  %t83 = load i32, ptr %l31, !tbaa !23
  %t84 = insertvalue { %"compiler/source:Span", i32, i64, ptr } %t82, i32 %t83, 1
  %t86 = insertvalue { %"compiler/source:Span", i32, i64, ptr } %t84, i64 %t67, 2
  %t88 = insertvalue { %"compiler/source:Span", i32, i64, ptr } %t86, ptr %t78, 3
  %t89 = getelementptr { i64, [5 x i64] }, ptr %t79, i32 0, i32 1
  store { %"compiler/source:Span", i32, i64, ptr } %t88, ptr %t89
  %t90 = load { i64, [5 x i64] }, ptr %t79
  %t92 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store { i64, [5 x i64] } %t90, ptr %t92
  call void @__olang_scope_close(ptr %s0)
  store ptr %t92, ptr %rv
  br label %ret
bb16:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/check:reflVal", ptr %l2, i32 0, i32 4
  %t96 = load i32, ptr %t95, !tbaa !23
  %t99 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %t94, i32 %t96)
  store i1 %t99, ptr %l44
  br label %bb17
bb17:
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t102 = getelementptr %"compiler/check:Checker", ptr %t100, i32 0, i32 1
  %t103 = load ptr, ptr %t102, !tbaa !29
  %t105 = getelementptr %"compiler/generic:Program", ptr %t103, i32 0, i32 2
  %t106 = getelementptr %"compiler/check:reflVal", ptr %l2, i32 0, i32 4
  %t107 = load i32, ptr %t106, !tbaa !23
  %t110 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCaseNames(ptr %v0, ptr %s0, ptr %t105, i32 %t107)
  store { i64, ptr } %t110, ptr %l49
  br label %bb18
bb18:
  %t111 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t112 = load ptr, ptr %l0, !tbaa !29
  store ptr %t112, ptr %l50, !tbaa !29
  %t113 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t113, ptr %l51
  %t114 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t114, ptr %l52
  %t115 = getelementptr %"compiler/check:reflVal", ptr %l2, i32 0, i32 4
  %t116 = load i32, ptr %t115, !tbaa !23
  store i32 %t116, ptr %l53, !tbaa !23
  store { i64, ptr } %t111, ptr %l54, !tbaa !27
  %t118 = getelementptr %"compiler/check:reflVal", ptr %l2, i32 0, i32 2
  %t119 = load i64, ptr %t118, !tbaa !24
  %t121 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t122 = load ptr, ptr %t121, !tbaa !27
  %t123 = getelementptr i32, ptr %t122, i64 %t119
  %t124 = load i32, ptr %t123, !tbaa !33
  store i32 %t124, ptr %l56, !tbaa !23
  %t125 = icmp sge i64 0, 0
  br i1 %t125, label %bb19, label %bb20
bb19:
  %t127 = icmp sle i64 0, 1152921504606846975
  br i1 %t127, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_c2468d0e741d9164_dbacc6d57ee844a8)
  unreachable
bb21:
  %t129 = mul i64 0, 8
  %t130 = insertvalue { i64, ptr } undef, i64 0, 0
  %t131 = insertvalue { i64, ptr } %t130, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t131, ptr %l59, !tbaa !27
  %t132 = icmp sge i64 0, 0
  br i1 %t132, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_c2468d0e741d9164_dbacc6d57ee844a8)
  unreachable
bb23:
  %t134 = icmp sle i64 0, 1152921504606846975
  br i1 %t134, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_c26cedf47b5c0c71_e777f9dba4d45095)
  unreachable
bb25:
  %t136 = mul i64 0, 8
  %t137 = insertvalue { i64, ptr } undef, i64 0, 0
  %t138 = insertvalue { i64, ptr } %t137, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t139 = load ptr, ptr %l50, !tbaa !29
  %t140 = load %"compiler/source:Span", ptr %l51
  %t141 = load %"compiler/source:Span", ptr %l52
  %t142 = load i32, ptr %l53, !tbaa !23
  %t143 = load i32, ptr %l56, !tbaa !23
  %t144 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t146 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eenumCase(ptr %v0, ptr %v0, ptr %v0, ptr %v2, ptr %t139, %"compiler/source:Span" %t140, %"compiler/source:Span" %t141, i32 %t142, i32 %t143, { i64, ptr } %t144, { i64, ptr } %t138)
  store ptr %t146, ptr %l63
  br label %bb27
bb26:
  call void @__olang_check_failed(ptr @olang_loc_c26cedf47b5c0c71_e777f9dba4d45095)
  unreachable
bb27:
  call void @__olang_scope_close(ptr %s0)
  %t147 = load ptr, ptr %l63, !tbaa !29
  store ptr %t147, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erewritten(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l14 = alloca { i64, ptr }
  %l18 = alloca ptr
  %l21 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l22 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a2, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l5, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t7 = load i64, ptr %l4, !tbaa !24
  %t8 = load i64, ptr %l5, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t15, ptr %l14, !tbaa !27
  %t16 = load i64, ptr %l4, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr i64, ptr %t19, i64 %t16
  %t21 = load i64, ptr %t20, !tbaa !34
  %t25 = getelementptr %"compiler/check:Checker", ptr %a0, i32 0, i32 120
  store ptr %t25, ptr %l18, !tbaa !29
  %t30 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s2, i64 %a1, i64 %t21)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t30, ptr %l21
  br label %bb5
bb5:
  %t31 = load ptr, ptr %l18, !tbaa !29
  %t32 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l21
  %t33 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %t31, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t32)
  store i1 %t33, ptr %l22
  br label %bb6
bb6:
  %t34 = load i1, ptr %l22, !tbaa !21
  br i1 %t34, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb10:
  %t36 = load i64, ptr %l4, !tbaa !24
  %t38 = add i64 %t36, 1
  store i64 %t38, ptr %l4, !tbaa !24
  br label %bb1
bb11:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroBorrowedFrom(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l12 = alloca i64
  %l15 = alloca i1
  %l18 = alloca i1
  %l27 = alloca i64
  %l30 = alloca i64
  %l51 = alloca i1
  %l52 = alloca i1
  %l56 = alloca i1
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t4 = getelementptr %"compiler/typed:Call", ptr %t2, i32 0, i32 0
  %t5 = load ptr, ptr %t4, !tbaa !29
  %t8 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyOfCallee(ptr %v0, ptr %v1, ptr %t1, ptr %t5)
  store i64 %t8, ptr %l12
  br label %bb1
bb1:
  %t9 = load i64, ptr %l12, !tbaa !24
  store i64 %t9, ptr %l2, !tbaa !24
  %t10 = load i64, ptr %l2, !tbaa !24
  %t12 = icmp slt i64 %t10, 0
  br i1 %t12, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb5
bb3:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load i64, ptr %l2, !tbaa !24
  %t18 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstanceBody(ptr %v0, ptr %t14, i64 %t15)
  store i1 %t18, ptr %l18
  br label %bb4
bb4:
  %t19 = load i1, ptr %l18, !tbaa !21
  %t20 = xor i1 %t19, true
  store i1 %t20, ptr %l15, !tbaa !21
  br label %bb5
bb5:
  %t22 = load i1, ptr %l15, !tbaa !21
  br i1 %t22, label %bb6, label %bb7
bb6:
  store i64 -1, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  store i64 0, ptr %l3, !tbaa !24
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t26 = getelementptr %"compiler/typed:Call", ptr %t24, i32 0, i32 1
  %t27 = load { i64, ptr }, ptr %t26, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t27, 0
  store i64 %t29, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t31 = load i64, ptr %l4, !tbaa !24
  %t32 = load i64, ptr %l3, !tbaa !24
  %t35 = icmp sgt i64 %t31, %t32
  br i1 %t35, label %bb9, label %bb10
bb9:
  %t37 = load i64, ptr %l5, !tbaa !24
  %t39 = icmp sgt i64 %t37, 0
  br i1 %t39, label %bb11, label %bb12
bb10:
  store i64 0, ptr %l27, !tbaa !24
  br label %bb14
bb11:
  %t41 = load i64, ptr %l4, !tbaa !24
  %t42 = load i64, ptr %l3, !tbaa !24
  %t45 = sub i64 %t41, %t42
  %t46 = load i64, ptr %l5, !tbaa !24
  %t49 = add i64 %t45, %t46
  %t51 = sub i64 %t49, 1
  %t52 = load i64, ptr %l5, !tbaa !24
  %t55 = sdiv i64 %t51, %t52
  store i64 %t55, ptr %l30, !tbaa !24
  br label %bb13
bb12:
  store i64 0, ptr %l30, !tbaa !24
  br label %bb13
bb13:
  %t57 = load i64, ptr %l30, !tbaa !24
  store i64 %t57, ptr %l27, !tbaa !24
  br label %bb14
bb14:
  %t58 = load i64, ptr %l27, !tbaa !24
  store i64 %t58, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb15
bb15:
  %t59 = load i64, ptr %l7, !tbaa !24
  %t60 = load i64, ptr %l6, !tbaa !24
  %t63 = icmp slt i64 %t59, %t60
  %t65 = xor i1 %t63, true
  br i1 %t65, label %bb16, label %bb17
bb16:
  br label %bb28
bb17:
  br label %bb18
bb18:
  %t67 = load i64, ptr %l3, !tbaa !24
  %t68 = load i64, ptr %l7, !tbaa !24
  %t69 = load i64, ptr %l5, !tbaa !24
  %t72 = mul i64 %t68, %t69
  %t75 = add i64 %t67, %t72
  store i64 %t75, ptr %l8, !tbaa !24
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t78 = load i64, ptr %l2, !tbaa !24
  %t79 = load i64, ptr %l8, !tbaa !24
  %t83 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroByArg(ptr %v0, ptr %t77, i64 %t78, i64 %t79)
  store i1 %t83, ptr %l51
  br label %bb19
bb19:
  %t84 = load i1, ptr %l51, !tbaa !21
  br i1 %t84, label %bb20, label %bb21
bb20:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = load i64, ptr %l2, !tbaa !24
  %t87 = load i64, ptr %l8, !tbaa !24
  %t91 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroFollows(ptr %v0, ptr %t85, i64 %t86, i64 %t87)
  store i1 %t91, ptr %l56
  br label %bb22
bb21:
  store i1 false, ptr %l52, !tbaa !21
  br label %bb23
bb22:
  %t92 = load i1, ptr %l56, !tbaa !21
  store i1 %t92, ptr %l52, !tbaa !21
  br label %bb23
bb23:
  %t93 = load i1, ptr %l52, !tbaa !21
  br i1 %t93, label %bb24, label %bb25
bb24:
  %t94 = load i64, ptr %l8, !tbaa !24
  store i64 %t94, ptr %rv
  br label %ret
bb25:
  br label %bb26
bb26:
  br label %bb27
bb27:
  %t96 = load i64, ptr %l7, !tbaa !24
  %t98 = add i64 %t96, 1
  store i64 %t98, ptr %l7, !tbaa !24
  br label %bb15
bb28:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroMatch(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l15 = alloca { i64, ptr }
  %l22 = alloca i1
  %l23 = alloca ptr
  %l29 = alloca i1
  %l37 = alloca i1
  %l47 = alloca i1
  %l48 = alloca ptr
  %l59 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Match", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  br label %bb16
bb3:
  br label %bb4
bb4:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %l15, !tbaa !27
  %t19 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr ptr, ptr %t22, i64 %t19
  %t24 = load ptr, ptr %t23, !tbaa !39
  store ptr %t24, ptr %l5, !tbaa !29
  %t26 = load ptr, ptr %l5, !tbaa !29
  %t28 = getelementptr %"compiler/typed:Arm", ptr %t26, i32 0, i32 4
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t31 = icmp eq ptr %t29, null
  %t33 = xor i1 %t31, true
  br i1 %t33, label %bb5, label %bb6
bb5:
  %t35 = load ptr, ptr %l0, !tbaa !29
  store ptr %t35, ptr %l23, !tbaa !29
  %t36 = load ptr, ptr %l5, !tbaa !29
  %t38 = getelementptr %"compiler/typed:Arm", ptr %t36, i32 0, i32 4
  %t39 = load ptr, ptr %t38, !tbaa !29
  %t41 = icmp eq ptr %t39, null
  br i1 %t41, label %bb7, label %bb8
bb6:
  store i1 false, ptr %l22, !tbaa !21
  br label %bb11
bb7:
  call void @__olang_check_failed(ptr @olang_loc_9ffee6a4e1a43bc2_8f88457b20f170fe)
  unreachable
bb8:
  br label %bb9
bb9:
  %t43 = load ptr, ptr %l5, !tbaa !29
  %t45 = getelementptr %"compiler/typed:Arm", ptr %t43, i32 0, i32 4
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t47 = load ptr, ptr %l23, !tbaa !29
  %t49 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroCopied(ptr %v0, ptr %v1, ptr %t47, ptr %t46)
  store i1 %t49, ptr %l29
  br label %bb10
bb10:
  %t50 = load i1, ptr %l29, !tbaa !21
  store i1 %t50, ptr %l22, !tbaa !21
  br label %bb11
bb11:
  %t51 = load i1, ptr %l22, !tbaa !21
  br i1 %t51, label %bb12, label %bb13
bb12:
  store i1 true, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  br label %bb15
bb15:
  %t53 = load i64, ptr %l3, !tbaa !24
  %t55 = add i64 %t53, 1
  store i64 %t55, ptr %l3, !tbaa !24
  br label %bb1
bb16:
  %t57 = load ptr, ptr %l1, !tbaa !29
  %t59 = getelementptr %"compiler/typed:Match", ptr %t57, i32 0, i32 2
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t62 = icmp eq ptr %t60, null
  %t64 = xor i1 %t62, true
  br i1 %t64, label %bb17, label %bb18
bb17:
  %t66 = load ptr, ptr %l1, !tbaa !29
  %t68 = getelementptr %"compiler/typed:Match", ptr %t66, i32 0, i32 2
  %t69 = load ptr, ptr %t68, !tbaa !29
  %t71 = icmp eq ptr %t69, null
  br i1 %t71, label %bb19, label %bb20
bb18:
  store i1 false, ptr %l37, !tbaa !21
  br label %bb22
bb19:
  call void @__olang_check_failed(ptr @olang_loc_ce05aca7270627a9_4d670951fa414da5)
  unreachable
bb20:
  br label %bb21
bb21:
  %t73 = load ptr, ptr %l1, !tbaa !29
  %t75 = getelementptr %"compiler/typed:Match", ptr %t73, i32 0, i32 2
  %t76 = load ptr, ptr %t75, !tbaa !29
  %t79 = getelementptr %"compiler/typed:Arm", ptr %t76, i32 0, i32 4
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t82 = icmp eq ptr %t80, null
  %t84 = xor i1 %t82, true
  store i1 %t84, ptr %l37, !tbaa !21
  br label %bb22
bb22:
  %t86 = load i1, ptr %l37, !tbaa !21
  br i1 %t86, label %bb23, label %bb24
bb23:
  %t87 = load ptr, ptr %l0, !tbaa !29
  store ptr %t87, ptr %l48, !tbaa !29
  %t88 = load ptr, ptr %l1, !tbaa !29
  %t90 = getelementptr %"compiler/typed:Match", ptr %t88, i32 0, i32 2
  %t91 = load ptr, ptr %t90, !tbaa !29
  %t93 = icmp eq ptr %t91, null
  br i1 %t93, label %bb25, label %bb26
bb24:
  store i1 false, ptr %l47, !tbaa !21
  br label %bb32
bb25:
  call void @__olang_check_failed(ptr @olang_loc_ce05aca7270627a9_4d670951fa414da5)
  unreachable
bb26:
  br label %bb27
bb27:
  %t95 = load ptr, ptr %l1, !tbaa !29
  %t97 = getelementptr %"compiler/typed:Match", ptr %t95, i32 0, i32 2
  %t98 = load ptr, ptr %t97, !tbaa !29
  %t101 = getelementptr %"compiler/typed:Arm", ptr %t98, i32 0, i32 4
  %t102 = load ptr, ptr %t101, !tbaa !29
  store ptr %t102, ptr %l6, !tbaa !29
  %t104 = load ptr, ptr %l6, !tbaa !29
  %t106 = icmp eq ptr %t104, null
  br i1 %t106, label %bb28, label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_ce05aca7270627a9_4d670951fa414da5)
  unreachable
bb29:
  br label %bb30
bb30:
  %t108 = load ptr, ptr %l6, !tbaa !29
  %t109 = load ptr, ptr %l48, !tbaa !29
  %t111 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroCopied(ptr %v0, ptr %v1, ptr %t109, ptr %t108)
  store i1 %t111, ptr %l59
  br label %bb31
bb31:
  %t112 = load i1, ptr %l59, !tbaa !21
  store i1 %t112, ptr %l47, !tbaa !21
  br label %bb32
bb32:
  %t113 = load i1, ptr %l47, !tbaa !21
  store i1 %t113, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroTrack(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l8 = alloca i1
  %l9 = alloca ptr
  %l12 = alloca i32
  %l13 = alloca i1
  %l15 = alloca ptr
  %l16 = alloca i1
  %l22 = alloca ptr
  %l25 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l28 = alloca %"compiler/check:roOrigin"
  %l29 = alloca ptr
  %l30 = alloca i1
  %l36 = alloca ptr
  %l39 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l42 = alloca %"compiler/check:roOrigin"
  %l43 = alloca ptr
  %l44 = alloca i1
  %l50 = alloca ptr
  %l53 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l57 = alloca %"compiler/check:roOrigin"
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb5
bb2:
  %t5 = load ptr, ptr %l0, !tbaa !29
  store ptr %t5, ptr %l9, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t9 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t6)
  store i32 %t9, ptr %l12
  br label %bb3
bb3:
  %t10 = load ptr, ptr %l9, !tbaa !29
  %t11 = load i32, ptr %l12, !tbaa !23
  %t12 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t10, i32 %t11)
  store i1 %t12, ptr %l13
  br label %bb4
bb4:
  %t13 = load i1, ptr %l13, !tbaa !21
  %t14 = xor i1 %t13, true
  store i1 %t14, ptr %l8, !tbaa !21
  br label %bb5
bb5:
  %t16 = load i1, ptr %l8, !tbaa !21
  br i1 %t16, label %bb6, label %bb7
bb6:
  br label %ret
bb7:
  br label %bb8
bb8:
  %t17 = load ptr, ptr %l2, !tbaa !29
  store ptr %t17, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t18 = load ptr, ptr %l15, !tbaa !29
  %t19 = icmp ne ptr %t18, null
  br i1 %t19, label %bb9, label %bb10
bb9:
  %t21 = load ptr, ptr %l15, !tbaa !29
  %t22 = load i64, ptr %t21, !range !{i64 0, i64 18}
  %t24 = icmp eq i64 %t22, 2
  store i1 %t24, ptr %l16, !tbaa !21
  br label %bb10
bb10:
  %t25 = load i1, ptr %l16, !tbaa !21
  br i1 %t25, label %bb11, label %bb12
bb11:
  %t26 = load ptr, ptr %l2, !tbaa !29
  %t28 = getelementptr { i64, [5 x i64] }, ptr %t26, i32 0, i32 1
  %t29 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t28, i32 0, i32 2
  %t30 = load ptr, ptr %t29
  store ptr %t30, ptr %l3, !tbaa !29
  br label %bb13
bb12:
  br label %bb17
bb13:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/check:Checker", ptr %t32, i32 0, i32 69
  store ptr %t34, ptr %l22, !tbaa !29
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load i64, ptr %l1, !tbaa !24
  %t39 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroKey(ptr %v0, ptr %t35, i64 %t36)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t39, ptr %l25
  br label %bb14
bb14:
  %t40 = load ptr, ptr %l3, !tbaa !29
  %t43 = call %"compiler/check:roOrigin" @compiler_2fcheck_3aroOrigin_2ector(ptr %v1, ptr %v0, ptr %t40, i1 false)
  store %"compiler/check:roOrigin" %t43, ptr %l28
  br label %bb15
bb15:
  %t44 = load ptr, ptr %l22, !tbaa !29
  %t45 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l25
  %t46 = load %"compiler/check:roOrigin", ptr %l28
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_Hd862b35741eab3a632965773dd6b12ba(ptr %v0, ptr %v0, ptr %t44, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t45, %"compiler/check:roOrigin" %t46)
  br label %bb16
bb16:
  br label %bb40
bb17:
  %t47 = load ptr, ptr %l2, !tbaa !29
  store ptr %t47, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t48 = load ptr, ptr %l29, !tbaa !29
  %t49 = icmp ne ptr %t48, null
  br i1 %t49, label %bb18, label %bb19
bb18:
  %t51 = load ptr, ptr %l29, !tbaa !29
  %t52 = load i64, ptr %t51, !range !{i64 0, i64 18}
  %t54 = icmp eq i64 %t52, 3
  store i1 %t54, ptr %l30, !tbaa !21
  br label %bb19
bb19:
  %t55 = load i1, ptr %l30, !tbaa !21
  br i1 %t55, label %bb20, label %bb21
bb20:
  %t56 = load ptr, ptr %l2, !tbaa !29
  %t58 = getelementptr { i64, [5 x i64] }, ptr %t56, i32 0, i32 1
  %t59 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t58, i32 0, i32 2
  %t60 = load ptr, ptr %t59
  store ptr %t60, ptr %l4, !tbaa !29
  br label %bb22
bb21:
  br label %bb26
bb22:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/check:Checker", ptr %t62, i32 0, i32 69
  store ptr %t64, ptr %l36, !tbaa !29
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load i64, ptr %l1, !tbaa !24
  %t69 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroKey(ptr %v0, ptr %t65, i64 %t66)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t69, ptr %l39
  br label %bb23
bb23:
  %t70 = load ptr, ptr %l4, !tbaa !29
  %t73 = call %"compiler/check:roOrigin" @compiler_2fcheck_3aroOrigin_2ector(ptr %v1, ptr %v0, ptr %t70, i1 true)
  store %"compiler/check:roOrigin" %t73, ptr %l42
  br label %bb24
bb24:
  %t74 = load ptr, ptr %l36, !tbaa !29
  %t75 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l39
  %t76 = load %"compiler/check:roOrigin", ptr %l42
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_Hd862b35741eab3a632965773dd6b12ba(ptr %v0, ptr %v0, ptr %t74, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t75, %"compiler/check:roOrigin" %t76)
  br label %bb25
bb25:
  br label %bb40
bb26:
  %t77 = load ptr, ptr %l2, !tbaa !29
  store ptr %t77, ptr %l43, !tbaa !29
  store i1 false, ptr %l44, !tbaa !21
  %t78 = load ptr, ptr %l43, !tbaa !29
  %t79 = icmp ne ptr %t78, null
  br i1 %t79, label %bb27, label %bb28
bb27:
  %t81 = load ptr, ptr %l43, !tbaa !29
  %t82 = load i64, ptr %t81, !range !{i64 0, i64 18}
  %t84 = icmp eq i64 %t82, 10
  store i1 %t84, ptr %l44, !tbaa !21
  br label %bb28
bb28:
  %t85 = load i1, ptr %l44, !tbaa !21
  br i1 %t85, label %bb29, label %bb30
bb29:
  %t86 = load ptr, ptr %l2, !tbaa !29
  %t88 = getelementptr { i64, [5 x i64] }, ptr %t86, i32 0, i32 1
  %t89 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t88, i32 0, i32 2
  %t90 = load ptr, ptr %t89
  store ptr %t90, ptr %l5, !tbaa !29
  br label %bb31
bb30:
  br label %bb35
bb31:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/check:Checker", ptr %t92, i32 0, i32 69
  store ptr %t94, ptr %l50, !tbaa !29
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t96 = load i64, ptr %l1, !tbaa !24
  %t99 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroKey(ptr %v0, ptr %t95, i64 %t96)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t99, ptr %l53
  br label %bb32
bb32:
  %t100 = load ptr, ptr %l5, !tbaa !29
  %t102 = getelementptr %"compiler/typed:Slice", ptr %t100, i32 0, i32 0
  %t103 = load ptr, ptr %t102, !tbaa !29
  %t106 = call %"compiler/check:roOrigin" @compiler_2fcheck_3aroOrigin_2ector(ptr %v1, ptr %v0, ptr %t103, i1 true)
  store %"compiler/check:roOrigin" %t106, ptr %l57
  br label %bb33
bb33:
  %t107 = load ptr, ptr %l50, !tbaa !29
  %t108 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l53
  %t109 = load %"compiler/check:roOrigin", ptr %l57
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_Hd862b35741eab3a632965773dd6b12ba(ptr %v0, ptr %v0, ptr %t107, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t108, %"compiler/check:roOrigin" %t109)
  br label %bb34
bb34:
  br label %bb40
bb35:
  br i1 true, label %bb36, label %bb37
bb36:
  br label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb40
bb39:
  call void @__olang_check_failed(ptr @olang_loc_9ed68493f04b873b_45e1787ed2cd21af)
  unreachable
bb40:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esamePlace(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca i64
  %l8 = alloca i32
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca i1
  %l27 = alloca ptr
  %l28 = alloca i1
  %l37 = alloca ptr
  %l38 = alloca i1
  %l45 = alloca ptr
  %l46 = alloca i1
  %l56 = alloca i1
  %l61 = alloca ptr
  %l62 = alloca i1
  %l69 = alloca ptr
  %l70 = alloca i1
  %l80 = alloca i1
  %l84 = alloca i1
  %l86 = alloca ptr
  %l87 = alloca i1
  %l92 = alloca ptr
  %l93 = alloca i1
  %l103 = alloca i1
  %l105 = alloca ptr
  %l106 = alloca i1
  %l111 = alloca ptr
  %l112 = alloca i1
  %l122 = alloca i1
  %l128 = alloca i1
  %l130 = alloca ptr
  %l131 = alloca i1
  %l136 = alloca ptr
  %l137 = alloca i1
  %l143 = alloca ptr
  %l145 = alloca ptr
  %l149 = alloca i1
  %l153 = alloca i1
  %l157 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l21, !tbaa !29
  store i1 false, ptr %l22, !tbaa !21
  %t2 = load ptr, ptr %l21, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l21, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l22, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l22, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l3, !tbaa !23
  br label %bb5
bb4:
  br label %bb16
bb5:
  %t16 = load ptr, ptr %l2, !tbaa !29
  store ptr %t16, ptr %l27, !tbaa !29
  store i1 false, ptr %l28, !tbaa !21
  %t17 = load ptr, ptr %l27, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t20 = load ptr, ptr %l27, !tbaa !29
  %t21 = load i64, ptr %t20, !range !{i64 0, i64 8}
  %t23 = icmp eq i64 %t21, 0
  store i1 %t23, ptr %l28, !tbaa !21
  br label %bb7
bb7:
  %t24 = load i1, ptr %l28, !tbaa !21
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t25 = load ptr, ptr %l2, !tbaa !29
  %t27 = getelementptr { i64, [4 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t27, i32 0, i32 2
  %t29 = load i32, ptr %t28
  store i32 %t29, ptr %l4, !tbaa !23
  br label %bb10
bb9:
  br label %bb11
bb10:
  %t31 = load i32, ptr %l3, !tbaa !23
  %t32 = load i32, ptr %l4, !tbaa !23
  %t35 = icmp eq i32 %t31, %t32
  store i1 %t35, ptr %rv
  br label %ret
bb11:
  br i1 true, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  store i1 false, ptr %rv
  br label %ret
bb15:
  call void @__olang_check_failed(ptr @olang_loc_e181575e6035f202_99a6d5836a9bf6a6)
  unreachable
bb16:
  %t38 = load ptr, ptr %l1, !tbaa !29
  store ptr %t38, ptr %l37, !tbaa !29
  store i1 false, ptr %l38, !tbaa !21
  %t39 = load ptr, ptr %l37, !tbaa !29
  %t40 = icmp ne ptr %t39, null
  br i1 %t40, label %bb17, label %bb18
bb17:
  %t42 = load ptr, ptr %l37, !tbaa !29
  %t43 = load i64, ptr %t42, !range !{i64 0, i64 8}
  %t45 = icmp eq i64 %t43, 1
  store i1 %t45, ptr %l38, !tbaa !21
  br label %bb18
bb18:
  %t46 = load i1, ptr %l38, !tbaa !21
  br i1 %t46, label %bb19, label %bb20
bb19:
  %t47 = load ptr, ptr %l1, !tbaa !29
  %t49 = getelementptr { i64, [4 x i64] }, ptr %t47, i32 0, i32 1
  %t50 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t49, i32 0, i32 2
  %t51 = load i64, ptr %t50
  store i64 %t51, ptr %l5, !tbaa !24
  %t53 = load ptr, ptr %l1, !tbaa !29
  %t55 = getelementptr { i64, [4 x i64] }, ptr %t53, i32 0, i32 1
  %t56 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t55, i32 0, i32 3
  %t57 = load i32, ptr %t56
  store i32 %t57, ptr %l6, !tbaa !23
  br label %bb21
bb20:
  br label %bb35
bb21:
  %t59 = load ptr, ptr %l2, !tbaa !29
  store ptr %t59, ptr %l45, !tbaa !29
  store i1 false, ptr %l46, !tbaa !21
  %t60 = load ptr, ptr %l45, !tbaa !29
  %t61 = icmp ne ptr %t60, null
  br i1 %t61, label %bb22, label %bb23
bb22:
  %t63 = load ptr, ptr %l45, !tbaa !29
  %t64 = load i64, ptr %t63, !range !{i64 0, i64 8}
  %t66 = icmp eq i64 %t64, 1
  store i1 %t66, ptr %l46, !tbaa !21
  br label %bb23
bb23:
  %t67 = load i1, ptr %l46, !tbaa !21
  br i1 %t67, label %bb24, label %bb25
bb24:
  %t68 = load ptr, ptr %l2, !tbaa !29
  %t70 = getelementptr { i64, [4 x i64] }, ptr %t68, i32 0, i32 1
  %t71 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t70, i32 0, i32 2
  %t72 = load i64, ptr %t71
  store i64 %t72, ptr %l7, !tbaa !24
  %t74 = load ptr, ptr %l2, !tbaa !29
  %t76 = getelementptr { i64, [4 x i64] }, ptr %t74, i32 0, i32 1
  %t77 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t76, i32 0, i32 3
  %t78 = load i32, ptr %t77
  store i32 %t78, ptr %l8, !tbaa !23
  br label %bb26
bb25:
  br label %bb30
bb26:
  %t80 = load i64, ptr %l5, !tbaa !24
  %t81 = load i64, ptr %l7, !tbaa !24
  %t84 = icmp eq i64 %t80, %t81
  br i1 %t84, label %bb27, label %bb28
bb27:
  %t86 = load i32, ptr %l6, !tbaa !23
  %t87 = load i32, ptr %l8, !tbaa !23
  %t90 = icmp eq i32 %t86, %t87
  store i1 %t90, ptr %l56, !tbaa !21
  br label %bb29
bb28:
  store i1 false, ptr %l56, !tbaa !21
  br label %bb29
bb29:
  %t92 = load i1, ptr %l56, !tbaa !21
  store i1 %t92, ptr %rv
  br label %ret
bb30:
  br i1 true, label %bb31, label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb34
bb33:
  store i1 false, ptr %rv
  br label %ret
bb34:
  call void @__olang_check_failed(ptr @olang_loc_a5d3444dbde3a383_cb32d8a11a505607)
  unreachable
bb35:
  %t94 = load ptr, ptr %l1, !tbaa !29
  store ptr %t94, ptr %l61, !tbaa !29
  store i1 false, ptr %l62, !tbaa !21
  %t95 = load ptr, ptr %l61, !tbaa !29
  %t96 = icmp ne ptr %t95, null
  br i1 %t96, label %bb36, label %bb37
bb36:
  %t98 = load ptr, ptr %l61, !tbaa !29
  %t99 = load i64, ptr %t98, !range !{i64 0, i64 8}
  %t101 = icmp eq i64 %t99, 3
  store i1 %t101, ptr %l62, !tbaa !21
  br label %bb37
bb37:
  %t102 = load i1, ptr %l62, !tbaa !21
  br i1 %t102, label %bb38, label %bb39
bb38:
  %t103 = load ptr, ptr %l1, !tbaa !29
  %t105 = getelementptr { i64, [4 x i64] }, ptr %t103, i32 0, i32 1
  %t106 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t105, i32 0, i32 2
  %t107 = load ptr, ptr %t106
  store ptr %t107, ptr %l9, !tbaa !29
  %t109 = load ptr, ptr %l1, !tbaa !29
  %t111 = getelementptr { i64, [4 x i64] }, ptr %t109, i32 0, i32 1
  %t112 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t111, i32 0, i32 3
  %t113 = load i64, ptr %t112
  store i64 %t113, ptr %l10, !tbaa !24
  br label %bb40
bb39:
  br label %bb55
bb40:
  %t115 = load ptr, ptr %l2, !tbaa !29
  store ptr %t115, ptr %l69, !tbaa !29
  store i1 false, ptr %l70, !tbaa !21
  %t116 = load ptr, ptr %l69, !tbaa !29
  %t117 = icmp ne ptr %t116, null
  br i1 %t117, label %bb41, label %bb42
bb41:
  %t119 = load ptr, ptr %l69, !tbaa !29
  %t120 = load i64, ptr %t119, !range !{i64 0, i64 8}
  %t122 = icmp eq i64 %t120, 3
  store i1 %t122, ptr %l70, !tbaa !21
  br label %bb42
bb42:
  %t123 = load i1, ptr %l70, !tbaa !21
  br i1 %t123, label %bb43, label %bb44
bb43:
  %t124 = load ptr, ptr %l2, !tbaa !29
  %t126 = getelementptr { i64, [4 x i64] }, ptr %t124, i32 0, i32 1
  %t127 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t126, i32 0, i32 2
  %t128 = load ptr, ptr %t127
  store ptr %t128, ptr %l11, !tbaa !29
  %t130 = load ptr, ptr %l2, !tbaa !29
  %t132 = getelementptr { i64, [4 x i64] }, ptr %t130, i32 0, i32 1
  %t133 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t132, i32 0, i32 3
  %t134 = load i64, ptr %t133
  store i64 %t134, ptr %l12, !tbaa !24
  br label %bb45
bb44:
  br label %bb50
bb45:
  %t136 = load i64, ptr %l10, !tbaa !24
  %t137 = load i64, ptr %l12, !tbaa !24
  %t140 = icmp eq i64 %t136, %t137
  br i1 %t140, label %bb46, label %bb47
bb46:
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t143 = load ptr, ptr %l9, !tbaa !29
  %t144 = load ptr, ptr %l11, !tbaa !29
  %t148 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esamePlace(ptr %v0, ptr %v1, ptr %v2, ptr %t142, ptr %t143, ptr %t144)
  store i1 %t148, ptr %l84
  br label %bb48
bb47:
  store i1 false, ptr %l80, !tbaa !21
  br label %bb49
bb48:
  %t149 = load i1, ptr %l84, !tbaa !21
  store i1 %t149, ptr %l80, !tbaa !21
  br label %bb49
bb49:
  %t150 = load i1, ptr %l80, !tbaa !21
  store i1 %t150, ptr %rv
  br label %ret
bb50:
  br i1 true, label %bb51, label %bb52
bb51:
  br label %bb53
bb52:
  br label %bb54
bb53:
  store i1 false, ptr %rv
  br label %ret
bb54:
  call void @__olang_check_failed(ptr @olang_loc_664096f84a6143a8_9c45533022ca790c)
  unreachable
bb55:
  %t152 = load ptr, ptr %l1, !tbaa !29
  store ptr %t152, ptr %l86, !tbaa !29
  store i1 false, ptr %l87, !tbaa !21
  %t153 = load ptr, ptr %l86, !tbaa !29
  %t154 = icmp ne ptr %t153, null
  br i1 %t154, label %bb56, label %bb57
bb56:
  %t156 = load ptr, ptr %l86, !tbaa !29
  %t157 = load i64, ptr %t156, !range !{i64 0, i64 8}
  %t159 = icmp eq i64 %t157, 4
  store i1 %t159, ptr %l87, !tbaa !21
  br label %bb57
bb57:
  %t160 = load i1, ptr %l87, !tbaa !21
  br i1 %t160, label %bb58, label %bb59
bb58:
  %t161 = load ptr, ptr %l1, !tbaa !29
  %t163 = getelementptr { i64, [4 x i64] }, ptr %t161, i32 0, i32 1
  %t164 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t163, i32 0, i32 2
  %t165 = load ptr, ptr %t164
  store ptr %t165, ptr %l13, !tbaa !29
  br label %bb60
bb59:
  br label %bb72
bb60:
  %t167 = load ptr, ptr %l2, !tbaa !29
  store ptr %t167, ptr %l92, !tbaa !29
  store i1 false, ptr %l93, !tbaa !21
  %t168 = load ptr, ptr %l92, !tbaa !29
  %t169 = icmp ne ptr %t168, null
  br i1 %t169, label %bb61, label %bb62
bb61:
  %t171 = load ptr, ptr %l92, !tbaa !29
  %t172 = load i64, ptr %t171, !range !{i64 0, i64 8}
  %t174 = icmp eq i64 %t172, 4
  store i1 %t174, ptr %l93, !tbaa !21
  br label %bb62
bb62:
  %t175 = load i1, ptr %l93, !tbaa !21
  br i1 %t175, label %bb63, label %bb64
bb63:
  %t176 = load ptr, ptr %l2, !tbaa !29
  %t178 = getelementptr { i64, [4 x i64] }, ptr %t176, i32 0, i32 1
  %t179 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t178, i32 0, i32 2
  %t180 = load ptr, ptr %t179
  store ptr %t180, ptr %l14, !tbaa !29
  br label %bb65
bb64:
  br label %bb67
bb65:
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t183 = load ptr, ptr %l13, !tbaa !29
  %t185 = getelementptr %"compiler/typed:Elem", ptr %t183, i32 0, i32 0
  %t186 = load ptr, ptr %t185, !tbaa !29
  %t187 = load ptr, ptr %l14, !tbaa !29
  %t189 = getelementptr %"compiler/typed:Elem", ptr %t187, i32 0, i32 0
  %t190 = load ptr, ptr %t189, !tbaa !29
  %t194 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esamePlace(ptr %v0, ptr %v1, ptr %v2, ptr %t182, ptr %t186, ptr %t190)
  store i1 %t194, ptr %l103
  br label %bb66
bb66:
  %t195 = load i1, ptr %l103, !tbaa !21
  store i1 %t195, ptr %rv
  br label %ret
bb67:
  br i1 true, label %bb68, label %bb69
bb68:
  br label %bb70
bb69:
  br label %bb71
bb70:
  store i1 false, ptr %rv
  br label %ret
bb71:
  call void @__olang_check_failed(ptr @olang_loc_5f0b92ad49630279_51f88f4b15ed303d)
  unreachable
bb72:
  %t197 = load ptr, ptr %l1, !tbaa !29
  store ptr %t197, ptr %l105, !tbaa !29
  store i1 false, ptr %l106, !tbaa !21
  %t198 = load ptr, ptr %l105, !tbaa !29
  %t199 = icmp ne ptr %t198, null
  br i1 %t199, label %bb73, label %bb74
bb73:
  %t201 = load ptr, ptr %l105, !tbaa !29
  %t202 = load i64, ptr %t201, !range !{i64 0, i64 8}
  %t204 = icmp eq i64 %t202, 5
  store i1 %t204, ptr %l106, !tbaa !21
  br label %bb74
bb74:
  %t205 = load i1, ptr %l106, !tbaa !21
  br i1 %t205, label %bb75, label %bb76
bb75:
  %t206 = load ptr, ptr %l1, !tbaa !29
  %t208 = getelementptr { i64, [4 x i64] }, ptr %t206, i32 0, i32 1
  %t209 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t208, i32 0, i32 2
  %t210 = load ptr, ptr %t209
  store ptr %t210, ptr %l15, !tbaa !29
  br label %bb77
bb76:
  br label %bb92
bb77:
  %t212 = load ptr, ptr %l2, !tbaa !29
  store ptr %t212, ptr %l111, !tbaa !29
  store i1 false, ptr %l112, !tbaa !21
  %t213 = load ptr, ptr %l111, !tbaa !29
  %t214 = icmp ne ptr %t213, null
  br i1 %t214, label %bb78, label %bb79
bb78:
  %t216 = load ptr, ptr %l111, !tbaa !29
  %t217 = load i64, ptr %t216, !range !{i64 0, i64 8}
  %t219 = icmp eq i64 %t217, 5
  store i1 %t219, ptr %l112, !tbaa !21
  br label %bb79
bb79:
  %t220 = load i1, ptr %l112, !tbaa !21
  br i1 %t220, label %bb80, label %bb81
bb80:
  %t221 = load ptr, ptr %l2, !tbaa !29
  %t223 = getelementptr { i64, [4 x i64] }, ptr %t221, i32 0, i32 1
  %t224 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t223, i32 0, i32 2
  %t225 = load ptr, ptr %t224
  store ptr %t225, ptr %l16, !tbaa !29
  br label %bb82
bb81:
  br label %bb87
bb82:
  %t227 = load ptr, ptr %l15, !tbaa !29
  %t229 = getelementptr %"compiler/typed:Payload", ptr %t227, i32 0, i32 1
  %t230 = load i64, ptr %t229, !tbaa !24
  %t231 = load ptr, ptr %l16, !tbaa !29
  %t233 = getelementptr %"compiler/typed:Payload", ptr %t231, i32 0, i32 1
  %t234 = load i64, ptr %t233, !tbaa !24
  %t237 = icmp eq i64 %t230, %t234
  br i1 %t237, label %bb83, label %bb84
bb83:
  %t239 = load ptr, ptr %l0, !tbaa !29
  %t240 = load ptr, ptr %l15, !tbaa !29
  %t242 = getelementptr %"compiler/typed:Payload", ptr %t240, i32 0, i32 0
  %t243 = load ptr, ptr %t242, !tbaa !29
  %t244 = load ptr, ptr %l16, !tbaa !29
  %t246 = getelementptr %"compiler/typed:Payload", ptr %t244, i32 0, i32 0
  %t247 = load ptr, ptr %t246, !tbaa !29
  %t251 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esamePlace(ptr %v0, ptr %v1, ptr %v2, ptr %t239, ptr %t243, ptr %t247)
  store i1 %t251, ptr %l128
  br label %bb85
bb84:
  store i1 false, ptr %l122, !tbaa !21
  br label %bb86
bb85:
  %t252 = load i1, ptr %l128, !tbaa !21
  store i1 %t252, ptr %l122, !tbaa !21
  br label %bb86
bb86:
  %t253 = load i1, ptr %l122, !tbaa !21
  store i1 %t253, ptr %rv
  br label %ret
bb87:
  br i1 true, label %bb88, label %bb89
bb88:
  br label %bb90
bb89:
  br label %bb91
bb90:
  store i1 false, ptr %rv
  br label %ret
bb91:
  call void @__olang_check_failed(ptr @olang_loc_265c788dd5eed9e_866edb98fc8c38ea)
  unreachable
bb92:
  %t255 = load ptr, ptr %l1, !tbaa !29
  store ptr %t255, ptr %l130, !tbaa !29
  store i1 false, ptr %l131, !tbaa !21
  %t256 = load ptr, ptr %l130, !tbaa !29
  %t257 = icmp ne ptr %t256, null
  br i1 %t257, label %bb93, label %bb94
bb93:
  %t259 = load ptr, ptr %l130, !tbaa !29
  %t260 = load i64, ptr %t259, !range !{i64 0, i64 8}
  %t262 = icmp eq i64 %t260, 2
  store i1 %t262, ptr %l131, !tbaa !21
  br label %bb94
bb94:
  %t263 = load i1, ptr %l131, !tbaa !21
  br i1 %t263, label %bb95, label %bb96
bb95:
  %t264 = load ptr, ptr %l1, !tbaa !29
  %t266 = getelementptr { i64, [4 x i64] }, ptr %t264, i32 0, i32 1
  %t267 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t266, i32 0, i32 2
  %t268 = load ptr, ptr %t267
  store ptr %t268, ptr %l17, !tbaa !29
  br label %bb97
bb96:
  br label %bb117
bb97:
  %t270 = load ptr, ptr %l2, !tbaa !29
  store ptr %t270, ptr %l136, !tbaa !29
  store i1 false, ptr %l137, !tbaa !21
  %t271 = load ptr, ptr %l136, !tbaa !29
  %t272 = icmp ne ptr %t271, null
  br i1 %t272, label %bb98, label %bb99
bb98:
  %t274 = load ptr, ptr %l136, !tbaa !29
  %t275 = load i64, ptr %t274, !range !{i64 0, i64 8}
  %t277 = icmp eq i64 %t275, 2
  store i1 %t277, ptr %l137, !tbaa !21
  br label %bb99
bb99:
  %t278 = load i1, ptr %l137, !tbaa !21
  br i1 %t278, label %bb100, label %bb101
bb100:
  %t279 = load ptr, ptr %l2, !tbaa !29
  %t281 = getelementptr { i64, [4 x i64] }, ptr %t279, i32 0, i32 1
  %t282 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t281, i32 0, i32 2
  %t283 = load ptr, ptr %t282
  store ptr %t283, ptr %l18, !tbaa !29
  br label %bb102
bb101:
  br label %bb112
bb102:
  %t285 = load ptr, ptr %l17, !tbaa !29
  %t287 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v1, ptr %v1, ptr %t285)
  store ptr %t287, ptr %l143
  br label %bb103
bb103:
  %t288 = load ptr, ptr %l143, !tbaa !29
  store ptr %t288, ptr %l19, !tbaa !29
  %t289 = load ptr, ptr %l18, !tbaa !29
  %t291 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v2, ptr %v2, ptr %t289)
  store ptr %t291, ptr %l145
  br label %bb104
bb104:
  %t292 = load ptr, ptr %l145, !tbaa !29
  store ptr %t292, ptr %l20, !tbaa !29
  %t293 = load ptr, ptr %l19, !tbaa !29
  %t295 = icmp eq ptr %t293, null
  %t297 = xor i1 %t295, true
  br i1 %t297, label %bb105, label %bb106
bb105:
  %t299 = load ptr, ptr %l20, !tbaa !29
  %t301 = icmp eq ptr %t299, null
  %t303 = xor i1 %t301, true
  store i1 %t303, ptr %l149, !tbaa !21
  br label %bb107
bb106:
  store i1 false, ptr %l149, !tbaa !21
  br label %bb107
bb107:
  %t305 = load i1, ptr %l149, !tbaa !21
  br i1 %t305, label %bb108, label %bb109
bb108:
  %t306 = load ptr, ptr %l0, !tbaa !29
  %t307 = load ptr, ptr %l19, !tbaa !29
  %t308 = load ptr, ptr %l20, !tbaa !29
  %t312 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esamePlace(ptr %v0, ptr %v1, ptr %v2, ptr %t306, ptr %t307, ptr %t308)
  store i1 %t312, ptr %l157
  br label %bb110
bb109:
  store i1 false, ptr %l153, !tbaa !21
  br label %bb111
bb110:
  %t313 = load i1, ptr %l157, !tbaa !21
  store i1 %t313, ptr %l153, !tbaa !21
  br label %bb111
bb111:
  %t314 = load i1, ptr %l153, !tbaa !21
  store i1 %t314, ptr %rv
  br label %ret
bb112:
  br i1 true, label %bb113, label %bb114
bb113:
  br label %bb115
bb114:
  br label %bb116
bb115:
  store i1 false, ptr %rv
  br label %ret
bb116:
  call void @__olang_check_failed(ptr @olang_loc_6ac4c8202b0b581f_2f15107fd7d9b5ab)
  unreachable
bb117:
  br i1 true, label %bb118, label %bb119
bb118:
  br label %bb120
bb119:
  br label %bb121
bb120:
  store i1 false, ptr %rv
  br label %ret
bb121:
  call void @__olang_check_failed(ptr @olang_loc_8bfef52d6d2c65e4_ce3ff42f583fc170)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eseqBase(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l11 = alloca ptr
  %l13 = alloca i32
  %l14 = alloca i32
  %l21 = alloca i64
  %l24 = alloca i64
  %l42 = alloca ptr
  %l44 = alloca i32
  %l45 = alloca i1
  %l47 = alloca %"compiler/source:Span"
  %l50 = alloca ptr
  %l52 = alloca i32
  %l53 = alloca i32
  %l57 = alloca ptr
  %rv = alloca ptr
  %t93 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a2, ptr %l3, !tbaa !29
  %t3 = load ptr, ptr %l0, !tbaa !29
  store ptr %t3, ptr %l11, !tbaa !29
  %t4 = load ptr, ptr %l3, !tbaa !29
  %t6 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t4)
  store i32 %t6, ptr %l13
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l11, !tbaa !29
  %t8 = load i32, ptr %l13, !tbaa !23
  %t9 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayOf(ptr %v0, ptr %t7, i32 %t8)
  store i32 %t9, ptr %l14
  br label %bb2
bb2:
  %t10 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t11 = load i32, ptr %l14, !tbaa !23
  %t13 = icmp eq i32 %t11, %t10
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l3, !tbaa !29
  store ptr %t15, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  store i64 0, ptr %l4, !tbaa !24
  store i64 4, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t17 = load i64, ptr %l5, !tbaa !24
  %t18 = load i64, ptr %l4, !tbaa !24
  %t21 = icmp sgt i64 %t17, %t18
  br i1 %t21, label %bb6, label %bb7
bb6:
  %t23 = load i64, ptr %l6, !tbaa !24
  %t25 = icmp sgt i64 %t23, 0
  br i1 %t25, label %bb8, label %bb9
bb7:
  store i64 0, ptr %l21, !tbaa !24
  br label %bb11
bb8:
  %t27 = load i64, ptr %l5, !tbaa !24
  %t28 = load i64, ptr %l4, !tbaa !24
  %t31 = sub i64 %t27, %t28
  %t32 = load i64, ptr %l6, !tbaa !24
  %t35 = add i64 %t31, %t32
  %t37 = sub i64 %t35, 1
  %t38 = load i64, ptr %l6, !tbaa !24
  %t41 = sdiv i64 %t37, %t38
  store i64 %t41, ptr %l24, !tbaa !24
  br label %bb10
bb9:
  store i64 0, ptr %l24, !tbaa !24
  br label %bb10
bb10:
  %t43 = load i64, ptr %l24, !tbaa !24
  store i64 %t43, ptr %l21, !tbaa !24
  br label %bb11
bb11:
  %t44 = load i64, ptr %l21, !tbaa !24
  store i64 %t44, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb12
bb12:
  %t45 = load i64, ptr %l8, !tbaa !24
  %t46 = load i64, ptr %l7, !tbaa !24
  %t49 = icmp slt i64 %t45, %t46
  %t51 = xor i1 %t49, true
  br i1 %t51, label %bb13, label %bb14
bb13:
  br label %bb25
bb14:
  br label %bb15
bb15:
  %t53 = load i64, ptr %l4, !tbaa !24
  %t54 = load i64, ptr %l8, !tbaa !24
  %t55 = load i64, ptr %l6, !tbaa !24
  %t58 = mul i64 %t54, %t55
  %t61 = add i64 %t53, %t58
  store i64 %t61, ptr %l9, !tbaa !24
  %t63 = load ptr, ptr %l0, !tbaa !29
  store ptr %t63, ptr %l42, !tbaa !29
  %t64 = load ptr, ptr %l3, !tbaa !29
  %t66 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t64)
  store i32 %t66, ptr %l44
  br label %bb16
bb16:
  %t67 = load ptr, ptr %l42, !tbaa !29
  %t68 = load i32, ptr %l44, !tbaa !23
  %t69 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t67, i32 %t68)
  store i1 %t69, ptr %l45
  br label %bb17
bb17:
  %t70 = load i1, ptr %l45, !tbaa !21
  %t71 = xor i1 %t70, true
  br i1 %t71, label %bb18, label %bb19
bb18:
  br label %bb25
bb19:
  br label %bb20
bb20:
  %t73 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t73, ptr %l47
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/check:Checker", ptr %t74, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !29
  %t79 = getelementptr %"compiler/generic:Program", ptr %t77, i32 0, i32 2
  store ptr %t79, ptr %l50, !tbaa !29
  %t80 = load ptr, ptr %l3, !tbaa !29
  %t82 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t80)
  store i32 %t82, ptr %l52
  br label %bb21
bb21:
  %t83 = load ptr, ptr %l50, !tbaa !29
  %t84 = load i32, ptr %l52, !tbaa !23
  %t85 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t83, i32 %t84)
  store i32 %t85, ptr %l53
  br label %bb22
bb22:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t87 = load %"compiler/source:Span", ptr %l1
  %t88 = load ptr, ptr %l3, !tbaa !29
  %t92 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v1, ptr %v1, ptr %t86, %"compiler/source:Span" %t87, ptr %t88)
  store ptr %t92, ptr %l57
  br label %bb23
bb23:
  store { i64, [4 x i64] } zeroinitializer, ptr %t93
  %t94 = getelementptr { i64, [4 x i64] }, ptr %t93, i32 0, i32 0
  store i64 2, ptr %t94
  %t95 = load %"compiler/source:Span", ptr %l47
  %t96 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t95, 0
  %t97 = load i32, ptr %l53, !tbaa !23
  %t98 = insertvalue { %"compiler/source:Span", i32, ptr } %t96, i32 %t97, 1
  %t99 = load ptr, ptr %l57, !tbaa !29
  %t100 = insertvalue { %"compiler/source:Span", i32, ptr } %t98, ptr %t99, 2
  %t101 = getelementptr { i64, [4 x i64] }, ptr %t93, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t100, ptr %t101
  %t102 = load { i64, [4 x i64] }, ptr %t93
  %t104 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t102, ptr %t104
  store ptr %t104, ptr %l3, !tbaa !29
  br label %bb24
bb24:
  %t106 = load i64, ptr %l8, !tbaa !24
  %t108 = add i64 %t106, 1
  store i64 %t108, ptr %l8, !tbaa !24
  br label %bb12
bb25:
  %t110 = load ptr, ptr %l3, !tbaa !29
  store ptr %t110, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eseqRows(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l27 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l30 = alloca i64
  %l32 = alloca i64
  %l37 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l41 = alloca i1
  %l42 = alloca ptr
  %l43 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %l52 = alloca ptr
  %l56 = alloca i1
  %l60 = alloca i1
  %l66 = alloca i1
  %l70 = alloca i1
  %l77 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l85 = alloca i64
  %l88 = alloca i64
  %l112 = alloca { i64, ptr }
  %l124 = alloca i64
  %l127 = alloca i64
  %l145 = alloca ptr
  %l147 = alloca { i64, ptr }
  %l150 = alloca %"compiler/source:Span"
  %l162 = alloca i64
  %l165 = alloca i64
  %l184 = alloca { i64, ptr }
  %l189 = alloca ptr
  %l191 = alloca { i64, ptr }
  %rv = alloca ptr
  %t259 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fast_3aPattern_26_3e_26_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l27
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l27
  %t3 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %t3
  store ptr %t3, ptr %l3, !tbaa !29
  store ptr %a1, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t7 = load i64, ptr %l5, !tbaa !24
  store i64 %t7, ptr %l30, !tbaa !24
  %t8 = load ptr, ptr %l4, !tbaa !29
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fast_3aPattern_26_3e_H06f4ae43b564aa38800728c5b9a6edfe(ptr %v1, ptr %t8)
  store i64 %t10, ptr %l32
  br label %bb3
bb3:
  %t11 = load i64, ptr %l30, !tbaa !24
  %t12 = load i64, ptr %l32, !tbaa !24
  %t13 = icmp slt i64 %t11, %t12
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb4, label %bb5
bb4:
  br label %bb81
bb5:
  br label %bb6
bb6:
  %t17 = load ptr, ptr %l4, !tbaa !29
  %t18 = load i64, ptr %l5, !tbaa !24
  %t21 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fast_3aPattern_26_3e_Hb04d670045d084ea2498d9030c4fbba9(ptr %v1, ptr %v1, ptr %t17, i64 %t18)
  store { i64, ptr } %t21, ptr %l37
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t22, ptr %l6, !tbaa !27
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t24, ptr %l39, !tbaa !27
  %t25 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 0
  %t28 = load ptr, ptr %t27, !tbaa !39
  %t31 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epatWild(ptr %v0, ptr %v1, ptr %t23, ptr %t28)
  store i1 %t31, ptr %l41
  br label %bb8
bb8:
  %t32 = load i1, ptr %l41, !tbaa !21
  br i1 %t32, label %bb9, label %bb10
bb9:
  %t33 = load ptr, ptr %l3, !tbaa !29
  store ptr %t33, ptr %l42, !tbaa !29
  %t34 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t34, ptr %l43, !tbaa !27
  %t35 = icmp sge i64 0, 0
  br i1 %t35, label %bb11, label %bb12
bb10:
  br label %bb17
bb11:
  %t37 = icmp sle i64 0, 1152921504606846975
  br i1 %t37, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @olang_loc_e4bef59f129059d8_aff2623e63fdc5dc)
  unreachable
bb13:
  %t39 = mul i64 0, 8
  %t40 = insertvalue { i64, ptr } undef, i64 0, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t42 = load i64, ptr %l2, !tbaa !24
  %t43 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t46 = call { i64, ptr } @compiler_2fcheck_2epatTail(ptr %v1, ptr %v1, ptr %v1, { i64, ptr } %t43, { i64, ptr } %t41, i64 %t42)
  store { i64, ptr } %t46, ptr %l48
  br label %bb15
bb14:
  call void @__olang_check_failed(ptr @olang_loc_e4bef59f129059d8_aff2623e63fdc5dc)
  unreachable
bb15:
  %t47 = load ptr, ptr %l42, !tbaa !29
  %t48 = load { i64, ptr }, ptr %l48, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fast_3aPattern_26_3e_H19842cc3f9f17801919cd111c108caa0(ptr %v2, ptr %v1, ptr %t47, { i64, ptr } %t48)
  br label %bb16
bb16:
  br label %bb80
bb17:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t50, ptr %l50, !tbaa !27
  %t51 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !27
  %t53 = getelementptr ptr, ptr %t52, i64 0
  %t54 = load ptr, ptr %t53, !tbaa !39
  %t57 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eshapeOf(ptr %v0, ptr %v1, ptr %v2, ptr %t49, ptr %t54)
  store ptr %t57, ptr %l52
  br label %bb18
bb18:
  %t58 = load ptr, ptr %l52, !tbaa !29
  store ptr %t58, ptr %l7, !tbaa !29
  %t59 = load ptr, ptr %l7, !tbaa !29
  %t61 = getelementptr %"compiler/check:elemsShape", ptr %t59, i32 0, i32 1
  %t62 = load i64, ptr %t61, !tbaa !24
  %t64 = icmp eq i64 %t62, -2
  br i1 %t64, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l56, !tbaa !21
  br label %bb24
bb20:
  %t66 = load ptr, ptr %l7, !tbaa !29
  %t68 = getelementptr %"compiler/check:elemsShape", ptr %t66, i32 0, i32 1
  %t69 = load i64, ptr %t68, !tbaa !24
  %t71 = icmp eq i64 %t69, -1
  br i1 %t71, label %bb21, label %bb22
bb21:
  %t73 = load ptr, ptr %l7, !tbaa !29
  %t75 = getelementptr %"compiler/check:elemsShape", ptr %t73, i32 0, i32 0
  %t76 = load { i64, ptr }, ptr %t75, !tbaa !27
  %t78 = extractvalue { i64, ptr } %t76, 0
  %t79 = load i64, ptr %l2, !tbaa !24
  %t82 = icmp ne i64 %t78, %t79
  store i1 %t82, ptr %l60, !tbaa !21
  br label %bb23
bb22:
  store i1 false, ptr %l60, !tbaa !21
  br label %bb23
bb23:
  %t84 = load i1, ptr %l60, !tbaa !21
  store i1 %t84, ptr %l56, !tbaa !21
  br label %bb24
bb24:
  %t85 = load i1, ptr %l56, !tbaa !21
  br i1 %t85, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l66, !tbaa !21
  br label %bb30
bb26:
  %t86 = load ptr, ptr %l7, !tbaa !29
  %t88 = getelementptr %"compiler/check:elemsShape", ptr %t86, i32 0, i32 1
  %t89 = load i64, ptr %t88, !tbaa !24
  %t91 = icmp sge i64 %t89, 0
  br i1 %t91, label %bb27, label %bb28
bb27:
  %t93 = load ptr, ptr %l7, !tbaa !29
  %t95 = getelementptr %"compiler/check:elemsShape", ptr %t93, i32 0, i32 0
  %t96 = load { i64, ptr }, ptr %t95, !tbaa !27
  %t98 = extractvalue { i64, ptr } %t96, 0
  %t100 = sub i64 %t98, 1
  %t101 = load i64, ptr %l2, !tbaa !24
  %t104 = icmp sgt i64 %t100, %t101
  store i1 %t104, ptr %l70, !tbaa !21
  br label %bb29
bb28:
  store i1 false, ptr %l70, !tbaa !21
  br label %bb29
bb29:
  %t106 = load i1, ptr %l70, !tbaa !21
  store i1 %t106, ptr %l66, !tbaa !21
  br label %bb30
bb30:
  %t107 = load i1, ptr %l66, !tbaa !21
  br i1 %t107, label %bb31, label %bb32
bb31:
  br label %bb80
bb32:
  br label %bb33
bb33:
  %t108 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPattern_26_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t108, ptr %l77
  br label %bb34
bb34:
  %t109 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l77
  %t110 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t109, ptr %t110
  store ptr %t110, ptr %l8, !tbaa !29
  store i64 0, ptr %l9, !tbaa !24
  %t112 = load ptr, ptr %l7, !tbaa !29
  %t114 = getelementptr %"compiler/check:elemsShape", ptr %t112, i32 0, i32 0
  %t115 = load { i64, ptr }, ptr %t114, !tbaa !27
  %t117 = extractvalue { i64, ptr } %t115, 0
  store i64 %t117, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t119 = load i64, ptr %l10, !tbaa !24
  %t120 = load i64, ptr %l9, !tbaa !24
  %t123 = icmp sgt i64 %t119, %t120
  br i1 %t123, label %bb35, label %bb36
bb35:
  %t125 = load i64, ptr %l11, !tbaa !24
  %t127 = icmp sgt i64 %t125, 0
  br i1 %t127, label %bb37, label %bb38
bb36:
  store i64 0, ptr %l85, !tbaa !24
  br label %bb40
bb37:
  %t129 = load i64, ptr %l10, !tbaa !24
  %t130 = load i64, ptr %l9, !tbaa !24
  %t133 = sub i64 %t129, %t130
  %t134 = load i64, ptr %l11, !tbaa !24
  %t137 = add i64 %t133, %t134
  %t139 = sub i64 %t137, 1
  %t140 = load i64, ptr %l11, !tbaa !24
  %t143 = sdiv i64 %t139, %t140
  store i64 %t143, ptr %l88, !tbaa !24
  br label %bb39
bb38:
  store i64 0, ptr %l88, !tbaa !24
  br label %bb39
bb39:
  %t145 = load i64, ptr %l88, !tbaa !24
  store i64 %t145, ptr %l85, !tbaa !24
  br label %bb40
bb40:
  %t146 = load i64, ptr %l85, !tbaa !24
  store i64 %t146, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb41
bb41:
  %t147 = load i64, ptr %l13, !tbaa !24
  %t148 = load i64, ptr %l12, !tbaa !24
  %t151 = icmp slt i64 %t147, %t148
  %t153 = xor i1 %t151, true
  br i1 %t153, label %bb42, label %bb43
bb42:
  br label %bb64
bb43:
  br label %bb44
bb44:
  %t155 = load i64, ptr %l9, !tbaa !24
  %t156 = load i64, ptr %l13, !tbaa !24
  %t157 = load i64, ptr %l11, !tbaa !24
  %t160 = mul i64 %t156, %t157
  %t163 = add i64 %t155, %t160
  store i64 %t163, ptr %l14, !tbaa !24
  %t165 = load i64, ptr %l14, !tbaa !24
  %t166 = load ptr, ptr %l7, !tbaa !29
  %t168 = getelementptr %"compiler/check:elemsShape", ptr %t166, i32 0, i32 1
  %t169 = load i64, ptr %t168, !tbaa !24
  %t172 = icmp ne i64 %t165, %t169
  br i1 %t172, label %bb45, label %bb46
bb45:
  %t174 = load ptr, ptr %l8, !tbaa !29
  %t175 = load ptr, ptr %l7, !tbaa !29
  %t177 = getelementptr %"compiler/check:elemsShape", ptr %t175, i32 0, i32 0
  %t178 = load { i64, ptr }, ptr %t177, !tbaa !27
  store { i64, ptr } %t178, ptr %l112, !tbaa !27
  %t179 = load i64, ptr %l14, !tbaa !24
  %t181 = getelementptr { i64, ptr }, ptr %l112, i32 0, i32 1
  %t182 = load ptr, ptr %t181, !tbaa !27
  %t183 = getelementptr ptr, ptr %t182, i64 %t179
  %t184 = load ptr, ptr %t183, !tbaa !39
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPattern_26_3e_2ePush_3ccompiler_2fast_3aPattern_26_3e(ptr %v2, ptr %v2, ptr %t174, ptr %t184)
  br label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb63
bb48:
  store i64 0, ptr %l15, !tbaa !24
  %t187 = load i64, ptr %l2, !tbaa !24
  %t188 = load ptr, ptr %l7, !tbaa !29
  %t190 = getelementptr %"compiler/check:elemsShape", ptr %t188, i32 0, i32 0
  %t191 = load { i64, ptr }, ptr %t190, !tbaa !27
  %t193 = extractvalue { i64, ptr } %t191, 0
  %t195 = sub i64 %t193, 1
  %t198 = sub i64 %t187, %t195
  store i64 %t198, ptr %l16, !tbaa !24
  store i64 1, ptr %l17, !tbaa !24
  %t200 = load i64, ptr %l16, !tbaa !24
  %t201 = load i64, ptr %l15, !tbaa !24
  %t204 = icmp sgt i64 %t200, %t201
  br i1 %t204, label %bb49, label %bb50
bb49:
  %t206 = load i64, ptr %l17, !tbaa !24
  %t208 = icmp sgt i64 %t206, 0
  br i1 %t208, label %bb51, label %bb52
bb50:
  store i64 0, ptr %l124, !tbaa !24
  br label %bb54
bb51:
  %t210 = load i64, ptr %l16, !tbaa !24
  %t211 = load i64, ptr %l15, !tbaa !24
  %t214 = sub i64 %t210, %t211
  %t215 = load i64, ptr %l17, !tbaa !24
  %t218 = add i64 %t214, %t215
  %t220 = sub i64 %t218, 1
  %t221 = load i64, ptr %l17, !tbaa !24
  %t224 = sdiv i64 %t220, %t221
  store i64 %t224, ptr %l127, !tbaa !24
  br label %bb53
bb52:
  store i64 0, ptr %l127, !tbaa !24
  br label %bb53
bb53:
  %t226 = load i64, ptr %l127, !tbaa !24
  store i64 %t226, ptr %l124, !tbaa !24
  br label %bb54
bb54:
  %t227 = load i64, ptr %l124, !tbaa !24
  store i64 %t227, ptr %l18, !tbaa !24
  store i64 0, ptr %l19, !tbaa !24
  br label %bb55
bb55:
  %t228 = load i64, ptr %l19, !tbaa !24
  %t229 = load i64, ptr %l18, !tbaa !24
  %t232 = icmp slt i64 %t228, %t229
  %t234 = xor i1 %t232, true
  br i1 %t234, label %bb56, label %bb57
bb56:
  br label %bb62
bb57:
  br label %bb58
bb58:
  %t236 = load i64, ptr %l15, !tbaa !24
  %t237 = load i64, ptr %l19, !tbaa !24
  %t238 = load i64, ptr %l17, !tbaa !24
  %t241 = mul i64 %t237, %t238
  %t244 = add i64 %t236, %t241
  store i64 %t244, ptr %l20, !tbaa !24
  %t246 = load ptr, ptr %l8, !tbaa !29
  store ptr %t246, ptr %l145, !tbaa !29
  %t247 = load ptr, ptr %l7, !tbaa !29
  %t249 = getelementptr %"compiler/check:elemsShape", ptr %t247, i32 0, i32 0
  %t250 = load { i64, ptr }, ptr %t249, !tbaa !27
  store { i64, ptr } %t250, ptr %l147, !tbaa !27
  %t251 = load i64, ptr %l14, !tbaa !24
  %t253 = getelementptr { i64, ptr }, ptr %l147, i32 0, i32 1
  %t254 = load ptr, ptr %t253, !tbaa !27
  %t255 = getelementptr ptr, ptr %t254, i64 %t251
  %t256 = load ptr, ptr %t255, !tbaa !39
  %t258 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aPattern_2eSpan(ptr %v2, ptr %t256)
  store %"compiler/source:Span" %t258, ptr %l150
  br label %bb59
bb59:
  store { i64, [4 x i64] } zeroinitializer, ptr %t259
  %t260 = getelementptr { i64, [4 x i64] }, ptr %t259, i32 0, i32 0
  store i64 0, ptr %t260
  %t261 = load %"compiler/source:Span", ptr %l150
  %t262 = insertvalue { %"compiler/source:Span" } undef, %"compiler/source:Span" %t261, 0
  %t263 = getelementptr { i64, [4 x i64] }, ptr %t259, i32 0, i32 1
  store { %"compiler/source:Span" } %t262, ptr %t263
  %t264 = load { i64, [4 x i64] }, ptr %t259
  %t266 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 40, i64 8)
  store { i64, [4 x i64] } %t264, ptr %t266
  %t267 = load ptr, ptr %l145, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPattern_26_3e_2ePush_3ccompiler_2fast_3aPattern_26_3e(ptr %v2, ptr %v2, ptr %t267, ptr %t266)
  br label %bb60
bb60:
  br label %bb61
bb61:
  %t269 = load i64, ptr %l19, !tbaa !24
  %t271 = add i64 %t269, 1
  store i64 %t271, ptr %l19, !tbaa !24
  br label %bb55
bb62:
  br label %bb63
bb63:
  %t273 = load i64, ptr %l13, !tbaa !24
  %t275 = add i64 %t273, 1
  store i64 %t275, ptr %l13, !tbaa !24
  br label %bb41
bb64:
  store i64 1, ptr %l21, !tbaa !24
  %t277 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t279 = extractvalue { i64, ptr } %t277, 0
  store i64 %t279, ptr %l22, !tbaa !24
  store i64 1, ptr %l23, !tbaa !24
  %t281 = load i64, ptr %l22, !tbaa !24
  %t282 = load i64, ptr %l21, !tbaa !24
  %t285 = icmp sgt i64 %t281, %t282
  br i1 %t285, label %bb65, label %bb66
bb65:
  %t287 = load i64, ptr %l23, !tbaa !24
  %t289 = icmp sgt i64 %t287, 0
  br i1 %t289, label %bb67, label %bb68
bb66:
  store i64 0, ptr %l162, !tbaa !24
  br label %bb70
bb67:
  %t291 = load i64, ptr %l22, !tbaa !24
  %t292 = load i64, ptr %l21, !tbaa !24
  %t295 = sub i64 %t291, %t292
  %t296 = load i64, ptr %l23, !tbaa !24
  %t299 = add i64 %t295, %t296
  %t301 = sub i64 %t299, 1
  %t302 = load i64, ptr %l23, !tbaa !24
  %t305 = sdiv i64 %t301, %t302
  store i64 %t305, ptr %l165, !tbaa !24
  br label %bb69
bb68:
  store i64 0, ptr %l165, !tbaa !24
  br label %bb69
bb69:
  %t307 = load i64, ptr %l165, !tbaa !24
  store i64 %t307, ptr %l162, !tbaa !24
  br label %bb70
bb70:
  %t308 = load i64, ptr %l162, !tbaa !24
  store i64 %t308, ptr %l24, !tbaa !24
  store i64 0, ptr %l25, !tbaa !24
  br label %bb71
bb71:
  %t309 = load i64, ptr %l25, !tbaa !24
  %t310 = load i64, ptr %l24, !tbaa !24
  %t313 = icmp slt i64 %t309, %t310
  %t315 = xor i1 %t313, true
  br i1 %t315, label %bb72, label %bb73
bb72:
  br label %bb77
bb73:
  br label %bb74
bb74:
  %t317 = load i64, ptr %l21, !tbaa !24
  %t318 = load i64, ptr %l25, !tbaa !24
  %t319 = load i64, ptr %l23, !tbaa !24
  %t322 = mul i64 %t318, %t319
  %t325 = add i64 %t317, %t322
  %t327 = load ptr, ptr %l8, !tbaa !29
  %t328 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t328, ptr %l184, !tbaa !27
  %t331 = getelementptr { i64, ptr }, ptr %l184, i32 0, i32 1
  %t332 = load ptr, ptr %t331, !tbaa !27
  %t333 = getelementptr ptr, ptr %t332, i64 %t325
  %t334 = load ptr, ptr %t333, !tbaa !39
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPattern_26_3e_2ePush_3ccompiler_2fast_3aPattern_26_3e(ptr %v2, ptr %v1, ptr %t327, ptr %t334)
  br label %bb75
bb75:
  br label %bb76
bb76:
  %t337 = load i64, ptr %l25, !tbaa !24
  %t339 = add i64 %t337, 1
  store i64 %t339, ptr %l25, !tbaa !24
  br label %bb71
bb77:
  %t341 = load ptr, ptr %l3, !tbaa !29
  store ptr %t341, ptr %l189, !tbaa !29
  %t342 = load ptr, ptr %l8, !tbaa !29
  %t344 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPattern_26_3e_2eToArr_H3d785ef7fade1f29078b6e80f1d617ba(ptr %v2, ptr %v2, ptr %t342)
  store { i64, ptr } %t344, ptr %l191
  br label %bb78
bb78:
  %t345 = load ptr, ptr %l189, !tbaa !29
  %t346 = load { i64, ptr }, ptr %l191, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fast_3aPattern_26_3e_H19842cc3f9f17801919cd111c108caa0(ptr %v2, ptr %v2, ptr %t345, { i64, ptr } %t346)
  br label %bb79
bb79:
  br label %bb80
bb80:
  %t347 = load i64, ptr %l5, !tbaa !24
  %t349 = add i64 %t347, 1
  store i64 %t349, ptr %l5, !tbaa !24
  br label %bb2
bb81:
  %t351 = load ptr, ptr %l3, !tbaa !29
  store ptr %t351, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estoreCopy(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l5 = alloca i32
  %l8 = alloca i1
  %l14 = alloca i1
  %l15 = alloca i1
  %l20 = alloca i1
  %l21 = alloca i1
  %l23 = alloca i1
  %l26 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t1)
  store i32 %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load i32, ptr %l5, !tbaa !23
  store i32 %t4, ptr %l3, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t6 = load i32, ptr %l3, !tbaa !23
  %t9 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t5, i32 %t6)
  store i1 %t9, ptr %l8
  br label %bb2
bb2:
  %t10 = load i1, ptr %l8, !tbaa !21
  br i1 %t10, label %bb3, label %bb4
bb3:
  %t11 = load ptr, ptr %l2, !tbaa !29
  store ptr %t11, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/check:Checker", ptr %t13, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t18 = getelementptr %"compiler/generic:Program", ptr %t16, i32 0, i32 2
  %t19 = load i32, ptr %l3, !tbaa !23
  %t22 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnsParts(ptr %v0, ptr %t18, i32 %t19)
  store i1 %t22, ptr %l14
  br label %bb6
bb6:
  %t23 = load i1, ptr %l14, !tbaa !21
  br i1 %t23, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb14
bb8:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/check:Checker", ptr %t24, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t29 = getelementptr %"compiler/generic:Program", ptr %t27, i32 0, i32 2
  %t30 = load i32, ptr %l3, !tbaa !23
  %t33 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnedPart(ptr %v0, ptr %t29, i32 %t30)
  store i1 %t33, ptr %l20
  br label %bb9
bb9:
  %t34 = load i1, ptr %l20, !tbaa !21
  br i1 %t34, label %bb10, label %bb11
bb10:
  %t35 = load ptr, ptr %l1, !tbaa !29
  %t37 = call i1 @compiler_2fcheck_2epartPlace(ptr %v1, ptr %t35)
  store i1 %t37, ptr %l23
  br label %bb12
bb11:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb13
bb12:
  %t38 = load i1, ptr %l23, !tbaa !21
  store i1 %t38, ptr %l21, !tbaa !21
  br label %bb13
bb13:
  %t39 = load i1, ptr %l21, !tbaa !21
  store i1 %t39, ptr %l15, !tbaa !21
  br label %bb14
bb14:
  %t40 = load i1, ptr %l15, !tbaa !21
  br i1 %t40, label %bb15, label %bb16
bb15:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load ptr, ptr %l2, !tbaa !29
  %t45 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eownCopy(ptr %v0, ptr %v2, ptr %v3, ptr %t41, ptr %t42)
  store ptr %t45, ptr %l26
  br label %bb17
bb16:
  br label %bb18
bb17:
  %t46 = load ptr, ptr %l26, !tbaa !29
  store ptr %t46, ptr %rv
  br label %ret
bb18:
  %t47 = load ptr, ptr %l2, !tbaa !29
  store ptr %t47, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estoreInto(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, %"compiler/source:Span" %a4, ptr %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i32
  %l10 = alloca { i64, [3 x i64] }
  %l12 = alloca i32
  %l15 = alloca i64
  %l18 = alloca i1
  %l20 = alloca i1
  %l25 = alloca i1
  %l33 = alloca ptr
  %l36 = alloca i32
  %l40 = alloca i1
  %l45 = alloca i1
  %l46 = alloca i1
  %l50 = alloca i1
  %l54 = alloca i1
  %l59 = alloca i1
  %l62 = alloca ptr
  %l63 = alloca ptr
  %l65 = alloca { i64, ptr }
  %l68 = alloca ptr
  %l71 = alloca { i64, [3 x i64] }
  %l79 = alloca ptr
  %l85 = alloca i32
  %l87 = alloca i32
  %l89 = alloca i1
  %l90 = alloca ptr
  %l93 = alloca i32
  %l94 = alloca i1
  %l102 = alloca ptr
  %l105 = alloca i1
  %l107 = alloca i1
  %l111 = alloca i64
  %l113 = alloca ptr
  %l115 = alloca ptr
  %l117 = alloca %"compiler/source:Span"
  %l119 = alloca i1
  %l120 = alloca ptr
  %l121 = alloca %"compiler/source:Span"
  %l122 = alloca ptr
  %l126 = alloca ptr
  %t171 = alloca { i64, [4 x i64] }, align 8
  %t228 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  store ptr %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t1)
  store i32 %t3, ptr %l12
  br label %bb1
bb1:
  %t4 = load i32, ptr %l12, !tbaa !23
  store i32 %t4, ptr %l6, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/check:Checker", ptr %t5, i32 0, i32 10
  %t9 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2eLen__H22c160154c8542d83ffe3c77c98973d0(ptr %v0, ptr %t7)
  store i64 %t9, ptr %l15
  br label %bb2
bb2:
  %t10 = load i64, ptr %l15, !tbaa !24
  store i64 %t10, ptr %l7, !tbaa !24
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load i32, ptr %l6, !tbaa !23
  %t15 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t11, i32 %t12)
  store i1 %t15, ptr %l18
  br label %bb3
bb3:
  %t16 = load i1, ptr %l18, !tbaa !21
  %t17 = xor i1 %t16, true
  br i1 %t17, label %bb4, label %bb5
bb4:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/check:Checker", ptr %t19, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t24 = getelementptr %"compiler/generic:Program", ptr %t22, i32 0, i32 2
  %t25 = load i32, ptr %l6, !tbaa !23
  %t28 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %t24, i32 %t25)
  store i1 %t28, ptr %l25
  br label %bb6
bb5:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb7
bb6:
  %t29 = load i1, ptr %l25, !tbaa !21
  store i1 %t29, ptr %l20, !tbaa !21
  br label %bb7
bb7:
  %t30 = load i1, ptr %l20, !tbaa !21
  br i1 %t30, label %bb8, label %bb9
bb8:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/check:Checker", ptr %t31, i32 0, i32 10
  %t34 = load ptr, ptr %l2, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2ePush_H521773322b2b1b179ce4cc03a1674857(ptr %v0, ptr %v1, ptr %t33, ptr %t34)
  br label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb11
bb11:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load ptr, ptr %l3, !tbaa !29
  %t40 = load i32, ptr %l6, !tbaa !23
  %t44 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v2, ptr %v0, ptr %t37, ptr %t38, i32 %t40)
  store ptr %t44, ptr %l33
  br label %bb12
bb12:
  %t45 = load ptr, ptr %l33, !tbaa !29
  store ptr %t45, ptr %l8, !tbaa !29
  %t46 = load ptr, ptr %l8, !tbaa !29
  %t49 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t46)
  store i32 %t49, ptr %l36
  br label %bb13
bb13:
  %t50 = load i32, ptr %l36, !tbaa !23
  store i32 %t50, ptr %l9, !tbaa !23
  %t51 = load ptr, ptr %l5, !tbaa !29
  %t53 = icmp eq ptr %t51, null
  %t55 = xor i1 %t53, true
  br i1 %t55, label %bb14, label %bb15
bb14:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/check:Checker", ptr %t57, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t62 = getelementptr %"compiler/generic:Program", ptr %t60, i32 0, i32 2
  %t63 = load i32, ptr %l6, !tbaa !23
  %t66 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %t62, i32 %t63)
  store i1 %t66, ptr %l45
  br label %bb16
bb15:
  store i1 false, ptr %l40, !tbaa !21
  br label %bb17
bb16:
  %t67 = load i1, ptr %l45, !tbaa !21
  store i1 %t67, ptr %l40, !tbaa !21
  br label %bb17
bb17:
  %t68 = load i1, ptr %l40, !tbaa !21
  br i1 %t68, label %bb18, label %bb19
bb18:
  %t69 = load i32, ptr %l9, !tbaa !23
  %t70 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t73 = icmp ne i32 %t69, %t70
  store i1 %t73, ptr %l46, !tbaa !21
  br label %bb20
bb19:
  store i1 false, ptr %l46, !tbaa !21
  br label %bb20
bb20:
  %t75 = load i1, ptr %l46, !tbaa !21
  br i1 %t75, label %bb21, label %bb22
bb21:
  %t76 = load i32, ptr %l9, !tbaa !23
  %t77 = load i32, ptr @G_2ecompiler_2ftypes_2eNullT, !tbaa !23
  %t80 = icmp ne i32 %t76, %t77
  store i1 %t80, ptr %l50, !tbaa !21
  br label %bb23
bb22:
  store i1 false, ptr %l50, !tbaa !21
  br label %bb23
bb23:
  %t82 = load i1, ptr %l50, !tbaa !21
  br i1 %t82, label %bb24, label %bb25
bb24:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/check:Checker", ptr %t83, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !29
  %t88 = getelementptr %"compiler/generic:Program", ptr %t86, i32 0, i32 2
  %t89 = load i32, ptr %l9, !tbaa !23
  %t92 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %t88, i32 %t89)
  store i1 %t92, ptr %l59
  br label %bb26
bb25:
  store i1 false, ptr %l54, !tbaa !21
  br label %bb27
bb26:
  %t93 = load i1, ptr %l59, !tbaa !21
  %t94 = xor i1 %t93, true
  store i1 %t94, ptr %l54, !tbaa !21
  br label %bb27
bb27:
  %t96 = load i1, ptr %l54, !tbaa !21
  br i1 %t96, label %bb28, label %bb29
bb28:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t97)
  store ptr %t99, ptr %l62
  br label %bb30
bb29:
  br label %bb32
bb30:
  %t100 = load ptr, ptr %l62, !tbaa !29
  store ptr %t100, ptr %l63, !tbaa !29
  %t101 = load ptr, ptr %l5, !tbaa !29
  %t103 = call { i64, ptr } @compiler_2fcheck_2epathOf(ptr %v3, ptr %v0, ptr %t101)
  store { i64, ptr } %t103, ptr %l65
  br label %bb31
bb31:
  %t104 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t105 = load ptr, ptr %l63, !tbaa !29
  %t106 = getelementptr %"compiler/check:frame", ptr %t105, i32 0, i32 46
  store { i64, ptr } %t104, ptr %t106, !tbaa !27
  br label %bb32
bb32:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = getelementptr %"compiler/check:Checker", ptr %t107, i32 0, i32 13
  %t110 = load { i64, [3 x i64] }, ptr %t109
  store { i64, [3 x i64] } %t110, ptr %l10
  %t112 = load ptr, ptr %l0, !tbaa !29
  store ptr %t112, ptr %l68, !tbaa !29
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t114 = load ptr, ptr %l2, !tbaa !29
  %t117 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplaceAt(ptr %v0, ptr %v1, ptr %t113, ptr %t114)
  store { i64, [3 x i64] } %t117, ptr %l71
  br label %bb33
bb33:
  %t118 = load { i64, [3 x i64] }, ptr %l71
  %t119 = load ptr, ptr %l68, !tbaa !29
  %t120 = getelementptr %"compiler/check:Checker", ptr %t119, i32 0, i32 13
  store { i64, [3 x i64] } %t118, ptr %t120
  %t121 = load i32, ptr %l6, !tbaa !23
  %t122 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t125 = icmp ne i32 %t121, %t122
  br i1 %t125, label %bb34, label %bb35
bb34:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t128 = load ptr, ptr %l8, !tbaa !29
  %t129 = load i32, ptr %l6, !tbaa !23
  %t135 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v0, ptr %v0, ptr %t127, ptr %t128, i32 %t129, %"compiler/source:Span" %a4)
  store ptr %t135, ptr %l79
  br label %bb36
bb35:
  br label %bb37
bb36:
  %t136 = load ptr, ptr %l79, !tbaa !29
  store ptr %t136, ptr %l8, !tbaa !29
  br label %bb37
bb37:
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t138 = load { i64, [3 x i64] }, ptr %l10
  %t141 = getelementptr %"compiler/check:Checker", ptr %t137, i32 0, i32 13
  store { i64, [3 x i64] } %t138, ptr %t141
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t144 = getelementptr %"compiler/check:Checker", ptr %t142, i32 0, i32 10
  %t145 = load i64, ptr %l7, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2eTrun_Haa7c8ccc08c8123d0b87c9688e5d351e(ptr %v0, ptr %t144, i64 %t145)
  br label %bb38
bb38:
  %t148 = load i32, ptr %l6, !tbaa !23
  store i32 %t148, ptr %l85, !tbaa !23
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t151 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %t149)
  store i32 %t151, ptr %l87
  br label %bb39
bb39:
  %t152 = load i32, ptr %l85, !tbaa !23
  %t153 = load i32, ptr %l87, !tbaa !23
  %t154 = icmp eq i32 %t152, %t153
  br i1 %t154, label %bb40, label %bb41
bb40:
  %t156 = load ptr, ptr %l0, !tbaa !29
  store ptr %t156, ptr %l90, !tbaa !29
  %t157 = load ptr, ptr %l8, !tbaa !29
  %t160 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t157)
  store i32 %t160, ptr %l93
  br label %bb42
bb41:
  store i1 false, ptr %l89, !tbaa !21
  br label %bb44
bb42:
  %t161 = load ptr, ptr %l90, !tbaa !29
  %t162 = load i32, ptr %l93, !tbaa !23
  %t163 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t161, i32 %t162)
  store i1 %t163, ptr %l94
  br label %bb43
bb43:
  %t164 = load i1, ptr %l94, !tbaa !21
  store i1 %t164, ptr %l89, !tbaa !21
  br label %bb44
bb44:
  %t165 = load i1, ptr %l89, !tbaa !21
  br i1 %t165, label %bb45, label %bb46
bb45:
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t167 = load %"compiler/source:Span", ptr %l1
  %t168 = load %"compiler/source:Span", ptr %l1
  %t169 = load i32, ptr %l6, !tbaa !23
  %t170 = load ptr, ptr %l8, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t171
  %t172 = getelementptr { i64, [4 x i64] }, ptr %t171, i32 0, i32 0
  store i64 2, ptr %t172
  %t174 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t168, 0
  %t176 = insertvalue { %"compiler/source:Span", i32, ptr } %t174, i32 %t169, 1
  %t178 = insertvalue { %"compiler/source:Span", i32, ptr } %t176, ptr %t170, 2
  %t179 = getelementptr { i64, [4 x i64] }, ptr %t171, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t178, ptr %t179
  %t180 = load { i64, [4 x i64] }, ptr %t171
  %t182 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t180, ptr %t182
  %t186 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v0, ptr %v0, ptr %t166, %"compiler/source:Span" %t167, ptr %t182)
  store ptr %t186, ptr %l102
  br label %bb47
bb46:
  br label %bb48
bb47:
  %t187 = load ptr, ptr %l102, !tbaa !29
  store ptr %t187, ptr %l8, !tbaa !29
  br label %bb48
bb48:
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t189 = load i32, ptr %l6, !tbaa !23
  %t192 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t188, i32 %t189)
  store i1 %t192, ptr %l105
  br label %bb49
bb49:
  %t193 = load i1, ptr %l105, !tbaa !21
  %t194 = xor i1 %t193, true
  br i1 %t194, label %bb50, label %bb51
bb50:
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t197 = load ptr, ptr %l2, !tbaa !29
  %t201 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroRoot(ptr %v0, ptr %v1, ptr %t196, ptr %t197)
  store i64 %t201, ptr %l111
  br label %bb52
bb51:
  store i1 false, ptr %l107, !tbaa !21
  br label %bb53
bb52:
  %t202 = load i64, ptr %l111, !tbaa !24
  %t203 = icmp slt i64 %t202, 0
  store i1 %t203, ptr %l107, !tbaa !21
  br label %bb53
bb53:
  %t205 = load i1, ptr %l107, !tbaa !21
  br i1 %t205, label %bb54, label %bb55
bb54:
  %t206 = load ptr, ptr %l0, !tbaa !29
  store ptr %t206, ptr %l113, !tbaa !29
  %t207 = load ptr, ptr %l8, !tbaa !29
  store ptr %t207, ptr %l115, !tbaa !29
  %t209 = load ptr, ptr %l3, !tbaa !29
  %t211 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t209)
  store %"compiler/source:Span" %t211, ptr %l117
  br label %bb56
bb55:
  br label %bb58
bb56:
  %t212 = load i64, ptr @G_2ecompiler_2fcheck_2eRoStored, !tbaa !24
  %t213 = load ptr, ptr %l113, !tbaa !29
  %t214 = load ptr, ptr %l115, !tbaa !29
  %t215 = load %"compiler/source:Span", ptr %l117
  %t217 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroStore(ptr %v0, ptr %v0, ptr %t213, ptr %t214, %"compiler/source:Span" %t215, i64 %t212)
  store i1 %t217, ptr %l119
  br label %bb57
bb57:
  br label %bb58
bb58:
  %t218 = load ptr, ptr %l0, !tbaa !29
  store ptr %t218, ptr %l120, !tbaa !29
  %t219 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t219, ptr %l121
  %t220 = load ptr, ptr %l2, !tbaa !29
  store ptr %t220, ptr %l122, !tbaa !29
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t222 = load ptr, ptr %l2, !tbaa !29
  %t223 = load ptr, ptr %l8, !tbaa !29
  %t227 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estoreCopy(ptr %v0, ptr %v1, ptr %v0, ptr %v0, ptr %t221, ptr %t222, ptr %t223)
  store ptr %t227, ptr %l126
  br label %bb59
bb59:
  store { i64, [3 x i64] } zeroinitializer, ptr %t228
  %t229 = getelementptr { i64, [3 x i64] }, ptr %t228, i32 0, i32 0
  store i64 1, ptr %t229
  %t230 = load %"compiler/source:Span", ptr %l121
  %t231 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t230, 0
  %t232 = load ptr, ptr %l122, !tbaa !29
  %t233 = insertvalue { %"compiler/source:Span", ptr, ptr } %t231, ptr %t232, 1
  %t234 = load ptr, ptr %l126, !tbaa !29
  %t235 = insertvalue { %"compiler/source:Span", ptr, ptr } %t233, ptr %t234, 2
  %t236 = getelementptr { i64, [3 x i64] }, ptr %t228, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t235, ptr %t236
  %t237 = load { i64, [3 x i64] }, ptr %t228
  %t239 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t237, ptr %t239
  %t240 = load ptr, ptr %l120, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t240, ptr %t239)
  br label %bb60
bb60:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextLit(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l5 = alloca ptr
  %l7 = alloca i32
  %l9 = alloca i32
  %l11 = alloca ptr
  %l13 = alloca i64
  %l16 = alloca { i64, ptr }
  %rv = alloca ptr
  %t28 = alloca { i64, [2 x i64] }, align 8
  %t36 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1, ptr %l2
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"compiler/check:Checker", ptr %t2, i32 0, i32 1
  %t5 = load ptr, ptr %t4, !tbaa !29
  %t7 = getelementptr %"compiler/generic:Program", ptr %t5, i32 0, i32 2
  store ptr %t7, ptr %l5, !tbaa !29
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %t8)
  store i32 %t10, ptr %l7
  br label %bb1
bb1:
  %t11 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t12 = load ptr, ptr %l5, !tbaa !29
  %t13 = load i32, ptr %l7, !tbaa !23
  %t15 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t12, i32 %t13, i64 %t11)
  store i32 %t15, ptr %l9
  br label %bb2
bb2:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t16)
  store ptr %t18, ptr %l11
  br label %bb3
bb3:
  %t19 = load ptr, ptr %l11, !tbaa !29
  %t21 = getelementptr %"compiler/check:frame", ptr %t19, i32 0, i32 2
  %t22 = load i64, ptr %t21, !tbaa !24
  store i64 %t22, ptr %l13, !tbaa !24
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load %"compiler/source:Span", ptr %l1
  %t27 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estrBytes(ptr %v0, ptr %v1, ptr %t23, %"compiler/source:Span" %t24)
  store { i64, ptr } %t27, ptr %l16
  br label %bb4
bb4:
  store { i64, [2 x i64] } zeroinitializer, ptr %t28
  %t29 = getelementptr { i64, [2 x i64] }, ptr %t28, i32 0, i32 0
  store i64 1, ptr %t29
  %t30 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t31 = insertvalue { { i64, ptr } } undef, { i64, ptr } %t30, 0
  %t32 = getelementptr { i64, [2 x i64] }, ptr %t28, i32 0, i32 1
  store { { i64, ptr } } %t31, ptr %t32
  %t33 = load { i64, [2 x i64] }, ptr %t28
  %t35 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 24, i64 8)
  store { i64, [2 x i64] } %t33, ptr %t35
  store { i64, [5 x i64] } zeroinitializer, ptr %t36
  %t37 = getelementptr { i64, [5 x i64] }, ptr %t36, i32 0, i32 0
  store i64 1, ptr %t37
  %t38 = load %"compiler/source:Span", ptr %l2
  %t39 = insertvalue { %"compiler/source:Span", i32, i64, ptr } undef, %"compiler/source:Span" %t38, 0
  %t40 = load i32, ptr %l9, !tbaa !23
  %t41 = insertvalue { %"compiler/source:Span", i32, i64, ptr } %t39, i32 %t40, 1
  %t42 = load i64, ptr %l13, !tbaa !24
  %t43 = insertvalue { %"compiler/source:Span", i32, i64, ptr } %t41, i64 %t42, 2
  %t45 = insertvalue { %"compiler/source:Span", i32, i64, ptr } %t43, ptr %t35, 3
  %t46 = getelementptr { i64, [5 x i64] }, ptr %t36, i32 0, i32 1
  store { %"compiler/source:Span", i32, i64, ptr } %t45, ptr %t46
  %t47 = load { i64, [5 x i64] }, ptr %t36
  %t49 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 48, i64 8)
  store { i64, [5 x i64] } %t47, ptr %t49
  store ptr %t49, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etopAssert(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, %"compiler/source:Span" %a2, ptr %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l11 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca i64
  %l17 = alloca ptr
  %l20 = alloca ptr
  %l22 = alloca i32
  %l24 = alloca i32
  %l25 = alloca i64
  %l28 = alloca i1
  %l32 = alloca i1
  %l36 = alloca ptr
  %l42 = alloca ptr
  %l44 = alloca i64
  %l45 = alloca %"compiler/source:Span"
  %l48 = alloca %"compiler/source:Span"
  %l51 = alloca %"compiler/check:TopAssertAsk"
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t3 = load ptr, ptr %l3, !tbaa !29
  %t4 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t9 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etopBody(ptr %v0, ptr %v1, ptr %t1, i64 %t2, ptr %t3, i32 %t4)
  store i64 %t9, ptr %l11
  br label %bb1
bb1:
  %t10 = load i64, ptr %l11, !tbaa !24
  store i64 %t10, ptr %l5, !tbaa !24
  store i64 -1, ptr %l6, !tbaa !24
  %t11 = load ptr, ptr %l4, !tbaa !29
  %t13 = icmp eq ptr %t11, null
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb2, label %bb3
bb2:
  %t17 = load ptr, ptr %l0, !tbaa !29
  store ptr %t17, ptr %l15, !tbaa !29
  %t18 = load i64, ptr %l1, !tbaa !24
  store i64 %t18, ptr %l16, !tbaa !24
  %t19 = load ptr, ptr %l4, !tbaa !29
  store ptr %t19, ptr %l17, !tbaa !29
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/check:Checker", ptr %t20, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t25 = getelementptr %"compiler/generic:Program", ptr %t23, i32 0, i32 2
  store ptr %t25, ptr %l20, !tbaa !29
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %t26)
  store i32 %t28, ptr %l22
  br label %bb4
bb3:
  br label %bb7
bb4:
  %t29 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t30 = load ptr, ptr %l20, !tbaa !29
  %t31 = load i32, ptr %l22, !tbaa !23
  %t33 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t30, i32 %t31, i64 %t29)
  store i32 %t33, ptr %l24
  br label %bb5
bb5:
  %t34 = load ptr, ptr %l15, !tbaa !29
  %t35 = load i64, ptr %l16, !tbaa !24
  %t36 = load ptr, ptr %l17, !tbaa !29
  %t37 = load i32, ptr %l24, !tbaa !23
  %t38 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etopBody(ptr %v0, ptr %v2, ptr %t34, i64 %t35, ptr %t36, i32 %t37)
  store i64 %t38, ptr %l25
  br label %bb6
bb6:
  %t39 = load i64, ptr %l25, !tbaa !24
  store i64 %t39, ptr %l6, !tbaa !24
  br label %bb7
bb7:
  %t40 = load i64, ptr %l5, !tbaa !24
  %t42 = icmp slt i64 %t40, 0
  br i1 %t42, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l28, !tbaa !21
  br label %bb13
bb9:
  %t44 = load ptr, ptr %l4, !tbaa !29
  %t46 = icmp eq ptr %t44, null
  %t48 = xor i1 %t46, true
  br i1 %t48, label %bb10, label %bb11
bb10:
  %t50 = load i64, ptr %l6, !tbaa !24
  %t52 = icmp slt i64 %t50, 0
  store i1 %t52, ptr %l32, !tbaa !21
  br label %bb12
bb11:
  store i1 false, ptr %l32, !tbaa !21
  br label %bb12
bb12:
  %t54 = load i1, ptr %l32, !tbaa !21
  store i1 %t54, ptr %l28, !tbaa !21
  br label %bb13
bb13:
  %t55 = load i1, ptr %l28, !tbaa !21
  br i1 %t55, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb15:
  br label %bb16
bb16:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/check:Checker", ptr %t56, i32 0, i32 89
  store ptr %t58, ptr %l36, !tbaa !29
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/check:Checker", ptr %t59, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = getelementptr %"compiler/generic:Program", ptr %t62, i32 0, i32 0
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t67 = getelementptr %"compiler/load:Loader", ptr %t65, i32 0, i32 10
  %t68 = load i64, ptr %l1, !tbaa !24
  %t71 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t67, i64 %t68)
  store ptr %t71, ptr %l42
  br label %bb17
bb17:
  %t72 = load ptr, ptr %l42, !tbaa !29
  %t74 = getelementptr %"compiler/load:Module", ptr %t72, i32 0, i32 4
  %t75 = load i64, ptr %t74, !tbaa !24
  store i64 %t75, ptr %l44, !tbaa !24
  store %"compiler/source:Span" %a2, ptr %l45
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t78 = load ptr, ptr %l3, !tbaa !29
  %t81 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoperatorOf(ptr %v0, ptr %v1, ptr %t77, ptr %t78)
  store %"compiler/source:Span" %t81, ptr %l48
  br label %bb18
bb18:
  %t82 = load i64, ptr %l5, !tbaa !24
  %t83 = load i64, ptr %l6, !tbaa !24
  %t84 = load i64, ptr %l44, !tbaa !24
  %t85 = load %"compiler/source:Span", ptr %l45
  %t86 = load %"compiler/source:Span", ptr %l48
  %t89 = call %"compiler/check:TopAssertAsk" @compiler_2fcheck_3aTopAssertAsk_2ector(ptr %s0, i64 %t84, %"compiler/source:Span" %t85, %"compiler/source:Span" %t86, i64 %t82, i64 %t83)
  store %"compiler/check:TopAssertAsk" %t89, ptr %l51
  br label %bb19
bb19:
  %t90 = load ptr, ptr %l36, !tbaa !29
  %t91 = load %"compiler/check:TopAssertAsk", ptr %l51
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aTopAssertAsk_3e_2eP_H67072fc16e996275e069a499f28fddf9(ptr %v0, ptr %t90, %"compiler/check:TopAssertAsk" %t91)
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etopSetDecls(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, { i64, ptr } %a2, i1 %a3, i1 %a4, ptr %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i1
  %l4 = alloca i1
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca %"compiler/source:Span"
  %l13 = alloca ptr
  %l14 = alloca { i64, [3 x i64] }
  %l15 = alloca i32
  %l16 = alloca ptr
  %l17 = alloca %"compiler/source:Span"
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca ptr
  %l34 = alloca ptr
  %l48 = alloca { i64, ptr }
  %l51 = alloca ptr
  %l52 = alloca i1
  %l67 = alloca ptr
  %l68 = alloca { i64, [3 x i64] }
  %l69 = alloca %"compiler/msgs:Msg"
  %l70 = alloca i64
  %l72 = alloca i32
  %l75 = alloca ptr
  %l80 = alloca ptr
  %l82 = alloca %"compiler/source:Span"
  %l85 = alloca ptr
  %l91 = alloca { i64, [3 x i64] }
  %l95 = alloca { i64, ptr }
  %l97 = alloca %"compiler/msgs:Msg"
  %l98 = alloca i64
  %l105 = alloca i64
  %l108 = alloca i64
  %l127 = alloca { i64, ptr }
  %l137 = alloca i1
  %l139 = alloca { i64, ptr }
  %l144 = alloca ptr
  %l150 = alloca { i64, [3 x i64] }
  %l154 = alloca { i64, ptr }
  %l156 = alloca %"compiler/msgs:Msg"
  %l157 = alloca i64
  %l163 = alloca ptr
  %l169 = alloca { i64, [3 x i64] }
  %l172 = alloca { i64, ptr }
  %l173 = alloca %"compiler/msgs:Msg"
  %l174 = alloca i64
  %l178 = alloca i1
  %l179 = alloca ptr
  %l180 = alloca { i64, [3 x i64] }
  %l183 = alloca { i64, ptr }
  %l184 = alloca %"compiler/msgs:Msg"
  %l185 = alloca i64
  %l188 = alloca ptr
  %l189 = alloca i1
  %l194 = alloca ptr
  %l195 = alloca i64
  %l196 = alloca ptr
  %l197 = alloca ptr
  %l198 = alloca i1
  %l199 = alloca i1
  %l202 = alloca ptr
  %l203 = alloca i64
  %l209 = alloca %"compiler/source:Span"
  %l211 = alloca i64
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %t88 = alloca { i64, [3 x i64] }, align 8
  %t148 = alloca { i64, [3 x i64] }, align 8
  %t284 = alloca { i64, [3 x i64] }, align 8
  %t335 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store i1 %a3, ptr %l3
  store i1 %a4, ptr %l4
  store ptr %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 0
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = getelementptr %"compiler/load:Loader", ptr %t13, i32 0, i32 10
  %t16 = load i64, ptr %l1, !tbaa !24
  %t19 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t15, i64 %t16)
  store ptr %t19, ptr %l34
  br label %bb4
bb4:
  %t20 = load ptr, ptr %l34, !tbaa !29
  %t22 = getelementptr %"compiler/load:Module", ptr %t20, i32 0, i32 4
  %t23 = load i64, ptr %t22, !tbaa !24
  store i64 %t23, ptr %l6, !tbaa !24
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/check:Checker", ptr %t25, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !29
  %t30 = getelementptr %"compiler/generic:Program", ptr %t28, i32 0, i32 0
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t33 = getelementptr %"compiler/load:Loader", ptr %t31, i32 0, i32 4
  %t34 = load ptr, ptr %t33, !tbaa !29
  store ptr %t34, ptr %l7, !tbaa !29
  %t36 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t36, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t38 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t38, 0
  store i64 %t40, ptr %l10, !tbaa !24
  br label %bb5
bb5:
  %t42 = load i64, ptr %l9, !tbaa !24
  %t43 = load i64, ptr %l10, !tbaa !24
  %t46 = icmp slt i64 %t42, %t43
  %t48 = xor i1 %t46, true
  br i1 %t48, label %bb6, label %bb7
bb6:
  br label %bb91
bb7:
  br label %bb8
bb8:
  %t50 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t50, ptr %l48, !tbaa !27
  %t51 = load i64, ptr %l9, !tbaa !24
  %t53 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !27
  %t55 = getelementptr ptr, ptr %t54, i64 %t51
  %t56 = load ptr, ptr %t55, !tbaa !39
  store ptr %t56, ptr %l11, !tbaa !29
  %t58 = load ptr, ptr %l11, !tbaa !29
  store ptr %t58, ptr %l51, !tbaa !29
  store i1 false, ptr %l52, !tbaa !21
  %t59 = load ptr, ptr %l51, !tbaa !29
  %t60 = icmp ne ptr %t59, null
  br i1 %t60, label %bb9, label %bb10
bb9:
  %t62 = load ptr, ptr %l51, !tbaa !29
  %t63 = load i64, ptr %t62, !range !{i64 0, i64 11}
  %t65 = icmp eq i64 %t63, 8
  store i1 %t65, ptr %l52, !tbaa !21
  br label %bb10
bb10:
  %t66 = load i1, ptr %l52, !tbaa !21
  br i1 %t66, label %bb11, label %bb12
bb11:
  %t67 = load ptr, ptr %l11, !tbaa !29
  %t69 = getelementptr { i64, [6 x i64] }, ptr %t67, i32 0, i32 1
  %t70 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t69, i32 0, i32 0
  %t71 = load %"compiler/source:Span", ptr %t70
  store %"compiler/source:Span" %t71, ptr %l12
  %t73 = load ptr, ptr %l11, !tbaa !29
  %t75 = getelementptr { i64, [6 x i64] }, ptr %t73, i32 0, i32 1
  %t76 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t75, i32 0, i32 1
  %t77 = load ptr, ptr %t76
  store ptr %t77, ptr %l13, !tbaa !29
  br label %bb13
bb12:
  br label %bb72
bb13:
  store %olang.scope zeroinitializer, ptr %s4
  %t79 = load i64, ptr %l6, !tbaa !24
  %t80 = getelementptr %"compiler/source:Span", ptr %l12, i32 0, i32 0
  %t81 = load i32, ptr %t80, !tbaa !23
  %t83 = sext i32 %t81 to i64
  %t84 = getelementptr %"compiler/source:Span", ptr %l12, i32 0, i32 1
  %t85 = load i32, ptr %t84, !tbaa !23
  %t87 = sext i32 %t85 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t88
  %t89 = getelementptr { i64, [3 x i64] }, ptr %t88, i32 0, i32 0
  store i64 3, ptr %t89
  %t91 = insertvalue { i64, i64, i64 } undef, i64 %t79, 0
  %t93 = insertvalue { i64, i64, i64 } %t91, i64 %t83, 1
  %t95 = insertvalue { i64, i64, i64 } %t93, i64 %t87, 2
  %t96 = getelementptr { i64, [3 x i64] }, ptr %t88, i32 0, i32 1
  store { i64, i64, i64 } %t95, ptr %t96
  %t97 = load { i64, [3 x i64] }, ptr %t88
  store { i64, [3 x i64] } %t97, ptr %l14
  %t99 = load i1, ptr %l3, !tbaa !21
  %t101 = xor i1 %t99, true
  br i1 %t101, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s5
  %t103 = load ptr, ptr %l7, !tbaa !29
  store ptr %t103, ptr %l67, !tbaa !29
  %t104 = load { i64, [3 x i64] }, ptr %l14
  store { i64, [3 x i64] } %t104, ptr %l68
  %t105 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTopSetPlace(ptr %s5)
  store %"compiler/msgs:Msg" %t105, ptr %l69
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t106 = load ptr, ptr %l67, !tbaa !29
  %t107 = load { i64, [3 x i64] }, ptr %l68
  %t108 = load %"compiler/msgs:Msg", ptr %l69
  %t109 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s5, ptr %t106, { i64, [3 x i64] } %t107, %"compiler/msgs:Msg" %t108)
  store i64 %t109, ptr %l70
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s4)
  br label %bb90
bb18:
  %t110 = load ptr, ptr %l13, !tbaa !29
  %t112 = call i32 @compiler_2fcheck_2esetName(ptr %v1, ptr %t110)
  store i32 %t112, ptr %l72
  br label %bb19
bb19:
  %t113 = load i32, ptr %l72, !tbaa !23
  store i32 %t113, ptr %l15, !tbaa !23
  %t114 = load i32, ptr %l15, !tbaa !23
  %t116 = icmp ne i32 %t114, 0
  br i1 %t116, label %bb20, label %bb21
bb20:
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t120 = getelementptr %"compiler/check:Checker", ptr %t118, i32 0, i32 1
  %t121 = load ptr, ptr %t120, !tbaa !29
  %t122 = load i64, ptr %l1, !tbaa !24
  %t123 = load i32, ptr %l15, !tbaa !23
  %t127 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eGlobalDecl(ptr %v0, ptr %s4, ptr %t121, i64 %t122, i32 %t123)
  store ptr %t127, ptr %l80
  br label %bb22
bb21:
  store ptr null, ptr %l75, !tbaa !29
  br label %bb23
bb22:
  %t128 = load ptr, ptr %l80, !tbaa !29
  store ptr %t128, ptr %l75, !tbaa !29
  br label %bb23
bb23:
  %t129 = load ptr, ptr %l75, !tbaa !29
  store ptr %t129, ptr %l16, !tbaa !29
  %t130 = load ptr, ptr %l13, !tbaa !29
  %t132 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t130)
  store %"compiler/source:Span" %t132, ptr %l82
  br label %bb24
bb24:
  %t133 = load %"compiler/source:Span", ptr %l82
  store %"compiler/source:Span" %t133, ptr %l17
  %t134 = load ptr, ptr %l16, !tbaa !29
  %t136 = icmp eq ptr %t134, null
  br i1 %t136, label %bb25, label %bb26
bb25:
  store %olang.scope zeroinitializer, ptr %s6
  %t138 = load ptr, ptr %l7, !tbaa !29
  store ptr %t138, ptr %l85, !tbaa !29
  %t139 = load i64, ptr %l6, !tbaa !24
  %t140 = getelementptr %"compiler/source:Span", ptr %l17, i32 0, i32 0
  %t141 = load i32, ptr %t140, !tbaa !23
  %t143 = sext i32 %t141 to i64
  %t144 = getelementptr %"compiler/source:Span", ptr %l17, i32 0, i32 1
  %t145 = load i32, ptr %t144, !tbaa !23
  %t147 = sext i32 %t145 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t148
  %t149 = getelementptr { i64, [3 x i64] }, ptr %t148, i32 0, i32 0
  store i64 3, ptr %t149
  %t151 = insertvalue { i64, i64, i64 } undef, i64 %t139, 0
  %t153 = insertvalue { i64, i64, i64 } %t151, i64 %t143, 1
  %t155 = insertvalue { i64, i64, i64 } %t153, i64 %t147, 2
  %t156 = getelementptr { i64, [3 x i64] }, ptr %t148, i32 0, i32 1
  store { i64, i64, i64 } %t155, ptr %t156
  %t157 = load { i64, [3 x i64] }, ptr %t148
  store { i64, [3 x i64] } %t157, ptr %l91
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t159 = load i64, ptr %l6, !tbaa !24
  %t160 = load %"compiler/source:Span", ptr %l17
  %t164 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc2(ptr %v0, ptr %s6, ptr %t158, i64 %t159, %"compiler/source:Span" %t160)
  store { i64, ptr } %t164, ptr %l95
  br label %bb27
bb26:
  br label %bb30
bb27:
  %t165 = load { i64, ptr }, ptr %l95, !tbaa !27
  %t166 = extractvalue { i64, ptr } %t165, 0
  %t167 = extractvalue { i64, ptr } %t165, 1
  %t168 = mul i64 %t166, 1
  %t169 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t168)
  call void @llvm.memcpy.p0.p0.i64(ptr %t169, ptr %t167, i64 %t168, i1 false)
  %t170 = insertvalue { i64, ptr } undef, i64 %t166, 0
  %t171 = insertvalue { i64, ptr } %t170, ptr %t169, 1
  %t173 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTopSetTarget(ptr %s6, ptr %s6, { i64, ptr } %t171)
  store %"compiler/msgs:Msg" %t173, ptr %l97
  br label %bb28
bb28:
  %t174 = load ptr, ptr %l85, !tbaa !29
  %t175 = load { i64, [3 x i64] }, ptr %l91
  %t176 = load %"compiler/msgs:Msg", ptr %l97
  %t177 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s6, ptr %t174, { i64, [3 x i64] } %t175, %"compiler/msgs:Msg" %t176)
  store i64 %t177, ptr %l98
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s4)
  br label %bb90
bb30:
  store i64 -1, ptr %l18, !tbaa !24
  store i64 0, ptr %l19, !tbaa !24
  %t178 = load ptr, ptr %l16, !tbaa !29
  %t180 = getelementptr %"compiler/ast:VarDecl", ptr %t178, i32 0, i32 0
  %t181 = load { i64, ptr }, ptr %t180, !tbaa !27
  %t183 = extractvalue { i64, ptr } %t181, 0
  store i64 %t183, ptr %l20, !tbaa !24
  store i64 1, ptr %l21, !tbaa !24
  %t185 = load i64, ptr %l20, !tbaa !24
  %t186 = load i64, ptr %l19, !tbaa !24
  %t189 = icmp sgt i64 %t185, %t186
  br i1 %t189, label %bb31, label %bb32
bb31:
  %t191 = load i64, ptr %l21, !tbaa !24
  %t193 = icmp sgt i64 %t191, 0
  br i1 %t193, label %bb33, label %bb34
bb32:
  store i64 0, ptr %l105, !tbaa !24
  br label %bb36
bb33:
  %t195 = load i64, ptr %l20, !tbaa !24
  %t196 = load i64, ptr %l19, !tbaa !24
  %t199 = sub i64 %t195, %t196
  %t200 = load i64, ptr %l21, !tbaa !24
  %t203 = add i64 %t199, %t200
  %t205 = sub i64 %t203, 1
  %t206 = load i64, ptr %l21, !tbaa !24
  %t209 = sdiv i64 %t205, %t206
  store i64 %t209, ptr %l108, !tbaa !24
  br label %bb35
bb34:
  store i64 0, ptr %l108, !tbaa !24
  br label %bb35
bb35:
  %t211 = load i64, ptr %l108, !tbaa !24
  store i64 %t211, ptr %l105, !tbaa !24
  br label %bb36
bb36:
  %t212 = load i64, ptr %l105, !tbaa !24
  store i64 %t212, ptr %l22, !tbaa !24
  store i64 0, ptr %l23, !tbaa !24
  br label %bb37
bb37:
  %t213 = load i64, ptr %l23, !tbaa !24
  %t214 = load i64, ptr %l22, !tbaa !24
  %t217 = icmp slt i64 %t213, %t214
  %t219 = xor i1 %t217, true
  br i1 %t219, label %bb38, label %bb39
bb38:
  br label %bb45
bb39:
  br label %bb40
bb40:
  %t221 = load i64, ptr %l19, !tbaa !24
  %t222 = load i64, ptr %l23, !tbaa !24
  %t223 = load i64, ptr %l21, !tbaa !24
  %t226 = mul i64 %t222, %t223
  %t229 = add i64 %t221, %t226
  store i64 %t229, ptr %l24, !tbaa !24
  %t231 = load ptr, ptr %l16, !tbaa !29
  %t233 = getelementptr %"compiler/ast:VarDecl", ptr %t231, i32 0, i32 0
  %t234 = load { i64, ptr }, ptr %t233, !tbaa !27
  store { i64, ptr } %t234, ptr %l127, !tbaa !27
  %t235 = load i64, ptr %l24, !tbaa !24
  %t237 = getelementptr { i64, ptr }, ptr %l127, i32 0, i32 1
  %t238 = load ptr, ptr %t237, !tbaa !27
  %t239 = getelementptr i32, ptr %t238, i64 %t235
  %t240 = load i32, ptr %t239, !tbaa !33
  %t241 = load i32, ptr %l15, !tbaa !23
  %t244 = icmp eq i32 %t240, %t241
  br i1 %t244, label %bb41, label %bb42
bb41:
  %t246 = load i64, ptr %l24, !tbaa !24
  store i64 %t246, ptr %l18, !tbaa !24
  br label %bb43
bb42:
  br label %bb43
bb43:
  br label %bb44
bb44:
  %t248 = load i64, ptr %l23, !tbaa !24
  %t250 = add i64 %t248, 1
  store i64 %t250, ptr %l23, !tbaa !24
  br label %bb37
bb45:
  %t252 = load i64, ptr %l18, !tbaa !24
  %t254 = icmp slt i64 %t252, 0
  br i1 %t254, label %bb46, label %bb47
bb46:
  store i1 true, ptr %l137, !tbaa !21
  br label %bb48
bb47:
  %t256 = load ptr, ptr %l16, !tbaa !29
  %t258 = getelementptr %"compiler/ast:VarDecl", ptr %t256, i32 0, i32 1
  %t259 = load { i64, ptr }, ptr %t258, !tbaa !27
  store { i64, ptr } %t259, ptr %l139, !tbaa !27
  %t260 = load i64, ptr %l18, !tbaa !24
  %t262 = getelementptr { i64, ptr }, ptr %l139, i32 0, i32 1
  %t263 = load ptr, ptr %t262, !tbaa !27
  %t264 = getelementptr %"compiler/source:Span", ptr %t263, i64 %t260
  %t265 = getelementptr %"compiler/source:Span", ptr %t264, i32 0, i32 0
  %t266 = load i32, ptr %t265, !tbaa !23
  %t267 = getelementptr %"compiler/source:Span", ptr %l12, i32 0, i32 0
  %t268 = load i32, ptr %t267, !tbaa !23
  %t271 = icmp sgt i32 %t266, %t268
  store i1 %t271, ptr %l137, !tbaa !21
  br label %bb48
bb48:
  %t273 = load i1, ptr %l137, !tbaa !21
  br i1 %t273, label %bb49, label %bb50
bb49:
  store %olang.scope zeroinitializer, ptr %s11
  %t274 = load ptr, ptr %l7, !tbaa !29
  store ptr %t274, ptr %l144, !tbaa !29
  %t275 = load i64, ptr %l6, !tbaa !24
  %t276 = getelementptr %"compiler/source:Span", ptr %l17, i32 0, i32 0
  %t277 = load i32, ptr %t276, !tbaa !23
  %t279 = sext i32 %t277 to i64
  %t280 = getelementptr %"compiler/source:Span", ptr %l17, i32 0, i32 1
  %t281 = load i32, ptr %t280, !tbaa !23
  %t283 = sext i32 %t281 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t284
  %t285 = getelementptr { i64, [3 x i64] }, ptr %t284, i32 0, i32 0
  store i64 3, ptr %t285
  %t287 = insertvalue { i64, i64, i64 } undef, i64 %t275, 0
  %t289 = insertvalue { i64, i64, i64 } %t287, i64 %t279, 1
  %t291 = insertvalue { i64, i64, i64 } %t289, i64 %t283, 2
  %t292 = getelementptr { i64, [3 x i64] }, ptr %t284, i32 0, i32 1
  store { i64, i64, i64 } %t291, ptr %t292
  %t293 = load { i64, [3 x i64] }, ptr %t284
  store { i64, [3 x i64] } %t293, ptr %l150
  %t294 = load ptr, ptr %l0, !tbaa !29
  %t295 = load i64, ptr %l6, !tbaa !24
  %t296 = load %"compiler/source:Span", ptr %l17
  %t300 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc2(ptr %v0, ptr %s11, ptr %t294, i64 %t295, %"compiler/source:Span" %t296)
  store { i64, ptr } %t300, ptr %l154
  br label %bb51
bb50:
  br label %bb54
bb51:
  %t301 = load { i64, ptr }, ptr %l154, !tbaa !27
  %t302 = extractvalue { i64, ptr } %t301, 0
  %t303 = extractvalue { i64, ptr } %t301, 1
  %t304 = mul i64 %t302, 1
  %t305 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t304)
  call void @llvm.memcpy.p0.p0.i64(ptr %t305, ptr %t303, i64 %t304, i1 false)
  %t306 = insertvalue { i64, ptr } undef, i64 %t302, 0
  %t307 = insertvalue { i64, ptr } %t306, ptr %t305, 1
  %t309 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTopSetTarget(ptr %s11, ptr %s11, { i64, ptr } %t307)
  store %"compiler/msgs:Msg" %t309, ptr %l156
  br label %bb52
bb52:
  %t310 = load ptr, ptr %l144, !tbaa !29
  %t311 = load { i64, [3 x i64] }, ptr %l150
  %t312 = load %"compiler/msgs:Msg", ptr %l156
  %t313 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s11, ptr %t310, { i64, [3 x i64] } %t311, %"compiler/msgs:Msg" %t312)
  store i64 %t313, ptr %l157
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s4)
  br label %bb90
bb54:
  %t314 = load i64, ptr %l18, !tbaa !24
  %t315 = load ptr, ptr %l16, !tbaa !29
  %t317 = getelementptr %"compiler/ast:VarDecl", ptr %t315, i32 0, i32 3
  %t318 = load { i64, ptr }, ptr %t317, !tbaa !27
  %t320 = extractvalue { i64, ptr } %t318, 0
  %t323 = icmp slt i64 %t314, %t320
  br i1 %t323, label %bb55, label %bb56
bb55:
  store %olang.scope zeroinitializer, ptr %s12
  %t325 = load ptr, ptr %l7, !tbaa !29
  store ptr %t325, ptr %l163, !tbaa !29
  %t326 = load i64, ptr %l6, !tbaa !24
  %t327 = getelementptr %"compiler/source:Span", ptr %l17, i32 0, i32 0
  %t328 = load i32, ptr %t327, !tbaa !23
  %t330 = sext i32 %t328 to i64
  %t331 = getelementptr %"compiler/source:Span", ptr %l17, i32 0, i32 1
  %t332 = load i32, ptr %t331, !tbaa !23
  %t334 = sext i32 %t332 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t335
  %t336 = getelementptr { i64, [3 x i64] }, ptr %t335, i32 0, i32 0
  store i64 3, ptr %t336
  %t338 = insertvalue { i64, i64, i64 } undef, i64 %t326, 0
  %t340 = insertvalue { i64, i64, i64 } %t338, i64 %t330, 1
  %t342 = insertvalue { i64, i64, i64 } %t340, i64 %t334, 2
  %t343 = getelementptr { i64, [3 x i64] }, ptr %t335, i32 0, i32 1
  store { i64, i64, i64 } %t342, ptr %t343
  %t344 = load { i64, [3 x i64] }, ptr %t335
  store { i64, [3 x i64] } %t344, ptr %l169
  %t345 = load ptr, ptr %l0, !tbaa !29
  %t346 = load i32, ptr %l15, !tbaa !23
  %t349 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t345, i32 %t346)
  store { i64, ptr } %t349, ptr %l172
  br label %bb57
bb56:
  br label %bb60
bb57:
  %t350 = load { i64, ptr }, ptr %l172, !tbaa !27
  %t351 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTopSetHasValue(ptr %v0, ptr %s12, { i64, ptr } %t350)
  store %"compiler/msgs:Msg" %t351, ptr %l173
  br label %bb58
bb58:
  %t352 = load ptr, ptr %l163, !tbaa !29
  %t353 = load { i64, [3 x i64] }, ptr %l169
  %t354 = load %"compiler/msgs:Msg", ptr %l173
  %t355 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s12, ptr %t352, { i64, [3 x i64] } %t353, %"compiler/msgs:Msg" %t354)
  store i64 %t355, ptr %l174
  br label %bb59
bb59:
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s4)
  br label %bb90
bb60:
  %t356 = load i1, ptr %l4, !tbaa !21
  br i1 %t356, label %bb61, label %bb62
bb61:
  %t358 = load ptr, ptr %l5, !tbaa !29
  %t359 = load i32, ptr %l15, !tbaa !23
  %t362 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H8da9376267bda3f76393292be0e507b2(ptr %v2, ptr %t358, i32 %t359)
  store i1 %t362, ptr %l178
  br label %bb63
bb62:
  br label %bb71
bb63:
  %t363 = load i1, ptr %l178, !tbaa !21
  br i1 %t363, label %bb64, label %bb65
bb64:
  store %olang.scope zeroinitializer, ptr %s14
  %t364 = load ptr, ptr %l7, !tbaa !29
  store ptr %t364, ptr %l179, !tbaa !29
  %t365 = load { i64, [3 x i64] }, ptr %l14
  store { i64, [3 x i64] } %t365, ptr %l180
  %t366 = load ptr, ptr %l0, !tbaa !29
  %t367 = load i32, ptr %l15, !tbaa !23
  %t370 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t366, i32 %t367)
  store { i64, ptr } %t370, ptr %l183
  br label %bb66
bb65:
  br label %bb69
bb66:
  %t371 = load { i64, ptr }, ptr %l183, !tbaa !27
  %t372 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTopSetTwice(ptr %v0, ptr %s14, { i64, ptr } %t371)
  store %"compiler/msgs:Msg" %t372, ptr %l184
  br label %bb67
bb67:
  %t373 = load ptr, ptr %l179, !tbaa !29
  %t374 = load { i64, [3 x i64] }, ptr %l180
  %t375 = load %"compiler/msgs:Msg", ptr %l184
  %t376 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s14, ptr %t373, { i64, [3 x i64] } %t374, %"compiler/msgs:Msg" %t375)
  store i64 %t376, ptr %l185
  br label %bb68
bb68:
  call void @__olang_scope_close(ptr %s14)
  br label %bb69
bb69:
  %t377 = load ptr, ptr %l5, !tbaa !29
  %t378 = load i32, ptr %l15, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H96b7de74ba8f33ba996281c879dd113a(ptr %v2, ptr %t377, i32 %t378, i1 true)
  br label %bb70
bb70:
  br label %bb71
bb71:
  call void @__olang_scope_close(ptr %s4)
  br label %bb89
bb72:
  %t381 = load ptr, ptr %l11, !tbaa !29
  store ptr %t381, ptr %l188, !tbaa !29
  store i1 false, ptr %l189, !tbaa !21
  %t382 = load ptr, ptr %l188, !tbaa !29
  %t383 = icmp ne ptr %t382, null
  br i1 %t383, label %bb73, label %bb74
bb73:
  %t385 = load ptr, ptr %l188, !tbaa !29
  %t386 = load i64, ptr %t385, !range !{i64 0, i64 11}
  %t388 = icmp eq i64 %t386, 7
  store i1 %t388, ptr %l189, !tbaa !21
  br label %bb74
bb74:
  %t389 = load i1, ptr %l189, !tbaa !21
  br i1 %t389, label %bb75, label %bb76
bb75:
  %t390 = load ptr, ptr %l11, !tbaa !29
  %t392 = getelementptr { i64, [6 x i64] }, ptr %t390, i32 0, i32 1
  %t393 = getelementptr { %"compiler/source:Span", ptr }, ptr %t392, i32 0, i32 1
  %t394 = load ptr, ptr %t393
  store ptr %t394, ptr %l25, !tbaa !29
  br label %bb77
bb76:
  br label %bb84
bb77:
  %t396 = load ptr, ptr %l0, !tbaa !29
  store ptr %t396, ptr %l194, !tbaa !29
  %t397 = load i64, ptr %l1, !tbaa !24
  store i64 %t397, ptr %l195, !tbaa !24
  %t398 = load ptr, ptr %l25, !tbaa !29
  store ptr %t398, ptr %l196, !tbaa !29
  %t399 = load ptr, ptr %l25, !tbaa !29
  store ptr %t399, ptr %l197, !tbaa !29
  %t400 = load i1, ptr %l3, !tbaa !21
  store i1 %t400, ptr %l198, !tbaa !21
  %t401 = load i1, ptr %l4, !tbaa !21
  store i1 %t401, ptr %l199, !tbaa !21
  %t402 = load ptr, ptr %l0, !tbaa !29
  %t404 = getelementptr %"compiler/check:Checker", ptr %t402, i32 0, i32 1
  %t405 = load ptr, ptr %t404, !tbaa !29
  %t407 = getelementptr %"compiler/generic:Program", ptr %t405, i32 0, i32 0
  %t408 = load ptr, ptr %t407, !tbaa !29
  store ptr %t408, ptr %l202, !tbaa !29
  %t409 = load i64, ptr %l1, !tbaa !24
  store i64 %t409, ptr %l203, !tbaa !24
  %t410 = load ptr, ptr %l25, !tbaa !29
  %t412 = getelementptr %"compiler/ast:TopIf", ptr %t410, i32 0, i32 0
  %t413 = load ptr, ptr %t412, !tbaa !29
  %t415 = icmp eq ptr %t413, null
  br i1 %t415, label %bb78, label %bb79
bb78:
  call void @__olang_check_failed(ptr @olang_loc_c6f64016a09fc530_b8b2abed7e41fd2c)
  unreachable
bb79:
  br label %bb80
bb80:
  %t417 = load ptr, ptr %l25, !tbaa !29
  %t419 = getelementptr %"compiler/ast:TopIf", ptr %t417, i32 0, i32 0
  %t420 = load ptr, ptr %t419, !tbaa !29
  %t422 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t420)
  store %"compiler/source:Span" %t422, ptr %l209
  br label %bb81
bb81:
  %t423 = getelementptr %"compiler/source:Span", ptr %l209, i32 0, i32 0
  %t424 = load i32, ptr %t423, !tbaa !23
  %t425 = load ptr, ptr %l202, !tbaa !29
  %t426 = load i64, ptr %l203, !tbaa !24
  %t428 = call i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2eChosen(ptr %v0, ptr %t425, i64 %t426, i32 %t424)
  store i64 %t428, ptr %l211
  br label %bb82
bb82:
  %t429 = load ptr, ptr %l5, !tbaa !29
  %t430 = load ptr, ptr %l194, !tbaa !29
  %t431 = load i64, ptr %l195, !tbaa !24
  %t432 = load ptr, ptr %l196, !tbaa !29
  %t433 = load ptr, ptr %l197, !tbaa !29
  %t434 = load i1, ptr %l198, !tbaa !21
  %t435 = load i1, ptr %l199, !tbaa !21
  %t436 = load i64, ptr %l211, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etopSetIf(ptr %v0, ptr %v1, ptr %v1, ptr %v2, ptr %t430, i64 %t431, ptr %t432, ptr %t433, i1 %t434, i1 %t435, i64 %t436, i64 0, ptr %t429)
  br label %bb83
bb83:
  br label %bb89
bb84:
  br i1 true, label %bb85, label %bb86
bb85:
  br label %bb87
bb86:
  br label %bb88
bb87:
  br label %bb89
bb88:
  call void @__olang_check_failed(ptr @olang_loc_37fb0db160a44e56_e10956c528b68142)
  unreachable
bb89:
  br label %bb90
bb90:
  %t438 = load i64, ptr %l9, !tbaa !24
  %t440 = add i64 %t438, 1
  store i64 %t440, ptr %l9, !tbaa !24
  br label %bb5
bb91:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etraitSets(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l11 = alloca i1
  %l17 = alloca ptr
  %l18 = alloca i1
  %l26 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l40 = alloca i1
  %l46 = alloca ptr
  %l48 = alloca i32
  %l50 = alloca i32
  %l54 = alloca { i64, ptr }
  %l58 = alloca %"compiler/source:Span"
  %l59 = alloca %"compiler/msgs:Msg"
  %l60 = alloca i64
  %s5 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l11, !tbaa !21
  br label %bb3
bb2:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t7 = getelementptr %"compiler/ast:TypeDecl", ptr %t5, i32 0, i32 3
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = icmp eq ptr %t8, null
  store i1 %t10, ptr %l11, !tbaa !21
  br label %bb3
bb3:
  %t12 = load i1, ptr %l11, !tbaa !21
  br i1 %t12, label %bb4, label %bb5
bb4:
  br label %ret
bb5:
  br label %bb6
bb6:
  %t13 = load ptr, ptr %l2, !tbaa !29
  %t15 = getelementptr %"compiler/ast:TypeDecl", ptr %t13, i32 0, i32 3
  %t16 = load ptr, ptr %t15, !tbaa !29
  store ptr %t16, ptr %l3, !tbaa !29
  %t18 = load ptr, ptr %l3, !tbaa !29
  store ptr %t18, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t19 = load ptr, ptr %l17, !tbaa !29
  %t20 = icmp ne ptr %t19, null
  br i1 %t20, label %bb7, label %bb8
bb7:
  %t22 = load ptr, ptr %l17, !tbaa !29
  %t23 = load i64, ptr %t22, !range !{i64 0, i64 5}
  %t25 = icmp eq i64 %t23, 2
  store i1 %t25, ptr %l18, !tbaa !21
  br label %bb8
bb8:
  %t26 = load i1, ptr %l18, !tbaa !21
  br i1 %t26, label %bb9, label %bb10
bb9:
  %t27 = load ptr, ptr %l3, !tbaa !29
  %t29 = getelementptr { i64, [6 x i64] }, ptr %t27, i32 0, i32 1
  %t30 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t29, i32 0, i32 0
  %t31 = load { i64, ptr }, ptr %t30
  store { i64, ptr } %t31, ptr %l4, !tbaa !27
  br label %bb11
bb10:
  br label %bb30
bb11:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t39 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %v0, ptr %t33, i64 -1, i64 %a1, i32 %t35, i32 0)
  store ptr %t39, ptr %l26
  br label %bb12
bb12:
  %t40 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t40, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t42 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t42, 0
  store i64 %t44, ptr %l7, !tbaa !24
  br label %bb13
bb13:
  %t46 = load i64, ptr %l6, !tbaa !24
  %t47 = load i64, ptr %l7, !tbaa !24
  %t50 = icmp slt i64 %t46, %t47
  %t52 = xor i1 %t50, true
  br i1 %t52, label %bb14, label %bb15
bb14:
  br label %bb28
bb15:
  br label %bb16
bb16:
  %t54 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t54, ptr %l34, !tbaa !27
  %t55 = load i64, ptr %l6, !tbaa !24
  %t57 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !27
  %t59 = getelementptr ptr, ptr %t58, i64 %t55
  %t60 = load ptr, ptr %t59, !tbaa !39
  store ptr %t60, ptr %l8, !tbaa !29
  %t62 = load ptr, ptr %l8, !tbaa !29
  %t64 = getelementptr %"compiler/ast:Func", ptr %t62, i32 0, i32 3
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t67 = getelementptr %"compiler/ast:Sig", ptr %t65, i32 0, i32 2
  %t68 = load i1, ptr %t67, !tbaa !21
  br i1 %t68, label %bb17, label %bb18
bb17:
  %t70 = load ptr, ptr %l8, !tbaa !29
  %t72 = getelementptr %"compiler/ast:Func", ptr %t70, i32 0, i32 3
  %t73 = load ptr, ptr %t72, !tbaa !29
  %t75 = getelementptr %"compiler/ast:Sig", ptr %t73, i32 0, i32 3
  %t76 = load { i64, ptr }, ptr %t75, !tbaa !27
  %t78 = extractvalue { i64, ptr } %t76, 0
  %t80 = icmp eq i64 %t78, 0
  store i1 %t80, ptr %l40, !tbaa !21
  br label %bb19
bb18:
  store i1 false, ptr %l40, !tbaa !21
  br label %bb19
bb19:
  %t82 = load i1, ptr %l40, !tbaa !21
  br i1 %t82, label %bb20, label %bb21
bb20:
  store %olang.scope zeroinitializer, ptr %s5
  %t83 = load ptr, ptr %l0, !tbaa !29
  store ptr %t83, ptr %l46, !tbaa !29
  %t84 = load ptr, ptr %l8, !tbaa !29
  %t86 = getelementptr %"compiler/ast:Func", ptr %t84, i32 0, i32 0
  %t87 = getelementptr %"compiler/source:Span", ptr %t86, i32 0, i32 0
  %t88 = load i32, ptr %t87, !tbaa !23
  store i32 %t88, ptr %l48, !tbaa !23
  %t89 = load ptr, ptr %l8, !tbaa !29
  %t91 = getelementptr %"compiler/ast:Func", ptr %t89, i32 0, i32 0
  %t92 = getelementptr %"compiler/source:Span", ptr %t91, i32 0, i32 0
  %t93 = load i32, ptr %t92, !tbaa !23
  store i32 %t93, ptr %l50, !tbaa !23
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t95 = load ptr, ptr %l8, !tbaa !29
  %t97 = getelementptr %"compiler/ast:Func", ptr %t95, i32 0, i32 2
  %t98 = load i32, ptr %t97, !tbaa !23
  %t101 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %s5, ptr %t94, i32 %t98)
  store { i64, ptr } %t101, ptr %l54
  br label %bb22
bb21:
  br label %bb26
bb22:
  %t102 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t103 = extractvalue { i64, ptr } %t102, 0
  %t105 = trunc i64 %t103 to i32
  %t106 = load i32, ptr %l50, !tbaa !23
  %t108 = add i32 %t106, %t105
  %t109 = load i32, ptr %l48, !tbaa !23
  %t111 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s5, i32 %t109, i32 %t108)
  store %"compiler/source:Span" %t111, ptr %l58
  br label %bb23
bb23:
  %t112 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTraitErrsUnwritten(ptr %s5)
  store %"compiler/msgs:Msg" %t112, ptr %l59
  br label %bb24
bb24:
  %t113 = load ptr, ptr %l46, !tbaa !29
  %t114 = load %"compiler/source:Span", ptr %l58
  %t115 = load %"compiler/msgs:Msg", ptr %l59
  %t116 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s5, ptr %t113, %"compiler/source:Span" %t114, %"compiler/msgs:Msg" %t115)
  store i64 %t116, ptr %l60
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s5)
  br label %bb26
bb26:
  br label %bb27
bb27:
  %t117 = load i64, ptr %l6, !tbaa !24
  %t119 = add i64 %t117, 1
  store i64 %t119, ptr %l6, !tbaa !24
  br label %bb13
bb28:
  %t121 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t121)
  br label %bb29
bb29:
  br label %bb35
bb30:
  br i1 true, label %bb31, label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb35
bb34:
  call void @__olang_check_failed(ptr @olang_loc_cc3b7a6e318210b6_464c855cb4a991aa)
  unreachable
bb35:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eviaMemoryJump(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l6 = alloca i32
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l13 = alloca ptr
  %l18 = alloca i32
  %l19 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l32 = alloca i1
  %l39 = alloca i32
  %l43 = alloca i1
  %l50 = alloca i1
  %l55 = alloca i1
  %l61 = alloca { i64, ptr }
  %l69 = alloca { i64, ptr }
  %s6 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  store ptr %t6, ptr %l13, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  %t13 = load i32, ptr %l1, !tbaa !23
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t16, ptr %l18
  br label %bb1
bb1:
  %t17 = load ptr, ptr %l13, !tbaa !29
  %t18 = load i32, ptr %l18, !tbaa !23
  %t19 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t17, i32 %t18)
  store { i64, ptr } %t19, ptr %l19
  br label %bb2
bb2:
  %t20 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t20, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t21 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t21, 0
  store i64 %t23, ptr %l4, !tbaa !24
  br label %bb3
bb3:
  %t25 = load i64, ptr %l3, !tbaa !24
  %t26 = load i64, ptr %l4, !tbaa !24
  %t29 = icmp slt i64 %t25, %t26
  %t31 = xor i1 %t29, true
  br i1 %t31, label %bb4, label %bb5
bb4:
  br label %bb9
bb5:
  br label %bb6
bb6:
  %t33 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t33, ptr %l26, !tbaa !27
  %t34 = load i64, ptr %l3, !tbaa !24
  %t36 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr i32, ptr %t37, i64 %t34
  %t39 = load i32, ptr %t38, !tbaa !33
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/check:Checker", ptr %t41, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !29
  %t48 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLayout(ptr %v0, ptr %t44, i32 %t39)
  store i1 %t48, ptr %l32
  br label %bb7
bb7:
  br label %bb8
bb8:
  %t49 = load i64, ptr %l3, !tbaa !24
  %t51 = add i64 %t49, 1
  store i64 %t51, ptr %l3, !tbaa !24
  br label %bb3
bb9:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/check:Checker", ptr %t53, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t58 = getelementptr %"compiler/generic:Program", ptr %t56, i32 0, i32 2
  %t59 = load i32, ptr %l1, !tbaa !23
  %t62 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t58, i32 %t59)
  store i32 %t62, ptr %l39
  br label %bb10
bb10:
  %t63 = load i32, ptr %l39, !tbaa !23
  store i32 %t63, ptr %l6, !tbaa !23
  %t64 = load i32, ptr %l6, !tbaa !23
  %t65 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t68 = icmp ne i32 %t64, %t65
  br i1 %t68, label %bb11, label %bb12
bb11:
  %t70 = load i32, ptr %l6, !tbaa !23
  %t71 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t74 = icmp ne i32 %t70, %t71
  store i1 %t74, ptr %l43, !tbaa !21
  br label %bb13
bb12:
  store i1 false, ptr %l43, !tbaa !21
  br label %bb13
bb13:
  %t76 = load i1, ptr %l43, !tbaa !21
  br i1 %t76, label %bb14, label %bb15
bb14:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/check:Checker", ptr %t77, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t81 = load i32, ptr %l6, !tbaa !23
  %t84 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLayout(ptr %v0, ptr %t80, i32 %t81)
  store i1 %t84, ptr %l50
  br label %bb16
bb15:
  br label %bb21
bb16:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/check:Checker", ptr %t85, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !29
  %t90 = getelementptr %"compiler/generic:Program", ptr %t88, i32 0, i32 2
  %t91 = load i32, ptr %l6, !tbaa !23
  %t94 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eViaMemory(ptr %v0, ptr %t90, i32 %t91)
  store i1 %t94, ptr %l55
  br label %bb17
bb17:
  %t95 = load i1, ptr %l55, !tbaa !21
  br i1 %t95, label %bb18, label %bb19
bb18:
  store i1 true, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  br label %bb21
bb21:
  store %olang.scope zeroinitializer, ptr %s6
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/check:Checker", ptr %t97, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !29
  %t102 = getelementptr %"compiler/generic:Program", ptr %t100, i32 0, i32 2
  %t103 = load i32, ptr %l1, !tbaa !23
  %t106 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePassing(ptr %v0, ptr %s6, ptr %t102, i32 %t103)
  store { i64, ptr } %t106, ptr %l61
  br label %bb22
bb22:
  %t107 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t108 = extractvalue { i64, ptr } %t107, 0
  %t109 = extractvalue { i64, ptr } %t107, 1
  %t110 = mul i64 %t108, 1
  %t111 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t110)
  call void @llvm.memcpy.p0.p0.i64(ptr %t111, ptr %t109, i64 %t110, i1 false)
  %t112 = insertvalue { i64, ptr } undef, i64 %t108, 0
  %t113 = insertvalue { i64, ptr } %t112, ptr %t111, 1
  store { i64, ptr } %t113, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t115 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t117 = extractvalue { i64, ptr } %t115, 0
  store i64 %t117, ptr %l9, !tbaa !24
  br label %bb23
bb23:
  %t119 = load i64, ptr %l8, !tbaa !24
  %t120 = load i64, ptr %l9, !tbaa !24
  %t123 = icmp slt i64 %t119, %t120
  %t125 = xor i1 %t123, true
  br i1 %t125, label %bb24, label %bb25
bb24:
  br label %bb31
bb25:
  br label %bb26
bb26:
  %t127 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t127, ptr %l69, !tbaa !27
  %t128 = load i64, ptr %l8, !tbaa !24
  %t130 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !27
  %t132 = getelementptr i8, ptr %t131, i64 %t128
  %t133 = load i8, ptr %t132, !tbaa !32
  %t137 = icmp eq i8 %t133, 109
  br i1 %t137, label %bb27, label %bb28
bb27:
  call void @__olang_scope_close(ptr %s6)
  store i1 true, ptr %rv
  br label %ret
bb28:
  br label %bb29
bb29:
  br label %bb30
bb30:
  %t140 = load i64, ptr %l8, !tbaa !24
  %t142 = add i64 %t140, 1
  store i64 %t142, ptr %l8, !tbaa !24
  br label %bb23
bb31:
  call void @__olang_scope_close(ptr %s6)
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eviewBody(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca ptr
  %l7 = alloca i1
  %l10 = alloca i64
  %l12 = alloca i1
  %l15 = alloca i64
  %l18 = alloca ptr
  %l20 = alloca ptr
  %l22 = alloca i64
  %l24 = alloca ptr
  %l27 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l3, !tbaa !29
  store ptr %t4, ptr %l1, !tbaa !29
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = getelementptr %"compiler/typed:Body", ptr %t5, i32 0, i32 11
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = icmp eq ptr %t8, null
  br i1 %t10, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb9
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load ptr, ptr %l1, !tbaa !29
  %t16 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eviewable(ptr %v0, ptr %v0, ptr %t12, ptr %t13)
  store i64 %t16, ptr %l10
  br label %bb4
bb4:
  %t17 = load i64, ptr %l10, !tbaa !24
  %t18 = icmp slt i64 %t17, 0
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t24 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorViewKey(ptr %v0, ptr %v0, ptr %t20, ptr %t21)
  store i64 %t24, ptr %l15
  br label %bb7
bb6:
  store i1 false, ptr %l12, !tbaa !21
  br label %bb8
bb7:
  %t25 = load i64, ptr %l15, !tbaa !24
  %t26 = icmp slt i64 %t25, 0
  store i1 %t26, ptr %l12, !tbaa !21
  br label %bb8
bb8:
  %t28 = load i1, ptr %l12, !tbaa !21
  store i1 %t28, ptr %l7, !tbaa !21
  br label %bb9
bb9:
  %t29 = load i1, ptr %l7, !tbaa !21
  br i1 %t29, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb11:
  br label %bb12
bb12:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/check:Checker", ptr %t30, i32 0, i32 65
  store ptr %t32, ptr %l18, !tbaa !29
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t33)
  store ptr %t35, ptr %l20
  br label %bb13
bb13:
  %t36 = load ptr, ptr %l20, !tbaa !29
  %t38 = getelementptr %"compiler/check:frame", ptr %t36, i32 0, i32 0
  %t39 = load i64, ptr %t38, !tbaa !24
  store i64 %t39, ptr %l22, !tbaa !24
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t40)
  store ptr %t42, ptr %l24
  br label %bb14
bb14:
  %t43 = load ptr, ptr %l24, !tbaa !29
  %t45 = getelementptr %"compiler/check:frame", ptr %t43, i32 0, i32 2
  %t46 = load i64, ptr %t45, !tbaa !24
  %t47 = load i64, ptr %l22, !tbaa !24
  %t49 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %t47, i64 %t46)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t49, ptr %l27
  br label %bb15
bb15:
  %t50 = load ptr, ptr %l18, !tbaa !29
  %t51 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_3e_H2474e1fc3c93452d7765e4ed18f29a03(ptr %v0, ptr %t50, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t51)
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkRuns(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, i64 %a4, ptr %a5, i32 %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca { i64, i64, i64 }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca i32
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca { i64, i64, i64 }
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i32
  %l26 = alloca ptr
  %l28 = alloca ptr
  %l29 = alloca i64
  %l30 = alloca { i64, i64, i64 }
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l39 = alloca i64
  %l40 = alloca ptr
  %l41 = alloca %"compiler/source:Span"
  %l43 = alloca i32
  %l44 = alloca i64
  %l45 = alloca ptr
  %l46 = alloca %"compiler/source:Span"
  %l49 = alloca i32
  %l50 = alloca ptr
  %l51 = alloca %"compiler/source:Span"
  %l53 = alloca i32
  %l54 = alloca ptr
  %l60 = alloca ptr
  %l61 = alloca %"compiler/source:Span"
  %l63 = alloca i32
  %l64 = alloca i64
  %l65 = alloca ptr
  %l66 = alloca %"compiler/source:Span"
  %l69 = alloca i32
  %l70 = alloca ptr
  %l71 = alloca %"compiler/source:Span"
  %l73 = alloca i32
  %l74 = alloca ptr
  %l79 = alloca i64
  %l83 = alloca { i64, i64, i64 }
  %l88 = alloca ptr
  %l93 = alloca ptr
  %l97 = alloca ptr
  %l98 = alloca %"compiler/source:Span"
  %l99 = alloca i64
  %l103 = alloca ptr
  %l104 = alloca ptr
  %l108 = alloca ptr
  %l109 = alloca { i64, ptr }
  %l110 = alloca ptr
  %l113 = alloca i32
  %l117 = alloca i64
  %l118 = alloca ptr
  %l119 = alloca %"compiler/source:Span"
  %l122 = alloca i32
  %l127 = alloca ptr
  %l130 = alloca ptr
  %l131 = alloca %"compiler/source:Span"
  %l133 = alloca i32
  %l134 = alloca i64
  %l135 = alloca ptr
  %l136 = alloca %"compiler/source:Span"
  %l139 = alloca i32
  %l140 = alloca ptr
  %l141 = alloca %"compiler/source:Span"
  %l143 = alloca i32
  %l144 = alloca i32
  %l148 = alloca ptr
  %l149 = alloca ptr
  %l152 = alloca ptr
  %l153 = alloca %"compiler/source:Span"
  %l155 = alloca i32
  %l156 = alloca i64
  %l157 = alloca ptr
  %l158 = alloca %"compiler/source:Span"
  %l161 = alloca i32
  %l162 = alloca ptr
  %l163 = alloca %"compiler/source:Span"
  %l165 = alloca i32
  %l166 = alloca ptr
  %l171 = alloca i64
  %l175 = alloca { i64, i64, i64 }
  %l179 = alloca i64
  %l181 = alloca ptr
  %l184 = alloca i64
  %l185 = alloca i32
  %l187 = alloca ptr
  %l191 = alloca ptr
  %l192 = alloca ptr
  %l193 = alloca %"compiler/source:Span"
  %l194 = alloca ptr
  %l195 = alloca %"compiler/source:Span"
  %l196 = alloca i32
  %l197 = alloca i32
  %l201 = alloca ptr
  %l205 = alloca ptr
  %l207 = alloca ptr
  %l209 = alloca ptr
  %l212 = alloca i32
  %l213 = alloca %"compiler/source:Span"
  %l216 = alloca i32
  %l220 = alloca ptr
  %l223 = alloca ptr
  %l224 = alloca %"compiler/source:Span"
  %l225 = alloca %"compiler/source:Span"
  %l230 = alloca i32
  %l231 = alloca ptr
  %l235 = alloca ptr
  %l237 = alloca %"compiler/typed:Elem"
  %l241 = alloca ptr
  %l251 = alloca i64
  %l253 = alloca ptr
  %l256 = alloca i64
  %l257 = alloca i32
  %l258 = alloca i64
  %l260 = alloca ptr
  %l263 = alloca i64
  %l264 = alloca i32
  %l270 = alloca ptr
  %l273 = alloca i64
  %l277 = alloca { i64, i64, i64 }
  %l281 = alloca ptr
  %l282 = alloca %"compiler/source:Span"
  %l283 = alloca %"compiler/source:Span"
  %l285 = alloca i32
  %l290 = alloca ptr
  %l291 = alloca ptr
  %l292 = alloca %"compiler/source:Span"
  %l294 = alloca i32
  %l295 = alloca i32
  %l299 = alloca ptr
  %l300 = alloca ptr
  %l301 = alloca %"compiler/source:Span"
  %l303 = alloca i32
  %l304 = alloca ptr
  %l306 = alloca ptr
  %l311 = alloca ptr
  %l312 = alloca %"compiler/source:Span"
  %l313 = alloca %"compiler/source:Span"
  %l315 = alloca i32
  %l320 = alloca ptr
  %l321 = alloca ptr
  %l322 = alloca %"compiler/source:Span"
  %l324 = alloca i32
  %l325 = alloca i32
  %l329 = alloca ptr
  %l330 = alloca ptr
  %l331 = alloca %"compiler/source:Span"
  %l333 = alloca i32
  %l334 = alloca ptr
  %l336 = alloca ptr
  %l344 = alloca ptr
  %l352 = alloca ptr
  %l353 = alloca %"compiler/source:Span"
  %l354 = alloca %"compiler/source:Span"
  %l356 = alloca i32
  %l361 = alloca ptr
  %l362 = alloca ptr
  %l363 = alloca %"compiler/source:Span"
  %l365 = alloca i32
  %l366 = alloca i32
  %l370 = alloca ptr
  %l374 = alloca ptr
  %l376 = alloca ptr
  %l384 = alloca ptr
  %t34 = alloca { i64, [3 x i64] }, align 8
  %t80 = alloca { i64, [3 x i64] }, align 8
  %t190 = alloca { i64, [3 x i64] }, align 8
  %t238 = alloca { i64, [3 x i64] }, align 8
  %t277 = alloca { i64, [3 x i64] }, align 8
  %t390 = alloca { i64, [4 x i64] }, align 8
  %t430 = alloca { i64, [4 x i64] }, align 8
  %t535 = alloca { i64, [4 x i64] }, align 8
  %t576 = alloca { i64, [3 x i64] }, align 8
  %t604 = alloca { i64, [4 x i64] }, align 8
  %t645 = alloca { i64, [3 x i64] }, align 8
  %t676 = alloca { i64, [3 x i64] }, align 8
  %t700 = alloca { i64, [4 x i64] }, align 8
  %t739 = alloca { i64, [3 x i64] }, align 8
  %t768 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load %"compiler/source:Span", ptr %l1
  %t7 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eborrowedSource(ptr %v0, ptr %v2, ptr %t1, %"compiler/source:Span" %t2, ptr %a3)
  store i64 %t7, ptr %l39
  br label %bb1
bb1:
  %t8 = load i64, ptr %l39, !tbaa !24
  store i64 %t8, ptr %l7, !tbaa !24
  %t9 = load ptr, ptr %l0, !tbaa !29
  store ptr %t9, ptr %l40, !tbaa !29
  %t10 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t10, ptr %l41
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t11)
  store i32 %t13, ptr %l43
  br label %bb2
bb2:
  %t14 = load ptr, ptr %l40, !tbaa !29
  %t15 = load %"compiler/source:Span", ptr %l41
  %t16 = load i32, ptr %l43, !tbaa !23
  %t17 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t14, %"compiler/source:Span" %t15, i32 %t16)
  store i64 %t17, ptr %l44
  br label %bb3
bb3:
  %t18 = load i64, ptr %l44, !tbaa !24
  store i64 %t18, ptr %l8, !tbaa !24
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l45, !tbaa !29
  %t20 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t20, ptr %l46
  %t21 = load i64, ptr %l8, !tbaa !24
  %t23 = trunc i64 %t21 to i32
  store i32 %t23, ptr %l49, !tbaa !23
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l50, !tbaa !29
  %t26 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t26, ptr %l51
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t27)
  store i32 %t29, ptr %l53
  br label %bb4
bb4:
  %t30 = load ptr, ptr %l50, !tbaa !29
  %t31 = load %"compiler/source:Span", ptr %l51
  %t32 = load i32, ptr %l53, !tbaa !23
  %t33 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v0, ptr %t30, %"compiler/source:Span" %t31, i32 %t32, i64 0)
  store ptr %t33, ptr %l54
  br label %bb5
bb5:
  store { i64, [3 x i64] } zeroinitializer, ptr %t34
  %t35 = getelementptr { i64, [3 x i64] }, ptr %t34, i32 0, i32 0
  store i64 0, ptr %t35
  %t36 = load %"compiler/source:Span", ptr %l46
  %t37 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t36, 0
  %t38 = load i32, ptr %l49, !tbaa !23
  %t39 = insertvalue { %"compiler/source:Span", i32, ptr } %t37, i32 %t38, 1
  %t40 = load ptr, ptr %l54, !tbaa !29
  %t41 = insertvalue { %"compiler/source:Span", i32, ptr } %t39, ptr %t40, 2
  %t42 = getelementptr { i64, [3 x i64] }, ptr %t34, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t41, ptr %t42
  %t43 = load { i64, [3 x i64] }, ptr %t34
  %t45 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t43, ptr %t45
  %t46 = load ptr, ptr %l45, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t46, ptr %t45)
  br label %bb6
bb6:
  store i64 -1, ptr %l9, !tbaa !24
  %t48 = load ptr, ptr %l2, !tbaa !29
  %t50 = getelementptr %"compiler/ast:ForIn", ptr %t48, i32 0, i32 0
  %t51 = load i32, ptr %t50, !tbaa !23
  %t53 = icmp ne i32 %t51, 0
  br i1 %t53, label %bb7, label %bb8
bb7:
  %t55 = load ptr, ptr %l0, !tbaa !29
  store ptr %t55, ptr %l60, !tbaa !29
  %t56 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t56, ptr %l61
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t57)
  store i32 %t59, ptr %l63
  br label %bb9
bb8:
  br label %bb14
bb9:
  %t60 = load ptr, ptr %l60, !tbaa !29
  %t61 = load %"compiler/source:Span", ptr %l61
  %t62 = load i32, ptr %l63, !tbaa !23
  %t63 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t60, %"compiler/source:Span" %t61, i32 %t62)
  store i64 %t63, ptr %l64
  br label %bb10
bb10:
  %t64 = load i64, ptr %l64, !tbaa !24
  store i64 %t64, ptr %l9, !tbaa !24
  %t65 = load ptr, ptr %l0, !tbaa !29
  store ptr %t65, ptr %l65, !tbaa !29
  %t66 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t66, ptr %l66
  %t67 = load i64, ptr %l9, !tbaa !24
  %t69 = trunc i64 %t67 to i32
  store i32 %t69, ptr %l69, !tbaa !23
  %t71 = load ptr, ptr %l0, !tbaa !29
  store ptr %t71, ptr %l70, !tbaa !29
  %t72 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t72, ptr %l71
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t73)
  store i32 %t75, ptr %l73
  br label %bb11
bb11:
  %t76 = load ptr, ptr %l70, !tbaa !29
  %t77 = load %"compiler/source:Span", ptr %l71
  %t78 = load i32, ptr %l73, !tbaa !23
  %t79 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v0, ptr %t76, %"compiler/source:Span" %t77, i32 %t78, i64 0)
  store ptr %t79, ptr %l74
  br label %bb12
bb12:
  store { i64, [3 x i64] } zeroinitializer, ptr %t80
  %t81 = getelementptr { i64, [3 x i64] }, ptr %t80, i32 0, i32 0
  store i64 0, ptr %t81
  %t82 = load %"compiler/source:Span", ptr %l66
  %t83 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t82, 0
  %t84 = load i32, ptr %l69, !tbaa !23
  %t85 = insertvalue { %"compiler/source:Span", i32, ptr } %t83, i32 %t84, 1
  %t86 = load ptr, ptr %l74, !tbaa !29
  %t87 = insertvalue { %"compiler/source:Span", i32, ptr } %t85, ptr %t86, 2
  %t88 = getelementptr { i64, [3 x i64] }, ptr %t80, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t87, ptr %t88
  %t89 = load { i64, [3 x i64] }, ptr %t80
  %t91 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t89, ptr %t91
  %t92 = load ptr, ptr %l65, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t92, ptr %t91)
  br label %bb13
bb13:
  br label %bb14
bb14:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/check:Checker", ptr %t94, i32 0, i32 37
  %t98 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t96)
  store i64 %t98, ptr %l79
  br label %bb15
bb15:
  %t99 = load i64, ptr %l79, !tbaa !24
  store i64 %t99, ptr %l10, !tbaa !24
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t101 = load %"compiler/source:Span", ptr %l1
  %t105 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t100, i32 2, %"compiler/source:Span" %t101)
  store { i64, i64, i64 } %t105, ptr %l83
  br label %bb16
bb16:
  %t106 = load { i64, i64, i64 }, ptr %l83
  store { i64, i64, i64 } %t106, ptr %l11
  %t107 = getelementptr { i64, i64, i64 }, ptr %l11, i32 0, i32 0
  %t108 = load i64, ptr %t107, !tbaa !24
  store i64 %t108, ptr %l12, !tbaa !24
  %t110 = getelementptr { i64, i64, i64 }, ptr %l11, i32 0, i32 1
  %t111 = load i64, ptr %t110, !tbaa !24
  store i64 %t111, ptr %l13, !tbaa !24
  %t113 = getelementptr { i64, i64, i64 }, ptr %l11, i32 0, i32 2
  %t114 = load i64, ptr %t113, !tbaa !24
  store i64 %t114, ptr %l14, !tbaa !24
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t118 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t116)
  store ptr %t118, ptr %l88
  br label %bb17
bb17:
  %t119 = load ptr, ptr %l88, !tbaa !29
  %t121 = getelementptr %"compiler/check:frame", ptr %t119, i32 0, i32 10
  %t122 = load i64, ptr %l12, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t121, i64 %t122)
  br label %bb18
bb18:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t127 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t125)
  store ptr %t127, ptr %l93
  br label %bb19
bb19:
  %t128 = load ptr, ptr %l93, !tbaa !29
  %t130 = getelementptr %"compiler/check:frame", ptr %t128, i32 0, i32 11
  %t131 = load i64, ptr %l12, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t130, i64 %t131)
  br label %bb20
bb20:
  %t134 = load ptr, ptr %l0, !tbaa !29
  store ptr %t134, ptr %l97, !tbaa !29
  %t135 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t135, ptr %l98
  store i64 %a4, ptr %l99, !tbaa !24
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t138 = load %"compiler/source:Span", ptr %l1
  %t139 = load i64, ptr %l7, !tbaa !24
  %t143 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t137, %"compiler/source:Span" %t138, i64 %t139)
  store ptr %t143, ptr %l103
  br label %bb21
bb21:
  %t144 = load ptr, ptr %l0, !tbaa !29
  store ptr %t144, ptr %l104, !tbaa !29
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t146 = load %"compiler/source:Span", ptr %l1
  %t147 = load i64, ptr %l8, !tbaa !24
  %t151 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t145, %"compiler/source:Span" %t146, i64 %t147)
  store ptr %t151, ptr %l108
  br label %bb22
bb22:
  %t152 = load ptr, ptr %l104, !tbaa !29
  %t153 = load ptr, ptr %l108, !tbaa !29
  %t154 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eone(ptr %v0, ptr %v0, ptr %v0, ptr %t152, ptr %t153)
  store { i64, ptr } %t154, ptr %l109
  br label %bb23
bb23:
  %t155 = load ptr, ptr %l97, !tbaa !29
  %t156 = load %"compiler/source:Span", ptr %l98
  %t157 = load i64, ptr %l99, !tbaa !24
  %t158 = load ptr, ptr %l103, !tbaa !29
  %t159 = load { i64, ptr }, ptr %l109, !tbaa !27
  %t160 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eloopCall(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t155, %"compiler/source:Span" %t156, i64 %t157, ptr %t158, { i64, ptr } %t159)
  store ptr %t160, ptr %l110
  br label %bb24
bb24:
  %t161 = load ptr, ptr %l110, !tbaa !29
  store ptr %t161, ptr %l15, !tbaa !29
  %t162 = load ptr, ptr %l15, !tbaa !29
  %t165 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t162)
  store i32 %t165, ptr %l113
  br label %bb25
bb25:
  %t166 = load i32, ptr %l113, !tbaa !23
  store i32 %t166, ptr %l16, !tbaa !23
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t168 = load %"compiler/source:Span", ptr %l1
  %t169 = load i32, ptr %l16, !tbaa !23
  %t173 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t167, %"compiler/source:Span" %t168, i32 %t169)
  store i64 %t173, ptr %l117
  br label %bb26
bb26:
  %t174 = load i64, ptr %l117, !tbaa !24
  store i64 %t174, ptr %l17, !tbaa !24
  %t175 = load ptr, ptr %l0, !tbaa !29
  store ptr %t175, ptr %l118, !tbaa !29
  %t176 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t176, ptr %l119
  %t177 = load i64, ptr %l17, !tbaa !24
  %t179 = trunc i64 %t177 to i32
  store i32 %t179, ptr %l122, !tbaa !23
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t182 = load %"compiler/source:Span", ptr %l1
  %t183 = load ptr, ptr %l15, !tbaa !29
  %t184 = load i64, ptr %l12, !tbaa !24
  %t189 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexhaustedOrBreak(ptr %v0, ptr %v0, ptr %v0, ptr %t181, %"compiler/source:Span" %t182, ptr %t183, i64 %t184)
  store ptr %t189, ptr %l127
  br label %bb27
bb27:
  store { i64, [3 x i64] } zeroinitializer, ptr %t190
  %t191 = getelementptr { i64, [3 x i64] }, ptr %t190, i32 0, i32 0
  store i64 0, ptr %t191
  %t192 = load %"compiler/source:Span", ptr %l119
  %t193 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t192, 0
  %t194 = load i32, ptr %l122, !tbaa !23
  %t195 = insertvalue { %"compiler/source:Span", i32, ptr } %t193, i32 %t194, 1
  %t196 = load ptr, ptr %l127, !tbaa !29
  %t197 = insertvalue { %"compiler/source:Span", i32, ptr } %t195, ptr %t196, 2
  %t198 = getelementptr { i64, [3 x i64] }, ptr %t190, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t197, ptr %t198
  %t199 = load { i64, [3 x i64] }, ptr %t190
  %t201 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t199, ptr %t201
  %t202 = load ptr, ptr %l118, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t202, ptr %t201)
  br label %bb28
bb28:
  %t204 = load ptr, ptr %l0, !tbaa !29
  store ptr %t204, ptr %l130, !tbaa !29
  %t205 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t205, ptr %l131
  %t206 = load ptr, ptr %l0, !tbaa !29
  %t208 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t206)
  store i32 %t208, ptr %l133
  br label %bb29
bb29:
  %t209 = load ptr, ptr %l130, !tbaa !29
  %t210 = load %"compiler/source:Span", ptr %l131
  %t211 = load i32, ptr %l133, !tbaa !23
  %t212 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t209, %"compiler/source:Span" %t210, i32 %t211)
  store i64 %t212, ptr %l134
  br label %bb30
bb30:
  %t213 = load i64, ptr %l134, !tbaa !24
  store i64 %t213, ptr %l18, !tbaa !24
  %t214 = load ptr, ptr %l0, !tbaa !29
  store ptr %t214, ptr %l135, !tbaa !29
  %t215 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t215, ptr %l136
  %t216 = load i64, ptr %l18, !tbaa !24
  %t218 = trunc i64 %t216 to i32
  store i32 %t218, ptr %l139, !tbaa !23
  %t220 = load ptr, ptr %l0, !tbaa !29
  store ptr %t220, ptr %l140, !tbaa !29
  %t221 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t221, ptr %l141
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t224 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t222)
  store i32 %t224, ptr %l143
  br label %bb31
bb31:
  store i32 22, ptr %l144
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t226 = load %"compiler/source:Span", ptr %l1
  %t227 = load i64, ptr %l17, !tbaa !24
  %t231 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t225, %"compiler/source:Span" %t226, i64 %t227)
  store ptr %t231, ptr %l148
  br label %bb32
bb32:
  %t232 = load ptr, ptr %l140, !tbaa !29
  %t233 = load %"compiler/source:Span", ptr %l141
  %t234 = load i32, ptr %l143, !tbaa !23
  %t235 = load i32, ptr %l144, !range !{i32 0, i32 43}
  %t236 = load ptr, ptr %l148, !tbaa !29
  %t237 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t232, %"compiler/source:Span" %t233, i32 %t234, i32 %t235, ptr %t236, ptr null)
  store ptr %t237, ptr %l149
  br label %bb33
bb33:
  store { i64, [3 x i64] } zeroinitializer, ptr %t238
  %t239 = getelementptr { i64, [3 x i64] }, ptr %t238, i32 0, i32 0
  store i64 0, ptr %t239
  %t240 = load %"compiler/source:Span", ptr %l136
  %t241 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t240, 0
  %t242 = load i32, ptr %l139, !tbaa !23
  %t243 = insertvalue { %"compiler/source:Span", i32, ptr } %t241, i32 %t242, 1
  %t244 = load ptr, ptr %l149, !tbaa !29
  %t245 = insertvalue { %"compiler/source:Span", i32, ptr } %t243, ptr %t244, 2
  %t246 = getelementptr { i64, [3 x i64] }, ptr %t238, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t245, ptr %t246
  %t247 = load { i64, [3 x i64] }, ptr %t238
  %t249 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t247, ptr %t249
  %t250 = load ptr, ptr %l135, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t250, ptr %t249)
  br label %bb34
bb34:
  %t252 = load ptr, ptr %l0, !tbaa !29
  store ptr %t252, ptr %l152, !tbaa !29
  %t253 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t253, ptr %l153
  %t254 = load ptr, ptr %l0, !tbaa !29
  %t256 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t254)
  store i32 %t256, ptr %l155
  br label %bb35
bb35:
  %t257 = load ptr, ptr %l152, !tbaa !29
  %t258 = load %"compiler/source:Span", ptr %l153
  %t259 = load i32, ptr %l155, !tbaa !23
  %t260 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t257, %"compiler/source:Span" %t258, i32 %t259)
  store i64 %t260, ptr %l156
  br label %bb36
bb36:
  %t261 = load i64, ptr %l156, !tbaa !24
  store i64 %t261, ptr %l19, !tbaa !24
  %t262 = load ptr, ptr %l0, !tbaa !29
  store ptr %t262, ptr %l157, !tbaa !29
  %t263 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t263, ptr %l158
  %t264 = load i64, ptr %l19, !tbaa !24
  %t266 = trunc i64 %t264 to i32
  store i32 %t266, ptr %l161, !tbaa !23
  %t268 = load ptr, ptr %l0, !tbaa !29
  store ptr %t268, ptr %l162, !tbaa !29
  %t269 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t269, ptr %l163
  %t270 = load ptr, ptr %l0, !tbaa !29
  %t272 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t270)
  store i32 %t272, ptr %l165
  br label %bb37
bb37:
  %t273 = load ptr, ptr %l162, !tbaa !29
  %t274 = load %"compiler/source:Span", ptr %l163
  %t275 = load i32, ptr %l165, !tbaa !23
  %t276 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v0, ptr %t273, %"compiler/source:Span" %t274, i32 %t275, i64 0)
  store ptr %t276, ptr %l166
  br label %bb38
bb38:
  store { i64, [3 x i64] } zeroinitializer, ptr %t277
  %t278 = getelementptr { i64, [3 x i64] }, ptr %t277, i32 0, i32 0
  store i64 0, ptr %t278
  %t279 = load %"compiler/source:Span", ptr %l158
  %t280 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t279, 0
  %t281 = load i32, ptr %l161, !tbaa !23
  %t282 = insertvalue { %"compiler/source:Span", i32, ptr } %t280, i32 %t281, 1
  %t283 = load ptr, ptr %l166, !tbaa !29
  %t284 = insertvalue { %"compiler/source:Span", i32, ptr } %t282, ptr %t283, 2
  %t285 = getelementptr { i64, [3 x i64] }, ptr %t277, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t284, ptr %t285
  %t286 = load { i64, [3 x i64] }, ptr %t277
  %t288 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t286, ptr %t288
  %t289 = load ptr, ptr %l157, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t289, ptr %t288)
  br label %bb39
bb39:
  %t291 = load ptr, ptr %l0, !tbaa !29
  %t293 = getelementptr %"compiler/check:Checker", ptr %t291, i32 0, i32 37
  %t295 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t293)
  store i64 %t295, ptr %l171
  br label %bb40
bb40:
  %t296 = load i64, ptr %l171, !tbaa !24
  store i64 %t296, ptr %l20, !tbaa !24
  %t297 = load ptr, ptr %l0, !tbaa !29
  %t298 = load %"compiler/source:Span", ptr %l1
  %t302 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t297, i32 2, %"compiler/source:Span" %t298)
  store { i64, i64, i64 } %t302, ptr %l175
  br label %bb41
bb41:
  %t303 = load { i64, i64, i64 }, ptr %l175
  store { i64, i64, i64 } %t303, ptr %l21
  %t304 = getelementptr { i64, i64, i64 }, ptr %l21, i32 0, i32 0
  %t305 = load i64, ptr %t304, !tbaa !24
  store i64 %t305, ptr %l22, !tbaa !24
  %t307 = getelementptr { i64, i64, i64 }, ptr %l21, i32 0, i32 1
  %t308 = load i64, ptr %t307, !tbaa !24
  store i64 %t308, ptr %l23, !tbaa !24
  %t310 = getelementptr { i64, i64, i64 }, ptr %l21, i32 0, i32 2
  %t311 = load i64, ptr %t310, !tbaa !24
  store i64 %t311, ptr %l24, !tbaa !24
  %t313 = load ptr, ptr %l0, !tbaa !29
  %t315 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t313)
  store ptr %t315, ptr %l181
  br label %bb42
bb42:
  %t316 = load ptr, ptr %l181, !tbaa !29
  %t318 = getelementptr %"compiler/check:frame", ptr %t316, i32 0, i32 10
  %t320 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t318)
  %t321 = extractvalue { i32, i64 } %t320, 1
  %t322 = extractvalue { i32, i64 } %t320, 0
  store i32 %t322, ptr %l185
  %t323 = icmp ne i32 %t322, 0
  br i1 %t323, label %bb44, label %ok.324, !prof !99
ok.324:
  store i64 %t321, ptr %l184
  br label %bb43
bb43:
  %t325 = load i64, ptr %l184, !tbaa !24
  store i64 %t325, ptr %l179, !tbaa !24
  br label %bb46
bb44:
  br label %bb45
bb45:
  call void @__olang_ert_req_clear()
  br label %bb46
bb46:
  %t326 = load ptr, ptr %l0, !tbaa !29
  %t328 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t326)
  store ptr %t328, ptr %l187
  br label %bb47
bb47:
  %t329 = load ptr, ptr %l187, !tbaa !29
  %t331 = getelementptr %"compiler/check:frame", ptr %t329, i32 0, i32 10
  %t332 = load i64, ptr %l22, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t331, i64 %t332)
  br label %bb48
bb48:
  %t335 = load ptr, ptr %l0, !tbaa !29
  store ptr %t335, ptr %l191, !tbaa !29
  %t336 = load ptr, ptr %l0, !tbaa !29
  store ptr %t336, ptr %l192, !tbaa !29
  %t337 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t337, ptr %l193
  %t338 = load ptr, ptr %l0, !tbaa !29
  store ptr %t338, ptr %l194, !tbaa !29
  %t339 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t339, ptr %l195
  %t340 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t340, ptr %l196, !tbaa !23
  store i32 15, ptr %l197
  %t341 = load ptr, ptr %l0, !tbaa !29
  %t342 = load %"compiler/source:Span", ptr %l1
  %t343 = load i64, ptr %l19, !tbaa !24
  %t347 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t341, %"compiler/source:Span" %t342, i64 %t343)
  store ptr %t347, ptr %l201
  br label %bb49
bb49:
  %t348 = load ptr, ptr %l0, !tbaa !29
  %t349 = load %"compiler/source:Span", ptr %l1
  %t350 = load i64, ptr %l18, !tbaa !24
  %t354 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t348, %"compiler/source:Span" %t349, i64 %t350)
  store ptr %t354, ptr %l205
  br label %bb50
bb50:
  %t355 = load ptr, ptr %l205, !tbaa !29
  %t356 = load ptr, ptr %l194, !tbaa !29
  %t357 = load %"compiler/source:Span", ptr %l195
  %t358 = load i32, ptr %l196, !tbaa !23
  %t359 = load i32, ptr %l197, !range !{i32 0, i32 43}
  %t360 = load ptr, ptr %l201, !tbaa !29
  %t362 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t356, %"compiler/source:Span" %t357, i32 %t358, i32 %t359, ptr %t360, ptr %t355)
  store ptr %t362, ptr %l207
  br label %bb51
bb51:
  %t363 = load i64, ptr %l22, !tbaa !24
  %t364 = load ptr, ptr %l192, !tbaa !29
  %t365 = load %"compiler/source:Span", ptr %l193
  %t366 = load ptr, ptr %l207, !tbaa !29
  %t368 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebreakUnless(ptr %v0, ptr %v0, ptr %v0, ptr %t364, %"compiler/source:Span" %t365, ptr %t366, i64 %t363)
  store ptr %t368, ptr %l209
  br label %bb52
bb52:
  %t369 = load ptr, ptr %l191, !tbaa !29
  %t370 = load ptr, ptr %l209, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t369, ptr %t370)
  br label %bb53
bb53:
  %t371 = load ptr, ptr %l0, !tbaa !29
  %t372 = load i32, ptr %l16, !tbaa !23
  %t375 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayOf(ptr %v0, ptr %t371, i32 %t372)
  store i32 %t375, ptr %l212
  br label %bb54
bb54:
  %t376 = load i32, ptr %l212, !tbaa !23
  store i32 %t376, ptr %l25, !tbaa !23
  %t377 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t377, ptr %l213
  %t378 = load ptr, ptr %l0, !tbaa !29
  %t379 = load i32, ptr %l16, !tbaa !23
  %t382 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t378, i32 %t379)
  store i32 %t382, ptr %l216
  br label %bb55
bb55:
  %t383 = load ptr, ptr %l0, !tbaa !29
  %t384 = load %"compiler/source:Span", ptr %l1
  %t385 = load i64, ptr %l17, !tbaa !24
  %t389 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t383, %"compiler/source:Span" %t384, i64 %t385)
  store ptr %t389, ptr %l220
  br label %bb56
bb56:
  store { i64, [4 x i64] } zeroinitializer, ptr %t390
  %t391 = getelementptr { i64, [4 x i64] }, ptr %t390, i32 0, i32 0
  store i64 2, ptr %t391
  %t392 = load %"compiler/source:Span", ptr %l213
  %t393 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t392, 0
  %t394 = load i32, ptr %l216, !tbaa !23
  %t395 = insertvalue { %"compiler/source:Span", i32, ptr } %t393, i32 %t394, 1
  %t396 = load ptr, ptr %l220, !tbaa !29
  %t397 = insertvalue { %"compiler/source:Span", i32, ptr } %t395, ptr %t396, 2
  %t398 = getelementptr { i64, [4 x i64] }, ptr %t390, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t397, ptr %t398
  %t399 = load { i64, [4 x i64] }, ptr %t390
  %t401 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t399, ptr %t401
  store ptr %t401, ptr %l26, !tbaa !29
  %t403 = load ptr, ptr %l0, !tbaa !29
  store ptr %t403, ptr %l223, !tbaa !29
  %t404 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t404, ptr %l224
  %t405 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t405, ptr %l225
  %t406 = load ptr, ptr %l0, !tbaa !29
  %t408 = getelementptr %"compiler/check:Checker", ptr %t406, i32 0, i32 1
  %t409 = load ptr, ptr %t408, !tbaa !29
  %t411 = getelementptr %"compiler/generic:Program", ptr %t409, i32 0, i32 2
  %t412 = load i32, ptr %l25, !tbaa !23
  %t415 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t411, i32 %t412)
  store i32 %t415, ptr %l230
  br label %bb57
bb57:
  %t416 = load ptr, ptr %l26, !tbaa !29
  store ptr %t416, ptr %l231, !tbaa !29
  %t417 = load ptr, ptr %l0, !tbaa !29
  %t418 = load %"compiler/source:Span", ptr %l1
  %t419 = load i64, ptr %l19, !tbaa !24
  %t423 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t417, %"compiler/source:Span" %t418, i64 %t419)
  store ptr %t423, ptr %l235
  br label %bb58
bb58:
  %t424 = load ptr, ptr %l231, !tbaa !29
  %t425 = load ptr, ptr %l235, !tbaa !29
  %t427 = call %"compiler/typed:Elem" @compiler_2ftyped_3aElem_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %t424, ptr %t425, i32 0)
  store %"compiler/typed:Elem" %t427, ptr %l237
  br label %bb59
bb59:
  %t428 = load %"compiler/typed:Elem", ptr %l237
  %t429 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Elem" %t428, ptr %t429
  store { i64, [4 x i64] } zeroinitializer, ptr %t430
  %t431 = getelementptr { i64, [4 x i64] }, ptr %t430, i32 0, i32 0
  store i64 4, ptr %t431
  %t432 = load %"compiler/source:Span", ptr %l225
  %t433 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t432, 0
  %t434 = load i32, ptr %l230, !tbaa !23
  %t435 = insertvalue { %"compiler/source:Span", i32, ptr } %t433, i32 %t434, 1
  %t437 = insertvalue { %"compiler/source:Span", i32, ptr } %t435, ptr %t429, 2
  %t438 = getelementptr { i64, [4 x i64] }, ptr %t430, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t437, ptr %t438
  %t439 = load { i64, [4 x i64] }, ptr %t430
  %t441 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t439, ptr %t441
  %t442 = load ptr, ptr %l223, !tbaa !29
  %t443 = load %"compiler/source:Span", ptr %l224
  %t445 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v0, ptr %v0, ptr %t442, %"compiler/source:Span" %t443, ptr %t441)
  store ptr %t445, ptr %l241
  br label %bb60
bb60:
  %t446 = load ptr, ptr %l241, !tbaa !29
  %t447 = load ptr, ptr %l0, !tbaa !29
  %t448 = load %"compiler/source:Span", ptr %l1
  %t449 = load ptr, ptr %l2, !tbaa !29
  %t450 = load i64, ptr %l9, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eelementLocals(ptr %v0, ptr %v1, ptr %v0, ptr %t447, %"compiler/source:Span" %t448, ptr %t449, i64 %t450, ptr %t446)
  br label %bb61
bb61:
  %t457 = load ptr, ptr %l0, !tbaa !29
  %t458 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkBody(ptr %v0, ptr %v1, ptr %v3, ptr %t457, ptr %t458, ptr %a5, i32 %a6)
  br label %bb62
bb62:
  %t465 = load ptr, ptr %l0, !tbaa !29
  %t467 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t465)
  store ptr %t467, ptr %l253
  br label %bb63
bb63:
  %t468 = load ptr, ptr %l253, !tbaa !29
  %t470 = getelementptr %"compiler/check:frame", ptr %t468, i32 0, i32 10
  %t472 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t470)
  %t473 = extractvalue { i32, i64 } %t472, 1
  %t474 = extractvalue { i32, i64 } %t472, 0
  store i32 %t474, ptr %l257
  %t475 = icmp ne i32 %t474, 0
  br i1 %t475, label %bb65, label %ok.476, !prof !99
ok.476:
  store i64 %t473, ptr %l256
  br label %bb64
bb64:
  %t477 = load i64, ptr %l256, !tbaa !24
  store i64 %t477, ptr %l251, !tbaa !24
  br label %bb67
bb65:
  br label %bb66
bb66:
  call void @__olang_ert_req_clear()
  br label %bb67
bb67:
  %t478 = load ptr, ptr %l0, !tbaa !29
  %t480 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t478)
  store ptr %t480, ptr %l260
  br label %bb68
bb68:
  %t481 = load ptr, ptr %l260, !tbaa !29
  %t483 = getelementptr %"compiler/check:frame", ptr %t481, i32 0, i32 11
  %t485 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t483)
  %t486 = extractvalue { i32, i64 } %t485, 1
  %t487 = extractvalue { i32, i64 } %t485, 0
  store i32 %t487, ptr %l264
  %t488 = icmp ne i32 %t487, 0
  br i1 %t488, label %bb70, label %ok.489, !prof !99
ok.489:
  store i64 %t486, ptr %l263
  br label %bb69
bb69:
  %t490 = load i64, ptr %l263, !tbaa !24
  store i64 %t490, ptr %l258, !tbaa !24
  br label %bb72
bb70:
  br label %bb71
bb71:
  call void @__olang_ert_req_clear()
  br label %bb72
bb72:
  %t491 = load ptr, ptr %l0, !tbaa !29
  %t492 = load i64, ptr %l22, !tbaa !24
  %t493 = load i64, ptr %l23, !tbaa !24
  %t494 = load i64, ptr %l24, !tbaa !24
  %t495 = load i64, ptr %l20, !tbaa !24
  %t501 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %v0, ptr %t491, i64 %t492, i64 %t493, i64 %t494, i64 %t495)
  store ptr %t501, ptr %l270
  br label %bb73
bb73:
  %t502 = load ptr, ptr %l270, !tbaa !29
  store ptr %t502, ptr %l28, !tbaa !29
  %t503 = load ptr, ptr %l0, !tbaa !29
  %t505 = getelementptr %"compiler/check:Checker", ptr %t503, i32 0, i32 37
  %t507 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t505)
  store i64 %t507, ptr %l273
  br label %bb74
bb74:
  %t508 = load i64, ptr %l273, !tbaa !24
  store i64 %t508, ptr %l29, !tbaa !24
  %t509 = load ptr, ptr %l0, !tbaa !29
  %t510 = load %"compiler/source:Span", ptr %l1
  %t514 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t509, i32 3, %"compiler/source:Span" %t510)
  store { i64, i64, i64 } %t514, ptr %l277
  br label %bb75
bb75:
  %t515 = load { i64, i64, i64 }, ptr %l277
  store { i64, i64, i64 } %t515, ptr %l30
  %t516 = getelementptr { i64, i64, i64 }, ptr %l30, i32 0, i32 0
  %t517 = load i64, ptr %t516, !tbaa !24
  store i64 %t517, ptr %l31, !tbaa !24
  %t519 = getelementptr { i64, i64, i64 }, ptr %l30, i32 0, i32 1
  %t520 = load i64, ptr %t519, !tbaa !24
  store i64 %t520, ptr %l32, !tbaa !24
  %t522 = getelementptr { i64, i64, i64 }, ptr %l30, i32 0, i32 2
  %t523 = load i64, ptr %t522, !tbaa !24
  store i64 %t523, ptr %l33, !tbaa !24
  %t525 = load ptr, ptr %l0, !tbaa !29
  store ptr %t525, ptr %l281, !tbaa !29
  %t526 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t526, ptr %l282
  %t527 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t527, ptr %l283
  %t528 = load ptr, ptr %l0, !tbaa !29
  %t530 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t528)
  store i32 %t530, ptr %l285
  br label %bb76
bb76:
  %t531 = load i64, ptr %l19, !tbaa !24
  %t533 = trunc i64 %t531 to i32
  store { i64, [4 x i64] } zeroinitializer, ptr %t535
  %t536 = getelementptr { i64, [4 x i64] }, ptr %t535, i32 0, i32 0
  store i64 0, ptr %t536
  %t537 = load %"compiler/source:Span", ptr %l283
  %t538 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t537, 0
  %t539 = load i32, ptr %l285, !tbaa !23
  %t540 = insertvalue { %"compiler/source:Span", i32, i32 } %t538, i32 %t539, 1
  %t542 = insertvalue { %"compiler/source:Span", i32, i32 } %t540, i32 %t533, 2
  %t543 = getelementptr { i64, [4 x i64] }, ptr %t535, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t542, ptr %t543
  %t544 = load { i64, [4 x i64] }, ptr %t535
  %t546 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t544, ptr %t546
  store ptr %t546, ptr %l290, !tbaa !29
  %t547 = load ptr, ptr %l0, !tbaa !29
  store ptr %t547, ptr %l291, !tbaa !29
  %t548 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t548, ptr %l292
  %t549 = load ptr, ptr %l0, !tbaa !29
  %t551 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t549)
  store i32 %t551, ptr %l294
  br label %bb77
bb77:
  store i32 3, ptr %l295
  %t552 = load ptr, ptr %l0, !tbaa !29
  %t553 = load %"compiler/source:Span", ptr %l1
  %t554 = load i64, ptr %l19, !tbaa !24
  %t558 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t552, %"compiler/source:Span" %t553, i64 %t554)
  store ptr %t558, ptr %l299
  br label %bb78
bb78:
  %t559 = load ptr, ptr %l0, !tbaa !29
  store ptr %t559, ptr %l300, !tbaa !29
  %t560 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t560, ptr %l301
  %t561 = load ptr, ptr %l0, !tbaa !29
  %t563 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t561)
  store i32 %t563, ptr %l303
  br label %bb79
bb79:
  %t564 = load ptr, ptr %l300, !tbaa !29
  %t565 = load %"compiler/source:Span", ptr %l301
  %t566 = load i32, ptr %l303, !tbaa !23
  %t567 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v0, ptr %t564, %"compiler/source:Span" %t565, i32 %t566, i64 1)
  store ptr %t567, ptr %l304
  br label %bb80
bb80:
  %t568 = load ptr, ptr %l304, !tbaa !29
  %t569 = load ptr, ptr %l291, !tbaa !29
  %t570 = load %"compiler/source:Span", ptr %l292
  %t571 = load i32, ptr %l294, !tbaa !23
  %t572 = load i32, ptr %l295, !range !{i32 0, i32 43}
  %t573 = load ptr, ptr %l299, !tbaa !29
  %t575 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t569, %"compiler/source:Span" %t570, i32 %t571, i32 %t572, ptr %t573, ptr %t568)
  store ptr %t575, ptr %l306
  br label %bb81
bb81:
  store { i64, [3 x i64] } zeroinitializer, ptr %t576
  %t577 = getelementptr { i64, [3 x i64] }, ptr %t576, i32 0, i32 0
  store i64 1, ptr %t577
  %t578 = load %"compiler/source:Span", ptr %l282
  %t579 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t578, 0
  %t580 = load ptr, ptr %l290, !tbaa !29
  %t581 = insertvalue { %"compiler/source:Span", ptr, ptr } %t579, ptr %t580, 1
  %t582 = load ptr, ptr %l306, !tbaa !29
  %t583 = insertvalue { %"compiler/source:Span", ptr, ptr } %t581, ptr %t582, 2
  %t584 = getelementptr { i64, [3 x i64] }, ptr %t576, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t583, ptr %t584
  %t585 = load { i64, [3 x i64] }, ptr %t576
  %t587 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t585, ptr %t587
  %t588 = load ptr, ptr %l281, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t588, ptr %t587)
  br label %bb82
bb82:
  %t590 = load i64, ptr %l9, !tbaa !24
  %t592 = icmp sge i64 %t590, 0
  br i1 %t592, label %bb83, label %bb84
bb83:
  %t594 = load ptr, ptr %l0, !tbaa !29
  store ptr %t594, ptr %l311, !tbaa !29
  %t595 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t595, ptr %l312
  %t596 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t596, ptr %l313
  %t597 = load ptr, ptr %l0, !tbaa !29
  %t599 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t597)
  store i32 %t599, ptr %l315
  br label %bb85
bb84:
  br label %bb92
bb85:
  %t600 = load i64, ptr %l9, !tbaa !24
  %t602 = trunc i64 %t600 to i32
  store { i64, [4 x i64] } zeroinitializer, ptr %t604
  %t605 = getelementptr { i64, [4 x i64] }, ptr %t604, i32 0, i32 0
  store i64 0, ptr %t605
  %t606 = load %"compiler/source:Span", ptr %l313
  %t607 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t606, 0
  %t608 = load i32, ptr %l315, !tbaa !23
  %t609 = insertvalue { %"compiler/source:Span", i32, i32 } %t607, i32 %t608, 1
  %t611 = insertvalue { %"compiler/source:Span", i32, i32 } %t609, i32 %t602, 2
  %t612 = getelementptr { i64, [4 x i64] }, ptr %t604, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t611, ptr %t612
  %t613 = load { i64, [4 x i64] }, ptr %t604
  %t615 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t613, ptr %t615
  store ptr %t615, ptr %l320, !tbaa !29
  %t616 = load ptr, ptr %l0, !tbaa !29
  store ptr %t616, ptr %l321, !tbaa !29
  %t617 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t617, ptr %l322
  %t618 = load ptr, ptr %l0, !tbaa !29
  %t620 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t618)
  store i32 %t620, ptr %l324
  br label %bb86
bb86:
  store i32 3, ptr %l325
  %t621 = load ptr, ptr %l0, !tbaa !29
  %t622 = load %"compiler/source:Span", ptr %l1
  %t623 = load i64, ptr %l9, !tbaa !24
  %t627 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t621, %"compiler/source:Span" %t622, i64 %t623)
  store ptr %t627, ptr %l329
  br label %bb87
bb87:
  %t628 = load ptr, ptr %l0, !tbaa !29
  store ptr %t628, ptr %l330, !tbaa !29
  %t629 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t629, ptr %l331
  %t630 = load ptr, ptr %l0, !tbaa !29
  %t632 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t630)
  store i32 %t632, ptr %l333
  br label %bb88
bb88:
  %t633 = load ptr, ptr %l330, !tbaa !29
  %t634 = load %"compiler/source:Span", ptr %l331
  %t635 = load i32, ptr %l333, !tbaa !23
  %t636 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v0, ptr %t633, %"compiler/source:Span" %t634, i32 %t635, i64 1)
  store ptr %t636, ptr %l334
  br label %bb89
bb89:
  %t637 = load ptr, ptr %l334, !tbaa !29
  %t638 = load ptr, ptr %l321, !tbaa !29
  %t639 = load %"compiler/source:Span", ptr %l322
  %t640 = load i32, ptr %l324, !tbaa !23
  %t641 = load i32, ptr %l325, !range !{i32 0, i32 43}
  %t642 = load ptr, ptr %l329, !tbaa !29
  %t644 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t638, %"compiler/source:Span" %t639, i32 %t640, i32 %t641, ptr %t642, ptr %t637)
  store ptr %t644, ptr %l336
  br label %bb90
bb90:
  store { i64, [3 x i64] } zeroinitializer, ptr %t645
  %t646 = getelementptr { i64, [3 x i64] }, ptr %t645, i32 0, i32 0
  store i64 1, ptr %t646
  %t647 = load %"compiler/source:Span", ptr %l312
  %t648 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t647, 0
  %t649 = load ptr, ptr %l320, !tbaa !29
  %t650 = insertvalue { %"compiler/source:Span", ptr, ptr } %t648, ptr %t649, 1
  %t651 = load ptr, ptr %l336, !tbaa !29
  %t652 = insertvalue { %"compiler/source:Span", ptr, ptr } %t650, ptr %t651, 2
  %t653 = getelementptr { i64, [3 x i64] }, ptr %t645, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t652, ptr %t653
  %t654 = load { i64, [3 x i64] }, ptr %t645
  %t656 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t654, ptr %t656
  %t657 = load ptr, ptr %l311, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t657, ptr %t656)
  br label %bb91
bb91:
  br label %bb92
bb92:
  %t659 = load ptr, ptr %l0, !tbaa !29
  %t660 = load i64, ptr %l31, !tbaa !24
  %t661 = load i64, ptr %l32, !tbaa !24
  %t662 = load i64, ptr %l33, !tbaa !24
  %t663 = load i64, ptr %l29, !tbaa !24
  %t669 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %v0, ptr %t659, i64 %t660, i64 %t661, i64 %t662, i64 %t663)
  store ptr %t669, ptr %l344
  br label %bb93
bb93:
  %t670 = load ptr, ptr %l344, !tbaa !29
  %t671 = load ptr, ptr %l0, !tbaa !29
  %t672 = load %"compiler/source:Span", ptr %l1
  %t673 = load ptr, ptr %l28, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t676
  %t677 = getelementptr { i64, [3 x i64] }, ptr %t676, i32 0, i32 0
  store i64 4, ptr %t677
  %t679 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t672, 0
  %t681 = insertvalue { %"compiler/source:Span", ptr, ptr } %t679, ptr %t673, 1
  %t683 = insertvalue { %"compiler/source:Span", ptr, ptr } %t681, ptr %t670, 2
  %t684 = getelementptr { i64, [3 x i64] }, ptr %t676, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t683, ptr %t684
  %t685 = load { i64, [3 x i64] }, ptr %t676
  %t687 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t685, ptr %t687
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t671, ptr %t687)
  br label %bb94
bb94:
  %t690 = load ptr, ptr %l0, !tbaa !29
  store ptr %t690, ptr %l352, !tbaa !29
  %t691 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t691, ptr %l353
  %t692 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t692, ptr %l354
  %t693 = load ptr, ptr %l0, !tbaa !29
  %t695 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t693)
  store i32 %t695, ptr %l356
  br label %bb95
bb95:
  %t696 = load i64, ptr %l8, !tbaa !24
  %t698 = trunc i64 %t696 to i32
  store { i64, [4 x i64] } zeroinitializer, ptr %t700
  %t701 = getelementptr { i64, [4 x i64] }, ptr %t700, i32 0, i32 0
  store i64 0, ptr %t701
  %t702 = load %"compiler/source:Span", ptr %l354
  %t703 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t702, 0
  %t704 = load i32, ptr %l356, !tbaa !23
  %t705 = insertvalue { %"compiler/source:Span", i32, i32 } %t703, i32 %t704, 1
  %t707 = insertvalue { %"compiler/source:Span", i32, i32 } %t705, i32 %t698, 2
  %t708 = getelementptr { i64, [4 x i64] }, ptr %t700, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t707, ptr %t708
  %t709 = load { i64, [4 x i64] }, ptr %t700
  %t711 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t709, ptr %t711
  store ptr %t711, ptr %l361, !tbaa !29
  %t712 = load ptr, ptr %l0, !tbaa !29
  store ptr %t712, ptr %l362, !tbaa !29
  %t713 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t713, ptr %l363
  %t714 = load ptr, ptr %l0, !tbaa !29
  %t716 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t714)
  store i32 %t716, ptr %l365
  br label %bb96
bb96:
  store i32 3, ptr %l366
  %t717 = load ptr, ptr %l0, !tbaa !29
  %t718 = load %"compiler/source:Span", ptr %l1
  %t719 = load i64, ptr %l8, !tbaa !24
  %t723 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t717, %"compiler/source:Span" %t718, i64 %t719)
  store ptr %t723, ptr %l370
  br label %bb97
bb97:
  %t724 = load ptr, ptr %l0, !tbaa !29
  %t725 = load %"compiler/source:Span", ptr %l1
  %t726 = load i64, ptr %l18, !tbaa !24
  %t730 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t724, %"compiler/source:Span" %t725, i64 %t726)
  store ptr %t730, ptr %l374
  br label %bb98
bb98:
  %t731 = load ptr, ptr %l374, !tbaa !29
  %t732 = load ptr, ptr %l362, !tbaa !29
  %t733 = load %"compiler/source:Span", ptr %l363
  %t734 = load i32, ptr %l365, !tbaa !23
  %t735 = load i32, ptr %l366, !range !{i32 0, i32 43}
  %t736 = load ptr, ptr %l370, !tbaa !29
  %t738 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t732, %"compiler/source:Span" %t733, i32 %t734, i32 %t735, ptr %t736, ptr %t731)
  store ptr %t738, ptr %l376
  br label %bb99
bb99:
  store { i64, [3 x i64] } zeroinitializer, ptr %t739
  %t740 = getelementptr { i64, [3 x i64] }, ptr %t739, i32 0, i32 0
  store i64 1, ptr %t740
  %t741 = load %"compiler/source:Span", ptr %l353
  %t742 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t741, 0
  %t743 = load ptr, ptr %l361, !tbaa !29
  %t744 = insertvalue { %"compiler/source:Span", ptr, ptr } %t742, ptr %t743, 1
  %t745 = load ptr, ptr %l376, !tbaa !29
  %t746 = insertvalue { %"compiler/source:Span", ptr, ptr } %t744, ptr %t745, 2
  %t747 = getelementptr { i64, [3 x i64] }, ptr %t739, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t746, ptr %t747
  %t748 = load { i64, [3 x i64] }, ptr %t739
  %t750 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t748, ptr %t750
  %t751 = load ptr, ptr %l352, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t751, ptr %t750)
  br label %bb100
bb100:
  %t753 = load ptr, ptr %l0, !tbaa !29
  %t754 = load i64, ptr %l12, !tbaa !24
  %t755 = load i64, ptr %l13, !tbaa !24
  %t756 = load i64, ptr %l14, !tbaa !24
  %t757 = load i64, ptr %l10, !tbaa !24
  %t763 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %v0, ptr %t753, i64 %t754, i64 %t755, i64 %t756, i64 %t757)
  store ptr %t763, ptr %l384
  br label %bb101
bb101:
  %t764 = load ptr, ptr %l384, !tbaa !29
  %t765 = load ptr, ptr %l0, !tbaa !29
  %t766 = load %"compiler/source:Span", ptr %l1
  store { i64, [3 x i64] } zeroinitializer, ptr %t768
  %t769 = getelementptr { i64, [3 x i64] }, ptr %t768, i32 0, i32 0
  store i64 4, ptr %t769
  %t771 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t766, 0
  %t773 = insertvalue { %"compiler/source:Span", ptr, ptr } %t771, ptr %t764, 1
  %t774 = insertvalue { %"compiler/source:Span", ptr, ptr } %t773, ptr null, 2
  %t775 = getelementptr { i64, [3 x i64] }, ptr %t768, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t774, ptr %t775
  %t776 = load { i64, [3 x i64] }, ptr %t768
  %t778 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t776, ptr %t778
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t765, ptr %t778)
  br label %bb102
bb102:
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewordBefore(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l10 = alloca ptr
  %l12 = alloca ptr
  %l15 = alloca ptr
  %l28 = alloca i1
  %l29 = alloca { i64, ptr }
  %l33 = alloca i1
  %l34 = alloca { i64, ptr }
  %l38 = alloca i1
  %l39 = alloca { i64, ptr }
  %l55 = alloca %"compiler/source:Span"
  %l61 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 10
  store ptr %t9, ptr %l10, !tbaa !29
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t10)
  store ptr %t12, ptr %l12
  br label %bb1
bb1:
  %t13 = load ptr, ptr %l12, !tbaa !29
  %t15 = getelementptr %"compiler/check:frame", ptr %t13, i32 0, i32 1
  %t16 = load i64, ptr %t15, !tbaa !24
  %t17 = load ptr, ptr %l10, !tbaa !29
  %t19 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t17, i64 %t16)
  store ptr %t19, ptr %l15
  br label %bb2
bb2:
  %t20 = load ptr, ptr %l15, !tbaa !29
  %t22 = getelementptr %"compiler/load:Module", ptr %t20, i32 0, i32 6
  %t23 = load ptr, ptr %t22, !tbaa !29
  store ptr %t23, ptr %l3, !tbaa !29
  %t25 = load ptr, ptr %l3, !tbaa !29
  %t27 = icmp eq ptr %t25, null
  br i1 %t27, label %bb3, label %bb4
bb3:
  call void @__olang_check_failed(ptr @olang_loc_db613d0fd16ec597_dffdd95765f5abab)
  unreachable
bb4:
  br label %bb5
bb5:
  %t29 = load ptr, ptr %l3, !tbaa !29
  %t32 = getelementptr %"compiler/source:Source", ptr %t29, i32 0, i32 1
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !27
  store { i64, ptr } %t33, ptr %l4, !tbaa !27
  %t35 = load i32, ptr %l1, !tbaa !23
  %t37 = sext i32 %t35 to i64
  %t39 = sub i64 %t37, 1
  store i64 %t39, ptr %l5, !tbaa !24
  br label %bb6
bb6:
  %t41 = load i64, ptr %l5, !tbaa !24
  %t43 = icmp sgt i64 %t41, 0
  br i1 %t43, label %bb7, label %bb8
bb7:
  %t45 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t45, ptr %l29, !tbaa !27
  %t46 = load i64, ptr %l5, !tbaa !24
  %t48 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = getelementptr i8, ptr %t49, i64 %t46
  %t51 = load i8, ptr %t50, !tbaa !32
  %t53 = icmp eq i8 %t51, 32
  br i1 %t53, label %bb9, label %bb10
bb8:
  store i1 false, ptr %l28, !tbaa !21
  br label %bb15
bb9:
  store i1 true, ptr %l33, !tbaa !21
  br label %bb11
bb10:
  %t55 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t55, ptr %l34, !tbaa !27
  %t56 = load i64, ptr %l5, !tbaa !24
  %t58 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = getelementptr i8, ptr %t59, i64 %t56
  %t61 = load i8, ptr %t60, !tbaa !32
  %t63 = icmp eq i8 %t61, 9
  store i1 %t63, ptr %l33, !tbaa !21
  br label %bb11
bb11:
  %t65 = load i1, ptr %l33, !tbaa !21
  br i1 %t65, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l38, !tbaa !21
  br label %bb14
bb13:
  %t66 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t66, ptr %l39, !tbaa !27
  %t67 = load i64, ptr %l5, !tbaa !24
  %t69 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !27
  %t71 = getelementptr i8, ptr %t70, i64 %t67
  %t72 = load i8, ptr %t71, !tbaa !32
  %t74 = icmp eq i8 %t72, 10
  store i1 %t74, ptr %l38, !tbaa !21
  br label %bb14
bb14:
  %t76 = load i1, ptr %l38, !tbaa !21
  store i1 %t76, ptr %l28, !tbaa !21
  br label %bb15
bb15:
  %t77 = load i1, ptr %l28, !tbaa !21
  %t78 = xor i1 %t77, true
  br i1 %t78, label %bb16, label %bb17
bb16:
  br label %bb20
bb17:
  br label %bb18
bb18:
  %t80 = load i64, ptr %l5, !tbaa !24
  %t82 = sub i64 %t80, 1
  store i64 %t82, ptr %l5, !tbaa !24
  br label %bb19
bb19:
  br label %bb6
bb20:
  %t84 = load i64, ptr %l5, !tbaa !24
  %t86 = add i64 %t84, 1
  %t89 = extractvalue { i64, ptr } %a2, 0
  %t92 = sub i64 %t86, %t89
  store i64 %t92, ptr %l6, !tbaa !24
  %t94 = load i64, ptr %l6, !tbaa !24
  %t96 = icmp slt i64 %t94, 0
  br i1 %t96, label %bb21, label %bb22
bb21:
  store %olang.scope zeroinitializer, ptr %s2
  %t98 = load i32, ptr %l1, !tbaa !23
  %t99 = load i32, ptr %l1, !tbaa !23
  %t102 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s2, i32 %t98, i32 %t99)
  store %"compiler/source:Span" %t102, ptr %l55
  br label %bb23
bb22:
  br label %bb24
bb23:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t103 = load %"compiler/source:Span", ptr %l55
  store %"compiler/source:Span" %t103, ptr %rv
  br label %ret
bb24:
  %t104 = load i64, ptr %l6, !tbaa !24
  %t106 = trunc i64 %t104 to i32
  %t107 = load i64, ptr %l5, !tbaa !24
  %t109 = add i64 %t107, 1
  %t111 = trunc i64 %t109 to i32
  %t114 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %t106, i32 %t111)
  store %"compiler/source:Span" %t114, ptr %l61
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s0)
  %t115 = load %"compiler/source:Span", ptr %l61
  store %"compiler/source:Span" %t115, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewritableTemp(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l6 = alloca i1
  %l8 = alloca i1
  %l13 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca i1
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i1, ptr %l6, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb5
bb3:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/check:Checker", ptr %t9, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = getelementptr %"compiler/generic:Program", ptr %t12, i32 0, i32 2
  %t15 = load i32, ptr %l1, !tbaa !23
  %t18 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t14, i32 %t15)
  store i64 %t18, ptr %l13
  br label %bb4
bb4:
  %t19 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t20 = load i64, ptr %l13, !tbaa !24
  %t22 = and i64 %t20, %t19
  %t24 = icmp eq i64 %t22, 0
  store i1 %t24, ptr %l8, !tbaa !21
  br label %bb5
bb5:
  %t26 = load i1, ptr %l8, !tbaa !21
  br i1 %t26, label %bb6, label %bb7
bb6:
  store ptr null, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t28 = load ptr, ptr %l2, !tbaa !29
  store ptr %t28, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t29 = load ptr, ptr %l19, !tbaa !29
  %t30 = icmp ne ptr %t29, null
  br i1 %t30, label %bb9, label %bb10
bb9:
  %t32 = load ptr, ptr %l19, !tbaa !29
  %t33 = load i64, ptr %t32, !range !{i64 0, i64 8}
  %t35 = icmp eq i64 %t33, 6
  store i1 %t35, ptr %l20, !tbaa !21
  br label %bb10
bb10:
  %t36 = load i1, ptr %l20, !tbaa !21
  br i1 %t36, label %bb11, label %bb12
bb11:
  %t37 = load ptr, ptr %l2, !tbaa !29
  %t39 = getelementptr { i64, [4 x i64] }, ptr %t37, i32 0, i32 1
  %t40 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t39, i32 0, i32 2
  %t41 = load ptr, ptr %t40
  store ptr %t41, ptr %l3, !tbaa !29
  br label %bb13
bb12:
  br label %bb14
bb13:
  %t43 = load ptr, ptr %l3, !tbaa !29
  store ptr %t43, ptr %l18, !tbaa !29
  br label %bb19
bb14:
  br i1 true, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  store ptr null, ptr %l18, !tbaa !29
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_6f2142d51bf1dfcd_a6163a9035ffb161)
  unreachable
bb19:
  %t46 = load ptr, ptr %l18, !tbaa !29
  store ptr %t46, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local %"compiler/check:narrowed" @compiler_2fcheck_2ecompiler_2fcheck_3anarrowed_2eKilled(%"compiler/check:narrowed" %a0) #0 {
entry:
  %l0 = alloca %"compiler/check:narrowed"
  %l6 = alloca %"compiler/check:narrowed"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/check:narrowed"
  store %"compiler/check:narrowed" %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = getelementptr %"compiler/check:narrowed", ptr %l0, i32 0, i32 0
  %t2 = load i64, ptr %t1, !tbaa !24
  %t3 = getelementptr %"compiler/check:narrowed", ptr %l0, i32 0, i32 1
  %t4 = load i64, ptr %t3, !tbaa !24
  %t5 = getelementptr %"compiler/check:narrowed", ptr %l0, i32 0, i32 2
  %t6 = load i32, ptr %t5, !tbaa !23
  %t7 = getelementptr %"compiler/check:narrowed", ptr %l0, i32 0, i32 3
  %t8 = load i64, ptr %t7, !tbaa !24
  %t9 = getelementptr %"compiler/check:narrowed", ptr %l0, i32 0, i32 4
  %t10 = load i64, ptr %t9, !tbaa !24
  %t16 = call %"compiler/check:narrowed" @compiler_2fcheck_3anarrowed_2ector(ptr %s0, i64 %t2, i64 %t4, i32 %t6, i64 %t8, i64 %t10, i1 true)
  store %"compiler/check:narrowed" %t16, ptr %l6
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t17 = load %"compiler/check:narrowed", ptr %l6
  store %"compiler/check:narrowed" %t17, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:narrowed", ptr %rv
  ret %"compiler/check:narrowed" %rr
}

define dso_local i1 @compiler_2fcheck_2efloatOverflows(i32 %a0, double %a1) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca double
  %l2 = alloca double
  %l5 = alloca i1
  %l27 = alloca i1
  %rv = alloca i1
  store i32 %a0, ptr %l0
  store double %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load double, ptr %l1, !tbaa !26
  %t3 = fcmp ogt double %t1, 0x7fefffffffffffff
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l5, !tbaa !21
  br label %bb3
bb2:
  %t5 = load double, ptr %l1, !tbaa !26
  %t7 = fcmp olt double %t5, 0xffefffffffffffff
  store i1 %t7, ptr %l5, !tbaa !21
  br label %bb3
bb3:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb4, label %bb5
bb4:
  store i1 false, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t11 = load double, ptr %l1, !tbaa !26
  store double %t11, ptr %l2, !tbaa !26
  %t13 = load i32, ptr %l0, !tbaa !23
  %t15 = icmp eq i32 %t13, 13
  br i1 %t15, label %bb7, label %bb8
bb7:
  %t17 = load double, ptr %l1, !tbaa !26
  %t19 = fptrunc double %t17 to float
  %t21 = fpext float %t19 to double
  store double %t21, ptr %l2, !tbaa !26
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t23 = load i32, ptr %l0, !tbaa !23
  %t25 = icmp eq i32 %t23, 11
  br i1 %t25, label %bb10, label %bb11
bb10:
  %t27 = load double, ptr %l1, !tbaa !26
  %t29 = fptrunc double %t27 to half
  %t31 = fpext half %t29 to double
  store double %t31, ptr %l2, !tbaa !26
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t33 = load i32, ptr %l0, !tbaa !23
  %t35 = icmp eq i32 %t33, 12
  br i1 %t35, label %bb13, label %bb14
bb13:
  %t37 = load double, ptr %l1, !tbaa !26
  %t39 = fptrunc double %t37 to bfloat
  %t41 = bitcast bfloat %t39 to i16
  %t42 = zext i16 %t41 to i32
  %t43 = shl i32 %t42, 16
  %t44 = bitcast i32 %t43 to float
  %t45 = fpext float %t44 to double
  store double %t45, ptr %l2, !tbaa !26
  br label %bb15
bb14:
  br label %bb15
bb15:
  %t47 = load double, ptr %l2, !tbaa !26
  %t49 = fcmp ogt double %t47, 0x7fefffffffffffff
  br i1 %t49, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb18
bb17:
  %t51 = load double, ptr %l2, !tbaa !26
  %t53 = fcmp olt double %t51, 0xffefffffffffffff
  store i1 %t53, ptr %l27, !tbaa !21
  br label %bb18
bb18:
  %t55 = load i1, ptr %l27, !tbaa !21
  store i1 %t55, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/check:litv" @compiler_2fcheck_2eintLit(i64 %a0) #0 {
entry:
  %l2 = alloca %"compiler/check:litv"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/check:litv"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call %"compiler/check:litv" @compiler_2fcheck_3alitv_2ector(ptr %s0, i1 true, i1 false, i1 false, i64 %a0, double 0x0000000000000000)
  store %"compiler/check:litv" %t3, ptr %l2
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t4 = load %"compiler/check:litv", ptr %l2
  store %"compiler/check:litv" %t4, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:litv", ptr %rv
  ret %"compiler/check:litv" %rr
}

define dso_local i1 @compiler_2fcheck_2eleaves(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca i1
  %l21 = alloca ptr
  %l22 = alloca i1
  %l25 = alloca ptr
  %l26 = alloca i1
  %l30 = alloca ptr
  %l31 = alloca i1
  %l35 = alloca ptr
  %l36 = alloca i1
  %l45 = alloca i1
  %l49 = alloca i1
  %l50 = alloca i1
  %l53 = alloca i1
  %l54 = alloca ptr
  %l55 = alloca i1
  %l62 = alloca i1
  %l63 = alloca ptr
  %l64 = alloca i1
  %l72 = alloca i1
  %l83 = alloca { i64, ptr }
  %l88 = alloca i1
  %l94 = alloca ptr
  %l95 = alloca i1
  %l106 = alloca i1
  %l108 = alloca i1
  %l112 = alloca i1
  %l114 = alloca ptr
  %l115 = alloca i1
  %l122 = alloca i32
  %l126 = alloca ptr
  %l127 = alloca i1
  %l140 = alloca { i64, ptr }
  %l145 = alloca i1
  %l157 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t2 = load ptr, ptr %l16, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l16, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 17}
  %t8 = icmp eq i64 %t6, 6
  store i1 %t8, ptr %l17, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l17, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store i1 true, ptr %rv
  br label %ret
bb6:
  %t11 = load ptr, ptr %l0, !tbaa !29
  store ptr %t11, ptr %l21, !tbaa !29
  store i1 false, ptr %l22, !tbaa !21
  %t12 = load ptr, ptr %l21, !tbaa !29
  %t13 = icmp ne ptr %t12, null
  br i1 %t13, label %bb7, label %bb8
bb7:
  %t15 = load ptr, ptr %l21, !tbaa !29
  %t16 = load i64, ptr %t15, !range !{i64 0, i64 17}
  %t18 = icmp eq i64 %t16, 7
  store i1 %t18, ptr %l22, !tbaa !21
  br label %bb8
bb8:
  %t19 = load i1, ptr %l22, !tbaa !21
  br i1 %t19, label %bb9, label %bb10
bb9:
  br label %bb15
bb10:
  %t20 = load ptr, ptr %l0, !tbaa !29
  store ptr %t20, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t21 = load ptr, ptr %l25, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %bb11, label %bb12
bb11:
  %t24 = load ptr, ptr %l25, !tbaa !29
  %t25 = load i64, ptr %t24, !range !{i64 0, i64 17}
  %t27 = icmp eq i64 %t25, 8
  store i1 %t27, ptr %l26, !tbaa !21
  br label %bb12
bb12:
  %t28 = load i1, ptr %l26, !tbaa !21
  br i1 %t28, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store i1 true, ptr %rv
  br label %ret
bb16:
  %t30 = load ptr, ptr %l0, !tbaa !29
  store ptr %t30, ptr %l30, !tbaa !29
  store i1 false, ptr %l31, !tbaa !21
  %t31 = load ptr, ptr %l30, !tbaa !29
  %t32 = icmp ne ptr %t31, null
  br i1 %t32, label %bb17, label %bb18
bb17:
  %t34 = load ptr, ptr %l30, !tbaa !29
  %t35 = load i64, ptr %t34, !range !{i64 0, i64 17}
  %t37 = icmp eq i64 %t35, 9
  store i1 %t37, ptr %l31, !tbaa !21
  br label %bb18
bb18:
  %t38 = load i1, ptr %l31, !tbaa !21
  br i1 %t38, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  store i1 true, ptr %rv
  br label %ret
bb22:
  %t40 = load ptr, ptr %l0, !tbaa !29
  store ptr %t40, ptr %l35, !tbaa !29
  store i1 false, ptr %l36, !tbaa !21
  %t41 = load ptr, ptr %l35, !tbaa !29
  %t42 = icmp ne ptr %t41, null
  br i1 %t42, label %bb23, label %bb24
bb23:
  %t44 = load ptr, ptr %l35, !tbaa !29
  %t45 = load i64, ptr %t44, !range !{i64 0, i64 17}
  %t47 = icmp eq i64 %t45, 3
  store i1 %t47, ptr %l36, !tbaa !21
  br label %bb24
bb24:
  %t48 = load i1, ptr %l36, !tbaa !21
  br i1 %t48, label %bb25, label %bb26
bb25:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr { i64, [3 x i64] }, ptr %t49, i32 0, i32 1
  %t52 = getelementptr { %"compiler/source:Span", ptr }, ptr %t51, i32 0, i32 1
  %t53 = load ptr, ptr %t52
  store ptr %t53, ptr %l1, !tbaa !29
  br label %bb27
bb26:
  br label %bb36
bb27:
  %t55 = load ptr, ptr %l1, !tbaa !29
  %t57 = getelementptr %"compiler/typed:If", ptr %t55, i32 0, i32 2
  %t58 = load ptr, ptr %t57, !tbaa !29
  %t60 = icmp eq ptr %t58, null
  %t62 = xor i1 %t60, true
  br i1 %t62, label %bb28, label %bb29
bb28:
  %t64 = load ptr, ptr %l1, !tbaa !29
  %t66 = getelementptr %"compiler/typed:If", ptr %t64, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !29
  %t70 = call i1 @compiler_2fcheck_2eleavesBlock(ptr %v0, ptr %t67)
  store i1 %t70, ptr %l49
  br label %bb30
bb29:
  store i1 false, ptr %l45, !tbaa !21
  br label %bb31
bb30:
  %t71 = load i1, ptr %l49, !tbaa !21
  store i1 %t71, ptr %l45, !tbaa !21
  br label %bb31
bb31:
  %t72 = load i1, ptr %l45, !tbaa !21
  br i1 %t72, label %bb32, label %bb33
bb32:
  %t73 = load ptr, ptr %l1, !tbaa !29
  %t75 = getelementptr %"compiler/typed:If", ptr %t73, i32 0, i32 2
  %t76 = load ptr, ptr %t75, !tbaa !29
  %t78 = call i1 @compiler_2fcheck_2eleavesBlock(ptr %v0, ptr %t76)
  store i1 %t78, ptr %l53
  br label %bb34
bb33:
  store i1 false, ptr %l50, !tbaa !21
  br label %bb35
bb34:
  %t79 = load i1, ptr %l53, !tbaa !21
  store i1 %t79, ptr %l50, !tbaa !21
  br label %bb35
bb35:
  %t80 = load i1, ptr %l50, !tbaa !21
  store i1 %t80, ptr %rv
  br label %ret
bb36:
  %t81 = load ptr, ptr %l0, !tbaa !29
  store ptr %t81, ptr %l54, !tbaa !29
  store i1 false, ptr %l55, !tbaa !21
  %t82 = load ptr, ptr %l54, !tbaa !29
  %t83 = icmp ne ptr %t82, null
  br i1 %t83, label %bb37, label %bb38
bb37:
  %t85 = load ptr, ptr %l54, !tbaa !29
  %t86 = load i64, ptr %t85, !range !{i64 0, i64 17}
  %t88 = icmp eq i64 %t86, 11
  store i1 %t88, ptr %l55, !tbaa !21
  br label %bb38
bb38:
  %t89 = load i1, ptr %l55, !tbaa !21
  br i1 %t89, label %bb39, label %bb40
bb39:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr { i64, [3 x i64] }, ptr %t90, i32 0, i32 1
  %t93 = getelementptr { %"compiler/source:Span", ptr }, ptr %t92, i32 0, i32 1
  %t94 = load ptr, ptr %t93
  store ptr %t94, ptr %l2, !tbaa !29
  br label %bb41
bb40:
  br label %bb43
bb41:
  %t96 = load ptr, ptr %l2, !tbaa !29
  %t99 = call i1 @compiler_2fcheck_2eleavesBlock(ptr %v0, ptr %t96)
  store i1 %t99, ptr %l62
  br label %bb42
bb42:
  %t100 = load i1, ptr %l62, !tbaa !21
  store i1 %t100, ptr %rv
  br label %ret
bb43:
  %t101 = load ptr, ptr %l0, !tbaa !29
  store ptr %t101, ptr %l63, !tbaa !29
  store i1 false, ptr %l64, !tbaa !21
  %t102 = load ptr, ptr %l63, !tbaa !29
  %t103 = icmp ne ptr %t102, null
  br i1 %t103, label %bb44, label %bb45
bb44:
  %t105 = load ptr, ptr %l63, !tbaa !29
  %t106 = load i64, ptr %t105, !range !{i64 0, i64 17}
  %t108 = icmp eq i64 %t106, 13
  store i1 %t108, ptr %l64, !tbaa !21
  br label %bb45
bb45:
  %t109 = load i1, ptr %l64, !tbaa !21
  br i1 %t109, label %bb46, label %bb47
bb46:
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = getelementptr { i64, [3 x i64] }, ptr %t110, i32 0, i32 1
  %t113 = getelementptr { %"compiler/source:Span", ptr }, ptr %t112, i32 0, i32 1
  %t114 = load ptr, ptr %t113
  store ptr %t114, ptr %l3, !tbaa !29
  br label %bb48
bb47:
  br label %bb63
bb48:
  %t116 = load ptr, ptr %l3, !tbaa !29
  %t118 = getelementptr %"compiler/typed:Join", ptr %t116, i32 0, i32 0
  %t119 = load ptr, ptr %t118, !tbaa !29
  %t122 = call i1 @compiler_2fcheck_2eleavesBlock(ptr %v0, ptr %t119)
  store i1 %t122, ptr %l72
  br label %bb49
bb49:
  %t123 = load i1, ptr %l72, !tbaa !21
  %t124 = xor i1 %t123, true
  br i1 %t124, label %bb50, label %bb51
bb50:
  store i1 false, ptr %rv
  br label %ret
bb51:
  br label %bb52
bb52:
  %t127 = load ptr, ptr %l3, !tbaa !29
  %t129 = getelementptr %"compiler/typed:Join", ptr %t127, i32 0, i32 2
  %t130 = load { i64, ptr }, ptr %t129, !tbaa !27
  store { i64, ptr } %t130, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t132 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t134 = extractvalue { i64, ptr } %t132, 0
  store i64 %t134, ptr %l6, !tbaa !24
  br label %bb53
bb53:
  %t136 = load i64, ptr %l5, !tbaa !24
  %t137 = load i64, ptr %l6, !tbaa !24
  %t140 = icmp slt i64 %t136, %t137
  %t142 = xor i1 %t140, true
  br i1 %t142, label %bb54, label %bb55
bb54:
  br label %bb62
bb55:
  br label %bb56
bb56:
  %t144 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t144, ptr %l83, !tbaa !27
  %t145 = load i64, ptr %l5, !tbaa !24
  %t147 = getelementptr { i64, ptr }, ptr %l83, i32 0, i32 1
  %t148 = load ptr, ptr %t147, !tbaa !27
  %t149 = getelementptr ptr, ptr %t148, i64 %t145
  %t150 = load ptr, ptr %t149, !tbaa !39
  %t154 = getelementptr %"compiler/typed:Clause", ptr %t150, i32 0, i32 3
  %t155 = load ptr, ptr %t154, !tbaa !29
  %t157 = call i1 @compiler_2fcheck_2eleavesBlock(ptr %v0, ptr %t155)
  store i1 %t157, ptr %l88
  br label %bb57
bb57:
  %t158 = load i1, ptr %l88, !tbaa !21
  %t159 = xor i1 %t158, true
  br i1 %t159, label %bb58, label %bb59
bb58:
  store i1 false, ptr %rv
  br label %ret
bb59:
  br label %bb60
bb60:
  br label %bb61
bb61:
  %t162 = load i64, ptr %l5, !tbaa !24
  %t164 = add i64 %t162, 1
  store i64 %t164, ptr %l5, !tbaa !24
  br label %bb53
bb62:
  store i1 true, ptr %rv
  br label %ret
bb63:
  %t167 = load ptr, ptr %l0, !tbaa !29
  store ptr %t167, ptr %l94, !tbaa !29
  store i1 false, ptr %l95, !tbaa !21
  %t168 = load ptr, ptr %l94, !tbaa !29
  %t169 = icmp ne ptr %t168, null
  br i1 %t169, label %bb64, label %bb65
bb64:
  %t171 = load ptr, ptr %l94, !tbaa !29
  %t172 = load i64, ptr %t171, !range !{i64 0, i64 17}
  %t174 = icmp eq i64 %t172, 4
  store i1 %t174, ptr %l95, !tbaa !21
  br label %bb65
bb65:
  %t175 = load i1, ptr %l95, !tbaa !21
  br i1 %t175, label %bb66, label %bb67
bb66:
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t178 = getelementptr { i64, [3 x i64] }, ptr %t176, i32 0, i32 1
  %t179 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t178, i32 0, i32 1
  %t180 = load ptr, ptr %t179
  store ptr %t180, ptr %l8, !tbaa !29
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t184 = getelementptr { i64, [3 x i64] }, ptr %t182, i32 0, i32 1
  %t185 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t184, i32 0, i32 2
  %t186 = load ptr, ptr %t185
  store ptr %t186, ptr %l9, !tbaa !29
  br label %bb68
bb67:
  br label %bb74
bb68:
  %t188 = load ptr, ptr %l8, !tbaa !29
  %t190 = load ptr, ptr %l8, !tbaa !29
  %t192 = getelementptr %"compiler/typed:Block", ptr %t190, i32 0, i32 0
  %t193 = load i32, ptr %t192, !tbaa !23
  %t196 = call i1 @compiler_2ftyped_2eBreaksOut(ptr %v0, ptr %t188, i32 %t193)
  store i1 %t196, ptr %l106
  br label %bb69
bb69:
  %t197 = load i1, ptr %l106, !tbaa !21
  %t198 = xor i1 %t197, true
  br i1 %t198, label %bb70, label %bb71
bb70:
  %t200 = load ptr, ptr %l9, !tbaa !29
  %t201 = load ptr, ptr %l8, !tbaa !29
  %t203 = getelementptr %"compiler/typed:Block", ptr %t201, i32 0, i32 0
  %t204 = load i32, ptr %t203, !tbaa !23
  %t207 = call i1 @compiler_2ftyped_2eBreaksOut(ptr %v0, ptr %t200, i32 %t204)
  store i1 %t207, ptr %l112
  br label %bb72
bb71:
  store i1 false, ptr %l108, !tbaa !21
  br label %bb73
bb72:
  %t208 = load i1, ptr %l112, !tbaa !21
  %t209 = xor i1 %t208, true
  store i1 %t209, ptr %l108, !tbaa !21
  br label %bb73
bb73:
  %t211 = load i1, ptr %l108, !tbaa !21
  store i1 %t211, ptr %rv
  br label %ret
bb74:
  %t212 = load ptr, ptr %l0, !tbaa !29
  store ptr %t212, ptr %l114, !tbaa !29
  store i1 false, ptr %l115, !tbaa !21
  %t213 = load ptr, ptr %l114, !tbaa !29
  %t214 = icmp ne ptr %t213, null
  br i1 %t214, label %bb75, label %bb76
bb75:
  %t216 = load ptr, ptr %l114, !tbaa !29
  %t217 = load i64, ptr %t216, !range !{i64 0, i64 17}
  %t219 = icmp eq i64 %t217, 2
  store i1 %t219, ptr %l115, !tbaa !21
  br label %bb76
bb76:
  %t220 = load i1, ptr %l115, !tbaa !21
  br i1 %t220, label %bb77, label %bb78
bb77:
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t223 = getelementptr { i64, [3 x i64] }, ptr %t221, i32 0, i32 1
  %t224 = getelementptr { %"compiler/source:Span", ptr }, ptr %t223, i32 0, i32 1
  %t225 = load ptr, ptr %t224
  store ptr %t225, ptr %l10, !tbaa !29
  br label %bb79
bb78:
  br label %bb108
bb79:
  %t227 = load ptr, ptr %l10, !tbaa !29
  %t230 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t227)
  store i32 %t230, ptr %l122
  br label %bb80
bb80:
  %t231 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t232 = load i32, ptr %l122, !tbaa !23
  %t234 = icmp eq i32 %t232, %t231
  br i1 %t234, label %bb81, label %bb82
bb81:
  store i1 true, ptr %rv
  br label %ret
bb82:
  br label %bb83
bb83:
  %t237 = load ptr, ptr %l10, !tbaa !29
  store ptr %t237, ptr %l126, !tbaa !29
  store i1 false, ptr %l127, !tbaa !21
  %t238 = load ptr, ptr %l126, !tbaa !29
  %t239 = icmp ne ptr %t238, null
  br i1 %t239, label %bb84, label %bb85
bb84:
  %t241 = load ptr, ptr %l126, !tbaa !29
  %t242 = load i64, ptr %t241, !range !{i64 0, i64 18}
  %t244 = icmp eq i64 %t242, 13
  store i1 %t244, ptr %l127, !tbaa !21
  br label %bb85
bb85:
  %t245 = load i1, ptr %l127, !tbaa !21
  br i1 %t245, label %bb86, label %bb87
bb86:
  %t246 = load ptr, ptr %l10, !tbaa !29
  %t248 = getelementptr { i64, [5 x i64] }, ptr %t246, i32 0, i32 1
  %t249 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t248, i32 0, i32 2
  %t250 = load ptr, ptr %t249
  store ptr %t250, ptr %l11, !tbaa !29
  br label %bb88
bb87:
  br label %bb103
bb88:
  %t252 = load ptr, ptr %l11, !tbaa !29
  %t254 = getelementptr %"compiler/typed:Match", ptr %t252, i32 0, i32 1
  %t255 = load { i64, ptr }, ptr %t254, !tbaa !27
  store { i64, ptr } %t255, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t257 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t259 = extractvalue { i64, ptr } %t257, 0
  store i64 %t259, ptr %l14, !tbaa !24
  br label %bb89
bb89:
  %t261 = load i64, ptr %l13, !tbaa !24
  %t262 = load i64, ptr %l14, !tbaa !24
  %t265 = icmp slt i64 %t261, %t262
  %t267 = xor i1 %t265, true
  br i1 %t267, label %bb90, label %bb91
bb90:
  br label %bb98
bb91:
  br label %bb92
bb92:
  %t269 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t269, ptr %l140, !tbaa !27
  %t270 = load i64, ptr %l13, !tbaa !24
  %t272 = getelementptr { i64, ptr }, ptr %l140, i32 0, i32 1
  %t273 = load ptr, ptr %t272, !tbaa !27
  %t274 = getelementptr ptr, ptr %t273, i64 %t270
  %t275 = load ptr, ptr %t274, !tbaa !39
  %t279 = getelementptr %"compiler/typed:Arm", ptr %t275, i32 0, i32 3
  %t280 = load ptr, ptr %t279, !tbaa !29
  %t282 = call i1 @compiler_2fcheck_2eleavesBlock(ptr %v0, ptr %t280)
  store i1 %t282, ptr %l145
  br label %bb93
bb93:
  %t283 = load i1, ptr %l145, !tbaa !21
  %t284 = xor i1 %t283, true
  br i1 %t284, label %bb94, label %bb95
bb94:
  store i1 false, ptr %rv
  br label %ret
bb95:
  br label %bb96
bb96:
  br label %bb97
bb97:
  %t287 = load i64, ptr %l13, !tbaa !24
  %t289 = add i64 %t287, 1
  store i64 %t289, ptr %l13, !tbaa !24
  br label %bb89
bb98:
  %t291 = load ptr, ptr %l11, !tbaa !29
  %t293 = getelementptr %"compiler/typed:Match", ptr %t291, i32 0, i32 2
  %t294 = load ptr, ptr %t293, !tbaa !29
  %t296 = icmp eq ptr %t294, null
  br i1 %t296, label %bb99, label %bb100
bb99:
  call void @__olang_check_failed(ptr @olang_loc_eb3e4e8f3f96f0ec_5bc3fc9686c42b70)
  unreachable
bb100:
  br label %bb101
bb101:
  %t298 = load ptr, ptr %l11, !tbaa !29
  %t300 = getelementptr %"compiler/typed:Match", ptr %t298, i32 0, i32 2
  %t301 = load ptr, ptr %t300, !tbaa !29
  %t304 = getelementptr %"compiler/typed:Arm", ptr %t301, i32 0, i32 3
  %t305 = load ptr, ptr %t304, !tbaa !29
  %t307 = call i1 @compiler_2fcheck_2eleavesBlock(ptr %v0, ptr %t305)
  store i1 %t307, ptr %l157
  br label %bb102
bb102:
  %t308 = load i1, ptr %l157, !tbaa !21
  store i1 %t308, ptr %rv
  br label %ret
bb103:
  br i1 true, label %bb104, label %bb105
bb104:
  br label %bb106
bb105:
  br label %bb107
bb106:
  store i1 false, ptr %rv
  br label %ret
bb107:
  call void @__olang_check_failed(ptr @olang_loc_bad8a01556e87002_6e42cd1773855696)
  unreachable
bb108:
  br i1 true, label %bb109, label %bb110
bb109:
  br label %bb111
bb110:
  br label %bb112
bb111:
  store i1 false, ptr %rv
  br label %ret
bb112:
  call void @__olang_check_failed(ptr @olang_loc_3862db6440158079_51a5529566dfad)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2epatTail(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1, i64 %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l20 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l32 = alloca { i64, ptr }
  %l43 = alloca i64
  %l46 = alloca i64
  %l64 = alloca ptr
  %l65 = alloca { i64, ptr }
  %l67 = alloca %"compiler/source:Span"
  %l77 = alloca i64
  %l80 = alloca i64
  %l99 = alloca { i64, ptr }
  %l105 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  %t97 = alloca { i64, [4 x i64] }, align 8
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPattern_26_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l20
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l20
  %t3 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %t3
  store ptr %t3, ptr %l3, !tbaa !29
  %t5 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t9 = icmp sgt i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t13 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  store i64 %t15, ptr %l6, !tbaa !24
  br label %bb4
bb3:
  store i64 0, ptr %l8, !tbaa !24
  store i64 %a2, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t19 = load i64, ptr %l9, !tbaa !24
  %t20 = load i64, ptr %l8, !tbaa !24
  %t23 = icmp sgt i64 %t19, %t20
  br i1 %t23, label %bb11, label %bb12
bb4:
  %t25 = load i64, ptr %l5, !tbaa !24
  %t26 = load i64, ptr %l6, !tbaa !24
  %t29 = icmp slt i64 %t25, %t26
  %t31 = xor i1 %t29, true
  br i1 %t31, label %bb5, label %bb6
bb5:
  br label %bb10
bb6:
  br label %bb7
bb7:
  %t33 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t33, ptr %l32, !tbaa !27
  %t34 = load i64, ptr %l5, !tbaa !24
  %t36 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr ptr, ptr %t37, i64 %t34
  %t39 = load ptr, ptr %t38, !tbaa !39
  %t41 = load ptr, ptr %l3, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPattern_26_3e_2ePush_3ccompiler_2fast_3aPattern_26_3e(ptr %v2, ptr %v1, ptr %t41, ptr %t39)
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t45 = load i64, ptr %l5, !tbaa !24
  %t47 = add i64 %t45, 1
  store i64 %t47, ptr %l5, !tbaa !24
  br label %bb4
bb10:
  br label %bb25
bb11:
  %t49 = load i64, ptr %l10, !tbaa !24
  %t51 = icmp sgt i64 %t49, 0
  br i1 %t51, label %bb13, label %bb14
bb12:
  store i64 0, ptr %l43, !tbaa !24
  br label %bb16
bb13:
  %t53 = load i64, ptr %l9, !tbaa !24
  %t54 = load i64, ptr %l8, !tbaa !24
  %t57 = sub i64 %t53, %t54
  %t58 = load i64, ptr %l10, !tbaa !24
  %t61 = add i64 %t57, %t58
  %t63 = sub i64 %t61, 1
  %t64 = load i64, ptr %l10, !tbaa !24
  %t67 = sdiv i64 %t63, %t64
  store i64 %t67, ptr %l46, !tbaa !24
  br label %bb15
bb14:
  store i64 0, ptr %l46, !tbaa !24
  br label %bb15
bb15:
  %t69 = load i64, ptr %l46, !tbaa !24
  store i64 %t69, ptr %l43, !tbaa !24
  br label %bb16
bb16:
  %t70 = load i64, ptr %l43, !tbaa !24
  store i64 %t70, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb17
bb17:
  %t71 = load i64, ptr %l12, !tbaa !24
  %t72 = load i64, ptr %l11, !tbaa !24
  %t75 = icmp slt i64 %t71, %t72
  %t77 = xor i1 %t75, true
  br i1 %t77, label %bb18, label %bb19
bb18:
  br label %bb24
bb19:
  br label %bb20
bb20:
  %t79 = load i64, ptr %l8, !tbaa !24
  %t80 = load i64, ptr %l12, !tbaa !24
  %t81 = load i64, ptr %l10, !tbaa !24
  %t84 = mul i64 %t80, %t81
  %t87 = add i64 %t79, %t84
  store i64 %t87, ptr %l13, !tbaa !24
  %t89 = load ptr, ptr %l3, !tbaa !29
  store ptr %t89, ptr %l64, !tbaa !29
  %t90 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t90, ptr %l65, !tbaa !27
  %t91 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !27
  %t93 = getelementptr ptr, ptr %t92, i64 0
  %t94 = load ptr, ptr %t93, !tbaa !39
  %t96 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aPattern_2eSpan(ptr %v0, ptr %t94)
  store %"compiler/source:Span" %t96, ptr %l67
  br label %bb21
bb21:
  store { i64, [4 x i64] } zeroinitializer, ptr %t97
  %t98 = getelementptr { i64, [4 x i64] }, ptr %t97, i32 0, i32 0
  store i64 0, ptr %t98
  %t99 = load %"compiler/source:Span", ptr %l67
  %t100 = insertvalue { %"compiler/source:Span" } undef, %"compiler/source:Span" %t99, 0
  %t101 = getelementptr { i64, [4 x i64] }, ptr %t97, i32 0, i32 1
  store { %"compiler/source:Span" } %t100, ptr %t101
  %t102 = load { i64, [4 x i64] }, ptr %t97
  %t104 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 40, i64 8)
  store { i64, [4 x i64] } %t102, ptr %t104
  %t105 = load ptr, ptr %l64, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPattern_26_3e_2ePush_3ccompiler_2fast_3aPattern_26_3e(ptr %v2, ptr %v2, ptr %t105, ptr %t104)
  br label %bb22
bb22:
  br label %bb23
bb23:
  %t107 = load i64, ptr %l12, !tbaa !24
  %t109 = add i64 %t107, 1
  store i64 %t109, ptr %l12, !tbaa !24
  br label %bb17
bb24:
  br label %bb25
bb25:
  store i64 1, ptr %l14, !tbaa !24
  %t111 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t113 = extractvalue { i64, ptr } %t111, 0
  store i64 %t113, ptr %l15, !tbaa !24
  store i64 1, ptr %l16, !tbaa !24
  %t115 = load i64, ptr %l15, !tbaa !24
  %t116 = load i64, ptr %l14, !tbaa !24
  %t119 = icmp sgt i64 %t115, %t116
  br i1 %t119, label %bb26, label %bb27
bb26:
  %t121 = load i64, ptr %l16, !tbaa !24
  %t123 = icmp sgt i64 %t121, 0
  br i1 %t123, label %bb28, label %bb29
bb27:
  store i64 0, ptr %l77, !tbaa !24
  br label %bb31
bb28:
  %t125 = load i64, ptr %l15, !tbaa !24
  %t126 = load i64, ptr %l14, !tbaa !24
  %t129 = sub i64 %t125, %t126
  %t130 = load i64, ptr %l16, !tbaa !24
  %t133 = add i64 %t129, %t130
  %t135 = sub i64 %t133, 1
  %t136 = load i64, ptr %l16, !tbaa !24
  %t139 = sdiv i64 %t135, %t136
  store i64 %t139, ptr %l80, !tbaa !24
  br label %bb30
bb29:
  store i64 0, ptr %l80, !tbaa !24
  br label %bb30
bb30:
  %t141 = load i64, ptr %l80, !tbaa !24
  store i64 %t141, ptr %l77, !tbaa !24
  br label %bb31
bb31:
  %t142 = load i64, ptr %l77, !tbaa !24
  store i64 %t142, ptr %l17, !tbaa !24
  store i64 0, ptr %l18, !tbaa !24
  br label %bb32
bb32:
  %t143 = load i64, ptr %l18, !tbaa !24
  %t144 = load i64, ptr %l17, !tbaa !24
  %t147 = icmp slt i64 %t143, %t144
  %t149 = xor i1 %t147, true
  br i1 %t149, label %bb33, label %bb34
bb33:
  br label %bb38
bb34:
  br label %bb35
bb35:
  %t151 = load i64, ptr %l14, !tbaa !24
  %t152 = load i64, ptr %l18, !tbaa !24
  %t153 = load i64, ptr %l16, !tbaa !24
  %t156 = mul i64 %t152, %t153
  %t159 = add i64 %t151, %t156
  %t161 = load ptr, ptr %l3, !tbaa !29
  %t162 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t162, ptr %l99, !tbaa !27
  %t165 = getelementptr { i64, ptr }, ptr %l99, i32 0, i32 1
  %t166 = load ptr, ptr %t165, !tbaa !27
  %t167 = getelementptr ptr, ptr %t166, i64 %t159
  %t168 = load ptr, ptr %t167, !tbaa !39
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPattern_26_3e_2ePush_3ccompiler_2fast_3aPattern_26_3e(ptr %v2, ptr %v0, ptr %t161, ptr %t168)
  br label %bb36
bb36:
  br label %bb37
bb37:
  %t171 = load i64, ptr %l18, !tbaa !24
  %t173 = add i64 %t171, 1
  store i64 %t173, ptr %l18, !tbaa !24
  br label %bb32
bb38:
  %t175 = load ptr, ptr %l3, !tbaa !29
  %t177 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPattern_26_3e_2eToArr_H3d785ef7fade1f29078b6e80f1d617ba(ptr %v2, ptr %v2, ptr %t175)
  store { i64, ptr } %t177, ptr %l105
  br label %bb39
bb39:
  %t178 = load { i64, ptr }, ptr %l105, !tbaa !27
  store { i64, ptr } %t178, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fcheck_2estmtLike(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i1
  %l4 = alloca ptr
  %l5 = alloca i1
  %l8 = alloca ptr
  %l9 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i1
  %l23 = alloca i1
  %l24 = alloca ptr
  %l25 = alloca i1
  %l32 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 30}
  %t8 = icmp eq i64 %t6, 12
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb13
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t11 = load ptr, ptr %l8, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb5, label %bb6
bb5:
  %t14 = load ptr, ptr %l8, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 30}
  %t17 = icmp eq i64 %t15, 21
  store i1 %t17, ptr %l9, !tbaa !21
  br label %bb6
bb6:
  %t18 = load i1, ptr %l9, !tbaa !21
  br i1 %t18, label %bb7, label %bb8
bb7:
  br label %bb13
bb8:
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t20 = load ptr, ptr %l12, !tbaa !29
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %bb9, label %bb10
bb9:
  %t23 = load ptr, ptr %l12, !tbaa !29
  %t24 = load i64, ptr %t23, !range !{i64 0, i64 30}
  %t26 = icmp eq i64 %t24, 4
  store i1 %t26, ptr %l13, !tbaa !21
  br label %bb10
bb10:
  %t27 = load i1, ptr %l13, !tbaa !21
  br i1 %t27, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb35
bb14:
  %t28 = load ptr, ptr %l0, !tbaa !29
  store ptr %t28, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t29 = load ptr, ptr %l16, !tbaa !29
  %t30 = icmp ne ptr %t29, null
  br i1 %t30, label %bb15, label %bb16
bb15:
  %t32 = load ptr, ptr %l16, !tbaa !29
  %t33 = load i64, ptr %t32, !range !{i64 0, i64 30}
  %t35 = icmp eq i64 %t33, 2
  store i1 %t35, ptr %l17, !tbaa !21
  br label %bb16
bb16:
  %t36 = load i1, ptr %l17, !tbaa !21
  br i1 %t36, label %bb17, label %bb18
bb17:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr { i64, [4 x i64] }, ptr %t37, i32 0, i32 1
  %t40 = getelementptr { %"compiler/source:Span", ptr }, ptr %t39, i32 0, i32 1
  %t41 = load ptr, ptr %t40
  store ptr %t41, ptr %l1, !tbaa !29
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t43 = load ptr, ptr %l1, !tbaa !29
  %t45 = call i1 @compiler_2fcheck_2estmtLike(ptr %v0, ptr %t43)
  store i1 %t45, ptr %l23
  br label %bb20
bb20:
  %t46 = load i1, ptr %l23, !tbaa !21
  store i1 %t46, ptr %l3, !tbaa !21
  br label %bb35
bb21:
  %t47 = load ptr, ptr %l0, !tbaa !29
  store ptr %t47, ptr %l24, !tbaa !29
  store i1 false, ptr %l25, !tbaa !21
  %t48 = load ptr, ptr %l24, !tbaa !29
  %t49 = icmp ne ptr %t48, null
  br i1 %t49, label %bb22, label %bb23
bb22:
  %t51 = load ptr, ptr %l24, !tbaa !29
  %t52 = load i64, ptr %t51, !range !{i64 0, i64 30}
  %t54 = icmp eq i64 %t52, 3
  store i1 %t54, ptr %l25, !tbaa !21
  br label %bb23
bb23:
  %t55 = load i1, ptr %l25, !tbaa !21
  br i1 %t55, label %bb24, label %bb25
bb24:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr { i64, [4 x i64] }, ptr %t56, i32 0, i32 1
  %t59 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t58, i32 0, i32 1
  %t60 = load i32, ptr %t59, !range !{i32 0, i32 98}
  store i32 %t60, ptr %l2
  br label %bb26
bb25:
  br label %bb30
bb26:
  %t62 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t64 = trunc i64 76 to i32
  %t65 = icmp eq i32 %t62, %t64
  br i1 %t65, label %bb27, label %bb28
bb27:
  store i1 true, ptr %l32, !tbaa !21
  br label %bb29
bb28:
  %t67 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t69 = trunc i64 77 to i32
  %t70 = icmp eq i32 %t67, %t69
  store i1 %t70, ptr %l32, !tbaa !21
  br label %bb29
bb29:
  %t72 = load i1, ptr %l32, !tbaa !21
  store i1 %t72, ptr %l3, !tbaa !21
  br label %bb35
bb30:
  br i1 true, label %bb31, label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb34
bb33:
  store i1 false, ptr %l3, !tbaa !21
  br label %bb35
bb34:
  call void @__olang_check_failed(ptr @olang_loc_d195b38137e2d30_7d67c1d5e7f3802c)
  unreachable
bb35:
  %t73 = load i1, ptr %l3, !tbaa !21
  store i1 %t73, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l17 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l19 = alloca ptr
  %l20 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca i1
  %l29 = alloca ptr
  %l30 = alloca i1
  %l35 = alloca ptr
  %l36 = alloca i1
  %l41 = alloca ptr
  %l42 = alloca i1
  %l47 = alloca ptr
  %l48 = alloca i1
  %l53 = alloca ptr
  %l54 = alloca i1
  %l62 = alloca ptr
  %l63 = alloca i1
  %l70 = alloca ptr
  %l71 = alloca i1
  %l76 = alloca ptr
  %l77 = alloca i1
  %l82 = alloca ptr
  %l83 = alloca i1
  %l91 = alloca ptr
  %l92 = alloca i1
  %l99 = alloca ptr
  %l100 = alloca i1
  %l107 = alloca ptr
  %l108 = alloca i1
  %l121 = alloca ptr
  %l122 = alloca i1
  %l140 = alloca ptr
  %l141 = alloca i1
  %l149 = alloca ptr
  %l150 = alloca i1
  %l157 = alloca ptr
  %l158 = alloca i1
  %l170 = alloca ptr
  %l171 = alloca i1
  %l187 = alloca ptr
  %l188 = alloca i1
  %l193 = alloca ptr
  %l194 = alloca i1
  %l199 = alloca ptr
  %l200 = alloca i1
  %l205 = alloca ptr
  %l206 = alloca i1
  %l211 = alloca ptr
  %l212 = alloca i1
  %l219 = alloca ptr
  %l220 = alloca i1
  %l232 = alloca ptr
  %l233 = alloca i1
  %l240 = alloca ptr
  %l241 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l0, !tbaa !29
  store ptr %t5, ptr %l23, !tbaa !29
  store i1 false, ptr %l24, !tbaa !21
  %t6 = load ptr, ptr %l23, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l23, !tbaa !29
  %t10 = load i64, ptr %t9, !range !{i64 0, i64 30}
  %t12 = icmp eq i64 %t10, 2
  store i1 %t12, ptr %l24, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l24, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr { i64, [4 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", ptr }, ptr %t16, i32 0, i32 1
  %t18 = load ptr, ptr %t17
  store ptr %t18, ptr %l2, !tbaa !29
  br label %bb28
bb7:
  %t20 = load ptr, ptr %l0, !tbaa !29
  store ptr %t20, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t21 = load ptr, ptr %l29, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %bb8, label %bb9
bb8:
  %t24 = load ptr, ptr %l29, !tbaa !29
  %t25 = load i64, ptr %t24, !range !{i64 0, i64 30}
  %t27 = icmp eq i64 %t25, 26
  store i1 %t27, ptr %l30, !tbaa !21
  br label %bb9
bb9:
  %t28 = load i1, ptr %l30, !tbaa !21
  br i1 %t28, label %bb10, label %bb11
bb10:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr { i64, [4 x i64] }, ptr %t29, i32 0, i32 1
  %t32 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t31, i32 0, i32 2
  %t33 = load ptr, ptr %t32
  store ptr %t33, ptr %l2, !tbaa !29
  br label %bb28
bb11:
  %t35 = load ptr, ptr %l0, !tbaa !29
  store ptr %t35, ptr %l35, !tbaa !29
  store i1 false, ptr %l36, !tbaa !21
  %t36 = load ptr, ptr %l35, !tbaa !29
  %t37 = icmp ne ptr %t36, null
  br i1 %t37, label %bb12, label %bb13
bb12:
  %t39 = load ptr, ptr %l35, !tbaa !29
  %t40 = load i64, ptr %t39, !range !{i64 0, i64 30}
  %t42 = icmp eq i64 %t40, 28
  store i1 %t42, ptr %l36, !tbaa !21
  br label %bb13
bb13:
  %t43 = load i1, ptr %l36, !tbaa !21
  br i1 %t43, label %bb14, label %bb15
bb14:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr { i64, [4 x i64] }, ptr %t44, i32 0, i32 1
  %t47 = getelementptr { %"compiler/source:Span", ptr }, ptr %t46, i32 0, i32 1
  %t48 = load ptr, ptr %t47
  store ptr %t48, ptr %l2, !tbaa !29
  br label %bb28
bb15:
  %t50 = load ptr, ptr %l0, !tbaa !29
  store ptr %t50, ptr %l41, !tbaa !29
  store i1 false, ptr %l42, !tbaa !21
  %t51 = load ptr, ptr %l41, !tbaa !29
  %t52 = icmp ne ptr %t51, null
  br i1 %t52, label %bb16, label %bb17
bb16:
  %t54 = load ptr, ptr %l41, !tbaa !29
  %t55 = load i64, ptr %t54, !range !{i64 0, i64 30}
  %t57 = icmp eq i64 %t55, 3
  store i1 %t57, ptr %l42, !tbaa !21
  br label %bb17
bb17:
  %t58 = load i1, ptr %l42, !tbaa !21
  br i1 %t58, label %bb18, label %bb19
bb18:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr { i64, [4 x i64] }, ptr %t59, i32 0, i32 1
  %t62 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t61, i32 0, i32 2
  %t63 = load ptr, ptr %t62
  store ptr %t63, ptr %l2, !tbaa !29
  br label %bb28
bb19:
  %t65 = load ptr, ptr %l0, !tbaa !29
  store ptr %t65, ptr %l47, !tbaa !29
  store i1 false, ptr %l48, !tbaa !21
  %t66 = load ptr, ptr %l47, !tbaa !29
  %t67 = icmp ne ptr %t66, null
  br i1 %t67, label %bb20, label %bb21
bb20:
  %t69 = load ptr, ptr %l47, !tbaa !29
  %t70 = load i64, ptr %t69, !range !{i64 0, i64 30}
  %t72 = icmp eq i64 %t70, 4
  store i1 %t72, ptr %l48, !tbaa !21
  br label %bb21
bb21:
  %t73 = load i1, ptr %l48, !tbaa !21
  br i1 %t73, label %bb22, label %bb23
bb22:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr { i64, [4 x i64] }, ptr %t74, i32 0, i32 1
  %t77 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t76, i32 0, i32 2
  %t78 = load ptr, ptr %t77
  store ptr %t78, ptr %l2, !tbaa !29
  br label %bb28
bb23:
  %t80 = load ptr, ptr %l0, !tbaa !29
  store ptr %t80, ptr %l53, !tbaa !29
  store i1 false, ptr %l54, !tbaa !21
  %t81 = load ptr, ptr %l53, !tbaa !29
  %t82 = icmp ne ptr %t81, null
  br i1 %t82, label %bb24, label %bb25
bb24:
  %t84 = load ptr, ptr %l53, !tbaa !29
  %t85 = load i64, ptr %t84, !range !{i64 0, i64 30}
  %t87 = icmp eq i64 %t85, 14
  store i1 %t87, ptr %l54, !tbaa !21
  br label %bb25
bb25:
  %t88 = load i1, ptr %l54, !tbaa !21
  br i1 %t88, label %bb26, label %bb27
bb26:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr { i64, [4 x i64] }, ptr %t89, i32 0, i32 1
  %t92 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t91, i32 0, i32 1
  %t93 = load ptr, ptr %t92
  store ptr %t93, ptr %l2, !tbaa !29
  br label %bb28
bb27:
  br label %bb30
bb28:
  %t95 = load ptr, ptr %l2, !tbaa !29
  %t97 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t95, ptr %t97)
  br label %bb29
bb29:
  br label %bb157
bb30:
  %t100 = load ptr, ptr %l0, !tbaa !29
  store ptr %t100, ptr %l62, !tbaa !29
  store i1 false, ptr %l63, !tbaa !21
  %t101 = load ptr, ptr %l62, !tbaa !29
  %t102 = icmp ne ptr %t101, null
  br i1 %t102, label %bb31, label %bb32
bb31:
  %t104 = load ptr, ptr %l62, !tbaa !29
  %t105 = load i64, ptr %t104, !range !{i64 0, i64 30}
  %t107 = icmp eq i64 %t105, 27
  store i1 %t107, ptr %l63, !tbaa !21
  br label %bb32
bb32:
  %t108 = load i1, ptr %l63, !tbaa !21
  br i1 %t108, label %bb33, label %bb34
bb33:
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = getelementptr { i64, [4 x i64] }, ptr %t109, i32 0, i32 1
  %t112 = getelementptr { %"compiler/source:Span", ptr }, ptr %t111, i32 0, i32 1
  %t113 = load ptr, ptr %t112
  store ptr %t113, ptr %l3, !tbaa !29
  br label %bb35
bb34:
  br label %bb37
bb35:
  %t115 = load ptr, ptr %l3, !tbaa !29
  %t116 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t115, ptr %t116)
  br label %bb36
bb36:
  br label %bb157
bb37:
  %t119 = load ptr, ptr %l0, !tbaa !29
  store ptr %t119, ptr %l70, !tbaa !29
  store i1 false, ptr %l71, !tbaa !21
  %t120 = load ptr, ptr %l70, !tbaa !29
  %t121 = icmp ne ptr %t120, null
  br i1 %t121, label %bb38, label %bb39
bb38:
  %t123 = load ptr, ptr %l70, !tbaa !29
  %t124 = load i64, ptr %t123, !range !{i64 0, i64 30}
  %t126 = icmp eq i64 %t124, 9
  store i1 %t126, ptr %l71, !tbaa !21
  br label %bb39
bb39:
  %t127 = load i1, ptr %l71, !tbaa !21
  br i1 %t127, label %bb40, label %bb41
bb40:
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t130 = getelementptr { i64, [4 x i64] }, ptr %t128, i32 0, i32 1
  %t131 = getelementptr { %"compiler/source:Span", ptr, ptr, i1 }, ptr %t130, i32 0, i32 1
  %t132 = load ptr, ptr %t131
  store ptr %t132, ptr %l4, !tbaa !29
  br label %bb50
bb41:
  %t134 = load ptr, ptr %l0, !tbaa !29
  store ptr %t134, ptr %l76, !tbaa !29
  store i1 false, ptr %l77, !tbaa !21
  %t135 = load ptr, ptr %l76, !tbaa !29
  %t136 = icmp ne ptr %t135, null
  br i1 %t136, label %bb42, label %bb43
bb42:
  %t138 = load ptr, ptr %l76, !tbaa !29
  %t139 = load i64, ptr %t138, !range !{i64 0, i64 30}
  %t141 = icmp eq i64 %t139, 11
  store i1 %t141, ptr %l77, !tbaa !21
  br label %bb43
bb43:
  %t142 = load i1, ptr %l77, !tbaa !21
  br i1 %t142, label %bb44, label %bb45
bb44:
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t145 = getelementptr { i64, [4 x i64] }, ptr %t143, i32 0, i32 1
  %t146 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t145, i32 0, i32 1
  %t147 = load ptr, ptr %t146
  store ptr %t147, ptr %l4, !tbaa !29
  br label %bb50
bb45:
  %t149 = load ptr, ptr %l0, !tbaa !29
  store ptr %t149, ptr %l82, !tbaa !29
  store i1 false, ptr %l83, !tbaa !21
  %t150 = load ptr, ptr %l82, !tbaa !29
  %t151 = icmp ne ptr %t150, null
  br i1 %t151, label %bb46, label %bb47
bb46:
  %t153 = load ptr, ptr %l82, !tbaa !29
  %t154 = load i64, ptr %t153, !range !{i64 0, i64 30}
  %t156 = icmp eq i64 %t154, 13
  store i1 %t156, ptr %l83, !tbaa !21
  br label %bb47
bb47:
  %t157 = load i1, ptr %l83, !tbaa !21
  br i1 %t157, label %bb48, label %bb49
bb48:
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t160 = getelementptr { i64, [4 x i64] }, ptr %t158, i32 0, i32 1
  %t161 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t160, i32 0, i32 1
  %t162 = load ptr, ptr %t161
  store ptr %t162, ptr %l4, !tbaa !29
  br label %bb50
bb49:
  br label %bb52
bb50:
  %t164 = load ptr, ptr %l4, !tbaa !29
  %t166 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t164, ptr %t166)
  br label %bb51
bb51:
  br label %bb157
bb52:
  %t169 = load ptr, ptr %l0, !tbaa !29
  store ptr %t169, ptr %l91, !tbaa !29
  store i1 false, ptr %l92, !tbaa !21
  %t170 = load ptr, ptr %l91, !tbaa !29
  %t171 = icmp ne ptr %t170, null
  br i1 %t171, label %bb53, label %bb54
bb53:
  %t173 = load ptr, ptr %l91, !tbaa !29
  %t174 = load i64, ptr %t173, !range !{i64 0, i64 30}
  %t176 = icmp eq i64 %t174, 5
  store i1 %t176, ptr %l92, !tbaa !21
  br label %bb54
bb54:
  %t177 = load i1, ptr %l92, !tbaa !21
  br i1 %t177, label %bb55, label %bb56
bb55:
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t180 = getelementptr { i64, [4 x i64] }, ptr %t178, i32 0, i32 1
  %t181 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t180, i32 0, i32 2
  %t182 = load ptr, ptr %t181
  store ptr %t182, ptr %l5, !tbaa !29
  %t184 = load ptr, ptr %l0, !tbaa !29
  %t186 = getelementptr { i64, [4 x i64] }, ptr %t184, i32 0, i32 1
  %t187 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t186, i32 0, i32 3
  %t188 = load ptr, ptr %t187
  store ptr %t188, ptr %l6, !tbaa !29
  br label %bb65
bb56:
  %t190 = load ptr, ptr %l0, !tbaa !29
  store ptr %t190, ptr %l99, !tbaa !29
  store i1 false, ptr %l100, !tbaa !21
  %t191 = load ptr, ptr %l99, !tbaa !29
  %t192 = icmp ne ptr %t191, null
  br i1 %t192, label %bb57, label %bb58
bb57:
  %t194 = load ptr, ptr %l99, !tbaa !29
  %t195 = load i64, ptr %t194, !range !{i64 0, i64 30}
  %t197 = icmp eq i64 %t195, 6
  store i1 %t197, ptr %l100, !tbaa !21
  br label %bb58
bb58:
  %t198 = load i1, ptr %l100, !tbaa !21
  br i1 %t198, label %bb59, label %bb60
bb59:
  %t199 = load ptr, ptr %l0, !tbaa !29
  %t201 = getelementptr { i64, [4 x i64] }, ptr %t199, i32 0, i32 1
  %t202 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t201, i32 0, i32 1
  %t203 = load ptr, ptr %t202
  store ptr %t203, ptr %l5, !tbaa !29
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t207 = getelementptr { i64, [4 x i64] }, ptr %t205, i32 0, i32 1
  %t208 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t207, i32 0, i32 2
  %t209 = load ptr, ptr %t208
  store ptr %t209, ptr %l6, !tbaa !29
  br label %bb65
bb60:
  %t211 = load ptr, ptr %l0, !tbaa !29
  store ptr %t211, ptr %l107, !tbaa !29
  store i1 false, ptr %l108, !tbaa !21
  %t212 = load ptr, ptr %l107, !tbaa !29
  %t213 = icmp ne ptr %t212, null
  br i1 %t213, label %bb61, label %bb62
bb61:
  %t215 = load ptr, ptr %l107, !tbaa !29
  %t216 = load i64, ptr %t215, !range !{i64 0, i64 30}
  %t218 = icmp eq i64 %t216, 10
  store i1 %t218, ptr %l108, !tbaa !21
  br label %bb62
bb62:
  %t219 = load i1, ptr %l108, !tbaa !21
  br i1 %t219, label %bb63, label %bb64
bb63:
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t222 = getelementptr { i64, [4 x i64] }, ptr %t220, i32 0, i32 1
  %t223 = getelementptr { %"compiler/source:Span", ptr, ptr, i1 }, ptr %t222, i32 0, i32 1
  %t224 = load ptr, ptr %t223
  store ptr %t224, ptr %l5, !tbaa !29
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t228 = getelementptr { i64, [4 x i64] }, ptr %t226, i32 0, i32 1
  %t229 = getelementptr { %"compiler/source:Span", ptr, ptr, i1 }, ptr %t228, i32 0, i32 2
  %t230 = load ptr, ptr %t229
  store ptr %t230, ptr %l6, !tbaa !29
  br label %bb65
bb64:
  br label %bb68
bb65:
  %t232 = load ptr, ptr %l5, !tbaa !29
  %t234 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t232, ptr %t234)
  br label %bb66
bb66:
  %t237 = load ptr, ptr %l6, !tbaa !29
  %t239 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t237, ptr %t239)
  br label %bb67
bb67:
  br label %bb157
bb68:
  %t242 = load ptr, ptr %l0, !tbaa !29
  store ptr %t242, ptr %l121, !tbaa !29
  store i1 false, ptr %l122, !tbaa !21
  %t243 = load ptr, ptr %l121, !tbaa !29
  %t244 = icmp ne ptr %t243, null
  br i1 %t244, label %bb69, label %bb70
bb69:
  %t246 = load ptr, ptr %l121, !tbaa !29
  %t247 = load i64, ptr %t246, !range !{i64 0, i64 30}
  %t249 = icmp eq i64 %t247, 8
  store i1 %t249, ptr %l122, !tbaa !21
  br label %bb70
bb70:
  %t250 = load i1, ptr %l122, !tbaa !21
  br i1 %t250, label %bb71, label %bb72
bb71:
  %t251 = load ptr, ptr %l0, !tbaa !29
  %t253 = getelementptr { i64, [4 x i64] }, ptr %t251, i32 0, i32 1
  %t254 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t253, i32 0, i32 1
  %t255 = load ptr, ptr %t254
  store ptr %t255, ptr %l7, !tbaa !29
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t259 = getelementptr { i64, [4 x i64] }, ptr %t257, i32 0, i32 1
  %t260 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t259, i32 0, i32 2
  %t261 = load ptr, ptr %t260
  store ptr %t261, ptr %l8, !tbaa !29
  %t263 = load ptr, ptr %l0, !tbaa !29
  %t265 = getelementptr { i64, [4 x i64] }, ptr %t263, i32 0, i32 1
  %t266 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t265, i32 0, i32 3
  %t267 = load ptr, ptr %t266
  store ptr %t267, ptr %l9, !tbaa !29
  br label %bb73
bb72:
  br label %bb77
bb73:
  %t269 = load ptr, ptr %l7, !tbaa !29
  %t271 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t269, ptr %t271)
  br label %bb74
bb74:
  %t274 = load ptr, ptr %l8, !tbaa !29
  %t276 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t274, ptr %t276)
  br label %bb75
bb75:
  %t279 = load ptr, ptr %l9, !tbaa !29
  %t281 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t279, ptr %t281)
  br label %bb76
bb76:
  br label %bb157
bb77:
  %t284 = load ptr, ptr %l0, !tbaa !29
  store ptr %t284, ptr %l140, !tbaa !29
  store i1 false, ptr %l141, !tbaa !21
  %t285 = load ptr, ptr %l140, !tbaa !29
  %t286 = icmp ne ptr %t285, null
  br i1 %t286, label %bb78, label %bb79
bb78:
  %t288 = load ptr, ptr %l140, !tbaa !29
  %t289 = load i64, ptr %t288, !range !{i64 0, i64 30}
  %t291 = icmp eq i64 %t289, 7
  store i1 %t291, ptr %l141, !tbaa !21
  br label %bb79
bb79:
  %t292 = load i1, ptr %l141, !tbaa !21
  br i1 %t292, label %bb80, label %bb81
bb80:
  %t293 = load ptr, ptr %l0, !tbaa !29
  %t295 = getelementptr { i64, [4 x i64] }, ptr %t293, i32 0, i32 1
  %t296 = getelementptr { %"compiler/source:Span", ptr }, ptr %t295, i32 0, i32 1
  %t297 = load ptr, ptr %t296
  store ptr %t297, ptr %l10, !tbaa !29
  br label %bb82
bb81:
  br label %bb84
bb82:
  %t299 = load ptr, ptr %l10, !tbaa !29
  %t301 = getelementptr %"compiler/ast:Chain", ptr %t299, i32 0, i32 1
  %t302 = load { i64, ptr }, ptr %t301, !tbaa !27
  %t303 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExprs(ptr %v0, ptr %v1, { i64, ptr } %t302, ptr %t303)
  br label %bb83
bb83:
  br label %bb157
bb84:
  %t306 = load ptr, ptr %l0, !tbaa !29
  store ptr %t306, ptr %l149, !tbaa !29
  store i1 false, ptr %l150, !tbaa !21
  %t307 = load ptr, ptr %l149, !tbaa !29
  %t308 = icmp ne ptr %t307, null
  br i1 %t308, label %bb85, label %bb86
bb85:
  %t310 = load ptr, ptr %l149, !tbaa !29
  %t311 = load i64, ptr %t310, !range !{i64 0, i64 30}
  %t313 = icmp eq i64 %t311, 12
  store i1 %t313, ptr %l150, !tbaa !21
  br label %bb86
bb86:
  %t314 = load i1, ptr %l150, !tbaa !21
  br i1 %t314, label %bb87, label %bb88
bb87:
  %t315 = load ptr, ptr %l0, !tbaa !29
  %t317 = getelementptr { i64, [4 x i64] }, ptr %t315, i32 0, i32 1
  %t318 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t317, i32 0, i32 1
  %t319 = load ptr, ptr %t318
  store ptr %t319, ptr %l11, !tbaa !29
  %t321 = load ptr, ptr %l0, !tbaa !29
  %t323 = getelementptr { i64, [4 x i64] }, ptr %t321, i32 0, i32 1
  %t324 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t323, i32 0, i32 2
  %t325 = load { i64, ptr }, ptr %t324
  store { i64, ptr } %t325, ptr %l12, !tbaa !27
  br label %bb93
bb88:
  %t327 = load ptr, ptr %l0, !tbaa !29
  store ptr %t327, ptr %l157, !tbaa !29
  store i1 false, ptr %l158, !tbaa !21
  %t328 = load ptr, ptr %l157, !tbaa !29
  %t329 = icmp ne ptr %t328, null
  br i1 %t329, label %bb89, label %bb90
bb89:
  %t331 = load ptr, ptr %l157, !tbaa !29
  %t332 = load i64, ptr %t331, !range !{i64 0, i64 30}
  %t334 = icmp eq i64 %t332, 15
  store i1 %t334, ptr %l158, !tbaa !21
  br label %bb90
bb90:
  %t335 = load i1, ptr %l158, !tbaa !21
  br i1 %t335, label %bb91, label %bb92
bb91:
  %t336 = load ptr, ptr %l0, !tbaa !29
  %t338 = getelementptr { i64, [4 x i64] }, ptr %t336, i32 0, i32 1
  %t339 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t338, i32 0, i32 1
  %t340 = load ptr, ptr %t339
  store ptr %t340, ptr %l11, !tbaa !29
  %t342 = load ptr, ptr %l0, !tbaa !29
  %t344 = getelementptr { i64, [4 x i64] }, ptr %t342, i32 0, i32 1
  %t345 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t344, i32 0, i32 2
  %t346 = load { i64, ptr }, ptr %t345
  store { i64, ptr } %t346, ptr %l12, !tbaa !27
  br label %bb93
bb92:
  br label %bb96
bb93:
  %t348 = load ptr, ptr %l11, !tbaa !29
  %t350 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t348, ptr %t350)
  br label %bb94
bb94:
  %t353 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t354 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExprs(ptr %v0, ptr %v1, { i64, ptr } %t353, ptr %t354)
  br label %bb95
bb95:
  br label %bb157
bb96:
  %t357 = load ptr, ptr %l0, !tbaa !29
  store ptr %t357, ptr %l170, !tbaa !29
  store i1 false, ptr %l171, !tbaa !21
  %t358 = load ptr, ptr %l170, !tbaa !29
  %t359 = icmp ne ptr %t358, null
  br i1 %t359, label %bb97, label %bb98
bb97:
  %t361 = load ptr, ptr %l170, !tbaa !29
  %t362 = load i64, ptr %t361, !range !{i64 0, i64 30}
  %t364 = icmp eq i64 %t362, 16
  store i1 %t364, ptr %l171, !tbaa !21
  br label %bb98
bb98:
  %t365 = load i1, ptr %l171, !tbaa !21
  br i1 %t365, label %bb99, label %bb100
bb99:
  %t366 = load ptr, ptr %l0, !tbaa !29
  %t368 = getelementptr { i64, [4 x i64] }, ptr %t366, i32 0, i32 1
  %t369 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t368, i32 0, i32 1
  %t370 = load ptr, ptr %t369
  store ptr %t370, ptr %l13, !tbaa !29
  %t372 = load ptr, ptr %l0, !tbaa !29
  %t374 = getelementptr { i64, [4 x i64] }, ptr %t372, i32 0, i32 1
  %t375 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t374, i32 0, i32 2
  %t376 = load ptr, ptr %t375
  store ptr %t376, ptr %l14, !tbaa !29
  %t378 = load ptr, ptr %l0, !tbaa !29
  %t380 = getelementptr { i64, [4 x i64] }, ptr %t378, i32 0, i32 1
  %t381 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t380, i32 0, i32 3
  %t382 = load ptr, ptr %t381
  store ptr %t382, ptr %l15, !tbaa !29
  br label %bb101
bb100:
  br label %bb105
bb101:
  %t384 = load ptr, ptr %l13, !tbaa !29
  %t386 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t384, ptr %t386)
  br label %bb102
bb102:
  %t389 = load ptr, ptr %l14, !tbaa !29
  %t390 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t389, ptr %t390)
  br label %bb103
bb103:
  %t393 = load ptr, ptr %l15, !tbaa !29
  %t394 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t393, ptr %t394)
  br label %bb104
bb104:
  br label %bb157
bb105:
  %t397 = load ptr, ptr %l0, !tbaa !29
  store ptr %t397, ptr %l187, !tbaa !29
  store i1 false, ptr %l188, !tbaa !21
  %t398 = load ptr, ptr %l187, !tbaa !29
  %t399 = icmp ne ptr %t398, null
  br i1 %t399, label %bb106, label %bb107
bb106:
  %t401 = load ptr, ptr %l187, !tbaa !29
  %t402 = load i64, ptr %t401, !range !{i64 0, i64 30}
  %t404 = icmp eq i64 %t402, 17
  store i1 %t404, ptr %l188, !tbaa !21
  br label %bb107
bb107:
  %t405 = load i1, ptr %l188, !tbaa !21
  br i1 %t405, label %bb108, label %bb109
bb108:
  %t406 = load ptr, ptr %l0, !tbaa !29
  %t408 = getelementptr { i64, [4 x i64] }, ptr %t406, i32 0, i32 1
  %t409 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t408, i32 0, i32 2
  %t410 = load { i64, ptr }, ptr %t409
  store { i64, ptr } %t410, ptr %l16, !tbaa !27
  br label %bb126
bb109:
  %t412 = load ptr, ptr %l0, !tbaa !29
  store ptr %t412, ptr %l193, !tbaa !29
  store i1 false, ptr %l194, !tbaa !21
  %t413 = load ptr, ptr %l193, !tbaa !29
  %t414 = icmp ne ptr %t413, null
  br i1 %t414, label %bb110, label %bb111
bb110:
  %t416 = load ptr, ptr %l193, !tbaa !29
  %t417 = load i64, ptr %t416, !range !{i64 0, i64 30}
  %t419 = icmp eq i64 %t417, 18
  store i1 %t419, ptr %l194, !tbaa !21
  br label %bb111
bb111:
  %t420 = load i1, ptr %l194, !tbaa !21
  br i1 %t420, label %bb112, label %bb113
bb112:
  %t421 = load ptr, ptr %l0, !tbaa !29
  %t423 = getelementptr { i64, [4 x i64] }, ptr %t421, i32 0, i32 1
  %t424 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t423, i32 0, i32 1
  %t425 = load { i64, ptr }, ptr %t424
  store { i64, ptr } %t425, ptr %l16, !tbaa !27
  br label %bb126
bb113:
  %t427 = load ptr, ptr %l0, !tbaa !29
  store ptr %t427, ptr %l199, !tbaa !29
  store i1 false, ptr %l200, !tbaa !21
  %t428 = load ptr, ptr %l199, !tbaa !29
  %t429 = icmp ne ptr %t428, null
  br i1 %t429, label %bb114, label %bb115
bb114:
  %t431 = load ptr, ptr %l199, !tbaa !29
  %t432 = load i64, ptr %t431, !range !{i64 0, i64 30}
  %t434 = icmp eq i64 %t432, 29
  store i1 %t434, ptr %l200, !tbaa !21
  br label %bb115
bb115:
  %t435 = load i1, ptr %l200, !tbaa !21
  br i1 %t435, label %bb116, label %bb117
bb116:
  %t436 = load ptr, ptr %l0, !tbaa !29
  %t438 = getelementptr { i64, [4 x i64] }, ptr %t436, i32 0, i32 1
  %t439 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t438, i32 0, i32 1
  %t440 = load { i64, ptr }, ptr %t439
  store { i64, ptr } %t440, ptr %l16, !tbaa !27
  br label %bb126
bb117:
  %t442 = load ptr, ptr %l0, !tbaa !29
  store ptr %t442, ptr %l205, !tbaa !29
  store i1 false, ptr %l206, !tbaa !21
  %t443 = load ptr, ptr %l205, !tbaa !29
  %t444 = icmp ne ptr %t443, null
  br i1 %t444, label %bb118, label %bb119
bb118:
  %t446 = load ptr, ptr %l205, !tbaa !29
  %t447 = load i64, ptr %t446, !range !{i64 0, i64 30}
  %t449 = icmp eq i64 %t447, 20
  store i1 %t449, ptr %l206, !tbaa !21
  br label %bb119
bb119:
  %t450 = load i1, ptr %l206, !tbaa !21
  br i1 %t450, label %bb120, label %bb121
bb120:
  %t451 = load ptr, ptr %l0, !tbaa !29
  %t453 = getelementptr { i64, [4 x i64] }, ptr %t451, i32 0, i32 1
  %t454 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t453, i32 0, i32 1
  %t455 = load { i64, ptr }, ptr %t454
  store { i64, ptr } %t455, ptr %l16, !tbaa !27
  br label %bb126
bb121:
  %t457 = load ptr, ptr %l0, !tbaa !29
  store ptr %t457, ptr %l211, !tbaa !29
  store i1 false, ptr %l212, !tbaa !21
  %t458 = load ptr, ptr %l211, !tbaa !29
  %t459 = icmp ne ptr %t458, null
  br i1 %t459, label %bb122, label %bb123
bb122:
  %t461 = load ptr, ptr %l211, !tbaa !29
  %t462 = load i64, ptr %t461, !range !{i64 0, i64 30}
  %t464 = icmp eq i64 %t462, 24
  store i1 %t464, ptr %l212, !tbaa !21
  br label %bb123
bb123:
  %t465 = load i1, ptr %l212, !tbaa !21
  br i1 %t465, label %bb124, label %bb125
bb124:
  %t466 = load ptr, ptr %l0, !tbaa !29
  %t468 = getelementptr { i64, [4 x i64] }, ptr %t466, i32 0, i32 1
  %t469 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t468, i32 0, i32 1
  %t470 = load { i64, ptr }, ptr %t469
  store { i64, ptr } %t470, ptr %l16, !tbaa !27
  br label %bb126
bb125:
  br label %bb128
bb126:
  %t472 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t473 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExprs(ptr %v0, ptr %v1, { i64, ptr } %t472, ptr %t473)
  br label %bb127
bb127:
  br label %bb157
bb128:
  %t476 = load ptr, ptr %l0, !tbaa !29
  store ptr %t476, ptr %l219, !tbaa !29
  store i1 false, ptr %l220, !tbaa !21
  %t477 = load ptr, ptr %l219, !tbaa !29
  %t478 = icmp ne ptr %t477, null
  br i1 %t478, label %bb129, label %bb130
bb129:
  %t480 = load ptr, ptr %l219, !tbaa !29
  %t481 = load i64, ptr %t480, !range !{i64 0, i64 30}
  %t483 = icmp eq i64 %t481, 21
  store i1 %t483, ptr %l220, !tbaa !21
  br label %bb130
bb130:
  %t484 = load i1, ptr %l220, !tbaa !21
  br i1 %t484, label %bb131, label %bb132
bb131:
  %t485 = load ptr, ptr %l0, !tbaa !29
  %t487 = getelementptr { i64, [4 x i64] }, ptr %t485, i32 0, i32 1
  %t488 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t487, i32 0, i32 1
  %t489 = load ptr, ptr %t488
  store ptr %t489, ptr %l17, !tbaa !29
  %t491 = load ptr, ptr %l0, !tbaa !29
  %t493 = getelementptr { i64, [4 x i64] }, ptr %t491, i32 0, i32 1
  %t494 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t493, i32 0, i32 2
  %t495 = load { i64, ptr }, ptr %t494
  store { i64, ptr } %t495, ptr %l18, !tbaa !27
  br label %bb133
bb132:
  br label %bb136
bb133:
  %t497 = load ptr, ptr %l17, !tbaa !29
  %t499 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t497, ptr %t499)
  br label %bb134
bb134:
  %t502 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t503 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredCatches(ptr %v0, ptr %v1, { i64, ptr } %t502, ptr %t503)
  br label %bb135
bb135:
  br label %bb157
bb136:
  %t506 = load ptr, ptr %l0, !tbaa !29
  store ptr %t506, ptr %l232, !tbaa !29
  store i1 false, ptr %l233, !tbaa !21
  %t507 = load ptr, ptr %l232, !tbaa !29
  %t508 = icmp ne ptr %t507, null
  br i1 %t508, label %bb137, label %bb138
bb137:
  %t510 = load ptr, ptr %l232, !tbaa !29
  %t511 = load i64, ptr %t510, !range !{i64 0, i64 30}
  %t513 = icmp eq i64 %t511, 23
  store i1 %t513, ptr %l233, !tbaa !21
  br label %bb138
bb138:
  %t514 = load i1, ptr %l233, !tbaa !21
  br i1 %t514, label %bb139, label %bb140
bb139:
  %t515 = load ptr, ptr %l0, !tbaa !29
  %t517 = getelementptr { i64, [4 x i64] }, ptr %t515, i32 0, i32 1
  %t518 = getelementptr { %"compiler/source:Span", ptr }, ptr %t517, i32 0, i32 1
  %t519 = load ptr, ptr %t518
  store ptr %t519, ptr %l19, !tbaa !29
  br label %bb141
bb140:
  br label %bb143
bb141:
  %t521 = load ptr, ptr %l19, !tbaa !29
  %t522 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredMatch(ptr %v0, ptr %v1, ptr %t521, ptr %t522)
  br label %bb142
bb142:
  br label %bb157
bb143:
  %t525 = load ptr, ptr %l0, !tbaa !29
  store ptr %t525, ptr %l240, !tbaa !29
  store i1 false, ptr %l241, !tbaa !21
  %t526 = load ptr, ptr %l240, !tbaa !29
  %t527 = icmp ne ptr %t526, null
  br i1 %t527, label %bb144, label %bb145
bb144:
  %t529 = load ptr, ptr %l240, !tbaa !29
  %t530 = load i64, ptr %t529, !range !{i64 0, i64 30}
  %t532 = icmp eq i64 %t530, 19
  store i1 %t532, ptr %l241, !tbaa !21
  br label %bb145
bb145:
  %t533 = load i1, ptr %l241, !tbaa !21
  br i1 %t533, label %bb146, label %bb147
bb146:
  %t534 = load ptr, ptr %l0, !tbaa !29
  %t536 = getelementptr { i64, [4 x i64] }, ptr %t534, i32 0, i32 1
  %t537 = getelementptr { %"compiler/source:Span", ptr }, ptr %t536, i32 0, i32 1
  %t538 = load ptr, ptr %t537
  store ptr %t538, ptr %l20, !tbaa !29
  br label %bb148
bb147:
  br label %bb152
bb148:
  %t540 = load ptr, ptr %l20, !tbaa !29
  %t542 = getelementptr %"compiler/ast:Compr", ptr %t540, i32 0, i32 1
  %t543 = load ptr, ptr %t542, !tbaa !29
  %t545 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t543, ptr %t545)
  br label %bb149
bb149:
  %t548 = load ptr, ptr %l20, !tbaa !29
  %t550 = getelementptr %"compiler/ast:Compr", ptr %t548, i32 0, i32 4
  %t551 = load ptr, ptr %t550, !tbaa !29
  %t553 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t551, ptr %t553)
  br label %bb150
bb150:
  %t556 = load ptr, ptr %l20, !tbaa !29
  %t558 = getelementptr %"compiler/ast:Compr", ptr %t556, i32 0, i32 5
  %t559 = load ptr, ptr %t558, !tbaa !29
  %t560 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t559, ptr %t560)
  br label %bb151
bb151:
  br label %bb157
bb152:
  br i1 true, label %bb153, label %bb154
bb153:
  br label %bb155
bb154:
  br label %bb156
bb155:
  br label %bb157
bb156:
  call void @__olang_check_failed(ptr @olang_loc_9cea8b157736196b_cebcd42f5be7b27)
  unreachable
bb157:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2estoredStmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l13 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l15 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca { i64, ptr }
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca ptr
  %l25 = alloca { i64, ptr }
  %l26 = alloca ptr
  %l27 = alloca { i64, ptr }
  %l28 = alloca i64
  %l29 = alloca i64
  %l31 = alloca ptr
  %l32 = alloca ptr
  %l35 = alloca ptr
  %l36 = alloca i1
  %l44 = alloca ptr
  %l45 = alloca i1
  %l53 = alloca ptr
  %l54 = alloca i1
  %l70 = alloca { i64, ptr }
  %l80 = alloca ptr
  %l81 = alloca i1
  %l93 = alloca ptr
  %l94 = alloca i1
  %l106 = alloca ptr
  %l107 = alloca i1
  %l114 = alloca ptr
  %l115 = alloca i1
  %l120 = alloca ptr
  %l121 = alloca i1
  %l128 = alloca ptr
  %l129 = alloca i1
  %l136 = alloca ptr
  %l137 = alloca i1
  %l149 = alloca ptr
  %l150 = alloca i1
  %l169 = alloca ptr
  %l170 = alloca i1
  %l185 = alloca ptr
  %l186 = alloca i1
  %l193 = alloca ptr
  %l194 = alloca i1
  %l201 = alloca ptr
  %l202 = alloca i1
  %l210 = alloca ptr
  %l211 = alloca i1
  %l223 = alloca ptr
  %l224 = alloca i1
  %l231 = alloca ptr
  %l232 = alloca i1
  %l249 = alloca { i64, ptr }
  %l259 = alloca ptr
  %l260 = alloca i1
  %l271 = alloca ptr
  %l272 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l0, !tbaa !29
  store ptr %t5, ptr %l35, !tbaa !29
  store i1 false, ptr %l36, !tbaa !21
  %t6 = load ptr, ptr %l35, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l35, !tbaa !29
  %t10 = load i64, ptr %t9, !range !{i64 0, i64 22}
  %t12 = icmp eq i64 %t10, 0
  store i1 %t12, ptr %l36, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l36, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr { i64, [4 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", ptr }, ptr %t16, i32 0, i32 1
  %t18 = load ptr, ptr %t17
  store ptr %t18, ptr %l2, !tbaa !29
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t20 = load ptr, ptr %l2, !tbaa !29
  %t22 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t20, ptr %t22)
  br label %bb9
bb9:
  br label %bb172
bb10:
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l44, !tbaa !29
  store i1 false, ptr %l45, !tbaa !21
  %t26 = load ptr, ptr %l44, !tbaa !29
  %t27 = icmp ne ptr %t26, null
  br i1 %t27, label %bb11, label %bb12
bb11:
  %t29 = load ptr, ptr %l44, !tbaa !29
  %t30 = load i64, ptr %t29, !range !{i64 0, i64 22}
  %t32 = icmp eq i64 %t30, 1
  store i1 %t32, ptr %l45, !tbaa !21
  br label %bb12
bb12:
  %t33 = load i1, ptr %l45, !tbaa !21
  br i1 %t33, label %bb13, label %bb14
bb13:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr { i64, [4 x i64] }, ptr %t34, i32 0, i32 1
  %t37 = getelementptr { %"compiler/source:Span", ptr }, ptr %t36, i32 0, i32 1
  %t38 = load ptr, ptr %t37
  store ptr %t38, ptr %l3, !tbaa !29
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t40 = load ptr, ptr %l3, !tbaa !29
  %t42 = getelementptr %"compiler/ast:VarDecl", ptr %t40, i32 0, i32 3
  %t43 = load { i64, ptr }, ptr %t42, !tbaa !27
  %t44 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExprs(ptr %v0, ptr %v1, { i64, ptr } %t43, ptr %t44)
  br label %bb16
bb16:
  br label %bb172
bb17:
  %t47 = load ptr, ptr %l0, !tbaa !29
  store ptr %t47, ptr %l53, !tbaa !29
  store i1 false, ptr %l54, !tbaa !21
  %t48 = load ptr, ptr %l53, !tbaa !29
  %t49 = icmp ne ptr %t48, null
  br i1 %t49, label %bb18, label %bb19
bb18:
  %t51 = load ptr, ptr %l53, !tbaa !29
  %t52 = load i64, ptr %t51, !range !{i64 0, i64 22}
  %t54 = icmp eq i64 %t52, 2
  store i1 %t54, ptr %l54, !tbaa !21
  br label %bb19
bb19:
  %t55 = load i1, ptr %l54, !tbaa !21
  br i1 %t55, label %bb20, label %bb21
bb20:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr { i64, [4 x i64] }, ptr %t56, i32 0, i32 1
  %t59 = getelementptr { %"compiler/source:Span", ptr }, ptr %t58, i32 0, i32 1
  %t60 = load ptr, ptr %t59
  store ptr %t60, ptr %l4, !tbaa !29
  br label %bb22
bb21:
  br label %bb34
bb22:
  %t62 = load ptr, ptr %l4, !tbaa !29
  %t64 = getelementptr %"compiler/ast:Multi", ptr %t62, i32 0, i32 1
  %t65 = load i1, ptr %t64, !tbaa !21
  %t67 = xor i1 %t65, true
  br i1 %t67, label %bb23, label %bb24
bb23:
  %t69 = load ptr, ptr %l4, !tbaa !29
  %t71 = getelementptr %"compiler/ast:Multi", ptr %t69, i32 0, i32 0
  %t72 = load { i64, ptr }, ptr %t71, !tbaa !27
  store { i64, ptr } %t72, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t74 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t76 = extractvalue { i64, ptr } %t74, 0
  store i64 %t76, ptr %l7, !tbaa !24
  br label %bb25
bb24:
  br label %bb32
bb25:
  %t78 = load i64, ptr %l6, !tbaa !24
  %t79 = load i64, ptr %l7, !tbaa !24
  %t82 = icmp slt i64 %t78, %t79
  %t84 = xor i1 %t82, true
  br i1 %t84, label %bb26, label %bb27
bb26:
  br label %bb31
bb27:
  br label %bb28
bb28:
  %t86 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t86, ptr %l70, !tbaa !27
  %t87 = load i64, ptr %l6, !tbaa !24
  %t89 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t90 = load ptr, ptr %t89, !tbaa !27
  %t91 = getelementptr ptr, ptr %t90, i64 %t87
  %t92 = load ptr, ptr %t91, !tbaa !39
  %t95 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredTarget(ptr %v0, ptr %v1, ptr %t92, ptr %t95)
  br label %bb29
bb29:
  br label %bb30
bb30:
  %t98 = load i64, ptr %l6, !tbaa !24
  %t100 = add i64 %t98, 1
  store i64 %t100, ptr %l6, !tbaa !24
  br label %bb25
bb31:
  br label %bb32
bb32:
  %t102 = load ptr, ptr %l4, !tbaa !29
  %t104 = getelementptr %"compiler/ast:Multi", ptr %t102, i32 0, i32 2
  %t105 = load { i64, ptr }, ptr %t104, !tbaa !27
  %t106 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExprs(ptr %v0, ptr %v1, { i64, ptr } %t105, ptr %t106)
  br label %bb33
bb33:
  br label %bb172
bb34:
  %t109 = load ptr, ptr %l0, !tbaa !29
  store ptr %t109, ptr %l80, !tbaa !29
  store i1 false, ptr %l81, !tbaa !21
  %t110 = load ptr, ptr %l80, !tbaa !29
  %t111 = icmp ne ptr %t110, null
  br i1 %t111, label %bb35, label %bb36
bb35:
  %t113 = load ptr, ptr %l80, !tbaa !29
  %t114 = load i64, ptr %t113, !range !{i64 0, i64 22}
  %t116 = icmp eq i64 %t114, 3
  store i1 %t116, ptr %l81, !tbaa !21
  br label %bb36
bb36:
  %t117 = load i1, ptr %l81, !tbaa !21
  br i1 %t117, label %bb37, label %bb38
bb37:
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t120 = getelementptr { i64, [4 x i64] }, ptr %t118, i32 0, i32 1
  %t121 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t120, i32 0, i32 2
  %t122 = load ptr, ptr %t121
  store ptr %t122, ptr %l9, !tbaa !29
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t126 = getelementptr { i64, [4 x i64] }, ptr %t124, i32 0, i32 1
  %t127 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t126, i32 0, i32 3
  %t128 = load ptr, ptr %t127
  store ptr %t128, ptr %l10, !tbaa !29
  br label %bb39
bb38:
  br label %bb42
bb39:
  %t130 = load ptr, ptr %l9, !tbaa !29
  %t131 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredTarget(ptr %v0, ptr %v1, ptr %t130, ptr %t131)
  br label %bb40
bb40:
  %t134 = load ptr, ptr %l10, !tbaa !29
  %t136 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t134, ptr %t136)
  br label %bb41
bb41:
  br label %bb172
bb42:
  %t139 = load ptr, ptr %l0, !tbaa !29
  store ptr %t139, ptr %l93, !tbaa !29
  store i1 false, ptr %l94, !tbaa !21
  %t140 = load ptr, ptr %l93, !tbaa !29
  %t141 = icmp ne ptr %t140, null
  br i1 %t141, label %bb43, label %bb44
bb43:
  %t143 = load ptr, ptr %l93, !tbaa !29
  %t144 = load i64, ptr %t143, !range !{i64 0, i64 22}
  %t146 = icmp eq i64 %t144, 4
  store i1 %t146, ptr %l94, !tbaa !21
  br label %bb44
bb44:
  %t147 = load i1, ptr %l94, !tbaa !21
  br i1 %t147, label %bb45, label %bb46
bb45:
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t150 = getelementptr { i64, [4 x i64] }, ptr %t148, i32 0, i32 1
  %t151 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t150, i32 0, i32 1
  %t152 = load ptr, ptr %t151
  store ptr %t152, ptr %l11, !tbaa !29
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t156 = getelementptr { i64, [4 x i64] }, ptr %t154, i32 0, i32 1
  %t157 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t156, i32 0, i32 2
  %t158 = load { i64, ptr }, ptr %t157
  store { i64, ptr } %t158, ptr %l12, !tbaa !27
  br label %bb47
bb46:
  br label %bb50
bb47:
  %t160 = load ptr, ptr %l11, !tbaa !29
  %t162 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredStmt(ptr %v0, ptr %v1, ptr %t160, ptr %t162)
  br label %bb48
bb48:
  %t165 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t166 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredCatches(ptr %v0, ptr %v1, { i64, ptr } %t165, ptr %t166)
  br label %bb49
bb49:
  br label %bb172
bb50:
  %t169 = load ptr, ptr %l0, !tbaa !29
  store ptr %t169, ptr %l106, !tbaa !29
  store i1 false, ptr %l107, !tbaa !21
  %t170 = load ptr, ptr %l106, !tbaa !29
  %t171 = icmp ne ptr %t170, null
  br i1 %t171, label %bb51, label %bb52
bb51:
  %t173 = load ptr, ptr %l106, !tbaa !29
  %t174 = load i64, ptr %t173, !range !{i64 0, i64 22}
  %t176 = icmp eq i64 %t174, 5
  store i1 %t176, ptr %l107, !tbaa !21
  br label %bb52
bb52:
  %t177 = load i1, ptr %l107, !tbaa !21
  br i1 %t177, label %bb53, label %bb54
bb53:
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t180 = getelementptr { i64, [4 x i64] }, ptr %t178, i32 0, i32 1
  %t181 = getelementptr { %"compiler/source:Span", ptr }, ptr %t180, i32 0, i32 1
  %t182 = load ptr, ptr %t181
  store ptr %t182, ptr %l13, !tbaa !29
  br label %bb55
bb54:
  br label %bb57
bb55:
  %t184 = load ptr, ptr %l13, !tbaa !29
  %t185 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredIf(ptr %v0, ptr %v1, ptr %t184, ptr %t185)
  br label %bb56
bb56:
  br label %bb172
bb57:
  %t188 = load ptr, ptr %l0, !tbaa !29
  store ptr %t188, ptr %l114, !tbaa !29
  store i1 false, ptr %l115, !tbaa !21
  %t189 = load ptr, ptr %l114, !tbaa !29
  %t190 = icmp ne ptr %t189, null
  br i1 %t190, label %bb58, label %bb59
bb58:
  %t192 = load ptr, ptr %l114, !tbaa !29
  %t193 = load i64, ptr %t192, !range !{i64 0, i64 22}
  %t195 = icmp eq i64 %t193, 6
  store i1 %t195, ptr %l115, !tbaa !21
  br label %bb59
bb59:
  %t196 = load i1, ptr %l115, !tbaa !21
  br i1 %t196, label %bb60, label %bb61
bb60:
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t199 = getelementptr { i64, [4 x i64] }, ptr %t197, i32 0, i32 1
  %t200 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t199, i32 0, i32 1
  %t201 = load { i64, ptr }, ptr %t200
  store { i64, ptr } %t201, ptr %l14, !tbaa !27
  br label %bb66
bb61:
  %t203 = load ptr, ptr %l0, !tbaa !29
  store ptr %t203, ptr %l120, !tbaa !29
  store i1 false, ptr %l121, !tbaa !21
  %t204 = load ptr, ptr %l120, !tbaa !29
  %t205 = icmp ne ptr %t204, null
  br i1 %t205, label %bb62, label %bb63
bb62:
  %t207 = load ptr, ptr %l120, !tbaa !29
  %t208 = load i64, ptr %t207, !range !{i64 0, i64 22}
  %t210 = icmp eq i64 %t208, 20
  store i1 %t210, ptr %l121, !tbaa !21
  br label %bb63
bb63:
  %t211 = load i1, ptr %l121, !tbaa !21
  br i1 %t211, label %bb64, label %bb65
bb64:
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t214 = getelementptr { i64, [4 x i64] }, ptr %t212, i32 0, i32 1
  %t215 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t214, i32 0, i32 1
  %t216 = load { i64, ptr }, ptr %t215
  store { i64, ptr } %t216, ptr %l14, !tbaa !27
  br label %bb66
bb65:
  br label %bb68
bb66:
  %t218 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t219 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredIn(ptr %v0, ptr %v1, { i64, ptr } %t218, ptr %t219)
  br label %bb67
bb67:
  br label %bb172
bb68:
  %t222 = load ptr, ptr %l0, !tbaa !29
  store ptr %t222, ptr %l128, !tbaa !29
  store i1 false, ptr %l129, !tbaa !21
  %t223 = load ptr, ptr %l128, !tbaa !29
  %t224 = icmp ne ptr %t223, null
  br i1 %t224, label %bb69, label %bb70
bb69:
  %t226 = load ptr, ptr %l128, !tbaa !29
  %t227 = load i64, ptr %t226, !range !{i64 0, i64 22}
  %t229 = icmp eq i64 %t227, 7
  store i1 %t229, ptr %l129, !tbaa !21
  br label %bb70
bb70:
  %t230 = load i1, ptr %l129, !tbaa !21
  br i1 %t230, label %bb71, label %bb72
bb71:
  %t231 = load ptr, ptr %l0, !tbaa !29
  %t233 = getelementptr { i64, [4 x i64] }, ptr %t231, i32 0, i32 1
  %t234 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t233, i32 0, i32 1
  %t235 = load ptr, ptr %t234
  store ptr %t235, ptr %l15, !tbaa !29
  %t237 = load ptr, ptr %l0, !tbaa !29
  %t239 = getelementptr { i64, [4 x i64] }, ptr %t237, i32 0, i32 1
  %t240 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t239, i32 0, i32 2
  %t241 = load { i64, ptr }, ptr %t240
  store { i64, ptr } %t241, ptr %l16, !tbaa !27
  br label %bb77
bb72:
  %t243 = load ptr, ptr %l0, !tbaa !29
  store ptr %t243, ptr %l136, !tbaa !29
  store i1 false, ptr %l137, !tbaa !21
  %t244 = load ptr, ptr %l136, !tbaa !29
  %t245 = icmp ne ptr %t244, null
  br i1 %t245, label %bb73, label %bb74
bb73:
  %t247 = load ptr, ptr %l136, !tbaa !29
  %t248 = load i64, ptr %t247, !range !{i64 0, i64 22}
  %t250 = icmp eq i64 %t248, 10
  store i1 %t250, ptr %l137, !tbaa !21
  br label %bb74
bb74:
  %t251 = load i1, ptr %l137, !tbaa !21
  br i1 %t251, label %bb75, label %bb76
bb75:
  %t252 = load ptr, ptr %l0, !tbaa !29
  %t254 = getelementptr { i64, [4 x i64] }, ptr %t252, i32 0, i32 1
  %t255 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t254, i32 0, i32 1
  %t256 = load { i64, ptr }, ptr %t255
  store { i64, ptr } %t256, ptr %l16, !tbaa !27
  %t258 = load ptr, ptr %l0, !tbaa !29
  %t260 = getelementptr { i64, [4 x i64] }, ptr %t258, i32 0, i32 1
  %t261 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t260, i32 0, i32 2
  %t262 = load ptr, ptr %t261
  store ptr %t262, ptr %l15, !tbaa !29
  br label %bb77
bb76:
  br label %bb80
bb77:
  %t264 = load ptr, ptr %l15, !tbaa !29
  %t266 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t264, ptr %t266)
  br label %bb78
bb78:
  %t269 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t270 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredIn(ptr %v0, ptr %v1, { i64, ptr } %t269, ptr %t270)
  br label %bb79
bb79:
  br label %bb172
bb80:
  %t273 = load ptr, ptr %l0, !tbaa !29
  store ptr %t273, ptr %l149, !tbaa !29
  store i1 false, ptr %l150, !tbaa !21
  %t274 = load ptr, ptr %l149, !tbaa !29
  %t275 = icmp ne ptr %t274, null
  br i1 %t275, label %bb81, label %bb82
bb81:
  %t277 = load ptr, ptr %l149, !tbaa !29
  %t278 = load i64, ptr %t277, !range !{i64 0, i64 22}
  %t280 = icmp eq i64 %t278, 8
  store i1 %t280, ptr %l150, !tbaa !21
  br label %bb82
bb82:
  %t281 = load i1, ptr %l150, !tbaa !21
  br i1 %t281, label %bb83, label %bb84
bb83:
  %t282 = load ptr, ptr %l0, !tbaa !29
  %t284 = getelementptr { i64, [4 x i64] }, ptr %t282, i32 0, i32 1
  %t285 = getelementptr { %"compiler/source:Span", ptr }, ptr %t284, i32 0, i32 1
  %t286 = load ptr, ptr %t285
  store ptr %t286, ptr %l17, !tbaa !29
  br label %bb85
bb84:
  br label %bb90
bb85:
  %t288 = load ptr, ptr %l17, !tbaa !29
  %t290 = getelementptr %"compiler/ast:For3", ptr %t288, i32 0, i32 0
  %t291 = load ptr, ptr %t290, !tbaa !29
  %t293 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredStmt(ptr %v0, ptr %v1, ptr %t291, ptr %t293)
  br label %bb86
bb86:
  %t296 = load ptr, ptr %l17, !tbaa !29
  %t298 = getelementptr %"compiler/ast:For3", ptr %t296, i32 0, i32 1
  %t299 = load ptr, ptr %t298, !tbaa !29
  %t300 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t299, ptr %t300)
  br label %bb87
bb87:
  %t303 = load ptr, ptr %l17, !tbaa !29
  %t305 = getelementptr %"compiler/ast:For3", ptr %t303, i32 0, i32 2
  %t306 = load ptr, ptr %t305, !tbaa !29
  %t308 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredStmt(ptr %v0, ptr %v1, ptr %t306, ptr %t308)
  br label %bb88
bb88:
  %t311 = load ptr, ptr %l17, !tbaa !29
  %t313 = getelementptr %"compiler/ast:For3", ptr %t311, i32 0, i32 3
  %t314 = load { i64, ptr }, ptr %t313, !tbaa !27
  %t315 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredIn(ptr %v0, ptr %v1, { i64, ptr } %t314, ptr %t315)
  br label %bb89
bb89:
  br label %bb172
bb90:
  %t318 = load ptr, ptr %l0, !tbaa !29
  store ptr %t318, ptr %l169, !tbaa !29
  store i1 false, ptr %l170, !tbaa !21
  %t319 = load ptr, ptr %l169, !tbaa !29
  %t320 = icmp ne ptr %t319, null
  br i1 %t320, label %bb91, label %bb92
bb91:
  %t322 = load ptr, ptr %l169, !tbaa !29
  %t323 = load i64, ptr %t322, !range !{i64 0, i64 22}
  %t325 = icmp eq i64 %t323, 9
  store i1 %t325, ptr %l170, !tbaa !21
  br label %bb92
bb92:
  %t326 = load i1, ptr %l170, !tbaa !21
  br i1 %t326, label %bb93, label %bb94
bb93:
  %t327 = load ptr, ptr %l0, !tbaa !29
  %t329 = getelementptr { i64, [4 x i64] }, ptr %t327, i32 0, i32 1
  %t330 = getelementptr { %"compiler/source:Span", ptr }, ptr %t329, i32 0, i32 1
  %t331 = load ptr, ptr %t330
  store ptr %t331, ptr %l18, !tbaa !29
  br label %bb95
bb94:
  br label %bb99
bb95:
  %t333 = load ptr, ptr %l18, !tbaa !29
  %t335 = getelementptr %"compiler/ast:ForIn", ptr %t333, i32 0, i32 2
  %t336 = load ptr, ptr %t335, !tbaa !29
  %t338 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t336, ptr %t338)
  br label %bb96
bb96:
  %t341 = load ptr, ptr %l18, !tbaa !29
  %t343 = getelementptr %"compiler/ast:ForIn", ptr %t341, i32 0, i32 4
  %t344 = load { i64, ptr }, ptr %t343, !tbaa !27
  %t345 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredIn(ptr %v0, ptr %v1, { i64, ptr } %t344, ptr %t345)
  br label %bb97
bb97:
  %t348 = load ptr, ptr %l18, !tbaa !29
  %t350 = getelementptr %"compiler/ast:ForIn", ptr %t348, i32 0, i32 5
  %t351 = load { i64, ptr }, ptr %t350, !tbaa !27
  %t352 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredCatches(ptr %v0, ptr %v1, { i64, ptr } %t351, ptr %t352)
  br label %bb98
bb98:
  br label %bb172
bb99:
  %t355 = load ptr, ptr %l0, !tbaa !29
  store ptr %t355, ptr %l185, !tbaa !29
  store i1 false, ptr %l186, !tbaa !21
  %t356 = load ptr, ptr %l185, !tbaa !29
  %t357 = icmp ne ptr %t356, null
  br i1 %t357, label %bb100, label %bb101
bb100:
  %t359 = load ptr, ptr %l185, !tbaa !29
  %t360 = load i64, ptr %t359, !range !{i64 0, i64 22}
  %t362 = icmp eq i64 %t360, 11
  store i1 %t362, ptr %l186, !tbaa !21
  br label %bb101
bb101:
  %t363 = load i1, ptr %l186, !tbaa !21
  br i1 %t363, label %bb102, label %bb103
bb102:
  %t364 = load ptr, ptr %l0, !tbaa !29
  %t366 = getelementptr { i64, [4 x i64] }, ptr %t364, i32 0, i32 1
  %t367 = getelementptr { %"compiler/source:Span", ptr }, ptr %t366, i32 0, i32 1
  %t368 = load ptr, ptr %t367
  store ptr %t368, ptr %l19, !tbaa !29
  br label %bb104
bb103:
  br label %bb106
bb104:
  %t370 = load ptr, ptr %l19, !tbaa !29
  %t371 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredMatch(ptr %v0, ptr %v1, ptr %t370, ptr %t371)
  br label %bb105
bb105:
  br label %bb172
bb106:
  %t374 = load ptr, ptr %l0, !tbaa !29
  store ptr %t374, ptr %l193, !tbaa !29
  store i1 false, ptr %l194, !tbaa !21
  %t375 = load ptr, ptr %l193, !tbaa !29
  %t376 = icmp ne ptr %t375, null
  br i1 %t376, label %bb107, label %bb108
bb107:
  %t378 = load ptr, ptr %l193, !tbaa !29
  %t379 = load i64, ptr %t378, !range !{i64 0, i64 22}
  %t381 = icmp eq i64 %t379, 12
  store i1 %t381, ptr %l194, !tbaa !21
  br label %bb108
bb108:
  %t382 = load i1, ptr %l194, !tbaa !21
  br i1 %t382, label %bb109, label %bb110
bb109:
  %t383 = load ptr, ptr %l0, !tbaa !29
  %t385 = getelementptr { i64, [4 x i64] }, ptr %t383, i32 0, i32 1
  %t386 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t385, i32 0, i32 1
  %t387 = load { i64, ptr }, ptr %t386
  store { i64, ptr } %t387, ptr %l20, !tbaa !27
  br label %bb111
bb110:
  br label %bb113
bb111:
  %t389 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t390 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExprs(ptr %v0, ptr %v1, { i64, ptr } %t389, ptr %t390)
  br label %bb112
bb112:
  br label %bb172
bb113:
  %t393 = load ptr, ptr %l0, !tbaa !29
  store ptr %t393, ptr %l201, !tbaa !29
  store i1 false, ptr %l202, !tbaa !21
  %t394 = load ptr, ptr %l201, !tbaa !29
  %t395 = icmp ne ptr %t394, null
  br i1 %t395, label %bb114, label %bb115
bb114:
  %t397 = load ptr, ptr %l201, !tbaa !29
  %t398 = load i64, ptr %t397, !range !{i64 0, i64 22}
  %t400 = icmp eq i64 %t398, 15
  store i1 %t400, ptr %l202, !tbaa !21
  br label %bb115
bb115:
  %t401 = load i1, ptr %l202, !tbaa !21
  br i1 %t401, label %bb116, label %bb117
bb116:
  %t402 = load ptr, ptr %l0, !tbaa !29
  %t404 = getelementptr { i64, [4 x i64] }, ptr %t402, i32 0, i32 1
  %t405 = getelementptr { %"compiler/source:Span", ptr }, ptr %t404, i32 0, i32 1
  %t406 = load ptr, ptr %t405
  store ptr %t406, ptr %l21, !tbaa !29
  br label %bb118
bb117:
  br label %bb120
bb118:
  %t408 = load ptr, ptr %l21, !tbaa !29
  %t410 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t408, ptr %t410)
  br label %bb119
bb119:
  br label %bb172
bb120:
  %t413 = load ptr, ptr %l0, !tbaa !29
  store ptr %t413, ptr %l210, !tbaa !29
  store i1 false, ptr %l211, !tbaa !21
  %t414 = load ptr, ptr %l210, !tbaa !29
  %t415 = icmp ne ptr %t414, null
  br i1 %t415, label %bb121, label %bb122
bb121:
  %t417 = load ptr, ptr %l210, !tbaa !29
  %t418 = load i64, ptr %t417, !range !{i64 0, i64 22}
  %t420 = icmp eq i64 %t418, 14
  store i1 %t420, ptr %l211, !tbaa !21
  br label %bb122
bb122:
  %t421 = load i1, ptr %l211, !tbaa !21
  br i1 %t421, label %bb123, label %bb124
bb123:
  %t422 = load ptr, ptr %l0, !tbaa !29
  %t424 = getelementptr { i64, [4 x i64] }, ptr %t422, i32 0, i32 1
  %t425 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t424, i32 0, i32 1
  %t426 = load ptr, ptr %t425
  store ptr %t426, ptr %l22, !tbaa !29
  %t428 = load ptr, ptr %l0, !tbaa !29
  %t430 = getelementptr { i64, [4 x i64] }, ptr %t428, i32 0, i32 1
  %t431 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t430, i32 0, i32 2
  %t432 = load ptr, ptr %t431
  store ptr %t432, ptr %l23, !tbaa !29
  br label %bb125
bb124:
  br label %bb128
bb125:
  %t434 = load ptr, ptr %l22, !tbaa !29
  %t436 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t434, ptr %t436)
  br label %bb126
bb126:
  %t439 = load ptr, ptr %l23, !tbaa !29
  %t440 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t439, ptr %t440)
  br label %bb127
bb127:
  br label %bb172
bb128:
  %t443 = load ptr, ptr %l0, !tbaa !29
  store ptr %t443, ptr %l223, !tbaa !29
  store i1 false, ptr %l224, !tbaa !21
  %t444 = load ptr, ptr %l223, !tbaa !29
  %t445 = icmp ne ptr %t444, null
  br i1 %t445, label %bb129, label %bb130
bb129:
  %t447 = load ptr, ptr %l223, !tbaa !29
  %t448 = load i64, ptr %t447, !range !{i64 0, i64 22}
  %t450 = icmp eq i64 %t448, 13
  store i1 %t450, ptr %l224, !tbaa !21
  br label %bb130
bb130:
  %t451 = load i1, ptr %l224, !tbaa !21
  br i1 %t451, label %bb131, label %bb132
bb131:
  %t452 = load ptr, ptr %l0, !tbaa !29
  %t454 = getelementptr { i64, [4 x i64] }, ptr %t452, i32 0, i32 1
  %t455 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t454, i32 0, i32 2
  %t456 = load ptr, ptr %t455
  store ptr %t456, ptr %l24, !tbaa !29
  br label %bb133
bb132:
  br label %bb135
bb133:
  %t458 = load ptr, ptr %l24, !tbaa !29
  %t459 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t458, ptr %t459)
  br label %bb134
bb134:
  br label %bb172
bb135:
  %t462 = load ptr, ptr %l0, !tbaa !29
  store ptr %t462, ptr %l231, !tbaa !29
  store i1 false, ptr %l232, !tbaa !21
  %t463 = load ptr, ptr %l231, !tbaa !29
  %t464 = icmp ne ptr %t463, null
  br i1 %t464, label %bb136, label %bb137
bb136:
  %t466 = load ptr, ptr %l231, !tbaa !29
  %t467 = load i64, ptr %t466, !range !{i64 0, i64 22}
  %t469 = icmp eq i64 %t467, 17
  store i1 %t469, ptr %l232, !tbaa !21
  br label %bb137
bb137:
  %t470 = load i1, ptr %l232, !tbaa !21
  br i1 %t470, label %bb138, label %bb139
bb138:
  %t471 = load ptr, ptr %l0, !tbaa !29
  %t473 = getelementptr { i64, [4 x i64] }, ptr %t471, i32 0, i32 1
  %t474 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t473, i32 0, i32 1
  %t475 = load { i64, ptr }, ptr %t474
  store { i64, ptr } %t475, ptr %l25, !tbaa !27
  %t477 = load ptr, ptr %l0, !tbaa !29
  %t479 = getelementptr { i64, [4 x i64] }, ptr %t477, i32 0, i32 1
  %t480 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t479, i32 0, i32 2
  %t481 = load ptr, ptr %t480
  store ptr %t481, ptr %l26, !tbaa !29
  br label %bb140
bb139:
  br label %bb152
bb140:
  %t483 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t485 = extractvalue { i64, ptr } %t483, 0
  %t487 = icmp sgt i64 %t485, 0
  br i1 %t487, label %bb141, label %bb142
bb141:
  %t489 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t489, ptr %l27, !tbaa !27
  store i64 0, ptr %l28, !tbaa !24
  %t491 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t493 = extractvalue { i64, ptr } %t491, 0
  store i64 %t493, ptr %l29, !tbaa !24
  br label %bb143
bb142:
  br label %bb150
bb143:
  %t495 = load i64, ptr %l28, !tbaa !24
  %t496 = load i64, ptr %l29, !tbaa !24
  %t499 = icmp slt i64 %t495, %t496
  %t501 = xor i1 %t499, true
  br i1 %t501, label %bb144, label %bb145
bb144:
  br label %bb149
bb145:
  br label %bb146
bb146:
  %t503 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t503, ptr %l249, !tbaa !27
  %t504 = load i64, ptr %l28, !tbaa !24
  %t506 = getelementptr { i64, ptr }, ptr %l249, i32 0, i32 1
  %t507 = load ptr, ptr %t506, !tbaa !27
  %t508 = getelementptr ptr, ptr %t507, i64 %t504
  %t509 = load ptr, ptr %t508, !tbaa !39
  %t512 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredTarget(ptr %v0, ptr %v1, ptr %t509, ptr %t512)
  br label %bb147
bb147:
  br label %bb148
bb148:
  %t515 = load i64, ptr %l28, !tbaa !24
  %t517 = add i64 %t515, 1
  store i64 %t517, ptr %l28, !tbaa !24
  br label %bb143
bb149:
  br label %bb150
bb150:
  %t519 = load ptr, ptr %l26, !tbaa !29
  %t521 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t519, ptr %t521)
  br label %bb151
bb151:
  br label %bb172
bb152:
  %t524 = load ptr, ptr %l0, !tbaa !29
  store ptr %t524, ptr %l259, !tbaa !29
  store i1 false, ptr %l260, !tbaa !21
  %t525 = load ptr, ptr %l259, !tbaa !29
  %t526 = icmp ne ptr %t525, null
  br i1 %t526, label %bb153, label %bb154
bb153:
  %t528 = load ptr, ptr %l259, !tbaa !29
  %t529 = load i64, ptr %t528, !range !{i64 0, i64 22}
  %t531 = icmp eq i64 %t529, 18
  store i1 %t531, ptr %l260, !tbaa !21
  br label %bb154
bb154:
  %t532 = load i1, ptr %l260, !tbaa !21
  br i1 %t532, label %bb155, label %bb156
bb155:
  %t533 = load ptr, ptr %l0, !tbaa !29
  %t535 = getelementptr { i64, [4 x i64] }, ptr %t533, i32 0, i32 1
  %t536 = getelementptr { %"compiler/source:Span", ptr }, ptr %t535, i32 0, i32 1
  %t537 = load ptr, ptr %t536
  store ptr %t537, ptr %l31, !tbaa !29
  br label %bb157
bb156:
  br label %bb160
bb157:
  %t539 = load ptr, ptr %l31, !tbaa !29
  %t541 = getelementptr %"compiler/ast:JoinS", ptr %t539, i32 0, i32 1
  %t542 = load { i64, ptr }, ptr %t541, !tbaa !27
  %t543 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredIn(ptr %v0, ptr %v1, { i64, ptr } %t542, ptr %t543)
  br label %bb158
bb158:
  %t546 = load ptr, ptr %l31, !tbaa !29
  %t548 = getelementptr %"compiler/ast:JoinS", ptr %t546, i32 0, i32 2
  %t549 = load { i64, ptr }, ptr %t548, !tbaa !27
  %t550 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredCatches(ptr %v0, ptr %v1, { i64, ptr } %t549, ptr %t550)
  br label %bb159
bb159:
  br label %bb172
bb160:
  %t553 = load ptr, ptr %l0, !tbaa !29
  store ptr %t553, ptr %l271, !tbaa !29
  store i1 false, ptr %l272, !tbaa !21
  %t554 = load ptr, ptr %l271, !tbaa !29
  %t555 = icmp ne ptr %t554, null
  br i1 %t555, label %bb161, label %bb162
bb161:
  %t557 = load ptr, ptr %l271, !tbaa !29
  %t558 = load i64, ptr %t557, !range !{i64 0, i64 22}
  %t560 = icmp eq i64 %t558, 19
  store i1 %t560, ptr %l272, !tbaa !21
  br label %bb162
bb162:
  %t561 = load i1, ptr %l272, !tbaa !21
  br i1 %t561, label %bb163, label %bb164
bb163:
  %t562 = load ptr, ptr %l0, !tbaa !29
  %t564 = getelementptr { i64, [4 x i64] }, ptr %t562, i32 0, i32 1
  %t565 = getelementptr { %"compiler/source:Span", ptr, i1 }, ptr %t564, i32 0, i32 1
  %t566 = load ptr, ptr %t565
  store ptr %t566, ptr %l32, !tbaa !29
  br label %bb165
bb164:
  br label %bb167
bb165:
  %t568 = load ptr, ptr %l32, !tbaa !29
  %t570 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredStmt(ptr %v0, ptr %v1, ptr %t568, ptr %t570)
  br label %bb166
bb166:
  br label %bb172
bb167:
  br i1 true, label %bb168, label %bb169
bb168:
  br label %bb170
bb169:
  br label %bb171
bb170:
  br label %bb172
bb171:
  call void @__olang_check_failed(ptr @olang_loc_129627029b1e0c70_26637847123ec4fc)
  unreachable
bb172:
  br label %ret
ret:
  ret void
}

define dso_local { i32, i128 } @compiler_2fcheck_2ewideDigits(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l13 = alloca i1
  %l16 = alloca i1
  %l19 = alloca i1
  %l22 = alloca i128
  %l24 = alloca i64
  %l25 = alloca i64
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca i32
  %l33 = alloca i128
  %l34 = alloca i32
  %l39 = alloca i1
  %l42 = alloca i1
  %l45 = alloca i1
  %l48 = alloca i128
  %l50 = alloca i64
  %l51 = alloca i64
  %l55 = alloca { i64, ptr }
  %l56 = alloca i64
  %l57 = alloca i32
  %l59 = alloca i128
  %l60 = alloca i32
  %l62 = alloca i128
  %l63 = alloca { i64, ptr }
  %l64 = alloca i64
  %l65 = alloca i32
  %l67 = alloca i128
  %l68 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i32, i128 }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d50, i32 0, i32 1) }, ptr %l4, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d51, i32 0, i32 1) }, ptr %l5, !tbaa !27
  %t4 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t6 = call { i64, ptr } @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eReplace_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %a0, { i64, ptr } %t4, { i64, ptr } %t5)
  store { i64, ptr } %t6, ptr %l6
  br label %bb1
bb1:
  %t7 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t7, 0
  store i64 %t8, ptr %l7, !tbaa !24
  %t9 = load i64, ptr %l7, !tbaa !24
  %t10 = mul i64 %t9, 1
  %t11 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t10)
  %t12 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t13 = insertvalue { i64, ptr } %t12, ptr %t11, 1
  store { i64, ptr } %t13, ptr %l8, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = load i64, ptr %l7, !tbaa !24
  %t19 = mul i64 %t18, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t15, ptr %t17, i64 %t19, i1 false)
  %t20 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t20, ptr %l1, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t22, 0
  %t26 = icmp sgt i64 %t24, 2
  br i1 %t26, label %bb2, label %bb3
bb2:
  %t28 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = getelementptr i8, ptr %t29, i64 0
  %t31 = load i8, ptr %t30, !tbaa !32
  %t33 = icmp eq i8 %t31, 48
  store i1 %t33, ptr %l13, !tbaa !21
  br label %bb4
bb3:
  store i1 false, ptr %l13, !tbaa !21
  br label %bb4
bb4:
  %t35 = load i1, ptr %l13, !tbaa !21
  br i1 %t35, label %bb5, label %bb6
bb5:
  %t36 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr i8, ptr %t37, i64 1
  %t39 = load i8, ptr %t38, !tbaa !32
  %t41 = icmp eq i8 %t39, 120
  br i1 %t41, label %bb7, label %bb8
bb6:
  store i1 false, ptr %l16, !tbaa !21
  br label %bb10
bb7:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb9
bb8:
  %t43 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !27
  %t45 = getelementptr i8, ptr %t44, i64 1
  %t46 = load i8, ptr %t45, !tbaa !32
  %t48 = icmp eq i8 %t46, 88
  store i1 %t48, ptr %l19, !tbaa !21
  br label %bb9
bb9:
  %t50 = load i1, ptr %l19, !tbaa !21
  store i1 %t50, ptr %l16, !tbaa !21
  br label %bb10
bb10:
  %t51 = load i1, ptr %l16, !tbaa !21
  br i1 %t51, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s1
  %t52 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t54 = extractvalue { i64, ptr } %t52, 0
  store i64 %t54, ptr %l24, !tbaa !24
  %t55 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t56 = extractvalue { i64, ptr } %t55, 0
  store i64 %t56, ptr %l25, !tbaa !24
  %t57 = icmp sge i64 2, 0
  br i1 %t57, label %bb13, label %bb14
bb12:
  br label %bb24
bb13:
  %t59 = load i64, ptr %l24, !tbaa !24
  %t60 = icmp sle i64 2, %t59
  br i1 %t60, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_a6a8aee764c9772b_17fecb5b27ccad8f)
  unreachable
bb15:
  %t62 = load i64, ptr %l24, !tbaa !24
  %t63 = load i64, ptr %l25, !tbaa !24
  %t64 = icmp sle i64 %t62, %t63
  br i1 %t64, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_a6a8aee764c9772b_17fecb5b27ccad8f)
  unreachable
bb17:
  %t66 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !27
  %t68 = load i64, ptr %l24, !tbaa !24
  %t69 = getelementptr i8, ptr %t67, i64 2
  %t70 = sub i64 %t68, 2
  %t71 = insertvalue { i64, ptr } undef, i64 %t70, 0
  %t72 = insertvalue { i64, ptr } %t71, ptr %t69, 1
  store { i64, ptr } %t72, ptr %l29, !tbaa !27
  %t73 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s1, i64 16)
  %t74 = extractvalue { i32, i64 } %t73, 1
  %t75 = extractvalue { i32, i64 } %t73, 0
  store i32 %t75, ptr %l31
  %t76 = icmp ne i32 %t75, 0
  br i1 %t76, label %bb20, label %ok.77, !prof !99
ok.77:
  store i64 %t74, ptr %l30
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_a6a8aee764c9772b_17fecb5b27ccad8f)
  unreachable
bb19:
  %t78 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t79 = load i64, ptr %l30, !tbaa !24
  %t80 = call { i32, i128 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseAs_3cU128_3e(ptr %s0, { i64, ptr } %t78, i64 %t79)
  %t81 = extractvalue { i32, i128 } %t80, 1
  %t82 = extractvalue { i32, i128 } %t80, 0
  store i32 %t82, ptr %l34
  %t83 = icmp ne i32 %t82, 0
  br i1 %t83, label %bb22, label %ok.84, !prof !99
ok.84:
  store i128 %t81, ptr %l33
  br label %bb21
bb20:
  %t85 = load i32, ptr %l31, !tbaa !23
  %t86 = lshr i32 %t85, 16
  %t87 = and i32 %t85, 65535
  %t88 = icmp eq i32 %t86, 1
  %t89 = select i1 %t88, i32 0, i32 0
  %t90 = icmp eq i32 %t85, 0
  %t91 = shl i32 %t89, 16
  %t92 = or i32 %t91, %t87
  %t93 = select i1 %t90, i32 0, i32 %t92
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t95 = insertvalue { i32, i128 } zeroinitializer, i32 %t93, 0
  store { i32, i128 } %t95, ptr %rv
  br label %ret
bb21:
  %t96 = load i128, ptr %l33
  store i128 %t96, ptr %l22
  br label %bb23
bb22:
  %t97 = load i32, ptr %l34, !tbaa !23
  %t98 = lshr i32 %t97, 16
  %t99 = and i32 %t97, 65535
  %t100 = icmp eq i32 %t98, 1
  %t101 = select i1 %t100, i32 1, i32 0
  %t102 = icmp eq i32 %t97, 0
  %t103 = shl i32 %t101, 16
  %t104 = or i32 %t103, %t99
  %t105 = select i1 %t102, i32 0, i32 %t104
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t107 = insertvalue { i32, i128 } zeroinitializer, i32 %t105, 0
  store { i32, i128 } %t107, ptr %rv
  br label %ret
bb23:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t108 = load i128, ptr %l22
  %t109 = insertvalue { i32, i128 } zeroinitializer, i128 %t108, 1
  store { i32, i128 } %t109, ptr %rv
  br label %ret
bb24:
  %t110 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t112 = extractvalue { i64, ptr } %t110, 0
  %t114 = icmp sgt i64 %t112, 2
  br i1 %t114, label %bb25, label %bb26
bb25:
  %t116 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t117 = load ptr, ptr %t116, !tbaa !27
  %t118 = getelementptr i8, ptr %t117, i64 0
  %t119 = load i8, ptr %t118, !tbaa !32
  %t121 = icmp eq i8 %t119, 48
  store i1 %t121, ptr %l39, !tbaa !21
  br label %bb27
bb26:
  store i1 false, ptr %l39, !tbaa !21
  br label %bb27
bb27:
  %t123 = load i1, ptr %l39, !tbaa !21
  br i1 %t123, label %bb28, label %bb29
bb28:
  %t124 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !27
  %t126 = getelementptr i8, ptr %t125, i64 1
  %t127 = load i8, ptr %t126, !tbaa !32
  %t129 = icmp eq i8 %t127, 98
  br i1 %t129, label %bb30, label %bb31
bb29:
  store i1 false, ptr %l42, !tbaa !21
  br label %bb33
bb30:
  store i1 true, ptr %l45, !tbaa !21
  br label %bb32
bb31:
  %t131 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t132 = load ptr, ptr %t131, !tbaa !27
  %t133 = getelementptr i8, ptr %t132, i64 1
  %t134 = load i8, ptr %t133, !tbaa !32
  %t136 = icmp eq i8 %t134, 66
  store i1 %t136, ptr %l45, !tbaa !21
  br label %bb32
bb32:
  %t138 = load i1, ptr %l45, !tbaa !21
  store i1 %t138, ptr %l42, !tbaa !21
  br label %bb33
bb33:
  %t139 = load i1, ptr %l42, !tbaa !21
  br i1 %t139, label %bb34, label %bb35
bb34:
  store %olang.scope zeroinitializer, ptr %s2
  %t140 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t142 = extractvalue { i64, ptr } %t140, 0
  store i64 %t142, ptr %l50, !tbaa !24
  %t143 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t144 = extractvalue { i64, ptr } %t143, 0
  store i64 %t144, ptr %l51, !tbaa !24
  %t145 = icmp sge i64 2, 0
  br i1 %t145, label %bb36, label %bb37
bb35:
  br label %bb47
bb36:
  %t147 = load i64, ptr %l50, !tbaa !24
  %t148 = icmp sle i64 2, %t147
  br i1 %t148, label %bb38, label %bb39
bb37:
  call void @__olang_check_failed(ptr @olang_loc_8cde041b4e8c8e2e_cde163ca5cf5392)
  unreachable
bb38:
  %t150 = load i64, ptr %l50, !tbaa !24
  %t151 = load i64, ptr %l51, !tbaa !24
  %t152 = icmp sle i64 %t150, %t151
  br i1 %t152, label %bb40, label %bb41
bb39:
  call void @__olang_check_failed(ptr @olang_loc_8cde041b4e8c8e2e_cde163ca5cf5392)
  unreachable
bb40:
  %t154 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t155 = load ptr, ptr %t154, !tbaa !27
  %t156 = load i64, ptr %l50, !tbaa !24
  %t157 = getelementptr i8, ptr %t155, i64 2
  %t158 = sub i64 %t156, 2
  %t159 = insertvalue { i64, ptr } undef, i64 %t158, 0
  %t160 = insertvalue { i64, ptr } %t159, ptr %t157, 1
  store { i64, ptr } %t160, ptr %l55, !tbaa !27
  %t161 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s2, i64 2)
  %t162 = extractvalue { i32, i64 } %t161, 1
  %t163 = extractvalue { i32, i64 } %t161, 0
  store i32 %t163, ptr %l57
  %t164 = icmp ne i32 %t163, 0
  br i1 %t164, label %bb43, label %ok.165, !prof !99
ok.165:
  store i64 %t162, ptr %l56
  br label %bb42
bb41:
  call void @__olang_check_failed(ptr @olang_loc_8cde041b4e8c8e2e_cde163ca5cf5392)
  unreachable
bb42:
  %t166 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t167 = load i64, ptr %l56, !tbaa !24
  %t168 = call { i32, i128 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseAs_3cU128_3e(ptr %s0, { i64, ptr } %t166, i64 %t167)
  %t169 = extractvalue { i32, i128 } %t168, 1
  %t170 = extractvalue { i32, i128 } %t168, 0
  store i32 %t170, ptr %l60
  %t171 = icmp ne i32 %t170, 0
  br i1 %t171, label %bb45, label %ok.172, !prof !99
ok.172:
  store i128 %t169, ptr %l59
  br label %bb44
bb43:
  %t173 = load i32, ptr %l57, !tbaa !23
  %t174 = lshr i32 %t173, 16
  %t175 = and i32 %t173, 65535
  %t176 = icmp eq i32 %t174, 1
  %t177 = select i1 %t176, i32 0, i32 0
  %t178 = icmp eq i32 %t173, 0
  %t179 = shl i32 %t177, 16
  %t180 = or i32 %t179, %t175
  %t181 = select i1 %t178, i32 0, i32 %t180
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t183 = insertvalue { i32, i128 } zeroinitializer, i32 %t181, 0
  store { i32, i128 } %t183, ptr %rv
  br label %ret
bb44:
  %t184 = load i128, ptr %l59
  store i128 %t184, ptr %l48
  br label %bb46
bb45:
  %t185 = load i32, ptr %l60, !tbaa !23
  %t186 = lshr i32 %t185, 16
  %t187 = and i32 %t185, 65535
  %t188 = icmp eq i32 %t186, 1
  %t189 = select i1 %t188, i32 1, i32 0
  %t190 = icmp eq i32 %t185, 0
  %t191 = shl i32 %t189, 16
  %t192 = or i32 %t191, %t187
  %t193 = select i1 %t190, i32 0, i32 %t192
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t195 = insertvalue { i32, i128 } zeroinitializer, i32 %t193, 0
  store { i32, i128 } %t195, ptr %rv
  br label %ret
bb46:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t196 = load i128, ptr %l48
  %t197 = insertvalue { i32, i128 } zeroinitializer, i128 %t196, 1
  store { i32, i128 } %t197, ptr %rv
  br label %ret
bb47:
  %t198 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t198, ptr %l63, !tbaa !27
  %t199 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s0, i64 10)
  %t200 = extractvalue { i32, i64 } %t199, 1
  %t201 = extractvalue { i32, i64 } %t199, 0
  store i32 %t201, ptr %l65
  %t202 = icmp ne i32 %t201, 0
  br i1 %t202, label %bb49, label %ok.203, !prof !99
ok.203:
  store i64 %t200, ptr %l64
  br label %bb48
bb48:
  %t204 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t205 = load i64, ptr %l64, !tbaa !24
  %t206 = call { i32, i128 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseAs_3cU128_3e(ptr %s0, { i64, ptr } %t204, i64 %t205)
  %t207 = extractvalue { i32, i128 } %t206, 1
  %t208 = extractvalue { i32, i128 } %t206, 0
  store i32 %t208, ptr %l68
  %t209 = icmp ne i32 %t208, 0
  br i1 %t209, label %bb51, label %ok.210, !prof !99
ok.210:
  store i128 %t207, ptr %l67
  br label %bb50
bb49:
  %t211 = load i32, ptr %l65, !tbaa !23
  %t212 = lshr i32 %t211, 16
  %t213 = and i32 %t211, 65535
  %t214 = icmp eq i32 %t212, 1
  %t215 = select i1 %t214, i32 0, i32 0
  %t216 = icmp eq i32 %t211, 0
  %t217 = shl i32 %t215, 16
  %t218 = or i32 %t217, %t213
  %t219 = select i1 %t216, i32 0, i32 %t218
  call void @__olang_scope_close(ptr %s0)
  %t221 = insertvalue { i32, i128 } zeroinitializer, i32 %t219, 0
  store { i32, i128 } %t221, ptr %rv
  br label %ret
bb50:
  %t222 = load i128, ptr %l67
  store i128 %t222, ptr %l62
  br label %bb52
bb51:
  %t223 = load i32, ptr %l68, !tbaa !23
  %t224 = lshr i32 %t223, 16
  %t225 = and i32 %t223, 65535
  %t226 = icmp eq i32 %t224, 1
  %t227 = select i1 %t226, i32 1, i32 0
  %t228 = icmp eq i32 %t223, 0
  %t229 = shl i32 %t227, 16
  %t230 = or i32 %t229, %t225
  %t231 = select i1 %t228, i32 0, i32 %t230
  call void @__olang_scope_close(ptr %s0)
  %t233 = insertvalue { i32, i128 } zeroinitializer, i32 %t231, 0
  store { i32, i128 } %t233, ptr %rv
  br label %ret
bb52:
  call void @__olang_scope_close(ptr %s0)
  %t234 = load i128, ptr %l62
  %t235 = insertvalue { i32, i128 } zeroinitializer, i128 %t234, 1
  store { i32, i128 } %t235, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i128 }, ptr %rv
  ret { i32, i128 } %rr
}

define dso_local i1 @compiler_2fcheck_2ewrittenMut(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i1
  %l5 = alloca i1
  %l6 = alloca ptr
  %l7 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  store ptr %t6, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t7 = load ptr, ptr %l6, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l6, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 8}
  %t13 = icmp eq i64 %t11, 4
  store i1 %t13, ptr %l7, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l7, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr { i64, [5 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", ptr, i1, i1 }, ptr %t17, i32 0, i32 2
  %t19 = load i1, ptr %t18
  store i1 %t19, ptr %l1, !tbaa !21
  br label %bb8
bb7:
  br label %bb9
bb8:
  %t21 = load i1, ptr %l1, !tbaa !21
  store i1 %t21, ptr %l5, !tbaa !21
  br label %bb14
bb9:
  br i1 true, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  store i1 false, ptr %l5, !tbaa !21
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_dd9051e7d89be652_5717c5df078d4726)
  unreachable
bb14:
  %t23 = load i1, ptr %l5, !tbaa !21
  store i1 %t23, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/check:laneNode" @compiler_2fcheck_3alaneNode_2ector(ptr %v0, ptr %v1, i64 %a0, i32 %a1, %"compiler/source:Span" %a2, %"compiler/source:Span" %a3, i64 %a4, i64 %a5, i64 %a6, ptr %a7, i32 %a8, i64 %a9, i32 %a10) #0 {
entry:
  %rv = alloca %"compiler/check:laneNode"
  br label %start
start:
  br label %bb0
bb0:
  %t24 = insertvalue %"compiler/check:laneNode" undef, i64 %a0, 0
  %t26 = insertvalue %"compiler/check:laneNode" %t24, i32 %a1, 1
  %t28 = insertvalue %"compiler/check:laneNode" %t26, %"compiler/source:Span" %a2, 2
  %t30 = insertvalue %"compiler/check:laneNode" %t28, %"compiler/source:Span" %a3, 3
  %t32 = insertvalue %"compiler/check:laneNode" %t30, i64 %a4, 4
  %t34 = insertvalue %"compiler/check:laneNode" %t32, i64 %a5, 5
  %t36 = insertvalue %"compiler/check:laneNode" %t34, i64 %a6, 6
  %t38 = insertvalue %"compiler/check:laneNode" %t36, ptr %a7, 7
  %t40 = insertvalue %"compiler/check:laneNode" %t38, i32 %a8, 8
  %t42 = insertvalue %"compiler/check:laneNode" %t40, i64 %a9, 9
  %t44 = insertvalue %"compiler/check:laneNode" %t42, i32 %a10, 10
  store %"compiler/check:laneNode" %t44, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:laneNode", ptr %rv
  ret %"compiler/check:laneNode" %rr
}

define dso_local %"compiler/check:opShape" @compiler_2fcheck_3aopShape_2ector(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i1 %a2, i1 %a3) #0 {
entry:
  %rv = alloca %"compiler/check:opShape"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/check:opShape" undef, { i64, ptr } %a0, 0
  %t12 = insertvalue %"compiler/check:opShape" %t10, i64 %a1, 1
  %t14 = insertvalue %"compiler/check:opShape" %t12, i1 %a2, 2
  %t16 = insertvalue %"compiler/check:opShape" %t14, i1 %a3, 3
  store %"compiler/check:opShape" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:opShape", ptr %rv
  ret %"compiler/check:opShape" %rr
}

define dso_local %"compiler/check:tailAsk" @compiler_2fcheck_3atailAsk_2ector(ptr %v0, i64 %a0, i64 %a1, %"compiler/source:Span" %a2, i64 %a3) #0 {
entry:
  %rv = alloca %"compiler/check:tailAsk"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/check:tailAsk" undef, i64 %a0, 0
  %t12 = insertvalue %"compiler/check:tailAsk" %t10, i64 %a1, 1
  %t14 = insertvalue %"compiler/check:tailAsk" %t12, %"compiler/source:Span" %a2, 2
  %t16 = insertvalue %"compiler/check:tailAsk" %t14, i64 %a3, 3
  store %"compiler/check:tailAsk" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:tailAsk", ptr %rv
  ret %"compiler/check:tailAsk" %rr
}

declare void @__olang_check_failed(ptr) cold noreturn
@.d0 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d1 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare void @__olang_ert_req_clear()
@.d2 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"OLANG_HANDLES" }>, align 8
@.d3 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d4 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_H7f6fc75342dba0a5a8ac6e31960b7ffa(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %a0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 24
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 24
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 1
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !27
  store { i64, ptr } %t21, ptr %l5, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t22, 0
  store i64 %t23, ptr %l6, !tbaa !24
  %t24 = load i64, ptr %l6, !tbaa !24
  %t25 = mul i64 %t24, 8
  %t26 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t25)
  %t27 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  store { i64, ptr } %t28, ptr %l7, !tbaa !27
  %t29 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = load i64, ptr %l6, !tbaa !24
  %t34 = mul i64 %t33, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t30, ptr %t32, i64 %t34, i1 false)
  %t35 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t36 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 1
  store { i64, ptr } %t35, ptr %t36, !tbaa !27
  %t37 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 2
  %t38 = load { i64, ptr }, ptr %t37, !tbaa !27
  store { i64, ptr } %t38, ptr %l8, !tbaa !27
  %t39 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t39, 0
  store i64 %t40, ptr %l9, !tbaa !24
  %t41 = load i64, ptr %l9, !tbaa !24
  %t42 = mul i64 %t41, 8
  %t43 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t42)
  %t44 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t43, 1
  store { i64, ptr } %t45, ptr %l10, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = load i64, ptr %l9, !tbaa !24
  %t51 = mul i64 %t50, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t47, ptr %t49, i64 %t51, i1 false)
  %t52 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t53 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 2
  store { i64, ptr } %t52, ptr %t53, !tbaa !27
  %t54 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t54, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
@__olang_empty_array = external constant [16 x i64]
@.d5 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Call" }>, align 8
@.d6 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"call" }>, align 8
@.d7 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Call" }>, align 8
@.d8 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"std/prelude/text" }>, align 8
@.d9 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Char" }>, align 8
@.d10 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Plus" }>, align 8
@.d11 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Mul" }>, align 8
@.d12 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"BitAnd" }>, align 8
@.d13 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"BitOr" }>, align 8
@.d14 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"BitXor" }>, align 8
@.d15 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Plus" }>, align 8
@.d16 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"'+'" }>, align 8
@.d17 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Mul" }>, align 8
@.d18 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"'*'" }>, align 8
@.d19 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"BitAnd" }>, align 8
@.d20 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"'&'" }>, align 8
@.d21 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"BitOr" }>, align 8
@.d22 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"'|'" }>, align 8
@.d23 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"'^'" }>, align 8
@.d24 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@__olang_prog_scope = external thread_local(initialexec) global ptr
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d25 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d26 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
@.d27 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"__olang_" }>, align 8
@.d28 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I64" }>, align 8
@.d29 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Neg" }>, align 8
@.d30 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"BitNot" }>, align 8
@.d31 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Has" }>, align 8
@.d32 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"'in'" }>, align 8
@.d33 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"Contains" }>, align 8
@.d34 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Has" }>, align 8
@.d35 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"'in'" }>, align 8
@.d36 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"'x in c'" }>, align 8
@.d37 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" ('in')" }>, align 8
@.d38 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Some" }>, align 8
@.d39 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"Every" }>, align 8
@.d40 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"Narrow" }>, align 8
@.d41 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"vacate" }>, align 8
@.d42 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Len" }>, align 8
@.d43 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Len" }>, align 8
@.d44 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Hash" }>, align 8
@.d45 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Str" }>, align 8
@.d46 = private constant <{ i64, [43 x i8] }> <{ i64 0, [43 x i8] c"a method the compiler supplies (E10b, E11c)" }>, align 8
@.d47 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"PadStart" }>, align 8
@.d48 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"PadEnd" }>, align 8
@.d49 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d50 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
@.d51 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
declare i32 @compiler_2fcheck_2esetName(ptr %v0, ptr %a0)
declare i1 @compiler_2fcheck_2echainAssignsAll(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_fcbb335a6871d594_96c5adf6eb865188 = external constant [0 x i8]
@olang_loc_b418a15f1455a8e1_40cdd11b1c753e15 = external constant [0 x i8]
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAllFns(ptr %v0, ptr %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnCount(ptr %v0, ptr %a0)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eRecordCount(ptr %v0, ptr %a0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCount(ptr %v0, ptr %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eattempt(ptr %v0, ptr %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esettleUnset(ptr %v0, ptr %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esettleHeldWalks(ptr %v0, ptr %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esettleIdle(ptr %v0, ptr %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esettleUnread(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_3e_Hda4ef06466535e66801340e999dad217(ptr %v0, ptr %a0)
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_3e_H87a29777ccf22aa2985fa9d3c61f9cd3(ptr %v0, ptr %a0, i64 %a1)
declare { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftypes_3aListId_3e__H9cb5d99387f926677a92c13412f9a8b2(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esettleFacts(ptr %v0, ptr %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efactsUndecided(ptr %v0, ptr %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esettleFixed(ptr %v0, ptr %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eorderGlobals(ptr %v0, ptr %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esettleAllViews(ptr %v0, ptr %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emutStorage(ptr %v0, ptr %a0)
declare { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehandleReport(ptr %v0, ptr %a0)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eForget(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereset(ptr %v0, ptr %a0)
@G_2ecompiler_2ftypes_2eBoolT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eExprBody(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, i32 %a3)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einfersErrs(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorViewKey(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_f6ac6f37bd028998_7777cf96519f6a94 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadsFixed(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %a0)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eReadMaybeNull(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/msgs:Msg" %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNonNull(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnyTrait(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnySlots(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eslotCall(ptr %v0, ptr %a0, i32 %a1, i64 %a2, %"compiler/source:Span" %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etraitMethod(ptr %v0, ptr %v1, ptr %a0, %"compiler/generic:AnySlot" %a1)
declare i1 @compiler_2fcheck_2ehasNamed(ptr %v0, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enamedArgs(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1)
@olang_loc_e1138a3bee8dfd28_1d9c93b07a3bbf3c = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallBody(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, ptr %a4, i64 %a5, ptr %a6, { i64, ptr } %a7, { i64, ptr } %a8)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnyDefault(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edefaultCopiesRecv(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eAnyNoCopy(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_ecdebd42147a0915_28ece6113815da89 = external constant [0 x i8]
@olang_loc_b35cdd4155941ff6_f61ebbb89c67ebca = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i64 %a3, ptr %a4, { i64, ptr } %a5, { i64, ptr } %a6, { i64, ptr } %a7)
declare %"compiler/msgs:Nearest" @compiler_2fmsgs_3aNearest_2ector(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fmsgs_2ecompiler_2fmsgs_3aNearest_2eOffer(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fmsgs_2ecompiler_2fmsgs_3aNearest_2eHint(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eAnyNoMethod(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edescTypeOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflType(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %a0)
declare { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmtsOf(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, i64 %a3, i64 %a4)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eReadOnly = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eWritable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroRef(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eOwning = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2)
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroKey(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fcheck_2ereadPlace(ptr %v0, ptr %v1, ptr %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroPlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, i1 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_c23231398495940d_3184fca2d3133de9 = external constant [0 x i8]
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_dec816aeadd109e0_adcbe0bcced90c1c = external constant [0 x i8]
@olang_loc_98ffdf46f6e43303_7907d8ed59f5817f = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v1, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_4b3a1421aaa5396_3ffde41a88bcce4a = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eJoinPieceCalled(ptr %v0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %a0)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopAfter(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotCallable(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eMember(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknownType(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eArgsFit(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v0, ptr %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eWrittenArity(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fgeneric_2eWrittenTypes(ptr %v0, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeArgCount(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i64 %a2)
@olang_loc_cf2e89857dc93528_274c4670bc5b9eac = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrPinned(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i32, i1 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtCases(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunpin(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtLast(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2)
declare %"compiler/ast:Branch" @compiler_2fast_3aBranch_2ector(ptr %v0, ptr %v1, %"compiler/source:Span" %a0, { i64, ptr } %a1, i64 %a2)
declare %"compiler/ast:If" @compiler_2fast_3aIf_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtCaseTest(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_H2251bc8fca359ca0394d0bb11af7ba0a(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_Hc8503b2b20cde402cc7bde6f68d96fc0(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrBind_3e_2eLen_3ccompiler_2fcheck_3aerrBind_3e(ptr %v0, ptr %a0)
declare %"compiler/check:errBind" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrBind_3e_2eAt_3ccompiler_2fcheck_3aerrBind_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePreludeType(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare { i64, ptr } @compiler_2fscan_2eLiteralBytes(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_d9d408bf8806a5b7_73d051fbfd3f3593 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %a0)
@olang_loc_c9813818497de78f_1a6747489dcf36eb = external constant [0 x i8]
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aClause_26_3e_2eAt_3ccompiler_2ftyped_3aClause_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecatchSpan(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCatchAfterCatchAll(ptr %v0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aClause_26_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aClause_26_3e_2ePush_Hc64f4d0e64077a33423ff9c4e583894f(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrWords(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleft(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCatchUnreachable(ptr %v0)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edefaultSpan(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefaultInStatement(ptr %v0)
@G_2ecompiler_2ftypes_2eVoidT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefaultNoValue(ptr %v0)
@olang_loc_20fb2e81a5b7d68a_7759df49ce89a9e = external constant [0 x i8]
declare i1 @compiler_2fcheck_2eleavesValue(ptr %v0, ptr %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefaultDead(ptr %v0)
declare i1 @compiler_2fcheck_2elastIsValue(ptr %v0, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCatchMustLeave(ptr %v0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefaultCount(ptr %v0, i64 %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, i32 %a3, i32 %a4)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enameSpan(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCommutesNotHere(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCommutesSameType(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2, i64 %a3)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCommutesClash(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, %"compiler/source:Span" %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCondNotBoolType(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eTextOf(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_f259f6ca06e66809_b1ef05920a904ef5 = external constant [0 x i8]
@olang_loc_67410fc9d6566a9c_b1c73ab5a8b03798 = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eevalOnly(ptr %v0, ptr %a0)
declare i1 @compiler_2fcheck_2eclosedExpr(ptr %v0, ptr %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i32 %a3, i32 %a4, i64 %a5)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enewBody(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, i32 %a2, i64 %a3, %"compiler/source:Span" %a4)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare void @compiler_2fgeneric_3aContext_2ector(ptr %out, ptr %v0, i64 %a0, i64 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v1, ptr %a0)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddBlock(ptr %v0, ptr %a0, i32 %a1, i32 %a2, %"compiler/source:Span" %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopyExpr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efitsTest(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v1, i32 %a0, { i64, ptr } %a1)
declare { { i64, [3 x i64] }, { i64, ptr } } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eTopContext(ptr %v0, ptr %v1, ptr %a0)
declare void @compiler_2fcheck_3aContractAsk_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, i64 %a0, i64 %a1, %"compiler/source:Span" %a2, i64 %a3, %"compiler/source:Span" %a4, { i64, ptr } %a5, { i64, ptr } %a6, { i64, [3 x i64] } %a7, { i64, ptr } %a8, { i64, ptr } %a9)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aContractAsk_3e_2ePu_H286c5e5dcd81788bf1de6ef6fc9774a9(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceArgs(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnContext(ptr %out, ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2)
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorContext(ptr %out, ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2)
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceContext(ptr %out, ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_f494bb64cf9470cb_fc1fe1776461b86f = external constant [0 x i8]
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, i32 %a3, i32 %a4, { i64, [2 x i64] } %a5)
@olang_loc_7e44f5428cde099f_6973e730479eef7b = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2eexprPath(ptr %v0, ptr %v1, ptr %a0)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorType(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
@olang_loc_21bd7d1c01cb29ff_7bd6b7239395673b = external constant [0 x i8]
declare %"compiler/ast:Path" @compiler_2fast_3aPath_2ector(ptr %v0, ptr %v1, %"compiler/source:Span" %a0, { i64, ptr } %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewordIndex(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexternParam(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallbackType(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eExternType(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/msgs:Msg" %a2)
@G_2ecompiler_2ftypes_2eNoreturnT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\11\00\00\00" }>, align 8
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexternValue(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eExternResult(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnIsExtern(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2eFnOwner(i64 %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoperatorRole(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare i64 @compiler_2fcheck_2eopShapeOf(ptr %v0, { i64, ptr } %a0)
@G_2ecompiler_2fcheck_2eOpShapes = external constant <{ [8 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [16 x i8] }>
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efnErrors(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eMethodCannotFail(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edrain(ptr %v0, ptr %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eloop(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, { i64, ptr } %a3, ptr %a4)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i64 %a2)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRole(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eRoleCtor = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsWritableAt(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_862846f5a5002b51_69e64f75e4a124a5 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eSetAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eOperandNotBool(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/check:laneNode" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alaneNode_3e_2eAt_3ccompiler_2fcheck_3alaneNode_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneArray(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneElemOf(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eExtends(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneResult(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisInt(ptr %v0, ptr %a0, i32 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v0, i64 %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eToArray_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %v1, ptr %a0)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewholeNarrowed(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaptureIn(ptr %v0, ptr %a0, i64 %a1, i32 %a2, %"compiler/source:Span" %a3)
declare i1 @compiler_2fnames_2eLoneCatchName(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i64 %a3)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebetween(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i64 %a3)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleUse(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, { i64, ptr } %a2, i64 %a3, %"compiler/source:Span" %a4, { i64, ptr } %a5)
declare %"compiler/generic:Binding" @compiler_2fgeneric_3aBinding_2ector(ptr %v0, i64 %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunify(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, ptr %a3, i1 %a4, i1 %a5)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eboundParam(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i64 %a2, ptr %a3)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotOperator(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, { i64, ptr } %a2, %"compiler/source:Span" %a3, { i64, ptr } %a4, i64 %a5, i1 %a6)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eMembershipNoMethod(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eneedErr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, { i64, ptr } %a3, %"compiler/msgs:Msg" %a4)
@olang_loc_1fa90a145069ae20_a62c963c9e2d6294 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eone(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
@olang_loc_e5386246bf71864d_e9422de20f0d1fa1 = external constant [0 x i8]
declare %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, ptr %a1)
declare i1 @compiler_2fcheck_2elaneMethodName(ptr %v0, { i64, ptr } %a0, i64 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneMethod(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, { i64, ptr } %a3, ptr %a4, { i64, ptr } %a5)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDefaultMethods(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrowCall(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, ptr %a3, { i64, ptr } %a4, { i64, ptr } %a5)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeArgsOnNonGeneric(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexplicitArgs(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, { i64, ptr } %a2, %"compiler/source:Span" %a3)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eMethodIsPrivate(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_d23330c3ef7ea91b_34477ea00961dc87 = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefaultAmbiguous(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3, ptr %a4, ptr %a5)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebadOver(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisOver(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebaseHas(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eMethodNotInherited(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esuppliedCall(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, ptr %a3, ptr %a4, { i64, ptr } %a5, { i64, ptr } %a6)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efieldIndex(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
@olang_loc_897998a95b9e5e2e_e7f90bd867c953f2 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efield(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, ptr %a3, i32 %a4)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCharNoPad(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ememberHint(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, i1 %a3)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnknownMethod(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
@olang_loc_97297cf958301a5_897be3a3c1a33231 = external constant [0 x i8]
@olang_loc_f4ec2e4bc4870738_831a294d3dfd1224 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einPlaceCall(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare { i64, ptr } @compiler_2fcheck_2eoperatorName(ptr %v0, i32 %a0)
declare { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %v0, i32 %a0)
@olang_loc_9311a1fdea965308_123228c6f8b4663c = external constant [0 x i8]
@olang_loc_6fa6db75017b9575_1d827b27b68e8189 = external constant [0 x i8]
@olang_loc_53860b63ce2a3756_eab450cf1ae092ca = external constant [0 x i8]
@olang_loc_70239da7d97117f8_be3796eb66d568d4 = external constant [0 x i8]
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emutParam(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_1f453287a90ee701_f75bf1e5be6f432d = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroLocal(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eGlobalDecl(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2)
@olang_loc_24dda45681d8cee1_6133aaee564c4ee5 = external constant [0 x i8]
@olang_loc_f10316e290a7e1b9_b7814005b7d82bcd = external constant [0 x i8]
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esettle(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare { i32, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_Hc78234e963d75e4843d79dfd3cff7b8f(ptr %v0, ptr %v1, ptr %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eliteralBeside(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epowExponent(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneArg(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneBinary(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, ptr %a4, ptr %a5)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epowValues(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, ptr %a3, ptr %a4)
declare { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eProtocolPrivate(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrorOncePerLine(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/msgs:Msg" %a2)
declare %"compiler/check:reflVal" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflFold(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
@G_2ecompiler_2fcheck_2eRvBool = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fcheck_2eRvInt = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fcheck_2eRvText = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCaseNames(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_c2468d0e741d9164_dbacc6d57ee844a8 = external constant [0 x i8]
@olang_loc_c26cedf47b5c0c71_e777f9dba4d45095 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eenumCase(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, i32 %a4, { i64, ptr } %a5, { i64, ptr } %a6)
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %v0, i64 %a0, i64 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyOfCallee(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstanceBody(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroByArg(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroFollows(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
@olang_loc_9ffee6a4e1a43bc2_8f88457b20f170fe = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroCopied(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_ce05aca7270627a9_4d670951fa414da5 = external constant [0 x i8]
declare %"compiler/check:roOrigin" @compiler_2fcheck_3aroOrigin_2ector(ptr %v0, ptr %v1, ptr %a0, i1 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_Hd862b35741eab3a632965773dd6b12ba(ptr %v0, ptr %v1, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, %"compiler/check:roOrigin" %a2)
@olang_loc_9ed68493f04b873b_45e1787ed2cd21af = external constant [0 x i8]
@olang_loc_e181575e6035f202_99a6d5836a9bf6a6 = external constant [0 x i8]
@olang_loc_a5d3444dbde3a383_cb32d8a11a505607 = external constant [0 x i8]
@olang_loc_664096f84a6143a8_9c45533022ca790c = external constant [0 x i8]
@olang_loc_5f0b92ad49630279_51f88f4b15ed303d = external constant [0 x i8]
@olang_loc_265c788dd5eed9e_866edb98fc8c38ea = external constant [0 x i8]
@olang_loc_6ac4c8202b0b581f_2f15107fd7d9b5ab = external constant [0 x i8]
@olang_loc_8bfef52d6d2c65e4_ce3ff42f583fc170 = external constant [0 x i8]
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v0, ptr %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fast_3aPattern_26_3e_26_3e_2ector(ptr %v0, i64 %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fast_3aPattern_26_3e_H06f4ae43b564aa38800728c5b9a6edfe(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fast_3aPattern_26_3e_Hb04d670045d084ea2498d9030c4fbba9(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epatWild(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_e4bef59f129059d8_aff2623e63fdc5dc = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fast_3aPattern_26_3e_H19842cc3f9f17801919cd111c108caa0(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eshapeOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPattern_26_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPattern_26_3e_2ePush_3ccompiler_2fast_3aPattern_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aPattern_2eSpan(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPattern_26_3e_2eToArr_H3d785ef7fade1f29078b6e80f1d617ba(ptr %v0, ptr %v1, ptr %a0)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnsParts(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnedPart(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2epartPlace(ptr %v0, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eownCopy(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2eLen__H22c160154c8542d83ffe3c77c98973d0(ptr %v0, ptr %a0)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2ePush_H521773322b2b1b179ce4cc03a1674857(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@G_2ecompiler_2ftypes_2eNullT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\0F\00\00\00" }>, align 8
declare { i64, ptr } @compiler_2fcheck_2epathOf(ptr %v0, ptr %v1, ptr %a0)
declare { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplaceAt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2eTrun_Haa7c8ccc08c8123d0b87c9688e5d351e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroRoot(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@G_2ecompiler_2fcheck_2eRoStored = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroStore(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2, i64 %a3)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estrBytes(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etopBody(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, i32 %a3)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoperatorOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/check:TopAssertAsk" @compiler_2fcheck_3aTopAssertAsk_2ector(ptr %v0, i64 %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i64 %a3, i64 %a4)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aTopAssertAsk_3e_2eP_H67072fc16e996275e069a499f28fddf9(ptr %v0, ptr %a0, %"compiler/check:TopAssertAsk" %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTopSetPlace(ptr %v0)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc2(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/source:Span" %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTopSetTarget(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTopSetHasValue(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H8da9376267bda3f76393292be0e507b2(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTopSetTwice(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H96b7de74ba8f33ba996281c879dd113a(ptr %v0, ptr %a0, i32 %a1, i1 %a2)
@olang_loc_c6f64016a09fc530_b8b2abed7e41fd2c = external constant [0 x i8]
declare i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2eChosen(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etopSetIf(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i64 %a1, ptr %a2, ptr %a3, i1 %a4, i1 %a5, i64 %a6, i64 %a7, ptr %a8)
@olang_loc_37fb0db160a44e56_e10956c528b68142 = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTraitErrsUnwritten(ptr %v0)
@olang_loc_cc3b7a6e318210b6_464c855cb4a991aa = external constant [0 x i8]
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLayout(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eViaMemory(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePassing(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eviewable(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_3e_H2474e1fc3c93452d7765e4ed18f29a03(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eloopCall(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, ptr %a3, { i64, ptr } %a4)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexhaustedOrBreak(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3)
declare { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebreakUnless(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3)
declare %"compiler/typed:Elem" @compiler_2ftyped_3aElem_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eelementLocals(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3, ptr %a4)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkBody(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i32 %a3)
@olang_loc_db613d0fd16ec597_dffdd95765f5abab = external constant [0 x i8]
@olang_loc_6f2142d51bf1dfcd_a6163a9035ffb161 = external constant [0 x i8]
declare %"compiler/check:narrowed" @compiler_2fcheck_3anarrowed_2ector(ptr %v0, i64 %a0, i64 %a1, i32 %a2, i64 %a3, i64 %a4, i1 %a5)
declare %"compiler/check:litv" @compiler_2fcheck_3alitv_2ector(ptr %v0, i1 %a0, i1 %a1, i1 %a2, i64 %a3, double %a4)
declare i1 @compiler_2fcheck_2eleavesBlock(ptr %v0, ptr %a0)
declare i1 @compiler_2ftyped_2eBreaksOut(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_eb3e4e8f3f96f0ec_5bc3fc9686c42b70 = external constant [0 x i8]
@olang_loc_bad8a01556e87002_6e42cd1773855696 = external constant [0 x i8]
@olang_loc_3862db6440158079_51a5529566dfad = external constant [0 x i8]
@olang_loc_d195b38137e2d30_7d67c1d5e7f3802c = external constant [0 x i8]
declare void @compiler_2fcheck_2estoredExprs(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1)
declare void @compiler_2fcheck_2estoredCatches(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1)
declare void @compiler_2fcheck_2estoredMatch(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_9cea8b157736196b_cebcd42f5be7b27 = external constant [0 x i8]
declare void @compiler_2fcheck_2estoredTarget(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fcheck_2estoredIf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fcheck_2estoredIn(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1)
@olang_loc_129627029b1e0c70_26637847123ec4fc = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eReplace_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
@olang_loc_a6a8aee764c9772b_17fecb5b27ccad8f = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %v0, i64 %a0)
declare { i32, i128 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseAs_3cU128_3e(ptr %v0, { i64, ptr } %a0, i64 %a1)
@olang_loc_8cde041b4e8c8e2e_cde163ca5cf5392 = external constant [0 x i8]
@olang_loc_dd9051e7d89be652_5717c5df078d4726 = external constant [0 x i8]

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
