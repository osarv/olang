; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/typed:Elem" = type { ptr, ptr, i32 }
%"compiler/typed:Payload" = type { ptr, i64, i32 }
%"compiler/check:Checker" = type { ptr, ptr, i1, i1, i1, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, { i64, [3 x i64] }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i32, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"compiler/source:Span", i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i32, i1, i1, %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, i32, i32, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/types:Table" = type { ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1 }
%"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64 }
%"compiler/load:Import" = type { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, { i64, ptr }, i64, i64 }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, { i64, ptr } }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, ptr, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" = type { i64, i64 }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/ast:Branch" = type { %"compiler/source:Span", { i64, ptr }, i64 }
%"compiler/msgs:Msg" = type { i32, { i64, ptr }, { i64, ptr } }
%"compiler/typed:Item" = type { i32, i64 }
%"compiler/check:frame" = type { i64, i64, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"compiler/generic:Context", i32, i32, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i32, i64, i64, i64, i64, i64, i1, i64, i1, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i1, i64, i64, i64, i1, i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, i64, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64 }
%"compiler/generic:Context" = type { i64, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/ast:Path" = type { %"compiler/source:Span", { i64, ptr } }
%"compiler/typed:Clause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr, { i64, ptr } }
%"compiler/ast:Catch" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr }, { i64, ptr }, i1 }
%"compiler/check:litv" = type { i1, i1, i1, i64, double, i1 }
%"compiler/typed:Block" = type { i32, { i64, ptr } }
%"compiler/ast:ForIn" = type { i32, i32, ptr, i1, { i64, ptr }, { i64, ptr } }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1 }
%"compiler/ast:Sig" = type { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, i1, { i64, ptr }, { i64, ptr }, ptr }
%"compiler/source:Source" = type { { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/generic:Binding" = type { i64, i64, { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/typed:Local" = type { i32, %"compiler/source:Span", i32, i32, i32, { i64, [2 x i64] } }
%"compiler/names:Ref" = type { i32, i64, i64 }
%"compiler/check:nullNarrow" = type { { i64, ptr }, i64, i1 }
%"compiler/ast:Chain" = type { { i64, ptr }, { i64, ptr } }
%"compiler/typed:Call" = type { ptr, { i64, ptr }, { i64, [2 x i64] }, i32, i1, i1 }
%"std/pair:Pair.b139c4f75a6545712256427180a82a06" = type { %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" }
%"compiler/check:roArg" = type { i64, i64, { i64, [3 x i64] }, { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/check:roFn" = type { i64, i64, { i64, [3 x i64] }, { i64, ptr } }
%"std/pair:Pair.1eb2466213689e002f25e81e83536e78" = type { i64, ptr }
%"compiler/generic:Unmet" = type { i64, i32, i32, i1, i1, i1 }
%"compiler/ast:TypeDecl" = type { i32, { i64, ptr }, i1, ptr }
%"compiler/typed:Try" = type { ptr, { i64, ptr }, i1, i1 }
%"compiler/ast:If" = type { ptr, ptr, ptr }
%"compiler/ast:Match" = type { %"compiler/source:Span", ptr, i1, { i64, ptr }, ptr }
%"compiler/ast:Case" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, ptr }
%"compiler/check:Ask" = type { i64, i64, i32, ptr, i64, { i64, ptr } }
%"compiler/check:opShape" = type { { i64, ptr }, i64, i1, i1 }
%"compiler/check:roOrigin" = type { ptr, i1 }
define dso_local void @compiler_2fcheck_2eBounds_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 1, ptr @G_2ecompiler_2fcheck_2eBounds, !tbaa !65
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2eCtEns_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 2, ptr @G_2ecompiler_2fcheck_2eCtEns, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2eCtEntry_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 3, ptr @G_2ecompiler_2fcheck_2eCtEntry, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2eallBuilt(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l16 = alloca { i64, ptr }
  %l20 = alloca i1
  %s3 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 true, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t8, ptr %l1, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l3, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s3
  %t14 = load i64, ptr %l2, !tbaa !24
  %t15 = load i64, ptr %l3, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s3)
  br label %bb13
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t22, ptr %l16, !tbaa !27
  %t23 = load i64, ptr %l2, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  %t32 = call i1 @compiler_2fcheck_2ebuiltAst(ptr %v0, ptr %t28)
  store i1 %t32, ptr %l20
  br label %bb8
bb8:
  %t33 = load i1, ptr %l20, !tbaa !21
  %t34 = xor i1 %t33, true
  br i1 %t34, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  store i1 false, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s3)
  br label %bb12
bb12:
  %t37 = load i64, ptr %l2, !tbaa !24
  %t39 = add i64 %t37, 1
  store i64 %t39, ptr %l2, !tbaa !24
  br label %bb4
bb13:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2eclosedPlace(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i1
  %l7 = alloca ptr
  %l8 = alloca i1
  %l11 = alloca ptr
  %l12 = alloca i1
  %l18 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca i1
  %l26 = alloca i1
  %l27 = alloca ptr
  %l28 = alloca i1
  %l35 = alloca i1
  %l36 = alloca i1
  %l39 = alloca i1
  %l40 = alloca ptr
  %l41 = alloca i1
  %l48 = alloca i1
  %l49 = alloca ptr
  %l50 = alloca i1
  %l56 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l7, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb50
bb6:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t11 = load ptr, ptr %l11, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb7, label %bb8
bb7:
  %t14 = load ptr, ptr %l11, !tbaa !29
  %t15 = load i64, ptr %t14
  %t17 = icmp eq i64 %t15, 2
  store i1 %t17, ptr %l12, !tbaa !21
  br label %bb8
bb8:
  %t18 = load i1, ptr %l12, !tbaa !21
  br i1 %t18, label %bb9, label %bb10
bb9:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr { i64, [4 x i64] }, ptr %t19, i32 0, i32 1
  %t22 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t21, i32 0, i32 2
  %t23 = load ptr, ptr %t22
  store ptr %t23, ptr %l1, !tbaa !29
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = call i1 @compiler_2fcheck_2eclosedExpr(ptr %v0, ptr %t25)
  store i1 %t27, ptr %l18
  br label %bb12
bb12:
  %t28 = load i1, ptr %l18, !tbaa !21
  store i1 %t28, ptr %l6, !tbaa !21
  br label %bb50
bb13:
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t30 = load ptr, ptr %l19, !tbaa !29
  %t31 = icmp ne ptr %t30, null
  br i1 %t31, label %bb14, label %bb15
bb14:
  %t33 = load ptr, ptr %l19, !tbaa !29
  %t34 = load i64, ptr %t33
  %t36 = icmp eq i64 %t34, 3
  store i1 %t36, ptr %l20, !tbaa !21
  br label %bb15
bb15:
  %t37 = load i1, ptr %l20, !tbaa !21
  br i1 %t37, label %bb16, label %bb17
bb16:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr { i64, [4 x i64] }, ptr %t38, i32 0, i32 1
  %t41 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t40, i32 0, i32 2
  %t42 = load ptr, ptr %t41
  store ptr %t42, ptr %l2, !tbaa !29
  br label %bb18
bb17:
  br label %bb20
bb18:
  %t44 = load ptr, ptr %l2, !tbaa !29
  %t46 = call i1 @compiler_2fcheck_2eclosedPlace(ptr %v0, ptr %t44)
  store i1 %t46, ptr %l26
  br label %bb19
bb19:
  %t47 = load i1, ptr %l26, !tbaa !21
  store i1 %t47, ptr %l6, !tbaa !21
  br label %bb50
bb20:
  %t48 = load ptr, ptr %l0, !tbaa !29
  store ptr %t48, ptr %l27, !tbaa !29
  store i1 false, ptr %l28, !tbaa !21
  %t49 = load ptr, ptr %l27, !tbaa !29
  %t50 = icmp ne ptr %t49, null
  br i1 %t50, label %bb21, label %bb22
bb21:
  %t52 = load ptr, ptr %l27, !tbaa !29
  %t53 = load i64, ptr %t52
  %t55 = icmp eq i64 %t53, 4
  store i1 %t55, ptr %l28, !tbaa !21
  br label %bb22
bb22:
  %t56 = load i1, ptr %l28, !tbaa !21
  br i1 %t56, label %bb23, label %bb24
bb23:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr { i64, [4 x i64] }, ptr %t57, i32 0, i32 1
  %t60 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t59, i32 0, i32 2
  %t61 = load ptr, ptr %t60
  store ptr %t61, ptr %l3, !tbaa !29
  br label %bb25
bb24:
  br label %bb31
bb25:
  %t63 = load ptr, ptr %l3, !tbaa !29
  %t65 = getelementptr %"compiler/typed:Elem", ptr %t63, i32 0, i32 0
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t68 = call i1 @compiler_2fcheck_2eclosedPlace(ptr %v0, ptr %t66)
  store i1 %t68, ptr %l35
  br label %bb26
bb26:
  %t69 = load i1, ptr %l35, !tbaa !21
  br i1 %t69, label %bb27, label %bb28
bb27:
  %t70 = load ptr, ptr %l3, !tbaa !29
  %t72 = getelementptr %"compiler/typed:Elem", ptr %t70, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !29
  %t75 = call i1 @compiler_2fcheck_2eclosedExpr(ptr %v0, ptr %t73)
  store i1 %t75, ptr %l39
  br label %bb29
bb28:
  store i1 false, ptr %l36, !tbaa !21
  br label %bb30
bb29:
  %t76 = load i1, ptr %l39, !tbaa !21
  store i1 %t76, ptr %l36, !tbaa !21
  br label %bb30
bb30:
  %t77 = load i1, ptr %l36, !tbaa !21
  store i1 %t77, ptr %l6, !tbaa !21
  br label %bb50
bb31:
  %t78 = load ptr, ptr %l0, !tbaa !29
  store ptr %t78, ptr %l40, !tbaa !29
  store i1 false, ptr %l41, !tbaa !21
  %t79 = load ptr, ptr %l40, !tbaa !29
  %t80 = icmp ne ptr %t79, null
  br i1 %t80, label %bb32, label %bb33
bb32:
  %t82 = load ptr, ptr %l40, !tbaa !29
  %t83 = load i64, ptr %t82
  %t85 = icmp eq i64 %t83, 5
  store i1 %t85, ptr %l41, !tbaa !21
  br label %bb33
bb33:
  %t86 = load i1, ptr %l41, !tbaa !21
  br i1 %t86, label %bb34, label %bb35
bb34:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr { i64, [4 x i64] }, ptr %t87, i32 0, i32 1
  %t90 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t89, i32 0, i32 2
  %t91 = load ptr, ptr %t90
  store ptr %t91, ptr %l4, !tbaa !29
  br label %bb36
bb35:
  br label %bb38
bb36:
  %t93 = load ptr, ptr %l4, !tbaa !29
  %t95 = getelementptr %"compiler/typed:Payload", ptr %t93, i32 0, i32 0
  %t96 = load ptr, ptr %t95, !tbaa !29
  %t98 = call i1 @compiler_2fcheck_2eclosedPlace(ptr %v0, ptr %t96)
  store i1 %t98, ptr %l48
  br label %bb37
bb37:
  %t99 = load i1, ptr %l48, !tbaa !21
  store i1 %t99, ptr %l6, !tbaa !21
  br label %bb50
bb38:
  %t100 = load ptr, ptr %l0, !tbaa !29
  store ptr %t100, ptr %l49, !tbaa !29
  store i1 false, ptr %l50, !tbaa !21
  %t101 = load ptr, ptr %l49, !tbaa !29
  %t102 = icmp ne ptr %t101, null
  br i1 %t102, label %bb39, label %bb40
bb39:
  %t104 = load ptr, ptr %l49, !tbaa !29
  %t105 = load i64, ptr %t104
  %t107 = icmp eq i64 %t105, 6
  store i1 %t107, ptr %l50, !tbaa !21
  br label %bb40
bb40:
  %t108 = load i1, ptr %l50, !tbaa !21
  br i1 %t108, label %bb41, label %bb42
bb41:
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = getelementptr { i64, [4 x i64] }, ptr %t109, i32 0, i32 1
  %t112 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t111, i32 0, i32 2
  %t113 = load ptr, ptr %t112
  store ptr %t113, ptr %l5, !tbaa !29
  br label %bb43
bb42:
  br label %bb45
bb43:
  %t115 = load ptr, ptr %l5, !tbaa !29
  %t117 = call i1 @compiler_2fcheck_2eclosedExpr(ptr %v0, ptr %t115)
  store i1 %t117, ptr %l56
  br label %bb44
bb44:
  %t118 = load i1, ptr %l56, !tbaa !21
  store i1 %t118, ptr %l6, !tbaa !21
  br label %bb50
bb45:
  br i1 true, label %bb46, label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb49
bb48:
  store i1 false, ptr %l6, !tbaa !21
  br label %bb50
bb49:
  call void @__olang_check_failed(ptr @olang_loc_3ee32a1caa2e355c_4063d0a06727bdc8)
  unreachable
bb50:
  %t119 = load i1, ptr %l6, !tbaa !21
  store i1 %t119, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eExprBody(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, i32 %a3) #0 {
entry:
  %l4 = alloca ptr
  %l5 = alloca i64
  %l8 = alloca { i64, ptr }
  %l14 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store ptr %a0, ptr %l4, !tbaa !29
  store i64 %a1, ptr %l5, !tbaa !24
  %t3 = icmp sge i64 0, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = icmp sle i64 0, 2305843009213693951
  br i1 %t5, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_a6ae1e9a693d05c9_888d1f7981f90365)
  unreachable
bb3:
  %t7 = mul i64 0, 4
  %t8 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t7)
  %t9 = insertvalue { i64, ptr } undef, i64 0, 0
  %t10 = insertvalue { i64, ptr } %t9, ptr %t8, 1
  store { i64, ptr } %t10, ptr %l8, !tbaa !27
  %t11 = icmp sge i64 0, 0
  br i1 %t11, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_a6ae1e9a693d05c9_888d1f7981f90365)
  unreachable
bb5:
  %t13 = icmp sle i64 0, 2305843009213693951
  br i1 %t13, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_a6ae1e9a693d05c9_888d1f7981f90365)
  unreachable
bb7:
  %t15 = mul i64 0, 4
  %t16 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t15)
  %t17 = insertvalue { i64, ptr } undef, i64 0, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = load ptr, ptr %l4, !tbaa !29
  %t22 = load i64, ptr %l5, !tbaa !24
  %t23 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t27 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eExprBodyIn(ptr %v0, ptr %s0, ptr %s0, ptr %v1, ptr %t21, i64 %t22, i64 -1, { i64, ptr } %t23, { i64, ptr } %t18, ptr %a2, i32 %a3)
  store i64 %t27, ptr %l14
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_a6ae1e9a693d05c9_888d1f7981f90365)
  unreachable
bb9:
  call void @__olang_scope_close(ptr %s0)
  %t28 = load i64, ptr %l14, !tbaa !24
  store i64 %t28, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTextType(ptr %v0, ptr %a0) #0 {
entry:
  %l2 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %a0)
  store i32 %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load i32, ptr %l2, !tbaa !23
  store i32 %t4, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earithCheck(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i1
  %l6 = alloca i1
  %l11 = alloca ptr
  %l14 = alloca i32
  %l15 = alloca i1
  %l18 = alloca i1
  %l21 = alloca i1
  %l29 = alloca i32
  %l39 = alloca i32
  %l47 = alloca i32
  %l51 = alloca i32
  %l53 = alloca i1
  %l56 = alloca i32
  %l58 = alloca i32
  %l70 = alloca i32
  %l75 = alloca ptr
  %l76 = alloca i32
  %l77 = alloca i64
  %l79 = alloca i64
  %l82 = alloca i32
  %l90 = alloca i32
  %l96 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  %t5 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i1, ptr %l6, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  store i32 0, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = getelementptr %"compiler/generic:Program", ptr %t13, i32 0, i32 2
  store ptr %t15, ptr %l11, !tbaa !29
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load i32, ptr %l2, !tbaa !23
  %t20 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t16, i32 %t17)
  store i32 %t20, ptr %l14
  br label %bb5
bb5:
  %t21 = load ptr, ptr %l11, !tbaa !29
  %t22 = load i32, ptr %l14, !tbaa !23
  %t23 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t21, i32 %t22)
  store i1 %t23, ptr %l15
  br label %bb6
bb6:
  %t24 = load i1, ptr %l15, !tbaa !21
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t25 = load i32, ptr %l1
  %t27 = trunc i64 3 to i32
  %t28 = icmp eq i32 %t25, %t27
  br i1 %t28, label %bb9, label %bb10
bb8:
  br label %bb27
bb9:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb11
bb10:
  %t30 = load i32, ptr %l1
  %t32 = trunc i64 4 to i32
  %t33 = icmp eq i32 %t30, %t32
  store i1 %t33, ptr %l18, !tbaa !21
  br label %bb11
bb11:
  %t35 = load i1, ptr %l18, !tbaa !21
  br i1 %t35, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb14
bb13:
  %t36 = load i32, ptr %l1
  %t38 = trunc i64 5 to i32
  %t39 = icmp eq i32 %t36, %t38
  store i1 %t39, ptr %l21, !tbaa !21
  br label %bb14
bb14:
  %t41 = load i1, ptr %l21, !tbaa !21
  br i1 %t41, label %bb15, label %bb16
bb15:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load i64, ptr @G_2ecompiler_2fcheck_2eOverflow, !tbaa !65
  %t44 = load i64, ptr @G_2ecompiler_2fcheck_2eInvalid, !tbaa !65
  %t47 = or i64 %t43, %t44
  %t51 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echeckOp(ptr %v0, ptr %t42, i32 0, i64 %t47)
  store i32 %t51, ptr %l29
  br label %bb17
bb16:
  br label %bb18
bb17:
  %t52 = load i32, ptr %l29
  store i32 %t52, ptr %rv
  br label %ret
bb18:
  %t53 = load i32, ptr %l1
  %t55 = trunc i64 6 to i32
  %t56 = icmp eq i32 %t53, %t55
  br i1 %t56, label %bb19, label %bb20
bb19:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load i64, ptr @G_2ecompiler_2fcheck_2eDivideByZero, !tbaa !65
  %t60 = load i64, ptr @G_2ecompiler_2fcheck_2eOverflow, !tbaa !65
  %t63 = or i64 %t59, %t60
  %t64 = load i64, ptr @G_2ecompiler_2fcheck_2eInvalid, !tbaa !65
  %t67 = or i64 %t63, %t64
  %t71 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echeckOp(ptr %v0, ptr %t58, i32 0, i64 %t67)
  store i32 %t71, ptr %l39
  br label %bb21
bb20:
  br label %bb22
bb21:
  %t72 = load i32, ptr %l39
  store i32 %t72, ptr %rv
  br label %ret
bb22:
  %t73 = load i32, ptr %l1
  %t75 = trunc i64 7 to i32
  %t76 = icmp eq i32 %t73, %t75
  br i1 %t76, label %bb23, label %bb24
bb23:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t79 = load i64, ptr @G_2ecompiler_2fcheck_2eDivideByZero, !tbaa !65
  %t80 = load i64, ptr @G_2ecompiler_2fcheck_2eInvalid, !tbaa !65
  %t83 = or i64 %t79, %t80
  %t87 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echeckOp(ptr %v0, ptr %t78, i32 0, i64 %t83)
  store i32 %t87, ptr %l47
  br label %bb25
bb24:
  br label %bb26
bb25:
  %t88 = load i32, ptr %l47
  store i32 %t88, ptr %rv
  br label %ret
bb26:
  store i32 0, ptr %rv
  br label %ret
bb27:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t91 = load i32, ptr %l2, !tbaa !23
  %t94 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t90, i32 %t91)
  store i32 %t94, ptr %l51
  br label %bb28
bb28:
  %t95 = load i32, ptr %l51, !tbaa !23
  %t96 = icmp sge i32 %t95, 3
  br i1 %t96, label %bb29, label %bb30
bb29:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t99 = load i32, ptr %l2, !tbaa !23
  %t102 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t98, i32 %t99)
  store i32 %t102, ptr %l56
  br label %bb31
bb30:
  store i1 false, ptr %l53, !tbaa !21
  br label %bb32
bb31:
  %t103 = load i32, ptr %l56, !tbaa !23
  %t104 = icmp sle i32 %t103, 6
  store i1 %t104, ptr %l53, !tbaa !21
  br label %bb32
bb32:
  %t106 = load i1, ptr %l53, !tbaa !21
  store i1 %t106, ptr %l3, !tbaa !21
  %t107 = load i32, ptr %l1
  %t109 = trunc i64 3 to i32
  %t110 = icmp eq i32 %t107, %t109
  br i1 %t110, label %bb33, label %bb34
bb33:
  br label %bb41
bb34:
  %t112 = load i32, ptr %l1
  %t114 = trunc i64 4 to i32
  %t115 = icmp eq i32 %t112, %t114
  br i1 %t115, label %bb35, label %bb36
bb35:
  br label %bb41
bb36:
  %t117 = load i32, ptr %l1
  %t119 = trunc i64 5 to i32
  %t120 = icmp eq i32 %t117, %t119
  br i1 %t120, label %bb37, label %bb38
bb37:
  br label %bb41
bb38:
  %t122 = load i32, ptr %l1
  %t124 = trunc i64 0 to i32
  %t125 = icmp eq i32 %t122, %t124
  br i1 %t125, label %bb39, label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb43
bb41:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t128 = load i64, ptr @G_2ecompiler_2fcheck_2eOverflow, !tbaa !65
  %t132 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echeckOp(ptr %v0, ptr %t127, i32 0, i64 %t128)
  store i32 %t132, ptr %l70
  br label %bb42
bb42:
  %t133 = load i32, ptr %l70
  store i32 %t133, ptr %l58
  br label %bb68
bb43:
  %t134 = load i32, ptr %l1
  %t136 = trunc i64 6 to i32
  %t137 = icmp eq i32 %t134, %t136
  br i1 %t137, label %bb44, label %bb45
bb44:
  br label %bb48
bb45:
  %t139 = load i32, ptr %l1
  %t141 = trunc i64 7 to i32
  %t142 = icmp eq i32 %t139, %t141
  br i1 %t142, label %bb46, label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb53
bb48:
  %t144 = load ptr, ptr %l0, !tbaa !29
  store ptr %t144, ptr %l75, !tbaa !29
  store i32 0, ptr %l76
  %t145 = load i64, ptr @G_2ecompiler_2fcheck_2eDivideByZero, !tbaa !65
  store i64 %t145, ptr %l77, !tbaa !65
  %t146 = load i1, ptr %l3, !tbaa !21
  br i1 %t146, label %bb49, label %bb50
bb49:
  %t148 = load i64, ptr @G_2ecompiler_2fcheck_2eOverflow, !tbaa !65
  store i64 %t148, ptr %l79, !tbaa !65
  br label %bb51
bb50:
  store i64 0, ptr %l79, !tbaa !65
  br label %bb51
bb51:
  %t150 = load i64, ptr %l77, !tbaa !65
  %t151 = load i64, ptr %l79, !tbaa !65
  %t152 = or i64 %t150, %t151
  %t153 = load ptr, ptr %l75, !tbaa !29
  %t154 = load i32, ptr %l76
  %t156 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echeckOp(ptr %v0, ptr %t153, i32 %t154, i64 %t152)
  store i32 %t156, ptr %l82
  br label %bb52
bb52:
  %t157 = load i32, ptr %l82
  store i32 %t157, ptr %l58
  br label %bb68
bb53:
  %t158 = load i32, ptr %l1
  %t160 = trunc i64 8 to i32
  %t161 = icmp eq i32 %t158, %t160
  br i1 %t161, label %bb54, label %bb55
bb54:
  br label %bb56
bb55:
  br label %bb58
bb56:
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t164 = load i64, ptr @G_2ecompiler_2fcheck_2eOverflow, !tbaa !65
  %t165 = load i64, ptr @G_2ecompiler_2fcheck_2eBounds, !tbaa !65
  %t168 = or i64 %t164, %t165
  %t172 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echeckOp(ptr %v0, ptr %t163, i32 0, i64 %t168)
  store i32 %t172, ptr %l90
  br label %bb57
bb57:
  %t173 = load i32, ptr %l90
  store i32 %t173, ptr %l58
  br label %bb68
bb58:
  %t174 = load i32, ptr %l1
  %t176 = trunc i64 9 to i32
  %t177 = icmp eq i32 %t174, %t176
  br i1 %t177, label %bb59, label %bb60
bb59:
  br label %bb61
bb60:
  br label %bb63
bb61:
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t180 = load i64, ptr @G_2ecompiler_2fcheck_2eBounds, !tbaa !65
  %t184 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echeckOp(ptr %v0, ptr %t179, i32 0, i64 %t180)
  store i32 %t184, ptr %l96
  br label %bb62
bb62:
  %t185 = load i32, ptr %l96
  store i32 %t185, ptr %l58
  br label %bb68
bb63:
  br i1 true, label %bb64, label %bb65
bb64:
  br label %bb66
bb65:
  br label %bb67
bb66:
  store i32 0, ptr %l58
  br label %bb68
bb67:
  call void @__olang_check_failed(ptr @olang_loc_f7ded25ed6635e09_bde75c58edf40565)
  unreachable
bb68:
  %t187 = load i32, ptr %l58
  store i32 %t187, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayOf(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca i32
  %l12 = alloca i32
  %l15 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t6 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t2, i32 %a1)
  store i32 %t6, ptr %l6
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l3, !tbaa !29
  %t8 = load i32, ptr %l6, !tbaa !23
  %t9 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t7, i32 %t8)
  store i32 %t9, ptr %l7
  br label %bb2
bb2:
  %t10 = load i32, ptr %l7, !tbaa !23
  store i32 %t10, ptr %l2, !tbaa !23
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/check:Checker", ptr %t11, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t16 = getelementptr %"compiler/generic:Program", ptr %t14, i32 0, i32 2
  %t17 = load i32, ptr %l2, !tbaa !23
  %t20 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t16, i32 %t17)
  store i32 %t20, ptr %l12
  br label %bb3
bb3:
  %t21 = load i32, ptr %l12
  %t23 = trunc i64 19 to i32
  %t24 = icmp eq i32 %t21, %t23
  br i1 %t24, label %bb4, label %bb5
bb4:
  %t26 = load i32, ptr %l2, !tbaa !23
  store i32 %t26, ptr %l15, !tbaa !23
  br label %bb6
bb5:
  %t28 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t28, ptr %l15, !tbaa !23
  br label %bb6
bb6:
  %t30 = load i32, ptr %l15, !tbaa !23
  store i32 %t30, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aModules(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca %"compiler/load:Import"
  %l12 = alloca i1
  %l20 = alloca ptr
  %l23 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l27 = alloca i32
  %l36 = alloca { i64, ptr }
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v1, ptr %t1, i64 %t2)
  store i1 %t5, ptr %l12
  br label %bb1
bb1:
  %t6 = load i1, ptr %l12, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  br label %ret
bb3:
  br label %bb4
bb4:
  %t7 = load ptr, ptr %l2, !tbaa !29
  %t8 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v1, ptr %t7, i64 %t8, i1 true)
  br label %bb5
bb5:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/check:Checker", ptr %t11, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t16 = getelementptr %"compiler/generic:Program", ptr %t14, i32 0, i32 0
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t19 = getelementptr %"compiler/load:Loader", ptr %t17, i32 0, i32 5
  %t20 = load i64, ptr %l1, !tbaa !24
  %t23 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t19, i64 %t20)
  store ptr %t23, ptr %l20
  br label %bb6
bb6:
  %t24 = load ptr, ptr %l20, !tbaa !29
  %t26 = getelementptr %"compiler/load:Module", ptr %t24, i32 0, i32 11
  store ptr %t26, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s3
  %t28 = load ptr, ptr %l4, !tbaa !29
  %t29 = load i64, ptr %l5, !tbaa !24
  %t32 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fload_3aImport_3e_2eRunFrom_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %t28, i64 %t29)
  %t33 = extractvalue { i32, { i64, ptr } } %t32, 1
  %t34 = extractvalue { i32, { i64, ptr } } %t32, 0
  store i32 %t34, ptr %l27
  %t35 = icmp ne i32 %t34, 0
  br i1 %t35, label %bb9, label %ok.36
ok.36:
  store { i64, ptr } %t33, ptr %l26
  br label %bb8
bb8:
  %t37 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t37, ptr %l23, !tbaa !27
  br label %bb13
bb9:
  %t38 = load i32, ptr %l27, !tbaa !23
  %t39 = ashr i32 %t38, 16
  %t41 = icmp eq i32 %t39, 1
  br i1 %t41, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_8144c9e107914b58_42c61ae8c534985c)
  unreachable
bb12:
  call void @__olang_scope_close(ptr %s3)
  br label %bb25
bb13:
  %t43 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t43, ptr %l6, !tbaa !27
  %t44 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t44, 0
  store i64 %t46, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb14
bb14:
  store %olang.scope zeroinitializer, ptr %s4
  %t48 = load i64, ptr %l8, !tbaa !24
  %t49 = load i64, ptr %l7, !tbaa !24
  %t52 = icmp slt i64 %t48, %t49
  %t54 = xor i1 %t52, true
  br i1 %t54, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s4)
  br label %bb23
bb16:
  br label %bb17
bb17:
  %t56 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t56, ptr %l36, !tbaa !27
  %t57 = load i64, ptr %l8, !tbaa !24
  %t59 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = getelementptr %"compiler/load:Import", ptr %t60, i64 %t57
  %t62 = load %"compiler/load:Import", ptr %t61
  store %"compiler/load:Import" %t62, ptr %l9
  %t64 = getelementptr %"compiler/load:Import", ptr %l9, i32 0, i32 5
  %t65 = load i64, ptr %t64, !tbaa !24
  %t67 = icmp sge i64 %t65, 0
  br i1 %t67, label %bb18, label %bb19
bb18:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/load:Import", ptr %l9, i32 0, i32 5
  %t71 = load i64, ptr %t70, !tbaa !24
  %t72 = load ptr, ptr %l2, !tbaa !29
  %t73 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aModules(ptr %v0, ptr %v1, ptr %v2, ptr %t69, i64 %t71, ptr %t72, ptr %t73)
  br label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s4)
  br label %bb22
bb22:
  %t78 = load i64, ptr %l8, !tbaa !24
  %t80 = add i64 %t78, 1
  store i64 %t80, ptr %l8, !tbaa !24
  br label %bb14
bb23:
  %t82 = load i64, ptr %l5, !tbaa !24
  %t83 = load i64, ptr %l7, !tbaa !24
  %t86 = add i64 %t82, %t83
  store i64 %t86, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb24
bb24:
  br label %bb7
bb25:
  %t88 = load ptr, ptr %l3, !tbaa !29
  %t89 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v2, ptr %t88, i64 %t89)
  br label %bb26
bb26:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyErrors(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i32
  %l8 = alloca ptr
  %l11 = alloca i1
  %l15 = alloca i1
  %l16 = alloca i32
  %l22 = alloca i32
  %l26 = alloca i64
  %l33 = alloca i64
  %l35 = alloca i32
  %l39 = alloca i32
  %l40 = alloca i32
  %l41 = alloca i1
  %l45 = alloca i1
  %l46 = alloca i32
  %l48 = alloca ptr
  %l49 = alloca i64
  %l54 = alloca { i64, ptr }
  %l56 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l59 = alloca i32
  %l61 = alloca ptr
  %l64 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l65 = alloca i32
  %l66 = alloca i32
  %l68 = alloca ptr
  %l69 = alloca i64
  %l74 = alloca { i64, ptr }
  %l76 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 10
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  store ptr %t7, ptr %l8
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l8, !tbaa !29
  %t10 = getelementptr %"compiler/typed:Body", ptr %t8, i32 0, i32 2
  %t11 = load i32, ptr %t10, !tbaa !23
  store i32 %t11, ptr %l2, !tbaa !23
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/check:Checker", ptr %t13, i32 0, i32 45
  %t16 = load i64, ptr %l1, !tbaa !24
  %t19 = call { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eGet_3cI64_2c_20Bool_3e(ptr %v0, ptr %t15, i64 %t16)
  %t20 = extractvalue { i32, i1 } %t19, 1
  %t21 = extractvalue { i32, i1 } %t19, 0
  store i32 %t21, ptr %l16
  %t22 = icmp ne i32 %t21, 0
  br i1 %t22, label %bb3, label %ok.23
ok.23:
  store i1 %t20, ptr %l15
  br label %bb2
bb2:
  %t24 = load i1, ptr %l15, !tbaa !21
  store i1 %t24, ptr %l11, !tbaa !21
  br label %bb5
bb3:
  br label %bb4
bb4:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb5
bb5:
  %t25 = load i1, ptr %l11, !tbaa !21
  %t26 = xor i1 %t25, true
  br i1 %t26, label %bb6, label %bb7
bb6:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/check:Checker", ptr %t28, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t33 = getelementptr %"compiler/generic:Program", ptr %t31, i32 0, i32 2
  %t34 = load i32, ptr %l2, !tbaa !23
  %t37 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t33, i32 %t34)
  store i32 %t37, ptr %l22
  br label %bb8
bb7:
  br label %bb9
bb8:
  call void @__olang_scope_close(ptr %s0)
  %t38 = load i32, ptr %l22, !tbaa !23
  store i32 %t38, ptr %rv
  br label %ret
bb9:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/check:Checker", ptr %t39, i32 0, i32 15
  %t42 = load i64, ptr %l1, !tbaa !24
  %t45 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t41, i64 %t42)
  store i64 %t45, ptr %l26
  br label %bb10
bb10:
  %t46 = load i64, ptr %l26, !tbaa !24
  %t47 = icmp eq i64 %t46, 0
  br i1 %t47, label %bb11, label %bb12
bb11:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echeckNow(ptr %v0, ptr %t49, i64 %t50)
  br label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb14
bb14:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/check:Checker", ptr %t53, i32 0, i32 15
  %t56 = load i64, ptr %l1, !tbaa !24
  %t59 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t55, i64 %t56)
  store i64 %t59, ptr %l33
  br label %bb15
bb15:
  %t60 = load i64, ptr %l33, !tbaa !24
  %t61 = icmp eq i64 %t60, 2
  br i1 %t61, label %bb16, label %bb17
bb16:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/check:Checker", ptr %t63, i32 0, i32 46
  %t66 = load i64, ptr %l1, !tbaa !24
  %t69 = call { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftypes_3aListId_3e__H9cb5d99387f926677a92c13412f9a8b2(ptr %v0, ptr %t65, i64 %t66)
  %t70 = extractvalue { i32, i32 } %t69, 1
  %t71 = extractvalue { i32, i32 } %t69, 0
  store i32 %t71, ptr %l40
  %t72 = icmp ne i32 %t71, 0
  br i1 %t72, label %bb19, label %ok.73
ok.73:
  store i32 %t70, ptr %l39
  br label %bb18
bb17:
  br label %bb33
bb18:
  %t74 = load i32, ptr %l39, !tbaa !23
  store i32 %t74, ptr %l35, !tbaa !23
  br label %bb21
bb19:
  br label %bb20
bb20:
  store i32 0, ptr %l35, !tbaa !23
  br label %bb21
bb21:
  %t75 = load i32, ptr %l35, !tbaa !23
  store i32 %t75, ptr %l3, !tbaa !23
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/check:Checker", ptr %t76, i32 0, i32 48
  %t79 = load i64, ptr %l1, !tbaa !24
  %t82 = call { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eGet_3cI64_2c_20Bool_3e(ptr %v0, ptr %t78, i64 %t79)
  %t83 = extractvalue { i32, i1 } %t82, 1
  %t84 = extractvalue { i32, i1 } %t82, 0
  store i32 %t84, ptr %l46
  %t85 = icmp ne i32 %t84, 0
  br i1 %t85, label %bb23, label %ok.86
ok.86:
  store i1 %t83, ptr %l45
  br label %bb22
bb22:
  %t87 = load i1, ptr %l45, !tbaa !21
  store i1 %t87, ptr %l41, !tbaa !21
  br label %bb25
bb23:
  br label %bb24
bb24:
  store i1 false, ptr %l41, !tbaa !21
  br label %bb25
bb25:
  %t88 = load i1, ptr %l41, !tbaa !21
  br i1 %t88, label %bb26, label %bb27
bb26:
  store %olang.scope zeroinitializer, ptr %s4
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"compiler/check:Checker", ptr %t89, i32 0, i32 47
  store ptr %t91, ptr %l48, !tbaa !29
  %t92 = load i64, ptr %l1, !tbaa !24
  store i64 %t92, ptr %l49, !tbaa !24
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/check:Checker", ptr %t93, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !29
  %t98 = getelementptr %"compiler/generic:Program", ptr %t96, i32 0, i32 2
  %t99 = load i32, ptr %l3, !tbaa !23
  %t102 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t98, i32 %t99)
  store { i64, ptr } %t102, ptr %l54
  br label %bb28
bb27:
  br label %bb32
bb28:
  %t103 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t104 = extractvalue { i64, ptr } %t103, 0
  %t105 = load i64, ptr %l49, !tbaa !24
  %t107 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s4, i64 %t105, i64 %t104)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t107, ptr %l56
  br label %bb29
bb29:
  %t108 = load ptr, ptr %l48, !tbaa !29
  %t109 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l56
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_Hb6f924c91b81223120b2cba278ece4a6(ptr %v0, ptr %t108, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t109)
  br label %bb30
bb30:
  %t110 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunsettle(ptr %v0, ptr %t110)
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s4)
  br label %bb32
bb32:
  %t112 = load i32, ptr %l3, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t112, ptr %rv
  br label %ret
bb33:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t116 = getelementptr %"compiler/check:Checker", ptr %t114, i32 0, i32 49
  store ptr %t116, ptr %l61, !tbaa !29
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t118 = load i64, ptr %l1, !tbaa !24
  %t121 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyKey(ptr %v0, ptr %t117, i64 %t118)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t121, ptr %l64
  br label %bb34
bb34:
  %t122 = load ptr, ptr %l61, !tbaa !29
  %t123 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l64
  %t124 = call { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_Hf3bb75ba9d3f922b4d327e9d3c1adfb0(ptr %v0, ptr %t122, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t123)
  %t125 = extractvalue { i32, i32 } %t124, 1
  %t126 = extractvalue { i32, i32 } %t124, 0
  store i32 %t126, ptr %l66
  %t127 = icmp ne i32 %t126, 0
  br i1 %t127, label %bb36, label %ok.128
ok.128:
  store i32 %t125, ptr %l65
  br label %bb35
bb35:
  %t129 = load i32, ptr %l65, !tbaa !23
  store i32 %t129, ptr %l59, !tbaa !23
  br label %bb38
bb36:
  br label %bb37
bb37:
  store i32 0, ptr %l59, !tbaa !23
  br label %bb38
bb38:
  %t130 = load i32, ptr %l59, !tbaa !23
  store i32 %t130, ptr %l4, !tbaa !23
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t133 = getelementptr %"compiler/check:Checker", ptr %t131, i32 0, i32 47
  store ptr %t133, ptr %l68, !tbaa !29
  %t134 = load i64, ptr %l1, !tbaa !24
  store i64 %t134, ptr %l69, !tbaa !24
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t137 = getelementptr %"compiler/check:Checker", ptr %t135, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !29
  %t140 = getelementptr %"compiler/generic:Program", ptr %t138, i32 0, i32 2
  %t141 = load i32, ptr %l4, !tbaa !23
  %t144 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t140, i32 %t141)
  store { i64, ptr } %t144, ptr %l74
  br label %bb39
bb39:
  %t145 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t146 = extractvalue { i64, ptr } %t145, 0
  %t147 = load i64, ptr %l69, !tbaa !24
  %t149 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %t147, i64 %t146)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t149, ptr %l76
  br label %bb40
bb40:
  %t150 = load ptr, ptr %l68, !tbaa !29
  %t151 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l76
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_Hb6f924c91b81223120b2cba278ece4a6(ptr %v0, ptr %t150, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t151)
  br label %bb41
bb41:
  %t152 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunsettle(ptr %v0, ptr %t152)
  br label %bb42
bb42:
  %t154 = load i32, ptr %l4, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t154, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebranchBlock(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l18 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Branch", ptr %t1, i32 0, i32 2
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = icmp sge i64 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/check:Checker", ptr %t8, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t13 = getelementptr %"compiler/generic:Program", ptr %t11, i32 0, i32 0
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t16 = getelementptr %"compiler/load:Loader", ptr %t14, i32 0, i32 4
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t18 = load ptr, ptr %l1, !tbaa !29
  %t20 = getelementptr %"compiler/ast:Branch", ptr %t18, i32 0, i32 2
  %t21 = load i64, ptr %t20, !tbaa !24
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eReopen(ptr %v0, ptr %t17, i64 %t21)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr %"compiler/ast:Branch", ptr %t25, i32 0, i32 1
  %t28 = load { i64, ptr }, ptr %t27, !tbaa !27
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t31 = getelementptr %"compiler/ast:Branch", ptr %t29, i32 0, i32 0
  %t32 = load %"compiler/source:Span", ptr %t31
  %t37 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eblockOf(ptr %v0, ptr %v1, ptr %t24, { i64, ptr } %t28, i32 1, %"compiler/source:Span" %t32)
  store ptr %t37, ptr %l18
  br label %bb5
bb5:
  %t38 = load ptr, ptr %l18, !tbaa !29
  store ptr %t38, ptr %l2, !tbaa !29
  %t39 = load ptr, ptr %l1, !tbaa !29
  %t41 = getelementptr %"compiler/ast:Branch", ptr %t39, i32 0, i32 2
  %t42 = load i64, ptr %t41, !tbaa !24
  %t44 = icmp sge i64 %t42, 0
  br i1 %t44, label %bb6, label %bb7
bb6:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/check:Checker", ptr %t46, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t51 = getelementptr %"compiler/generic:Program", ptr %t49, i32 0, i32 0
  %t52 = load ptr, ptr %t51, !tbaa !29
  %t54 = getelementptr %"compiler/load:Loader", ptr %t52, i32 0, i32 4
  %t55 = load ptr, ptr %t54, !tbaa !29
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eEndHold(ptr %v0, ptr %t55)
  br label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t57 = load ptr, ptr %l2, !tbaa !29
  store ptr %t57, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseCompare(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l14 = alloca ptr
  %l17 = alloca i32
  %l23 = alloca ptr
  %l26 = alloca i32
  %l29 = alloca i1
  %l31 = alloca ptr
  %l33 = alloca %"compiler/source:Span"
  %l34 = alloca ptr
  %l36 = alloca ptr
  %l37 = alloca %"compiler/source:Span"
  %l38 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l43 = alloca %"compiler/msgs:Msg"
  %l44 = alloca i64
  %l47 = alloca ptr
  %l48 = alloca ptr
  %l50 = alloca ptr
  %l52 = alloca i64
  %l54 = alloca ptr
  %l56 = alloca %"compiler/source:Span"
  %l57 = alloca ptr
  %l59 = alloca ptr
  %l60 = alloca %"compiler/source:Span"
  %l61 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  %l66 = alloca %"compiler/msgs:Msg"
  %l67 = alloca i64
  %l70 = alloca ptr
  %l72 = alloca ptr
  %l75 = alloca %"compiler/source:Span"
  %l76 = alloca i32
  %l77 = alloca ptr
  %l81 = alloca i32
  %l84 = alloca ptr
  %l85 = alloca ptr
  %l90 = alloca ptr
  %l93 = alloca ptr
  %l97 = alloca ptr
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca ptr
  %t146 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t8 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %t1, ptr %a3, i32 %t4)
  store ptr %t8, ptr %l14
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l14, !tbaa !29
  store ptr %t9, ptr %l5, !tbaa !29
  %t10 = load ptr, ptr %l5, !tbaa !29
  %t13 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t10)
  store i32 %t13, ptr %l17
  br label %bb2
bb2:
  %t14 = load i32, ptr %l17, !tbaa !23
  store i32 %t14, ptr %l6, !tbaa !23
  %t15 = load i32, ptr %l6, !tbaa !23
  %t16 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t19 = icmp eq i32 %t15, %t16
  br i1 %t19, label %bb3, label %bb4
bb3:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load %"compiler/source:Span", ptr %l1
  %t25 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t21, %"compiler/source:Span" %t22)
  store ptr %t25, ptr %l23
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t26 = load ptr, ptr %l23, !tbaa !29
  store ptr %t26, ptr %rv
  br label %ret
bb6:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load i32, ptr %l6, !tbaa !23
  %t31 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t27, i32 %t28)
  store i32 %t31, ptr %l26
  br label %bb7
bb7:
  %t32 = load i32, ptr %l26, !tbaa !23
  store i32 %t32, ptr %l7, !tbaa !23
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load i32, ptr %l7, !tbaa !23
  %t37 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %t33, i32 %t34)
  store i1 %t37, ptr %l29
  br label %bb8
bb8:
  %t38 = load i1, ptr %l29, !tbaa !21
  %t39 = xor i1 %t38, true
  br i1 %t39, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t41 = load ptr, ptr %l0, !tbaa !29
  store ptr %t41, ptr %l31, !tbaa !29
  %t42 = load ptr, ptr %l4, !tbaa !29
  %t44 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t42)
  store %"compiler/source:Span" %t44, ptr %l33
  br label %bb11
bb10:
  br label %bb19
bb11:
  %t45 = load ptr, ptr %l0, !tbaa !29
  store ptr %t45, ptr %l34, !tbaa !29
  %t46 = load ptr, ptr %l4, !tbaa !29
  %t48 = call ptr @compiler_2fcheck_2ecasePath(ptr %v2, ptr %t46)
  store ptr %t48, ptr %l36
  br label %bb12
bb12:
  %t49 = load ptr, ptr %l36, !tbaa !29
  %t50 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t49)
  store %"compiler/source:Span" %t50, ptr %l37
  br label %bb13
bb13:
  %t51 = load ptr, ptr %l34, !tbaa !29
  %t52 = load %"compiler/source:Span", ptr %l37
  %t53 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %t51, %"compiler/source:Span" %t52)
  store { i64, ptr } %t53, ptr %l38
  br label %bb14
bb14:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load i32, ptr %l7, !tbaa !23
  %t58 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s2, ptr %t54, i32 %t55)
  store { i64, ptr } %t58, ptr %l41
  br label %bb15
bb15:
  %t59 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t60 = extractvalue { i64, ptr } %t59, 0
  %t61 = extractvalue { i64, ptr } %t59, 1
  %t62 = mul i64 %t60, 1
  %t63 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t62)
  call void @llvm.memcpy.p0.p0.i64(ptr %t63, ptr %t61, i64 %t62, i1 false)
  %t64 = insertvalue { i64, ptr } undef, i64 %t60, 0
  %t65 = insertvalue { i64, ptr } %t64, ptr %t63, 1
  %t66 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t68 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaseTestNotEnum(ptr %v0, ptr %s2, ptr %s2, { i64, ptr } %t66, { i64, ptr } %t65)
  store %"compiler/msgs:Msg" %t68, ptr %l43
  br label %bb16
bb16:
  %t69 = load ptr, ptr %l31, !tbaa !29
  %t70 = load %"compiler/source:Span", ptr %l33
  %t71 = load %"compiler/msgs:Msg", ptr %l43
  %t72 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s2, ptr %t69, %"compiler/source:Span" %t70, %"compiler/msgs:Msg" %t71)
  store i64 %t72, ptr %l44
  br label %bb17
bb17:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t74 = load %"compiler/source:Span", ptr %l1
  %t77 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t73, %"compiler/source:Span" %t74)
  store ptr %t77, ptr %l47
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s2)
  %t78 = load ptr, ptr %l47, !tbaa !29
  store ptr %t78, ptr %rv
  br label %ret
bb19:
  %t79 = load ptr, ptr %l0, !tbaa !29
  store ptr %t79, ptr %l48, !tbaa !29
  %t80 = load ptr, ptr %l4, !tbaa !29
  %t82 = call ptr @compiler_2fcheck_2ecasePath(ptr %v2, ptr %t80)
  store ptr %t82, ptr %l50
  br label %bb20
bb20:
  %t83 = load i32, ptr %l7, !tbaa !23
  %t84 = load ptr, ptr %l48, !tbaa !29
  %t85 = load ptr, ptr %l50, !tbaa !29
  %t87 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseTag(ptr %v0, ptr %v2, ptr %t84, ptr %t85, i32 %t83)
  store i64 %t87, ptr %l52
  br label %bb21
bb21:
  %t88 = load i64, ptr %l52, !tbaa !24
  %t89 = icmp slt i64 %t88, 0
  br i1 %t89, label %bb22, label %bb23
bb22:
  store %olang.scope zeroinitializer, ptr %s3
  %t91 = load ptr, ptr %l0, !tbaa !29
  store ptr %t91, ptr %l54, !tbaa !29
  %t92 = load ptr, ptr %l4, !tbaa !29
  %t94 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t92)
  store %"compiler/source:Span" %t94, ptr %l56
  br label %bb24
bb23:
  br label %bb32
bb24:
  %t95 = load ptr, ptr %l0, !tbaa !29
  store ptr %t95, ptr %l57, !tbaa !29
  %t96 = load ptr, ptr %l4, !tbaa !29
  %t98 = call ptr @compiler_2fcheck_2ecasePath(ptr %v2, ptr %t96)
  store ptr %t98, ptr %l59
  br label %bb25
bb25:
  %t99 = load ptr, ptr %l59, !tbaa !29
  %t100 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t99)
  store %"compiler/source:Span" %t100, ptr %l60
  br label %bb26
bb26:
  %t101 = load ptr, ptr %l57, !tbaa !29
  %t102 = load %"compiler/source:Span", ptr %l60
  %t103 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %t101, %"compiler/source:Span" %t102)
  store { i64, ptr } %t103, ptr %l61
  br label %bb27
bb27:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t105 = load i32, ptr %l7, !tbaa !23
  %t108 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s3, ptr %t104, i32 %t105)
  store { i64, ptr } %t108, ptr %l64
  br label %bb28
bb28:
  %t109 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t110 = extractvalue { i64, ptr } %t109, 0
  %t111 = extractvalue { i64, ptr } %t109, 1
  %t112 = mul i64 %t110, 1
  %t113 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t112)
  call void @llvm.memcpy.p0.p0.i64(ptr %t113, ptr %t111, i64 %t112, i1 false)
  %t114 = insertvalue { i64, ptr } undef, i64 %t110, 0
  %t115 = insertvalue { i64, ptr } %t114, ptr %t113, 1
  %t116 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t118 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaseTestOther(ptr %v0, ptr %s3, ptr %s3, { i64, ptr } %t116, { i64, ptr } %t115)
  store %"compiler/msgs:Msg" %t118, ptr %l66
  br label %bb29
bb29:
  %t119 = load ptr, ptr %l54, !tbaa !29
  %t120 = load %"compiler/source:Span", ptr %l56
  %t121 = load %"compiler/msgs:Msg", ptr %l66
  %t122 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s3, ptr %t119, %"compiler/source:Span" %t120, %"compiler/msgs:Msg" %t121)
  store i64 %t122, ptr %l67
  br label %bb30
bb30:
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t124 = load %"compiler/source:Span", ptr %l1
  %t127 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t123, %"compiler/source:Span" %t124)
  store ptr %t127, ptr %l70
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s3)
  %t128 = load ptr, ptr %l70, !tbaa !29
  store ptr %t128, ptr %rv
  br label %ret
bb32:
  %t129 = load ptr, ptr %l5, !tbaa !29
  %t131 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v0, ptr %t129)
  store ptr %t131, ptr %l72
  br label %bb33
bb33:
  %t132 = load ptr, ptr %l72, !tbaa !29
  store ptr %t132, ptr %l8, !tbaa !29
  %t133 = load ptr, ptr %l8, !tbaa !29
  %t135 = icmp eq ptr %t133, null
  br i1 %t135, label %bb34, label %bb35
bb34:
  %t137 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t137, ptr %l75
  %t138 = load i32, ptr %l6, !tbaa !23
  store i32 %t138, ptr %l76, !tbaa !23
  %t139 = load ptr, ptr %l5, !tbaa !29
  store ptr %t139, ptr %l77, !tbaa !29
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t141 = load %"compiler/source:Span", ptr %l1
  %t145 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %t140, i32 8, %"compiler/source:Span" %t141)
  store i32 %t145, ptr %l81
  br label %bb36
bb35:
  br label %bb37
bb36:
  store { i64, [4 x i64] } zeroinitializer, ptr %t146
  %t147 = getelementptr { i64, [4 x i64] }, ptr %t146, i32 0, i32 0
  store i64 6, ptr %t147
  %t148 = load %"compiler/source:Span", ptr %l75
  %t149 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } undef, %"compiler/source:Span" %t148, 0
  %t150 = load i32, ptr %l76, !tbaa !23
  %t151 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t149, i32 %t150, 1
  %t152 = load ptr, ptr %l77, !tbaa !29
  %t153 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t151, ptr %t152, 2
  %t154 = load i32, ptr %l81, !tbaa !23
  %t155 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t153, i32 %t154, 3
  %t156 = getelementptr { i64, [4 x i64] }, ptr %t146, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i32 } %t155, ptr %t156
  %t157 = load { i64, [4 x i64] }, ptr %t146
  %t159 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t157, ptr %t159
  store ptr %t159, ptr %l8, !tbaa !29
  br label %bb37
bb37:
  %t161 = load ptr, ptr %l0, !tbaa !29
  store ptr %t161, ptr %l84, !tbaa !29
  %t162 = load ptr, ptr %l4, !tbaa !29
  store ptr %t162, ptr %l85, !tbaa !29
  %t163 = load ptr, ptr %l8, !tbaa !29
  %t165 = icmp eq ptr %t163, null
  br i1 %t165, label %bb38, label %bb39
bb38:
  call void @__olang_check_failed(ptr @olang_loc_e1487403b47c0485_2c2fc5ff7a99fd49)
  unreachable
bb39:
  br label %bb40
bb40:
  %t167 = load ptr, ptr %l8, !tbaa !29
  %t168 = load i32, ptr %l6, !tbaa !23
  %t169 = load ptr, ptr %l84, !tbaa !29
  %t170 = load ptr, ptr %l85, !tbaa !29
  %t173 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseTest(ptr %v0, ptr %v2, ptr %t169, ptr %t170, ptr %t167, i32 %t168)
  store ptr %t173, ptr %l90
  br label %bb41
bb41:
  %t174 = load ptr, ptr %l90, !tbaa !29
  store ptr %t174, ptr %l9, !tbaa !29
  %t177 = trunc i64 75 to i32
  %t178 = icmp eq i32 %a2, %t177
  br i1 %t178, label %bb42, label %bb43
bb42:
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t181 = load %"compiler/source:Span", ptr %l1
  %t182 = load ptr, ptr %l9, !tbaa !29
  %t186 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enegate(ptr %v0, ptr %t180, %"compiler/source:Span" %t181, ptr %t182)
  store ptr %t186, ptr %l97
  br label %bb44
bb43:
  %t187 = load ptr, ptr %l9, !tbaa !29
  store ptr %t187, ptr %l93, !tbaa !29
  br label %bb45
bb44:
  %t189 = load ptr, ptr %l97, !tbaa !29
  store ptr %t189, ptr %l93, !tbaa !29
  br label %bb45
bb45:
  %t190 = load ptr, ptr %l93, !tbaa !29
  store ptr %t190, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseTag(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca %"compiler/source:Span"
  %l16 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca i1
  %l29 = alloca i32
  %l32 = alloca i1
  %l38 = alloca i1
  %l42 = alloca i1
  %l47 = alloca i32
  %l52 = alloca i32
  %l59 = alloca { i64, ptr }
  %l69 = alloca i64
  %l72 = alloca i64
  %l90 = alloca { i64, ptr }
  %l96 = alloca %"compiler/source:Span"
  %l97 = alloca ptr
  %l98 = alloca i32
  %l99 = alloca i32
  %l100 = alloca i32
  %l103 = alloca { i64, ptr }
  %l108 = alloca %"compiler/source:Span"
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  %t5 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l16
  br label %bb1
bb1:
  %t6 = load i1, ptr %l16, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  store i64 -1, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t10 = load ptr, ptr %l1, !tbaa !29
  store ptr %t10, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t11 = load ptr, ptr %l19, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb5, label %bb6
bb5:
  %t14 = load ptr, ptr %l19, !tbaa !29
  %t15 = load i64, ptr %t14
  %t17 = icmp eq i64 %t15, 15
  store i1 %t17, ptr %l20, !tbaa !21
  br label %bb6
bb6:
  %t18 = load i1, ptr %l20, !tbaa !21
  br i1 %t18, label %bb7, label %bb8
bb7:
  %t19 = load ptr, ptr %l1, !tbaa !29
  %t21 = getelementptr { i64, [5 x i64] }, ptr %t19, i32 0, i32 1
  %t22 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t21, i32 0, i32 1
  %t23 = load ptr, ptr %t22
  store ptr %t23, ptr %l3, !tbaa !29
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [5 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t27, i32 0, i32 2
  %t29 = load i32, ptr %t28
  store i32 %t29, ptr %l4, !tbaa !23
  br label %bb9
bb8:
  br label %bb49
bb9:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load ptr, ptr %l3, !tbaa !29
  %t35 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeNamed(ptr %v0, ptr %v1, ptr %t31, ptr %t32)
  store i32 %t35, ptr %l29
  br label %bb10
bb10:
  %t36 = load i32, ptr %l29, !tbaa !23
  store i32 %t36, ptr %l5, !tbaa !23
  %t37 = load i32, ptr %l5, !tbaa !23
  %t39 = icmp slt i32 %t37, 0
  br i1 %t39, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l32, !tbaa !21
  br label %bb14
bb12:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/check:Checker", ptr %t41, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !29
  %t46 = getelementptr %"compiler/generic:Program", ptr %t44, i32 0, i32 2
  %t47 = load i32, ptr %l5, !tbaa !23
  %t48 = load i32, ptr %l2, !tbaa !23
  %t52 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t46, i32 %t47, i32 %t48)
  store i1 %t52, ptr %l38
  br label %bb13
bb13:
  %t53 = load i1, ptr %l38, !tbaa !21
  %t54 = xor i1 %t53, true
  store i1 %t54, ptr %l32, !tbaa !21
  br label %bb14
bb14:
  %t56 = load i1, ptr %l32, !tbaa !21
  br i1 %t56, label %bb15, label %bb16
bb15:
  %t57 = load i32, ptr %l5, !tbaa !23
  %t59 = icmp slt i32 %t57, 0
  br i1 %t59, label %bb17, label %bb18
bb16:
  br label %bb25
bb17:
  store i1 true, ptr %l42, !tbaa !21
  br label %bb21
bb18:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/check:Checker", ptr %t61, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !29
  %t66 = getelementptr %"compiler/generic:Program", ptr %t64, i32 0, i32 2
  %t67 = load i32, ptr %l5, !tbaa !23
  %t70 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t66, i32 %t67)
  store i32 %t70, ptr %l47
  br label %bb19
bb19:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/check:Checker", ptr %t71, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !29
  %t76 = getelementptr %"compiler/generic:Program", ptr %t74, i32 0, i32 2
  %t77 = load i32, ptr %l2, !tbaa !23
  %t80 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t76, i32 %t77)
  store i32 %t80, ptr %l52
  br label %bb20
bb20:
  %t81 = load i32, ptr %l47, !tbaa !23
  %t82 = load i32, ptr %l52, !tbaa !23
  %t83 = icmp ne i32 %t81, %t82
  store i1 %t83, ptr %l42, !tbaa !21
  br label %bb21
bb21:
  %t85 = load i1, ptr %l42, !tbaa !21
  br i1 %t85, label %bb22, label %bb23
bb22:
  store i64 -1, ptr %rv
  br label %ret
bb23:
  br label %bb24
bb24:
  br label %bb25
bb25:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/check:Checker", ptr %t87, i32 0, i32 1
  %t90 = load ptr, ptr %t89, !tbaa !29
  %t92 = getelementptr %"compiler/generic:Program", ptr %t90, i32 0, i32 2
  %t93 = load i32, ptr %l2, !tbaa !23
  %t96 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCaseNames(ptr %v0, ptr %t92, i32 %t93)
  store { i64, ptr } %t96, ptr %l59
  br label %bb26
bb26:
  %t97 = load { i64, ptr }, ptr %l59, !tbaa !27
  store { i64, ptr } %t97, ptr %l6, !tbaa !27
  %t98 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t100 = extractvalue { i64, ptr } %t98, 0
  %t102 = icmp eq i64 %t100, 0
  br i1 %t102, label %bb27, label %bb28
bb27:
  store i64 -1, ptr %rv
  br label %ret
bb28:
  br label %bb29
bb29:
  store i64 0, ptr %l7, !tbaa !24
  %t105 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t107 = extractvalue { i64, ptr } %t105, 0
  store i64 %t107, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t109 = load i64, ptr %l8, !tbaa !24
  %t110 = load i64, ptr %l7, !tbaa !24
  %t113 = icmp sgt i64 %t109, %t110
  br i1 %t113, label %bb30, label %bb31
bb30:
  %t115 = load i64, ptr %l9, !tbaa !24
  %t117 = icmp sgt i64 %t115, 0
  br i1 %t117, label %bb32, label %bb33
bb31:
  store i64 0, ptr %l69, !tbaa !24
  br label %bb35
bb32:
  %t119 = load i64, ptr %l8, !tbaa !24
  %t120 = load i64, ptr %l7, !tbaa !24
  %t123 = sub i64 %t119, %t120
  %t124 = load i64, ptr %l9, !tbaa !24
  %t127 = add i64 %t123, %t124
  %t129 = sub i64 %t127, 1
  %t130 = load i64, ptr %l9, !tbaa !24
  %t133 = sdiv i64 %t129, %t130
  store i64 %t133, ptr %l72, !tbaa !24
  br label %bb34
bb33:
  store i64 0, ptr %l72, !tbaa !24
  br label %bb34
bb34:
  %t135 = load i64, ptr %l72, !tbaa !24
  store i64 %t135, ptr %l69, !tbaa !24
  br label %bb35
bb35:
  %t136 = load i64, ptr %l69, !tbaa !24
  store i64 %t136, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb36
bb36:
  store %olang.scope zeroinitializer, ptr %s7
  %t137 = load i64, ptr %l11, !tbaa !24
  %t138 = load i64, ptr %l10, !tbaa !24
  %t141 = icmp slt i64 %t137, %t138
  %t143 = xor i1 %t141, true
  br i1 %t143, label %bb37, label %bb38
bb37:
  call void @__olang_scope_close(ptr %s7)
  br label %bb48
bb38:
  br label %bb39
bb39:
  %t145 = load i64, ptr %l7, !tbaa !24
  %t146 = load i64, ptr %l11, !tbaa !24
  %t147 = load i64, ptr %l9, !tbaa !24
  %t150 = mul i64 %t146, %t147
  %t153 = add i64 %t145, %t150
  store i64 %t153, ptr %l12, !tbaa !24
  %t155 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t155, ptr %l90, !tbaa !27
  %t156 = load i64, ptr %l12, !tbaa !24
  %t158 = getelementptr { i64, ptr }, ptr %l90, i32 0, i32 1
  %t159 = load ptr, ptr %t158, !tbaa !27
  %t160 = getelementptr i32, ptr %t159, i64 %t156
  %t161 = load i32, ptr %t160, !tbaa !33
  %t162 = load i32, ptr %l4, !tbaa !23
  %t165 = icmp eq i32 %t161, %t162
  br i1 %t165, label %bb40, label %bb41
bb40:
  store %olang.scope zeroinitializer, ptr %s8
  %t167 = load ptr, ptr %l1, !tbaa !29
  %t169 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t167)
  store %"compiler/source:Span" %t169, ptr %l96
  br label %bb42
bb41:
  br label %bb46
bb42:
  %t170 = load %"compiler/source:Span", ptr %l96
  store %"compiler/source:Span" %t170, ptr %l13
  %t171 = load ptr, ptr %l0, !tbaa !29
  store ptr %t171, ptr %l97, !tbaa !29
  %t172 = load i32, ptr %l2, !tbaa !23
  store i32 %t172, ptr %l98, !tbaa !23
  %t173 = load i32, ptr %l4, !tbaa !23
  store i32 %t173, ptr %l99, !tbaa !23
  %t174 = getelementptr %"compiler/source:Span", ptr %l13, i32 0, i32 1
  %t175 = load i32, ptr %t174, !tbaa !23
  store i32 %t175, ptr %l100, !tbaa !23
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t177 = load i32, ptr %l4, !tbaa !23
  %t180 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t176, i32 %t177)
  store { i64, ptr } %t180, ptr %l103
  br label %bb43
bb43:
  %t181 = load { i64, ptr }, ptr %l103, !tbaa !27
  %t182 = extractvalue { i64, ptr } %t181, 0
  %t184 = trunc i64 %t182 to i32
  %t185 = load i32, ptr %l100, !tbaa !23
  %t187 = sub i32 %t185, %t184
  %t188 = getelementptr %"compiler/source:Span", ptr %l13, i32 0, i32 1
  %t189 = load i32, ptr %t188, !tbaa !23
  %t192 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s8, i32 %t187, i32 %t189)
  store %"compiler/source:Span" %t192, ptr %l108
  br label %bb44
bb44:
  %t193 = load ptr, ptr %l97, !tbaa !29
  %t194 = load i32, ptr %l98, !tbaa !23
  %t195 = load i32, ptr %l99, !tbaa !23
  %t196 = load %"compiler/source:Span", ptr %l108
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecasePublic(ptr %v0, ptr %t193, i32 %t194, i32 %t195, %"compiler/source:Span" %t196)
  br label %bb45
bb45:
  %t197 = load i64, ptr %l12, !tbaa !24
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s7)
  store i64 %t197, ptr %rv
  br label %ret
bb46:
  call void @__olang_scope_close(ptr %s7)
  br label %bb47
bb47:
  %t199 = load i64, ptr %l11, !tbaa !24
  %t201 = add i64 %t199, 1
  store i64 %t201, ptr %l11, !tbaa !24
  br label %bb36
bb48:
  store i64 -1, ptr %rv
  br label %ret
bb49:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecatchItem(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca { i64, i32 }
  %l5 = alloca i64
  %l6 = alloca i32
  %l8 = alloca ptr
  %l10 = alloca ptr
  %l14 = alloca i32
  %l18 = alloca ptr
  %l20 = alloca %"compiler/typed:Item"
  %l23 = alloca { i64, i32 }
  %l31 = alloca ptr
  %l34 = alloca %"compiler/typed:Item"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l8, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t5)
  store ptr %t7, ptr %l10
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l10, !tbaa !29
  %t10 = getelementptr %"compiler/check:frame", ptr %t8, i32 0, i32 4
  %t11 = load ptr, ptr %l1, !tbaa !29
  %t12 = load ptr, ptr %l8, !tbaa !29
  %t15 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorType(ptr %v0, ptr %v0, ptr %v1, ptr %t12, ptr %t10, ptr %t11)
  store i32 %t15, ptr %l14
  br label %bb2
bb2:
  %t16 = load i32, ptr %l14, !tbaa !23
  store i32 %t16, ptr %l3, !tbaa !23
  %t17 = load i32, ptr %l3, !tbaa !23
  %t18 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t21 = icmp ne i32 %t17, %t18
  br i1 %t21, label %bb3, label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t23 = load ptr, ptr %l2, !tbaa !29
  store ptr %t23, ptr %l18, !tbaa !29
  %t24 = load i32, ptr %l3, !tbaa !23
  %t26 = call %"compiler/typed:Item" @compiler_2ftyped_3aItem_2ector(ptr %s1, i32 %t24, i64 -1)
  store %"compiler/typed:Item" %t26, ptr %l20
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t27 = load ptr, ptr %l18, !tbaa !29
  %t28 = load %"compiler/typed:Item", ptr %l20
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aItem_3e_2ePush_3ccompiler_2ftyped_3aItem_3e(ptr %v2, ptr %t27, %"compiler/typed:Item" %t28)
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb7:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t30 = load ptr, ptr %l1, !tbaa !29
  %t33 = call { i64, i32 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrorWord(ptr %v0, ptr %v1, ptr %t29, ptr %t30)
  store { i64, i32 } %t33, ptr %l23
  br label %bb8
bb8:
  %t34 = load { i64, i32 }, ptr %l23
  store { i64, i32 } %t34, ptr %l4
  %t35 = getelementptr { i64, i32 }, ptr %l4, i32 0, i32 0
  %t36 = load i64, ptr %t35, !tbaa !24
  store i64 %t36, ptr %l5, !tbaa !24
  %t38 = getelementptr { i64, i32 }, ptr %l4, i32 0, i32 1
  %t39 = load i32, ptr %t38, !tbaa !23
  store i32 %t39, ptr %l6, !tbaa !23
  %t41 = load i64, ptr %l5, !tbaa !24
  %t43 = icmp slt i64 %t41, 0
  br i1 %t43, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t46 = load ptr, ptr %l1, !tbaa !29
  %t48 = getelementptr %"compiler/ast:Path", ptr %t46, i32 0, i32 0
  %t49 = load %"compiler/source:Span", ptr %t48
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %s2, ptr %t45, %"compiler/source:Span" %t49, { i64, ptr } { i64 36, ptr @.d0 })
  br label %bb11
bb10:
  br label %bb12
bb11:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb12:
  %t52 = load ptr, ptr %l2, !tbaa !29
  store ptr %t52, ptr %l31, !tbaa !29
  %t53 = load i32, ptr %l6, !tbaa !23
  %t54 = load i64, ptr %l5, !tbaa !24
  %t57 = call %"compiler/typed:Item" @compiler_2ftyped_3aItem_2ector(ptr %s0, i32 %t53, i64 %t54)
  store %"compiler/typed:Item" %t57, ptr %l34
  br label %bb13
bb13:
  %t58 = load ptr, ptr %l31, !tbaa !29
  %t59 = load %"compiler/typed:Item", ptr %l34
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aItem_3e_2ePush_3ccompiler_2ftyped_3aItem_3e(ptr %v2, ptr %t58, %"compiler/typed:Item" %t59)
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclauseRules(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, ptr %a2, i1 %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l20 = alloca i1
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca %"compiler/typed:Item"
  %l26 = alloca i1
  %l27 = alloca i1
  %l28 = alloca i64
  %l38 = alloca i64
  %l41 = alloca i64
  %l59 = alloca { i64, ptr }
  %l64 = alloca ptr
  %l67 = alloca i1
  %l72 = alloca ptr
  %l75 = alloca ptr
  %l78 = alloca %"compiler/source:Span"
  %l79 = alloca %"compiler/msgs:Msg"
  %l80 = alloca i64
  %l84 = alloca i1
  %l88 = alloca i1
  %l93 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l98 = alloca i64
  %l101 = alloca i64
  %l119 = alloca ptr
  %l122 = alloca ptr
  %l133 = alloca { i64, ptr }
  %l138 = alloca i1
  %l141 = alloca i32
  %l147 = alloca i64
  %l149 = alloca i32
  %l153 = alloca i32
  %l159 = alloca ptr
  %l162 = alloca %"compiler/source:Span"
  %l163 = alloca %"compiler/msgs:Msg"
  %l164 = alloca i64
  %l173 = alloca ptr
  %l176 = alloca %"compiler/source:Span"
  %l177 = alloca %"compiler/msgs:Msg"
  %l178 = alloca i64
  %l184 = alloca ptr
  %l187 = alloca %"compiler/source:Span"
  %l188 = alloca %"compiler/msgs:Msg"
  %l189 = alloca i64
  %l195 = alloca i1
  %l201 = alloca i1
  %l203 = alloca i1
  %l205 = alloca ptr
  %l208 = alloca %"compiler/source:Span"
  %l209 = alloca %"compiler/msgs:Msg"
  %l210 = alloca i64
  %l214 = alloca i1
  %l221 = alloca i1
  %l224 = alloca i1
  %l225 = alloca ptr
  %l228 = alloca %"compiler/source:Span"
  %l229 = alloca %"compiler/msgs:Msg"
  %l230 = alloca i64
  %l233 = alloca i1
  %l238 = alloca i32
  %l243 = alloca ptr
  %l248 = alloca i32
  %l249 = alloca { i64, ptr }
  %l256 = alloca ptr
  %l259 = alloca %"compiler/source:Span"
  %l264 = alloca %"compiler/msgs:Msg"
  %l265 = alloca i64
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i32 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  store i64 0, ptr %l5, !tbaa !24
  %t8 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t8, 0
  store i64 %t10, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t12 = load i64, ptr %l6, !tbaa !24
  %t13 = load i64, ptr %l5, !tbaa !24
  %t16 = icmp sgt i64 %t12, %t13
  br i1 %t16, label %bb4, label %bb5
bb4:
  %t18 = load i64, ptr %l7, !tbaa !24
  %t20 = icmp sgt i64 %t18, 0
  br i1 %t20, label %bb6, label %bb7
bb5:
  store i64 0, ptr %l38, !tbaa !24
  br label %bb9
bb6:
  %t22 = load i64, ptr %l6, !tbaa !24
  %t23 = load i64, ptr %l5, !tbaa !24
  %t26 = sub i64 %t22, %t23
  %t27 = load i64, ptr %l7, !tbaa !24
  %t30 = add i64 %t26, %t27
  %t32 = sub i64 %t30, 1
  %t33 = load i64, ptr %l7, !tbaa !24
  %t36 = sdiv i64 %t32, %t33
  store i64 %t36, ptr %l41, !tbaa !24
  br label %bb8
bb7:
  store i64 0, ptr %l41, !tbaa !24
  br label %bb8
bb8:
  %t38 = load i64, ptr %l41, !tbaa !24
  store i64 %t38, ptr %l38, !tbaa !24
  br label %bb9
bb9:
  %t39 = load i64, ptr %l38, !tbaa !24
  store i64 %t39, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s3
  %t40 = load i64, ptr %l9, !tbaa !24
  %t41 = load i64, ptr %l8, !tbaa !24
  %t44 = icmp slt i64 %t40, %t41
  %t46 = xor i1 %t44, true
  br i1 %t46, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s3)
  br label %bb138
bb12:
  br label %bb13
bb13:
  %t48 = load i64, ptr %l5, !tbaa !24
  %t49 = load i64, ptr %l9, !tbaa !24
  %t50 = load i64, ptr %l7, !tbaa !24
  %t53 = mul i64 %t49, %t50
  %t56 = add i64 %t48, %t53
  store i64 %t56, ptr %l10, !tbaa !24
  %t58 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t58, ptr %l59, !tbaa !27
  %t59 = load i64, ptr %l10, !tbaa !24
  %t61 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !27
  %t63 = getelementptr ptr, ptr %t62, i64 %t59
  %t64 = load ptr, ptr %t63, !tbaa !39
  store ptr %t64, ptr %l11, !tbaa !29
  %t66 = load ptr, ptr %l2, !tbaa !29
  %t67 = load i64, ptr %l10, !tbaa !24
  %t70 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aClause_26_3e_2eA_H5c1658fda327bafea70286240d031c3b(ptr %v2, ptr %v2, ptr %t66, i64 %t67)
  store ptr %t70, ptr %l64
  br label %bb14
bb14:
  %t71 = load ptr, ptr %l64, !tbaa !29
  store ptr %t71, ptr %l12, !tbaa !29
  %t72 = load i64, ptr %l10, !tbaa !24
  %t74 = icmp sgt i64 %t72, 0
  br i1 %t74, label %bb15, label %bb16
bb15:
  %t76 = load ptr, ptr %l2, !tbaa !29
  %t78 = load i64, ptr %l10, !tbaa !24
  %t80 = sub i64 %t78, 1
  %t83 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aClause_26_3e_2eA_H5c1658fda327bafea70286240d031c3b(ptr %v2, ptr %s3, ptr %t76, i64 %t80)
  store ptr %t83, ptr %l72
  br label %bb17
bb16:
  store i1 false, ptr %l67, !tbaa !21
  br label %bb18
bb17:
  %t84 = load ptr, ptr %l72, !tbaa !29
  %t86 = getelementptr %"compiler/typed:Clause", ptr %t84, i32 0, i32 2
  %t87 = load i1, ptr %t86, !tbaa !21
  store i1 %t87, ptr %l67, !tbaa !21
  br label %bb18
bb18:
  %t89 = load i1, ptr %l67, !tbaa !21
  br i1 %t89, label %bb19, label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s4
  %t90 = load ptr, ptr %l0, !tbaa !29
  store ptr %t90, ptr %l75, !tbaa !29
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load ptr, ptr %l11, !tbaa !29
  %t95 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecatchSpan(ptr %v0, ptr %v1, ptr %t91, ptr %t92)
  store %"compiler/source:Span" %t95, ptr %l78
  br label %bb21
bb20:
  br label %bb24
bb21:
  %t96 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCatchAfterCatchAll(ptr %s4)
  store %"compiler/msgs:Msg" %t96, ptr %l79
  br label %bb22
bb22:
  %t97 = load ptr, ptr %l75, !tbaa !29
  %t98 = load %"compiler/source:Span", ptr %l78
  %t99 = load %"compiler/msgs:Msg", ptr %l79
  %t100 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s4, ptr %t97, %"compiler/source:Span" %t98, %"compiler/msgs:Msg" %t99)
  store i64 %t100, ptr %l80
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  store i1 true, ptr %rv
  br label %ret
bb24:
  %t102 = load i64, ptr %l10, !tbaa !24
  %t104 = icmp sgt i64 %t102, 0
  br i1 %t104, label %bb25, label %bb26
bb25:
  %t106 = load ptr, ptr %l12, !tbaa !29
  %t108 = getelementptr %"compiler/typed:Clause", ptr %t106, i32 0, i32 2
  %t109 = load i1, ptr %t108, !tbaa !21
  %t111 = xor i1 %t109, true
  store i1 %t111, ptr %l84, !tbaa !21
  br label %bb27
bb26:
  store i1 false, ptr %l84, !tbaa !21
  br label %bb27
bb27:
  %t113 = load i1, ptr %l84, !tbaa !21
  br i1 %t113, label %bb28, label %bb29
bb28:
  %t114 = load ptr, ptr %l12, !tbaa !29
  %t116 = getelementptr %"compiler/typed:Clause", ptr %t114, i32 0, i32 1
  %t117 = load { i64, ptr }, ptr %t116, !tbaa !27
  %t119 = extractvalue { i64, ptr } %t117, 0
  %t121 = icmp sgt i64 %t119, 0
  store i1 %t121, ptr %l88, !tbaa !21
  br label %bb30
bb29:
  store i1 false, ptr %l88, !tbaa !21
  br label %bb30
bb30:
  %t123 = load i1, ptr %l88, !tbaa !21
  br i1 %t123, label %bb31, label %bb32
bb31:
  store %olang.scope zeroinitializer, ptr %s5
  %t124 = load ptr, ptr @__olang_prog_scope
  %t125 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aClause_26_3e(ptr %t124)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t125, ptr %l93
  br label %bb33
bb32:
  br label %bb71
bb33:
  %t126 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l93
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t126, ptr %l13
  store i64 0, ptr %l14, !tbaa !24
  %t127 = load i64, ptr %l10, !tbaa !24
  store i64 %t127, ptr %l15, !tbaa !24
  store i64 1, ptr %l16, !tbaa !24
  %t129 = load i64, ptr %l15, !tbaa !24
  %t130 = load i64, ptr %l14, !tbaa !24
  %t133 = icmp sgt i64 %t129, %t130
  br i1 %t133, label %bb34, label %bb35
bb34:
  %t135 = load i64, ptr %l16, !tbaa !24
  %t137 = icmp sgt i64 %t135, 0
  br i1 %t137, label %bb36, label %bb37
bb35:
  store i64 0, ptr %l98, !tbaa !24
  br label %bb39
bb36:
  %t139 = load i64, ptr %l15, !tbaa !24
  %t140 = load i64, ptr %l14, !tbaa !24
  %t143 = sub i64 %t139, %t140
  %t144 = load i64, ptr %l16, !tbaa !24
  %t147 = add i64 %t143, %t144
  %t149 = sub i64 %t147, 1
  %t150 = load i64, ptr %l16, !tbaa !24
  %t153 = sdiv i64 %t149, %t150
  store i64 %t153, ptr %l101, !tbaa !24
  br label %bb38
bb37:
  store i64 0, ptr %l101, !tbaa !24
  br label %bb38
bb38:
  %t155 = load i64, ptr %l101, !tbaa !24
  store i64 %t155, ptr %l98, !tbaa !24
  br label %bb39
bb39:
  %t156 = load i64, ptr %l98, !tbaa !24
  store i64 %t156, ptr %l17, !tbaa !24
  store i64 0, ptr %l18, !tbaa !24
  br label %bb40
bb40:
  store %olang.scope zeroinitializer, ptr %s7
  %t157 = load i64, ptr %l18, !tbaa !24
  %t158 = load i64, ptr %l17, !tbaa !24
  %t161 = icmp slt i64 %t157, %t158
  %t163 = xor i1 %t161, true
  br i1 %t163, label %bb41, label %bb42
bb41:
  call void @__olang_scope_close(ptr %s7)
  br label %bb47
bb42:
  br label %bb43
bb43:
  %t165 = load i64, ptr %l14, !tbaa !24
  %t166 = load i64, ptr %l18, !tbaa !24
  %t167 = load i64, ptr %l16, !tbaa !24
  %t170 = mul i64 %t166, %t167
  %t173 = add i64 %t165, %t170
  store ptr %l13, ptr %l119, !tbaa !29
  %t175 = load ptr, ptr %l2, !tbaa !29
  %t179 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aClause_26_3e_2eA_H5c1658fda327bafea70286240d031c3b(ptr %v2, ptr %v2, ptr %t175, i64 %t173)
  store ptr %t179, ptr %l122
  br label %bb44
bb44:
  %t180 = load ptr, ptr %l119, !tbaa !29
  %t181 = load ptr, ptr %l122, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aClause_26_3e_2eP_Hee51906bde9346e7b7b6808fdce5ba81(ptr %s5, ptr %v2, ptr %t180, ptr %t181)
  br label %bb45
bb45:
  call void @__olang_scope_close(ptr %s7)
  br label %bb46
bb46:
  %t182 = load i64, ptr %l18, !tbaa !24
  %t184 = add i64 %t182, 1
  store i64 %t184, ptr %l18, !tbaa !24
  br label %bb40
bb47:
  store i1 true, ptr %l20, !tbaa !21
  %t186 = load ptr, ptr %l12, !tbaa !29
  %t188 = getelementptr %"compiler/typed:Clause", ptr %t186, i32 0, i32 1
  %t189 = load { i64, ptr }, ptr %t188, !tbaa !27
  store { i64, ptr } %t189, ptr %l21, !tbaa !27
  store i64 0, ptr %l22, !tbaa !24
  %t191 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t193 = extractvalue { i64, ptr } %t191, 0
  store i64 %t193, ptr %l23, !tbaa !24
  br label %bb48
bb48:
  store %olang.scope zeroinitializer, ptr %s10
  %t195 = load i64, ptr %l22, !tbaa !24
  %t196 = load i64, ptr %l23, !tbaa !24
  %t199 = icmp slt i64 %t195, %t196
  %t201 = xor i1 %t199, true
  br i1 %t201, label %bb49, label %bb50
bb49:
  call void @__olang_scope_close(ptr %s10)
  br label %bb64
bb50:
  br label %bb51
bb51:
  %t203 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t203, ptr %l133, !tbaa !27
  %t204 = load i64, ptr %l22, !tbaa !24
  %t206 = getelementptr { i64, ptr }, ptr %l133, i32 0, i32 1
  %t207 = load ptr, ptr %t206, !tbaa !27
  %t208 = getelementptr %"compiler/typed:Item", ptr %t207, i64 %t204
  %t209 = load %"compiler/typed:Item", ptr %t208
  store %"compiler/typed:Item" %t209, ptr %l24
  %t211 = getelementptr %"compiler/typed:Item", ptr %l24, i32 0, i32 1
  %t212 = load i64, ptr %t211, !tbaa !24
  %t214 = icmp slt i64 %t212, 0
  br i1 %t214, label %bb52, label %bb53
bb52:
  store i1 true, ptr %l138, !tbaa !21
  br label %bb54
bb53:
  %t216 = getelementptr %"compiler/typed:Item", ptr %l24, i32 0, i32 1
  %t217 = load i64, ptr %t216, !tbaa !24
  %t219 = icmp sge i64 %t217, 64
  store i1 %t219, ptr %l138, !tbaa !21
  br label %bb54
bb54:
  %t221 = load i1, ptr %l138, !tbaa !21
  br i1 %t221, label %bb55, label %bb56
bb55:
  %t222 = getelementptr %"compiler/typed:Item", ptr %l24, i32 0, i32 0
  %t223 = load i32, ptr %t222, !tbaa !23
  store i32 %t223, ptr %l141, !tbaa !23
  br label %bb58
bb56:
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t227 = getelementptr %"compiler/check:Checker", ptr %t225, i32 0, i32 1
  %t228 = load ptr, ptr %t227, !tbaa !29
  %t230 = getelementptr %"compiler/generic:Program", ptr %t228, i32 0, i32 2
  %t231 = getelementptr %"compiler/typed:Item", ptr %l24, i32 0, i32 0
  %t232 = load i32, ptr %t231, !tbaa !23
  %t233 = getelementptr %"compiler/typed:Item", ptr %l24, i32 0, i32 1
  %t234 = load i64, ptr %t233, !tbaa !24
  store i64 %t234, ptr %l147, !tbaa !24
  %t235 = load i64, ptr %l147, !tbaa !24
  %t236 = load i64, ptr %l147, !tbaa !24
  %t237 = shl i64 1, %t236
  %t241 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrWords(ptr %v0, ptr %t230, i32 %t232, i64 %t237)
  store i32 %t241, ptr %l149
  br label %bb57
bb57:
  %t242 = load i32, ptr %l149, !tbaa !23
  store i32 %t242, ptr %l141, !tbaa !23
  br label %bb58
bb58:
  %t243 = load i32, ptr %l141, !tbaa !23
  %t244 = load ptr, ptr %l0, !tbaa !29
  %t249 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleft(ptr %v0, ptr %s5, ptr %t244, i32 %t243, ptr %l13)
  store i32 %t249, ptr %l153
  br label %bb59
bb59:
  %t250 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t251 = load i32, ptr %l153, !tbaa !23
  %t253 = icmp ne i32 %t251, %t250
  br i1 %t253, label %bb60, label %bb61
bb60:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb62
bb61:
  br label %bb62
bb62:
  call void @__olang_scope_close(ptr %s10)
  br label %bb63
bb63:
  %t255 = load i64, ptr %l22, !tbaa !24
  %t257 = add i64 %t255, 1
  store i64 %t257, ptr %l22, !tbaa !24
  br label %bb48
bb64:
  %t259 = load i1, ptr %l20, !tbaa !21
  br i1 %t259, label %bb65, label %bb66
bb65:
  store %olang.scope zeroinitializer, ptr %s13
  %t261 = load ptr, ptr %l0, !tbaa !29
  store ptr %t261, ptr %l159, !tbaa !29
  %t262 = load ptr, ptr %l0, !tbaa !29
  %t263 = load ptr, ptr %l11, !tbaa !29
  %t266 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecatchSpan(ptr %v0, ptr %v1, ptr %t262, ptr %t263)
  store %"compiler/source:Span" %t266, ptr %l162
  br label %bb67
bb66:
  br label %bb70
bb67:
  %t267 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCatchUnreachable(ptr %s13)
  store %"compiler/msgs:Msg" %t267, ptr %l163
  br label %bb68
bb68:
  %t268 = load ptr, ptr %l159, !tbaa !29
  %t269 = load %"compiler/source:Span", ptr %l162
  %t270 = load %"compiler/msgs:Msg", ptr %l163
  %t271 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s13, ptr %t268, %"compiler/source:Span" %t269, %"compiler/msgs:Msg" %t270)
  store i64 %t271, ptr %l164
  br label %bb69
bb69:
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s3)
  store i1 true, ptr %rv
  br label %ret
bb70:
  call void @__olang_scope_close(ptr %s5)
  br label %bb71
bb71:
  %t273 = load ptr, ptr %l11, !tbaa !29
  %t275 = getelementptr %"compiler/ast:Catch", ptr %t273, i32 0, i32 3
  %t276 = load { i64, ptr }, ptr %t275, !tbaa !27
  %t278 = extractvalue { i64, ptr } %t276, 0
  %t280 = icmp sgt i64 %t278, 0
  store i1 %t280, ptr %l26, !tbaa !21
  %t284 = xor i1 %a3, true
  br i1 %t284, label %bb72, label %bb73
bb72:
  %t286 = load i1, ptr %l26, !tbaa !21
  br i1 %t286, label %bb74, label %bb75
bb73:
  br label %bb80
bb74:
  store %olang.scope zeroinitializer, ptr %s15
  %t288 = load ptr, ptr %l0, !tbaa !29
  store ptr %t288, ptr %l173, !tbaa !29
  %t289 = load ptr, ptr %l0, !tbaa !29
  %t290 = load ptr, ptr %l11, !tbaa !29
  %t293 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edefaultSpan(ptr %v0, ptr %v1, ptr %t289, ptr %t290)
  store %"compiler/source:Span" %t293, ptr %l176
  br label %bb76
bb75:
  br label %bb79
bb76:
  %t294 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefaultInStatement(ptr %s15)
  store %"compiler/msgs:Msg" %t294, ptr %l177
  br label %bb77
bb77:
  %t295 = load ptr, ptr %l173, !tbaa !29
  %t296 = load %"compiler/source:Span", ptr %l176
  %t297 = load %"compiler/msgs:Msg", ptr %l177
  %t298 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s15, ptr %t295, %"compiler/source:Span" %t296, %"compiler/msgs:Msg" %t297)
  store i64 %t298, ptr %l178
  br label %bb78
bb78:
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s3)
  store i1 true, ptr %rv
  br label %ret
bb79:
  call void @__olang_scope_close(ptr %s3)
  br label %bb137
bb80:
  %t300 = load i32, ptr %l4, !tbaa !23
  %t301 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t304 = icmp eq i32 %t300, %t301
  br i1 %t304, label %bb81, label %bb82
bb81:
  %t306 = load i1, ptr %l26, !tbaa !21
  br i1 %t306, label %bb83, label %bb84
bb82:
  br label %bb89
bb83:
  store %olang.scope zeroinitializer, ptr %s17
  %t308 = load ptr, ptr %l0, !tbaa !29
  store ptr %t308, ptr %l184, !tbaa !29
  %t309 = load ptr, ptr %l0, !tbaa !29
  %t310 = load ptr, ptr %l11, !tbaa !29
  %t313 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecatchSpan(ptr %v0, ptr %v1, ptr %t309, ptr %t310)
  store %"compiler/source:Span" %t313, ptr %l187
  br label %bb85
bb84:
  br label %bb88
bb85:
  %t314 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefaultNoValue(ptr %s17)
  store %"compiler/msgs:Msg" %t314, ptr %l188
  br label %bb86
bb86:
  %t315 = load ptr, ptr %l184, !tbaa !29
  %t316 = load %"compiler/source:Span", ptr %l187
  %t317 = load %"compiler/msgs:Msg", ptr %l188
  %t318 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s17, ptr %t315, %"compiler/source:Span" %t316, %"compiler/msgs:Msg" %t317)
  store i64 %t318, ptr %l189
  br label %bb87
bb87:
  call void @__olang_scope_close(ptr %s17)
  call void @__olang_scope_close(ptr %s3)
  store i1 true, ptr %rv
  br label %ret
bb88:
  call void @__olang_scope_close(ptr %s3)
  br label %bb137
bb89:
  %t320 = load ptr, ptr %l12, !tbaa !29
  %t322 = getelementptr %"compiler/typed:Clause", ptr %t320, i32 0, i32 3
  %t323 = load ptr, ptr %t322, !tbaa !29
  %t325 = icmp eq ptr %t323, null
  %t327 = xor i1 %t325, true
  br i1 %t327, label %bb90, label %bb91
bb90:
  %t329 = load ptr, ptr %l12, !tbaa !29
  %t331 = getelementptr %"compiler/typed:Clause", ptr %t329, i32 0, i32 3
  %t332 = load ptr, ptr %t331, !tbaa !29
  %t334 = icmp eq ptr %t332, null
  br i1 %t334, label %bb92, label %bb93
bb91:
  store i1 false, ptr %l195, !tbaa !21
  br label %bb96
bb92:
  call void @__olang_check_failed(ptr @olang_loc_20fb2e81a5b7d68a_7759df49ce89a9e)
  unreachable
bb93:
  br label %bb94
bb94:
  %t336 = load ptr, ptr %l12, !tbaa !29
  %t338 = getelementptr %"compiler/typed:Clause", ptr %t336, i32 0, i32 3
  %t339 = load ptr, ptr %t338, !tbaa !29
  %t341 = call i1 @compiler_2fcheck_2eleavesValue(ptr %v2, ptr %t339)
  store i1 %t341, ptr %l201
  br label %bb95
bb95:
  %t342 = load i1, ptr %l201, !tbaa !21
  store i1 %t342, ptr %l195, !tbaa !21
  br label %bb96
bb96:
  %t343 = load i1, ptr %l195, !tbaa !21
  store i1 %t343, ptr %l27, !tbaa !21
  %t344 = load i1, ptr %l27, !tbaa !21
  br i1 %t344, label %bb97, label %bb98
bb97:
  %t346 = load i1, ptr %l26, !tbaa !21
  store i1 %t346, ptr %l203, !tbaa !21
  br label %bb99
bb98:
  store i1 false, ptr %l203, !tbaa !21
  br label %bb99
bb99:
  %t348 = load i1, ptr %l203, !tbaa !21
  br i1 %t348, label %bb100, label %bb101
bb100:
  store %olang.scope zeroinitializer, ptr %s18
  %t349 = load ptr, ptr %l0, !tbaa !29
  store ptr %t349, ptr %l205, !tbaa !29
  %t350 = load ptr, ptr %l0, !tbaa !29
  %t351 = load ptr, ptr %l11, !tbaa !29
  %t354 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edefaultSpan(ptr %v0, ptr %v1, ptr %t350, ptr %t351)
  store %"compiler/source:Span" %t354, ptr %l208
  br label %bb102
bb101:
  br label %bb105
bb102:
  %t355 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefaultDead(ptr %s18)
  store %"compiler/msgs:Msg" %t355, ptr %l209
  br label %bb103
bb103:
  %t356 = load ptr, ptr %l205, !tbaa !29
  %t357 = load %"compiler/source:Span", ptr %l208
  %t358 = load %"compiler/msgs:Msg", ptr %l209
  %t359 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s18, ptr %t356, %"compiler/source:Span" %t357, %"compiler/msgs:Msg" %t358)
  store i64 %t359, ptr %l210
  br label %bb104
bb104:
  call void @__olang_scope_close(ptr %s18)
  call void @__olang_scope_close(ptr %s3)
  store i1 true, ptr %rv
  br label %ret
bb105:
  %t361 = load i1, ptr %l27, !tbaa !21
  %t363 = xor i1 %t361, true
  br i1 %t363, label %bb106, label %bb107
bb106:
  %t365 = load i1, ptr %l26, !tbaa !21
  %t367 = xor i1 %t365, true
  store i1 %t367, ptr %l214, !tbaa !21
  br label %bb108
bb107:
  store i1 false, ptr %l214, !tbaa !21
  br label %bb108
bb108:
  %t369 = load i1, ptr %l214, !tbaa !21
  br i1 %t369, label %bb109, label %bb110
bb109:
  store %olang.scope zeroinitializer, ptr %s19
  %t370 = load ptr, ptr %l11, !tbaa !29
  %t372 = getelementptr %"compiler/ast:Catch", ptr %t370, i32 0, i32 2
  %t373 = load { i64, ptr }, ptr %t372, !tbaa !27
  %t375 = extractvalue { i64, ptr } %t373, 0
  %t377 = icmp sgt i64 %t375, 0
  br i1 %t377, label %bb111, label %bb112
bb110:
  br label %bb121
bb111:
  %t379 = load ptr, ptr %l11, !tbaa !29
  %t381 = getelementptr %"compiler/ast:Catch", ptr %t379, i32 0, i32 2
  %t382 = load { i64, ptr }, ptr %t381, !tbaa !27
  %t384 = call i1 @compiler_2fcheck_2elastIsValue(ptr %v1, { i64, ptr } %t382)
  store i1 %t384, ptr %l224
  br label %bb113
bb112:
  store i1 false, ptr %l221, !tbaa !21
  br label %bb114
bb113:
  %t385 = load i1, ptr %l224, !tbaa !21
  store i1 %t385, ptr %l221, !tbaa !21
  br label %bb114
bb114:
  %t386 = load i1, ptr %l221, !tbaa !21
  br i1 %t386, label %bb115, label %bb116
bb115:
  call void @__olang_scope_close(ptr %s19)
  call void @__olang_scope_close(ptr %s3)
  br label %bb137
bb116:
  br label %bb117
bb117:
  %t387 = load ptr, ptr %l0, !tbaa !29
  store ptr %t387, ptr %l225, !tbaa !29
  %t388 = load ptr, ptr %l0, !tbaa !29
  %t389 = load ptr, ptr %l11, !tbaa !29
  %t392 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecatchSpan(ptr %v0, ptr %v1, ptr %t388, ptr %t389)
  store %"compiler/source:Span" %t392, ptr %l228
  br label %bb118
bb118:
  %t393 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCatchMustLeave(ptr %s19)
  store %"compiler/msgs:Msg" %t393, ptr %l229
  br label %bb119
bb119:
  %t394 = load ptr, ptr %l225, !tbaa !29
  %t395 = load %"compiler/source:Span", ptr %l228
  %t396 = load %"compiler/msgs:Msg", ptr %l229
  %t397 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s19, ptr %t394, %"compiler/source:Span" %t395, %"compiler/msgs:Msg" %t396)
  store i64 %t397, ptr %l230
  br label %bb120
bb120:
  call void @__olang_scope_close(ptr %s19)
  call void @__olang_scope_close(ptr %s3)
  store i1 true, ptr %rv
  br label %ret
bb121:
  %t399 = load i1, ptr %l26, !tbaa !21
  br i1 %t399, label %bb122, label %bb123
bb122:
  %t401 = load ptr, ptr %l0, !tbaa !29
  %t403 = getelementptr %"compiler/check:Checker", ptr %t401, i32 0, i32 1
  %t404 = load ptr, ptr %t403, !tbaa !29
  %t406 = getelementptr %"compiler/generic:Program", ptr %t404, i32 0, i32 2
  %t407 = load i32, ptr %l4, !tbaa !23
  %t410 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t406, i32 %t407)
  store i32 %t410, ptr %l238
  br label %bb124
bb123:
  store i1 false, ptr %l233, !tbaa !21
  br label %bb125
bb124:
  %t411 = load i32, ptr %l238
  %t413 = trunc i64 22 to i32
  %t414 = icmp eq i32 %t411, %t413
  store i1 %t414, ptr %l233, !tbaa !21
  br label %bb125
bb125:
  %t416 = load i1, ptr %l233, !tbaa !21
  br i1 %t416, label %bb126, label %bb127
bb126:
  %t417 = load ptr, ptr %l0, !tbaa !29
  %t419 = getelementptr %"compiler/check:Checker", ptr %t417, i32 0, i32 1
  %t420 = load ptr, ptr %t419, !tbaa !29
  %t422 = getelementptr %"compiler/generic:Program", ptr %t420, i32 0, i32 2
  store ptr %t422, ptr %l243, !tbaa !29
  %t423 = load ptr, ptr %l0, !tbaa !29
  %t425 = getelementptr %"compiler/check:Checker", ptr %t423, i32 0, i32 1
  %t426 = load ptr, ptr %t425, !tbaa !29
  %t428 = getelementptr %"compiler/generic:Program", ptr %t426, i32 0, i32 2
  %t429 = load i32, ptr %l4, !tbaa !23
  %t432 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t428, i32 %t429)
  store i32 %t432, ptr %l248
  br label %bb128
bb127:
  br label %bb136
bb128:
  %t433 = load ptr, ptr %l243, !tbaa !29
  %t434 = load i32, ptr %l248, !tbaa !23
  %t435 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t433, i32 %t434)
  store { i64, ptr } %t435, ptr %l249
  br label %bb129
bb129:
  %t436 = load { i64, ptr }, ptr %l249, !tbaa !27
  %t437 = extractvalue { i64, ptr } %t436, 0
  store i64 %t437, ptr %l28, !tbaa !24
  %t439 = load ptr, ptr %l11, !tbaa !29
  %t441 = getelementptr %"compiler/ast:Catch", ptr %t439, i32 0, i32 3
  %t442 = load { i64, ptr }, ptr %t441, !tbaa !27
  %t444 = extractvalue { i64, ptr } %t442, 0
  %t445 = load i64, ptr %l28, !tbaa !24
  %t448 = icmp ne i64 %t444, %t445
  br i1 %t448, label %bb130, label %bb131
bb130:
  store %olang.scope zeroinitializer, ptr %s22
  %t450 = load ptr, ptr %l0, !tbaa !29
  store ptr %t450, ptr %l256, !tbaa !29
  %t451 = load ptr, ptr %l0, !tbaa !29
  %t452 = load ptr, ptr %l11, !tbaa !29
  %t455 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edefaultSpan(ptr %v0, ptr %v1, ptr %t451, ptr %t452)
  store %"compiler/source:Span" %t455, ptr %l259
  br label %bb132
bb131:
  br label %bb135
bb132:
  %t456 = load i64, ptr %l28, !tbaa !24
  %t457 = load ptr, ptr %l11, !tbaa !29
  %t459 = getelementptr %"compiler/ast:Catch", ptr %t457, i32 0, i32 3
  %t460 = load { i64, ptr }, ptr %t459, !tbaa !27
  %t462 = extractvalue { i64, ptr } %t460, 0
  %t465 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefaultCount(ptr %s22, i64 %t456, i64 %t462)
  store %"compiler/msgs:Msg" %t465, ptr %l264
  br label %bb133
bb133:
  %t466 = load ptr, ptr %l256, !tbaa !29
  %t467 = load %"compiler/source:Span", ptr %l259
  %t468 = load %"compiler/msgs:Msg", ptr %l264
  %t469 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s22, ptr %t466, %"compiler/source:Span" %t467, %"compiler/msgs:Msg" %t468)
  store i64 %t469, ptr %l265
  br label %bb134
bb134:
  call void @__olang_scope_close(ptr %s22)
  call void @__olang_scope_close(ptr %s3)
  store i1 true, ptr %rv
  br label %ret
bb135:
  br label %bb136
bb136:
  call void @__olang_scope_close(ptr %s3)
  br label %bb137
bb137:
  %t471 = load i64, ptr %l9, !tbaa !24
  %t473 = add i64 %t471, 1
  store i64 %t473, ptr %l9, !tbaa !24
  br label %bb10
bb138:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econversion(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca %"compiler/check:litv"
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i64
  %l17 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca %"compiler/source:Span"
  %l25 = alloca %"compiler/msgs:Msg"
  %l26 = alloca i64
  %l29 = alloca ptr
  %l31 = alloca { i64, ptr }
  %l34 = alloca %"compiler/check:litv"
  %l37 = alloca i1
  %l41 = alloca i1
  %l42 = alloca i1
  %l45 = alloca i1
  %l47 = alloca { i64, ptr }
  %l49 = alloca i1
  %l50 = alloca i1
  %l52 = alloca { i64, ptr }
  %l54 = alloca i1
  %l56 = alloca ptr
  %l58 = alloca { i64, ptr }
  %l62 = alloca ptr
  %l63 = alloca { i64, ptr }
  %l65 = alloca %"compiler/source:Span"
  %l66 = alloca ptr
  %l69 = alloca i32
  %l73 = alloca i1
  %l80 = alloca i1
  %l81 = alloca i1
  %l84 = alloca i1
  %l86 = alloca ptr
  %l87 = alloca { i64, ptr }
  %l89 = alloca %"compiler/source:Span"
  %l92 = alloca { i64, ptr }
  %l93 = alloca { i64, ptr }
  %l96 = alloca { i64, ptr }
  %l98 = alloca %"compiler/msgs:Msg"
  %l99 = alloca i64
  %l102 = alloca ptr
  %l103 = alloca ptr
  %l104 = alloca i32
  %l108 = alloca i64
  %l109 = alloca i32
  %l115 = alloca i64
  %l119 = alloca %"compiler/source:Span"
  %l120 = alloca i32
  %l121 = alloca i32
  %l122 = alloca i32
  %l126 = alloca { i64, ptr }
  %l132 = alloca i64
  %l134 = alloca ptr
  %l135 = alloca %"compiler/source:Span"
  %l136 = alloca { i64, ptr }
  %l138 = alloca %"compiler/source:Span"
  %l145 = alloca ptr
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca ptr
  %t242 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l2, !tbaa !23
  %t2 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t5 = icmp eq i32 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load %"compiler/source:Span", ptr %l1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %s1, ptr %t7, %"compiler/source:Span" %t8, { i64, ptr } { i64 25, ptr @.d1 })
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load %"compiler/source:Span", ptr %l1
  %t15 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t11, %"compiler/source:Span" %t12)
  store ptr %t15, ptr %l17
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s1)
  %t16 = load ptr, ptr %l17, !tbaa !29
  store ptr %t16, ptr %rv
  br label %ret
bb5:
  %t17 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t17, 0
  %t21 = icmp ne i64 %t19, 1
  br i1 %t21, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s2
  %t23 = load ptr, ptr %l0, !tbaa !29
  store ptr %t23, ptr %l21, !tbaa !29
  %t24 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t24, ptr %l22
  %t25 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t29 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eArgCount(ptr %s2, ptr %s2, i64 1, { i64, ptr } { i64 0, ptr @.d2 }, i64 %t27)
  store %"compiler/msgs:Msg" %t29, ptr %l25
  br label %bb8
bb7:
  br label %bb11
bb8:
  %t30 = load ptr, ptr %l21, !tbaa !29
  %t31 = load %"compiler/source:Span", ptr %l22
  %t32 = load %"compiler/msgs:Msg", ptr %l25
  %t33 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s2, ptr %t30, %"compiler/source:Span" %t31, %"compiler/msgs:Msg" %t32)
  store i64 %t33, ptr %l26
  br label %bb9
bb9:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load %"compiler/source:Span", ptr %l1
  %t38 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t34, %"compiler/source:Span" %t35)
  store ptr %t38, ptr %l29
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s2)
  %t39 = load ptr, ptr %l29, !tbaa !29
  store ptr %t39, ptr %rv
  br label %ret
bb11:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t41, ptr %l31, !tbaa !27
  %t42 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = getelementptr ptr, ptr %t43, i64 0
  %t45 = load ptr, ptr %t44, !tbaa !39
  %t49 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %t40, ptr %t45)
  store %"compiler/check:litv" %t49, ptr %l34
  br label %bb12
bb12:
  %t50 = load %"compiler/check:litv", ptr %l34
  store %"compiler/check:litv" %t50, ptr %l4
  %t51 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t51, ptr %l5, !tbaa !23
  %t53 = getelementptr %"compiler/check:litv", ptr %l4, i32 0, i32 0
  %t54 = load i1, ptr %t53, !tbaa !21
  br i1 %t54, label %bb13, label %bb14
bb13:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t57 = load %"compiler/check:litv", ptr %l4
  %t58 = load i32, ptr %l2, !tbaa !23
  %t62 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitFits(ptr %v0, ptr %t56, %"compiler/check:litv" %t57, i32 %t58)
  store i1 %t62, ptr %l41
  br label %bb15
bb14:
  store i1 false, ptr %l37, !tbaa !21
  br label %bb16
bb15:
  %t63 = load i1, ptr %l41, !tbaa !21
  store i1 %t63, ptr %l37, !tbaa !21
  br label %bb16
bb16:
  %t64 = load i1, ptr %l37, !tbaa !21
  br i1 %t64, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l42, !tbaa !21
  br label %bb27
bb18:
  %t65 = getelementptr %"compiler/check:litv", ptr %l4, i32 0, i32 0
  %t66 = load i1, ptr %t65, !tbaa !21
  %t68 = xor i1 %t66, true
  br i1 %t68, label %bb19, label %bb20
bb19:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t71, ptr %l47, !tbaa !27
  %t72 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = getelementptr ptr, ptr %t73, i64 0
  %t75 = load ptr, ptr %t74, !tbaa !39
  %t78 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v1, ptr %t70, ptr %t75)
  store i1 %t78, ptr %l49
  br label %bb21
bb20:
  store i1 false, ptr %l45, !tbaa !21
  br label %bb26
bb21:
  %t79 = load i1, ptr %l49, !tbaa !21
  br i1 %t79, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l50, !tbaa !21
  br label %bb25
bb23:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t81, ptr %l52, !tbaa !27
  %t82 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !27
  %t84 = getelementptr ptr, ptr %t83, i64 0
  %t85 = load ptr, ptr %t84, !tbaa !39
  %t88 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eshiftLit(ptr %v0, ptr %v1, ptr %t80, ptr %t85)
  store i1 %t88, ptr %l54
  br label %bb24
bb24:
  %t89 = load i1, ptr %l54, !tbaa !21
  store i1 %t89, ptr %l50, !tbaa !21
  br label %bb25
bb25:
  %t90 = load i1, ptr %l50, !tbaa !21
  store i1 %t90, ptr %l45, !tbaa !21
  br label %bb26
bb26:
  %t91 = load i1, ptr %l45, !tbaa !21
  store i1 %t91, ptr %l42, !tbaa !21
  br label %bb27
bb27:
  %t92 = load i1, ptr %l42, !tbaa !21
  br i1 %t92, label %bb28, label %bb29
bb28:
  %t93 = load i32, ptr %l2, !tbaa !23
  store i32 %t93, ptr %l5, !tbaa !23
  br label %bb30
bb29:
  br label %bb30
bb30:
  %t95 = load ptr, ptr %l0, !tbaa !29
  store ptr %t95, ptr %l56, !tbaa !29
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t97 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t97, ptr %l58, !tbaa !27
  %t98 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !27
  %t100 = getelementptr ptr, ptr %t99, i64 0
  %t101 = load ptr, ptr %t100, !tbaa !39
  %t103 = load i32, ptr %l5, !tbaa !23
  %t107 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %t96, ptr %t101, i32 %t103)
  store ptr %t107, ptr %l62
  br label %bb31
bb31:
  %t108 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t108, ptr %l63, !tbaa !27
  %t109 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t110 = load ptr, ptr %t109, !tbaa !27
  %t111 = getelementptr ptr, ptr %t110, i64 0
  %t112 = load ptr, ptr %t111, !tbaa !39
  %t114 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t112)
  store %"compiler/source:Span" %t114, ptr %l65
  br label %bb32
bb32:
  %t115 = load ptr, ptr %l56, !tbaa !29
  %t116 = load ptr, ptr %l62, !tbaa !29
  %t117 = load %"compiler/source:Span", ptr %l65
  %t118 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %t115, ptr %t116, %"compiler/source:Span" %t117)
  store ptr %t118, ptr %l66
  br label %bb33
bb33:
  %t119 = load ptr, ptr %l66, !tbaa !29
  store ptr %t119, ptr %l6, !tbaa !29
  %t120 = load ptr, ptr %l6, !tbaa !29
  %t123 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t120)
  store i32 %t123, ptr %l69
  br label %bb34
bb34:
  %t124 = load i32, ptr %l69, !tbaa !23
  store i32 %t124, ptr %l7, !tbaa !23
  %t125 = load i32, ptr %l7, !tbaa !23
  %t126 = load i32, ptr %l2, !tbaa !23
  %t129 = icmp eq i32 %t125, %t126
  br i1 %t129, label %bb35, label %bb36
bb35:
  store i1 true, ptr %l73, !tbaa !21
  br label %bb37
bb36:
  %t131 = load i32, ptr %l7, !tbaa !23
  %t132 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t135 = icmp eq i32 %t131, %t132
  store i1 %t135, ptr %l73, !tbaa !21
  br label %bb37
bb37:
  %t137 = load i1, ptr %l73, !tbaa !21
  br i1 %t137, label %bb38, label %bb39
bb38:
  %t138 = load ptr, ptr %l6, !tbaa !29
  store ptr %t138, ptr %rv
  br label %ret
bb39:
  br label %bb40
bb40:
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t141 = load i32, ptr %l7, !tbaa !23
  %t144 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t140, i32 %t141)
  store i1 %t144, ptr %l80
  br label %bb41
bb41:
  %t145 = load i1, ptr %l80, !tbaa !21
  br i1 %t145, label %bb42, label %bb43
bb42:
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t147 = load i32, ptr %l2, !tbaa !23
  %t150 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t146, i32 %t147)
  store i1 %t150, ptr %l84
  br label %bb44
bb43:
  store i1 false, ptr %l81, !tbaa !21
  br label %bb45
bb44:
  %t151 = load i1, ptr %l84, !tbaa !21
  store i1 %t151, ptr %l81, !tbaa !21
  br label %bb45
bb45:
  %t152 = load i1, ptr %l81, !tbaa !21
  %t153 = xor i1 %t152, true
  br i1 %t153, label %bb46, label %bb47
bb46:
  store %olang.scope zeroinitializer, ptr %s5
  %t155 = load ptr, ptr %l0, !tbaa !29
  store ptr %t155, ptr %l86, !tbaa !29
  %t156 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t156, ptr %l87, !tbaa !27
  %t157 = getelementptr { i64, ptr }, ptr %l87, i32 0, i32 1
  %t158 = load ptr, ptr %t157, !tbaa !27
  %t159 = getelementptr ptr, ptr %t158, i64 0
  %t160 = load ptr, ptr %t159, !tbaa !39
  %t162 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t160)
  store %"compiler/source:Span" %t162, ptr %l89
  br label %bb48
bb47:
  br label %bb54
bb48:
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t164 = load i32, ptr %l2, !tbaa !23
  %t167 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s5, ptr %t163, i32 %t164)
  store { i64, ptr } %t167, ptr %l92
  br label %bb49
bb49:
  %t168 = load { i64, ptr }, ptr %l92, !tbaa !27
  %t169 = extractvalue { i64, ptr } %t168, 0
  %t170 = extractvalue { i64, ptr } %t168, 1
  %t171 = mul i64 %t169, 1
  %t172 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t171)
  call void @llvm.memcpy.p0.p0.i64(ptr %t172, ptr %t170, i64 %t171, i1 false)
  %t173 = insertvalue { i64, ptr } undef, i64 %t169, 0
  %t174 = insertvalue { i64, ptr } %t173, ptr %t172, 1
  store { i64, ptr } %t174, ptr %l93, !tbaa !27
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t176 = load i32, ptr %l7, !tbaa !23
  %t179 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s5, ptr %t175, i32 %t176)
  store { i64, ptr } %t179, ptr %l96
  br label %bb50
bb50:
  %t180 = load { i64, ptr }, ptr %l96, !tbaa !27
  %t181 = extractvalue { i64, ptr } %t180, 0
  %t182 = extractvalue { i64, ptr } %t180, 1
  %t183 = mul i64 %t181, 1
  %t184 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t183)
  call void @llvm.memcpy.p0.p0.i64(ptr %t184, ptr %t182, i64 %t183, i1 false)
  %t185 = insertvalue { i64, ptr } undef, i64 %t181, 0
  %t186 = insertvalue { i64, ptr } %t185, ptr %t184, 1
  %t187 = load { i64, ptr }, ptr %l93, !tbaa !27
  %t189 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeMismatch(ptr %s5, ptr %s5, ptr %s5, { i64, ptr } %t187, { i64, ptr } %t186)
  store %"compiler/msgs:Msg" %t189, ptr %l98
  br label %bb51
bb51:
  %t190 = load ptr, ptr %l86, !tbaa !29
  %t191 = load %"compiler/source:Span", ptr %l89
  %t192 = load %"compiler/msgs:Msg", ptr %l98
  %t193 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s5, ptr %t190, %"compiler/source:Span" %t191, %"compiler/msgs:Msg" %t192)
  store i64 %t193, ptr %l99
  br label %bb52
bb52:
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t195 = load %"compiler/source:Span", ptr %l1
  %t198 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t194, %"compiler/source:Span" %t195)
  store ptr %t198, ptr %l102
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s5)
  %t199 = load ptr, ptr %l102, !tbaa !29
  store ptr %t199, ptr %rv
  br label %ret
bb54:
  %t200 = load ptr, ptr %l0, !tbaa !29
  store ptr %t200, ptr %l103, !tbaa !29
  store i32 0, ptr %l104
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t202 = load i32, ptr %l7, !tbaa !23
  %t203 = load i32, ptr %l2, !tbaa !23
  %t207 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvWords(ptr %v0, ptr %t201, i32 %t202, i32 %t203)
  store i64 %t207, ptr %l108
  br label %bb55
bb55:
  %t208 = load ptr, ptr %l103, !tbaa !29
  %t209 = load i32, ptr %l104
  %t210 = load i64, ptr %l108, !tbaa !65
  %t211 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echeckOp(ptr %v0, ptr %t208, i32 %t209, i64 %t210)
  store i32 %t211, ptr %l109
  br label %bb56
bb56:
  %t212 = load i32, ptr %l109
  store i32 %t212, ptr %l8
  %t213 = load i32, ptr %l8
  %t215 = trunc i64 0 to i32
  %t216 = icmp eq i32 %t213, %t215
  %t218 = xor i1 %t216, true
  br i1 %t218, label %bb57, label %bb58
bb57:
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t222 = getelementptr %"compiler/check:Checker", ptr %t220, i32 0, i32 31
  %t224 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t222)
  store i64 %t224, ptr %l115
  br label %bb59
bb58:
  br label %bb62
bb59:
  %t225 = load i64, ptr %l115, !tbaa !24
  store i64 %t225, ptr %l9, !tbaa !24
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t228 = getelementptr %"compiler/check:Checker", ptr %t226, i32 0, i32 31
  %t229 = load ptr, ptr %l6, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ePus_H51a5125d8f537c6ff8e01fc80ef561c7(ptr %v0, ptr %v0, ptr %t228, ptr %t229)
  br label %bb60
bb60:
  %t232 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t232, ptr %l119
  %t233 = load i32, ptr %l2, !tbaa !23
  store i32 %t233, ptr %l120, !tbaa !23
  store i32 20, ptr %l121
  %t234 = load i32, ptr %l8
  store i32 %t234, ptr %l122
  %t235 = load ptr, ptr %l0, !tbaa !29
  %t237 = getelementptr %"compiler/check:Checker", ptr %t235, i32 0, i32 31
  %t238 = load i64, ptr %l9, !tbaa !24
  %t241 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t237, i64 %t238)
  store { i64, ptr } %t241, ptr %l126
  br label %bb61
bb61:
  store { i64, [5 x i64] } zeroinitializer, ptr %t242
  %t243 = getelementptr { i64, [5 x i64] }, ptr %t242, i32 0, i32 0
  store i64 9, ptr %t243
  %t244 = load %"compiler/source:Span", ptr %l119
  %t245 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } undef, %"compiler/source:Span" %t244, 0
  %t246 = load i32, ptr %l120, !tbaa !23
  %t247 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t245, i32 %t246, 1
  %t248 = load i32, ptr %l121
  %t249 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t247, i32 %t248, 2
  %t250 = load i32, ptr %l122
  %t251 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t249, i32 %t250, 3
  %t252 = load { i64, ptr }, ptr %l126, !tbaa !27
  %t253 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t251, { i64, ptr } %t252, 4
  %t254 = getelementptr { i64, [5 x i64] }, ptr %t242, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t253, ptr %t254
  %t255 = load { i64, [5 x i64] }, ptr %t242
  %t257 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t255, ptr %t257
  store ptr %t257, ptr %rv
  br label %ret
bb62:
  %t259 = load ptr, ptr %l0, !tbaa !29
  %t260 = load i32, ptr %l7, !tbaa !23
  %t261 = load i32, ptr %l2, !tbaa !23
  %t265 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvWords(ptr %v0, ptr %t259, i32 %t260, i32 %t261)
  store i64 %t265, ptr %l132
  br label %bb63
bb63:
  %t266 = load i64, ptr %l132, !tbaa !65
  %t267 = icmp ne i64 %t266, 0
  br i1 %t267, label %bb64, label %bb65
bb64:
  %t269 = load ptr, ptr %l0, !tbaa !29
  store ptr %t269, ptr %l134, !tbaa !29
  %t270 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t270, ptr %l135
  %t271 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t271, ptr %l136, !tbaa !27
  %t272 = getelementptr { i64, ptr }, ptr %l136, i32 0, i32 1
  %t273 = load ptr, ptr %t272, !tbaa !27
  %t274 = getelementptr ptr, ptr %t273, i64 0
  %t275 = load ptr, ptr %t274, !tbaa !39
  %t277 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t275)
  store %"compiler/source:Span" %t277, ptr %l138
  br label %bb66
bb65:
  br label %bb68
bb66:
  %t278 = load ptr, ptr %l6, !tbaa !29
  %t279 = load i32, ptr %l2, !tbaa !23
  %t280 = load ptr, ptr %l134, !tbaa !29
  %t281 = load %"compiler/source:Span", ptr %l135
  %t282 = load %"compiler/source:Span", ptr %l138
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econversionAt(ptr %v0, ptr %t280, %"compiler/source:Span" %t281, %"compiler/source:Span" %t282, ptr %t278, i32 %t279)
  br label %bb67
bb67:
  br label %bb68
bb68:
  %t285 = load ptr, ptr %l0, !tbaa !29
  %t286 = load %"compiler/source:Span", ptr %l1
  %t287 = load ptr, ptr %l6, !tbaa !29
  %t288 = load i32, ptr %l2, !tbaa !23
  %t293 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %t285, %"compiler/source:Span" %t286, ptr %t287, i32 %t288)
  store ptr %t293, ptr %l145
  br label %bb69
bb69:
  %t294 = load ptr, ptr %l145, !tbaa !29
  store ptr %t294, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectFinish(ptr %v0, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca ptr
  %l7 = alloca i1
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l18 = alloca ptr
  %l24 = alloca i32
  %l25 = alloca i32
  %l31 = alloca i32
  %l32 = alloca i32
  %l34 = alloca ptr
  %l35 = alloca ptr
  %l37 = alloca ptr
  %l39 = alloca ptr
  %l42 = alloca { i64, ptr }
  %l43 = alloca %"compiler/typed:Block"
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l2, !tbaa !23
  %t2 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t5 = icmp ne i32 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load i32, ptr %l2, !tbaa !23
  %t8 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t11 = icmp ne i32 %t7, %t8
  store i1 %t11, ptr %l7, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l7, !tbaa !21
  br label %bb3
bb3:
  %t13 = load i1, ptr %l7, !tbaa !21
  br i1 %t13, label %bb4, label %bb5
bb4:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/check:Checker", ptr %t14, i32 0, i32 10
  %t17 = load i64, ptr %l1, !tbaa !24
  %t20 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t16, i64 %t17)
  store ptr %t20, ptr %l14
  br label %bb6
bb5:
  br label %bb10
bb6:
  %t21 = load ptr, ptr %l14, !tbaa !29
  store ptr %t21, ptr %l3, !tbaa !29
  %t22 = load ptr, ptr %l3, !tbaa !29
  store ptr %t22, ptr %l15, !tbaa !29
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/check:Checker", ptr %t23, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t28 = getelementptr %"compiler/generic:Program", ptr %t26, i32 0, i32 2
  store ptr %t28, ptr %l18, !tbaa !29
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/check:Checker", ptr %t29, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t34 = getelementptr %"compiler/generic:Program", ptr %t32, i32 0, i32 2
  %t35 = load ptr, ptr %l3, !tbaa !29
  %t37 = getelementptr %"compiler/typed:Body", ptr %t35, i32 0, i32 2
  %t38 = load i32, ptr %t37, !tbaa !23
  %t41 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t34, i32 %t38)
  store i32 %t41, ptr %l24
  br label %bb7
bb7:
  %t42 = load i32, ptr %l2, !tbaa !23
  store i32 %t42, ptr %l25, !tbaa !23
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/check:Checker", ptr %t43, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t48 = getelementptr %"compiler/generic:Program", ptr %t46, i32 0, i32 2
  %t49 = load ptr, ptr %l3, !tbaa !29
  %t51 = getelementptr %"compiler/typed:Body", ptr %t49, i32 0, i32 2
  %t52 = load i32, ptr %t51, !tbaa !23
  %t55 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesOf(ptr %v0, ptr %t48, i32 %t52)
  store i32 %t55, ptr %l31
  br label %bb8
bb8:
  %t56 = load ptr, ptr %l18, !tbaa !29
  %t57 = load i32, ptr %l24, !tbaa !23
  %t58 = load i32, ptr %l25, !tbaa !23
  %t59 = load i32, ptr %l31, !tbaa !23
  %t60 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t56, i32 %t57, i32 %t58, i32 0, i32 %t59, i64 0)
  store i32 %t60, ptr %l32
  br label %bb9
bb9:
  %t61 = load i32, ptr %l32, !tbaa !23
  %t62 = load ptr, ptr %l15, !tbaa !29
  %t63 = getelementptr %"compiler/typed:Body", ptr %t62, i32 0, i32 2
  store i32 %t61, ptr %t63, !tbaa !23
  br label %bb10
bb10:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t64)
  store ptr %t66, ptr %l34
  br label %bb11
bb11:
  %t67 = load ptr, ptr %l34, !tbaa !29
  store ptr %t67, ptr %l35, !tbaa !29
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/check:Checker", ptr %t68, i32 0, i32 32
  store ptr %t70, ptr %l37, !tbaa !29
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t71)
  store ptr %t73, ptr %l39
  br label %bb12
bb12:
  %t74 = load ptr, ptr %l39, !tbaa !29
  %t76 = getelementptr %"compiler/check:frame", ptr %t74, i32 0, i32 52
  %t77 = load i64, ptr %t76, !tbaa !24
  %t78 = load ptr, ptr %l37, !tbaa !29
  %t80 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t78, i64 %t77)
  store { i64, ptr } %t80, ptr %l42
  br label %bb13
bb13:
  %t81 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t82 = call %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v0, i32 0, { i64, ptr } %t81)
  store %"compiler/typed:Block" %t82, ptr %l43
  br label %bb14
bb14:
  %t83 = load %"compiler/typed:Block", ptr %l43
  %t84 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Block" %t83, ptr %t84
  %t86 = load ptr, ptr %l35, !tbaa !29
  %t87 = getelementptr %"compiler/typed:Body", ptr %t86, i32 0, i32 11
  store ptr %t84, ptr %t87, !tbaa !29
  %t88 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t88)
  br label %bb15
bb15:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/check:Checker", ptr %t90, i32 0, i32 15
  %t93 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t92, i64 %t93, i64 2)
  br label %bb16
bb16:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edoFor(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca { i64, i64, i64 }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca { i64, i64, i64 }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l18 = alloca i64
  %l22 = alloca { i64, i64, i64 }
  %l27 = alloca ptr
  %l32 = alloca ptr
  %l41 = alloca i64
  %l43 = alloca ptr
  %l46 = alloca i64
  %l47 = alloca i32
  %l48 = alloca i64
  %l50 = alloca ptr
  %l53 = alloca i64
  %l54 = alloca i32
  %l60 = alloca ptr
  %l63 = alloca i64
  %l67 = alloca { i64, i64, i64 }
  %l71 = alloca ptr
  %l72 = alloca ptr
  %l73 = alloca %"compiler/source:Span"
  %l76 = alloca ptr
  %l78 = alloca ptr
  %l84 = alloca ptr
  %t144 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 32
  %t5 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l18
  br label %bb1
bb1:
  %t6 = load i64, ptr %l18, !tbaa !24
  store i64 %t6, ptr %l4, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load %"compiler/source:Span", ptr %l1
  %t12 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t7, i32 2, %"compiler/source:Span" %t8)
  store { i64, i64, i64 } %t12, ptr %l22
  br label %bb2
bb2:
  %t13 = load { i64, i64, i64 }, ptr %l22
  store { i64, i64, i64 } %t13, ptr %l5
  %t14 = getelementptr { i64, i64, i64 }, ptr %l5, i32 0, i32 0
  %t15 = load i64, ptr %t14, !tbaa !24
  store i64 %t15, ptr %l6, !tbaa !24
  %t17 = getelementptr { i64, i64, i64 }, ptr %l5, i32 0, i32 1
  %t18 = load i64, ptr %t17, !tbaa !24
  store i64 %t18, ptr %l7, !tbaa !24
  %t20 = getelementptr { i64, i64, i64 }, ptr %l5, i32 0, i32 2
  %t21 = load i64, ptr %t20, !tbaa !24
  store i64 %t21, ptr %l8, !tbaa !24
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t23)
  store ptr %t25, ptr %l27
  br label %bb3
bb3:
  %t26 = load ptr, ptr %l27, !tbaa !29
  %t28 = getelementptr %"compiler/check:frame", ptr %t26, i32 0, i32 10
  %t29 = load i64, ptr %l6, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t28, i64 %t29)
  br label %bb4
bb4:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t32)
  store ptr %t34, ptr %l32
  br label %bb5
bb5:
  %t35 = load ptr, ptr %l32, !tbaa !29
  %t37 = getelementptr %"compiler/check:frame", ptr %t35, i32 0, i32 11
  %t38 = load i64, ptr %l6, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t37, i64 %t38)
  br label %bb6
bb6:
  %t41 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t41, 0
  %t45 = icmp sgt i64 %t43, 0
  br i1 %t45, label %bb7, label %bb8
bb7:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load { i64, ptr }, ptr %l2, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmtsOf(ptr %v0, ptr %v1, ptr %t47, { i64, ptr } %t48)
  br label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb10
bb10:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t51)
  store ptr %t53, ptr %l43
  br label %bb11
bb11:
  %t54 = load ptr, ptr %l43, !tbaa !29
  %t56 = getelementptr %"compiler/check:frame", ptr %t54, i32 0, i32 10
  %t58 = call { i32, i64 } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t56)
  %t59 = extractvalue { i32, i64 } %t58, 1
  %t60 = extractvalue { i32, i64 } %t58, 0
  store i32 %t60, ptr %l47
  %t61 = icmp ne i32 %t60, 0
  br i1 %t61, label %bb13, label %ok.62
ok.62:
  store i64 %t59, ptr %l46
  br label %bb12
bb12:
  %t63 = load i64, ptr %l46, !tbaa !24
  store i64 %t63, ptr %l41, !tbaa !24
  br label %bb15
bb13:
  br label %bb14
bb14:
  br label %bb15
bb15:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t64)
  store ptr %t66, ptr %l50
  br label %bb16
bb16:
  %t67 = load ptr, ptr %l50, !tbaa !29
  %t69 = getelementptr %"compiler/check:frame", ptr %t67, i32 0, i32 11
  %t71 = call { i32, i64 } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t69)
  %t72 = extractvalue { i32, i64 } %t71, 1
  %t73 = extractvalue { i32, i64 } %t71, 0
  store i32 %t73, ptr %l54
  %t74 = icmp ne i32 %t73, 0
  br i1 %t74, label %bb18, label %ok.75
ok.75:
  store i64 %t72, ptr %l53
  br label %bb17
bb17:
  %t76 = load i64, ptr %l53, !tbaa !24
  store i64 %t76, ptr %l48, !tbaa !24
  br label %bb20
bb18:
  br label %bb19
bb19:
  br label %bb20
bb20:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t78 = load i64, ptr %l6, !tbaa !24
  %t79 = load i64, ptr %l7, !tbaa !24
  %t80 = load i64, ptr %l8, !tbaa !24
  %t81 = load i64, ptr %l4, !tbaa !24
  %t87 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %t77, i64 %t78, i64 %t79, i64 %t80, i64 %t81)
  store ptr %t87, ptr %l60
  br label %bb21
bb21:
  %t88 = load ptr, ptr %l60, !tbaa !29
  store ptr %t88, ptr %l9, !tbaa !29
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"compiler/check:Checker", ptr %t89, i32 0, i32 32
  %t93 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t91)
  store i64 %t93, ptr %l63
  br label %bb22
bb22:
  %t94 = load i64, ptr %l63, !tbaa !24
  store i64 %t94, ptr %l10, !tbaa !24
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t96 = load %"compiler/source:Span", ptr %l1
  %t100 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t95, i32 3, %"compiler/source:Span" %t96)
  store { i64, i64, i64 } %t100, ptr %l67
  br label %bb23
bb23:
  %t101 = load { i64, i64, i64 }, ptr %l67
  store { i64, i64, i64 } %t101, ptr %l11
  %t102 = getelementptr { i64, i64, i64 }, ptr %l11, i32 0, i32 0
  %t103 = load i64, ptr %t102, !tbaa !24
  store i64 %t103, ptr %l12, !tbaa !24
  %t105 = getelementptr { i64, i64, i64 }, ptr %l11, i32 0, i32 1
  %t106 = load i64, ptr %t105, !tbaa !24
  store i64 %t106, ptr %l13, !tbaa !24
  %t108 = getelementptr { i64, i64, i64 }, ptr %l11, i32 0, i32 2
  %t109 = load i64, ptr %t108, !tbaa !24
  store i64 %t109, ptr %l14, !tbaa !24
  %t111 = load ptr, ptr %l0, !tbaa !29
  store ptr %t111, ptr %l71, !tbaa !29
  %t112 = load ptr, ptr %l0, !tbaa !29
  store ptr %t112, ptr %l72, !tbaa !29
  %t113 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t113, ptr %l73
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t118 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econd1(ptr %v0, ptr %v2, ptr %t114, ptr %a3)
  store ptr %t118, ptr %l76
  br label %bb24
bb24:
  %t119 = load i64, ptr %l6, !tbaa !24
  %t120 = load ptr, ptr %l72, !tbaa !29
  %t121 = load %"compiler/source:Span", ptr %l73
  %t122 = load ptr, ptr %l76, !tbaa !29
  %t124 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebreakUnless(ptr %v0, ptr %t120, %"compiler/source:Span" %t121, ptr %t122, i64 %t119)
  store ptr %t124, ptr %l78
  br label %bb25
bb25:
  %t125 = load ptr, ptr %l71, !tbaa !29
  %t126 = load ptr, ptr %l78, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t125, ptr %t126)
  br label %bb26
bb26:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t128 = load i64, ptr %l12, !tbaa !24
  %t129 = load i64, ptr %l13, !tbaa !24
  %t130 = load i64, ptr %l14, !tbaa !24
  %t131 = load i64, ptr %l10, !tbaa !24
  %t137 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %t127, i64 %t128, i64 %t129, i64 %t130, i64 %t131)
  store ptr %t137, ptr %l84
  br label %bb27
bb27:
  %t138 = load ptr, ptr %l84, !tbaa !29
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t140 = load %"compiler/source:Span", ptr %l1
  %t141 = load ptr, ptr %l9, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t144
  %t145 = getelementptr { i64, [3 x i64] }, ptr %t144, i32 0, i32 0
  store i64 4, ptr %t145
  %t147 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t140, 0
  %t149 = insertvalue { %"compiler/source:Span", ptr, ptr } %t147, ptr %t141, 1
  %t151 = insertvalue { %"compiler/source:Span", ptr, ptr } %t149, ptr %t138, 2
  %t152 = getelementptr { i64, [3 x i64] }, ptr %t144, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t151, ptr %t152
  %t153 = load { i64, [3 x i64] }, ptr %t144
  %t155 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t153, ptr %t155
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t139, ptr %t155)
  br label %bb28
bb28:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edrain(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i64
  %l6 = alloca i64
  %l13 = alloca i64
  %l14 = alloca ptr
  %l20 = alloca i64
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 14
  %t4 = load i64, ptr %t3, !tbaa !24
  store i64 %t4, ptr %l3, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/check:Checker", ptr %t5, i32 0, i32 13
  %t9 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t7)
  store i64 %t9, ptr %l6
  br label %bb2
bb2:
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l6, !tbaa !24
  %t12 = icmp slt i64 %t10, %t11
  %t14 = xor i1 %t12, true
  br i1 %t14, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s1)
  br label %bb13
bb4:
  br label %bb5
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/check:Checker", ptr %t16, i32 0, i32 13
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/check:Checker", ptr %t19, i32 0, i32 14
  %t22 = load i64, ptr %t21, !tbaa !24
  %t25 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t18, i64 %t22)
  store i64 %t25, ptr %l13
  br label %bb6
bb6:
  %t26 = load i64, ptr %l13, !tbaa !24
  store i64 %t26, ptr %l1, !tbaa !24
  %t27 = load ptr, ptr %l0, !tbaa !29
  store ptr %t27, ptr %l14, !tbaa !29
  %t28 = load ptr, ptr %l14, !tbaa !29
  %t29 = getelementptr %"compiler/check:Checker", ptr %t28, i32 0, i32 14
  %t30 = load i64, ptr %t29, !tbaa !24
  %t32 = add i64 %t30, 1
  %t34 = load ptr, ptr %l14, !tbaa !29
  %t35 = getelementptr %"compiler/check:Checker", ptr %t34, i32 0, i32 14
  store i64 %t32, ptr %t35, !tbaa !24
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/check:Checker", ptr %t36, i32 0, i32 15
  %t39 = load i64, ptr %l1, !tbaa !24
  %t42 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t38, i64 %t39)
  store i64 %t42, ptr %l20
  br label %bb7
bb7:
  %t43 = load i64, ptr %l20, !tbaa !24
  %t44 = icmp eq i64 %t43, 0
  br i1 %t44, label %bb8, label %bb9
bb8:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echeck(ptr %v0, ptr %t46, i64 %t47)
  br label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s1)
  br label %bb12
bb12:
  br label %bb1
bb13:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eelementLocals(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca ptr
  %l6 = alloca i64
  %l10 = alloca i1
  %l13 = alloca ptr
  %l15 = alloca i32
  %l16 = alloca %"compiler/source:Span"
  %l18 = alloca i32
  %l21 = alloca i64
  %l22 = alloca ptr
  %l23 = alloca %"compiler/source:Span"
  %l26 = alloca i32
  %l30 = alloca ptr
  %l33 = alloca ptr
  %l35 = alloca i32
  %l36 = alloca %"compiler/source:Span"
  %l39 = alloca i32
  %l42 = alloca i64
  %t22 = alloca { i64, [2 x i64] }, align 8
  %t46 = alloca { i64, [3 x i64] }, align 8
  %t70 = alloca { i64, [2 x i64] }, align 8
  %t94 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i64 %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/ast:ForIn", ptr %t1, i32 0, i32 0
  %t4 = load i32, ptr %t3, !tbaa !23
  %t6 = icmp ne i32 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load i64, ptr %l3, !tbaa !24
  %t10 = icmp sge i64 %t8, 0
  store i1 %t10, ptr %l10, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb3
bb3:
  %t12 = load i1, ptr %l10, !tbaa !21
  br i1 %t12, label %bb4, label %bb5
bb4:
  %t13 = load ptr, ptr %l0, !tbaa !29
  store ptr %t13, ptr %l13, !tbaa !29
  %t14 = load ptr, ptr %l2, !tbaa !29
  %t16 = getelementptr %"compiler/ast:ForIn", ptr %t14, i32 0, i32 0
  %t17 = load i32, ptr %t16, !tbaa !23
  store i32 %t17, ptr %l15, !tbaa !23
  %t18 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t18, ptr %l16
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t19)
  store i32 %t21, ptr %l18
  br label %bb6
bb5:
  br label %bb10
bb6:
  store { i64, [2 x i64] } zeroinitializer, ptr %t22
  %t23 = getelementptr { i64, [2 x i64] }, ptr %t22, i32 0, i32 0
  store i64 0, ptr %t23
  %t24 = load { i64, [2 x i64] }, ptr %t22
  %t25 = load ptr, ptr %l13, !tbaa !29
  %t26 = load i32, ptr %l15, !tbaa !23
  %t27 = load %"compiler/source:Span", ptr %l16
  %t28 = load i32, ptr %l18, !tbaa !23
  %t31 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %t25, i32 %t26, %"compiler/source:Span" %t27, i32 %t28, i32 1, { i64, [2 x i64] } %t24)
  store i64 %t31, ptr %l21
  br label %bb7
bb7:
  %t32 = load i64, ptr %l21, !tbaa !24
  %t33 = load ptr, ptr %l0, !tbaa !29
  store ptr %t33, ptr %l22, !tbaa !29
  %t34 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t34, ptr %l23
  %t37 = trunc i64 %t32 to i32
  store i32 %t37, ptr %l26, !tbaa !23
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load %"compiler/source:Span", ptr %l1
  %t41 = load i64, ptr %l3, !tbaa !24
  %t45 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t39, %"compiler/source:Span" %t40, i64 %t41)
  store ptr %t45, ptr %l30
  br label %bb8
bb8:
  store { i64, [3 x i64] } zeroinitializer, ptr %t46
  %t47 = getelementptr { i64, [3 x i64] }, ptr %t46, i32 0, i32 0
  store i64 0, ptr %t47
  %t48 = load %"compiler/source:Span", ptr %l23
  %t49 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t48, 0
  %t50 = load i32, ptr %l26, !tbaa !23
  %t51 = insertvalue { %"compiler/source:Span", i32, ptr } %t49, i32 %t50, 1
  %t52 = load ptr, ptr %l30, !tbaa !29
  %t53 = insertvalue { %"compiler/source:Span", i32, ptr } %t51, ptr %t52, 2
  %t54 = getelementptr { i64, [3 x i64] }, ptr %t46, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t53, ptr %t54
  %t55 = load { i64, [3 x i64] }, ptr %t46
  %t57 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t55, ptr %t57
  %t58 = load ptr, ptr %l22, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t58, ptr %t57)
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t60 = load ptr, ptr %l0, !tbaa !29
  store ptr %t60, ptr %l33, !tbaa !29
  %t61 = load ptr, ptr %l2, !tbaa !29
  %t63 = getelementptr %"compiler/ast:ForIn", ptr %t61, i32 0, i32 1
  %t64 = load i32, ptr %t63, !tbaa !23
  store i32 %t64, ptr %l35, !tbaa !23
  %t65 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t65, ptr %l36
  %t66 = load ptr, ptr %l4, !tbaa !29
  %t69 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t66)
  store i32 %t69, ptr %l39
  br label %bb11
bb11:
  store { i64, [2 x i64] } zeroinitializer, ptr %t70
  %t71 = getelementptr { i64, [2 x i64] }, ptr %t70, i32 0, i32 0
  store i64 5, ptr %t71
  %t72 = load { i64, [2 x i64] }, ptr %t70
  %t73 = load ptr, ptr %l33, !tbaa !29
  %t74 = load i32, ptr %l35, !tbaa !23
  %t75 = load %"compiler/source:Span", ptr %l36
  %t76 = load i32, ptr %l39, !tbaa !23
  %t79 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %t73, i32 %t74, %"compiler/source:Span" %t75, i32 %t76, i32 1, { i64, [2 x i64] } %t72)
  store i64 %t79, ptr %l42
  br label %bb12
bb12:
  %t80 = load i64, ptr %l42, !tbaa !24
  store i64 %t80, ptr %l6, !tbaa !24
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t82 = load i64, ptr %l6, !tbaa !24
  %t83 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroLet(ptr %v0, ptr %v0, ptr %t81, i64 %t82, ptr %t83)
  br label %bb13
bb13:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t88 = load %"compiler/source:Span", ptr %l1
  %t89 = load i64, ptr %l6, !tbaa !24
  %t91 = trunc i64 %t89 to i32
  %t93 = load ptr, ptr %l4, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t94
  %t95 = getelementptr { i64, [3 x i64] }, ptr %t94, i32 0, i32 0
  store i64 0, ptr %t95
  %t97 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t88, 0
  %t99 = insertvalue { %"compiler/source:Span", i32, ptr } %t97, i32 %t91, 1
  %t101 = insertvalue { %"compiler/source:Span", i32, ptr } %t99, ptr %t93, 2
  %t102 = getelementptr { i64, [3 x i64] }, ptr %t94, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t101, ptr %t102
  %t103 = load { i64, [3 x i64] }, ptr %t94
  %t105 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t103, ptr %t105
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t87, ptr %t105)
  br label %bb14
bb14:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrorSetKnown(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca %"compiler/generic:Context"
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l15 = alloca ptr
  %l24 = alloca i64
  %l26 = alloca %"compiler/generic:Context"
  %l36 = alloca { i64, ptr }
  %l43 = alloca i1
  %l48 = alloca i32
  %l56 = alloca i1
  %l58 = alloca ptr
  %l59 = alloca ptr
  %l61 = alloca %"compiler/source:Span"
  %l63 = alloca { i64, ptr }
  %l65 = alloca i64
  %l66 = alloca i64
  %l71 = alloca %"compiler/ast:Path"
  %l73 = alloca i32
  %l81 = alloca ptr
  %l88 = alloca { i64, ptr }
  %l91 = alloca i64
  %l94 = alloca i64
  %l95 = alloca i64
  %l103 = alloca ptr
  %l109 = alloca ptr
  %l118 = alloca { i64, [3 x i64] }
  %l120 = alloca { i64, ptr }
  %l122 = alloca %"compiler/msgs:Msg"
  %l123 = alloca i64
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %t250 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i64, ptr %l1, !tbaa !24
  %t8 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t4, i64 %t5)
  store ptr %t8, ptr %l15
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l15, !tbaa !29
  store ptr %t9, ptr %l2, !tbaa !29
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr %"compiler/ast:Func", ptr %t10, i32 0, i32 3
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = getelementptr %"compiler/ast:Sig", ptr %t13, i32 0, i32 3
  %t16 = load { i64, ptr }, ptr %t15, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t16, 0
  %t20 = icmp eq i64 %t18, 0
  br i1 %t20, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/check:Checker", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t26 = load i64, ptr %l1, !tbaa !24
  %t29 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t25, i64 %t26)
  store i64 %t29, ptr %l24
  br label %bb5
bb5:
  %t30 = load i64, ptr %l24, !tbaa !24
  store i64 %t30, ptr %l3, !tbaa !24
  %t31 = load i64, ptr %l3, !tbaa !24
  %t33 = call %"compiler/generic:Context" @compiler_2fgeneric_3aContext_2ector(ptr %s0, i64 %t31, i64 -1)
  store %"compiler/generic:Context" %t33, ptr %l26
  br label %bb6
bb6:
  %t34 = load %"compiler/generic:Context", ptr %l26
  store %"compiler/generic:Context" %t34, ptr %l4
  %t35 = load ptr, ptr %l2, !tbaa !29
  %t37 = getelementptr %"compiler/ast:Func", ptr %t35, i32 0, i32 3
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t40 = getelementptr %"compiler/ast:Sig", ptr %t38, i32 0, i32 3
  %t41 = load { i64, ptr }, ptr %t40, !tbaa !27
  store { i64, ptr } %t41, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t43 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t43, 0
  store i64 %t45, ptr %l7, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s3
  %t47 = load i64, ptr %l6, !tbaa !24
  %t48 = load i64, ptr %l7, !tbaa !24
  %t51 = icmp slt i64 %t47, %t48
  %t53 = xor i1 %t51, true
  br i1 %t53, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s3)
  br label %bb47
bb9:
  br label %bb10
bb10:
  %t55 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t55, ptr %l36, !tbaa !27
  %t56 = load i64, ptr %l6, !tbaa !24
  %t58 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = getelementptr ptr, ptr %t59, i64 %t56
  %t61 = load ptr, ptr %t60, !tbaa !39
  store ptr %t61, ptr %l8, !tbaa !29
  %t63 = load ptr, ptr %l8, !tbaa !29
  %t65 = getelementptr %"compiler/ast:Path", ptr %t63, i32 0, i32 1
  %t66 = load { i64, ptr }, ptr %t65, !tbaa !27
  %t68 = extractvalue { i64, ptr } %t66, 0
  %t70 = icmp eq i64 %t68, 0
  br i1 %t70, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l43, !tbaa !21
  br label %bb14
bb12:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr %"compiler/check:Checker", ptr %t72, i32 0, i32 1
  %t75 = load ptr, ptr %t74, !tbaa !29
  %t76 = load ptr, ptr %l8, !tbaa !29
  %t80 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorType(ptr %v0, ptr %s0, ptr %v0, ptr %t75, ptr %l4, ptr %t76)
  store i32 %t80, ptr %l48
  br label %bb13
bb13:
  %t81 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t82 = load i32, ptr %l48, !tbaa !23
  %t84 = icmp ne i32 %t82, %t81
  store i1 %t84, ptr %l43, !tbaa !21
  br label %bb14
bb14:
  %t86 = load i1, ptr %l43, !tbaa !21
  br i1 %t86, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s3)
  br label %bb46
bb16:
  br label %bb17
bb17:
  %t87 = load ptr, ptr %l8, !tbaa !29
  %t89 = getelementptr %"compiler/ast:Path", ptr %t87, i32 0, i32 1
  %t90 = load { i64, ptr }, ptr %t89, !tbaa !27
  %t92 = extractvalue { i64, ptr } %t90, 0
  store i64 %t92, ptr %l9, !tbaa !24
  %t94 = load i64, ptr %l9, !tbaa !24
  %t96 = icmp sge i64 %t94, 2
  br i1 %t96, label %bb18, label %bb19
bb18:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/check:Checker", ptr %t98, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !29
  store ptr %t101, ptr %l58, !tbaa !29
  store ptr %l4, ptr %l59, !tbaa !29
  %t102 = load ptr, ptr %l8, !tbaa !29
  %t104 = getelementptr %"compiler/ast:Path", ptr %t102, i32 0, i32 0
  %t105 = load %"compiler/source:Span", ptr %t104
  store %"compiler/source:Span" %t105, ptr %l61
  %t106 = load ptr, ptr %l8, !tbaa !29
  %t108 = getelementptr %"compiler/ast:Path", ptr %t106, i32 0, i32 1
  %t109 = load { i64, ptr }, ptr %t108, !tbaa !27
  store { i64, ptr } %t109, ptr %l63, !tbaa !27
  %t110 = load i64, ptr %l9, !tbaa !24
  %t112 = sub i64 %t110, 1
  store i64 %t112, ptr %l65, !tbaa !24
  %t113 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t113, 0
  store i64 %t114, ptr %l66, !tbaa !24
  %t115 = icmp sge i64 0, 0
  br i1 %t115, label %bb20, label %bb21
bb19:
  store i1 false, ptr %l56, !tbaa !21
  br label %bb28
bb20:
  %t117 = load i64, ptr %l65, !tbaa !24
  %t118 = icmp sle i64 0, %t117
  br i1 %t118, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_5a93da9c7afac93d_73d680f9d44bf021)
  unreachable
bb22:
  %t120 = load i64, ptr %l65, !tbaa !24
  %t121 = load i64, ptr %l66, !tbaa !24
  %t122 = icmp sle i64 %t120, %t121
  br i1 %t122, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_5a93da9c7afac93d_73d680f9d44bf021)
  unreachable
bb24:
  %t124 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !27
  %t126 = load i64, ptr %l65, !tbaa !24
  %t127 = getelementptr i32, ptr %t125, i64 0
  %t128 = sub i64 %t126, 0
  %t129 = insertvalue { i64, ptr } undef, i64 %t128, 0
  %t130 = insertvalue { i64, ptr } %t129, ptr %t127, 1
  %t131 = load %"compiler/source:Span", ptr %l61
  %t133 = call %"compiler/ast:Path" @compiler_2fast_3aPath_2ector(ptr %v0, ptr %s3, %"compiler/source:Span" %t131, { i64, ptr } %t130)
  store %"compiler/ast:Path" %t133, ptr %l71
  br label %bb26
bb25:
  call void @__olang_check_failed(ptr @olang_loc_5a93da9c7afac93d_73d680f9d44bf021)
  unreachable
bb26:
  %t134 = load %"compiler/ast:Path", ptr %l71
  %t135 = call ptr @__olang_scope_alloc_a(ptr %s3, i64 24, i64 8)
  store %"compiler/ast:Path" %t134, ptr %t135
  %t136 = load ptr, ptr %l58, !tbaa !29
  %t137 = load ptr, ptr %l59, !tbaa !29
  %t139 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorType(ptr %v0, ptr %s0, ptr %s3, ptr %t136, ptr %t137, ptr %t135)
  store i32 %t139, ptr %l73
  br label %bb27
bb27:
  %t140 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t141 = load i32, ptr %l73, !tbaa !23
  %t143 = icmp ne i32 %t141, %t140
  store i1 %t143, ptr %l56, !tbaa !21
  br label %bb28
bb28:
  %t145 = load i1, ptr %l56, !tbaa !21
  br i1 %t145, label %bb29, label %bb30
bb29:
  call void @__olang_scope_close(ptr %s3)
  br label %bb46
bb30:
  br label %bb31
bb31:
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t148 = getelementptr %"compiler/check:Checker", ptr %t146, i32 0, i32 1
  %t149 = load ptr, ptr %t148, !tbaa !29
  %t151 = getelementptr %"compiler/generic:Program", ptr %t149, i32 0, i32 0
  %t152 = load ptr, ptr %t151, !tbaa !29
  %t154 = getelementptr %"compiler/load:Loader", ptr %t152, i32 0, i32 5
  %t155 = load i64, ptr %l3, !tbaa !24
  %t158 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t154, i64 %t155)
  store ptr %t158, ptr %l81
  br label %bb32
bb32:
  %t159 = load ptr, ptr %l81, !tbaa !29
  %t161 = getelementptr %"compiler/load:Module", ptr %t159, i32 0, i32 6
  %t162 = load ptr, ptr %t161, !tbaa !29
  store ptr %t162, ptr %l10, !tbaa !29
  %t164 = load ptr, ptr %l10, !tbaa !29
  %t166 = icmp eq ptr %t164, null
  br i1 %t166, label %bb33, label %bb34
bb33:
  call void @__olang_check_failed(ptr @olang_loc_cb89be5255da0a98_182555ab3f6639bc)
  unreachable
bb34:
  br label %bb35
bb35:
  %t168 = load ptr, ptr %l10, !tbaa !29
  %t171 = getelementptr %"compiler/source:Source", ptr %t168, i32 0, i32 1
  %t172 = load { i64, ptr }, ptr %t171, !tbaa !27
  store { i64, ptr } %t172, ptr %l88, !tbaa !27
  %t173 = load ptr, ptr %l8, !tbaa !29
  %t175 = getelementptr %"compiler/ast:Path", ptr %t173, i32 0, i32 0
  %t176 = getelementptr %"compiler/source:Span", ptr %t175, i32 0, i32 0
  %t177 = load i32, ptr %t176, !tbaa !23
  %t179 = sext i32 %t177 to i64
  store i64 %t179, ptr %l91, !tbaa !24
  %t180 = load ptr, ptr %l8, !tbaa !29
  %t182 = getelementptr %"compiler/ast:Path", ptr %t180, i32 0, i32 0
  %t183 = getelementptr %"compiler/source:Span", ptr %t182, i32 0, i32 1
  %t184 = load i32, ptr %t183, !tbaa !23
  %t186 = sext i32 %t184 to i64
  store i64 %t186, ptr %l94, !tbaa !24
  %t187 = load { i64, ptr }, ptr %l88, !tbaa !27
  %t188 = extractvalue { i64, ptr } %t187, 0
  store i64 %t188, ptr %l95, !tbaa !24
  %t189 = load i64, ptr %l91, !tbaa !24
  %t190 = icmp sge i64 %t189, 0
  br i1 %t190, label %bb36, label %bb37
bb36:
  %t192 = load i64, ptr %l91, !tbaa !24
  %t193 = load i64, ptr %l94, !tbaa !24
  %t194 = icmp sle i64 %t192, %t193
  br i1 %t194, label %bb38, label %bb39
bb37:
  call void @__olang_check_failed(ptr @olang_loc_920e32cd1c61adb_5a2712b6fcd7371f)
  unreachable
bb38:
  %t196 = load i64, ptr %l94, !tbaa !24
  %t197 = load i64, ptr %l95, !tbaa !24
  %t198 = icmp sle i64 %t196, %t197
  br i1 %t198, label %bb40, label %bb41
bb39:
  call void @__olang_check_failed(ptr @olang_loc_920e32cd1c61adb_5a2712b6fcd7371f)
  unreachable
bb40:
  %t200 = getelementptr { i64, ptr }, ptr %l88, i32 0, i32 1
  %t201 = load ptr, ptr %t200, !tbaa !27
  %t202 = load i64, ptr %l91, !tbaa !24
  %t203 = load i64, ptr %l94, !tbaa !24
  %t204 = getelementptr i8, ptr %t201, i64 %t202
  %t205 = sub i64 %t203, %t202
  %t206 = insertvalue { i64, ptr } undef, i64 %t205, 0
  %t207 = insertvalue { i64, ptr } %t206, ptr %t204, 1
  store { i64, ptr } %t207, ptr %l11, !tbaa !27
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t211 = getelementptr %"compiler/check:Checker", ptr %t209, i32 0, i32 1
  %t212 = load ptr, ptr %t211, !tbaa !29
  %t214 = getelementptr %"compiler/generic:Program", ptr %t212, i32 0, i32 0
  %t215 = load ptr, ptr %t214, !tbaa !29
  %t217 = getelementptr %"compiler/load:Loader", ptr %t215, i32 0, i32 4
  %t218 = load ptr, ptr %t217, !tbaa !29
  store ptr %t218, ptr %l103, !tbaa !29
  %t219 = load ptr, ptr %l0, !tbaa !29
  %t221 = getelementptr %"compiler/check:Checker", ptr %t219, i32 0, i32 1
  %t222 = load ptr, ptr %t221, !tbaa !29
  %t224 = getelementptr %"compiler/generic:Program", ptr %t222, i32 0, i32 0
  %t225 = load ptr, ptr %t224, !tbaa !29
  %t227 = getelementptr %"compiler/load:Loader", ptr %t225, i32 0, i32 5
  %t228 = load i64, ptr %l3, !tbaa !24
  %t231 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t227, i64 %t228)
  store ptr %t231, ptr %l109
  br label %bb42
bb41:
  call void @__olang_check_failed(ptr @olang_loc_920e32cd1c61adb_5a2712b6fcd7371f)
  unreachable
bb42:
  %t232 = load ptr, ptr %l109, !tbaa !29
  %t234 = getelementptr %"compiler/load:Module", ptr %t232, i32 0, i32 4
  %t235 = load i64, ptr %t234, !tbaa !24
  %t236 = load ptr, ptr %l8, !tbaa !29
  %t238 = getelementptr %"compiler/ast:Path", ptr %t236, i32 0, i32 0
  %t239 = getelementptr %"compiler/source:Span", ptr %t238, i32 0, i32 0
  %t240 = load i32, ptr %t239, !tbaa !23
  %t242 = sext i32 %t240 to i64
  %t243 = load ptr, ptr %l8, !tbaa !29
  %t245 = getelementptr %"compiler/ast:Path", ptr %t243, i32 0, i32 0
  %t246 = getelementptr %"compiler/source:Span", ptr %t245, i32 0, i32 1
  %t247 = load i32, ptr %t246, !tbaa !23
  %t249 = sext i32 %t247 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t250
  %t251 = getelementptr { i64, [3 x i64] }, ptr %t250, i32 0, i32 0
  store i64 3, ptr %t251
  %t253 = insertvalue { i64, i64, i64 } undef, i64 %t235, 0
  %t255 = insertvalue { i64, i64, i64 } %t253, i64 %t242, 1
  %t257 = insertvalue { i64, i64, i64 } %t255, i64 %t249, 2
  %t258 = getelementptr { i64, [3 x i64] }, ptr %t250, i32 0, i32 1
  store { i64, i64, i64 } %t257, ptr %t258
  %t259 = load { i64, [3 x i64] }, ptr %t250
  store { i64, [3 x i64] } %t259, ptr %l118
  %t260 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t262 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %s3, { i64, ptr } %t260)
  store { i64, ptr } %t262, ptr %l120
  br label %bb43
bb43:
  %t263 = load { i64, ptr }, ptr %l120, !tbaa !27
  %t264 = extractvalue { i64, ptr } %t263, 0
  %t265 = extractvalue { i64, ptr } %t263, 1
  %t266 = mul i64 %t264, 1
  %t267 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t266)
  call void @llvm.memcpy.p0.p0.i64(ptr %t267, ptr %t265, i64 %t266, i1 false)
  %t268 = insertvalue { i64, ptr } undef, i64 %t264, 0
  %t269 = insertvalue { i64, ptr } %t268, ptr %t267, 1
  %t271 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnknownErrorType(ptr %s3, ptr %s3, { i64, ptr } %t269)
  store %"compiler/msgs:Msg" %t271, ptr %l122
  br label %bb44
bb44:
  %t272 = load ptr, ptr %l103, !tbaa !29
  %t273 = load { i64, [3 x i64] }, ptr %l118
  %t274 = load %"compiler/msgs:Msg", ptr %l122
  %t275 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s3, ptr %t272, { i64, [3 x i64] } %t273, %"compiler/msgs:Msg" %t274)
  store i64 %t275, ptr %l123
  br label %bb45
bb45:
  call void @__olang_scope_close(ptr %s3)
  br label %bb46
bb46:
  %t276 = load i64, ptr %l6, !tbaa !24
  %t278 = add i64 %t276, 1
  store i64 %t278, ptr %l6, !tbaa !24
  br label %bb7
bb47:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexternParam(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l6 = alloca i1
  %l10 = alloca i1
  %l15 = alloca i32
  %l20 = alloca i32
  %l23 = alloca i1
  %l26 = alloca ptr
  %l27 = alloca ptr
  %l32 = alloca i32
  %l33 = alloca i32
  %l34 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t7 = load i32, ptr %l1, !tbaa !23
  %t10 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNumber(ptr %v0, ptr %t6, i32 %t7)
  store i1 %t10, ptr %l6
  br label %bb1
bb1:
  %t11 = load i1, ptr %l6, !tbaa !21
  br i1 %t11, label %bb2, label %bb3
bb2:
  store i1 true, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load i32, ptr %l1, !tbaa !23
  %t17 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t13, i32 %t14)
  store i1 %t17, ptr %l10
  br label %bb5
bb5:
  %t18 = load i1, ptr %l10, !tbaa !21
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/check:Checker", ptr %t19, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t24 = getelementptr %"compiler/generic:Program", ptr %t22, i32 0, i32 2
  %t25 = load i32, ptr %l1, !tbaa !23
  %t28 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t24, i32 %t25)
  store i32 %t28, ptr %l15
  br label %bb8
bb7:
  br label %bb9
bb8:
  %t29 = load i32, ptr %l15, !tbaa !23
  store i32 %t29, ptr %l1, !tbaa !23
  br label %bb9
bb9:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/check:Checker", ptr %t30, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t35 = getelementptr %"compiler/generic:Program", ptr %t33, i32 0, i32 2
  %t36 = load i32, ptr %l1, !tbaa !23
  %t39 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t35, i32 %t36)
  store i32 %t39, ptr %l20
  br label %bb10
bb10:
  %t40 = load i32, ptr %l20
  %t42 = trunc i64 19 to i32
  %t43 = icmp eq i32 %t40, %t42
  br i1 %t43, label %bb11, label %bb12
bb11:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/check:Checker", ptr %t45, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !29
  %t50 = getelementptr %"compiler/generic:Program", ptr %t48, i32 0, i32 2
  store ptr %t50, ptr %l26, !tbaa !29
  %t51 = load ptr, ptr %l0, !tbaa !29
  store ptr %t51, ptr %l27, !tbaa !29
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/check:Checker", ptr %t52, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !29
  %t57 = getelementptr %"compiler/generic:Program", ptr %t55, i32 0, i32 2
  %t58 = load i32, ptr %l1, !tbaa !23
  %t61 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t57, i32 %t58)
  store i32 %t61, ptr %l32
  br label %bb13
bb12:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb16
bb13:
  %t62 = load ptr, ptr %l27, !tbaa !29
  %t63 = load i32, ptr %l32, !tbaa !23
  %t64 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t62, i32 %t63)
  store i32 %t64, ptr %l33
  br label %bb14
bb14:
  %t65 = load ptr, ptr %l26, !tbaa !29
  %t66 = load i32, ptr %l33, !tbaa !23
  %t67 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNumber(ptr %v0, ptr %t65, i32 %t66)
  store i1 %t67, ptr %l34
  br label %bb15
bb15:
  %t68 = load i1, ptr %l34, !tbaa !21
  store i1 %t68, ptr %l23, !tbaa !21
  br label %bb16
bb16:
  %t69 = load i1, ptr %l23, !tbaa !21
  store i1 %t69, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efnBody(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i32
  %l17 = alloca i64
  %l21 = alloca i32
  %l22 = alloca ptr
  %l24 = alloca { i64, [2 x i64] }
  %l25 = alloca i32
  %l29 = alloca i64
  %l33 = alloca ptr
  %l36 = alloca i64
  %l43 = alloca i1
  %rv = alloca i64
  %t40 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 16
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t3, i64 %t4)
  %t8 = extractvalue { i32, i64 } %t7, 1
  %t9 = extractvalue { i32, i64 } %t7, 0
  store i32 %t9, ptr %l10
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11
ok.11:
  store i64 %t8, ptr %l9
  br label %bb1
bb1:
  %t12 = load i64, ptr %l9, !tbaa !24
  store i64 %t12, ptr %l5, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  store i64 -1, ptr %l5, !tbaa !24
  br label %bb4
bb4:
  %t13 = load i64, ptr %l5, !tbaa !24
  store i64 %t13, ptr %l2, !tbaa !24
  %t14 = load i64, ptr %l2, !tbaa !24
  %t16 = icmp sge i64 %t14, 0
  br i1 %t16, label %bb5, label %bb6
bb5:
  %t18 = load i64, ptr %l2, !tbaa !24
  store i64 %t18, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/check:Checker", ptr %t20, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t24 = load i64, ptr %l1, !tbaa !24
  %t27 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t23, i64 %t24)
  store i64 %t27, ptr %l17
  br label %bb8
bb8:
  %t28 = load i64, ptr %l17, !tbaa !24
  store i64 %t28, ptr %l3, !tbaa !24
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/check:Checker", ptr %t29, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t33 = load i64, ptr %l1, !tbaa !24
  %t36 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceSig(ptr %v0, ptr %t32, i64 %t33)
  store i32 %t36, ptr %l21
  br label %bb9
bb9:
  %t37 = load i32, ptr %l21, !tbaa !23
  store i32 %t37, ptr %l4, !tbaa !23
  %t38 = load ptr, ptr %l0, !tbaa !29
  store ptr %t38, ptr %l22, !tbaa !29
  %t39 = load i64, ptr %l1, !tbaa !24
  store { i64, [2 x i64] } zeroinitializer, ptr %t40
  %t41 = getelementptr { i64, [2 x i64] }, ptr %t40, i32 0, i32 0
  store i64 0, ptr %t41
  %t43 = insertvalue { i64 } undef, i64 %t39, 0
  %t44 = getelementptr { i64, [2 x i64] }, ptr %t40, i32 0, i32 1
  store { i64 } %t43, ptr %t44
  %t45 = load { i64, [2 x i64] }, ptr %t40
  store { i64, [2 x i64] } %t45, ptr %l24
  %t46 = load i32, ptr %l4, !tbaa !23
  store i32 %t46, ptr %l25, !tbaa !23
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/check:Checker", ptr %t47, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !29
  %t51 = load i64, ptr %l3, !tbaa !24
  %t54 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t50, i64 %t51)
  store i64 %t54, ptr %l29
  br label %bb10
bb10:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/check:Checker", ptr %t55, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !29
  %t59 = load i64, ptr %l3, !tbaa !24
  %t62 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t58, i64 %t59)
  store ptr %t62, ptr %l33
  br label %bb11
bb11:
  %t63 = load ptr, ptr %l33, !tbaa !29
  %t65 = getelementptr %"compiler/ast:Func", ptr %t63, i32 0, i32 0
  %t66 = load %"compiler/source:Span", ptr %t65
  %t67 = load ptr, ptr %l22, !tbaa !29
  %t68 = load { i64, [2 x i64] }, ptr %l24
  %t69 = load i32, ptr %l25, !tbaa !23
  %t70 = load i64, ptr %l29, !tbaa !24
  %t72 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enewBody(ptr %v0, ptr %t67, { i64, [2 x i64] } %t68, i32 %t69, i64 %t70, %"compiler/source:Span" %t66)
  store i64 %t72, ptr %l36
  br label %bb12
bb12:
  %t73 = load i64, ptr %l36, !tbaa !24
  store i64 %t73, ptr %l2, !tbaa !24
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/check:Checker", ptr %t74, i32 0, i32 16
  %t77 = load i64, ptr %l1, !tbaa !24
  %t78 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t76, i64 %t77, i64 %t78)
  br label %bb13
bb13:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t83 = load i32, ptr %l4, !tbaa !23
  %t86 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einfersErrs(ptr %v0, ptr %t82, i32 %t83)
  store i1 %t86, ptr %l43
  br label %bb14
bb14:
  %t87 = load i1, ptr %l43, !tbaa !21
  br i1 %t87, label %bb15, label %bb16
bb15:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/check:Checker", ptr %t88, i32 0, i32 45
  %t91 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t90, i64 %t91, i1 true)
  br label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb18
bb18:
  %t94 = load i64, ptr %l2, !tbaa !24
  store i64 %t94, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l6 = alloca ptr
  %l9 = alloca i64
  %l11 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 12
  %t5 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fcheck_3aframe_26_3_H2d42092ce658fb6cce0104fa754a4e33(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp sgt i64 %t6, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/check:Checker", ptr %t9, i32 0, i32 12
  store ptr %t11, ptr %l6, !tbaa !29
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/check:Checker", ptr %t12, i32 0, i32 12
  %t16 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fcheck_3aframe_26_3_H2d42092ce658fb6cce0104fa754a4e33(ptr %v0, ptr %t14)
  store i64 %t16, ptr %l9
  br label %bb4
bb3:
  %t17 = extractvalue { i64, ptr } { i64 44, ptr @.d3 }, 1
  %t18 = extractvalue { i64, ptr } { i64 44, ptr @.d3 }, 0
  %t19 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t17, 1
  call void @__olang_check_failed_text(ptr @olang_loc_fd7c4531a6f9112_8820f62eca2e3ad6, { i64, ptr } %t20)
  unreachable
bb4:
  %t21 = load i64, ptr %l9, !tbaa !24
  %t22 = sub i64 %t21, 1
  %t23 = load ptr, ptr %l6, !tbaa !29
  %t25 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fcheck_3aframe_26_3_Hbcd822ae67306ca6a025f17ed2cfb61c(ptr %v0, ptr %v0, ptr %t23, i64 %t22)
  store ptr %t25, ptr %l11
  br label %bb5
bb5:
  %t26 = load ptr, ptr %l11, !tbaa !29
  store ptr %t26, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eheldArg(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, ptr %a2, i64 %a3) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca ptr
  %l3 = alloca i64
  %l6 = alloca i64
  %l8 = alloca { i64, ptr }
  %l11 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l15 = alloca %"compiler/source:Span"
  %l18 = alloca i64
  %l19 = alloca ptr
  %rv = alloca ptr
  store { i64, ptr } %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t2 = load i64, ptr %l3, !tbaa !24
  %t5 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t1, i64 %t2)
  store i64 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i64, ptr %l6, !tbaa !24
  %t7 = icmp slt i64 %t6, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t9, ptr %l8, !tbaa !27
  %t10 = load i64, ptr %l3, !tbaa !24
  %t12 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr ptr, ptr %t13, i64 %t10
  %t15 = load ptr, ptr %t14, !tbaa !39
  store ptr %t15, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  store ptr %a0, ptr %l11, !tbaa !29
  %t18 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t18, ptr %l12, !tbaa !27
  %t19 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr ptr, ptr %t22, i64 %t19
  %t24 = load ptr, ptr %t23, !tbaa !39
  %t26 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %t24)
  store %"compiler/source:Span" %t26, ptr %l15
  br label %bb5
bb5:
  %t27 = load ptr, ptr %l2, !tbaa !29
  %t28 = load i64, ptr %l3, !tbaa !24
  %t31 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t27, i64 %t28)
  store i64 %t31, ptr %l18
  br label %bb6
bb6:
  %t32 = load ptr, ptr %l11, !tbaa !29
  %t33 = load %"compiler/source:Span", ptr %l15
  %t34 = load i64, ptr %l18, !tbaa !24
  %t35 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t32, %"compiler/source:Span" %t33, i64 %t34)
  store ptr %t35, ptr %l19
  br label %bb7
bb7:
  %t36 = load ptr, ptr %l19, !tbaa !29
  store ptr %t36, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eindexPlace(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca ptr
  %l7 = alloca ptr
  %l15 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplace(ptr %v0, ptr %v1, ptr %t1, ptr %a2)
  store ptr %t5, ptr %l7
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l7, !tbaa !29
  store ptr %t6, ptr %l4, !tbaa !29
  %t7 = load ptr, ptr %l4, !tbaa !29
  %t9 = icmp eq ptr %t7, null
  br i1 %t9, label %bb2, label %bb3
bb2:
  store ptr null, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = load ptr, ptr %l4, !tbaa !29
  %t20 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eelemPlace(ptr %v0, ptr %v2, ptr %t12, %"compiler/source:Span" %a1, ptr %t14, { i64, ptr } %a3)
  store ptr %t20, ptr %l15
  br label %bb5
bb5:
  %t21 = load ptr, ptr %l15, !tbaa !29
  store ptr %t21, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einferredCtor(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, { i64, ptr } %a4, i32 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca %"compiler/generic:Binding"
  %lp13 = alloca ptr
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca ptr
  %l21 = alloca %"compiler/check:litv"
  %l22 = alloca i1
  %l23 = alloca ptr
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i32
  %l31 = alloca { i64, ptr }
  %l32 = alloca i32
  %l33 = alloca i32
  %l35 = alloca i32
  %l40 = alloca i32
  %l43 = alloca ptr
  %l46 = alloca i32
  %l47 = alloca i32
  %l52 = alloca i1
  %l57 = alloca i32
  %l60 = alloca i1
  %l65 = alloca i32
  %l68 = alloca i1
  %l73 = alloca i32
  %l80 = alloca ptr
  %l84 = alloca i32
  %l87 = alloca i32
  %l95 = alloca ptr
  %l99 = alloca i32
  %l105 = alloca ptr
  %l107 = alloca i64
  %l112 = alloca i64
  %l115 = alloca ptr
  %l120 = alloca i32
  %l121 = alloca { i64, ptr }
  %l124 = alloca %"compiler/generic:Binding"
  %l125 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l131 = alloca i64
  %l134 = alloca i64
  %l153 = alloca { i64, ptr }
  %l157 = alloca %"compiler/check:litv"
  %l159 = alloca i1
  %l161 = alloca { i64, ptr }
  %l164 = alloca i1
  %l166 = alloca i1
  %l169 = alloca { i64, ptr }
  %l172 = alloca i1
  %l177 = alloca ptr
  %l178 = alloca { i64, ptr }
  %l180 = alloca i32
  %l182 = alloca i32
  %l186 = alloca i32
  %l188 = alloca i32
  %l190 = alloca { i64, ptr }
  %l193 = alloca ptr
  %l194 = alloca i1
  %l197 = alloca ptr
  %l198 = alloca i1
  %l202 = alloca { i64, ptr }
  %l207 = alloca ptr
  %l212 = alloca i1
  %l217 = alloca i1
  %l220 = alloca i32
  %l223 = alloca i1
  %l226 = alloca i32
  %l229 = alloca ptr
  %l230 = alloca { i64, ptr }
  %l232 = alloca i32
  %l235 = alloca i32
  %l253 = alloca i64
  %l256 = alloca i64
  %l274 = alloca { i64, ptr }
  %l280 = alloca ptr
  %l285 = alloca i32
  %l286 = alloca { i64, ptr }
  %l287 = alloca ptr
  %l288 = alloca %"compiler/source:Span"
  %l291 = alloca %"compiler/msgs:Msg"
  %l292 = alloca i64
  %l295 = alloca ptr
  %l298 = alloca i1
  %l299 = alloca { i64, ptr }
  %l300 = alloca i64
  %l303 = alloca ptr
  %l308 = alloca i32
  %l310 = alloca i32
  %l313 = alloca ptr
  %l316 = alloca i32
  %l317 = alloca i32
  %l320 = alloca { i64, ptr }
  %l321 = alloca i64
  %l327 = alloca i32
  %l331 = alloca ptr
  %l332 = alloca i32
  %l337 = alloca i32
  %l338 = alloca i32
  %l342 = alloca i1
  %l344 = alloca i1
  %l348 = alloca i1
  %l352 = alloca ptr
  %l356 = alloca i32
  %l362 = alloca ptr
  %l365 = alloca i64
  %l370 = alloca ptr
  %l371 = alloca %"compiler/source:Span"
  %l372 = alloca %"compiler/source:Span"
  %l373 = alloca i32
  %l378 = alloca ptr
  %l379 = alloca { i64, ptr }
  %l381 = alloca { i64, ptr }
  %l382 = alloca ptr
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %rv = alloca ptr
  %t706 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  store i32 %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  store i32 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l5, !tbaa !23
  %t2 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t5 = icmp ne i32 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  store ptr %t12, ptr %l43, !tbaa !29
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load i32, ptr %l5, !tbaa !23
  %t17 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t13, i32 %t14)
  store i32 %t17, ptr %l46
  br label %bb3
bb2:
  %t18 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t18, ptr %l40, !tbaa !23
  br label %bb5
bb3:
  %t20 = load ptr, ptr %l43, !tbaa !29
  %t21 = load i32, ptr %l46, !tbaa !23
  %t22 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t20, i32 %t21)
  store i32 %t22, ptr %l47
  br label %bb4
bb4:
  %t23 = load i32, ptr %l47, !tbaa !23
  store i32 %t23, ptr %l40, !tbaa !23
  br label %bb5
bb5:
  %t24 = load i32, ptr %l40, !tbaa !23
  store i32 %t24, ptr %l6, !tbaa !23
  %t25 = load i32, ptr %l6, !tbaa !23
  %t26 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t29 = icmp ne i32 %t25, %t26
  br i1 %t29, label %bb6, label %bb7
bb6:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/check:Checker", ptr %t31, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t36 = getelementptr %"compiler/generic:Program", ptr %t34, i32 0, i32 2
  %t37 = load i32, ptr %l6, !tbaa !23
  %t40 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t36, i32 %t37)
  store i32 %t40, ptr %l57
  br label %bb8
bb7:
  store i1 false, ptr %l52, !tbaa !21
  br label %bb9
bb8:
  %t41 = load i32, ptr %l57
  %t43 = trunc i64 18 to i32
  %t44 = icmp eq i32 %t41, %t43
  store i1 %t44, ptr %l52, !tbaa !21
  br label %bb9
bb9:
  %t46 = load i1, ptr %l52, !tbaa !21
  br i1 %t46, label %bb10, label %bb11
bb10:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/check:Checker", ptr %t47, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !29
  %t52 = getelementptr %"compiler/generic:Program", ptr %t50, i32 0, i32 2
  %t53 = load i32, ptr %l6, !tbaa !23
  %t56 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t52, i32 %t53)
  store i32 %t56, ptr %l65
  br label %bb12
bb11:
  store i1 false, ptr %l60, !tbaa !21
  br label %bb13
bb12:
  %t57 = load i32, ptr %l3, !tbaa !23
  %t58 = load i32, ptr %l65, !tbaa !23
  %t60 = icmp eq i32 %t58, %t57
  store i1 %t60, ptr %l60, !tbaa !21
  br label %bb13
bb13:
  %t62 = load i1, ptr %l60, !tbaa !21
  br i1 %t62, label %bb14, label %bb15
bb14:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/check:Checker", ptr %t63, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t68 = getelementptr %"compiler/generic:Program", ptr %t66, i32 0, i32 2
  %t69 = load i32, ptr %l6, !tbaa !23
  %t72 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t68, i32 %t69)
  store i32 %t72, ptr %l73
  br label %bb16
bb15:
  store i1 false, ptr %l68, !tbaa !21
  br label %bb17
bb16:
  %t73 = load i32, ptr %l73, !tbaa !23
  %t74 = icmp ne i32 %t73, 0
  store i1 %t74, ptr %l68, !tbaa !21
  br label %bb17
bb17:
  %t76 = load i1, ptr %l68, !tbaa !21
  br i1 %t76, label %bb18, label %bb19
bb18:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t78 = load %"compiler/source:Span", ptr %l1
  %t79 = load %"compiler/source:Span", ptr %l2
  %t80 = load i32, ptr %l6, !tbaa !23
  %t81 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t87 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econstruct(ptr %v0, ptr %v1, ptr %t77, %"compiler/source:Span" %t78, %"compiler/source:Span" %t79, i32 %t80, { i64, ptr } %t81)
  store ptr %t87, ptr %l80
  br label %bb20
bb19:
  br label %bb21
bb20:
  call void @__olang_scope_close(ptr %s0)
  %t88 = load ptr, ptr %l80, !tbaa !29
  store ptr %t88, ptr %rv
  br label %ret
bb21:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"compiler/check:Checker", ptr %t89, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !29
  %t93 = load i32, ptr %l3, !tbaa !23
  %t96 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSelfType(ptr %v0, ptr %t92, i32 %t93)
  store i32 %t96, ptr %l84
  br label %bb22
bb22:
  %t97 = load i32, ptr %l84, !tbaa !23
  store i32 %t97, ptr %l7, !tbaa !23
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t99 = load i32, ptr %l7, !tbaa !23
  %t102 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %t98, i32 %t99)
  store i32 %t102, ptr %l87
  br label %bb23
bb23:
  %t103 = load i32, ptr %l87
  %t105 = trunc i64 0 to i32
  %t106 = icmp eq i32 %t103, %t105
  %t108 = xor i1 %t106, true
  br i1 %t108, label %bb24, label %bb25
bb24:
  store %olang.scope zeroinitializer, ptr %s2
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t111 = load %"compiler/source:Span", ptr %l2
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %s2, ptr %t110, %"compiler/source:Span" %t111, { i64, ptr } { i64 63, ptr @.d4 })
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t115 = load %"compiler/source:Span", ptr %l1
  %t118 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t114, %"compiler/source:Span" %t115)
  store ptr %t118, ptr %l95
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t119 = load ptr, ptr %l95, !tbaa !29
  store ptr %t119, ptr %rv
  br label %ret
bb28:
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t122 = getelementptr %"compiler/check:Checker", ptr %t120, i32 0, i32 1
  %t123 = load ptr, ptr %t122, !tbaa !29
  %t124 = load i32, ptr %l7, !tbaa !23
  %t127 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorSig(ptr %v0, ptr %t123, i32 %t124)
  store i32 %t127, ptr %l99
  br label %bb29
bb29:
  %t128 = load i32, ptr %l99, !tbaa !23
  store i32 %t128, ptr %l8, !tbaa !23
  %t129 = load i32, ptr %l8, !tbaa !23
  %t130 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t133 = icmp eq i32 %t129, %t130
  br i1 %t133, label %bb30, label %bb31
bb30:
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t136 = load %"compiler/source:Span", ptr %l1
  %t139 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t135, %"compiler/source:Span" %t136)
  store ptr %t139, ptr %l105
  br label %bb32
bb31:
  br label %bb33
bb32:
  call void @__olang_scope_close(ptr %s0)
  %t140 = load ptr, ptr %l105, !tbaa !29
  store ptr %t140, ptr %rv
  br label %ret
bb33:
  %t141 = load i32, ptr %l3, !tbaa !23
  %t143 = call i64 @compiler_2fgeneric_2eDeclOwner(i32 %t141)
  store i64 %t143, ptr %l107
  br label %bb34
bb34:
  %t144 = load i64, ptr %l107, !tbaa !24
  store i64 %t144, ptr %l9, !tbaa !24
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t147 = getelementptr %"compiler/check:Checker", ptr %t145, i32 0, i32 1
  %t148 = load ptr, ptr %t147, !tbaa !29
  %t150 = getelementptr %"compiler/generic:Program", ptr %t148, i32 0, i32 2
  %t151 = load i32, ptr %l3, !tbaa !23
  %t154 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclParams(ptr %v0, ptr %t150, i32 %t151)
  store i64 %t154, ptr %l112
  br label %bb35
bb35:
  %t155 = load i64, ptr %l112, !tbaa !24
  store i64 %t155, ptr %l10, !tbaa !24
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t158 = getelementptr %"compiler/check:Checker", ptr %t156, i32 0, i32 1
  %t159 = load ptr, ptr %t158, !tbaa !29
  %t161 = getelementptr %"compiler/generic:Program", ptr %t159, i32 0, i32 2
  store ptr %t161, ptr %l115, !tbaa !29
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t164 = getelementptr %"compiler/check:Checker", ptr %t162, i32 0, i32 1
  %t165 = load ptr, ptr %t164, !tbaa !29
  %t167 = getelementptr %"compiler/generic:Program", ptr %t165, i32 0, i32 2
  %t168 = load i32, ptr %l8, !tbaa !23
  %t171 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t167, i32 %t168)
  store i32 %t171, ptr %l120
  br label %bb36
bb36:
  %t172 = load ptr, ptr %l115, !tbaa !29
  %t173 = load i32, ptr %l120, !tbaa !23
  %t174 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t172, i32 %t173)
  store { i64, ptr } %t174, ptr %l121
  br label %bb37
bb37:
  %t175 = load { i64, ptr }, ptr %l121, !tbaa !27
  store { i64, ptr } %t175, ptr %l11, !tbaa !27
  %t176 = load i64, ptr %l9, !tbaa !24
  %t177 = load i64, ptr %l10, !tbaa !24
  %t180 = call %"compiler/generic:Binding" @compiler_2fgeneric_3aBinding_2ector(ptr %s0, i64 %t176, i64 %t177)
  store %"compiler/generic:Binding" %t180, ptr %l124
  br label %bb38
bb38:
  %t181 = load %"compiler/generic:Binding", ptr %l124
  store %"compiler/generic:Binding" %t181, ptr %l12
  %t182 = load ptr, ptr @__olang_prog_scope
  %t183 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e(ptr %t182)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t183, ptr %l125
  br label %bb39
bb39:
  %t184 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 8, i64 8)
  store ptr %t184, ptr %lp13
  %t185 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l125
  %t186 = load ptr, ptr %lp13
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t185, ptr %t186
  store i64 0, ptr %l14, !tbaa !24
  %t187 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t189 = extractvalue { i64, ptr } %t187, 0
  store i64 %t189, ptr %l15, !tbaa !24
  store i64 1, ptr %l16, !tbaa !24
  %t191 = load i64, ptr %l15, !tbaa !24
  %t192 = load i64, ptr %l14, !tbaa !24
  %t195 = icmp sgt i64 %t191, %t192
  br i1 %t195, label %bb40, label %bb41
bb40:
  %t197 = load i64, ptr %l16, !tbaa !24
  %t199 = icmp sgt i64 %t197, 0
  br i1 %t199, label %bb42, label %bb43
bb41:
  store i64 0, ptr %l131, !tbaa !24
  br label %bb45
bb42:
  %t201 = load i64, ptr %l15, !tbaa !24
  %t202 = load i64, ptr %l14, !tbaa !24
  %t205 = sub i64 %t201, %t202
  %t206 = load i64, ptr %l16, !tbaa !24
  %t209 = add i64 %t205, %t206
  %t211 = sub i64 %t209, 1
  %t212 = load i64, ptr %l16, !tbaa !24
  %t215 = sdiv i64 %t211, %t212
  store i64 %t215, ptr %l134, !tbaa !24
  br label %bb44
bb43:
  store i64 0, ptr %l134, !tbaa !24
  br label %bb44
bb44:
  %t217 = load i64, ptr %l134, !tbaa !24
  store i64 %t217, ptr %l131, !tbaa !24
  br label %bb45
bb45:
  %t218 = load i64, ptr %l131, !tbaa !24
  store i64 %t218, ptr %l17, !tbaa !24
  store i64 0, ptr %l18, !tbaa !24
  br label %bb46
bb46:
  store %olang.scope zeroinitializer, ptr %s5
  %t219 = load i64, ptr %l18, !tbaa !24
  %t220 = load i64, ptr %l17, !tbaa !24
  %t223 = icmp slt i64 %t219, %t220
  %t225 = xor i1 %t223, true
  br i1 %t225, label %bb47, label %bb48
bb47:
  call void @__olang_scope_close(ptr %s5)
  br label %bb105
bb48:
  br label %bb49
bb49:
  %t227 = load i64, ptr %l14, !tbaa !24
  %t228 = load i64, ptr %l18, !tbaa !24
  %t229 = load i64, ptr %l16, !tbaa !24
  %t232 = mul i64 %t228, %t229
  %t235 = add i64 %t227, %t232
  store i64 %t235, ptr %l19, !tbaa !24
  store ptr null, ptr %l20, !tbaa !29
  %t237 = load ptr, ptr %l0, !tbaa !29
  %t238 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t238, ptr %l153, !tbaa !27
  %t239 = load i64, ptr %l19, !tbaa !24
  %t241 = getelementptr { i64, ptr }, ptr %l153, i32 0, i32 1
  %t242 = load ptr, ptr %t241, !tbaa !27
  %t243 = getelementptr ptr, ptr %t242, i64 %t239
  %t244 = load ptr, ptr %t243, !tbaa !39
  %t248 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %t237, ptr %t244)
  store %"compiler/check:litv" %t248, ptr %l157
  br label %bb50
bb50:
  %t249 = load %"compiler/check:litv", ptr %l157
  store %"compiler/check:litv" %t249, ptr %l21
  %t250 = getelementptr %"compiler/check:litv", ptr %l21, i32 0, i32 0
  %t251 = load i1, ptr %t250, !tbaa !21
  br i1 %t251, label %bb51, label %bb52
bb51:
  store i1 true, ptr %l159, !tbaa !21
  br label %bb54
bb52:
  %t253 = load ptr, ptr %l0, !tbaa !29
  %t254 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t254, ptr %l161, !tbaa !27
  %t255 = load i64, ptr %l19, !tbaa !24
  %t257 = getelementptr { i64, ptr }, ptr %l161, i32 0, i32 1
  %t258 = load ptr, ptr %t257, !tbaa !27
  %t259 = getelementptr ptr, ptr %t258, i64 %t255
  %t260 = load ptr, ptr %t259, !tbaa !39
  %t263 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v1, ptr %t253, ptr %t260)
  store i1 %t263, ptr %l164
  br label %bb53
bb53:
  %t264 = load i1, ptr %l164, !tbaa !21
  store i1 %t264, ptr %l159, !tbaa !21
  br label %bb54
bb54:
  %t265 = load i1, ptr %l159, !tbaa !21
  br i1 %t265, label %bb55, label %bb56
bb55:
  %t266 = getelementptr %"compiler/check:litv", ptr %l21, i32 0, i32 0
  %t267 = load i1, ptr %t266, !tbaa !21
  br i1 %t267, label %bb57, label %bb58
bb56:
  %t269 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t269, ptr %l190, !tbaa !27
  %t270 = load i64, ptr %l19, !tbaa !24
  %t272 = getelementptr { i64, ptr }, ptr %l190, i32 0, i32 1
  %t273 = load ptr, ptr %t272, !tbaa !27
  %t274 = getelementptr ptr, ptr %t273, i64 %t270
  %t275 = load ptr, ptr %t274, !tbaa !39
  store ptr %t275, ptr %l23, !tbaa !29
  %t277 = load ptr, ptr %l23, !tbaa !29
  store ptr %t277, ptr %l193, !tbaa !29
  store i1 false, ptr %l194, !tbaa !21
  %t278 = load ptr, ptr %l193, !tbaa !29
  %t279 = icmp ne ptr %t278, null
  br i1 %t279, label %bb70, label %bb71
bb57:
  %t281 = getelementptr %"compiler/check:litv", ptr %l21, i32 0, i32 1
  %t282 = load i1, ptr %t281, !tbaa !21
  store i1 %t282, ptr %l166, !tbaa !21
  br label %bb60
bb58:
  %t284 = load ptr, ptr %l0, !tbaa !29
  %t285 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t285, ptr %l169, !tbaa !27
  %t286 = load i64, ptr %l19, !tbaa !24
  %t288 = getelementptr { i64, ptr }, ptr %l169, i32 0, i32 1
  %t289 = load ptr, ptr %t288, !tbaa !27
  %t290 = getelementptr ptr, ptr %t289, i64 %t286
  %t291 = load ptr, ptr %t290, !tbaa !39
  %t294 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitFloat(ptr %v0, ptr %v1, ptr %t284, ptr %t291)
  store i1 %t294, ptr %l172
  br label %bb59
bb59:
  %t295 = load i1, ptr %l172, !tbaa !21
  store i1 %t295, ptr %l166, !tbaa !21
  br label %bb60
bb60:
  %t296 = load i1, ptr %l166, !tbaa !21
  store i1 %t296, ptr %l22, !tbaa !21
  %t297 = load i64, ptr %l19, !tbaa !24
  %t298 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t300 = extractvalue { i64, ptr } %t298, 0
  %t303 = icmp slt i64 %t297, %t300
  br i1 %t303, label %bb61, label %bb62
bb61:
  store %olang.scope zeroinitializer, ptr %s7
  %t305 = load ptr, ptr %l0, !tbaa !29
  store ptr %t305, ptr %l177, !tbaa !29
  %t306 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t306, ptr %l178, !tbaa !27
  %t307 = load i64, ptr %l19, !tbaa !24
  %t309 = getelementptr { i64, ptr }, ptr %l178, i32 0, i32 1
  %t310 = load ptr, ptr %t309, !tbaa !27
  %t311 = getelementptr i32, ptr %t310, i64 %t307
  %t312 = load i32, ptr %t311, !tbaa !33
  store i32 %t312, ptr %l180, !tbaa !23
  %t313 = load i1, ptr %l22, !tbaa !21
  br i1 %t313, label %bb63, label %bb64
bb62:
  br label %bb69
bb63:
  %t315 = load ptr, ptr %l0, !tbaa !29
  %t317 = getelementptr %"compiler/check:Checker", ptr %t315, i32 0, i32 1
  %t318 = load ptr, ptr %t317, !tbaa !29
  %t320 = getelementptr %"compiler/generic:Program", ptr %t318, i32 0, i32 2
  %t322 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s7, ptr %t320, { i64, ptr } { i64 3, ptr @.d5 })
  store i32 %t322, ptr %l186
  br label %bb65
bb64:
  %t323 = load ptr, ptr %l0, !tbaa !29
  %t325 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t323)
  store i32 %t325, ptr %l188
  br label %bb66
bb65:
  %t326 = load i32, ptr %l186, !tbaa !23
  store i32 %t326, ptr %l182, !tbaa !23
  br label %bb67
bb66:
  %t327 = load i32, ptr %l188, !tbaa !23
  store i32 %t327, ptr %l182, !tbaa !23
  br label %bb67
bb67:
  %t328 = load ptr, ptr %l177, !tbaa !29
  %t329 = load i32, ptr %l180, !tbaa !23
  %t330 = load i32, ptr %l182, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunify(ptr %v0, ptr %s0, ptr %t328, i32 %t329, i32 %t330, ptr %l12, i1 true, i1 false)
  br label %bb68
bb68:
  call void @__olang_scope_close(ptr %s7)
  br label %bb69
bb69:
  br label %bb82
bb70:
  %t332 = load ptr, ptr %l193, !tbaa !29
  %t333 = load i64, ptr %t332
  %t335 = icmp eq i64 %t333, 23
  store i1 %t335, ptr %l194, !tbaa !21
  br label %bb71
bb71:
  %t336 = load i1, ptr %l194, !tbaa !21
  br i1 %t336, label %bb72, label %bb73
bb72:
  br label %bb78
bb73:
  %t337 = load ptr, ptr %l23, !tbaa !29
  store ptr %t337, ptr %l197, !tbaa !29
  store i1 false, ptr %l198, !tbaa !21
  %t338 = load ptr, ptr %l197, !tbaa !29
  %t339 = icmp ne ptr %t338, null
  br i1 %t339, label %bb74, label %bb75
bb74:
  %t341 = load ptr, ptr %l197, !tbaa !29
  %t342 = load i64, ptr %t341
  %t344 = icmp eq i64 %t342, 26
  store i1 %t344, ptr %l198, !tbaa !21
  br label %bb75
bb75:
  %t345 = load i1, ptr %l198, !tbaa !21
  br i1 %t345, label %bb76, label %bb77
bb76:
  br label %bb78
bb77:
  br label %bb79
bb78:
  br label %bb81
bb79:
  %t346 = load ptr, ptr %l0, !tbaa !29
  %t347 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t347, ptr %l202, !tbaa !27
  %t348 = load i64, ptr %l19, !tbaa !24
  %t350 = getelementptr { i64, ptr }, ptr %l202, i32 0, i32 1
  %t351 = load ptr, ptr %t350, !tbaa !27
  %t352 = getelementptr ptr, ptr %t351, i64 %t348
  %t353 = load ptr, ptr %t352, !tbaa !39
  %t355 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t359 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %t346, ptr %t353, i32 %t355)
  store ptr %t359, ptr %l207
  br label %bb80
bb80:
  %t360 = load ptr, ptr %l207, !tbaa !29
  store ptr %t360, ptr %l20, !tbaa !29
  br label %bb81
bb81:
  br label %bb82
bb82:
  %t362 = load ptr, ptr %l20, !tbaa !29
  %t364 = icmp eq ptr %t362, null
  %t366 = xor i1 %t364, true
  br i1 %t366, label %bb83, label %bb84
bb83:
  %t368 = load i64, ptr %l19, !tbaa !24
  %t369 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t371 = extractvalue { i64, ptr } %t369, 0
  %t374 = icmp slt i64 %t368, %t371
  store i1 %t374, ptr %l212, !tbaa !21
  br label %bb85
bb84:
  store i1 false, ptr %l212, !tbaa !21
  br label %bb85
bb85:
  %t376 = load i1, ptr %l212, !tbaa !21
  br i1 %t376, label %bb86, label %bb87
bb86:
  %t377 = load ptr, ptr %l20, !tbaa !29
  %t380 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t377)
  store i32 %t380, ptr %l220
  br label %bb88
bb87:
  store i1 false, ptr %l217, !tbaa !21
  br label %bb89
bb88:
  %t381 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t382 = load i32, ptr %l220, !tbaa !23
  %t384 = icmp ne i32 %t382, %t381
  store i1 %t384, ptr %l217, !tbaa !21
  br label %bb89
bb89:
  %t386 = load i1, ptr %l217, !tbaa !21
  br i1 %t386, label %bb90, label %bb91
bb90:
  %t387 = load ptr, ptr %l20, !tbaa !29
  %t390 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t387)
  store i32 %t390, ptr %l226
  br label %bb92
bb91:
  store i1 false, ptr %l223, !tbaa !21
  br label %bb93
bb92:
  %t391 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t392 = load i32, ptr %l226, !tbaa !23
  %t394 = icmp ne i32 %t392, %t391
  store i1 %t394, ptr %l223, !tbaa !21
  br label %bb93
bb93:
  %t396 = load i1, ptr %l223, !tbaa !21
  br i1 %t396, label %bb94, label %bb95
bb94:
  %t397 = load ptr, ptr %l0, !tbaa !29
  store ptr %t397, ptr %l229, !tbaa !29
  %t398 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t398, ptr %l230, !tbaa !27
  %t399 = load i64, ptr %l19, !tbaa !24
  %t401 = getelementptr { i64, ptr }, ptr %l230, i32 0, i32 1
  %t402 = load ptr, ptr %t401, !tbaa !27
  %t403 = getelementptr i32, ptr %t402, i64 %t399
  %t404 = load i32, ptr %t403, !tbaa !33
  store i32 %t404, ptr %l232, !tbaa !23
  %t405 = load ptr, ptr %l0, !tbaa !29
  %t406 = load ptr, ptr %l20, !tbaa !29
  %t409 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebindType(ptr %v0, ptr %v0, ptr %t405, ptr %t406)
  store i32 %t409, ptr %l235
  br label %bb96
bb95:
  br label %bb98
bb96:
  %t410 = load ptr, ptr %l229, !tbaa !29
  %t411 = load i32, ptr %l232, !tbaa !23
  %t412 = load i32, ptr %l235, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunify(ptr %v0, ptr %s0, ptr %t410, i32 %t411, i32 %t412, ptr %l12, i1 false, i1 false)
  br label %bb97
bb97:
  br label %bb98
bb98:
  %t414 = load ptr, ptr %l20, !tbaa !29
  %t416 = icmp eq ptr %t414, null
  br i1 %t416, label %bb99, label %bb100
bb99:
  %t418 = load ptr, ptr %lp13
  %t419 = load ptr, ptr %l0, !tbaa !29
  %t421 = getelementptr %"compiler/check:Checker", ptr %t419, i32 0, i32 0
  %t422 = load ptr, ptr %t421, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ePus_H51a5125d8f537c6ff8e01fc80ef561c7(ptr %v0, ptr %v0, ptr %t418, ptr %t422)
  br label %bb101
bb100:
  %t425 = load ptr, ptr %lp13
  %t426 = load ptr, ptr %l20, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ePus_H51a5125d8f537c6ff8e01fc80ef561c7(ptr %v0, ptr %v0, ptr %t425, ptr %t426)
  br label %bb102
bb101:
  br label %bb103
bb102:
  br label %bb103
bb103:
  call void @__olang_scope_close(ptr %s5)
  br label %bb104
bb104:
  %t429 = load i64, ptr %l18, !tbaa !24
  %t431 = add i64 %t429, 1
  store i64 %t431, ptr %l18, !tbaa !24
  br label %bb46
bb105:
  %t433 = load ptr, ptr %l0, !tbaa !29
  %t435 = getelementptr %"compiler/check:Checker", ptr %t433, i32 0, i32 1
  %t436 = load ptr, ptr %t435, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInferThroughBounds(ptr %v0, ptr %s0, ptr %t436, ptr %l12)
  br label %bb106
bb106:
  store i64 0, ptr %l24, !tbaa !24
  %t439 = load i64, ptr %l10, !tbaa !24
  store i64 %t439, ptr %l25, !tbaa !24
  store i64 1, ptr %l26, !tbaa !24
  %t441 = load i64, ptr %l25, !tbaa !24
  %t442 = load i64, ptr %l24, !tbaa !24
  %t445 = icmp sgt i64 %t441, %t442
  br i1 %t445, label %bb107, label %bb108
bb107:
  %t447 = load i64, ptr %l26, !tbaa !24
  %t449 = icmp sgt i64 %t447, 0
  br i1 %t449, label %bb109, label %bb110
bb108:
  store i64 0, ptr %l253, !tbaa !24
  br label %bb112
bb109:
  %t451 = load i64, ptr %l25, !tbaa !24
  %t452 = load i64, ptr %l24, !tbaa !24
  %t455 = sub i64 %t451, %t452
  %t456 = load i64, ptr %l26, !tbaa !24
  %t459 = add i64 %t455, %t456
  %t461 = sub i64 %t459, 1
  %t462 = load i64, ptr %l26, !tbaa !24
  %t465 = sdiv i64 %t461, %t462
  store i64 %t465, ptr %l256, !tbaa !24
  br label %bb111
bb110:
  store i64 0, ptr %l256, !tbaa !24
  br label %bb111
bb111:
  %t467 = load i64, ptr %l256, !tbaa !24
  store i64 %t467, ptr %l253, !tbaa !24
  br label %bb112
bb112:
  %t468 = load i64, ptr %l253, !tbaa !24
  store i64 %t468, ptr %l27, !tbaa !24
  store i64 0, ptr %l28, !tbaa !24
  br label %bb113
bb113:
  store %olang.scope zeroinitializer, ptr %s16
  %t469 = load i64, ptr %l28, !tbaa !24
  %t470 = load i64, ptr %l27, !tbaa !24
  %t473 = icmp slt i64 %t469, %t470
  %t475 = xor i1 %t473, true
  br i1 %t475, label %bb114, label %bb115
bb114:
  call void @__olang_scope_close(ptr %s16)
  br label %bb138
bb115:
  br label %bb116
bb116:
  %t477 = load i64, ptr %l24, !tbaa !24
  %t478 = load i64, ptr %l28, !tbaa !24
  %t479 = load i64, ptr %l26, !tbaa !24
  %t482 = mul i64 %t478, %t479
  %t485 = add i64 %t477, %t482
  store i64 %t485, ptr %l29, !tbaa !24
  %t487 = getelementptr %"compiler/generic:Binding", ptr %l12, i32 0, i32 2
  %t488 = load { i64, ptr }, ptr %t487, !tbaa !27
  store { i64, ptr } %t488, ptr %l274, !tbaa !27
  %t489 = load i64, ptr %l29, !tbaa !24
  %t491 = getelementptr { i64, ptr }, ptr %l274, i32 0, i32 1
  %t492 = load ptr, ptr %t491, !tbaa !27
  %t493 = getelementptr i32, ptr %t492, i64 %t489
  %t494 = load i32, ptr %t493, !tbaa !33
  store i32 %t494, ptr %l30, !tbaa !23
  %t496 = load i32, ptr %l30, !tbaa !23
  %t497 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t500 = icmp eq i32 %t496, %t497
  br i1 %t500, label %bb117, label %bb118
bb117:
  store %olang.scope zeroinitializer, ptr %s17
  %t502 = load ptr, ptr %l0, !tbaa !29
  store ptr %t502, ptr %l280, !tbaa !29
  %t503 = load ptr, ptr %l0, !tbaa !29
  %t505 = getelementptr %"compiler/check:Checker", ptr %t503, i32 0, i32 1
  %t506 = load ptr, ptr %t505, !tbaa !29
  %t508 = getelementptr %"compiler/generic:Program", ptr %t506, i32 0, i32 2
  %t509 = load i32, ptr %l3, !tbaa !23
  %t512 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t508, i32 %t509)
  store i32 %t512, ptr %l285
  br label %bb119
bb118:
  br label %bb124
bb119:
  %t513 = load ptr, ptr %l280, !tbaa !29
  %t514 = load i32, ptr %l285, !tbaa !23
  %t515 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t513, i32 %t514)
  store { i64, ptr } %t515, ptr %l286
  br label %bb120
bb120:
  %t516 = load { i64, ptr }, ptr %l286, !tbaa !27
  store { i64, ptr } %t516, ptr %l31, !tbaa !27
  %t517 = load ptr, ptr %l0, !tbaa !29
  store ptr %t517, ptr %l287, !tbaa !29
  %t518 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t518, ptr %l288
  %t519 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t520 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t523 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCtorTypeArgsNotInferable(ptr %v0, ptr %v0, ptr %s17, { i64, ptr } %t519, { i64, ptr } %t520)
  store %"compiler/msgs:Msg" %t523, ptr %l291
  br label %bb121
bb121:
  %t524 = load ptr, ptr %l287, !tbaa !29
  %t525 = load %"compiler/source:Span", ptr %l288
  %t526 = load %"compiler/msgs:Msg", ptr %l291
  %t527 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s17, ptr %t524, %"compiler/source:Span" %t525, %"compiler/msgs:Msg" %t526)
  store i64 %t527, ptr %l292
  br label %bb122
bb122:
  %t528 = load ptr, ptr %l0, !tbaa !29
  %t529 = load %"compiler/source:Span", ptr %l1
  %t532 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t528, %"compiler/source:Span" %t529)
  store ptr %t532, ptr %l295
  br label %bb123
bb123:
  call void @__olang_scope_close(ptr %s17)
  call void @__olang_scope_close(ptr %s16)
  call void @__olang_scope_close(ptr %s0)
  %t533 = load ptr, ptr %l295, !tbaa !29
  store ptr %t533, ptr %rv
  br label %ret
bb124:
  %t534 = load ptr, ptr %l0, !tbaa !29
  %t535 = load i32, ptr %l30, !tbaa !23
  %t538 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t534, i32 %t535)
  store i1 %t538, ptr %l298
  br label %bb125
bb125:
  %t539 = load i1, ptr %l298, !tbaa !21
  br i1 %t539, label %bb126, label %bb127
bb126:
  %t540 = getelementptr %"compiler/generic:Binding", ptr %l12, i32 0, i32 2
  %t541 = load { i64, ptr }, ptr %t540, !tbaa !27
  store { i64, ptr } %t541, ptr %l299, !tbaa !27
  %t542 = load i64, ptr %l29, !tbaa !24
  store i64 %t542, ptr %l300, !tbaa !24
  %t543 = load ptr, ptr %l0, !tbaa !29
  %t545 = getelementptr %"compiler/check:Checker", ptr %t543, i32 0, i32 1
  %t546 = load ptr, ptr %t545, !tbaa !29
  %t548 = getelementptr %"compiler/generic:Program", ptr %t546, i32 0, i32 2
  store ptr %t548, ptr %l303, !tbaa !29
  %t549 = load ptr, ptr %l0, !tbaa !29
  %t551 = getelementptr %"compiler/check:Checker", ptr %t549, i32 0, i32 1
  %t552 = load ptr, ptr %t551, !tbaa !29
  %t554 = getelementptr %"compiler/generic:Program", ptr %t552, i32 0, i32 2
  %t555 = load i32, ptr %l30, !tbaa !23
  %t558 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t554, i32 %t555)
  store i32 %t558, ptr %l308
  br label %bb128
bb127:
  %t559 = load ptr, ptr %l0, !tbaa !29
  %t561 = getelementptr %"compiler/check:Checker", ptr %t559, i32 0, i32 1
  %t562 = load ptr, ptr %t561, !tbaa !29
  %t564 = getelementptr %"compiler/generic:Program", ptr %t562, i32 0, i32 2
  store ptr %t564, ptr %l313, !tbaa !29
  %t565 = load ptr, ptr %l0, !tbaa !29
  %t566 = load i32, ptr %l30, !tbaa !23
  %t569 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t565, i32 %t566)
  store i32 %t569, ptr %l316
  br label %bb130
bb128:
  %t570 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t571 = load ptr, ptr %l303, !tbaa !29
  %t572 = load i32, ptr %l308, !tbaa !23
  %t574 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t571, i32 %t572, i64 %t570)
  store i32 %t574, ptr %l310
  br label %bb129
bb129:
  %t575 = load i32, ptr %l310, !tbaa !23
  %t576 = load i64, ptr %l300, !tbaa !24
  %t577 = getelementptr { i64, ptr }, ptr %l299, i32 0, i32 1
  %t578 = load ptr, ptr %t577, !tbaa !27
  %t579 = getelementptr i32, ptr %t578, i64 %t576
  store i32 %t575, ptr %t579, !tbaa !33
  br label %bb136
bb130:
  %t580 = load ptr, ptr %l313, !tbaa !29
  %t581 = load i32, ptr %l316, !tbaa !23
  %t582 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t580, i32 %t581)
  store i32 %t582, ptr %l317
  br label %bb131
bb131:
  %t583 = load i32, ptr %l317
  %t585 = trunc i64 19 to i32
  %t586 = icmp eq i32 %t583, %t585
  br i1 %t586, label %bb132, label %bb133
bb132:
  %t588 = getelementptr %"compiler/generic:Binding", ptr %l12, i32 0, i32 2
  %t589 = load { i64, ptr }, ptr %t588, !tbaa !27
  store { i64, ptr } %t589, ptr %l320, !tbaa !27
  %t590 = load i64, ptr %l29, !tbaa !24
  store i64 %t590, ptr %l321, !tbaa !24
  %t591 = load ptr, ptr %l0, !tbaa !29
  %t593 = getelementptr %"compiler/check:Checker", ptr %t591, i32 0, i32 1
  %t594 = load ptr, ptr %t593, !tbaa !29
  %t596 = getelementptr %"compiler/generic:Program", ptr %t594, i32 0, i32 2
  %t597 = load i32, ptr %l30, !tbaa !23
  %t598 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t602 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t596, i32 %t597, i64 %t598)
  store i32 %t602, ptr %l327
  br label %bb134
bb133:
  br label %bb135
bb134:
  %t603 = load i32, ptr %l327, !tbaa !23
  %t604 = load i64, ptr %l321, !tbaa !24
  %t605 = getelementptr { i64, ptr }, ptr %l320, i32 0, i32 1
  %t606 = load ptr, ptr %t605, !tbaa !27
  %t607 = getelementptr i32, ptr %t606, i64 %t604
  store i32 %t603, ptr %t607, !tbaa !33
  br label %bb135
bb135:
  br label %bb136
bb136:
  call void @__olang_scope_close(ptr %s16)
  br label %bb137
bb137:
  %t608 = load i64, ptr %l28, !tbaa !24
  %t610 = add i64 %t608, 1
  store i64 %t610, ptr %l28, !tbaa !24
  br label %bb113
bb138:
  %t612 = load ptr, ptr %l0, !tbaa !29
  %t614 = getelementptr %"compiler/check:Checker", ptr %t612, i32 0, i32 1
  %t615 = load ptr, ptr %t614, !tbaa !29
  store ptr %t615, ptr %l331, !tbaa !29
  %t616 = load i32, ptr %l3, !tbaa !23
  store i32 %t616, ptr %l332, !tbaa !23
  %t617 = load ptr, ptr %l0, !tbaa !29
  %t619 = getelementptr %"compiler/check:Checker", ptr %t617, i32 0, i32 1
  %t620 = load ptr, ptr %t619, !tbaa !29
  %t622 = getelementptr %"compiler/generic:Program", ptr %t620, i32 0, i32 2
  %t623 = getelementptr %"compiler/generic:Binding", ptr %l12, i32 0, i32 2
  %t624 = load { i64, ptr }, ptr %t623, !tbaa !27
  %t627 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t622, { i64, ptr } %t624)
  store i32 %t627, ptr %l337
  br label %bb139
bb139:
  %t628 = load ptr, ptr %l331, !tbaa !29
  %t629 = load i32, ptr %l332, !tbaa !23
  %t630 = load i32, ptr %l337, !tbaa !23
  %t631 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstance(ptr %v0, ptr %t628, i32 %t629, i32 %t630)
  store i32 %t631, ptr %l338
  br label %bb140
bb140:
  %t632 = load i32, ptr %l338, !tbaa !23
  store i32 %t632, ptr %l32, !tbaa !23
  %t633 = load ptr, ptr %l0, !tbaa !29
  %t634 = load i32, ptr %l32, !tbaa !23
  %t635 = load %"compiler/source:Span", ptr %l2
  %t639 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstancesMet(ptr %v0, ptr %t633, i32 %t634, %"compiler/source:Span" %t635)
  store i1 %t639, ptr %l342
  br label %bb141
bb141:
  %t640 = load i1, ptr %l342, !tbaa !21
  %t641 = xor i1 %t640, true
  br i1 %t641, label %bb142, label %bb143
bb142:
  store i1 true, ptr %l344, !tbaa !21
  br label %bb145
bb143:
  %t643 = load ptr, ptr %l0, !tbaa !29
  %t645 = getelementptr %"compiler/check:Checker", ptr %t643, i32 0, i32 1
  %t646 = load ptr, ptr %t645, !tbaa !29
  %t647 = load i32, ptr %l32, !tbaa !23
  %t650 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t646, i32 %t647)
  store i1 %t650, ptr %l348
  br label %bb144
bb144:
  %t651 = load i1, ptr %l348, !tbaa !21
  %t652 = xor i1 %t651, true
  store i1 %t652, ptr %l344, !tbaa !21
  br label %bb145
bb145:
  %t654 = load i1, ptr %l344, !tbaa !21
  br i1 %t654, label %bb146, label %bb147
bb146:
  %t655 = load ptr, ptr %l0, !tbaa !29
  %t656 = load %"compiler/source:Span", ptr %l1
  %t659 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t655, %"compiler/source:Span" %t656)
  store ptr %t659, ptr %l352
  br label %bb148
bb147:
  br label %bb149
bb148:
  call void @__olang_scope_close(ptr %s0)
  %t660 = load ptr, ptr %l352, !tbaa !29
  store ptr %t660, ptr %rv
  br label %ret
bb149:
  %t661 = load ptr, ptr %l0, !tbaa !29
  %t663 = getelementptr %"compiler/check:Checker", ptr %t661, i32 0, i32 1
  %t664 = load ptr, ptr %t663, !tbaa !29
  %t665 = load i32, ptr %l32, !tbaa !23
  %t668 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorSig(ptr %v0, ptr %t664, i32 %t665)
  store i32 %t668, ptr %l356
  br label %bb150
bb150:
  %t669 = load i32, ptr %l356, !tbaa !23
  store i32 %t669, ptr %l33, !tbaa !23
  %t670 = load i32, ptr %l33, !tbaa !23
  %t671 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t674 = icmp eq i32 %t670, %t671
  br i1 %t674, label %bb151, label %bb152
bb151:
  %t676 = load ptr, ptr %l0, !tbaa !29
  %t677 = load %"compiler/source:Span", ptr %l1
  %t680 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t676, %"compiler/source:Span" %t677)
  store ptr %t680, ptr %l362
  br label %bb153
bb152:
  br label %bb154
bb153:
  call void @__olang_scope_close(ptr %s0)
  %t681 = load ptr, ptr %l362, !tbaa !29
  store ptr %t681, ptr %rv
  br label %ret
bb154:
  %t682 = load ptr, ptr %l0, !tbaa !29
  %t683 = load i32, ptr %l32, !tbaa !23
  %t686 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorBody(ptr %v0, ptr %t682, i32 %t683)
  store i64 %t686, ptr %l365
  br label %bb155
bb155:
  %t687 = load i64, ptr %l365, !tbaa !24
  %t688 = load ptr, ptr %l0, !tbaa !29
  %t690 = getelementptr %"compiler/check:Checker", ptr %t688, i32 0, i32 21
  %t691 = load i32, ptr %t690, !tbaa !23
  store i32 %t691, ptr %l35, !tbaa !23
  %t693 = load ptr, ptr %l0, !tbaa !29
  %t694 = load i32, ptr %l32, !tbaa !23
  %t697 = getelementptr %"compiler/check:Checker", ptr %t693, i32 0, i32 21
  store i32 %t694, ptr %t697, !tbaa !23
  %t698 = load ptr, ptr %l0, !tbaa !29
  store ptr %t698, ptr %l370, !tbaa !29
  %t699 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t699, ptr %l371
  %t700 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t700, ptr %l372
  %t701 = load i32, ptr %l33, !tbaa !23
  store i32 %t701, ptr %l373, !tbaa !23
  %t704 = trunc i64 %t687 to i32
  store { i64, [1 x i64] } zeroinitializer, ptr %t706
  %t707 = getelementptr { i64, [1 x i64] }, ptr %t706, i32 0, i32 0
  store i64 0, ptr %t707
  %t709 = insertvalue { i32 } undef, i32 %t704, 0
  %t710 = getelementptr { i64, [1 x i64] }, ptr %t706, i32 0, i32 1
  store { i32 } %t709, ptr %t710
  %t711 = load { i64, [1 x i64] }, ptr %t706
  %t713 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store { i64, [1 x i64] } %t711, ptr %t713
  store ptr %t713, ptr %l378, !tbaa !29
  %t714 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t714, ptr %l379, !tbaa !27
  %t715 = load ptr, ptr %lp13
  %t717 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2eToA_H3b732fb6bb2c20fd2f0446a621d56c2c(ptr %v0, ptr %v0, ptr %t715)
  store { i64, ptr } %t717, ptr %l381
  br label %bb156
bb156:
  %t718 = load ptr, ptr %l370, !tbaa !29
  %t719 = load %"compiler/source:Span", ptr %l371
  %t720 = load %"compiler/source:Span", ptr %l372
  %t721 = load i32, ptr %l373, !tbaa !23
  %t722 = load ptr, ptr %l378, !tbaa !29
  %t723 = load { i64, ptr }, ptr %l379, !tbaa !27
  %t724 = load { i64, ptr }, ptr %l381, !tbaa !27
  %t725 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallBody(ptr %v0, ptr %v1, ptr %t718, %"compiler/source:Span" %t719, %"compiler/source:Span" %t720, i32 %t721, ptr %t722, i64 -1, ptr null, { i64, ptr } %t723, { i64, ptr } %t724)
  store ptr %t725, ptr %l382
  br label %bb157
bb157:
  %t726 = load ptr, ptr %l382, !tbaa !29
  %t727 = load ptr, ptr %l0, !tbaa !29
  %t728 = load i32, ptr %l35, !tbaa !23
  %t731 = getelementptr %"compiler/check:Checker", ptr %t727, i32 0, i32 21
  store i32 %t728, ptr %t731, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store ptr %t726, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleak(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l8 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t1)
  store ptr %t3, ptr %l8
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l8, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/check:Checker", ptr %t5, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = getelementptr %"compiler/generic:Program", ptr %t8, i32 0, i32 2
  %t14 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t10, i32 %a1)
  store { i64, ptr } %t14, ptr %l13
  br label %bb2
bb2:
  %t15 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t15, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t16 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t16, 0
  store i64 %t18, ptr %l5, !tbaa !24
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t20 = load i64, ptr %l4, !tbaa !24
  %t21 = load i64, ptr %l5, !tbaa !24
  %t24 = icmp slt i64 %t20, %t21
  %t26 = xor i1 %t24, true
  br i1 %t26, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s2)
  br label %bb9
bb5:
  br label %bb6
bb6:
  %t28 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t28, ptr %l20, !tbaa !27
  %t29 = load i64, ptr %l4, !tbaa !24
  %t31 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = getelementptr i32, ptr %t32, i64 %t29
  %t34 = load i32, ptr %t33, !tbaa !33
  %t36 = load ptr, ptr %l2, !tbaa !29
  %t38 = getelementptr %"compiler/check:frame", ptr %t36, i32 0, i32 25
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t38, i32 %t34)
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s2)
  br label %bb8
bb8:
  %t42 = load i64, ptr %l4, !tbaa !24
  %t44 = add i64 %t42, 1
  store i64 %t44, ptr %l4, !tbaa !24
  br label %bb3
bb9:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleft(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca %"compiler/typed:Item"
  %l21 = alloca i32
  %l24 = alloca i64
  %l27 = alloca i64
  %l29 = alloca i64
  %l36 = alloca i64
  %l40 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l44 = alloca i32
  %l53 = alloca { i64, ptr }
  %l67 = alloca { i64, ptr }
  %l79 = alloca i64
  %l96 = alloca i32
  %l103 = alloca i32
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t7 = load i32, ptr %l1, !tbaa !23
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t10, ptr %l21
  br label %bb1
bb1:
  %t11 = load i32, ptr %l21, !tbaa !23
  store i32 %t11, ptr %l3, !tbaa !23
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load i32, ptr %l3, !tbaa !23
  %t16 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewordCount(ptr %v0, ptr %t12, i32 %t13)
  store i64 %t16, ptr %l24
  br label %bb2
bb2:
  %t17 = load i64, ptr %l24, !tbaa !24
  store i64 %t17, ptr %l4, !tbaa !24
  %t18 = load i64, ptr %l4, !tbaa !24
  %t20 = icmp sge i64 %t18, 64
  br i1 %t20, label %bb3, label %bb4
bb3:
  %t22 = sub i64 0, 1
  store i64 %t22, ptr %l27, !tbaa !65
  br label %bb5
bb4:
  %t24 = load i64, ptr %l4, !tbaa !24
  store i64 %t24, ptr %l29, !tbaa !24
  %t25 = load i64, ptr %l29, !tbaa !24
  %t26 = load i64, ptr %l29, !tbaa !24
  %t27 = shl i64 1, %t26
  %t29 = sub i64 %t27, 1
  store i64 %t29, ptr %l27, !tbaa !65
  br label %bb5
bb5:
  %t31 = load i64, ptr %l27, !tbaa !65
  store i64 %t31, ptr %l5, !tbaa !65
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/check:Checker", ptr %t32, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t37 = getelementptr %"compiler/generic:Program", ptr %t35, i32 0, i32 2
  %t38 = load i32, ptr %l1, !tbaa !23
  %t41 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %t37, i32 %t38)
  store i64 %t41, ptr %l36
  br label %bb6
bb6:
  %t42 = load i64, ptr %l5, !tbaa !65
  %t43 = load i64, ptr %l36, !tbaa !65
  %t45 = and i64 %t43, %t42
  store i64 %t45, ptr %l6, !tbaa !65
  store ptr %a2, ptr %l7, !tbaa !29
  store i64 0, ptr %l8, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t49 = load ptr, ptr %l7, !tbaa !29
  %t50 = load i64, ptr %l8, !tbaa !24
  %t53 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aClause_26_3e_2eR_H9395c9c55f40ca4e18bbadf0b4ab31aa(ptr %v1, ptr %t49, i64 %t50)
  %t54 = extractvalue { i32, { i64, ptr } } %t53, 1
  %t55 = extractvalue { i32, { i64, ptr } } %t53, 0
  store i32 %t55, ptr %l44
  %t56 = icmp ne i32 %t55, 0
  br i1 %t56, label %bb9, label %ok.57
ok.57:
  store { i64, ptr } %t54, ptr %l43
  br label %bb8
bb8:
  %t58 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t58, ptr %l40, !tbaa !27
  br label %bb13
bb9:
  %t59 = load i32, ptr %l44, !tbaa !23
  %t60 = ashr i32 %t59, 16
  %t62 = icmp eq i32 %t60, 1
  br i1 %t62, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_c9e70fc2ae99f8ec_a4a86a2066a83508)
  unreachable
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %bb39
bb13:
  %t64 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t64, ptr %l9, !tbaa !27
  %t65 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t67 = extractvalue { i64, ptr } %t65, 0
  store i64 %t67, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb14
bb14:
  store %olang.scope zeroinitializer, ptr %s3
  %t69 = load i64, ptr %l11, !tbaa !24
  %t70 = load i64, ptr %l10, !tbaa !24
  %t73 = icmp slt i64 %t69, %t70
  %t75 = xor i1 %t73, true
  br i1 %t75, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s3)
  br label %bb37
bb16:
  br label %bb17
bb17:
  %t77 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t77, ptr %l53, !tbaa !27
  %t78 = load i64, ptr %l11, !tbaa !24
  %t80 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t81 = load ptr, ptr %t80, !tbaa !27
  %t82 = getelementptr ptr, ptr %t81, i64 %t78
  %t83 = load ptr, ptr %t82, !tbaa !39
  store ptr %t83, ptr %l12, !tbaa !29
  %t85 = load ptr, ptr %l12, !tbaa !29
  %t87 = getelementptr %"compiler/typed:Clause", ptr %t85, i32 0, i32 2
  %t88 = load i1, ptr %t87, !tbaa !21
  br i1 %t88, label %bb18, label %bb19
bb18:
  %t90 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  store i32 %t90, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  %t92 = load ptr, ptr %l12, !tbaa !29
  %t94 = getelementptr %"compiler/typed:Clause", ptr %t92, i32 0, i32 1
  %t95 = load { i64, ptr }, ptr %t94, !tbaa !27
  store { i64, ptr } %t95, ptr %l13, !tbaa !27
  store i64 0, ptr %l14, !tbaa !24
  %t97 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t99 = extractvalue { i64, ptr } %t97, 0
  store i64 %t99, ptr %l15, !tbaa !24
  br label %bb21
bb21:
  store %olang.scope zeroinitializer, ptr %s6
  %t101 = load i64, ptr %l14, !tbaa !24
  %t102 = load i64, ptr %l15, !tbaa !24
  %t105 = icmp slt i64 %t101, %t102
  %t107 = xor i1 %t105, true
  br i1 %t107, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s6)
  br label %bb35
bb23:
  br label %bb24
bb24:
  %t109 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t109, ptr %l67, !tbaa !27
  %t110 = load i64, ptr %l14, !tbaa !24
  %t112 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !27
  %t114 = getelementptr %"compiler/typed:Item", ptr %t113, i64 %t110
  %t115 = load %"compiler/typed:Item", ptr %t114
  store %"compiler/typed:Item" %t115, ptr %l16
  %t117 = getelementptr %"compiler/typed:Item", ptr %l16, i32 0, i32 0
  %t118 = load i32, ptr %t117, !tbaa !23
  %t119 = load i32, ptr %l3, !tbaa !23
  %t122 = icmp eq i32 %t118, %t119
  br i1 %t122, label %bb25, label %bb26
bb25:
  %t124 = getelementptr %"compiler/typed:Item", ptr %l16, i32 0, i32 1
  %t125 = load i64, ptr %t124, !tbaa !24
  %t127 = icmp slt i64 %t125, 0
  br i1 %t127, label %bb27, label %bb28
bb26:
  br label %bb33
bb27:
  %t129 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  store i32 %t129, ptr %rv
  br label %ret
bb28:
  br label %bb29
bb29:
  %t131 = getelementptr %"compiler/typed:Item", ptr %l16, i32 0, i32 1
  %t132 = load i64, ptr %t131, !tbaa !24
  %t134 = icmp slt i64 %t132, 64
  br i1 %t134, label %bb30, label %bb31
bb30:
  %t136 = load i64, ptr %l6, !tbaa !65
  %t137 = getelementptr %"compiler/typed:Item", ptr %l16, i32 0, i32 1
  %t138 = load i64, ptr %t137, !tbaa !24
  store i64 %t138, ptr %l79, !tbaa !24
  %t139 = load i64, ptr %l79, !tbaa !24
  %t140 = load i64, ptr %l79, !tbaa !24
  %t141 = shl i64 1, %t140
  %t143 = xor i64 %t141, -1
  %t146 = and i64 %t136, %t143
  store i64 %t146, ptr %l6, !tbaa !65
  br label %bb32
bb31:
  br label %bb32
bb32:
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s6)
  br label %bb34
bb34:
  %t148 = load i64, ptr %l14, !tbaa !24
  %t150 = add i64 %t148, 1
  store i64 %t150, ptr %l14, !tbaa !24
  br label %bb21
bb35:
  call void @__olang_scope_close(ptr %s3)
  br label %bb36
bb36:
  %t152 = load i64, ptr %l11, !tbaa !24
  %t154 = add i64 %t152, 1
  store i64 %t154, ptr %l11, !tbaa !24
  br label %bb14
bb37:
  %t156 = load i64, ptr %l8, !tbaa !24
  %t157 = load i64, ptr %l10, !tbaa !24
  %t160 = add i64 %t156, %t157
  store i64 %t160, ptr %l8, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb38
bb38:
  br label %bb7
bb39:
  %t162 = load i64, ptr %l6, !tbaa !65
  %t164 = icmp eq i64 %t162, 0
  br i1 %t164, label %bb40, label %bb41
bb40:
  %t166 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t166, ptr %rv
  br label %ret
bb41:
  br label %bb42
bb42:
  %t168 = load i64, ptr %l6, !tbaa !65
  %t169 = load i64, ptr %l5, !tbaa !65
  %t172 = icmp eq i64 %t168, %t169
  br i1 %t172, label %bb43, label %bb44
bb43:
  %t174 = load i32, ptr %l3, !tbaa !23
  store i32 %t174, ptr %l96, !tbaa !23
  br label %bb46
bb44:
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t178 = getelementptr %"compiler/check:Checker", ptr %t176, i32 0, i32 1
  %t179 = load ptr, ptr %t178, !tbaa !29
  %t181 = getelementptr %"compiler/generic:Program", ptr %t179, i32 0, i32 2
  %t182 = load i32, ptr %l3, !tbaa !23
  %t183 = load i64, ptr %l6, !tbaa !65
  %t187 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrWords(ptr %v0, ptr %t181, i32 %t182, i64 %t183)
  store i32 %t187, ptr %l103
  br label %bb45
bb45:
  %t188 = load i32, ptr %l103, !tbaa !23
  store i32 %t188, ptr %l96, !tbaa !23
  br label %bb46
bb46:
  %t189 = load i32, ptr %l96, !tbaa !23
  store i32 %t189, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLikeFits(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/check:litv"
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l14 = alloca %"compiler/check:litv"
  %l19 = alloca i1
  %l20 = alloca ptr
  %l21 = alloca i1
  %l29 = alloca i1
  %l30 = alloca ptr
  %l31 = alloca i1
  %l41 = alloca i1
  %l42 = alloca i1
  %l46 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l2, !tbaa !23
  %t2 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t5 = icmp eq i32 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t9 = load ptr, ptr %l1, !tbaa !29
  %t13 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %t8, ptr %t9)
  store %"compiler/check:litv" %t13, ptr %l14
  br label %bb4
bb4:
  %t14 = load %"compiler/check:litv", ptr %l14
  store %"compiler/check:litv" %t14, ptr %l3
  %t15 = getelementptr %"compiler/check:litv", ptr %l3, i32 0, i32 0
  %t16 = load i1, ptr %t15, !tbaa !21
  br i1 %t16, label %bb5, label %bb6
bb5:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load %"compiler/check:litv", ptr %l3
  %t20 = load i32, ptr %l2, !tbaa !23
  %t24 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitFits(ptr %v0, ptr %t18, %"compiler/check:litv" %t19, i32 %t20)
  store i1 %t24, ptr %l19
  br label %bb7
bb6:
  br label %bb8
bb7:
  %t25 = load i1, ptr %l19, !tbaa !21
  store i1 %t25, ptr %rv
  br label %ret
bb8:
  %t26 = load ptr, ptr %l1, !tbaa !29
  store ptr %t26, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t27 = load ptr, ptr %l20, !tbaa !29
  %t28 = icmp ne ptr %t27, null
  br i1 %t28, label %bb9, label %bb10
bb9:
  %t30 = load ptr, ptr %l20, !tbaa !29
  %t31 = load i64, ptr %t30
  %t33 = icmp eq i64 %t31, 2
  store i1 %t33, ptr %l21, !tbaa !21
  br label %bb10
bb10:
  %t34 = load i1, ptr %l21, !tbaa !21
  br i1 %t34, label %bb11, label %bb12
bb11:
  %t35 = load ptr, ptr %l1, !tbaa !29
  %t37 = getelementptr { i64, [5 x i64] }, ptr %t35, i32 0, i32 1
  %t38 = getelementptr { %"compiler/source:Span", ptr }, ptr %t37, i32 0, i32 1
  %t39 = load ptr, ptr %t38
  store ptr %t39, ptr %l4, !tbaa !29
  br label %bb13
bb12:
  br label %bb15
bb13:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load ptr, ptr %l4, !tbaa !29
  %t43 = load i32, ptr %l2, !tbaa !23
  %t47 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLikeFits(ptr %v0, ptr %v1, ptr %t41, ptr %t42, i32 %t43)
  store i1 %t47, ptr %l29
  br label %bb14
bb14:
  %t48 = load i1, ptr %l29, !tbaa !21
  store i1 %t48, ptr %rv
  br label %ret
bb15:
  %t49 = load ptr, ptr %l1, !tbaa !29
  store ptr %t49, ptr %l30, !tbaa !29
  store i1 false, ptr %l31, !tbaa !21
  %t50 = load ptr, ptr %l30, !tbaa !29
  %t51 = icmp ne ptr %t50, null
  br i1 %t51, label %bb16, label %bb17
bb16:
  %t53 = load ptr, ptr %l30, !tbaa !29
  %t54 = load i64, ptr %t53
  %t56 = icmp eq i64 %t54, 8
  store i1 %t56, ptr %l31, !tbaa !21
  br label %bb17
bb17:
  %t57 = load i1, ptr %l31, !tbaa !21
  br i1 %t57, label %bb18, label %bb19
bb18:
  %t58 = load ptr, ptr %l1, !tbaa !29
  %t60 = getelementptr { i64, [5 x i64] }, ptr %t58, i32 0, i32 1
  %t61 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t60, i32 0, i32 1
  %t62 = load ptr, ptr %t61
  store ptr %t62, ptr %l5, !tbaa !29
  %t64 = load ptr, ptr %l1, !tbaa !29
  %t66 = getelementptr { i64, [5 x i64] }, ptr %t64, i32 0, i32 1
  %t67 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t66, i32 0, i32 3
  %t68 = load ptr, ptr %t67
  store ptr %t68, ptr %l6, !tbaa !29
  br label %bb20
bb19:
  br label %bb26
bb20:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = load ptr, ptr %l5, !tbaa !29
  %t72 = load i32, ptr %l2, !tbaa !23
  %t76 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLikeFits(ptr %v0, ptr %v1, ptr %t70, ptr %t71, i32 %t72)
  store i1 %t76, ptr %l41
  br label %bb21
bb21:
  %t77 = load i1, ptr %l41, !tbaa !21
  br i1 %t77, label %bb22, label %bb23
bb22:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t79 = load ptr, ptr %l6, !tbaa !29
  %t80 = load i32, ptr %l2, !tbaa !23
  %t84 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLikeFits(ptr %v0, ptr %v1, ptr %t78, ptr %t79, i32 %t80)
  store i1 %t84, ptr %l46
  br label %bb24
bb23:
  store i1 false, ptr %l42, !tbaa !21
  br label %bb25
bb24:
  %t85 = load i1, ptr %l46, !tbaa !21
  store i1 %t85, ptr %l42, !tbaa !21
  br label %bb25
bb25:
  %t86 = load i1, ptr %l42, !tbaa !21
  store i1 %t86, ptr %rv
  br label %ret
bb26:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eliteralLocalNote(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca %"compiler/typed:Local"
  %l5 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l6 = alloca %"compiler/source:Span"
  %l10 = alloca ptr
  %l14 = alloca %"compiler/typed:Local"
  %l16 = alloca ptr
  %l20 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l21 = alloca %"compiler/source:Span"
  %l25 = alloca %"compiler/source:Span"
  %l26 = alloca i32
  %l27 = alloca %"compiler/source:Span"
  %l33 = alloca i1
  %l37 = alloca ptr
  %l38 = alloca i64
  %l41 = alloca { i64, [3 x i64] }
  %l44 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l51 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %l57 = alloca %"compiler/msgs:Msg"
  %l61 = alloca ptr
  %l62 = alloca i64
  %l65 = alloca { i64, [3 x i64] }
  %l68 = alloca { i64, ptr }
  %l71 = alloca { i64, ptr }
  %l72 = alloca { i64, ptr }
  %l75 = alloca { i64, ptr }
  %l76 = alloca { i64, ptr }
  %l79 = alloca { i64, ptr }
  %l82 = alloca { i64, ptr }
  %l84 = alloca %"compiler/msgs:Msg"
  %l88 = alloca ptr
  %l89 = alloca i64
  %l92 = alloca { i64, [3 x i64] }
  %l95 = alloca { i64, ptr }
  %l98 = alloca { i64, ptr }
  %l99 = alloca { i64, ptr }
  %l102 = alloca { i64, ptr }
  %l105 = alloca { i64, ptr }
  %l107 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t5)
  store ptr %t7, ptr %l10
  br label %bb4
bb4:
  %t8 = load ptr, ptr %l10, !tbaa !29
  %t10 = getelementptr %"compiler/typed:Body", ptr %t8, i32 0, i32 7
  %t11 = load i64, ptr %l2, !tbaa !24
  %t14 = call %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t10, i64 %t11)
  store %"compiler/typed:Local" %t14, ptr %l14
  br label %bb5
bb5:
  %t15 = load %"compiler/typed:Local", ptr %l14
  store %"compiler/typed:Local" %t15, ptr %l4
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t16)
  store ptr %t18, ptr %l16
  br label %bb6
bb6:
  %t19 = load ptr, ptr %l16, !tbaa !29
  %t21 = getelementptr %"compiler/check:frame", ptr %t19, i32 0, i32 0
  %t22 = load i64, ptr %t21, !tbaa !24
  %t23 = load i64, ptr %l2, !tbaa !24
  %t26 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %t22, i64 %t23)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t26, ptr %l20
  br label %bb7
bb7:
  %t27 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l20
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t27, ptr %l5
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/check:Checker", ptr %t28, i32 0, i32 27
  %t31 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l5
  %t34 = call { i32, %"compiler/source:Span" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H7d5384a5030fc995e793b3fe1f57e776(ptr %v0, ptr %t30, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t31)
  %t35 = extractvalue { i32, %"compiler/source:Span" } %t34, 1
  %t36 = extractvalue { i32, %"compiler/source:Span" } %t34, 0
  store i32 %t36, ptr %l26
  %t37 = icmp ne i32 %t36, 0
  br i1 %t37, label %bb9, label %ok.38
ok.38:
  store %"compiler/source:Span" %t35, ptr %l25
  br label %bb8
bb8:
  %t39 = load %"compiler/source:Span", ptr %l25
  store %"compiler/source:Span" %t39, ptr %l21
  br label %bb12
bb9:
  br label %bb10
bb10:
  %t40 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 -1, i32 -1)
  store %"compiler/source:Span" %t40, ptr %l27
  br label %bb11
bb11:
  %t41 = load %"compiler/source:Span", ptr %l27
  store %"compiler/source:Span" %t41, ptr %l21
  br label %bb12
bb12:
  %t42 = load %"compiler/source:Span", ptr %l21
  store %"compiler/source:Span" %t42, ptr %l6
  %t43 = getelementptr %"compiler/source:Span", ptr %l6, i32 0, i32 0
  %t44 = load i32, ptr %t43, !tbaa !23
  %t46 = icmp sge i32 %t44, 0
  br i1 %t46, label %bb13, label %bb14
bb13:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/check:Checker", ptr %t48, i32 0, i32 28
  %t51 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l5
  %t54 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %t50, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t51)
  store i1 %t54, ptr %l33
  br label %bb15
bb14:
  br label %bb34
bb15:
  %t55 = load i1, ptr %l33, !tbaa !21
  br i1 %t55, label %bb16, label %bb17
bb16:
  store %olang.scope zeroinitializer, ptr %s3
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/check:Checker", ptr %t56, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t61 = getelementptr %"compiler/generic:Program", ptr %t59, i32 0, i32 0
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = getelementptr %"compiler/load:Loader", ptr %t62, i32 0, i32 4
  %t65 = load ptr, ptr %t64, !tbaa !29
  store ptr %t65, ptr %l37, !tbaa !29
  %t66 = load i64, ptr %l1, !tbaa !24
  store i64 %t66, ptr %l38, !tbaa !24
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load %"compiler/source:Span", ptr %l6
  %t71 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %t67, %"compiler/source:Span" %t68)
  store { i64, [3 x i64] } %t71, ptr %l41
  br label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s4
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr %"compiler/check:Checker", ptr %t72, i32 0, i32 1
  %t75 = load ptr, ptr %t74, !tbaa !29
  %t77 = getelementptr %"compiler/generic:Program", ptr %t75, i32 0, i32 0
  %t78 = load ptr, ptr %t77, !tbaa !29
  %t80 = getelementptr %"compiler/load:Loader", ptr %t78, i32 0, i32 4
  %t81 = load ptr, ptr %t80, !tbaa !29
  store ptr %t81, ptr %l61, !tbaa !29
  %t82 = load i64, ptr %l1, !tbaa !24
  store i64 %t82, ptr %l62, !tbaa !24
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load %"compiler/source:Span", ptr %l6
  %t87 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %t83, %"compiler/source:Span" %t84)
  store { i64, [3 x i64] } %t87, ptr %l65
  br label %bb25
bb18:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 0
  %t90 = load i32, ptr %t89, !tbaa !23
  %t93 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t88, i32 %t90)
  store { i64, ptr } %t93, ptr %l44
  br label %bb19
bb19:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 2
  %t96 = load i32, ptr %t95, !tbaa !23
  %t99 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s3, ptr %t94, i32 %t96)
  store { i64, ptr } %t99, ptr %l47
  br label %bb20
bb20:
  %t100 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t100, 0
  %t102 = extractvalue { i64, ptr } %t100, 1
  %t103 = mul i64 %t101, 1
  %t104 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t103)
  call void @llvm.memcpy.p0.p0.i64(ptr %t104, ptr %t102, i64 %t103, i1 false)
  %t105 = insertvalue { i64, ptr } undef, i64 %t101, 0
  %t106 = insertvalue { i64, ptr } %t105, ptr %t104, 1
  store { i64, ptr } %t106, ptr %l48, !tbaa !27
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t108 = load i32, ptr %l3, !tbaa !23
  %t111 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s3, ptr %t107, i32 %t108)
  store { i64, ptr } %t111, ptr %l51
  br label %bb21
bb21:
  %t112 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t113 = extractvalue { i64, ptr } %t112, 0
  %t114 = extractvalue { i64, ptr } %t112, 1
  %t115 = mul i64 %t113, 1
  %t116 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t115)
  call void @llvm.memcpy.p0.p0.i64(ptr %t116, ptr %t114, i64 %t115, i1 false)
  %t117 = insertvalue { i64, ptr } undef, i64 %t113, 0
  %t118 = insertvalue { i64, ptr } %t117, ptr %t116, 1
  store { i64, ptr } %t118, ptr %l52, !tbaa !27
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t120 = load i32, ptr %l3, !tbaa !23
  %t123 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s3, ptr %t119, i32 %t120)
  store { i64, ptr } %t123, ptr %l55
  br label %bb22
bb22:
  %t124 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t125 = extractvalue { i64, ptr } %t124, 0
  %t126 = extractvalue { i64, ptr } %t124, 1
  %t127 = mul i64 %t125, 1
  %t128 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t127)
  call void @llvm.memcpy.p0.p0.i64(ptr %t128, ptr %t126, i64 %t127, i1 false)
  %t129 = insertvalue { i64, ptr } undef, i64 %t125, 0
  %t130 = insertvalue { i64, ptr } %t129, ptr %t128, 1
  %t131 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t132 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t133 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t135 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteLiteralRangeExpr(ptr %v0, ptr %s3, ptr %s3, ptr %s3, ptr %s3, { i64, ptr } %t131, { i64, ptr } %t132, { i64, ptr } %t133, { i64, ptr } %t130)
  store %"compiler/msgs:Msg" %t135, ptr %l57
  br label %bb23
bb23:
  %t136 = load ptr, ptr %l37, !tbaa !29
  %t137 = load i64, ptr %l38, !tbaa !24
  %t138 = load { i64, [3 x i64] }, ptr %l41
  %t139 = load %"compiler/msgs:Msg", ptr %l57
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %s3, ptr %t136, i64 %t137, { i64, [3 x i64] } %t138, %"compiler/msgs:Msg" %t139)
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s3)
  br label %bb33
bb25:
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t141 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 0
  %t142 = load i32, ptr %t141, !tbaa !23
  %t145 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t140, i32 %t142)
  store { i64, ptr } %t145, ptr %l68
  br label %bb26
bb26:
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t147 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 2
  %t148 = load i32, ptr %t147, !tbaa !23
  %t151 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s4, ptr %t146, i32 %t148)
  store { i64, ptr } %t151, ptr %l71
  br label %bb27
bb27:
  %t152 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t153 = extractvalue { i64, ptr } %t152, 0
  %t154 = extractvalue { i64, ptr } %t152, 1
  %t155 = mul i64 %t153, 1
  %t156 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t155)
  call void @llvm.memcpy.p0.p0.i64(ptr %t156, ptr %t154, i64 %t155, i1 false)
  %t157 = insertvalue { i64, ptr } undef, i64 %t153, 0
  %t158 = insertvalue { i64, ptr } %t157, ptr %t156, 1
  store { i64, ptr } %t158, ptr %l72, !tbaa !27
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t160 = load i32, ptr %l3, !tbaa !23
  %t163 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s4, ptr %t159, i32 %t160)
  store { i64, ptr } %t163, ptr %l75
  br label %bb28
bb28:
  %t164 = load { i64, ptr }, ptr %l75, !tbaa !27
  %t165 = extractvalue { i64, ptr } %t164, 0
  %t166 = extractvalue { i64, ptr } %t164, 1
  %t167 = mul i64 %t165, 1
  %t168 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t167)
  call void @llvm.memcpy.p0.p0.i64(ptr %t168, ptr %t166, i64 %t167, i1 false)
  %t169 = insertvalue { i64, ptr } undef, i64 %t165, 0
  %t170 = insertvalue { i64, ptr } %t169, ptr %t168, 1
  store { i64, ptr } %t170, ptr %l76, !tbaa !27
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t172 = load %"compiler/source:Span", ptr %l6
  %t175 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %t171, %"compiler/source:Span" %t172)
  store { i64, ptr } %t175, ptr %l79
  br label %bb29
bb29:
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t177 = load i32, ptr %l3, !tbaa !23
  %t180 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s4, ptr %t176, i32 %t177)
  store { i64, ptr } %t180, ptr %l82
  br label %bb30
bb30:
  %t181 = load { i64, ptr }, ptr %l82, !tbaa !27
  %t182 = extractvalue { i64, ptr } %t181, 0
  %t183 = extractvalue { i64, ptr } %t181, 1
  %t184 = mul i64 %t182, 1
  %t185 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t184)
  call void @llvm.memcpy.p0.p0.i64(ptr %t185, ptr %t183, i64 %t184, i1 false)
  %t186 = insertvalue { i64, ptr } undef, i64 %t182, 0
  %t187 = insertvalue { i64, ptr } %t186, ptr %t185, 1
  %t188 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t189 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t190 = load { i64, ptr }, ptr %l76, !tbaa !27
  %t191 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t193 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteLiteralRange(ptr %v0, ptr %s4, ptr %s4, ptr %v0, ptr %s4, ptr %s4, { i64, ptr } %t188, { i64, ptr } %t189, { i64, ptr } %t190, { i64, ptr } %t191, { i64, ptr } %t187)
  store %"compiler/msgs:Msg" %t193, ptr %l84
  br label %bb31
bb31:
  %t194 = load ptr, ptr %l61, !tbaa !29
  %t195 = load i64, ptr %l62, !tbaa !24
  %t196 = load { i64, [3 x i64] }, ptr %l65
  %t197 = load %"compiler/msgs:Msg", ptr %l84
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %s4, ptr %t194, i64 %t195, { i64, [3 x i64] } %t196, %"compiler/msgs:Msg" %t197)
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s4)
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb34:
  %t198 = load ptr, ptr %l0, !tbaa !29
  %t200 = getelementptr %"compiler/check:Checker", ptr %t198, i32 0, i32 1
  %t201 = load ptr, ptr %t200, !tbaa !29
  %t203 = getelementptr %"compiler/generic:Program", ptr %t201, i32 0, i32 0
  %t204 = load ptr, ptr %t203, !tbaa !29
  %t206 = getelementptr %"compiler/load:Loader", ptr %t204, i32 0, i32 4
  %t207 = load ptr, ptr %t206, !tbaa !29
  store ptr %t207, ptr %l88, !tbaa !29
  %t208 = load i64, ptr %l1, !tbaa !24
  store i64 %t208, ptr %l89, !tbaa !24
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t210 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 1
  %t211 = load %"compiler/source:Span", ptr %t210
  %t214 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %t209, %"compiler/source:Span" %t211)
  store { i64, [3 x i64] } %t214, ptr %l92
  br label %bb35
bb35:
  %t215 = load ptr, ptr %l0, !tbaa !29
  %t216 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 0
  %t217 = load i32, ptr %t216, !tbaa !23
  %t220 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t215, i32 %t217)
  store { i64, ptr } %t220, ptr %l95
  br label %bb36
bb36:
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t222 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 2
  %t223 = load i32, ptr %t222, !tbaa !23
  %t226 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t221, i32 %t223)
  store { i64, ptr } %t226, ptr %l98
  br label %bb37
bb37:
  %t227 = load { i64, ptr }, ptr %l98, !tbaa !27
  %t228 = extractvalue { i64, ptr } %t227, 0
  %t229 = extractvalue { i64, ptr } %t227, 1
  %t230 = mul i64 %t228, 1
  %t231 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t230)
  call void @llvm.memcpy.p0.p0.i64(ptr %t231, ptr %t229, i64 %t230, i1 false)
  %t232 = insertvalue { i64, ptr } undef, i64 %t228, 0
  %t233 = insertvalue { i64, ptr } %t232, ptr %t231, 1
  store { i64, ptr } %t233, ptr %l99, !tbaa !27
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t235 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 0
  %t236 = load i32, ptr %t235, !tbaa !23
  %t239 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t234, i32 %t236)
  store { i64, ptr } %t239, ptr %l102
  br label %bb38
bb38:
  %t240 = load ptr, ptr %l0, !tbaa !29
  %t241 = load i32, ptr %l3, !tbaa !23
  %t244 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t240, i32 %t241)
  store { i64, ptr } %t244, ptr %l105
  br label %bb39
bb39:
  %t245 = load { i64, ptr }, ptr %l105, !tbaa !27
  %t246 = extractvalue { i64, ptr } %t245, 0
  %t247 = extractvalue { i64, ptr } %t245, 1
  %t248 = mul i64 %t246, 1
  %t249 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t248)
  call void @llvm.memcpy.p0.p0.i64(ptr %t249, ptr %t247, i64 %t248, i1 false)
  %t250 = insertvalue { i64, ptr } undef, i64 %t246, 0
  %t251 = insertvalue { i64, ptr } %t250, ptr %t249, 1
  %t252 = load { i64, ptr }, ptr %l95, !tbaa !27
  %t253 = load { i64, ptr }, ptr %l99, !tbaa !27
  %t254 = load { i64, ptr }, ptr %l102, !tbaa !27
  %t256 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteLiteralLocal(ptr %v0, ptr %s0, ptr %v0, ptr %s0, ptr %s0, { i64, ptr } %t252, { i64, ptr } %t253, { i64, ptr } %t254, { i64, ptr } %t251)
  store %"compiler/msgs:Msg" %t256, ptr %l107
  br label %bb40
bb40:
  %t257 = load ptr, ptr %l88, !tbaa !29
  %t258 = load i64, ptr %l89, !tbaa !24
  %t259 = load { i64, [3 x i64] }, ptr %l92
  %t260 = load %"compiler/msgs:Msg", ptr %l107
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %s0, ptr %t257, i64 %t258, { i64, [3 x i64] } %t259, %"compiler/msgs:Msg" %t260)
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eloopCall(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, ptr %a3, { i64, ptr } %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l13 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca ptr
  %l21 = alloca i64
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca i64
  %l27 = alloca ptr
  %l30 = alloca i32
  %l33 = alloca i64
  %l34 = alloca ptr
  %l38 = alloca ptr
  %l39 = alloca %"compiler/source:Span"
  %l40 = alloca %"compiler/source:Span"
  %l41 = alloca i64
  %l43 = alloca ptr
  %l46 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l51 = alloca ptr
  %l52 = alloca ptr
  %l60 = alloca { i64, ptr }
  %l67 = alloca { i64, ptr }
  %l74 = alloca i32
  %l77 = alloca ptr
  %l82 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l86 = alloca i64
  %l90 = alloca i64
  %l93 = alloca i64
  %l113 = alloca ptr
  %l117 = alloca i32
  %l118 = alloca i32
  %l121 = alloca ptr
  %l125 = alloca i32
  %l132 = alloca { i64, ptr }
  %l135 = alloca { i64, ptr }
  %l136 = alloca i32
  %l145 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t1)
  store ptr %t3, ptr %l27
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l27, !tbaa !29
  store ptr %t4, ptr %l5, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/check:Checker", ptr %t5, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePreludeType(ptr %v0, ptr %s0, ptr %s0, ptr %t8, { i64, ptr } { i64 20, ptr @.d6 }, { i64, ptr } { i64 9, ptr @.d7 })
  store i32 %t10, ptr %l30
  br label %bb2
bb2:
  %t11 = load i32, ptr %l30, !tbaa !23
  store i32 %t11, ptr %l6, !tbaa !23
  %t12 = load ptr, ptr %l5, !tbaa !29
  %t14 = getelementptr %"compiler/check:frame", ptr %t12, i32 0, i32 25
  %t16 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t14)
  store i64 %t16, ptr %l33
  br label %bb3
bb3:
  %t17 = load i64, ptr %l33, !tbaa !24
  store i64 %t17, ptr %l7, !tbaa !24
  %t18 = load ptr, ptr %l5, !tbaa !29
  store ptr %t18, ptr %l34, !tbaa !29
  %t19 = load ptr, ptr %l34, !tbaa !29
  %t20 = getelementptr %"compiler/check:frame", ptr %t19, i32 0, i32 15
  %t21 = load i64, ptr %t20, !tbaa !24
  %t23 = add i64 %t21, 1
  %t25 = load ptr, ptr %l34, !tbaa !29
  %t26 = getelementptr %"compiler/check:frame", ptr %t25, i32 0, i32 15
  store i64 %t23, ptr %t26, !tbaa !24
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/check:Checker", ptr %t27, i32 0, i32 34
  store i32 0, ptr %t29, !tbaa !23
  %t30 = load ptr, ptr %l0, !tbaa !29
  store ptr %t30, ptr %l38, !tbaa !29
  %t31 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t31, ptr %l39
  %t32 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t32, ptr %l40
  store i64 %a2, ptr %l41, !tbaa !24
  store ptr %a3, ptr %l43, !tbaa !29
  %t36 = icmp sge i64 0, 0
  br i1 %t36, label %bb4, label %bb5
bb4:
  %t38 = icmp sle i64 0, 1152921504606846975
  br i1 %t38, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_652199a1d15cfac6_f2a0b86627c88902)
  unreachable
bb6:
  %t40 = mul i64 0, 8
  %t41 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t40)
  %t42 = insertvalue { i64, ptr } undef, i64 0, 0
  %t43 = insertvalue { i64, ptr } %t42, ptr %t41, 1
  store { i64, ptr } %t43, ptr %l46, !tbaa !27
  store { i64, ptr } %a4, ptr %l47, !tbaa !27
  %t45 = icmp sge i64 0, 0
  br i1 %t45, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_652199a1d15cfac6_f2a0b86627c88902)
  unreachable
bb8:
  %t47 = icmp sle i64 0, 2305843009213693951
  br i1 %t47, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_7509e56452997e5b_fb360af196d85db7)
  unreachable
bb10:
  %t49 = mul i64 0, 4
  %t50 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t49)
  %t51 = insertvalue { i64, ptr } undef, i64 0, 0
  %t52 = insertvalue { i64, ptr } %t51, ptr %t50, 1
  %t53 = load ptr, ptr %l38, !tbaa !29
  %t54 = load %"compiler/source:Span", ptr %l39
  %t55 = load %"compiler/source:Span", ptr %l40
  %t56 = load i64, ptr %l41, !tbaa !24
  %t57 = load ptr, ptr %l43, !tbaa !29
  %t58 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t59 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t61 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v0, ptr %s0, ptr %t53, %"compiler/source:Span" %t54, %"compiler/source:Span" %t55, i64 %t56, ptr %t57, { i64, ptr } %t58, { i64, ptr } %t59, { i64, ptr } %t52)
  store ptr %t61, ptr %l51
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_7509e56452997e5b_fb360af196d85db7)
  unreachable
bb12:
  %t62 = load ptr, ptr %l51, !tbaa !29
  store ptr %t62, ptr %l8, !tbaa !29
  %t63 = load ptr, ptr %l5, !tbaa !29
  store ptr %t63, ptr %l52, !tbaa !29
  %t64 = load ptr, ptr %l52, !tbaa !29
  %t65 = getelementptr %"compiler/check:frame", ptr %t64, i32 0, i32 15
  %t66 = load i64, ptr %t65, !tbaa !24
  %t68 = sub i64 %t66, 1
  %t70 = load ptr, ptr %l52, !tbaa !29
  %t71 = getelementptr %"compiler/check:frame", ptr %t70, i32 0, i32 15
  store i64 %t68, ptr %t71, !tbaa !24
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr %"compiler/check:Checker", ptr %t72, i32 0, i32 1
  %t75 = load ptr, ptr %t74, !tbaa !29
  %t77 = getelementptr %"compiler/generic:Program", ptr %t75, i32 0, i32 2
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/check:Checker", ptr %t78, i32 0, i32 34
  %t81 = load i32, ptr %t80, !tbaa !23
  %t84 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t77, i32 %t81)
  store { i64, ptr } %t84, ptr %l60
  br label %bb13
bb13:
  %t85 = load { i64, ptr }, ptr %l60, !tbaa !27
  store { i64, ptr } %t85, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t86 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t88 = extractvalue { i64, ptr } %t86, 0
  store i64 %t88, ptr %l11, !tbaa !24
  br label %bb14
bb14:
  store %olang.scope zeroinitializer, ptr %s2
  %t90 = load i64, ptr %l10, !tbaa !24
  %t91 = load i64, ptr %l11, !tbaa !24
  %t94 = icmp slt i64 %t90, %t91
  %t96 = xor i1 %t94, true
  br i1 %t96, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s2)
  br label %bb23
bb16:
  br label %bb17
bb17:
  %t98 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t98, ptr %l67, !tbaa !27
  %t99 = load i64, ptr %l10, !tbaa !24
  %t101 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !27
  %t103 = getelementptr i32, ptr %t102, i64 %t99
  %t104 = load i32, ptr %t103, !tbaa !33
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = getelementptr %"compiler/check:Checker", ptr %t106, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !29
  %t111 = getelementptr %"compiler/generic:Program", ptr %t109, i32 0, i32 2
  %t115 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t111, i32 %t104)
  store i32 %t115, ptr %l74
  br label %bb18
bb18:
  %t116 = load i32, ptr %l6, !tbaa !23
  %t117 = load i32, ptr %l74, !tbaa !23
  %t119 = icmp ne i32 %t117, %t116
  br i1 %t119, label %bb19, label %bb20
bb19:
  %t121 = load ptr, ptr %l5, !tbaa !29
  store ptr %t121, ptr %l77, !tbaa !29
  %t122 = load ptr, ptr %l77, !tbaa !29
  %t123 = getelementptr %"compiler/check:frame", ptr %t122, i32 0, i32 19
  %t124 = load i64, ptr %t123, !tbaa !24
  %t126 = add i64 %t124, 1
  %t128 = load ptr, ptr %l77, !tbaa !29
  %t129 = getelementptr %"compiler/check:frame", ptr %t128, i32 0, i32 19
  store i64 %t126, ptr %t129, !tbaa !24
  br label %bb21
bb20:
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s2)
  br label %bb22
bb22:
  %t130 = load i64, ptr %l10, !tbaa !24
  %t132 = add i64 %t130, 1
  store i64 %t132, ptr %l10, !tbaa !24
  br label %bb14
bb23:
  %t134 = load ptr, ptr @__olang_prog_scope
  %t135 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e(ptr %t134)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t135, ptr %l82
  br label %bb24
bb24:
  %t136 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l82
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t136, ptr %l13
  %t137 = load i64, ptr %l7, !tbaa !24
  store i64 %t137, ptr %l14, !tbaa !24
  %t139 = load ptr, ptr %l5, !tbaa !29
  %t141 = getelementptr %"compiler/check:frame", ptr %t139, i32 0, i32 25
  %t143 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t141)
  store i64 %t143, ptr %l86
  br label %bb25
bb25:
  %t144 = load i64, ptr %l86, !tbaa !24
  store i64 %t144, ptr %l15, !tbaa !24
  store i64 1, ptr %l16, !tbaa !24
  %t145 = load i64, ptr %l15, !tbaa !24
  %t146 = load i64, ptr %l14, !tbaa !24
  %t149 = icmp sgt i64 %t145, %t146
  br i1 %t149, label %bb26, label %bb27
bb26:
  %t151 = load i64, ptr %l16, !tbaa !24
  %t153 = icmp sgt i64 %t151, 0
  br i1 %t153, label %bb28, label %bb29
bb27:
  store i64 0, ptr %l90, !tbaa !24
  br label %bb31
bb28:
  %t155 = load i64, ptr %l15, !tbaa !24
  %t156 = load i64, ptr %l14, !tbaa !24
  %t159 = sub i64 %t155, %t156
  %t160 = load i64, ptr %l16, !tbaa !24
  %t163 = add i64 %t159, %t160
  %t165 = sub i64 %t163, 1
  %t166 = load i64, ptr %l16, !tbaa !24
  %t169 = sdiv i64 %t165, %t166
  store i64 %t169, ptr %l93, !tbaa !24
  br label %bb30
bb29:
  store i64 0, ptr %l93, !tbaa !24
  br label %bb30
bb30:
  %t171 = load i64, ptr %l93, !tbaa !24
  store i64 %t171, ptr %l90, !tbaa !24
  br label %bb31
bb31:
  %t172 = load i64, ptr %l90, !tbaa !24
  store i64 %t172, ptr %l17, !tbaa !24
  store i64 0, ptr %l18, !tbaa !24
  br label %bb32
bb32:
  store %olang.scope zeroinitializer, ptr %s6
  %t173 = load i64, ptr %l18, !tbaa !24
  %t174 = load i64, ptr %l17, !tbaa !24
  %t177 = icmp slt i64 %t173, %t174
  %t179 = xor i1 %t177, true
  br i1 %t179, label %bb33, label %bb34
bb33:
  call void @__olang_scope_close(ptr %s6)
  br label %bb44
bb34:
  br label %bb35
bb35:
  %t181 = load i64, ptr %l14, !tbaa !24
  %t182 = load i64, ptr %l18, !tbaa !24
  %t183 = load i64, ptr %l16, !tbaa !24
  %t186 = mul i64 %t182, %t183
  %t189 = add i64 %t181, %t186
  store i64 %t189, ptr %l19, !tbaa !24
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t193 = getelementptr %"compiler/check:Checker", ptr %t191, i32 0, i32 1
  %t194 = load ptr, ptr %t193, !tbaa !29
  %t196 = getelementptr %"compiler/generic:Program", ptr %t194, i32 0, i32 2
  store ptr %t196, ptr %l113, !tbaa !29
  %t197 = load ptr, ptr %l5, !tbaa !29
  %t199 = getelementptr %"compiler/check:frame", ptr %t197, i32 0, i32 25
  %t200 = load i64, ptr %l19, !tbaa !24
  %t203 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t199, i64 %t200)
  store i32 %t203, ptr %l117
  br label %bb36
bb36:
  %t204 = load ptr, ptr %l113, !tbaa !29
  %t205 = load i32, ptr %l117, !tbaa !23
  %t206 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t204, i32 %t205)
  store i32 %t206, ptr %l118
  br label %bb37
bb37:
  %t207 = load i32, ptr %l6, !tbaa !23
  %t208 = load i32, ptr %l118, !tbaa !23
  %t210 = icmp ne i32 %t208, %t207
  br i1 %t210, label %bb38, label %bb39
bb38:
  store ptr %l13, ptr %l121, !tbaa !29
  %t212 = load ptr, ptr %l5, !tbaa !29
  %t214 = getelementptr %"compiler/check:frame", ptr %t212, i32 0, i32 25
  %t215 = load i64, ptr %l19, !tbaa !24
  %t218 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t214, i64 %t215)
  store i32 %t218, ptr %l125
  br label %bb40
bb39:
  br label %bb42
bb40:
  %t219 = load ptr, ptr %l121, !tbaa !29
  %t220 = load i32, ptr %l125, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t219, i32 %t220)
  br label %bb41
bb41:
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s6)
  br label %bb43
bb43:
  %t221 = load i64, ptr %l18, !tbaa !24
  %t223 = add i64 %t221, 1
  store i64 %t223, ptr %l18, !tbaa !24
  br label %bb32
bb44:
  %t225 = load ptr, ptr %l5, !tbaa !29
  %t227 = getelementptr %"compiler/check:frame", ptr %t225, i32 0, i32 25
  %t228 = load i64, ptr %l7, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eTrun_H62a150000c9aaeb3d030aed80f9d3e2e(ptr %v0, ptr %t227, i64 %t228)
  br label %bb45
bb45:
  store ptr %l13, ptr %l20, !tbaa !29
  store i64 0, ptr %l21, !tbaa !24
  br label %bb46
bb46:
  store %olang.scope zeroinitializer, ptr %s10
  %t232 = load ptr, ptr %l20, !tbaa !29
  %t233 = load i64, ptr %l21, !tbaa !24
  %t236 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eRunF_H9c1707946c43ec840ffe1821bea89b1f(ptr %s0, ptr %t232, i64 %t233)
  %t237 = extractvalue { i32, { i64, ptr } } %t236, 1
  %t238 = extractvalue { i32, { i64, ptr } } %t236, 0
  store i32 %t238, ptr %l136
  %t239 = icmp ne i32 %t238, 0
  br i1 %t239, label %bb48, label %ok.240
ok.240:
  store { i64, ptr } %t237, ptr %l135
  br label %bb47
bb47:
  %t241 = load { i64, ptr }, ptr %l135, !tbaa !27
  store { i64, ptr } %t241, ptr %l132, !tbaa !27
  br label %bb52
bb48:
  %t242 = load i32, ptr %l136, !tbaa !23
  %t243 = ashr i32 %t242, 16
  %t245 = icmp eq i32 %t243, 1
  br i1 %t245, label %bb49, label %bb50
bb49:
  br label %bb51
bb50:
  call void @__olang_check_failed(ptr @olang_loc_d1119d7289e18fc7_4b5c36986650edfb)
  unreachable
bb51:
  call void @__olang_scope_close(ptr %s10)
  br label %bb61
bb52:
  %t247 = load { i64, ptr }, ptr %l132, !tbaa !27
  store { i64, ptr } %t247, ptr %l22, !tbaa !27
  %t248 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t250 = extractvalue { i64, ptr } %t248, 0
  store i64 %t250, ptr %l23, !tbaa !24
  store i64 0, ptr %l24, !tbaa !24
  br label %bb53
bb53:
  store %olang.scope zeroinitializer, ptr %s11
  %t252 = load i64, ptr %l24, !tbaa !24
  %t253 = load i64, ptr %l23, !tbaa !24
  %t256 = icmp slt i64 %t252, %t253
  %t258 = xor i1 %t256, true
  br i1 %t258, label %bb54, label %bb55
bb54:
  call void @__olang_scope_close(ptr %s11)
  br label %bb59
bb55:
  br label %bb56
bb56:
  %t260 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t260, ptr %l145, !tbaa !27
  %t261 = load i64, ptr %l24, !tbaa !24
  %t263 = getelementptr { i64, ptr }, ptr %l145, i32 0, i32 1
  %t264 = load ptr, ptr %t263, !tbaa !27
  %t265 = getelementptr i32, ptr %t264, i64 %t261
  %t266 = load i32, ptr %t265, !tbaa !33
  %t268 = load ptr, ptr %l5, !tbaa !29
  %t270 = getelementptr %"compiler/check:frame", ptr %t268, i32 0, i32 25
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t270, i32 %t266)
  br label %bb57
bb57:
  call void @__olang_scope_close(ptr %s11)
  br label %bb58
bb58:
  %t274 = load i64, ptr %l24, !tbaa !24
  %t276 = add i64 %t274, 1
  store i64 %t276, ptr %l24, !tbaa !24
  br label %bb53
bb59:
  %t278 = load i64, ptr %l21, !tbaa !24
  %t279 = load i64, ptr %l23, !tbaa !24
  %t282 = add i64 %t278, %t279
  store i64 %t282, ptr %l21, !tbaa !24
  call void @__olang_scope_close(ptr %s10)
  br label %bb60
bb60:
  br label %bb46
bb61:
  %t284 = load ptr, ptr %l8, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t284, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emutBefore(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca i1
  %l6 = alloca i1
  %l7 = alloca ptr
  %l8 = alloca i1
  %l21 = alloca i1
  %l23 = alloca %"compiler/source:Span"
  %l26 = alloca i1
  %l27 = alloca %"compiler/source:Span"
  %l31 = alloca i1
  %l34 = alloca i1
  %l35 = alloca i1
  %l40 = alloca i32
  %l43 = alloca %"compiler/source:Span"
  %l47 = alloca i1
  %l49 = alloca %"compiler/source:Span"
  %l54 = alloca i1
  %l57 = alloca i1
  %l58 = alloca %"compiler/source:Span"
  %l62 = alloca %"compiler/source:Span"
  %l63 = alloca %"compiler/source:Span"
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l7, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 4
  store i1 %t8, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr, i1, i1 }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l3
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", ptr, i1, i1 }, ptr %t18, i32 0, i32 1
  %t20 = load ptr, ptr %t19
  store ptr %t20, ptr %l4, !tbaa !29
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr { i64, [5 x i64] }, ptr %t22, i32 0, i32 1
  %t25 = getelementptr { %"compiler/source:Span", ptr, i1, i1 }, ptr %t24, i32 0, i32 2
  %t26 = load i1, ptr %t25
  store i1 %t26, ptr %l5, !tbaa !21
  %t28 = load ptr, ptr %l1, !tbaa !29
  %t30 = getelementptr { i64, [5 x i64] }, ptr %t28, i32 0, i32 1
  %t31 = getelementptr { %"compiler/source:Span", ptr, i1, i1 }, ptr %t30, i32 0, i32 3
  %t32 = load i1, ptr %t31
  store i1 %t32, ptr %l6, !tbaa !21
  br label %bb5
bb4:
  br label %bb43
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t34 = load i1, ptr %l5, !tbaa !21
  %t36 = xor i1 %t34, true
  br i1 %t36, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb8
bb7:
  %t38 = load i1, ptr %l6, !tbaa !21
  store i1 %t38, ptr %l21, !tbaa !21
  br label %bb8
bb8:
  %t40 = load i1, ptr %l21, !tbaa !21
  br i1 %t40, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t41 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s2, i32 -1, i32 -1)
  store %"compiler/source:Span" %t41, ptr %l23
  br label %bb11
bb10:
  br label %bb12
bb11:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  %t42 = load %"compiler/source:Span", ptr %l23
  store %"compiler/source:Span" %t42, ptr %rv
  br label %ret
bb12:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = load ptr, ptr %l4, !tbaa !29
  %t47 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enamesTypeVar(ptr %v0, ptr %v1, ptr %t43, ptr %t44)
  store i1 %t47, ptr %l26
  br label %bb13
bb13:
  %t48 = load i1, ptr %l26, !tbaa !21
  br i1 %t48, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s3
  %t49 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s3, i32 -1, i32 -1)
  store %"compiler/source:Span" %t49, ptr %l27
  br label %bb16
bb15:
  br label %bb17
bb16:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s1)
  %t50 = load %"compiler/source:Span", ptr %l27
  store %"compiler/source:Span" %t50, ptr %rv
  br label %ret
bb17:
  %t51 = load i32, ptr %l2, !tbaa !23
  %t52 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t55 = icmp ne i32 %t51, %t52
  br i1 %t55, label %bb18, label %bb19
bb18:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t58 = load i32, ptr %l2, !tbaa !23
  %t61 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t57, i32 %t58)
  store i1 %t61, ptr %l34
  br label %bb20
bb19:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb25
bb20:
  %t62 = load i1, ptr %l34, !tbaa !21
  br i1 %t62, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l35, !tbaa !21
  br label %bb24
bb22:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/check:Checker", ptr %t63, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t68 = getelementptr %"compiler/generic:Program", ptr %t66, i32 0, i32 2
  %t69 = load i32, ptr %l2, !tbaa !23
  %t72 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t68, i32 %t69)
  store i32 %t72, ptr %l40
  br label %bb23
bb23:
  %t73 = load i32, ptr %l40
  %t75 = trunc i64 25 to i32
  %t76 = icmp eq i32 %t73, %t75
  store i1 %t76, ptr %l35, !tbaa !21
  br label %bb24
bb24:
  %t78 = load i1, ptr %l35, !tbaa !21
  store i1 %t78, ptr %l31, !tbaa !21
  br label %bb25
bb25:
  %t79 = load i1, ptr %l31, !tbaa !21
  br i1 %t79, label %bb26, label %bb27
bb26:
  store %olang.scope zeroinitializer, ptr %s4
  %t80 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s4, i32 -1, i32 -1)
  store %"compiler/source:Span" %t80, ptr %l43
  br label %bb28
bb27:
  br label %bb29
bb28:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s1)
  %t81 = load %"compiler/source:Span", ptr %l43
  store %"compiler/source:Span" %t81, ptr %rv
  br label %ret
bb29:
  %t82 = load i32, ptr %l2, !tbaa !23
  %t83 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t86 = icmp eq i32 %t82, %t83
  br i1 %t86, label %bb30, label %bb31
bb30:
  %t88 = load ptr, ptr %l1, !tbaa !29
  %t90 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t88)
  store %"compiler/source:Span" %t90, ptr %l49
  br label %bb32
bb31:
  store i1 false, ptr %l47, !tbaa !21
  br label %bb33
bb32:
  %t91 = getelementptr %"compiler/source:Span", ptr %l49, i32 0, i32 1
  %t92 = load i32, ptr %t91, !tbaa !23
  %t93 = getelementptr %"compiler/source:Span", ptr %l3, i32 0, i32 0
  %t94 = load i32, ptr %t93, !tbaa !23
  %t96 = add i32 %t94, 3
  %t99 = icmp sgt i32 %t92, %t96
  store i1 %t99, ptr %l47, !tbaa !21
  br label %bb33
bb33:
  %t101 = load i1, ptr %l47, !tbaa !21
  br i1 %t101, label %bb34, label %bb35
bb34:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t103 = load ptr, ptr %l1, !tbaa !29
  %t106 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewrittenRefOrVar(ptr %v0, ptr %v1, ptr %t102, ptr %t103)
  store i1 %t106, ptr %l57
  br label %bb36
bb35:
  store i1 false, ptr %l54, !tbaa !21
  br label %bb37
bb36:
  %t107 = load i1, ptr %l57, !tbaa !21
  store i1 %t107, ptr %l54, !tbaa !21
  br label %bb37
bb37:
  %t108 = load i1, ptr %l54, !tbaa !21
  br i1 %t108, label %bb38, label %bb39
bb38:
  store %olang.scope zeroinitializer, ptr %s5
  %t109 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s5, i32 -1, i32 -1)
  store %"compiler/source:Span" %t109, ptr %l58
  br label %bb40
bb39:
  br label %bb41
bb40:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s1)
  %t110 = load %"compiler/source:Span", ptr %l58
  store %"compiler/source:Span" %t110, ptr %rv
  br label %ret
bb41:
  %t111 = getelementptr %"compiler/source:Span", ptr %l3, i32 0, i32 0
  %t112 = load i32, ptr %t111, !tbaa !23
  %t113 = getelementptr %"compiler/source:Span", ptr %l3, i32 0, i32 0
  %t114 = load i32, ptr %t113, !tbaa !23
  %t116 = add i32 %t114, 3
  %t119 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s1, i32 %t112, i32 %t116)
  store %"compiler/source:Span" %t119, ptr %l62
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s1)
  %t120 = load %"compiler/source:Span", ptr %l62
  store %"compiler/source:Span" %t120, ptr %rv
  br label %ret
bb43:
  store %olang.scope zeroinitializer, ptr %s6
  %t121 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s6, i32 -1, i32 -1)
  store %"compiler/source:Span" %t121, ptr %l63
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s6)
  %t122 = load %"compiler/source:Span", ptr %l63
  store %"compiler/source:Span" %t122, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enamesLocal(ptr %v0, ptr %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l5 = alloca ptr
  %l7 = alloca ptr
  %l11 = alloca %"compiler/names:Ref"
  %l15 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 1
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l5, !tbaa !29
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t8)
  store ptr %t10, ptr %l7
  br label %bb1
bb1:
  %t11 = load ptr, ptr %l7, !tbaa !29
  %t13 = getelementptr %"compiler/check:frame", ptr %t11, i32 0, i32 2
  %t14 = load i64, ptr %t13, !tbaa !24
  %t15 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t16 = load i32, ptr %t15, !tbaa !23
  %t17 = load ptr, ptr %l5, !tbaa !29
  %t20 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t17, i64 %t14, i32 %t16)
  store %"compiler/names:Ref" %t20, ptr %l11
  br label %bb2
bb2:
  %t21 = getelementptr %"compiler/names:Ref", ptr %l11, i32 0, i32 0
  %t22 = load i32, ptr %t21
  store i32 %t22, ptr %l2
  %t24 = load i32, ptr %l2
  %t26 = trunc i64 1 to i32
  %t27 = icmp eq i32 %t24, %t26
  br i1 %t27, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb5
bb4:
  %t29 = load i32, ptr %l2
  %t31 = trunc i64 8 to i32
  %t32 = icmp eq i32 %t29, %t31
  store i1 %t32, ptr %l15, !tbaa !21
  br label %bb5
bb5:
  %t34 = load i1, ptr %l15, !tbaa !21
  store i1 %t34, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoMeet(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i32
  %l6 = alloca i1
  %l8 = alloca i1
  %l11 = alloca i1
  %l13 = alloca i1
  %l16 = alloca i1
  %l22 = alloca i32
  %l25 = alloca ptr
  %l26 = alloca %"compiler/source:Span"
  %l29 = alloca { i64, ptr }
  %l30 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l39 = alloca %"compiler/msgs:Msg"
  %l40 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  %t5 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i1, ptr %l6, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb5
bb3:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load i32, ptr %l3, !tbaa !23
  %t13 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t9, i32 %t10)
  store i1 %t13, ptr %l11
  br label %bb4
bb4:
  %t14 = load i1, ptr %l11, !tbaa !21
  %t15 = xor i1 %t14, true
  store i1 %t15, ptr %l8, !tbaa !21
  br label %bb5
bb5:
  %t17 = load i1, ptr %l8, !tbaa !21
  br i1 %t17, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb9
bb7:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load i32, ptr %l2, !tbaa !23
  %t22 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t18, i32 %t19)
  store i1 %t22, ptr %l16
  br label %bb8
bb8:
  %t23 = load i1, ptr %l16, !tbaa !21
  store i1 %t23, ptr %l13, !tbaa !21
  br label %bb9
bb9:
  %t24 = load i1, ptr %l13, !tbaa !21
  br i1 %t24, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/check:Checker", ptr %t26, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t30 = load i32, ptr %l2, !tbaa !23
  %t31 = load i32, ptr %l3, !tbaa !23
  %t35 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMeet(ptr %v0, ptr %t29, i32 %t30, i32 %t31)
  store i32 %t35, ptr %l22
  br label %bb13
bb13:
  %t36 = load i32, ptr %l22, !tbaa !23
  %t37 = icmp sge i32 %t36, 0
  br i1 %t37, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t40 = load ptr, ptr %l0, !tbaa !29
  store ptr %t40, ptr %l25, !tbaa !29
  store %"compiler/source:Span" %a1, ptr %l26
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load i32, ptr %l2, !tbaa !23
  %t46 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t42, i32 %t43)
  store { i64, ptr } %t46, ptr %l29
  br label %bb17
bb17:
  %t47 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t48 = extractvalue { i64, ptr } %t47, 0
  %t49 = extractvalue { i64, ptr } %t47, 1
  %t50 = mul i64 %t48, 1
  %t51 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t50)
  call void @llvm.memcpy.p0.p0.i64(ptr %t51, ptr %t49, i64 %t50, i1 false)
  %t52 = insertvalue { i64, ptr } undef, i64 %t48, 0
  %t53 = insertvalue { i64, ptr } %t52, ptr %t51, 1
  store { i64, ptr } %t53, ptr %l30, !tbaa !27
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load i32, ptr %l2, !tbaa !23
  %t58 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t54, i32 %t55)
  store { i64, ptr } %t58, ptr %l33
  br label %bb18
bb18:
  %t59 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t60 = extractvalue { i64, ptr } %t59, 0
  %t61 = extractvalue { i64, ptr } %t59, 1
  %t62 = mul i64 %t60, 1
  %t63 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t62)
  call void @llvm.memcpy.p0.p0.i64(ptr %t63, ptr %t61, i64 %t62, i1 false)
  %t64 = insertvalue { i64, ptr } undef, i64 %t60, 0
  %t65 = insertvalue { i64, ptr } %t64, ptr %t63, 1
  store { i64, ptr } %t65, ptr %l34, !tbaa !27
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load i32, ptr %l3, !tbaa !23
  %t70 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t66, i32 %t67)
  store { i64, ptr } %t70, ptr %l37
  br label %bb19
bb19:
  %t71 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t72 = extractvalue { i64, ptr } %t71, 0
  %t73 = extractvalue { i64, ptr } %t71, 1
  %t74 = mul i64 %t72, 1
  %t75 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t74)
  call void @llvm.memcpy.p0.p0.i64(ptr %t75, ptr %t73, i64 %t74, i1 false)
  %t76 = insertvalue { i64, ptr } undef, i64 %t72, 0
  %t77 = insertvalue { i64, ptr } %t76, ptr %t75, 1
  %t78 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t79 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t81 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eLiteralDoesNotMeet(ptr %s0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t78, { i64, ptr } %t79, { i64, ptr } %t77)
  store %"compiler/msgs:Msg" %t81, ptr %l39
  br label %bb20
bb20:
  %t82 = load ptr, ptr %l25, !tbaa !29
  %t83 = load %"compiler/source:Span", ptr %l26
  %t84 = load %"compiler/msgs:Msg", ptr %l39
  %t85 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s0, ptr %t82, %"compiler/source:Span" %t83, %"compiler/msgs:Msg" %t84)
  store i64 %t85, ptr %l40
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoreturnSpan(ptr %v0, ptr %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l1 = alloca %"compiler/source:Span"
  %l3 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i32
  %l24 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t2 = load %"compiler/source:Span", ptr %l1
  %t5 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %a0, %"compiler/source:Span" %t2)
  store { i64, ptr } %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t9 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %s0, { i64, ptr } %t6, { i64, ptr } { i64 10, ptr @.d8 })
  %t10 = extractvalue { i32, i64 } %t9, 1
  %t11 = extractvalue { i32, i64 } %t9, 0
  store i32 %t11, ptr %l10
  %t12 = icmp ne i32 %t11, 0
  br i1 %t12, label %bb3, label %ok.13
ok.13:
  store i64 %t10, ptr %l9
  br label %bb2
bb2:
  %t14 = load i64, ptr %l9, !tbaa !24
  store i64 %t14, ptr %l7, !tbaa !24
  br label %bb5
bb3:
  br label %bb4
bb4:
  store i64 -1, ptr %l7, !tbaa !24
  br label %bb5
bb5:
  %t15 = load i64, ptr %l7, !tbaa !24
  store i64 %t15, ptr %l3, !tbaa !24
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = icmp slt i64 %t16, 0
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t20 = load %"compiler/source:Span", ptr %l1
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/source:Span" %t20, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t22 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t23 = load i32, ptr %t22, !tbaa !23
  %t24 = load i64, ptr %l3, !tbaa !24
  %t26 = add i64 %t24, 2
  %t28 = trunc i64 %t26 to i32
  %t31 = add i32 %t23, %t28
  %t32 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t33 = load i32, ptr %t32, !tbaa !23
  %t34 = load i64, ptr %l3, !tbaa !24
  %t36 = add i64 %t34, 10
  %t38 = trunc i64 %t36 to i32
  %t41 = add i32 %t33, %t38
  %t44 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %t31, i32 %t41)
  store %"compiler/source:Span" %t44, ptr %l24
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s0)
  %t45 = load %"compiler/source:Span", ptr %l24
  store %"compiler/source:Span" %t45, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotCapture(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2) #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emustWrite(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2, i1 true)
  br label %bb1
bb1:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotOperator(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, { i64, ptr } %a2, %"compiler/source:Span" %a3, { i64, ptr } %a4, i64 %a5, i1 %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i1
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca ptr
  %l15 = alloca %"compiler/source:Span"
  %l19 = alloca i1
  %l22 = alloca i1
  %l26 = alloca ptr
  %l27 = alloca i32
  %l33 = alloca i32
  %l34 = alloca i64
  %l38 = alloca ptr
  %l39 = alloca i32
  %l43 = alloca ptr
  %l45 = alloca { i64, ptr }
  %l47 = alloca i32
  %l48 = alloca i64
  %l54 = alloca ptr
  %l57 = alloca ptr
  %l61 = alloca i32
  %l62 = alloca i32
  %l63 = alloca { i64, ptr }
  %l67 = alloca i1
  %l77 = alloca { i64, ptr }
  %l80 = alloca { i64, ptr }
  %l86 = alloca { i64, ptr }
  %l92 = alloca { i64, ptr }
  %l94 = alloca { i64, ptr }
  %l99 = alloca ptr
  %l100 = alloca %"compiler/source:Span"
  %l103 = alloca { i64, ptr }
  %l104 = alloca { i64, ptr }
  %l105 = alloca ptr
  %l109 = alloca ptr
  %l112 = alloca { i64, ptr }
  %l116 = alloca %"compiler/msgs:Msg"
  %l117 = alloca i64
  %l121 = alloca ptr
  %l125 = alloca ptr
  %l129 = alloca i64
  %l130 = alloca ptr
  %l138 = alloca ptr
  %l139 = alloca i64
  %l145 = alloca { i64, [3 x i64] }
  %l149 = alloca { i64, ptr }
  %l151 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca i1
  %t311 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store i64 %a5, ptr %l5
  store i1 %a6, ptr %l6
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l1, !tbaa !23
  %t2 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t5 = icmp eq i32 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb4
bb2:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l1, !tbaa !23
  %t11 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t7, i32 %t8)
  store i1 %t11, ptr %l22
  br label %bb3
bb3:
  %t12 = load i1, ptr %l22, !tbaa !21
  %t13 = xor i1 %t12, true
  store i1 %t13, ptr %l19, !tbaa !21
  br label %bb4
bb4:
  %t15 = load i1, ptr %l19, !tbaa !21
  br i1 %t15, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/check:Checker", ptr %t17, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !29
  store ptr %t20, ptr %l26, !tbaa !29
  %t21 = load i32, ptr %l1, !tbaa !23
  store i32 %t21, ptr %l27, !tbaa !23
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/check:Checker", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/generic:Program", ptr %t25, i32 0, i32 0
  %t28 = load ptr, ptr %t27, !tbaa !29
  %t30 = getelementptr %"compiler/load:Loader", ptr %t28, i32 0, i32 3
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t32 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t35 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %t31, { i64, ptr } %t32)
  store i32 %t35, ptr %l33
  br label %bb8
bb8:
  %t36 = load ptr, ptr %l26, !tbaa !29
  %t37 = load i32, ptr %l27, !tbaa !23
  %t38 = load i32, ptr %l33, !tbaa !23
  %t39 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t36, i32 %t37, i32 %t38)
  store i64 %t39, ptr %l34
  br label %bb9
bb9:
  %t40 = load i64, ptr %l34, !tbaa !24
  store i64 %t40, ptr %l7, !tbaa !24
  %t41 = load i64, ptr %l7, !tbaa !24
  %t43 = icmp slt i64 %t41, 0
  br i1 %t43, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/check:Checker", ptr %t45, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !29
  store ptr %t48, ptr %l38, !tbaa !29
  %t49 = load i32, ptr %l1, !tbaa !23
  store i32 %t49, ptr %l39, !tbaa !23
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/check:Checker", ptr %t50, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t55 = getelementptr %"compiler/generic:Program", ptr %t53, i32 0, i32 0
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t58 = getelementptr %"compiler/load:Loader", ptr %t56, i32 0, i32 3
  %t59 = load ptr, ptr %t58, !tbaa !29
  store ptr %t59, ptr %l43, !tbaa !29
  %t60 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t62 = call { i64, ptr } @compiler_2fcheck_2elowerFirst(ptr %v1, ptr %s2, { i64, ptr } %t60)
  store { i64, ptr } %t62, ptr %l45
  br label %bb12
bb11:
  br label %bb15
bb12:
  %t63 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t64 = extractvalue { i64, ptr } %t63, 0
  %t65 = extractvalue { i64, ptr } %t63, 1
  %t66 = mul i64 %t64, 1
  %t67 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t66)
  call void @llvm.memcpy.p0.p0.i64(ptr %t67, ptr %t65, i64 %t66, i1 false)
  %t68 = insertvalue { i64, ptr } undef, i64 %t64, 0
  %t69 = insertvalue { i64, ptr } %t68, ptr %t67, 1
  %t70 = load ptr, ptr %l43, !tbaa !29
  %t72 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %s2, ptr %t70, { i64, ptr } %t69)
  store i32 %t72, ptr %l47
  br label %bb13
bb13:
  %t73 = load ptr, ptr %l38, !tbaa !29
  %t74 = load i32, ptr %l39, !tbaa !23
  %t75 = load i32, ptr %l47, !tbaa !23
  %t76 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t73, i32 %t74, i32 %t75)
  store i64 %t76, ptr %l48
  br label %bb14
bb14:
  %t77 = load i64, ptr %l48, !tbaa !24
  store i64 %t77, ptr %l7, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb15
bb15:
  %t78 = load i64, ptr %l7, !tbaa !24
  %t80 = icmp slt i64 %t78, 0
  br i1 %t80, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/check:Checker", ptr %t83, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !29
  %t88 = getelementptr %"compiler/generic:Program", ptr %t86, i32 0, i32 2
  store ptr %t88, ptr %l54, !tbaa !29
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"compiler/check:Checker", ptr %t89, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !29
  %t94 = getelementptr %"compiler/generic:Program", ptr %t92, i32 0, i32 2
  store ptr %t94, ptr %l57, !tbaa !29
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr %"compiler/check:Checker", ptr %t95, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !29
  %t99 = load i64, ptr %l7, !tbaa !24
  %t102 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t98, i64 %t99)
  store i32 %t102, ptr %l61
  br label %bb19
bb19:
  %t103 = load ptr, ptr %l57, !tbaa !29
  %t104 = load i32, ptr %l61, !tbaa !23
  %t105 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t103, i32 %t104)
  store i32 %t105, ptr %l62
  br label %bb20
bb20:
  %t106 = load ptr, ptr %l54, !tbaa !29
  %t107 = load i32, ptr %l62, !tbaa !23
  %t108 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t106, i32 %t107)
  store { i64, ptr } %t108, ptr %l63
  br label %bb21
bb21:
  %t109 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t110 = extractvalue { i64, ptr } %t109, 0
  %t112 = sub i64 %t110, 1
  store i64 %t112, ptr %l8, !tbaa !24
  %t114 = load i1, ptr %l6, !tbaa !21
  br i1 %t114, label %bb22, label %bb23
bb22:
  %t116 = load i64, ptr %l8, !tbaa !24
  %t117 = load i64, ptr %l5, !tbaa !24
  %t120 = icmp sge i64 %t116, %t117
  store i1 %t120, ptr %l67, !tbaa !21
  br label %bb24
bb23:
  %t122 = load i64, ptr %l8, !tbaa !24
  %t123 = load i64, ptr %l5, !tbaa !24
  %t126 = icmp eq i64 %t122, %t123
  store i1 %t126, ptr %l67, !tbaa !21
  br label %bb24
bb24:
  %t128 = load i1, ptr %l67, !tbaa !21
  br i1 %t128, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  %t130 = load i64, ptr %l8, !tbaa !24
  %t132 = icmp eq i64 %t130, 0
  br i1 %t132, label %bb28, label %bb29
bb28:
  store { i64, ptr } { i64 13, ptr @.d9 }, ptr %l77, !tbaa !27
  br label %bb33
bb29:
  %t134 = load i64, ptr %l8, !tbaa !24
  %t136 = icmp eq i64 %t134, 1
  br i1 %t136, label %bb30, label %bb31
bb30:
  store { i64, ptr } { i64 13, ptr @.d10 }, ptr %l80, !tbaa !27
  br label %bb32
bb31:
  %t138 = load i64, ptr %l8, !tbaa !24
  %t140 = call i64 @__olang_fmt_i64(ptr null, i64 %t138)
  %t141 = extractvalue { i64, ptr } { i64 11, ptr @.d11 }, 1
  %t142 = extractvalue { i64, ptr } { i64 11, ptr @.d11 }, 0
  %t143 = add i64 %t140, %t142
  %t144 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t143)
  %t145 = call i64 @__olang_fmt_i64(ptr %t144, i64 %t138)
  %t146 = getelementptr i8, ptr %t144, i64 %t140
  call void @olang_textcopy(ptr %t146, ptr %t141, i64 %t142)
  %t147 = insertvalue { i64, ptr } undef, i64 %t143, 0
  %t148 = insertvalue { i64, ptr } %t147, ptr %t144, 1
  %t150 = extractvalue { i64, ptr } %t148, 0
  %t151 = extractvalue { i64, ptr } %t148, 1
  %t152 = mul i64 %t150, 1
  %t153 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t152)
  call void @llvm.memcpy.p0.p0.i64(ptr %t153, ptr %t151, i64 %t152, i1 false)
  %t154 = insertvalue { i64, ptr } undef, i64 %t150, 0
  %t155 = insertvalue { i64, ptr } %t154, ptr %t153, 1
  store { i64, ptr } %t155, ptr %l80, !tbaa !27
  br label %bb32
bb32:
  %t157 = load { i64, ptr }, ptr %l80, !tbaa !27
  store { i64, ptr } %t157, ptr %l77, !tbaa !27
  br label %bb33
bb33:
  %t158 = load { i64, ptr }, ptr %l77, !tbaa !27
  store { i64, ptr } %t158, ptr %l9, !tbaa !27
  %t159 = load i64, ptr %l5, !tbaa !24
  %t161 = icmp eq i64 %t159, 1
  br i1 %t161, label %bb34, label %bb35
bb34:
  store { i64, ptr } { i64 3, ptr @.d12 }, ptr %l86, !tbaa !27
  br label %bb36
bb35:
  %t163 = load i64, ptr %l5, !tbaa !24
  %t165 = call i64 @__olang_fmt_i64(ptr null, i64 %t163)
  %t166 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t165)
  %t167 = call i64 @__olang_fmt_i64(ptr %t166, i64 %t163)
  %t168 = insertvalue { i64, ptr } undef, i64 %t165, 0
  %t169 = insertvalue { i64, ptr } %t168, ptr %t166, 1
  %t171 = extractvalue { i64, ptr } %t169, 0
  %t172 = extractvalue { i64, ptr } %t169, 1
  %t173 = mul i64 %t171, 1
  %t174 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t173)
  call void @llvm.memcpy.p0.p0.i64(ptr %t174, ptr %t172, i64 %t173, i1 false)
  %t175 = insertvalue { i64, ptr } undef, i64 %t171, 0
  %t176 = insertvalue { i64, ptr } %t175, ptr %t174, 1
  store { i64, ptr } %t176, ptr %l86, !tbaa !27
  br label %bb36
bb36:
  %t178 = load { i64, ptr }, ptr %l86, !tbaa !27
  store { i64, ptr } %t178, ptr %l10, !tbaa !27
  %t179 = load i64, ptr %l5, !tbaa !24
  %t181 = icmp eq i64 %t179, 0
  br i1 %t181, label %bb37, label %bb38
bb37:
  store { i64, ptr } { i64 4, ptr @.d13 }, ptr %l92, !tbaa !27
  br label %bb42
bb38:
  %t183 = load i1, ptr %l6, !tbaa !21
  br i1 %t183, label %bb39, label %bb40
bb39:
  %t185 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t186 = extractvalue { i64, ptr } { i64 9, ptr @.d14 }, 1
  %t187 = extractvalue { i64, ptr } { i64 9, ptr @.d14 }, 0
  %t189 = extractvalue { i64, ptr } %t185, 1
  %t190 = extractvalue { i64, ptr } %t185, 0
  %t191 = add i64 %t187, %t190
  %t192 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t191)
  call void @olang_textcopy(ptr %t192, ptr %t186, i64 %t187)
  %t193 = getelementptr i8, ptr %t192, i64 %t187
  call void @olang_textcopy(ptr %t193, ptr %t189, i64 %t190)
  %t194 = insertvalue { i64, ptr } undef, i64 %t191, 0
  %t195 = insertvalue { i64, ptr } %t194, ptr %t192, 1
  %t197 = extractvalue { i64, ptr } %t195, 0
  %t198 = extractvalue { i64, ptr } %t195, 1
  %t199 = mul i64 %t197, 1
  %t200 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t199)
  call void @llvm.memcpy.p0.p0.i64(ptr %t200, ptr %t198, i64 %t199, i1 false)
  %t201 = insertvalue { i64, ptr } undef, i64 %t197, 0
  %t202 = insertvalue { i64, ptr } %t201, ptr %t200, 1
  store { i64, ptr } %t202, ptr %l94, !tbaa !27
  br label %bb41
bb40:
  %t204 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t204, ptr %l94, !tbaa !27
  br label %bb41
bb41:
  %t206 = load { i64, ptr }, ptr %l94, !tbaa !27
  store { i64, ptr } %t206, ptr %l92, !tbaa !27
  br label %bb42
bb42:
  %t207 = load { i64, ptr }, ptr %l92, !tbaa !27
  store { i64, ptr } %t207, ptr %l11, !tbaa !27
  %t208 = load ptr, ptr %l0, !tbaa !29
  store ptr %t208, ptr %l99, !tbaa !29
  store %"compiler/source:Span" %a3, ptr %l100
  %t210 = load ptr, ptr %l0, !tbaa !29
  %t211 = load i32, ptr %l1, !tbaa !23
  %t214 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t210, i32 %t211)
  store { i64, ptr } %t214, ptr %l103
  br label %bb43
bb43:
  %t215 = load { i64, ptr }, ptr %l103, !tbaa !27
  %t216 = extractvalue { i64, ptr } %t215, 0
  %t217 = extractvalue { i64, ptr } %t215, 1
  %t218 = mul i64 %t216, 1
  %t219 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t218)
  call void @llvm.memcpy.p0.p0.i64(ptr %t219, ptr %t217, i64 %t218, i1 false)
  %t220 = insertvalue { i64, ptr } undef, i64 %t216, 0
  %t221 = insertvalue { i64, ptr } %t220, ptr %t219, 1
  store { i64, ptr } %t221, ptr %l104, !tbaa !27
  %t222 = load ptr, ptr %l0, !tbaa !29
  store ptr %t222, ptr %l105, !tbaa !29
  %t223 = load ptr, ptr %l0, !tbaa !29
  %t225 = getelementptr %"compiler/check:Checker", ptr %t223, i32 0, i32 1
  %t226 = load ptr, ptr %t225, !tbaa !29
  %t227 = load i64, ptr %l7, !tbaa !24
  %t230 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t226, i64 %t227)
  store ptr %t230, ptr %l109
  br label %bb44
bb44:
  %t231 = load ptr, ptr %l109, !tbaa !29
  %t233 = getelementptr %"compiler/ast:Func", ptr %t231, i32 0, i32 2
  %t234 = load i32, ptr %t233, !tbaa !23
  %t235 = load ptr, ptr %l105, !tbaa !29
  %t237 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t235, i32 %t234)
  store { i64, ptr } %t237, ptr %l112
  br label %bb45
bb45:
  %t238 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t240 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t241 = load { i64, ptr }, ptr %l104, !tbaa !27
  %t242 = load { i64, ptr }, ptr %l112, !tbaa !27
  %t246 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotTheOperator(ptr %s0, ptr %v0, ptr %s0, ptr %v2, ptr %s0, ptr %s0, { i64, ptr } %t241, { i64, ptr } %t242, { i64, ptr } %t238, { i64, ptr } %a4, { i64, ptr } %t240)
  store %"compiler/msgs:Msg" %t246, ptr %l116
  br label %bb46
bb46:
  %t247 = load ptr, ptr %l99, !tbaa !29
  %t248 = load %"compiler/source:Span", ptr %l100
  %t249 = load %"compiler/msgs:Msg", ptr %l116
  %t250 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s0, ptr %t247, %"compiler/source:Span" %t248, %"compiler/msgs:Msg" %t249)
  store i64 %t250, ptr %l117
  br label %bb47
bb47:
  %t251 = load i64, ptr %l117, !tbaa !24
  store i64 %t251, ptr %l12, !tbaa !24
  %t252 = load ptr, ptr %l0, !tbaa !29
  %t254 = getelementptr %"compiler/check:Checker", ptr %t252, i32 0, i32 1
  %t255 = load ptr, ptr %t254, !tbaa !29
  %t256 = load i64, ptr %l7, !tbaa !24
  %t259 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t255, i64 %t256)
  store ptr %t259, ptr %l121
  br label %bb48
bb48:
  %t260 = load ptr, ptr %l121, !tbaa !29
  store ptr %t260, ptr %l13, !tbaa !29
  %t261 = load ptr, ptr %l0, !tbaa !29
  %t263 = getelementptr %"compiler/check:Checker", ptr %t261, i32 0, i32 1
  %t264 = load ptr, ptr %t263, !tbaa !29
  %t266 = getelementptr %"compiler/generic:Program", ptr %t264, i32 0, i32 0
  %t267 = load ptr, ptr %t266, !tbaa !29
  %t269 = getelementptr %"compiler/load:Loader", ptr %t267, i32 0, i32 5
  store ptr %t269, ptr %l125, !tbaa !29
  %t270 = load ptr, ptr %l0, !tbaa !29
  %t272 = getelementptr %"compiler/check:Checker", ptr %t270, i32 0, i32 1
  %t273 = load ptr, ptr %t272, !tbaa !29
  %t274 = load i64, ptr %l7, !tbaa !24
  %t277 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t273, i64 %t274)
  store i64 %t277, ptr %l129
  br label %bb49
bb49:
  %t278 = load ptr, ptr %l125, !tbaa !29
  %t279 = load i64, ptr %l129, !tbaa !24
  %t280 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t278, i64 %t279)
  store ptr %t280, ptr %l130
  br label %bb50
bb50:
  %t281 = load ptr, ptr %l130, !tbaa !29
  %t283 = getelementptr %"compiler/load:Module", ptr %t281, i32 0, i32 4
  %t284 = load i64, ptr %t283, !tbaa !24
  %t286 = load ptr, ptr %l13, !tbaa !29
  %t288 = getelementptr %"compiler/ast:Func", ptr %t286, i32 0, i32 0
  %t289 = load %"compiler/source:Span", ptr %t288
  store %"compiler/source:Span" %t289, ptr %l15
  %t291 = load ptr, ptr %l0, !tbaa !29
  %t293 = getelementptr %"compiler/check:Checker", ptr %t291, i32 0, i32 1
  %t294 = load ptr, ptr %t293, !tbaa !29
  %t296 = getelementptr %"compiler/generic:Program", ptr %t294, i32 0, i32 0
  %t297 = load ptr, ptr %t296, !tbaa !29
  %t299 = getelementptr %"compiler/load:Loader", ptr %t297, i32 0, i32 4
  %t300 = load ptr, ptr %t299, !tbaa !29
  store ptr %t300, ptr %l138, !tbaa !29
  %t301 = load i64, ptr %l12, !tbaa !24
  store i64 %t301, ptr %l139, !tbaa !24
  %t303 = getelementptr %"compiler/source:Span", ptr %l15, i32 0, i32 0
  %t304 = load i32, ptr %t303, !tbaa !23
  %t306 = sext i32 %t304 to i64
  %t307 = getelementptr %"compiler/source:Span", ptr %l15, i32 0, i32 1
  %t308 = load i32, ptr %t307, !tbaa !23
  %t310 = sext i32 %t308 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t311
  %t312 = getelementptr { i64, [3 x i64] }, ptr %t311, i32 0, i32 0
  store i64 3, ptr %t312
  %t314 = insertvalue { i64, i64, i64 } undef, i64 %t284, 0
  %t316 = insertvalue { i64, i64, i64 } %t314, i64 %t306, 1
  %t318 = insertvalue { i64, i64, i64 } %t316, i64 %t310, 2
  %t319 = getelementptr { i64, [3 x i64] }, ptr %t311, i32 0, i32 1
  store { i64, i64, i64 } %t318, ptr %t319
  %t320 = load { i64, [3 x i64] }, ptr %t311
  store { i64, [3 x i64] } %t320, ptr %l145
  %t321 = load ptr, ptr %l0, !tbaa !29
  %t322 = load ptr, ptr %l13, !tbaa !29
  %t324 = getelementptr %"compiler/ast:Func", ptr %t322, i32 0, i32 2
  %t325 = load i32, ptr %t324, !tbaa !23
  %t328 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s0, ptr %t321, i32 %t325)
  store { i64, ptr } %t328, ptr %l149
  br label %bb51
bb51:
  %t329 = load { i64, ptr }, ptr %l149, !tbaa !27
  %t330 = extractvalue { i64, ptr } %t329, 0
  %t331 = extractvalue { i64, ptr } %t329, 1
  %t332 = mul i64 %t330, 1
  %t333 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t332)
  call void @llvm.memcpy.p0.p0.i64(ptr %t333, ptr %t331, i64 %t332, i1 false)
  %t334 = insertvalue { i64, ptr } undef, i64 %t330, 0
  %t335 = insertvalue { i64, ptr } %t334, ptr %t333, 1
  %t337 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteDeclaredHere(ptr %s0, ptr %s0, { i64, ptr } %t335)
  store %"compiler/msgs:Msg" %t337, ptr %l151
  br label %bb52
bb52:
  %t338 = load ptr, ptr %l138, !tbaa !29
  %t339 = load i64, ptr %l139, !tbaa !24
  %t340 = load { i64, [3 x i64] }, ptr %l145
  %t341 = load %"compiler/msgs:Msg", ptr %l151
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %s0, ptr %t338, i64 %t339, { i64, [3 x i64] } %t340, %"compiler/msgs:Msg" %t341)
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enullKnown(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca %"compiler/check:nullNarrow"
  %l13 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca i32
  %l29 = alloca { i64, ptr }
  %l34 = alloca i1
  %l37 = alloca i1
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t10 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %a0)
  store ptr %t10, ptr %l13
  br label %bb4
bb4:
  %t11 = load ptr, ptr %l13, !tbaa !29
  %t13 = getelementptr %"compiler/check:frame", ptr %t11, i32 0, i32 46
  store ptr %t13, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb5
bb5:
  store %olang.scope zeroinitializer, ptr %s3
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t16 = load i64, ptr %l3, !tbaa !24
  %t19 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3anullNarrow_3e_2e_H7b40d2e2dc0a1b98abd717d3c6137546(ptr %v0, ptr %t15, i64 %t16)
  %t20 = extractvalue { i32, { i64, ptr } } %t19, 1
  %t21 = extractvalue { i32, { i64, ptr } } %t19, 0
  store i32 %t21, ptr %l20
  %t22 = icmp ne i32 %t21, 0
  br i1 %t22, label %bb7, label %ok.23
ok.23:
  store { i64, ptr } %t20, ptr %l19
  br label %bb6
bb6:
  %t24 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t24, ptr %l16, !tbaa !27
  br label %bb11
bb7:
  %t25 = load i32, ptr %l20, !tbaa !23
  %t26 = ashr i32 %t25, 16
  %t28 = icmp eq i32 %t26, 1
  br i1 %t28, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_9c106c9f4aa088c5_d9578fd6b61bf4a9)
  unreachable
bb10:
  call void @__olang_scope_close(ptr %s3)
  br label %bb26
bb11:
  %t30 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t30, ptr %l4, !tbaa !27
  %t31 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t33 = extractvalue { i64, ptr } %t31, 0
  store i64 %t33, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s4
  %t35 = load i64, ptr %l6, !tbaa !24
  %t36 = load i64, ptr %l5, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s4)
  br label %bb24
bb14:
  br label %bb15
bb15:
  %t43 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t43, ptr %l29, !tbaa !27
  %t44 = load i64, ptr %l6, !tbaa !24
  %t46 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = getelementptr %"compiler/check:nullNarrow", ptr %t47, i64 %t44
  %t49 = load %"compiler/check:nullNarrow", ptr %t48
  store %"compiler/check:nullNarrow" %t49, ptr %l7
  %t51 = getelementptr %"compiler/check:nullNarrow", ptr %l7, i32 0, i32 2
  %t52 = load i1, ptr %t51, !tbaa !21
  %t54 = xor i1 %t52, true
  br i1 %t54, label %bb16, label %bb17
bb16:
  %t56 = getelementptr %"compiler/check:nullNarrow", ptr %l7, i32 0, i32 0
  %t57 = load { i64, ptr }, ptr %t56, !tbaa !27
  %t58 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t61 = call i1 @compiler_2fcheck_2esamePath(ptr %v0, ptr %v1, { i64, ptr } %t57, { i64, ptr } %t58)
  store i1 %t61, ptr %l37
  br label %bb18
bb17:
  store i1 false, ptr %l34, !tbaa !21
  br label %bb19
bb18:
  %t62 = load i1, ptr %l37, !tbaa !21
  store i1 %t62, ptr %l34, !tbaa !21
  br label %bb19
bb19:
  %t63 = load i1, ptr %l34, !tbaa !21
  br i1 %t63, label %bb20, label %bb21
bb20:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  store i1 true, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s4)
  br label %bb23
bb23:
  %t65 = load i64, ptr %l6, !tbaa !24
  %t67 = add i64 %t65, 1
  store i64 %t67, ptr %l6, !tbaa !24
  br label %bb12
bb24:
  %t69 = load i64, ptr %l3, !tbaa !24
  %t70 = load i64, ptr %l5, !tbaa !24
  %t73 = add i64 %t69, %t70
  store i64 %t73, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb25
bb25:
  br label %bb5
bb26:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopValues(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, ptr %a4, ptr %a5, %"compiler/source:Span" %a6, %"compiler/source:Span" %a7) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca ptr
  %l11 = alloca i1
  %l12 = alloca %"compiler/source:Span"
  %l14 = alloca i32
  %l17 = alloca i32
  %l20 = alloca i32
  %l24 = alloca i1
  %l28 = alloca ptr
  %l29 = alloca %"compiler/source:Span"
  %l31 = alloca i1
  %l32 = alloca i32
  %l35 = alloca ptr
  %l39 = alloca i1
  %l45 = alloca i1
  %l48 = alloca i1
  %l51 = alloca ptr
  %l52 = alloca %"compiler/source:Span"
  %l53 = alloca i32
  %l55 = alloca i32
  %l59 = alloca ptr
  %l60 = alloca ptr
  %l61 = alloca %"compiler/source:Span"
  %l63 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  %l66 = alloca %"compiler/msgs:Msg"
  %l67 = alloca i64
  %l70 = alloca ptr
  %l73 = alloca ptr
  %l74 = alloca %"compiler/source:Span"
  %l77 = alloca { i64, ptr }
  %l79 = alloca %"compiler/msgs:Msg"
  %l80 = alloca i64
  %l83 = alloca ptr
  %l87 = alloca i1
  %l97 = alloca ptr
  %l104 = alloca ptr
  %l107 = alloca i32
  %l109 = alloca i1
  %l111 = alloca ptr
  %l112 = alloca %"compiler/source:Span"
  %l115 = alloca { i64, ptr }
  %l117 = alloca %"compiler/msgs:Msg"
  %l118 = alloca i64
  %l121 = alloca ptr
  %l124 = alloca i1
  %l127 = alloca i1
  %l130 = alloca i1
  %l131 = alloca i1
  %l137 = alloca i1
  %l138 = alloca i1
  %l141 = alloca i64
  %l145 = alloca i1
  %l147 = alloca i1
  %l150 = alloca i1
  %l152 = alloca i1
  %l156 = alloca i1
  %l168 = alloca ptr
  %l173 = alloca { i64, ptr }
  %l174 = alloca i1
  %l176 = alloca i1
  %l177 = alloca ptr
  %l180 = alloca i32
  %l182 = alloca { i64, ptr }
  %l183 = alloca %"compiler/source:Span"
  %l185 = alloca { i64, ptr }
  %l186 = alloca { i64, ptr }
  %l188 = alloca i1
  %l191 = alloca ptr
  %l194 = alloca i1
  %l195 = alloca i1
  %l198 = alloca i1
  %l199 = alloca ptr
  %l200 = alloca %"compiler/source:Span"
  %l202 = alloca { i64, ptr }
  %l203 = alloca { i64, ptr }
  %l204 = alloca { i64, ptr }
  %l207 = alloca { i64, ptr }
  %l208 = alloca { i64, ptr }
  %l211 = alloca { i64, ptr }
  %l213 = alloca %"compiler/msgs:Msg"
  %l214 = alloca i64
  %l215 = alloca ptr
  %l216 = alloca %"compiler/source:Span"
  %l218 = alloca { i64, ptr }
  %l219 = alloca { i64, ptr }
  %l220 = alloca { i64, ptr }
  %l223 = alloca { i64, ptr }
  %l225 = alloca %"compiler/msgs:Msg"
  %l226 = alloca i64
  %l229 = alloca ptr
  %l232 = alloca i1
  %l237 = alloca i1
  %l239 = alloca ptr
  %l240 = alloca %"compiler/source:Span"
  %l242 = alloca { i64, ptr }
  %l243 = alloca { i64, ptr }
  %l244 = alloca { i64, ptr }
  %l247 = alloca { i64, ptr }
  %l249 = alloca %"compiler/msgs:Msg"
  %l250 = alloca i64
  %l253 = alloca i1
  %l255 = alloca ptr
  %l256 = alloca %"compiler/source:Span"
  %l258 = alloca { i64, ptr }
  %l259 = alloca { i64, ptr }
  %l260 = alloca { i64, ptr }
  %l263 = alloca { i64, ptr }
  %l265 = alloca %"compiler/msgs:Msg"
  %l266 = alloca i64
  %l268 = alloca i1
  %l270 = alloca i1
  %l273 = alloca i1
  %l274 = alloca i1
  %l278 = alloca i1
  %l280 = alloca ptr
  %l281 = alloca %"compiler/source:Span"
  %l284 = alloca { i64, ptr }
  %l285 = alloca { i64, ptr }
  %l287 = alloca { i64, ptr }
  %l288 = alloca { i64, ptr }
  %l289 = alloca { i64, ptr }
  %l291 = alloca { i64, ptr }
  %l294 = alloca %"compiler/msgs:Msg"
  %l295 = alloca i64
  %l298 = alloca ptr
  %l299 = alloca ptr
  %l300 = alloca %"compiler/source:Span"
  %l301 = alloca i32
  %l303 = alloca i32
  %l306 = alloca ptr
  %l315 = alloca i32
  %l318 = alloca ptr
  %l319 = alloca %"compiler/source:Span"
  %l322 = alloca { i64, ptr }
  %l323 = alloca { i64, ptr }
  %l326 = alloca { i64, ptr }
  %l328 = alloca %"compiler/msgs:Msg"
  %l329 = alloca i64
  %l332 = alloca ptr
  %l340 = alloca ptr
  %l348 = alloca ptr
  %l350 = alloca i1
  %l351 = alloca i1
  %l354 = alloca i1
  %l356 = alloca ptr
  %l357 = alloca %"compiler/source:Span"
  %l359 = alloca { i64, ptr }
  %l360 = alloca { i64, ptr }
  %l361 = alloca { i64, ptr }
  %l364 = alloca { i64, ptr }
  %l366 = alloca %"compiler/msgs:Msg"
  %l367 = alloca i64
  %l370 = alloca ptr
  %l372 = alloca i1
  %l374 = alloca i1
  %l377 = alloca i1
  %l378 = alloca i1
  %l382 = alloca i1
  %l384 = alloca ptr
  %l385 = alloca %"compiler/source:Span"
  %l388 = alloca { i64, ptr }
  %l389 = alloca { i64, ptr }
  %l391 = alloca { i64, ptr }
  %l392 = alloca { i64, ptr }
  %l393 = alloca { i64, ptr }
  %l395 = alloca { i64, ptr }
  %l398 = alloca %"compiler/msgs:Msg"
  %l399 = alloca i64
  %l402 = alloca ptr
  %l404 = alloca i1
  %l405 = alloca ptr
  %l406 = alloca %"compiler/source:Span"
  %l407 = alloca i32
  %l409 = alloca i32
  %l413 = alloca ptr
  %l414 = alloca ptr
  %l415 = alloca %"compiler/source:Span"
  %l416 = alloca i32
  %l418 = alloca i32
  %l421 = alloca ptr
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  store i32 %a3, ptr %l3
  store ptr %a4, ptr %l4
  store ptr %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l4, !tbaa !29
  %t4 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t1)
  store i32 %t4, ptr %l17
  br label %bb1
bb1:
  %t5 = load i32, ptr %l17, !tbaa !23
  store i32 %t5, ptr %l8, !tbaa !23
  %t6 = load ptr, ptr %l5, !tbaa !29
  %t9 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t6)
  store i32 %t9, ptr %l20
  br label %bb2
bb2:
  %t10 = load i32, ptr %l20, !tbaa !23
  store i32 %t10, ptr %l9, !tbaa !23
  %t11 = load i32, ptr %l8, !tbaa !23
  %t12 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t15 = icmp eq i32 %t11, %t12
  br i1 %t15, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l24, !tbaa !21
  br label %bb5
bb4:
  %t17 = load i32, ptr %l9, !tbaa !23
  %t18 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t21 = icmp eq i32 %t17, %t18
  store i1 %t21, ptr %l24, !tbaa !21
  br label %bb5
bb5:
  %t23 = load i1, ptr %l24, !tbaa !21
  br i1 %t23, label %bb6, label %bb7
bb6:
  %t24 = load ptr, ptr %l0, !tbaa !29
  store ptr %t24, ptr %l28, !tbaa !29
  %t25 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t25, ptr %l29
  %t26 = load i32, ptr %l3
  %t28 = call i1 @compiler_2fcheck_2ecompares(i32 %t26)
  store i1 %t28, ptr %l31
  br label %bb8
bb7:
  br label %bb13
bb8:
  %t29 = load i1, ptr %l31, !tbaa !21
  br i1 %t29, label %bb9, label %bb10
bb9:
  %t30 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t30, ptr %l32, !tbaa !23
  br label %bb11
bb10:
  %t32 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t32, ptr %l32, !tbaa !23
  br label %bb11
bb11:
  %t34 = load ptr, ptr %l28, !tbaa !29
  %t35 = load %"compiler/source:Span", ptr %l29
  %t36 = load i32, ptr %l32, !tbaa !23
  %t37 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t34, %"compiler/source:Span" %t35, i32 %t36, i64 0)
  store ptr %t37, ptr %l35
  br label %bb12
bb12:
  %t38 = load ptr, ptr %l35, !tbaa !29
  store ptr %t38, ptr %rv
  br label %ret
bb13:
  %t39 = load i32, ptr %l8, !tbaa !23
  %t40 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t43 = icmp eq i32 %t39, %t40
  br i1 %t43, label %bb14, label %bb15
bb14:
  %t45 = load i32, ptr %l9, !tbaa !23
  %t46 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t49 = icmp eq i32 %t45, %t46
  store i1 %t49, ptr %l39, !tbaa !21
  br label %bb16
bb15:
  store i1 false, ptr %l39, !tbaa !21
  br label %bb16
bb16:
  %t51 = load i1, ptr %l39, !tbaa !21
  br i1 %t51, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s2
  %t52 = load i32, ptr %l3
  %t54 = trunc i64 73 to i32
  %t55 = icmp eq i32 %t52, %t54
  br i1 %t55, label %bb19, label %bb20
bb18:
  br label %bb35
bb19:
  store i1 true, ptr %l45, !tbaa !21
  br label %bb21
bb20:
  %t57 = load i32, ptr %l3
  %t59 = trunc i64 75 to i32
  %t60 = icmp eq i32 %t57, %t59
  store i1 %t60, ptr %l45, !tbaa !21
  br label %bb21
bb21:
  %t62 = load i1, ptr %l45, !tbaa !21
  br i1 %t62, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l48, !tbaa !21
  br label %bb24
bb23:
  %t63 = load i32, ptr %l3
  %t65 = trunc i64 47 to i32
  %t66 = icmp eq i32 %t63, %t65
  store i1 %t66, ptr %l48, !tbaa !21
  br label %bb24
bb24:
  %t68 = load i1, ptr %l48, !tbaa !21
  br i1 %t68, label %bb25, label %bb26
bb25:
  %t69 = load ptr, ptr %l0, !tbaa !29
  store ptr %t69, ptr %l51, !tbaa !29
  %t70 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t70, ptr %l52
  %t71 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t71, ptr %l53, !tbaa !23
  %t72 = load i32, ptr %l3
  %t74 = call i32 @compiler_2fcheck_2ebinaryOp(i32 %t72)
  store i32 %t74, ptr %l55
  br label %bb27
bb26:
  br label %bb29
bb27:
  %t75 = load ptr, ptr %l4, !tbaa !29
  %t76 = load ptr, ptr %l5, !tbaa !29
  %t78 = load ptr, ptr %l51, !tbaa !29
  %t79 = load %"compiler/source:Span", ptr %l52
  %t80 = load i32, ptr %l53, !tbaa !23
  %t81 = load i32, ptr %l55
  %t84 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %t78, %"compiler/source:Span" %t79, i32 %t80, i32 %t81, ptr %t75, ptr %t76)
  store ptr %t84, ptr %l59
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s2)
  %t85 = load ptr, ptr %l59, !tbaa !29
  store ptr %t85, ptr %rv
  br label %ret
bb29:
  %t86 = load ptr, ptr %l0, !tbaa !29
  store ptr %t86, ptr %l60, !tbaa !29
  %t87 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t87, ptr %l61
  %t88 = load i32, ptr %l3
  %t90 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s2, i32 %t88)
  store { i64, ptr } %t90, ptr %l63
  br label %bb30
bb30:
  %t91 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t92 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %s2, ptr %s2, { i64, ptr } %t91)
  store { i64, ptr } %t92, ptr %l64
  br label %bb31
bb31:
  %t93 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t94 = extractvalue { i64, ptr } %t93, 0
  %t95 = extractvalue { i64, ptr } %t93, 1
  %t96 = mul i64 %t94, 1
  %t97 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t96)
  call void @llvm.memcpy.p0.p0.i64(ptr %t97, ptr %t95, i64 %t96, i1 false)
  %t98 = insertvalue { i64, ptr } undef, i64 %t94, 0
  %t99 = insertvalue { i64, ptr } %t98, ptr %t97, 1
  %t101 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eOperandNotNumber(ptr %s2, ptr %s2, ptr %s2, { i64, ptr } %t99, { i64, ptr } { i64 4, ptr @.d15 })
  store %"compiler/msgs:Msg" %t101, ptr %l66
  br label %bb32
bb32:
  %t102 = load ptr, ptr %l60, !tbaa !29
  %t103 = load %"compiler/source:Span", ptr %l61
  %t104 = load %"compiler/msgs:Msg", ptr %l66
  %t105 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s2, ptr %t102, %"compiler/source:Span" %t103, %"compiler/msgs:Msg" %t104)
  store i64 %t105, ptr %l67
  br label %bb33
bb33:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t107 = load %"compiler/source:Span", ptr %l1
  %t110 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t106, %"compiler/source:Span" %t107)
  store ptr %t110, ptr %l70
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s2)
  %t111 = load ptr, ptr %l70, !tbaa !29
  store ptr %t111, ptr %rv
  br label %ret
bb35:
  %t112 = load i32, ptr %l3
  %t114 = trunc i64 47 to i32
  %t115 = icmp eq i32 %t112, %t114
  br i1 %t115, label %bb36, label %bb37
bb36:
  store %olang.scope zeroinitializer, ptr %s4
  %t117 = load ptr, ptr %l0, !tbaa !29
  store ptr %t117, ptr %l73, !tbaa !29
  %t118 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t118, ptr %l74
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t120 = load i32, ptr %l8, !tbaa !23
  %t123 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s4, ptr %t119, i32 %t120)
  store { i64, ptr } %t123, ptr %l77
  br label %bb38
bb37:
  br label %bb42
bb38:
  %t124 = load { i64, ptr }, ptr %l77, !tbaa !27
  %t125 = extractvalue { i64, ptr } %t124, 0
  %t126 = extractvalue { i64, ptr } %t124, 1
  %t127 = mul i64 %t125, 1
  %t128 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t127)
  call void @llvm.memcpy.p0.p0.i64(ptr %t128, ptr %t126, i64 %t127, i1 false)
  %t129 = insertvalue { i64, ptr } undef, i64 %t125, 0
  %t130 = insertvalue { i64, ptr } %t129, ptr %t128, 1
  %t132 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eOperandNotBool(ptr %s4, ptr %s4, ptr %s4, { i64, ptr } { i64 5, ptr @.d16 }, { i64, ptr } %t130)
  store %"compiler/msgs:Msg" %t132, ptr %l79
  br label %bb39
bb39:
  %t133 = load ptr, ptr %l73, !tbaa !29
  %t134 = load %"compiler/source:Span", ptr %l74
  %t135 = load %"compiler/msgs:Msg", ptr %l79
  %t136 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s4, ptr %t133, %"compiler/source:Span" %t134, %"compiler/msgs:Msg" %t135)
  store i64 %t136, ptr %l80
  br label %bb40
bb40:
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t138 = load %"compiler/source:Span", ptr %l1
  %t141 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t137, %"compiler/source:Span" %t138)
  store ptr %t141, ptr %l83
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s4)
  %t142 = load ptr, ptr %l83, !tbaa !29
  store ptr %t142, ptr %rv
  br label %ret
bb42:
  %t143 = load i32, ptr %l3
  %t145 = trunc i64 73 to i32
  %t146 = icmp eq i32 %t143, %t145
  %t148 = xor i1 %t146, true
  br i1 %t148, label %bb43, label %bb44
bb43:
  %t150 = load i32, ptr %l3
  %t152 = trunc i64 75 to i32
  %t153 = icmp eq i32 %t150, %t152
  %t155 = xor i1 %t153, true
  store i1 %t155, ptr %l87, !tbaa !21
  br label %bb45
bb44:
  store i1 false, ptr %l87, !tbaa !21
  br label %bb45
bb45:
  %t157 = load i1, ptr %l87, !tbaa !21
  br i1 %t157, label %bb46, label %bb47
bb46:
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t159 = load %"compiler/source:Span", ptr %l1
  %t160 = load %"compiler/source:Span", ptr %l2
  %t161 = load i32, ptr %l3
  %t162 = load ptr, ptr %l4, !tbaa !29
  %t163 = load ptr, ptr %l5, !tbaa !29
  %t170 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoperatorCall(ptr %v0, ptr %t158, %"compiler/source:Span" %t159, %"compiler/source:Span" %t160, i32 %t161, ptr %t162, ptr %t163)
  store ptr %t170, ptr %l97
  br label %bb48
bb47:
  br label %bb52
bb48:
  %t171 = load ptr, ptr %l97, !tbaa !29
  store ptr %t171, ptr %l10, !tbaa !29
  %t172 = load ptr, ptr %l10, !tbaa !29
  %t174 = icmp eq ptr %t172, null
  %t176 = xor i1 %t174, true
  br i1 %t176, label %bb49, label %bb50
bb49:
  %t178 = load ptr, ptr %l10, !tbaa !29
  store ptr %t178, ptr %rv
  br label %ret
bb50:
  br label %bb51
bb51:
  br label %bb52
bb52:
  %t180 = load i32, ptr %l3
  %t182 = trunc i64 54 to i32
  %t183 = icmp eq i32 %t180, %t182
  br i1 %t183, label %bb53, label %bb54
bb53:
  store %olang.scope zeroinitializer, ptr %s7
  %t185 = load ptr, ptr %l0, !tbaa !29
  store ptr %t185, ptr %l104, !tbaa !29
  %t186 = load ptr, ptr %l0, !tbaa !29
  %t187 = load i32, ptr %l8, !tbaa !23
  %t190 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t186, i32 %t187)
  store i32 %t190, ptr %l107
  br label %bb55
bb54:
  br label %bb64
bb55:
  %t191 = load %"compiler/source:Span", ptr %l2
  %t192 = load ptr, ptr %l104, !tbaa !29
  %t193 = load i32, ptr %l107, !tbaa !23
  %t195 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotOperator(ptr %v0, ptr %s7, ptr %s7, ptr %t192, i32 %t193, { i64, ptr } { i64 6, ptr @.d17 }, %"compiler/source:Span" %t191, { i64, ptr } { i64 3, ptr @.d18 }, i64 1, i1 false)
  store i1 %t195, ptr %l109
  br label %bb56
bb56:
  %t196 = load i1, ptr %l109, !tbaa !21
  %t197 = xor i1 %t196, true
  br i1 %t197, label %bb57, label %bb58
bb57:
  store %olang.scope zeroinitializer, ptr %s8
  %t199 = load ptr, ptr %l0, !tbaa !29
  store ptr %t199, ptr %l111, !tbaa !29
  %t200 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t200, ptr %l112
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t202 = load i32, ptr %l8, !tbaa !23
  %t205 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s8, ptr %t201, i32 %t202)
  store { i64, ptr } %t205, ptr %l115
  br label %bb59
bb58:
  br label %bb62
bb59:
  %t206 = load { i64, ptr }, ptr %l115, !tbaa !27
  %t207 = extractvalue { i64, ptr } %t206, 0
  %t208 = extractvalue { i64, ptr } %t206, 1
  %t209 = mul i64 %t207, 1
  %t210 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t209)
  call void @llvm.memcpy.p0.p0.i64(ptr %t210, ptr %t208, i64 %t209, i1 false)
  %t211 = insertvalue { i64, ptr } undef, i64 %t207, 0
  %t212 = insertvalue { i64, ptr } %t211, ptr %t210, 1
  %t214 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eMatmulUndeclared(ptr %s8, ptr %s8, { i64, ptr } %t212)
  store %"compiler/msgs:Msg" %t214, ptr %l117
  br label %bb60
bb60:
  %t215 = load ptr, ptr %l111, !tbaa !29
  %t216 = load %"compiler/source:Span", ptr %l112
  %t217 = load %"compiler/msgs:Msg", ptr %l117
  %t218 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s8, ptr %t215, %"compiler/source:Span" %t216, %"compiler/msgs:Msg" %t217)
  store i64 %t218, ptr %l118
  br label %bb61
bb61:
  call void @__olang_scope_close(ptr %s8)
  br label %bb62
bb62:
  %t219 = load ptr, ptr %l0, !tbaa !29
  %t220 = load %"compiler/source:Span", ptr %l1
  %t223 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t219, %"compiler/source:Span" %t220)
  store ptr %t223, ptr %l121
  br label %bb63
bb63:
  call void @__olang_scope_close(ptr %s7)
  %t224 = load ptr, ptr %l121, !tbaa !29
  store ptr %t224, ptr %rv
  br label %ret
bb64:
  %t225 = load i32, ptr %l3
  %t227 = trunc i64 73 to i32
  %t228 = icmp eq i32 %t225, %t227
  br i1 %t228, label %bb65, label %bb66
bb65:
  store i1 true, ptr %l124, !tbaa !21
  br label %bb67
bb66:
  %t230 = load i32, ptr %l3
  %t232 = trunc i64 75 to i32
  %t233 = icmp eq i32 %t230, %t232
  store i1 %t233, ptr %l124, !tbaa !21
  br label %bb67
bb67:
  %t235 = load i1, ptr %l124, !tbaa !21
  br i1 %t235, label %bb68, label %bb69
bb68:
  %t236 = load ptr, ptr %l0, !tbaa !29
  %t237 = load i32, ptr %l8, !tbaa !23
  %t240 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t236, i32 %t237)
  store i1 %t240, ptr %l130
  br label %bb70
bb69:
  store i1 false, ptr %l127, !tbaa !21
  br label %bb71
bb70:
  %t241 = load i1, ptr %l130, !tbaa !21
  store i1 %t241, ptr %l127, !tbaa !21
  br label %bb71
bb71:
  %t242 = load i1, ptr %l127, !tbaa !21
  br i1 %t242, label %bb72, label %bb73
bb72:
  %t243 = load ptr, ptr %l0, !tbaa !29
  %t245 = getelementptr %"compiler/check:Checker", ptr %t243, i32 0, i32 1
  %t246 = load ptr, ptr %t245, !tbaa !29
  %t248 = getelementptr %"compiler/generic:Program", ptr %t246, i32 0, i32 2
  %t249 = load i32, ptr %l8, !tbaa !23
  %t250 = load i32, ptr %l9, !tbaa !23
  %t254 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t248, i32 %t249, i32 %t250)
  store i1 %t254, ptr %l137
  br label %bb74
bb73:
  store i1 false, ptr %l131, !tbaa !21
  br label %bb75
bb74:
  %t255 = load i1, ptr %l137, !tbaa !21
  store i1 %t255, ptr %l131, !tbaa !21
  br label %bb75
bb75:
  %t256 = load i1, ptr %l131, !tbaa !21
  br i1 %t256, label %bb76, label %bb77
bb76:
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t258 = load i32, ptr %l8, !tbaa !23
  %t261 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeqMethod(ptr %v0, ptr %t257, i32 %t258)
  store i64 %t261, ptr %l141
  br label %bb78
bb77:
  store i1 false, ptr %l138, !tbaa !21
  br label %bb79
bb78:
  %t262 = load i64, ptr %l141, !tbaa !24
  %t263 = icmp ne i64 %t262, -1
  store i1 %t263, ptr %l138, !tbaa !21
  br label %bb79
bb79:
  %t265 = load i1, ptr %l138, !tbaa !21
  store i1 %t265, ptr %l11, !tbaa !21
  %t266 = load ptr, ptr %l0, !tbaa !29
  %t267 = load i32, ptr %l8, !tbaa !23
  %t270 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t266, i32 %t267)
  store i1 %t270, ptr %l145
  br label %bb80
bb80:
  %t271 = load i1, ptr %l145, !tbaa !21
  %t272 = xor i1 %t271, true
  br i1 %t272, label %bb81, label %bb82
bb81:
  store i1 true, ptr %l147, !tbaa !21
  br label %bb84
bb82:
  %t274 = load ptr, ptr %l0, !tbaa !29
  %t275 = load i32, ptr %l9, !tbaa !23
  %t278 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t274, i32 %t275)
  store i1 %t278, ptr %l150
  br label %bb83
bb83:
  %t279 = load i1, ptr %l150, !tbaa !21
  %t280 = xor i1 %t279, true
  store i1 %t280, ptr %l147, !tbaa !21
  br label %bb84
bb84:
  %t282 = load i1, ptr %l147, !tbaa !21
  br i1 %t282, label %bb85, label %bb86
bb85:
  store i1 true, ptr %l152, !tbaa !21
  br label %bb87
bb86:
  %t283 = load i1, ptr %l11, !tbaa !21
  store i1 %t283, ptr %l152, !tbaa !21
  br label %bb87
bb87:
  %t285 = load i1, ptr %l152, !tbaa !21
  br i1 %t285, label %bb88, label %bb89
bb88:
  store %olang.scope zeroinitializer, ptr %s9
  %t286 = load i32, ptr %l3
  %t288 = trunc i64 73 to i32
  %t289 = icmp eq i32 %t286, %t288
  br i1 %t289, label %bb90, label %bb91
bb89:
  br label %bb131
bb90:
  store i1 true, ptr %l156, !tbaa !21
  br label %bb92
bb91:
  %t291 = load i32, ptr %l3
  %t293 = trunc i64 75 to i32
  %t294 = icmp eq i32 %t291, %t293
  store i1 %t294, ptr %l156, !tbaa !21
  br label %bb92
bb92:
  %t296 = load i1, ptr %l156, !tbaa !21
  br i1 %t296, label %bb93, label %bb94
bb93:
  %t297 = load ptr, ptr %l0, !tbaa !29
  %t299 = getelementptr %"compiler/check:Checker", ptr %t297, i32 0, i32 37
  %t300 = load %"compiler/source:Span", ptr %t299
  store %"compiler/source:Span" %t300, ptr %l12
  %t302 = load ptr, ptr %l0, !tbaa !29
  %t303 = load %"compiler/source:Span", ptr %l2
  %t306 = getelementptr %"compiler/check:Checker", ptr %t302, i32 0, i32 37
  store %"compiler/source:Span" %t303, ptr %t306
  %t307 = load ptr, ptr %l0, !tbaa !29
  %t308 = load %"compiler/source:Span", ptr %l1
  %t309 = load i32, ptr %l3
  %t310 = load ptr, ptr %l4, !tbaa !29
  %t311 = load ptr, ptr %l5, !tbaa !29
  %t317 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eequality(ptr %v0, ptr %t307, %"compiler/source:Span" %t308, i32 %t309, ptr %t310, ptr %t311)
  store ptr %t317, ptr %l168
  br label %bb95
bb94:
  br label %bb96
bb95:
  %t318 = load ptr, ptr %l168, !tbaa !29
  %t319 = load ptr, ptr %l0, !tbaa !29
  %t320 = load %"compiler/source:Span", ptr %l12
  %t323 = getelementptr %"compiler/check:Checker", ptr %t319, i32 0, i32 37
  store %"compiler/source:Span" %t320, ptr %t323
  call void @__olang_scope_close(ptr %s9)
  store ptr %t318, ptr %rv
  br label %ret
bb96:
  %t326 = load i32, ptr %l3
  %t328 = call { i64, ptr } @compiler_2fcheck_2eoperatorName(ptr %s9, i32 %t326)
  store { i64, ptr } %t328, ptr %l173
  br label %bb97
bb97:
  %t329 = load { i64, ptr }, ptr %l173, !tbaa !27
  %t330 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s9, ptr %s9, { i64, ptr } %t329, { i64, ptr } { i64 0, ptr @.d19 })
  store i1 %t330, ptr %l174
  br label %bb98
bb98:
  %t331 = load i1, ptr %l174, !tbaa !21
  %t332 = xor i1 %t331, true
  br i1 %t332, label %bb99, label %bb100
bb99:
  %t334 = load ptr, ptr %l0, !tbaa !29
  store ptr %t334, ptr %l177, !tbaa !29
  %t335 = load ptr, ptr %l0, !tbaa !29
  %t336 = load i32, ptr %l8, !tbaa !23
  %t339 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t335, i32 %t336)
  store i32 %t339, ptr %l180
  br label %bb101
bb100:
  store i1 false, ptr %l176, !tbaa !21
  br label %bb106
bb101:
  %t340 = load i32, ptr %l3
  %t342 = call { i64, ptr } @compiler_2fcheck_2eoperatorName(ptr %s9, i32 %t340)
  store { i64, ptr } %t342, ptr %l182
  br label %bb102
bb102:
  %t343 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t343, ptr %l183
  %t344 = load i32, ptr %l3
  %t346 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s9, i32 %t344)
  store { i64, ptr } %t346, ptr %l185
  br label %bb103
bb103:
  %t347 = load { i64, ptr }, ptr %l185, !tbaa !27
  %t348 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %s9, ptr %s9, { i64, ptr } %t347)
  store { i64, ptr } %t348, ptr %l186
  br label %bb104
bb104:
  %t349 = load { i64, ptr }, ptr %l186, !tbaa !27
  %t350 = extractvalue { i64, ptr } %t349, 0
  %t351 = extractvalue { i64, ptr } %t349, 1
  %t352 = mul i64 %t350, 1
  %t353 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t352)
  call void @llvm.memcpy.p0.p0.i64(ptr %t353, ptr %t351, i64 %t352, i1 false)
  %t354 = insertvalue { i64, ptr } undef, i64 %t350, 0
  %t355 = insertvalue { i64, ptr } %t354, ptr %t353, 1
  %t356 = load ptr, ptr %l177, !tbaa !29
  %t357 = load i32, ptr %l180, !tbaa !23
  %t358 = load { i64, ptr }, ptr %l182, !tbaa !27
  %t359 = load %"compiler/source:Span", ptr %l183
  %t361 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotOperator(ptr %v0, ptr %s9, ptr %s9, ptr %t356, i32 %t357, { i64, ptr } %t358, %"compiler/source:Span" %t359, { i64, ptr } %t355, i64 1, i1 false)
  store i1 %t361, ptr %l188
  br label %bb105
bb105:
  %t362 = load i1, ptr %l188, !tbaa !21
  store i1 %t362, ptr %l176, !tbaa !21
  br label %bb106
bb106:
  %t363 = load i1, ptr %l176, !tbaa !21
  br i1 %t363, label %bb107, label %bb108
bb107:
  %t364 = load ptr, ptr %l0, !tbaa !29
  %t365 = load %"compiler/source:Span", ptr %l1
  %t368 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t364, %"compiler/source:Span" %t365)
  store ptr %t368, ptr %l191
  br label %bb109
bb108:
  br label %bb110
bb109:
  call void @__olang_scope_close(ptr %s9)
  %t369 = load ptr, ptr %l191, !tbaa !29
  store ptr %t369, ptr %rv
  br label %ret
bb110:
  %t370 = load ptr, ptr %l0, !tbaa !29
  %t371 = load i32, ptr %l8, !tbaa !23
  %t374 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t370, i32 %t371)
  store i1 %t374, ptr %l194
  br label %bb111
bb111:
  %t375 = load i1, ptr %l194, !tbaa !21
  br i1 %t375, label %bb112, label %bb113
bb112:
  store i1 true, ptr %l195, !tbaa !21
  br label %bb115
bb113:
  %t376 = load ptr, ptr %l0, !tbaa !29
  %t377 = load i32, ptr %l9, !tbaa !23
  %t380 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t376, i32 %t377)
  store i1 %t380, ptr %l198
  br label %bb114
bb114:
  %t381 = load i1, ptr %l198, !tbaa !21
  store i1 %t381, ptr %l195, !tbaa !21
  br label %bb115
bb115:
  %t382 = load i1, ptr %l195, !tbaa !21
  br i1 %t382, label %bb116, label %bb117
bb116:
  store %olang.scope zeroinitializer, ptr %s12
  %t383 = load ptr, ptr %l0, !tbaa !29
  store ptr %t383, ptr %l199, !tbaa !29
  %t384 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t384, ptr %l200
  %t385 = load i32, ptr %l3
  %t387 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s12, i32 %t385)
  store { i64, ptr } %t387, ptr %l202
  br label %bb118
bb117:
  store %olang.scope zeroinitializer, ptr %s13
  %t388 = load ptr, ptr %l0, !tbaa !29
  store ptr %t388, ptr %l215, !tbaa !29
  %t389 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t389, ptr %l216
  %t390 = load i32, ptr %l3
  %t392 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s13, i32 %t390)
  store { i64, ptr } %t392, ptr %l218
  br label %bb124
bb118:
  %t393 = load { i64, ptr }, ptr %l202, !tbaa !27
  %t394 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %s12, ptr %s12, { i64, ptr } %t393)
  store { i64, ptr } %t394, ptr %l203
  br label %bb119
bb119:
  %t395 = load { i64, ptr }, ptr %l203, !tbaa !27
  %t396 = extractvalue { i64, ptr } %t395, 0
  %t397 = extractvalue { i64, ptr } %t395, 1
  %t398 = mul i64 %t396, 1
  %t399 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t398)
  call void @llvm.memcpy.p0.p0.i64(ptr %t399, ptr %t397, i64 %t398, i1 false)
  %t400 = insertvalue { i64, ptr } undef, i64 %t396, 0
  %t401 = insertvalue { i64, ptr } %t400, ptr %t399, 1
  store { i64, ptr } %t401, ptr %l204, !tbaa !27
  %t402 = load ptr, ptr %l0, !tbaa !29
  %t403 = load i32, ptr %l8, !tbaa !23
  %t406 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s12, ptr %t402, i32 %t403)
  store { i64, ptr } %t406, ptr %l207
  br label %bb120
bb120:
  %t407 = load { i64, ptr }, ptr %l207, !tbaa !27
  %t408 = extractvalue { i64, ptr } %t407, 0
  %t409 = extractvalue { i64, ptr } %t407, 1
  %t410 = mul i64 %t408, 1
  %t411 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t410)
  call void @llvm.memcpy.p0.p0.i64(ptr %t411, ptr %t409, i64 %t410, i1 false)
  %t412 = insertvalue { i64, ptr } undef, i64 %t408, 0
  %t413 = insertvalue { i64, ptr } %t412, ptr %t411, 1
  store { i64, ptr } %t413, ptr %l208, !tbaa !27
  %t414 = load ptr, ptr %l0, !tbaa !29
  %t415 = load i32, ptr %l9, !tbaa !23
  %t418 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s12, ptr %t414, i32 %t415)
  store { i64, ptr } %t418, ptr %l211
  br label %bb121
bb121:
  %t419 = load { i64, ptr }, ptr %l211, !tbaa !27
  %t420 = extractvalue { i64, ptr } %t419, 0
  %t421 = extractvalue { i64, ptr } %t419, 1
  %t422 = mul i64 %t420, 1
  %t423 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t422)
  call void @llvm.memcpy.p0.p0.i64(ptr %t423, ptr %t421, i64 %t422, i1 false)
  %t424 = insertvalue { i64, ptr } undef, i64 %t420, 0
  %t425 = insertvalue { i64, ptr } %t424, ptr %t423, 1
  %t426 = load { i64, ptr }, ptr %l204, !tbaa !27
  %t427 = load { i64, ptr }, ptr %l208, !tbaa !27
  %t429 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eOperandsDiffer(ptr %s12, ptr %s12, ptr %s12, ptr %s12, { i64, ptr } %t426, { i64, ptr } %t427, { i64, ptr } %t425)
  store %"compiler/msgs:Msg" %t429, ptr %l213
  br label %bb122
bb122:
  %t430 = load ptr, ptr %l199, !tbaa !29
  %t431 = load %"compiler/source:Span", ptr %l200
  %t432 = load %"compiler/msgs:Msg", ptr %l213
  %t433 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s12, ptr %t430, %"compiler/source:Span" %t431, %"compiler/msgs:Msg" %t432)
  store i64 %t433, ptr %l214
  br label %bb123
bb123:
  call void @__olang_scope_close(ptr %s12)
  br label %bb129
bb124:
  %t434 = load { i64, ptr }, ptr %l218, !tbaa !27
  %t435 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %s13, ptr %s13, { i64, ptr } %t434)
  store { i64, ptr } %t435, ptr %l219
  br label %bb125
bb125:
  %t436 = load { i64, ptr }, ptr %l219, !tbaa !27
  %t437 = extractvalue { i64, ptr } %t436, 0
  %t438 = extractvalue { i64, ptr } %t436, 1
  %t439 = mul i64 %t437, 1
  %t440 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t439)
  call void @llvm.memcpy.p0.p0.i64(ptr %t440, ptr %t438, i64 %t439, i1 false)
  %t441 = insertvalue { i64, ptr } undef, i64 %t437, 0
  %t442 = insertvalue { i64, ptr } %t441, ptr %t440, 1
  store { i64, ptr } %t442, ptr %l220, !tbaa !27
  %t443 = load ptr, ptr %l0, !tbaa !29
  %t444 = load i32, ptr %l8, !tbaa !23
  %t447 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s13, ptr %t443, i32 %t444)
  store { i64, ptr } %t447, ptr %l223
  br label %bb126
bb126:
  %t448 = load { i64, ptr }, ptr %l223, !tbaa !27
  %t449 = extractvalue { i64, ptr } %t448, 0
  %t450 = extractvalue { i64, ptr } %t448, 1
  %t451 = mul i64 %t449, 1
  %t452 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t451)
  call void @llvm.memcpy.p0.p0.i64(ptr %t452, ptr %t450, i64 %t451, i1 false)
  %t453 = insertvalue { i64, ptr } undef, i64 %t449, 0
  %t454 = insertvalue { i64, ptr } %t453, ptr %t452, 1
  %t455 = load { i64, ptr }, ptr %l220, !tbaa !27
  %t457 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eOperandNotNumber(ptr %s13, ptr %s13, ptr %s13, { i64, ptr } %t455, { i64, ptr } %t454)
  store %"compiler/msgs:Msg" %t457, ptr %l225
  br label %bb127
bb127:
  %t458 = load ptr, ptr %l215, !tbaa !29
  %t459 = load %"compiler/source:Span", ptr %l216
  %t460 = load %"compiler/msgs:Msg", ptr %l225
  %t461 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s13, ptr %t458, %"compiler/source:Span" %t459, %"compiler/msgs:Msg" %t460)
  store i64 %t461, ptr %l226
  br label %bb128
bb128:
  call void @__olang_scope_close(ptr %s13)
  br label %bb129
bb129:
  %t462 = load ptr, ptr %l0, !tbaa !29
  %t463 = load %"compiler/source:Span", ptr %l1
  %t466 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t462, %"compiler/source:Span" %t463)
  store ptr %t466, ptr %l229
  br label %bb130
bb130:
  call void @__olang_scope_close(ptr %s9)
  %t467 = load ptr, ptr %l229, !tbaa !29
  store ptr %t467, ptr %rv
  br label %ret
bb131:
  %t468 = load i32, ptr %l3
  %t470 = trunc i64 86 to i32
  %t471 = icmp eq i32 %t468, %t470
  br i1 %t471, label %bb132, label %bb133
bb132:
  store i1 true, ptr %l232, !tbaa !21
  br label %bb134
bb133:
  %t473 = load i32, ptr %l3
  %t475 = trunc i64 87 to i32
  %t476 = icmp eq i32 %t473, %t475
  store i1 %t476, ptr %l232, !tbaa !21
  br label %bb134
bb134:
  %t478 = load i1, ptr %l232, !tbaa !21
  br i1 %t478, label %bb135, label %bb136
bb135:
  %t479 = load ptr, ptr %l0, !tbaa !29
  %t480 = load i32, ptr %l8, !tbaa !23
  %t483 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisInt(ptr %v0, ptr %t479, i32 %t480)
  store i1 %t483, ptr %l237
  br label %bb137
bb136:
  br label %bb176
bb137:
  %t484 = load i1, ptr %l237, !tbaa !21
  %t485 = xor i1 %t484, true
  br i1 %t485, label %bb138, label %bb139
bb138:
  store %olang.scope zeroinitializer, ptr %s15
  %t487 = load ptr, ptr %l0, !tbaa !29
  store ptr %t487, ptr %l239, !tbaa !29
  %t488 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t488, ptr %l240
  %t489 = load i32, ptr %l3
  %t491 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s15, i32 %t489)
  store { i64, ptr } %t491, ptr %l242
  br label %bb140
bb139:
  br label %bb145
bb140:
  %t492 = load { i64, ptr }, ptr %l242, !tbaa !27
  %t493 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %s15, ptr %s15, { i64, ptr } %t492)
  store { i64, ptr } %t493, ptr %l243
  br label %bb141
bb141:
  %t494 = load { i64, ptr }, ptr %l243, !tbaa !27
  %t495 = extractvalue { i64, ptr } %t494, 0
  %t496 = extractvalue { i64, ptr } %t494, 1
  %t497 = mul i64 %t495, 1
  %t498 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t497)
  call void @llvm.memcpy.p0.p0.i64(ptr %t498, ptr %t496, i64 %t497, i1 false)
  %t499 = insertvalue { i64, ptr } undef, i64 %t495, 0
  %t500 = insertvalue { i64, ptr } %t499, ptr %t498, 1
  store { i64, ptr } %t500, ptr %l244, !tbaa !27
  %t501 = load ptr, ptr %l0, !tbaa !29
  %t502 = load i32, ptr %l8, !tbaa !23
  %t505 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s15, ptr %t501, i32 %t502)
  store { i64, ptr } %t505, ptr %l247
  br label %bb142
bb142:
  %t506 = load { i64, ptr }, ptr %l247, !tbaa !27
  %t507 = extractvalue { i64, ptr } %t506, 0
  %t508 = extractvalue { i64, ptr } %t506, 1
  %t509 = mul i64 %t507, 1
  %t510 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t509)
  call void @llvm.memcpy.p0.p0.i64(ptr %t510, ptr %t508, i64 %t509, i1 false)
  %t511 = insertvalue { i64, ptr } undef, i64 %t507, 0
  %t512 = insertvalue { i64, ptr } %t511, ptr %t510, 1
  %t513 = load { i64, ptr }, ptr %l244, !tbaa !27
  %t515 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eOperandNotInt(ptr %s15, ptr %s15, ptr %s15, { i64, ptr } %t513, { i64, ptr } %t512)
  store %"compiler/msgs:Msg" %t515, ptr %l249
  br label %bb143
bb143:
  %t516 = load ptr, ptr %l239, !tbaa !29
  %t517 = load %"compiler/source:Span", ptr %l240
  %t518 = load %"compiler/msgs:Msg", ptr %l249
  %t519 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s15, ptr %t516, %"compiler/source:Span" %t517, %"compiler/msgs:Msg" %t518)
  store i64 %t519, ptr %l250
  br label %bb144
bb144:
  call void @__olang_scope_close(ptr %s15)
  br label %bb145
bb145:
  %t520 = load ptr, ptr %l0, !tbaa !29
  %t521 = load i32, ptr %l9, !tbaa !23
  %t524 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisInt(ptr %v0, ptr %t520, i32 %t521)
  store i1 %t524, ptr %l253
  br label %bb146
bb146:
  %t525 = load i1, ptr %l253, !tbaa !21
  %t526 = xor i1 %t525, true
  br i1 %t526, label %bb147, label %bb148
bb147:
  store %olang.scope zeroinitializer, ptr %s16
  %t528 = load ptr, ptr %l0, !tbaa !29
  store ptr %t528, ptr %l255, !tbaa !29
  %t529 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t529, ptr %l256
  %t530 = load i32, ptr %l3
  %t532 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s16, i32 %t530)
  store { i64, ptr } %t532, ptr %l258
  br label %bb149
bb148:
  br label %bb154
bb149:
  %t533 = load { i64, ptr }, ptr %l258, !tbaa !27
  %t534 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %s16, ptr %s16, { i64, ptr } %t533)
  store { i64, ptr } %t534, ptr %l259
  br label %bb150
bb150:
  %t535 = load { i64, ptr }, ptr %l259, !tbaa !27
  %t536 = extractvalue { i64, ptr } %t535, 0
  %t537 = extractvalue { i64, ptr } %t535, 1
  %t538 = mul i64 %t536, 1
  %t539 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t538)
  call void @llvm.memcpy.p0.p0.i64(ptr %t539, ptr %t537, i64 %t538, i1 false)
  %t540 = insertvalue { i64, ptr } undef, i64 %t536, 0
  %t541 = insertvalue { i64, ptr } %t540, ptr %t539, 1
  store { i64, ptr } %t541, ptr %l260, !tbaa !27
  %t542 = load ptr, ptr %l0, !tbaa !29
  %t543 = load i32, ptr %l9, !tbaa !23
  %t546 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s16, ptr %t542, i32 %t543)
  store { i64, ptr } %t546, ptr %l263
  br label %bb151
bb151:
  %t547 = load { i64, ptr }, ptr %l263, !tbaa !27
  %t548 = extractvalue { i64, ptr } %t547, 0
  %t549 = extractvalue { i64, ptr } %t547, 1
  %t550 = mul i64 %t548, 1
  %t551 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t550)
  call void @llvm.memcpy.p0.p0.i64(ptr %t551, ptr %t549, i64 %t550, i1 false)
  %t552 = insertvalue { i64, ptr } undef, i64 %t548, 0
  %t553 = insertvalue { i64, ptr } %t552, ptr %t551, 1
  %t554 = load { i64, ptr }, ptr %l260, !tbaa !27
  %t556 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eOperandNotInt(ptr %s16, ptr %s16, ptr %s16, { i64, ptr } %t554, { i64, ptr } %t553)
  store %"compiler/msgs:Msg" %t556, ptr %l265
  br label %bb152
bb152:
  %t557 = load ptr, ptr %l255, !tbaa !29
  %t558 = load %"compiler/source:Span", ptr %l256
  %t559 = load %"compiler/msgs:Msg", ptr %l265
  %t560 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s16, ptr %t557, %"compiler/source:Span" %t558, %"compiler/msgs:Msg" %t559)
  store i64 %t560, ptr %l266
  br label %bb153
bb153:
  call void @__olang_scope_close(ptr %s16)
  br label %bb154
bb154:
  %t561 = load i32, ptr %l3
  %t563 = call i1 @compiler_2fcheck_2ecompares(i32 %t561)
  store i1 %t563, ptr %l268
  br label %bb155
bb155:
  %t564 = load i1, ptr %l268, !tbaa !21
  %t565 = xor i1 %t564, true
  br i1 %t565, label %bb156, label %bb157
bb156:
  %t567 = load ptr, ptr %l0, !tbaa !29
  %t568 = load i32, ptr %l8, !tbaa !23
  %t571 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t567, i32 %t568)
  store i1 %t571, ptr %l273
  br label %bb158
bb157:
  store i1 false, ptr %l270, !tbaa !21
  br label %bb159
bb158:
  %t572 = load i1, ptr %l273, !tbaa !21
  store i1 %t572, ptr %l270, !tbaa !21
  br label %bb159
bb159:
  %t573 = load i1, ptr %l270, !tbaa !21
  br i1 %t573, label %bb160, label %bb161
bb160:
  %t574 = load ptr, ptr %l0, !tbaa !29
  %t576 = getelementptr %"compiler/check:Checker", ptr %t574, i32 0, i32 1
  %t577 = load ptr, ptr %t576, !tbaa !29
  %t578 = load i32, ptr %l8, !tbaa !23
  %t581 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eExtends(ptr %v0, ptr %t577, i32 %t578)
  store i1 %t581, ptr %l278
  br label %bb162
bb161:
  store i1 false, ptr %l274, !tbaa !21
  br label %bb163
bb162:
  %t582 = load i1, ptr %l278, !tbaa !21
  %t583 = xor i1 %t582, true
  store i1 %t583, ptr %l274, !tbaa !21
  br label %bb163
bb163:
  %t585 = load i1, ptr %l274, !tbaa !21
  br i1 %t585, label %bb164, label %bb165
bb164:
  store %olang.scope zeroinitializer, ptr %s17
  %t586 = load ptr, ptr %l0, !tbaa !29
  store ptr %t586, ptr %l280, !tbaa !29
  %t587 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t587, ptr %l281
  %t588 = load ptr, ptr %l0, !tbaa !29
  %t589 = load i32, ptr %l8, !tbaa !23
  %t592 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s17, ptr %t588, i32 %t589)
  store { i64, ptr } %t592, ptr %l284
  br label %bb166
bb165:
  br label %bb173
bb166:
  %t593 = load { i64, ptr }, ptr %l284, !tbaa !27
  %t594 = extractvalue { i64, ptr } %t593, 0
  %t595 = extractvalue { i64, ptr } %t593, 1
  %t596 = mul i64 %t594, 1
  %t597 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t596)
  call void @llvm.memcpy.p0.p0.i64(ptr %t597, ptr %t595, i64 %t596, i1 false)
  %t598 = insertvalue { i64, ptr } undef, i64 %t594, 0
  %t599 = insertvalue { i64, ptr } %t598, ptr %t597, 1
  store { i64, ptr } %t599, ptr %l285, !tbaa !27
  %t600 = load i32, ptr %l3
  %t602 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s17, i32 %t600)
  store { i64, ptr } %t602, ptr %l287
  br label %bb167
bb167:
  %t603 = load { i64, ptr }, ptr %l287, !tbaa !27
  %t604 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %s17, ptr %s17, { i64, ptr } %t603)
  store { i64, ptr } %t604, ptr %l288
  br label %bb168
bb168:
  %t605 = load { i64, ptr }, ptr %l288, !tbaa !27
  %t606 = extractvalue { i64, ptr } %t605, 0
  %t607 = extractvalue { i64, ptr } %t605, 1
  %t608 = mul i64 %t606, 1
  %t609 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t608)
  call void @llvm.memcpy.p0.p0.i64(ptr %t609, ptr %t607, i64 %t608, i1 false)
  %t610 = insertvalue { i64, ptr } undef, i64 %t606, 0
  %t611 = insertvalue { i64, ptr } %t610, ptr %t609, 1
  store { i64, ptr } %t611, ptr %l289, !tbaa !27
  %t612 = load i32, ptr %l3
  %t614 = call { i64, ptr } @compiler_2fcheck_2eoperatorName(ptr %s17, i32 %t612)
  store { i64, ptr } %t614, ptr %l291
  br label %bb169
bb169:
  %t615 = extractvalue { i64, ptr } { i64 1, ptr @.d20 }, 1
  %t616 = extractvalue { i64, ptr } { i64 1, ptr @.d20 }, 0
  %t617 = load { i64, ptr }, ptr %l291, !tbaa !27
  %t618 = extractvalue { i64, ptr } %t617, 1
  %t619 = extractvalue { i64, ptr } %t617, 0
  %t620 = add i64 %t616, %t619
  %t621 = extractvalue { i64, ptr } { i64 1, ptr @.d21 }, 1
  %t622 = extractvalue { i64, ptr } { i64 1, ptr @.d21 }, 0
  %t623 = add i64 %t620, %t622
  %t624 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t623)
  call void @olang_textcopy(ptr %t624, ptr %t615, i64 %t616)
  %t625 = getelementptr i8, ptr %t624, i64 %t616
  call void @olang_textcopy(ptr %t625, ptr %t618, i64 %t619)
  %t626 = getelementptr i8, ptr %t625, i64 %t619
  call void @olang_textcopy(ptr %t626, ptr %t621, i64 %t622)
  %t627 = insertvalue { i64, ptr } undef, i64 %t623, 0
  %t628 = insertvalue { i64, ptr } %t627, ptr %t624, 1
  %t630 = extractvalue { i64, ptr } %t628, 0
  %t631 = extractvalue { i64, ptr } %t628, 1
  %t632 = mul i64 %t630, 1
  %t633 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t632)
  call void @llvm.memcpy.p0.p0.i64(ptr %t633, ptr %t631, i64 %t632, i1 false)
  %t634 = insertvalue { i64, ptr } undef, i64 %t630, 0
  %t635 = insertvalue { i64, ptr } %t634, ptr %t633, 1
  %t636 = load { i64, ptr }, ptr %l285, !tbaa !27
  %t637 = load { i64, ptr }, ptr %l289, !tbaa !27
  %t639 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotExtendedOp(ptr %s17, ptr %s17, ptr %s17, ptr %s17, { i64, ptr } %t636, { i64, ptr } %t637, { i64, ptr } %t635)
  store %"compiler/msgs:Msg" %t639, ptr %l294
  br label %bb170
bb170:
  %t640 = load ptr, ptr %l280, !tbaa !29
  %t641 = load %"compiler/source:Span", ptr %l281
  %t642 = load %"compiler/msgs:Msg", ptr %l294
  %t643 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s17, ptr %t640, %"compiler/source:Span" %t641, %"compiler/msgs:Msg" %t642)
  store i64 %t643, ptr %l295
  br label %bb171
bb171:
  %t644 = load ptr, ptr %l0, !tbaa !29
  %t645 = load %"compiler/source:Span", ptr %l1
  %t648 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t644, %"compiler/source:Span" %t645)
  store ptr %t648, ptr %l298
  br label %bb172
bb172:
  call void @__olang_scope_close(ptr %s17)
  %t649 = load ptr, ptr %l298, !tbaa !29
  store ptr %t649, ptr %rv
  br label %ret
bb173:
  %t650 = load ptr, ptr %l0, !tbaa !29
  store ptr %t650, ptr %l299, !tbaa !29
  %t651 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t651, ptr %l300
  %t652 = load i32, ptr %l8, !tbaa !23
  store i32 %t652, ptr %l301, !tbaa !23
  %t653 = load i32, ptr %l3
  %t655 = call i32 @compiler_2fcheck_2ebinaryOp(i32 %t653)
  store i32 %t655, ptr %l303
  br label %bb174
bb174:
  %t656 = load ptr, ptr %l4, !tbaa !29
  %t657 = load ptr, ptr %l5, !tbaa !29
  %t658 = load ptr, ptr %l299, !tbaa !29
  %t659 = load %"compiler/source:Span", ptr %l300
  %t660 = load i32, ptr %l301, !tbaa !23
  %t661 = load i32, ptr %l303
  %t664 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echeckedPrim(ptr %v0, ptr %t658, %"compiler/source:Span" %t659, i32 %t660, i32 %t661, ptr %t656, ptr %t657)
  store ptr %t664, ptr %l306
  br label %bb175
bb175:
  %t665 = load ptr, ptr %l306, !tbaa !29
  store ptr %t665, ptr %rv
  br label %ret
bb176:
  %t666 = load i32, ptr %l8, !tbaa !23
  store i32 %t666, ptr %l14, !tbaa !23
  %t668 = load i32, ptr %l8, !tbaa !23
  %t669 = load i32, ptr %l9, !tbaa !23
  %t672 = icmp ne i32 %t668, %t669
  br i1 %t672, label %bb177, label %bb178
bb177:
  %t674 = load ptr, ptr %l0, !tbaa !29
  %t676 = getelementptr %"compiler/check:Checker", ptr %t674, i32 0, i32 1
  %t677 = load ptr, ptr %t676, !tbaa !29
  %t678 = load i32, ptr %l8, !tbaa !23
  %t679 = load i32, ptr %l9, !tbaa !23
  %t683 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMeet(ptr %v0, ptr %t677, i32 %t678, i32 %t679)
  store i32 %t683, ptr %l315
  br label %bb179
bb178:
  br label %bb196
bb179:
  %t684 = load i32, ptr %l315, !tbaa !23
  store i32 %t684, ptr %l14, !tbaa !23
  %t685 = load i32, ptr %l14, !tbaa !23
  %t687 = icmp slt i32 %t685, 0
  br i1 %t687, label %bb180, label %bb181
bb180:
  store %olang.scope zeroinitializer, ptr %s20
  %t689 = load ptr, ptr %l0, !tbaa !29
  store ptr %t689, ptr %l318, !tbaa !29
  %t690 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t690, ptr %l319
  %t691 = load ptr, ptr %l0, !tbaa !29
  %t692 = load i32, ptr %l8, !tbaa !23
  %t695 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s20, ptr %t691, i32 %t692)
  store { i64, ptr } %t695, ptr %l322
  br label %bb182
bb181:
  br label %bb187
bb182:
  %t696 = load { i64, ptr }, ptr %l322, !tbaa !27
  %t697 = extractvalue { i64, ptr } %t696, 0
  %t698 = extractvalue { i64, ptr } %t696, 1
  %t699 = mul i64 %t697, 1
  %t700 = call ptr @__olang_scope_alloc(ptr %s20, i64 %t699)
  call void @llvm.memcpy.p0.p0.i64(ptr %t700, ptr %t698, i64 %t699, i1 false)
  %t701 = insertvalue { i64, ptr } undef, i64 %t697, 0
  %t702 = insertvalue { i64, ptr } %t701, ptr %t700, 1
  store { i64, ptr } %t702, ptr %l323, !tbaa !27
  %t703 = load ptr, ptr %l0, !tbaa !29
  %t704 = load i32, ptr %l9, !tbaa !23
  %t707 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s20, ptr %t703, i32 %t704)
  store { i64, ptr } %t707, ptr %l326
  br label %bb183
bb183:
  %t708 = load { i64, ptr }, ptr %l326, !tbaa !27
  %t709 = extractvalue { i64, ptr } %t708, 0
  %t710 = extractvalue { i64, ptr } %t708, 1
  %t711 = mul i64 %t709, 1
  %t712 = call ptr @__olang_scope_alloc(ptr %s20, i64 %t711)
  call void @llvm.memcpy.p0.p0.i64(ptr %t712, ptr %t710, i64 %t711, i1 false)
  %t713 = insertvalue { i64, ptr } undef, i64 %t709, 0
  %t714 = insertvalue { i64, ptr } %t713, ptr %t712, 1
  %t715 = load { i64, ptr }, ptr %l323, !tbaa !27
  %t717 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNumbersDoNotMeet(ptr %s20, ptr %s20, ptr %s20, { i64, ptr } %t715, { i64, ptr } %t714)
  store %"compiler/msgs:Msg" %t717, ptr %l328
  br label %bb184
bb184:
  %t718 = load ptr, ptr %l318, !tbaa !29
  %t719 = load %"compiler/source:Span", ptr %l319
  %t720 = load %"compiler/msgs:Msg", ptr %l328
  %t721 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s20, ptr %t718, %"compiler/source:Span" %t719, %"compiler/msgs:Msg" %t720)
  store i64 %t721, ptr %l329
  br label %bb185
bb185:
  %t722 = load ptr, ptr %l0, !tbaa !29
  %t723 = load %"compiler/source:Span", ptr %l1
  %t726 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t722, %"compiler/source:Span" %t723)
  store ptr %t726, ptr %l332
  br label %bb186
bb186:
  call void @__olang_scope_close(ptr %s20)
  %t727 = load ptr, ptr %l332, !tbaa !29
  store ptr %t727, ptr %rv
  br label %ret
bb187:
  %t728 = load i32, ptr %l14, !tbaa !23
  %t729 = load i32, ptr %l8, !tbaa !23
  %t732 = icmp ne i32 %t728, %t729
  br i1 %t732, label %bb188, label %bb189
bb188:
  %t734 = load ptr, ptr %l0, !tbaa !29
  %t736 = load ptr, ptr %l4, !tbaa !29
  %t737 = load i32, ptr %l14, !tbaa !23
  %t742 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %t734, %"compiler/source:Span" %a6, ptr %t736, i32 %t737)
  store ptr %t742, ptr %l340
  br label %bb190
bb189:
  br label %bb191
bb190:
  %t743 = load ptr, ptr %l340, !tbaa !29
  store ptr %t743, ptr %l4, !tbaa !29
  br label %bb191
bb191:
  %t744 = load i32, ptr %l14, !tbaa !23
  %t745 = load i32, ptr %l9, !tbaa !23
  %t748 = icmp ne i32 %t744, %t745
  br i1 %t748, label %bb192, label %bb193
bb192:
  %t750 = load ptr, ptr %l0, !tbaa !29
  %t752 = load ptr, ptr %l5, !tbaa !29
  %t753 = load i32, ptr %l14, !tbaa !23
  %t758 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %t750, %"compiler/source:Span" %a7, ptr %t752, i32 %t753)
  store ptr %t758, ptr %l348
  br label %bb194
bb193:
  br label %bb195
bb194:
  %t759 = load ptr, ptr %l348, !tbaa !29
  store ptr %t759, ptr %l5, !tbaa !29
  br label %bb195
bb195:
  br label %bb196
bb196:
  %t760 = load i32, ptr %l3
  %t762 = call i1 @compiler_2fcheck_2eintOnly(i32 %t760)
  store i1 %t762, ptr %l350
  br label %bb197
bb197:
  %t763 = load i1, ptr %l350, !tbaa !21
  br i1 %t763, label %bb198, label %bb199
bb198:
  %t764 = load ptr, ptr %l0, !tbaa !29
  %t765 = load i32, ptr %l14, !tbaa !23
  %t768 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisInt(ptr %v0, ptr %t764, i32 %t765)
  store i1 %t768, ptr %l354
  br label %bb200
bb199:
  store i1 false, ptr %l351, !tbaa !21
  br label %bb201
bb200:
  %t769 = load i1, ptr %l354, !tbaa !21
  %t770 = xor i1 %t769, true
  store i1 %t770, ptr %l351, !tbaa !21
  br label %bb201
bb201:
  %t772 = load i1, ptr %l351, !tbaa !21
  br i1 %t772, label %bb202, label %bb203
bb202:
  store %olang.scope zeroinitializer, ptr %s23
  %t773 = load ptr, ptr %l0, !tbaa !29
  store ptr %t773, ptr %l356, !tbaa !29
  %t774 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t774, ptr %l357
  %t775 = load i32, ptr %l3
  %t777 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s23, i32 %t775)
  store { i64, ptr } %t777, ptr %l359
  br label %bb204
bb203:
  br label %bb210
bb204:
  %t778 = load { i64, ptr }, ptr %l359, !tbaa !27
  %t779 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %s23, ptr %s23, { i64, ptr } %t778)
  store { i64, ptr } %t779, ptr %l360
  br label %bb205
bb205:
  %t780 = load { i64, ptr }, ptr %l360, !tbaa !27
  %t781 = extractvalue { i64, ptr } %t780, 0
  %t782 = extractvalue { i64, ptr } %t780, 1
  %t783 = mul i64 %t781, 1
  %t784 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t783)
  call void @llvm.memcpy.p0.p0.i64(ptr %t784, ptr %t782, i64 %t783, i1 false)
  %t785 = insertvalue { i64, ptr } undef, i64 %t781, 0
  %t786 = insertvalue { i64, ptr } %t785, ptr %t784, 1
  store { i64, ptr } %t786, ptr %l361, !tbaa !27
  %t787 = load ptr, ptr %l0, !tbaa !29
  %t788 = load i32, ptr %l14, !tbaa !23
  %t791 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s23, ptr %t787, i32 %t788)
  store { i64, ptr } %t791, ptr %l364
  br label %bb206
bb206:
  %t792 = load { i64, ptr }, ptr %l364, !tbaa !27
  %t793 = extractvalue { i64, ptr } %t792, 0
  %t794 = extractvalue { i64, ptr } %t792, 1
  %t795 = mul i64 %t793, 1
  %t796 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t795)
  call void @llvm.memcpy.p0.p0.i64(ptr %t796, ptr %t794, i64 %t795, i1 false)
  %t797 = insertvalue { i64, ptr } undef, i64 %t793, 0
  %t798 = insertvalue { i64, ptr } %t797, ptr %t796, 1
  %t799 = load { i64, ptr }, ptr %l361, !tbaa !27
  %t801 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eOperandNotInt(ptr %s23, ptr %s23, ptr %s23, { i64, ptr } %t799, { i64, ptr } %t798)
  store %"compiler/msgs:Msg" %t801, ptr %l366
  br label %bb207
bb207:
  %t802 = load ptr, ptr %l356, !tbaa !29
  %t803 = load %"compiler/source:Span", ptr %l357
  %t804 = load %"compiler/msgs:Msg", ptr %l366
  %t805 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s23, ptr %t802, %"compiler/source:Span" %t803, %"compiler/msgs:Msg" %t804)
  store i64 %t805, ptr %l367
  br label %bb208
bb208:
  %t806 = load ptr, ptr %l0, !tbaa !29
  %t807 = load %"compiler/source:Span", ptr %l1
  %t810 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t806, %"compiler/source:Span" %t807)
  store ptr %t810, ptr %l370
  br label %bb209
bb209:
  call void @__olang_scope_close(ptr %s23)
  %t811 = load ptr, ptr %l370, !tbaa !29
  store ptr %t811, ptr %rv
  br label %ret
bb210:
  %t812 = load i32, ptr %l3
  %t814 = call i1 @compiler_2fcheck_2ecompares(i32 %t812)
  store i1 %t814, ptr %l372
  br label %bb211
bb211:
  %t815 = load i1, ptr %l372, !tbaa !21
  %t816 = xor i1 %t815, true
  br i1 %t816, label %bb212, label %bb213
bb212:
  %t818 = load ptr, ptr %l0, !tbaa !29
  %t819 = load i32, ptr %l14, !tbaa !23
  %t822 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t818, i32 %t819)
  store i1 %t822, ptr %l377
  br label %bb214
bb213:
  store i1 false, ptr %l374, !tbaa !21
  br label %bb215
bb214:
  %t823 = load i1, ptr %l377, !tbaa !21
  store i1 %t823, ptr %l374, !tbaa !21
  br label %bb215
bb215:
  %t824 = load i1, ptr %l374, !tbaa !21
  br i1 %t824, label %bb216, label %bb217
bb216:
  %t825 = load ptr, ptr %l0, !tbaa !29
  %t827 = getelementptr %"compiler/check:Checker", ptr %t825, i32 0, i32 1
  %t828 = load ptr, ptr %t827, !tbaa !29
  %t829 = load i32, ptr %l14, !tbaa !23
  %t832 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eExtends(ptr %v0, ptr %t828, i32 %t829)
  store i1 %t832, ptr %l382
  br label %bb218
bb217:
  store i1 false, ptr %l378, !tbaa !21
  br label %bb219
bb218:
  %t833 = load i1, ptr %l382, !tbaa !21
  %t834 = xor i1 %t833, true
  store i1 %t834, ptr %l378, !tbaa !21
  br label %bb219
bb219:
  %t836 = load i1, ptr %l378, !tbaa !21
  br i1 %t836, label %bb220, label %bb221
bb220:
  store %olang.scope zeroinitializer, ptr %s24
  %t837 = load ptr, ptr %l0, !tbaa !29
  store ptr %t837, ptr %l384, !tbaa !29
  %t838 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t838, ptr %l385
  %t839 = load ptr, ptr %l0, !tbaa !29
  %t840 = load i32, ptr %l14, !tbaa !23
  %t843 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s24, ptr %t839, i32 %t840)
  store { i64, ptr } %t843, ptr %l388
  br label %bb222
bb221:
  br label %bb229
bb222:
  %t844 = load { i64, ptr }, ptr %l388, !tbaa !27
  %t845 = extractvalue { i64, ptr } %t844, 0
  %t846 = extractvalue { i64, ptr } %t844, 1
  %t847 = mul i64 %t845, 1
  %t848 = call ptr @__olang_scope_alloc(ptr %s24, i64 %t847)
  call void @llvm.memcpy.p0.p0.i64(ptr %t848, ptr %t846, i64 %t847, i1 false)
  %t849 = insertvalue { i64, ptr } undef, i64 %t845, 0
  %t850 = insertvalue { i64, ptr } %t849, ptr %t848, 1
  store { i64, ptr } %t850, ptr %l389, !tbaa !27
  %t851 = load i32, ptr %l3
  %t853 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s24, i32 %t851)
  store { i64, ptr } %t853, ptr %l391
  br label %bb223
bb223:
  %t854 = load { i64, ptr }, ptr %l391, !tbaa !27
  %t855 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %s24, ptr %s24, { i64, ptr } %t854)
  store { i64, ptr } %t855, ptr %l392
  br label %bb224
bb224:
  %t856 = load { i64, ptr }, ptr %l392, !tbaa !27
  %t857 = extractvalue { i64, ptr } %t856, 0
  %t858 = extractvalue { i64, ptr } %t856, 1
  %t859 = mul i64 %t857, 1
  %t860 = call ptr @__olang_scope_alloc(ptr %s24, i64 %t859)
  call void @llvm.memcpy.p0.p0.i64(ptr %t860, ptr %t858, i64 %t859, i1 false)
  %t861 = insertvalue { i64, ptr } undef, i64 %t857, 0
  %t862 = insertvalue { i64, ptr } %t861, ptr %t860, 1
  store { i64, ptr } %t862, ptr %l393, !tbaa !27
  %t863 = load i32, ptr %l3
  %t865 = call { i64, ptr } @compiler_2fcheck_2eoperatorName(ptr %s24, i32 %t863)
  store { i64, ptr } %t865, ptr %l395
  br label %bb225
bb225:
  %t866 = extractvalue { i64, ptr } { i64 1, ptr @.d22 }, 1
  %t867 = extractvalue { i64, ptr } { i64 1, ptr @.d22 }, 0
  %t868 = load { i64, ptr }, ptr %l395, !tbaa !27
  %t869 = extractvalue { i64, ptr } %t868, 1
  %t870 = extractvalue { i64, ptr } %t868, 0
  %t871 = add i64 %t867, %t870
  %t872 = extractvalue { i64, ptr } { i64 1, ptr @.d23 }, 1
  %t873 = extractvalue { i64, ptr } { i64 1, ptr @.d23 }, 0
  %t874 = add i64 %t871, %t873
  %t875 = call ptr @__olang_scope_alloc(ptr %s24, i64 %t874)
  call void @olang_textcopy(ptr %t875, ptr %t866, i64 %t867)
  %t876 = getelementptr i8, ptr %t875, i64 %t867
  call void @olang_textcopy(ptr %t876, ptr %t869, i64 %t870)
  %t877 = getelementptr i8, ptr %t876, i64 %t870
  call void @olang_textcopy(ptr %t877, ptr %t872, i64 %t873)
  %t878 = insertvalue { i64, ptr } undef, i64 %t874, 0
  %t879 = insertvalue { i64, ptr } %t878, ptr %t875, 1
  %t881 = extractvalue { i64, ptr } %t879, 0
  %t882 = extractvalue { i64, ptr } %t879, 1
  %t883 = mul i64 %t881, 1
  %t884 = call ptr @__olang_scope_alloc(ptr %s24, i64 %t883)
  call void @llvm.memcpy.p0.p0.i64(ptr %t884, ptr %t882, i64 %t883, i1 false)
  %t885 = insertvalue { i64, ptr } undef, i64 %t881, 0
  %t886 = insertvalue { i64, ptr } %t885, ptr %t884, 1
  %t887 = load { i64, ptr }, ptr %l389, !tbaa !27
  %t888 = load { i64, ptr }, ptr %l393, !tbaa !27
  %t890 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotExtendedOp(ptr %s24, ptr %s24, ptr %s24, ptr %s24, { i64, ptr } %t887, { i64, ptr } %t888, { i64, ptr } %t886)
  store %"compiler/msgs:Msg" %t890, ptr %l398
  br label %bb226
bb226:
  %t891 = load ptr, ptr %l384, !tbaa !29
  %t892 = load %"compiler/source:Span", ptr %l385
  %t893 = load %"compiler/msgs:Msg", ptr %l398
  %t894 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s24, ptr %t891, %"compiler/source:Span" %t892, %"compiler/msgs:Msg" %t893)
  store i64 %t894, ptr %l399
  br label %bb227
bb227:
  %t895 = load ptr, ptr %l0, !tbaa !29
  %t896 = load %"compiler/source:Span", ptr %l1
  %t899 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t895, %"compiler/source:Span" %t896)
  store ptr %t899, ptr %l402
  br label %bb228
bb228:
  call void @__olang_scope_close(ptr %s24)
  %t900 = load ptr, ptr %l402, !tbaa !29
  store ptr %t900, ptr %rv
  br label %ret
bb229:
  %t901 = load i32, ptr %l3
  %t903 = call i1 @compiler_2fcheck_2ecompares(i32 %t901)
  store i1 %t903, ptr %l404
  br label %bb230
bb230:
  %t904 = load i1, ptr %l404, !tbaa !21
  br i1 %t904, label %bb231, label %bb232
bb231:
  %t905 = load ptr, ptr %l0, !tbaa !29
  store ptr %t905, ptr %l405, !tbaa !29
  %t906 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t906, ptr %l406
  %t907 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t907, ptr %l407, !tbaa !23
  %t908 = load i32, ptr %l3
  %t910 = call i32 @compiler_2fcheck_2ebinaryOp(i32 %t908)
  store i32 %t910, ptr %l409
  br label %bb233
bb232:
  br label %bb235
bb233:
  %t911 = load ptr, ptr %l4, !tbaa !29
  %t912 = load ptr, ptr %l5, !tbaa !29
  %t914 = load ptr, ptr %l405, !tbaa !29
  %t915 = load %"compiler/source:Span", ptr %l406
  %t916 = load i32, ptr %l407, !tbaa !23
  %t917 = load i32, ptr %l409
  %t920 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %t914, %"compiler/source:Span" %t915, i32 %t916, i32 %t917, ptr %t911, ptr %t912)
  store ptr %t920, ptr %l413
  br label %bb234
bb234:
  %t921 = load ptr, ptr %l413, !tbaa !29
  store ptr %t921, ptr %rv
  br label %ret
bb235:
  %t922 = load ptr, ptr %l0, !tbaa !29
  store ptr %t922, ptr %l414, !tbaa !29
  %t923 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t923, ptr %l415
  %t924 = load i32, ptr %l14, !tbaa !23
  store i32 %t924, ptr %l416, !tbaa !23
  %t925 = load i32, ptr %l3
  %t927 = call i32 @compiler_2fcheck_2ebinaryOp(i32 %t925)
  store i32 %t927, ptr %l418
  br label %bb236
bb236:
  %t928 = load ptr, ptr %l4, !tbaa !29
  %t929 = load ptr, ptr %l5, !tbaa !29
  %t930 = load ptr, ptr %l414, !tbaa !29
  %t931 = load %"compiler/source:Span", ptr %l415
  %t932 = load i32, ptr %l416, !tbaa !23
  %t933 = load i32, ptr %l418
  %t936 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echeckedPrim(ptr %v0, ptr %t930, %"compiler/source:Span" %t931, i32 %t932, i32 %t933, ptr %t928, ptr %t929)
  store ptr %t936, ptr %l421
  br label %bb237
bb237:
  %t937 = load ptr, ptr %l421, !tbaa !29
  store ptr %t937, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparamOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l5 = alloca i64
  %l8 = alloca i64
  %l11 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erootLocal(ptr %v0, ptr %v1, ptr %t1, ptr %a1)
  store i64 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i64, ptr %l5, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load i64, ptr %l2, !tbaa !24
  %t9 = icmp sge i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load i64, ptr %l2, !tbaa !24
  %t15 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparamIndex(ptr %v0, ptr %t11, i64 %t12)
  store i64 %t15, ptr %l11
  br label %bb4
bb3:
  store i64 -1, ptr %l8, !tbaa !24
  br label %bb5
bb4:
  %t16 = load i64, ptr %l11, !tbaa !24
  store i64 %t16, ptr %l8, !tbaa !24
  br label %bb5
bb5:
  %t17 = load i64, ptr %l8, !tbaa !24
  store i64 %t17, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epathPart(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l15 = alloca { i64, ptr }
  %l23 = alloca i64
  %l26 = alloca i64
  %l47 = alloca i1
  %l48 = alloca { i64, ptr }
  %l69 = alloca %"compiler/source:Span"
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t4 = getelementptr %"compiler/ast:Path", ptr %t2, i32 0, i32 0
  %t5 = load %"compiler/source:Span", ptr %t4
  %t8 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %a0, %"compiler/source:Span" %t5)
  store { i64, ptr } %t8, ptr %l15
  br label %bb1
bb1:
  %t9 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t9, ptr %l3, !tbaa !27
  %t10 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  %t14 = load i64, ptr %l2, !tbaa !24
  %t16 = add i64 %t14, 1
  store i64 %t16, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t18 = load i64, ptr %l6, !tbaa !24
  %t19 = load i64, ptr %l5, !tbaa !24
  %t22 = icmp sgt i64 %t18, %t19
  br i1 %t22, label %bb2, label %bb3
bb2:
  %t24 = load i64, ptr %l7, !tbaa !24
  %t26 = icmp sgt i64 %t24, 0
  br i1 %t26, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb7
bb4:
  %t28 = load i64, ptr %l6, !tbaa !24
  %t29 = load i64, ptr %l5, !tbaa !24
  %t32 = sub i64 %t28, %t29
  %t33 = load i64, ptr %l7, !tbaa !24
  %t36 = add i64 %t32, %t33
  %t38 = sub i64 %t36, 1
  %t39 = load i64, ptr %l7, !tbaa !24
  %t42 = sdiv i64 %t38, %t39
  store i64 %t42, ptr %l26, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l26, !tbaa !24
  br label %bb6
bb6:
  %t44 = load i64, ptr %l26, !tbaa !24
  store i64 %t44, ptr %l23, !tbaa !24
  br label %bb7
bb7:
  %t45 = load i64, ptr %l23, !tbaa !24
  store i64 %t45, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t46 = load i64, ptr %l9, !tbaa !24
  %t47 = load i64, ptr %l8, !tbaa !24
  %t50 = icmp slt i64 %t46, %t47
  %t52 = xor i1 %t50, true
  br i1 %t52, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb29
bb10:
  br label %bb11
bb11:
  %t54 = load i64, ptr %l5, !tbaa !24
  %t55 = load i64, ptr %l9, !tbaa !24
  %t56 = load i64, ptr %l7, !tbaa !24
  %t59 = mul i64 %t55, %t56
  %t62 = add i64 %t54, %t59
  store i64 %t62, ptr %l10, !tbaa !24
  %t64 = load i64, ptr %l4, !tbaa !24
  store i64 %t64, ptr %l11, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s3
  %t66 = load i64, ptr %l11, !tbaa !24
  %t68 = icmp sgt i64 %t66, 0
  br i1 %t68, label %bb13, label %bb14
bb13:
  %t70 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t70, ptr %l48, !tbaa !27
  %t71 = load i64, ptr %l11, !tbaa !24
  %t73 = sub i64 %t71, 1
  %t75 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = getelementptr i8, ptr %t76, i64 %t73
  %t78 = load i8, ptr %t77, !tbaa !32
  %t80 = icmp ne i8 %t78, 46
  store i1 %t80, ptr %l47, !tbaa !21
  br label %bb15
bb14:
  store i1 false, ptr %l47, !tbaa !21
  br label %bb15
bb15:
  %t82 = load i1, ptr %l47, !tbaa !21
  %t83 = xor i1 %t82, true
  br i1 %t83, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s3)
  br label %bb20
bb17:
  br label %bb18
bb18:
  %t85 = load i64, ptr %l11, !tbaa !24
  %t87 = sub i64 %t85, 1
  store i64 %t87, ptr %l11, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb19
bb19:
  br label %bb12
bb20:
  %t89 = load i64, ptr %l10, !tbaa !24
  %t90 = load i64, ptr %l2, !tbaa !24
  %t93 = icmp eq i64 %t89, %t90
  br i1 %t93, label %bb21, label %bb22
bb21:
  store %olang.scope zeroinitializer, ptr %s4
  %t95 = load ptr, ptr %l1, !tbaa !29
  %t97 = getelementptr %"compiler/ast:Path", ptr %t95, i32 0, i32 0
  %t98 = getelementptr %"compiler/source:Span", ptr %t97, i32 0, i32 0
  %t99 = load i32, ptr %t98, !tbaa !23
  %t100 = load i64, ptr %l11, !tbaa !24
  %t102 = trunc i64 %t100 to i32
  %t105 = add i32 %t99, %t102
  %t106 = load ptr, ptr %l1, !tbaa !29
  %t108 = getelementptr %"compiler/ast:Path", ptr %t106, i32 0, i32 0
  %t109 = getelementptr %"compiler/source:Span", ptr %t108, i32 0, i32 0
  %t110 = load i32, ptr %t109, !tbaa !23
  %t111 = load i64, ptr %l4, !tbaa !24
  %t113 = trunc i64 %t111 to i32
  %t116 = add i32 %t110, %t113
  %t119 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s4, i32 %t105, i32 %t116)
  store %"compiler/source:Span" %t119, ptr %l69
  br label %bb23
bb22:
  br label %bb24
bb23:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s2)
  %t120 = load %"compiler/source:Span", ptr %l69
  store %"compiler/source:Span" %t120, ptr %rv
  br label %ret
bb24:
  %t121 = load i64, ptr %l11, !tbaa !24
  %t123 = sub i64 %t121, 1
  store i64 %t123, ptr %l4, !tbaa !24
  %t125 = load i64, ptr %l4, !tbaa !24
  %t127 = icmp slt i64 %t125, 0
  br i1 %t127, label %bb25, label %bb26
bb25:
  %t129 = load ptr, ptr %l1, !tbaa !29
  %t131 = getelementptr %"compiler/ast:Path", ptr %t129, i32 0, i32 0
  %t132 = load %"compiler/source:Span", ptr %t131
  call void @__olang_scope_close(ptr %s2)
  store %"compiler/source:Span" %t132, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s2)
  br label %bb28
bb28:
  %t134 = load i64, ptr %l9, !tbaa !24
  %t136 = add i64 %t134, 1
  store i64 %t136, ptr %l9, !tbaa !24
  br label %bb8
bb29:
  %t138 = load ptr, ptr %l1, !tbaa !29
  %t140 = getelementptr %"compiler/ast:Path", ptr %t138, i32 0, i32 0
  %t141 = load %"compiler/source:Span", ptr %t140
  store %"compiler/source:Span" %t141, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplaceName(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i1
  %l12 = alloca ptr
  %l14 = alloca %"compiler/typed:Local"
  %l16 = alloca ptr
  %l17 = alloca i1
  %rv = alloca i32
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb8
bb5:
  %t18 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %a0)
  store ptr %t18, ptr %l12
  br label %bb6
bb6:
  %t19 = load i32, ptr %l2, !tbaa !23
  %t20 = load ptr, ptr %l12, !tbaa !29
  %t22 = call %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %t20, i32 %t19)
  store %"compiler/typed:Local" %t22, ptr %l14
  br label %bb7
bb7:
  %t23 = getelementptr %"compiler/typed:Local", ptr %l14, i32 0, i32 0
  %t24 = load i32, ptr %t23, !tbaa !23
  store i32 %t24, ptr %l4, !tbaa !23
  br label %bb19
bb8:
  %t26 = load ptr, ptr %l1, !tbaa !29
  store ptr %t26, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t27 = load ptr, ptr %l16, !tbaa !29
  %t28 = icmp ne ptr %t27, null
  br i1 %t28, label %bb9, label %bb10
bb9:
  %t30 = load ptr, ptr %l16, !tbaa !29
  %t31 = load i64, ptr %t30
  %t33 = icmp eq i64 %t31, 1
  store i1 %t33, ptr %l17, !tbaa !21
  br label %bb10
bb10:
  %t34 = load i1, ptr %l17, !tbaa !21
  br i1 %t34, label %bb11, label %bb12
bb11:
  %t35 = load ptr, ptr %l1, !tbaa !29
  %t37 = getelementptr { i64, [4 x i64] }, ptr %t35, i32 0, i32 1
  %t38 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t37, i32 0, i32 3
  %t39 = load i32, ptr %t38
  store i32 %t39, ptr %l3, !tbaa !23
  br label %bb13
bb12:
  br label %bb14
bb13:
  %t41 = load i32, ptr %l3, !tbaa !23
  store i32 %t41, ptr %l4, !tbaa !23
  br label %bb19
bb14:
  br i1 true, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  store i32 0, ptr %l4, !tbaa !23
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_1f453287a90ee701_f75bf1e5be6f432d)
  unreachable
bb19:
  %t43 = load i32, ptr %l4, !tbaa !23
  store i32 %t43, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3, ptr %a4, ptr %a5) #0 {
entry:
  %l0 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i64
  %l9 = alloca i64
  %l19 = alloca %"compiler/source:Span"
  %l20 = alloca i32
  %l21 = alloca i32
  %l22 = alloca i32
  %l26 = alloca { i64, ptr }
  %rv = alloca ptr
  %t35 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 31
  %t5 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load i64, ptr %l9, !tbaa !24
  store i64 %t6, ptr %l6, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 31
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ePus_H51a5125d8f537c6ff8e01fc80ef561c7(ptr %v0, ptr %v0, ptr %t9, ptr %a4)
  br label %bb2
bb2:
  %t13 = load ptr, ptr %l5, !tbaa !29
  %t15 = icmp eq ptr %t13, null
  %t17 = xor i1 %t15, true
  br i1 %t17, label %bb3, label %bb4
bb3:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/check:Checker", ptr %t19, i32 0, i32 31
  %t22 = load ptr, ptr %l5, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ePus_H51a5125d8f537c6ff8e01fc80ef561c7(ptr %v0, ptr %v0, ptr %t21, ptr %t22)
  br label %bb5
bb4:
  br label %bb6
bb5:
  br label %bb6
bb6:
  store %"compiler/source:Span" %a1, ptr %l19
  store i32 %a2, ptr %l20, !tbaa !23
  store i32 %a3, ptr %l21
  store i32 0, ptr %l22
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/check:Checker", ptr %t28, i32 0, i32 31
  %t31 = load i64, ptr %l6, !tbaa !24
  %t34 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t30, i64 %t31)
  store { i64, ptr } %t34, ptr %l26
  br label %bb7
bb7:
  store { i64, [5 x i64] } zeroinitializer, ptr %t35
  %t36 = getelementptr { i64, [5 x i64] }, ptr %t35, i32 0, i32 0
  store i64 9, ptr %t36
  %t37 = load %"compiler/source:Span", ptr %l19
  %t38 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } undef, %"compiler/source:Span" %t37, 0
  %t39 = load i32, ptr %l20, !tbaa !23
  %t40 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t38, i32 %t39, 1
  %t41 = load i32, ptr %l21
  %t42 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t40, i32 %t41, 2
  %t43 = load i32, ptr %l22
  %t44 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t42, i32 %t43, 3
  %t45 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t46 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t44, { i64, ptr } %t45, 4
  %t47 = getelementptr { i64, [5 x i64] }, ptr %t35, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t46, ptr %t47
  %t48 = load { i64, [5 x i64] }, ptr %t35
  %t50 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t48, ptr %t50
  store ptr %t50, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprivateRole(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, i32 %a2, { i64, ptr } %a3, %"compiler/source:Span" %a4, { i64, ptr } %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l9 = alloca i1
  %l12 = alloca i64
  %l15 = alloca ptr
  %l19 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l25 = alloca i1
  %l26 = alloca i1
  %l30 = alloca i64
  %l32 = alloca ptr
  %l40 = alloca ptr
  %l43 = alloca { i64, [3 x i64] }
  %l44 = alloca { i64, ptr }
  %l45 = alloca ptr
  %l48 = alloca i32
  %l49 = alloca { i64, ptr }
  %l53 = alloca %"compiler/msgs:Msg"
  %l54 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb4
bb2:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/check:Checker", ptr %t5, i32 0, i32 12
  %t9 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fcheck_3aframe_26_3_H2d42092ce658fb6cce0104fa754a4e33(ptr %v0, ptr %t7)
  store i64 %t9, ptr %l12
  br label %bb3
bb3:
  %t10 = load i64, ptr %l12, !tbaa !24
  %t11 = icmp eq i64 %t10, 0
  store i1 %t11, ptr %l9, !tbaa !21
  br label %bb4
bb4:
  %t13 = load i1, ptr %l9, !tbaa !21
  br i1 %t13, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t15 = load ptr, ptr %l0, !tbaa !29
  store ptr %t15, ptr %l15, !tbaa !29
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/check:Checker", ptr %t16, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t20 = load i64, ptr %l1, !tbaa !24
  %t23 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t19, i64 %t20)
  store ptr %t23, ptr %l19
  br label %bb8
bb8:
  %t24 = load ptr, ptr %l19, !tbaa !29
  %t26 = getelementptr %"compiler/ast:Func", ptr %t24, i32 0, i32 2
  %t27 = load i32, ptr %t26, !tbaa !23
  %t28 = load ptr, ptr %l15, !tbaa !29
  %t30 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t28, i32 %t27)
  store { i64, ptr } %t30, ptr %l22
  br label %bb9
bb9:
  %t31 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t31, ptr %l6, !tbaa !27
  %t32 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t33 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t36 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %t32, { i64, ptr } %t33)
  store i1 %t36, ptr %l25
  br label %bb10
bb10:
  %t37 = load i1, ptr %l25, !tbaa !21
  br i1 %t37, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb15
bb12:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/check:Checker", ptr %t38, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t42 = load i64, ptr %l1, !tbaa !24
  %t45 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t41, i64 %t42)
  store i64 %t45, ptr %l30
  br label %bb13
bb13:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t46)
  store ptr %t48, ptr %l32
  br label %bb14
bb14:
  %t49 = load ptr, ptr %l32, !tbaa !29
  %t51 = getelementptr %"compiler/check:frame", ptr %t49, i32 0, i32 1
  %t52 = load i64, ptr %t51, !tbaa !24
  %t53 = load i64, ptr %l30, !tbaa !24
  %t55 = icmp eq i64 %t53, %t52
  store i1 %t55, ptr %l26, !tbaa !21
  br label %bb15
bb15:
  %t57 = load i1, ptr %l26, !tbaa !21
  br i1 %t57, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/check:Checker", ptr %t59, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = getelementptr %"compiler/generic:Program", ptr %t62, i32 0, i32 0
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t67 = getelementptr %"compiler/load:Loader", ptr %t65, i32 0, i32 4
  %t68 = load ptr, ptr %t67, !tbaa !29
  store ptr %t68, ptr %l40, !tbaa !29
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t73 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %t69, %"compiler/source:Span" %a4)
  store { i64, [3 x i64] } %t73, ptr %l43
  br label %bb19
bb19:
  store { i64, ptr } %a5, ptr %l44, !tbaa !27
  %t75 = load ptr, ptr %l0, !tbaa !29
  store ptr %t75, ptr %l45, !tbaa !29
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t80 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t76, i32 %a2)
  store i32 %t80, ptr %l48
  br label %bb20
bb20:
  %t81 = load ptr, ptr %l45, !tbaa !29
  %t82 = load i32, ptr %l48, !tbaa !23
  %t83 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t81, i32 %t82)
  store { i64, ptr } %t83, ptr %l49
  br label %bb21
bb21:
  %t84 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t85 = extractvalue { i64, ptr } %t84, 0
  %t86 = extractvalue { i64, ptr } %t84, 1
  %t87 = mul i64 %t85, 1
  %t88 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t87)
  call void @llvm.memcpy.p0.p0.i64(ptr %t88, ptr %t86, i64 %t87, i1 false)
  %t89 = insertvalue { i64, ptr } undef, i64 %t85, 0
  %t90 = insertvalue { i64, ptr } %t89, ptr %t88, 1
  %t91 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t92 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t93 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t97 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eProtocolPrivate(ptr %v2, ptr %s0, ptr %v0, ptr %v1, ptr %s0, { i64, ptr } %t93, { i64, ptr } %t90, { i64, ptr } %t91, { i64, ptr } %t92)
  store %"compiler/msgs:Msg" %t97, ptr %l53
  br label %bb22
bb22:
  %t98 = load ptr, ptr %l40, !tbaa !29
  %t99 = load { i64, [3 x i64] }, ptr %l43
  %t100 = load %"compiler/msgs:Msg", ptr %l53
  %t101 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrorOncePerLine(ptr %v0, ptr %s0, ptr %t98, { i64, [3 x i64] } %t99, %"compiler/msgs:Msg" %t100)
  store i64 %t101, ptr %l54
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadsConst(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca i1
  %l21 = alloca ptr
  %l22 = alloca i1
  %l27 = alloca ptr
  %l28 = alloca i1
  %l36 = alloca i1
  %l37 = alloca ptr
  %l38 = alloca i1
  %l48 = alloca i64
  %l50 = alloca ptr
  %l51 = alloca i1
  %l61 = alloca i1
  %l62 = alloca i1
  %l66 = alloca i1
  %l67 = alloca ptr
  %l68 = alloca i1
  %l81 = alloca { i64, ptr }
  %l87 = alloca i1
  %s7 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l1, !tbaa !29
  store ptr %t6, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t7 = load ptr, ptr %l15, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l15, !tbaa !29
  %t11 = load i64, ptr %t10
  %t13 = icmp eq i64 %t11, 2
  store i1 %t13, ptr %l16, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l16, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr { i64, [5 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", ptr }, ptr %t17, i32 0, i32 1
  %t19 = load ptr, ptr %t18
  store ptr %t19, ptr %l2, !tbaa !29
  br label %bb16
bb7:
  %t21 = load ptr, ptr %l1, !tbaa !29
  store ptr %t21, ptr %l21, !tbaa !29
  store i1 false, ptr %l22, !tbaa !21
  %t22 = load ptr, ptr %l21, !tbaa !29
  %t23 = icmp ne ptr %t22, null
  br i1 %t23, label %bb8, label %bb9
bb8:
  %t25 = load ptr, ptr %l21, !tbaa !29
  %t26 = load i64, ptr %t25
  %t28 = icmp eq i64 %t26, 3
  store i1 %t28, ptr %l22, !tbaa !21
  br label %bb9
bb9:
  %t29 = load i1, ptr %l22, !tbaa !21
  br i1 %t29, label %bb10, label %bb11
bb10:
  %t30 = load ptr, ptr %l1, !tbaa !29
  %t32 = getelementptr { i64, [5 x i64] }, ptr %t30, i32 0, i32 1
  %t33 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t32, i32 0, i32 2
  %t34 = load ptr, ptr %t33
  store ptr %t34, ptr %l2, !tbaa !29
  br label %bb16
bb11:
  %t36 = load ptr, ptr %l1, !tbaa !29
  store ptr %t36, ptr %l27, !tbaa !29
  store i1 false, ptr %l28, !tbaa !21
  %t37 = load ptr, ptr %l27, !tbaa !29
  %t38 = icmp ne ptr %t37, null
  br i1 %t38, label %bb12, label %bb13
bb12:
  %t40 = load ptr, ptr %l27, !tbaa !29
  %t41 = load i64, ptr %t40
  %t43 = icmp eq i64 %t41, 15
  store i1 %t43, ptr %l28, !tbaa !21
  br label %bb13
bb13:
  %t44 = load i1, ptr %l28, !tbaa !21
  br i1 %t44, label %bb14, label %bb15
bb14:
  %t45 = load ptr, ptr %l1, !tbaa !29
  %t47 = getelementptr { i64, [5 x i64] }, ptr %t45, i32 0, i32 1
  %t48 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t47, i32 0, i32 1
  %t49 = load ptr, ptr %t48
  store ptr %t49, ptr %l2, !tbaa !29
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t52 = load ptr, ptr %l2, !tbaa !29
  %t56 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadsConst(ptr %v0, ptr %v1, ptr %t51, ptr %t52)
  store i1 %t56, ptr %l36
  br label %bb17
bb17:
  %t57 = load i1, ptr %l36, !tbaa !21
  store i1 %t57, ptr %rv
  br label %ret
bb18:
  %t58 = load ptr, ptr %l1, !tbaa !29
  store ptr %t58, ptr %l37, !tbaa !29
  store i1 false, ptr %l38, !tbaa !21
  %t59 = load ptr, ptr %l37, !tbaa !29
  %t60 = icmp ne ptr %t59, null
  br i1 %t60, label %bb19, label %bb20
bb19:
  %t62 = load ptr, ptr %l37, !tbaa !29
  %t63 = load i64, ptr %t62
  %t65 = icmp eq i64 %t63, 12
  store i1 %t65, ptr %l38, !tbaa !21
  br label %bb20
bb20:
  %t66 = load i1, ptr %l38, !tbaa !21
  br i1 %t66, label %bb21, label %bb22
bb21:
  %t67 = load ptr, ptr %l1, !tbaa !29
  %t69 = getelementptr { i64, [5 x i64] }, ptr %t67, i32 0, i32 1
  %t70 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t69, i32 0, i32 1
  %t71 = load ptr, ptr %t70
  store ptr %t71, ptr %l3, !tbaa !29
  %t73 = load ptr, ptr %l1, !tbaa !29
  %t75 = getelementptr { i64, [5 x i64] }, ptr %t73, i32 0, i32 1
  %t76 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t75, i32 0, i32 2
  %t77 = load { i64, ptr }, ptr %t76
  store { i64, ptr } %t77, ptr %l4, !tbaa !27
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t80 = load ptr, ptr %l3, !tbaa !29
  %t81 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t85 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparamLen(ptr %v0, ptr %v1, ptr %v1, ptr %t79, ptr %t80, { i64, ptr } %t81)
  store i64 %t85, ptr %l48
  br label %bb24
bb24:
  %t86 = load i64, ptr %l48, !tbaa !24
  %t87 = icmp sge i64 %t86, 0
  store i1 %t87, ptr %rv
  br label %ret
bb25:
  %t89 = load ptr, ptr %l1, !tbaa !29
  store ptr %t89, ptr %l50, !tbaa !29
  store i1 false, ptr %l51, !tbaa !21
  %t90 = load ptr, ptr %l50, !tbaa !29
  %t91 = icmp ne ptr %t90, null
  br i1 %t91, label %bb26, label %bb27
bb26:
  %t93 = load ptr, ptr %l50, !tbaa !29
  %t94 = load i64, ptr %t93
  %t96 = icmp eq i64 %t94, 5
  store i1 %t96, ptr %l51, !tbaa !21
  br label %bb27
bb27:
  %t97 = load i1, ptr %l51, !tbaa !21
  br i1 %t97, label %bb28, label %bb29
bb28:
  %t98 = load ptr, ptr %l1, !tbaa !29
  %t100 = getelementptr { i64, [5 x i64] }, ptr %t98, i32 0, i32 1
  %t101 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t100, i32 0, i32 2
  %t102 = load ptr, ptr %t101
  store ptr %t102, ptr %l5, !tbaa !29
  %t104 = load ptr, ptr %l1, !tbaa !29
  %t106 = getelementptr { i64, [5 x i64] }, ptr %t104, i32 0, i32 1
  %t107 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t106, i32 0, i32 3
  %t108 = load ptr, ptr %t107
  store ptr %t108, ptr %l6, !tbaa !29
  br label %bb30
bb29:
  br label %bb36
bb30:
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t111 = load ptr, ptr %l5, !tbaa !29
  %t115 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadsConst(ptr %v0, ptr %v1, ptr %t110, ptr %t111)
  store i1 %t115, ptr %l61
  br label %bb31
bb31:
  %t116 = load i1, ptr %l61, !tbaa !21
  br i1 %t116, label %bb32, label %bb33
bb32:
  store i1 true, ptr %l62, !tbaa !21
  br label %bb35
bb33:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t118 = load ptr, ptr %l6, !tbaa !29
  %t122 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadsConst(ptr %v0, ptr %v1, ptr %t117, ptr %t118)
  store i1 %t122, ptr %l66
  br label %bb34
bb34:
  %t123 = load i1, ptr %l66, !tbaa !21
  store i1 %t123, ptr %l62, !tbaa !21
  br label %bb35
bb35:
  %t124 = load i1, ptr %l62, !tbaa !21
  store i1 %t124, ptr %rv
  br label %ret
bb36:
  %t125 = load ptr, ptr %l1, !tbaa !29
  store ptr %t125, ptr %l67, !tbaa !29
  store i1 false, ptr %l68, !tbaa !21
  %t126 = load ptr, ptr %l67, !tbaa !29
  %t127 = icmp ne ptr %t126, null
  br i1 %t127, label %bb37, label %bb38
bb37:
  %t129 = load ptr, ptr %l67, !tbaa !29
  %t130 = load i64, ptr %t129
  %t132 = icmp eq i64 %t130, 7
  store i1 %t132, ptr %l68, !tbaa !21
  br label %bb38
bb38:
  %t133 = load i1, ptr %l68, !tbaa !21
  br i1 %t133, label %bb39, label %bb40
bb39:
  %t134 = load ptr, ptr %l1, !tbaa !29
  %t136 = getelementptr { i64, [5 x i64] }, ptr %t134, i32 0, i32 1
  %t137 = getelementptr { %"compiler/source:Span", ptr }, ptr %t136, i32 0, i32 1
  %t138 = load ptr, ptr %t137
  store ptr %t138, ptr %l7, !tbaa !29
  br label %bb41
bb40:
  br label %bb52
bb41:
  %t140 = load ptr, ptr %l7, !tbaa !29
  %t142 = getelementptr %"compiler/ast:Chain", ptr %t140, i32 0, i32 1
  %t143 = load { i64, ptr }, ptr %t142, !tbaa !27
  store { i64, ptr } %t143, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t145 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t147 = extractvalue { i64, ptr } %t145, 0
  store i64 %t147, ptr %l10, !tbaa !24
  br label %bb42
bb42:
  store %olang.scope zeroinitializer, ptr %s7
  %t149 = load i64, ptr %l9, !tbaa !24
  %t150 = load i64, ptr %l10, !tbaa !24
  %t153 = icmp slt i64 %t149, %t150
  %t155 = xor i1 %t153, true
  br i1 %t155, label %bb43, label %bb44
bb43:
  call void @__olang_scope_close(ptr %s7)
  br label %bb51
bb44:
  br label %bb45
bb45:
  %t157 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t157, ptr %l81, !tbaa !27
  %t158 = load i64, ptr %l9, !tbaa !24
  %t160 = getelementptr { i64, ptr }, ptr %l81, i32 0, i32 1
  %t161 = load ptr, ptr %t160, !tbaa !27
  %t162 = getelementptr ptr, ptr %t161, i64 %t158
  %t163 = load ptr, ptr %t162, !tbaa !39
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t170 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadsConst(ptr %v0, ptr %v1, ptr %t165, ptr %t163)
  store i1 %t170, ptr %l87
  br label %bb46
bb46:
  %t171 = load i1, ptr %l87, !tbaa !21
  br i1 %t171, label %bb47, label %bb48
bb47:
  call void @__olang_scope_close(ptr %s7)
  store i1 true, ptr %rv
  br label %ret
bb48:
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s7)
  br label %bb50
bb50:
  %t173 = load i64, ptr %l9, !tbaa !24
  %t175 = add i64 %t173, 1
  store i64 %t175, ptr %l9, !tbaa !24
  br label %bb42
bb51:
  store i1 false, ptr %rv
  br label %ret
bb52:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadsReference(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i32
  %l9 = alloca i64
  %l10 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l14 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i32
  %l27 = alloca { i64, ptr }
  %l32 = alloca i64
  %l35 = alloca i1
  %l37 = alloca ptr
  %l41 = alloca %"compiler/typed:Local"
  %l45 = alloca i1
  %l47 = alloca ptr
  %l51 = alloca i1
  %l54 = alloca ptr
  %l57 = alloca i32
  %l58 = alloca i1
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l10
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l10
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %l2
  call void @compiler_2fcheck_2enamesIn(ptr %v1, ptr %s0, ptr %a1, ptr %l2)
  br label %bb2
bb2:
  store ptr %l2, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t8 = load ptr, ptr %l3, !tbaa !29
  %t9 = load i64, ptr %l4, !tbaa !24
  %t12 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2eRun_H660dd195b8dfbe46b01e30313ba3abe1(ptr %s0, ptr %t8, i64 %t9)
  %t13 = extractvalue { i32, { i64, ptr } } %t12, 1
  %t14 = extractvalue { i32, { i64, ptr } } %t12, 0
  store i32 %t14, ptr %l18
  %t15 = icmp ne i32 %t14, 0
  br i1 %t15, label %bb5, label %ok.16
ok.16:
  store { i64, ptr } %t13, ptr %l17
  br label %bb4
bb4:
  %t17 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t17, ptr %l14, !tbaa !27
  br label %bb9
bb5:
  %t18 = load i32, ptr %l18, !tbaa !23
  %t19 = ashr i32 %t18, 16
  %t21 = icmp eq i32 %t19, 1
  br i1 %t21, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_check_failed(ptr @olang_loc_35725fa398e3a571_191401de5ef7023d)
  unreachable
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb36
bb9:
  %t23 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t23, ptr %l5, !tbaa !27
  %t24 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  store i64 %t26, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s3
  %t28 = load i64, ptr %l7, !tbaa !24
  %t29 = load i64, ptr %l6, !tbaa !24
  %t32 = icmp slt i64 %t28, %t29
  %t34 = xor i1 %t32, true
  br i1 %t34, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s3)
  br label %bb34
bb12:
  br label %bb13
bb13:
  %t36 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t36, ptr %l27, !tbaa !27
  %t37 = load i64, ptr %l7, !tbaa !24
  %t39 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !27
  %t41 = getelementptr i32, ptr %t40, i64 %t37
  %t42 = load i32, ptr %t41, !tbaa !33
  store i32 %t42, ptr %l8, !tbaa !23
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = load i32, ptr %l8, !tbaa !23
  %t48 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalNamed(ptr %v0, ptr %t44, i32 %t45)
  store i64 %t48, ptr %l32
  br label %bb14
bb14:
  %t49 = load i64, ptr %l32, !tbaa !24
  store i64 %t49, ptr %l9, !tbaa !24
  %t50 = load i64, ptr %l9, !tbaa !24
  %t52 = icmp slt i64 %t50, 0
  br i1 %t52, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l35, !tbaa !21
  br label %bb19
bb16:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t54)
  store ptr %t56, ptr %l37
  br label %bb17
bb17:
  %t57 = load ptr, ptr %l37, !tbaa !29
  %t59 = getelementptr %"compiler/typed:Body", ptr %t57, i32 0, i32 7
  %t60 = load i64, ptr %l9, !tbaa !24
  %t63 = call %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t59, i64 %t60)
  store %"compiler/typed:Local" %t63, ptr %l41
  br label %bb18
bb18:
  %t64 = getelementptr %"compiler/typed:Local", ptr %l41, i32 0, i32 4
  %t65 = load i32, ptr %t64
  %t67 = trunc i64 0 to i32
  %t68 = icmp eq i32 %t65, %t67
  %t70 = xor i1 %t68, true
  store i1 %t70, ptr %l35, !tbaa !21
  br label %bb19
bb19:
  %t72 = load i1, ptr %l35, !tbaa !21
  br i1 %t72, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l45, !tbaa !21
  br label %bb24
bb21:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t73)
  store ptr %t75, ptr %l47
  br label %bb22
bb22:
  %t76 = load ptr, ptr %l47, !tbaa !29
  %t78 = getelementptr %"compiler/check:frame", ptr %t76, i32 0, i32 50
  %t79 = load i32, ptr %l8, !tbaa !23
  %t82 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H8da9376267bda3f76393292be0e507b2(ptr %v0, ptr %t78, i32 %t79)
  store i1 %t82, ptr %l51
  br label %bb23
bb23:
  %t83 = load i1, ptr %l51, !tbaa !21
  store i1 %t83, ptr %l45, !tbaa !21
  br label %bb24
bb24:
  %t84 = load i1, ptr %l45, !tbaa !21
  br i1 %t84, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s3)
  br label %bb33
bb26:
  br label %bb27
bb27:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/check:Checker", ptr %t85, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !29
  %t90 = getelementptr %"compiler/generic:Program", ptr %t88, i32 0, i32 2
  store ptr %t90, ptr %l54, !tbaa !29
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load i64, ptr %l9, !tbaa !24
  %t95 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalType(ptr %v0, ptr %t91, i64 %t92)
  store i32 %t95, ptr %l57
  br label %bb28
bb28:
  %t96 = load ptr, ptr %l54, !tbaa !29
  %t97 = load i32, ptr %l57, !tbaa !23
  %t98 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %t96, i32 %t97)
  store i1 %t98, ptr %l58
  br label %bb29
bb29:
  %t99 = load i1, ptr %l58, !tbaa !21
  br i1 %t99, label %bb30, label %bb31
bb30:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb31:
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s3)
  br label %bb33
bb33:
  %t101 = load i64, ptr %l7, !tbaa !24
  %t103 = add i64 %t101, 1
  store i64 %t103, ptr %l7, !tbaa !24
  br label %bb10
bb34:
  %t105 = load i64, ptr %l4, !tbaa !24
  %t106 = load i64, ptr %l6, !tbaa !24
  %t109 = add i64 %t105, %t106
  store i64 %t109, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb35
bb35:
  br label %bb3
bb36:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresultAt(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca { i64, [2 x i64] }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l8 = alloca ptr
  %l13 = alloca i1
  %l14 = alloca i64
  %l17 = alloca i64
  %l23 = alloca ptr
  %l32 = alloca i64
  %l36 = alloca ptr
  %l43 = alloca i1
  %l49 = alloca ptr
  %l53 = alloca i64
  %l54 = alloca { i64, ptr }
  %l58 = alloca { i64, [3 x i64] }
  %rv = alloca { i64, [3 x i64] }
  %t24 = alloca { i64, [3 x i64] }, align 8
  %t89 = alloca { i64, [3 x i64] }, align 8
  %t115 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t1)
  store ptr %t3, ptr %l8
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l8, !tbaa !29
  %t6 = getelementptr %"compiler/check:frame", ptr %t4, i32 0, i32 0
  %t7 = load i64, ptr %t6, !tbaa !24
  store i64 %t7, ptr %l2, !tbaa !24
  %t9 = load i64, ptr %l2, !tbaa !24
  %t11 = icmp slt i64 %t9, 0
  br i1 %t11, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb5
bb3:
  %t13 = load i64, ptr %l2, !tbaa !24
  store i64 %t13, ptr %l14, !tbaa !24
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/check:Checker", ptr %t14, i32 0, i32 10
  %t18 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_Ha6bcf4d517e3d7b46809e1dbf938da91(ptr %v0, ptr %t16)
  store i64 %t18, ptr %l17
  br label %bb4
bb4:
  %t19 = load i64, ptr %l14, !tbaa !24
  %t20 = load i64, ptr %l17, !tbaa !24
  %t21 = icmp sge i64 %t19, %t20
  store i1 %t21, ptr %l13, !tbaa !21
  br label %bb5
bb5:
  %t23 = load i1, ptr %l13, !tbaa !21
  br i1 %t23, label %bb6, label %bb7
bb6:
  store { i64, [3 x i64] } zeroinitializer, ptr %t24
  %t25 = getelementptr { i64, [3 x i64] }, ptr %t24, i32 0, i32 0
  store i64 0, ptr %t25
  %t26 = load { i64, [3 x i64] }, ptr %t24
  store { i64, [3 x i64] } %t26, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/check:Checker", ptr %t28, i32 0, i32 10
  %t31 = load i64, ptr %l2, !tbaa !24
  %t34 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t30, i64 %t31)
  store ptr %t34, ptr %l23
  br label %bb9
bb9:
  %t35 = load ptr, ptr %l23, !tbaa !29
  %t37 = getelementptr %"compiler/typed:Body", ptr %t35, i32 0, i32 1
  %t38 = load { i64, [2 x i64] }, ptr %t37
  store { i64, [2 x i64] } %t38, ptr %l3
  %t40 = load { i64, [2 x i64] }, ptr %l3
  %t42 = extractvalue { i64, [2 x i64] } %t40, 0
  %t43 = icmp eq i64 %t42, 0
  br i1 %t43, label %bb10, label %bb11
bb10:
  %t45 = getelementptr { i64, [2 x i64] }, ptr %l3, i32 0, i32 1
  %t46 = getelementptr { i64 }, ptr %t45, i32 0, i32 0
  %t47 = load i64, ptr %t46
  store i64 %t47, ptr %l4, !tbaa !24
  br label %bb12
bb11:
  br label %bb23
bb12:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/check:Checker", ptr %t49, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !29
  %t53 = load i64, ptr %l4, !tbaa !24
  %t56 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t52, i64 %t53)
  store i64 %t56, ptr %l32
  br label %bb13
bb13:
  %t57 = load i64, ptr %l32, !tbaa !24
  store i64 %t57, ptr %l5, !tbaa !24
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/check:Checker", ptr %t58, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !29
  %t62 = load i64, ptr %l5, !tbaa !24
  %t65 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t61, i64 %t62)
  store ptr %t65, ptr %l36
  br label %bb14
bb14:
  %t66 = load ptr, ptr %l36, !tbaa !29
  %t68 = getelementptr %"compiler/ast:Func", ptr %t66, i32 0, i32 3
  %t69 = load ptr, ptr %t68, !tbaa !29
  %t71 = getelementptr %"compiler/ast:Sig", ptr %t69, i32 0, i32 1
  %t72 = load { i64, ptr }, ptr %t71, !tbaa !27
  store { i64, ptr } %t72, ptr %l6, !tbaa !27
  %t74 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t76 = extractvalue { i64, ptr } %t74, 0
  %t78 = icmp eq i64 %t76, 0
  br i1 %t78, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l43, !tbaa !21
  br label %bb17
bb16:
  %t80 = load i64, ptr %l1, !tbaa !24
  %t81 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t83 = extractvalue { i64, ptr } %t81, 0
  %t86 = icmp sge i64 %t80, %t83
  store i1 %t86, ptr %l43, !tbaa !21
  br label %bb17
bb17:
  %t88 = load i1, ptr %l43, !tbaa !21
  br i1 %t88, label %bb18, label %bb19
bb18:
  store { i64, [3 x i64] } zeroinitializer, ptr %t89
  %t90 = getelementptr { i64, [3 x i64] }, ptr %t89, i32 0, i32 0
  store i64 0, ptr %t90
  %t91 = load { i64, [3 x i64] }, ptr %t89
  store { i64, [3 x i64] } %t91, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  %t93 = load ptr, ptr %l0, !tbaa !29
  store ptr %t93, ptr %l49, !tbaa !29
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/check:Checker", ptr %t94, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !29
  %t98 = load i64, ptr %l5, !tbaa !24
  %t101 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t97, i64 %t98)
  store i64 %t101, ptr %l53
  br label %bb21
bb21:
  %t102 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t102, ptr %l54, !tbaa !27
  %t103 = load i64, ptr %l1, !tbaa !24
  %t105 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !27
  %t107 = getelementptr ptr, ptr %t106, i64 %t103
  %t108 = load ptr, ptr %t107, !tbaa !39
  %t110 = load ptr, ptr %l49, !tbaa !29
  %t111 = load i64, ptr %l53, !tbaa !24
  %t113 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emarkAt(ptr %v0, ptr %v0, ptr %t110, i64 %t111, ptr %t108)
  store { i64, [3 x i64] } %t113, ptr %l58
  br label %bb22
bb22:
  %t114 = load { i64, [3 x i64] }, ptr %l58
  store { i64, [3 x i64] } %t114, ptr %rv
  br label %ret
bb23:
  store { i64, [3 x i64] } zeroinitializer, ptr %t115
  %t116 = getelementptr { i64, [3 x i64] }, ptr %t115, i32 0, i32 0
  store i64 0, ptr %t116
  %t117 = load { i64, [3 x i64] }, ptr %t115
  store { i64, [3 x i64] } %t117, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [3 x i64] }, ptr %rv
  ret { i64, [3 x i64] } %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroBorrowedFrom(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l15 = alloca i64
  %l18 = alloca i1
  %l21 = alloca i1
  %l27 = alloca ptr
  %l34 = alloca i64
  %l44 = alloca i64
  %l47 = alloca i64
  %l70 = alloca i64
  %l74 = alloca i1
  %l78 = alloca i1
  %l82 = alloca i1
  %s4 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t4 = getelementptr %"compiler/typed:Call", ptr %t2, i32 0, i32 0
  %t5 = load ptr, ptr %t4, !tbaa !29
  %t8 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyOfCallee(ptr %v0, ptr %v1, ptr %t1, ptr %t5)
  store i64 %t8, ptr %l15
  br label %bb1
bb1:
  %t9 = load i64, ptr %l15, !tbaa !24
  store i64 %t9, ptr %l2, !tbaa !24
  %t10 = load i64, ptr %l2, !tbaa !24
  %t12 = icmp slt i64 %t10, 0
  br i1 %t12, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb5
bb3:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load i64, ptr %l2, !tbaa !24
  %t18 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstanceBody(ptr %v0, ptr %t14, i64 %t15)
  store i1 %t18, ptr %l21
  br label %bb4
bb4:
  %t19 = load i1, ptr %l21, !tbaa !21
  %t20 = xor i1 %t19, true
  store i1 %t20, ptr %l18, !tbaa !21
  br label %bb5
bb5:
  %t22 = load i1, ptr %l18, !tbaa !21
  br i1 %t22, label %bb6, label %bb7
bb6:
  store i64 -1, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/check:Checker", ptr %t24, i32 0, i32 10
  %t27 = load i64, ptr %l2, !tbaa !24
  %t30 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t26, i64 %t27)
  store ptr %t30, ptr %l27
  br label %bb9
bb9:
  %t31 = load ptr, ptr %l27, !tbaa !29
  %t33 = getelementptr %"compiler/typed:Body", ptr %t31, i32 0, i32 2
  %t34 = load i32, ptr %t33, !tbaa !23
  store i32 %t34, ptr %l3, !tbaa !23
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/check:Checker", ptr %t36, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !29
  %t41 = getelementptr %"compiler/generic:Program", ptr %t39, i32 0, i32 2
  %t42 = load i32, ptr %l3, !tbaa !23
  %t45 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v0, ptr %t41, i32 %t42, i64 0)
  store i64 %t45, ptr %l34
  br label %bb10
bb10:
  %t46 = load i64, ptr %l34, !tbaa !24
  store i64 %t46, ptr %l4, !tbaa !24
  %t47 = load i64, ptr %l4, !tbaa !24
  %t49 = icmp slt i64 %t47, 0
  br i1 %t49, label %bb11, label %bb12
bb11:
  store i64 -1, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  store i64 0, ptr %l5, !tbaa !24
  %t52 = load ptr, ptr %l1, !tbaa !29
  %t54 = getelementptr %"compiler/typed:Call", ptr %t52, i32 0, i32 1
  %t55 = load { i64, ptr }, ptr %t54, !tbaa !27
  %t57 = extractvalue { i64, ptr } %t55, 0
  store i64 %t57, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t59 = load i64, ptr %l6, !tbaa !24
  %t60 = load i64, ptr %l5, !tbaa !24
  %t63 = icmp sgt i64 %t59, %t60
  br i1 %t63, label %bb14, label %bb15
bb14:
  %t65 = load i64, ptr %l7, !tbaa !24
  %t67 = icmp sgt i64 %t65, 0
  br i1 %t67, label %bb16, label %bb17
bb15:
  store i64 0, ptr %l44, !tbaa !24
  br label %bb19
bb16:
  %t69 = load i64, ptr %l6, !tbaa !24
  %t70 = load i64, ptr %l5, !tbaa !24
  %t73 = sub i64 %t69, %t70
  %t74 = load i64, ptr %l7, !tbaa !24
  %t77 = add i64 %t73, %t74
  %t79 = sub i64 %t77, 1
  %t80 = load i64, ptr %l7, !tbaa !24
  %t83 = sdiv i64 %t79, %t80
  store i64 %t83, ptr %l47, !tbaa !24
  br label %bb18
bb17:
  store i64 0, ptr %l47, !tbaa !24
  br label %bb18
bb18:
  %t85 = load i64, ptr %l47, !tbaa !24
  store i64 %t85, ptr %l44, !tbaa !24
  br label %bb19
bb19:
  %t86 = load i64, ptr %l44, !tbaa !24
  store i64 %t86, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb20
bb20:
  store %olang.scope zeroinitializer, ptr %s4
  %t87 = load i64, ptr %l9, !tbaa !24
  %t88 = load i64, ptr %l8, !tbaa !24
  %t91 = icmp slt i64 %t87, %t88
  %t93 = xor i1 %t91, true
  br i1 %t93, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s4)
  br label %bb36
bb22:
  br label %bb23
bb23:
  %t95 = load i64, ptr %l5, !tbaa !24
  %t96 = load i64, ptr %l9, !tbaa !24
  %t97 = load i64, ptr %l7, !tbaa !24
  %t100 = mul i64 %t96, %t97
  %t103 = add i64 %t95, %t100
  store i64 %t103, ptr %l10, !tbaa !24
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr %"compiler/check:Checker", ptr %t105, i32 0, i32 1
  %t108 = load ptr, ptr %t107, !tbaa !29
  %t110 = getelementptr %"compiler/generic:Program", ptr %t108, i32 0, i32 2
  %t111 = load i32, ptr %l3, !tbaa !23
  %t112 = load i64, ptr %l10, !tbaa !24
  %t116 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShareOf(ptr %v0, ptr %t110, i32 %t111, i64 %t112)
  store i64 %t116, ptr %l70
  br label %bb24
bb24:
  %t117 = load i64, ptr %l70, !tbaa !24
  store i64 %t117, ptr %l11, !tbaa !24
  %t118 = load i64, ptr %l10, !tbaa !24
  %t119 = load i64, ptr %l4, !tbaa !24
  %t122 = icmp eq i64 %t118, %t119
  br i1 %t122, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l74, !tbaa !21
  br label %bb27
bb26:
  %t124 = load i64, ptr %l11, !tbaa !24
  %t125 = load i64, ptr %l4, !tbaa !24
  %t128 = icmp eq i64 %t124, %t125
  store i1 %t128, ptr %l74, !tbaa !21
  br label %bb27
bb27:
  %t130 = load i1, ptr %l74, !tbaa !21
  br i1 %t130, label %bb28, label %bb29
bb28:
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t132 = load i64, ptr %l2, !tbaa !24
  %t133 = load i64, ptr %l10, !tbaa !24
  %t137 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroByArg(ptr %v0, ptr %t131, i64 %t132, i64 %t133)
  store i1 %t137, ptr %l82
  br label %bb30
bb29:
  store i1 false, ptr %l78, !tbaa !21
  br label %bb31
bb30:
  %t138 = load i1, ptr %l82, !tbaa !21
  store i1 %t138, ptr %l78, !tbaa !21
  br label %bb31
bb31:
  %t139 = load i1, ptr %l78, !tbaa !21
  br i1 %t139, label %bb32, label %bb33
bb32:
  %t140 = load i64, ptr %l10, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  store i64 %t140, ptr %rv
  br label %ret
bb33:
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s4)
  br label %bb35
bb35:
  %t142 = load i64, ptr %l9, !tbaa !24
  %t144 = add i64 %t142, 1
  store i64 %t144, ptr %l9, !tbaa !24
  br label %bb20
bb36:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroCallAt(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l1 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i1
  %l17 = alloca i1
  %l19 = alloca { i64, ptr }
  %l21 = alloca %"compiler/source:Span"
  %l23 = alloca %"compiler/source:Span"
  %l25 = alloca i1
  %l28 = alloca %"compiler/source:Span"
  %rv = alloca %"compiler/source:Span"
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 6
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l3
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t18, i32 0, i32 2
  %t20 = load ptr, ptr %t19
  store ptr %t20, ptr %l4, !tbaa !29
  br label %bb5
bb4:
  br label %bb15
bb5:
  %t22 = load ptr, ptr %l4, !tbaa !29
  %t24 = getelementptr %"compiler/typed:Call", ptr %t22, i32 0, i32 1
  %t25 = load { i64, ptr }, ptr %t24, !tbaa !27
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t29 = icmp sgt i64 %t27, 0
  br i1 %t29, label %bb6, label %bb7
bb6:
  %t31 = load ptr, ptr %l4, !tbaa !29
  %t33 = getelementptr %"compiler/typed:Call", ptr %t31, i32 0, i32 1
  %t34 = load { i64, ptr }, ptr %t33, !tbaa !27
  store { i64, ptr } %t34, ptr %l19, !tbaa !27
  %t35 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !27
  %t37 = getelementptr ptr, ptr %t36, i64 0
  %t38 = load ptr, ptr %t37, !tbaa !39
  %t40 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t38)
  store %"compiler/source:Span" %t40, ptr %l21
  br label %bb8
bb7:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb10
bb8:
  %t41 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t41, ptr %l23
  %t44 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fsource_3aSpan(ptr %l21, ptr %l23)
  store i1 %t44, ptr %l25
  br label %bb9
bb9:
  %t45 = load i1, ptr %l25, !tbaa !21
  store i1 %t45, ptr %l17, !tbaa !21
  br label %bb10
bb10:
  %t46 = load i1, ptr %l17, !tbaa !21
  br i1 %t46, label %bb11, label %bb12
bb11:
  %t48 = load %"compiler/source:Span", ptr %l3
  %t51 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebracketIn(ptr %v0, ptr %a0, %"compiler/source:Span" %t48)
  store %"compiler/source:Span" %t51, ptr %l28
  br label %bb13
bb12:
  br label %bb14
bb13:
  %t52 = load %"compiler/source:Span", ptr %l28
  store %"compiler/source:Span" %t52, ptr %rv
  br label %ret
bb14:
  br label %bb16
bb15:
  br label %bb16
bb16:
  store %"compiler/source:Span" %a2, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroFollows(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l4 = alloca ptr
  %l7 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l8 = alloca i1
  %l13 = alloca i1
  %l14 = alloca i1
  %l18 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 61
  store ptr %t3, ptr %l4, !tbaa !29
  %t4 = load i64, ptr %l1, !tbaa !24
  %t5 = load i64, ptr %l2, !tbaa !24
  %t8 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %t4, i64 %t5)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t8, ptr %l7
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l4, !tbaa !29
  %t10 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l7
  %t11 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %t9, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t10)
  store i1 %t11, ptr %l8
  br label %bb2
bb2:
  %t12 = load i1, ptr %l8, !tbaa !21
  br i1 %t12, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load i64, ptr %l1, !tbaa !24
  %t16 = load i64, ptr %l2, !tbaa !24
  %t20 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroByArg(ptr %v0, ptr %t14, i64 %t15, i64 %t16)
  store i1 %t20, ptr %l13
  br label %bb6
bb6:
  %t21 = load i1, ptr %l13, !tbaa !21
  br i1 %t21, label %bb7, label %bb8
bb7:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/check:Checker", ptr %t22, i32 0, i32 15
  %t25 = load i64, ptr %l1, !tbaa !24
  %t28 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t24, i64 %t25)
  store i64 %t28, ptr %l18
  br label %bb9
bb8:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb10
bb9:
  %t29 = load i64, ptr %l18, !tbaa !24
  %t30 = icmp ne i64 %t29, 2
  store i1 %t30, ptr %l14, !tbaa !21
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s0)
  %t32 = load i1, ptr %l14, !tbaa !21
  store i1 %t32, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroSettle(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i1
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca %"std/pair:Pair.b139c4f75a6545712256427180a82a06"
  %l14 = alloca ptr
  %l15 = alloca i64
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca %"compiler/check:roArg"
  %l20 = alloca ptr
  %l21 = alloca %"compiler/typed:Local"
  %l23 = alloca ptr
  %l24 = alloca i64
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca %"compiler/check:roArg"
  %l29 = alloca ptr
  %l30 = alloca %"compiler/typed:Local"
  %l32 = alloca ptr
  %l33 = alloca i64
  %l34 = alloca { i64, ptr }
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca %"compiler/check:roFn"
  %l38 = alloca ptr
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca %"compiler/typed:Local"
  %l46 = alloca { i64, ptr }
  %l50 = alloca i64
  %l55 = alloca i64
  %l58 = alloca i64
  %l78 = alloca { i64, ptr }
  %l81 = alloca { i64, ptr }
  %l82 = alloca i32
  %l91 = alloca { i64, ptr }
  %l97 = alloca i1
  %l98 = alloca i1
  %l102 = alloca i1
  %l118 = alloca { i64, ptr }
  %l121 = alloca { i64, ptr }
  %l122 = alloca i32
  %l131 = alloca { i64, ptr }
  %l135 = alloca ptr
  %l138 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l139 = alloca i1
  %l144 = alloca ptr
  %l145 = alloca i64
  %l148 = alloca i64
  %l150 = alloca ptr
  %l154 = alloca i32
  %l155 = alloca %"compiler/typed:Local"
  %l159 = alloca ptr
  %l160 = alloca { i64, [3 x i64] }
  %l161 = alloca { i64, ptr }
  %l164 = alloca { i64, ptr }
  %l167 = alloca %"compiler/msgs:Msg"
  %l168 = alloca i64
  %l172 = alloca ptr
  %l173 = alloca i64
  %l180 = alloca { i64, [3 x i64] }
  %l183 = alloca { i64, ptr }
  %l185 = alloca %"compiler/msgs:Msg"
  %l194 = alloca { i64, ptr }
  %l197 = alloca { i64, ptr }
  %l198 = alloca i32
  %l207 = alloca { i64, ptr }
  %l211 = alloca ptr
  %l214 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l215 = alloca i1
  %l220 = alloca ptr
  %l221 = alloca i64
  %l224 = alloca i64
  %l226 = alloca ptr
  %l230 = alloca i32
  %l231 = alloca %"compiler/typed:Local"
  %l235 = alloca ptr
  %l236 = alloca { i64, [3 x i64] }
  %l237 = alloca { i64, ptr }
  %l240 = alloca { i64, ptr }
  %l242 = alloca %"compiler/msgs:Msg"
  %l243 = alloca i64
  %l247 = alloca ptr
  %l248 = alloca i64
  %l255 = alloca { i64, [3 x i64] }
  %l258 = alloca { i64, ptr }
  %l260 = alloca %"compiler/msgs:Msg"
  %l268 = alloca { i64, ptr }
  %l271 = alloca { i64, ptr }
  %l272 = alloca i32
  %l281 = alloca { i64, ptr }
  %l287 = alloca ptr
  %l291 = alloca i64
  %l295 = alloca i64
  %l298 = alloca i64
  %l317 = alloca ptr
  %l320 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l321 = alloca i1
  %l323 = alloca ptr
  %l327 = alloca i32
  %l328 = alloca %"compiler/typed:Local"
  %l331 = alloca { i64, ptr }
  %l335 = alloca ptr
  %l336 = alloca { i64, [3 x i64] }
  %l337 = alloca { i64, ptr }
  %l340 = alloca { i64, ptr }
  %l342 = alloca %"compiler/msgs:Msg"
  %l343 = alloca i64
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %t291 = alloca { i64, [3 x i64] }, align 8
  %t477 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroSettleDeep(ptr %v0, ptr %t1)
  br label %bb1
bb1:
  store i64 0, ptr %l1, !tbaa !24
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/check:Checker", ptr %t3, i32 0, i32 57
  %t7 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3cstd_2fpair_3aPa_H0373c7e46aeaf586ca7dddb6278d7312(ptr %v0, ptr %t5)
  store i64 %t7, ptr %l50
  br label %bb2
bb2:
  %t8 = load i64, ptr %l50, !tbaa !24
  %t9 = add i64 %t8, 1
  store i64 %t9, ptr %l2, !tbaa !24
  store i64 1, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l2, !tbaa !24
  %t12 = load i64, ptr %l1, !tbaa !24
  %t15 = icmp sgt i64 %t11, %t12
  br i1 %t15, label %bb3, label %bb4
bb3:
  %t17 = load i64, ptr %l3, !tbaa !24
  %t19 = icmp sgt i64 %t17, 0
  br i1 %t19, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l55, !tbaa !24
  br label %bb8
bb5:
  %t21 = load i64, ptr %l2, !tbaa !24
  %t22 = load i64, ptr %l1, !tbaa !24
  %t25 = sub i64 %t21, %t22
  %t26 = load i64, ptr %l3, !tbaa !24
  %t29 = add i64 %t25, %t26
  %t31 = sub i64 %t29, 1
  %t32 = load i64, ptr %l3, !tbaa !24
  %t35 = sdiv i64 %t31, %t32
  store i64 %t35, ptr %l58, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l58, !tbaa !24
  br label %bb7
bb7:
  %t37 = load i64, ptr %l58, !tbaa !24
  store i64 %t37, ptr %l55, !tbaa !24
  br label %bb8
bb8:
  %t38 = load i64, ptr %l55, !tbaa !24
  store i64 %t38, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t39 = load i64, ptr %l5, !tbaa !24
  %t40 = load i64, ptr %l4, !tbaa !24
  %t43 = icmp slt i64 %t39, %t40
  %t45 = xor i1 %t43, true
  br i1 %t45, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb41
bb11:
  br label %bb12
bb12:
  %t47 = load i64, ptr %l1, !tbaa !24
  %t48 = load i64, ptr %l5, !tbaa !24
  %t49 = load i64, ptr %l3, !tbaa !24
  %t52 = mul i64 %t48, %t49
  %t55 = add i64 %t47, %t52
  store i64 %t55, ptr %l6, !tbaa !24
  store i1 false, ptr %l7, !tbaa !21
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/check:Checker", ptr %t57, i32 0, i32 57
  store ptr %t59, ptr %l8, !tbaa !29
  store i64 0, ptr %l9, !tbaa !24
  br label %bb13
bb13:
  store %olang.scope zeroinitializer, ptr %s4
  %t61 = load ptr, ptr %l8, !tbaa !29
  %t62 = load i64, ptr %l9, !tbaa !24
  %t65 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3cstd_2fpair_3aPa_H4e5c12183874056031e206ecb8273178(ptr %v0, ptr %t61, i64 %t62)
  %t66 = extractvalue { i32, { i64, ptr } } %t65, 1
  %t67 = extractvalue { i32, { i64, ptr } } %t65, 0
  store i32 %t67, ptr %l82
  %t68 = icmp ne i32 %t67, 0
  br i1 %t68, label %bb15, label %ok.69
ok.69:
  store { i64, ptr } %t66, ptr %l81
  br label %bb14
bb14:
  %t70 = load { i64, ptr }, ptr %l81, !tbaa !27
  store { i64, ptr } %t70, ptr %l78, !tbaa !27
  br label %bb19
bb15:
  %t71 = load i32, ptr %l82, !tbaa !23
  %t72 = ashr i32 %t71, 16
  %t74 = icmp eq i32 %t72, 1
  br i1 %t74, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_94fb3c639c1db4f7_cb3989d33edb9243)
  unreachable
bb18:
  call void @__olang_scope_close(ptr %s4)
  br label %bb36
bb19:
  %t76 = load { i64, ptr }, ptr %l78, !tbaa !27
  store { i64, ptr } %t76, ptr %l10, !tbaa !27
  %t77 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t79 = extractvalue { i64, ptr } %t77, 0
  store i64 %t79, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb20
bb20:
  store %olang.scope zeroinitializer, ptr %s5
  %t81 = load i64, ptr %l12, !tbaa !24
  %t82 = load i64, ptr %l11, !tbaa !24
  %t85 = icmp slt i64 %t81, %t82
  %t87 = xor i1 %t85, true
  br i1 %t87, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s5)
  br label %bb34
bb22:
  br label %bb23
bb23:
  %t89 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t89, ptr %l91, !tbaa !27
  %t90 = load i64, ptr %l12, !tbaa !24
  %t92 = getelementptr { i64, ptr }, ptr %l91, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !27
  %t94 = getelementptr %"std/pair:Pair.b139c4f75a6545712256427180a82a06", ptr %t93, i64 %t90
  %t95 = load %"std/pair:Pair.b139c4f75a6545712256427180a82a06", ptr %t94
  store %"std/pair:Pair.b139c4f75a6545712256427180a82a06" %t95, ptr %l13
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/check:Checker", ptr %t97, i32 0, i32 56
  %t100 = getelementptr %"std/pair:Pair.b139c4f75a6545712256427180a82a06", ptr %l13, i32 0, i32 1
  %t101 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %t100
  %t104 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %t99, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t101)
  store i1 %t104, ptr %l97
  br label %bb24
bb24:
  %t105 = load i1, ptr %l97, !tbaa !21
  br i1 %t105, label %bb25, label %bb26
bb25:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = getelementptr %"compiler/check:Checker", ptr %t106, i32 0, i32 56
  %t109 = getelementptr %"std/pair:Pair.b139c4f75a6545712256427180a82a06", ptr %l13, i32 0, i32 0
  %t110 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %t109
  %t113 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %t108, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t110)
  store i1 %t113, ptr %l102
  br label %bb27
bb26:
  store i1 false, ptr %l98, !tbaa !21
  br label %bb28
bb27:
  %t114 = load i1, ptr %l102, !tbaa !21
  %t115 = xor i1 %t114, true
  store i1 %t115, ptr %l98, !tbaa !21
  br label %bb28
bb28:
  %t117 = load i1, ptr %l98, !tbaa !21
  br i1 %t117, label %bb29, label %bb30
bb29:
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t120 = getelementptr %"compiler/check:Checker", ptr %t118, i32 0, i32 56
  %t121 = getelementptr %"std/pair:Pair.b139c4f75a6545712256427180a82a06", ptr %l13, i32 0, i32 0
  %t122 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %t121
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %t120, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t122, i1 true)
  br label %bb31
bb30:
  br label %bb32
bb31:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s5)
  br label %bb33
bb33:
  %t125 = load i64, ptr %l12, !tbaa !24
  %t127 = add i64 %t125, 1
  store i64 %t127, ptr %l12, !tbaa !24
  br label %bb20
bb34:
  %t129 = load i64, ptr %l9, !tbaa !24
  %t130 = load i64, ptr %l11, !tbaa !24
  %t133 = add i64 %t129, %t130
  store i64 %t133, ptr %l9, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  br label %bb35
bb35:
  br label %bb13
bb36:
  %t135 = load i1, ptr %l7, !tbaa !21
  %t137 = xor i1 %t135, true
  br i1 %t137, label %bb37, label %bb38
bb37:
  call void @__olang_scope_close(ptr %s2)
  br label %bb41
bb38:
  br label %bb39
bb39:
  call void @__olang_scope_close(ptr %s2)
  br label %bb40
bb40:
  %t139 = load i64, ptr %l5, !tbaa !24
  %t141 = add i64 %t139, 1
  store i64 %t141, ptr %l5, !tbaa !24
  br label %bb9
bb41:
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t145 = getelementptr %"compiler/check:Checker", ptr %t143, i32 0, i32 58
  store ptr %t145, ptr %l14, !tbaa !29
  store i64 0, ptr %l15, !tbaa !24
  br label %bb42
bb42:
  store %olang.scope zeroinitializer, ptr %s11
  %t147 = load ptr, ptr %l14, !tbaa !29
  %t148 = load i64, ptr %l15, !tbaa !24
  %t151 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aroArg_3e_2eRunFrom_3ccompiler_2fcheck_3aroArg_3e(ptr %v0, ptr %t147, i64 %t148)
  %t152 = extractvalue { i32, { i64, ptr } } %t151, 1
  %t153 = extractvalue { i32, { i64, ptr } } %t151, 0
  store i32 %t153, ptr %l122
  %t154 = icmp ne i32 %t153, 0
  br i1 %t154, label %bb44, label %ok.155
ok.155:
  store { i64, ptr } %t152, ptr %l121
  br label %bb43
bb43:
  %t156 = load { i64, ptr }, ptr %l121, !tbaa !27
  store { i64, ptr } %t156, ptr %l118, !tbaa !27
  br label %bb48
bb44:
  %t157 = load i32, ptr %l122, !tbaa !23
  %t158 = ashr i32 %t157, 16
  %t160 = icmp eq i32 %t158, 1
  br i1 %t160, label %bb45, label %bb46
bb45:
  br label %bb47
bb46:
  call void @__olang_check_failed(ptr @olang_loc_b42405a4ff8f50d6_8f3ce3b7732b4ac2)
  unreachable
bb47:
  call void @__olang_scope_close(ptr %s11)
  br label %bb74
bb48:
  %t162 = load { i64, ptr }, ptr %l118, !tbaa !27
  store { i64, ptr } %t162, ptr %l16, !tbaa !27
  %t163 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t165 = extractvalue { i64, ptr } %t163, 0
  store i64 %t165, ptr %l17, !tbaa !24
  store i64 0, ptr %l18, !tbaa !24
  br label %bb49
bb49:
  store %olang.scope zeroinitializer, ptr %s12
  %t167 = load i64, ptr %l18, !tbaa !24
  %t168 = load i64, ptr %l17, !tbaa !24
  %t171 = icmp slt i64 %t167, %t168
  %t173 = xor i1 %t171, true
  br i1 %t173, label %bb50, label %bb51
bb50:
  call void @__olang_scope_close(ptr %s12)
  br label %bb72
bb51:
  br label %bb52
bb52:
  %t175 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t175, ptr %l131, !tbaa !27
  %t176 = load i64, ptr %l18, !tbaa !24
  %t178 = getelementptr { i64, ptr }, ptr %l131, i32 0, i32 1
  %t179 = load ptr, ptr %t178, !tbaa !27
  %t180 = getelementptr %"compiler/check:roArg", ptr %t179, i64 %t176
  %t181 = load %"compiler/check:roArg", ptr %t180
  store %"compiler/check:roArg" %t181, ptr %l19
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t185 = getelementptr %"compiler/check:Checker", ptr %t183, i32 0, i32 56
  store ptr %t185, ptr %l135, !tbaa !29
  %t186 = getelementptr %"compiler/check:roArg", ptr %l19, i32 0, i32 0
  %t187 = load i64, ptr %t186, !tbaa !24
  %t188 = getelementptr %"compiler/check:roArg", ptr %l19, i32 0, i32 1
  %t189 = load i64, ptr %t188, !tbaa !24
  %t192 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s12, i64 %t187, i64 %t189)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t192, ptr %l138
  br label %bb53
bb53:
  %t193 = load ptr, ptr %l135, !tbaa !29
  %t194 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l138
  %t195 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %t193, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t194)
  store i1 %t195, ptr %l139
  br label %bb54
bb54:
  %t196 = load i1, ptr %l139, !tbaa !21
  %t197 = xor i1 %t196, true
  br i1 %t197, label %bb55, label %bb56
bb55:
  call void @__olang_scope_close(ptr %s12)
  br label %bb71
bb56:
  br label %bb57
bb57:
  %t199 = load ptr, ptr %l0, !tbaa !29
  %t201 = getelementptr %"compiler/check:Checker", ptr %t199, i32 0, i32 10
  %t202 = getelementptr %"compiler/check:roArg", ptr %l19, i32 0, i32 0
  %t203 = load i64, ptr %t202, !tbaa !24
  %t206 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t201, i64 %t203)
  store ptr %t206, ptr %l144
  br label %bb58
bb58:
  %t207 = load ptr, ptr %l144, !tbaa !29
  store ptr %t207, ptr %l20, !tbaa !29
  %t208 = getelementptr %"compiler/check:roArg", ptr %l19, i32 0, i32 1
  %t209 = load i64, ptr %t208, !tbaa !24
  store i64 %t209, ptr %l145, !tbaa !24
  %t210 = load ptr, ptr %l20, !tbaa !29
  %t212 = getelementptr %"compiler/typed:Body", ptr %t210, i32 0, i32 5
  %t214 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t212)
  store i64 %t214, ptr %l148
  br label %bb59
bb59:
  %t215 = load i64, ptr %l145, !tbaa !24
  %t216 = load i64, ptr %l148, !tbaa !24
  %t217 = icmp sge i64 %t215, %t216
  br i1 %t217, label %bb60, label %bb61
bb60:
  call void @__olang_scope_close(ptr %s12)
  br label %bb71
bb61:
  br label %bb62
bb62:
  %t219 = load ptr, ptr %l20, !tbaa !29
  store ptr %t219, ptr %l150, !tbaa !29
  %t220 = load ptr, ptr %l20, !tbaa !29
  %t222 = getelementptr %"compiler/typed:Body", ptr %t220, i32 0, i32 5
  %t223 = getelementptr %"compiler/check:roArg", ptr %l19, i32 0, i32 1
  %t224 = load i64, ptr %t223, !tbaa !24
  %t227 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t222, i64 %t224)
  store i32 %t227, ptr %l154
  br label %bb63
bb63:
  %t228 = load ptr, ptr %l150, !tbaa !29
  %t229 = load i32, ptr %l154, !tbaa !23
  %t230 = call %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %t228, i32 %t229)
  store %"compiler/typed:Local" %t230, ptr %l155
  br label %bb64
bb64:
  %t231 = load %"compiler/typed:Local", ptr %l155
  store %"compiler/typed:Local" %t231, ptr %l21
  %t232 = load ptr, ptr %l0, !tbaa !29
  %t234 = getelementptr %"compiler/check:Checker", ptr %t232, i32 0, i32 1
  %t235 = load ptr, ptr %t234, !tbaa !29
  %t237 = getelementptr %"compiler/generic:Program", ptr %t235, i32 0, i32 0
  %t238 = load ptr, ptr %t237, !tbaa !29
  %t240 = getelementptr %"compiler/load:Loader", ptr %t238, i32 0, i32 4
  %t241 = load ptr, ptr %t240, !tbaa !29
  store ptr %t241, ptr %l159, !tbaa !29
  %t242 = getelementptr %"compiler/check:roArg", ptr %l19, i32 0, i32 2
  %t243 = load { i64, [3 x i64] }, ptr %t242
  store { i64, [3 x i64] } %t243, ptr %l160
  %t244 = getelementptr %"compiler/check:roArg", ptr %l19, i32 0, i32 3
  %t245 = load { i64, ptr }, ptr %t244, !tbaa !27
  store { i64, ptr } %t245, ptr %l161, !tbaa !27
  %t246 = load ptr, ptr %l0, !tbaa !29
  %t247 = getelementptr %"compiler/typed:Local", ptr %l21, i32 0, i32 0
  %t248 = load i32, ptr %t247, !tbaa !23
  %t251 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t246, i32 %t248)
  store { i64, ptr } %t251, ptr %l164
  br label %bb65
bb65:
  %t252 = getelementptr %"compiler/check:roArg", ptr %l19, i32 0, i32 4
  %t253 = load { i64, ptr }, ptr %t252, !tbaa !27
  %t254 = getelementptr %"compiler/check:roArg", ptr %l19, i32 0, i32 5
  %t255 = load { i64, ptr }, ptr %t254, !tbaa !27
  %t256 = load { i64, ptr }, ptr %l161, !tbaa !27
  %t257 = load { i64, ptr }, ptr %l164, !tbaa !27
  %t260 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eReadOnlyCopyArg(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %s12, { i64, ptr } %t256, { i64, ptr } %t257, { i64, ptr } %t253, { i64, ptr } %t255)
  store %"compiler/msgs:Msg" %t260, ptr %l167
  br label %bb66
bb66:
  %t261 = load ptr, ptr %l159, !tbaa !29
  %t262 = load { i64, [3 x i64] }, ptr %l160
  %t263 = load %"compiler/msgs:Msg", ptr %l167
  %t264 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s12, ptr %t261, { i64, [3 x i64] } %t262, %"compiler/msgs:Msg" %t263)
  store i64 %t264, ptr %l168
  br label %bb67
bb67:
  %t265 = load i64, ptr %l168, !tbaa !24
  %t266 = load ptr, ptr %l0, !tbaa !29
  %t268 = getelementptr %"compiler/check:Checker", ptr %t266, i32 0, i32 1
  %t269 = load ptr, ptr %t268, !tbaa !29
  %t271 = getelementptr %"compiler/generic:Program", ptr %t269, i32 0, i32 0
  %t272 = load ptr, ptr %t271, !tbaa !29
  %t274 = getelementptr %"compiler/load:Loader", ptr %t272, i32 0, i32 4
  %t275 = load ptr, ptr %t274, !tbaa !29
  store ptr %t275, ptr %l172, !tbaa !29
  store i64 %t265, ptr %l173, !tbaa !24
  %t277 = load ptr, ptr %l20, !tbaa !29
  %t279 = getelementptr %"compiler/typed:Body", ptr %t277, i32 0, i32 3
  %t280 = load i64, ptr %t279, !tbaa !24
  %t281 = getelementptr %"compiler/typed:Local", ptr %l21, i32 0, i32 1
  %t282 = getelementptr %"compiler/source:Span", ptr %t281, i32 0, i32 0
  %t283 = load i32, ptr %t282, !tbaa !23
  %t285 = sext i32 %t283 to i64
  %t286 = getelementptr %"compiler/typed:Local", ptr %l21, i32 0, i32 1
  %t287 = getelementptr %"compiler/source:Span", ptr %t286, i32 0, i32 1
  %t288 = load i32, ptr %t287, !tbaa !23
  %t290 = sext i32 %t288 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t291
  %t292 = getelementptr { i64, [3 x i64] }, ptr %t291, i32 0, i32 0
  store i64 3, ptr %t292
  %t294 = insertvalue { i64, i64, i64 } undef, i64 %t280, 0
  %t296 = insertvalue { i64, i64, i64 } %t294, i64 %t285, 1
  %t298 = insertvalue { i64, i64, i64 } %t296, i64 %t290, 2
  %t299 = getelementptr { i64, [3 x i64] }, ptr %t291, i32 0, i32 1
  store { i64, i64, i64 } %t298, ptr %t299
  %t300 = load { i64, [3 x i64] }, ptr %t291
  store { i64, [3 x i64] } %t300, ptr %l180
  %t301 = load ptr, ptr %l0, !tbaa !29
  %t302 = getelementptr %"compiler/typed:Local", ptr %l21, i32 0, i32 0
  %t303 = load i32, ptr %t302, !tbaa !23
  %t306 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s12, ptr %t301, i32 %t303)
  store { i64, ptr } %t306, ptr %l183
  br label %bb68
bb68:
  %t307 = load { i64, ptr }, ptr %l183, !tbaa !27
  %t308 = extractvalue { i64, ptr } %t307, 0
  %t309 = extractvalue { i64, ptr } %t307, 1
  %t310 = mul i64 %t308, 1
  %t311 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t310)
  call void @llvm.memcpy.p0.p0.i64(ptr %t311, ptr %t309, i64 %t310, i1 false)
  %t312 = insertvalue { i64, ptr } undef, i64 %t308, 0
  %t313 = insertvalue { i64, ptr } %t312, ptr %t311, 1
  %t315 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteDeclaredHere(ptr %s12, ptr %s12, { i64, ptr } %t313)
  store %"compiler/msgs:Msg" %t315, ptr %l185
  br label %bb69
bb69:
  %t316 = load ptr, ptr %l172, !tbaa !29
  %t317 = load i64, ptr %l173, !tbaa !24
  %t318 = load { i64, [3 x i64] }, ptr %l180
  %t319 = load %"compiler/msgs:Msg", ptr %l185
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %s12, ptr %t316, i64 %t317, { i64, [3 x i64] } %t318, %"compiler/msgs:Msg" %t319)
  br label %bb70
bb70:
  call void @__olang_scope_close(ptr %s12)
  br label %bb71
bb71:
  %t320 = load i64, ptr %l18, !tbaa !24
  %t322 = add i64 %t320, 1
  store i64 %t322, ptr %l18, !tbaa !24
  br label %bb49
bb72:
  %t324 = load i64, ptr %l15, !tbaa !24
  %t325 = load i64, ptr %l17, !tbaa !24
  %t328 = add i64 %t324, %t325
  store i64 %t328, ptr %l15, !tbaa !24
  call void @__olang_scope_close(ptr %s11)
  br label %bb73
bb73:
  br label %bb42
bb74:
  %t330 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estrReceivers(ptr %v0, ptr %t330)
  br label %bb75
bb75:
  %t332 = load ptr, ptr %l0, !tbaa !29
  %t334 = getelementptr %"compiler/check:Checker", ptr %t332, i32 0, i32 65
  store ptr %t334, ptr %l23, !tbaa !29
  store i64 0, ptr %l24, !tbaa !24
  br label %bb76
bb76:
  store %olang.scope zeroinitializer, ptr %s17
  %t336 = load ptr, ptr %l23, !tbaa !29
  %t337 = load i64, ptr %l24, !tbaa !24
  %t340 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aroArg_3e_2eRunFrom_3ccompiler_2fcheck_3aroArg_3e(ptr %v0, ptr %t336, i64 %t337)
  %t341 = extractvalue { i32, { i64, ptr } } %t340, 1
  %t342 = extractvalue { i32, { i64, ptr } } %t340, 0
  store i32 %t342, ptr %l198
  %t343 = icmp ne i32 %t342, 0
  br i1 %t343, label %bb78, label %ok.344
ok.344:
  store { i64, ptr } %t341, ptr %l197
  br label %bb77
bb77:
  %t345 = load { i64, ptr }, ptr %l197, !tbaa !27
  store { i64, ptr } %t345, ptr %l194, !tbaa !27
  br label %bb82
bb78:
  %t346 = load i32, ptr %l198, !tbaa !23
  %t347 = ashr i32 %t346, 16
  %t349 = icmp eq i32 %t347, 1
  br i1 %t349, label %bb79, label %bb80
bb79:
  br label %bb81
bb80:
  call void @__olang_check_failed(ptr @olang_loc_6fbbefab94ae0ced_3a79826f299b6b39)
  unreachable
bb81:
  call void @__olang_scope_close(ptr %s17)
  br label %bb108
bb82:
  %t351 = load { i64, ptr }, ptr %l194, !tbaa !27
  store { i64, ptr } %t351, ptr %l25, !tbaa !27
  %t352 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t354 = extractvalue { i64, ptr } %t352, 0
  store i64 %t354, ptr %l26, !tbaa !24
  store i64 0, ptr %l27, !tbaa !24
  br label %bb83
bb83:
  store %olang.scope zeroinitializer, ptr %s18
  %t356 = load i64, ptr %l27, !tbaa !24
  %t357 = load i64, ptr %l26, !tbaa !24
  %t360 = icmp slt i64 %t356, %t357
  %t362 = xor i1 %t360, true
  br i1 %t362, label %bb84, label %bb85
bb84:
  call void @__olang_scope_close(ptr %s18)
  br label %bb106
bb85:
  br label %bb86
bb86:
  %t364 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t364, ptr %l207, !tbaa !27
  %t365 = load i64, ptr %l27, !tbaa !24
  %t367 = getelementptr { i64, ptr }, ptr %l207, i32 0, i32 1
  %t368 = load ptr, ptr %t367, !tbaa !27
  %t369 = getelementptr %"compiler/check:roArg", ptr %t368, i64 %t365
  %t370 = load %"compiler/check:roArg", ptr %t369
  store %"compiler/check:roArg" %t370, ptr %l28
  %t372 = load ptr, ptr %l0, !tbaa !29
  %t374 = getelementptr %"compiler/check:Checker", ptr %t372, i32 0, i32 56
  store ptr %t374, ptr %l211, !tbaa !29
  %t375 = getelementptr %"compiler/check:roArg", ptr %l28, i32 0, i32 0
  %t376 = load i64, ptr %t375, !tbaa !24
  %t377 = getelementptr %"compiler/check:roArg", ptr %l28, i32 0, i32 1
  %t378 = load i64, ptr %t377, !tbaa !24
  %t381 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s18, i64 %t376, i64 %t378)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t381, ptr %l214
  br label %bb87
bb87:
  %t382 = load ptr, ptr %l211, !tbaa !29
  %t383 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l214
  %t384 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %t382, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t383)
  store i1 %t384, ptr %l215
  br label %bb88
bb88:
  %t385 = load i1, ptr %l215, !tbaa !21
  %t386 = xor i1 %t385, true
  br i1 %t386, label %bb89, label %bb90
bb89:
  call void @__olang_scope_close(ptr %s18)
  br label %bb105
bb90:
  br label %bb91
bb91:
  %t388 = load ptr, ptr %l0, !tbaa !29
  %t390 = getelementptr %"compiler/check:Checker", ptr %t388, i32 0, i32 10
  %t391 = getelementptr %"compiler/check:roArg", ptr %l28, i32 0, i32 0
  %t392 = load i64, ptr %t391, !tbaa !24
  %t395 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t390, i64 %t392)
  store ptr %t395, ptr %l220
  br label %bb92
bb92:
  %t396 = load ptr, ptr %l220, !tbaa !29
  store ptr %t396, ptr %l29, !tbaa !29
  %t397 = getelementptr %"compiler/check:roArg", ptr %l28, i32 0, i32 1
  %t398 = load i64, ptr %t397, !tbaa !24
  store i64 %t398, ptr %l221, !tbaa !24
  %t399 = load ptr, ptr %l29, !tbaa !29
  %t401 = getelementptr %"compiler/typed:Body", ptr %t399, i32 0, i32 5
  %t403 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t401)
  store i64 %t403, ptr %l224
  br label %bb93
bb93:
  %t404 = load i64, ptr %l221, !tbaa !24
  %t405 = load i64, ptr %l224, !tbaa !24
  %t406 = icmp sge i64 %t404, %t405
  br i1 %t406, label %bb94, label %bb95
bb94:
  call void @__olang_scope_close(ptr %s18)
  br label %bb105
bb95:
  br label %bb96
bb96:
  %t408 = load ptr, ptr %l29, !tbaa !29
  store ptr %t408, ptr %l226, !tbaa !29
  %t409 = load ptr, ptr %l29, !tbaa !29
  %t411 = getelementptr %"compiler/typed:Body", ptr %t409, i32 0, i32 5
  %t412 = getelementptr %"compiler/check:roArg", ptr %l28, i32 0, i32 1
  %t413 = load i64, ptr %t412, !tbaa !24
  %t416 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t411, i64 %t413)
  store i32 %t416, ptr %l230
  br label %bb97
bb97:
  %t417 = load ptr, ptr %l226, !tbaa !29
  %t418 = load i32, ptr %l230, !tbaa !23
  %t419 = call %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %t417, i32 %t418)
  store %"compiler/typed:Local" %t419, ptr %l231
  br label %bb98
bb98:
  %t420 = load %"compiler/typed:Local", ptr %l231
  store %"compiler/typed:Local" %t420, ptr %l30
  %t421 = load ptr, ptr %l0, !tbaa !29
  %t423 = getelementptr %"compiler/check:Checker", ptr %t421, i32 0, i32 1
  %t424 = load ptr, ptr %t423, !tbaa !29
  %t426 = getelementptr %"compiler/generic:Program", ptr %t424, i32 0, i32 0
  %t427 = load ptr, ptr %t426, !tbaa !29
  %t429 = getelementptr %"compiler/load:Loader", ptr %t427, i32 0, i32 4
  %t430 = load ptr, ptr %t429, !tbaa !29
  store ptr %t430, ptr %l235, !tbaa !29
  %t431 = getelementptr %"compiler/check:roArg", ptr %l28, i32 0, i32 2
  %t432 = load { i64, [3 x i64] }, ptr %t431
  store { i64, [3 x i64] } %t432, ptr %l236
  %t433 = getelementptr %"compiler/check:roArg", ptr %l28, i32 0, i32 3
  %t434 = load { i64, ptr }, ptr %t433, !tbaa !27
  store { i64, ptr } %t434, ptr %l237, !tbaa !27
  %t435 = load ptr, ptr %l0, !tbaa !29
  %t436 = getelementptr %"compiler/typed:Local", ptr %l30, i32 0, i32 0
  %t437 = load i32, ptr %t436, !tbaa !23
  %t440 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t435, i32 %t437)
  store { i64, ptr } %t440, ptr %l240
  br label %bb99
bb99:
  %t441 = getelementptr %"compiler/check:roArg", ptr %l28, i32 0, i32 4
  %t442 = load { i64, ptr }, ptr %t441, !tbaa !27
  %t443 = load { i64, ptr }, ptr %l237, !tbaa !27
  %t444 = load { i64, ptr }, ptr %l240, !tbaa !27
  %t446 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eReadOnlyRefKept(ptr %v0, ptr %v0, ptr %v0, ptr %s18, { i64, ptr } %t443, { i64, ptr } %t444, { i64, ptr } %t442)
  store %"compiler/msgs:Msg" %t446, ptr %l242
  br label %bb100
bb100:
  %t447 = load ptr, ptr %l235, !tbaa !29
  %t448 = load { i64, [3 x i64] }, ptr %l236
  %t449 = load %"compiler/msgs:Msg", ptr %l242
  %t450 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s18, ptr %t447, { i64, [3 x i64] } %t448, %"compiler/msgs:Msg" %t449)
  store i64 %t450, ptr %l243
  br label %bb101
bb101:
  %t451 = load i64, ptr %l243, !tbaa !24
  %t452 = load ptr, ptr %l0, !tbaa !29
  %t454 = getelementptr %"compiler/check:Checker", ptr %t452, i32 0, i32 1
  %t455 = load ptr, ptr %t454, !tbaa !29
  %t457 = getelementptr %"compiler/generic:Program", ptr %t455, i32 0, i32 0
  %t458 = load ptr, ptr %t457, !tbaa !29
  %t460 = getelementptr %"compiler/load:Loader", ptr %t458, i32 0, i32 4
  %t461 = load ptr, ptr %t460, !tbaa !29
  store ptr %t461, ptr %l247, !tbaa !29
  store i64 %t451, ptr %l248, !tbaa !24
  %t463 = load ptr, ptr %l29, !tbaa !29
  %t465 = getelementptr %"compiler/typed:Body", ptr %t463, i32 0, i32 3
  %t466 = load i64, ptr %t465, !tbaa !24
  %t467 = getelementptr %"compiler/typed:Local", ptr %l30, i32 0, i32 1
  %t468 = getelementptr %"compiler/source:Span", ptr %t467, i32 0, i32 0
  %t469 = load i32, ptr %t468, !tbaa !23
  %t471 = sext i32 %t469 to i64
  %t472 = getelementptr %"compiler/typed:Local", ptr %l30, i32 0, i32 1
  %t473 = getelementptr %"compiler/source:Span", ptr %t472, i32 0, i32 1
  %t474 = load i32, ptr %t473, !tbaa !23
  %t476 = sext i32 %t474 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t477
  %t478 = getelementptr { i64, [3 x i64] }, ptr %t477, i32 0, i32 0
  store i64 3, ptr %t478
  %t480 = insertvalue { i64, i64, i64 } undef, i64 %t466, 0
  %t482 = insertvalue { i64, i64, i64 } %t480, i64 %t471, 1
  %t484 = insertvalue { i64, i64, i64 } %t482, i64 %t476, 2
  %t485 = getelementptr { i64, [3 x i64] }, ptr %t477, i32 0, i32 1
  store { i64, i64, i64 } %t484, ptr %t485
  %t486 = load { i64, [3 x i64] }, ptr %t477
  store { i64, [3 x i64] } %t486, ptr %l255
  %t487 = load ptr, ptr %l0, !tbaa !29
  %t488 = getelementptr %"compiler/typed:Local", ptr %l30, i32 0, i32 0
  %t489 = load i32, ptr %t488, !tbaa !23
  %t492 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s18, ptr %t487, i32 %t489)
  store { i64, ptr } %t492, ptr %l258
  br label %bb102
bb102:
  %t493 = load { i64, ptr }, ptr %l258, !tbaa !27
  %t494 = extractvalue { i64, ptr } %t493, 0
  %t495 = extractvalue { i64, ptr } %t493, 1
  %t496 = mul i64 %t494, 1
  %t497 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t496)
  call void @llvm.memcpy.p0.p0.i64(ptr %t497, ptr %t495, i64 %t496, i1 false)
  %t498 = insertvalue { i64, ptr } undef, i64 %t494, 0
  %t499 = insertvalue { i64, ptr } %t498, ptr %t497, 1
  %t501 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteDeclaredHere(ptr %s18, ptr %s18, { i64, ptr } %t499)
  store %"compiler/msgs:Msg" %t501, ptr %l260
  br label %bb103
bb103:
  %t502 = load ptr, ptr %l247, !tbaa !29
  %t503 = load i64, ptr %l248, !tbaa !24
  %t504 = load { i64, [3 x i64] }, ptr %l255
  %t505 = load %"compiler/msgs:Msg", ptr %l260
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %s18, ptr %t502, i64 %t503, { i64, [3 x i64] } %t504, %"compiler/msgs:Msg" %t505)
  br label %bb104
bb104:
  call void @__olang_scope_close(ptr %s18)
  br label %bb105
bb105:
  %t506 = load i64, ptr %l27, !tbaa !24
  %t508 = add i64 %t506, 1
  store i64 %t508, ptr %l27, !tbaa !24
  br label %bb83
bb106:
  %t510 = load i64, ptr %l24, !tbaa !24
  %t511 = load i64, ptr %l26, !tbaa !24
  %t514 = add i64 %t510, %t511
  store i64 %t514, ptr %l24, !tbaa !24
  call void @__olang_scope_close(ptr %s17)
  br label %bb107
bb107:
  br label %bb76
bb108:
  %t516 = load ptr, ptr %l0, !tbaa !29
  %t518 = getelementptr %"compiler/check:Checker", ptr %t516, i32 0, i32 59
  store ptr %t518, ptr %l32, !tbaa !29
  store i64 0, ptr %l33, !tbaa !24
  br label %bb109
bb109:
  store %olang.scope zeroinitializer, ptr %s23
  %t520 = load ptr, ptr %l32, !tbaa !29
  %t521 = load i64, ptr %l33, !tbaa !24
  %t524 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aroFn_3e_2eRunFrom_3ccompiler_2fcheck_3aroFn_3e(ptr %v0, ptr %t520, i64 %t521)
  %t525 = extractvalue { i32, { i64, ptr } } %t524, 1
  %t526 = extractvalue { i32, { i64, ptr } } %t524, 0
  store i32 %t526, ptr %l272
  %t527 = icmp ne i32 %t526, 0
  br i1 %t527, label %bb111, label %ok.528
ok.528:
  store { i64, ptr } %t525, ptr %l271
  br label %bb110
bb110:
  %t529 = load { i64, ptr }, ptr %l271, !tbaa !27
  store { i64, ptr } %t529, ptr %l268, !tbaa !27
  br label %bb115
bb111:
  %t530 = load i32, ptr %l272, !tbaa !23
  %t531 = ashr i32 %t530, 16
  %t533 = icmp eq i32 %t531, 1
  br i1 %t533, label %bb112, label %bb113
bb112:
  br label %bb114
bb113:
  call void @__olang_check_failed(ptr @olang_loc_46f27f903cdc013c_b0b6515331b7b68)
  unreachable
bb114:
  call void @__olang_scope_close(ptr %s23)
  br label %bb148
bb115:
  %t535 = load { i64, ptr }, ptr %l268, !tbaa !27
  store { i64, ptr } %t535, ptr %l34, !tbaa !27
  %t536 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t538 = extractvalue { i64, ptr } %t536, 0
  store i64 %t538, ptr %l35, !tbaa !24
  store i64 0, ptr %l36, !tbaa !24
  br label %bb116
bb116:
  store %olang.scope zeroinitializer, ptr %s24
  %t540 = load i64, ptr %l36, !tbaa !24
  %t541 = load i64, ptr %l35, !tbaa !24
  %t544 = icmp slt i64 %t540, %t541
  %t546 = xor i1 %t544, true
  br i1 %t546, label %bb117, label %bb118
bb117:
  call void @__olang_scope_close(ptr %s24)
  br label %bb146
bb118:
  br label %bb119
bb119:
  %t548 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t548, ptr %l281, !tbaa !27
  %t549 = load i64, ptr %l36, !tbaa !24
  %t551 = getelementptr { i64, ptr }, ptr %l281, i32 0, i32 1
  %t552 = load ptr, ptr %t551, !tbaa !27
  %t553 = getelementptr %"compiler/check:roFn", ptr %t552, i64 %t549
  %t554 = load %"compiler/check:roFn", ptr %t553
  store %"compiler/check:roFn" %t554, ptr %l37
  %t556 = load ptr, ptr %l0, !tbaa !29
  %t558 = getelementptr %"compiler/check:Checker", ptr %t556, i32 0, i32 10
  %t559 = getelementptr %"compiler/check:roFn", ptr %l37, i32 0, i32 0
  %t560 = load i64, ptr %t559, !tbaa !24
  %t563 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t558, i64 %t560)
  store ptr %t563, ptr %l287
  br label %bb120
bb120:
  %t564 = load ptr, ptr %l287, !tbaa !29
  store ptr %t564, ptr %l38, !tbaa !29
  %t565 = getelementptr %"compiler/check:roFn", ptr %l37, i32 0, i32 1
  %t566 = load i64, ptr %t565, !tbaa !24
  store i64 %t566, ptr %l39, !tbaa !24
  %t568 = load ptr, ptr %l38, !tbaa !29
  %t570 = getelementptr %"compiler/typed:Body", ptr %t568, i32 0, i32 5
  %t572 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t570)
  store i64 %t572, ptr %l291
  br label %bb121
bb121:
  %t573 = load i64, ptr %l291, !tbaa !24
  store i64 %t573, ptr %l40, !tbaa !24
  store i64 1, ptr %l41, !tbaa !24
  %t574 = load i64, ptr %l40, !tbaa !24
  %t575 = load i64, ptr %l39, !tbaa !24
  %t578 = icmp sgt i64 %t574, %t575
  br i1 %t578, label %bb122, label %bb123
bb122:
  %t580 = load i64, ptr %l41, !tbaa !24
  %t582 = icmp sgt i64 %t580, 0
  br i1 %t582, label %bb124, label %bb125
bb123:
  store i64 0, ptr %l295, !tbaa !24
  br label %bb127
bb124:
  %t584 = load i64, ptr %l40, !tbaa !24
  %t585 = load i64, ptr %l39, !tbaa !24
  %t588 = sub i64 %t584, %t585
  %t589 = load i64, ptr %l41, !tbaa !24
  %t592 = add i64 %t588, %t589
  %t594 = sub i64 %t592, 1
  %t595 = load i64, ptr %l41, !tbaa !24
  %t598 = sdiv i64 %t594, %t595
  store i64 %t598, ptr %l298, !tbaa !24
  br label %bb126
bb125:
  store i64 0, ptr %l298, !tbaa !24
  br label %bb126
bb126:
  %t600 = load i64, ptr %l298, !tbaa !24
  store i64 %t600, ptr %l295, !tbaa !24
  br label %bb127
bb127:
  %t601 = load i64, ptr %l295, !tbaa !24
  store i64 %t601, ptr %l42, !tbaa !24
  store i64 0, ptr %l43, !tbaa !24
  br label %bb128
bb128:
  store %olang.scope zeroinitializer, ptr %s26
  %t602 = load i64, ptr %l43, !tbaa !24
  %t603 = load i64, ptr %l42, !tbaa !24
  %t606 = icmp slt i64 %t602, %t603
  %t608 = xor i1 %t606, true
  br i1 %t608, label %bb129, label %bb130
bb129:
  call void @__olang_scope_close(ptr %s26)
  br label %bb144
bb130:
  br label %bb131
bb131:
  %t610 = load i64, ptr %l39, !tbaa !24
  %t611 = load i64, ptr %l43, !tbaa !24
  %t612 = load i64, ptr %l41, !tbaa !24
  %t615 = mul i64 %t611, %t612
  %t618 = add i64 %t610, %t615
  store i64 %t618, ptr %l44, !tbaa !24
  %t620 = load ptr, ptr %l0, !tbaa !29
  %t622 = getelementptr %"compiler/check:Checker", ptr %t620, i32 0, i32 56
  store ptr %t622, ptr %l317, !tbaa !29
  %t623 = getelementptr %"compiler/check:roFn", ptr %l37, i32 0, i32 0
  %t624 = load i64, ptr %t623, !tbaa !24
  %t625 = load i64, ptr %l44, !tbaa !24
  %t628 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s26, i64 %t624, i64 %t625)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t628, ptr %l320
  br label %bb132
bb132:
  %t629 = load ptr, ptr %l317, !tbaa !29
  %t630 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l320
  %t631 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %t629, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t630)
  store i1 %t631, ptr %l321
  br label %bb133
bb133:
  %t632 = load i1, ptr %l321, !tbaa !21
  %t633 = xor i1 %t632, true
  br i1 %t633, label %bb134, label %bb135
bb134:
  call void @__olang_scope_close(ptr %s26)
  br label %bb143
bb135:
  br label %bb136
bb136:
  %t635 = load ptr, ptr %l38, !tbaa !29
  store ptr %t635, ptr %l323, !tbaa !29
  %t636 = load ptr, ptr %l38, !tbaa !29
  %t638 = getelementptr %"compiler/typed:Body", ptr %t636, i32 0, i32 5
  %t639 = load i64, ptr %l44, !tbaa !24
  %t642 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t638, i64 %t639)
  store i32 %t642, ptr %l327
  br label %bb137
bb137:
  %t643 = load ptr, ptr %l323, !tbaa !29
  %t644 = load i32, ptr %l327, !tbaa !23
  %t645 = call %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %t643, i32 %t644)
  store %"compiler/typed:Local" %t645, ptr %l328
  br label %bb138
bb138:
  %t646 = load %"compiler/typed:Local", ptr %l328
  store %"compiler/typed:Local" %t646, ptr %l45
  %t647 = load ptr, ptr %l0, !tbaa !29
  %t648 = getelementptr %"compiler/typed:Local", ptr %l45, i32 0, i32 2
  %t649 = load i32, ptr %t648, !tbaa !23
  %t652 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroFix(ptr %v0, ptr %s26, ptr %t647, i32 0, i32 %t649)
  store { i64, ptr } %t652, ptr %l331
  br label %bb139
bb139:
  %t653 = load { i64, ptr }, ptr %l331, !tbaa !27
  store { i64, ptr } %t653, ptr %l46, !tbaa !27
  %t654 = load ptr, ptr %l0, !tbaa !29
  %t656 = getelementptr %"compiler/check:Checker", ptr %t654, i32 0, i32 1
  %t657 = load ptr, ptr %t656, !tbaa !29
  %t659 = getelementptr %"compiler/generic:Program", ptr %t657, i32 0, i32 0
  %t660 = load ptr, ptr %t659, !tbaa !29
  %t662 = getelementptr %"compiler/load:Loader", ptr %t660, i32 0, i32 4
  %t663 = load ptr, ptr %t662, !tbaa !29
  store ptr %t663, ptr %l335, !tbaa !29
  %t664 = getelementptr %"compiler/check:roFn", ptr %l37, i32 0, i32 2
  %t665 = load { i64, [3 x i64] }, ptr %t664
  store { i64, [3 x i64] } %t665, ptr %l336
  %t666 = getelementptr %"compiler/check:roFn", ptr %l37, i32 0, i32 3
  %t667 = load { i64, ptr }, ptr %t666, !tbaa !27
  store { i64, ptr } %t667, ptr %l337, !tbaa !27
  %t668 = load ptr, ptr %l0, !tbaa !29
  %t669 = getelementptr %"compiler/typed:Local", ptr %l45, i32 0, i32 0
  %t670 = load i32, ptr %t669, !tbaa !23
  %t673 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t668, i32 %t670)
  store { i64, ptr } %t673, ptr %l340
  br label %bb140
bb140:
  %t674 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t675 = load { i64, ptr }, ptr %l337, !tbaa !27
  %t676 = load { i64, ptr }, ptr %l340, !tbaa !27
  %t678 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eReadOnlyFuncValue(ptr %v0, ptr %v0, ptr %s26, ptr %s26, { i64, ptr } %t675, { i64, ptr } %t676, { i64, ptr } %t674)
  store %"compiler/msgs:Msg" %t678, ptr %l342
  br label %bb141
bb141:
  %t679 = load ptr, ptr %l335, !tbaa !29
  %t680 = load { i64, [3 x i64] }, ptr %l336
  %t681 = load %"compiler/msgs:Msg", ptr %l342
  %t682 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s26, ptr %t679, { i64, [3 x i64] } %t680, %"compiler/msgs:Msg" %t681)
  store i64 %t682, ptr %l343
  br label %bb142
bb142:
  call void @__olang_scope_close(ptr %s26)
  br label %bb144
bb143:
  %t683 = load i64, ptr %l43, !tbaa !24
  %t685 = add i64 %t683, 1
  store i64 %t685, ptr %l43, !tbaa !24
  br label %bb128
bb144:
  call void @__olang_scope_close(ptr %s24)
  br label %bb145
bb145:
  %t687 = load i64, ptr %l36, !tbaa !24
  %t689 = add i64 %t687, 1
  store i64 %t689, ptr %l36, !tbaa !24
  br label %bb116
bb146:
  %t691 = load i64, ptr %l33, !tbaa !24
  %t692 = load i64, ptr %l35, !tbaa !24
  %t695 = add i64 %t691, %t692
  store i64 %t695, ptr %l33, !tbaa !24
  call void @__olang_scope_close(ptr %s23)
  br label %bb147
bb147:
  br label %bb109
bb148:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroSettleResults(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca %"std/pair:Pair.1eb2466213689e002f25e81e83536e78"
  %l8 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l17 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l21 = alloca i32
  %l30 = alloca { i64, ptr }
  %l36 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l42 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l46 = alloca i32
  %l55 = alloca { i64, ptr }
  %l59 = alloca ptr
  %l62 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 62
  store ptr %t3, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load i64, ptr %l3, !tbaa !24
  %t9 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3cI64_2c_20compil_Hd792a4b485af98ba4ad9cd9a7f4f4722(ptr %v0, ptr %t5, i64 %t6)
  %t10 = extractvalue { i32, { i64, ptr } } %t9, 1
  %t11 = extractvalue { i32, { i64, ptr } } %t9, 0
  store i32 %t11, ptr %l21
  %t12 = icmp ne i32 %t11, 0
  br i1 %t12, label %bb3, label %ok.13
ok.13:
  store { i64, ptr } %t10, ptr %l20
  br label %bb2
bb2:
  %t14 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t14, ptr %l17, !tbaa !27
  br label %bb7
bb3:
  %t15 = load i32, ptr %l21, !tbaa !23
  %t16 = ashr i32 %t15, 16
  %t18 = icmp eq i32 %t16, 1
  br i1 %t18, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  call void @__olang_check_failed(ptr @olang_loc_674cd1771ebc67df_c0fbe9e0645b3c13)
  unreachable
bb6:
  call void @__olang_scope_close(ptr %s2)
  br label %bb37
bb7:
  %t20 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t20, ptr %l4, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t21, 0
  store i64 %t23, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t25 = load i64, ptr %l6, !tbaa !24
  %t26 = load i64, ptr %l5, !tbaa !24
  %t29 = icmp slt i64 %t25, %t26
  %t31 = xor i1 %t29, true
  br i1 %t31, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb35
bb10:
  br label %bb11
bb11:
  %t33 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t33, ptr %l30, !tbaa !27
  %t34 = load i64, ptr %l6, !tbaa !24
  %t36 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr %"std/pair:Pair.1eb2466213689e002f25e81e83536e78", ptr %t37, i64 %t34
  %t39 = load %"std/pair:Pair.1eb2466213689e002f25e81e83536e78", ptr %t38
  store %"std/pair:Pair.1eb2466213689e002f25e81e83536e78" %t39, ptr %l7
  %t41 = getelementptr %"std/pair:Pair.1eb2466213689e002f25e81e83536e78", ptr %l7, i32 0, i32 0
  %t42 = load i64, ptr %t41, !tbaa !24
  %t43 = load i64, ptr %l1, !tbaa !24
  %t46 = icmp ne i64 %t42, %t43
  br i1 %t46, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s3)
  br label %bb34
bb13:
  br label %bb14
bb14:
  %t48 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %s3)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t48, ptr %l36
  br label %bb15
bb15:
  %t49 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l36
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t49, ptr %l8
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t51 = load i64, ptr %l1, !tbaa !24
  %t52 = getelementptr %"std/pair:Pair.1eb2466213689e002f25e81e83536e78", ptr %l7, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroDeep(ptr %v0, ptr %v0, ptr %s3, ptr %t50, i64 %t51, ptr %t53, ptr %l8)
  br label %bb16
bb16:
  store ptr %l8, ptr %l9, !tbaa !29
  store i64 0, ptr %l10, !tbaa !24
  br label %bb17
bb17:
  store %olang.scope zeroinitializer, ptr %s6
  %t59 = load ptr, ptr %l9, !tbaa !29
  %t60 = load i64, ptr %l10, !tbaa !24
  %t63 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %s3, ptr %t59, i64 %t60)
  %t64 = extractvalue { i32, { i64, ptr } } %t63, 1
  %t65 = extractvalue { i32, { i64, ptr } } %t63, 0
  store i32 %t65, ptr %l46
  %t66 = icmp ne i32 %t65, 0
  br i1 %t66, label %bb19, label %ok.67
ok.67:
  store { i64, ptr } %t64, ptr %l45
  br label %bb18
bb18:
  %t68 = load { i64, ptr }, ptr %l45, !tbaa !27
  store { i64, ptr } %t68, ptr %l42, !tbaa !27
  br label %bb23
bb19:
  %t69 = load i32, ptr %l46, !tbaa !23
  %t70 = ashr i32 %t69, 16
  %t72 = icmp eq i32 %t70, 1
  br i1 %t72, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_4accb82e327e9b5e_83bcad9ba4931212)
  unreachable
bb22:
  call void @__olang_scope_close(ptr %s6)
  br label %bb33
bb23:
  %t74 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t74, ptr %l11, !tbaa !27
  %t75 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t77 = extractvalue { i64, ptr } %t75, 0
  store i64 %t77, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb24
bb24:
  store %olang.scope zeroinitializer, ptr %s7
  %t79 = load i64, ptr %l13, !tbaa !24
  %t80 = load i64, ptr %l12, !tbaa !24
  %t83 = icmp slt i64 %t79, %t80
  %t85 = xor i1 %t83, true
  br i1 %t85, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s7)
  br label %bb31
bb26:
  br label %bb27
bb27:
  %t87 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t87, ptr %l55, !tbaa !27
  %t88 = load i64, ptr %l13, !tbaa !24
  %t90 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t91 = load ptr, ptr %t90, !tbaa !27
  %t92 = getelementptr i64, ptr %t91, i64 %t88
  %t93 = load i64, ptr %t92, !tbaa !34
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr %"compiler/check:Checker", ptr %t95, i32 0, i32 61
  store ptr %t97, ptr %l59, !tbaa !29
  %t98 = load i64, ptr %l1, !tbaa !24
  %t102 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s7, i64 %t98, i64 %t93)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t102, ptr %l62
  br label %bb28
bb28:
  %t103 = load ptr, ptr %l59, !tbaa !29
  %t104 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l62
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %t103, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t104, i1 true)
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s7)
  br label %bb30
bb30:
  %t105 = load i64, ptr %l13, !tbaa !24
  %t107 = add i64 %t105, 1
  store i64 %t107, ptr %l13, !tbaa !24
  br label %bb24
bb31:
  %t109 = load i64, ptr %l10, !tbaa !24
  %t110 = load i64, ptr %l12, !tbaa !24
  %t113 = add i64 %t109, %t110
  store i64 %t113, ptr %l10, !tbaa !24
  call void @__olang_scope_close(ptr %s6)
  br label %bb32
bb32:
  br label %bb17
bb33:
  call void @__olang_scope_close(ptr %s3)
  br label %bb34
bb34:
  %t115 = load i64, ptr %l6, !tbaa !24
  %t117 = add i64 %t115, 1
  store i64 %t117, ptr %l6, !tbaa !24
  br label %bb8
bb35:
  %t119 = load i64, ptr %l3, !tbaa !24
  %t120 = load i64, ptr %l5, !tbaa !24
  %t123 = add i64 %t119, %t120
  store i64 %t123, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb36
bb36:
  br label %bb1
bb37:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etempValue(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i1
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca i1
  %l25 = alloca ptr
  %l26 = alloca ptr
  %l27 = alloca i1
  %l35 = alloca ptr
  %l36 = alloca ptr
  %l37 = alloca i1
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l7, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t20 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etempValue(ptr %v0, ptr %v1, ptr %t16, ptr %t17)
  store ptr %t20, ptr %l15
  br label %bb6
bb6:
  %t21 = load ptr, ptr %l15, !tbaa !29
  store ptr %t21, ptr %l6, !tbaa !29
  br label %bb32
bb7:
  %t22 = load ptr, ptr %l1, !tbaa !29
  store ptr %t22, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t23 = load ptr, ptr %l16, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t26 = load ptr, ptr %l16, !tbaa !29
  %t27 = load i64, ptr %t26
  %t29 = icmp eq i64 %t27, 4
  store i1 %t29, ptr %l17, !tbaa !21
  br label %bb9
bb9:
  %t30 = load i1, ptr %l17, !tbaa !21
  br i1 %t30, label %bb10, label %bb11
bb10:
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr { i64, [4 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t33, i32 0, i32 2
  %t35 = load ptr, ptr %t34
  store ptr %t35, ptr %l3, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load ptr, ptr %l3, !tbaa !29
  %t40 = getelementptr %"compiler/typed:Elem", ptr %t38, i32 0, i32 0
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t44 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etempValue(ptr %v0, ptr %v1, ptr %t37, ptr %t41)
  store ptr %t44, ptr %l25
  br label %bb13
bb13:
  %t45 = load ptr, ptr %l25, !tbaa !29
  store ptr %t45, ptr %l6, !tbaa !29
  br label %bb32
bb14:
  %t46 = load ptr, ptr %l1, !tbaa !29
  store ptr %t46, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t47 = load ptr, ptr %l26, !tbaa !29
  %t48 = icmp ne ptr %t47, null
  br i1 %t48, label %bb15, label %bb16
bb15:
  %t50 = load ptr, ptr %l26, !tbaa !29
  %t51 = load i64, ptr %t50
  %t53 = icmp eq i64 %t51, 5
  store i1 %t53, ptr %l27, !tbaa !21
  br label %bb16
bb16:
  %t54 = load i1, ptr %l27, !tbaa !21
  br i1 %t54, label %bb17, label %bb18
bb17:
  %t55 = load ptr, ptr %l1, !tbaa !29
  %t57 = getelementptr { i64, [4 x i64] }, ptr %t55, i32 0, i32 1
  %t58 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t57, i32 0, i32 2
  %t59 = load ptr, ptr %t58
  store ptr %t59, ptr %l4, !tbaa !29
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = load ptr, ptr %l4, !tbaa !29
  %t64 = getelementptr %"compiler/typed:Payload", ptr %t62, i32 0, i32 0
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t68 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etempValue(ptr %v0, ptr %v1, ptr %t61, ptr %t65)
  store ptr %t68, ptr %l35
  br label %bb20
bb20:
  %t69 = load ptr, ptr %l35, !tbaa !29
  store ptr %t69, ptr %l6, !tbaa !29
  br label %bb32
bb21:
  %t70 = load ptr, ptr %l1, !tbaa !29
  store ptr %t70, ptr %l36, !tbaa !29
  store i1 false, ptr %l37, !tbaa !21
  %t71 = load ptr, ptr %l36, !tbaa !29
  %t72 = icmp ne ptr %t71, null
  br i1 %t72, label %bb22, label %bb23
bb22:
  %t74 = load ptr, ptr %l36, !tbaa !29
  %t75 = load i64, ptr %t74
  %t77 = icmp eq i64 %t75, 6
  store i1 %t77, ptr %l37, !tbaa !21
  br label %bb23
bb23:
  %t78 = load i1, ptr %l37, !tbaa !21
  br i1 %t78, label %bb24, label %bb25
bb24:
  %t79 = load ptr, ptr %l1, !tbaa !29
  %t81 = getelementptr { i64, [4 x i64] }, ptr %t79, i32 0, i32 1
  %t82 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t81, i32 0, i32 2
  %t83 = load ptr, ptr %t82
  store ptr %t83, ptr %l5, !tbaa !29
  br label %bb26
bb25:
  br label %bb27
bb26:
  %t85 = load ptr, ptr %l5, !tbaa !29
  store ptr %t85, ptr %l6, !tbaa !29
  br label %bb32
bb27:
  br i1 true, label %bb28, label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb31
bb30:
  store ptr null, ptr %l6, !tbaa !29
  br label %bb32
bb31:
  call void @__olang_check_failed(ptr @olang_loc_8e2cf6b2c24620f0_dcbb1c47a1cef46c)
  unreachable
bb32:
  %t88 = load ptr, ptr %l6, !tbaa !29
  store ptr %t88, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etraitHeader(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i32
  %l9 = alloca i32
  %l10 = alloca i1
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca i1
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca ptr
  %l20 = alloca i1
  %l21 = alloca i32
  %l22 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i32
  %l27 = alloca %"compiler/generic:Unmet"
  %l30 = alloca i1
  %l36 = alloca ptr
  %l37 = alloca i1
  %l47 = alloca i1
  %l56 = alloca i64
  %l63 = alloca i32
  %l67 = alloca ptr
  %l68 = alloca ptr
  %l72 = alloca %"compiler/generic:Context"
  %l76 = alloca i32
  %l84 = alloca { i64, ptr }
  %l90 = alloca i1
  %l92 = alloca ptr
  %l94 = alloca %"compiler/source:Span"
  %l95 = alloca ptr
  %l97 = alloca %"compiler/source:Span"
  %l98 = alloca { i64, ptr }
  %l99 = alloca %"compiler/msgs:Msg"
  %l100 = alloca i64
  %l105 = alloca i1
  %l109 = alloca i1
  %l113 = alloca i1
  %l114 = alloca ptr
  %l115 = alloca { i64, ptr }
  %l117 = alloca %"compiler/source:Span"
  %l121 = alloca { i64, ptr }
  %l123 = alloca %"compiler/msgs:Msg"
  %l124 = alloca i64
  %l127 = alloca i1
  %l139 = alloca { i64, ptr }
  %l145 = alloca i1
  %l147 = alloca i32
  %l149 = alloca ptr
  %l151 = alloca ptr
  %l156 = alloca i32
  %l160 = alloca i32
  %l171 = alloca i1
  %l173 = alloca ptr
  %l175 = alloca %"compiler/source:Span"
  %l176 = alloca ptr
  %l178 = alloca %"compiler/source:Span"
  %l179 = alloca { i64, ptr }
  %l180 = alloca %"compiler/msgs:Msg"
  %l181 = alloca i64
  %l185 = alloca { i64, ptr }
  %l187 = alloca i64
  %l198 = alloca { i64, ptr }
  %l205 = alloca %"compiler/generic:Unmet"
  %l208 = alloca i1
  %l210 = alloca ptr
  %l212 = alloca %"compiler/source:Span"
  %l215 = alloca { i64, ptr }
  %l216 = alloca { i64, ptr }
  %l220 = alloca { i64, ptr }
  %l221 = alloca { i64, ptr }
  %l224 = alloca { i64, ptr }
  %l226 = alloca %"compiler/msgs:Msg"
  %l227 = alloca i64
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb3
bb2:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t7 = getelementptr %"compiler/ast:TypeDecl", ptr %t5, i32 0, i32 3
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = icmp eq ptr %t8, null
  store i1 %t10, ptr %l30, !tbaa !21
  br label %bb3
bb3:
  %t12 = load i1, ptr %l30, !tbaa !21
  br i1 %t12, label %bb4, label %bb5
bb4:
  br label %ret
bb5:
  br label %bb6
bb6:
  %t13 = load ptr, ptr %l2, !tbaa !29
  %t15 = getelementptr %"compiler/ast:TypeDecl", ptr %t13, i32 0, i32 3
  %t16 = load ptr, ptr %t15, !tbaa !29
  store ptr %t16, ptr %l3, !tbaa !29
  %t18 = load ptr, ptr %l3, !tbaa !29
  store ptr %t18, ptr %l36, !tbaa !29
  store i1 false, ptr %l37, !tbaa !21
  %t19 = load ptr, ptr %l36, !tbaa !29
  %t20 = icmp ne ptr %t19, null
  br i1 %t20, label %bb7, label %bb8
bb7:
  %t22 = load ptr, ptr %l36, !tbaa !29
  %t23 = load i64, ptr %t22
  %t25 = icmp eq i64 %t23, 2
  store i1 %t25, ptr %l37, !tbaa !21
  br label %bb8
bb8:
  %t26 = load i1, ptr %l37, !tbaa !21
  br i1 %t26, label %bb9, label %bb10
bb9:
  %t27 = load ptr, ptr %l3, !tbaa !29
  %t29 = getelementptr { i64, [6 x i64] }, ptr %t27, i32 0, i32 1
  %t30 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t29, i32 0, i32 1
  %t31 = load { i64, ptr }, ptr %t30
  store { i64, ptr } %t31, ptr %l4, !tbaa !27
  %t33 = load ptr, ptr %l3, !tbaa !29
  %t35 = getelementptr { i64, [6 x i64] }, ptr %t33, i32 0, i32 1
  %t36 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t35, i32 0, i32 2
  %t37 = load { i64, ptr }, ptr %t36
  store { i64, ptr } %t37, ptr %l5, !tbaa !27
  br label %bb11
bb10:
  br label %bb113
bb11:
  %t39 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t39, 0
  %t43 = icmp eq i64 %t41, 0
  br i1 %t43, label %bb12, label %bb13
bb12:
  %t45 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t47 = extractvalue { i64, ptr } %t45, 0
  %t49 = icmp eq i64 %t47, 0
  store i1 %t49, ptr %l47, !tbaa !21
  br label %bb14
bb13:
  store i1 false, ptr %l47, !tbaa !21
  br label %bb14
bb14:
  %t51 = load i1, ptr %l47, !tbaa !21
  br i1 %t51, label %bb15, label %bb16
bb15:
  br label %ret
bb16:
  br label %bb17
bb17:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/check:Checker", ptr %t52, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !29
  %t56 = load i64, ptr %l1, !tbaa !24
  %t57 = load ptr, ptr %l2, !tbaa !29
  %t59 = getelementptr %"compiler/ast:TypeDecl", ptr %t57, i32 0, i32 0
  %t60 = load i32, ptr %t59, !tbaa !23
  %t64 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeEntry(ptr %v0, ptr %t55, i64 %t56, i32 %t60)
  store i64 %t64, ptr %l56
  br label %bb18
bb18:
  %t65 = load i64, ptr %l56, !tbaa !24
  store i64 %t65, ptr %l6, !tbaa !24
  %t66 = load i64, ptr %l6, !tbaa !24
  %t68 = icmp slt i64 %t66, 0
  br i1 %t68, label %bb19, label %bb20
bb19:
  br label %ret
bb20:
  br label %bb21
bb21:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/check:Checker", ptr %t70, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !29
  %t74 = load i64, ptr %l1, !tbaa !24
  %t75 = load i64, ptr %l6, !tbaa !24
  %t79 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %t73, i64 %t74, i64 %t75)
  store i32 %t79, ptr %l63
  br label %bb22
bb22:
  %t80 = load i32, ptr %l63, !tbaa !23
  store i32 %t80, ptr %l7, !tbaa !23
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t82 = load i64, ptr %l1, !tbaa !24
  %t83 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t87 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %t81, i64 -1, i64 %t82, i32 %t83, i32 0)
  store ptr %t87, ptr %l67
  br label %bb23
bb23:
  %t88 = load ptr, ptr %l67, !tbaa !29
  store ptr %t88, ptr %l68, !tbaa !29
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/check:Checker", ptr %t90, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !29
  %t94 = load i32, ptr %l7, !tbaa !23
  %t97 = call %"compiler/generic:Context" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclContext(ptr %v0, ptr %v0, ptr %t93, i32 %t94)
  store %"compiler/generic:Context" %t97, ptr %l72
  br label %bb24
bb24:
  %t98 = load %"compiler/generic:Context", ptr %l72
  %t99 = load ptr, ptr %l68, !tbaa !29
  %t100 = getelementptr %"compiler/check:frame", ptr %t99, i32 0, i32 4
  store %"compiler/generic:Context" %t98, ptr %t100
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr %"compiler/check:Checker", ptr %t101, i32 0, i32 1
  %t104 = load ptr, ptr %t103, !tbaa !29
  %t105 = load i32, ptr %l7, !tbaa !23
  %t108 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSelfType(ptr %v0, ptr %t104, i32 %t105)
  store i32 %t108, ptr %l76
  br label %bb25
bb25:
  %t109 = load i32, ptr %l76, !tbaa !23
  store i32 %t109, ptr %l9, !tbaa !23
  store i1 false, ptr %l10, !tbaa !21
  %t110 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t110, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t112 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t112, 0
  store i64 %t114, ptr %l13, !tbaa !24
  br label %bb26
bb26:
  store %olang.scope zeroinitializer, ptr %s6
  %t116 = load i64, ptr %l12, !tbaa !24
  %t117 = load i64, ptr %l13, !tbaa !24
  %t120 = icmp slt i64 %t116, %t117
  %t122 = xor i1 %t120, true
  br i1 %t122, label %bb27, label %bb28
bb27:
  call void @__olang_scope_close(ptr %s6)
  br label %bb40
bb28:
  br label %bb29
bb29:
  %t124 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t124, ptr %l84, !tbaa !27
  %t125 = load i64, ptr %l12, !tbaa !24
  %t127 = getelementptr { i64, ptr }, ptr %l84, i32 0, i32 1
  %t128 = load ptr, ptr %t127, !tbaa !27
  %t129 = getelementptr ptr, ptr %t128, i64 %t125
  %t130 = load ptr, ptr %t129, !tbaa !39
  store ptr %t130, ptr %l14, !tbaa !29
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t133 = load i64, ptr %l1, !tbaa !24
  %t134 = load ptr, ptr %l14, !tbaa !29
  %t138 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etraitRef(ptr %v0, ptr %v1, ptr %t132, i64 %t133, ptr %t134)
  store i1 %t138, ptr %l90
  br label %bb30
bb30:
  %t139 = load i1, ptr %l90, !tbaa !21
  %t140 = xor i1 %t139, true
  br i1 %t140, label %bb31, label %bb32
bb31:
  store %olang.scope zeroinitializer, ptr %s7
  %t142 = load ptr, ptr %l0, !tbaa !29
  store ptr %t142, ptr %l92, !tbaa !29
  %t143 = load ptr, ptr %l14, !tbaa !29
  %t145 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t143)
  store %"compiler/source:Span" %t145, ptr %l94
  br label %bb33
bb32:
  br label %bb38
bb33:
  %t146 = load ptr, ptr %l0, !tbaa !29
  store ptr %t146, ptr %l95, !tbaa !29
  %t147 = load ptr, ptr %l14, !tbaa !29
  %t149 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t147)
  store %"compiler/source:Span" %t149, ptr %l97
  br label %bb34
bb34:
  %t150 = load ptr, ptr %l95, !tbaa !29
  %t151 = load %"compiler/source:Span", ptr %l97
  %t152 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %t150, %"compiler/source:Span" %t151)
  store { i64, ptr } %t152, ptr %l98
  br label %bb35
bb35:
  %t153 = load { i64, ptr }, ptr %l98, !tbaa !27
  %t154 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTraitExtendsNotTrait(ptr %v0, ptr %s7, { i64, ptr } %t153)
  store %"compiler/msgs:Msg" %t154, ptr %l99
  br label %bb36
bb36:
  %t155 = load ptr, ptr %l92, !tbaa !29
  %t156 = load %"compiler/source:Span", ptr %l94
  %t157 = load %"compiler/msgs:Msg", ptr %l99
  %t158 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s7, ptr %t155, %"compiler/source:Span" %t156, %"compiler/msgs:Msg" %t157)
  store i64 %t158, ptr %l100
  br label %bb37
bb37:
  store i1 true, ptr %l10, !tbaa !21
  call void @__olang_scope_close(ptr %s7)
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s6)
  br label %bb39
bb39:
  %t159 = load i64, ptr %l12, !tbaa !24
  %t161 = add i64 %t159, 1
  store i64 %t161, ptr %l12, !tbaa !24
  br label %bb26
bb40:
  %t163 = load i1, ptr %l10, !tbaa !21
  %t165 = xor i1 %t163, true
  br i1 %t165, label %bb41, label %bb42
bb41:
  %t167 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t169 = extractvalue { i64, ptr } %t167, 0
  %t171 = icmp sgt i64 %t169, 0
  store i1 %t171, ptr %l105, !tbaa !21
  br label %bb43
bb42:
  store i1 false, ptr %l105, !tbaa !21
  br label %bb43
bb43:
  %t173 = load i1, ptr %l105, !tbaa !21
  br i1 %t173, label %bb44, label %bb45
bb44:
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t175 = load i32, ptr %l7, !tbaa !23
  %t176 = load i32, ptr %l9, !tbaa !23
  %t180 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereachesTrait(ptr %v0, ptr %t174, i32 %t175, i32 %t176, i64 0)
  store i1 %t180, ptr %l113
  br label %bb46
bb45:
  store i1 false, ptr %l109, !tbaa !21
  br label %bb47
bb46:
  %t181 = load i1, ptr %l113, !tbaa !21
  store i1 %t181, ptr %l109, !tbaa !21
  br label %bb47
bb47:
  %t182 = load i1, ptr %l109, !tbaa !21
  br i1 %t182, label %bb48, label %bb49
bb48:
  store %olang.scope zeroinitializer, ptr %s9
  %t183 = load ptr, ptr %l0, !tbaa !29
  store ptr %t183, ptr %l114, !tbaa !29
  %t184 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t184, ptr %l115, !tbaa !27
  %t185 = getelementptr { i64, ptr }, ptr %l115, i32 0, i32 1
  %t186 = load ptr, ptr %t185, !tbaa !27
  %t187 = getelementptr ptr, ptr %t186, i64 0
  %t188 = load ptr, ptr %t187, !tbaa !39
  %t190 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t188)
  store %"compiler/source:Span" %t190, ptr %l117
  br label %bb50
bb49:
  br label %bb54
bb50:
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t192 = load ptr, ptr %l2, !tbaa !29
  %t194 = getelementptr %"compiler/ast:TypeDecl", ptr %t192, i32 0, i32 0
  %t195 = load i32, ptr %t194, !tbaa !23
  %t198 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s9, ptr %t191, i32 %t195)
  store { i64, ptr } %t198, ptr %l121
  br label %bb51
bb51:
  %t199 = load { i64, ptr }, ptr %l121, !tbaa !27
  %t200 = extractvalue { i64, ptr } %t199, 0
  %t201 = extractvalue { i64, ptr } %t199, 1
  %t202 = mul i64 %t200, 1
  %t203 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t202)
  call void @llvm.memcpy.p0.p0.i64(ptr %t203, ptr %t201, i64 %t202, i1 false)
  %t204 = insertvalue { i64, ptr } undef, i64 %t200, 0
  %t205 = insertvalue { i64, ptr } %t204, ptr %t203, 1
  %t207 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTraitExtendsItself(ptr %s9, ptr %s9, { i64, ptr } %t205)
  store %"compiler/msgs:Msg" %t207, ptr %l123
  br label %bb52
bb52:
  %t208 = load ptr, ptr %l114, !tbaa !29
  %t209 = load %"compiler/source:Span", ptr %l117
  %t210 = load %"compiler/msgs:Msg", ptr %l123
  %t211 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s9, ptr %t208, %"compiler/source:Span" %t209, %"compiler/msgs:Msg" %t210)
  store i64 %t211, ptr %l124
  br label %bb53
bb53:
  store i1 true, ptr %l10, !tbaa !21
  call void @__olang_scope_close(ptr %s9)
  br label %bb54
bb54:
  %t212 = load i1, ptr %l10, !tbaa !21
  %t214 = xor i1 %t212, true
  br i1 %t214, label %bb55, label %bb56
bb55:
  %t216 = load ptr, ptr %l2, !tbaa !29
  %t218 = getelementptr %"compiler/ast:TypeDecl", ptr %t216, i32 0, i32 1
  %t219 = load { i64, ptr }, ptr %t218, !tbaa !27
  %t221 = extractvalue { i64, ptr } %t219, 0
  %t223 = icmp eq i64 %t221, 0
  store i1 %t223, ptr %l127, !tbaa !21
  br label %bb57
bb56:
  store i1 false, ptr %l127, !tbaa !21
  br label %bb57
bb57:
  %t225 = load i1, ptr %l127, !tbaa !21
  store i1 %t225, ptr %l15, !tbaa !21
  %t226 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t226, ptr %l16, !tbaa !27
  store i64 0, ptr %l17, !tbaa !24
  %t228 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t230 = extractvalue { i64, ptr } %t228, 0
  store i64 %t230, ptr %l18, !tbaa !24
  br label %bb58
bb58:
  store %olang.scope zeroinitializer, ptr %s11
  %t232 = load i64, ptr %l17, !tbaa !24
  %t233 = load i64, ptr %l18, !tbaa !24
  %t236 = icmp slt i64 %t232, %t233
  %t238 = xor i1 %t236, true
  br i1 %t238, label %bb59, label %bb60
bb59:
  call void @__olang_scope_close(ptr %s11)
  br label %bb111
bb60:
  br label %bb61
bb61:
  %t240 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t240, ptr %l139, !tbaa !27
  %t241 = load i64, ptr %l17, !tbaa !24
  %t243 = getelementptr { i64, ptr }, ptr %l139, i32 0, i32 1
  %t244 = load ptr, ptr %t243, !tbaa !27
  %t245 = getelementptr ptr, ptr %t244, i64 %t241
  %t246 = load ptr, ptr %t245, !tbaa !39
  store ptr %t246, ptr %l19, !tbaa !29
  %t248 = load ptr, ptr %l0, !tbaa !29
  %t249 = load i64, ptr %l1, !tbaa !24
  %t250 = load ptr, ptr %l19, !tbaa !29
  %t254 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etraitRef(ptr %v0, ptr %v1, ptr %t248, i64 %t249, ptr %t250)
  store i1 %t254, ptr %l145
  br label %bb62
bb62:
  %t255 = load i1, ptr %l145, !tbaa !21
  store i1 %t255, ptr %l20, !tbaa !21
  %t256 = load i1, ptr %l20, !tbaa !21
  br i1 %t256, label %bb63, label %bb64
bb63:
  %t258 = load ptr, ptr %l0, !tbaa !29
  %t260 = getelementptr %"compiler/check:Checker", ptr %t258, i32 0, i32 1
  %t261 = load ptr, ptr %t260, !tbaa !29
  store ptr %t261, ptr %l149, !tbaa !29
  %t262 = load ptr, ptr %l0, !tbaa !29
  %t264 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t262)
  store ptr %t264, ptr %l151
  br label %bb65
bb64:
  %t265 = load ptr, ptr %l0, !tbaa !29
  %t266 = load ptr, ptr %l19, !tbaa !29
  %t270 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresolve(ptr %v0, ptr %v1, ptr %t265, ptr %t266)
  store i32 %t270, ptr %l160
  br label %bb67
bb65:
  %t271 = load ptr, ptr %l151, !tbaa !29
  %t273 = getelementptr %"compiler/check:frame", ptr %t271, i32 0, i32 4
  %t274 = load ptr, ptr %l19, !tbaa !29
  %t276 = load ptr, ptr %l149, !tbaa !29
  %t279 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eResolve(ptr %v0, ptr %v0, ptr %v1, ptr %t276, ptr %t273, ptr %t274)
  store i32 %t279, ptr %l156
  br label %bb66
bb66:
  %t280 = load i32, ptr %l156, !tbaa !23
  store i32 %t280, ptr %l147, !tbaa !23
  br label %bb68
bb67:
  %t281 = load i32, ptr %l160, !tbaa !23
  store i32 %t281, ptr %l147, !tbaa !23
  br label %bb68
bb68:
  %t282 = load i32, ptr %l147, !tbaa !23
  store i32 %t282, ptr %l21, !tbaa !23
  %t283 = load i32, ptr %l21, !tbaa !23
  %t284 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t287 = icmp eq i32 %t283, %t284
  br i1 %t287, label %bb69, label %bb70
bb69:
  call void @__olang_scope_close(ptr %s11)
  br label %bb110
bb70:
  br label %bb71
bb71:
  %t289 = load i32, ptr %l21, !tbaa !23
  %t291 = insertvalue [1 x i32] undef, i32 %t289, 0
  %t293 = load ptr, ptr @__olang_prog_scope
  %t294 = call ptr @__olang_scope_alloc(ptr %t293, i64 4)
  store [1 x i32] %t291, ptr %t294
  %t295 = insertvalue { i64, ptr } undef, i64 1, 0
  %t296 = insertvalue { i64, ptr } %t295, ptr %t294, 1
  store { i64, ptr } %t296, ptr %l22, !tbaa !27
  %t298 = load i1, ptr %l20, !tbaa !21
  br i1 %t298, label %bb72, label %bb73
bb72:
  %t300 = load ptr, ptr %l0, !tbaa !29
  %t302 = getelementptr %"compiler/check:Checker", ptr %t300, i32 0, i32 1
  %t303 = load ptr, ptr %t302, !tbaa !29
  %t304 = load i32, ptr %l21, !tbaa !23
  %t307 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsClosedTrait(ptr %v0, ptr %t303, i32 %t304)
  store i1 %t307, ptr %l171
  br label %bb74
bb73:
  br label %bb87
bb74:
  %t308 = load i1, ptr %l171, !tbaa !21
  %t309 = xor i1 %t308, true
  br i1 %t309, label %bb75, label %bb76
bb75:
  store %olang.scope zeroinitializer, ptr %s14
  %t311 = load ptr, ptr %l0, !tbaa !29
  store ptr %t311, ptr %l173, !tbaa !29
  %t312 = load ptr, ptr %l19, !tbaa !29
  %t314 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t312)
  store %"compiler/source:Span" %t314, ptr %l175
  br label %bb77
bb76:
  br label %bb82
bb77:
  %t315 = load ptr, ptr %l0, !tbaa !29
  store ptr %t315, ptr %l176, !tbaa !29
  %t316 = load ptr, ptr %l19, !tbaa !29
  %t318 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t316)
  store %"compiler/source:Span" %t318, ptr %l178
  br label %bb78
bb78:
  %t319 = load ptr, ptr %l176, !tbaa !29
  %t320 = load %"compiler/source:Span", ptr %l178
  %t321 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %t319, %"compiler/source:Span" %t320)
  store { i64, ptr } %t321, ptr %l179
  br label %bb79
bb79:
  %t322 = load { i64, ptr }, ptr %l179, !tbaa !27
  %t323 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTraitMemberOpen(ptr %v0, ptr %s14, { i64, ptr } %t322)
  store %"compiler/msgs:Msg" %t323, ptr %l180
  br label %bb80
bb80:
  %t324 = load ptr, ptr %l173, !tbaa !29
  %t325 = load %"compiler/source:Span", ptr %l175
  %t326 = load %"compiler/msgs:Msg", ptr %l180
  %t327 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s14, ptr %t324, %"compiler/source:Span" %t325, %"compiler/msgs:Msg" %t326)
  store i64 %t327, ptr %l181
  br label %bb81
bb81:
  call void @__olang_scope_close(ptr %s14)
  call void @__olang_scope_close(ptr %s11)
  br label %bb110
bb82:
  %t328 = load ptr, ptr %l0, !tbaa !29
  %t330 = getelementptr %"compiler/check:Checker", ptr %t328, i32 0, i32 1
  %t331 = load ptr, ptr %t330, !tbaa !29
  %t332 = load i32, ptr %l21, !tbaa !23
  %t335 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMembers(ptr %v0, ptr %s11, ptr %t331, i32 %t332)
  store { i64, ptr } %t335, ptr %l185
  br label %bb83
bb83:
  %t336 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t337 = extractvalue { i64, ptr } %t336, 0
  %t338 = load { i64, ptr }, ptr %l185, !tbaa !27
  %t339 = extractvalue { i64, ptr } %t338, 0
  store i64 %t339, ptr %l187, !tbaa !24
  %t341 = load i64, ptr %l187, !tbaa !24
  %t342 = icmp eq i64 %t337, %t341
  br i1 %t342, label %bb84, label %bb85
bb84:
  %t344 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t345 = load ptr, ptr %t344, !tbaa !27
  %t346 = getelementptr { i64, ptr }, ptr %l185, i32 0, i32 1
  %t347 = load ptr, ptr %t346, !tbaa !27
  %t348 = load i64, ptr %l187, !tbaa !24
  %t349 = mul i64 %t348, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t345, ptr %t347, i64 %t349, i1 false)
  br label %bb86
bb85:
  %t350 = load { i64, ptr }, ptr %l185, !tbaa !27
  store { i64, ptr } %t350, ptr %l22, !tbaa !27
  br label %bb86
bb86:
  br label %bb87
bb87:
  %t351 = load i1, ptr %l15, !tbaa !21
  %t353 = xor i1 %t351, true
  br i1 %t353, label %bb88, label %bb89
bb88:
  call void @__olang_scope_close(ptr %s11)
  br label %bb110
bb89:
  br label %bb90
bb90:
  %t355 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t355, ptr %l23, !tbaa !27
  store i64 0, ptr %l24, !tbaa !24
  %t357 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t359 = extractvalue { i64, ptr } %t357, 0
  store i64 %t359, ptr %l25, !tbaa !24
  br label %bb91
bb91:
  store %olang.scope zeroinitializer, ptr %s17
  %t361 = load i64, ptr %l24, !tbaa !24
  %t362 = load i64, ptr %l25, !tbaa !24
  %t365 = icmp slt i64 %t361, %t362
  %t367 = xor i1 %t365, true
  br i1 %t367, label %bb92, label %bb93
bb92:
  call void @__olang_scope_close(ptr %s17)
  br label %bb109
bb93:
  br label %bb94
bb94:
  %t369 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t369, ptr %l198, !tbaa !27
  %t370 = load i64, ptr %l24, !tbaa !24
  %t372 = getelementptr { i64, ptr }, ptr %l198, i32 0, i32 1
  %t373 = load ptr, ptr %t372, !tbaa !27
  %t374 = getelementptr i32, ptr %t373, i64 %t370
  %t375 = load i32, ptr %t374, !tbaa !33
  store i32 %t375, ptr %l26, !tbaa !23
  %t377 = load ptr, ptr %l0, !tbaa !29
  %t379 = getelementptr %"compiler/check:Checker", ptr %t377, i32 0, i32 1
  %t380 = load ptr, ptr %t379, !tbaa !29
  %t381 = load i32, ptr %l26, !tbaa !23
  %t382 = load i32, ptr %l9, !tbaa !23
  %t386 = call %"compiler/generic:Unmet" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMissing(ptr %v0, ptr %t380, i32 %t381, i32 %t382, i1 false, i64 0)
  store %"compiler/generic:Unmet" %t386, ptr %l205
  br label %bb95
bb95:
  %t387 = load %"compiler/generic:Unmet", ptr %l205
  store %"compiler/generic:Unmet" %t387, ptr %l27
  %t388 = getelementptr %"compiler/generic:Unmet", ptr %l27, i32 0, i32 0
  %t389 = load i64, ptr %t388, !tbaa !24
  %t391 = icmp sge i64 %t389, 0
  br i1 %t391, label %bb96, label %bb97
bb96:
  %t393 = getelementptr %"compiler/generic:Unmet", ptr %l27, i32 0, i32 3
  %t394 = load i1, ptr %t393, !tbaa !21
  store i1 %t394, ptr %l208, !tbaa !21
  br label %bb98
bb97:
  store i1 false, ptr %l208, !tbaa !21
  br label %bb98
bb98:
  %t396 = load i1, ptr %l208, !tbaa !21
  br i1 %t396, label %bb99, label %bb100
bb99:
  store %olang.scope zeroinitializer, ptr %s18
  %t397 = load ptr, ptr %l0, !tbaa !29
  store ptr %t397, ptr %l210, !tbaa !29
  %t398 = load ptr, ptr %l19, !tbaa !29
  %t400 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t398)
  store %"compiler/source:Span" %t400, ptr %l212
  br label %bb101
bb100:
  br label %bb107
bb101:
  %t401 = load ptr, ptr %l0, !tbaa !29
  %t402 = load i32, ptr %l26, !tbaa !23
  %t405 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s18, ptr %t401, i32 %t402)
  store { i64, ptr } %t405, ptr %l215
  br label %bb102
bb102:
  %t406 = load { i64, ptr }, ptr %l215, !tbaa !27
  %t407 = extractvalue { i64, ptr } %t406, 0
  %t408 = extractvalue { i64, ptr } %t406, 1
  %t409 = mul i64 %t407, 1
  %t410 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t409)
  call void @llvm.memcpy.p0.p0.i64(ptr %t410, ptr %t408, i64 %t409, i1 false)
  %t411 = insertvalue { i64, ptr } undef, i64 %t407, 0
  %t412 = insertvalue { i64, ptr } %t411, ptr %t410, 1
  store { i64, ptr } %t412, ptr %l216, !tbaa !27
  %t413 = load ptr, ptr %l0, !tbaa !29
  %t414 = load ptr, ptr %l2, !tbaa !29
  %t416 = getelementptr %"compiler/ast:TypeDecl", ptr %t414, i32 0, i32 0
  %t417 = load i32, ptr %t416, !tbaa !23
  %t420 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s18, ptr %t413, i32 %t417)
  store { i64, ptr } %t420, ptr %l220
  br label %bb103
bb103:
  %t421 = load { i64, ptr }, ptr %l220, !tbaa !27
  %t422 = extractvalue { i64, ptr } %t421, 0
  %t423 = extractvalue { i64, ptr } %t421, 1
  %t424 = mul i64 %t422, 1
  %t425 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t424)
  call void @llvm.memcpy.p0.p0.i64(ptr %t425, ptr %t423, i64 %t424, i1 false)
  %t426 = insertvalue { i64, ptr } undef, i64 %t422, 0
  %t427 = insertvalue { i64, ptr } %t426, ptr %t425, 1
  store { i64, ptr } %t427, ptr %l221, !tbaa !27
  %t428 = load ptr, ptr %l0, !tbaa !29
  %t429 = getelementptr %"compiler/generic:Unmet", ptr %l27, i32 0, i32 2
  %t430 = load i32, ptr %t429, !tbaa !23
  %t433 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s18, ptr %t428, i32 %t430)
  store { i64, ptr } %t433, ptr %l224
  br label %bb104
bb104:
  %t434 = load { i64, ptr }, ptr %l224, !tbaa !27
  %t435 = extractvalue { i64, ptr } %t434, 0
  %t436 = extractvalue { i64, ptr } %t434, 1
  %t437 = mul i64 %t435, 1
  %t438 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t437)
  call void @llvm.memcpy.p0.p0.i64(ptr %t438, ptr %t436, i64 %t437, i1 false)
  %t439 = insertvalue { i64, ptr } undef, i64 %t435, 0
  %t440 = insertvalue { i64, ptr } %t439, ptr %t438, 1
  %t441 = load { i64, ptr }, ptr %l216, !tbaa !27
  %t442 = load { i64, ptr }, ptr %l221, !tbaa !27
  %t444 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTraitMemberMissing(ptr %s18, ptr %s18, ptr %s18, ptr %s18, { i64, ptr } %t441, { i64, ptr } %t442, { i64, ptr } %t440)
  store %"compiler/msgs:Msg" %t444, ptr %l226
  br label %bb105
bb105:
  %t445 = load ptr, ptr %l210, !tbaa !29
  %t446 = load %"compiler/source:Span", ptr %l212
  %t447 = load %"compiler/msgs:Msg", ptr %l226
  %t448 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s18, ptr %t445, %"compiler/source:Span" %t446, %"compiler/msgs:Msg" %t447)
  store i64 %t448, ptr %l227
  br label %bb106
bb106:
  call void @__olang_scope_close(ptr %s18)
  br label %bb107
bb107:
  call void @__olang_scope_close(ptr %s17)
  br label %bb108
bb108:
  %t449 = load i64, ptr %l24, !tbaa !24
  %t451 = add i64 %t449, 1
  store i64 %t451, ptr %l24, !tbaa !24
  br label %bb91
bb109:
  call void @__olang_scope_close(ptr %s11)
  br label %bb110
bb110:
  %t453 = load i64, ptr %l17, !tbaa !24
  %t455 = add i64 %t453, 1
  store i64 %t455, ptr %l17, !tbaa !24
  br label %bb58
bb111:
  %t457 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t457)
  br label %bb112
bb112:
  br label %bb114
bb113:
  br label %bb114
bb114:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etraitRef(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca %"compiler/names:Ref"
  %l5 = alloca ptr
  %l6 = alloca i1
  %l13 = alloca ptr
  %l19 = alloca ptr
  %l23 = alloca %"compiler/names:Ref"
  %l27 = alloca i1
  %l35 = alloca ptr
  %l40 = alloca i32
  %l41 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l3
  br label %bb5
bb4:
  br label %bb16
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/check:Checker", ptr %t16, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = getelementptr %"compiler/generic:Program", ptr %t19, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !29
  store ptr %t22, ptr %l13, !tbaa !29
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/check:Checker", ptr %t23, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t28 = getelementptr %"compiler/generic:Program", ptr %t26, i32 0, i32 0
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t31 = getelementptr %"compiler/load:Loader", ptr %t29, i32 0, i32 5
  %t35 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t31, i64 %a1)
  store ptr %t35, ptr %l19
  br label %bb6
bb6:
  %t36 = load ptr, ptr %l19, !tbaa !29
  %t38 = getelementptr %"compiler/load:Module", ptr %t36, i32 0, i32 4
  %t39 = load i64, ptr %t38, !tbaa !24
  %t40 = getelementptr %"compiler/source:Span", ptr %l3, i32 0, i32 0
  %t41 = load i32, ptr %t40, !tbaa !23
  %t42 = load ptr, ptr %l13, !tbaa !29
  %t45 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t42, i64 %t39, i32 %t41)
  store %"compiler/names:Ref" %t45, ptr %l23
  br label %bb7
bb7:
  %t46 = load %"compiler/names:Ref", ptr %l23
  store %"compiler/names:Ref" %t46, ptr %l4
  %t47 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 0
  %t48 = load i32, ptr %t47
  %t50 = trunc i64 4 to i32
  %t51 = icmp eq i32 %t48, %t50
  %t53 = xor i1 %t51, true
  br i1 %t53, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb10
bb9:
  %t55 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 2
  %t56 = load i64, ptr %t55, !tbaa !24
  %t58 = icmp slt i64 %t56, 0
  store i1 %t58, ptr %l27, !tbaa !21
  br label %bb10
bb10:
  %t60 = load i1, ptr %l27, !tbaa !21
  br i1 %t60, label %bb11, label %bb12
bb11:
  %t61 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 0
  %t62 = load i32, ptr %t61
  %t64 = trunc i64 7 to i32
  %t65 = icmp eq i32 %t62, %t64
  %t67 = xor i1 %t65, true
  store i1 %t67, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/check:Checker", ptr %t69, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !29
  %t74 = getelementptr %"compiler/generic:Program", ptr %t72, i32 0, i32 2
  store ptr %t74, ptr %l35, !tbaa !29
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/check:Checker", ptr %t75, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !29
  %t79 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 1
  %t80 = load i64, ptr %t79, !tbaa !24
  %t81 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 2
  %t82 = load i64, ptr %t81, !tbaa !24
  %t86 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %t78, i64 %t80, i64 %t82)
  store i32 %t86, ptr %l40
  br label %bb14
bb14:
  %t87 = load ptr, ptr %l35, !tbaa !29
  %t88 = load i32, ptr %l40, !tbaa !23
  %t89 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t87, i32 %t88)
  store i32 %t89, ptr %l41
  br label %bb15
bb15:
  %t90 = load i32, ptr %l41
  %t92 = trunc i64 3 to i32
  %t93 = icmp eq i32 %t90, %t92
  store i1 %t93, ptr %rv
  br label %ret
bb16:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etryExpr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, { i64, ptr } %a3, i1 %a4, i32 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i1
  %l5 = alloca i32
  %l6 = alloca i1
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca i32
  %lp15 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i1
  %l27 = alloca ptr
  %l30 = alloca i64
  %l37 = alloca ptr
  %l40 = alloca ptr
  %l42 = alloca i64
  %l49 = alloca ptr
  %l50 = alloca ptr
  %l59 = alloca i1
  %l62 = alloca i32
  %l65 = alloca i1
  %l67 = alloca i1
  %l69 = alloca ptr
  %l70 = alloca %"compiler/source:Span"
  %l71 = alloca i1
  %l76 = alloca i1
  %l78 = alloca i1
  %l82 = alloca ptr
  %l86 = alloca ptr
  %l89 = alloca i64
  %l96 = alloca i32
  %l98 = alloca i1
  %l101 = alloca i1
  %l102 = alloca i1
  %l107 = alloca i1
  %l109 = alloca i1
  %l111 = alloca i1
  %l112 = alloca i1
  %l116 = alloca i1
  %l121 = alloca i1
  %l126 = alloca i32
  %l127 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l138 = alloca { i64, ptr }
  %l141 = alloca ptr
  %l146 = alloca ptr
  %l154 = alloca i1
  %l155 = alloca i1
  %l159 = alloca ptr
  %l164 = alloca i64
  %l166 = alloca i1
  %l168 = alloca i64
  %l170 = alloca i1
  %l174 = alloca ptr
  %l175 = alloca i32
  %l176 = alloca i32
  %l178 = alloca i32
  %l180 = alloca %"compiler/source:Span"
  %l184 = alloca %"compiler/source:Span"
  %l185 = alloca i32
  %l187 = alloca ptr
  %l189 = alloca { i64, ptr }
  %l191 = alloca %"compiler/typed:Try"
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca ptr
  %t348 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  store i1 %a4, ptr %l4
  store i32 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 35
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  store i1 %t6, ptr %l6, !tbaa !21
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/check:Checker", ptr %t8, i32 0, i32 35
  store i1 false, ptr %t10, !tbaa !21
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t11)
  store ptr %t13, ptr %l27
  br label %bb1
bb1:
  %t14 = load ptr, ptr %l27, !tbaa !29
  store ptr %t14, ptr %l7, !tbaa !29
  %t15 = load ptr, ptr %l7, !tbaa !29
  %t17 = getelementptr %"compiler/check:frame", ptr %t15, i32 0, i32 25
  %t19 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t17)
  store i64 %t19, ptr %l30
  br label %bb2
bb2:
  %t20 = load i64, ptr %l30, !tbaa !24
  store i64 %t20, ptr %l8, !tbaa !24
  %t21 = load ptr, ptr %l7, !tbaa !29
  %t23 = getelementptr %"compiler/check:frame", ptr %t21, i32 0, i32 17
  %t24 = load i64, ptr %t23, !tbaa !24
  store i64 %t24, ptr %l9, !tbaa !24
  %t26 = load ptr, ptr %l7, !tbaa !29
  %t28 = getelementptr %"compiler/check:frame", ptr %t26, i32 0, i32 18
  %t29 = load i64, ptr %t28, !tbaa !24
  store i64 %t29, ptr %l10, !tbaa !24
  %t31 = load ptr, ptr %l7, !tbaa !29
  %t33 = getelementptr %"compiler/check:frame", ptr %t31, i32 0, i32 16
  %t34 = load i64, ptr %t33, !tbaa !24
  store i64 %t34, ptr %l11, !tbaa !24
  %t36 = load ptr, ptr %l7, !tbaa !29
  store ptr %t36, ptr %l37, !tbaa !29
  %t37 = load ptr, ptr %l37, !tbaa !29
  %t38 = getelementptr %"compiler/check:frame", ptr %t37, i32 0, i32 15
  %t39 = load i64, ptr %t38, !tbaa !24
  %t41 = add i64 %t39, 1
  %t43 = load ptr, ptr %l37, !tbaa !29
  %t44 = getelementptr %"compiler/check:frame", ptr %t43, i32 0, i32 15
  store i64 %t41, ptr %t44, !tbaa !24
  %t45 = load ptr, ptr %l7, !tbaa !29
  store ptr %t45, ptr %l40, !tbaa !29
  %t46 = load i1, ptr %l4, !tbaa !21
  br i1 %t46, label %bb3, label %bb4
bb3:
  %t48 = load i64, ptr %l11, !tbaa !24
  %t50 = add i64 %t48, 1
  store i64 %t50, ptr %l42, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l42, !tbaa !24
  br label %bb5
bb5:
  %t52 = load i64, ptr %l42, !tbaa !24
  %t53 = load ptr, ptr %l40, !tbaa !29
  %t54 = getelementptr %"compiler/check:frame", ptr %t53, i32 0, i32 16
  store i64 %t52, ptr %t54, !tbaa !24
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = load ptr, ptr %l2, !tbaa !29
  %t58 = load i32, ptr %l5, !tbaa !23
  %t62 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %t55, ptr %t56, i32 %t58)
  store ptr %t62, ptr %l49
  br label %bb6
bb6:
  %t63 = load ptr, ptr %l49, !tbaa !29
  store ptr %t63, ptr %l12, !tbaa !29
  %t64 = load ptr, ptr %l7, !tbaa !29
  store ptr %t64, ptr %l50, !tbaa !29
  %t65 = load ptr, ptr %l50, !tbaa !29
  %t66 = getelementptr %"compiler/check:frame", ptr %t65, i32 0, i32 15
  %t67 = load i64, ptr %t66, !tbaa !24
  %t69 = sub i64 %t67, 1
  %t71 = load ptr, ptr %l50, !tbaa !29
  %t72 = getelementptr %"compiler/check:frame", ptr %t71, i32 0, i32 15
  store i64 %t69, ptr %t72, !tbaa !24
  %t73 = load ptr, ptr %l7, !tbaa !29
  %t74 = load i64, ptr %l11, !tbaa !24
  %t77 = getelementptr %"compiler/check:frame", ptr %t73, i32 0, i32 16
  store i64 %t74, ptr %t77, !tbaa !24
  %t78 = load ptr, ptr %l7, !tbaa !29
  %t80 = getelementptr %"compiler/check:frame", ptr %t78, i32 0, i32 17
  %t81 = load i64, ptr %t80, !tbaa !24
  %t82 = load i64, ptr %l9, !tbaa !24
  %t85 = icmp eq i64 %t81, %t82
  br i1 %t85, label %bb7, label %bb8
bb7:
  %t87 = load ptr, ptr %l12, !tbaa !29
  %t90 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t87)
  store i32 %t90, ptr %l62
  br label %bb9
bb8:
  store i1 false, ptr %l59, !tbaa !21
  br label %bb10
bb9:
  %t91 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t92 = load i32, ptr %l62, !tbaa !23
  %t94 = icmp ne i32 %t92, %t91
  store i1 %t94, ptr %l59, !tbaa !21
  br label %bb10
bb10:
  %t96 = load i1, ptr %l59, !tbaa !21
  br i1 %t96, label %bb11, label %bb12
bb11:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einGeneric(ptr %v0, ptr %t97)
  store i1 %t99, ptr %l67
  br label %bb13
bb12:
  store i1 false, ptr %l65, !tbaa !21
  br label %bb14
bb13:
  %t100 = load i1, ptr %l67, !tbaa !21
  %t101 = xor i1 %t100, true
  store i1 %t101, ptr %l65, !tbaa !21
  br label %bb14
bb14:
  %t103 = load i1, ptr %l65, !tbaa !21
  br i1 %t103, label %bb15, label %bb16
bb15:
  %t104 = load ptr, ptr %l0, !tbaa !29
  store ptr %t104, ptr %l69, !tbaa !29
  %t105 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t105, ptr %l70
  %t106 = load i1, ptr %l4, !tbaa !21
  store i1 %t106, ptr %l71, !tbaa !21
  %t107 = load ptr, ptr %l7, !tbaa !29
  %t109 = getelementptr %"compiler/check:frame", ptr %t107, i32 0, i32 18
  %t110 = load i64, ptr %t109, !tbaa !24
  %t111 = load i64, ptr %l10, !tbaa !24
  %t114 = icmp sgt i64 %t110, %t111
  br i1 %t114, label %bb17, label %bb18
bb16:
  br label %bb26
bb17:
  store i1 true, ptr %l76, !tbaa !21
  br label %bb20
bb18:
  %t116 = load ptr, ptr %l2, !tbaa !29
  %t118 = call i1 @compiler_2fcheck_2echeckableAst(ptr %v1, ptr %t116)
  store i1 %t118, ptr %l78
  br label %bb19
bb19:
  %t119 = load i1, ptr %l78, !tbaa !21
  store i1 %t119, ptr %l76, !tbaa !21
  br label %bb20
bb20:
  %t120 = load ptr, ptr %l69, !tbaa !29
  %t121 = load %"compiler/source:Span", ptr %l70
  %t122 = load i1, ptr %l71, !tbaa !21
  %t123 = load i1, ptr %l76, !tbaa !21
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enothingFails(ptr %v0, ptr %t120, %"compiler/source:Span" %t121, i1 %t122, i1 %t123)
  br label %bb21
bb21:
  %t124 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t126 = extractvalue { i64, ptr } %t124, 0
  %t128 = icmp eq i64 %t126, 0
  br i1 %t128, label %bb22, label %bb23
bb22:
  %t130 = load ptr, ptr %l12, !tbaa !29
  store ptr %t130, ptr %l82, !tbaa !29
  br label %bb25
bb23:
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t133 = load %"compiler/source:Span", ptr %l1
  %t136 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t132, %"compiler/source:Span" %t133)
  store ptr %t136, ptr %l86
  br label %bb24
bb24:
  %t137 = load ptr, ptr %l86, !tbaa !29
  store ptr %t137, ptr %l82, !tbaa !29
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s0)
  %t138 = load ptr, ptr %l82, !tbaa !29
  store ptr %t138, ptr %rv
  br label %ret
bb26:
  %t139 = load ptr, ptr %l7, !tbaa !29
  %t141 = getelementptr %"compiler/check:frame", ptr %t139, i32 0, i32 25
  %t143 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t141)
  store i64 %t143, ptr %l89
  br label %bb27
bb27:
  %t144 = load i64, ptr %l89, !tbaa !24
  store i64 %t144, ptr %l13, !tbaa !24
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t146 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t147 = load i64, ptr %l8, !tbaa !24
  %t148 = load i64, ptr %l13, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eproduced(ptr %v0, ptr %v2, ptr %t145, { i64, ptr } %t146, i64 %t147, i64 %t148)
  br label %bb28
bb28:
  %t153 = load ptr, ptr %l12, !tbaa !29
  %t156 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t153)
  store i32 %t156, ptr %l96
  br label %bb29
bb29:
  %t157 = load i32, ptr %l96, !tbaa !23
  store i32 %t157, ptr %l14, !tbaa !23
  %t158 = load i1, ptr %l6, !tbaa !21
  br i1 %t158, label %bb30, label %bb31
bb30:
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t161 = load i32, ptr %l14, !tbaa !23
  %t164 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t160, i32 %t161)
  store i1 %t164, ptr %l101
  br label %bb32
bb31:
  store i1 false, ptr %l98, !tbaa !21
  br label %bb33
bb32:
  %t165 = load i1, ptr %l101, !tbaa !21
  store i1 %t165, ptr %l98, !tbaa !21
  br label %bb33
bb33:
  %t166 = load i1, ptr %l98, !tbaa !21
  br i1 %t166, label %bb34, label %bb35
bb34:
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t169 = getelementptr %"compiler/check:Checker", ptr %t167, i32 0, i32 1
  %t170 = load ptr, ptr %t169, !tbaa !29
  %t172 = getelementptr %"compiler/generic:Program", ptr %t170, i32 0, i32 2
  %t173 = load i32, ptr %l14, !tbaa !23
  %t176 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %t172, i32 %t173)
  store i1 %t176, ptr %l107
  br label %bb36
bb35:
  store i1 false, ptr %l102, !tbaa !21
  br label %bb37
bb36:
  %t177 = load i1, ptr %l107, !tbaa !21
  %t178 = xor i1 %t177, true
  store i1 %t178, ptr %l102, !tbaa !21
  br label %bb37
bb37:
  %t180 = load i1, ptr %l102, !tbaa !21
  br i1 %t180, label %bb38, label %bb39
bb38:
  %t181 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t183 = call i1 @compiler_2fcheck_2enullDefault(ptr %v2, { i64, ptr } %t181)
  store i1 %t183, ptr %l111
  br label %bb40
bb39:
  store i1 false, ptr %l109, !tbaa !21
  br label %bb41
bb40:
  %t184 = load i1, ptr %l111, !tbaa !21
  store i1 %t184, ptr %l109, !tbaa !21
  br label %bb41
bb41:
  %t185 = load i1, ptr %l109, !tbaa !21
  br i1 %t185, label %bb42, label %bb43
bb42:
  %t186 = load i32, ptr %l5, !tbaa !23
  %t187 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t190 = icmp eq i32 %t186, %t187
  br i1 %t190, label %bb44, label %bb45
bb43:
  store i1 false, ptr %l112, !tbaa !21
  br label %bb48
bb44:
  store i1 true, ptr %l116, !tbaa !21
  br label %bb47
bb45:
  %t192 = load ptr, ptr %l0, !tbaa !29
  %t194 = getelementptr %"compiler/check:Checker", ptr %t192, i32 0, i32 1
  %t195 = load ptr, ptr %t194, !tbaa !29
  %t197 = getelementptr %"compiler/generic:Program", ptr %t195, i32 0, i32 2
  %t198 = load i32, ptr %l5, !tbaa !23
  %t201 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %t197, i32 %t198)
  store i1 %t201, ptr %l121
  br label %bb46
bb46:
  %t202 = load i1, ptr %l121, !tbaa !21
  store i1 %t202, ptr %l116, !tbaa !21
  br label %bb47
bb47:
  %t203 = load i1, ptr %l116, !tbaa !21
  store i1 %t203, ptr %l112, !tbaa !21
  br label %bb48
bb48:
  %t204 = load i1, ptr %l112, !tbaa !21
  br i1 %t204, label %bb49, label %bb50
bb49:
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t207 = getelementptr %"compiler/check:Checker", ptr %t205, i32 0, i32 1
  %t208 = load ptr, ptr %t207, !tbaa !29
  %t210 = getelementptr %"compiler/generic:Program", ptr %t208, i32 0, i32 2
  %t211 = load i32, ptr %l14, !tbaa !23
  %t214 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOrNull(ptr %v0, ptr %t210, i32 %t211)
  store i32 %t214, ptr %l126
  br label %bb51
bb50:
  br label %bb52
bb51:
  %t215 = load i32, ptr %l126, !tbaa !23
  store i32 %t215, ptr %l14, !tbaa !23
  br label %bb52
bb52:
  %t216 = load ptr, ptr @__olang_prog_scope
  %t217 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aClause_26_3e(ptr %t216)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t217, ptr %l127
  br label %bb53
bb53:
  %t218 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 8, i64 8)
  store ptr %t218, ptr %lp15
  %t219 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l127
  %t220 = load ptr, ptr %lp15
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t219, ptr %t220
  %t221 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t223 = extractvalue { i64, ptr } %t221, 0
  %t225 = icmp sgt i64 %t223, 0
  br i1 %t225, label %bb54, label %bb55
bb54:
  %t227 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t227, ptr %l16, !tbaa !27
  store i64 0, ptr %l17, !tbaa !24
  %t229 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t231 = extractvalue { i64, ptr } %t229, 0
  store i64 %t231, ptr %l18, !tbaa !24
  br label %bb56
bb55:
  br label %bb64
bb56:
  store %olang.scope zeroinitializer, ptr %s5
  %t233 = load i64, ptr %l17, !tbaa !24
  %t234 = load i64, ptr %l18, !tbaa !24
  %t237 = icmp slt i64 %t233, %t234
  %t239 = xor i1 %t237, true
  br i1 %t239, label %bb57, label %bb58
bb57:
  call void @__olang_scope_close(ptr %s5)
  br label %bb63
bb58:
  br label %bb59
bb59:
  %t241 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t241, ptr %l138, !tbaa !27
  %t242 = load i64, ptr %l17, !tbaa !24
  %t244 = getelementptr { i64, ptr }, ptr %l138, i32 0, i32 1
  %t245 = load ptr, ptr %t244, !tbaa !27
  %t246 = getelementptr ptr, ptr %t245, i64 %t242
  %t247 = load ptr, ptr %t246, !tbaa !39
  %t249 = load ptr, ptr %lp15
  store ptr %t249, ptr %l141, !tbaa !29
  %t250 = load ptr, ptr %l0, !tbaa !29
  %t252 = load i32, ptr %l14, !tbaa !23
  %t253 = load i1, ptr %l6, !tbaa !21
  %t258 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclause(ptr %v0, ptr %v2, ptr %t250, ptr %t247, i32 %t252, i1 %t253)
  store ptr %t258, ptr %l146
  br label %bb60
bb60:
  %t259 = load ptr, ptr %l141, !tbaa !29
  %t260 = load ptr, ptr %l146, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aClause_26_3e_2eP_Hee51906bde9346e7b7b6808fdce5ba81(ptr %v0, ptr %v0, ptr %t259, ptr %t260)
  br label %bb61
bb61:
  call void @__olang_scope_close(ptr %s5)
  br label %bb62
bb62:
  %t261 = load i64, ptr %l17, !tbaa !24
  %t263 = add i64 %t261, 1
  store i64 %t263, ptr %l17, !tbaa !24
  br label %bb56
bb63:
  br label %bb64
bb64:
  %t265 = load ptr, ptr %l0, !tbaa !29
  %t266 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t267 = load ptr, ptr %lp15
  %t268 = load i1, ptr %l6, !tbaa !21
  %t269 = load i32, ptr %l14, !tbaa !23
  %t275 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclauseRules(ptr %v0, ptr %v2, ptr %v0, ptr %t265, { i64, ptr } %t266, ptr %t267, i1 %t268, i32 %t269)
  store i1 %t275, ptr %l154
  br label %bb65
bb65:
  %t276 = load i1, ptr %l154, !tbaa !21
  br i1 %t276, label %bb66, label %bb67
bb66:
  %t277 = load i1, ptr %l6, !tbaa !21
  store i1 %t277, ptr %l155, !tbaa !21
  br label %bb68
bb67:
  store i1 false, ptr %l155, !tbaa !21
  br label %bb68
bb68:
  %t279 = load i1, ptr %l155, !tbaa !21
  br i1 %t279, label %bb69, label %bb70
bb69:
  %t280 = load ptr, ptr %l0, !tbaa !29
  %t281 = load %"compiler/source:Span", ptr %l1
  %t284 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t280, %"compiler/source:Span" %t281)
  store ptr %t284, ptr %l159
  br label %bb71
bb70:
  br label %bb72
bb71:
  call void @__olang_scope_close(ptr %s0)
  %t285 = load ptr, ptr %l159, !tbaa !29
  store ptr %t285, ptr %rv
  br label %ret
bb72:
  %t286 = load ptr, ptr %l0, !tbaa !29
  %t287 = load i64, ptr %l8, !tbaa !24
  %t288 = load i64, ptr %l13, !tbaa !24
  %t289 = load ptr, ptr %lp15
  %t294 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaught(ptr %v0, ptr %v0, ptr %t286, i64 %t287, i64 %t288, ptr %t289)
  store i64 %t294, ptr %l164
  br label %bb73
bb73:
  %t295 = load i64, ptr %l164, !tbaa !24
  store i64 %t295, ptr %l20, !tbaa !24
  %t296 = load i1, ptr %l4, !tbaa !21
  br i1 %t296, label %bb74, label %bb75
bb74:
  %t298 = load ptr, ptr %lp15
  %t300 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aClause_26_3e_2eL_H39694dc3b7c161b4999ab170e8f3fd84(ptr %v0, ptr %t298)
  store i64 %t300, ptr %l168
  br label %bb76
bb75:
  store i1 false, ptr %l166, !tbaa !21
  br label %bb77
bb76:
  %t301 = load i64, ptr %l168, !tbaa !24
  %t302 = icmp eq i64 %t301, 0
  store i1 %t302, ptr %l166, !tbaa !21
  br label %bb77
bb77:
  %t304 = load i1, ptr %l166, !tbaa !21
  br i1 %t304, label %bb78, label %bb79
bb78:
  %t305 = load ptr, ptr %l7, !tbaa !29
  %t307 = getelementptr %"compiler/check:frame", ptr %t305, i32 0, i32 15
  %t308 = load i64, ptr %t307, !tbaa !24
  %t310 = icmp sgt i64 %t308, 0
  store i1 %t310, ptr %l170, !tbaa !21
  br label %bb80
bb79:
  store i1 false, ptr %l170, !tbaa !21
  br label %bb80
bb80:
  %t312 = load i1, ptr %l170, !tbaa !21
  store i1 %t312, ptr %l21, !tbaa !21
  %t313 = load ptr, ptr %l0, !tbaa !29
  store ptr %t313, ptr %l174, !tbaa !29
  %t314 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t315 = load i32, ptr %t314, !tbaa !23
  store i32 %t315, ptr %l175, !tbaa !23
  %t316 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t317 = load i32, ptr %t316, !tbaa !23
  store i32 %t317, ptr %l176, !tbaa !23
  %t318 = load i1, ptr %l4, !tbaa !21
  br i1 %t318, label %bb81, label %bb82
bb81:
  store i32 7, ptr %l178, !tbaa !23
  br label %bb83
bb82:
  store i32 3, ptr %l178, !tbaa !23
  br label %bb83
bb83:
  %t320 = load i32, ptr %l176, !tbaa !23
  %t321 = load i32, ptr %l178, !tbaa !23
  %t322 = add i32 %t320, %t321
  %t323 = load i32, ptr %l175, !tbaa !23
  %t325 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %t323, i32 %t322)
  store %"compiler/source:Span" %t325, ptr %l180
  br label %bb84
bb84:
  %t326 = load i64, ptr %l8, !tbaa !24
  %t327 = load i64, ptr %l20, !tbaa !24
  %t328 = load i1, ptr %l21, !tbaa !21
  %t329 = load ptr, ptr %l174, !tbaa !29
  %t330 = load %"compiler/source:Span", ptr %l180
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eescapes(ptr %v0, ptr %t329, %"compiler/source:Span" %t330, i64 %t326, i64 %t327, i1 %t328)
  br label %bb85
bb85:
  %t334 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t334, ptr %l184
  %t335 = load i32, ptr %l14, !tbaa !23
  store i32 %t335, ptr %l185, !tbaa !23
  %t336 = load ptr, ptr %l12, !tbaa !29
  store ptr %t336, ptr %l187, !tbaa !29
  %t338 = load ptr, ptr %lp15
  %t340 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aClause_26_3e_2eT_H39fa81f2ad510245a68cbacb663c8d87(ptr %v0, ptr %v0, ptr %t338)
  store { i64, ptr } %t340, ptr %l189
  br label %bb86
bb86:
  %t341 = load i1, ptr %l21, !tbaa !21
  %t342 = load ptr, ptr %l187, !tbaa !29
  %t343 = load { i64, ptr }, ptr %l189, !tbaa !27
  %t345 = call %"compiler/typed:Try" @compiler_2ftyped_3aTry_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %t342, { i64, ptr } %t343, i1 false, i1 %t341)
  store %"compiler/typed:Try" %t345, ptr %l191
  br label %bb87
bb87:
  %t346 = load %"compiler/typed:Try", ptr %l191
  %t347 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"compiler/typed:Try" %t346, ptr %t347
  store { i64, [5 x i64] } zeroinitializer, ptr %t348
  %t349 = getelementptr { i64, [5 x i64] }, ptr %t348, i32 0, i32 0
  store i64 14, ptr %t349
  %t350 = load %"compiler/source:Span", ptr %l184
  %t351 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t350, 0
  %t352 = load i32, ptr %l185, !tbaa !23
  %t353 = insertvalue { %"compiler/source:Span", i32, ptr } %t351, i32 %t352, 1
  %t355 = insertvalue { %"compiler/source:Span", i32, ptr } %t353, ptr %t347, 2
  %t356 = getelementptr { i64, [5 x i64] }, ptr %t348, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t355, ptr %t356
  %t357 = load { i64, [5 x i64] }, ptr %t348
  %t359 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t357, ptr %t359
  call void @__olang_scope_close(ptr %s0)
  store ptr %t359, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etyOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i1
  %l21 = alloca i1
  %l22 = alloca i1
  %l27 = alloca i32
  %l29 = alloca i32
  %l31 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l33 = alloca i64
  %l34 = alloca { i64, ptr }
  %l35 = alloca ptr
  %l38 = alloca i32
  %l39 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i64, ptr }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, i64, ptr }, ptr %t18, i32 0, i32 3
  %t20 = load ptr, ptr %t19
  store ptr %t20, ptr %l3, !tbaa !29
  br label %bb5
bb4:
  br label %bb26
bb5:
  %t22 = load ptr, ptr %l3, !tbaa !29
  store ptr %t22, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t23 = load ptr, ptr %l13, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb6, label %bb7
bb6:
  %t26 = load ptr, ptr %l13, !tbaa !29
  %t27 = load i64, ptr %t26
  %t29 = icmp eq i64 %t27, 1
  store i1 %t29, ptr %l14, !tbaa !21
  br label %bb7
bb7:
  %t30 = load i1, ptr %l14, !tbaa !21
  br i1 %t30, label %bb8, label %bb9
bb8:
  %t31 = load ptr, ptr %l3, !tbaa !29
  %t33 = getelementptr { i64, [2 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { { i64, ptr } }, ptr %t33, i32 0, i32 0
  %t35 = load { i64, ptr }, ptr %t34
  store { i64, ptr } %t35, ptr %l4, !tbaa !27
  br label %bb10
bb9:
  br label %bb20
bb10:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load i32, ptr %l2, !tbaa !23
  %t41 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t37, i32 %t38)
  store i1 %t41, ptr %l21
  br label %bb11
bb11:
  %t42 = load i1, ptr %l21, !tbaa !21
  br i1 %t42, label %bb12, label %bb13
bb12:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/check:Checker", ptr %t43, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t48 = getelementptr %"compiler/generic:Program", ptr %t46, i32 0, i32 2
  %t49 = load i32, ptr %l2, !tbaa !23
  %t52 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t48, i32 %t49)
  store i32 %t52, ptr %l27
  br label %bb14
bb13:
  store i1 false, ptr %l22, !tbaa !21
  br label %bb16
bb14:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %t53)
  store i32 %t55, ptr %l29
  br label %bb15
bb15:
  %t56 = load i32, ptr %l27, !tbaa !23
  %t57 = load i32, ptr %l29, !tbaa !23
  %t58 = icmp eq i32 %t56, %t57
  store i1 %t58, ptr %l22, !tbaa !21
  br label %bb16
bb16:
  %t60 = load i1, ptr %l22, !tbaa !21
  br i1 %t60, label %bb17, label %bb18
bb17:
  store { i64, ptr } { i64 6, ptr @.d24 }, ptr %l31, !tbaa !27
  %t61 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t61, ptr %l32, !tbaa !27
  %t62 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t63 = extractvalue { i64, ptr } %t62, 0
  store i64 %t63, ptr %l33, !tbaa !24
  %t64 = load i64, ptr %l33, !tbaa !24
  %t65 = mul i64 %t64, 1
  %t66 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t65)
  %t67 = insertvalue { i64, ptr } undef, i64 %t64, 0
  %t68 = insertvalue { i64, ptr } %t67, ptr %t66, 1
  store { i64, ptr } %t68, ptr %l34, !tbaa !27
  %t69 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !27
  %t71 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !27
  %t73 = load i64, ptr %l33, !tbaa !24
  %t74 = mul i64 %t73, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t70, ptr %t72, i64 %t74, i1 false)
  %t75 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t75, ptr %l32, !tbaa !27
  %t76 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t76, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  br label %bb25
bb20:
  br i1 true, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_e722c21055ee6b49_58bcebf0b772fb7d)
  unreachable
bb25:
  br label %bb31
bb26:
  br i1 true, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb31
bb30:
  call void @__olang_check_failed(ptr @olang_loc_eca48244095fc078_aacf4c954a6e214c)
  unreachable
bb31:
  %t77 = load ptr, ptr %l0, !tbaa !29
  store ptr %t77, ptr %l35, !tbaa !29
  %t78 = load ptr, ptr %l1, !tbaa !29
  %t81 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t78)
  store i32 %t81, ptr %l38
  br label %bb32
bb32:
  %t82 = load ptr, ptr %l35, !tbaa !29
  %t83 = load i32, ptr %l38, !tbaa !23
  %t84 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v2, ptr %t82, i32 %t83)
  store { i64, ptr } %t84, ptr %l39
  br label %bb33
bb33:
  %t85 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t85, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkIndexed(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, i64 %a4, i64 %a5, ptr %a6, i32 %a7) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca { i64, i64, i64 }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca i64
  %l19 = alloca { i64, i64, i64 }
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l27 = alloca i64
  %l28 = alloca ptr
  %l29 = alloca %"compiler/source:Span"
  %l31 = alloca i32
  %l32 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca %"compiler/source:Span"
  %l37 = alloca i32
  %l38 = alloca ptr
  %l39 = alloca %"compiler/source:Span"
  %l41 = alloca i32
  %l42 = alloca ptr
  %l47 = alloca i64
  %l51 = alloca { i64, i64, i64 }
  %l56 = alloca ptr
  %l61 = alloca ptr
  %l68 = alloca ptr
  %l69 = alloca ptr
  %l72 = alloca ptr
  %l73 = alloca %"compiler/source:Span"
  %l74 = alloca %"compiler/source:Span"
  %l75 = alloca i64
  %l79 = alloca ptr
  %l80 = alloca ptr
  %l83 = alloca { i64, ptr }
  %l86 = alloca { i64, ptr }
  %l90 = alloca ptr
  %l91 = alloca ptr
  %l92 = alloca ptr
  %l93 = alloca %"compiler/source:Span"
  %l94 = alloca ptr
  %l95 = alloca %"compiler/source:Span"
  %l96 = alloca i32
  %l97 = alloca i32
  %l101 = alloca ptr
  %l104 = alloca ptr
  %l106 = alloca ptr
  %l107 = alloca ptr
  %l108 = alloca %"compiler/source:Span"
  %l109 = alloca %"compiler/source:Span"
  %l110 = alloca i64
  %l114 = alloca ptr
  %l115 = alloca ptr
  %l118 = alloca { i64, ptr }
  %l119 = alloca ptr
  %l123 = alloca ptr
  %l124 = alloca { i64, ptr }
  %l128 = alloca ptr
  %l132 = alloca ptr
  %l133 = alloca ptr
  %l145 = alloca i64
  %l147 = alloca ptr
  %l150 = alloca i64
  %l151 = alloca i32
  %l152 = alloca i64
  %l154 = alloca ptr
  %l157 = alloca i64
  %l158 = alloca i32
  %l164 = alloca ptr
  %l167 = alloca i64
  %l171 = alloca { i64, i64, i64 }
  %l175 = alloca ptr
  %l176 = alloca %"compiler/source:Span"
  %l177 = alloca %"compiler/source:Span"
  %l179 = alloca i32
  %l184 = alloca ptr
  %l185 = alloca ptr
  %l186 = alloca %"compiler/source:Span"
  %l188 = alloca i32
  %l189 = alloca i32
  %l193 = alloca ptr
  %l194 = alloca ptr
  %l195 = alloca %"compiler/source:Span"
  %l197 = alloca i32
  %l198 = alloca ptr
  %l200 = alloca ptr
  %l208 = alloca ptr
  %s0 = alloca %olang.scope
  %t34 = alloca { i64, [3 x i64] }, align 8
  %t335 = alloca { i64, [4 x i64] }, align 8
  %t376 = alloca { i64, [3 x i64] }, align 8
  %t407 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load %"compiler/source:Span", ptr %l1
  %t7 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eborrowedSource(ptr %v0, ptr %t1, %"compiler/source:Span" %t2, ptr %a3)
  store i64 %t7, ptr %l27
  br label %bb1
bb1:
  %t8 = load i64, ptr %l27, !tbaa !24
  store i64 %t8, ptr %l8, !tbaa !24
  %t9 = load ptr, ptr %l0, !tbaa !29
  store ptr %t9, ptr %l28, !tbaa !29
  %t10 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t10, ptr %l29
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t11)
  store i32 %t13, ptr %l31
  br label %bb2
bb2:
  %t14 = load ptr, ptr %l28, !tbaa !29
  %t15 = load %"compiler/source:Span", ptr %l29
  %t16 = load i32, ptr %l31, !tbaa !23
  %t17 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t14, %"compiler/source:Span" %t15, i32 %t16)
  store i64 %t17, ptr %l32
  br label %bb3
bb3:
  %t18 = load i64, ptr %l32, !tbaa !24
  store i64 %t18, ptr %l9, !tbaa !24
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l33, !tbaa !29
  %t20 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t20, ptr %l34
  %t21 = load i64, ptr %l9, !tbaa !24
  %t23 = trunc i64 %t21 to i32
  store i32 %t23, ptr %l37, !tbaa !23
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l38, !tbaa !29
  %t26 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t26, ptr %l39
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t27)
  store i32 %t29, ptr %l41
  br label %bb4
bb4:
  %t30 = load ptr, ptr %l38, !tbaa !29
  %t31 = load %"compiler/source:Span", ptr %l39
  %t32 = load i32, ptr %l41, !tbaa !23
  %t33 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t30, %"compiler/source:Span" %t31, i32 %t32, i64 0)
  store ptr %t33, ptr %l42
  br label %bb5
bb5:
  store { i64, [3 x i64] } zeroinitializer, ptr %t34
  %t35 = getelementptr { i64, [3 x i64] }, ptr %t34, i32 0, i32 0
  store i64 0, ptr %t35
  %t36 = load %"compiler/source:Span", ptr %l34
  %t37 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t36, 0
  %t38 = load i32, ptr %l37, !tbaa !23
  %t39 = insertvalue { %"compiler/source:Span", i32, ptr } %t37, i32 %t38, 1
  %t40 = load ptr, ptr %l42, !tbaa !29
  %t41 = insertvalue { %"compiler/source:Span", i32, ptr } %t39, ptr %t40, 2
  %t42 = getelementptr { i64, [3 x i64] }, ptr %t34, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t41, ptr %t42
  %t43 = load { i64, [3 x i64] }, ptr %t34
  %t45 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t43, ptr %t45
  %t46 = load ptr, ptr %l33, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t46, ptr %t45)
  br label %bb6
bb6:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/check:Checker", ptr %t48, i32 0, i32 32
  %t52 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t50)
  store i64 %t52, ptr %l47
  br label %bb7
bb7:
  %t53 = load i64, ptr %l47, !tbaa !24
  store i64 %t53, ptr %l10, !tbaa !24
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load %"compiler/source:Span", ptr %l1
  %t59 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t54, i32 2, %"compiler/source:Span" %t55)
  store { i64, i64, i64 } %t59, ptr %l51
  br label %bb8
bb8:
  %t60 = load { i64, i64, i64 }, ptr %l51
  store { i64, i64, i64 } %t60, ptr %l11
  %t61 = getelementptr { i64, i64, i64 }, ptr %l11, i32 0, i32 0
  %t62 = load i64, ptr %t61, !tbaa !24
  store i64 %t62, ptr %l12, !tbaa !24
  %t64 = getelementptr { i64, i64, i64 }, ptr %l11, i32 0, i32 1
  %t65 = load i64, ptr %t64, !tbaa !24
  store i64 %t65, ptr %l13, !tbaa !24
  %t67 = getelementptr { i64, i64, i64 }, ptr %l11, i32 0, i32 2
  %t68 = load i64, ptr %t67, !tbaa !24
  store i64 %t68, ptr %l14, !tbaa !24
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t70)
  store ptr %t72, ptr %l56
  br label %bb9
bb9:
  %t73 = load ptr, ptr %l56, !tbaa !29
  %t75 = getelementptr %"compiler/check:frame", ptr %t73, i32 0, i32 10
  %t76 = load i64, ptr %l12, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t75, i64 %t76)
  br label %bb10
bb10:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t79)
  store ptr %t81, ptr %l61
  br label %bb11
bb11:
  %t82 = load ptr, ptr %l61, !tbaa !29
  %t84 = getelementptr %"compiler/check:frame", ptr %t82, i32 0, i32 11
  %t85 = load i64, ptr %l12, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t84, i64 %t85)
  br label %bb12
bb12:
  %t88 = load ptr, ptr %l2, !tbaa !29
  %t90 = getelementptr %"compiler/ast:ForIn", ptr %t88, i32 0, i32 3
  %t91 = load i1, ptr %t90, !tbaa !21
  br i1 %t91, label %bb13, label %bb14
bb13:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t93)
  store ptr %t95, ptr %l68
  br label %bb15
bb14:
  br label %bb16
bb15:
  %t96 = load ptr, ptr %l68, !tbaa !29
  store ptr %t96, ptr %l69, !tbaa !29
  %t97 = load ptr, ptr %l69, !tbaa !29
  %t98 = getelementptr %"compiler/check:frame", ptr %t97, i32 0, i32 15
  %t99 = load i64, ptr %t98, !tbaa !24
  %t101 = add i64 %t99, 1
  %t103 = load ptr, ptr %l69, !tbaa !29
  %t104 = getelementptr %"compiler/check:frame", ptr %t103, i32 0, i32 15
  store i64 %t101, ptr %t104, !tbaa !24
  br label %bb16
bb16:
  %t105 = load ptr, ptr %l0, !tbaa !29
  store ptr %t105, ptr %l72, !tbaa !29
  %t106 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t106, ptr %l73
  %t107 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t107, ptr %l74
  store i64 %a5, ptr %l75, !tbaa !24
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t110 = load %"compiler/source:Span", ptr %l1
  %t111 = load i64, ptr %l8, !tbaa !24
  %t115 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t109, %"compiler/source:Span" %t110, i64 %t111)
  store ptr %t115, ptr %l79
  br label %bb17
bb17:
  %t116 = load ptr, ptr %l79, !tbaa !29
  store ptr %t116, ptr %l80, !tbaa !29
  %t117 = icmp sge i64 0, 0
  br i1 %t117, label %bb18, label %bb19
bb18:
  %t119 = icmp sle i64 0, 1152921504606846975
  br i1 %t119, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_5c35d65bf515aa44_9edccba99dd9b7f8)
  unreachable
bb20:
  %t121 = mul i64 0, 8
  %t122 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t121)
  %t123 = insertvalue { i64, ptr } undef, i64 0, 0
  %t124 = insertvalue { i64, ptr } %t123, ptr %t122, 1
  store { i64, ptr } %t124, ptr %l83, !tbaa !27
  %t125 = icmp sge i64 0, 0
  br i1 %t125, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_5c35d65bf515aa44_9edccba99dd9b7f8)
  unreachable
bb22:
  %t127 = icmp sle i64 0, 1152921504606846975
  br i1 %t127, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_5c35d65bf515aa44_9edccba99dd9b7f8)
  unreachable
bb24:
  %t129 = mul i64 0, 8
  %t130 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t129)
  %t131 = insertvalue { i64, ptr } undef, i64 0, 0
  %t132 = insertvalue { i64, ptr } %t131, ptr %t130, 1
  store { i64, ptr } %t132, ptr %l86, !tbaa !27
  %t133 = icmp sge i64 0, 0
  br i1 %t133, label %bb26, label %bb27
bb25:
  call void @__olang_check_failed(ptr @olang_loc_5c35d65bf515aa44_9edccba99dd9b7f8)
  unreachable
bb26:
  %t135 = icmp sle i64 0, 2305843009213693951
  br i1 %t135, label %bb28, label %bb29
bb27:
  call void @__olang_check_failed(ptr @olang_loc_19568a04807ed851_528b5bfe222c3865)
  unreachable
bb28:
  %t137 = mul i64 0, 4
  %t138 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t137)
  %t139 = insertvalue { i64, ptr } undef, i64 0, 0
  %t140 = insertvalue { i64, ptr } %t139, ptr %t138, 1
  %t141 = load ptr, ptr %l72, !tbaa !29
  %t142 = load %"compiler/source:Span", ptr %l73
  %t143 = load %"compiler/source:Span", ptr %l74
  %t144 = load i64, ptr %l75, !tbaa !24
  %t145 = load ptr, ptr %l80, !tbaa !29
  %t146 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t147 = load { i64, ptr }, ptr %l86, !tbaa !27
  %t149 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v0, ptr %s0, ptr %t141, %"compiler/source:Span" %t142, %"compiler/source:Span" %t143, i64 %t144, ptr %t145, { i64, ptr } %t146, { i64, ptr } %t147, { i64, ptr } %t140)
  store ptr %t149, ptr %l90
  br label %bb30
bb29:
  call void @__olang_check_failed(ptr @olang_loc_19568a04807ed851_528b5bfe222c3865)
  unreachable
bb30:
  %t150 = load ptr, ptr %l90, !tbaa !29
  store ptr %t150, ptr %l15, !tbaa !29
  %t151 = load ptr, ptr %l0, !tbaa !29
  store ptr %t151, ptr %l91, !tbaa !29
  %t152 = load ptr, ptr %l0, !tbaa !29
  store ptr %t152, ptr %l92, !tbaa !29
  %t153 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t153, ptr %l93
  %t154 = load ptr, ptr %l0, !tbaa !29
  store ptr %t154, ptr %l94, !tbaa !29
  %t155 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t155, ptr %l95
  %t156 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t156, ptr %l96, !tbaa !23
  store i32 15, ptr %l97
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t158 = load %"compiler/source:Span", ptr %l1
  %t159 = load i64, ptr %l9, !tbaa !24
  %t163 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t157, %"compiler/source:Span" %t158, i64 %t159)
  store ptr %t163, ptr %l101
  br label %bb31
bb31:
  %t164 = load ptr, ptr %l15, !tbaa !29
  %t166 = load ptr, ptr %l94, !tbaa !29
  %t167 = load %"compiler/source:Span", ptr %l95
  %t168 = load i32, ptr %l96, !tbaa !23
  %t169 = load i32, ptr %l97
  %t170 = load ptr, ptr %l101, !tbaa !29
  %t172 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %t166, %"compiler/source:Span" %t167, i32 %t168, i32 %t169, ptr %t170, ptr %t164)
  store ptr %t172, ptr %l104
  br label %bb32
bb32:
  %t173 = load i64, ptr %l12, !tbaa !24
  %t174 = load ptr, ptr %l92, !tbaa !29
  %t175 = load %"compiler/source:Span", ptr %l93
  %t176 = load ptr, ptr %l104, !tbaa !29
  %t178 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebreakUnless(ptr %v0, ptr %t174, %"compiler/source:Span" %t175, ptr %t176, i64 %t173)
  store ptr %t178, ptr %l106
  br label %bb33
bb33:
  %t179 = load ptr, ptr %l91, !tbaa !29
  %t180 = load ptr, ptr %l106, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t179, ptr %t180)
  br label %bb34
bb34:
  %t181 = load ptr, ptr %l0, !tbaa !29
  store ptr %t181, ptr %l107, !tbaa !29
  %t182 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t182, ptr %l108
  %t183 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t183, ptr %l109
  store i64 %a4, ptr %l110, !tbaa !24
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t186 = load %"compiler/source:Span", ptr %l1
  %t187 = load i64, ptr %l8, !tbaa !24
  %t191 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t185, %"compiler/source:Span" %t186, i64 %t187)
  store ptr %t191, ptr %l114
  br label %bb35
bb35:
  %t192 = load ptr, ptr %l114, !tbaa !29
  store ptr %t192, ptr %l115, !tbaa !29
  %t193 = icmp sge i64 0, 0
  br i1 %t193, label %bb36, label %bb37
bb36:
  %t195 = icmp sle i64 0, 1152921504606846975
  br i1 %t195, label %bb38, label %bb39
bb37:
  call void @__olang_check_failed(ptr @olang_loc_130b25e968db6b32_47c65c95f253846)
  unreachable
bb38:
  %t197 = mul i64 0, 8
  %t198 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t197)
  %t199 = insertvalue { i64, ptr } undef, i64 0, 0
  %t200 = insertvalue { i64, ptr } %t199, ptr %t198, 1
  store { i64, ptr } %t200, ptr %l118, !tbaa !27
  %t201 = load ptr, ptr %l0, !tbaa !29
  store ptr %t201, ptr %l119, !tbaa !29
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t203 = load %"compiler/source:Span", ptr %l1
  %t204 = load i64, ptr %l9, !tbaa !24
  %t208 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t202, %"compiler/source:Span" %t203, i64 %t204)
  store ptr %t208, ptr %l123
  br label %bb40
bb39:
  call void @__olang_check_failed(ptr @olang_loc_130b25e968db6b32_47c65c95f253846)
  unreachable
bb40:
  %t209 = load ptr, ptr %l119, !tbaa !29
  %t210 = load ptr, ptr %l123, !tbaa !29
  %t211 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eone(ptr %v0, ptr %t209, ptr %t210)
  store { i64, ptr } %t211, ptr %l124
  br label %bb41
bb41:
  %t212 = icmp sge i64 0, 0
  br i1 %t212, label %bb42, label %bb43
bb42:
  %t214 = icmp sle i64 0, 2305843009213693951
  br i1 %t214, label %bb44, label %bb45
bb43:
  call void @__olang_check_failed(ptr @olang_loc_19568a04807ed851_528b5bfe222c3865)
  unreachable
bb44:
  %t216 = mul i64 0, 4
  %t217 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t216)
  %t218 = insertvalue { i64, ptr } undef, i64 0, 0
  %t219 = insertvalue { i64, ptr } %t218, ptr %t217, 1
  %t220 = load ptr, ptr %l107, !tbaa !29
  %t221 = load %"compiler/source:Span", ptr %l108
  %t222 = load %"compiler/source:Span", ptr %l109
  %t223 = load i64, ptr %l110, !tbaa !24
  %t224 = load ptr, ptr %l115, !tbaa !29
  %t225 = load { i64, ptr }, ptr %l118, !tbaa !27
  %t226 = load { i64, ptr }, ptr %l124, !tbaa !27
  %t228 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v0, ptr %s0, ptr %t220, %"compiler/source:Span" %t221, %"compiler/source:Span" %t222, i64 %t223, ptr %t224, { i64, ptr } %t225, { i64, ptr } %t226, { i64, ptr } %t219)
  store ptr %t228, ptr %l128
  br label %bb46
bb45:
  call void @__olang_check_failed(ptr @olang_loc_19568a04807ed851_528b5bfe222c3865)
  unreachable
bb46:
  %t229 = load ptr, ptr %l128, !tbaa !29
  store ptr %t229, ptr %l16, !tbaa !29
  %t230 = load ptr, ptr %l2, !tbaa !29
  %t232 = getelementptr %"compiler/ast:ForIn", ptr %t230, i32 0, i32 3
  %t233 = load i1, ptr %t232, !tbaa !21
  br i1 %t233, label %bb47, label %bb48
bb47:
  %t235 = load ptr, ptr %l0, !tbaa !29
  %t237 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t235)
  store ptr %t237, ptr %l132
  br label %bb49
bb48:
  br label %bb50
bb49:
  %t238 = load ptr, ptr %l132, !tbaa !29
  store ptr %t238, ptr %l133, !tbaa !29
  %t239 = load ptr, ptr %l133, !tbaa !29
  %t240 = getelementptr %"compiler/check:frame", ptr %t239, i32 0, i32 15
  %t241 = load i64, ptr %t240, !tbaa !24
  %t243 = sub i64 %t241, 1
  %t245 = load ptr, ptr %l133, !tbaa !29
  %t246 = getelementptr %"compiler/check:frame", ptr %t245, i32 0, i32 15
  store i64 %t243, ptr %t246, !tbaa !24
  br label %bb50
bb50:
  %t247 = load ptr, ptr %l0, !tbaa !29
  %t248 = load %"compiler/source:Span", ptr %l1
  %t249 = load ptr, ptr %l2, !tbaa !29
  %t250 = load i64, ptr %l9, !tbaa !24
  %t251 = load ptr, ptr %l16, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eelementLocals(ptr %v0, ptr %v1, ptr %t247, %"compiler/source:Span" %t248, ptr %t249, i64 %t250, ptr %t251)
  br label %bb51
bb51:
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t258 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkBody(ptr %v0, ptr %v1, ptr %v2, ptr %t257, ptr %t258, ptr %a6, i32 %a7)
  br label %bb52
bb52:
  %t265 = load ptr, ptr %l0, !tbaa !29
  %t267 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t265)
  store ptr %t267, ptr %l147
  br label %bb53
bb53:
  %t268 = load ptr, ptr %l147, !tbaa !29
  %t270 = getelementptr %"compiler/check:frame", ptr %t268, i32 0, i32 10
  %t272 = call { i32, i64 } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t270)
  %t273 = extractvalue { i32, i64 } %t272, 1
  %t274 = extractvalue { i32, i64 } %t272, 0
  store i32 %t274, ptr %l151
  %t275 = icmp ne i32 %t274, 0
  br i1 %t275, label %bb55, label %ok.276
ok.276:
  store i64 %t273, ptr %l150
  br label %bb54
bb54:
  %t277 = load i64, ptr %l150, !tbaa !24
  store i64 %t277, ptr %l145, !tbaa !24
  br label %bb57
bb55:
  br label %bb56
bb56:
  br label %bb57
bb57:
  %t278 = load ptr, ptr %l0, !tbaa !29
  %t280 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t278)
  store ptr %t280, ptr %l154
  br label %bb58
bb58:
  %t281 = load ptr, ptr %l154, !tbaa !29
  %t283 = getelementptr %"compiler/check:frame", ptr %t281, i32 0, i32 11
  %t285 = call { i32, i64 } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t283)
  %t286 = extractvalue { i32, i64 } %t285, 1
  %t287 = extractvalue { i32, i64 } %t285, 0
  store i32 %t287, ptr %l158
  %t288 = icmp ne i32 %t287, 0
  br i1 %t288, label %bb60, label %ok.289
ok.289:
  store i64 %t286, ptr %l157
  br label %bb59
bb59:
  %t290 = load i64, ptr %l157, !tbaa !24
  store i64 %t290, ptr %l152, !tbaa !24
  br label %bb62
bb60:
  br label %bb61
bb61:
  br label %bb62
bb62:
  %t291 = load ptr, ptr %l0, !tbaa !29
  %t292 = load i64, ptr %l12, !tbaa !24
  %t293 = load i64, ptr %l13, !tbaa !24
  %t294 = load i64, ptr %l14, !tbaa !24
  %t295 = load i64, ptr %l10, !tbaa !24
  %t301 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %t291, i64 %t292, i64 %t293, i64 %t294, i64 %t295)
  store ptr %t301, ptr %l164
  br label %bb63
bb63:
  %t302 = load ptr, ptr %l164, !tbaa !29
  store ptr %t302, ptr %l17, !tbaa !29
  %t303 = load ptr, ptr %l0, !tbaa !29
  %t305 = getelementptr %"compiler/check:Checker", ptr %t303, i32 0, i32 32
  %t307 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t305)
  store i64 %t307, ptr %l167
  br label %bb64
bb64:
  %t308 = load i64, ptr %l167, !tbaa !24
  store i64 %t308, ptr %l18, !tbaa !24
  %t309 = load ptr, ptr %l0, !tbaa !29
  %t310 = load %"compiler/source:Span", ptr %l1
  %t314 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t309, i32 3, %"compiler/source:Span" %t310)
  store { i64, i64, i64 } %t314, ptr %l171
  br label %bb65
bb65:
  %t315 = load { i64, i64, i64 }, ptr %l171
  store { i64, i64, i64 } %t315, ptr %l19
  %t316 = getelementptr { i64, i64, i64 }, ptr %l19, i32 0, i32 0
  %t317 = load i64, ptr %t316, !tbaa !24
  store i64 %t317, ptr %l20, !tbaa !24
  %t319 = getelementptr { i64, i64, i64 }, ptr %l19, i32 0, i32 1
  %t320 = load i64, ptr %t319, !tbaa !24
  store i64 %t320, ptr %l21, !tbaa !24
  %t322 = getelementptr { i64, i64, i64 }, ptr %l19, i32 0, i32 2
  %t323 = load i64, ptr %t322, !tbaa !24
  store i64 %t323, ptr %l22, !tbaa !24
  %t325 = load ptr, ptr %l0, !tbaa !29
  store ptr %t325, ptr %l175, !tbaa !29
  %t326 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t326, ptr %l176
  %t327 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t327, ptr %l177
  %t328 = load ptr, ptr %l0, !tbaa !29
  %t330 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t328)
  store i32 %t330, ptr %l179
  br label %bb66
bb66:
  %t331 = load i64, ptr %l9, !tbaa !24
  %t333 = trunc i64 %t331 to i32
  store { i64, [4 x i64] } zeroinitializer, ptr %t335
  %t336 = getelementptr { i64, [4 x i64] }, ptr %t335, i32 0, i32 0
  store i64 0, ptr %t336
  %t337 = load %"compiler/source:Span", ptr %l177
  %t338 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t337, 0
  %t339 = load i32, ptr %l179, !tbaa !23
  %t340 = insertvalue { %"compiler/source:Span", i32, i32 } %t338, i32 %t339, 1
  %t342 = insertvalue { %"compiler/source:Span", i32, i32 } %t340, i32 %t333, 2
  %t343 = getelementptr { i64, [4 x i64] }, ptr %t335, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t342, ptr %t343
  %t344 = load { i64, [4 x i64] }, ptr %t335
  %t346 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t344, ptr %t346
  store ptr %t346, ptr %l184, !tbaa !29
  %t347 = load ptr, ptr %l0, !tbaa !29
  store ptr %t347, ptr %l185, !tbaa !29
  %t348 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t348, ptr %l186
  %t349 = load ptr, ptr %l0, !tbaa !29
  %t351 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t349)
  store i32 %t351, ptr %l188
  br label %bb67
bb67:
  store i32 3, ptr %l189
  %t352 = load ptr, ptr %l0, !tbaa !29
  %t353 = load %"compiler/source:Span", ptr %l1
  %t354 = load i64, ptr %l9, !tbaa !24
  %t358 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t352, %"compiler/source:Span" %t353, i64 %t354)
  store ptr %t358, ptr %l193
  br label %bb68
bb68:
  %t359 = load ptr, ptr %l0, !tbaa !29
  store ptr %t359, ptr %l194, !tbaa !29
  %t360 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t360, ptr %l195
  %t361 = load ptr, ptr %l0, !tbaa !29
  %t363 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t361)
  store i32 %t363, ptr %l197
  br label %bb69
bb69:
  %t364 = load ptr, ptr %l194, !tbaa !29
  %t365 = load %"compiler/source:Span", ptr %l195
  %t366 = load i32, ptr %l197, !tbaa !23
  %t367 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t364, %"compiler/source:Span" %t365, i32 %t366, i64 1)
  store ptr %t367, ptr %l198
  br label %bb70
bb70:
  %t368 = load ptr, ptr %l198, !tbaa !29
  %t369 = load ptr, ptr %l185, !tbaa !29
  %t370 = load %"compiler/source:Span", ptr %l186
  %t371 = load i32, ptr %l188, !tbaa !23
  %t372 = load i32, ptr %l189
  %t373 = load ptr, ptr %l193, !tbaa !29
  %t375 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %t369, %"compiler/source:Span" %t370, i32 %t371, i32 %t372, ptr %t373, ptr %t368)
  store ptr %t375, ptr %l200
  br label %bb71
bb71:
  store { i64, [3 x i64] } zeroinitializer, ptr %t376
  %t377 = getelementptr { i64, [3 x i64] }, ptr %t376, i32 0, i32 0
  store i64 1, ptr %t377
  %t378 = load %"compiler/source:Span", ptr %l176
  %t379 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t378, 0
  %t380 = load ptr, ptr %l184, !tbaa !29
  %t381 = insertvalue { %"compiler/source:Span", ptr, ptr } %t379, ptr %t380, 1
  %t382 = load ptr, ptr %l200, !tbaa !29
  %t383 = insertvalue { %"compiler/source:Span", ptr, ptr } %t381, ptr %t382, 2
  %t384 = getelementptr { i64, [3 x i64] }, ptr %t376, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t383, ptr %t384
  %t385 = load { i64, [3 x i64] }, ptr %t376
  %t387 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t385, ptr %t387
  %t388 = load ptr, ptr %l175, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t388, ptr %t387)
  br label %bb72
bb72:
  %t390 = load ptr, ptr %l0, !tbaa !29
  %t391 = load i64, ptr %l20, !tbaa !24
  %t392 = load i64, ptr %l21, !tbaa !24
  %t393 = load i64, ptr %l22, !tbaa !24
  %t394 = load i64, ptr %l18, !tbaa !24
  %t400 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %t390, i64 %t391, i64 %t392, i64 %t393, i64 %t394)
  store ptr %t400, ptr %l208
  br label %bb73
bb73:
  %t401 = load ptr, ptr %l208, !tbaa !29
  %t402 = load ptr, ptr %l0, !tbaa !29
  %t403 = load %"compiler/source:Span", ptr %l1
  %t404 = load ptr, ptr %l17, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t407
  %t408 = getelementptr { i64, [3 x i64] }, ptr %t407, i32 0, i32 0
  store i64 4, ptr %t408
  %t410 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t403, 0
  %t412 = insertvalue { %"compiler/source:Span", ptr, ptr } %t410, ptr %t404, 1
  %t414 = insertvalue { %"compiler/source:Span", ptr, ptr } %t412, ptr %t401, 2
  %t415 = getelementptr { i64, [3 x i64] }, ptr %t407, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t414, ptr %t415
  %t416 = load { i64, [3 x i64] }, ptr %t407
  %t418 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t416, ptr %t418
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t402, ptr %t418)
  br label %bb74
bb74:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2eentryOf(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca i1
  %l17 = alloca ptr
  %l18 = alloca i1
  %l21 = alloca ptr
  %l22 = alloca i1
  %l25 = alloca ptr
  %l26 = alloca i1
  %l35 = alloca i1
  %l37 = alloca i1
  %l40 = alloca i1
  %l44 = alloca i1
  %l45 = alloca ptr
  %l47 = alloca %"compiler/source:Span"
  %l48 = alloca i64
  %l49 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l53 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %l57 = alloca i32
  %l66 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t2 = load ptr, ptr %l13, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l13, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l14, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l14, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb13
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t11 = load ptr, ptr %l17, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb5, label %bb6
bb5:
  %t14 = load ptr, ptr %l17, !tbaa !29
  %t15 = load i64, ptr %t14
  %t17 = icmp eq i64 %t15, 23
  store i1 %t17, ptr %l18, !tbaa !21
  br label %bb6
bb6:
  %t18 = load i1, ptr %l18, !tbaa !21
  br i1 %t18, label %bb7, label %bb8
bb7:
  br label %bb13
bb8:
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l21, !tbaa !29
  store i1 false, ptr %l22, !tbaa !21
  %t20 = load ptr, ptr %l21, !tbaa !29
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %bb9, label %bb10
bb9:
  %t23 = load ptr, ptr %l21, !tbaa !29
  %t24 = load i64, ptr %t23
  %t26 = icmp eq i64 %t24, 24
  store i1 %t26, ptr %l22, !tbaa !21
  br label %bb10
bb10:
  %t27 = load i1, ptr %l22, !tbaa !21
  br i1 %t27, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb14:
  %t28 = load ptr, ptr %l0, !tbaa !29
  store ptr %t28, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t29 = load ptr, ptr %l25, !tbaa !29
  %t30 = icmp ne ptr %t29, null
  br i1 %t30, label %bb15, label %bb16
bb15:
  %t32 = load ptr, ptr %l25, !tbaa !29
  %t33 = load i64, ptr %t32
  %t35 = icmp eq i64 %t33, 3
  store i1 %t35, ptr %l26, !tbaa !21
  br label %bb16
bb16:
  %t36 = load i1, ptr %l26, !tbaa !21
  br i1 %t36, label %bb17, label %bb18
bb17:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr { i64, [5 x i64] }, ptr %t37, i32 0, i32 1
  %t40 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t39, i32 0, i32 1
  %t41 = load i32, ptr %t40
  store i32 %t41, ptr %l5
  br label %bb19
bb18:
  br label %bb23
bb19:
  %t43 = load i32, ptr %l5
  %t45 = trunc i64 14 to i32
  %t46 = icmp eq i32 %t43, %t45
  br i1 %t46, label %bb20, label %bb21
bb20:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb21:
  br label %bb22
bb22:
  br label %bb24
bb23:
  br label %bb24
bb24:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = load ptr, ptr %l1, !tbaa !29
  %t52 = call i1 @compiler_2fcheck_2ementions(ptr %v0, ptr %v1, ptr %t48, ptr %t49)
  store i1 %t52, ptr %l35
  br label %bb25
bb25:
  %t53 = load i1, ptr %l35, !tbaa !21
  %t54 = xor i1 %t53, true
  br i1 %t54, label %bb26, label %bb27
bb26:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t57 = load ptr, ptr %l3, !tbaa !29
  %t60 = call i1 @compiler_2fcheck_2ementions(ptr %v0, ptr %v3, ptr %t56, ptr %t57)
  store i1 %t60, ptr %l40
  br label %bb28
bb27:
  store i1 false, ptr %l37, !tbaa !21
  br label %bb29
bb28:
  %t61 = load i1, ptr %l40, !tbaa !21
  %t62 = xor i1 %t61, true
  store i1 %t62, ptr %l37, !tbaa !21
  br label %bb29
bb29:
  %t64 = load i1, ptr %l37, !tbaa !21
  br i1 %t64, label %bb30, label %bb31
bb30:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load ptr, ptr %l2, !tbaa !29
  %t69 = call i1 @compiler_2fcheck_2ementions(ptr %v0, ptr %v2, ptr %t65, ptr %t66)
  store i1 %t69, ptr %l44
  br label %bb32
bb31:
  br label %bb39
bb32:
  %t70 = load i1, ptr %l44, !tbaa !21
  br i1 %t70, label %bb33, label %bb34
bb33:
  %t71 = load ptr, ptr %l4, !tbaa !29
  store ptr %t71, ptr %l45, !tbaa !29
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %t72)
  store %"compiler/source:Span" %t74, ptr %l47
  br label %bb35
bb34:
  br label %bb38
bb35:
  %t75 = load %"compiler/source:Span", ptr %l47
  %t76 = call i64 @compiler_2fcheck_2ectKey(%"compiler/source:Span" %t75)
  store i64 %t76, ptr %l48
  br label %bb36
bb36:
  %t77 = load ptr, ptr %l45, !tbaa !29
  %t78 = load i64, ptr %l48, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v4, ptr %t77, i64 %t78)
  br label %bb37
bb37:
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb39:
  %t79 = load ptr, ptr @__olang_prog_scope
  %t80 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aExpr_26_3e(ptr %t79)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t80, ptr %l49
  br label %bb40
bb40:
  %t81 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l49
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t81, ptr %l6
  %t82 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2echildren(ptr %v0, ptr %s0, ptr %t82, ptr %l6)
  br label %bb41
bb41:
  store ptr %l6, ptr %l7, !tbaa !29
  store i64 0, ptr %l8, !tbaa !24
  br label %bb42
bb42:
  store %olang.scope zeroinitializer, ptr %s8
  %t86 = load ptr, ptr %l7, !tbaa !29
  %t87 = load i64, ptr %l8, !tbaa !24
  %t90 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aExpr_26_3e_2eRunFrom_3ccompiler_2fast_3aExpr_26_3e(ptr %s0, ptr %t86, i64 %t87)
  %t91 = extractvalue { i32, { i64, ptr } } %t90, 1
  %t92 = extractvalue { i32, { i64, ptr } } %t90, 0
  store i32 %t92, ptr %l57
  %t93 = icmp ne i32 %t92, 0
  br i1 %t93, label %bb44, label %ok.94
ok.94:
  store { i64, ptr } %t91, ptr %l56
  br label %bb43
bb43:
  %t95 = load { i64, ptr }, ptr %l56, !tbaa !27
  store { i64, ptr } %t95, ptr %l53, !tbaa !27
  br label %bb48
bb44:
  %t96 = load i32, ptr %l57, !tbaa !23
  %t97 = ashr i32 %t96, 16
  %t99 = icmp eq i32 %t97, 1
  br i1 %t99, label %bb45, label %bb46
bb45:
  br label %bb47
bb46:
  call void @__olang_check_failed(ptr @olang_loc_9968ca61e870dfa2_23744643ae92cbe6)
  unreachable
bb47:
  call void @__olang_scope_close(ptr %s8)
  br label %bb57
bb48:
  %t101 = load { i64, ptr }, ptr %l53, !tbaa !27
  store { i64, ptr } %t101, ptr %l9, !tbaa !27
  %t102 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t104 = extractvalue { i64, ptr } %t102, 0
  store i64 %t104, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb49
bb49:
  store %olang.scope zeroinitializer, ptr %s9
  %t106 = load i64, ptr %l11, !tbaa !24
  %t107 = load i64, ptr %l10, !tbaa !24
  %t110 = icmp slt i64 %t106, %t107
  %t112 = xor i1 %t110, true
  br i1 %t112, label %bb50, label %bb51
bb50:
  call void @__olang_scope_close(ptr %s9)
  br label %bb55
bb51:
  br label %bb52
bb52:
  %t114 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t114, ptr %l66, !tbaa !27
  %t115 = load i64, ptr %l11, !tbaa !24
  %t117 = getelementptr { i64, ptr }, ptr %l66, i32 0, i32 1
  %t118 = load ptr, ptr %t117, !tbaa !27
  %t119 = getelementptr ptr, ptr %t118, i64 %t115
  %t120 = load ptr, ptr %t119, !tbaa !39
  %t123 = load ptr, ptr %l1, !tbaa !29
  %t124 = load ptr, ptr %l2, !tbaa !29
  %t125 = load ptr, ptr %l3, !tbaa !29
  %t126 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fcheck_2eentryOf(ptr %s0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %t120, ptr %t123, ptr %t124, ptr %t125, ptr %t126)
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s9)
  br label %bb54
bb54:
  %t132 = load i64, ptr %l11, !tbaa !24
  %t134 = add i64 %t132, 1
  store i64 %t134, ptr %l11, !tbaa !24
  br label %bb49
bb55:
  %t136 = load i64, ptr %l8, !tbaa !24
  %t137 = load i64, ptr %l10, !tbaa !24
  %t140 = add i64 %t136, %t137
  store i64 %t140, ptr %l8, !tbaa !24
  call void @__olang_scope_close(ptr %s8)
  br label %bb56
bb56:
  br label %bb42
bb57:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fcheck_2efloatBits(i32 %a0, double %a1) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca double
  %rv = alloca i64
  store i32 %a0, ptr %l0
  store double %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0, !tbaa !23
  %t3 = icmp eq i32 %t1, 13
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load double, ptr %l1, !tbaa !26
  %t7 = fptrunc double %t5 to float
  %t9 = bitcast float %t7 to i32
  %t11 = zext i32 %t9 to i64
  store i64 %t11, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t13 = load i32, ptr %l0, !tbaa !23
  %t15 = icmp eq i32 %t13, 11
  br i1 %t15, label %bb4, label %bb5
bb4:
  %t17 = load double, ptr %l1, !tbaa !26
  %t19 = fptrunc double %t17 to half
  %t21 = bitcast half %t19 to i16
  %t22 = call i16 asm "", "=r,0"(i16 %t21)
  %t24 = zext i16 %t22 to i64
  store i64 %t24, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t26 = load i32, ptr %l0, !tbaa !23
  %t28 = icmp eq i32 %t26, 12
  br i1 %t28, label %bb7, label %bb8
bb7:
  %t30 = load double, ptr %l1, !tbaa !26
  %t32 = fptrunc double %t30 to bfloat
  %t34 = bitcast bfloat %t32 to i16
  %t35 = call i16 asm "", "=r,0"(i16 %t34)
  %t37 = zext i16 %t35 to i64
  store i64 %t37, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t39 = load double, ptr %l1, !tbaa !26
  %t41 = bitcast double %t39 to i64
  store i64 %t41, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fcheck_2efloatOverflows(i32 %a0, double %a1) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca double
  %l2 = alloca double
  %l5 = alloca i1
  %l27 = alloca i1
  %rv = alloca i1
  store i32 %a0, ptr %l0
  store double %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load double, ptr %l1, !tbaa !26
  %t3 = fcmp ogt double %t1, 0x7fefffffffffffff
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l5, !tbaa !21
  br label %bb3
bb2:
  %t5 = load double, ptr %l1, !tbaa !26
  %t7 = fcmp olt double %t5, 0xffefffffffffffff
  store i1 %t7, ptr %l5, !tbaa !21
  br label %bb3
bb3:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb4, label %bb5
bb4:
  store i1 false, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t11 = load double, ptr %l1, !tbaa !26
  store double %t11, ptr %l2, !tbaa !26
  %t13 = load i32, ptr %l0, !tbaa !23
  %t15 = icmp eq i32 %t13, 13
  br i1 %t15, label %bb7, label %bb8
bb7:
  %t17 = load double, ptr %l1, !tbaa !26
  %t19 = fptrunc double %t17 to float
  %t21 = fpext float %t19 to double
  store double %t21, ptr %l2, !tbaa !26
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t23 = load i32, ptr %l0, !tbaa !23
  %t25 = icmp eq i32 %t23, 11
  br i1 %t25, label %bb10, label %bb11
bb10:
  %t27 = load double, ptr %l1, !tbaa !26
  %t29 = fptrunc double %t27 to half
  %t31 = fpext half %t29 to double
  store double %t31, ptr %l2, !tbaa !26
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t33 = load i32, ptr %l0, !tbaa !23
  %t35 = icmp eq i32 %t33, 12
  br i1 %t35, label %bb13, label %bb14
bb13:
  %t37 = load double, ptr %l1, !tbaa !26
  %t39 = fptrunc double %t37 to bfloat
  %t41 = bitcast bfloat %t39 to i16
  %t42 = zext i16 %t41 to i32
  %t43 = shl i32 %t42, 16
  %t44 = bitcast i32 %t43 to float
  %t45 = fpext float %t44 to double
  store double %t45, ptr %l2, !tbaa !26
  br label %bb15
bb14:
  br label %bb15
bb15:
  %t47 = load double, ptr %l2, !tbaa !26
  %t49 = fcmp ogt double %t47, 0x7fefffffffffffff
  br i1 %t49, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb18
bb17:
  %t51 = load double, ptr %l2, !tbaa !26
  %t53 = fcmp olt double %t51, 0xffefffffffffffff
  store i1 %t53, ptr %l27, !tbaa !21
  br label %bb18
bb18:
  %t55 = load i1, ptr %l27, !tbaa !21
  store i1 %t55, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2eifAssigns(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l6 = alloca i1
  %l15 = alloca i1
  %l20 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/ast:If", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  %t8 = xor i1 %t6, true
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/ast:If", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = icmp eq ptr %t13, null
  br i1 %t15, label %bb3, label %bb4
bb2:
  store i1 false, ptr %l6, !tbaa !21
  br label %bb7
bb3:
  call void @__olang_check_failed(ptr @olang_loc_cc3b6ed7ca85eab5_875d9ef7a16c4e59)
  unreachable
bb4:
  br label %bb5
bb5:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/ast:If", ptr %t17, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t23 = getelementptr %"compiler/ast:Branch", ptr %t20, i32 0, i32 1
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  %t25 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t28 = call i1 @compiler_2fcheck_2eassignsName(ptr %v0, ptr %v1, { i64, ptr } %t24, { i64, ptr } %t25)
  store i1 %t28, ptr %l15
  br label %bb6
bb6:
  %t29 = load i1, ptr %l15, !tbaa !21
  store i1 %t29, ptr %l6, !tbaa !21
  br label %bb7
bb7:
  %t30 = load i1, ptr %l6, !tbaa !21
  br i1 %t30, label %bb8, label %bb9
bb8:
  store i1 true, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/ast:If", ptr %t32, i32 0, i32 2
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t36 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t39 = call i1 @compiler_2fcheck_2estmtAssigns(ptr %v0, ptr %v1, ptr %t35, { i64, ptr } %t36)
  store i1 %t39, ptr %l20
  br label %bb11
bb11:
  %t40 = load i1, ptr %l20, !tbaa !21
  store i1 %t40, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2eisData(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l1, !tbaa !29
  store i1 false, ptr %l2, !tbaa !21
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l2, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l2, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store i1 true, ptr %rv
  br label %ret
bb6:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ematchAssigns(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l14 = alloca { i64, ptr }
  %l20 = alloca i1
  %l28 = alloca i1
  %l37 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Match", ptr %t1, i32 0, i32 3
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb3:
  br label %bb4
bb4:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %l14, !tbaa !27
  %t19 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr ptr, ptr %t22, i64 %t19
  %t24 = load ptr, ptr %t23, !tbaa !39
  %t28 = getelementptr %"compiler/ast:Case", ptr %t24, i32 0, i32 4
  %t29 = load { i64, ptr }, ptr %t28, !tbaa !27
  %t30 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t33 = call i1 @compiler_2fcheck_2eassignsName(ptr %v0, ptr %v1, { i64, ptr } %t29, { i64, ptr } %t30)
  store i1 %t33, ptr %l20
  br label %bb5
bb5:
  %t34 = load i1, ptr %l20, !tbaa !21
  br i1 %t34, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb9
bb9:
  %t36 = load i64, ptr %l3, !tbaa !24
  %t38 = add i64 %t36, 1
  store i64 %t38, ptr %l3, !tbaa !24
  br label %bb1
bb10:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/ast:Match", ptr %t40, i32 0, i32 4
  %t43 = load ptr, ptr %t42, !tbaa !29
  %t45 = icmp eq ptr %t43, null
  %t47 = xor i1 %t45, true
  br i1 %t47, label %bb11, label %bb12
bb11:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/ast:Match", ptr %t49, i32 0, i32 4
  %t52 = load ptr, ptr %t51, !tbaa !29
  %t54 = icmp eq ptr %t52, null
  br i1 %t54, label %bb13, label %bb14
bb12:
  store i1 false, ptr %l28, !tbaa !21
  br label %bb17
bb13:
  call void @__olang_check_failed(ptr @olang_loc_bff01f20505ccdb5_4aab420456ab469)
  unreachable
bb14:
  br label %bb15
bb15:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/ast:Match", ptr %t56, i32 0, i32 4
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t62 = getelementptr %"compiler/ast:Case", ptr %t59, i32 0, i32 4
  %t63 = load { i64, ptr }, ptr %t62, !tbaa !27
  %t64 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t67 = call i1 @compiler_2fcheck_2eassignsName(ptr %v0, ptr %v1, { i64, ptr } %t63, { i64, ptr } %t64)
  store i1 %t67, ptr %l37
  br label %bb16
bb16:
  %t68 = load i1, ptr %l37, !tbaa !21
  store i1 %t68, ptr %l28, !tbaa !21
  br label %bb17
bb17:
  %t69 = load i1, ptr %l28, !tbaa !21
  store i1 %t69, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/source:Span" @compiler_2fcheck_2ememberSpan(%"compiler/source:Span" %a0, i64 %a1) #0 {
entry:
  %l0 = alloca %"compiler/source:Span"
  %l7 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store %"compiler/source:Span" %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = getelementptr %"compiler/source:Span", ptr %l0, i32 0, i32 1
  %t2 = load i32, ptr %t1, !tbaa !23
  %t5 = trunc i64 %a1 to i32
  %t8 = sub i32 %t2, %t5
  %t9 = getelementptr %"compiler/source:Span", ptr %l0, i32 0, i32 1
  %t10 = load i32, ptr %t9, !tbaa !23
  %t13 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %t8, i32 %t10)
  store %"compiler/source:Span" %t13, ptr %l7
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t14 = load %"compiler/source:Span", ptr %l7
  store %"compiler/source:Span" %t14, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local %"compiler/check:Ask" @compiler_2fcheck_3aAsk_2ector(ptr %v0, ptr %v1, ptr %v2, i64 %a0, i64 %a1, i32 %a2, ptr %a3, i64 %a4, { i64, ptr } %a5) #0 {
entry:
  %rv = alloca %"compiler/check:Ask"
  br label %start
start:
  br label %bb0
bb0:
  %t14 = insertvalue %"compiler/check:Ask" undef, i64 %a0, 0
  %t16 = insertvalue %"compiler/check:Ask" %t14, i64 %a1, 1
  %t18 = insertvalue %"compiler/check:Ask" %t16, i32 %a2, 2
  %t20 = insertvalue %"compiler/check:Ask" %t18, ptr %a3, 3
  %t22 = insertvalue %"compiler/check:Ask" %t20, i64 %a4, 4
  %t24 = insertvalue %"compiler/check:Ask" %t22, { i64, ptr } %a5, 5
  store %"compiler/check:Ask" %t24, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:Ask", ptr %rv
  ret %"compiler/check:Ask" %rr
}

define dso_local %"compiler/check:litv" @compiler_2fcheck_3alitv_2ector(ptr %v0, i1 %a0, i1 %a1, i1 %a2, i64 %a3, double %a4) #0 {
entry:
  %rv = alloca %"compiler/check:litv"
  br label %start
start:
  br label %bb0
bb0:
  %t12 = insertvalue %"compiler/check:litv" undef, i1 %a0, 0
  %t14 = insertvalue %"compiler/check:litv" %t12, i1 %a1, 1
  %t16 = insertvalue %"compiler/check:litv" %t14, i1 %a2, 2
  %t18 = insertvalue %"compiler/check:litv" %t16, i64 %a3, 3
  %t20 = insertvalue %"compiler/check:litv" %t18, double %a4, 4
  %t22 = insertvalue %"compiler/check:litv" %t20, i1 false, 5
  store %"compiler/check:litv" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:litv", ptr %rv
  ret %"compiler/check:litv" %rr
}

define dso_local %"compiler/check:opShape" @compiler_2fcheck_3aopShape_2ector(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i1 %a2, i1 %a3) #0 {
entry:
  %rv = alloca %"compiler/check:opShape"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/check:opShape" undef, { i64, ptr } %a0, 0
  %t12 = insertvalue %"compiler/check:opShape" %t10, i64 %a1, 1
  %t14 = insertvalue %"compiler/check:opShape" %t12, i1 %a2, 2
  %t16 = insertvalue %"compiler/check:opShape" %t14, i1 %a3, 3
  store %"compiler/check:opShape" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:opShape", ptr %rv
  ret %"compiler/check:opShape" %rr
}

define dso_local %"compiler/check:roOrigin" @compiler_2fcheck_3aroOrigin_2ector(ptr %v0, ptr %v1, ptr %a0, i1 %a1) #0 {
entry:
  %rv = alloca %"compiler/check:roOrigin"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/check:roOrigin" undef, ptr %a0, 0
  %t8 = insertvalue %"compiler/check:roOrigin" %t6, i1 %a1, 1
  store %"compiler/check:roOrigin" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:roOrigin", ptr %rv
  ret %"compiler/check:roOrigin" %rr
}

define dso_local void @olang_2einit_2ecompiler_2fcheck() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  call void @compiler_2fcheck_2eCtReq_2einit()
  br label %bb1
bb1:
  call void @compiler_2fcheck_2eCtEns_2einit()
  br label %bb2
bb2:
  call void @compiler_2fcheck_2eCtEntry_2einit()
  br label %bb3
bb3:
  call void @compiler_2fcheck_2eOpShapes_2einit()
  br label %bb4
bb4:
  call void @compiler_2fcheck_2eContractWord_2einit()
  br label %bb5
bb5:
  call void @compiler_2fcheck_2eBounds_2einit()
  br label %bb6
bb6:
  call void @compiler_2fcheck_2eDivideByZero_2einit()
  br label %bb7
bb7:
  call void @compiler_2fcheck_2eOverflow_2einit()
  br label %bb8
bb8:
  call void @compiler_2fcheck_2eInvalid_2einit()
  br label %bb9
bb9:
  call void @compiler_2fcheck_2eWrongCase_2einit()
  br label %bb10
bb10:
  call void @compiler_2fcheck_2eRoStored_2einit()
  br label %bb11
bb11:
  call void @compiler_2fcheck_2eRoDecl_2einit()
  br label %bb12
bb12:
  call void @compiler_2fcheck_2eRoReturned_2einit()
  br label %bb13
bb13:
  call void @compiler_2fcheck_2eRoGlobal_2einit()
  br label %bb14
bb14:
  call void @compiler_2fcheck_2eliteralOrder_2einit()
  br label %bb15
bb15:
  br label %ret
ret:
  ret void
}

define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
chunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare void @__olang_check_failed(ptr)
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
@.d0 = private constant [36 x i8] c"a catch item the checker cannot find"
@__olang_prog_scope = external thread_local(initialexec) global ptr
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aClause_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aClause_26_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.d1 = private constant [25 x i8] c"a conversion of this kind"
@.d2 = private constant [0 x i8] c""
@.d3 = private constant [44 x i8] c"the checker asked for a frame with none open"
declare void @__olang_check_failed_text(ptr, { i64, ptr })
@.d4 = private constant [63 x i8] c"a generic type's constructor with its arguments inferred (G10c)"
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.d5 = private constant [3 x i8] c"F64"
@.d6 = private constant [20 x i8] c"std/prelude/iterator"
@.d7 = private constant [9 x i8] c"Exhausted"
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.d8 = private constant [10 x i8] c") noreturn"
@.d9 = private constant [13 x i8] c"no parameters"
@.d10 = private constant [13 x i8] c"one parameter"
declare i64 @__olang_fmt_i64(ptr, i64)
@.d11 = private constant [11 x i8] c" parameters"
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d12 = private constant [3 x i8] c"one"
@.d13 = private constant [4 x i8] c"none"
@.d14 = private constant [9 x i8] c"at least "
@.d15 = private constant [4 x i8] c"Bool"
@.d16 = private constant [5 x i8] c"'xor'"
@.d17 = private constant [6 x i8] c"MatMul"
@.d18 = private constant [3 x i8] c"'@'"
@.d19 = private constant [0 x i8] c""
@.d20 = private constant [1 x i8] c"'"
@.d21 = private constant [1 x i8] c"'"
@.d22 = private constant [1 x i8] c"'"
@.d23 = private constant [1 x i8] c"'"
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fsource_3aSpan(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = getelementptr %"compiler/source:Span", ptr %t1, i32 0, i32 0
  %t3 = load i32, ptr %t2, !tbaa !23
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t5 = getelementptr %"compiler/source:Span", ptr %t4, i32 0, i32 0
  %t6 = load i32, ptr %t5, !tbaa !23
  %t9 = icmp eq i32 %t3, %t6
  br i1 %t9, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb4
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/source:Span", ptr %t11, i32 0, i32 1
  %t13 = load i32, ptr %t12, !tbaa !23
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr %"compiler/source:Span", ptr %t14, i32 0, i32 1
  %t16 = load i32, ptr %t15, !tbaa !23
  %t19 = icmp eq i32 %t13, %t16
  br i1 %t19, label %bb3, label %bb1
bb3:
  br label %bb4
bb4:
  %t21 = load i1, ptr %l2, !tbaa !21
  store i1 %t21, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d24 = private constant [6 x i8] c"String"
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aExpr_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fast_3aExpr_26_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@G_2ecompiler_2fcheck_2eBounds = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fcheck_2eCtEns = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fcheck_2eCtEntry = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2fcheck_2ebuiltAst(ptr %v0, ptr %a0)
declare i1 @compiler_2fcheck_2eclosedExpr(ptr %v0, ptr %a0)
@olang_loc_3ee32a1caa2e355c_4063d0a06727bdc8 = external constant [0 x i8]
@olang_loc_a6ae1e9a693d05c9_888d1f7981f90365 = external constant [0 x i8]
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eExprBodyIn(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i64 %a1, i64 %a2, { i64, ptr } %a3, { i64, ptr } %a4, ptr %a5, i32 %a6)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2fcheck_2eOverflow = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fcheck_2eInvalid = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\08\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echeckOp(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
@G_2ecompiler_2fcheck_2eDivideByZero = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@olang_loc_f7ded25ed6635e09_bde75c58edf40565 = external constant [0 x i8]
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fload_3aImport_3e_2eRunFrom_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_8144c9e107914b58_42c61ae8c534985c = external constant [0 x i8]
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eGet_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echeckNow(ptr %v0, ptr %a0, i64 %a1)
declare { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftypes_3aListId_3e__H9cb5d99387f926677a92c13412f9a8b2(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %a0, i32 %a1)
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %v0, i64 %a0, i64 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_Hb6f924c91b81223120b2cba278ece4a6(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunsettle(ptr %v0, ptr %a0)
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyKey(ptr %v0, ptr %a0, i64 %a1)
declare { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_Hf3bb75ba9d3f922b4d327e9d3c1adfb0(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eReopen(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eblockOf(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i32 %a2, %"compiler/source:Span" %a3)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eEndHold(ptr %v0, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare ptr @compiler_2fcheck_2ecasePath(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaseTestNotEnum(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/msgs:Msg" %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaseTestOther(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare ptr @compiler_2fcheck_2ereadPlace(ptr %v0, ptr %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
@olang_loc_e1487403b47c0485_2c2fc5ff7a99fd49 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseTest(ptr %v0, ptr %v1, ptr %a0, ptr %a1, ptr %a2, i32 %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enegate(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeNamed(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCaseNames(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecasePublic(ptr %v0, ptr %a0, i32 %a1, i32 %a2, %"compiler/source:Span" %a3)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorType(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare %"compiler/typed:Item" @compiler_2ftyped_3aItem_2ector(ptr %v0, i32 %a0, i64 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aItem_3e_2ePush_3ccompiler_2ftyped_3aItem_3e(ptr %v0, ptr %a0, %"compiler/typed:Item" %a1)
declare { i64, i32 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrorWord(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2)
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aClause_26_3e_2eA_H5c1658fda327bafea70286240d031c3b(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecatchSpan(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCatchAfterCatchAll(ptr %v0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aClause_26_3e_2eP_Hee51906bde9346e7b7b6808fdce5ba81(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrWords(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCatchUnreachable(ptr %v0)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edefaultSpan(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefaultInStatement(ptr %v0)
@G_2ecompiler_2ftypes_2eVoidT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefaultNoValue(ptr %v0)
@olang_loc_20fb2e81a5b7d68a_7759df49ce89a9e = external constant [0 x i8]
declare i1 @compiler_2fcheck_2eleavesValue(ptr %v0, ptr %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefaultDead(ptr %v0)
declare i1 @compiler_2fcheck_2elastIsValue(ptr %v0, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCatchMustLeave(ptr %v0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefaultCount(ptr %v0, i64 %a0, i64 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eArgCount(ptr %v0, ptr %v1, i64 %a0, { i64, ptr } %a1, i64 %a2)
declare %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitFits(ptr %v0, ptr %a0, %"compiler/check:litv" %a1, i32 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eshiftLit(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %a0, ptr %a1, %"compiler/source:Span" %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeMismatch(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvWords(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ePus_H51a5125d8f537c6ff8e01fc80ef561c7(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econversionAt(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, ptr %a3, i32 %a4)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3)
@G_2ecompiler_2ftypes_2eBoolT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i32 %a3, i32 %a4, i64 %a5)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v1, i32 %a0, { i64, ptr } %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %a0)
declare { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmtsOf(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i32, i64 } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i64 %a3, i64 %a4)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econd1(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebreakUnless(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echeck(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %a0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, i32 %a3, i32 %a4, { i64, [2 x i64] } %a5)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroLet(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/generic:Context" @compiler_2fgeneric_3aContext_2ector(ptr %v0, i64 %a0, i64 %a1)
@olang_loc_5a93da9c7afac93d_73d680f9d44bf021 = external constant [0 x i8]
declare %"compiler/ast:Path" @compiler_2fast_3aPath_2ector(ptr %v0, ptr %v1, %"compiler/source:Span" %a0, { i64, ptr } %a1)
@olang_loc_cb89be5255da0a98_182555ab3f6639bc = external constant [0 x i8]
@olang_loc_920e32cd1c61adb_5a2712b6fcd7371f = external constant [0 x i8]
declare { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnknownErrorType(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/msgs:Msg" %a2)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNumber(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceSig(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enewBody(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, i32 %a2, i64 %a3, %"compiler/source:Span" %a4)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einfersErrs(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fcheck_3aframe_26_3_H2d42092ce658fb6cce0104fa754a4e33(ptr %v0, ptr %a0)
@olang_loc_fd7c4531a6f9112_8820f62eca2e3ad6 = external constant [0 x i8]
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fcheck_3aframe_26_3_Hbcd822ae67306ca6a025f17ed2cfb61c(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplace(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eelemPlace(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, { i64, ptr } %a3)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econstruct(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, { i64, ptr } %a4)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSelfType(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorSig(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fgeneric_2eDeclOwner(i32 %a0)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclParams(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/generic:Binding" @compiler_2fgeneric_3aBinding_2ector(ptr %v0, i64 %a0, i64 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitFloat(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunify(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, ptr %a3, i1 %a4, i1 %a5)
@G_2ecompiler_2ftypes_2eNoreturnT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\11\00\00\00" }>, align 8
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebindType(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInferThroughBounds(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCtorTypeArgsNotInferable(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
@G_2ecompiler_2ftypes_2eReadOnly = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstance(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstancesMet(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorBody(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2eToA_H3b732fb6bb2c20fd2f0446a621d56c2c(ptr %v0, ptr %v1, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallBody(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, ptr %a4, i64 %a5, ptr %a6, { i64, ptr } %a7, { i64, ptr } %a8)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewordCount(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %a0, i32 %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aClause_26_3e_2eR_H9395c9c55f40ca4e18bbadf0b4ab31aa(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_c9e70fc2ae99f8ec_a4a86a2066a83508 = external constant [0 x i8]
declare %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i32, %"compiler/source:Span" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H7d5384a5030fc995e793b3fe1f57e776(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteLiteralRangeExpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, [3 x i64] } %a2, %"compiler/msgs:Msg" %a3)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteLiteralRange(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteLiteralLocal(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePreludeType(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0)
@olang_loc_652199a1d15cfac6_f2a0b86627c88902 = external constant [0 x i8]
@olang_loc_7509e56452997e5b_fb360af196d85db7 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i64 %a3, ptr %a4, { i64, ptr } %a5, { i64, ptr } %a6, { i64, ptr } %a7)
declare i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eTrun_H62a150000c9aaeb3d030aed80f9d3e2e(ptr %v0, ptr %a0, i64 %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eRunF_H9c1707946c43ec840ffe1821bea89b1f(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_d1119d7289e18fc7_4b5c36986650edfb = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enamesTypeVar(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v0, ptr %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewrittenRefOrVar(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMeet(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eLiteralDoesNotMeet(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emustWrite(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2, i1 %a3)
declare i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare { i64, ptr } @compiler_2fcheck_2elowerFirst(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotTheOperator(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteDeclaredHere(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3anullNarrow_3e_2e_H7b40d2e2dc0a1b98abd717d3c6137546(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_9c106c9f4aa088c5_d9578fd6b61bf4a9 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2esamePath(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2ecompares(i32 %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i64 %a3)
declare i32 @compiler_2fcheck_2ebinaryOp(i32 %a0)
declare { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %v0, i32 %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eOperandNotNumber(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eOperandNotBool(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoperatorCall(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, ptr %a4, ptr %a5)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eMatmulUndeclared(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeqMethod(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eequality(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3, ptr %a4)
declare { i64, ptr } @compiler_2fcheck_2eoperatorName(ptr %v0, i32 %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eOperandsDiffer(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisInt(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eOperandNotInt(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eExtends(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotExtendedOp(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echeckedPrim(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3, ptr %a4, ptr %a5)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNumbersDoNotMeet(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2eintOnly(i32 %a0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erootLocal(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparamIndex(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_1f453287a90ee701_f75bf1e5be6f432d = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eProtocolPrivate(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrorOncePerLine(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/msgs:Msg" %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparamLen(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, ptr } %a2)
declare void @compiler_2fcheck_2enamesIn(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2eRun_H660dd195b8dfbe46b01e30313ba3abe1(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_35725fa398e3a571_191401de5ef7023d = external constant [0 x i8]
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalNamed(ptr %v0, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H8da9376267bda3f76393292be0e507b2(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalType(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_Ha6bcf4d517e3d7b46809e1dbf938da91(ptr %v0, ptr %a0)
declare { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emarkAt(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyOfCallee(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstanceBody(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShareOf(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroByArg(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebracketIn(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroSettleDeep(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3cstd_2fpair_3aPa_H0373c7e46aeaf586ca7dddb6278d7312(ptr %v0, ptr %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3cstd_2fpair_3aPa_H4e5c12183874056031e206ecb8273178(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_94fb3c639c1db4f7_cb3989d33edb9243 = external constant [0 x i8]
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, i1 %a2)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aroArg_3e_2eRunFrom_3ccompiler_2fcheck_3aroArg_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_b42405a4ff8f50d6_8f3ce3b7732b4ac2 = external constant [0 x i8]
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eReadOnlyCopyArg(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estrReceivers(ptr %v0, ptr %a0)
@olang_loc_6fbbefab94ae0ced_3a79826f299b6b39 = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eReadOnlyRefKept(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aroFn_3e_2eRunFrom_3ccompiler_2fcheck_3aroFn_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_46f27f903cdc013c_b0b6515331b7b68 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroFix(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eReadOnlyFuncValue(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3cI64_2c_20compil_Hd792a4b485af98ba4ad9cd9a7f4f4722(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_674cd1771ebc67df_c0fbe9e0645b3c13 = external constant [0 x i8]
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %v0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroDeep(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2, ptr %a3)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_4accb82e327e9b5e_83bcad9ba4931212 = external constant [0 x i8]
@olang_loc_8e2cf6b2c24620f0_dcbb1c47a1cef46c = external constant [0 x i8]
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeEntry(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i32 %a3, i32 %a4)
declare %"compiler/generic:Context" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclContext(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTraitExtendsNotTrait(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereachesTrait(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i64 %a3)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTraitExtendsItself(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresolve(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eResolve(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsClosedTrait(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTraitMemberOpen(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMembers(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/generic:Unmet" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMissing(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i1 %a3, i64 %a4)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTraitMemberMissing(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einGeneric(ptr %v0, ptr %a0)
declare i1 @compiler_2fcheck_2echeckableAst(ptr %v0, ptr %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enothingFails(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i1 %a2, i1 %a3)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eproduced(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2, i64 %a3)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2enullDefault(ptr %v0, { i64, ptr } %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOrNull(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclause(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, i1 %a3)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaught(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, ptr %a3)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aClause_26_3e_2eL_H39694dc3b7c161b4999ab170e8f3fd84(ptr %v0, ptr %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eescapes(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, i64 %a3, i1 %a4)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aClause_26_3e_2eT_H39fa81f2ad510245a68cbacb663c8d87(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/typed:Try" @compiler_2ftyped_3aTry_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i1 %a2, i1 %a3)
@olang_loc_e722c21055ee6b49_58bcebf0b772fb7d = external constant [0 x i8]
@olang_loc_eca48244095fc078_aacf4c954a6e214c = external constant [0 x i8]
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eborrowedSource(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2)
@olang_loc_5c35d65bf515aa44_9edccba99dd9b7f8 = external constant [0 x i8]
@olang_loc_19568a04807ed851_528b5bfe222c3865 = external constant [0 x i8]
@olang_loc_130b25e968db6b32_47c65c95f253846 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eone(ptr %v0, ptr %a0, ptr %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkBody(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i32 %a3)
declare i1 @compiler_2fcheck_2ementions(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2fcheck_2ectKey(%"compiler/source:Span" %a0)
declare void @compiler_2fcheck_2echildren(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aExpr_26_3e_2eRunFrom_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_9968ca61e870dfa2_23744643ae92cbe6 = external constant [0 x i8]
@olang_loc_cc3b6ed7ca85eab5_875d9ef7a16c4e59 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2eassignsName(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2estmtAssigns(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_bff01f20505ccdb5_4aab420456ab469 = external constant [0 x i8]
declare void @compiler_2fcheck_2eCtReq_2einit()
declare void @compiler_2fcheck_2eOpShapes_2einit()
declare void @compiler_2fcheck_2eContractWord_2einit()
declare void @compiler_2fcheck_2eDivideByZero_2einit()
declare void @compiler_2fcheck_2eOverflow_2einit()
declare void @compiler_2fcheck_2eInvalid_2einit()
declare void @compiler_2fcheck_2eWrongCase_2einit()
declare void @compiler_2fcheck_2eRoStored_2einit()
declare void @compiler_2fcheck_2eRoDecl_2einit()
declare void @compiler_2fcheck_2eRoReturned_2einit()
declare void @compiler_2fcheck_2eRoGlobal_2einit()
declare void @compiler_2fcheck_2eliteralOrder_2einit()
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aClause_26_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fast_3aExpr_26_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
