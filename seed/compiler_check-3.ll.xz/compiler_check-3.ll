; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/check:opShape" = type { { i64, ptr }, i64, i1, i1 }
%"compiler/check:litv" = type { i1, i1, i1, i64, double, i1, i1, i1, i128 }
%"compiler/typed:Clause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr, { i64, ptr }, i64, i32 }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/generic:AnySlot" = type { i32, i32, i64, i64, i1, i32 }
%"compiler/generic:AnyTable" = type { i32, i32, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/msgs:Msg" = type { i32, { i64, ptr }, { i64, ptr } }
%"compiler/check:Checker" = type { ptr, ptr, i1, i1, i1, i1, i64, i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, { i64, [3 x i64] }, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i32, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"compiler/source:Span", i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i32, i1, i1, %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, i32, i32, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i64, i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/check:frame" = type { i64, i64, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"compiler/generic:Context", i32, i32, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i32, i64, i64, i64, i1, i64, i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i1, i64, i64, i64, i1, i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, i64, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/generic:Context" = type { i64, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/types:Table" = type { ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64 }
%"compiler/check:b5aWalk" = type { i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1 }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1 }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1, i1 }
%"compiler/ast:CaseDecl" = type { %"compiler/source:Span", i32, { i64, ptr }, i1, ptr }
%"compiler/generic:Desc" = type { i64, i32, i64, i64 }
%"compiler/ast:Case" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, ptr }
%"compiler/ast:Match" = type { %"compiler/source:Span", ptr, i1, { i64, ptr }, ptr }
%"compiler/typed:Make" = type { i32, i64, { i64, ptr }, ptr, i32, i32 }
%"compiler/typed:Try" = type { ptr, { i64, ptr }, i1, i1 }
%"compiler/typed:Promote" = type { ptr, i32 }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/generic:Binding" = type { i64, i64, { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/check:laneNode" = type { i64, i32, %"compiler/source:Span", %"compiler/source:Span", i64, i64, i64, ptr, i32, i64, i32 }
%"compiler/typed:Local" = type { i32, %"compiler/source:Span", i32, i32, i32, { i64, [2 x i64] } }
%"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" = type { i32, i64 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/ast:Path" = type { %"compiler/source:Span", { i64, ptr } }
%"compiler/check:reflVal" = type { i1, i64, i64, { i64, ptr }, i32 }
%"compiler/check:reflList" = type { i1, i32, i64, i64 }
%"compiler/names:Ref" = type { i32, i64, i64 }
%"compiler/check:roArg" = type { i64, i64, { i64, [3 x i64] }, { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" = type { i64, i64 }
%"std/pair:Pair.b139c4f75a6545712256427180a82a06" = type { %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" }
%"compiler/check:roDeepArg" = type { i64, ptr, i64, i64 }
%"compiler/typed:Call" = type { ptr, { i64, ptr }, { i64, [2 x i64] }, i32, i1 }
%"std/pair:Pair.1eb2466213689e002f25e81e83536e78" = type { i64, ptr }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, ptr, i1, i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/typed:Bind" = type { i32, ptr }
%"compiler/source:Source" = type { { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/ast:StructBody" = type { { i64, ptr }, ptr, { i64, ptr }, %"compiler/source:Span", { i64, ptr }, { i64, ptr } }
%"compiler/ast:VarDecl" = type { { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, i1, i1 }
%"compiler/check:narrowed" = type { i64, i64, i32, i64, i64 }
%"compiler/check:nullNarrow" = type { { i64, ptr }, i64, i1 }
define dso_local void @compiler_2fcheck_2eLaneArr_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr @G_2ecompiler_2fcheck_2eLaneArr, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2eLaneBin_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 2, ptr @G_2ecompiler_2fcheck_2eLaneBin, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2eLaneScalar_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 1, ptr @G_2ecompiler_2fcheck_2eLaneScalar, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2eOpShapes_2einit() #0 {
entry:
  %l0 = alloca %"compiler/check:opShape"
  %l1 = alloca %"compiler/check:opShape"
  %l2 = alloca %"compiler/check:opShape"
  %l3 = alloca %"compiler/check:opShape"
  %l4 = alloca %"compiler/check:opShape"
  %l5 = alloca %"compiler/check:opShape"
  %l6 = alloca %"compiler/check:opShape"
  %l7 = alloca %"compiler/check:opShape"
  %l8 = alloca %"compiler/check:opShape"
  %l9 = alloca %"compiler/check:opShape"
  %l10 = alloca %"compiler/check:opShape"
  %l11 = alloca %"compiler/check:opShape"
  %l12 = alloca %"compiler/check:opShape"
  %l13 = alloca %"compiler/check:opShape"
  %l14 = alloca %"compiler/check:opShape"
  %l15 = alloca %"compiler/check:opShape"
  %l16 = alloca %"compiler/check:opShape"
  %l17 = alloca %"compiler/check:opShape"
  %l18 = alloca %"compiler/check:opShape"
  %l19 = alloca %"compiler/check:opShape"
  %l20 = alloca %"compiler/check:opShape"
  %l21 = alloca %"compiler/check:opShape"
  %l22 = alloca [22 x %"compiler/check:opShape"]
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = load ptr, ptr @__olang_prog_scope
  %t3 = call %"compiler/check:opShape" @compiler_2fcheck_3aopShape_2ector(ptr %t1, ptr %t2, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d0, i32 0, i32 1) }, i64 1, i1 true, i1 true)
  store %"compiler/check:opShape" %t3, ptr %l0
  br label %bb1
bb1:
  %t4 = load ptr, ptr @__olang_prog_scope
  %t5 = load ptr, ptr @__olang_prog_scope
  %t6 = call %"compiler/check:opShape" @compiler_2fcheck_3aopShape_2ector(ptr %t4, ptr %t5, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d1, i32 0, i32 1) }, i64 1, i1 true, i1 true)
  store %"compiler/check:opShape" %t6, ptr %l1
  br label %bb2
bb2:
  %t7 = load ptr, ptr @__olang_prog_scope
  %t8 = load ptr, ptr @__olang_prog_scope
  %t9 = call %"compiler/check:opShape" @compiler_2fcheck_3aopShape_2ector(ptr %t7, ptr %t8, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d2, i32 0, i32 1) }, i64 1, i1 true, i1 true)
  store %"compiler/check:opShape" %t9, ptr %l2
  br label %bb3
bb3:
  %t10 = load ptr, ptr @__olang_prog_scope
  %t11 = load ptr, ptr @__olang_prog_scope
  %t12 = call %"compiler/check:opShape" @compiler_2fcheck_3aopShape_2ector(ptr %t10, ptr %t11, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d3, i32 0, i32 1) }, i64 1, i1 true, i1 true)
  store %"compiler/check:opShape" %t12, ptr %l3
  br label %bb4
bb4:
  %t13 = load ptr, ptr @__olang_prog_scope
  %t14 = load ptr, ptr @__olang_prog_scope
  %t15 = call %"compiler/check:opShape" @compiler_2fcheck_3aopShape_2ector(ptr %t13, ptr %t14, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d4, i32 0, i32 1) }, i64 1, i1 true, i1 true)
  store %"compiler/check:opShape" %t15, ptr %l4
  br label %bb5
bb5:
  %t16 = load ptr, ptr @__olang_prog_scope
  %t17 = load ptr, ptr @__olang_prog_scope
  %t18 = call %"compiler/check:opShape" @compiler_2fcheck_3aopShape_2ector(ptr %t16, ptr %t17, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d5, i32 0, i32 1) }, i64 1, i1 true, i1 true)
  store %"compiler/check:opShape" %t18, ptr %l5
  br label %bb6
bb6:
  %t19 = load ptr, ptr @__olang_prog_scope
  %t20 = load ptr, ptr @__olang_prog_scope
  %t21 = call %"compiler/check:opShape" @compiler_2fcheck_3aopShape_2ector(ptr %t19, ptr %t20, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d6, i32 0, i32 1) }, i64 0, i1 true, i1 true)
  store %"compiler/check:opShape" %t21, ptr %l6
  br label %bb7
bb7:
  %t22 = load ptr, ptr @__olang_prog_scope
  %t23 = load ptr, ptr @__olang_prog_scope
  %t24 = call %"compiler/check:opShape" @compiler_2fcheck_3aopShape_2ector(ptr %t22, ptr %t23, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d7, i32 0, i32 1) }, i64 1, i1 true, i1 true)
  store %"compiler/check:opShape" %t24, ptr %l7
  br label %bb8
bb8:
  %t25 = load ptr, ptr @__olang_prog_scope
  %t26 = load ptr, ptr @__olang_prog_scope
  %t27 = call %"compiler/check:opShape" @compiler_2fcheck_3aopShape_2ector(ptr %t25, ptr %t26, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d8, i32 0, i32 1) }, i64 1, i1 true, i1 true)
  store %"compiler/check:opShape" %t27, ptr %l8
  br label %bb9
bb9:
  %t28 = load ptr, ptr @__olang_prog_scope
  %t29 = load ptr, ptr @__olang_prog_scope
  %t30 = call %"compiler/check:opShape" @compiler_2fcheck_3aopShape_2ector(ptr %t28, ptr %t29, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d9, i32 0, i32 1) }, i64 2, i1 false, i1 true)
  store %"compiler/check:opShape" %t30, ptr %l9
  br label %bb10
bb10:
  %t31 = load ptr, ptr @__olang_prog_scope
  %t32 = load ptr, ptr @__olang_prog_scope
  %t33 = call %"compiler/check:opShape" @compiler_2fcheck_3aopShape_2ector(ptr %t31, ptr %t32, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d10, i32 0, i32 1) }, i64 2, i1 true, i1 true)
  store %"compiler/check:opShape" %t33, ptr %l10
  br label %bb11
bb11:
  %t34 = load ptr, ptr @__olang_prog_scope
  %t35 = load ptr, ptr @__olang_prog_scope
  %t36 = call %"compiler/check:opShape" @compiler_2fcheck_3aopShape_2ector(ptr %t34, ptr %t35, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d11, i32 0, i32 1) }, i64 1, i1 true, i1 true)
  store %"compiler/check:opShape" %t36, ptr %l11
  br label %bb12
bb12:
  %t37 = load ptr, ptr @__olang_prog_scope
  %t38 = load ptr, ptr @__olang_prog_scope
  %t39 = call %"compiler/check:opShape" @compiler_2fcheck_3aopShape_2ector(ptr %t37, ptr %t38, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d12, i32 0, i32 1) }, i64 1, i1 true, i1 true)
  store %"compiler/check:opShape" %t39, ptr %l12
  br label %bb13
bb13:
  %t40 = load ptr, ptr @__olang_prog_scope
  %t41 = load ptr, ptr @__olang_prog_scope
  %t42 = call %"compiler/check:opShape" @compiler_2fcheck_3aopShape_2ector(ptr %t40, ptr %t41, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d13, i32 0, i32 1) }, i64 1, i1 true, i1 true)
  store %"compiler/check:opShape" %t42, ptr %l13
  br label %bb14
bb14:
  %t43 = load ptr, ptr @__olang_prog_scope
  %t44 = load ptr, ptr @__olang_prog_scope
  %t45 = call %"compiler/check:opShape" @compiler_2fcheck_3aopShape_2ector(ptr %t43, ptr %t44, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d14, i32 0, i32 1) }, i64 1, i1 true, i1 true)
  store %"compiler/check:opShape" %t45, ptr %l14
  br label %bb15
bb15:
  %t46 = load ptr, ptr @__olang_prog_scope
  %t47 = load ptr, ptr @__olang_prog_scope
  %t48 = call %"compiler/check:opShape" @compiler_2fcheck_3aopShape_2ector(ptr %t46, ptr %t47, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d15, i32 0, i32 1) }, i64 1, i1 true, i1 true)
  store %"compiler/check:opShape" %t48, ptr %l15
  br label %bb16
bb16:
  %t49 = load ptr, ptr @__olang_prog_scope
  %t50 = load ptr, ptr @__olang_prog_scope
  %t51 = call %"compiler/check:opShape" @compiler_2fcheck_3aopShape_2ector(ptr %t49, ptr %t50, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d16, i32 0, i32 1) }, i64 0, i1 true, i1 true)
  store %"compiler/check:opShape" %t51, ptr %l16
  br label %bb17
bb17:
  %t52 = load ptr, ptr @__olang_prog_scope
  %t53 = load ptr, ptr @__olang_prog_scope
  %t54 = call %"compiler/check:opShape" @compiler_2fcheck_3aopShape_2ector(ptr %t52, ptr %t53, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d17, i32 0, i32 1) }, i64 0, i1 true, i1 true)
  store %"compiler/check:opShape" %t54, ptr %l17
  br label %bb18
bb18:
  %t55 = load ptr, ptr @__olang_prog_scope
  %t56 = load ptr, ptr @__olang_prog_scope
  %t57 = call %"compiler/check:opShape" @compiler_2fcheck_3aopShape_2ector(ptr %t55, ptr %t56, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d18, i32 0, i32 1) }, i64 0, i1 true, i1 true)
  store %"compiler/check:opShape" %t57, ptr %l18
  br label %bb19
bb19:
  %t58 = load ptr, ptr @__olang_prog_scope
  %t59 = load ptr, ptr @__olang_prog_scope
  %t60 = call %"compiler/check:opShape" @compiler_2fcheck_3aopShape_2ector(ptr %t58, ptr %t59, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d19, i32 0, i32 1) }, i64 0, i1 true, i1 false)
  store %"compiler/check:opShape" %t60, ptr %l19
  br label %bb20
bb20:
  %t61 = load ptr, ptr @__olang_prog_scope
  %t62 = load ptr, ptr @__olang_prog_scope
  %t63 = call %"compiler/check:opShape" @compiler_2fcheck_3aopShape_2ector(ptr %t61, ptr %t62, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d20, i32 0, i32 1) }, i64 1, i1 true, i1 false)
  store %"compiler/check:opShape" %t63, ptr %l20
  br label %bb21
bb21:
  %t64 = load ptr, ptr @__olang_prog_scope
  %t65 = load ptr, ptr @__olang_prog_scope
  %t66 = call %"compiler/check:opShape" @compiler_2fcheck_3aopShape_2ector(ptr %t64, ptr %t65, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d21, i32 0, i32 1) }, i64 0, i1 true, i1 false)
  store %"compiler/check:opShape" %t66, ptr %l21
  br label %bb22
bb22:
  %t67 = load %"compiler/check:opShape", ptr %l0
  %t68 = load %"compiler/check:opShape", ptr %l1
  %t69 = load %"compiler/check:opShape", ptr %l2
  %t70 = load %"compiler/check:opShape", ptr %l3
  %t71 = load %"compiler/check:opShape", ptr %l4
  %t72 = load %"compiler/check:opShape", ptr %l5
  %t73 = load %"compiler/check:opShape", ptr %l6
  %t74 = load %"compiler/check:opShape", ptr %l7
  %t75 = load %"compiler/check:opShape", ptr %l8
  %t76 = load %"compiler/check:opShape", ptr %l9
  %t77 = load %"compiler/check:opShape", ptr %l10
  %t78 = load %"compiler/check:opShape", ptr %l11
  %t79 = load %"compiler/check:opShape", ptr %l12
  %t80 = load %"compiler/check:opShape", ptr %l13
  %t81 = load %"compiler/check:opShape", ptr %l14
  %t82 = load %"compiler/check:opShape", ptr %l15
  %t83 = load %"compiler/check:opShape", ptr %l16
  %t84 = load %"compiler/check:opShape", ptr %l17
  %t85 = load %"compiler/check:opShape", ptr %l18
  %t86 = load %"compiler/check:opShape", ptr %l19
  %t87 = load %"compiler/check:opShape", ptr %l20
  %t88 = load %"compiler/check:opShape", ptr %l21
  %t89 = getelementptr [22 x %"compiler/check:opShape"], ptr %l22, i64 0, i64 0
  store %"compiler/check:opShape" %t67, ptr %t89
  %t90 = getelementptr [22 x %"compiler/check:opShape"], ptr %l22, i64 0, i64 1
  store %"compiler/check:opShape" %t68, ptr %t90
  %t91 = getelementptr [22 x %"compiler/check:opShape"], ptr %l22, i64 0, i64 2
  store %"compiler/check:opShape" %t69, ptr %t91
  %t92 = getelementptr [22 x %"compiler/check:opShape"], ptr %l22, i64 0, i64 3
  store %"compiler/check:opShape" %t70, ptr %t92
  %t93 = getelementptr [22 x %"compiler/check:opShape"], ptr %l22, i64 0, i64 4
  store %"compiler/check:opShape" %t71, ptr %t93
  %t94 = getelementptr [22 x %"compiler/check:opShape"], ptr %l22, i64 0, i64 5
  store %"compiler/check:opShape" %t72, ptr %t94
  %t95 = getelementptr [22 x %"compiler/check:opShape"], ptr %l22, i64 0, i64 6
  store %"compiler/check:opShape" %t73, ptr %t95
  %t96 = getelementptr [22 x %"compiler/check:opShape"], ptr %l22, i64 0, i64 7
  store %"compiler/check:opShape" %t74, ptr %t96
  %t97 = getelementptr [22 x %"compiler/check:opShape"], ptr %l22, i64 0, i64 8
  store %"compiler/check:opShape" %t75, ptr %t97
  %t98 = getelementptr [22 x %"compiler/check:opShape"], ptr %l22, i64 0, i64 9
  store %"compiler/check:opShape" %t76, ptr %t98
  %t99 = getelementptr [22 x %"compiler/check:opShape"], ptr %l22, i64 0, i64 10
  store %"compiler/check:opShape" %t77, ptr %t99
  %t100 = getelementptr [22 x %"compiler/check:opShape"], ptr %l22, i64 0, i64 11
  store %"compiler/check:opShape" %t78, ptr %t100
  %t101 = getelementptr [22 x %"compiler/check:opShape"], ptr %l22, i64 0, i64 12
  store %"compiler/check:opShape" %t79, ptr %t101
  %t102 = getelementptr [22 x %"compiler/check:opShape"], ptr %l22, i64 0, i64 13
  store %"compiler/check:opShape" %t80, ptr %t102
  %t103 = getelementptr [22 x %"compiler/check:opShape"], ptr %l22, i64 0, i64 14
  store %"compiler/check:opShape" %t81, ptr %t103
  %t104 = getelementptr [22 x %"compiler/check:opShape"], ptr %l22, i64 0, i64 15
  store %"compiler/check:opShape" %t82, ptr %t104
  %t105 = getelementptr [22 x %"compiler/check:opShape"], ptr %l22, i64 0, i64 16
  store %"compiler/check:opShape" %t83, ptr %t105
  %t106 = getelementptr [22 x %"compiler/check:opShape"], ptr %l22, i64 0, i64 17
  store %"compiler/check:opShape" %t84, ptr %t106
  %t107 = getelementptr [22 x %"compiler/check:opShape"], ptr %l22, i64 0, i64 18
  store %"compiler/check:opShape" %t85, ptr %t107
  %t108 = getelementptr [22 x %"compiler/check:opShape"], ptr %l22, i64 0, i64 19
  store %"compiler/check:opShape" %t86, ptr %t108
  %t109 = getelementptr [22 x %"compiler/check:opShape"], ptr %l22, i64 0, i64 20
  store %"compiler/check:opShape" %t87, ptr %t109
  %t110 = getelementptr [22 x %"compiler/check:opShape"], ptr %l22, i64 0, i64 21
  store %"compiler/check:opShape" %t88, ptr %t110
  call void @llvm.memmove.p0.p0.i64(ptr @G_2ecompiler_2fcheck_2eOpShapes, ptr %l22, i64 704, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2eRoGlobal_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 3, ptr @G_2ecompiler_2fcheck_2eRoGlobal, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/check:litv" @compiler_2fcheck_2eaddMag(i1 %a0, i128 %a1, i1 %a2, i128 %a3) #0 {
entry:
  %l0 = alloca i1
  %l1 = alloca i128
  %l2 = alloca i1
  %l3 = alloca i128
  %l4 = alloca i128
  %l14 = alloca %"compiler/check:litv"
  %l17 = alloca %"compiler/check:litv"
  %l25 = alloca %"compiler/check:litv"
  %l30 = alloca %"compiler/check:litv"
  %rv = alloca %"compiler/check:litv"
  store i1 %a0, ptr %l0
  store i128 %a1, ptr %l1
  store i1 %a2, ptr %l2
  store i128 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i1, ptr %l0, !tbaa !21
  %t2 = load i1, ptr %l2, !tbaa !21
  %t5 = icmp eq i1 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load i128, ptr %l1
  %t8 = load i128, ptr %l3
  %t11 = add i128 %t7, %t8
  store i128 %t11, ptr %l4
  %t13 = load i128, ptr %l4
  %t14 = load i128, ptr %l1
  %t17 = icmp ult i128 %t13, %t14
  br i1 %t17, label %bb3, label %bb4
bb2:
  br label %bb8
bb3:
  %t19 = call %"compiler/check:litv" @compiler_2fcheck_2enoLit()
  store %"compiler/check:litv" %t19, ptr %l14
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t20 = load %"compiler/check:litv", ptr %l14
  store %"compiler/check:litv" %t20, ptr %rv
  br label %ret
bb6:
  %t21 = load i1, ptr %l0, !tbaa !21
  %t22 = load i128, ptr %l4
  %t25 = call %"compiler/check:litv" @compiler_2fcheck_2eofMag(i1 %t21, i128 %t22)
  store %"compiler/check:litv" %t25, ptr %l17
  br label %bb7
bb7:
  %t26 = load %"compiler/check:litv", ptr %l17
  store %"compiler/check:litv" %t26, ptr %rv
  br label %ret
bb8:
  %t27 = load i128, ptr %l1
  %t28 = load i128, ptr %l3
  %t31 = icmp uge i128 %t27, %t28
  br i1 %t31, label %bb9, label %bb10
bb9:
  %t33 = load i1, ptr %l0, !tbaa !21
  %t34 = load i128, ptr %l1
  %t35 = load i128, ptr %l3
  %t38 = sub i128 %t34, %t35
  %t41 = call %"compiler/check:litv" @compiler_2fcheck_2eofMag(i1 %t33, i128 %t38)
  store %"compiler/check:litv" %t41, ptr %l25
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t42 = load %"compiler/check:litv", ptr %l25
  store %"compiler/check:litv" %t42, ptr %rv
  br label %ret
bb12:
  %t43 = load i1, ptr %l2, !tbaa !21
  %t44 = load i128, ptr %l3
  %t45 = load i128, ptr %l1
  %t48 = sub i128 %t44, %t45
  %t51 = call %"compiler/check:litv" @compiler_2fcheck_2eofMag(i1 %t43, i128 %t48)
  store %"compiler/check:litv" %t51, ptr %l30
  br label %bb13
bb13:
  %t52 = load %"compiler/check:litv", ptr %l30
  store %"compiler/check:litv" %t52, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:litv", ptr %rv
  ret %"compiler/check:litv" %rr
}

define dso_local i1 @compiler_2fcheck_2eclausesBreak(ptr %v0, { i64, ptr } %a0, i32 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l17 = alloca { i64, ptr }
  %l23 = alloca i1
  %l24 = alloca i1
  %l28 = alloca i1
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t8, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t14 = load i64, ptr %l3, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb17
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t22, ptr %l17, !tbaa !27
  %t23 = load i64, ptr %l3, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  store ptr %t28, ptr %l5, !tbaa !29
  %t30 = load ptr, ptr %l5, !tbaa !29
  %t32 = getelementptr %"compiler/typed:Clause", ptr %t30, i32 0, i32 3
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t34 = load i32, ptr %l1, !tbaa !23
  %t37 = call i1 @compiler_2fcheck_2ebreaks(ptr %v0, ptr %t33, i32 %t34)
  store i1 %t37, ptr %l23
  br label %bb8
bb8:
  %t38 = load i1, ptr %l23, !tbaa !21
  br i1 %t38, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l24, !tbaa !21
  br label %bb12
bb10:
  %t39 = load ptr, ptr %l5, !tbaa !29
  %t41 = getelementptr %"compiler/typed:Clause", ptr %t39, i32 0, i32 4
  %t42 = load { i64, ptr }, ptr %t41, !tbaa !27
  %t43 = load i32, ptr %l1, !tbaa !23
  %t46 = call i1 @compiler_2fcheck_2eexprsBreak(ptr %v0, { i64, ptr } %t42, i32 %t43)
  store i1 %t46, ptr %l28
  br label %bb11
bb11:
  %t47 = load i1, ptr %l28, !tbaa !21
  store i1 %t47, ptr %l24, !tbaa !21
  br label %bb12
bb12:
  %t48 = load i1, ptr %l24, !tbaa !21
  br i1 %t48, label %bb13, label %bb14
bb13:
  store i1 true, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  br label %bb16
bb16:
  %t50 = load i64, ptr %l3, !tbaa !24
  %t52 = add i64 %t50, 1
  store i64 %t52, ptr %l3, !tbaa !24
  br label %bb4
bb17:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyTable(ptr %v0, ptr %a0, i32 %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca { i64, i1 }
  %l5 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca i32
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l15 = alloca %"compiler/generic:AnySlot"
  %l16 = alloca i64
  %l17 = alloca i32
  %l18 = alloca i64
  %l19 = alloca %"compiler/generic:AnyTable"
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca %"compiler/generic:AnySlot"
  %l31 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l33 = alloca ptr
  %l34 = alloca i32
  %l35 = alloca i32
  %l37 = alloca ptr
  %l41 = alloca { i64, i1 }
  %l49 = alloca i1
  %l50 = alloca i64
  %l55 = alloca { i64, ptr }
  %l57 = alloca ptr
  %l62 = alloca i32
  %l63 = alloca i32
  %l69 = alloca i64
  %l72 = alloca i64
  %l90 = alloca { i64, ptr }
  %l97 = alloca i64
  %l105 = alloca i32
  %l107 = alloca ptr
  %l109 = alloca i64
  %l110 = alloca i64
  %l115 = alloca i32
  %l122 = alloca i32
  %l126 = alloca i1
  %l130 = alloca i1
  %l132 = alloca ptr
  %l133 = alloca %"compiler/source:Span"
  %l136 = alloca { i64, ptr }
  %l137 = alloca { i64, ptr }
  %l140 = alloca { i64, ptr }
  %l141 = alloca { i64, ptr }
  %l144 = alloca { i64, ptr }
  %l146 = alloca %"compiler/msgs:Msg"
  %l147 = alloca i64
  %l150 = alloca ptr
  %l151 = alloca i64
  %l152 = alloca i64
  %l155 = alloca { i64, ptr }
  %l157 = alloca %"compiler/msgs:Msg"
  %l168 = alloca %"compiler/generic:AnyTable"
  %l170 = alloca ptr
  %l178 = alloca i64
  %l181 = alloca i64
  %l199 = alloca { i64, ptr }
  %l204 = alloca ptr
  %l209 = alloca i32
  %l210 = alloca { i64, ptr }
  %l214 = alloca { i64, ptr }
  %l216 = alloca i64
  %l219 = alloca ptr
  %l220 = alloca i32
  %l226 = alloca i32
  %l227 = alloca i32
  %l228 = alloca ptr
  %l236 = alloca i64
  %l239 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %s0 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %rv = alloca i64
  %t439 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l33, !tbaa !29
  %t5 = load i32, ptr %l1, !tbaa !23
  store i32 %t5, ptr %l34, !tbaa !23
  %t6 = load i32, ptr %l2, !tbaa !23
  store i32 %t6, ptr %l35, !tbaa !23
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t7)
  store ptr %t9, ptr %l37
  br label %bb1
bb1:
  %t10 = load ptr, ptr %l37, !tbaa !29
  %t12 = getelementptr %"compiler/check:frame", ptr %t10, i32 0, i32 2
  %t13 = load i64, ptr %t12, !tbaa !24
  %t14 = load %"compiler/source:Span", ptr %l3
  %t15 = load ptr, ptr %l33, !tbaa !29
  %t16 = load i32, ptr %l34, !tbaa !23
  %t17 = load i32, ptr %l35, !tbaa !23
  %t20 = call { i64, i1 } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnyTableFor(ptr %v0, ptr %t15, i32 %t16, i32 %t17, i64 %t13, %"compiler/source:Span" %t14)
  store { i64, i1 } %t20, ptr %l41
  br label %bb2
bb2:
  %t21 = load { i64, i1 }, ptr %l41
  store { i64, i1 } %t21, ptr %l4
  %t22 = getelementptr { i64, i1 }, ptr %l4, i32 0, i32 0
  %t23 = load i64, ptr %t22, !tbaa !24
  store i64 %t23, ptr %l5, !tbaa !24
  %t25 = getelementptr { i64, i1 }, ptr %l4, i32 0, i32 1
  %t26 = load i1, ptr %t25, !tbaa !21
  %t30 = xor i1 %t26, true
  br i1 %t30, label %bb3, label %bb4
bb3:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/check:Checker", ptr %t32, i32 0, i32 95
  %t35 = load i64, ptr %l5, !tbaa !24
  %t38 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t34, i64 %t35)
  store i1 %t38, ptr %l49
  br label %bb5
bb4:
  br label %bb9
bb5:
  %t39 = load i1, ptr %l49, !tbaa !21
  br i1 %t39, label %bb6, label %bb7
bb6:
  store i64 -1, ptr %l50, !tbaa !24
  br label %bb8
bb7:
  %t40 = load i64, ptr %l5, !tbaa !24
  store i64 %t40, ptr %l50, !tbaa !24
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s0)
  %t42 = load i64, ptr %l50, !tbaa !24
  store i64 %t42, ptr %rv
  br label %ret
bb9:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/check:Checker", ptr %t43, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t47 = load i32, ptr %l2, !tbaa !23
  %t50 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnySlots(ptr %v0, ptr %t46, i32 %t47)
  store { i64, ptr } %t50, ptr %l55
  br label %bb10
bb10:
  %t51 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t51, ptr %l7, !tbaa !27
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/check:Checker", ptr %t52, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !29
  store ptr %t55, ptr %l57, !tbaa !29
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/check:Checker", ptr %t56, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t61 = getelementptr %"compiler/generic:Program", ptr %t59, i32 0, i32 2
  %t62 = load i32, ptr %l1, !tbaa !23
  %t65 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t61, i32 %t62)
  store i32 %t65, ptr %l62
  br label %bb11
bb11:
  %t66 = load ptr, ptr %l57, !tbaa !29
  %t67 = load i32, ptr %l62, !tbaa !23
  %t68 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnyStored(ptr %v0, ptr %t66, i32 %t67)
  store i32 %t68, ptr %l63
  br label %bb12
bb12:
  %t69 = load i32, ptr %l63, !tbaa !23
  store i32 %t69, ptr %l8, !tbaa !23
  store i64 0, ptr %l9, !tbaa !24
  %t70 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t72 = extractvalue { i64, ptr } %t70, 0
  store i64 %t72, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t74 = load i64, ptr %l10, !tbaa !24
  %t75 = load i64, ptr %l9, !tbaa !24
  %t78 = icmp sgt i64 %t74, %t75
  br i1 %t78, label %bb13, label %bb14
bb13:
  %t80 = load i64, ptr %l11, !tbaa !24
  %t82 = icmp sgt i64 %t80, 0
  br i1 %t82, label %bb15, label %bb16
bb14:
  store i64 0, ptr %l69, !tbaa !24
  br label %bb18
bb15:
  %t84 = load i64, ptr %l10, !tbaa !24
  %t85 = load i64, ptr %l9, !tbaa !24
  %t88 = sub i64 %t84, %t85
  %t89 = load i64, ptr %l11, !tbaa !24
  %t92 = add i64 %t88, %t89
  %t94 = sub i64 %t92, 1
  %t95 = load i64, ptr %l11, !tbaa !24
  %t98 = sdiv i64 %t94, %t95
  store i64 %t98, ptr %l72, !tbaa !24
  br label %bb17
bb16:
  store i64 0, ptr %l72, !tbaa !24
  br label %bb17
bb17:
  %t100 = load i64, ptr %l72, !tbaa !24
  store i64 %t100, ptr %l69, !tbaa !24
  br label %bb18
bb18:
  %t101 = load i64, ptr %l69, !tbaa !24
  store i64 %t101, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb19
bb19:
  %t102 = load i64, ptr %l13, !tbaa !24
  %t103 = load i64, ptr %l12, !tbaa !24
  %t106 = icmp slt i64 %t102, %t103
  %t108 = xor i1 %t106, true
  br i1 %t108, label %bb20, label %bb21
bb20:
  br label %bb58
bb21:
  br label %bb22
bb22:
  %t110 = load i64, ptr %l9, !tbaa !24
  %t111 = load i64, ptr %l13, !tbaa !24
  %t112 = load i64, ptr %l11, !tbaa !24
  %t115 = mul i64 %t111, %t112
  %t118 = add i64 %t110, %t115
  %t120 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t120, ptr %l90, !tbaa !27
  %t123 = getelementptr { i64, ptr }, ptr %l90, i32 0, i32 1
  %t124 = load ptr, ptr %t123, !tbaa !27
  %t125 = getelementptr %"compiler/generic:AnySlot", ptr %t124, i64 %t118
  %t126 = load %"compiler/generic:AnySlot", ptr %t125
  store %"compiler/generic:AnySlot" %t126, ptr %l15
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t130 = getelementptr %"compiler/check:Checker", ptr %t128, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !29
  %t132 = load i32, ptr %l1, !tbaa !23
  %t133 = getelementptr %"compiler/generic:AnySlot", ptr %l15, i32 0, i32 0
  %t134 = load i32, ptr %t133, !tbaa !23
  %t138 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t131, i32 %t132, i32 %t134)
  store i64 %t138, ptr %l97
  br label %bb23
bb23:
  %t139 = load i64, ptr %l97, !tbaa !24
  store i64 %t139, ptr %l16, !tbaa !24
  %t140 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t140, ptr %l17, !tbaa !23
  %t142 = load i64, ptr %l16, !tbaa !24
  %t144 = icmp sge i64 %t142, 0
  br i1 %t144, label %bb24, label %bb25
bb24:
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t148 = getelementptr %"compiler/check:Checker", ptr %t146, i32 0, i32 1
  %t149 = load ptr, ptr %t148, !tbaa !29
  %t150 = load i64, ptr %l16, !tbaa !24
  %t151 = load i32, ptr %l1, !tbaa !23
  %t155 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodSig(ptr %v0, ptr %t149, i64 %t150, i32 %t151)
  store i32 %t155, ptr %l105
  br label %bb26
bb25:
  %t156 = getelementptr %"compiler/generic:AnySlot", ptr %l15, i32 0, i32 3
  %t157 = load i64, ptr %t156, !tbaa !24
  %t159 = icmp sge i64 %t157, 0
  br i1 %t159, label %bb33, label %bb34
bb26:
  %t161 = load i32, ptr %l105, !tbaa !23
  store i32 %t161, ptr %l17, !tbaa !23
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t164 = getelementptr %"compiler/check:Checker", ptr %t162, i32 0, i32 1
  %t165 = load ptr, ptr %t164, !tbaa !29
  store ptr %t165, ptr %l107, !tbaa !29
  %t166 = load i64, ptr %l16, !tbaa !24
  %t168 = call i64 @compiler_2fgeneric_2eFnOwner(i64 %t166)
  store i64 %t168, ptr %l109
  br label %bb27
bb27:
  %t169 = load ptr, ptr %l107, !tbaa !29
  %t170 = load i64, ptr %l109, !tbaa !24
  %t171 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %t169, i64 %t170)
  store i64 %t171, ptr %l110
  br label %bb28
bb28:
  %t172 = load i64, ptr %l110, !tbaa !24
  %t173 = icmp sgt i64 %t172, 0
  br i1 %t173, label %bb29, label %bb30
bb29:
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t176 = load i64, ptr %l16, !tbaa !24
  %t177 = load i32, ptr %l1, !tbaa !23
  %t181 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eimplSig(ptr %v0, ptr %t175, i64 %t176, i32 %t177)
  store i32 %t181, ptr %l115
  br label %bb31
bb30:
  br label %bb32
bb31:
  %t182 = load i32, ptr %l115, !tbaa !23
  store i32 %t182, ptr %l17, !tbaa !23
  br label %bb32
bb32:
  br label %bb37
bb33:
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t185 = getelementptr %"compiler/check:Checker", ptr %t183, i32 0, i32 1
  %t186 = load ptr, ptr %t185, !tbaa !29
  %t187 = getelementptr %"compiler/generic:AnySlot", ptr %l15, i32 0, i32 3
  %t188 = load i64, ptr %t187, !tbaa !24
  %t189 = load i32, ptr %l1, !tbaa !23
  %t193 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDefaultAt(ptr %v0, ptr %t186, i64 %t188, i32 %t189)
  store i32 %t193, ptr %l122
  br label %bb35
bb34:
  br label %bb36
bb35:
  %t194 = load i32, ptr %l122, !tbaa !23
  store i32 %t194, ptr %l17, !tbaa !23
  br label %bb36
bb36:
  br label %bb37
bb37:
  %t195 = load i32, ptr %l17, !tbaa !23
  %t196 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t199 = icmp ne i32 %t195, %t196
  br i1 %t199, label %bb38, label %bb39
bb38:
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t202 = load i32, ptr %l17, !tbaa !23
  %t203 = getelementptr %"compiler/generic:AnySlot", ptr %l15, i32 0, i32 5
  %t204 = load i32, ptr %t203, !tbaa !23
  %t208 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyScopesAgree(ptr %v0, ptr %t201, i32 %t202, i32 %t204)
  store i1 %t208, ptr %l130
  br label %bb40
bb39:
  store i1 false, ptr %l126, !tbaa !21
  br label %bb41
bb40:
  %t209 = load i1, ptr %l130, !tbaa !21
  %t210 = xor i1 %t209, true
  store i1 %t210, ptr %l126, !tbaa !21
  br label %bb41
bb41:
  %t212 = load i1, ptr %l126, !tbaa !21
  br i1 %t212, label %bb42, label %bb43
bb42:
  store %olang.scope zeroinitializer, ptr %s8
  %t213 = load ptr, ptr %l0, !tbaa !29
  store ptr %t213, ptr %l132, !tbaa !29
  %t214 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t214, ptr %l133
  %t215 = load ptr, ptr %l0, !tbaa !29
  %t216 = load i32, ptr %l1, !tbaa !23
  %t219 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s8, ptr %t215, i32 %t216)
  store { i64, ptr } %t219, ptr %l136
  br label %bb44
bb43:
  br label %bb56
bb44:
  %t220 = load { i64, ptr }, ptr %l136, !tbaa !27
  %t221 = extractvalue { i64, ptr } %t220, 0
  %t222 = extractvalue { i64, ptr } %t220, 1
  %t223 = mul i64 %t221, 1
  %t224 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t223)
  call void @llvm.memcpy.p0.p0.i64(ptr %t224, ptr %t222, i64 %t223, i1 false)
  %t225 = insertvalue { i64, ptr } undef, i64 %t221, 0
  %t226 = insertvalue { i64, ptr } %t225, ptr %t224, 1
  store { i64, ptr } %t226, ptr %l137, !tbaa !27
  %t227 = load ptr, ptr %l0, !tbaa !29
  %t228 = getelementptr %"compiler/generic:AnySlot", ptr %l15, i32 0, i32 0
  %t229 = load i32, ptr %t228, !tbaa !23
  %t232 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s8, ptr %t227, i32 %t229)
  store { i64, ptr } %t232, ptr %l140
  br label %bb45
bb45:
  %t233 = load { i64, ptr }, ptr %l140, !tbaa !27
  %t234 = extractvalue { i64, ptr } %t233, 0
  %t235 = extractvalue { i64, ptr } %t233, 1
  %t236 = mul i64 %t234, 1
  %t237 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t236)
  call void @llvm.memcpy.p0.p0.i64(ptr %t237, ptr %t235, i64 %t236, i1 false)
  %t238 = insertvalue { i64, ptr } undef, i64 %t234, 0
  %t239 = insertvalue { i64, ptr } %t238, ptr %t237, 1
  store { i64, ptr } %t239, ptr %l141, !tbaa !27
  %t240 = load ptr, ptr %l0, !tbaa !29
  %t241 = load i32, ptr %l2, !tbaa !23
  %t244 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s8, ptr %t240, i32 %t241)
  store { i64, ptr } %t244, ptr %l144
  br label %bb46
bb46:
  %t245 = load { i64, ptr }, ptr %l144, !tbaa !27
  %t246 = extractvalue { i64, ptr } %t245, 0
  %t247 = extractvalue { i64, ptr } %t245, 1
  %t248 = mul i64 %t246, 1
  %t249 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t248)
  call void @llvm.memcpy.p0.p0.i64(ptr %t249, ptr %t247, i64 %t248, i1 false)
  %t250 = insertvalue { i64, ptr } undef, i64 %t246, 0
  %t251 = insertvalue { i64, ptr } %t250, ptr %t249, 1
  %t252 = load { i64, ptr }, ptr %l137, !tbaa !27
  %t253 = load { i64, ptr }, ptr %l141, !tbaa !27
  %t255 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eAnyMethodScopes(ptr %s8, ptr %s8, ptr %s8, ptr %s8, { i64, ptr } %t252, { i64, ptr } %t253, { i64, ptr } %t251)
  store %"compiler/msgs:Msg" %t255, ptr %l146
  br label %bb47
bb47:
  %t256 = load ptr, ptr %l132, !tbaa !29
  %t257 = load %"compiler/source:Span", ptr %l133
  %t258 = load %"compiler/msgs:Msg", ptr %l146
  %t259 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s8, ptr %t256, %"compiler/source:Span" %t257, %"compiler/msgs:Msg" %t258)
  store i64 %t259, ptr %l147
  br label %bb48
bb48:
  %t260 = load i64, ptr %l147, !tbaa !24
  store i64 %t260, ptr %l18, !tbaa !24
  %t261 = load i64, ptr %l16, !tbaa !24
  %t263 = icmp sge i64 %t261, 0
  br i1 %t263, label %bb49, label %bb50
bb49:
  store %olang.scope zeroinitializer, ptr %s9
  %t265 = load ptr, ptr %l0, !tbaa !29
  store ptr %t265, ptr %l150, !tbaa !29
  %t266 = load i64, ptr %l18, !tbaa !24
  store i64 %t266, ptr %l151, !tbaa !24
  %t267 = load i64, ptr %l16, !tbaa !24
  store i64 %t267, ptr %l152, !tbaa !24
  %t268 = load ptr, ptr %l0, !tbaa !29
  %t269 = getelementptr %"compiler/generic:AnySlot", ptr %l15, i32 0, i32 0
  %t270 = load i32, ptr %t269, !tbaa !23
  %t273 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s9, ptr %t268, i32 %t270)
  store { i64, ptr } %t273, ptr %l155
  br label %bb51
bb50:
  br label %bb54
bb51:
  %t274 = load { i64, ptr }, ptr %l155, !tbaa !27
  %t275 = extractvalue { i64, ptr } %t274, 0
  %t276 = extractvalue { i64, ptr } %t274, 1
  %t277 = mul i64 %t275, 1
  %t278 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t277)
  call void @llvm.memcpy.p0.p0.i64(ptr %t278, ptr %t276, i64 %t277, i1 false)
  %t279 = insertvalue { i64, ptr } undef, i64 %t275, 0
  %t280 = insertvalue { i64, ptr } %t279, ptr %t278, 1
  %t282 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteAnyMethod(ptr %s9, ptr %s9, { i64, ptr } %t280)
  store %"compiler/msgs:Msg" %t282, ptr %l157
  br label %bb52
bb52:
  %t283 = load ptr, ptr %l150, !tbaa !29
  %t284 = load i64, ptr %l151, !tbaa !24
  %t285 = load i64, ptr %l152, !tbaa !24
  %t286 = load %"compiler/msgs:Msg", ptr %l157
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoteAt(ptr %v0, ptr %s9, ptr %t283, i64 %t284, i64 %t285, %"compiler/msgs:Msg" %t286)
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s9)
  br label %bb54
bb54:
  %t287 = load ptr, ptr %l0, !tbaa !29
  %t289 = getelementptr %"compiler/check:Checker", ptr %t287, i32 0, i32 95
  %t290 = load i64, ptr %l5, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t289, i64 %t290, i1 true)
  br label %bb55
bb55:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb56:
  br label %bb57
bb57:
  %t294 = load i64, ptr %l13, !tbaa !24
  %t296 = add i64 %t294, 1
  store i64 %t296, ptr %l13, !tbaa !24
  br label %bb19
bb58:
  %t298 = load ptr, ptr %l0, !tbaa !29
  %t300 = getelementptr %"compiler/check:Checker", ptr %t298, i32 0, i32 1
  %t301 = load ptr, ptr %t300, !tbaa !29
  %t303 = getelementptr %"compiler/generic:Program", ptr %t301, i32 0, i32 42
  %t304 = load i64, ptr %l5, !tbaa !24
  %t307 = call %"compiler/generic:AnyTable" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aAnyTable_3e_2eAt__He9601a52fe5cfa5abe1b41d520aed001(ptr %v0, ptr %v0, ptr %t303, i64 %t304)
  store %"compiler/generic:AnyTable" %t307, ptr %l168
  br label %bb59
bb59:
  %t308 = load %"compiler/generic:AnyTable", ptr %l168
  store %"compiler/generic:AnyTable" %t308, ptr %l19
  %t309 = load ptr, ptr %l0, !tbaa !29
  %t311 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t309)
  store ptr %t311, ptr %l170
  br label %bb60
bb60:
  %t312 = load ptr, ptr %l170, !tbaa !29
  %t314 = getelementptr %"compiler/check:frame", ptr %t312, i32 0, i32 1
  %t315 = load i64, ptr %t314, !tbaa !24
  store i64 %t315, ptr %l20, !tbaa !24
  store i64 0, ptr %l21, !tbaa !24
  %t317 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t319 = extractvalue { i64, ptr } %t317, 0
  store i64 %t319, ptr %l22, !tbaa !24
  store i64 1, ptr %l23, !tbaa !24
  %t321 = load i64, ptr %l22, !tbaa !24
  %t322 = load i64, ptr %l21, !tbaa !24
  %t325 = icmp sgt i64 %t321, %t322
  br i1 %t325, label %bb61, label %bb62
bb61:
  %t327 = load i64, ptr %l23, !tbaa !24
  %t329 = icmp sgt i64 %t327, 0
  br i1 %t329, label %bb63, label %bb64
bb62:
  store i64 0, ptr %l178, !tbaa !24
  br label %bb66
bb63:
  %t331 = load i64, ptr %l22, !tbaa !24
  %t332 = load i64, ptr %l21, !tbaa !24
  %t335 = sub i64 %t331, %t332
  %t336 = load i64, ptr %l23, !tbaa !24
  %t339 = add i64 %t335, %t336
  %t341 = sub i64 %t339, 1
  %t342 = load i64, ptr %l23, !tbaa !24
  %t345 = sdiv i64 %t341, %t342
  store i64 %t345, ptr %l181, !tbaa !24
  br label %bb65
bb64:
  store i64 0, ptr %l181, !tbaa !24
  br label %bb65
bb65:
  %t347 = load i64, ptr %l181, !tbaa !24
  store i64 %t347, ptr %l178, !tbaa !24
  br label %bb66
bb66:
  %t348 = load i64, ptr %l178, !tbaa !24
  store i64 %t348, ptr %l24, !tbaa !24
  store i64 0, ptr %l25, !tbaa !24
  br label %bb67
bb67:
  %t349 = load i64, ptr %l25, !tbaa !24
  %t350 = load i64, ptr %l24, !tbaa !24
  %t353 = icmp slt i64 %t349, %t350
  %t355 = xor i1 %t353, true
  br i1 %t355, label %bb68, label %bb69
bb68:
  br label %bb79
bb69:
  br label %bb70
bb70:
  %t357 = load i64, ptr %l21, !tbaa !24
  %t358 = load i64, ptr %l25, !tbaa !24
  %t359 = load i64, ptr %l23, !tbaa !24
  %t362 = mul i64 %t358, %t359
  %t365 = add i64 %t357, %t362
  store i64 %t365, ptr %l26, !tbaa !24
  %t367 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t367, ptr %l199, !tbaa !27
  %t368 = load i64, ptr %l26, !tbaa !24
  %t370 = getelementptr { i64, ptr }, ptr %l199, i32 0, i32 1
  %t371 = load ptr, ptr %t370, !tbaa !27
  %t372 = getelementptr %"compiler/generic:AnySlot", ptr %t371, i64 %t368
  %t373 = load %"compiler/generic:AnySlot", ptr %t372
  store %"compiler/generic:AnySlot" %t373, ptr %l27
  %t375 = load ptr, ptr %l0, !tbaa !29
  %t377 = getelementptr %"compiler/check:Checker", ptr %t375, i32 0, i32 1
  %t378 = load ptr, ptr %t377, !tbaa !29
  %t380 = getelementptr %"compiler/generic:Program", ptr %t378, i32 0, i32 2
  store ptr %t380, ptr %l204, !tbaa !29
  %t381 = load ptr, ptr %l0, !tbaa !29
  %t383 = getelementptr %"compiler/check:Checker", ptr %t381, i32 0, i32 1
  %t384 = load ptr, ptr %t383, !tbaa !29
  %t386 = getelementptr %"compiler/generic:Program", ptr %t384, i32 0, i32 2
  %t387 = getelementptr %"compiler/generic:AnySlot", ptr %l27, i32 0, i32 5
  %t388 = load i32, ptr %t387, !tbaa !23
  %t391 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t386, i32 %t388)
  store i32 %t391, ptr %l209
  br label %bb71
bb71:
  %t392 = load ptr, ptr %l204, !tbaa !29
  %t393 = load i32, ptr %l209, !tbaa !23
  %t394 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t392, i32 %t393)
  store { i64, ptr } %t394, ptr %l210
  br label %bb72
bb72:
  %t395 = load { i64, ptr }, ptr %l210, !tbaa !27
  %t396 = load ptr, ptr %l0, !tbaa !29
  %t398 = getelementptr %"compiler/check:Checker", ptr %t396, i32 0, i32 1
  %t399 = load ptr, ptr %t398, !tbaa !29
  %t401 = getelementptr %"compiler/generic:Program", ptr %t399, i32 0, i32 2
  store { i64, ptr } %t395, ptr %l214, !tbaa !27
  %t403 = getelementptr { i64, ptr }, ptr %l214, i32 0, i32 1
  %t404 = load ptr, ptr %t403, !tbaa !27
  %t405 = getelementptr i32, ptr %t404, i64 0
  %t406 = load i32, ptr %t405, !tbaa !33
  %t409 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t401, i32 %t406)
  store i64 %t409, ptr %l216
  br label %bb73
bb73:
  %t410 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t411 = load i64, ptr %l216, !tbaa !24
  %t413 = and i64 %t411, %t410
  %t415 = load ptr, ptr %l0, !tbaa !29
  store ptr %t415, ptr %l219, !tbaa !29
  %t416 = getelementptr %"compiler/generic:AnySlot", ptr %l27, i32 0, i32 5
  %t417 = load i32, ptr %t416, !tbaa !23
  store i32 %t417, ptr %l220, !tbaa !23
  %t418 = load ptr, ptr %l0, !tbaa !29
  %t420 = getelementptr %"compiler/check:Checker", ptr %t418, i32 0, i32 1
  %t421 = load ptr, ptr %t420, !tbaa !29
  %t423 = getelementptr %"compiler/generic:Program", ptr %t421, i32 0, i32 2
  %t424 = load i32, ptr %l8, !tbaa !23
  %t429 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t423, i32 %t424, i64 %t413)
  store i32 %t429, ptr %l226
  br label %bb74
bb74:
  %t430 = load ptr, ptr %l219, !tbaa !29
  %t431 = load i32, ptr %l220, !tbaa !23
  %t432 = load i32, ptr %l226, !tbaa !23
  %t433 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erecvReplaced(ptr %v0, ptr %t430, i32 %t431, i32 %t432)
  store i32 %t433, ptr %l227
  br label %bb75
bb75:
  %t434 = load i32, ptr %l227, !tbaa !23
  %t435 = getelementptr %"compiler/generic:AnyTable", ptr %l19, i32 0, i32 5
  store ptr %t435, ptr %l228, !tbaa !29
  %t436 = load ptr, ptr %l0, !tbaa !29
  %t437 = load i64, ptr %l5, !tbaa !24
  %t438 = load i64, ptr %l26, !tbaa !24
  store { i64, [2 x i64] } zeroinitializer, ptr %t439
  %t440 = getelementptr { i64, [2 x i64] }, ptr %t439, i32 0, i32 0
  store i64 9, ptr %t440
  %t442 = insertvalue { i64, i64 } undef, i64 %t437, 0
  %t444 = insertvalue { i64, i64 } %t442, i64 %t438, 1
  %t445 = getelementptr { i64, [2 x i64] }, ptr %t439, i32 0, i32 1
  store { i64, i64 } %t444, ptr %t445
  %t446 = load { i64, [2 x i64] }, ptr %t439
  %t448 = load i64, ptr %l20, !tbaa !24
  %t449 = load %"compiler/source:Span", ptr %l3
  %t455 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enewBody(ptr %v0, ptr %t436, { i64, [2 x i64] } %t446, i32 %t434, i64 %t448, %"compiler/source:Span" %t449)
  store i64 %t455, ptr %l236
  br label %bb76
bb76:
  %t456 = load ptr, ptr %l228, !tbaa !29
  %t457 = load i64, ptr %l236, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t456, i64 %t457)
  br label %bb77
bb77:
  br label %bb78
bb78:
  %t458 = load i64, ptr %l25, !tbaa !24
  %t460 = add i64 %t458, 1
  store i64 %t460, ptr %l25, !tbaa !24
  br label %bb67
bb79:
  %t462 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_2ector(ptr %s0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t462, ptr %l239
  br label %bb80
bb80:
  %t463 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l239
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t463, ptr %l31
  %t464 = load ptr, ptr %l0, !tbaa !29
  %t465 = load i32, ptr %l1, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewantStr(ptr %v0, ptr %s0, ptr %t464, i32 %t465, ptr %l31, i64 0)
  br label %bb81
bb81:
  %t469 = load i64, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t469, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aFn(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i1
  %l6 = alloca i1
  %l7 = alloca i64
  %l10 = alloca i64
  %l12 = alloca i1
  %l16 = alloca i1
  %l23 = alloca ptr
  %l24 = alloca ptr
  %l28 = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb4
bb2:
  %t5 = load i64, ptr %l2, !tbaa !24
  store i64 %t5, ptr %l7, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 11
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l10
  br label %bb3
bb3:
  %t11 = load i64, ptr %l7, !tbaa !24
  %t12 = load i64, ptr %l10, !tbaa !24
  %t13 = icmp sge i64 %t11, %t12
  store i1 %t13, ptr %l6, !tbaa !21
  br label %bb4
bb4:
  %t15 = load i1, ptr %l6, !tbaa !21
  br i1 %t15, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb8
bb6:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr %"compiler/check:b5aWalk", ptr %t16, i32 0, i32 1
  %t19 = load i64, ptr %l2, !tbaa !24
  %t22 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v1, ptr %t18, i64 %t19)
  store i1 %t22, ptr %l16
  br label %bb7
bb7:
  %t23 = load i1, ptr %l16, !tbaa !21
  store i1 %t23, ptr %l12, !tbaa !21
  br label %bb8
bb8:
  %t24 = load i1, ptr %l12, !tbaa !21
  br i1 %t24, label %bb9, label %bb10
bb9:
  br label %ret
bb10:
  br label %bb11
bb11:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr %"compiler/check:b5aWalk", ptr %t25, i32 0, i32 1
  %t28 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v1, ptr %t27, i64 %t28, i1 true)
  br label %bb12
bb12:
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr %"compiler/check:b5aWalk", ptr %t31, i32 0, i32 6
  %t34 = load i1, ptr %t33, !tbaa !21
  store i1 %t34, ptr %l3, !tbaa !21
  %t36 = load ptr, ptr %l1, !tbaa !29
  %t38 = getelementptr %"compiler/check:b5aWalk", ptr %t36, i32 0, i32 6
  store i1 false, ptr %t38, !tbaa !21
  %t39 = load ptr, ptr %l0, !tbaa !29
  store ptr %t39, ptr %l23, !tbaa !29
  %t40 = load ptr, ptr %l1, !tbaa !29
  store ptr %t40, ptr %l24, !tbaa !29
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/check:Checker", ptr %t41, i32 0, i32 11
  %t44 = load i64, ptr %l2, !tbaa !24
  %t47 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t43, i64 %t44)
  store ptr %t47, ptr %l28
  br label %bb13
bb13:
  %t48 = load ptr, ptr %l28, !tbaa !29
  %t50 = getelementptr %"compiler/typed:Body", ptr %t48, i32 0, i32 11
  %t51 = load ptr, ptr %t50, !tbaa !29
  %t52 = load ptr, ptr %l23, !tbaa !29
  %t53 = load ptr, ptr %l24, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aBlock(ptr %v0, ptr %v1, ptr %v0, ptr %t52, ptr %t53, ptr %t51)
  br label %bb14
bb14:
  %t55 = load ptr, ptr %l1, !tbaa !29
  %t56 = load i1, ptr %l3, !tbaa !21
  %t59 = getelementptr %"compiler/check:b5aWalk", ptr %t55, i32 0, i32 6
  store i1 %t56, ptr %t59, !tbaa !21
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aStr(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l24 = alloca i1
  %l28 = alloca i1
  %l31 = alloca i1
  %l35 = alloca i1
  %l43 = alloca i32
  %l46 = alloca ptr
  %l47 = alloca ptr
  %l52 = alloca i32
  %l69 = alloca ptr
  %l70 = alloca i32
  %l75 = alloca i32
  %l76 = alloca i64
  %l79 = alloca ptr
  %l80 = alloca ptr
  %l84 = alloca i64
  %l90 = alloca i1
  %l94 = alloca ptr
  %l99 = alloca i32
  %l100 = alloca { i64, ptr }
  %l107 = alloca { i64, ptr }
  %l119 = alloca ptr
  %l124 = alloca i32
  %l125 = alloca { i64, ptr }
  %l132 = alloca { i64, ptr }
  %l144 = alloca ptr
  %l145 = alloca ptr
  %l150 = alloca i32
  %l159 = alloca ptr
  %l164 = alloca i32
  %l165 = alloca { i64, ptr }
  %l172 = alloca { i64, ptr }
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l3, !tbaa !24
  %t3 = icmp sgt i64 %t1, 16
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l24, !tbaa !21
  br label %bb3
bb2:
  %t5 = load i32, ptr %l2, !tbaa !23
  %t6 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t9 = icmp eq i32 %t5, %t6
  store i1 %t9, ptr %l24, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l24, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l28, !tbaa !21
  br label %bb6
bb5:
  %t12 = load i32, ptr %l2, !tbaa !23
  %t14 = icmp eq i32 %t12, 0
  store i1 %t14, ptr %l28, !tbaa !21
  br label %bb6
bb6:
  %t16 = load i1, ptr %l28, !tbaa !21
  br i1 %t16, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l31, !tbaa !21
  br label %bb10
bb8:
  %t17 = load ptr, ptr %l1, !tbaa !29
  %t19 = getelementptr %"compiler/check:b5aWalk", ptr %t17, i32 0, i32 5
  %t20 = load i32, ptr %l2, !tbaa !23
  %t23 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_Hb3133f486435530b533aaf49461c92b5(ptr %v1, ptr %t19, i32 %t20)
  store i1 %t23, ptr %l35
  br label %bb9
bb9:
  %t24 = load i1, ptr %l35, !tbaa !21
  store i1 %t24, ptr %l31, !tbaa !21
  br label %bb10
bb10:
  %t25 = load i1, ptr %l31, !tbaa !21
  br i1 %t25, label %bb11, label %bb12
bb11:
  br label %ret
bb12:
  br label %bb13
bb13:
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t28 = getelementptr %"compiler/check:b5aWalk", ptr %t26, i32 0, i32 5
  %t29 = load i32, ptr %l2, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_H64d9be73b6c9bed004c541bdf7f0ca0a(ptr %v1, ptr %t28, i32 %t29, i1 true)
  br label %bb14
bb14:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/check:Checker", ptr %t32, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t37 = getelementptr %"compiler/generic:Program", ptr %t35, i32 0, i32 2
  %t38 = load i32, ptr %l2, !tbaa !23
  %t41 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t37, i32 %t38)
  store i32 %t41, ptr %l43
  br label %bb15
bb15:
  %t42 = load i32, ptr %l43
  store i32 %t42, ptr %l4
  %t43 = load i32, ptr %l4
  %t45 = trunc i64 20 to i32
  %t46 = icmp eq i32 %t43, %t45
  br i1 %t46, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb21
bb18:
  %t48 = load ptr, ptr %l0, !tbaa !29
  store ptr %t48, ptr %l46, !tbaa !29
  %t49 = load ptr, ptr %l1, !tbaa !29
  store ptr %t49, ptr %l47, !tbaa !29
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/check:Checker", ptr %t50, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t55 = getelementptr %"compiler/generic:Program", ptr %t53, i32 0, i32 2
  %t56 = load i32, ptr %l2, !tbaa !23
  %t59 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t55, i32 %t56)
  store i32 %t59, ptr %l52
  br label %bb19
bb19:
  %t60 = load i64, ptr %l3, !tbaa !24
  %t62 = add i64 %t60, 1
  %t63 = load ptr, ptr %l46, !tbaa !29
  %t64 = load ptr, ptr %l47, !tbaa !29
  %t65 = load i32, ptr %l52, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aStr(ptr %v0, ptr %v1, ptr %t63, ptr %t64, i32 %t65, i64 %t62)
  br label %bb20
bb20:
  br label %bb82
bb21:
  %t67 = load i32, ptr %l4
  %t69 = trunc i64 18 to i32
  %t70 = icmp eq i32 %t67, %t69
  br i1 %t70, label %bb22, label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb60
bb24:
  store %olang.scope zeroinitializer, ptr %s4
  %t72 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d22, i32 0, i32 1) }, 0
  %t73 = insertvalue [2 x { i64, ptr }] %t72, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d23, i32 0, i32 1) }, 1
  %t75 = call ptr @__olang_scope_alloc_a(ptr %s4, i64 32, i64 8)
  store [2 x { i64, ptr }] %t73, ptr %t75
  store ptr %t75, ptr %l5
  store i64 0, ptr %l6, !tbaa !24
  %t77 = load ptr, ptr %l5
  store i64 2, ptr %l7, !tbaa !24
  br label %bb25
bb25:
  %t80 = load i64, ptr %l6, !tbaa !24
  %t81 = load i64, ptr %l7, !tbaa !24
  %t84 = icmp slt i64 %t80, %t81
  %t86 = xor i1 %t84, true
  br i1 %t86, label %bb26, label %bb27
bb26:
  br label %bb37
bb27:
  br label %bb28
bb28:
  %t88 = load ptr, ptr %l5
  %t89 = load i64, ptr %l6, !tbaa !24
  %t92 = getelementptr [2 x { i64, ptr }], ptr %t88, i64 0, i64 %t89
  %t93 = load { i64, ptr }, ptr %t92, !tbaa !37
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr %"compiler/check:Checker", ptr %t95, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !29
  store ptr %t98, ptr %l69, !tbaa !29
  %t99 = load i32, ptr %l2, !tbaa !23
  store i32 %t99, ptr %l70, !tbaa !23
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t102 = getelementptr %"compiler/check:Checker", ptr %t100, i32 0, i32 1
  %t103 = load ptr, ptr %t102, !tbaa !29
  %t105 = getelementptr %"compiler/generic:Program", ptr %t103, i32 0, i32 2
  %t106 = getelementptr %"compiler/types:Table", ptr %t105, i32 0, i32 0
  %t107 = load ptr, ptr %t106, !tbaa !29
  %t109 = load ptr, ptr @__olang_prog_scope
  %t112 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %t109, ptr %t107, { i64, ptr } %t93)
  store i32 %t112, ptr %l75
  br label %bb29
bb29:
  %t113 = load ptr, ptr %l69, !tbaa !29
  %t114 = load i32, ptr %l70, !tbaa !23
  %t115 = load i32, ptr %l75, !tbaa !23
  %t116 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t113, i32 %t114, i32 %t115)
  store i64 %t116, ptr %l76
  br label %bb30
bb30:
  %t117 = load i64, ptr %l76, !tbaa !24
  store i64 %t117, ptr %l9, !tbaa !24
  %t118 = load i64, ptr %l9, !tbaa !24
  %t120 = icmp sge i64 %t118, 0
  br i1 %t120, label %bb31, label %bb32
bb31:
  %t122 = load ptr, ptr %l0, !tbaa !29
  store ptr %t122, ptr %l79, !tbaa !29
  %t123 = load ptr, ptr %l1, !tbaa !29
  store ptr %t123, ptr %l80, !tbaa !29
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t125 = load i64, ptr %l9, !tbaa !24
  %t126 = load i32, ptr %l2, !tbaa !23
  %t130 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aStrBody(ptr %v0, ptr %t124, i64 %t125, i32 %t126)
  store i64 %t130, ptr %l84
  br label %bb33
bb32:
  br label %bb35
bb33:
  %t131 = load ptr, ptr %l79, !tbaa !29
  %t132 = load ptr, ptr %l80, !tbaa !29
  %t133 = load i64, ptr %l84, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aFn(ptr %v0, ptr %v1, ptr %t131, ptr %t132, i64 %t133)
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s4)
  br label %ret
bb35:
  br label %bb36
bb36:
  %t134 = load i64, ptr %l6, !tbaa !24
  %t136 = add i64 %t134, 1
  store i64 %t136, ptr %l6, !tbaa !24
  br label %bb25
bb37:
  call void @__olang_scope_close(ptr %s4)
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t140 = getelementptr %"compiler/check:Checker", ptr %t138, i32 0, i32 1
  %t141 = load ptr, ptr %t140, !tbaa !29
  %t142 = load i32, ptr %l2, !tbaa !23
  %t145 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t141, i32 %t142)
  store i1 %t145, ptr %l90
  br label %bb38
bb38:
  %t146 = load i1, ptr %l90, !tbaa !21
  %t147 = xor i1 %t146, true
  br i1 %t147, label %bb39, label %bb40
bb39:
  br label %ret
bb40:
  br label %bb41
bb41:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t151 = getelementptr %"compiler/check:Checker", ptr %t149, i32 0, i32 1
  %t152 = load ptr, ptr %t151, !tbaa !29
  %t154 = getelementptr %"compiler/generic:Program", ptr %t152, i32 0, i32 2
  store ptr %t154, ptr %l94, !tbaa !29
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t157 = getelementptr %"compiler/check:Checker", ptr %t155, i32 0, i32 1
  %t158 = load ptr, ptr %t157, !tbaa !29
  %t160 = getelementptr %"compiler/generic:Program", ptr %t158, i32 0, i32 2
  %t161 = load i32, ptr %l2, !tbaa !23
  %t164 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t160, i32 %t161)
  store i32 %t164, ptr %l99
  br label %bb42
bb42:
  %t165 = load ptr, ptr %l94, !tbaa !29
  %t166 = load i32, ptr %l99, !tbaa !23
  %t167 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t165, i32 %t166)
  store { i64, ptr } %t167, ptr %l100
  br label %bb43
bb43:
  %t168 = load { i64, ptr }, ptr %l100, !tbaa !27
  store { i64, ptr } %t168, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t169 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t171 = extractvalue { i64, ptr } %t169, 0
  store i64 %t171, ptr %l12, !tbaa !24
  br label %bb44
bb44:
  %t173 = load i64, ptr %l11, !tbaa !24
  %t174 = load i64, ptr %l12, !tbaa !24
  %t177 = icmp slt i64 %t173, %t174
  %t179 = xor i1 %t177, true
  br i1 %t179, label %bb45, label %bb46
bb45:
  br label %bb50
bb46:
  br label %bb47
bb47:
  %t181 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t181, ptr %l107, !tbaa !27
  %t182 = load i64, ptr %l11, !tbaa !24
  %t184 = getelementptr { i64, ptr }, ptr %l107, i32 0, i32 1
  %t185 = load ptr, ptr %t184, !tbaa !27
  %t186 = getelementptr i32, ptr %t185, i64 %t182
  %t187 = load i32, ptr %t186, !tbaa !33
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t190 = load ptr, ptr %l1, !tbaa !29
  %t192 = load i64, ptr %l3, !tbaa !24
  %t194 = add i64 %t192, 1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aStr(ptr %v0, ptr %v1, ptr %t189, ptr %t190, i32 %t187, i64 %t194)
  br label %bb48
bb48:
  br label %bb49
bb49:
  %t199 = load i64, ptr %l11, !tbaa !24
  %t201 = add i64 %t199, 1
  store i64 %t201, ptr %l11, !tbaa !24
  br label %bb44
bb50:
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t205 = getelementptr %"compiler/check:Checker", ptr %t203, i32 0, i32 1
  %t206 = load ptr, ptr %t205, !tbaa !29
  %t208 = getelementptr %"compiler/generic:Program", ptr %t206, i32 0, i32 2
  store ptr %t208, ptr %l119, !tbaa !29
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t211 = getelementptr %"compiler/check:Checker", ptr %t209, i32 0, i32 1
  %t212 = load ptr, ptr %t211, !tbaa !29
  %t214 = getelementptr %"compiler/generic:Program", ptr %t212, i32 0, i32 2
  %t215 = load i32, ptr %l2, !tbaa !23
  %t218 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t214, i32 %t215)
  store i32 %t218, ptr %l124
  br label %bb51
bb51:
  %t219 = load ptr, ptr %l119, !tbaa !29
  %t220 = load i32, ptr %l124, !tbaa !23
  %t221 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t219, i32 %t220)
  store { i64, ptr } %t221, ptr %l125
  br label %bb52
bb52:
  %t222 = load { i64, ptr }, ptr %l125, !tbaa !27
  store { i64, ptr } %t222, ptr %l14, !tbaa !27
  store i64 0, ptr %l15, !tbaa !24
  %t223 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t225 = extractvalue { i64, ptr } %t223, 0
  store i64 %t225, ptr %l16, !tbaa !24
  br label %bb53
bb53:
  %t227 = load i64, ptr %l15, !tbaa !24
  %t228 = load i64, ptr %l16, !tbaa !24
  %t231 = icmp slt i64 %t227, %t228
  %t233 = xor i1 %t231, true
  br i1 %t233, label %bb54, label %bb55
bb54:
  br label %bb59
bb55:
  br label %bb56
bb56:
  %t235 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t235, ptr %l132, !tbaa !27
  %t236 = load i64, ptr %l15, !tbaa !24
  %t238 = getelementptr { i64, ptr }, ptr %l132, i32 0, i32 1
  %t239 = load ptr, ptr %t238, !tbaa !27
  %t240 = getelementptr i32, ptr %t239, i64 %t236
  %t241 = load i32, ptr %t240, !tbaa !33
  %t243 = load ptr, ptr %l0, !tbaa !29
  %t244 = load ptr, ptr %l1, !tbaa !29
  %t246 = load i64, ptr %l3, !tbaa !24
  %t248 = add i64 %t246, 1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aStr(ptr %v0, ptr %v1, ptr %t243, ptr %t244, i32 %t241, i64 %t248)
  br label %bb57
bb57:
  br label %bb58
bb58:
  %t253 = load i64, ptr %l15, !tbaa !24
  %t255 = add i64 %t253, 1
  store i64 %t255, ptr %l15, !tbaa !24
  br label %bb53
bb59:
  br label %bb82
bb60:
  %t257 = load i32, ptr %l4
  %t259 = trunc i64 19 to i32
  %t260 = icmp eq i32 %t257, %t259
  br i1 %t260, label %bb61, label %bb62
bb61:
  br label %bb63
bb62:
  br label %bb66
bb63:
  %t262 = load ptr, ptr %l0, !tbaa !29
  store ptr %t262, ptr %l144, !tbaa !29
  %t263 = load ptr, ptr %l1, !tbaa !29
  store ptr %t263, ptr %l145, !tbaa !29
  %t264 = load ptr, ptr %l0, !tbaa !29
  %t266 = getelementptr %"compiler/check:Checker", ptr %t264, i32 0, i32 1
  %t267 = load ptr, ptr %t266, !tbaa !29
  %t269 = getelementptr %"compiler/generic:Program", ptr %t267, i32 0, i32 2
  %t270 = load i32, ptr %l2, !tbaa !23
  %t273 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t269, i32 %t270)
  store i32 %t273, ptr %l150
  br label %bb64
bb64:
  %t274 = load i64, ptr %l3, !tbaa !24
  %t276 = add i64 %t274, 1
  %t277 = load ptr, ptr %l144, !tbaa !29
  %t278 = load ptr, ptr %l145, !tbaa !29
  %t279 = load i32, ptr %l150, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aStr(ptr %v0, ptr %v1, ptr %t277, ptr %t278, i32 %t279, i64 %t276)
  br label %bb65
bb65:
  br label %bb82
bb66:
  %t281 = load i32, ptr %l4
  %t283 = trunc i64 22 to i32
  %t284 = icmp eq i32 %t281, %t283
  br i1 %t284, label %bb67, label %bb68
bb67:
  br label %bb71
bb68:
  %t286 = load i32, ptr %l4
  %t288 = trunc i64 23 to i32
  %t289 = icmp eq i32 %t286, %t288
  br i1 %t289, label %bb69, label %bb70
bb69:
  br label %bb71
bb70:
  br label %bb81
bb71:
  %t291 = load ptr, ptr %l0, !tbaa !29
  %t293 = getelementptr %"compiler/check:Checker", ptr %t291, i32 0, i32 1
  %t294 = load ptr, ptr %t293, !tbaa !29
  %t296 = getelementptr %"compiler/generic:Program", ptr %t294, i32 0, i32 2
  store ptr %t296, ptr %l159, !tbaa !29
  %t297 = load ptr, ptr %l0, !tbaa !29
  %t299 = getelementptr %"compiler/check:Checker", ptr %t297, i32 0, i32 1
  %t300 = load ptr, ptr %t299, !tbaa !29
  %t302 = getelementptr %"compiler/generic:Program", ptr %t300, i32 0, i32 2
  %t303 = load i32, ptr %l2, !tbaa !23
  %t306 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t302, i32 %t303)
  store i32 %t306, ptr %l164
  br label %bb72
bb72:
  %t307 = load ptr, ptr %l159, !tbaa !29
  %t308 = load i32, ptr %l164, !tbaa !23
  %t309 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t307, i32 %t308)
  store { i64, ptr } %t309, ptr %l165
  br label %bb73
bb73:
  %t310 = load { i64, ptr }, ptr %l165, !tbaa !27
  store { i64, ptr } %t310, ptr %l18, !tbaa !27
  store i64 0, ptr %l19, !tbaa !24
  %t311 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t313 = extractvalue { i64, ptr } %t311, 0
  store i64 %t313, ptr %l20, !tbaa !24
  br label %bb74
bb74:
  %t315 = load i64, ptr %l19, !tbaa !24
  %t316 = load i64, ptr %l20, !tbaa !24
  %t319 = icmp slt i64 %t315, %t316
  %t321 = xor i1 %t319, true
  br i1 %t321, label %bb75, label %bb76
bb75:
  br label %bb80
bb76:
  br label %bb77
bb77:
  %t323 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t323, ptr %l172, !tbaa !27
  %t324 = load i64, ptr %l19, !tbaa !24
  %t326 = getelementptr { i64, ptr }, ptr %l172, i32 0, i32 1
  %t327 = load ptr, ptr %t326, !tbaa !27
  %t328 = getelementptr i32, ptr %t327, i64 %t324
  %t329 = load i32, ptr %t328, !tbaa !33
  %t331 = load ptr, ptr %l0, !tbaa !29
  %t332 = load ptr, ptr %l1, !tbaa !29
  %t334 = load i64, ptr %l3, !tbaa !24
  %t336 = add i64 %t334, 1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aStr(ptr %v0, ptr %v1, ptr %t331, ptr %t332, i32 %t329, i64 %t336)
  br label %bb78
bb78:
  br label %bb79
bb79:
  %t341 = load i64, ptr %l19, !tbaa !24
  %t343 = add i64 %t341, 1
  store i64 %t343, ptr %l19, !tbaa !24
  br label %bb74
bb80:
  br label %bb82
bb81:
  br label %bb82
bb82:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebindType(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i1
  %l11 = alloca i1
  %l12 = alloca i1
  %l17 = alloca i32
  %l19 = alloca i32
  %l22 = alloca i32
  %l25 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i64, ptr }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb16
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load i32, ptr %l2, !tbaa !23
  %t20 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t16, i32 %t17)
  store i1 %t20, ptr %l11
  br label %bb6
bb6:
  %t21 = load i1, ptr %l11, !tbaa !21
  br i1 %t21, label %bb7, label %bb8
bb7:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/check:Checker", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/generic:Program", ptr %t25, i32 0, i32 2
  %t28 = load i32, ptr %l2, !tbaa !23
  %t31 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t27, i32 %t28)
  store i32 %t31, ptr %l17
  br label %bb9
bb8:
  store i1 false, ptr %l12, !tbaa !21
  br label %bb11
bb9:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %t32)
  store i32 %t34, ptr %l19
  br label %bb10
bb10:
  %t35 = load i32, ptr %l17, !tbaa !23
  %t36 = load i32, ptr %l19, !tbaa !23
  %t37 = icmp eq i32 %t35, %t36
  store i1 %t37, ptr %l12, !tbaa !21
  br label %bb11
bb11:
  %t39 = load i1, ptr %l12, !tbaa !21
  br i1 %t39, label %bb12, label %bb13
bb12:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %t40)
  store i32 %t42, ptr %l22
  br label %bb14
bb13:
  br label %bb15
bb14:
  %t43 = load i32, ptr %l22, !tbaa !23
  store i32 %t43, ptr %rv
  br label %ret
bb15:
  br label %bb17
bb16:
  br label %bb17
bb17:
  %t44 = load ptr, ptr %l1, !tbaa !29
  %t47 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t44)
  store i32 %t47, ptr %l25
  br label %bb18
bb18:
  %t48 = load i32, ptr %l25, !tbaa !23
  store i32 %t48, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecalleeName(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca ptr
  %l8 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca { i64, ptr }
  %l19 = alloca i1
  %l23 = alloca i1
  %l24 = alloca ptr
  %l27 = alloca ptr
  %l33 = alloca i32
  %l34 = alloca i32
  %l35 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l37 = alloca i64
  %l38 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l41 = alloca i64
  %l42 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp sge i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l0, !tbaa !29
  store ptr %t5, ptr %l4, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t10 = load i64, ptr %l1, !tbaa !24
  %t13 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t9, i64 %t10)
  store ptr %t13, ptr %l8
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t14 = load ptr, ptr %l8, !tbaa !29
  %t16 = getelementptr %"compiler/ast:Func", ptr %t14, i32 0, i32 2
  %t17 = load i32, ptr %t16, !tbaa !23
  %t18 = load ptr, ptr %l4, !tbaa !29
  %t20 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t18, i32 %t17)
  store { i64, ptr } %t20, ptr %l11
  br label %bb4
bb4:
  %t21 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t21, ptr %l12, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t22, 0
  store i64 %t23, ptr %l13, !tbaa !24
  %t24 = load i64, ptr %l13, !tbaa !24
  %t25 = mul i64 %t24, 1
  %t26 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t25)
  %t27 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  store { i64, ptr } %t28, ptr %l14, !tbaa !27
  %t29 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = load i64, ptr %l13, !tbaa !24
  %t34 = mul i64 %t33, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t30, ptr %t32, i64 %t34, i1 false)
  %t35 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t35, ptr %l12, !tbaa !27
  %t36 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t36, ptr %rv
  br label %ret
bb5:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/check:Checker", ptr %t37, i32 0, i32 22
  %t40 = load i32, ptr %t39, !tbaa !23
  %t41 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t44 = icmp ne i32 %t40, %t41
  br i1 %t44, label %bb6, label %bb7
bb6:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/check:Checker", ptr %t47, i32 0, i32 22
  %t50 = load i32, ptr %t49, !tbaa !23
  %t53 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t46, i32 %t50)
  store i1 %t53, ptr %l23
  br label %bb8
bb7:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb9
bb8:
  %t54 = load i1, ptr %l23, !tbaa !21
  store i1 %t54, ptr %l19, !tbaa !21
  br label %bb9
bb9:
  %t55 = load i1, ptr %l19, !tbaa !21
  br i1 %t55, label %bb10, label %bb11
bb10:
  %t56 = load ptr, ptr %l0, !tbaa !29
  store ptr %t56, ptr %l24, !tbaa !29
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/check:Checker", ptr %t57, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t62 = getelementptr %"compiler/generic:Program", ptr %t60, i32 0, i32 2
  store ptr %t62, ptr %l27, !tbaa !29
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/check:Checker", ptr %t63, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t68 = getelementptr %"compiler/generic:Program", ptr %t66, i32 0, i32 2
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/check:Checker", ptr %t69, i32 0, i32 22
  %t72 = load i32, ptr %t71, !tbaa !23
  %t75 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t68, i32 %t72)
  store i32 %t75, ptr %l33
  br label %bb12
bb11:
  br label %bb15
bb12:
  %t76 = load ptr, ptr %l27, !tbaa !29
  %t77 = load i32, ptr %l33, !tbaa !23
  %t78 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t76, i32 %t77)
  store i32 %t78, ptr %l34
  br label %bb13
bb13:
  %t79 = load ptr, ptr %l24, !tbaa !29
  %t80 = load i32, ptr %l34, !tbaa !23
  %t81 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t79, i32 %t80)
  store { i64, ptr } %t81, ptr %l35
  br label %bb14
bb14:
  %t82 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t82, ptr %l36, !tbaa !27
  %t83 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t84 = extractvalue { i64, ptr } %t83, 0
  store i64 %t84, ptr %l37, !tbaa !24
  %t85 = load i64, ptr %l37, !tbaa !24
  %t86 = mul i64 %t85, 1
  %t87 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t86)
  %t88 = insertvalue { i64, ptr } undef, i64 %t85, 0
  %t89 = insertvalue { i64, ptr } %t88, ptr %t87, 1
  store { i64, ptr } %t89, ptr %l38, !tbaa !27
  %t90 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t91 = load ptr, ptr %t90, !tbaa !27
  %t92 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !27
  %t94 = load i64, ptr %l37, !tbaa !24
  %t95 = mul i64 %t94, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t91, ptr %t93, i64 %t95, i1 false)
  %t96 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t96, ptr %l36, !tbaa !27
  %t97 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t97, ptr %rv
  br label %ret
bb15:
  store { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d24, i32 0, i32 1) }, ptr %l39, !tbaa !27
  %t98 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t98, ptr %l40, !tbaa !27
  %t99 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t100 = extractvalue { i64, ptr } %t99, 0
  store i64 %t100, ptr %l41, !tbaa !24
  %t101 = load i64, ptr %l41, !tbaa !24
  %t102 = mul i64 %t101, 1
  %t103 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t102)
  %t104 = insertvalue { i64, ptr } undef, i64 %t101, 0
  %t105 = insertvalue { i64, ptr } %t104, ptr %t103, 1
  store { i64, ptr } %t105, ptr %l42, !tbaa !27
  %t106 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !27
  %t108 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !27
  %t110 = load i64, ptr %l41, !tbaa !24
  %t111 = mul i64 %t110, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t107, ptr %t109, i64 %t111, i1 false)
  %t112 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t112, ptr %l40, !tbaa !27
  %t113 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t113, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseNameSpan(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l3 = alloca i32
  %l5 = alloca i32
  %l9 = alloca { i64, ptr }
  %l13 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:CaseDecl", ptr %t1, i32 0, i32 0
  %t4 = getelementptr %"compiler/source:Span", ptr %t3, i32 0, i32 0
  %t5 = load i32, ptr %t4, !tbaa !23
  store i32 %t5, ptr %l3, !tbaa !23
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = getelementptr %"compiler/ast:CaseDecl", ptr %t6, i32 0, i32 0
  %t9 = getelementptr %"compiler/source:Span", ptr %t8, i32 0, i32 0
  %t10 = load i32, ptr %t9, !tbaa !23
  store i32 %t10, ptr %l5, !tbaa !23
  %t12 = load ptr, ptr %l1, !tbaa !29
  %t14 = getelementptr %"compiler/ast:CaseDecl", ptr %t12, i32 0, i32 1
  %t15 = load i32, ptr %t14, !tbaa !23
  %t18 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %a0, i32 %t15)
  store { i64, ptr } %t18, ptr %l9
  br label %bb1
bb1:
  %t19 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t19, 0
  %t22 = trunc i64 %t20 to i32
  %t23 = load i32, ptr %l5, !tbaa !23
  %t25 = add i32 %t23, %t22
  %t26 = load i32, ptr %l3, !tbaa !23
  %t28 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %t26, i32 %t25)
  store %"compiler/source:Span" %t28, ptr %l13
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  %t29 = load %"compiler/source:Span", ptr %l13
  store %"compiler/source:Span" %t29, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseTag(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/generic:Desc"
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca %"compiler/source:Span"
  %l16 = alloca i1
  %l21 = alloca %"compiler/generic:Desc"
  %l30 = alloca i1
  %l31 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca i1
  %l44 = alloca i1
  %l51 = alloca { i64, ptr }
  %l61 = alloca i64
  %l64 = alloca i64
  %l82 = alloca { i64, ptr }
  %l88 = alloca %"compiler/source:Span"
  %l89 = alloca ptr
  %l90 = alloca i32
  %l91 = alloca i32
  %l92 = alloca i32
  %l95 = alloca { i64, ptr }
  %l100 = alloca %"compiler/source:Span"
  %s8 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  %t5 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l16
  br label %bb1
bb1:
  %t6 = load i1, ptr %l16, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  store i64 -1, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load ptr, ptr %l1, !tbaa !29
  %t14 = call %"compiler/generic:Desc" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseDesc(ptr %v0, ptr %v1, ptr %t10, ptr %t11)
  store %"compiler/generic:Desc" %t14, ptr %l21
  br label %bb5
bb5:
  %t15 = load %"compiler/generic:Desc", ptr %l21
  store %"compiler/generic:Desc" %t15, ptr %l3
  %t16 = getelementptr %"compiler/generic:Desc", ptr %l3, i32 0, i32 0
  %t17 = load i64, ptr %t16, !tbaa !24
  %t18 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescCase, !tbaa !24
  %t21 = icmp eq i64 %t17, %t18
  br i1 %t21, label %bb6, label %bb7
bb6:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/check:Checker", ptr %t23, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t28 = getelementptr %"compiler/generic:Program", ptr %t26, i32 0, i32 2
  %t29 = getelementptr %"compiler/generic:Desc", ptr %l3, i32 0, i32 1
  %t30 = load i32, ptr %t29, !tbaa !23
  %t31 = load i32, ptr %l2, !tbaa !23
  %t35 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t28, i32 %t30, i32 %t31)
  store i1 %t35, ptr %l30
  br label %bb8
bb7:
  br label %bb12
bb8:
  %t36 = load i1, ptr %l30, !tbaa !21
  br i1 %t36, label %bb9, label %bb10
bb9:
  %t37 = getelementptr %"compiler/generic:Desc", ptr %l3, i32 0, i32 2
  %t38 = load i64, ptr %t37, !tbaa !24
  store i64 %t38, ptr %l31, !tbaa !24
  br label %bb11
bb10:
  store i64 -1, ptr %l31, !tbaa !24
  br label %bb11
bb11:
  %t40 = load i64, ptr %l31, !tbaa !24
  store i64 %t40, ptr %rv
  br label %ret
bb12:
  %t41 = load ptr, ptr %l1, !tbaa !29
  store ptr %t41, ptr %l33, !tbaa !29
  store i1 false, ptr %l34, !tbaa !21
  %t42 = load ptr, ptr %l33, !tbaa !29
  %t43 = icmp ne ptr %t42, null
  br i1 %t43, label %bb13, label %bb14
bb13:
  %t45 = load ptr, ptr %l33, !tbaa !29
  %t46 = load i64, ptr %t45
  %t48 = icmp eq i64 %t46, 15
  store i1 %t48, ptr %l34, !tbaa !21
  br label %bb14
bb14:
  %t49 = load i1, ptr %l34, !tbaa !21
  br i1 %t49, label %bb15, label %bb16
bb15:
  %t50 = load ptr, ptr %l1, !tbaa !29
  %t52 = getelementptr { i64, [5 x i64] }, ptr %t50, i32 0, i32 1
  %t53 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t52, i32 0, i32 1
  %t54 = load ptr, ptr %t53
  store ptr %t54, ptr %l4, !tbaa !29
  %t56 = load ptr, ptr %l1, !tbaa !29
  %t58 = getelementptr { i64, [5 x i64] }, ptr %t56, i32 0, i32 1
  %t59 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t58, i32 0, i32 2
  %t60 = load i32, ptr %t59
  store i32 %t60, ptr %l5, !tbaa !23
  br label %bb17
bb16:
  br label %bb45
bb17:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load ptr, ptr %l4, !tbaa !29
  %t64 = load i32, ptr %l2, !tbaa !23
  %t68 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enamesEnumOf(ptr %v0, ptr %v1, ptr %t62, ptr %t63, i32 %t64)
  store i1 %t68, ptr %l44
  br label %bb18
bb18:
  %t69 = load i1, ptr %l44, !tbaa !21
  %t70 = xor i1 %t69, true
  br i1 %t70, label %bb19, label %bb20
bb19:
  store i64 -1, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/check:Checker", ptr %t73, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !29
  %t78 = getelementptr %"compiler/generic:Program", ptr %t76, i32 0, i32 2
  %t79 = load i32, ptr %l2, !tbaa !23
  %t82 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCaseNames(ptr %v0, ptr %t78, i32 %t79)
  store { i64, ptr } %t82, ptr %l51
  br label %bb22
bb22:
  %t83 = load { i64, ptr }, ptr %l51, !tbaa !27
  store { i64, ptr } %t83, ptr %l6, !tbaa !27
  %t84 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t84, 0
  %t88 = icmp eq i64 %t86, 0
  br i1 %t88, label %bb23, label %bb24
bb23:
  store i64 -1, ptr %rv
  br label %ret
bb24:
  br label %bb25
bb25:
  store i64 0, ptr %l7, !tbaa !24
  %t91 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t93 = extractvalue { i64, ptr } %t91, 0
  store i64 %t93, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t95 = load i64, ptr %l8, !tbaa !24
  %t96 = load i64, ptr %l7, !tbaa !24
  %t99 = icmp sgt i64 %t95, %t96
  br i1 %t99, label %bb26, label %bb27
bb26:
  %t101 = load i64, ptr %l9, !tbaa !24
  %t103 = icmp sgt i64 %t101, 0
  br i1 %t103, label %bb28, label %bb29
bb27:
  store i64 0, ptr %l61, !tbaa !24
  br label %bb31
bb28:
  %t105 = load i64, ptr %l8, !tbaa !24
  %t106 = load i64, ptr %l7, !tbaa !24
  %t109 = sub i64 %t105, %t106
  %t110 = load i64, ptr %l9, !tbaa !24
  %t113 = add i64 %t109, %t110
  %t115 = sub i64 %t113, 1
  %t116 = load i64, ptr %l9, !tbaa !24
  %t119 = sdiv i64 %t115, %t116
  store i64 %t119, ptr %l64, !tbaa !24
  br label %bb30
bb29:
  store i64 0, ptr %l64, !tbaa !24
  br label %bb30
bb30:
  %t121 = load i64, ptr %l64, !tbaa !24
  store i64 %t121, ptr %l61, !tbaa !24
  br label %bb31
bb31:
  %t122 = load i64, ptr %l61, !tbaa !24
  store i64 %t122, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb32
bb32:
  %t123 = load i64, ptr %l11, !tbaa !24
  %t124 = load i64, ptr %l10, !tbaa !24
  %t127 = icmp slt i64 %t123, %t124
  %t129 = xor i1 %t127, true
  br i1 %t129, label %bb33, label %bb34
bb33:
  br label %bb44
bb34:
  br label %bb35
bb35:
  %t131 = load i64, ptr %l7, !tbaa !24
  %t132 = load i64, ptr %l11, !tbaa !24
  %t133 = load i64, ptr %l9, !tbaa !24
  %t136 = mul i64 %t132, %t133
  %t139 = add i64 %t131, %t136
  store i64 %t139, ptr %l12, !tbaa !24
  %t141 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t141, ptr %l82, !tbaa !27
  %t142 = load i64, ptr %l12, !tbaa !24
  %t144 = getelementptr { i64, ptr }, ptr %l82, i32 0, i32 1
  %t145 = load ptr, ptr %t144, !tbaa !27
  %t146 = getelementptr i32, ptr %t145, i64 %t142
  %t147 = load i32, ptr %t146, !tbaa !33
  %t148 = load i32, ptr %l5, !tbaa !23
  %t151 = icmp eq i32 %t147, %t148
  br i1 %t151, label %bb36, label %bb37
bb36:
  store %olang.scope zeroinitializer, ptr %s8
  %t153 = load ptr, ptr %l1, !tbaa !29
  %t155 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t153)
  store %"compiler/source:Span" %t155, ptr %l88
  br label %bb38
bb37:
  br label %bb42
bb38:
  %t156 = load %"compiler/source:Span", ptr %l88
  store %"compiler/source:Span" %t156, ptr %l13
  %t157 = load ptr, ptr %l0, !tbaa !29
  store ptr %t157, ptr %l89, !tbaa !29
  %t158 = load i32, ptr %l2, !tbaa !23
  store i32 %t158, ptr %l90, !tbaa !23
  %t159 = load i32, ptr %l5, !tbaa !23
  store i32 %t159, ptr %l91, !tbaa !23
  %t160 = getelementptr %"compiler/source:Span", ptr %l13, i32 0, i32 1
  %t161 = load i32, ptr %t160, !tbaa !23
  store i32 %t161, ptr %l92, !tbaa !23
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t163 = load i32, ptr %l5, !tbaa !23
  %t166 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t162, i32 %t163)
  store { i64, ptr } %t166, ptr %l95
  br label %bb39
bb39:
  %t167 = load { i64, ptr }, ptr %l95, !tbaa !27
  %t168 = extractvalue { i64, ptr } %t167, 0
  %t170 = trunc i64 %t168 to i32
  %t171 = load i32, ptr %l92, !tbaa !23
  %t173 = sub i32 %t171, %t170
  %t174 = getelementptr %"compiler/source:Span", ptr %l13, i32 0, i32 1
  %t175 = load i32, ptr %t174, !tbaa !23
  %t178 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s8, i32 %t173, i32 %t175)
  store %"compiler/source:Span" %t178, ptr %l100
  br label %bb40
bb40:
  %t179 = load ptr, ptr %l89, !tbaa !29
  %t180 = load i32, ptr %l90, !tbaa !23
  %t181 = load i32, ptr %l91, !tbaa !23
  %t182 = load %"compiler/source:Span", ptr %l100
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecasePublic(ptr %v0, ptr %t179, i32 %t180, i32 %t181, %"compiler/source:Span" %t182)
  br label %bb41
bb41:
  %t183 = load i64, ptr %l12, !tbaa !24
  call void @__olang_scope_close(ptr %s8)
  store i64 %t183, ptr %rv
  br label %ret
bb42:
  br label %bb43
bb43:
  %t185 = load i64, ptr %l11, !tbaa !24
  %t187 = add i64 %t185, 1
  store i64 %t187, ptr %l11, !tbaa !24
  br label %bb32
bb44:
  store i64 -1, ptr %rv
  br label %ret
bb45:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtCaseTest(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca %"compiler/source:Span"
  %l10 = alloca ptr
  %l19 = alloca { i64, ptr }
  %l22 = alloca ptr
  %l23 = alloca i1
  %l30 = alloca ptr
  %l31 = alloca i1
  %l49 = alloca ptr
  %l73 = alloca %"compiler/source:Span"
  %l74 = alloca i32
  %l77 = alloca ptr
  %rv = alloca ptr
  %t74 = alloca { i64, [5 x i64] }, align 8
  %t106 = alloca { i64, [5 x i64] }, align 8
  %t134 = alloca { i64, [5 x i64] }, align 8
  %t174 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store ptr null, ptr %l3, !tbaa !29
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Case", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l6, !tbaa !24
  br label %bb1
bb1:
  %t10 = load i64, ptr %l5, !tbaa !24
  %t11 = load i64, ptr %l6, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  br label %bb23
bb3:
  br label %bb4
bb4:
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t18, ptr %l19, !tbaa !27
  %t19 = load i64, ptr %l5, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr ptr, ptr %t22, i64 %t19
  %t24 = load ptr, ptr %t23, !tbaa !39
  store ptr %t24, ptr %l7, !tbaa !29
  store ptr null, ptr %l8, !tbaa !29
  %t26 = load ptr, ptr %l7, !tbaa !29
  store ptr %t26, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t27 = load ptr, ptr %l22, !tbaa !29
  %t28 = icmp ne ptr %t27, null
  br i1 %t28, label %bb5, label %bb6
bb5:
  %t30 = load ptr, ptr %l22, !tbaa !29
  %t31 = load i64, ptr %t30
  %t33 = icmp eq i64 %t31, 1
  store i1 %t33, ptr %l23, !tbaa !21
  br label %bb6
bb6:
  %t34 = load i1, ptr %l23, !tbaa !21
  br i1 %t34, label %bb7, label %bb8
bb7:
  %t35 = load ptr, ptr %l7, !tbaa !29
  %t37 = getelementptr { i64, [4 x i64] }, ptr %t35, i32 0, i32 1
  %t38 = getelementptr { %"compiler/source:Span", ptr }, ptr %t37, i32 0, i32 0
  %t39 = load %"compiler/source:Span", ptr %t38
  store %"compiler/source:Span" %t39, ptr %l9
  %t41 = load ptr, ptr %l7, !tbaa !29
  %t43 = getelementptr { i64, [4 x i64] }, ptr %t41, i32 0, i32 1
  %t44 = getelementptr { %"compiler/source:Span", ptr }, ptr %t43, i32 0, i32 1
  %t45 = load ptr, ptr %t44
  store ptr %t45, ptr %l10, !tbaa !29
  br label %bb13
bb8:
  %t47 = load ptr, ptr %l7, !tbaa !29
  store ptr %t47, ptr %l30, !tbaa !29
  store i1 false, ptr %l31, !tbaa !21
  %t48 = load ptr, ptr %l30, !tbaa !29
  %t49 = icmp ne ptr %t48, null
  br i1 %t49, label %bb9, label %bb10
bb9:
  %t51 = load ptr, ptr %l30, !tbaa !29
  %t52 = load i64, ptr %t51
  %t54 = icmp eq i64 %t52, 4
  store i1 %t54, ptr %l31, !tbaa !21
  br label %bb10
bb10:
  %t55 = load i1, ptr %l31, !tbaa !21
  br i1 %t55, label %bb11, label %bb12
bb11:
  %t56 = load ptr, ptr %l7, !tbaa !29
  %t58 = getelementptr { i64, [4 x i64] }, ptr %t56, i32 0, i32 1
  %t59 = getelementptr { %"compiler/source:Span", ptr }, ptr %t58, i32 0, i32 0
  %t60 = load %"compiler/source:Span", ptr %t59
  store %"compiler/source:Span" %t60, ptr %l9
  %t62 = load ptr, ptr %l7, !tbaa !29
  %t64 = getelementptr { i64, [4 x i64] }, ptr %t62, i32 0, i32 1
  %t65 = getelementptr { %"compiler/source:Span", ptr }, ptr %t64, i32 0, i32 1
  %t66 = load ptr, ptr %t65
  store ptr %t66, ptr %l10, !tbaa !29
  br label %bb13
bb12:
  br label %bb14
bb13:
  %t68 = load %"compiler/source:Span", ptr %l9
  %t71 = getelementptr %"compiler/ast:Match", ptr %a1, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !29
  %t73 = load ptr, ptr %l10, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t74
  %t75 = getelementptr { i64, [5 x i64] }, ptr %t74, i32 0, i32 0
  store i64 5, ptr %t75
  %t77 = insertvalue { %"compiler/source:Span", i32, ptr, ptr } undef, %"compiler/source:Span" %t68, 0
  %t79 = insertvalue { %"compiler/source:Span", i32, ptr, ptr } %t77, i32 75, 1
  %t81 = insertvalue { %"compiler/source:Span", i32, ptr, ptr } %t79, ptr %t72, 2
  %t83 = insertvalue { %"compiler/source:Span", i32, ptr, ptr } %t81, ptr %t73, 3
  %t84 = getelementptr { i64, [5 x i64] }, ptr %t74, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, ptr } %t83, ptr %t84
  %t85 = load { i64, [5 x i64] }, ptr %t74
  %t87 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 48, i64 8)
  store { i64, [5 x i64] } %t85, ptr %t87
  store ptr %t87, ptr %l8, !tbaa !29
  br label %bb15
bb14:
  br label %bb15
bb15:
  %t89 = load ptr, ptr %l8, !tbaa !29
  %t91 = icmp eq ptr %t89, null
  br i1 %t91, label %bb16, label %bb17
bb16:
  br label %bb22
bb17:
  br label %bb18
bb18:
  %t93 = load ptr, ptr %l3, !tbaa !29
  %t95 = icmp eq ptr %t93, null
  br i1 %t95, label %bb19, label %bb20
bb19:
  %t97 = load ptr, ptr %l8, !tbaa !29
  store ptr %t97, ptr %l49, !tbaa !29
  br label %bb21
bb20:
  %t100 = load ptr, ptr %l2, !tbaa !29
  %t102 = getelementptr %"compiler/ast:Case", ptr %t100, i32 0, i32 0
  %t103 = load %"compiler/source:Span", ptr %t102
  %t104 = load ptr, ptr %l3, !tbaa !29
  %t105 = load ptr, ptr %l8, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t106
  %t107 = getelementptr { i64, [5 x i64] }, ptr %t106, i32 0, i32 0
  store i64 5, ptr %t107
  %t109 = insertvalue { %"compiler/source:Span", i32, ptr, ptr } undef, %"compiler/source:Span" %t103, 0
  %t111 = insertvalue { %"compiler/source:Span", i32, ptr, ptr } %t109, i32 47, 1
  %t113 = insertvalue { %"compiler/source:Span", i32, ptr, ptr } %t111, ptr %t104, 2
  %t115 = insertvalue { %"compiler/source:Span", i32, ptr, ptr } %t113, ptr %t105, 3
  %t116 = getelementptr { i64, [5 x i64] }, ptr %t106, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, ptr } %t115, ptr %t116
  %t117 = load { i64, [5 x i64] }, ptr %t106
  %t119 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 48, i64 8)
  store { i64, [5 x i64] } %t117, ptr %t119
  store ptr %t119, ptr %l49, !tbaa !29
  br label %bb21
bb21:
  %t121 = load ptr, ptr %l49, !tbaa !29
  store ptr %t121, ptr %l3, !tbaa !29
  br label %bb22
bb22:
  %t122 = load i64, ptr %l5, !tbaa !24
  %t124 = add i64 %t122, 1
  store i64 %t124, ptr %l5, !tbaa !24
  br label %bb1
bb23:
  %t126 = load ptr, ptr %l3, !tbaa !29
  %t128 = icmp eq ptr %t126, null
  br i1 %t128, label %bb24, label %bb25
bb24:
  %t130 = load ptr, ptr %l2, !tbaa !29
  %t132 = getelementptr %"compiler/ast:Case", ptr %t130, i32 0, i32 0
  %t133 = load %"compiler/source:Span", ptr %t132
  store { i64, [5 x i64] } zeroinitializer, ptr %t134
  %t135 = getelementptr { i64, [5 x i64] }, ptr %t134, i32 0, i32 0
  store i64 1, ptr %t135
  %t137 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t133, 0
  %t139 = insertvalue { %"compiler/source:Span", i32 } %t137, i32 6, 1
  %t140 = getelementptr { i64, [5 x i64] }, ptr %t134, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t139, ptr %t140
  %t141 = load { i64, [5 x i64] }, ptr %t134
  %t143 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 48, i64 8)
  store { i64, [5 x i64] } %t141, ptr %t143
  store ptr %t143, ptr %l3, !tbaa !29
  br label %bb26
bb25:
  br label %bb26
bb26:
  %t145 = load ptr, ptr %l2, !tbaa !29
  %t147 = getelementptr %"compiler/ast:Case", ptr %t145, i32 0, i32 3
  %t148 = load ptr, ptr %t147, !tbaa !29
  %t150 = icmp eq ptr %t148, null
  %t152 = xor i1 %t150, true
  br i1 %t152, label %bb27, label %bb28
bb27:
  %t154 = load ptr, ptr %l2, !tbaa !29
  %t156 = getelementptr %"compiler/ast:Case", ptr %t154, i32 0, i32 0
  %t157 = load %"compiler/source:Span", ptr %t156
  store %"compiler/source:Span" %t157, ptr %l73
  store i32 46, ptr %l74
  %t158 = load ptr, ptr %l3, !tbaa !29
  %t160 = icmp eq ptr %t158, null
  br i1 %t160, label %bb29, label %bb30
bb28:
  br label %bb35
bb29:
  call void @__olang_check_failed(ptr @olang_loc_da99cffe6602dc08_7fa7c9f5ef49167c)
  unreachable
bb30:
  br label %bb31
bb31:
  %t162 = load ptr, ptr %l3, !tbaa !29
  store ptr %t162, ptr %l77, !tbaa !29
  %t163 = load ptr, ptr %l2, !tbaa !29
  %t165 = getelementptr %"compiler/ast:Case", ptr %t163, i32 0, i32 3
  %t166 = load ptr, ptr %t165, !tbaa !29
  %t168 = icmp eq ptr %t166, null
  br i1 %t168, label %bb32, label %bb33
bb32:
  call void @__olang_check_failed(ptr @olang_loc_da99cffe6602dc08_7fa7c9f5ef49167c)
  unreachable
bb33:
  br label %bb34
bb34:
  %t170 = load ptr, ptr %l2, !tbaa !29
  %t172 = getelementptr %"compiler/ast:Case", ptr %t170, i32 0, i32 3
  %t173 = load ptr, ptr %t172, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t174
  %t175 = getelementptr { i64, [5 x i64] }, ptr %t174, i32 0, i32 0
  store i64 5, ptr %t175
  %t176 = load %"compiler/source:Span", ptr %l73
  %t177 = insertvalue { %"compiler/source:Span", i32, ptr, ptr } undef, %"compiler/source:Span" %t176, 0
  %t178 = load i32, ptr %l74
  %t179 = insertvalue { %"compiler/source:Span", i32, ptr, ptr } %t177, i32 %t178, 1
  %t180 = load ptr, ptr %l77, !tbaa !29
  %t181 = insertvalue { %"compiler/source:Span", i32, ptr, ptr } %t179, ptr %t180, 2
  %t183 = insertvalue { %"compiler/source:Span", i32, ptr, ptr } %t181, ptr %t173, 3
  %t184 = getelementptr { i64, [5 x i64] }, ptr %t174, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, ptr } %t183, ptr %t184
  %t185 = load { i64, [5 x i64] }, ptr %t174
  %t187 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 48, i64 8)
  store { i64, [5 x i64] } %t185, ptr %t187
  store ptr %t187, ptr %l3, !tbaa !29
  br label %bb35
bb35:
  %t189 = load ptr, ptr %l3, !tbaa !29
  %t191 = icmp eq ptr %t189, null
  br i1 %t191, label %bb36, label %bb37
bb36:
  call void @__olang_check_failed(ptr @olang_loc_ddff752a05460a27_f846f4bbf4f845eb)
  unreachable
bb37:
  br label %bb38
bb38:
  %t193 = load ptr, ptr %l3, !tbaa !29
  store ptr %t193, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvWords(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %lp6 = alloca ptr
  %l9 = alloca i32
  %l12 = alloca i32
  %l14 = alloca i32
  %l20 = alloca i1
  %l21 = alloca i1
  %l26 = alloca i1
  %l29 = alloca i32
  %l31 = alloca { i64, ptr }
  %l36 = alloca i1
  %l41 = alloca i64
  %l46 = alloca i64
  %l48 = alloca i1
  %l52 = alloca { i64, ptr }
  %l54 = alloca { i64, ptr }
  %l61 = alloca i1
  %l66 = alloca i64
  %l68 = alloca { i64, ptr }
  %l70 = alloca { i64, ptr }
  %l77 = alloca i32
  %l83 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t1, i32 %a1)
  store i32 %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load i32, ptr %l9, !tbaa !23
  store i32 %t6, ptr %l3, !tbaa !23
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t11 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t7, i32 %a2)
  store i32 %t11, ptr %l12
  br label %bb2
bb2:
  %t12 = load i32, ptr %l12, !tbaa !23
  store i32 %t12, ptr %l4, !tbaa !23
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epreludeWord(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %t13, { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d25, i32 0, i32 1) }, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d26, i32 0, i32 1) }, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d27, i32 0, i32 1) })
  store i32 %t15, ptr %l14
  br label %bb3
bb3:
  %t16 = load i32, ptr %l14, !tbaa !23
  store i32 %t16, ptr %l5, !tbaa !23
  %t17 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 0, i64 8)
  store ptr %t17, ptr %lp6
  %t19 = load ptr, ptr %lp6
  store [0 x i32] zeroinitializer, ptr %t19
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/check:Checker", ptr %t20, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t25 = getelementptr %"compiler/generic:Program", ptr %t23, i32 0, i32 2
  %t26 = load i32, ptr %l3, !tbaa !23
  %t29 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t25, i32 %t26)
  store i1 %t29, ptr %l20
  br label %bb4
bb4:
  %t30 = load i1, ptr %l20, !tbaa !21
  br i1 %t30, label %bb5, label %bb6
bb5:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/check:Checker", ptr %t31, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t36 = getelementptr %"compiler/generic:Program", ptr %t34, i32 0, i32 2
  %t37 = load i32, ptr %l4, !tbaa !23
  %t40 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t36, i32 %t37)
  store i1 %t40, ptr %l26
  br label %bb7
bb6:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb8
bb7:
  %t41 = load i1, ptr %l26, !tbaa !21
  %t42 = xor i1 %t41, true
  store i1 %t42, ptr %l21, !tbaa !21
  br label %bb8
bb8:
  %t44 = load i1, ptr %l21, !tbaa !21
  br i1 %t44, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s1
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epreludeWord(ptr %v0, ptr %s1, ptr %s1, ptr %s1, ptr %t45, { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d28, i32 0, i32 1) }, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d29, i32 0, i32 1) }, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d30, i32 0, i32 1) })
  store i32 %t47, ptr %l29
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t48 = load i32, ptr %l5, !tbaa !23
  %t49 = mul i64 2, 4
  %t50 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t49)
  %t51 = insertvalue { i64, ptr } undef, i64 2, 0
  %t52 = insertvalue { i64, ptr } %t51, ptr %t50, 1
  store { i64, ptr } %t52, ptr %l31, !tbaa !27
  %t53 = load i32, ptr %l29, !tbaa !23
  %t54 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = getelementptr i32, ptr %t55, i64 0
  store i32 %t53, ptr %t56, !tbaa !33
  %t58 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = getelementptr i32, ptr %t59, i64 1
  store i32 %t48, ptr %t60, !tbaa !33
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t61 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t61, ptr %rv
  br label %ret
bb12:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/check:Checker", ptr %t62, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t67 = getelementptr %"compiler/generic:Program", ptr %t65, i32 0, i32 2
  %t68 = load i32, ptr %l3, !tbaa !23
  %t71 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t67, i32 %t68)
  store i1 %t71, ptr %l36
  br label %bb13
bb13:
  %t72 = load i1, ptr %l36, !tbaa !21
  br i1 %t72, label %bb14, label %bb15
bb14:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/check:Checker", ptr %t73, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !29
  %t78 = getelementptr %"compiler/generic:Program", ptr %t76, i32 0, i32 2
  %t79 = load i32, ptr %l4, !tbaa !23
  %t82 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %t78, i32 %t79)
  store i64 %t82, ptr %l41
  br label %bb16
bb15:
  br label %bb24
bb16:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/check:Checker", ptr %t83, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !29
  %t88 = getelementptr %"compiler/generic:Program", ptr %t86, i32 0, i32 2
  %t89 = load i32, ptr %l3, !tbaa !23
  %t92 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %t88, i32 %t89)
  store i64 %t92, ptr %l46
  br label %bb17
bb17:
  %t93 = load i64, ptr %l41, !tbaa !24
  %t94 = load i64, ptr %l46, !tbaa !24
  %t95 = icmp slt i64 %t93, %t94
  br i1 %t95, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l48, !tbaa !21
  br label %bb20
bb19:
  %t97 = load i32, ptr %l4, !tbaa !23
  %t98 = load i32, ptr %l3, !tbaa !23
  %t101 = icmp ne i32 %t97, %t98
  store i1 %t101, ptr %l48, !tbaa !21
  br label %bb20
bb20:
  %t103 = load i1, ptr %l48, !tbaa !21
  br i1 %t103, label %bb21, label %bb22
bb21:
  %t104 = load i32, ptr %l5, !tbaa !23
  %t105 = mul i64 1, 4
  %t106 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t105)
  %t107 = insertvalue { i64, ptr } undef, i64 1, 0
  %t108 = insertvalue { i64, ptr } %t107, ptr %t106, 1
  store { i64, ptr } %t108, ptr %l54, !tbaa !27
  %t110 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !27
  %t112 = getelementptr i32, ptr %t111, i64 0
  store i32 %t104, ptr %t112, !tbaa !33
  %t113 = load { i64, ptr }, ptr %l54, !tbaa !27
  store { i64, ptr } %t113, ptr %l52, !tbaa !27
  br label %bb23
bb22:
  %t114 = load ptr, ptr %lp6
  %t116 = insertvalue { i64, ptr } undef, i64 0, 0
  %t117 = insertvalue { i64, ptr } %t116, ptr %t114, 1
  store { i64, ptr } %t117, ptr %l52, !tbaa !27
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s0)
  %t119 = load { i64, ptr }, ptr %l52, !tbaa !27
  store { i64, ptr } %t119, ptr %rv
  br label %ret
bb24:
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t122 = getelementptr %"compiler/check:Checker", ptr %t120, i32 0, i32 1
  %t123 = load ptr, ptr %t122, !tbaa !29
  %t125 = getelementptr %"compiler/generic:Program", ptr %t123, i32 0, i32 2
  %t126 = load i32, ptr %l4, !tbaa !23
  %t129 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t125, i32 %t126)
  store i1 %t129, ptr %l61
  br label %bb25
bb25:
  %t130 = load i1, ptr %l61, !tbaa !21
  br i1 %t130, label %bb26, label %bb27
bb26:
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t133 = getelementptr %"compiler/check:Checker", ptr %t131, i32 0, i32 1
  %t134 = load ptr, ptr %t133, !tbaa !29
  %t136 = getelementptr %"compiler/generic:Program", ptr %t134, i32 0, i32 2
  %t137 = load i32, ptr %l4, !tbaa !23
  %t140 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %t136, i32 %t137)
  store i64 %t140, ptr %l66
  br label %bb28
bb27:
  br label %bb32
bb28:
  %t141 = load i64, ptr %l66, !tbaa !24
  %t142 = icmp sle i64 %t141, 16
  br i1 %t142, label %bb29, label %bb30
bb29:
  %t144 = load i32, ptr %l5, !tbaa !23
  %t145 = mul i64 1, 4
  %t146 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t145)
  %t147 = insertvalue { i64, ptr } undef, i64 1, 0
  %t148 = insertvalue { i64, ptr } %t147, ptr %t146, 1
  store { i64, ptr } %t148, ptr %l70, !tbaa !27
  %t150 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t151 = load ptr, ptr %t150, !tbaa !27
  %t152 = getelementptr i32, ptr %t151, i64 0
  store i32 %t144, ptr %t152, !tbaa !33
  %t153 = load { i64, ptr }, ptr %l70, !tbaa !27
  store { i64, ptr } %t153, ptr %l68, !tbaa !27
  br label %bb31
bb30:
  %t154 = load ptr, ptr %lp6
  %t156 = insertvalue { i64, ptr } undef, i64 0, 0
  %t157 = insertvalue { i64, ptr } %t156, ptr %t154, 1
  store { i64, ptr } %t157, ptr %l68, !tbaa !27
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s0)
  %t159 = load { i64, ptr }, ptr %l68, !tbaa !27
  store { i64, ptr } %t159, ptr %rv
  br label %ret
bb32:
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t162 = getelementptr %"compiler/check:Checker", ptr %t160, i32 0, i32 1
  %t163 = load ptr, ptr %t162, !tbaa !29
  %t164 = load i32, ptr %l3, !tbaa !23
  %t165 = load i32, ptr %l4, !tbaa !23
  %t169 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMeet(ptr %v0, ptr %t163, i32 %t164, i32 %t165)
  store i32 %t169, ptr %l77
  br label %bb33
bb33:
  %t170 = load i32, ptr %l4, !tbaa !23
  %t171 = load i32, ptr %l77, !tbaa !23
  %t173 = icmp eq i32 %t171, %t170
  br i1 %t173, label %bb34, label %bb35
bb34:
  %t175 = load ptr, ptr %lp6
  %t177 = insertvalue { i64, ptr } undef, i64 0, 0
  %t178 = insertvalue { i64, ptr } %t177, ptr %t175, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t178, ptr %rv
  br label %ret
bb35:
  br label %bb36
bb36:
  %t180 = load i32, ptr %l5, !tbaa !23
  %t181 = mul i64 1, 4
  %t182 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t181)
  %t183 = insertvalue { i64, ptr } undef, i64 1, 0
  %t184 = insertvalue { i64, ptr } %t183, ptr %t182, 1
  store { i64, ptr } %t184, ptr %l83, !tbaa !27
  %t186 = getelementptr { i64, ptr }, ptr %l83, i32 0, i32 1
  %t187 = load ptr, ptr %t186, !tbaa !27
  %t188 = getelementptr i32, ptr %t187, i64 0
  store i32 %t180, ptr %t188, !tbaa !33
  call void @__olang_scope_close(ptr %s0)
  %t189 = load { i64, ptr }, ptr %l83, !tbaa !27
  store { i64, ptr } %t189, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecover(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2, ptr %a3, i1 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i32
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca i64
  %l19 = alloca ptr
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca ptr
  %l25 = alloca i64
  %l27 = alloca i64
  %l29 = alloca ptr
  %l30 = alloca i1
  %l41 = alloca i32
  %l46 = alloca ptr
  %l47 = alloca i1
  %l55 = alloca i1
  %l56 = alloca i32
  %l59 = alloca ptr
  %l63 = alloca i32
  %l64 = alloca i32
  %l67 = alloca ptr
  %l72 = alloca i32
  %l73 = alloca { i64, ptr }
  %l83 = alloca i64
  %l86 = alloca i64
  %l104 = alloca i64
  %l106 = alloca i64
  %l108 = alloca i1
  %l112 = alloca { i64, ptr }
  %l116 = alloca i1
  %l119 = alloca i1
  %l120 = alloca i1
  %l122 = alloca ptr
  %l123 = alloca %"compiler/source:Span"
  %l126 = alloca { i64, ptr }
  %l128 = alloca %"compiler/msgs:Msg"
  %l129 = alloca i64
  %l134 = alloca ptr
  %l135 = alloca i1
  %l140 = alloca ptr
  %l141 = alloca i1
  %l149 = alloca i64
  %l154 = alloca ptr
  %l155 = alloca i1
  %l169 = alloca { i64, ptr }
  %l172 = alloca ptr
  %l173 = alloca i1
  %l176 = alloca ptr
  %l177 = alloca i1
  %l185 = alloca i64
  %s10 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l3, !tbaa !29
  %t3 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v2, ptr %t1)
  store i64 %t3, ptr %l27
  br label %bb1
bb1:
  %t4 = load i64, ptr %l27, !tbaa !24
  %t5 = icmp eq i64 %t4, 0
  br i1 %t5, label %bb2, label %bb3
bb2:
  br label %ret
bb3:
  br label %bb4
bb4:
  %t7 = load ptr, ptr %l1, !tbaa !29
  store ptr %t7, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t8 = load ptr, ptr %l29, !tbaa !29
  %t9 = icmp ne ptr %t8, null
  br i1 %t9, label %bb5, label %bb6
bb5:
  %t11 = load ptr, ptr %l29, !tbaa !29
  %t12 = load i64, ptr %t11
  %t14 = icmp eq i64 %t12, 5
  store i1 %t14, ptr %l30, !tbaa !21
  br label %bb6
bb6:
  %t15 = load i1, ptr %l30, !tbaa !21
  br i1 %t15, label %bb7, label %bb8
bb7:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [4 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", ptr, i32, %"compiler/source:Span" }, ptr %t18, i32 0, i32 0
  %t20 = load %"compiler/source:Span", ptr %t19
  store %"compiler/source:Span" %t20, ptr %l5
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr { i64, [4 x i64] }, ptr %t22, i32 0, i32 1
  %t25 = getelementptr { %"compiler/source:Span", ptr, i32, %"compiler/source:Span" }, ptr %t24, i32 0, i32 1
  %t26 = load ptr, ptr %t25
  store ptr %t26, ptr %l6, !tbaa !29
  br label %bb9
bb8:
  br label %bb63
bb9:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/check:Checker", ptr %t28, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t33 = getelementptr %"compiler/generic:Program", ptr %t31, i32 0, i32 2
  %t34 = load i32, ptr %l2, !tbaa !23
  %t37 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t33, i32 %t34)
  store i32 %t37, ptr %l41
  br label %bb10
bb10:
  %t38 = load i32, ptr %l41
  %t40 = trunc i64 29 to i32
  %t41 = icmp eq i32 %t38, %t40
  %t43 = xor i1 %t41, true
  br i1 %t43, label %bb11, label %bb12
bb11:
  br label %ret
bb12:
  br label %bb13
bb13:
  %t45 = load ptr, ptr %l6, !tbaa !29
  store ptr %t45, ptr %l7, !tbaa !29
  %t47 = load ptr, ptr %l6, !tbaa !29
  store ptr %t47, ptr %l46, !tbaa !29
  store i1 false, ptr %l47, !tbaa !21
  %t48 = load ptr, ptr %l46, !tbaa !29
  %t49 = icmp ne ptr %t48, null
  br i1 %t49, label %bb14, label %bb15
bb14:
  %t51 = load ptr, ptr %l46, !tbaa !29
  %t52 = load i64, ptr %t51
  %t54 = icmp eq i64 %t52, 3
  store i1 %t54, ptr %l47, !tbaa !21
  br label %bb15
bb15:
  %t55 = load i1, ptr %l47, !tbaa !21
  br i1 %t55, label %bb16, label %bb17
bb16:
  %t56 = load ptr, ptr %l6, !tbaa !29
  %t58 = getelementptr { i64, [5 x i64] }, ptr %t56, i32 0, i32 1
  %t59 = getelementptr { %"compiler/source:Span", ptr, i32, i1 }, ptr %t58, i32 0, i32 1
  %t60 = load ptr, ptr %t59
  store ptr %t60, ptr %l8, !tbaa !29
  br label %bb18
bb17:
  br label %bb19
bb18:
  %t62 = load ptr, ptr %l8, !tbaa !29
  store ptr %t62, ptr %l7, !tbaa !29
  br label %bb20
bb19:
  br label %bb20
bb20:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t65 = load ptr, ptr %l7, !tbaa !29
  %t68 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseTypeWritten(ptr %v0, ptr %v1, ptr %t64, ptr %t65, i1 false)
  store i1 %t68, ptr %l55
  br label %bb21
bb21:
  %t69 = load i1, ptr %l55, !tbaa !21
  br i1 %t69, label %bb22, label %bb23
bb22:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/check:Checker", ptr %t70, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !29
  %t75 = getelementptr %"compiler/generic:Program", ptr %t73, i32 0, i32 2
  store ptr %t75, ptr %l59, !tbaa !29
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t77 = load ptr, ptr %l7, !tbaa !29
  %t81 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresolve(ptr %v0, ptr %v1, ptr %t76, ptr %t77)
  store i32 %t81, ptr %l63
  br label %bb24
bb23:
  %t82 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t82, ptr %l56, !tbaa !23
  br label %bb26
bb24:
  %t84 = load ptr, ptr %l59, !tbaa !29
  %t85 = load i32, ptr %l63, !tbaa !23
  %t86 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t84, i32 %t85)
  store i32 %t86, ptr %l64
  br label %bb25
bb25:
  %t87 = load i32, ptr %l64, !tbaa !23
  store i32 %t87, ptr %l56, !tbaa !23
  br label %bb26
bb26:
  %t88 = load i32, ptr %l56, !tbaa !23
  store i32 %t88, ptr %l9, !tbaa !23
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"compiler/check:Checker", ptr %t89, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !29
  store ptr %t92, ptr %l67, !tbaa !29
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/check:Checker", ptr %t93, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !29
  %t98 = getelementptr %"compiler/generic:Program", ptr %t96, i32 0, i32 2
  %t99 = load i32, ptr %l2, !tbaa !23
  %t102 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnyTrait(ptr %v0, ptr %t98, i32 %t99)
  store i32 %t102, ptr %l72
  br label %bb27
bb27:
  %t103 = load ptr, ptr %l67, !tbaa !29
  %t104 = load i32, ptr %l72, !tbaa !23
  %t105 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMembers(ptr %v0, ptr %t103, i32 %t104)
  store { i64, ptr } %t105, ptr %l73
  br label %bb28
bb28:
  %t106 = load { i64, ptr }, ptr %l73, !tbaa !27
  store { i64, ptr } %t106, ptr %l10, !tbaa !27
  %t107 = load i32, ptr %l9, !tbaa !23
  %t108 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t111 = icmp eq i32 %t107, %t108
  br i1 %t111, label %bb29, label %bb30
bb29:
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t115 = getelementptr %"compiler/check:Checker", ptr %t113, i32 0, i32 96
  store i1 true, ptr %t115, !tbaa !21
  br label %ret
bb30:
  br label %bb31
bb31:
  store i64 0, ptr %l11, !tbaa !24
  %t116 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t118 = extractvalue { i64, ptr } %t116, 0
  store i64 %t118, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t120 = load i64, ptr %l12, !tbaa !24
  %t121 = load i64, ptr %l11, !tbaa !24
  %t124 = icmp sgt i64 %t120, %t121
  br i1 %t124, label %bb32, label %bb33
bb32:
  %t126 = load i64, ptr %l13, !tbaa !24
  %t128 = icmp sgt i64 %t126, 0
  br i1 %t128, label %bb34, label %bb35
bb33:
  store i64 0, ptr %l83, !tbaa !24
  br label %bb37
bb34:
  %t130 = load i64, ptr %l12, !tbaa !24
  %t131 = load i64, ptr %l11, !tbaa !24
  %t134 = sub i64 %t130, %t131
  %t135 = load i64, ptr %l13, !tbaa !24
  %t138 = add i64 %t134, %t135
  %t140 = sub i64 %t138, 1
  %t141 = load i64, ptr %l13, !tbaa !24
  %t144 = sdiv i64 %t140, %t141
  store i64 %t144, ptr %l86, !tbaa !24
  br label %bb36
bb35:
  store i64 0, ptr %l86, !tbaa !24
  br label %bb36
bb36:
  %t146 = load i64, ptr %l86, !tbaa !24
  store i64 %t146, ptr %l83, !tbaa !24
  br label %bb37
bb37:
  %t147 = load i64, ptr %l83, !tbaa !24
  store i64 %t147, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb38
bb38:
  %t148 = load i64, ptr %l15, !tbaa !24
  %t149 = load i64, ptr %l14, !tbaa !24
  %t152 = icmp slt i64 %t148, %t149
  %t154 = xor i1 %t152, true
  br i1 %t154, label %bb39, label %bb40
bb39:
  br label %bb62
bb40:
  br label %bb41
bb41:
  %t156 = load i64, ptr %l11, !tbaa !24
  %t157 = load i64, ptr %l15, !tbaa !24
  %t158 = load i64, ptr %l13, !tbaa !24
  %t161 = mul i64 %t157, %t158
  %t164 = add i64 %t156, %t161
  store i64 %t164, ptr %l16, !tbaa !24
  %t166 = load i64, ptr %l16, !tbaa !24
  store i64 %t166, ptr %l104, !tbaa !24
  %t167 = load ptr, ptr %l3, !tbaa !29
  %t169 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v2, ptr %t167)
  store i64 %t169, ptr %l106
  br label %bb42
bb42:
  %t170 = load i64, ptr %l104, !tbaa !24
  %t171 = load i64, ptr %l106, !tbaa !24
  %t172 = icmp slt i64 %t170, %t171
  br i1 %t172, label %bb43, label %bb44
bb43:
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t176 = getelementptr %"compiler/check:Checker", ptr %t174, i32 0, i32 1
  %t177 = load ptr, ptr %t176, !tbaa !29
  %t179 = getelementptr %"compiler/generic:Program", ptr %t177, i32 0, i32 2
  %t180 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t180, ptr %l112, !tbaa !27
  %t181 = load i64, ptr %l16, !tbaa !24
  %t183 = getelementptr { i64, ptr }, ptr %l112, i32 0, i32 1
  %t184 = load ptr, ptr %t183, !tbaa !27
  %t185 = getelementptr i32, ptr %t184, i64 %t181
  %t186 = load i32, ptr %t185, !tbaa !33
  %t187 = load i32, ptr %l9, !tbaa !23
  %t191 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t179, i32 %t186, i32 %t187)
  store i1 %t191, ptr %l116
  br label %bb45
bb44:
  store i1 false, ptr %l108, !tbaa !21
  br label %bb46
bb45:
  %t192 = load i1, ptr %l116, !tbaa !21
  store i1 %t192, ptr %l108, !tbaa !21
  br label %bb46
bb46:
  %t193 = load i1, ptr %l108, !tbaa !21
  br i1 %t193, label %bb47, label %bb48
bb47:
  %t194 = load ptr, ptr %l3, !tbaa !29
  %t195 = load i64, ptr %l16, !tbaa !24
  %t198 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v2, ptr %t194, i64 %t195)
  store i1 %t198, ptr %l119
  br label %bb49
bb48:
  br label %bb60
bb49:
  %t199 = load i1, ptr %l119, !tbaa !21
  br i1 %t199, label %bb50, label %bb51
bb50:
  store i1 true, ptr %l120, !tbaa !21
  br label %bb52
bb51:
  store i1 %a4, ptr %l120, !tbaa !21
  br label %bb52
bb52:
  %t202 = load i1, ptr %l120, !tbaa !21
  br i1 %t202, label %bb53, label %bb54
bb53:
  store %olang.scope zeroinitializer, ptr %s10
  %t203 = load ptr, ptr %l0, !tbaa !29
  store ptr %t203, ptr %l122, !tbaa !29
  %t204 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t204, ptr %l123
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t206 = load i32, ptr %l9, !tbaa !23
  %t209 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s10, ptr %t205, i32 %t206)
  store { i64, ptr } %t209, ptr %l126
  br label %bb55
bb54:
  br label %bb58
bb55:
  %t210 = load { i64, ptr }, ptr %l126, !tbaa !27
  %t211 = extractvalue { i64, ptr } %t210, 0
  %t212 = extractvalue { i64, ptr } %t210, 1
  %t213 = mul i64 %t211, 1
  %t214 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t213)
  call void @llvm.memcpy.p0.p0.i64(ptr %t214, ptr %t212, i64 %t213, i1 false)
  %t215 = insertvalue { i64, ptr } undef, i64 %t211, 0
  %t216 = insertvalue { i64, ptr } %t215, ptr %t214, 1
  %t218 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eAnyCaseTwice(ptr %s10, ptr %s10, { i64, ptr } %t216)
  store %"compiler/msgs:Msg" %t218, ptr %l128
  br label %bb56
bb56:
  %t219 = load ptr, ptr %l122, !tbaa !29
  %t220 = load %"compiler/source:Span", ptr %l123
  %t221 = load %"compiler/msgs:Msg", ptr %l128
  %t222 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s10, ptr %t219, %"compiler/source:Span" %t220, %"compiler/msgs:Msg" %t221)
  store i64 %t222, ptr %l129
  br label %bb57
bb57:
  call void @__olang_scope_close(ptr %s10)
  br label %bb58
bb58:
  %t223 = load ptr, ptr %l3, !tbaa !29
  %t224 = load i64, ptr %l16, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v2, ptr %t223, i64 %t224, i1 true)
  br label %bb59
bb59:
  br label %bb60
bb60:
  br label %bb61
bb61:
  %t227 = load i64, ptr %l15, !tbaa !24
  %t229 = add i64 %t227, 1
  store i64 %t229, ptr %l15, !tbaa !24
  br label %bb38
bb62:
  br label %bb107
bb63:
  %t231 = load ptr, ptr %l1, !tbaa !29
  store ptr %t231, ptr %l134, !tbaa !29
  store i1 false, ptr %l135, !tbaa !21
  %t232 = load ptr, ptr %l134, !tbaa !29
  %t233 = icmp ne ptr %t232, null
  br i1 %t233, label %bb64, label %bb65
bb64:
  %t235 = load ptr, ptr %l134, !tbaa !29
  %t236 = load i64, ptr %t235
  %t238 = icmp eq i64 %t236, 1
  store i1 %t238, ptr %l135, !tbaa !21
  br label %bb65
bb65:
  %t239 = load i1, ptr %l135, !tbaa !21
  br i1 %t239, label %bb66, label %bb67
bb66:
  %t240 = load ptr, ptr %l1, !tbaa !29
  %t242 = getelementptr { i64, [4 x i64] }, ptr %t240, i32 0, i32 1
  %t243 = getelementptr { %"compiler/source:Span", ptr }, ptr %t242, i32 0, i32 1
  %t244 = load ptr, ptr %t243
  store ptr %t244, ptr %l17, !tbaa !29
  br label %bb72
bb67:
  %t246 = load ptr, ptr %l1, !tbaa !29
  store ptr %t246, ptr %l140, !tbaa !29
  store i1 false, ptr %l141, !tbaa !21
  %t247 = load ptr, ptr %l140, !tbaa !29
  %t248 = icmp ne ptr %t247, null
  br i1 %t248, label %bb68, label %bb69
bb68:
  %t250 = load ptr, ptr %l140, !tbaa !29
  %t251 = load i64, ptr %t250
  %t253 = icmp eq i64 %t251, 4
  store i1 %t253, ptr %l141, !tbaa !21
  br label %bb69
bb69:
  %t254 = load i1, ptr %l141, !tbaa !21
  br i1 %t254, label %bb70, label %bb71
bb70:
  %t255 = load ptr, ptr %l1, !tbaa !29
  %t257 = getelementptr { i64, [4 x i64] }, ptr %t255, i32 0, i32 1
  %t258 = getelementptr { %"compiler/source:Span", ptr }, ptr %t257, i32 0, i32 1
  %t259 = load ptr, ptr %t258
  store ptr %t259, ptr %l17, !tbaa !29
  br label %bb72
bb71:
  br label %bb78
bb72:
  %t261 = load ptr, ptr %l0, !tbaa !29
  %t262 = load ptr, ptr %l17, !tbaa !29
  %t263 = load i32, ptr %l2, !tbaa !23
  %t267 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseTag(ptr %v0, ptr %v1, ptr %t261, ptr %t262, i32 %t263)
  store i64 %t267, ptr %l149
  br label %bb73
bb73:
  %t268 = load i64, ptr %l149, !tbaa !24
  store i64 %t268, ptr %l18, !tbaa !24
  %t269 = load i64, ptr %l18, !tbaa !24
  %t271 = icmp sge i64 %t269, 0
  br i1 %t271, label %bb74, label %bb75
bb74:
  %t273 = load ptr, ptr %l3, !tbaa !29
  %t274 = load i64, ptr %l18, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v2, ptr %t273, i64 %t274, i1 true)
  br label %bb76
bb75:
  br label %bb77
bb76:
  br label %bb77
bb77:
  br label %bb107
bb78:
  %t277 = load ptr, ptr %l1, !tbaa !29
  store ptr %t277, ptr %l154, !tbaa !29
  store i1 false, ptr %l155, !tbaa !21
  %t278 = load ptr, ptr %l154, !tbaa !29
  %t279 = icmp ne ptr %t278, null
  br i1 %t279, label %bb79, label %bb80
bb79:
  %t281 = load ptr, ptr %l154, !tbaa !29
  %t282 = load i64, ptr %t281
  %t284 = icmp eq i64 %t282, 2
  store i1 %t284, ptr %l155, !tbaa !21
  br label %bb80
bb80:
  %t285 = load i1, ptr %l155, !tbaa !21
  br i1 %t285, label %bb81, label %bb82
bb81:
  %t286 = load ptr, ptr %l1, !tbaa !29
  %t288 = getelementptr { i64, [4 x i64] }, ptr %t286, i32 0, i32 1
  %t289 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t288, i32 0, i32 1
  %t290 = load ptr, ptr %t289
  store ptr %t290, ptr %l19, !tbaa !29
  %t292 = load ptr, ptr %l1, !tbaa !29
  %t294 = getelementptr { i64, [4 x i64] }, ptr %t292, i32 0, i32 1
  %t295 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t294, i32 0, i32 2
  %t296 = load { i64, ptr }, ptr %t295
  store { i64, ptr } %t296, ptr %l20, !tbaa !27
  br label %bb83
bb82:
  br label %bb106
bb83:
  %t298 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t298, ptr %l21, !tbaa !27
  store i64 0, ptr %l22, !tbaa !24
  %t300 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t302 = extractvalue { i64, ptr } %t300, 0
  store i64 %t302, ptr %l23, !tbaa !24
  br label %bb84
bb84:
  %t304 = load i64, ptr %l22, !tbaa !24
  %t305 = load i64, ptr %l23, !tbaa !24
  %t308 = icmp slt i64 %t304, %t305
  %t310 = xor i1 %t308, true
  br i1 %t310, label %bb85, label %bb86
bb85:
  br label %bb100
bb86:
  br label %bb87
bb87:
  %t312 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t312, ptr %l169, !tbaa !27
  %t313 = load i64, ptr %l22, !tbaa !24
  %t315 = getelementptr { i64, ptr }, ptr %l169, i32 0, i32 1
  %t316 = load ptr, ptr %t315, !tbaa !27
  %t317 = getelementptr ptr, ptr %t316, i64 %t313
  %t318 = load ptr, ptr %t317, !tbaa !39
  store ptr %t318, ptr %l24, !tbaa !29
  %t320 = load ptr, ptr %l24, !tbaa !29
  store ptr %t320, ptr %l172, !tbaa !29
  store i1 false, ptr %l173, !tbaa !21
  %t321 = load ptr, ptr %l172, !tbaa !29
  %t322 = icmp ne ptr %t321, null
  br i1 %t322, label %bb88, label %bb89
bb88:
  %t324 = load ptr, ptr %l172, !tbaa !29
  %t325 = load i64, ptr %t324
  %t327 = icmp eq i64 %t325, 3
  store i1 %t327, ptr %l173, !tbaa !21
  br label %bb89
bb89:
  %t328 = load i1, ptr %l173, !tbaa !21
  br i1 %t328, label %bb90, label %bb91
bb90:
  br label %bb96
bb91:
  %t329 = load ptr, ptr %l24, !tbaa !29
  store ptr %t329, ptr %l176, !tbaa !29
  store i1 false, ptr %l177, !tbaa !21
  %t330 = load ptr, ptr %l176, !tbaa !29
  %t331 = icmp ne ptr %t330, null
  br i1 %t331, label %bb92, label %bb93
bb92:
  %t333 = load ptr, ptr %l176, !tbaa !29
  %t334 = load i64, ptr %t333
  %t336 = icmp eq i64 %t334, 0
  store i1 %t336, ptr %l177, !tbaa !21
  br label %bb93
bb93:
  %t337 = load i1, ptr %l177, !tbaa !21
  br i1 %t337, label %bb94, label %bb95
bb94:
  br label %bb96
bb95:
  br label %bb97
bb96:
  br label %bb98
bb97:
  br label %ret
bb98:
  br label %bb99
bb99:
  %t338 = load i64, ptr %l22, !tbaa !24
  %t340 = add i64 %t338, 1
  store i64 %t340, ptr %l22, !tbaa !24
  br label %bb84
bb100:
  %t342 = load ptr, ptr %l0, !tbaa !29
  %t343 = load ptr, ptr %l19, !tbaa !29
  %t344 = load i32, ptr %l2, !tbaa !23
  %t348 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseTag(ptr %v0, ptr %v1, ptr %t342, ptr %t343, i32 %t344)
  store i64 %t348, ptr %l185
  br label %bb101
bb101:
  %t349 = load i64, ptr %l185, !tbaa !24
  store i64 %t349, ptr %l25, !tbaa !24
  %t350 = load i64, ptr %l25, !tbaa !24
  %t352 = icmp sge i64 %t350, 0
  br i1 %t352, label %bb102, label %bb103
bb102:
  %t354 = load ptr, ptr %l3, !tbaa !29
  %t355 = load i64, ptr %l25, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v2, ptr %t354, i64 %t355, i1 true)
  br label %bb104
bb103:
  br label %bb105
bb104:
  br label %bb105
bb105:
  br label %bb107
bb106:
  br label %bb107
bb107:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecurInst(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [2 x i64] }
  %l2 = alloca i64
  %l5 = alloca i64
  %l7 = alloca i1
  %l9 = alloca ptr
  %l15 = alloca ptr
  %l18 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 13
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_H2251bc8fca359ca0394d0bb11af7ba0a(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i64, ptr %l5, !tbaa !24
  %t7 = icmp eq i64 %t6, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb5
bb3:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t9)
  store ptr %t11, ptr %l9
  br label %bb4
bb4:
  %t12 = load ptr, ptr %l9, !tbaa !29
  %t14 = getelementptr %"compiler/check:frame", ptr %t12, i32 0, i32 0
  %t15 = load i64, ptr %t14, !tbaa !24
  %t17 = icmp slt i64 %t15, 0
  store i1 %t17, ptr %l7, !tbaa !21
  br label %bb5
bb5:
  %t19 = load i1, ptr %l7, !tbaa !21
  br i1 %t19, label %bb6, label %bb7
bb6:
  store i64 -1, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t21)
  store ptr %t23, ptr %l15
  br label %bb9
bb9:
  %t24 = load ptr, ptr %l15, !tbaa !29
  %t26 = getelementptr %"compiler/typed:Body", ptr %t24, i32 0, i32 1
  %t27 = load { i64, [2 x i64] }, ptr %t26
  store { i64, [2 x i64] } %t27, ptr %l1
  %t29 = load { i64, [2 x i64] }, ptr %l1
  %t31 = extractvalue { i64, [2 x i64] } %t29, 0
  %t32 = icmp eq i64 %t31, 0
  br i1 %t32, label %bb10, label %bb11
bb10:
  %t34 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t35 = getelementptr { i64 }, ptr %t34, i32 0, i32 0
  %t36 = load i64, ptr %t35
  store i64 %t36, ptr %l2, !tbaa !24
  br label %bb12
bb11:
  br label %bb13
bb12:
  %t38 = load i64, ptr %l2, !tbaa !24
  store i64 %t38, ptr %l18, !tbaa !24
  br label %bb18
bb13:
  br i1 true, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  store i64 -1, ptr %l18, !tbaa !24
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_1b2b22cc85627f3f_81f3e65f4e45ba6b)
  unreachable
bb18:
  %t40 = load i64, ptr %l18, !tbaa !24
  store i64 %t40, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edefaultCopiesRecv(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca i32
  %l8 = alloca i32
  %l11 = alloca ptr
  %l16 = alloca i32
  %l17 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l25 = alloca i32
  %l30 = alloca i32
  %l36 = alloca ptr
  %l41 = alloca i32
  %l46 = alloca i64
  %l51 = alloca i64
  %l52 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t8 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t4, i64 %a1)
  store i32 %t8, ptr %l8
  br label %bb1
bb1:
  %t9 = load i32, ptr %l8, !tbaa !23
  store i32 %t9, ptr %l2, !tbaa !23
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = getelementptr %"compiler/generic:Program", ptr %t13, i32 0, i32 2
  store ptr %t15, ptr %l11, !tbaa !29
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/check:Checker", ptr %t16, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = getelementptr %"compiler/generic:Program", ptr %t19, i32 0, i32 2
  %t22 = load i32, ptr %l2, !tbaa !23
  %t25 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t21, i32 %t22)
  store i32 %t25, ptr %l16
  br label %bb2
bb2:
  %t26 = load ptr, ptr %l11, !tbaa !29
  %t27 = load i32, ptr %l16, !tbaa !23
  %t28 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t26, i32 %t27)
  store { i64, ptr } %t28, ptr %l17
  br label %bb3
bb3:
  %t29 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t29, ptr %l3, !tbaa !27
  %t30 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t30, 0
  %t34 = icmp eq i64 %t32, 0
  br i1 %t34, label %bb4, label %bb5
bb4:
  store i1 false, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t38, ptr %l23, !tbaa !27
  %t39 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !27
  %t41 = getelementptr i32, ptr %t40, i64 0
  %t42 = load i32, ptr %t41, !tbaa !33
  %t45 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t37, i32 %t42)
  store i32 %t45, ptr %l25
  br label %bb7
bb7:
  %t46 = load i32, ptr %l25, !tbaa !23
  store i32 %t46, ptr %l4, !tbaa !23
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/check:Checker", ptr %t47, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !29
  %t52 = getelementptr %"compiler/generic:Program", ptr %t50, i32 0, i32 2
  %t53 = load i32, ptr %l4, !tbaa !23
  %t56 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t52, i32 %t53)
  store i32 %t56, ptr %l30
  br label %bb8
bb8:
  %t57 = load i32, ptr %l30
  %t59 = trunc i64 25 to i32
  %t60 = icmp eq i32 %t57, %t59
  %t62 = xor i1 %t60, true
  br i1 %t62, label %bb9, label %bb10
bb9:
  store i1 false, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/check:Checker", ptr %t65, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !29
  store ptr %t68, ptr %l36, !tbaa !29
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/check:Checker", ptr %t69, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !29
  %t74 = getelementptr %"compiler/generic:Program", ptr %t72, i32 0, i32 2
  %t75 = load i32, ptr %l2, !tbaa !23
  %t78 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t74, i32 %t75)
  store i32 %t78, ptr %l41
  br label %bb12
bb12:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/check:Checker", ptr %t79, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t84 = getelementptr %"compiler/generic:Program", ptr %t82, i32 0, i32 2
  %t85 = load i32, ptr %l4, !tbaa !23
  %t88 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %t84, i32 %t85)
  store i64 %t88, ptr %l46
  br label %bb13
bb13:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"compiler/check:Checker", ptr %t89, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !29
  %t94 = getelementptr %"compiler/generic:Program", ptr %t92, i32 0, i32 2
  %t95 = load i32, ptr %l4, !tbaa !23
  %t98 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eB(ptr %v0, ptr %t94, i32 %t95)
  store i64 %t98, ptr %l51
  br label %bb14
bb14:
  %t99 = load ptr, ptr %l36, !tbaa !29
  %t100 = load i32, ptr %l41, !tbaa !23
  %t101 = load i64, ptr %l46, !tbaa !24
  %t102 = load i64, ptr %l51, !tbaa !24
  %t103 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eHoldsVarByValue(ptr %v0, ptr %t99, i32 %t100, i64 %t101, i64 %t102, i64 0)
  store i1 %t103, ptr %l52
  br label %bb15
bb15:
  %t104 = load i1, ptr %l52, !tbaa !21
  store i1 %t104, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropTaken(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2, ptr %a3) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i64
  %l4 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l12 = alloca i32
  %l13 = alloca ptr
  %l14 = alloca i64
  %l16 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l19 = alloca i64
  %l23 = alloca i64
  %l26 = alloca i64
  %l46 = alloca i32
  %l50 = alloca i32
  %l61 = alloca i64
  %l63 = alloca i64
  %l68 = alloca i32
  %s0 = alloca %olang.scope
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l16
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l16
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l4
  %t3 = load i64, ptr %l2, !tbaa !24
  store i64 %t3, ptr %l5, !tbaa !24
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v1, ptr %t5)
  store i64 %t7, ptr %l19
  br label %bb2
bb2:
  %t8 = load i64, ptr %l19, !tbaa !24
  store i64 %t8, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t9 = load i64, ptr %l6, !tbaa !24
  %t10 = load i64, ptr %l5, !tbaa !24
  %t13 = icmp sgt i64 %t9, %t10
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t15 = load i64, ptr %l7, !tbaa !24
  %t17 = icmp sgt i64 %t15, 0
  br i1 %t17, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb8
bb5:
  %t19 = load i64, ptr %l6, !tbaa !24
  %t20 = load i64, ptr %l5, !tbaa !24
  %t23 = sub i64 %t19, %t20
  %t24 = load i64, ptr %l7, !tbaa !24
  %t27 = add i64 %t23, %t24
  %t29 = sub i64 %t27, 1
  %t30 = load i64, ptr %l7, !tbaa !24
  %t33 = sdiv i64 %t29, %t30
  store i64 %t33, ptr %l26, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l26, !tbaa !24
  br label %bb7
bb7:
  %t35 = load i64, ptr %l26, !tbaa !24
  store i64 %t35, ptr %l23, !tbaa !24
  br label %bb8
bb8:
  %t36 = load i64, ptr %l23, !tbaa !24
  store i64 %t36, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb9
bb9:
  %t37 = load i64, ptr %l9, !tbaa !24
  %t38 = load i64, ptr %l8, !tbaa !24
  %t41 = icmp slt i64 %t37, %t38
  %t43 = xor i1 %t41, true
  br i1 %t43, label %bb10, label %bb11
bb10:
  br label %bb20
bb11:
  br label %bb12
bb12:
  %t45 = load i64, ptr %l5, !tbaa !24
  %t46 = load i64, ptr %l9, !tbaa !24
  %t47 = load i64, ptr %l7, !tbaa !24
  %t50 = mul i64 %t46, %t47
  %t53 = add i64 %t45, %t50
  %t55 = load ptr, ptr %l1, !tbaa !29
  %t59 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v1, ptr %t55, i64 %t53)
  store i32 %t59, ptr %l46
  br label %bb13
bb13:
  %t60 = load i32, ptr %l46, !tbaa !23
  %t67 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleft(ptr %v0, ptr %v2, ptr %a0, i32 %t60, ptr %a3)
  store i32 %t67, ptr %l50
  br label %bb14
bb14:
  %t68 = load i32, ptr %l50, !tbaa !23
  store i32 %t68, ptr %l12, !tbaa !23
  %t69 = load i32, ptr %l12, !tbaa !23
  %t70 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t73 = icmp ne i32 %t69, %t70
  br i1 %t73, label %bb15, label %bb16
bb15:
  %t75 = load i32, ptr %l12, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l4, i32 %t75)
  br label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb18
bb18:
  br label %bb19
bb19:
  %t78 = load i64, ptr %l9, !tbaa !24
  %t80 = add i64 %t78, 1
  store i64 %t80, ptr %l9, !tbaa !24
  br label %bb9
bb20:
  %t82 = load ptr, ptr %l1, !tbaa !29
  %t83 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eTruncate_3ccompiler_2ftypes_3aTypeId_3e(ptr %v1, ptr %t82, i64 %t83)
  br label %bb21
bb21:
  store ptr %l4, ptr %l13, !tbaa !29
  store i64 0, ptr %l14, !tbaa !24
  br label %bb22
bb22:
  %t87 = load i64, ptr %l14, !tbaa !24
  store i64 %t87, ptr %l61, !tbaa !24
  %t88 = load ptr, ptr %l13, !tbaa !29
  %t90 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t88)
  store i64 %t90, ptr %l63
  br label %bb23
bb23:
  %t91 = load i64, ptr %l61, !tbaa !24
  %t92 = load i64, ptr %l63, !tbaa !24
  %t93 = icmp slt i64 %t91, %t92
  %t95 = xor i1 %t93, true
  br i1 %t95, label %bb24, label %bb25
bb24:
  br label %bb30
bb25:
  br label %bb26
bb26:
  %t97 = load ptr, ptr %l13, !tbaa !29
  %t98 = load i64, ptr %l14, !tbaa !24
  %t101 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t97, i64 %t98)
  store i32 %t101, ptr %l68
  br label %bb27
bb27:
  %t102 = load i32, ptr %l68, !tbaa !23
  %t103 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v1, ptr %t103, i32 %t102)
  br label %bb28
bb28:
  br label %bb29
bb29:
  %t107 = load i64, ptr %l14, !tbaa !24
  %t109 = add i64 %t107, 1
  store i64 %t109, ptr %l14, !tbaa !24
  br label %bb22
bb30:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeqShaped(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca { i64, ptr }
  %l6 = alloca ptr
  %l9 = alloca ptr
  %l13 = alloca i32
  %l14 = alloca i32
  %l15 = alloca { i64, ptr }
  %l19 = alloca i1
  %l22 = alloca ptr
  %l24 = alloca { i64, ptr }
  %l26 = alloca i32
  %l27 = alloca i32
  %l30 = alloca i1
  %l33 = alloca ptr
  %l36 = alloca ptr
  %l38 = alloca { i64, ptr }
  %l40 = alloca i32
  %l41 = alloca i32
  %l46 = alloca i32
  %l47 = alloca i1
  %l48 = alloca i1
  %l51 = alloca ptr
  %l53 = alloca { i64, ptr }
  %l55 = alloca i32
  %l56 = alloca i32
  %l61 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  store ptr %t6, ptr %l6, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  store ptr %t12, ptr %l9, !tbaa !29
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/check:Checker", ptr %t13, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t20 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t16, i64 %a2)
  store i32 %t20, ptr %l13
  br label %bb1
bb1:
  %t21 = load ptr, ptr %l9, !tbaa !29
  %t22 = load i32, ptr %l13, !tbaa !23
  %t23 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t21, i32 %t22)
  store i32 %t23, ptr %l14
  br label %bb2
bb2:
  %t24 = load ptr, ptr %l6, !tbaa !29
  %t25 = load i32, ptr %l14, !tbaa !23
  %t26 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t24, i32 %t25)
  store { i64, ptr } %t26, ptr %l15
  br label %bb3
bb3:
  %t27 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t27, ptr %l3, !tbaa !27
  %t28 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t28, 0
  %t32 = icmp eq i64 %t30, 2
  br i1 %t32, label %bb4, label %bb5
bb4:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/check:Checker", ptr %t34, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t39 = getelementptr %"compiler/generic:Program", ptr %t37, i32 0, i32 2
  store ptr %t39, ptr %l22, !tbaa !29
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t41, ptr %l24, !tbaa !27
  %t42 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = getelementptr i32, ptr %t43, i64 1
  %t45 = load i32, ptr %t44, !tbaa !33
  %t48 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t40, i32 %t45)
  store i32 %t48, ptr %l26
  br label %bb6
bb5:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb21
bb6:
  %t49 = load ptr, ptr %l22, !tbaa !29
  %t50 = load i32, ptr %l26, !tbaa !23
  %t51 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t49, i32 %t50)
  store i32 %t51, ptr %l27
  br label %bb7
bb7:
  %t52 = load i32, ptr %l27
  %t54 = trunc i64 25 to i32
  %t55 = icmp eq i32 %t52, %t54
  br i1 %t55, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb14
bb9:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/check:Checker", ptr %t57, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t62 = getelementptr %"compiler/generic:Program", ptr %t60, i32 0, i32 2
  store ptr %t62, ptr %l33, !tbaa !29
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/check:Checker", ptr %t63, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t68 = getelementptr %"compiler/generic:Program", ptr %t66, i32 0, i32 2
  store ptr %t68, ptr %l36, !tbaa !29
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t70, ptr %l38, !tbaa !27
  %t71 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !27
  %t73 = getelementptr i32, ptr %t72, i64 1
  %t74 = load i32, ptr %t73, !tbaa !33
  %t77 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t69, i32 %t74)
  store i32 %t77, ptr %l40
  br label %bb10
bb10:
  %t78 = load ptr, ptr %l36, !tbaa !29
  %t79 = load i32, ptr %l40, !tbaa !23
  %t80 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t78, i32 %t79)
  store i32 %t80, ptr %l41
  br label %bb11
bb11:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/check:Checker", ptr %t81, i32 0, i32 1
  %t84 = load ptr, ptr %t83, !tbaa !29
  %t86 = getelementptr %"compiler/generic:Program", ptr %t84, i32 0, i32 2
  %t87 = load i32, ptr %l1, !tbaa !23
  %t90 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t86, i32 %t87)
  store i32 %t90, ptr %l46
  br label %bb12
bb12:
  %t91 = load ptr, ptr %l33, !tbaa !29
  %t92 = load i32, ptr %l41, !tbaa !23
  %t93 = load i32, ptr %l46, !tbaa !23
  %t94 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t91, i32 %t92, i32 %t93)
  store i1 %t94, ptr %l47
  br label %bb13
bb13:
  %t95 = load i1, ptr %l47, !tbaa !21
  store i1 %t95, ptr %l30, !tbaa !21
  br label %bb14
bb14:
  %t96 = load i1, ptr %l30, !tbaa !21
  br i1 %t96, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l48, !tbaa !21
  br label %bb20
bb16:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/check:Checker", ptr %t97, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !29
  %t102 = getelementptr %"compiler/generic:Program", ptr %t100, i32 0, i32 2
  store ptr %t102, ptr %l51, !tbaa !29
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t104 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t104, ptr %l53, !tbaa !27
  %t105 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !27
  %t107 = getelementptr i32, ptr %t106, i64 1
  %t108 = load i32, ptr %t107, !tbaa !33
  %t111 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t103, i32 %t108)
  store i32 %t111, ptr %l55
  br label %bb17
bb17:
  %t112 = load ptr, ptr %l51, !tbaa !29
  %t113 = load i32, ptr %l55, !tbaa !23
  %t114 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t112, i32 %t113)
  store i32 %t114, ptr %l56
  br label %bb18
bb18:
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"compiler/check:Checker", ptr %t115, i32 0, i32 1
  %t118 = load ptr, ptr %t117, !tbaa !29
  %t120 = getelementptr %"compiler/generic:Program", ptr %t118, i32 0, i32 2
  %t121 = load i32, ptr %l1, !tbaa !23
  %t124 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t120, i32 %t121)
  store i32 %t124, ptr %l61
  br label %bb19
bb19:
  %t125 = load i32, ptr %l56, !tbaa !23
  %t126 = load i32, ptr %l61, !tbaa !23
  %t127 = icmp eq i32 %t125, %t126
  store i1 %t127, ptr %l48, !tbaa !21
  br label %bb20
bb20:
  %t129 = load i1, ptr %l48, !tbaa !21
  store i1 %t129, ptr %l19, !tbaa !21
  br label %bb21
bb21:
  %t130 = load i1, ptr %l19, !tbaa !21
  store i1 %t130, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca %"compiler/source:Span"
  %l9 = alloca i32
  %l10 = alloca %"compiler/source:Span"
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca ptr
  %lp18 = alloca ptr
  %l19 = alloca i32
  %l20 = alloca i32
  %l21 = alloca i32
  %l22 = alloca %"compiler/source:Span"
  %l23 = alloca i64
  %l24 = alloca ptr
  %l26 = alloca i32
  %l28 = alloca ptr
  %l31 = alloca i32
  %l32 = alloca i32
  %l33 = alloca %"compiler/source:Span"
  %l34 = alloca ptr
  %l35 = alloca ptr
  %l36 = alloca ptr
  %l37 = alloca i64
  %l39 = alloca i32
  %l40 = alloca %"compiler/source:Span"
  %l41 = alloca ptr
  %l42 = alloca ptr
  %l43 = alloca ptr
  %l44 = alloca i32
  %l45 = alloca i32
  %l47 = alloca ptr
  %l48 = alloca i32
  %l49 = alloca i32
  %l50 = alloca i64
  %l53 = alloca i32
  %l57 = alloca i1
  %l61 = alloca i1
  %l68 = alloca i32
  %l71 = alloca i1
  %l74 = alloca i32
  %l81 = alloca i1
  %l87 = alloca i1
  %l88 = alloca i1
  %l94 = alloca i1
  %l96 = alloca ptr
  %l97 = alloca %"compiler/source:Span"
  %l100 = alloca { i64, ptr }
  %l101 = alloca { i64, ptr }
  %l104 = alloca { i64, ptr }
  %l106 = alloca %"compiler/msgs:Msg"
  %l107 = alloca i64
  %l111 = alloca ptr
  %l112 = alloca i64
  %l115 = alloca { i64, [3 x i64] }
  %l118 = alloca { i64, ptr }
  %l120 = alloca %"compiler/msgs:Msg"
  %l125 = alloca i1
  %l131 = alloca i1
  %l134 = alloca i1
  %l135 = alloca i1
  %l140 = alloca i64
  %l147 = alloca i1
  %l157 = alloca i32
  %l162 = alloca i32
  %l165 = alloca i1
  %l168 = alloca i1
  %l173 = alloca i1
  %l178 = alloca i1
  %l184 = alloca i1
  %l186 = alloca %"compiler/source:Span"
  %l187 = alloca ptr
  %l188 = alloca %"compiler/source:Span"
  %l191 = alloca { i64, ptr }
  %l194 = alloca { i64, ptr }
  %l195 = alloca { i64, ptr }
  %l198 = alloca { i64, ptr }
  %l199 = alloca { i64, ptr }
  %l202 = alloca { i64, ptr }
  %l203 = alloca { i64, ptr }
  %l205 = alloca %"compiler/msgs:Msg"
  %l206 = alloca i64
  %l208 = alloca ptr
  %l209 = alloca %"compiler/source:Span"
  %l210 = alloca ptr
  %l211 = alloca ptr
  %l216 = alloca i32
  %l218 = alloca ptr
  %l220 = alloca ptr
  %l225 = alloca i1
  %l226 = alloca i1
  %l230 = alloca i1
  %l235 = alloca i1
  %l236 = alloca i1
  %l239 = alloca ptr
  %l244 = alloca i32
  %l249 = alloca i32
  %l250 = alloca i1
  %l256 = alloca ptr
  %l261 = alloca i32
  %l265 = alloca i1
  %l268 = alloca ptr
  %l273 = alloca i32
  %l278 = alloca i32
  %l279 = alloca i1
  %l281 = alloca ptr
  %l282 = alloca i1
  %l294 = alloca i64
  %l303 = alloca { i64, ptr }
  %l307 = alloca ptr
  %l308 = alloca ptr
  %l311 = alloca ptr
  %l316 = alloca i32
  %l318 = alloca %"compiler/source:Span"
  %l319 = alloca ptr
  %l324 = alloca ptr
  %l329 = alloca i32
  %l334 = alloca i32
  %l335 = alloca i32
  %l336 = alloca %"compiler/source:Span"
  %l337 = alloca i32
  %l338 = alloca i32
  %l342 = alloca { i64, ptr }
  %l347 = alloca %"compiler/typed:Make"
  %l354 = alloca ptr
  %l356 = alloca i1
  %l357 = alloca i1
  %l364 = alloca i32
  %l367 = alloca i32
  %l372 = alloca i32
  %l379 = alloca i1
  %l381 = alloca i1
  %l382 = alloca ptr
  %l383 = alloca i32
  %l386 = alloca i32
  %l387 = alloca i1
  %l388 = alloca ptr
  %l389 = alloca %"compiler/source:Span"
  %l390 = alloca ptr
  %l393 = alloca i32
  %l396 = alloca ptr
  %l397 = alloca i32
  %l402 = alloca i64
  %l403 = alloca i32
  %l405 = alloca ptr
  %l408 = alloca i32
  %l413 = alloca i32
  %l416 = alloca i1
  %l421 = alloca i32
  %l423 = alloca i1
  %l424 = alloca ptr
  %l427 = alloca ptr
  %l430 = alloca i32
  %l431 = alloca i32
  %l436 = alloca i32
  %l437 = alloca i1
  %l438 = alloca ptr
  %l439 = alloca i1
  %l450 = alloca i64
  %l453 = alloca ptr
  %l458 = alloca i32
  %l459 = alloca i64
  %l461 = alloca %"compiler/source:Span"
  %l467 = alloca i32
  %l479 = alloca ptr
  %l482 = alloca i1
  %l484 = alloca i1
  %l487 = alloca i32
  %l490 = alloca i1
  %l491 = alloca i1
  %l494 = alloca ptr
  %l497 = alloca i32
  %l498 = alloca i32
  %l501 = alloca i1
  %l502 = alloca ptr
  %l507 = alloca i32
  %l510 = alloca ptr
  %l513 = alloca i32
  %l514 = alloca i32
  %l515 = alloca i1
  %l516 = alloca ptr
  %l517 = alloca %"compiler/source:Span"
  %l518 = alloca ptr
  %l519 = alloca ptr
  %l522 = alloca i32
  %l524 = alloca ptr
  %l526 = alloca ptr
  %l531 = alloca ptr
  %l534 = alloca i1
  %l537 = alloca i1
  %l538 = alloca ptr
  %l539 = alloca i32
  %l540 = alloca i32
  %l542 = alloca i1
  %l543 = alloca i1
  %l548 = alloca ptr
  %l551 = alloca i1
  %l555 = alloca i1
  %l563 = alloca ptr
  %l573 = alloca i1
  %l578 = alloca i1
  %l579 = alloca i1
  %l585 = alloca ptr
  %l590 = alloca i1
  %l591 = alloca ptr
  %l592 = alloca %"compiler/source:Span"
  %l593 = alloca ptr
  %l596 = alloca i32
  %l597 = alloca { i64, ptr }
  %l598 = alloca { i64, ptr }
  %l601 = alloca { i64, ptr }
  %l603 = alloca %"compiler/msgs:Msg"
  %l604 = alloca i64
  %l608 = alloca ptr
  %l611 = alloca ptr
  %l612 = alloca %"compiler/source:Span"
  %l615 = alloca { i64, ptr }
  %l616 = alloca { i64, ptr }
  %l617 = alloca ptr
  %l622 = alloca i32
  %l623 = alloca { i64, ptr }
  %l625 = alloca %"compiler/msgs:Msg"
  %l626 = alloca i64
  %l630 = alloca ptr
  %l631 = alloca %"compiler/source:Span"
  %l634 = alloca { i64, ptr }
  %l636 = alloca %"compiler/msgs:Msg"
  %l637 = alloca i64
  %l641 = alloca i1
  %l642 = alloca i1
  %l645 = alloca i1
  %l646 = alloca i1
  %l650 = alloca i1
  %l658 = alloca i1
  %l663 = alloca ptr
  %l664 = alloca ptr
  %l665 = alloca %"compiler/source:Span"
  %l668 = alloca { i64, ptr }
  %l669 = alloca { i64, ptr }
  %l672 = alloca { i64, ptr }
  %l673 = alloca { i64, ptr }
  %l676 = alloca { i64, ptr }
  %l678 = alloca %"compiler/msgs:Msg"
  %l679 = alloca i64
  %l680 = alloca ptr
  %l681 = alloca i64
  %l686 = alloca i64
  %l691 = alloca i1
  %l699 = alloca i32
  %l705 = alloca i1
  %l706 = alloca i1
  %l710 = alloca i1
  %l715 = alloca i1
  %l716 = alloca ptr
  %l718 = alloca %"compiler/source:Span"
  %l719 = alloca ptr
  %l721 = alloca %"compiler/source:Span"
  %l722 = alloca { i64, ptr }
  %l725 = alloca { i64, ptr }
  %l726 = alloca { i64, ptr }
  %l727 = alloca ptr
  %l729 = alloca %"compiler/source:Span"
  %l730 = alloca { i64, ptr }
  %l731 = alloca { i64, ptr }
  %l733 = alloca %"compiler/msgs:Msg"
  %l734 = alloca i64
  %l735 = alloca ptr
  %l743 = alloca ptr
  %l746 = alloca ptr
  %l749 = alloca i1
  %l757 = alloca i32
  %l763 = alloca i1
  %l764 = alloca ptr
  %l765 = alloca i1
  %l776 = alloca i1
  %l782 = alloca ptr
  %l785 = alloca %"compiler/source:Span"
  %l786 = alloca i32
  %l787 = alloca ptr
  %l795 = alloca ptr
  %l801 = alloca %"compiler/typed:Try"
  %l806 = alloca ptr
  %l814 = alloca i64
  %l826 = alloca i64
  %l828 = alloca i64
  %l833 = alloca ptr
  %l837 = alloca i1
  %l838 = alloca %"compiler/source:Span"
  %l839 = alloca i32
  %l840 = alloca ptr
  %l844 = alloca i32
  %l845 = alloca %"compiler/typed:Promote"
  %l851 = alloca ptr
  %l852 = alloca i1
  %l861 = alloca i1
  %l862 = alloca %"compiler/source:Span"
  %l863 = alloca i32
  %l864 = alloca ptr
  %l868 = alloca i32
  %l869 = alloca %"compiler/typed:Promote"
  %l882 = alloca i64
  %l888 = alloca %"compiler/source:Span"
  %l891 = alloca i1
  %l894 = alloca i1
  %l895 = alloca ptr
  %l896 = alloca %"compiler/source:Span"
  %l897 = alloca %"compiler/msgs:Msg"
  %l898 = alloca i64
  %l902 = alloca %"compiler/source:Span"
  %l903 = alloca i32
  %l904 = alloca ptr
  %l908 = alloca i32
  %l909 = alloca %"compiler/typed:Promote"
  %l916 = alloca i1
  %l917 = alloca i1
  %l920 = alloca i1
  %l921 = alloca i1
  %l924 = alloca i1
  %l925 = alloca i1
  %l930 = alloca i1
  %l932 = alloca ptr
  %l936 = alloca i1
  %l939 = alloca i1
  %l944 = alloca i32
  %l950 = alloca i64
  %l960 = alloca ptr
  %l961 = alloca %"compiler/source:Span"
  %l962 = alloca %"compiler/source:Span"
  %l965 = alloca ptr
  %l966 = alloca i32
  %l971 = alloca i64
  %l972 = alloca i32
  %l977 = alloca ptr
  %l981 = alloca ptr
  %l990 = alloca ptr
  %l994 = alloca i1
  %l997 = alloca i1
  %l998 = alloca i1
  %l1001 = alloca i1
  %l1007 = alloca %"compiler/source:Span"
  %l1008 = alloca i32
  %l1009 = alloca ptr
  %l1013 = alloca i32
  %l1014 = alloca %"compiler/typed:Promote"
  %l1020 = alloca i1
  %l1027 = alloca i32
  %l1032 = alloca i32
  %l1038 = alloca i1
  %l1039 = alloca i1
  %l1043 = alloca i1
  %l1046 = alloca i1
  %l1047 = alloca i1
  %l1053 = alloca i1
  %l1054 = alloca i1
  %l1059 = alloca i64
  %l1067 = alloca i64
  %l1072 = alloca i64
  %l1074 = alloca ptr
  %l1079 = alloca ptr
  %l1085 = alloca i64
  %l1087 = alloca i64
  %l1092 = alloca i64
  %l1096 = alloca i1
  %l1101 = alloca i64
  %l1105 = alloca i1
  %l1110 = alloca i64
  %l1115 = alloca ptr
  %l1116 = alloca ptr
  %l1117 = alloca %"compiler/source:Span"
  %l1118 = alloca ptr
  %l1121 = alloca ptr
  %l1122 = alloca i32
  %l1127 = alloca i64
  %l1129 = alloca i64
  %l1134 = alloca i64
  %l1138 = alloca i32
  %l1139 = alloca ptr
  %l1142 = alloca ptr
  %l1147 = alloca i64
  %l1151 = alloca i1
  %l1156 = alloca i64
  %l1161 = alloca i1
  %l1162 = alloca ptr
  %l1170 = alloca ptr
  %l1173 = alloca ptr
  %l1174 = alloca %"compiler/source:Span"
  %l1175 = alloca i32
  %l1176 = alloca ptr
  %l1180 = alloca i32
  %l1181 = alloca %"compiler/typed:Promote"
  %l1185 = alloca ptr
  %l1186 = alloca %"compiler/source:Span"
  %l1187 = alloca %"compiler/msgs:Msg"
  %l1188 = alloca i64
  %l1194 = alloca i64
  %l1198 = alloca i1
  %l1202 = alloca i1
  %l1210 = alloca i1
  %l1216 = alloca ptr
  %l1220 = alloca i1
  %l1225 = alloca ptr
  %l1228 = alloca i1
  %l1233 = alloca i32
  %l1243 = alloca i32
  %l1251 = alloca ptr
  %l1254 = alloca i32
  %l1259 = alloca i32
  %l1262 = alloca i1
  %l1267 = alloca i32
  %l1269 = alloca i1
  %l1270 = alloca ptr
  %l1275 = alloca i32
  %l1280 = alloca i32
  %l1281 = alloca i1
  %l1284 = alloca ptr
  %l1289 = alloca i32
  %l1290 = alloca i32
  %l1293 = alloca ptr
  %l1294 = alloca %"compiler/source:Span"
  %l1297 = alloca ptr
  %l1302 = alloca i32
  %l1303 = alloca i64
  %l1304 = alloca %"compiler/msgs:Msg"
  %l1305 = alloca i64
  %l1309 = alloca i64
  %l1313 = alloca %"compiler/source:Span"
  %l1314 = alloca i32
  %l1315 = alloca i32
  %l1316 = alloca i32
  %l1320 = alloca { i64, ptr }
  %l1325 = alloca i1
  %l1328 = alloca i1
  %l1331 = alloca ptr
  %l1336 = alloca i32
  %l1341 = alloca i32
  %l1342 = alloca i1
  %l1343 = alloca i1
  %l1346 = alloca ptr
  %l1351 = alloca i32
  %l1352 = alloca i32
  %l1355 = alloca i1
  %l1358 = alloca ptr
  %l1363 = alloca i32
  %l1364 = alloca i32
  %l1367 = alloca ptr
  %l1368 = alloca %"compiler/source:Span"
  %l1371 = alloca ptr
  %l1376 = alloca i32
  %l1377 = alloca i64
  %l1380 = alloca ptr
  %l1385 = alloca i32
  %l1386 = alloca i64
  %l1387 = alloca %"compiler/msgs:Msg"
  %l1388 = alloca i64
  %l1390 = alloca ptr
  %l1391 = alloca %"compiler/source:Span"
  %l1394 = alloca { i64, ptr }
  %l1395 = alloca { i64, ptr }
  %l1398 = alloca { i64, ptr }
  %l1400 = alloca %"compiler/msgs:Msg"
  %l1401 = alloca i64
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s29 = alloca %olang.scope
  %s31 = alloca %olang.scope
  %s32 = alloca %olang.scope
  %s33 = alloca %olang.scope
  %s37 = alloca %olang.scope
  %s53 = alloca %olang.scope
  %s64 = alloca %olang.scope
  %s72 = alloca %olang.scope
  %s73 = alloca %olang.scope
  %rv = alloca ptr
  %t647 = alloca { i64, [5 x i64] }, align 8
  %t912 = alloca { i64, [5 x i64] }, align 8
  %t932 = alloca { i64, [4 x i64] }, align 8
  %t1519 = alloca { i64, [4 x i64] }, align 8
  %t1665 = alloca { i64, [5 x i64] }, align 8
  %t1758 = alloca { i64, [5 x i64] }, align 8
  %t1815 = alloca { i64, [5 x i64] }, align 8
  %t1831 = alloca { i64, [5 x i64] }, align 8
  %t1906 = alloca { i64, [5 x i64] }, align 8
  %t2036 = alloca { i64, [5 x i64] }, align 8
  %t2104 = alloca { i64, [5 x i64] }, align 8
  %t2131 = alloca { i64, [5 x i64] }, align 8
  %t2448 = alloca { i64, [4 x i64] }, align 8
  %t2486 = alloca { i64, [5 x i64] }, align 8
  %t2625 = alloca { i64, [4 x i64] }, align 8
  %t2778 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t4 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t1)
  store i32 %t4, ptr %l53
  br label %bb1
bb1:
  %t5 = load i32, ptr %l53, !tbaa !23
  store i32 %t5, ptr %l4, !tbaa !23
  %t6 = load i32, ptr %l2, !tbaa !23
  %t7 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t10 = icmp eq i32 %t6, %t7
  br i1 %t10, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l57, !tbaa !21
  br label %bb4
bb3:
  %t12 = load i32, ptr %l4, !tbaa !23
  %t13 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t16 = icmp eq i32 %t12, %t13
  store i1 %t16, ptr %l57, !tbaa !21
  br label %bb4
bb4:
  %t18 = load i1, ptr %l57, !tbaa !21
  br i1 %t18, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l61, !tbaa !21
  br label %bb7
bb6:
  %t19 = load i32, ptr %l2, !tbaa !23
  %t20 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t23 = icmp eq i32 %t19, %t20
  store i1 %t23, ptr %l61, !tbaa !21
  br label %bb7
bb7:
  %t25 = load i1, ptr %l61, !tbaa !21
  br i1 %t25, label %bb8, label %bb9
bb8:
  %t26 = load ptr, ptr %l1, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t26, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load i32, ptr %l2, !tbaa !23
  %t32 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t28, i32 %t29)
  store i32 %t32, ptr %l68
  br label %bb11
bb11:
  %t33 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t34 = load i32, ptr %l68, !tbaa !23
  %t36 = icmp eq i32 %t34, %t33
  br i1 %t36, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l71, !tbaa !21
  br label %bb15
bb13:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load i32, ptr %l4, !tbaa !23
  %t42 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t38, i32 %t39)
  store i32 %t42, ptr %l74
  br label %bb14
bb14:
  %t43 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t44 = load i32, ptr %l74, !tbaa !23
  %t46 = icmp eq i32 %t44, %t43
  store i1 %t46, ptr %l71, !tbaa !21
  br label %bb15
bb15:
  %t48 = load i1, ptr %l71, !tbaa !21
  br i1 %t48, label %bb16, label %bb17
bb16:
  %t49 = load ptr, ptr %l1, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t49, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  %t51 = load i32, ptr %l4, !tbaa !23
  %t52 = load i32, ptr %l2, !tbaa !23
  %t55 = icmp ne i32 %t51, %t52
  br i1 %t55, label %bb19, label %bb20
bb19:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/check:Checker", ptr %t57, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t62 = getelementptr %"compiler/generic:Program", ptr %t60, i32 0, i32 2
  %t63 = load i32, ptr %l4, !tbaa !23
  %t64 = load i32, ptr %l2, !tbaa !23
  %t68 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t62, i32 %t63, i32 %t64)
  store i1 %t68, ptr %l87
  br label %bb21
bb20:
  store i1 false, ptr %l81, !tbaa !21
  br label %bb22
bb21:
  %t69 = load i1, ptr %l87, !tbaa !21
  store i1 %t69, ptr %l81, !tbaa !21
  br label %bb22
bb22:
  %t70 = load i1, ptr %l81, !tbaa !21
  br i1 %t70, label %bb23, label %bb24
bb23:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/check:Checker", ptr %t71, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !29
  %t76 = getelementptr %"compiler/generic:Program", ptr %t74, i32 0, i32 2
  %t77 = load i32, ptr %l4, !tbaa !23
  %t78 = load i32, ptr %l2, !tbaa !23
  %t82 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesFit(ptr %v0, ptr %t76, i32 %t77, i32 %t78)
  store i1 %t82, ptr %l94
  br label %bb25
bb24:
  store i1 false, ptr %l88, !tbaa !21
  br label %bb26
bb25:
  %t83 = load i1, ptr %l94, !tbaa !21
  %t84 = xor i1 %t83, true
  store i1 %t84, ptr %l88, !tbaa !21
  br label %bb26
bb26:
  %t86 = load i1, ptr %l88, !tbaa !21
  br i1 %t86, label %bb27, label %bb28
bb27:
  store %olang.scope zeroinitializer, ptr %s3
  %t87 = load ptr, ptr %l0, !tbaa !29
  store ptr %t87, ptr %l96, !tbaa !29
  %t88 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t88, ptr %l97
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t90 = load i32, ptr %l2, !tbaa !23
  %t93 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s3, ptr %t89, i32 %t90)
  store { i64, ptr } %t93, ptr %l100
  br label %bb29
bb28:
  br label %bb37
bb29:
  %t94 = load { i64, ptr }, ptr %l100, !tbaa !27
  %t95 = extractvalue { i64, ptr } %t94, 0
  %t96 = extractvalue { i64, ptr } %t94, 1
  %t97 = mul i64 %t95, 1
  %t98 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t97)
  call void @llvm.memcpy.p0.p0.i64(ptr %t98, ptr %t96, i64 %t97, i1 false)
  %t99 = insertvalue { i64, ptr } undef, i64 %t95, 0
  %t100 = insertvalue { i64, ptr } %t99, ptr %t98, 1
  store { i64, ptr } %t100, ptr %l101, !tbaa !27
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t102 = load i32, ptr %l4, !tbaa !23
  %t105 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s3, ptr %t101, i32 %t102)
  store { i64, ptr } %t105, ptr %l104
  br label %bb30
bb30:
  %t106 = load { i64, ptr }, ptr %l104, !tbaa !27
  %t107 = extractvalue { i64, ptr } %t106, 0
  %t108 = extractvalue { i64, ptr } %t106, 1
  %t109 = mul i64 %t107, 1
  %t110 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t109)
  call void @llvm.memcpy.p0.p0.i64(ptr %t110, ptr %t108, i64 %t109, i1 false)
  %t111 = insertvalue { i64, ptr } undef, i64 %t107, 0
  %t112 = insertvalue { i64, ptr } %t111, ptr %t110, 1
  %t113 = load { i64, ptr }, ptr %l101, !tbaa !27
  %t115 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeMismatch(ptr %s3, ptr %s3, ptr %s3, { i64, ptr } %t113, { i64, ptr } %t112)
  store %"compiler/msgs:Msg" %t115, ptr %l106
  br label %bb31
bb31:
  %t116 = load ptr, ptr %l96, !tbaa !29
  %t117 = load %"compiler/source:Span", ptr %l97
  %t118 = load %"compiler/msgs:Msg", ptr %l106
  %t119 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s3, ptr %t116, %"compiler/source:Span" %t117, %"compiler/msgs:Msg" %t118)
  store i64 %t119, ptr %l107
  br label %bb32
bb32:
  %t120 = load i64, ptr %l107, !tbaa !24
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"compiler/check:Checker", ptr %t121, i32 0, i32 1
  %t124 = load ptr, ptr %t123, !tbaa !29
  %t126 = getelementptr %"compiler/generic:Program", ptr %t124, i32 0, i32 0
  %t127 = load ptr, ptr %t126, !tbaa !29
  %t129 = getelementptr %"compiler/load:Loader", ptr %t127, i32 0, i32 4
  %t130 = load ptr, ptr %t129, !tbaa !29
  store ptr %t130, ptr %l111, !tbaa !29
  store i64 %t120, ptr %l112, !tbaa !24
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t133 = load %"compiler/source:Span", ptr %l3
  %t136 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %t132, %"compiler/source:Span" %t133)
  store { i64, [3 x i64] } %t136, ptr %l115
  br label %bb33
bb33:
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t138 = load i32, ptr %l4, !tbaa !23
  %t141 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s3, ptr %t137, i32 %t138)
  store { i64, ptr } %t141, ptr %l118
  br label %bb34
bb34:
  %t142 = load { i64, ptr }, ptr %l118, !tbaa !27
  %t143 = extractvalue { i64, ptr } %t142, 0
  %t144 = extractvalue { i64, ptr } %t142, 1
  %t145 = mul i64 %t143, 1
  %t146 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t145)
  call void @llvm.memcpy.p0.p0.i64(ptr %t146, ptr %t144, i64 %t145, i1 false)
  %t147 = insertvalue { i64, ptr } undef, i64 %t143, 0
  %t148 = insertvalue { i64, ptr } %t147, ptr %t146, 1
  %t150 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteFuncTypeScopes(ptr %s3, ptr %s3, { i64, ptr } %t148)
  store %"compiler/msgs:Msg" %t150, ptr %l120
  br label %bb35
bb35:
  %t151 = load ptr, ptr %l111, !tbaa !29
  %t152 = load i64, ptr %l112, !tbaa !24
  %t153 = load { i64, [3 x i64] }, ptr %l115
  %t154 = load %"compiler/msgs:Msg", ptr %l120
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %s3, ptr %t151, i64 %t152, { i64, [3 x i64] } %t153, %"compiler/msgs:Msg" %t154)
  br label %bb36
bb36:
  %t155 = load ptr, ptr %l1, !tbaa !29
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t155, ptr %rv
  br label %ret
bb37:
  %t157 = load i32, ptr %l4, !tbaa !23
  %t158 = load i32, ptr %l2, !tbaa !23
  %t161 = icmp eq i32 %t157, %t158
  br i1 %t161, label %bb38, label %bb39
bb38:
  store i1 true, ptr %l125, !tbaa !21
  br label %bb41
bb39:
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t165 = getelementptr %"compiler/check:Checker", ptr %t163, i32 0, i32 1
  %t166 = load ptr, ptr %t165, !tbaa !29
  %t168 = getelementptr %"compiler/generic:Program", ptr %t166, i32 0, i32 2
  %t169 = load i32, ptr %l4, !tbaa !23
  %t170 = load i32, ptr %l2, !tbaa !23
  %t174 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t168, i32 %t169, i32 %t170)
  store i1 %t174, ptr %l131
  br label %bb40
bb40:
  %t175 = load i1, ptr %l131, !tbaa !21
  store i1 %t175, ptr %l125, !tbaa !21
  br label %bb41
bb41:
  %t176 = load i1, ptr %l125, !tbaa !21
  br i1 %t176, label %bb42, label %bb43
bb42:
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t178 = load i32, ptr %l2, !tbaa !23
  %t181 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t177, i32 %t178)
  store i1 %t181, ptr %l134
  br label %bb44
bb43:
  br label %bb53
bb44:
  %t182 = load i1, ptr %l134, !tbaa !21
  br i1 %t182, label %bb45, label %bb46
bb45:
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t185 = getelementptr %"compiler/check:Checker", ptr %t183, i32 0, i32 1
  %t186 = load ptr, ptr %t185, !tbaa !29
  %t188 = getelementptr %"compiler/generic:Program", ptr %t186, i32 0, i32 2
  %t189 = load i32, ptr %l2, !tbaa !23
  %t192 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t188, i32 %t189)
  store i64 %t192, ptr %l140
  br label %bb47
bb46:
  store i1 false, ptr %l135, !tbaa !21
  br label %bb48
bb47:
  %t193 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t194 = load i64, ptr %l140, !tbaa !24
  %t196 = and i64 %t194, %t193
  %t198 = icmp ne i64 %t196, 0
  store i1 %t198, ptr %l135, !tbaa !21
  br label %bb48
bb48:
  %t200 = load i1, ptr %l135, !tbaa !21
  br i1 %t200, label %bb49, label %bb50
bb49:
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t202 = load ptr, ptr %l1, !tbaa !29
  %t203 = load %"compiler/source:Span", ptr %l3
  %t207 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroWritableRef(ptr %v0, ptr %v0, ptr %t201, ptr %t202, %"compiler/source:Span" %t203)
  store i1 %t207, ptr %l147
  br label %bb51
bb50:
  br label %bb52
bb51:
  br label %bb52
bb52:
  %t208 = load ptr, ptr %l1, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t208, ptr %rv
  br label %ret
bb53:
  %t210 = load i32, ptr %l4, !tbaa !23
  %t211 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t214 = icmp eq i32 %t210, %t211
  br i1 %t214, label %bb54, label %bb55
bb54:
  %t216 = load ptr, ptr %l1, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t216, ptr %rv
  br label %ret
bb55:
  br label %bb56
bb56:
  %t218 = load ptr, ptr %l0, !tbaa !29
  %t220 = getelementptr %"compiler/check:Checker", ptr %t218, i32 0, i32 1
  %t221 = load ptr, ptr %t220, !tbaa !29
  %t223 = getelementptr %"compiler/generic:Program", ptr %t221, i32 0, i32 2
  %t224 = load i32, ptr %l4, !tbaa !23
  %t227 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t223, i32 %t224)
  store i32 %t227, ptr %l157
  br label %bb57
bb57:
  %t228 = load i32, ptr %l157
  store i32 %t228, ptr %l6
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t231 = getelementptr %"compiler/check:Checker", ptr %t229, i32 0, i32 1
  %t232 = load ptr, ptr %t231, !tbaa !29
  %t234 = getelementptr %"compiler/generic:Program", ptr %t232, i32 0, i32 2
  %t235 = load i32, ptr %l2, !tbaa !23
  %t238 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t234, i32 %t235)
  store i32 %t238, ptr %l162
  br label %bb58
bb58:
  %t239 = load i32, ptr %l162
  store i32 %t239, ptr %l7
  %t240 = load i32, ptr %l6
  %t242 = trunc i64 20 to i32
  %t243 = icmp eq i32 %t240, %t242
  br i1 %t243, label %bb59, label %bb60
bb59:
  %t245 = load i32, ptr %l7
  %t247 = trunc i64 20 to i32
  %t248 = icmp eq i32 %t245, %t247
  store i1 %t248, ptr %l165, !tbaa !21
  br label %bb61
bb60:
  store i1 false, ptr %l165, !tbaa !21
  br label %bb61
bb61:
  %t250 = load i1, ptr %l165, !tbaa !21
  br i1 %t250, label %bb62, label %bb63
bb62:
  %t251 = load ptr, ptr %l0, !tbaa !29
  %t253 = getelementptr %"compiler/check:Checker", ptr %t251, i32 0, i32 1
  %t254 = load ptr, ptr %t253, !tbaa !29
  %t256 = getelementptr %"compiler/generic:Program", ptr %t254, i32 0, i32 2
  %t257 = load i32, ptr %l4, !tbaa !23
  %t260 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %t256, i32 %t257)
  store i1 %t260, ptr %l173
  br label %bb64
bb63:
  store i1 false, ptr %l168, !tbaa !21
  br label %bb66
bb64:
  %t261 = load ptr, ptr %l0, !tbaa !29
  %t263 = getelementptr %"compiler/check:Checker", ptr %t261, i32 0, i32 1
  %t264 = load ptr, ptr %t263, !tbaa !29
  %t266 = getelementptr %"compiler/generic:Program", ptr %t264, i32 0, i32 2
  %t267 = load i32, ptr %l2, !tbaa !23
  %t270 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %t266, i32 %t267)
  store i1 %t270, ptr %l178
  br label %bb65
bb65:
  %t271 = load i1, ptr %l173, !tbaa !21
  %t272 = load i1, ptr %l178, !tbaa !21
  %t273 = icmp ne i1 %t271, %t272
  store i1 %t273, ptr %l168, !tbaa !21
  br label %bb66
bb66:
  %t275 = load i1, ptr %l168, !tbaa !21
  br i1 %t275, label %bb67, label %bb68
bb67:
  %t276 = load ptr, ptr %l0, !tbaa !29
  %t278 = getelementptr %"compiler/check:Checker", ptr %t276, i32 0, i32 1
  %t279 = load ptr, ptr %t278, !tbaa !29
  %t281 = getelementptr %"compiler/generic:Program", ptr %t279, i32 0, i32 2
  %t282 = load i32, ptr %l4, !tbaa !23
  %t285 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %t281, i32 %t282)
  store i1 %t285, ptr %l184
  br label %bb69
bb68:
  br label %bb84
bb69:
  %t286 = load i1, ptr %l184, !tbaa !21
  br i1 %t286, label %bb70, label %bb71
bb70:
  store %olang.scope zeroinitializer, ptr %s8
  %t287 = load ptr, ptr %l1, !tbaa !29
  %t289 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %t287)
  store %"compiler/source:Span" %t289, ptr %l186
  br label %bb72
bb71:
  br label %bb80
bb72:
  %t290 = load %"compiler/source:Span", ptr %l186
  store %"compiler/source:Span" %t290, ptr %l8
  %t291 = load ptr, ptr %l0, !tbaa !29
  store ptr %t291, ptr %l187, !tbaa !29
  %t292 = load %"compiler/source:Span", ptr %l8
  store %"compiler/source:Span" %t292, ptr %l188
  %t293 = load ptr, ptr %l0, !tbaa !29
  %t294 = load %"compiler/source:Span", ptr %l8
  %t297 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %t293, %"compiler/source:Span" %t294)
  store { i64, ptr } %t297, ptr %l191
  br label %bb73
bb73:
  %t298 = load ptr, ptr %l0, !tbaa !29
  %t299 = load i32, ptr %l4, !tbaa !23
  %t302 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s8, ptr %t298, i32 %t299)
  store { i64, ptr } %t302, ptr %l194
  br label %bb74
bb74:
  %t303 = load { i64, ptr }, ptr %l194, !tbaa !27
  %t304 = extractvalue { i64, ptr } %t303, 0
  %t305 = extractvalue { i64, ptr } %t303, 1
  %t306 = mul i64 %t304, 1
  %t307 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t306)
  call void @llvm.memcpy.p0.p0.i64(ptr %t307, ptr %t305, i64 %t306, i1 false)
  %t308 = insertvalue { i64, ptr } undef, i64 %t304, 0
  %t309 = insertvalue { i64, ptr } %t308, ptr %t307, 1
  store { i64, ptr } %t309, ptr %l195, !tbaa !27
  %t310 = load ptr, ptr %l0, !tbaa !29
  %t311 = load i32, ptr %l2, !tbaa !23
  %t314 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s8, ptr %t310, i32 %t311)
  store { i64, ptr } %t314, ptr %l198
  br label %bb75
bb75:
  %t315 = load { i64, ptr }, ptr %l198, !tbaa !27
  %t316 = extractvalue { i64, ptr } %t315, 0
  %t317 = extractvalue { i64, ptr } %t315, 1
  %t318 = mul i64 %t316, 1
  %t319 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t318)
  call void @llvm.memcpy.p0.p0.i64(ptr %t319, ptr %t317, i64 %t318, i1 false)
  %t320 = insertvalue { i64, ptr } undef, i64 %t316, 0
  %t321 = insertvalue { i64, ptr } %t320, ptr %t319, 1
  store { i64, ptr } %t321, ptr %l199, !tbaa !27
  %t322 = load ptr, ptr %l0, !tbaa !29
  %t323 = load %"compiler/source:Span", ptr %l8
  %t326 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %t322, %"compiler/source:Span" %t323)
  store { i64, ptr } %t326, ptr %l202
  br label %bb76
bb76:
  %t327 = load { i64, ptr }, ptr %l202, !tbaa !27
  %t328 = call { i64, ptr } @compiler_2fcheck_2ebangOf(ptr %v0, ptr %s8, { i64, ptr } %t327)
  store { i64, ptr } %t328, ptr %l203
  br label %bb77
bb77:
  %t329 = load { i64, ptr }, ptr %l203, !tbaa !27
  %t330 = extractvalue { i64, ptr } %t329, 0
  %t331 = extractvalue { i64, ptr } %t329, 1
  %t332 = mul i64 %t330, 1
  %t333 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t332)
  call void @llvm.memcpy.p0.p0.i64(ptr %t333, ptr %t331, i64 %t332, i1 false)
  %t334 = insertvalue { i64, ptr } undef, i64 %t330, 0
  %t335 = insertvalue { i64, ptr } %t334, ptr %t333, 1
  %t336 = load { i64, ptr }, ptr %l191, !tbaa !27
  %t337 = load { i64, ptr }, ptr %l195, !tbaa !27
  %t338 = load { i64, ptr }, ptr %l199, !tbaa !27
  %t340 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eMayBeNull(ptr %v0, ptr %s8, ptr %s8, ptr %s8, ptr %s8, { i64, ptr } %t336, { i64, ptr } %t337, { i64, ptr } %t338, { i64, ptr } %t335)
  store %"compiler/msgs:Msg" %t340, ptr %l205
  br label %bb78
bb78:
  %t341 = load ptr, ptr %l187, !tbaa !29
  %t342 = load %"compiler/source:Span", ptr %l188
  %t343 = load %"compiler/msgs:Msg", ptr %l205
  %t344 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s8, ptr %t341, %"compiler/source:Span" %t342, %"compiler/msgs:Msg" %t343)
  store i64 %t344, ptr %l206
  br label %bb79
bb79:
  %t345 = load ptr, ptr %l1, !tbaa !29
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t345, ptr %rv
  br label %ret
bb80:
  %t347 = load ptr, ptr %l0, !tbaa !29
  store ptr %t347, ptr %l208, !tbaa !29
  %t348 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t348, ptr %l209
  %t349 = load ptr, ptr %l0, !tbaa !29
  store ptr %t349, ptr %l210, !tbaa !29
  %t350 = load ptr, ptr %l1, !tbaa !29
  store ptr %t350, ptr %l211, !tbaa !29
  %t351 = load ptr, ptr %l0, !tbaa !29
  %t353 = getelementptr %"compiler/check:Checker", ptr %t351, i32 0, i32 1
  %t354 = load ptr, ptr %t353, !tbaa !29
  %t356 = getelementptr %"compiler/generic:Program", ptr %t354, i32 0, i32 2
  %t357 = load i32, ptr %l2, !tbaa !23
  %t360 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNonNull(ptr %v0, ptr %t356, i32 %t357)
  store i32 %t360, ptr %l216
  br label %bb81
bb81:
  %t361 = load %"compiler/source:Span", ptr %l3
  %t362 = load ptr, ptr %l210, !tbaa !29
  %t363 = load ptr, ptr %l211, !tbaa !29
  %t364 = load i32, ptr %l216, !tbaa !23
  %t366 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %t362, ptr %t363, i32 %t364, %"compiler/source:Span" %t361)
  store ptr %t366, ptr %l218
  br label %bb82
bb82:
  %t367 = load i32, ptr %l2, !tbaa !23
  %t368 = load ptr, ptr %l208, !tbaa !29
  %t369 = load %"compiler/source:Span", ptr %l209
  %t370 = load ptr, ptr %l218, !tbaa !29
  %t372 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %t368, %"compiler/source:Span" %t369, ptr %t370, i32 %t367)
  store ptr %t372, ptr %l220
  br label %bb83
bb83:
  call void @__olang_scope_close(ptr %s0)
  %t373 = load ptr, ptr %l220, !tbaa !29
  store ptr %t373, ptr %rv
  br label %ret
bb84:
  %t374 = load ptr, ptr %l0, !tbaa !29
  %t376 = getelementptr %"compiler/check:Checker", ptr %t374, i32 0, i32 1
  %t377 = load ptr, ptr %t376, !tbaa !29
  %t379 = getelementptr %"compiler/generic:Program", ptr %t377, i32 0, i32 2
  %t380 = load i32, ptr %l2, !tbaa !23
  %t383 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsAny(ptr %v0, ptr %t379, i32 %t380)
  store i1 %t383, ptr %l225
  br label %bb85
bb85:
  %t384 = load i1, ptr %l225, !tbaa !21
  br i1 %t384, label %bb86, label %bb87
bb86:
  %t385 = load i32, ptr %l4, !tbaa !23
  %t386 = load i32, ptr @G_2ecompiler_2ftypes_2eNullT, !tbaa !23
  %t389 = icmp ne i32 %t385, %t386
  store i1 %t389, ptr %l226, !tbaa !21
  br label %bb88
bb87:
  store i1 false, ptr %l226, !tbaa !21
  br label %bb88
bb88:
  %t391 = load i1, ptr %l226, !tbaa !21
  br i1 %t391, label %bb89, label %bb90
bb89:
  %t392 = load ptr, ptr %l0, !tbaa !29
  %t394 = getelementptr %"compiler/check:Checker", ptr %t392, i32 0, i32 1
  %t395 = load ptr, ptr %t394, !tbaa !29
  %t397 = getelementptr %"compiler/generic:Program", ptr %t395, i32 0, i32 2
  %t398 = load i32, ptr %l4, !tbaa !23
  %t401 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsAny(ptr %v0, ptr %t397, i32 %t398)
  store i1 %t401, ptr %l235
  br label %bb91
bb90:
  store i1 false, ptr %l230, !tbaa !21
  br label %bb98
bb91:
  %t402 = load i1, ptr %l235, !tbaa !21
  br i1 %t402, label %bb92, label %bb93
bb92:
  %t403 = load ptr, ptr %l0, !tbaa !29
  %t405 = getelementptr %"compiler/check:Checker", ptr %t403, i32 0, i32 1
  %t406 = load ptr, ptr %t405, !tbaa !29
  %t408 = getelementptr %"compiler/generic:Program", ptr %t406, i32 0, i32 2
  store ptr %t408, ptr %l239, !tbaa !29
  %t409 = load ptr, ptr %l0, !tbaa !29
  %t411 = getelementptr %"compiler/check:Checker", ptr %t409, i32 0, i32 1
  %t412 = load ptr, ptr %t411, !tbaa !29
  %t414 = getelementptr %"compiler/generic:Program", ptr %t412, i32 0, i32 2
  %t415 = load i32, ptr %l4, !tbaa !23
  %t418 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t414, i32 %t415)
  store i32 %t418, ptr %l244
  br label %bb94
bb93:
  store i1 false, ptr %l236, !tbaa !21
  br label %bb97
bb94:
  %t419 = load ptr, ptr %l0, !tbaa !29
  %t421 = getelementptr %"compiler/check:Checker", ptr %t419, i32 0, i32 1
  %t422 = load ptr, ptr %t421, !tbaa !29
  %t424 = getelementptr %"compiler/generic:Program", ptr %t422, i32 0, i32 2
  %t425 = load i32, ptr %l2, !tbaa !23
  %t428 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t424, i32 %t425)
  store i32 %t428, ptr %l249
  br label %bb95
bb95:
  %t429 = load ptr, ptr %l239, !tbaa !29
  %t430 = load i32, ptr %l244, !tbaa !23
  %t431 = load i32, ptr %l249, !tbaa !23
  %t432 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t429, i32 %t430, i32 %t431)
  store i1 %t432, ptr %l250
  br label %bb96
bb96:
  %t433 = load i1, ptr %l250, !tbaa !21
  store i1 %t433, ptr %l236, !tbaa !21
  br label %bb97
bb97:
  %t434 = load i1, ptr %l236, !tbaa !21
  %t435 = xor i1 %t434, true
  store i1 %t435, ptr %l230, !tbaa !21
  br label %bb98
bb98:
  %t437 = load i1, ptr %l230, !tbaa !21
  br i1 %t437, label %bb99, label %bb100
bb99:
  %t438 = load ptr, ptr %l0, !tbaa !29
  %t439 = load ptr, ptr %l1, !tbaa !29
  %t440 = load i32, ptr %l2, !tbaa !23
  %t441 = load %"compiler/source:Span", ptr %l3
  %t446 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etoAny(ptr %v0, ptr %t438, ptr %t439, i32 %t440, %"compiler/source:Span" %t441)
  store ptr %t446, ptr %l256
  br label %bb101
bb100:
  br label %bb102
bb101:
  call void @__olang_scope_close(ptr %s0)
  %t447 = load ptr, ptr %l256, !tbaa !29
  store ptr %t447, ptr %rv
  br label %ret
bb102:
  %t448 = load i32, ptr %l6
  %t450 = trunc i64 19 to i32
  %t451 = icmp eq i32 %t448, %t450
  br i1 %t451, label %bb103, label %bb104
bb103:
  %t453 = load ptr, ptr %l0, !tbaa !29
  %t454 = load i32, ptr %l2, !tbaa !23
  %t457 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayOf(ptr %v0, ptr %t453, i32 %t454)
  store i32 %t457, ptr %l261
  br label %bb105
bb104:
  br label %bb143
bb105:
  %t458 = load i32, ptr %l261, !tbaa !23
  store i32 %t458, ptr %l9, !tbaa !23
  %t459 = load i32, ptr %l9, !tbaa !23
  %t460 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t463 = icmp ne i32 %t459, %t460
  br i1 %t463, label %bb106, label %bb107
bb106:
  %t465 = load ptr, ptr %l0, !tbaa !29
  %t467 = getelementptr %"compiler/check:Checker", ptr %t465, i32 0, i32 1
  %t468 = load ptr, ptr %t467, !tbaa !29
  %t470 = getelementptr %"compiler/generic:Program", ptr %t468, i32 0, i32 2
  store ptr %t470, ptr %l268, !tbaa !29
  %t471 = load ptr, ptr %l0, !tbaa !29
  %t473 = getelementptr %"compiler/check:Checker", ptr %t471, i32 0, i32 1
  %t474 = load ptr, ptr %t473, !tbaa !29
  %t476 = getelementptr %"compiler/generic:Program", ptr %t474, i32 0, i32 2
  %t477 = load i32, ptr %l4, !tbaa !23
  %t480 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t476, i32 %t477)
  store i32 %t480, ptr %l273
  br label %bb108
bb107:
  store i1 false, ptr %l265, !tbaa !21
  br label %bb111
bb108:
  %t481 = load ptr, ptr %l0, !tbaa !29
  %t483 = getelementptr %"compiler/check:Checker", ptr %t481, i32 0, i32 1
  %t484 = load ptr, ptr %t483, !tbaa !29
  %t486 = getelementptr %"compiler/generic:Program", ptr %t484, i32 0, i32 2
  %t487 = load i32, ptr %l9, !tbaa !23
  %t490 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t486, i32 %t487)
  store i32 %t490, ptr %l278
  br label %bb109
bb109:
  %t491 = load ptr, ptr %l268, !tbaa !29
  %t492 = load i32, ptr %l273, !tbaa !23
  %t493 = load i32, ptr %l278, !tbaa !23
  %t494 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t491, i32 %t492, i32 %t493)
  store i1 %t494, ptr %l279
  br label %bb110
bb110:
  %t495 = load i1, ptr %l279, !tbaa !21
  %t496 = xor i1 %t495, true
  store i1 %t496, ptr %l265, !tbaa !21
  br label %bb111
bb111:
  %t498 = load i1, ptr %l265, !tbaa !21
  br i1 %t498, label %bb112, label %bb113
bb112:
  %t499 = load ptr, ptr %l1, !tbaa !29
  store ptr %t499, ptr %l281, !tbaa !29
  store i1 false, ptr %l282, !tbaa !21
  %t500 = load ptr, ptr %l281, !tbaa !29
  %t501 = icmp ne ptr %t500, null
  br i1 %t501, label %bb114, label %bb115
bb113:
  br label %bb142
bb114:
  %t503 = load ptr, ptr %l281, !tbaa !29
  %t504 = load i64, ptr %t503
  %t506 = icmp eq i64 %t504, 7
  store i1 %t506, ptr %l282, !tbaa !21
  br label %bb115
bb115:
  %t507 = load i1, ptr %l282, !tbaa !21
  br i1 %t507, label %bb116, label %bb117
bb116:
  %t508 = load ptr, ptr %l1, !tbaa !29
  %t510 = getelementptr { i64, [5 x i64] }, ptr %t508, i32 0, i32 1
  %t511 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t510, i32 0, i32 0
  %t512 = load %"compiler/source:Span", ptr %t511
  store %"compiler/source:Span" %t512, ptr %l10
  %t514 = load ptr, ptr %l1, !tbaa !29
  %t516 = getelementptr { i64, [5 x i64] }, ptr %t514, i32 0, i32 1
  %t517 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t516, i32 0, i32 2
  %t518 = load ptr, ptr %t517
  store ptr %t518, ptr %l11, !tbaa !29
  br label %bb118
bb117:
  br label %bb140
bb118:
  %t520 = load ptr, ptr %l11, !tbaa !29
  %t522 = getelementptr %"compiler/typed:Make", ptr %t520, i32 0, i32 0
  %t523 = load i32, ptr %t522
  %t525 = trunc i64 2 to i32
  %t526 = icmp eq i32 %t523, %t525
  br i1 %t526, label %bb119, label %bb120
bb119:
  %t528 = load ptr, ptr %l0, !tbaa !29
  %t530 = getelementptr %"compiler/check:Checker", ptr %t528, i32 0, i32 32
  %t532 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t530)
  store i64 %t532, ptr %l294
  br label %bb121
bb120:
  br label %bb139
bb121:
  %t533 = load i64, ptr %l294, !tbaa !24
  store i64 %t533, ptr %l12, !tbaa !24
  %t534 = load ptr, ptr %l11, !tbaa !29
  %t536 = getelementptr %"compiler/typed:Make", ptr %t534, i32 0, i32 2
  %t537 = load { i64, ptr }, ptr %t536, !tbaa !27
  store { i64, ptr } %t537, ptr %l13, !tbaa !27
  store i64 0, ptr %l14, !tbaa !24
  %t539 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t541 = extractvalue { i64, ptr } %t539, 0
  store i64 %t541, ptr %l15, !tbaa !24
  br label %bb122
bb122:
  %t543 = load i64, ptr %l14, !tbaa !24
  %t544 = load i64, ptr %l15, !tbaa !24
  %t547 = icmp slt i64 %t543, %t544
  %t549 = xor i1 %t547, true
  br i1 %t549, label %bb123, label %bb124
bb123:
  br label %bb132
bb124:
  br label %bb125
bb125:
  %t551 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t551, ptr %l303, !tbaa !27
  %t552 = load i64, ptr %l14, !tbaa !24
  %t554 = getelementptr { i64, ptr }, ptr %l303, i32 0, i32 1
  %t555 = load ptr, ptr %t554, !tbaa !27
  %t556 = getelementptr ptr, ptr %t555, i64 %t552
  %t557 = load ptr, ptr %t556, !tbaa !39
  store ptr %t557, ptr %l16, !tbaa !29
  %t559 = load ptr, ptr %l0, !tbaa !29
  %t561 = getelementptr %"compiler/check:Checker", ptr %t559, i32 0, i32 32
  store ptr %t561, ptr %l307, !tbaa !29
  %t562 = load ptr, ptr %l0, !tbaa !29
  store ptr %t562, ptr %l308, !tbaa !29
  %t563 = load ptr, ptr %l0, !tbaa !29
  %t564 = load ptr, ptr %l16, !tbaa !29
  %t567 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunadapted(ptr %v0, ptr %t563, ptr %t564)
  store ptr %t567, ptr %l311
  br label %bb126
bb126:
  %t568 = load ptr, ptr %l0, !tbaa !29
  %t570 = getelementptr %"compiler/check:Checker", ptr %t568, i32 0, i32 1
  %t571 = load ptr, ptr %t570, !tbaa !29
  %t573 = getelementptr %"compiler/generic:Program", ptr %t571, i32 0, i32 2
  %t574 = load i32, ptr %l9, !tbaa !23
  %t577 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t573, i32 %t574)
  store i32 %t577, ptr %l316
  br label %bb127
bb127:
  %t578 = load ptr, ptr %l16, !tbaa !29
  %t580 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %t578)
  store %"compiler/source:Span" %t580, ptr %l318
  br label %bb128
bb128:
  %t581 = load ptr, ptr %l308, !tbaa !29
  %t582 = load ptr, ptr %l311, !tbaa !29
  %t583 = load i32, ptr %l316, !tbaa !23
  %t584 = load %"compiler/source:Span", ptr %l318
  %t585 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %t581, ptr %t582, i32 %t583, %"compiler/source:Span" %t584)
  store ptr %t585, ptr %l319
  br label %bb129
bb129:
  %t586 = load ptr, ptr %l307, !tbaa !29
  %t587 = load ptr, ptr %l319, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t586, ptr %t587)
  br label %bb130
bb130:
  br label %bb131
bb131:
  %t588 = load i64, ptr %l14, !tbaa !24
  %t590 = add i64 %t588, 1
  store i64 %t590, ptr %l14, !tbaa !24
  br label %bb122
bb132:
  %t592 = load ptr, ptr %l0, !tbaa !29
  %t594 = getelementptr %"compiler/check:Checker", ptr %t592, i32 0, i32 1
  %t595 = load ptr, ptr %t594, !tbaa !29
  %t597 = getelementptr %"compiler/generic:Program", ptr %t595, i32 0, i32 2
  store ptr %t597, ptr %l324, !tbaa !29
  %t598 = load ptr, ptr %l0, !tbaa !29
  %t600 = getelementptr %"compiler/check:Checker", ptr %t598, i32 0, i32 1
  %t601 = load ptr, ptr %t600, !tbaa !29
  %t603 = getelementptr %"compiler/generic:Program", ptr %t601, i32 0, i32 2
  %t604 = load i32, ptr %l9, !tbaa !23
  %t607 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t603, i32 %t604)
  store i32 %t607, ptr %l329
  br label %bb133
bb133:
  %t608 = load ptr, ptr %l0, !tbaa !29
  %t610 = getelementptr %"compiler/check:Checker", ptr %t608, i32 0, i32 1
  %t611 = load ptr, ptr %t610, !tbaa !29
  %t613 = getelementptr %"compiler/generic:Program", ptr %t611, i32 0, i32 2
  %t614 = load i32, ptr %l4, !tbaa !23
  %t617 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t613, i32 %t614)
  store i32 %t617, ptr %l334
  br label %bb134
bb134:
  %t618 = load ptr, ptr %l324, !tbaa !29
  %t619 = load i32, ptr %l329, !tbaa !23
  %t620 = load i32, ptr %l334, !tbaa !23
  %t621 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %t618, i32 %t619, i32 %t620)
  store i32 %t621, ptr %l335
  br label %bb135
bb135:
  %t622 = load i32, ptr %l335, !tbaa !23
  %t623 = load %"compiler/source:Span", ptr %l10
  store %"compiler/source:Span" %t623, ptr %l336
  store i32 %t622, ptr %l337, !tbaa !23
  store i32 2, ptr %l338
  %t625 = load ptr, ptr %l0, !tbaa !29
  %t627 = getelementptr %"compiler/check:Checker", ptr %t625, i32 0, i32 32
  %t628 = load i64, ptr %l12, !tbaa !24
  %t631 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t627, i64 %t628)
  store { i64, ptr } %t631, ptr %l342
  br label %bb136
bb136:
  %t632 = load ptr, ptr %l11, !tbaa !29
  %t634 = getelementptr %"compiler/typed:Make", ptr %t632, i32 0, i32 4
  %t635 = load i32, ptr %t634, !tbaa !23
  %t636 = load ptr, ptr %l11, !tbaa !29
  %t638 = getelementptr %"compiler/typed:Make", ptr %t636, i32 0, i32 5
  %t639 = load i32, ptr %t638
  %t640 = load i32, ptr %l338
  %t641 = load { i64, ptr }, ptr %l342, !tbaa !27
  %t644 = call %"compiler/typed:Make" @compiler_2ftyped_3aMake_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t640, i64 0, { i64, ptr } %t641, ptr null, i32 %t635, i32 %t639)
  store %"compiler/typed:Make" %t644, ptr %l347
  br label %bb137
bb137:
  %t645 = load %"compiler/typed:Make", ptr %l347
  %t646 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store %"compiler/typed:Make" %t645, ptr %t646
  store { i64, [5 x i64] } zeroinitializer, ptr %t647
  %t648 = getelementptr { i64, [5 x i64] }, ptr %t647, i32 0, i32 0
  store i64 7, ptr %t648
  %t649 = load %"compiler/source:Span", ptr %l336
  %t650 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t649, 0
  %t651 = load i32, ptr %l337, !tbaa !23
  %t652 = insertvalue { %"compiler/source:Span", i32, ptr } %t650, i32 %t651, 1
  %t654 = insertvalue { %"compiler/source:Span", i32, ptr } %t652, ptr %t646, 2
  %t655 = getelementptr { i64, [5 x i64] }, ptr %t647, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t654, ptr %t655
  %t656 = load { i64, [5 x i64] }, ptr %t647
  %t657 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store ptr %t657, ptr %lp18
  %t659 = load ptr, ptr %lp18
  store { i64, [5 x i64] } %t656, ptr %t659
  %t660 = load ptr, ptr %l0, !tbaa !29
  %t661 = load ptr, ptr %lp18
  %t662 = load i32, ptr %l2, !tbaa !23
  %t663 = load %"compiler/source:Span", ptr %l3
  %t668 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %t660, ptr %t661, i32 %t662, %"compiler/source:Span" %t663)
  store ptr %t668, ptr %l354
  br label %bb138
bb138:
  call void @__olang_scope_close(ptr %s0)
  %t669 = load ptr, ptr %l354, !tbaa !29
  store ptr %t669, ptr %rv
  br label %ret
bb139:
  br label %bb141
bb140:
  br label %bb141
bb141:
  br label %bb142
bb142:
  br label %bb143
bb143:
  %t670 = load ptr, ptr %l1, !tbaa !29
  %t672 = call i1 @compiler_2fcheck_2eisData(ptr %v0, ptr %t670)
  store i1 %t672, ptr %l356
  br label %bb144
bb144:
  %t673 = load i1, ptr %l356, !tbaa !21
  br i1 %t673, label %bb145, label %bb146
bb145:
  %t674 = load i32, ptr %l6
  %t676 = trunc i64 20 to i32
  %t677 = icmp eq i32 %t674, %t676
  store i1 %t677, ptr %l357, !tbaa !21
  br label %bb147
bb146:
  store i1 false, ptr %l357, !tbaa !21
  br label %bb147
bb147:
  %t679 = load i1, ptr %l357, !tbaa !21
  br i1 %t679, label %bb148, label %bb149
bb148:
  %t680 = load ptr, ptr %l0, !tbaa !29
  %t682 = getelementptr %"compiler/check:Checker", ptr %t680, i32 0, i32 1
  %t683 = load ptr, ptr %t682, !tbaa !29
  %t685 = getelementptr %"compiler/generic:Program", ptr %t683, i32 0, i32 2
  %t686 = load i32, ptr %l4, !tbaa !23
  %t689 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t685, i32 %t686)
  store i32 %t689, ptr %l364
  br label %bb150
bb149:
  br label %bb201
bb150:
  %t690 = load i32, ptr %l364, !tbaa !23
  store i32 %t690, ptr %l19, !tbaa !23
  %t691 = load i32, ptr %l7
  %t693 = trunc i64 20 to i32
  %t694 = icmp eq i32 %t691, %t693
  br i1 %t694, label %bb151, label %bb152
bb151:
  %t696 = load ptr, ptr %l0, !tbaa !29
  %t698 = getelementptr %"compiler/check:Checker", ptr %t696, i32 0, i32 1
  %t699 = load ptr, ptr %t698, !tbaa !29
  %t701 = getelementptr %"compiler/generic:Program", ptr %t699, i32 0, i32 2
  %t702 = load i32, ptr %l2, !tbaa !23
  %t705 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t701, i32 %t702)
  store i32 %t705, ptr %l372
  br label %bb153
bb152:
  %t706 = load i32, ptr %l2, !tbaa !23
  store i32 %t706, ptr %l367, !tbaa !23
  br label %bb154
bb153:
  %t708 = load i32, ptr %l372, !tbaa !23
  store i32 %t708, ptr %l367, !tbaa !23
  br label %bb154
bb154:
  %t709 = load i32, ptr %l367, !tbaa !23
  store i32 %t709, ptr %l20, !tbaa !23
  %t710 = load ptr, ptr %l0, !tbaa !29
  %t712 = getelementptr %"compiler/check:Checker", ptr %t710, i32 0, i32 1
  %t713 = load ptr, ptr %t712, !tbaa !29
  %t715 = getelementptr %"compiler/generic:Program", ptr %t713, i32 0, i32 2
  %t716 = load i32, ptr %l19, !tbaa !23
  %t717 = load i32, ptr %l20, !tbaa !23
  %t721 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t715, i32 %t716, i32 %t717)
  store i1 %t721, ptr %l379
  br label %bb155
bb155:
  %t722 = load i1, ptr %l379, !tbaa !21
  %t723 = xor i1 %t722, true
  br i1 %t723, label %bb156, label %bb157
bb156:
  %t725 = load ptr, ptr %l0, !tbaa !29
  store ptr %t725, ptr %l382, !tbaa !29
  %t726 = load i32, ptr %l19, !tbaa !23
  store i32 %t726, ptr %l383, !tbaa !23
  %t727 = load ptr, ptr %l0, !tbaa !29
  %t728 = load i32, ptr %l20, !tbaa !23
  %t731 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t727, i32 %t728)
  store i32 %t731, ptr %l386
  br label %bb158
bb157:
  store i1 false, ptr %l381, !tbaa !21
  br label %bb160
bb158:
  %t732 = load ptr, ptr %l382, !tbaa !29
  %t733 = load i32, ptr %l383, !tbaa !23
  %t734 = load i32, ptr %l386, !tbaa !23
  %t735 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esameRepr(ptr %v0, ptr %t732, i32 %t733, i32 %t734)
  store i1 %t735, ptr %l387
  br label %bb159
bb159:
  %t736 = load i1, ptr %l387, !tbaa !21
  store i1 %t736, ptr %l381, !tbaa !21
  br label %bb160
bb160:
  %t737 = load i1, ptr %l381, !tbaa !21
  br i1 %t737, label %bb161, label %bb162
bb161:
  %t738 = load ptr, ptr %l0, !tbaa !29
  store ptr %t738, ptr %l388, !tbaa !29
  %t739 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t739, ptr %l389
  %t740 = load ptr, ptr %l1, !tbaa !29
  store ptr %t740, ptr %l390, !tbaa !29
  %t741 = load i32, ptr %l7
  %t743 = trunc i64 20 to i32
  %t744 = icmp eq i32 %t741, %t743
  br i1 %t744, label %bb163, label %bb164
bb162:
  br label %bb169
bb163:
  %t746 = load ptr, ptr %l0, !tbaa !29
  %t748 = getelementptr %"compiler/check:Checker", ptr %t746, i32 0, i32 1
  %t749 = load ptr, ptr %t748, !tbaa !29
  %t751 = getelementptr %"compiler/generic:Program", ptr %t749, i32 0, i32 2
  store ptr %t751, ptr %l396, !tbaa !29
  %t752 = load i32, ptr %l20, !tbaa !23
  store i32 %t752, ptr %l397, !tbaa !23
  %t753 = load ptr, ptr %l0, !tbaa !29
  %t755 = getelementptr %"compiler/check:Checker", ptr %t753, i32 0, i32 1
  %t756 = load ptr, ptr %t755, !tbaa !29
  %t758 = getelementptr %"compiler/generic:Program", ptr %t756, i32 0, i32 2
  %t759 = load i32, ptr %l4, !tbaa !23
  %t762 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t758, i32 %t759)
  store i64 %t762, ptr %l402
  br label %bb165
bb164:
  %t763 = load i32, ptr %l20, !tbaa !23
  store i32 %t763, ptr %l393, !tbaa !23
  br label %bb167
bb165:
  %t765 = load ptr, ptr %l396, !tbaa !29
  %t766 = load i32, ptr %l397, !tbaa !23
  %t767 = load i64, ptr %l402, !tbaa !24
  %t768 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t765, i32 %t766, i64 %t767)
  store i32 %t768, ptr %l403
  br label %bb166
bb166:
  %t769 = load i32, ptr %l403, !tbaa !23
  store i32 %t769, ptr %l393, !tbaa !23
  br label %bb167
bb167:
  %t770 = load ptr, ptr %l388, !tbaa !29
  %t771 = load %"compiler/source:Span", ptr %l389
  %t772 = load ptr, ptr %l390, !tbaa !29
  %t773 = load i32, ptr %l393, !tbaa !23
  %t774 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %t770, %"compiler/source:Span" %t771, ptr %t772, i32 %t773)
  store ptr %t774, ptr %l405
  br label %bb168
bb168:
  call void @__olang_scope_close(ptr %s0)
  %t775 = load ptr, ptr %l405, !tbaa !29
  store ptr %t775, ptr %rv
  br label %ret
bb169:
  %t776 = load ptr, ptr %l0, !tbaa !29
  %t777 = load i32, ptr %l20, !tbaa !23
  %t780 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t776, i32 %t777)
  store i32 %t780, ptr %l408
  br label %bb170
bb170:
  %t781 = load i32, ptr %l408, !tbaa !23
  store i32 %t781, ptr %l21, !tbaa !23
  %t782 = load ptr, ptr %l0, !tbaa !29
  %t784 = getelementptr %"compiler/check:Checker", ptr %t782, i32 0, i32 1
  %t785 = load ptr, ptr %t784, !tbaa !29
  %t787 = getelementptr %"compiler/generic:Program", ptr %t785, i32 0, i32 2
  %t788 = load i32, ptr %l21, !tbaa !23
  %t791 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t787, i32 %t788)
  store i32 %t791, ptr %l413
  br label %bb171
bb171:
  %t792 = load i32, ptr %l413
  %t794 = trunc i64 19 to i32
  %t795 = icmp eq i32 %t792, %t794
  br i1 %t795, label %bb172, label %bb173
bb172:
  %t797 = load ptr, ptr %l0, !tbaa !29
  %t799 = getelementptr %"compiler/check:Checker", ptr %t797, i32 0, i32 1
  %t800 = load ptr, ptr %t799, !tbaa !29
  %t802 = getelementptr %"compiler/generic:Program", ptr %t800, i32 0, i32 2
  %t803 = load i32, ptr %l21, !tbaa !23
  %t806 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t802, i32 %t803)
  store i32 %t806, ptr %l421
  br label %bb174
bb173:
  store i1 false, ptr %l416, !tbaa !21
  br label %bb175
bb174:
  %t807 = load i32, ptr %l421, !tbaa !23
  %t808 = icmp ne i32 %t807, 0
  store i1 %t808, ptr %l416, !tbaa !21
  br label %bb175
bb175:
  %t810 = load i1, ptr %l416, !tbaa !21
  br i1 %t810, label %bb176, label %bb177
bb176:
  %t811 = load ptr, ptr %l0, !tbaa !29
  store ptr %t811, ptr %l424, !tbaa !29
  %t812 = load ptr, ptr %l0, !tbaa !29
  %t814 = getelementptr %"compiler/check:Checker", ptr %t812, i32 0, i32 1
  %t815 = load ptr, ptr %t814, !tbaa !29
  %t817 = getelementptr %"compiler/generic:Program", ptr %t815, i32 0, i32 2
  store ptr %t817, ptr %l427, !tbaa !29
  %t818 = load ptr, ptr %l0, !tbaa !29
  %t819 = load i32, ptr %l19, !tbaa !23
  %t822 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t818, i32 %t819)
  store i32 %t822, ptr %l430
  br label %bb178
bb177:
  store i1 false, ptr %l423, !tbaa !21
  br label %bb182
bb178:
  %t823 = load ptr, ptr %l427, !tbaa !29
  %t824 = load i32, ptr %l430, !tbaa !23
  %t825 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t823, i32 %t824)
  store i32 %t825, ptr %l431
  br label %bb179
bb179:
  %t826 = load ptr, ptr %l0, !tbaa !29
  %t828 = getelementptr %"compiler/check:Checker", ptr %t826, i32 0, i32 1
  %t829 = load ptr, ptr %t828, !tbaa !29
  %t831 = getelementptr %"compiler/generic:Program", ptr %t829, i32 0, i32 2
  %t832 = load i32, ptr %l21, !tbaa !23
  %t835 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t831, i32 %t832)
  store i32 %t835, ptr %l436
  br label %bb180
bb180:
  %t836 = load ptr, ptr %l424, !tbaa !29
  %t837 = load i32, ptr %l431, !tbaa !23
  %t838 = load i32, ptr %l436, !tbaa !23
  %t839 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esameRepr(ptr %v0, ptr %t836, i32 %t837, i32 %t838)
  store i1 %t839, ptr %l437
  br label %bb181
bb181:
  %t840 = load i1, ptr %l437, !tbaa !21
  store i1 %t840, ptr %l423, !tbaa !21
  br label %bb182
bb182:
  %t841 = load i1, ptr %l423, !tbaa !21
  br i1 %t841, label %bb183, label %bb184
bb183:
  %t842 = load ptr, ptr %l1, !tbaa !29
  store ptr %t842, ptr %l438, !tbaa !29
  store i1 false, ptr %l439, !tbaa !21
  %t843 = load ptr, ptr %l438, !tbaa !29
  %t844 = icmp ne ptr %t843, null
  br i1 %t844, label %bb185, label %bb186
bb184:
  br label %bb200
bb185:
  %t846 = load ptr, ptr %l438, !tbaa !29
  %t847 = load i64, ptr %t846
  %t849 = icmp eq i64 %t847, 1
  store i1 %t849, ptr %l439, !tbaa !21
  br label %bb186
bb186:
  %t850 = load i1, ptr %l439, !tbaa !21
  br i1 %t850, label %bb187, label %bb188
bb187:
  %t851 = load ptr, ptr %l1, !tbaa !29
  %t853 = getelementptr { i64, [5 x i64] }, ptr %t851, i32 0, i32 1
  %t854 = getelementptr { %"compiler/source:Span", i32, i64, ptr }, ptr %t853, i32 0, i32 0
  %t855 = load %"compiler/source:Span", ptr %t854
  store %"compiler/source:Span" %t855, ptr %l22
  %t857 = load ptr, ptr %l1, !tbaa !29
  %t859 = getelementptr { i64, [5 x i64] }, ptr %t857, i32 0, i32 1
  %t860 = getelementptr { %"compiler/source:Span", i32, i64, ptr }, ptr %t859, i32 0, i32 2
  %t861 = load i64, ptr %t860
  store i64 %t861, ptr %l23, !tbaa !24
  %t863 = load ptr, ptr %l1, !tbaa !29
  %t865 = getelementptr { i64, [5 x i64] }, ptr %t863, i32 0, i32 1
  %t866 = getelementptr { %"compiler/source:Span", i32, i64, ptr }, ptr %t865, i32 0, i32 3
  %t867 = load ptr, ptr %t866
  store ptr %t867, ptr %l24, !tbaa !29
  br label %bb189
bb188:
  br label %bb198
bb189:
  %t869 = load ptr, ptr %l0, !tbaa !29
  %t870 = load ptr, ptr %l1, !tbaa !29
  %t873 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edataLength(ptr %v0, ptr %v0, ptr %t869, ptr %t870)
  store i64 %t873, ptr %l450
  br label %bb190
bb190:
  %t874 = load ptr, ptr %l0, !tbaa !29
  %t876 = getelementptr %"compiler/check:Checker", ptr %t874, i32 0, i32 1
  %t877 = load ptr, ptr %t876, !tbaa !29
  %t879 = getelementptr %"compiler/generic:Program", ptr %t877, i32 0, i32 2
  store ptr %t879, ptr %l453, !tbaa !29
  %t880 = load ptr, ptr %l0, !tbaa !29
  %t882 = getelementptr %"compiler/check:Checker", ptr %t880, i32 0, i32 1
  %t883 = load ptr, ptr %t882, !tbaa !29
  %t885 = getelementptr %"compiler/generic:Program", ptr %t883, i32 0, i32 2
  %t886 = load i32, ptr %l21, !tbaa !23
  %t889 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t885, i32 %t886)
  store i32 %t889, ptr %l458
  br label %bb191
bb191:
  %t890 = load ptr, ptr %l453, !tbaa !29
  %t891 = load i32, ptr %l458, !tbaa !23
  %t892 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %t890, i32 %t891)
  store i64 %t892, ptr %l459
  br label %bb192
bb192:
  %t893 = load i64, ptr %l450, !tbaa !24
  %t894 = load i64, ptr %l459, !tbaa !24
  %t895 = icmp eq i64 %t893, %t894
  br i1 %t895, label %bb193, label %bb194
bb193:
  %t897 = load %"compiler/source:Span", ptr %l22
  store %"compiler/source:Span" %t897, ptr %l461
  %t898 = load ptr, ptr %l0, !tbaa !29
  %t900 = getelementptr %"compiler/check:Checker", ptr %t898, i32 0, i32 1
  %t901 = load ptr, ptr %t900, !tbaa !29
  %t903 = getelementptr %"compiler/generic:Program", ptr %t901, i32 0, i32 2
  %t904 = load i32, ptr %l20, !tbaa !23
  %t905 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t909 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t903, i32 %t904, i64 %t905)
  store i32 %t909, ptr %l467
  br label %bb195
bb194:
  br label %bb197
bb195:
  %t910 = load i64, ptr %l23, !tbaa !24
  %t911 = load ptr, ptr %l24, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t912
  %t913 = getelementptr { i64, [5 x i64] }, ptr %t912, i32 0, i32 0
  store i64 1, ptr %t913
  %t914 = load %"compiler/source:Span", ptr %l461
  %t915 = insertvalue { %"compiler/source:Span", i32, i64, ptr } undef, %"compiler/source:Span" %t914, 0
  %t916 = load i32, ptr %l467, !tbaa !23
  %t917 = insertvalue { %"compiler/source:Span", i32, i64, ptr } %t915, i32 %t916, 1
  %t919 = insertvalue { %"compiler/source:Span", i32, i64, ptr } %t917, i64 %t910, 2
  %t921 = insertvalue { %"compiler/source:Span", i32, i64, ptr } %t919, ptr %t911, 3
  %t922 = getelementptr { i64, [5 x i64] }, ptr %t912, i32 0, i32 1
  store { %"compiler/source:Span", i32, i64, ptr } %t921, ptr %t922
  %t923 = load { i64, [5 x i64] }, ptr %t912
  %t925 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t923, ptr %t925
  %t927 = load ptr, ptr %l0, !tbaa !29
  %t928 = load %"compiler/source:Span", ptr %l3
  %t929 = load %"compiler/source:Span", ptr %l3
  %t930 = load i32, ptr %l20, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t932
  %t933 = getelementptr { i64, [4 x i64] }, ptr %t932, i32 0, i32 0
  store i64 2, ptr %t933
  %t935 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t929, 0
  %t937 = insertvalue { %"compiler/source:Span", i32, ptr } %t935, i32 %t930, 1
  %t939 = insertvalue { %"compiler/source:Span", i32, ptr } %t937, ptr %t925, 2
  %t940 = getelementptr { i64, [4 x i64] }, ptr %t932, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t939, ptr %t940
  %t941 = load { i64, [4 x i64] }, ptr %t932
  %t943 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t941, ptr %t943
  %t947 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t927, %"compiler/source:Span" %t928, ptr %t943)
  store ptr %t947, ptr %l479
  br label %bb196
bb196:
  call void @__olang_scope_close(ptr %s0)
  %t948 = load ptr, ptr %l479, !tbaa !29
  store ptr %t948, ptr %rv
  br label %ret
bb197:
  br label %bb199
bb198:
  br label %bb199
bb199:
  br label %bb200
bb200:
  br label %bb201
bb201:
  %t949 = load i32, ptr %l6
  %t951 = trunc i64 19 to i32
  %t952 = icmp eq i32 %t949, %t951
  br i1 %t952, label %bb202, label %bb203
bb202:
  %t954 = load ptr, ptr %l1, !tbaa !29
  %t956 = call i1 @compiler_2fcheck_2eisArrayMake(ptr %v0, ptr %t954)
  store i1 %t956, ptr %l484
  br label %bb204
bb203:
  store i1 false, ptr %l482, !tbaa !21
  br label %bb205
bb204:
  %t957 = load i1, ptr %l484, !tbaa !21
  store i1 %t957, ptr %l482, !tbaa !21
  br label %bb205
bb205:
  %t958 = load i1, ptr %l482, !tbaa !21
  br i1 %t958, label %bb206, label %bb207
bb206:
  %t959 = load ptr, ptr %l0, !tbaa !29
  %t960 = load i32, ptr %l2, !tbaa !23
  %t963 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t959, i32 %t960)
  store i32 %t963, ptr %l487
  br label %bb208
bb207:
  br label %bb229
bb208:
  %t964 = load i32, ptr %l487, !tbaa !23
  store i32 %t964, ptr %l26, !tbaa !23
  %t965 = load ptr, ptr %l0, !tbaa !29
  %t966 = load i32, ptr %l26, !tbaa !23
  %t969 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisOver(ptr %v0, ptr %t965, i32 %t966)
  store i1 %t969, ptr %l490
  br label %bb209
bb209:
  %t970 = load i1, ptr %l490, !tbaa !21
  br i1 %t970, label %bb210, label %bb211
bb210:
  %t971 = load ptr, ptr %l0, !tbaa !29
  %t973 = getelementptr %"compiler/check:Checker", ptr %t971, i32 0, i32 1
  %t974 = load ptr, ptr %t973, !tbaa !29
  %t976 = getelementptr %"compiler/generic:Program", ptr %t974, i32 0, i32 2
  store ptr %t976, ptr %l494, !tbaa !29
  %t977 = load ptr, ptr %l0, !tbaa !29
  %t978 = load i32, ptr %l26, !tbaa !23
  %t981 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t977, i32 %t978)
  store i32 %t981, ptr %l497
  br label %bb212
bb211:
  store i1 false, ptr %l491, !tbaa !21
  br label %bb214
bb212:
  %t982 = load ptr, ptr %l494, !tbaa !29
  %t983 = load i32, ptr %l497, !tbaa !23
  %t984 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t982, i32 %t983)
  store i32 %t984, ptr %l498
  br label %bb213
bb213:
  %t985 = load i32, ptr %l498
  %t987 = trunc i64 19 to i32
  %t988 = icmp eq i32 %t985, %t987
  store i1 %t988, ptr %l491, !tbaa !21
  br label %bb214
bb214:
  %t990 = load i1, ptr %l491, !tbaa !21
  br i1 %t990, label %bb215, label %bb216
bb215:
  %t991 = load ptr, ptr %l0, !tbaa !29
  store ptr %t991, ptr %l502, !tbaa !29
  %t992 = load ptr, ptr %l0, !tbaa !29
  %t994 = getelementptr %"compiler/check:Checker", ptr %t992, i32 0, i32 1
  %t995 = load ptr, ptr %t994, !tbaa !29
  %t997 = getelementptr %"compiler/generic:Program", ptr %t995, i32 0, i32 2
  %t998 = load i32, ptr %l4, !tbaa !23
  %t1001 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t997, i32 %t998)
  store i32 %t1001, ptr %l507
  br label %bb217
bb216:
  store i1 false, ptr %l501, !tbaa !21
  br label %bb221
bb217:
  %t1002 = load ptr, ptr %l0, !tbaa !29
  %t1004 = getelementptr %"compiler/check:Checker", ptr %t1002, i32 0, i32 1
  %t1005 = load ptr, ptr %t1004, !tbaa !29
  %t1007 = getelementptr %"compiler/generic:Program", ptr %t1005, i32 0, i32 2
  store ptr %t1007, ptr %l510, !tbaa !29
  %t1008 = load ptr, ptr %l0, !tbaa !29
  %t1009 = load i32, ptr %l26, !tbaa !23
  %t1012 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t1008, i32 %t1009)
  store i32 %t1012, ptr %l513
  br label %bb218
bb218:
  %t1013 = load ptr, ptr %l510, !tbaa !29
  %t1014 = load i32, ptr %l513, !tbaa !23
  %t1015 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t1013, i32 %t1014)
  store i32 %t1015, ptr %l514
  br label %bb219
bb219:
  %t1016 = load ptr, ptr %l502, !tbaa !29
  %t1017 = load i32, ptr %l507, !tbaa !23
  %t1018 = load i32, ptr %l514, !tbaa !23
  %t1019 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esameRepr(ptr %v0, ptr %t1016, i32 %t1017, i32 %t1018)
  store i1 %t1019, ptr %l515
  br label %bb220
bb220:
  %t1020 = load i1, ptr %l515, !tbaa !21
  store i1 %t1020, ptr %l501, !tbaa !21
  br label %bb221
bb221:
  %t1021 = load i1, ptr %l501, !tbaa !21
  br i1 %t1021, label %bb222, label %bb223
bb222:
  %t1022 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1022, ptr %l516, !tbaa !29
  %t1023 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t1023, ptr %l517
  %t1024 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1024, ptr %l518, !tbaa !29
  %t1025 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1025, ptr %l519, !tbaa !29
  %t1026 = load ptr, ptr %l0, !tbaa !29
  %t1027 = load i32, ptr %l26, !tbaa !23
  %t1030 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t1026, i32 %t1027)
  store i32 %t1030, ptr %l522
  br label %bb224
bb223:
  br label %bb228
bb224:
  %t1031 = load %"compiler/source:Span", ptr %l3
  %t1032 = load ptr, ptr %l518, !tbaa !29
  %t1033 = load ptr, ptr %l519, !tbaa !29
  %t1034 = load i32, ptr %l522, !tbaa !23
  %t1036 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %t1032, ptr %t1033, i32 %t1034, %"compiler/source:Span" %t1031)
  store ptr %t1036, ptr %l524
  br label %bb225
bb225:
  %t1037 = load i32, ptr %l26, !tbaa !23
  %t1038 = load ptr, ptr %l516, !tbaa !29
  %t1039 = load %"compiler/source:Span", ptr %l517
  %t1040 = load ptr, ptr %l524, !tbaa !29
  %t1042 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %t1038, %"compiler/source:Span" %t1039, ptr %t1040, i32 %t1037)
  store ptr %t1042, ptr %l526
  br label %bb226
bb226:
  %t1043 = load ptr, ptr %l526, !tbaa !29
  %t1044 = load ptr, ptr %l0, !tbaa !29
  %t1046 = load i32, ptr %l2, !tbaa !23
  %t1047 = load %"compiler/source:Span", ptr %l3
  %t1052 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %t1044, ptr %t1043, i32 %t1046, %"compiler/source:Span" %t1047)
  store ptr %t1052, ptr %l531
  br label %bb227
bb227:
  call void @__olang_scope_close(ptr %s0)
  %t1053 = load ptr, ptr %l531, !tbaa !29
  store ptr %t1053, ptr %rv
  br label %ret
bb228:
  br label %bb229
bb229:
  %t1054 = load i32, ptr %l6
  %t1056 = trunc i64 21 to i32
  %t1057 = icmp eq i32 %t1054, %t1056
  br i1 %t1057, label %bb230, label %bb231
bb230:
  %t1059 = load i32, ptr %l7
  %t1061 = trunc i64 21 to i32
  %t1062 = icmp eq i32 %t1059, %t1061
  store i1 %t1062, ptr %l534, !tbaa !21
  br label %bb232
bb231:
  store i1 false, ptr %l534, !tbaa !21
  br label %bb232
bb232:
  %t1064 = load i1, ptr %l534, !tbaa !21
  br i1 %t1064, label %bb233, label %bb234
bb233:
  %t1065 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1065, ptr %l538, !tbaa !29
  %t1066 = load i32, ptr %l4, !tbaa !23
  store i32 %t1066, ptr %l539, !tbaa !23
  %t1067 = load i32, ptr %l2, !tbaa !23
  store i32 %t1067, ptr %l540, !tbaa !23
  %t1068 = load ptr, ptr %l1, !tbaa !29
  %t1070 = call i1 @compiler_2fcheck_2enamedFn(ptr %v0, ptr %t1068)
  store i1 %t1070, ptr %l542
  br label %bb235
bb234:
  store i1 false, ptr %l537, !tbaa !21
  br label %bb237
bb235:
  %t1071 = load ptr, ptr %l538, !tbaa !29
  %t1072 = load i32, ptr %l539, !tbaa !23
  %t1073 = load i32, ptr %l540, !tbaa !23
  %t1074 = load i1, ptr %l542, !tbaa !21
  %t1075 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efuncFits(ptr %v0, ptr %t1071, i32 %t1072, i32 %t1073, i1 %t1074)
  store i1 %t1075, ptr %l543
  br label %bb236
bb236:
  %t1076 = load i1, ptr %l543, !tbaa !21
  store i1 %t1076, ptr %l537, !tbaa !21
  br label %bb237
bb237:
  %t1077 = load i1, ptr %l537, !tbaa !21
  br i1 %t1077, label %bb238, label %bb239
bb238:
  %t1078 = load ptr, ptr %l0, !tbaa !29
  %t1079 = load %"compiler/source:Span", ptr %l3
  %t1080 = load ptr, ptr %l1, !tbaa !29
  %t1081 = load i32, ptr %l2, !tbaa !23
  %t1086 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %t1078, %"compiler/source:Span" %t1079, ptr %t1080, i32 %t1081)
  store ptr %t1086, ptr %l548
  br label %bb240
bb239:
  br label %bb241
bb240:
  call void @__olang_scope_close(ptr %s0)
  %t1087 = load ptr, ptr %l548, !tbaa !29
  store ptr %t1087, ptr %rv
  br label %ret
bb241:
  %t1088 = load i32, ptr %l7
  %t1090 = trunc i64 21 to i32
  %t1091 = icmp eq i32 %t1088, %t1090
  br i1 %t1091, label %bb242, label %bb243
bb242:
  %t1093 = load i32, ptr %l6
  %t1095 = trunc i64 21 to i32
  %t1096 = icmp eq i32 %t1093, %t1095
  %t1098 = xor i1 %t1096, true
  store i1 %t1098, ptr %l551, !tbaa !21
  br label %bb244
bb243:
  store i1 false, ptr %l551, !tbaa !21
  br label %bb244
bb244:
  %t1100 = load i1, ptr %l551, !tbaa !21
  br i1 %t1100, label %bb245, label %bb246
bb245:
  %t1101 = load i32, ptr %l4, !tbaa !23
  %t1102 = load i32, ptr @G_2ecompiler_2ftypes_2eNullT, !tbaa !23
  %t1105 = icmp ne i32 %t1101, %t1102
  store i1 %t1105, ptr %l555, !tbaa !21
  br label %bb247
bb246:
  store i1 false, ptr %l555, !tbaa !21
  br label %bb247
bb247:
  %t1107 = load i1, ptr %l555, !tbaa !21
  br i1 %t1107, label %bb248, label %bb249
bb248:
  %t1108 = load ptr, ptr %l0, !tbaa !29
  %t1109 = load %"compiler/source:Span", ptr %l3
  %t1110 = load ptr, ptr %l1, !tbaa !29
  %t1111 = load i32, ptr %l2, !tbaa !23
  %t1116 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eadapter(ptr %v0, ptr %t1108, %"compiler/source:Span" %t1109, ptr %t1110, i32 %t1111)
  store ptr %t1116, ptr %l563
  br label %bb250
bb249:
  br label %bb254
bb250:
  %t1117 = load ptr, ptr %l563, !tbaa !29
  store ptr %t1117, ptr %l28, !tbaa !29
  %t1118 = load ptr, ptr %l28, !tbaa !29
  %t1120 = icmp eq ptr %t1118, null
  %t1122 = xor i1 %t1120, true
  br i1 %t1122, label %bb251, label %bb252
bb251:
  %t1124 = load ptr, ptr %l28, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t1124, ptr %rv
  br label %ret
bb252:
  br label %bb253
bb253:
  br label %bb254
bb254:
  %t1126 = load i32, ptr %l4, !tbaa !23
  %t1127 = load i32, ptr @G_2ecompiler_2ftypes_2eNullT, !tbaa !23
  %t1130 = icmp eq i32 %t1126, %t1127
  br i1 %t1130, label %bb255, label %bb256
bb255:
  store %olang.scope zeroinitializer, ptr %s29
  %t1132 = load i32, ptr %l7
  %t1134 = trunc i64 20 to i32
  %t1135 = icmp eq i32 %t1132, %t1134
  br i1 %t1135, label %bb257, label %bb258
bb256:
  br label %bb290
bb257:
  %t1137 = load ptr, ptr %l0, !tbaa !29
  %t1139 = getelementptr %"compiler/check:Checker", ptr %t1137, i32 0, i32 1
  %t1140 = load ptr, ptr %t1139, !tbaa !29
  %t1142 = getelementptr %"compiler/generic:Program", ptr %t1140, i32 0, i32 2
  %t1143 = load i32, ptr %l2, !tbaa !23
  %t1146 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %t1142, i32 %t1143)
  store i1 %t1146, ptr %l578
  br label %bb259
bb258:
  store i1 false, ptr %l573, !tbaa !21
  br label %bb260
bb259:
  %t1147 = load i1, ptr %l578, !tbaa !21
  store i1 %t1147, ptr %l573, !tbaa !21
  br label %bb260
bb260:
  %t1148 = load i1, ptr %l573, !tbaa !21
  br i1 %t1148, label %bb261, label %bb262
bb261:
  store i1 true, ptr %l579, !tbaa !21
  br label %bb263
bb262:
  %t1149 = load i32, ptr %l7
  %t1151 = trunc i64 21 to i32
  %t1152 = icmp eq i32 %t1149, %t1151
  store i1 %t1152, ptr %l579, !tbaa !21
  br label %bb263
bb263:
  %t1154 = load i1, ptr %l579, !tbaa !21
  br i1 %t1154, label %bb264, label %bb265
bb264:
  %t1155 = load ptr, ptr %l0, !tbaa !29
  %t1156 = load %"compiler/source:Span", ptr %l3
  %t1157 = load i32, ptr %l2, !tbaa !23
  %t1161 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t1155, %"compiler/source:Span" %t1156, i32 %t1157, i64 0)
  store ptr %t1161, ptr %l585
  br label %bb266
bb265:
  br label %bb267
bb266:
  call void @__olang_scope_close(ptr %s29)
  call void @__olang_scope_close(ptr %s0)
  %t1162 = load ptr, ptr %l585, !tbaa !29
  store ptr %t1162, ptr %rv
  br label %ret
bb267:
  %t1163 = load ptr, ptr %l0, !tbaa !29
  %t1165 = getelementptr %"compiler/check:Checker", ptr %t1163, i32 0, i32 1
  %t1166 = load ptr, ptr %t1165, !tbaa !29
  %t1168 = getelementptr %"compiler/generic:Program", ptr %t1166, i32 0, i32 2
  %t1169 = load i32, ptr %l2, !tbaa !23
  %t1172 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArrayRef(ptr %v0, ptr %t1168, i32 %t1169)
  store i1 %t1172, ptr %l590
  br label %bb268
bb268:
  %t1173 = load i1, ptr %l590, !tbaa !21
  br i1 %t1173, label %bb269, label %bb270
bb269:
  store %olang.scope zeroinitializer, ptr %s31
  %t1174 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1174, ptr %l591, !tbaa !29
  %t1175 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t1175, ptr %l592
  %t1176 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1176, ptr %l593, !tbaa !29
  %t1177 = load ptr, ptr %l0, !tbaa !29
  %t1178 = load i32, ptr %l2, !tbaa !23
  %t1181 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t1177, i32 %t1178)
  store i32 %t1181, ptr %l596
  br label %bb271
bb270:
  br label %bb277
bb271:
  %t1182 = load ptr, ptr %l593, !tbaa !29
  %t1183 = load i32, ptr %l596, !tbaa !23
  %t1184 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s31, ptr %t1182, i32 %t1183)
  store { i64, ptr } %t1184, ptr %l597
  br label %bb272
bb272:
  %t1185 = load { i64, ptr }, ptr %l597, !tbaa !27
  %t1186 = extractvalue { i64, ptr } %t1185, 0
  %t1187 = extractvalue { i64, ptr } %t1185, 1
  %t1188 = mul i64 %t1186, 1
  %t1189 = call ptr @__olang_scope_alloc(ptr %s31, i64 %t1188)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1189, ptr %t1187, i64 %t1188, i1 false)
  %t1190 = insertvalue { i64, ptr } undef, i64 %t1186, 0
  %t1191 = insertvalue { i64, ptr } %t1190, ptr %t1189, 1
  store { i64, ptr } %t1191, ptr %l598, !tbaa !27
  %t1192 = load ptr, ptr %l0, !tbaa !29
  %t1193 = load i32, ptr %l2, !tbaa !23
  %t1196 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemptyArray(ptr %v0, ptr %s31, ptr %t1192, i32 %t1193)
  store { i64, ptr } %t1196, ptr %l601
  br label %bb273
bb273:
  %t1197 = load { i64, ptr }, ptr %l601, !tbaa !27
  %t1198 = extractvalue { i64, ptr } %t1197, 0
  %t1199 = extractvalue { i64, ptr } %t1197, 1
  %t1200 = mul i64 %t1198, 1
  %t1201 = call ptr @__olang_scope_alloc(ptr %s31, i64 %t1200)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1201, ptr %t1199, i64 %t1200, i1 false)
  %t1202 = insertvalue { i64, ptr } undef, i64 %t1198, 0
  %t1203 = insertvalue { i64, ptr } %t1202, ptr %t1201, 1
  %t1204 = load { i64, ptr }, ptr %l598, !tbaa !27
  %t1206 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNullToArray(ptr %s31, ptr %s31, ptr %s31, { i64, ptr } %t1204, { i64, ptr } %t1203)
  store %"compiler/msgs:Msg" %t1206, ptr %l603
  br label %bb274
bb274:
  %t1207 = load ptr, ptr %l591, !tbaa !29
  %t1208 = load %"compiler/source:Span", ptr %l592
  %t1209 = load %"compiler/msgs:Msg", ptr %l603
  %t1210 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s31, ptr %t1207, %"compiler/source:Span" %t1208, %"compiler/msgs:Msg" %t1209)
  store i64 %t1210, ptr %l604
  br label %bb275
bb275:
  %t1211 = load ptr, ptr %l0, !tbaa !29
  %t1212 = load %"compiler/source:Span", ptr %l3
  %t1213 = load i32, ptr %l2, !tbaa !23
  %t1217 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t1211, %"compiler/source:Span" %t1212, i32 %t1213, i64 0)
  store ptr %t1217, ptr %l608
  br label %bb276
bb276:
  call void @__olang_scope_close(ptr %s31)
  call void @__olang_scope_close(ptr %s29)
  call void @__olang_scope_close(ptr %s0)
  %t1218 = load ptr, ptr %l608, !tbaa !29
  store ptr %t1218, ptr %rv
  br label %ret
bb277:
  %t1219 = load i32, ptr %l7
  %t1221 = trunc i64 20 to i32
  %t1222 = icmp eq i32 %t1219, %t1221
  br i1 %t1222, label %bb278, label %bb279
bb278:
  store %olang.scope zeroinitializer, ptr %s32
  %t1224 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1224, ptr %l611, !tbaa !29
  %t1225 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t1225, ptr %l612
  %t1226 = load ptr, ptr %l0, !tbaa !29
  %t1227 = load i32, ptr %l2, !tbaa !23
  %t1230 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s32, ptr %t1226, i32 %t1227)
  store { i64, ptr } %t1230, ptr %l615
  br label %bb280
bb279:
  br label %bb286
bb280:
  %t1231 = load { i64, ptr }, ptr %l615, !tbaa !27
  %t1232 = extractvalue { i64, ptr } %t1231, 0
  %t1233 = extractvalue { i64, ptr } %t1231, 1
  %t1234 = mul i64 %t1232, 1
  %t1235 = call ptr @__olang_scope_alloc(ptr %s32, i64 %t1234)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1235, ptr %t1233, i64 %t1234, i1 false)
  %t1236 = insertvalue { i64, ptr } undef, i64 %t1232, 0
  %t1237 = insertvalue { i64, ptr } %t1236, ptr %t1235, 1
  store { i64, ptr } %t1237, ptr %l616, !tbaa !27
  %t1238 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1238, ptr %l617, !tbaa !29
  %t1239 = load ptr, ptr %l0, !tbaa !29
  %t1241 = getelementptr %"compiler/check:Checker", ptr %t1239, i32 0, i32 1
  %t1242 = load ptr, ptr %t1241, !tbaa !29
  %t1244 = getelementptr %"compiler/generic:Program", ptr %t1242, i32 0, i32 2
  %t1245 = load i32, ptr %l2, !tbaa !23
  %t1248 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOrNull(ptr %v0, ptr %t1244, i32 %t1245)
  store i32 %t1248, ptr %l622
  br label %bb281
bb281:
  %t1249 = load ptr, ptr %l617, !tbaa !29
  %t1250 = load i32, ptr %l622, !tbaa !23
  %t1251 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s32, ptr %t1249, i32 %t1250)
  store { i64, ptr } %t1251, ptr %l623
  br label %bb282
bb282:
  %t1252 = load { i64, ptr }, ptr %l623, !tbaa !27
  %t1253 = extractvalue { i64, ptr } %t1252, 0
  %t1254 = extractvalue { i64, ptr } %t1252, 1
  %t1255 = mul i64 %t1253, 1
  %t1256 = call ptr @__olang_scope_alloc(ptr %s32, i64 %t1255)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1256, ptr %t1254, i64 %t1255, i1 false)
  %t1257 = insertvalue { i64, ptr } undef, i64 %t1253, 0
  %t1258 = insertvalue { i64, ptr } %t1257, ptr %t1256, 1
  %t1259 = load { i64, ptr }, ptr %l616, !tbaa !27
  %t1261 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNullToNonNull(ptr %s32, ptr %s32, ptr %s32, { i64, ptr } %t1259, { i64, ptr } %t1258)
  store %"compiler/msgs:Msg" %t1261, ptr %l625
  br label %bb283
bb283:
  %t1262 = load ptr, ptr %l611, !tbaa !29
  %t1263 = load %"compiler/source:Span", ptr %l612
  %t1264 = load %"compiler/msgs:Msg", ptr %l625
  %t1265 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s32, ptr %t1262, %"compiler/source:Span" %t1263, %"compiler/msgs:Msg" %t1264)
  store i64 %t1265, ptr %l626
  br label %bb284
bb284:
  %t1266 = load i64, ptr %l626, !tbaa !24
  %t1267 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclNote(ptr %v0, ptr %t1267, i64 %t1266)
  br label %bb285
bb285:
  %t1271 = load ptr, ptr %l1, !tbaa !29
  call void @__olang_scope_close(ptr %s32)
  call void @__olang_scope_close(ptr %s29)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t1271, ptr %rv
  br label %ret
bb286:
  %t1273 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1273, ptr %l630, !tbaa !29
  %t1274 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t1274, ptr %l631
  %t1275 = load ptr, ptr %l0, !tbaa !29
  %t1276 = load i32, ptr %l2, !tbaa !23
  %t1279 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s29, ptr %t1275, i32 %t1276)
  store { i64, ptr } %t1279, ptr %l634
  br label %bb287
bb287:
  %t1280 = load { i64, ptr }, ptr %l634, !tbaa !27
  %t1281 = extractvalue { i64, ptr } %t1280, 0
  %t1282 = extractvalue { i64, ptr } %t1280, 1
  %t1283 = mul i64 %t1281, 1
  %t1284 = call ptr @__olang_scope_alloc(ptr %s29, i64 %t1283)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1284, ptr %t1282, i64 %t1283, i1 false)
  %t1285 = insertvalue { i64, ptr } undef, i64 %t1281, 0
  %t1286 = insertvalue { i64, ptr } %t1285, ptr %t1284, 1
  %t1288 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeMismatch(ptr %s29, ptr %s29, ptr %s29, { i64, ptr } %t1286, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d31, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t1288, ptr %l636
  br label %bb288
bb288:
  %t1289 = load ptr, ptr %l630, !tbaa !29
  %t1290 = load %"compiler/source:Span", ptr %l631
  %t1291 = load %"compiler/msgs:Msg", ptr %l636
  %t1292 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s29, ptr %t1289, %"compiler/source:Span" %t1290, %"compiler/msgs:Msg" %t1291)
  store i64 %t1292, ptr %l637
  br label %bb289
bb289:
  %t1293 = load ptr, ptr %l1, !tbaa !29
  call void @__olang_scope_close(ptr %s29)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t1293, ptr %rv
  br label %ret
bb290:
  %t1295 = load ptr, ptr %l0, !tbaa !29
  %t1296 = load i32, ptr %l4, !tbaa !23
  %t1299 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t1295, i32 %t1296)
  store i1 %t1299, ptr %l641
  br label %bb291
bb291:
  %t1300 = load i1, ptr %l641, !tbaa !21
  br i1 %t1300, label %bb292, label %bb293
bb292:
  %t1301 = load ptr, ptr %l0, !tbaa !29
  %t1302 = load i32, ptr %l2, !tbaa !23
  %t1305 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t1301, i32 %t1302)
  store i1 %t1305, ptr %l645
  br label %bb294
bb293:
  store i1 false, ptr %l642, !tbaa !21
  br label %bb295
bb294:
  %t1306 = load i1, ptr %l645, !tbaa !21
  store i1 %t1306, ptr %l642, !tbaa !21
  br label %bb295
bb295:
  %t1307 = load i1, ptr %l642, !tbaa !21
  br i1 %t1307, label %bb296, label %bb297
bb296:
  %t1308 = load i32, ptr %l6
  %t1310 = trunc i64 20 to i32
  %t1311 = icmp eq i32 %t1308, %t1310
  %t1313 = xor i1 %t1311, true
  store i1 %t1313, ptr %l646, !tbaa !21
  br label %bb298
bb297:
  store i1 false, ptr %l646, !tbaa !21
  br label %bb298
bb298:
  %t1315 = load i1, ptr %l646, !tbaa !21
  br i1 %t1315, label %bb299, label %bb300
bb299:
  %t1316 = load i32, ptr %l7
  %t1318 = trunc i64 20 to i32
  %t1319 = icmp eq i32 %t1316, %t1318
  %t1321 = xor i1 %t1319, true
  store i1 %t1321, ptr %l650, !tbaa !21
  br label %bb301
bb300:
  store i1 false, ptr %l650, !tbaa !21
  br label %bb301
bb301:
  %t1323 = load i1, ptr %l650, !tbaa !21
  br i1 %t1323, label %bb302, label %bb303
bb302:
  store %olang.scope zeroinitializer, ptr %s33
  %t1324 = load ptr, ptr %l0, !tbaa !29
  %t1326 = getelementptr %"compiler/check:Checker", ptr %t1324, i32 0, i32 1
  %t1327 = load ptr, ptr %t1326, !tbaa !29
  %t1328 = load i32, ptr %l4, !tbaa !23
  %t1329 = load i32, ptr %l2, !tbaa !23
  %t1333 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFlows(ptr %v0, ptr %t1327, i32 %t1328, i32 %t1329)
  store i1 %t1333, ptr %l658
  br label %bb304
bb303:
  br label %bb316
bb304:
  %t1334 = load i1, ptr %l658, !tbaa !21
  br i1 %t1334, label %bb305, label %bb306
bb305:
  %t1335 = load ptr, ptr %l0, !tbaa !29
  %t1336 = load %"compiler/source:Span", ptr %l3
  %t1337 = load ptr, ptr %l1, !tbaa !29
  %t1338 = load i32, ptr %l2, !tbaa !23
  %t1343 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %t1335, %"compiler/source:Span" %t1336, ptr %t1337, i32 %t1338)
  store ptr %t1343, ptr %l663
  br label %bb307
bb306:
  br label %bb308
bb307:
  call void @__olang_scope_close(ptr %s33)
  call void @__olang_scope_close(ptr %s0)
  %t1344 = load ptr, ptr %l663, !tbaa !29
  store ptr %t1344, ptr %rv
  br label %ret
bb308:
  %t1345 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1345, ptr %l664, !tbaa !29
  %t1346 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t1346, ptr %l665
  %t1347 = load ptr, ptr %l0, !tbaa !29
  %t1348 = load i32, ptr %l4, !tbaa !23
  %t1351 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s33, ptr %t1347, i32 %t1348)
  store { i64, ptr } %t1351, ptr %l668
  br label %bb309
bb309:
  %t1352 = load { i64, ptr }, ptr %l668, !tbaa !27
  %t1353 = extractvalue { i64, ptr } %t1352, 0
  %t1354 = extractvalue { i64, ptr } %t1352, 1
  %t1355 = mul i64 %t1353, 1
  %t1356 = call ptr @__olang_scope_alloc(ptr %s33, i64 %t1355)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1356, ptr %t1354, i64 %t1355, i1 false)
  %t1357 = insertvalue { i64, ptr } undef, i64 %t1353, 0
  %t1358 = insertvalue { i64, ptr } %t1357, ptr %t1356, 1
  store { i64, ptr } %t1358, ptr %l669, !tbaa !27
  %t1359 = load ptr, ptr %l0, !tbaa !29
  %t1360 = load i32, ptr %l2, !tbaa !23
  %t1363 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s33, ptr %t1359, i32 %t1360)
  store { i64, ptr } %t1363, ptr %l672
  br label %bb310
bb310:
  %t1364 = load { i64, ptr }, ptr %l672, !tbaa !27
  %t1365 = extractvalue { i64, ptr } %t1364, 0
  %t1366 = extractvalue { i64, ptr } %t1364, 1
  %t1367 = mul i64 %t1365, 1
  %t1368 = call ptr @__olang_scope_alloc(ptr %s33, i64 %t1367)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1368, ptr %t1366, i64 %t1367, i1 false)
  %t1369 = insertvalue { i64, ptr } undef, i64 %t1365, 0
  %t1370 = insertvalue { i64, ptr } %t1369, ptr %t1368, 1
  store { i64, ptr } %t1370, ptr %l673, !tbaa !27
  %t1371 = load ptr, ptr %l0, !tbaa !29
  %t1372 = load i32, ptr %l2, !tbaa !23
  %t1375 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s33, ptr %t1371, i32 %t1372)
  store { i64, ptr } %t1375, ptr %l676
  br label %bb311
bb311:
  %t1376 = load { i64, ptr }, ptr %l676, !tbaa !27
  %t1377 = extractvalue { i64, ptr } %t1376, 0
  %t1378 = extractvalue { i64, ptr } %t1376, 1
  %t1379 = mul i64 %t1377, 1
  %t1380 = call ptr @__olang_scope_alloc(ptr %s33, i64 %t1379)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1380, ptr %t1378, i64 %t1379, i1 false)
  %t1381 = insertvalue { i64, ptr } undef, i64 %t1377, 0
  %t1382 = insertvalue { i64, ptr } %t1381, ptr %t1380, 1
  %t1383 = load { i64, ptr }, ptr %l669, !tbaa !27
  %t1384 = load { i64, ptr }, ptr %l673, !tbaa !27
  %t1386 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNumberDoesNotFlow(ptr %s33, ptr %s33, ptr %s33, ptr %s33, { i64, ptr } %t1383, { i64, ptr } %t1384, { i64, ptr } %t1382)
  store %"compiler/msgs:Msg" %t1386, ptr %l678
  br label %bb312
bb312:
  %t1387 = load ptr, ptr %l664, !tbaa !29
  %t1388 = load %"compiler/source:Span", ptr %l665
  %t1389 = load %"compiler/msgs:Msg", ptr %l678
  %t1390 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s33, ptr %t1387, %"compiler/source:Span" %t1388, %"compiler/msgs:Msg" %t1389)
  store i64 %t1390, ptr %l679
  br label %bb313
bb313:
  %t1391 = load i64, ptr %l679, !tbaa !24
  %t1392 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1392, ptr %l680, !tbaa !29
  store i64 %t1391, ptr %l681, !tbaa !24
  %t1394 = load ptr, ptr %l0, !tbaa !29
  %t1395 = load ptr, ptr %l1, !tbaa !29
  %t1397 = load i32, ptr %l4, !tbaa !23
  %t1401 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eliteralLocalIn(ptr %v0, ptr %v0, ptr %t1394, ptr %t1395, i32 %t1397)
  store i64 %t1401, ptr %l686
  br label %bb314
bb314:
  %t1402 = load i32, ptr %l2, !tbaa !23
  %t1403 = load ptr, ptr %l680, !tbaa !29
  %t1404 = load i64, ptr %l681, !tbaa !24
  %t1405 = load i64, ptr %l686, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eliteralLocalNote(ptr %v0, ptr %t1403, i64 %t1404, i64 %t1405, i32 %t1402)
  br label %bb315
bb315:
  %t1407 = load ptr, ptr %l1, !tbaa !29
  call void @__olang_scope_close(ptr %s33)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t1407, ptr %rv
  br label %ret
bb316:
  %t1409 = load i32, ptr %l6
  %t1411 = trunc i64 20 to i32
  %t1412 = icmp eq i32 %t1409, %t1411
  br i1 %t1412, label %bb317, label %bb318
bb317:
  %t1414 = load i32, ptr %l7
  %t1416 = trunc i64 20 to i32
  %t1417 = icmp eq i32 %t1414, %t1416
  %t1419 = xor i1 %t1417, true
  store i1 %t1419, ptr %l691, !tbaa !21
  br label %bb319
bb318:
  store i1 false, ptr %l691, !tbaa !21
  br label %bb319
bb319:
  %t1421 = load i1, ptr %l691, !tbaa !21
  br i1 %t1421, label %bb320, label %bb321
bb320:
  %t1422 = load ptr, ptr %l0, !tbaa !29
  %t1424 = getelementptr %"compiler/check:Checker", ptr %t1422, i32 0, i32 1
  %t1425 = load ptr, ptr %t1424, !tbaa !29
  %t1427 = getelementptr %"compiler/generic:Program", ptr %t1425, i32 0, i32 2
  %t1428 = load i32, ptr %l4, !tbaa !23
  %t1431 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t1427, i32 %t1428)
  store i32 %t1431, ptr %l699
  br label %bb322
bb321:
  br label %bb346
bb322:
  %t1432 = load i32, ptr %l699, !tbaa !23
  store i32 %t1432, ptr %l31, !tbaa !23
  %t1433 = load ptr, ptr %l0, !tbaa !29
  %t1435 = getelementptr %"compiler/check:Checker", ptr %t1433, i32 0, i32 1
  %t1436 = load ptr, ptr %t1435, !tbaa !29
  %t1438 = getelementptr %"compiler/generic:Program", ptr %t1436, i32 0, i32 2
  %t1439 = load i32, ptr %l31, !tbaa !23
  %t1440 = load i32, ptr %l2, !tbaa !23
  %t1444 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t1438, i32 %t1439, i32 %t1440)
  store i1 %t1444, ptr %l705
  br label %bb323
bb323:
  %t1445 = load i1, ptr %l705, !tbaa !21
  br i1 %t1445, label %bb324, label %bb325
bb324:
  store i1 true, ptr %l706, !tbaa !21
  br label %bb327
bb325:
  %t1446 = load ptr, ptr %l0, !tbaa !29
  %t1447 = load i32, ptr %l31, !tbaa !23
  %t1448 = load i32, ptr %l2, !tbaa !23
  %t1452 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eflowsInto(ptr %v0, ptr %t1446, i32 %t1447, i32 %t1448)
  store i1 %t1452, ptr %l710
  br label %bb326
bb326:
  %t1453 = load i1, ptr %l710, !tbaa !21
  store i1 %t1453, ptr %l706, !tbaa !21
  br label %bb327
bb327:
  %t1454 = load i1, ptr %l706, !tbaa !21
  br i1 %t1454, label %bb328, label %bb329
bb328:
  %t1455 = load ptr, ptr %l0, !tbaa !29
  %t1457 = getelementptr %"compiler/check:Checker", ptr %t1455, i32 0, i32 1
  %t1458 = load ptr, ptr %t1457, !tbaa !29
  %t1460 = getelementptr %"compiler/generic:Program", ptr %t1458, i32 0, i32 2
  %t1461 = load i32, ptr %l4, !tbaa !23
  %t1464 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %t1460, i32 %t1461)
  store i1 %t1464, ptr %l715
  br label %bb330
bb329:
  br label %bb345
bb330:
  %t1465 = load i1, ptr %l715, !tbaa !21
  br i1 %t1465, label %bb331, label %bb332
bb331:
  store %olang.scope zeroinitializer, ptr %s37
  %t1466 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1466, ptr %l716, !tbaa !29
  %t1467 = load ptr, ptr %l1, !tbaa !29
  %t1469 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %t1467)
  store %"compiler/source:Span" %t1469, ptr %l718
  br label %bb333
bb332:
  br label %bb342
bb333:
  %t1470 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1470, ptr %l719, !tbaa !29
  %t1471 = load ptr, ptr %l1, !tbaa !29
  %t1473 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %t1471)
  store %"compiler/source:Span" %t1473, ptr %l721
  br label %bb334
bb334:
  %t1474 = load ptr, ptr %l719, !tbaa !29
  %t1475 = load %"compiler/source:Span", ptr %l721
  %t1476 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %t1474, %"compiler/source:Span" %t1475)
  store { i64, ptr } %t1476, ptr %l722
  br label %bb335
bb335:
  %t1477 = load ptr, ptr %l0, !tbaa !29
  %t1478 = load i32, ptr %l4, !tbaa !23
  %t1481 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s37, ptr %t1477, i32 %t1478)
  store { i64, ptr } %t1481, ptr %l725
  br label %bb336
bb336:
  %t1482 = load { i64, ptr }, ptr %l725, !tbaa !27
  %t1483 = extractvalue { i64, ptr } %t1482, 0
  %t1484 = extractvalue { i64, ptr } %t1482, 1
  %t1485 = mul i64 %t1483, 1
  %t1486 = call ptr @__olang_scope_alloc(ptr %s37, i64 %t1485)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1486, ptr %t1484, i64 %t1485, i1 false)
  %t1487 = insertvalue { i64, ptr } undef, i64 %t1483, 0
  %t1488 = insertvalue { i64, ptr } %t1487, ptr %t1486, 1
  store { i64, ptr } %t1488, ptr %l726, !tbaa !27
  %t1489 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1489, ptr %l727, !tbaa !29
  %t1490 = load ptr, ptr %l1, !tbaa !29
  %t1492 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %t1490)
  store %"compiler/source:Span" %t1492, ptr %l729
  br label %bb337
bb337:
  %t1493 = load ptr, ptr %l727, !tbaa !29
  %t1494 = load %"compiler/source:Span", ptr %l729
  %t1495 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %t1493, %"compiler/source:Span" %t1494)
  store { i64, ptr } %t1495, ptr %l730
  br label %bb338
bb338:
  %t1496 = load { i64, ptr }, ptr %l730, !tbaa !27
  %t1497 = call { i64, ptr } @compiler_2fcheck_2ebangOf(ptr %v0, ptr %s37, { i64, ptr } %t1496)
  store { i64, ptr } %t1497, ptr %l731
  br label %bb339
bb339:
  %t1498 = load { i64, ptr }, ptr %l731, !tbaa !27
  %t1499 = extractvalue { i64, ptr } %t1498, 0
  %t1500 = extractvalue { i64, ptr } %t1498, 1
  %t1501 = mul i64 %t1499, 1
  %t1502 = call ptr @__olang_scope_alloc(ptr %s37, i64 %t1501)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1502, ptr %t1500, i64 %t1501, i1 false)
  %t1503 = insertvalue { i64, ptr } undef, i64 %t1499, 0
  %t1504 = insertvalue { i64, ptr } %t1503, ptr %t1502, 1
  %t1505 = load { i64, ptr }, ptr %l722, !tbaa !27
  %t1506 = load { i64, ptr }, ptr %l726, !tbaa !27
  %t1508 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eReadMaybeNull(ptr %v0, ptr %s37, ptr %s37, ptr %s37, { i64, ptr } %t1505, { i64, ptr } %t1506, { i64, ptr } %t1504)
  store %"compiler/msgs:Msg" %t1508, ptr %l733
  br label %bb340
bb340:
  %t1509 = load ptr, ptr %l716, !tbaa !29
  %t1510 = load %"compiler/source:Span", ptr %l718
  %t1511 = load %"compiler/msgs:Msg", ptr %l733
  %t1512 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s37, ptr %t1509, %"compiler/source:Span" %t1510, %"compiler/msgs:Msg" %t1511)
  store i64 %t1512, ptr %l734
  br label %bb341
bb341:
  call void @__olang_scope_close(ptr %s37)
  br label %bb342
bb342:
  %t1513 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1513, ptr %l735, !tbaa !29
  %t1514 = load ptr, ptr %l0, !tbaa !29
  %t1515 = load %"compiler/source:Span", ptr %l3
  %t1516 = load %"compiler/source:Span", ptr %l3
  %t1517 = load i32, ptr %l31, !tbaa !23
  %t1518 = load ptr, ptr %l1, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t1519
  %t1520 = getelementptr { i64, [4 x i64] }, ptr %t1519, i32 0, i32 0
  store i64 2, ptr %t1520
  %t1522 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t1516, 0
  %t1524 = insertvalue { %"compiler/source:Span", i32, ptr } %t1522, i32 %t1517, 1
  %t1526 = insertvalue { %"compiler/source:Span", i32, ptr } %t1524, ptr %t1518, 2
  %t1527 = getelementptr { i64, [4 x i64] }, ptr %t1519, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t1526, ptr %t1527
  %t1528 = load { i64, [4 x i64] }, ptr %t1519
  %t1530 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t1528, ptr %t1530
  %t1534 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t1514, %"compiler/source:Span" %t1515, ptr %t1530)
  store ptr %t1534, ptr %l743
  br label %bb343
bb343:
  %t1535 = load i32, ptr %l2, !tbaa !23
  %t1536 = load %"compiler/source:Span", ptr %l3
  %t1537 = load ptr, ptr %l735, !tbaa !29
  %t1538 = load ptr, ptr %l743, !tbaa !29
  %t1541 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %t1537, ptr %t1538, i32 %t1535, %"compiler/source:Span" %t1536)
  store ptr %t1541, ptr %l746
  br label %bb344
bb344:
  call void @__olang_scope_close(ptr %s0)
  %t1542 = load ptr, ptr %l746, !tbaa !29
  store ptr %t1542, ptr %rv
  br label %ret
bb345:
  br label %bb346
bb346:
  %t1543 = load i32, ptr %l7
  %t1545 = trunc i64 20 to i32
  %t1546 = icmp eq i32 %t1543, %t1545
  br i1 %t1546, label %bb347, label %bb348
bb347:
  %t1548 = load i32, ptr %l6
  %t1550 = trunc i64 20 to i32
  %t1551 = icmp eq i32 %t1548, %t1550
  %t1553 = xor i1 %t1551, true
  store i1 %t1553, ptr %l749, !tbaa !21
  br label %bb349
bb348:
  store i1 false, ptr %l749, !tbaa !21
  br label %bb349
bb349:
  %t1555 = load i1, ptr %l749, !tbaa !21
  br i1 %t1555, label %bb350, label %bb351
bb350:
  %t1556 = load ptr, ptr %l0, !tbaa !29
  %t1558 = getelementptr %"compiler/check:Checker", ptr %t1556, i32 0, i32 1
  %t1559 = load ptr, ptr %t1558, !tbaa !29
  %t1561 = getelementptr %"compiler/generic:Program", ptr %t1559, i32 0, i32 2
  %t1562 = load i32, ptr %l2, !tbaa !23
  %t1565 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t1561, i32 %t1562)
  store i32 %t1565, ptr %l757
  br label %bb352
bb351:
  br label %bb487
bb352:
  %t1566 = load i32, ptr %l757, !tbaa !23
  store i32 %t1566, ptr %l32, !tbaa !23
  %t1567 = load ptr, ptr %l0, !tbaa !29
  %t1569 = getelementptr %"compiler/check:Checker", ptr %t1567, i32 0, i32 1
  %t1570 = load ptr, ptr %t1569, !tbaa !29
  %t1572 = getelementptr %"compiler/generic:Program", ptr %t1570, i32 0, i32 2
  %t1573 = load i32, ptr %l32, !tbaa !23
  %t1574 = load i32, ptr %l4, !tbaa !23
  %t1578 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t1572, i32 %t1573, i32 %t1574)
  store i1 %t1578, ptr %l763
  br label %bb353
bb353:
  %t1579 = load i1, ptr %l763, !tbaa !21
  br i1 %t1579, label %bb354, label %bb355
bb354:
  %t1580 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1580, ptr %l764, !tbaa !29
  store i1 false, ptr %l765, !tbaa !21
  %t1581 = load ptr, ptr %l764, !tbaa !29
  %t1582 = icmp ne ptr %t1581, null
  br i1 %t1582, label %bb356, label %bb357
bb355:
  br label %bb432
bb356:
  %t1584 = load ptr, ptr %l764, !tbaa !29
  %t1585 = load i64, ptr %t1584
  %t1587 = icmp eq i64 %t1585, 14
  store i1 %t1587, ptr %l765, !tbaa !21
  br label %bb357
bb357:
  %t1588 = load i1, ptr %l765, !tbaa !21
  br i1 %t1588, label %bb358, label %bb359
bb358:
  %t1589 = load ptr, ptr %l1, !tbaa !29
  %t1591 = getelementptr { i64, [5 x i64] }, ptr %t1589, i32 0, i32 1
  %t1592 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t1591, i32 0, i32 0
  %t1593 = load %"compiler/source:Span", ptr %t1592
  store %"compiler/source:Span" %t1593, ptr %l33
  %t1595 = load ptr, ptr %l1, !tbaa !29
  %t1597 = getelementptr { i64, [5 x i64] }, ptr %t1595, i32 0, i32 1
  %t1598 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t1597, i32 0, i32 2
  %t1599 = load ptr, ptr %t1598
  store ptr %t1599, ptr %l34, !tbaa !29
  br label %bb360
bb359:
  br label %bb376
bb360:
  %t1601 = load ptr, ptr %l34, !tbaa !29
  %t1603 = getelementptr %"compiler/typed:Try", ptr %t1601, i32 0, i32 1
  %t1604 = load { i64, ptr }, ptr %t1603, !tbaa !27
  %t1606 = extractvalue { i64, ptr } %t1604, 0
  %t1608 = icmp eq i64 %t1606, 0
  br i1 %t1608, label %bb361, label %bb362
bb361:
  %t1610 = load ptr, ptr %l34, !tbaa !29
  %t1612 = getelementptr %"compiler/typed:Try", ptr %t1610, i32 0, i32 0
  %t1613 = load ptr, ptr %t1612, !tbaa !29
  %t1615 = icmp eq ptr %t1613, null
  br i1 %t1615, label %bb363, label %bb364
bb362:
  store i1 false, ptr %l776, !tbaa !21
  br label %bb367
bb363:
  call void @__olang_check_failed(ptr @olang_loc_6745a459824cdbb9_2d85ba610b532f4d)
  unreachable
bb364:
  br label %bb365
bb365:
  %t1617 = load ptr, ptr %l34, !tbaa !29
  %t1619 = getelementptr %"compiler/typed:Try", ptr %t1617, i32 0, i32 0
  %t1620 = load ptr, ptr %t1619, !tbaa !29
  %t1622 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v0, ptr %t1620)
  store ptr %t1622, ptr %l782
  br label %bb366
bb366:
  %t1623 = load ptr, ptr %l782, !tbaa !29
  %t1624 = icmp eq ptr %t1623, null
  %t1626 = xor i1 %t1624, true
  store i1 %t1626, ptr %l776, !tbaa !21
  br label %bb367
bb367:
  %t1628 = load i1, ptr %l776, !tbaa !21
  br i1 %t1628, label %bb368, label %bb369
bb368:
  %t1629 = load %"compiler/source:Span", ptr %l33
  store %"compiler/source:Span" %t1629, ptr %l785
  %t1630 = load i32, ptr %l2, !tbaa !23
  store i32 %t1630, ptr %l786, !tbaa !23
  %t1631 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1631, ptr %l787, !tbaa !29
  %t1632 = load ptr, ptr %l34, !tbaa !29
  %t1634 = getelementptr %"compiler/typed:Try", ptr %t1632, i32 0, i32 0
  %t1635 = load ptr, ptr %t1634, !tbaa !29
  %t1637 = icmp eq ptr %t1635, null
  br i1 %t1637, label %bb370, label %bb371
bb369:
  br label %bb375
bb370:
  call void @__olang_check_failed(ptr @olang_loc_a4df8c70fd3d792_71930a831bbf5566)
  unreachable
bb371:
  br label %bb372
bb372:
  %t1639 = load ptr, ptr %l34, !tbaa !29
  %t1641 = getelementptr %"compiler/typed:Try", ptr %t1639, i32 0, i32 0
  %t1642 = load ptr, ptr %t1641, !tbaa !29
  %t1643 = load i32, ptr %l2, !tbaa !23
  %t1644 = load %"compiler/source:Span", ptr %l3
  %t1645 = load ptr, ptr %l787, !tbaa !29
  %t1649 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %t1645, ptr %t1642, i32 %t1643, %"compiler/source:Span" %t1644)
  store ptr %t1649, ptr %l795
  br label %bb373
bb373:
  %t1650 = load ptr, ptr %l795, !tbaa !29
  %t1651 = load ptr, ptr %l34, !tbaa !29
  %t1653 = getelementptr %"compiler/typed:Try", ptr %t1651, i32 0, i32 1
  %t1654 = load { i64, ptr }, ptr %t1653, !tbaa !27
  %t1655 = load ptr, ptr %l34, !tbaa !29
  %t1657 = getelementptr %"compiler/typed:Try", ptr %t1655, i32 0, i32 2
  %t1658 = load i1, ptr %t1657, !tbaa !21
  %t1662 = call %"compiler/typed:Try" @compiler_2ftyped_3aTry_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %t1650, { i64, ptr } %t1654, i1 %t1658, i1 false)
  store %"compiler/typed:Try" %t1662, ptr %l801
  br label %bb374
bb374:
  %t1663 = load %"compiler/typed:Try", ptr %l801
  %t1664 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"compiler/typed:Try" %t1663, ptr %t1664
  store { i64, [5 x i64] } zeroinitializer, ptr %t1665
  %t1666 = getelementptr { i64, [5 x i64] }, ptr %t1665, i32 0, i32 0
  store i64 14, ptr %t1666
  %t1667 = load %"compiler/source:Span", ptr %l785
  %t1668 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t1667, 0
  %t1669 = load i32, ptr %l786, !tbaa !23
  %t1670 = insertvalue { %"compiler/source:Span", i32, ptr } %t1668, i32 %t1669, 1
  %t1672 = insertvalue { %"compiler/source:Span", i32, ptr } %t1670, ptr %t1664, 2
  %t1673 = getelementptr { i64, [5 x i64] }, ptr %t1665, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t1672, ptr %t1673
  %t1674 = load { i64, [5 x i64] }, ptr %t1665
  %t1676 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t1674, ptr %t1676
  call void @__olang_scope_close(ptr %s0)
  store ptr %t1676, ptr %rv
  br label %ret
bb375:
  br label %bb377
bb376:
  br label %bb377
bb377:
  %t1678 = load ptr, ptr %l1, !tbaa !29
  %t1680 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v0, ptr %t1678)
  store ptr %t1680, ptr %l806
  br label %bb378
bb378:
  %t1681 = load ptr, ptr %l806, !tbaa !29
  store ptr %t1681, ptr %l35, !tbaa !29
  %t1682 = load ptr, ptr %l35, !tbaa !29
  %t1684 = icmp eq ptr %t1682, null
  %t1686 = xor i1 %t1684, true
  br i1 %t1686, label %bb379, label %bb380
bb379:
  %t1688 = load ptr, ptr %l0, !tbaa !29
  %t1690 = getelementptr %"compiler/check:Checker", ptr %t1688, i32 0, i32 1
  %t1691 = load ptr, ptr %t1690, !tbaa !29
  %t1693 = getelementptr %"compiler/generic:Program", ptr %t1691, i32 0, i32 2
  %t1694 = load i32, ptr %l2, !tbaa !23
  %t1697 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t1693, i32 %t1694)
  store i64 %t1697, ptr %l814
  br label %bb381
bb380:
  br label %bb414
bb381:
  %t1698 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t1699 = load i64, ptr %l814, !tbaa !24
  %t1701 = and i64 %t1699, %t1698
  %t1703 = icmp ne i64 %t1701, 0
  br i1 %t1703, label %bb382, label %bb383
bb382:
  %t1705 = load ptr, ptr %l0, !tbaa !29
  %t1706 = load ptr, ptr %l35, !tbaa !29
  %t1707 = load %"compiler/source:Span", ptr %l3
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emustWrite(ptr %v0, ptr %v0, ptr %t1705, ptr %t1706, %"compiler/source:Span" %t1707, i1 false)
  br label %bb384
bb383:
  br label %bb386
bb384:
  %t1711 = load ptr, ptr %l0, !tbaa !29
  %t1712 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroDeepNeed(ptr %v0, ptr %v0, ptr %t1711, ptr %t1712)
  br label %bb385
bb385:
  br label %bb386
bb386:
  %t1716 = load ptr, ptr %l0, !tbaa !29
  %t1718 = getelementptr %"compiler/check:Checker", ptr %t1716, i32 0, i32 8
  store ptr %t1718, ptr %l36, !tbaa !29
  store i64 0, ptr %l37, !tbaa !24
  br label %bb387
bb387:
  %t1720 = load i64, ptr %l37, !tbaa !24
  store i64 %t1720, ptr %l826, !tbaa !24
  %t1721 = load ptr, ptr %l36, !tbaa !29
  %t1723 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlace_26_3e_2eLen_3ccompiler_2ftyped_3aPlace_26_3e(ptr %v0, ptr %t1721)
  store i64 %t1723, ptr %l828
  br label %bb388
bb388:
  %t1724 = load i64, ptr %l826, !tbaa !24
  %t1725 = load i64, ptr %l828, !tbaa !24
  %t1726 = icmp slt i64 %t1724, %t1725
  %t1728 = xor i1 %t1726, true
  br i1 %t1728, label %bb389, label %bb390
bb389:
  br label %bb400
bb390:
  br label %bb391
bb391:
  %t1730 = load ptr, ptr %l36, !tbaa !29
  %t1731 = load i64, ptr %l37, !tbaa !24
  %t1734 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlace_26_3e_2eAt_3ccompiler_2ftyped_3aPlace_26_3e(ptr %v0, ptr %v0, ptr %t1730, i64 %t1731)
  store ptr %t1734, ptr %l833
  br label %bb392
bb392:
  %t1735 = load ptr, ptr %l833, !tbaa !29
  %t1736 = load ptr, ptr %l0, !tbaa !29
  %t1737 = load ptr, ptr %l35, !tbaa !29
  %t1742 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewithin(ptr %v0, ptr %v0, ptr %v0, ptr %t1736, ptr %t1737, ptr %t1735)
  store i1 %t1742, ptr %l837
  br label %bb393
bb393:
  %t1743 = load i1, ptr %l837, !tbaa !21
  br i1 %t1743, label %bb394, label %bb395
bb394:
  %t1744 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t1744, ptr %l838
  %t1745 = load i32, ptr %l2, !tbaa !23
  store i32 %t1745, ptr %l839, !tbaa !23
  %t1746 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1746, ptr %l840, !tbaa !29
  %t1747 = load ptr, ptr %l0, !tbaa !29
  %t1748 = load %"compiler/source:Span", ptr %l3
  %t1752 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %t1747, i32 2, %"compiler/source:Span" %t1748)
  store i32 %t1752, ptr %l844
  br label %bb396
bb395:
  br label %bb398
bb396:
  %t1753 = load ptr, ptr %l840, !tbaa !29
  %t1754 = load i32, ptr %l844, !tbaa !23
  %t1755 = call %"compiler/typed:Promote" @compiler_2ftyped_3aPromote_2ector(ptr %v0, ptr %v0, ptr %t1753, i32 %t1754)
  store %"compiler/typed:Promote" %t1755, ptr %l845
  br label %bb397
bb397:
  %t1756 = load %"compiler/typed:Promote", ptr %l845
  %t1757 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store %"compiler/typed:Promote" %t1756, ptr %t1757
  store { i64, [5 x i64] } zeroinitializer, ptr %t1758
  %t1759 = getelementptr { i64, [5 x i64] }, ptr %t1758, i32 0, i32 0
  store i64 5, ptr %t1759
  %t1760 = load %"compiler/source:Span", ptr %l838
  %t1761 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t1760, 0
  %t1762 = load i32, ptr %l839, !tbaa !23
  %t1763 = insertvalue { %"compiler/source:Span", i32, ptr } %t1761, i32 %t1762, 1
  %t1765 = insertvalue { %"compiler/source:Span", i32, ptr } %t1763, ptr %t1757, 2
  %t1766 = getelementptr { i64, [5 x i64] }, ptr %t1758, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t1765, ptr %t1766
  %t1767 = load { i64, [5 x i64] }, ptr %t1758
  %t1769 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t1767, ptr %t1769
  call void @__olang_scope_close(ptr %s0)
  store ptr %t1769, ptr %rv
  br label %ret
bb398:
  br label %bb399
bb399:
  %t1771 = load i64, ptr %l37, !tbaa !24
  %t1773 = add i64 %t1771, 1
  store i64 %t1773, ptr %l37, !tbaa !24
  br label %bb387
bb400:
  %t1775 = load ptr, ptr %l35, !tbaa !29
  store ptr %t1775, ptr %l851, !tbaa !29
  store i1 false, ptr %l852, !tbaa !21
  %t1776 = load ptr, ptr %l851, !tbaa !29
  %t1777 = icmp ne ptr %t1776, null
  br i1 %t1777, label %bb401, label %bb402
bb401:
  %t1779 = load ptr, ptr %l851, !tbaa !29
  %t1780 = load i64, ptr %t1779
  %t1782 = icmp eq i64 %t1780, 7
  store i1 %t1782, ptr %l852, !tbaa !21
  br label %bb402
bb402:
  %t1783 = load i1, ptr %l852, !tbaa !21
  br i1 %t1783, label %bb403, label %bb404
bb403:
  %t1784 = load ptr, ptr %l35, !tbaa !29
  %t1786 = getelementptr { i64, [4 x i64] }, ptr %t1784, i32 0, i32 1
  %t1787 = getelementptr { %"compiler/source:Span", i32 }, ptr %t1786, i32 0, i32 1
  %t1788 = load i32, ptr %t1787
  store i32 %t1788, ptr %l39, !tbaa !23
  br label %bb405
bb404:
  br label %bb412
bb405:
  %t1790 = load ptr, ptr %l0, !tbaa !29
  %t1792 = getelementptr %"compiler/check:Checker", ptr %t1790, i32 0, i32 1
  %t1793 = load ptr, ptr %t1792, !tbaa !29
  %t1795 = getelementptr %"compiler/generic:Program", ptr %t1793, i32 0, i32 2
  %t1796 = load i32, ptr %l39, !tbaa !23
  %t1799 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %t1795, i32 %t1796)
  store i1 %t1799, ptr %l861
  br label %bb406
bb406:
  %t1800 = load i1, ptr %l861, !tbaa !21
  br i1 %t1800, label %bb407, label %bb408
bb407:
  %t1801 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t1801, ptr %l862
  %t1802 = load i32, ptr %l2, !tbaa !23
  store i32 %t1802, ptr %l863, !tbaa !23
  %t1803 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1803, ptr %l864, !tbaa !29
  %t1804 = load ptr, ptr %l0, !tbaa !29
  %t1805 = load %"compiler/source:Span", ptr %l3
  %t1809 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %t1804, i32 2, %"compiler/source:Span" %t1805)
  store i32 %t1809, ptr %l868
  br label %bb409
bb408:
  br label %bb411
bb409:
  %t1810 = load ptr, ptr %l864, !tbaa !29
  %t1811 = load i32, ptr %l868, !tbaa !23
  %t1812 = call %"compiler/typed:Promote" @compiler_2ftyped_3aPromote_2ector(ptr %v0, ptr %v0, ptr %t1810, i32 %t1811)
  store %"compiler/typed:Promote" %t1812, ptr %l869
  br label %bb410
bb410:
  %t1813 = load %"compiler/typed:Promote", ptr %l869
  %t1814 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store %"compiler/typed:Promote" %t1813, ptr %t1814
  store { i64, [5 x i64] } zeroinitializer, ptr %t1815
  %t1816 = getelementptr { i64, [5 x i64] }, ptr %t1815, i32 0, i32 0
  store i64 5, ptr %t1816
  %t1817 = load %"compiler/source:Span", ptr %l862
  %t1818 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t1817, 0
  %t1819 = load i32, ptr %l863, !tbaa !23
  %t1820 = insertvalue { %"compiler/source:Span", i32, ptr } %t1818, i32 %t1819, 1
  %t1822 = insertvalue { %"compiler/source:Span", i32, ptr } %t1820, ptr %t1814, 2
  %t1823 = getelementptr { i64, [5 x i64] }, ptr %t1815, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t1822, ptr %t1823
  %t1824 = load { i64, [5 x i64] }, ptr %t1815
  %t1826 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t1824, ptr %t1826
  call void @__olang_scope_close(ptr %s0)
  store ptr %t1826, ptr %rv
  br label %ret
bb411:
  br label %bb413
bb412:
  br label %bb413
bb413:
  %t1828 = load %"compiler/source:Span", ptr %l3
  %t1829 = load i32, ptr %l2, !tbaa !23
  %t1830 = load ptr, ptr %l35, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t1831
  %t1832 = getelementptr { i64, [5 x i64] }, ptr %t1831, i32 0, i32 0
  store i64 3, ptr %t1832
  %t1834 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t1828, 0
  %t1836 = insertvalue { %"compiler/source:Span", i32, ptr } %t1834, i32 %t1829, 1
  %t1838 = insertvalue { %"compiler/source:Span", i32, ptr } %t1836, ptr %t1830, 2
  %t1839 = getelementptr { i64, [5 x i64] }, ptr %t1831, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t1838, ptr %t1839
  %t1840 = load { i64, [5 x i64] }, ptr %t1831
  %t1842 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t1840, ptr %t1842
  call void @__olang_scope_close(ptr %s0)
  store ptr %t1842, ptr %rv
  br label %ret
bb414:
  %t1844 = load ptr, ptr %l0, !tbaa !29
  %t1846 = getelementptr %"compiler/check:Checker", ptr %t1844, i32 0, i32 1
  %t1847 = load ptr, ptr %t1846, !tbaa !29
  %t1849 = getelementptr %"compiler/generic:Program", ptr %t1847, i32 0, i32 2
  %t1850 = load i32, ptr %l2, !tbaa !23
  %t1853 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t1849, i32 %t1850)
  store i64 %t1853, ptr %l882
  br label %bb415
bb415:
  %t1854 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t1855 = load i64, ptr %l882, !tbaa !24
  %t1857 = and i64 %t1855, %t1854
  %t1859 = icmp ne i64 %t1857, 0
  br i1 %t1859, label %bb416, label %bb417
bb416:
  %t1861 = load ptr, ptr %l0, !tbaa !29
  %t1862 = load ptr, ptr %l1, !tbaa !29
  %t1865 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echosenAt(ptr %v0, ptr %v0, ptr %t1861, ptr %t1862)
  store %"compiler/source:Span" %t1865, ptr %l888
  br label %bb418
bb417:
  br label %bb429
bb418:
  %t1866 = load %"compiler/source:Span", ptr %l888
  store %"compiler/source:Span" %t1866, ptr %l40
  %t1867 = getelementptr %"compiler/source:Span", ptr %l40, i32 0, i32 0
  %t1868 = load i32, ptr %t1867, !tbaa !23
  %t1870 = icmp sge i32 %t1868, 0
  br i1 %t1870, label %bb419, label %bb420
bb419:
  %t1872 = load ptr, ptr %l0, !tbaa !29
  %t1873 = load ptr, ptr %l1, !tbaa !29
  %t1876 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econdChoosesPlace(ptr %v0, ptr %v0, ptr %t1872, ptr %t1873)
  store i1 %t1876, ptr %l894
  br label %bb421
bb420:
  store i1 false, ptr %l891, !tbaa !21
  br label %bb422
bb421:
  %t1877 = load i1, ptr %l894, !tbaa !21
  store i1 %t1877, ptr %l891, !tbaa !21
  br label %bb422
bb422:
  %t1878 = load i1, ptr %l891, !tbaa !21
  br i1 %t1878, label %bb423, label %bb424
bb423:
  store %olang.scope zeroinitializer, ptr %s53
  %t1879 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1879, ptr %l895, !tbaa !29
  %t1880 = load %"compiler/source:Span", ptr %l40
  store %"compiler/source:Span" %t1880, ptr %l896
  %t1881 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCondLentWritable(ptr %s53)
  store %"compiler/msgs:Msg" %t1881, ptr %l897
  br label %bb425
bb424:
  %t1882 = load ptr, ptr %l0, !tbaa !29
  %t1883 = load ptr, ptr %l1, !tbaa !29
  %t1884 = load %"compiler/source:Span", ptr %l3
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroLend(ptr %v0, ptr %v0, ptr %t1882, ptr %t1883, %"compiler/source:Span" %t1884)
  br label %bb427
bb425:
  %t1888 = load ptr, ptr %l895, !tbaa !29
  %t1889 = load %"compiler/source:Span", ptr %l896
  %t1890 = load %"compiler/msgs:Msg", ptr %l897
  %t1891 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s53, ptr %t1888, %"compiler/source:Span" %t1889, %"compiler/msgs:Msg" %t1890)
  store i64 %t1891, ptr %l898
  br label %bb426
bb426:
  call void @__olang_scope_close(ptr %s53)
  br label %bb428
bb427:
  br label %bb428
bb428:
  br label %bb429
bb429:
  %t1892 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t1892, ptr %l902
  %t1893 = load i32, ptr %l2, !tbaa !23
  store i32 %t1893, ptr %l903, !tbaa !23
  %t1894 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1894, ptr %l904, !tbaa !29
  %t1895 = load ptr, ptr %l0, !tbaa !29
  %t1896 = load %"compiler/source:Span", ptr %l3
  %t1900 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %t1895, i32 2, %"compiler/source:Span" %t1896)
  store i32 %t1900, ptr %l908
  br label %bb430
bb430:
  %t1901 = load ptr, ptr %l904, !tbaa !29
  %t1902 = load i32, ptr %l908, !tbaa !23
  %t1903 = call %"compiler/typed:Promote" @compiler_2ftyped_3aPromote_2ector(ptr %v0, ptr %v0, ptr %t1901, i32 %t1902)
  store %"compiler/typed:Promote" %t1903, ptr %l909
  br label %bb431
bb431:
  %t1904 = load %"compiler/typed:Promote", ptr %l909
  %t1905 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store %"compiler/typed:Promote" %t1904, ptr %t1905
  store { i64, [5 x i64] } zeroinitializer, ptr %t1906
  %t1907 = getelementptr { i64, [5 x i64] }, ptr %t1906, i32 0, i32 0
  store i64 5, ptr %t1907
  %t1908 = load %"compiler/source:Span", ptr %l902
  %t1909 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t1908, 0
  %t1910 = load i32, ptr %l903, !tbaa !23
  %t1911 = insertvalue { %"compiler/source:Span", i32, ptr } %t1909, i32 %t1910, 1
  %t1913 = insertvalue { %"compiler/source:Span", i32, ptr } %t1911, ptr %t1905, 2
  %t1914 = getelementptr { i64, [5 x i64] }, ptr %t1906, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t1913, ptr %t1914
  %t1915 = load { i64, [5 x i64] }, ptr %t1906
  %t1917 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t1915, ptr %t1917
  call void @__olang_scope_close(ptr %s0)
  store ptr %t1917, ptr %rv
  br label %ret
bb432:
  %t1919 = load ptr, ptr %l0, !tbaa !29
  %t1920 = load i32, ptr %l4, !tbaa !23
  %t1921 = load i32, ptr %l32, !tbaa !23
  %t1925 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eflowsInto(ptr %v0, ptr %t1919, i32 %t1920, i32 %t1921)
  store i1 %t1925, ptr %l916
  br label %bb433
bb433:
  %t1926 = load i1, ptr %l916, !tbaa !21
  br i1 %t1926, label %bb434, label %bb435
bb434:
  store i1 true, ptr %l917, !tbaa !21
  br label %bb445
bb435:
  %t1927 = load ptr, ptr %l0, !tbaa !29
  %t1928 = load i32, ptr %l4, !tbaa !23
  %t1931 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t1927, i32 %t1928)
  store i1 %t1931, ptr %l920
  br label %bb436
bb436:
  %t1932 = load i1, ptr %l920, !tbaa !21
  br i1 %t1932, label %bb437, label %bb438
bb437:
  %t1933 = load ptr, ptr %l0, !tbaa !29
  %t1934 = load i32, ptr %l32, !tbaa !23
  %t1937 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t1933, i32 %t1934)
  store i1 %t1937, ptr %l924
  br label %bb439
bb438:
  store i1 false, ptr %l921, !tbaa !21
  br label %bb440
bb439:
  %t1938 = load i1, ptr %l924, !tbaa !21
  store i1 %t1938, ptr %l921, !tbaa !21
  br label %bb440
bb440:
  %t1939 = load i1, ptr %l921, !tbaa !21
  br i1 %t1939, label %bb441, label %bb442
bb441:
  %t1940 = load ptr, ptr %l0, !tbaa !29
  %t1942 = getelementptr %"compiler/check:Checker", ptr %t1940, i32 0, i32 1
  %t1943 = load ptr, ptr %t1942, !tbaa !29
  %t1944 = load i32, ptr %l4, !tbaa !23
  %t1945 = load i32, ptr %l32, !tbaa !23
  %t1949 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFlows(ptr %v0, ptr %t1943, i32 %t1944, i32 %t1945)
  store i1 %t1949, ptr %l930
  br label %bb443
bb442:
  store i1 false, ptr %l925, !tbaa !21
  br label %bb444
bb443:
  %t1950 = load i1, ptr %l930, !tbaa !21
  store i1 %t1950, ptr %l925, !tbaa !21
  br label %bb444
bb444:
  %t1951 = load i1, ptr %l925, !tbaa !21
  store i1 %t1951, ptr %l917, !tbaa !21
  br label %bb445
bb445:
  %t1952 = load i1, ptr %l917, !tbaa !21
  br i1 %t1952, label %bb446, label %bb447
bb446:
  %t1953 = load ptr, ptr %l1, !tbaa !29
  %t1955 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v0, ptr %t1953)
  store ptr %t1955, ptr %l932
  br label %bb448
bb447:
  br label %bb486
bb448:
  %t1956 = load ptr, ptr %l932, !tbaa !29
  store ptr %t1956, ptr %l41, !tbaa !29
  %t1957 = load ptr, ptr %l41, !tbaa !29
  %t1959 = icmp eq ptr %t1957, null
  %t1961 = xor i1 %t1959, true
  br i1 %t1961, label %bb449, label %bb450
bb449:
  %t1963 = load i32, ptr %l6
  %t1965 = trunc i64 19 to i32
  %t1966 = icmp eq i32 %t1963, %t1965
  store i1 %t1966, ptr %l936, !tbaa !21
  br label %bb451
bb450:
  store i1 false, ptr %l936, !tbaa !21
  br label %bb451
bb451:
  %t1968 = load i1, ptr %l936, !tbaa !21
  br i1 %t1968, label %bb452, label %bb453
bb452:
  %t1969 = load ptr, ptr %l0, !tbaa !29
  %t1971 = getelementptr %"compiler/check:Checker", ptr %t1969, i32 0, i32 1
  %t1972 = load ptr, ptr %t1971, !tbaa !29
  %t1974 = getelementptr %"compiler/generic:Program", ptr %t1972, i32 0, i32 2
  %t1975 = load i32, ptr %l4, !tbaa !23
  %t1978 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t1974, i32 %t1975)
  store i32 %t1978, ptr %l944
  br label %bb454
bb453:
  store i1 false, ptr %l939, !tbaa !21
  br label %bb455
bb454:
  %t1979 = load i32, ptr %l944, !tbaa !23
  %t1980 = icmp ne i32 %t1979, 0
  store i1 %t1980, ptr %l939, !tbaa !21
  br label %bb455
bb455:
  %t1982 = load i1, ptr %l939, !tbaa !21
  br i1 %t1982, label %bb456, label %bb457
bb456:
  %t1983 = load ptr, ptr %l0, !tbaa !29
  %t1985 = getelementptr %"compiler/check:Checker", ptr %t1983, i32 0, i32 1
  %t1986 = load ptr, ptr %t1985, !tbaa !29
  %t1988 = getelementptr %"compiler/generic:Program", ptr %t1986, i32 0, i32 2
  %t1989 = load i32, ptr %l2, !tbaa !23
  %t1992 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t1988, i32 %t1989)
  store i64 %t1992, ptr %l950
  br label %bb458
bb457:
  br label %bb467
bb458:
  %t1993 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t1994 = load i64, ptr %l950, !tbaa !24
  %t1996 = and i64 %t1994, %t1993
  %t1998 = icmp ne i64 %t1996, 0
  br i1 %t1998, label %bb459, label %bb460
bb459:
  %t2000 = load ptr, ptr %l0, !tbaa !29
  %t2001 = load ptr, ptr %l41, !tbaa !29
  %t2002 = load %"compiler/source:Span", ptr %l3
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emustWrite(ptr %v0, ptr %v0, ptr %t2000, ptr %t2001, %"compiler/source:Span" %t2002, i1 false)
  br label %bb461
bb460:
  br label %bb463
bb461:
  %t2006 = load ptr, ptr %l0, !tbaa !29
  %t2007 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroDeepNeed(ptr %v0, ptr %v0, ptr %t2006, ptr %t2007)
  br label %bb462
bb462:
  br label %bb463
bb463:
  %t2011 = load ptr, ptr %l0, !tbaa !29
  store ptr %t2011, ptr %l960, !tbaa !29
  %t2012 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t2012, ptr %l961
  %t2013 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t2013, ptr %l962
  %t2014 = load ptr, ptr %l0, !tbaa !29
  %t2016 = getelementptr %"compiler/check:Checker", ptr %t2014, i32 0, i32 1
  %t2017 = load ptr, ptr %t2016, !tbaa !29
  %t2019 = getelementptr %"compiler/generic:Program", ptr %t2017, i32 0, i32 2
  store ptr %t2019, ptr %l965, !tbaa !29
  %t2020 = load i32, ptr %l4, !tbaa !23
  store i32 %t2020, ptr %l966, !tbaa !23
  %t2021 = load ptr, ptr %l0, !tbaa !29
  %t2023 = getelementptr %"compiler/check:Checker", ptr %t2021, i32 0, i32 1
  %t2024 = load ptr, ptr %t2023, !tbaa !29
  %t2026 = getelementptr %"compiler/generic:Program", ptr %t2024, i32 0, i32 2
  %t2027 = load i32, ptr %l2, !tbaa !23
  %t2030 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t2026, i32 %t2027)
  store i64 %t2030, ptr %l971
  br label %bb464
bb464:
  %t2031 = load ptr, ptr %l965, !tbaa !29
  %t2032 = load i32, ptr %l966, !tbaa !23
  %t2033 = load i64, ptr %l971, !tbaa !24
  %t2034 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t2031, i32 %t2032, i64 %t2033)
  store i32 %t2034, ptr %l972
  br label %bb465
bb465:
  %t2035 = load ptr, ptr %l41, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t2036
  %t2037 = getelementptr { i64, [5 x i64] }, ptr %t2036, i32 0, i32 0
  store i64 3, ptr %t2037
  %t2038 = load %"compiler/source:Span", ptr %l962
  %t2039 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t2038, 0
  %t2040 = load i32, ptr %l972, !tbaa !23
  %t2041 = insertvalue { %"compiler/source:Span", i32, ptr } %t2039, i32 %t2040, 1
  %t2043 = insertvalue { %"compiler/source:Span", i32, ptr } %t2041, ptr %t2035, 2
  %t2044 = getelementptr { i64, [5 x i64] }, ptr %t2036, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t2043, ptr %t2044
  %t2045 = load { i64, [5 x i64] }, ptr %t2036
  %t2047 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t2045, ptr %t2047
  %t2048 = load i32, ptr %l2, !tbaa !23
  %t2049 = load ptr, ptr %l960, !tbaa !29
  %t2050 = load %"compiler/source:Span", ptr %l961
  %t2053 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %t2049, %"compiler/source:Span" %t2050, ptr %t2047, i32 %t2048)
  store ptr %t2053, ptr %l977
  br label %bb466
bb466:
  call void @__olang_scope_close(ptr %s0)
  %t2054 = load ptr, ptr %l977, !tbaa !29
  store ptr %t2054, ptr %rv
  br label %ret
bb467:
  %t2055 = load ptr, ptr %l0, !tbaa !29
  %t2056 = load ptr, ptr %l1, !tbaa !29
  %t2057 = load i32, ptr %l2, !tbaa !23
  %t2061 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estaticArray(ptr %v0, ptr %t2055, ptr %t2056, i32 %t2057)
  store ptr %t2061, ptr %l981
  br label %bb468
bb468:
  %t2062 = load ptr, ptr %l981, !tbaa !29
  store ptr %t2062, ptr %l42, !tbaa !29
  %t2063 = load ptr, ptr %l42, !tbaa !29
  %t2065 = icmp eq ptr %t2063, null
  %t2067 = xor i1 %t2065, true
  br i1 %t2067, label %bb469, label %bb470
bb469:
  %t2069 = load ptr, ptr %l42, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t2069, ptr %rv
  br label %ret
bb470:
  br label %bb471
bb471:
  %t2071 = load ptr, ptr %l0, !tbaa !29
  %t2072 = load ptr, ptr %l1, !tbaa !29
  %t2073 = load i32, ptr %l32, !tbaa !23
  %t2074 = load %"compiler/source:Span", ptr %l3
  %t2079 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %t2071, ptr %t2072, i32 %t2073, %"compiler/source:Span" %t2074)
  store ptr %t2079, ptr %l990
  br label %bb472
bb472:
  %t2080 = load ptr, ptr %l990, !tbaa !29
  store ptr %t2080, ptr %l43, !tbaa !29
  %t2081 = load ptr, ptr %l41, !tbaa !29
  %t2083 = icmp eq ptr %t2081, null
  %t2085 = xor i1 %t2083, true
  br i1 %t2085, label %bb473, label %bb474
bb473:
  %t2087 = load ptr, ptr %l0, !tbaa !29
  %t2088 = load i32, ptr %l4, !tbaa !23
  %t2091 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t2087, i32 %t2088)
  store i1 %t2091, ptr %l997
  br label %bb475
bb474:
  store i1 false, ptr %l994, !tbaa !21
  br label %bb476
bb475:
  %t2092 = load i1, ptr %l997, !tbaa !21
  store i1 %t2092, ptr %l994, !tbaa !21
  br label %bb476
bb476:
  %t2093 = load i1, ptr %l994, !tbaa !21
  br i1 %t2093, label %bb477, label %bb478
bb477:
  %t2094 = load ptr, ptr %l0, !tbaa !29
  %t2095 = load i32, ptr %l4, !tbaa !23
  %t2098 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisOver(ptr %v0, ptr %t2094, i32 %t2095)
  store i1 %t2098, ptr %l1001
  br label %bb479
bb478:
  store i1 false, ptr %l998, !tbaa !21
  br label %bb480
bb479:
  %t2099 = load i1, ptr %l1001, !tbaa !21
  store i1 %t2099, ptr %l998, !tbaa !21
  br label %bb480
bb480:
  %t2100 = load i1, ptr %l998, !tbaa !21
  br i1 %t2100, label %bb481, label %bb482
bb481:
  %t2101 = load %"compiler/source:Span", ptr %l3
  %t2102 = load i32, ptr %l2, !tbaa !23
  %t2103 = load ptr, ptr %l41, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t2104
  %t2105 = getelementptr { i64, [5 x i64] }, ptr %t2104, i32 0, i32 0
  store i64 3, ptr %t2105
  %t2107 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t2101, 0
  %t2109 = insertvalue { %"compiler/source:Span", i32, ptr } %t2107, i32 %t2102, 1
  %t2111 = insertvalue { %"compiler/source:Span", i32, ptr } %t2109, ptr %t2103, 2
  %t2112 = getelementptr { i64, [5 x i64] }, ptr %t2104, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t2111, ptr %t2112
  %t2113 = load { i64, [5 x i64] }, ptr %t2104
  %t2115 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t2113, ptr %t2115
  call void @__olang_scope_close(ptr %s0)
  store ptr %t2115, ptr %rv
  br label %ret
bb482:
  br label %bb483
bb483:
  %t2117 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t2117, ptr %l1007
  %t2118 = load i32, ptr %l2, !tbaa !23
  store i32 %t2118, ptr %l1008, !tbaa !23
  %t2119 = load ptr, ptr %l43, !tbaa !29
  store ptr %t2119, ptr %l1009, !tbaa !29
  %t2120 = load ptr, ptr %l0, !tbaa !29
  %t2121 = load %"compiler/source:Span", ptr %l3
  %t2125 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %t2120, i32 2, %"compiler/source:Span" %t2121)
  store i32 %t2125, ptr %l1013
  br label %bb484
bb484:
  %t2126 = load ptr, ptr %l1009, !tbaa !29
  %t2127 = load i32, ptr %l1013, !tbaa !23
  %t2128 = call %"compiler/typed:Promote" @compiler_2ftyped_3aPromote_2ector(ptr %v0, ptr %v0, ptr %t2126, i32 %t2127)
  store %"compiler/typed:Promote" %t2128, ptr %l1014
  br label %bb485
bb485:
  %t2129 = load %"compiler/typed:Promote", ptr %l1014
  %t2130 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store %"compiler/typed:Promote" %t2129, ptr %t2130
  store { i64, [5 x i64] } zeroinitializer, ptr %t2131
  %t2132 = getelementptr { i64, [5 x i64] }, ptr %t2131, i32 0, i32 0
  store i64 5, ptr %t2132
  %t2133 = load %"compiler/source:Span", ptr %l1007
  %t2134 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t2133, 0
  %t2135 = load i32, ptr %l1008, !tbaa !23
  %t2136 = insertvalue { %"compiler/source:Span", i32, ptr } %t2134, i32 %t2135, 1
  %t2138 = insertvalue { %"compiler/source:Span", i32, ptr } %t2136, ptr %t2130, 2
  %t2139 = getelementptr { i64, [5 x i64] }, ptr %t2131, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t2138, ptr %t2139
  %t2140 = load { i64, [5 x i64] }, ptr %t2131
  %t2142 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t2140, ptr %t2142
  call void @__olang_scope_close(ptr %s0)
  store ptr %t2142, ptr %rv
  br label %ret
bb486:
  br label %bb487
bb487:
  %t2144 = load i32, ptr %l6
  %t2146 = trunc i64 20 to i32
  %t2147 = icmp eq i32 %t2144, %t2146
  br i1 %t2147, label %bb488, label %bb489
bb488:
  %t2149 = load i32, ptr %l7
  %t2151 = trunc i64 20 to i32
  %t2152 = icmp eq i32 %t2149, %t2151
  store i1 %t2152, ptr %l1020, !tbaa !21
  br label %bb490
bb489:
  store i1 false, ptr %l1020, !tbaa !21
  br label %bb490
bb490:
  %t2154 = load i1, ptr %l1020, !tbaa !21
  br i1 %t2154, label %bb491, label %bb492
bb491:
  %t2155 = load ptr, ptr %l0, !tbaa !29
  %t2157 = getelementptr %"compiler/check:Checker", ptr %t2155, i32 0, i32 1
  %t2158 = load ptr, ptr %t2157, !tbaa !29
  %t2160 = getelementptr %"compiler/generic:Program", ptr %t2158, i32 0, i32 2
  %t2161 = load i32, ptr %l4, !tbaa !23
  %t2164 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t2160, i32 %t2161)
  store i32 %t2164, ptr %l1027
  br label %bb493
bb492:
  br label %bb570
bb493:
  %t2165 = load i32, ptr %l1027, !tbaa !23
  store i32 %t2165, ptr %l44, !tbaa !23
  %t2166 = load ptr, ptr %l0, !tbaa !29
  %t2168 = getelementptr %"compiler/check:Checker", ptr %t2166, i32 0, i32 1
  %t2169 = load ptr, ptr %t2168, !tbaa !29
  %t2171 = getelementptr %"compiler/generic:Program", ptr %t2169, i32 0, i32 2
  %t2172 = load i32, ptr %l2, !tbaa !23
  %t2175 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t2171, i32 %t2172)
  store i32 %t2175, ptr %l1032
  br label %bb494
bb494:
  %t2176 = load i32, ptr %l1032, !tbaa !23
  store i32 %t2176, ptr %l45, !tbaa !23
  %t2177 = load ptr, ptr %l0, !tbaa !29
  %t2179 = getelementptr %"compiler/check:Checker", ptr %t2177, i32 0, i32 1
  %t2180 = load ptr, ptr %t2179, !tbaa !29
  %t2182 = getelementptr %"compiler/generic:Program", ptr %t2180, i32 0, i32 2
  %t2183 = load i32, ptr %l44, !tbaa !23
  %t2184 = load i32, ptr %l45, !tbaa !23
  %t2188 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t2182, i32 %t2183, i32 %t2184)
  store i1 %t2188, ptr %l1038
  br label %bb495
bb495:
  %t2189 = load i1, ptr %l1038, !tbaa !21
  br i1 %t2189, label %bb496, label %bb497
bb496:
  store i1 true, ptr %l1039, !tbaa !21
  br label %bb499
bb497:
  %t2190 = load ptr, ptr %l0, !tbaa !29
  %t2191 = load i32, ptr %l44, !tbaa !23
  %t2192 = load i32, ptr %l45, !tbaa !23
  %t2196 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eflowsInto(ptr %v0, ptr %t2190, i32 %t2191, i32 %t2192)
  store i1 %t2196, ptr %l1043
  br label %bb498
bb498:
  %t2197 = load i1, ptr %l1043, !tbaa !21
  store i1 %t2197, ptr %l1039, !tbaa !21
  br label %bb499
bb499:
  %t2198 = load i1, ptr %l1039, !tbaa !21
  br i1 %t2198, label %bb500, label %bb501
bb500:
  %t2199 = load ptr, ptr %l0, !tbaa !29
  %t2200 = load i32, ptr %l4, !tbaa !23
  %t2203 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eforeignRef(ptr %v0, ptr %t2199, i32 %t2200)
  store i1 %t2203, ptr %l1046
  br label %bb502
bb501:
  br label %bb569
bb502:
  %t2204 = load i1, ptr %l1046, !tbaa !21
  br i1 %t2204, label %bb503, label %bb504
bb503:
  %t2205 = load ptr, ptr %l0, !tbaa !29
  %t2207 = getelementptr %"compiler/check:Checker", ptr %t2205, i32 0, i32 1
  %t2208 = load ptr, ptr %t2207, !tbaa !29
  %t2210 = getelementptr %"compiler/generic:Program", ptr %t2208, i32 0, i32 2
  %t2211 = load i32, ptr %l44, !tbaa !23
  %t2212 = load i32, ptr %l45, !tbaa !23
  %t2216 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t2210, i32 %t2211, i32 %t2212)
  store i1 %t2216, ptr %l1053
  br label %bb505
bb504:
  store i1 false, ptr %l1047, !tbaa !21
  br label %bb506
bb505:
  %t2217 = load i1, ptr %l1053, !tbaa !21
  store i1 %t2217, ptr %l1047, !tbaa !21
  br label %bb506
bb506:
  %t2218 = load i1, ptr %l1047, !tbaa !21
  br i1 %t2218, label %bb507, label %bb508
bb507:
  %t2219 = load ptr, ptr %l0, !tbaa !29
  %t2221 = getelementptr %"compiler/check:Checker", ptr %t2219, i32 0, i32 1
  %t2222 = load ptr, ptr %t2221, !tbaa !29
  %t2224 = getelementptr %"compiler/generic:Program", ptr %t2222, i32 0, i32 2
  %t2225 = load i32, ptr %l2, !tbaa !23
  %t2228 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t2224, i32 %t2225)
  store i64 %t2228, ptr %l1059
  br label %bb509
bb508:
  store i1 false, ptr %l1054, !tbaa !21
  br label %bb510
bb509:
  %t2229 = load i64, ptr @G_2ecompiler_2ftypes_2eOwning, !tbaa !24
  %t2230 = load i64, ptr %l1059, !tbaa !24
  %t2232 = and i64 %t2230, %t2229
  %t2234 = icmp eq i64 %t2232, 0
  store i1 %t2234, ptr %l1054, !tbaa !21
  br label %bb510
bb510:
  %t2236 = load i1, ptr %l1054, !tbaa !21
  br i1 %t2236, label %bb511, label %bb512
bb511:
  %t2237 = load ptr, ptr %l0, !tbaa !29
  %t2239 = getelementptr %"compiler/check:Checker", ptr %t2237, i32 0, i32 1
  %t2240 = load ptr, ptr %t2239, !tbaa !29
  %t2242 = getelementptr %"compiler/generic:Program", ptr %t2240, i32 0, i32 2
  %t2243 = load i32, ptr %l4, !tbaa !23
  %t2246 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t2242, i32 %t2243)
  store i64 %t2246, ptr %l1067
  br label %bb513
bb512:
  br label %bb519
bb513:
  %t2247 = load ptr, ptr %l0, !tbaa !29
  %t2249 = getelementptr %"compiler/check:Checker", ptr %t2247, i32 0, i32 1
  %t2250 = load ptr, ptr %t2249, !tbaa !29
  %t2252 = getelementptr %"compiler/generic:Program", ptr %t2250, i32 0, i32 2
  %t2253 = load i32, ptr %l2, !tbaa !23
  %t2256 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t2252, i32 %t2253)
  store i64 %t2256, ptr %l1072
  br label %bb514
bb514:
  %t2257 = load i64, ptr %l1067, !tbaa !24
  %t2258 = load i64, ptr %l1072, !tbaa !24
  %t2259 = icmp ne i64 %t2257, %t2258
  br i1 %t2259, label %bb515, label %bb516
bb515:
  %t2261 = load ptr, ptr %l0, !tbaa !29
  %t2262 = load %"compiler/source:Span", ptr %l3
  %t2263 = load ptr, ptr %l1, !tbaa !29
  %t2264 = load i32, ptr %l2, !tbaa !23
  %t2269 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %t2261, %"compiler/source:Span" %t2262, ptr %t2263, i32 %t2264)
  store ptr %t2269, ptr %l1079
  br label %bb517
bb516:
  %t2270 = load ptr, ptr %l1, !tbaa !29
  store ptr %t2270, ptr %l1074, !tbaa !29
  br label %bb518
bb517:
  %t2272 = load ptr, ptr %l1079, !tbaa !29
  store ptr %t2272, ptr %l1074, !tbaa !29
  br label %bb518
bb518:
  call void @__olang_scope_close(ptr %s0)
  %t2273 = load ptr, ptr %l1074, !tbaa !29
  store ptr %t2273, ptr %rv
  br label %ret
bb519:
  %t2274 = load ptr, ptr %l0, !tbaa !29
  %t2276 = getelementptr %"compiler/check:Checker", ptr %t2274, i32 0, i32 1
  %t2277 = load ptr, ptr %t2276, !tbaa !29
  %t2279 = getelementptr %"compiler/generic:Program", ptr %t2277, i32 0, i32 2
  %t2280 = load i32, ptr %l2, !tbaa !23
  %t2283 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t2279, i32 %t2280)
  store i64 %t2283, ptr %l1085
  br label %bb520
bb520:
  %t2284 = load i64, ptr @G_2ecompiler_2ftypes_2eOwning, !tbaa !24
  %t2285 = load i64, ptr %l1085, !tbaa !24
  %t2287 = and i64 %t2285, %t2284
  store i64 %t2287, ptr %l1087, !tbaa !24
  %t2288 = load ptr, ptr %l0, !tbaa !29
  %t2290 = getelementptr %"compiler/check:Checker", ptr %t2288, i32 0, i32 1
  %t2291 = load ptr, ptr %t2290, !tbaa !29
  %t2293 = getelementptr %"compiler/generic:Program", ptr %t2291, i32 0, i32 2
  %t2294 = load i32, ptr %l4, !tbaa !23
  %t2297 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t2293, i32 %t2294)
  store i64 %t2297, ptr %l1092
  br label %bb521
bb521:
  %t2298 = load i64, ptr @G_2ecompiler_2ftypes_2eOwning, !tbaa !24
  %t2299 = load i64, ptr %l1092, !tbaa !24
  %t2301 = and i64 %t2299, %t2298
  %t2302 = load i64, ptr %l1087, !tbaa !24
  %t2304 = icmp ne i64 %t2302, %t2301
  br i1 %t2304, label %bb522, label %bb523
bb522:
  %t2306 = load ptr, ptr %l0, !tbaa !29
  %t2308 = getelementptr %"compiler/check:Checker", ptr %t2306, i32 0, i32 1
  %t2309 = load ptr, ptr %t2308, !tbaa !29
  %t2311 = getelementptr %"compiler/generic:Program", ptr %t2309, i32 0, i32 2
  %t2312 = load i32, ptr %l2, !tbaa !23
  %t2315 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t2311, i32 %t2312)
  store i64 %t2315, ptr %l1101
  br label %bb524
bb523:
  store i1 false, ptr %l1096, !tbaa !21
  br label %bb529
bb524:
  %t2316 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t2317 = load i64, ptr %l1101, !tbaa !24
  %t2319 = and i64 %t2317, %t2316
  %t2321 = icmp ne i64 %t2319, 0
  br i1 %t2321, label %bb525, label %bb526
bb525:
  %t2323 = load ptr, ptr %l0, !tbaa !29
  %t2325 = getelementptr %"compiler/check:Checker", ptr %t2323, i32 0, i32 1
  %t2326 = load ptr, ptr %t2325, !tbaa !29
  %t2328 = getelementptr %"compiler/generic:Program", ptr %t2326, i32 0, i32 2
  %t2329 = load i32, ptr %l4, !tbaa !23
  %t2332 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t2328, i32 %t2329)
  store i64 %t2332, ptr %l1110
  br label %bb527
bb526:
  store i1 false, ptr %l1105, !tbaa !21
  br label %bb528
bb527:
  %t2333 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t2334 = load i64, ptr %l1110, !tbaa !24
  %t2336 = and i64 %t2334, %t2333
  %t2338 = icmp eq i64 %t2336, 0
  store i1 %t2338, ptr %l1105, !tbaa !21
  br label %bb528
bb528:
  %t2340 = load i1, ptr %l1105, !tbaa !21
  %t2341 = xor i1 %t2340, true
  store i1 %t2341, ptr %l1096, !tbaa !21
  br label %bb529
bb529:
  %t2343 = load i1, ptr %l1096, !tbaa !21
  br i1 %t2343, label %bb530, label %bb531
bb530:
  %t2344 = load ptr, ptr %l0, !tbaa !29
  store ptr %t2344, ptr %l1115, !tbaa !29
  %t2345 = load ptr, ptr %l0, !tbaa !29
  store ptr %t2345, ptr %l1116, !tbaa !29
  %t2346 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t2346, ptr %l1117
  %t2347 = load ptr, ptr %l1, !tbaa !29
  store ptr %t2347, ptr %l1118, !tbaa !29
  %t2348 = load ptr, ptr %l0, !tbaa !29
  %t2350 = getelementptr %"compiler/check:Checker", ptr %t2348, i32 0, i32 1
  %t2351 = load ptr, ptr %t2350, !tbaa !29
  %t2353 = getelementptr %"compiler/generic:Program", ptr %t2351, i32 0, i32 2
  store ptr %t2353, ptr %l1121, !tbaa !29
  %t2354 = load i32, ptr %l44, !tbaa !23
  store i32 %t2354, ptr %l1122, !tbaa !23
  %t2355 = load ptr, ptr %l0, !tbaa !29
  %t2357 = getelementptr %"compiler/check:Checker", ptr %t2355, i32 0, i32 1
  %t2358 = load ptr, ptr %t2357, !tbaa !29
  %t2360 = getelementptr %"compiler/generic:Program", ptr %t2358, i32 0, i32 2
  %t2361 = load i32, ptr %l4, !tbaa !23
  %t2364 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t2360, i32 %t2361)
  store i64 %t2364, ptr %l1127
  br label %bb532
bb531:
  br label %bb537
bb532:
  %t2365 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t2366 = load i64, ptr %l1127, !tbaa !24
  %t2368 = and i64 %t2366, %t2365
  store i64 %t2368, ptr %l1129, !tbaa !24
  %t2369 = load ptr, ptr %l0, !tbaa !29
  %t2371 = getelementptr %"compiler/check:Checker", ptr %t2369, i32 0, i32 1
  %t2372 = load ptr, ptr %t2371, !tbaa !29
  %t2374 = getelementptr %"compiler/generic:Program", ptr %t2372, i32 0, i32 2
  %t2375 = load i32, ptr %l2, !tbaa !23
  %t2378 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t2374, i32 %t2375)
  store i64 %t2378, ptr %l1134
  br label %bb533
bb533:
  %t2379 = load i64, ptr @G_2ecompiler_2ftypes_2eOwning, !tbaa !24
  %t2380 = load i64, ptr %l1134, !tbaa !24
  %t2382 = and i64 %t2380, %t2379
  %t2383 = load i64, ptr %l1129, !tbaa !24
  %t2385 = or i64 %t2383, %t2382
  %t2386 = load ptr, ptr %l1121, !tbaa !29
  %t2387 = load i32, ptr %l1122, !tbaa !23
  %t2389 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t2386, i32 %t2387, i64 %t2385)
  store i32 %t2389, ptr %l1138
  br label %bb534
bb534:
  %t2390 = load ptr, ptr %l1116, !tbaa !29
  %t2391 = load %"compiler/source:Span", ptr %l1117
  %t2392 = load ptr, ptr %l1118, !tbaa !29
  %t2393 = load i32, ptr %l1138, !tbaa !23
  %t2394 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %t2390, %"compiler/source:Span" %t2391, ptr %t2392, i32 %t2393)
  store ptr %t2394, ptr %l1139
  br label %bb535
bb535:
  %t2395 = load i32, ptr %l2, !tbaa !23
  %t2396 = load %"compiler/source:Span", ptr %l3
  %t2397 = load ptr, ptr %l1115, !tbaa !29
  %t2398 = load ptr, ptr %l1139, !tbaa !29
  %t2401 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %t2397, ptr %t2398, i32 %t2395, %"compiler/source:Span" %t2396)
  store ptr %t2401, ptr %l1142
  br label %bb536
bb536:
  call void @__olang_scope_close(ptr %s0)
  %t2402 = load ptr, ptr %l1142, !tbaa !29
  store ptr %t2402, ptr %rv
  br label %ret
bb537:
  %t2403 = load ptr, ptr %l0, !tbaa !29
  %t2405 = getelementptr %"compiler/check:Checker", ptr %t2403, i32 0, i32 1
  %t2406 = load ptr, ptr %t2405, !tbaa !29
  %t2408 = getelementptr %"compiler/generic:Program", ptr %t2406, i32 0, i32 2
  %t2409 = load i32, ptr %l2, !tbaa !23
  %t2412 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t2408, i32 %t2409)
  store i64 %t2412, ptr %l1147
  br label %bb538
bb538:
  %t2413 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t2414 = load i64, ptr %l1147, !tbaa !24
  %t2416 = and i64 %t2414, %t2413
  %t2418 = icmp ne i64 %t2416, 0
  br i1 %t2418, label %bb539, label %bb540
bb539:
  %t2420 = load ptr, ptr %l0, !tbaa !29
  %t2422 = getelementptr %"compiler/check:Checker", ptr %t2420, i32 0, i32 1
  %t2423 = load ptr, ptr %t2422, !tbaa !29
  %t2425 = getelementptr %"compiler/generic:Program", ptr %t2423, i32 0, i32 2
  %t2426 = load i32, ptr %l4, !tbaa !23
  %t2429 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t2425, i32 %t2426)
  store i64 %t2429, ptr %l1156
  br label %bb541
bb540:
  store i1 false, ptr %l1151, !tbaa !21
  br label %bb542
bb541:
  %t2430 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t2431 = load i64, ptr %l1156, !tbaa !24
  %t2433 = and i64 %t2431, %t2430
  %t2435 = icmp eq i64 %t2433, 0
  store i1 %t2435, ptr %l1151, !tbaa !21
  br label %bb542
bb542:
  %t2437 = load i1, ptr %l1151, !tbaa !21
  br i1 %t2437, label %bb543, label %bb544
bb543:
  store %olang.scope zeroinitializer, ptr %s64
  %t2438 = load ptr, ptr %l1, !tbaa !29
  %t2440 = call i1 @compiler_2fcheck_2eisData(ptr %v0, ptr %t2438)
  store i1 %t2440, ptr %l1161
  br label %bb545
bb544:
  br label %bb555
bb545:
  %t2441 = load i1, ptr %l1161, !tbaa !21
  br i1 %t2441, label %bb546, label %bb547
bb546:
  %t2442 = load ptr, ptr %l0, !tbaa !29
  store ptr %t2442, ptr %l1162, !tbaa !29
  %t2443 = load ptr, ptr %l0, !tbaa !29
  %t2444 = load %"compiler/source:Span", ptr %l3
  %t2445 = load %"compiler/source:Span", ptr %l3
  %t2446 = load i32, ptr %l44, !tbaa !23
  %t2447 = load ptr, ptr %l1, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t2448
  %t2449 = getelementptr { i64, [4 x i64] }, ptr %t2448, i32 0, i32 0
  store i64 2, ptr %t2449
  %t2451 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t2445, 0
  %t2453 = insertvalue { %"compiler/source:Span", i32, ptr } %t2451, i32 %t2446, 1
  %t2455 = insertvalue { %"compiler/source:Span", i32, ptr } %t2453, ptr %t2447, 2
  %t2456 = getelementptr { i64, [4 x i64] }, ptr %t2448, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t2455, ptr %t2456
  %t2457 = load { i64, [4 x i64] }, ptr %t2448
  %t2459 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t2457, ptr %t2459
  %t2463 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t2443, %"compiler/source:Span" %t2444, ptr %t2459)
  store ptr %t2463, ptr %l1170
  br label %bb548
bb547:
  br label %bb552
bb548:
  %t2464 = load i32, ptr %l45, !tbaa !23
  %t2465 = load %"compiler/source:Span", ptr %l3
  %t2466 = load ptr, ptr %l1162, !tbaa !29
  %t2467 = load ptr, ptr %l1170, !tbaa !29
  %t2470 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %t2466, ptr %t2467, i32 %t2464, %"compiler/source:Span" %t2465)
  store ptr %t2470, ptr %l1173
  br label %bb549
bb549:
  %t2471 = load ptr, ptr %l1173, !tbaa !29
  %t2472 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t2472, ptr %l1174
  %t2473 = load i32, ptr %l2, !tbaa !23
  store i32 %t2473, ptr %l1175, !tbaa !23
  store ptr %t2471, ptr %l1176, !tbaa !29
  %t2475 = load ptr, ptr %l0, !tbaa !29
  %t2476 = load %"compiler/source:Span", ptr %l3
  %t2480 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %t2475, i32 2, %"compiler/source:Span" %t2476)
  store i32 %t2480, ptr %l1180
  br label %bb550
bb550:
  %t2481 = load ptr, ptr %l1176, !tbaa !29
  %t2482 = load i32, ptr %l1180, !tbaa !23
  %t2483 = call %"compiler/typed:Promote" @compiler_2ftyped_3aPromote_2ector(ptr %v0, ptr %v0, ptr %t2481, i32 %t2482)
  store %"compiler/typed:Promote" %t2483, ptr %l1181
  br label %bb551
bb551:
  %t2484 = load %"compiler/typed:Promote", ptr %l1181
  %t2485 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store %"compiler/typed:Promote" %t2484, ptr %t2485
  store { i64, [5 x i64] } zeroinitializer, ptr %t2486
  %t2487 = getelementptr { i64, [5 x i64] }, ptr %t2486, i32 0, i32 0
  store i64 5, ptr %t2487
  %t2488 = load %"compiler/source:Span", ptr %l1174
  %t2489 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t2488, 0
  %t2490 = load i32, ptr %l1175, !tbaa !23
  %t2491 = insertvalue { %"compiler/source:Span", i32, ptr } %t2489, i32 %t2490, 1
  %t2493 = insertvalue { %"compiler/source:Span", i32, ptr } %t2491, ptr %t2485, 2
  %t2494 = getelementptr { i64, [5 x i64] }, ptr %t2486, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t2493, ptr %t2494
  %t2495 = load { i64, [5 x i64] }, ptr %t2486
  %t2497 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t2495, ptr %t2497
  call void @__olang_scope_close(ptr %s64)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t2497, ptr %rv
  br label %ret
bb552:
  %t2499 = load ptr, ptr %l0, !tbaa !29
  store ptr %t2499, ptr %l1185, !tbaa !29
  %t2500 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t2500, ptr %l1186
  %t2501 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eReadOnlyToWritable(ptr %s64)
  store %"compiler/msgs:Msg" %t2501, ptr %l1187
  br label %bb553
bb553:
  %t2502 = load ptr, ptr %l1185, !tbaa !29
  %t2503 = load %"compiler/source:Span", ptr %l1186
  %t2504 = load %"compiler/msgs:Msg", ptr %l1187
  %t2505 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s64, ptr %t2502, %"compiler/source:Span" %t2503, %"compiler/msgs:Msg" %t2504)
  store i64 %t2505, ptr %l1188
  br label %bb554
bb554:
  %t2506 = load ptr, ptr %l1, !tbaa !29
  call void @__olang_scope_close(ptr %s64)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t2506, ptr %rv
  br label %ret
bb555:
  %t2508 = load ptr, ptr %l0, !tbaa !29
  %t2510 = getelementptr %"compiler/check:Checker", ptr %t2508, i32 0, i32 1
  %t2511 = load ptr, ptr %t2510, !tbaa !29
  %t2513 = getelementptr %"compiler/generic:Program", ptr %t2511, i32 0, i32 2
  %t2514 = load i32, ptr %l2, !tbaa !23
  %t2517 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t2513, i32 %t2514)
  store i64 %t2517, ptr %l1194
  br label %bb556
bb556:
  %t2518 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t2519 = load i64, ptr %l1194, !tbaa !24
  %t2521 = and i64 %t2519, %t2518
  %t2523 = icmp ne i64 %t2521, 0
  br i1 %t2523, label %bb557, label %bb558
bb557:
  %t2525 = load ptr, ptr %l0, !tbaa !29
  %t2526 = load ptr, ptr %l1, !tbaa !29
  %t2527 = load %"compiler/source:Span", ptr %l3
  %t2531 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroWritableRef(ptr %v0, ptr %v0, ptr %t2525, ptr %t2526, %"compiler/source:Span" %t2527)
  store i1 %t2531, ptr %l1202
  br label %bb559
bb558:
  store i1 false, ptr %l1198, !tbaa !21
  br label %bb560
bb559:
  %t2532 = load i1, ptr %l1202, !tbaa !21
  %t2533 = xor i1 %t2532, true
  store i1 %t2533, ptr %l1198, !tbaa !21
  br label %bb560
bb560:
  %t2535 = load i1, ptr %l1198, !tbaa !21
  br i1 %t2535, label %bb561, label %bb562
bb561:
  %t2536 = load ptr, ptr %l1, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t2536, ptr %rv
  br label %ret
bb562:
  br label %bb563
bb563:
  %t2538 = load ptr, ptr %l0, !tbaa !29
  %t2540 = getelementptr %"compiler/check:Checker", ptr %t2538, i32 0, i32 1
  %t2541 = load ptr, ptr %t2540, !tbaa !29
  %t2543 = getelementptr %"compiler/generic:Program", ptr %t2541, i32 0, i32 2
  %t2544 = load i32, ptr %l44, !tbaa !23
  %t2545 = load i32, ptr %l45, !tbaa !23
  %t2549 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t2543, i32 %t2544, i32 %t2545)
  store i1 %t2549, ptr %l1210
  br label %bb564
bb564:
  %t2550 = load i1, ptr %l1210, !tbaa !21
  br i1 %t2550, label %bb565, label %bb566
bb565:
  %t2551 = load ptr, ptr %l1, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t2551, ptr %rv
  br label %ret
bb566:
  br label %bb567
bb567:
  %t2553 = load ptr, ptr %l0, !tbaa !29
  %t2554 = load %"compiler/source:Span", ptr %l3
  %t2555 = load ptr, ptr %l1, !tbaa !29
  %t2556 = load i32, ptr %l2, !tbaa !23
  %t2561 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %t2553, %"compiler/source:Span" %t2554, ptr %t2555, i32 %t2556)
  store ptr %t2561, ptr %l1216
  br label %bb568
bb568:
  call void @__olang_scope_close(ptr %s0)
  %t2562 = load ptr, ptr %l1216, !tbaa !29
  store ptr %t2562, ptr %rv
  br label %ret
bb569:
  br label %bb570
bb570:
  %t2563 = load ptr, ptr %l0, !tbaa !29
  %t2564 = load i32, ptr %l4, !tbaa !23
  %t2565 = load i32, ptr %l2, !tbaa !23
  %t2569 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eflowsInto(ptr %v0, ptr %t2563, i32 %t2564, i32 %t2565)
  store i1 %t2569, ptr %l1220
  br label %bb571
bb571:
  %t2570 = load i1, ptr %l1220, !tbaa !21
  br i1 %t2570, label %bb572, label %bb573
bb572:
  %t2571 = load ptr, ptr %l0, !tbaa !29
  %t2572 = load %"compiler/source:Span", ptr %l3
  %t2573 = load ptr, ptr %l1, !tbaa !29
  %t2574 = load i32, ptr %l2, !tbaa !23
  %t2579 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %t2571, %"compiler/source:Span" %t2572, ptr %t2573, i32 %t2574)
  store ptr %t2579, ptr %l1225
  br label %bb574
bb573:
  br label %bb575
bb574:
  call void @__olang_scope_close(ptr %s0)
  %t2580 = load ptr, ptr %l1225, !tbaa !29
  store ptr %t2580, ptr %rv
  br label %ret
bb575:
  %t2581 = load i32, ptr %l7
  %t2583 = trunc i64 19 to i32
  %t2584 = icmp eq i32 %t2581, %t2583
  br i1 %t2584, label %bb576, label %bb577
bb576:
  %t2586 = load ptr, ptr %l0, !tbaa !29
  %t2588 = getelementptr %"compiler/check:Checker", ptr %t2586, i32 0, i32 1
  %t2589 = load ptr, ptr %t2588, !tbaa !29
  %t2591 = getelementptr %"compiler/generic:Program", ptr %t2589, i32 0, i32 2
  %t2592 = load i32, ptr %l2, !tbaa !23
  %t2595 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t2591, i32 %t2592)
  store i32 %t2595, ptr %l1233
  br label %bb578
bb577:
  store i1 false, ptr %l1228, !tbaa !21
  br label %bb579
bb578:
  %t2596 = load i32, ptr %l1233, !tbaa !23
  %t2597 = icmp ne i32 %t2596, 0
  store i1 %t2597, ptr %l1228, !tbaa !21
  br label %bb579
bb579:
  %t2599 = load i1, ptr %l1228, !tbaa !21
  br i1 %t2599, label %bb580, label %bb581
bb580:
  %t2600 = load ptr, ptr %l1, !tbaa !29
  store ptr %t2600, ptr %l47, !tbaa !29
  %t2602 = load i32, ptr %l4, !tbaa !23
  store i32 %t2602, ptr %l48, !tbaa !23
  %t2604 = load i32, ptr %l6
  %t2606 = trunc i64 20 to i32
  %t2607 = icmp eq i32 %t2604, %t2606
  br i1 %t2607, label %bb582, label %bb583
bb581:
  br label %bb614
bb582:
  %t2609 = load ptr, ptr %l0, !tbaa !29
  %t2611 = getelementptr %"compiler/check:Checker", ptr %t2609, i32 0, i32 1
  %t2612 = load ptr, ptr %t2611, !tbaa !29
  %t2614 = getelementptr %"compiler/generic:Program", ptr %t2612, i32 0, i32 2
  %t2615 = load i32, ptr %l4, !tbaa !23
  %t2618 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t2614, i32 %t2615)
  store i32 %t2618, ptr %l1243
  br label %bb584
bb583:
  br label %bb586
bb584:
  %t2619 = load i32, ptr %l1243, !tbaa !23
  store i32 %t2619, ptr %l48, !tbaa !23
  %t2620 = load ptr, ptr %l0, !tbaa !29
  %t2621 = load %"compiler/source:Span", ptr %l3
  %t2622 = load %"compiler/source:Span", ptr %l3
  %t2623 = load i32, ptr %l48, !tbaa !23
  %t2624 = load ptr, ptr %l1, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t2625
  %t2626 = getelementptr { i64, [4 x i64] }, ptr %t2625, i32 0, i32 0
  store i64 2, ptr %t2626
  %t2628 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t2622, 0
  %t2630 = insertvalue { %"compiler/source:Span", i32, ptr } %t2628, i32 %t2623, 1
  %t2632 = insertvalue { %"compiler/source:Span", i32, ptr } %t2630, ptr %t2624, 2
  %t2633 = getelementptr { i64, [4 x i64] }, ptr %t2625, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t2632, ptr %t2633
  %t2634 = load { i64, [4 x i64] }, ptr %t2625
  %t2636 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t2634, ptr %t2636
  %t2640 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t2620, %"compiler/source:Span" %t2621, ptr %t2636)
  store ptr %t2640, ptr %l1251
  br label %bb585
bb585:
  %t2641 = load ptr, ptr %l1251, !tbaa !29
  store ptr %t2641, ptr %l47, !tbaa !29
  br label %bb586
bb586:
  %t2642 = load ptr, ptr %l0, !tbaa !29
  %t2643 = load i32, ptr %l48, !tbaa !23
  %t2646 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t2642, i32 %t2643)
  store i32 %t2646, ptr %l1254
  br label %bb587
bb587:
  %t2647 = load i32, ptr %l1254, !tbaa !23
  store i32 %t2647, ptr %l49, !tbaa !23
  %t2648 = load ptr, ptr %l0, !tbaa !29
  %t2650 = getelementptr %"compiler/check:Checker", ptr %t2648, i32 0, i32 1
  %t2651 = load ptr, ptr %t2650, !tbaa !29
  %t2653 = getelementptr %"compiler/generic:Program", ptr %t2651, i32 0, i32 2
  %t2654 = load i32, ptr %l49, !tbaa !23
  %t2657 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t2653, i32 %t2654)
  store i32 %t2657, ptr %l1259
  br label %bb588
bb588:
  %t2658 = load i32, ptr %l1259
  %t2660 = trunc i64 19 to i32
  %t2661 = icmp eq i32 %t2658, %t2660
  br i1 %t2661, label %bb589, label %bb590
bb589:
  %t2663 = load ptr, ptr %l0, !tbaa !29
  %t2665 = getelementptr %"compiler/check:Checker", ptr %t2663, i32 0, i32 1
  %t2666 = load ptr, ptr %t2665, !tbaa !29
  %t2668 = getelementptr %"compiler/generic:Program", ptr %t2666, i32 0, i32 2
  %t2669 = load i32, ptr %l49, !tbaa !23
  %t2672 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t2668, i32 %t2669)
  store i32 %t2672, ptr %l1267
  br label %bb591
bb590:
  store i1 false, ptr %l1262, !tbaa !21
  br label %bb592
bb591:
  %t2673 = load i32, ptr %l1267, !tbaa !23
  %t2674 = icmp eq i32 %t2673, 0
  store i1 %t2674, ptr %l1262, !tbaa !21
  br label %bb592
bb592:
  %t2676 = load i1, ptr %l1262, !tbaa !21
  br i1 %t2676, label %bb593, label %bb594
bb593:
  %t2677 = load ptr, ptr %l0, !tbaa !29
  store ptr %t2677, ptr %l1270, !tbaa !29
  %t2678 = load ptr, ptr %l0, !tbaa !29
  %t2680 = getelementptr %"compiler/check:Checker", ptr %t2678, i32 0, i32 1
  %t2681 = load ptr, ptr %t2680, !tbaa !29
  %t2683 = getelementptr %"compiler/generic:Program", ptr %t2681, i32 0, i32 2
  %t2684 = load i32, ptr %l49, !tbaa !23
  %t2687 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t2683, i32 %t2684)
  store i32 %t2687, ptr %l1275
  br label %bb595
bb594:
  store i1 false, ptr %l1269, !tbaa !21
  br label %bb598
bb595:
  %t2688 = load ptr, ptr %l0, !tbaa !29
  %t2690 = getelementptr %"compiler/check:Checker", ptr %t2688, i32 0, i32 1
  %t2691 = load ptr, ptr %t2690, !tbaa !29
  %t2693 = getelementptr %"compiler/generic:Program", ptr %t2691, i32 0, i32 2
  %t2694 = load i32, ptr %l2, !tbaa !23
  %t2697 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t2693, i32 %t2694)
  store i32 %t2697, ptr %l1280
  br label %bb596
bb596:
  %t2698 = load ptr, ptr %l1270, !tbaa !29
  %t2699 = load i32, ptr %l1275, !tbaa !23
  %t2700 = load i32, ptr %l1280, !tbaa !23
  %t2701 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esameRepr(ptr %v0, ptr %t2698, i32 %t2699, i32 %t2700)
  store i1 %t2701, ptr %l1281
  br label %bb597
bb597:
  %t2702 = load i1, ptr %l1281, !tbaa !21
  store i1 %t2702, ptr %l1269, !tbaa !21
  br label %bb598
bb598:
  %t2703 = load i1, ptr %l1269, !tbaa !21
  br i1 %t2703, label %bb599, label %bb600
bb599:
  %t2704 = load ptr, ptr %l0, !tbaa !29
  %t2706 = getelementptr %"compiler/check:Checker", ptr %t2704, i32 0, i32 1
  %t2707 = load ptr, ptr %t2706, !tbaa !29
  %t2709 = getelementptr %"compiler/generic:Program", ptr %t2707, i32 0, i32 2
  store ptr %t2709, ptr %l1284, !tbaa !29
  %t2710 = load ptr, ptr %l0, !tbaa !29
  %t2712 = getelementptr %"compiler/check:Checker", ptr %t2710, i32 0, i32 1
  %t2713 = load ptr, ptr %t2712, !tbaa !29
  %t2715 = getelementptr %"compiler/generic:Program", ptr %t2713, i32 0, i32 2
  %t2716 = load i32, ptr %l2, !tbaa !23
  %t2719 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t2715, i32 %t2716)
  store i32 %t2719, ptr %l1289
  br label %bb601
bb600:
  br label %bb613
bb601:
  %t2720 = load ptr, ptr %l1284, !tbaa !29
  %t2721 = load i32, ptr %l1289, !tbaa !23
  %t2722 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t2720, i32 %t2721)
  store i32 %t2722, ptr %l1290
  br label %bb602
bb602:
  %t2723 = load i32, ptr %l1290
  %t2725 = trunc i64 26 to i32
  %t2726 = icmp eq i32 %t2723, %t2725
  br i1 %t2726, label %bb603, label %bb604
bb603:
  store %olang.scope zeroinitializer, ptr %s72
  %t2728 = load ptr, ptr %l0, !tbaa !29
  store ptr %t2728, ptr %l1293, !tbaa !29
  %t2729 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t2729, ptr %l1294
  %t2730 = load ptr, ptr %l0, !tbaa !29
  %t2732 = getelementptr %"compiler/check:Checker", ptr %t2730, i32 0, i32 1
  %t2733 = load ptr, ptr %t2732, !tbaa !29
  %t2735 = getelementptr %"compiler/generic:Program", ptr %t2733, i32 0, i32 2
  store ptr %t2735, ptr %l1297, !tbaa !29
  %t2736 = load ptr, ptr %l0, !tbaa !29
  %t2738 = getelementptr %"compiler/check:Checker", ptr %t2736, i32 0, i32 1
  %t2739 = load ptr, ptr %t2738, !tbaa !29
  %t2741 = getelementptr %"compiler/generic:Program", ptr %t2739, i32 0, i32 2
  %t2742 = load i32, ptr %l2, !tbaa !23
  %t2745 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t2741, i32 %t2742)
  store i32 %t2745, ptr %l1302
  br label %bb605
bb604:
  br label %bb609
bb605:
  %t2746 = load ptr, ptr %l1297, !tbaa !29
  %t2747 = load i32, ptr %l1302, !tbaa !23
  %t2748 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %t2746, i32 %t2747)
  store i64 %t2748, ptr %l1303
  br label %bb606
bb606:
  %t2749 = load i64, ptr %l1303, !tbaa !24
  %t2750 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eArrayRunTimeIntoFixed(ptr %s72, i64 %t2749)
  store %"compiler/msgs:Msg" %t2750, ptr %l1304
  br label %bb607
bb607:
  %t2751 = load ptr, ptr %l1293, !tbaa !29
  %t2752 = load %"compiler/source:Span", ptr %l1294
  %t2753 = load %"compiler/msgs:Msg", ptr %l1304
  %t2754 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s72, ptr %t2751, %"compiler/source:Span" %t2752, %"compiler/msgs:Msg" %t2753)
  store i64 %t2754, ptr %l1305
  br label %bb608
bb608:
  %t2755 = load ptr, ptr %l1, !tbaa !29
  call void @__olang_scope_close(ptr %s72)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t2755, ptr %rv
  br label %ret
bb609:
  %t2757 = load ptr, ptr %l0, !tbaa !29
  %t2759 = getelementptr %"compiler/check:Checker", ptr %t2757, i32 0, i32 32
  %t2761 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t2759)
  store i64 %t2761, ptr %l1309
  br label %bb610
bb610:
  %t2762 = load i64, ptr %l1309, !tbaa !24
  store i64 %t2762, ptr %l50, !tbaa !24
  %t2763 = load ptr, ptr %l0, !tbaa !29
  %t2765 = getelementptr %"compiler/check:Checker", ptr %t2763, i32 0, i32 32
  %t2766 = load ptr, ptr %l47, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t2765, ptr %t2766)
  br label %bb611
bb611:
  %t2769 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t2769, ptr %l1313
  %t2770 = load i32, ptr %l2, !tbaa !23
  store i32 %t2770, ptr %l1314, !tbaa !23
  store i32 20, ptr %l1315
  store i32 1, ptr %l1316
  %t2771 = load ptr, ptr %l0, !tbaa !29
  %t2773 = getelementptr %"compiler/check:Checker", ptr %t2771, i32 0, i32 32
  %t2774 = load i64, ptr %l50, !tbaa !24
  %t2777 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t2773, i64 %t2774)
  store { i64, ptr } %t2777, ptr %l1320
  br label %bb612
bb612:
  store { i64, [5 x i64] } zeroinitializer, ptr %t2778
  %t2779 = getelementptr { i64, [5 x i64] }, ptr %t2778, i32 0, i32 0
  store i64 9, ptr %t2779
  %t2780 = load %"compiler/source:Span", ptr %l1313
  %t2781 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } undef, %"compiler/source:Span" %t2780, 0
  %t2782 = load i32, ptr %l1314, !tbaa !23
  %t2783 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t2781, i32 %t2782, 1
  %t2784 = load i32, ptr %l1315
  %t2785 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t2783, i32 %t2784, 2
  %t2786 = load i32, ptr %l1316
  %t2787 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t2785, i32 %t2786, 3
  %t2788 = load { i64, ptr }, ptr %l1320, !tbaa !27
  %t2789 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t2787, { i64, ptr } %t2788, 4
  %t2790 = getelementptr { i64, [5 x i64] }, ptr %t2778, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t2789, ptr %t2790
  %t2791 = load { i64, [5 x i64] }, ptr %t2778
  %t2793 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t2791, ptr %t2793
  call void @__olang_scope_close(ptr %s0)
  store ptr %t2793, ptr %rv
  br label %ret
bb613:
  br label %bb614
bb614:
  %t2795 = load i32, ptr %l6
  %t2797 = trunc i64 19 to i32
  %t2798 = icmp eq i32 %t2795, %t2797
  br i1 %t2798, label %bb615, label %bb616
bb615:
  %t2800 = load i32, ptr %l7
  %t2802 = trunc i64 19 to i32
  %t2803 = icmp eq i32 %t2800, %t2802
  store i1 %t2803, ptr %l1325, !tbaa !21
  br label %bb617
bb616:
  store i1 false, ptr %l1325, !tbaa !21
  br label %bb617
bb617:
  %t2805 = load i1, ptr %l1325, !tbaa !21
  br i1 %t2805, label %bb618, label %bb619
bb618:
  %t2806 = load ptr, ptr %l0, !tbaa !29
  %t2808 = getelementptr %"compiler/check:Checker", ptr %t2806, i32 0, i32 1
  %t2809 = load ptr, ptr %t2808, !tbaa !29
  %t2811 = getelementptr %"compiler/generic:Program", ptr %t2809, i32 0, i32 2
  store ptr %t2811, ptr %l1331, !tbaa !29
  %t2812 = load ptr, ptr %l0, !tbaa !29
  %t2814 = getelementptr %"compiler/check:Checker", ptr %t2812, i32 0, i32 1
  %t2815 = load ptr, ptr %t2814, !tbaa !29
  %t2817 = getelementptr %"compiler/generic:Program", ptr %t2815, i32 0, i32 2
  %t2818 = load i32, ptr %l4, !tbaa !23
  %t2821 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t2817, i32 %t2818)
  store i32 %t2821, ptr %l1336
  br label %bb620
bb619:
  store i1 false, ptr %l1328, !tbaa !21
  br label %bb623
bb620:
  %t2822 = load ptr, ptr %l0, !tbaa !29
  %t2824 = getelementptr %"compiler/check:Checker", ptr %t2822, i32 0, i32 1
  %t2825 = load ptr, ptr %t2824, !tbaa !29
  %t2827 = getelementptr %"compiler/generic:Program", ptr %t2825, i32 0, i32 2
  %t2828 = load i32, ptr %l2, !tbaa !23
  %t2831 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t2827, i32 %t2828)
  store i32 %t2831, ptr %l1341
  br label %bb621
bb621:
  %t2832 = load ptr, ptr %l1331, !tbaa !29
  %t2833 = load i32, ptr %l1336, !tbaa !23
  %t2834 = load i32, ptr %l1341, !tbaa !23
  %t2835 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t2832, i32 %t2833, i32 %t2834)
  store i1 %t2835, ptr %l1342
  br label %bb622
bb622:
  %t2836 = load i1, ptr %l1342, !tbaa !21
  store i1 %t2836, ptr %l1328, !tbaa !21
  br label %bb623
bb623:
  %t2837 = load i1, ptr %l1328, !tbaa !21
  br i1 %t2837, label %bb624, label %bb625
bb624:
  %t2838 = load ptr, ptr %l0, !tbaa !29
  %t2840 = getelementptr %"compiler/check:Checker", ptr %t2838, i32 0, i32 1
  %t2841 = load ptr, ptr %t2840, !tbaa !29
  %t2843 = getelementptr %"compiler/generic:Program", ptr %t2841, i32 0, i32 2
  store ptr %t2843, ptr %l1346, !tbaa !29
  %t2844 = load ptr, ptr %l0, !tbaa !29
  %t2846 = getelementptr %"compiler/check:Checker", ptr %t2844, i32 0, i32 1
  %t2847 = load ptr, ptr %t2846, !tbaa !29
  %t2849 = getelementptr %"compiler/generic:Program", ptr %t2847, i32 0, i32 2
  %t2850 = load i32, ptr %l4, !tbaa !23
  %t2853 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t2849, i32 %t2850)
  store i32 %t2853, ptr %l1351
  br label %bb626
bb625:
  store i1 false, ptr %l1343, !tbaa !21
  br label %bb628
bb626:
  %t2854 = load ptr, ptr %l1346, !tbaa !29
  %t2855 = load i32, ptr %l1351, !tbaa !23
  %t2856 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t2854, i32 %t2855)
  store i32 %t2856, ptr %l1352
  br label %bb627
bb627:
  %t2857 = load i32, ptr %l1352
  %t2859 = trunc i64 26 to i32
  %t2860 = icmp eq i32 %t2857, %t2859
  store i1 %t2860, ptr %l1343, !tbaa !21
  br label %bb628
bb628:
  %t2862 = load i1, ptr %l1343, !tbaa !21
  br i1 %t2862, label %bb629, label %bb630
bb629:
  %t2863 = load ptr, ptr %l0, !tbaa !29
  %t2865 = getelementptr %"compiler/check:Checker", ptr %t2863, i32 0, i32 1
  %t2866 = load ptr, ptr %t2865, !tbaa !29
  %t2868 = getelementptr %"compiler/generic:Program", ptr %t2866, i32 0, i32 2
  store ptr %t2868, ptr %l1358, !tbaa !29
  %t2869 = load ptr, ptr %l0, !tbaa !29
  %t2871 = getelementptr %"compiler/check:Checker", ptr %t2869, i32 0, i32 1
  %t2872 = load ptr, ptr %t2871, !tbaa !29
  %t2874 = getelementptr %"compiler/generic:Program", ptr %t2872, i32 0, i32 2
  %t2875 = load i32, ptr %l2, !tbaa !23
  %t2878 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t2874, i32 %t2875)
  store i32 %t2878, ptr %l1363
  br label %bb631
bb630:
  store i1 false, ptr %l1355, !tbaa !21
  br label %bb633
bb631:
  %t2879 = load ptr, ptr %l1358, !tbaa !29
  %t2880 = load i32, ptr %l1363, !tbaa !23
  %t2881 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t2879, i32 %t2880)
  store i32 %t2881, ptr %l1364
  br label %bb632
bb632:
  %t2882 = load i32, ptr %l1364
  %t2884 = trunc i64 26 to i32
  %t2885 = icmp eq i32 %t2882, %t2884
  store i1 %t2885, ptr %l1355, !tbaa !21
  br label %bb633
bb633:
  %t2887 = load i1, ptr %l1355, !tbaa !21
  br i1 %t2887, label %bb634, label %bb635
bb634:
  store %olang.scope zeroinitializer, ptr %s73
  %t2888 = load ptr, ptr %l0, !tbaa !29
  store ptr %t2888, ptr %l1367, !tbaa !29
  %t2889 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t2889, ptr %l1368
  %t2890 = load ptr, ptr %l0, !tbaa !29
  %t2892 = getelementptr %"compiler/check:Checker", ptr %t2890, i32 0, i32 1
  %t2893 = load ptr, ptr %t2892, !tbaa !29
  %t2895 = getelementptr %"compiler/generic:Program", ptr %t2893, i32 0, i32 2
  store ptr %t2895, ptr %l1371, !tbaa !29
  %t2896 = load ptr, ptr %l0, !tbaa !29
  %t2898 = getelementptr %"compiler/check:Checker", ptr %t2896, i32 0, i32 1
  %t2899 = load ptr, ptr %t2898, !tbaa !29
  %t2901 = getelementptr %"compiler/generic:Program", ptr %t2899, i32 0, i32 2
  %t2902 = load i32, ptr %l4, !tbaa !23
  %t2905 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t2901, i32 %t2902)
  store i32 %t2905, ptr %l1376
  br label %bb636
bb635:
  br label %bb642
bb636:
  %t2906 = load ptr, ptr %l1371, !tbaa !29
  %t2907 = load i32, ptr %l1376, !tbaa !23
  %t2908 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %t2906, i32 %t2907)
  store i64 %t2908, ptr %l1377
  br label %bb637
bb637:
  %t2909 = load ptr, ptr %l0, !tbaa !29
  %t2911 = getelementptr %"compiler/check:Checker", ptr %t2909, i32 0, i32 1
  %t2912 = load ptr, ptr %t2911, !tbaa !29
  %t2914 = getelementptr %"compiler/generic:Program", ptr %t2912, i32 0, i32 2
  store ptr %t2914, ptr %l1380, !tbaa !29
  %t2915 = load ptr, ptr %l0, !tbaa !29
  %t2917 = getelementptr %"compiler/check:Checker", ptr %t2915, i32 0, i32 1
  %t2918 = load ptr, ptr %t2917, !tbaa !29
  %t2920 = getelementptr %"compiler/generic:Program", ptr %t2918, i32 0, i32 2
  %t2921 = load i32, ptr %l2, !tbaa !23
  %t2924 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t2920, i32 %t2921)
  store i32 %t2924, ptr %l1385
  br label %bb638
bb638:
  %t2925 = load ptr, ptr %l1380, !tbaa !29
  %t2926 = load i32, ptr %l1385, !tbaa !23
  %t2927 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %t2925, i32 %t2926)
  store i64 %t2927, ptr %l1386
  br label %bb639
bb639:
  %t2928 = load i64, ptr %l1377, !tbaa !24
  %t2929 = load i64, ptr %l1386, !tbaa !24
  %t2930 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eArraySizeMismatch(ptr %s73, i64 %t2928, i64 %t2929)
  store %"compiler/msgs:Msg" %t2930, ptr %l1387
  br label %bb640
bb640:
  %t2931 = load ptr, ptr %l1367, !tbaa !29
  %t2932 = load %"compiler/source:Span", ptr %l1368
  %t2933 = load %"compiler/msgs:Msg", ptr %l1387
  %t2934 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s73, ptr %t2931, %"compiler/source:Span" %t2932, %"compiler/msgs:Msg" %t2933)
  store i64 %t2934, ptr %l1388
  br label %bb641
bb641:
  %t2935 = load ptr, ptr %l1, !tbaa !29
  call void @__olang_scope_close(ptr %s73)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t2935, ptr %rv
  br label %ret
bb642:
  %t2937 = load ptr, ptr %l0, !tbaa !29
  store ptr %t2937, ptr %l1390, !tbaa !29
  %t2938 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t2938, ptr %l1391
  %t2939 = load ptr, ptr %l0, !tbaa !29
  %t2940 = load i32, ptr %l2, !tbaa !23
  %t2943 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t2939, i32 %t2940)
  store { i64, ptr } %t2943, ptr %l1394
  br label %bb643
bb643:
  %t2944 = load { i64, ptr }, ptr %l1394, !tbaa !27
  %t2945 = extractvalue { i64, ptr } %t2944, 0
  %t2946 = extractvalue { i64, ptr } %t2944, 1
  %t2947 = mul i64 %t2945, 1
  %t2948 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t2947)
  call void @llvm.memcpy.p0.p0.i64(ptr %t2948, ptr %t2946, i64 %t2947, i1 false)
  %t2949 = insertvalue { i64, ptr } undef, i64 %t2945, 0
  %t2950 = insertvalue { i64, ptr } %t2949, ptr %t2948, 1
  store { i64, ptr } %t2950, ptr %l1395, !tbaa !27
  %t2951 = load ptr, ptr %l0, !tbaa !29
  %t2952 = load ptr, ptr %l1, !tbaa !29
  %t2955 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etyOf(ptr %v0, ptr %v0, ptr %s0, ptr %t2951, ptr %t2952)
  store { i64, ptr } %t2955, ptr %l1398
  br label %bb644
bb644:
  %t2956 = load { i64, ptr }, ptr %l1398, !tbaa !27
  %t2957 = extractvalue { i64, ptr } %t2956, 0
  %t2958 = extractvalue { i64, ptr } %t2956, 1
  %t2959 = mul i64 %t2957, 1
  %t2960 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t2959)
  call void @llvm.memcpy.p0.p0.i64(ptr %t2960, ptr %t2958, i64 %t2959, i1 false)
  %t2961 = insertvalue { i64, ptr } undef, i64 %t2957, 0
  %t2962 = insertvalue { i64, ptr } %t2961, ptr %t2960, 1
  %t2963 = load { i64, ptr }, ptr %l1395, !tbaa !27
  %t2965 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeMismatch(ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t2963, { i64, ptr } %t2962)
  store %"compiler/msgs:Msg" %t2965, ptr %l1400
  br label %bb645
bb645:
  %t2966 = load ptr, ptr %l1390, !tbaa !29
  %t2967 = load %"compiler/source:Span", ptr %l1391
  %t2968 = load %"compiler/msgs:Msg", ptr %l1400
  %t2969 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s0, ptr %t2966, %"compiler/source:Span" %t2967, %"compiler/msgs:Msg" %t2968)
  store i64 %t2969, ptr %l1401
  br label %bb646
bb646:
  %t2970 = load ptr, ptr %l1, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t2970, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local { ptr, i1 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efitQuiet(ptr %v0, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i1
  %l12 = alloca i64
  %l17 = alloca i64
  %l22 = alloca ptr
  %l31 = alloca i64
  %rv = alloca { ptr, i1 }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 4
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCount(ptr %v0, ptr %t10)
  store i64 %t12, ptr %l12
  br label %bb1
bb1:
  %t13 = load i64, ptr %l12, !tbaa !24
  store i64 %t13, ptr %l4, !tbaa !24
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/check:Checker", ptr %t14, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t19 = getelementptr %"compiler/generic:Program", ptr %t17, i32 0, i32 0
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t22 = getelementptr %"compiler/load:Loader", ptr %t20, i32 0, i32 4
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t25 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eHold(ptr %v0, ptr %t23)
  store i64 %t25, ptr %l17
  br label %bb2
bb2:
  %t26 = load i64, ptr %l17, !tbaa !24
  store i64 %t26, ptr %l5, !tbaa !24
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t35 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %t27, ptr %a1, i32 %a2, %"compiler/source:Span" %a3)
  store ptr %t35, ptr %l22
  br label %bb3
bb3:
  %t36 = load ptr, ptr %l22, !tbaa !29
  store ptr %t36, ptr %l6, !tbaa !29
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/check:Checker", ptr %t37, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t42 = getelementptr %"compiler/generic:Program", ptr %t40, i32 0, i32 0
  %t43 = load ptr, ptr %t42, !tbaa !29
  %t45 = getelementptr %"compiler/load:Loader", ptr %t43, i32 0, i32 4
  %t46 = load ptr, ptr %t45, !tbaa !29
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eEndHold(ptr %v0, ptr %t46)
  br label %bb4
bb4:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/check:Checker", ptr %t48, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !29
  %t53 = getelementptr %"compiler/generic:Program", ptr %t51, i32 0, i32 0
  %t54 = load ptr, ptr %t53, !tbaa !29
  %t56 = getelementptr %"compiler/load:Loader", ptr %t54, i32 0, i32 4
  %t57 = load ptr, ptr %t56, !tbaa !29
  %t59 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCount(ptr %v0, ptr %t57)
  store i64 %t59, ptr %l31
  br label %bb5
bb5:
  %t60 = load i64, ptr %l4, !tbaa !24
  %t61 = load i64, ptr %l31, !tbaa !24
  %t63 = icmp eq i64 %t61, %t60
  store i1 %t63, ptr %l7, !tbaa !21
  %t65 = load i1, ptr %l7, !tbaa !21
  br i1 %t65, label %bb6, label %bb7
bb6:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/check:Checker", ptr %t67, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !29
  %t72 = getelementptr %"compiler/generic:Program", ptr %t70, i32 0, i32 0
  %t73 = load ptr, ptr %t72, !tbaa !29
  %t75 = getelementptr %"compiler/load:Loader", ptr %t73, i32 0, i32 4
  %t76 = load ptr, ptr %t75, !tbaa !29
  %t77 = load i64, ptr %l5, !tbaa !24
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eChoose(ptr %v0, ptr %t76, i64 %t77)
  br label %bb8
bb7:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/check:Checker", ptr %t80, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !29
  %t85 = getelementptr %"compiler/generic:Program", ptr %t83, i32 0, i32 0
  %t86 = load ptr, ptr %t85, !tbaa !29
  %t88 = getelementptr %"compiler/load:Loader", ptr %t86, i32 0, i32 4
  %t89 = load ptr, ptr %t88, !tbaa !29
  %t90 = load i64, ptr %l5, !tbaa !24
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eDrop(ptr %v0, ptr %t89, i64 %t90)
  br label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb10
bb10:
  %t93 = load ptr, ptr %l6, !tbaa !29
  %t94 = load i1, ptr %l7, !tbaa !21
  %t96 = insertvalue { ptr, i1 } undef, ptr %t93, 0
  %t98 = insertvalue { ptr, i1 } %t96, i1 %t94, 1
  store { ptr, i1 } %t98, ptr %rv
  br label %ret
ret:
  %rr = load { ptr, i1 }, ptr %rv
  ret { ptr, i1 } %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehasResultScope(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l6 = alloca ptr
  %l13 = alloca ptr
  %l15 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t1)
  store ptr %t3, ptr %l6
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l6, !tbaa !29
  %t6 = getelementptr %"compiler/check:frame", ptr %t4, i32 0, i32 0
  %t7 = load i64, ptr %t6, !tbaa !24
  %t9 = icmp slt i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/check:Checker", ptr %t12, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = getelementptr %"compiler/generic:Program", ptr %t15, i32 0, i32 2
  store ptr %t17, ptr %l13, !tbaa !29
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t18)
  store ptr %t20, ptr %l15
  br label %bb5
bb5:
  %t21 = load ptr, ptr %l15, !tbaa !29
  %t23 = getelementptr %"compiler/typed:Body", ptr %t21, i32 0, i32 2
  %t24 = load i32, ptr %t23, !tbaa !23
  %t25 = load ptr, ptr %l13, !tbaa !29
  %t27 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopeVarsOf(ptr %v0, ptr %s2, ptr %t25, i32 %t24)
  store { i64, ptr } %t27, ptr %l18
  br label %bb6
bb6:
  %t28 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t28, 0
  %t30 = extractvalue { i64, ptr } %t28, 1
  %t31 = mul i64 %t29, 8
  %t32 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t31)
  call void @llvm.memcpy.p0.p0.i64(ptr %t32, ptr %t30, i64 %t31, i1 false)
  %t33 = insertvalue { i64, ptr } undef, i64 %t29, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t32, 1
  store { i64, ptr } %t34, ptr %l1, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  %t36 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t36, 0
  store i64 %t38, ptr %l3, !tbaa !24
  br label %bb7
bb7:
  %t40 = load i64, ptr %l2, !tbaa !24
  %t41 = load i64, ptr %l3, !tbaa !24
  %t44 = icmp slt i64 %t40, %t41
  %t46 = xor i1 %t44, true
  br i1 %t46, label %bb8, label %bb9
bb8:
  br label %bb15
bb9:
  br label %bb10
bb10:
  %t48 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t48, ptr %l26, !tbaa !27
  %t49 = load i64, ptr %l2, !tbaa !24
  %t51 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !27
  %t53 = getelementptr i64, ptr %t52, i64 %t49
  %t54 = load i64, ptr %t53, !tbaa !34
  %t57 = load i64, ptr @G_2ecompiler_2ftypes_2eResultVar, !tbaa !24
  %t60 = icmp eq i64 %t54, %t57
  br i1 %t60, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  br label %bb14
bb14:
  %t63 = load i64, ptr %l2, !tbaa !24
  %t65 = add i64 %t63, 1
  store i64 %t65, ptr %l2, !tbaa !24
  br label %bb7
bb15:
  call void @__olang_scope_close(ptr %s2)
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2) #0 {
entry:
  %l8 = alloca i64
  %rv = alloca i64
  %t4 = alloca { i64, [2 x i64] }, align 8
  br label %start
start:
  br label %bb0
bb0:
  store { i64, [2 x i64] } zeroinitializer, ptr %t4
  %t5 = getelementptr { i64, [2 x i64] }, ptr %t4, i32 0, i32 0
  store i64 0, ptr %t5
  %t6 = load { i64, [2 x i64] }, ptr %t4
  %t12 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %a0, i32 0, %"compiler/source:Span" %a1, i32 %a2, i32 3, { i64, [2 x i64] } %t6)
  store i64 %t12, ptr %l8
  br label %bb1
bb1:
  %t13 = load i64, ptr %l8, !tbaa !24
  store i64 %t13, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsInst(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca i32
  %l8 = alloca i1
  %l21 = alloca i32
  %l27 = alloca i1
  %l32 = alloca i32
  %l35 = alloca ptr
  %l40 = alloca i32
  %l43 = alloca i1
  %l46 = alloca ptr
  %l51 = alloca i32
  %l54 = alloca i1
  %l57 = alloca ptr
  %l62 = alloca i32
  %l66 = alloca i1
  %l74 = alloca i32
  %l77 = alloca ptr
  %l82 = alloca i32
  %l86 = alloca i1
  %l91 = alloca ptr
  %l96 = alloca i32
  %l99 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l3, !tbaa !24
  %t3 = icmp sgt i64 %t1, 16
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb3
bb2:
  %t5 = load i32, ptr %l1, !tbaa !23
  %t6 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t9 = icmp eq i32 %t5, %t6
  store i1 %t9, ptr %l8, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l8, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  store i1 false, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t13 = load i32, ptr %l1, !tbaa !23
  %t14 = load i32, ptr %l2, !tbaa !23
  %t17 = icmp eq i32 %t13, %t14
  br i1 %t17, label %bb7, label %bb8
bb7:
  store i1 true, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/check:Checker", ptr %t20, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t25 = getelementptr %"compiler/generic:Program", ptr %t23, i32 0, i32 2
  %t26 = load i32, ptr %l1, !tbaa !23
  %t29 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t25, i32 %t26)
  store i32 %t29, ptr %l21
  br label %bb10
bb10:
  %t30 = load i32, ptr %l21
  store i32 %t30, ptr %l4
  %t31 = load i32, ptr %l4
  %t33 = trunc i64 18 to i32
  %t34 = icmp eq i32 %t31, %t33
  br i1 %t34, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb34
bb13:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/check:Checker", ptr %t36, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !29
  %t40 = load i32, ptr %l1, !tbaa !23
  %t43 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t39, i32 %t40)
  store i1 %t43, ptr %l27
  br label %bb14
bb14:
  %t44 = load i1, ptr %l27, !tbaa !21
  %t45 = xor i1 %t44, true
  br i1 %t45, label %bb15, label %bb16
bb15:
  store i1 false, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = load i32, ptr %l1, !tbaa !23
  %t52 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %t48, i32 %t49)
  store i32 %t52, ptr %l32
  br label %bb18
bb18:
  %t53 = load i32, ptr %l32
  store i32 %t53, ptr %l5
  %t54 = load i32, ptr %l5
  %t56 = trunc i64 0 to i32
  %t57 = icmp eq i32 %t54, %t56
  br i1 %t57, label %bb19, label %bb20
bb19:
  %t59 = load ptr, ptr %l0, !tbaa !29
  store ptr %t59, ptr %l35, !tbaa !29
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/check:Checker", ptr %t60, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !29
  %t65 = getelementptr %"compiler/generic:Program", ptr %t63, i32 0, i32 2
  %t66 = load i32, ptr %l1, !tbaa !23
  %t69 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t65, i32 %t66)
  store i32 %t69, ptr %l40
  br label %bb21
bb20:
  br label %bb23
bb21:
  %t70 = load i32, ptr %l2, !tbaa !23
  %t71 = load i64, ptr %l3, !tbaa !24
  %t72 = load ptr, ptr %l35, !tbaa !29
  %t73 = load i32, ptr %l40, !tbaa !23
  %t76 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistHoldsInst(ptr %v0, ptr %t72, i32 %t73, i32 %t70, i64 %t71)
  store i1 %t76, ptr %l43
  br label %bb22
bb22:
  %t77 = load i1, ptr %l43, !tbaa !21
  store i1 %t77, ptr %rv
  br label %ret
bb23:
  %t78 = load i32, ptr %l5
  %t80 = trunc i64 1 to i32
  %t81 = icmp eq i32 %t78, %t80
  br i1 %t81, label %bb24, label %bb25
bb24:
  %t83 = load ptr, ptr %l0, !tbaa !29
  store ptr %t83, ptr %l46, !tbaa !29
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/check:Checker", ptr %t84, i32 0, i32 1
  %t87 = load ptr, ptr %t86, !tbaa !29
  %t89 = getelementptr %"compiler/generic:Program", ptr %t87, i32 0, i32 2
  %t90 = load i32, ptr %l1, !tbaa !23
  %t93 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t89, i32 %t90)
  store i32 %t93, ptr %l51
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t94 = load i32, ptr %l2, !tbaa !23
  %t95 = load i64, ptr %l3, !tbaa !24
  %t96 = load ptr, ptr %l46, !tbaa !29
  %t97 = load i32, ptr %l51, !tbaa !23
  %t100 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistHoldsInst(ptr %v0, ptr %t96, i32 %t97, i32 %t94, i64 %t95)
  store i1 %t100, ptr %l54
  br label %bb27
bb27:
  %t101 = load i1, ptr %l54, !tbaa !21
  store i1 %t101, ptr %rv
  br label %ret
bb28:
  %t102 = load i32, ptr %l5
  %t104 = trunc i64 4 to i32
  %t105 = icmp eq i32 %t102, %t104
  br i1 %t105, label %bb29, label %bb30
bb29:
  %t107 = load ptr, ptr %l0, !tbaa !29
  store ptr %t107, ptr %l57, !tbaa !29
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/check:Checker", ptr %t108, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !29
  %t113 = getelementptr %"compiler/generic:Program", ptr %t111, i32 0, i32 2
  %t114 = load i32, ptr %l1, !tbaa !23
  %t117 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t113, i32 %t114)
  store i32 %t117, ptr %l62
  br label %bb31
bb30:
  br label %bb33
bb31:
  %t118 = load i32, ptr %l2, !tbaa !23
  %t119 = load i64, ptr %l3, !tbaa !24
  %t121 = add i64 %t119, 1
  %t122 = load ptr, ptr %l57, !tbaa !29
  %t123 = load i32, ptr %l62, !tbaa !23
  %t126 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsInst(ptr %v0, ptr %t122, i32 %t123, i32 %t118, i64 %t121)
  store i1 %t126, ptr %l66
  br label %bb32
bb32:
  %t127 = load i1, ptr %l66, !tbaa !21
  store i1 %t127, ptr %rv
  br label %ret
bb33:
  store i1 false, ptr %rv
  br label %ret
bb34:
  %t129 = load i32, ptr %l4
  %t131 = trunc i64 19 to i32
  %t132 = icmp eq i32 %t129, %t131
  br i1 %t132, label %bb35, label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb44
bb37:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr %"compiler/check:Checker", ptr %t134, i32 0, i32 1
  %t137 = load ptr, ptr %t136, !tbaa !29
  %t139 = getelementptr %"compiler/generic:Program", ptr %t137, i32 0, i32 2
  %t140 = load i32, ptr %l1, !tbaa !23
  %t143 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t139, i32 %t140)
  store i32 %t143, ptr %l74
  br label %bb38
bb38:
  %t144 = load i32, ptr %l74, !tbaa !23
  %t145 = icmp eq i32 %t144, 0
  br i1 %t145, label %bb39, label %bb40
bb39:
  store i1 false, ptr %rv
  br label %ret
bb40:
  br label %bb41
bb41:
  %t148 = load ptr, ptr %l0, !tbaa !29
  store ptr %t148, ptr %l77, !tbaa !29
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t151 = getelementptr %"compiler/check:Checker", ptr %t149, i32 0, i32 1
  %t152 = load ptr, ptr %t151, !tbaa !29
  %t154 = getelementptr %"compiler/generic:Program", ptr %t152, i32 0, i32 2
  %t155 = load i32, ptr %l1, !tbaa !23
  %t158 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t154, i32 %t155)
  store i32 %t158, ptr %l82
  br label %bb42
bb42:
  %t159 = load i32, ptr %l2, !tbaa !23
  %t160 = load i64, ptr %l3, !tbaa !24
  %t162 = add i64 %t160, 1
  %t163 = load ptr, ptr %l77, !tbaa !29
  %t164 = load i32, ptr %l82, !tbaa !23
  %t167 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsInst(ptr %v0, ptr %t163, i32 %t164, i32 %t159, i64 %t162)
  store i1 %t167, ptr %l86
  br label %bb43
bb43:
  %t168 = load i1, ptr %l86, !tbaa !21
  store i1 %t168, ptr %rv
  br label %ret
bb44:
  %t169 = load i32, ptr %l4
  %t171 = trunc i64 22 to i32
  %t172 = icmp eq i32 %t169, %t171
  br i1 %t172, label %bb45, label %bb46
bb45:
  br label %bb49
bb46:
  %t174 = load i32, ptr %l4
  %t176 = trunc i64 23 to i32
  %t177 = icmp eq i32 %t174, %t176
  br i1 %t177, label %bb47, label %bb48
bb47:
  br label %bb49
bb48:
  br label %bb52
bb49:
  %t179 = load ptr, ptr %l0, !tbaa !29
  store ptr %t179, ptr %l91, !tbaa !29
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t182 = getelementptr %"compiler/check:Checker", ptr %t180, i32 0, i32 1
  %t183 = load ptr, ptr %t182, !tbaa !29
  %t185 = getelementptr %"compiler/generic:Program", ptr %t183, i32 0, i32 2
  %t186 = load i32, ptr %l1, !tbaa !23
  %t189 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t185, i32 %t186)
  store i32 %t189, ptr %l96
  br label %bb50
bb50:
  %t190 = load i32, ptr %l2, !tbaa !23
  %t191 = load i64, ptr %l3, !tbaa !24
  %t192 = load ptr, ptr %l91, !tbaa !29
  %t193 = load i32, ptr %l96, !tbaa !23
  %t196 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistHoldsInst(ptr %v0, ptr %t192, i32 %t193, i32 %t190, i64 %t191)
  store i1 %t196, ptr %l99
  br label %bb51
bb51:
  %t197 = load i1, ptr %l99, !tbaa !21
  store i1 %t197, ptr %rv
  br label %ret
bb52:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einferredCtor(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, { i64, ptr } %a4, i32 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca %"compiler/generic:Binding"
  %lp13 = alloca ptr
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca ptr
  %l21 = alloca %"compiler/check:litv"
  %l22 = alloca i1
  %l23 = alloca ptr
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i32
  %l31 = alloca { i64, ptr }
  %l32 = alloca i32
  %l33 = alloca i32
  %l35 = alloca i32
  %l40 = alloca i32
  %l43 = alloca ptr
  %l46 = alloca i32
  %l47 = alloca i32
  %l52 = alloca i1
  %l57 = alloca i32
  %l60 = alloca i1
  %l65 = alloca i32
  %l68 = alloca i1
  %l73 = alloca i32
  %l80 = alloca ptr
  %l84 = alloca i32
  %l87 = alloca i32
  %l95 = alloca ptr
  %l99 = alloca i32
  %l105 = alloca ptr
  %l107 = alloca i64
  %l112 = alloca i64
  %l115 = alloca ptr
  %l120 = alloca i32
  %l121 = alloca { i64, ptr }
  %l124 = alloca %"compiler/generic:Binding"
  %l125 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l131 = alloca i64
  %l134 = alloca i64
  %l153 = alloca { i64, ptr }
  %l157 = alloca %"compiler/check:litv"
  %l159 = alloca i1
  %l161 = alloca { i64, ptr }
  %l164 = alloca i1
  %l166 = alloca i1
  %l169 = alloca { i64, ptr }
  %l172 = alloca i1
  %l177 = alloca ptr
  %l178 = alloca { i64, ptr }
  %l180 = alloca i32
  %l182 = alloca i32
  %l186 = alloca i32
  %l188 = alloca i32
  %l190 = alloca { i64, ptr }
  %l193 = alloca ptr
  %l194 = alloca i1
  %l197 = alloca ptr
  %l198 = alloca i1
  %l202 = alloca { i64, ptr }
  %l207 = alloca ptr
  %l212 = alloca i1
  %l217 = alloca i1
  %l220 = alloca i32
  %l223 = alloca i1
  %l226 = alloca i32
  %l229 = alloca ptr
  %l230 = alloca { i64, ptr }
  %l232 = alloca i32
  %l235 = alloca i32
  %l253 = alloca i64
  %l256 = alloca i64
  %l274 = alloca { i64, ptr }
  %l280 = alloca i1
  %l285 = alloca i1
  %l286 = alloca { i64, ptr }
  %l287 = alloca i64
  %l290 = alloca i32
  %l294 = alloca ptr
  %l299 = alloca i32
  %l300 = alloca { i64, ptr }
  %l301 = alloca ptr
  %l302 = alloca %"compiler/source:Span"
  %l305 = alloca %"compiler/msgs:Msg"
  %l306 = alloca i64
  %l309 = alloca ptr
  %l312 = alloca i1
  %l313 = alloca { i64, ptr }
  %l314 = alloca i64
  %l317 = alloca ptr
  %l322 = alloca i32
  %l324 = alloca i32
  %l327 = alloca ptr
  %l330 = alloca i32
  %l331 = alloca i32
  %l334 = alloca { i64, ptr }
  %l335 = alloca i64
  %l341 = alloca i32
  %l345 = alloca ptr
  %l346 = alloca i32
  %l351 = alloca i32
  %l352 = alloca i32
  %l356 = alloca i1
  %l358 = alloca i1
  %l362 = alloca i1
  %l366 = alloca ptr
  %l370 = alloca i32
  %l376 = alloca ptr
  %l379 = alloca i64
  %l384 = alloca ptr
  %l385 = alloca %"compiler/source:Span"
  %l386 = alloca %"compiler/source:Span"
  %l387 = alloca i32
  %l392 = alloca ptr
  %l393 = alloca { i64, ptr }
  %l395 = alloca { i64, ptr }
  %l396 = alloca ptr
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %rv = alloca ptr
  %t737 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  store i32 %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  store i32 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l5, !tbaa !23
  %t2 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t5 = icmp ne i32 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  store ptr %t12, ptr %l43, !tbaa !29
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load i32, ptr %l5, !tbaa !23
  %t17 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t13, i32 %t14)
  store i32 %t17, ptr %l46
  br label %bb3
bb2:
  %t18 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t18, ptr %l40, !tbaa !23
  br label %bb5
bb3:
  %t20 = load ptr, ptr %l43, !tbaa !29
  %t21 = load i32, ptr %l46, !tbaa !23
  %t22 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t20, i32 %t21)
  store i32 %t22, ptr %l47
  br label %bb4
bb4:
  %t23 = load i32, ptr %l47, !tbaa !23
  store i32 %t23, ptr %l40, !tbaa !23
  br label %bb5
bb5:
  %t24 = load i32, ptr %l40, !tbaa !23
  store i32 %t24, ptr %l6, !tbaa !23
  %t25 = load i32, ptr %l6, !tbaa !23
  %t26 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t29 = icmp ne i32 %t25, %t26
  br i1 %t29, label %bb6, label %bb7
bb6:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/check:Checker", ptr %t31, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t36 = getelementptr %"compiler/generic:Program", ptr %t34, i32 0, i32 2
  %t37 = load i32, ptr %l6, !tbaa !23
  %t40 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t36, i32 %t37)
  store i32 %t40, ptr %l57
  br label %bb8
bb7:
  store i1 false, ptr %l52, !tbaa !21
  br label %bb9
bb8:
  %t41 = load i32, ptr %l57
  %t43 = trunc i64 18 to i32
  %t44 = icmp eq i32 %t41, %t43
  store i1 %t44, ptr %l52, !tbaa !21
  br label %bb9
bb9:
  %t46 = load i1, ptr %l52, !tbaa !21
  br i1 %t46, label %bb10, label %bb11
bb10:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/check:Checker", ptr %t47, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !29
  %t52 = getelementptr %"compiler/generic:Program", ptr %t50, i32 0, i32 2
  %t53 = load i32, ptr %l6, !tbaa !23
  %t56 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t52, i32 %t53)
  store i32 %t56, ptr %l65
  br label %bb12
bb11:
  store i1 false, ptr %l60, !tbaa !21
  br label %bb13
bb12:
  %t57 = load i32, ptr %l3, !tbaa !23
  %t58 = load i32, ptr %l65, !tbaa !23
  %t60 = icmp eq i32 %t58, %t57
  store i1 %t60, ptr %l60, !tbaa !21
  br label %bb13
bb13:
  %t62 = load i1, ptr %l60, !tbaa !21
  br i1 %t62, label %bb14, label %bb15
bb14:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/check:Checker", ptr %t63, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t68 = getelementptr %"compiler/generic:Program", ptr %t66, i32 0, i32 2
  %t69 = load i32, ptr %l6, !tbaa !23
  %t72 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t68, i32 %t69)
  store i32 %t72, ptr %l73
  br label %bb16
bb15:
  store i1 false, ptr %l68, !tbaa !21
  br label %bb17
bb16:
  %t73 = load i32, ptr %l73, !tbaa !23
  %t74 = icmp ne i32 %t73, 0
  store i1 %t74, ptr %l68, !tbaa !21
  br label %bb17
bb17:
  %t76 = load i1, ptr %l68, !tbaa !21
  br i1 %t76, label %bb18, label %bb19
bb18:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t78 = load %"compiler/source:Span", ptr %l1
  %t79 = load %"compiler/source:Span", ptr %l2
  %t80 = load i32, ptr %l6, !tbaa !23
  %t81 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t87 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econstruct(ptr %v0, ptr %v1, ptr %t77, %"compiler/source:Span" %t78, %"compiler/source:Span" %t79, i32 %t80, { i64, ptr } %t81)
  store ptr %t87, ptr %l80
  br label %bb20
bb19:
  br label %bb21
bb20:
  call void @__olang_scope_close(ptr %s0)
  %t88 = load ptr, ptr %l80, !tbaa !29
  store ptr %t88, ptr %rv
  br label %ret
bb21:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"compiler/check:Checker", ptr %t89, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !29
  %t93 = load i32, ptr %l3, !tbaa !23
  %t96 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSelfType(ptr %v0, ptr %t92, i32 %t93)
  store i32 %t96, ptr %l84
  br label %bb22
bb22:
  %t97 = load i32, ptr %l84, !tbaa !23
  store i32 %t97, ptr %l7, !tbaa !23
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t99 = load i32, ptr %l7, !tbaa !23
  %t102 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %t98, i32 %t99)
  store i32 %t102, ptr %l87
  br label %bb23
bb23:
  %t103 = load i32, ptr %l87
  %t105 = trunc i64 0 to i32
  %t106 = icmp eq i32 %t103, %t105
  %t108 = xor i1 %t106, true
  br i1 %t108, label %bb24, label %bb25
bb24:
  store %olang.scope zeroinitializer, ptr %s2
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t111 = load %"compiler/source:Span", ptr %l2
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %s2, ptr %t110, %"compiler/source:Span" %t111, { i64, ptr } { i64 63, ptr getelementptr inbounds (<{ i64, [63 x i8] }>, ptr @.d32, i32 0, i32 1) })
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t115 = load %"compiler/source:Span", ptr %l1
  %t118 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t114, %"compiler/source:Span" %t115)
  store ptr %t118, ptr %l95
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t119 = load ptr, ptr %l95, !tbaa !29
  store ptr %t119, ptr %rv
  br label %ret
bb28:
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t122 = getelementptr %"compiler/check:Checker", ptr %t120, i32 0, i32 1
  %t123 = load ptr, ptr %t122, !tbaa !29
  %t124 = load i32, ptr %l7, !tbaa !23
  %t127 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorSig(ptr %v0, ptr %t123, i32 %t124)
  store i32 %t127, ptr %l99
  br label %bb29
bb29:
  %t128 = load i32, ptr %l99, !tbaa !23
  store i32 %t128, ptr %l8, !tbaa !23
  %t129 = load i32, ptr %l8, !tbaa !23
  %t130 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t133 = icmp eq i32 %t129, %t130
  br i1 %t133, label %bb30, label %bb31
bb30:
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t136 = load %"compiler/source:Span", ptr %l1
  %t139 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t135, %"compiler/source:Span" %t136)
  store ptr %t139, ptr %l105
  br label %bb32
bb31:
  br label %bb33
bb32:
  call void @__olang_scope_close(ptr %s0)
  %t140 = load ptr, ptr %l105, !tbaa !29
  store ptr %t140, ptr %rv
  br label %ret
bb33:
  %t141 = load i32, ptr %l3, !tbaa !23
  %t143 = call i64 @compiler_2fgeneric_2eDeclOwner(i32 %t141)
  store i64 %t143, ptr %l107
  br label %bb34
bb34:
  %t144 = load i64, ptr %l107, !tbaa !24
  store i64 %t144, ptr %l9, !tbaa !24
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t147 = getelementptr %"compiler/check:Checker", ptr %t145, i32 0, i32 1
  %t148 = load ptr, ptr %t147, !tbaa !29
  %t150 = getelementptr %"compiler/generic:Program", ptr %t148, i32 0, i32 2
  %t151 = load i32, ptr %l3, !tbaa !23
  %t154 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclParams(ptr %v0, ptr %t150, i32 %t151)
  store i64 %t154, ptr %l112
  br label %bb35
bb35:
  %t155 = load i64, ptr %l112, !tbaa !24
  store i64 %t155, ptr %l10, !tbaa !24
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t158 = getelementptr %"compiler/check:Checker", ptr %t156, i32 0, i32 1
  %t159 = load ptr, ptr %t158, !tbaa !29
  %t161 = getelementptr %"compiler/generic:Program", ptr %t159, i32 0, i32 2
  store ptr %t161, ptr %l115, !tbaa !29
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t164 = getelementptr %"compiler/check:Checker", ptr %t162, i32 0, i32 1
  %t165 = load ptr, ptr %t164, !tbaa !29
  %t167 = getelementptr %"compiler/generic:Program", ptr %t165, i32 0, i32 2
  %t168 = load i32, ptr %l8, !tbaa !23
  %t171 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t167, i32 %t168)
  store i32 %t171, ptr %l120
  br label %bb36
bb36:
  %t172 = load ptr, ptr %l115, !tbaa !29
  %t173 = load i32, ptr %l120, !tbaa !23
  %t174 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t172, i32 %t173)
  store { i64, ptr } %t174, ptr %l121
  br label %bb37
bb37:
  %t175 = load { i64, ptr }, ptr %l121, !tbaa !27
  store { i64, ptr } %t175, ptr %l11, !tbaa !27
  %t176 = load i64, ptr %l9, !tbaa !24
  %t177 = load i64, ptr %l10, !tbaa !24
  %t180 = call %"compiler/generic:Binding" @compiler_2fgeneric_3aBinding_2ector(ptr %s0, i64 %t176, i64 %t177)
  store %"compiler/generic:Binding" %t180, ptr %l124
  br label %bb38
bb38:
  %t181 = load %"compiler/generic:Binding", ptr %l124
  store %"compiler/generic:Binding" %t181, ptr %l12
  %t182 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t182, ptr %l125
  br label %bb39
bb39:
  %t183 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 8, i64 8)
  store ptr %t183, ptr %lp13
  %t184 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l125
  %t185 = load ptr, ptr %lp13
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t184, ptr %t185
  store i64 0, ptr %l14, !tbaa !24
  %t186 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t188 = extractvalue { i64, ptr } %t186, 0
  store i64 %t188, ptr %l15, !tbaa !24
  store i64 1, ptr %l16, !tbaa !24
  %t190 = load i64, ptr %l15, !tbaa !24
  %t191 = load i64, ptr %l14, !tbaa !24
  %t194 = icmp sgt i64 %t190, %t191
  br i1 %t194, label %bb40, label %bb41
bb40:
  %t196 = load i64, ptr %l16, !tbaa !24
  %t198 = icmp sgt i64 %t196, 0
  br i1 %t198, label %bb42, label %bb43
bb41:
  store i64 0, ptr %l131, !tbaa !24
  br label %bb45
bb42:
  %t200 = load i64, ptr %l15, !tbaa !24
  %t201 = load i64, ptr %l14, !tbaa !24
  %t204 = sub i64 %t200, %t201
  %t205 = load i64, ptr %l16, !tbaa !24
  %t208 = add i64 %t204, %t205
  %t210 = sub i64 %t208, 1
  %t211 = load i64, ptr %l16, !tbaa !24
  %t214 = sdiv i64 %t210, %t211
  store i64 %t214, ptr %l134, !tbaa !24
  br label %bb44
bb43:
  store i64 0, ptr %l134, !tbaa !24
  br label %bb44
bb44:
  %t216 = load i64, ptr %l134, !tbaa !24
  store i64 %t216, ptr %l131, !tbaa !24
  br label %bb45
bb45:
  %t217 = load i64, ptr %l131, !tbaa !24
  store i64 %t217, ptr %l17, !tbaa !24
  store i64 0, ptr %l18, !tbaa !24
  br label %bb46
bb46:
  %t218 = load i64, ptr %l18, !tbaa !24
  %t219 = load i64, ptr %l17, !tbaa !24
  %t222 = icmp slt i64 %t218, %t219
  %t224 = xor i1 %t222, true
  br i1 %t224, label %bb47, label %bb48
bb47:
  br label %bb105
bb48:
  br label %bb49
bb49:
  %t226 = load i64, ptr %l14, !tbaa !24
  %t227 = load i64, ptr %l18, !tbaa !24
  %t228 = load i64, ptr %l16, !tbaa !24
  %t231 = mul i64 %t227, %t228
  %t234 = add i64 %t226, %t231
  store i64 %t234, ptr %l19, !tbaa !24
  store ptr null, ptr %l20, !tbaa !29
  %t236 = load ptr, ptr %l0, !tbaa !29
  %t237 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t237, ptr %l153, !tbaa !27
  %t238 = load i64, ptr %l19, !tbaa !24
  %t240 = getelementptr { i64, ptr }, ptr %l153, i32 0, i32 1
  %t241 = load ptr, ptr %t240, !tbaa !27
  %t242 = getelementptr ptr, ptr %t241, i64 %t238
  %t243 = load ptr, ptr %t242, !tbaa !39
  %t247 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %t236, ptr %t243)
  store %"compiler/check:litv" %t247, ptr %l157
  br label %bb50
bb50:
  %t248 = load %"compiler/check:litv", ptr %l157
  store %"compiler/check:litv" %t248, ptr %l21
  %t249 = getelementptr %"compiler/check:litv", ptr %l21, i32 0, i32 0
  %t250 = load i1, ptr %t249, !tbaa !21
  br i1 %t250, label %bb51, label %bb52
bb51:
  store i1 true, ptr %l159, !tbaa !21
  br label %bb54
bb52:
  %t252 = load ptr, ptr %l0, !tbaa !29
  %t253 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t253, ptr %l161, !tbaa !27
  %t254 = load i64, ptr %l19, !tbaa !24
  %t256 = getelementptr { i64, ptr }, ptr %l161, i32 0, i32 1
  %t257 = load ptr, ptr %t256, !tbaa !27
  %t258 = getelementptr ptr, ptr %t257, i64 %t254
  %t259 = load ptr, ptr %t258, !tbaa !39
  %t262 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v1, ptr %t252, ptr %t259)
  store i1 %t262, ptr %l164
  br label %bb53
bb53:
  %t263 = load i1, ptr %l164, !tbaa !21
  store i1 %t263, ptr %l159, !tbaa !21
  br label %bb54
bb54:
  %t264 = load i1, ptr %l159, !tbaa !21
  br i1 %t264, label %bb55, label %bb56
bb55:
  %t265 = getelementptr %"compiler/check:litv", ptr %l21, i32 0, i32 0
  %t266 = load i1, ptr %t265, !tbaa !21
  br i1 %t266, label %bb57, label %bb58
bb56:
  %t268 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t268, ptr %l190, !tbaa !27
  %t269 = load i64, ptr %l19, !tbaa !24
  %t271 = getelementptr { i64, ptr }, ptr %l190, i32 0, i32 1
  %t272 = load ptr, ptr %t271, !tbaa !27
  %t273 = getelementptr ptr, ptr %t272, i64 %t269
  %t274 = load ptr, ptr %t273, !tbaa !39
  store ptr %t274, ptr %l23, !tbaa !29
  %t276 = load ptr, ptr %l23, !tbaa !29
  store ptr %t276, ptr %l193, !tbaa !29
  store i1 false, ptr %l194, !tbaa !21
  %t277 = load ptr, ptr %l193, !tbaa !29
  %t278 = icmp ne ptr %t277, null
  br i1 %t278, label %bb70, label %bb71
bb57:
  %t280 = getelementptr %"compiler/check:litv", ptr %l21, i32 0, i32 1
  %t281 = load i1, ptr %t280, !tbaa !21
  store i1 %t281, ptr %l166, !tbaa !21
  br label %bb60
bb58:
  %t283 = load ptr, ptr %l0, !tbaa !29
  %t284 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t284, ptr %l169, !tbaa !27
  %t285 = load i64, ptr %l19, !tbaa !24
  %t287 = getelementptr { i64, ptr }, ptr %l169, i32 0, i32 1
  %t288 = load ptr, ptr %t287, !tbaa !27
  %t289 = getelementptr ptr, ptr %t288, i64 %t285
  %t290 = load ptr, ptr %t289, !tbaa !39
  %t293 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitFloat(ptr %v0, ptr %v1, ptr %t283, ptr %t290)
  store i1 %t293, ptr %l172
  br label %bb59
bb59:
  %t294 = load i1, ptr %l172, !tbaa !21
  store i1 %t294, ptr %l166, !tbaa !21
  br label %bb60
bb60:
  %t295 = load i1, ptr %l166, !tbaa !21
  store i1 %t295, ptr %l22, !tbaa !21
  %t296 = load i64, ptr %l19, !tbaa !24
  %t297 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t299 = extractvalue { i64, ptr } %t297, 0
  %t302 = icmp slt i64 %t296, %t299
  br i1 %t302, label %bb61, label %bb62
bb61:
  store %olang.scope zeroinitializer, ptr %s7
  %t304 = load ptr, ptr %l0, !tbaa !29
  store ptr %t304, ptr %l177, !tbaa !29
  %t305 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t305, ptr %l178, !tbaa !27
  %t306 = load i64, ptr %l19, !tbaa !24
  %t308 = getelementptr { i64, ptr }, ptr %l178, i32 0, i32 1
  %t309 = load ptr, ptr %t308, !tbaa !27
  %t310 = getelementptr i32, ptr %t309, i64 %t306
  %t311 = load i32, ptr %t310, !tbaa !33
  store i32 %t311, ptr %l180, !tbaa !23
  %t312 = load i1, ptr %l22, !tbaa !21
  br i1 %t312, label %bb63, label %bb64
bb62:
  br label %bb69
bb63:
  %t314 = load ptr, ptr %l0, !tbaa !29
  %t316 = getelementptr %"compiler/check:Checker", ptr %t314, i32 0, i32 1
  %t317 = load ptr, ptr %t316, !tbaa !29
  %t319 = getelementptr %"compiler/generic:Program", ptr %t317, i32 0, i32 2
  %t321 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s7, ptr %t319, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d33, i32 0, i32 1) })
  store i32 %t321, ptr %l186
  br label %bb65
bb64:
  %t322 = load ptr, ptr %l0, !tbaa !29
  %t324 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t322)
  store i32 %t324, ptr %l188
  br label %bb66
bb65:
  %t325 = load i32, ptr %l186, !tbaa !23
  store i32 %t325, ptr %l182, !tbaa !23
  br label %bb67
bb66:
  %t326 = load i32, ptr %l188, !tbaa !23
  store i32 %t326, ptr %l182, !tbaa !23
  br label %bb67
bb67:
  %t327 = load ptr, ptr %l177, !tbaa !29
  %t328 = load i32, ptr %l180, !tbaa !23
  %t329 = load i32, ptr %l182, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunify(ptr %v0, ptr %s0, ptr %t327, i32 %t328, i32 %t329, ptr %l12, i1 true, i1 false)
  br label %bb68
bb68:
  call void @__olang_scope_close(ptr %s7)
  br label %bb69
bb69:
  br label %bb82
bb70:
  %t331 = load ptr, ptr %l193, !tbaa !29
  %t332 = load i64, ptr %t331
  %t334 = icmp eq i64 %t332, 23
  store i1 %t334, ptr %l194, !tbaa !21
  br label %bb71
bb71:
  %t335 = load i1, ptr %l194, !tbaa !21
  br i1 %t335, label %bb72, label %bb73
bb72:
  br label %bb78
bb73:
  %t336 = load ptr, ptr %l23, !tbaa !29
  store ptr %t336, ptr %l197, !tbaa !29
  store i1 false, ptr %l198, !tbaa !21
  %t337 = load ptr, ptr %l197, !tbaa !29
  %t338 = icmp ne ptr %t337, null
  br i1 %t338, label %bb74, label %bb75
bb74:
  %t340 = load ptr, ptr %l197, !tbaa !29
  %t341 = load i64, ptr %t340
  %t343 = icmp eq i64 %t341, 26
  store i1 %t343, ptr %l198, !tbaa !21
  br label %bb75
bb75:
  %t344 = load i1, ptr %l198, !tbaa !21
  br i1 %t344, label %bb76, label %bb77
bb76:
  br label %bb78
bb77:
  br label %bb79
bb78:
  br label %bb81
bb79:
  %t345 = load ptr, ptr %l0, !tbaa !29
  %t346 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t346, ptr %l202, !tbaa !27
  %t347 = load i64, ptr %l19, !tbaa !24
  %t349 = getelementptr { i64, ptr }, ptr %l202, i32 0, i32 1
  %t350 = load ptr, ptr %t349, !tbaa !27
  %t351 = getelementptr ptr, ptr %t350, i64 %t347
  %t352 = load ptr, ptr %t351, !tbaa !39
  %t354 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t358 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %t345, ptr %t352, i32 %t354)
  store ptr %t358, ptr %l207
  br label %bb80
bb80:
  %t359 = load ptr, ptr %l207, !tbaa !29
  store ptr %t359, ptr %l20, !tbaa !29
  br label %bb81
bb81:
  br label %bb82
bb82:
  %t361 = load ptr, ptr %l20, !tbaa !29
  %t363 = icmp eq ptr %t361, null
  %t365 = xor i1 %t363, true
  br i1 %t365, label %bb83, label %bb84
bb83:
  %t367 = load i64, ptr %l19, !tbaa !24
  %t368 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t370 = extractvalue { i64, ptr } %t368, 0
  %t373 = icmp slt i64 %t367, %t370
  store i1 %t373, ptr %l212, !tbaa !21
  br label %bb85
bb84:
  store i1 false, ptr %l212, !tbaa !21
  br label %bb85
bb85:
  %t375 = load i1, ptr %l212, !tbaa !21
  br i1 %t375, label %bb86, label %bb87
bb86:
  %t376 = load ptr, ptr %l20, !tbaa !29
  %t379 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t376)
  store i32 %t379, ptr %l220
  br label %bb88
bb87:
  store i1 false, ptr %l217, !tbaa !21
  br label %bb89
bb88:
  %t380 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t381 = load i32, ptr %l220, !tbaa !23
  %t383 = icmp ne i32 %t381, %t380
  store i1 %t383, ptr %l217, !tbaa !21
  br label %bb89
bb89:
  %t385 = load i1, ptr %l217, !tbaa !21
  br i1 %t385, label %bb90, label %bb91
bb90:
  %t386 = load ptr, ptr %l20, !tbaa !29
  %t389 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t386)
  store i32 %t389, ptr %l226
  br label %bb92
bb91:
  store i1 false, ptr %l223, !tbaa !21
  br label %bb93
bb92:
  %t390 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t391 = load i32, ptr %l226, !tbaa !23
  %t393 = icmp ne i32 %t391, %t390
  store i1 %t393, ptr %l223, !tbaa !21
  br label %bb93
bb93:
  %t395 = load i1, ptr %l223, !tbaa !21
  br i1 %t395, label %bb94, label %bb95
bb94:
  %t396 = load ptr, ptr %l0, !tbaa !29
  store ptr %t396, ptr %l229, !tbaa !29
  %t397 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t397, ptr %l230, !tbaa !27
  %t398 = load i64, ptr %l19, !tbaa !24
  %t400 = getelementptr { i64, ptr }, ptr %l230, i32 0, i32 1
  %t401 = load ptr, ptr %t400, !tbaa !27
  %t402 = getelementptr i32, ptr %t401, i64 %t398
  %t403 = load i32, ptr %t402, !tbaa !33
  store i32 %t403, ptr %l232, !tbaa !23
  %t404 = load ptr, ptr %l0, !tbaa !29
  %t405 = load ptr, ptr %l20, !tbaa !29
  %t408 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebindType(ptr %v0, ptr %v0, ptr %t404, ptr %t405)
  store i32 %t408, ptr %l235
  br label %bb96
bb95:
  br label %bb98
bb96:
  %t409 = load ptr, ptr %l229, !tbaa !29
  %t410 = load i32, ptr %l232, !tbaa !23
  %t411 = load i32, ptr %l235, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunify(ptr %v0, ptr %s0, ptr %t409, i32 %t410, i32 %t411, ptr %l12, i1 false, i1 false)
  br label %bb97
bb97:
  br label %bb98
bb98:
  %t413 = load ptr, ptr %l20, !tbaa !29
  %t415 = icmp eq ptr %t413, null
  br i1 %t415, label %bb99, label %bb100
bb99:
  %t417 = load ptr, ptr %lp13
  %t418 = load ptr, ptr %l0, !tbaa !29
  %t420 = getelementptr %"compiler/check:Checker", ptr %t418, i32 0, i32 0
  %t421 = load ptr, ptr %t420, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t417, ptr %t421)
  br label %bb101
bb100:
  %t424 = load ptr, ptr %lp13
  %t425 = load ptr, ptr %l20, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t424, ptr %t425)
  br label %bb102
bb101:
  br label %bb103
bb102:
  br label %bb103
bb103:
  br label %bb104
bb104:
  %t428 = load i64, ptr %l18, !tbaa !24
  %t430 = add i64 %t428, 1
  store i64 %t430, ptr %l18, !tbaa !24
  br label %bb46
bb105:
  %t432 = load ptr, ptr %l0, !tbaa !29
  %t434 = getelementptr %"compiler/check:Checker", ptr %t432, i32 0, i32 1
  %t435 = load ptr, ptr %t434, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInferThroughBounds(ptr %v0, ptr %s0, ptr %t435, ptr %l12)
  br label %bb106
bb106:
  store i64 0, ptr %l24, !tbaa !24
  %t438 = load i64, ptr %l10, !tbaa !24
  store i64 %t438, ptr %l25, !tbaa !24
  store i64 1, ptr %l26, !tbaa !24
  %t440 = load i64, ptr %l25, !tbaa !24
  %t441 = load i64, ptr %l24, !tbaa !24
  %t444 = icmp sgt i64 %t440, %t441
  br i1 %t444, label %bb107, label %bb108
bb107:
  %t446 = load i64, ptr %l26, !tbaa !24
  %t448 = icmp sgt i64 %t446, 0
  br i1 %t448, label %bb109, label %bb110
bb108:
  store i64 0, ptr %l253, !tbaa !24
  br label %bb112
bb109:
  %t450 = load i64, ptr %l25, !tbaa !24
  %t451 = load i64, ptr %l24, !tbaa !24
  %t454 = sub i64 %t450, %t451
  %t455 = load i64, ptr %l26, !tbaa !24
  %t458 = add i64 %t454, %t455
  %t460 = sub i64 %t458, 1
  %t461 = load i64, ptr %l26, !tbaa !24
  %t464 = sdiv i64 %t460, %t461
  store i64 %t464, ptr %l256, !tbaa !24
  br label %bb111
bb110:
  store i64 0, ptr %l256, !tbaa !24
  br label %bb111
bb111:
  %t466 = load i64, ptr %l256, !tbaa !24
  store i64 %t466, ptr %l253, !tbaa !24
  br label %bb112
bb112:
  %t467 = load i64, ptr %l253, !tbaa !24
  store i64 %t467, ptr %l27, !tbaa !24
  store i64 0, ptr %l28, !tbaa !24
  br label %bb113
bb113:
  %t468 = load i64, ptr %l28, !tbaa !24
  %t469 = load i64, ptr %l27, !tbaa !24
  %t472 = icmp slt i64 %t468, %t469
  %t474 = xor i1 %t472, true
  br i1 %t474, label %bb114, label %bb115
bb114:
  br label %bb146
bb115:
  br label %bb116
bb116:
  %t476 = load i64, ptr %l24, !tbaa !24
  %t477 = load i64, ptr %l28, !tbaa !24
  %t478 = load i64, ptr %l26, !tbaa !24
  %t481 = mul i64 %t477, %t478
  %t484 = add i64 %t476, %t481
  store i64 %t484, ptr %l29, !tbaa !24
  %t486 = getelementptr %"compiler/generic:Binding", ptr %l12, i32 0, i32 2
  %t487 = load { i64, ptr }, ptr %t486, !tbaa !27
  store { i64, ptr } %t487, ptr %l274, !tbaa !27
  %t488 = load i64, ptr %l29, !tbaa !24
  %t490 = getelementptr { i64, ptr }, ptr %l274, i32 0, i32 1
  %t491 = load ptr, ptr %t490, !tbaa !27
  %t492 = getelementptr i32, ptr %t491, i64 %t488
  %t493 = load i32, ptr %t492, !tbaa !33
  store i32 %t493, ptr %l30, !tbaa !23
  %t495 = load i32, ptr %l30, !tbaa !23
  %t496 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t499 = icmp eq i32 %t495, %t496
  br i1 %t499, label %bb117, label %bb118
bb117:
  %t501 = load ptr, ptr %l0, !tbaa !29
  %t503 = getelementptr %"compiler/check:Checker", ptr %t501, i32 0, i32 1
  %t504 = load ptr, ptr %t503, !tbaa !29
  %t505 = load i64, ptr %l9, !tbaa !24
  %t506 = load i64, ptr %l29, !tbaa !24
  %t510 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrVarAt(ptr %v0, ptr %t504, i64 %t505, i64 %t506)
  store i1 %t510, ptr %l285
  br label %bb119
bb118:
  store i1 false, ptr %l280, !tbaa !21
  br label %bb120
bb119:
  %t511 = load i1, ptr %l285, !tbaa !21
  store i1 %t511, ptr %l280, !tbaa !21
  br label %bb120
bb120:
  %t512 = load i1, ptr %l280, !tbaa !21
  br i1 %t512, label %bb121, label %bb122
bb121:
  %t513 = getelementptr %"compiler/generic:Binding", ptr %l12, i32 0, i32 2
  %t514 = load { i64, ptr }, ptr %t513, !tbaa !27
  store { i64, ptr } %t514, ptr %l286, !tbaa !27
  %t515 = load i64, ptr %l29, !tbaa !24
  store i64 %t515, ptr %l287, !tbaa !24
  %t516 = load ptr, ptr %l0, !tbaa !29
  %t518 = getelementptr %"compiler/check:Checker", ptr %t516, i32 0, i32 1
  %t519 = load ptr, ptr %t518, !tbaa !29
  %t521 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrSetOf(ptr %v0, ptr %t519, i32 0)
  store i32 %t521, ptr %l290
  br label %bb123
bb122:
  br label %bb124
bb123:
  %t522 = load i32, ptr %l290, !tbaa !23
  %t523 = load i64, ptr %l287, !tbaa !24
  %t524 = getelementptr { i64, ptr }, ptr %l286, i32 0, i32 1
  %t525 = load ptr, ptr %t524, !tbaa !27
  %t526 = getelementptr i32, ptr %t525, i64 %t523
  store i32 %t522, ptr %t526, !tbaa !33
  br label %bb145
bb124:
  %t527 = load i32, ptr %l30, !tbaa !23
  %t528 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t531 = icmp eq i32 %t527, %t528
  br i1 %t531, label %bb125, label %bb126
bb125:
  store %olang.scope zeroinitializer, ptr %s18
  %t533 = load ptr, ptr %l0, !tbaa !29
  store ptr %t533, ptr %l294, !tbaa !29
  %t534 = load ptr, ptr %l0, !tbaa !29
  %t536 = getelementptr %"compiler/check:Checker", ptr %t534, i32 0, i32 1
  %t537 = load ptr, ptr %t536, !tbaa !29
  %t539 = getelementptr %"compiler/generic:Program", ptr %t537, i32 0, i32 2
  %t540 = load i32, ptr %l3, !tbaa !23
  %t543 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t539, i32 %t540)
  store i32 %t543, ptr %l299
  br label %bb127
bb126:
  br label %bb132
bb127:
  %t544 = load ptr, ptr %l294, !tbaa !29
  %t545 = load i32, ptr %l299, !tbaa !23
  %t546 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t544, i32 %t545)
  store { i64, ptr } %t546, ptr %l300
  br label %bb128
bb128:
  %t547 = load { i64, ptr }, ptr %l300, !tbaa !27
  store { i64, ptr } %t547, ptr %l31, !tbaa !27
  %t548 = load ptr, ptr %l0, !tbaa !29
  store ptr %t548, ptr %l301, !tbaa !29
  %t549 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t549, ptr %l302
  %t550 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t551 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t554 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCtorTypeArgsNotInferable(ptr %v0, ptr %v0, ptr %s18, { i64, ptr } %t550, { i64, ptr } %t551)
  store %"compiler/msgs:Msg" %t554, ptr %l305
  br label %bb129
bb129:
  %t555 = load ptr, ptr %l301, !tbaa !29
  %t556 = load %"compiler/source:Span", ptr %l302
  %t557 = load %"compiler/msgs:Msg", ptr %l305
  %t558 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s18, ptr %t555, %"compiler/source:Span" %t556, %"compiler/msgs:Msg" %t557)
  store i64 %t558, ptr %l306
  br label %bb130
bb130:
  %t559 = load ptr, ptr %l0, !tbaa !29
  %t560 = load %"compiler/source:Span", ptr %l1
  %t563 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t559, %"compiler/source:Span" %t560)
  store ptr %t563, ptr %l309
  br label %bb131
bb131:
  call void @__olang_scope_close(ptr %s18)
  call void @__olang_scope_close(ptr %s0)
  %t564 = load ptr, ptr %l309, !tbaa !29
  store ptr %t564, ptr %rv
  br label %ret
bb132:
  %t565 = load ptr, ptr %l0, !tbaa !29
  %t566 = load i32, ptr %l30, !tbaa !23
  %t569 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t565, i32 %t566)
  store i1 %t569, ptr %l312
  br label %bb133
bb133:
  %t570 = load i1, ptr %l312, !tbaa !21
  br i1 %t570, label %bb134, label %bb135
bb134:
  %t571 = getelementptr %"compiler/generic:Binding", ptr %l12, i32 0, i32 2
  %t572 = load { i64, ptr }, ptr %t571, !tbaa !27
  store { i64, ptr } %t572, ptr %l313, !tbaa !27
  %t573 = load i64, ptr %l29, !tbaa !24
  store i64 %t573, ptr %l314, !tbaa !24
  %t574 = load ptr, ptr %l0, !tbaa !29
  %t576 = getelementptr %"compiler/check:Checker", ptr %t574, i32 0, i32 1
  %t577 = load ptr, ptr %t576, !tbaa !29
  %t579 = getelementptr %"compiler/generic:Program", ptr %t577, i32 0, i32 2
  store ptr %t579, ptr %l317, !tbaa !29
  %t580 = load ptr, ptr %l0, !tbaa !29
  %t582 = getelementptr %"compiler/check:Checker", ptr %t580, i32 0, i32 1
  %t583 = load ptr, ptr %t582, !tbaa !29
  %t585 = getelementptr %"compiler/generic:Program", ptr %t583, i32 0, i32 2
  %t586 = load i32, ptr %l30, !tbaa !23
  %t589 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t585, i32 %t586)
  store i32 %t589, ptr %l322
  br label %bb136
bb135:
  %t590 = load ptr, ptr %l0, !tbaa !29
  %t592 = getelementptr %"compiler/check:Checker", ptr %t590, i32 0, i32 1
  %t593 = load ptr, ptr %t592, !tbaa !29
  %t595 = getelementptr %"compiler/generic:Program", ptr %t593, i32 0, i32 2
  store ptr %t595, ptr %l327, !tbaa !29
  %t596 = load ptr, ptr %l0, !tbaa !29
  %t597 = load i32, ptr %l30, !tbaa !23
  %t600 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t596, i32 %t597)
  store i32 %t600, ptr %l330
  br label %bb138
bb136:
  %t601 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t602 = load ptr, ptr %l317, !tbaa !29
  %t603 = load i32, ptr %l322, !tbaa !23
  %t605 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t602, i32 %t603, i64 %t601)
  store i32 %t605, ptr %l324
  br label %bb137
bb137:
  %t606 = load i32, ptr %l324, !tbaa !23
  %t607 = load i64, ptr %l314, !tbaa !24
  %t608 = getelementptr { i64, ptr }, ptr %l313, i32 0, i32 1
  %t609 = load ptr, ptr %t608, !tbaa !27
  %t610 = getelementptr i32, ptr %t609, i64 %t607
  store i32 %t606, ptr %t610, !tbaa !33
  br label %bb144
bb138:
  %t611 = load ptr, ptr %l327, !tbaa !29
  %t612 = load i32, ptr %l330, !tbaa !23
  %t613 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t611, i32 %t612)
  store i32 %t613, ptr %l331
  br label %bb139
bb139:
  %t614 = load i32, ptr %l331
  %t616 = trunc i64 19 to i32
  %t617 = icmp eq i32 %t614, %t616
  br i1 %t617, label %bb140, label %bb141
bb140:
  %t619 = getelementptr %"compiler/generic:Binding", ptr %l12, i32 0, i32 2
  %t620 = load { i64, ptr }, ptr %t619, !tbaa !27
  store { i64, ptr } %t620, ptr %l334, !tbaa !27
  %t621 = load i64, ptr %l29, !tbaa !24
  store i64 %t621, ptr %l335, !tbaa !24
  %t622 = load ptr, ptr %l0, !tbaa !29
  %t624 = getelementptr %"compiler/check:Checker", ptr %t622, i32 0, i32 1
  %t625 = load ptr, ptr %t624, !tbaa !29
  %t627 = getelementptr %"compiler/generic:Program", ptr %t625, i32 0, i32 2
  %t628 = load i32, ptr %l30, !tbaa !23
  %t629 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t633 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t627, i32 %t628, i64 %t629)
  store i32 %t633, ptr %l341
  br label %bb142
bb141:
  br label %bb143
bb142:
  %t634 = load i32, ptr %l341, !tbaa !23
  %t635 = load i64, ptr %l335, !tbaa !24
  %t636 = getelementptr { i64, ptr }, ptr %l334, i32 0, i32 1
  %t637 = load ptr, ptr %t636, !tbaa !27
  %t638 = getelementptr i32, ptr %t637, i64 %t635
  store i32 %t634, ptr %t638, !tbaa !33
  br label %bb143
bb143:
  br label %bb144
bb144:
  br label %bb145
bb145:
  %t639 = load i64, ptr %l28, !tbaa !24
  %t641 = add i64 %t639, 1
  store i64 %t641, ptr %l28, !tbaa !24
  br label %bb113
bb146:
  %t643 = load ptr, ptr %l0, !tbaa !29
  %t645 = getelementptr %"compiler/check:Checker", ptr %t643, i32 0, i32 1
  %t646 = load ptr, ptr %t645, !tbaa !29
  store ptr %t646, ptr %l345, !tbaa !29
  %t647 = load i32, ptr %l3, !tbaa !23
  store i32 %t647, ptr %l346, !tbaa !23
  %t648 = load ptr, ptr %l0, !tbaa !29
  %t650 = getelementptr %"compiler/check:Checker", ptr %t648, i32 0, i32 1
  %t651 = load ptr, ptr %t650, !tbaa !29
  %t653 = getelementptr %"compiler/generic:Program", ptr %t651, i32 0, i32 2
  %t654 = getelementptr %"compiler/generic:Binding", ptr %l12, i32 0, i32 2
  %t655 = load { i64, ptr }, ptr %t654, !tbaa !27
  %t658 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t653, { i64, ptr } %t655)
  store i32 %t658, ptr %l351
  br label %bb147
bb147:
  %t659 = load ptr, ptr %l345, !tbaa !29
  %t660 = load i32, ptr %l346, !tbaa !23
  %t661 = load i32, ptr %l351, !tbaa !23
  %t662 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstance(ptr %v0, ptr %t659, i32 %t660, i32 %t661)
  store i32 %t662, ptr %l352
  br label %bb148
bb148:
  %t663 = load i32, ptr %l352, !tbaa !23
  store i32 %t663, ptr %l32, !tbaa !23
  %t664 = load ptr, ptr %l0, !tbaa !29
  %t665 = load i32, ptr %l32, !tbaa !23
  %t666 = load %"compiler/source:Span", ptr %l2
  %t670 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstancesMet(ptr %v0, ptr %t664, i32 %t665, %"compiler/source:Span" %t666)
  store i1 %t670, ptr %l356
  br label %bb149
bb149:
  %t671 = load i1, ptr %l356, !tbaa !21
  %t672 = xor i1 %t671, true
  br i1 %t672, label %bb150, label %bb151
bb150:
  store i1 true, ptr %l358, !tbaa !21
  br label %bb153
bb151:
  %t674 = load ptr, ptr %l0, !tbaa !29
  %t676 = getelementptr %"compiler/check:Checker", ptr %t674, i32 0, i32 1
  %t677 = load ptr, ptr %t676, !tbaa !29
  %t678 = load i32, ptr %l32, !tbaa !23
  %t681 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t677, i32 %t678)
  store i1 %t681, ptr %l362
  br label %bb152
bb152:
  %t682 = load i1, ptr %l362, !tbaa !21
  %t683 = xor i1 %t682, true
  store i1 %t683, ptr %l358, !tbaa !21
  br label %bb153
bb153:
  %t685 = load i1, ptr %l358, !tbaa !21
  br i1 %t685, label %bb154, label %bb155
bb154:
  %t686 = load ptr, ptr %l0, !tbaa !29
  %t687 = load %"compiler/source:Span", ptr %l1
  %t690 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t686, %"compiler/source:Span" %t687)
  store ptr %t690, ptr %l366
  br label %bb156
bb155:
  br label %bb157
bb156:
  call void @__olang_scope_close(ptr %s0)
  %t691 = load ptr, ptr %l366, !tbaa !29
  store ptr %t691, ptr %rv
  br label %ret
bb157:
  %t692 = load ptr, ptr %l0, !tbaa !29
  %t694 = getelementptr %"compiler/check:Checker", ptr %t692, i32 0, i32 1
  %t695 = load ptr, ptr %t694, !tbaa !29
  %t696 = load i32, ptr %l32, !tbaa !23
  %t699 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorSig(ptr %v0, ptr %t695, i32 %t696)
  store i32 %t699, ptr %l370
  br label %bb158
bb158:
  %t700 = load i32, ptr %l370, !tbaa !23
  store i32 %t700, ptr %l33, !tbaa !23
  %t701 = load i32, ptr %l33, !tbaa !23
  %t702 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t705 = icmp eq i32 %t701, %t702
  br i1 %t705, label %bb159, label %bb160
bb159:
  %t707 = load ptr, ptr %l0, !tbaa !29
  %t708 = load %"compiler/source:Span", ptr %l1
  %t711 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t707, %"compiler/source:Span" %t708)
  store ptr %t711, ptr %l376
  br label %bb161
bb160:
  br label %bb162
bb161:
  call void @__olang_scope_close(ptr %s0)
  %t712 = load ptr, ptr %l376, !tbaa !29
  store ptr %t712, ptr %rv
  br label %ret
bb162:
  %t713 = load ptr, ptr %l0, !tbaa !29
  %t714 = load i32, ptr %l32, !tbaa !23
  %t717 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorBody(ptr %v0, ptr %t713, i32 %t714)
  store i64 %t717, ptr %l379
  br label %bb163
bb163:
  %t718 = load i64, ptr %l379, !tbaa !24
  %t719 = load ptr, ptr %l0, !tbaa !29
  %t721 = getelementptr %"compiler/check:Checker", ptr %t719, i32 0, i32 22
  %t722 = load i32, ptr %t721, !tbaa !23
  store i32 %t722, ptr %l35, !tbaa !23
  %t724 = load ptr, ptr %l0, !tbaa !29
  %t725 = load i32, ptr %l32, !tbaa !23
  %t728 = getelementptr %"compiler/check:Checker", ptr %t724, i32 0, i32 22
  store i32 %t725, ptr %t728, !tbaa !23
  %t729 = load ptr, ptr %l0, !tbaa !29
  store ptr %t729, ptr %l384, !tbaa !29
  %t730 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t730, ptr %l385
  %t731 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t731, ptr %l386
  %t732 = load i32, ptr %l33, !tbaa !23
  store i32 %t732, ptr %l387, !tbaa !23
  %t735 = trunc i64 %t718 to i32
  store { i64, [3 x i64] } zeroinitializer, ptr %t737
  %t738 = getelementptr { i64, [3 x i64] }, ptr %t737, i32 0, i32 0
  store i64 0, ptr %t738
  %t740 = insertvalue { i32 } undef, i32 %t735, 0
  %t741 = getelementptr { i64, [3 x i64] }, ptr %t737, i32 0, i32 1
  store { i32 } %t740, ptr %t741
  %t742 = load { i64, [3 x i64] }, ptr %t737
  %t744 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t742, ptr %t744
  store ptr %t744, ptr %l392, !tbaa !29
  %t745 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t745, ptr %l393, !tbaa !27
  %t746 = load ptr, ptr %lp13
  %t748 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eToArra_H50cbff9caa8a2389caf3e92da7e24507(ptr %v0, ptr %v0, ptr %t746)
  store { i64, ptr } %t748, ptr %l395
  br label %bb164
bb164:
  %t749 = load ptr, ptr %l384, !tbaa !29
  %t750 = load %"compiler/source:Span", ptr %l385
  %t751 = load %"compiler/source:Span", ptr %l386
  %t752 = load i32, ptr %l387, !tbaa !23
  %t753 = load ptr, ptr %l392, !tbaa !29
  %t754 = load { i64, ptr }, ptr %l393, !tbaa !27
  %t755 = load { i64, ptr }, ptr %l395, !tbaa !27
  %t756 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallBody(ptr %v0, ptr %v1, ptr %t749, %"compiler/source:Span" %t750, %"compiler/source:Span" %t751, i32 %t752, ptr %t753, i64 -1, ptr null, { i64, ptr } %t754, { i64, ptr } %t755)
  store ptr %t756, ptr %l396
  br label %bb165
bb165:
  %t757 = load ptr, ptr %l396, !tbaa !29
  %t758 = load ptr, ptr %l0, !tbaa !29
  %t759 = load i32, ptr %l35, !tbaa !23
  %t762 = getelementptr %"compiler/check:Checker", ptr %t758, i32 0, i32 22
  store i32 %t759, ptr %t762, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store ptr %t757, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einfersErrs(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l10 = alloca i32
  %l11 = alloca { i64, ptr }
  %l15 = alloca i1
  %l16 = alloca { i64, ptr }
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  store ptr %t6, ptr %l5, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t12, i32 %a1)
  store i32 %t16, ptr %l10
  br label %bb1
bb1:
  %t17 = load ptr, ptr %l5, !tbaa !29
  %t18 = load i32, ptr %l10, !tbaa !23
  %t19 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t17, i32 %t18)
  store { i64, ptr } %t19, ptr %l11
  br label %bb2
bb2:
  %t20 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t20, ptr %l2, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t25 = icmp eq i64 %t23, 1
  br i1 %t25, label %bb3, label %bb4
bb3:
  %t27 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t27, ptr %l16, !tbaa !27
  %t28 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = getelementptr i32, ptr %t29, i64 0
  %t31 = load i32, ptr %t30, !tbaa !33
  %t32 = load i32, ptr @G_2ecompiler_2ftypes_2eDefaultErrT, !tbaa !23
  %t35 = icmp eq i32 %t31, %t32
  store i1 %t35, ptr %l15, !tbaa !21
  br label %bb5
bb4:
  store i1 false, ptr %l15, !tbaa !21
  br label %bb5
bb5:
  %t37 = load i1, ptr %l15, !tbaa !21
  store i1 %t37, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstField(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l3 = alloca i64
  %lp5 = alloca ptr
  %l7 = alloca ptr
  %l15 = alloca i32
  %l16 = alloca %"compiler/source:Span"
  %l21 = alloca i32
  %l25 = alloca ptr
  %l32 = alloca ptr
  %rv = alloca ptr
  %t38 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t1)
  store ptr %t3, ptr %l7
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l7, !tbaa !29
  %t6 = getelementptr %"compiler/check:frame", ptr %t4, i32 0, i32 28
  %t7 = load i64, ptr %t6, !tbaa !24
  store i64 %t7, ptr %l3, !tbaa !24
  %t9 = load i64, ptr %l3, !tbaa !24
  %t11 = icmp slt i64 %t9, 0
  br i1 %t11, label %bb2, label %bb3
bb2:
  store ptr null, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load i64, ptr %l3, !tbaa !24
  %t18 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalType(ptr %v0, ptr %t14, i64 %t15)
  store i32 %t18, ptr %l15
  br label %bb5
bb5:
  %t19 = load i32, ptr %l15, !tbaa !23
  %t20 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t20, ptr %l16
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/check:Checker", ptr %t21, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t26 = getelementptr %"compiler/generic:Program", ptr %t24, i32 0, i32 2
  %t30 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t26, i32 %t19)
  store i32 %t30, ptr %l21
  br label %bb6
bb6:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load %"compiler/source:Span", ptr %l1
  %t33 = load i64, ptr %l3, !tbaa !24
  %t37 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t31, %"compiler/source:Span" %t32, i64 %t33)
  store ptr %t37, ptr %l25
  br label %bb7
bb7:
  store { i64, [4 x i64] } zeroinitializer, ptr %t38
  %t39 = getelementptr { i64, [4 x i64] }, ptr %t38, i32 0, i32 0
  store i64 2, ptr %t39
  %t40 = load %"compiler/source:Span", ptr %l16
  %t41 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t40, 0
  %t42 = load i32, ptr %l21, !tbaa !23
  %t43 = insertvalue { %"compiler/source:Span", i32, ptr } %t41, i32 %t42, 1
  %t44 = load ptr, ptr %l25, !tbaa !29
  %t45 = insertvalue { %"compiler/source:Span", i32, ptr } %t43, ptr %t44, 2
  %t46 = getelementptr { i64, [4 x i64] }, ptr %t38, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t45, ptr %t46
  %t47 = load { i64, [4 x i64] }, ptr %t38
  %t48 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store ptr %t48, ptr %lp5
  %t50 = load ptr, ptr %lp5
  store { i64, [4 x i64] } %t47, ptr %t50
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t52 = load %"compiler/source:Span", ptr %l1
  %t53 = load %"compiler/source:Span", ptr %l1
  %t54 = load ptr, ptr %lp5
  %t61 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efield(ptr %v0, ptr %t51, %"compiler/source:Span" %t52, %"compiler/source:Span" %t53, ptr %t54, i32 %a2)
  store ptr %t61, ptr %l32
  br label %bb8
bb8:
  %t62 = load ptr, ptr %l32, !tbaa !29
  store ptr %t62, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i1
  %l5 = alloca i1
  %l8 = alloca i32
  %l11 = alloca i1
  %l15 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i1, ptr %l4, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l1, !tbaa !23
  %t11 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %t7, i32 %t8)
  store i32 %t11, ptr %l8
  br label %bb4
bb3:
  store i1 false, ptr %l5, !tbaa !21
  br label %bb5
bb4:
  %t12 = load i32, ptr %l8
  %t14 = trunc i64 1 to i32
  %t15 = icmp eq i32 %t12, %t14
  store i1 %t15, ptr %l5, !tbaa !21
  br label %bb5
bb5:
  %t17 = load i1, ptr %l5, !tbaa !21
  br i1 %t17, label %bb6, label %bb7
bb6:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/check:Checker", ptr %t18, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t22 = load i32, ptr %l1, !tbaa !23
  %t25 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t21, i32 %t22)
  store i1 %t25, ptr %l15
  br label %bb8
bb7:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb9
bb8:
  %t26 = load i1, ptr %l15, !tbaa !21
  store i1 %t26, ptr %l11, !tbaa !21
  br label %bb9
bb9:
  %t27 = load i1, ptr %l11, !tbaa !21
  store i1 %t27, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisOver(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i1
  %l5 = alloca i1
  %l8 = alloca i32
  %l11 = alloca i1
  %l15 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i1, ptr %l4, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l1, !tbaa !23
  %t11 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %t7, i32 %t8)
  store i32 %t11, ptr %l8
  br label %bb4
bb3:
  store i1 false, ptr %l5, !tbaa !21
  br label %bb5
bb4:
  %t12 = load i32, ptr %l8
  %t14 = trunc i64 4 to i32
  %t15 = icmp eq i32 %t12, %t14
  store i1 %t15, ptr %l5, !tbaa !21
  br label %bb5
bb5:
  %t17 = load i1, ptr %l5, !tbaa !21
  br i1 %t17, label %bb6, label %bb7
bb6:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/check:Checker", ptr %t18, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t22 = load i32, ptr %l1, !tbaa !23
  %t25 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t21, i32 %t22)
  store i1 %t25, ptr %l15
  br label %bb8
bb7:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb9
bb8:
  %t26 = load i1, ptr %l15, !tbaa !21
  store i1 %t26, ptr %l11, !tbaa !21
  br label %bb9
bb9:
  %t27 = load i1, ptr %l11, !tbaa !21
  store i1 %t27, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elambdaErrs(ptr %v0, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca i1
  %l32 = alloca i32
  %l41 = alloca ptr
  %l42 = alloca ptr
  %l45 = alloca ptr
  %l51 = alloca i32
  %l57 = alloca i32
  %l58 = alloca i32
  %l64 = alloca i32
  %l65 = alloca i32
  %l68 = alloca ptr
  %l73 = alloca i32
  %l78 = alloca i32
  %l79 = alloca i32
  %l84 = alloca i32
  %l89 = alloca i64
  %l90 = alloca i32
  %rv = alloca ptr
  %t191 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t7 = load ptr, ptr %l1, !tbaa !29
  store ptr %t7, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t8 = load ptr, ptr %l12, !tbaa !29
  %t9 = icmp ne ptr %t8, null
  br i1 %t9, label %bb4, label %bb5
bb4:
  %t11 = load ptr, ptr %l12, !tbaa !29
  %t12 = load i64, ptr %t11
  %t14 = icmp eq i64 %t12, 15
  store i1 %t14, ptr %l13, !tbaa !21
  br label %bb5
bb5:
  %t15 = load i1, ptr %l13, !tbaa !21
  br i1 %t15, label %bb6, label %bb7
bb6:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t18, i32 0, i32 0
  %t20 = load %"compiler/source:Span", ptr %t19
  store %"compiler/source:Span" %t20, ptr %l3
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr { i64, [5 x i64] }, ptr %t22, i32 0, i32 1
  %t25 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t24, i32 0, i32 1
  %t26 = load i32, ptr %t25
  store i32 %t26, ptr %l4, !tbaa !23
  %t28 = load ptr, ptr %l1, !tbaa !29
  %t30 = getelementptr { i64, [5 x i64] }, ptr %t28, i32 0, i32 1
  %t31 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t30, i32 0, i32 2
  %t32 = load ptr, ptr %t31
  store ptr %t32, ptr %l5, !tbaa !29
  br label %bb8
bb7:
  br label %bb29
bb8:
  %t34 = load ptr, ptr %l5, !tbaa !29
  store ptr %t34, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t35 = load ptr, ptr %l22, !tbaa !29
  %t36 = icmp ne ptr %t35, null
  br i1 %t36, label %bb9, label %bb10
bb9:
  %t38 = load ptr, ptr %l22, !tbaa !29
  %t39 = load i64, ptr %t38
  %t41 = icmp eq i64 %t39, 1
  store i1 %t41, ptr %l23, !tbaa !21
  br label %bb10
bb10:
  %t42 = load i1, ptr %l23, !tbaa !21
  br i1 %t42, label %bb11, label %bb12
bb11:
  %t43 = load ptr, ptr %l5, !tbaa !29
  %t45 = getelementptr { i64, [4 x i64] }, ptr %t43, i32 0, i32 1
  %t46 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t45, i32 0, i32 0
  %t47 = load i32, ptr %t46
  store i32 %t47, ptr %l6, !tbaa !23
  br label %bb13
bb12:
  br label %bb28
bb13:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/check:Checker", ptr %t49, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !29
  %t54 = getelementptr %"compiler/generic:Program", ptr %t52, i32 0, i32 2
  %t55 = load i32, ptr %l4, !tbaa !23
  %t58 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t54, i32 %t55)
  store i32 %t58, ptr %l32
  br label %bb14
bb14:
  %t59 = load i32, ptr %l2, !tbaa !23
  %t60 = load i32, ptr %l32, !tbaa !23
  %t62 = icmp eq i32 %t60, %t59
  br i1 %t62, label %bb15, label %bb16
bb15:
  %t64 = load ptr, ptr %l1, !tbaa !29
  store ptr %t64, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/check:Checker", ptr %t67, i32 0, i32 11
  %t70 = load i32, ptr %l6, !tbaa !23
  %t72 = sext i32 %t70 to i64
  %t75 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t69, i64 %t72)
  store ptr %t75, ptr %l41
  br label %bb18
bb18:
  %t76 = load ptr, ptr %l41, !tbaa !29
  store ptr %t76, ptr %l7, !tbaa !29
  %t77 = load ptr, ptr %l7, !tbaa !29
  store ptr %t77, ptr %l42, !tbaa !29
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/check:Checker", ptr %t78, i32 0, i32 1
  %t81 = load ptr, ptr %t80, !tbaa !29
  %t83 = getelementptr %"compiler/generic:Program", ptr %t81, i32 0, i32 2
  store ptr %t83, ptr %l45, !tbaa !29
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/check:Checker", ptr %t84, i32 0, i32 1
  %t87 = load ptr, ptr %t86, !tbaa !29
  %t89 = getelementptr %"compiler/generic:Program", ptr %t87, i32 0, i32 2
  %t90 = load ptr, ptr %l7, !tbaa !29
  %t92 = getelementptr %"compiler/typed:Body", ptr %t90, i32 0, i32 2
  %t93 = load i32, ptr %t92, !tbaa !23
  %t96 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t89, i32 %t93)
  store i32 %t96, ptr %l51
  br label %bb19
bb19:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/check:Checker", ptr %t97, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !29
  %t102 = getelementptr %"compiler/generic:Program", ptr %t100, i32 0, i32 2
  %t103 = load ptr, ptr %l7, !tbaa !29
  %t105 = getelementptr %"compiler/typed:Body", ptr %t103, i32 0, i32 2
  %t106 = load i32, ptr %t105, !tbaa !23
  %t109 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t102, i32 %t106)
  store i32 %t109, ptr %l57
  br label %bb20
bb20:
  %t110 = load i32, ptr %l2, !tbaa !23
  store i32 %t110, ptr %l58, !tbaa !23
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr %"compiler/check:Checker", ptr %t111, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !29
  %t116 = getelementptr %"compiler/generic:Program", ptr %t114, i32 0, i32 2
  %t117 = load ptr, ptr %l7, !tbaa !29
  %t119 = getelementptr %"compiler/typed:Body", ptr %t117, i32 0, i32 2
  %t120 = load i32, ptr %t119, !tbaa !23
  %t123 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesOf(ptr %v0, ptr %t116, i32 %t120)
  store i32 %t123, ptr %l64
  br label %bb21
bb21:
  %t124 = load ptr, ptr %l45, !tbaa !29
  %t125 = load i32, ptr %l51, !tbaa !23
  %t126 = load i32, ptr %l57, !tbaa !23
  %t127 = load i32, ptr %l58, !tbaa !23
  %t128 = load i32, ptr %l64, !tbaa !23
  %t129 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t124, i32 %t125, i32 %t126, i32 %t127, i32 %t128, i64 0)
  store i32 %t129, ptr %l65
  br label %bb22
bb22:
  %t130 = load i32, ptr %l65, !tbaa !23
  %t131 = load ptr, ptr %l42, !tbaa !29
  %t132 = getelementptr %"compiler/typed:Body", ptr %t131, i32 0, i32 2
  store i32 %t130, ptr %t132, !tbaa !23
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t135 = getelementptr %"compiler/check:Checker", ptr %t133, i32 0, i32 1
  %t136 = load ptr, ptr %t135, !tbaa !29
  %t138 = getelementptr %"compiler/generic:Program", ptr %t136, i32 0, i32 2
  store ptr %t138, ptr %l68, !tbaa !29
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t141 = getelementptr %"compiler/check:Checker", ptr %t139, i32 0, i32 1
  %t142 = load ptr, ptr %t141, !tbaa !29
  %t144 = getelementptr %"compiler/generic:Program", ptr %t142, i32 0, i32 2
  %t145 = load i32, ptr %l4, !tbaa !23
  %t148 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t144, i32 %t145)
  store i32 %t148, ptr %l73
  br label %bb23
bb23:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t151 = getelementptr %"compiler/check:Checker", ptr %t149, i32 0, i32 1
  %t152 = load ptr, ptr %t151, !tbaa !29
  %t154 = getelementptr %"compiler/generic:Program", ptr %t152, i32 0, i32 2
  %t155 = load i32, ptr %l4, !tbaa !23
  %t158 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t154, i32 %t155)
  store i32 %t158, ptr %l78
  br label %bb24
bb24:
  %t159 = load i32, ptr %l2, !tbaa !23
  store i32 %t159, ptr %l79, !tbaa !23
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t162 = getelementptr %"compiler/check:Checker", ptr %t160, i32 0, i32 1
  %t163 = load ptr, ptr %t162, !tbaa !29
  %t165 = getelementptr %"compiler/generic:Program", ptr %t163, i32 0, i32 2
  %t166 = load i32, ptr %l4, !tbaa !23
  %t169 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesOf(ptr %v0, ptr %t165, i32 %t166)
  store i32 %t169, ptr %l84
  br label %bb25
bb25:
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t172 = getelementptr %"compiler/check:Checker", ptr %t170, i32 0, i32 1
  %t173 = load ptr, ptr %t172, !tbaa !29
  %t175 = getelementptr %"compiler/generic:Program", ptr %t173, i32 0, i32 2
  %t176 = load i32, ptr %l4, !tbaa !23
  %t179 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNamesIdOf(ptr %v0, ptr %t175, i32 %t176)
  store i64 %t179, ptr %l89
  br label %bb26
bb26:
  %t180 = load ptr, ptr %l68, !tbaa !29
  %t181 = load i32, ptr %l73, !tbaa !23
  %t182 = load i32, ptr %l78, !tbaa !23
  %t183 = load i32, ptr %l79, !tbaa !23
  %t184 = load i32, ptr %l84, !tbaa !23
  %t185 = load i64, ptr %l89, !tbaa !24
  %t186 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t180, i32 %t181, i32 %t182, i32 %t183, i32 %t184, i64 %t185)
  store i32 %t186, ptr %l90
  br label %bb27
bb27:
  %t187 = load i32, ptr %l90, !tbaa !23
  %t188 = load %"compiler/source:Span", ptr %l3
  %t190 = load ptr, ptr %l5, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t191
  %t192 = getelementptr { i64, [5 x i64] }, ptr %t191, i32 0, i32 0
  store i64 15, ptr %t192
  %t194 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t188, 0
  %t196 = insertvalue { %"compiler/source:Span", i32, ptr } %t194, i32 %t187, 1
  %t198 = insertvalue { %"compiler/source:Span", i32, ptr } %t196, ptr %t190, 2
  %t199 = getelementptr { i64, [5 x i64] }, ptr %t191, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t198, ptr %t199
  %t200 = load { i64, [5 x i64] }, ptr %t191
  %t202 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t200, ptr %t202
  store ptr %t202, ptr %rv
  br label %ret
bb28:
  %t204 = load ptr, ptr %l1, !tbaa !29
  store ptr %t204, ptr %rv
  br label %ret
bb29:
  %t207 = load ptr, ptr %l1, !tbaa !29
  store ptr %t207, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneMethodCalled(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"compiler/check:laneNode"
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %lp7 = alloca ptr
  %l8 = alloca i32
  %l12 = alloca %"compiler/check:laneNode"
  %l16 = alloca i1
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca { i64, ptr }
  %l42 = alloca { i64, ptr }
  %l44 = alloca i1
  %l50 = alloca %"compiler/check:laneNode"
  %l55 = alloca i1
  %l58 = alloca i1
  %l60 = alloca i1
  %l63 = alloca i1
  %l64 = alloca i1
  %l68 = alloca i1
  %l73 = alloca { i64, ptr }
  %l75 = alloca { i64, ptr }
  %l77 = alloca { i64, ptr }
  %l79 = alloca i64
  %l80 = alloca { i64, ptr }
  %l83 = alloca { i64, ptr }
  %l84 = alloca { i64, ptr }
  %l85 = alloca i64
  %l86 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 35
  %t7 = call %"compiler/check:laneNode" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alaneNode_3e_2eAt_3ccompiler_2fcheck_3alaneNode_3e(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store %"compiler/check:laneNode" %t7, ptr %l12
  br label %bb1
bb1:
  %t8 = load %"compiler/check:laneNode", ptr %l12
  store %"compiler/check:laneNode" %t8, ptr %l2
  %t9 = getelementptr %"compiler/check:laneNode", ptr %l2, i32 0, i32 0
  %t10 = load i64, ptr %t9, !tbaa !24
  %t11 = load i64, ptr @G_2ecompiler_2fcheck_2eLaneArr, !tbaa !24
  %t14 = icmp eq i64 %t10, %t11
  br i1 %t14, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb4
bb3:
  %t16 = getelementptr %"compiler/check:laneNode", ptr %l2, i32 0, i32 0
  %t17 = load i64, ptr %t16, !tbaa !24
  %t18 = load i64, ptr @G_2ecompiler_2fcheck_2eLaneScalar, !tbaa !24
  %t21 = icmp eq i64 %t17, %t18
  store i1 %t21, ptr %l16, !tbaa !21
  br label %bb4
bb4:
  %t23 = load i1, ptr %l16, !tbaa !21
  br i1 %t23, label %bb5, label %bb6
bb5:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d34, i32 0, i32 1) }, ptr %l20, !tbaa !27
  %t24 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t24, ptr %l21, !tbaa !27
  %t25 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t25, 0
  store i64 %t26, ptr %l22, !tbaa !24
  %t27 = load i64, ptr %l22, !tbaa !24
  %t28 = mul i64 %t27, 1
  %t29 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t28)
  %t30 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t29, 1
  store { i64, ptr } %t31, ptr %l23, !tbaa !27
  %t32 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !27
  %t34 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !27
  %t36 = load i64, ptr %l22, !tbaa !24
  %t37 = mul i64 %t36, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t33, ptr %t35, i64 %t37, i1 false)
  %t38 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t38, ptr %l21, !tbaa !27
  %t39 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t39, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t40 = getelementptr %"compiler/check:laneNode", ptr %l2, i32 0, i32 4
  %t41 = load i64, ptr %t40, !tbaa !24
  %t42 = getelementptr %"compiler/check:laneNode", ptr %l2, i32 0, i32 5
  %t43 = load i64, ptr %t42, !tbaa !24
  %t44 = getelementptr %"compiler/check:laneNode", ptr %l2, i32 0, i32 6
  %t45 = load i64, ptr %t44, !tbaa !24
  %t47 = insertvalue [3 x i64] undef, i64 %t41, 0
  %t49 = insertvalue [3 x i64] %t47, i64 %t43, 1
  %t51 = insertvalue [3 x i64] %t49, i64 %t45, 2
  %t53 = call ptr @__olang_scope_alloc_a(ptr %s2, i64 24, i64 8)
  store [3 x i64] %t51, ptr %t53
  store ptr %t53, ptr %l3
  store i64 0, ptr %l4, !tbaa !24
  %t55 = load ptr, ptr %l3
  store i64 3, ptr %l5, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t58 = load i64, ptr %l4, !tbaa !24
  %t59 = load i64, ptr %l5, !tbaa !24
  %t62 = icmp slt i64 %t58, %t59
  %t64 = xor i1 %t62, true
  br i1 %t64, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb41
bb10:
  br label %bb11
bb11:
  %t66 = load ptr, ptr %l3
  %t67 = load i64, ptr %l4, !tbaa !24
  %t70 = getelementptr [3 x i64], ptr %t66, i64 0, i64 %t67
  %t71 = load i64, ptr %t70, !tbaa !34
  store i64 %t71, ptr %l6, !tbaa !24
  %t73 = load i64, ptr %l6, !tbaa !24
  %t75 = icmp slt i64 %t73, 0
  br i1 %t75, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s3)
  br label %bb40
bb13:
  br label %bb14
bb14:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t78 = load i64, ptr %l6, !tbaa !24
  %t81 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneMethodCalled(ptr %v0, ptr %v1, ptr %t77, i64 %t78)
  store { i64, ptr } %t81, ptr %l42
  br label %bb15
bb15:
  %t82 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t82, ptr %lp7
  %t83 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t84 = load ptr, ptr %lp7
  store { i64, ptr } %t83, ptr %t84, !tbaa !27
  %t85 = load ptr, ptr %lp7
  %t86 = load { i64, ptr }, ptr %t85, !tbaa !27
  %t88 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s3, { i64, ptr } %t86, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d35, i32 0, i32 1) })
  store i1 %t88, ptr %l44
  br label %bb16
bb16:
  %t89 = load i1, ptr %l44, !tbaa !21
  %t90 = xor i1 %t89, true
  br i1 %t90, label %bb17, label %bb18
bb17:
  %t92 = load ptr, ptr %lp7
  %t93 = load { i64, ptr }, ptr %t92, !tbaa !27
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  store { i64, ptr } %t93, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr %"compiler/check:Checker", ptr %t95, i32 0, i32 35
  %t98 = load i64, ptr %l6, !tbaa !24
  %t101 = call %"compiler/check:laneNode" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alaneNode_3e_2eAt_3ccompiler_2fcheck_3alaneNode_3e(ptr %v0, ptr %s3, ptr %t97, i64 %t98)
  store %"compiler/check:laneNode" %t101, ptr %l50
  br label %bb20
bb20:
  %t102 = getelementptr %"compiler/check:laneNode", ptr %l50, i32 0, i32 8
  %t103 = load i32, ptr %t102, !tbaa !23
  store i32 %t103, ptr %l8, !tbaa !23
  %t105 = load i32, ptr %l8, !tbaa !23
  %t106 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t109 = icmp ne i32 %t105, %t106
  br i1 %t109, label %bb21, label %bb22
bb21:
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t112 = load i32, ptr %l8, !tbaa !23
  %t115 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t111, i32 %t112)
  store i1 %t115, ptr %l58
  br label %bb23
bb22:
  store i1 false, ptr %l55, !tbaa !21
  br label %bb32
bb23:
  %t116 = load i1, ptr %l58, !tbaa !21
  %t117 = xor i1 %t116, true
  br i1 %t117, label %bb24, label %bb25
bb24:
  store i1 true, ptr %l60, !tbaa !21
  br label %bb31
bb25:
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t120 = load i32, ptr %l8, !tbaa !23
  %t123 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t119, i32 %t120)
  store i1 %t123, ptr %l63
  br label %bb26
bb26:
  %t124 = load i1, ptr %l63, !tbaa !21
  br i1 %t124, label %bb27, label %bb28
bb27:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t127 = getelementptr %"compiler/check:Checker", ptr %t125, i32 0, i32 1
  %t128 = load ptr, ptr %t127, !tbaa !29
  %t129 = load i32, ptr %l8, !tbaa !23
  %t132 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eExtends(ptr %v0, ptr %t128, i32 %t129)
  store i1 %t132, ptr %l68
  br label %bb29
bb28:
  store i1 false, ptr %l64, !tbaa !21
  br label %bb30
bb29:
  %t133 = load i1, ptr %l68, !tbaa !21
  %t134 = xor i1 %t133, true
  store i1 %t134, ptr %l64, !tbaa !21
  br label %bb30
bb30:
  %t136 = load i1, ptr %l64, !tbaa !21
  store i1 %t136, ptr %l60, !tbaa !21
  br label %bb31
bb31:
  %t137 = load i1, ptr %l60, !tbaa !21
  store i1 %t137, ptr %l55, !tbaa !21
  br label %bb32
bb32:
  %t138 = load i1, ptr %l55, !tbaa !21
  br i1 %t138, label %bb33, label %bb34
bb33:
  store %olang.scope zeroinitializer, ptr %s6
  %t139 = getelementptr %"compiler/check:laneNode", ptr %l2, i32 0, i32 0
  %t140 = load i64, ptr %t139, !tbaa !24
  %t141 = load i64, ptr @G_2ecompiler_2fcheck_2eLaneBin, !tbaa !24
  %t144 = icmp eq i64 %t140, %t141
  br i1 %t144, label %bb35, label %bb36
bb34:
  br label %bb39
bb35:
  %t146 = getelementptr %"compiler/check:laneNode", ptr %l2, i32 0, i32 1
  %t147 = load i32, ptr %t146
  %t149 = call { i64, ptr } @compiler_2fcheck_2eoperatorName(ptr %s6, i32 %t147)
  store { i64, ptr } %t149, ptr %l75
  br label %bb37
bb36:
  store { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d36, i32 0, i32 1) }, ptr %l77, !tbaa !27
  %t150 = load { i64, ptr }, ptr %l77, !tbaa !27
  store { i64, ptr } %t150, ptr %l73, !tbaa !27
  br label %bb38
bb37:
  %t152 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d37, i32 0, i32 1) }, 1
  %t153 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d37, i32 0, i32 1) }, 0
  %t154 = load { i64, ptr }, ptr %l75, !tbaa !27
  %t155 = extractvalue { i64, ptr } %t154, 1
  %t156 = extractvalue { i64, ptr } %t154, 0
  %t157 = add i64 %t153, %t156
  %t158 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d37, i32 0, i32 1) }, 1
  %t159 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d37, i32 0, i32 1) }, 0
  %t160 = add i64 %t157, %t159
  %t161 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t160)
  call void @olang_textcopy(ptr %t161, ptr %t152, i64 %t153)
  %t162 = getelementptr i8, ptr %t161, i64 %t153
  call void @olang_textcopy(ptr %t162, ptr %t155, i64 %t156)
  %t163 = getelementptr i8, ptr %t162, i64 %t156
  call void @olang_textcopy(ptr %t163, ptr %t158, i64 %t159)
  %t164 = insertvalue { i64, ptr } undef, i64 %t160, 0
  %t165 = insertvalue { i64, ptr } %t164, ptr %t161, 1
  store { i64, ptr } %t165, ptr %l73, !tbaa !27
  br label %bb38
bb38:
  %t167 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t168 = extractvalue { i64, ptr } %t167, 0
  store i64 %t168, ptr %l79, !tbaa !24
  %t169 = load i64, ptr %l79, !tbaa !24
  %t170 = mul i64 %t169, 1
  %t171 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t170)
  %t172 = insertvalue { i64, ptr } undef, i64 %t169, 0
  %t173 = insertvalue { i64, ptr } %t172, ptr %t171, 1
  store { i64, ptr } %t173, ptr %l80, !tbaa !27
  %t174 = getelementptr { i64, ptr }, ptr %l80, i32 0, i32 1
  %t175 = load ptr, ptr %t174, !tbaa !27
  %t176 = getelementptr { i64, ptr }, ptr %l73, i32 0, i32 1
  %t177 = load ptr, ptr %t176, !tbaa !27
  %t178 = load i64, ptr %l79, !tbaa !24
  %t179 = mul i64 %t178, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t175, ptr %t177, i64 %t179, i1 false)
  %t180 = load { i64, ptr }, ptr %l80, !tbaa !27
  store { i64, ptr } %t180, ptr %l73, !tbaa !27
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  %t181 = load { i64, ptr }, ptr %l73, !tbaa !27
  store { i64, ptr } %t181, ptr %rv
  br label %ret
bb39:
  call void @__olang_scope_close(ptr %s3)
  br label %bb40
bb40:
  %t182 = load i64, ptr %l4, !tbaa !24
  %t184 = add i64 %t182, 1
  store i64 %t184, ptr %l4, !tbaa !24
  br label %bb8
bb41:
  call void @__olang_scope_close(ptr %s2)
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d38, i32 0, i32 1) }, ptr %l83, !tbaa !27
  %t186 = load { i64, ptr }, ptr %l83, !tbaa !27
  store { i64, ptr } %t186, ptr %l84, !tbaa !27
  %t187 = load { i64, ptr }, ptr %l84, !tbaa !27
  %t188 = extractvalue { i64, ptr } %t187, 0
  store i64 %t188, ptr %l85, !tbaa !24
  %t189 = load i64, ptr %l85, !tbaa !24
  %t190 = mul i64 %t189, 1
  %t191 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t190)
  %t192 = insertvalue { i64, ptr } undef, i64 %t189, 0
  %t193 = insertvalue { i64, ptr } %t192, ptr %t191, 1
  store { i64, ptr } %t193, ptr %l86, !tbaa !27
  %t194 = getelementptr { i64, ptr }, ptr %l86, i32 0, i32 1
  %t195 = load ptr, ptr %t194, !tbaa !27
  %t196 = getelementptr { i64, ptr }, ptr %l84, i32 0, i32 1
  %t197 = load ptr, ptr %t196, !tbaa !27
  %t198 = load i64, ptr %l85, !tbaa !24
  %t199 = mul i64 %t198, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t195, ptr %t197, i64 %t199, i1 false)
  %t200 = load { i64, ptr }, ptr %l86, !tbaa !27
  store { i64, ptr } %t200, ptr %l84, !tbaa !27
  %t201 = load { i64, ptr }, ptr %l84, !tbaa !27
  store { i64, ptr } %t201, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i1
  %l15 = alloca i1
  %l16 = alloca i64
  %l17 = alloca i64
  %l20 = alloca i64
  %l23 = alloca i1
  %l26 = alloca i32
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t18, i32 0, i32 2
  %t20 = load i64, ptr %t19
  store i64 %t20, ptr %l3, !tbaa !24
  br label %bb5
bb4:
  br label %bb17
bb5:
  %t22 = load i64, ptr %l3, !tbaa !24
  %t23 = load i64, ptr @G_2ecompiler_2fcheck_2eLaneMagic, !tbaa !24
  %t26 = icmp sge i64 %t22, %t23
  br i1 %t26, label %bb6, label %bb7
bb6:
  %t28 = load i64, ptr %l3, !tbaa !24
  store i64 %t28, ptr %l16, !tbaa !24
  %t29 = load i64, ptr @G_2ecompiler_2fcheck_2eLaneMagic, !tbaa !24
  store i64 %t29, ptr %l17, !tbaa !24
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/check:Checker", ptr %t30, i32 0, i32 35
  %t34 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alaneNode_3e_2eLen_3ccompiler_2fcheck_3alaneNode_3e(ptr %v0, ptr %t32)
  store i64 %t34, ptr %l20
  br label %bb8
bb7:
  store i1 false, ptr %l15, !tbaa !21
  br label %bb9
bb8:
  %t35 = load i64, ptr %l17, !tbaa !24
  %t36 = load i64, ptr %l20, !tbaa !24
  %t37 = add i64 %t35, %t36
  %t38 = load i64, ptr %l16, !tbaa !24
  %t40 = icmp slt i64 %t38, %t37
  store i1 %t40, ptr %l15, !tbaa !21
  br label %bb9
bb9:
  %t42 = load i1, ptr %l15, !tbaa !21
  br i1 %t42, label %bb10, label %bb11
bb10:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = load i32, ptr %l2, !tbaa !23
  %t47 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayOf(ptr %v0, ptr %t43, i32 %t44)
  store i32 %t47, ptr %l26
  br label %bb12
bb11:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb13
bb12:
  %t48 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t49 = load i32, ptr %l26, !tbaa !23
  %t51 = icmp ne i32 %t49, %t48
  store i1 %t51, ptr %l23, !tbaa !21
  br label %bb13
bb13:
  %t53 = load i1, ptr %l23, !tbaa !21
  br i1 %t53, label %bb14, label %bb15
bb14:
  %t54 = load i64, ptr %l3, !tbaa !24
  %t55 = load i64, ptr @G_2ecompiler_2fcheck_2eLaneMagic, !tbaa !24
  %t58 = sub i64 %t54, %t55
  store i64 %t58, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  store i64 -1, ptr %rv
  br label %ret
bb17:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistHoldsBy(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i32
  %l12 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l24 = alloca i1
  %l30 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t10 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t6, i32 %a1)
  store { i64, ptr } %t10, ptr %l12
  br label %bb1
bb1:
  %t11 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t12 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t12, 0
  store i64 %t14, ptr %l6, !tbaa !24
  br label %bb2
bb2:
  %t16 = load i64, ptr %l5, !tbaa !24
  %t17 = load i64, ptr %l6, !tbaa !24
  %t20 = icmp slt i64 %t16, %t17
  %t22 = xor i1 %t20, true
  br i1 %t22, label %bb3, label %bb4
bb3:
  br label %bb14
bb4:
  br label %bb5
bb5:
  %t24 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t24, ptr %l19, !tbaa !27
  %t25 = load i64, ptr %l5, !tbaa !24
  %t27 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = getelementptr i32, ptr %t28, i64 %t25
  %t30 = load i32, ptr %t29, !tbaa !33
  store i32 %t30, ptr %l7, !tbaa !23
  %t32 = load i32, ptr %l7, !tbaa !23
  %t34 = icmp ne i32 %t32, 0
  br i1 %t34, label %bb6, label %bb7
bb6:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load i32, ptr %l7, !tbaa !23
  %t41 = add i64 %a3, 1
  %t46 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsBy(ptr %v0, ptr %t36, i32 %t37, i32 %a2, i64 %t41)
  store i1 %t46, ptr %l30
  br label %bb8
bb7:
  store i1 false, ptr %l24, !tbaa !21
  br label %bb9
bb8:
  %t47 = load i1, ptr %l30, !tbaa !21
  store i1 %t47, ptr %l24, !tbaa !21
  br label %bb9
bb9:
  %t48 = load i1, ptr %l24, !tbaa !21
  br i1 %t48, label %bb10, label %bb11
bb10:
  store i1 true, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t50 = load i64, ptr %l5, !tbaa !24
  %t52 = add i64 %t50, 1
  store i64 %t52, ptr %l5, !tbaa !24
  br label %bb2
bb14:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitFits(ptr %v0, ptr %a0, %"compiler/check:litv" %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/check:litv"
  %l3 = alloca i32
  %l6 = alloca i32
  %l11 = alloca i1
  %l19 = alloca i1
  %l20 = alloca i1
  %l23 = alloca i1
  %l29 = alloca i1
  %l30 = alloca i32
  %l32 = alloca double
  %l33 = alloca i1
  %l40 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store %"compiler/check:litv" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t1, i32 %a2)
  store i32 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i32, ptr %l6, !tbaa !23
  store i32 %t6, ptr %l3, !tbaa !23
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  %t13 = load i32, ptr %l3, !tbaa !23
  %t16 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNumber(ptr %v0, ptr %t12, i32 %t13)
  store i1 %t16, ptr %l11
  br label %bb2
bb2:
  %t17 = load i1, ptr %l11, !tbaa !21
  %t18 = xor i1 %t17, true
  br i1 %t18, label %bb3, label %bb4
bb3:
  store i1 false, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t21 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 1
  %t22 = load i1, ptr %t21, !tbaa !21
  br i1 %t22, label %bb6, label %bb7
bb6:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/check:Checker", ptr %t24, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t29 = getelementptr %"compiler/generic:Program", ptr %t27, i32 0, i32 2
  %t30 = load i32, ptr %l3, !tbaa !23
  %t33 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t29, i32 %t30)
  store i1 %t33, ptr %l19
  br label %bb8
bb7:
  br label %bb13
bb8:
  %t34 = load i1, ptr %l19, !tbaa !21
  br i1 %t34, label %bb9, label %bb10
bb9:
  %t35 = load i32, ptr %l3, !tbaa !23
  %t36 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 4
  %t37 = load double, ptr %t36, !tbaa !26
  %t40 = call i1 @compiler_2fcheck_2efloatOverflows(i32 %t35, double %t37)
  store i1 %t40, ptr %l23
  br label %bb11
bb10:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb12
bb11:
  %t41 = load i1, ptr %l23, !tbaa !21
  %t42 = xor i1 %t41, true
  store i1 %t42, ptr %l20, !tbaa !21
  br label %bb12
bb12:
  %t44 = load i1, ptr %l20, !tbaa !21
  store i1 %t44, ptr %rv
  br label %ret
bb13:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/check:Checker", ptr %t45, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !29
  %t50 = getelementptr %"compiler/generic:Program", ptr %t48, i32 0, i32 2
  %t51 = load i32, ptr %l3, !tbaa !23
  %t54 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t50, i32 %t51)
  store i1 %t54, ptr %l29
  br label %bb14
bb14:
  %t55 = load i1, ptr %l29, !tbaa !21
  br i1 %t55, label %bb15, label %bb16
bb15:
  %t56 = load i32, ptr %l3, !tbaa !23
  store i32 %t56, ptr %l30, !tbaa !23
  %t57 = load %"compiler/check:litv", ptr %l1
  %t59 = call double @compiler_2fcheck_2elitF64(%"compiler/check:litv" %t57)
  store double %t59, ptr %l32
  br label %bb17
bb16:
  br label %bb19
bb17:
  %t60 = load i32, ptr %l30, !tbaa !23
  %t61 = load double, ptr %l32, !tbaa !26
  %t62 = call i1 @compiler_2fcheck_2efloatOverflows(i32 %t60, double %t61)
  store i1 %t62, ptr %l33
  br label %bb18
bb18:
  %t63 = load i1, ptr %l33, !tbaa !21
  %t64 = xor i1 %t63, true
  store i1 %t64, ptr %rv
  br label %ret
bb19:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/check:Checker", ptr %t66, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !29
  %t71 = getelementptr %"compiler/generic:Program", ptr %t69, i32 0, i32 2
  %t72 = load %"compiler/check:litv", ptr %l1
  %t73 = load i32, ptr %l3, !tbaa !23
  %t77 = call i1 @compiler_2fcheck_2eintFits(ptr %v0, ptr %t71, %"compiler/check:litv" %t72, i32 %t73)
  store i1 %t77, ptr %l40
  br label %bb20
bb20:
  %t78 = load i1, ptr %l40, !tbaa !21
  store i1 %t78, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, i32 %a3, i32 %a4, { i64, [2 x i64] } %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca i64
  %l9 = alloca ptr
  %l11 = alloca ptr
  %l21 = alloca %"compiler/typed:Local"
  %l22 = alloca i32
  %l26 = alloca i1
  %l29 = alloca { i64, ptr }
  %l30 = alloca i1
  %l33 = alloca ptr
  %l34 = alloca i32
  %l35 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i32
  %l41 = alloca %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed"
  %l50 = alloca i32
  %l53 = alloca i1
  %l57 = alloca %"compiler/generic:Desc"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t1)
  store ptr %t3, ptr %l9
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l9, !tbaa !29
  store ptr %t4, ptr %l6, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t5)
  store ptr %t7, ptr %l11
  br label %bb2
bb2:
  %t8 = load i32, ptr %l1, !tbaa !23
  %t10 = load i32, ptr %l3, !tbaa !23
  %t11 = load ptr, ptr %l6, !tbaa !29
  %t13 = getelementptr %"compiler/check:frame", ptr %t11, i32 0, i32 7
  %t14 = load i64, ptr %t13, !tbaa !24
  %t16 = trunc i64 %t14 to i32
  %t26 = call %"compiler/typed:Local" @compiler_2ftyped_3aLocal_2ector(ptr %s0, i32 %t8, %"compiler/source:Span" %a2, i32 %t10, i32 %t16, i32 %a4, { i64, [2 x i64] } %a5)
  store %"compiler/typed:Local" %t26, ptr %l21
  br label %bb3
bb3:
  %t27 = load ptr, ptr %l11, !tbaa !29
  %t28 = load %"compiler/typed:Local", ptr %l21
  %t29 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddLocal(ptr %v0, ptr %t27, %"compiler/typed:Local" %t28)
  store i32 %t29, ptr %l22
  br label %bb4
bb4:
  %t30 = load i32, ptr %l22, !tbaa !23
  %t31 = sext i32 %t30 to i64
  store i64 %t31, ptr %l7, !tbaa !24
  %t33 = load i32, ptr %l1, !tbaa !23
  %t35 = icmp ne i32 %t33, 0
  br i1 %t35, label %bb5, label %bb6
bb5:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load i32, ptr %l1, !tbaa !23
  %t41 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t37, i32 %t38)
  store { i64, ptr } %t41, ptr %l29
  br label %bb7
bb6:
  store i1 false, ptr %l26, !tbaa !21
  br label %bb9
bb7:
  %t42 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t43 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t42, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d39, i32 0, i32 1) })
  store i1 %t43, ptr %l30
  br label %bb8
bb8:
  %t44 = load i1, ptr %l30, !tbaa !21
  %t45 = xor i1 %t44, true
  store i1 %t45, ptr %l26, !tbaa !21
  br label %bb9
bb9:
  %t47 = load i1, ptr %l26, !tbaa !21
  br i1 %t47, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s1
  %t48 = load ptr, ptr %l6, !tbaa !29
  %t50 = getelementptr %"compiler/check:frame", ptr %t48, i32 0, i32 9
  store ptr %t50, ptr %l33, !tbaa !29
  %t51 = load i32, ptr %l1, !tbaa !23
  store i32 %t51, ptr %l34, !tbaa !23
  %t52 = load ptr, ptr %l6, !tbaa !29
  %t54 = getelementptr %"compiler/check:frame", ptr %t52, i32 0, i32 8
  %t55 = load i32, ptr %l1, !tbaa !23
  %t58 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %t54, i32 %t55)
  %t59 = extractvalue { i32, i64 } %t58, 1
  %t60 = extractvalue { i32, i64 } %t58, 0
  store i32 %t60, ptr %l40
  %t61 = icmp ne i32 %t60, 0
  br i1 %t61, label %bb13, label %ok.62
ok.62:
  store i64 %t59, ptr %l39
  br label %bb12
bb11:
  br label %bb28
bb12:
  %t63 = load i64, ptr %l39, !tbaa !24
  store i64 %t63, ptr %l35, !tbaa !24
  br label %bb15
bb13:
  br label %bb14
bb14:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l35, !tbaa !24
  br label %bb15
bb15:
  %t64 = load i32, ptr %l34, !tbaa !23
  %t65 = load i64, ptr %l35, !tbaa !24
  %t66 = call %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" @std_2fpair_3aPair_3ccompiler_2fsource_3aNameId_2c_20I64_3e_2ector(ptr %s1, i32 %t64, i64 %t65)
  store %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" %t66, ptr %l41
  br label %bb16
bb16:
  %t67 = load ptr, ptr %l33, !tbaa !29
  %t68 = load %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed", ptr %l41
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fsource__H6d3eea1e3a905a651c612011755d5d17(ptr %v0, ptr %t67, %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" %t68)
  br label %bb17
bb17:
  %t69 = load ptr, ptr %l6, !tbaa !29
  %t71 = getelementptr %"compiler/check:frame", ptr %t69, i32 0, i32 8
  %t72 = load i32, ptr %l1, !tbaa !23
  %t73 = load i64, ptr %l7, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H862756c16d115e5c03a79726209f69fa(ptr %v0, ptr %t71, i32 %t72, i64 %t73)
  br label %bb18
bb18:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/check:Checker", ptr %t77, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t82 = getelementptr %"compiler/generic:Program", ptr %t80, i32 0, i32 2
  %t83 = load i32, ptr %l3, !tbaa !23
  %t86 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t82, i32 %t83)
  store i32 %t86, ptr %l50
  br label %bb19
bb19:
  %t87 = load i32, ptr %l50
  %t89 = trunc i64 18 to i32
  %t90 = icmp eq i32 %t87, %t89
  br i1 %t90, label %bb20, label %bb21
bb20:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/check:Checker", ptr %t92, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !29
  %t96 = load i32, ptr %l3, !tbaa !23
  %t99 = call %"compiler/generic:Desc" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDescOf(ptr %v0, ptr %t95, i32 %t96)
  store %"compiler/generic:Desc" %t99, ptr %l57
  br label %bb22
bb21:
  store i1 false, ptr %l53, !tbaa !21
  br label %bb23
bb22:
  %t100 = getelementptr %"compiler/generic:Desc", ptr %l57, i32 0, i32 0
  %t101 = load i64, ptr %t100, !tbaa !24
  %t102 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescNone, !tbaa !24
  %t105 = icmp ne i64 %t101, %t102
  store i1 %t105, ptr %l53, !tbaa !21
  br label %bb23
bb23:
  %t107 = load i1, ptr %l53, !tbaa !21
  br i1 %t107, label %bb24, label %bb25
bb24:
  %t108 = load ptr, ptr %l6, !tbaa !29
  %t110 = getelementptr %"compiler/check:frame", ptr %t108, i32 0, i32 4
  %t111 = getelementptr %"compiler/generic:Context", ptr %t110, i32 0, i32 3
  %t112 = load i32, ptr %l1, !tbaa !23
  %t113 = load i32, ptr %l3, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_H943a9bb03970f71acf57214091669a7d(ptr %v0, ptr %t111, i32 %t112, i32 %t113)
  br label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s1)
  br label %bb28
bb28:
  %t117 = load i64, ptr %l7, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t117, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"std/prelude/text:StringBuilder" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ememberListing(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %lp2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca %"std/prelude/text:StringBuilder"
  %l10 = alloca { i64, ptr }
  %l17 = alloca i64
  %l20 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l33 = alloca i1
  %l37 = alloca { i64, ptr }
  %l40 = alloca i1
  %l41 = alloca i1
  %l45 = alloca { i64, ptr }
  %l49 = alloca i1
  %l50 = alloca i1
  %l54 = alloca { i64, ptr }
  %l57 = alloca i1
  %l61 = alloca { i64, ptr }
  %l65 = alloca i1
  %l67 = alloca i1
  %l71 = alloca { i64, ptr }
  %l75 = alloca i64
  %l79 = alloca { i64, ptr }
  %l82 = alloca i64
  %l93 = alloca ptr
  %l95 = alloca { i64, ptr }
  %l98 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca %"std/prelude/text:StringBuilder"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v1)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l6
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t2, ptr %lp2
  %t3 = load %"std/prelude/text:StringBuilder", ptr %l6
  %t4 = load ptr, ptr %lp2
  store %"std/prelude/text:StringBuilder" %t3, ptr %t4
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/check:Checker", ptr %t5, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t12 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMembers(ptr %v0, ptr %t8, i32 %a1)
  store { i64, ptr } %t12, ptr %l10
  br label %bb2
bb2:
  %t13 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t13, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t14 = load i64, ptr %l4, !tbaa !24
  %t15 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t20 = icmp slt i64 %t14, %t17
  %t22 = xor i1 %t20, true
  br i1 %t22, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s1)
  br label %bb45
bb5:
  br label %bb6
bb6:
  %t24 = load ptr, ptr %lp2
  %t26 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %v1, ptr %t24)
  store i64 %t26, ptr %l17
  br label %bb7
bb7:
  %t27 = load i64, ptr %l17, !tbaa !24
  %t28 = icmp sgt i64 %t27, 0
  br i1 %t28, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t30 = load ptr, ptr %lp2
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s2, ptr %t30, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d40, i32 0, i32 1) })
  br label %bb10
bb9:
  br label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb11:
  %t32 = load ptr, ptr %lp2
  store ptr %t32, ptr %l20, !tbaa !29
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t34, ptr %l22, !tbaa !27
  %t35 = load i64, ptr %l4, !tbaa !24
  %t37 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !27
  %t39 = getelementptr i32, ptr %t38, i64 %t35
  %t40 = load i32, ptr %t39, !tbaa !33
  %t43 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s1, ptr %t33, i32 %t40)
  store { i64, ptr } %t43, ptr %l25
  br label %bb12
bb12:
  %t44 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t44, 0
  %t46 = extractvalue { i64, ptr } %t44, 1
  %t47 = mul i64 %t45, 1
  %t48 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t47)
  call void @llvm.memcpy.p0.p0.i64(ptr %t48, ptr %t46, i64 %t47, i1 false)
  %t49 = insertvalue { i64, ptr } undef, i64 %t45, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t48, 1
  %t51 = load ptr, ptr %l20, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s1, ptr %t51, { i64, ptr } %t50)
  br label %bb13
bb13:
  %t53 = load i64, ptr %l4, !tbaa !24
  store i64 %t53, ptr %l5, !tbaa !24
  br label %bb14
bb14:
  %t55 = load i64, ptr %l5, !tbaa !24
  %t57 = add i64 %t55, 1
  %t58 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t60 = extractvalue { i64, ptr } %t58, 0
  %t63 = icmp slt i64 %t57, %t60
  br i1 %t63, label %bb15, label %bb16
bb15:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/check:Checker", ptr %t65, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !29
  %t70 = getelementptr %"compiler/generic:Program", ptr %t68, i32 0, i32 2
  %t71 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t71, ptr %l37, !tbaa !27
  %t72 = load i64, ptr %l5, !tbaa !24
  %t74 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t75 = load ptr, ptr %t74, !tbaa !27
  %t76 = getelementptr i32, ptr %t75, i64 %t72
  %t77 = load i32, ptr %t76, !tbaa !33
  %t80 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %t70, i32 %t77)
  store i1 %t80, ptr %l40
  br label %bb17
bb16:
  store i1 false, ptr %l33, !tbaa !21
  br label %bb18
bb17:
  %t81 = load i1, ptr %l40, !tbaa !21
  store i1 %t81, ptr %l33, !tbaa !21
  br label %bb18
bb18:
  %t82 = load i1, ptr %l33, !tbaa !21
  br i1 %t82, label %bb19, label %bb20
bb19:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/check:Checker", ptr %t83, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !29
  %t88 = getelementptr %"compiler/generic:Program", ptr %t86, i32 0, i32 2
  %t89 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t89, ptr %l45, !tbaa !27
  %t90 = load i64, ptr %l5, !tbaa !24
  %t92 = add i64 %t90, 1
  %t94 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !27
  %t96 = getelementptr i32, ptr %t95, i64 %t92
  %t97 = load i32, ptr %t96, !tbaa !33
  %t100 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %t88, i32 %t97)
  store i1 %t100, ptr %l49
  br label %bb21
bb20:
  store i1 false, ptr %l41, !tbaa !21
  br label %bb22
bb21:
  %t101 = load i1, ptr %l49, !tbaa !21
  store i1 %t101, ptr %l41, !tbaa !21
  br label %bb22
bb22:
  %t102 = load i1, ptr %l41, !tbaa !21
  br i1 %t102, label %bb23, label %bb24
bb23:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t105 = getelementptr %"compiler/check:Checker", ptr %t103, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !29
  %t108 = getelementptr %"compiler/generic:Program", ptr %t106, i32 0, i32 2
  %t109 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t109, ptr %l54, !tbaa !27
  %t110 = load i64, ptr %l5, !tbaa !24
  %t112 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !27
  %t114 = getelementptr i32, ptr %t113, i64 %t110
  %t115 = load i32, ptr %t114, !tbaa !33
  %t118 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %t108, i32 %t115)
  store i1 %t118, ptr %l57
  br label %bb25
bb24:
  store i1 false, ptr %l50, !tbaa !21
  br label %bb27
bb25:
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t121 = getelementptr %"compiler/check:Checker", ptr %t119, i32 0, i32 1
  %t122 = load ptr, ptr %t121, !tbaa !29
  %t124 = getelementptr %"compiler/generic:Program", ptr %t122, i32 0, i32 2
  %t125 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t125, ptr %l61, !tbaa !27
  %t126 = load i64, ptr %l5, !tbaa !24
  %t128 = add i64 %t126, 1
  %t130 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !27
  %t132 = getelementptr i32, ptr %t131, i64 %t128
  %t133 = load i32, ptr %t132, !tbaa !33
  %t136 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %t124, i32 %t133)
  store i1 %t136, ptr %l65
  br label %bb26
bb26:
  %t137 = load i1, ptr %l57, !tbaa !21
  %t138 = load i1, ptr %l65, !tbaa !21
  %t139 = icmp eq i1 %t137, %t138
  store i1 %t139, ptr %l50, !tbaa !21
  br label %bb27
bb27:
  %t141 = load i1, ptr %l50, !tbaa !21
  br i1 %t141, label %bb28, label %bb29
bb28:
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t144 = getelementptr %"compiler/check:Checker", ptr %t142, i32 0, i32 1
  %t145 = load ptr, ptr %t144, !tbaa !29
  %t147 = getelementptr %"compiler/generic:Program", ptr %t145, i32 0, i32 2
  %t148 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t148, ptr %l71, !tbaa !27
  %t149 = load i64, ptr %l5, !tbaa !24
  %t151 = add i64 %t149, 1
  %t153 = getelementptr { i64, ptr }, ptr %l71, i32 0, i32 1
  %t154 = load ptr, ptr %t153, !tbaa !27
  %t155 = getelementptr i32, ptr %t154, i64 %t151
  %t156 = load i32, ptr %t155, !tbaa !33
  %t159 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %t147, i32 %t156)
  store i64 %t159, ptr %l75
  br label %bb30
bb29:
  store i1 false, ptr %l67, !tbaa !21
  br label %bb32
bb30:
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t162 = getelementptr %"compiler/check:Checker", ptr %t160, i32 0, i32 1
  %t163 = load ptr, ptr %t162, !tbaa !29
  %t165 = getelementptr %"compiler/generic:Program", ptr %t163, i32 0, i32 2
  %t166 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t166, ptr %l79, !tbaa !27
  %t167 = load i64, ptr %l5, !tbaa !24
  %t169 = getelementptr { i64, ptr }, ptr %l79, i32 0, i32 1
  %t170 = load ptr, ptr %t169, !tbaa !27
  %t171 = getelementptr i32, ptr %t170, i64 %t167
  %t172 = load i32, ptr %t171, !tbaa !33
  %t175 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %t165, i32 %t172)
  store i64 %t175, ptr %l82
  br label %bb31
bb31:
  %t176 = load i64, ptr %l82, !tbaa !24
  %t177 = add i64 %t176, 1
  %t178 = load i64, ptr %l75, !tbaa !24
  %t180 = icmp eq i64 %t178, %t177
  store i1 %t180, ptr %l67, !tbaa !21
  br label %bb32
bb32:
  %t182 = load i1, ptr %l67, !tbaa !21
  %t183 = xor i1 %t182, true
  br i1 %t183, label %bb33, label %bb34
bb33:
  br label %bb37
bb34:
  br label %bb35
bb35:
  %t185 = load i64, ptr %l5, !tbaa !24
  %t187 = add i64 %t185, 1
  store i64 %t187, ptr %l5, !tbaa !24
  br label %bb36
bb36:
  br label %bb14
bb37:
  %t189 = load i64, ptr %l5, !tbaa !24
  %t190 = load i64, ptr %l4, !tbaa !24
  %t192 = add i64 %t190, 1
  %t195 = icmp sgt i64 %t189, %t192
  br i1 %t195, label %bb38, label %bb39
bb38:
  store %olang.scope zeroinitializer, ptr %s4
  %t197 = load ptr, ptr %lp2
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s4, ptr %t197, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d41, i32 0, i32 1) })
  br label %bb40
bb39:
  br label %bb43
bb40:
  %t199 = load ptr, ptr %lp2
  store ptr %t199, ptr %l93, !tbaa !29
  %t200 = load ptr, ptr %l0, !tbaa !29
  %t201 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t201, ptr %l95, !tbaa !27
  %t202 = load i64, ptr %l5, !tbaa !24
  %t204 = getelementptr { i64, ptr }, ptr %l95, i32 0, i32 1
  %t205 = load ptr, ptr %t204, !tbaa !27
  %t206 = getelementptr i32, ptr %t205, i64 %t202
  %t207 = load i32, ptr %t206, !tbaa !33
  %t210 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s4, ptr %t200, i32 %t207)
  store { i64, ptr } %t210, ptr %l98
  br label %bb41
bb41:
  %t211 = load { i64, ptr }, ptr %l98, !tbaa !27
  %t212 = extractvalue { i64, ptr } %t211, 0
  %t213 = extractvalue { i64, ptr } %t211, 1
  %t214 = mul i64 %t212, 1
  %t215 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t214)
  call void @llvm.memcpy.p0.p0.i64(ptr %t215, ptr %t213, i64 %t214, i1 false)
  %t216 = insertvalue { i64, ptr } undef, i64 %t212, 0
  %t217 = insertvalue { i64, ptr } %t216, ptr %t215, 1
  %t218 = load ptr, ptr %l93, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s4, ptr %t218, { i64, ptr } %t217)
  br label %bb42
bb42:
  %t220 = load i64, ptr %l5, !tbaa !24
  store i64 %t220, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  br label %bb43
bb43:
  %t222 = load i64, ptr %l4, !tbaa !24
  %t224 = add i64 %t222, 1
  store i64 %t224, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb44
bb44:
  br label %bb3
bb45:
  %t226 = load ptr, ptr %lp2
  %t227 = load %"std/prelude/text:StringBuilder", ptr %t226
  store %"std/prelude/text:StringBuilder" %t227, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/text:StringBuilder", ptr %rv
  ret %"std/prelude/text:StringBuilder" %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrowCopy(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i64
  %l8 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca i1
  %l19 = alloca ptr
  %l22 = alloca i64
  %l24 = alloca i64
  %l29 = alloca i64
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v1, ptr %a1)
  store ptr %t3, ptr %l8
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l8, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t7 = icmp eq ptr %t5, null
  br i1 %t7, label %bb2, label %bb3
bb2:
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t10 = load ptr, ptr %l2, !tbaa !29
  store ptr %t10, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t11 = load ptr, ptr %l12, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb5, label %bb6
bb5:
  %t14 = load ptr, ptr %l12, !tbaa !29
  %t15 = load i64, ptr %t14
  %t17 = icmp eq i64 %t15, 0
  store i1 %t17, ptr %l13, !tbaa !21
  br label %bb6
bb6:
  %t18 = load i1, ptr %l13, !tbaa !21
  br i1 %t18, label %bb7, label %bb8
bb7:
  %t19 = load ptr, ptr %l2, !tbaa !29
  %t21 = getelementptr { i64, [4 x i64] }, ptr %t19, i32 0, i32 1
  %t22 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t21, i32 0, i32 2
  %t23 = load i32, ptr %t22
  store i32 %t23, ptr %l3, !tbaa !23
  br label %bb9
bb8:
  br label %bb22
bb9:
  %t27 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %a0)
  store ptr %t27, ptr %l19
  br label %bb10
bb10:
  %t28 = load ptr, ptr %l19, !tbaa !29
  %t30 = getelementptr %"compiler/check:frame", ptr %t28, i32 0, i32 44
  store ptr %t30, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb11
bb11:
  %t32 = load i64, ptr %l5, !tbaa !24
  store i64 %t32, ptr %l22, !tbaa !24
  %t33 = load ptr, ptr %l4, !tbaa !29
  %t35 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t33)
  store i64 %t35, ptr %l24
  br label %bb12
bb12:
  %t36 = load i64, ptr %l22, !tbaa !24
  %t37 = load i64, ptr %l24, !tbaa !24
  %t38 = icmp slt i64 %t36, %t37
  %t40 = xor i1 %t38, true
  br i1 %t40, label %bb13, label %bb14
bb13:
  br label %bb21
bb14:
  br label %bb15
bb15:
  %t42 = load ptr, ptr %l4, !tbaa !29
  %t43 = load i64, ptr %l5, !tbaa !24
  %t46 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t42, i64 %t43)
  store i64 %t46, ptr %l29
  br label %bb16
bb16:
  %t47 = load i64, ptr %l29, !tbaa !24
  %t49 = load i32, ptr %l3, !tbaa !23
  %t51 = sext i32 %t49 to i64
  %t54 = icmp eq i64 %t47, %t51
  br i1 %t54, label %bb17, label %bb18
bb17:
  store i1 true, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  br label %bb20
bb20:
  %t57 = load i64, ptr %l5, !tbaa !24
  %t59 = add i64 %t57, 1
  store i64 %t59, ptr %l5, !tbaa !24
  br label %bb11
bb21:
  br label %bb23
bb22:
  br label %bb23
bb23:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparam(ptr %v0, ptr %v1, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, i32 %a3, i64 %a4, ptr %a5) #0 {
entry:
  %l0 = alloca ptr
  %l5 = alloca ptr
  %l7 = alloca i64
  %l9 = alloca ptr
  %l14 = alloca { i64, [2 x i64] }
  %l21 = alloca i64
  %l23 = alloca ptr
  %l33 = alloca ptr
  %l35 = alloca ptr
  %l36 = alloca i64
  %l39 = alloca { i64, [3 x i64] }
  store ptr %a0, ptr %l0
  store ptr %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t1)
  store ptr %t3, ptr %l9
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/check:Checker", ptr %t4, i32 0, i32 1
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/generic:Program", ptr %t7, i32 0, i32 2
  %t11 = load ptr, ptr %l9, !tbaa !29
  %t14 = call { i64, [2 x i64] } @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eParamMark(ptr %v0, ptr %v0, ptr %t11, ptr %t9, i64 %a4)
  store { i64, [2 x i64] } %t14, ptr %l14
  br label %bb2
bb2:
  %t15 = load { i64, [2 x i64] }, ptr %l14
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t27 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %t16, i32 %a1, %"compiler/source:Span" %a2, i32 %a3, i32 0, { i64, [2 x i64] } %t15)
  store i64 %t27, ptr %l21
  br label %bb3
bb3:
  %t28 = load i64, ptr %l21, !tbaa !24
  store i64 %t28, ptr %l7, !tbaa !24
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t29)
  store ptr %t31, ptr %l23
  br label %bb4
bb4:
  %t32 = load ptr, ptr %l23, !tbaa !29
  %t34 = getelementptr %"compiler/typed:Body", ptr %t32, i32 0, i32 5
  %t35 = load i64, ptr %l7, !tbaa !24
  %t37 = trunc i64 %t35 to i32
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2ePush_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t34, i32 %t37)
  br label %bb5
bb5:
  %t41 = load ptr, ptr %l5, !tbaa !29
  %t43 = icmp eq ptr %t41, null
  %t45 = xor i1 %t43, true
  br i1 %t45, label %bb6, label %bb7
bb6:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t47)
  store ptr %t49, ptr %l33
  br label %bb8
bb7:
  br label %bb11
bb8:
  %t50 = load ptr, ptr %l33, !tbaa !29
  %t52 = getelementptr %"compiler/check:frame", ptr %t50, i32 0, i32 3
  store ptr %t52, ptr %l35, !tbaa !29
  %t53 = load i64, ptr %l7, !tbaa !24
  store i64 %t53, ptr %l36, !tbaa !24
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load ptr, ptr %l5, !tbaa !29
  %t58 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeWrittenAt(ptr %v0, ptr %v1, ptr %t54, ptr %t55)
  store { i64, [3 x i64] } %t58, ptr %l39
  br label %bb9
bb9:
  %t59 = load ptr, ptr %l35, !tbaa !29
  %t60 = load i64, ptr %l36, !tbaa !24
  %t61 = load { i64, [3 x i64] }, ptr %l39
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fdiag_3aWhere_3e_2e_Hc07a7e56a24d8f1225398db99ea19a4b(ptr %v0, ptr %t59, i64 %t60, { i64, [3 x i64] } %t61)
  br label %bb10
bb10:
  br label %bb11
bb11:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparamIndex(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"compiler/typed:Local"
  %l3 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l11 = alloca ptr
  %l15 = alloca %"compiler/typed:Local"
  %l19 = alloca i1
  %l22 = alloca i1
  %l23 = alloca i1
  %l26 = alloca i1
  %l30 = alloca ptr
  %l34 = alloca i64
  %l38 = alloca i64
  %l41 = alloca i64
  %l61 = alloca i32
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t1)
  store ptr %t3, ptr %l11
  br label %bb1
bb1:
  %t4 = load i64, ptr %l1, !tbaa !24
  %t6 = trunc i64 %t4 to i32
  %t8 = load ptr, ptr %l11, !tbaa !29
  %t10 = call %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %t8, i32 %t6)
  store %"compiler/typed:Local" %t10, ptr %l15
  br label %bb2
bb2:
  %t11 = load %"compiler/typed:Local", ptr %l15
  store %"compiler/typed:Local" %t11, ptr %l2
  %t12 = getelementptr %"compiler/typed:Local", ptr %l2, i32 0, i32 4
  %t13 = load i32, ptr %t12
  %t15 = trunc i64 0 to i32
  %t16 = icmp eq i32 %t13, %t15
  %t18 = xor i1 %t16, true
  br i1 %t18, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb6
bb4:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/typed:Local", ptr %l2, i32 0, i32 2
  %t22 = load i32, ptr %t21, !tbaa !23
  %t25 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t20, i32 %t22)
  store i1 %t25, ptr %l22
  br label %bb5
bb5:
  %t26 = load i1, ptr %l22, !tbaa !21
  store i1 %t26, ptr %l19, !tbaa !21
  br label %bb6
bb6:
  %t27 = load i1, ptr %l19, !tbaa !21
  br i1 %t27, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb10
bb8:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/typed:Local", ptr %l2, i32 0, i32 2
  %t30 = load i32, ptr %t29, !tbaa !23
  %t33 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsWritable(ptr %v0, ptr %t28, i32 %t30)
  store i1 %t33, ptr %l26
  br label %bb9
bb9:
  %t34 = load i1, ptr %l26, !tbaa !21
  %t35 = xor i1 %t34, true
  store i1 %t35, ptr %l23, !tbaa !21
  br label %bb10
bb10:
  %t37 = load i1, ptr %l23, !tbaa !21
  br i1 %t37, label %bb11, label %bb12
bb11:
  store i64 -1, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t39)
  store ptr %t41, ptr %l30
  br label %bb14
bb14:
  %t42 = load ptr, ptr %l30, !tbaa !29
  %t44 = getelementptr %"compiler/typed:Body", ptr %t42, i32 0, i32 5
  %t45 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t44
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t45, ptr %l3
  store i64 0, ptr %l4, !tbaa !24
  %t48 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %l3)
  store i64 %t48, ptr %l34
  br label %bb15
bb15:
  %t49 = load i64, ptr %l34, !tbaa !24
  store i64 %t49, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t50 = load i64, ptr %l5, !tbaa !24
  %t51 = load i64, ptr %l4, !tbaa !24
  %t54 = icmp sgt i64 %t50, %t51
  br i1 %t54, label %bb16, label %bb17
bb16:
  %t56 = load i64, ptr %l6, !tbaa !24
  %t58 = icmp sgt i64 %t56, 0
  br i1 %t58, label %bb18, label %bb19
bb17:
  store i64 0, ptr %l38, !tbaa !24
  br label %bb21
bb18:
  %t60 = load i64, ptr %l5, !tbaa !24
  %t61 = load i64, ptr %l4, !tbaa !24
  %t64 = sub i64 %t60, %t61
  %t65 = load i64, ptr %l6, !tbaa !24
  %t68 = add i64 %t64, %t65
  %t70 = sub i64 %t68, 1
  %t71 = load i64, ptr %l6, !tbaa !24
  %t74 = sdiv i64 %t70, %t71
  store i64 %t74, ptr %l41, !tbaa !24
  br label %bb20
bb19:
  store i64 0, ptr %l41, !tbaa !24
  br label %bb20
bb20:
  %t76 = load i64, ptr %l41, !tbaa !24
  store i64 %t76, ptr %l38, !tbaa !24
  br label %bb21
bb21:
  %t77 = load i64, ptr %l38, !tbaa !24
  store i64 %t77, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb22
bb22:
  %t78 = load i64, ptr %l8, !tbaa !24
  %t79 = load i64, ptr %l7, !tbaa !24
  %t82 = icmp slt i64 %t78, %t79
  %t84 = xor i1 %t82, true
  br i1 %t84, label %bb23, label %bb24
bb23:
  br label %bb31
bb24:
  br label %bb25
bb25:
  %t86 = load i64, ptr %l4, !tbaa !24
  %t87 = load i64, ptr %l8, !tbaa !24
  %t88 = load i64, ptr %l6, !tbaa !24
  %t91 = mul i64 %t87, %t88
  %t94 = add i64 %t86, %t91
  store i64 %t94, ptr %l9, !tbaa !24
  %t96 = load i64, ptr %l9, !tbaa !24
  %t99 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %l3, i64 %t96)
  store i32 %t99, ptr %l61
  br label %bb26
bb26:
  %t100 = load i32, ptr %l61, !tbaa !23
  %t101 = sext i32 %t100 to i64
  %t102 = load i64, ptr %l1, !tbaa !24
  %t105 = icmp eq i64 %t101, %t102
  br i1 %t105, label %bb27, label %bb28
bb27:
  %t107 = load i64, ptr %l9, !tbaa !24
  store i64 %t107, ptr %rv
  br label %ret
bb28:
  br label %bb29
bb29:
  br label %bb30
bb30:
  %t109 = load i64, ptr %l8, !tbaa !24
  %t111 = add i64 %t109, 1
  store i64 %t111, ptr %l8, !tbaa !24
  br label %bb22
bb31:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epathPart(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l15 = alloca { i64, ptr }
  %l23 = alloca i64
  %l26 = alloca i64
  %l47 = alloca i1
  %l48 = alloca { i64, ptr }
  %l69 = alloca %"compiler/source:Span"
  %s4 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t4 = getelementptr %"compiler/ast:Path", ptr %t2, i32 0, i32 0
  %t5 = load %"compiler/source:Span", ptr %t4
  %t8 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %a0, %"compiler/source:Span" %t5)
  store { i64, ptr } %t8, ptr %l15
  br label %bb1
bb1:
  %t9 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t9, ptr %l3, !tbaa !27
  %t10 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  %t14 = load i64, ptr %l2, !tbaa !24
  %t16 = add i64 %t14, 1
  store i64 %t16, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t18 = load i64, ptr %l6, !tbaa !24
  %t19 = load i64, ptr %l5, !tbaa !24
  %t22 = icmp sgt i64 %t18, %t19
  br i1 %t22, label %bb2, label %bb3
bb2:
  %t24 = load i64, ptr %l7, !tbaa !24
  %t26 = icmp sgt i64 %t24, 0
  br i1 %t26, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb7
bb4:
  %t28 = load i64, ptr %l6, !tbaa !24
  %t29 = load i64, ptr %l5, !tbaa !24
  %t32 = sub i64 %t28, %t29
  %t33 = load i64, ptr %l7, !tbaa !24
  %t36 = add i64 %t32, %t33
  %t38 = sub i64 %t36, 1
  %t39 = load i64, ptr %l7, !tbaa !24
  %t42 = sdiv i64 %t38, %t39
  store i64 %t42, ptr %l26, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l26, !tbaa !24
  br label %bb6
bb6:
  %t44 = load i64, ptr %l26, !tbaa !24
  store i64 %t44, ptr %l23, !tbaa !24
  br label %bb7
bb7:
  %t45 = load i64, ptr %l23, !tbaa !24
  store i64 %t45, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb8
bb8:
  %t46 = load i64, ptr %l9, !tbaa !24
  %t47 = load i64, ptr %l8, !tbaa !24
  %t50 = icmp slt i64 %t46, %t47
  %t52 = xor i1 %t50, true
  br i1 %t52, label %bb9, label %bb10
bb9:
  br label %bb29
bb10:
  br label %bb11
bb11:
  %t54 = load i64, ptr %l5, !tbaa !24
  %t55 = load i64, ptr %l9, !tbaa !24
  %t56 = load i64, ptr %l7, !tbaa !24
  %t59 = mul i64 %t55, %t56
  %t62 = add i64 %t54, %t59
  store i64 %t62, ptr %l10, !tbaa !24
  %t64 = load i64, ptr %l4, !tbaa !24
  store i64 %t64, ptr %l11, !tbaa !24
  br label %bb12
bb12:
  %t66 = load i64, ptr %l11, !tbaa !24
  %t68 = icmp sgt i64 %t66, 0
  br i1 %t68, label %bb13, label %bb14
bb13:
  %t70 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t70, ptr %l48, !tbaa !27
  %t71 = load i64, ptr %l11, !tbaa !24
  %t73 = sub i64 %t71, 1
  %t75 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = getelementptr i8, ptr %t76, i64 %t73
  %t78 = load i8, ptr %t77, !tbaa !32
  %t80 = icmp ne i8 %t78, 46
  store i1 %t80, ptr %l47, !tbaa !21
  br label %bb15
bb14:
  store i1 false, ptr %l47, !tbaa !21
  br label %bb15
bb15:
  %t82 = load i1, ptr %l47, !tbaa !21
  %t83 = xor i1 %t82, true
  br i1 %t83, label %bb16, label %bb17
bb16:
  br label %bb20
bb17:
  br label %bb18
bb18:
  %t85 = load i64, ptr %l11, !tbaa !24
  %t87 = sub i64 %t85, 1
  store i64 %t87, ptr %l11, !tbaa !24
  br label %bb19
bb19:
  br label %bb12
bb20:
  %t89 = load i64, ptr %l10, !tbaa !24
  %t90 = load i64, ptr %l2, !tbaa !24
  %t93 = icmp eq i64 %t89, %t90
  br i1 %t93, label %bb21, label %bb22
bb21:
  store %olang.scope zeroinitializer, ptr %s4
  %t95 = load ptr, ptr %l1, !tbaa !29
  %t97 = getelementptr %"compiler/ast:Path", ptr %t95, i32 0, i32 0
  %t98 = getelementptr %"compiler/source:Span", ptr %t97, i32 0, i32 0
  %t99 = load i32, ptr %t98, !tbaa !23
  %t100 = load i64, ptr %l11, !tbaa !24
  %t102 = trunc i64 %t100 to i32
  %t105 = add i32 %t99, %t102
  %t106 = load ptr, ptr %l1, !tbaa !29
  %t108 = getelementptr %"compiler/ast:Path", ptr %t106, i32 0, i32 0
  %t109 = getelementptr %"compiler/source:Span", ptr %t108, i32 0, i32 0
  %t110 = load i32, ptr %t109, !tbaa !23
  %t111 = load i64, ptr %l4, !tbaa !24
  %t113 = trunc i64 %t111 to i32
  %t116 = add i32 %t110, %t113
  %t119 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s4, i32 %t105, i32 %t116)
  store %"compiler/source:Span" %t119, ptr %l69
  br label %bb23
bb22:
  br label %bb24
bb23:
  call void @__olang_scope_close(ptr %s4)
  %t120 = load %"compiler/source:Span", ptr %l69
  store %"compiler/source:Span" %t120, ptr %rv
  br label %ret
bb24:
  %t121 = load i64, ptr %l11, !tbaa !24
  %t123 = sub i64 %t121, 1
  store i64 %t123, ptr %l4, !tbaa !24
  %t125 = load i64, ptr %l4, !tbaa !24
  %t127 = icmp slt i64 %t125, 0
  br i1 %t127, label %bb25, label %bb26
bb25:
  %t129 = load ptr, ptr %l1, !tbaa !29
  %t131 = getelementptr %"compiler/ast:Path", ptr %t129, i32 0, i32 0
  %t132 = load %"compiler/source:Span", ptr %t131
  store %"compiler/source:Span" %t132, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  br label %bb28
bb28:
  %t134 = load i64, ptr %l9, !tbaa !24
  %t136 = add i64 %t134, 1
  store i64 %t136, ptr %l9, !tbaa !24
  br label %bb8
bb29:
  %t138 = load ptr, ptr %l1, !tbaa !29
  %t140 = getelementptr %"compiler/ast:Path", ptr %t138, i32 0, i32 0
  %t141 = load %"compiler/source:Span", ptr %t140
  store %"compiler/source:Span" %t141, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplainScalar(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i1
  %l5 = alloca i1
  %l8 = alloca i32
  %l14 = alloca i1
  %l15 = alloca i1
  %l18 = alloca ptr
  %l23 = alloca i32
  %l24 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i1, ptr %l4, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l5, !tbaa !21
  br label %bb5
bb3:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l1, !tbaa !23
  %t11 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t7, i32 %t8)
  store i32 %t11, ptr %l8
  br label %bb4
bb4:
  %t12 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t13 = load i32, ptr %l8, !tbaa !23
  %t15 = icmp eq i32 %t13, %t12
  store i1 %t15, ptr %l5, !tbaa !21
  br label %bb5
bb5:
  %t17 = load i1, ptr %l5, !tbaa !21
  br i1 %t17, label %bb6, label %bb7
bb6:
  store i1 true, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t20 = load i32, ptr %l1, !tbaa !23
  %t23 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %t19, i32 %t20)
  store i1 %t23, ptr %l14
  br label %bb9
bb9:
  %t24 = load i1, ptr %l14, !tbaa !21
  br i1 %t24, label %bb10, label %bb11
bb10:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/check:Checker", ptr %t25, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !29
  %t30 = getelementptr %"compiler/generic:Program", ptr %t28, i32 0, i32 2
  store ptr %t30, ptr %l18, !tbaa !29
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/check:Checker", ptr %t31, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t36 = getelementptr %"compiler/generic:Program", ptr %t34, i32 0, i32 2
  %t37 = load i32, ptr %l1, !tbaa !23
  %t40 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t36, i32 %t37)
  store i32 %t40, ptr %l23
  br label %bb12
bb11:
  store i1 false, ptr %l15, !tbaa !21
  br label %bb14
bb12:
  %t41 = load ptr, ptr %l18, !tbaa !29
  %t42 = load i32, ptr %l23, !tbaa !23
  %t43 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasPayload(ptr %v0, ptr %t41, i32 %t42)
  store i1 %t43, ptr %l24
  br label %bb13
bb13:
  %t44 = load i1, ptr %l24, !tbaa !21
  %t45 = xor i1 %t44, true
  store i1 %t45, ptr %l15, !tbaa !21
  br label %bb14
bb14:
  %t47 = load i1, ptr %l15, !tbaa !21
  store i1 %t47, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/check:reflVal" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflFold(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca %"compiler/check:litv"
  %l5 = alloca ptr
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca ptr
  %lp11 = alloca ptr
  %l12 = alloca i32
  %l13 = alloca ptr
  %l14 = alloca ptr
  %lp15 = alloca ptr
  %lp16 = alloca ptr
  %l17 = alloca i1
  %l18 = alloca ptr
  %l19 = alloca { i64, ptr }
  %l20 = alloca ptr
  %l21 = alloca i32
  %l22 = alloca %"compiler/check:reflList"
  %l23 = alloca { { i64, ptr }, { i64, ptr } }
  %l24 = alloca { i64, ptr }
  %l26 = alloca ptr
  %l27 = alloca i32
  %l28 = alloca i32
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca ptr
  %l37 = alloca i1
  %l48 = alloca { i64, ptr }
  %l49 = alloca i1
  %l50 = alloca %"compiler/check:reflVal"
  %l55 = alloca { i64, ptr }
  %l57 = alloca %"compiler/check:reflVal"
  %l61 = alloca %"compiler/check:litv"
  %l63 = alloca i1
  %l66 = alloca i1
  %l70 = alloca %"compiler/check:reflVal"
  %l71 = alloca %"compiler/check:reflVal"
  %l72 = alloca ptr
  %l73 = alloca i1
  %l80 = alloca %"compiler/check:reflVal"
  %l81 = alloca ptr
  %l82 = alloca i1
  %l91 = alloca ptr
  %l93 = alloca ptr
  %l97 = alloca %"compiler/names:Ref"
  %l100 = alloca i1
  %l103 = alloca i64
  %l105 = alloca i32
  %l107 = alloca ptr
  %l111 = alloca i32
  %l112 = alloca i32
  %l115 = alloca i1
  %l120 = alloca i32
  %l128 = alloca i64
  %l129 = alloca %"compiler/check:reflVal"
  %l130 = alloca %"compiler/check:reflVal"
  %l131 = alloca ptr
  %l132 = alloca i1
  %l141 = alloca %"compiler/check:reflVal"
  %l147 = alloca i1
  %l153 = alloca %"compiler/check:reflVal"
  %l156 = alloca i1
  %l162 = alloca %"compiler/check:reflVal"
  %l163 = alloca %"compiler/check:reflVal"
  %l164 = alloca ptr
  %l165 = alloca i1
  %l176 = alloca %"compiler/check:reflVal"
  %l179 = alloca i1
  %l181 = alloca i1
  %l185 = alloca i1
  %l191 = alloca i1
  %l193 = alloca i1
  %l197 = alloca i1
  %l203 = alloca %"compiler/check:reflVal"
  %l206 = alloca i1
  %l209 = alloca i1
  %l213 = alloca %"compiler/check:reflVal"
  %l216 = alloca i1
  %l222 = alloca %"compiler/check:reflVal"
  %l224 = alloca %"compiler/check:reflVal"
  %l227 = alloca i1
  %l238 = alloca i1
  %l243 = alloca i1
  %l251 = alloca %"compiler/check:reflVal"
  %l255 = alloca %"compiler/check:reflVal"
  %l256 = alloca %"compiler/check:reflVal"
  %l262 = alloca %"compiler/check:reflVal"
  %l268 = alloca %"compiler/check:reflVal"
  %l274 = alloca %"compiler/check:reflVal"
  %l280 = alloca %"compiler/check:reflVal"
  %l286 = alloca %"compiler/check:reflVal"
  %l292 = alloca %"compiler/check:reflVal"
  %l298 = alloca %"compiler/check:reflVal"
  %l299 = alloca %"compiler/check:reflVal"
  %l300 = alloca ptr
  %l301 = alloca i1
  %l308 = alloca ptr
  %l309 = alloca i1
  %l318 = alloca { i64, ptr }
  %l319 = alloca i1
  %l320 = alloca i1
  %l326 = alloca %"compiler/check:reflList"
  %l332 = alloca %"compiler/check:reflVal"
  %l334 = alloca ptr
  %l335 = alloca i32
  %l336 = alloca i64
  %l337 = alloca i64
  %l339 = alloca ptr
  %l342 = alloca { { i64, ptr }, { i64, ptr } }
  %l343 = alloca { i64, ptr }
  %l344 = alloca i64
  %l345 = alloca { i64, ptr }
  %l346 = alloca { i64, ptr }
  %l347 = alloca i64
  %l348 = alloca { i64, ptr }
  %l350 = alloca i1
  %l351 = alloca %"compiler/check:reflVal"
  %l354 = alloca %"compiler/check:reflVal"
  %l355 = alloca %"compiler/check:reflVal"
  %l356 = alloca %"compiler/check:reflVal"
  %l357 = alloca ptr
  %l358 = alloca i1
  %l367 = alloca i32
  %l370 = alloca i1
  %l373 = alloca i1
  %l374 = alloca i1
  %l378 = alloca i1
  %l379 = alloca i1
  %l382 = alloca i1
  %l388 = alloca { i64, ptr }
  %l394 = alloca i64
  %l397 = alloca i64
  %l415 = alloca { i64, ptr }
  %l423 = alloca %"compiler/check:reflVal"
  %l429 = alloca %"compiler/check:reflVal"
  %l430 = alloca %"compiler/check:reflVal"
  %s2 = alloca %olang.scope
  %s31 = alloca %olang.scope
  %s33 = alloca %olang.scope
  %rv = alloca %"compiler/check:reflVal"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l36, !tbaa !29
  store i1 false, ptr %l37, !tbaa !21
  %t2 = load ptr, ptr %l36, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l36, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l37, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l37, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l2
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32 }, ptr %t18, i32 0, i32 1
  %t20 = load i32, ptr %t19
  store i32 %t20, ptr %l3
  br label %bb5
bb4:
  br label %bb29
bb5:
  %t22 = load i32, ptr %l3
  %t24 = trunc i64 6 to i32
  %t25 = icmp eq i32 %t22, %t24
  br i1 %t25, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s2
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load %"compiler/source:Span", ptr %l2
  %t31 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %t27, %"compiler/source:Span" %t28)
  store { i64, ptr } %t31, ptr %l48
  br label %bb8
bb7:
  br label %bb11
bb8:
  %t32 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t33 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t32, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d42, i32 0, i32 1) })
  store i1 %t33, ptr %l49
  br label %bb9
bb9:
  %t34 = load i1, ptr %l49, !tbaa !21
  %t35 = call %"compiler/check:reflVal" @compiler_2fcheck_2ervBool(ptr %v2, i1 %t34)
  store %"compiler/check:reflVal" %t35, ptr %l50
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s2)
  %t36 = load %"compiler/check:reflVal", ptr %l50
  store %"compiler/check:reflVal" %t36, ptr %rv
  br label %ret
bb11:
  %t37 = load i32, ptr %l3
  %t39 = trunc i64 5 to i32
  %t40 = icmp eq i32 %t37, %t39
  br i1 %t40, label %bb12, label %bb13
bb12:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load %"compiler/source:Span", ptr %l2
  %t46 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estrBytes(ptr %v0, ptr %t42, %"compiler/source:Span" %t43)
  store { i64, ptr } %t46, ptr %l55
  br label %bb14
bb13:
  br label %bb16
bb14:
  %t47 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t49 = call %"compiler/check:reflVal" @compiler_2fcheck_2ervText(ptr %v0, ptr %v2, { i64, ptr } %t47)
  store %"compiler/check:reflVal" %t49, ptr %l57
  br label %bb15
bb15:
  %t50 = load %"compiler/check:reflVal", ptr %l57
  store %"compiler/check:reflVal" %t50, ptr %rv
  br label %ret
bb16:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t52 = load ptr, ptr %l1, !tbaa !29
  %t56 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %t51, ptr %t52)
  store %"compiler/check:litv" %t56, ptr %l61
  br label %bb17
bb17:
  %t57 = load %"compiler/check:litv", ptr %l61
  store %"compiler/check:litv" %t57, ptr %l4
  %t58 = getelementptr %"compiler/check:litv", ptr %l4, i32 0, i32 0
  %t59 = load i1, ptr %t58, !tbaa !21
  br i1 %t59, label %bb18, label %bb19
bb18:
  %t61 = getelementptr %"compiler/check:litv", ptr %l4, i32 0, i32 1
  %t62 = load i1, ptr %t61, !tbaa !21
  %t64 = xor i1 %t62, true
  store i1 %t64, ptr %l63, !tbaa !21
  br label %bb20
bb19:
  store i1 false, ptr %l63, !tbaa !21
  br label %bb20
bb20:
  %t66 = load i1, ptr %l63, !tbaa !21
  br i1 %t66, label %bb21, label %bb22
bb21:
  %t67 = getelementptr %"compiler/check:litv", ptr %l4, i32 0, i32 2
  %t68 = load i1, ptr %t67, !tbaa !21
  %t70 = xor i1 %t68, true
  store i1 %t70, ptr %l66, !tbaa !21
  br label %bb23
bb22:
  store i1 false, ptr %l66, !tbaa !21
  br label %bb23
bb23:
  %t72 = load i1, ptr %l66, !tbaa !21
  br i1 %t72, label %bb24, label %bb25
bb24:
  %t73 = getelementptr %"compiler/check:litv", ptr %l4, i32 0, i32 3
  %t74 = load i64, ptr %t73, !tbaa !24
  %t76 = call %"compiler/check:reflVal" @compiler_2fcheck_2ervInt(ptr %v2, i64 %t74)
  store %"compiler/check:reflVal" %t76, ptr %l70
  br label %bb26
bb25:
  br label %bb27
bb26:
  %t77 = load %"compiler/check:reflVal", ptr %l70
  store %"compiler/check:reflVal" %t77, ptr %rv
  br label %ret
bb27:
  %t78 = call %"compiler/check:reflVal" @compiler_2fcheck_2enoRefl(ptr %v2)
  store %"compiler/check:reflVal" %t78, ptr %l71
  br label %bb28
bb28:
  %t79 = load %"compiler/check:reflVal", ptr %l71
  store %"compiler/check:reflVal" %t79, ptr %rv
  br label %ret
bb29:
  %t80 = load ptr, ptr %l1, !tbaa !29
  store ptr %t80, ptr %l72, !tbaa !29
  store i1 false, ptr %l73, !tbaa !21
  %t81 = load ptr, ptr %l72, !tbaa !29
  %t82 = icmp ne ptr %t81, null
  br i1 %t82, label %bb30, label %bb31
bb30:
  %t84 = load ptr, ptr %l72, !tbaa !29
  %t85 = load i64, ptr %t84
  %t87 = icmp eq i64 %t85, 2
  store i1 %t87, ptr %l73, !tbaa !21
  br label %bb31
bb31:
  %t88 = load i1, ptr %l73, !tbaa !21
  br i1 %t88, label %bb32, label %bb33
bb32:
  %t89 = load ptr, ptr %l1, !tbaa !29
  %t91 = getelementptr { i64, [5 x i64] }, ptr %t89, i32 0, i32 1
  %t92 = getelementptr { %"compiler/source:Span", ptr }, ptr %t91, i32 0, i32 1
  %t93 = load ptr, ptr %t92
  store ptr %t93, ptr %l5, !tbaa !29
  br label %bb34
bb33:
  br label %bb36
bb34:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t96 = load ptr, ptr %l5, !tbaa !29
  %t99 = call %"compiler/check:reflVal" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflFold(ptr %v0, ptr %v1, ptr %v2, ptr %t95, ptr %t96)
  store %"compiler/check:reflVal" %t99, ptr %l80
  br label %bb35
bb35:
  %t100 = load %"compiler/check:reflVal", ptr %l80
  store %"compiler/check:reflVal" %t100, ptr %rv
  br label %ret
bb36:
  %t101 = load ptr, ptr %l1, !tbaa !29
  store ptr %t101, ptr %l81, !tbaa !29
  store i1 false, ptr %l82, !tbaa !21
  %t102 = load ptr, ptr %l81, !tbaa !29
  %t103 = icmp ne ptr %t102, null
  br i1 %t103, label %bb37, label %bb38
bb37:
  %t105 = load ptr, ptr %l81, !tbaa !29
  %t106 = load i64, ptr %t105
  %t108 = icmp eq i64 %t106, 0
  store i1 %t108, ptr %l82, !tbaa !21
  br label %bb38
bb38:
  %t109 = load i1, ptr %l82, !tbaa !21
  br i1 %t109, label %bb39, label %bb40
bb39:
  %t110 = load ptr, ptr %l1, !tbaa !29
  %t112 = getelementptr { i64, [5 x i64] }, ptr %t110, i32 0, i32 1
  %t113 = getelementptr { %"compiler/source:Span", i32 }, ptr %t112, i32 0, i32 0
  %t114 = load %"compiler/source:Span", ptr %t113
  store %"compiler/source:Span" %t114, ptr %l6
  %t116 = load ptr, ptr %l1, !tbaa !29
  %t118 = getelementptr { i64, [5 x i64] }, ptr %t116, i32 0, i32 1
  %t119 = getelementptr { %"compiler/source:Span", i32 }, ptr %t118, i32 0, i32 1
  %t120 = load i32, ptr %t119
  store i32 %t120, ptr %l7, !tbaa !23
  br label %bb41
bb40:
  br label %bb66
bb41:
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t124 = getelementptr %"compiler/check:Checker", ptr %t122, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !29
  %t127 = getelementptr %"compiler/generic:Program", ptr %t125, i32 0, i32 1
  %t128 = load ptr, ptr %t127, !tbaa !29
  store ptr %t128, ptr %l91, !tbaa !29
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t131 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t129)
  store ptr %t131, ptr %l93
  br label %bb42
bb42:
  %t132 = load ptr, ptr %l93, !tbaa !29
  %t134 = getelementptr %"compiler/check:frame", ptr %t132, i32 0, i32 2
  %t135 = load i64, ptr %t134, !tbaa !24
  %t136 = getelementptr %"compiler/source:Span", ptr %l6, i32 0, i32 0
  %t137 = load i32, ptr %t136, !tbaa !23
  %t138 = load ptr, ptr %l91, !tbaa !29
  %t141 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t138, i64 %t135, i32 %t137)
  store %"compiler/names:Ref" %t141, ptr %l97
  br label %bb43
bb43:
  %t142 = getelementptr %"compiler/names:Ref", ptr %l97, i32 0, i32 0
  %t143 = load i32, ptr %t142
  %t145 = trunc i64 1 to i32
  %t146 = icmp eq i32 %t143, %t145
  br i1 %t146, label %bb44, label %bb45
bb44:
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t149 = load i32, ptr %l7, !tbaa !23
  %t152 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalNamed(ptr %v0, ptr %t148, i32 %t149)
  store i64 %t152, ptr %l103
  br label %bb46
bb45:
  store i1 false, ptr %l100, !tbaa !21
  br label %bb47
bb46:
  %t153 = load i64, ptr %l103, !tbaa !24
  %t154 = icmp slt i64 %t153, 0
  store i1 %t154, ptr %l100, !tbaa !21
  br label %bb47
bb47:
  %t156 = load i1, ptr %l100, !tbaa !21
  br i1 %t156, label %bb48, label %bb49
bb48:
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t159 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t157)
  store ptr %t159, ptr %l107
  br label %bb50
bb49:
  br label %bb64
bb50:
  %t160 = load ptr, ptr %l107, !tbaa !29
  %t162 = getelementptr %"compiler/check:frame", ptr %t160, i32 0, i32 4
  %t163 = getelementptr %"compiler/generic:Context", ptr %t162, i32 0, i32 3
  %t164 = load i32, ptr %l7, !tbaa !23
  %t167 = call { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_Hfd0413fe7fd4e5914f6cad5b418b7a6d(ptr %v0, ptr %t163, i32 %t164)
  %t168 = extractvalue { i32, i32 } %t167, 1
  %t169 = extractvalue { i32, i32 } %t167, 0
  store i32 %t169, ptr %l112
  %t170 = icmp ne i32 %t169, 0
  br i1 %t170, label %bb52, label %ok.171
ok.171:
  store i32 %t168, ptr %l111
  br label %bb51
bb51:
  %t172 = load i32, ptr %l111, !tbaa !23
  store i32 %t172, ptr %l105, !tbaa !23
  br label %bb54
bb52:
  br label %bb53
bb53:
  call void @__olang_ert_req_clear()
  store i32 -1, ptr %l105, !tbaa !23
  br label %bb54
bb54:
  %t173 = load i32, ptr %l105, !tbaa !23
  store i32 %t173, ptr %l8, !tbaa !23
  %t174 = load i32, ptr %l8, !tbaa !23
  %t176 = icmp sge i32 %t174, 0
  br i1 %t176, label %bb55, label %bb56
bb55:
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t180 = getelementptr %"compiler/check:Checker", ptr %t178, i32 0, i32 1
  %t181 = load ptr, ptr %t180, !tbaa !29
  %t183 = getelementptr %"compiler/generic:Program", ptr %t181, i32 0, i32 2
  %t184 = load i32, ptr %l8, !tbaa !23
  %t187 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t183, i32 %t184)
  store i32 %t187, ptr %l120
  br label %bb57
bb56:
  store i1 false, ptr %l115, !tbaa !21
  br label %bb58
bb57:
  %t188 = load i32, ptr %l120
  %t190 = trunc i64 26 to i32
  %t191 = icmp eq i32 %t188, %t190
  store i1 %t191, ptr %l115, !tbaa !21
  br label %bb58
bb58:
  %t193 = load i1, ptr %l115, !tbaa !21
  br i1 %t193, label %bb59, label %bb60
bb59:
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t196 = getelementptr %"compiler/check:Checker", ptr %t194, i32 0, i32 97
  store i1 true, ptr %t196, !tbaa !21
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t199 = getelementptr %"compiler/check:Checker", ptr %t197, i32 0, i32 1
  %t200 = load ptr, ptr %t199, !tbaa !29
  %t202 = getelementptr %"compiler/generic:Program", ptr %t200, i32 0, i32 2
  %t203 = load i32, ptr %l8, !tbaa !23
  %t206 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %t202, i32 %t203)
  store i64 %t206, ptr %l128
  br label %bb61
bb60:
  br label %bb63
bb61:
  %t207 = load i64, ptr %l128, !tbaa !24
  %t208 = call %"compiler/check:reflVal" @compiler_2fcheck_2ervInt(ptr %v2, i64 %t207)
  store %"compiler/check:reflVal" %t208, ptr %l129
  br label %bb62
bb62:
  %t209 = load %"compiler/check:reflVal", ptr %l129
  store %"compiler/check:reflVal" %t209, ptr %rv
  br label %ret
bb63:
  br label %bb64
bb64:
  %t210 = call %"compiler/check:reflVal" @compiler_2fcheck_2enoRefl(ptr %v2)
  store %"compiler/check:reflVal" %t210, ptr %l130
  br label %bb65
bb65:
  %t211 = load %"compiler/check:reflVal", ptr %l130
  store %"compiler/check:reflVal" %t211, ptr %rv
  br label %ret
bb66:
  %t212 = load ptr, ptr %l1, !tbaa !29
  store ptr %t212, ptr %l131, !tbaa !29
  store i1 false, ptr %l132, !tbaa !21
  %t213 = load ptr, ptr %l131, !tbaa !29
  %t214 = icmp ne ptr %t213, null
  br i1 %t214, label %bb67, label %bb68
bb67:
  %t216 = load ptr, ptr %l131, !tbaa !29
  %t217 = load i64, ptr %t216
  %t219 = icmp eq i64 %t217, 3
  store i1 %t219, ptr %l132, !tbaa !21
  br label %bb68
bb68:
  %t220 = load i1, ptr %l132, !tbaa !21
  br i1 %t220, label %bb69, label %bb70
bb69:
  %t221 = load ptr, ptr %l1, !tbaa !29
  %t223 = getelementptr { i64, [5 x i64] }, ptr %t221, i32 0, i32 1
  %t224 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t223, i32 0, i32 1
  %t225 = load i32, ptr %t224
  store i32 %t225, ptr %l9
  %t227 = load ptr, ptr %l1, !tbaa !29
  %t229 = getelementptr { i64, [5 x i64] }, ptr %t227, i32 0, i32 1
  %t230 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t229, i32 0, i32 2
  %t231 = load ptr, ptr %t230
  store ptr %t231, ptr %l10, !tbaa !29
  br label %bb71
bb70:
  br label %bb91
bb71:
  %t233 = load ptr, ptr %l0, !tbaa !29
  %t234 = load ptr, ptr %l10, !tbaa !29
  %t237 = call %"compiler/check:reflVal" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflFold(ptr %v0, ptr %v1, ptr %v2, ptr %t233, ptr %t234)
  store %"compiler/check:reflVal" %t237, ptr %l141
  br label %bb72
bb72:
  %t238 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store ptr %t238, ptr %lp11
  %t239 = load %"compiler/check:reflVal", ptr %l141
  %t240 = load ptr, ptr %lp11
  store %"compiler/check:reflVal" %t239, ptr %t240
  %t241 = load ptr, ptr %lp11
  %t242 = getelementptr %"compiler/check:reflVal", ptr %t241, i32 0, i32 0
  %t243 = load i1, ptr %t242, !tbaa !21
  %t245 = xor i1 %t243, true
  br i1 %t245, label %bb73, label %bb74
bb73:
  %t247 = load ptr, ptr %lp11
  %t248 = load %"compiler/check:reflVal", ptr %t247
  store %"compiler/check:reflVal" %t248, ptr %rv
  br label %ret
bb74:
  br label %bb75
bb75:
  %t250 = load i32, ptr %l9
  %t252 = trunc i64 49 to i32
  %t253 = icmp eq i32 %t250, %t252
  br i1 %t253, label %bb76, label %bb77
bb76:
  %t255 = load ptr, ptr %lp11
  %t256 = getelementptr %"compiler/check:reflVal", ptr %t255, i32 0, i32 1
  %t257 = load i64, ptr %t256, !tbaa !24
  %t258 = load i64, ptr @G_2ecompiler_2fcheck_2eRvBool, !tbaa !24
  %t261 = icmp eq i64 %t257, %t258
  store i1 %t261, ptr %l147, !tbaa !21
  br label %bb78
bb77:
  store i1 false, ptr %l147, !tbaa !21
  br label %bb78
bb78:
  %t263 = load i1, ptr %l147, !tbaa !21
  br i1 %t263, label %bb79, label %bb80
bb79:
  %t264 = load ptr, ptr %lp11
  %t265 = getelementptr %"compiler/check:reflVal", ptr %t264, i32 0, i32 2
  %t266 = load i64, ptr %t265, !tbaa !24
  %t268 = icmp eq i64 %t266, 0
  %t270 = call %"compiler/check:reflVal" @compiler_2fcheck_2ervBool(ptr %v2, i1 %t268)
  store %"compiler/check:reflVal" %t270, ptr %l153
  br label %bb81
bb80:
  br label %bb82
bb81:
  %t271 = load %"compiler/check:reflVal", ptr %l153
  store %"compiler/check:reflVal" %t271, ptr %rv
  br label %ret
bb82:
  %t272 = load i32, ptr %l9
  %t274 = trunc i64 52 to i32
  %t275 = icmp eq i32 %t272, %t274
  br i1 %t275, label %bb83, label %bb84
bb83:
  %t277 = load ptr, ptr %lp11
  %t278 = getelementptr %"compiler/check:reflVal", ptr %t277, i32 0, i32 1
  %t279 = load i64, ptr %t278, !tbaa !24
  %t280 = load i64, ptr @G_2ecompiler_2fcheck_2eRvInt, !tbaa !24
  %t283 = icmp eq i64 %t279, %t280
  store i1 %t283, ptr %l156, !tbaa !21
  br label %bb85
bb84:
  store i1 false, ptr %l156, !tbaa !21
  br label %bb85
bb85:
  %t285 = load i1, ptr %l156, !tbaa !21
  br i1 %t285, label %bb86, label %bb87
bb86:
  %t286 = load ptr, ptr %lp11
  %t287 = getelementptr %"compiler/check:reflVal", ptr %t286, i32 0, i32 2
  %t288 = load i64, ptr %t287, !tbaa !24
  %t290 = sub i64 0, %t288
  %t292 = call %"compiler/check:reflVal" @compiler_2fcheck_2ervInt(ptr %v2, i64 %t290)
  store %"compiler/check:reflVal" %t292, ptr %l162
  br label %bb88
bb87:
  br label %bb89
bb88:
  %t293 = load %"compiler/check:reflVal", ptr %l162
  store %"compiler/check:reflVal" %t293, ptr %rv
  br label %ret
bb89:
  %t294 = call %"compiler/check:reflVal" @compiler_2fcheck_2enoRefl(ptr %v2)
  store %"compiler/check:reflVal" %t294, ptr %l163
  br label %bb90
bb90:
  %t295 = load %"compiler/check:reflVal", ptr %l163
  store %"compiler/check:reflVal" %t295, ptr %rv
  br label %ret
bb91:
  %t296 = load ptr, ptr %l1, !tbaa !29
  store ptr %t296, ptr %l164, !tbaa !29
  store i1 false, ptr %l165, !tbaa !21
  %t297 = load ptr, ptr %l164, !tbaa !29
  %t298 = icmp ne ptr %t297, null
  br i1 %t298, label %bb92, label %bb93
bb92:
  %t300 = load ptr, ptr %l164, !tbaa !29
  %t301 = load i64, ptr %t300
  %t303 = icmp eq i64 %t301, 5
  store i1 %t303, ptr %l165, !tbaa !21
  br label %bb93
bb93:
  %t304 = load i1, ptr %l165, !tbaa !21
  br i1 %t304, label %bb94, label %bb95
bb94:
  %t305 = load ptr, ptr %l1, !tbaa !29
  %t307 = getelementptr { i64, [5 x i64] }, ptr %t305, i32 0, i32 1
  %t308 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t307, i32 0, i32 1
  %t309 = load i32, ptr %t308
  store i32 %t309, ptr %l12
  %t311 = load ptr, ptr %l1, !tbaa !29
  %t313 = getelementptr { i64, [5 x i64] }, ptr %t311, i32 0, i32 1
  %t314 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t313, i32 0, i32 2
  %t315 = load ptr, ptr %t314
  store ptr %t315, ptr %l13, !tbaa !29
  %t317 = load ptr, ptr %l1, !tbaa !29
  %t319 = getelementptr { i64, [5 x i64] }, ptr %t317, i32 0, i32 1
  %t320 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t319, i32 0, i32 3
  %t321 = load ptr, ptr %t320
  store ptr %t321, ptr %l14, !tbaa !29
  br label %bb96
bb95:
  br label %bb205
bb96:
  %t323 = load ptr, ptr %l0, !tbaa !29
  %t324 = load ptr, ptr %l13, !tbaa !29
  %t327 = call %"compiler/check:reflVal" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflFold(ptr %v0, ptr %v1, ptr %v2, ptr %t323, ptr %t324)
  store %"compiler/check:reflVal" %t327, ptr %l176
  br label %bb97
bb97:
  %t328 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store ptr %t328, ptr %lp15
  %t329 = load %"compiler/check:reflVal", ptr %l176
  %t330 = load ptr, ptr %lp15
  store %"compiler/check:reflVal" %t329, ptr %t330
  %t331 = load i32, ptr %l12
  %t333 = trunc i64 46 to i32
  %t334 = icmp eq i32 %t331, %t333
  br i1 %t334, label %bb98, label %bb99
bb98:
  %t336 = load ptr, ptr %lp15
  %t337 = getelementptr %"compiler/check:reflVal", ptr %t336, i32 0, i32 0
  %t338 = load i1, ptr %t337, !tbaa !21
  store i1 %t338, ptr %l179, !tbaa !21
  br label %bb100
bb99:
  store i1 false, ptr %l179, !tbaa !21
  br label %bb100
bb100:
  %t340 = load i1, ptr %l179, !tbaa !21
  br i1 %t340, label %bb101, label %bb102
bb101:
  %t341 = load ptr, ptr %lp15
  %t342 = getelementptr %"compiler/check:reflVal", ptr %t341, i32 0, i32 1
  %t343 = load i64, ptr %t342, !tbaa !24
  %t344 = load i64, ptr @G_2ecompiler_2fcheck_2eRvBool, !tbaa !24
  %t347 = icmp eq i64 %t343, %t344
  store i1 %t347, ptr %l181, !tbaa !21
  br label %bb103
bb102:
  store i1 false, ptr %l181, !tbaa !21
  br label %bb103
bb103:
  %t349 = load i1, ptr %l181, !tbaa !21
  br i1 %t349, label %bb104, label %bb105
bb104:
  %t350 = load ptr, ptr %lp15
  %t351 = getelementptr %"compiler/check:reflVal", ptr %t350, i32 0, i32 2
  %t352 = load i64, ptr %t351, !tbaa !24
  %t354 = icmp eq i64 %t352, 0
  store i1 %t354, ptr %l185, !tbaa !21
  br label %bb106
bb105:
  store i1 false, ptr %l185, !tbaa !21
  br label %bb106
bb106:
  %t356 = load i1, ptr %l185, !tbaa !21
  br i1 %t356, label %bb107, label %bb108
bb107:
  %t357 = load ptr, ptr %lp15
  %t358 = load %"compiler/check:reflVal", ptr %t357
  store %"compiler/check:reflVal" %t358, ptr %rv
  br label %ret
bb108:
  br label %bb109
bb109:
  %t360 = load i32, ptr %l12
  %t362 = trunc i64 47 to i32
  %t363 = icmp eq i32 %t360, %t362
  br i1 %t363, label %bb110, label %bb111
bb110:
  %t365 = load ptr, ptr %lp15
  %t366 = getelementptr %"compiler/check:reflVal", ptr %t365, i32 0, i32 0
  %t367 = load i1, ptr %t366, !tbaa !21
  store i1 %t367, ptr %l191, !tbaa !21
  br label %bb112
bb111:
  store i1 false, ptr %l191, !tbaa !21
  br label %bb112
bb112:
  %t369 = load i1, ptr %l191, !tbaa !21
  br i1 %t369, label %bb113, label %bb114
bb113:
  %t370 = load ptr, ptr %lp15
  %t371 = getelementptr %"compiler/check:reflVal", ptr %t370, i32 0, i32 1
  %t372 = load i64, ptr %t371, !tbaa !24
  %t373 = load i64, ptr @G_2ecompiler_2fcheck_2eRvBool, !tbaa !24
  %t376 = icmp eq i64 %t372, %t373
  store i1 %t376, ptr %l193, !tbaa !21
  br label %bb115
bb114:
  store i1 false, ptr %l193, !tbaa !21
  br label %bb115
bb115:
  %t378 = load i1, ptr %l193, !tbaa !21
  br i1 %t378, label %bb116, label %bb117
bb116:
  %t379 = load ptr, ptr %lp15
  %t380 = getelementptr %"compiler/check:reflVal", ptr %t379, i32 0, i32 2
  %t381 = load i64, ptr %t380, !tbaa !24
  %t383 = icmp eq i64 %t381, 1
  store i1 %t383, ptr %l197, !tbaa !21
  br label %bb118
bb117:
  store i1 false, ptr %l197, !tbaa !21
  br label %bb118
bb118:
  %t385 = load i1, ptr %l197, !tbaa !21
  br i1 %t385, label %bb119, label %bb120
bb119:
  %t386 = load ptr, ptr %lp15
  %t387 = load %"compiler/check:reflVal", ptr %t386
  store %"compiler/check:reflVal" %t387, ptr %rv
  br label %ret
bb120:
  br label %bb121
bb121:
  %t389 = load ptr, ptr %l0, !tbaa !29
  %t390 = load ptr, ptr %l14, !tbaa !29
  %t393 = call %"compiler/check:reflVal" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflFold(ptr %v0, ptr %v1, ptr %v2, ptr %t389, ptr %t390)
  store %"compiler/check:reflVal" %t393, ptr %l203
  br label %bb122
bb122:
  %t394 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store ptr %t394, ptr %lp16
  %t395 = load %"compiler/check:reflVal", ptr %l203
  %t396 = load ptr, ptr %lp16
  store %"compiler/check:reflVal" %t395, ptr %t396
  %t397 = load ptr, ptr %lp15
  %t398 = getelementptr %"compiler/check:reflVal", ptr %t397, i32 0, i32 0
  %t399 = load i1, ptr %t398, !tbaa !21
  %t401 = xor i1 %t399, true
  br i1 %t401, label %bb123, label %bb124
bb123:
  store i1 true, ptr %l206, !tbaa !21
  br label %bb125
bb124:
  %t403 = load ptr, ptr %lp16
  %t404 = getelementptr %"compiler/check:reflVal", ptr %t403, i32 0, i32 0
  %t405 = load i1, ptr %t404, !tbaa !21
  %t407 = xor i1 %t405, true
  store i1 %t407, ptr %l206, !tbaa !21
  br label %bb125
bb125:
  %t409 = load i1, ptr %l206, !tbaa !21
  br i1 %t409, label %bb126, label %bb127
bb126:
  store i1 true, ptr %l209, !tbaa !21
  br label %bb128
bb127:
  %t410 = load ptr, ptr %lp15
  %t411 = getelementptr %"compiler/check:reflVal", ptr %t410, i32 0, i32 1
  %t412 = load i64, ptr %t411, !tbaa !24
  %t413 = load ptr, ptr %lp16
  %t414 = getelementptr %"compiler/check:reflVal", ptr %t413, i32 0, i32 1
  %t415 = load i64, ptr %t414, !tbaa !24
  %t418 = icmp ne i64 %t412, %t415
  store i1 %t418, ptr %l209, !tbaa !21
  br label %bb128
bb128:
  %t420 = load i1, ptr %l209, !tbaa !21
  br i1 %t420, label %bb129, label %bb130
bb129:
  %t421 = call %"compiler/check:reflVal" @compiler_2fcheck_2enoRefl(ptr %v2)
  store %"compiler/check:reflVal" %t421, ptr %l213
  br label %bb131
bb130:
  br label %bb132
bb131:
  %t422 = load %"compiler/check:reflVal", ptr %l213
  store %"compiler/check:reflVal" %t422, ptr %rv
  br label %ret
bb132:
  %t423 = load i32, ptr %l12
  %t425 = trunc i64 46 to i32
  %t426 = icmp eq i32 %t423, %t425
  br i1 %t426, label %bb133, label %bb134
bb133:
  store i1 true, ptr %l216, !tbaa !21
  br label %bb135
bb134:
  %t428 = load i32, ptr %l12
  %t430 = trunc i64 47 to i32
  %t431 = icmp eq i32 %t428, %t430
  store i1 %t431, ptr %l216, !tbaa !21
  br label %bb135
bb135:
  %t433 = load i1, ptr %l216, !tbaa !21
  br i1 %t433, label %bb136, label %bb137
bb136:
  %t434 = load ptr, ptr %lp15
  %t435 = getelementptr %"compiler/check:reflVal", ptr %t434, i32 0, i32 1
  %t436 = load i64, ptr %t435, !tbaa !24
  %t437 = load i64, ptr @G_2ecompiler_2fcheck_2eRvBool, !tbaa !24
  %t440 = icmp eq i64 %t436, %t437
  br i1 %t440, label %bb138, label %bb139
bb137:
  br label %bb142
bb138:
  %t442 = load ptr, ptr %lp16
  %t443 = load %"compiler/check:reflVal", ptr %t442
  store %"compiler/check:reflVal" %t443, ptr %l222
  br label %bb141
bb139:
  %t445 = call %"compiler/check:reflVal" @compiler_2fcheck_2enoRefl(ptr %v2)
  store %"compiler/check:reflVal" %t445, ptr %l224
  br label %bb140
bb140:
  %t446 = load %"compiler/check:reflVal", ptr %l224
  store %"compiler/check:reflVal" %t446, ptr %l222
  br label %bb141
bb141:
  %t447 = load %"compiler/check:reflVal", ptr %l222
  store %"compiler/check:reflVal" %t447, ptr %rv
  br label %ret
bb142:
  %t448 = load i32, ptr %l12
  %t450 = trunc i64 75 to i32
  %t451 = icmp eq i32 %t448, %t450
  br i1 %t451, label %bb143, label %bb144
bb143:
  store i1 true, ptr %l227, !tbaa !21
  br label %bb145
bb144:
  %t453 = load i32, ptr %l12
  %t455 = trunc i64 77 to i32
  %t456 = icmp eq i32 %t453, %t455
  store i1 %t456, ptr %l227, !tbaa !21
  br label %bb145
bb145:
  %t458 = load i1, ptr %l227, !tbaa !21
  br i1 %t458, label %bb146, label %bb147
bb146:
  %t459 = load ptr, ptr %lp15
  %t460 = getelementptr %"compiler/check:reflVal", ptr %t459, i32 0, i32 2
  %t461 = load i64, ptr %t460, !tbaa !24
  %t462 = load ptr, ptr %lp16
  %t463 = getelementptr %"compiler/check:reflVal", ptr %t462, i32 0, i32 2
  %t464 = load i64, ptr %t463, !tbaa !24
  %t467 = icmp eq i64 %t461, %t464
  store i1 %t467, ptr %l17, !tbaa !21
  %t469 = load ptr, ptr %lp15
  %t470 = getelementptr %"compiler/check:reflVal", ptr %t469, i32 0, i32 1
  %t471 = load i64, ptr %t470, !tbaa !24
  %t472 = load i64, ptr @G_2ecompiler_2fcheck_2eRvText, !tbaa !24
  %t475 = icmp eq i64 %t471, %t472
  br i1 %t475, label %bb148, label %bb149
bb147:
  br label %bb159
bb148:
  %t477 = load ptr, ptr %lp15
  %t478 = getelementptr %"compiler/check:reflVal", ptr %t477, i32 0, i32 3
  %t479 = load { i64, ptr }, ptr %t478, !tbaa !27
  %t480 = load ptr, ptr %lp16
  %t481 = getelementptr %"compiler/check:reflVal", ptr %t480, i32 0, i32 3
  %t482 = load { i64, ptr }, ptr %t481, !tbaa !27
  %t485 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %v2, { i64, ptr } %t479, { i64, ptr } %t482)
  store i1 %t485, ptr %l238
  br label %bb150
bb149:
  br label %bb151
bb150:
  %t486 = load i1, ptr %l238, !tbaa !21
  store i1 %t486, ptr %l17, !tbaa !21
  br label %bb151
bb151:
  %t487 = load ptr, ptr %lp15
  %t488 = getelementptr %"compiler/check:reflVal", ptr %t487, i32 0, i32 1
  %t489 = load i64, ptr %t488, !tbaa !24
  %t490 = load i64, ptr @G_2ecompiler_2fcheck_2eRvCase, !tbaa !24
  %t493 = icmp eq i64 %t489, %t490
  br i1 %t493, label %bb152, label %bb153
bb152:
  %t495 = load i1, ptr %l17, !tbaa !21
  br i1 %t495, label %bb154, label %bb155
bb153:
  br label %bb157
bb154:
  %t497 = load ptr, ptr %lp15
  %t498 = getelementptr %"compiler/check:reflVal", ptr %t497, i32 0, i32 4
  %t499 = load i32, ptr %t498, !tbaa !23
  %t500 = load ptr, ptr %lp16
  %t501 = getelementptr %"compiler/check:reflVal", ptr %t500, i32 0, i32 4
  %t502 = load i32, ptr %t501, !tbaa !23
  %t505 = icmp eq i32 %t499, %t502
  store i1 %t505, ptr %l243, !tbaa !21
  br label %bb156
bb155:
  store i1 false, ptr %l243, !tbaa !21
  br label %bb156
bb156:
  %t507 = load i1, ptr %l243, !tbaa !21
  store i1 %t507, ptr %l17, !tbaa !21
  br label %bb157
bb157:
  %t508 = load i1, ptr %l17, !tbaa !21
  %t509 = load i32, ptr %l12
  %t511 = trunc i64 75 to i32
  %t512 = icmp eq i32 %t509, %t511
  %t515 = icmp eq i1 %t508, %t512
  %t517 = call %"compiler/check:reflVal" @compiler_2fcheck_2ervBool(ptr %v2, i1 %t515)
  store %"compiler/check:reflVal" %t517, ptr %l251
  br label %bb158
bb158:
  %t518 = load %"compiler/check:reflVal", ptr %l251
  store %"compiler/check:reflVal" %t518, ptr %rv
  br label %ret
bb159:
  %t519 = load ptr, ptr %lp15
  %t520 = getelementptr %"compiler/check:reflVal", ptr %t519, i32 0, i32 1
  %t521 = load i64, ptr %t520, !tbaa !24
  %t522 = load i64, ptr @G_2ecompiler_2fcheck_2eRvInt, !tbaa !24
  %t525 = icmp ne i64 %t521, %t522
  br i1 %t525, label %bb160, label %bb161
bb160:
  %t527 = call %"compiler/check:reflVal" @compiler_2fcheck_2enoRefl(ptr %v2)
  store %"compiler/check:reflVal" %t527, ptr %l255
  br label %bb162
bb161:
  br label %bb163
bb162:
  %t528 = load %"compiler/check:reflVal", ptr %l255
  store %"compiler/check:reflVal" %t528, ptr %rv
  br label %ret
bb163:
  %t529 = load i32, ptr %l12
  %t531 = trunc i64 79 to i32
  %t532 = icmp eq i32 %t529, %t531
  br i1 %t532, label %bb164, label %bb165
bb164:
  br label %bb166
bb165:
  br label %bb168
bb166:
  %t534 = load ptr, ptr %lp15
  %t535 = getelementptr %"compiler/check:reflVal", ptr %t534, i32 0, i32 2
  %t536 = load i64, ptr %t535, !tbaa !24
  %t537 = load ptr, ptr %lp16
  %t538 = getelementptr %"compiler/check:reflVal", ptr %t537, i32 0, i32 2
  %t539 = load i64, ptr %t538, !tbaa !24
  %t542 = icmp slt i64 %t536, %t539
  %t544 = call %"compiler/check:reflVal" @compiler_2fcheck_2ervBool(ptr %v2, i1 %t542)
  store %"compiler/check:reflVal" %t544, ptr %l262
  br label %bb167
bb167:
  %t545 = load %"compiler/check:reflVal", ptr %l262
  store %"compiler/check:reflVal" %t545, ptr %l256
  br label %bb204
bb168:
  %t546 = load i32, ptr %l12
  %t548 = trunc i64 80 to i32
  %t549 = icmp eq i32 %t546, %t548
  br i1 %t549, label %bb169, label %bb170
bb169:
  br label %bb171
bb170:
  br label %bb173
bb171:
  %t551 = load ptr, ptr %lp15
  %t552 = getelementptr %"compiler/check:reflVal", ptr %t551, i32 0, i32 2
  %t553 = load i64, ptr %t552, !tbaa !24
  %t554 = load ptr, ptr %lp16
  %t555 = getelementptr %"compiler/check:reflVal", ptr %t554, i32 0, i32 2
  %t556 = load i64, ptr %t555, !tbaa !24
  %t559 = icmp sle i64 %t553, %t556
  %t561 = call %"compiler/check:reflVal" @compiler_2fcheck_2ervBool(ptr %v2, i1 %t559)
  store %"compiler/check:reflVal" %t561, ptr %l268
  br label %bb172
bb172:
  %t562 = load %"compiler/check:reflVal", ptr %l268
  store %"compiler/check:reflVal" %t562, ptr %l256
  br label %bb204
bb173:
  %t563 = load i32, ptr %l12
  %t565 = trunc i64 81 to i32
  %t566 = icmp eq i32 %t563, %t565
  br i1 %t566, label %bb174, label %bb175
bb174:
  br label %bb176
bb175:
  br label %bb178
bb176:
  %t568 = load ptr, ptr %lp15
  %t569 = getelementptr %"compiler/check:reflVal", ptr %t568, i32 0, i32 2
  %t570 = load i64, ptr %t569, !tbaa !24
  %t571 = load ptr, ptr %lp16
  %t572 = getelementptr %"compiler/check:reflVal", ptr %t571, i32 0, i32 2
  %t573 = load i64, ptr %t572, !tbaa !24
  %t576 = icmp sgt i64 %t570, %t573
  %t578 = call %"compiler/check:reflVal" @compiler_2fcheck_2ervBool(ptr %v2, i1 %t576)
  store %"compiler/check:reflVal" %t578, ptr %l274
  br label %bb177
bb177:
  %t579 = load %"compiler/check:reflVal", ptr %l274
  store %"compiler/check:reflVal" %t579, ptr %l256
  br label %bb204
bb178:
  %t580 = load i32, ptr %l12
  %t582 = trunc i64 82 to i32
  %t583 = icmp eq i32 %t580, %t582
  br i1 %t583, label %bb179, label %bb180
bb179:
  br label %bb181
bb180:
  br label %bb183
bb181:
  %t585 = load ptr, ptr %lp15
  %t586 = getelementptr %"compiler/check:reflVal", ptr %t585, i32 0, i32 2
  %t587 = load i64, ptr %t586, !tbaa !24
  %t588 = load ptr, ptr %lp16
  %t589 = getelementptr %"compiler/check:reflVal", ptr %t588, i32 0, i32 2
  %t590 = load i64, ptr %t589, !tbaa !24
  %t593 = icmp sge i64 %t587, %t590
  %t595 = call %"compiler/check:reflVal" @compiler_2fcheck_2ervBool(ptr %v2, i1 %t593)
  store %"compiler/check:reflVal" %t595, ptr %l280
  br label %bb182
bb182:
  %t596 = load %"compiler/check:reflVal", ptr %l280
  store %"compiler/check:reflVal" %t596, ptr %l256
  br label %bb204
bb183:
  %t597 = load i32, ptr %l12
  %t599 = trunc i64 51 to i32
  %t600 = icmp eq i32 %t597, %t599
  br i1 %t600, label %bb184, label %bb185
bb184:
  br label %bb186
bb185:
  br label %bb188
bb186:
  %t602 = load ptr, ptr %lp15
  %t603 = getelementptr %"compiler/check:reflVal", ptr %t602, i32 0, i32 2
  %t604 = load i64, ptr %t603, !tbaa !24
  %t605 = load ptr, ptr %lp16
  %t606 = getelementptr %"compiler/check:reflVal", ptr %t605, i32 0, i32 2
  %t607 = load i64, ptr %t606, !tbaa !24
  %t610 = add i64 %t604, %t607
  %t612 = call %"compiler/check:reflVal" @compiler_2fcheck_2ervInt(ptr %v2, i64 %t610)
  store %"compiler/check:reflVal" %t612, ptr %l286
  br label %bb187
bb187:
  %t613 = load %"compiler/check:reflVal", ptr %l286
  store %"compiler/check:reflVal" %t613, ptr %l256
  br label %bb204
bb188:
  %t614 = load i32, ptr %l12
  %t616 = trunc i64 52 to i32
  %t617 = icmp eq i32 %t614, %t616
  br i1 %t617, label %bb189, label %bb190
bb189:
  br label %bb191
bb190:
  br label %bb193
bb191:
  %t619 = load ptr, ptr %lp15
  %t620 = getelementptr %"compiler/check:reflVal", ptr %t619, i32 0, i32 2
  %t621 = load i64, ptr %t620, !tbaa !24
  %t622 = load ptr, ptr %lp16
  %t623 = getelementptr %"compiler/check:reflVal", ptr %t622, i32 0, i32 2
  %t624 = load i64, ptr %t623, !tbaa !24
  %t627 = sub i64 %t621, %t624
  %t629 = call %"compiler/check:reflVal" @compiler_2fcheck_2ervInt(ptr %v2, i64 %t627)
  store %"compiler/check:reflVal" %t629, ptr %l292
  br label %bb192
bb192:
  %t630 = load %"compiler/check:reflVal", ptr %l292
  store %"compiler/check:reflVal" %t630, ptr %l256
  br label %bb204
bb193:
  %t631 = load i32, ptr %l12
  %t633 = trunc i64 53 to i32
  %t634 = icmp eq i32 %t631, %t633
  br i1 %t634, label %bb194, label %bb195
bb194:
  br label %bb196
bb195:
  br label %bb198
bb196:
  %t636 = load ptr, ptr %lp15
  %t637 = getelementptr %"compiler/check:reflVal", ptr %t636, i32 0, i32 2
  %t638 = load i64, ptr %t637, !tbaa !24
  %t639 = load ptr, ptr %lp16
  %t640 = getelementptr %"compiler/check:reflVal", ptr %t639, i32 0, i32 2
  %t641 = load i64, ptr %t640, !tbaa !24
  %t644 = mul i64 %t638, %t641
  %t646 = call %"compiler/check:reflVal" @compiler_2fcheck_2ervInt(ptr %v2, i64 %t644)
  store %"compiler/check:reflVal" %t646, ptr %l298
  br label %bb197
bb197:
  %t647 = load %"compiler/check:reflVal", ptr %l298
  store %"compiler/check:reflVal" %t647, ptr %l256
  br label %bb204
bb198:
  br i1 true, label %bb199, label %bb200
bb199:
  br label %bb201
bb200:
  br label %bb203
bb201:
  %t648 = call %"compiler/check:reflVal" @compiler_2fcheck_2enoRefl(ptr %v2)
  store %"compiler/check:reflVal" %t648, ptr %l299
  br label %bb202
bb202:
  %t649 = load %"compiler/check:reflVal", ptr %l299
  store %"compiler/check:reflVal" %t649, ptr %l256
  br label %bb204
bb203:
  call void @__olang_check_failed(ptr @olang_loc_86ff27eaf091632f_ba308f61bf434c3)
  unreachable
bb204:
  %t650 = load %"compiler/check:reflVal", ptr %l256
  store %"compiler/check:reflVal" %t650, ptr %rv
  br label %ret
bb205:
  %t651 = load ptr, ptr %l1, !tbaa !29
  store ptr %t651, ptr %l300, !tbaa !29
  store i1 false, ptr %l301, !tbaa !21
  %t652 = load ptr, ptr %l300, !tbaa !29
  %t653 = icmp ne ptr %t652, null
  br i1 %t653, label %bb206, label %bb207
bb206:
  %t655 = load ptr, ptr %l300, !tbaa !29
  %t656 = load i64, ptr %t655
  %t658 = icmp eq i64 %t656, 12
  store i1 %t658, ptr %l301, !tbaa !21
  br label %bb207
bb207:
  %t659 = load i1, ptr %l301, !tbaa !21
  br i1 %t659, label %bb208, label %bb209
bb208:
  %t660 = load ptr, ptr %l1, !tbaa !29
  %t662 = getelementptr { i64, [5 x i64] }, ptr %t660, i32 0, i32 1
  %t663 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t662, i32 0, i32 1
  %t664 = load ptr, ptr %t663
  store ptr %t664, ptr %l18, !tbaa !29
  %t666 = load ptr, ptr %l1, !tbaa !29
  %t668 = getelementptr { i64, [5 x i64] }, ptr %t666, i32 0, i32 1
  %t669 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t668, i32 0, i32 2
  %t670 = load { i64, ptr }, ptr %t669
  store { i64, ptr } %t670, ptr %l19, !tbaa !27
  br label %bb210
bb209:
  br label %bb243
bb210:
  %t672 = load ptr, ptr %l18, !tbaa !29
  store ptr %t672, ptr %l308, !tbaa !29
  store i1 false, ptr %l309, !tbaa !21
  %t673 = load ptr, ptr %l308, !tbaa !29
  %t674 = icmp ne ptr %t673, null
  br i1 %t674, label %bb211, label %bb212
bb211:
  %t676 = load ptr, ptr %l308, !tbaa !29
  %t677 = load i64, ptr %t676
  %t679 = icmp eq i64 %t677, 15
  store i1 %t679, ptr %l309, !tbaa !21
  br label %bb212
bb212:
  %t680 = load i1, ptr %l309, !tbaa !21
  br i1 %t680, label %bb213, label %bb214
bb213:
  %t681 = load ptr, ptr %l18, !tbaa !29
  %t683 = getelementptr { i64, [5 x i64] }, ptr %t681, i32 0, i32 1
  %t684 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t683, i32 0, i32 1
  %t685 = load ptr, ptr %t684
  store ptr %t685, ptr %l20, !tbaa !29
  %t687 = load ptr, ptr %l18, !tbaa !29
  %t689 = getelementptr { i64, [5 x i64] }, ptr %t687, i32 0, i32 1
  %t690 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t689, i32 0, i32 2
  %t691 = load i32, ptr %t690
  store i32 %t691, ptr %l21, !tbaa !23
  br label %bb215
bb214:
  br label %bb240
bb215:
  store %olang.scope zeroinitializer, ptr %s31
  %t693 = load ptr, ptr %l0, !tbaa !29
  %t694 = load i32, ptr %l21, !tbaa !23
  %t697 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t693, i32 %t694)
  store { i64, ptr } %t697, ptr %l318
  br label %bb216
bb216:
  %t698 = load { i64, ptr }, ptr %l318, !tbaa !27
  %t699 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s31, { i64, ptr } %t698, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d43, i32 0, i32 1) })
  store i1 %t699, ptr %l319
  br label %bb217
bb217:
  %t700 = load i1, ptr %l319, !tbaa !21
  br i1 %t700, label %bb218, label %bb219
bb218:
  %t701 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t703 = extractvalue { i64, ptr } %t701, 0
  %t705 = icmp eq i64 %t703, 0
  store i1 %t705, ptr %l320, !tbaa !21
  br label %bb220
bb219:
  store i1 false, ptr %l320, !tbaa !21
  br label %bb220
bb220:
  %t707 = load i1, ptr %l320, !tbaa !21
  br i1 %t707, label %bb221, label %bb222
bb221:
  %t708 = load ptr, ptr %l0, !tbaa !29
  %t709 = load ptr, ptr %l20, !tbaa !29
  %t712 = call %"compiler/check:reflList" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistOf(ptr %v0, ptr %v1, ptr %t708, ptr %t709)
  store %"compiler/check:reflList" %t712, ptr %l326
  br label %bb223
bb222:
  br label %bb239
bb223:
  %t713 = load %"compiler/check:reflList", ptr %l326
  store %"compiler/check:reflList" %t713, ptr %l22
  %t714 = getelementptr %"compiler/check:reflList", ptr %l22, i32 0, i32 0
  %t715 = load i1, ptr %t714, !tbaa !21
  br i1 %t715, label %bb224, label %bb225
bb224:
  store %olang.scope zeroinitializer, ptr %s33
  %t717 = load ptr, ptr %l0, !tbaa !29
  %t719 = getelementptr %"compiler/check:Checker", ptr %t717, i32 0, i32 97
  store i1 true, ptr %t719, !tbaa !21
  %t720 = getelementptr %"compiler/check:reflList", ptr %l22, i32 0, i32 1
  %t721 = load i32, ptr %t720, !tbaa !23
  %t722 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t725 = icmp eq i32 %t721, %t722
  br i1 %t725, label %bb226, label %bb227
bb225:
  br label %bb238
bb226:
  %t727 = call %"compiler/check:reflVal" @compiler_2fcheck_2enoRefl(ptr %v2)
  store %"compiler/check:reflVal" %t727, ptr %l332
  br label %bb228
bb227:
  br label %bb229
bb228:
  call void @__olang_scope_close(ptr %s33)
  call void @__olang_scope_close(ptr %s31)
  %t728 = load %"compiler/check:reflVal", ptr %l332
  store %"compiler/check:reflVal" %t728, ptr %rv
  br label %ret
bb229:
  %t729 = load ptr, ptr %l0, !tbaa !29
  %t731 = getelementptr %"compiler/check:Checker", ptr %t729, i32 0, i32 1
  %t732 = load ptr, ptr %t731, !tbaa !29
  store ptr %t732, ptr %l334, !tbaa !29
  %t733 = getelementptr %"compiler/check:reflList", ptr %l22, i32 0, i32 1
  %t734 = load i32, ptr %t733, !tbaa !23
  store i32 %t734, ptr %l335, !tbaa !23
  %t735 = getelementptr %"compiler/check:reflList", ptr %l22, i32 0, i32 2
  %t736 = load i64, ptr %t735, !tbaa !24
  store i64 %t736, ptr %l336, !tbaa !24
  %t737 = getelementptr %"compiler/check:reflList", ptr %l22, i32 0, i32 3
  %t738 = load i64, ptr %t737, !tbaa !24
  store i64 %t738, ptr %l337, !tbaa !24
  %t739 = load ptr, ptr %l0, !tbaa !29
  %t741 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t739)
  store ptr %t741, ptr %l339
  br label %bb230
bb230:
  %t742 = load ptr, ptr %l339, !tbaa !29
  %t744 = getelementptr %"compiler/check:frame", ptr %t742, i32 0, i32 1
  %t745 = load i64, ptr %t744, !tbaa !24
  %t746 = load ptr, ptr %l334, !tbaa !29
  %t747 = load i32, ptr %l335, !tbaa !23
  %t748 = load i64, ptr %l336, !tbaa !24
  %t749 = load i64, ptr %l337, !tbaa !24
  %t751 = call { { i64, ptr }, { i64, ptr } } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eReflItems(ptr %v0, ptr %s33, ptr %t746, i32 %t747, i64 %t748, i64 %t749, i64 %t745)
  store { { i64, ptr }, { i64, ptr } } %t751, ptr %l342
  br label %bb231
bb231:
  %t752 = load { { i64, ptr }, { i64, ptr } }, ptr %l342
  store { { i64, ptr }, { i64, ptr } } %t752, ptr %l23
  %t753 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l23, i32 0, i32 0
  %t754 = load { i64, ptr }, ptr %t753, !tbaa !27
  store { i64, ptr } %t754, ptr %l343, !tbaa !27
  %t755 = load { i64, ptr }, ptr %l343, !tbaa !27
  %t756 = extractvalue { i64, ptr } %t755, 0
  store i64 %t756, ptr %l344, !tbaa !24
  %t757 = load i64, ptr %l344, !tbaa !24
  %t758 = mul i64 %t757, 8
  %t759 = call ptr @__olang_scope_alloc_zeroed(ptr %s33, i64 %t758)
  %t760 = insertvalue { i64, ptr } undef, i64 %t757, 0
  %t761 = insertvalue { i64, ptr } %t760, ptr %t759, 1
  store { i64, ptr } %t761, ptr %l345, !tbaa !27
  %t762 = getelementptr { i64, ptr }, ptr %l345, i32 0, i32 1
  %t763 = load ptr, ptr %t762, !tbaa !27
  %t764 = getelementptr { i64, ptr }, ptr %l343, i32 0, i32 1
  %t765 = load ptr, ptr %t764, !tbaa !27
  %t766 = load i64, ptr %l344, !tbaa !24
  %t767 = mul i64 %t766, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t763, ptr %t765, i64 %t767, i1 false)
  %t768 = load { i64, ptr }, ptr %l345, !tbaa !27
  store { i64, ptr } %t768, ptr %l24, !tbaa !27
  %t769 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l23, i32 0, i32 1
  %t770 = load { i64, ptr }, ptr %t769, !tbaa !27
  store { i64, ptr } %t770, ptr %l346, !tbaa !27
  %t771 = load { i64, ptr }, ptr %l346, !tbaa !27
  %t772 = extractvalue { i64, ptr } %t771, 0
  store i64 %t772, ptr %l347, !tbaa !24
  %t773 = load i64, ptr %l347, !tbaa !24
  %t774 = mul i64 %t773, 1
  %t775 = call ptr @__olang_scope_alloc_zeroed(ptr %s33, i64 %t774)
  %t776 = insertvalue { i64, ptr } undef, i64 %t773, 0
  %t777 = insertvalue { i64, ptr } %t776, ptr %t775, 1
  store { i64, ptr } %t777, ptr %l348, !tbaa !27
  %t778 = getelementptr { i64, ptr }, ptr %l348, i32 0, i32 1
  %t779 = load ptr, ptr %t778, !tbaa !27
  %t780 = getelementptr { i64, ptr }, ptr %l346, i32 0, i32 1
  %t781 = load ptr, ptr %t780, !tbaa !27
  %t782 = load i64, ptr %l347, !tbaa !24
  %t783 = mul i64 %t782, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t779, ptr %t781, i64 %t783, i1 false)
  %t784 = load { i64, ptr }, ptr %l348, !tbaa !27
  %t787 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s33, ptr %s33, { i64, ptr } %t784, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d44, i32 0, i32 1) })
  store i1 %t787, ptr %l350
  br label %bb232
bb232:
  %t788 = load i1, ptr %l350, !tbaa !21
  br i1 %t788, label %bb233, label %bb234
bb233:
  %t789 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t791 = extractvalue { i64, ptr } %t789, 0
  %t793 = call %"compiler/check:reflVal" @compiler_2fcheck_2ervInt(ptr %v2, i64 %t791)
  store %"compiler/check:reflVal" %t793, ptr %l354
  br label %bb235
bb234:
  %t794 = call %"compiler/check:reflVal" @compiler_2fcheck_2enoRefl(ptr %v2)
  store %"compiler/check:reflVal" %t794, ptr %l355
  br label %bb236
bb235:
  %t795 = load %"compiler/check:reflVal", ptr %l354
  store %"compiler/check:reflVal" %t795, ptr %l351
  br label %bb237
bb236:
  %t796 = load %"compiler/check:reflVal", ptr %l355
  store %"compiler/check:reflVal" %t796, ptr %l351
  br label %bb237
bb237:
  call void @__olang_scope_close(ptr %s33)
  call void @__olang_scope_close(ptr %s31)
  %t797 = load %"compiler/check:reflVal", ptr %l351
  store %"compiler/check:reflVal" %t797, ptr %rv
  br label %ret
bb238:
  br label %bb239
bb239:
  call void @__olang_scope_close(ptr %s31)
  br label %bb241
bb240:
  br label %bb241
bb241:
  %t798 = call %"compiler/check:reflVal" @compiler_2fcheck_2enoRefl(ptr %v2)
  store %"compiler/check:reflVal" %t798, ptr %l356
  br label %bb242
bb242:
  %t799 = load %"compiler/check:reflVal", ptr %l356
  store %"compiler/check:reflVal" %t799, ptr %rv
  br label %ret
bb243:
  %t800 = load ptr, ptr %l1, !tbaa !29
  store ptr %t800, ptr %l357, !tbaa !29
  store i1 false, ptr %l358, !tbaa !21
  %t801 = load ptr, ptr %l357, !tbaa !29
  %t802 = icmp ne ptr %t801, null
  br i1 %t802, label %bb244, label %bb245
bb244:
  %t804 = load ptr, ptr %l357, !tbaa !29
  %t805 = load i64, ptr %t804
  %t807 = icmp eq i64 %t805, 15
  store i1 %t807, ptr %l358, !tbaa !21
  br label %bb245
bb245:
  %t808 = load i1, ptr %l358, !tbaa !21
  br i1 %t808, label %bb246, label %bb247
bb246:
  %t809 = load ptr, ptr %l1, !tbaa !29
  %t811 = getelementptr { i64, [5 x i64] }, ptr %t809, i32 0, i32 1
  %t812 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t811, i32 0, i32 1
  %t813 = load ptr, ptr %t812
  store ptr %t813, ptr %l26, !tbaa !29
  %t815 = load ptr, ptr %l1, !tbaa !29
  %t817 = getelementptr { i64, [5 x i64] }, ptr %t815, i32 0, i32 1
  %t818 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t817, i32 0, i32 2
  %t819 = load i32, ptr %t818
  store i32 %t819, ptr %l27, !tbaa !23
  br label %bb248
bb247:
  br label %bb283
bb248:
  %t821 = load ptr, ptr %l0, !tbaa !29
  %t822 = load ptr, ptr %l26, !tbaa !29
  %t825 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeNamed(ptr %v0, ptr %v1, ptr %t821, ptr %t822)
  store i32 %t825, ptr %l367
  br label %bb249
bb249:
  %t826 = load i32, ptr %l367, !tbaa !23
  store i32 %t826, ptr %l28, !tbaa !23
  %t827 = load i32, ptr %l28, !tbaa !23
  %t829 = icmp sge i32 %t827, 0
  br i1 %t829, label %bb250, label %bb251
bb250:
  %t831 = load ptr, ptr %l0, !tbaa !29
  %t832 = load i32, ptr %l28, !tbaa !23
  %t835 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %t831, i32 %t832)
  store i1 %t835, ptr %l373
  br label %bb252
bb251:
  store i1 false, ptr %l370, !tbaa !21
  br label %bb253
bb252:
  %t836 = load i1, ptr %l373, !tbaa !21
  store i1 %t836, ptr %l370, !tbaa !21
  br label %bb253
bb253:
  %t837 = load i1, ptr %l370, !tbaa !21
  br i1 %t837, label %bb254, label %bb255
bb254:
  %t838 = load ptr, ptr %l0, !tbaa !29
  %t839 = load i32, ptr %l28, !tbaa !23
  %t840 = load i32, ptr %l27, !tbaa !23
  %t844 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehasCase(ptr %v0, ptr %t838, i32 %t839, i32 %t840)
  store i1 %t844, ptr %l378
  br label %bb256
bb255:
  store i1 false, ptr %l374, !tbaa !21
  br label %bb257
bb256:
  %t845 = load i1, ptr %l378, !tbaa !21
  store i1 %t845, ptr %l374, !tbaa !21
  br label %bb257
bb257:
  %t846 = load i1, ptr %l374, !tbaa !21
  br i1 %t846, label %bb258, label %bb259
bb258:
  %t847 = load ptr, ptr %l0, !tbaa !29
  %t848 = load ptr, ptr %l26, !tbaa !29
  %t851 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eviaTypeVar(ptr %v0, ptr %v1, ptr %t847, ptr %t848)
  store i1 %t851, ptr %l382
  br label %bb260
bb259:
  store i1 false, ptr %l379, !tbaa !21
  br label %bb261
bb260:
  %t852 = load i1, ptr %l382, !tbaa !21
  %t853 = xor i1 %t852, true
  store i1 %t853, ptr %l379, !tbaa !21
  br label %bb261
bb261:
  %t855 = load i1, ptr %l379, !tbaa !21
  br i1 %t855, label %bb262, label %bb263
bb262:
  %t856 = load ptr, ptr %l0, !tbaa !29
  %t858 = getelementptr %"compiler/check:Checker", ptr %t856, i32 0, i32 1
  %t859 = load ptr, ptr %t858, !tbaa !29
  %t861 = getelementptr %"compiler/generic:Program", ptr %t859, i32 0, i32 2
  %t862 = load i32, ptr %l28, !tbaa !23
  %t865 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCaseNames(ptr %v0, ptr %t861, i32 %t862)
  store { i64, ptr } %t865, ptr %l388
  br label %bb264
bb263:
  br label %bb281
bb264:
  %t866 = load { i64, ptr }, ptr %l388, !tbaa !27
  store { i64, ptr } %t866, ptr %l29, !tbaa !27
  store i64 0, ptr %l30, !tbaa !24
  %t867 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t869 = extractvalue { i64, ptr } %t867, 0
  store i64 %t869, ptr %l31, !tbaa !24
  store i64 1, ptr %l32, !tbaa !24
  %t871 = load i64, ptr %l31, !tbaa !24
  %t872 = load i64, ptr %l30, !tbaa !24
  %t875 = icmp sgt i64 %t871, %t872
  br i1 %t875, label %bb265, label %bb266
bb265:
  %t877 = load i64, ptr %l32, !tbaa !24
  %t879 = icmp sgt i64 %t877, 0
  br i1 %t879, label %bb267, label %bb268
bb266:
  store i64 0, ptr %l394, !tbaa !24
  br label %bb270
bb267:
  %t881 = load i64, ptr %l31, !tbaa !24
  %t882 = load i64, ptr %l30, !tbaa !24
  %t885 = sub i64 %t881, %t882
  %t886 = load i64, ptr %l32, !tbaa !24
  %t889 = add i64 %t885, %t886
  %t891 = sub i64 %t889, 1
  %t892 = load i64, ptr %l32, !tbaa !24
  %t895 = sdiv i64 %t891, %t892
  store i64 %t895, ptr %l397, !tbaa !24
  br label %bb269
bb268:
  store i64 0, ptr %l397, !tbaa !24
  br label %bb269
bb269:
  %t897 = load i64, ptr %l397, !tbaa !24
  store i64 %t897, ptr %l394, !tbaa !24
  br label %bb270
bb270:
  %t898 = load i64, ptr %l394, !tbaa !24
  store i64 %t898, ptr %l33, !tbaa !24
  store i64 0, ptr %l34, !tbaa !24
  br label %bb271
bb271:
  %t899 = load i64, ptr %l34, !tbaa !24
  %t900 = load i64, ptr %l33, !tbaa !24
  %t903 = icmp slt i64 %t899, %t900
  %t905 = xor i1 %t903, true
  br i1 %t905, label %bb272, label %bb273
bb272:
  br label %bb280
bb273:
  br label %bb274
bb274:
  %t907 = load i64, ptr %l30, !tbaa !24
  %t908 = load i64, ptr %l34, !tbaa !24
  %t909 = load i64, ptr %l32, !tbaa !24
  %t912 = mul i64 %t908, %t909
  %t915 = add i64 %t907, %t912
  store i64 %t915, ptr %l35, !tbaa !24
  %t917 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t917, ptr %l415, !tbaa !27
  %t918 = load i64, ptr %l35, !tbaa !24
  %t920 = getelementptr { i64, ptr }, ptr %l415, i32 0, i32 1
  %t921 = load ptr, ptr %t920, !tbaa !27
  %t922 = getelementptr i32, ptr %t921, i64 %t918
  %t923 = load i32, ptr %t922, !tbaa !33
  %t924 = load i32, ptr %l27, !tbaa !23
  %t927 = icmp eq i32 %t923, %t924
  br i1 %t927, label %bb275, label %bb276
bb275:
  %t929 = load i64, ptr @G_2ecompiler_2fcheck_2eRvCase, !tbaa !24
  %t930 = load i64, ptr %l35, !tbaa !24
  %t931 = load i32, ptr %l28, !tbaa !23
  %t935 = call %"compiler/check:reflVal" @compiler_2fcheck_3areflVal_2ector(ptr %v2, ptr %v2, i1 true, i64 %t929, i64 %t930, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d45, i32 0, i32 1) }, i32 %t931)
  store %"compiler/check:reflVal" %t935, ptr %l423
  br label %bb277
bb276:
  br label %bb278
bb277:
  %t936 = load %"compiler/check:reflVal", ptr %l423
  store %"compiler/check:reflVal" %t936, ptr %rv
  br label %ret
bb278:
  br label %bb279
bb279:
  %t937 = load i64, ptr %l34, !tbaa !24
  %t939 = add i64 %t937, 1
  store i64 %t939, ptr %l34, !tbaa !24
  br label %bb271
bb280:
  br label %bb281
bb281:
  %t941 = load ptr, ptr %l0, !tbaa !29
  %t942 = load ptr, ptr %l26, !tbaa !29
  %t943 = load i32, ptr %l27, !tbaa !23
  %t947 = call %"compiler/check:reflVal" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflConst(ptr %v0, ptr %v1, ptr %v2, ptr %t941, ptr %t942, i32 %t943)
  store %"compiler/check:reflVal" %t947, ptr %l429
  br label %bb282
bb282:
  %t948 = load %"compiler/check:reflVal", ptr %l429
  store %"compiler/check:reflVal" %t948, ptr %rv
  br label %ret
bb283:
  %t949 = call %"compiler/check:reflVal" @compiler_2fcheck_2enoRefl(ptr %v2)
  store %"compiler/check:reflVal" %t949, ptr %l430
  br label %bb284
bb284:
  %t950 = load %"compiler/check:reflVal", ptr %l430
  store %"compiler/check:reflVal" %t950, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:reflVal", ptr %rv
  ret %"compiler/check:reflVal" %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroArgFor(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, i64 %a2, ptr %a3, %"compiler/source:Span" %a4, { i64, ptr } %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca i64
  %l13 = alloca i1
  %l17 = alloca ptr
  %l20 = alloca ptr
  %l23 = alloca i32
  %l24 = alloca i1
  %l28 = alloca i1
  %l32 = alloca ptr
  %l35 = alloca ptr
  %l38 = alloca ptr
  %l42 = alloca ptr
  %l45 = alloca i32
  %l46 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l50 = alloca i32
  %l53 = alloca i1
  %l58 = alloca i1
  %l60 = alloca ptr
  %l61 = alloca i64
  %l62 = alloca i64
  %l65 = alloca { i64, [3 x i64] }
  %l66 = alloca { i64, ptr }
  %l69 = alloca { i64, ptr }
  %l71 = alloca %"compiler/check:roArg"
  %l72 = alloca ptr
  %l73 = alloca i1
  %l81 = alloca i64
  %l85 = alloca ptr
  %l88 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l91 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l92 = alloca %"std/pair:Pair.b139c4f75a6545712256427180a82a06"
  %l95 = alloca i1
  %l97 = alloca ptr
  %l102 = alloca %"compiler/check:roDeepArg"
  %l103 = alloca ptr
  %l106 = alloca i32
  %l107 = alloca i1
  %l112 = alloca i1
  %l114 = alloca ptr
  %l115 = alloca i64
  %l116 = alloca i64
  %l119 = alloca { i64, [3 x i64] }
  %l120 = alloca { i64, ptr }
  %l121 = alloca ptr
  %l124 = alloca i32
  %l125 = alloca { i64, ptr }
  %l126 = alloca { i64, ptr }
  %l127 = alloca ptr
  %l130 = alloca i32
  %l133 = alloca i32
  %l134 = alloca { i64, ptr }
  %l136 = alloca %"compiler/check:roArg"
  %l137 = alloca ptr
  %l139 = alloca ptr
  %l140 = alloca i64
  %l144 = alloca ptr
  %l147 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l150 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l151 = alloca %"std/pair:Pair.b139c4f75a6545712256427180a82a06"
  %l154 = alloca i1
  %l156 = alloca ptr
  %l161 = alloca %"compiler/check:roDeepArg"
  %s7 = alloca %olang.scope
  %s12 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  store ptr %a3, ptr %l3
  store %"compiler/source:Span" %a4, ptr %l4
  store { i64, ptr } %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb3
bb2:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t7 = icmp eq ptr %t5, null
  store i1 %t7, ptr %l13, !tbaa !21
  br label %bb3
bb3:
  %t9 = load i1, ptr %l13, !tbaa !21
  br i1 %t9, label %bb4, label %bb5
bb4:
  br label %ret
bb5:
  br label %bb6
bb6:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t10)
  store ptr %t12, ptr %l17
  br label %bb7
bb7:
  %t13 = load ptr, ptr %l17, !tbaa !29
  %t15 = getelementptr %"compiler/check:frame", ptr %t13, i32 0, i32 0
  %t16 = load i64, ptr %t15, !tbaa !24
  store i64 %t16, ptr %l6, !tbaa !24
  %t18 = load ptr, ptr %l0, !tbaa !29
  store ptr %t18, ptr %l20, !tbaa !29
  %t19 = load ptr, ptr %l3, !tbaa !29
  %t22 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t19)
  store i32 %t22, ptr %l23
  br label %bb8
bb8:
  %t23 = load ptr, ptr %l20, !tbaa !29
  %t24 = load i32, ptr %l23, !tbaa !23
  %t25 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t23, i32 %t24)
  store i1 %t25, ptr %l24
  br label %bb9
bb9:
  %t26 = load i1, ptr %l24, !tbaa !21
  br i1 %t26, label %bb10, label %bb11
bb10:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load i64, ptr %l1, !tbaa !24
  %t29 = load i64, ptr %l2, !tbaa !24
  %t33 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroByArg(ptr %v0, ptr %t27, i64 %t28, i64 %t29)
  store i1 %t33, ptr %l28
  br label %bb12
bb11:
  br label %bb53
bb12:
  %t34 = load i1, ptr %l28, !tbaa !21
  %t35 = xor i1 %t34, true
  br i1 %t35, label %bb13, label %bb14
bb13:
  br label %ret
bb14:
  br label %bb15
bb15:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/check:Checker", ptr %t37, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t42 = getelementptr %"compiler/generic:Program", ptr %t40, i32 0, i32 2
  store ptr %t42, ptr %l32, !tbaa !29
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/check:Checker", ptr %t43, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t48 = getelementptr %"compiler/generic:Program", ptr %t46, i32 0, i32 2
  store ptr %t48, ptr %l35, !tbaa !29
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/check:Checker", ptr %t49, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !29
  %t54 = getelementptr %"compiler/generic:Program", ptr %t52, i32 0, i32 2
  store ptr %t54, ptr %l38, !tbaa !29
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/check:Checker", ptr %t55, i32 0, i32 11
  %t58 = load i64, ptr %l1, !tbaa !24
  %t61 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t57, i64 %t58)
  store ptr %t61, ptr %l42
  br label %bb16
bb16:
  %t62 = load ptr, ptr %l42, !tbaa !29
  %t64 = getelementptr %"compiler/typed:Body", ptr %t62, i32 0, i32 2
  %t65 = load i32, ptr %t64, !tbaa !23
  %t66 = load ptr, ptr %l38, !tbaa !29
  %t68 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t66, i32 %t65)
  store i32 %t68, ptr %l45
  br label %bb17
bb17:
  %t69 = load ptr, ptr %l35, !tbaa !29
  %t70 = load i32, ptr %l45, !tbaa !23
  %t71 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t69, i32 %t70)
  store { i64, ptr } %t71, ptr %l46
  br label %bb18
bb18:
  %t72 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t72, ptr %l47, !tbaa !27
  %t73 = load i64, ptr %l2, !tbaa !24
  %t75 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = getelementptr i32, ptr %t76, i64 %t73
  %t78 = load i32, ptr %t77, !tbaa !33
  %t79 = load ptr, ptr %l32, !tbaa !29
  %t81 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t79, i32 %t78)
  store i32 %t81, ptr %l50
  br label %bb19
bb19:
  %t82 = load i32, ptr %l50, !tbaa !23
  store i32 %t82, ptr %l7, !tbaa !23
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load i32, ptr %l7, !tbaa !23
  %t87 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enamedHolds(ptr %v0, ptr %t83, i32 %t84)
  store i1 %t87, ptr %l53
  br label %bb20
bb20:
  %t88 = load i1, ptr %l53, !tbaa !21
  %t89 = xor i1 %t88, true
  br i1 %t89, label %bb21, label %bb22
bb21:
  br label %ret
bb22:
  br label %bb23
bb23:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load ptr, ptr %l3, !tbaa !29
  %t96 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroRef(ptr %v0, ptr %v1, ptr %t91, ptr %t92)
  store i1 %t96, ptr %l58
  br label %bb24
bb24:
  %t97 = load i1, ptr %l58, !tbaa !21
  br i1 %t97, label %bb25, label %bb26
bb25:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/check:Checker", ptr %t98, i32 0, i32 69
  store ptr %t100, ptr %l60, !tbaa !29
  %t101 = load i64, ptr %l1, !tbaa !24
  store i64 %t101, ptr %l61, !tbaa !24
  %t102 = load i64, ptr %l2, !tbaa !24
  store i64 %t102, ptr %l62, !tbaa !24
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t104 = load %"compiler/source:Span", ptr %l4
  %t107 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %t103, %"compiler/source:Span" %t104)
  store { i64, [3 x i64] } %t107, ptr %l65
  br label %bb27
bb26:
  br label %bb31
bb27:
  %t108 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t108, ptr %l66, !tbaa !27
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t110 = load i32, ptr %l7, !tbaa !23
  %t113 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v0, ptr %t109, i32 %t110)
  store { i64, ptr } %t113, ptr %l69
  br label %bb28
bb28:
  %t114 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t115 = extractvalue { i64, ptr } %t114, 0
  %t116 = extractvalue { i64, ptr } %t114, 1
  %t117 = mul i64 %t115, 1
  %t118 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t117)
  call void @llvm.memcpy.p0.p0.i64(ptr %t118, ptr %t116, i64 %t117, i1 false)
  %t119 = insertvalue { i64, ptr } undef, i64 %t115, 0
  %t120 = insertvalue { i64, ptr } %t119, ptr %t118, 1
  %t121 = load i64, ptr %l61, !tbaa !24
  %t122 = load i64, ptr %l62, !tbaa !24
  %t123 = load { i64, [3 x i64] }, ptr %l65
  %t124 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t126 = call %"compiler/check:roArg" @compiler_2fcheck_3aroArg_2ector(ptr %v2, ptr %v0, ptr %v0, ptr %v0, i64 %t121, i64 %t122, { i64, [3 x i64] } %t123, { i64, ptr } %t124, { i64, ptr } %t120, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d46, i32 0, i32 1) })
  store %"compiler/check:roArg" %t126, ptr %l71
  br label %bb29
bb29:
  %t127 = load ptr, ptr %l60, !tbaa !29
  %t128 = load %"compiler/check:roArg", ptr %l71
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aroArg_3e_2ePush_3ccompiler_2fcheck_3aroArg_3e(ptr %v0, ptr %v0, ptr %t127, %"compiler/check:roArg" %t128)
  br label %bb30
bb30:
  br label %ret
bb31:
  %t129 = load ptr, ptr %l3, !tbaa !29
  store ptr %t129, ptr %l72, !tbaa !29
  store i1 false, ptr %l73, !tbaa !21
  %t130 = load ptr, ptr %l72, !tbaa !29
  %t131 = icmp ne ptr %t130, null
  br i1 %t131, label %bb32, label %bb33
bb32:
  %t133 = load ptr, ptr %l72, !tbaa !29
  %t134 = load i64, ptr %t133
  %t136 = icmp eq i64 %t134, 3
  store i1 %t136, ptr %l73, !tbaa !21
  br label %bb33
bb33:
  %t137 = load i1, ptr %l73, !tbaa !21
  br i1 %t137, label %bb34, label %bb35
bb34:
  %t138 = load ptr, ptr %l3, !tbaa !29
  %t140 = getelementptr { i64, [5 x i64] }, ptr %t138, i32 0, i32 1
  %t141 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t140, i32 0, i32 2
  %t142 = load ptr, ptr %t141
  store ptr %t142, ptr %l8, !tbaa !29
  br label %bb36
bb35:
  br label %bb45
bb36:
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t145 = load ptr, ptr %l8, !tbaa !29
  %t149 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparamOf(ptr %v0, ptr %v1, ptr %t144, ptr %t145)
  store i64 %t149, ptr %l81
  br label %bb37
bb37:
  %t150 = load i64, ptr %l81, !tbaa !24
  store i64 %t150, ptr %l9, !tbaa !24
  %t151 = load i64, ptr %l9, !tbaa !24
  %t153 = icmp sge i64 %t151, 0
  br i1 %t153, label %bb38, label %bb39
bb38:
  store %olang.scope zeroinitializer, ptr %s7
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t157 = getelementptr %"compiler/check:Checker", ptr %t155, i32 0, i32 61
  store ptr %t157, ptr %l85, !tbaa !29
  %t158 = load i64, ptr %l6, !tbaa !24
  %t159 = load i64, ptr %l9, !tbaa !24
  %t162 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s7, i64 %t158, i64 %t159)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t162, ptr %l88
  br label %bb40
bb39:
  br label %bb44
bb40:
  %t163 = load i64, ptr %l1, !tbaa !24
  %t164 = load i64, ptr %l2, !tbaa !24
  %t167 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s7, i64 %t163, i64 %t164)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t167, ptr %l91
  br label %bb41
bb41:
  %t168 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l88
  %t169 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l91
  %t170 = call %"std/pair:Pair.b139c4f75a6545712256427180a82a06" @std_2fpair_3aPair_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20std_2fpair_3aPair_3cI64_2c_20I64_3e_3e_2ector(ptr %s7, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t168, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t169)
  store %"std/pair:Pair.b139c4f75a6545712256427180a82a06" %t170, ptr %l92
  br label %bb42
bb42:
  %t171 = load ptr, ptr %l85, !tbaa !29
  %t172 = load %"std/pair:Pair.b139c4f75a6545712256427180a82a06", ptr %l92
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cstd_2fpair_3aPair__H9be680f663aa81558c844970355ca108(ptr %v0, ptr %t171, %"std/pair:Pair.b139c4f75a6545712256427180a82a06" %t172)
  br label %bb43
bb43:
  call void @__olang_scope_close(ptr %s7)
  br label %bb44
bb44:
  br label %bb46
bb45:
  br label %bb46
bb46:
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t174 = load i64, ptr %l6, !tbaa !24
  %t177 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstanceBody(ptr %v0, ptr %t173, i64 %t174)
  store i1 %t177, ptr %l95
  br label %bb47
bb47:
  %t178 = load i1, ptr %l95, !tbaa !21
  br i1 %t178, label %bb48, label %bb49
bb48:
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t181 = getelementptr %"compiler/check:Checker", ptr %t179, i32 0, i32 68
  store ptr %t181, ptr %l97, !tbaa !29
  %t182 = load i64, ptr %l6, !tbaa !24
  %t183 = load ptr, ptr %l3, !tbaa !29
  %t184 = load i64, ptr %l1, !tbaa !24
  %t185 = load i64, ptr %l2, !tbaa !24
  %t190 = call %"compiler/check:roDeepArg" @compiler_2fcheck_3aroDeepArg_2ector(ptr %v1, ptr %v0, i64 %t182, ptr %t183, i64 %t184, i64 %t185)
  store %"compiler/check:roDeepArg" %t190, ptr %l102
  br label %bb50
bb49:
  br label %bb52
bb50:
  %t191 = load ptr, ptr %l97, !tbaa !29
  %t192 = load %"compiler/check:roDeepArg", ptr %l102
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aroDeepArg_3e_2ePush_H0e30e0389c54f9bfc05db61d637e277e(ptr %v0, ptr %v0, ptr %t191, %"compiler/check:roDeepArg" %t192)
  br label %bb51
bb51:
  br label %bb52
bb52:
  br label %ret
bb53:
  %t193 = load ptr, ptr %l0, !tbaa !29
  store ptr %t193, ptr %l103, !tbaa !29
  %t194 = load ptr, ptr %l3, !tbaa !29
  %t197 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t194)
  store i32 %t197, ptr %l106
  br label %bb54
bb54:
  %t198 = load ptr, ptr %l103, !tbaa !29
  %t199 = load i32, ptr %l106, !tbaa !23
  %t200 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsWritable(ptr %v0, ptr %t198, i32 %t199)
  store i1 %t200, ptr %l107
  br label %bb55
bb55:
  %t201 = load i1, ptr %l107, !tbaa !21
  %t202 = xor i1 %t201, true
  br i1 %t202, label %bb56, label %bb57
bb56:
  br label %ret
bb57:
  br label %bb58
bb58:
  %t204 = load ptr, ptr %l0, !tbaa !29
  %t205 = load ptr, ptr %l3, !tbaa !29
  %t209 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroValue(ptr %v0, ptr %v1, ptr %t204, ptr %t205)
  store i1 %t209, ptr %l112
  br label %bb59
bb59:
  %t210 = load i1, ptr %l112, !tbaa !21
  br i1 %t210, label %bb60, label %bb61
bb60:
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t213 = getelementptr %"compiler/check:Checker", ptr %t211, i32 0, i32 62
  store ptr %t213, ptr %l114, !tbaa !29
  %t214 = load i64, ptr %l1, !tbaa !24
  store i64 %t214, ptr %l115, !tbaa !24
  %t215 = load i64, ptr %l2, !tbaa !24
  store i64 %t215, ptr %l116, !tbaa !24
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t217 = load %"compiler/source:Span", ptr %l4
  %t220 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %t216, %"compiler/source:Span" %t217)
  store { i64, [3 x i64] } %t220, ptr %l119
  br label %bb62
bb61:
  br label %bb70
bb62:
  %t221 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t221, ptr %l120, !tbaa !27
  %t222 = load ptr, ptr %l0, !tbaa !29
  store ptr %t222, ptr %l121, !tbaa !29
  %t223 = load ptr, ptr %l3, !tbaa !29
  %t226 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t223)
  store i32 %t226, ptr %l124
  br label %bb63
bb63:
  %t227 = load ptr, ptr %l121, !tbaa !29
  %t228 = load i32, ptr %l124, !tbaa !23
  %t229 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v0, ptr %t227, i32 %t228)
  store { i64, ptr } %t229, ptr %l125
  br label %bb64
bb64:
  %t230 = load { i64, ptr }, ptr %l125, !tbaa !27
  %t231 = extractvalue { i64, ptr } %t230, 0
  %t232 = extractvalue { i64, ptr } %t230, 1
  %t233 = mul i64 %t231, 1
  %t234 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t233)
  call void @llvm.memcpy.p0.p0.i64(ptr %t234, ptr %t232, i64 %t233, i1 false)
  %t235 = insertvalue { i64, ptr } undef, i64 %t231, 0
  %t236 = insertvalue { i64, ptr } %t235, ptr %t234, 1
  store { i64, ptr } %t236, ptr %l126, !tbaa !27
  %t237 = load ptr, ptr %l0, !tbaa !29
  store ptr %t237, ptr %l127, !tbaa !29
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t239 = load ptr, ptr %l3, !tbaa !29
  %t242 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroName(ptr %v0, ptr %v1, ptr %t238, ptr %t239)
  store i32 %t242, ptr %l130
  br label %bb65
bb65:
  %t243 = load ptr, ptr %l3, !tbaa !29
  %t246 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t243)
  store i32 %t246, ptr %l133
  br label %bb66
bb66:
  %t247 = load ptr, ptr %l127, !tbaa !29
  %t248 = load i32, ptr %l130, !tbaa !23
  %t249 = load i32, ptr %l133, !tbaa !23
  %t250 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroFix(ptr %v0, ptr %v0, ptr %t247, i32 %t248, i32 %t249)
  store { i64, ptr } %t250, ptr %l134
  br label %bb67
bb67:
  %t251 = load { i64, ptr }, ptr %l134, !tbaa !27
  %t252 = extractvalue { i64, ptr } %t251, 0
  %t253 = extractvalue { i64, ptr } %t251, 1
  %t254 = mul i64 %t252, 1
  %t255 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t254)
  call void @llvm.memcpy.p0.p0.i64(ptr %t255, ptr %t253, i64 %t254, i1 false)
  %t256 = insertvalue { i64, ptr } undef, i64 %t252, 0
  %t257 = insertvalue { i64, ptr } %t256, ptr %t255, 1
  %t258 = load i64, ptr %l115, !tbaa !24
  %t259 = load i64, ptr %l116, !tbaa !24
  %t260 = load { i64, [3 x i64] }, ptr %l119
  %t261 = load { i64, ptr }, ptr %l120, !tbaa !27
  %t262 = load { i64, ptr }, ptr %l126, !tbaa !27
  %t264 = call %"compiler/check:roArg" @compiler_2fcheck_3aroArg_2ector(ptr %v2, ptr %v0, ptr %v0, ptr %v0, i64 %t258, i64 %t259, { i64, [3 x i64] } %t260, { i64, ptr } %t261, { i64, ptr } %t262, { i64, ptr } %t257)
  store %"compiler/check:roArg" %t264, ptr %l136
  br label %bb68
bb68:
  %t265 = load ptr, ptr %l114, !tbaa !29
  %t266 = load %"compiler/check:roArg", ptr %l136
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aroArg_3e_2ePush_3ccompiler_2fcheck_3aroArg_3e(ptr %v0, ptr %v0, ptr %t265, %"compiler/check:roArg" %t266)
  br label %bb69
bb69:
  br label %ret
bb70:
  %t267 = load ptr, ptr %l0, !tbaa !29
  store ptr %t267, ptr %l137, !tbaa !29
  %t268 = load ptr, ptr %l3, !tbaa !29
  %t270 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v1, ptr %t268)
  store ptr %t270, ptr %l139
  br label %bb71
bb71:
  %t271 = load ptr, ptr %l137, !tbaa !29
  %t272 = load ptr, ptr %l139, !tbaa !29
  %t273 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparamOf(ptr %v0, ptr %v1, ptr %t271, ptr %t272)
  store i64 %t273, ptr %l140
  br label %bb72
bb72:
  %t274 = load i64, ptr %l140, !tbaa !24
  store i64 %t274, ptr %l10, !tbaa !24
  %t275 = load i64, ptr %l10, !tbaa !24
  %t277 = icmp sge i64 %t275, 0
  br i1 %t277, label %bb73, label %bb74
bb73:
  store %olang.scope zeroinitializer, ptr %s12
  %t279 = load ptr, ptr %l0, !tbaa !29
  %t281 = getelementptr %"compiler/check:Checker", ptr %t279, i32 0, i32 61
  store ptr %t281, ptr %l144, !tbaa !29
  %t282 = load i64, ptr %l6, !tbaa !24
  %t283 = load i64, ptr %l10, !tbaa !24
  %t286 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s12, i64 %t282, i64 %t283)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t286, ptr %l147
  br label %bb75
bb74:
  br label %bb79
bb75:
  %t287 = load i64, ptr %l1, !tbaa !24
  %t288 = load i64, ptr %l2, !tbaa !24
  %t291 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s12, i64 %t287, i64 %t288)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t291, ptr %l150
  br label %bb76
bb76:
  %t292 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l147
  %t293 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l150
  %t294 = call %"std/pair:Pair.b139c4f75a6545712256427180a82a06" @std_2fpair_3aPair_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20std_2fpair_3aPair_3cI64_2c_20I64_3e_3e_2ector(ptr %s12, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t292, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t293)
  store %"std/pair:Pair.b139c4f75a6545712256427180a82a06" %t294, ptr %l151
  br label %bb77
bb77:
  %t295 = load ptr, ptr %l144, !tbaa !29
  %t296 = load %"std/pair:Pair.b139c4f75a6545712256427180a82a06", ptr %l151
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cstd_2fpair_3aPair__H9be680f663aa81558c844970355ca108(ptr %v0, ptr %t295, %"std/pair:Pair.b139c4f75a6545712256427180a82a06" %t296)
  br label %bb78
bb78:
  call void @__olang_scope_close(ptr %s12)
  br label %bb79
bb79:
  %t297 = load ptr, ptr %l0, !tbaa !29
  %t298 = load i64, ptr %l6, !tbaa !24
  %t301 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstanceBody(ptr %v0, ptr %t297, i64 %t298)
  store i1 %t301, ptr %l154
  br label %bb80
bb80:
  %t302 = load i1, ptr %l154, !tbaa !21
  br i1 %t302, label %bb81, label %bb82
bb81:
  %t303 = load ptr, ptr %l0, !tbaa !29
  %t305 = getelementptr %"compiler/check:Checker", ptr %t303, i32 0, i32 68
  store ptr %t305, ptr %l156, !tbaa !29
  %t306 = load i64, ptr %l6, !tbaa !24
  %t307 = load ptr, ptr %l3, !tbaa !29
  %t308 = load i64, ptr %l1, !tbaa !24
  %t309 = load i64, ptr %l2, !tbaa !24
  %t314 = call %"compiler/check:roDeepArg" @compiler_2fcheck_3aroDeepArg_2ector(ptr %v1, ptr %v0, i64 %t306, ptr %t307, i64 %t308, i64 %t309)
  store %"compiler/check:roDeepArg" %t314, ptr %l161
  br label %bb83
bb82:
  br label %bb85
bb83:
  %t315 = load ptr, ptr %l156, !tbaa !29
  %t316 = load %"compiler/check:roDeepArg", ptr %l161
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aroDeepArg_3e_2ePush_H0e30e0389c54f9bfc05db61d637e277e(ptr %v0, ptr %v0, ptr %t315, %"compiler/check:roDeepArg" %t316)
  br label %bb84
bb84:
  br label %bb85
bb85:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroCallCopy(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l13 = alloca i64
  %l23 = alloca i64
  %l26 = alloca i64
  %l45 = alloca { i64, ptr }
  %l48 = alloca ptr
  %l51 = alloca i32
  %l52 = alloca i1
  %l53 = alloca i1
  %l57 = alloca i1
  %l58 = alloca i1
  %l62 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t4 = getelementptr %"compiler/typed:Call", ptr %t2, i32 0, i32 0
  %t5 = load ptr, ptr %t4, !tbaa !29
  %t8 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyOfCallee(ptr %v0, ptr %v1, ptr %t1, ptr %t5)
  store i64 %t8, ptr %l13
  br label %bb1
bb1:
  %t9 = load i64, ptr %l13, !tbaa !24
  store i64 %t9, ptr %l2, !tbaa !24
  %t10 = load i64, ptr %l2, !tbaa !24
  %t12 = icmp slt i64 %t10, 0
  br i1 %t12, label %bb2, label %bb3
bb2:
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  store i64 0, ptr %l3, !tbaa !24
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr %"compiler/typed:Call", ptr %t15, i32 0, i32 1
  %t18 = load { i64, ptr }, ptr %t17, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t18, 0
  store i64 %t20, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t22 = load i64, ptr %l4, !tbaa !24
  %t23 = load i64, ptr %l3, !tbaa !24
  %t26 = icmp sgt i64 %t22, %t23
  br i1 %t26, label %bb5, label %bb6
bb5:
  %t28 = load i64, ptr %l5, !tbaa !24
  %t30 = icmp sgt i64 %t28, 0
  br i1 %t30, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb10
bb7:
  %t32 = load i64, ptr %l4, !tbaa !24
  %t33 = load i64, ptr %l3, !tbaa !24
  %t36 = sub i64 %t32, %t33
  %t37 = load i64, ptr %l5, !tbaa !24
  %t40 = add i64 %t36, %t37
  %t42 = sub i64 %t40, 1
  %t43 = load i64, ptr %l5, !tbaa !24
  %t46 = sdiv i64 %t42, %t43
  store i64 %t46, ptr %l26, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l26, !tbaa !24
  br label %bb9
bb9:
  %t48 = load i64, ptr %l26, !tbaa !24
  store i64 %t48, ptr %l23, !tbaa !24
  br label %bb10
bb10:
  %t49 = load i64, ptr %l23, !tbaa !24
  store i64 %t49, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb11
bb11:
  %t50 = load i64, ptr %l7, !tbaa !24
  %t51 = load i64, ptr %l6, !tbaa !24
  %t54 = icmp slt i64 %t50, %t51
  %t56 = xor i1 %t54, true
  br i1 %t56, label %bb12, label %bb13
bb12:
  br label %bb29
bb13:
  br label %bb14
bb14:
  %t58 = load i64, ptr %l3, !tbaa !24
  %t59 = load i64, ptr %l7, !tbaa !24
  %t60 = load i64, ptr %l5, !tbaa !24
  %t63 = mul i64 %t59, %t60
  %t66 = add i64 %t58, %t63
  store i64 %t66, ptr %l8, !tbaa !24
  %t68 = load ptr, ptr %l1, !tbaa !29
  %t70 = getelementptr %"compiler/typed:Call", ptr %t68, i32 0, i32 1
  %t71 = load { i64, ptr }, ptr %t70, !tbaa !27
  store { i64, ptr } %t71, ptr %l45, !tbaa !27
  %t72 = load i64, ptr %l8, !tbaa !24
  %t74 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t75 = load ptr, ptr %t74, !tbaa !27
  %t76 = getelementptr ptr, ptr %t75, i64 %t72
  %t77 = load ptr, ptr %t76, !tbaa !39
  store ptr %t77, ptr %l9, !tbaa !29
  %t79 = load ptr, ptr %l0, !tbaa !29
  store ptr %t79, ptr %l48, !tbaa !29
  %t80 = load ptr, ptr %l9, !tbaa !29
  %t83 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t80)
  store i32 %t83, ptr %l51
  br label %bb15
bb15:
  %t84 = load ptr, ptr %l48, !tbaa !29
  %t85 = load i32, ptr %l51, !tbaa !23
  %t86 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t84, i32 %t85)
  store i1 %t86, ptr %l52
  br label %bb16
bb16:
  %t87 = load i1, ptr %l52, !tbaa !21
  br i1 %t87, label %bb17, label %bb18
bb17:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t89 = load i64, ptr %l2, !tbaa !24
  %t90 = load i64, ptr %l8, !tbaa !24
  %t94 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroFollows(ptr %v0, ptr %t88, i64 %t89, i64 %t90)
  store i1 %t94, ptr %l57
  br label %bb19
bb18:
  store i1 false, ptr %l53, !tbaa !21
  br label %bb20
bb19:
  %t95 = load i1, ptr %l57, !tbaa !21
  store i1 %t95, ptr %l53, !tbaa !21
  br label %bb20
bb20:
  %t96 = load i1, ptr %l53, !tbaa !21
  br i1 %t96, label %bb21, label %bb22
bb21:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t98 = load ptr, ptr %l9, !tbaa !29
  %t102 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroRef(ptr %v0, ptr %v1, ptr %t97, ptr %t98)
  store i1 %t102, ptr %l62
  br label %bb23
bb22:
  store i1 false, ptr %l58, !tbaa !21
  br label %bb24
bb23:
  %t103 = load i1, ptr %l62, !tbaa !21
  store i1 %t103, ptr %l58, !tbaa !21
  br label %bb24
bb24:
  %t104 = load i1, ptr %l58, !tbaa !21
  br i1 %t104, label %bb25, label %bb26
bb25:
  store i1 true, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  br label %bb28
bb28:
  %t106 = load i64, ptr %l7, !tbaa !24
  %t108 = add i64 %t106, 1
  store i64 %t108, ptr %l7, !tbaa !24
  br label %bb11
bb29:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroCheckCallee(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l13 = alloca i64
  %l16 = alloca i1
  %l20 = alloca i64
  %l22 = alloca i1
  %l25 = alloca i1
  %l29 = alloca i1
  %l31 = alloca i1
  %l34 = alloca i1
  %l38 = alloca ptr
  %l41 = alloca ptr
  %l45 = alloca ptr
  %l48 = alloca i32
  %l49 = alloca { i64, ptr }
  %l55 = alloca i64
  %l58 = alloca i64
  %l79 = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyOfCallee(ptr %v0, ptr %v1, ptr %t1, ptr %a1)
  store i64 %t5, ptr %l13
  br label %bb1
bb1:
  %t6 = load i64, ptr %l13, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t9 = icmp slt i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb5
bb3:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/check:Checker", ptr %t11, i32 0, i32 16
  %t14 = load i64, ptr %l3, !tbaa !24
  %t17 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t13, i64 %t14)
  store i64 %t17, ptr %l20
  br label %bb4
bb4:
  %t18 = load i64, ptr %l20, !tbaa !24
  %t19 = icmp ne i64 %t18, 0
  store i1 %t19, ptr %l16, !tbaa !21
  br label %bb5
bb5:
  %t21 = load i1, ptr %l16, !tbaa !21
  br i1 %t21, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l22, !tbaa !21
  br label %bb9
bb7:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load i64, ptr %l3, !tbaa !24
  %t26 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstanceBody(ptr %v0, ptr %t22, i64 %t23)
  store i1 %t26, ptr %l25
  br label %bb8
bb8:
  %t27 = load i1, ptr %l25, !tbaa !21
  %t28 = xor i1 %t27, true
  store i1 %t28, ptr %l22, !tbaa !21
  br label %bb9
bb9:
  %t30 = load i1, ptr %l22, !tbaa !21
  br i1 %t30, label %bb10, label %bb11
bb10:
  br label %ret
bb11:
  br label %bb12
bb12:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load i32, ptr %l2, !tbaa !23
  %t35 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t31, i32 %t32)
  store i1 %t35, ptr %l29
  br label %bb13
bb13:
  %t36 = load i1, ptr %l29, !tbaa !21
  %t37 = xor i1 %t36, true
  br i1 %t37, label %bb14, label %bb15
bb14:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load i32, ptr %l2, !tbaa !23
  %t43 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsWritable(ptr %v0, ptr %t39, i32 %t40)
  store i1 %t43, ptr %l34
  br label %bb16
bb15:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb17
bb16:
  %t44 = load i1, ptr %l34, !tbaa !21
  %t45 = xor i1 %t44, true
  store i1 %t45, ptr %l31, !tbaa !21
  br label %bb17
bb17:
  %t47 = load i1, ptr %l31, !tbaa !21
  br i1 %t47, label %bb18, label %bb19
bb18:
  br label %ret
bb19:
  br label %bb20
bb20:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/check:Checker", ptr %t48, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !29
  %t53 = getelementptr %"compiler/generic:Program", ptr %t51, i32 0, i32 2
  store ptr %t53, ptr %l38, !tbaa !29
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/check:Checker", ptr %t54, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !29
  %t59 = getelementptr %"compiler/generic:Program", ptr %t57, i32 0, i32 2
  store ptr %t59, ptr %l41, !tbaa !29
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/check:Checker", ptr %t60, i32 0, i32 11
  %t63 = load i64, ptr %l3, !tbaa !24
  %t66 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t62, i64 %t63)
  store ptr %t66, ptr %l45
  br label %bb21
bb21:
  %t67 = load ptr, ptr %l45, !tbaa !29
  %t69 = getelementptr %"compiler/typed:Body", ptr %t67, i32 0, i32 2
  %t70 = load i32, ptr %t69, !tbaa !23
  %t71 = load ptr, ptr %l41, !tbaa !29
  %t73 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t71, i32 %t70)
  store i32 %t73, ptr %l48
  br label %bb22
bb22:
  %t74 = load ptr, ptr %l38, !tbaa !29
  %t75 = load i32, ptr %l48, !tbaa !23
  %t76 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t74, i32 %t75)
  store { i64, ptr } %t76, ptr %l49
  br label %bb23
bb23:
  %t77 = load { i64, ptr }, ptr %l49, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t80 = extractvalue { i64, ptr } %t77, 0
  store i64 %t80, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t82 = load i64, ptr %l6, !tbaa !24
  %t83 = load i64, ptr %l5, !tbaa !24
  %t86 = icmp sgt i64 %t82, %t83
  br i1 %t86, label %bb24, label %bb25
bb24:
  %t88 = load i64, ptr %l7, !tbaa !24
  %t90 = icmp sgt i64 %t88, 0
  br i1 %t90, label %bb26, label %bb27
bb25:
  store i64 0, ptr %l55, !tbaa !24
  br label %bb29
bb26:
  %t92 = load i64, ptr %l6, !tbaa !24
  %t93 = load i64, ptr %l5, !tbaa !24
  %t96 = sub i64 %t92, %t93
  %t97 = load i64, ptr %l7, !tbaa !24
  %t100 = add i64 %t96, %t97
  %t102 = sub i64 %t100, 1
  %t103 = load i64, ptr %l7, !tbaa !24
  %t106 = sdiv i64 %t102, %t103
  store i64 %t106, ptr %l58, !tbaa !24
  br label %bb28
bb27:
  store i64 0, ptr %l58, !tbaa !24
  br label %bb28
bb28:
  %t108 = load i64, ptr %l58, !tbaa !24
  store i64 %t108, ptr %l55, !tbaa !24
  br label %bb29
bb29:
  %t109 = load i64, ptr %l55, !tbaa !24
  store i64 %t109, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb30
bb30:
  %t110 = load i64, ptr %l9, !tbaa !24
  %t111 = load i64, ptr %l8, !tbaa !24
  %t114 = icmp slt i64 %t110, %t111
  %t116 = xor i1 %t114, true
  br i1 %t116, label %bb31, label %bb32
bb31:
  br label %bb40
bb32:
  br label %bb33
bb33:
  %t118 = load i64, ptr %l5, !tbaa !24
  %t119 = load i64, ptr %l9, !tbaa !24
  %t120 = load i64, ptr %l7, !tbaa !24
  %t123 = mul i64 %t119, %t120
  %t126 = add i64 %t118, %t123
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t129 = load i64, ptr %l3, !tbaa !24
  %t134 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroByArg(ptr %v0, ptr %t128, i64 %t129, i64 %t126)
  store i1 %t134, ptr %l79
  br label %bb34
bb34:
  %t135 = load i1, ptr %l79, !tbaa !21
  br i1 %t135, label %bb35, label %bb36
bb35:
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t137 = load i64, ptr %l3, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echeckNow(ptr %v0, ptr %t136, i64 %t137)
  br label %bb37
bb36:
  br label %bb38
bb37:
  br label %ret
bb38:
  br label %bb39
bb39:
  %t140 = load i64, ptr %l9, !tbaa !24
  %t142 = add i64 %t140, 1
  store i64 %t142, ptr %l9, !tbaa !24
  br label %bb30
bb40:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroLend(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l6 = alloca i1
  %l7 = alloca ptr
  %l11 = alloca %"compiler/source:Span"
  %l12 = alloca ptr
  %l15 = alloca i32
  %l18 = alloca i32
  %l19 = alloca { i64, ptr }
  %l21 = alloca %"compiler/msgs:Msg"
  %l22 = alloca i64
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t6 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroValue(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  store i1 %t6, ptr %l6
  br label %bb1
bb1:
  %t7 = load i1, ptr %l6, !tbaa !21
  br i1 %t7, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t8 = load ptr, ptr %l0, !tbaa !29
  store ptr %t8, ptr %l7, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t15 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroCallAt(ptr %v0, ptr %v1, ptr %t9, ptr %t10, %"compiler/source:Span" %a2)
  store %"compiler/source:Span" %t15, ptr %l11
  br label %bb4
bb3:
  br label %bb10
bb4:
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l12, !tbaa !29
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t18 = load ptr, ptr %l1, !tbaa !29
  %t21 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroName(ptr %v0, ptr %v1, ptr %t17, ptr %t18)
  store i32 %t21, ptr %l15
  br label %bb5
bb5:
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t25 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t22)
  store i32 %t25, ptr %l18
  br label %bb6
bb6:
  %t26 = load ptr, ptr %l12, !tbaa !29
  %t27 = load i32, ptr %l15, !tbaa !23
  %t28 = load i32, ptr %l18, !tbaa !23
  %t29 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroFix(ptr %v0, ptr %s1, ptr %t26, i32 %t27, i32 %t28)
  store { i64, ptr } %t29, ptr %l19
  br label %bb7
bb7:
  %t30 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t31 = extractvalue { i64, ptr } %t30, 0
  %t32 = extractvalue { i64, ptr } %t30, 1
  %t33 = mul i64 %t31, 1
  %t34 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t33)
  call void @llvm.memcpy.p0.p0.i64(ptr %t34, ptr %t32, i64 %t33, i1 false)
  %t35 = insertvalue { i64, ptr } undef, i64 %t31, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr %t34, 1
  %t38 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eReadOnlyCopyLent(ptr %s1, ptr %s1, { i64, ptr } %t36)
  store %"compiler/msgs:Msg" %t38, ptr %l21
  br label %bb8
bb8:
  %t39 = load ptr, ptr %l7, !tbaa !29
  %t40 = load %"compiler/source:Span", ptr %l11
  %t41 = load %"compiler/msgs:Msg", ptr %l21
  %t42 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s1, ptr %t39, %"compiler/source:Span" %t40, %"compiler/msgs:Msg" %t41)
  store i64 %t42, ptr %l22
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s1)
  br label %ret
bb10:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroDeepNeed(ptr %v0, ptr %v1, ptr %t43, ptr %t44)
  br label %bb11
bb11:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroLet(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l6 = alloca i1
  %l8 = alloca ptr
  %l11 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l14 = alloca i32
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t6 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroValue(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  store i1 %t6, ptr %l6
  br label %bb1
bb1:
  %t7 = load i1, ptr %l6, !tbaa !21
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/check:Checker", ptr %t8, i32 0, i32 57
  store ptr %t10, ptr %l8, !tbaa !29
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load i64, ptr %l1, !tbaa !24
  %t15 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroKey(ptr %v0, ptr %t11, i64 %t12)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t15, ptr %l11
  br label %bb4
bb3:
  br label %bb7
bb4:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t20 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroName(ptr %v0, ptr %v1, ptr %t16, ptr %t17)
  store i32 %t20, ptr %l14
  br label %bb5
bb5:
  %t21 = load ptr, ptr %l8, !tbaa !29
  %t22 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l11
  %t23 = load i32, ptr %l14, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_Hc59e30334647acda8fe9b2b02a632dfd(ptr %v0, ptr %t21, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t22, i32 %t23)
  br label %bb6
bb6:
  br label %bb7
bb7:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load i64, ptr %l1, !tbaa !24
  %t26 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroTrack(ptr %v0, ptr %v1, ptr %t24, i64 %t25, ptr %t26)
  br label %bb8
bb8:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroResult(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l4 = alloca i1
  %l5 = alloca ptr
  %l7 = alloca ptr
  %l10 = alloca i1
  %l12 = alloca i1
  %l13 = alloca ptr
  %l16 = alloca i32
  %l17 = alloca i1
  %l20 = alloca ptr
  %l22 = alloca ptr
  %l26 = alloca %"std/pair:Pair.1eb2466213689e002f25e81e83536e78"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l4, !tbaa !21
  br label %bb5
bb2:
  %t5 = load ptr, ptr %l0, !tbaa !29
  store ptr %t5, ptr %l5, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t6)
  store ptr %t8, ptr %l7
  br label %bb3
bb3:
  %t9 = load ptr, ptr %l7, !tbaa !29
  %t11 = getelementptr %"compiler/check:frame", ptr %t9, i32 0, i32 0
  %t12 = load i64, ptr %t11, !tbaa !24
  %t13 = load ptr, ptr %l5, !tbaa !29
  %t15 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstanceBody(ptr %v0, ptr %t13, i64 %t12)
  store i1 %t15, ptr %l10
  br label %bb4
bb4:
  %t16 = load i1, ptr %l10, !tbaa !21
  %t17 = xor i1 %t16, true
  store i1 %t17, ptr %l4, !tbaa !21
  br label %bb5
bb5:
  %t19 = load i1, ptr %l4, !tbaa !21
  br i1 %t19, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb10
bb7:
  %t20 = load ptr, ptr %l0, !tbaa !29
  store ptr %t20, ptr %l13, !tbaa !29
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t24 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t21)
  store i32 %t24, ptr %l16
  br label %bb8
bb8:
  %t25 = load ptr, ptr %l13, !tbaa !29
  %t26 = load i32, ptr %l16, !tbaa !23
  %t27 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsWritable(ptr %v0, ptr %t25, i32 %t26)
  store i1 %t27, ptr %l17
  br label %bb9
bb9:
  %t28 = load i1, ptr %l17, !tbaa !21
  %t29 = xor i1 %t28, true
  store i1 %t29, ptr %l12, !tbaa !21
  br label %bb10
bb10:
  %t31 = load i1, ptr %l12, !tbaa !21
  br i1 %t31, label %bb11, label %bb12
bb11:
  br label %ret
bb12:
  br label %bb13
bb13:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/check:Checker", ptr %t32, i32 0, i32 66
  store ptr %t34, ptr %l20, !tbaa !29
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t35)
  store ptr %t37, ptr %l22
  br label %bb14
bb14:
  %t38 = load ptr, ptr %l22, !tbaa !29
  %t40 = getelementptr %"compiler/check:frame", ptr %t38, i32 0, i32 0
  %t41 = load i64, ptr %t40, !tbaa !24
  %t42 = load ptr, ptr %l1, !tbaa !29
  %t45 = call %"std/pair:Pair.1eb2466213689e002f25e81e83536e78" @std_2fpair_3aPair_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_2ector(ptr %v1, ptr %v0, i64 %t41, ptr %t42)
  store %"std/pair:Pair.1eb2466213689e002f25e81e83536e78" %t45, ptr %l26
  br label %bb15
bb15:
  %t46 = load ptr, ptr %l20, !tbaa !29
  %t47 = load %"std/pair:Pair.1eb2466213689e002f25e81e83536e78", ptr %l26
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20compiler__H316d0dfdbceeb7b188a6719f0ad8fbbe(ptr %v0, ptr %v0, ptr %t46, %"std/pair:Pair.1eb2466213689e002f25e81e83536e78" %t47)
  br label %bb16
bb16:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroRoot(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l5 = alloca i64
  %l8 = alloca i1
  %l11 = alloca i1
  %l12 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erootLocal(ptr %v0, ptr %v1, ptr %t1, ptr %a1)
  store i64 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i64, ptr %l5, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load i64, ptr %l2, !tbaa !24
  %t9 = icmp sge i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load i64, ptr %l2, !tbaa !24
  %t15 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroLocal(ptr %v0, ptr %t11, i64 %t12)
  store i1 %t15, ptr %l11
  br label %bb4
bb3:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb5
bb4:
  %t16 = load i1, ptr %l11, !tbaa !21
  store i1 %t16, ptr %l8, !tbaa !21
  br label %bb5
bb5:
  %t17 = load i1, ptr %l8, !tbaa !21
  br i1 %t17, label %bb6, label %bb7
bb6:
  %t18 = load i64, ptr %l2, !tbaa !24
  store i64 %t18, ptr %l12, !tbaa !24
  br label %bb8
bb7:
  store i64 -1, ptr %l12, !tbaa !24
  br label %bb8
bb8:
  %t20 = load i64, ptr %l12, !tbaa !24
  store i64 %t20, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroStore(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca %"compiler/msgs:Msg"
  %l10 = alloca i1
  %l15 = alloca i1
  %l16 = alloca ptr
  %l19 = alloca i32
  %l20 = alloca i1
  %l22 = alloca ptr
  %l24 = alloca ptr
  %l34 = alloca i32
  %l35 = alloca ptr
  %l36 = alloca ptr
  %l40 = alloca i32
  %l42 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l48 = alloca %"compiler/msgs:Msg"
  %l53 = alloca { i64, ptr }
  %l56 = alloca %"compiler/msgs:Msg"
  %l61 = alloca { i64, ptr }
  %l64 = alloca %"compiler/msgs:Msg"
  %l69 = alloca { i64, ptr }
  %l72 = alloca %"compiler/msgs:Msg"
  %l76 = alloca i64
  %l77 = alloca ptr
  %l78 = alloca i64
  %l82 = alloca ptr
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t5 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroValue(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  store i1 %t5, ptr %l10
  br label %bb1
bb1:
  %t6 = load i1, ptr %l10, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load ptr, ptr %l1, !tbaa !29
  %t11 = icmp eq ptr %t9, null
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb4, label %bb5
bb3:
  br label %bb19
bb4:
  %t15 = load ptr, ptr %l0, !tbaa !29
  store ptr %t15, ptr %l16, !tbaa !29
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t19 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t16)
  store i32 %t19, ptr %l19
  br label %bb6
bb5:
  store i1 false, ptr %l15, !tbaa !21
  br label %bb8
bb6:
  %t20 = load ptr, ptr %l16, !tbaa !29
  %t21 = load i32, ptr %l19, !tbaa !23
  %t22 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t20, i32 %t21)
  store i1 %t22, ptr %l20
  br label %bb7
bb7:
  %t23 = load i1, ptr %l20, !tbaa !21
  %t24 = xor i1 %t23, true
  store i1 %t24, ptr %l15, !tbaa !21
  br label %bb8
bb8:
  %t26 = load i1, ptr %l15, !tbaa !21
  br i1 %t26, label %bb9, label %bb10
bb9:
  %t27 = load ptr, ptr %l0, !tbaa !29
  store ptr %t27, ptr %l22, !tbaa !29
  %t28 = load ptr, ptr %l1, !tbaa !29
  %t30 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v1, ptr %t28)
  store ptr %t30, ptr %l24
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t31 = load ptr, ptr %l22, !tbaa !29
  %t32 = load ptr, ptr %l24, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroNeed(ptr %v0, ptr %v1, ptr %t31, ptr %t32)
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t33 = load i64, ptr %l3, !tbaa !24
  %t34 = load i64, ptr @G_2ecompiler_2fcheck_2eRoReturned, !tbaa !24
  %t37 = icmp eq i64 %t33, %t34
  br i1 %t37, label %bb14, label %bb15
bb14:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroResult(ptr %v0, ptr %v1, ptr %t39, ptr %t40)
  br label %bb16
bb15:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroDeepNeed(ptr %v0, ptr %v1, ptr %t43, ptr %t44)
  br label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb19:
  %t48 = load ptr, ptr %l1, !tbaa !29
  %t50 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t48)
  store i32 %t50, ptr %l34
  br label %bb20
bb20:
  %t51 = load i32, ptr %l34, !tbaa !23
  store i32 %t51, ptr %l4, !tbaa !23
  %t52 = load ptr, ptr %l0, !tbaa !29
  store ptr %t52, ptr %l35, !tbaa !29
  %t53 = load ptr, ptr %l0, !tbaa !29
  store ptr %t53, ptr %l36, !tbaa !29
  %t54 = load ptr, ptr %l1, !tbaa !29
  %t56 = icmp eq ptr %t54, null
  br i1 %t56, label %bb21, label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_57dc1f8c088d198a_6c44e525bc3c6ade)
  unreachable
bb22:
  br label %bb23
bb23:
  %t58 = load ptr, ptr %l1, !tbaa !29
  %t59 = load ptr, ptr %l36, !tbaa !29
  %t61 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroName(ptr %v0, ptr %v1, ptr %t59, ptr %t58)
  store i32 %t61, ptr %l40
  br label %bb24
bb24:
  %t62 = load i32, ptr %l4, !tbaa !23
  %t63 = load ptr, ptr %l35, !tbaa !29
  %t64 = load i32, ptr %l40, !tbaa !23
  %t66 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroFix(ptr %v0, ptr %s0, ptr %t63, i32 %t64, i32 %t62)
  store { i64, ptr } %t66, ptr %l42
  br label %bb25
bb25:
  %t67 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t67, ptr %l5, !tbaa !27
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load i32, ptr %l4, !tbaa !23
  %t72 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t68, i32 %t69)
  store { i64, ptr } %t72, ptr %l45
  br label %bb26
bb26:
  %t73 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t74 = extractvalue { i64, ptr } %t73, 0
  %t75 = extractvalue { i64, ptr } %t73, 1
  %t76 = mul i64 %t74, 1
  %t77 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t76)
  call void @llvm.memcpy.p0.p0.i64(ptr %t77, ptr %t75, i64 %t76, i1 false)
  %t78 = insertvalue { i64, ptr } undef, i64 %t74, 0
  %t79 = insertvalue { i64, ptr } %t78, ptr %t77, 1
  %t80 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t83 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eReadOnlyCopyStored(ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t79, { i64, ptr } %t80)
  store %"compiler/msgs:Msg" %t83, ptr %l48
  br label %bb27
bb27:
  %t84 = load %"compiler/msgs:Msg", ptr %l48
  store %"compiler/msgs:Msg" %t84, ptr %l6
  %t85 = load i64, ptr %l3, !tbaa !24
  %t87 = icmp eq i64 %t85, 1
  br i1 %t87, label %bb28, label %bb29
bb28:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t90 = load i32, ptr %l4, !tbaa !23
  %t93 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t89, i32 %t90)
  store { i64, ptr } %t93, ptr %l53
  br label %bb30
bb29:
  br label %bb32
bb30:
  %t94 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t95 = extractvalue { i64, ptr } %t94, 0
  %t96 = extractvalue { i64, ptr } %t94, 1
  %t97 = mul i64 %t95, 1
  %t98 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t97)
  call void @llvm.memcpy.p0.p0.i64(ptr %t98, ptr %t96, i64 %t97, i1 false)
  %t99 = insertvalue { i64, ptr } undef, i64 %t95, 0
  %t100 = insertvalue { i64, ptr } %t99, ptr %t98, 1
  %t101 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t104 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eReadOnlyCopyDecl(ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t100, { i64, ptr } %t101)
  store %"compiler/msgs:Msg" %t104, ptr %l56
  br label %bb31
bb31:
  %t105 = load %"compiler/msgs:Msg", ptr %l56
  store %"compiler/msgs:Msg" %t105, ptr %l6
  br label %bb32
bb32:
  %t106 = load i64, ptr %l3, !tbaa !24
  %t108 = icmp eq i64 %t106, 2
  br i1 %t108, label %bb33, label %bb34
bb33:
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t111 = load i32, ptr %l4, !tbaa !23
  %t114 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t110, i32 %t111)
  store { i64, ptr } %t114, ptr %l61
  br label %bb35
bb34:
  br label %bb37
bb35:
  %t115 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t116 = extractvalue { i64, ptr } %t115, 0
  %t117 = extractvalue { i64, ptr } %t115, 1
  %t118 = mul i64 %t116, 1
  %t119 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t118)
  call void @llvm.memcpy.p0.p0.i64(ptr %t119, ptr %t117, i64 %t118, i1 false)
  %t120 = insertvalue { i64, ptr } undef, i64 %t116, 0
  %t121 = insertvalue { i64, ptr } %t120, ptr %t119, 1
  %t122 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t125 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eReadOnlyCopyReturned(ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t121, { i64, ptr } %t122)
  store %"compiler/msgs:Msg" %t125, ptr %l64
  br label %bb36
bb36:
  %t126 = load %"compiler/msgs:Msg", ptr %l64
  store %"compiler/msgs:Msg" %t126, ptr %l6
  br label %bb37
bb37:
  %t127 = load i64, ptr %l3, !tbaa !24
  %t129 = icmp eq i64 %t127, 3
  br i1 %t129, label %bb38, label %bb39
bb38:
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t132 = load i32, ptr %l4, !tbaa !23
  %t135 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t131, i32 %t132)
  store { i64, ptr } %t135, ptr %l69
  br label %bb40
bb39:
  br label %bb42
bb40:
  %t136 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t137 = extractvalue { i64, ptr } %t136, 0
  %t138 = extractvalue { i64, ptr } %t136, 1
  %t139 = mul i64 %t137, 1
  %t140 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t139)
  call void @llvm.memcpy.p0.p0.i64(ptr %t140, ptr %t138, i64 %t139, i1 false)
  %t141 = insertvalue { i64, ptr } undef, i64 %t137, 0
  %t142 = insertvalue { i64, ptr } %t141, ptr %t140, 1
  %t143 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t146 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eReadOnlyCopyGlobal(ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t142, { i64, ptr } %t143)
  store %"compiler/msgs:Msg" %t146, ptr %l72
  br label %bb41
bb41:
  %t147 = load %"compiler/msgs:Msg", ptr %l72
  store %"compiler/msgs:Msg" %t147, ptr %l6
  br label %bb42
bb42:
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t150 = load %"compiler/msgs:Msg", ptr %l6
  %t154 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s0, ptr %t148, %"compiler/source:Span" %a2, %"compiler/msgs:Msg" %t150)
  store i64 %t154, ptr %l76
  br label %bb43
bb43:
  %t155 = load i64, ptr %l76, !tbaa !24
  %t156 = load ptr, ptr %l0, !tbaa !29
  store ptr %t156, ptr %l77, !tbaa !29
  store i64 %t155, ptr %l78, !tbaa !24
  %t158 = load ptr, ptr %l1, !tbaa !29
  %t160 = icmp eq ptr %t158, null
  br i1 %t160, label %bb44, label %bb45
bb44:
  call void @__olang_check_failed(ptr @olang_loc_658c1f9b991d3291_83ad80e13fec4285)
  unreachable
bb45:
  br label %bb46
bb46:
  %t162 = load ptr, ptr %l1, !tbaa !29
  %t164 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v1, ptr %t162)
  store ptr %t164, ptr %l82
  br label %bb47
bb47:
  %t165 = load ptr, ptr %l77, !tbaa !29
  %t166 = load i64, ptr %l78, !tbaa !24
  %t167 = load ptr, ptr %l82, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoteRo(ptr %v0, ptr %v1, ptr %t165, i64 %t166, ptr %t167)
  br label %bb48
bb48:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetItems(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %lp2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l7 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l12 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l7
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t2, ptr %lp2
  %t3 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l7
  %t4 = load ptr, ptr %lp2
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %t4
  %t7 = getelementptr %"compiler/check:Checker", ptr %a0, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = getelementptr %"compiler/generic:Program", ptr %t8, i32 0, i32 2
  %t14 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t10, i32 %a1)
  store { i64, ptr } %t14, ptr %l12
  br label %bb2
bb2:
  %t15 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t15, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t16 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t16, 0
  store i64 %t18, ptr %l5, !tbaa !24
  br label %bb3
bb3:
  %t20 = load i64, ptr %l4, !tbaa !24
  %t21 = load i64, ptr %l5, !tbaa !24
  %t24 = icmp slt i64 %t20, %t21
  %t26 = xor i1 %t24, true
  br i1 %t26, label %bb4, label %bb5
bb4:
  br label %bb9
bb5:
  br label %bb6
bb6:
  %t28 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t28, ptr %l19, !tbaa !27
  %t29 = load i64, ptr %l4, !tbaa !24
  %t31 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = getelementptr i32, ptr %t32, i64 %t29
  %t34 = load i32, ptr %t33, !tbaa !33
  %t36 = load ptr, ptr %lp2
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v1, ptr %t36, i32 %t34)
  br label %bb7
bb7:
  br label %bb8
bb8:
  %t40 = load i64, ptr %l4, !tbaa !24
  %t42 = add i64 %t40, 1
  store i64 %t42, ptr %l4, !tbaa !24
  br label %bb3
bb9:
  %t44 = load ptr, ptr %lp2
  %t45 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t44
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t45, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eshapeErr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, { i64, ptr } %a3, %"compiler/msgs:Msg" %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l3 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l10 = alloca i64
  %l14 = alloca { i64, ptr }
  %l17 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca i64
  %l26 = alloca { i64, [3 x i64] }
  %l30 = alloca %"compiler/msgs:Msg"
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load %"compiler/source:Span", ptr %l1
  %t7 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v3, ptr %t1, %"compiler/source:Span" %t2, %"compiler/msgs:Msg" %a4)
  store i64 %t7, ptr %l10
  br label %bb1
bb1:
  %t8 = load i64, ptr %l10, !tbaa !24
  store i64 %t8, ptr %l5, !tbaa !24
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/ast:Func", ptr %a2, i32 0, i32 2
  %t13 = load i32, ptr %t12, !tbaa !23
  %t16 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t9, i32 %t13)
  store { i64, ptr } %t16, ptr %l14
  br label %bb2
bb2:
  %t17 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t17, ptr %l6, !tbaa !27
  %t18 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t19 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t22 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v2, { i64, ptr } %t18, { i64, ptr } %t19)
  store i1 %t22, ptr %l17
  br label %bb3
bb3:
  %t23 = load i1, ptr %l17, !tbaa !21
  %t24 = xor i1 %t23, true
  br i1 %t24, label %bb4, label %bb5
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/check:Checker", ptr %t26, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t31 = getelementptr %"compiler/generic:Program", ptr %t29, i32 0, i32 0
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t34 = getelementptr %"compiler/load:Loader", ptr %t32, i32 0, i32 4
  %t35 = load ptr, ptr %t34, !tbaa !29
  store ptr %t35, ptr %l22, !tbaa !29
  %t36 = load i64, ptr %l5, !tbaa !24
  store i64 %t36, ptr %l23, !tbaa !24
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load %"compiler/source:Span", ptr %l1
  %t41 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %t37, %"compiler/source:Span" %t38)
  store { i64, [3 x i64] } %t41, ptr %l26
  br label %bb6
bb5:
  br label %bb9
bb6:
  %t42 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t43 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t44 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t48 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteProtocolSpelling(ptr %v0, ptr %v2, ptr %v2, ptr %s1, { i64, ptr } %t42, { i64, ptr } %t43, { i64, ptr } %t44)
  store %"compiler/msgs:Msg" %t48, ptr %l30
  br label %bb7
bb7:
  %t49 = load ptr, ptr %l22, !tbaa !29
  %t50 = load i64, ptr %l23, !tbaa !24
  %t51 = load { i64, [3 x i64] }, ptr %l26
  %t52 = load %"compiler/msgs:Msg", ptr %l30
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %s1, ptr %t49, i64 %t50, { i64, [3 x i64] } %t51, %"compiler/msgs:Msg" %t52)
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s1)
  br label %bb9
bb9:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eshiftLit(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i1
  %l14 = alloca i1
  %l15 = alloca ptr
  %l16 = alloca i1
  %l27 = alloca i1
  %l33 = alloca %"compiler/check:litv"
  %l35 = alloca i1
  %l39 = alloca %"compiler/check:litv"
  %l44 = alloca i1
  %l45 = alloca i1
  %l49 = alloca %"compiler/check:litv"
  %l51 = alloca i1
  %l54 = alloca i1
  %l55 = alloca i1
  %l58 = alloca i1
  %l59 = alloca i1
  %l63 = alloca %"compiler/check:litv"
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t2 = load ptr, ptr %l6, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l6, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l7, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l7, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t20 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eshiftLit(ptr %v0, ptr %v1, ptr %t16, ptr %t17)
  store i1 %t20, ptr %l14
  br label %bb6
bb6:
  %t21 = load i1, ptr %l14, !tbaa !21
  store i1 %t21, ptr %rv
  br label %ret
bb7:
  %t22 = load ptr, ptr %l1, !tbaa !29
  store ptr %t22, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t23 = load ptr, ptr %l15, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t26 = load ptr, ptr %l15, !tbaa !29
  %t27 = load i64, ptr %t26
  %t29 = icmp eq i64 %t27, 5
  store i1 %t29, ptr %l16, !tbaa !21
  br label %bb9
bb9:
  %t30 = load i1, ptr %l16, !tbaa !21
  br i1 %t30, label %bb10, label %bb11
bb10:
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr { i64, [5 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t33, i32 0, i32 1
  %t35 = load i32, ptr %t34
  store i32 %t35, ptr %l3
  %t37 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr { i64, [5 x i64] }, ptr %t37, i32 0, i32 1
  %t40 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t39, i32 0, i32 2
  %t41 = load ptr, ptr %t40
  store ptr %t41, ptr %l4, !tbaa !29
  %t43 = load ptr, ptr %l1, !tbaa !29
  %t45 = getelementptr { i64, [5 x i64] }, ptr %t43, i32 0, i32 1
  %t46 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t45, i32 0, i32 3
  %t47 = load ptr, ptr %t46
  store ptr %t47, ptr %l5, !tbaa !29
  br label %bb12
bb11:
  br label %bb41
bb12:
  %t49 = load i32, ptr %l3
  %t51 = trunc i64 88 to i32
  %t52 = icmp eq i32 %t49, %t51
  br i1 %t52, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb15
bb14:
  %t54 = load i32, ptr %l3
  %t56 = trunc i64 89 to i32
  %t57 = icmp eq i32 %t54, %t56
  store i1 %t57, ptr %l27, !tbaa !21
  br label %bb15
bb15:
  %t59 = load i1, ptr %l27, !tbaa !21
  br i1 %t59, label %bb16, label %bb17
bb16:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load ptr, ptr %l4, !tbaa !29
  %t65 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %t60, ptr %t61)
  store %"compiler/check:litv" %t65, ptr %l33
  br label %bb18
bb17:
  br label %bb23
bb18:
  %t66 = getelementptr %"compiler/check:litv", ptr %l33, i32 0, i32 0
  %t67 = load i1, ptr %t66, !tbaa !21
  br i1 %t67, label %bb19, label %bb20
bb19:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load ptr, ptr %l5, !tbaa !29
  %t74 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %t69, ptr %t70)
  store %"compiler/check:litv" %t74, ptr %l39
  br label %bb21
bb20:
  store i1 false, ptr %l35, !tbaa !21
  br label %bb22
bb21:
  %t75 = getelementptr %"compiler/check:litv", ptr %l39, i32 0, i32 0
  %t76 = load i1, ptr %t75, !tbaa !21
  %t78 = xor i1 %t76, true
  store i1 %t78, ptr %l35, !tbaa !21
  br label %bb22
bb22:
  %t80 = load i1, ptr %l35, !tbaa !21
  store i1 %t80, ptr %rv
  br label %ret
bb23:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t82 = load ptr, ptr %l4, !tbaa !29
  %t85 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eshiftLit(ptr %v0, ptr %v1, ptr %t81, ptr %t82)
  store i1 %t85, ptr %l44
  br label %bb24
bb24:
  %t86 = load i1, ptr %l44, !tbaa !21
  br i1 %t86, label %bb25, label %bb26
bb25:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t88 = load ptr, ptr %l5, !tbaa !29
  %t92 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %t87, ptr %t88)
  store %"compiler/check:litv" %t92, ptr %l49
  br label %bb27
bb26:
  store i1 false, ptr %l45, !tbaa !21
  br label %bb32
bb27:
  %t93 = getelementptr %"compiler/check:litv", ptr %l49, i32 0, i32 0
  %t94 = load i1, ptr %t93, !tbaa !21
  br i1 %t94, label %bb28, label %bb29
bb28:
  store i1 true, ptr %l51, !tbaa !21
  br label %bb31
bb29:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t97 = load ptr, ptr %l5, !tbaa !29
  %t100 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eshiftLit(ptr %v0, ptr %v1, ptr %t96, ptr %t97)
  store i1 %t100, ptr %l54
  br label %bb30
bb30:
  %t101 = load i1, ptr %l54, !tbaa !21
  store i1 %t101, ptr %l51, !tbaa !21
  br label %bb31
bb31:
  %t102 = load i1, ptr %l51, !tbaa !21
  store i1 %t102, ptr %l45, !tbaa !21
  br label %bb32
bb32:
  %t103 = load i1, ptr %l45, !tbaa !21
  br i1 %t103, label %bb33, label %bb34
bb33:
  store i1 true, ptr %l55, !tbaa !21
  br label %bb40
bb34:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t105 = load ptr, ptr %l5, !tbaa !29
  %t108 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eshiftLit(ptr %v0, ptr %v1, ptr %t104, ptr %t105)
  store i1 %t108, ptr %l58
  br label %bb35
bb35:
  %t109 = load i1, ptr %l58, !tbaa !21
  br i1 %t109, label %bb36, label %bb37
bb36:
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t111 = load ptr, ptr %l4, !tbaa !29
  %t115 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %t110, ptr %t111)
  store %"compiler/check:litv" %t115, ptr %l63
  br label %bb38
bb37:
  store i1 false, ptr %l59, !tbaa !21
  br label %bb39
bb38:
  %t116 = getelementptr %"compiler/check:litv", ptr %l63, i32 0, i32 0
  %t117 = load i1, ptr %t116, !tbaa !21
  store i1 %t117, ptr %l59, !tbaa !21
  br label %bb39
bb39:
  %t119 = load i1, ptr %l59, !tbaa !21
  store i1 %t119, ptr %l55, !tbaa !21
  br label %bb40
bb40:
  %t120 = load i1, ptr %l55, !tbaa !21
  store i1 %t120, ptr %rv
  br label %ret
bb41:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etestBody(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/source:Span" %a2, { i64, ptr } %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"compiler/source:Span"
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l10 = alloca { i64, [2 x i64] }
  %l15 = alloca i32
  %l18 = alloca i64
  %l26 = alloca ptr
  %l27 = alloca ptr
  %l29 = alloca %"compiler/generic:Context"
  %l32 = alloca ptr
  %l35 = alloca i32
  %l38 = alloca ptr
  %l40 = alloca ptr
  %t3 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store { i64, [2 x i64] } zeroinitializer, ptr %t3
  %t4 = getelementptr { i64, [2 x i64] }, ptr %t3, i32 0, i32 0
  store i64 5, ptr %t4
  %t6 = insertvalue { i64 } undef, i64 %a4, 0
  %t7 = getelementptr { i64, [2 x i64] }, ptr %t3, i32 0, i32 1
  store { i64 } %t6, ptr %t7
  %t8 = load { i64, [2 x i64] }, ptr %t3
  store { i64, [2 x i64] } %t8, ptr %l10
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/check:Checker", ptr %t9, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = getelementptr %"compiler/generic:Program", ptr %t12, i32 0, i32 2
  %t15 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t18 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t14, i32 0, i32 %t15, i32 0, i32 0, i64 0)
  store i32 %t18, ptr %l15
  br label %bb1
bb1:
  %t19 = load i64, ptr %l1, !tbaa !24
  %t20 = load %"compiler/source:Span", ptr %l2
  %t21 = load ptr, ptr %l8, !tbaa !29
  %t22 = load { i64, [2 x i64] }, ptr %l10
  %t23 = load i32, ptr %l15, !tbaa !23
  %t26 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enewBody(ptr %v0, ptr %t21, { i64, [2 x i64] } %t22, i32 %t23, i64 %t19, %"compiler/source:Span" %t20)
  store i64 %t26, ptr %l18
  br label %bb2
bb2:
  %t27 = load i64, ptr %l18, !tbaa !24
  store i64 %t27, ptr %l5, !tbaa !24
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/check:Checker", ptr %t28, i32 0, i32 16
  %t31 = load i64, ptr %l5, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t30, i64 %t31, i64 1)
  br label %bb3
bb3:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load i64, ptr %l5, !tbaa !24
  %t36 = load i64, ptr %l1, !tbaa !24
  %t37 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t42 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %t34, i64 %t35, i64 %t36, i32 %t37, i32 0)
  store ptr %t42, ptr %l26
  br label %bb4
bb4:
  %t43 = load ptr, ptr %l26, !tbaa !29
  store ptr %t43, ptr %l6, !tbaa !29
  %t44 = load ptr, ptr %l6, !tbaa !29
  store ptr %t44, ptr %l27, !tbaa !29
  %t45 = load i64, ptr %l1, !tbaa !24
  %t47 = call %"compiler/generic:Context" @compiler_2fgeneric_3aContext_2ector(ptr %v0, i64 %t45, i64 -1)
  store %"compiler/generic:Context" %t47, ptr %l29
  br label %bb5
bb5:
  %t48 = load %"compiler/generic:Context", ptr %l29
  %t49 = load ptr, ptr %l27, !tbaa !29
  %t50 = getelementptr %"compiler/check:frame", ptr %t49, i32 0, i32 4
  store %"compiler/generic:Context" %t48, ptr %t50
  %t51 = load ptr, ptr %l6, !tbaa !29
  %t53 = getelementptr %"compiler/check:frame", ptr %t51, i32 0, i32 12
  store i1 true, ptr %t53, !tbaa !21
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t54)
  store ptr %t56, ptr %l32
  br label %bb6
bb6:
  %t57 = load %"compiler/source:Span", ptr %l2
  %t58 = load ptr, ptr %l32, !tbaa !29
  %t61 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddBlock(ptr %v0, ptr %t58, i32 -1, i32 0, %"compiler/source:Span" %t57)
  store i32 %t61, ptr %l35
  br label %bb7
bb7:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t66 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erootStmts(ptr %v0, ptr %v1, ptr %t62, { i64, ptr } %a3)
  store ptr %t66, ptr %l38
  br label %bb8
bb8:
  %t67 = load ptr, ptr %l38, !tbaa !29
  store ptr %t67, ptr %l7, !tbaa !29
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t68)
  store ptr %t70, ptr %l40
  br label %bb9
bb9:
  %t71 = load ptr, ptr %l40, !tbaa !29
  %t72 = load ptr, ptr %l7, !tbaa !29
  %t76 = getelementptr %"compiler/typed:Body", ptr %t71, i32 0, i32 11
  store ptr %t72, ptr %t76, !tbaa !29
  %t77 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t77)
  br label %bb10
bb10:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/check:Checker", ptr %t79, i32 0, i32 16
  %t82 = load i64, ptr %l5, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t81, i64 %t82, i64 2)
  br label %bb11
bb11:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etraitRef(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca %"compiler/names:Ref"
  %l5 = alloca ptr
  %l6 = alloca i1
  %l13 = alloca ptr
  %l19 = alloca ptr
  %l23 = alloca %"compiler/names:Ref"
  %l27 = alloca i1
  %l35 = alloca ptr
  %l40 = alloca i32
  %l41 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l3
  br label %bb5
bb4:
  br label %bb16
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/check:Checker", ptr %t16, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = getelementptr %"compiler/generic:Program", ptr %t19, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !29
  store ptr %t22, ptr %l13, !tbaa !29
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/check:Checker", ptr %t23, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t28 = getelementptr %"compiler/generic:Program", ptr %t26, i32 0, i32 0
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t31 = getelementptr %"compiler/load:Loader", ptr %t29, i32 0, i32 5
  %t35 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t31, i64 %a1)
  store ptr %t35, ptr %l19
  br label %bb6
bb6:
  %t36 = load ptr, ptr %l19, !tbaa !29
  %t38 = getelementptr %"compiler/load:Module", ptr %t36, i32 0, i32 4
  %t39 = load i64, ptr %t38, !tbaa !24
  %t40 = getelementptr %"compiler/source:Span", ptr %l3, i32 0, i32 0
  %t41 = load i32, ptr %t40, !tbaa !23
  %t42 = load ptr, ptr %l13, !tbaa !29
  %t45 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t42, i64 %t39, i32 %t41)
  store %"compiler/names:Ref" %t45, ptr %l23
  br label %bb7
bb7:
  %t46 = load %"compiler/names:Ref", ptr %l23
  store %"compiler/names:Ref" %t46, ptr %l4
  %t47 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 0
  %t48 = load i32, ptr %t47
  %t50 = trunc i64 4 to i32
  %t51 = icmp eq i32 %t48, %t50
  %t53 = xor i1 %t51, true
  br i1 %t53, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb10
bb9:
  %t55 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 2
  %t56 = load i64, ptr %t55, !tbaa !24
  %t58 = icmp slt i64 %t56, 0
  store i1 %t58, ptr %l27, !tbaa !21
  br label %bb10
bb10:
  %t60 = load i1, ptr %l27, !tbaa !21
  br i1 %t60, label %bb11, label %bb12
bb11:
  %t61 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 0
  %t62 = load i32, ptr %t61
  %t64 = trunc i64 7 to i32
  %t65 = icmp eq i32 %t62, %t64
  %t67 = xor i1 %t65, true
  store i1 %t67, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/check:Checker", ptr %t69, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !29
  %t74 = getelementptr %"compiler/generic:Program", ptr %t72, i32 0, i32 2
  store ptr %t74, ptr %l35, !tbaa !29
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/check:Checker", ptr %t75, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !29
  %t79 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 1
  %t80 = load i64, ptr %t79, !tbaa !24
  %t81 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 2
  %t82 = load i64, ptr %t81, !tbaa !24
  %t86 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %t78, i64 %t80, i64 %t82)
  store i32 %t86, ptr %l40
  br label %bb14
bb14:
  %t87 = load ptr, ptr %l35, !tbaa !29
  %t88 = load i32, ptr %l40, !tbaa !23
  %t89 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t87, i32 %t88)
  store i32 %t89, ptr %l41
  br label %bb15
bb15:
  %t90 = load i32, ptr %l41
  %t92 = trunc i64 3 to i32
  %t93 = icmp eq i32 %t90, %t92
  store i1 %t93, ptr %rv
  br label %ret
bb16:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeCase(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3, %"compiler/source:Span" %a4, ptr %a5, i32 %a6, ptr %a7) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i32
  %l8 = alloca i32
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca i64
  %l19 = alloca ptr
  %l24 = alloca i32
  %l31 = alloca ptr
  %l35 = alloca ptr
  %l36 = alloca ptr
  %l37 = alloca %"compiler/source:Span"
  %l38 = alloca i32
  %l39 = alloca i32
  %l40 = alloca ptr
  %l44 = alloca ptr
  %l46 = alloca ptr
  %l49 = alloca { i64, ptr }
  %l50 = alloca i1
  %l52 = alloca ptr
  %l53 = alloca %"compiler/source:Span"
  %l57 = alloca ptr
  %l60 = alloca ptr
  %l61 = alloca ptr
  %l62 = alloca i32
  %l63 = alloca %"compiler/source:Span"
  %l66 = alloca i32
  %l69 = alloca i64
  %l73 = alloca ptr
  %l78 = alloca %"compiler/typed:Bind"
  %s0 = alloca %olang.scope
  %rv = alloca ptr
  %t101 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a3, ptr %l3
  store ptr %a5, ptr %l5
  store i32 %a6, ptr %l6
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l6, !tbaa !23
  %t2 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t5 = icmp eq i32 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load %"compiler/source:Span", ptr %l1
  %t9 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t13 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t7, %"compiler/source:Span" %t8, i32 %t9, i64 0)
  store ptr %t13, ptr %l19
  br label %bb3
bb2:
  br label %bb4
bb3:
  call void @__olang_scope_close(ptr %s0)
  %t14 = load ptr, ptr %l19, !tbaa !29
  store ptr %t14, ptr %rv
  br label %ret
bb4:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load %"compiler/source:Span", ptr %l1
  %t17 = load i32, ptr %l6, !tbaa !23
  %t23 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyCaseType(ptr %v0, ptr %v1, ptr %t15, %"compiler/source:Span" %t16, i32 %t17, ptr %a2)
  store i32 %t23, ptr %l24
  br label %bb5
bb5:
  %t24 = load i32, ptr %l24, !tbaa !23
  store i32 %t24, ptr %l8, !tbaa !23
  %t25 = load i32, ptr %l8, !tbaa !23
  %t26 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t29 = icmp eq i32 %t25, %t26
  br i1 %t29, label %bb6, label %bb7
bb6:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load %"compiler/source:Span", ptr %l1
  %t33 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t37 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t31, %"compiler/source:Span" %t32, i32 %t33, i64 0)
  store ptr %t37, ptr %l31
  br label %bb8
bb7:
  br label %bb9
bb8:
  call void @__olang_scope_close(ptr %s0)
  %t38 = load ptr, ptr %l31, !tbaa !29
  store ptr %t38, ptr %rv
  br label %ret
bb9:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load %"compiler/source:Span", ptr %l1
  %t41 = load ptr, ptr %l5, !tbaa !29
  %t45 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t39, %"compiler/source:Span" %t40, ptr %t41)
  store ptr %t45, ptr %l35
  br label %bb10
bb10:
  %t46 = load ptr, ptr %l35, !tbaa !29
  %t47 = load ptr, ptr %l0, !tbaa !29
  store ptr %t47, ptr %l36, !tbaa !29
  %t48 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t48, ptr %l37
  %t49 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t49, ptr %l38, !tbaa !23
  store i32 42, ptr %l39
  store ptr %t46, ptr %l40, !tbaa !29
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t52 = load %"compiler/source:Span", ptr %l1
  %t53 = load i32, ptr %l8, !tbaa !23
  %t57 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t51, %"compiler/source:Span" %t52, i32 %t53, i64 0)
  store ptr %t57, ptr %l44
  br label %bb11
bb11:
  %t58 = load ptr, ptr %l44, !tbaa !29
  %t59 = load ptr, ptr %l36, !tbaa !29
  %t60 = load %"compiler/source:Span", ptr %l37
  %t61 = load i32, ptr %l38, !tbaa !23
  %t62 = load i32, ptr %l39
  %t63 = load ptr, ptr %l40, !tbaa !29
  %t65 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %t59, %"compiler/source:Span" %t60, i32 %t61, i32 %t62, ptr %t63, ptr %t58)
  store ptr %t65, ptr %l46
  br label %bb12
bb12:
  %t66 = load ptr, ptr %l46, !tbaa !29
  store ptr %t66, ptr %l10, !tbaa !29
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load i32, ptr %l3, !tbaa !23
  %t71 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t67, i32 %t68)
  store { i64, ptr } %t71, ptr %l49
  br label %bb13
bb13:
  %t72 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t73 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t72, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d47, i32 0, i32 1) })
  store i1 %t73, ptr %l50
  br label %bb14
bb14:
  %t74 = load i1, ptr %l50, !tbaa !21
  %t75 = xor i1 %t74, true
  br i1 %t75, label %bb15, label %bb16
bb15:
  %t77 = load ptr, ptr %l0, !tbaa !29
  store ptr %t77, ptr %l52, !tbaa !29
  %t78 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t78, ptr %l53
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t80 = load %"compiler/source:Span", ptr %l1
  %t81 = load ptr, ptr %l5, !tbaa !29
  %t85 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t79, %"compiler/source:Span" %t80, ptr %t81)
  store ptr %t85, ptr %l57
  br label %bb17
bb16:
  br label %bb24
bb17:
  %t86 = load i32, ptr %l8, !tbaa !23
  %t87 = load ptr, ptr %l52, !tbaa !29
  %t88 = load %"compiler/source:Span", ptr %l53
  %t89 = load ptr, ptr %l57, !tbaa !29
  %t92 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyInstance(ptr %v0, ptr %t87, %"compiler/source:Span" %t88, ptr %t89, i32 %t86, i32 0)
  store ptr %t92, ptr %l60
  br label %bb18
bb18:
  %t93 = load ptr, ptr %l60, !tbaa !29
  store ptr %t93, ptr %l11, !tbaa !29
  %t94 = load ptr, ptr %l0, !tbaa !29
  store ptr %t94, ptr %l61, !tbaa !29
  %t95 = load i32, ptr %l3, !tbaa !23
  store i32 %t95, ptr %l62, !tbaa !23
  store %"compiler/source:Span" %a4, ptr %l63
  %t97 = load ptr, ptr %l11, !tbaa !29
  %t100 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t97)
  store i32 %t100, ptr %l66
  br label %bb19
bb19:
  store { i64, [2 x i64] } zeroinitializer, ptr %t101
  %t102 = getelementptr { i64, [2 x i64] }, ptr %t101, i32 0, i32 0
  store i64 5, ptr %t102
  %t103 = load { i64, [2 x i64] }, ptr %t101
  %t104 = load ptr, ptr %l61, !tbaa !29
  %t105 = load i32, ptr %l62, !tbaa !23
  %t106 = load %"compiler/source:Span", ptr %l63
  %t107 = load i32, ptr %l66, !tbaa !23
  %t110 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %t104, i32 %t105, %"compiler/source:Span" %t106, i32 %t107, i32 4, { i64, [2 x i64] } %t103)
  store i64 %t110, ptr %l69
  br label %bb20
bb20:
  %t111 = load i64, ptr %l69, !tbaa !24
  store i64 %t111, ptr %l12, !tbaa !24
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t113 = load i64, ptr %l12, !tbaa !24
  %t114 = load ptr, ptr %l11, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroLet(ptr %v0, ptr %v0, ptr %t112, i64 %t113, ptr %t114)
  br label %bb21
bb21:
  store ptr %a7, ptr %l73, !tbaa !29
  %t119 = load i64, ptr %l12, !tbaa !24
  %t121 = trunc i64 %t119 to i32
  %t123 = load ptr, ptr %l11, !tbaa !29
  %t126 = call %"compiler/typed:Bind" @compiler_2ftyped_3aBind_2ector(ptr %v0, ptr %v0, i32 %t121, ptr %t123)
  store %"compiler/typed:Bind" %t126, ptr %l78
  br label %bb22
bb22:
  %t127 = load %"compiler/typed:Bind", ptr %l78
  %t128 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store %"compiler/typed:Bind" %t127, ptr %t128
  %t129 = load ptr, ptr %l73, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBind_26_3e_2ePush_3ccompiler_2ftyped_3aBind_26_3e(ptr %v0, ptr %v0, ptr %t129, ptr %t128)
  br label %bb23
bb23:
  br label %bb24
bb24:
  %t131 = load ptr, ptr %l10, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t131, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l13 = alloca i64
  %l16 = alloca i64
  %l36 = alloca i1
  %l43 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i32 %a1, ptr %l2, !tbaa !23
  store i64 0, ptr %l3, !tbaa !24
  store i64 32, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t3 = load i64, ptr %l4, !tbaa !24
  %t4 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp sgt i64 %t3, %t4
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = load i64, ptr %l5, !tbaa !24
  %t11 = icmp sgt i64 %t9, 0
  br i1 %t11, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l13, !tbaa !24
  br label %bb6
bb3:
  %t13 = load i64, ptr %l4, !tbaa !24
  %t14 = load i64, ptr %l3, !tbaa !24
  %t17 = sub i64 %t13, %t14
  %t18 = load i64, ptr %l5, !tbaa !24
  %t21 = add i64 %t17, %t18
  %t23 = sub i64 %t21, 1
  %t24 = load i64, ptr %l5, !tbaa !24
  %t27 = sdiv i64 %t23, %t24
  store i64 %t27, ptr %l16, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l16, !tbaa !24
  br label %bb5
bb5:
  %t29 = load i64, ptr %l16, !tbaa !24
  store i64 %t29, ptr %l13, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l13, !tbaa !24
  store i64 %t30, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb7
bb7:
  %t31 = load i64, ptr %l7, !tbaa !24
  %t32 = load i64, ptr %l6, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  %t37 = xor i1 %t35, true
  br i1 %t37, label %bb8, label %bb9
bb8:
  br label %bb17
bb9:
  br label %bb10
bb10:
  %t39 = load i64, ptr %l3, !tbaa !24
  %t40 = load i64, ptr %l7, !tbaa !24
  %t41 = load i64, ptr %l5, !tbaa !24
  %t44 = mul i64 %t40, %t41
  %t47 = add i64 %t39, %t44
  store i64 %t47, ptr %l8, !tbaa !24
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load i32, ptr %l2, !tbaa !23
  %t53 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisOver(ptr %v0, ptr %t49, i32 %t50)
  store i1 %t53, ptr %l36
  br label %bb11
bb11:
  %t54 = load i1, ptr %l36, !tbaa !21
  %t55 = xor i1 %t54, true
  br i1 %t55, label %bb12, label %bb13
bb12:
  %t57 = load i32, ptr %l2, !tbaa !23
  store i32 %t57, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/check:Checker", ptr %t59, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = getelementptr %"compiler/generic:Program", ptr %t62, i32 0, i32 2
  %t65 = load i32, ptr %l2, !tbaa !23
  %t68 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t64, i32 %t65)
  store i32 %t68, ptr %l43
  br label %bb15
bb15:
  %t69 = load i32, ptr %l43, !tbaa !23
  store i32 %t69, ptr %l2, !tbaa !23
  br label %bb16
bb16:
  %t70 = load i64, ptr %l7, !tbaa !24
  %t72 = add i64 %t70, 1
  store i64 %t72, ptr %l7, !tbaa !24
  br label %bb7
bb17:
  %t74 = load i32, ptr %l2, !tbaa !23
  store i32 %t74, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %a0, ptr %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca i32
  %l7 = alloca i32
  %l10 = alloca i1
  %l15 = alloca i32
  %l18 = alloca i1
  %l19 = alloca i1
  %l30 = alloca ptr
  %rv = alloca ptr
  %t41 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t4 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t1)
  store i32 %t4, ptr %l7
  br label %bb1
bb1:
  %t5 = load i32, ptr %l7, !tbaa !23
  store i32 %t5, ptr %l3, !tbaa !23
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load i32, ptr %l3, !tbaa !23
  %t10 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t6, i32 %t7)
  store i1 %t10, ptr %l10
  br label %bb2
bb2:
  %t11 = load i1, ptr %l10, !tbaa !21
  br i1 %t11, label %bb3, label %bb4
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/check:Checker", ptr %t12, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = getelementptr %"compiler/generic:Program", ptr %t15, i32 0, i32 2
  %t18 = load i32, ptr %l3, !tbaa !23
  %t21 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t17, i32 %t18)
  store i32 %t21, ptr %l15
  br label %bb5
bb4:
  br label %bb14
bb5:
  %t22 = load i32, ptr %l15, !tbaa !23
  store i32 %t22, ptr %l4, !tbaa !23
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load i32, ptr %l4, !tbaa !23
  %t27 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t23, i32 %t24)
  store i1 %t27, ptr %l18
  br label %bb6
bb6:
  %t28 = load i1, ptr %l18, !tbaa !21
  br i1 %t28, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb9
bb8:
  %t29 = load i32, ptr %l4, !tbaa !23
  %t30 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t33 = icmp eq i32 %t29, %t30
  store i1 %t33, ptr %l19, !tbaa !21
  br label %bb9
bb9:
  %t35 = load i1, ptr %l19, !tbaa !21
  br i1 %t35, label %bb10, label %bb11
bb10:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load %"compiler/source:Span", ptr %l2
  %t38 = load %"compiler/source:Span", ptr %l2
  %t39 = load i32, ptr %l4, !tbaa !23
  %t40 = load ptr, ptr %l1, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t41
  %t42 = getelementptr { i64, [4 x i64] }, ptr %t41, i32 0, i32 0
  store i64 2, ptr %t42
  %t44 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t38, 0
  %t46 = insertvalue { %"compiler/source:Span", i32, ptr } %t44, i32 %t39, 1
  %t48 = insertvalue { %"compiler/source:Span", i32, ptr } %t46, ptr %t40, 2
  %t49 = getelementptr { i64, [4 x i64] }, ptr %t41, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t48, ptr %t49
  %t50 = load { i64, [4 x i64] }, ptr %t41
  %t52 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t50, ptr %t52
  %t56 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t36, %"compiler/source:Span" %t37, ptr %t52)
  store ptr %t56, ptr %l30
  br label %bb12
bb11:
  br label %bb13
bb12:
  %t57 = load ptr, ptr %l30, !tbaa !29
  store ptr %t57, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t58 = load ptr, ptr %l1, !tbaa !29
  store ptr %t58, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewordIn(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i1
  %l7 = alloca i64
  %l8 = alloca i1
  %l12 = alloca ptr
  %l14 = alloca ptr
  %l17 = alloca ptr
  %l35 = alloca { i64, ptr }
  %l36 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l47 = alloca i1
  %l50 = alloca i1
  %l51 = alloca { i64, ptr }
  %l55 = alloca i1
  %l56 = alloca i1
  %l57 = alloca { i64, ptr }
  %l61 = alloca i1
  %l62 = alloca i1
  %l63 = alloca { i64, ptr }
  %l77 = alloca i1
  %l78 = alloca { i64, ptr }
  %l81 = alloca i1
  %l82 = alloca i1
  %l83 = alloca { i64, ptr }
  %l86 = alloca i1
  %l87 = alloca i1
  %l88 = alloca { i64, ptr }
  %l94 = alloca i1
  %l100 = alloca %"compiler/source:Span"
  %l103 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 5
  store ptr %t9, ptr %l12, !tbaa !29
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t10)
  store ptr %t12, ptr %l14
  br label %bb1
bb1:
  %t13 = load ptr, ptr %l14, !tbaa !29
  %t15 = getelementptr %"compiler/check:frame", ptr %t13, i32 0, i32 1
  %t16 = load i64, ptr %t15, !tbaa !24
  %t17 = load ptr, ptr %l12, !tbaa !29
  %t19 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t17, i64 %t16)
  store ptr %t19, ptr %l17
  br label %bb2
bb2:
  %t20 = load ptr, ptr %l17, !tbaa !29
  %t22 = getelementptr %"compiler/load:Module", ptr %t20, i32 0, i32 6
  %t23 = load ptr, ptr %t22, !tbaa !29
  store ptr %t23, ptr %l3, !tbaa !29
  %t25 = load ptr, ptr %l3, !tbaa !29
  %t27 = icmp eq ptr %t25, null
  br i1 %t27, label %bb3, label %bb4
bb3:
  call void @__olang_check_failed(ptr @olang_loc_261e3060da575f7_c13e4a553a852783)
  unreachable
bb4:
  br label %bb5
bb5:
  %t29 = load ptr, ptr %l3, !tbaa !29
  %t32 = getelementptr %"compiler/source:Source", ptr %t29, i32 0, i32 1
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !27
  store { i64, ptr } %t33, ptr %l4, !tbaa !27
  %t35 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t36 = load i32, ptr %t35, !tbaa !23
  %t38 = sext i32 %t36 to i64
  store i64 %t38, ptr %l5, !tbaa !24
  br label %bb6
bb6:
  %t40 = load i64, ptr %l5, !tbaa !24
  %t41 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t41, 0
  %t46 = add i64 %t40, %t43
  %t47 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t48 = load i32, ptr %t47, !tbaa !23
  %t50 = sext i32 %t48 to i64
  %t53 = icmp sle i64 %t46, %t50
  %t55 = xor i1 %t53, true
  br i1 %t55, label %bb7, label %bb8
bb7:
  br label %bb50
bb8:
  br label %bb9
bb9:
  %t57 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t57, ptr %l35, !tbaa !27
  %t58 = load i64, ptr %l5, !tbaa !24
  store i64 %t58, ptr %l36, !tbaa !24
  %t59 = load i64, ptr %l5, !tbaa !24
  %t60 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t62 = extractvalue { i64, ptr } %t60, 0
  %t65 = add i64 %t59, %t62
  store i64 %t65, ptr %l40, !tbaa !24
  %t66 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t67 = extractvalue { i64, ptr } %t66, 0
  store i64 %t67, ptr %l41, !tbaa !24
  %t68 = load i64, ptr %l36, !tbaa !24
  %t69 = icmp sge i64 %t68, 0
  br i1 %t69, label %bb10, label %bb11
bb10:
  %t71 = load i64, ptr %l36, !tbaa !24
  %t72 = load i64, ptr %l40, !tbaa !24
  %t73 = icmp sle i64 %t71, %t72
  br i1 %t73, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_1591269354839ba0_3246c27539059c2c)
  unreachable
bb12:
  %t75 = load i64, ptr %l40, !tbaa !24
  %t76 = load i64, ptr %l41, !tbaa !24
  %t77 = icmp sle i64 %t75, %t76
  br i1 %t77, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_1591269354839ba0_3246c27539059c2c)
  unreachable
bb14:
  %t79 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = load i64, ptr %l36, !tbaa !24
  %t82 = load i64, ptr %l40, !tbaa !24
  %t83 = getelementptr i8, ptr %t80, i64 %t81
  %t84 = sub i64 %t82, %t81
  %t85 = insertvalue { i64, ptr } undef, i64 %t84, 0
  %t86 = insertvalue { i64, ptr } %t85, ptr %t83, 1
  %t87 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t90 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %t86, { i64, ptr } %t87)
  store i1 %t90, ptr %l47
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_1591269354839ba0_3246c27539059c2c)
  unreachable
bb16:
  %t91 = load i1, ptr %l47, !tbaa !21
  br i1 %t91, label %bb17, label %bb18
bb17:
  %t92 = load i64, ptr %l5, !tbaa !24
  %t94 = icmp eq i64 %t92, 0
  br i1 %t94, label %bb19, label %bb20
bb18:
  br label %bb48
bb19:
  store i1 true, ptr %l50, !tbaa !21
  br label %bb29
bb20:
  %t96 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t96, ptr %l51, !tbaa !27
  %t97 = load i64, ptr %l5, !tbaa !24
  %t99 = sub i64 %t97, 1
  %t101 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !27
  %t103 = getelementptr i8, ptr %t102, i64 %t99
  %t104 = load i8, ptr %t103, !tbaa !32
  %t106 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t104)
  store i1 %t106, ptr %l55
  br label %bb21
bb21:
  %t107 = load i1, ptr %l55, !tbaa !21
  br i1 %t107, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l56, !tbaa !21
  br label %bb25
bb23:
  %t108 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t108, ptr %l57, !tbaa !27
  %t109 = load i64, ptr %l5, !tbaa !24
  %t111 = sub i64 %t109, 1
  %t113 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !27
  %t115 = getelementptr i8, ptr %t114, i64 %t111
  %t116 = load i8, ptr %t115, !tbaa !32
  %t118 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t116)
  store i1 %t118, ptr %l61
  br label %bb24
bb24:
  %t119 = load i1, ptr %l61, !tbaa !21
  store i1 %t119, ptr %l56, !tbaa !21
  br label %bb25
bb25:
  %t120 = load i1, ptr %l56, !tbaa !21
  br i1 %t120, label %bb26, label %bb27
bb26:
  store i1 true, ptr %l62, !tbaa !21
  br label %bb28
bb27:
  %t121 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t121, ptr %l63, !tbaa !27
  %t122 = load i64, ptr %l5, !tbaa !24
  %t124 = sub i64 %t122, 1
  %t126 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t127 = load ptr, ptr %t126, !tbaa !27
  %t128 = getelementptr i8, ptr %t127, i64 %t124
  %t129 = load i8, ptr %t128, !tbaa !32
  %t131 = icmp eq i8 %t129, 95
  store i1 %t131, ptr %l62, !tbaa !21
  br label %bb28
bb28:
  %t133 = load i1, ptr %l62, !tbaa !21
  %t134 = xor i1 %t133, true
  store i1 %t134, ptr %l50, !tbaa !21
  br label %bb29
bb29:
  %t136 = load i1, ptr %l50, !tbaa !21
  store i1 %t136, ptr %l6, !tbaa !21
  %t137 = load i64, ptr %l5, !tbaa !24
  %t138 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t140 = extractvalue { i64, ptr } %t138, 0
  %t143 = add i64 %t137, %t140
  store i64 %t143, ptr %l7, !tbaa !24
  %t145 = load i64, ptr %l7, !tbaa !24
  %t146 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t148 = extractvalue { i64, ptr } %t146, 0
  %t151 = icmp sge i64 %t145, %t148
  br i1 %t151, label %bb30, label %bb31
bb30:
  store i1 true, ptr %l77, !tbaa !21
  br label %bb40
bb31:
  %t153 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t153, ptr %l78, !tbaa !27
  %t154 = load i64, ptr %l7, !tbaa !24
  %t156 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t157 = load ptr, ptr %t156, !tbaa !27
  %t158 = getelementptr i8, ptr %t157, i64 %t154
  %t159 = load i8, ptr %t158, !tbaa !32
  %t161 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t159)
  store i1 %t161, ptr %l81
  br label %bb32
bb32:
  %t162 = load i1, ptr %l81, !tbaa !21
  br i1 %t162, label %bb33, label %bb34
bb33:
  store i1 true, ptr %l82, !tbaa !21
  br label %bb36
bb34:
  %t163 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t163, ptr %l83, !tbaa !27
  %t164 = load i64, ptr %l7, !tbaa !24
  %t166 = getelementptr { i64, ptr }, ptr %l83, i32 0, i32 1
  %t167 = load ptr, ptr %t166, !tbaa !27
  %t168 = getelementptr i8, ptr %t167, i64 %t164
  %t169 = load i8, ptr %t168, !tbaa !32
  %t171 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t169)
  store i1 %t171, ptr %l86
  br label %bb35
bb35:
  %t172 = load i1, ptr %l86, !tbaa !21
  store i1 %t172, ptr %l82, !tbaa !21
  br label %bb36
bb36:
  %t173 = load i1, ptr %l82, !tbaa !21
  br i1 %t173, label %bb37, label %bb38
bb37:
  store i1 true, ptr %l87, !tbaa !21
  br label %bb39
bb38:
  %t174 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t174, ptr %l88, !tbaa !27
  %t175 = load i64, ptr %l7, !tbaa !24
  %t177 = getelementptr { i64, ptr }, ptr %l88, i32 0, i32 1
  %t178 = load ptr, ptr %t177, !tbaa !27
  %t179 = getelementptr i8, ptr %t178, i64 %t175
  %t180 = load i8, ptr %t179, !tbaa !32
  %t182 = icmp eq i8 %t180, 95
  store i1 %t182, ptr %l87, !tbaa !21
  br label %bb39
bb39:
  %t184 = load i1, ptr %l87, !tbaa !21
  %t185 = xor i1 %t184, true
  store i1 %t185, ptr %l77, !tbaa !21
  br label %bb40
bb40:
  %t187 = load i1, ptr %l77, !tbaa !21
  store i1 %t187, ptr %l8, !tbaa !21
  %t188 = load i1, ptr %l6, !tbaa !21
  br i1 %t188, label %bb41, label %bb42
bb41:
  %t190 = load i1, ptr %l8, !tbaa !21
  store i1 %t190, ptr %l94, !tbaa !21
  br label %bb43
bb42:
  store i1 false, ptr %l94, !tbaa !21
  br label %bb43
bb43:
  %t192 = load i1, ptr %l94, !tbaa !21
  br i1 %t192, label %bb44, label %bb45
bb44:
  store %olang.scope zeroinitializer, ptr %s3
  %t193 = load i64, ptr %l5, !tbaa !24
  %t195 = trunc i64 %t193 to i32
  %t196 = load i64, ptr %l7, !tbaa !24
  %t198 = trunc i64 %t196 to i32
  %t201 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s3, i32 %t195, i32 %t198)
  store %"compiler/source:Span" %t201, ptr %l100
  br label %bb46
bb45:
  br label %bb47
bb46:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t202 = load %"compiler/source:Span", ptr %l100
  store %"compiler/source:Span" %t202, ptr %rv
  br label %ret
bb47:
  br label %bb48
bb48:
  %t203 = load i64, ptr %l5, !tbaa !24
  %t205 = add i64 %t203, 1
  store i64 %t205, ptr %l5, !tbaa !24
  br label %bb49
bb49:
  br label %bb6
bb50:
  %t207 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 -1, i32 -1)
  store %"compiler/source:Span" %t207, ptr %l103
  br label %bb51
bb51:
  call void @__olang_scope_close(ptr %s0)
  %t208 = load %"compiler/source:Span", ptr %l103
  store %"compiler/source:Span" %t208, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewrittenEnum(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i1
  %l13 = alloca i32
  %l19 = alloca i32
  %l25 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 15
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb15
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t20 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeNamed(ptr %v0, ptr %v1, ptr %t16, ptr %t17)
  store i32 %t20, ptr %l13
  br label %bb6
bb6:
  %t21 = load i32, ptr %l13, !tbaa !23
  store i32 %t21, ptr %l3, !tbaa !23
  %t22 = load i32, ptr %l3, !tbaa !23
  %t24 = icmp sge i32 %t22, 0
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t26 = load i32, ptr %l3, !tbaa !23
  store i32 %t26, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load ptr, ptr %l2, !tbaa !29
  %t32 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egenericNamed(ptr %v0, ptr %v1, ptr %t28, ptr %t29)
  store i32 %t32, ptr %l19
  br label %bb10
bb10:
  %t33 = load i32, ptr %l19, !tbaa !23
  store i32 %t33, ptr %l4, !tbaa !23
  %t34 = load i32, ptr %l4, !tbaa !23
  %t36 = icmp sge i32 %t34, 0
  br i1 %t36, label %bb11, label %bb12
bb11:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/check:Checker", ptr %t38, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t42 = load i32, ptr %l4, !tbaa !23
  %t45 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSelfType(ptr %v0, ptr %t41, i32 %t42)
  store i32 %t45, ptr %l25
  br label %bb13
bb12:
  br label %bb14
bb13:
  %t46 = load i32, ptr %l25, !tbaa !23
  store i32 %t46, ptr %rv
  br label %ret
bb14:
  br label %bb16
bb15:
  br label %bb16
bb16:
  store i32 -1, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2efieldSpans(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %lp1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l11 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l25 = alloca { i64, ptr }
  %l28 = alloca ptr
  %l29 = alloca i1
  %l44 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l11
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t2, ptr %lp1
  %t3 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l11
  %t4 = load ptr, ptr %lp1
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %t4
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/ast:StructBody", ptr %t5, i32 0, i32 2
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t8, 0
  %t12 = icmp eq i64 %t10, 0
  br i1 %t12, label %bb2, label %bb3
bb2:
  %t14 = load ptr, ptr %lp1
  %t15 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t14
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t15, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/ast:StructBody", ptr %t17, i32 0, i32 2
  %t20 = load { i64, ptr }, ptr %t19, !tbaa !27
  store { i64, ptr } %t20, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t22, 0
  store i64 %t24, ptr %l4, !tbaa !24
  br label %bb5
bb5:
  %t26 = load i64, ptr %l3, !tbaa !24
  %t27 = load i64, ptr %l4, !tbaa !24
  %t30 = icmp slt i64 %t26, %t27
  %t32 = xor i1 %t30, true
  br i1 %t32, label %bb6, label %bb7
bb6:
  br label %bb27
bb7:
  br label %bb8
bb8:
  %t34 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t34, ptr %l25, !tbaa !27
  %t35 = load i64, ptr %l3, !tbaa !24
  %t37 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !27
  %t39 = getelementptr ptr, ptr %t38, i64 %t35
  %t40 = load ptr, ptr %t39, !tbaa !39
  store ptr %t40, ptr %l5, !tbaa !29
  %t42 = load ptr, ptr %l5, !tbaa !29
  store ptr %t42, ptr %l28, !tbaa !29
  store i1 false, ptr %l29, !tbaa !21
  %t43 = load ptr, ptr %l28, !tbaa !29
  %t44 = icmp ne ptr %t43, null
  br i1 %t44, label %bb9, label %bb10
bb9:
  %t46 = load ptr, ptr %l28, !tbaa !29
  %t47 = load i64, ptr %t46
  %t49 = icmp eq i64 %t47, 1
  store i1 %t49, ptr %l29, !tbaa !21
  br label %bb10
bb10:
  %t50 = load i1, ptr %l29, !tbaa !21
  br i1 %t50, label %bb11, label %bb12
bb11:
  %t51 = load ptr, ptr %l5, !tbaa !29
  %t53 = getelementptr { i64, [4 x i64] }, ptr %t51, i32 0, i32 1
  %t54 = getelementptr { %"compiler/source:Span", ptr }, ptr %t53, i32 0, i32 1
  %t55 = load ptr, ptr %t54
  store ptr %t55, ptr %l6, !tbaa !29
  br label %bb13
bb12:
  br label %bb24
bb13:
  %t57 = load ptr, ptr %l6, !tbaa !29
  %t59 = getelementptr %"compiler/ast:VarDecl", ptr %t57, i32 0, i32 5
  %t60 = load i1, ptr %t59, !tbaa !21
  br i1 %t60, label %bb14, label %bb15
bb14:
  %t62 = load ptr, ptr %l6, !tbaa !29
  %t64 = getelementptr %"compiler/ast:VarDecl", ptr %t62, i32 0, i32 1
  %t65 = load { i64, ptr }, ptr %t64, !tbaa !27
  store { i64, ptr } %t65, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t67 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t67, 0
  store i64 %t69, ptr %l9, !tbaa !24
  br label %bb16
bb15:
  br label %bb23
bb16:
  %t71 = load i64, ptr %l8, !tbaa !24
  %t72 = load i64, ptr %l9, !tbaa !24
  %t75 = icmp slt i64 %t71, %t72
  %t77 = xor i1 %t75, true
  br i1 %t77, label %bb17, label %bb18
bb17:
  br label %bb22
bb18:
  br label %bb19
bb19:
  %t79 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t79, ptr %l44, !tbaa !27
  %t80 = load i64, ptr %l8, !tbaa !24
  %t82 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !27
  %t84 = getelementptr %"compiler/source:Span", ptr %t83, i64 %t80
  %t85 = load %"compiler/source:Span", ptr %t84
  %t87 = load ptr, ptr %lp1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v1, ptr %t87, %"compiler/source:Span" %t85)
  br label %bb20
bb20:
  br label %bb21
bb21:
  %t91 = load i64, ptr %l8, !tbaa !24
  %t93 = add i64 %t91, 1
  store i64 %t93, ptr %l8, !tbaa !24
  br label %bb16
bb22:
  br label %bb23
bb23:
  br label %bb25
bb24:
  br label %bb25
bb25:
  br label %bb26
bb26:
  %t95 = load i64, ptr %l3, !tbaa !24
  %t97 = add i64 %t95, 1
  store i64 %t97, ptr %l3, !tbaa !24
  br label %bb5
bb27:
  %t99 = load ptr, ptr %lp1
  %t100 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t99
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t100, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local %"compiler/check:litv" @compiler_2fcheck_2efloatLit(double %a0) #0 {
entry:
  %l2 = alloca %"compiler/check:litv"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/check:litv"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call %"compiler/check:litv" @compiler_2fcheck_3alitv_2ector(ptr %s0, i1 true, i1 true, i1 false, i64 0, double %a0)
  store %"compiler/check:litv" %t3, ptr %l2
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t4 = load %"compiler/check:litv", ptr %l2
  store %"compiler/check:litv" %t4, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:litv", ptr %rv
  ret %"compiler/check:litv" %rr
}

define dso_local i1 @compiler_2fcheck_2eintOnly(i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l3 = alloca i1
  %l6 = alloca i1
  %l9 = alloca i1
  %l12 = alloca i1
  %l15 = alloca i1
  %rv = alloca i1
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0
  %t3 = trunc i64 83 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb3
bb2:
  %t6 = load i32, ptr %l0
  %t8 = trunc i64 84 to i32
  %t9 = icmp eq i32 %t6, %t8
  store i1 %t9, ptr %l3, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l3, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb6
bb5:
  %t12 = load i32, ptr %l0
  %t14 = trunc i64 85 to i32
  %t15 = icmp eq i32 %t12, %t14
  store i1 %t15, ptr %l6, !tbaa !21
  br label %bb6
bb6:
  %t17 = load i1, ptr %l6, !tbaa !21
  br i1 %t17, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb9
bb8:
  %t18 = load i32, ptr %l0
  %t20 = trunc i64 55 to i32
  %t21 = icmp eq i32 %t18, %t20
  store i1 %t21, ptr %l9, !tbaa !21
  br label %bb9
bb9:
  %t23 = load i1, ptr %l9, !tbaa !21
  br i1 %t23, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb12
bb11:
  %t24 = load i32, ptr %l0
  %t26 = trunc i64 88 to i32
  %t27 = icmp eq i32 %t24, %t26
  store i1 %t27, ptr %l12, !tbaa !21
  br label %bb12
bb12:
  %t29 = load i1, ptr %l12, !tbaa !21
  br i1 %t29, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb15
bb14:
  %t30 = load i32, ptr %l0
  %t32 = trunc i64 89 to i32
  %t33 = icmp eq i32 %t30, %t32
  store i1 %t33, ptr %l15, !tbaa !21
  br label %bb15
bb15:
  %t35 = load i1, ptr %l15, !tbaa !21
  store i1 %t35, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2eisCharLit(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i1
  %l3 = alloca ptr
  %l4 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l1
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load i32, ptr %l1
  %t18 = trunc i64 4 to i32
  %t19 = icmp eq i32 %t16, %t18
  store i1 %t19, ptr %l2, !tbaa !21
  br label %bb11
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_83df14ccfb59caa2_79e7c0956b45666e)
  unreachable
bb11:
  %t21 = load i1, ptr %l2, !tbaa !21
  store i1 %t21, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2eisFuncTypeRef(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca i1
  %l2 = alloca ptr
  %l3 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l2, !tbaa !29
  store i1 false, ptr %l3, !tbaa !21
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store i1 true, ptr %l1, !tbaa !21
  br label %bb11
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i1 false, ptr %l1, !tbaa !21
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_c99fc0d93a64b260_1a05e01caddb974)
  unreachable
bb11:
  %t10 = load i1, ptr %l1, !tbaa !21
  store i1 %t10, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fcheck_2elimitBits(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i1
  %l7 = alloca i64
  %l10 = alloca i1
  %l13 = alloca i1
  %l17 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l25 = alloca i64
  %l29 = alloca i64
  %l31 = alloca i64
  %l36 = alloca [6 x i64]
  %l41 = alloca [6 x i64]
  %l46 = alloca [6 x i64]
  %l49 = alloca [6 x i64]
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %t1, i32 %t2)
  store i64 %t5, ptr %l7
  br label %bb1
bb1:
  %t6 = load i64, ptr %l7, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l1, !tbaa !23
  %t11 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %t7, i32 %t8)
  store i1 %t11, ptr %l10
  br label %bb2
bb2:
  %t12 = load i1, ptr %l10, !tbaa !21
  br i1 %t12, label %bb3, label %bb4
bb3:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load i32, ptr %l1, !tbaa !23
  %t17 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %t13, i32 %t14)
  store i1 %t17, ptr %l13
  br label %bb5
bb4:
  br label %bb18
bb5:
  %t18 = load i1, ptr %l13, !tbaa !21
  store i1 %t18, ptr %l4, !tbaa !21
  %t19 = load i64, ptr %l2, !tbaa !24
  %t21 = icmp eq i64 %t19, 0
  br i1 %t21, label %bb6, label %bb7
bb6:
  %t23 = load i1, ptr %l4, !tbaa !21
  br i1 %t23, label %bb8, label %bb9
bb7:
  br label %bb14
bb8:
  %t25 = load i64, ptr %l3, !tbaa !24
  %t27 = icmp eq i64 %t25, 64
  br i1 %t27, label %bb10, label %bb11
bb9:
  %t29 = load i64, ptr %l3, !tbaa !24
  %t31 = sub i64 %t29, 1
  store i64 %t31, ptr %l25, !tbaa !24
  %t32 = load i64, ptr %l25, !tbaa !24
  %t33 = load i64, ptr %l25, !tbaa !24
  %t34 = shl i64 1, %t33
  %t36 = sub i64 %t34, 1
  store i64 %t36, ptr %l17, !tbaa !24
  br label %bb13
bb10:
  store i64 -1, ptr %l20, !tbaa !24
  br label %bb12
bb11:
  %t38 = load i64, ptr %l3, !tbaa !24
  store i64 %t38, ptr %l21, !tbaa !24
  %t39 = load i64, ptr %l21, !tbaa !24
  %t40 = load i64, ptr %l21, !tbaa !24
  %t41 = shl i64 1, %t40
  %t43 = sub i64 %t41, 1
  store i64 %t43, ptr %l20, !tbaa !24
  br label %bb12
bb12:
  %t45 = load i64, ptr %l20, !tbaa !24
  store i64 %t45, ptr %l17, !tbaa !24
  br label %bb13
bb13:
  %t46 = load i64, ptr %l17, !tbaa !24
  store i64 %t46, ptr %rv
  br label %ret
bb14:
  %t47 = load i1, ptr %l4, !tbaa !21
  br i1 %t47, label %bb15, label %bb16
bb15:
  store i64 0, ptr %l29, !tbaa !24
  br label %bb17
bb16:
  %t49 = load i64, ptr %l3, !tbaa !24
  %t51 = sub i64 %t49, 1
  store i64 %t51, ptr %l31, !tbaa !24
  %t52 = load i64, ptr %l31, !tbaa !24
  %t53 = load i64, ptr %l31, !tbaa !24
  %t54 = shl i64 1, %t53
  %t56 = sub i64 0, %t54
  store i64 %t56, ptr %l29, !tbaa !24
  br label %bb17
bb17:
  %t58 = load i64, ptr %l29, !tbaa !24
  store i64 %t58, ptr %rv
  br label %ret
bb18:
  %t59 = load i32, ptr %l1, !tbaa !23
  %t61 = icmp eq i32 %t59, 13
  br i1 %t61, label %bb19, label %bb20
bb19:
  %t63 = insertvalue [6 x i64] undef, i64 2139095039, 0
  %t64 = insertvalue [6 x i64] %t63, i64 4286578687, 1
  %t65 = insertvalue [6 x i64] %t64, i64 2139095040, 2
  %t66 = insertvalue [6 x i64] %t65, i64 2143289344, 3
  %t67 = insertvalue [6 x i64] %t66, i64 872415232, 4
  %t68 = insertvalue [6 x i64] %t67, i64 8388608, 5
  store [6 x i64] %t68, ptr %l36
  %t69 = load i64, ptr %l2, !tbaa !24
  %t71 = getelementptr [6 x i64], ptr %l36, i64 0, i64 %t69
  %t72 = load i64, ptr %t71, !tbaa !34
  store i64 %t72, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t74 = load i32, ptr %l1, !tbaa !23
  %t76 = icmp eq i32 %t74, 11
  br i1 %t76, label %bb22, label %bb23
bb22:
  %t78 = insertvalue [6 x i64] undef, i64 31743, 0
  %t79 = insertvalue [6 x i64] %t78, i64 64511, 1
  %t80 = insertvalue [6 x i64] %t79, i64 31744, 2
  %t81 = insertvalue [6 x i64] %t80, i64 32256, 3
  %t82 = insertvalue [6 x i64] %t81, i64 5120, 4
  %t83 = insertvalue [6 x i64] %t82, i64 1024, 5
  store [6 x i64] %t83, ptr %l41
  %t84 = load i64, ptr %l2, !tbaa !24
  %t86 = getelementptr [6 x i64], ptr %l41, i64 0, i64 %t84
  %t87 = load i64, ptr %t86, !tbaa !34
  store i64 %t87, ptr %rv
  br label %ret
bb23:
  br label %bb24
bb24:
  %t89 = load i32, ptr %l1, !tbaa !23
  %t91 = icmp eq i32 %t89, 12
  br i1 %t91, label %bb25, label %bb26
bb25:
  %t93 = insertvalue [6 x i64] undef, i64 32639, 0
  %t94 = insertvalue [6 x i64] %t93, i64 65407, 1
  %t95 = insertvalue [6 x i64] %t94, i64 32640, 2
  %t96 = insertvalue [6 x i64] %t95, i64 32704, 3
  %t97 = insertvalue [6 x i64] %t96, i64 15360, 4
  %t98 = insertvalue [6 x i64] %t97, i64 128, 5
  store [6 x i64] %t98, ptr %l46
  %t99 = load i64, ptr %l2, !tbaa !24
  %t101 = getelementptr [6 x i64], ptr %l46, i64 0, i64 %t99
  %t102 = load i64, ptr %t101, !tbaa !34
  store i64 %t102, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  %t104 = insertvalue [6 x i64] undef, i64 9218868437227405311, 0
  %t105 = insertvalue [6 x i64] %t104, i64 -4503599627370497, 1
  %t106 = insertvalue [6 x i64] %t105, i64 9218868437227405312, 2
  %t107 = insertvalue [6 x i64] %t106, i64 9221120237041090560, 3
  %t108 = insertvalue [6 x i64] %t107, i64 4372995238176751616, 4
  %t109 = insertvalue [6 x i64] %t108, i64 4503599627370496, 5
  store [6 x i64] %t109, ptr %l49
  %t110 = load i64, ptr %l2, !tbaa !24
  %t112 = getelementptr [6 x i64], ptr %l49, i64 0, i64 %t110
  %t113 = load i64, ptr %t112, !tbaa !34
  store i64 %t113, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"compiler/check:litv" @compiler_2fcheck_2eofMag(i1 %a0, i128 %a1) #0 {
entry:
  %l1 = alloca i128
  %l2 = alloca i128
  %l5 = alloca %"compiler/check:litv"
  %l14 = alloca %"compiler/check:litv"
  %l20 = alloca %"compiler/check:litv"
  %l22 = alloca %"compiler/check:litv"
  %l30 = alloca %"compiler/check:litv"
  %l35 = alloca %"compiler/check:litv"
  %l36 = alloca %"compiler/check:litv"
  %s4 = alloca %olang.scope
  %rv = alloca %"compiler/check:litv"
  store i128 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i128, ptr %l1
  %t3 = icmp eq i128 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call %"compiler/check:litv" @compiler_2fcheck_2eintLit(i64 0)
  store %"compiler/check:litv" %t5, ptr %l5
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t6 = load %"compiler/check:litv", ptr %l5
  store %"compiler/check:litv" %t6, ptr %rv
  br label %ret
bb4:
  %t7 = shl i128 1, 63
  store i128 %t7, ptr %l2
  %t11 = xor i1 %a0, true
  br i1 %t11, label %bb5, label %bb6
bb5:
  %t13 = load i128, ptr %l1
  %t14 = load i128, ptr %l2
  %t17 = icmp ult i128 %t13, %t14
  br i1 %t17, label %bb7, label %bb8
bb6:
  br label %bb16
bb7:
  %t19 = load i128, ptr %l1
  %t21 = trunc i128 %t19 to i64
  %t23 = call %"compiler/check:litv" @compiler_2fcheck_2eintLit(i64 %t21)
  store %"compiler/check:litv" %t23, ptr %l14
  br label %bb9
bb8:
  br label %bb10
bb9:
  %t24 = load %"compiler/check:litv", ptr %l14
  store %"compiler/check:litv" %t24, ptr %rv
  br label %ret
bb10:
  %t25 = load i128, ptr %l1
  %t26 = shl i128 1, 64
  %t29 = icmp ult i128 %t25, %t26
  br i1 %t29, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s4
  %t31 = load i128, ptr %l1
  %t33 = trunc i128 %t31 to i64
  %t35 = call %"compiler/check:litv" @compiler_2fcheck_3alitv_2ector(ptr %s4, i1 true, i1 false, i1 true, i64 %t33, double 0x0000000000000000)
  store %"compiler/check:litv" %t35, ptr %l20
  br label %bb13
bb12:
  br label %bb14
bb13:
  call void @__olang_scope_close(ptr %s4)
  %t36 = load %"compiler/check:litv", ptr %l20
  store %"compiler/check:litv" %t36, ptr %rv
  br label %ret
bb14:
  %t37 = load i128, ptr %l1
  %t39 = call %"compiler/check:litv" @compiler_2fcheck_2ewideLit(i1 false, i128 %t37)
  store %"compiler/check:litv" %t39, ptr %l22
  br label %bb15
bb15:
  %t40 = load %"compiler/check:litv", ptr %l22
  store %"compiler/check:litv" %t40, ptr %rv
  br label %ret
bb16:
  %t41 = load i128, ptr %l1
  %t42 = load i128, ptr %l2
  %t45 = icmp ule i128 %t41, %t42
  br i1 %t45, label %bb17, label %bb18
bb17:
  %t47 = load i128, ptr %l1
  %t49 = trunc i128 %t47 to i64
  %t51 = sub i64 0, %t49
  %t54 = call %"compiler/check:litv" @compiler_2fcheck_2eintLit(i64 %t51)
  store %"compiler/check:litv" %t54, ptr %l30
  br label %bb19
bb18:
  br label %bb20
bb19:
  %t55 = load %"compiler/check:litv", ptr %l30
  store %"compiler/check:litv" %t55, ptr %rv
  br label %ret
bb20:
  %t56 = load i128, ptr %l1
  %t57 = shl i128 1, 127
  %t60 = icmp ule i128 %t56, %t57
  br i1 %t60, label %bb21, label %bb22
bb21:
  %t62 = load i128, ptr %l1
  %t64 = call %"compiler/check:litv" @compiler_2fcheck_2ewideLit(i1 true, i128 %t62)
  store %"compiler/check:litv" %t64, ptr %l35
  br label %bb23
bb22:
  br label %bb24
bb23:
  %t65 = load %"compiler/check:litv", ptr %l35
  store %"compiler/check:litv" %t65, ptr %rv
  br label %ret
bb24:
  %t66 = call %"compiler/check:litv" @compiler_2fcheck_2enoLit()
  store %"compiler/check:litv" %t66, ptr %l36
  br label %bb25
bb25:
  %t67 = load %"compiler/check:litv", ptr %l36
  store %"compiler/check:litv" %t67, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:litv", ptr %rv
  ret %"compiler/check:litv" %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2epathOf(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %lp6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca i1
  %l19 = alloca i32
  %l23 = alloca ptr
  %l24 = alloca i1
  %l30 = alloca { i64, ptr }
  %l31 = alloca ptr
  %l32 = alloca i1
  %l40 = alloca { i64, ptr }
  %l49 = alloca i64
  %l50 = alloca i32
  %l59 = alloca i64
  %l62 = alloca i64
  %l81 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  %t24 = alloca i64
  %t110 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t2 = load ptr, ptr %l13, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l13, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l14, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l14, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l1, !tbaa !23
  br label %bb5
bb4:
  br label %bb10
bb5:
  %t16 = load i32, ptr %l1, !tbaa !23
  store i32 %t16, ptr %l19, !tbaa !23
  %t17 = icmp sge i64 1, 0
  br i1 %t17, label %bb6, label %bb7
bb6:
  %t19 = icmp sle i64 1, 2305843009213693951
  br i1 %t19, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_3043109bf91ec9f6_e521dc8ddba3d97a)
  unreachable
bb8:
  %t21 = mul i64 1, 4
  %t22 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t21)
  %t23 = load i32, ptr %l19, !tbaa !23
  store i64 0, ptr %t24
  br label %fill.25
fill.25:
  %t28 = load i64, ptr %t24
  %t29 = icmp slt i64 %t28, 1
  br i1 %t29, label %fillb.26, label %filld.27
fillb.26:
  %t30 = getelementptr i32, ptr %t22, i64 %t28
  store i32 %t23, ptr %t30
  %t31 = add i64 %t28, 1
  store i64 %t31, ptr %t24
  br label %fill.25
filld.27:
  %t32 = insertvalue { i64, ptr } undef, i64 1, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t22, 1
  store { i64, ptr } %t33, ptr %rv
  br label %ret
bb9:
  call void @__olang_check_failed(ptr @olang_loc_3043109bf91ec9f6_e521dc8ddba3d97a)
  unreachable
bb10:
  %t35 = load ptr, ptr %l0, !tbaa !29
  store ptr %t35, ptr %l23, !tbaa !29
  store i1 false, ptr %l24, !tbaa !21
  %t36 = load ptr, ptr %l23, !tbaa !29
  %t37 = icmp ne ptr %t36, null
  br i1 %t37, label %bb11, label %bb12
bb11:
  %t39 = load ptr, ptr %l23, !tbaa !29
  %t40 = load i64, ptr %t39
  %t42 = icmp eq i64 %t40, 2
  store i1 %t42, ptr %l24, !tbaa !21
  br label %bb12
bb12:
  %t43 = load i1, ptr %l24, !tbaa !21
  br i1 %t43, label %bb13, label %bb14
bb13:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr { i64, [5 x i64] }, ptr %t44, i32 0, i32 1
  %t47 = getelementptr { %"compiler/source:Span", ptr }, ptr %t46, i32 0, i32 1
  %t48 = load ptr, ptr %t47
  store ptr %t48, ptr %l2, !tbaa !29
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t50 = load ptr, ptr %l2, !tbaa !29
  %t52 = call { i64, ptr } @compiler_2fcheck_2epathOf(ptr %v0, ptr %t50)
  store { i64, ptr } %t52, ptr %l30
  br label %bb16
bb16:
  %t53 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t53, ptr %rv
  br label %ret
bb17:
  %t54 = load ptr, ptr %l0, !tbaa !29
  store ptr %t54, ptr %l31, !tbaa !29
  store i1 false, ptr %l32, !tbaa !21
  %t55 = load ptr, ptr %l31, !tbaa !29
  %t56 = icmp ne ptr %t55, null
  br i1 %t56, label %bb18, label %bb19
bb18:
  %t58 = load ptr, ptr %l31, !tbaa !29
  %t59 = load i64, ptr %t58
  %t61 = icmp eq i64 %t59, 15
  store i1 %t61, ptr %l32, !tbaa !21
  br label %bb19
bb19:
  %t62 = load i1, ptr %l32, !tbaa !21
  br i1 %t62, label %bb20, label %bb21
bb20:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr { i64, [5 x i64] }, ptr %t63, i32 0, i32 1
  %t66 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t65, i32 0, i32 1
  %t67 = load ptr, ptr %t66
  store ptr %t67, ptr %l3, !tbaa !29
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr { i64, [5 x i64] }, ptr %t69, i32 0, i32 1
  %t72 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t71, i32 0, i32 2
  %t73 = load i32, ptr %t72
  store i32 %t73, ptr %l4, !tbaa !23
  br label %bb22
bb21:
  br label %bb47
bb22:
  %t75 = load ptr, ptr %l3, !tbaa !29
  %t77 = call { i64, ptr } @compiler_2fcheck_2epathOf(ptr %v0, ptr %t75)
  store { i64, ptr } %t77, ptr %l40
  br label %bb23
bb23:
  %t78 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t78, ptr %l5, !tbaa !27
  %t79 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t81 = extractvalue { i64, ptr } %t79, 0
  %t83 = icmp eq i64 %t81, 0
  br i1 %t83, label %bb24, label %bb25
bb24:
  %t85 = icmp sge i64 0, 0
  br i1 %t85, label %bb26, label %bb27
bb25:
  br label %bb30
bb26:
  %t87 = icmp sle i64 0, 2305843009213693951
  br i1 %t87, label %bb28, label %bb29
bb27:
  call void @__olang_check_failed(ptr @olang_loc_4815dd6a844b648b_8f1bd19822fdb0cf)
  unreachable
bb28:
  %t89 = mul i64 0, 4
  %t90 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t89)
  %t91 = insertvalue { i64, ptr } undef, i64 0, 0
  %t92 = insertvalue { i64, ptr } %t91, ptr %t90, 1
  store { i64, ptr } %t92, ptr %rv
  br label %ret
bb29:
  call void @__olang_check_failed(ptr @olang_loc_4815dd6a844b648b_8f1bd19822fdb0cf)
  unreachable
bb30:
  %t94 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t96 = extractvalue { i64, ptr } %t94, 0
  %t98 = add i64 %t96, 1
  store i64 %t98, ptr %l49, !tbaa !24
  %t99 = load i32, ptr %l4, !tbaa !23
  store i32 %t99, ptr %l50, !tbaa !23
  %t100 = load i64, ptr %l49, !tbaa !24
  %t101 = icmp sge i64 %t100, 0
  br i1 %t101, label %bb31, label %bb32
bb31:
  %t103 = load i64, ptr %l49, !tbaa !24
  %t104 = icmp sle i64 %t103, 2305843009213693951
  br i1 %t104, label %bb33, label %bb34
bb32:
  call void @__olang_check_failed(ptr @olang_loc_5df9bd969218a728_7fa184e5bc45956c)
  unreachable
bb33:
  %t106 = load i64, ptr %l49, !tbaa !24
  %t107 = mul i64 %t106, 4
  %t108 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t107)
  %t109 = load i32, ptr %l50, !tbaa !23
  store i64 0, ptr %t110
  br label %fill.111
fill.111:
  %t114 = load i64, ptr %t110
  %t115 = icmp slt i64 %t114, %t106
  br i1 %t115, label %fillb.112, label %filld.113
fillb.112:
  %t116 = getelementptr i32, ptr %t108, i64 %t114
  store i32 %t109, ptr %t116
  %t117 = add i64 %t114, 1
  store i64 %t117, ptr %t110
  br label %fill.111
filld.113:
  %t118 = insertvalue { i64, ptr } undef, i64 %t106, 0
  %t119 = insertvalue { i64, ptr } %t118, ptr %t108, 1
  %t120 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store ptr %t120, ptr %lp6
  %t122 = load ptr, ptr %lp6
  store { i64, ptr } %t119, ptr %t122, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t123 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t125 = extractvalue { i64, ptr } %t123, 0
  store i64 %t125, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t127 = load i64, ptr %l8, !tbaa !24
  %t128 = load i64, ptr %l7, !tbaa !24
  %t131 = icmp sgt i64 %t127, %t128
  br i1 %t131, label %bb35, label %bb36
bb34:
  call void @__olang_check_failed(ptr @olang_loc_5df9bd969218a728_7fa184e5bc45956c)
  unreachable
bb35:
  %t133 = load i64, ptr %l9, !tbaa !24
  %t135 = icmp sgt i64 %t133, 0
  br i1 %t135, label %bb37, label %bb38
bb36:
  store i64 0, ptr %l59, !tbaa !24
  br label %bb40
bb37:
  %t137 = load i64, ptr %l8, !tbaa !24
  %t138 = load i64, ptr %l7, !tbaa !24
  %t141 = sub i64 %t137, %t138
  %t142 = load i64, ptr %l9, !tbaa !24
  %t145 = add i64 %t141, %t142
  %t147 = sub i64 %t145, 1
  %t148 = load i64, ptr %l9, !tbaa !24
  %t151 = sdiv i64 %t147, %t148
  store i64 %t151, ptr %l62, !tbaa !24
  br label %bb39
bb38:
  store i64 0, ptr %l62, !tbaa !24
  br label %bb39
bb39:
  %t153 = load i64, ptr %l62, !tbaa !24
  store i64 %t153, ptr %l59, !tbaa !24
  br label %bb40
bb40:
  %t154 = load i64, ptr %l59, !tbaa !24
  store i64 %t154, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb41
bb41:
  %t155 = load i64, ptr %l11, !tbaa !24
  %t156 = load i64, ptr %l10, !tbaa !24
  %t159 = icmp slt i64 %t155, %t156
  %t161 = xor i1 %t159, true
  br i1 %t161, label %bb42, label %bb43
bb42:
  br label %bb46
bb43:
  br label %bb44
bb44:
  %t163 = load i64, ptr %l7, !tbaa !24
  %t164 = load i64, ptr %l11, !tbaa !24
  %t165 = load i64, ptr %l9, !tbaa !24
  %t168 = mul i64 %t164, %t165
  %t171 = add i64 %t163, %t168
  store i64 %t171, ptr %l12, !tbaa !24
  %t173 = load i64, ptr %l12, !tbaa !24
  %t174 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t174, ptr %l81, !tbaa !27
  %t175 = load i64, ptr %l12, !tbaa !24
  %t177 = getelementptr { i64, ptr }, ptr %l81, i32 0, i32 1
  %t178 = load ptr, ptr %t177, !tbaa !27
  %t179 = getelementptr i32, ptr %t178, i64 %t175
  %t180 = load i32, ptr %t179, !tbaa !33
  %t182 = load ptr, ptr %lp6
  %t184 = getelementptr { i64, ptr }, ptr %t182, i32 0, i32 1
  %t185 = load ptr, ptr %t184, !tbaa !27
  %t186 = getelementptr i32, ptr %t185, i64 %t173
  store i32 %t180, ptr %t186, !tbaa !33
  br label %bb45
bb45:
  %t187 = load i64, ptr %l11, !tbaa !24
  %t189 = add i64 %t187, 1
  store i64 %t189, ptr %l11, !tbaa !24
  br label %bb41
bb46:
  %t191 = load ptr, ptr %lp6
  %t192 = load { i64, ptr }, ptr %t191, !tbaa !27
  store { i64, ptr } %t192, ptr %rv
  br label %ret
bb47:
  br i1 true, label %bb48, label %bb49
bb48:
  br label %bb50
bb49:
  br label %bb55
bb50:
  %t194 = icmp sge i64 0, 0
  br i1 %t194, label %bb51, label %bb52
bb51:
  %t196 = icmp sle i64 0, 2305843009213693951
  br i1 %t196, label %bb53, label %bb54
bb52:
  call void @__olang_check_failed(ptr @olang_loc_69c4f09cb804b315_a031ca4d3ae928f9)
  unreachable
bb53:
  %t198 = mul i64 0, 4
  %t199 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t198)
  %t200 = insertvalue { i64, ptr } undef, i64 0, 0
  %t201 = insertvalue { i64, ptr } %t200, ptr %t199, 1
  store { i64, ptr } %t201, ptr %rv
  br label %ret
bb54:
  call void @__olang_check_failed(ptr @olang_loc_69c4f09cb804b315_a031ca4d3ae928f9)
  unreachable
bb55:
  call void @__olang_check_failed(ptr @olang_loc_81e6157a61b9a5f1_a0e5ca59452f2055)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fcheck_2epureRead(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca ptr
  %l4 = alloca i1
  %l10 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = call i1 @compiler_2fcheck_2epurePlace(ptr %v0, ptr %t16)
  store i1 %t18, ptr %l10
  br label %bb6
bb6:
  %t19 = load i1, ptr %l10, !tbaa !21
  store i1 %t19, ptr %l2, !tbaa !21
  br label %bb12
bb7:
  br i1 true, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_327c34393f585585_f16c5fd873651789)
  unreachable
bb12:
  %t20 = load i1, ptr %l2, !tbaa !21
  store i1 %t20, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2erefWrittenTop(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca i1
  %l2 = alloca ptr
  %l3 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l2, !tbaa !29
  store i1 false, ptr %l3, !tbaa !21
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store i1 true, ptr %l1, !tbaa !21
  br label %bb11
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i1 false, ptr %l1, !tbaa !21
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_c8609edc258484d8_b7e66af2ba2e899c)
  unreachable
bb11:
  %t10 = load i1, ptr %l1, !tbaa !21
  store i1 %t10, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2estoredTarget(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t17 = load i32, ptr %l2, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H96b7de74ba8f33ba996281c879dd113a(ptr %v1, ptr %t16, i32 %t17, i1 true)
  br label %bb6
bb6:
  br label %bb16
bb7:
  %t20 = load ptr, ptr %l0, !tbaa !29
  store ptr %t20, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t21 = load ptr, ptr %l12, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %bb8, label %bb9
bb8:
  %t24 = load ptr, ptr %l12, !tbaa !29
  %t25 = load i64, ptr %t24
  %t27 = icmp eq i64 %t25, 2
  store i1 %t27, ptr %l13, !tbaa !21
  br label %bb9
bb9:
  %t28 = load i1, ptr %l13, !tbaa !21
  br i1 %t28, label %bb10, label %bb11
bb10:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr { i64, [5 x i64] }, ptr %t29, i32 0, i32 1
  %t32 = getelementptr { %"compiler/source:Span", ptr }, ptr %t31, i32 0, i32 1
  %t33 = load ptr, ptr %t32
  store ptr %t33, ptr %l3, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t35 = load ptr, ptr %l3, !tbaa !29
  %t36 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredTarget(ptr %v0, ptr %v1, ptr %t35, ptr %t36)
  br label %bb13
bb13:
  br label %bb16
bb14:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t39, ptr %t41)
  br label %bb15
bb15:
  br label %bb16
bb16:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fcheck_2etypePathOf(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %lp5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca i1
  %l18 = alloca i32
  %l22 = alloca ptr
  %l23 = alloca i1
  %l31 = alloca { i64, ptr }
  %l38 = alloca i64
  %l47 = alloca i64
  %l50 = alloca i64
  %l69 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  %t24 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t2 = load ptr, ptr %l12, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l12, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l13, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l13, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l1, !tbaa !23
  br label %bb5
bb4:
  br label %bb10
bb5:
  %t16 = load i32, ptr %l1, !tbaa !23
  store i32 %t16, ptr %l18, !tbaa !23
  %t17 = icmp sge i64 1, 0
  br i1 %t17, label %bb6, label %bb7
bb6:
  %t19 = icmp sle i64 1, 2305843009213693951
  br i1 %t19, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_b3d4fbe8a8a5f52e_5afb106a2ffe6622)
  unreachable
bb8:
  %t21 = mul i64 1, 4
  %t22 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t21)
  %t23 = load i32, ptr %l18, !tbaa !23
  store i64 0, ptr %t24
  br label %fill.25
fill.25:
  %t28 = load i64, ptr %t24
  %t29 = icmp slt i64 %t28, 1
  br i1 %t29, label %fillb.26, label %filld.27
fillb.26:
  %t30 = getelementptr i32, ptr %t22, i64 %t28
  store i32 %t23, ptr %t30
  %t31 = add i64 %t28, 1
  store i64 %t31, ptr %t24
  br label %fill.25
filld.27:
  %t32 = insertvalue { i64, ptr } undef, i64 1, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t22, 1
  store { i64, ptr } %t33, ptr %rv
  br label %ret
bb9:
  call void @__olang_check_failed(ptr @olang_loc_b3d4fbe8a8a5f52e_5afb106a2ffe6622)
  unreachable
bb10:
  %t35 = load ptr, ptr %l0, !tbaa !29
  store ptr %t35, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t36 = load ptr, ptr %l22, !tbaa !29
  %t37 = icmp ne ptr %t36, null
  br i1 %t37, label %bb11, label %bb12
bb11:
  %t39 = load ptr, ptr %l22, !tbaa !29
  %t40 = load i64, ptr %t39
  %t42 = icmp eq i64 %t40, 15
  store i1 %t42, ptr %l23, !tbaa !21
  br label %bb12
bb12:
  %t43 = load i1, ptr %l23, !tbaa !21
  br i1 %t43, label %bb13, label %bb14
bb13:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr { i64, [5 x i64] }, ptr %t44, i32 0, i32 1
  %t47 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t46, i32 0, i32 1
  %t48 = load ptr, ptr %t47
  store ptr %t48, ptr %l2, !tbaa !29
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr { i64, [5 x i64] }, ptr %t50, i32 0, i32 1
  %t53 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t52, i32 0, i32 2
  %t54 = load i32, ptr %t53
  store i32 %t54, ptr %l3, !tbaa !23
  br label %bb15
bb14:
  br label %bb36
bb15:
  %t56 = load ptr, ptr %l2, !tbaa !29
  %t58 = call { i64, ptr } @compiler_2fcheck_2etypePathOf(ptr %v0, ptr %t56)
  store { i64, ptr } %t58, ptr %l31
  br label %bb16
bb16:
  %t59 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t59, ptr %l4, !tbaa !27
  %t60 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t62 = extractvalue { i64, ptr } %t60, 0
  %t64 = icmp eq i64 %t62, 0
  br i1 %t64, label %bb17, label %bb18
bb17:
  %t66 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t66, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  %t68 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t70 = extractvalue { i64, ptr } %t68, 0
  %t72 = add i64 %t70, 1
  store i64 %t72, ptr %l38, !tbaa !24
  %t73 = load i64, ptr %l38, !tbaa !24
  %t74 = icmp sge i64 %t73, 0
  br i1 %t74, label %bb20, label %bb21
bb20:
  %t76 = load i64, ptr %l38, !tbaa !24
  %t77 = icmp sle i64 %t76, 2305843009213693951
  br i1 %t77, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_5f893925bf4851a3_7a54563cc3def2d7)
  unreachable
bb22:
  %t79 = load i64, ptr %l38, !tbaa !24
  %t80 = mul i64 %t79, 4
  %t81 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t80)
  %t82 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t83 = insertvalue { i64, ptr } %t82, ptr %t81, 1
  %t84 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store ptr %t84, ptr %lp5
  %t86 = load ptr, ptr %lp5
  store { i64, ptr } %t83, ptr %t86, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t87 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t89 = extractvalue { i64, ptr } %t87, 0
  store i64 %t89, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t91 = load i64, ptr %l7, !tbaa !24
  %t92 = load i64, ptr %l6, !tbaa !24
  %t95 = icmp sgt i64 %t91, %t92
  br i1 %t95, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_5f893925bf4851a3_7a54563cc3def2d7)
  unreachable
bb24:
  %t97 = load i64, ptr %l8, !tbaa !24
  %t99 = icmp sgt i64 %t97, 0
  br i1 %t99, label %bb26, label %bb27
bb25:
  store i64 0, ptr %l47, !tbaa !24
  br label %bb29
bb26:
  %t101 = load i64, ptr %l7, !tbaa !24
  %t102 = load i64, ptr %l6, !tbaa !24
  %t105 = sub i64 %t101, %t102
  %t106 = load i64, ptr %l8, !tbaa !24
  %t109 = add i64 %t105, %t106
  %t111 = sub i64 %t109, 1
  %t112 = load i64, ptr %l8, !tbaa !24
  %t115 = sdiv i64 %t111, %t112
  store i64 %t115, ptr %l50, !tbaa !24
  br label %bb28
bb27:
  store i64 0, ptr %l50, !tbaa !24
  br label %bb28
bb28:
  %t117 = load i64, ptr %l50, !tbaa !24
  store i64 %t117, ptr %l47, !tbaa !24
  br label %bb29
bb29:
  %t118 = load i64, ptr %l47, !tbaa !24
  store i64 %t118, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb30
bb30:
  %t119 = load i64, ptr %l10, !tbaa !24
  %t120 = load i64, ptr %l9, !tbaa !24
  %t123 = icmp slt i64 %t119, %t120
  %t125 = xor i1 %t123, true
  br i1 %t125, label %bb31, label %bb32
bb31:
  br label %bb35
bb32:
  br label %bb33
bb33:
  %t127 = load i64, ptr %l6, !tbaa !24
  %t128 = load i64, ptr %l10, !tbaa !24
  %t129 = load i64, ptr %l8, !tbaa !24
  %t132 = mul i64 %t128, %t129
  %t135 = add i64 %t127, %t132
  store i64 %t135, ptr %l11, !tbaa !24
  %t137 = load i64, ptr %l11, !tbaa !24
  %t138 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t138, ptr %l69, !tbaa !27
  %t139 = load i64, ptr %l11, !tbaa !24
  %t141 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t142 = load ptr, ptr %t141, !tbaa !27
  %t143 = getelementptr i32, ptr %t142, i64 %t139
  %t144 = load i32, ptr %t143, !tbaa !33
  %t146 = load ptr, ptr %lp5
  %t148 = getelementptr { i64, ptr }, ptr %t146, i32 0, i32 1
  %t149 = load ptr, ptr %t148, !tbaa !27
  %t150 = getelementptr i32, ptr %t149, i64 %t137
  store i32 %t144, ptr %t150, !tbaa !33
  br label %bb34
bb34:
  %t151 = load i64, ptr %l10, !tbaa !24
  %t153 = add i64 %t151, 1
  store i64 %t153, ptr %l10, !tbaa !24
  br label %bb30
bb35:
  %t155 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t157 = extractvalue { i64, ptr } %t155, 0
  %t158 = load i32, ptr %l3, !tbaa !23
  %t160 = load ptr, ptr %lp5
  %t162 = getelementptr { i64, ptr }, ptr %t160, i32 0, i32 1
  %t163 = load ptr, ptr %t162, !tbaa !27
  %t164 = getelementptr i32, ptr %t163, i64 %t157
  store i32 %t158, ptr %t164, !tbaa !33
  %t165 = load ptr, ptr %lp5
  %t166 = load { i64, ptr }, ptr %t165, !tbaa !27
  store { i64, ptr } %t166, ptr %rv
  br label %ret
bb36:
  %t168 = icmp sge i64 0, 0
  br i1 %t168, label %bb37, label %bb38
bb37:
  %t170 = icmp sle i64 0, 2305843009213693951
  br i1 %t170, label %bb39, label %bb40
bb38:
  call void @__olang_check_failed(ptr @olang_loc_846f5e9676ec8800_37ad59496399134)
  unreachable
bb39:
  %t172 = mul i64 0, 4
  %t173 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t172)
  %t174 = insertvalue { i64, ptr } undef, i64 0, 0
  %t175 = insertvalue { i64, ptr } %t174, ptr %t173, 1
  store { i64, ptr } %t175, ptr %rv
  br label %ret
bb40:
  call void @__olang_check_failed(ptr @olang_loc_846f5e9676ec8800_37ad59496399134)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i32, i128 } @compiler_2fcheck_2ewideDigits(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l11 = alloca i1
  %l14 = alloca i1
  %l17 = alloca i1
  %l20 = alloca i128
  %l22 = alloca i64
  %l23 = alloca i64
  %l27 = alloca { i64, ptr }
  %l28 = alloca i64
  %l29 = alloca i32
  %l31 = alloca i128
  %l32 = alloca i32
  %l37 = alloca i1
  %l40 = alloca i1
  %l43 = alloca i1
  %l46 = alloca i128
  %l48 = alloca i64
  %l49 = alloca i64
  %l53 = alloca { i64, ptr }
  %l54 = alloca i64
  %l55 = alloca i32
  %l57 = alloca i128
  %l58 = alloca i32
  %l60 = alloca i128
  %l61 = alloca { i64, ptr }
  %l62 = alloca i64
  %l63 = alloca i32
  %l65 = alloca i128
  %l66 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i32, i128 }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d48, i32 0, i32 1) }, ptr %l4, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d49, i32 0, i32 1) }, ptr %l5, !tbaa !27
  %t4 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t6 = call { i64, ptr } @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eReplace_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %a0, { i64, ptr } %t4, { i64, ptr } %t5)
  store { i64, ptr } %t6, ptr %l6
  br label %bb1
bb1:
  %t7 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t7, ptr %l1, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  %t13 = icmp sgt i64 %t11, 2
  br i1 %t13, label %bb2, label %bb3
bb2:
  %t15 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !27
  %t17 = getelementptr i8, ptr %t16, i64 0
  %t18 = load i8, ptr %t17, !tbaa !32
  %t20 = icmp eq i8 %t18, 48
  store i1 %t20, ptr %l11, !tbaa !21
  br label %bb4
bb3:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb4
bb4:
  %t22 = load i1, ptr %l11, !tbaa !21
  br i1 %t22, label %bb5, label %bb6
bb5:
  %t23 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = getelementptr i8, ptr %t24, i64 1
  %t26 = load i8, ptr %t25, !tbaa !32
  %t28 = icmp eq i8 %t26, 120
  br i1 %t28, label %bb7, label %bb8
bb6:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb10
bb7:
  store i1 true, ptr %l17, !tbaa !21
  br label %bb9
bb8:
  %t30 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !27
  %t32 = getelementptr i8, ptr %t31, i64 1
  %t33 = load i8, ptr %t32, !tbaa !32
  %t35 = icmp eq i8 %t33, 88
  store i1 %t35, ptr %l17, !tbaa !21
  br label %bb9
bb9:
  %t37 = load i1, ptr %l17, !tbaa !21
  store i1 %t37, ptr %l14, !tbaa !21
  br label %bb10
bb10:
  %t38 = load i1, ptr %l14, !tbaa !21
  br i1 %t38, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s1
  %t39 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t39, 0
  store i64 %t41, ptr %l22, !tbaa !24
  %t42 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t42, 0
  store i64 %t43, ptr %l23, !tbaa !24
  %t44 = icmp sge i64 2, 0
  br i1 %t44, label %bb13, label %bb14
bb12:
  br label %bb24
bb13:
  %t46 = load i64, ptr %l22, !tbaa !24
  %t47 = icmp sle i64 2, %t46
  br i1 %t47, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_a6a8aee764c9772b_17fecb5b27ccad8f)
  unreachable
bb15:
  %t49 = load i64, ptr %l22, !tbaa !24
  %t50 = load i64, ptr %l23, !tbaa !24
  %t51 = icmp sle i64 %t49, %t50
  br i1 %t51, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_a6a8aee764c9772b_17fecb5b27ccad8f)
  unreachable
bb17:
  %t53 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !27
  %t55 = load i64, ptr %l22, !tbaa !24
  %t56 = getelementptr i8, ptr %t54, i64 2
  %t57 = sub i64 %t55, 2
  %t58 = insertvalue { i64, ptr } undef, i64 %t57, 0
  %t59 = insertvalue { i64, ptr } %t58, ptr %t56, 1
  store { i64, ptr } %t59, ptr %l27, !tbaa !27
  %t60 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s1, i64 16)
  %t61 = extractvalue { i32, i64 } %t60, 1
  %t62 = extractvalue { i32, i64 } %t60, 0
  store i32 %t62, ptr %l29
  %t63 = icmp ne i32 %t62, 0
  br i1 %t63, label %bb20, label %ok.64
ok.64:
  store i64 %t61, ptr %l28
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_a6a8aee764c9772b_17fecb5b27ccad8f)
  unreachable
bb19:
  %t65 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t66 = load i64, ptr %l28, !tbaa !24
  %t67 = call { i32, i128 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseAs_3cU128_3e(ptr %s0, { i64, ptr } %t65, i64 %t66)
  %t68 = extractvalue { i32, i128 } %t67, 1
  %t69 = extractvalue { i32, i128 } %t67, 0
  store i32 %t69, ptr %l32
  %t70 = icmp ne i32 %t69, 0
  br i1 %t70, label %bb22, label %ok.71
ok.71:
  store i128 %t68, ptr %l31
  br label %bb21
bb20:
  %t72 = load i32, ptr %l29, !tbaa !23
  %t73 = lshr i32 %t72, 16
  %t74 = and i32 %t72, 65535
  %t75 = icmp eq i32 %t73, 1
  %t76 = select i1 %t75, i32 0, i32 0
  %t77 = icmp eq i32 %t72, 0
  %t78 = shl i32 %t76, 16
  %t79 = or i32 %t78, %t74
  %t80 = select i1 %t77, i32 0, i32 %t79
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t82 = insertvalue { i32, i128 } zeroinitializer, i32 %t80, 0
  store { i32, i128 } %t82, ptr %rv
  br label %ret
bb21:
  %t83 = load i128, ptr %l31
  store i128 %t83, ptr %l20
  br label %bb23
bb22:
  %t84 = load i32, ptr %l32, !tbaa !23
  %t85 = lshr i32 %t84, 16
  %t86 = and i32 %t84, 65535
  %t87 = icmp eq i32 %t85, 1
  %t88 = select i1 %t87, i32 1, i32 0
  %t89 = icmp eq i32 %t84, 0
  %t90 = shl i32 %t88, 16
  %t91 = or i32 %t90, %t86
  %t92 = select i1 %t89, i32 0, i32 %t91
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t94 = insertvalue { i32, i128 } zeroinitializer, i32 %t92, 0
  store { i32, i128 } %t94, ptr %rv
  br label %ret
bb23:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t95 = load i128, ptr %l20
  %t96 = insertvalue { i32, i128 } zeroinitializer, i128 %t95, 1
  store { i32, i128 } %t96, ptr %rv
  br label %ret
bb24:
  %t97 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t99 = extractvalue { i64, ptr } %t97, 0
  %t101 = icmp sgt i64 %t99, 2
  br i1 %t101, label %bb25, label %bb26
bb25:
  %t103 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t104 = load ptr, ptr %t103, !tbaa !27
  %t105 = getelementptr i8, ptr %t104, i64 0
  %t106 = load i8, ptr %t105, !tbaa !32
  %t108 = icmp eq i8 %t106, 48
  store i1 %t108, ptr %l37, !tbaa !21
  br label %bb27
bb26:
  store i1 false, ptr %l37, !tbaa !21
  br label %bb27
bb27:
  %t110 = load i1, ptr %l37, !tbaa !21
  br i1 %t110, label %bb28, label %bb29
bb28:
  %t111 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !27
  %t113 = getelementptr i8, ptr %t112, i64 1
  %t114 = load i8, ptr %t113, !tbaa !32
  %t116 = icmp eq i8 %t114, 98
  br i1 %t116, label %bb30, label %bb31
bb29:
  store i1 false, ptr %l40, !tbaa !21
  br label %bb33
bb30:
  store i1 true, ptr %l43, !tbaa !21
  br label %bb32
bb31:
  %t118 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t119 = load ptr, ptr %t118, !tbaa !27
  %t120 = getelementptr i8, ptr %t119, i64 1
  %t121 = load i8, ptr %t120, !tbaa !32
  %t123 = icmp eq i8 %t121, 66
  store i1 %t123, ptr %l43, !tbaa !21
  br label %bb32
bb32:
  %t125 = load i1, ptr %l43, !tbaa !21
  store i1 %t125, ptr %l40, !tbaa !21
  br label %bb33
bb33:
  %t126 = load i1, ptr %l40, !tbaa !21
  br i1 %t126, label %bb34, label %bb35
bb34:
  store %olang.scope zeroinitializer, ptr %s2
  %t127 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t129 = extractvalue { i64, ptr } %t127, 0
  store i64 %t129, ptr %l48, !tbaa !24
  %t130 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t131 = extractvalue { i64, ptr } %t130, 0
  store i64 %t131, ptr %l49, !tbaa !24
  %t132 = icmp sge i64 2, 0
  br i1 %t132, label %bb36, label %bb37
bb35:
  br label %bb47
bb36:
  %t134 = load i64, ptr %l48, !tbaa !24
  %t135 = icmp sle i64 2, %t134
  br i1 %t135, label %bb38, label %bb39
bb37:
  call void @__olang_check_failed(ptr @olang_loc_8cde041b4e8c8e2e_cde163ca5cf5392)
  unreachable
bb38:
  %t137 = load i64, ptr %l48, !tbaa !24
  %t138 = load i64, ptr %l49, !tbaa !24
  %t139 = icmp sle i64 %t137, %t138
  br i1 %t139, label %bb40, label %bb41
bb39:
  call void @__olang_check_failed(ptr @olang_loc_8cde041b4e8c8e2e_cde163ca5cf5392)
  unreachable
bb40:
  %t141 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t142 = load ptr, ptr %t141, !tbaa !27
  %t143 = load i64, ptr %l48, !tbaa !24
  %t144 = getelementptr i8, ptr %t142, i64 2
  %t145 = sub i64 %t143, 2
  %t146 = insertvalue { i64, ptr } undef, i64 %t145, 0
  %t147 = insertvalue { i64, ptr } %t146, ptr %t144, 1
  store { i64, ptr } %t147, ptr %l53, !tbaa !27
  %t148 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s2, i64 2)
  %t149 = extractvalue { i32, i64 } %t148, 1
  %t150 = extractvalue { i32, i64 } %t148, 0
  store i32 %t150, ptr %l55
  %t151 = icmp ne i32 %t150, 0
  br i1 %t151, label %bb43, label %ok.152
ok.152:
  store i64 %t149, ptr %l54
  br label %bb42
bb41:
  call void @__olang_check_failed(ptr @olang_loc_8cde041b4e8c8e2e_cde163ca5cf5392)
  unreachable
bb42:
  %t153 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t154 = load i64, ptr %l54, !tbaa !24
  %t155 = call { i32, i128 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseAs_3cU128_3e(ptr %s0, { i64, ptr } %t153, i64 %t154)
  %t156 = extractvalue { i32, i128 } %t155, 1
  %t157 = extractvalue { i32, i128 } %t155, 0
  store i32 %t157, ptr %l58
  %t158 = icmp ne i32 %t157, 0
  br i1 %t158, label %bb45, label %ok.159
ok.159:
  store i128 %t156, ptr %l57
  br label %bb44
bb43:
  %t160 = load i32, ptr %l55, !tbaa !23
  %t161 = lshr i32 %t160, 16
  %t162 = and i32 %t160, 65535
  %t163 = icmp eq i32 %t161, 1
  %t164 = select i1 %t163, i32 0, i32 0
  %t165 = icmp eq i32 %t160, 0
  %t166 = shl i32 %t164, 16
  %t167 = or i32 %t166, %t162
  %t168 = select i1 %t165, i32 0, i32 %t167
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t170 = insertvalue { i32, i128 } zeroinitializer, i32 %t168, 0
  store { i32, i128 } %t170, ptr %rv
  br label %ret
bb44:
  %t171 = load i128, ptr %l57
  store i128 %t171, ptr %l46
  br label %bb46
bb45:
  %t172 = load i32, ptr %l58, !tbaa !23
  %t173 = lshr i32 %t172, 16
  %t174 = and i32 %t172, 65535
  %t175 = icmp eq i32 %t173, 1
  %t176 = select i1 %t175, i32 1, i32 0
  %t177 = icmp eq i32 %t172, 0
  %t178 = shl i32 %t176, 16
  %t179 = or i32 %t178, %t174
  %t180 = select i1 %t177, i32 0, i32 %t179
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t182 = insertvalue { i32, i128 } zeroinitializer, i32 %t180, 0
  store { i32, i128 } %t182, ptr %rv
  br label %ret
bb46:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t183 = load i128, ptr %l46
  %t184 = insertvalue { i32, i128 } zeroinitializer, i128 %t183, 1
  store { i32, i128 } %t184, ptr %rv
  br label %ret
bb47:
  %t185 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t185, ptr %l61, !tbaa !27
  %t186 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s0, i64 10)
  %t187 = extractvalue { i32, i64 } %t186, 1
  %t188 = extractvalue { i32, i64 } %t186, 0
  store i32 %t188, ptr %l63
  %t189 = icmp ne i32 %t188, 0
  br i1 %t189, label %bb49, label %ok.190
ok.190:
  store i64 %t187, ptr %l62
  br label %bb48
bb48:
  %t191 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t192 = load i64, ptr %l62, !tbaa !24
  %t193 = call { i32, i128 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseAs_3cU128_3e(ptr %s0, { i64, ptr } %t191, i64 %t192)
  %t194 = extractvalue { i32, i128 } %t193, 1
  %t195 = extractvalue { i32, i128 } %t193, 0
  store i32 %t195, ptr %l66
  %t196 = icmp ne i32 %t195, 0
  br i1 %t196, label %bb51, label %ok.197
ok.197:
  store i128 %t194, ptr %l65
  br label %bb50
bb49:
  %t198 = load i32, ptr %l63, !tbaa !23
  %t199 = lshr i32 %t198, 16
  %t200 = and i32 %t198, 65535
  %t201 = icmp eq i32 %t199, 1
  %t202 = select i1 %t201, i32 0, i32 0
  %t203 = icmp eq i32 %t198, 0
  %t204 = shl i32 %t202, 16
  %t205 = or i32 %t204, %t200
  %t206 = select i1 %t203, i32 0, i32 %t205
  call void @__olang_scope_close(ptr %s0)
  %t208 = insertvalue { i32, i128 } zeroinitializer, i32 %t206, 0
  store { i32, i128 } %t208, ptr %rv
  br label %ret
bb50:
  %t209 = load i128, ptr %l65
  store i128 %t209, ptr %l60
  br label %bb52
bb51:
  %t210 = load i32, ptr %l66, !tbaa !23
  %t211 = lshr i32 %t210, 16
  %t212 = and i32 %t210, 65535
  %t213 = icmp eq i32 %t211, 1
  %t214 = select i1 %t213, i32 1, i32 0
  %t215 = icmp eq i32 %t210, 0
  %t216 = shl i32 %t214, 16
  %t217 = or i32 %t216, %t212
  %t218 = select i1 %t215, i32 0, i32 %t217
  call void @__olang_scope_close(ptr %s0)
  %t220 = insertvalue { i32, i128 } zeroinitializer, i32 %t218, 0
  store { i32, i128 } %t220, ptr %rv
  br label %ret
bb52:
  call void @__olang_scope_close(ptr %s0)
  %t221 = load i128, ptr %l60
  %t222 = insertvalue { i32, i128 } zeroinitializer, i128 %t221, 1
  store { i32, i128 } %t222, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i128 }, ptr %rv
  ret { i32, i128 } %rr
}

define dso_local %"compiler/check:narrowed" @compiler_2fcheck_3anarrowed_2ector(ptr %v0, i64 %a0, i64 %a1, i32 %a2, i64 %a3, i64 %a4) #0 {
entry:
  %rv = alloca %"compiler/check:narrowed"
  br label %start
start:
  br label %bb0
bb0:
  %t12 = insertvalue %"compiler/check:narrowed" undef, i64 %a0, 0
  %t14 = insertvalue %"compiler/check:narrowed" %t12, i64 %a1, 1
  %t16 = insertvalue %"compiler/check:narrowed" %t14, i32 %a2, 2
  %t18 = insertvalue %"compiler/check:narrowed" %t16, i64 %a3, 3
  %t20 = insertvalue %"compiler/check:narrowed" %t18, i64 %a4, 4
  store %"compiler/check:narrowed" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:narrowed", ptr %rv
  ret %"compiler/check:narrowed" %rr
}

define dso_local %"compiler/check:nullNarrow" @compiler_2fcheck_3anullNarrow_2ector(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i1 %a2) #0 {
entry:
  %rv = alloca %"compiler/check:nullNarrow"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/check:nullNarrow" undef, { i64, ptr } %a0, 0
  %t10 = insertvalue %"compiler/check:nullNarrow" %t8, i64 %a1, 1
  %t12 = insertvalue %"compiler/check:nullNarrow" %t10, i1 %a2, 2
  store %"compiler/check:nullNarrow" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:nullNarrow", ptr %rv
  ret %"compiler/check:nullNarrow" %rr
}

define dso_local %"compiler/check:roArg" @compiler_2fcheck_3aroArg_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, i64 %a0, i64 %a1, { i64, [3 x i64] } %a2, { i64, ptr } %a3, { i64, ptr } %a4, { i64, ptr } %a5) #0 {
entry:
  %rv = alloca %"compiler/check:roArg"
  br label %start
start:
  br label %bb0
bb0:
  %t14 = insertvalue %"compiler/check:roArg" undef, i64 %a0, 0
  %t16 = insertvalue %"compiler/check:roArg" %t14, i64 %a1, 1
  %t18 = insertvalue %"compiler/check:roArg" %t16, { i64, [3 x i64] } %a2, 2
  %t20 = insertvalue %"compiler/check:roArg" %t18, { i64, ptr } %a3, 3
  %t22 = insertvalue %"compiler/check:roArg" %t20, { i64, ptr } %a4, 4
  %t24 = insertvalue %"compiler/check:roArg" %t22, { i64, ptr } %a5, 5
  store %"compiler/check:roArg" %t24, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:roArg", ptr %rv
  ret %"compiler/check:roArg" %rr
}

@__olang_prog_scope = external thread_local(initialexec) global ptr
@.d0 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Plus" }>, align 8
@.d1 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"Minus" }>, align 8
@.d2 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Mul" }>, align 8
@.d3 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Div" }>, align 8
@.d4 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Rem" }>, align 8
@.d5 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"MatMul" }>, align 8
@.d6 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Neg" }>, align 8
@.d7 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Less" }>, align 8
@.d8 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"At" }>, align 8
@.d9 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"SetAt" }>, align 8
@.d10 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"Slice" }>, align 8
@.d11 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"BitAnd" }>, align 8
@.d12 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"BitOr" }>, align 8
@.d13 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"BitXor" }>, align 8
@.d14 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"ShiftLeft" }>, align 8
@.d15 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"ShiftRight" }>, align 8
@.d16 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"BitNot" }>, align 8
@.d17 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Inc" }>, align 8
@.d18 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Dec" }>, align 8
@.d19 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Len" }>, align 8
@.d20 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"Eq" }>, align 8
@.d21 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Str" }>, align 8
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d22 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Str" }>, align 8
@.d23 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"str" }>, align 8
declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@.d24 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"this constructor" }>, align 8
declare void @__olang_check_failed(ptr)
@.d25 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"std/prelude/number" }>, align 8
@.d26 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"NumberError" }>, align 8
@.d27 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"OVERFLOW" }>, align 8
@.d28 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"std/prelude/number" }>, align 8
@.d29 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"NumberError" }>, align 8
@.d30 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"INVALID" }>, align 8
@.d31 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"null" }>, align 8
@.d32 = private constant <{ i64, [63 x i8] }> <{ i64 0, [63 x i8] c"a generic type's constructor with its arguments inferred (G10c)" }>, align 8
@.d33 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"F64" }>, align 8
@.d34 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d35 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d36 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"operator method" }>, align 8
@.d37 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d38 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d39 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
declare void @__olang_ert_req_clear()
@.d40 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d41 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" to " }>, align 8
@.d42 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"true" }>, align 8
@.d43 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Len" }>, align 8
@.d44 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d45 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d46 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d47 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
@.d48 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
@.d49 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@G_2ecompiler_2fcheck_2eLaneArr = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fcheck_2eLaneBin = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fcheck_2eLaneScalar = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/check:opShape" @compiler_2fcheck_3aopShape_2ector(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i1 %a2, i1 %a3)
@G_2ecompiler_2fcheck_2eOpShapes = external constant <{ [8 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [16 x i8] }>
@G_2ecompiler_2fcheck_2eRoGlobal = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/check:litv" @compiler_2fcheck_2enoLit()
declare i1 @compiler_2fcheck_2ebreaks(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2eexprsBreak(ptr %v0, { i64, ptr } %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %a0)
declare { i64, i1 } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnyTableFor(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i64 %a3, %"compiler/source:Span" %a4)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnySlots(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnyStored(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodSig(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i64 @compiler_2fgeneric_2eFnOwner(i64 %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eimplSig(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDefaultAt(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyScopesAgree(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eAnyMethodScopes(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/msgs:Msg" %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteAnyMethod(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoteAt(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, %"compiler/msgs:Msg" %a3)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare %"compiler/generic:AnyTable" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aAnyTable_3e_2eAt__He9601a52fe5cfa5abe1b41d520aed001(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eWritable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erecvReplaced(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enewBody(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, i32 %a2, i64 %a3, %"compiler/source:Span" %a4)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_2ector(ptr %v0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewantStr(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2, i64 %a3)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aBlock(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_Hb3133f486435530b533aaf49461c92b5(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_H64d9be73b6c9bed004c541bdf7f0ca0a(ptr %v0, ptr %a0, i32 %a1, i1 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aStrBody(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %a0)
declare i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %a0)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare %"compiler/generic:Desc" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseDesc(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@G_2ecompiler_2fgeneric_2eDescCase = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enamesEnumOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCaseNames(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecasePublic(ptr %v0, ptr %a0, i32 %a1, i32 %a2, %"compiler/source:Span" %a3)
@olang_loc_da99cffe6602dc08_7fa7c9f5ef49167c = external constant [0 x i8]
@olang_loc_ddff752a05460a27_f846f4bbf4f845eb = external constant [0 x i8]
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epreludeWord(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMeet(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseTypeWritten(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresolve(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnyTrait(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMembers(ptr %v0, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eAnyCaseTwice(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_H2251bc8fca359ca0394d0bb11af7ba0a(ptr %v0, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %a0)
@olang_loc_1b2b22cc85627f3f_81f3e65f4e45ba6b = external constant [0 x i8]
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eB(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eHoldsVarByValue(ptr %v0, ptr %a0, i32 %a1, i64 %a2, i64 %a3, i64 %a4)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v0, i64 %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleft(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eTruncate_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2ftypes_2eVoidT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesFit(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeMismatch(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteFuncTypeScopes(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, [3 x i64] } %a2, %"compiler/msgs:Msg" %a3)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroWritableRef(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2)
@G_2ecompiler_2ftypes_2eNoreturnT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\11\00\00\00" }>, align 8
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare { i64, ptr } @compiler_2fcheck_2ebangOf(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eMayBeNull(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNonNull(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsAny(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eNullT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\0F\00\00\00" }>, align 8
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etoAny(ptr %v0, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayOf(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunadapted(ptr %v0, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/typed:Make" @compiler_2ftyped_3aMake_2ector(ptr %v0, ptr %v1, ptr %v2, i32 %a0, i64 %a1, { i64, ptr } %a2, ptr %a3, i32 %a4, i32 %a5)
declare i1 @compiler_2fcheck_2eisData(ptr %v0, ptr %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esameRepr(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edataLength(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eReadOnly = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare i1 @compiler_2fcheck_2eisArrayMake(ptr %v0, ptr %a0)
declare i1 @compiler_2fcheck_2enamedFn(ptr %v0, ptr %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efuncFits(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i1 %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eadapter(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i64 %a3)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArrayRef(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemptyArray(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNullToArray(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOrNull(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNullToNonNull(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclNote(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFlows(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNumberDoesNotFlow(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eliteralLocalIn(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eliteralLocalNote(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i32 %a3)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eflowsInto(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eReadMaybeNull(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
@olang_loc_6745a459824cdbb9_2d85ba610b532f4d = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ereadPlace(ptr %v0, ptr %a0)
@olang_loc_a4df8c70fd3d792_71930a831bbf5566 = external constant [0 x i8]
declare %"compiler/typed:Try" @compiler_2ftyped_3aTry_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i1 %a2, i1 %a3)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emustWrite(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2, i1 %a3)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroDeepNeed(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlace_26_3e_2eLen_3ccompiler_2ftyped_3aPlace_26_3e(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlace_26_3e_2eAt_3ccompiler_2ftyped_3aPlace_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewithin(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare %"compiler/typed:Promote" @compiler_2ftyped_3aPromote_2ector(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echosenAt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econdChoosesPlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCondLentWritable(ptr %v0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estaticArray(ptr %v0, ptr %a0, ptr %a1, i32 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eforeignRef(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eOwning = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eReadOnlyToWritable(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eArrayRunTimeIntoFixed(ptr %v0, i64 %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eArraySizeMismatch(ptr %v0, i64 %a0, i64 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etyOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCount(ptr %v0, ptr %a0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eHold(ptr %v0, ptr %a0)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eEndHold(ptr %v0, ptr %a0)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eChoose(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eDrop(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopeVarsOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eResultVar = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FF\FF\FF\FF\FF\FF\FF\FF" }>, align 8
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistHoldsInst(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i64 %a3)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econstruct(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, { i64, ptr } %a4)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSelfType(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorSig(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fgeneric_2eDeclOwner(i32 %a0)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclParams(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/generic:Binding" @compiler_2fgeneric_3aBinding_2ector(ptr %v0, i64 %a0, i64 %a1)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ector(ptr %v0, i64 %a0)
declare %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitFloat(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunify(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, ptr %a3, i1 %a4, i1 %a5)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInferThroughBounds(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrVarAt(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrSetOf(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCtorTypeArgsNotInferable(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstance(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstancesMet(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorBody(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eToArra_H50cbff9caa8a2389caf3e92da7e24507(ptr %v0, ptr %v1, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallBody(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, ptr %a4, i64 %a5, ptr %a6, { i64, ptr } %a7, { i64, ptr } %a8)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eDefaultErrT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\10\00\00\00" }>, align 8
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalType(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efield(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, ptr %a3, i32 %a4)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i32 %a3, i32 %a4, i64 %a5)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNamesIdOf(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/check:laneNode" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alaneNode_3e_2eAt_3ccompiler_2fcheck_3alaneNode_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@G_2ecompiler_2ftypes_2eBoolT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eExtends(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fcheck_2eoperatorName(ptr %v0, i32 %a0)
@G_2ecompiler_2fcheck_2eLaneMagic = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\01\00\00" }>, align 8
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alaneNode_3e_2eLen_3ccompiler_2fcheck_3alaneNode_3e(ptr %v0, ptr %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsBy(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i64 %a3)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNumber(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2efloatOverflows(i32 %a0, double %a1)
declare double @compiler_2fcheck_2elitF64(%"compiler/check:litv" %a0)
declare i1 @compiler_2fcheck_2eintFits(ptr %v0, ptr %a0, %"compiler/check:litv" %a1, i32 %a2)
declare %"compiler/typed:Local" @compiler_2ftyped_3aLocal_2ector(ptr %v0, i32 %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3, i32 %a4, { i64, [2 x i64] } %a5)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddLocal(ptr %v0, ptr %a0, %"compiler/typed:Local" %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %a0, i32 %a1)
declare %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" @std_2fpair_3aPair_3ccompiler_2fsource_3aNameId_2c_20I64_3e_2ector(ptr %v0, i32 %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fsource__H6d3eea1e3a905a651c612011755d5d17(ptr %v0, ptr %a0, %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H862756c16d115e5c03a79726209f69fa(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare %"compiler/generic:Desc" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDescOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2fgeneric_2eDescNone = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_H943a9bb03970f71acf57214091669a7d(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %v0, ptr %a0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, [2 x i64] } @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eParamMark(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2ePush_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0, i32 %a1)
declare { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeWrittenAt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fdiag_3aWhere_3e_2e_Hc07a7e56a24d8f1225398db99ea19a4b(ptr %v0, ptr %a0, i64 %a1, { i64, [3 x i64] } %a2)
declare %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsWritable(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasPayload(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/check:reflVal" @compiler_2fcheck_2ervBool(ptr %v0, i1 %a0)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estrBytes(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare %"compiler/check:reflVal" @compiler_2fcheck_2ervText(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/check:reflVal" @compiler_2fcheck_2ervInt(ptr %v0, i64 %a0)
declare %"compiler/check:reflVal" @compiler_2fcheck_2enoRefl(ptr %v0)
declare %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalNamed(ptr %v0, ptr %a0, i32 %a1)
declare { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_Hfd0413fe7fd4e5914f6cad5b418b7a6d(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2fcheck_2eRvBool = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fcheck_2eRvInt = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fcheck_2eRvText = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fcheck_2eRvCase = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
@olang_loc_86ff27eaf091632f_ba308f61bf434c3 = external constant [0 x i8]
declare %"compiler/check:reflList" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { { i64, ptr }, { i64, ptr } } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eReflItems(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i64 %a2, i64 %a3, i64 %a4)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeNamed(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehasCase(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eviaTypeVar(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/check:reflVal" @compiler_2fcheck_3areflVal_2ector(ptr %v0, ptr %v1, i1 %a0, i64 %a1, i64 %a2, { i64, ptr } %a3, i32 %a4)
declare %"compiler/check:reflVal" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflConst(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroByArg(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enamedHolds(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroRef(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aroArg_3e_2ePush_3ccompiler_2fcheck_3aroArg_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/check:roArg" %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparamOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %v0, i64 %a0, i64 %a1)
declare %"std/pair:Pair.b139c4f75a6545712256427180a82a06" @std_2fpair_3aPair_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20std_2fpair_3aPair_3cI64_2c_20I64_3e_3e_2ector(ptr %v0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cstd_2fpair_3aPair__H9be680f663aa81558c844970355ca108(ptr %v0, ptr %a0, %"std/pair:Pair.b139c4f75a6545712256427180a82a06" %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstanceBody(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/check:roDeepArg" @compiler_2fcheck_3aroDeepArg_2ector(ptr %v0, ptr %v1, i64 %a0, ptr %a1, i64 %a2, i64 %a3)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aroDeepArg_3e_2ePush_H0e30e0389c54f9bfc05db61d637e277e(ptr %v0, ptr %v1, ptr %a0, %"compiler/check:roDeepArg" %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroValue(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroName(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroFix(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyOfCallee(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroFollows(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echeckNow(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroCallAt(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eReadOnlyCopyLent(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroKey(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_Hc59e30334647acda8fe9b2b02a632dfd(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, i32 %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroTrack(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare %"std/pair:Pair.1eb2466213689e002f25e81e83536e78" @std_2fpair_3aPair_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_2ector(ptr %v0, ptr %v1, i64 %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20compiler__H316d0dfdbceeb7b188a6719f0ad8fbbe(ptr %v0, ptr %v1, ptr %a0, %"std/pair:Pair.1eb2466213689e002f25e81e83536e78" %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erootLocal(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroLocal(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroNeed(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@G_2ecompiler_2fcheck_2eRoReturned = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@olang_loc_57dc1f8c088d198a_6c44e525bc3c6ade = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eReadOnlyCopyStored(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eReadOnlyCopyDecl(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eReadOnlyCopyReturned(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eReadOnlyCopyGlobal(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_658c1f9b991d3291_83ad80e13fec4285 = external constant [0 x i8]
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoteRo(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteProtocolSpelling(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i32 %a3, i32 %a4)
declare %"compiler/generic:Context" @compiler_2fgeneric_3aContext_2ector(ptr %v0, i64 %a0, i64 %a1)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddBlock(ptr %v0, ptr %a0, i32 %a1, i32 %a2, %"compiler/source:Span" %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erootStmts(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyCaseType(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3, ptr %a4, ptr %a5)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyInstance(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3, i32 %a4)
declare %"compiler/typed:Bind" @compiler_2ftyped_3aBind_2ector(ptr %v0, ptr %v1, i32 %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBind_26_3e_2ePush_3ccompiler_2ftyped_3aBind_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_261e3060da575f7_c13e4a553a852783 = external constant [0 x i8]
@olang_loc_1591269354839ba0_3246c27539059c2c = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egenericNamed(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare %"compiler/check:litv" @compiler_2fcheck_3alitv_2ector(ptr %v0, i1 %a0, i1 %a1, i1 %a2, i64 %a3, double %a4)
@olang_loc_83df14ccfb59caa2_79e7c0956b45666e = external constant [0 x i8]
@olang_loc_c99fc0d93a64b260_1a05e01caddb974 = external constant [0 x i8]
declare %"compiler/check:litv" @compiler_2fcheck_2eintLit(i64 %a0)
declare %"compiler/check:litv" @compiler_2fcheck_2ewideLit(i1 %a0, i128 %a1)
@olang_loc_3043109bf91ec9f6_e521dc8ddba3d97a = external constant [0 x i8]
@olang_loc_4815dd6a844b648b_8f1bd19822fdb0cf = external constant [0 x i8]
@olang_loc_5df9bd969218a728_7fa184e5bc45956c = external constant [0 x i8]
@olang_loc_69c4f09cb804b315_a031ca4d3ae928f9 = external constant [0 x i8]
@olang_loc_81e6157a61b9a5f1_a0e5ca59452f2055 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2epurePlace(ptr %v0, ptr %a0)
@olang_loc_327c34393f585585_f16c5fd873651789 = external constant [0 x i8]
@olang_loc_c8609edc258484d8_b7e66af2ba2e899c = external constant [0 x i8]
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H96b7de74ba8f33ba996281c879dd113a(ptr %v0, ptr %a0, i32 %a1, i1 %a2)
declare void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_b3d4fbe8a8a5f52e_5afb106a2ffe6622 = external constant [0 x i8]
@olang_loc_5f893925bf4851a3_7a54563cc3def2d7 = external constant [0 x i8]
@olang_loc_846f5e9676ec8800_37ad59496399134 = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eReplace_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
@olang_loc_a6a8aee764c9772b_17fecb5b27ccad8f = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %v0, i64 %a0)
declare { i32, i128 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseAs_3cU128_3e(ptr %v0, { i64, ptr } %a0, i64 %a1)
@olang_loc_8cde041b4e8c8e2e_cde163ca5cf5392 = external constant [0 x i8]

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
