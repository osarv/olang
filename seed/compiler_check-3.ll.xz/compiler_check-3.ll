; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/check:Checker" = type { ptr, ptr, i1, i1, i1, i1, i64, i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, { i64, [3 x i64] }, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i32, i64, %"compiler/source:Span", i32, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"compiler/source:Span", i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i32, i1, i1, %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, i32, i32, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i64, i64, i64, i64, i64, i64, i64, i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i1, i1, %"std/prelude/text:StringBuilder", i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/source:Span" = type { i32, i32 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/types:Table" = type { ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64 }
%"compiler/generic:Context" = type { i64, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/msgs:Msg" = type { i32, { i64, ptr }, { i64, ptr } }
%"compiler/typed:Block" = type { i32, { i64, ptr } }
%"compiler/check:ValueAsk" = type { i32, i64, %"compiler/source:Span", i32, i64, { i64, [3 x i64] }, i1, { i64, [3 x i64] } }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/check:frame" = type { i64, i64, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"compiler/generic:Context", i32, i32, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i32, i64, i64, i64, i1, i64, i1, i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i1, i64, i64, i64, i1, i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, i64, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"compiler/source:Span", i64, i1 }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i32, i1, i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/generic:Desc" = type { i64, i32, i64, i64 }
%"compiler/typed:Item" = type { i32, i64 }
%"compiler/ast:Path" = type { %"compiler/source:Span", { i64, ptr } }
%"compiler/typed:Clause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr, { i64, ptr }, i64, i32 }
%"compiler/ast:Catch" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i32, %"compiler/source:Span" }
%"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" = type { i64, i64 }
%"compiler/ast:VarDecl" = type { { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, i1, i1, { i64, ptr }, i1 }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, ptr, i1, i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, { i64, ptr }, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/ast:TypeDecl" = type { i32, { i64, ptr }, i1, ptr, { i64, ptr } }
%"compiler/ast:StructBody" = type { { i64, ptr }, ptr, { i64, ptr }, %"compiler/source:Span", { i64, ptr }, { i64, ptr } }
%"compiler/ast:Param" = type { %"compiler/source:Span", i32, ptr, ptr, { i64, ptr } }
%"compiler/ast:CaseDecl" = type { %"compiler/source:Span", i32, { i64, ptr }, i1, ptr, { i64, ptr } }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1, i1, { i64, ptr } }
%"compiler/ast:Sig" = type { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, i1, ptr, i1, i1 }
%"compiler/ast:ForIn" = type { i32, i32, ptr, i1, { i64, ptr }, { i64, ptr }, i1 }
%"compiler/typed:Payload" = type { ptr, i64, i32 }
%"compiler/typed:Cond" = type { ptr, ptr, ptr }
%"compiler/typed:Seq" = type { { i64, ptr }, ptr }
%"compiler/check:factsMark" = type { i64, i64, i64 }
%"compiler/source:Source" = type { { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/check:Gap" = type { i64, %"compiler/source:Span", { i64, ptr } }
%"compiler/names:Ref" = type { i32, i64, i64 }
%"compiler/check:laneNode" = type { i64, i32, %"compiler/source:Span", %"compiler/source:Span", i64, i64, i64, ptr, i32, i64, i32 }
%"compiler/check:laneVals" = type { i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/typed:If" = type { ptr, ptr, ptr }
%"compiler/typed:Local" = type { i32, %"compiler/source:Span", i32, i32, i32, { i64, [2 x i64] }, i1 }
%"compiler/generic:AnySlot" = type { i32, i32, i64, i64, i1, i32 }
%"compiler/typed:Arm" = type { %"compiler/source:Span", { i64, ptr }, ptr, ptr, ptr }
%"compiler/ast:Match" = type { %"compiler/source:Span", ptr, i1, { i64, ptr } }
%"compiler/check:typeCase" = type { i1, i1, i32, i64, i64, i1 }
%"compiler/ast:Case" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, ptr }
%"compiler/msgs:Nearest" = type { { i64, ptr }, { i64, ptr }, i64 }
%"compiler/check:nullNarrow" = type { { i64, ptr }, i64, i1 }
%"compiler/check:reflVal" = type { i1, i64, i64, { i64, ptr }, i32 }
%"compiler/check:narrowed" = type { i64, i64, i32, i64, i64, i1 }
%"compiler/typed:Call" = type { ptr, { i64, ptr }, { i64, [2 x i64] }, i32, i1, i1 }
%"compiler/typed:Slice" = type { ptr, ptr, ptr, i32 }
%"compiler/ast:TopIf" = type { ptr, ptr, ptr, ptr }
%"compiler/ast:TopBranch" = type { %"compiler/source:Span", { i64, ptr }, i64 }
%"compiler/generic:Binding" = type { i64, i64, { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/check:litv" = type { i1, i1, i1, i64, double, i1, i1, i1, i128 }
%"compiler/check:reflList" = type { i1, i32, i64, i64 }
%"compiler/typed:Make" = type { i32, i64, { i64, ptr }, ptr, i32, i32, i1 }
%"compiler/ast:Compr" = type { ptr, ptr, i32, i32, ptr, ptr, i1, i64 }
%"compiler/check:ContractAsk" = type { i64, i64, %"compiler/source:Span", i64, %"compiler/source:Span", { i64, ptr }, { i64, ptr }, { i64, [3 x i64] }, { i64, ptr }, { i64, ptr } }
%"compiler/check:roFn" = type { i64, i64, { i64, [3 x i64] }, { i64, ptr } }
%"compiler/check:tailAsk" = type { i64, i64, %"compiler/source:Span", i64 }
%"compiler/check:unsetCand" = type { i64, i64, i64, i1, i64, %"compiler/source:Span", i32, i1 }
define dso_local i1 @compiler_2fcheck_2ebadSeparator(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l12 = alloca i64
  %l15 = alloca i64
  %l33 = alloca { i64, ptr }
  %l39 = alloca i1
  %l46 = alloca { i64, ptr }
  %l50 = alloca i1
  %l52 = alloca i1
  %l53 = alloca { i64, ptr }
  %l57 = alloca i1
  %l60 = alloca { i64, ptr }
  %l64 = alloca i1
  %l66 = alloca i1
  %l67 = alloca { i64, ptr }
  %l71 = alloca i1
  %l76 = alloca i1
  %l77 = alloca { i64, ptr }
  %l82 = alloca i1
  %l83 = alloca { i64, ptr }
  %l88 = alloca i1
  %l91 = alloca i1
  %l92 = alloca { i64, ptr }
  %l97 = alloca i1
  %l98 = alloca { i64, ptr }
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l2, !tbaa !24
  store i64 1, ptr %l3, !tbaa !24
  %t5 = load i64, ptr %l2, !tbaa !24
  %t6 = load i64, ptr %l1, !tbaa !24
  %t9 = icmp sgt i64 %t5, %t6
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load i64, ptr %l3, !tbaa !24
  %t13 = icmp sgt i64 %t11, 0
  br i1 %t13, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l12, !tbaa !24
  br label %bb6
bb3:
  %t15 = load i64, ptr %l2, !tbaa !24
  %t16 = load i64, ptr %l1, !tbaa !24
  %t19 = sub i64 %t15, %t16
  %t20 = load i64, ptr %l3, !tbaa !24
  %t23 = add i64 %t19, %t20
  %t25 = sub i64 %t23, 1
  %t26 = load i64, ptr %l3, !tbaa !24
  %t29 = sdiv i64 %t25, %t26
  store i64 %t29, ptr %l15, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l15, !tbaa !24
  br label %bb5
bb5:
  %t31 = load i64, ptr %l15, !tbaa !24
  store i64 %t31, ptr %l12, !tbaa !24
  br label %bb6
bb6:
  %t32 = load i64, ptr %l12, !tbaa !24
  store i64 %t32, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb7
bb7:
  %t33 = load i64, ptr %l5, !tbaa !24
  %t34 = load i64, ptr %l4, !tbaa !24
  %t37 = icmp slt i64 %t33, %t34
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb8, label %bb9
bb8:
  br label %bb55
bb9:
  br label %bb10
bb10:
  %t41 = load i64, ptr %l1, !tbaa !24
  %t42 = load i64, ptr %l5, !tbaa !24
  %t43 = load i64, ptr %l3, !tbaa !24
  %t46 = mul i64 %t42, %t43
  %t49 = add i64 %t41, %t46
  store i64 %t49, ptr %l6, !tbaa !24
  %t51 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t51, ptr %l33, !tbaa !27
  %t52 = load i64, ptr %l6, !tbaa !24
  %t54 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = getelementptr i8, ptr %t55, i64 %t52
  %t57 = load i8, ptr %t56, !tbaa !32
  %t59 = icmp ne i8 %t57, 95
  br i1 %t59, label %bb11, label %bb12
bb11:
  br label %bb54
bb12:
  br label %bb13
bb13:
  %t61 = load i64, ptr %l6, !tbaa !24
  %t63 = icmp eq i64 %t61, 0
  br i1 %t63, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l39, !tbaa !21
  br label %bb16
bb15:
  %t65 = load i64, ptr %l6, !tbaa !24
  %t67 = add i64 %t65, 1
  %t68 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t70 = extractvalue { i64, ptr } %t68, 0
  %t73 = icmp sge i64 %t67, %t70
  store i1 %t73, ptr %l39, !tbaa !21
  br label %bb16
bb16:
  %t75 = load i1, ptr %l39, !tbaa !21
  br i1 %t75, label %bb17, label %bb18
bb17:
  store i1 true, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  %t77 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t77, ptr %l46, !tbaa !27
  %t78 = load i64, ptr %l6, !tbaa !24
  %t80 = sub i64 %t78, 1
  %t82 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !27
  %t84 = getelementptr i8, ptr %t83, i64 %t80
  %t85 = load i8, ptr %t84, !tbaa !32
  %t87 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t85)
  store i1 %t87, ptr %l50
  br label %bb20
bb20:
  %t88 = load i1, ptr %l50, !tbaa !21
  %t89 = xor i1 %t88, true
  br i1 %t89, label %bb21, label %bb22
bb21:
  %t91 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t91, ptr %l53, !tbaa !27
  %t92 = load i64, ptr %l6, !tbaa !24
  %t94 = sub i64 %t92, 1
  %t96 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !27
  %t98 = getelementptr i8, ptr %t97, i64 %t94
  %t99 = load i8, ptr %t98, !tbaa !32
  %t101 = call i1 @compiler_2fcheck_2eisHexDigit(i8 %t99)
  store i1 %t101, ptr %l57
  br label %bb23
bb22:
  store i1 false, ptr %l52, !tbaa !21
  br label %bb24
bb23:
  %t102 = load i1, ptr %l57, !tbaa !21
  %t103 = xor i1 %t102, true
  store i1 %t103, ptr %l52, !tbaa !21
  br label %bb24
bb24:
  %t105 = load i1, ptr %l52, !tbaa !21
  br i1 %t105, label %bb25, label %bb26
bb25:
  store i1 true, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  %t107 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t107, ptr %l60, !tbaa !27
  %t108 = load i64, ptr %l6, !tbaa !24
  %t110 = add i64 %t108, 1
  %t112 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !27
  %t114 = getelementptr i8, ptr %t113, i64 %t110
  %t115 = load i8, ptr %t114, !tbaa !32
  %t117 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t115)
  store i1 %t117, ptr %l64
  br label %bb28
bb28:
  %t118 = load i1, ptr %l64, !tbaa !21
  %t119 = xor i1 %t118, true
  br i1 %t119, label %bb29, label %bb30
bb29:
  %t121 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t121, ptr %l67, !tbaa !27
  %t122 = load i64, ptr %l6, !tbaa !24
  %t124 = add i64 %t122, 1
  %t126 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t127 = load ptr, ptr %t126, !tbaa !27
  %t128 = getelementptr i8, ptr %t127, i64 %t124
  %t129 = load i8, ptr %t128, !tbaa !32
  %t131 = call i1 @compiler_2fcheck_2eisHexDigit(i8 %t129)
  store i1 %t131, ptr %l71
  br label %bb31
bb30:
  store i1 false, ptr %l66, !tbaa !21
  br label %bb32
bb31:
  %t132 = load i1, ptr %l71, !tbaa !21
  %t133 = xor i1 %t132, true
  store i1 %t133, ptr %l66, !tbaa !21
  br label %bb32
bb32:
  %t135 = load i1, ptr %l66, !tbaa !21
  br i1 %t135, label %bb33, label %bb34
bb33:
  store i1 true, ptr %rv
  br label %ret
bb34:
  br label %bb35
bb35:
  %t137 = load i64, ptr %l6, !tbaa !24
  %t139 = icmp sge i64 %t137, 2
  br i1 %t139, label %bb36, label %bb37
bb36:
  %t141 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t141, ptr %l77, !tbaa !27
  %t142 = load i64, ptr %l6, !tbaa !24
  %t144 = sub i64 %t142, 1
  %t146 = getelementptr { i64, ptr }, ptr %l77, i32 0, i32 1
  %t147 = load ptr, ptr %t146, !tbaa !27
  %t148 = getelementptr i8, ptr %t147, i64 %t144
  %t149 = load i8, ptr %t148, !tbaa !32
  %t151 = icmp eq i8 %t149, 120
  store i1 %t151, ptr %l76, !tbaa !21
  br label %bb38
bb37:
  store i1 false, ptr %l76, !tbaa !21
  br label %bb38
bb38:
  %t153 = load i1, ptr %l76, !tbaa !21
  br i1 %t153, label %bb39, label %bb40
bb39:
  %t154 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t154, ptr %l83, !tbaa !27
  %t155 = load i64, ptr %l6, !tbaa !24
  %t157 = sub i64 %t155, 2
  %t159 = getelementptr { i64, ptr }, ptr %l83, i32 0, i32 1
  %t160 = load ptr, ptr %t159, !tbaa !27
  %t161 = getelementptr i8, ptr %t160, i64 %t157
  %t162 = load i8, ptr %t161, !tbaa !32
  %t164 = icmp eq i8 %t162, 48
  store i1 %t164, ptr %l82, !tbaa !21
  br label %bb41
bb40:
  store i1 false, ptr %l82, !tbaa !21
  br label %bb41
bb41:
  %t166 = load i1, ptr %l82, !tbaa !21
  br i1 %t166, label %bb42, label %bb43
bb42:
  store i1 true, ptr %l88, !tbaa !21
  br label %bb50
bb43:
  %t167 = load i64, ptr %l6, !tbaa !24
  %t169 = icmp sge i64 %t167, 2
  br i1 %t169, label %bb44, label %bb45
bb44:
  %t171 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t171, ptr %l92, !tbaa !27
  %t172 = load i64, ptr %l6, !tbaa !24
  %t174 = sub i64 %t172, 1
  %t176 = getelementptr { i64, ptr }, ptr %l92, i32 0, i32 1
  %t177 = load ptr, ptr %t176, !tbaa !27
  %t178 = getelementptr i8, ptr %t177, i64 %t174
  %t179 = load i8, ptr %t178, !tbaa !32
  %t181 = icmp eq i8 %t179, 98
  store i1 %t181, ptr %l91, !tbaa !21
  br label %bb46
bb45:
  store i1 false, ptr %l91, !tbaa !21
  br label %bb46
bb46:
  %t183 = load i1, ptr %l91, !tbaa !21
  br i1 %t183, label %bb47, label %bb48
bb47:
  %t184 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t184, ptr %l98, !tbaa !27
  %t185 = load i64, ptr %l6, !tbaa !24
  %t187 = sub i64 %t185, 2
  %t189 = getelementptr { i64, ptr }, ptr %l98, i32 0, i32 1
  %t190 = load ptr, ptr %t189, !tbaa !27
  %t191 = getelementptr i8, ptr %t190, i64 %t187
  %t192 = load i8, ptr %t191, !tbaa !32
  %t194 = icmp eq i8 %t192, 48
  store i1 %t194, ptr %l97, !tbaa !21
  br label %bb49
bb48:
  store i1 false, ptr %l97, !tbaa !21
  br label %bb49
bb49:
  %t196 = load i1, ptr %l97, !tbaa !21
  store i1 %t196, ptr %l88, !tbaa !21
  br label %bb50
bb50:
  %t197 = load i1, ptr %l88, !tbaa !21
  br i1 %t197, label %bb51, label %bb52
bb51:
  store i1 true, ptr %rv
  br label %ret
bb52:
  br label %bb53
bb53:
  br label %bb54
bb54:
  %t199 = load i64, ptr %l5, !tbaa !24
  %t201 = add i64 %t199, 1
  store i64 %t201, ptr %l5, !tbaa !24
  br label %bb7
bb55:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fcheck_2ebinaryOp(i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca i32
  %rv = alloca i32
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0
  %t3 = trunc i64 52 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  store i32 3, ptr %l1
  br label %bb71
bb4:
  %t7 = load i32, ptr %l0
  %t9 = trunc i64 53 to i32
  %t10 = icmp eq i32 %t7, %t9
  br i1 %t10, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store i32 4, ptr %l1
  br label %bb71
bb8:
  %t13 = load i32, ptr %l0
  %t15 = trunc i64 54 to i32
  %t16 = icmp eq i32 %t13, %t15
  br i1 %t16, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store i32 5, ptr %l1
  br label %bb71
bb12:
  %t19 = load i32, ptr %l0
  %t21 = trunc i64 55 to i32
  %t22 = icmp eq i32 %t19, %t21
  br i1 %t22, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store i32 6, ptr %l1
  br label %bb71
bb16:
  %t25 = load i32, ptr %l0
  %t27 = trunc i64 56 to i32
  %t28 = icmp eq i32 %t25, %t27
  br i1 %t28, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  store i32 7, ptr %l1
  br label %bb71
bb20:
  %t31 = load i32, ptr %l0
  %t33 = trunc i64 88 to i32
  %t34 = icmp eq i32 %t31, %t33
  br i1 %t34, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  store i32 8, ptr %l1
  br label %bb71
bb24:
  %t37 = load i32, ptr %l0
  %t39 = trunc i64 89 to i32
  %t40 = icmp eq i32 %t37, %t39
  br i1 %t40, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  store i32 9, ptr %l1
  br label %bb71
bb28:
  %t43 = load i32, ptr %l0
  %t45 = trunc i64 83 to i32
  %t46 = icmp eq i32 %t43, %t45
  br i1 %t46, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  store i32 10, ptr %l1
  br label %bb71
bb32:
  %t49 = load i32, ptr %l0
  %t51 = trunc i64 84 to i32
  %t52 = icmp eq i32 %t49, %t51
  br i1 %t52, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb36
bb35:
  store i32 11, ptr %l1
  br label %bb71
bb36:
  %t55 = load i32, ptr %l0
  %t57 = trunc i64 85 to i32
  %t58 = icmp eq i32 %t55, %t57
  br i1 %t58, label %bb37, label %bb38
bb37:
  br label %bb41
bb38:
  %t60 = load i32, ptr %l0
  %t62 = trunc i64 47 to i32
  %t63 = icmp eq i32 %t60, %t62
  br i1 %t63, label %bb39, label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb42
bb41:
  store i32 12, ptr %l1
  br label %bb71
bb42:
  %t66 = load i32, ptr %l0
  %t68 = trunc i64 76 to i32
  %t69 = icmp eq i32 %t66, %t68
  br i1 %t69, label %bb43, label %bb44
bb43:
  br label %bb45
bb44:
  br label %bb46
bb45:
  store i32 13, ptr %l1
  br label %bb71
bb46:
  %t72 = load i32, ptr %l0
  %t74 = trunc i64 77 to i32
  %t75 = icmp eq i32 %t72, %t74
  br i1 %t75, label %bb47, label %bb48
bb47:
  br label %bb49
bb48:
  br label %bb50
bb49:
  store i32 14, ptr %l1
  br label %bb71
bb50:
  %t78 = load i32, ptr %l0
  %t80 = trunc i64 79 to i32
  %t81 = icmp eq i32 %t78, %t80
  br i1 %t81, label %bb51, label %bb52
bb51:
  br label %bb53
bb52:
  br label %bb54
bb53:
  store i32 15, ptr %l1
  br label %bb71
bb54:
  %t84 = load i32, ptr %l0
  %t86 = trunc i64 80 to i32
  %t87 = icmp eq i32 %t84, %t86
  br i1 %t87, label %bb55, label %bb56
bb55:
  br label %bb57
bb56:
  br label %bb58
bb57:
  store i32 16, ptr %l1
  br label %bb71
bb58:
  %t90 = load i32, ptr %l0
  %t92 = trunc i64 81 to i32
  %t93 = icmp eq i32 %t90, %t92
  br i1 %t93, label %bb59, label %bb60
bb59:
  br label %bb61
bb60:
  br label %bb62
bb61:
  store i32 17, ptr %l1
  br label %bb71
bb62:
  %t96 = load i32, ptr %l0
  %t98 = trunc i64 82 to i32
  %t99 = icmp eq i32 %t96, %t98
  br i1 %t99, label %bb63, label %bb64
bb63:
  br label %bb65
bb64:
  br label %bb66
bb65:
  store i32 18, ptr %l1
  br label %bb71
bb66:
  br i1 true, label %bb67, label %bb68
bb67:
  br label %bb69
bb68:
  br label %bb70
bb69:
  store i32 3, ptr %l1
  br label %bb71
bb70:
  call void @__olang_check_failed(ptr @olang_loc_b418a15f1455a8e1_40cdd11b1c753e15)
  unreachable
bb71:
  %t103 = load i32, ptr %l1
  store i32 %t103, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fcheck_2ebitOp(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l3 = alloca i1
  %l6 = alloca i1
  %l9 = alloca i1
  %l12 = alloca i1
  %l15 = alloca i1
  %l18 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d0, i32 0, i32 1) })
  store i1 %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load i1, ptr %l3, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb5
bb4:
  store i32 31, ptr %l1
  br label %bb35
bb5:
  %t6 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t8 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t6, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d1, i32 0, i32 1) })
  store i1 %t8, ptr %l6
  br label %bb6
bb6:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i32 32, ptr %l1
  br label %bb35
bb10:
  %t11 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t13 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t11, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d2, i32 0, i32 1) })
  store i1 %t13, ptr %l9
  br label %bb11
bb11:
  %t14 = load i1, ptr %l9, !tbaa !21
  br i1 %t14, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  store i32 33, ptr %l1
  br label %bb35
bb15:
  %t16 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t18 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t16, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d3, i32 0, i32 1) })
  store i1 %t18, ptr %l12
  br label %bb16
bb16:
  %t19 = load i1, ptr %l12, !tbaa !21
  br i1 %t19, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  store i32 34, ptr %l1
  br label %bb35
bb20:
  %t21 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t23 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t21, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d4, i32 0, i32 1) })
  store i1 %t23, ptr %l15
  br label %bb21
bb21:
  %t24 = load i1, ptr %l15, !tbaa !21
  br i1 %t24, label %bb22, label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb25
bb24:
  store i32 35, ptr %l1
  br label %bb35
bb25:
  %t26 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t28 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t26, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d5, i32 0, i32 1) })
  store i1 %t28, ptr %l18
  br label %bb26
bb26:
  %t29 = load i1, ptr %l18, !tbaa !21
  br i1 %t29, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb30
bb29:
  store i32 36, ptr %l1
  br label %bb35
bb30:
  br i1 true, label %bb31, label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb34
bb33:
  store i32 29, ptr %l1
  br label %bb35
bb34:
  call void @__olang_check_failed(ptr @olang_loc_a3fc486149a2dc5d_17491af4361141b9)
  unreachable
bb35:
  call void @__olang_scope_close(ptr %s0)
  %t32 = load i32, ptr %l1
  store i32 %t32, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eBodyOfInstance(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l2 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i32
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/check:Checker", ptr %a0, i32 0, i32 18
  %t7 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t3, i64 %a1)
  %t8 = extractvalue { i32, i64 } %t7, 1
  %t9 = extractvalue { i32, i64 } %t7, 0
  store i32 %t9, ptr %l7
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11, !prof !99
ok.11:
  store i64 %t8, ptr %l6
  br label %bb1
bb1:
  %t12 = load i64, ptr %l6, !tbaa !24
  store i64 %t12, ptr %l2, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l2, !tbaa !24
  br label %bb4
bb4:
  %t13 = load i64, ptr %l2, !tbaa !24
  store i64 %t13, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eInfersErrors(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einfersErrs(ptr %v0, ptr %a0, i32 %a1)
  store i1 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i1, ptr %l4, !tbaa !21
  store i1 %t6, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayOf(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca i32
  %l12 = alloca i32
  %l15 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t6 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t2, i32 %a1)
  store i32 %t6, ptr %l6
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l3, !tbaa !29
  %t8 = load i32, ptr %l6, !tbaa !23
  %t9 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t7, i32 %t8)
  store i32 %t9, ptr %l7
  br label %bb2
bb2:
  %t10 = load i32, ptr %l7, !tbaa !23
  store i32 %t10, ptr %l2, !tbaa !23
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/check:Checker", ptr %t11, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t16 = getelementptr %"compiler/generic:Program", ptr %t14, i32 0, i32 2
  %t17 = load i32, ptr %l2, !tbaa !23
  %t20 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t16, i32 %t17)
  store i32 %t20, ptr %l12
  br label %bb3
bb3:
  %t21 = load i32, ptr %l12
  %t23 = trunc i64 19 to i32
  %t24 = icmp eq i32 %t21, %t23
  br i1 %t24, label %bb4, label %bb5
bb4:
  %t26 = load i32, ptr %l2, !tbaa !23
  store i32 %t26, ptr %l15, !tbaa !23
  br label %bb6
bb5:
  %t28 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t28, ptr %l15, !tbaa !23
  br label %bb6
bb6:
  %t30 = load i32, ptr %l15, !tbaa !23
  store i32 %t30, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2easkValue(ptr %v0, ptr %v1, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, i32 %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca %"compiler/generic:Context"
  %l12 = alloca i64
  %l14 = alloca i64
  %l15 = alloca ptr
  %l18 = alloca i1
  %l21 = alloca i64
  %l23 = alloca i1
  %l30 = alloca i1
  %l33 = alloca i1
  %l42 = alloca i1
  %l45 = alloca i1
  %l46 = alloca i1
  %l48 = alloca ptr
  %l53 = alloca i32
  %l54 = alloca i64
  %l56 = alloca ptr
  %l57 = alloca %"compiler/source:Span"
  %l60 = alloca { i64, ptr }
  %l62 = alloca %"compiler/msgs:Msg"
  %l63 = alloca i64
  %l65 = alloca i64
  %l68 = alloca i64
  %l71 = alloca ptr
  %l78 = alloca ptr
  %l81 = alloca { i64, [2 x i64] }
  %l86 = alloca i32
  %l89 = alloca i64
  %l97 = alloca ptr
  %l101 = alloca ptr
  %l104 = alloca i32
  %l107 = alloca i64
  %l111 = alloca ptr
  %l116 = alloca ptr
  %l120 = alloca ptr
  %l126 = alloca ptr
  %l135 = alloca ptr
  %l136 = alloca ptr
  %l140 = alloca { i64, ptr }
  %l141 = alloca %"compiler/typed:Block"
  %l149 = alloca i64
  %l152 = alloca i1
  %l155 = alloca i64
  %l166 = alloca ptr
  %l169 = alloca ptr
  %l170 = alloca i32
  %l171 = alloca i64
  %l172 = alloca %"compiler/source:Span"
  %l173 = alloca i32
  %l174 = alloca i64
  %l182 = alloca { i64, [3 x i64] }
  %l183 = alloca %"compiler/check:ValueAsk"
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %t140 = alloca { i64, [2 x i64] }, align 8
  %t243 = alloca { i64, [3 x i64] }, align 8
  %t341 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  store i32 %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 103
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb4
bb2:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 14
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_H2251bc8fca359ca0394d0bb11af7ba0a(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l21
  br label %bb3
bb3:
  %t11 = load i64, ptr %l21, !tbaa !24
  %t12 = icmp eq i64 %t11, 0
  store i1 %t12, ptr %l18, !tbaa !21
  br label %bb4
bb4:
  %t14 = load i1, ptr %l18, !tbaa !21
  br i1 %t14, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb7
bb6:
  %t15 = load i32, ptr %l3, !tbaa !23
  %t16 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t19 = icmp eq i32 %t15, %t16
  store i1 %t19, ptr %l23, !tbaa !21
  br label %bb7
bb7:
  %t21 = load i1, ptr %l23, !tbaa !21
  br i1 %t21, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb9:
  br label %bb10
bb10:
  %t22 = load i32, ptr %l1
  %t24 = trunc i64 0 to i32
  %t25 = icmp eq i32 %t22, %t24
  %t27 = xor i1 %t25, true
  br i1 %t27, label %bb11, label %bb12
bb11:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t30 = load i32, ptr %l3, !tbaa !23
  %t33 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ezeroCalls(ptr %v0, ptr %t29, i32 %t30)
  store i1 %t33, ptr %l33
  br label %bb13
bb12:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb14
bb13:
  %t34 = load i1, ptr %l33, !tbaa !21
  %t35 = xor i1 %t34, true
  store i1 %t35, ptr %l30, !tbaa !21
  br label %bb14
bb14:
  %t37 = load i1, ptr %l30, !tbaa !21
  br i1 %t37, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb16:
  br label %bb17
bb17:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/check:Checker", ptr %t38, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t43 = getelementptr %"compiler/generic:Program", ptr %t41, i32 0, i32 0
  %t44 = load ptr, ptr %t43, !tbaa !29
  %t46 = getelementptr %"compiler/load:Loader", ptr %t44, i32 0, i32 4
  %t47 = load ptr, ptr %t46, !tbaa !29
  store ptr %t47, ptr %l5, !tbaa !29
  %t49 = load i32, ptr %l1
  %t51 = trunc i64 0 to i32
  %t52 = icmp eq i32 %t49, %t51
  %t54 = xor i1 %t52, true
  br i1 %t54, label %bb18, label %bb19
bb18:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t57 = load i32, ptr %l3, !tbaa !23
  %t60 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisStruct(ptr %v0, ptr %t56, i32 %t57)
  store i1 %t60, ptr %l45
  br label %bb20
bb19:
  store i1 false, ptr %l42, !tbaa !21
  br label %bb21
bb20:
  %t61 = load i1, ptr %l45, !tbaa !21
  store i1 %t61, ptr %l42, !tbaa !21
  br label %bb21
bb21:
  %t62 = load i1, ptr %l42, !tbaa !21
  br i1 %t62, label %bb22, label %bb23
bb22:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/check:Checker", ptr %t63, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !29
  store ptr %t66, ptr %l48, !tbaa !29
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/check:Checker", ptr %t67, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !29
  %t72 = getelementptr %"compiler/generic:Program", ptr %t70, i32 0, i32 2
  %t73 = load i32, ptr %l3, !tbaa !23
  %t76 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t72, i32 %t73)
  store i32 %t76, ptr %l53
  br label %bb24
bb23:
  store i1 false, ptr %l46, !tbaa !21
  br label %bb26
bb24:
  %t77 = load ptr, ptr %l48, !tbaa !29
  %t78 = load i32, ptr %l53, !tbaa !23
  %t79 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorVars(ptr %v0, ptr %t77, i32 %t78)
  store i64 %t79, ptr %l54
  br label %bb25
bb25:
  %t80 = load i64, ptr %l54, !tbaa !24
  %t81 = icmp sgt i64 %t80, 0
  store i1 %t81, ptr %l46, !tbaa !21
  br label %bb26
bb26:
  %t83 = load i1, ptr %l46, !tbaa !21
  br i1 %t83, label %bb27, label %bb28
bb27:
  store %olang.scope zeroinitializer, ptr %s3
  %t84 = load ptr, ptr %l0, !tbaa !29
  store ptr %t84, ptr %l56, !tbaa !29
  %t85 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t85, ptr %l57
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t87 = load i32, ptr %l3, !tbaa !23
  %t90 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s3, ptr %t86, i32 %t87)
  store { i64, ptr } %t90, ptr %l60
  br label %bb29
bb28:
  br label %bb32
bb29:
  %t91 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t92 = extractvalue { i64, ptr } %t91, 0
  %t93 = extractvalue { i64, ptr } %t91, 1
  %t94 = mul i64 %t92, 1
  %t95 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t94)
  call void @llvm.memcpy.p0.p0.i64(ptr %t95, ptr %t93, i64 %t94, i1 false)
  %t96 = insertvalue { i64, ptr } undef, i64 %t92, 0
  %t97 = insertvalue { i64, ptr } %t96, ptr %t95, 1
  %t99 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoZeroValue(ptr %s3, ptr %s3, ptr %s3, { i64, ptr } %t97, { i64, ptr } { i64 50, ptr getelementptr inbounds (<{ i64, [50 x i8] }>, ptr @.d6, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t99, ptr %l62
  br label %bb30
bb30:
  %t100 = load ptr, ptr %l56, !tbaa !29
  %t101 = load %"compiler/source:Span", ptr %l57
  %t102 = load %"compiler/msgs:Msg", ptr %l62
  %t103 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s3, ptr %t100, %"compiler/source:Span" %t101, %"compiler/msgs:Msg" %t102)
  store i64 %t103, ptr %l63
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb32:
  %t104 = load ptr, ptr %l5, !tbaa !29
  %t106 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCount(ptr %v0, ptr %t104)
  store i64 %t106, ptr %l65
  br label %bb33
bb33:
  %t107 = load i64, ptr %l65, !tbaa !24
  store i64 %t107, ptr %l6, !tbaa !24
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/check:Checker", ptr %t108, i32 0, i32 13
  %t112 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aGap_3e_2eLen_3ccompiler_2fcheck_3aGap_3e(ptr %v0, ptr %t110)
  store i64 %t112, ptr %l68
  br label %bb34
bb34:
  %t113 = load i64, ptr %l68, !tbaa !24
  store i64 %t113, ptr %l7, !tbaa !24
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t116 = getelementptr %"compiler/check:Checker", ptr %t114, i32 0, i32 103
  store i1 true, ptr %t116, !tbaa !21
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t117)
  store ptr %t119, ptr %l71
  br label %bb35
bb35:
  %t120 = load ptr, ptr %l71, !tbaa !29
  store ptr %t120, ptr %l8, !tbaa !29
  %t121 = load ptr, ptr %l8, !tbaa !29
  %t123 = getelementptr %"compiler/check:frame", ptr %t121, i32 0, i32 1
  %t124 = load i64, ptr %t123, !tbaa !24
  store i64 %t124, ptr %l9, !tbaa !24
  %t126 = load ptr, ptr %l8, !tbaa !29
  %t128 = getelementptr %"compiler/check:frame", ptr %t126, i32 0, i32 2
  %t129 = load i64, ptr %t128, !tbaa !24
  store i64 %t129, ptr %l10, !tbaa !24
  %t131 = load ptr, ptr %l8, !tbaa !29
  %t133 = getelementptr %"compiler/check:frame", ptr %t131, i32 0, i32 4
  %t134 = load %"compiler/generic:Context", ptr %t133
  store %"compiler/generic:Context" %t134, ptr %l11
  %t136 = load ptr, ptr %l0, !tbaa !29
  store ptr %t136, ptr %l78, !tbaa !29
  %t137 = load i64, ptr %l9, !tbaa !24
  %t138 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t139 = load i32, ptr %t138, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t140
  %t141 = getelementptr { i64, [2 x i64] }, ptr %t140, i32 0, i32 0
  store i64 7, ptr %t141
  %t143 = insertvalue { i64, i32 } undef, i64 %t137, 0
  %t145 = insertvalue { i64, i32 } %t143, i32 %t139, 1
  %t146 = getelementptr { i64, [2 x i64] }, ptr %t140, i32 0, i32 1
  store { i64, i32 } %t145, ptr %t146
  %t147 = load { i64, [2 x i64] }, ptr %t140
  store { i64, [2 x i64] } %t147, ptr %l81
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t150 = getelementptr %"compiler/check:Checker", ptr %t148, i32 0, i32 1
  %t151 = load ptr, ptr %t150, !tbaa !29
  %t153 = getelementptr %"compiler/generic:Program", ptr %t151, i32 0, i32 2
  %t154 = load i32, ptr %l3, !tbaa !23
  %t157 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t153, i32 0, i32 %t154, i32 0, i32 0, i64 0)
  store i32 %t157, ptr %l86
  br label %bb36
bb36:
  %t158 = load i64, ptr %l9, !tbaa !24
  %t159 = load %"compiler/source:Span", ptr %l2
  %t160 = load ptr, ptr %l78, !tbaa !29
  %t161 = load { i64, [2 x i64] }, ptr %l81
  %t162 = load i32, ptr %l86, !tbaa !23
  %t165 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enewBody(ptr %v0, ptr %t160, { i64, [2 x i64] } %t161, i32 %t162, i64 %t158, %"compiler/source:Span" %t159)
  store i64 %t165, ptr %l89
  br label %bb37
bb37:
  %t166 = load i64, ptr %l89, !tbaa !24
  store i64 %t166, ptr %l12, !tbaa !24
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t169 = getelementptr %"compiler/check:Checker", ptr %t167, i32 0, i32 17
  %t170 = load i64, ptr %l12, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t169, i64 %t170, i64 1)
  br label %bb38
bb38:
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t174 = load i64, ptr %l12, !tbaa !24
  %t175 = load i64, ptr %l9, !tbaa !24
  %t176 = load i32, ptr %l3, !tbaa !23
  %t181 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %t173, i64 %t174, i64 %t175, i32 %t176, i32 0)
  store ptr %t181, ptr %l97
  br label %bb39
bb39:
  %t182 = load ptr, ptr %l97, !tbaa !29
  %t184 = load %"compiler/generic:Context", ptr %l11
  %t187 = getelementptr %"compiler/check:frame", ptr %t182, i32 0, i32 4
  store %"compiler/generic:Context" %t184, ptr %t187
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t190 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t188)
  store ptr %t190, ptr %l101
  br label %bb40
bb40:
  %t191 = load %"compiler/source:Span", ptr %l2
  %t192 = load ptr, ptr %l101, !tbaa !29
  %t195 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddBlock(ptr %v0, ptr %t192, i32 -1, i32 0, %"compiler/source:Span" %t191)
  store i32 %t195, ptr %l104
  br label %bb41
bb41:
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t198 = getelementptr %"compiler/check:Checker", ptr %t196, i32 0, i32 37
  %t200 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t198)
  store i64 %t200, ptr %l107
  br label %bb42
bb42:
  %t201 = load i64, ptr %l107, !tbaa !24
  store i64 %t201, ptr %l14, !tbaa !24
  %t202 = load ptr, ptr %l4, !tbaa !29
  %t204 = icmp eq ptr %t202, null
  %t206 = xor i1 %t204, true
  br i1 %t206, label %bb43, label %bb44
bb43:
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t209 = load ptr, ptr %l4, !tbaa !29
  %t211 = load i32, ptr %l3, !tbaa !23
  %t215 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitCtor(ptr %v0, ptr %v1, ptr %t208, ptr %t209, i32 %t211)
  store ptr %t215, ptr %l116
  br label %bb45
bb44:
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t217 = load %"compiler/source:Span", ptr %l2
  %t218 = load i32, ptr %l3, !tbaa !23
  %t222 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ezero(ptr %v0, ptr %t216, %"compiler/source:Span" %t217, i32 %t218)
  store ptr %t222, ptr %l120
  br label %bb46
bb45:
  %t223 = load ptr, ptr %l116, !tbaa !29
  store ptr %t223, ptr %l111, !tbaa !29
  br label %bb47
bb46:
  %t224 = load ptr, ptr %l120, !tbaa !29
  store ptr %t224, ptr %l111, !tbaa !29
  br label %bb47
bb47:
  %t226 = load ptr, ptr %l111, !tbaa !29
  store ptr %t226, ptr %l15, !tbaa !29
  %t227 = load ptr, ptr %l15, !tbaa !29
  %t229 = icmp eq ptr %t227, null
  br i1 %t229, label %bb48, label %bb49
bb48:
  %t231 = load ptr, ptr %l0, !tbaa !29
  %t232 = load %"compiler/source:Span", ptr %l2
  %t235 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t231, %"compiler/source:Span" %t232)
  store ptr %t235, ptr %l126
  br label %bb50
bb49:
  br label %bb51
bb50:
  %t236 = load ptr, ptr %l126, !tbaa !29
  store ptr %t236, ptr %l15, !tbaa !29
  br label %bb51
bb51:
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t240 = getelementptr %"compiler/check:Checker", ptr %t238, i32 0, i32 37
  %t241 = load %"compiler/source:Span", ptr %l2
  %t242 = load ptr, ptr %l15, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t243
  %t244 = getelementptr { i64, [3 x i64] }, ptr %t243, i32 0, i32 0
  store i64 6, ptr %t244
  %t246 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t241, 0
  %t248 = insertvalue { %"compiler/source:Span", ptr } %t246, ptr %t242, 1
  %t249 = getelementptr { i64, [3 x i64] }, ptr %t243, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t248, ptr %t249
  %t250 = load { i64, [3 x i64] }, ptr %t243
  %t252 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t250, ptr %t252
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t240, ptr %t252)
  br label %bb52
bb52:
  %t255 = load ptr, ptr %l0, !tbaa !29
  %t257 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t255)
  store ptr %t257, ptr %l135
  br label %bb53
bb53:
  %t258 = load ptr, ptr %l135, !tbaa !29
  store ptr %t258, ptr %l136, !tbaa !29
  %t259 = load ptr, ptr %l0, !tbaa !29
  %t261 = getelementptr %"compiler/check:Checker", ptr %t259, i32 0, i32 37
  %t262 = load i64, ptr %l14, !tbaa !24
  %t265 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t261, i64 %t262)
  store { i64, ptr } %t265, ptr %l140
  br label %bb54
bb54:
  %t266 = load { i64, ptr }, ptr %l140, !tbaa !27
  %t267 = call %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v0, i32 0, { i64, ptr } %t266)
  store %"compiler/typed:Block" %t267, ptr %l141
  br label %bb55
bb55:
  %t268 = load %"compiler/typed:Block", ptr %l141
  %t269 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Block" %t268, ptr %t269
  %t271 = load ptr, ptr %l136, !tbaa !29
  %t272 = getelementptr %"compiler/typed:Body", ptr %t271, i32 0, i32 11
  store ptr %t269, ptr %t272, !tbaa !29
  %t273 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t273)
  br label %bb56
bb56:
  %t275 = load ptr, ptr %l0, !tbaa !29
  %t277 = getelementptr %"compiler/check:Checker", ptr %t275, i32 0, i32 17
  %t278 = load i64, ptr %l12, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t277, i64 %t278, i64 2)
  br label %bb57
bb57:
  %t281 = load ptr, ptr %l0, !tbaa !29
  %t283 = getelementptr %"compiler/check:Checker", ptr %t281, i32 0, i32 103
  store i1 false, ptr %t283, !tbaa !21
  %t284 = load ptr, ptr %l5, !tbaa !29
  %t286 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCount(ptr %v0, ptr %t284)
  store i64 %t286, ptr %l149
  br label %bb58
bb58:
  %t287 = load i64, ptr %l6, !tbaa !24
  %t288 = load i64, ptr %l149, !tbaa !24
  %t290 = icmp sgt i64 %t288, %t287
  br i1 %t290, label %bb59, label %bb60
bb59:
  store i1 true, ptr %l152, !tbaa !21
  br label %bb62
bb60:
  %t292 = load ptr, ptr %l0, !tbaa !29
  %t294 = getelementptr %"compiler/check:Checker", ptr %t292, i32 0, i32 13
  %t296 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aGap_3e_2eLen_3ccompiler_2fcheck_3aGap_3e(ptr %v0, ptr %t294)
  store i64 %t296, ptr %l155
  br label %bb61
bb61:
  %t297 = load i64, ptr %l7, !tbaa !24
  %t298 = load i64, ptr %l155, !tbaa !24
  %t300 = icmp sgt i64 %t298, %t297
  store i1 %t300, ptr %l152, !tbaa !21
  br label %bb62
bb62:
  %t302 = load i1, ptr %l152, !tbaa !21
  br i1 %t302, label %bb63, label %bb64
bb63:
  %t303 = load ptr, ptr %l5, !tbaa !29
  %t304 = load i64, ptr %l6, !tbaa !24
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eForget(ptr %v0, ptr %t303, i64 %t304)
  br label %bb65
bb64:
  br label %bb68
bb65:
  %t307 = load ptr, ptr %l0, !tbaa !29
  %t309 = getelementptr %"compiler/check:Checker", ptr %t307, i32 0, i32 13
  %t310 = load i64, ptr %l7, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aGap_3e_2eTruncate_3ccompiler_2fcheck_3aGap_3e(ptr %v0, ptr %t309, i64 %t310)
  br label %bb66
bb66:
  %t313 = load ptr, ptr %l0, !tbaa !29
  %t315 = getelementptr %"compiler/check:Checker", ptr %t313, i32 0, i32 12
  %t316 = load i64, ptr %l12, !tbaa !24
  %t319 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t315, i64 %t316)
  store ptr %t319, ptr %l166
  br label %bb67
bb67:
  %t320 = load ptr, ptr %l166, !tbaa !29
  %t322 = getelementptr %"compiler/typed:Body", ptr %t320, i32 0, i32 11
  store ptr null, ptr %t322, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb68:
  %t323 = load ptr, ptr %l0, !tbaa !29
  %t325 = getelementptr %"compiler/check:Checker", ptr %t323, i32 0, i32 85
  store ptr %t325, ptr %l169, !tbaa !29
  %t326 = load i32, ptr %l1
  store i32 %t326, ptr %l170
  %t327 = load i64, ptr %l10, !tbaa !24
  store i64 %t327, ptr %l171, !tbaa !24
  %t328 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t328, ptr %l172
  %t329 = load i32, ptr %l3, !tbaa !23
  store i32 %t329, ptr %l173, !tbaa !23
  %t330 = load i64, ptr %l12, !tbaa !24
  store i64 %t330, ptr %l174, !tbaa !24
  %t331 = load ptr, ptr %l5, !tbaa !29
  %t332 = load i64, ptr %l10, !tbaa !24
  %t333 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t334 = load i32, ptr %t333, !tbaa !23
  %t336 = sext i32 %t334 to i64
  %t337 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 1
  %t338 = load i32, ptr %t337, !tbaa !23
  %t340 = sext i32 %t338 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t341
  %t342 = getelementptr { i64, [3 x i64] }, ptr %t341, i32 0, i32 0
  store i64 3, ptr %t342
  %t344 = insertvalue { i64, i64, i64 } undef, i64 %t332, 0
  %t346 = insertvalue { i64, i64, i64 } %t344, i64 %t336, 1
  %t348 = insertvalue { i64, i64, i64 } %t346, i64 %t340, 2
  %t349 = getelementptr { i64, [3 x i64] }, ptr %t341, i32 0, i32 1
  store { i64, i64, i64 } %t348, ptr %t349
  %t350 = load { i64, [3 x i64] }, ptr %t341
  %t353 = call { i64, [3 x i64] } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eUseOf(ptr %v0, ptr %t331, { i64, [3 x i64] } %t350)
  store { i64, [3 x i64] } %t353, ptr %l182
  br label %bb69
bb69:
  %t354 = load i32, ptr %l170
  %t355 = load i64, ptr %l171, !tbaa !24
  %t356 = load %"compiler/source:Span", ptr %l172
  %t357 = load i32, ptr %l173, !tbaa !23
  %t358 = load i64, ptr %l174, !tbaa !24
  %t359 = load { i64, [3 x i64] }, ptr %l182
  %t360 = call %"compiler/check:ValueAsk" @compiler_2fcheck_3aValueAsk_2ector(ptr %s0, i32 %t354, i64 %t355, %"compiler/source:Span" %t356, i32 %t357, i64 %t358, { i64, [3 x i64] } %t359)
  store %"compiler/check:ValueAsk" %t360, ptr %l183
  br label %bb70
bb70:
  %t361 = load ptr, ptr %l169, !tbaa !29
  %t362 = load %"compiler/check:ValueAsk", ptr %l183
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aValueAsk_3e_2ePush_3ccompiler_2fcheck_3aValueAsk_3e(ptr %v0, ptr %t361, %"compiler/check:ValueAsk" %t362)
  br label %bb71
bb71:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eblockOf(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca { i64, i64, i64 }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l11 = alloca i64
  %l15 = alloca { i64, i64, i64 }
  %l26 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 37
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l11
  br label %bb1
bb1:
  %t6 = load i64, ptr %l11, !tbaa !24
  store i64 %t6, ptr %l4, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t13 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t7, i32 %a2, %"compiler/source:Span" %a3)
  store { i64, i64, i64 } %t13, ptr %l15
  br label %bb2
bb2:
  %t14 = load { i64, i64, i64 }, ptr %l15
  store { i64, i64, i64 } %t14, ptr %l5
  %t15 = getelementptr { i64, i64, i64 }, ptr %l5, i32 0, i32 0
  %t16 = load i64, ptr %t15, !tbaa !24
  store i64 %t16, ptr %l6, !tbaa !24
  %t18 = getelementptr { i64, i64, i64 }, ptr %l5, i32 0, i32 1
  %t19 = load i64, ptr %t18, !tbaa !24
  store i64 %t19, ptr %l7, !tbaa !24
  %t21 = getelementptr { i64, i64, i64 }, ptr %l5, i32 0, i32 2
  %t22 = load i64, ptr %t21, !tbaa !24
  store i64 %t22, ptr %l8, !tbaa !24
  %t24 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmtsOf(ptr %v0, ptr %v1, ptr %t24, { i64, ptr } %a1)
  br label %bb3
bb3:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load i64, ptr %l6, !tbaa !24
  %t30 = load i64, ptr %l7, !tbaa !24
  %t31 = load i64, ptr %l8, !tbaa !24
  %t32 = load i64, ptr %l4, !tbaa !24
  %t38 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %t28, i64 %t29, i64 %t30, i64 %t31, i64 %t32)
  store ptr %t38, ptr %l26
  br label %bb4
bb4:
  %t39 = load ptr, ptr %l26, !tbaa !29
  store ptr %t39, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseTag(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/generic:Desc"
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca %"compiler/source:Span"
  %l16 = alloca i1
  %l21 = alloca %"compiler/generic:Desc"
  %l30 = alloca i1
  %l31 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca i1
  %l44 = alloca i1
  %l51 = alloca { i64, ptr }
  %l61 = alloca i64
  %l64 = alloca i64
  %l82 = alloca { i64, ptr }
  %l88 = alloca %"compiler/source:Span"
  %l89 = alloca ptr
  %l90 = alloca i32
  %l91 = alloca i32
  %l92 = alloca i32
  %l95 = alloca { i64, ptr }
  %l100 = alloca %"compiler/source:Span"
  %s8 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  %t5 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l16
  br label %bb1
bb1:
  %t6 = load i1, ptr %l16, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  store i64 -1, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load ptr, ptr %l1, !tbaa !29
  %t14 = call %"compiler/generic:Desc" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseDesc(ptr %v0, ptr %v1, ptr %t10, ptr %t11)
  store %"compiler/generic:Desc" %t14, ptr %l21
  br label %bb5
bb5:
  %t15 = load %"compiler/generic:Desc", ptr %l21
  store %"compiler/generic:Desc" %t15, ptr %l3
  %t16 = getelementptr %"compiler/generic:Desc", ptr %l3, i32 0, i32 0
  %t17 = load i64, ptr %t16, !tbaa !24
  %t18 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescCase, !tbaa !24
  %t21 = icmp eq i64 %t17, %t18
  br i1 %t21, label %bb6, label %bb7
bb6:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/check:Checker", ptr %t23, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t28 = getelementptr %"compiler/generic:Program", ptr %t26, i32 0, i32 2
  %t29 = getelementptr %"compiler/generic:Desc", ptr %l3, i32 0, i32 1
  %t30 = load i32, ptr %t29, !tbaa !23
  %t31 = load i32, ptr %l2, !tbaa !23
  %t35 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t28, i32 %t30, i32 %t31)
  store i1 %t35, ptr %l30
  br label %bb8
bb7:
  br label %bb12
bb8:
  %t36 = load i1, ptr %l30, !tbaa !21
  br i1 %t36, label %bb9, label %bb10
bb9:
  %t37 = getelementptr %"compiler/generic:Desc", ptr %l3, i32 0, i32 2
  %t38 = load i64, ptr %t37, !tbaa !24
  store i64 %t38, ptr %l31, !tbaa !24
  br label %bb11
bb10:
  store i64 -1, ptr %l31, !tbaa !24
  br label %bb11
bb11:
  %t40 = load i64, ptr %l31, !tbaa !24
  store i64 %t40, ptr %rv
  br label %ret
bb12:
  %t41 = load ptr, ptr %l1, !tbaa !29
  store ptr %t41, ptr %l33, !tbaa !29
  store i1 false, ptr %l34, !tbaa !21
  %t42 = load ptr, ptr %l33, !tbaa !29
  %t43 = icmp ne ptr %t42, null
  br i1 %t43, label %bb13, label %bb14
bb13:
  %t45 = load ptr, ptr %l33, !tbaa !29
  %t46 = load i64, ptr %t45
  %t48 = icmp eq i64 %t46, 15
  store i1 %t48, ptr %l34, !tbaa !21
  br label %bb14
bb14:
  %t49 = load i1, ptr %l34, !tbaa !21
  br i1 %t49, label %bb15, label %bb16
bb15:
  %t50 = load ptr, ptr %l1, !tbaa !29
  %t52 = getelementptr { i64, [5 x i64] }, ptr %t50, i32 0, i32 1
  %t53 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t52, i32 0, i32 1
  %t54 = load ptr, ptr %t53
  store ptr %t54, ptr %l4, !tbaa !29
  %t56 = load ptr, ptr %l1, !tbaa !29
  %t58 = getelementptr { i64, [5 x i64] }, ptr %t56, i32 0, i32 1
  %t59 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t58, i32 0, i32 2
  %t60 = load i32, ptr %t59
  store i32 %t60, ptr %l5, !tbaa !23
  br label %bb17
bb16:
  br label %bb45
bb17:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load ptr, ptr %l4, !tbaa !29
  %t64 = load i32, ptr %l2, !tbaa !23
  %t68 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enamesEnumOf(ptr %v0, ptr %v1, ptr %t62, ptr %t63, i32 %t64)
  store i1 %t68, ptr %l44
  br label %bb18
bb18:
  %t69 = load i1, ptr %l44, !tbaa !21
  %t70 = xor i1 %t69, true
  br i1 %t70, label %bb19, label %bb20
bb19:
  store i64 -1, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/check:Checker", ptr %t73, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !29
  %t78 = getelementptr %"compiler/generic:Program", ptr %t76, i32 0, i32 2
  %t79 = load i32, ptr %l2, !tbaa !23
  %t82 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCaseNames(ptr %v0, ptr %t78, i32 %t79)
  store { i64, ptr } %t82, ptr %l51
  br label %bb22
bb22:
  %t83 = load { i64, ptr }, ptr %l51, !tbaa !27
  store { i64, ptr } %t83, ptr %l6, !tbaa !27
  %t84 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t84, 0
  %t88 = icmp eq i64 %t86, 0
  br i1 %t88, label %bb23, label %bb24
bb23:
  store i64 -1, ptr %rv
  br label %ret
bb24:
  br label %bb25
bb25:
  store i64 0, ptr %l7, !tbaa !24
  %t91 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t93 = extractvalue { i64, ptr } %t91, 0
  store i64 %t93, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t95 = load i64, ptr %l8, !tbaa !24
  %t96 = load i64, ptr %l7, !tbaa !24
  %t99 = icmp sgt i64 %t95, %t96
  br i1 %t99, label %bb26, label %bb27
bb26:
  %t101 = load i64, ptr %l9, !tbaa !24
  %t103 = icmp sgt i64 %t101, 0
  br i1 %t103, label %bb28, label %bb29
bb27:
  store i64 0, ptr %l61, !tbaa !24
  br label %bb31
bb28:
  %t105 = load i64, ptr %l8, !tbaa !24
  %t106 = load i64, ptr %l7, !tbaa !24
  %t109 = sub i64 %t105, %t106
  %t110 = load i64, ptr %l9, !tbaa !24
  %t113 = add i64 %t109, %t110
  %t115 = sub i64 %t113, 1
  %t116 = load i64, ptr %l9, !tbaa !24
  %t119 = sdiv i64 %t115, %t116
  store i64 %t119, ptr %l64, !tbaa !24
  br label %bb30
bb29:
  store i64 0, ptr %l64, !tbaa !24
  br label %bb30
bb30:
  %t121 = load i64, ptr %l64, !tbaa !24
  store i64 %t121, ptr %l61, !tbaa !24
  br label %bb31
bb31:
  %t122 = load i64, ptr %l61, !tbaa !24
  store i64 %t122, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb32
bb32:
  %t123 = load i64, ptr %l11, !tbaa !24
  %t124 = load i64, ptr %l10, !tbaa !24
  %t127 = icmp slt i64 %t123, %t124
  %t129 = xor i1 %t127, true
  br i1 %t129, label %bb33, label %bb34
bb33:
  br label %bb44
bb34:
  br label %bb35
bb35:
  %t131 = load i64, ptr %l7, !tbaa !24
  %t132 = load i64, ptr %l11, !tbaa !24
  %t133 = load i64, ptr %l9, !tbaa !24
  %t136 = mul i64 %t132, %t133
  %t139 = add i64 %t131, %t136
  store i64 %t139, ptr %l12, !tbaa !24
  %t141 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t141, ptr %l82, !tbaa !27
  %t142 = load i64, ptr %l12, !tbaa !24
  %t144 = getelementptr { i64, ptr }, ptr %l82, i32 0, i32 1
  %t145 = load ptr, ptr %t144, !tbaa !27
  %t146 = getelementptr i32, ptr %t145, i64 %t142
  %t147 = load i32, ptr %t146, !tbaa !33
  %t148 = load i32, ptr %l5, !tbaa !23
  %t151 = icmp eq i32 %t147, %t148
  br i1 %t151, label %bb36, label %bb37
bb36:
  store %olang.scope zeroinitializer, ptr %s8
  %t153 = load ptr, ptr %l1, !tbaa !29
  %t155 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t153)
  store %"compiler/source:Span" %t155, ptr %l88
  br label %bb38
bb37:
  br label %bb42
bb38:
  %t156 = load %"compiler/source:Span", ptr %l88
  store %"compiler/source:Span" %t156, ptr %l13
  %t157 = load ptr, ptr %l0, !tbaa !29
  store ptr %t157, ptr %l89, !tbaa !29
  %t158 = load i32, ptr %l2, !tbaa !23
  store i32 %t158, ptr %l90, !tbaa !23
  %t159 = load i32, ptr %l5, !tbaa !23
  store i32 %t159, ptr %l91, !tbaa !23
  %t160 = getelementptr %"compiler/source:Span", ptr %l13, i32 0, i32 1
  %t161 = load i32, ptr %t160, !tbaa !23
  store i32 %t161, ptr %l92, !tbaa !23
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t163 = load i32, ptr %l5, !tbaa !23
  %t166 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t162, i32 %t163)
  store { i64, ptr } %t166, ptr %l95
  br label %bb39
bb39:
  %t167 = load { i64, ptr }, ptr %l95, !tbaa !27
  %t168 = extractvalue { i64, ptr } %t167, 0
  %t170 = trunc i64 %t168 to i32
  %t171 = load i32, ptr %l92, !tbaa !23
  %t173 = sub i32 %t171, %t170
  %t174 = getelementptr %"compiler/source:Span", ptr %l13, i32 0, i32 1
  %t175 = load i32, ptr %t174, !tbaa !23
  %t178 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s8, i32 %t173, i32 %t175)
  store %"compiler/source:Span" %t178, ptr %l100
  br label %bb40
bb40:
  %t179 = load ptr, ptr %l89, !tbaa !29
  %t180 = load i32, ptr %l90, !tbaa !23
  %t181 = load i32, ptr %l91, !tbaa !23
  %t182 = load %"compiler/source:Span", ptr %l100
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecasePublic(ptr %v0, ptr %t179, i32 %t180, i32 %t181, %"compiler/source:Span" %t182)
  br label %bb41
bb41:
  %t183 = load i64, ptr %l12, !tbaa !24
  call void @__olang_scope_close(ptr %s8)
  store i64 %t183, ptr %rv
  br label %ret
bb42:
  br label %bb43
bb43:
  %t185 = load i64, ptr %l11, !tbaa !24
  %t187 = add i64 %t185, 1
  store i64 %t187, ptr %l11, !tbaa !24
  br label %bb32
bb44:
  store i64 -1, ptr %rv
  br label %ret
bb45:
  br i1 true, label %bb46, label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb49
bb48:
  store i64 -1, ptr %rv
  br label %ret
bb49:
  call void @__olang_check_failed(ptr @olang_loc_276be77200b53441_cc6e235db38ae28d)
  unreachable
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecatchItem(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i32
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i32
  %l16 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l17 = alloca ptr
  %l18 = alloca i64
  %l19 = alloca i32
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca { i64, i32 }
  %l28 = alloca i64
  %l29 = alloca i32
  %l34 = alloca i1
  %l36 = alloca ptr
  %l40 = alloca { i64, ptr }
  %l42 = alloca i1
  %l44 = alloca ptr
  %l46 = alloca ptr
  %l50 = alloca i32
  %l55 = alloca i32
  %l60 = alloca ptr
  %l65 = alloca i32
  %l66 = alloca { i64, ptr }
  %l73 = alloca { i64, ptr }
  %l80 = alloca i32
  %l87 = alloca i64
  %l91 = alloca i64
  %l94 = alloca i64
  %l113 = alloca i64
  %l117 = alloca ptr
  %l122 = alloca i32
  %l124 = alloca %"compiler/typed:Item"
  %l131 = alloca i32
  %l134 = alloca ptr
  %l136 = alloca %"compiler/typed:Item"
  %l142 = alloca i1
  %l144 = alloca ptr
  %l146 = alloca ptr
  %l150 = alloca i32
  %l157 = alloca i1
  %l159 = alloca ptr
  %l161 = alloca %"compiler/typed:Item"
  %l162 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l168 = alloca i64
  %l170 = alloca i64
  %l175 = alloca i32
  %l183 = alloca i32
  %l187 = alloca ptr
  %l189 = alloca %"compiler/typed:Item"
  %l194 = alloca i64
  %l198 = alloca i64
  %l201 = alloca i64
  %l220 = alloca i64
  %l224 = alloca ptr
  %l229 = alloca i32
  %l231 = alloca %"compiler/typed:Item"
  %l238 = alloca { i64, i32 }
  %l244 = alloca ptr
  %l246 = alloca ptr
  %l250 = alloca i1
  %l251 = alloca ptr
  %l254 = alloca %"compiler/typed:Item"
  %s0 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s22 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Path", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp eq i64 %t6, 1
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t10)
  store ptr %t12, ptr %l36
  br label %bb3
bb2:
  store i1 false, ptr %l34, !tbaa !21
  br label %bb5
bb3:
  %t13 = load ptr, ptr %l36, !tbaa !29
  %t15 = getelementptr %"compiler/check:frame", ptr %t13, i32 0, i32 4
  %t16 = getelementptr %"compiler/generic:Context", ptr %t15, i32 0, i32 2
  %t17 = load ptr, ptr %l1, !tbaa !29
  %t19 = getelementptr %"compiler/ast:Path", ptr %t17, i32 0, i32 1
  %t20 = load { i64, ptr }, ptr %t19, !tbaa !27
  store { i64, ptr } %t20, ptr %l40, !tbaa !27
  %t21 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr i32, ptr %t22, i64 0
  %t24 = load i32, ptr %t23, !tbaa !33
  %t27 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_He6be2b0836caba7ddc59483ff74db438(ptr %v0, ptr %t16, i32 %t24)
  store i1 %t27, ptr %l42
  br label %bb4
bb4:
  %t28 = load i1, ptr %l42, !tbaa !21
  store i1 %t28, ptr %l34, !tbaa !21
  br label %bb5
bb5:
  %t29 = load i1, ptr %l34, !tbaa !21
  br i1 %t29, label %bb6, label %bb7
bb6:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/check:Checker", ptr %t30, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !29
  store ptr %t33, ptr %l44, !tbaa !29
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t34)
  store ptr %t36, ptr %l46
  br label %bb8
bb7:
  br label %bb55
bb8:
  %t37 = load ptr, ptr %l46, !tbaa !29
  %t39 = getelementptr %"compiler/check:frame", ptr %t37, i32 0, i32 4
  %t40 = load ptr, ptr %l1, !tbaa !29
  %t41 = load ptr, ptr %l44, !tbaa !29
  %t44 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorSetItem(ptr %v0, ptr %v0, ptr %v1, ptr %t41, ptr %t39, ptr %t40)
  store i32 %t44, ptr %l50
  br label %bb9
bb9:
  %t45 = load i32, ptr %l50, !tbaa !23
  store i32 %t45, ptr %l3, !tbaa !23
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/check:Checker", ptr %t46, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t51 = getelementptr %"compiler/generic:Program", ptr %t49, i32 0, i32 2
  %t52 = load i32, ptr %l3, !tbaa !23
  %t55 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t51, i32 %t52)
  store i32 %t55, ptr %l55
  br label %bb10
bb10:
  %t56 = load i32, ptr %l55
  %t58 = trunc i64 30 to i32
  %t59 = icmp eq i32 %t56, %t58
  br i1 %t59, label %bb11, label %bb12
bb11:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/check:Checker", ptr %t61, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !29
  %t66 = getelementptr %"compiler/generic:Program", ptr %t64, i32 0, i32 2
  store ptr %t66, ptr %l60, !tbaa !29
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/check:Checker", ptr %t67, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !29
  %t72 = getelementptr %"compiler/generic:Program", ptr %t70, i32 0, i32 2
  %t73 = load i32, ptr %l3, !tbaa !23
  %t76 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrSetItems(ptr %v0, ptr %t72, i32 %t73)
  store i32 %t76, ptr %l65
  br label %bb13
bb12:
  br label %bb50
bb13:
  %t77 = load ptr, ptr %l60, !tbaa !29
  %t78 = load i32, ptr %l65, !tbaa !23
  %t79 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t77, i32 %t78)
  store { i64, ptr } %t79, ptr %l66
  br label %bb14
bb14:
  %t80 = load { i64, ptr }, ptr %l66, !tbaa !27
  store { i64, ptr } %t80, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t81 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t83 = extractvalue { i64, ptr } %t81, 0
  store i64 %t83, ptr %l6, !tbaa !24
  br label %bb15
bb15:
  %t85 = load i64, ptr %l5, !tbaa !24
  %t86 = load i64, ptr %l6, !tbaa !24
  %t89 = icmp slt i64 %t85, %t86
  %t91 = xor i1 %t89, true
  br i1 %t91, label %bb16, label %bb17
bb16:
  br label %bb49
bb17:
  br label %bb18
bb18:
  %t93 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t93, ptr %l73, !tbaa !27
  %t94 = load i64, ptr %l5, !tbaa !24
  %t96 = getelementptr { i64, ptr }, ptr %l73, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !27
  %t98 = getelementptr i32, ptr %t97, i64 %t94
  %t99 = load i32, ptr %t98, !tbaa !33
  store i32 %t99, ptr %l7, !tbaa !23
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr %"compiler/check:Checker", ptr %t101, i32 0, i32 1
  %t104 = load ptr, ptr %t103, !tbaa !29
  %t106 = getelementptr %"compiler/generic:Program", ptr %t104, i32 0, i32 2
  %t107 = load i32, ptr %l7, !tbaa !23
  %t110 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t106, i32 %t107)
  store i32 %t110, ptr %l80
  br label %bb19
bb19:
  %t111 = load i32, ptr %l80
  %t113 = trunc i64 28 to i32
  %t114 = icmp eq i32 %t111, %t113
  br i1 %t114, label %bb20, label %bb21
bb20:
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t118 = getelementptr %"compiler/check:Checker", ptr %t116, i32 0, i32 1
  %t119 = load ptr, ptr %t118, !tbaa !29
  %t121 = getelementptr %"compiler/generic:Program", ptr %t119, i32 0, i32 2
  %t122 = load i32, ptr %l7, !tbaa !23
  %t125 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %t121, i32 %t122)
  store i64 %t125, ptr %l87
  br label %bb22
bb21:
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t128 = getelementptr %"compiler/check:Checker", ptr %t126, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !29
  %t131 = getelementptr %"compiler/generic:Program", ptr %t129, i32 0, i32 2
  %t132 = load i32, ptr %l7, !tbaa !23
  %t135 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t131, i32 %t132)
  store i32 %t135, ptr %l131
  br label %bb41
bb22:
  %t136 = load i64, ptr %l87, !tbaa !65
  store i64 %t136, ptr %l8, !tbaa !65
  store i64 0, ptr %l9, !tbaa !24
  store i64 64, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t137 = load i64, ptr %l10, !tbaa !24
  %t138 = load i64, ptr %l9, !tbaa !24
  %t141 = icmp sgt i64 %t137, %t138
  br i1 %t141, label %bb23, label %bb24
bb23:
  %t143 = load i64, ptr %l11, !tbaa !24
  %t145 = icmp sgt i64 %t143, 0
  br i1 %t145, label %bb25, label %bb26
bb24:
  store i64 0, ptr %l91, !tbaa !24
  br label %bb28
bb25:
  %t147 = load i64, ptr %l10, !tbaa !24
  %t148 = load i64, ptr %l9, !tbaa !24
  %t151 = sub i64 %t147, %t148
  %t152 = load i64, ptr %l11, !tbaa !24
  %t155 = add i64 %t151, %t152
  %t157 = sub i64 %t155, 1
  %t158 = load i64, ptr %l11, !tbaa !24
  %t161 = sdiv i64 %t157, %t158
  store i64 %t161, ptr %l94, !tbaa !24
  br label %bb27
bb26:
  store i64 0, ptr %l94, !tbaa !24
  br label %bb27
bb27:
  %t163 = load i64, ptr %l94, !tbaa !24
  store i64 %t163, ptr %l91, !tbaa !24
  br label %bb28
bb28:
  %t164 = load i64, ptr %l91, !tbaa !24
  store i64 %t164, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb29
bb29:
  %t165 = load i64, ptr %l13, !tbaa !24
  %t166 = load i64, ptr %l12, !tbaa !24
  %t169 = icmp slt i64 %t165, %t166
  %t171 = xor i1 %t169, true
  br i1 %t171, label %bb30, label %bb31
bb30:
  br label %bb40
bb31:
  br label %bb32
bb32:
  %t173 = load i64, ptr %l9, !tbaa !24
  %t174 = load i64, ptr %l13, !tbaa !24
  %t175 = load i64, ptr %l11, !tbaa !24
  %t178 = mul i64 %t174, %t175
  %t181 = add i64 %t173, %t178
  store i64 %t181, ptr %l14, !tbaa !24
  %t183 = load i64, ptr %l8, !tbaa !65
  %t184 = load i64, ptr %l14, !tbaa !24
  store i64 %t184, ptr %l113, !tbaa !24
  %t185 = load i64, ptr %l113, !tbaa !24
  %t186 = load i64, ptr %l113, !tbaa !24
  %t187 = shl i64 1, %t186
  %t190 = and i64 %t183, %t187
  %t192 = icmp ne i64 %t190, 0
  br i1 %t192, label %bb33, label %bb34
bb33:
  store %olang.scope zeroinitializer, ptr %s8
  %t194 = load ptr, ptr %l2, !tbaa !29
  store ptr %t194, ptr %l117, !tbaa !29
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t197 = getelementptr %"compiler/check:Checker", ptr %t195, i32 0, i32 1
  %t198 = load ptr, ptr %t197, !tbaa !29
  %t200 = getelementptr %"compiler/generic:Program", ptr %t198, i32 0, i32 2
  %t201 = load i32, ptr %l7, !tbaa !23
  %t204 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t200, i32 %t201)
  store i32 %t204, ptr %l122
  br label %bb35
bb34:
  br label %bb38
bb35:
  %t205 = load i64, ptr %l14, !tbaa !24
  %t206 = load i32, ptr %l122, !tbaa !23
  %t208 = call %"compiler/typed:Item" @compiler_2ftyped_3aItem_2ector(ptr %s8, i32 %t206, i64 %t205)
  store %"compiler/typed:Item" %t208, ptr %l124
  br label %bb36
bb36:
  %t209 = load ptr, ptr %l117, !tbaa !29
  %t210 = load %"compiler/typed:Item", ptr %l124
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aItem_3e_2ePush_3ccompiler_2ftyped_3aItem_3e(ptr %v2, ptr %t209, %"compiler/typed:Item" %t210)
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s8)
  br label %bb38
bb38:
  br label %bb39
bb39:
  %t211 = load i64, ptr %l13, !tbaa !24
  %t213 = add i64 %t211, 1
  store i64 %t213, ptr %l13, !tbaa !24
  br label %bb29
bb40:
  br label %bb47
bb41:
  %t215 = load i32, ptr %l131
  %t217 = trunc i64 18 to i32
  %t218 = icmp eq i32 %t215, %t217
  br i1 %t218, label %bb42, label %bb43
bb42:
  store %olang.scope zeroinitializer, ptr %s11
  %t220 = load ptr, ptr %l2, !tbaa !29
  store ptr %t220, ptr %l134, !tbaa !29
  %t221 = load i32, ptr %l7, !tbaa !23
  %t223 = call %"compiler/typed:Item" @compiler_2ftyped_3aItem_2ector(ptr %s11, i32 %t221, i64 -1)
  store %"compiler/typed:Item" %t223, ptr %l136
  br label %bb44
bb43:
  br label %bb46
bb44:
  %t224 = load ptr, ptr %l134, !tbaa !29
  %t225 = load %"compiler/typed:Item", ptr %l136
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aItem_3e_2ePush_3ccompiler_2ftyped_3aItem_3e(ptr %v2, ptr %t224, %"compiler/typed:Item" %t225)
  br label %bb45
bb45:
  call void @__olang_scope_close(ptr %s11)
  br label %bb46
bb46:
  br label %bb47
bb47:
  br label %bb48
bb48:
  %t226 = load i64, ptr %l5, !tbaa !24
  %t228 = add i64 %t226, 1
  store i64 %t228, ptr %l5, !tbaa !24
  br label %bb15
bb49:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb50:
  %t230 = load ptr, ptr %l0, !tbaa !29
  %t232 = getelementptr %"compiler/check:Checker", ptr %t230, i32 0, i32 1
  %t233 = load ptr, ptr %t232, !tbaa !29
  %t234 = load i32, ptr %l3, !tbaa !23
  %t237 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsErrVar(ptr %v0, ptr %t233, i32 %t234)
  store i1 %t237, ptr %l142
  br label %bb51
bb51:
  %t238 = load i1, ptr %l142, !tbaa !21
  br i1 %t238, label %bb52, label %bb53
bb52:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb53:
  br label %bb54
bb54:
  br label %bb55
bb55:
  %t239 = load ptr, ptr %l0, !tbaa !29
  %t241 = getelementptr %"compiler/check:Checker", ptr %t239, i32 0, i32 1
  %t242 = load ptr, ptr %t241, !tbaa !29
  store ptr %t242, ptr %l144, !tbaa !29
  %t243 = load ptr, ptr %l0, !tbaa !29
  %t245 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t243)
  store ptr %t245, ptr %l146
  br label %bb56
bb56:
  %t246 = load ptr, ptr %l146, !tbaa !29
  %t248 = getelementptr %"compiler/check:frame", ptr %t246, i32 0, i32 4
  %t249 = load ptr, ptr %l1, !tbaa !29
  %t250 = load ptr, ptr %l144, !tbaa !29
  %t253 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorType(ptr %v0, ptr %v0, ptr %v1, ptr %t250, ptr %t248, ptr %t249)
  store i32 %t253, ptr %l150
  br label %bb57
bb57:
  %t254 = load i32, ptr %l150, !tbaa !23
  store i32 %t254, ptr %l15, !tbaa !23
  %t255 = load i32, ptr %l15, !tbaa !23
  %t256 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t259 = icmp ne i32 %t255, %t256
  br i1 %t259, label %bb58, label %bb59
bb58:
  store %olang.scope zeroinitializer, ptr %s14
  %t261 = load ptr, ptr %l0, !tbaa !29
  %t263 = getelementptr %"compiler/check:Checker", ptr %t261, i32 0, i32 1
  %t264 = load ptr, ptr %t263, !tbaa !29
  %t265 = load i32, ptr %l15, !tbaa !23
  %t268 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsErrorSet(ptr %v0, ptr %t264, i32 %t265)
  store i1 %t268, ptr %l157
  br label %bb60
bb59:
  br label %bb104
bb60:
  %t269 = load i1, ptr %l157, !tbaa !21
  %t270 = xor i1 %t269, true
  br i1 %t270, label %bb61, label %bb62
bb61:
  store %olang.scope zeroinitializer, ptr %s15
  %t272 = load ptr, ptr %l2, !tbaa !29
  store ptr %t272, ptr %l159, !tbaa !29
  %t273 = load i32, ptr %l15, !tbaa !23
  %t275 = call %"compiler/typed:Item" @compiler_2ftyped_3aItem_2ector(ptr %s15, i32 %t273, i64 -1)
  store %"compiler/typed:Item" %t275, ptr %l161
  br label %bb63
bb62:
  br label %bb65
bb63:
  %t276 = load ptr, ptr %l159, !tbaa !29
  %t277 = load %"compiler/typed:Item", ptr %l161
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aItem_3e_2ePush_3ccompiler_2ftyped_3aItem_3e(ptr %v2, ptr %t276, %"compiler/typed:Item" %t277)
  br label %bb64
bb64:
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s14)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb65:
  %t278 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %s14, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t278, ptr %l162
  br label %bb66
bb66:
  %t279 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l162
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t279, ptr %l16
  %t280 = load ptr, ptr %l0, !tbaa !29
  %t282 = getelementptr %"compiler/check:Checker", ptr %t280, i32 0, i32 1
  %t283 = load ptr, ptr %t282, !tbaa !29
  %t284 = load i32, ptr %l15, !tbaa !23
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eEntriesOf(ptr %v0, ptr %s14, ptr %t283, i32 %t284, ptr %l16)
  br label %bb67
bb67:
  store ptr %l16, ptr %l17, !tbaa !29
  store i64 0, ptr %l18, !tbaa !24
  br label %bb68
bb68:
  %t289 = load i64, ptr %l18, !tbaa !24
  store i64 %t289, ptr %l168, !tbaa !24
  %t290 = load ptr, ptr %l17, !tbaa !29
  %t292 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %s14, ptr %t290)
  store i64 %t292, ptr %l170
  br label %bb69
bb69:
  %t293 = load i64, ptr %l168, !tbaa !24
  %t294 = load i64, ptr %l170, !tbaa !24
  %t295 = icmp slt i64 %t293, %t294
  %t297 = xor i1 %t295, true
  br i1 %t297, label %bb70, label %bb71
bb70:
  br label %bb103
bb71:
  br label %bb72
bb72:
  %t299 = load ptr, ptr %l17, !tbaa !29
  %t300 = load i64, ptr %l18, !tbaa !24
  %t303 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %s14, ptr %t299, i64 %t300)
  store i32 %t303, ptr %l175
  br label %bb73
bb73:
  %t304 = load i32, ptr %l175, !tbaa !23
  store i32 %t304, ptr %l19, !tbaa !23
  %t305 = load i32, ptr %l19, !tbaa !23
  %t306 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t309 = icmp eq i32 %t305, %t306
  br i1 %t309, label %bb74, label %bb75
bb74:
  br label %bb102
bb75:
  br label %bb76
bb76:
  %t311 = load ptr, ptr %l0, !tbaa !29
  %t313 = getelementptr %"compiler/check:Checker", ptr %t311, i32 0, i32 1
  %t314 = load ptr, ptr %t313, !tbaa !29
  %t316 = getelementptr %"compiler/generic:Program", ptr %t314, i32 0, i32 2
  %t317 = load i32, ptr %l19, !tbaa !23
  %t320 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t316, i32 %t317)
  store i32 %t320, ptr %l183
  br label %bb77
bb77:
  %t321 = load i32, ptr %l183
  %t323 = trunc i64 28 to i32
  %t324 = icmp eq i32 %t321, %t323
  %t326 = xor i1 %t324, true
  br i1 %t326, label %bb78, label %bb79
bb78:
  store %olang.scope zeroinitializer, ptr %s19
  %t328 = load ptr, ptr %l2, !tbaa !29
  store ptr %t328, ptr %l187, !tbaa !29
  %t329 = load i32, ptr %l19, !tbaa !23
  %t331 = call %"compiler/typed:Item" @compiler_2ftyped_3aItem_2ector(ptr %s19, i32 %t329, i64 -1)
  store %"compiler/typed:Item" %t331, ptr %l189
  br label %bb80
bb79:
  br label %bb82
bb80:
  %t332 = load ptr, ptr %l187, !tbaa !29
  %t333 = load %"compiler/typed:Item", ptr %l189
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aItem_3e_2ePush_3ccompiler_2ftyped_3aItem_3e(ptr %v2, ptr %t332, %"compiler/typed:Item" %t333)
  br label %bb81
bb81:
  call void @__olang_scope_close(ptr %s19)
  br label %bb102
bb82:
  %t334 = load ptr, ptr %l0, !tbaa !29
  %t336 = getelementptr %"compiler/check:Checker", ptr %t334, i32 0, i32 1
  %t337 = load ptr, ptr %t336, !tbaa !29
  %t339 = getelementptr %"compiler/generic:Program", ptr %t337, i32 0, i32 2
  %t340 = load i32, ptr %l19, !tbaa !23
  %t343 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %t339, i32 %t340)
  store i64 %t343, ptr %l194
  br label %bb83
bb83:
  %t344 = load i64, ptr %l194, !tbaa !65
  store i64 %t344, ptr %l20, !tbaa !65
  store i64 0, ptr %l21, !tbaa !24
  store i64 64, ptr %l22, !tbaa !24
  store i64 1, ptr %l23, !tbaa !24
  %t345 = load i64, ptr %l22, !tbaa !24
  %t346 = load i64, ptr %l21, !tbaa !24
  %t349 = icmp sgt i64 %t345, %t346
  br i1 %t349, label %bb84, label %bb85
bb84:
  %t351 = load i64, ptr %l23, !tbaa !24
  %t353 = icmp sgt i64 %t351, 0
  br i1 %t353, label %bb86, label %bb87
bb85:
  store i64 0, ptr %l198, !tbaa !24
  br label %bb89
bb86:
  %t355 = load i64, ptr %l22, !tbaa !24
  %t356 = load i64, ptr %l21, !tbaa !24
  %t359 = sub i64 %t355, %t356
  %t360 = load i64, ptr %l23, !tbaa !24
  %t363 = add i64 %t359, %t360
  %t365 = sub i64 %t363, 1
  %t366 = load i64, ptr %l23, !tbaa !24
  %t369 = sdiv i64 %t365, %t366
  store i64 %t369, ptr %l201, !tbaa !24
  br label %bb88
bb87:
  store i64 0, ptr %l201, !tbaa !24
  br label %bb88
bb88:
  %t371 = load i64, ptr %l201, !tbaa !24
  store i64 %t371, ptr %l198, !tbaa !24
  br label %bb89
bb89:
  %t372 = load i64, ptr %l198, !tbaa !24
  store i64 %t372, ptr %l24, !tbaa !24
  store i64 0, ptr %l25, !tbaa !24
  br label %bb90
bb90:
  %t373 = load i64, ptr %l25, !tbaa !24
  %t374 = load i64, ptr %l24, !tbaa !24
  %t377 = icmp slt i64 %t373, %t374
  %t379 = xor i1 %t377, true
  br i1 %t379, label %bb91, label %bb92
bb91:
  br label %bb101
bb92:
  br label %bb93
bb93:
  %t381 = load i64, ptr %l21, !tbaa !24
  %t382 = load i64, ptr %l25, !tbaa !24
  %t383 = load i64, ptr %l23, !tbaa !24
  %t386 = mul i64 %t382, %t383
  %t389 = add i64 %t381, %t386
  store i64 %t389, ptr %l26, !tbaa !24
  %t391 = load i64, ptr %l20, !tbaa !65
  %t392 = load i64, ptr %l26, !tbaa !24
  store i64 %t392, ptr %l220, !tbaa !24
  %t393 = load i64, ptr %l220, !tbaa !24
  %t394 = load i64, ptr %l220, !tbaa !24
  %t395 = shl i64 1, %t394
  %t398 = and i64 %t391, %t395
  %t400 = icmp ne i64 %t398, 0
  br i1 %t400, label %bb94, label %bb95
bb94:
  store %olang.scope zeroinitializer, ptr %s22
  %t402 = load ptr, ptr %l2, !tbaa !29
  store ptr %t402, ptr %l224, !tbaa !29
  %t403 = load ptr, ptr %l0, !tbaa !29
  %t405 = getelementptr %"compiler/check:Checker", ptr %t403, i32 0, i32 1
  %t406 = load ptr, ptr %t405, !tbaa !29
  %t408 = getelementptr %"compiler/generic:Program", ptr %t406, i32 0, i32 2
  %t409 = load i32, ptr %l19, !tbaa !23
  %t412 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t408, i32 %t409)
  store i32 %t412, ptr %l229
  br label %bb96
bb95:
  br label %bb99
bb96:
  %t413 = load i64, ptr %l26, !tbaa !24
  %t414 = load i32, ptr %l229, !tbaa !23
  %t416 = call %"compiler/typed:Item" @compiler_2ftyped_3aItem_2ector(ptr %s22, i32 %t414, i64 %t413)
  store %"compiler/typed:Item" %t416, ptr %l231
  br label %bb97
bb97:
  %t417 = load ptr, ptr %l224, !tbaa !29
  %t418 = load %"compiler/typed:Item", ptr %l231
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aItem_3e_2ePush_3ccompiler_2ftyped_3aItem_3e(ptr %v2, ptr %t417, %"compiler/typed:Item" %t418)
  br label %bb98
bb98:
  call void @__olang_scope_close(ptr %s22)
  br label %bb99
bb99:
  br label %bb100
bb100:
  %t419 = load i64, ptr %l25, !tbaa !24
  %t421 = add i64 %t419, 1
  store i64 %t421, ptr %l25, !tbaa !24
  br label %bb90
bb101:
  br label %bb102
bb102:
  %t423 = load i64, ptr %l18, !tbaa !24
  %t425 = add i64 %t423, 1
  store i64 %t425, ptr %l18, !tbaa !24
  br label %bb68
bb103:
  call void @__olang_scope_close(ptr %s14)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb104:
  %t427 = load ptr, ptr %l0, !tbaa !29
  %t428 = load ptr, ptr %l1, !tbaa !29
  %t431 = call { i64, i32 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrorWord(ptr %v0, ptr %v1, ptr %t427, ptr %t428)
  store { i64, i32 } %t431, ptr %l238
  br label %bb105
bb105:
  %t432 = load { i64, i32 }, ptr %l238
  store { i64, i32 } %t432, ptr %l27
  %t433 = getelementptr { i64, i32 }, ptr %l27, i32 0, i32 0
  %t434 = load i64, ptr %t433, !tbaa !24
  store i64 %t434, ptr %l28, !tbaa !24
  %t436 = getelementptr { i64, i32 }, ptr %l27, i32 0, i32 1
  %t437 = load i32, ptr %t436, !tbaa !23
  store i32 %t437, ptr %l29, !tbaa !23
  %t439 = load i64, ptr %l28, !tbaa !24
  %t441 = icmp slt i64 %t439, 0
  br i1 %t441, label %bb106, label %bb107
bb106:
  %t443 = load ptr, ptr %l0, !tbaa !29
  %t445 = getelementptr %"compiler/check:Checker", ptr %t443, i32 0, i32 1
  %t446 = load ptr, ptr %t445, !tbaa !29
  store ptr %t446, ptr %l244, !tbaa !29
  %t447 = load ptr, ptr %l0, !tbaa !29
  %t449 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t447)
  store ptr %t449, ptr %l246
  br label %bb108
bb107:
  br label %bb110
bb108:
  %t450 = load ptr, ptr %l246, !tbaa !29
  %t452 = getelementptr %"compiler/check:frame", ptr %t450, i32 0, i32 4
  %t453 = load ptr, ptr %l1, !tbaa !29
  %t454 = load ptr, ptr %l244, !tbaa !29
  %t457 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorItemKnown(ptr %v0, ptr %v0, ptr %v1, ptr %t454, ptr %t452, ptr %t453)
  store i1 %t457, ptr %l250
  br label %bb109
bb109:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb110:
  %t458 = load ptr, ptr %l2, !tbaa !29
  store ptr %t458, ptr %l251, !tbaa !29
  %t459 = load i32, ptr %l29, !tbaa !23
  %t460 = load i64, ptr %l28, !tbaa !24
  %t463 = call %"compiler/typed:Item" @compiler_2ftyped_3aItem_2ector(ptr %s0, i32 %t459, i64 %t460)
  store %"compiler/typed:Item" %t463, ptr %l254
  br label %bb111
bb111:
  %t464 = load ptr, ptr %l251, !tbaa !29
  %t465 = load %"compiler/typed:Item", ptr %l254
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aItem_3e_2ePush_3ccompiler_2ftyped_3aItem_3e(ptr %v2, ptr %t464, %"compiler/typed:Item" %t465)
  br label %bb112
bb112:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclauseRules(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, ptr %a2, i1 %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l20 = alloca i1
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca %"compiler/typed:Item"
  %l26 = alloca i1
  %l27 = alloca i1
  %l28 = alloca i64
  %l38 = alloca i64
  %l41 = alloca i64
  %l59 = alloca { i64, ptr }
  %l64 = alloca ptr
  %l67 = alloca i1
  %l72 = alloca ptr
  %l75 = alloca ptr
  %l78 = alloca %"compiler/source:Span"
  %l79 = alloca %"compiler/msgs:Msg"
  %l80 = alloca i64
  %l84 = alloca i1
  %l88 = alloca i1
  %l93 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l98 = alloca i64
  %l101 = alloca i64
  %l119 = alloca ptr
  %l122 = alloca ptr
  %l133 = alloca { i64, ptr }
  %l138 = alloca i1
  %l141 = alloca i32
  %l147 = alloca i64
  %l149 = alloca i32
  %l153 = alloca i32
  %l159 = alloca ptr
  %l162 = alloca %"compiler/source:Span"
  %l163 = alloca %"compiler/msgs:Msg"
  %l164 = alloca i64
  %l173 = alloca ptr
  %l176 = alloca %"compiler/source:Span"
  %l177 = alloca %"compiler/msgs:Msg"
  %l178 = alloca i64
  %l184 = alloca ptr
  %l187 = alloca %"compiler/source:Span"
  %l188 = alloca %"compiler/msgs:Msg"
  %l189 = alloca i64
  %l195 = alloca i1
  %l201 = alloca i1
  %l203 = alloca i1
  %l205 = alloca ptr
  %l208 = alloca %"compiler/source:Span"
  %l209 = alloca %"compiler/msgs:Msg"
  %l210 = alloca i64
  %l214 = alloca i1
  %l221 = alloca i1
  %l224 = alloca i1
  %l225 = alloca ptr
  %l228 = alloca %"compiler/source:Span"
  %l229 = alloca %"compiler/msgs:Msg"
  %l230 = alloca i64
  %l233 = alloca i1
  %l238 = alloca i32
  %l243 = alloca ptr
  %l248 = alloca i32
  %l249 = alloca { i64, ptr }
  %l256 = alloca ptr
  %l259 = alloca %"compiler/source:Span"
  %l264 = alloca %"compiler/msgs:Msg"
  %l265 = alloca i64
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i32 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  store i64 0, ptr %l5, !tbaa !24
  %t8 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t8, 0
  store i64 %t10, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t12 = load i64, ptr %l6, !tbaa !24
  %t13 = load i64, ptr %l5, !tbaa !24
  %t16 = icmp sgt i64 %t12, %t13
  br i1 %t16, label %bb4, label %bb5
bb4:
  %t18 = load i64, ptr %l7, !tbaa !24
  %t20 = icmp sgt i64 %t18, 0
  br i1 %t20, label %bb6, label %bb7
bb5:
  store i64 0, ptr %l38, !tbaa !24
  br label %bb9
bb6:
  %t22 = load i64, ptr %l6, !tbaa !24
  %t23 = load i64, ptr %l5, !tbaa !24
  %t26 = sub i64 %t22, %t23
  %t27 = load i64, ptr %l7, !tbaa !24
  %t30 = add i64 %t26, %t27
  %t32 = sub i64 %t30, 1
  %t33 = load i64, ptr %l7, !tbaa !24
  %t36 = sdiv i64 %t32, %t33
  store i64 %t36, ptr %l41, !tbaa !24
  br label %bb8
bb7:
  store i64 0, ptr %l41, !tbaa !24
  br label %bb8
bb8:
  %t38 = load i64, ptr %l41, !tbaa !24
  store i64 %t38, ptr %l38, !tbaa !24
  br label %bb9
bb9:
  %t39 = load i64, ptr %l38, !tbaa !24
  store i64 %t39, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s3
  %t40 = load i64, ptr %l9, !tbaa !24
  %t41 = load i64, ptr %l8, !tbaa !24
  %t44 = icmp slt i64 %t40, %t41
  %t46 = xor i1 %t44, true
  br i1 %t46, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s3)
  br label %bb138
bb12:
  br label %bb13
bb13:
  %t48 = load i64, ptr %l5, !tbaa !24
  %t49 = load i64, ptr %l9, !tbaa !24
  %t50 = load i64, ptr %l7, !tbaa !24
  %t53 = mul i64 %t49, %t50
  %t56 = add i64 %t48, %t53
  store i64 %t56, ptr %l10, !tbaa !24
  %t58 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t58, ptr %l59, !tbaa !27
  %t59 = load i64, ptr %l10, !tbaa !24
  %t61 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !27
  %t63 = getelementptr ptr, ptr %t62, i64 %t59
  %t64 = load ptr, ptr %t63, !tbaa !39
  store ptr %t64, ptr %l11, !tbaa !29
  %t66 = load ptr, ptr %l2, !tbaa !29
  %t67 = load i64, ptr %l10, !tbaa !24
  %t70 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aClause_26_3e_2eAt_3ccompiler_2ftyped_3aClause_26_3e(ptr %v2, ptr %v2, ptr %t66, i64 %t67)
  store ptr %t70, ptr %l64
  br label %bb14
bb14:
  %t71 = load ptr, ptr %l64, !tbaa !29
  store ptr %t71, ptr %l12, !tbaa !29
  %t72 = load i64, ptr %l10, !tbaa !24
  %t74 = icmp sgt i64 %t72, 0
  br i1 %t74, label %bb15, label %bb16
bb15:
  %t76 = load ptr, ptr %l2, !tbaa !29
  %t78 = load i64, ptr %l10, !tbaa !24
  %t80 = sub i64 %t78, 1
  %t83 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aClause_26_3e_2eAt_3ccompiler_2ftyped_3aClause_26_3e(ptr %v2, ptr %s3, ptr %t76, i64 %t80)
  store ptr %t83, ptr %l72
  br label %bb17
bb16:
  store i1 false, ptr %l67, !tbaa !21
  br label %bb18
bb17:
  %t84 = load ptr, ptr %l72, !tbaa !29
  %t86 = getelementptr %"compiler/typed:Clause", ptr %t84, i32 0, i32 2
  %t87 = load i1, ptr %t86, !tbaa !21
  store i1 %t87, ptr %l67, !tbaa !21
  br label %bb18
bb18:
  %t89 = load i1, ptr %l67, !tbaa !21
  br i1 %t89, label %bb19, label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s4
  %t90 = load ptr, ptr %l0, !tbaa !29
  store ptr %t90, ptr %l75, !tbaa !29
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load ptr, ptr %l11, !tbaa !29
  %t95 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecatchSpan(ptr %v0, ptr %v1, ptr %t91, ptr %t92)
  store %"compiler/source:Span" %t95, ptr %l78
  br label %bb21
bb20:
  br label %bb24
bb21:
  %t96 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCatchAfterCatchAll(ptr %s4)
  store %"compiler/msgs:Msg" %t96, ptr %l79
  br label %bb22
bb22:
  %t97 = load ptr, ptr %l75, !tbaa !29
  %t98 = load %"compiler/source:Span", ptr %l78
  %t99 = load %"compiler/msgs:Msg", ptr %l79
  %t100 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s4, ptr %t97, %"compiler/source:Span" %t98, %"compiler/msgs:Msg" %t99)
  store i64 %t100, ptr %l80
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  store i1 true, ptr %rv
  br label %ret
bb24:
  %t102 = load i64, ptr %l10, !tbaa !24
  %t104 = icmp sgt i64 %t102, 0
  br i1 %t104, label %bb25, label %bb26
bb25:
  %t106 = load ptr, ptr %l12, !tbaa !29
  %t108 = getelementptr %"compiler/typed:Clause", ptr %t106, i32 0, i32 2
  %t109 = load i1, ptr %t108, !tbaa !21
  %t111 = xor i1 %t109, true
  store i1 %t111, ptr %l84, !tbaa !21
  br label %bb27
bb26:
  store i1 false, ptr %l84, !tbaa !21
  br label %bb27
bb27:
  %t113 = load i1, ptr %l84, !tbaa !21
  br i1 %t113, label %bb28, label %bb29
bb28:
  %t114 = load ptr, ptr %l12, !tbaa !29
  %t116 = getelementptr %"compiler/typed:Clause", ptr %t114, i32 0, i32 1
  %t117 = load { i64, ptr }, ptr %t116, !tbaa !27
  %t119 = extractvalue { i64, ptr } %t117, 0
  %t121 = icmp sgt i64 %t119, 0
  store i1 %t121, ptr %l88, !tbaa !21
  br label %bb30
bb29:
  store i1 false, ptr %l88, !tbaa !21
  br label %bb30
bb30:
  %t123 = load i1, ptr %l88, !tbaa !21
  br i1 %t123, label %bb31, label %bb32
bb31:
  store %olang.scope zeroinitializer, ptr %s5
  %t124 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aClause_26_3e_2ector(ptr %s5, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t124, ptr %l93
  br label %bb33
bb32:
  br label %bb71
bb33:
  %t125 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l93
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t125, ptr %l13
  store i64 0, ptr %l14, !tbaa !24
  %t126 = load i64, ptr %l10, !tbaa !24
  store i64 %t126, ptr %l15, !tbaa !24
  store i64 1, ptr %l16, !tbaa !24
  %t128 = load i64, ptr %l15, !tbaa !24
  %t129 = load i64, ptr %l14, !tbaa !24
  %t132 = icmp sgt i64 %t128, %t129
  br i1 %t132, label %bb34, label %bb35
bb34:
  %t134 = load i64, ptr %l16, !tbaa !24
  %t136 = icmp sgt i64 %t134, 0
  br i1 %t136, label %bb36, label %bb37
bb35:
  store i64 0, ptr %l98, !tbaa !24
  br label %bb39
bb36:
  %t138 = load i64, ptr %l15, !tbaa !24
  %t139 = load i64, ptr %l14, !tbaa !24
  %t142 = sub i64 %t138, %t139
  %t143 = load i64, ptr %l16, !tbaa !24
  %t146 = add i64 %t142, %t143
  %t148 = sub i64 %t146, 1
  %t149 = load i64, ptr %l16, !tbaa !24
  %t152 = sdiv i64 %t148, %t149
  store i64 %t152, ptr %l101, !tbaa !24
  br label %bb38
bb37:
  store i64 0, ptr %l101, !tbaa !24
  br label %bb38
bb38:
  %t154 = load i64, ptr %l101, !tbaa !24
  store i64 %t154, ptr %l98, !tbaa !24
  br label %bb39
bb39:
  %t155 = load i64, ptr %l98, !tbaa !24
  store i64 %t155, ptr %l17, !tbaa !24
  store i64 0, ptr %l18, !tbaa !24
  br label %bb40
bb40:
  %t156 = load i64, ptr %l18, !tbaa !24
  %t157 = load i64, ptr %l17, !tbaa !24
  %t160 = icmp slt i64 %t156, %t157
  %t162 = xor i1 %t160, true
  br i1 %t162, label %bb41, label %bb42
bb41:
  br label %bb47
bb42:
  br label %bb43
bb43:
  %t164 = load i64, ptr %l14, !tbaa !24
  %t165 = load i64, ptr %l18, !tbaa !24
  %t166 = load i64, ptr %l16, !tbaa !24
  %t169 = mul i64 %t165, %t166
  %t172 = add i64 %t164, %t169
  store ptr %l13, ptr %l119, !tbaa !29
  %t174 = load ptr, ptr %l2, !tbaa !29
  %t178 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aClause_26_3e_2eAt_3ccompiler_2ftyped_3aClause_26_3e(ptr %v2, ptr %v2, ptr %t174, i64 %t172)
  store ptr %t178, ptr %l122
  br label %bb44
bb44:
  %t179 = load ptr, ptr %l119, !tbaa !29
  %t180 = load ptr, ptr %l122, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aClause_26_3e_2ePush_Hc64f4d0e64077a33423ff9c4e583894f(ptr %s5, ptr %v2, ptr %t179, ptr %t180)
  br label %bb45
bb45:
  br label %bb46
bb46:
  %t181 = load i64, ptr %l18, !tbaa !24
  %t183 = add i64 %t181, 1
  store i64 %t183, ptr %l18, !tbaa !24
  br label %bb40
bb47:
  store i1 true, ptr %l20, !tbaa !21
  %t185 = load ptr, ptr %l12, !tbaa !29
  %t187 = getelementptr %"compiler/typed:Clause", ptr %t185, i32 0, i32 1
  %t188 = load { i64, ptr }, ptr %t187, !tbaa !27
  store { i64, ptr } %t188, ptr %l21, !tbaa !27
  store i64 0, ptr %l22, !tbaa !24
  %t190 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t192 = extractvalue { i64, ptr } %t190, 0
  store i64 %t192, ptr %l23, !tbaa !24
  br label %bb48
bb48:
  %t194 = load i64, ptr %l22, !tbaa !24
  %t195 = load i64, ptr %l23, !tbaa !24
  %t198 = icmp slt i64 %t194, %t195
  %t200 = xor i1 %t198, true
  br i1 %t200, label %bb49, label %bb50
bb49:
  br label %bb64
bb50:
  br label %bb51
bb51:
  %t202 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t202, ptr %l133, !tbaa !27
  %t203 = load i64, ptr %l22, !tbaa !24
  %t205 = getelementptr { i64, ptr }, ptr %l133, i32 0, i32 1
  %t206 = load ptr, ptr %t205, !tbaa !27
  %t207 = getelementptr %"compiler/typed:Item", ptr %t206, i64 %t203
  %t208 = load %"compiler/typed:Item", ptr %t207
  store %"compiler/typed:Item" %t208, ptr %l24
  %t210 = getelementptr %"compiler/typed:Item", ptr %l24, i32 0, i32 1
  %t211 = load i64, ptr %t210, !tbaa !24
  %t213 = icmp slt i64 %t211, 0
  br i1 %t213, label %bb52, label %bb53
bb52:
  store i1 true, ptr %l138, !tbaa !21
  br label %bb54
bb53:
  %t215 = getelementptr %"compiler/typed:Item", ptr %l24, i32 0, i32 1
  %t216 = load i64, ptr %t215, !tbaa !24
  %t218 = icmp sge i64 %t216, 64
  store i1 %t218, ptr %l138, !tbaa !21
  br label %bb54
bb54:
  %t220 = load i1, ptr %l138, !tbaa !21
  br i1 %t220, label %bb55, label %bb56
bb55:
  %t221 = getelementptr %"compiler/typed:Item", ptr %l24, i32 0, i32 0
  %t222 = load i32, ptr %t221, !tbaa !23
  store i32 %t222, ptr %l141, !tbaa !23
  br label %bb58
bb56:
  %t224 = load ptr, ptr %l0, !tbaa !29
  %t226 = getelementptr %"compiler/check:Checker", ptr %t224, i32 0, i32 1
  %t227 = load ptr, ptr %t226, !tbaa !29
  %t229 = getelementptr %"compiler/generic:Program", ptr %t227, i32 0, i32 2
  %t230 = getelementptr %"compiler/typed:Item", ptr %l24, i32 0, i32 0
  %t231 = load i32, ptr %t230, !tbaa !23
  %t232 = getelementptr %"compiler/typed:Item", ptr %l24, i32 0, i32 1
  %t233 = load i64, ptr %t232, !tbaa !24
  store i64 %t233, ptr %l147, !tbaa !24
  %t234 = load i64, ptr %l147, !tbaa !24
  %t235 = load i64, ptr %l147, !tbaa !24
  %t236 = shl i64 1, %t235
  %t240 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrWords(ptr %v0, ptr %t229, i32 %t231, i64 %t236)
  store i32 %t240, ptr %l149
  br label %bb57
bb57:
  %t241 = load i32, ptr %l149, !tbaa !23
  store i32 %t241, ptr %l141, !tbaa !23
  br label %bb58
bb58:
  %t242 = load i32, ptr %l141, !tbaa !23
  %t243 = load ptr, ptr %l0, !tbaa !29
  %t248 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleft(ptr %v0, ptr %s5, ptr %t243, i32 %t242, ptr %l13)
  store i32 %t248, ptr %l153
  br label %bb59
bb59:
  %t249 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t250 = load i32, ptr %l153, !tbaa !23
  %t252 = icmp ne i32 %t250, %t249
  br i1 %t252, label %bb60, label %bb61
bb60:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb62
bb61:
  br label %bb62
bb62:
  br label %bb63
bb63:
  %t254 = load i64, ptr %l22, !tbaa !24
  %t256 = add i64 %t254, 1
  store i64 %t256, ptr %l22, !tbaa !24
  br label %bb48
bb64:
  %t258 = load i1, ptr %l20, !tbaa !21
  br i1 %t258, label %bb65, label %bb66
bb65:
  store %olang.scope zeroinitializer, ptr %s13
  %t260 = load ptr, ptr %l0, !tbaa !29
  store ptr %t260, ptr %l159, !tbaa !29
  %t261 = load ptr, ptr %l0, !tbaa !29
  %t262 = load ptr, ptr %l11, !tbaa !29
  %t265 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecatchSpan(ptr %v0, ptr %v1, ptr %t261, ptr %t262)
  store %"compiler/source:Span" %t265, ptr %l162
  br label %bb67
bb66:
  br label %bb70
bb67:
  %t266 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCatchUnreachable(ptr %s13)
  store %"compiler/msgs:Msg" %t266, ptr %l163
  br label %bb68
bb68:
  %t267 = load ptr, ptr %l159, !tbaa !29
  %t268 = load %"compiler/source:Span", ptr %l162
  %t269 = load %"compiler/msgs:Msg", ptr %l163
  %t270 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s13, ptr %t267, %"compiler/source:Span" %t268, %"compiler/msgs:Msg" %t269)
  store i64 %t270, ptr %l164
  br label %bb69
bb69:
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s3)
  store i1 true, ptr %rv
  br label %ret
bb70:
  call void @__olang_scope_close(ptr %s5)
  br label %bb71
bb71:
  %t272 = load ptr, ptr %l11, !tbaa !29
  %t274 = getelementptr %"compiler/ast:Catch", ptr %t272, i32 0, i32 3
  %t275 = load { i64, ptr }, ptr %t274, !tbaa !27
  %t277 = extractvalue { i64, ptr } %t275, 0
  %t279 = icmp sgt i64 %t277, 0
  store i1 %t279, ptr %l26, !tbaa !21
  %t283 = xor i1 %a3, true
  br i1 %t283, label %bb72, label %bb73
bb72:
  %t285 = load i1, ptr %l26, !tbaa !21
  br i1 %t285, label %bb74, label %bb75
bb73:
  br label %bb80
bb74:
  store %olang.scope zeroinitializer, ptr %s15
  %t287 = load ptr, ptr %l0, !tbaa !29
  store ptr %t287, ptr %l173, !tbaa !29
  %t288 = load ptr, ptr %l0, !tbaa !29
  %t289 = load ptr, ptr %l11, !tbaa !29
  %t292 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edefaultSpan(ptr %v0, ptr %v1, ptr %t288, ptr %t289)
  store %"compiler/source:Span" %t292, ptr %l176
  br label %bb76
bb75:
  br label %bb79
bb76:
  %t293 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefaultInStatement(ptr %s15)
  store %"compiler/msgs:Msg" %t293, ptr %l177
  br label %bb77
bb77:
  %t294 = load ptr, ptr %l173, !tbaa !29
  %t295 = load %"compiler/source:Span", ptr %l176
  %t296 = load %"compiler/msgs:Msg", ptr %l177
  %t297 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s15, ptr %t294, %"compiler/source:Span" %t295, %"compiler/msgs:Msg" %t296)
  store i64 %t297, ptr %l178
  br label %bb78
bb78:
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s3)
  store i1 true, ptr %rv
  br label %ret
bb79:
  call void @__olang_scope_close(ptr %s3)
  br label %bb137
bb80:
  %t299 = load i32, ptr %l4, !tbaa !23
  %t300 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t303 = icmp eq i32 %t299, %t300
  br i1 %t303, label %bb81, label %bb82
bb81:
  %t305 = load i1, ptr %l26, !tbaa !21
  br i1 %t305, label %bb83, label %bb84
bb82:
  br label %bb89
bb83:
  store %olang.scope zeroinitializer, ptr %s17
  %t307 = load ptr, ptr %l0, !tbaa !29
  store ptr %t307, ptr %l184, !tbaa !29
  %t308 = load ptr, ptr %l0, !tbaa !29
  %t309 = load ptr, ptr %l11, !tbaa !29
  %t312 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecatchSpan(ptr %v0, ptr %v1, ptr %t308, ptr %t309)
  store %"compiler/source:Span" %t312, ptr %l187
  br label %bb85
bb84:
  br label %bb88
bb85:
  %t313 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefaultNoValue(ptr %s17)
  store %"compiler/msgs:Msg" %t313, ptr %l188
  br label %bb86
bb86:
  %t314 = load ptr, ptr %l184, !tbaa !29
  %t315 = load %"compiler/source:Span", ptr %l187
  %t316 = load %"compiler/msgs:Msg", ptr %l188
  %t317 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s17, ptr %t314, %"compiler/source:Span" %t315, %"compiler/msgs:Msg" %t316)
  store i64 %t317, ptr %l189
  br label %bb87
bb87:
  call void @__olang_scope_close(ptr %s17)
  call void @__olang_scope_close(ptr %s3)
  store i1 true, ptr %rv
  br label %ret
bb88:
  call void @__olang_scope_close(ptr %s3)
  br label %bb137
bb89:
  %t319 = load ptr, ptr %l12, !tbaa !29
  %t321 = getelementptr %"compiler/typed:Clause", ptr %t319, i32 0, i32 3
  %t322 = load ptr, ptr %t321, !tbaa !29
  %t324 = icmp eq ptr %t322, null
  %t326 = xor i1 %t324, true
  br i1 %t326, label %bb90, label %bb91
bb90:
  %t328 = load ptr, ptr %l12, !tbaa !29
  %t330 = getelementptr %"compiler/typed:Clause", ptr %t328, i32 0, i32 3
  %t331 = load ptr, ptr %t330, !tbaa !29
  %t333 = icmp eq ptr %t331, null
  br i1 %t333, label %bb92, label %bb93
bb91:
  store i1 false, ptr %l195, !tbaa !21
  br label %bb96
bb92:
  call void @__olang_check_failed(ptr @olang_loc_20fb2e81a5b7d68a_7759df49ce89a9e)
  unreachable
bb93:
  br label %bb94
bb94:
  %t335 = load ptr, ptr %l12, !tbaa !29
  %t337 = getelementptr %"compiler/typed:Clause", ptr %t335, i32 0, i32 3
  %t338 = load ptr, ptr %t337, !tbaa !29
  %t340 = call i1 @compiler_2fcheck_2eleavesValue(ptr %v2, ptr %t338)
  store i1 %t340, ptr %l201
  br label %bb95
bb95:
  %t341 = load i1, ptr %l201, !tbaa !21
  store i1 %t341, ptr %l195, !tbaa !21
  br label %bb96
bb96:
  %t342 = load i1, ptr %l195, !tbaa !21
  store i1 %t342, ptr %l27, !tbaa !21
  %t343 = load i1, ptr %l27, !tbaa !21
  br i1 %t343, label %bb97, label %bb98
bb97:
  %t345 = load i1, ptr %l26, !tbaa !21
  store i1 %t345, ptr %l203, !tbaa !21
  br label %bb99
bb98:
  store i1 false, ptr %l203, !tbaa !21
  br label %bb99
bb99:
  %t347 = load i1, ptr %l203, !tbaa !21
  br i1 %t347, label %bb100, label %bb101
bb100:
  store %olang.scope zeroinitializer, ptr %s18
  %t348 = load ptr, ptr %l0, !tbaa !29
  store ptr %t348, ptr %l205, !tbaa !29
  %t349 = load ptr, ptr %l0, !tbaa !29
  %t350 = load ptr, ptr %l11, !tbaa !29
  %t353 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edefaultSpan(ptr %v0, ptr %v1, ptr %t349, ptr %t350)
  store %"compiler/source:Span" %t353, ptr %l208
  br label %bb102
bb101:
  br label %bb105
bb102:
  %t354 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefaultDead(ptr %s18)
  store %"compiler/msgs:Msg" %t354, ptr %l209
  br label %bb103
bb103:
  %t355 = load ptr, ptr %l205, !tbaa !29
  %t356 = load %"compiler/source:Span", ptr %l208
  %t357 = load %"compiler/msgs:Msg", ptr %l209
  %t358 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s18, ptr %t355, %"compiler/source:Span" %t356, %"compiler/msgs:Msg" %t357)
  store i64 %t358, ptr %l210
  br label %bb104
bb104:
  call void @__olang_scope_close(ptr %s18)
  call void @__olang_scope_close(ptr %s3)
  store i1 true, ptr %rv
  br label %ret
bb105:
  %t360 = load i1, ptr %l27, !tbaa !21
  %t362 = xor i1 %t360, true
  br i1 %t362, label %bb106, label %bb107
bb106:
  %t364 = load i1, ptr %l26, !tbaa !21
  %t366 = xor i1 %t364, true
  store i1 %t366, ptr %l214, !tbaa !21
  br label %bb108
bb107:
  store i1 false, ptr %l214, !tbaa !21
  br label %bb108
bb108:
  %t368 = load i1, ptr %l214, !tbaa !21
  br i1 %t368, label %bb109, label %bb110
bb109:
  store %olang.scope zeroinitializer, ptr %s19
  %t369 = load ptr, ptr %l11, !tbaa !29
  %t371 = getelementptr %"compiler/ast:Catch", ptr %t369, i32 0, i32 2
  %t372 = load { i64, ptr }, ptr %t371, !tbaa !27
  %t374 = extractvalue { i64, ptr } %t372, 0
  %t376 = icmp sgt i64 %t374, 0
  br i1 %t376, label %bb111, label %bb112
bb110:
  br label %bb121
bb111:
  %t378 = load ptr, ptr %l11, !tbaa !29
  %t380 = getelementptr %"compiler/ast:Catch", ptr %t378, i32 0, i32 2
  %t381 = load { i64, ptr }, ptr %t380, !tbaa !27
  %t383 = call i1 @compiler_2fcheck_2elastIsValue(ptr %v1, { i64, ptr } %t381)
  store i1 %t383, ptr %l224
  br label %bb113
bb112:
  store i1 false, ptr %l221, !tbaa !21
  br label %bb114
bb113:
  %t384 = load i1, ptr %l224, !tbaa !21
  store i1 %t384, ptr %l221, !tbaa !21
  br label %bb114
bb114:
  %t385 = load i1, ptr %l221, !tbaa !21
  br i1 %t385, label %bb115, label %bb116
bb115:
  call void @__olang_scope_close(ptr %s19)
  call void @__olang_scope_close(ptr %s3)
  br label %bb137
bb116:
  br label %bb117
bb117:
  %t386 = load ptr, ptr %l0, !tbaa !29
  store ptr %t386, ptr %l225, !tbaa !29
  %t387 = load ptr, ptr %l0, !tbaa !29
  %t388 = load ptr, ptr %l11, !tbaa !29
  %t391 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecatchSpan(ptr %v0, ptr %v1, ptr %t387, ptr %t388)
  store %"compiler/source:Span" %t391, ptr %l228
  br label %bb118
bb118:
  %t392 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCatchMustLeave(ptr %s19)
  store %"compiler/msgs:Msg" %t392, ptr %l229
  br label %bb119
bb119:
  %t393 = load ptr, ptr %l225, !tbaa !29
  %t394 = load %"compiler/source:Span", ptr %l228
  %t395 = load %"compiler/msgs:Msg", ptr %l229
  %t396 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s19, ptr %t393, %"compiler/source:Span" %t394, %"compiler/msgs:Msg" %t395)
  store i64 %t396, ptr %l230
  br label %bb120
bb120:
  call void @__olang_scope_close(ptr %s19)
  call void @__olang_scope_close(ptr %s3)
  store i1 true, ptr %rv
  br label %ret
bb121:
  %t398 = load i1, ptr %l26, !tbaa !21
  br i1 %t398, label %bb122, label %bb123
bb122:
  %t400 = load ptr, ptr %l0, !tbaa !29
  %t402 = getelementptr %"compiler/check:Checker", ptr %t400, i32 0, i32 1
  %t403 = load ptr, ptr %t402, !tbaa !29
  %t405 = getelementptr %"compiler/generic:Program", ptr %t403, i32 0, i32 2
  %t406 = load i32, ptr %l4, !tbaa !23
  %t409 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t405, i32 %t406)
  store i32 %t409, ptr %l238
  br label %bb124
bb123:
  store i1 false, ptr %l233, !tbaa !21
  br label %bb125
bb124:
  %t410 = load i32, ptr %l238
  %t412 = trunc i64 22 to i32
  %t413 = icmp eq i32 %t410, %t412
  store i1 %t413, ptr %l233, !tbaa !21
  br label %bb125
bb125:
  %t415 = load i1, ptr %l233, !tbaa !21
  br i1 %t415, label %bb126, label %bb127
bb126:
  %t416 = load ptr, ptr %l0, !tbaa !29
  %t418 = getelementptr %"compiler/check:Checker", ptr %t416, i32 0, i32 1
  %t419 = load ptr, ptr %t418, !tbaa !29
  %t421 = getelementptr %"compiler/generic:Program", ptr %t419, i32 0, i32 2
  store ptr %t421, ptr %l243, !tbaa !29
  %t422 = load ptr, ptr %l0, !tbaa !29
  %t424 = getelementptr %"compiler/check:Checker", ptr %t422, i32 0, i32 1
  %t425 = load ptr, ptr %t424, !tbaa !29
  %t427 = getelementptr %"compiler/generic:Program", ptr %t425, i32 0, i32 2
  %t428 = load i32, ptr %l4, !tbaa !23
  %t431 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t427, i32 %t428)
  store i32 %t431, ptr %l248
  br label %bb128
bb127:
  br label %bb136
bb128:
  %t432 = load ptr, ptr %l243, !tbaa !29
  %t433 = load i32, ptr %l248, !tbaa !23
  %t434 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t432, i32 %t433)
  store { i64, ptr } %t434, ptr %l249
  br label %bb129
bb129:
  %t435 = load { i64, ptr }, ptr %l249, !tbaa !27
  %t436 = extractvalue { i64, ptr } %t435, 0
  store i64 %t436, ptr %l28, !tbaa !24
  %t438 = load ptr, ptr %l11, !tbaa !29
  %t440 = getelementptr %"compiler/ast:Catch", ptr %t438, i32 0, i32 3
  %t441 = load { i64, ptr }, ptr %t440, !tbaa !27
  %t443 = extractvalue { i64, ptr } %t441, 0
  %t444 = load i64, ptr %l28, !tbaa !24
  %t447 = icmp ne i64 %t443, %t444
  br i1 %t447, label %bb130, label %bb131
bb130:
  store %olang.scope zeroinitializer, ptr %s22
  %t449 = load ptr, ptr %l0, !tbaa !29
  store ptr %t449, ptr %l256, !tbaa !29
  %t450 = load ptr, ptr %l0, !tbaa !29
  %t451 = load ptr, ptr %l11, !tbaa !29
  %t454 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edefaultSpan(ptr %v0, ptr %v1, ptr %t450, ptr %t451)
  store %"compiler/source:Span" %t454, ptr %l259
  br label %bb132
bb131:
  br label %bb135
bb132:
  %t455 = load i64, ptr %l28, !tbaa !24
  %t456 = load ptr, ptr %l11, !tbaa !29
  %t458 = getelementptr %"compiler/ast:Catch", ptr %t456, i32 0, i32 3
  %t459 = load { i64, ptr }, ptr %t458, !tbaa !27
  %t461 = extractvalue { i64, ptr } %t459, 0
  %t464 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefaultCount(ptr %s22, i64 %t455, i64 %t461)
  store %"compiler/msgs:Msg" %t464, ptr %l264
  br label %bb133
bb133:
  %t465 = load ptr, ptr %l256, !tbaa !29
  %t466 = load %"compiler/source:Span", ptr %l259
  %t467 = load %"compiler/msgs:Msg", ptr %l264
  %t468 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s22, ptr %t465, %"compiler/source:Span" %t466, %"compiler/msgs:Msg" %t467)
  store i64 %t468, ptr %l265
  br label %bb134
bb134:
  call void @__olang_scope_close(ptr %s22)
  call void @__olang_scope_close(ptr %s3)
  store i1 true, ptr %rv
  br label %ret
bb135:
  br label %bb136
bb136:
  call void @__olang_scope_close(ptr %s3)
  br label %bb137
bb137:
  %t470 = load i64, ptr %l9, !tbaa !24
  %t472 = add i64 %t470, 1
  store i64 %t472, ptr %l9, !tbaa !24
  br label %bb10
bb138:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecomptime(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca { i64, [2 x i64] }
  %l6 = alloca i64
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i32
  %l12 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l13 = alloca i64
  %l14 = alloca i32
  %l15 = alloca ptr
  %l17 = alloca ptr
  %l22 = alloca ptr
  %l33 = alloca ptr
  %l37 = alloca i1
  %l42 = alloca i1
  %l44 = alloca i1
  %l49 = alloca i1
  %l51 = alloca { i64, ptr }
  %l53 = alloca %"compiler/source:Span"
  %l55 = alloca %"compiler/source:Span"
  %l57 = alloca i1
  %l67 = alloca ptr
  %l69 = alloca { i64, ptr }
  %l71 = alloca i1
  %l72 = alloca i64
  %l82 = alloca ptr
  %l89 = alloca ptr
  %l96 = alloca i32
  %l100 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l101 = alloca i64
  %l105 = alloca i64
  %l106 = alloca i32
  %l115 = alloca i64
  %l116 = alloca i32
  %l120 = alloca i32
  %l121 = alloca i32
  %l128 = alloca ptr
  %l139 = alloca i32
  %l142 = alloca %"compiler/source:Span"
  %l148 = alloca i32
  %l155 = alloca ptr
  %s0 = alloca %olang.scope
  %rv = alloca ptr
  %t274 = alloca { i64, [4 x i64] }, align 8
  %t318 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t1)
  store ptr %t3, ptr %l17
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l17, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/check:Checker", ptr %t5, i32 0, i32 12
  %t8 = load ptr, ptr %l4, !tbaa !29
  %t10 = getelementptr %"compiler/check:frame", ptr %t8, i32 0, i32 0
  %t11 = load i64, ptr %t10, !tbaa !24
  %t14 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t7, i64 %t11)
  store ptr %t14, ptr %l22
  br label %bb2
bb2:
  %t15 = load ptr, ptr %l22, !tbaa !29
  %t17 = getelementptr %"compiler/typed:Body", ptr %t15, i32 0, i32 1
  %t18 = load { i64, [2 x i64] }, ptr %t17
  store { i64, [2 x i64] } %t18, ptr %l5
  %t20 = load { i64, [2 x i64] }, ptr %l5
  %t22 = extractvalue { i64, [2 x i64] } %t20, 0
  %t23 = icmp eq i64 %t22, 6
  br i1 %t23, label %bb3, label %bb4
bb3:
  %t25 = getelementptr { i64, [2 x i64] }, ptr %l5, i32 0, i32 1
  %t26 = getelementptr { i64, i32 }, ptr %t25, i32 0, i32 0
  %t27 = load i64, ptr %t26
  store i64 %t27, ptr %l6, !tbaa !24
  %t29 = getelementptr { i64, [2 x i64] }, ptr %l5, i32 0, i32 1
  %t30 = getelementptr { i64, i32 }, ptr %t29, i32 0, i32 1
  %t31 = load i32, ptr %t30
  store i32 %t31, ptr %l7, !tbaa !23
  br label %bb5
bb4:
  br label %bb24
bb5:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/check:Checker", ptr %t33, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !29
  %t37 = load i64, ptr %l6, !tbaa !24
  %t38 = load i32, ptr %l7, !tbaa !23
  %t42 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eGlobalDecl(ptr %v0, ptr %t36, i64 %t37, i32 %t38)
  store ptr %t42, ptr %l33
  br label %bb6
bb6:
  %t43 = load ptr, ptr %l33, !tbaa !29
  store ptr %t43, ptr %l8, !tbaa !29
  %t44 = load ptr, ptr %l8, !tbaa !29
  %t46 = icmp eq ptr %t44, null
  %t48 = xor i1 %t46, true
  br i1 %t48, label %bb7, label %bb8
bb7:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/check:Checker", ptr %t50, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t54 = load i64, ptr %l6, !tbaa !24
  %t55 = load i32, ptr %l7, !tbaa !23
  %t59 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsSynth(ptr %v0, ptr %t53, i64 %t54, i32 %t55)
  store i1 %t59, ptr %l42
  br label %bb9
bb8:
  store i1 false, ptr %l37, !tbaa !21
  br label %bb10
bb9:
  %t60 = load i1, ptr %l42, !tbaa !21
  %t61 = xor i1 %t60, true
  store i1 %t61, ptr %l37, !tbaa !21
  br label %bb10
bb10:
  %t63 = load i1, ptr %l37, !tbaa !21
  br i1 %t63, label %bb11, label %bb12
bb11:
  %t64 = load ptr, ptr %l8, !tbaa !29
  %t66 = getelementptr %"compiler/ast:VarDecl", ptr %t64, i32 0, i32 3
  %t67 = load { i64, ptr }, ptr %t66, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t67, 0
  %t71 = icmp sgt i64 %t69, 0
  store i1 %t71, ptr %l44, !tbaa !21
  br label %bb13
bb12:
  store i1 false, ptr %l44, !tbaa !21
  br label %bb13
bb13:
  %t73 = load i1, ptr %l44, !tbaa !21
  br i1 %t73, label %bb14, label %bb15
bb14:
  %t74 = load ptr, ptr %l8, !tbaa !29
  %t76 = getelementptr %"compiler/ast:VarDecl", ptr %t74, i32 0, i32 3
  %t77 = load { i64, ptr }, ptr %t76, !tbaa !27
  store { i64, ptr } %t77, ptr %l51, !tbaa !27
  %t78 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !27
  %t80 = getelementptr ptr, ptr %t79, i64 0
  %t81 = load ptr, ptr %t80, !tbaa !39
  %t83 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %t81)
  store %"compiler/source:Span" %t83, ptr %l53
  br label %bb16
bb15:
  store i1 false, ptr %l49, !tbaa !21
  br label %bb18
bb16:
  %t84 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t84, ptr %l55
  %t87 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fsource_3aSpan(ptr %l53, ptr %l55)
  store i1 %t87, ptr %l57
  br label %bb17
bb17:
  %t88 = load i1, ptr %l57, !tbaa !21
  store i1 %t88, ptr %l49, !tbaa !21
  br label %bb18
bb18:
  %t89 = load i1, ptr %l49, !tbaa !21
  br i1 %t89, label %bb19, label %bb20
bb19:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/check:Checker", ptr %t90, i32 0, i32 106
  %t93 = load ptr, ptr %l4, !tbaa !29
  %t95 = getelementptr %"compiler/check:frame", ptr %t93, i32 0, i32 0
  %t96 = load i64, ptr %t95, !tbaa !24
  %t97 = load %"compiler/source:Span", ptr %l1
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fsource_3aSpan_3e_2_H19fded22be32a91ca4084130356a325d(ptr %v0, ptr %t92, i64 %t96, %"compiler/source:Span" %t97)
  br label %bb21
bb20:
  br label %bb23
bb21:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t102 = load ptr, ptr %l2, !tbaa !29
  %t104 = load i32, ptr %l3, !tbaa !23
  %t108 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %t101, ptr %t102, i32 %t104)
  store ptr %t108, ptr %l67
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s0)
  %t109 = load ptr, ptr %l67, !tbaa !29
  store ptr %t109, ptr %rv
  br label %ret
bb23:
  br label %bb29
bb24:
  br i1 true, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_fa3c94e3a612a0dd_4761343759351551)
  unreachable
bb29:
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecomptimeCtx(ptr %v0, ptr %s0, ptr %t110)
  store { i64, ptr } %t112, ptr %l69
  br label %bb30
bb30:
  %t113 = load { i64, ptr }, ptr %l69, !tbaa !27
  store { i64, ptr } %t113, ptr %l9, !tbaa !27
  %t114 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t116 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t114, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d7, i32 0, i32 1) })
  store i1 %t116, ptr %l71
  br label %bb31
bb31:
  %t117 = load i1, ptr %l71, !tbaa !21
  br i1 %t117, label %bb32, label %bb33
bb32:
  %t118 = load ptr, ptr %l4, !tbaa !29
  %t120 = getelementptr %"compiler/check:frame", ptr %t118, i32 0, i32 1
  %t121 = load i64, ptr %t120, !tbaa !24
  store i64 %t121, ptr %l72, !tbaa !24
  br label %bb34
bb33:
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"compiler/check:Checker", ptr %t123, i32 0, i32 1
  %t126 = load ptr, ptr %t125, !tbaa !29
  %t128 = getelementptr %"compiler/generic:Program", ptr %t126, i32 0, i32 0
  %t129 = load ptr, ptr %t128, !tbaa !29
  %t131 = getelementptr %"compiler/load:Loader", ptr %t129, i32 0, i32 7
  %t132 = load i64, ptr %t131, !tbaa !24
  store i64 %t132, ptr %l72, !tbaa !24
  br label %bb34
bb34:
  %t134 = load i64, ptr %l72, !tbaa !24
  store i64 %t134, ptr %l10, !tbaa !24
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t137 = getelementptr %"compiler/check:Checker", ptr %t135, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !29
  %t140 = getelementptr %"compiler/generic:Program", ptr %t138, i32 0, i32 0
  %t141 = load ptr, ptr %t140, !tbaa !29
  %t143 = getelementptr %"compiler/load:Loader", ptr %t141, i32 0, i32 3
  %t144 = load ptr, ptr %t143, !tbaa !29
  store ptr %t144, ptr %l82, !tbaa !29
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t147 = getelementptr %"compiler/check:Checker", ptr %t145, i32 0, i32 1
  %t148 = load ptr, ptr %t147, !tbaa !29
  %t150 = getelementptr %"compiler/generic:Program", ptr %t148, i32 0, i32 0
  %t151 = load ptr, ptr %t150, !tbaa !29
  %t153 = getelementptr %"compiler/load:Loader", ptr %t151, i32 0, i32 5
  %t154 = load ptr, ptr %l4, !tbaa !29
  %t156 = getelementptr %"compiler/check:frame", ptr %t154, i32 0, i32 1
  %t157 = load i64, ptr %t156, !tbaa !24
  %t160 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t153, i64 %t157)
  store ptr %t160, ptr %l89
  br label %bb35
bb35:
  %t161 = load ptr, ptr %l89, !tbaa !29
  %t163 = getelementptr %"compiler/load:Module", ptr %t161, i32 0, i32 2
  %t164 = load { i64, ptr }, ptr %t163, !tbaa !27
  %t165 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t166 = load i32, ptr %t165, !tbaa !23
  %t167 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t168 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d8, i32 0, i32 1) }, 1
  %t169 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d8, i32 0, i32 1) }, 0
  %t171 = extractvalue { i64, ptr } %t164, 1
  %t172 = extractvalue { i64, ptr } %t164, 0
  %t173 = add i64 %t169, %t172
  %t174 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d9, i32 0, i32 1) }, 1
  %t175 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d9, i32 0, i32 1) }, 0
  %t176 = add i64 %t173, %t175
  %t178 = sext i32 %t166 to i64
  %t179 = call i64 @__olang_fmt_i64(ptr null, i64 %t178)
  %t180 = add i64 %t176, %t179
  %t182 = extractvalue { i64, ptr } %t167, 1
  %t183 = extractvalue { i64, ptr } %t167, 0
  %t184 = add i64 %t180, %t183
  %t185 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t184)
  call void @olang_textcopy(ptr %t185, ptr %t168, i64 %t169)
  %t186 = getelementptr i8, ptr %t185, i64 %t169
  call void @olang_textcopy(ptr %t186, ptr %t171, i64 %t172)
  %t187 = getelementptr i8, ptr %t186, i64 %t172
  call void @olang_textcopy(ptr %t187, ptr %t174, i64 %t175)
  %t188 = getelementptr i8, ptr %t187, i64 %t175
  %t189 = call i64 @__olang_fmt_i64(ptr %t188, i64 %t178)
  %t190 = getelementptr i8, ptr %t188, i64 %t179
  call void @olang_textcopy(ptr %t190, ptr %t182, i64 %t183)
  %t191 = insertvalue { i64, ptr } undef, i64 %t184, 0
  %t192 = insertvalue { i64, ptr } %t191, ptr %t185, 1
  %t194 = extractvalue { i64, ptr } %t192, 0
  %t195 = extractvalue { i64, ptr } %t192, 1
  %t196 = mul i64 %t194, 1
  %t197 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t196)
  call void @llvm.memcpy.p0.p0.i64(ptr %t197, ptr %t195, i64 %t196, i1 false)
  %t198 = insertvalue { i64, ptr } undef, i64 %t194, 0
  %t199 = insertvalue { i64, ptr } %t198, ptr %t197, 1
  %t200 = load ptr, ptr %l82, !tbaa !29
  %t202 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %s0, ptr %t200, { i64, ptr } %t199)
  store i32 %t202, ptr %l96
  br label %bb36
bb36:
  %t203 = load i32, ptr %l96, !tbaa !23
  store i32 %t203, ptr %l11, !tbaa !23
  %t204 = load i64, ptr %l10, !tbaa !24
  %t205 = load i32, ptr %l11, !tbaa !23
  %t207 = sext i32 %t205 to i64
  %t210 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %t204, i64 %t207)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t210, ptr %l100
  br label %bb37
bb37:
  %t211 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l100
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t211, ptr %l12
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t214 = getelementptr %"compiler/check:Checker", ptr %t212, i32 0, i32 27
  %t215 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l12
  %t218 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H5696e1a008d256bf9453cde2b49c6c45(ptr %v0, ptr %t214, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t215)
  %t219 = extractvalue { i32, i64 } %t218, 1
  %t220 = extractvalue { i32, i64 } %t218, 0
  store i32 %t220, ptr %l106
  %t221 = icmp ne i32 %t220, 0
  br i1 %t221, label %bb39, label %ok.222, !prof !99
ok.222:
  store i64 %t219, ptr %l105
  br label %bb38
bb38:
  %t223 = load i64, ptr %l105, !tbaa !24
  store i64 %t223, ptr %l101, !tbaa !24
  br label %bb41
bb39:
  br label %bb40
bb40:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l101, !tbaa !24
  br label %bb41
bb41:
  %t224 = load i64, ptr %l101, !tbaa !24
  store i64 %t224, ptr %l13, !tbaa !24
  %t225 = load i64, ptr %l13, !tbaa !24
  %t227 = icmp slt i64 %t225, 0
  br i1 %t227, label %bb42, label %bb43
bb42:
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t230 = load %"compiler/source:Span", ptr %l1
  %t231 = load ptr, ptr %l2, !tbaa !29
  %t232 = load i32, ptr %l3, !tbaa !23
  %t233 = load i64, ptr %l10, !tbaa !24
  %t234 = load i32, ptr %l11, !tbaa !23
  %t241 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecomptimeBody(ptr %v0, ptr %v1, ptr %t229, %"compiler/source:Span" %t230, ptr %t231, i32 %t232, i64 %t233, i32 %t234)
  store i64 %t241, ptr %l115
  br label %bb44
bb43:
  br label %bb45
bb44:
  %t242 = load i64, ptr %l115, !tbaa !24
  store i64 %t242, ptr %l13, !tbaa !24
  br label %bb45
bb45:
  %t243 = load ptr, ptr %l0, !tbaa !29
  %t245 = getelementptr %"compiler/check:Checker", ptr %t243, i32 0, i32 28
  %t246 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l12
  %t249 = call { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H3cc70d507a7fc767d013b59b12ee0a99(ptr %v0, ptr %t245, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t246)
  %t250 = extractvalue { i32, i32 } %t249, 1
  %t251 = extractvalue { i32, i32 } %t249, 0
  store i32 %t251, ptr %l121
  %t252 = icmp ne i32 %t251, 0
  br i1 %t252, label %bb47, label %ok.253, !prof !99
ok.253:
  store i32 %t250, ptr %l120
  br label %bb46
bb46:
  %t254 = load i32, ptr %l120, !tbaa !23
  store i32 %t254, ptr %l116, !tbaa !23
  br label %bb49
bb47:
  br label %bb48
bb48:
  call void @__olang_ert_req_clear()
  %t255 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t255, ptr %l116, !tbaa !23
  br label %bb49
bb49:
  %t257 = load i32, ptr %l116, !tbaa !23
  store i32 %t257, ptr %l14, !tbaa !23
  %t258 = load i32, ptr %l14, !tbaa !23
  %t259 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t262 = icmp eq i32 %t258, %t259
  br i1 %t262, label %bb50, label %bb51
bb50:
  %t264 = load ptr, ptr %l0, !tbaa !29
  %t265 = load %"compiler/source:Span", ptr %l1
  %t268 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t264, %"compiler/source:Span" %t265)
  store ptr %t268, ptr %l128
  br label %bb52
bb51:
  br label %bb53
bb52:
  call void @__olang_scope_close(ptr %s0)
  %t269 = load ptr, ptr %l128, !tbaa !29
  store ptr %t269, ptr %rv
  br label %ret
bb53:
  %t270 = load %"compiler/source:Span", ptr %l1
  %t271 = load i32, ptr %l14, !tbaa !23
  %t272 = load i64, ptr %l10, !tbaa !24
  %t273 = load i32, ptr %l11, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t274
  %t275 = getelementptr { i64, [4 x i64] }, ptr %t274, i32 0, i32 0
  store i64 1, ptr %t275
  %t277 = insertvalue { %"compiler/source:Span", i32, i64, i32 } undef, %"compiler/source:Span" %t270, 0
  %t279 = insertvalue { %"compiler/source:Span", i32, i64, i32 } %t277, i32 %t271, 1
  %t281 = insertvalue { %"compiler/source:Span", i32, i64, i32 } %t279, i64 %t272, 2
  %t283 = insertvalue { %"compiler/source:Span", i32, i64, i32 } %t281, i32 %t273, 3
  %t284 = getelementptr { i64, [4 x i64] }, ptr %t274, i32 0, i32 1
  store { %"compiler/source:Span", i32, i64, i32 } %t283, ptr %t284
  %t285 = load { i64, [4 x i64] }, ptr %t274
  %t287 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t285, ptr %t287
  store ptr %t287, ptr %l15, !tbaa !29
  %t289 = load ptr, ptr %l0, !tbaa !29
  %t291 = getelementptr %"compiler/check:Checker", ptr %t289, i32 0, i32 1
  %t292 = load ptr, ptr %t291, !tbaa !29
  %t294 = getelementptr %"compiler/generic:Program", ptr %t292, i32 0, i32 2
  %t295 = load i32, ptr %l14, !tbaa !23
  %t298 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t294, i32 %t295)
  store i32 %t298, ptr %l139
  br label %bb54
bb54:
  %t299 = load i32, ptr %l139
  %t301 = trunc i64 19 to i32
  %t302 = icmp eq i32 %t299, %t301
  br i1 %t302, label %bb55, label %bb56
bb55:
  %t304 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t304, ptr %l142
  %t305 = load ptr, ptr %l0, !tbaa !29
  %t307 = getelementptr %"compiler/check:Checker", ptr %t305, i32 0, i32 1
  %t308 = load ptr, ptr %t307, !tbaa !29
  %t310 = getelementptr %"compiler/generic:Program", ptr %t308, i32 0, i32 2
  %t311 = load i32, ptr %l14, !tbaa !23
  %t312 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t316 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t310, i32 %t311, i64 %t312)
  store i32 %t316, ptr %l148
  br label %bb57
bb56:
  br label %bb58
bb57:
  %t317 = load ptr, ptr %l15, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t318
  %t319 = getelementptr { i64, [5 x i64] }, ptr %t318, i32 0, i32 0
  store i64 3, ptr %t319
  %t320 = load %"compiler/source:Span", ptr %l142
  %t321 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t320, 0
  %t322 = load i32, ptr %l148, !tbaa !23
  %t323 = insertvalue { %"compiler/source:Span", i32, ptr } %t321, i32 %t322, 1
  %t325 = insertvalue { %"compiler/source:Span", i32, ptr } %t323, ptr %t317, 2
  %t326 = getelementptr { i64, [5 x i64] }, ptr %t318, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t325, ptr %t326
  %t327 = load { i64, [5 x i64] }, ptr %t318
  %t329 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t327, ptr %t329
  call void @__olang_scope_close(ptr %s0)
  store ptr %t329, ptr %rv
  br label %ret
bb58:
  %t331 = load ptr, ptr %l0, !tbaa !29
  %t332 = load %"compiler/source:Span", ptr %l1
  %t333 = load ptr, ptr %l15, !tbaa !29
  %t337 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t331, %"compiler/source:Span" %t332, ptr %t333)
  store ptr %t337, ptr %l155
  br label %bb59
bb59:
  call void @__olang_scope_close(ptr %s0)
  %t338 = load ptr, ptr %l155, !tbaa !29
  store ptr %t338, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopyAll(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l10 = alloca i64
  %l18 = alloca { i64, ptr }
  %l22 = alloca ptr
  %l26 = alloca ptr
  %l32 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 36
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l10
  br label %bb1
bb1:
  %t6 = load i64, ptr %l10, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  store { i64, ptr } %a1, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t9 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  store i64 %t11, ptr %l6, !tbaa !24
  br label %bb2
bb2:
  %t13 = load i64, ptr %l5, !tbaa !24
  %t14 = load i64, ptr %l6, !tbaa !24
  %t17 = icmp slt i64 %t13, %t14
  %t19 = xor i1 %t17, true
  br i1 %t19, label %bb3, label %bb4
bb3:
  br label %bb9
bb4:
  br label %bb5
bb5:
  %t21 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t21, ptr %l18, !tbaa !27
  %t22 = load i64, ptr %l5, !tbaa !24
  %t24 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr ptr, ptr %t25, i64 %t22
  %t27 = load ptr, ptr %t26, !tbaa !39
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/check:Checker", ptr %t29, i32 0, i32 36
  store ptr %t31, ptr %l22, !tbaa !29
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t38 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopyExpr(ptr %v0, ptr %v1, ptr %t32, ptr %t27, i64 %a2)
  store ptr %t38, ptr %l26
  br label %bb6
bb6:
  %t39 = load ptr, ptr %l22, !tbaa !29
  %t40 = load ptr, ptr %l26, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t39, ptr %t40)
  br label %bb7
bb7:
  br label %bb8
bb8:
  %t41 = load i64, ptr %l5, !tbaa !24
  %t43 = add i64 %t41, 1
  store i64 %t43, ptr %l5, !tbaa !24
  br label %bb2
bb9:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/check:Checker", ptr %t45, i32 0, i32 36
  %t48 = load i64, ptr %l3, !tbaa !24
  %t51 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t47, i64 %t48)
  store { i64, ptr } %t51, ptr %l32
  br label %bb10
bb10:
  %t52 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t52, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclAttrs(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca ptr
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i64
  %l24 = alloca ptr
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca i64
  %l29 = alloca ptr
  %l30 = alloca { i64, ptr }
  %l31 = alloca i64
  %l32 = alloca i64
  %l34 = alloca ptr
  %l35 = alloca i1
  %l52 = alloca ptr
  %l53 = alloca i1
  %l66 = alloca { i64, ptr }
  %l83 = alloca { i64, ptr }
  %l86 = alloca ptr
  %l87 = alloca i1
  %l98 = alloca ptr
  %l99 = alloca i1
  %l111 = alloca { i64, ptr }
  %l126 = alloca { i64, ptr }
  %l137 = alloca ptr
  %l138 = alloca i1
  %l155 = alloca { i64, ptr }
  %l164 = alloca ptr
  %l165 = alloca i1
  %l183 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  store ptr %t1, ptr %l34, !tbaa !29
  store i1 false, ptr %l35, !tbaa !21
  %t2 = load ptr, ptr %l34, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l34, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l35, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l35, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr { i64, [6 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l3, !tbaa !29
  br label %bb5
bb4:
  br label %bb85
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load i64, ptr %l1, !tbaa !24
  %t18 = load ptr, ptr %l3, !tbaa !29
  %t20 = getelementptr %"compiler/ast:TypeDecl", ptr %t18, i32 0, i32 4
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eattrsChecked(ptr %v0, ptr %v1, ptr %t16, i64 %t17, { i64, ptr } %t21)
  br label %bb6
bb6:
  %t25 = load ptr, ptr %l3, !tbaa !29
  %t27 = getelementptr %"compiler/ast:TypeDecl", ptr %t25, i32 0, i32 3
  %t28 = load ptr, ptr %t27, !tbaa !29
  %t30 = icmp eq ptr %t28, null
  br i1 %t30, label %bb7, label %bb8
bb7:
  br label %ret
bb8:
  br label %bb9
bb9:
  %t32 = load ptr, ptr %l3, !tbaa !29
  %t34 = getelementptr %"compiler/ast:TypeDecl", ptr %t32, i32 0, i32 3
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t37 = icmp eq ptr %t35, null
  br i1 %t37, label %bb10, label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_e375dcd56c8db7ae_8ebec7f18eafef7a)
  unreachable
bb11:
  br label %bb12
bb12:
  %t39 = load ptr, ptr %l3, !tbaa !29
  %t41 = getelementptr %"compiler/ast:TypeDecl", ptr %t39, i32 0, i32 3
  %t42 = load ptr, ptr %t41, !tbaa !29
  store ptr %t42, ptr %l4, !tbaa !29
  %t44 = load ptr, ptr %l4, !tbaa !29
  store ptr %t44, ptr %l52, !tbaa !29
  store i1 false, ptr %l53, !tbaa !21
  %t45 = load ptr, ptr %l52, !tbaa !29
  %t46 = icmp ne ptr %t45, null
  br i1 %t46, label %bb13, label %bb14
bb13:
  %t48 = load ptr, ptr %l52, !tbaa !29
  %t49 = load i64, ptr %t48
  %t51 = icmp eq i64 %t49, 0
  store i1 %t51, ptr %l53, !tbaa !21
  br label %bb14
bb14:
  %t52 = load i1, ptr %l53, !tbaa !21
  br i1 %t52, label %bb15, label %bb16
bb15:
  %t53 = load ptr, ptr %l4, !tbaa !29
  %t55 = getelementptr { i64, [6 x i64] }, ptr %t53, i32 0, i32 1
  %t56 = getelementptr { ptr }, ptr %t55, i32 0, i32 0
  %t57 = load ptr, ptr %t56
  store ptr %t57, ptr %l5, !tbaa !29
  br label %bb17
bb16:
  br label %bb43
bb17:
  %t59 = load ptr, ptr %l5, !tbaa !29
  %t61 = getelementptr %"compiler/ast:StructBody", ptr %t59, i32 0, i32 0
  %t62 = load { i64, ptr }, ptr %t61, !tbaa !27
  store { i64, ptr } %t62, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t64 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t66 = extractvalue { i64, ptr } %t64, 0
  store i64 %t66, ptr %l8, !tbaa !24
  br label %bb18
bb18:
  %t68 = load i64, ptr %l7, !tbaa !24
  %t69 = load i64, ptr %l8, !tbaa !24
  %t72 = icmp slt i64 %t68, %t69
  %t74 = xor i1 %t72, true
  br i1 %t74, label %bb19, label %bb20
bb19:
  br label %bb24
bb20:
  br label %bb21
bb21:
  %t76 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t76, ptr %l66, !tbaa !27
  %t77 = load i64, ptr %l7, !tbaa !24
  %t79 = getelementptr { i64, ptr }, ptr %l66, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = getelementptr ptr, ptr %t80, i64 %t77
  %t82 = load ptr, ptr %t81, !tbaa !39
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t85 = load i64, ptr %l1, !tbaa !24
  %t88 = getelementptr %"compiler/ast:Param", ptr %t82, i32 0, i32 4
  %t89 = load { i64, ptr }, ptr %t88, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eattrsChecked(ptr %v0, ptr %v1, ptr %t84, i64 %t85, { i64, ptr } %t89)
  br label %bb22
bb22:
  br label %bb23
bb23:
  %t93 = load i64, ptr %l7, !tbaa !24
  %t95 = add i64 %t93, 1
  store i64 %t95, ptr %l7, !tbaa !24
  br label %bb18
bb24:
  %t97 = load ptr, ptr %l5, !tbaa !29
  %t99 = getelementptr %"compiler/ast:StructBody", ptr %t97, i32 0, i32 2
  %t100 = load { i64, ptr }, ptr %t99, !tbaa !27
  store { i64, ptr } %t100, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t102 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t104 = extractvalue { i64, ptr } %t102, 0
  store i64 %t104, ptr %l12, !tbaa !24
  br label %bb25
bb25:
  %t106 = load i64, ptr %l11, !tbaa !24
  %t107 = load i64, ptr %l12, !tbaa !24
  %t110 = icmp slt i64 %t106, %t107
  %t112 = xor i1 %t110, true
  br i1 %t112, label %bb26, label %bb27
bb26:
  br label %bb42
bb27:
  br label %bb28
bb28:
  %t114 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t114, ptr %l83, !tbaa !27
  %t115 = load i64, ptr %l11, !tbaa !24
  %t117 = getelementptr { i64, ptr }, ptr %l83, i32 0, i32 1
  %t118 = load ptr, ptr %t117, !tbaa !27
  %t119 = getelementptr ptr, ptr %t118, i64 %t115
  %t120 = load ptr, ptr %t119, !tbaa !39
  store ptr %t120, ptr %l13, !tbaa !29
  %t122 = load ptr, ptr %l13, !tbaa !29
  store ptr %t122, ptr %l86, !tbaa !29
  store i1 false, ptr %l87, !tbaa !21
  %t123 = load ptr, ptr %l86, !tbaa !29
  %t124 = icmp ne ptr %t123, null
  br i1 %t124, label %bb29, label %bb30
bb29:
  %t126 = load ptr, ptr %l86, !tbaa !29
  %t127 = load i64, ptr %t126
  %t129 = icmp eq i64 %t127, 1
  store i1 %t129, ptr %l87, !tbaa !21
  br label %bb30
bb30:
  %t130 = load i1, ptr %l87, !tbaa !21
  br i1 %t130, label %bb31, label %bb32
bb31:
  %t131 = load ptr, ptr %l13, !tbaa !29
  %t133 = getelementptr { i64, [4 x i64] }, ptr %t131, i32 0, i32 1
  %t134 = getelementptr { %"compiler/source:Span", ptr }, ptr %t133, i32 0, i32 1
  %t135 = load ptr, ptr %t134
  store ptr %t135, ptr %l14, !tbaa !29
  br label %bb33
bb32:
  br label %bb35
bb33:
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t138 = load i64, ptr %l1, !tbaa !24
  %t139 = load ptr, ptr %l14, !tbaa !29
  %t141 = getelementptr %"compiler/ast:VarDecl", ptr %t139, i32 0, i32 6
  %t142 = load { i64, ptr }, ptr %t141, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eattrsChecked(ptr %v0, ptr %v1, ptr %t137, i64 %t138, { i64, ptr } %t142)
  br label %bb34
bb34:
  br label %bb40
bb35:
  br i1 true, label %bb36, label %bb37
bb36:
  br label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb40
bb39:
  call void @__olang_check_failed(ptr @olang_loc_f43f80063d96068c_f8dacab5994fea88)
  unreachable
bb40:
  br label %bb41
bb41:
  %t146 = load i64, ptr %l11, !tbaa !24
  %t148 = add i64 %t146, 1
  store i64 %t148, ptr %l11, !tbaa !24
  br label %bb25
bb42:
  br label %bb84
bb43:
  %t150 = load ptr, ptr %l4, !tbaa !29
  store ptr %t150, ptr %l98, !tbaa !29
  store i1 false, ptr %l99, !tbaa !21
  %t151 = load ptr, ptr %l98, !tbaa !29
  %t152 = icmp ne ptr %t151, null
  br i1 %t152, label %bb44, label %bb45
bb44:
  %t154 = load ptr, ptr %l98, !tbaa !29
  %t155 = load i64, ptr %t154
  %t157 = icmp eq i64 %t155, 1
  store i1 %t157, ptr %l99, !tbaa !21
  br label %bb45
bb45:
  %t158 = load i1, ptr %l99, !tbaa !21
  br i1 %t158, label %bb46, label %bb47
bb46:
  %t159 = load ptr, ptr %l4, !tbaa !29
  %t161 = getelementptr { i64, [6 x i64] }, ptr %t159, i32 0, i32 1
  %t162 = getelementptr { { i64, ptr }, ptr }, ptr %t161, i32 0, i32 0
  %t163 = load { i64, ptr }, ptr %t162
  store { i64, ptr } %t163, ptr %l15, !tbaa !27
  br label %bb48
bb47:
  br label %bb63
bb48:
  %t165 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t165, ptr %l16, !tbaa !27
  store i64 0, ptr %l17, !tbaa !24
  %t167 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t169 = extractvalue { i64, ptr } %t167, 0
  store i64 %t169, ptr %l18, !tbaa !24
  br label %bb49
bb49:
  %t171 = load i64, ptr %l17, !tbaa !24
  %t172 = load i64, ptr %l18, !tbaa !24
  %t175 = icmp slt i64 %t171, %t172
  %t177 = xor i1 %t175, true
  br i1 %t177, label %bb50, label %bb51
bb50:
  br label %bb62
bb51:
  br label %bb52
bb52:
  %t179 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t179, ptr %l111, !tbaa !27
  %t180 = load i64, ptr %l17, !tbaa !24
  %t182 = getelementptr { i64, ptr }, ptr %l111, i32 0, i32 1
  %t183 = load ptr, ptr %t182, !tbaa !27
  %t184 = getelementptr ptr, ptr %t183, i64 %t180
  %t185 = load ptr, ptr %t184, !tbaa !39
  store ptr %t185, ptr %l19, !tbaa !29
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t188 = load i64, ptr %l1, !tbaa !24
  %t189 = load ptr, ptr %l19, !tbaa !29
  %t191 = getelementptr %"compiler/ast:CaseDecl", ptr %t189, i32 0, i32 5
  %t192 = load { i64, ptr }, ptr %t191, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eattrsChecked(ptr %v0, ptr %v1, ptr %t187, i64 %t188, { i64, ptr } %t192)
  br label %bb53
bb53:
  %t196 = load ptr, ptr %l19, !tbaa !29
  %t198 = getelementptr %"compiler/ast:CaseDecl", ptr %t196, i32 0, i32 2
  %t199 = load { i64, ptr }, ptr %t198, !tbaa !27
  store { i64, ptr } %t199, ptr %l20, !tbaa !27
  store i64 0, ptr %l21, !tbaa !24
  %t201 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t203 = extractvalue { i64, ptr } %t201, 0
  store i64 %t203, ptr %l22, !tbaa !24
  br label %bb54
bb54:
  %t205 = load i64, ptr %l21, !tbaa !24
  %t206 = load i64, ptr %l22, !tbaa !24
  %t209 = icmp slt i64 %t205, %t206
  %t211 = xor i1 %t209, true
  br i1 %t211, label %bb55, label %bb56
bb55:
  br label %bb60
bb56:
  br label %bb57
bb57:
  %t213 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t213, ptr %l126, !tbaa !27
  %t214 = load i64, ptr %l21, !tbaa !24
  %t216 = getelementptr { i64, ptr }, ptr %l126, i32 0, i32 1
  %t217 = load ptr, ptr %t216, !tbaa !27
  %t218 = getelementptr ptr, ptr %t217, i64 %t214
  %t219 = load ptr, ptr %t218, !tbaa !39
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t222 = load i64, ptr %l1, !tbaa !24
  %t225 = getelementptr %"compiler/ast:Param", ptr %t219, i32 0, i32 4
  %t226 = load { i64, ptr }, ptr %t225, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eattrsChecked(ptr %v0, ptr %v1, ptr %t221, i64 %t222, { i64, ptr } %t226)
  br label %bb58
bb58:
  br label %bb59
bb59:
  %t230 = load i64, ptr %l21, !tbaa !24
  %t232 = add i64 %t230, 1
  store i64 %t232, ptr %l21, !tbaa !24
  br label %bb54
bb60:
  br label %bb61
bb61:
  %t234 = load i64, ptr %l17, !tbaa !24
  %t236 = add i64 %t234, 1
  store i64 %t236, ptr %l17, !tbaa !24
  br label %bb49
bb62:
  br label %bb84
bb63:
  %t238 = load ptr, ptr %l4, !tbaa !29
  store ptr %t238, ptr %l137, !tbaa !29
  store i1 false, ptr %l138, !tbaa !21
  %t239 = load ptr, ptr %l137, !tbaa !29
  %t240 = icmp ne ptr %t239, null
  br i1 %t240, label %bb64, label %bb65
bb64:
  %t242 = load ptr, ptr %l137, !tbaa !29
  %t243 = load i64, ptr %t242
  %t245 = icmp eq i64 %t243, 3
  store i1 %t245, ptr %l138, !tbaa !21
  br label %bb65
bb65:
  %t246 = load i1, ptr %l138, !tbaa !21
  br i1 %t246, label %bb66, label %bb67
bb66:
  %t247 = load ptr, ptr %l4, !tbaa !29
  %t249 = getelementptr { i64, [6 x i64] }, ptr %t247, i32 0, i32 1
  %t250 = getelementptr { ptr, ptr }, ptr %t249, i32 0, i32 1
  %t251 = load ptr, ptr %t250
  store ptr %t251, ptr %l24, !tbaa !29
  br label %bb68
bb67:
  br label %bb79
bb68:
  %t253 = load ptr, ptr %l24, !tbaa !29
  %t255 = icmp eq ptr %t253, null
  %t257 = xor i1 %t255, true
  br i1 %t257, label %bb69, label %bb70
bb69:
  %t259 = load ptr, ptr %l24, !tbaa !29
  %t261 = getelementptr %"compiler/ast:Func", ptr %t259, i32 0, i32 3
  %t262 = load ptr, ptr %t261, !tbaa !29
  %t264 = getelementptr %"compiler/ast:Sig", ptr %t262, i32 0, i32 0
  %t265 = load { i64, ptr }, ptr %t264, !tbaa !27
  store { i64, ptr } %t265, ptr %l25, !tbaa !27
  store i64 0, ptr %l26, !tbaa !24
  %t267 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t269 = extractvalue { i64, ptr } %t267, 0
  store i64 %t269, ptr %l27, !tbaa !24
  br label %bb71
bb70:
  br label %bb78
bb71:
  %t271 = load i64, ptr %l26, !tbaa !24
  %t272 = load i64, ptr %l27, !tbaa !24
  %t275 = icmp slt i64 %t271, %t272
  %t277 = xor i1 %t275, true
  br i1 %t277, label %bb72, label %bb73
bb72:
  br label %bb77
bb73:
  br label %bb74
bb74:
  %t279 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t279, ptr %l155, !tbaa !27
  %t280 = load i64, ptr %l26, !tbaa !24
  %t282 = getelementptr { i64, ptr }, ptr %l155, i32 0, i32 1
  %t283 = load ptr, ptr %t282, !tbaa !27
  %t284 = getelementptr ptr, ptr %t283, i64 %t280
  %t285 = load ptr, ptr %t284, !tbaa !39
  %t287 = load ptr, ptr %l0, !tbaa !29
  %t288 = load i64, ptr %l1, !tbaa !24
  %t291 = getelementptr %"compiler/ast:Param", ptr %t285, i32 0, i32 4
  %t292 = load { i64, ptr }, ptr %t291, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eattrsChecked(ptr %v0, ptr %v1, ptr %t287, i64 %t288, { i64, ptr } %t292)
  br label %bb75
bb75:
  br label %bb76
bb76:
  %t296 = load i64, ptr %l26, !tbaa !24
  %t298 = add i64 %t296, 1
  store i64 %t298, ptr %l26, !tbaa !24
  br label %bb71
bb77:
  br label %bb78
bb78:
  br label %bb84
bb79:
  br i1 true, label %bb80, label %bb81
bb80:
  br label %bb82
bb81:
  br label %bb83
bb82:
  br label %bb84
bb83:
  call void @__olang_check_failed(ptr @olang_loc_232d0577351be387_c741f4f8dd012e63)
  unreachable
bb84:
  br label %bb104
bb85:
  %t300 = load ptr, ptr %l2, !tbaa !29
  store ptr %t300, ptr %l164, !tbaa !29
  store i1 false, ptr %l165, !tbaa !21
  %t301 = load ptr, ptr %l164, !tbaa !29
  %t302 = icmp ne ptr %t301, null
  br i1 %t302, label %bb86, label %bb87
bb86:
  %t304 = load ptr, ptr %l164, !tbaa !29
  %t305 = load i64, ptr %t304
  %t307 = icmp eq i64 %t305, 0
  store i1 %t307, ptr %l165, !tbaa !21
  br label %bb87
bb87:
  %t308 = load i1, ptr %l165, !tbaa !21
  br i1 %t308, label %bb88, label %bb89
bb88:
  %t309 = load ptr, ptr %l2, !tbaa !29
  %t311 = getelementptr { i64, [6 x i64] }, ptr %t309, i32 0, i32 1
  %t312 = getelementptr { ptr }, ptr %t311, i32 0, i32 0
  %t313 = load ptr, ptr %t312
  store ptr %t313, ptr %l29, !tbaa !29
  br label %bb90
bb89:
  br label %bb99
bb90:
  %t315 = load ptr, ptr %l0, !tbaa !29
  %t316 = load i64, ptr %l1, !tbaa !24
  %t317 = load ptr, ptr %l29, !tbaa !29
  %t319 = getelementptr %"compiler/ast:Func", ptr %t317, i32 0, i32 8
  %t320 = load { i64, ptr }, ptr %t319, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eattrsChecked(ptr %v0, ptr %v1, ptr %t315, i64 %t316, { i64, ptr } %t320)
  br label %bb91
bb91:
  %t324 = load ptr, ptr %l29, !tbaa !29
  %t326 = getelementptr %"compiler/ast:Func", ptr %t324, i32 0, i32 3
  %t327 = load ptr, ptr %t326, !tbaa !29
  %t329 = getelementptr %"compiler/ast:Sig", ptr %t327, i32 0, i32 0
  %t330 = load { i64, ptr }, ptr %t329, !tbaa !27
  store { i64, ptr } %t330, ptr %l30, !tbaa !27
  store i64 0, ptr %l31, !tbaa !24
  %t332 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t334 = extractvalue { i64, ptr } %t332, 0
  store i64 %t334, ptr %l32, !tbaa !24
  br label %bb92
bb92:
  %t336 = load i64, ptr %l31, !tbaa !24
  %t337 = load i64, ptr %l32, !tbaa !24
  %t340 = icmp slt i64 %t336, %t337
  %t342 = xor i1 %t340, true
  br i1 %t342, label %bb93, label %bb94
bb93:
  br label %bb98
bb94:
  br label %bb95
bb95:
  %t344 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t344, ptr %l183, !tbaa !27
  %t345 = load i64, ptr %l31, !tbaa !24
  %t347 = getelementptr { i64, ptr }, ptr %l183, i32 0, i32 1
  %t348 = load ptr, ptr %t347, !tbaa !27
  %t349 = getelementptr ptr, ptr %t348, i64 %t345
  %t350 = load ptr, ptr %t349, !tbaa !39
  %t352 = load ptr, ptr %l0, !tbaa !29
  %t353 = load i64, ptr %l1, !tbaa !24
  %t356 = getelementptr %"compiler/ast:Param", ptr %t350, i32 0, i32 4
  %t357 = load { i64, ptr }, ptr %t356, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eattrsChecked(ptr %v0, ptr %v1, ptr %t352, i64 %t353, { i64, ptr } %t357)
  br label %bb96
bb96:
  br label %bb97
bb97:
  %t361 = load i64, ptr %l31, !tbaa !24
  %t363 = add i64 %t361, 1
  store i64 %t363, ptr %l31, !tbaa !24
  br label %bb92
bb98:
  br label %bb104
bb99:
  br i1 true, label %bb100, label %bb101
bb100:
  br label %bb102
bb101:
  br label %bb103
bb102:
  br label %bb104
bb103:
  call void @__olang_check_failed(ptr @olang_loc_f1a1025985678426_2b1dd11da3705062)
  unreachable
bb104:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca ptr
  %l9 = alloca i32
  %l10 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  store ptr %t6, ptr %l4, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t12, i32 %a1)
  store i32 %t16, ptr %l9
  br label %bb1
bb1:
  %t17 = load ptr, ptr %l4, !tbaa !29
  %t18 = load i32, ptr %l9, !tbaa !23
  %t19 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t17, i32 %t18)
  store i32 %t19, ptr %l10
  br label %bb2
bb2:
  %t20 = load i32, ptr %l10
  store i32 %t20, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edescName(ptr %v0, ptr %v1, ptr %a0, %"compiler/generic:Desc" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/generic:Desc"
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca %"compiler/generic:Desc"
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l12 = alloca i32
  %l18 = alloca i1
  %l19 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l41 = alloca i64
  %l42 = alloca { i64, ptr }
  %l48 = alloca i1
  %l49 = alloca ptr
  %l52 = alloca ptr
  %l57 = alloca i32
  %l58 = alloca i32
  %l59 = alloca { i64, ptr }
  %l65 = alloca i32
  %l71 = alloca { i64, ptr }
  %l76 = alloca { i64, ptr }
  %l82 = alloca { i64, ptr }
  %l83 = alloca { i64, ptr }
  %l85 = alloca i64
  %l86 = alloca { i64, ptr }
  %l91 = alloca { i64, ptr }
  %l96 = alloca { i64, ptr }
  %l98 = alloca { i64, ptr }
  %l101 = alloca { i64, ptr }
  %l103 = alloca { i64, ptr }
  %l105 = alloca i64
  %l106 = alloca { i64, ptr }
  %l110 = alloca ptr
  %l114 = alloca ptr
  %l117 = alloca { i64, ptr }
  %l126 = alloca i32
  %l129 = alloca { i64, ptr }
  %l130 = alloca { i64, ptr }
  %l131 = alloca i64
  %l132 = alloca { i64, ptr }
  %l136 = alloca %"compiler/generic:Desc"
  %l143 = alloca ptr
  %l151 = alloca { i64, ptr }
  %l153 = alloca { i64, ptr }
  %l157 = alloca { i64, ptr }
  %l159 = alloca { i64, ptr }
  %l161 = alloca i64
  %l162 = alloca { i64, ptr }
  %l166 = alloca { i64, ptr }
  %l171 = alloca { i64, ptr }
  %l173 = alloca { i64, ptr }
  %l177 = alloca { i64, ptr }
  %l179 = alloca { i64, ptr }
  %l181 = alloca i64
  %l182 = alloca { i64, ptr }
  %l183 = alloca { i64, ptr }
  %l184 = alloca { i64, ptr }
  %l185 = alloca i64
  %l186 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store %"compiler/generic:Desc" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = getelementptr %"compiler/generic:Desc", ptr %l1, i32 0, i32 1
  %t6 = load i32, ptr %t5, !tbaa !23
  %t9 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eReflUnder(ptr %v0, ptr %t4, i32 %t6)
  store i32 %t9, ptr %l12
  br label %bb1
bb1:
  %t10 = load i32, ptr %l12, !tbaa !23
  store i32 %t10, ptr %l2, !tbaa !23
  %t11 = getelementptr %"compiler/generic:Desc", ptr %l1, i32 0, i32 0
  %t12 = load i64, ptr %t11, !tbaa !24
  %t13 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescField, !tbaa !24
  %t16 = icmp eq i64 %t12, %t13
  br i1 %t16, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load i32, ptr %l2, !tbaa !23
  %t22 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisStruct(ptr %v0, ptr %t18, i32 %t19)
  store i1 %t22, ptr %l18
  br label %bb4
bb3:
  br label %bb14
bb4:
  %t23 = load i1, ptr %l18, !tbaa !21
  br i1 %t23, label %bb5, label %bb6
bb5:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/check:Checker", ptr %t24, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t28 = load i32, ptr %l2, !tbaa !23
  %t31 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFieldNames(ptr %v0, ptr %s1, ptr %t27, i32 %t28)
  store { i64, ptr } %t31, ptr %l23
  br label %bb7
bb6:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/check:Checker", ptr %t32, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t36 = load i32, ptr %l2, !tbaa !23
  %t37 = getelementptr %"compiler/generic:Desc", ptr %l1, i32 0, i32 2
  %t38 = load i64, ptr %t37, !tbaa !24
  %t42 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCaseFieldNames(ptr %v0, ptr %s1, ptr %t35, i32 %t36, i64 %t38)
  store { i64, ptr } %t42, ptr %l28
  br label %bb8
bb7:
  %t43 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t43, ptr %l19, !tbaa !27
  br label %bb9
bb8:
  %t44 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t44, ptr %l19, !tbaa !27
  br label %bb9
bb9:
  %t45 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t45, ptr %l3, !tbaa !27
  %t46 = getelementptr %"compiler/generic:Desc", ptr %l1, i32 0, i32 3
  %t47 = load i64, ptr %t46, !tbaa !24
  %t48 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t48, 0
  %t53 = icmp slt i64 %t47, %t50
  br i1 %t53, label %bb10, label %bb11
bb10:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/generic:Desc", ptr %l1, i32 0, i32 3
  %t57 = load i64, ptr %t56, !tbaa !24
  %t59 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = getelementptr i32, ptr %t60, i64 %t57
  %t62 = load i32, ptr %t61, !tbaa !33
  %t65 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t55, i32 %t62)
  store { i64, ptr } %t65, ptr %l37
  br label %bb12
bb11:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d10, i32 0, i32 1) }, ptr %l39, !tbaa !27
  %t66 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t66, ptr %l33, !tbaa !27
  br label %bb13
bb12:
  %t68 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t68, 1
  %t70 = extractvalue { i64, ptr } %t68, 0
  %t71 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t70)
  call void @olang_textcopy(ptr %t71, ptr %t69, i64 %t70)
  %t72 = insertvalue { i64, ptr } undef, i64 %t70, 0
  %t73 = insertvalue { i64, ptr } %t72, ptr %t71, 1
  store { i64, ptr } %t73, ptr %l33, !tbaa !27
  br label %bb13
bb13:
  %t75 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t76 = extractvalue { i64, ptr } %t75, 0
  store i64 %t76, ptr %l41, !tbaa !24
  %t77 = load i64, ptr %l41, !tbaa !24
  %t78 = mul i64 %t77, 1
  %t79 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t78)
  %t80 = insertvalue { i64, ptr } undef, i64 %t77, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t79, 1
  store { i64, ptr } %t81, ptr %l42, !tbaa !27
  %t82 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !27
  %t84 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !27
  %t86 = load i64, ptr %l41, !tbaa !24
  %t87 = mul i64 %t86, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t83, ptr %t85, i64 %t87, i1 false)
  %t88 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t88, ptr %l33, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  %t89 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t89, ptr %rv
  br label %ret
bb14:
  %t90 = getelementptr %"compiler/generic:Desc", ptr %l1, i32 0, i32 0
  %t91 = load i64, ptr %t90, !tbaa !24
  %t92 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescCase, !tbaa !24
  %t95 = icmp eq i64 %t91, %t92
  br i1 %t95, label %bb15, label %bb16
bb15:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t98 = load i32, ptr %l2, !tbaa !23
  %t101 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisStruct(ptr %v0, ptr %t97, i32 %t98)
  store i1 %t101, ptr %l48
  br label %bb17
bb16:
  br label %bb38
bb17:
  %t102 = load i1, ptr %l48, !tbaa !21
  br i1 %t102, label %bb18, label %bb19
bb18:
  %t103 = load ptr, ptr %l0, !tbaa !29
  store ptr %t103, ptr %l49, !tbaa !29
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = getelementptr %"compiler/check:Checker", ptr %t104, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !29
  %t109 = getelementptr %"compiler/generic:Program", ptr %t107, i32 0, i32 2
  store ptr %t109, ptr %l52, !tbaa !29
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = getelementptr %"compiler/check:Checker", ptr %t110, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !29
  %t115 = getelementptr %"compiler/generic:Program", ptr %t113, i32 0, i32 2
  %t116 = load i32, ptr %l2, !tbaa !23
  %t119 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t115, i32 %t116)
  store i32 %t119, ptr %l57
  br label %bb20
bb19:
  br label %bb23
bb20:
  %t120 = load ptr, ptr %l52, !tbaa !29
  %t121 = load i32, ptr %l57, !tbaa !23
  %t122 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t120, i32 %t121)
  store i32 %t122, ptr %l58
  br label %bb21
bb21:
  %t123 = load ptr, ptr %l49, !tbaa !29
  %t124 = load i32, ptr %l58, !tbaa !23
  %t125 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t123, i32 %t124)
  store { i64, ptr } %t125, ptr %l59
  br label %bb22
bb22:
  %t126 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t127 = extractvalue { i64, ptr } %t126, 1
  %t128 = extractvalue { i64, ptr } %t126, 0
  %t129 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t128)
  call void @olang_textcopy(ptr %t129, ptr %t127, i64 %t128)
  %t130 = insertvalue { i64, ptr } undef, i64 %t128, 0
  %t131 = insertvalue { i64, ptr } %t130, ptr %t129, 1
  store { i64, ptr } %t131, ptr %rv
  br label %ret
bb23:
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t135 = getelementptr %"compiler/check:Checker", ptr %t133, i32 0, i32 1
  %t136 = load ptr, ptr %t135, !tbaa !29
  %t138 = getelementptr %"compiler/generic:Program", ptr %t136, i32 0, i32 2
  %t139 = load i32, ptr %l2, !tbaa !23
  %t142 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t138, i32 %t139)
  store i32 %t142, ptr %l65
  br label %bb24
bb24:
  %t143 = load i32, ptr %l65
  %t145 = trunc i64 32 to i32
  %t146 = icmp eq i32 %t143, %t145
  br i1 %t146, label %bb25, label %bb26
bb25:
  store %olang.scope zeroinitializer, ptr %s6
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t150 = getelementptr %"compiler/check:Checker", ptr %t148, i32 0, i32 1
  %t151 = load ptr, ptr %t150, !tbaa !29
  %t152 = load i32, ptr %l2, !tbaa !23
  %t155 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrValCodes(ptr %v0, ptr %s6, ptr %t151, i32 %t152)
  store { i64, ptr } %t155, ptr %l71
  br label %bb27
bb26:
  br label %bb32
bb27:
  %t156 = load { i64, ptr }, ptr %l71, !tbaa !27
  store { i64, ptr } %t156, ptr %l4, !tbaa !27
  %t157 = getelementptr %"compiler/generic:Desc", ptr %l1, i32 0, i32 2
  %t158 = load i64, ptr %t157, !tbaa !24
  %t159 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t161 = extractvalue { i64, ptr } %t159, 0
  %t164 = icmp slt i64 %t158, %t161
  br i1 %t164, label %bb28, label %bb29
bb28:
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t168 = getelementptr %"compiler/check:Checker", ptr %t166, i32 0, i32 1
  %t169 = load ptr, ptr %t168, !tbaa !29
  %t170 = load i32, ptr %l2, !tbaa !23
  %t171 = getelementptr %"compiler/generic:Desc", ptr %l1, i32 0, i32 2
  %t172 = load i64, ptr %t171, !tbaa !24
  %t174 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t175 = load ptr, ptr %t174, !tbaa !27
  %t176 = getelementptr i64, ptr %t175, i64 %t172
  %t177 = load i64, ptr %t176, !tbaa !34
  %t181 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrValWordText(ptr %v0, ptr %v1, ptr %t169, i32 %t170, i64 %t177)
  store { i64, ptr } %t181, ptr %l82
  br label %bb30
bb29:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d11, i32 0, i32 1) }, ptr %l83, !tbaa !27
  %t182 = load { i64, ptr }, ptr %l83, !tbaa !27
  store { i64, ptr } %t182, ptr %l76, !tbaa !27
  br label %bb31
bb30:
  %t184 = load { i64, ptr }, ptr %l82, !tbaa !27
  store { i64, ptr } %t184, ptr %l76, !tbaa !27
  br label %bb31
bb31:
  %t185 = load { i64, ptr }, ptr %l76, !tbaa !27
  %t186 = extractvalue { i64, ptr } %t185, 0
  store i64 %t186, ptr %l85, !tbaa !24
  %t187 = load i64, ptr %l85, !tbaa !24
  %t188 = mul i64 %t187, 1
  %t189 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t188)
  %t190 = insertvalue { i64, ptr } undef, i64 %t187, 0
  %t191 = insertvalue { i64, ptr } %t190, ptr %t189, 1
  store { i64, ptr } %t191, ptr %l86, !tbaa !27
  %t192 = getelementptr { i64, ptr }, ptr %l86, i32 0, i32 1
  %t193 = load ptr, ptr %t192, !tbaa !27
  %t194 = getelementptr { i64, ptr }, ptr %l76, i32 0, i32 1
  %t195 = load ptr, ptr %t194, !tbaa !27
  %t196 = load i64, ptr %l85, !tbaa !24
  %t197 = mul i64 %t196, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t193, ptr %t195, i64 %t197, i1 false)
  %t198 = load { i64, ptr }, ptr %l86, !tbaa !27
  store { i64, ptr } %t198, ptr %l76, !tbaa !27
  call void @__olang_scope_close(ptr %s6)
  %t199 = load { i64, ptr }, ptr %l76, !tbaa !27
  store { i64, ptr } %t199, ptr %rv
  br label %ret
bb32:
  %t200 = load ptr, ptr %l0, !tbaa !29
  %t202 = getelementptr %"compiler/check:Checker", ptr %t200, i32 0, i32 1
  %t203 = load ptr, ptr %t202, !tbaa !29
  %t205 = getelementptr %"compiler/generic:Program", ptr %t203, i32 0, i32 2
  %t206 = load i32, ptr %l2, !tbaa !23
  %t209 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCaseNames(ptr %v0, ptr %t205, i32 %t206)
  store { i64, ptr } %t209, ptr %l91
  br label %bb33
bb33:
  %t210 = load { i64, ptr }, ptr %l91, !tbaa !27
  store { i64, ptr } %t210, ptr %l5, !tbaa !27
  %t211 = getelementptr %"compiler/generic:Desc", ptr %l1, i32 0, i32 2
  %t212 = load i64, ptr %t211, !tbaa !24
  %t213 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t215 = extractvalue { i64, ptr } %t213, 0
  %t218 = icmp slt i64 %t212, %t215
  br i1 %t218, label %bb34, label %bb35
bb34:
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t221 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t221, ptr %l98, !tbaa !27
  %t222 = getelementptr %"compiler/generic:Desc", ptr %l1, i32 0, i32 2
  %t223 = load i64, ptr %t222, !tbaa !24
  %t225 = getelementptr { i64, ptr }, ptr %l98, i32 0, i32 1
  %t226 = load ptr, ptr %t225, !tbaa !27
  %t227 = getelementptr i32, ptr %t226, i64 %t223
  %t228 = load i32, ptr %t227, !tbaa !33
  %t231 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t220, i32 %t228)
  store { i64, ptr } %t231, ptr %l101
  br label %bb36
bb35:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d12, i32 0, i32 1) }, ptr %l103, !tbaa !27
  %t232 = load { i64, ptr }, ptr %l103, !tbaa !27
  store { i64, ptr } %t232, ptr %l96, !tbaa !27
  br label %bb37
bb36:
  %t234 = load { i64, ptr }, ptr %l101, !tbaa !27
  %t235 = extractvalue { i64, ptr } %t234, 1
  %t236 = extractvalue { i64, ptr } %t234, 0
  %t237 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t236)
  call void @olang_textcopy(ptr %t237, ptr %t235, i64 %t236)
  %t238 = insertvalue { i64, ptr } undef, i64 %t236, 0
  %t239 = insertvalue { i64, ptr } %t238, ptr %t237, 1
  store { i64, ptr } %t239, ptr %l96, !tbaa !27
  br label %bb37
bb37:
  %t241 = load { i64, ptr }, ptr %l96, !tbaa !27
  %t242 = extractvalue { i64, ptr } %t241, 0
  store i64 %t242, ptr %l105, !tbaa !24
  %t243 = load i64, ptr %l105, !tbaa !24
  %t244 = mul i64 %t243, 1
  %t245 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t244)
  %t246 = insertvalue { i64, ptr } undef, i64 %t243, 0
  %t247 = insertvalue { i64, ptr } %t246, ptr %t245, 1
  store { i64, ptr } %t247, ptr %l106, !tbaa !27
  %t248 = getelementptr { i64, ptr }, ptr %l106, i32 0, i32 1
  %t249 = load ptr, ptr %t248, !tbaa !27
  %t250 = getelementptr { i64, ptr }, ptr %l96, i32 0, i32 1
  %t251 = load ptr, ptr %t250, !tbaa !27
  %t252 = load i64, ptr %l105, !tbaa !24
  %t253 = mul i64 %t252, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t249, ptr %t251, i64 %t253, i1 false)
  %t254 = load { i64, ptr }, ptr %l106, !tbaa !27
  store { i64, ptr } %t254, ptr %l96, !tbaa !27
  %t255 = load { i64, ptr }, ptr %l96, !tbaa !27
  store { i64, ptr } %t255, ptr %rv
  br label %ret
bb38:
  %t256 = getelementptr %"compiler/generic:Desc", ptr %l1, i32 0, i32 0
  %t257 = load i64, ptr %t256, !tbaa !24
  %t258 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescFunc, !tbaa !24
  %t261 = icmp eq i64 %t257, %t258
  br i1 %t261, label %bb39, label %bb40
bb39:
  %t263 = load ptr, ptr %l0, !tbaa !29
  store ptr %t263, ptr %l110, !tbaa !29
  %t264 = load ptr, ptr %l0, !tbaa !29
  %t266 = getelementptr %"compiler/check:Checker", ptr %t264, i32 0, i32 1
  %t267 = load ptr, ptr %t266, !tbaa !29
  %t268 = getelementptr %"compiler/generic:Desc", ptr %l1, i32 0, i32 2
  %t269 = load i64, ptr %t268, !tbaa !24
  %t272 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t267, i64 %t269)
  store ptr %t272, ptr %l114
  br label %bb41
bb40:
  br label %bb43
bb41:
  %t273 = load ptr, ptr %l114, !tbaa !29
  %t275 = getelementptr %"compiler/ast:Func", ptr %t273, i32 0, i32 2
  %t276 = load i32, ptr %t275, !tbaa !23
  %t277 = load ptr, ptr %l110, !tbaa !29
  %t279 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t277, i32 %t276)
  store { i64, ptr } %t279, ptr %l117
  br label %bb42
bb42:
  %t280 = load { i64, ptr }, ptr %l117, !tbaa !27
  %t281 = extractvalue { i64, ptr } %t280, 1
  %t282 = extractvalue { i64, ptr } %t280, 0
  %t283 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t282)
  call void @olang_textcopy(ptr %t283, ptr %t281, i64 %t282)
  %t284 = insertvalue { i64, ptr } undef, i64 %t282, 0
  %t285 = insertvalue { i64, ptr } %t284, ptr %t283, 1
  store { i64, ptr } %t285, ptr %rv
  br label %ret
bb43:
  %t287 = getelementptr %"compiler/generic:Desc", ptr %l1, i32 0, i32 0
  %t288 = load i64, ptr %t287, !tbaa !24
  %t289 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescParam, !tbaa !24
  %t292 = icmp eq i64 %t288, %t289
  br i1 %t292, label %bb44, label %bb45
bb44:
  %t294 = load ptr, ptr %l0, !tbaa !29
  %t296 = getelementptr %"compiler/check:Checker", ptr %t294, i32 0, i32 1
  %t297 = load ptr, ptr %t296, !tbaa !29
  %t299 = getelementptr %"compiler/generic:Program", ptr %t297, i32 0, i32 2
  %t300 = getelementptr %"compiler/generic:Desc", ptr %l1, i32 0, i32 1
  %t301 = load i32, ptr %t300, !tbaa !23
  %t304 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t299, i32 %t301)
  store i32 %t304, ptr %l126
  br label %bb46
bb45:
  br label %bb64
bb46:
  %t305 = load i32, ptr %l126
  %t307 = trunc i64 21 to i32
  %t308 = icmp eq i32 %t305, %t307
  br i1 %t308, label %bb47, label %bb48
bb47:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d13, i32 0, i32 1) }, ptr %l129, !tbaa !27
  %t310 = load { i64, ptr }, ptr %l129, !tbaa !27
  store { i64, ptr } %t310, ptr %l130, !tbaa !27
  %t311 = load { i64, ptr }, ptr %l130, !tbaa !27
  %t312 = extractvalue { i64, ptr } %t311, 0
  store i64 %t312, ptr %l131, !tbaa !24
  %t313 = load i64, ptr %l131, !tbaa !24
  %t314 = mul i64 %t313, 1
  %t315 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t314)
  %t316 = insertvalue { i64, ptr } undef, i64 %t313, 0
  %t317 = insertvalue { i64, ptr } %t316, ptr %t315, 1
  store { i64, ptr } %t317, ptr %l132, !tbaa !27
  %t318 = getelementptr { i64, ptr }, ptr %l132, i32 0, i32 1
  %t319 = load ptr, ptr %t318, !tbaa !27
  %t320 = getelementptr { i64, ptr }, ptr %l130, i32 0, i32 1
  %t321 = load ptr, ptr %t320, !tbaa !27
  %t322 = load i64, ptr %l131, !tbaa !24
  %t323 = mul i64 %t322, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t319, ptr %t321, i64 %t323, i1 false)
  %t324 = load { i64, ptr }, ptr %l132, !tbaa !27
  store { i64, ptr } %t324, ptr %l130, !tbaa !27
  %t325 = load { i64, ptr }, ptr %l130, !tbaa !27
  store { i64, ptr } %t325, ptr %rv
  br label %ret
bb48:
  br label %bb49
bb49:
  %t326 = load ptr, ptr %l0, !tbaa !29
  %t328 = getelementptr %"compiler/check:Checker", ptr %t326, i32 0, i32 1
  %t329 = load ptr, ptr %t328, !tbaa !29
  %t330 = getelementptr %"compiler/generic:Desc", ptr %l1, i32 0, i32 1
  %t331 = load i32, ptr %t330, !tbaa !23
  %t334 = call %"compiler/generic:Desc" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDescOf(ptr %v0, ptr %t329, i32 %t331)
  store %"compiler/generic:Desc" %t334, ptr %l136
  br label %bb50
bb50:
  %t335 = load %"compiler/generic:Desc", ptr %l136
  store %"compiler/generic:Desc" %t335, ptr %l6
  %t336 = getelementptr %"compiler/generic:Desc", ptr %l6, i32 0, i32 0
  %t337 = load i64, ptr %t336, !tbaa !24
  %t338 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescFunc, !tbaa !24
  %t341 = icmp eq i64 %t337, %t338
  br i1 %t341, label %bb51, label %bb52
bb51:
  %t343 = load ptr, ptr %l0, !tbaa !29
  %t345 = getelementptr %"compiler/check:Checker", ptr %t343, i32 0, i32 1
  %t346 = load ptr, ptr %t345, !tbaa !29
  %t347 = getelementptr %"compiler/generic:Desc", ptr %l6, i32 0, i32 2
  %t348 = load i64, ptr %t347, !tbaa !24
  %t351 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t346, i64 %t348)
  store ptr %t351, ptr %l143
  br label %bb53
bb52:
  br label %bb58
bb53:
  %t352 = load ptr, ptr %l143, !tbaa !29
  %t354 = getelementptr %"compiler/ast:Func", ptr %t352, i32 0, i32 3
  %t355 = load ptr, ptr %t354, !tbaa !29
  %t357 = getelementptr %"compiler/ast:Sig", ptr %t355, i32 0, i32 0
  %t358 = load { i64, ptr }, ptr %t357, !tbaa !27
  store { i64, ptr } %t358, ptr %l7, !tbaa !27
  %t360 = getelementptr %"compiler/generic:Desc", ptr %l1, i32 0, i32 3
  %t361 = load i64, ptr %t360, !tbaa !24
  %t362 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t364 = extractvalue { i64, ptr } %t362, 0
  %t367 = icmp slt i64 %t361, %t364
  br i1 %t367, label %bb54, label %bb55
bb54:
  %t369 = load ptr, ptr %l0, !tbaa !29
  %t370 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t370, ptr %l153, !tbaa !27
  %t371 = getelementptr %"compiler/generic:Desc", ptr %l1, i32 0, i32 3
  %t372 = load i64, ptr %t371, !tbaa !24
  %t374 = getelementptr { i64, ptr }, ptr %l153, i32 0, i32 1
  %t375 = load ptr, ptr %t374, !tbaa !27
  %t376 = getelementptr ptr, ptr %t375, i64 %t372
  %t377 = load ptr, ptr %t376, !tbaa !39
  %t379 = getelementptr %"compiler/ast:Param", ptr %t377, i32 0, i32 1
  %t380 = load i32, ptr %t379, !tbaa !23
  %t383 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t369, i32 %t380)
  store { i64, ptr } %t383, ptr %l157
  br label %bb56
bb55:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d14, i32 0, i32 1) }, ptr %l159, !tbaa !27
  %t384 = load { i64, ptr }, ptr %l159, !tbaa !27
  store { i64, ptr } %t384, ptr %l151, !tbaa !27
  br label %bb57
bb56:
  %t386 = load { i64, ptr }, ptr %l157, !tbaa !27
  %t387 = extractvalue { i64, ptr } %t386, 1
  %t388 = extractvalue { i64, ptr } %t386, 0
  %t389 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t388)
  call void @olang_textcopy(ptr %t389, ptr %t387, i64 %t388)
  %t390 = insertvalue { i64, ptr } undef, i64 %t388, 0
  %t391 = insertvalue { i64, ptr } %t390, ptr %t389, 1
  store { i64, ptr } %t391, ptr %l151, !tbaa !27
  br label %bb57
bb57:
  %t393 = load { i64, ptr }, ptr %l151, !tbaa !27
  %t394 = extractvalue { i64, ptr } %t393, 0
  store i64 %t394, ptr %l161, !tbaa !24
  %t395 = load i64, ptr %l161, !tbaa !24
  %t396 = mul i64 %t395, 1
  %t397 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t396)
  %t398 = insertvalue { i64, ptr } undef, i64 %t395, 0
  %t399 = insertvalue { i64, ptr } %t398, ptr %t397, 1
  store { i64, ptr } %t399, ptr %l162, !tbaa !27
  %t400 = getelementptr { i64, ptr }, ptr %l162, i32 0, i32 1
  %t401 = load ptr, ptr %t400, !tbaa !27
  %t402 = getelementptr { i64, ptr }, ptr %l151, i32 0, i32 1
  %t403 = load ptr, ptr %t402, !tbaa !27
  %t404 = load i64, ptr %l161, !tbaa !24
  %t405 = mul i64 %t404, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t401, ptr %t403, i64 %t405, i1 false)
  %t406 = load { i64, ptr }, ptr %l162, !tbaa !27
  store { i64, ptr } %t406, ptr %l151, !tbaa !27
  %t407 = load { i64, ptr }, ptr %l151, !tbaa !27
  store { i64, ptr } %t407, ptr %rv
  br label %ret
bb58:
  %t408 = load ptr, ptr %l0, !tbaa !29
  %t410 = getelementptr %"compiler/check:Checker", ptr %t408, i32 0, i32 1
  %t411 = load ptr, ptr %t410, !tbaa !29
  %t412 = getelementptr %"compiler/generic:Desc", ptr %l1, i32 0, i32 1
  %t413 = load i32, ptr %t412, !tbaa !23
  %t416 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorParams(ptr %v0, ptr %t411, i32 %t413)
  store { i64, ptr } %t416, ptr %l166
  br label %bb59
bb59:
  %t417 = load { i64, ptr }, ptr %l166, !tbaa !27
  store { i64, ptr } %t417, ptr %l8, !tbaa !27
  %t418 = getelementptr %"compiler/generic:Desc", ptr %l1, i32 0, i32 3
  %t419 = load i64, ptr %t418, !tbaa !24
  %t420 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t422 = extractvalue { i64, ptr } %t420, 0
  %t425 = icmp slt i64 %t419, %t422
  br i1 %t425, label %bb60, label %bb61
bb60:
  %t427 = load ptr, ptr %l0, !tbaa !29
  %t428 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t428, ptr %l173, !tbaa !27
  %t429 = getelementptr %"compiler/generic:Desc", ptr %l1, i32 0, i32 3
  %t430 = load i64, ptr %t429, !tbaa !24
  %t432 = getelementptr { i64, ptr }, ptr %l173, i32 0, i32 1
  %t433 = load ptr, ptr %t432, !tbaa !27
  %t434 = getelementptr ptr, ptr %t433, i64 %t430
  %t435 = load ptr, ptr %t434, !tbaa !39
  %t437 = getelementptr %"compiler/ast:Param", ptr %t435, i32 0, i32 1
  %t438 = load i32, ptr %t437, !tbaa !23
  %t441 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t427, i32 %t438)
  store { i64, ptr } %t441, ptr %l177
  br label %bb62
bb61:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d15, i32 0, i32 1) }, ptr %l179, !tbaa !27
  %t442 = load { i64, ptr }, ptr %l179, !tbaa !27
  store { i64, ptr } %t442, ptr %l171, !tbaa !27
  br label %bb63
bb62:
  %t444 = load { i64, ptr }, ptr %l177, !tbaa !27
  %t445 = extractvalue { i64, ptr } %t444, 1
  %t446 = extractvalue { i64, ptr } %t444, 0
  %t447 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t446)
  call void @olang_textcopy(ptr %t447, ptr %t445, i64 %t446)
  %t448 = insertvalue { i64, ptr } undef, i64 %t446, 0
  %t449 = insertvalue { i64, ptr } %t448, ptr %t447, 1
  store { i64, ptr } %t449, ptr %l171, !tbaa !27
  br label %bb63
bb63:
  %t451 = load { i64, ptr }, ptr %l171, !tbaa !27
  %t452 = extractvalue { i64, ptr } %t451, 0
  store i64 %t452, ptr %l181, !tbaa !24
  %t453 = load i64, ptr %l181, !tbaa !24
  %t454 = mul i64 %t453, 1
  %t455 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t454)
  %t456 = insertvalue { i64, ptr } undef, i64 %t453, 0
  %t457 = insertvalue { i64, ptr } %t456, ptr %t455, 1
  store { i64, ptr } %t457, ptr %l182, !tbaa !27
  %t458 = getelementptr { i64, ptr }, ptr %l182, i32 0, i32 1
  %t459 = load ptr, ptr %t458, !tbaa !27
  %t460 = getelementptr { i64, ptr }, ptr %l171, i32 0, i32 1
  %t461 = load ptr, ptr %t460, !tbaa !27
  %t462 = load i64, ptr %l181, !tbaa !24
  %t463 = mul i64 %t462, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t459, ptr %t461, i64 %t463, i1 false)
  %t464 = load { i64, ptr }, ptr %l182, !tbaa !27
  store { i64, ptr } %t464, ptr %l171, !tbaa !27
  %t465 = load { i64, ptr }, ptr %l171, !tbaa !27
  store { i64, ptr } %t465, ptr %rv
  br label %ret
bb64:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d16, i32 0, i32 1) }, ptr %l183, !tbaa !27
  %t466 = load { i64, ptr }, ptr %l183, !tbaa !27
  store { i64, ptr } %t466, ptr %l184, !tbaa !27
  %t467 = load { i64, ptr }, ptr %l184, !tbaa !27
  %t468 = extractvalue { i64, ptr } %t467, 0
  store i64 %t468, ptr %l185, !tbaa !24
  %t469 = load i64, ptr %l185, !tbaa !24
  %t470 = mul i64 %t469, 1
  %t471 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t470)
  %t472 = insertvalue { i64, ptr } undef, i64 %t469, 0
  %t473 = insertvalue { i64, ptr } %t472, ptr %t471, 1
  store { i64, ptr } %t473, ptr %l186, !tbaa !27
  %t474 = getelementptr { i64, ptr }, ptr %l186, i32 0, i32 1
  %t475 = load ptr, ptr %t474, !tbaa !27
  %t476 = getelementptr { i64, ptr }, ptr %l184, i32 0, i32 1
  %t477 = load ptr, ptr %t476, !tbaa !27
  %t478 = load i64, ptr %l185, !tbaa !24
  %t479 = mul i64 %t478, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t475, ptr %t477, i64 %t479, i1 false)
  %t480 = load { i64, ptr }, ptr %l186, !tbaa !27
  store { i64, ptr } %t480, ptr %l184, !tbaa !27
  %t481 = load { i64, ptr }, ptr %l184, !tbaa !27
  store { i64, ptr } %t481, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edoFor(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca { i64, i64, i64 }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca { i64, i64, i64 }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l18 = alloca i64
  %l22 = alloca { i64, i64, i64 }
  %l27 = alloca ptr
  %l32 = alloca ptr
  %l41 = alloca i64
  %l43 = alloca ptr
  %l46 = alloca i64
  %l47 = alloca i32
  %l48 = alloca i64
  %l50 = alloca ptr
  %l53 = alloca i64
  %l54 = alloca i32
  %l60 = alloca ptr
  %l63 = alloca i64
  %l67 = alloca { i64, i64, i64 }
  %l71 = alloca ptr
  %l72 = alloca ptr
  %l73 = alloca %"compiler/source:Span"
  %l76 = alloca ptr
  %l78 = alloca ptr
  %l84 = alloca ptr
  %t144 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 37
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l18
  br label %bb1
bb1:
  %t6 = load i64, ptr %l18, !tbaa !24
  store i64 %t6, ptr %l4, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load %"compiler/source:Span", ptr %l1
  %t12 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t7, i32 2, %"compiler/source:Span" %t8)
  store { i64, i64, i64 } %t12, ptr %l22
  br label %bb2
bb2:
  %t13 = load { i64, i64, i64 }, ptr %l22
  store { i64, i64, i64 } %t13, ptr %l5
  %t14 = getelementptr { i64, i64, i64 }, ptr %l5, i32 0, i32 0
  %t15 = load i64, ptr %t14, !tbaa !24
  store i64 %t15, ptr %l6, !tbaa !24
  %t17 = getelementptr { i64, i64, i64 }, ptr %l5, i32 0, i32 1
  %t18 = load i64, ptr %t17, !tbaa !24
  store i64 %t18, ptr %l7, !tbaa !24
  %t20 = getelementptr { i64, i64, i64 }, ptr %l5, i32 0, i32 2
  %t21 = load i64, ptr %t20, !tbaa !24
  store i64 %t21, ptr %l8, !tbaa !24
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t23)
  store ptr %t25, ptr %l27
  br label %bb3
bb3:
  %t26 = load ptr, ptr %l27, !tbaa !29
  %t28 = getelementptr %"compiler/check:frame", ptr %t26, i32 0, i32 10
  %t29 = load i64, ptr %l6, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t28, i64 %t29)
  br label %bb4
bb4:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t32)
  store ptr %t34, ptr %l32
  br label %bb5
bb5:
  %t35 = load ptr, ptr %l32, !tbaa !29
  %t37 = getelementptr %"compiler/check:frame", ptr %t35, i32 0, i32 11
  %t38 = load i64, ptr %l6, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t37, i64 %t38)
  br label %bb6
bb6:
  %t41 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t41, 0
  %t45 = icmp sgt i64 %t43, 0
  br i1 %t45, label %bb7, label %bb8
bb7:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load { i64, ptr }, ptr %l2, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmtsOf(ptr %v0, ptr %v1, ptr %t47, { i64, ptr } %t48)
  br label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb10
bb10:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t51)
  store ptr %t53, ptr %l43
  br label %bb11
bb11:
  %t54 = load ptr, ptr %l43, !tbaa !29
  %t56 = getelementptr %"compiler/check:frame", ptr %t54, i32 0, i32 10
  %t58 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t56)
  %t59 = extractvalue { i32, i64 } %t58, 1
  %t60 = extractvalue { i32, i64 } %t58, 0
  store i32 %t60, ptr %l47
  %t61 = icmp ne i32 %t60, 0
  br i1 %t61, label %bb13, label %ok.62, !prof !99
ok.62:
  store i64 %t59, ptr %l46
  br label %bb12
bb12:
  %t63 = load i64, ptr %l46, !tbaa !24
  store i64 %t63, ptr %l41, !tbaa !24
  br label %bb15
bb13:
  br label %bb14
bb14:
  call void @__olang_ert_req_clear()
  br label %bb15
bb15:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t64)
  store ptr %t66, ptr %l50
  br label %bb16
bb16:
  %t67 = load ptr, ptr %l50, !tbaa !29
  %t69 = getelementptr %"compiler/check:frame", ptr %t67, i32 0, i32 11
  %t71 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t69)
  %t72 = extractvalue { i32, i64 } %t71, 1
  %t73 = extractvalue { i32, i64 } %t71, 0
  store i32 %t73, ptr %l54
  %t74 = icmp ne i32 %t73, 0
  br i1 %t74, label %bb18, label %ok.75, !prof !99
ok.75:
  store i64 %t72, ptr %l53
  br label %bb17
bb17:
  %t76 = load i64, ptr %l53, !tbaa !24
  store i64 %t76, ptr %l48, !tbaa !24
  br label %bb20
bb18:
  br label %bb19
bb19:
  call void @__olang_ert_req_clear()
  br label %bb20
bb20:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t78 = load i64, ptr %l6, !tbaa !24
  %t79 = load i64, ptr %l7, !tbaa !24
  %t80 = load i64, ptr %l8, !tbaa !24
  %t81 = load i64, ptr %l4, !tbaa !24
  %t87 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %t77, i64 %t78, i64 %t79, i64 %t80, i64 %t81)
  store ptr %t87, ptr %l60
  br label %bb21
bb21:
  %t88 = load ptr, ptr %l60, !tbaa !29
  store ptr %t88, ptr %l9, !tbaa !29
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"compiler/check:Checker", ptr %t89, i32 0, i32 37
  %t93 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t91)
  store i64 %t93, ptr %l63
  br label %bb22
bb22:
  %t94 = load i64, ptr %l63, !tbaa !24
  store i64 %t94, ptr %l10, !tbaa !24
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t96 = load %"compiler/source:Span", ptr %l1
  %t100 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t95, i32 3, %"compiler/source:Span" %t96)
  store { i64, i64, i64 } %t100, ptr %l67
  br label %bb23
bb23:
  %t101 = load { i64, i64, i64 }, ptr %l67
  store { i64, i64, i64 } %t101, ptr %l11
  %t102 = getelementptr { i64, i64, i64 }, ptr %l11, i32 0, i32 0
  %t103 = load i64, ptr %t102, !tbaa !24
  store i64 %t103, ptr %l12, !tbaa !24
  %t105 = getelementptr { i64, i64, i64 }, ptr %l11, i32 0, i32 1
  %t106 = load i64, ptr %t105, !tbaa !24
  store i64 %t106, ptr %l13, !tbaa !24
  %t108 = getelementptr { i64, i64, i64 }, ptr %l11, i32 0, i32 2
  %t109 = load i64, ptr %t108, !tbaa !24
  store i64 %t109, ptr %l14, !tbaa !24
  %t111 = load ptr, ptr %l0, !tbaa !29
  store ptr %t111, ptr %l71, !tbaa !29
  %t112 = load ptr, ptr %l0, !tbaa !29
  store ptr %t112, ptr %l72, !tbaa !29
  %t113 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t113, ptr %l73
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t118 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econd1(ptr %v0, ptr %v2, ptr %t114, ptr %a3)
  store ptr %t118, ptr %l76
  br label %bb24
bb24:
  %t119 = load i64, ptr %l6, !tbaa !24
  %t120 = load ptr, ptr %l72, !tbaa !29
  %t121 = load %"compiler/source:Span", ptr %l73
  %t122 = load ptr, ptr %l76, !tbaa !29
  %t124 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebreakUnless(ptr %v0, ptr %t120, %"compiler/source:Span" %t121, ptr %t122, i64 %t119)
  store ptr %t124, ptr %l78
  br label %bb25
bb25:
  %t125 = load ptr, ptr %l71, !tbaa !29
  %t126 = load ptr, ptr %l78, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t125, ptr %t126)
  br label %bb26
bb26:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t128 = load i64, ptr %l12, !tbaa !24
  %t129 = load i64, ptr %l13, !tbaa !24
  %t130 = load i64, ptr %l14, !tbaa !24
  %t131 = load i64, ptr %l10, !tbaa !24
  %t137 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %t127, i64 %t128, i64 %t129, i64 %t130, i64 %t131)
  store ptr %t137, ptr %l84
  br label %bb27
bb27:
  %t138 = load ptr, ptr %l84, !tbaa !29
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t140 = load %"compiler/source:Span", ptr %l1
  %t141 = load ptr, ptr %l9, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t144
  %t145 = getelementptr { i64, [3 x i64] }, ptr %t144, i32 0, i32 0
  store i64 4, ptr %t145
  %t147 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t140, 0
  %t149 = insertvalue { %"compiler/source:Span", ptr, ptr } %t147, ptr %t141, 1
  %t151 = insertvalue { %"compiler/source:Span", ptr, ptr } %t149, ptr %t138, 2
  %t152 = getelementptr { i64, [3 x i64] }, ptr %t144, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t151, ptr %t152
  %t153 = load { i64, [3 x i64] }, ptr %t144
  %t155 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t153, ptr %t155
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t139, ptr %t155)
  br label %bb28
bb28:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropTaken(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2, ptr %a3) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i64
  %l4 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l12 = alloca i32
  %l13 = alloca ptr
  %l14 = alloca i64
  %l16 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l19 = alloca i64
  %l23 = alloca i64
  %l26 = alloca i64
  %l46 = alloca i32
  %l50 = alloca i32
  %l61 = alloca i64
  %l63 = alloca i64
  %l68 = alloca i32
  %s0 = alloca %olang.scope
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l16
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l16
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l4
  %t3 = load i64, ptr %l2, !tbaa !24
  store i64 %t3, ptr %l5, !tbaa !24
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v1, ptr %t5)
  store i64 %t7, ptr %l19
  br label %bb2
bb2:
  %t8 = load i64, ptr %l19, !tbaa !24
  store i64 %t8, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t9 = load i64, ptr %l6, !tbaa !24
  %t10 = load i64, ptr %l5, !tbaa !24
  %t13 = icmp sgt i64 %t9, %t10
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t15 = load i64, ptr %l7, !tbaa !24
  %t17 = icmp sgt i64 %t15, 0
  br i1 %t17, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb8
bb5:
  %t19 = load i64, ptr %l6, !tbaa !24
  %t20 = load i64, ptr %l5, !tbaa !24
  %t23 = sub i64 %t19, %t20
  %t24 = load i64, ptr %l7, !tbaa !24
  %t27 = add i64 %t23, %t24
  %t29 = sub i64 %t27, 1
  %t30 = load i64, ptr %l7, !tbaa !24
  %t33 = sdiv i64 %t29, %t30
  store i64 %t33, ptr %l26, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l26, !tbaa !24
  br label %bb7
bb7:
  %t35 = load i64, ptr %l26, !tbaa !24
  store i64 %t35, ptr %l23, !tbaa !24
  br label %bb8
bb8:
  %t36 = load i64, ptr %l23, !tbaa !24
  store i64 %t36, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb9
bb9:
  %t37 = load i64, ptr %l9, !tbaa !24
  %t38 = load i64, ptr %l8, !tbaa !24
  %t41 = icmp slt i64 %t37, %t38
  %t43 = xor i1 %t41, true
  br i1 %t43, label %bb10, label %bb11
bb10:
  br label %bb20
bb11:
  br label %bb12
bb12:
  %t45 = load i64, ptr %l5, !tbaa !24
  %t46 = load i64, ptr %l9, !tbaa !24
  %t47 = load i64, ptr %l7, !tbaa !24
  %t50 = mul i64 %t46, %t47
  %t53 = add i64 %t45, %t50
  %t55 = load ptr, ptr %l1, !tbaa !29
  %t59 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v1, ptr %t55, i64 %t53)
  store i32 %t59, ptr %l46
  br label %bb13
bb13:
  %t60 = load i32, ptr %l46, !tbaa !23
  %t67 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleft(ptr %v0, ptr %v2, ptr %a0, i32 %t60, ptr %a3)
  store i32 %t67, ptr %l50
  br label %bb14
bb14:
  %t68 = load i32, ptr %l50, !tbaa !23
  store i32 %t68, ptr %l12, !tbaa !23
  %t69 = load i32, ptr %l12, !tbaa !23
  %t70 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t73 = icmp ne i32 %t69, %t70
  br i1 %t73, label %bb15, label %bb16
bb15:
  %t75 = load i32, ptr %l12, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l4, i32 %t75)
  br label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb18
bb18:
  br label %bb19
bb19:
  %t78 = load i64, ptr %l9, !tbaa !24
  %t80 = add i64 %t78, 1
  store i64 %t80, ptr %l9, !tbaa !24
  br label %bb9
bb20:
  %t82 = load ptr, ptr %l1, !tbaa !29
  %t83 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eTruncate_3ccompiler_2ftypes_3aTypeId_3e(ptr %v1, ptr %t82, i64 %t83)
  br label %bb21
bb21:
  store ptr %l4, ptr %l13, !tbaa !29
  store i64 0, ptr %l14, !tbaa !24
  br label %bb22
bb22:
  %t87 = load i64, ptr %l14, !tbaa !24
  store i64 %t87, ptr %l61, !tbaa !24
  %t88 = load ptr, ptr %l13, !tbaa !29
  %t90 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t88)
  store i64 %t90, ptr %l63
  br label %bb23
bb23:
  %t91 = load i64, ptr %l61, !tbaa !24
  %t92 = load i64, ptr %l63, !tbaa !24
  %t93 = icmp slt i64 %t91, %t92
  %t95 = xor i1 %t93, true
  br i1 %t95, label %bb24, label %bb25
bb24:
  br label %bb30
bb25:
  br label %bb26
bb26:
  %t97 = load ptr, ptr %l13, !tbaa !29
  %t98 = load i64, ptr %l14, !tbaa !24
  %t101 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t97, i64 %t98)
  store i32 %t101, ptr %l68
  br label %bb27
bb27:
  %t102 = load i32, ptr %l68, !tbaa !23
  %t103 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v1, ptr %t103, i32 %t102)
  br label %bb28
bb28:
  br label %bb29
bb29:
  %t107 = load i64, ptr %l14, !tbaa !24
  %t109 = add i64 %t107, 1
  store i64 %t109, ptr %l14, !tbaa !24
  br label %bb22
bb30:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eelementLocals(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca ptr
  %l6 = alloca i64
  %l10 = alloca i1
  %l13 = alloca ptr
  %l15 = alloca i32
  %l16 = alloca %"compiler/source:Span"
  %l18 = alloca i32
  %l21 = alloca i64
  %l22 = alloca ptr
  %l23 = alloca %"compiler/source:Span"
  %l26 = alloca i32
  %l30 = alloca ptr
  %l33 = alloca ptr
  %l35 = alloca i32
  %l36 = alloca %"compiler/source:Span"
  %l39 = alloca i32
  %l42 = alloca i64
  %t22 = alloca { i64, [2 x i64] }, align 8
  %t46 = alloca { i64, [3 x i64] }, align 8
  %t70 = alloca { i64, [2 x i64] }, align 8
  %t94 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i64 %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/ast:ForIn", ptr %t1, i32 0, i32 0
  %t4 = load i32, ptr %t3, !tbaa !23
  %t6 = icmp ne i32 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load i64, ptr %l3, !tbaa !24
  %t10 = icmp sge i64 %t8, 0
  store i1 %t10, ptr %l10, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb3
bb3:
  %t12 = load i1, ptr %l10, !tbaa !21
  br i1 %t12, label %bb4, label %bb5
bb4:
  %t13 = load ptr, ptr %l0, !tbaa !29
  store ptr %t13, ptr %l13, !tbaa !29
  %t14 = load ptr, ptr %l2, !tbaa !29
  %t16 = getelementptr %"compiler/ast:ForIn", ptr %t14, i32 0, i32 0
  %t17 = load i32, ptr %t16, !tbaa !23
  store i32 %t17, ptr %l15, !tbaa !23
  %t18 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t18, ptr %l16
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t19)
  store i32 %t21, ptr %l18
  br label %bb6
bb5:
  br label %bb10
bb6:
  store { i64, [2 x i64] } zeroinitializer, ptr %t22
  %t23 = getelementptr { i64, [2 x i64] }, ptr %t22, i32 0, i32 0
  store i64 0, ptr %t23
  %t24 = load { i64, [2 x i64] }, ptr %t22
  %t25 = load ptr, ptr %l13, !tbaa !29
  %t26 = load i32, ptr %l15, !tbaa !23
  %t27 = load %"compiler/source:Span", ptr %l16
  %t28 = load i32, ptr %l18, !tbaa !23
  %t31 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %t25, i32 %t26, %"compiler/source:Span" %t27, i32 %t28, i32 1, { i64, [2 x i64] } %t24)
  store i64 %t31, ptr %l21
  br label %bb7
bb7:
  %t32 = load i64, ptr %l21, !tbaa !24
  %t33 = load ptr, ptr %l0, !tbaa !29
  store ptr %t33, ptr %l22, !tbaa !29
  %t34 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t34, ptr %l23
  %t37 = trunc i64 %t32 to i32
  store i32 %t37, ptr %l26, !tbaa !23
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load %"compiler/source:Span", ptr %l1
  %t41 = load i64, ptr %l3, !tbaa !24
  %t45 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t39, %"compiler/source:Span" %t40, i64 %t41)
  store ptr %t45, ptr %l30
  br label %bb8
bb8:
  store { i64, [3 x i64] } zeroinitializer, ptr %t46
  %t47 = getelementptr { i64, [3 x i64] }, ptr %t46, i32 0, i32 0
  store i64 0, ptr %t47
  %t48 = load %"compiler/source:Span", ptr %l23
  %t49 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t48, 0
  %t50 = load i32, ptr %l26, !tbaa !23
  %t51 = insertvalue { %"compiler/source:Span", i32, ptr } %t49, i32 %t50, 1
  %t52 = load ptr, ptr %l30, !tbaa !29
  %t53 = insertvalue { %"compiler/source:Span", i32, ptr } %t51, ptr %t52, 2
  %t54 = getelementptr { i64, [3 x i64] }, ptr %t46, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t53, ptr %t54
  %t55 = load { i64, [3 x i64] }, ptr %t46
  %t57 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t55, ptr %t57
  %t58 = load ptr, ptr %l22, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t58, ptr %t57)
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t60 = load ptr, ptr %l0, !tbaa !29
  store ptr %t60, ptr %l33, !tbaa !29
  %t61 = load ptr, ptr %l2, !tbaa !29
  %t63 = getelementptr %"compiler/ast:ForIn", ptr %t61, i32 0, i32 1
  %t64 = load i32, ptr %t63, !tbaa !23
  store i32 %t64, ptr %l35, !tbaa !23
  %t65 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t65, ptr %l36
  %t66 = load ptr, ptr %l4, !tbaa !29
  %t69 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t66)
  store i32 %t69, ptr %l39
  br label %bb11
bb11:
  store { i64, [2 x i64] } zeroinitializer, ptr %t70
  %t71 = getelementptr { i64, [2 x i64] }, ptr %t70, i32 0, i32 0
  store i64 5, ptr %t71
  %t72 = load { i64, [2 x i64] }, ptr %t70
  %t73 = load ptr, ptr %l33, !tbaa !29
  %t74 = load i32, ptr %l35, !tbaa !23
  %t75 = load %"compiler/source:Span", ptr %l36
  %t76 = load i32, ptr %l39, !tbaa !23
  %t79 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %t73, i32 %t74, %"compiler/source:Span" %t75, i32 %t76, i32 1, { i64, [2 x i64] } %t72)
  store i64 %t79, ptr %l42
  br label %bb12
bb12:
  %t80 = load i64, ptr %l42, !tbaa !24
  store i64 %t80, ptr %l6, !tbaa !24
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t82 = load i64, ptr %l6, !tbaa !24
  %t83 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroLet(ptr %v0, ptr %v0, ptr %t81, i64 %t82, ptr %t83)
  br label %bb13
bb13:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t88 = load %"compiler/source:Span", ptr %l1
  %t89 = load i64, ptr %l6, !tbaa !24
  %t91 = trunc i64 %t89 to i32
  %t93 = load ptr, ptr %l4, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t94
  %t95 = getelementptr { i64, [3 x i64] }, ptr %t94, i32 0, i32 0
  store i64 0, ptr %t95
  %t97 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t88, 0
  %t99 = insertvalue { %"compiler/source:Span", i32, ptr } %t97, i32 %t91, 1
  %t101 = insertvalue { %"compiler/source:Span", i32, ptr } %t99, ptr %t93, 2
  %t102 = getelementptr { i64, [3 x i64] }, ptr %t94, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t101, ptr %t102
  %t103 = load { i64, [3 x i64] }, ptr %t94
  %t105 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t103, ptr %t105
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t87, ptr %t105)
  br label %bb14
bb14:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemptyArray(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i1
  %l4 = alloca { i64, ptr }
  %l8 = alloca i32
  %l9 = alloca i32
  %l11 = alloca i32
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca { i64, ptr }
  %l20 = alloca ptr
  %l23 = alloca ptr
  %l26 = alloca i32
  %l27 = alloca i32
  %l28 = alloca { i64, ptr }
  %l32 = alloca i1
  %l33 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l42 = alloca { i64, ptr }
  %l43 = alloca i64
  %l44 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t1, i32 %a1)
  store i32 %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load i32, ptr %l8, !tbaa !23
  store i32 %t6, ptr %l2, !tbaa !23
  %t7 = load i32, ptr %l2, !tbaa !23
  store i32 %t7, ptr %l9, !tbaa !23
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %t8)
  store i32 %t10, ptr %l11
  br label %bb2
bb2:
  %t11 = load i32, ptr %l9, !tbaa !23
  %t12 = load i32, ptr %l11, !tbaa !23
  %t13 = icmp eq i32 %t11, %t12
  br i1 %t13, label %bb3, label %bb4
bb3:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d17, i32 0, i32 1) }, ptr %l13, !tbaa !27
  %t15 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t15, ptr %l14, !tbaa !27
  %t16 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t16, 0
  store i64 %t17, ptr %l15, !tbaa !24
  %t18 = load i64, ptr %l15, !tbaa !24
  %t19 = mul i64 %t18, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  %t21 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  store { i64, ptr } %t22, ptr %l16, !tbaa !27
  %t23 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = load i64, ptr %l15, !tbaa !24
  %t28 = mul i64 %t27, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t24, ptr %t26, i64 %t28, i1 false)
  %t29 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t29, ptr %l14, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t30 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t30, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/check:Checker", ptr %t31, i32 0, i32 5
  %t34 = load i1, ptr %t33, !tbaa !21
  store i1 %t34, ptr %l3, !tbaa !21
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/check:Checker", ptr %t36, i32 0, i32 5
  store i1 true, ptr %t38, !tbaa !21
  %t39 = load ptr, ptr %l0, !tbaa !29
  store ptr %t39, ptr %l20, !tbaa !29
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/check:Checker", ptr %t40, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !29
  %t45 = getelementptr %"compiler/generic:Program", ptr %t43, i32 0, i32 2
  store ptr %t45, ptr %l23, !tbaa !29
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load i32, ptr %l2, !tbaa !23
  %t50 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t46, i32 %t47)
  store i32 %t50, ptr %l26
  br label %bb6
bb6:
  %t51 = load ptr, ptr %l23, !tbaa !29
  %t52 = load i32, ptr %l26, !tbaa !23
  %t53 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t51, i32 %t52)
  store i32 %t53, ptr %l27
  br label %bb7
bb7:
  %t54 = load ptr, ptr %l20, !tbaa !29
  %t55 = load i32, ptr %l27, !tbaa !23
  %t56 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t54, i32 %t55)
  store { i64, ptr } %t56, ptr %l28
  br label %bb8
bb8:
  %t57 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d18, i32 0, i32 1) }, 1
  %t58 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d18, i32 0, i32 1) }, 0
  %t59 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t60 = extractvalue { i64, ptr } %t59, 1
  %t61 = extractvalue { i64, ptr } %t59, 0
  %t62 = add i64 %t58, %t61
  %t63 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d19, i32 0, i32 1) }, 1
  %t64 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d19, i32 0, i32 1) }, 0
  %t65 = add i64 %t62, %t64
  %t66 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t65)
  call void @olang_textcopy(ptr %t66, ptr %t57, i64 %t58)
  %t67 = getelementptr i8, ptr %t66, i64 %t58
  call void @olang_textcopy(ptr %t67, ptr %t60, i64 %t61)
  %t68 = getelementptr i8, ptr %t67, i64 %t61
  call void @olang_textcopy(ptr %t68, ptr %t63, i64 %t64)
  %t69 = insertvalue { i64, ptr } undef, i64 %t65, 0
  %t70 = insertvalue { i64, ptr } %t69, ptr %t66, 1
  store { i64, ptr } %t70, ptr %l4, !tbaa !27
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t73 = load i32, ptr %l2, !tbaa !23
  %t76 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t72, i32 %t73)
  store i1 %t76, ptr %l32
  br label %bb9
bb9:
  %t77 = load i1, ptr %l32, !tbaa !21
  br i1 %t77, label %bb10, label %bb11
bb10:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t79 = load i32, ptr %l2, !tbaa !23
  %t82 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t78, i32 %t79)
  store { i64, ptr } %t82, ptr %l36
  br label %bb12
bb11:
  %t83 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t83, ptr %l33, !tbaa !27
  br label %bb13
bb12:
  %t85 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t86 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t87 = extractvalue { i64, ptr } %t86, 1
  %t88 = extractvalue { i64, ptr } %t86, 0
  %t89 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d20, i32 0, i32 1) }, 1
  %t90 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d20, i32 0, i32 1) }, 0
  %t91 = add i64 %t88, %t90
  %t93 = extractvalue { i64, ptr } %t85, 1
  %t94 = extractvalue { i64, ptr } %t85, 0
  %t95 = add i64 %t91, %t94
  %t96 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d21, i32 0, i32 1) }, 1
  %t97 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d21, i32 0, i32 1) }, 0
  %t98 = add i64 %t95, %t97
  %t99 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t98)
  call void @olang_textcopy(ptr %t99, ptr %t87, i64 %t88)
  %t100 = getelementptr i8, ptr %t99, i64 %t88
  call void @olang_textcopy(ptr %t100, ptr %t89, i64 %t90)
  %t101 = getelementptr i8, ptr %t100, i64 %t90
  call void @olang_textcopy(ptr %t101, ptr %t93, i64 %t94)
  %t102 = getelementptr i8, ptr %t101, i64 %t94
  call void @olang_textcopy(ptr %t102, ptr %t96, i64 %t97)
  %t103 = insertvalue { i64, ptr } undef, i64 %t98, 0
  %t104 = insertvalue { i64, ptr } %t103, ptr %t99, 1
  store { i64, ptr } %t104, ptr %l33, !tbaa !27
  br label %bb13
bb13:
  %t106 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t108 = load i1, ptr %l3, !tbaa !21
  %t111 = getelementptr %"compiler/check:Checker", ptr %t107, i32 0, i32 5
  store i1 %t108, ptr %t111, !tbaa !21
  store { i64, ptr } %t106, ptr %l42, !tbaa !27
  %t113 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t113, 0
  store i64 %t114, ptr %l43, !tbaa !24
  %t115 = load i64, ptr %l43, !tbaa !24
  %t116 = mul i64 %t115, 1
  %t117 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t116)
  %t118 = insertvalue { i64, ptr } undef, i64 %t115, 0
  %t119 = insertvalue { i64, ptr } %t118, ptr %t117, 1
  store { i64, ptr } %t119, ptr %l44, !tbaa !27
  %t120 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t121 = load ptr, ptr %t120, !tbaa !27
  %t122 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t123 = load ptr, ptr %t122, !tbaa !27
  %t124 = load i64, ptr %l43, !tbaa !24
  %t125 = mul i64 %t124, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t121, ptr %t123, i64 %t125, i1 false)
  %t126 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t126, ptr %l42, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t127 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t127, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eenumsEqual(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  %l18 = alloca ptr
  %lp19 = alloca ptr
  %lp20 = alloca ptr
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l31 = alloca i64
  %l32 = alloca ptr
  %l33 = alloca %"compiler/source:Span"
  %l38 = alloca ptr
  %l39 = alloca ptr
  %l40 = alloca ptr
  %l41 = alloca %"compiler/source:Span"
  %l46 = alloca ptr
  %l47 = alloca ptr
  %l50 = alloca ptr
  %l55 = alloca i32
  %l56 = alloca { i64, ptr }
  %l60 = alloca ptr
  %l66 = alloca i64
  %l69 = alloca i64
  %l94 = alloca ptr
  %l97 = alloca ptr
  %l102 = alloca i32
  %l103 = alloca i32
  %l104 = alloca { i64, ptr }
  %l105 = alloca ptr
  %l106 = alloca %"compiler/source:Span"
  %l107 = alloca i32
  %l108 = alloca i32
  %l112 = alloca ptr
  %l113 = alloca ptr
  %l114 = alloca %"compiler/source:Span"
  %l116 = alloca i32
  %l118 = alloca ptr
  %l120 = alloca ptr
  %l121 = alloca %"compiler/source:Span"
  %l122 = alloca { i64, ptr }
  %l124 = alloca i32
  %l128 = alloca %"compiler/typed:Payload"
  %l131 = alloca %"compiler/source:Span"
  %l132 = alloca { i64, ptr }
  %l134 = alloca i32
  %l138 = alloca %"compiler/typed:Payload"
  %l146 = alloca i64
  %l149 = alloca i64
  %l167 = alloca ptr
  %l168 = alloca %"compiler/source:Span"
  %l169 = alloca i32
  %l173 = alloca { i64, ptr }
  %l180 = alloca ptr
  %l184 = alloca { i64, ptr }
  %l191 = alloca ptr
  %l192 = alloca ptr
  %l197 = alloca ptr
  %l200 = alloca ptr
  %l201 = alloca %"compiler/source:Span"
  %l202 = alloca i32
  %l203 = alloca i32
  %l207 = alloca ptr
  %l208 = alloca ptr
  %l209 = alloca %"compiler/source:Span"
  %l211 = alloca i32
  %l213 = alloca ptr
  %l215 = alloca ptr
  %l216 = alloca %"compiler/source:Span"
  %l217 = alloca i32
  %l222 = alloca %"compiler/typed:Cond"
  %l230 = alloca i64
  %l233 = alloca %"compiler/source:Span"
  %l234 = alloca i32
  %l238 = alloca { i64, ptr }
  %l241 = alloca %"compiler/typed:Seq"
  %rv = alloca ptr
  %t202 = alloca { i64, [4 x i64] }, align 8
  %t231 = alloca { i64, [4 x i64] }, align 8
  %t308 = alloca { i64, [4 x i64] }, align 8
  %t338 = alloca { i64, [4 x i64] }, align 8
  %t419 = alloca { i64, [5 x i64] }, align 8
  %t462 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 37
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l31
  br label %bb1
bb1:
  %t6 = load i64, ptr %l31, !tbaa !24
  store i64 %t6, ptr %l5, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  store ptr %t7, ptr %l32, !tbaa !29
  %t8 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t8, ptr %l33
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = load i32, ptr %l4, !tbaa !23
  %t12 = load %"compiler/source:Span", ptr %l1
  %t17 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %t9, ptr %a2, i32 %t11, %"compiler/source:Span" %t12)
  store ptr %t17, ptr %l38
  br label %bb2
bb2:
  %t18 = load ptr, ptr %l32, !tbaa !29
  %t19 = load %"compiler/source:Span", ptr %l33
  %t20 = load ptr, ptr %l38, !tbaa !29
  %t21 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eheldOf(ptr %v0, ptr %t18, %"compiler/source:Span" %t19, ptr %t20)
  store ptr %t21, ptr %l39
  br label %bb3
bb3:
  %t22 = load ptr, ptr %l39, !tbaa !29
  store ptr %t22, ptr %l6, !tbaa !29
  %t23 = load ptr, ptr %l0, !tbaa !29
  store ptr %t23, ptr %l40, !tbaa !29
  %t24 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t24, ptr %l41
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = load i32, ptr %l4, !tbaa !23
  %t28 = load %"compiler/source:Span", ptr %l1
  %t33 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %t25, ptr %a3, i32 %t27, %"compiler/source:Span" %t28)
  store ptr %t33, ptr %l46
  br label %bb4
bb4:
  %t34 = load ptr, ptr %l40, !tbaa !29
  %t35 = load %"compiler/source:Span", ptr %l41
  %t36 = load ptr, ptr %l46, !tbaa !29
  %t37 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eheldOf(ptr %v0, ptr %t34, %"compiler/source:Span" %t35, ptr %t36)
  store ptr %t37, ptr %l47
  br label %bb5
bb5:
  %t38 = load ptr, ptr %l47, !tbaa !29
  store ptr %t38, ptr %l7, !tbaa !29
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/check:Checker", ptr %t39, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !29
  %t44 = getelementptr %"compiler/generic:Program", ptr %t42, i32 0, i32 2
  store ptr %t44, ptr %l50, !tbaa !29
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/check:Checker", ptr %t45, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !29
  %t50 = getelementptr %"compiler/generic:Program", ptr %t48, i32 0, i32 2
  %t51 = load i32, ptr %l4, !tbaa !23
  %t54 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t50, i32 %t51)
  store i32 %t54, ptr %l55
  br label %bb6
bb6:
  %t55 = load ptr, ptr %l50, !tbaa !29
  %t56 = load i32, ptr %l55, !tbaa !23
  %t57 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t55, i32 %t56)
  store { i64, ptr } %t57, ptr %l56
  br label %bb7
bb7:
  %t58 = load { i64, ptr }, ptr %l56, !tbaa !27
  store { i64, ptr } %t58, ptr %l8, !tbaa !27
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = load %"compiler/source:Span", ptr %l1
  %t61 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t65 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t59, %"compiler/source:Span" %t60, i32 %t61, i64 0)
  store ptr %t65, ptr %l60
  br label %bb8
bb8:
  %t66 = load ptr, ptr %l60, !tbaa !29
  store ptr %t66, ptr %l9, !tbaa !29
  store i64 0, ptr %l10, !tbaa !24
  %t67 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t67, 0
  store i64 %t69, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t71 = load i64, ptr %l11, !tbaa !24
  %t72 = load i64, ptr %l10, !tbaa !24
  %t75 = icmp sgt i64 %t71, %t72
  br i1 %t75, label %bb9, label %bb10
bb9:
  %t77 = load i64, ptr %l12, !tbaa !24
  %t79 = icmp sgt i64 %t77, 0
  br i1 %t79, label %bb11, label %bb12
bb10:
  store i64 0, ptr %l66, !tbaa !24
  br label %bb14
bb11:
  %t81 = load i64, ptr %l11, !tbaa !24
  %t82 = load i64, ptr %l10, !tbaa !24
  %t85 = sub i64 %t81, %t82
  %t86 = load i64, ptr %l12, !tbaa !24
  %t89 = add i64 %t85, %t86
  %t91 = sub i64 %t89, 1
  %t92 = load i64, ptr %l12, !tbaa !24
  %t95 = sdiv i64 %t91, %t92
  store i64 %t95, ptr %l69, !tbaa !24
  br label %bb13
bb12:
  store i64 0, ptr %l69, !tbaa !24
  br label %bb13
bb13:
  %t97 = load i64, ptr %l69, !tbaa !24
  store i64 %t97, ptr %l66, !tbaa !24
  br label %bb14
bb14:
  %t98 = load i64, ptr %l66, !tbaa !24
  store i64 %t98, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb15
bb15:
  %t99 = load i64, ptr %l14, !tbaa !24
  %t100 = load i64, ptr %l13, !tbaa !24
  %t103 = icmp slt i64 %t99, %t100
  %t105 = xor i1 %t103, true
  br i1 %t105, label %bb16, label %bb17
bb16:
  br label %bb50
bb17:
  br label %bb18
bb18:
  %t107 = load i64, ptr %l10, !tbaa !24
  %t108 = load i64, ptr %l14, !tbaa !24
  %t109 = load i64, ptr %l12, !tbaa !24
  %t112 = mul i64 %t108, %t109
  %t115 = add i64 %t107, %t112
  %t117 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t119 = extractvalue { i64, ptr } %t117, 0
  %t121 = sub i64 %t119, 1
  %t125 = sub i64 %t121, %t115
  store i64 %t125, ptr %l16, !tbaa !24
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t129 = getelementptr %"compiler/check:Checker", ptr %t127, i32 0, i32 1
  %t130 = load ptr, ptr %t129, !tbaa !29
  %t132 = getelementptr %"compiler/generic:Program", ptr %t130, i32 0, i32 2
  store ptr %t132, ptr %l94, !tbaa !29
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t135 = getelementptr %"compiler/check:Checker", ptr %t133, i32 0, i32 1
  %t136 = load ptr, ptr %t135, !tbaa !29
  %t138 = getelementptr %"compiler/generic:Program", ptr %t136, i32 0, i32 2
  store ptr %t138, ptr %l97, !tbaa !29
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t141 = getelementptr %"compiler/check:Checker", ptr %t139, i32 0, i32 1
  %t142 = load ptr, ptr %t141, !tbaa !29
  %t143 = load i32, ptr %l4, !tbaa !23
  %t144 = load i64, ptr %l16, !tbaa !24
  %t148 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCaseSig(ptr %v0, ptr %t142, i32 %t143, i64 %t144)
  store i32 %t148, ptr %l102
  br label %bb19
bb19:
  %t149 = load ptr, ptr %l97, !tbaa !29
  %t150 = load i32, ptr %l102, !tbaa !23
  %t151 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t149, i32 %t150)
  store i32 %t151, ptr %l103
  br label %bb20
bb20:
  %t152 = load ptr, ptr %l94, !tbaa !29
  %t153 = load i32, ptr %l103, !tbaa !23
  %t154 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t152, i32 %t153)
  store { i64, ptr } %t154, ptr %l104
  br label %bb21
bb21:
  %t155 = load { i64, ptr }, ptr %l104, !tbaa !27
  store { i64, ptr } %t155, ptr %l17, !tbaa !27
  %t156 = load ptr, ptr %l0, !tbaa !29
  store ptr %t156, ptr %l105, !tbaa !29
  %t157 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t157, ptr %l106
  %t158 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t158, ptr %l107, !tbaa !23
  store i32 23, ptr %l108
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t160 = load %"compiler/source:Span", ptr %l1
  %t161 = load ptr, ptr %l7, !tbaa !29
  %t165 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t159, %"compiler/source:Span" %t160, ptr %t161)
  store ptr %t165, ptr %l112
  br label %bb22
bb22:
  %t166 = load ptr, ptr %l0, !tbaa !29
  store ptr %t166, ptr %l113, !tbaa !29
  %t167 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t167, ptr %l114
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t170 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t168)
  store i32 %t170, ptr %l116
  br label %bb23
bb23:
  %t171 = load i64, ptr %l16, !tbaa !24
  %t172 = load ptr, ptr %l113, !tbaa !29
  %t173 = load %"compiler/source:Span", ptr %l114
  %t174 = load i32, ptr %l116, !tbaa !23
  %t176 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t172, %"compiler/source:Span" %t173, i32 %t174, i64 %t171)
  store ptr %t176, ptr %l118
  br label %bb24
bb24:
  %t177 = load ptr, ptr %l118, !tbaa !29
  %t178 = load ptr, ptr %l105, !tbaa !29
  %t179 = load %"compiler/source:Span", ptr %l106
  %t180 = load i32, ptr %l107, !tbaa !23
  %t181 = load i32, ptr %l108
  %t182 = load ptr, ptr %l112, !tbaa !29
  %t184 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %t178, %"compiler/source:Span" %t179, i32 %t180, i32 %t181, ptr %t182, ptr %t177)
  store ptr %t184, ptr %l120
  br label %bb25
bb25:
  %t185 = load ptr, ptr %l120, !tbaa !29
  store ptr %t185, ptr %l18, !tbaa !29
  %t186 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t186, ptr %l121
  %t187 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t187, ptr %l122, !tbaa !27
  %t188 = load i64, ptr %l16, !tbaa !24
  %t190 = getelementptr { i64, ptr }, ptr %l122, i32 0, i32 1
  %t191 = load ptr, ptr %t190, !tbaa !27
  %t192 = getelementptr i32, ptr %t191, i64 %t188
  %t193 = load i32, ptr %t192, !tbaa !33
  store i32 %t193, ptr %l124, !tbaa !23
  %t194 = load ptr, ptr %l6, !tbaa !29
  %t195 = load i64, ptr %l16, !tbaa !24
  %t199 = call %"compiler/typed:Payload" @compiler_2ftyped_3aPayload_2ector(ptr %v0, ptr %v0, ptr %t194, i64 %t195, i32 0)
  store %"compiler/typed:Payload" %t199, ptr %l128
  br label %bb26
bb26:
  %t200 = load %"compiler/typed:Payload", ptr %l128
  %t201 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Payload" %t200, ptr %t201
  store { i64, [4 x i64] } zeroinitializer, ptr %t202
  %t203 = getelementptr { i64, [4 x i64] }, ptr %t202, i32 0, i32 0
  store i64 5, ptr %t203
  %t204 = load %"compiler/source:Span", ptr %l121
  %t205 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t204, 0
  %t206 = load i32, ptr %l124, !tbaa !23
  %t207 = insertvalue { %"compiler/source:Span", i32, ptr } %t205, i32 %t206, 1
  %t209 = insertvalue { %"compiler/source:Span", i32, ptr } %t207, ptr %t201, 2
  %t210 = getelementptr { i64, [4 x i64] }, ptr %t202, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t209, ptr %t210
  %t211 = load { i64, [4 x i64] }, ptr %t202
  %t212 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store ptr %t212, ptr %lp19
  %t214 = load ptr, ptr %lp19
  store { i64, [4 x i64] } %t211, ptr %t214
  %t215 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t215, ptr %l131
  %t216 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t216, ptr %l132, !tbaa !27
  %t217 = load i64, ptr %l16, !tbaa !24
  %t219 = getelementptr { i64, ptr }, ptr %l132, i32 0, i32 1
  %t220 = load ptr, ptr %t219, !tbaa !27
  %t221 = getelementptr i32, ptr %t220, i64 %t217
  %t222 = load i32, ptr %t221, !tbaa !33
  store i32 %t222, ptr %l134, !tbaa !23
  %t223 = load ptr, ptr %l7, !tbaa !29
  %t224 = load i64, ptr %l16, !tbaa !24
  %t228 = call %"compiler/typed:Payload" @compiler_2ftyped_3aPayload_2ector(ptr %v0, ptr %v0, ptr %t223, i64 %t224, i32 0)
  store %"compiler/typed:Payload" %t228, ptr %l138
  br label %bb27
bb27:
  %t229 = load %"compiler/typed:Payload", ptr %l138
  %t230 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Payload" %t229, ptr %t230
  store { i64, [4 x i64] } zeroinitializer, ptr %t231
  %t232 = getelementptr { i64, [4 x i64] }, ptr %t231, i32 0, i32 0
  store i64 5, ptr %t232
  %t233 = load %"compiler/source:Span", ptr %l131
  %t234 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t233, 0
  %t235 = load i32, ptr %l134, !tbaa !23
  %t236 = insertvalue { %"compiler/source:Span", i32, ptr } %t234, i32 %t235, 1
  %t238 = insertvalue { %"compiler/source:Span", i32, ptr } %t236, ptr %t230, 2
  %t239 = getelementptr { i64, [4 x i64] }, ptr %t231, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t238, ptr %t239
  %t240 = load { i64, [4 x i64] }, ptr %t231
  %t241 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store ptr %t241, ptr %lp20
  %t243 = load ptr, ptr %lp20
  store { i64, [4 x i64] } %t240, ptr %t243
  store i64 0, ptr %l21, !tbaa !24
  %t244 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t246 = extractvalue { i64, ptr } %t244, 0
  store i64 %t246, ptr %l22, !tbaa !24
  store i64 1, ptr %l23, !tbaa !24
  %t248 = load i64, ptr %l22, !tbaa !24
  %t249 = load i64, ptr %l21, !tbaa !24
  %t252 = icmp sgt i64 %t248, %t249
  br i1 %t252, label %bb28, label %bb29
bb28:
  %t254 = load i64, ptr %l23, !tbaa !24
  %t256 = icmp sgt i64 %t254, 0
  br i1 %t256, label %bb30, label %bb31
bb29:
  store i64 0, ptr %l146, !tbaa !24
  br label %bb33
bb30:
  %t258 = load i64, ptr %l22, !tbaa !24
  %t259 = load i64, ptr %l21, !tbaa !24
  %t262 = sub i64 %t258, %t259
  %t263 = load i64, ptr %l23, !tbaa !24
  %t266 = add i64 %t262, %t263
  %t268 = sub i64 %t266, 1
  %t269 = load i64, ptr %l23, !tbaa !24
  %t272 = sdiv i64 %t268, %t269
  store i64 %t272, ptr %l149, !tbaa !24
  br label %bb32
bb31:
  store i64 0, ptr %l149, !tbaa !24
  br label %bb32
bb32:
  %t274 = load i64, ptr %l149, !tbaa !24
  store i64 %t274, ptr %l146, !tbaa !24
  br label %bb33
bb33:
  %t275 = load i64, ptr %l146, !tbaa !24
  store i64 %t275, ptr %l24, !tbaa !24
  store i64 0, ptr %l25, !tbaa !24
  br label %bb34
bb34:
  %t276 = load i64, ptr %l25, !tbaa !24
  %t277 = load i64, ptr %l24, !tbaa !24
  %t280 = icmp slt i64 %t276, %t277
  %t282 = xor i1 %t280, true
  br i1 %t282, label %bb35, label %bb36
bb35:
  br label %bb43
bb36:
  br label %bb37
bb37:
  %t284 = load i64, ptr %l21, !tbaa !24
  %t285 = load i64, ptr %l25, !tbaa !24
  %t286 = load i64, ptr %l23, !tbaa !24
  %t289 = mul i64 %t285, %t286
  %t292 = add i64 %t284, %t289
  store i64 %t292, ptr %l26, !tbaa !24
  %t294 = load ptr, ptr %l0, !tbaa !29
  store ptr %t294, ptr %l167, !tbaa !29
  %t295 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t295, ptr %l168
  store i32 76, ptr %l169
  %t296 = load ptr, ptr %l0, !tbaa !29
  %t297 = load %"compiler/source:Span", ptr %l1
  %t298 = load %"compiler/source:Span", ptr %l1
  %t299 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t299, ptr %l173, !tbaa !27
  %t300 = load i64, ptr %l26, !tbaa !24
  %t302 = getelementptr { i64, ptr }, ptr %l173, i32 0, i32 1
  %t303 = load ptr, ptr %t302, !tbaa !27
  %t304 = getelementptr i32, ptr %t303, i64 %t300
  %t305 = load i32, ptr %t304, !tbaa !33
  %t306 = load ptr, ptr %lp19
  %t307 = load i64, ptr %l26, !tbaa !24
  store { i64, [4 x i64] } zeroinitializer, ptr %t308
  %t309 = getelementptr { i64, [4 x i64] }, ptr %t308, i32 0, i32 0
  store i64 3, ptr %t309
  %t311 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } undef, %"compiler/source:Span" %t298, 0
  %t313 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t311, i32 %t305, 1
  %t315 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t313, ptr %t306, 2
  %t317 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t315, i64 %t307, 3
  %t318 = getelementptr { i64, [4 x i64] }, ptr %t308, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i64 } %t317, ptr %t318
  %t319 = load { i64, [4 x i64] }, ptr %t308
  %t321 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t319, ptr %t321
  %t325 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t296, %"compiler/source:Span" %t297, ptr %t321)
  store ptr %t325, ptr %l180
  br label %bb38
bb38:
  %t326 = load ptr, ptr %l0, !tbaa !29
  %t327 = load %"compiler/source:Span", ptr %l1
  %t328 = load %"compiler/source:Span", ptr %l1
  %t329 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t329, ptr %l184, !tbaa !27
  %t330 = load i64, ptr %l26, !tbaa !24
  %t332 = getelementptr { i64, ptr }, ptr %l184, i32 0, i32 1
  %t333 = load ptr, ptr %t332, !tbaa !27
  %t334 = getelementptr i32, ptr %t333, i64 %t330
  %t335 = load i32, ptr %t334, !tbaa !33
  %t336 = load ptr, ptr %lp20
  %t337 = load i64, ptr %l26, !tbaa !24
  store { i64, [4 x i64] } zeroinitializer, ptr %t338
  %t339 = getelementptr { i64, [4 x i64] }, ptr %t338, i32 0, i32 0
  store i64 3, ptr %t339
  %t341 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } undef, %"compiler/source:Span" %t328, 0
  %t343 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t341, i32 %t335, 1
  %t345 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t343, ptr %t336, 2
  %t347 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t345, i64 %t337, 3
  %t348 = getelementptr { i64, [4 x i64] }, ptr %t338, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i64 } %t347, ptr %t348
  %t349 = load { i64, [4 x i64] }, ptr %t338
  %t351 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t349, ptr %t351
  %t355 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t326, %"compiler/source:Span" %t327, ptr %t351)
  store ptr %t355, ptr %l191
  br label %bb39
bb39:
  %t356 = load ptr, ptr %l167, !tbaa !29
  %t357 = load %"compiler/source:Span", ptr %l168
  %t358 = load i32, ptr %l169
  %t359 = load ptr, ptr %l180, !tbaa !29
  %t360 = load ptr, ptr %l191, !tbaa !29
  %t361 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eequality(ptr %v0, ptr %t356, %"compiler/source:Span" %t357, i32 %t358, ptr %t359, ptr %t360)
  store ptr %t361, ptr %l192
  br label %bb40
bb40:
  %t362 = load ptr, ptr %l192, !tbaa !29
  %t363 = load ptr, ptr %l0, !tbaa !29
  %t364 = load %"compiler/source:Span", ptr %l1
  %t365 = load ptr, ptr %l18, !tbaa !29
  %t371 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eand2(ptr %v0, ptr %t363, %"compiler/source:Span" %t364, ptr %t365, ptr %t362)
  store ptr %t371, ptr %l197
  br label %bb41
bb41:
  %t372 = load ptr, ptr %l197, !tbaa !29
  store ptr %t372, ptr %l18, !tbaa !29
  br label %bb42
bb42:
  %t373 = load i64, ptr %l25, !tbaa !24
  %t375 = add i64 %t373, 1
  store i64 %t375, ptr %l25, !tbaa !24
  br label %bb34
bb43:
  %t377 = load ptr, ptr %l0, !tbaa !29
  store ptr %t377, ptr %l200, !tbaa !29
  %t378 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t378, ptr %l201
  %t379 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t379, ptr %l202, !tbaa !23
  store i32 23, ptr %l203
  %t380 = load ptr, ptr %l0, !tbaa !29
  %t381 = load %"compiler/source:Span", ptr %l1
  %t382 = load ptr, ptr %l6, !tbaa !29
  %t386 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t380, %"compiler/source:Span" %t381, ptr %t382)
  store ptr %t386, ptr %l207
  br label %bb44
bb44:
  %t387 = load ptr, ptr %l0, !tbaa !29
  store ptr %t387, ptr %l208, !tbaa !29
  %t388 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t388, ptr %l209
  %t389 = load ptr, ptr %l0, !tbaa !29
  %t391 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t389)
  store i32 %t391, ptr %l211
  br label %bb45
bb45:
  %t392 = load i64, ptr %l16, !tbaa !24
  %t393 = load ptr, ptr %l208, !tbaa !29
  %t394 = load %"compiler/source:Span", ptr %l209
  %t395 = load i32, ptr %l211, !tbaa !23
  %t397 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t393, %"compiler/source:Span" %t394, i32 %t395, i64 %t392)
  store ptr %t397, ptr %l213
  br label %bb46
bb46:
  %t398 = load ptr, ptr %l213, !tbaa !29
  %t399 = load ptr, ptr %l200, !tbaa !29
  %t400 = load %"compiler/source:Span", ptr %l201
  %t401 = load i32, ptr %l202, !tbaa !23
  %t402 = load i32, ptr %l203
  %t403 = load ptr, ptr %l207, !tbaa !29
  %t405 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %t399, %"compiler/source:Span" %t400, i32 %t401, i32 %t402, ptr %t403, ptr %t398)
  store ptr %t405, ptr %l215
  br label %bb47
bb47:
  %t406 = load ptr, ptr %l215, !tbaa !29
  %t407 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t407, ptr %l216
  %t408 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t408, ptr %l217, !tbaa !23
  %t410 = load ptr, ptr %l18, !tbaa !29
  %t412 = load ptr, ptr %l9, !tbaa !29
  %t416 = call %"compiler/typed:Cond" @compiler_2ftyped_3aCond_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t406, ptr %t410, ptr %t412)
  store %"compiler/typed:Cond" %t416, ptr %l222
  br label %bb48
bb48:
  %t417 = load %"compiler/typed:Cond", ptr %l222
  %t418 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Cond" %t417, ptr %t418
  store { i64, [5 x i64] } zeroinitializer, ptr %t419
  %t420 = getelementptr { i64, [5 x i64] }, ptr %t419, i32 0, i32 0
  store i64 11, ptr %t420
  %t421 = load %"compiler/source:Span", ptr %l216
  %t422 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t421, 0
  %t423 = load i32, ptr %l217, !tbaa !23
  %t424 = insertvalue { %"compiler/source:Span", i32, ptr } %t422, i32 %t423, 1
  %t426 = insertvalue { %"compiler/source:Span", i32, ptr } %t424, ptr %t418, 2
  %t427 = getelementptr { i64, [5 x i64] }, ptr %t419, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t426, ptr %t427
  %t428 = load { i64, [5 x i64] }, ptr %t419
  %t430 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t428, ptr %t430
  store ptr %t430, ptr %l9, !tbaa !29
  br label %bb49
bb49:
  %t432 = load i64, ptr %l14, !tbaa !24
  %t434 = add i64 %t432, 1
  store i64 %t434, ptr %l14, !tbaa !24
  br label %bb15
bb50:
  %t436 = load ptr, ptr %l0, !tbaa !29
  %t438 = getelementptr %"compiler/check:Checker", ptr %t436, i32 0, i32 37
  %t440 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t438)
  store i64 %t440, ptr %l230
  br label %bb51
bb51:
  %t441 = load i64, ptr %l5, !tbaa !24
  %t442 = load i64, ptr %l230, !tbaa !24
  %t444 = icmp sgt i64 %t442, %t441
  br i1 %t444, label %bb52, label %bb53
bb52:
  %t446 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t446, ptr %l233
  %t447 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t447, ptr %l234, !tbaa !23
  %t448 = load ptr, ptr %l0, !tbaa !29
  %t450 = getelementptr %"compiler/check:Checker", ptr %t448, i32 0, i32 37
  %t451 = load i64, ptr %l5, !tbaa !24
  %t454 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t450, i64 %t451)
  store { i64, ptr } %t454, ptr %l238
  br label %bb54
bb53:
  br label %bb56
bb54:
  %t455 = load ptr, ptr %l9, !tbaa !29
  %t457 = load { i64, ptr }, ptr %l238, !tbaa !27
  %t459 = call %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t457, ptr %t455)
  store %"compiler/typed:Seq" %t459, ptr %l241
  br label %bb55
bb55:
  %t460 = load %"compiler/typed:Seq", ptr %l241
  %t461 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Seq" %t460, ptr %t461
  store { i64, [5 x i64] } zeroinitializer, ptr %t462
  %t463 = getelementptr { i64, [5 x i64] }, ptr %t462, i32 0, i32 0
  store i64 12, ptr %t463
  %t464 = load %"compiler/source:Span", ptr %l233
  %t465 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t464, 0
  %t466 = load i32, ptr %l234, !tbaa !23
  %t467 = insertvalue { %"compiler/source:Span", i32, ptr } %t465, i32 %t466, 1
  %t469 = insertvalue { %"compiler/source:Span", i32, ptr } %t467, ptr %t461, 2
  %t470 = getelementptr { i64, [5 x i64] }, ptr %t462, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t469, ptr %t470
  %t471 = load { i64, [5 x i64] }, ptr %t462
  %t473 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t471, ptr %t473
  store ptr %t473, ptr %rv
  br label %ret
bb56:
  %t475 = load ptr, ptr %l9, !tbaa !29
  store ptr %t475, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrHeld(ptr %v0, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i1
  %l11 = alloca ptr
  %l12 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i1
  %l22 = alloca %"compiler/source:Span"
  %l23 = alloca ptr
  %l24 = alloca %"compiler/source:Span"
  %l27 = alloca i32
  %l28 = alloca i64
  %l41 = alloca ptr
  %rv = alloca ptr
  %t62 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb17
bb5:
  %t16 = load ptr, ptr %l2, !tbaa !29
  store ptr %t16, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t17 = load ptr, ptr %l11, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t20 = load ptr, ptr %l11, !tbaa !29
  %t21 = load i64, ptr %t20
  %t23 = icmp eq i64 %t21, 0
  store i1 %t23, ptr %l12, !tbaa !21
  br label %bb7
bb7:
  %t24 = load i1, ptr %l12, !tbaa !21
  br i1 %t24, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  %t25 = load ptr, ptr %l1, !tbaa !29
  store ptr %t25, ptr %rv
  br label %ret
bb11:
  br i1 true, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_fde34f6ad3d04e85_8bb8dc064f471149)
  unreachable
bb16:
  br label %bb28
bb17:
  %t27 = load ptr, ptr %l1, !tbaa !29
  store ptr %t27, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t28 = load ptr, ptr %l16, !tbaa !29
  %t29 = icmp ne ptr %t28, null
  br i1 %t29, label %bb18, label %bb19
bb18:
  %t31 = load ptr, ptr %l16, !tbaa !29
  %t32 = load i64, ptr %t31
  %t34 = icmp eq i64 %t32, 0
  store i1 %t34, ptr %l17, !tbaa !21
  br label %bb19
bb19:
  %t35 = load i1, ptr %l17, !tbaa !21
  br i1 %t35, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb23
bb22:
  %t36 = load ptr, ptr %l1, !tbaa !29
  store ptr %t36, ptr %rv
  br label %ret
bb23:
  br i1 true, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  call void @__olang_check_failed(ptr @olang_loc_7e2870e38111b7d4_913a9c3a02b86678)
  unreachable
bb28:
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t40 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %t38)
  store %"compiler/source:Span" %t40, ptr %l22
  br label %bb29
bb29:
  %t41 = load %"compiler/source:Span", ptr %l22
  store %"compiler/source:Span" %t41, ptr %l3
  %t42 = load ptr, ptr %l0, !tbaa !29
  store ptr %t42, ptr %l23, !tbaa !29
  %t43 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t43, ptr %l24
  %t44 = load ptr, ptr %l1, !tbaa !29
  %t47 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t44)
  store i32 %t47, ptr %l27
  br label %bb30
bb30:
  %t48 = load ptr, ptr %l23, !tbaa !29
  %t49 = load %"compiler/source:Span", ptr %l24
  %t50 = load i32, ptr %l27, !tbaa !23
  %t51 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t48, %"compiler/source:Span" %t49, i32 %t50)
  store i64 %t51, ptr %l28
  br label %bb31
bb31:
  %t52 = load i64, ptr %l28, !tbaa !24
  store i64 %t52, ptr %l4, !tbaa !24
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/check:Checker", ptr %t53, i32 0, i32 37
  %t56 = load %"compiler/source:Span", ptr %l3
  %t57 = load i64, ptr %l4, !tbaa !24
  %t59 = trunc i64 %t57 to i32
  %t61 = load ptr, ptr %l1, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t62
  %t63 = getelementptr { i64, [3 x i64] }, ptr %t62, i32 0, i32 0
  store i64 0, ptr %t63
  %t65 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t56, 0
  %t67 = insertvalue { %"compiler/source:Span", i32, ptr } %t65, i32 %t59, 1
  %t69 = insertvalue { %"compiler/source:Span", i32, ptr } %t67, ptr %t61, 2
  %t70 = getelementptr { i64, [3 x i64] }, ptr %t62, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t69, ptr %t70
  %t71 = load { i64, [3 x i64] }, ptr %t62
  %t73 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t71, ptr %t73
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t55, ptr %t73)
  br label %bb32
bb32:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t77 = load %"compiler/source:Span", ptr %l3
  %t78 = load i64, ptr %l4, !tbaa !24
  %t82 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t76, %"compiler/source:Span" %t77, i64 %t78)
  store ptr %t82, ptr %l41
  br label %bb33
bb33:
  %t83 = load ptr, ptr %l41, !tbaa !29
  store ptr %t83, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eescapes(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca i64
  %l22 = alloca ptr
  %l32 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l38 = alloca i64
  %l42 = alloca i64
  %l45 = alloca i64
  %l63 = alloca ptr
  %l67 = alloca i32
  %l77 = alloca i64
  %l80 = alloca i64
  %l99 = alloca ptr
  %l103 = alloca i32
  %l110 = alloca i64
  %l112 = alloca i64
  %l117 = alloca i32
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t1)
  store ptr %t3, ptr %l22
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l22, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t5 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp eq i64 %t5, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = load i64, ptr %l2, !tbaa !24
  %t12 = load i64, ptr %l3, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eescapeRules(ptr %v0, ptr %t9, %"compiler/source:Span" %a1, i64 %t11, i64 %t12)
  br label %bb5
bb5:
  %t17 = load ptr, ptr %l4, !tbaa !29
  %t19 = getelementptr %"compiler/check:frame", ptr %t17, i32 0, i32 15
  %t20 = load i64, ptr %t19, !tbaa !24
  %t22 = icmp eq i64 %t20, 0
  br i1 %t22, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb7:
  br label %bb8
bb8:
  %t24 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t24, ptr %l32
  br label %bb9
bb9:
  %t25 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l32
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t25, ptr %l5
  %t26 = load i64, ptr %l2, !tbaa !24
  %t27 = load i64, ptr %l3, !tbaa !24
  %t30 = add i64 %t26, %t27
  store i64 %t30, ptr %l6, !tbaa !24
  %t32 = load ptr, ptr %l4, !tbaa !29
  %t34 = getelementptr %"compiler/check:frame", ptr %t32, i32 0, i32 26
  %t36 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t34)
  store i64 %t36, ptr %l38
  br label %bb10
bb10:
  %t37 = load i64, ptr %l38, !tbaa !24
  store i64 %t37, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t38 = load i64, ptr %l7, !tbaa !24
  %t39 = load i64, ptr %l6, !tbaa !24
  %t42 = icmp sgt i64 %t38, %t39
  br i1 %t42, label %bb11, label %bb12
bb11:
  %t44 = load i64, ptr %l8, !tbaa !24
  %t46 = icmp sgt i64 %t44, 0
  br i1 %t46, label %bb13, label %bb14
bb12:
  store i64 0, ptr %l42, !tbaa !24
  br label %bb16
bb13:
  %t48 = load i64, ptr %l7, !tbaa !24
  %t49 = load i64, ptr %l6, !tbaa !24
  %t52 = sub i64 %t48, %t49
  %t53 = load i64, ptr %l8, !tbaa !24
  %t56 = add i64 %t52, %t53
  %t58 = sub i64 %t56, 1
  %t59 = load i64, ptr %l8, !tbaa !24
  %t62 = sdiv i64 %t58, %t59
  store i64 %t62, ptr %l45, !tbaa !24
  br label %bb15
bb14:
  store i64 0, ptr %l45, !tbaa !24
  br label %bb15
bb15:
  %t64 = load i64, ptr %l45, !tbaa !24
  store i64 %t64, ptr %l42, !tbaa !24
  br label %bb16
bb16:
  %t65 = load i64, ptr %l42, !tbaa !24
  store i64 %t65, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb17
bb17:
  %t66 = load i64, ptr %l10, !tbaa !24
  %t67 = load i64, ptr %l9, !tbaa !24
  %t70 = icmp slt i64 %t66, %t67
  %t72 = xor i1 %t70, true
  br i1 %t72, label %bb18, label %bb19
bb18:
  br label %bb24
bb19:
  br label %bb20
bb20:
  %t74 = load i64, ptr %l6, !tbaa !24
  %t75 = load i64, ptr %l10, !tbaa !24
  %t76 = load i64, ptr %l8, !tbaa !24
  %t79 = mul i64 %t75, %t76
  %t82 = add i64 %t74, %t79
  store ptr %l5, ptr %l63, !tbaa !29
  %t84 = load ptr, ptr %l4, !tbaa !29
  %t86 = getelementptr %"compiler/check:frame", ptr %t84, i32 0, i32 26
  %t90 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t86, i64 %t82)
  store i32 %t90, ptr %l67
  br label %bb21
bb21:
  %t91 = load ptr, ptr %l63, !tbaa !29
  %t92 = load i32, ptr %l67, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t91, i32 %t92)
  br label %bb22
bb22:
  br label %bb23
bb23:
  %t93 = load i64, ptr %l10, !tbaa !24
  %t95 = add i64 %t93, 1
  store i64 %t95, ptr %l10, !tbaa !24
  br label %bb17
bb24:
  %t97 = load i64, ptr %l2, !tbaa !24
  store i64 %t97, ptr %l12, !tbaa !24
  %t99 = load i64, ptr %l2, !tbaa !24
  %t100 = load i64, ptr %l3, !tbaa !24
  %t103 = add i64 %t99, %t100
  store i64 %t103, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t105 = load i64, ptr %l13, !tbaa !24
  %t106 = load i64, ptr %l12, !tbaa !24
  %t109 = icmp sgt i64 %t105, %t106
  br i1 %t109, label %bb25, label %bb26
bb25:
  %t111 = load i64, ptr %l14, !tbaa !24
  %t113 = icmp sgt i64 %t111, 0
  br i1 %t113, label %bb27, label %bb28
bb26:
  store i64 0, ptr %l77, !tbaa !24
  br label %bb30
bb27:
  %t115 = load i64, ptr %l13, !tbaa !24
  %t116 = load i64, ptr %l12, !tbaa !24
  %t119 = sub i64 %t115, %t116
  %t120 = load i64, ptr %l14, !tbaa !24
  %t123 = add i64 %t119, %t120
  %t125 = sub i64 %t123, 1
  %t126 = load i64, ptr %l14, !tbaa !24
  %t129 = sdiv i64 %t125, %t126
  store i64 %t129, ptr %l80, !tbaa !24
  br label %bb29
bb28:
  store i64 0, ptr %l80, !tbaa !24
  br label %bb29
bb29:
  %t131 = load i64, ptr %l80, !tbaa !24
  store i64 %t131, ptr %l77, !tbaa !24
  br label %bb30
bb30:
  %t132 = load i64, ptr %l77, !tbaa !24
  store i64 %t132, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb31
bb31:
  %t133 = load i64, ptr %l16, !tbaa !24
  %t134 = load i64, ptr %l15, !tbaa !24
  %t137 = icmp slt i64 %t133, %t134
  %t139 = xor i1 %t137, true
  br i1 %t139, label %bb32, label %bb33
bb32:
  br label %bb38
bb33:
  br label %bb34
bb34:
  %t141 = load i64, ptr %l12, !tbaa !24
  %t142 = load i64, ptr %l16, !tbaa !24
  %t143 = load i64, ptr %l14, !tbaa !24
  %t146 = mul i64 %t142, %t143
  %t149 = add i64 %t141, %t146
  %t151 = load ptr, ptr %l4, !tbaa !29
  %t153 = getelementptr %"compiler/check:frame", ptr %t151, i32 0, i32 27
  store ptr %t153, ptr %l99, !tbaa !29
  %t154 = load ptr, ptr %l4, !tbaa !29
  %t156 = getelementptr %"compiler/check:frame", ptr %t154, i32 0, i32 26
  %t160 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t156, i64 %t149)
  store i32 %t160, ptr %l103
  br label %bb35
bb35:
  %t161 = load ptr, ptr %l99, !tbaa !29
  %t162 = load i32, ptr %l103, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t161, i32 %t162)
  br label %bb36
bb36:
  br label %bb37
bb37:
  %t163 = load i64, ptr %l16, !tbaa !24
  %t165 = add i64 %t163, 1
  store i64 %t165, ptr %l16, !tbaa !24
  br label %bb31
bb38:
  %t167 = load ptr, ptr %l4, !tbaa !29
  %t169 = getelementptr %"compiler/check:frame", ptr %t167, i32 0, i32 26
  %t170 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eTruncate_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t169, i64 %t170)
  br label %bb39
bb39:
  store ptr %l5, ptr %l18, !tbaa !29
  store i64 0, ptr %l19, !tbaa !24
  br label %bb40
bb40:
  %t174 = load i64, ptr %l19, !tbaa !24
  store i64 %t174, ptr %l110, !tbaa !24
  %t175 = load ptr, ptr %l18, !tbaa !29
  %t177 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t175)
  store i64 %t177, ptr %l112
  br label %bb41
bb41:
  %t178 = load i64, ptr %l110, !tbaa !24
  %t179 = load i64, ptr %l112, !tbaa !24
  %t180 = icmp slt i64 %t178, %t179
  %t182 = xor i1 %t180, true
  br i1 %t182, label %bb42, label %bb43
bb42:
  br label %bb48
bb43:
  br label %bb44
bb44:
  %t184 = load ptr, ptr %l18, !tbaa !29
  %t185 = load i64, ptr %l19, !tbaa !24
  %t188 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t184, i64 %t185)
  store i32 %t188, ptr %l117
  br label %bb45
bb45:
  %t189 = load i32, ptr %l117, !tbaa !23
  %t190 = load ptr, ptr %l4, !tbaa !29
  %t192 = getelementptr %"compiler/check:frame", ptr %t190, i32 0, i32 26
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t192, i32 %t189)
  br label %bb46
bb46:
  br label %bb47
bb47:
  %t196 = load i64, ptr %l19, !tbaa !24
  %t198 = add i64 %t196, 1
  store i64 %t198, ptr %l19, !tbaa !24
  br label %bb40
bb48:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efactsExpr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i1 %a2, ptr %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l5 = alloca %"compiler/check:factsMark"
  %l6 = alloca i64
  %l7 = alloca i1
  %l8 = alloca ptr
  %l10 = alloca %"compiler/check:factsMark"
  %l13 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca i1
  %l18 = alloca ptr
  %l23 = alloca i64
  %l30 = alloca ptr
  %l33 = alloca %"compiler/source:Span"
  %l36 = alloca i32
  %l40 = alloca { i64, ptr }
  %l43 = alloca %"compiler/typed:Seq"
  %rv = alloca ptr
  %t67 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call %"compiler/check:factsMark" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efactsHeld(ptr %v0, ptr %t1)
  store %"compiler/check:factsMark" %t3, ptr %l10
  br label %bb1
bb1:
  %t4 = load %"compiler/check:factsMark", ptr %l10
  store %"compiler/check:factsMark" %t4, ptr %l5
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/check:Checker", ptr %t5, i32 0, i32 37
  %t9 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t7)
  store i64 %t9, ptr %l13
  br label %bb2
bb2:
  %t10 = load i64, ptr %l13, !tbaa !24
  store i64 %t10, ptr %l6, !tbaa !24
  %t11 = load ptr, ptr %l0, !tbaa !29
  store ptr %t11, ptr %l14, !tbaa !29
  store ptr %a1, ptr %l15, !tbaa !29
  store i1 %a2, ptr %l16, !tbaa !21
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t14)
  store ptr %t16, ptr %l18
  br label %bb3
bb3:
  %t17 = load ptr, ptr %l18, !tbaa !29
  %t19 = getelementptr %"compiler/check:frame", ptr %t17, i32 0, i32 7
  %t20 = load i64, ptr %t19, !tbaa !24
  %t21 = load ptr, ptr %l14, !tbaa !29
  %t22 = load ptr, ptr %l15, !tbaa !29
  %t23 = load i1, ptr %l16, !tbaa !21
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epushFacts(ptr %v0, ptr %v1, ptr %t21, ptr %t22, i1 %t23, i64 %t20)
  br label %bb4
bb4:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/check:Checker", ptr %t25, i32 0, i32 37
  %t29 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t27)
  store i64 %t29, ptr %l23
  br label %bb5
bb5:
  %t30 = load i64, ptr %l6, !tbaa !24
  %t31 = load i64, ptr %l23, !tbaa !24
  %t33 = icmp sgt i64 %t31, %t30
  store i1 %t33, ptr %l7, !tbaa !21
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load ptr, ptr %l3, !tbaa !29
  %t42 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v2, ptr %t35, ptr %t36, i32 %a4)
  store ptr %t42, ptr %l30
  br label %bb6
bb6:
  %t43 = load ptr, ptr %l30, !tbaa !29
  store ptr %t43, ptr %l8, !tbaa !29
  %t44 = load i1, ptr %l7, !tbaa !21
  br i1 %t44, label %bb7, label %bb8
bb7:
  %t46 = load ptr, ptr %l3, !tbaa !29
  %t48 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t46)
  store %"compiler/source:Span" %t48, ptr %l33
  br label %bb9
bb8:
  br label %bb13
bb9:
  %t49 = load ptr, ptr %l8, !tbaa !29
  %t52 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t49)
  store i32 %t52, ptr %l36
  br label %bb10
bb10:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/check:Checker", ptr %t53, i32 0, i32 37
  %t56 = load i64, ptr %l6, !tbaa !24
  %t59 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t55, i64 %t56)
  store { i64, ptr } %t59, ptr %l40
  br label %bb11
bb11:
  %t60 = load ptr, ptr %l8, !tbaa !29
  %t62 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t64 = call %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t62, ptr %t60)
  store %"compiler/typed:Seq" %t64, ptr %l43
  br label %bb12
bb12:
  %t65 = load %"compiler/typed:Seq", ptr %l43
  %t66 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Seq" %t65, ptr %t66
  store { i64, [5 x i64] } zeroinitializer, ptr %t67
  %t68 = getelementptr { i64, [5 x i64] }, ptr %t67, i32 0, i32 0
  store i64 12, ptr %t68
  %t69 = load %"compiler/source:Span", ptr %l33
  %t70 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t69, 0
  %t71 = load i32, ptr %l36, !tbaa !23
  %t72 = insertvalue { %"compiler/source:Span", i32, ptr } %t70, i32 %t71, 1
  %t74 = insertvalue { %"compiler/source:Span", i32, ptr } %t72, ptr %t66, 2
  %t75 = getelementptr { i64, [5 x i64] }, ptr %t67, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t74, ptr %t75
  %t76 = load { i64, [5 x i64] }, ptr %t67
  %t78 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t76, ptr %t78
  store ptr %t78, ptr %l8, !tbaa !29
  br label %bb13
bb13:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load %"compiler/check:factsMark", ptr %l5
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efactsDrop(ptr %v0, ptr %t80, %"compiler/check:factsMark" %t81)
  br label %bb14
bb14:
  %t84 = load ptr, ptr %l8, !tbaa !29
  store ptr %t84, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efnNameAt(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l13 = alloca ptr
  %l17 = alloca i64
  %l23 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l39 = alloca i64
  %l52 = alloca i64
  %l53 = alloca { i64, ptr }
  %l54 = alloca i64
  %l57 = alloca i64
  %l58 = alloca i64
  %l64 = alloca i64
  %l65 = alloca i32
  %l68 = alloca i64
  %l80 = alloca ptr
  %rv = alloca { i64, [3 x i64] }
  %t179 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i64, ptr %l1, !tbaa !24
  %t8 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t4, i64 %t5)
  store ptr %t8, ptr %l13
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l13, !tbaa !29
  store ptr %t9, ptr %l2, !tbaa !29
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t14 = load i64, ptr %l1, !tbaa !24
  %t17 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t13, i64 %t14)
  store i64 %t17, ptr %l17
  br label %bb2
bb2:
  %t18 = load i64, ptr %l17, !tbaa !24
  store i64 %t18, ptr %l3, !tbaa !24
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/check:Checker", ptr %t19, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t24 = getelementptr %"compiler/generic:Program", ptr %t22, i32 0, i32 0
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/load:Loader", ptr %t25, i32 0, i32 5
  %t28 = load i64, ptr %l3, !tbaa !24
  %t31 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t27, i64 %t28)
  store ptr %t31, ptr %l23
  br label %bb3
bb3:
  %t32 = load ptr, ptr %l23, !tbaa !29
  %t34 = getelementptr %"compiler/load:Module", ptr %t32, i32 0, i32 6
  %t35 = load ptr, ptr %t34, !tbaa !29
  store ptr %t35, ptr %l4, !tbaa !29
  %t37 = load ptr, ptr %l4, !tbaa !29
  %t39 = icmp eq ptr %t37, null
  br i1 %t39, label %bb4, label %bb5
bb4:
  call void @__olang_check_failed(ptr @olang_loc_a78beee7b0d01a06_c23e8f3cd3901b22)
  unreachable
bb5:
  br label %bb6
bb6:
  %t41 = load ptr, ptr %l4, !tbaa !29
  %t44 = getelementptr %"compiler/source:Source", ptr %t41, i32 0, i32 1
  %t45 = load { i64, ptr }, ptr %t44, !tbaa !27
  store { i64, ptr } %t45, ptr %l5, !tbaa !27
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load ptr, ptr %l2, !tbaa !29
  %t50 = getelementptr %"compiler/ast:Func", ptr %t48, i32 0, i32 2
  %t51 = load i32, ptr %t50, !tbaa !23
  %t54 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t47, i32 %t51)
  store { i64, ptr } %t54, ptr %l34
  br label %bb7
bb7:
  %t55 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t55, ptr %l6, !tbaa !27
  %t56 = load ptr, ptr %l2, !tbaa !29
  %t58 = getelementptr %"compiler/ast:Func", ptr %t56, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t61 = icmp eq ptr %t59, null
  %t63 = xor i1 %t61, true
  br i1 %t63, label %bb8, label %bb9
bb8:
  %t65 = load ptr, ptr %l2, !tbaa !29
  %t67 = getelementptr %"compiler/ast:Func", ptr %t65, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !29
  %t70 = icmp eq ptr %t68, null
  br i1 %t70, label %bb10, label %bb11
bb9:
  %t72 = load ptr, ptr %l2, !tbaa !29
  %t74 = getelementptr %"compiler/ast:Func", ptr %t72, i32 0, i32 0
  %t75 = getelementptr %"compiler/source:Span", ptr %t74, i32 0, i32 0
  %t76 = load i32, ptr %t75, !tbaa !23
  %t78 = sext i32 %t76 to i64
  %t80 = add i64 %t78, 2
  store i64 %t80, ptr %l39, !tbaa !24
  br label %bb13
bb10:
  call void @__olang_check_failed(ptr @olang_loc_a9ac84188a5d3ced_8a30b05829c2589)
  unreachable
bb11:
  br label %bb12
bb12:
  %t82 = load ptr, ptr %l2, !tbaa !29
  %t84 = getelementptr %"compiler/ast:Func", ptr %t82, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !29
  %t88 = getelementptr %"compiler/ast:Param", ptr %t85, i32 0, i32 0
  %t89 = getelementptr %"compiler/source:Span", ptr %t88, i32 0, i32 1
  %t90 = load i32, ptr %t89, !tbaa !23
  %t92 = sext i32 %t90 to i64
  store i64 %t92, ptr %l39, !tbaa !24
  br label %bb13
bb13:
  %t94 = load i64, ptr %l39, !tbaa !24
  store i64 %t94, ptr %l7, !tbaa !24
  %t95 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t95, ptr %l53, !tbaa !27
  %t96 = load i64, ptr %l7, !tbaa !24
  store i64 %t96, ptr %l54, !tbaa !24
  %t97 = load ptr, ptr %l2, !tbaa !29
  %t99 = getelementptr %"compiler/ast:Func", ptr %t97, i32 0, i32 0
  %t100 = getelementptr %"compiler/source:Span", ptr %t99, i32 0, i32 1
  %t101 = load i32, ptr %t100, !tbaa !23
  %t103 = sext i32 %t101 to i64
  store i64 %t103, ptr %l57, !tbaa !24
  %t104 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t105 = extractvalue { i64, ptr } %t104, 0
  store i64 %t105, ptr %l58, !tbaa !24
  %t106 = load i64, ptr %l54, !tbaa !24
  %t107 = icmp sge i64 %t106, 0
  br i1 %t107, label %bb14, label %bb15
bb14:
  %t109 = load i64, ptr %l54, !tbaa !24
  %t110 = load i64, ptr %l57, !tbaa !24
  %t111 = icmp sle i64 %t109, %t110
  br i1 %t111, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_d343f6dbe85f33a0_61dfe5c423c7544c)
  unreachable
bb16:
  %t113 = load i64, ptr %l57, !tbaa !24
  %t114 = load i64, ptr %l58, !tbaa !24
  %t115 = icmp sle i64 %t113, %t114
  br i1 %t115, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_d343f6dbe85f33a0_61dfe5c423c7544c)
  unreachable
bb18:
  %t117 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t118 = load ptr, ptr %t117, !tbaa !27
  %t119 = load i64, ptr %l54, !tbaa !24
  %t120 = load i64, ptr %l57, !tbaa !24
  %t121 = getelementptr i8, ptr %t118, i64 %t119
  %t122 = sub i64 %t120, %t119
  %t123 = insertvalue { i64, ptr } undef, i64 %t122, 0
  %t124 = insertvalue { i64, ptr } %t123, ptr %t121, 1
  %t125 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t128 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v0, { i64, ptr } %t124, { i64, ptr } %t125)
  %t129 = extractvalue { i32, i64 } %t128, 1
  %t130 = extractvalue { i32, i64 } %t128, 0
  store i32 %t130, ptr %l65
  %t131 = icmp ne i32 %t130, 0
  br i1 %t131, label %bb21, label %ok.132, !prof !99
ok.132:
  store i64 %t129, ptr %l64
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_d343f6dbe85f33a0_61dfe5c423c7544c)
  unreachable
bb20:
  %t133 = load i64, ptr %l64, !tbaa !24
  store i64 %t133, ptr %l52, !tbaa !24
  br label %bb23
bb21:
  br label %bb22
bb22:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l52, !tbaa !24
  br label %bb23
bb23:
  %t134 = load i64, ptr %l52, !tbaa !24
  store i64 %t134, ptr %l8, !tbaa !24
  %t135 = load i64, ptr %l8, !tbaa !24
  %t137 = icmp slt i64 %t135, 0
  br i1 %t137, label %bb24, label %bb25
bb24:
  %t139 = load ptr, ptr %l2, !tbaa !29
  %t141 = getelementptr %"compiler/ast:Func", ptr %t139, i32 0, i32 0
  %t142 = getelementptr %"compiler/source:Span", ptr %t141, i32 0, i32 0
  %t143 = load i32, ptr %t142, !tbaa !23
  %t145 = sext i32 %t143 to i64
  store i64 %t145, ptr %l68, !tbaa !24
  br label %bb26
bb25:
  %t147 = load i64, ptr %l7, !tbaa !24
  %t148 = load i64, ptr %l8, !tbaa !24
  %t151 = add i64 %t147, %t148
  store i64 %t151, ptr %l68, !tbaa !24
  br label %bb26
bb26:
  %t153 = load i64, ptr %l68, !tbaa !24
  store i64 %t153, ptr %l9, !tbaa !24
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t156 = getelementptr %"compiler/check:Checker", ptr %t154, i32 0, i32 1
  %t157 = load ptr, ptr %t156, !tbaa !29
  %t159 = getelementptr %"compiler/generic:Program", ptr %t157, i32 0, i32 0
  %t160 = load ptr, ptr %t159, !tbaa !29
  %t162 = getelementptr %"compiler/load:Loader", ptr %t160, i32 0, i32 5
  %t163 = load i64, ptr %l3, !tbaa !24
  %t166 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t162, i64 %t163)
  store ptr %t166, ptr %l80
  br label %bb27
bb27:
  %t167 = load ptr, ptr %l80, !tbaa !29
  %t169 = getelementptr %"compiler/load:Module", ptr %t167, i32 0, i32 4
  %t170 = load i64, ptr %t169, !tbaa !24
  %t171 = load i64, ptr %l9, !tbaa !24
  %t172 = load i64, ptr %l9, !tbaa !24
  %t173 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t175 = extractvalue { i64, ptr } %t173, 0
  %t178 = add i64 %t172, %t175
  store { i64, [3 x i64] } zeroinitializer, ptr %t179
  %t180 = getelementptr { i64, [3 x i64] }, ptr %t179, i32 0, i32 0
  store i64 3, ptr %t180
  %t182 = insertvalue { i64, i64, i64 } undef, i64 %t170, 0
  %t184 = insertvalue { i64, i64, i64 } %t182, i64 %t171, 1
  %t186 = insertvalue { i64, i64, i64 } %t184, i64 %t178, 2
  %t187 = getelementptr { i64, [3 x i64] }, ptr %t179, i32 0, i32 1
  store { i64, i64, i64 } %t186, ptr %t187
  %t188 = load { i64, [3 x i64] }, ptr %t179
  store { i64, [3 x i64] } %t188, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [3 x i64] }, ptr %rv
  ret { i64, [3 x i64] } %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l6 = alloca i64
  %l9 = alloca ptr
  %l13 = alloca ptr
  %l16 = alloca ptr
  %l22 = alloca %"compiler/check:Gap"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 -1, ptr %l3, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 14
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_H2251bc8fca359ca0394d0bb11af7ba0a(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i64, ptr %l6, !tbaa !24
  %t7 = icmp sgt i64 %t6, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t9)
  store ptr %t11, ptr %l9
  br label %bb4
bb3:
  br label %bb6
bb4:
  %t12 = load ptr, ptr %l9, !tbaa !29
  %t14 = getelementptr %"compiler/check:frame", ptr %t12, i32 0, i32 2
  %t15 = load i64, ptr %t14, !tbaa !24
  store i64 %t15, ptr %l3, !tbaa !24
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t17)
  store ptr %t19, ptr %l13
  br label %bb5
bb5:
  %t20 = load ptr, ptr %l13, !tbaa !29
  %t22 = getelementptr %"compiler/check:frame", ptr %t20, i32 0, i32 18
  store i1 true, ptr %t22, !tbaa !21
  br label %bb6
bb6:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/check:Checker", ptr %t23, i32 0, i32 13
  store ptr %t25, ptr %l16, !tbaa !29
  %t26 = load i64, ptr %l3, !tbaa !24
  %t30 = extractvalue { i64, ptr } %a2, 1
  %t31 = extractvalue { i64, ptr } %a2, 0
  %t32 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t31)
  call void @olang_textcopy(ptr %t32, ptr %t30, i64 %t31)
  %t33 = insertvalue { i64, ptr } undef, i64 %t31, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t32, 1
  %t36 = extractvalue { i64, ptr } %t34, 0
  %t37 = extractvalue { i64, ptr } %t34, 1
  %t38 = mul i64 %t36, 1
  %t39 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t38)
  call void @llvm.memcpy.p0.p0.i64(ptr %t39, ptr %t37, i64 %t38, i1 false)
  %t40 = insertvalue { i64, ptr } undef, i64 %t36, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t39, 1
  %t45 = call %"compiler/check:Gap" @compiler_2fcheck_3aGap_2ector(ptr %v0, ptr %v0, i64 %t26, %"compiler/source:Span" %a1, { i64, ptr } %t41)
  store %"compiler/check:Gap" %t45, ptr %l22
  br label %bb7
bb7:
  %t46 = load ptr, ptr %l16, !tbaa !29
  %t47 = load %"compiler/check:Gap", ptr %l22
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aGap_3e_2ePush_3ccompiler_2fcheck_3aGap_3e(ptr %v0, ptr %v0, ptr %t46, %"compiler/check:Gap" %t47)
  br label %bb8
bb8:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egenericNamed(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca %"compiler/names:Ref"
  %l4 = alloca i32
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca %"compiler/names:Ref"
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca i1
  %l16 = alloca ptr
  %l18 = alloca ptr
  %l22 = alloca %"compiler/names:Ref"
  %l25 = alloca i1
  %l32 = alloca i32
  %l37 = alloca i64
  %l40 = alloca ptr
  %l41 = alloca i1
  %l48 = alloca ptr
  %l50 = alloca ptr
  %l54 = alloca %"compiler/names:Ref"
  %l57 = alloca i1
  %l64 = alloca i32
  %l69 = alloca i64
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l2
  br label %bb5
bb4:
  br label %bb19
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/check:Checker", ptr %t16, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = getelementptr %"compiler/generic:Program", ptr %t19, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !29
  store ptr %t22, ptr %l16, !tbaa !29
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t23)
  store ptr %t25, ptr %l18
  br label %bb6
bb6:
  %t26 = load ptr, ptr %l18, !tbaa !29
  %t28 = getelementptr %"compiler/check:frame", ptr %t26, i32 0, i32 2
  %t29 = load i64, ptr %t28, !tbaa !24
  %t30 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t31 = load i32, ptr %t30, !tbaa !23
  %t32 = load ptr, ptr %l16, !tbaa !29
  %t35 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t32, i64 %t29, i32 %t31)
  store %"compiler/names:Ref" %t35, ptr %l22
  br label %bb7
bb7:
  %t36 = load %"compiler/names:Ref", ptr %l22
  store %"compiler/names:Ref" %t36, ptr %l3
  %t37 = getelementptr %"compiler/names:Ref", ptr %l3, i32 0, i32 0
  %t38 = load i32, ptr %t37
  %t40 = trunc i64 4 to i32
  %t41 = icmp eq i32 %t38, %t40
  br i1 %t41, label %bb8, label %bb9
bb8:
  %t43 = getelementptr %"compiler/names:Ref", ptr %l3, i32 0, i32 2
  %t44 = load i64, ptr %t43, !tbaa !24
  %t46 = icmp sge i64 %t44, 0
  store i1 %t46, ptr %l25, !tbaa !21
  br label %bb10
bb9:
  store i1 false, ptr %l25, !tbaa !21
  br label %bb10
bb10:
  %t48 = load i1, ptr %l25, !tbaa !21
  br i1 %t48, label %bb11, label %bb12
bb11:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/check:Checker", ptr %t49, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !29
  %t53 = getelementptr %"compiler/names:Ref", ptr %l3, i32 0, i32 1
  %t54 = load i64, ptr %t53, !tbaa !24
  %t55 = getelementptr %"compiler/names:Ref", ptr %l3, i32 0, i32 2
  %t56 = load i64, ptr %t55, !tbaa !24
  %t60 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %t52, i64 %t54, i64 %t56)
  store i32 %t60, ptr %l32
  br label %bb13
bb12:
  br label %bb18
bb13:
  %t61 = load i32, ptr %l32, !tbaa !23
  store i32 %t61, ptr %l4, !tbaa !23
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/check:Checker", ptr %t62, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t67 = getelementptr %"compiler/generic:Program", ptr %t65, i32 0, i32 2
  %t68 = load i32, ptr %l4, !tbaa !23
  %t71 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclParams(ptr %v0, ptr %t67, i32 %t68)
  store i64 %t71, ptr %l37
  br label %bb14
bb14:
  %t72 = load i64, ptr %l37, !tbaa !24
  %t73 = icmp sgt i64 %t72, 0
  br i1 %t73, label %bb15, label %bb16
bb15:
  %t75 = load i32, ptr %l4, !tbaa !23
  store i32 %t75, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  br label %bb18
bb18:
  br label %bb43
bb19:
  %t77 = load ptr, ptr %l1, !tbaa !29
  store ptr %t77, ptr %l40, !tbaa !29
  store i1 false, ptr %l41, !tbaa !21
  %t78 = load ptr, ptr %l40, !tbaa !29
  %t79 = icmp ne ptr %t78, null
  br i1 %t79, label %bb20, label %bb21
bb20:
  %t81 = load ptr, ptr %l40, !tbaa !29
  %t82 = load i64, ptr %t81
  %t84 = icmp eq i64 %t82, 15
  store i1 %t84, ptr %l41, !tbaa !21
  br label %bb21
bb21:
  %t85 = load i1, ptr %l41, !tbaa !21
  br i1 %t85, label %bb22, label %bb23
bb22:
  %t86 = load ptr, ptr %l1, !tbaa !29
  %t88 = getelementptr { i64, [5 x i64] }, ptr %t86, i32 0, i32 1
  %t89 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t88, i32 0, i32 0
  %t90 = load %"compiler/source:Span", ptr %t89
  store %"compiler/source:Span" %t90, ptr %l5
  br label %bb24
bb23:
  br label %bb38
bb24:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/check:Checker", ptr %t92, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !29
  %t97 = getelementptr %"compiler/generic:Program", ptr %t95, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !29
  store ptr %t98, ptr %l48, !tbaa !29
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t99)
  store ptr %t101, ptr %l50
  br label %bb25
bb25:
  %t102 = load ptr, ptr %l50, !tbaa !29
  %t104 = getelementptr %"compiler/check:frame", ptr %t102, i32 0, i32 2
  %t105 = load i64, ptr %t104, !tbaa !24
  %t106 = getelementptr %"compiler/source:Span", ptr %l5, i32 0, i32 1
  %t107 = load i32, ptr %t106, !tbaa !23
  %t108 = load ptr, ptr %l48, !tbaa !29
  %t111 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eMember(ptr %v0, ptr %t108, i64 %t105, i32 %t107)
  store %"compiler/names:Ref" %t111, ptr %l54
  br label %bb26
bb26:
  %t112 = load %"compiler/names:Ref", ptr %l54
  store %"compiler/names:Ref" %t112, ptr %l6
  %t113 = getelementptr %"compiler/names:Ref", ptr %l6, i32 0, i32 0
  %t114 = load i32, ptr %t113
  %t116 = trunc i64 4 to i32
  %t117 = icmp eq i32 %t114, %t116
  br i1 %t117, label %bb27, label %bb28
bb27:
  %t119 = getelementptr %"compiler/names:Ref", ptr %l6, i32 0, i32 2
  %t120 = load i64, ptr %t119, !tbaa !24
  %t122 = icmp sge i64 %t120, 0
  store i1 %t122, ptr %l57, !tbaa !21
  br label %bb29
bb28:
  store i1 false, ptr %l57, !tbaa !21
  br label %bb29
bb29:
  %t124 = load i1, ptr %l57, !tbaa !21
  br i1 %t124, label %bb30, label %bb31
bb30:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t127 = getelementptr %"compiler/check:Checker", ptr %t125, i32 0, i32 1
  %t128 = load ptr, ptr %t127, !tbaa !29
  %t129 = getelementptr %"compiler/names:Ref", ptr %l6, i32 0, i32 1
  %t130 = load i64, ptr %t129, !tbaa !24
  %t131 = getelementptr %"compiler/names:Ref", ptr %l6, i32 0, i32 2
  %t132 = load i64, ptr %t131, !tbaa !24
  %t136 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %t128, i64 %t130, i64 %t132)
  store i32 %t136, ptr %l64
  br label %bb32
bb31:
  br label %bb37
bb32:
  %t137 = load i32, ptr %l64, !tbaa !23
  store i32 %t137, ptr %l7, !tbaa !23
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t140 = getelementptr %"compiler/check:Checker", ptr %t138, i32 0, i32 1
  %t141 = load ptr, ptr %t140, !tbaa !29
  %t143 = getelementptr %"compiler/generic:Program", ptr %t141, i32 0, i32 2
  %t144 = load i32, ptr %l7, !tbaa !23
  %t147 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclParams(ptr %v0, ptr %t143, i32 %t144)
  store i64 %t147, ptr %l69
  br label %bb33
bb33:
  %t148 = load i64, ptr %l69, !tbaa !24
  %t149 = icmp sgt i64 %t148, 0
  br i1 %t149, label %bb34, label %bb35
bb34:
  %t151 = load i32, ptr %l7, !tbaa !23
  store i32 %t151, ptr %rv
  br label %ret
bb35:
  br label %bb36
bb36:
  br label %bb37
bb37:
  br label %bb43
bb38:
  br i1 true, label %bb39, label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb42
bb41:
  br label %bb43
bb42:
  call void @__olang_check_failed(ptr @olang_loc_369dcc443ccea639_2a432d0faa4fb925)
  unreachable
bb43:
  store i32 -1, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehole(ptr %v0, ptr %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l0 = alloca ptr
  %rv = alloca ptr
  %t3 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store { i64, [5 x i64] } zeroinitializer, ptr %t3
  %t4 = getelementptr { i64, [5 x i64] }, ptr %t3, i32 0, i32 0
  store i64 0, ptr %t4
  %t6 = insertvalue { %"compiler/source:Span", i32, i64 } undef, %"compiler/source:Span" %a1, 0
  %t8 = insertvalue { %"compiler/source:Span", i32, i64 } %t6, i32 %t2, 1
  %t9 = insertvalue { %"compiler/source:Span", i32, i64 } %t8, i64 0, 2
  %t10 = getelementptr { i64, [5 x i64] }, ptr %t3, i32 0, i32 1
  store { %"compiler/source:Span", i32, i64 } %t9, ptr %t10
  %t11 = load { i64, [5 x i64] }, ptr %t3
  %t13 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t11, ptr %t13
  store ptr %t13, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eidentity(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, i1 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i1
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca { i64, ptr }
  %l7 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca { i64, [3 x i64] }
  %l14 = alloca ptr
  %l16 = alloca i1
  %l17 = alloca i1
  %l19 = alloca i1
  %l26 = alloca ptr
  %l27 = alloca ptr
  %l29 = alloca %"compiler/source:Span"
  %l31 = alloca %"compiler/source:Span"
  %l32 = alloca %"compiler/source:Span"
  %l34 = alloca i1
  %l37 = alloca { i64, ptr }
  %l40 = alloca i1
  %l41 = alloca ptr
  %l42 = alloca %"compiler/source:Span"
  %l43 = alloca { i64, ptr }
  %l44 = alloca ptr
  %l46 = alloca %"compiler/source:Span"
  %l47 = alloca { i64, ptr }
  %l48 = alloca ptr
  %l50 = alloca %"compiler/source:Span"
  %l51 = alloca { i64, ptr }
  %l52 = alloca %"compiler/msgs:Msg"
  %l53 = alloca i64
  %l54 = alloca ptr
  %l55 = alloca %"compiler/source:Span"
  %l57 = alloca %"compiler/msgs:Msg"
  %l58 = alloca i64
  %l62 = alloca ptr
  %l64 = alloca i1
  %l65 = alloca ptr
  %l66 = alloca %"compiler/source:Span"
  %l67 = alloca %"compiler/msgs:Msg"
  %l68 = alloca i64
  %l72 = alloca ptr
  %l77 = alloca ptr
  %l80 = alloca i32
  %l86 = alloca ptr
  %l91 = alloca i1
  %l95 = alloca i1
  %l96 = alloca ptr
  %l97 = alloca %"compiler/source:Span"
  %l98 = alloca ptr
  %l100 = alloca %"compiler/source:Span"
  %l101 = alloca { i64, ptr }
  %l104 = alloca %"compiler/msgs:Msg"
  %l105 = alloca i64
  %l106 = alloca ptr
  %l107 = alloca %"compiler/source:Span"
  %l108 = alloca i32
  %l110 = alloca i64
  %l111 = alloca ptr
  %l112 = alloca ptr
  %l113 = alloca %"compiler/source:Span"
  %l114 = alloca i32
  %l115 = alloca i32
  %l116 = alloca ptr
  %l120 = alloca ptr
  %l122 = alloca ptr
  %l124 = alloca ptr
  %l128 = alloca ptr
  %l132 = alloca i1
  %l134 = alloca i1
  %l139 = alloca i32
  %l143 = alloca ptr
  %l144 = alloca %"compiler/source:Span"
  %l147 = alloca { i64, ptr }
  %l149 = alloca %"compiler/msgs:Msg"
  %l150 = alloca i64
  %l154 = alloca ptr
  %l159 = alloca i1
  %l160 = alloca ptr
  %l161 = alloca %"compiler/source:Span"
  %l162 = alloca ptr
  %l164 = alloca %"compiler/source:Span"
  %l165 = alloca { i64, ptr }
  %l167 = alloca { i64, ptr }
  %l168 = alloca %"compiler/msgs:Msg"
  %l169 = alloca i64
  %l170 = alloca ptr
  %l171 = alloca %"compiler/source:Span"
  %l172 = alloca i32
  %l174 = alloca i64
  %l175 = alloca ptr
  %l178 = alloca i1
  %l179 = alloca i1
  %l184 = alloca i1
  %l186 = alloca ptr
  %l187 = alloca %"compiler/source:Span"
  %l188 = alloca ptr
  %l190 = alloca %"compiler/source:Span"
  %l191 = alloca { i64, ptr }
  %l194 = alloca { i64, ptr }
  %l195 = alloca { i64, ptr }
  %l197 = alloca { i64, ptr }
  %l198 = alloca %"compiler/msgs:Msg"
  %l199 = alloca i64
  %l201 = alloca ptr
  %l205 = alloca { i64, [3 x i64] }
  %l208 = alloca { i64, [3 x i64] }
  %l211 = alloca { i64, [3 x i64] }
  %l218 = alloca ptr
  %l219 = alloca i64
  %l220 = alloca { i64, [3 x i64] }
  %l221 = alloca %"compiler/msgs:Msg"
  %l222 = alloca ptr
  %l223 = alloca %"compiler/source:Span"
  %l224 = alloca i32
  %l226 = alloca i64
  %l227 = alloca ptr
  %l228 = alloca ptr
  %l233 = alloca ptr
  %l234 = alloca i32
  %l236 = alloca %"compiler/source:Span"
  %l237 = alloca ptr
  %l245 = alloca ptr
  %l247 = alloca ptr
  %l251 = alloca ptr
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  store i1 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = call i1 @compiler_2fcheck_2eisNullLit(ptr %v1, ptr %t1)
  store i1 %t3, ptr %l16
  br label %bb1
bb1:
  %t4 = load i1, ptr %l16, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t7 = call i1 @compiler_2fcheck_2eisNullLit(ptr %v2, ptr %t5)
  store i1 %t7, ptr %l19
  br label %bb4
bb3:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb5
bb4:
  %t8 = load i1, ptr %l19, !tbaa !21
  %t9 = xor i1 %t8, true
  store i1 %t9, ptr %l17, !tbaa !21
  br label %bb5
bb5:
  %t11 = load i1, ptr %l17, !tbaa !21
  br i1 %t11, label %bb6, label %bb7
bb6:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load %"compiler/source:Span", ptr %l1
  %t14 = load ptr, ptr %l3, !tbaa !29
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t16 = load i1, ptr %l4, !tbaa !21
  %t22 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eidentity(ptr %v0, ptr %v2, ptr %v1, ptr %t12, %"compiler/source:Span" %t13, ptr %t14, ptr %t15, i1 %t16)
  store ptr %t22, ptr %l26
  br label %bb8
bb7:
  br label %bb9
bb8:
  %t23 = load ptr, ptr %l26, !tbaa !29
  store ptr %t23, ptr %rv
  br label %ret
bb9:
  %t24 = load ptr, ptr %l0, !tbaa !29
  store ptr %t24, ptr %l27, !tbaa !29
  %t25 = load ptr, ptr %l2, !tbaa !29
  %t27 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t25)
  store %"compiler/source:Span" %t27, ptr %l29
  br label %bb10
bb10:
  %t28 = load ptr, ptr %l3, !tbaa !29
  %t30 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t28)
  store %"compiler/source:Span" %t30, ptr %l31
  br label %bb11
bb11:
  %t31 = load ptr, ptr %l27, !tbaa !29
  %t32 = load %"compiler/source:Span", ptr %l29
  %t33 = load %"compiler/source:Span", ptr %l31
  %t34 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebetween(ptr %v0, ptr %t31, %"compiler/source:Span" %t32, %"compiler/source:Span" %t33, i64 2)
  store %"compiler/source:Span" %t34, ptr %l32
  br label %bb12
bb12:
  %t35 = load %"compiler/source:Span", ptr %l32
  store %"compiler/source:Span" %t35, ptr %l5
  %t36 = load ptr, ptr %l3, !tbaa !29
  %t38 = call i1 @compiler_2fcheck_2eisNullLit(ptr %v2, ptr %t36)
  store i1 %t38, ptr %l34
  br label %bb13
bb13:
  %t39 = load i1, ptr %l34, !tbaa !21
  %t40 = xor i1 %t39, true
  br i1 %t40, label %bb14, label %bb15
bb14:
  %t42 = load i1, ptr %l4, !tbaa !21
  br i1 %t42, label %bb16, label %bb17
bb15:
  br label %bb32
bb16:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d22, i32 0, i32 1) }, ptr %l37, !tbaa !27
  br label %bb18
bb17:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d23, i32 0, i32 1) }, ptr %l37, !tbaa !27
  br label %bb18
bb18:
  %t44 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t44, ptr %l6, !tbaa !27
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t46 = load ptr, ptr %l3, !tbaa !29
  %t49 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseWritten(ptr %v0, ptr %v2, ptr %t45, ptr %t46)
  store i1 %t49, ptr %l40
  br label %bb19
bb19:
  %t50 = load i1, ptr %l40, !tbaa !21
  br i1 %t50, label %bb20, label %bb21
bb20:
  store %olang.scope zeroinitializer, ptr %s3
  %t51 = load ptr, ptr %l0, !tbaa !29
  store ptr %t51, ptr %l41, !tbaa !29
  %t52 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t52, ptr %l42
  %t53 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t53, ptr %l43, !tbaa !27
  %t54 = load ptr, ptr %l0, !tbaa !29
  store ptr %t54, ptr %l44, !tbaa !29
  %t55 = load ptr, ptr %l2, !tbaa !29
  %t57 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t55)
  store %"compiler/source:Span" %t57, ptr %l46
  br label %bb22
bb21:
  store %olang.scope zeroinitializer, ptr %s4
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l54, !tbaa !29
  %t59 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t59, ptr %l55
  %t60 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t61 = load ptr, ptr @__olang_prog_scope
  %t63 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eIsOnlyNull(ptr %t61, ptr %s4, { i64, ptr } %t60)
  store %"compiler/msgs:Msg" %t63, ptr %l57
  br label %bb28
bb22:
  %t64 = load ptr, ptr %l44, !tbaa !29
  %t65 = load %"compiler/source:Span", ptr %l46
  %t66 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %t64, %"compiler/source:Span" %t65)
  store { i64, ptr } %t66, ptr %l47
  br label %bb23
bb23:
  %t67 = load ptr, ptr %l0, !tbaa !29
  store ptr %t67, ptr %l48, !tbaa !29
  %t68 = load ptr, ptr %l3, !tbaa !29
  %t70 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t68)
  store %"compiler/source:Span" %t70, ptr %l50
  br label %bb24
bb24:
  %t71 = load ptr, ptr %l48, !tbaa !29
  %t72 = load %"compiler/source:Span", ptr %l50
  %t73 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %t71, %"compiler/source:Span" %t72)
  store { i64, ptr } %t73, ptr %l51
  br label %bb25
bb25:
  %t74 = load ptr, ptr @__olang_prog_scope
  %t75 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t76 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t77 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t78 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eIsCaseWritten(ptr %t74, ptr %v0, ptr %v0, ptr %s3, { i64, ptr } %t75, { i64, ptr } %t76, { i64, ptr } %t77)
  store %"compiler/msgs:Msg" %t78, ptr %l52
  br label %bb26
bb26:
  %t79 = load ptr, ptr %l41, !tbaa !29
  %t80 = load %"compiler/source:Span", ptr %l42
  %t81 = load %"compiler/msgs:Msg", ptr %l52
  %t82 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s3, ptr %t79, %"compiler/source:Span" %t80, %"compiler/msgs:Msg" %t81)
  store i64 %t82, ptr %l53
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s3)
  br label %bb30
bb28:
  %t83 = load ptr, ptr %l54, !tbaa !29
  %t84 = load %"compiler/source:Span", ptr %l55
  %t85 = load %"compiler/msgs:Msg", ptr %l57
  %t86 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s4, ptr %t83, %"compiler/source:Span" %t84, %"compiler/msgs:Msg" %t85)
  store i64 %t86, ptr %l58
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s4)
  br label %bb30
bb30:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t88 = load %"compiler/source:Span", ptr %l1
  %t89 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t93 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t87, %"compiler/source:Span" %t88, i32 %t89, i64 0)
  store ptr %t93, ptr %l62
  br label %bb31
bb31:
  %t94 = load ptr, ptr %l62, !tbaa !29
  store ptr %t94, ptr %rv
  br label %ret
bb32:
  %t95 = load ptr, ptr %l2, !tbaa !29
  %t97 = call i1 @compiler_2fcheck_2eisNullLit(ptr %v1, ptr %t95)
  store i1 %t97, ptr %l64
  br label %bb33
bb33:
  %t98 = load i1, ptr %l64, !tbaa !21
  br i1 %t98, label %bb34, label %bb35
bb34:
  store %olang.scope zeroinitializer, ptr %s5
  %t99 = load ptr, ptr %l0, !tbaa !29
  store ptr %t99, ptr %l65, !tbaa !29
  %t100 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t100, ptr %l66
  %t101 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eIsNullOfNull(ptr %s5)
  store %"compiler/msgs:Msg" %t101, ptr %l67
  br label %bb36
bb35:
  br label %bb39
bb36:
  %t102 = load ptr, ptr %l65, !tbaa !29
  %t103 = load %"compiler/source:Span", ptr %l66
  %t104 = load %"compiler/msgs:Msg", ptr %l67
  %t105 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s5, ptr %t102, %"compiler/source:Span" %t103, %"compiler/msgs:Msg" %t104)
  store i64 %t105, ptr %l68
  br label %bb37
bb37:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t107 = load %"compiler/source:Span", ptr %l1
  %t108 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t112 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t106, %"compiler/source:Span" %t107, i32 %t108, i64 0)
  store ptr %t112, ptr %l72
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s5)
  %t113 = load ptr, ptr %l72, !tbaa !29
  store ptr %t113, ptr %rv
  br label %ret
bb39:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t115 = load ptr, ptr %l2, !tbaa !29
  %t117 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t121 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %t114, ptr %t115, i32 %t117)
  store ptr %t121, ptr %l77
  br label %bb40
bb40:
  %t122 = load ptr, ptr %l77, !tbaa !29
  store ptr %t122, ptr %l7, !tbaa !29
  %t123 = load ptr, ptr %l7, !tbaa !29
  %t126 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t123)
  store i32 %t126, ptr %l80
  br label %bb41
bb41:
  %t127 = load i32, ptr %l80, !tbaa !23
  store i32 %t127, ptr %l8, !tbaa !23
  %t128 = load i32, ptr %l8, !tbaa !23
  %t129 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t132 = icmp eq i32 %t128, %t129
  br i1 %t132, label %bb42, label %bb43
bb42:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t135 = load %"compiler/source:Span", ptr %l1
  %t138 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t134, %"compiler/source:Span" %t135)
  store ptr %t138, ptr %l86
  br label %bb44
bb43:
  br label %bb45
bb44:
  %t139 = load ptr, ptr %l86, !tbaa !29
  store ptr %t139, ptr %rv
  br label %ret
bb45:
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t142 = getelementptr %"compiler/check:Checker", ptr %t140, i32 0, i32 1
  %t143 = load ptr, ptr %t142, !tbaa !29
  %t145 = getelementptr %"compiler/generic:Program", ptr %t143, i32 0, i32 2
  %t146 = load i32, ptr %l8, !tbaa !23
  %t149 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsErrVal(ptr %v0, ptr %t145, i32 %t146)
  store i1 %t149, ptr %l91
  br label %bb46
bb46:
  %t150 = load i1, ptr %l91, !tbaa !21
  br i1 %t150, label %bb47, label %bb48
bb47:
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t152 = load ptr, ptr %l2, !tbaa !29
  %t153 = load ptr, ptr %l7, !tbaa !29
  %t157 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrNonNull(ptr %v0, ptr %v1, ptr %v0, ptr %t151, ptr %t152, ptr %t153)
  store i1 %t157, ptr %l95
  br label %bb49
bb48:
  br label %bb67
bb49:
  %t158 = load i1, ptr %l95, !tbaa !21
  br i1 %t158, label %bb50, label %bb51
bb50:
  store %olang.scope zeroinitializer, ptr %s8
  %t159 = load ptr, ptr %l0, !tbaa !29
  store ptr %t159, ptr %l96, !tbaa !29
  %t160 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t160, ptr %l97
  %t161 = load ptr, ptr %l0, !tbaa !29
  store ptr %t161, ptr %l98, !tbaa !29
  %t162 = load ptr, ptr %l2, !tbaa !29
  %t164 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t162)
  store %"compiler/source:Span" %t164, ptr %l100
  br label %bb52
bb51:
  br label %bb60
bb52:
  %t165 = load ptr, ptr %l98, !tbaa !29
  %t166 = load %"compiler/source:Span", ptr %l100
  %t167 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %t165, %"compiler/source:Span" %t166)
  store { i64, ptr } %t167, ptr %l101
  br label %bb53
bb53:
  %t168 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d24, i32 0, i32 1) }, 1
  %t169 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d24, i32 0, i32 1) }, 0
  %t170 = load { i64, ptr }, ptr %l101, !tbaa !27
  %t171 = extractvalue { i64, ptr } %t170, 1
  %t172 = extractvalue { i64, ptr } %t170, 0
  %t173 = add i64 %t169, %t172
  %t174 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d24, i32 0, i32 1) }, 1
  %t175 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d24, i32 0, i32 1) }, 0
  %t176 = add i64 %t173, %t175
  %t177 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t176)
  call void @olang_textcopy(ptr %t177, ptr %t168, i64 %t169)
  %t178 = getelementptr i8, ptr %t177, i64 %t169
  call void @olang_textcopy(ptr %t178, ptr %t171, i64 %t172)
  %t179 = getelementptr i8, ptr %t178, i64 %t172
  call void @olang_textcopy(ptr %t179, ptr %t174, i64 %t175)
  %t180 = insertvalue { i64, ptr } undef, i64 %t176, 0
  %t181 = insertvalue { i64, ptr } %t180, ptr %t177, 1
  %t183 = extractvalue { i64, ptr } %t181, 0
  %t184 = extractvalue { i64, ptr } %t181, 1
  %t185 = mul i64 %t183, 1
  %t186 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t185)
  call void @llvm.memcpy.p0.p0.i64(ptr %t186, ptr %t184, i64 %t185, i1 false)
  %t187 = insertvalue { i64, ptr } undef, i64 %t183, 0
  %t188 = insertvalue { i64, ptr } %t187, ptr %t186, 1
  %t190 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eErrNeverNull(ptr %s8, ptr %s8, { i64, ptr } %t188)
  store %"compiler/msgs:Msg" %t190, ptr %l104
  br label %bb54
bb54:
  %t191 = load ptr, ptr %l96, !tbaa !29
  %t192 = load %"compiler/source:Span", ptr %l97
  %t193 = load %"compiler/msgs:Msg", ptr %l104
  %t194 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s8, ptr %t191, %"compiler/source:Span" %t192, %"compiler/msgs:Msg" %t193)
  store i64 %t194, ptr %l105
  br label %bb55
bb55:
  %t195 = load ptr, ptr %l0, !tbaa !29
  store ptr %t195, ptr %l106, !tbaa !29
  %t196 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t196, ptr %l107
  %t197 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t197, ptr %l108, !tbaa !23
  %t198 = load i1, ptr %l4, !tbaa !21
  br i1 %t198, label %bb56, label %bb57
bb56:
  store i64 1, ptr %l110, !tbaa !24
  br label %bb58
bb57:
  store i64 0, ptr %l110, !tbaa !24
  br label %bb58
bb58:
  %t200 = load ptr, ptr %l106, !tbaa !29
  %t201 = load %"compiler/source:Span", ptr %l107
  %t202 = load i32, ptr %l108, !tbaa !23
  %t203 = load i64, ptr %l110, !tbaa !24
  %t204 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t200, %"compiler/source:Span" %t201, i32 %t202, i64 %t203)
  store ptr %t204, ptr %l111
  br label %bb59
bb59:
  call void @__olang_scope_close(ptr %s8)
  %t205 = load ptr, ptr %l111, !tbaa !29
  store ptr %t205, ptr %rv
  br label %ret
bb60:
  %t206 = load ptr, ptr %l0, !tbaa !29
  store ptr %t206, ptr %l112, !tbaa !29
  %t207 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t207, ptr %l113
  %t208 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t208, ptr %l114, !tbaa !23
  store i32 13, ptr %l115
  %t209 = load ptr, ptr %l7, !tbaa !29
  store ptr %t209, ptr %l116, !tbaa !29
  %t210 = load ptr, ptr %l0, !tbaa !29
  %t211 = load %"compiler/source:Span", ptr %l1
  %t212 = load i32, ptr %l8, !tbaa !23
  %t216 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t210, %"compiler/source:Span" %t211, i32 %t212, i64 0)
  store ptr %t216, ptr %l120
  br label %bb61
bb61:
  %t217 = load ptr, ptr %l120, !tbaa !29
  %t218 = load ptr, ptr %l112, !tbaa !29
  %t219 = load %"compiler/source:Span", ptr %l113
  %t220 = load i32, ptr %l114, !tbaa !23
  %t221 = load i32, ptr %l115
  %t222 = load ptr, ptr %l116, !tbaa !29
  %t224 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %t218, %"compiler/source:Span" %t219, i32 %t220, i32 %t221, ptr %t222, ptr %t217)
  store ptr %t224, ptr %l122
  br label %bb62
bb62:
  %t225 = load ptr, ptr %l122, !tbaa !29
  store ptr %t225, ptr %l9, !tbaa !29
  %t226 = load i1, ptr %l4, !tbaa !21
  br i1 %t226, label %bb63, label %bb64
bb63:
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t229 = load %"compiler/source:Span", ptr %l1
  %t230 = load ptr, ptr %l9, !tbaa !29
  %t234 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enegate(ptr %v0, ptr %t228, %"compiler/source:Span" %t229, ptr %t230)
  store ptr %t234, ptr %l128
  br label %bb65
bb64:
  %t235 = load ptr, ptr %l9, !tbaa !29
  store ptr %t235, ptr %l124, !tbaa !29
  br label %bb66
bb65:
  %t237 = load ptr, ptr %l128, !tbaa !29
  store ptr %t237, ptr %l124, !tbaa !29
  br label %bb66
bb66:
  %t238 = load ptr, ptr %l124, !tbaa !29
  store ptr %t238, ptr %rv
  br label %ret
bb67:
  %t239 = load ptr, ptr %l0, !tbaa !29
  %t240 = load i32, ptr %l8, !tbaa !23
  %t243 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t239, i32 %t240)
  store i1 %t243, ptr %l132
  br label %bb68
bb68:
  %t244 = load i1, ptr %l132, !tbaa !21
  %t245 = xor i1 %t244, true
  br i1 %t245, label %bb69, label %bb70
bb69:
  %t247 = load ptr, ptr %l0, !tbaa !29
  %t249 = getelementptr %"compiler/check:Checker", ptr %t247, i32 0, i32 1
  %t250 = load ptr, ptr %t249, !tbaa !29
  %t252 = getelementptr %"compiler/generic:Program", ptr %t250, i32 0, i32 2
  %t253 = load i32, ptr %l8, !tbaa !23
  %t256 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t252, i32 %t253)
  store i32 %t256, ptr %l139
  br label %bb71
bb70:
  store i1 false, ptr %l134, !tbaa !21
  br label %bb72
bb71:
  %t257 = load i32, ptr %l139
  %t259 = trunc i64 21 to i32
  %t260 = icmp eq i32 %t257, %t259
  %t262 = xor i1 %t260, true
  store i1 %t262, ptr %l134, !tbaa !21
  br label %bb72
bb72:
  %t264 = load i1, ptr %l134, !tbaa !21
  br i1 %t264, label %bb73, label %bb74
bb73:
  store %olang.scope zeroinitializer, ptr %s10
  %t265 = load ptr, ptr %l0, !tbaa !29
  store ptr %t265, ptr %l143, !tbaa !29
  %t266 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t266, ptr %l144
  %t267 = load ptr, ptr %l0, !tbaa !29
  %t268 = load i32, ptr %l8, !tbaa !23
  %t271 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s10, ptr %t267, i32 %t268)
  store { i64, ptr } %t271, ptr %l147
  br label %bb75
bb74:
  br label %bb79
bb75:
  %t272 = load { i64, ptr }, ptr %l147, !tbaa !27
  %t273 = extractvalue { i64, ptr } %t272, 0
  %t274 = extractvalue { i64, ptr } %t272, 1
  %t275 = mul i64 %t273, 1
  %t276 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t275)
  call void @llvm.memcpy.p0.p0.i64(ptr %t276, ptr %t274, i64 %t275, i1 false)
  %t277 = insertvalue { i64, ptr } undef, i64 %t273, 0
  %t278 = insertvalue { i64, ptr } %t277, ptr %t276, 1
  %t280 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eIsNullOfValue(ptr %s10, ptr %s10, { i64, ptr } %t278)
  store %"compiler/msgs:Msg" %t280, ptr %l149
  br label %bb76
bb76:
  %t281 = load ptr, ptr %l143, !tbaa !29
  %t282 = load %"compiler/source:Span", ptr %l144
  %t283 = load %"compiler/msgs:Msg", ptr %l149
  %t284 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s10, ptr %t281, %"compiler/source:Span" %t282, %"compiler/msgs:Msg" %t283)
  store i64 %t284, ptr %l150
  br label %bb77
bb77:
  %t285 = load ptr, ptr %l0, !tbaa !29
  %t286 = load %"compiler/source:Span", ptr %l1
  %t287 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t291 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t285, %"compiler/source:Span" %t286, i32 %t287, i64 0)
  store ptr %t291, ptr %l154
  br label %bb78
bb78:
  call void @__olang_scope_close(ptr %s10)
  %t292 = load ptr, ptr %l154, !tbaa !29
  store ptr %t292, ptr %rv
  br label %ret
bb79:
  %t293 = load ptr, ptr %l0, !tbaa !29
  %t295 = getelementptr %"compiler/check:Checker", ptr %t293, i32 0, i32 1
  %t296 = load ptr, ptr %t295, !tbaa !29
  %t298 = getelementptr %"compiler/generic:Program", ptr %t296, i32 0, i32 2
  %t299 = load i32, ptr %l8, !tbaa !23
  %t302 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArrayRef(ptr %v0, ptr %t298, i32 %t299)
  store i1 %t302, ptr %l159
  br label %bb80
bb80:
  %t303 = load i1, ptr %l159, !tbaa !21
  br i1 %t303, label %bb81, label %bb82
bb81:
  store %olang.scope zeroinitializer, ptr %s11
  %t304 = load ptr, ptr %l0, !tbaa !29
  store ptr %t304, ptr %l160, !tbaa !29
  %t305 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t305, ptr %l161
  %t306 = load ptr, ptr %l0, !tbaa !29
  store ptr %t306, ptr %l162, !tbaa !29
  %t307 = load ptr, ptr %l2, !tbaa !29
  %t309 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t307)
  store %"compiler/source:Span" %t309, ptr %l164
  br label %bb83
bb82:
  br label %bb94
bb83:
  %t310 = load ptr, ptr %l162, !tbaa !29
  %t311 = load %"compiler/source:Span", ptr %l164
  %t312 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %t310, %"compiler/source:Span" %t311)
  store { i64, ptr } %t312, ptr %l165
  br label %bb84
bb84:
  %t313 = load i1, ptr %l4, !tbaa !21
  br i1 %t313, label %bb85, label %bb86
bb85:
  store { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d25, i32 0, i32 1) }, ptr %l167, !tbaa !27
  br label %bb87
bb86:
  store { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d26, i32 0, i32 1) }, ptr %l167, !tbaa !27
  br label %bb87
bb87:
  %t315 = load { i64, ptr }, ptr %l165, !tbaa !27
  %t316 = load { i64, ptr }, ptr %l167, !tbaa !27
  %t317 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eArrayIsNull(ptr %v0, ptr %s11, ptr %s11, { i64, ptr } %t315, { i64, ptr } %t316)
  store %"compiler/msgs:Msg" %t317, ptr %l168
  br label %bb88
bb88:
  %t318 = load ptr, ptr %l160, !tbaa !29
  %t319 = load %"compiler/source:Span", ptr %l161
  %t320 = load %"compiler/msgs:Msg", ptr %l168
  %t321 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s11, ptr %t318, %"compiler/source:Span" %t319, %"compiler/msgs:Msg" %t320)
  store i64 %t321, ptr %l169
  br label %bb89
bb89:
  %t322 = load ptr, ptr %l0, !tbaa !29
  store ptr %t322, ptr %l170, !tbaa !29
  %t323 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t323, ptr %l171
  %t324 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t324, ptr %l172, !tbaa !23
  %t325 = load i1, ptr %l4, !tbaa !21
  br i1 %t325, label %bb90, label %bb91
bb90:
  store i64 1, ptr %l174, !tbaa !24
  br label %bb92
bb91:
  store i64 0, ptr %l174, !tbaa !24
  br label %bb92
bb92:
  %t327 = load ptr, ptr %l170, !tbaa !29
  %t328 = load %"compiler/source:Span", ptr %l171
  %t329 = load i32, ptr %l172, !tbaa !23
  %t330 = load i64, ptr %l174, !tbaa !24
  %t331 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t327, %"compiler/source:Span" %t328, i32 %t329, i64 %t330)
  store ptr %t331, ptr %l175
  br label %bb93
bb93:
  call void @__olang_scope_close(ptr %s11)
  %t332 = load ptr, ptr %l175, !tbaa !29
  store ptr %t332, ptr %rv
  br label %ret
bb94:
  %t333 = load ptr, ptr %l0, !tbaa !29
  %t334 = load i32, ptr %l8, !tbaa !23
  %t337 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t333, i32 %t334)
  store i1 %t337, ptr %l178
  br label %bb95
bb95:
  %t338 = load i1, ptr %l178, !tbaa !21
  br i1 %t338, label %bb96, label %bb97
bb96:
  %t339 = load ptr, ptr %l0, !tbaa !29
  %t341 = getelementptr %"compiler/check:Checker", ptr %t339, i32 0, i32 1
  %t342 = load ptr, ptr %t341, !tbaa !29
  %t344 = getelementptr %"compiler/generic:Program", ptr %t342, i32 0, i32 2
  %t345 = load i32, ptr %l8, !tbaa !23
  %t348 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %t344, i32 %t345)
  store i1 %t348, ptr %l184
  br label %bb98
bb97:
  store i1 false, ptr %l179, !tbaa !21
  br label %bb99
bb98:
  %t349 = load i1, ptr %l184, !tbaa !21
  %t350 = xor i1 %t349, true
  store i1 %t350, ptr %l179, !tbaa !21
  br label %bb99
bb99:
  %t352 = load i1, ptr %l179, !tbaa !21
  br i1 %t352, label %bb100, label %bb101
bb100:
  store %olang.scope zeroinitializer, ptr %s12
  %t353 = load ptr, ptr %l0, !tbaa !29
  store ptr %t353, ptr %l186, !tbaa !29
  %t354 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t354, ptr %l187
  %t355 = load ptr, ptr %l0, !tbaa !29
  store ptr %t355, ptr %l188, !tbaa !29
  %t356 = load ptr, ptr %l2, !tbaa !29
  %t358 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t356)
  store %"compiler/source:Span" %t358, ptr %l190
  br label %bb102
bb101:
  br label %bb125
bb102:
  %t359 = load ptr, ptr %l188, !tbaa !29
  %t360 = load %"compiler/source:Span", ptr %l190
  %t361 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %t359, %"compiler/source:Span" %t360)
  store { i64, ptr } %t361, ptr %l191
  br label %bb103
bb103:
  %t362 = load ptr, ptr %l0, !tbaa !29
  %t363 = load i32, ptr %l8, !tbaa !23
  %t366 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s12, ptr %t362, i32 %t363)
  store { i64, ptr } %t366, ptr %l194
  br label %bb104
bb104:
  %t367 = load { i64, ptr }, ptr %l194, !tbaa !27
  %t368 = extractvalue { i64, ptr } %t367, 0
  %t369 = extractvalue { i64, ptr } %t367, 1
  %t370 = mul i64 %t368, 1
  %t371 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t370)
  call void @llvm.memcpy.p0.p0.i64(ptr %t371, ptr %t369, i64 %t370, i1 false)
  %t372 = insertvalue { i64, ptr } undef, i64 %t368, 0
  %t373 = insertvalue { i64, ptr } %t372, ptr %t371, 1
  store { i64, ptr } %t373, ptr %l195, !tbaa !27
  %t374 = load i1, ptr %l4, !tbaa !21
  br i1 %t374, label %bb105, label %bb106
bb105:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d27, i32 0, i32 1) }, ptr %l197, !tbaa !27
  br label %bb107
bb106:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d28, i32 0, i32 1) }, ptr %l197, !tbaa !27
  br label %bb107
bb107:
  %t376 = load { i64, ptr }, ptr %l191, !tbaa !27
  %t377 = load { i64, ptr }, ptr %l195, !tbaa !27
  %t378 = load { i64, ptr }, ptr %l197, !tbaa !27
  %t379 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNeverNull(ptr %v0, ptr %s12, ptr %s12, ptr %s12, { i64, ptr } %t376, { i64, ptr } %t377, { i64, ptr } %t378)
  store %"compiler/msgs:Msg" %t379, ptr %l198
  br label %bb108
bb108:
  %t380 = load ptr, ptr %l186, !tbaa !29
  %t381 = load %"compiler/source:Span", ptr %l187
  %t382 = load %"compiler/msgs:Msg", ptr %l198
  %t383 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s12, ptr %t380, %"compiler/source:Span" %t381, %"compiler/msgs:Msg" %t382)
  store i64 %t383, ptr %l199
  br label %bb109
bb109:
  %t384 = load i64, ptr %l199, !tbaa !24
  store i64 %t384, ptr %l10, !tbaa !24
  %t385 = load ptr, ptr %l7, !tbaa !29
  %t387 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v0, ptr %t385)
  store ptr %t387, ptr %l201
  br label %bb110
bb110:
  %t388 = load ptr, ptr %l201, !tbaa !29
  store ptr %t388, ptr %l11, !tbaa !29
  %t389 = load ptr, ptr %l11, !tbaa !29
  %t391 = icmp eq ptr %t389, null
  %t393 = xor i1 %t391, true
  br i1 %t393, label %bb111, label %bb112
bb111:
  %t395 = load ptr, ptr %l0, !tbaa !29
  %t396 = load ptr, ptr %l11, !tbaa !29
  %t399 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplaceAt(ptr %v0, ptr %v0, ptr %t395, ptr %t396)
  store { i64, [3 x i64] } %t399, ptr %l208
  br label %bb113
bb112:
  %t400 = load ptr, ptr %l0, !tbaa !29
  %t401 = load ptr, ptr %l7, !tbaa !29
  %t404 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecalledAt(ptr %v0, ptr %v0, ptr %t400, ptr %t401)
  store { i64, [3 x i64] } %t404, ptr %l211
  br label %bb114
bb113:
  %t405 = load { i64, [3 x i64] }, ptr %l208
  store { i64, [3 x i64] } %t405, ptr %l205
  br label %bb115
bb114:
  %t406 = load { i64, [3 x i64] }, ptr %l211
  store { i64, [3 x i64] } %t406, ptr %l205
  br label %bb115
bb115:
  %t407 = load { i64, [3 x i64] }, ptr %l205
  store { i64, [3 x i64] } %t407, ptr %l12
  %t408 = load { i64, [3 x i64] }, ptr %l12
  %t410 = extractvalue { i64, [3 x i64] } %t408, 0
  %t411 = icmp eq i64 %t410, 0
  %t413 = xor i1 %t411, true
  br i1 %t413, label %bb116, label %bb117
bb116:
  store %olang.scope zeroinitializer, ptr %s13
  %t415 = load ptr, ptr %l0, !tbaa !29
  %t417 = getelementptr %"compiler/check:Checker", ptr %t415, i32 0, i32 1
  %t418 = load ptr, ptr %t417, !tbaa !29
  %t420 = getelementptr %"compiler/generic:Program", ptr %t418, i32 0, i32 0
  %t421 = load ptr, ptr %t420, !tbaa !29
  %t423 = getelementptr %"compiler/load:Loader", ptr %t421, i32 0, i32 4
  %t424 = load ptr, ptr %t423, !tbaa !29
  store ptr %t424, ptr %l218, !tbaa !29
  %t425 = load i64, ptr %l10, !tbaa !24
  store i64 %t425, ptr %l219, !tbaa !24
  %t426 = load { i64, [3 x i64] }, ptr %l12
  store { i64, [3 x i64] } %t426, ptr %l220
  %t427 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteNullableDecl(ptr %s13)
  store %"compiler/msgs:Msg" %t427, ptr %l221
  br label %bb118
bb117:
  br label %bb120
bb118:
  %t428 = load ptr, ptr %l218, !tbaa !29
  %t429 = load i64, ptr %l219, !tbaa !24
  %t430 = load { i64, [3 x i64] }, ptr %l220
  %t431 = load %"compiler/msgs:Msg", ptr %l221
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %s13, ptr %t428, i64 %t429, { i64, [3 x i64] } %t430, %"compiler/msgs:Msg" %t431)
  br label %bb119
bb119:
  call void @__olang_scope_close(ptr %s13)
  br label %bb120
bb120:
  %t432 = load ptr, ptr %l0, !tbaa !29
  store ptr %t432, ptr %l222, !tbaa !29
  %t433 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t433, ptr %l223
  %t434 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t434, ptr %l224, !tbaa !23
  %t435 = load i1, ptr %l4, !tbaa !21
  br i1 %t435, label %bb121, label %bb122
bb121:
  store i64 1, ptr %l226, !tbaa !24
  br label %bb123
bb122:
  store i64 0, ptr %l226, !tbaa !24
  br label %bb123
bb123:
  %t437 = load ptr, ptr %l222, !tbaa !29
  %t438 = load %"compiler/source:Span", ptr %l223
  %t439 = load i32, ptr %l224, !tbaa !23
  %t440 = load i64, ptr %l226, !tbaa !24
  %t441 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t437, %"compiler/source:Span" %t438, i32 %t439, i64 %t440)
  store ptr %t441, ptr %l227
  br label %bb124
bb124:
  call void @__olang_scope_close(ptr %s12)
  %t442 = load ptr, ptr %l227, !tbaa !29
  store ptr %t442, ptr %rv
  br label %ret
bb125:
  %t443 = load ptr, ptr %l0, !tbaa !29
  store ptr %t443, ptr %l228, !tbaa !29
  %t444 = load ptr, ptr %l0, !tbaa !29
  %t445 = load ptr, ptr %l3, !tbaa !29
  %t447 = load i32, ptr %l8, !tbaa !23
  %t451 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v2, ptr %t444, ptr %t445, i32 %t447)
  store ptr %t451, ptr %l233
  br label %bb126
bb126:
  %t452 = load i32, ptr %l8, !tbaa !23
  store i32 %t452, ptr %l234, !tbaa !23
  %t453 = load ptr, ptr %l3, !tbaa !29
  %t455 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t453)
  store %"compiler/source:Span" %t455, ptr %l236
  br label %bb127
bb127:
  %t456 = load ptr, ptr %l228, !tbaa !29
  %t457 = load ptr, ptr %l233, !tbaa !29
  %t458 = load i32, ptr %l234, !tbaa !23
  %t459 = load %"compiler/source:Span", ptr %l236
  %t460 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %t456, ptr %t457, i32 %t458, %"compiler/source:Span" %t459)
  store ptr %t460, ptr %l237
  br label %bb128
bb128:
  %t461 = load ptr, ptr %l237, !tbaa !29
  %t462 = load ptr, ptr %l0, !tbaa !29
  %t463 = load %"compiler/source:Span", ptr %l1
  %t464 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t465 = load ptr, ptr %l7, !tbaa !29
  %t474 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %t462, %"compiler/source:Span" %t463, i32 %t464, i32 19, ptr %t465, ptr %t461)
  store ptr %t474, ptr %l245
  br label %bb129
bb129:
  %t475 = load ptr, ptr %l245, !tbaa !29
  store ptr %t475, ptr %l14, !tbaa !29
  %t476 = load i1, ptr %l4, !tbaa !21
  br i1 %t476, label %bb130, label %bb131
bb130:
  %t478 = load ptr, ptr %l0, !tbaa !29
  %t479 = load %"compiler/source:Span", ptr %l1
  %t480 = load ptr, ptr %l14, !tbaa !29
  %t484 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enegate(ptr %v0, ptr %t478, %"compiler/source:Span" %t479, ptr %t480)
  store ptr %t484, ptr %l251
  br label %bb132
bb131:
  %t485 = load ptr, ptr %l14, !tbaa !29
  store ptr %t485, ptr %l247, !tbaa !29
  br label %bb133
bb132:
  %t487 = load ptr, ptr %l251, !tbaa !29
  store ptr %t487, ptr %l247, !tbaa !29
  br label %bb133
bb133:
  %t488 = load ptr, ptr %l247, !tbaa !29
  store ptr %t488, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLength(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i1
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca %"compiler/check:laneNode"
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca i64
  %l15 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l22 = alloca %"compiler/check:laneNode"
  %l26 = alloca ptr
  %l27 = alloca ptr
  %l28 = alloca %"compiler/source:Span"
  %l30 = alloca i32
  %l32 = alloca ptr
  %l35 = alloca i64
  %l37 = alloca i64
  %l42 = alloca i64
  %l46 = alloca %"compiler/check:laneNode"
  %l50 = alloca i1
  %l53 = alloca i64
  %l57 = alloca i64
  %l58 = alloca i32
  %l61 = alloca ptr
  %l62 = alloca %"compiler/source:Span"
  %l64 = alloca i32
  %l65 = alloca i32
  %l69 = alloca ptr
  %l70 = alloca ptr
  %l77 = alloca i64
  %l84 = alloca %"compiler/source:Span"
  %l86 = alloca i32
  %l87 = alloca i32
  %l88 = alloca i32
  %l92 = alloca { i64, ptr }
  %l100 = alloca i1
  %l103 = alloca i1
  %l105 = alloca ptr
  %l106 = alloca ptr
  %l107 = alloca %"compiler/source:Span"
  %l109 = alloca i32
  %l110 = alloca i64
  %s0 = alloca %olang.scope
  %t146 = alloca { i64, [5 x i64] }, align 8
  %t204 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i64 %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l15
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l15
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l4
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t4 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLeaves(ptr %v0, ptr %s0, ptr %t3, i64 %t4, ptr %l4)
  br label %bb2
bb2:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/check:Checker", ptr %t8, i32 0, i32 39
  %t11 = load i64, ptr %l2, !tbaa !24
  %t14 = call %"compiler/check:laneNode" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alaneNode_3e_2eAt_3ccompiler_2fcheck_3alaneNode_3e(ptr %v0, ptr %s0, ptr %t10, i64 %t11)
  store %"compiler/check:laneNode" %t14, ptr %l22
  br label %bb3
bb3:
  %t15 = getelementptr %"compiler/check:laneNode", ptr %l22, i32 0, i32 9
  %t16 = load i64, ptr %t15, !tbaa !24
  store i64 %t16, ptr %l5, !tbaa !24
  %t18 = load i64, ptr %l5, !tbaa !24
  %t20 = icmp sge i64 %t18, 0
  br i1 %t20, label %bb4, label %bb5
bb4:
  %t22 = load ptr, ptr %l0, !tbaa !29
  store ptr %t22, ptr %l27, !tbaa !29
  %t23 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t23, ptr %l28
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t24)
  store i32 %t26, ptr %l30
  br label %bb6
bb5:
  store ptr null, ptr %l26, !tbaa !29
  br label %bb8
bb6:
  %t27 = load i64, ptr %l5, !tbaa !24
  %t28 = load ptr, ptr %l27, !tbaa !29
  %t29 = load %"compiler/source:Span", ptr %l28
  %t30 = load i32, ptr %l30, !tbaa !23
  %t32 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t28, %"compiler/source:Span" %t29, i32 %t30, i64 %t27)
  store ptr %t32, ptr %l32
  br label %bb7
bb7:
  %t33 = load ptr, ptr %l32, !tbaa !29
  store ptr %t33, ptr %l26, !tbaa !29
  br label %bb8
bb8:
  %t35 = load ptr, ptr %l26, !tbaa !29
  store ptr %t35, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  store ptr %l4, ptr %l8, !tbaa !29
  store i64 0, ptr %l9, !tbaa !24
  br label %bb9
bb9:
  %t37 = load i64, ptr %l9, !tbaa !24
  store i64 %t37, ptr %l35, !tbaa !24
  %t38 = load ptr, ptr %l8, !tbaa !29
  %t40 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t38)
  store i64 %t40, ptr %l37
  br label %bb10
bb10:
  %t41 = load i64, ptr %l35, !tbaa !24
  %t42 = load i64, ptr %l37, !tbaa !24
  %t43 = icmp slt i64 %t41, %t42
  %t45 = xor i1 %t43, true
  br i1 %t45, label %bb11, label %bb12
bb11:
  br label %bb41
bb12:
  br label %bb13
bb13:
  %t47 = load ptr, ptr %l8, !tbaa !29
  %t48 = load i64, ptr %l9, !tbaa !24
  %t51 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t47, i64 %t48)
  store i64 %t51, ptr %l42
  br label %bb14
bb14:
  %t52 = load i64, ptr %l42, !tbaa !24
  store i64 %t52, ptr %l10, !tbaa !24
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/check:Checker", ptr %t53, i32 0, i32 39
  %t56 = load i64, ptr %l10, !tbaa !24
  %t59 = call %"compiler/check:laneNode" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alaneNode_3e_2eAt_3ccompiler_2fcheck_3alaneNode_3e(ptr %v0, ptr %v0, ptr %t55, i64 %t56)
  store %"compiler/check:laneNode" %t59, ptr %l46
  br label %bb15
bb15:
  %t60 = load %"compiler/check:laneNode", ptr %l46
  store %"compiler/check:laneNode" %t60, ptr %l11
  %t61 = getelementptr %"compiler/check:laneNode", ptr %l11, i32 0, i32 0
  %t62 = load i64, ptr %t61, !tbaa !24
  %t63 = load i64, ptr @G_2ecompiler_2fcheck_2eLaneArr, !tbaa !24
  %t66 = icmp ne i64 %t62, %t63
  br i1 %t66, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l50, !tbaa !21
  br label %bb18
bb17:
  %t68 = getelementptr %"compiler/check:laneNode", ptr %l11, i32 0, i32 9
  %t69 = load i64, ptr %t68, !tbaa !24
  %t71 = icmp sge i64 %t69, 0
  store i1 %t71, ptr %l50, !tbaa !21
  br label %bb18
bb18:
  %t73 = load i1, ptr %l50, !tbaa !21
  br i1 %t73, label %bb19, label %bb20
bb19:
  br label %bb40
bb20:
  br label %bb21
bb21:
  %t74 = load ptr, ptr %l3, !tbaa !29
  %t76 = getelementptr %"compiler/check:laneVals", ptr %t74, i32 0, i32 1
  %t77 = load i64, ptr %l10, !tbaa !24
  %t80 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v1, ptr %t76, i64 %t77)
  %t81 = extractvalue { i32, i64 } %t80, 1
  %t82 = extractvalue { i32, i64 } %t80, 0
  store i32 %t82, ptr %l58
  %t83 = icmp ne i32 %t82, 0
  br i1 %t83, label %bb23, label %ok.84, !prof !99
ok.84:
  store i64 %t81, ptr %l57
  br label %bb22
bb22:
  %t85 = load i64, ptr %l57, !tbaa !24
  store i64 %t85, ptr %l53, !tbaa !24
  br label %bb25
bb23:
  br label %bb24
bb24:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l53, !tbaa !24
  br label %bb25
bb25:
  %t86 = load i64, ptr %l53, !tbaa !24
  store i64 %t86, ptr %l12, !tbaa !24
  %t87 = load i64, ptr %l12, !tbaa !24
  %t89 = icmp slt i64 %t87, 0
  br i1 %t89, label %bb26, label %bb27
bb26:
  br label %bb40
bb27:
  br label %bb28
bb28:
  %t91 = load ptr, ptr %l0, !tbaa !29
  store ptr %t91, ptr %l61, !tbaa !29
  %t92 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t92, ptr %l62
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t93)
  store i32 %t95, ptr %l64
  br label %bb29
bb29:
  store i32 22, ptr %l65
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t97 = load %"compiler/source:Span", ptr %l1
  %t98 = load i64, ptr %l12, !tbaa !24
  %t102 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t96, %"compiler/source:Span" %t97, i64 %t98)
  store ptr %t102, ptr %l69
  br label %bb30
bb30:
  %t103 = load ptr, ptr %l61, !tbaa !29
  %t104 = load %"compiler/source:Span", ptr %l62
  %t105 = load i32, ptr %l64, !tbaa !23
  %t106 = load i32, ptr %l65
  %t107 = load ptr, ptr %l69, !tbaa !29
  %t108 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %t103, %"compiler/source:Span" %t104, i32 %t105, i32 %t106, ptr %t107, ptr null)
  store ptr %t108, ptr %l70
  br label %bb31
bb31:
  %t109 = load ptr, ptr %l70, !tbaa !29
  store ptr %t109, ptr %l13, !tbaa !29
  %t110 = load ptr, ptr %l6, !tbaa !29
  %t112 = icmp eq ptr %t110, null
  br i1 %t112, label %bb32, label %bb33
bb32:
  %t114 = load ptr, ptr %l13, !tbaa !29
  store ptr %t114, ptr %l6, !tbaa !29
  br label %bb39
bb33:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"compiler/check:Checker", ptr %t117, i32 0, i32 36
  %t121 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t119)
  store i64 %t121, ptr %l77
  br label %bb34
bb34:
  %t122 = load i64, ptr %l77, !tbaa !24
  store i64 %t122, ptr %l14, !tbaa !24
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"compiler/check:Checker", ptr %t123, i32 0, i32 36
  %t126 = load ptr, ptr %l6, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t125, ptr %t126)
  br label %bb35
bb35:
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t131 = getelementptr %"compiler/check:Checker", ptr %t129, i32 0, i32 36
  %t132 = load ptr, ptr %l13, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t131, ptr %t132)
  br label %bb36
bb36:
  %t135 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t135, ptr %l84
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t138 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t136)
  store i32 %t138, ptr %l86
  br label %bb37
bb37:
  store i32 38, ptr %l87
  store i32 1, ptr %l88
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t141 = getelementptr %"compiler/check:Checker", ptr %t139, i32 0, i32 36
  %t142 = load i64, ptr %l14, !tbaa !24
  %t145 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t141, i64 %t142)
  store { i64, ptr } %t145, ptr %l92
  br label %bb38
bb38:
  store { i64, [5 x i64] } zeroinitializer, ptr %t146
  %t147 = getelementptr { i64, [5 x i64] }, ptr %t146, i32 0, i32 0
  store i64 9, ptr %t147
  %t148 = load %"compiler/source:Span", ptr %l84
  %t149 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } undef, %"compiler/source:Span" %t148, 0
  %t150 = load i32, ptr %l86, !tbaa !23
  %t151 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t149, i32 %t150, 1
  %t152 = load i32, ptr %l87
  %t153 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t151, i32 %t152, 2
  %t154 = load i32, ptr %l88
  %t155 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t153, i32 %t154, 3
  %t156 = load { i64, ptr }, ptr %l92, !tbaa !27
  %t157 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t155, { i64, ptr } %t156, 4
  %t158 = getelementptr { i64, [5 x i64] }, ptr %t146, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t157, ptr %t158
  %t159 = load { i64, [5 x i64] }, ptr %t146
  %t161 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t159, ptr %t161
  store ptr %t161, ptr %l6, !tbaa !29
  store i1 true, ptr %l7, !tbaa !21
  br label %bb39
bb39:
  br label %bb40
bb40:
  %t163 = load i64, ptr %l9, !tbaa !24
  %t165 = add i64 %t163, 1
  store i64 %t165, ptr %l9, !tbaa !24
  br label %bb9
bb41:
  %t167 = load ptr, ptr %l6, !tbaa !29
  %t169 = icmp eq ptr %t167, null
  %t171 = xor i1 %t169, true
  br i1 %t171, label %bb42, label %bb43
bb42:
  %t173 = load i64, ptr %l5, !tbaa !24
  %t175 = icmp slt i64 %t173, 0
  br i1 %t175, label %bb44, label %bb45
bb43:
  store i1 false, ptr %l100, !tbaa !21
  br label %bb47
bb44:
  store i1 true, ptr %l103, !tbaa !21
  br label %bb46
bb45:
  %t177 = load i1, ptr %l7, !tbaa !21
  store i1 %t177, ptr %l103, !tbaa !21
  br label %bb46
bb46:
  %t179 = load i1, ptr %l103, !tbaa !21
  store i1 %t179, ptr %l100, !tbaa !21
  br label %bb47
bb47:
  %t180 = load i1, ptr %l100, !tbaa !21
  br i1 %t180, label %bb48, label %bb49
bb48:
  %t181 = load ptr, ptr %l3, !tbaa !29
  store ptr %t181, ptr %l105, !tbaa !29
  %t182 = load ptr, ptr %l0, !tbaa !29
  store ptr %t182, ptr %l106, !tbaa !29
  %t183 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t183, ptr %l107
  %t184 = load ptr, ptr %l0, !tbaa !29
  %t186 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t184)
  store i32 %t186, ptr %l109
  br label %bb50
bb49:
  br label %bb53
bb50:
  %t187 = load ptr, ptr %l106, !tbaa !29
  %t188 = load %"compiler/source:Span", ptr %l107
  %t189 = load i32, ptr %l109, !tbaa !23
  %t190 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t187, %"compiler/source:Span" %t188, i32 %t189)
  store i64 %t190, ptr %l110
  br label %bb51
bb51:
  %t191 = load i64, ptr %l110, !tbaa !24
  %t192 = load ptr, ptr %l105, !tbaa !29
  %t193 = getelementptr %"compiler/check:laneVals", ptr %t192, i32 0, i32 0
  store i64 %t191, ptr %t193, !tbaa !24
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t195 = load %"compiler/source:Span", ptr %l1
  %t196 = load ptr, ptr %l3, !tbaa !29
  %t198 = getelementptr %"compiler/check:laneVals", ptr %t196, i32 0, i32 0
  %t199 = load i64, ptr %t198, !tbaa !24
  %t201 = trunc i64 %t199 to i32
  %t203 = load ptr, ptr %l6, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t204
  %t205 = getelementptr { i64, [3 x i64] }, ptr %t204, i32 0, i32 0
  store i64 0, ptr %t205
  %t207 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t195, 0
  %t209 = insertvalue { %"compiler/source:Span", i32, ptr } %t207, i32 %t201, 1
  %t211 = insertvalue { %"compiler/source:Span", i32, ptr } %t209, ptr %t203, 2
  %t212 = getelementptr { i64, [3 x i64] }, ptr %t204, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t211, ptr %t212
  %t213 = load { i64, [3 x i64] }, ptr %t204
  %t215 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t213, ptr %t215
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t194, ptr %t215)
  br label %bb52
bb52:
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneTotal(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, { i64, ptr } %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca %"compiler/check:laneNode"
  %l6 = alloca i32
  %l7 = alloca i64
  %lp8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca { i64, i64, i64, i64, i64 }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l18 = alloca i1
  %l19 = alloca i64
  %l20 = alloca { i64, i64, i64, i64, i64 }
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca ptr
  %l27 = alloca i64
  %lp28 = alloca ptr
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca ptr
  %l33 = alloca i64
  %l34 = alloca { i64, i64, i64, i64, i64 }
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca ptr
  %l42 = alloca ptr
  %l43 = alloca i64
  %lp44 = alloca ptr
  %l48 = alloca %"compiler/check:laneNode"
  %l56 = alloca ptr
  %l58 = alloca i1
  %l59 = alloca i1
  %l61 = alloca i1
  %l62 = alloca i1
  %l66 = alloca ptr
  %l67 = alloca %"compiler/source:Span"
  %l70 = alloca { i64, ptr }
  %l73 = alloca { i64, ptr }
  %l75 = alloca %"compiler/msgs:Msg"
  %l76 = alloca i64
  %l79 = alloca ptr
  %l82 = alloca i64
  %l86 = alloca %"compiler/check:laneVals"
  %l91 = alloca ptr
  %l93 = alloca i1
  %l97 = alloca i64
  %l98 = alloca ptr
  %l99 = alloca %"compiler/source:Span"
  %l102 = alloca i32
  %l106 = alloca ptr
  %l112 = alloca { i64, i64, i64, i64, i64 }
  %l118 = alloca ptr
  %l119 = alloca %"compiler/source:Span"
  %l120 = alloca %"compiler/source:Span"
  %l121 = alloca i32
  %l125 = alloca ptr
  %l126 = alloca ptr
  %l127 = alloca %"compiler/source:Span"
  %l128 = alloca i64
  %l129 = alloca ptr
  %l133 = alloca ptr
  %l134 = alloca ptr
  %l137 = alloca ptr
  %l138 = alloca ptr
  %l139 = alloca %"compiler/source:Span"
  %l146 = alloca ptr
  %l151 = alloca ptr
  %l161 = alloca %"compiler/source:Span"
  %l162 = alloca i32
  %l166 = alloca { i64, ptr }
  %l170 = alloca ptr
  %l172 = alloca %"compiler/typed:Seq"
  %l177 = alloca i1
  %l178 = alloca i1
  %l180 = alloca i1
  %l182 = alloca i1
  %l186 = alloca i64
  %l187 = alloca ptr
  %l188 = alloca %"compiler/source:Span"
  %l191 = alloca i32
  %l192 = alloca ptr
  %l193 = alloca %"compiler/source:Span"
  %l194 = alloca i32
  %l196 = alloca i64
  %l197 = alloca ptr
  %l203 = alloca { i64, i64, i64, i64, i64 }
  %l209 = alloca ptr
  %l210 = alloca %"compiler/source:Span"
  %l211 = alloca i64
  %l212 = alloca ptr
  %l216 = alloca ptr
  %l217 = alloca ptr
  %l220 = alloca i64
  %l222 = alloca ptr
  %l223 = alloca %"compiler/source:Span"
  %l230 = alloca ptr
  %l231 = alloca ptr
  %l232 = alloca %"compiler/source:Span"
  %l233 = alloca i32
  %l235 = alloca i64
  %l236 = alloca ptr
  %l249 = alloca ptr
  %l253 = alloca i32
  %l257 = alloca { i64, ptr }
  %l258 = alloca %"compiler/typed:Block"
  %l259 = alloca ptr
  %l260 = alloca %"compiler/source:Span"
  %l262 = alloca ptr
  %l267 = alloca ptr
  %l269 = alloca %"compiler/typed:If"
  %l280 = alloca %"compiler/source:Span"
  %l281 = alloca i32
  %l285 = alloca { i64, ptr }
  %l289 = alloca ptr
  %l291 = alloca %"compiler/typed:Seq"
  %l295 = alloca ptr
  %l297 = alloca i32
  %l298 = alloca { i64, ptr }
  %l300 = alloca i32
  %l301 = alloca ptr
  %l302 = alloca %"compiler/source:Span"
  %l303 = alloca %"compiler/source:Span"
  %l304 = alloca i32
  %l305 = alloca i32
  %l306 = alloca i32
  %l309 = alloca { i64, ptr }
  %l314 = alloca ptr
  %l315 = alloca %"compiler/source:Span"
  %l317 = alloca i32
  %l318 = alloca i64
  %l319 = alloca ptr
  %l320 = alloca %"compiler/source:Span"
  %l323 = alloca i32
  %l324 = alloca ptr
  %l325 = alloca %"compiler/source:Span"
  %l327 = alloca i32
  %l328 = alloca ptr
  %l335 = alloca i64
  %l336 = alloca ptr
  %l337 = alloca %"compiler/source:Span"
  %l338 = alloca i64
  %l339 = alloca ptr
  %l343 = alloca ptr
  %l344 = alloca ptr
  %l357 = alloca i64
  %l358 = alloca ptr
  %l359 = alloca %"compiler/source:Span"
  %l362 = alloca i32
  %l367 = alloca ptr
  %l370 = alloca ptr
  %l371 = alloca %"compiler/source:Span"
  %l376 = alloca ptr
  %l377 = alloca { i64, i64, i64, i64, i64 }
  %l386 = alloca i64
  %l387 = alloca ptr
  %l388 = alloca %"compiler/source:Span"
  %l391 = alloca i32
  %l392 = alloca ptr
  %l393 = alloca ptr
  %l394 = alloca %"compiler/source:Span"
  %l395 = alloca i64
  %l396 = alloca ptr
  %l400 = alloca ptr
  %l401 = alloca ptr
  %l404 = alloca ptr
  %l408 = alloca i1
  %l409 = alloca ptr
  %l410 = alloca ptr
  %l411 = alloca %"compiler/source:Span"
  %l412 = alloca %"compiler/source:Span"
  %l413 = alloca i32
  %l417 = alloca ptr
  %l421 = alloca ptr
  %l424 = alloca ptr
  %l425 = alloca ptr
  %l426 = alloca %"compiler/source:Span"
  %l427 = alloca %"compiler/source:Span"
  %l428 = alloca i32
  %l432 = alloca ptr
  %l436 = alloca ptr
  %l439 = alloca ptr
  %l442 = alloca ptr
  %l445 = alloca i32
  %l446 = alloca i1
  %l447 = alloca ptr
  %l448 = alloca %"compiler/source:Span"
  %l449 = alloca i32
  %l450 = alloca i32
  %l454 = alloca ptr
  %l458 = alloca ptr
  %l460 = alloca ptr
  %l461 = alloca %"compiler/source:Span"
  %l462 = alloca i32
  %l463 = alloca ptr
  %l467 = alloca ptr
  %l470 = alloca %"compiler/typed:Cond"
  %l476 = alloca i64
  %l478 = alloca ptr
  %l479 = alloca %"compiler/source:Span"
  %l486 = alloca ptr
  %l490 = alloca ptr
  %l494 = alloca ptr
  %l498 = alloca i32
  %l502 = alloca { i64, ptr }
  %l503 = alloca %"compiler/typed:Block"
  %l504 = alloca ptr
  %l505 = alloca %"compiler/source:Span"
  %l508 = alloca %"compiler/typed:If"
  %l519 = alloca %"compiler/source:Span"
  %l520 = alloca i32
  %l524 = alloca { i64, ptr }
  %l528 = alloca ptr
  %l530 = alloca %"compiler/typed:Seq"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca ptr
  %t142 = alloca { i64, [3 x i64] }, align 8
  %t226 = alloca { i64, [4 x i64] }, align 8
  %t247 = alloca { i64, [3 x i64] }, align 8
  %t297 = alloca { i64, [5 x i64] }, align 8
  %t347 = alloca { i64, [3 x i64] }, align 8
  %t418 = alloca { i64, [4 x i64] }, align 8
  %t440 = alloca { i64, [3 x i64] }, align 8
  %t462 = alloca { i64, [3 x i64] }, align 8
  %t519 = alloca { i64, [3 x i64] }, align 8
  %t567 = alloca { i64, [5 x i64] }, align 8
  %t608 = alloca { i64, [5 x i64] }, align 8
  %t624 = alloca { i64, [3 x i64] }, align 8
  %t661 = alloca { i64, [3 x i64] }, align 8
  %t753 = alloca { i64, [3 x i64] }, align 8
  %t837 = alloca { i64, [3 x i64] }, align 8
  %t973 = alloca { i64, [5 x i64] }, align 8
  %t1002 = alloca { i64, [4 x i64] }, align 8
  %t1021 = alloca { i64, [3 x i64] }, align 8
  %t1067 = alloca { i64, [3 x i64] }, align 8
  %t1115 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  store i64 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 39
  %t4 = load i64, ptr %l4, !tbaa !24
  %t7 = call %"compiler/check:laneNode" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alaneNode_3e_2eAt_3ccompiler_2fcheck_3alaneNode_3e(ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  store %"compiler/check:laneNode" %t7, ptr %l48
  br label %bb1
bb1:
  %t8 = load %"compiler/check:laneNode", ptr %l48
  store %"compiler/check:laneNode" %t8, ptr %l5
  %t9 = getelementptr %"compiler/check:laneNode", ptr %l5, i32 0, i32 8
  %t10 = load i32, ptr %t9, !tbaa !23
  store i32 %t10, ptr %l6, !tbaa !23
  %t12 = load i32, ptr %l6, !tbaa !23
  %t13 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t16 = icmp eq i32 %t12, %t13
  br i1 %t16, label %bb2, label %bb3
bb2:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load %"compiler/source:Span", ptr %l1
  %t20 = load i64, ptr %l4, !tbaa !24
  %t24 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneSay(ptr %v0, ptr %t18, %"compiler/source:Span" %t19, i64 %t20)
  store ptr %t24, ptr %l56
  br label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_scope_close(ptr %s0)
  %t25 = load ptr, ptr %l56, !tbaa !29
  store ptr %t25, ptr %rv
  br label %ret
bb5:
  %t26 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t28 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t26, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d29, i32 0, i32 1) })
  store i1 %t28, ptr %l58
  br label %bb6
bb6:
  %t29 = load i1, ptr %l58, !tbaa !21
  br i1 %t29, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l59, !tbaa !21
  br label %bb10
bb8:
  %t30 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t32 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t30, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d30, i32 0, i32 1) })
  store i1 %t32, ptr %l61
  br label %bb9
bb9:
  %t33 = load i1, ptr %l61, !tbaa !21
  store i1 %t33, ptr %l59, !tbaa !21
  br label %bb10
bb10:
  %t34 = load i1, ptr %l59, !tbaa !21
  br i1 %t34, label %bb11, label %bb12
bb11:
  %t35 = load i32, ptr %l6, !tbaa !23
  %t36 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t39 = icmp ne i32 %t35, %t36
  store i1 %t39, ptr %l62, !tbaa !21
  br label %bb13
bb12:
  store i1 false, ptr %l62, !tbaa !21
  br label %bb13
bb13:
  %t41 = load i1, ptr %l62, !tbaa !21
  br i1 %t41, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s2
  %t42 = load ptr, ptr %l0, !tbaa !29
  store ptr %t42, ptr %l66, !tbaa !29
  %t43 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t43, ptr %l67
  %t44 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t45 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d31, i32 0, i32 1) }, 1
  %t46 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d31, i32 0, i32 1) }, 0
  %t48 = extractvalue { i64, ptr } %t44, 1
  %t49 = extractvalue { i64, ptr } %t44, 0
  %t50 = add i64 %t46, %t49
  %t51 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d32, i32 0, i32 1) }, 1
  %t52 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d32, i32 0, i32 1) }, 0
  %t53 = add i64 %t50, %t52
  %t54 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t53)
  call void @olang_textcopy(ptr %t54, ptr %t45, i64 %t46)
  %t55 = getelementptr i8, ptr %t54, i64 %t46
  call void @olang_textcopy(ptr %t55, ptr %t48, i64 %t49)
  %t56 = getelementptr i8, ptr %t55, i64 %t49
  call void @olang_textcopy(ptr %t56, ptr %t51, i64 %t52)
  %t57 = insertvalue { i64, ptr } undef, i64 %t53, 0
  %t58 = insertvalue { i64, ptr } %t57, ptr %t54, 1
  %t60 = extractvalue { i64, ptr } %t58, 0
  %t61 = extractvalue { i64, ptr } %t58, 1
  %t62 = mul i64 %t60, 1
  %t63 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t62)
  call void @llvm.memcpy.p0.p0.i64(ptr %t63, ptr %t61, i64 %t62, i1 false)
  %t64 = insertvalue { i64, ptr } undef, i64 %t60, 0
  %t65 = insertvalue { i64, ptr } %t64, ptr %t63, 1
  store { i64, ptr } %t65, ptr %l70, !tbaa !27
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load i32, ptr %l6, !tbaa !23
  %t70 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s2, ptr %t66, i32 %t67)
  store { i64, ptr } %t70, ptr %l73
  br label %bb16
bb15:
  br label %bb20
bb16:
  %t71 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t72 = extractvalue { i64, ptr } %t71, 0
  %t73 = extractvalue { i64, ptr } %t71, 1
  %t74 = mul i64 %t72, 1
  %t75 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t74)
  call void @llvm.memcpy.p0.p0.i64(ptr %t75, ptr %t73, i64 %t74, i1 false)
  %t76 = insertvalue { i64, ptr } undef, i64 %t72, 0
  %t77 = insertvalue { i64, ptr } %t76, ptr %t75, 1
  %t78 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t80 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eLaneMaskBool(ptr %s2, ptr %s2, ptr %s2, { i64, ptr } %t78, { i64, ptr } %t77)
  store %"compiler/msgs:Msg" %t80, ptr %l75
  br label %bb17
bb17:
  %t81 = load ptr, ptr %l66, !tbaa !29
  %t82 = load %"compiler/source:Span", ptr %l67
  %t83 = load %"compiler/msgs:Msg", ptr %l75
  %t84 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s2, ptr %t81, %"compiler/source:Span" %t82, %"compiler/msgs:Msg" %t83)
  store i64 %t84, ptr %l76
  br label %bb18
bb18:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = load %"compiler/source:Span", ptr %l1
  %t89 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t85, %"compiler/source:Span" %t86)
  store ptr %t89, ptr %l79
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t90 = load ptr, ptr %l79, !tbaa !29
  store ptr %t90, ptr %rv
  br label %ret
bb20:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"compiler/check:Checker", ptr %t91, i32 0, i32 37
  %t95 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t93)
  store i64 %t95, ptr %l82
  br label %bb21
bb21:
  %t96 = load i64, ptr %l82, !tbaa !24
  store i64 %t96, ptr %l7, !tbaa !24
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t98 = load %"compiler/source:Span", ptr %l1
  %t99 = load i64, ptr %l4, !tbaa !24
  %t103 = call %"compiler/check:laneVals" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneSetup(ptr %v0, ptr %v0, ptr %t97, %"compiler/source:Span" %t98, i64 %t99)
  store %"compiler/check:laneVals" %t103, ptr %l86
  br label %bb22
bb22:
  %t104 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store ptr %t104, ptr %lp8
  %t105 = load %"compiler/check:laneVals", ptr %l86
  %t106 = load ptr, ptr %lp8
  store %"compiler/check:laneVals" %t105, ptr %t106
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t108 = load %"compiler/source:Span", ptr %l1
  %t109 = load i64, ptr %l4, !tbaa !24
  %t110 = load ptr, ptr %lp8
  %t115 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneCount(ptr %v0, ptr %v0, ptr %t107, %"compiler/source:Span" %t108, i64 %t109, ptr %t110)
  store ptr %t115, ptr %l91
  br label %bb23
bb23:
  %t116 = load ptr, ptr %l91, !tbaa !29
  store ptr %t116, ptr %l9, !tbaa !29
  %t117 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t119 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t117, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d33, i32 0, i32 1) })
  store i1 %t119, ptr %l93
  br label %bb24
bb24:
  %t120 = load i1, ptr %l93, !tbaa !21
  br i1 %t120, label %bb25, label %bb26
bb25:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t122 = load %"compiler/source:Span", ptr %l1
  %t123 = load i32, ptr %l6, !tbaa !23
  %t127 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t121, %"compiler/source:Span" %t122, i32 %t123)
  store i64 %t127, ptr %l97
  br label %bb27
bb26:
  br label %bb41
bb27:
  %t128 = load i64, ptr %l97, !tbaa !24
  store i64 %t128, ptr %l10, !tbaa !24
  %t129 = load ptr, ptr %l0, !tbaa !29
  store ptr %t129, ptr %l98, !tbaa !29
  %t130 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t130, ptr %l99
  %t131 = load i64, ptr %l10, !tbaa !24
  %t133 = trunc i64 %t131 to i32
  store i32 %t133, ptr %l102, !tbaa !23
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t136 = load %"compiler/source:Span", ptr %l1
  %t137 = load i32, ptr %l6, !tbaa !23
  %t141 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ezero(ptr %v0, ptr %t135, %"compiler/source:Span" %t136, i32 %t137)
  store ptr %t141, ptr %l106
  br label %bb28
bb28:
  store { i64, [3 x i64] } zeroinitializer, ptr %t142
  %t143 = getelementptr { i64, [3 x i64] }, ptr %t142, i32 0, i32 0
  store i64 0, ptr %t143
  %t144 = load %"compiler/source:Span", ptr %l99
  %t145 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t144, 0
  %t146 = load i32, ptr %l102, !tbaa !23
  %t147 = insertvalue { %"compiler/source:Span", i32, ptr } %t145, i32 %t146, 1
  %t148 = load ptr, ptr %l106, !tbaa !29
  %t149 = insertvalue { %"compiler/source:Span", i32, ptr } %t147, ptr %t148, 2
  %t150 = getelementptr { i64, [3 x i64] }, ptr %t142, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t149, ptr %t150
  %t151 = load { i64, [3 x i64] }, ptr %t142
  %t153 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t151, ptr %t153
  %t154 = load ptr, ptr %l98, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t154, ptr %t153)
  br label %bb29
bb29:
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t157 = load %"compiler/source:Span", ptr %l1
  %t158 = load ptr, ptr %l9, !tbaa !29
  %t162 = call { i64, i64, i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLoopOpen(ptr %v0, ptr %t156, %"compiler/source:Span" %t157, ptr %t158, i64 0)
  store { i64, i64, i64, i64, i64 } %t162, ptr %l112
  br label %bb30
bb30:
  %t163 = load { i64, i64, i64, i64, i64 }, ptr %l112
  store { i64, i64, i64, i64, i64 } %t163, ptr %l11
  %t164 = getelementptr { i64, i64, i64, i64, i64 }, ptr %l11, i32 0, i32 0
  %t165 = load i64, ptr %t164, !tbaa !24
  store i64 %t165, ptr %l12, !tbaa !24
  %t167 = getelementptr { i64, i64, i64, i64, i64 }, ptr %l11, i32 0, i32 1
  %t168 = load i64, ptr %t167, !tbaa !24
  store i64 %t168, ptr %l13, !tbaa !24
  %t170 = getelementptr { i64, i64, i64, i64, i64 }, ptr %l11, i32 0, i32 2
  %t171 = load i64, ptr %t170, !tbaa !24
  store i64 %t171, ptr %l14, !tbaa !24
  %t173 = getelementptr { i64, i64, i64, i64, i64 }, ptr %l11, i32 0, i32 3
  %t174 = load i64, ptr %t173, !tbaa !24
  store i64 %t174, ptr %l15, !tbaa !24
  %t176 = getelementptr { i64, i64, i64, i64, i64 }, ptr %l11, i32 0, i32 4
  %t177 = load i64, ptr %t176, !tbaa !24
  store i64 %t177, ptr %l16, !tbaa !24
  %t179 = load ptr, ptr %l0, !tbaa !29
  store ptr %t179, ptr %l118, !tbaa !29
  %t180 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t180, ptr %l119
  %t181 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t181, ptr %l120
  store i32 52, ptr %l121
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t183 = load %"compiler/source:Span", ptr %l1
  %t184 = load i64, ptr %l10, !tbaa !24
  %t188 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t182, %"compiler/source:Span" %t183, i64 %t184)
  store ptr %t188, ptr %l125
  br label %bb31
bb31:
  %t189 = load ptr, ptr %l0, !tbaa !29
  store ptr %t189, ptr %l126, !tbaa !29
  %t190 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t190, ptr %l127
  %t191 = load i64, ptr %l4, !tbaa !24
  store i64 %t191, ptr %l128, !tbaa !24
  %t192 = load ptr, ptr %lp8
  store ptr %t192, ptr %l129, !tbaa !29
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t194 = load %"compiler/source:Span", ptr %l1
  %t195 = load i64, ptr %l12, !tbaa !24
  %t199 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t193, %"compiler/source:Span" %t194, i64 %t195)
  store ptr %t199, ptr %l133
  br label %bb32
bb32:
  %t200 = load ptr, ptr %l126, !tbaa !29
  %t201 = load %"compiler/source:Span", ptr %l127
  %t202 = load i64, ptr %l128, !tbaa !24
  %t203 = load ptr, ptr %l129, !tbaa !29
  %t204 = load ptr, ptr %l133, !tbaa !29
  %t205 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneElem(ptr %v0, ptr %v0, ptr %t200, %"compiler/source:Span" %t201, i64 %t202, ptr %t203, ptr %t204)
  store ptr %t205, ptr %l134
  br label %bb33
bb33:
  %t206 = load %"compiler/source:Span", ptr %l1
  %t207 = load %"compiler/source:Span", ptr %l1
  %t208 = load ptr, ptr %l118, !tbaa !29
  %t209 = load %"compiler/source:Span", ptr %l119
  %t210 = load %"compiler/source:Span", ptr %l120
  %t211 = load i32, ptr %l121
  %t212 = load ptr, ptr %l125, !tbaa !29
  %t213 = load ptr, ptr %l134, !tbaa !29
  %t216 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopValues(ptr %v0, ptr %t208, %"compiler/source:Span" %t209, %"compiler/source:Span" %t210, i32 %t211, ptr %t212, ptr %t213, %"compiler/source:Span" %t206, %"compiler/source:Span" %t207)
  store ptr %t216, ptr %l137
  br label %bb34
bb34:
  %t217 = load ptr, ptr %l137, !tbaa !29
  %t218 = load ptr, ptr %l0, !tbaa !29
  store ptr %t218, ptr %l138, !tbaa !29
  %t219 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t219, ptr %l139
  %t220 = load %"compiler/source:Span", ptr %l1
  %t221 = load i32, ptr %l6, !tbaa !23
  %t222 = load i64, ptr %l10, !tbaa !24
  %t224 = trunc i64 %t222 to i32
  store { i64, [4 x i64] } zeroinitializer, ptr %t226
  %t227 = getelementptr { i64, [4 x i64] }, ptr %t226, i32 0, i32 0
  store i64 0, ptr %t227
  %t229 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t220, 0
  %t231 = insertvalue { %"compiler/source:Span", i32, i32 } %t229, i32 %t221, 1
  %t233 = insertvalue { %"compiler/source:Span", i32, i32 } %t231, i32 %t224, 2
  %t234 = getelementptr { i64, [4 x i64] }, ptr %t226, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t233, ptr %t234
  %t235 = load { i64, [4 x i64] }, ptr %t226
  %t237 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t235, ptr %t237
  store ptr %t237, ptr %l146, !tbaa !29
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t240 = load i32, ptr %l6, !tbaa !23
  %t241 = load %"compiler/source:Span", ptr %l1
  %t246 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %t238, ptr %t217, i32 %t240, %"compiler/source:Span" %t241)
  store ptr %t246, ptr %l151
  br label %bb35
bb35:
  store { i64, [3 x i64] } zeroinitializer, ptr %t247
  %t248 = getelementptr { i64, [3 x i64] }, ptr %t247, i32 0, i32 0
  store i64 1, ptr %t248
  %t249 = load %"compiler/source:Span", ptr %l139
  %t250 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t249, 0
  %t251 = load ptr, ptr %l146, !tbaa !29
  %t252 = insertvalue { %"compiler/source:Span", ptr, ptr } %t250, ptr %t251, 1
  %t253 = load ptr, ptr %l151, !tbaa !29
  %t254 = insertvalue { %"compiler/source:Span", ptr, ptr } %t252, ptr %t253, 2
  %t255 = getelementptr { i64, [3 x i64] }, ptr %t247, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t254, ptr %t255
  %t256 = load { i64, [3 x i64] }, ptr %t247
  %t258 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t256, ptr %t258
  %t259 = load ptr, ptr %l138, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t259, ptr %t258)
  br label %bb36
bb36:
  %t261 = load ptr, ptr %l0, !tbaa !29
  %t262 = load %"compiler/source:Span", ptr %l1
  %t263 = load i64, ptr %l12, !tbaa !24
  %t264 = load i64, ptr %l13, !tbaa !24
  %t265 = load i64, ptr %l14, !tbaa !24
  %t266 = load i64, ptr %l15, !tbaa !24
  %t267 = load i64, ptr %l16, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLoopClose(ptr %v0, ptr %t261, %"compiler/source:Span" %t262, i64 %t263, i64 %t264, i64 %t265, i64 %t266, i64 %t267)
  br label %bb37
bb37:
  %t275 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t275, ptr %l161
  %t276 = load i32, ptr %l6, !tbaa !23
  store i32 %t276, ptr %l162, !tbaa !23
  %t277 = load ptr, ptr %l0, !tbaa !29
  %t279 = getelementptr %"compiler/check:Checker", ptr %t277, i32 0, i32 37
  %t280 = load i64, ptr %l7, !tbaa !24
  %t283 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t279, i64 %t280)
  store { i64, ptr } %t283, ptr %l166
  br label %bb38
bb38:
  %t284 = load ptr, ptr %l0, !tbaa !29
  %t285 = load %"compiler/source:Span", ptr %l1
  %t286 = load i64, ptr %l10, !tbaa !24
  %t290 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t284, %"compiler/source:Span" %t285, i64 %t286)
  store ptr %t290, ptr %l170
  br label %bb39
bb39:
  %t291 = load ptr, ptr %l170, !tbaa !29
  %t292 = load { i64, ptr }, ptr %l166, !tbaa !27
  %t294 = call %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t292, ptr %t291)
  store %"compiler/typed:Seq" %t294, ptr %l172
  br label %bb40
bb40:
  %t295 = load %"compiler/typed:Seq", ptr %l172
  %t296 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Seq" %t295, ptr %t296
  store { i64, [5 x i64] } zeroinitializer, ptr %t297
  %t298 = getelementptr { i64, [5 x i64] }, ptr %t297, i32 0, i32 0
  store i64 12, ptr %t298
  %t299 = load %"compiler/source:Span", ptr %l161
  %t300 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t299, 0
  %t301 = load i32, ptr %l162, !tbaa !23
  %t302 = insertvalue { %"compiler/source:Span", i32, ptr } %t300, i32 %t301, 1
  %t304 = insertvalue { %"compiler/source:Span", i32, ptr } %t302, ptr %t296, 2
  %t305 = getelementptr { i64, [5 x i64] }, ptr %t297, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t304, ptr %t305
  %t306 = load { i64, [5 x i64] }, ptr %t297
  %t308 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t306, ptr %t308
  call void @__olang_scope_close(ptr %s0)
  store ptr %t308, ptr %rv
  br label %ret
bb41:
  %t310 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t312 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t310, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d34, i32 0, i32 1) })
  store i1 %t312, ptr %l177
  br label %bb42
bb42:
  %t313 = load i1, ptr %l177, !tbaa !21
  br i1 %t313, label %bb43, label %bb44
bb43:
  store i1 true, ptr %l178, !tbaa !21
  br label %bb46
bb44:
  %t314 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t316 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t314, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d35, i32 0, i32 1) })
  store i1 %t316, ptr %l180
  br label %bb45
bb45:
  %t317 = load i1, ptr %l180, !tbaa !21
  store i1 %t317, ptr %l178, !tbaa !21
  br label %bb46
bb46:
  %t318 = load i1, ptr %l178, !tbaa !21
  br i1 %t318, label %bb47, label %bb48
bb47:
  store %olang.scope zeroinitializer, ptr %s5
  %t319 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t321 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s5, { i64, ptr } %t319, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d36, i32 0, i32 1) })
  store i1 %t321, ptr %l182
  br label %bb49
bb48:
  br label %bb79
bb49:
  %t322 = load i1, ptr %l182, !tbaa !21
  store i1 %t322, ptr %l18, !tbaa !21
  %t323 = load ptr, ptr %l0, !tbaa !29
  %t324 = load %"compiler/source:Span", ptr %l1
  %t325 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t329 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t323, %"compiler/source:Span" %t324, i32 %t325)
  store i64 %t329, ptr %l186
  br label %bb50
bb50:
  %t330 = load i64, ptr %l186, !tbaa !24
  store i64 %t330, ptr %l19, !tbaa !24
  %t331 = load ptr, ptr %l0, !tbaa !29
  store ptr %t331, ptr %l187, !tbaa !29
  %t332 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t332, ptr %l188
  %t333 = load i64, ptr %l19, !tbaa !24
  %t335 = trunc i64 %t333 to i32
  store i32 %t335, ptr %l191, !tbaa !23
  %t337 = load ptr, ptr %l0, !tbaa !29
  store ptr %t337, ptr %l192, !tbaa !29
  %t338 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t338, ptr %l193
  %t339 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t339, ptr %l194, !tbaa !23
  %t340 = load i1, ptr %l18, !tbaa !21
  br i1 %t340, label %bb51, label %bb52
bb51:
  store i64 0, ptr %l196, !tbaa !24
  br label %bb53
bb52:
  store i64 1, ptr %l196, !tbaa !24
  br label %bb53
bb53:
  %t342 = load ptr, ptr %l192, !tbaa !29
  %t343 = load %"compiler/source:Span", ptr %l193
  %t344 = load i32, ptr %l194, !tbaa !23
  %t345 = load i64, ptr %l196, !tbaa !24
  %t346 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t342, %"compiler/source:Span" %t343, i32 %t344, i64 %t345)
  store ptr %t346, ptr %l197
  br label %bb54
bb54:
  store { i64, [3 x i64] } zeroinitializer, ptr %t347
  %t348 = getelementptr { i64, [3 x i64] }, ptr %t347, i32 0, i32 0
  store i64 0, ptr %t348
  %t349 = load %"compiler/source:Span", ptr %l188
  %t350 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t349, 0
  %t351 = load i32, ptr %l191, !tbaa !23
  %t352 = insertvalue { %"compiler/source:Span", i32, ptr } %t350, i32 %t351, 1
  %t353 = load ptr, ptr %l197, !tbaa !29
  %t354 = insertvalue { %"compiler/source:Span", i32, ptr } %t352, ptr %t353, 2
  %t355 = getelementptr { i64, [3 x i64] }, ptr %t347, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t354, ptr %t355
  %t356 = load { i64, [3 x i64] }, ptr %t347
  %t358 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t356, ptr %t358
  %t359 = load ptr, ptr %l187, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t359, ptr %t358)
  br label %bb55
bb55:
  %t361 = load ptr, ptr %l0, !tbaa !29
  %t362 = load %"compiler/source:Span", ptr %l1
  %t363 = load ptr, ptr %l9, !tbaa !29
  %t367 = call { i64, i64, i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLoopOpen(ptr %v0, ptr %t361, %"compiler/source:Span" %t362, ptr %t363, i64 0)
  store { i64, i64, i64, i64, i64 } %t367, ptr %l203
  br label %bb56
bb56:
  %t368 = load { i64, i64, i64, i64, i64 }, ptr %l203
  store { i64, i64, i64, i64, i64 } %t368, ptr %l20
  %t369 = getelementptr { i64, i64, i64, i64, i64 }, ptr %l20, i32 0, i32 0
  %t370 = load i64, ptr %t369, !tbaa !24
  store i64 %t370, ptr %l21, !tbaa !24
  %t372 = getelementptr { i64, i64, i64, i64, i64 }, ptr %l20, i32 0, i32 1
  %t373 = load i64, ptr %t372, !tbaa !24
  store i64 %t373, ptr %l22, !tbaa !24
  %t375 = getelementptr { i64, i64, i64, i64, i64 }, ptr %l20, i32 0, i32 2
  %t376 = load i64, ptr %t375, !tbaa !24
  store i64 %t376, ptr %l23, !tbaa !24
  %t378 = getelementptr { i64, i64, i64, i64, i64 }, ptr %l20, i32 0, i32 3
  %t379 = load i64, ptr %t378, !tbaa !24
  store i64 %t379, ptr %l24, !tbaa !24
  %t381 = getelementptr { i64, i64, i64, i64, i64 }, ptr %l20, i32 0, i32 4
  %t382 = load i64, ptr %t381, !tbaa !24
  store i64 %t382, ptr %l25, !tbaa !24
  %t384 = load ptr, ptr %l0, !tbaa !29
  store ptr %t384, ptr %l209, !tbaa !29
  %t385 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t385, ptr %l210
  %t386 = load i64, ptr %l4, !tbaa !24
  store i64 %t386, ptr %l211, !tbaa !24
  %t387 = load ptr, ptr %lp8
  store ptr %t387, ptr %l212, !tbaa !29
  %t388 = load ptr, ptr %l0, !tbaa !29
  %t389 = load %"compiler/source:Span", ptr %l1
  %t390 = load i64, ptr %l21, !tbaa !24
  %t394 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t388, %"compiler/source:Span" %t389, i64 %t390)
  store ptr %t394, ptr %l216
  br label %bb57
bb57:
  %t395 = load ptr, ptr %l209, !tbaa !29
  %t396 = load %"compiler/source:Span", ptr %l210
  %t397 = load i64, ptr %l211, !tbaa !24
  %t398 = load ptr, ptr %l212, !tbaa !29
  %t399 = load ptr, ptr %l216, !tbaa !29
  %t400 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneElem(ptr %v0, ptr %v0, ptr %t395, %"compiler/source:Span" %t396, i64 %t397, ptr %t398, ptr %t399)
  store ptr %t400, ptr %l217
  br label %bb58
bb58:
  %t401 = load ptr, ptr %l217, !tbaa !29
  store ptr %t401, ptr %l26, !tbaa !29
  %t402 = load ptr, ptr %l0, !tbaa !29
  %t404 = getelementptr %"compiler/check:Checker", ptr %t402, i32 0, i32 37
  %t406 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t404)
  store i64 %t406, ptr %l220
  br label %bb59
bb59:
  %t407 = load i64, ptr %l220, !tbaa !24
  store i64 %t407, ptr %l27, !tbaa !24
  %t408 = load ptr, ptr %l0, !tbaa !29
  %t410 = getelementptr %"compiler/check:Checker", ptr %t408, i32 0, i32 37
  store ptr %t410, ptr %l222, !tbaa !29
  %t411 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t411, ptr %l223
  %t412 = load %"compiler/source:Span", ptr %l1
  %t413 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t414 = load i64, ptr %l19, !tbaa !24
  %t416 = trunc i64 %t414 to i32
  store { i64, [4 x i64] } zeroinitializer, ptr %t418
  %t419 = getelementptr { i64, [4 x i64] }, ptr %t418, i32 0, i32 0
  store i64 0, ptr %t419
  %t421 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t412, 0
  %t423 = insertvalue { %"compiler/source:Span", i32, i32 } %t421, i32 %t413, 1
  %t425 = insertvalue { %"compiler/source:Span", i32, i32 } %t423, i32 %t416, 2
  %t426 = getelementptr { i64, [4 x i64] }, ptr %t418, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t425, ptr %t426
  %t427 = load { i64, [4 x i64] }, ptr %t418
  %t429 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t427, ptr %t429
  store ptr %t429, ptr %l230, !tbaa !29
  %t430 = load ptr, ptr %l0, !tbaa !29
  store ptr %t430, ptr %l231, !tbaa !29
  %t431 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t431, ptr %l232
  %t432 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t432, ptr %l233, !tbaa !23
  %t433 = load i1, ptr %l18, !tbaa !21
  br i1 %t433, label %bb60, label %bb61
bb60:
  store i64 1, ptr %l235, !tbaa !24
  br label %bb62
bb61:
  store i64 0, ptr %l235, !tbaa !24
  br label %bb62
bb62:
  %t435 = load ptr, ptr %l231, !tbaa !29
  %t436 = load %"compiler/source:Span", ptr %l232
  %t437 = load i32, ptr %l233, !tbaa !23
  %t438 = load i64, ptr %l235, !tbaa !24
  %t439 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t435, %"compiler/source:Span" %t436, i32 %t437, i64 %t438)
  store ptr %t439, ptr %l236
  br label %bb63
bb63:
  store { i64, [3 x i64] } zeroinitializer, ptr %t440
  %t441 = getelementptr { i64, [3 x i64] }, ptr %t440, i32 0, i32 0
  store i64 1, ptr %t441
  %t442 = load %"compiler/source:Span", ptr %l223
  %t443 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t442, 0
  %t444 = load ptr, ptr %l230, !tbaa !29
  %t445 = insertvalue { %"compiler/source:Span", ptr, ptr } %t443, ptr %t444, 1
  %t446 = load ptr, ptr %l236, !tbaa !29
  %t447 = insertvalue { %"compiler/source:Span", ptr, ptr } %t445, ptr %t446, 2
  %t448 = getelementptr { i64, [3 x i64] }, ptr %t440, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t447, ptr %t448
  %t449 = load { i64, [3 x i64] }, ptr %t440
  %t451 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t449, ptr %t451
  %t452 = load ptr, ptr %l222, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t452, ptr %t451)
  br label %bb64
bb64:
  %t454 = load ptr, ptr %l0, !tbaa !29
  %t456 = getelementptr %"compiler/check:Checker", ptr %t454, i32 0, i32 37
  %t457 = load %"compiler/source:Span", ptr %l1
  %t458 = load i64, ptr %l22, !tbaa !24
  %t460 = trunc i64 %t458 to i32
  store { i64, [3 x i64] } zeroinitializer, ptr %t462
  %t463 = getelementptr { i64, [3 x i64] }, ptr %t462, i32 0, i32 0
  store i64 5, ptr %t463
  %t465 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t457, 0
  %t467 = insertvalue { %"compiler/source:Span", i32, i32 } %t465, i32 0, 1
  %t469 = insertvalue { %"compiler/source:Span", i32, i32 } %t467, i32 %t460, 2
  %t470 = getelementptr { i64, [3 x i64] }, ptr %t462, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t469, ptr %t470
  %t471 = load { i64, [3 x i64] }, ptr %t462
  %t473 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t471, ptr %t473
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t456, ptr %t473)
  br label %bb65
bb65:
  %t476 = load ptr, ptr %l0, !tbaa !29
  %t478 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t476)
  store ptr %t478, ptr %l249
  br label %bb66
bb66:
  %t479 = load ptr, ptr %l249, !tbaa !29
  %t481 = getelementptr %"compiler/check:frame", ptr %t479, i32 0, i32 7
  %t482 = load i64, ptr %t481, !tbaa !24
  %t484 = trunc i64 %t482 to i32
  store i32 %t484, ptr %l253, !tbaa !23
  %t486 = load ptr, ptr %l0, !tbaa !29
  %t488 = getelementptr %"compiler/check:Checker", ptr %t486, i32 0, i32 37
  %t489 = load i64, ptr %l27, !tbaa !24
  %t492 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t488, i64 %t489)
  store { i64, ptr } %t492, ptr %l257
  br label %bb67
bb67:
  %t493 = load i32, ptr %l253, !tbaa !23
  %t494 = load { i64, ptr }, ptr %l257, !tbaa !27
  %t495 = call %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v0, i32 %t493, { i64, ptr } %t494)
  store %"compiler/typed:Block" %t495, ptr %l258
  br label %bb68
bb68:
  %t496 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store ptr %t496, ptr %lp28
  %t497 = load %"compiler/typed:Block", ptr %l258
  %t498 = load ptr, ptr %lp28
  store %"compiler/typed:Block" %t497, ptr %t498
  %t499 = load ptr, ptr %l0, !tbaa !29
  store ptr %t499, ptr %l259, !tbaa !29
  %t500 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t500, ptr %l260
  %t501 = load i1, ptr %l18, !tbaa !21
  br i1 %t501, label %bb69, label %bb70
bb69:
  %t503 = load ptr, ptr %l26, !tbaa !29
  store ptr %t503, ptr %l262, !tbaa !29
  br label %bb72
bb70:
  %t505 = load ptr, ptr %l0, !tbaa !29
  %t506 = load %"compiler/source:Span", ptr %l1
  %t507 = load ptr, ptr %l26, !tbaa !29
  %t511 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enegate(ptr %v0, ptr %t505, %"compiler/source:Span" %t506, ptr %t507)
  store ptr %t511, ptr %l267
  br label %bb71
bb71:
  %t512 = load ptr, ptr %l267, !tbaa !29
  store ptr %t512, ptr %l262, !tbaa !29
  br label %bb72
bb72:
  %t513 = load ptr, ptr %lp28
  %t514 = load ptr, ptr %l262, !tbaa !29
  %t516 = call %"compiler/typed:If" @compiler_2ftyped_3aIf_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t514, ptr %t513, ptr null)
  store %"compiler/typed:If" %t516, ptr %l269
  br label %bb73
bb73:
  %t517 = load %"compiler/typed:If", ptr %l269
  %t518 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:If" %t517, ptr %t518
  store { i64, [3 x i64] } zeroinitializer, ptr %t519
  %t520 = getelementptr { i64, [3 x i64] }, ptr %t519, i32 0, i32 0
  store i64 3, ptr %t520
  %t521 = load %"compiler/source:Span", ptr %l260
  %t522 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t521, 0
  %t524 = insertvalue { %"compiler/source:Span", ptr } %t522, ptr %t518, 1
  %t525 = getelementptr { i64, [3 x i64] }, ptr %t519, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t524, ptr %t525
  %t526 = load { i64, [3 x i64] }, ptr %t519
  %t528 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t526, ptr %t528
  %t529 = load ptr, ptr %l259, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t529, ptr %t528)
  br label %bb74
bb74:
  %t531 = load ptr, ptr %l0, !tbaa !29
  %t532 = load %"compiler/source:Span", ptr %l1
  %t533 = load i64, ptr %l21, !tbaa !24
  %t534 = load i64, ptr %l22, !tbaa !24
  %t535 = load i64, ptr %l23, !tbaa !24
  %t536 = load i64, ptr %l24, !tbaa !24
  %t537 = load i64, ptr %l25, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLoopClose(ptr %v0, ptr %t531, %"compiler/source:Span" %t532, i64 %t533, i64 %t534, i64 %t535, i64 %t536, i64 %t537)
  br label %bb75
bb75:
  %t545 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t545, ptr %l280
  %t546 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t546, ptr %l281, !tbaa !23
  %t547 = load ptr, ptr %l0, !tbaa !29
  %t549 = getelementptr %"compiler/check:Checker", ptr %t547, i32 0, i32 37
  %t550 = load i64, ptr %l7, !tbaa !24
  %t553 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t549, i64 %t550)
  store { i64, ptr } %t553, ptr %l285
  br label %bb76
bb76:
  %t554 = load ptr, ptr %l0, !tbaa !29
  %t555 = load %"compiler/source:Span", ptr %l1
  %t556 = load i64, ptr %l19, !tbaa !24
  %t560 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t554, %"compiler/source:Span" %t555, i64 %t556)
  store ptr %t560, ptr %l289
  br label %bb77
bb77:
  %t561 = load ptr, ptr %l289, !tbaa !29
  %t562 = load { i64, ptr }, ptr %l285, !tbaa !27
  %t564 = call %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t562, ptr %t561)
  store %"compiler/typed:Seq" %t564, ptr %l291
  br label %bb78
bb78:
  %t565 = load %"compiler/typed:Seq", ptr %l291
  %t566 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Seq" %t565, ptr %t566
  store { i64, [5 x i64] } zeroinitializer, ptr %t567
  %t568 = getelementptr { i64, [5 x i64] }, ptr %t567, i32 0, i32 0
  store i64 12, ptr %t568
  %t569 = load %"compiler/source:Span", ptr %l280
  %t570 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t569, 0
  %t571 = load i32, ptr %l281, !tbaa !23
  %t572 = insertvalue { %"compiler/source:Span", i32, ptr } %t570, i32 %t571, 1
  %t574 = insertvalue { %"compiler/source:Span", i32, ptr } %t572, ptr %t566, 2
  %t575 = getelementptr { i64, [5 x i64] }, ptr %t567, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t574, ptr %t575
  %t576 = load { i64, [5 x i64] }, ptr %t567
  %t578 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t576, ptr %t578
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t578, ptr %rv
  br label %ret
bb79:
  %t580 = load ptr, ptr %l0, !tbaa !29
  store ptr %t580, ptr %l295, !tbaa !29
  %t581 = load ptr, ptr %l0, !tbaa !29
  %t583 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epreludeWord(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %t581, { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d37, i32 0, i32 1) }, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d38, i32 0, i32 1) }, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d39, i32 0, i32 1) })
  store i32 %t583, ptr %l297
  br label %bb80
bb80:
  %t584 = mul i64 1, 4
  %t585 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t584)
  %t586 = insertvalue { i64, ptr } undef, i64 1, 0
  %t587 = insertvalue { i64, ptr } %t586, ptr %t585, 1
  store { i64, ptr } %t587, ptr %l298, !tbaa !27
  %t588 = load i32, ptr %l297, !tbaa !23
  %t589 = getelementptr { i64, ptr }, ptr %l298, i32 0, i32 1
  %t590 = load ptr, ptr %t589, !tbaa !27
  %t591 = getelementptr i32, ptr %t590, i64 0
  store i32 %t588, ptr %t591, !tbaa !33
  %t592 = load %"compiler/source:Span", ptr %l2
  %t593 = load ptr, ptr %l295, !tbaa !29
  %t594 = load { i64, ptr }, ptr %l298, !tbaa !27
  %t596 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efailOp(ptr %v0, ptr %s0, ptr %t593, { i64, ptr } %t594, %"compiler/source:Span" %t592, i1 false)
  store i32 %t596, ptr %l300
  br label %bb81
bb81:
  %t597 = load i32, ptr %l300
  %t598 = load ptr, ptr %l0, !tbaa !29
  store ptr %t598, ptr %l301, !tbaa !29
  %t599 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t599, ptr %l302
  %t600 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t600, ptr %l303
  %t601 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  store i32 %t601, ptr %l304, !tbaa !23
  store i32 39, ptr %l305
  store i32 %t597, ptr %l306
  %t603 = load ptr, ptr %l0, !tbaa !29
  %t604 = load ptr, ptr %l9, !tbaa !29
  %t607 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eone(ptr %v0, ptr %t603, ptr %t604)
  store { i64, ptr } %t607, ptr %l309
  br label %bb82
bb82:
  store { i64, [5 x i64] } zeroinitializer, ptr %t608
  %t609 = getelementptr { i64, [5 x i64] }, ptr %t608, i32 0, i32 0
  store i64 9, ptr %t609
  %t610 = load %"compiler/source:Span", ptr %l303
  %t611 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } undef, %"compiler/source:Span" %t610, 0
  %t612 = load i32, ptr %l304, !tbaa !23
  %t613 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t611, i32 %t612, 1
  %t614 = load i32, ptr %l305
  %t615 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t613, i32 %t614, 2
  %t616 = load i32, ptr %l306
  %t617 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t615, i32 %t616, 3
  %t618 = load { i64, ptr }, ptr %l309, !tbaa !27
  %t619 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t617, { i64, ptr } %t618, 4
  %t620 = getelementptr { i64, [5 x i64] }, ptr %t608, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t619, ptr %t620
  %t621 = load { i64, [5 x i64] }, ptr %t608
  %t623 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t621, ptr %t623
  store { i64, [3 x i64] } zeroinitializer, ptr %t624
  %t625 = getelementptr { i64, [3 x i64] }, ptr %t624, i32 0, i32 0
  store i64 2, ptr %t625
  %t626 = load %"compiler/source:Span", ptr %l302
  %t627 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t626, 0
  %t629 = insertvalue { %"compiler/source:Span", ptr } %t627, ptr %t623, 1
  %t630 = getelementptr { i64, [3 x i64] }, ptr %t624, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t629, ptr %t630
  %t631 = load { i64, [3 x i64] }, ptr %t624
  %t633 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t631, ptr %t633
  %t634 = load ptr, ptr %l301, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t634, ptr %t633)
  br label %bb83
bb83:
  %t636 = load ptr, ptr %l0, !tbaa !29
  store ptr %t636, ptr %l314, !tbaa !29
  %t637 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t637, ptr %l315
  %t638 = load ptr, ptr %l0, !tbaa !29
  %t640 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t638)
  store i32 %t640, ptr %l317
  br label %bb84
bb84:
  %t641 = load ptr, ptr %l314, !tbaa !29
  %t642 = load %"compiler/source:Span", ptr %l315
  %t643 = load i32, ptr %l317, !tbaa !23
  %t644 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t641, %"compiler/source:Span" %t642, i32 %t643)
  store i64 %t644, ptr %l318
  br label %bb85
bb85:
  %t645 = load i64, ptr %l318, !tbaa !24
  store i64 %t645, ptr %l30, !tbaa !24
  %t646 = load ptr, ptr %l0, !tbaa !29
  store ptr %t646, ptr %l319, !tbaa !29
  %t647 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t647, ptr %l320
  %t648 = load i64, ptr %l30, !tbaa !24
  %t650 = trunc i64 %t648 to i32
  store i32 %t650, ptr %l323, !tbaa !23
  %t652 = load ptr, ptr %l0, !tbaa !29
  store ptr %t652, ptr %l324, !tbaa !29
  %t653 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t653, ptr %l325
  %t654 = load ptr, ptr %l0, !tbaa !29
  %t656 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t654)
  store i32 %t656, ptr %l327
  br label %bb86
bb86:
  %t657 = load ptr, ptr %l324, !tbaa !29
  %t658 = load %"compiler/source:Span", ptr %l325
  %t659 = load i32, ptr %l327, !tbaa !23
  %t660 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t657, %"compiler/source:Span" %t658, i32 %t659, i64 0)
  store ptr %t660, ptr %l328
  br label %bb87
bb87:
  store { i64, [3 x i64] } zeroinitializer, ptr %t661
  %t662 = getelementptr { i64, [3 x i64] }, ptr %t661, i32 0, i32 0
  store i64 0, ptr %t662
  %t663 = load %"compiler/source:Span", ptr %l320
  %t664 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t663, 0
  %t665 = load i32, ptr %l323, !tbaa !23
  %t666 = insertvalue { %"compiler/source:Span", i32, ptr } %t664, i32 %t665, 1
  %t667 = load ptr, ptr %l328, !tbaa !29
  %t668 = insertvalue { %"compiler/source:Span", i32, ptr } %t666, ptr %t667, 2
  %t669 = getelementptr { i64, [3 x i64] }, ptr %t661, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t668, ptr %t669
  %t670 = load { i64, [3 x i64] }, ptr %t661
  %t672 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t670, ptr %t672
  %t673 = load ptr, ptr %l319, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t673, ptr %t672)
  br label %bb88
bb88:
  %t675 = load ptr, ptr %l0, !tbaa !29
  %t677 = getelementptr %"compiler/check:Checker", ptr %t675, i32 0, i32 1
  %t678 = load ptr, ptr %t677, !tbaa !29
  %t680 = getelementptr %"compiler/generic:Program", ptr %t678, i32 0, i32 0
  %t681 = load ptr, ptr %t680, !tbaa !29
  %t683 = getelementptr %"compiler/load:Loader", ptr %t681, i32 0, i32 4
  %t684 = load ptr, ptr %t683, !tbaa !29
  %t686 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eHold(ptr %v0, ptr %t684)
  store i64 %t686, ptr %l335
  br label %bb89
bb89:
  %t687 = load i64, ptr %l335, !tbaa !24
  store i64 %t687, ptr %l31, !tbaa !24
  %t688 = load ptr, ptr %l0, !tbaa !29
  store ptr %t688, ptr %l336, !tbaa !29
  %t689 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t689, ptr %l337
  %t690 = load i64, ptr %l4, !tbaa !24
  store i64 %t690, ptr %l338, !tbaa !24
  %t691 = load ptr, ptr %lp8
  store ptr %t691, ptr %l339, !tbaa !29
  %t692 = load ptr, ptr %l0, !tbaa !29
  %t693 = load %"compiler/source:Span", ptr %l1
  %t694 = load i64, ptr %l30, !tbaa !24
  %t698 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t692, %"compiler/source:Span" %t693, i64 %t694)
  store ptr %t698, ptr %l343
  br label %bb90
bb90:
  %t699 = load ptr, ptr %l336, !tbaa !29
  %t700 = load %"compiler/source:Span", ptr %l337
  %t701 = load i64, ptr %l338, !tbaa !24
  %t702 = load ptr, ptr %l339, !tbaa !29
  %t703 = load ptr, ptr %l343, !tbaa !29
  %t704 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneElem(ptr %v0, ptr %v0, ptr %t699, %"compiler/source:Span" %t700, i64 %t701, ptr %t702, ptr %t703)
  store ptr %t704, ptr %l344
  br label %bb91
bb91:
  %t705 = load ptr, ptr %l344, !tbaa !29
  store ptr %t705, ptr %l32, !tbaa !29
  %t706 = load ptr, ptr %l0, !tbaa !29
  %t708 = getelementptr %"compiler/check:Checker", ptr %t706, i32 0, i32 1
  %t709 = load ptr, ptr %t708, !tbaa !29
  %t711 = getelementptr %"compiler/generic:Program", ptr %t709, i32 0, i32 0
  %t712 = load ptr, ptr %t711, !tbaa !29
  %t714 = getelementptr %"compiler/load:Loader", ptr %t712, i32 0, i32 4
  %t715 = load ptr, ptr %t714, !tbaa !29
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eEndHold(ptr %v0, ptr %t715)
  br label %bb92
bb92:
  %t717 = load ptr, ptr %l0, !tbaa !29
  %t719 = getelementptr %"compiler/check:Checker", ptr %t717, i32 0, i32 1
  %t720 = load ptr, ptr %t719, !tbaa !29
  %t722 = getelementptr %"compiler/generic:Program", ptr %t720, i32 0, i32 0
  %t723 = load ptr, ptr %t722, !tbaa !29
  %t725 = getelementptr %"compiler/load:Loader", ptr %t723, i32 0, i32 4
  %t726 = load ptr, ptr %t725, !tbaa !29
  %t727 = load i64, ptr %l31, !tbaa !24
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eDrop(ptr %v0, ptr %t726, i64 %t727)
  br label %bb93
bb93:
  %t730 = load ptr, ptr %l0, !tbaa !29
  %t731 = load %"compiler/source:Span", ptr %l1
  %t732 = load i32, ptr %l6, !tbaa !23
  %t736 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t730, %"compiler/source:Span" %t731, i32 %t732)
  store i64 %t736, ptr %l357
  br label %bb94
bb94:
  %t737 = load i64, ptr %l357, !tbaa !24
  store i64 %t737, ptr %l33, !tbaa !24
  %t738 = load ptr, ptr %l0, !tbaa !29
  store ptr %t738, ptr %l358, !tbaa !29
  %t739 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t739, ptr %l359
  %t740 = load i64, ptr %l33, !tbaa !24
  %t742 = trunc i64 %t740 to i32
  store i32 %t742, ptr %l362, !tbaa !23
  %t744 = load ptr, ptr %l0, !tbaa !29
  %t745 = load ptr, ptr %l32, !tbaa !29
  %t746 = load i32, ptr %l6, !tbaa !23
  %t747 = load %"compiler/source:Span", ptr %l1
  %t752 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %t744, ptr %t745, i32 %t746, %"compiler/source:Span" %t747)
  store ptr %t752, ptr %l367
  br label %bb95
bb95:
  store { i64, [3 x i64] } zeroinitializer, ptr %t753
  %t754 = getelementptr { i64, [3 x i64] }, ptr %t753, i32 0, i32 0
  store i64 0, ptr %t754
  %t755 = load %"compiler/source:Span", ptr %l359
  %t756 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t755, 0
  %t757 = load i32, ptr %l362, !tbaa !23
  %t758 = insertvalue { %"compiler/source:Span", i32, ptr } %t756, i32 %t757, 1
  %t759 = load ptr, ptr %l367, !tbaa !29
  %t760 = insertvalue { %"compiler/source:Span", i32, ptr } %t758, ptr %t759, 2
  %t761 = getelementptr { i64, [3 x i64] }, ptr %t753, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t760, ptr %t761
  %t762 = load { i64, [3 x i64] }, ptr %t753
  %t764 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t762, ptr %t764
  %t765 = load ptr, ptr %l358, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t765, ptr %t764)
  br label %bb96
bb96:
  %t767 = load ptr, ptr %l0, !tbaa !29
  store ptr %t767, ptr %l370, !tbaa !29
  %t768 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t768, ptr %l371
  %t769 = load ptr, ptr %l0, !tbaa !29
  %t770 = load %"compiler/source:Span", ptr %l1
  %t771 = load i64, ptr %l4, !tbaa !24
  %t772 = load ptr, ptr %lp8
  %t777 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneCount(ptr %v0, ptr %v0, ptr %t769, %"compiler/source:Span" %t770, i64 %t771, ptr %t772)
  store ptr %t777, ptr %l376
  br label %bb97
bb97:
  %t778 = load ptr, ptr %l370, !tbaa !29
  %t779 = load %"compiler/source:Span", ptr %l371
  %t780 = load ptr, ptr %l376, !tbaa !29
  %t781 = call { i64, i64, i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLoopOpen(ptr %v0, ptr %t778, %"compiler/source:Span" %t779, ptr %t780, i64 1)
  store { i64, i64, i64, i64, i64 } %t781, ptr %l377
  br label %bb98
bb98:
  %t782 = load { i64, i64, i64, i64, i64 }, ptr %l377
  store { i64, i64, i64, i64, i64 } %t782, ptr %l34
  %t783 = getelementptr { i64, i64, i64, i64, i64 }, ptr %l34, i32 0, i32 0
  %t784 = load i64, ptr %t783, !tbaa !24
  store i64 %t784, ptr %l35, !tbaa !24
  %t786 = getelementptr { i64, i64, i64, i64, i64 }, ptr %l34, i32 0, i32 1
  %t787 = load i64, ptr %t786, !tbaa !24
  store i64 %t787, ptr %l36, !tbaa !24
  %t789 = getelementptr { i64, i64, i64, i64, i64 }, ptr %l34, i32 0, i32 2
  %t790 = load i64, ptr %t789, !tbaa !24
  store i64 %t790, ptr %l37, !tbaa !24
  %t792 = getelementptr { i64, i64, i64, i64, i64 }, ptr %l34, i32 0, i32 3
  %t793 = load i64, ptr %t792, !tbaa !24
  store i64 %t793, ptr %l38, !tbaa !24
  %t795 = getelementptr { i64, i64, i64, i64, i64 }, ptr %l34, i32 0, i32 4
  %t796 = load i64, ptr %t795, !tbaa !24
  store i64 %t796, ptr %l39, !tbaa !24
  %t798 = load ptr, ptr %l0, !tbaa !29
  %t799 = load %"compiler/source:Span", ptr %l1
  %t800 = load i32, ptr %l6, !tbaa !23
  %t804 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t798, %"compiler/source:Span" %t799, i32 %t800)
  store i64 %t804, ptr %l386
  br label %bb99
bb99:
  %t805 = load i64, ptr %l386, !tbaa !24
  store i64 %t805, ptr %l40, !tbaa !24
  %t806 = load ptr, ptr %l0, !tbaa !29
  store ptr %t806, ptr %l387, !tbaa !29
  %t807 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t807, ptr %l388
  %t808 = load i64, ptr %l40, !tbaa !24
  %t810 = trunc i64 %t808 to i32
  store i32 %t810, ptr %l391, !tbaa !23
  %t812 = load ptr, ptr %l0, !tbaa !29
  store ptr %t812, ptr %l392, !tbaa !29
  %t813 = load ptr, ptr %l0, !tbaa !29
  store ptr %t813, ptr %l393, !tbaa !29
  %t814 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t814, ptr %l394
  %t815 = load i64, ptr %l4, !tbaa !24
  store i64 %t815, ptr %l395, !tbaa !24
  %t816 = load ptr, ptr %lp8
  store ptr %t816, ptr %l396, !tbaa !29
  %t817 = load ptr, ptr %l0, !tbaa !29
  %t818 = load %"compiler/source:Span", ptr %l1
  %t819 = load i64, ptr %l35, !tbaa !24
  %t823 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t817, %"compiler/source:Span" %t818, i64 %t819)
  store ptr %t823, ptr %l400
  br label %bb100
bb100:
  %t824 = load ptr, ptr %l393, !tbaa !29
  %t825 = load %"compiler/source:Span", ptr %l394
  %t826 = load i64, ptr %l395, !tbaa !24
  %t827 = load ptr, ptr %l396, !tbaa !29
  %t828 = load ptr, ptr %l400, !tbaa !29
  %t829 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneElem(ptr %v0, ptr %v0, ptr %t824, %"compiler/source:Span" %t825, i64 %t826, ptr %t827, ptr %t828)
  store ptr %t829, ptr %l401
  br label %bb101
bb101:
  %t830 = load i32, ptr %l6, !tbaa !23
  %t831 = load %"compiler/source:Span", ptr %l1
  %t832 = load ptr, ptr %l392, !tbaa !29
  %t833 = load ptr, ptr %l401, !tbaa !29
  %t836 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %t832, ptr %t833, i32 %t830, %"compiler/source:Span" %t831)
  store ptr %t836, ptr %l404
  br label %bb102
bb102:
  store { i64, [3 x i64] } zeroinitializer, ptr %t837
  %t838 = getelementptr { i64, [3 x i64] }, ptr %t837, i32 0, i32 0
  store i64 0, ptr %t838
  %t839 = load %"compiler/source:Span", ptr %l388
  %t840 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t839, 0
  %t841 = load i32, ptr %l391, !tbaa !23
  %t842 = insertvalue { %"compiler/source:Span", i32, ptr } %t840, i32 %t841, 1
  %t843 = load ptr, ptr %l404, !tbaa !29
  %t844 = insertvalue { %"compiler/source:Span", i32, ptr } %t842, ptr %t843, 2
  %t845 = getelementptr { i64, [3 x i64] }, ptr %t837, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t844, ptr %t845
  %t846 = load { i64, [3 x i64] }, ptr %t837
  %t848 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t846, ptr %t848
  %t849 = load ptr, ptr %l387, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t849, ptr %t848)
  br label %bb103
bb103:
  %t851 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t853 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t851, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d40, i32 0, i32 1) })
  store i1 %t853, ptr %l408
  br label %bb104
bb104:
  %t854 = load i1, ptr %l408, !tbaa !21
  br i1 %t854, label %bb105, label %bb106
bb105:
  %t855 = load ptr, ptr %l0, !tbaa !29
  store ptr %t855, ptr %l410, !tbaa !29
  %t856 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t856, ptr %l411
  %t857 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t857, ptr %l412
  store i32 79, ptr %l413
  %t858 = load ptr, ptr %l0, !tbaa !29
  %t859 = load %"compiler/source:Span", ptr %l1
  %t860 = load i64, ptr %l40, !tbaa !24
  %t864 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t858, %"compiler/source:Span" %t859, i64 %t860)
  store ptr %t864, ptr %l417
  br label %bb107
bb106:
  %t865 = load ptr, ptr %l0, !tbaa !29
  store ptr %t865, ptr %l425, !tbaa !29
  %t866 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t866, ptr %l426
  %t867 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t867, ptr %l427
  store i32 79, ptr %l428
  %t868 = load ptr, ptr %l0, !tbaa !29
  %t869 = load %"compiler/source:Span", ptr %l1
  %t870 = load i64, ptr %l33, !tbaa !24
  %t874 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t868, %"compiler/source:Span" %t869, i64 %t870)
  store ptr %t874, ptr %l432
  br label %bb110
bb107:
  %t875 = load ptr, ptr %l0, !tbaa !29
  %t876 = load %"compiler/source:Span", ptr %l1
  %t877 = load i64, ptr %l33, !tbaa !24
  %t881 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t875, %"compiler/source:Span" %t876, i64 %t877)
  store ptr %t881, ptr %l421
  br label %bb108
bb108:
  %t882 = load %"compiler/source:Span", ptr %l1
  %t883 = load %"compiler/source:Span", ptr %l1
  %t884 = load ptr, ptr %l410, !tbaa !29
  %t885 = load %"compiler/source:Span", ptr %l411
  %t886 = load %"compiler/source:Span", ptr %l412
  %t887 = load i32, ptr %l413
  %t888 = load ptr, ptr %l417, !tbaa !29
  %t889 = load ptr, ptr %l421, !tbaa !29
  %t892 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopValues(ptr %v0, ptr %t884, %"compiler/source:Span" %t885, %"compiler/source:Span" %t886, i32 %t887, ptr %t888, ptr %t889, %"compiler/source:Span" %t882, %"compiler/source:Span" %t883)
  store ptr %t892, ptr %l424
  br label %bb109
bb109:
  %t893 = load ptr, ptr %l424, !tbaa !29
  store ptr %t893, ptr %l409, !tbaa !29
  br label %bb113
bb110:
  %t894 = load ptr, ptr %l0, !tbaa !29
  %t895 = load %"compiler/source:Span", ptr %l1
  %t896 = load i64, ptr %l40, !tbaa !24
  %t900 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t894, %"compiler/source:Span" %t895, i64 %t896)
  store ptr %t900, ptr %l436
  br label %bb111
bb111:
  %t901 = load %"compiler/source:Span", ptr %l1
  %t902 = load %"compiler/source:Span", ptr %l1
  %t903 = load ptr, ptr %l425, !tbaa !29
  %t904 = load %"compiler/source:Span", ptr %l426
  %t905 = load %"compiler/source:Span", ptr %l427
  %t906 = load i32, ptr %l428
  %t907 = load ptr, ptr %l432, !tbaa !29
  %t908 = load ptr, ptr %l436, !tbaa !29
  %t911 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopValues(ptr %v0, ptr %t903, %"compiler/source:Span" %t904, %"compiler/source:Span" %t905, i32 %t906, ptr %t907, ptr %t908, %"compiler/source:Span" %t901, %"compiler/source:Span" %t902)
  store ptr %t911, ptr %l439
  br label %bb112
bb112:
  %t912 = load ptr, ptr %l439, !tbaa !29
  store ptr %t912, ptr %l409, !tbaa !29
  br label %bb113
bb113:
  %t913 = load ptr, ptr %l409, !tbaa !29
  store ptr %t913, ptr %l41, !tbaa !29
  %t914 = load ptr, ptr %l0, !tbaa !29
  %t916 = getelementptr %"compiler/check:Checker", ptr %t914, i32 0, i32 1
  %t917 = load ptr, ptr %t916, !tbaa !29
  %t919 = getelementptr %"compiler/generic:Program", ptr %t917, i32 0, i32 2
  store ptr %t919, ptr %l442, !tbaa !29
  %t920 = load ptr, ptr %l0, !tbaa !29
  %t921 = load i32, ptr %l6, !tbaa !23
  %t924 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t920, i32 %t921)
  store i32 %t924, ptr %l445
  br label %bb114
bb114:
  %t925 = load ptr, ptr %l442, !tbaa !29
  %t926 = load i32, ptr %l445, !tbaa !23
  %t927 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t925, i32 %t926)
  store i1 %t927, ptr %l446
  br label %bb115
bb115:
  %t928 = load i1, ptr %l446, !tbaa !21
  br i1 %t928, label %bb116, label %bb117
bb116:
  %t929 = load ptr, ptr %l0, !tbaa !29
  store ptr %t929, ptr %l447, !tbaa !29
  %t930 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t930, ptr %l448
  %t931 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t931, ptr %l449, !tbaa !23
  store i32 14, ptr %l450
  %t932 = load ptr, ptr %l0, !tbaa !29
  %t933 = load %"compiler/source:Span", ptr %l1
  %t934 = load i64, ptr %l40, !tbaa !24
  %t938 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t932, %"compiler/source:Span" %t933, i64 %t934)
  store ptr %t938, ptr %l454
  br label %bb118
bb117:
  br label %bb123
bb118:
  %t939 = load ptr, ptr %l0, !tbaa !29
  %t940 = load %"compiler/source:Span", ptr %l1
  %t941 = load i64, ptr %l40, !tbaa !24
  %t945 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t939, %"compiler/source:Span" %t940, i64 %t941)
  store ptr %t945, ptr %l458
  br label %bb119
bb119:
  %t946 = load ptr, ptr %l458, !tbaa !29
  %t947 = load ptr, ptr %l447, !tbaa !29
  %t948 = load %"compiler/source:Span", ptr %l448
  %t949 = load i32, ptr %l449, !tbaa !23
  %t950 = load i32, ptr %l450
  %t951 = load ptr, ptr %l454, !tbaa !29
  %t953 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %t947, %"compiler/source:Span" %t948, i32 %t949, i32 %t950, ptr %t951, ptr %t946)
  store ptr %t953, ptr %l460
  br label %bb120
bb120:
  %t954 = load ptr, ptr %l460, !tbaa !29
  store ptr %t954, ptr %l42, !tbaa !29
  %t955 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t955, ptr %l461
  %t956 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t956, ptr %l462, !tbaa !23
  %t957 = load ptr, ptr %l41, !tbaa !29
  store ptr %t957, ptr %l463, !tbaa !29
  %t958 = load ptr, ptr %l0, !tbaa !29
  %t959 = load %"compiler/source:Span", ptr %l1
  %t960 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t964 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t958, %"compiler/source:Span" %t959, i32 %t960, i64 1)
  store ptr %t964, ptr %l467
  br label %bb121
bb121:
  %t965 = load ptr, ptr %l467, !tbaa !29
  %t966 = load ptr, ptr %l42, !tbaa !29
  %t967 = load ptr, ptr %l463, !tbaa !29
  %t970 = call %"compiler/typed:Cond" @compiler_2ftyped_3aCond_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t967, ptr %t965, ptr %t966)
  store %"compiler/typed:Cond" %t970, ptr %l470
  br label %bb122
bb122:
  %t971 = load %"compiler/typed:Cond", ptr %l470
  %t972 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Cond" %t971, ptr %t972
  store { i64, [5 x i64] } zeroinitializer, ptr %t973
  %t974 = getelementptr { i64, [5 x i64] }, ptr %t973, i32 0, i32 0
  store i64 11, ptr %t974
  %t975 = load %"compiler/source:Span", ptr %l461
  %t976 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t975, 0
  %t977 = load i32, ptr %l462, !tbaa !23
  %t978 = insertvalue { %"compiler/source:Span", i32, ptr } %t976, i32 %t977, 1
  %t980 = insertvalue { %"compiler/source:Span", i32, ptr } %t978, ptr %t972, 2
  %t981 = getelementptr { i64, [5 x i64] }, ptr %t973, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t980, ptr %t981
  %t982 = load { i64, [5 x i64] }, ptr %t973
  %t984 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t982, ptr %t984
  store ptr %t984, ptr %l41, !tbaa !29
  br label %bb123
bb123:
  %t986 = load ptr, ptr %l0, !tbaa !29
  %t988 = getelementptr %"compiler/check:Checker", ptr %t986, i32 0, i32 37
  %t990 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t988)
  store i64 %t990, ptr %l476
  br label %bb124
bb124:
  %t991 = load i64, ptr %l476, !tbaa !24
  store i64 %t991, ptr %l43, !tbaa !24
  %t992 = load ptr, ptr %l0, !tbaa !29
  %t994 = getelementptr %"compiler/check:Checker", ptr %t992, i32 0, i32 37
  store ptr %t994, ptr %l478, !tbaa !29
  %t995 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t995, ptr %l479
  %t996 = load %"compiler/source:Span", ptr %l1
  %t997 = load i32, ptr %l6, !tbaa !23
  %t998 = load i64, ptr %l33, !tbaa !24
  %t1000 = trunc i64 %t998 to i32
  store { i64, [4 x i64] } zeroinitializer, ptr %t1002
  %t1003 = getelementptr { i64, [4 x i64] }, ptr %t1002, i32 0, i32 0
  store i64 0, ptr %t1003
  %t1005 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t996, 0
  %t1007 = insertvalue { %"compiler/source:Span", i32, i32 } %t1005, i32 %t997, 1
  %t1009 = insertvalue { %"compiler/source:Span", i32, i32 } %t1007, i32 %t1000, 2
  %t1010 = getelementptr { i64, [4 x i64] }, ptr %t1002, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t1009, ptr %t1010
  %t1011 = load { i64, [4 x i64] }, ptr %t1002
  %t1013 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t1011, ptr %t1013
  store ptr %t1013, ptr %l486, !tbaa !29
  %t1014 = load ptr, ptr %l0, !tbaa !29
  %t1015 = load %"compiler/source:Span", ptr %l1
  %t1016 = load i64, ptr %l40, !tbaa !24
  %t1020 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t1014, %"compiler/source:Span" %t1015, i64 %t1016)
  store ptr %t1020, ptr %l490
  br label %bb125
bb125:
  store { i64, [3 x i64] } zeroinitializer, ptr %t1021
  %t1022 = getelementptr { i64, [3 x i64] }, ptr %t1021, i32 0, i32 0
  store i64 1, ptr %t1022
  %t1023 = load %"compiler/source:Span", ptr %l479
  %t1024 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t1023, 0
  %t1025 = load ptr, ptr %l486, !tbaa !29
  %t1026 = insertvalue { %"compiler/source:Span", ptr, ptr } %t1024, ptr %t1025, 1
  %t1027 = load ptr, ptr %l490, !tbaa !29
  %t1028 = insertvalue { %"compiler/source:Span", ptr, ptr } %t1026, ptr %t1027, 2
  %t1029 = getelementptr { i64, [3 x i64] }, ptr %t1021, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t1028, ptr %t1029
  %t1030 = load { i64, [3 x i64] }, ptr %t1021
  %t1032 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t1030, ptr %t1032
  %t1033 = load ptr, ptr %l478, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t1033, ptr %t1032)
  br label %bb126
bb126:
  %t1035 = load ptr, ptr %l0, !tbaa !29
  %t1037 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t1035)
  store ptr %t1037, ptr %l494
  br label %bb127
bb127:
  %t1038 = load ptr, ptr %l494, !tbaa !29
  %t1040 = getelementptr %"compiler/check:frame", ptr %t1038, i32 0, i32 7
  %t1041 = load i64, ptr %t1040, !tbaa !24
  %t1043 = trunc i64 %t1041 to i32
  store i32 %t1043, ptr %l498, !tbaa !23
  %t1045 = load ptr, ptr %l0, !tbaa !29
  %t1047 = getelementptr %"compiler/check:Checker", ptr %t1045, i32 0, i32 37
  %t1048 = load i64, ptr %l43, !tbaa !24
  %t1051 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t1047, i64 %t1048)
  store { i64, ptr } %t1051, ptr %l502
  br label %bb128
bb128:
  %t1052 = load i32, ptr %l498, !tbaa !23
  %t1053 = load { i64, ptr }, ptr %l502, !tbaa !27
  %t1054 = call %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v0, i32 %t1052, { i64, ptr } %t1053)
  store %"compiler/typed:Block" %t1054, ptr %l503
  br label %bb129
bb129:
  %t1055 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store ptr %t1055, ptr %lp44
  %t1056 = load %"compiler/typed:Block", ptr %l503
  %t1057 = load ptr, ptr %lp44
  store %"compiler/typed:Block" %t1056, ptr %t1057
  %t1058 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1058, ptr %l504, !tbaa !29
  %t1059 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1059, ptr %l505
  %t1060 = load ptr, ptr %l41, !tbaa !29
  %t1061 = load ptr, ptr %lp44
  %t1064 = call %"compiler/typed:If" @compiler_2ftyped_3aIf_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t1060, ptr %t1061, ptr null)
  store %"compiler/typed:If" %t1064, ptr %l508
  br label %bb130
bb130:
  %t1065 = load %"compiler/typed:If", ptr %l508
  %t1066 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:If" %t1065, ptr %t1066
  store { i64, [3 x i64] } zeroinitializer, ptr %t1067
  %t1068 = getelementptr { i64, [3 x i64] }, ptr %t1067, i32 0, i32 0
  store i64 3, ptr %t1068
  %t1069 = load %"compiler/source:Span", ptr %l505
  %t1070 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t1069, 0
  %t1072 = insertvalue { %"compiler/source:Span", ptr } %t1070, ptr %t1066, 1
  %t1073 = getelementptr { i64, [3 x i64] }, ptr %t1067, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t1072, ptr %t1073
  %t1074 = load { i64, [3 x i64] }, ptr %t1067
  %t1076 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t1074, ptr %t1076
  %t1077 = load ptr, ptr %l504, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t1077, ptr %t1076)
  br label %bb131
bb131:
  %t1079 = load ptr, ptr %l0, !tbaa !29
  %t1080 = load %"compiler/source:Span", ptr %l1
  %t1081 = load i64, ptr %l35, !tbaa !24
  %t1082 = load i64, ptr %l36, !tbaa !24
  %t1083 = load i64, ptr %l37, !tbaa !24
  %t1084 = load i64, ptr %l38, !tbaa !24
  %t1085 = load i64, ptr %l39, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLoopClose(ptr %v0, ptr %t1079, %"compiler/source:Span" %t1080, i64 %t1081, i64 %t1082, i64 %t1083, i64 %t1084, i64 %t1085)
  br label %bb132
bb132:
  %t1093 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1093, ptr %l519
  %t1094 = load i32, ptr %l6, !tbaa !23
  store i32 %t1094, ptr %l520, !tbaa !23
  %t1095 = load ptr, ptr %l0, !tbaa !29
  %t1097 = getelementptr %"compiler/check:Checker", ptr %t1095, i32 0, i32 37
  %t1098 = load i64, ptr %l7, !tbaa !24
  %t1101 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t1097, i64 %t1098)
  store { i64, ptr } %t1101, ptr %l524
  br label %bb133
bb133:
  %t1102 = load ptr, ptr %l0, !tbaa !29
  %t1103 = load %"compiler/source:Span", ptr %l1
  %t1104 = load i64, ptr %l33, !tbaa !24
  %t1108 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t1102, %"compiler/source:Span" %t1103, i64 %t1104)
  store ptr %t1108, ptr %l528
  br label %bb134
bb134:
  %t1109 = load ptr, ptr %l528, !tbaa !29
  %t1110 = load { i64, ptr }, ptr %l524, !tbaa !27
  %t1112 = call %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t1110, ptr %t1109)
  store %"compiler/typed:Seq" %t1112, ptr %l530
  br label %bb135
bb135:
  %t1113 = load %"compiler/typed:Seq", ptr %l530
  %t1114 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Seq" %t1113, ptr %t1114
  store { i64, [5 x i64] } zeroinitializer, ptr %t1115
  %t1116 = getelementptr { i64, [5 x i64] }, ptr %t1115, i32 0, i32 0
  store i64 12, ptr %t1116
  %t1117 = load %"compiler/source:Span", ptr %l519
  %t1118 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t1117, 0
  %t1119 = load i32, ptr %l520, !tbaa !23
  %t1120 = insertvalue { %"compiler/source:Span", i32, ptr } %t1118, i32 %t1119, 1
  %t1122 = insertvalue { %"compiler/source:Span", i32, ptr } %t1120, ptr %t1114, 2
  %t1123 = getelementptr { i64, [5 x i64] }, ptr %t1115, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t1122, ptr %t1123
  %t1124 = load { i64, [5 x i64] }, ptr %t1115
  %t1126 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t1124, ptr %t1126
  call void @__olang_scope_close(ptr %s0)
  store ptr %t1126, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneType(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"compiler/check:laneNode"
  %l6 = alloca %"compiler/check:laneNode"
  %l13 = alloca ptr
  %l14 = alloca i32
  %l17 = alloca i32
  %l20 = alloca ptr
  %l22 = alloca i32
  %l24 = alloca i32
  %l25 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 39
  %t7 = call %"compiler/check:laneNode" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alaneNode_3e_2eAt_3ccompiler_2fcheck_3alaneNode_3e(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store %"compiler/check:laneNode" %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = load %"compiler/check:laneNode", ptr %l6
  store %"compiler/check:laneNode" %t8, ptr %l2
  %t9 = getelementptr %"compiler/check:laneNode", ptr %l2, i32 0, i32 10
  %t10 = load i32, ptr %t9, !tbaa !23
  %t11 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t14 = icmp ne i32 %t10, %t11
  br i1 %t14, label %bb2, label %bb3
bb2:
  %t16 = getelementptr %"compiler/check:laneNode", ptr %l2, i32 0, i32 10
  %t17 = load i32, ptr %t16, !tbaa !23
  store i32 %t17, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/check:Checker", ptr %t19, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t24 = getelementptr %"compiler/generic:Program", ptr %t22, i32 0, i32 2
  store ptr %t24, ptr %l13, !tbaa !29
  %t25 = getelementptr %"compiler/check:laneNode", ptr %l2, i32 0, i32 8
  %t26 = load i32, ptr %t25, !tbaa !23
  store i32 %t26, ptr %l14, !tbaa !23
  %t27 = getelementptr %"compiler/check:laneNode", ptr %l2, i32 0, i32 9
  %t28 = load i64, ptr %t27, !tbaa !24
  %t30 = icmp sge i64 %t28, 0
  br i1 %t30, label %bb5, label %bb6
bb5:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/check:Checker", ptr %t32, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t37 = getelementptr %"compiler/generic:Program", ptr %t35, i32 0, i32 2
  store ptr %t37, ptr %l20, !tbaa !29
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t38)
  store i32 %t40, ptr %l22
  br label %bb7
bb6:
  store i32 0, ptr %l17, !tbaa !23
  br label %bb9
bb7:
  %t41 = getelementptr %"compiler/check:laneNode", ptr %l2, i32 0, i32 9
  %t42 = load i64, ptr %t41, !tbaa !24
  %t43 = load ptr, ptr %l20, !tbaa !29
  %t44 = load i32, ptr %l22, !tbaa !23
  %t46 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConst(ptr %v0, ptr %t43, i32 %t44, i64 %t42)
  store i32 %t46, ptr %l24
  br label %bb8
bb8:
  %t47 = load i32, ptr %l24, !tbaa !23
  store i32 %t47, ptr %l17, !tbaa !23
  br label %bb9
bb9:
  %t48 = load ptr, ptr %l13, !tbaa !29
  %t49 = load i32, ptr %l14, !tbaa !23
  %t50 = load i32, ptr %l17, !tbaa !23
  %t51 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %t48, i32 %t49, i32 %t50)
  store i32 %t51, ptr %l25
  br label %bb10
bb10:
  %t52 = load i32, ptr %l25, !tbaa !23
  store i32 %t52, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleadWord(ptr %v0, ptr %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l6 = alloca { i64, ptr }
  %l11 = alloca i1
  %l12 = alloca { i64, ptr }
  %l15 = alloca i1
  %l16 = alloca i1
  %l17 = alloca { i64, ptr }
  %l20 = alloca i1
  %l21 = alloca i1
  %l22 = alloca { i64, ptr }
  %l31 = alloca %"compiler/source:Span"
  %l37 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t2 = load %"compiler/source:Span", ptr %l1
  %t5 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %a0, %"compiler/source:Span" %t2)
  store { i64, ptr } %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t6, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  br label %bb2
bb2:
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t8, 0
  %t13 = icmp slt i64 %t7, %t10
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t15, ptr %l12, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr i8, ptr %t19, i64 %t16
  %t21 = load i8, ptr %t20, !tbaa !32
  %t23 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t21)
  store i1 %t23, ptr %l15
  br label %bb5
bb4:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb13
bb5:
  %t24 = load i1, ptr %l15, !tbaa !21
  br i1 %t24, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb9
bb7:
  %t25 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t25, ptr %l17, !tbaa !27
  %t26 = load i64, ptr %l3, !tbaa !24
  %t28 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = getelementptr i8, ptr %t29, i64 %t26
  %t31 = load i8, ptr %t30, !tbaa !32
  %t33 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t31)
  store i1 %t33, ptr %l20
  br label %bb8
bb8:
  %t34 = load i1, ptr %l20, !tbaa !21
  store i1 %t34, ptr %l16, !tbaa !21
  br label %bb9
bb9:
  %t35 = load i1, ptr %l16, !tbaa !21
  br i1 %t35, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb12
bb11:
  %t36 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t36, ptr %l22, !tbaa !27
  %t37 = load i64, ptr %l3, !tbaa !24
  %t39 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !27
  %t41 = getelementptr i8, ptr %t40, i64 %t37
  %t42 = load i8, ptr %t41, !tbaa !32
  %t44 = icmp eq i8 %t42, 95
  store i1 %t44, ptr %l21, !tbaa !21
  br label %bb12
bb12:
  %t46 = load i1, ptr %l21, !tbaa !21
  store i1 %t46, ptr %l11, !tbaa !21
  br label %bb13
bb13:
  %t47 = load i1, ptr %l11, !tbaa !21
  %t48 = xor i1 %t47, true
  br i1 %t48, label %bb14, label %bb15
bb14:
  br label %bb18
bb15:
  br label %bb16
bb16:
  %t50 = load i64, ptr %l3, !tbaa !24
  %t52 = add i64 %t50, 1
  store i64 %t52, ptr %l3, !tbaa !24
  br label %bb17
bb17:
  br label %bb2
bb18:
  %t54 = load i64, ptr %l3, !tbaa !24
  %t56 = icmp sgt i64 %t54, 0
  br i1 %t56, label %bb19, label %bb20
bb19:
  %t58 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t59 = load i32, ptr %t58, !tbaa !23
  %t60 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t61 = load i32, ptr %t60, !tbaa !23
  %t62 = load i64, ptr %l3, !tbaa !24
  %t64 = trunc i64 %t62 to i32
  %t67 = add i32 %t61, %t64
  %t70 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %t59, i32 %t67)
  store %"compiler/source:Span" %t70, ptr %l37
  br label %bb21
bb20:
  %t71 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t71, ptr %l31
  br label %bb22
bb21:
  %t73 = load %"compiler/source:Span", ptr %l37
  store %"compiler/source:Span" %t73, ptr %l31
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s0)
  %t74 = load %"compiler/source:Span", ptr %l31
  store %"compiler/source:Span" %t74, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eliteralLocalNote(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca %"compiler/typed:Local"
  %l5 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l6 = alloca %"compiler/source:Span"
  %l10 = alloca ptr
  %l14 = alloca %"compiler/typed:Local"
  %l16 = alloca ptr
  %l20 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l21 = alloca %"compiler/source:Span"
  %l25 = alloca %"compiler/source:Span"
  %l26 = alloca i32
  %l27 = alloca %"compiler/source:Span"
  %l33 = alloca i1
  %l37 = alloca ptr
  %l38 = alloca i64
  %l41 = alloca { i64, [3 x i64] }
  %l44 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l51 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %l57 = alloca %"compiler/msgs:Msg"
  %l61 = alloca ptr
  %l62 = alloca i64
  %l65 = alloca { i64, [3 x i64] }
  %l68 = alloca { i64, ptr }
  %l71 = alloca { i64, ptr }
  %l72 = alloca { i64, ptr }
  %l75 = alloca { i64, ptr }
  %l76 = alloca { i64, ptr }
  %l79 = alloca { i64, ptr }
  %l82 = alloca { i64, ptr }
  %l84 = alloca %"compiler/msgs:Msg"
  %l88 = alloca ptr
  %l89 = alloca i64
  %l92 = alloca { i64, [3 x i64] }
  %l95 = alloca { i64, ptr }
  %l98 = alloca { i64, ptr }
  %l99 = alloca { i64, ptr }
  %l102 = alloca { i64, ptr }
  %l105 = alloca { i64, ptr }
  %l107 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t5)
  store ptr %t7, ptr %l10
  br label %bb4
bb4:
  %t8 = load ptr, ptr %l10, !tbaa !29
  %t10 = getelementptr %"compiler/typed:Body", ptr %t8, i32 0, i32 7
  %t11 = load i64, ptr %l2, !tbaa !24
  %t14 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t10, i64 %t11)
  store %"compiler/typed:Local" %t14, ptr %l14
  br label %bb5
bb5:
  %t15 = load %"compiler/typed:Local", ptr %l14
  store %"compiler/typed:Local" %t15, ptr %l4
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t16)
  store ptr %t18, ptr %l16
  br label %bb6
bb6:
  %t19 = load ptr, ptr %l16, !tbaa !29
  %t21 = getelementptr %"compiler/check:frame", ptr %t19, i32 0, i32 0
  %t22 = load i64, ptr %t21, !tbaa !24
  %t23 = load i64, ptr %l2, !tbaa !24
  %t26 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %t22, i64 %t23)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t26, ptr %l20
  br label %bb7
bb7:
  %t27 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l20
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t27, ptr %l5
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/check:Checker", ptr %t28, i32 0, i32 32
  %t31 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l5
  %t34 = call { i32, %"compiler/source:Span" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H7d5384a5030fc995e793b3fe1f57e776(ptr %v0, ptr %t30, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t31)
  %t35 = extractvalue { i32, %"compiler/source:Span" } %t34, 1
  %t36 = extractvalue { i32, %"compiler/source:Span" } %t34, 0
  store i32 %t36, ptr %l26
  %t37 = icmp ne i32 %t36, 0
  br i1 %t37, label %bb9, label %ok.38, !prof !99
ok.38:
  store %"compiler/source:Span" %t35, ptr %l25
  br label %bb8
bb8:
  %t39 = load %"compiler/source:Span", ptr %l25
  store %"compiler/source:Span" %t39, ptr %l21
  br label %bb12
bb9:
  br label %bb10
bb10:
  call void @__olang_ert_req_clear()
  %t40 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 -1, i32 -1)
  store %"compiler/source:Span" %t40, ptr %l27
  br label %bb11
bb11:
  %t41 = load %"compiler/source:Span", ptr %l27
  store %"compiler/source:Span" %t41, ptr %l21
  br label %bb12
bb12:
  %t42 = load %"compiler/source:Span", ptr %l21
  store %"compiler/source:Span" %t42, ptr %l6
  %t43 = getelementptr %"compiler/source:Span", ptr %l6, i32 0, i32 0
  %t44 = load i32, ptr %t43, !tbaa !23
  %t46 = icmp sge i32 %t44, 0
  br i1 %t46, label %bb13, label %bb14
bb13:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/check:Checker", ptr %t48, i32 0, i32 33
  %t51 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l5
  %t54 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %t50, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t51)
  store i1 %t54, ptr %l33
  br label %bb15
bb14:
  br label %bb34
bb15:
  %t55 = load i1, ptr %l33, !tbaa !21
  br i1 %t55, label %bb16, label %bb17
bb16:
  store %olang.scope zeroinitializer, ptr %s3
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/check:Checker", ptr %t56, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t61 = getelementptr %"compiler/generic:Program", ptr %t59, i32 0, i32 0
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = getelementptr %"compiler/load:Loader", ptr %t62, i32 0, i32 4
  %t65 = load ptr, ptr %t64, !tbaa !29
  store ptr %t65, ptr %l37, !tbaa !29
  %t66 = load i64, ptr %l1, !tbaa !24
  store i64 %t66, ptr %l38, !tbaa !24
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load %"compiler/source:Span", ptr %l6
  %t71 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %t67, %"compiler/source:Span" %t68)
  store { i64, [3 x i64] } %t71, ptr %l41
  br label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s4
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr %"compiler/check:Checker", ptr %t72, i32 0, i32 1
  %t75 = load ptr, ptr %t74, !tbaa !29
  %t77 = getelementptr %"compiler/generic:Program", ptr %t75, i32 0, i32 0
  %t78 = load ptr, ptr %t77, !tbaa !29
  %t80 = getelementptr %"compiler/load:Loader", ptr %t78, i32 0, i32 4
  %t81 = load ptr, ptr %t80, !tbaa !29
  store ptr %t81, ptr %l61, !tbaa !29
  %t82 = load i64, ptr %l1, !tbaa !24
  store i64 %t82, ptr %l62, !tbaa !24
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load %"compiler/source:Span", ptr %l6
  %t87 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %t83, %"compiler/source:Span" %t84)
  store { i64, [3 x i64] } %t87, ptr %l65
  br label %bb25
bb18:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 0
  %t90 = load i32, ptr %t89, !tbaa !23
  %t93 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t88, i32 %t90)
  store { i64, ptr } %t93, ptr %l44
  br label %bb19
bb19:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 2
  %t96 = load i32, ptr %t95, !tbaa !23
  %t99 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s3, ptr %t94, i32 %t96)
  store { i64, ptr } %t99, ptr %l47
  br label %bb20
bb20:
  %t100 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t100, 0
  %t102 = extractvalue { i64, ptr } %t100, 1
  %t103 = mul i64 %t101, 1
  %t104 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t103)
  call void @llvm.memcpy.p0.p0.i64(ptr %t104, ptr %t102, i64 %t103, i1 false)
  %t105 = insertvalue { i64, ptr } undef, i64 %t101, 0
  %t106 = insertvalue { i64, ptr } %t105, ptr %t104, 1
  store { i64, ptr } %t106, ptr %l48, !tbaa !27
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t108 = load i32, ptr %l3, !tbaa !23
  %t111 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s3, ptr %t107, i32 %t108)
  store { i64, ptr } %t111, ptr %l51
  br label %bb21
bb21:
  %t112 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t113 = extractvalue { i64, ptr } %t112, 0
  %t114 = extractvalue { i64, ptr } %t112, 1
  %t115 = mul i64 %t113, 1
  %t116 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t115)
  call void @llvm.memcpy.p0.p0.i64(ptr %t116, ptr %t114, i64 %t115, i1 false)
  %t117 = insertvalue { i64, ptr } undef, i64 %t113, 0
  %t118 = insertvalue { i64, ptr } %t117, ptr %t116, 1
  store { i64, ptr } %t118, ptr %l52, !tbaa !27
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t120 = load i32, ptr %l3, !tbaa !23
  %t123 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s3, ptr %t119, i32 %t120)
  store { i64, ptr } %t123, ptr %l55
  br label %bb22
bb22:
  %t124 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t125 = extractvalue { i64, ptr } %t124, 0
  %t126 = extractvalue { i64, ptr } %t124, 1
  %t127 = mul i64 %t125, 1
  %t128 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t127)
  call void @llvm.memcpy.p0.p0.i64(ptr %t128, ptr %t126, i64 %t127, i1 false)
  %t129 = insertvalue { i64, ptr } undef, i64 %t125, 0
  %t130 = insertvalue { i64, ptr } %t129, ptr %t128, 1
  %t131 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t132 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t133 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t135 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteLiteralRangeExpr(ptr %v0, ptr %s3, ptr %s3, ptr %s3, ptr %s3, { i64, ptr } %t131, { i64, ptr } %t132, { i64, ptr } %t133, { i64, ptr } %t130)
  store %"compiler/msgs:Msg" %t135, ptr %l57
  br label %bb23
bb23:
  %t136 = load ptr, ptr %l37, !tbaa !29
  %t137 = load i64, ptr %l38, !tbaa !24
  %t138 = load { i64, [3 x i64] }, ptr %l41
  %t139 = load %"compiler/msgs:Msg", ptr %l57
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %s3, ptr %t136, i64 %t137, { i64, [3 x i64] } %t138, %"compiler/msgs:Msg" %t139)
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s3)
  br label %bb33
bb25:
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t141 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 0
  %t142 = load i32, ptr %t141, !tbaa !23
  %t145 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t140, i32 %t142)
  store { i64, ptr } %t145, ptr %l68
  br label %bb26
bb26:
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t147 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 2
  %t148 = load i32, ptr %t147, !tbaa !23
  %t151 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s4, ptr %t146, i32 %t148)
  store { i64, ptr } %t151, ptr %l71
  br label %bb27
bb27:
  %t152 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t153 = extractvalue { i64, ptr } %t152, 0
  %t154 = extractvalue { i64, ptr } %t152, 1
  %t155 = mul i64 %t153, 1
  %t156 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t155)
  call void @llvm.memcpy.p0.p0.i64(ptr %t156, ptr %t154, i64 %t155, i1 false)
  %t157 = insertvalue { i64, ptr } undef, i64 %t153, 0
  %t158 = insertvalue { i64, ptr } %t157, ptr %t156, 1
  store { i64, ptr } %t158, ptr %l72, !tbaa !27
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t160 = load i32, ptr %l3, !tbaa !23
  %t163 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s4, ptr %t159, i32 %t160)
  store { i64, ptr } %t163, ptr %l75
  br label %bb28
bb28:
  %t164 = load { i64, ptr }, ptr %l75, !tbaa !27
  %t165 = extractvalue { i64, ptr } %t164, 0
  %t166 = extractvalue { i64, ptr } %t164, 1
  %t167 = mul i64 %t165, 1
  %t168 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t167)
  call void @llvm.memcpy.p0.p0.i64(ptr %t168, ptr %t166, i64 %t167, i1 false)
  %t169 = insertvalue { i64, ptr } undef, i64 %t165, 0
  %t170 = insertvalue { i64, ptr } %t169, ptr %t168, 1
  store { i64, ptr } %t170, ptr %l76, !tbaa !27
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t172 = load %"compiler/source:Span", ptr %l6
  %t175 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %t171, %"compiler/source:Span" %t172)
  store { i64, ptr } %t175, ptr %l79
  br label %bb29
bb29:
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t177 = load i32, ptr %l3, !tbaa !23
  %t180 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s4, ptr %t176, i32 %t177)
  store { i64, ptr } %t180, ptr %l82
  br label %bb30
bb30:
  %t181 = load { i64, ptr }, ptr %l82, !tbaa !27
  %t182 = extractvalue { i64, ptr } %t181, 0
  %t183 = extractvalue { i64, ptr } %t181, 1
  %t184 = mul i64 %t182, 1
  %t185 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t184)
  call void @llvm.memcpy.p0.p0.i64(ptr %t185, ptr %t183, i64 %t184, i1 false)
  %t186 = insertvalue { i64, ptr } undef, i64 %t182, 0
  %t187 = insertvalue { i64, ptr } %t186, ptr %t185, 1
  %t188 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t189 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t190 = load { i64, ptr }, ptr %l76, !tbaa !27
  %t191 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t193 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteLiteralRange(ptr %v0, ptr %s4, ptr %s4, ptr %v0, ptr %s4, ptr %s4, { i64, ptr } %t188, { i64, ptr } %t189, { i64, ptr } %t190, { i64, ptr } %t191, { i64, ptr } %t187)
  store %"compiler/msgs:Msg" %t193, ptr %l84
  br label %bb31
bb31:
  %t194 = load ptr, ptr %l61, !tbaa !29
  %t195 = load i64, ptr %l62, !tbaa !24
  %t196 = load { i64, [3 x i64] }, ptr %l65
  %t197 = load %"compiler/msgs:Msg", ptr %l84
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %s4, ptr %t194, i64 %t195, { i64, [3 x i64] } %t196, %"compiler/msgs:Msg" %t197)
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s4)
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb34:
  %t198 = load ptr, ptr %l0, !tbaa !29
  %t200 = getelementptr %"compiler/check:Checker", ptr %t198, i32 0, i32 1
  %t201 = load ptr, ptr %t200, !tbaa !29
  %t203 = getelementptr %"compiler/generic:Program", ptr %t201, i32 0, i32 0
  %t204 = load ptr, ptr %t203, !tbaa !29
  %t206 = getelementptr %"compiler/load:Loader", ptr %t204, i32 0, i32 4
  %t207 = load ptr, ptr %t206, !tbaa !29
  store ptr %t207, ptr %l88, !tbaa !29
  %t208 = load i64, ptr %l1, !tbaa !24
  store i64 %t208, ptr %l89, !tbaa !24
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t210 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 1
  %t211 = load %"compiler/source:Span", ptr %t210
  %t214 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %t209, %"compiler/source:Span" %t211)
  store { i64, [3 x i64] } %t214, ptr %l92
  br label %bb35
bb35:
  %t215 = load ptr, ptr %l0, !tbaa !29
  %t216 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 0
  %t217 = load i32, ptr %t216, !tbaa !23
  %t220 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t215, i32 %t217)
  store { i64, ptr } %t220, ptr %l95
  br label %bb36
bb36:
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t222 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 2
  %t223 = load i32, ptr %t222, !tbaa !23
  %t226 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t221, i32 %t223)
  store { i64, ptr } %t226, ptr %l98
  br label %bb37
bb37:
  %t227 = load { i64, ptr }, ptr %l98, !tbaa !27
  %t228 = extractvalue { i64, ptr } %t227, 0
  %t229 = extractvalue { i64, ptr } %t227, 1
  %t230 = mul i64 %t228, 1
  %t231 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t230)
  call void @llvm.memcpy.p0.p0.i64(ptr %t231, ptr %t229, i64 %t230, i1 false)
  %t232 = insertvalue { i64, ptr } undef, i64 %t228, 0
  %t233 = insertvalue { i64, ptr } %t232, ptr %t231, 1
  store { i64, ptr } %t233, ptr %l99, !tbaa !27
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t235 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 0
  %t236 = load i32, ptr %t235, !tbaa !23
  %t239 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t234, i32 %t236)
  store { i64, ptr } %t239, ptr %l102
  br label %bb38
bb38:
  %t240 = load ptr, ptr %l0, !tbaa !29
  %t241 = load i32, ptr %l3, !tbaa !23
  %t244 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t240, i32 %t241)
  store { i64, ptr } %t244, ptr %l105
  br label %bb39
bb39:
  %t245 = load { i64, ptr }, ptr %l105, !tbaa !27
  %t246 = extractvalue { i64, ptr } %t245, 0
  %t247 = extractvalue { i64, ptr } %t245, 1
  %t248 = mul i64 %t246, 1
  %t249 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t248)
  call void @llvm.memcpy.p0.p0.i64(ptr %t249, ptr %t247, i64 %t248, i1 false)
  %t250 = insertvalue { i64, ptr } undef, i64 %t246, 0
  %t251 = insertvalue { i64, ptr } %t250, ptr %t249, 1
  %t252 = load { i64, ptr }, ptr %l95, !tbaa !27
  %t253 = load { i64, ptr }, ptr %l99, !tbaa !27
  %t254 = load { i64, ptr }, ptr %l102, !tbaa !27
  %t256 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteLiteralLocal(ptr %v0, ptr %s0, ptr %v0, ptr %s0, ptr %s0, { i64, ptr } %t252, { i64, ptr } %t253, { i64, ptr } %t254, { i64, ptr } %t251)
  store %"compiler/msgs:Msg" %t256, ptr %l107
  br label %bb40
bb40:
  %t257 = load ptr, ptr %l88, !tbaa !29
  %t258 = load i64, ptr %l89, !tbaa !24
  %t259 = load { i64, [3 x i64] }, ptr %l92
  %t260 = load %"compiler/msgs:Msg", ptr %l107
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %s0, ptr %t257, i64 %t258, { i64, [3 x i64] } %t259, %"compiler/msgs:Msg" %t260)
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eloopCall(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, ptr %a3, { i64, ptr } %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i32
  %l10 = alloca %"compiler/generic:AnySlot"
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l15 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca ptr
  %l23 = alloca i64
  %l26 = alloca ptr
  %l29 = alloca i32
  %l32 = alloca i64
  %l33 = alloca ptr
  %l41 = alloca ptr
  %l44 = alloca i32
  %l45 = alloca i32
  %l49 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %l59 = alloca ptr
  %l60 = alloca %"compiler/source:Span"
  %l61 = alloca %"compiler/source:Span"
  %l62 = alloca i32
  %l68 = alloca ptr
  %l70 = alloca ptr
  %l75 = alloca ptr
  %l77 = alloca ptr
  %l78 = alloca %"compiler/source:Span"
  %l79 = alloca %"compiler/source:Span"
  %l80 = alloca i64
  %l82 = alloca ptr
  %l85 = alloca { i64, ptr }
  %l86 = alloca { i64, ptr }
  %l90 = alloca ptr
  %l92 = alloca ptr
  %l100 = alloca { i64, ptr }
  %l107 = alloca { i64, ptr }
  %l114 = alloca i32
  %l117 = alloca ptr
  %l122 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l126 = alloca i64
  %l130 = alloca i64
  %l133 = alloca i64
  %l153 = alloca ptr
  %l157 = alloca i32
  %l158 = alloca i32
  %l161 = alloca ptr
  %l165 = alloca i32
  %l172 = alloca i64
  %l174 = alloca i64
  %l179 = alloca i32
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca ptr
  %t95 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i64 %a2, ptr %l2
  store ptr %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t1)
  store ptr %t3, ptr %l26
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l26, !tbaa !29
  store ptr %t4, ptr %l5, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/check:Checker", ptr %t5, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePreludeType(ptr %v0, ptr %s0, ptr %s0, ptr %t8, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d41, i32 0, i32 1) }, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d42, i32 0, i32 1) })
  store i32 %t10, ptr %l29
  br label %bb2
bb2:
  %t11 = load i32, ptr %l29, !tbaa !23
  store i32 %t11, ptr %l6, !tbaa !23
  %t12 = load ptr, ptr %l5, !tbaa !29
  %t14 = getelementptr %"compiler/check:frame", ptr %t12, i32 0, i32 26
  %t16 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t14)
  store i64 %t16, ptr %l32
  br label %bb3
bb3:
  %t17 = load i64, ptr %l32, !tbaa !24
  store i64 %t17, ptr %l7, !tbaa !24
  %t18 = load ptr, ptr %l5, !tbaa !29
  store ptr %t18, ptr %l33, !tbaa !29
  %t19 = load ptr, ptr %l33, !tbaa !29
  %t20 = getelementptr %"compiler/check:frame", ptr %t19, i32 0, i32 15
  %t21 = load i64, ptr %t20, !tbaa !24
  %t23 = add i64 %t21, 1
  %t25 = load ptr, ptr %l33, !tbaa !29
  %t26 = getelementptr %"compiler/check:frame", ptr %t25, i32 0, i32 15
  store i64 %t23, ptr %t26, !tbaa !24
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/check:Checker", ptr %t27, i32 0, i32 41
  store i32 0, ptr %t29, !tbaa !23
  store ptr null, ptr %l8, !tbaa !29
  %t30 = load i64, ptr %l2, !tbaa !24
  %t32 = icmp slt i64 %t30, -1
  br i1 %t32, label %bb4, label %bb5
bb4:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/check:Checker", ptr %t34, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t39 = getelementptr %"compiler/generic:Program", ptr %t37, i32 0, i32 2
  store ptr %t39, ptr %l41, !tbaa !29
  %t40 = load ptr, ptr %l3, !tbaa !29
  %t43 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t40)
  store i32 %t43, ptr %l44
  br label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s2
  %t44 = load ptr, ptr %l0, !tbaa !29
  store ptr %t44, ptr %l77, !tbaa !29
  %t45 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t45, ptr %l78
  %t46 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t46, ptr %l79
  %t47 = load i64, ptr %l2, !tbaa !24
  store i64 %t47, ptr %l80, !tbaa !24
  %t48 = load ptr, ptr %l3, !tbaa !29
  store ptr %t48, ptr %l82, !tbaa !29
  %t50 = icmp sge i64 0, 0
  br i1 %t50, label %bb15, label %bb16
bb6:
  %t52 = load ptr, ptr %l41, !tbaa !29
  %t53 = load i32, ptr %l44, !tbaa !23
  %t54 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnyTrait(ptr %v0, ptr %t52, i32 %t53)
  store i32 %t54, ptr %l45
  br label %bb7
bb7:
  %t55 = load i32, ptr %l45, !tbaa !23
  store i32 %t55, ptr %l9, !tbaa !23
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/check:Checker", ptr %t56, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t60 = load i32, ptr %l9, !tbaa !23
  %t63 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnySlots(ptr %v0, ptr %t59, i32 %t60)
  store { i64, ptr } %t63, ptr %l49
  br label %bb8
bb8:
  %t64 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t64, ptr %l50, !tbaa !27
  %t65 = load i64, ptr %l2, !tbaa !24
  %t67 = sub i64 -2, %t65
  %t69 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !27
  %t71 = getelementptr %"compiler/generic:AnySlot", ptr %t70, i64 %t67
  %t72 = load %"compiler/generic:AnySlot", ptr %t71
  store %"compiler/generic:AnySlot" %t72, ptr %l10
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load i32, ptr %l9, !tbaa !23
  %t76 = load i64, ptr %l2, !tbaa !24
  %t78 = sub i64 -2, %t76
  %t79 = load %"compiler/source:Span", ptr %l1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eslotCall(ptr %v0, ptr %t74, i32 %t75, i64 %t78, %"compiler/source:Span" %t79)
  br label %bb9
bb9:
  %t84 = load ptr, ptr %l0, !tbaa !29
  store ptr %t84, ptr %l59, !tbaa !29
  %t85 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t85, ptr %l60
  %t86 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t86, ptr %l61
  %t87 = getelementptr %"compiler/generic:AnySlot", ptr %l10, i32 0, i32 5
  %t88 = load i32, ptr %t87, !tbaa !23
  store i32 %t88, ptr %l62, !tbaa !23
  %t89 = load i32, ptr %l9, !tbaa !23
  %t90 = load i64, ptr %l2, !tbaa !24
  %t92 = sub i64 -2, %t90
  %t93 = getelementptr %"compiler/generic:AnySlot", ptr %l10, i32 0, i32 5
  %t94 = load i32, ptr %t93, !tbaa !23
  store { i64, [3 x i64] } zeroinitializer, ptr %t95
  %t96 = getelementptr { i64, [3 x i64] }, ptr %t95, i32 0, i32 0
  store i64 3, ptr %t96
  %t98 = insertvalue { i32, i64, i32 } undef, i32 %t89, 0
  %t100 = insertvalue { i32, i64, i32 } %t98, i64 %t92, 1
  %t102 = insertvalue { i32, i64, i32 } %t100, i32 %t94, 2
  %t103 = getelementptr { i64, [3 x i64] }, ptr %t95, i32 0, i32 1
  store { i32, i64, i32 } %t102, ptr %t103
  %t104 = load { i64, [3 x i64] }, ptr %t95
  %t106 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t104, ptr %t106
  store ptr %t106, ptr %l68, !tbaa !29
  %t107 = load ptr, ptr %l3, !tbaa !29
  store ptr %t107, ptr %l70, !tbaa !29
  %t109 = icmp sge i64 0, 0
  br i1 %t109, label %bb10, label %bb11
bb10:
  %t111 = icmp sle i64 0, 1152921504606846975
  br i1 %t111, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_652199a1d15cfac6_f2a0b86627c88902)
  unreachable
bb12:
  %t113 = mul i64 0, 8
  %t114 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t113)
  %t115 = insertvalue { i64, ptr } undef, i64 0, 0
  %t116 = insertvalue { i64, ptr } %t115, ptr %t114, 1
  %t117 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t118 = load ptr, ptr %l59, !tbaa !29
  %t119 = load %"compiler/source:Span", ptr %l60
  %t120 = load %"compiler/source:Span", ptr %l61
  %t121 = load i32, ptr %l62, !tbaa !23
  %t122 = load ptr, ptr %l68, !tbaa !29
  %t123 = load ptr, ptr %l70, !tbaa !29
  %t126 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallBody(ptr %v0, ptr %v0, ptr %t118, %"compiler/source:Span" %t119, %"compiler/source:Span" %t120, i32 %t121, ptr %t122, i64 -1, ptr %t123, { i64, ptr } %t116, { i64, ptr } %t117)
  store ptr %t126, ptr %l75
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_652199a1d15cfac6_f2a0b86627c88902)
  unreachable
bb14:
  %t127 = load ptr, ptr %l75, !tbaa !29
  store ptr %t127, ptr %l8, !tbaa !29
  br label %bb24
bb15:
  %t129 = icmp sle i64 0, 1152921504606846975
  br i1 %t129, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_7509e56452997e5b_fb360af196d85db7)
  unreachable
bb17:
  %t131 = mul i64 0, 8
  %t132 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t131)
  %t133 = insertvalue { i64, ptr } undef, i64 0, 0
  %t134 = insertvalue { i64, ptr } %t133, ptr %t132, 1
  store { i64, ptr } %t134, ptr %l85, !tbaa !27
  %t135 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t135, ptr %l86, !tbaa !27
  %t136 = icmp sge i64 0, 0
  br i1 %t136, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_7509e56452997e5b_fb360af196d85db7)
  unreachable
bb19:
  %t138 = icmp sle i64 0, 2305843009213693951
  br i1 %t138, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_ff81ff8210117a78_6f7a62fdc976c914)
  unreachable
bb21:
  %t140 = mul i64 0, 4
  %t141 = call ptr @__olang_scope_alloc_zeroed(ptr %s2, i64 %t140)
  %t142 = insertvalue { i64, ptr } undef, i64 0, 0
  %t143 = insertvalue { i64, ptr } %t142, ptr %t141, 1
  %t144 = load ptr, ptr %l77, !tbaa !29
  %t145 = load %"compiler/source:Span", ptr %l78
  %t146 = load %"compiler/source:Span", ptr %l79
  %t147 = load i64, ptr %l80, !tbaa !24
  %t148 = load ptr, ptr %l82, !tbaa !29
  %t149 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t150 = load { i64, ptr }, ptr %l86, !tbaa !27
  %t152 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v0, ptr %s2, ptr %t144, %"compiler/source:Span" %t145, %"compiler/source:Span" %t146, i64 %t147, ptr %t148, { i64, ptr } %t149, { i64, ptr } %t150, { i64, ptr } %t143)
  store ptr %t152, ptr %l90
  br label %bb23
bb22:
  call void @__olang_check_failed(ptr @olang_loc_ff81ff8210117a78_6f7a62fdc976c914)
  unreachable
bb23:
  %t153 = load ptr, ptr %l90, !tbaa !29
  store ptr %t153, ptr %l8, !tbaa !29
  call void @__olang_scope_close(ptr %s2)
  br label %bb24
bb24:
  %t155 = load ptr, ptr %l5, !tbaa !29
  store ptr %t155, ptr %l92, !tbaa !29
  %t156 = load ptr, ptr %l92, !tbaa !29
  %t157 = getelementptr %"compiler/check:frame", ptr %t156, i32 0, i32 15
  %t158 = load i64, ptr %t157, !tbaa !24
  %t160 = sub i64 %t158, 1
  %t162 = load ptr, ptr %l92, !tbaa !29
  %t163 = getelementptr %"compiler/check:frame", ptr %t162, i32 0, i32 15
  store i64 %t160, ptr %t163, !tbaa !24
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t166 = getelementptr %"compiler/check:Checker", ptr %t164, i32 0, i32 1
  %t167 = load ptr, ptr %t166, !tbaa !29
  %t169 = getelementptr %"compiler/generic:Program", ptr %t167, i32 0, i32 2
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t172 = getelementptr %"compiler/check:Checker", ptr %t170, i32 0, i32 41
  %t173 = load i32, ptr %t172, !tbaa !23
  %t176 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t169, i32 %t173)
  store { i64, ptr } %t176, ptr %l100
  br label %bb25
bb25:
  %t177 = load { i64, ptr }, ptr %l100, !tbaa !27
  store { i64, ptr } %t177, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t178 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t180 = extractvalue { i64, ptr } %t178, 0
  store i64 %t180, ptr %l13, !tbaa !24
  br label %bb26
bb26:
  %t182 = load i64, ptr %l12, !tbaa !24
  %t183 = load i64, ptr %l13, !tbaa !24
  %t186 = icmp slt i64 %t182, %t183
  %t188 = xor i1 %t186, true
  br i1 %t188, label %bb27, label %bb28
bb27:
  br label %bb35
bb28:
  br label %bb29
bb29:
  %t190 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t190, ptr %l107, !tbaa !27
  %t191 = load i64, ptr %l12, !tbaa !24
  %t193 = getelementptr { i64, ptr }, ptr %l107, i32 0, i32 1
  %t194 = load ptr, ptr %t193, !tbaa !27
  %t195 = getelementptr i32, ptr %t194, i64 %t191
  %t196 = load i32, ptr %t195, !tbaa !33
  %t198 = load ptr, ptr %l0, !tbaa !29
  %t200 = getelementptr %"compiler/check:Checker", ptr %t198, i32 0, i32 1
  %t201 = load ptr, ptr %t200, !tbaa !29
  %t203 = getelementptr %"compiler/generic:Program", ptr %t201, i32 0, i32 2
  %t207 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t203, i32 %t196)
  store i32 %t207, ptr %l114
  br label %bb30
bb30:
  %t208 = load i32, ptr %l6, !tbaa !23
  %t209 = load i32, ptr %l114, !tbaa !23
  %t211 = icmp ne i32 %t209, %t208
  br i1 %t211, label %bb31, label %bb32
bb31:
  %t213 = load ptr, ptr %l5, !tbaa !29
  store ptr %t213, ptr %l117, !tbaa !29
  %t214 = load ptr, ptr %l117, !tbaa !29
  %t215 = getelementptr %"compiler/check:frame", ptr %t214, i32 0, i32 17
  %t216 = load i64, ptr %t215, !tbaa !24
  %t218 = add i64 %t216, 1
  %t220 = load ptr, ptr %l117, !tbaa !29
  %t221 = getelementptr %"compiler/check:frame", ptr %t220, i32 0, i32 17
  store i64 %t218, ptr %t221, !tbaa !24
  br label %bb33
bb32:
  br label %bb33
bb33:
  br label %bb34
bb34:
  %t222 = load i64, ptr %l12, !tbaa !24
  %t224 = add i64 %t222, 1
  store i64 %t224, ptr %l12, !tbaa !24
  br label %bb26
bb35:
  %t226 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t226, ptr %l122
  br label %bb36
bb36:
  %t227 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l122
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t227, ptr %l15
  %t228 = load i64, ptr %l7, !tbaa !24
  store i64 %t228, ptr %l16, !tbaa !24
  %t230 = load ptr, ptr %l5, !tbaa !29
  %t232 = getelementptr %"compiler/check:frame", ptr %t230, i32 0, i32 26
  %t234 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t232)
  store i64 %t234, ptr %l126
  br label %bb37
bb37:
  %t235 = load i64, ptr %l126, !tbaa !24
  store i64 %t235, ptr %l17, !tbaa !24
  store i64 1, ptr %l18, !tbaa !24
  %t236 = load i64, ptr %l17, !tbaa !24
  %t237 = load i64, ptr %l16, !tbaa !24
  %t240 = icmp sgt i64 %t236, %t237
  br i1 %t240, label %bb38, label %bb39
bb38:
  %t242 = load i64, ptr %l18, !tbaa !24
  %t244 = icmp sgt i64 %t242, 0
  br i1 %t244, label %bb40, label %bb41
bb39:
  store i64 0, ptr %l130, !tbaa !24
  br label %bb43
bb40:
  %t246 = load i64, ptr %l17, !tbaa !24
  %t247 = load i64, ptr %l16, !tbaa !24
  %t250 = sub i64 %t246, %t247
  %t251 = load i64, ptr %l18, !tbaa !24
  %t254 = add i64 %t250, %t251
  %t256 = sub i64 %t254, 1
  %t257 = load i64, ptr %l18, !tbaa !24
  %t260 = sdiv i64 %t256, %t257
  store i64 %t260, ptr %l133, !tbaa !24
  br label %bb42
bb41:
  store i64 0, ptr %l133, !tbaa !24
  br label %bb42
bb42:
  %t262 = load i64, ptr %l133, !tbaa !24
  store i64 %t262, ptr %l130, !tbaa !24
  br label %bb43
bb43:
  %t263 = load i64, ptr %l130, !tbaa !24
  store i64 %t263, ptr %l19, !tbaa !24
  store i64 0, ptr %l20, !tbaa !24
  br label %bb44
bb44:
  %t264 = load i64, ptr %l20, !tbaa !24
  %t265 = load i64, ptr %l19, !tbaa !24
  %t268 = icmp slt i64 %t264, %t265
  %t270 = xor i1 %t268, true
  br i1 %t270, label %bb45, label %bb46
bb45:
  br label %bb56
bb46:
  br label %bb47
bb47:
  %t272 = load i64, ptr %l16, !tbaa !24
  %t273 = load i64, ptr %l20, !tbaa !24
  %t274 = load i64, ptr %l18, !tbaa !24
  %t277 = mul i64 %t273, %t274
  %t280 = add i64 %t272, %t277
  store i64 %t280, ptr %l21, !tbaa !24
  %t282 = load ptr, ptr %l0, !tbaa !29
  %t284 = getelementptr %"compiler/check:Checker", ptr %t282, i32 0, i32 1
  %t285 = load ptr, ptr %t284, !tbaa !29
  %t287 = getelementptr %"compiler/generic:Program", ptr %t285, i32 0, i32 2
  store ptr %t287, ptr %l153, !tbaa !29
  %t288 = load ptr, ptr %l5, !tbaa !29
  %t290 = getelementptr %"compiler/check:frame", ptr %t288, i32 0, i32 26
  %t291 = load i64, ptr %l21, !tbaa !24
  %t294 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t290, i64 %t291)
  store i32 %t294, ptr %l157
  br label %bb48
bb48:
  %t295 = load ptr, ptr %l153, !tbaa !29
  %t296 = load i32, ptr %l157, !tbaa !23
  %t297 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t295, i32 %t296)
  store i32 %t297, ptr %l158
  br label %bb49
bb49:
  %t298 = load i32, ptr %l6, !tbaa !23
  %t299 = load i32, ptr %l158, !tbaa !23
  %t301 = icmp ne i32 %t299, %t298
  br i1 %t301, label %bb50, label %bb51
bb50:
  store ptr %l15, ptr %l161, !tbaa !29
  %t303 = load ptr, ptr %l5, !tbaa !29
  %t305 = getelementptr %"compiler/check:frame", ptr %t303, i32 0, i32 26
  %t306 = load i64, ptr %l21, !tbaa !24
  %t309 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t305, i64 %t306)
  store i32 %t309, ptr %l165
  br label %bb52
bb51:
  br label %bb54
bb52:
  %t310 = load ptr, ptr %l161, !tbaa !29
  %t311 = load i32, ptr %l165, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t310, i32 %t311)
  br label %bb53
bb53:
  br label %bb54
bb54:
  br label %bb55
bb55:
  %t312 = load i64, ptr %l20, !tbaa !24
  %t314 = add i64 %t312, 1
  store i64 %t314, ptr %l20, !tbaa !24
  br label %bb44
bb56:
  %t316 = load ptr, ptr %l5, !tbaa !29
  %t318 = getelementptr %"compiler/check:frame", ptr %t316, i32 0, i32 26
  %t319 = load i64, ptr %l7, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eTruncate_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t318, i64 %t319)
  br label %bb57
bb57:
  store ptr %l15, ptr %l22, !tbaa !29
  store i64 0, ptr %l23, !tbaa !24
  br label %bb58
bb58:
  %t323 = load i64, ptr %l23, !tbaa !24
  store i64 %t323, ptr %l172, !tbaa !24
  %t324 = load ptr, ptr %l22, !tbaa !29
  %t326 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t324)
  store i64 %t326, ptr %l174
  br label %bb59
bb59:
  %t327 = load i64, ptr %l172, !tbaa !24
  %t328 = load i64, ptr %l174, !tbaa !24
  %t329 = icmp slt i64 %t327, %t328
  %t331 = xor i1 %t329, true
  br i1 %t331, label %bb60, label %bb61
bb60:
  br label %bb66
bb61:
  br label %bb62
bb62:
  %t333 = load ptr, ptr %l22, !tbaa !29
  %t334 = load i64, ptr %l23, !tbaa !24
  %t337 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t333, i64 %t334)
  store i32 %t337, ptr %l179
  br label %bb63
bb63:
  %t338 = load i32, ptr %l179, !tbaa !23
  %t339 = load ptr, ptr %l5, !tbaa !29
  %t341 = getelementptr %"compiler/check:frame", ptr %t339, i32 0, i32 26
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t341, i32 %t338)
  br label %bb64
bb64:
  br label %bb65
bb65:
  %t345 = load i64, ptr %l23, !tbaa !24
  %t347 = add i64 %t345, 1
  store i64 %t347, ptr %l23, !tbaa !24
  br label %bb58
bb66:
  %t349 = load ptr, ptr %l8, !tbaa !29
  %t351 = icmp eq ptr %t349, null
  br i1 %t351, label %bb67, label %bb68
bb67:
  call void @__olang_check_failed(ptr @olang_loc_77a5603a1298311f_4bb819fe8c7bb9e3)
  unreachable
bb68:
  br label %bb69
bb69:
  %t353 = load ptr, ptr %l8, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t353, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ematchElse(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, i32 %a2, ptr %a3, ptr %a4, i1 %a5, i1 %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l5 = alloca i1
  %l6 = alloca i1
  %l7 = alloca i64
  %lp8 = alloca ptr
  %l11 = alloca i64
  %l13 = alloca i1
  %l31 = alloca ptr
  %l35 = alloca i32
  %l39 = alloca { i64, ptr }
  %l40 = alloca %"compiler/typed:Block"
  %l42 = alloca %"compiler/source:Span"
  %l47 = alloca %"compiler/typed:Arm"
  %rv = alloca ptr
  %t19 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i1 %a5, ptr %l5
  store i1 %a6, ptr %l6
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 37
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l11
  br label %bb1
bb1:
  %t6 = load i64, ptr %l11, !tbaa !24
  store i64 %t6, ptr %l7, !tbaa !24
  %t7 = load i1, ptr %l5, !tbaa !21
  br i1 %t7, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb4
bb3:
  %t9 = load i1, ptr %l6, !tbaa !21
  store i1 %t9, ptr %l13, !tbaa !21
  br label %bb4
bb4:
  %t11 = load i1, ptr %l13, !tbaa !21
  br i1 %t11, label %bb5, label %bb6
bb5:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/check:Checker", ptr %t12, i32 0, i32 37
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr %"compiler/ast:Match", ptr %t15, i32 0, i32 0
  %t18 = load %"compiler/source:Span", ptr %t17
  store { i64, [3 x i64] } zeroinitializer, ptr %t19
  %t20 = getelementptr { i64, [3 x i64] }, ptr %t19, i32 0, i32 0
  store i64 9, ptr %t20
  %t22 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t18, 0
  %t24 = insertvalue { %"compiler/source:Span", i32, ptr } %t22, i32 0, 1
  %t25 = insertvalue { %"compiler/source:Span", i32, ptr } %t24, ptr null, 2
  %t26 = getelementptr { i64, [3 x i64] }, ptr %t19, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t25, ptr %t26
  %t27 = load { i64, [3 x i64] }, ptr %t19
  %t29 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t27, ptr %t29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t14, ptr %t29)
  br label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb8
bb8:
  %t32 = load i1, ptr %l5, !tbaa !21
  %t34 = xor i1 %t32, true
  br i1 %t34, label %bb9, label %bb10
bb9:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load ptr, ptr %l1, !tbaa !29
  %t41 = load i1, ptr %l6, !tbaa !21
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esayUncovered(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t36, ptr %t37, i32 %a2, ptr %a3, ptr %a4, i1 %t41)
  br label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t48)
  store ptr %t50, ptr %l31
  br label %bb13
bb13:
  %t51 = load ptr, ptr %l31, !tbaa !29
  %t53 = getelementptr %"compiler/check:frame", ptr %t51, i32 0, i32 7
  %t54 = load i64, ptr %t53, !tbaa !24
  %t56 = trunc i64 %t54 to i32
  store i32 %t56, ptr %l35, !tbaa !23
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/check:Checker", ptr %t58, i32 0, i32 37
  %t61 = load i64, ptr %l7, !tbaa !24
  %t64 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t60, i64 %t61)
  store { i64, ptr } %t64, ptr %l39
  br label %bb14
bb14:
  %t65 = load i32, ptr %l35, !tbaa !23
  %t66 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t67 = call %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v0, i32 %t65, { i64, ptr } %t66)
  store %"compiler/typed:Block" %t67, ptr %l40
  br label %bb15
bb15:
  %t68 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store ptr %t68, ptr %lp8
  %t69 = load %"compiler/typed:Block", ptr %l40
  %t70 = load ptr, ptr %lp8
  store %"compiler/typed:Block" %t69, ptr %t70
  %t71 = load ptr, ptr %l1, !tbaa !29
  %t73 = getelementptr %"compiler/ast:Match", ptr %t71, i32 0, i32 0
  %t74 = load %"compiler/source:Span", ptr %t73
  store %"compiler/source:Span" %t74, ptr %l42
  %t75 = icmp sge i64 0, 0
  br i1 %t75, label %bb16, label %bb17
bb16:
  %t77 = icmp sle i64 0, 1152921504606846975
  br i1 %t77, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_3cc47694b244d9ce_439392ee5cdf31e2)
  unreachable
bb18:
  %t79 = mul i64 0, 8
  %t80 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t79)
  %t81 = insertvalue { i64, ptr } undef, i64 0, 0
  %t82 = insertvalue { i64, ptr } %t81, ptr %t80, 1
  %t83 = load ptr, ptr %lp8
  %t84 = load %"compiler/source:Span", ptr %l42
  %t87 = call %"compiler/typed:Arm" @compiler_2ftyped_3aArm_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, %"compiler/source:Span" %t84, { i64, ptr } %t82, ptr null, ptr %t83, ptr null)
  store %"compiler/typed:Arm" %t87, ptr %l47
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_3cc47694b244d9ce_439392ee5cdf31e2)
  unreachable
bb20:
  %t88 = load %"compiler/typed:Arm", ptr %l47
  %t89 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store %"compiler/typed:Arm" %t88, ptr %t89
  store ptr %t89, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ematchOnType(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca i64
  %l21 = alloca %"compiler/check:typeCase"
  %l22 = alloca %"compiler/check:typeCase"
  %l23 = alloca ptr
  %l24 = alloca i64
  %l26 = alloca ptr
  %l27 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l31 = alloca i32
  %l38 = alloca ptr
  %l41 = alloca %"compiler/source:Span"
  %l42 = alloca %"compiler/msgs:Msg"
  %l43 = alloca i64
  %l53 = alloca { i64, ptr }
  %l60 = alloca ptr
  %l61 = alloca ptr
  %l67 = alloca %"compiler/source:Span"
  %l69 = alloca %"compiler/source:Span"
  %l70 = alloca %"compiler/msgs:Msg"
  %l71 = alloca i64
  %l74 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l81 = alloca i64
  %l84 = alloca i64
  %l103 = alloca { i64, ptr }
  %l113 = alloca { i64, ptr }
  %l118 = alloca i1
  %l120 = alloca i64
  %l122 = alloca i64
  %l127 = alloca %"compiler/check:typeCase"
  %l132 = alloca ptr
  %l133 = alloca ptr
  %l135 = alloca %"compiler/source:Span"
  %l136 = alloca { i64, [3 x i64] }
  %l137 = alloca %"compiler/msgs:Msg"
  %l138 = alloca i64
  %l141 = alloca ptr
  %l143 = alloca %"compiler/check:typeCase"
  %l149 = alloca %"compiler/check:typeCase"
  %l154 = alloca i64
  %l156 = alloca i64
  %l161 = alloca %"compiler/check:typeCase"
  %l165 = alloca i1
  %l169 = alloca ptr
  %l170 = alloca ptr
  %l172 = alloca %"compiler/source:Span"
  %l173 = alloca { i64, [3 x i64] }
  %l174 = alloca %"compiler/msgs:Msg"
  %l175 = alloca i64
  %l186 = alloca i1
  %l195 = alloca ptr
  %l198 = alloca %"compiler/source:Span"
  %l201 = alloca { i64, ptr }
  %l203 = alloca %"compiler/msgs:Msg"
  %l204 = alloca i64
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l26, !tbaa !29
  %t2 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l27
  br label %bb1
bb1:
  %t3 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l27
  %t4 = load ptr, ptr %l26, !tbaa !29
  %t5 = getelementptr %"compiler/check:Checker", ptr %t4, i32 0, i32 124
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %t5
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load ptr, ptr %l1, !tbaa !29
  %t9 = getelementptr %"compiler/ast:Match", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t13 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflType(ptr %v0, ptr %v1, ptr %t6, ptr %t10)
  store i32 %t13, ptr %l31
  br label %bb2
bb2:
  %t14 = load i32, ptr %l31, !tbaa !23
  store i32 %t14, ptr %l2, !tbaa !23
  %t15 = load i32, ptr %l2, !tbaa !23
  %t16 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t19 = icmp eq i32 %t15, %t16
  br i1 %t19, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s0)
  store i64 -2, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t22 = load i32, ptr %l2, !tbaa !23
  %t24 = icmp slt i32 %t22, 0
  br i1 %t24, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s2
  %t26 = load ptr, ptr %l0, !tbaa !29
  store ptr %t26, ptr %l38, !tbaa !29
  %t27 = load ptr, ptr %l1, !tbaa !29
  %t29 = getelementptr %"compiler/ast:Match", ptr %t27, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !29
  %t32 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t30)
  store %"compiler/source:Span" %t32, ptr %l41
  br label %bb8
bb7:
  br label %bb11
bb8:
  %t33 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eReflMatchSubject(ptr %s2)
  store %"compiler/msgs:Msg" %t33, ptr %l42
  br label %bb9
bb9:
  %t34 = load ptr, ptr %l38, !tbaa !29
  %t35 = load %"compiler/source:Span", ptr %l41
  %t36 = load %"compiler/msgs:Msg", ptr %l42
  %t37 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s2, ptr %t34, %"compiler/source:Span" %t35, %"compiler/msgs:Msg" %t36)
  store i64 %t37, ptr %l43
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store i64 -2, ptr %rv
  br label %ret
bb11:
  %t39 = load ptr, ptr %l1, !tbaa !29
  %t41 = getelementptr %"compiler/ast:Match", ptr %t39, i32 0, i32 3
  %t42 = load { i64, ptr }, ptr %t41, !tbaa !27
  store { i64, ptr } %t42, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t44 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t44, 0
  store i64 %t46, ptr %l5, !tbaa !24
  br label %bb12
bb12:
  %t48 = load i64, ptr %l4, !tbaa !24
  %t49 = load i64, ptr %l5, !tbaa !24
  %t52 = icmp slt i64 %t48, %t49
  %t54 = xor i1 %t52, true
  br i1 %t54, label %bb13, label %bb14
bb13:
  br label %bb27
bb14:
  br label %bb15
bb15:
  %t56 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t56, ptr %l53, !tbaa !27
  %t57 = load i64, ptr %l4, !tbaa !24
  %t59 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = getelementptr ptr, ptr %t60, i64 %t57
  %t62 = load ptr, ptr %t61, !tbaa !39
  store ptr %t62, ptr %l6, !tbaa !29
  %t64 = load ptr, ptr %l6, !tbaa !29
  %t66 = getelementptr %"compiler/ast:Case", ptr %t64, i32 0, i32 3
  %t67 = load ptr, ptr %t66, !tbaa !29
  %t69 = icmp eq ptr %t67, null
  %t71 = xor i1 %t69, true
  br i1 %t71, label %bb16, label %bb17
bb16:
  store %olang.scope zeroinitializer, ptr %s5
  %t73 = load ptr, ptr %l0, !tbaa !29
  store ptr %t73, ptr %l60, !tbaa !29
  %t74 = load ptr, ptr %l0, !tbaa !29
  store ptr %t74, ptr %l61, !tbaa !29
  %t75 = load ptr, ptr %l6, !tbaa !29
  %t77 = getelementptr %"compiler/ast:Case", ptr %t75, i32 0, i32 3
  %t78 = load ptr, ptr %t77, !tbaa !29
  %t80 = icmp eq ptr %t78, null
  br i1 %t80, label %bb18, label %bb19
bb17:
  br label %bb25
bb18:
  call void @__olang_check_failed(ptr @olang_loc_775dfd67c7206a52_c2d8bc16e2444876)
  unreachable
bb19:
  br label %bb20
bb20:
  %t82 = load ptr, ptr %l6, !tbaa !29
  %t84 = getelementptr %"compiler/ast:Case", ptr %t82, i32 0, i32 3
  %t85 = load ptr, ptr %t84, !tbaa !29
  %t87 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t85)
  store %"compiler/source:Span" %t87, ptr %l67
  br label %bb21
bb21:
  %t88 = getelementptr %"compiler/source:Span", ptr %l67, i32 0, i32 0
  %t89 = load i32, ptr %t88, !tbaa !23
  %t90 = load ptr, ptr %l61, !tbaa !29
  %t92 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewordBefore(ptr %v0, ptr %s5, ptr %t90, i32 %t89, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d43, i32 0, i32 1) })
  store %"compiler/source:Span" %t92, ptr %l69
  br label %bb22
bb22:
  %t93 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeMatchGuard(ptr %s5)
  store %"compiler/msgs:Msg" %t93, ptr %l70
  br label %bb23
bb23:
  %t94 = load ptr, ptr %l60, !tbaa !29
  %t95 = load %"compiler/source:Span", ptr %l69
  %t96 = load %"compiler/msgs:Msg", ptr %l70
  %t97 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s5, ptr %t94, %"compiler/source:Span" %t95, %"compiler/msgs:Msg" %t96)
  store i64 %t97, ptr %l71
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s5)
  br label %bb25
bb25:
  br label %bb26
bb26:
  %t98 = load i64, ptr %l4, !tbaa !24
  %t100 = add i64 %t98, 1
  store i64 %t100, ptr %l4, !tbaa !24
  br label %bb12
bb27:
  store i64 -1, ptr %l7, !tbaa !24
  %t102 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3atypeCase_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t102, ptr %l74
  br label %bb28
bb28:
  %t103 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l74
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t103, ptr %l8
  store i64 0, ptr %l9, !tbaa !24
  %t104 = load ptr, ptr %l1, !tbaa !29
  %t106 = getelementptr %"compiler/ast:Match", ptr %t104, i32 0, i32 3
  %t107 = load { i64, ptr }, ptr %t106, !tbaa !27
  %t109 = extractvalue { i64, ptr } %t107, 0
  store i64 %t109, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t111 = load i64, ptr %l10, !tbaa !24
  %t112 = load i64, ptr %l9, !tbaa !24
  %t115 = icmp sgt i64 %t111, %t112
  br i1 %t115, label %bb29, label %bb30
bb29:
  %t117 = load i64, ptr %l11, !tbaa !24
  %t119 = icmp sgt i64 %t117, 0
  br i1 %t119, label %bb31, label %bb32
bb30:
  store i64 0, ptr %l81, !tbaa !24
  br label %bb34
bb31:
  %t121 = load i64, ptr %l10, !tbaa !24
  %t122 = load i64, ptr %l9, !tbaa !24
  %t125 = sub i64 %t121, %t122
  %t126 = load i64, ptr %l11, !tbaa !24
  %t129 = add i64 %t125, %t126
  %t131 = sub i64 %t129, 1
  %t132 = load i64, ptr %l11, !tbaa !24
  %t135 = sdiv i64 %t131, %t132
  store i64 %t135, ptr %l84, !tbaa !24
  br label %bb33
bb32:
  store i64 0, ptr %l84, !tbaa !24
  br label %bb33
bb33:
  %t137 = load i64, ptr %l84, !tbaa !24
  store i64 %t137, ptr %l81, !tbaa !24
  br label %bb34
bb34:
  %t138 = load i64, ptr %l81, !tbaa !24
  store i64 %t138, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb35
bb35:
  %t139 = load i64, ptr %l13, !tbaa !24
  %t140 = load i64, ptr %l12, !tbaa !24
  %t143 = icmp slt i64 %t139, %t140
  %t145 = xor i1 %t143, true
  br i1 %t145, label %bb36, label %bb37
bb36:
  br label %bb98
bb37:
  br label %bb38
bb38:
  %t147 = load i64, ptr %l9, !tbaa !24
  %t148 = load i64, ptr %l13, !tbaa !24
  %t149 = load i64, ptr %l11, !tbaa !24
  %t152 = mul i64 %t148, %t149
  %t155 = add i64 %t147, %t152
  store i64 %t155, ptr %l14, !tbaa !24
  %t157 = load ptr, ptr %l1, !tbaa !29
  %t159 = getelementptr %"compiler/ast:Match", ptr %t157, i32 0, i32 3
  %t160 = load { i64, ptr }, ptr %t159, !tbaa !27
  store { i64, ptr } %t160, ptr %l103, !tbaa !27
  %t161 = load i64, ptr %l14, !tbaa !24
  %t163 = getelementptr { i64, ptr }, ptr %l103, i32 0, i32 1
  %t164 = load ptr, ptr %t163, !tbaa !27
  %t165 = getelementptr ptr, ptr %t164, i64 %t161
  %t166 = load ptr, ptr %t165, !tbaa !39
  %t168 = getelementptr %"compiler/ast:Case", ptr %t166, i32 0, i32 2
  %t169 = load { i64, ptr }, ptr %t168, !tbaa !27
  store { i64, ptr } %t169, ptr %l15, !tbaa !27
  store i64 0, ptr %l16, !tbaa !24
  %t171 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t173 = extractvalue { i64, ptr } %t171, 0
  store i64 %t173, ptr %l17, !tbaa !24
  br label %bb39
bb39:
  %t175 = load i64, ptr %l16, !tbaa !24
  %t176 = load i64, ptr %l17, !tbaa !24
  %t179 = icmp slt i64 %t175, %t176
  %t181 = xor i1 %t179, true
  br i1 %t181, label %bb40, label %bb41
bb40:
  br label %bb96
bb41:
  br label %bb42
bb42:
  %t183 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t183, ptr %l113, !tbaa !27
  %t184 = load i64, ptr %l16, !tbaa !24
  %t186 = getelementptr { i64, ptr }, ptr %l113, i32 0, i32 1
  %t187 = load ptr, ptr %t186, !tbaa !27
  %t188 = getelementptr ptr, ptr %t187, i64 %t184
  %t189 = load ptr, ptr %t188, !tbaa !39
  store ptr %t189, ptr %l18, !tbaa !29
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t192 = load ptr, ptr %l18, !tbaa !29
  %t195 = call i1 @compiler_2fcheck_2eisWildType(ptr %v0, ptr %v1, ptr %t191, ptr %t192)
  store i1 %t195, ptr %l118
  br label %bb43
bb43:
  %t196 = load i1, ptr %l118, !tbaa !21
  br i1 %t196, label %bb44, label %bb45
bb44:
  store %olang.scope zeroinitializer, ptr %s11
  store ptr %l8, ptr %l19, !tbaa !29
  store i64 0, ptr %l20, !tbaa !24
  br label %bb46
bb45:
  br label %bb66
bb46:
  %t198 = load i64, ptr %l20, !tbaa !24
  store i64 %t198, ptr %l120, !tbaa !24
  %t199 = load ptr, ptr %l19, !tbaa !29
  %t201 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3atypeCase_3e_2eLen_3ccompiler_2fcheck_3atypeCase_3e(ptr %s0, ptr %t199)
  store i64 %t201, ptr %l122
  br label %bb47
bb47:
  %t202 = load i64, ptr %l120, !tbaa !24
  %t203 = load i64, ptr %l122, !tbaa !24
  %t204 = icmp slt i64 %t202, %t203
  %t206 = xor i1 %t204, true
  br i1 %t206, label %bb48, label %bb49
bb48:
  br label %bb60
bb49:
  br label %bb50
bb50:
  %t208 = load ptr, ptr %l19, !tbaa !29
  %t209 = load i64, ptr %l20, !tbaa !24
  %t212 = call %"compiler/check:typeCase" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3atypeCase_3e_2eAt_3ccompiler_2fcheck_3atypeCase_3e(ptr %s0, ptr %t208, i64 %t209)
  store %"compiler/check:typeCase" %t212, ptr %l127
  br label %bb51
bb51:
  %t213 = load %"compiler/check:typeCase", ptr %l127
  store %"compiler/check:typeCase" %t213, ptr %l21
  %t214 = getelementptr %"compiler/check:typeCase", ptr %l21, i32 0, i32 0
  %t215 = load i1, ptr %t214, !tbaa !21
  br i1 %t215, label %bb52, label %bb53
bb52:
  store %olang.scope zeroinitializer, ptr %s14
  %t217 = load ptr, ptr %l0, !tbaa !29
  %t219 = getelementptr %"compiler/check:Checker", ptr %t217, i32 0, i32 1
  %t220 = load ptr, ptr %t219, !tbaa !29
  %t222 = getelementptr %"compiler/generic:Program", ptr %t220, i32 0, i32 0
  %t223 = load ptr, ptr %t222, !tbaa !29
  %t225 = getelementptr %"compiler/load:Loader", ptr %t223, i32 0, i32 4
  %t226 = load ptr, ptr %t225, !tbaa !29
  store ptr %t226, ptr %l132, !tbaa !29
  %t227 = load ptr, ptr %l0, !tbaa !29
  store ptr %t227, ptr %l133, !tbaa !29
  %t228 = load ptr, ptr %l18, !tbaa !29
  %t230 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t228)
  store %"compiler/source:Span" %t230, ptr %l135
  br label %bb54
bb53:
  br label %bb58
bb54:
  %t231 = load ptr, ptr %l133, !tbaa !29
  %t232 = load %"compiler/source:Span", ptr %l135
  %t233 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %t231, %"compiler/source:Span" %t232)
  store { i64, [3 x i64] } %t233, ptr %l136
  br label %bb55
bb55:
  %t234 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eReflCaseUnreachable(ptr %s14)
  store %"compiler/msgs:Msg" %t234, ptr %l137
  br label %bb56
bb56:
  %t235 = load ptr, ptr %l132, !tbaa !29
  %t236 = load { i64, [3 x i64] }, ptr %l136
  %t237 = load %"compiler/msgs:Msg", ptr %l137
  %t238 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrorOncePerLine(ptr %v0, ptr %s14, ptr %t235, { i64, [3 x i64] } %t236, %"compiler/msgs:Msg" %t237)
  store i64 %t238, ptr %l138
  br label %bb57
bb57:
  call void @__olang_scope_close(ptr %s14)
  br label %bb58
bb58:
  br label %bb59
bb59:
  %t239 = load i64, ptr %l20, !tbaa !24
  %t241 = add i64 %t239, 1
  store i64 %t241, ptr %l20, !tbaa !24
  br label %bb46
bb60:
  store ptr %l8, ptr %l141, !tbaa !29
  %t243 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t245 = call %"compiler/check:typeCase" @compiler_2fcheck_3atypeCase_2ector(ptr %s11, i1 true, i1 false, i32 %t243, i64 0)
  store %"compiler/check:typeCase" %t245, ptr %l143
  br label %bb61
bb61:
  %t246 = load ptr, ptr %l141, !tbaa !29
  %t247 = load %"compiler/check:typeCase", ptr %l143
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3atypeCase_3e_2ePush_3ccompiler_2fcheck_3atypeCase_3e(ptr %s0, ptr %t246, %"compiler/check:typeCase" %t247)
  br label %bb62
bb62:
  %t248 = load i64, ptr %l7, !tbaa !24
  %t250 = icmp slt i64 %t248, 0
  br i1 %t250, label %bb63, label %bb64
bb63:
  %t252 = load i64, ptr %l14, !tbaa !24
  store i64 %t252, ptr %l7, !tbaa !24
  br label %bb65
bb64:
  br label %bb65
bb65:
  call void @__olang_scope_close(ptr %s11)
  br label %bb95
bb66:
  %t254 = load ptr, ptr %l0, !tbaa !29
  %t255 = load ptr, ptr %l18, !tbaa !29
  %t258 = call %"compiler/check:typeCase" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeCaseOf(ptr %v0, ptr %v1, ptr %t254, ptr %t255)
  store %"compiler/check:typeCase" %t258, ptr %l149
  br label %bb67
bb67:
  %t259 = load %"compiler/check:typeCase", ptr %l149
  store %"compiler/check:typeCase" %t259, ptr %l22
  %t260 = getelementptr %"compiler/check:typeCase", ptr %l22, i32 0, i32 2
  %t261 = load i32, ptr %t260, !tbaa !23
  %t262 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t265 = icmp eq i32 %t261, %t262
  br i1 %t265, label %bb68, label %bb69
bb68:
  br label %bb95
bb69:
  br label %bb70
bb70:
  store ptr %l8, ptr %l23, !tbaa !29
  store i64 0, ptr %l24, !tbaa !24
  br label %bb71
bb71:
  %t268 = load i64, ptr %l24, !tbaa !24
  store i64 %t268, ptr %l154, !tbaa !24
  %t269 = load ptr, ptr %l23, !tbaa !29
  %t271 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3atypeCase_3e_2eLen_3ccompiler_2fcheck_3atypeCase_3e(ptr %s0, ptr %t269)
  store i64 %t271, ptr %l156
  br label %bb72
bb72:
  %t272 = load i64, ptr %l154, !tbaa !24
  %t273 = load i64, ptr %l156, !tbaa !24
  %t274 = icmp slt i64 %t272, %t273
  %t276 = xor i1 %t274, true
  br i1 %t276, label %bb73, label %bb74
bb73:
  br label %bb86
bb74:
  br label %bb75
bb75:
  %t278 = load ptr, ptr %l23, !tbaa !29
  %t279 = load i64, ptr %l24, !tbaa !24
  %t282 = call %"compiler/check:typeCase" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3atypeCase_3e_2eAt_3ccompiler_2fcheck_3atypeCase_3e(ptr %s0, ptr %t278, i64 %t279)
  store %"compiler/check:typeCase" %t282, ptr %l161
  br label %bb76
bb76:
  %t283 = load %"compiler/check:typeCase", ptr %l161
  %t284 = load ptr, ptr %l0, !tbaa !29
  %t286 = load %"compiler/check:typeCase", ptr %l22
  %t290 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeCaseCovers(ptr %v0, ptr %t284, %"compiler/check:typeCase" %t283, %"compiler/check:typeCase" %t286)
  store i1 %t290, ptr %l165
  br label %bb77
bb77:
  %t291 = load i1, ptr %l165, !tbaa !21
  br i1 %t291, label %bb78, label %bb79
bb78:
  store %olang.scope zeroinitializer, ptr %s20
  %t292 = load ptr, ptr %l0, !tbaa !29
  %t294 = getelementptr %"compiler/check:Checker", ptr %t292, i32 0, i32 1
  %t295 = load ptr, ptr %t294, !tbaa !29
  %t297 = getelementptr %"compiler/generic:Program", ptr %t295, i32 0, i32 0
  %t298 = load ptr, ptr %t297, !tbaa !29
  %t300 = getelementptr %"compiler/load:Loader", ptr %t298, i32 0, i32 4
  %t301 = load ptr, ptr %t300, !tbaa !29
  store ptr %t301, ptr %l169, !tbaa !29
  %t302 = load ptr, ptr %l0, !tbaa !29
  store ptr %t302, ptr %l170, !tbaa !29
  %t303 = load ptr, ptr %l18, !tbaa !29
  %t305 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t303)
  store %"compiler/source:Span" %t305, ptr %l172
  br label %bb80
bb79:
  br label %bb84
bb80:
  %t306 = load ptr, ptr %l170, !tbaa !29
  %t307 = load %"compiler/source:Span", ptr %l172
  %t308 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %t306, %"compiler/source:Span" %t307)
  store { i64, [3 x i64] } %t308, ptr %l173
  br label %bb81
bb81:
  %t309 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eReflCaseUnreachable(ptr %s20)
  store %"compiler/msgs:Msg" %t309, ptr %l174
  br label %bb82
bb82:
  %t310 = load ptr, ptr %l169, !tbaa !29
  %t311 = load { i64, [3 x i64] }, ptr %l173
  %t312 = load %"compiler/msgs:Msg", ptr %l174
  %t313 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrorOncePerLine(ptr %v0, ptr %s20, ptr %t310, { i64, [3 x i64] } %t311, %"compiler/msgs:Msg" %t312)
  store i64 %t313, ptr %l175
  br label %bb83
bb83:
  call void @__olang_scope_close(ptr %s20)
  br label %bb84
bb84:
  br label %bb85
bb85:
  %t314 = load i64, ptr %l24, !tbaa !24
  %t316 = add i64 %t314, 1
  store i64 %t316, ptr %l24, !tbaa !24
  br label %bb71
bb86:
  %t318 = load %"compiler/check:typeCase", ptr %l22
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3atypeCase_3e_2ePush_3ccompiler_2fcheck_3atypeCase_3e(ptr %s0, ptr %l8, %"compiler/check:typeCase" %t318)
  br label %bb87
bb87:
  %t321 = load i64, ptr %l7, !tbaa !24
  %t323 = icmp sge i64 %t321, 0
  br i1 %t323, label %bb88, label %bb89
bb88:
  br label %bb95
bb89:
  br label %bb90
bb90:
  %t325 = load ptr, ptr %l0, !tbaa !29
  %t326 = load %"compiler/check:typeCase", ptr %l22
  %t327 = load i32, ptr %l2, !tbaa !23
  %t328 = load ptr, ptr %l18, !tbaa !29
  %t333 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeCaseHolds(ptr %v0, ptr %v1, ptr %t325, %"compiler/check:typeCase" %t326, i32 %t327, ptr %t328)
  store i1 %t333, ptr %l186
  br label %bb91
bb91:
  %t334 = load i1, ptr %l186, !tbaa !21
  br i1 %t334, label %bb92, label %bb93
bb92:
  %t335 = load i64, ptr %l14, !tbaa !24
  store i64 %t335, ptr %l7, !tbaa !24
  br label %bb94
bb93:
  br label %bb94
bb94:
  br label %bb95
bb95:
  %t337 = load i64, ptr %l16, !tbaa !24
  %t339 = add i64 %t337, 1
  store i64 %t339, ptr %l16, !tbaa !24
  br label %bb39
bb96:
  br label %bb97
bb97:
  %t341 = load i64, ptr %l13, !tbaa !24
  %t343 = add i64 %t341, 1
  store i64 %t343, ptr %l13, !tbaa !24
  br label %bb35
bb98:
  %t345 = load i64, ptr %l7, !tbaa !24
  %t347 = icmp sge i64 %t345, 0
  br i1 %t347, label %bb99, label %bb100
bb99:
  %t349 = load i64, ptr %l7, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t349, ptr %rv
  br label %ret
bb100:
  br label %bb101
bb101:
  %t351 = load ptr, ptr %l0, !tbaa !29
  store ptr %t351, ptr %l195, !tbaa !29
  %t352 = load ptr, ptr %l1, !tbaa !29
  %t354 = getelementptr %"compiler/ast:Match", ptr %t352, i32 0, i32 1
  %t355 = load ptr, ptr %t354, !tbaa !29
  %t357 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t355)
  store %"compiler/source:Span" %t357, ptr %l198
  br label %bb102
bb102:
  %t358 = load ptr, ptr %l0, !tbaa !29
  %t359 = load i32, ptr %l2, !tbaa !23
  %t362 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t358, i32 %t359)
  store { i64, ptr } %t362, ptr %l201
  br label %bb103
bb103:
  %t363 = load { i64, ptr }, ptr %l201, !tbaa !27
  %t364 = extractvalue { i64, ptr } %t363, 0
  %t365 = extractvalue { i64, ptr } %t363, 1
  %t366 = mul i64 %t364, 1
  %t367 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t366)
  call void @llvm.memcpy.p0.p0.i64(ptr %t367, ptr %t365, i64 %t366, i1 false)
  %t368 = insertvalue { i64, ptr } undef, i64 %t364, 0
  %t369 = insertvalue { i64, ptr } %t368, ptr %t367, 1
  %t371 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeMatchUncovered(ptr %s0, ptr %s0, { i64, ptr } %t369)
  store %"compiler/msgs:Msg" %t371, ptr %l203
  br label %bb104
bb104:
  %t372 = load ptr, ptr %l195, !tbaa !29
  %t373 = load %"compiler/source:Span", ptr %l198
  %t374 = load %"compiler/msgs:Msg", ptr %l203
  %t375 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s0, ptr %t372, %"compiler/source:Span" %t373, %"compiler/msgs:Msg" %t374)
  store i64 %t375, ptr %l204
  br label %bb105
bb105:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ematchValue(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca ptr
  %l13 = alloca i1
  %l16 = alloca i1
  %l21 = alloca ptr
  %l26 = alloca i64
  %l31 = alloca ptr
  %l33 = alloca { i64, ptr }
  %l43 = alloca ptr
  %l45 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l50 = alloca ptr
  %l56 = alloca i64
  %l61 = alloca i64
  %l66 = alloca ptr
  %l69 = alloca %"compiler/source:Span"
  %l70 = alloca %"compiler/msgs:Msg"
  %l71 = alloca i64
  %l74 = alloca ptr
  %l76 = alloca { i64, ptr }
  %l86 = alloca ptr
  %l91 = alloca ptr
  %l96 = alloca ptr
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Match", ptr %t1, i32 0, i32 2
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t9 = load ptr, ptr %l2, !tbaa !29
  %t12 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrMatch(ptr %v0, ptr %v1, ptr %t8, ptr %t9)
  store i1 %t12, ptr %l16
  br label %bb3
bb2:
  store i1 false, ptr %l13, !tbaa !21
  br label %bb4
bb3:
  %t13 = load i1, ptr %l16, !tbaa !21
  store i1 %t13, ptr %l13, !tbaa !21
  br label %bb4
bb4:
  %t14 = load i1, ptr %l13, !tbaa !21
  br i1 %t14, label %bb5, label %bb6
bb5:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load %"compiler/source:Span", ptr %l1
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t18 = load i32, ptr %l3, !tbaa !23
  %t23 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtMatchValue(ptr %v0, ptr %v1, ptr %t15, %"compiler/source:Span" %t16, ptr %t17, i32 %t18)
  store ptr %t23, ptr %l21
  br label %bb7
bb6:
  br label %bb8
bb7:
  %t24 = load ptr, ptr %l21, !tbaa !29
  store ptr %t24, ptr %rv
  br label %ret
bb8:
  %t25 = load ptr, ptr %l2, !tbaa !29
  %t27 = getelementptr %"compiler/ast:Match", ptr %t25, i32 0, i32 2
  %t28 = load i1, ptr %t27, !tbaa !21
  br i1 %t28, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load ptr, ptr %l2, !tbaa !29
  %t34 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ematchOnType(ptr %v0, ptr %v1, ptr %t30, ptr %t31)
  store i64 %t34, ptr %l26
  br label %bb11
bb10:
  br label %bb24
bb11:
  %t35 = load i64, ptr %l26, !tbaa !24
  store i64 %t35, ptr %l4, !tbaa !24
  %t36 = load i64, ptr %l4, !tbaa !24
  %t38 = icmp slt i64 %t36, 0
  br i1 %t38, label %bb12, label %bb13
bb12:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load %"compiler/source:Span", ptr %l1
  %t44 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t40, %"compiler/source:Span" %t41)
  store ptr %t44, ptr %l31
  br label %bb14
bb13:
  br label %bb15
bb14:
  call void @__olang_scope_close(ptr %s2)
  %t45 = load ptr, ptr %l31, !tbaa !29
  store ptr %t45, ptr %rv
  br label %ret
bb15:
  %t46 = load ptr, ptr %l2, !tbaa !29
  %t48 = getelementptr %"compiler/ast:Match", ptr %t46, i32 0, i32 3
  %t49 = load { i64, ptr }, ptr %t48, !tbaa !27
  store { i64, ptr } %t49, ptr %l33, !tbaa !27
  %t50 = load i64, ptr %l4, !tbaa !24
  %t52 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !27
  %t54 = getelementptr ptr, ptr %t53, i64 %t50
  %t55 = load ptr, ptr %t54, !tbaa !39
  store ptr %t55, ptr %l5, !tbaa !29
  %t57 = load ptr, ptr %l5, !tbaa !29
  %t59 = getelementptr %"compiler/ast:Case", ptr %t57, i32 0, i32 5
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t62 = icmp eq ptr %t60, null
  br i1 %t62, label %bb16, label %bb17
bb16:
  store %olang.scope zeroinitializer, ptr %s4
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t65 = load %"compiler/source:Span", ptr %l1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %s4, ptr %t64, %"compiler/source:Span" %t65, { i64, ptr } { i64 52, ptr getelementptr inbounds (<{ i64, [52 x i8] }>, ptr @.d44, i32 0, i32 1) })
  br label %bb18
bb17:
  br label %bb20
bb18:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load %"compiler/source:Span", ptr %l1
  %t72 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t68, %"compiler/source:Span" %t69)
  store ptr %t72, ptr %l43
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s2)
  %t73 = load ptr, ptr %l43, !tbaa !29
  store ptr %t73, ptr %rv
  br label %ret
bb20:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebindCase(ptr %v0, ptr %s2, ptr %t74)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t76, ptr %l45
  br label %bb21
bb21:
  %t77 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l45
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t77, ptr %l6
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t79 = load ptr, ptr %l5, !tbaa !29
  %t81 = getelementptr %"compiler/ast:Case", ptr %t79, i32 0, i32 5
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t83 = load i32, ptr %l3, !tbaa !23
  %t87 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %t78, ptr %t82, i32 %t83)
  store ptr %t87, ptr %l50
  br label %bb22
bb22:
  %t88 = load ptr, ptr %l50, !tbaa !29
  store ptr %t88, ptr %l7, !tbaa !29
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t90 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l6
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunbindCase(ptr %v0, ptr %s2, ptr %t89, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t90)
  br label %bb23
bb23:
  %t93 = load ptr, ptr %l7, !tbaa !29
  call void @__olang_scope_close(ptr %s2)
  store ptr %t93, ptr %rv
  br label %ret
bb24:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t96 = load ptr, ptr %l2, !tbaa !29
  %t99 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflMatch(ptr %v0, ptr %v1, ptr %t95, ptr %t96)
  store i64 %t99, ptr %l56
  br label %bb25
bb25:
  %t100 = load i64, ptr %l56, !tbaa !24
  store i64 %t100, ptr %l8, !tbaa !24
  %t101 = load i64, ptr %l8, !tbaa !24
  %t103 = icmp eq i64 %t101, -2
  br i1 %t103, label %bb26, label %bb27
bb26:
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t106 = load ptr, ptr %l2, !tbaa !29
  %t109 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elenMatch(ptr %v0, ptr %v1, ptr %t105, ptr %t106)
  store i64 %t109, ptr %l61
  br label %bb28
bb27:
  br label %bb29
bb28:
  %t110 = load i64, ptr %l61, !tbaa !24
  store i64 %t110, ptr %l8, !tbaa !24
  br label %bb29
bb29:
  %t111 = load i64, ptr %l8, !tbaa !24
  %t113 = icmp ne i64 %t111, -2
  br i1 %t113, label %bb30, label %bb31
bb30:
  %t115 = load i64, ptr %l8, !tbaa !24
  %t117 = icmp slt i64 %t115, 0
  br i1 %t117, label %bb32, label %bb33
bb31:
  br label %bb45
bb32:
  store %olang.scope zeroinitializer, ptr %s7
  %t119 = load ptr, ptr %l0, !tbaa !29
  store ptr %t119, ptr %l66, !tbaa !29
  %t120 = load ptr, ptr %l2, !tbaa !29
  %t122 = getelementptr %"compiler/ast:Match", ptr %t120, i32 0, i32 1
  %t123 = load ptr, ptr %t122, !tbaa !29
  %t125 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t123)
  store %"compiler/source:Span" %t125, ptr %l69
  br label %bb34
bb33:
  br label %bb38
bb34:
  %t126 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eMatchValueNone(ptr %s7)
  store %"compiler/msgs:Msg" %t126, ptr %l70
  br label %bb35
bb35:
  %t127 = load ptr, ptr %l66, !tbaa !29
  %t128 = load %"compiler/source:Span", ptr %l69
  %t129 = load %"compiler/msgs:Msg", ptr %l70
  %t130 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s7, ptr %t127, %"compiler/source:Span" %t128, %"compiler/msgs:Msg" %t129)
  store i64 %t130, ptr %l71
  br label %bb36
bb36:
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t132 = load %"compiler/source:Span", ptr %l1
  %t135 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t131, %"compiler/source:Span" %t132)
  store ptr %t135, ptr %l74
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s7)
  %t136 = load ptr, ptr %l74, !tbaa !29
  store ptr %t136, ptr %rv
  br label %ret
bb38:
  %t137 = load ptr, ptr %l2, !tbaa !29
  %t139 = getelementptr %"compiler/ast:Match", ptr %t137, i32 0, i32 3
  %t140 = load { i64, ptr }, ptr %t139, !tbaa !27
  store { i64, ptr } %t140, ptr %l76, !tbaa !27
  %t141 = load i64, ptr %l8, !tbaa !24
  %t143 = getelementptr { i64, ptr }, ptr %l76, i32 0, i32 1
  %t144 = load ptr, ptr %t143, !tbaa !27
  %t145 = getelementptr ptr, ptr %t144, i64 %t141
  %t146 = load ptr, ptr %t145, !tbaa !39
  store ptr %t146, ptr %l9, !tbaa !29
  %t148 = load ptr, ptr %l9, !tbaa !29
  %t150 = getelementptr %"compiler/ast:Case", ptr %t148, i32 0, i32 5
  %t151 = load ptr, ptr %t150, !tbaa !29
  %t153 = icmp eq ptr %t151, null
  br i1 %t153, label %bb39, label %bb40
bb39:
  store %olang.scope zeroinitializer, ptr %s8
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t156 = load %"compiler/source:Span", ptr %l1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %s8, ptr %t155, %"compiler/source:Span" %t156, { i64, ptr } { i64 54, ptr getelementptr inbounds (<{ i64, [54 x i8] }>, ptr @.d45, i32 0, i32 1) })
  br label %bb41
bb40:
  br label %bb43
bb41:
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t160 = load %"compiler/source:Span", ptr %l1
  %t163 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t159, %"compiler/source:Span" %t160)
  store ptr %t163, ptr %l86
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s8)
  %t164 = load ptr, ptr %l86, !tbaa !29
  store ptr %t164, ptr %rv
  br label %ret
bb43:
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t166 = load ptr, ptr %l9, !tbaa !29
  %t168 = getelementptr %"compiler/ast:Case", ptr %t166, i32 0, i32 5
  %t169 = load ptr, ptr %t168, !tbaa !29
  %t170 = load i32, ptr %l3, !tbaa !23
  %t174 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %t165, ptr %t169, i32 %t170)
  store ptr %t174, ptr %l91
  br label %bb44
bb44:
  %t175 = load ptr, ptr %l91, !tbaa !29
  store ptr %t175, ptr %rv
  br label %ret
bb45:
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t177 = load %"compiler/source:Span", ptr %l1
  %t178 = load ptr, ptr %l2, !tbaa !29
  %t179 = load i32, ptr %l3, !tbaa !23
  %t184 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ematchExpr(ptr %v0, ptr %v1, ptr %t176, %"compiler/source:Span" %t177, ptr %t178, i1 true, i32 %t179)
  store ptr %t184, ptr %l96
  br label %bb46
bb46:
  %t185 = load ptr, ptr %l96, !tbaa !29
  store ptr %t185, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enamedArgs(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i1
  %l7 = alloca i1
  %lp8 = alloca ptr
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca %"compiler/source:Span"
  %l19 = alloca i32
  %l20 = alloca ptr
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca %"compiler/source:Span"
  %l29 = alloca ptr
  %l30 = alloca { i64, ptr }
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %lp41 = alloca ptr
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i64
  %l48 = alloca ptr
  %l50 = alloca i1
  %l55 = alloca i64
  %l59 = alloca i64
  %l63 = alloca i64
  %l71 = alloca i64
  %l74 = alloca i64
  %l92 = alloca { i64, ptr }
  %l95 = alloca ptr
  %l96 = alloca i1
  %l109 = alloca i64
  %l112 = alloca i64
  %l130 = alloca { i64, ptr }
  %l139 = alloca i32
  %l140 = alloca i32
  %l143 = alloca { i64, ptr }
  %l147 = alloca %"compiler/source:Span"
  %l152 = alloca { i64, ptr }
  %l153 = alloca %"compiler/msgs:Nearest"
  %l162 = alloca { i64, ptr }
  %l169 = alloca ptr
  %l173 = alloca { i64, ptr }
  %l180 = alloca ptr
  %l181 = alloca %"compiler/source:Span"
  %l184 = alloca { i64, ptr }
  %l185 = alloca { i64, ptr }
  %l187 = alloca { i64, ptr }
  %l191 = alloca %"compiler/msgs:Msg"
  %l192 = alloca i64
  %l193 = alloca ptr
  %l194 = alloca %"compiler/source:Span"
  %l197 = alloca { i64, ptr }
  %l198 = alloca { i64, ptr }
  %l200 = alloca { i64, ptr }
  %l202 = alloca %"compiler/msgs:Msg"
  %l203 = alloca i64
  %l204 = alloca { i64, ptr }
  %l209 = alloca ptr
  %l210 = alloca %"compiler/source:Span"
  %l213 = alloca { i64, ptr }
  %l215 = alloca %"compiler/msgs:Msg"
  %l216 = alloca i64
  %l221 = alloca ptr
  %l222 = alloca %"compiler/source:Span"
  %l225 = alloca %"compiler/msgs:Msg"
  %l228 = alloca { i64, ptr }
  %l230 = alloca %"compiler/msgs:Msg"
  %l233 = alloca { i64, ptr }
  %l235 = alloca %"compiler/msgs:Msg"
  %l236 = alloca i64
  %l244 = alloca ptr
  %l246 = alloca %"compiler/source:Span"
  %l247 = alloca %"compiler/msgs:Msg"
  %l248 = alloca i64
  %l264 = alloca ptr
  %l265 = alloca { i64, ptr }
  %l268 = alloca %"compiler/source:Span"
  %l269 = alloca i64
  %l272 = alloca { i64, ptr }
  %l274 = alloca %"compiler/msgs:Msg"
  %l275 = alloca i64
  %l283 = alloca i64
  %l286 = alloca i64
  %l311 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l319 = alloca i64
  %l322 = alloca i64
  %l344 = alloca ptr
  %l345 = alloca { i64, ptr }
  %l347 = alloca %"compiler/source:Span"
  %l359 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t38 = alloca i64
  %t704 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t3 = call i1 @compiler_2fcheck_2ehasNamed(ptr %v2, { i64, ptr } %t1)
  store i1 %t3, ptr %l50
  br label %bb1
bb1:
  %t4 = load i1, ptr %l50, !tbaa !21
  %t5 = xor i1 %t4, true
  br i1 %t5, label %bb2, label %bb3
bb2:
  %t7 = load { i64, ptr }, ptr %l2, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t7, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t9 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  store i64 %t11, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  store i1 false, ptr %l6, !tbaa !21
  store i1 false, ptr %l7, !tbaa !21
  %t13 = load i64, ptr %l4, !tbaa !24
  store i64 %t13, ptr %l55, !tbaa !24
  %t14 = load i64, ptr %l55, !tbaa !24
  %t15 = icmp sge i64 %t14, 0
  br i1 %t15, label %bb5, label %bb6
bb5:
  %t17 = load i64, ptr %l55, !tbaa !24
  %t18 = icmp sle i64 %t17, 1152921504606846975
  br i1 %t18, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_2a22705e3675cc6a_15625908cbc104fe)
  unreachable
bb7:
  %t20 = load i64, ptr %l55, !tbaa !24
  %t21 = mul i64 %t20, 8
  %t22 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t21)
  %t23 = insertvalue { i64, ptr } undef, i64 %t20, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t22, 1
  %t25 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t25, ptr %lp8
  %t27 = load ptr, ptr %lp8
  store { i64, ptr } %t24, ptr %t27, !tbaa !27
  %t28 = load i64, ptr %l4, !tbaa !24
  store i64 %t28, ptr %l59, !tbaa !24
  %t29 = load i64, ptr %l59, !tbaa !24
  %t30 = icmp sge i64 %t29, 0
  br i1 %t30, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_2a22705e3675cc6a_15625908cbc104fe)
  unreachable
bb9:
  %t32 = load i64, ptr %l59, !tbaa !24
  %t33 = icmp sle i64 %t32, 1152921504606846975
  br i1 %t33, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_e03e15fa1ad8573f_767a3f28b3ff5a33)
  unreachable
bb11:
  %t35 = load i64, ptr %l59, !tbaa !24
  %t36 = mul i64 %t35, 8
  %t37 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t36)
  store i64 0, ptr %t38
  br label %fill.39
fill.39:
  %t42 = load i64, ptr %t38
  %t43 = icmp slt i64 %t42, %t35
  br i1 %t43, label %fillb.40, label %filld.41
fillb.40:
  %t44 = getelementptr i64, ptr %t37, i64 %t42
  store i64 -1, ptr %t44
  %t45 = add i64 %t42, 1
  store i64 %t45, ptr %t38
  br label %fill.39
filld.41:
  %t46 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t47 = insertvalue { i64, ptr } %t46, ptr %t37, 1
  store { i64, ptr } %t47, ptr %l9, !tbaa !27
  %t49 = load i64, ptr %l4, !tbaa !24
  store i64 %t49, ptr %l63, !tbaa !24
  %t50 = load i64, ptr %l63, !tbaa !24
  %t51 = icmp sge i64 %t50, 0
  br i1 %t51, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @olang_loc_e03e15fa1ad8573f_767a3f28b3ff5a33)
  unreachable
bb13:
  %t53 = load i64, ptr %l63, !tbaa !24
  %t54 = mul i64 %t53, 1
  %t55 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t54)
  %t56 = insertvalue { i64, ptr } undef, i64 %t53, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t55, 1
  store { i64, ptr } %t57, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t59 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t61 = extractvalue { i64, ptr } %t59, 0
  store i64 %t61, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t63 = load i64, ptr %l12, !tbaa !24
  %t64 = load i64, ptr %l11, !tbaa !24
  %t67 = icmp sgt i64 %t63, %t64
  br i1 %t67, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_f1d5d3b2155f2ddc_ad13ea37e14bc210)
  unreachable
bb15:
  %t69 = load i64, ptr %l13, !tbaa !24
  %t71 = icmp sgt i64 %t69, 0
  br i1 %t71, label %bb17, label %bb18
bb16:
  store i64 0, ptr %l71, !tbaa !24
  br label %bb20
bb17:
  %t73 = load i64, ptr %l12, !tbaa !24
  %t74 = load i64, ptr %l11, !tbaa !24
  %t77 = sub i64 %t73, %t74
  %t78 = load i64, ptr %l13, !tbaa !24
  %t81 = add i64 %t77, %t78
  %t83 = sub i64 %t81, 1
  %t84 = load i64, ptr %l13, !tbaa !24
  %t87 = sdiv i64 %t83, %t84
  store i64 %t87, ptr %l74, !tbaa !24
  br label %bb19
bb18:
  store i64 0, ptr %l74, !tbaa !24
  br label %bb19
bb19:
  %t89 = load i64, ptr %l74, !tbaa !24
  store i64 %t89, ptr %l71, !tbaa !24
  br label %bb20
bb20:
  %t90 = load i64, ptr %l71, !tbaa !24
  store i64 %t90, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb21
bb21:
  %t91 = load i64, ptr %l15, !tbaa !24
  %t92 = load i64, ptr %l14, !tbaa !24
  %t95 = icmp slt i64 %t91, %t92
  %t97 = xor i1 %t95, true
  br i1 %t97, label %bb22, label %bb23
bb22:
  br label %bb107
bb23:
  br label %bb24
bb24:
  %t99 = load i64, ptr %l11, !tbaa !24
  %t100 = load i64, ptr %l15, !tbaa !24
  %t101 = load i64, ptr %l13, !tbaa !24
  %t104 = mul i64 %t100, %t101
  %t107 = add i64 %t99, %t104
  store i64 %t107, ptr %l16, !tbaa !24
  %t109 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t109, ptr %l92, !tbaa !27
  %t110 = load i64, ptr %l16, !tbaa !24
  %t112 = getelementptr { i64, ptr }, ptr %l92, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !27
  %t114 = getelementptr ptr, ptr %t113, i64 %t110
  %t115 = load ptr, ptr %t114, !tbaa !39
  store ptr %t115, ptr %l17, !tbaa !29
  %t117 = load ptr, ptr %l17, !tbaa !29
  store ptr %t117, ptr %l95, !tbaa !29
  store i1 false, ptr %l96, !tbaa !21
  %t118 = load ptr, ptr %l95, !tbaa !29
  %t119 = icmp ne ptr %t118, null
  br i1 %t119, label %bb25, label %bb26
bb25:
  %t121 = load ptr, ptr %l95, !tbaa !29
  %t122 = load i64, ptr %t121
  %t124 = icmp eq i64 %t122, 27
  store i1 %t124, ptr %l96, !tbaa !21
  br label %bb26
bb26:
  %t125 = load i1, ptr %l96, !tbaa !21
  br i1 %t125, label %bb27, label %bb28
bb27:
  %t126 = load ptr, ptr %l17, !tbaa !29
  %t128 = getelementptr { i64, [5 x i64] }, ptr %t126, i32 0, i32 1
  %t129 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t128, i32 0, i32 0
  %t130 = load %"compiler/source:Span", ptr %t129
  store %"compiler/source:Span" %t130, ptr %l18
  %t132 = load ptr, ptr %l17, !tbaa !29
  %t134 = getelementptr { i64, [5 x i64] }, ptr %t132, i32 0, i32 1
  %t135 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t134, i32 0, i32 1
  %t136 = load i32, ptr %t135
  store i32 %t136, ptr %l19, !tbaa !23
  %t138 = load ptr, ptr %l17, !tbaa !29
  %t140 = getelementptr { i64, [5 x i64] }, ptr %t138, i32 0, i32 1
  %t141 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t140, i32 0, i32 2
  %t142 = load ptr, ptr %t141
  store ptr %t142, ptr %l20, !tbaa !29
  br label %bb29
bb28:
  br label %bb91
bb29:
  store %olang.scope zeroinitializer, ptr %s4
  store i1 true, ptr %l6, !tbaa !21
  store i64 -1, ptr %l21, !tbaa !24
  store i64 0, ptr %l22, !tbaa !24
  %t144 = load i64, ptr %l4, !tbaa !24
  store i64 %t144, ptr %l23, !tbaa !24
  store i64 1, ptr %l24, !tbaa !24
  %t146 = load i64, ptr %l23, !tbaa !24
  %t147 = load i64, ptr %l22, !tbaa !24
  %t150 = icmp sgt i64 %t146, %t147
  br i1 %t150, label %bb30, label %bb31
bb30:
  %t152 = load i64, ptr %l24, !tbaa !24
  %t154 = icmp sgt i64 %t152, 0
  br i1 %t154, label %bb32, label %bb33
bb31:
  store i64 0, ptr %l109, !tbaa !24
  br label %bb35
bb32:
  %t156 = load i64, ptr %l23, !tbaa !24
  %t157 = load i64, ptr %l22, !tbaa !24
  %t160 = sub i64 %t156, %t157
  %t161 = load i64, ptr %l24, !tbaa !24
  %t164 = add i64 %t160, %t161
  %t166 = sub i64 %t164, 1
  %t167 = load i64, ptr %l24, !tbaa !24
  %t170 = sdiv i64 %t166, %t167
  store i64 %t170, ptr %l112, !tbaa !24
  br label %bb34
bb33:
  store i64 0, ptr %l112, !tbaa !24
  br label %bb34
bb34:
  %t172 = load i64, ptr %l112, !tbaa !24
  store i64 %t172, ptr %l109, !tbaa !24
  br label %bb35
bb35:
  %t173 = load i64, ptr %l109, !tbaa !24
  store i64 %t173, ptr %l25, !tbaa !24
  store i64 0, ptr %l26, !tbaa !24
  br label %bb36
bb36:
  %t174 = load i64, ptr %l26, !tbaa !24
  %t175 = load i64, ptr %l25, !tbaa !24
  %t178 = icmp slt i64 %t174, %t175
  %t180 = xor i1 %t178, true
  br i1 %t180, label %bb37, label %bb38
bb37:
  br label %bb44
bb38:
  br label %bb39
bb39:
  %t182 = load i64, ptr %l22, !tbaa !24
  %t183 = load i64, ptr %l26, !tbaa !24
  %t184 = load i64, ptr %l24, !tbaa !24
  %t187 = mul i64 %t183, %t184
  %t190 = add i64 %t182, %t187
  store i64 %t190, ptr %l27, !tbaa !24
  %t192 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t192, ptr %l130, !tbaa !27
  %t193 = load i64, ptr %l27, !tbaa !24
  %t195 = getelementptr { i64, ptr }, ptr %l130, i32 0, i32 1
  %t196 = load ptr, ptr %t195, !tbaa !27
  %t197 = getelementptr ptr, ptr %t196, i64 %t193
  %t198 = load ptr, ptr %t197, !tbaa !39
  %t200 = getelementptr %"compiler/ast:Param", ptr %t198, i32 0, i32 1
  %t201 = load i32, ptr %t200, !tbaa !23
  %t202 = load i32, ptr %l19, !tbaa !23
  %t205 = icmp eq i32 %t201, %t202
  br i1 %t205, label %bb40, label %bb41
bb40:
  %t207 = load i64, ptr %l27, !tbaa !24
  store i64 %t207, ptr %l21, !tbaa !24
  br label %bb42
bb41:
  br label %bb42
bb42:
  br label %bb43
bb43:
  %t209 = load i64, ptr %l26, !tbaa !24
  %t211 = add i64 %t209, 1
  store i64 %t211, ptr %l26, !tbaa !24
  br label %bb36
bb44:
  %t213 = getelementptr %"compiler/source:Span", ptr %l18, i32 0, i32 0
  %t214 = load i32, ptr %t213, !tbaa !23
  store i32 %t214, ptr %l139, !tbaa !23
  %t215 = getelementptr %"compiler/source:Span", ptr %l18, i32 0, i32 0
  %t216 = load i32, ptr %t215, !tbaa !23
  store i32 %t216, ptr %l140, !tbaa !23
  %t217 = load ptr, ptr %l0, !tbaa !29
  %t218 = load i32, ptr %l19, !tbaa !23
  %t221 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t217, i32 %t218)
  store { i64, ptr } %t221, ptr %l143
  br label %bb45
bb45:
  %t222 = load { i64, ptr }, ptr %l143, !tbaa !27
  %t223 = extractvalue { i64, ptr } %t222, 0
  %t225 = trunc i64 %t223 to i32
  %t226 = load i32, ptr %l140, !tbaa !23
  %t228 = add i32 %t226, %t225
  %t229 = load i32, ptr %l139, !tbaa !23
  %t231 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s4, i32 %t229, i32 %t228)
  store %"compiler/source:Span" %t231, ptr %l147
  br label %bb46
bb46:
  %t232 = load %"compiler/source:Span", ptr %l147
  store %"compiler/source:Span" %t232, ptr %l28
  %t233 = load i64, ptr %l21, !tbaa !24
  %t235 = icmp slt i64 %t233, 0
  br i1 %t235, label %bb47, label %bb48
bb47:
  store %olang.scope zeroinitializer, ptr %s9
  %t237 = load ptr, ptr %l0, !tbaa !29
  %t238 = load i32, ptr %l19, !tbaa !23
  %t241 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t237, i32 %t238)
  store { i64, ptr } %t241, ptr %l152
  br label %bb49
bb48:
  %t242 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t242, ptr %l204, !tbaa !27
  %t243 = load i64, ptr %l21, !tbaa !24
  %t245 = getelementptr { i64, ptr }, ptr %l204, i32 0, i32 1
  %t246 = load ptr, ptr %t245, !tbaa !27
  %t247 = getelementptr ptr, ptr %t246, i64 %t243
  %t248 = load ptr, ptr %t247, !tbaa !39
  %t250 = getelementptr %"compiler/ast:Param", ptr %t248, i32 0, i32 3
  %t251 = load ptr, ptr %t250, !tbaa !29
  %t253 = icmp eq ptr %t251, null
  br i1 %t253, label %bb73, label %bb74
bb49:
  %t255 = load { i64, ptr }, ptr %l152, !tbaa !27
  %t256 = call %"compiler/msgs:Nearest" @compiler_2fmsgs_3aNearest_2ector(ptr %v0, ptr %s9, { i64, ptr } %t255)
  store %"compiler/msgs:Nearest" %t256, ptr %l153
  br label %bb50
bb50:
  %t257 = load %"compiler/msgs:Nearest", ptr %l153
  %t258 = call ptr @__olang_scope_alloc_a(ptr %s9, i64 40, i64 8)
  store %"compiler/msgs:Nearest" %t257, ptr %t258
  store ptr %t258, ptr %l29, !tbaa !29
  %t260 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t260, ptr %l30, !tbaa !27
  store i64 0, ptr %l31, !tbaa !24
  %t262 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t264 = extractvalue { i64, ptr } %t262, 0
  store i64 %t264, ptr %l32, !tbaa !24
  br label %bb51
bb51:
  %t266 = load i64, ptr %l31, !tbaa !24
  %t267 = load i64, ptr %l32, !tbaa !24
  %t270 = icmp slt i64 %t266, %t267
  %t272 = xor i1 %t270, true
  br i1 %t272, label %bb52, label %bb53
bb52:
  br label %bb61
bb53:
  br label %bb54
bb54:
  %t274 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t274, ptr %l162, !tbaa !27
  %t275 = load i64, ptr %l31, !tbaa !24
  %t277 = getelementptr { i64, ptr }, ptr %l162, i32 0, i32 1
  %t278 = load ptr, ptr %t277, !tbaa !27
  %t279 = getelementptr ptr, ptr %t278, i64 %t275
  %t280 = load ptr, ptr %t279, !tbaa !39
  store ptr %t280, ptr %l33, !tbaa !29
  %t282 = load ptr, ptr %l33, !tbaa !29
  %t284 = getelementptr %"compiler/ast:Param", ptr %t282, i32 0, i32 3
  %t285 = load ptr, ptr %t284, !tbaa !29
  %t287 = icmp eq ptr %t285, null
  %t289 = xor i1 %t287, true
  br i1 %t289, label %bb55, label %bb56
bb55:
  %t291 = load ptr, ptr %l29, !tbaa !29
  store ptr %t291, ptr %l169, !tbaa !29
  %t292 = load ptr, ptr %l0, !tbaa !29
  %t293 = load ptr, ptr %l33, !tbaa !29
  %t295 = getelementptr %"compiler/ast:Param", ptr %t293, i32 0, i32 1
  %t296 = load i32, ptr %t295, !tbaa !23
  %t299 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t292, i32 %t296)
  store { i64, ptr } %t299, ptr %l173
  br label %bb57
bb56:
  br label %bb59
bb57:
  %t300 = load ptr, ptr %l169, !tbaa !29
  %t301 = load { i64, ptr }, ptr %l173, !tbaa !27
  call void @compiler_2fmsgs_2ecompiler_2fmsgs_3aNearest_2eOffer(ptr %s9, ptr %v0, ptr %t300, { i64, ptr } %t301)
  br label %bb58
bb58:
  br label %bb59
bb59:
  br label %bb60
bb60:
  %t302 = load i64, ptr %l31, !tbaa !24
  %t304 = add i64 %t302, 1
  store i64 %t304, ptr %l31, !tbaa !24
  br label %bb51
bb61:
  %t306 = load ptr, ptr %l29, !tbaa !29
  %t308 = getelementptr %"compiler/msgs:Nearest", ptr %t306, i32 0, i32 1
  %t309 = load { i64, ptr }, ptr %t308, !tbaa !27
  %t311 = extractvalue { i64, ptr } %t309, 0
  %t313 = icmp sgt i64 %t311, 0
  br i1 %t313, label %bb62, label %bb63
bb62:
  store %olang.scope zeroinitializer, ptr %s14
  %t315 = load ptr, ptr %l0, !tbaa !29
  store ptr %t315, ptr %l180, !tbaa !29
  %t316 = load %"compiler/source:Span", ptr %l28
  store %"compiler/source:Span" %t316, ptr %l181
  %t317 = load ptr, ptr %l0, !tbaa !29
  %t318 = load i32, ptr %l19, !tbaa !23
  %t321 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s14, ptr %t317, i32 %t318)
  store { i64, ptr } %t321, ptr %l184
  br label %bb64
bb63:
  store %olang.scope zeroinitializer, ptr %s15
  %t322 = load ptr, ptr %l0, !tbaa !29
  store ptr %t322, ptr %l193, !tbaa !29
  %t323 = load %"compiler/source:Span", ptr %l28
  store %"compiler/source:Span" %t323, ptr %l194
  %t324 = load ptr, ptr %l0, !tbaa !29
  %t325 = load i32, ptr %l19, !tbaa !23
  %t328 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s15, ptr %t324, i32 %t325)
  store { i64, ptr } %t328, ptr %l197
  br label %bb68
bb64:
  %t329 = load { i64, ptr }, ptr %l184, !tbaa !27
  %t330 = extractvalue { i64, ptr } %t329, 0
  %t331 = extractvalue { i64, ptr } %t329, 1
  %t332 = mul i64 %t330, 1
  %t333 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t332)
  call void @llvm.memcpy.p0.p0.i64(ptr %t333, ptr %t331, i64 %t332, i1 false)
  %t334 = insertvalue { i64, ptr } undef, i64 %t330, 0
  %t335 = insertvalue { i64, ptr } %t334, ptr %t333, 1
  store { i64, ptr } %t335, ptr %l185, !tbaa !27
  %t336 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t338 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v3, ptr %s14, { i64, ptr } %t336)
  store { i64, ptr } %t338, ptr %l187
  br label %bb65
bb65:
  %t339 = load { i64, ptr }, ptr %l187, !tbaa !27
  %t340 = extractvalue { i64, ptr } %t339, 0
  %t341 = extractvalue { i64, ptr } %t339, 1
  %t342 = mul i64 %t340, 1
  %t343 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t342)
  call void @llvm.memcpy.p0.p0.i64(ptr %t343, ptr %t341, i64 %t342, i1 false)
  %t344 = insertvalue { i64, ptr } undef, i64 %t340, 0
  %t345 = insertvalue { i64, ptr } %t344, ptr %t343, 1
  %t346 = load ptr, ptr %l29, !tbaa !29
  %t348 = getelementptr %"compiler/msgs:Nearest", ptr %t346, i32 0, i32 1
  %t349 = load { i64, ptr }, ptr %t348, !tbaa !27
  %t350 = load { i64, ptr }, ptr %l185, !tbaa !27
  %t353 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNamedArgUnknownMeant(ptr %s14, ptr %s14, ptr %s9, ptr %s14, { i64, ptr } %t350, { i64, ptr } %t345, { i64, ptr } %t349)
  store %"compiler/msgs:Msg" %t353, ptr %l191
  br label %bb66
bb66:
  %t354 = load ptr, ptr %l180, !tbaa !29
  %t355 = load %"compiler/source:Span", ptr %l181
  %t356 = load %"compiler/msgs:Msg", ptr %l191
  %t357 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s14, ptr %t354, %"compiler/source:Span" %t355, %"compiler/msgs:Msg" %t356)
  store i64 %t357, ptr %l192
  br label %bb67
bb67:
  call void @__olang_scope_close(ptr %s14)
  br label %bb72
bb68:
  %t358 = load { i64, ptr }, ptr %l197, !tbaa !27
  %t359 = extractvalue { i64, ptr } %t358, 0
  %t360 = extractvalue { i64, ptr } %t358, 1
  %t361 = mul i64 %t359, 1
  %t362 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t361)
  call void @llvm.memcpy.p0.p0.i64(ptr %t362, ptr %t360, i64 %t361, i1 false)
  %t363 = insertvalue { i64, ptr } undef, i64 %t359, 0
  %t364 = insertvalue { i64, ptr } %t363, ptr %t362, 1
  store { i64, ptr } %t364, ptr %l198, !tbaa !27
  %t365 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t367 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v3, ptr %s15, { i64, ptr } %t365)
  store { i64, ptr } %t367, ptr %l200
  br label %bb69
bb69:
  %t368 = load { i64, ptr }, ptr %l200, !tbaa !27
  %t369 = extractvalue { i64, ptr } %t368, 0
  %t370 = extractvalue { i64, ptr } %t368, 1
  %t371 = mul i64 %t369, 1
  %t372 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t371)
  call void @llvm.memcpy.p0.p0.i64(ptr %t372, ptr %t370, i64 %t371, i1 false)
  %t373 = insertvalue { i64, ptr } undef, i64 %t369, 0
  %t374 = insertvalue { i64, ptr } %t373, ptr %t372, 1
  %t375 = load { i64, ptr }, ptr %l198, !tbaa !27
  %t377 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNamedArgUnknown(ptr %s15, ptr %s15, ptr %s15, { i64, ptr } %t375, { i64, ptr } %t374)
  store %"compiler/msgs:Msg" %t377, ptr %l202
  br label %bb70
bb70:
  %t378 = load ptr, ptr %l193, !tbaa !29
  %t379 = load %"compiler/source:Span", ptr %l194
  %t380 = load %"compiler/msgs:Msg", ptr %l202
  %t381 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s15, ptr %t378, %"compiler/source:Span" %t379, %"compiler/msgs:Msg" %t380)
  store i64 %t381, ptr %l203
  br label %bb71
bb71:
  call void @__olang_scope_close(ptr %s15)
  br label %bb72
bb72:
  store i1 true, ptr %l7, !tbaa !21
  call void @__olang_scope_close(ptr %s9)
  br label %bb90
bb73:
  store %olang.scope zeroinitializer, ptr %s17
  %t382 = load ptr, ptr %l0, !tbaa !29
  store ptr %t382, ptr %l209, !tbaa !29
  %t383 = load %"compiler/source:Span", ptr %l28
  store %"compiler/source:Span" %t383, ptr %l210
  %t384 = load ptr, ptr %l0, !tbaa !29
  %t385 = load i32, ptr %l19, !tbaa !23
  %t388 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s17, ptr %t384, i32 %t385)
  store { i64, ptr } %t388, ptr %l213
  br label %bb75
bb74:
  %t389 = load i64, ptr %l21, !tbaa !24
  %t390 = load ptr, ptr %lp8
  %t392 = getelementptr { i64, ptr }, ptr %t390, i32 0, i32 1
  %t393 = load ptr, ptr %t392, !tbaa !27
  %t394 = getelementptr ptr, ptr %t393, i64 %t389
  %t395 = load ptr, ptr %t394, !tbaa !39
  %t397 = icmp eq ptr %t395, null
  %t399 = xor i1 %t397, true
  br i1 %t399, label %bb78, label %bb79
bb75:
  %t401 = load { i64, ptr }, ptr %l213, !tbaa !27
  %t402 = extractvalue { i64, ptr } %t401, 0
  %t403 = extractvalue { i64, ptr } %t401, 1
  %t404 = mul i64 %t402, 1
  %t405 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t404)
  call void @llvm.memcpy.p0.p0.i64(ptr %t405, ptr %t403, i64 %t404, i1 false)
  %t406 = insertvalue { i64, ptr } undef, i64 %t402, 0
  %t407 = insertvalue { i64, ptr } %t406, ptr %t405, 1
  %t409 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNamedArgRequired(ptr %s17, ptr %s17, { i64, ptr } %t407)
  store %"compiler/msgs:Msg" %t409, ptr %l215
  br label %bb76
bb76:
  %t410 = load ptr, ptr %l209, !tbaa !29
  %t411 = load %"compiler/source:Span", ptr %l210
  %t412 = load %"compiler/msgs:Msg", ptr %l215
  %t413 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s17, ptr %t410, %"compiler/source:Span" %t411, %"compiler/msgs:Msg" %t412)
  store i64 %t413, ptr %l216
  br label %bb77
bb77:
  store i1 true, ptr %l7, !tbaa !21
  call void @__olang_scope_close(ptr %s17)
  br label %bb89
bb78:
  store %olang.scope zeroinitializer, ptr %s19
  %t414 = load ptr, ptr %l0, !tbaa !29
  store ptr %t414, ptr %l221, !tbaa !29
  %t415 = load %"compiler/source:Span", ptr %l28
  store %"compiler/source:Span" %t415, ptr %l222
  %t416 = load i64, ptr %l21, !tbaa !24
  %t418 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t419 = load ptr, ptr %t418, !tbaa !27
  %t420 = getelementptr i1, ptr %t419, i64 %t416
  %t421 = load i1, ptr %t420, !tbaa !31
  br i1 %t421, label %bb80, label %bb81
bb79:
  %t423 = load i64, ptr %l21, !tbaa !24
  %t424 = load ptr, ptr %l20, !tbaa !29
  %t427 = load ptr, ptr %lp8
  %t429 = getelementptr { i64, ptr }, ptr %t427, i32 0, i32 1
  %t430 = load ptr, ptr %t429, !tbaa !27
  %t431 = getelementptr ptr, ptr %t430, i64 %t423
  store ptr %t424, ptr %t431, !tbaa !39
  %t432 = load i64, ptr %l21, !tbaa !24
  %t433 = load i64, ptr %l16, !tbaa !24
  %t436 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t437 = load ptr, ptr %t436, !tbaa !27
  %t438 = getelementptr i64, ptr %t437, i64 %t432
  store i64 %t433, ptr %t438, !tbaa !34
  %t439 = load i64, ptr %l21, !tbaa !24
  %t441 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t442 = load ptr, ptr %t441, !tbaa !27
  %t443 = getelementptr i1, ptr %t442, i64 %t439
  store i1 true, ptr %t443, !tbaa !31
  br label %bb88
bb80:
  %t444 = load ptr, ptr %l0, !tbaa !29
  %t445 = load i32, ptr %l19, !tbaa !23
  %t448 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s19, ptr %t444, i32 %t445)
  store { i64, ptr } %t448, ptr %l228
  br label %bb82
bb81:
  %t449 = load ptr, ptr %l0, !tbaa !29
  %t450 = load i32, ptr %l19, !tbaa !23
  %t453 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s19, ptr %t449, i32 %t450)
  store { i64, ptr } %t453, ptr %l233
  br label %bb84
bb82:
  %t454 = load { i64, ptr }, ptr %l228, !tbaa !27
  %t455 = extractvalue { i64, ptr } %t454, 0
  %t456 = extractvalue { i64, ptr } %t454, 1
  %t457 = mul i64 %t455, 1
  %t458 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t457)
  call void @llvm.memcpy.p0.p0.i64(ptr %t458, ptr %t456, i64 %t457, i1 false)
  %t459 = insertvalue { i64, ptr } undef, i64 %t455, 0
  %t460 = insertvalue { i64, ptr } %t459, ptr %t458, 1
  %t462 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNamedArgTwice(ptr %s19, ptr %s19, { i64, ptr } %t460)
  store %"compiler/msgs:Msg" %t462, ptr %l230
  br label %bb83
bb83:
  %t463 = load %"compiler/msgs:Msg", ptr %l230
  store %"compiler/msgs:Msg" %t463, ptr %l225
  br label %bb86
bb84:
  %t464 = load { i64, ptr }, ptr %l233, !tbaa !27
  %t465 = extractvalue { i64, ptr } %t464, 0
  %t466 = extractvalue { i64, ptr } %t464, 1
  %t467 = mul i64 %t465, 1
  %t468 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t467)
  call void @llvm.memcpy.p0.p0.i64(ptr %t468, ptr %t466, i64 %t467, i1 false)
  %t469 = insertvalue { i64, ptr } undef, i64 %t465, 0
  %t470 = insertvalue { i64, ptr } %t469, ptr %t468, 1
  %t472 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNamedArgAlsoPositional(ptr %s19, ptr %s19, { i64, ptr } %t470)
  store %"compiler/msgs:Msg" %t472, ptr %l235
  br label %bb85
bb85:
  %t473 = load %"compiler/msgs:Msg", ptr %l235
  store %"compiler/msgs:Msg" %t473, ptr %l225
  br label %bb86
bb86:
  %t474 = load ptr, ptr %l221, !tbaa !29
  %t475 = load %"compiler/source:Span", ptr %l222
  %t476 = load %"compiler/msgs:Msg", ptr %l225
  %t477 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s19, ptr %t474, %"compiler/source:Span" %t475, %"compiler/msgs:Msg" %t476)
  store i64 %t477, ptr %l236
  br label %bb87
bb87:
  store i1 true, ptr %l7, !tbaa !21
  call void @__olang_scope_close(ptr %s19)
  br label %bb88
bb88:
  br label %bb89
bb89:
  br label %bb90
bb90:
  call void @__olang_scope_close(ptr %s4)
  br label %bb105
bb91:
  br i1 true, label %bb92, label %bb93
bb92:
  br label %bb94
bb93:
  br label %bb104
bb94:
  %t478 = load i1, ptr %l6, !tbaa !21
  br i1 %t478, label %bb95, label %bb96
bb95:
  store %olang.scope zeroinitializer, ptr %s22
  %t480 = load ptr, ptr %l0, !tbaa !29
  store ptr %t480, ptr %l244, !tbaa !29
  %t481 = load ptr, ptr %l17, !tbaa !29
  %t483 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t481)
  store %"compiler/source:Span" %t483, ptr %l246
  br label %bb97
bb96:
  %t484 = load i64, ptr %l5, !tbaa !24
  %t485 = load i64, ptr %l4, !tbaa !24
  %t488 = icmp slt i64 %t484, %t485
  br i1 %t488, label %bb100, label %bb101
bb97:
  %t490 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2ePositionalAfterNamed(ptr %s22)
  store %"compiler/msgs:Msg" %t490, ptr %l247
  br label %bb98
bb98:
  %t491 = load ptr, ptr %l244, !tbaa !29
  %t492 = load %"compiler/source:Span", ptr %l246
  %t493 = load %"compiler/msgs:Msg", ptr %l247
  %t494 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s22, ptr %t491, %"compiler/source:Span" %t492, %"compiler/msgs:Msg" %t493)
  store i64 %t494, ptr %l248
  br label %bb99
bb99:
  store i1 true, ptr %l7, !tbaa !21
  call void @__olang_scope_close(ptr %s22)
  br label %bb103
bb100:
  %t495 = load i64, ptr %l5, !tbaa !24
  %t496 = load ptr, ptr %l17, !tbaa !29
  %t499 = load ptr, ptr %lp8
  %t501 = getelementptr { i64, ptr }, ptr %t499, i32 0, i32 1
  %t502 = load ptr, ptr %t501, !tbaa !27
  %t503 = getelementptr ptr, ptr %t502, i64 %t495
  store ptr %t496, ptr %t503, !tbaa !39
  %t504 = load i64, ptr %l5, !tbaa !24
  %t505 = load i64, ptr %l16, !tbaa !24
  %t508 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t509 = load ptr, ptr %t508, !tbaa !27
  %t510 = getelementptr i64, ptr %t509, i64 %t504
  store i64 %t505, ptr %t510, !tbaa !34
  br label %bb102
bb101:
  br label %bb102
bb102:
  br label %bb103
bb103:
  %t511 = load i64, ptr %l5, !tbaa !24
  %t513 = add i64 %t511, 1
  store i64 %t513, ptr %l5, !tbaa !24
  br label %bb105
bb104:
  call void @__olang_check_failed(ptr @olang_loc_6a354e0ae5aa0db2_42d5d79e5424950e)
  unreachable
bb105:
  br label %bb106
bb106:
  %t515 = load i64, ptr %l15, !tbaa !24
  %t517 = add i64 %t515, 1
  store i64 %t517, ptr %l15, !tbaa !24
  br label %bb21
bb107:
  %t519 = load i64, ptr %l5, !tbaa !24
  %t520 = load i64, ptr %l4, !tbaa !24
  %t523 = icmp sgt i64 %t519, %t520
  br i1 %t523, label %bb108, label %bb109
bb108:
  store %olang.scope zeroinitializer, ptr %s26
  %t525 = load ptr, ptr %l0, !tbaa !29
  store ptr %t525, ptr %l264, !tbaa !29
  %t526 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t526, ptr %l265, !tbaa !27
  %t527 = load i64, ptr %l4, !tbaa !24
  %t529 = getelementptr { i64, ptr }, ptr %l265, i32 0, i32 1
  %t530 = load ptr, ptr %t529, !tbaa !27
  %t531 = getelementptr ptr, ptr %t530, i64 %t527
  %t532 = load ptr, ptr %t531, !tbaa !39
  %t534 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t532)
  store %"compiler/source:Span" %t534, ptr %l268
  br label %bb110
bb109:
  br label %bb116
bb110:
  %t535 = load i64, ptr %l4, !tbaa !24
  store i64 %t535, ptr %l269, !tbaa !24
  %t536 = load i64, ptr %l4, !tbaa !24
  %t538 = icmp eq i64 %t536, 1
  br i1 %t538, label %bb111, label %bb112
bb111:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d46, i32 0, i32 1) }, ptr %l272, !tbaa !27
  br label %bb113
bb112:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d47, i32 0, i32 1) }, ptr %l272, !tbaa !27
  br label %bb113
bb113:
  %t540 = load i64, ptr %l5, !tbaa !24
  %t541 = load i64, ptr %l269, !tbaa !24
  %t542 = load { i64, ptr }, ptr %l272, !tbaa !27
  %t544 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eArgCount(ptr %s26, ptr %s26, i64 %t541, { i64, ptr } %t542, i64 %t540)
  store %"compiler/msgs:Msg" %t544, ptr %l274
  br label %bb114
bb114:
  %t545 = load ptr, ptr %l264, !tbaa !29
  %t546 = load %"compiler/source:Span", ptr %l268
  %t547 = load %"compiler/msgs:Msg", ptr %l274
  %t548 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s26, ptr %t545, %"compiler/source:Span" %t546, %"compiler/msgs:Msg" %t547)
  store i64 %t548, ptr %l275
  br label %bb115
bb115:
  store i1 true, ptr %l7, !tbaa !21
  call void @__olang_scope_close(ptr %s26)
  br label %bb116
bb116:
  %t549 = load i1, ptr %l7, !tbaa !21
  br i1 %t549, label %bb117, label %bb118
bb117:
  %t551 = load ptr, ptr %l0, !tbaa !29
  %t553 = getelementptr %"compiler/check:Checker", ptr %t551, i32 0, i32 122
  store i1 true, ptr %t553, !tbaa !21
  %t554 = load { i64, ptr }, ptr %l2, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t554, ptr %rv
  br label %ret
bb118:
  br label %bb119
bb119:
  store i64 -1, ptr %l34, !tbaa !24
  store i64 0, ptr %l35, !tbaa !24
  %t556 = load i64, ptr %l4, !tbaa !24
  store i64 %t556, ptr %l36, !tbaa !24
  store i64 1, ptr %l37, !tbaa !24
  %t558 = load i64, ptr %l36, !tbaa !24
  %t559 = load i64, ptr %l35, !tbaa !24
  %t562 = icmp sgt i64 %t558, %t559
  br i1 %t562, label %bb120, label %bb121
bb120:
  %t564 = load i64, ptr %l37, !tbaa !24
  %t566 = icmp sgt i64 %t564, 0
  br i1 %t566, label %bb122, label %bb123
bb121:
  store i64 0, ptr %l283, !tbaa !24
  br label %bb125
bb122:
  %t568 = load i64, ptr %l36, !tbaa !24
  %t569 = load i64, ptr %l35, !tbaa !24
  %t572 = sub i64 %t568, %t569
  %t573 = load i64, ptr %l37, !tbaa !24
  %t576 = add i64 %t572, %t573
  %t578 = sub i64 %t576, 1
  %t579 = load i64, ptr %l37, !tbaa !24
  %t582 = sdiv i64 %t578, %t579
  store i64 %t582, ptr %l286, !tbaa !24
  br label %bb124
bb123:
  store i64 0, ptr %l286, !tbaa !24
  br label %bb124
bb124:
  %t584 = load i64, ptr %l286, !tbaa !24
  store i64 %t584, ptr %l283, !tbaa !24
  br label %bb125
bb125:
  %t585 = load i64, ptr %l283, !tbaa !24
  store i64 %t585, ptr %l38, !tbaa !24
  store i64 0, ptr %l39, !tbaa !24
  br label %bb126
bb126:
  %t586 = load i64, ptr %l39, !tbaa !24
  %t587 = load i64, ptr %l38, !tbaa !24
  %t590 = icmp slt i64 %t586, %t587
  %t592 = xor i1 %t590, true
  br i1 %t592, label %bb127, label %bb128
bb127:
  br label %bb134
bb128:
  br label %bb129
bb129:
  %t594 = load i64, ptr %l35, !tbaa !24
  %t595 = load i64, ptr %l39, !tbaa !24
  %t596 = load i64, ptr %l37, !tbaa !24
  %t599 = mul i64 %t595, %t596
  %t602 = add i64 %t594, %t599
  store i64 %t602, ptr %l40, !tbaa !24
  %t604 = load i64, ptr %l40, !tbaa !24
  %t605 = load ptr, ptr %lp8
  %t607 = getelementptr { i64, ptr }, ptr %t605, i32 0, i32 1
  %t608 = load ptr, ptr %t607, !tbaa !27
  %t609 = getelementptr ptr, ptr %t608, i64 %t604
  %t610 = load ptr, ptr %t609, !tbaa !39
  %t612 = icmp eq ptr %t610, null
  %t614 = xor i1 %t612, true
  br i1 %t614, label %bb130, label %bb131
bb130:
  %t616 = load i64, ptr %l40, !tbaa !24
  store i64 %t616, ptr %l34, !tbaa !24
  br label %bb132
bb131:
  br label %bb132
bb132:
  br label %bb133
bb133:
  %t618 = load i64, ptr %l39, !tbaa !24
  %t620 = add i64 %t618, 1
  store i64 %t620, ptr %l39, !tbaa !24
  br label %bb126
bb134:
  %t622 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t622, ptr %l311
  br label %bb135
bb135:
  %t623 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 8, i64 8)
  store ptr %t623, ptr %lp41
  %t624 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l311
  %t625 = load ptr, ptr %lp41
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t624, ptr %t625
  %t626 = load ptr, ptr %l0, !tbaa !29
  %t628 = getelementptr %"compiler/check:Checker", ptr %t626, i32 0, i32 123
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t628)
  br label %bb136
bb136:
  store i64 0, ptr %l42, !tbaa !24
  %t630 = load i64, ptr %l34, !tbaa !24
  %t632 = add i64 %t630, 1
  store i64 %t632, ptr %l43, !tbaa !24
  store i64 1, ptr %l44, !tbaa !24
  %t634 = load i64, ptr %l43, !tbaa !24
  %t635 = load i64, ptr %l42, !tbaa !24
  %t638 = icmp sgt i64 %t634, %t635
  br i1 %t638, label %bb137, label %bb138
bb137:
  %t640 = load i64, ptr %l44, !tbaa !24
  %t642 = icmp sgt i64 %t640, 0
  br i1 %t642, label %bb139, label %bb140
bb138:
  store i64 0, ptr %l319, !tbaa !24
  br label %bb142
bb139:
  %t644 = load i64, ptr %l43, !tbaa !24
  %t645 = load i64, ptr %l42, !tbaa !24
  %t648 = sub i64 %t644, %t645
  %t649 = load i64, ptr %l44, !tbaa !24
  %t652 = add i64 %t648, %t649
  %t654 = sub i64 %t652, 1
  %t655 = load i64, ptr %l44, !tbaa !24
  %t658 = sdiv i64 %t654, %t655
  store i64 %t658, ptr %l322, !tbaa !24
  br label %bb141
bb140:
  store i64 0, ptr %l322, !tbaa !24
  br label %bb141
bb141:
  %t660 = load i64, ptr %l322, !tbaa !24
  store i64 %t660, ptr %l319, !tbaa !24
  br label %bb142
bb142:
  %t661 = load i64, ptr %l319, !tbaa !24
  store i64 %t661, ptr %l45, !tbaa !24
  store i64 0, ptr %l46, !tbaa !24
  br label %bb143
bb143:
  %t662 = load i64, ptr %l46, !tbaa !24
  %t663 = load i64, ptr %l45, !tbaa !24
  %t666 = icmp slt i64 %t662, %t663
  %t668 = xor i1 %t666, true
  br i1 %t668, label %bb144, label %bb145
bb144:
  br label %bb155
bb145:
  br label %bb146
bb146:
  %t670 = load i64, ptr %l42, !tbaa !24
  %t671 = load i64, ptr %l46, !tbaa !24
  %t672 = load i64, ptr %l44, !tbaa !24
  %t675 = mul i64 %t671, %t672
  %t678 = add i64 %t670, %t675
  store i64 %t678, ptr %l47, !tbaa !24
  %t680 = load i64, ptr %l47, !tbaa !24
  %t681 = load ptr, ptr %lp8
  %t683 = getelementptr { i64, ptr }, ptr %t681, i32 0, i32 1
  %t684 = load ptr, ptr %t683, !tbaa !27
  %t685 = getelementptr ptr, ptr %t684, i64 %t680
  %t686 = load ptr, ptr %t685, !tbaa !39
  store ptr %t686, ptr %l48, !tbaa !29
  %t688 = load ptr, ptr %l48, !tbaa !29
  %t690 = icmp eq ptr %t688, null
  br i1 %t690, label %bb147, label %bb148
bb147:
  %t692 = load ptr, ptr %lp41
  store ptr %t692, ptr %l344, !tbaa !29
  %t693 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t693, ptr %l345, !tbaa !27
  %t694 = getelementptr { i64, ptr }, ptr %l345, i32 0, i32 1
  %t695 = load ptr, ptr %t694, !tbaa !27
  %t696 = getelementptr ptr, ptr %t695, i64 0
  %t697 = load ptr, ptr %t696, !tbaa !39
  %t699 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t697)
  store %"compiler/source:Span" %t699, ptr %l347
  br label %bb149
bb148:
  %t700 = load ptr, ptr %lp41
  %t701 = load ptr, ptr %l48, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v2, ptr %v2, ptr %t700, ptr %t701)
  br label %bb151
bb149:
  store { i64, [5 x i64] } zeroinitializer, ptr %t704
  %t705 = getelementptr { i64, [5 x i64] }, ptr %t704, i32 0, i32 0
  store i64 26, ptr %t705
  %t706 = load %"compiler/source:Span", ptr %l347
  %t707 = insertvalue { %"compiler/source:Span" } undef, %"compiler/source:Span" %t706, 0
  %t708 = getelementptr { i64, [5 x i64] }, ptr %t704, i32 0, i32 1
  store { %"compiler/source:Span" } %t707, ptr %t708
  %t709 = load { i64, [5 x i64] }, ptr %t704
  %t711 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store { i64, [5 x i64] } %t709, ptr %t711
  %t712 = load ptr, ptr %l344, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v2, ptr %v2, ptr %t712, ptr %t711)
  br label %bb150
bb150:
  br label %bb152
bb151:
  br label %bb152
bb152:
  %t714 = load ptr, ptr %l0, !tbaa !29
  %t716 = getelementptr %"compiler/check:Checker", ptr %t714, i32 0, i32 123
  %t717 = load i64, ptr %l47, !tbaa !24
  %t719 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t720 = load ptr, ptr %t719, !tbaa !27
  %t721 = getelementptr i64, ptr %t720, i64 %t717
  %t722 = load i64, ptr %t721, !tbaa !34
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t716, i64 %t722)
  br label %bb153
bb153:
  br label %bb154
bb154:
  %t725 = load i64, ptr %l46, !tbaa !24
  %t727 = add i64 %t725, 1
  store i64 %t727, ptr %l46, !tbaa !24
  br label %bb143
bb155:
  %t729 = load ptr, ptr %lp41
  %t731 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2eToArray_3ccompiler_2fast_3aExpr_26_3e(ptr %v2, ptr %v2, ptr %t729)
  store { i64, ptr } %t731, ptr %l359
  br label %bb156
bb156:
  call void @__olang_scope_close(ptr %s0)
  %t732 = load { i64, ptr }, ptr %l359, !tbaa !27
  store { i64, ptr } %t732, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enullKnown(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca %"compiler/check:nullNarrow"
  %l10 = alloca ptr
  %l13 = alloca i64
  %l15 = alloca i64
  %l20 = alloca %"compiler/check:nullNarrow"
  %l23 = alloca i1
  %l26 = alloca i1
  %rv = alloca i1
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t10 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %a0)
  store ptr %t10, ptr %l10
  br label %bb4
bb4:
  %t11 = load ptr, ptr %l10, !tbaa !29
  %t13 = getelementptr %"compiler/check:frame", ptr %t11, i32 0, i32 47
  store ptr %t13, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb5
bb5:
  %t15 = load i64, ptr %l3, !tbaa !24
  store i64 %t15, ptr %l13, !tbaa !24
  %t16 = load ptr, ptr %l2, !tbaa !29
  %t18 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anullNarrow_3e_2eLen_H4b13e48b0a317e727dbe35330ad8712a(ptr %v0, ptr %t16)
  store i64 %t18, ptr %l15
  br label %bb6
bb6:
  %t19 = load i64, ptr %l13, !tbaa !24
  %t20 = load i64, ptr %l15, !tbaa !24
  %t21 = icmp slt i64 %t19, %t20
  %t23 = xor i1 %t21, true
  br i1 %t23, label %bb7, label %bb8
bb7:
  br label %bb19
bb8:
  br label %bb9
bb9:
  %t25 = load ptr, ptr %l2, !tbaa !29
  %t26 = load i64, ptr %l3, !tbaa !24
  %t29 = call %"compiler/check:nullNarrow" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anullNarrow_3e_2eAt__H22e551fb00043bde3f1f8b2c6007f7cb(ptr %v0, ptr %v0, ptr %t25, i64 %t26)
  store %"compiler/check:nullNarrow" %t29, ptr %l20
  br label %bb10
bb10:
  %t30 = load %"compiler/check:nullNarrow", ptr %l20
  store %"compiler/check:nullNarrow" %t30, ptr %l4
  %t31 = getelementptr %"compiler/check:nullNarrow", ptr %l4, i32 0, i32 2
  %t32 = load i1, ptr %t31, !tbaa !21
  %t34 = xor i1 %t32, true
  br i1 %t34, label %bb11, label %bb12
bb11:
  %t36 = getelementptr %"compiler/check:nullNarrow", ptr %l4, i32 0, i32 0
  %t37 = load { i64, ptr }, ptr %t36, !tbaa !27
  %t38 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t41 = call i1 @compiler_2fcheck_2esamePath(ptr %v0, ptr %v1, { i64, ptr } %t37, { i64, ptr } %t38)
  store i1 %t41, ptr %l26
  br label %bb13
bb12:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb14
bb13:
  %t42 = load i1, ptr %l26, !tbaa !21
  store i1 %t42, ptr %l23, !tbaa !21
  br label %bb14
bb14:
  %t43 = load i1, ptr %l23, !tbaa !21
  br i1 %t43, label %bb15, label %bb16
bb15:
  store i1 true, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  br label %bb18
bb18:
  %t45 = load i64, ptr %l3, !tbaa !24
  %t47 = add i64 %t45, 1
  store i64 %t47, ptr %l3, !tbaa !24
  br label %bb5
bb19:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eorderModule(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l4 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca { i64, [2 x i64] }
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l19 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l20 = alloca ptr
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca ptr
  %l24 = alloca i64
  %l26 = alloca { i64, ptr }
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i1
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i64
  %l51 = alloca i64
  %l52 = alloca i64
  %l53 = alloca i64
  %l54 = alloca i64
  %l55 = alloca i64
  %l56 = alloca i64
  %l57 = alloca i64
  %l58 = alloca i64
  %l59 = alloca i64
  %l60 = alloca i64
  %l61 = alloca i64
  %l62 = alloca i64
  %l63 = alloca i64
  %l64 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l65 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l68 = alloca i64
  %l70 = alloca i64
  %l75 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l79 = alloca i64
  %l83 = alloca i64
  %l84 = alloca i32
  %l87 = alloca i1
  %l91 = alloca ptr
  %l95 = alloca i1
  %l98 = alloca i1
  %l99 = alloca ptr
  %l100 = alloca i64
  %l102 = alloca i64
  %l109 = alloca i64
  %l113 = alloca i64
  %l116 = alloca i64
  %l137 = alloca ptr
  %l146 = alloca i1
  %l150 = alloca ptr
  %l155 = alloca i1
  %l158 = alloca i1
  %l160 = alloca ptr
  %l161 = alloca i64
  %l163 = alloca i64
  %l169 = alloca i64
  %l170 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l171 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l173 = alloca i64
  %l175 = alloca i64
  %l180 = alloca i64
  %l181 = alloca ptr
  %l183 = alloca i64
  %l187 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l189 = alloca i64
  %l191 = alloca i64
  %l196 = alloca i64
  %l197 = alloca ptr
  %l198 = alloca i64
  %l201 = alloca i64
  %l202 = alloca i32
  %l207 = alloca ptr
  %l209 = alloca i64
  %l210 = alloca i64
  %l221 = alloca i64
  %l224 = alloca i64
  %l246 = alloca i64
  %l250 = alloca i64
  %l254 = alloca i64
  %l257 = alloca i64
  %l277 = alloca i64
  %l279 = alloca i1
  %l282 = alloca i64
  %l294 = alloca ptr
  %l297 = alloca i64
  %l305 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l306 = alloca i64
  %l309 = alloca i64
  %l310 = alloca i32
  %l319 = alloca i64
  %l323 = alloca i64
  %l326 = alloca i64
  %l346 = alloca i64
  %l347 = alloca ptr
  %l348 = alloca ptr
  %l351 = alloca i64
  %l352 = alloca i64
  %l361 = alloca i64
  %l365 = alloca i64
  %l369 = alloca i64
  %l372 = alloca i64
  %l392 = alloca i1
  %l395 = alloca i64
  %l397 = alloca i1
  %l400 = alloca i64
  %l405 = alloca i64
  %l414 = alloca i64
  %l417 = alloca i64
  %l439 = alloca ptr
  %l442 = alloca i64
  %s0 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s18 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l64
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l64
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l3
  %t3 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %s0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %l65
  br label %bb2
bb2:
  %t4 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l65
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t4, ptr %l4
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/check:Checker", ptr %t5, i32 0, i32 29
  store ptr %t7, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb3
bb3:
  %t9 = load i64, ptr %l6, !tbaa !24
  store i64 %t9, ptr %l68, !tbaa !24
  %t10 = load ptr, ptr %l5, !tbaa !29
  %t12 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_3e_Hda4ef06466535e66801340e999dad217(ptr %v0, ptr %t10)
  store i64 %t12, ptr %l70
  br label %bb4
bb4:
  %t13 = load i64, ptr %l68, !tbaa !24
  %t14 = load i64, ptr %l70, !tbaa !24
  %t15 = icmp slt i64 %t13, %t14
  %t17 = xor i1 %t15, true
  br i1 %t17, label %bb5, label %bb6
bb5:
  br label %bb31
bb6:
  br label %bb7
bb7:
  %t19 = load ptr, ptr %l5, !tbaa !29
  %t20 = load i64, ptr %l6, !tbaa !24
  %t23 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_3e_H87a29777ccf22aa2985fa9d3c61f9cd3(ptr %v0, ptr %t19, i64 %t20)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t23, ptr %l75
  br label %bb8
bb8:
  %t24 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l75
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t24, ptr %l7
  %t25 = getelementptr %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l7, i32 0, i32 0
  %t26 = load i64, ptr %t25, !tbaa !24
  %t27 = load i64, ptr %l1, !tbaa !24
  %t30 = icmp ne i64 %t26, %t27
  br i1 %t30, label %bb9, label %bb10
bb9:
  br label %bb30
bb10:
  br label %bb11
bb11:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/check:Checker", ptr %t32, i32 0, i32 27
  %t35 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l7
  %t38 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H5696e1a008d256bf9453cde2b49c6c45(ptr %v0, ptr %t34, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t35)
  %t39 = extractvalue { i32, i64 } %t38, 1
  %t40 = extractvalue { i32, i64 } %t38, 0
  store i32 %t40, ptr %l84
  %t41 = icmp ne i32 %t40, 0
  br i1 %t41, label %bb13, label %ok.42, !prof !99
ok.42:
  store i64 %t39, ptr %l83
  br label %bb12
bb12:
  %t43 = load i64, ptr %l83, !tbaa !24
  store i64 %t43, ptr %l79, !tbaa !24
  br label %bb15
bb13:
  br label %bb14
bb14:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l79, !tbaa !24
  br label %bb15
bb15:
  %t44 = load i64, ptr %l79, !tbaa !24
  store i64 %t44, ptr %l8, !tbaa !24
  %t45 = load i64, ptr %l8, !tbaa !24
  %t47 = icmp slt i64 %t45, 0
  br i1 %t47, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l87, !tbaa !21
  br label %bb19
bb17:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/check:Checker", ptr %t49, i32 0, i32 12
  %t52 = load i64, ptr %l8, !tbaa !24
  %t55 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t51, i64 %t52)
  store ptr %t55, ptr %l91
  br label %bb18
bb18:
  %t56 = load ptr, ptr %l91, !tbaa !29
  %t58 = getelementptr %"compiler/typed:Body", ptr %t56, i32 0, i32 11
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t61 = icmp eq ptr %t59, null
  store i1 %t61, ptr %l87, !tbaa !21
  br label %bb19
bb19:
  %t63 = load i1, ptr %l87, !tbaa !21
  br i1 %t63, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l95, !tbaa !21
  br label %bb23
bb21:
  %t64 = load i64, ptr %l8, !tbaa !24
  %t67 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %s0, ptr %l4, i64 %t64)
  store i1 %t67, ptr %l98
  br label %bb22
bb22:
  %t68 = load i1, ptr %l98, !tbaa !21
  store i1 %t68, ptr %l95, !tbaa !21
  br label %bb23
bb23:
  %t69 = load i1, ptr %l95, !tbaa !21
  br i1 %t69, label %bb24, label %bb25
bb24:
  br label %bb30
bb25:
  br label %bb26
bb26:
  store ptr %l4, ptr %l99, !tbaa !29
  %t70 = load i64, ptr %l8, !tbaa !24
  store i64 %t70, ptr %l100, !tbaa !24
  %t72 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l3)
  store i64 %t72, ptr %l102
  br label %bb27
bb27:
  %t73 = load ptr, ptr %l99, !tbaa !29
  %t74 = load i64, ptr %l100, !tbaa !24
  %t75 = load i64, ptr %l102, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %s0, ptr %t73, i64 %t74, i64 %t75)
  br label %bb28
bb28:
  %t76 = load i64, ptr %l8, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l3, i64 %t76)
  br label %bb29
bb29:
  br label %bb30
bb30:
  %t79 = load i64, ptr %l6, !tbaa !24
  %t81 = add i64 %t79, 1
  store i64 %t81, ptr %l6, !tbaa !24
  br label %bb3
bb31:
  store i64 0, ptr %l9, !tbaa !24
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/check:Checker", ptr %t83, i32 0, i32 12
  %t87 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t85)
  store i64 %t87, ptr %l109
  br label %bb32
bb32:
  %t88 = load i64, ptr %l109, !tbaa !24
  store i64 %t88, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t89 = load i64, ptr %l10, !tbaa !24
  %t90 = load i64, ptr %l9, !tbaa !24
  %t93 = icmp sgt i64 %t89, %t90
  br i1 %t93, label %bb33, label %bb34
bb33:
  %t95 = load i64, ptr %l11, !tbaa !24
  %t97 = icmp sgt i64 %t95, 0
  br i1 %t97, label %bb35, label %bb36
bb34:
  store i64 0, ptr %l113, !tbaa !24
  br label %bb38
bb35:
  %t99 = load i64, ptr %l10, !tbaa !24
  %t100 = load i64, ptr %l9, !tbaa !24
  %t103 = sub i64 %t99, %t100
  %t104 = load i64, ptr %l11, !tbaa !24
  %t107 = add i64 %t103, %t104
  %t109 = sub i64 %t107, 1
  %t110 = load i64, ptr %l11, !tbaa !24
  %t113 = sdiv i64 %t109, %t110
  store i64 %t113, ptr %l116, !tbaa !24
  br label %bb37
bb36:
  store i64 0, ptr %l116, !tbaa !24
  br label %bb37
bb37:
  %t115 = load i64, ptr %l116, !tbaa !24
  store i64 %t115, ptr %l113, !tbaa !24
  br label %bb38
bb38:
  %t116 = load i64, ptr %l113, !tbaa !24
  store i64 %t116, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb39
bb39:
  %t117 = load i64, ptr %l13, !tbaa !24
  %t118 = load i64, ptr %l12, !tbaa !24
  %t121 = icmp slt i64 %t117, %t118
  %t123 = xor i1 %t121, true
  br i1 %t123, label %bb40, label %bb41
bb40:
  br label %bb68
bb41:
  br label %bb42
bb42:
  %t125 = load i64, ptr %l9, !tbaa !24
  %t126 = load i64, ptr %l13, !tbaa !24
  %t127 = load i64, ptr %l11, !tbaa !24
  %t130 = mul i64 %t126, %t127
  %t133 = add i64 %t125, %t130
  store i64 %t133, ptr %l14, !tbaa !24
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t137 = getelementptr %"compiler/check:Checker", ptr %t135, i32 0, i32 12
  %t138 = load i64, ptr %l14, !tbaa !24
  %t141 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t137, i64 %t138)
  store ptr %t141, ptr %l137
  br label %bb43
bb43:
  %t142 = load ptr, ptr %l137, !tbaa !29
  %t144 = getelementptr %"compiler/typed:Body", ptr %t142, i32 0, i32 1
  %t145 = load { i64, [2 x i64] }, ptr %t144
  store { i64, [2 x i64] } %t145, ptr %l15
  %t147 = load { i64, [2 x i64] }, ptr %l15
  %t149 = extractvalue { i64, [2 x i64] } %t147, 0
  %t150 = icmp eq i64 %t149, 6
  br i1 %t150, label %bb44, label %bb45
bb44:
  %t152 = getelementptr { i64, [2 x i64] }, ptr %l15, i32 0, i32 1
  %t153 = getelementptr { i64, i32 }, ptr %t152, i32 0, i32 0
  %t154 = load i64, ptr %t153
  store i64 %t154, ptr %l16, !tbaa !24
  br label %bb46
bb45:
  br label %bb61
bb46:
  %t156 = load i64, ptr %l16, !tbaa !24
  %t157 = load i64, ptr %l1, !tbaa !24
  %t160 = icmp eq i64 %t156, %t157
  br i1 %t160, label %bb47, label %bb48
bb47:
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t164 = getelementptr %"compiler/check:Checker", ptr %t162, i32 0, i32 12
  %t165 = load i64, ptr %l14, !tbaa !24
  %t168 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t164, i64 %t165)
  store ptr %t168, ptr %l150
  br label %bb49
bb48:
  store i1 false, ptr %l146, !tbaa !21
  br label %bb50
bb49:
  %t169 = load ptr, ptr %l150, !tbaa !29
  %t171 = getelementptr %"compiler/typed:Body", ptr %t169, i32 0, i32 11
  %t172 = load ptr, ptr %t171, !tbaa !29
  %t174 = icmp eq ptr %t172, null
  %t176 = xor i1 %t174, true
  store i1 %t176, ptr %l146, !tbaa !21
  br label %bb50
bb50:
  %t178 = load i1, ptr %l146, !tbaa !21
  br i1 %t178, label %bb51, label %bb52
bb51:
  %t179 = load i64, ptr %l14, !tbaa !24
  %t182 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %s0, ptr %l4, i64 %t179)
  store i1 %t182, ptr %l158
  br label %bb53
bb52:
  store i1 false, ptr %l155, !tbaa !21
  br label %bb54
bb53:
  %t183 = load i1, ptr %l158, !tbaa !21
  %t184 = xor i1 %t183, true
  store i1 %t184, ptr %l155, !tbaa !21
  br label %bb54
bb54:
  %t186 = load i1, ptr %l155, !tbaa !21
  br i1 %t186, label %bb55, label %bb56
bb55:
  store ptr %l4, ptr %l160, !tbaa !29
  %t187 = load i64, ptr %l14, !tbaa !24
  store i64 %t187, ptr %l161, !tbaa !24
  %t189 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l3)
  store i64 %t189, ptr %l163
  br label %bb57
bb56:
  br label %bb60
bb57:
  %t190 = load ptr, ptr %l160, !tbaa !29
  %t191 = load i64, ptr %l161, !tbaa !24
  %t192 = load i64, ptr %l163, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %s0, ptr %t190, i64 %t191, i64 %t192)
  br label %bb58
bb58:
  %t193 = load i64, ptr %l14, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l3, i64 %t193)
  br label %bb59
bb59:
  br label %bb60
bb60:
  br label %bb66
bb61:
  br i1 true, label %bb62, label %bb63
bb62:
  br label %bb64
bb63:
  br label %bb65
bb64:
  br label %bb66
bb65:
  call void @__olang_check_failed(ptr @olang_loc_eb65b3680edb0345_685145072e457a11)
  unreachable
bb66:
  br label %bb67
bb67:
  %t196 = load i64, ptr %l13, !tbaa !24
  %t198 = add i64 %t196, 1
  store i64 %t198, ptr %l13, !tbaa !24
  br label %bb39
bb68:
  %t201 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l3)
  store i64 %t201, ptr %l169
  br label %bb69
bb69:
  %t202 = load i64, ptr %l169, !tbaa !24
  store i64 %t202, ptr %l17, !tbaa !24
  %t203 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t203, ptr %l170
  br label %bb70
bb70:
  %t204 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l170
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t204, ptr %l18
  %t205 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t205, ptr %l171
  br label %bb71
bb71:
  %t206 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l171
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t206, ptr %l19
  store ptr %l3, ptr %l20, !tbaa !29
  store i64 0, ptr %l21, !tbaa !24
  br label %bb72
bb72:
  %t208 = load i64, ptr %l21, !tbaa !24
  store i64 %t208, ptr %l173, !tbaa !24
  %t209 = load ptr, ptr %l20, !tbaa !29
  %t211 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t209)
  store i64 %t211, ptr %l175
  br label %bb73
bb73:
  %t212 = load i64, ptr %l173, !tbaa !24
  %t213 = load i64, ptr %l175, !tbaa !24
  %t214 = icmp slt i64 %t212, %t213
  %t216 = xor i1 %t214, true
  br i1 %t216, label %bb74, label %bb75
bb74:
  br label %bb95
bb75:
  br label %bb76
bb76:
  %t218 = load ptr, ptr %l20, !tbaa !29
  %t219 = load i64, ptr %l21, !tbaa !24
  %t222 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t218, i64 %t219)
  store i64 %t222, ptr %l180
  br label %bb77
bb77:
  %t223 = load i64, ptr %l180, !tbaa !24
  store i64 %t223, ptr %l22, !tbaa !24
  store ptr %l18, ptr %l181, !tbaa !29
  %t225 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l19)
  store i64 %t225, ptr %l183
  br label %bb78
bb78:
  %t226 = load ptr, ptr %l181, !tbaa !29
  %t227 = load i64, ptr %l183, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %t226, i64 %t227)
  br label %bb79
bb79:
  store %olang.scope zeroinitializer, ptr %s14
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t229 = load i64, ptr %l1, !tbaa !24
  %t230 = load i64, ptr %l22, !tbaa !24
  %t234 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eglobalDeps(ptr %v0, ptr %s14, ptr %t228, i64 %t229, i64 %t230)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t234, ptr %l187
  br label %bb80
bb80:
  %t235 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l187
  %t236 = call ptr @__olang_scope_alloc_a(ptr %s14, i64 8, i64 8)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t235, ptr %t236
  store ptr %t236, ptr %l23, !tbaa !29
  store i64 0, ptr %l24, !tbaa !24
  br label %bb81
bb81:
  %t238 = load i64, ptr %l24, !tbaa !24
  store i64 %t238, ptr %l189, !tbaa !24
  %t239 = load ptr, ptr %l23, !tbaa !29
  %t241 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s14, ptr %t239)
  store i64 %t241, ptr %l191
  br label %bb82
bb82:
  %t242 = load i64, ptr %l189, !tbaa !24
  %t243 = load i64, ptr %l191, !tbaa !24
  %t244 = icmp slt i64 %t242, %t243
  %t246 = xor i1 %t244, true
  br i1 %t246, label %bb83, label %bb84
bb83:
  br label %bb93
bb84:
  br label %bb85
bb85:
  %t248 = load ptr, ptr %l23, !tbaa !29
  %t249 = load i64, ptr %l24, !tbaa !24
  %t252 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s14, ptr %t248, i64 %t249)
  store i64 %t252, ptr %l196
  br label %bb86
bb86:
  %t253 = load i64, ptr %l196, !tbaa !24
  store ptr %l19, ptr %l197, !tbaa !29
  %t257 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %s0, ptr %l4, i64 %t253)
  %t258 = extractvalue { i32, i64 } %t257, 1
  %t259 = extractvalue { i32, i64 } %t257, 0
  store i32 %t259, ptr %l202
  %t260 = icmp ne i32 %t259, 0
  br i1 %t260, label %bb88, label %ok.261, !prof !99
ok.261:
  store i64 %t258, ptr %l201
  br label %bb87
bb87:
  %t262 = load i64, ptr %l201, !tbaa !24
  store i64 %t262, ptr %l198, !tbaa !24
  br label %bb90
bb88:
  br label %bb89
bb89:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l198, !tbaa !24
  br label %bb90
bb90:
  %t263 = load ptr, ptr %l197, !tbaa !29
  %t264 = load i64, ptr %l198, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %t263, i64 %t264)
  br label %bb91
bb91:
  br label %bb92
bb92:
  %t265 = load i64, ptr %l24, !tbaa !24
  %t267 = add i64 %t265, 1
  store i64 %t267, ptr %l24, !tbaa !24
  br label %bb81
bb93:
  call void @__olang_scope_close(ptr %s14)
  br label %bb94
bb94:
  %t269 = load i64, ptr %l21, !tbaa !24
  %t271 = add i64 %t269, 1
  store i64 %t271, ptr %l21, !tbaa !24
  br label %bb72
bb95:
  store ptr %l18, ptr %l207, !tbaa !29
  %t274 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l19)
  store i64 %t274, ptr %l209
  br label %bb96
bb96:
  %t275 = load ptr, ptr %l207, !tbaa !29
  %t276 = load i64, ptr %l209, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %t275, i64 %t276)
  br label %bb97
bb97:
  %t277 = load i64, ptr %l17, !tbaa !24
  store i64 %t277, ptr %l210, !tbaa !24
  %t278 = load i64, ptr %l210, !tbaa !24
  %t279 = icmp sge i64 %t278, 0
  br i1 %t279, label %bb98, label %bb99
bb98:
  %t281 = load i64, ptr %l210, !tbaa !24
  %t282 = mul i64 %t281, 1
  %t283 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t282)
  %t284 = insertvalue { i64, ptr } undef, i64 %t281, 0
  %t285 = insertvalue { i64, ptr } %t284, ptr %t283, 1
  store { i64, ptr } %t285, ptr %l26, !tbaa !27
  store i64 0, ptr %l27, !tbaa !24
  br label %bb100
bb99:
  call void @__olang_check_failed(ptr @olang_loc_becd3eb77e076db3_2d856a700a1e74b7)
  unreachable
bb100:
  store %olang.scope zeroinitializer, ptr %s18
  %t287 = load i64, ptr %l27, !tbaa !24
  %t288 = load i64, ptr %l17, !tbaa !24
  %t291 = icmp slt i64 %t287, %t288
  %t293 = xor i1 %t291, true
  br i1 %t293, label %bb101, label %bb102
bb101:
  call void @__olang_scope_close(ptr %s18)
  br label %bb232
bb102:
  br label %bb103
bb103:
  store i64 -1, ptr %l28, !tbaa !24
  store i64 0, ptr %l29, !tbaa !24
  %t295 = load i64, ptr %l17, !tbaa !24
  store i64 %t295, ptr %l30, !tbaa !24
  store i64 1, ptr %l31, !tbaa !24
  %t297 = load i64, ptr %l30, !tbaa !24
  %t298 = load i64, ptr %l29, !tbaa !24
  %t301 = icmp sgt i64 %t297, %t298
  br i1 %t301, label %bb104, label %bb105
bb104:
  %t303 = load i64, ptr %l31, !tbaa !24
  %t305 = icmp sgt i64 %t303, 0
  br i1 %t305, label %bb106, label %bb107
bb105:
  store i64 0, ptr %l221, !tbaa !24
  br label %bb109
bb106:
  %t307 = load i64, ptr %l30, !tbaa !24
  %t308 = load i64, ptr %l29, !tbaa !24
  %t311 = sub i64 %t307, %t308
  %t312 = load i64, ptr %l31, !tbaa !24
  %t315 = add i64 %t311, %t312
  %t317 = sub i64 %t315, 1
  %t318 = load i64, ptr %l31, !tbaa !24
  %t321 = sdiv i64 %t317, %t318
  store i64 %t321, ptr %l224, !tbaa !24
  br label %bb108
bb107:
  store i64 0, ptr %l224, !tbaa !24
  br label %bb108
bb108:
  %t323 = load i64, ptr %l224, !tbaa !24
  store i64 %t323, ptr %l221, !tbaa !24
  br label %bb109
bb109:
  %t324 = load i64, ptr %l221, !tbaa !24
  store i64 %t324, ptr %l32, !tbaa !24
  store i64 0, ptr %l33, !tbaa !24
  br label %bb110
bb110:
  %t325 = load i64, ptr %l33, !tbaa !24
  %t326 = load i64, ptr %l32, !tbaa !24
  %t329 = icmp slt i64 %t325, %t326
  %t331 = xor i1 %t329, true
  br i1 %t331, label %bb111, label %bb112
bb111:
  br label %bb143
bb112:
  br label %bb113
bb113:
  %t333 = load i64, ptr %l29, !tbaa !24
  %t334 = load i64, ptr %l33, !tbaa !24
  %t335 = load i64, ptr %l31, !tbaa !24
  %t338 = mul i64 %t334, %t335
  %t341 = add i64 %t333, %t338
  store i64 %t341, ptr %l34, !tbaa !24
  %t343 = load i64, ptr %l34, !tbaa !24
  %t345 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t346 = load ptr, ptr %t345, !tbaa !27
  %t347 = getelementptr i1, ptr %t346, i64 %t343
  %t348 = load i1, ptr %t347, !tbaa !31
  br i1 %t348, label %bb114, label %bb115
bb114:
  br label %bb142
bb115:
  br label %bb116
bb116:
  store i1 true, ptr %l35, !tbaa !21
  %t350 = load i64, ptr %l34, !tbaa !24
  %t353 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l18, i64 %t350)
  store i64 %t353, ptr %l246
  br label %bb117
bb117:
  %t354 = load i64, ptr %l246, !tbaa !24
  store i64 %t354, ptr %l36, !tbaa !24
  %t355 = load i64, ptr %l34, !tbaa !24
  %t357 = add i64 %t355, 1
  %t360 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l18, i64 %t357)
  store i64 %t360, ptr %l250
  br label %bb118
bb118:
  %t361 = load i64, ptr %l250, !tbaa !24
  store i64 %t361, ptr %l37, !tbaa !24
  store i64 1, ptr %l38, !tbaa !24
  %t362 = load i64, ptr %l37, !tbaa !24
  %t363 = load i64, ptr %l36, !tbaa !24
  %t366 = icmp sgt i64 %t362, %t363
  br i1 %t366, label %bb119, label %bb120
bb119:
  %t368 = load i64, ptr %l38, !tbaa !24
  %t370 = icmp sgt i64 %t368, 0
  br i1 %t370, label %bb121, label %bb122
bb120:
  store i64 0, ptr %l254, !tbaa !24
  br label %bb124
bb121:
  %t372 = load i64, ptr %l37, !tbaa !24
  %t373 = load i64, ptr %l36, !tbaa !24
  %t376 = sub i64 %t372, %t373
  %t377 = load i64, ptr %l38, !tbaa !24
  %t380 = add i64 %t376, %t377
  %t382 = sub i64 %t380, 1
  %t383 = load i64, ptr %l38, !tbaa !24
  %t386 = sdiv i64 %t382, %t383
  store i64 %t386, ptr %l257, !tbaa !24
  br label %bb123
bb122:
  store i64 0, ptr %l257, !tbaa !24
  br label %bb123
bb123:
  %t388 = load i64, ptr %l257, !tbaa !24
  store i64 %t388, ptr %l254, !tbaa !24
  br label %bb124
bb124:
  %t389 = load i64, ptr %l254, !tbaa !24
  store i64 %t389, ptr %l39, !tbaa !24
  store i64 0, ptr %l40, !tbaa !24
  br label %bb125
bb125:
  %t390 = load i64, ptr %l40, !tbaa !24
  %t391 = load i64, ptr %l39, !tbaa !24
  %t394 = icmp slt i64 %t390, %t391
  %t396 = xor i1 %t394, true
  br i1 %t396, label %bb126, label %bb127
bb126:
  br label %bb138
bb127:
  br label %bb128
bb128:
  %t398 = load i64, ptr %l36, !tbaa !24
  %t399 = load i64, ptr %l40, !tbaa !24
  %t400 = load i64, ptr %l38, !tbaa !24
  %t403 = mul i64 %t399, %t400
  %t406 = add i64 %t398, %t403
  store i64 %t406, ptr %l41, !tbaa !24
  %t408 = load i64, ptr %l41, !tbaa !24
  %t411 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l19, i64 %t408)
  store i64 %t411, ptr %l277
  br label %bb129
bb129:
  %t412 = load i64, ptr %l277, !tbaa !24
  %t413 = icmp sge i64 %t412, 0
  br i1 %t413, label %bb130, label %bb131
bb130:
  %t415 = load i64, ptr %l41, !tbaa !24
  %t418 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l19, i64 %t415)
  store i64 %t418, ptr %l282
  br label %bb132
bb131:
  store i1 false, ptr %l279, !tbaa !21
  br label %bb133
bb132:
  %t419 = load i64, ptr %l282, !tbaa !24
  %t420 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t421 = load ptr, ptr %t420, !tbaa !27
  %t422 = getelementptr i1, ptr %t421, i64 %t419
  %t423 = load i1, ptr %t422, !tbaa !31
  %t425 = xor i1 %t423, true
  store i1 %t425, ptr %l279, !tbaa !21
  br label %bb133
bb133:
  %t427 = load i1, ptr %l279, !tbaa !21
  br i1 %t427, label %bb134, label %bb135
bb134:
  store i1 false, ptr %l35, !tbaa !21
  br label %bb136
bb135:
  br label %bb136
bb136:
  br label %bb137
bb137:
  %t428 = load i64, ptr %l40, !tbaa !24
  %t430 = add i64 %t428, 1
  store i64 %t430, ptr %l40, !tbaa !24
  br label %bb125
bb138:
  %t432 = load i1, ptr %l35, !tbaa !21
  br i1 %t432, label %bb139, label %bb140
bb139:
  %t434 = load i64, ptr %l34, !tbaa !24
  store i64 %t434, ptr %l28, !tbaa !24
  br label %bb143
bb140:
  br label %bb141
bb141:
  br label %bb142
bb142:
  %t436 = load i64, ptr %l33, !tbaa !24
  %t438 = add i64 %t436, 1
  store i64 %t438, ptr %l33, !tbaa !24
  br label %bb110
bb143:
  %t440 = load i64, ptr %l28, !tbaa !24
  %t442 = icmp sge i64 %t440, 0
  br i1 %t442, label %bb144, label %bb145
bb144:
  %t444 = load i64, ptr %l28, !tbaa !24
  %t446 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t447 = load ptr, ptr %t446, !tbaa !27
  %t448 = getelementptr i1, ptr %t447, i64 %t444
  store i1 true, ptr %t448, !tbaa !31
  %t449 = load ptr, ptr %l2, !tbaa !29
  store ptr %t449, ptr %l294, !tbaa !29
  %t450 = load i64, ptr %l28, !tbaa !24
  %t453 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l3, i64 %t450)
  store i64 %t453, ptr %l297
  br label %bb146
bb145:
  br label %bb148
bb146:
  %t454 = load ptr, ptr %l294, !tbaa !29
  %t455 = load i64, ptr %l297, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t454, i64 %t455)
  br label %bb147
bb147:
  %t456 = load i64, ptr %l27, !tbaa !24
  %t458 = add i64 %t456, 1
  store i64 %t458, ptr %l27, !tbaa !24
  call void @__olang_scope_close(ptr %s18)
  br label %bb231
bb148:
  store i64 0, ptr %l42, !tbaa !24
  br label %bb149
bb149:
  %t460 = load i64, ptr %l42, !tbaa !24
  %t462 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t463 = load ptr, ptr %t462, !tbaa !27
  %t464 = getelementptr i1, ptr %t463, i64 %t460
  %t465 = load i1, ptr %t464, !tbaa !31
  %t467 = xor i1 %t465, true
  br i1 %t467, label %bb150, label %bb151
bb150:
  br label %bb154
bb151:
  br label %bb152
bb152:
  %t469 = load i64, ptr %l42, !tbaa !24
  %t471 = add i64 %t469, 1
  store i64 %t471, ptr %l42, !tbaa !24
  br label %bb153
bb153:
  br label %bb149
bb154:
  %t473 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s18, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t473, ptr %l305
  br label %bb155
bb155:
  %t474 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l305
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t474, ptr %l43
  br label %bb156
bb156:
  %t475 = load i64, ptr %l42, !tbaa !24
  %t478 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eIndexOf_3cI64_3e(ptr %s18, ptr %l43, i64 %t475)
  %t479 = extractvalue { i32, i64 } %t478, 1
  %t480 = extractvalue { i32, i64 } %t478, 0
  store i32 %t480, ptr %l310
  %t481 = icmp ne i32 %t480, 0
  br i1 %t481, label %bb158, label %ok.482, !prof !99
ok.482:
  store i64 %t479, ptr %l309
  br label %bb157
bb157:
  %t483 = load i64, ptr %l309, !tbaa !24
  store i64 %t483, ptr %l306, !tbaa !24
  br label %bb160
bb158:
  br label %bb159
bb159:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l306, !tbaa !24
  br label %bb160
bb160:
  %t484 = load i64, ptr %l306, !tbaa !24
  store i64 %t484, ptr %l44, !tbaa !24
  %t485 = load i64, ptr %l44, !tbaa !24
  %t487 = icmp sge i64 %t485, 0
  br i1 %t487, label %bb161, label %bb162
bb161:
  %t489 = load ptr, ptr %l0, !tbaa !29
  %t490 = load i64, ptr %l44, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aCycle(ptr %v0, ptr %s0, ptr %s18, ptr %t489, ptr %l3, ptr %l43, i64 %t490)
  br label %bb163
bb162:
  br label %bb181
bb163:
  %t495 = load i64, ptr %l44, !tbaa !24
  store i64 %t495, ptr %l45, !tbaa !24
  %t498 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s18, ptr %l43)
  store i64 %t498, ptr %l319
  br label %bb164
bb164:
  %t499 = load i64, ptr %l319, !tbaa !24
  store i64 %t499, ptr %l46, !tbaa !24
  store i64 1, ptr %l47, !tbaa !24
  %t500 = load i64, ptr %l46, !tbaa !24
  %t501 = load i64, ptr %l45, !tbaa !24
  %t504 = icmp sgt i64 %t500, %t501
  br i1 %t504, label %bb165, label %bb166
bb165:
  %t506 = load i64, ptr %l47, !tbaa !24
  %t508 = icmp sgt i64 %t506, 0
  br i1 %t508, label %bb167, label %bb168
bb166:
  store i64 0, ptr %l323, !tbaa !24
  br label %bb170
bb167:
  %t510 = load i64, ptr %l46, !tbaa !24
  %t511 = load i64, ptr %l45, !tbaa !24
  %t514 = sub i64 %t510, %t511
  %t515 = load i64, ptr %l47, !tbaa !24
  %t518 = add i64 %t514, %t515
  %t520 = sub i64 %t518, 1
  %t521 = load i64, ptr %l47, !tbaa !24
  %t524 = sdiv i64 %t520, %t521
  store i64 %t524, ptr %l326, !tbaa !24
  br label %bb169
bb168:
  store i64 0, ptr %l326, !tbaa !24
  br label %bb169
bb169:
  %t526 = load i64, ptr %l326, !tbaa !24
  store i64 %t526, ptr %l323, !tbaa !24
  br label %bb170
bb170:
  %t527 = load i64, ptr %l323, !tbaa !24
  store i64 %t527, ptr %l48, !tbaa !24
  store i64 0, ptr %l49, !tbaa !24
  br label %bb171
bb171:
  %t528 = load i64, ptr %l49, !tbaa !24
  %t529 = load i64, ptr %l48, !tbaa !24
  %t532 = icmp slt i64 %t528, %t529
  %t534 = xor i1 %t532, true
  br i1 %t534, label %bb172, label %bb173
bb172:
  br label %bb180
bb173:
  br label %bb174
bb174:
  %t536 = load i64, ptr %l45, !tbaa !24
  %t537 = load i64, ptr %l49, !tbaa !24
  %t538 = load i64, ptr %l47, !tbaa !24
  %t541 = mul i64 %t537, %t538
  %t544 = add i64 %t536, %t541
  store i64 %t544, ptr %l50, !tbaa !24
  %t546 = load i64, ptr %l50, !tbaa !24
  %t549 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s18, ptr %l43, i64 %t546)
  store i64 %t549, ptr %l346
  br label %bb175
bb175:
  %t550 = load i64, ptr %l346, !tbaa !24
  %t551 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t552 = load ptr, ptr %t551, !tbaa !27
  %t553 = getelementptr i1, ptr %t552, i64 %t550
  store i1 true, ptr %t553, !tbaa !31
  %t554 = load ptr, ptr %l2, !tbaa !29
  store ptr %t554, ptr %l347, !tbaa !29
  store ptr %l3, ptr %l348, !tbaa !29
  %t555 = load i64, ptr %l50, !tbaa !24
  %t558 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s18, ptr %l43, i64 %t555)
  store i64 %t558, ptr %l351
  br label %bb176
bb176:
  %t559 = load ptr, ptr %l348, !tbaa !29
  %t560 = load i64, ptr %l351, !tbaa !24
  %t561 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t559, i64 %t560)
  store i64 %t561, ptr %l352
  br label %bb177
bb177:
  %t562 = load ptr, ptr %l347, !tbaa !29
  %t563 = load i64, ptr %l352, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t562, i64 %t563)
  br label %bb178
bb178:
  %t564 = load i64, ptr %l27, !tbaa !24
  %t566 = add i64 %t564, 1
  store i64 %t566, ptr %l27, !tbaa !24
  br label %bb179
bb179:
  %t568 = load i64, ptr %l49, !tbaa !24
  %t570 = add i64 %t568, 1
  store i64 %t570, ptr %l49, !tbaa !24
  br label %bb171
bb180:
  br label %bb230
bb181:
  %t572 = load i64, ptr %l42, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s18, ptr %l43, i64 %t572)
  br label %bb182
bb182:
  store i64 -1, ptr %l51, !tbaa !24
  %t575 = load i64, ptr %l42, !tbaa !24
  %t578 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l18, i64 %t575)
  store i64 %t578, ptr %l361
  br label %bb183
bb183:
  %t579 = load i64, ptr %l361, !tbaa !24
  store i64 %t579, ptr %l52, !tbaa !24
  %t580 = load i64, ptr %l42, !tbaa !24
  %t582 = add i64 %t580, 1
  %t585 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l18, i64 %t582)
  store i64 %t585, ptr %l365
  br label %bb184
bb184:
  %t586 = load i64, ptr %l365, !tbaa !24
  store i64 %t586, ptr %l53, !tbaa !24
  store i64 1, ptr %l54, !tbaa !24
  %t587 = load i64, ptr %l53, !tbaa !24
  %t588 = load i64, ptr %l52, !tbaa !24
  %t591 = icmp sgt i64 %t587, %t588
  br i1 %t591, label %bb185, label %bb186
bb185:
  %t593 = load i64, ptr %l54, !tbaa !24
  %t595 = icmp sgt i64 %t593, 0
  br i1 %t595, label %bb187, label %bb188
bb186:
  store i64 0, ptr %l369, !tbaa !24
  br label %bb190
bb187:
  %t597 = load i64, ptr %l53, !tbaa !24
  %t598 = load i64, ptr %l52, !tbaa !24
  %t601 = sub i64 %t597, %t598
  %t602 = load i64, ptr %l54, !tbaa !24
  %t605 = add i64 %t601, %t602
  %t607 = sub i64 %t605, 1
  %t608 = load i64, ptr %l54, !tbaa !24
  %t611 = sdiv i64 %t607, %t608
  store i64 %t611, ptr %l372, !tbaa !24
  br label %bb189
bb188:
  store i64 0, ptr %l372, !tbaa !24
  br label %bb189
bb189:
  %t613 = load i64, ptr %l372, !tbaa !24
  store i64 %t613, ptr %l369, !tbaa !24
  br label %bb190
bb190:
  %t614 = load i64, ptr %l369, !tbaa !24
  store i64 %t614, ptr %l55, !tbaa !24
  store i64 0, ptr %l56, !tbaa !24
  br label %bb191
bb191:
  %t615 = load i64, ptr %l56, !tbaa !24
  %t616 = load i64, ptr %l55, !tbaa !24
  %t619 = icmp slt i64 %t615, %t616
  %t621 = xor i1 %t619, true
  br i1 %t621, label %bb192, label %bb193
bb192:
  br label %bb208
bb193:
  br label %bb194
bb194:
  %t623 = load i64, ptr %l52, !tbaa !24
  %t624 = load i64, ptr %l56, !tbaa !24
  %t625 = load i64, ptr %l54, !tbaa !24
  %t628 = mul i64 %t624, %t625
  %t631 = add i64 %t623, %t628
  store i64 %t631, ptr %l57, !tbaa !24
  %t633 = load i64, ptr %l51, !tbaa !24
  %t635 = icmp slt i64 %t633, 0
  br i1 %t635, label %bb195, label %bb196
bb195:
  %t637 = load i64, ptr %l57, !tbaa !24
  %t640 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l19, i64 %t637)
  store i64 %t640, ptr %l395
  br label %bb197
bb196:
  store i1 false, ptr %l392, !tbaa !21
  br label %bb198
bb197:
  %t641 = load i64, ptr %l395, !tbaa !24
  %t642 = icmp sge i64 %t641, 0
  store i1 %t642, ptr %l392, !tbaa !21
  br label %bb198
bb198:
  %t644 = load i1, ptr %l392, !tbaa !21
  br i1 %t644, label %bb199, label %bb200
bb199:
  %t645 = load i64, ptr %l57, !tbaa !24
  %t648 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l19, i64 %t645)
  store i64 %t648, ptr %l400
  br label %bb201
bb200:
  store i1 false, ptr %l397, !tbaa !21
  br label %bb202
bb201:
  %t649 = load i64, ptr %l400, !tbaa !24
  %t650 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t651 = load ptr, ptr %t650, !tbaa !27
  %t652 = getelementptr i1, ptr %t651, i64 %t649
  %t653 = load i1, ptr %t652, !tbaa !31
  %t655 = xor i1 %t653, true
  store i1 %t655, ptr %l397, !tbaa !21
  br label %bb202
bb202:
  %t657 = load i1, ptr %l397, !tbaa !21
  br i1 %t657, label %bb203, label %bb204
bb203:
  %t658 = load i64, ptr %l57, !tbaa !24
  %t661 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l19, i64 %t658)
  store i64 %t661, ptr %l405
  br label %bb205
bb204:
  br label %bb206
bb205:
  %t662 = load i64, ptr %l405, !tbaa !24
  store i64 %t662, ptr %l51, !tbaa !24
  br label %bb206
bb206:
  br label %bb207
bb207:
  %t663 = load i64, ptr %l56, !tbaa !24
  %t665 = add i64 %t663, 1
  store i64 %t665, ptr %l56, !tbaa !24
  br label %bb191
bb208:
  %t667 = load i64, ptr %l51, !tbaa !24
  %t669 = icmp slt i64 %t667, 0
  br i1 %t669, label %bb209, label %bb210
bb209:
  store i64 0, ptr %l58, !tbaa !24
  %t671 = load i64, ptr %l17, !tbaa !24
  store i64 %t671, ptr %l59, !tbaa !24
  store i64 1, ptr %l60, !tbaa !24
  %t673 = load i64, ptr %l59, !tbaa !24
  %t674 = load i64, ptr %l58, !tbaa !24
  %t677 = icmp sgt i64 %t673, %t674
  br i1 %t677, label %bb211, label %bb212
bb210:
  br label %bb228
bb211:
  %t679 = load i64, ptr %l60, !tbaa !24
  %t681 = icmp sgt i64 %t679, 0
  br i1 %t681, label %bb213, label %bb214
bb212:
  store i64 0, ptr %l414, !tbaa !24
  br label %bb216
bb213:
  %t683 = load i64, ptr %l59, !tbaa !24
  %t684 = load i64, ptr %l58, !tbaa !24
  %t687 = sub i64 %t683, %t684
  %t688 = load i64, ptr %l60, !tbaa !24
  %t691 = add i64 %t687, %t688
  %t693 = sub i64 %t691, 1
  %t694 = load i64, ptr %l60, !tbaa !24
  %t697 = sdiv i64 %t693, %t694
  store i64 %t697, ptr %l417, !tbaa !24
  br label %bb215
bb214:
  store i64 0, ptr %l417, !tbaa !24
  br label %bb215
bb215:
  %t699 = load i64, ptr %l417, !tbaa !24
  store i64 %t699, ptr %l414, !tbaa !24
  br label %bb216
bb216:
  %t700 = load i64, ptr %l414, !tbaa !24
  store i64 %t700, ptr %l61, !tbaa !24
  store i64 0, ptr %l62, !tbaa !24
  br label %bb217
bb217:
  %t701 = load i64, ptr %l62, !tbaa !24
  %t702 = load i64, ptr %l61, !tbaa !24
  %t705 = icmp slt i64 %t701, %t702
  %t707 = xor i1 %t705, true
  br i1 %t707, label %bb218, label %bb219
bb218:
  br label %bb227
bb219:
  br label %bb220
bb220:
  %t709 = load i64, ptr %l58, !tbaa !24
  %t710 = load i64, ptr %l62, !tbaa !24
  %t711 = load i64, ptr %l60, !tbaa !24
  %t714 = mul i64 %t710, %t711
  %t717 = add i64 %t709, %t714
  store i64 %t717, ptr %l63, !tbaa !24
  %t719 = load i64, ptr %l63, !tbaa !24
  %t721 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t722 = load ptr, ptr %t721, !tbaa !27
  %t723 = getelementptr i1, ptr %t722, i64 %t719
  %t724 = load i1, ptr %t723, !tbaa !31
  %t726 = xor i1 %t724, true
  br i1 %t726, label %bb221, label %bb222
bb221:
  %t728 = load i64, ptr %l63, !tbaa !24
  %t730 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t731 = load ptr, ptr %t730, !tbaa !27
  %t732 = getelementptr i1, ptr %t731, i64 %t728
  store i1 true, ptr %t732, !tbaa !31
  %t733 = load ptr, ptr %l2, !tbaa !29
  store ptr %t733, ptr %l439, !tbaa !29
  %t734 = load i64, ptr %l63, !tbaa !24
  %t737 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l3, i64 %t734)
  store i64 %t737, ptr %l442
  br label %bb223
bb222:
  br label %bb225
bb223:
  %t738 = load ptr, ptr %l439, !tbaa !29
  %t739 = load i64, ptr %l442, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t738, i64 %t739)
  br label %bb224
bb224:
  %t740 = load i64, ptr %l27, !tbaa !24
  %t742 = add i64 %t740, 1
  store i64 %t742, ptr %l27, !tbaa !24
  br label %bb225
bb225:
  br label %bb226
bb226:
  %t744 = load i64, ptr %l62, !tbaa !24
  %t746 = add i64 %t744, 1
  store i64 %t746, ptr %l62, !tbaa !24
  br label %bb217
bb227:
  br label %bb230
bb228:
  %t748 = load i64, ptr %l51, !tbaa !24
  store i64 %t748, ptr %l42, !tbaa !24
  br label %bb229
bb229:
  br label %bb156
bb230:
  call void @__olang_scope_close(ptr %s18)
  br label %bb231
bb231:
  br label %bb100
bb232:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparamOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l5 = alloca i64
  %l8 = alloca i64
  %l11 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erootLocal(ptr %v0, ptr %v1, ptr %t1, ptr %a1)
  store i64 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i64, ptr %l5, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load i64, ptr %l2, !tbaa !24
  %t9 = icmp sge i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load i64, ptr %l2, !tbaa !24
  %t15 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparamIndex(ptr %v0, ptr %t11, i64 %t12)
  store i64 %t15, ptr %l11
  br label %bb4
bb3:
  store i64 -1, ptr %l8, !tbaa !24
  br label %bb5
bb4:
  %t16 = load i64, ptr %l11, !tbaa !24
  store i64 %t16, ptr %l8, !tbaa !24
  br label %bb5
bb5:
  %t17 = load i64, ptr %l8, !tbaa !24
  store i64 %t17, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epartsEqual(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l12 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca ptr
  %l22 = alloca i1
  %l27 = alloca i32
  %l28 = alloca ptr
  %l29 = alloca %"compiler/source:Span"
  %l30 = alloca i32
  %l31 = alloca ptr
  %l32 = alloca %"compiler/source:Span"
  %l37 = alloca ptr
  %l39 = alloca ptr
  %l40 = alloca ptr
  %l41 = alloca %"compiler/source:Span"
  %l46 = alloca ptr
  %l48 = alloca ptr
  %l49 = alloca ptr
  %l55 = alloca i32
  %l58 = alloca i1
  %l65 = alloca i32
  %l68 = alloca i1
  %l71 = alloca i32
  %l78 = alloca i32
  %l86 = alloca ptr
  %l90 = alloca i1
  %l93 = alloca i32
  %l101 = alloca ptr
  %l106 = alloca i64
  %l107 = alloca ptr
  %l108 = alloca %"compiler/source:Span"
  %l113 = alloca ptr
  %l114 = alloca ptr
  %l115 = alloca ptr
  %l116 = alloca %"compiler/source:Span"
  %l121 = alloca ptr
  %l122 = alloca ptr
  %l127 = alloca { i64, ptr }
  %l131 = alloca ptr
  %l137 = alloca i64
  %l140 = alloca i64
  %l158 = alloca ptr
  %l159 = alloca %"compiler/source:Span"
  %l160 = alloca i32
  %l164 = alloca { i64, ptr }
  %l171 = alloca ptr
  %l175 = alloca { i64, ptr }
  %l182 = alloca ptr
  %l183 = alloca ptr
  %l186 = alloca ptr
  %l188 = alloca %"compiler/source:Span"
  %l189 = alloca i32
  %l190 = alloca ptr
  %l192 = alloca ptr
  %l196 = alloca ptr
  %l197 = alloca %"compiler/typed:Cond"
  %l205 = alloca i64
  %l208 = alloca %"compiler/source:Span"
  %l209 = alloca i32
  %l213 = alloca { i64, ptr }
  %l216 = alloca %"compiler/typed:Seq"
  %rv = alloca ptr
  %t291 = alloca { i64, [4 x i64] }, align 8
  %t321 = alloca { i64, [4 x i64] }, align 8
  %t370 = alloca { i64, [5 x i64] }, align 8
  %t414 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  store i32 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l4, !tbaa !23
  %t5 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisOver(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l22
  br label %bb1
bb1:
  %t6 = load i1, ptr %l22, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  %t13 = load i32, ptr %l4, !tbaa !23
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t16, ptr %l27
  br label %bb4
bb3:
  br label %bb10
bb4:
  %t17 = load i32, ptr %l27, !tbaa !23
  store i32 %t17, ptr %l5, !tbaa !23
  %t18 = load ptr, ptr %l0, !tbaa !29
  store ptr %t18, ptr %l28, !tbaa !29
  %t19 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t19, ptr %l29
  store i32 76, ptr %l30
  %t20 = load ptr, ptr %l0, !tbaa !29
  store ptr %t20, ptr %l31, !tbaa !29
  %t21 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t21, ptr %l32
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load ptr, ptr %l2, !tbaa !29
  %t24 = load i32, ptr %l4, !tbaa !23
  %t25 = load %"compiler/source:Span", ptr %l1
  %t30 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %t22, ptr %t23, i32 %t24, %"compiler/source:Span" %t25)
  store ptr %t30, ptr %l37
  br label %bb5
bb5:
  %t31 = load i32, ptr %l5, !tbaa !23
  %t32 = load ptr, ptr %l31, !tbaa !29
  %t33 = load %"compiler/source:Span", ptr %l32
  %t34 = load ptr, ptr %l37, !tbaa !29
  %t36 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %t32, %"compiler/source:Span" %t33, ptr %t34, i32 %t31)
  store ptr %t36, ptr %l39
  br label %bb6
bb6:
  %t37 = load ptr, ptr %l0, !tbaa !29
  store ptr %t37, ptr %l40, !tbaa !29
  %t38 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t38, ptr %l41
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load ptr, ptr %l3, !tbaa !29
  %t41 = load i32, ptr %l4, !tbaa !23
  %t42 = load %"compiler/source:Span", ptr %l1
  %t47 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %t39, ptr %t40, i32 %t41, %"compiler/source:Span" %t42)
  store ptr %t47, ptr %l46
  br label %bb7
bb7:
  %t48 = load i32, ptr %l5, !tbaa !23
  %t49 = load ptr, ptr %l40, !tbaa !29
  %t50 = load %"compiler/source:Span", ptr %l41
  %t51 = load ptr, ptr %l46, !tbaa !29
  %t53 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %t49, %"compiler/source:Span" %t50, ptr %t51, i32 %t48)
  store ptr %t53, ptr %l48
  br label %bb8
bb8:
  %t54 = load ptr, ptr %l28, !tbaa !29
  %t55 = load %"compiler/source:Span", ptr %l29
  %t56 = load i32, ptr %l30
  %t57 = load ptr, ptr %l39, !tbaa !29
  %t58 = load ptr, ptr %l48, !tbaa !29
  %t59 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eequality(ptr %v0, ptr %t54, %"compiler/source:Span" %t55, i32 %t56, ptr %t57, ptr %t58)
  store ptr %t59, ptr %l49
  br label %bb9
bb9:
  %t60 = load ptr, ptr %l49, !tbaa !29
  store ptr %t60, ptr %rv
  br label %ret
bb10:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/check:Checker", ptr %t62, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t67 = getelementptr %"compiler/generic:Program", ptr %t65, i32 0, i32 2
  %t68 = load i32, ptr %l4, !tbaa !23
  %t71 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t67, i32 %t68)
  store i32 %t71, ptr %l55
  br label %bb11
bb11:
  %t72 = load i32, ptr %l55
  store i32 %t72, ptr %l6
  store i32 0, ptr %l7, !tbaa !23
  %t73 = load i32, ptr %l6
  %t75 = trunc i64 23 to i32
  %t76 = icmp eq i32 %t73, %t75
  br i1 %t76, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l58, !tbaa !21
  br label %bb14
bb13:
  %t78 = load i32, ptr %l6
  %t80 = trunc i64 22 to i32
  %t81 = icmp eq i32 %t78, %t80
  store i1 %t81, ptr %l58, !tbaa !21
  br label %bb14
bb14:
  %t83 = load i1, ptr %l58, !tbaa !21
  br i1 %t83, label %bb15, label %bb16
bb15:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/check:Checker", ptr %t84, i32 0, i32 1
  %t87 = load ptr, ptr %t86, !tbaa !29
  %t89 = getelementptr %"compiler/generic:Program", ptr %t87, i32 0, i32 2
  %t90 = load i32, ptr %l4, !tbaa !23
  %t93 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t89, i32 %t90)
  store i32 %t93, ptr %l65
  br label %bb17
bb16:
  %t94 = load i32, ptr %l6
  %t96 = trunc i64 18 to i32
  %t97 = icmp eq i32 %t94, %t96
  br i1 %t97, label %bb18, label %bb19
bb17:
  %t99 = load i32, ptr %l65, !tbaa !23
  store i32 %t99, ptr %l7, !tbaa !23
  br label %bb36
bb18:
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t101 = load i32, ptr %l4, !tbaa !23
  %t104 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %t100, i32 %t101)
  store i32 %t104, ptr %l71
  br label %bb20
bb19:
  store i1 false, ptr %l68, !tbaa !21
  br label %bb21
bb20:
  %t105 = load i32, ptr %l71
  %t107 = trunc i64 0 to i32
  %t108 = icmp eq i32 %t105, %t107
  store i1 %t108, ptr %l68, !tbaa !21
  br label %bb21
bb21:
  %t110 = load i1, ptr %l68, !tbaa !21
  br i1 %t110, label %bb22, label %bb23
bb22:
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr %"compiler/check:Checker", ptr %t111, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !29
  %t116 = getelementptr %"compiler/generic:Program", ptr %t114, i32 0, i32 2
  %t117 = load i32, ptr %l4, !tbaa !23
  %t120 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t116, i32 %t117)
  store i32 %t120, ptr %l78
  br label %bb24
bb23:
  %t121 = load i32, ptr %l6
  %t123 = trunc i64 19 to i32
  %t124 = icmp eq i32 %t121, %t123
  br i1 %t124, label %bb25, label %bb26
bb24:
  %t126 = load i32, ptr %l78, !tbaa !23
  store i32 %t126, ptr %l7, !tbaa !23
  br label %bb35
bb25:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t128 = load %"compiler/source:Span", ptr %l1
  %t129 = load ptr, ptr %l2, !tbaa !29
  %t130 = load ptr, ptr %l3, !tbaa !29
  %t131 = load i32, ptr %l4, !tbaa !23
  %t137 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earraysEqual(ptr %v0, ptr %t127, %"compiler/source:Span" %t128, ptr %t129, ptr %t130, i32 %t131)
  store ptr %t137, ptr %l86
  br label %bb27
bb26:
  %t138 = load i32, ptr %l6
  %t140 = trunc i64 18 to i32
  %t141 = icmp eq i32 %t138, %t140
  br i1 %t141, label %bb28, label %bb29
bb27:
  %t143 = load ptr, ptr %l86, !tbaa !29
  store ptr %t143, ptr %rv
  br label %ret
bb28:
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t146 = load i32, ptr %l4, !tbaa !23
  %t149 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %t145, i32 %t146)
  store i32 %t149, ptr %l93
  br label %bb30
bb29:
  store i1 false, ptr %l90, !tbaa !21
  br label %bb31
bb30:
  %t150 = load i32, ptr %l93
  %t152 = trunc i64 1 to i32
  %t153 = icmp eq i32 %t150, %t152
  store i1 %t153, ptr %l90, !tbaa !21
  br label %bb31
bb31:
  %t155 = load i1, ptr %l90, !tbaa !21
  br i1 %t155, label %bb32, label %bb33
bb32:
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t157 = load %"compiler/source:Span", ptr %l1
  %t158 = load ptr, ptr %l2, !tbaa !29
  %t159 = load ptr, ptr %l3, !tbaa !29
  %t160 = load i32, ptr %l4, !tbaa !23
  %t166 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eenumsEqual(ptr %v0, ptr %t156, %"compiler/source:Span" %t157, ptr %t158, ptr %t159, i32 %t160)
  store ptr %t166, ptr %l101
  br label %bb34
bb33:
  store ptr null, ptr %rv
  br label %ret
bb34:
  %t168 = load ptr, ptr %l101, !tbaa !29
  store ptr %t168, ptr %rv
  br label %ret
bb35:
  br label %bb36
bb36:
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t172 = getelementptr %"compiler/check:Checker", ptr %t170, i32 0, i32 37
  %t174 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t172)
  store i64 %t174, ptr %l106
  br label %bb37
bb37:
  %t175 = load i64, ptr %l106, !tbaa !24
  store i64 %t175, ptr %l8, !tbaa !24
  %t176 = load ptr, ptr %l0, !tbaa !29
  store ptr %t176, ptr %l107, !tbaa !29
  %t177 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t177, ptr %l108
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t179 = load ptr, ptr %l2, !tbaa !29
  %t180 = load i32, ptr %l4, !tbaa !23
  %t181 = load %"compiler/source:Span", ptr %l1
  %t186 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %t178, ptr %t179, i32 %t180, %"compiler/source:Span" %t181)
  store ptr %t186, ptr %l113
  br label %bb38
bb38:
  %t187 = load ptr, ptr %l107, !tbaa !29
  %t188 = load %"compiler/source:Span", ptr %l108
  %t189 = load ptr, ptr %l113, !tbaa !29
  %t190 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eheldOf(ptr %v0, ptr %t187, %"compiler/source:Span" %t188, ptr %t189)
  store ptr %t190, ptr %l114
  br label %bb39
bb39:
  %t191 = load ptr, ptr %l114, !tbaa !29
  store ptr %t191, ptr %l9, !tbaa !29
  %t192 = load ptr, ptr %l0, !tbaa !29
  store ptr %t192, ptr %l115, !tbaa !29
  %t193 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t193, ptr %l116
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t195 = load ptr, ptr %l3, !tbaa !29
  %t196 = load i32, ptr %l4, !tbaa !23
  %t197 = load %"compiler/source:Span", ptr %l1
  %t202 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %t194, ptr %t195, i32 %t196, %"compiler/source:Span" %t197)
  store ptr %t202, ptr %l121
  br label %bb40
bb40:
  %t203 = load ptr, ptr %l115, !tbaa !29
  %t204 = load %"compiler/source:Span", ptr %l116
  %t205 = load ptr, ptr %l121, !tbaa !29
  %t206 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eheldOf(ptr %v0, ptr %t203, %"compiler/source:Span" %t204, ptr %t205)
  store ptr %t206, ptr %l122
  br label %bb41
bb41:
  %t207 = load ptr, ptr %l122, !tbaa !29
  store ptr %t207, ptr %l10, !tbaa !29
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t210 = getelementptr %"compiler/check:Checker", ptr %t208, i32 0, i32 1
  %t211 = load ptr, ptr %t210, !tbaa !29
  %t213 = getelementptr %"compiler/generic:Program", ptr %t211, i32 0, i32 2
  %t214 = load i32, ptr %l7, !tbaa !23
  %t217 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t213, i32 %t214)
  store { i64, ptr } %t217, ptr %l127
  br label %bb42
bb42:
  %t218 = load { i64, ptr }, ptr %l127, !tbaa !27
  store { i64, ptr } %t218, ptr %l11, !tbaa !27
  %t219 = load ptr, ptr %l0, !tbaa !29
  %t220 = load %"compiler/source:Span", ptr %l1
  %t221 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t225 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t219, %"compiler/source:Span" %t220, i32 %t221, i64 1)
  store ptr %t225, ptr %l131
  br label %bb43
bb43:
  %t226 = load ptr, ptr %l131, !tbaa !29
  store ptr %t226, ptr %l12, !tbaa !29
  store i64 0, ptr %l13, !tbaa !24
  %t227 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t229 = extractvalue { i64, ptr } %t227, 0
  store i64 %t229, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t231 = load i64, ptr %l14, !tbaa !24
  %t232 = load i64, ptr %l13, !tbaa !24
  %t235 = icmp sgt i64 %t231, %t232
  br i1 %t235, label %bb44, label %bb45
bb44:
  %t237 = load i64, ptr %l15, !tbaa !24
  %t239 = icmp sgt i64 %t237, 0
  br i1 %t239, label %bb46, label %bb47
bb45:
  store i64 0, ptr %l137, !tbaa !24
  br label %bb49
bb46:
  %t241 = load i64, ptr %l14, !tbaa !24
  %t242 = load i64, ptr %l13, !tbaa !24
  %t245 = sub i64 %t241, %t242
  %t246 = load i64, ptr %l15, !tbaa !24
  %t249 = add i64 %t245, %t246
  %t251 = sub i64 %t249, 1
  %t252 = load i64, ptr %l15, !tbaa !24
  %t255 = sdiv i64 %t251, %t252
  store i64 %t255, ptr %l140, !tbaa !24
  br label %bb48
bb47:
  store i64 0, ptr %l140, !tbaa !24
  br label %bb48
bb48:
  %t257 = load i64, ptr %l140, !tbaa !24
  store i64 %t257, ptr %l137, !tbaa !24
  br label %bb49
bb49:
  %t258 = load i64, ptr %l137, !tbaa !24
  store i64 %t258, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb50
bb50:
  %t259 = load i64, ptr %l17, !tbaa !24
  %t260 = load i64, ptr %l16, !tbaa !24
  %t263 = icmp slt i64 %t259, %t260
  %t265 = xor i1 %t263, true
  br i1 %t265, label %bb51, label %bb52
bb51:
  br label %bb63
bb52:
  br label %bb53
bb53:
  %t267 = load i64, ptr %l13, !tbaa !24
  %t268 = load i64, ptr %l17, !tbaa !24
  %t269 = load i64, ptr %l15, !tbaa !24
  %t272 = mul i64 %t268, %t269
  %t275 = add i64 %t267, %t272
  store i64 %t275, ptr %l18, !tbaa !24
  %t277 = load ptr, ptr %l0, !tbaa !29
  store ptr %t277, ptr %l158, !tbaa !29
  %t278 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t278, ptr %l159
  store i32 76, ptr %l160
  %t279 = load ptr, ptr %l0, !tbaa !29
  %t280 = load %"compiler/source:Span", ptr %l1
  %t281 = load %"compiler/source:Span", ptr %l1
  %t282 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t282, ptr %l164, !tbaa !27
  %t283 = load i64, ptr %l18, !tbaa !24
  %t285 = getelementptr { i64, ptr }, ptr %l164, i32 0, i32 1
  %t286 = load ptr, ptr %t285, !tbaa !27
  %t287 = getelementptr i32, ptr %t286, i64 %t283
  %t288 = load i32, ptr %t287, !tbaa !33
  %t289 = load ptr, ptr %l9, !tbaa !29
  %t290 = load i64, ptr %l18, !tbaa !24
  store { i64, [4 x i64] } zeroinitializer, ptr %t291
  %t292 = getelementptr { i64, [4 x i64] }, ptr %t291, i32 0, i32 0
  store i64 3, ptr %t292
  %t294 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } undef, %"compiler/source:Span" %t281, 0
  %t296 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t294, i32 %t288, 1
  %t298 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t296, ptr %t289, 2
  %t300 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t298, i64 %t290, 3
  %t301 = getelementptr { i64, [4 x i64] }, ptr %t291, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i64 } %t300, ptr %t301
  %t302 = load { i64, [4 x i64] }, ptr %t291
  %t304 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t302, ptr %t304
  %t308 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t279, %"compiler/source:Span" %t280, ptr %t304)
  store ptr %t308, ptr %l171
  br label %bb54
bb54:
  %t309 = load ptr, ptr %l0, !tbaa !29
  %t310 = load %"compiler/source:Span", ptr %l1
  %t311 = load %"compiler/source:Span", ptr %l1
  %t312 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t312, ptr %l175, !tbaa !27
  %t313 = load i64, ptr %l18, !tbaa !24
  %t315 = getelementptr { i64, ptr }, ptr %l175, i32 0, i32 1
  %t316 = load ptr, ptr %t315, !tbaa !27
  %t317 = getelementptr i32, ptr %t316, i64 %t313
  %t318 = load i32, ptr %t317, !tbaa !33
  %t319 = load ptr, ptr %l10, !tbaa !29
  %t320 = load i64, ptr %l18, !tbaa !24
  store { i64, [4 x i64] } zeroinitializer, ptr %t321
  %t322 = getelementptr { i64, [4 x i64] }, ptr %t321, i32 0, i32 0
  store i64 3, ptr %t322
  %t324 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } undef, %"compiler/source:Span" %t311, 0
  %t326 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t324, i32 %t318, 1
  %t328 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t326, ptr %t319, 2
  %t330 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t328, i64 %t320, 3
  %t331 = getelementptr { i64, [4 x i64] }, ptr %t321, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i64 } %t330, ptr %t331
  %t332 = load { i64, [4 x i64] }, ptr %t321
  %t334 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t332, ptr %t334
  %t338 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t309, %"compiler/source:Span" %t310, ptr %t334)
  store ptr %t338, ptr %l182
  br label %bb55
bb55:
  %t339 = load ptr, ptr %l158, !tbaa !29
  %t340 = load %"compiler/source:Span", ptr %l159
  %t341 = load i32, ptr %l160
  %t342 = load ptr, ptr %l171, !tbaa !29
  %t343 = load ptr, ptr %l182, !tbaa !29
  %t344 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eequality(ptr %v0, ptr %t339, %"compiler/source:Span" %t340, i32 %t341, ptr %t342, ptr %t343)
  store ptr %t344, ptr %l183
  br label %bb56
bb56:
  %t345 = load ptr, ptr %l183, !tbaa !29
  store ptr %t345, ptr %l19, !tbaa !29
  %t346 = load i64, ptr %l18, !tbaa !24
  %t348 = icmp eq i64 %t346, 0
  br i1 %t348, label %bb57, label %bb58
bb57:
  %t350 = load ptr, ptr %l19, !tbaa !29
  store ptr %t350, ptr %l186, !tbaa !29
  br label %bb61
bb58:
  %t352 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t352, ptr %l188
  %t353 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t353, ptr %l189, !tbaa !23
  %t354 = load ptr, ptr %l12, !tbaa !29
  store ptr %t354, ptr %l190, !tbaa !29
  %t355 = load ptr, ptr %l19, !tbaa !29
  store ptr %t355, ptr %l192, !tbaa !29
  %t357 = load ptr, ptr %l0, !tbaa !29
  %t358 = load %"compiler/source:Span", ptr %l1
  %t359 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t363 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t357, %"compiler/source:Span" %t358, i32 %t359, i64 0)
  store ptr %t363, ptr %l196
  br label %bb59
bb59:
  %t364 = load ptr, ptr %l190, !tbaa !29
  %t365 = load ptr, ptr %l192, !tbaa !29
  %t366 = load ptr, ptr %l196, !tbaa !29
  %t367 = call %"compiler/typed:Cond" @compiler_2ftyped_3aCond_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t364, ptr %t365, ptr %t366)
  store %"compiler/typed:Cond" %t367, ptr %l197
  br label %bb60
bb60:
  %t368 = load %"compiler/typed:Cond", ptr %l197
  %t369 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Cond" %t368, ptr %t369
  store { i64, [5 x i64] } zeroinitializer, ptr %t370
  %t371 = getelementptr { i64, [5 x i64] }, ptr %t370, i32 0, i32 0
  store i64 11, ptr %t371
  %t372 = load %"compiler/source:Span", ptr %l188
  %t373 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t372, 0
  %t374 = load i32, ptr %l189, !tbaa !23
  %t375 = insertvalue { %"compiler/source:Span", i32, ptr } %t373, i32 %t374, 1
  %t377 = insertvalue { %"compiler/source:Span", i32, ptr } %t375, ptr %t369, 2
  %t378 = getelementptr { i64, [5 x i64] }, ptr %t370, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t377, ptr %t378
  %t379 = load { i64, [5 x i64] }, ptr %t370
  %t381 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t379, ptr %t381
  store ptr %t381, ptr %l186, !tbaa !29
  br label %bb61
bb61:
  %t383 = load ptr, ptr %l186, !tbaa !29
  store ptr %t383, ptr %l12, !tbaa !29
  br label %bb62
bb62:
  %t384 = load i64, ptr %l17, !tbaa !24
  %t386 = add i64 %t384, 1
  store i64 %t386, ptr %l17, !tbaa !24
  br label %bb50
bb63:
  %t388 = load ptr, ptr %l0, !tbaa !29
  %t390 = getelementptr %"compiler/check:Checker", ptr %t388, i32 0, i32 37
  %t392 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t390)
  store i64 %t392, ptr %l205
  br label %bb64
bb64:
  %t393 = load i64, ptr %l8, !tbaa !24
  %t394 = load i64, ptr %l205, !tbaa !24
  %t396 = icmp sgt i64 %t394, %t393
  br i1 %t396, label %bb65, label %bb66
bb65:
  %t398 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t398, ptr %l208
  %t399 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t399, ptr %l209, !tbaa !23
  %t400 = load ptr, ptr %l0, !tbaa !29
  %t402 = getelementptr %"compiler/check:Checker", ptr %t400, i32 0, i32 37
  %t403 = load i64, ptr %l8, !tbaa !24
  %t406 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t402, i64 %t403)
  store { i64, ptr } %t406, ptr %l213
  br label %bb67
bb66:
  br label %bb69
bb67:
  %t407 = load ptr, ptr %l12, !tbaa !29
  %t409 = load { i64, ptr }, ptr %l213, !tbaa !27
  %t411 = call %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t409, ptr %t407)
  store %"compiler/typed:Seq" %t411, ptr %l216
  br label %bb68
bb68:
  %t412 = load %"compiler/typed:Seq", ptr %l216
  %t413 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Seq" %t412, ptr %t413
  store { i64, [5 x i64] } zeroinitializer, ptr %t414
  %t415 = getelementptr { i64, [5 x i64] }, ptr %t414, i32 0, i32 0
  store i64 12, ptr %t415
  %t416 = load %"compiler/source:Span", ptr %l208
  %t417 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t416, 0
  %t418 = load i32, ptr %l209, !tbaa !23
  %t419 = insertvalue { %"compiler/source:Span", i32, ptr } %t417, i32 %t418, 1
  %t421 = insertvalue { %"compiler/source:Span", i32, ptr } %t419, ptr %t413, 2
  %t422 = getelementptr { i64, [5 x i64] }, ptr %t414, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t421, ptr %t422
  %t423 = load { i64, [5 x i64] }, ptr %t414
  %t425 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t423, ptr %t425
  store ptr %t425, ptr %rv
  br label %ret
bb69:
  %t427 = load ptr, ptr %l12, !tbaa !29
  store ptr %t427, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epathPart(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l15 = alloca { i64, ptr }
  %l23 = alloca i64
  %l26 = alloca i64
  %l47 = alloca i1
  %l48 = alloca { i64, ptr }
  %l69 = alloca %"compiler/source:Span"
  %s4 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t4 = getelementptr %"compiler/ast:Path", ptr %t2, i32 0, i32 0
  %t5 = load %"compiler/source:Span", ptr %t4
  %t8 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %a0, %"compiler/source:Span" %t5)
  store { i64, ptr } %t8, ptr %l15
  br label %bb1
bb1:
  %t9 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t9, ptr %l3, !tbaa !27
  %t10 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  %t14 = load i64, ptr %l2, !tbaa !24
  %t16 = add i64 %t14, 1
  store i64 %t16, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t18 = load i64, ptr %l6, !tbaa !24
  %t19 = load i64, ptr %l5, !tbaa !24
  %t22 = icmp sgt i64 %t18, %t19
  br i1 %t22, label %bb2, label %bb3
bb2:
  %t24 = load i64, ptr %l7, !tbaa !24
  %t26 = icmp sgt i64 %t24, 0
  br i1 %t26, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb7
bb4:
  %t28 = load i64, ptr %l6, !tbaa !24
  %t29 = load i64, ptr %l5, !tbaa !24
  %t32 = sub i64 %t28, %t29
  %t33 = load i64, ptr %l7, !tbaa !24
  %t36 = add i64 %t32, %t33
  %t38 = sub i64 %t36, 1
  %t39 = load i64, ptr %l7, !tbaa !24
  %t42 = sdiv i64 %t38, %t39
  store i64 %t42, ptr %l26, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l26, !tbaa !24
  br label %bb6
bb6:
  %t44 = load i64, ptr %l26, !tbaa !24
  store i64 %t44, ptr %l23, !tbaa !24
  br label %bb7
bb7:
  %t45 = load i64, ptr %l23, !tbaa !24
  store i64 %t45, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb8
bb8:
  %t46 = load i64, ptr %l9, !tbaa !24
  %t47 = load i64, ptr %l8, !tbaa !24
  %t50 = icmp slt i64 %t46, %t47
  %t52 = xor i1 %t50, true
  br i1 %t52, label %bb9, label %bb10
bb9:
  br label %bb29
bb10:
  br label %bb11
bb11:
  %t54 = load i64, ptr %l5, !tbaa !24
  %t55 = load i64, ptr %l9, !tbaa !24
  %t56 = load i64, ptr %l7, !tbaa !24
  %t59 = mul i64 %t55, %t56
  %t62 = add i64 %t54, %t59
  store i64 %t62, ptr %l10, !tbaa !24
  %t64 = load i64, ptr %l4, !tbaa !24
  store i64 %t64, ptr %l11, !tbaa !24
  br label %bb12
bb12:
  %t66 = load i64, ptr %l11, !tbaa !24
  %t68 = icmp sgt i64 %t66, 0
  br i1 %t68, label %bb13, label %bb14
bb13:
  %t70 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t70, ptr %l48, !tbaa !27
  %t71 = load i64, ptr %l11, !tbaa !24
  %t73 = sub i64 %t71, 1
  %t75 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = getelementptr i8, ptr %t76, i64 %t73
  %t78 = load i8, ptr %t77, !tbaa !32
  %t80 = icmp ne i8 %t78, 46
  store i1 %t80, ptr %l47, !tbaa !21
  br label %bb15
bb14:
  store i1 false, ptr %l47, !tbaa !21
  br label %bb15
bb15:
  %t82 = load i1, ptr %l47, !tbaa !21
  %t83 = xor i1 %t82, true
  br i1 %t83, label %bb16, label %bb17
bb16:
  br label %bb20
bb17:
  br label %bb18
bb18:
  %t85 = load i64, ptr %l11, !tbaa !24
  %t87 = sub i64 %t85, 1
  store i64 %t87, ptr %l11, !tbaa !24
  br label %bb19
bb19:
  br label %bb12
bb20:
  %t89 = load i64, ptr %l10, !tbaa !24
  %t90 = load i64, ptr %l2, !tbaa !24
  %t93 = icmp eq i64 %t89, %t90
  br i1 %t93, label %bb21, label %bb22
bb21:
  store %olang.scope zeroinitializer, ptr %s4
  %t95 = load ptr, ptr %l1, !tbaa !29
  %t97 = getelementptr %"compiler/ast:Path", ptr %t95, i32 0, i32 0
  %t98 = getelementptr %"compiler/source:Span", ptr %t97, i32 0, i32 0
  %t99 = load i32, ptr %t98, !tbaa !23
  %t100 = load i64, ptr %l11, !tbaa !24
  %t102 = trunc i64 %t100 to i32
  %t105 = add i32 %t99, %t102
  %t106 = load ptr, ptr %l1, !tbaa !29
  %t108 = getelementptr %"compiler/ast:Path", ptr %t106, i32 0, i32 0
  %t109 = getelementptr %"compiler/source:Span", ptr %t108, i32 0, i32 0
  %t110 = load i32, ptr %t109, !tbaa !23
  %t111 = load i64, ptr %l4, !tbaa !24
  %t113 = trunc i64 %t111 to i32
  %t116 = add i32 %t110, %t113
  %t119 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s4, i32 %t105, i32 %t116)
  store %"compiler/source:Span" %t119, ptr %l69
  br label %bb23
bb22:
  br label %bb24
bb23:
  call void @__olang_scope_close(ptr %s4)
  %t120 = load %"compiler/source:Span", ptr %l69
  store %"compiler/source:Span" %t120, ptr %rv
  br label %ret
bb24:
  %t121 = load i64, ptr %l11, !tbaa !24
  %t123 = sub i64 %t121, 1
  store i64 %t123, ptr %l4, !tbaa !24
  %t125 = load i64, ptr %l4, !tbaa !24
  %t127 = icmp slt i64 %t125, 0
  br i1 %t127, label %bb25, label %bb26
bb25:
  %t129 = load ptr, ptr %l1, !tbaa !29
  %t131 = getelementptr %"compiler/ast:Path", ptr %t129, i32 0, i32 0
  %t132 = load %"compiler/source:Span", ptr %t131
  store %"compiler/source:Span" %t132, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  br label %bb28
bb28:
  %t134 = load i64, ptr %l9, !tbaa !24
  %t136 = add i64 %t134, 1
  store i64 %t136, ptr %l9, !tbaa !24
  br label %bb8
bb29:
  %t138 = load ptr, ptr %l1, !tbaa !29
  %t140 = getelementptr %"compiler/ast:Path", ptr %t138, i32 0, i32 0
  %t141 = load %"compiler/source:Span", ptr %t140
  store %"compiler/source:Span" %t141, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplaceName(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i1
  %l12 = alloca ptr
  %l14 = alloca %"compiler/typed:Local"
  %l16 = alloca ptr
  %l17 = alloca i1
  %rv = alloca i32
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb8
bb5:
  %t18 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %a0)
  store ptr %t18, ptr %l12
  br label %bb6
bb6:
  %t19 = load i32, ptr %l2, !tbaa !23
  %t20 = load ptr, ptr %l12, !tbaa !29
  %t22 = call %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %t20, i32 %t19)
  store %"compiler/typed:Local" %t22, ptr %l14
  br label %bb7
bb7:
  %t23 = getelementptr %"compiler/typed:Local", ptr %l14, i32 0, i32 0
  %t24 = load i32, ptr %t23, !tbaa !23
  store i32 %t24, ptr %l4, !tbaa !23
  br label %bb19
bb8:
  %t26 = load ptr, ptr %l1, !tbaa !29
  store ptr %t26, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t27 = load ptr, ptr %l16, !tbaa !29
  %t28 = icmp ne ptr %t27, null
  br i1 %t28, label %bb9, label %bb10
bb9:
  %t30 = load ptr, ptr %l16, !tbaa !29
  %t31 = load i64, ptr %t30
  %t33 = icmp eq i64 %t31, 1
  store i1 %t33, ptr %l17, !tbaa !21
  br label %bb10
bb10:
  %t34 = load i1, ptr %l17, !tbaa !21
  br i1 %t34, label %bb11, label %bb12
bb11:
  %t35 = load ptr, ptr %l1, !tbaa !29
  %t37 = getelementptr { i64, [4 x i64] }, ptr %t35, i32 0, i32 1
  %t38 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t37, i32 0, i32 3
  %t39 = load i32, ptr %t38
  store i32 %t39, ptr %l3, !tbaa !23
  br label %bb13
bb12:
  br label %bb14
bb13:
  %t41 = load i32, ptr %l3, !tbaa !23
  store i32 %t41, ptr %l4, !tbaa !23
  br label %bb19
bb14:
  br i1 true, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  store i32 0, ptr %l4, !tbaa !23
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_1f453287a90ee701_f75bf1e5be6f432d)
  unreachable
bb19:
  %t43 = load i32, ptr %l4, !tbaa !23
  store i32 %t43, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eputTarget(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2, ptr %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca i32
  %l9 = alloca ptr
  %l11 = alloca %"compiler/source:Span"
  %l13 = alloca ptr
  %l14 = alloca i1
  %l23 = alloca { i64, ptr }
  %l24 = alloca i1
  %l26 = alloca ptr
  %l30 = alloca i1
  %l31 = alloca i1
  %l34 = alloca i32
  %l39 = alloca i32
  %l42 = alloca ptr
  %l45 = alloca i32
  %l46 = alloca i32
  %l49 = alloca i1
  %l52 = alloca ptr
  %l53 = alloca i32
  %l56 = alloca i32
  %l57 = alloca i1
  %l63 = alloca ptr
  %l70 = alloca i64
  %l79 = alloca ptr
  %l80 = alloca %"compiler/source:Span"
  %l81 = alloca %"compiler/msgs:Msg"
  %l82 = alloca i64
  %l85 = alloca ptr
  %l88 = alloca ptr
  %l89 = alloca %"compiler/source:Span"
  %l90 = alloca ptr
  %l91 = alloca ptr
  %l92 = alloca ptr
  %l94 = alloca i32
  %l96 = alloca ptr
  %s2 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %t116 = alloca { i64, [2 x i64] }, align 8
  %t134 = alloca { i64, [3 x i64] }, align 8
  %t179 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a3, ptr %l3
  store i32 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t1)
  store %"compiler/source:Span" %t3, ptr %l11
  br label %bb1
bb1:
  %t4 = load %"compiler/source:Span", ptr %l11
  store %"compiler/source:Span" %t4, ptr %l5
  br i1 %a2, label %bb2, label %bb3
bb2:
  %t7 = load ptr, ptr %l1, !tbaa !29
  store ptr %t7, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t8 = load ptr, ptr %l13, !tbaa !29
  %t9 = icmp ne ptr %t8, null
  br i1 %t9, label %bb4, label %bb5
bb3:
  br label %bb45
bb4:
  %t11 = load ptr, ptr %l13, !tbaa !29
  %t12 = load i64, ptr %t11
  %t14 = icmp eq i64 %t12, 0
  store i1 %t14, ptr %l14, !tbaa !21
  br label %bb5
bb5:
  %t15 = load i1, ptr %l14, !tbaa !21
  br i1 %t15, label %bb6, label %bb7
bb6:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32 }, ptr %t18, i32 0, i32 0
  %t20 = load %"compiler/source:Span", ptr %t19
  store %"compiler/source:Span" %t20, ptr %l6
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr { i64, [5 x i64] }, ptr %t22, i32 0, i32 1
  %t25 = getelementptr { %"compiler/source:Span", i32 }, ptr %t24, i32 0, i32 1
  %t26 = load i32, ptr %t25
  store i32 %t26, ptr %l7, !tbaa !23
  br label %bb8
bb7:
  br label %bb37
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load i32, ptr %l7, !tbaa !23
  %t32 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t28, i32 %t29)
  store { i64, ptr } %t32, ptr %l23
  br label %bb9
bb9:
  %t33 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t34 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t33, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d48, i32 0, i32 1) })
  store i1 %t34, ptr %l24
  br label %bb10
bb10:
  %t35 = load i1, ptr %l24, !tbaa !21
  br i1 %t35, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb12:
  br label %bb13
bb13:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t36)
  store ptr %t38, ptr %l26
  br label %bb14
bb14:
  %t39 = load ptr, ptr %l26, !tbaa !29
  %t41 = getelementptr %"compiler/check:frame", ptr %t39, i32 0, i32 41
  %t42 = load i32, ptr %l7, !tbaa !23
  %t45 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H8da9376267bda3f76393292be0e507b2(ptr %v0, ptr %t41, i32 %t42)
  store i1 %t45, ptr %l30
  br label %bb15
bb15:
  %t46 = load i1, ptr %l30, !tbaa !21
  br i1 %t46, label %bb16, label %bb17
bb16:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load i32, ptr %l4, !tbaa !23
  %t51 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erunLength(ptr %v0, ptr %t47, i32 %t48)
  store i32 %t51, ptr %l34
  br label %bb18
bb17:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb19
bb18:
  %t52 = load i32, ptr %l4, !tbaa !23
  %t53 = load i32, ptr %l34, !tbaa !23
  %t55 = icmp ne i32 %t53, %t52
  store i1 %t55, ptr %l31, !tbaa !21
  br label %bb19
bb19:
  %t57 = load i1, ptr %l31, !tbaa !21
  br i1 %t57, label %bb20, label %bb21
bb20:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load i32, ptr %l4, !tbaa !23
  %t62 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erunLength(ptr %v0, ptr %t58, i32 %t59)
  store i32 %t62, ptr %l39
  br label %bb22
bb21:
  br label %bb23
bb22:
  %t63 = load i32, ptr %l39, !tbaa !23
  store i32 %t63, ptr %l4, !tbaa !23
  br label %bb23
bb23:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/check:Checker", ptr %t64, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !29
  %t69 = getelementptr %"compiler/generic:Program", ptr %t67, i32 0, i32 2
  store ptr %t69, ptr %l42, !tbaa !29
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = load i32, ptr %l4, !tbaa !23
  %t74 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t70, i32 %t71)
  store i32 %t74, ptr %l45
  br label %bb24
bb24:
  %t75 = load ptr, ptr %l42, !tbaa !29
  %t76 = load i32, ptr %l45, !tbaa !23
  %t77 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t75, i32 %t76)
  store i32 %t77, ptr %l46
  br label %bb25
bb25:
  %t78 = load i32, ptr %l46
  %t80 = trunc i64 19 to i32
  %t81 = icmp eq i32 %t78, %t80
  br i1 %t81, label %bb26, label %bb27
bb26:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/check:Checker", ptr %t83, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !29
  %t88 = getelementptr %"compiler/generic:Program", ptr %t86, i32 0, i32 2
  store ptr %t88, ptr %l52, !tbaa !29
  %t89 = load i32, ptr %l4, !tbaa !23
  store i32 %t89, ptr %l53, !tbaa !23
  %t90 = load ptr, ptr %l3, !tbaa !29
  %t93 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t90)
  store i32 %t93, ptr %l56
  br label %bb28
bb27:
  store i1 false, ptr %l49, !tbaa !21
  br label %bb30
bb28:
  %t94 = load ptr, ptr %l52, !tbaa !29
  %t95 = load i32, ptr %l53, !tbaa !23
  %t96 = load i32, ptr %l56, !tbaa !23
  %t97 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t94, i32 %t95, i32 %t96)
  store i1 %t97, ptr %l57
  br label %bb29
bb29:
  %t98 = load i1, ptr %l57, !tbaa !21
  %t99 = xor i1 %t98, true
  store i1 %t99, ptr %l49, !tbaa !21
  br label %bb30
bb30:
  %t101 = load i1, ptr %l49, !tbaa !21
  br i1 %t101, label %bb31, label %bb32
bb31:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t103 = load ptr, ptr %l3, !tbaa !29
  %t104 = load i32, ptr %l4, !tbaa !23
  %t105 = load %"compiler/source:Span", ptr %l6
  %t110 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %t102, ptr %t103, i32 %t104, %"compiler/source:Span" %t105)
  store ptr %t110, ptr %l63
  br label %bb33
bb32:
  br label %bb34
bb33:
  %t111 = load ptr, ptr %l63, !tbaa !29
  store ptr %t111, ptr %l3, !tbaa !29
  br label %bb34
bb34:
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t113 = load i32, ptr %l7, !tbaa !23
  %t114 = load %"compiler/source:Span", ptr %l6
  %t115 = load i32, ptr %l4, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t116
  %t117 = getelementptr { i64, [2 x i64] }, ptr %t116, i32 0, i32 0
  store i64 5, ptr %t117
  %t118 = load { i64, [2 x i64] }, ptr %t116
  %t125 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %t112, i32 %t113, %"compiler/source:Span" %t114, i32 %t115, i32 1, { i64, [2 x i64] } %t118)
  store i64 %t125, ptr %l70
  br label %bb35
bb35:
  %t126 = load i64, ptr %l70, !tbaa !24
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t128 = load %"compiler/source:Span", ptr %l6
  %t131 = trunc i64 %t126 to i32
  %t133 = load ptr, ptr %l3, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t134
  %t135 = getelementptr { i64, [3 x i64] }, ptr %t134, i32 0, i32 0
  store i64 0, ptr %t135
  %t137 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t128, 0
  %t139 = insertvalue { %"compiler/source:Span", i32, ptr } %t137, i32 %t131, 1
  %t141 = insertvalue { %"compiler/source:Span", i32, ptr } %t139, ptr %t133, 2
  %t142 = getelementptr { i64, [3 x i64] }, ptr %t134, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t141, ptr %t142
  %t143 = load { i64, [3 x i64] }, ptr %t134
  %t145 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t143, ptr %t145
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t127, ptr %t145)
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s2)
  br label %bb44
bb37:
  br i1 true, label %bb38, label %bb39
bb38:
  br label %bb40
bb39:
  br label %bb43
bb40:
  store %olang.scope zeroinitializer, ptr %s6
  %t148 = load ptr, ptr %l0, !tbaa !29
  store ptr %t148, ptr %l79, !tbaa !29
  %t149 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t149, ptr %l80
  %t150 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eDestructNotName(ptr %s6)
  store %"compiler/msgs:Msg" %t150, ptr %l81
  br label %bb41
bb41:
  %t151 = load ptr, ptr %l79, !tbaa !29
  %t152 = load %"compiler/source:Span", ptr %l80
  %t153 = load %"compiler/msgs:Msg", ptr %l81
  %t154 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s6, ptr %t151, %"compiler/source:Span" %t152, %"compiler/msgs:Msg" %t153)
  store i64 %t154, ptr %l82
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s6)
  br label %bb44
bb43:
  call void @__olang_check_failed(ptr @olang_loc_fb06dcd16342dc9_94e70e479081575d)
  unreachable
bb44:
  br label %ret
bb45:
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t156 = load ptr, ptr %l1, !tbaa !29
  %t159 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ediscardOr(ptr %v0, ptr %v1, ptr %t155, ptr %t156)
  store ptr %t159, ptr %l85
  br label %bb46
bb46:
  %t160 = load ptr, ptr %l85, !tbaa !29
  store ptr %t160, ptr %l9, !tbaa !29
  %t161 = load ptr, ptr %l9, !tbaa !29
  %t163 = icmp eq ptr %t161, null
  br i1 %t163, label %bb47, label %bb48
bb47:
  br label %ret
bb48:
  br label %bb49
bb49:
  %t165 = load ptr, ptr %l0, !tbaa !29
  store ptr %t165, ptr %l88, !tbaa !29
  %t166 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t166, ptr %l89
  %t167 = load ptr, ptr %l9, !tbaa !29
  store ptr %t167, ptr %l90, !tbaa !29
  %t168 = load ptr, ptr %l0, !tbaa !29
  store ptr %t168, ptr %l91, !tbaa !29
  %t169 = load ptr, ptr %l3, !tbaa !29
  store ptr %t169, ptr %l92, !tbaa !29
  %t170 = load ptr, ptr %l9, !tbaa !29
  %t172 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v0, ptr %t170)
  store i32 %t172, ptr %l94
  br label %bb50
bb50:
  %t173 = load %"compiler/source:Span", ptr %l5
  %t174 = load ptr, ptr %l91, !tbaa !29
  %t175 = load ptr, ptr %l92, !tbaa !29
  %t176 = load i32, ptr %l94, !tbaa !23
  %t178 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %t174, ptr %t175, i32 %t176, %"compiler/source:Span" %t173)
  store ptr %t178, ptr %l96
  br label %bb51
bb51:
  store { i64, [3 x i64] } zeroinitializer, ptr %t179
  %t180 = getelementptr { i64, [3 x i64] }, ptr %t179, i32 0, i32 0
  store i64 1, ptr %t180
  %t181 = load %"compiler/source:Span", ptr %l89
  %t182 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t181, 0
  %t183 = load ptr, ptr %l90, !tbaa !29
  %t184 = insertvalue { %"compiler/source:Span", ptr, ptr } %t182, ptr %t183, 1
  %t185 = load ptr, ptr %l96, !tbaa !29
  %t186 = insertvalue { %"compiler/source:Span", ptr, ptr } %t184, ptr %t185, 2
  %t187 = getelementptr { i64, [3 x i64] }, ptr %t179, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t186, ptr %t187
  %t188 = load { i64, [3 x i64] }, ptr %t179
  %t190 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t188, ptr %t190
  %t191 = load ptr, ptr %l88, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t191, ptr %t190)
  br label %bb52
bb52:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eraise(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca { i64, i32 }
  %l7 = alloca i64
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca ptr
  %l11 = alloca i32
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i32
  %l17 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca %"compiler/source:Span"
  %l22 = alloca %"compiler/msgs:Msg"
  %l23 = alloca i64
  %l25 = alloca ptr
  %l29 = alloca ptr
  %l33 = alloca %"compiler/source:Span"
  %l34 = alloca %"compiler/msgs:Msg"
  %l35 = alloca i64
  %l37 = alloca ptr
  %l41 = alloca ptr
  %l45 = alloca %"compiler/source:Span"
  %l46 = alloca ptr
  %l48 = alloca ptr
  %l51 = alloca { i64, ptr }
  %l52 = alloca %"compiler/msgs:Msg"
  %l53 = alloca i64
  %l58 = alloca ptr
  %l60 = alloca ptr
  %l65 = alloca %"compiler/names:Ref"
  %l71 = alloca i1
  %l74 = alloca i1
  %l81 = alloca { i64, ptr }
  %l84 = alloca ptr
  %l89 = alloca i32
  %l97 = alloca i1
  %l99 = alloca ptr
  %l101 = alloca %"compiler/source:Span"
  %l104 = alloca { i64, ptr }
  %l106 = alloca { i64, ptr }
  %l108 = alloca %"compiler/msgs:Msg"
  %l109 = alloca i64
  %l115 = alloca { i64, i32 }
  %l121 = alloca ptr
  %l123 = alloca ptr
  %l127 = alloca i1
  %l130 = alloca i32
  %l135 = alloca i64
  %l137 = alloca i32
  %l140 = alloca ptr
  %l144 = alloca i1
  %l154 = alloca { i64, ptr }
  %l161 = alloca { i64, ptr }
  %l168 = alloca i32
  %l177 = alloca ptr
  %l180 = alloca %"compiler/source:Span"
  %l183 = alloca { i64, ptr }
  %l185 = alloca %"compiler/msgs:Msg"
  %l186 = alloca i64
  %l191 = alloca i32
  %l194 = alloca ptr
  %l197 = alloca %"compiler/source:Span"
  %l200 = alloca { i64, ptr }
  %l202 = alloca %"compiler/msgs:Msg"
  %l203 = alloca i64
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %t420 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t1)
  store ptr %t3, ptr %l17
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l17, !tbaa !29
  %t6 = getelementptr %"compiler/check:frame", ptr %t4, i32 0, i32 30
  %t7 = load i1, ptr %t6, !tbaa !21
  br i1 %t7, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t9 = load ptr, ptr %l0, !tbaa !29
  store ptr %t9, ptr %l20, !tbaa !29
  %t10 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t10, ptr %l21
  %t11 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTaskClauseError(ptr %s1)
  store %"compiler/msgs:Msg" %t11, ptr %l22
  br label %bb4
bb3:
  br label %bb6
bb4:
  %t12 = load ptr, ptr %l20, !tbaa !29
  %t13 = load %"compiler/source:Span", ptr %l21
  %t14 = load %"compiler/msgs:Msg", ptr %l22
  %t15 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s1, ptr %t12, %"compiler/source:Span" %t13, %"compiler/msgs:Msg" %t14)
  store i64 %t15, ptr %l23
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s1)
  br label %ret
bb6:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t16)
  store ptr %t18, ptr %l25
  br label %bb7
bb7:
  %t19 = load ptr, ptr %l25, !tbaa !29
  %t21 = getelementptr %"compiler/check:frame", ptr %t19, i32 0, i32 32
  %t22 = load i64, ptr %t21, !tbaa !24
  %t24 = icmp sge i64 %t22, 0
  br i1 %t24, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t26 = load ptr, ptr %l0, !tbaa !29
  store ptr %t26, ptr %l29, !tbaa !29
  %t27 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t28 = load i32, ptr %t27, !tbaa !23
  %t29 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t30 = load i32, ptr %t29, !tbaa !23
  %t32 = add i32 %t30, 5
  %t35 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s2, i32 %t28, i32 %t32)
  store %"compiler/source:Span" %t35, ptr %l33
  br label %bb10
bb9:
  br label %bb13
bb10:
  %t36 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eDeferErrorEscapes(ptr %s2)
  store %"compiler/msgs:Msg" %t36, ptr %l34
  br label %bb11
bb11:
  %t37 = load ptr, ptr %l29, !tbaa !29
  %t38 = load %"compiler/source:Span", ptr %l33
  %t39 = load %"compiler/msgs:Msg", ptr %l34
  %t40 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s2, ptr %t37, %"compiler/source:Span" %t38, %"compiler/msgs:Msg" %t39)
  store i64 %t40, ptr %l35
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb13:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t41)
  store ptr %t43, ptr %l37
  br label %bb14
bb14:
  %t44 = load ptr, ptr %l37, !tbaa !29
  %t46 = getelementptr %"compiler/check:frame", ptr %t44, i32 0, i32 33
  %t47 = load i64, ptr %t46, !tbaa !24
  %t49 = icmp sge i64 %t47, 0
  br i1 %t49, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s3
  %t51 = load ptr, ptr %l0, !tbaa !29
  store ptr %t51, ptr %l41, !tbaa !29
  %t52 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t53 = load i32, ptr %t52, !tbaa !23
  %t54 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t55 = load i32, ptr %t54, !tbaa !23
  %t57 = add i32 %t55, 5
  %t60 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s3, i32 %t53, i32 %t57)
  store %"compiler/source:Span" %t60, ptr %l45
  br label %bb17
bb16:
  br label %bb22
bb17:
  %t61 = load ptr, ptr %l0, !tbaa !29
  store ptr %t61, ptr %l46, !tbaa !29
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t62)
  store ptr %t64, ptr %l48
  br label %bb18
bb18:
  %t65 = load ptr, ptr %l48, !tbaa !29
  %t67 = getelementptr %"compiler/check:frame", ptr %t65, i32 0, i32 34
  %t68 = load i1, ptr %t67, !tbaa !21
  %t69 = load ptr, ptr %l46, !tbaa !29
  %t71 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emsgOwner(ptr %v0, ptr %s3, ptr %t69, i1 %t68)
  store { i64, ptr } %t71, ptr %l51
  br label %bb19
bb19:
  %t72 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t73 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eAssertMsgError(ptr %s3, ptr %s3, { i64, ptr } %t72)
  store %"compiler/msgs:Msg" %t73, ptr %l52
  br label %bb20
bb20:
  %t74 = load ptr, ptr %l41, !tbaa !29
  %t75 = load %"compiler/source:Span", ptr %l45
  %t76 = load %"compiler/msgs:Msg", ptr %l52
  %t77 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s3, ptr %t74, %"compiler/source:Span" %t75, %"compiler/msgs:Msg" %t76)
  store i64 %t77, ptr %l53
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s3)
  br label %ret
bb22:
  %t78 = load ptr, ptr %l2, !tbaa !29
  %t80 = icmp eq ptr %t78, null
  br i1 %t80, label %bb23, label %bb24
bb23:
  br label %ret
bb24:
  br label %bb25
bb25:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/check:Checker", ptr %t82, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !29
  %t87 = getelementptr %"compiler/generic:Program", ptr %t85, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !29
  store ptr %t88, ptr %l58, !tbaa !29
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t89)
  store ptr %t91, ptr %l60
  br label %bb26
bb26:
  %t92 = load ptr, ptr %l60, !tbaa !29
  %t94 = getelementptr %"compiler/check:frame", ptr %t92, i32 0, i32 2
  %t95 = load i64, ptr %t94, !tbaa !24
  %t96 = load ptr, ptr %l2, !tbaa !29
  %t98 = getelementptr %"compiler/ast:Path", ptr %t96, i32 0, i32 0
  %t99 = getelementptr %"compiler/source:Span", ptr %t98, i32 0, i32 0
  %t100 = load i32, ptr %t99, !tbaa !23
  %t101 = load ptr, ptr %l58, !tbaa !29
  %t104 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t101, i64 %t95, i32 %t100)
  store %"compiler/names:Ref" %t104, ptr %l65
  br label %bb27
bb27:
  %t105 = getelementptr %"compiler/names:Ref", ptr %l65, i32 0, i32 0
  %t106 = load i32, ptr %t105
  store i32 %t106, ptr %l3
  %t108 = load ptr, ptr %l2, !tbaa !29
  %t110 = getelementptr %"compiler/ast:Path", ptr %t108, i32 0, i32 1
  %t111 = load { i64, ptr }, ptr %t110, !tbaa !27
  %t113 = extractvalue { i64, ptr } %t111, 0
  %t115 = icmp eq i64 %t113, 1
  br i1 %t115, label %bb28, label %bb29
bb28:
  %t117 = load i32, ptr %l3
  %t119 = trunc i64 1 to i32
  %t120 = icmp eq i32 %t117, %t119
  br i1 %t120, label %bb30, label %bb31
bb29:
  store i1 false, ptr %l71, !tbaa !21
  br label %bb33
bb30:
  store i1 true, ptr %l74, !tbaa !21
  br label %bb32
bb31:
  %t122 = load i32, ptr %l3
  %t124 = trunc i64 2 to i32
  %t125 = icmp eq i32 %t122, %t124
  store i1 %t125, ptr %l74, !tbaa !21
  br label %bb32
bb32:
  %t127 = load i1, ptr %l74, !tbaa !21
  store i1 %t127, ptr %l71, !tbaa !21
  br label %bb33
bb33:
  %t128 = load i1, ptr %l71, !tbaa !21
  br i1 %t128, label %bb34, label %bb35
bb34:
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t130 = load ptr, ptr %l2, !tbaa !29
  %t132 = getelementptr %"compiler/ast:Path", ptr %t130, i32 0, i32 0
  %t133 = load %"compiler/source:Span", ptr %t132
  %t134 = load ptr, ptr %l2, !tbaa !29
  %t136 = getelementptr %"compiler/ast:Path", ptr %t134, i32 0, i32 1
  %t137 = load { i64, ptr }, ptr %t136, !tbaa !27
  store { i64, ptr } %t137, ptr %l81, !tbaa !27
  %t138 = getelementptr { i64, ptr }, ptr %l81, i32 0, i32 1
  %t139 = load ptr, ptr %t138, !tbaa !27
  %t140 = getelementptr i32, ptr %t139, i64 0
  %t141 = load i32, ptr %t140, !tbaa !33
  %t142 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t147 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ename(ptr %v0, ptr %t129, %"compiler/source:Span" %t133, i32 %t141, i32 %t142, i1 false)
  store ptr %t147, ptr %l84
  br label %bb36
bb35:
  br label %bb52
bb36:
  %t148 = load ptr, ptr %l84, !tbaa !29
  store ptr %t148, ptr %l4, !tbaa !29
  %t149 = load ptr, ptr %l4, !tbaa !29
  %t151 = icmp eq ptr %t149, null
  br i1 %t151, label %bb37, label %bb38
bb37:
  br label %ret
bb38:
  br label %bb39
bb39:
  %t153 = load ptr, ptr %l4, !tbaa !29
  %t156 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t153)
  store i32 %t156, ptr %l89
  br label %bb40
bb40:
  %t157 = load i32, ptr %l89, !tbaa !23
  store i32 %t157, ptr %l5, !tbaa !23
  %t158 = load i32, ptr %l5, !tbaa !23
  %t159 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t162 = icmp eq i32 %t158, %t159
  br i1 %t162, label %bb41, label %bb42
bb41:
  br label %ret
bb42:
  br label %bb43
bb43:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t166 = getelementptr %"compiler/check:Checker", ptr %t164, i32 0, i32 1
  %t167 = load ptr, ptr %t166, !tbaa !29
  %t169 = getelementptr %"compiler/generic:Program", ptr %t167, i32 0, i32 2
  %t170 = load i32, ptr %l5, !tbaa !23
  %t173 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsErrVal(ptr %v0, ptr %t169, i32 %t170)
  store i1 %t173, ptr %l97
  br label %bb44
bb44:
  %t174 = load i1, ptr %l97, !tbaa !21
  %t175 = xor i1 %t174, true
  br i1 %t175, label %bb45, label %bb46
bb45:
  store %olang.scope zeroinitializer, ptr %s8
  %t177 = load ptr, ptr %l0, !tbaa !29
  store ptr %t177, ptr %l99, !tbaa !29
  %t178 = load ptr, ptr %l2, !tbaa !29
  %t180 = getelementptr %"compiler/ast:Path", ptr %t178, i32 0, i32 0
  %t181 = load %"compiler/source:Span", ptr %t180
  store %"compiler/source:Span" %t181, ptr %l101
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t183 = load ptr, ptr %l2, !tbaa !29
  %t185 = getelementptr %"compiler/ast:Path", ptr %t183, i32 0, i32 1
  %t186 = load { i64, ptr }, ptr %t185, !tbaa !27
  store { i64, ptr } %t186, ptr %l104, !tbaa !27
  %t187 = getelementptr { i64, ptr }, ptr %l104, i32 0, i32 1
  %t188 = load ptr, ptr %t187, !tbaa !27
  %t189 = getelementptr i32, ptr %t188, i64 0
  %t190 = load i32, ptr %t189, !tbaa !33
  %t193 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s8, ptr %t182, i32 %t190)
  store { i64, ptr } %t193, ptr %l106
  br label %bb47
bb46:
  br label %bb50
bb47:
  %t194 = load { i64, ptr }, ptr %l106, !tbaa !27
  %t195 = extractvalue { i64, ptr } %t194, 0
  %t196 = extractvalue { i64, ptr } %t194, 1
  %t197 = mul i64 %t195, 1
  %t198 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t197)
  call void @llvm.memcpy.p0.p0.i64(ptr %t198, ptr %t196, i64 %t197, i1 false)
  %t199 = insertvalue { i64, ptr } undef, i64 %t195, 0
  %t200 = insertvalue { i64, ptr } %t199, ptr %t198, 1
  %t202 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eRaiseNotCaught(ptr %s8, ptr %s8, { i64, ptr } %t200)
  store %"compiler/msgs:Msg" %t202, ptr %l108
  br label %bb48
bb48:
  %t203 = load ptr, ptr %l99, !tbaa !29
  %t204 = load %"compiler/source:Span", ptr %l101
  %t205 = load %"compiler/msgs:Msg", ptr %l108
  %t206 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s8, ptr %t203, %"compiler/source:Span" %t204, %"compiler/msgs:Msg" %t205)
  store i64 %t206, ptr %l109
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s8)
  br label %ret
bb50:
  %t207 = load ptr, ptr %l0, !tbaa !29
  %t208 = load %"compiler/source:Span", ptr %l1
  %t209 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereraise(ptr %v0, ptr %t207, %"compiler/source:Span" %t208, ptr %t209)
  br label %bb51
bb51:
  br label %ret
bb52:
  %t213 = load ptr, ptr %l0, !tbaa !29
  %t214 = load ptr, ptr %l2, !tbaa !29
  %t217 = call { i64, i32 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrorWord(ptr %v0, ptr %v1, ptr %t213, ptr %t214)
  store { i64, i32 } %t217, ptr %l115
  br label %bb53
bb53:
  %t218 = load { i64, i32 }, ptr %l115
  store { i64, i32 } %t218, ptr %l6
  %t219 = getelementptr { i64, i32 }, ptr %l6, i32 0, i32 0
  %t220 = load i64, ptr %t219, !tbaa !24
  store i64 %t220, ptr %l7, !tbaa !24
  %t222 = getelementptr { i64, i32 }, ptr %l6, i32 0, i32 1
  %t223 = load i32, ptr %t222, !tbaa !23
  store i32 %t223, ptr %l8, !tbaa !23
  %t225 = load i64, ptr %l7, !tbaa !24
  %t227 = icmp slt i64 %t225, 0
  br i1 %t227, label %bb54, label %bb55
bb54:
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t231 = getelementptr %"compiler/check:Checker", ptr %t229, i32 0, i32 1
  %t232 = load ptr, ptr %t231, !tbaa !29
  store ptr %t232, ptr %l121, !tbaa !29
  %t233 = load ptr, ptr %l0, !tbaa !29
  %t235 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t233)
  store ptr %t235, ptr %l123
  br label %bb56
bb55:
  br label %bb58
bb56:
  %t236 = load ptr, ptr %l123, !tbaa !29
  %t238 = getelementptr %"compiler/check:frame", ptr %t236, i32 0, i32 4
  %t239 = load ptr, ptr %l2, !tbaa !29
  %t240 = load ptr, ptr %l121, !tbaa !29
  %t243 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorItemKnown(ptr %v0, ptr %v0, ptr %v1, ptr %t240, ptr %t238, ptr %t239)
  store i1 %t243, ptr %l127
  br label %bb57
bb57:
  br label %ret
bb58:
  %t244 = load i64, ptr %l7, !tbaa !24
  %t246 = icmp slt i64 %t244, 64
  br i1 %t246, label %bb59, label %bb60
bb59:
  %t248 = load ptr, ptr %l0, !tbaa !29
  %t250 = getelementptr %"compiler/check:Checker", ptr %t248, i32 0, i32 1
  %t251 = load ptr, ptr %t250, !tbaa !29
  %t253 = getelementptr %"compiler/generic:Program", ptr %t251, i32 0, i32 2
  %t254 = load i32, ptr %l8, !tbaa !23
  %t255 = load i64, ptr %l7, !tbaa !24
  store i64 %t255, ptr %l135, !tbaa !24
  %t256 = load i64, ptr %l135, !tbaa !24
  %t257 = load i64, ptr %l135, !tbaa !24
  %t258 = shl i64 1, %t257
  %t262 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrWords(ptr %v0, ptr %t253, i32 %t254, i64 %t258)
  store i32 %t262, ptr %l137
  br label %bb61
bb60:
  %t263 = load i32, ptr %l8, !tbaa !23
  store i32 %t263, ptr %l130, !tbaa !23
  br label %bb62
bb61:
  %t265 = load i32, ptr %l137, !tbaa !23
  store i32 %t265, ptr %l130, !tbaa !23
  br label %bb62
bb62:
  %t266 = load i32, ptr %l130, !tbaa !23
  store i32 %t266, ptr %l9, !tbaa !23
  %t267 = load ptr, ptr %l0, !tbaa !29
  %t269 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t267)
  store ptr %t269, ptr %l140
  br label %bb63
bb63:
  %t270 = load ptr, ptr %l140, !tbaa !29
  store ptr %t270, ptr %l10, !tbaa !29
  %t271 = load ptr, ptr %l10, !tbaa !29
  %t273 = getelementptr %"compiler/check:frame", ptr %t271, i32 0, i32 24
  %t274 = load i1, ptr %t273, !tbaa !21
  %t276 = xor i1 %t274, true
  br i1 %t276, label %bb64, label %bb65
bb64:
  %t278 = load ptr, ptr %l10, !tbaa !29
  %t280 = getelementptr %"compiler/check:frame", ptr %t278, i32 0, i32 12
  %t281 = load i1, ptr %t280, !tbaa !21
  %t283 = xor i1 %t281, true
  store i1 %t283, ptr %l144, !tbaa !21
  br label %bb66
bb65:
  store i1 false, ptr %l144, !tbaa !21
  br label %bb66
bb66:
  %t285 = load i1, ptr %l144, !tbaa !21
  br i1 %t285, label %bb67, label %bb68
bb67:
  %t286 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t286, ptr %l11, !tbaa !23
  %t288 = load ptr, ptr %l0, !tbaa !29
  %t290 = getelementptr %"compiler/check:Checker", ptr %t288, i32 0, i32 1
  %t291 = load ptr, ptr %t290, !tbaa !29
  %t293 = getelementptr %"compiler/generic:Program", ptr %t291, i32 0, i32 2
  %t294 = load ptr, ptr %l10, !tbaa !29
  %t296 = getelementptr %"compiler/check:frame", ptr %t294, i32 0, i32 6
  %t297 = load i32, ptr %t296, !tbaa !23
  %t300 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t293, i32 %t297)
  store { i64, ptr } %t300, ptr %l154
  br label %bb69
bb68:
  br label %bb95
bb69:
  %t301 = load { i64, ptr }, ptr %l154, !tbaa !27
  store { i64, ptr } %t301, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t302 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t304 = extractvalue { i64, ptr } %t302, 0
  store i64 %t304, ptr %l14, !tbaa !24
  br label %bb70
bb70:
  %t306 = load i64, ptr %l13, !tbaa !24
  %t307 = load i64, ptr %l14, !tbaa !24
  %t310 = icmp slt i64 %t306, %t307
  %t312 = xor i1 %t310, true
  br i1 %t312, label %bb71, label %bb72
bb71:
  br label %bb79
bb72:
  br label %bb73
bb73:
  %t314 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t314, ptr %l161, !tbaa !27
  %t315 = load i64, ptr %l13, !tbaa !24
  %t317 = getelementptr { i64, ptr }, ptr %l161, i32 0, i32 1
  %t318 = load ptr, ptr %t317, !tbaa !27
  %t319 = getelementptr i32, ptr %t318, i64 %t315
  %t320 = load i32, ptr %t319, !tbaa !33
  store i32 %t320, ptr %l15, !tbaa !23
  %t322 = load ptr, ptr %l0, !tbaa !29
  %t324 = getelementptr %"compiler/check:Checker", ptr %t322, i32 0, i32 1
  %t325 = load ptr, ptr %t324, !tbaa !29
  %t327 = getelementptr %"compiler/generic:Program", ptr %t325, i32 0, i32 2
  %t328 = load i32, ptr %l15, !tbaa !23
  %t331 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t327, i32 %t328)
  store i32 %t331, ptr %l168
  br label %bb74
bb74:
  %t332 = load i32, ptr %l8, !tbaa !23
  %t333 = load i32, ptr %l168, !tbaa !23
  %t335 = icmp eq i32 %t333, %t332
  br i1 %t335, label %bb75, label %bb76
bb75:
  %t337 = load i32, ptr %l15, !tbaa !23
  store i32 %t337, ptr %l11, !tbaa !23
  br label %bb77
bb76:
  br label %bb77
bb77:
  br label %bb78
bb78:
  %t339 = load i64, ptr %l13, !tbaa !24
  %t341 = add i64 %t339, 1
  store i64 %t341, ptr %l13, !tbaa !24
  br label %bb70
bb79:
  %t343 = load i32, ptr %l11, !tbaa !23
  %t344 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t347 = icmp eq i32 %t343, %t344
  br i1 %t347, label %bb80, label %bb81
bb80:
  store %olang.scope zeroinitializer, ptr %s15
  %t349 = load ptr, ptr %l0, !tbaa !29
  store ptr %t349, ptr %l177, !tbaa !29
  %t350 = load ptr, ptr %l0, !tbaa !29
  %t351 = load ptr, ptr %l2, !tbaa !29
  %t354 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epathPart(ptr %v0, ptr %v1, ptr %t350, ptr %t351, i64 1)
  store %"compiler/source:Span" %t354, ptr %l180
  br label %bb82
bb81:
  %t355 = load ptr, ptr %l0, !tbaa !29
  %t356 = load ptr, ptr %l10, !tbaa !29
  %t358 = getelementptr %"compiler/check:frame", ptr %t356, i32 0, i32 6
  %t359 = load i32, ptr %t358, !tbaa !23
  %t360 = load i32, ptr %l9, !tbaa !23
  %t364 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euncovered(ptr %v0, ptr %t355, i32 %t359, i32 %t360)
  store i32 %t364, ptr %l191
  br label %bb86
bb82:
  %t365 = load ptr, ptr %l0, !tbaa !29
  %t366 = load i32, ptr %l8, !tbaa !23
  %t369 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s15, ptr %t365, i32 %t366)
  store { i64, ptr } %t369, ptr %l183
  br label %bb83
bb83:
  %t370 = load { i64, ptr }, ptr %l183, !tbaa !27
  %t371 = extractvalue { i64, ptr } %t370, 0
  %t372 = extractvalue { i64, ptr } %t370, 1
  %t373 = mul i64 %t371, 1
  %t374 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t373)
  call void @llvm.memcpy.p0.p0.i64(ptr %t374, ptr %t372, i64 %t373, i1 false)
  %t375 = insertvalue { i64, ptr } undef, i64 %t371, 0
  %t376 = insertvalue { i64, ptr } %t375, ptr %t374, 1
  %t378 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eErrorUndeclared(ptr %s15, ptr %s15, { i64, ptr } %t376)
  store %"compiler/msgs:Msg" %t378, ptr %l185
  br label %bb84
bb84:
  %t379 = load ptr, ptr %l177, !tbaa !29
  %t380 = load %"compiler/source:Span", ptr %l180
  %t381 = load %"compiler/msgs:Msg", ptr %l185
  %t382 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s15, ptr %t379, %"compiler/source:Span" %t380, %"compiler/msgs:Msg" %t381)
  store i64 %t382, ptr %l186
  br label %bb85
bb85:
  call void @__olang_scope_close(ptr %s15)
  br label %bb94
bb86:
  %t383 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t384 = load i32, ptr %l191, !tbaa !23
  %t386 = icmp ne i32 %t384, %t383
  br i1 %t386, label %bb87, label %bb88
bb87:
  store %olang.scope zeroinitializer, ptr %s17
  %t388 = load ptr, ptr %l0, !tbaa !29
  store ptr %t388, ptr %l194, !tbaa !29
  %t389 = load ptr, ptr %l0, !tbaa !29
  %t390 = load ptr, ptr %l2, !tbaa !29
  %t393 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epathPart(ptr %v0, ptr %v1, ptr %t389, ptr %t390, i64 0)
  store %"compiler/source:Span" %t393, ptr %l197
  br label %bb89
bb88:
  br label %bb93
bb89:
  %t394 = load ptr, ptr %l0, !tbaa !29
  %t395 = load i32, ptr %l11, !tbaa !23
  %t398 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s17, ptr %t394, i32 %t395)
  store { i64, ptr } %t398, ptr %l200
  br label %bb90
bb90:
  %t399 = load { i64, ptr }, ptr %l200, !tbaa !27
  %t400 = extractvalue { i64, ptr } %t399, 0
  %t401 = extractvalue { i64, ptr } %t399, 1
  %t402 = mul i64 %t400, 1
  %t403 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t402)
  call void @llvm.memcpy.p0.p0.i64(ptr %t403, ptr %t401, i64 %t402, i1 false)
  %t404 = insertvalue { i64, ptr } undef, i64 %t400, 0
  %t405 = insertvalue { i64, ptr } %t404, ptr %t403, 1
  %t407 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eErrorWordNotInSet(ptr %s17, ptr %s17, { i64, ptr } %t405)
  store %"compiler/msgs:Msg" %t407, ptr %l202
  br label %bb91
bb91:
  %t408 = load ptr, ptr %l194, !tbaa !29
  %t409 = load %"compiler/source:Span", ptr %l197
  %t410 = load %"compiler/msgs:Msg", ptr %l202
  %t411 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s17, ptr %t408, %"compiler/source:Span" %t409, %"compiler/msgs:Msg" %t410)
  store i64 %t411, ptr %l203
  br label %bb92
bb92:
  call void @__olang_scope_close(ptr %s17)
  br label %bb93
bb93:
  br label %bb94
bb94:
  br label %bb95
bb95:
  %t412 = load ptr, ptr %l0, !tbaa !29
  %t413 = load i32, ptr %l9, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleaks1(ptr %v0, ptr %t412, i32 %t413)
  br label %bb96
bb96:
  %t416 = load ptr, ptr %l0, !tbaa !29
  %t417 = load %"compiler/source:Span", ptr %l1
  %t418 = load i32, ptr %l8, !tbaa !23
  %t419 = load i64, ptr %l7, !tbaa !24
  store { i64, [3 x i64] } zeroinitializer, ptr %t420
  %t421 = getelementptr { i64, [3 x i64] }, ptr %t420, i32 0, i32 0
  store i64 7, ptr %t421
  %t423 = insertvalue { %"compiler/source:Span", i32, i64 } undef, %"compiler/source:Span" %t417, 0
  %t425 = insertvalue { %"compiler/source:Span", i32, i64 } %t423, i32 %t418, 1
  %t427 = insertvalue { %"compiler/source:Span", i32, i64 } %t425, i64 %t419, 2
  %t428 = getelementptr { i64, [3 x i64] }, ptr %t420, i32 0, i32 1
  store { %"compiler/source:Span", i32, i64 } %t427, ptr %t428
  %t429 = load { i64, [3 x i64] }, ptr %t420
  %t431 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t429, ptr %t431
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t416, ptr %t431)
  br label %bb97
bb97:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflDefault(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, %"compiler/generic:Desc" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/generic:Desc"
  %l4 = alloca { i32, { i64, ptr } }
  %l5 = alloca i32
  %l6 = alloca %"compiler/generic:Desc"
  %l8 = alloca i32
  %l12 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca %"compiler/source:Span"
  %l19 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l25 = alloca %"compiler/msgs:Msg"
  %l26 = alloca i64
  %l29 = alloca ptr
  %l33 = alloca { i32, { i64, ptr } }
  %l38 = alloca %"compiler/generic:Desc"
  %l45 = alloca ptr
  %l50 = alloca ptr
  %l51 = alloca %"compiler/source:Span"
  %l52 = alloca i64
  %l53 = alloca i64
  %l55 = alloca i64
  %l58 = alloca ptr
  %l67 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store %"compiler/generic:Desc" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load %"compiler/generic:Desc", ptr %l2
  %t5 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparamDefault(ptr %v0, ptr %t1, %"compiler/generic:Desc" %t2)
  store ptr %t5, ptr %l12
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l12, !tbaa !29
  %t9 = icmp eq ptr %t6, null
  br i1 %t9, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t11 = load ptr, ptr %l0, !tbaa !29
  store ptr %t11, ptr %l15, !tbaa !29
  %t12 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t12, ptr %l16
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load %"compiler/generic:Desc", ptr %l2
  %t17 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edescName(ptr %v0, ptr %s1, ptr %t13, %"compiler/generic:Desc" %t14)
  store { i64, ptr } %t17, ptr %l19
  br label %bb4
bb3:
  br label %bb9
bb4:
  %t18 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t18, 0
  %t20 = extractvalue { i64, ptr } %t18, 1
  %t21 = mul i64 %t19, 1
  %t22 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t21)
  call void @llvm.memcpy.p0.p0.i64(ptr %t22, ptr %t20, i64 %t21, i1 false)
  %t23 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t22, 1
  store { i64, ptr } %t24, ptr %l20, !tbaa !27
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/generic:Desc", ptr %l2, i32 0, i32 1
  %t27 = load i32, ptr %t26, !tbaa !23
  %t30 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s1, ptr %t25, i32 %t27)
  store { i64, ptr } %t30, ptr %l23
  br label %bb5
bb5:
  %t31 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  %t33 = extractvalue { i64, ptr } %t31, 1
  %t34 = mul i64 %t32, 1
  %t35 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t34)
  call void @llvm.memcpy.p0.p0.i64(ptr %t35, ptr %t33, i64 %t34, i1 false)
  %t36 = insertvalue { i64, ptr } undef, i64 %t32, 0
  %t37 = insertvalue { i64, ptr } %t36, ptr %t35, 1
  %t38 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t40 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eReflNoDefault(ptr %s1, ptr %s1, ptr %s1, { i64, ptr } %t38, { i64, ptr } %t37)
  store %"compiler/msgs:Msg" %t40, ptr %l25
  br label %bb6
bb6:
  %t41 = load ptr, ptr %l15, !tbaa !29
  %t42 = load %"compiler/source:Span", ptr %l16
  %t43 = load %"compiler/msgs:Msg", ptr %l25
  %t44 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s1, ptr %t41, %"compiler/source:Span" %t42, %"compiler/msgs:Msg" %t43)
  store i64 %t44, ptr %l26
  br label %bb7
bb7:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t46 = load %"compiler/source:Span", ptr %l1
  %t49 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t45, %"compiler/source:Span" %t46)
  store ptr %t49, ptr %l29
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t50 = load ptr, ptr %l29, !tbaa !29
  store ptr %t50, ptr %rv
  br label %ret
bb9:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/check:Checker", ptr %t51, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !29
  %t55 = load %"compiler/generic:Desc", ptr %l2
  %t58 = call { i32, { i64, ptr } } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDescType(ptr %v0, ptr %s0, ptr %t54, %"compiler/generic:Desc" %t55)
  store { i32, { i64, ptr } } %t58, ptr %l33
  br label %bb10
bb10:
  %t59 = load { i32, { i64, ptr } }, ptr %l33
  store { i32, { i64, ptr } } %t59, ptr %l4
  %t60 = getelementptr { i32, { i64, ptr } }, ptr %l4, i32 0, i32 0
  %t61 = load i32, ptr %t60, !tbaa !23
  store i32 %t61, ptr %l5, !tbaa !23
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/check:Checker", ptr %t63, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t67 = getelementptr %"compiler/generic:Desc", ptr %l2, i32 0, i32 1
  %t68 = load i32, ptr %t67, !tbaa !23
  %t71 = call %"compiler/generic:Desc" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDescOf(ptr %v0, ptr %t66, i32 %t68)
  store %"compiler/generic:Desc" %t71, ptr %l38
  br label %bb11
bb11:
  %t72 = load %"compiler/generic:Desc", ptr %l38
  store %"compiler/generic:Desc" %t72, ptr %l6
  %t73 = getelementptr %"compiler/generic:Desc", ptr %l6, i32 0, i32 0
  %t74 = load i64, ptr %t73, !tbaa !24
  %t75 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescFunc, !tbaa !24
  %t78 = icmp eq i64 %t74, %t75
  br i1 %t78, label %bb12, label %bb13
bb12:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/check:Checker", ptr %t80, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !29
  %t84 = getelementptr %"compiler/generic:Desc", ptr %l6, i32 0, i32 2
  %t85 = load i64, ptr %t84, !tbaa !24
  %t88 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t83, i64 %t85)
  store ptr %t88, ptr %l45
  br label %bb14
bb13:
  br label %bb19
bb14:
  %t89 = load ptr, ptr %l45, !tbaa !29
  %t91 = getelementptr %"compiler/ast:Func", ptr %t89, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !29
  %t94 = icmp eq ptr %t92, null
  %t96 = xor i1 %t94, true
  %t98 = load ptr, ptr %l0, !tbaa !29
  store ptr %t98, ptr %l50, !tbaa !29
  %t99 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t99, ptr %l51
  %t100 = getelementptr %"compiler/generic:Desc", ptr %l6, i32 0, i32 2
  %t101 = load i64, ptr %t100, !tbaa !24
  store i64 %t101, ptr %l52, !tbaa !24
  %t102 = getelementptr %"compiler/generic:Desc", ptr %l2, i32 0, i32 3
  %t103 = load i64, ptr %t102, !tbaa !24
  store i64 %t103, ptr %l53, !tbaa !24
  br i1 %t96, label %bb15, label %bb16
bb15:
  store i64 1, ptr %l55, !tbaa !24
  br label %bb17
bb16:
  store i64 0, ptr %l55, !tbaa !24
  br label %bb17
bb17:
  %t106 = load i64, ptr %l53, !tbaa !24
  %t107 = load i64, ptr %l55, !tbaa !24
  %t108 = add i64 %t106, %t107
  %t109 = load i32, ptr %l5, !tbaa !23
  %t110 = load ptr, ptr %l50, !tbaa !29
  %t111 = load %"compiler/source:Span", ptr %l51
  %t112 = load i64, ptr %l52, !tbaa !24
  %t115 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edefaultArg(ptr %v0, ptr %t110, %"compiler/source:Span" %t111, i64 %t112, i64 %t108, i1 false, i32 %t109, i32 0)
  store ptr %t115, ptr %l58
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s0)
  %t116 = load ptr, ptr %l58, !tbaa !29
  store ptr %t116, ptr %rv
  br label %ret
bb19:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"compiler/check:Checker", ptr %t117, i32 0, i32 23
  %t120 = load i32, ptr %t119, !tbaa !23
  store i32 %t120, ptr %l8, !tbaa !23
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"compiler/generic:Desc", ptr %l2, i32 0, i32 1
  %t124 = load i32, ptr %t123, !tbaa !23
  %t127 = getelementptr %"compiler/check:Checker", ptr %t122, i32 0, i32 23
  store i32 %t124, ptr %t127, !tbaa !23
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t129 = load %"compiler/source:Span", ptr %l1
  %t130 = getelementptr %"compiler/generic:Desc", ptr %l2, i32 0, i32 3
  %t131 = load i64, ptr %t130, !tbaa !24
  %t132 = load i32, ptr %l5, !tbaa !23
  %t137 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorDefault(ptr %v0, ptr %t128, %"compiler/source:Span" %t129, i64 %t131, i32 %t132)
  store ptr %t137, ptr %l67
  br label %bb20
bb20:
  %t138 = load ptr, ptr %l67, !tbaa !29
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t140 = load i32, ptr %l8, !tbaa !23
  %t143 = getelementptr %"compiler/check:Checker", ptr %t139, i32 0, i32 23
  store i32 %t140, ptr %t143, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store ptr %t138, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local %"compiler/check:reflVal" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflInt(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %lp2 = alloca ptr
  %l5 = alloca %"compiler/check:reflVal"
  %l7 = alloca i1
  %l12 = alloca %"compiler/check:reflVal"
  %rv = alloca %"compiler/check:reflVal"
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call %"compiler/check:reflVal" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflFold(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
  store %"compiler/check:reflVal" %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store ptr %t6, ptr %lp2
  %t7 = load %"compiler/check:reflVal", ptr %l5
  %t8 = load ptr, ptr %lp2
  store %"compiler/check:reflVal" %t7, ptr %t8
  %t9 = load ptr, ptr %lp2
  %t10 = getelementptr %"compiler/check:reflVal", ptr %t9, i32 0, i32 0
  %t11 = load i1, ptr %t10, !tbaa !21
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load ptr, ptr %lp2
  %t14 = getelementptr %"compiler/check:reflVal", ptr %t13, i32 0, i32 1
  %t15 = load i64, ptr %t14, !tbaa !24
  %t16 = load i64, ptr @G_2ecompiler_2fcheck_2eRvInt, !tbaa !24
  %t19 = icmp eq i64 %t15, %t16
  store i1 %t19, ptr %l7, !tbaa !21
  br label %bb4
bb3:
  store i1 false, ptr %l7, !tbaa !21
  br label %bb4
bb4:
  %t21 = load i1, ptr %l7, !tbaa !21
  br i1 %t21, label %bb5, label %bb6
bb5:
  %t22 = load ptr, ptr %lp2
  %t23 = load %"compiler/check:reflVal", ptr %t22
  store %"compiler/check:reflVal" %t23, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t25 = call %"compiler/check:reflVal" @compiler_2fcheck_2enoRefl(ptr %v2)
  store %"compiler/check:reflVal" %t25, ptr %l12
  br label %bb8
bb8:
  %t26 = load %"compiler/check:reflVal", ptr %l12
  store %"compiler/check:reflVal" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:reflVal", ptr %rv
  ret %"compiler/check:reflVal" %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflOf(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, { i64, ptr } %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/generic:Desc"
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca { i32, { i64, ptr } }
  %l16 = alloca i32
  %l17 = alloca i64
  %l18 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca i64
  %l21 = alloca %"compiler/check:narrowed"
  %l22 = alloca { i64, ptr }
  %lp24 = alloca ptr
  %l28 = alloca %"compiler/generic:Desc"
  %l32 = alloca ptr
  %l33 = alloca %"compiler/source:Span"
  %l37 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l42 = alloca %"compiler/msgs:Msg"
  %l43 = alloca i64
  %l50 = alloca ptr
  %l51 = alloca %"compiler/source:Span"
  %l54 = alloca %"compiler/msgs:Msg"
  %l55 = alloca i64
  %l60 = alloca { i64, ptr }
  %l62 = alloca ptr
  %l68 = alloca i32
  %l72 = alloca i64
  %l75 = alloca i64
  %l95 = alloca i1
  %l99 = alloca %"compiler/source:Span"
  %l104 = alloca i32
  %l108 = alloca ptr
  %l115 = alloca i32
  %l127 = alloca i1
  %l129 = alloca ptr
  %l130 = alloca { i64, ptr }
  %l132 = alloca %"compiler/source:Span"
  %l135 = alloca { i64, ptr }
  %l136 = alloca { i64, ptr }
  %l139 = alloca { i64, ptr }
  %l141 = alloca %"compiler/msgs:Msg"
  %l142 = alloca i64
  %l147 = alloca { i32, { i64, ptr } }
  %l151 = alloca i1
  %l159 = alloca { i64, ptr }
  %l161 = alloca i64
  %l163 = alloca ptr
  %l166 = alloca i64
  %l168 = alloca i64
  %l173 = alloca %"compiler/check:narrowed"
  %l177 = alloca i1
  %l181 = alloca i1
  %l192 = alloca { i64, ptr }
  %l193 = alloca ptr
  %l194 = alloca { i64, ptr }
  %l196 = alloca %"compiler/source:Span"
  %l199 = alloca { i64, ptr }
  %l200 = alloca { i64, ptr }
  %l202 = alloca { i64, ptr }
  %l205 = alloca { i64, ptr }
  %l208 = alloca { i64, ptr }
  %l211 = alloca %"compiler/msgs:Msg"
  %l212 = alloca i64
  %l216 = alloca ptr
  %l221 = alloca i32
  %l222 = alloca { i64, ptr }
  %l223 = alloca { i64, ptr }
  %l226 = alloca %"compiler/source:Span"
  %l227 = alloca i32
  %l231 = alloca %"compiler/typed:Payload"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %rv = alloca ptr
  %t164 = alloca { i64, [4 x i64] }, align 8
  %t279 = alloca { i64, [4 x i64] }, align 8
  %t474 = alloca { i64, [4 x i64] }, align 8
  %t492 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store { i64, ptr } %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t8 = call %"compiler/generic:Desc" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDescOf(ptr %v0, ptr %t4, i32 %a3)
  store %"compiler/generic:Desc" %t8, ptr %l28
  br label %bb1
bb1:
  %t9 = load %"compiler/generic:Desc", ptr %l28
  store %"compiler/generic:Desc" %t9, ptr %l5
  %t10 = getelementptr %"compiler/generic:Desc", ptr %l5, i32 0, i32 0
  %t11 = load i64, ptr %t10, !tbaa !24
  %t12 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescField, !tbaa !24
  %t15 = icmp ne i64 %t11, %t12
  br i1 %t15, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t17 = load ptr, ptr %l0, !tbaa !29
  store ptr %t17, ptr %l32, !tbaa !29
  store %"compiler/source:Span" %a2, ptr %l33
  %t19 = getelementptr %"compiler/generic:Desc", ptr %l5, i32 0, i32 0
  %t20 = load i64, ptr %t19, !tbaa !24
  %t21 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescCase, !tbaa !24
  %t24 = icmp eq i64 %t20, %t21
  br i1 %t24, label %bb4, label %bb5
bb3:
  br label %bb13
bb4:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d49, i32 0, i32 1) }, ptr %l37, !tbaa !27
  br label %bb9
bb5:
  %t26 = getelementptr %"compiler/generic:Desc", ptr %l5, i32 0, i32 0
  %t27 = load i64, ptr %t26, !tbaa !24
  %t28 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescParam, !tbaa !24
  %t31 = icmp eq i64 %t27, %t28
  br i1 %t31, label %bb6, label %bb7
bb6:
  store { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d50, i32 0, i32 1) }, ptr %l41, !tbaa !27
  br label %bb8
bb7:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d51, i32 0, i32 1) }, ptr %l41, !tbaa !27
  br label %bb8
bb8:
  %t33 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t33, ptr %l37, !tbaa !27
  br label %bb9
bb9:
  %t34 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t35 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eReflDescNoMember(ptr %s1, ptr %s1, ptr %s1, ptr %s1, { i64, ptr } %t34, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d52, i32 0, i32 1) }, { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d53, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t35, ptr %l42
  br label %bb10
bb10:
  %t36 = load ptr, ptr %l32, !tbaa !29
  %t37 = load %"compiler/source:Span", ptr %l33
  %t38 = load %"compiler/msgs:Msg", ptr %l42
  %t39 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s1, ptr %t36, %"compiler/source:Span" %t37, %"compiler/msgs:Msg" %t38)
  store i64 %t39, ptr %l43
  br label %bb11
bb11:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load { i64, ptr }, ptr %l4, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v1, ptr %t40, { i64, ptr } %t41)
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb13:
  %t45 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t47 = extractvalue { i64, ptr } %t45, 0
  %t49 = icmp ne i64 %t47, 1
  br i1 %t49, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s2
  %t51 = load ptr, ptr %l0, !tbaa !29
  store ptr %t51, ptr %l50, !tbaa !29
  %t52 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t52, ptr %l51
  %t53 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t55 = extractvalue { i64, ptr } %t53, 0
  %t57 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eReflOfArgs(ptr %s2, i64 %t55)
  store %"compiler/msgs:Msg" %t57, ptr %l54
  br label %bb16
bb15:
  br label %bb19
bb16:
  %t58 = load ptr, ptr %l50, !tbaa !29
  %t59 = load %"compiler/source:Span", ptr %l51
  %t60 = load %"compiler/msgs:Msg", ptr %l54
  %t61 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s2, ptr %t58, %"compiler/source:Span" %t59, %"compiler/msgs:Msg" %t60)
  store i64 %t61, ptr %l55
  br label %bb17
bb17:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load { i64, ptr }, ptr %l4, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v1, ptr %t62, { i64, ptr } %t63)
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb19:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t68, ptr %l60, !tbaa !27
  %t69 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !27
  %t71 = getelementptr ptr, ptr %t70, i64 0
  %t72 = load ptr, ptr %t71, !tbaa !39
  %t75 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplace(ptr %v0, ptr %v1, ptr %t67, ptr %t72)
  store ptr %t75, ptr %l62
  br label %bb20
bb20:
  %t76 = load ptr, ptr %l62, !tbaa !29
  store ptr %t76, ptr %l6, !tbaa !29
  %t77 = load ptr, ptr %l6, !tbaa !29
  %t79 = icmp eq ptr %t77, null
  br i1 %t79, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  %t82 = load ptr, ptr %l6, !tbaa !29
  store ptr %t82, ptr %l7, !tbaa !29
  %t84 = load ptr, ptr %l7, !tbaa !29
  %t86 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v0, ptr %t84)
  store i32 %t86, ptr %l68
  br label %bb24
bb24:
  %t87 = load i32, ptr %l68, !tbaa !23
  store i32 %t87, ptr %l8, !tbaa !23
  store i64 0, ptr %l9, !tbaa !24
  store i64 4, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t88 = load i64, ptr %l10, !tbaa !24
  %t89 = load i64, ptr %l9, !tbaa !24
  %t92 = icmp sgt i64 %t88, %t89
  br i1 %t92, label %bb25, label %bb26
bb25:
  %t94 = load i64, ptr %l11, !tbaa !24
  %t96 = icmp sgt i64 %t94, 0
  br i1 %t96, label %bb27, label %bb28
bb26:
  store i64 0, ptr %l72, !tbaa !24
  br label %bb30
bb27:
  %t98 = load i64, ptr %l10, !tbaa !24
  %t99 = load i64, ptr %l9, !tbaa !24
  %t102 = sub i64 %t98, %t99
  %t103 = load i64, ptr %l11, !tbaa !24
  %t106 = add i64 %t102, %t103
  %t108 = sub i64 %t106, 1
  %t109 = load i64, ptr %l11, !tbaa !24
  %t112 = sdiv i64 %t108, %t109
  store i64 %t112, ptr %l75, !tbaa !24
  br label %bb29
bb28:
  store i64 0, ptr %l75, !tbaa !24
  br label %bb29
bb29:
  %t114 = load i64, ptr %l75, !tbaa !24
  store i64 %t114, ptr %l72, !tbaa !24
  br label %bb30
bb30:
  %t115 = load i64, ptr %l72, !tbaa !24
  store i64 %t115, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb31
bb31:
  %t116 = load i64, ptr %l13, !tbaa !24
  %t117 = load i64, ptr %l12, !tbaa !24
  %t120 = icmp slt i64 %t116, %t117
  %t122 = xor i1 %t120, true
  br i1 %t122, label %bb32, label %bb33
bb32:
  br label %bb44
bb33:
  br label %bb34
bb34:
  %t124 = load i64, ptr %l9, !tbaa !24
  %t125 = load i64, ptr %l13, !tbaa !24
  %t126 = load i64, ptr %l11, !tbaa !24
  %t129 = mul i64 %t125, %t126
  %t132 = add i64 %t124, %t129
  store i64 %t132, ptr %l14, !tbaa !24
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t135 = load i32, ptr %l8, !tbaa !23
  %t138 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t134, i32 %t135)
  store i1 %t138, ptr %l95
  br label %bb35
bb35:
  %t139 = load i1, ptr %l95, !tbaa !21
  %t140 = xor i1 %t139, true
  br i1 %t140, label %bb36, label %bb37
bb36:
  br label %bb44
bb37:
  br label %bb38
bb38:
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t143 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enullRead(ptr %v0, ptr %v0, ptr %t142, ptr %t143)
  br label %bb39
bb39:
  %t146 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t146, ptr %l99
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t149 = getelementptr %"compiler/check:Checker", ptr %t147, i32 0, i32 1
  %t150 = load ptr, ptr %t149, !tbaa !29
  %t152 = getelementptr %"compiler/generic:Program", ptr %t150, i32 0, i32 2
  %t153 = load i32, ptr %l8, !tbaa !23
  %t156 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t152, i32 %t153)
  store i32 %t156, ptr %l104
  br label %bb40
bb40:
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t158 = load %"compiler/source:Span", ptr %l1
  %t159 = load ptr, ptr %l7, !tbaa !29
  %t163 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t157, %"compiler/source:Span" %t158, ptr %t159)
  store ptr %t163, ptr %l108
  br label %bb41
bb41:
  store { i64, [4 x i64] } zeroinitializer, ptr %t164
  %t165 = getelementptr { i64, [4 x i64] }, ptr %t164, i32 0, i32 0
  store i64 2, ptr %t165
  %t166 = load %"compiler/source:Span", ptr %l99
  %t167 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t166, 0
  %t168 = load i32, ptr %l104, !tbaa !23
  %t169 = insertvalue { %"compiler/source:Span", i32, ptr } %t167, i32 %t168, 1
  %t170 = load ptr, ptr %l108, !tbaa !29
  %t171 = insertvalue { %"compiler/source:Span", i32, ptr } %t169, ptr %t170, 2
  %t172 = getelementptr { i64, [4 x i64] }, ptr %t164, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t171, ptr %t172
  %t173 = load { i64, [4 x i64] }, ptr %t164
  %t175 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t173, ptr %t175
  store ptr %t175, ptr %l7, !tbaa !29
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t179 = getelementptr %"compiler/check:Checker", ptr %t177, i32 0, i32 1
  %t180 = load ptr, ptr %t179, !tbaa !29
  %t182 = getelementptr %"compiler/generic:Program", ptr %t180, i32 0, i32 2
  %t183 = load i32, ptr %l8, !tbaa !23
  %t186 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t182, i32 %t183)
  store i32 %t186, ptr %l115
  br label %bb42
bb42:
  %t187 = load i32, ptr %l115, !tbaa !23
  store i32 %t187, ptr %l8, !tbaa !23
  br label %bb43
bb43:
  %t188 = load i64, ptr %l13, !tbaa !24
  %t190 = add i64 %t188, 1
  store i64 %t190, ptr %l13, !tbaa !24
  br label %bb31
bb44:
  %t192 = load i32, ptr %l8, !tbaa !23
  %t193 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t196 = icmp eq i32 %t192, %t193
  br i1 %t196, label %bb45, label %bb46
bb45:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb46:
  br label %bb47
bb47:
  %t199 = load ptr, ptr %l0, !tbaa !29
  %t201 = getelementptr %"compiler/check:Checker", ptr %t199, i32 0, i32 1
  %t202 = load ptr, ptr %t201, !tbaa !29
  %t204 = getelementptr %"compiler/generic:Program", ptr %t202, i32 0, i32 2
  %t205 = load i32, ptr %l8, !tbaa !23
  %t206 = getelementptr %"compiler/generic:Desc", ptr %l5, i32 0, i32 1
  %t207 = load i32, ptr %t206, !tbaa !23
  %t211 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t204, i32 %t205, i32 %t207)
  store i1 %t211, ptr %l127
  br label %bb48
bb48:
  %t212 = load i1, ptr %l127, !tbaa !21
  %t213 = xor i1 %t212, true
  br i1 %t213, label %bb49, label %bb50
bb49:
  store %olang.scope zeroinitializer, ptr %s9
  %t215 = load ptr, ptr %l0, !tbaa !29
  store ptr %t215, ptr %l129, !tbaa !29
  %t216 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t216, ptr %l130, !tbaa !27
  %t217 = getelementptr { i64, ptr }, ptr %l130, i32 0, i32 1
  %t218 = load ptr, ptr %t217, !tbaa !27
  %t219 = getelementptr ptr, ptr %t218, i64 0
  %t220 = load ptr, ptr %t219, !tbaa !39
  %t222 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t220)
  store %"compiler/source:Span" %t222, ptr %l132
  br label %bb51
bb50:
  br label %bb56
bb51:
  %t223 = load ptr, ptr %l0, !tbaa !29
  %t224 = getelementptr %"compiler/generic:Desc", ptr %l5, i32 0, i32 1
  %t225 = load i32, ptr %t224, !tbaa !23
  %t228 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s9, ptr %t223, i32 %t225)
  store { i64, ptr } %t228, ptr %l135
  br label %bb52
bb52:
  %t229 = load { i64, ptr }, ptr %l135, !tbaa !27
  %t230 = extractvalue { i64, ptr } %t229, 0
  %t231 = extractvalue { i64, ptr } %t229, 1
  %t232 = mul i64 %t230, 1
  %t233 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t232)
  call void @llvm.memcpy.p0.p0.i64(ptr %t233, ptr %t231, i64 %t232, i1 false)
  %t234 = insertvalue { i64, ptr } undef, i64 %t230, 0
  %t235 = insertvalue { i64, ptr } %t234, ptr %t233, 1
  store { i64, ptr } %t235, ptr %l136, !tbaa !27
  %t236 = load ptr, ptr %l0, !tbaa !29
  %t237 = load i32, ptr %l8, !tbaa !23
  %t240 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s9, ptr %t236, i32 %t237)
  store { i64, ptr } %t240, ptr %l139
  br label %bb53
bb53:
  %t241 = load { i64, ptr }, ptr %l139, !tbaa !27
  %t242 = extractvalue { i64, ptr } %t241, 0
  %t243 = extractvalue { i64, ptr } %t241, 1
  %t244 = mul i64 %t242, 1
  %t245 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t244)
  call void @llvm.memcpy.p0.p0.i64(ptr %t245, ptr %t243, i64 %t244, i1 false)
  %t246 = insertvalue { i64, ptr } undef, i64 %t242, 0
  %t247 = insertvalue { i64, ptr } %t246, ptr %t245, 1
  %t248 = load { i64, ptr }, ptr %l136, !tbaa !27
  %t250 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eReflOfType(ptr %s9, ptr %s9, ptr %s9, { i64, ptr } %t248, { i64, ptr } %t247)
  store %"compiler/msgs:Msg" %t250, ptr %l141
  br label %bb54
bb54:
  %t251 = load ptr, ptr %l129, !tbaa !29
  %t252 = load %"compiler/source:Span", ptr %l132
  %t253 = load %"compiler/msgs:Msg", ptr %l141
  %t254 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s9, ptr %t251, %"compiler/source:Span" %t252, %"compiler/msgs:Msg" %t253)
  store i64 %t254, ptr %l142
  br label %bb55
bb55:
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb56:
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t258 = getelementptr %"compiler/check:Checker", ptr %t256, i32 0, i32 1
  %t259 = load ptr, ptr %t258, !tbaa !29
  %t260 = load %"compiler/generic:Desc", ptr %l5
  %t263 = call { i32, { i64, ptr } } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDescType(ptr %v0, ptr %s0, ptr %t259, %"compiler/generic:Desc" %t260)
  store { i32, { i64, ptr } } %t263, ptr %l147
  br label %bb57
bb57:
  %t264 = load { i32, { i64, ptr } }, ptr %l147
  store { i32, { i64, ptr } } %t264, ptr %l15
  %t265 = getelementptr { i32, { i64, ptr } }, ptr %l15, i32 0, i32 0
  %t266 = load i32, ptr %t265, !tbaa !23
  store i32 %t266, ptr %l16, !tbaa !23
  %t268 = load ptr, ptr %l0, !tbaa !29
  %t269 = load i32, ptr %l8, !tbaa !23
  %t272 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisStruct(ptr %v0, ptr %t268, i32 %t269)
  store i1 %t272, ptr %l151
  br label %bb58
bb58:
  %t273 = load i1, ptr %l151, !tbaa !21
  br i1 %t273, label %bb59, label %bb60
bb59:
  %t274 = load %"compiler/source:Span", ptr %l1
  %t275 = load i32, ptr %l16, !tbaa !23
  %t276 = load ptr, ptr %l7, !tbaa !29
  %t277 = getelementptr %"compiler/generic:Desc", ptr %l5, i32 0, i32 3
  %t278 = load i64, ptr %t277, !tbaa !24
  store { i64, [4 x i64] } zeroinitializer, ptr %t279
  %t280 = getelementptr { i64, [4 x i64] }, ptr %t279, i32 0, i32 0
  store i64 3, ptr %t280
  %t282 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } undef, %"compiler/source:Span" %t274, 0
  %t284 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t282, i32 %t275, 1
  %t286 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t284, ptr %t276, 2
  %t288 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t286, i64 %t278, 3
  %t289 = getelementptr { i64, [4 x i64] }, ptr %t279, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i64 } %t288, ptr %t289
  %t290 = load { i64, [4 x i64] }, ptr %t279
  %t292 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t290, ptr %t292
  call void @__olang_scope_close(ptr %s0)
  store ptr %t292, ptr %rv
  br label %ret
bb60:
  br label %bb61
bb61:
  %t294 = load ptr, ptr %l0, !tbaa !29
  %t295 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t295, ptr %l159, !tbaa !27
  %t296 = getelementptr { i64, ptr }, ptr %l159, i32 0, i32 1
  %t297 = load ptr, ptr %t296, !tbaa !27
  %t298 = getelementptr ptr, ptr %t297, i64 0
  %t299 = load ptr, ptr %t298, !tbaa !39
  %t302 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrowLocal(ptr %v0, ptr %v1, ptr %t294, ptr %t299)
  store i64 %t302, ptr %l161
  br label %bb62
bb62:
  %t303 = load i64, ptr %l161, !tbaa !24
  store i64 %t303, ptr %l17, !tbaa !24
  store i1 false, ptr %l18, !tbaa !21
  %t304 = load ptr, ptr %l0, !tbaa !29
  %t306 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t304)
  store ptr %t306, ptr %l163
  br label %bb63
bb63:
  %t307 = load ptr, ptr %l163, !tbaa !29
  %t309 = getelementptr %"compiler/check:frame", ptr %t307, i32 0, i32 44
  store ptr %t309, ptr %l19, !tbaa !29
  store i64 0, ptr %l20, !tbaa !24
  br label %bb64
bb64:
  %t311 = load i64, ptr %l20, !tbaa !24
  store i64 %t311, ptr %l166, !tbaa !24
  %t312 = load ptr, ptr %l19, !tbaa !29
  %t314 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2eLen_3ccompiler_2fcheck_3anarrowed_3e(ptr %v0, ptr %t312)
  store i64 %t314, ptr %l168
  br label %bb65
bb65:
  %t315 = load i64, ptr %l166, !tbaa !24
  %t316 = load i64, ptr %l168, !tbaa !24
  %t317 = icmp slt i64 %t315, %t316
  %t319 = xor i1 %t317, true
  br i1 %t319, label %bb66, label %bb67
bb66:
  br label %bb80
bb67:
  br label %bb68
bb68:
  %t321 = load ptr, ptr %l19, !tbaa !29
  %t322 = load i64, ptr %l20, !tbaa !24
  %t325 = call %"compiler/check:narrowed" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2eAt_3ccompiler_2fcheck_3anarrowed_3e(ptr %v0, ptr %t321, i64 %t322)
  store %"compiler/check:narrowed" %t325, ptr %l173
  br label %bb69
bb69:
  %t326 = load %"compiler/check:narrowed", ptr %l173
  store %"compiler/check:narrowed" %t326, ptr %l21
  %t327 = getelementptr %"compiler/check:narrowed", ptr %l21, i32 0, i32 0
  %t328 = load i64, ptr %t327, !tbaa !24
  %t329 = load i64, ptr %l17, !tbaa !24
  %t332 = icmp eq i64 %t328, %t329
  br i1 %t332, label %bb70, label %bb71
bb70:
  %t334 = getelementptr %"compiler/check:narrowed", ptr %l21, i32 0, i32 1
  %t335 = load i64, ptr %t334, !tbaa !24
  %t336 = getelementptr %"compiler/generic:Desc", ptr %l5, i32 0, i32 2
  %t337 = load i64, ptr %t336, !tbaa !24
  %t340 = icmp eq i64 %t335, %t337
  store i1 %t340, ptr %l177, !tbaa !21
  br label %bb72
bb71:
  store i1 false, ptr %l177, !tbaa !21
  br label %bb72
bb72:
  %t342 = load i1, ptr %l177, !tbaa !21
  br i1 %t342, label %bb73, label %bb74
bb73:
  %t343 = getelementptr %"compiler/check:narrowed", ptr %l21, i32 0, i32 5
  %t344 = load i1, ptr %t343, !tbaa !21
  %t346 = xor i1 %t344, true
  store i1 %t346, ptr %l181, !tbaa !21
  br label %bb75
bb74:
  store i1 false, ptr %l181, !tbaa !21
  br label %bb75
bb75:
  %t348 = load i1, ptr %l181, !tbaa !21
  br i1 %t348, label %bb76, label %bb77
bb76:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb78
bb77:
  br label %bb78
bb78:
  br label %bb79
bb79:
  %t349 = load i64, ptr %l20, !tbaa !24
  %t351 = add i64 %t349, 1
  store i64 %t351, ptr %l20, !tbaa !24
  br label %bb64
bb80:
  %t353 = load i1, ptr %l18, !tbaa !21
  %t355 = xor i1 %t353, true
  br i1 %t355, label %bb81, label %bb82
bb81:
  store %olang.scope zeroinitializer, ptr %s15
  %t357 = load ptr, ptr %l0, !tbaa !29
  %t359 = getelementptr %"compiler/check:Checker", ptr %t357, i32 0, i32 1
  %t360 = load ptr, ptr %t359, !tbaa !29
  %t362 = getelementptr %"compiler/generic:Program", ptr %t360, i32 0, i32 2
  %t363 = load i32, ptr %l8, !tbaa !23
  %t366 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCaseNames(ptr %v0, ptr %t362, i32 %t363)
  store { i64, ptr } %t366, ptr %l192
  br label %bb83
bb82:
  br label %bb90
bb83:
  %t367 = load { i64, ptr }, ptr %l192, !tbaa !27
  store { i64, ptr } %t367, ptr %l22, !tbaa !27
  %t368 = load ptr, ptr %l0, !tbaa !29
  store ptr %t368, ptr %l193, !tbaa !29
  %t369 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t369, ptr %l194, !tbaa !27
  %t370 = getelementptr { i64, ptr }, ptr %l194, i32 0, i32 1
  %t371 = load ptr, ptr %t370, !tbaa !27
  %t372 = getelementptr ptr, ptr %t371, i64 0
  %t373 = load ptr, ptr %t372, !tbaa !39
  %t375 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t373)
  store %"compiler/source:Span" %t375, ptr %l196
  br label %bb84
bb84:
  %t376 = load ptr, ptr %l0, !tbaa !29
  %t377 = load i32, ptr %l8, !tbaa !23
  %t380 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s15, ptr %t376, i32 %t377)
  store { i64, ptr } %t380, ptr %l199
  br label %bb85
bb85:
  %t381 = load { i64, ptr }, ptr %l199, !tbaa !27
  %t382 = extractvalue { i64, ptr } %t381, 0
  %t383 = extractvalue { i64, ptr } %t381, 1
  %t384 = mul i64 %t382, 1
  %t385 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t384)
  call void @llvm.memcpy.p0.p0.i64(ptr %t385, ptr %t383, i64 %t384, i1 false)
  %t386 = insertvalue { i64, ptr } undef, i64 %t382, 0
  %t387 = insertvalue { i64, ptr } %t386, ptr %t385, 1
  store { i64, ptr } %t387, ptr %l200, !tbaa !27
  %t388 = load ptr, ptr %l0, !tbaa !29
  %t389 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t389, ptr %l202, !tbaa !27
  %t390 = getelementptr %"compiler/generic:Desc", ptr %l5, i32 0, i32 2
  %t391 = load i64, ptr %t390, !tbaa !24
  %t393 = getelementptr { i64, ptr }, ptr %l202, i32 0, i32 1
  %t394 = load ptr, ptr %t393, !tbaa !27
  %t395 = getelementptr i32, ptr %t394, i64 %t391
  %t396 = load i32, ptr %t395, !tbaa !33
  %t399 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t388, i32 %t396)
  store { i64, ptr } %t399, ptr %l205
  br label %bb86
bb86:
  %t400 = load ptr, ptr %l0, !tbaa !29
  %t401 = load %"compiler/generic:Desc", ptr %l5
  %t404 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edescName(ptr %v0, ptr %s15, ptr %t400, %"compiler/generic:Desc" %t401)
  store { i64, ptr } %t404, ptr %l208
  br label %bb87
bb87:
  %t405 = load { i64, ptr }, ptr %l205, !tbaa !27
  %t406 = extractvalue { i64, ptr } %t405, 1
  %t407 = extractvalue { i64, ptr } %t405, 0
  %t408 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d54, i32 0, i32 1) }, 1
  %t409 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d54, i32 0, i32 1) }, 0
  %t410 = add i64 %t407, %t409
  %t411 = load { i64, ptr }, ptr %l208, !tbaa !27
  %t412 = extractvalue { i64, ptr } %t411, 1
  %t413 = extractvalue { i64, ptr } %t411, 0
  %t414 = add i64 %t410, %t413
  %t415 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t414)
  call void @olang_textcopy(ptr %t415, ptr %t406, i64 %t407)
  %t416 = getelementptr i8, ptr %t415, i64 %t407
  call void @olang_textcopy(ptr %t416, ptr %t408, i64 %t409)
  %t417 = getelementptr i8, ptr %t416, i64 %t409
  call void @olang_textcopy(ptr %t417, ptr %t412, i64 %t413)
  %t418 = insertvalue { i64, ptr } undef, i64 %t414, 0
  %t419 = insertvalue { i64, ptr } %t418, ptr %t415, 1
  %t421 = extractvalue { i64, ptr } %t419, 0
  %t422 = extractvalue { i64, ptr } %t419, 1
  %t423 = mul i64 %t421, 1
  %t424 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t423)
  call void @llvm.memcpy.p0.p0.i64(ptr %t424, ptr %t422, i64 %t423, i1 false)
  %t425 = insertvalue { i64, ptr } undef, i64 %t421, 0
  %t426 = insertvalue { i64, ptr } %t425, ptr %t424, 1
  %t427 = load { i64, ptr }, ptr %l200, !tbaa !27
  %t429 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eFieldOfEnum(ptr %s15, ptr %s15, ptr %s15, { i64, ptr } %t427, { i64, ptr } %t426)
  store %"compiler/msgs:Msg" %t429, ptr %l211
  br label %bb88
bb88:
  %t430 = load ptr, ptr %l193, !tbaa !29
  %t431 = load %"compiler/source:Span", ptr %l196
  %t432 = load %"compiler/msgs:Msg", ptr %l211
  %t433 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s15, ptr %t430, %"compiler/source:Span" %t431, %"compiler/msgs:Msg" %t432)
  store i64 %t433, ptr %l212
  br label %bb89
bb89:
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb90:
  %t435 = load ptr, ptr %l0, !tbaa !29
  %t437 = getelementptr %"compiler/check:Checker", ptr %t435, i32 0, i32 1
  %t438 = load ptr, ptr %t437, !tbaa !29
  %t440 = getelementptr %"compiler/generic:Program", ptr %t438, i32 0, i32 2
  store ptr %t440, ptr %l216, !tbaa !29
  %t441 = load ptr, ptr %l0, !tbaa !29
  %t443 = getelementptr %"compiler/check:Checker", ptr %t441, i32 0, i32 1
  %t444 = load ptr, ptr %t443, !tbaa !29
  %t446 = getelementptr %"compiler/generic:Program", ptr %t444, i32 0, i32 2
  %t447 = load i32, ptr %l8, !tbaa !23
  %t450 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t446, i32 %t447)
  store i32 %t450, ptr %l221
  br label %bb91
bb91:
  %t451 = load ptr, ptr %l216, !tbaa !29
  %t452 = load i32, ptr %l221, !tbaa !23
  %t453 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t451, i32 %t452)
  store { i64, ptr } %t453, ptr %l222
  br label %bb92
bb92:
  %t454 = load { i64, ptr }, ptr %l222, !tbaa !27
  store { i64, ptr } %t454, ptr %l223, !tbaa !27
  %t455 = getelementptr %"compiler/generic:Desc", ptr %l5, i32 0, i32 2
  %t456 = load i64, ptr %t455, !tbaa !24
  %t458 = getelementptr { i64, ptr }, ptr %l223, i32 0, i32 1
  %t459 = load ptr, ptr %t458, !tbaa !27
  %t460 = getelementptr i32, ptr %t459, i64 %t456
  %t461 = load i32, ptr %t460, !tbaa !33
  %t463 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t463, ptr %l226
  store i32 %t461, ptr %l227, !tbaa !23
  %t465 = load ptr, ptr %l7, !tbaa !29
  %t466 = getelementptr %"compiler/generic:Desc", ptr %l5, i32 0, i32 2
  %t467 = load i64, ptr %t466, !tbaa !24
  %t471 = call %"compiler/typed:Payload" @compiler_2ftyped_3aPayload_2ector(ptr %v0, ptr %v0, ptr %t465, i64 %t467, i32 0)
  store %"compiler/typed:Payload" %t471, ptr %l231
  br label %bb93
bb93:
  %t472 = load %"compiler/typed:Payload", ptr %l231
  %t473 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Payload" %t472, ptr %t473
  store { i64, [4 x i64] } zeroinitializer, ptr %t474
  %t475 = getelementptr { i64, [4 x i64] }, ptr %t474, i32 0, i32 0
  store i64 5, ptr %t475
  %t476 = load %"compiler/source:Span", ptr %l226
  %t477 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t476, 0
  %t478 = load i32, ptr %l227, !tbaa !23
  %t479 = insertvalue { %"compiler/source:Span", i32, ptr } %t477, i32 %t478, 1
  %t481 = insertvalue { %"compiler/source:Span", i32, ptr } %t479, ptr %t473, 2
  %t482 = getelementptr { i64, [4 x i64] }, ptr %t474, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t481, ptr %t482
  %t483 = load { i64, [4 x i64] }, ptr %t474
  %t484 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store ptr %t484, ptr %lp24
  %t486 = load ptr, ptr %lp24
  store { i64, [4 x i64] } %t483, ptr %t486
  %t487 = load %"compiler/source:Span", ptr %l1
  %t488 = load i32, ptr %l16, !tbaa !23
  %t489 = load ptr, ptr %lp24
  %t490 = getelementptr %"compiler/generic:Desc", ptr %l5, i32 0, i32 3
  %t491 = load i64, ptr %t490, !tbaa !24
  store { i64, [4 x i64] } zeroinitializer, ptr %t492
  %t493 = getelementptr { i64, [4 x i64] }, ptr %t492, i32 0, i32 0
  store i64 3, ptr %t493
  %t495 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } undef, %"compiler/source:Span" %t487, 0
  %t497 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t495, i32 %t488, 1
  %t499 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t497, ptr %t489, 2
  %t501 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t499, i64 %t491, 3
  %t502 = getelementptr { i64, [4 x i64] }, ptr %t492, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i64 } %t501, ptr %t502
  %t503 = load { i64, [4 x i64] }, ptr %t492
  %t505 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t503, ptr %t505
  call void @__olang_scope_close(ptr %s0)
  store ptr %t505, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroCallAt(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l1 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i1
  %l17 = alloca i1
  %l19 = alloca { i64, ptr }
  %l21 = alloca %"compiler/source:Span"
  %l23 = alloca %"compiler/source:Span"
  %l25 = alloca i1
  %l28 = alloca %"compiler/source:Span"
  %rv = alloca %"compiler/source:Span"
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 6
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l3
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t18, i32 0, i32 2
  %t20 = load ptr, ptr %t19
  store ptr %t20, ptr %l4, !tbaa !29
  br label %bb5
bb4:
  br label %bb15
bb5:
  %t22 = load ptr, ptr %l4, !tbaa !29
  %t24 = getelementptr %"compiler/typed:Call", ptr %t22, i32 0, i32 1
  %t25 = load { i64, ptr }, ptr %t24, !tbaa !27
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t29 = icmp sgt i64 %t27, 0
  br i1 %t29, label %bb6, label %bb7
bb6:
  %t31 = load ptr, ptr %l4, !tbaa !29
  %t33 = getelementptr %"compiler/typed:Call", ptr %t31, i32 0, i32 1
  %t34 = load { i64, ptr }, ptr %t33, !tbaa !27
  store { i64, ptr } %t34, ptr %l19, !tbaa !27
  %t35 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !27
  %t37 = getelementptr ptr, ptr %t36, i64 0
  %t38 = load ptr, ptr %t37, !tbaa !39
  %t40 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t38)
  store %"compiler/source:Span" %t40, ptr %l21
  br label %bb8
bb7:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb10
bb8:
  %t41 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t41, ptr %l23
  %t44 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fsource_3aSpan(ptr %l21, ptr %l23)
  store i1 %t44, ptr %l25
  br label %bb9
bb9:
  %t45 = load i1, ptr %l25, !tbaa !21
  store i1 %t45, ptr %l17, !tbaa !21
  br label %bb10
bb10:
  %t46 = load i1, ptr %l17, !tbaa !21
  br i1 %t46, label %bb11, label %bb12
bb11:
  %t48 = load %"compiler/source:Span", ptr %l3
  %t51 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebracketIn(ptr %v0, ptr %a0, %"compiler/source:Span" %t48)
  store %"compiler/source:Span" %t51, ptr %l28
  br label %bb13
bb12:
  br label %bb14
bb13:
  %t52 = load %"compiler/source:Span", ptr %l28
  store %"compiler/source:Span" %t52, ptr %rv
  br label %ret
bb14:
  br label %bb20
bb15:
  br i1 true, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_860e4bd13e8a5221_206c5ac6505376ad)
  unreachable
bb20:
  store %"compiler/source:Span" %a2, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroLet(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l6 = alloca i1
  %l8 = alloca ptr
  %l11 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l14 = alloca i32
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t6 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroValue(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  store i1 %t6, ptr %l6
  br label %bb1
bb1:
  %t7 = load i1, ptr %l6, !tbaa !21
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/check:Checker", ptr %t8, i32 0, i32 61
  store ptr %t10, ptr %l8, !tbaa !29
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load i64, ptr %l1, !tbaa !24
  %t15 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroKey(ptr %v0, ptr %t11, i64 %t12)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t15, ptr %l11
  br label %bb4
bb3:
  br label %bb7
bb4:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t20 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroName(ptr %v0, ptr %v1, ptr %t16, ptr %t17)
  store i32 %t20, ptr %l14
  br label %bb5
bb5:
  %t21 = load ptr, ptr %l8, !tbaa !29
  %t22 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l11
  %t23 = load i32, ptr %l14, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_Hc59e30334647acda8fe9b2b02a632dfd(ptr %v0, ptr %t21, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t22, i32 %t23)
  br label %bb6
bb6:
  br label %bb7
bb7:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load i64, ptr %l1, !tbaa !24
  %t26 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroTrack(ptr %v0, ptr %v1, ptr %t24, i64 %t25, ptr %t26)
  br label %bb8
bb8:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroRef(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca { i64, ptr }
  %l13 = alloca ptr
  %l16 = alloca i32
  %l17 = alloca i64
  %l21 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca i64
  %l26 = alloca i1
  %l27 = alloca ptr
  %l29 = alloca ptr
  %l30 = alloca i1
  %l31 = alloca i1
  %l32 = alloca ptr
  %l33 = alloca i1
  %l40 = alloca i1
  %l41 = alloca ptr
  %l42 = alloca i1
  %l50 = alloca i1
  %l51 = alloca ptr
  %l52 = alloca i1
  %l61 = alloca i1
  %l62 = alloca ptr
  %l63 = alloca i1
  %l70 = alloca i1
  %l71 = alloca ptr
  %l72 = alloca i1
  %l80 = alloca i1
  %l81 = alloca i1
  %l85 = alloca i1
  %l87 = alloca { i64, ptr }
  %l90 = alloca i1
  %l91 = alloca ptr
  %l92 = alloca i1
  %l95 = alloca ptr
  %l96 = alloca i1
  %l99 = alloca ptr
  %l100 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = getelementptr %"compiler/generic:Program", ptr %t9, i32 0, i32 2
  store ptr %t11, ptr %l13, !tbaa !29
  %t12 = load ptr, ptr %l1, !tbaa !29
  %t15 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t12)
  store i32 %t15, ptr %l16
  br label %bb4
bb4:
  %t16 = load ptr, ptr %l13, !tbaa !29
  %t17 = load i32, ptr %l16, !tbaa !23
  %t18 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t16, i32 %t17)
  store i64 %t18, ptr %l17
  br label %bb5
bb5:
  %t19 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t20 = load i64, ptr %l17, !tbaa !24
  %t22 = and i64 %t20, %t19
  %t24 = icmp ne i64 %t22, 0
  br i1 %t24, label %bb6, label %bb7
bb6:
  %t26 = load ptr, ptr %l0, !tbaa !29
  store ptr %t26, ptr %l21, !tbaa !29
  %t27 = load ptr, ptr %l1, !tbaa !29
  %t29 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v1, ptr %t27)
  store ptr %t29, ptr %l23
  br label %bb8
bb7:
  br label %bb15
bb8:
  %t30 = load ptr, ptr %l21, !tbaa !29
  %t31 = load ptr, ptr %l23, !tbaa !29
  %t32 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroRoot(ptr %v0, ptr %v1, ptr %t30, ptr %t31)
  store i64 %t32, ptr %l24
  br label %bb9
bb9:
  %t33 = load i64, ptr %l24, !tbaa !24
  %t34 = icmp sge i64 %t33, 0
  br i1 %t34, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb14
bb11:
  %t36 = load ptr, ptr %l0, !tbaa !29
  store ptr %t36, ptr %l27, !tbaa !29
  %t37 = load ptr, ptr %l1, !tbaa !29
  %t39 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v1, ptr %t37)
  store ptr %t39, ptr %l29
  br label %bb12
bb12:
  %t40 = load ptr, ptr %l27, !tbaa !29
  %t41 = load ptr, ptr %l29, !tbaa !29
  %t42 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroTempBase(ptr %v0, ptr %v1, ptr %t40, ptr %t41)
  store i1 %t42, ptr %l30
  br label %bb13
bb13:
  %t43 = load i1, ptr %l30, !tbaa !21
  store i1 %t43, ptr %l26, !tbaa !21
  br label %bb14
bb14:
  %t44 = load i1, ptr %l26, !tbaa !21
  store i1 %t44, ptr %rv
  br label %ret
bb15:
  %t45 = load ptr, ptr %l1, !tbaa !29
  store ptr %t45, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t46 = load ptr, ptr %l32, !tbaa !29
  %t47 = icmp ne ptr %t46, null
  br i1 %t47, label %bb16, label %bb17
bb16:
  %t49 = load ptr, ptr %l32, !tbaa !29
  %t50 = load i64, ptr %t49
  %t52 = icmp eq i64 %t50, 2
  store i1 %t52, ptr %l33, !tbaa !21
  br label %bb17
bb17:
  %t53 = load i1, ptr %l33, !tbaa !21
  br i1 %t53, label %bb18, label %bb19
bb18:
  %t54 = load ptr, ptr %l1, !tbaa !29
  %t56 = getelementptr { i64, [5 x i64] }, ptr %t54, i32 0, i32 1
  %t57 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t56, i32 0, i32 2
  %t58 = load ptr, ptr %t57
  store ptr %t58, ptr %l2, !tbaa !29
  br label %bb20
bb19:
  br label %bb22
bb20:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load ptr, ptr %l2, !tbaa !29
  %t64 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroRead(ptr %v0, ptr %v1, ptr %t60, ptr %t61)
  store i1 %t64, ptr %l40
  br label %bb21
bb21:
  %t65 = load i1, ptr %l40, !tbaa !21
  store i1 %t65, ptr %l31, !tbaa !21
  br label %bb76
bb22:
  %t66 = load ptr, ptr %l1, !tbaa !29
  store ptr %t66, ptr %l41, !tbaa !29
  store i1 false, ptr %l42, !tbaa !21
  %t67 = load ptr, ptr %l41, !tbaa !29
  %t68 = icmp ne ptr %t67, null
  br i1 %t68, label %bb23, label %bb24
bb23:
  %t70 = load ptr, ptr %l41, !tbaa !29
  %t71 = load i64, ptr %t70
  %t73 = icmp eq i64 %t71, 3
  store i1 %t73, ptr %l42, !tbaa !21
  br label %bb24
bb24:
  %t74 = load i1, ptr %l42, !tbaa !21
  br i1 %t74, label %bb25, label %bb26
bb25:
  %t75 = load ptr, ptr %l1, !tbaa !29
  %t77 = getelementptr { i64, [5 x i64] }, ptr %t75, i32 0, i32 1
  %t78 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t77, i32 0, i32 2
  %t79 = load ptr, ptr %t78
  store ptr %t79, ptr %l3, !tbaa !29
  br label %bb27
bb26:
  br label %bb29
bb27:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t82 = load ptr, ptr %l3, !tbaa !29
  %t86 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroPlace(ptr %v0, ptr %v1, ptr %t81, ptr %t82)
  store i1 %t86, ptr %l50
  br label %bb28
bb28:
  %t87 = load i1, ptr %l50, !tbaa !21
  store i1 %t87, ptr %l31, !tbaa !21
  br label %bb76
bb29:
  %t88 = load ptr, ptr %l1, !tbaa !29
  store ptr %t88, ptr %l51, !tbaa !29
  store i1 false, ptr %l52, !tbaa !21
  %t89 = load ptr, ptr %l51, !tbaa !29
  %t90 = icmp ne ptr %t89, null
  br i1 %t90, label %bb30, label %bb31
bb30:
  %t92 = load ptr, ptr %l51, !tbaa !29
  %t93 = load i64, ptr %t92
  %t95 = icmp eq i64 %t93, 10
  store i1 %t95, ptr %l52, !tbaa !21
  br label %bb31
bb31:
  %t96 = load i1, ptr %l52, !tbaa !21
  br i1 %t96, label %bb32, label %bb33
bb32:
  %t97 = load ptr, ptr %l1, !tbaa !29
  %t99 = getelementptr { i64, [5 x i64] }, ptr %t97, i32 0, i32 1
  %t100 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t99, i32 0, i32 2
  %t101 = load ptr, ptr %t100
  store ptr %t101, ptr %l4, !tbaa !29
  br label %bb34
bb33:
  br label %bb36
bb34:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t104 = load ptr, ptr %l4, !tbaa !29
  %t106 = getelementptr %"compiler/typed:Slice", ptr %t104, i32 0, i32 0
  %t107 = load ptr, ptr %t106, !tbaa !29
  %t111 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroPlace(ptr %v0, ptr %v1, ptr %t103, ptr %t107)
  store i1 %t111, ptr %l61
  br label %bb35
bb35:
  %t112 = load i1, ptr %l61, !tbaa !21
  store i1 %t112, ptr %l31, !tbaa !21
  br label %bb76
bb36:
  %t113 = load ptr, ptr %l1, !tbaa !29
  store ptr %t113, ptr %l62, !tbaa !29
  store i1 false, ptr %l63, !tbaa !21
  %t114 = load ptr, ptr %l62, !tbaa !29
  %t115 = icmp ne ptr %t114, null
  br i1 %t115, label %bb37, label %bb38
bb37:
  %t117 = load ptr, ptr %l62, !tbaa !29
  %t118 = load i64, ptr %t117
  %t120 = icmp eq i64 %t118, 6
  store i1 %t120, ptr %l63, !tbaa !21
  br label %bb38
bb38:
  %t121 = load i1, ptr %l63, !tbaa !21
  br i1 %t121, label %bb39, label %bb40
bb39:
  %t122 = load ptr, ptr %l1, !tbaa !29
  %t124 = getelementptr { i64, [5 x i64] }, ptr %t122, i32 0, i32 1
  %t125 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t124, i32 0, i32 2
  %t126 = load ptr, ptr %t125
  store ptr %t126, ptr %l5, !tbaa !29
  br label %bb41
bb40:
  br label %bb43
bb41:
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t129 = load ptr, ptr %l5, !tbaa !29
  %t132 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroCallRef(ptr %v0, ptr %v1, ptr %t128, ptr %t129)
  store i1 %t132, ptr %l70
  br label %bb42
bb42:
  %t133 = load i1, ptr %l70, !tbaa !21
  store i1 %t133, ptr %l31, !tbaa !21
  br label %bb76
bb43:
  %t134 = load ptr, ptr %l1, !tbaa !29
  store ptr %t134, ptr %l71, !tbaa !29
  store i1 false, ptr %l72, !tbaa !21
  %t135 = load ptr, ptr %l71, !tbaa !29
  %t136 = icmp ne ptr %t135, null
  br i1 %t136, label %bb44, label %bb45
bb44:
  %t138 = load ptr, ptr %l71, !tbaa !29
  %t139 = load i64, ptr %t138
  %t141 = icmp eq i64 %t139, 9
  store i1 %t141, ptr %l72, !tbaa !21
  br label %bb45
bb45:
  %t142 = load i1, ptr %l72, !tbaa !21
  br i1 %t142, label %bb46, label %bb47
bb46:
  %t143 = load ptr, ptr %l1, !tbaa !29
  %t145 = getelementptr { i64, [5 x i64] }, ptr %t143, i32 0, i32 1
  %t146 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t145, i32 0, i32 2
  %t147 = load i32, ptr %t146
  store i32 %t147, ptr %l6
  %t149 = load ptr, ptr %l1, !tbaa !29
  %t151 = getelementptr { i64, [5 x i64] }, ptr %t149, i32 0, i32 1
  %t152 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t151, i32 0, i32 4
  %t153 = load { i64, ptr }, ptr %t152
  store { i64, ptr } %t153, ptr %l7, !tbaa !27
  br label %bb48
bb47:
  br label %bb57
bb48:
  %t155 = load i32, ptr %l6
  %t157 = call i1 @compiler_2ftyped_2ePassesRefs(i32 %t155)
  store i1 %t157, ptr %l80
  br label %bb49
bb49:
  %t158 = load i1, ptr %l80, !tbaa !21
  br i1 %t158, label %bb50, label %bb51
bb50:
  %t159 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t161 = extractvalue { i64, ptr } %t159, 0
  %t163 = icmp sgt i64 %t161, 0
  store i1 %t163, ptr %l81, !tbaa !21
  br label %bb52
bb51:
  store i1 false, ptr %l81, !tbaa !21
  br label %bb52
bb52:
  %t165 = load i1, ptr %l81, !tbaa !21
  br i1 %t165, label %bb53, label %bb54
bb53:
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t167 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t167, ptr %l87, !tbaa !27
  %t168 = getelementptr { i64, ptr }, ptr %l87, i32 0, i32 1
  %t169 = load ptr, ptr %t168, !tbaa !27
  %t170 = getelementptr ptr, ptr %t169, i64 0
  %t171 = load ptr, ptr %t170, !tbaa !39
  %t175 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroRef(ptr %v0, ptr %v1, ptr %t166, ptr %t171)
  store i1 %t175, ptr %l90
  br label %bb55
bb54:
  store i1 true, ptr %l85, !tbaa !21
  br label %bb56
bb55:
  %t176 = load i1, ptr %l90, !tbaa !21
  store i1 %t176, ptr %l85, !tbaa !21
  br label %bb56
bb56:
  %t177 = load i1, ptr %l85, !tbaa !21
  store i1 %t177, ptr %l31, !tbaa !21
  br label %bb76
bb57:
  %t178 = load ptr, ptr %l1, !tbaa !29
  store ptr %t178, ptr %l91, !tbaa !29
  store i1 false, ptr %l92, !tbaa !21
  %t179 = load ptr, ptr %l91, !tbaa !29
  %t180 = icmp ne ptr %t179, null
  br i1 %t180, label %bb58, label %bb59
bb58:
  %t182 = load ptr, ptr %l91, !tbaa !29
  %t183 = load i64, ptr %t182
  %t185 = icmp eq i64 %t183, 5
  store i1 %t185, ptr %l92, !tbaa !21
  br label %bb59
bb59:
  %t186 = load i1, ptr %l92, !tbaa !21
  br i1 %t186, label %bb60, label %bb61
bb60:
  br label %bb70
bb61:
  %t187 = load ptr, ptr %l1, !tbaa !29
  store ptr %t187, ptr %l95, !tbaa !29
  store i1 false, ptr %l96, !tbaa !21
  %t188 = load ptr, ptr %l95, !tbaa !29
  %t189 = icmp ne ptr %t188, null
  br i1 %t189, label %bb62, label %bb63
bb62:
  %t191 = load ptr, ptr %l95, !tbaa !29
  %t192 = load i64, ptr %t191
  %t194 = icmp eq i64 %t192, 1
  store i1 %t194, ptr %l96, !tbaa !21
  br label %bb63
bb63:
  %t195 = load i1, ptr %l96, !tbaa !21
  br i1 %t195, label %bb64, label %bb65
bb64:
  br label %bb70
bb65:
  %t196 = load ptr, ptr %l1, !tbaa !29
  store ptr %t196, ptr %l99, !tbaa !29
  store i1 false, ptr %l100, !tbaa !21
  %t197 = load ptr, ptr %l99, !tbaa !29
  %t198 = icmp ne ptr %t197, null
  br i1 %t198, label %bb66, label %bb67
bb66:
  %t200 = load ptr, ptr %l99, !tbaa !29
  %t201 = load i64, ptr %t200
  %t203 = icmp eq i64 %t201, 0
  store i1 %t203, ptr %l100, !tbaa !21
  br label %bb67
bb67:
  %t204 = load i1, ptr %l100, !tbaa !21
  br i1 %t204, label %bb68, label %bb69
bb68:
  br label %bb70
bb69:
  br label %bb71
bb70:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb76
bb71:
  br i1 true, label %bb72, label %bb73
bb72:
  br label %bb74
bb73:
  br label %bb75
bb74:
  store i1 true, ptr %l31, !tbaa !21
  br label %bb76
bb75:
  call void @__olang_check_failed(ptr @olang_loc_62c5ac3e914a4019_8e197c98e172d865)
  unreachable
bb76:
  %t205 = load i1, ptr %l31, !tbaa !21
  store i1 %t205, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estep(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i1
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca i64
  %l12 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca %"compiler/source:Span"
  %l18 = alloca i32
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l24 = alloca %"compiler/source:Span"
  %l25 = alloca %"compiler/source:Span"
  %l29 = alloca i1
  %l30 = alloca ptr
  %l31 = alloca ptr
  %l33 = alloca %"compiler/source:Span"
  %l35 = alloca i32
  %l38 = alloca i1
  %l40 = alloca i1
  %l43 = alloca i1
  %l44 = alloca i1
  %l48 = alloca i1
  %l53 = alloca i1
  %l59 = alloca i1
  %l61 = alloca ptr
  %l62 = alloca ptr
  %l64 = alloca %"compiler/source:Span"
  %l65 = alloca %"compiler/source:Span"
  %l68 = alloca { i64, ptr }
  %l70 = alloca %"compiler/msgs:Msg"
  %l71 = alloca i64
  %l78 = alloca ptr
  %l79 = alloca ptr
  %l80 = alloca %"compiler/source:Span"
  %l81 = alloca i32
  %l84 = alloca ptr
  %l87 = alloca i32
  %l88 = alloca i1
  %l89 = alloca i64
  %l92 = alloca i32
  %l93 = alloca i64
  %l94 = alloca ptr
  %l96 = alloca i32
  %l101 = alloca i64
  %l108 = alloca ptr
  %l109 = alloca %"compiler/source:Span"
  %l110 = alloca ptr
  %l111 = alloca %"compiler/source:Span"
  %l112 = alloca i32
  %l113 = alloca i32
  %l114 = alloca i32
  %l118 = alloca { i64, ptr }
  %s4 = alloca %olang.scope
  %t131 = alloca { i64, [4 x i64] }, align 8
  %t214 = alloca { i64, [5 x i64] }, align 8
  %t230 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i1 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t5 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplace(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  store ptr %t5, ptr %l12
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l12, !tbaa !29
  store ptr %t6, ptr %l4, !tbaa !29
  %t7 = load ptr, ptr %l4, !tbaa !29
  %t9 = icmp eq ptr %t7, null
  br i1 %t9, label %bb2, label %bb3
bb2:
  br label %ret
bb3:
  br label %bb4
bb4:
  %t11 = load ptr, ptr %l0, !tbaa !29
  store ptr %t11, ptr %l15, !tbaa !29
  %t12 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t12, ptr %l16
  %t13 = load i1, ptr %l3, !tbaa !21
  br i1 %t13, label %bb5, label %bb6
bb5:
  store i32 64, ptr %l18
  br label %bb7
bb6:
  store i32 65, ptr %l18
  br label %bb7
bb7:
  %t17 = load ptr, ptr %l4, !tbaa !29
  store ptr %t17, ptr %l21, !tbaa !29
  %t18 = load ptr, ptr %l0, !tbaa !29
  store ptr %t18, ptr %l22, !tbaa !29
  %t19 = load ptr, ptr %l2, !tbaa !29
  %t21 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t19)
  store %"compiler/source:Span" %t21, ptr %l24
  br label %bb8
bb8:
  %t22 = load ptr, ptr %l22, !tbaa !29
  %t23 = load %"compiler/source:Span", ptr %l24
  %t24 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopAfter(ptr %v0, ptr %t22, %"compiler/source:Span" %t23, i64 2)
  store %"compiler/source:Span" %t24, ptr %l25
  br label %bb9
bb9:
  %t25 = icmp sge i64 0, 0
  br i1 %t25, label %bb10, label %bb11
bb10:
  %t27 = icmp sle i64 0, 1152921504606846975
  br i1 %t27, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_ddf5999d75afc0ea_2c71428eb0b518ce)
  unreachable
bb12:
  %t29 = mul i64 0, 8
  %t30 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t29)
  %t31 = insertvalue { i64, ptr } undef, i64 0, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t33 = load ptr, ptr %l15, !tbaa !29
  %t34 = load %"compiler/source:Span", ptr %l16
  %t35 = load i32, ptr %l18
  %t36 = load ptr, ptr %l21, !tbaa !29
  %t37 = load %"compiler/source:Span", ptr %l25
  %t39 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewriteBack(ptr %v0, ptr %v0, ptr %v0, ptr %t33, %"compiler/source:Span" %t34, i32 %t35, ptr %t36, ptr null, %"compiler/source:Span" %t37, i64 -1, { i64, ptr } %t32)
  store i1 %t39, ptr %l29
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_ddf5999d75afc0ea_2c71428eb0b518ce)
  unreachable
bb14:
  %t40 = load i1, ptr %l29, !tbaa !21
  br i1 %t40, label %bb15, label %bb16
bb15:
  br label %ret
bb16:
  br label %bb17
bb17:
  %t41 = load ptr, ptr %l0, !tbaa !29
  store ptr %t41, ptr %l30, !tbaa !29
  %t42 = load ptr, ptr %l4, !tbaa !29
  store ptr %t42, ptr %l31, !tbaa !29
  %t43 = load ptr, ptr %l2, !tbaa !29
  %t45 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t43)
  store %"compiler/source:Span" %t45, ptr %l33
  br label %bb18
bb18:
  %t46 = load ptr, ptr %l30, !tbaa !29
  %t47 = load ptr, ptr %l31, !tbaa !29
  %t48 = load %"compiler/source:Span", ptr %l33
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotCapture(ptr %v0, ptr %v0, ptr %t46, ptr %t47, %"compiler/source:Span" %t48)
  br label %bb19
bb19:
  %t49 = load ptr, ptr %l4, !tbaa !29
  %t51 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v0, ptr %t49)
  store i32 %t51, ptr %l35
  br label %bb20
bb20:
  %t52 = load i32, ptr %l35, !tbaa !23
  store i32 %t52, ptr %l5, !tbaa !23
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = load i32, ptr %l5, !tbaa !23
  %t57 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t53, i32 %t54)
  store i1 %t57, ptr %l38
  br label %bb21
bb21:
  %t58 = load i1, ptr %l38, !tbaa !21
  %t59 = xor i1 %t58, true
  br i1 %t59, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l40, !tbaa !21
  br label %bb29
bb23:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = load i32, ptr %l5, !tbaa !23
  %t65 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t61, i32 %t62)
  store i1 %t65, ptr %l43
  br label %bb24
bb24:
  %t66 = load i1, ptr %l43, !tbaa !21
  br i1 %t66, label %bb25, label %bb26
bb25:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/check:Checker", ptr %t67, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !29
  %t71 = load i32, ptr %l5, !tbaa !23
  %t74 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eExtends(ptr %v0, ptr %t70, i32 %t71)
  store i1 %t74, ptr %l48
  br label %bb27
bb26:
  store i1 false, ptr %l44, !tbaa !21
  br label %bb28
bb27:
  %t75 = load i1, ptr %l48, !tbaa !21
  %t76 = xor i1 %t75, true
  store i1 %t76, ptr %l44, !tbaa !21
  br label %bb28
bb28:
  %t78 = load i1, ptr %l44, !tbaa !21
  store i1 %t78, ptr %l40, !tbaa !21
  br label %bb29
bb29:
  %t79 = load i1, ptr %l40, !tbaa !21
  br i1 %t79, label %bb30, label %bb31
bb30:
  %t80 = load i32, ptr %l5, !tbaa !23
  %t81 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t84 = icmp ne i32 %t80, %t81
  br i1 %t84, label %bb32, label %bb33
bb31:
  br label %bb44
bb32:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t87 = load %"compiler/source:Span", ptr %l1
  %t88 = load ptr, ptr %l4, !tbaa !29
  %t89 = load i32, ptr %l5, !tbaa !23
  %t90 = load i1, ptr %l3, !tbaa !21
  %t96 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estepMethod(ptr %v0, ptr %t86, %"compiler/source:Span" %t87, ptr %t88, i32 %t89, i1 %t90)
  store i1 %t96, ptr %l59
  br label %bb34
bb33:
  store i1 false, ptr %l53, !tbaa !21
  br label %bb35
bb34:
  %t97 = load i1, ptr %l59, !tbaa !21
  %t98 = xor i1 %t97, true
  store i1 %t98, ptr %l53, !tbaa !21
  br label %bb35
bb35:
  %t100 = load i1, ptr %l53, !tbaa !21
  br i1 %t100, label %bb36, label %bb37
bb36:
  store %olang.scope zeroinitializer, ptr %s4
  %t101 = load ptr, ptr %l0, !tbaa !29
  store ptr %t101, ptr %l61, !tbaa !29
  %t102 = load ptr, ptr %l0, !tbaa !29
  store ptr %t102, ptr %l62, !tbaa !29
  %t103 = load ptr, ptr %l2, !tbaa !29
  %t105 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t103)
  store %"compiler/source:Span" %t105, ptr %l64
  br label %bb38
bb37:
  br label %bb43
bb38:
  %t106 = load ptr, ptr %l62, !tbaa !29
  %t107 = load %"compiler/source:Span", ptr %l64
  %t108 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopAfter(ptr %v0, ptr %t106, %"compiler/source:Span" %t107, i64 2)
  store %"compiler/source:Span" %t108, ptr %l65
  br label %bb39
bb39:
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t110 = load i32, ptr %l5, !tbaa !23
  %t113 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s4, ptr %t109, i32 %t110)
  store { i64, ptr } %t113, ptr %l68
  br label %bb40
bb40:
  %t114 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t115 = extractvalue { i64, ptr } %t114, 0
  %t116 = extractvalue { i64, ptr } %t114, 1
  %t117 = mul i64 %t115, 1
  %t118 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t117)
  call void @llvm.memcpy.p0.p0.i64(ptr %t118, ptr %t116, i64 %t117, i1 false)
  %t119 = insertvalue { i64, ptr } undef, i64 %t115, 0
  %t120 = insertvalue { i64, ptr } %t119, ptr %t118, 1
  %t122 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eStepNotNumber(ptr %s4, ptr %s4, { i64, ptr } %t120)
  store %"compiler/msgs:Msg" %t122, ptr %l70
  br label %bb41
bb41:
  %t123 = load ptr, ptr %l61, !tbaa !29
  %t124 = load %"compiler/source:Span", ptr %l65
  %t125 = load %"compiler/msgs:Msg", ptr %l70
  %t126 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s4, ptr %t123, %"compiler/source:Span" %t124, %"compiler/msgs:Msg" %t125)
  store i64 %t126, ptr %l71
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s4)
  br label %bb43
bb43:
  br label %ret
bb44:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t128 = load %"compiler/source:Span", ptr %l1
  %t129 = load %"compiler/source:Span", ptr %l1
  %t130 = load i32, ptr %l5, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t131
  %t132 = getelementptr { i64, [4 x i64] }, ptr %t131, i32 0, i32 0
  store i64 7, ptr %t132
  %t134 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t129, 0
  %t136 = insertvalue { %"compiler/source:Span", i32 } %t134, i32 %t130, 1
  %t137 = getelementptr { i64, [4 x i64] }, ptr %t131, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t136, ptr %t137
  %t138 = load { i64, [4 x i64] }, ptr %t131
  %t140 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t138, ptr %t140
  %t144 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t127, %"compiler/source:Span" %t128, ptr %t140)
  store ptr %t144, ptr %l78
  br label %bb45
bb45:
  %t145 = load ptr, ptr %l78, !tbaa !29
  store ptr %t145, ptr %l6, !tbaa !29
  %t146 = load ptr, ptr %l0, !tbaa !29
  store ptr %t146, ptr %l79, !tbaa !29
  %t147 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t147, ptr %l80
  %t148 = load i32, ptr %l5, !tbaa !23
  store i32 %t148, ptr %l81, !tbaa !23
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t151 = getelementptr %"compiler/check:Checker", ptr %t149, i32 0, i32 1
  %t152 = load ptr, ptr %t151, !tbaa !29
  %t154 = getelementptr %"compiler/generic:Program", ptr %t152, i32 0, i32 2
  store ptr %t154, ptr %l84, !tbaa !29
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t156 = load i32, ptr %l5, !tbaa !23
  %t159 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t155, i32 %t156)
  store i32 %t159, ptr %l87
  br label %bb46
bb46:
  %t160 = load ptr, ptr %l84, !tbaa !29
  %t161 = load i32, ptr %l87, !tbaa !23
  %t162 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t160, i32 %t161)
  store i1 %t162, ptr %l88
  br label %bb47
bb47:
  %t163 = load i1, ptr %l88, !tbaa !21
  br i1 %t163, label %bb48, label %bb49
bb48:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t165 = load i32, ptr %l5, !tbaa !23
  %t168 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t164, i32 %t165)
  store i32 %t168, ptr %l92
  br label %bb50
bb49:
  store i64 1, ptr %l89, !tbaa !24
  br label %bb52
bb50:
  %t169 = load i32, ptr %l92, !tbaa !23
  %t170 = call i64 @compiler_2fcheck_2efloatBits(i32 %t169, double 0x3ff0000000000000)
  store i64 %t170, ptr %l93
  br label %bb51
bb51:
  %t171 = load i64, ptr %l93, !tbaa !24
  store i64 %t171, ptr %l89, !tbaa !24
  br label %bb52
bb52:
  %t172 = load ptr, ptr %l79, !tbaa !29
  %t173 = load %"compiler/source:Span", ptr %l80
  %t174 = load i32, ptr %l81, !tbaa !23
  %t175 = load i64, ptr %l89, !tbaa !24
  %t176 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t172, %"compiler/source:Span" %t173, i32 %t174, i64 %t175)
  store ptr %t176, ptr %l94
  br label %bb53
bb53:
  %t177 = load ptr, ptr %l94, !tbaa !29
  store ptr %t177, ptr %l7, !tbaa !29
  %t178 = load i1, ptr %l3, !tbaa !21
  br i1 %t178, label %bb54, label %bb55
bb54:
  store i32 3, ptr %l96
  br label %bb56
bb55:
  store i32 4, ptr %l96
  br label %bb56
bb56:
  %t182 = load i32, ptr %l96
  store i32 %t182, ptr %l8
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t185 = getelementptr %"compiler/check:Checker", ptr %t183, i32 0, i32 36
  %t187 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t185)
  store i64 %t187, ptr %l101
  br label %bb57
bb57:
  %t188 = load i64, ptr %l101, !tbaa !24
  store i64 %t188, ptr %l9, !tbaa !24
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t191 = getelementptr %"compiler/check:Checker", ptr %t189, i32 0, i32 36
  %t192 = load ptr, ptr %l6, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t191, ptr %t192)
  br label %bb58
bb58:
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t197 = getelementptr %"compiler/check:Checker", ptr %t195, i32 0, i32 36
  %t198 = load ptr, ptr %l7, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t197, ptr %t198)
  br label %bb59
bb59:
  %t201 = load ptr, ptr %l0, !tbaa !29
  store ptr %t201, ptr %l108, !tbaa !29
  %t202 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t202, ptr %l109
  %t203 = load ptr, ptr %l4, !tbaa !29
  store ptr %t203, ptr %l110, !tbaa !29
  %t204 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t204, ptr %l111
  %t205 = load i32, ptr %l5, !tbaa !23
  store i32 %t205, ptr %l112, !tbaa !23
  %t206 = load i32, ptr %l8
  store i32 %t206, ptr %l113
  store i32 0, ptr %l114
  %t207 = load ptr, ptr %l0, !tbaa !29
  %t209 = getelementptr %"compiler/check:Checker", ptr %t207, i32 0, i32 36
  %t210 = load i64, ptr %l9, !tbaa !24
  %t213 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t209, i64 %t210)
  store { i64, ptr } %t213, ptr %l118
  br label %bb60
bb60:
  store { i64, [5 x i64] } zeroinitializer, ptr %t214
  %t215 = getelementptr { i64, [5 x i64] }, ptr %t214, i32 0, i32 0
  store i64 9, ptr %t215
  %t216 = load %"compiler/source:Span", ptr %l111
  %t217 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } undef, %"compiler/source:Span" %t216, 0
  %t218 = load i32, ptr %l112, !tbaa !23
  %t219 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t217, i32 %t218, 1
  %t220 = load i32, ptr %l113
  %t221 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t219, i32 %t220, 2
  %t222 = load i32, ptr %l114
  %t223 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t221, i32 %t222, 3
  %t224 = load { i64, ptr }, ptr %l118, !tbaa !27
  %t225 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t223, { i64, ptr } %t224, 4
  %t226 = getelementptr { i64, [5 x i64] }, ptr %t214, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t225, ptr %t226
  %t227 = load { i64, [5 x i64] }, ptr %t214
  %t229 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t227, ptr %t229
  store { i64, [3 x i64] } zeroinitializer, ptr %t230
  %t231 = getelementptr { i64, [3 x i64] }, ptr %t230, i32 0, i32 0
  store i64 1, ptr %t231
  %t232 = load %"compiler/source:Span", ptr %l109
  %t233 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t232, 0
  %t234 = load ptr, ptr %l110, !tbaa !29
  %t235 = insertvalue { %"compiler/source:Span", ptr, ptr } %t233, ptr %t234, 1
  %t237 = insertvalue { %"compiler/source:Span", ptr, ptr } %t235, ptr %t229, 2
  %t238 = getelementptr { i64, [3 x i64] }, ptr %t230, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t237, ptr %t238
  %t239 = load { i64, [3 x i64] }, ptr %t230
  %t241 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t239, ptr %t241
  %t242 = load ptr, ptr %l108, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t242, ptr %t241)
  br label %bb61
bb61:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estrBytes(ptr %v0, ptr %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
  store { i64, ptr } %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t7 = call { i64, ptr } @compiler_2fscan_2eLiteralBytes(ptr %v0, ptr %v0, { i64, ptr } %t6)
  store { i64, ptr } %t7, ptr %l5
  br label %bb2
bb2:
  %t8 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t8, 0
  %t10 = extractvalue { i64, ptr } %t8, 1
  %t11 = mul i64 %t9, 1
  %t12 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t10, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ethunkModule(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l12 = alloca ptr
  %l19 = alloca i64
  %l23 = alloca i64
  %l26 = alloca i64
  %l49 = alloca ptr
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 12
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store ptr %t7, ptr %l12
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l12, !tbaa !29
  %t10 = getelementptr %"compiler/typed:Body", ptr %t8, i32 0, i32 3
  %t11 = load i64, ptr %t10, !tbaa !24
  store i64 %t11, ptr %l2, !tbaa !24
  store i64 0, ptr %l3, !tbaa !24
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/check:Checker", ptr %t13, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t18 = getelementptr %"compiler/generic:Program", ptr %t16, i32 0, i32 0
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = getelementptr %"compiler/load:Loader", ptr %t19, i32 0, i32 5
  %t23 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %t21)
  store i64 %t23, ptr %l19
  br label %bb2
bb2:
  %t24 = load i64, ptr %l19, !tbaa !24
  store i64 %t24, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t25 = load i64, ptr %l4, !tbaa !24
  %t26 = load i64, ptr %l3, !tbaa !24
  %t29 = icmp sgt i64 %t25, %t26
  br i1 %t29, label %bb3, label %bb4
bb3:
  %t31 = load i64, ptr %l5, !tbaa !24
  %t33 = icmp sgt i64 %t31, 0
  br i1 %t33, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb8
bb5:
  %t35 = load i64, ptr %l4, !tbaa !24
  %t36 = load i64, ptr %l3, !tbaa !24
  %t39 = sub i64 %t35, %t36
  %t40 = load i64, ptr %l5, !tbaa !24
  %t43 = add i64 %t39, %t40
  %t45 = sub i64 %t43, 1
  %t46 = load i64, ptr %l5, !tbaa !24
  %t49 = sdiv i64 %t45, %t46
  store i64 %t49, ptr %l26, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l26, !tbaa !24
  br label %bb7
bb7:
  %t51 = load i64, ptr %l26, !tbaa !24
  store i64 %t51, ptr %l23, !tbaa !24
  br label %bb8
bb8:
  %t52 = load i64, ptr %l23, !tbaa !24
  store i64 %t52, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb9
bb9:
  %t53 = load i64, ptr %l7, !tbaa !24
  %t54 = load i64, ptr %l6, !tbaa !24
  %t57 = icmp slt i64 %t53, %t54
  %t59 = xor i1 %t57, true
  br i1 %t59, label %bb10, label %bb11
bb10:
  br label %bb18
bb11:
  br label %bb12
bb12:
  %t61 = load i64, ptr %l3, !tbaa !24
  %t62 = load i64, ptr %l7, !tbaa !24
  %t63 = load i64, ptr %l5, !tbaa !24
  %t66 = mul i64 %t62, %t63
  %t69 = add i64 %t61, %t66
  store i64 %t69, ptr %l8, !tbaa !24
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/check:Checker", ptr %t71, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !29
  %t76 = getelementptr %"compiler/generic:Program", ptr %t74, i32 0, i32 0
  %t77 = load ptr, ptr %t76, !tbaa !29
  %t79 = getelementptr %"compiler/load:Loader", ptr %t77, i32 0, i32 5
  %t80 = load i64, ptr %l8, !tbaa !24
  %t83 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t79, i64 %t80)
  store ptr %t83, ptr %l49
  br label %bb13
bb13:
  %t84 = load ptr, ptr %l49, !tbaa !29
  %t86 = getelementptr %"compiler/load:Module", ptr %t84, i32 0, i32 4
  %t87 = load i64, ptr %t86, !tbaa !24
  %t88 = load i64, ptr %l2, !tbaa !24
  %t91 = icmp eq i64 %t87, %t88
  br i1 %t91, label %bb14, label %bb15
bb14:
  %t93 = load i64, ptr %l8, !tbaa !24
  store i64 %t93, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  br label %bb17
bb17:
  %t95 = load i64, ptr %l7, !tbaa !24
  %t97 = add i64 %t95, 1
  store i64 %t97, ptr %l7, !tbaa !24
  br label %bb9
bb18:
  store i64 0, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etopSetIf(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i64 %a1, ptr %a2, ptr %a3, i1 %a4, i1 %a5, i64 %a6, i64 %a7, ptr %a8) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l5 = alloca i1
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca i32
  %l15 = alloca ptr
  %l16 = alloca %"compiler/source:Span"
  %l18 = alloca i32
  %l23 = alloca ptr
  %l24 = alloca i64
  %l31 = alloca { i64, ptr }
  %l33 = alloca i1
  %l42 = alloca ptr
  %l43 = alloca i64
  %l44 = alloca ptr
  %l60 = alloca ptr
  %l61 = alloca i64
  %l68 = alloca { i64, ptr }
  %l70 = alloca i1
  %l80 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l84 = alloca i64
  %l91 = alloca ptr
  %l99 = alloca i64
  %l101 = alloca i64
  %l106 = alloca i32
  %l112 = alloca i1
  %l113 = alloca ptr
  %l114 = alloca i64
  %l120 = alloca %"compiler/source:Span"
  %l123 = alloca { i64, ptr }
  %l124 = alloca i1
  %l130 = alloca %"compiler/source:Span"
  %l131 = alloca ptr
  %l137 = alloca { i64, [3 x i64] }
  %l140 = alloca { i64, ptr }
  %l141 = alloca %"compiler/msgs:Msg"
  %l142 = alloca i64
  %l155 = alloca ptr
  %l158 = alloca i32
  %l160 = alloca ptr
  %l164 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l165 = alloca i32
  %l166 = alloca i32
  %l171 = alloca i1
  %l175 = alloca i1
  %s0 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %t248 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  store i1 %a5, ptr %l5
  store i64 %a6, ptr %l6
  store i64 %a7, ptr %l7
  store ptr %a8, ptr %l8
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l3, !tbaa !29
  %t3 = getelementptr %"compiler/ast:TopIf", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  %t8 = xor i1 %t6, true
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l23, !tbaa !29
  %t11 = load i64, ptr %l1, !tbaa !24
  store i64 %t11, ptr %l24, !tbaa !24
  %t12 = load ptr, ptr %l3, !tbaa !29
  %t14 = getelementptr %"compiler/ast:TopIf", ptr %t12, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = icmp eq ptr %t15, null
  br i1 %t17, label %bb3, label %bb4
bb2:
  br label %bb10
bb3:
  call void @__olang_check_failed(ptr @olang_loc_6b4c91049558e776_f5788538a01eee7a)
  unreachable
bb4:
  br label %bb5
bb5:
  %t19 = load ptr, ptr %l3, !tbaa !29
  %t21 = getelementptr %"compiler/ast:TopIf", ptr %t19, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t25 = getelementptr %"compiler/ast:TopBranch", ptr %t22, i32 0, i32 1
  %t26 = load { i64, ptr }, ptr %t25, !tbaa !27
  store { i64, ptr } %t26, ptr %l31, !tbaa !27
  %t27 = load i1, ptr %l5, !tbaa !21
  br i1 %t27, label %bb6, label %bb7
bb6:
  %t29 = load i64, ptr %l6, !tbaa !24
  %t30 = load i64, ptr %l7, !tbaa !24
  %t33 = icmp eq i64 %t29, %t30
  store i1 %t33, ptr %l33, !tbaa !21
  br label %bb8
bb7:
  store i1 false, ptr %l33, !tbaa !21
  br label %bb8
bb8:
  %t35 = load ptr, ptr %l8, !tbaa !29
  %t36 = load ptr, ptr %l23, !tbaa !29
  %t37 = load i64, ptr %l24, !tbaa !24
  %t38 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t39 = load i1, ptr %l33, !tbaa !21
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etopSetDecls(ptr %v0, ptr %v2, ptr %v3, ptr %t36, i64 %t37, { i64, ptr } %t38, i1 true, i1 %t39, ptr %t35)
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t41 = load ptr, ptr %l3, !tbaa !29
  %t43 = getelementptr %"compiler/ast:TopIf", ptr %t41, i32 0, i32 2
  %t44 = load ptr, ptr %t43, !tbaa !29
  %t46 = icmp eq ptr %t44, null
  %t48 = xor i1 %t46, true
  br i1 %t48, label %bb11, label %bb12
bb11:
  %t50 = load ptr, ptr %l0, !tbaa !29
  store ptr %t50, ptr %l42, !tbaa !29
  %t51 = load i64, ptr %l1, !tbaa !24
  store i64 %t51, ptr %l43, !tbaa !24
  %t52 = load ptr, ptr %l2, !tbaa !29
  store ptr %t52, ptr %l44, !tbaa !29
  %t53 = load ptr, ptr %l3, !tbaa !29
  %t55 = getelementptr %"compiler/ast:TopIf", ptr %t53, i32 0, i32 2
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t58 = icmp eq ptr %t56, null
  br i1 %t58, label %bb13, label %bb14
bb12:
  %t60 = load ptr, ptr %l3, !tbaa !29
  %t62 = getelementptr %"compiler/ast:TopIf", ptr %t60, i32 0, i32 3
  %t63 = load ptr, ptr %t62, !tbaa !29
  %t65 = icmp eq ptr %t63, null
  %t67 = xor i1 %t65, true
  br i1 %t67, label %bb17, label %bb18
bb13:
  call void @__olang_check_failed(ptr @olang_loc_812bc6763f016bdd_ce6f0e3f96c00d01)
  unreachable
bb14:
  br label %bb15
bb15:
  %t69 = load ptr, ptr %l3, !tbaa !29
  %t71 = getelementptr %"compiler/ast:TopIf", ptr %t69, i32 0, i32 2
  %t72 = load ptr, ptr %t71, !tbaa !29
  %t74 = load i1, ptr %l5, !tbaa !21
  %t75 = load i64, ptr %l6, !tbaa !24
  %t76 = load i64, ptr %l7, !tbaa !24
  %t78 = add i64 %t76, 1
  %t79 = load ptr, ptr %l8, !tbaa !29
  %t80 = load ptr, ptr %l42, !tbaa !29
  %t81 = load i64, ptr %l43, !tbaa !24
  %t82 = load ptr, ptr %l44, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etopSetIf(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t80, i64 %t81, ptr %t82, ptr %t72, i1 %a4, i1 %t74, i64 %t75, i64 %t78, ptr %t79)
  br label %bb16
bb16:
  br label %bb27
bb17:
  %t89 = load ptr, ptr %l0, !tbaa !29
  store ptr %t89, ptr %l60, !tbaa !29
  %t90 = load i64, ptr %l1, !tbaa !24
  store i64 %t90, ptr %l61, !tbaa !24
  %t91 = load ptr, ptr %l3, !tbaa !29
  %t93 = getelementptr %"compiler/ast:TopIf", ptr %t91, i32 0, i32 3
  %t94 = load ptr, ptr %t93, !tbaa !29
  %t96 = icmp eq ptr %t94, null
  br i1 %t96, label %bb19, label %bb20
bb18:
  br label %bb26
bb19:
  call void @__olang_check_failed(ptr @olang_loc_8d628e20c33cf608_43e2c14925cb83cc)
  unreachable
bb20:
  br label %bb21
bb21:
  %t98 = load ptr, ptr %l3, !tbaa !29
  %t100 = getelementptr %"compiler/ast:TopIf", ptr %t98, i32 0, i32 3
  %t101 = load ptr, ptr %t100, !tbaa !29
  %t104 = getelementptr %"compiler/ast:TopBranch", ptr %t101, i32 0, i32 1
  %t105 = load { i64, ptr }, ptr %t104, !tbaa !27
  store { i64, ptr } %t105, ptr %l68, !tbaa !27
  %t106 = load i1, ptr %l5, !tbaa !21
  br i1 %t106, label %bb22, label %bb23
bb22:
  %t108 = load i64, ptr %l6, !tbaa !24
  %t109 = load i64, ptr %l7, !tbaa !24
  %t111 = add i64 %t109, 1
  %t114 = icmp eq i64 %t108, %t111
  store i1 %t114, ptr %l70, !tbaa !21
  br label %bb24
bb23:
  store i1 false, ptr %l70, !tbaa !21
  br label %bb24
bb24:
  %t116 = load ptr, ptr %l8, !tbaa !29
  %t117 = load ptr, ptr %l60, !tbaa !29
  %t118 = load i64, ptr %l61, !tbaa !24
  %t119 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t120 = load i1, ptr %l70, !tbaa !21
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etopSetDecls(ptr %v0, ptr %v2, ptr %v3, ptr %t117, i64 %t118, { i64, ptr } %t119, i1 true, i1 %t120, ptr %t116)
  br label %bb25
bb25:
  br label %bb26
bb26:
  br label %bb27
bb27:
  %t122 = load ptr, ptr %l2, !tbaa !29
  %t123 = load ptr, ptr %l3, !tbaa !29
  %t126 = icmp eq ptr %t122, %t123
  %t128 = xor i1 %t126, true
  br i1 %t128, label %bb28, label %bb29
bb28:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb29:
  br label %bb30
bb30:
  %t130 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t130, ptr %l80
  br label %bb31
bb31:
  %t131 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l80
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t131, ptr %l9
  %t132 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fcheck_2echainNames(ptr %v1, ptr %s0, ptr %t132, ptr %l9)
  br label %bb32
bb32:
  %t136 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %s0, ptr %l9)
  store i64 %t136, ptr %l84
  br label %bb33
bb33:
  %t137 = load i64, ptr %l84, !tbaa !24
  %t138 = icmp eq i64 %t137, 0
  br i1 %t138, label %bb34, label %bb35
bb34:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb35:
  br label %bb36
bb36:
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t142 = getelementptr %"compiler/check:Checker", ptr %t140, i32 0, i32 1
  %t143 = load ptr, ptr %t142, !tbaa !29
  %t145 = getelementptr %"compiler/generic:Program", ptr %t143, i32 0, i32 0
  %t146 = load ptr, ptr %t145, !tbaa !29
  %t148 = getelementptr %"compiler/load:Loader", ptr %t146, i32 0, i32 5
  %t149 = load i64, ptr %l1, !tbaa !24
  %t152 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t148, i64 %t149)
  store ptr %t152, ptr %l91
  br label %bb37
bb37:
  %t153 = load ptr, ptr %l91, !tbaa !29
  %t155 = getelementptr %"compiler/load:Module", ptr %t153, i32 0, i32 4
  %t156 = load i64, ptr %t155, !tbaa !24
  store i64 %t156, ptr %l10, !tbaa !24
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t160 = getelementptr %"compiler/check:Checker", ptr %t158, i32 0, i32 1
  %t161 = load ptr, ptr %t160, !tbaa !29
  %t163 = getelementptr %"compiler/generic:Program", ptr %t161, i32 0, i32 0
  %t164 = load ptr, ptr %t163, !tbaa !29
  %t166 = getelementptr %"compiler/load:Loader", ptr %t164, i32 0, i32 4
  %t167 = load ptr, ptr %t166, !tbaa !29
  store ptr %t167, ptr %l11, !tbaa !29
  store ptr %l9, ptr %l12, !tbaa !29
  store i64 0, ptr %l13, !tbaa !24
  br label %bb38
bb38:
  store %olang.scope zeroinitializer, ptr %s8
  %t170 = load i64, ptr %l13, !tbaa !24
  store i64 %t170, ptr %l99, !tbaa !24
  %t171 = load ptr, ptr %l12, !tbaa !29
  %t173 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %s0, ptr %t171)
  store i64 %t173, ptr %l101
  br label %bb39
bb39:
  %t174 = load i64, ptr %l99, !tbaa !24
  %t175 = load i64, ptr %l101, !tbaa !24
  %t176 = icmp slt i64 %t174, %t175
  %t178 = xor i1 %t176, true
  br i1 %t178, label %bb40, label %bb41
bb40:
  call void @__olang_scope_close(ptr %s8)
  br label %bb90
bb41:
  br label %bb42
bb42:
  %t180 = load ptr, ptr %l12, !tbaa !29
  %t181 = load i64, ptr %l13, !tbaa !24
  %t184 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eAt_3ccompiler_2fsource_3aNameId_3e(ptr %s0, ptr %t180, i64 %t181)
  store i32 %t184, ptr %l106
  br label %bb43
bb43:
  %t185 = load i32, ptr %l106, !tbaa !23
  store i32 %t185, ptr %l14, !tbaa !23
  %t186 = load ptr, ptr %l2, !tbaa !29
  store ptr %t186, ptr %l15, !tbaa !29
  br label %bb44
bb44:
  %t188 = load ptr, ptr %l15, !tbaa !29
  %t190 = getelementptr %"compiler/ast:TopIf", ptr %t188, i32 0, i32 0
  %t191 = load ptr, ptr %t190, !tbaa !29
  %t193 = icmp eq ptr %t191, null
  %t195 = xor i1 %t193, true
  br i1 %t195, label %bb45, label %bb46
bb45:
  %t197 = load ptr, ptr %l0, !tbaa !29
  store ptr %t197, ptr %l113, !tbaa !29
  %t198 = load i64, ptr %l10, !tbaa !24
  store i64 %t198, ptr %l114, !tbaa !24
  %t199 = load ptr, ptr %l15, !tbaa !29
  %t201 = getelementptr %"compiler/ast:TopIf", ptr %t199, i32 0, i32 0
  %t202 = load ptr, ptr %t201, !tbaa !29
  %t204 = icmp eq ptr %t202, null
  br i1 %t204, label %bb47, label %bb48
bb46:
  store i1 false, ptr %l112, !tbaa !21
  br label %bb53
bb47:
  call void @__olang_check_failed(ptr @olang_loc_90c8334c62802427_4400025bac92e03b)
  unreachable
bb48:
  br label %bb49
bb49:
  %t206 = load ptr, ptr %l15, !tbaa !29
  %t208 = getelementptr %"compiler/ast:TopIf", ptr %t206, i32 0, i32 0
  %t209 = load ptr, ptr %t208, !tbaa !29
  %t211 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t209)
  store %"compiler/source:Span" %t211, ptr %l120
  br label %bb50
bb50:
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t213 = load i32, ptr %l14, !tbaa !23
  %t216 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t212, i32 %t213)
  store { i64, ptr } %t216, ptr %l123
  br label %bb51
bb51:
  %t217 = load ptr, ptr %l113, !tbaa !29
  %t218 = load i64, ptr %l114, !tbaa !24
  %t219 = load %"compiler/source:Span", ptr %l120
  %t220 = load { i64, ptr }, ptr %l123, !tbaa !27
  %t221 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econdReads(ptr %v0, ptr %v0, ptr %t217, i64 %t218, %"compiler/source:Span" %t219, { i64, ptr } %t220)
  store i1 %t221, ptr %l124
  br label %bb52
bb52:
  %t222 = load i1, ptr %l124, !tbaa !21
  store i1 %t222, ptr %l112, !tbaa !21
  br label %bb53
bb53:
  %t223 = load i1, ptr %l112, !tbaa !21
  br i1 %t223, label %bb54, label %bb55
bb54:
  store %olang.scope zeroinitializer, ptr %s10
  %t224 = load ptr, ptr %l15, !tbaa !29
  %t226 = getelementptr %"compiler/ast:TopIf", ptr %t224, i32 0, i32 0
  %t227 = load ptr, ptr %t226, !tbaa !29
  %t229 = icmp eq ptr %t227, null
  br i1 %t229, label %bb56, label %bb57
bb55:
  br label %bb63
bb56:
  call void @__olang_check_failed(ptr @olang_loc_39ed54cf65861a3a_83e11e15934e9cb6)
  unreachable
bb57:
  br label %bb58
bb58:
  %t231 = load ptr, ptr %l15, !tbaa !29
  %t233 = getelementptr %"compiler/ast:TopIf", ptr %t231, i32 0, i32 0
  %t234 = load ptr, ptr %t233, !tbaa !29
  %t236 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t234)
  store %"compiler/source:Span" %t236, ptr %l130
  br label %bb59
bb59:
  %t237 = load %"compiler/source:Span", ptr %l130
  store %"compiler/source:Span" %t237, ptr %l16
  %t238 = load ptr, ptr %l11, !tbaa !29
  store ptr %t238, ptr %l131, !tbaa !29
  %t239 = load i64, ptr %l10, !tbaa !24
  %t240 = getelementptr %"compiler/source:Span", ptr %l16, i32 0, i32 0
  %t241 = load i32, ptr %t240, !tbaa !23
  %t243 = sext i32 %t241 to i64
  %t244 = getelementptr %"compiler/source:Span", ptr %l16, i32 0, i32 1
  %t245 = load i32, ptr %t244, !tbaa !23
  %t247 = sext i32 %t245 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t248
  %t249 = getelementptr { i64, [3 x i64] }, ptr %t248, i32 0, i32 0
  store i64 3, ptr %t249
  %t251 = insertvalue { i64, i64, i64 } undef, i64 %t239, 0
  %t253 = insertvalue { i64, i64, i64 } %t251, i64 %t243, 1
  %t255 = insertvalue { i64, i64, i64 } %t253, i64 %t247, 2
  %t256 = getelementptr { i64, [3 x i64] }, ptr %t248, i32 0, i32 1
  store { i64, i64, i64 } %t255, ptr %t256
  %t257 = load { i64, [3 x i64] }, ptr %t248
  store { i64, [3 x i64] } %t257, ptr %l137
  %t258 = load ptr, ptr %l0, !tbaa !29
  %t259 = load i32, ptr %l14, !tbaa !23
  %t262 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t258, i32 %t259)
  store { i64, ptr } %t262, ptr %l140
  br label %bb60
bb60:
  %t263 = load { i64, ptr }, ptr %l140, !tbaa !27
  %t264 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTopSetCondReads(ptr %v0, ptr %s10, { i64, ptr } %t263)
  store %"compiler/msgs:Msg" %t264, ptr %l141
  br label %bb61
bb61:
  %t265 = load ptr, ptr %l131, !tbaa !29
  %t266 = load { i64, [3 x i64] }, ptr %l137
  %t267 = load %"compiler/msgs:Msg", ptr %l141
  %t268 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s10, ptr %t265, { i64, [3 x i64] } %t266, %"compiler/msgs:Msg" %t267)
  store i64 %t268, ptr %l142
  br label %bb62
bb62:
  call void @__olang_scope_close(ptr %s10)
  br label %bb63
bb63:
  %t269 = load ptr, ptr %l15, !tbaa !29
  %t271 = getelementptr %"compiler/ast:TopIf", ptr %t269, i32 0, i32 2
  %t272 = load ptr, ptr %t271, !tbaa !29
  %t274 = icmp eq ptr %t272, null
  br i1 %t274, label %bb64, label %bb65
bb64:
  br label %bb71
bb65:
  br label %bb66
bb66:
  %t276 = load ptr, ptr %l15, !tbaa !29
  %t278 = getelementptr %"compiler/ast:TopIf", ptr %t276, i32 0, i32 2
  %t279 = load ptr, ptr %t278, !tbaa !29
  %t281 = icmp eq ptr %t279, null
  br i1 %t281, label %bb67, label %bb68
bb67:
  call void @__olang_check_failed(ptr @olang_loc_39e926dc5bd50dc1_491eed70903c4c1d)
  unreachable
bb68:
  br label %bb69
bb69:
  %t283 = load ptr, ptr %l15, !tbaa !29
  %t285 = getelementptr %"compiler/ast:TopIf", ptr %t283, i32 0, i32 2
  %t286 = load ptr, ptr %t285, !tbaa !29
  store ptr %t286, ptr %l15, !tbaa !29
  br label %bb70
bb70:
  br label %bb44
bb71:
  %t288 = load ptr, ptr %l0, !tbaa !29
  %t290 = getelementptr %"compiler/check:Checker", ptr %t288, i32 0, i32 1
  %t291 = load ptr, ptr %t290, !tbaa !29
  %t292 = load i64, ptr %l1, !tbaa !24
  %t293 = load i32, ptr %l14, !tbaa !23
  %t297 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eGlobalDecl(ptr %v0, ptr %t291, i64 %t292, i32 %t293)
  store ptr %t297, ptr %l155
  br label %bb72
bb72:
  %t298 = load ptr, ptr %l155, !tbaa !29
  %t301 = icmp eq ptr %t298, null
  br i1 %t301, label %bb73, label %bb74
bb73:
  call void @__olang_scope_close(ptr %s8)
  br label %bb89
bb74:
  br label %bb75
bb75:
  %t303 = load ptr, ptr %l0, !tbaa !29
  %t305 = getelementptr %"compiler/check:Checker", ptr %t303, i32 0, i32 28
  store ptr %t305, ptr %l160, !tbaa !29
  %t306 = load i64, ptr %l1, !tbaa !24
  %t307 = load i32, ptr %l14, !tbaa !23
  %t309 = sext i32 %t307 to i64
  %t312 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s8, i64 %t306, i64 %t309)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t312, ptr %l164
  br label %bb76
bb76:
  %t313 = load ptr, ptr %l160, !tbaa !29
  %t314 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l164
  %t315 = call { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H3cc70d507a7fc767d013b59b12ee0a99(ptr %v0, ptr %t313, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t314)
  %t316 = extractvalue { i32, i32 } %t315, 1
  %t317 = extractvalue { i32, i32 } %t315, 0
  store i32 %t317, ptr %l166
  %t318 = icmp ne i32 %t317, 0
  br i1 %t318, label %bb78, label %ok.319, !prof !99
ok.319:
  store i32 %t316, ptr %l165
  br label %bb77
bb77:
  %t320 = load i32, ptr %l165, !tbaa !23
  store i32 %t320, ptr %l158, !tbaa !23
  br label %bb80
bb78:
  br label %bb79
bb79:
  call void @__olang_ert_req_clear()
  %t321 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t321, ptr %l158, !tbaa !23
  br label %bb80
bb80:
  %t323 = load i32, ptr %l158, !tbaa !23
  store i32 %t323, ptr %l18, !tbaa !23
  %t324 = load i32, ptr %l18, !tbaa !23
  %t325 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t328 = icmp eq i32 %t324, %t325
  br i1 %t328, label %bb81, label %bb82
bb81:
  store i1 true, ptr %l171, !tbaa !21
  br label %bb84
bb82:
  %t330 = load ptr, ptr %l0, !tbaa !29
  %t331 = load i64, ptr %l1, !tbaa !24
  %t332 = load i32, ptr %l18, !tbaa !23
  %t336 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehasZero(ptr %v0, ptr %t330, i64 %t331, i32 %t332)
  store i1 %t336, ptr %l175
  br label %bb83
bb83:
  %t337 = load i1, ptr %l175, !tbaa !21
  store i1 %t337, ptr %l171, !tbaa !21
  br label %bb84
bb84:
  %t338 = load i1, ptr %l171, !tbaa !21
  br i1 %t338, label %bb85, label %bb86
bb85:
  call void @__olang_scope_close(ptr %s8)
  br label %bb89
bb86:
  br label %bb87
bb87:
  %t339 = load ptr, ptr %l0, !tbaa !29
  %t340 = load i64, ptr %l10, !tbaa !24
  %t341 = load ptr, ptr %l2, !tbaa !29
  %t342 = load i32, ptr %l14, !tbaa !23
  %t343 = load i32, ptr %l18, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebranchesAssign(ptr %v0, ptr %v1, ptr %t339, i64 %t340, ptr %t341, i32 %t342, i32 %t343)
  br label %bb88
bb88:
  call void @__olang_scope_close(ptr %s8)
  br label %bb89
bb89:
  %t349 = load i64, ptr %l13, !tbaa !24
  %t351 = add i64 %t349, 1
  store i64 %t351, ptr %l13, !tbaa !24
  br label %bb38
bb90:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etwinCall(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, { i64, ptr } %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca %"compiler/generic:Binding"
  %lp12 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca ptr
  %l20 = alloca %"compiler/check:litv"
  %l21 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l29 = alloca i32
  %l30 = alloca i32
  %l31 = alloca i64
  %l32 = alloca i32
  %l37 = alloca i32
  %l43 = alloca ptr
  %l48 = alloca i32
  %l52 = alloca { i64, ptr }
  %l60 = alloca ptr
  %l63 = alloca { i64, ptr }
  %l67 = alloca i64
  %l71 = alloca i64
  %l74 = alloca ptr
  %l79 = alloca i32
  %l80 = alloca { i64, ptr }
  %l83 = alloca %"compiler/generic:Binding"
  %l84 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l90 = alloca i64
  %l93 = alloca i64
  %l112 = alloca { i64, ptr }
  %l116 = alloca %"compiler/check:litv"
  %l118 = alloca i1
  %l120 = alloca { i64, ptr }
  %l123 = alloca i1
  %l125 = alloca i1
  %l128 = alloca { i64, ptr }
  %l131 = alloca i1
  %l136 = alloca ptr
  %l137 = alloca { i64, ptr }
  %l139 = alloca i32
  %l141 = alloca i32
  %l145 = alloca i32
  %l147 = alloca i32
  %l149 = alloca { i64, ptr }
  %l152 = alloca ptr
  %l153 = alloca i1
  %l156 = alloca ptr
  %l157 = alloca i1
  %l161 = alloca { i64, ptr }
  %l166 = alloca ptr
  %l171 = alloca i1
  %l176 = alloca i1
  %l179 = alloca i32
  %l182 = alloca i1
  %l185 = alloca i32
  %l188 = alloca ptr
  %l189 = alloca { i64, ptr }
  %l191 = alloca i32
  %l194 = alloca i32
  %l212 = alloca i64
  %l215 = alloca i64
  %l233 = alloca { i64, ptr }
  %l238 = alloca ptr
  %l239 = alloca %"compiler/source:Span"
  %l242 = alloca { i64, ptr }
  %l244 = alloca %"compiler/msgs:Msg"
  %l245 = alloca i64
  %l248 = alloca ptr
  %l255 = alloca i32
  %l260 = alloca i32
  %l266 = alloca ptr
  %l270 = alloca i64
  %l277 = alloca ptr
  %l278 = alloca %"compiler/source:Span"
  %l279 = alloca %"compiler/source:Span"
  %l280 = alloca i32
  %l285 = alloca ptr
  %l286 = alloca { i64, ptr }
  %l288 = alloca { i64, ptr }
  %l289 = alloca ptr
  %s0 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %rv = alloca ptr
  %t520 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  store i32 %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i32, ptr %l3, !tbaa !23
  %t8 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorSig(ptr %v0, ptr %t4, i32 %t5)
  store i32 %t8, ptr %l37
  br label %bb1
bb1:
  %t9 = load i32, ptr %l37, !tbaa !23
  store i32 %t9, ptr %l5, !tbaa !23
  %t10 = load i32, ptr %l5, !tbaa !23
  %t11 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t14 = icmp eq i32 %t10, %t11
  br i1 %t14, label %bb2, label %bb3
bb2:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load %"compiler/source:Span", ptr %l1
  %t20 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t16, %"compiler/source:Span" %t17)
  store ptr %t20, ptr %l43
  br label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_scope_close(ptr %s0)
  %t21 = load ptr, ptr %l43, !tbaa !29
  store ptr %t21, ptr %rv
  br label %ret
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/check:Checker", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/generic:Program", ptr %t25, i32 0, i32 2
  %t28 = load i32, ptr %l3, !tbaa !23
  %t31 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t27, i32 %t28)
  store i32 %t31, ptr %l48
  br label %bb6
bb6:
  %t32 = load i32, ptr %l48, !tbaa !23
  store i32 %t32, ptr %l6, !tbaa !23
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load i32, ptr %l6, !tbaa !23
  %t35 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t39 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorNamed(ptr %v0, ptr %v1, ptr %t33, i32 %t34, { i64, ptr } %t35)
  store { i64, ptr } %t39, ptr %l52
  br label %bb7
bb7:
  %t40 = load { i64, ptr }, ptr %l52, !tbaa !27
  store { i64, ptr } %t40, ptr %l4, !tbaa !27
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/check:Checker", ptr %t41, i32 0, i32 122
  %t44 = load i1, ptr %t43, !tbaa !21
  br i1 %t44, label %bb8, label %bb9
bb8:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/check:Checker", ptr %t46, i32 0, i32 122
  store i1 false, ptr %t48, !tbaa !21
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load { i64, ptr }, ptr %l4, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v1, ptr %t49, { i64, ptr } %t50)
  br label %bb10
bb9:
  br label %bb12
bb10:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = load %"compiler/source:Span", ptr %l1
  %t57 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t53, %"compiler/source:Span" %t54)
  store ptr %t57, ptr %l60
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s0)
  %t58 = load ptr, ptr %l60, !tbaa !29
  store ptr %t58, ptr %rv
  br label %ret
bb12:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/check:Checker", ptr %t59, i32 0, i32 123
  %t63 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %v0, ptr %s0, ptr %t61)
  store { i64, ptr } %t63, ptr %l63
  br label %bb13
bb13:
  %t64 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t64, ptr %l7, !tbaa !27
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/check:Checker", ptr %t65, i32 0, i32 123
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t67)
  br label %bb14
bb14:
  %t69 = load i32, ptr %l6, !tbaa !23
  %t71 = call i64 @compiler_2fgeneric_2eCtorOwner(i32 %t69)
  store i64 %t71, ptr %l67
  br label %bb15
bb15:
  %t72 = load i64, ptr %l67, !tbaa !24
  store i64 %t72, ptr %l8, !tbaa !24
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/check:Checker", ptr %t73, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !29
  %t77 = load i32, ptr %l6, !tbaa !23
  %t80 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorVars(ptr %v0, ptr %t76, i32 %t77)
  store i64 %t80, ptr %l71
  br label %bb16
bb16:
  %t81 = load i64, ptr %l71, !tbaa !24
  store i64 %t81, ptr %l9, !tbaa !24
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/check:Checker", ptr %t82, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !29
  %t87 = getelementptr %"compiler/generic:Program", ptr %t85, i32 0, i32 2
  store ptr %t87, ptr %l74, !tbaa !29
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/check:Checker", ptr %t88, i32 0, i32 1
  %t91 = load ptr, ptr %t90, !tbaa !29
  %t93 = getelementptr %"compiler/generic:Program", ptr %t91, i32 0, i32 2
  %t94 = load i32, ptr %l5, !tbaa !23
  %t97 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t93, i32 %t94)
  store i32 %t97, ptr %l79
  br label %bb17
bb17:
  %t98 = load ptr, ptr %l74, !tbaa !29
  %t99 = load i32, ptr %l79, !tbaa !23
  %t100 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t98, i32 %t99)
  store { i64, ptr } %t100, ptr %l80
  br label %bb18
bb18:
  %t101 = load { i64, ptr }, ptr %l80, !tbaa !27
  store { i64, ptr } %t101, ptr %l10, !tbaa !27
  %t102 = load i64, ptr %l8, !tbaa !24
  %t103 = load i64, ptr %l9, !tbaa !24
  %t106 = call %"compiler/generic:Binding" @compiler_2fgeneric_3aBinding_2ector(ptr %s0, i64 %t102, i64 %t103)
  store %"compiler/generic:Binding" %t106, ptr %l83
  br label %bb19
bb19:
  %t107 = load %"compiler/generic:Binding", ptr %l83
  store %"compiler/generic:Binding" %t107, ptr %l11
  %t108 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t108, ptr %l84
  br label %bb20
bb20:
  %t109 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 8, i64 8)
  store ptr %t109, ptr %lp12
  %t110 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l84
  %t111 = load ptr, ptr %lp12
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t110, ptr %t111
  store i64 0, ptr %l13, !tbaa !24
  %t112 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t112, 0
  store i64 %t114, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t116 = load i64, ptr %l14, !tbaa !24
  %t117 = load i64, ptr %l13, !tbaa !24
  %t120 = icmp sgt i64 %t116, %t117
  br i1 %t120, label %bb21, label %bb22
bb21:
  %t122 = load i64, ptr %l15, !tbaa !24
  %t124 = icmp sgt i64 %t122, 0
  br i1 %t124, label %bb23, label %bb24
bb22:
  store i64 0, ptr %l90, !tbaa !24
  br label %bb26
bb23:
  %t126 = load i64, ptr %l14, !tbaa !24
  %t127 = load i64, ptr %l13, !tbaa !24
  %t130 = sub i64 %t126, %t127
  %t131 = load i64, ptr %l15, !tbaa !24
  %t134 = add i64 %t130, %t131
  %t136 = sub i64 %t134, 1
  %t137 = load i64, ptr %l15, !tbaa !24
  %t140 = sdiv i64 %t136, %t137
  store i64 %t140, ptr %l93, !tbaa !24
  br label %bb25
bb24:
  store i64 0, ptr %l93, !tbaa !24
  br label %bb25
bb25:
  %t142 = load i64, ptr %l93, !tbaa !24
  store i64 %t142, ptr %l90, !tbaa !24
  br label %bb26
bb26:
  %t143 = load i64, ptr %l90, !tbaa !24
  store i64 %t143, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb27
bb27:
  %t144 = load i64, ptr %l17, !tbaa !24
  %t145 = load i64, ptr %l16, !tbaa !24
  %t148 = icmp slt i64 %t144, %t145
  %t150 = xor i1 %t148, true
  br i1 %t150, label %bb28, label %bb29
bb28:
  br label %bb90
bb29:
  br label %bb30
bb30:
  %t152 = load i64, ptr %l13, !tbaa !24
  %t153 = load i64, ptr %l17, !tbaa !24
  %t154 = load i64, ptr %l15, !tbaa !24
  %t157 = mul i64 %t153, %t154
  %t160 = add i64 %t152, %t157
  store i64 %t160, ptr %l18, !tbaa !24
  store ptr null, ptr %l19, !tbaa !29
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t163 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t163, ptr %l112, !tbaa !27
  %t164 = load i64, ptr %l18, !tbaa !24
  %t166 = getelementptr { i64, ptr }, ptr %l112, i32 0, i32 1
  %t167 = load ptr, ptr %t166, !tbaa !27
  %t168 = getelementptr ptr, ptr %t167, i64 %t164
  %t169 = load ptr, ptr %t168, !tbaa !39
  %t173 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %t162, ptr %t169)
  store %"compiler/check:litv" %t173, ptr %l116
  br label %bb31
bb31:
  %t174 = load %"compiler/check:litv", ptr %l116
  store %"compiler/check:litv" %t174, ptr %l20
  %t175 = getelementptr %"compiler/check:litv", ptr %l20, i32 0, i32 0
  %t176 = load i1, ptr %t175, !tbaa !21
  br i1 %t176, label %bb32, label %bb33
bb32:
  store i1 true, ptr %l118, !tbaa !21
  br label %bb35
bb33:
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t179 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t179, ptr %l120, !tbaa !27
  %t180 = load i64, ptr %l18, !tbaa !24
  %t182 = getelementptr { i64, ptr }, ptr %l120, i32 0, i32 1
  %t183 = load ptr, ptr %t182, !tbaa !27
  %t184 = getelementptr ptr, ptr %t183, i64 %t180
  %t185 = load ptr, ptr %t184, !tbaa !39
  %t188 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v1, ptr %t178, ptr %t185)
  store i1 %t188, ptr %l123
  br label %bb34
bb34:
  %t189 = load i1, ptr %l123, !tbaa !21
  store i1 %t189, ptr %l118, !tbaa !21
  br label %bb35
bb35:
  %t190 = load i1, ptr %l118, !tbaa !21
  br i1 %t190, label %bb36, label %bb37
bb36:
  %t191 = getelementptr %"compiler/check:litv", ptr %l20, i32 0, i32 0
  %t192 = load i1, ptr %t191, !tbaa !21
  br i1 %t192, label %bb38, label %bb39
bb37:
  %t194 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t194, ptr %l149, !tbaa !27
  %t195 = load i64, ptr %l18, !tbaa !24
  %t197 = getelementptr { i64, ptr }, ptr %l149, i32 0, i32 1
  %t198 = load ptr, ptr %t197, !tbaa !27
  %t199 = getelementptr ptr, ptr %t198, i64 %t195
  %t200 = load ptr, ptr %t199, !tbaa !39
  store ptr %t200, ptr %l22, !tbaa !29
  %t202 = load ptr, ptr %l22, !tbaa !29
  store ptr %t202, ptr %l152, !tbaa !29
  store i1 false, ptr %l153, !tbaa !21
  %t203 = load ptr, ptr %l152, !tbaa !29
  %t204 = icmp ne ptr %t203, null
  br i1 %t204, label %bb51, label %bb52
bb38:
  %t206 = getelementptr %"compiler/check:litv", ptr %l20, i32 0, i32 1
  %t207 = load i1, ptr %t206, !tbaa !21
  store i1 %t207, ptr %l125, !tbaa !21
  br label %bb41
bb39:
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t210 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t210, ptr %l128, !tbaa !27
  %t211 = load i64, ptr %l18, !tbaa !24
  %t213 = getelementptr { i64, ptr }, ptr %l128, i32 0, i32 1
  %t214 = load ptr, ptr %t213, !tbaa !27
  %t215 = getelementptr ptr, ptr %t214, i64 %t211
  %t216 = load ptr, ptr %t215, !tbaa !39
  %t219 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitFloat(ptr %v0, ptr %v1, ptr %t209, ptr %t216)
  store i1 %t219, ptr %l131
  br label %bb40
bb40:
  %t220 = load i1, ptr %l131, !tbaa !21
  store i1 %t220, ptr %l125, !tbaa !21
  br label %bb41
bb41:
  %t221 = load i1, ptr %l125, !tbaa !21
  store i1 %t221, ptr %l21, !tbaa !21
  %t222 = load i64, ptr %l18, !tbaa !24
  %t223 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t225 = extractvalue { i64, ptr } %t223, 0
  %t228 = icmp slt i64 %t222, %t225
  br i1 %t228, label %bb42, label %bb43
bb42:
  store %olang.scope zeroinitializer, ptr %s6
  %t230 = load ptr, ptr %l0, !tbaa !29
  store ptr %t230, ptr %l136, !tbaa !29
  %t231 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t231, ptr %l137, !tbaa !27
  %t232 = load i64, ptr %l18, !tbaa !24
  %t234 = getelementptr { i64, ptr }, ptr %l137, i32 0, i32 1
  %t235 = load ptr, ptr %t234, !tbaa !27
  %t236 = getelementptr i32, ptr %t235, i64 %t232
  %t237 = load i32, ptr %t236, !tbaa !33
  store i32 %t237, ptr %l139, !tbaa !23
  %t238 = load i1, ptr %l21, !tbaa !21
  br i1 %t238, label %bb44, label %bb45
bb43:
  br label %bb50
bb44:
  %t240 = load ptr, ptr %l0, !tbaa !29
  %t242 = getelementptr %"compiler/check:Checker", ptr %t240, i32 0, i32 1
  %t243 = load ptr, ptr %t242, !tbaa !29
  %t245 = getelementptr %"compiler/generic:Program", ptr %t243, i32 0, i32 2
  %t247 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s6, ptr %t245, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d55, i32 0, i32 1) })
  store i32 %t247, ptr %l145
  br label %bb46
bb45:
  %t248 = load ptr, ptr %l0, !tbaa !29
  %t250 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t248)
  store i32 %t250, ptr %l147
  br label %bb47
bb46:
  %t251 = load i32, ptr %l145, !tbaa !23
  store i32 %t251, ptr %l141, !tbaa !23
  br label %bb48
bb47:
  %t252 = load i32, ptr %l147, !tbaa !23
  store i32 %t252, ptr %l141, !tbaa !23
  br label %bb48
bb48:
  %t253 = load ptr, ptr %l136, !tbaa !29
  %t254 = load i32, ptr %l139, !tbaa !23
  %t255 = load i32, ptr %l141, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunify(ptr %v0, ptr %s0, ptr %t253, i32 %t254, i32 %t255, ptr %l11, i1 true, i1 false)
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s6)
  br label %bb50
bb50:
  br label %bb67
bb51:
  %t257 = load ptr, ptr %l152, !tbaa !29
  %t258 = load i64, ptr %t257
  %t260 = icmp eq i64 %t258, 23
  store i1 %t260, ptr %l153, !tbaa !21
  br label %bb52
bb52:
  %t261 = load i1, ptr %l153, !tbaa !21
  br i1 %t261, label %bb53, label %bb54
bb53:
  br label %bb59
bb54:
  %t262 = load ptr, ptr %l22, !tbaa !29
  store ptr %t262, ptr %l156, !tbaa !29
  store i1 false, ptr %l157, !tbaa !21
  %t263 = load ptr, ptr %l156, !tbaa !29
  %t264 = icmp ne ptr %t263, null
  br i1 %t264, label %bb55, label %bb56
bb55:
  %t266 = load ptr, ptr %l156, !tbaa !29
  %t267 = load i64, ptr %t266
  %t269 = icmp eq i64 %t267, 26
  store i1 %t269, ptr %l157, !tbaa !21
  br label %bb56
bb56:
  %t270 = load i1, ptr %l157, !tbaa !21
  br i1 %t270, label %bb57, label %bb58
bb57:
  br label %bb59
bb58:
  br label %bb60
bb59:
  br label %bb66
bb60:
  br i1 true, label %bb61, label %bb62
bb61:
  br label %bb63
bb62:
  br label %bb65
bb63:
  %t271 = load ptr, ptr %l0, !tbaa !29
  %t272 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t272, ptr %l161, !tbaa !27
  %t273 = load i64, ptr %l18, !tbaa !24
  %t275 = getelementptr { i64, ptr }, ptr %l161, i32 0, i32 1
  %t276 = load ptr, ptr %t275, !tbaa !27
  %t277 = getelementptr ptr, ptr %t276, i64 %t273
  %t278 = load ptr, ptr %t277, !tbaa !39
  %t280 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t284 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %t271, ptr %t278, i32 %t280)
  store ptr %t284, ptr %l166
  br label %bb64
bb64:
  %t285 = load ptr, ptr %l166, !tbaa !29
  store ptr %t285, ptr %l19, !tbaa !29
  br label %bb66
bb65:
  call void @__olang_check_failed(ptr @olang_loc_86f2d648d7a819c5_fc1d6e84e063e4d9)
  unreachable
bb66:
  br label %bb67
bb67:
  %t287 = load ptr, ptr %l19, !tbaa !29
  %t289 = icmp eq ptr %t287, null
  %t291 = xor i1 %t289, true
  br i1 %t291, label %bb68, label %bb69
bb68:
  %t293 = load i64, ptr %l18, !tbaa !24
  %t294 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t296 = extractvalue { i64, ptr } %t294, 0
  %t299 = icmp slt i64 %t293, %t296
  store i1 %t299, ptr %l171, !tbaa !21
  br label %bb70
bb69:
  store i1 false, ptr %l171, !tbaa !21
  br label %bb70
bb70:
  %t301 = load i1, ptr %l171, !tbaa !21
  br i1 %t301, label %bb71, label %bb72
bb71:
  %t302 = load ptr, ptr %l19, !tbaa !29
  %t305 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t302)
  store i32 %t305, ptr %l179
  br label %bb73
bb72:
  store i1 false, ptr %l176, !tbaa !21
  br label %bb74
bb73:
  %t306 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t307 = load i32, ptr %l179, !tbaa !23
  %t309 = icmp ne i32 %t307, %t306
  store i1 %t309, ptr %l176, !tbaa !21
  br label %bb74
bb74:
  %t311 = load i1, ptr %l176, !tbaa !21
  br i1 %t311, label %bb75, label %bb76
bb75:
  %t312 = load ptr, ptr %l19, !tbaa !29
  %t315 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t312)
  store i32 %t315, ptr %l185
  br label %bb77
bb76:
  store i1 false, ptr %l182, !tbaa !21
  br label %bb78
bb77:
  %t316 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t317 = load i32, ptr %l185, !tbaa !23
  %t319 = icmp ne i32 %t317, %t316
  store i1 %t319, ptr %l182, !tbaa !21
  br label %bb78
bb78:
  %t321 = load i1, ptr %l182, !tbaa !21
  br i1 %t321, label %bb79, label %bb80
bb79:
  %t322 = load ptr, ptr %l0, !tbaa !29
  store ptr %t322, ptr %l188, !tbaa !29
  %t323 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t323, ptr %l189, !tbaa !27
  %t324 = load i64, ptr %l18, !tbaa !24
  %t326 = getelementptr { i64, ptr }, ptr %l189, i32 0, i32 1
  %t327 = load ptr, ptr %t326, !tbaa !27
  %t328 = getelementptr i32, ptr %t327, i64 %t324
  %t329 = load i32, ptr %t328, !tbaa !33
  store i32 %t329, ptr %l191, !tbaa !23
  %t330 = load ptr, ptr %l0, !tbaa !29
  %t331 = load ptr, ptr %l19, !tbaa !29
  %t334 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebindType(ptr %v0, ptr %v0, ptr %t330, ptr %t331)
  store i32 %t334, ptr %l194
  br label %bb81
bb80:
  br label %bb83
bb81:
  %t335 = load ptr, ptr %l188, !tbaa !29
  %t336 = load i32, ptr %l191, !tbaa !23
  %t337 = load i32, ptr %l194, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunify(ptr %v0, ptr %s0, ptr %t335, i32 %t336, i32 %t337, ptr %l11, i1 false, i1 false)
  br label %bb82
bb82:
  br label %bb83
bb83:
  %t339 = load ptr, ptr %l19, !tbaa !29
  %t341 = icmp eq ptr %t339, null
  br i1 %t341, label %bb84, label %bb85
bb84:
  %t343 = load ptr, ptr %lp12
  %t344 = load ptr, ptr %l0, !tbaa !29
  %t346 = getelementptr %"compiler/check:Checker", ptr %t344, i32 0, i32 0
  %t347 = load ptr, ptr %t346, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t343, ptr %t347)
  br label %bb86
bb85:
  %t350 = load ptr, ptr %lp12
  %t351 = load ptr, ptr %l19, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t350, ptr %t351)
  br label %bb87
bb86:
  br label %bb88
bb87:
  br label %bb88
bb88:
  br label %bb89
bb89:
  %t354 = load i64, ptr %l17, !tbaa !24
  %t356 = add i64 %t354, 1
  store i64 %t356, ptr %l17, !tbaa !24
  br label %bb27
bb90:
  %t358 = load ptr, ptr %l0, !tbaa !29
  %t360 = getelementptr %"compiler/check:Checker", ptr %t358, i32 0, i32 1
  %t361 = load ptr, ptr %t360, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInferThroughBounds(ptr %v0, ptr %s0, ptr %t361, ptr %l11)
  br label %bb91
bb91:
  store i64 0, ptr %l23, !tbaa !24
  %t364 = load i64, ptr %l9, !tbaa !24
  store i64 %t364, ptr %l24, !tbaa !24
  store i64 1, ptr %l25, !tbaa !24
  %t366 = load i64, ptr %l24, !tbaa !24
  %t367 = load i64, ptr %l23, !tbaa !24
  %t370 = icmp sgt i64 %t366, %t367
  br i1 %t370, label %bb92, label %bb93
bb92:
  %t372 = load i64, ptr %l25, !tbaa !24
  %t374 = icmp sgt i64 %t372, 0
  br i1 %t374, label %bb94, label %bb95
bb93:
  store i64 0, ptr %l212, !tbaa !24
  br label %bb97
bb94:
  %t376 = load i64, ptr %l24, !tbaa !24
  %t377 = load i64, ptr %l23, !tbaa !24
  %t380 = sub i64 %t376, %t377
  %t381 = load i64, ptr %l25, !tbaa !24
  %t384 = add i64 %t380, %t381
  %t386 = sub i64 %t384, 1
  %t387 = load i64, ptr %l25, !tbaa !24
  %t390 = sdiv i64 %t386, %t387
  store i64 %t390, ptr %l215, !tbaa !24
  br label %bb96
bb95:
  store i64 0, ptr %l215, !tbaa !24
  br label %bb96
bb96:
  %t392 = load i64, ptr %l215, !tbaa !24
  store i64 %t392, ptr %l212, !tbaa !24
  br label %bb97
bb97:
  %t393 = load i64, ptr %l212, !tbaa !24
  store i64 %t393, ptr %l26, !tbaa !24
  store i64 0, ptr %l27, !tbaa !24
  br label %bb98
bb98:
  %t394 = load i64, ptr %l27, !tbaa !24
  %t395 = load i64, ptr %l26, !tbaa !24
  %t398 = icmp slt i64 %t394, %t395
  %t400 = xor i1 %t398, true
  br i1 %t400, label %bb99, label %bb100
bb99:
  br label %bb110
bb100:
  br label %bb101
bb101:
  %t402 = load i64, ptr %l23, !tbaa !24
  %t403 = load i64, ptr %l27, !tbaa !24
  %t404 = load i64, ptr %l25, !tbaa !24
  %t407 = mul i64 %t403, %t404
  %t410 = add i64 %t402, %t407
  %t412 = getelementptr %"compiler/generic:Binding", ptr %l11, i32 0, i32 2
  %t413 = load { i64, ptr }, ptr %t412, !tbaa !27
  store { i64, ptr } %t413, ptr %l233, !tbaa !27
  %t416 = getelementptr { i64, ptr }, ptr %l233, i32 0, i32 1
  %t417 = load ptr, ptr %t416, !tbaa !27
  %t418 = getelementptr i32, ptr %t417, i64 %t410
  %t419 = load i32, ptr %t418, !tbaa !33
  %t420 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t423 = icmp eq i32 %t419, %t420
  br i1 %t423, label %bb102, label %bb103
bb102:
  store %olang.scope zeroinitializer, ptr %s16
  %t425 = load ptr, ptr %l0, !tbaa !29
  store ptr %t425, ptr %l238, !tbaa !29
  %t426 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t426, ptr %l239
  %t427 = load ptr, ptr %l0, !tbaa !29
  %t428 = load i32, ptr %l3, !tbaa !23
  %t431 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s16, ptr %t427, i32 %t428)
  store { i64, ptr } %t431, ptr %l242
  br label %bb104
bb103:
  br label %bb108
bb104:
  %t432 = load { i64, ptr }, ptr %l242, !tbaa !27
  %t433 = extractvalue { i64, ptr } %t432, 0
  %t434 = extractvalue { i64, ptr } %t432, 1
  %t435 = mul i64 %t433, 1
  %t436 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t435)
  call void @llvm.memcpy.p0.p0.i64(ptr %t436, ptr %t434, i64 %t435, i1 false)
  %t437 = insertvalue { i64, ptr } undef, i64 %t433, 0
  %t438 = insertvalue { i64, ptr } %t437, ptr %t436, 1
  %t440 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCtorVarsNotInferable(ptr %s16, ptr %s16, { i64, ptr } %t438)
  store %"compiler/msgs:Msg" %t440, ptr %l244
  br label %bb105
bb105:
  %t441 = load ptr, ptr %l238, !tbaa !29
  %t442 = load %"compiler/source:Span", ptr %l239
  %t443 = load %"compiler/msgs:Msg", ptr %l244
  %t444 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s16, ptr %t441, %"compiler/source:Span" %t442, %"compiler/msgs:Msg" %t443)
  store i64 %t444, ptr %l245
  br label %bb106
bb106:
  %t445 = load ptr, ptr %l0, !tbaa !29
  %t446 = load %"compiler/source:Span", ptr %l1
  %t449 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t445, %"compiler/source:Span" %t446)
  store ptr %t449, ptr %l248
  br label %bb107
bb107:
  call void @__olang_scope_close(ptr %s16)
  call void @__olang_scope_close(ptr %s0)
  %t450 = load ptr, ptr %l248, !tbaa !29
  store ptr %t450, ptr %rv
  br label %ret
bb108:
  br label %bb109
bb109:
  %t451 = load i64, ptr %l27, !tbaa !24
  %t453 = add i64 %t451, 1
  store i64 %t453, ptr %l27, !tbaa !24
  br label %bb98
bb110:
  %t455 = load ptr, ptr %l0, !tbaa !29
  %t457 = getelementptr %"compiler/check:Checker", ptr %t455, i32 0, i32 1
  %t458 = load ptr, ptr %t457, !tbaa !29
  %t460 = getelementptr %"compiler/generic:Program", ptr %t458, i32 0, i32 2
  %t461 = getelementptr %"compiler/generic:Binding", ptr %l11, i32 0, i32 2
  %t462 = load { i64, ptr }, ptr %t461, !tbaa !27
  %t465 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t460, { i64, ptr } %t462)
  store i32 %t465, ptr %l255
  br label %bb111
bb111:
  %t466 = load i32, ptr %l255, !tbaa !23
  store i32 %t466, ptr %l29, !tbaa !23
  %t467 = load ptr, ptr %l0, !tbaa !29
  %t469 = getelementptr %"compiler/check:Checker", ptr %t467, i32 0, i32 1
  %t470 = load ptr, ptr %t469, !tbaa !29
  %t471 = load i32, ptr %l3, !tbaa !23
  %t472 = load i32, ptr %l29, !tbaa !23
  %t476 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorSigAt(ptr %v0, ptr %t470, i32 %t471, i32 %t472)
  store i32 %t476, ptr %l260
  br label %bb112
bb112:
  %t477 = load i32, ptr %l260, !tbaa !23
  store i32 %t477, ptr %l30, !tbaa !23
  %t478 = load i32, ptr %l30, !tbaa !23
  %t479 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t482 = icmp eq i32 %t478, %t479
  br i1 %t482, label %bb113, label %bb114
bb113:
  %t484 = load ptr, ptr %l0, !tbaa !29
  %t485 = load %"compiler/source:Span", ptr %l1
  %t488 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t484, %"compiler/source:Span" %t485)
  store ptr %t488, ptr %l266
  br label %bb115
bb114:
  br label %bb116
bb115:
  call void @__olang_scope_close(ptr %s0)
  %t489 = load ptr, ptr %l266, !tbaa !29
  store ptr %t489, ptr %rv
  br label %ret
bb116:
  %t490 = load ptr, ptr %l0, !tbaa !29
  %t491 = load i32, ptr %l3, !tbaa !23
  %t492 = load i32, ptr %l29, !tbaa !23
  %t496 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etwinBody(ptr %v0, ptr %t490, i32 %t491, i32 %t492)
  store i64 %t496, ptr %l270
  br label %bb117
bb117:
  %t497 = load i64, ptr %l270, !tbaa !24
  store i64 %t497, ptr %l31, !tbaa !24
  %t498 = load ptr, ptr %l0, !tbaa !29
  %t500 = getelementptr %"compiler/check:Checker", ptr %t498, i32 0, i32 23
  %t501 = load i32, ptr %t500, !tbaa !23
  store i32 %t501, ptr %l32, !tbaa !23
  %t503 = load ptr, ptr %l0, !tbaa !29
  %t504 = load i32, ptr %l3, !tbaa !23
  %t507 = getelementptr %"compiler/check:Checker", ptr %t503, i32 0, i32 23
  store i32 %t504, ptr %t507, !tbaa !23
  %t508 = load ptr, ptr %l0, !tbaa !29
  %t509 = load { i64, ptr }, ptr %l7, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetOrder(ptr %v0, ptr %s0, ptr %t508, { i64, ptr } %t509)
  br label %bb118
bb118:
  %t512 = load ptr, ptr %l0, !tbaa !29
  store ptr %t512, ptr %l277, !tbaa !29
  %t513 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t513, ptr %l278
  %t514 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t514, ptr %l279
  %t515 = load i32, ptr %l30, !tbaa !23
  store i32 %t515, ptr %l280, !tbaa !23
  %t516 = load i64, ptr %l31, !tbaa !24
  %t518 = trunc i64 %t516 to i32
  store { i64, [3 x i64] } zeroinitializer, ptr %t520
  %t521 = getelementptr { i64, [3 x i64] }, ptr %t520, i32 0, i32 0
  store i64 0, ptr %t521
  %t523 = insertvalue { i32 } undef, i32 %t518, 0
  %t524 = getelementptr { i64, [3 x i64] }, ptr %t520, i32 0, i32 1
  store { i32 } %t523, ptr %t524
  %t525 = load { i64, [3 x i64] }, ptr %t520
  %t527 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t525, ptr %t527
  store ptr %t527, ptr %l285, !tbaa !29
  %t528 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t528, ptr %l286, !tbaa !27
  %t529 = load ptr, ptr %lp12
  %t531 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eToArra_H50cbff9caa8a2389caf3e92da7e24507(ptr %v0, ptr %v0, ptr %t529)
  store { i64, ptr } %t531, ptr %l288
  br label %bb119
bb119:
  %t532 = load ptr, ptr %l277, !tbaa !29
  %t533 = load %"compiler/source:Span", ptr %l278
  %t534 = load %"compiler/source:Span", ptr %l279
  %t535 = load i32, ptr %l280, !tbaa !23
  %t536 = load ptr, ptr %l285, !tbaa !29
  %t537 = load { i64, ptr }, ptr %l286, !tbaa !27
  %t538 = load { i64, ptr }, ptr %l288, !tbaa !27
  %t539 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallBody(ptr %v0, ptr %v1, ptr %t532, %"compiler/source:Span" %t533, %"compiler/source:Span" %t534, i32 %t535, ptr %t536, i64 -1, ptr null, { i64, ptr } %t537, { i64, ptr } %t538)
  store ptr %t539, ptr %l289
  br label %bb120
bb120:
  %t540 = load ptr, ptr %l289, !tbaa !29
  %t541 = load ptr, ptr %l0, !tbaa !29
  %t542 = load i32, ptr %l32, !tbaa !23
  %t545 = getelementptr %"compiler/check:Checker", ptr %t541, i32 0, i32 23
  store i32 %t542, ptr %t545, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store ptr %t540, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etyOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca i1
  %l18 = alloca i1
  %l19 = alloca i1
  %l24 = alloca i32
  %l26 = alloca i32
  %l28 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca { i64, ptr }
  %l32 = alloca ptr
  %l35 = alloca i32
  %l36 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i64, ptr }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, i64, ptr }, ptr %t18, i32 0, i32 3
  %t20 = load ptr, ptr %t19
  store ptr %t20, ptr %l3, !tbaa !29
  br label %bb5
bb4:
  br label %bb26
bb5:
  %t22 = load ptr, ptr %l3, !tbaa !29
  store ptr %t22, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t23 = load ptr, ptr %l12, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb6, label %bb7
bb6:
  %t26 = load ptr, ptr %l12, !tbaa !29
  %t27 = load i64, ptr %t26
  %t29 = icmp eq i64 %t27, 1
  store i1 %t29, ptr %l13, !tbaa !21
  br label %bb7
bb7:
  %t30 = load i1, ptr %l13, !tbaa !21
  br i1 %t30, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb20
bb10:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load i32, ptr %l2, !tbaa !23
  %t35 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t31, i32 %t32)
  store i1 %t35, ptr %l18
  br label %bb11
bb11:
  %t36 = load i1, ptr %l18, !tbaa !21
  br i1 %t36, label %bb12, label %bb13
bb12:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/check:Checker", ptr %t37, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t42 = getelementptr %"compiler/generic:Program", ptr %t40, i32 0, i32 2
  %t43 = load i32, ptr %l2, !tbaa !23
  %t46 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t42, i32 %t43)
  store i32 %t46, ptr %l24
  br label %bb14
bb13:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb16
bb14:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %t47)
  store i32 %t49, ptr %l26
  br label %bb15
bb15:
  %t50 = load i32, ptr %l24, !tbaa !23
  %t51 = load i32, ptr %l26, !tbaa !23
  %t52 = icmp eq i32 %t50, %t51
  store i1 %t52, ptr %l19, !tbaa !21
  br label %bb16
bb16:
  %t54 = load i1, ptr %l19, !tbaa !21
  br i1 %t54, label %bb17, label %bb18
bb17:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d56, i32 0, i32 1) }, ptr %l28, !tbaa !27
  %t55 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t55, ptr %l29, !tbaa !27
  %t56 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t57 = extractvalue { i64, ptr } %t56, 0
  store i64 %t57, ptr %l30, !tbaa !24
  %t58 = load i64, ptr %l30, !tbaa !24
  %t59 = mul i64 %t58, 1
  %t60 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t59)
  %t61 = insertvalue { i64, ptr } undef, i64 %t58, 0
  %t62 = insertvalue { i64, ptr } %t61, ptr %t60, 1
  store { i64, ptr } %t62, ptr %l31, !tbaa !27
  %t63 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !27
  %t65 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !27
  %t67 = load i64, ptr %l30, !tbaa !24
  %t68 = mul i64 %t67, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t64, ptr %t66, i64 %t68, i1 false)
  %t69 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t69, ptr %l29, !tbaa !27
  %t70 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t70, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  br label %bb25
bb20:
  br i1 true, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_e722c21055ee6b49_58bcebf0b772fb7d)
  unreachable
bb25:
  br label %bb31
bb26:
  br i1 true, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb31
bb30:
  call void @__olang_check_failed(ptr @olang_loc_eca48244095fc078_aacf4c954a6e214c)
  unreachable
bb31:
  %t71 = load ptr, ptr %l0, !tbaa !29
  store ptr %t71, ptr %l32, !tbaa !29
  %t72 = load ptr, ptr %l1, !tbaa !29
  %t75 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t72)
  store i32 %t75, ptr %l35
  br label %bb32
bb32:
  %t76 = load ptr, ptr %l32, !tbaa !29
  %t77 = load i32, ptr %l35, !tbaa !23
  %t78 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v2, ptr %t76, i32 %t77)
  store { i64, ptr } %t78, ptr %l36
  br label %bb33
bb33:
  %t79 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t79, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunrolledCompr(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, %"compiler/check:reflList" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca %"compiler/check:reflList"
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i32
  %l15 = alloca i32
  %l16 = alloca i1
  %l17 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca { i64, ptr }
  %l24 = alloca i32
  %l25 = alloca ptr
  %l28 = alloca %"compiler/source:Span"
  %l30 = alloca { i64, ptr }
  %l33 = alloca i64
  %l39 = alloca i64
  %l42 = alloca i64
  %l60 = alloca ptr
  %l62 = alloca i32
  %l67 = alloca i32
  %l68 = alloca i32
  %l69 = alloca ptr
  %l71 = alloca i32
  %l74 = alloca ptr
  %l76 = alloca i32
  %l78 = alloca i32
  %l79 = alloca i32
  %l87 = alloca i64
  %l90 = alloca ptr
  %l96 = alloca %"compiler/source:Span"
  %l97 = alloca %"compiler/msgs:Msg"
  %l98 = alloca i64
  %l106 = alloca ptr
  %l109 = alloca i1
  %l111 = alloca ptr
  %l113 = alloca ptr
  %l116 = alloca %"compiler/source:Span"
  %l118 = alloca i1
  %l137 = alloca { i64, ptr }
  %l140 = alloca ptr
  %l141 = alloca i32
  %l144 = alloca ptr
  %l146 = alloca i32
  %l148 = alloca i32
  %l149 = alloca i32
  %l150 = alloca %"compiler/source:Span"
  %l151 = alloca i32
  %l152 = alloca i32
  %l153 = alloca { i64, ptr }
  %l157 = alloca i32
  %l159 = alloca %"compiler/typed:Make"
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca ptr
  %t288 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store %"compiler/check:reflList" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t4 = getelementptr %"compiler/ast:Compr", ptr %t2, i32 0, i32 0
  %t5 = load ptr, ptr %t4, !tbaa !29
  %t8 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresolve(ptr %v0, ptr %v1, ptr %t1, ptr %t5)
  store i32 %t8, ptr %l24
  br label %bb1
bb1:
  %t9 = load i32, ptr %l24, !tbaa !23
  store i32 %t9, ptr %l4, !tbaa !23
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l25, !tbaa !29
  %t11 = load ptr, ptr %l2, !tbaa !29
  %t13 = getelementptr %"compiler/ast:Compr", ptr %t11, i32 0, i32 4
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t16 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t14)
  store %"compiler/source:Span" %t16, ptr %l28
  br label %bb2
bb2:
  %t17 = load %"compiler/check:reflList", ptr %l3
  %t18 = load ptr, ptr %l25, !tbaa !29
  %t19 = load %"compiler/source:Span", ptr %l28
  %t21 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistItems(ptr %v0, ptr %s0, ptr %t18, %"compiler/source:Span" %t19, %"compiler/check:reflList" %t17)
  store { i64, ptr } %t21, ptr %l30
  br label %bb3
bb3:
  %t22 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t22, ptr %l5, !tbaa !27
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/check:Checker", ptr %t23, i32 0, i32 36
  %t27 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t25)
  store i64 %t27, ptr %l33
  br label %bb4
bb4:
  %t28 = load i64, ptr %l33, !tbaa !24
  store i64 %t28, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  %t29 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t31 = extractvalue { i64, ptr } %t29, 0
  store i64 %t31, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t33 = load i64, ptr %l9, !tbaa !24
  %t34 = load i64, ptr %l8, !tbaa !24
  %t37 = icmp sgt i64 %t33, %t34
  br i1 %t37, label %bb5, label %bb6
bb5:
  %t39 = load i64, ptr %l10, !tbaa !24
  %t41 = icmp sgt i64 %t39, 0
  br i1 %t41, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l39, !tbaa !24
  br label %bb10
bb7:
  %t43 = load i64, ptr %l9, !tbaa !24
  %t44 = load i64, ptr %l8, !tbaa !24
  %t47 = sub i64 %t43, %t44
  %t48 = load i64, ptr %l10, !tbaa !24
  %t51 = add i64 %t47, %t48
  %t53 = sub i64 %t51, 1
  %t54 = load i64, ptr %l10, !tbaa !24
  %t57 = sdiv i64 %t53, %t54
  store i64 %t57, ptr %l42, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l42, !tbaa !24
  br label %bb9
bb9:
  %t59 = load i64, ptr %l42, !tbaa !24
  store i64 %t59, ptr %l39, !tbaa !24
  br label %bb10
bb10:
  %t60 = load i64, ptr %l39, !tbaa !24
  store i64 %t60, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb11
bb11:
  %t61 = load i64, ptr %l12, !tbaa !24
  %t62 = load i64, ptr %l11, !tbaa !24
  %t65 = icmp slt i64 %t61, %t62
  %t67 = xor i1 %t65, true
  br i1 %t67, label %bb12, label %bb13
bb12:
  br label %bb47
bb13:
  br label %bb14
bb14:
  %t69 = load i64, ptr %l8, !tbaa !24
  %t70 = load i64, ptr %l12, !tbaa !24
  %t71 = load i64, ptr %l10, !tbaa !24
  %t74 = mul i64 %t70, %t71
  %t77 = add i64 %t69, %t74
  store i64 %t77, ptr %l13, !tbaa !24
  %t79 = load ptr, ptr %l0, !tbaa !29
  store ptr %t79, ptr %l60, !tbaa !29
  %t80 = load ptr, ptr %l2, !tbaa !29
  %t82 = getelementptr %"compiler/ast:Compr", ptr %t80, i32 0, i32 3
  %t83 = load i32, ptr %t82, !tbaa !23
  store i32 %t83, ptr %l62, !tbaa !23
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t85 = load %"compiler/check:reflList", ptr %l3
  %t86 = load i64, ptr %l13, !tbaa !24
  %t88 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !27
  %t90 = getelementptr i64, ptr %t89, i64 %t86
  %t91 = load i64, ptr %t90, !tbaa !34
  %t95 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edescriptor(ptr %v0, ptr %t84, %"compiler/check:reflList" %t85, i64 %t91)
  store i32 %t95, ptr %l67
  br label %bb15
bb15:
  %t96 = load ptr, ptr %l60, !tbaa !29
  %t97 = load i32, ptr %l62, !tbaa !23
  %t98 = load i32, ptr %l67, !tbaa !23
  %t99 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflBind(ptr %v0, ptr %t96, i32 %t97, i32 %t98)
  store i32 %t99, ptr %l68
  br label %bb16
bb16:
  %t100 = load i32, ptr %l68, !tbaa !23
  store i32 %t100, ptr %l14, !tbaa !23
  %t101 = load ptr, ptr %l0, !tbaa !29
  store ptr %t101, ptr %l69, !tbaa !29
  %t102 = load ptr, ptr %l2, !tbaa !29
  %t104 = getelementptr %"compiler/ast:Compr", ptr %t102, i32 0, i32 2
  %t105 = load i32, ptr %t104, !tbaa !23
  store i32 %t105, ptr %l71, !tbaa !23
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = getelementptr %"compiler/check:Checker", ptr %t106, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !29
  %t111 = getelementptr %"compiler/generic:Program", ptr %t109, i32 0, i32 2
  store ptr %t111, ptr %l74, !tbaa !29
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t114 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t112)
  store i32 %t114, ptr %l76
  br label %bb17
bb17:
  %t115 = load i64, ptr %l13, !tbaa !24
  %t116 = load ptr, ptr %l74, !tbaa !29
  %t117 = load i32, ptr %l76, !tbaa !23
  %t119 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConst(ptr %v0, ptr %t116, i32 %t117, i64 %t115)
  store i32 %t119, ptr %l78
  br label %bb18
bb18:
  %t120 = load ptr, ptr %l69, !tbaa !29
  %t121 = load i32, ptr %l71, !tbaa !23
  %t122 = load i32, ptr %l78, !tbaa !23
  %t123 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflBind(ptr %v0, ptr %t120, i32 %t121, i32 %t122)
  store i32 %t123, ptr %l79
  br label %bb19
bb19:
  %t124 = load i32, ptr %l79, !tbaa !23
  store i32 %t124, ptr %l15, !tbaa !23
  store i1 true, ptr %l16, !tbaa !21
  %t125 = load ptr, ptr %l2, !tbaa !29
  %t127 = getelementptr %"compiler/ast:Compr", ptr %t125, i32 0, i32 5
  %t128 = load ptr, ptr %t127, !tbaa !29
  %t130 = icmp eq ptr %t128, null
  %t132 = xor i1 %t130, true
  br i1 %t132, label %bb20, label %bb21
bb20:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t135 = load ptr, ptr %l2, !tbaa !29
  %t137 = getelementptr %"compiler/ast:Compr", ptr %t135, i32 0, i32 5
  %t138 = load ptr, ptr %t137, !tbaa !29
  %t141 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflDecide(ptr %v0, ptr %v1, ptr %t134, ptr %t138)
  store i64 %t141, ptr %l87
  br label %bb22
bb21:
  br label %bb32
bb22:
  %t142 = load i64, ptr %l87, !tbaa !24
  store i64 %t142, ptr %l17, !tbaa !24
  %t143 = load i64, ptr %l17, !tbaa !24
  %t145 = icmp slt i64 %t143, 0
  br i1 %t145, label %bb23, label %bb24
bb23:
  store %olang.scope zeroinitializer, ptr %s4
  %t147 = load ptr, ptr %l0, !tbaa !29
  store ptr %t147, ptr %l90, !tbaa !29
  %t148 = load ptr, ptr %l2, !tbaa !29
  %t150 = getelementptr %"compiler/ast:Compr", ptr %t148, i32 0, i32 5
  %t151 = load ptr, ptr %t150, !tbaa !29
  %t153 = icmp eq ptr %t151, null
  br i1 %t153, label %bb25, label %bb26
bb24:
  %t155 = load i64, ptr %l17, !tbaa !24
  %t157 = icmp eq i64 %t155, 1
  store i1 %t157, ptr %l16, !tbaa !21
  br label %bb31
bb25:
  call void @__olang_check_failed(ptr @olang_loc_ef99e54d7427d8e6_6c42201a9dddf792)
  unreachable
bb26:
  br label %bb27
bb27:
  %t159 = load ptr, ptr %l2, !tbaa !29
  %t161 = getelementptr %"compiler/ast:Compr", ptr %t159, i32 0, i32 5
  %t162 = load ptr, ptr %t161, !tbaa !29
  %t164 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t162)
  store %"compiler/source:Span" %t164, ptr %l96
  br label %bb28
bb28:
  %t165 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eReflFilterUndecided(ptr %s4)
  store %"compiler/msgs:Msg" %t165, ptr %l97
  br label %bb29
bb29:
  %t166 = load ptr, ptr %l90, !tbaa !29
  %t167 = load %"compiler/source:Span", ptr %l96
  %t168 = load %"compiler/msgs:Msg", ptr %l97
  %t169 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s4, ptr %t166, %"compiler/source:Span" %t167, %"compiler/msgs:Msg" %t168)
  store i64 %t169, ptr %l98
  br label %bb30
bb30:
  store i1 false, ptr %l16, !tbaa !21
  call void @__olang_scope_close(ptr %s4)
  br label %bb31
bb31:
  br label %bb32
bb32:
  %t170 = load i1, ptr %l16, !tbaa !21
  br i1 %t170, label %bb33, label %bb34
bb33:
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t173 = load ptr, ptr %l2, !tbaa !29
  %t175 = getelementptr %"compiler/ast:Compr", ptr %t173, i32 0, i32 1
  %t176 = load ptr, ptr %t175, !tbaa !29
  %t177 = load i32, ptr %l4, !tbaa !23
  %t181 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v1, ptr %t172, ptr %t176, i32 %t177)
  store ptr %t181, ptr %l106
  br label %bb35
bb34:
  br label %bb43
bb35:
  %t182 = load ptr, ptr %l106, !tbaa !29
  store ptr %t182, ptr %l18, !tbaa !29
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t184 = load i32, ptr %l4, !tbaa !23
  %t187 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t183, i32 %t184)
  store i1 %t187, ptr %l109
  br label %bb36
bb36:
  %t188 = load i1, ptr %l109, !tbaa !21
  %t189 = xor i1 %t188, true
  br i1 %t189, label %bb37, label %bb38
bb37:
  %t191 = load ptr, ptr %l0, !tbaa !29
  store ptr %t191, ptr %l111, !tbaa !29
  %t192 = load ptr, ptr %l18, !tbaa !29
  store ptr %t192, ptr %l113, !tbaa !29
  %t194 = load ptr, ptr %l2, !tbaa !29
  %t196 = getelementptr %"compiler/ast:Compr", ptr %t194, i32 0, i32 1
  %t197 = load ptr, ptr %t196, !tbaa !29
  %t199 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t197)
  store %"compiler/source:Span" %t199, ptr %l116
  br label %bb39
bb38:
  br label %bb41
bb39:
  %t200 = load i64, ptr @G_2ecompiler_2fcheck_2eRoStored, !tbaa !24
  %t201 = load ptr, ptr %l111, !tbaa !29
  %t202 = load ptr, ptr %l113, !tbaa !29
  %t203 = load %"compiler/source:Span", ptr %l116
  %t205 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroStore(ptr %v0, ptr %v0, ptr %t201, ptr %t202, %"compiler/source:Span" %t203, i64 %t200)
  store i1 %t205, ptr %l118
  br label %bb40
bb40:
  br label %bb41
bb41:
  %t206 = load ptr, ptr %l0, !tbaa !29
  %t208 = getelementptr %"compiler/check:Checker", ptr %t206, i32 0, i32 36
  %t209 = load ptr, ptr %l18, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t208, ptr %t209)
  br label %bb42
bb42:
  %t212 = load i64, ptr %l7, !tbaa !24
  %t214 = add i64 %t212, 1
  store i64 %t214, ptr %l7, !tbaa !24
  br label %bb43
bb43:
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t217 = load ptr, ptr %l2, !tbaa !29
  %t219 = getelementptr %"compiler/ast:Compr", ptr %t217, i32 0, i32 2
  %t220 = load i32, ptr %t219, !tbaa !23
  %t221 = load i32, ptr %l15, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflUnbind(ptr %v0, ptr %t216, i32 %t220, i32 %t221)
  br label %bb44
bb44:
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t226 = load ptr, ptr %l2, !tbaa !29
  %t228 = getelementptr %"compiler/ast:Compr", ptr %t226, i32 0, i32 3
  %t229 = load i32, ptr %t228, !tbaa !23
  %t230 = load i32, ptr %l14, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflUnbind(ptr %v0, ptr %t225, i32 %t229, i32 %t230)
  br label %bb45
bb45:
  br label %bb46
bb46:
  %t234 = load i64, ptr %l12, !tbaa !24
  %t236 = add i64 %t234, 1
  store i64 %t236, ptr %l12, !tbaa !24
  br label %bb11
bb47:
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t240 = getelementptr %"compiler/check:Checker", ptr %t238, i32 0, i32 36
  %t241 = load i64, ptr %l6, !tbaa !24
  %t244 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t240, i64 %t241)
  store { i64, ptr } %t244, ptr %l137
  br label %bb48
bb48:
  %t245 = load { i64, ptr }, ptr %l137, !tbaa !27
  store { i64, ptr } %t245, ptr %l19, !tbaa !27
  %t246 = load ptr, ptr %l0, !tbaa !29
  %t248 = getelementptr %"compiler/check:Checker", ptr %t246, i32 0, i32 1
  %t249 = load ptr, ptr %t248, !tbaa !29
  %t251 = getelementptr %"compiler/generic:Program", ptr %t249, i32 0, i32 2
  store ptr %t251, ptr %l140, !tbaa !29
  %t252 = load i32, ptr %l4, !tbaa !23
  store i32 %t252, ptr %l141, !tbaa !23
  %t253 = load ptr, ptr %l0, !tbaa !29
  %t255 = getelementptr %"compiler/check:Checker", ptr %t253, i32 0, i32 1
  %t256 = load ptr, ptr %t255, !tbaa !29
  %t258 = getelementptr %"compiler/generic:Program", ptr %t256, i32 0, i32 2
  store ptr %t258, ptr %l144, !tbaa !29
  %t259 = load ptr, ptr %l0, !tbaa !29
  %t261 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t259)
  store i32 %t261, ptr %l146
  br label %bb49
bb49:
  %t262 = load i64, ptr %l7, !tbaa !24
  %t263 = load ptr, ptr %l144, !tbaa !29
  %t264 = load i32, ptr %l146, !tbaa !23
  %t266 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConst(ptr %v0, ptr %t263, i32 %t264, i64 %t262)
  store i32 %t266, ptr %l148
  br label %bb50
bb50:
  %t267 = load ptr, ptr %l140, !tbaa !29
  %t268 = load i32, ptr %l141, !tbaa !23
  %t269 = load i32, ptr %l148, !tbaa !23
  %t270 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %t267, i32 %t268, i32 %t269)
  store i32 %t270, ptr %l149
  br label %bb51
bb51:
  %t271 = load i32, ptr %l149, !tbaa !23
  %t272 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t272, ptr %l150
  store i32 %t271, ptr %l151, !tbaa !23
  store i32 2, ptr %l152
  %t274 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t274, ptr %l153, !tbaa !27
  %t275 = load ptr, ptr %l0, !tbaa !29
  %t276 = load %"compiler/source:Span", ptr %l1
  %t280 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %t275, i32 1, %"compiler/source:Span" %t276)
  store i32 %t280, ptr %l157
  br label %bb52
bb52:
  %t281 = load i32, ptr %l152
  %t282 = load { i64, ptr }, ptr %l153, !tbaa !27
  %t283 = load i32, ptr %l157, !tbaa !23
  %t285 = call %"compiler/typed:Make" @compiler_2ftyped_3aMake_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t281, i64 0, { i64, ptr } %t282, ptr null, i32 %t283, i32 0, i1 false)
  store %"compiler/typed:Make" %t285, ptr %l159
  br label %bb53
bb53:
  %t286 = load %"compiler/typed:Make", ptr %l159
  %t287 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 56, i64 8)
  store %"compiler/typed:Make" %t286, ptr %t287
  store { i64, [5 x i64] } zeroinitializer, ptr %t288
  %t289 = getelementptr { i64, [5 x i64] }, ptr %t288, i32 0, i32 0
  store i64 7, ptr %t289
  %t290 = load %"compiler/source:Span", ptr %l150
  %t291 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t290, 0
  %t292 = load i32, ptr %l151, !tbaa !23
  %t293 = insertvalue { %"compiler/source:Span", i32, ptr } %t291, i32 %t292, 1
  %t295 = insertvalue { %"compiler/source:Span", i32, ptr } %t293, ptr %t287, 2
  %t296 = getelementptr { i64, [5 x i64] }, ptr %t288, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t295, ptr %t296
  %t297 = load { i64, [5 x i64] }, ptr %t288
  %t299 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t297, ptr %t299
  call void @__olang_scope_close(ptr %s0)
  store ptr %t299, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2eisLimitName(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l2 = alloca i64
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call i64 @compiler_2fcheck_2elimitIndex(ptr %v0, { i64, ptr } %a0)
  store i64 %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load i64, ptr %l2, !tbaa !24
  %t5 = icmp sge i64 %t4, 0
  store i1 %t5, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fcheck_2elistIndex(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l3 = alloca i1
  %l6 = alloca i1
  %l9 = alloca i1
  %l12 = alloca i1
  %l15 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d57, i32 0, i32 1) })
  store i1 %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load i1, ptr %l3, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb5
bb4:
  %t5 = load i64, ptr @G_2ecompiler_2fgeneric_2eListFields, !tbaa !24
  store i64 %t5, ptr %l1, !tbaa !24
  br label %bb30
bb5:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t9 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t7, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d58, i32 0, i32 1) })
  store i1 %t9, ptr %l6
  br label %bb6
bb6:
  %t10 = load i1, ptr %l6, !tbaa !21
  br i1 %t10, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  %t11 = load i64, ptr @G_2ecompiler_2fgeneric_2eListCases, !tbaa !24
  store i64 %t11, ptr %l1, !tbaa !24
  br label %bb30
bb10:
  %t13 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t15 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t13, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d59, i32 0, i32 1) })
  store i1 %t15, ptr %l9
  br label %bb11
bb11:
  %t16 = load i1, ptr %l9, !tbaa !21
  br i1 %t16, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  %t17 = load i64, ptr @G_2ecompiler_2fgeneric_2eListParams, !tbaa !24
  store i64 %t17, ptr %l1, !tbaa !24
  br label %bb30
bb15:
  %t19 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t21 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t19, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d60, i32 0, i32 1) })
  store i1 %t21, ptr %l12
  br label %bb16
bb16:
  %t22 = load i1, ptr %l12, !tbaa !21
  br i1 %t22, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  %t23 = load i64, ptr @G_2ecompiler_2fgeneric_2eListResults, !tbaa !24
  store i64 %t23, ptr %l1, !tbaa !24
  br label %bb30
bb20:
  %t25 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t27 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t25, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d61, i32 0, i32 1) })
  store i1 %t27, ptr %l15
  br label %bb21
bb21:
  %t28 = load i1, ptr %l15, !tbaa !21
  br i1 %t28, label %bb22, label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb25
bb24:
  %t29 = load i64, ptr @G_2ecompiler_2fgeneric_2eListMethods, !tbaa !24
  store i64 %t29, ptr %l1, !tbaa !24
  br label %bb30
bb25:
  br i1 true, label %bb26, label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb29
bb28:
  store i64 -1, ptr %l1, !tbaa !24
  br label %bb30
bb29:
  call void @__olang_check_failed(ptr @olang_loc_77a436a5c2d44065_8e586571f5cf09a9)
  unreachable
bb30:
  call void @__olang_scope_close(ptr %s0)
  %t31 = load i64, ptr %l1, !tbaa !24
  store i64 %t31, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"compiler/source:Span" @compiler_2fcheck_2ememberSpan(%"compiler/source:Span" %a0, i64 %a1) #0 {
entry:
  %l0 = alloca %"compiler/source:Span"
  %l7 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store %"compiler/source:Span" %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = getelementptr %"compiler/source:Span", ptr %l0, i32 0, i32 1
  %t2 = load i32, ptr %t1, !tbaa !23
  %t5 = trunc i64 %a1 to i32
  %t8 = sub i32 %t2, %t5
  %t9 = getelementptr %"compiler/source:Span", ptr %l0, i32 0, i32 1
  %t10 = load i32, ptr %t9, !tbaa !23
  %t13 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %t8, i32 %t10)
  store %"compiler/source:Span" %t13, ptr %l7
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t14 = load %"compiler/source:Span", ptr %l7
  store %"compiler/source:Span" %t14, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local i1 @compiler_2fcheck_2epureRead(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca ptr
  %l4 = alloca i1
  %l10 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = call i1 @compiler_2fcheck_2epurePlace(ptr %v0, ptr %t16)
  store i1 %t18, ptr %l10
  br label %bb6
bb6:
  %t19 = load i1, ptr %l10, !tbaa !21
  store i1 %t19, ptr %l2, !tbaa !21
  br label %bb12
bb7:
  br i1 true, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_327c34393f585585_f16c5fd873651789)
  unreachable
bb12:
  %t20 = load i1, ptr %l2, !tbaa !21
  store i1 %t20, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2estoredMatch(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l18 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Match", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t4, ptr %t6)
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/ast:Match", ptr %t9, i32 0, i32 3
  %t12 = load { i64, ptr }, ptr %t11, !tbaa !27
  store { i64, ptr } %t12, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t14 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t14, 0
  store i64 %t16, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  %t18 = load i64, ptr %l3, !tbaa !24
  %t19 = load i64, ptr %l4, !tbaa !24
  %t22 = icmp slt i64 %t18, %t19
  %t24 = xor i1 %t22, true
  br i1 %t24, label %bb3, label %bb4
bb3:
  br label %bb8
bb4:
  br label %bb5
bb5:
  %t26 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t26, ptr %l18, !tbaa !27
  %t27 = load i64, ptr %l3, !tbaa !24
  %t29 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = getelementptr ptr, ptr %t30, i64 %t27
  %t32 = load ptr, ptr %t31, !tbaa !39
  %t35 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredCase(ptr %v0, ptr %v1, ptr %t32, ptr %t35)
  br label %bb6
bb6:
  br label %bb7
bb7:
  %t38 = load i64, ptr %l3, !tbaa !24
  %t40 = add i64 %t38, 1
  store i64 %t40, ptr %l3, !tbaa !24
  br label %bb2
bb8:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_3aContractAsk_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, i64 %a0, i64 %a1, %"compiler/source:Span" %a2, i64 %a3, %"compiler/source:Span" %a4, { i64, ptr } %a5, { i64, ptr } %a6, { i64, [3 x i64] } %a7, { i64, ptr } %a8, { i64, ptr } %a9) #0 {
entry:
  %l30 = alloca %"compiler/check:ContractAsk"
  br label %start
start:
  br label %bb0
bb0:
  %t21 = getelementptr %"compiler/check:ContractAsk", ptr %l30, i32 0, i32 0
  store i64 %a0, ptr %t21, !tbaa !24
  %t23 = getelementptr %"compiler/check:ContractAsk", ptr %l30, i32 0, i32 1
  store i64 %a1, ptr %t23, !tbaa !24
  %t25 = getelementptr %"compiler/check:ContractAsk", ptr %l30, i32 0, i32 2
  store %"compiler/source:Span" %a2, ptr %t25
  %t27 = getelementptr %"compiler/check:ContractAsk", ptr %l30, i32 0, i32 3
  store i64 %a3, ptr %t27, !tbaa !24
  %t29 = getelementptr %"compiler/check:ContractAsk", ptr %l30, i32 0, i32 4
  store %"compiler/source:Span" %a4, ptr %t29
  %t31 = getelementptr %"compiler/check:ContractAsk", ptr %l30, i32 0, i32 5
  store { i64, ptr } %a5, ptr %t31, !tbaa !27
  %t33 = getelementptr %"compiler/check:ContractAsk", ptr %l30, i32 0, i32 6
  store { i64, ptr } %a6, ptr %t33, !tbaa !27
  %t35 = getelementptr %"compiler/check:ContractAsk", ptr %l30, i32 0, i32 7
  store { i64, [3 x i64] } %a7, ptr %t35
  %t37 = getelementptr %"compiler/check:ContractAsk", ptr %l30, i32 0, i32 8
  store { i64, ptr } %a8, ptr %t37, !tbaa !27
  %t39 = getelementptr %"compiler/check:ContractAsk", ptr %l30, i32 0, i32 9
  store { i64, ptr } %a9, ptr %t39, !tbaa !27
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l30, i64 136, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/check:reflList" @compiler_2fcheck_3areflList_2ector(ptr %v0, i1 %a0, i32 %a1, i64 %a2, i64 %a3) #0 {
entry:
  %rv = alloca %"compiler/check:reflList"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/check:reflList" undef, i1 %a0, 0
  %t12 = insertvalue %"compiler/check:reflList" %t10, i32 %a1, 1
  %t14 = insertvalue %"compiler/check:reflList" %t12, i64 %a2, 2
  %t16 = insertvalue %"compiler/check:reflList" %t14, i64 %a3, 3
  store %"compiler/check:reflList" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:reflList", ptr %rv
  ret %"compiler/check:reflList" %rr
}

define dso_local %"compiler/check:roFn" @compiler_2fcheck_3aroFn_2ector(ptr %v0, ptr %v1, i64 %a0, i64 %a1, { i64, [3 x i64] } %a2, { i64, ptr } %a3) #0 {
entry:
  %rv = alloca %"compiler/check:roFn"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/check:roFn" undef, i64 %a0, 0
  %t12 = insertvalue %"compiler/check:roFn" %t10, i64 %a1, 1
  %t14 = insertvalue %"compiler/check:roFn" %t12, { i64, [3 x i64] } %a2, 2
  %t16 = insertvalue %"compiler/check:roFn" %t14, { i64, ptr } %a3, 3
  store %"compiler/check:roFn" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:roFn", ptr %rv
  ret %"compiler/check:roFn" %rr
}

define dso_local %"compiler/check:tailAsk" @compiler_2fcheck_3atailAsk_2ector(ptr %v0, i64 %a0, i64 %a1, %"compiler/source:Span" %a2, i64 %a3) #0 {
entry:
  %rv = alloca %"compiler/check:tailAsk"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/check:tailAsk" undef, i64 %a0, 0
  %t12 = insertvalue %"compiler/check:tailAsk" %t10, i64 %a1, 1
  %t14 = insertvalue %"compiler/check:tailAsk" %t12, %"compiler/source:Span" %a2, 2
  %t16 = insertvalue %"compiler/check:tailAsk" %t14, i64 %a3, 3
  store %"compiler/check:tailAsk" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:tailAsk", ptr %rv
  ret %"compiler/check:tailAsk" %rr
}

define dso_local %"compiler/check:unsetCand" @compiler_2fcheck_3aunsetCand_2ector(ptr %v0, i64 %a0, i64 %a1, i64 %a2, i1 %a3, i64 %a4, %"compiler/source:Span" %a5, i32 %a6, i1 %a7) #0 {
entry:
  %rv = alloca %"compiler/check:unsetCand"
  br label %start
start:
  br label %bb0
bb0:
  %t18 = insertvalue %"compiler/check:unsetCand" undef, i64 %a0, 0
  %t20 = insertvalue %"compiler/check:unsetCand" %t18, i64 %a1, 1
  %t22 = insertvalue %"compiler/check:unsetCand" %t20, i64 %a2, 2
  %t24 = insertvalue %"compiler/check:unsetCand" %t22, i1 %a3, 3
  %t26 = insertvalue %"compiler/check:unsetCand" %t24, i64 %a4, 4
  %t28 = insertvalue %"compiler/check:unsetCand" %t26, %"compiler/source:Span" %a5, 5
  %t30 = insertvalue %"compiler/check:unsetCand" %t28, i32 %a6, 6
  %t32 = insertvalue %"compiler/check:unsetCand" %t30, i1 %a7, 7
  store %"compiler/check:unsetCand" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:unsetCand", ptr %rv
  ret %"compiler/check:unsetCand" %rr
}

declare void @__olang_check_failed(ptr) cold noreturn
@.d0 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"LeadingZeros" }>, align 8
@.d1 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"TrailingZeros" }>, align 8
@.d2 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"PopCount" }>, align 8
@.d3 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"RotateLeft" }>, align 8
@.d4 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"RotateRight" }>, align 8
@.d5 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"ByteSwap" }>, align 8
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare void @__olang_ert_req_clear()
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d6 = private constant <{ i64, [50 x i8] }> <{ i64 0, [50 x i8] c"it introduces a type variable, which no zero binds" }>, align 8
declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fsource_3aSpan(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = getelementptr %"compiler/source:Span", ptr %t1, i32 0, i32 0
  %t3 = load i32, ptr %t2, !tbaa !23
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t5 = getelementptr %"compiler/source:Span", ptr %t4, i32 0, i32 0
  %t6 = load i32, ptr %t5, !tbaa !23
  %t9 = icmp eq i32 %t3, %t6
  br i1 %t9, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb4
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/source:Span", ptr %t11, i32 0, i32 1
  %t13 = load i32, ptr %t12, !tbaa !23
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr %"compiler/source:Span", ptr %t14, i32 0, i32 1
  %t16 = load i32, ptr %t15, !tbaa !23
  %t19 = icmp eq i32 %t13, %t16
  br i1 %t19, label %bb3, label %bb1
bb3:
  br label %bb4
bb4:
  %t21 = load i1, ptr %l2, !tbaa !21
  store i1 %t21, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d7 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d8 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"comptime." }>, align 8
@.d9 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d10 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d11 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d12 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d13 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d14 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d15 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d16 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d17 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"\22\22" }>, align 8
@.d18 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"Array<" }>, align 8
@.d19 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c">(0)" }>, align 8
@.d20 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d21 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d22 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"!=" }>, align 8
@.d23 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"==" }>, align 8
@__olang_prog_scope = external thread_local(initialexec) global ptr
@.d24 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d25 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c".Len() > 0" }>, align 8
@.d26 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c".Len() == 0" }>, align 8
@.d27 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"true" }>, align 8
@.d28 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"false" }>, align 8
@.d29 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Some" }>, align 8
@.d30 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"Every" }>, align 8
@.d31 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d32 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"()'" }>, align 8
@.d33 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Sum" }>, align 8
@.d34 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Some" }>, align 8
@.d35 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"Every" }>, align 8
@.d36 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Some" }>, align 8
@.d37 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"std/prelude/array" }>, align 8
@.d38 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"ArrayError" }>, align 8
@.d39 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"EMPTY" }>, align 8
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@.d40 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Min" }>, align 8
@.d41 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"std/prelude/iterator" }>, align 8
@.d42 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"Exhausted" }>, align 8
@.d43 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"if" }>, align 8
@.d44 = private constant <{ i64, [52 x i8] }> <{ i64 0, [52 x i8] c"a match on a type leaving from its chosen case (G15)" }>, align 8
@.d45 = private constant <{ i64, [54 x i8] }> <{ i64 0, [54 x i8] c"a match on a length leaving from its chosen case (G30)" }>, align 8
@.d46 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d47 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"s" }>, align 8
define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.d48 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
@.d49 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"case" }>, align 8
@.d50 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"parameter" }>, align 8
@.d51 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"result" }>, align 8
@.d52 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"Of" }>, align 8
@.d53 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"its Name and Type" }>, align 8
@.d54 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"'s " }>, align 8
@.d55 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"F64" }>, align 8
@.d56 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"String" }>, align 8
@.d57 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"Fields" }>, align 8
@.d58 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"Cases" }>, align 8
@.d59 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"Params" }>, align 8
@.d60 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"Results" }>, align 8
@.d61 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"Methods" }>, align 8
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %a0)
declare i1 @compiler_2fcheck_2eisHexDigit(i8 %a0)
@olang_loc_b418a15f1455a8e1_40cdd11b1c753e15 = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_a3fc486149a2dc5d_17491af4361141b9 = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einfersErrs(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_H2251bc8fca359ca0394d0bb11af7ba0a(ptr %v0, ptr %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ezeroCalls(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisStruct(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorVars(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoZeroValue(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/msgs:Msg" %a2)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCount(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aGap_3e_2eLen_3ccompiler_2fcheck_3aGap_3e(ptr %v0, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i32 %a3, i32 %a4, i64 %a5)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enewBody(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, i32 %a2, i64 %a3, %"compiler/source:Span" %a4)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i32 %a3, i32 %a4)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %a0)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddBlock(ptr %v0, ptr %a0, i32 %a1, i32 %a2, %"compiler/source:Span" %a3)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitCtor(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ezero(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v1, i32 %a0, { i64, ptr } %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %a0)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eForget(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aGap_3e_2eTruncate_3ccompiler_2fcheck_3aGap_3e(ptr %v0, ptr %a0, i64 %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, [3 x i64] } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eUseOf(ptr %v0, ptr %a0, { i64, [3 x i64] } %a1)
declare %"compiler/check:ValueAsk" @compiler_2fcheck_3aValueAsk_2ector(ptr %v0, i32 %a0, i64 %a1, %"compiler/source:Span" %a2, i32 %a3, i64 %a4, { i64, [3 x i64] } %a5)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aValueAsk_3e_2ePush_3ccompiler_2fcheck_3aValueAsk_3e(ptr %v0, ptr %a0, %"compiler/check:ValueAsk" %a1)
declare { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmtsOf(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i64 %a3, i64 %a4)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/generic:Desc" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseDesc(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@G_2ecompiler_2fgeneric_2eDescCase = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enamesEnumOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCaseNames(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecasePublic(ptr %v0, ptr %a0, i32 %a1, i32 %a2, %"compiler/source:Span" %a3)
@olang_loc_276be77200b53441_cc6e235db38ae28d = external constant [0 x i8]
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_He6be2b0836caba7ddc59483ff74db438(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorSetItem(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrSetItems(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/typed:Item" @compiler_2ftyped_3aItem_2ector(ptr %v0, i32 %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aItem_3e_2ePush_3ccompiler_2ftyped_3aItem_3e(ptr %v0, ptr %a0, %"compiler/typed:Item" %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsErrVar(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorType(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsErrorSet(ptr %v0, ptr %a0, i32 %a1)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v0, i64 %a0)
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eEntriesOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, i32 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrorWord(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorItemKnown(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aClause_26_3e_2eAt_3ccompiler_2ftyped_3aClause_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecatchSpan(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCatchAfterCatchAll(ptr %v0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aClause_26_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aClause_26_3e_2ePush_Hc64f4d0e64077a33423ff9c4e583894f(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrWords(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleft(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCatchUnreachable(ptr %v0)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edefaultSpan(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefaultInStatement(ptr %v0)
@G_2ecompiler_2ftypes_2eVoidT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefaultNoValue(ptr %v0)
@olang_loc_20fb2e81a5b7d68a_7759df49ce89a9e = external constant [0 x i8]
declare i1 @compiler_2fcheck_2eleavesValue(ptr %v0, ptr %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefaultDead(ptr %v0)
declare i1 @compiler_2fcheck_2elastIsValue(ptr %v0, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCatchMustLeave(ptr %v0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefaultCount(ptr %v0, i64 %a0, i64 %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eGlobalDecl(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsSynth(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fsource_3aSpan_3e_2_H19fded22be32a91ca4084130356a325d(ptr %v0, ptr %a0, i64 %a1, %"compiler/source:Span" %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
@olang_loc_fa3c94e3a612a0dd_4761343759351551 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecomptimeCtx(ptr %v0, ptr %v1, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %v0, i64 %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H5696e1a008d256bf9453cde2b49c6c45(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecomptimeBody(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3, i64 %a4, i32 %a5)
declare { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H3cc70d507a7fc767d013b59b12ee0a99(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
@G_2ecompiler_2ftypes_2eReadOnly = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopyExpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eattrsChecked(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2)
@olang_loc_e375dcd56c8db7ae_8ebec7f18eafef7a = external constant [0 x i8]
@olang_loc_f43f80063d96068c_f8dacab5994fea88 = external constant [0 x i8]
@olang_loc_232d0577351be387_c741f4f8dd012e63 = external constant [0 x i8]
@olang_loc_f1a1025985678426_2b1dd11da3705062 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eReflUnder(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2fgeneric_2eDescField = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFieldNames(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCaseFieldNames(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i64 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrValCodes(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrValWordText(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i64 %a2)
@G_2ecompiler_2fgeneric_2eDescFunc = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00" }>, align 8
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2fgeneric_2eDescParam = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/generic:Desc" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDescOf(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorParams(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econd1(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebreakUnless(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eTruncate_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %a0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, i32 %a3, i32 %a4, { i64, [2 x i64] } %a5)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2)
declare i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eheldOf(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eBoolT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i64 %a3)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCaseSig(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3, ptr %a4, ptr %a5)
declare %"compiler/typed:Payload" @compiler_2ftyped_3aPayload_2ector(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eequality(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3, ptr %a4)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eand2(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3)
declare %"compiler/typed:Cond" @compiler_2ftyped_3aCond_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2)
declare %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, ptr %a1)
@olang_loc_fde34f6ad3d04e85_8bb8dc064f471149 = external constant [0 x i8]
@olang_loc_7e2870e38111b7d4_913a9c3a02b86678 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eescapeRules(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, i64 %a3)
declare %"compiler/check:factsMark" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efactsHeld(ptr %v0, ptr %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epushFacts(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2, i64 %a3)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efactsDrop(ptr %v0, ptr %a0, %"compiler/check:factsMark" %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_a78beee7b0d01a06_c23e8f3cd3901b22 = external constant [0 x i8]
@olang_loc_a9ac84188a5d3ced_8a30b05829c2589 = external constant [0 x i8]
@olang_loc_d343f6dbe85f33a0_61dfe5c423c7544c = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/check:Gap" @compiler_2fcheck_3aGap_2ector(ptr %v0, ptr %v1, i64 %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aGap_3e_2ePush_3ccompiler_2fcheck_3aGap_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/check:Gap" %a1)
declare %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclParams(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eMember(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
@olang_loc_369dcc443ccea639_2a432d0faa4fb925 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2eisNullLit(ptr %v0, ptr %a0)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebetween(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i64 %a3)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseWritten(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eIsOnlyNull(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eIsCaseWritten(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eIsNullOfNull(ptr %v0)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsErrVal(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrNonNull(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eErrNeverNull(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enegate(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eIsNullOfValue(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArrayRef(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eArrayIsNull(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNeverNull(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare ptr @compiler_2fcheck_2ereadPlace(ptr %v0, ptr %a0)
declare { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplaceAt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecalledAt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteNullableDecl(ptr %v0)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, [3 x i64] } %a2, %"compiler/msgs:Msg" %a3)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLeaves(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare %"compiler/check:laneNode" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alaneNode_3e_2eAt_3ccompiler_2fcheck_3alaneNode_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2fcheck_2eLaneArr = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneSay(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eLaneMaskBool(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/check:laneVals" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneSetup(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i64 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneCount(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, ptr %a3)
declare { i64, i64, i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLoopOpen(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneElem(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, ptr %a3, ptr %a4)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopValues(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, ptr %a4, ptr %a5, %"compiler/source:Span" %a6, %"compiler/source:Span" %a7)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLoopClose(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, i64 %a3, i64 %a4, i64 %a5, i64 %a6)
declare %"compiler/typed:If" @compiler_2ftyped_3aIf_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epreludeWord(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efailOp(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, %"compiler/source:Span" %a2, i1 %a3)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eone(ptr %v0, ptr %a0, ptr %a1)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eHold(ptr %v0, ptr %a0)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eEndHold(ptr %v0, ptr %a0)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eDrop(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConst(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %a0)
declare %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i32, %"compiler/source:Span" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H7d5384a5030fc995e793b3fe1f57e776(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteLiteralRangeExpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteLiteralRange(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteLiteralLocal(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePreludeType(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnyTrait(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnySlots(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eslotCall(ptr %v0, ptr %a0, i32 %a1, i64 %a2, %"compiler/source:Span" %a3)
@olang_loc_652199a1d15cfac6_f2a0b86627c88902 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallBody(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, ptr %a4, i64 %a5, ptr %a6, { i64, ptr } %a7, { i64, ptr } %a8)
@olang_loc_7509e56452997e5b_fb360af196d85db7 = external constant [0 x i8]
@olang_loc_ff81ff8210117a78_6f7a62fdc976c914 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i64 %a3, ptr %a4, { i64, ptr } %a5, { i64, ptr } %a6, { i64, ptr } %a7)
@olang_loc_77a5603a1298311f_4bb819fe8c7bb9e3 = external constant [0 x i8]
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esayUncovered(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, i32 %a2, ptr %a3, ptr %a4, i1 %a5)
@olang_loc_3cc47694b244d9ce_439392ee5cdf31e2 = external constant [0 x i8]
declare %"compiler/typed:Arm" @compiler_2ftyped_3aArm_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, %"compiler/source:Span" %a0, { i64, ptr } %a1, ptr %a2, ptr %a3, ptr %a4)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_3e_2ector(ptr %v0, i64 %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflType(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eReflMatchSubject(ptr %v0)
@olang_loc_775dfd67c7206a52_c2d8bc16e2444876 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewordBefore(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeMatchGuard(ptr %v0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3atypeCase_3e_2ector(ptr %v0, i64 %a0)
declare i1 @compiler_2fcheck_2eisWildType(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3atypeCase_3e_2eLen_3ccompiler_2fcheck_3atypeCase_3e(ptr %v0, ptr %a0)
declare %"compiler/check:typeCase" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3atypeCase_3e_2eAt_3ccompiler_2fcheck_3atypeCase_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v0, ptr %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eReflCaseUnreachable(ptr %v0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrorOncePerLine(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/msgs:Msg" %a2)
declare %"compiler/check:typeCase" @compiler_2fcheck_3atypeCase_2ector(ptr %v0, i1 %a0, i1 %a1, i32 %a2, i64 %a3)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3atypeCase_3e_2ePush_3ccompiler_2fcheck_3atypeCase_3e(ptr %v0, ptr %a0, %"compiler/check:typeCase" %a1)
declare %"compiler/check:typeCase" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeCaseOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeCaseCovers(ptr %v0, ptr %a0, %"compiler/check:typeCase" %a1, %"compiler/check:typeCase" %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeCaseHolds(ptr %v0, ptr %v1, ptr %a0, %"compiler/check:typeCase" %a1, i32 %a2, ptr %a3)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeMatchUncovered(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrMatch(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtMatchValue(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebindCase(ptr %v0, ptr %v1, ptr %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunbindCase(ptr %v0, ptr %v1, ptr %a0, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflMatch(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elenMatch(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eMatchValueNone(ptr %v0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ematchExpr(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i1 %a3, i32 %a4)
declare i1 @compiler_2fcheck_2ehasNamed(ptr %v0, { i64, ptr } %a0)
@olang_loc_2a22705e3675cc6a_15625908cbc104fe = external constant [0 x i8]
@olang_loc_e03e15fa1ad8573f_767a3f28b3ff5a33 = external constant [0 x i8]
@olang_loc_f1d5d3b2155f2ddc_ad13ea37e14bc210 = external constant [0 x i8]
declare %"compiler/msgs:Nearest" @compiler_2fmsgs_3aNearest_2ector(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fmsgs_2ecompiler_2fmsgs_3aNearest_2eOffer(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNamedArgUnknownMeant(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNamedArgUnknown(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNamedArgRequired(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNamedArgTwice(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNamedArgAlsoPositional(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2ePositionalAfterNamed(ptr %v0)
@olang_loc_6a354e0ae5aa0db2_42d5d79e5424950e = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eArgCount(ptr %v0, ptr %v1, i64 %a0, { i64, ptr } %a1, i64 %a2)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2eToArray_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anullNarrow_3e_2eLen_H4b13e48b0a317e727dbe35330ad8712a(ptr %v0, ptr %a0)
declare %"compiler/check:nullNarrow" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anullNarrow_3e_2eAt__H22e551fb00043bde3f1f8b2c6007f7cb(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2fcheck_2esamePath(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_3e_Hda4ef06466535e66801340e999dad217(ptr %v0, ptr %a0)
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_3e_H87a29777ccf22aa2985fa9d3c61f9cd3(ptr %v0, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %a0)
@olang_loc_eb65b3680edb0345_685145072e457a11 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eglobalDeps(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2)
@olang_loc_becd3eb77e076db3_2d856a700a1e74b7 = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eIndexOf_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aCycle(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i64 %a3)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erootLocal(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparamIndex(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisOver(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earraysEqual(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, i32 %a4)
declare %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_1f453287a90ee701_f75bf1e5be6f432d = external constant [0 x i8]
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H8da9376267bda3f76393292be0e507b2(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erunLength(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eDestructNotName(ptr %v0)
@olang_loc_fb06dcd16342dc9_94e70e479081575d = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ediscardOr(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v0, ptr %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTaskClauseError(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eDeferErrorEscapes(ptr %v0)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emsgOwner(ptr %v0, ptr %v1, ptr %a0, i1 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eAssertMsgError(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ename(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3, i1 %a4)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eRaiseNotCaught(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereraise(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euncovered(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eErrorUndeclared(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eErrorWordNotInSet(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleaks1(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparamDefault(ptr %v0, ptr %a0, %"compiler/generic:Desc" %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eReflNoDefault(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i32, { i64, ptr } } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDescType(ptr %v0, ptr %v1, ptr %a0, %"compiler/generic:Desc" %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edefaultArg(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, i64 %a3, i1 %a4, i32 %a5, i32 %a6)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorDefault(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, i32 %a3)
declare %"compiler/check:reflVal" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflFold(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
@G_2ecompiler_2fcheck_2eRvInt = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/check:reflVal" @compiler_2fcheck_2enoRefl(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eReflDescNoMember(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eReflOfArgs(ptr %v0, i64 %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplace(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enullRead(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eReflOfType(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrowLocal(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2eLen_3ccompiler_2fcheck_3anarrowed_3e(ptr %v0, ptr %a0)
declare %"compiler/check:narrowed" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2eAt_3ccompiler_2fcheck_3anarrowed_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eFieldOfEnum(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebracketIn(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
@olang_loc_860e4bd13e8a5221_206c5ac6505376ad = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroValue(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroKey(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroName(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_Hc59e30334647acda8fe9b2b02a632dfd(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, i32 %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroTrack(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eWritable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroRoot(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroTempBase(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroRead(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroPlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroCallRef(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2ftyped_2ePassesRefs(i32 %a0)
@olang_loc_62c5ac3e914a4019_8e197c98e172d865 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopAfter(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2)
@olang_loc_ddf5999d75afc0ea_2c71428eb0b518ce = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewriteBack(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3, ptr %a4, %"compiler/source:Span" %a5, i64 %a6, { i64, ptr } %a7)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotCapture(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eExtends(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estepMethod(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3, i1 %a4)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eStepNotNumber(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @compiler_2fcheck_2efloatBits(i32 %a0, double %a1)
declare { i64, ptr } @compiler_2fscan_2eLiteralBytes(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %a0)
@olang_loc_6b4c91049558e776_f5788538a01eee7a = external constant [0 x i8]
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etopSetDecls(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, { i64, ptr } %a2, i1 %a3, i1 %a4, ptr %a5)
@olang_loc_812bc6763f016bdd_ce6f0e3f96c00d01 = external constant [0 x i8]
@olang_loc_8d628e20c33cf608_43e2c14925cb83cc = external constant [0 x i8]
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %v0, i64 %a0)
declare void @compiler_2fcheck_2echainNames(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eAt_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_90c8334c62802427_4400025bac92e03b = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econdReads(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/source:Span" %a2, { i64, ptr } %a3)
@olang_loc_39ed54cf65861a3a_83e11e15934e9cb6 = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTopSetCondReads(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/msgs:Msg" %a2)
@olang_loc_39e926dc5bd50dc1_491eed70903c4c1d = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehasZero(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebranchesAssign(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, i32 %a3, i32 %a4)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorSig(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorNamed(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %v0, ptr %v1, ptr %a0)
declare i64 @compiler_2fgeneric_2eCtorOwner(i32 %a0)
declare %"compiler/generic:Binding" @compiler_2fgeneric_3aBinding_2ector(ptr %v0, i64 %a0, i64 %a1)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ector(ptr %v0, i64 %a0)
declare %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitFloat(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunify(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, ptr %a3, i1 %a4, i1 %a5)
@olang_loc_86f2d648d7a819c5_fc1d6e84e063e4d9 = external constant [0 x i8]
@G_2ecompiler_2ftypes_2eNoreturnT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\11\00\00\00" }>, align 8
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebindType(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInferThroughBounds(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCtorVarsNotInferable(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorSigAt(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etwinBody(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetOrder(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eToArra_H50cbff9caa8a2389caf3e92da7e24507(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_e722c21055ee6b49_58bcebf0b772fb7d = external constant [0 x i8]
@olang_loc_eca48244095fc078_aacf4c954a6e214c = external constant [0 x i8]
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresolve(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistItems(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/check:reflList" %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edescriptor(ptr %v0, ptr %a0, %"compiler/check:reflList" %a1, i64 %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflBind(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflDecide(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_ef99e54d7427d8e6_6c42201a9dddf792 = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eReflFilterUndecided(ptr %v0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
@G_2ecompiler_2fcheck_2eRoStored = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroStore(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2, i64 %a3)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflUnbind(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare %"compiler/typed:Make" @compiler_2ftyped_3aMake_2ector(ptr %v0, ptr %v1, ptr %v2, i32 %a0, i64 %a1, { i64, ptr } %a2, ptr %a3, i32 %a4, i32 %a5, i1 %a6)
declare i64 @compiler_2fcheck_2elimitIndex(ptr %v0, { i64, ptr } %a0)
@G_2ecompiler_2fgeneric_2eListFields = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fgeneric_2eListCases = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fgeneric_2eListParams = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fgeneric_2eListResults = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fgeneric_2eListMethods = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00" }>, align 8
@olang_loc_77a436a5c2d44065_8e586571f5cf09a9 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2epurePlace(ptr %v0, ptr %a0)
@olang_loc_327c34393f585585_f16c5fd873651789 = external constant [0 x i8]
declare void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fcheck_2estoredCase(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
