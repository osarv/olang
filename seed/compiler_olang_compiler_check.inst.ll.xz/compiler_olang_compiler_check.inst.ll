; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"std/list:listState.9783095779ea18337775adeb6569839d" = type { { i64, ptr }, { i64, ptr }, i64, i64, { i64, ptr }, i64, i64, i64 }
%"std/pair:Pair.0eea5a06f8f0107e600fd23235f2e98f" = type { %"compiler/generic:Origin", i64 }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64 }
%"compiler/source:Span" = type { i32, i32 }
%"std/pair:Pair.91de8c8eb84d52d1e58996aec31d85aa" = type { i32, i32 }
%"std/prelude/map:MapEntry.eb00e4a6e4307a4e46e40fbcd79d6b4f" = type { i64, i1 }
%"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50" = type { { i64, ptr }, i64, ptr }
%"std/prelude/map:mapSlot.bf8e2f5a99d2ad08487ec11f6be9b652" = type { %"std/prelude/map:MapEntry.eb00e4a6e4307a4e46e40fbcd79d6b4f", ptr }
%"std/prelude/map:mapSlot.727a518559d2b598d6ef289c4e704dc3" = type { %"std/prelude/map:MapEntry.457163fdec6e9d9dd96e1de2e7dfe82b", ptr }
%"std/prelude/map:MapEntry.457163fdec6e9d9dd96e1de2e7dfe82b" = type { i64, { i64, [3 x i64] } }
%"std/prelude/map:MapEntry.30ce370d829aff239a34c06a62e67c2e" = type { i64, %"compiler/typed:ContractInfo" }
%"compiler/typed:ContractInfo" = type { { i64, ptr }, i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"std/prelude/map:mapSlot.0482058481105505dc7df18be1ecde54" = type { %"std/prelude/map:MapEntry.30ce370d829aff239a34c06a62e67c2e", ptr }
%"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" = type { i32, i32 }
%"std/prelude/map:mapSlot.79a9cb365fafee3b3ee9688fef10964d" = type { %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa", ptr }
%"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" = type { i64, i64 }
%"std/prelude/map:mapSlot.ab8e368d2e26ea985fc81f522ce8ac91" = type { %"std/prelude/map:MapEntry.adf118859e04490c36a9a3f2e59cf058", ptr }
%"std/prelude/map:MapEntry.adf118859e04490c36a9a3f2e59cf058" = type { %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", { i64, ptr } }
%"compiler/check:fixedInit" = type { ptr, i32 }
%"std/prelude/map:mapSlot.8d5f4b852d3f9c4d7ccf5e7675d9833d" = type { %"std/prelude/map:MapEntry.c479befe3d340af6fb5e3e84080d9cfc", ptr }
%"std/prelude/map:MapEntry.c479befe3d340af6fb5e3e84080d9cfc" = type { %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", %"compiler/check:fixedInit" }
%"std/prelude/map:mapSlot.68a4db19b59c4f3946b7eb69de485429" = type { %"std/prelude/map:MapEntry.886e108519677d9fd0a73cc9f7e545eb", ptr }
%"std/prelude/map:MapEntry.886e108519677d9fd0a73cc9f7e545eb" = type { %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", i32 }
%"std/prelude/map:mapSlot.a04f5d5eeace3a348c0931984fa7d629" = type { %"std/prelude/map:MapEntry.ecf182cf123eba82aed5d6288e5f1385", ptr }
%"std/prelude/map:MapEntry.ecf182cf123eba82aed5d6288e5f1385" = type { %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/check:roOrigin" = type { ptr, i1 }
%"std/prelude/map:mapSlot.fb4da8fc57bf420be68a6f6108589d27" = type { %"std/prelude/map:MapEntry.cae77de4d581cc3ff23f947d2513f613", ptr }
%"std/prelude/map:MapEntry.cae77de4d581cc3ff23f947d2513f613" = type { %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", %"compiler/check:roOrigin" }
%"std/prelude/map:MapEntry.1eb2466213689e002f25e81e83536e78" = type { i64, ptr }
%"std/prelude/map:mapSlot.13b431b0462eb7c9b33f2a6ba793b9e3" = type { %"std/prelude/map:MapEntry.1eb2466213689e002f25e81e83536e78", ptr }
%"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"compiler/check:Ask" = type { i64, i64, i32, ptr, i64, { i64, ptr } }
%"compiler/check:AssertAsk" = type { i64, i64, %"compiler/source:Span", %"compiler/source:Span", i64, i64, { i64, ptr }, { i64, [3 x i64] }, { i64, ptr } }
%"compiler/check:ContractAsk" = type { i64, i64, %"compiler/source:Span", i64, %"compiler/source:Span", { i64, ptr }, { i64, ptr }, { i64, [3 x i64] }, { i64, ptr }, { i64, ptr } }
%"compiler/check:EmbedAsk" = type { i64, i64, i32 }
%"compiler/check:Gap" = type { i64, %"compiler/source:Span", { i64, ptr } }
%"compiler/check:ValueAsk" = type { i32, i64, %"compiler/source:Span", i32, i64, { i64, [3 x i64] } }
%"compiler/check:atRec" = type { i64, i64, ptr, i32 }
%"compiler/check:errBind" = type { i32, i64, i32, %"compiler/source:Span" }
%"compiler/check:errNarrow" = type { i64, i32, i64 }
%"compiler/check:laneNode" = type { i64, i32, %"compiler/source:Span", %"compiler/source:Span", i64, i64, i64, ptr, i32, i64, i32 }
%"compiler/check:narrowed" = type { i64, i64, i32, i64, i64 }
%"compiler/check:nullNarrow" = type { { i64, ptr }, i64, i1 }
%"compiler/check:roArg" = type { i64, i64, { i64, [3 x i64] }, { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/check:roDeepArg" = type { i64, ptr, i64, i64 }
%"compiler/check:roFn" = type { i64, i64, { i64, [3 x i64] }, { i64, ptr } }
%"compiler/check:typeCase" = type { i1, i1, i32, i64, i64, i1 }
%"compiler/typed:Item" = type { i32, i64 }
%"compiler/typed:ScopeRel" = type { i64, i64, %"compiler/source:Span" }
%"std/pair:Pair.1eb2466213689e002f25e81e83536e78" = type { i64, ptr }
define dso_local void @std_2flist_2estd_2flist_3aList_3ccompiler_2ftyped_3aExpr_3f_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_3f_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l17 = alloca ptr
  %l20 = alloca ptr
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = getelementptr %"std/list:listState.9783095779ea18337775adeb6569839d", ptr %t6, i32 0, i32 5
  %t9 = load i64, ptr %t8, !tbaa !24
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr %"std/list:listState.9783095779ea18337775adeb6569839d", ptr %t10, i32 0, i32 6
  %t13 = load i64, ptr %t12, !tbaa !24
  %t16 = icmp eq i64 %t9, %t13
  br i1 %t16, label %bb1, label %bb2
bb1:
  %t18 = load ptr, ptr %l2, !tbaa !29
  %t19 = load ptr, ptr %l1, !tbaa !29
  call void @std_2flist_2estd_2flist_3alistState_3ccompiler_2ftyped_3aExpr_3f_26_3e_2egrow_3ccompiler_2ftyped_3aExpr_3f_26_3e(ptr %v0, ptr %v1, ptr %t18, ptr %t19)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t22 = load ptr, ptr %l2, !tbaa !29
  %t24 = getelementptr %"std/list:listState.9783095779ea18337775adeb6569839d", ptr %t22, i32 0, i32 4
  %t25 = load { i64, ptr }, ptr %t24, !tbaa !27
  store { i64, ptr } %t25, ptr %l13, !tbaa !27
  %t26 = load ptr, ptr %l2, !tbaa !29
  %t28 = getelementptr %"std/list:listState.9783095779ea18337775adeb6569839d", ptr %t26, i32 0, i32 5
  %t29 = load i64, ptr %t28, !tbaa !24
  %t30 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = getelementptr ptr, ptr %t34, i64 %t29
  store ptr %t30, ptr %t35, !tbaa !39
  %t36 = load ptr, ptr %l2, !tbaa !29
  store ptr %t36, ptr %l17, !tbaa !29
  %t37 = load ptr, ptr %l17, !tbaa !29
  %t38 = getelementptr %"std/list:listState.9783095779ea18337775adeb6569839d", ptr %t37, i32 0, i32 5
  %t39 = load i64, ptr %t38, !tbaa !24
  %t41 = add i64 %t39, 1
  %t43 = load ptr, ptr %l17, !tbaa !29
  %t44 = getelementptr %"std/list:listState.9783095779ea18337775adeb6569839d", ptr %t43, i32 0, i32 5
  store i64 %t41, ptr %t44, !tbaa !24
  %t45 = load ptr, ptr %l2, !tbaa !29
  store ptr %t45, ptr %l20, !tbaa !29
  %t46 = load ptr, ptr %l20, !tbaa !29
  %t47 = getelementptr %"std/list:listState.9783095779ea18337775adeb6569839d", ptr %t46, i32 0, i32 7
  %t48 = load i64, ptr %t47, !tbaa !24
  %t50 = add i64 %t48, 1
  %t52 = load ptr, ptr %l20, !tbaa !29
  %t53 = getelementptr %"std/list:listState.9783095779ea18337775adeb6569839d", ptr %t52, i32 0, i32 7
  store i64 %t50, ptr %t53, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @std_2flist_2estd_2flist_3aList_3ccompiler_2ftyped_3aExpr_3f_26_3e_2eToArray_3ccompiler_2ftyped_3aExpr_3f_26_3e(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l27 = alloca i64
  %l29 = alloca { i64, ptr }
  %l30 = alloca ptr
  %l39 = alloca i64
  %l42 = alloca i64
  %l62 = alloca { i64, ptr }
  %l76 = alloca i64
  %l79 = alloca i64
  %l97 = alloca { i64, ptr }
  %l101 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  %t44 = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l1, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = getelementptr %"std/list:listState.9783095779ea18337775adeb6569839d", ptr %t6, i32 0, i32 7
  %t9 = load i64, ptr %t8, !tbaa !24
  %t11 = icmp eq i64 %t9, 0
  br i1 %t11, label %bb1, label %bb2
bb1:
  %t13 = icmp sge i64 0, 0
  br i1 %t13, label %bb3, label %bb4
bb2:
  br label %bb7
bb3:
  %t15 = icmp sle i64 0, 1152921504606846975
  br i1 %t15, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_f08d1cd84d5664bf_7f8b445f2be8b9e3)
  unreachable
bb5:
  %t17 = mul i64 0, 8
  %t18 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t17)
  %t19 = insertvalue { i64, ptr } undef, i64 0, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  store { i64, ptr } %t20, ptr %rv
  br label %ret
bb6:
  call void @__olang_check_failed(ptr @olang_loc_f08d1cd84d5664bf_7f8b445f2be8b9e3)
  unreachable
bb7:
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr %"std/list:listState.9783095779ea18337775adeb6569839d", ptr %t22, i32 0, i32 7
  %t25 = load i64, ptr %t24, !tbaa !24
  store i64 %t25, ptr %l27, !tbaa !24
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t28 = getelementptr %"std/list:listState.9783095779ea18337775adeb6569839d", ptr %t26, i32 0, i32 1
  %t29 = load { i64, ptr }, ptr %t28, !tbaa !27
  store { i64, ptr } %t29, ptr %l29, !tbaa !27
  %t30 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !27
  %t32 = getelementptr ptr, ptr %t31, i64 0
  %t33 = load ptr, ptr %t32, !tbaa !39
  store ptr %t33, ptr %l30, !tbaa !29
  %t34 = load i64, ptr %l27, !tbaa !24
  %t35 = icmp sge i64 %t34, 0
  br i1 %t35, label %bb8, label %bb9
bb8:
  %t37 = load i64, ptr %l27, !tbaa !24
  %t38 = icmp sle i64 %t37, 1152921504606846975
  br i1 %t38, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_3a71773c68f3d9ea_62ce35ef480fba6e)
  unreachable
bb10:
  %t40 = load i64, ptr %l27, !tbaa !24
  %t41 = mul i64 %t40, 8
  %t42 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t41)
  %t43 = load ptr, ptr %l30, !tbaa !29
  store i64 0, ptr %t44
  br label %fill.45
fill.45:
  %t48 = load i64, ptr %t44
  %t49 = icmp slt i64 %t48, %t40
  br i1 %t49, label %fillb.46, label %filld.47
fillb.46:
  %t50 = getelementptr ptr, ptr %t42, i64 %t48
  store ptr %t43, ptr %t50
  %t51 = add i64 %t48, 1
  store i64 %t51, ptr %t44
  br label %fill.45
filld.47:
  %t52 = insertvalue { i64, ptr } undef, i64 %t40, 0
  %t53 = insertvalue { i64, ptr } %t52, ptr %t42, 1
  store { i64, ptr } %t53, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  store i64 0, ptr %l4, !tbaa !24
  %t55 = load ptr, ptr %l1, !tbaa !29
  %t57 = getelementptr %"std/list:listState.9783095779ea18337775adeb6569839d", ptr %t55, i32 0, i32 2
  %t58 = load i64, ptr %t57, !tbaa !24
  store i64 %t58, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t60 = load i64, ptr %l5, !tbaa !24
  %t61 = load i64, ptr %l4, !tbaa !24
  %t64 = icmp sgt i64 %t60, %t61
  br i1 %t64, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_3a71773c68f3d9ea_62ce35ef480fba6e)
  unreachable
bb12:
  %t66 = load i64, ptr %l6, !tbaa !24
  %t68 = icmp sgt i64 %t66, 0
  br i1 %t68, label %bb14, label %bb15
bb13:
  store i64 0, ptr %l39, !tbaa !24
  br label %bb17
bb14:
  %t70 = load i64, ptr %l5, !tbaa !24
  %t71 = load i64, ptr %l4, !tbaa !24
  %t74 = sub i64 %t70, %t71
  %t75 = load i64, ptr %l6, !tbaa !24
  %t78 = add i64 %t74, %t75
  %t80 = sub i64 %t78, 1
  %t81 = load i64, ptr %l6, !tbaa !24
  %t84 = sdiv i64 %t80, %t81
  store i64 %t84, ptr %l42, !tbaa !24
  br label %bb16
bb15:
  store i64 0, ptr %l42, !tbaa !24
  br label %bb16
bb16:
  %t86 = load i64, ptr %l42, !tbaa !24
  store i64 %t86, ptr %l39, !tbaa !24
  br label %bb17
bb17:
  %t87 = load i64, ptr %l39, !tbaa !24
  store i64 %t87, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb18
bb18:
  %t88 = load i64, ptr %l8, !tbaa !24
  %t89 = load i64, ptr %l7, !tbaa !24
  %t92 = icmp slt i64 %t88, %t89
  %t94 = xor i1 %t92, true
  br i1 %t94, label %bb19, label %bb20
bb19:
  br label %bb39
bb20:
  br label %bb21
bb21:
  %t96 = load i64, ptr %l4, !tbaa !24
  %t97 = load i64, ptr %l8, !tbaa !24
  %t98 = load i64, ptr %l6, !tbaa !24
  %t101 = mul i64 %t97, %t98
  %t104 = add i64 %t96, %t101
  store i64 %t104, ptr %l9, !tbaa !24
  %t106 = load ptr, ptr %l1, !tbaa !29
  %t107 = load i64, ptr %l9, !tbaa !24
  %t110 = call { i64, ptr } @std_2flist_2estd_2flist_3alistState_3ccompiler_2ftyped_3aExpr_3f_26_3e_2echunk_3ccompiler_2ftyped_3aExpr_3f_26_3e(ptr %v0, ptr %t106, i64 %t107)
  store { i64, ptr } %t110, ptr %l62
  br label %bb22
bb22:
  %t111 = load { i64, ptr }, ptr %l62, !tbaa !27
  store { i64, ptr } %t111, ptr %l10, !tbaa !27
  %t112 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t112, 0
  store i64 %t114, ptr %l11, !tbaa !24
  %t116 = load i64, ptr %l9, !tbaa !24
  %t117 = load ptr, ptr %l1, !tbaa !29
  %t119 = getelementptr %"std/list:listState.9783095779ea18337775adeb6569839d", ptr %t117, i32 0, i32 2
  %t120 = load i64, ptr %t119, !tbaa !24
  %t122 = sub i64 %t120, 1
  %t125 = icmp eq i64 %t116, %t122
  br i1 %t125, label %bb23, label %bb24
bb23:
  %t127 = load ptr, ptr %l1, !tbaa !29
  %t129 = getelementptr %"std/list:listState.9783095779ea18337775adeb6569839d", ptr %t127, i32 0, i32 5
  %t130 = load i64, ptr %t129, !tbaa !24
  store i64 %t130, ptr %l11, !tbaa !24
  br label %bb25
bb24:
  br label %bb25
bb25:
  store i64 0, ptr %l12, !tbaa !24
  %t132 = load i64, ptr %l11, !tbaa !24
  store i64 %t132, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t134 = load i64, ptr %l13, !tbaa !24
  %t135 = load i64, ptr %l12, !tbaa !24
  %t138 = icmp sgt i64 %t134, %t135
  br i1 %t138, label %bb26, label %bb27
bb26:
  %t140 = load i64, ptr %l14, !tbaa !24
  %t142 = icmp sgt i64 %t140, 0
  br i1 %t142, label %bb28, label %bb29
bb27:
  store i64 0, ptr %l76, !tbaa !24
  br label %bb31
bb28:
  %t144 = load i64, ptr %l13, !tbaa !24
  %t145 = load i64, ptr %l12, !tbaa !24
  %t148 = sub i64 %t144, %t145
  %t149 = load i64, ptr %l14, !tbaa !24
  %t152 = add i64 %t148, %t149
  %t154 = sub i64 %t152, 1
  %t155 = load i64, ptr %l14, !tbaa !24
  %t158 = sdiv i64 %t154, %t155
  store i64 %t158, ptr %l79, !tbaa !24
  br label %bb30
bb29:
  store i64 0, ptr %l79, !tbaa !24
  br label %bb30
bb30:
  %t160 = load i64, ptr %l79, !tbaa !24
  store i64 %t160, ptr %l76, !tbaa !24
  br label %bb31
bb31:
  %t161 = load i64, ptr %l76, !tbaa !24
  store i64 %t161, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb32
bb32:
  %t162 = load i64, ptr %l16, !tbaa !24
  %t163 = load i64, ptr %l15, !tbaa !24
  %t166 = icmp slt i64 %t162, %t163
  %t168 = xor i1 %t166, true
  br i1 %t168, label %bb33, label %bb34
bb33:
  br label %bb37
bb34:
  br label %bb35
bb35:
  %t170 = load i64, ptr %l12, !tbaa !24
  %t171 = load i64, ptr %l16, !tbaa !24
  %t172 = load i64, ptr %l14, !tbaa !24
  %t175 = mul i64 %t171, %t172
  %t178 = add i64 %t170, %t175
  store i64 %t178, ptr %l17, !tbaa !24
  %t180 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t180, ptr %l97, !tbaa !27
  %t181 = load i64, ptr %l3, !tbaa !24
  %t182 = load i64, ptr %l17, !tbaa !24
  %t185 = add i64 %t181, %t182
  %t186 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t186, ptr %l101, !tbaa !27
  %t187 = load i64, ptr %l17, !tbaa !24
  %t189 = getelementptr { i64, ptr }, ptr %l101, i32 0, i32 1
  %t190 = load ptr, ptr %t189, !tbaa !27
  %t191 = getelementptr ptr, ptr %t190, i64 %t187
  %t192 = load ptr, ptr %t191, !tbaa !39
  %t195 = getelementptr { i64, ptr }, ptr %l97, i32 0, i32 1
  %t196 = load ptr, ptr %t195, !tbaa !27
  %t197 = getelementptr ptr, ptr %t196, i64 %t185
  store ptr %t192, ptr %t197, !tbaa !39
  br label %bb36
bb36:
  %t198 = load i64, ptr %l16, !tbaa !24
  %t200 = add i64 %t198, 1
  store i64 %t200, ptr %l16, !tbaa !24
  br label %bb32
bb37:
  %t202 = load i64, ptr %l3, !tbaa !24
  %t203 = load i64, ptr %l11, !tbaa !24
  %t206 = add i64 %t202, %t203
  store i64 %t206, ptr %l3, !tbaa !24
  br label %bb38
bb38:
  %t208 = load i64, ptr %l8, !tbaa !24
  %t210 = add i64 %t208, 1
  store i64 %t210, ptr %l8, !tbaa !24
  br label %bb18
bb39:
  %t212 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t212, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

@std_2flist_2estd_2flist_3aList_3ccompiler_2ftyped_3aPlace_3f_26_3e_2ePush_3ccompiler_2ftyped_3aPlace_3f_26_3e = dso_local alias void (ptr, ptr, ptr, ptr), ptr @std_2flist_2estd_2flist_3aList_3ccompiler_2ftyped_3aExpr_3f_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_3f_26_3e
@std_2flist_2estd_2flist_3aList_3ccompiler_2ftyped_3aPlace_3f_26_3e_2eToArray_3ccompiler_2ftyped_3aPlace_3f_26_3e = dso_local alias { i64, ptr } (ptr, ptr, ptr), ptr @std_2flist_2estd_2flist_3aList_3ccompiler_2ftyped_3aExpr_3f_26_3e_2eToArray_3ccompiler_2ftyped_3aExpr_3f_26_3e
define dso_local { i64, ptr } @std_2flist_2estd_2flist_3alistState_3ccompiler_2ftyped_3aExpr_3f_26_3e_2echunk_3ccompiler_2ftyped_3aExpr_3f_26_3e(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l7 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp eq i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"std/list:listState.9783095779ea18337775adeb6569839d", ptr %t5, i32 0, i32 1
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  store { i64, ptr } %t8, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"std/list:listState.9783095779ea18337775adeb6569839d", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  store { i64, ptr } %t13, ptr %l7, !tbaa !27
  %t14 = load i64, ptr %l1, !tbaa !24
  %t16 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr { i64, ptr }, ptr %t17, i64 %t14
  %t19 = load { i64, ptr }, ptr %t18, !tbaa !37
  store { i64, ptr } %t19, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @std_2flist_2estd_2flist_3alistState_3ccompiler_2ftyped_3aExpr_3f_26_3e_2egrow_3ccompiler_2ftyped_3aExpr_3f_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l14 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l22 = alloca ptr
  %l23 = alloca i64
  %l24 = alloca ptr
  %l36 = alloca ptr
  %l38 = alloca { i64, ptr }
  %l50 = alloca i64
  %l52 = alloca { i64, ptr }
  %l61 = alloca i64
  %l64 = alloca i64
  %l82 = alloca { i64, ptr }
  %l85 = alloca { i64, ptr }
  %l93 = alloca { i64, ptr }
  %l95 = alloca i64
  %l98 = alloca i64
  %l99 = alloca i64
  %l100 = alloca ptr
  %l106 = alloca { i64, ptr }
  %l110 = alloca ptr
  %l113 = alloca ptr
  %t54 = alloca i64
  %t104 = alloca i64
  %t137 = alloca i64
  %t253 = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/list:listState.9783095779ea18337775adeb6569839d", ptr %t1, i32 0, i32 2
  %t4 = load i64, ptr %t3, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"std/list:listState.9783095779ea18337775adeb6569839d", ptr %t5, i32 0, i32 3
  %t8 = load i64, ptr %t7, !tbaa !24
  %t11 = icmp slt i64 %t4, %t8
  br i1 %t11, label %bb1, label %bb2
bb1:
  %t13 = load ptr, ptr %l0, !tbaa !29
  store ptr %t13, ptr %l14, !tbaa !29
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"std/list:listState.9783095779ea18337775adeb6569839d", ptr %t15, i32 0, i32 2
  %t18 = load i64, ptr %t17, !tbaa !24
  %t21 = call { i64, ptr } @std_2flist_2estd_2flist_3alistState_3ccompiler_2ftyped_3aExpr_3f_26_3e_2echunk_3ccompiler_2ftyped_3aExpr_3f_26_3e(ptr %v0, ptr %t14, i64 %t18)
  store { i64, ptr } %t21, ptr %l18
  br label %bb3
bb2:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"std/list:listState.9783095779ea18337775adeb6569839d", ptr %t22, i32 0, i32 3
  %t25 = load i64, ptr %t24, !tbaa !24
  %t27 = icmp eq i64 %t25, 0
  br i1 %t27, label %bb4, label %bb5
bb3:
  %t29 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t30 = load ptr, ptr %l14, !tbaa !29
  %t31 = getelementptr %"std/list:listState.9783095779ea18337775adeb6569839d", ptr %t30, i32 0, i32 4
  store { i64, ptr } %t29, ptr %t31, !tbaa !27
  br label %bb41
bb4:
  %t32 = load ptr, ptr %l0, !tbaa !29
  store ptr %t32, ptr %l22, !tbaa !29
  %t33 = load i64, ptr @G_2estd_2flist_2efirstChunk, !tbaa !24
  store i64 %t33, ptr %l23, !tbaa !24
  %t34 = load ptr, ptr %l1, !tbaa !29
  store ptr %t34, ptr %l24, !tbaa !29
  %t35 = load i64, ptr %l23, !tbaa !24
  %t36 = icmp sge i64 %t35, 0
  br i1 %t36, label %bb6, label %bb7
bb5:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"std/list:listState.9783095779ea18337775adeb6569839d", ptr %t38, i32 0, i32 0
  %t41 = load { i64, ptr }, ptr %t40, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t41, 0
  %t45 = icmp eq i64 %t43, 0
  br i1 %t45, label %bb10, label %bb11
bb6:
  %t47 = load i64, ptr %l23, !tbaa !24
  %t48 = icmp sle i64 %t47, 1152921504606846975
  br i1 %t48, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_4ecb415fcfbe9b59_88114aadccd2637d)
  unreachable
bb8:
  %t50 = load i64, ptr %l23, !tbaa !24
  %t51 = mul i64 %t50, 8
  %t52 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t51)
  %t53 = load ptr, ptr %l24, !tbaa !29
  store i64 0, ptr %t54
  br label %fill.55
fill.55:
  %t58 = load i64, ptr %t54
  %t59 = icmp slt i64 %t58, %t50
  br i1 %t59, label %fillb.56, label %filld.57
fillb.56:
  %t60 = getelementptr ptr, ptr %t52, i64 %t58
  store ptr %t53, ptr %t60
  %t61 = add i64 %t58, 1
  store i64 %t61, ptr %t54
  br label %fill.55
filld.57:
  %t62 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t63 = insertvalue { i64, ptr } %t62, ptr %t52, 1
  %t65 = load ptr, ptr %l22, !tbaa !29
  %t66 = getelementptr %"std/list:listState.9783095779ea18337775adeb6569839d", ptr %t65, i32 0, i32 1
  store { i64, ptr } %t63, ptr %t66, !tbaa !27
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"std/list:listState.9783095779ea18337775adeb6569839d", ptr %t68, i32 0, i32 1
  %t71 = load { i64, ptr }, ptr %t70, !tbaa !27
  %t74 = getelementptr %"std/list:listState.9783095779ea18337775adeb6569839d", ptr %t67, i32 0, i32 4
  store { i64, ptr } %t71, ptr %t74, !tbaa !27
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"std/list:listState.9783095779ea18337775adeb6569839d", ptr %t75, i32 0, i32 3
  store i64 1, ptr %t77, !tbaa !24
  br label %bb40
bb9:
  call void @__olang_check_failed(ptr @olang_loc_4ecb415fcfbe9b59_88114aadccd2637d)
  unreachable
bb10:
  %t78 = load ptr, ptr %l0, !tbaa !29
  store ptr %t78, ptr %l36, !tbaa !29
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"std/list:listState.9783095779ea18337775adeb6569839d", ptr %t79, i32 0, i32 1
  %t82 = load { i64, ptr }, ptr %t81, !tbaa !27
  store { i64, ptr } %t82, ptr %l38, !tbaa !27
  %t83 = icmp sge i64 4, 0
  br i1 %t83, label %bb12, label %bb13
bb11:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"std/list:listState.9783095779ea18337775adeb6569839d", ptr %t85, i32 0, i32 3
  %t88 = load i64, ptr %t87, !tbaa !24
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"std/list:listState.9783095779ea18337775adeb6569839d", ptr %t89, i32 0, i32 0
  %t92 = load { i64, ptr }, ptr %t91, !tbaa !27
  %t94 = extractvalue { i64, ptr } %t92, 0
  %t97 = icmp eq i64 %t88, %t94
  br i1 %t97, label %bb16, label %bb17
bb12:
  %t99 = icmp sle i64 4, 576460752303423487
  br i1 %t99, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_34e5301f43e4e84c_cc350fb9ff4bb650)
  unreachable
bb14:
  %t101 = mul i64 4, 16
  %t102 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t101)
  %t103 = load { i64, ptr }, ptr %l38, !tbaa !27
  store i64 0, ptr %t104
  br label %fill.105
fill.105:
  %t108 = load i64, ptr %t104
  %t109 = icmp slt i64 %t108, 4
  br i1 %t109, label %fillb.106, label %filld.107
fillb.106:
  %t110 = getelementptr { i64, ptr }, ptr %t102, i64 %t108
  store { i64, ptr } %t103, ptr %t110
  %t111 = add i64 %t108, 1
  store i64 %t111, ptr %t104
  br label %fill.105
filld.107:
  %t112 = insertvalue { i64, ptr } undef, i64 4, 0
  %t113 = insertvalue { i64, ptr } %t112, ptr %t102, 1
  %t115 = load ptr, ptr %l36, !tbaa !29
  %t116 = getelementptr %"std/list:listState.9783095779ea18337775adeb6569839d", ptr %t115, i32 0, i32 0
  store { i64, ptr } %t113, ptr %t116, !tbaa !27
  br label %bb35
bb15:
  call void @__olang_check_failed(ptr @olang_loc_34e5301f43e4e84c_cc350fb9ff4bb650)
  unreachable
bb16:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"std/list:listState.9783095779ea18337775adeb6569839d", ptr %t117, i32 0, i32 3
  %t120 = load i64, ptr %t119, !tbaa !24
  %t122 = mul i64 %t120, 2
  store i64 %t122, ptr %l50, !tbaa !24
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"std/list:listState.9783095779ea18337775adeb6569839d", ptr %t123, i32 0, i32 1
  %t126 = load { i64, ptr }, ptr %t125, !tbaa !27
  store { i64, ptr } %t126, ptr %l52, !tbaa !27
  %t127 = load i64, ptr %l50, !tbaa !24
  %t128 = icmp sge i64 %t127, 0
  br i1 %t128, label %bb18, label %bb19
bb17:
  br label %bb34
bb18:
  %t130 = load i64, ptr %l50, !tbaa !24
  %t131 = icmp sle i64 %t130, 576460752303423487
  br i1 %t131, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_58092ffe9980adaf_794c3d04db71ce73)
  unreachable
bb20:
  %t133 = load i64, ptr %l50, !tbaa !24
  %t134 = mul i64 %t133, 16
  %t135 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t134)
  %t136 = load { i64, ptr }, ptr %l52, !tbaa !27
  store i64 0, ptr %t137
  br label %fill.138
fill.138:
  %t141 = load i64, ptr %t137
  %t142 = icmp slt i64 %t141, %t133
  br i1 %t142, label %fillb.139, label %filld.140
fillb.139:
  %t143 = getelementptr { i64, ptr }, ptr %t135, i64 %t141
  store { i64, ptr } %t136, ptr %t143
  %t144 = add i64 %t141, 1
  store i64 %t144, ptr %t137
  br label %fill.138
filld.140:
  %t145 = insertvalue { i64, ptr } undef, i64 %t133, 0
  %t146 = insertvalue { i64, ptr } %t145, ptr %t135, 1
  store { i64, ptr } %t146, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t150 = getelementptr %"std/list:listState.9783095779ea18337775adeb6569839d", ptr %t148, i32 0, i32 3
  %t151 = load i64, ptr %t150, !tbaa !24
  store i64 %t151, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t153 = load i64, ptr %l4, !tbaa !24
  %t154 = load i64, ptr %l3, !tbaa !24
  %t157 = icmp sgt i64 %t153, %t154
  br i1 %t157, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_58092ffe9980adaf_794c3d04db71ce73)
  unreachable
bb22:
  %t159 = load i64, ptr %l5, !tbaa !24
  %t161 = icmp sgt i64 %t159, 0
  br i1 %t161, label %bb24, label %bb25
bb23:
  store i64 0, ptr %l61, !tbaa !24
  br label %bb27
bb24:
  %t163 = load i64, ptr %l4, !tbaa !24
  %t164 = load i64, ptr %l3, !tbaa !24
  %t167 = sub i64 %t163, %t164
  %t168 = load i64, ptr %l5, !tbaa !24
  %t171 = add i64 %t167, %t168
  %t173 = sub i64 %t171, 1
  %t174 = load i64, ptr %l5, !tbaa !24
  %t177 = sdiv i64 %t173, %t174
  store i64 %t177, ptr %l64, !tbaa !24
  br label %bb26
bb25:
  store i64 0, ptr %l64, !tbaa !24
  br label %bb26
bb26:
  %t179 = load i64, ptr %l64, !tbaa !24
  store i64 %t179, ptr %l61, !tbaa !24
  br label %bb27
bb27:
  %t180 = load i64, ptr %l61, !tbaa !24
  store i64 %t180, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb28
bb28:
  %t181 = load i64, ptr %l7, !tbaa !24
  %t182 = load i64, ptr %l6, !tbaa !24
  %t185 = icmp slt i64 %t181, %t182
  %t187 = xor i1 %t185, true
  br i1 %t187, label %bb29, label %bb30
bb29:
  br label %bb33
bb30:
  br label %bb31
bb31:
  %t189 = load i64, ptr %l3, !tbaa !24
  %t190 = load i64, ptr %l7, !tbaa !24
  %t191 = load i64, ptr %l5, !tbaa !24
  %t194 = mul i64 %t190, %t191
  %t197 = add i64 %t189, %t194
  store i64 %t197, ptr %l8, !tbaa !24
  %t199 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t199, ptr %l82, !tbaa !27
  %t200 = load i64, ptr %l8, !tbaa !24
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t203 = getelementptr %"std/list:listState.9783095779ea18337775adeb6569839d", ptr %t201, i32 0, i32 0
  %t204 = load { i64, ptr }, ptr %t203, !tbaa !27
  store { i64, ptr } %t204, ptr %l85, !tbaa !27
  %t205 = load i64, ptr %l8, !tbaa !24
  %t207 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t208 = load ptr, ptr %t207, !tbaa !27
  %t209 = getelementptr { i64, ptr }, ptr %t208, i64 %t205
  %t210 = load { i64, ptr }, ptr %t209, !tbaa !37
  %t213 = getelementptr { i64, ptr }, ptr %l82, i32 0, i32 1
  %t214 = load ptr, ptr %t213, !tbaa !27
  %t215 = getelementptr { i64, ptr }, ptr %t214, i64 %t200
  store { i64, ptr } %t210, ptr %t215, !tbaa !37
  br label %bb32
bb32:
  %t216 = load i64, ptr %l7, !tbaa !24
  %t218 = add i64 %t216, 1
  store i64 %t218, ptr %l7, !tbaa !24
  br label %bb28
bb33:
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t221 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t224 = getelementptr %"std/list:listState.9783095779ea18337775adeb6569839d", ptr %t220, i32 0, i32 0
  store { i64, ptr } %t221, ptr %t224, !tbaa !27
  br label %bb34
bb34:
  br label %bb35
bb35:
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t227 = getelementptr %"std/list:listState.9783095779ea18337775adeb6569839d", ptr %t225, i32 0, i32 0
  %t228 = load { i64, ptr }, ptr %t227, !tbaa !27
  store { i64, ptr } %t228, ptr %l93, !tbaa !27
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t231 = getelementptr %"std/list:listState.9783095779ea18337775adeb6569839d", ptr %t229, i32 0, i32 3
  %t232 = load i64, ptr %t231, !tbaa !24
  store i64 %t232, ptr %l95, !tbaa !24
  %t233 = load i64, ptr @G_2estd_2flist_2efirstChunk, !tbaa !24
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t236 = getelementptr %"std/list:listState.9783095779ea18337775adeb6569839d", ptr %t234, i32 0, i32 3
  %t237 = load i64, ptr %t236, !tbaa !24
  store i64 %t237, ptr %l98, !tbaa !24
  %t239 = load i64, ptr %l98, !tbaa !24
  %t240 = load i64, ptr %l98, !tbaa !24
  %t241 = shl i64 %t233, %t240
  store i64 %t241, ptr %l99, !tbaa !24
  %t242 = load ptr, ptr %l1, !tbaa !29
  store ptr %t242, ptr %l100, !tbaa !29
  %t243 = load i64, ptr %l99, !tbaa !24
  %t244 = icmp sge i64 %t243, 0
  br i1 %t244, label %bb36, label %bb37
bb36:
  %t246 = load i64, ptr %l99, !tbaa !24
  %t247 = icmp sle i64 %t246, 1152921504606846975
  br i1 %t247, label %bb38, label %bb39
bb37:
  call void @__olang_check_failed(ptr @olang_loc_3c9fcdae779a95da_a192967db0cbff3e)
  unreachable
bb38:
  %t249 = load i64, ptr %l99, !tbaa !24
  %t250 = mul i64 %t249, 8
  %t251 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t250)
  %t252 = load ptr, ptr %l100, !tbaa !29
  store i64 0, ptr %t253
  br label %fill.254
fill.254:
  %t257 = load i64, ptr %t253
  %t258 = icmp slt i64 %t257, %t249
  br i1 %t258, label %fillb.255, label %filld.256
fillb.255:
  %t259 = getelementptr ptr, ptr %t251, i64 %t257
  store ptr %t252, ptr %t259
  %t260 = add i64 %t257, 1
  store i64 %t260, ptr %t253
  br label %fill.254
filld.256:
  %t261 = insertvalue { i64, ptr } undef, i64 %t249, 0
  %t262 = insertvalue { i64, ptr } %t261, ptr %t251, 1
  %t264 = load i64, ptr %l95, !tbaa !24
  %t265 = getelementptr { i64, ptr }, ptr %l93, i32 0, i32 1
  %t266 = load ptr, ptr %t265, !tbaa !27
  %t267 = getelementptr { i64, ptr }, ptr %t266, i64 %t264
  store { i64, ptr } %t262, ptr %t267, !tbaa !37
  %t268 = load ptr, ptr %l0, !tbaa !29
  %t269 = load ptr, ptr %l0, !tbaa !29
  %t271 = getelementptr %"std/list:listState.9783095779ea18337775adeb6569839d", ptr %t269, i32 0, i32 0
  %t272 = load { i64, ptr }, ptr %t271, !tbaa !27
  store { i64, ptr } %t272, ptr %l106, !tbaa !27
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t275 = getelementptr %"std/list:listState.9783095779ea18337775adeb6569839d", ptr %t273, i32 0, i32 3
  %t276 = load i64, ptr %t275, !tbaa !24
  %t278 = getelementptr { i64, ptr }, ptr %l106, i32 0, i32 1
  %t279 = load ptr, ptr %t278, !tbaa !27
  %t280 = getelementptr { i64, ptr }, ptr %t279, i64 %t276
  %t281 = load { i64, ptr }, ptr %t280, !tbaa !37
  %t284 = getelementptr %"std/list:listState.9783095779ea18337775adeb6569839d", ptr %t268, i32 0, i32 4
  store { i64, ptr } %t281, ptr %t284, !tbaa !27
  %t285 = load ptr, ptr %l0, !tbaa !29
  store ptr %t285, ptr %l110, !tbaa !29
  %t286 = load ptr, ptr %l110, !tbaa !29
  %t287 = getelementptr %"std/list:listState.9783095779ea18337775adeb6569839d", ptr %t286, i32 0, i32 3
  %t288 = load i64, ptr %t287, !tbaa !24
  %t290 = add i64 %t288, 1
  %t292 = load ptr, ptr %l110, !tbaa !29
  %t293 = getelementptr %"std/list:listState.9783095779ea18337775adeb6569839d", ptr %t292, i32 0, i32 3
  store i64 %t290, ptr %t293, !tbaa !24
  br label %bb40
bb39:
  call void @__olang_check_failed(ptr @olang_loc_3c9fcdae779a95da_a192967db0cbff3e)
  unreachable
bb40:
  br label %bb41
bb41:
  %t294 = load ptr, ptr %l0, !tbaa !29
  store ptr %t294, ptr %l113, !tbaa !29
  %t295 = load ptr, ptr %l113, !tbaa !29
  %t296 = getelementptr %"std/list:listState.9783095779ea18337775adeb6569839d", ptr %t295, i32 0, i32 2
  %t297 = load i64, ptr %t296, !tbaa !24
  %t299 = add i64 %t297, 1
  %t301 = load ptr, ptr %l113, !tbaa !29
  %t302 = getelementptr %"std/list:listState.9783095779ea18337775adeb6569839d", ptr %t301, i32 0, i32 2
  store i64 %t299, ptr %t302, !tbaa !24
  %t303 = load ptr, ptr %l0, !tbaa !29
  %t305 = getelementptr %"std/list:listState.9783095779ea18337775adeb6569839d", ptr %t303, i32 0, i32 5
  store i64 0, ptr %t305, !tbaa !24
  %t306 = load ptr, ptr %l0, !tbaa !29
  %t307 = load ptr, ptr %l0, !tbaa !29
  %t309 = getelementptr %"std/list:listState.9783095779ea18337775adeb6569839d", ptr %t307, i32 0, i32 4
  %t310 = load { i64, ptr }, ptr %t309, !tbaa !27
  %t312 = extractvalue { i64, ptr } %t310, 0
  %t315 = getelementptr %"std/list:listState.9783095779ea18337775adeb6569839d", ptr %t306, i32 0, i32 6
  store i64 %t312, ptr %t315, !tbaa !24
  br label %ret
ret:
  ret void
}

@std_2flist_2estd_2flist_3alistState_3ccompiler_2ftyped_3aPlace_3f_26_3e_2echunk_3ccompiler_2ftyped_3aPlace_3f_26_3e = dso_local alias { i64, ptr } (ptr, ptr, i64), ptr @std_2flist_2estd_2flist_3alistState_3ccompiler_2ftyped_3aExpr_3f_26_3e_2echunk_3ccompiler_2ftyped_3aExpr_3f_26_3e
@std_2flist_2estd_2flist_3alistState_3ccompiler_2ftyped_3aPlace_3f_26_3e_2egrow_3ccompiler_2ftyped_3aPlace_3f_26_3e = dso_local alias void (ptr, ptr, ptr, ptr), ptr @std_2flist_2estd_2flist_3alistState_3ccompiler_2ftyped_3aExpr_3f_26_3e_2egrow_3ccompiler_2ftyped_3aExpr_3f_26_3e
define dso_local %"std/list:listState.9783095779ea18337775adeb6569839d" @std_2flist_3alistState_3ccompiler_2ftyped_3aExpr_3f_26_3e_2ector(ptr %v0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %rv = alloca %"std/list:listState.9783095779ea18337775adeb6569839d"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = icmp sge i64 0, 0
  br i1 %t1, label %bb1, label %bb2
bb1:
  %t3 = icmp sle i64 0, 576460752303423487
  br i1 %t3, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_9c26c043f6adbd37_4eba68de8fa37583)
  unreachable
bb3:
  %t5 = mul i64 0, 16
  %t6 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t5)
  %t7 = insertvalue { i64, ptr } undef, i64 0, 0
  %t8 = insertvalue { i64, ptr } %t7, ptr %t6, 1
  store { i64, ptr } %t8, ptr %l0, !tbaa !27
  %t10 = icmp sge i64 0, 0
  br i1 %t10, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_9c26c043f6adbd37_4eba68de8fa37583)
  unreachable
bb5:
  %t12 = icmp sle i64 0, 1152921504606846975
  br i1 %t12, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_93916db8879de882_a38eb1e37fdd568e)
  unreachable
bb7:
  %t14 = mul i64 0, 8
  %t15 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t14)
  %t16 = insertvalue { i64, ptr } undef, i64 0, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t15, 1
  store { i64, ptr } %t17, ptr %l1, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  store i64 0, ptr %l3, !tbaa !24
  %t19 = icmp sge i64 0, 0
  br i1 %t19, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_93916db8879de882_a38eb1e37fdd568e)
  unreachable
bb9:
  %t21 = icmp sle i64 0, 1152921504606846975
  br i1 %t21, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_5380aff59a2be5a1_77ecbad11d54d68d)
  unreachable
bb11:
  %t23 = mul i64 0, 8
  %t24 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t23)
  %t25 = insertvalue { i64, ptr } undef, i64 0, 0
  %t26 = insertvalue { i64, ptr } %t25, ptr %t24, 1
  %t28 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t29 = insertvalue %"std/list:listState.9783095779ea18337775adeb6569839d" undef, { i64, ptr } %t28, 0
  %t30 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t31 = insertvalue %"std/list:listState.9783095779ea18337775adeb6569839d" %t29, { i64, ptr } %t30, 1
  %t32 = load i64, ptr %l2, !tbaa !24
  %t33 = insertvalue %"std/list:listState.9783095779ea18337775adeb6569839d" %t31, i64 %t32, 2
  %t34 = load i64, ptr %l3, !tbaa !24
  %t35 = insertvalue %"std/list:listState.9783095779ea18337775adeb6569839d" %t33, i64 %t34, 3
  %t37 = insertvalue %"std/list:listState.9783095779ea18337775adeb6569839d" %t35, { i64, ptr } %t26, 4
  %t39 = insertvalue %"std/list:listState.9783095779ea18337775adeb6569839d" %t37, i64 0, 5
  %t41 = insertvalue %"std/list:listState.9783095779ea18337775adeb6569839d" %t39, i64 0, 6
  %t43 = insertvalue %"std/list:listState.9783095779ea18337775adeb6569839d" %t41, i64 0, 7
  store %"std/list:listState.9783095779ea18337775adeb6569839d" %t43, ptr %rv
  br label %ret
bb12:
  call void @__olang_check_failed(ptr @olang_loc_5380aff59a2be5a1_77ecbad11d54d68d)
  unreachable
ret:
  %rr = load %"std/list:listState.9783095779ea18337775adeb6569839d", ptr %rv
  ret %"std/list:listState.9783095779ea18337775adeb6569839d" %rr
}

@std_2flist_3alistState_3ccompiler_2ftyped_3aPlace_3f_26_3e_2ector = dso_local alias %"std/list:listState.9783095779ea18337775adeb6569839d" (ptr), ptr @std_2flist_3alistState_3ccompiler_2ftyped_3aExpr_3f_26_3e_2ector
define dso_local %"std/pair:Pair.0eea5a06f8f0107e600fd23235f2e98f" @std_2fpair_3aPair_3ccompiler_2fgeneric_3aOrigin_2c_20I64_3e_2ector(ptr %v0, %"compiler/generic:Origin" %a0, i64 %a1) #0 {
entry:
  %rv = alloca %"std/pair:Pair.0eea5a06f8f0107e600fd23235f2e98f"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"std/pair:Pair.0eea5a06f8f0107e600fd23235f2e98f" undef, %"compiler/generic:Origin" %a0, 0
  %t8 = insertvalue %"std/pair:Pair.0eea5a06f8f0107e600fd23235f2e98f" %t6, i64 %a1, 1
  store %"std/pair:Pair.0eea5a06f8f0107e600fd23235f2e98f" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"std/pair:Pair.0eea5a06f8f0107e600fd23235f2e98f", ptr %rv
  ret %"std/pair:Pair.0eea5a06f8f0107e600fd23235f2e98f" %rr
}

define dso_local %"std/pair:Pair.91de8c8eb84d52d1e58996aec31d85aa" @std_2fpair_3aPair_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2ector(ptr %v0, i32 %a0, i32 %a1) #0 {
entry:
  %rv = alloca %"std/pair:Pair.91de8c8eb84d52d1e58996aec31d85aa"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"std/pair:Pair.91de8c8eb84d52d1e58996aec31d85aa" undef, i32 %a0, 0
  %t8 = insertvalue %"std/pair:Pair.91de8c8eb84d52d1e58996aec31d85aa" %t6, i32 %a1, 1
  store %"std/pair:Pair.91de8c8eb84d52d1e58996aec31d85aa" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"std/pair:Pair.91de8c8eb84d52d1e58996aec31d85aa", ptr %rv
  ret %"std/pair:Pair.91de8c8eb84d52d1e58996aec31d85aa" %rr
}

define dso_local i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eRemove_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l10 = alloca i64
  %l12 = alloca { i64, ptr }
  %l24 = alloca %"std/prelude/map:MapEntry.eb00e4a6e4307a4e46e40fbcd79d6b4f"
  %l28 = alloca { i64, ptr }
  %l41 = alloca ptr
  %rv = alloca i1
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t7 = load i64, ptr %l1, !tbaa !24
  %t10 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cI64_2c_20Bool_3e_2ebucketOf_3cI64_2c_20Bool_3e(ptr %v0, ptr %t6, i64 %t7)
  store i64 %t10, ptr %l10
  br label %bb1
bb1:
  %t11 = load i64, ptr %l10, !tbaa !24
  store i64 %t11, ptr %l3, !tbaa !24
  store ptr null, ptr %l4, !tbaa !29
  %t12 = load ptr, ptr %l2, !tbaa !29
  %t14 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  store { i64, ptr } %t15, ptr %l12, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  store ptr %t21, ptr %l5, !tbaa !29
  br label %bb2
bb2:
  %t23 = load ptr, ptr %l5, !tbaa !29
  %t25 = icmp eq ptr %t23, null
  %t27 = xor i1 %t25, true
  %t29 = xor i1 %t27, true
  br i1 %t29, label %bb3, label %bb4
bb3:
  br label %bb13
bb4:
  br label %bb5
bb5:
  %t31 = load ptr, ptr %l5, !tbaa !29
  %t33 = getelementptr %"std/prelude/map:mapSlot.bf8e2f5a99d2ad08487ec11f6be9b652", ptr %t31, i32 0, i32 0
  %t34 = getelementptr %"std/prelude/map:MapEntry.eb00e4a6e4307a4e46e40fbcd79d6b4f", ptr %t33, i32 0, i32 0
  %t35 = load i64, ptr %t34, !tbaa !24
  %t36 = load i64, ptr %l1, !tbaa !24
  %t39 = icmp eq i64 %t35, %t36
  br i1 %t39, label %bb6, label %bb7
bb6:
  %t41 = load ptr, ptr %l5, !tbaa !29
  %t43 = getelementptr %"std/prelude/map:mapSlot.bf8e2f5a99d2ad08487ec11f6be9b652", ptr %t41, i32 0, i32 0
  %t44 = load %"std/prelude/map:MapEntry.eb00e4a6e4307a4e46e40fbcd79d6b4f", ptr %t43
  store %"std/prelude/map:MapEntry.eb00e4a6e4307a4e46e40fbcd79d6b4f" %t44, ptr %l24
  %t45 = load ptr, ptr %l4, !tbaa !29
  %t47 = icmp eq ptr %t45, null
  br i1 %t47, label %bb8, label %bb9
bb7:
  br label %bb11
bb8:
  %t49 = load ptr, ptr %l2, !tbaa !29
  %t51 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t49, i32 0, i32 0
  %t52 = load { i64, ptr }, ptr %t51, !tbaa !27
  store { i64, ptr } %t52, ptr %l28, !tbaa !27
  %t53 = load i64, ptr %l3, !tbaa !24
  %t54 = load ptr, ptr %l5, !tbaa !29
  %t56 = getelementptr %"std/prelude/map:mapSlot.bf8e2f5a99d2ad08487ec11f6be9b652", ptr %t54, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !29
  %t60 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !27
  %t62 = getelementptr ptr, ptr %t61, i64 %t53
  store ptr %t57, ptr %t62, !tbaa !39
  br label %bb10
bb9:
  %t63 = load ptr, ptr %l4, !tbaa !29
  %t64 = load ptr, ptr %l5, !tbaa !29
  %t66 = getelementptr %"std/prelude/map:mapSlot.bf8e2f5a99d2ad08487ec11f6be9b652", ptr %t64, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !29
  %t70 = getelementptr %"std/prelude/map:mapSlot.bf8e2f5a99d2ad08487ec11f6be9b652", ptr %t63, i32 0, i32 1
  store ptr %t67, ptr %t70, !tbaa !29
  br label %bb10
bb10:
  %t71 = load ptr, ptr %l5, !tbaa !29
  %t72 = load ptr, ptr %l2, !tbaa !29
  %t74 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t72, i32 0, i32 2
  %t75 = load ptr, ptr %t74, !tbaa !29
  %t78 = getelementptr %"std/prelude/map:mapSlot.bf8e2f5a99d2ad08487ec11f6be9b652", ptr %t71, i32 0, i32 1
  store ptr %t75, ptr %t78, !tbaa !29
  %t79 = load ptr, ptr %l2, !tbaa !29
  %t80 = load ptr, ptr %l5, !tbaa !29
  %t84 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t79, i32 0, i32 2
  store ptr %t80, ptr %t84, !tbaa !29
  %t85 = load ptr, ptr %l2, !tbaa !29
  store ptr %t85, ptr %l41, !tbaa !29
  %t86 = load ptr, ptr %l41, !tbaa !29
  %t87 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t86, i32 0, i32 1
  %t88 = load i64, ptr %t87, !tbaa !24
  %t90 = sub i64 %t88, 1
  %t92 = load ptr, ptr %l41, !tbaa !29
  %t93 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t92, i32 0, i32 1
  store i64 %t90, ptr %t93, !tbaa !24
  store i1 true, ptr %rv
  br label %ret
bb11:
  %t95 = load ptr, ptr %l5, !tbaa !29
  store ptr %t95, ptr %l4, !tbaa !29
  br label %bb12
bb12:
  %t98 = load ptr, ptr %l5, !tbaa !29
  %t100 = getelementptr %"std/prelude/map:mapSlot.bf8e2f5a99d2ad08487ec11f6be9b652", ptr %t98, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !29
  store ptr %t101, ptr %l5, !tbaa !29
  br label %bb2
bb13:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fcheck_3arawTable_2_H63c69eede5e7cc65b54d8ce1ed292a98(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %r = tail call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_Hc57530578add1ad359c6d87470cc4752(ptr %v0, ptr %a0, i64 %a1)
  ret i1 %r
}

define dso_local { i32, ptr } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fcheck_3arawTable_2_Hc06038cfd2a883d900a989353ba26a88(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %r = tail call { i32, ptr } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_H68cd31c3dbcdb47f3349b834dda1e07d(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
  ret { i32, ptr } %r
}

define dso_local { i32, { i64, [3 x i64] } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fdiag_3aWhere_3e_2e_H38805f4eed72f99710d38d2dedaea985(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l10 = alloca i64
  %rv = alloca { i32, { i64, [3 x i64] } }
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t6, i32 0, i32 0
  %t9 = load { i64, ptr }, ptr %t8, !tbaa !27
  store { i64, ptr } %t9, ptr %l7, !tbaa !27
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t11 = load i64, ptr %l1, !tbaa !24
  %t14 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cI64_2c_20Bool_3e_2ebucketOf_3cI64_2c_20Bool_3e(ptr %v0, ptr %t10, i64 %t11)
  store i64 %t14, ptr %l10
  br label %bb1
bb1:
  %t15 = load i64, ptr %l10, !tbaa !24
  %t16 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr ptr, ptr %t17, i64 %t15
  %t19 = load ptr, ptr %t18, !tbaa !39
  store ptr %t19, ptr %l3, !tbaa !29
  br label %bb2
bb2:
  %t21 = load ptr, ptr %l3, !tbaa !29
  %t23 = icmp eq ptr %t21, null
  %t25 = xor i1 %t23, true
  %t27 = xor i1 %t25, true
  br i1 %t27, label %bb3, label %bb4
bb3:
  br label %bb10
bb4:
  br label %bb5
bb5:
  %t29 = load ptr, ptr %l3, !tbaa !29
  %t31 = getelementptr %"std/prelude/map:mapSlot.727a518559d2b598d6ef289c4e704dc3", ptr %t29, i32 0, i32 0
  %t32 = getelementptr %"std/prelude/map:MapEntry.457163fdec6e9d9dd96e1de2e7dfe82b", ptr %t31, i32 0, i32 0
  %t33 = load i64, ptr %t32, !tbaa !24
  %t34 = load i64, ptr %l1, !tbaa !24
  %t37 = icmp eq i64 %t33, %t34
  br i1 %t37, label %bb6, label %bb7
bb6:
  %t39 = load ptr, ptr %l3, !tbaa !29
  %t41 = getelementptr %"std/prelude/map:mapSlot.727a518559d2b598d6ef289c4e704dc3", ptr %t39, i32 0, i32 0
  %t42 = getelementptr %"std/prelude/map:MapEntry.457163fdec6e9d9dd96e1de2e7dfe82b", ptr %t41, i32 0, i32 1
  %t43 = load { i64, [3 x i64] }, ptr %t42
  %t45 = insertvalue { i32, { i64, [3 x i64] } } zeroinitializer, { i64, [3 x i64] } %t43, 1
  store { i32, { i64, [3 x i64] } } %t45, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t46 = load ptr, ptr %l3, !tbaa !29
  %t48 = getelementptr %"std/prelude/map:mapSlot.727a518559d2b598d6ef289c4e704dc3", ptr %t46, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !29
  store ptr %t49, ptr %l3, !tbaa !29
  br label %bb2
bb10:
  %t52 = insertvalue { i32, { i64, [3 x i64] } } zeroinitializer, i32 65536, 0
  store { i32, { i64, [3 x i64] } } %t52, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, [3 x i64] } }, ptr %rv
  ret { i32, { i64, [3 x i64] } } %rr
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fdiag_3aWhere_3e_2e_Hc07a7e56a24d8f1225398db99ea19a4b(ptr %v0, ptr %a0, i64 %a1, { i64, [3 x i64] } %a2) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca { i64, [3 x i64] }
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca ptr
  %l10 = alloca i64
  %l12 = alloca { i64, ptr }
  store i64 %a1, ptr %l1
  store { i64, [3 x i64] } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load ptr, ptr %l3, !tbaa !29
  %t7 = load i64, ptr %l1, !tbaa !24
  %t10 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cI64_2c_20Bool_3e_2ebucketOf_3cI64_2c_20Bool_3e(ptr %v0, ptr %t6, i64 %t7)
  store i64 %t10, ptr %l10
  br label %bb1
bb1:
  %t11 = load i64, ptr %l10, !tbaa !24
  store i64 %t11, ptr %l4, !tbaa !24
  %t12 = load ptr, ptr %l3, !tbaa !29
  %t14 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  store { i64, ptr } %t15, ptr %l12, !tbaa !27
  %t16 = load i64, ptr %l4, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  store ptr %t21, ptr %l5, !tbaa !29
  br label %bb2
bb2:
  %t23 = load ptr, ptr %l5, !tbaa !29
  %t25 = icmp eq ptr %t23, null
  %t27 = xor i1 %t25, true
  %t29 = xor i1 %t27, true
  br i1 %t29, label %bb3, label %bb4
bb3:
  br label %bb10
bb4:
  br label %bb5
bb5:
  %t31 = load ptr, ptr %l5, !tbaa !29
  %t33 = getelementptr %"std/prelude/map:mapSlot.727a518559d2b598d6ef289c4e704dc3", ptr %t31, i32 0, i32 0
  %t34 = getelementptr %"std/prelude/map:MapEntry.457163fdec6e9d9dd96e1de2e7dfe82b", ptr %t33, i32 0, i32 0
  %t35 = load i64, ptr %t34, !tbaa !24
  %t36 = load i64, ptr %l1, !tbaa !24
  %t39 = icmp eq i64 %t35, %t36
  br i1 %t39, label %bb6, label %bb7
bb6:
  %t41 = load ptr, ptr %l5, !tbaa !29
  %t42 = load { i64, [3 x i64] }, ptr %l2
  %t45 = getelementptr %"std/prelude/map:mapSlot.727a518559d2b598d6ef289c4e704dc3", ptr %t41, i32 0, i32 0
  %t46 = getelementptr %"std/prelude/map:MapEntry.457163fdec6e9d9dd96e1de2e7dfe82b", ptr %t45, i32 0, i32 1
  store { i64, [3 x i64] } %t42, ptr %t46
  br label %ret
bb7:
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t47 = load ptr, ptr %l5, !tbaa !29
  %t49 = getelementptr %"std/prelude/map:mapSlot.727a518559d2b598d6ef289c4e704dc3", ptr %t47, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !29
  store ptr %t50, ptr %l5, !tbaa !29
  br label %bb2
bb10:
  %t52 = load ptr, ptr %l3, !tbaa !29
  %t53 = load i64, ptr %l4, !tbaa !24
  %t54 = load i64, ptr %l1, !tbaa !24
  %t55 = load { i64, [3 x i64] }, ptr %l2
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cI64_2c_20compiler_2fdiag_3aWhere__Ha2beffd59aa8cf27179d2e8906b62049(ptr %v0, ptr %t52, i64 %t53, i64 %t54, { i64, [3 x i64] } %t55)
  br label %bb11
bb11:
  br label %ret
ret:
  ret void
}

define dso_local i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aContractIn_H044304b59760c17b661e6227d2ca1ac9(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l10 = alloca i64
  %l12 = alloca { i64, ptr }
  %l24 = alloca %"std/prelude/map:MapEntry.30ce370d829aff239a34c06a62e67c2e"
  %l28 = alloca { i64, ptr }
  %l41 = alloca ptr
  %rv = alloca i1
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t7 = load i64, ptr %l1, !tbaa !24
  %t10 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cI64_2c_20Bool_3e_2ebucketOf_3cI64_2c_20Bool_3e(ptr %v0, ptr %t6, i64 %t7)
  store i64 %t10, ptr %l10
  br label %bb1
bb1:
  %t11 = load i64, ptr %l10, !tbaa !24
  store i64 %t11, ptr %l3, !tbaa !24
  store ptr null, ptr %l4, !tbaa !29
  %t12 = load ptr, ptr %l2, !tbaa !29
  %t14 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  store { i64, ptr } %t15, ptr %l12, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  store ptr %t21, ptr %l5, !tbaa !29
  br label %bb2
bb2:
  %t23 = load ptr, ptr %l5, !tbaa !29
  %t25 = icmp eq ptr %t23, null
  %t27 = xor i1 %t25, true
  %t29 = xor i1 %t27, true
  br i1 %t29, label %bb3, label %bb4
bb3:
  br label %bb13
bb4:
  br label %bb5
bb5:
  %t31 = load ptr, ptr %l5, !tbaa !29
  %t33 = getelementptr %"std/prelude/map:mapSlot.0482058481105505dc7df18be1ecde54", ptr %t31, i32 0, i32 0
  %t34 = getelementptr %"std/prelude/map:MapEntry.30ce370d829aff239a34c06a62e67c2e", ptr %t33, i32 0, i32 0
  %t35 = load i64, ptr %t34, !tbaa !24
  %t36 = load i64, ptr %l1, !tbaa !24
  %t39 = icmp eq i64 %t35, %t36
  br i1 %t39, label %bb6, label %bb7
bb6:
  %t41 = load ptr, ptr %l5, !tbaa !29
  %t43 = getelementptr %"std/prelude/map:mapSlot.0482058481105505dc7df18be1ecde54", ptr %t41, i32 0, i32 0
  %t44 = load %"std/prelude/map:MapEntry.30ce370d829aff239a34c06a62e67c2e", ptr %t43
  store %"std/prelude/map:MapEntry.30ce370d829aff239a34c06a62e67c2e" %t44, ptr %l24
  %t45 = load ptr, ptr %l4, !tbaa !29
  %t47 = icmp eq ptr %t45, null
  br i1 %t47, label %bb8, label %bb9
bb7:
  br label %bb11
bb8:
  %t49 = load ptr, ptr %l2, !tbaa !29
  %t51 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t49, i32 0, i32 0
  %t52 = load { i64, ptr }, ptr %t51, !tbaa !27
  store { i64, ptr } %t52, ptr %l28, !tbaa !27
  %t53 = load i64, ptr %l3, !tbaa !24
  %t54 = load ptr, ptr %l5, !tbaa !29
  %t56 = getelementptr %"std/prelude/map:mapSlot.0482058481105505dc7df18be1ecde54", ptr %t54, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !29
  %t60 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !27
  %t62 = getelementptr ptr, ptr %t61, i64 %t53
  store ptr %t57, ptr %t62, !tbaa !39
  br label %bb10
bb9:
  %t63 = load ptr, ptr %l4, !tbaa !29
  %t64 = load ptr, ptr %l5, !tbaa !29
  %t66 = getelementptr %"std/prelude/map:mapSlot.0482058481105505dc7df18be1ecde54", ptr %t64, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !29
  %t70 = getelementptr %"std/prelude/map:mapSlot.0482058481105505dc7df18be1ecde54", ptr %t63, i32 0, i32 1
  store ptr %t67, ptr %t70, !tbaa !29
  br label %bb10
bb10:
  %t71 = load ptr, ptr %l5, !tbaa !29
  %t72 = load ptr, ptr %l2, !tbaa !29
  %t74 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t72, i32 0, i32 2
  %t75 = load ptr, ptr %t74, !tbaa !29
  %t78 = getelementptr %"std/prelude/map:mapSlot.0482058481105505dc7df18be1ecde54", ptr %t71, i32 0, i32 1
  store ptr %t75, ptr %t78, !tbaa !29
  %t79 = load ptr, ptr %l2, !tbaa !29
  %t80 = load ptr, ptr %l5, !tbaa !29
  %t84 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t79, i32 0, i32 2
  store ptr %t80, ptr %t84, !tbaa !29
  %t85 = load ptr, ptr %l2, !tbaa !29
  store ptr %t85, ptr %l41, !tbaa !29
  %t86 = load ptr, ptr %l41, !tbaa !29
  %t87 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t86, i32 0, i32 1
  %t88 = load i64, ptr %t87, !tbaa !24
  %t90 = sub i64 %t88, 1
  %t92 = load ptr, ptr %l41, !tbaa !29
  %t93 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t92, i32 0, i32 1
  store i64 %t90, ptr %t93, !tbaa !24
  store i1 true, ptr %rv
  br label %ret
bb11:
  %t95 = load ptr, ptr %l5, !tbaa !29
  store ptr %t95, ptr %l4, !tbaa !29
  br label %bb12
bb12:
  %t98 = load ptr, ptr %l5, !tbaa !29
  %t100 = getelementptr %"std/prelude/map:mapSlot.0482058481105505dc7df18be1ecde54", ptr %t98, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !29
  store ptr %t101, ptr %l5, !tbaa !29
  br label %bb2
bb13:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i32, %"compiler/typed:ContractInfo" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aContractIn_H1fc1bd863e6a60d3e5c2aece55d841d1(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l10 = alloca i64
  %rv = alloca { i32, %"compiler/typed:ContractInfo" }
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t6, i32 0, i32 0
  %t9 = load { i64, ptr }, ptr %t8, !tbaa !27
  store { i64, ptr } %t9, ptr %l7, !tbaa !27
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t11 = load i64, ptr %l1, !tbaa !24
  %t14 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cI64_2c_20Bool_3e_2ebucketOf_3cI64_2c_20Bool_3e(ptr %v0, ptr %t10, i64 %t11)
  store i64 %t14, ptr %l10
  br label %bb1
bb1:
  %t15 = load i64, ptr %l10, !tbaa !24
  %t16 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr ptr, ptr %t17, i64 %t15
  %t19 = load ptr, ptr %t18, !tbaa !39
  store ptr %t19, ptr %l3, !tbaa !29
  br label %bb2
bb2:
  %t21 = load ptr, ptr %l3, !tbaa !29
  %t23 = icmp eq ptr %t21, null
  %t25 = xor i1 %t23, true
  %t27 = xor i1 %t25, true
  br i1 %t27, label %bb3, label %bb4
bb3:
  br label %bb10
bb4:
  br label %bb5
bb5:
  %t29 = load ptr, ptr %l3, !tbaa !29
  %t31 = getelementptr %"std/prelude/map:mapSlot.0482058481105505dc7df18be1ecde54", ptr %t29, i32 0, i32 0
  %t32 = getelementptr %"std/prelude/map:MapEntry.30ce370d829aff239a34c06a62e67c2e", ptr %t31, i32 0, i32 0
  %t33 = load i64, ptr %t32, !tbaa !24
  %t34 = load i64, ptr %l1, !tbaa !24
  %t37 = icmp eq i64 %t33, %t34
  br i1 %t37, label %bb6, label %bb7
bb6:
  %t39 = load ptr, ptr %l3, !tbaa !29
  %t41 = getelementptr %"std/prelude/map:mapSlot.0482058481105505dc7df18be1ecde54", ptr %t39, i32 0, i32 0
  %t42 = getelementptr %"std/prelude/map:MapEntry.30ce370d829aff239a34c06a62e67c2e", ptr %t41, i32 0, i32 1
  %t43 = load %"compiler/typed:ContractInfo", ptr %t42
  %t45 = insertvalue { i32, %"compiler/typed:ContractInfo" } zeroinitializer, %"compiler/typed:ContractInfo" %t43, 1
  store { i32, %"compiler/typed:ContractInfo" } %t45, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t46 = load ptr, ptr %l3, !tbaa !29
  %t48 = getelementptr %"std/prelude/map:mapSlot.0482058481105505dc7df18be1ecde54", ptr %t46, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !29
  store ptr %t49, ptr %l3, !tbaa !29
  br label %bb2
bb10:
  %t52 = insertvalue { i32, %"compiler/typed:ContractInfo" } zeroinitializer, i32 65536, 0
  store { i32, %"compiler/typed:ContractInfo" } %t52, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"compiler/typed:ContractInfo" }, ptr %rv
  ret { i32, %"compiler/typed:ContractInfo" } %rr
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aContractIn_H9735389c66b65d66c88b8429345781ec(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/typed:ContractInfo" %a2) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca %"compiler/typed:ContractInfo"
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca ptr
  %l10 = alloca i64
  %l12 = alloca { i64, ptr }
  store i64 %a1, ptr %l1
  store %"compiler/typed:ContractInfo" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load ptr, ptr %l3, !tbaa !29
  %t7 = load i64, ptr %l1, !tbaa !24
  %t10 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cI64_2c_20Bool_3e_2ebucketOf_3cI64_2c_20Bool_3e(ptr %v0, ptr %t6, i64 %t7)
  store i64 %t10, ptr %l10
  br label %bb1
bb1:
  %t11 = load i64, ptr %l10, !tbaa !24
  store i64 %t11, ptr %l4, !tbaa !24
  %t12 = load ptr, ptr %l3, !tbaa !29
  %t14 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  store { i64, ptr } %t15, ptr %l12, !tbaa !27
  %t16 = load i64, ptr %l4, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  store ptr %t21, ptr %l5, !tbaa !29
  br label %bb2
bb2:
  %t23 = load ptr, ptr %l5, !tbaa !29
  %t25 = icmp eq ptr %t23, null
  %t27 = xor i1 %t25, true
  %t29 = xor i1 %t27, true
  br i1 %t29, label %bb3, label %bb4
bb3:
  br label %bb10
bb4:
  br label %bb5
bb5:
  %t31 = load ptr, ptr %l5, !tbaa !29
  %t33 = getelementptr %"std/prelude/map:mapSlot.0482058481105505dc7df18be1ecde54", ptr %t31, i32 0, i32 0
  %t34 = getelementptr %"std/prelude/map:MapEntry.30ce370d829aff239a34c06a62e67c2e", ptr %t33, i32 0, i32 0
  %t35 = load i64, ptr %t34, !tbaa !24
  %t36 = load i64, ptr %l1, !tbaa !24
  %t39 = icmp eq i64 %t35, %t36
  br i1 %t39, label %bb6, label %bb7
bb6:
  %t41 = load ptr, ptr %l5, !tbaa !29
  %t42 = load %"compiler/typed:ContractInfo", ptr %l2
  %t45 = getelementptr %"std/prelude/map:mapSlot.0482058481105505dc7df18be1ecde54", ptr %t41, i32 0, i32 0
  %t46 = getelementptr %"std/prelude/map:MapEntry.30ce370d829aff239a34c06a62e67c2e", ptr %t45, i32 0, i32 1
  store %"compiler/typed:ContractInfo" %t42, ptr %t46
  br label %ret
bb7:
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t47 = load ptr, ptr %l5, !tbaa !29
  %t49 = getelementptr %"std/prelude/map:mapSlot.0482058481105505dc7df18be1ecde54", ptr %t47, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !29
  store ptr %t50, ptr %l5, !tbaa !29
  br label %bb2
bb10:
  %t52 = load ptr, ptr %l3, !tbaa !29
  %t53 = load i64, ptr %l4, !tbaa !24
  %t54 = load i64, ptr %l1, !tbaa !24
  %t55 = load %"compiler/typed:ContractInfo", ptr %l2
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cI64_2c_20compiler_2ftyped_3aContr_H99da597b4067da6fce96bff81dbb1566(ptr %v0, ptr %v1, ptr %t52, i64 %t53, i64 %t54, %"compiler/typed:ContractInfo" %t55)
  br label %bb11
bb11:
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftypes_3aListId_3e__Hb311157f9ff5cfde66cc01a7f8069ed8(ptr %v0, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  tail call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftypes_3aDeclId_3e__H7ddd7dd10a6733ce5265405d8e7c8faa(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
  ret void
}

define dso_local i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_H2c4b9eb360b9a0ada2008890a467b28d(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l10 = alloca i64
  %l12 = alloca { i64, ptr }
  %l24 = alloca %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa"
  %l28 = alloca { i64, ptr }
  %l41 = alloca ptr
  %rv = alloca i1
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t7 = load i32, ptr %l1, !tbaa !23
  %t10 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3ccompiler_2fsource_3aNameId_2c_20B_Heab357d0b792d165805bc071c98cf6d1(ptr %v0, ptr %t6, i32 %t7)
  store i64 %t10, ptr %l10
  br label %bb1
bb1:
  %t11 = load i64, ptr %l10, !tbaa !24
  store i64 %t11, ptr %l3, !tbaa !24
  store ptr null, ptr %l4, !tbaa !29
  %t12 = load ptr, ptr %l2, !tbaa !29
  %t14 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  store { i64, ptr } %t15, ptr %l12, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  store ptr %t21, ptr %l5, !tbaa !29
  br label %bb2
bb2:
  %t23 = load ptr, ptr %l5, !tbaa !29
  %t25 = icmp eq ptr %t23, null
  %t27 = xor i1 %t25, true
  %t29 = xor i1 %t27, true
  br i1 %t29, label %bb3, label %bb4
bb3:
  br label %bb13
bb4:
  br label %bb5
bb5:
  %t31 = load ptr, ptr %l5, !tbaa !29
  %t33 = getelementptr %"std/prelude/map:mapSlot.79a9cb365fafee3b3ee9688fef10964d", ptr %t31, i32 0, i32 0
  %t34 = getelementptr %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa", ptr %t33, i32 0, i32 0
  %t35 = load i32, ptr %t34, !tbaa !23
  %t36 = load i32, ptr %l1, !tbaa !23
  %t39 = icmp eq i32 %t35, %t36
  br i1 %t39, label %bb6, label %bb7
bb6:
  %t41 = load ptr, ptr %l5, !tbaa !29
  %t43 = getelementptr %"std/prelude/map:mapSlot.79a9cb365fafee3b3ee9688fef10964d", ptr %t41, i32 0, i32 0
  %t44 = load %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa", ptr %t43
  store %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" %t44, ptr %l24
  %t45 = load ptr, ptr %l4, !tbaa !29
  %t47 = icmp eq ptr %t45, null
  br i1 %t47, label %bb8, label %bb9
bb7:
  br label %bb11
bb8:
  %t49 = load ptr, ptr %l2, !tbaa !29
  %t51 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t49, i32 0, i32 0
  %t52 = load { i64, ptr }, ptr %t51, !tbaa !27
  store { i64, ptr } %t52, ptr %l28, !tbaa !27
  %t53 = load i64, ptr %l3, !tbaa !24
  %t54 = load ptr, ptr %l5, !tbaa !29
  %t56 = getelementptr %"std/prelude/map:mapSlot.79a9cb365fafee3b3ee9688fef10964d", ptr %t54, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !29
  %t60 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !27
  %t62 = getelementptr ptr, ptr %t61, i64 %t53
  store ptr %t57, ptr %t62, !tbaa !39
  br label %bb10
bb9:
  %t63 = load ptr, ptr %l4, !tbaa !29
  %t64 = load ptr, ptr %l5, !tbaa !29
  %t66 = getelementptr %"std/prelude/map:mapSlot.79a9cb365fafee3b3ee9688fef10964d", ptr %t64, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !29
  %t70 = getelementptr %"std/prelude/map:mapSlot.79a9cb365fafee3b3ee9688fef10964d", ptr %t63, i32 0, i32 1
  store ptr %t67, ptr %t70, !tbaa !29
  br label %bb10
bb10:
  %t71 = load ptr, ptr %l5, !tbaa !29
  %t72 = load ptr, ptr %l2, !tbaa !29
  %t74 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t72, i32 0, i32 2
  %t75 = load ptr, ptr %t74, !tbaa !29
  %t78 = getelementptr %"std/prelude/map:mapSlot.79a9cb365fafee3b3ee9688fef10964d", ptr %t71, i32 0, i32 1
  store ptr %t75, ptr %t78, !tbaa !29
  %t79 = load ptr, ptr %l2, !tbaa !29
  %t80 = load ptr, ptr %l5, !tbaa !29
  %t84 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t79, i32 0, i32 2
  store ptr %t80, ptr %t84, !tbaa !29
  %t85 = load ptr, ptr %l2, !tbaa !29
  store ptr %t85, ptr %l41, !tbaa !29
  %t86 = load ptr, ptr %l41, !tbaa !29
  %t87 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t86, i32 0, i32 1
  %t88 = load i64, ptr %t87, !tbaa !24
  %t90 = sub i64 %t88, 1
  %t92 = load ptr, ptr %l41, !tbaa !29
  %t93 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t92, i32 0, i32 1
  store i64 %t90, ptr %t93, !tbaa !24
  store i1 true, ptr %rv
  br label %ret
bb11:
  %t95 = load ptr, ptr %l5, !tbaa !29
  store ptr %t95, ptr %l4, !tbaa !29
  br label %bb12
bb12:
  %t98 = load ptr, ptr %l5, !tbaa !29
  %t100 = getelementptr %"std/prelude/map:mapSlot.79a9cb365fafee3b3ee9688fef10964d", ptr %t98, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !29
  store ptr %t101, ptr %l5, !tbaa !29
  br label %bb2
bb13:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H031c7c147cc8ce0b988dd3fed8d142ad(ptr %v0, ptr %v1, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1) #0 {
entry:
  %l1 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l10 = alloca i64
  %l17 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l19 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l21 = alloca i1
  %rv = alloca { i32, { i64, ptr } }
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t6, i32 0, i32 0
  %t9 = load { i64, ptr }, ptr %t8, !tbaa !27
  store { i64, ptr } %t9, ptr %l7, !tbaa !27
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t11 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l1
  %t14 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cstd_2fpair_3aPair_3cI64_2c_20I64__H25550a5aa964c9352053a58344d5fc74(ptr %v0, ptr %t10, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t11)
  store i64 %t14, ptr %l10
  br label %bb1
bb1:
  %t15 = load i64, ptr %l10, !tbaa !24
  %t16 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr ptr, ptr %t17, i64 %t15
  %t19 = load ptr, ptr %t18, !tbaa !39
  store ptr %t19, ptr %l3, !tbaa !29
  br label %bb2
bb2:
  %t21 = load ptr, ptr %l3, !tbaa !29
  %t23 = icmp eq ptr %t21, null
  %t25 = xor i1 %t23, true
  %t27 = xor i1 %t25, true
  br i1 %t27, label %bb3, label %bb4
bb3:
  br label %bb11
bb4:
  br label %bb5
bb5:
  %t29 = load ptr, ptr %l3, !tbaa !29
  %t31 = getelementptr %"std/prelude/map:mapSlot.ab8e368d2e26ea985fc81f522ce8ac91", ptr %t29, i32 0, i32 0
  %t32 = getelementptr %"std/prelude/map:MapEntry.adf118859e04490c36a9a3f2e59cf058", ptr %t31, i32 0, i32 0
  %t33 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %t32
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t33, ptr %l17
  %t34 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l1
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t34, ptr %l19
  %t37 = call i1 @olang_2eHelperKind_2eEqual_2estd_2fpair_3aPair_3cI64_2c_20I64_3e(ptr %l17, ptr %l19)
  store i1 %t37, ptr %l21
  br label %bb6
bb6:
  %t38 = load i1, ptr %l21, !tbaa !21
  br i1 %t38, label %bb7, label %bb8
bb7:
  %t39 = load ptr, ptr %l3, !tbaa !29
  %t41 = getelementptr %"std/prelude/map:mapSlot.ab8e368d2e26ea985fc81f522ce8ac91", ptr %t39, i32 0, i32 0
  %t42 = getelementptr %"std/prelude/map:MapEntry.adf118859e04490c36a9a3f2e59cf058", ptr %t41, i32 0, i32 1
  %t43 = load { i64, ptr }, ptr %t42, !tbaa !27
  %t45 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t43, 1
  store { i32, { i64, ptr } } %t45, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t46 = load ptr, ptr %l3, !tbaa !29
  %t48 = getelementptr %"std/prelude/map:mapSlot.ab8e368d2e26ea985fc81f522ce8ac91", ptr %t46, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !29
  store ptr %t49, ptr %l3, !tbaa !29
  br label %bb2
bb11:
  %t52 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t52, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H5daf2b89f219287cc2404f0b0e96c809(ptr %v0, ptr %v1, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, %"compiler/check:fixedInit" %a2) #0 {
entry:
  %l1 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l2 = alloca %"compiler/check:fixedInit"
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca ptr
  %l10 = alloca i64
  %l12 = alloca { i64, ptr }
  %l20 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l22 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l24 = alloca i1
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, ptr %l1
  store %"compiler/check:fixedInit" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load ptr, ptr %l3, !tbaa !29
  %t7 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l1
  %t10 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cstd_2fpair_3aPair_3cI64_2c_20I64__H25550a5aa964c9352053a58344d5fc74(ptr %v0, ptr %t6, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t7)
  store i64 %t10, ptr %l10
  br label %bb1
bb1:
  %t11 = load i64, ptr %l10, !tbaa !24
  store i64 %t11, ptr %l4, !tbaa !24
  %t12 = load ptr, ptr %l3, !tbaa !29
  %t14 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  store { i64, ptr } %t15, ptr %l12, !tbaa !27
  %t16 = load i64, ptr %l4, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  store ptr %t21, ptr %l5, !tbaa !29
  br label %bb2
bb2:
  %t23 = load ptr, ptr %l5, !tbaa !29
  %t25 = icmp eq ptr %t23, null
  %t27 = xor i1 %t25, true
  %t29 = xor i1 %t27, true
  br i1 %t29, label %bb3, label %bb4
bb3:
  br label %bb11
bb4:
  br label %bb5
bb5:
  %t31 = load ptr, ptr %l5, !tbaa !29
  %t33 = getelementptr %"std/prelude/map:mapSlot.8d5f4b852d3f9c4d7ccf5e7675d9833d", ptr %t31, i32 0, i32 0
  %t34 = getelementptr %"std/prelude/map:MapEntry.c479befe3d340af6fb5e3e84080d9cfc", ptr %t33, i32 0, i32 0
  %t35 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %t34
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t35, ptr %l20
  %t36 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l1
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t36, ptr %l22
  %t39 = call i1 @olang_2eHelperKind_2eEqual_2estd_2fpair_3aPair_3cI64_2c_20I64_3e(ptr %l20, ptr %l22)
  store i1 %t39, ptr %l24
  br label %bb6
bb6:
  %t40 = load i1, ptr %l24, !tbaa !21
  br i1 %t40, label %bb7, label %bb8
bb7:
  %t41 = load ptr, ptr %l5, !tbaa !29
  %t42 = load %"compiler/check:fixedInit", ptr %l2
  %t45 = getelementptr %"std/prelude/map:mapSlot.8d5f4b852d3f9c4d7ccf5e7675d9833d", ptr %t41, i32 0, i32 0
  %t46 = getelementptr %"std/prelude/map:MapEntry.c479befe3d340af6fb5e3e84080d9cfc", ptr %t45, i32 0, i32 1
  store %"compiler/check:fixedInit" %t42, ptr %t46
  br label %ret
bb8:
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t47 = load ptr, ptr %l5, !tbaa !29
  %t49 = getelementptr %"std/prelude/map:mapSlot.8d5f4b852d3f9c4d7ccf5e7675d9833d", ptr %t47, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !29
  store ptr %t50, ptr %l5, !tbaa !29
  br label %bb2
bb11:
  %t52 = load ptr, ptr %l3, !tbaa !29
  %t53 = load i64, ptr %l4, !tbaa !24
  %t54 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l1
  %t55 = load %"compiler/check:fixedInit", ptr %l2
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cstd_2fpair_3aPair_3cI64_2c_20I64__Ha7ee54d42e4cb7e14b56fc3c6a6b8eb5(ptr %v0, ptr %v1, ptr %t52, i64 %t53, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t54, %"compiler/check:fixedInit" %t55)
  br label %bb12
bb12:
  br label %ret
ret:
  ret void
}

define dso_local i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H77423593ceb02e5da917ccb6013316ec(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1) #0 {
entry:
  %l1 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l10 = alloca i64
  %l17 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l19 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l21 = alloca i1
  %rv = alloca i1
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t6, i32 0, i32 0
  %t9 = load { i64, ptr }, ptr %t8, !tbaa !27
  store { i64, ptr } %t9, ptr %l7, !tbaa !27
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t11 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l1
  %t14 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cstd_2fpair_3aPair_3cI64_2c_20I64__H25550a5aa964c9352053a58344d5fc74(ptr %v0, ptr %t10, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t11)
  store i64 %t14, ptr %l10
  br label %bb1
bb1:
  %t15 = load i64, ptr %l10, !tbaa !24
  %t16 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr ptr, ptr %t17, i64 %t15
  %t19 = load ptr, ptr %t18, !tbaa !39
  store ptr %t19, ptr %l3, !tbaa !29
  br label %bb2
bb2:
  %t21 = load ptr, ptr %l3, !tbaa !29
  %t23 = icmp eq ptr %t21, null
  %t25 = xor i1 %t23, true
  %t27 = xor i1 %t25, true
  br i1 %t27, label %bb3, label %bb4
bb3:
  br label %bb11
bb4:
  br label %bb5
bb5:
  %t29 = load ptr, ptr %l3, !tbaa !29
  %t31 = getelementptr %"std/prelude/map:mapSlot.68a4db19b59c4f3946b7eb69de485429", ptr %t29, i32 0, i32 0
  %t32 = getelementptr %"std/prelude/map:MapEntry.886e108519677d9fd0a73cc9f7e545eb", ptr %t31, i32 0, i32 0
  %t33 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %t32
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t33, ptr %l17
  %t34 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l1
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t34, ptr %l19
  %t37 = call i1 @olang_2eHelperKind_2eEqual_2estd_2fpair_3aPair_3cI64_2c_20I64_3e(ptr %l17, ptr %l19)
  store i1 %t37, ptr %l21
  br label %bb6
bb6:
  %t38 = load i1, ptr %l21, !tbaa !21
  br i1 %t38, label %bb7, label %bb8
bb7:
  store i1 true, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t40 = load ptr, ptr %l3, !tbaa !29
  %t42 = getelementptr %"std/prelude/map:mapSlot.68a4db19b59c4f3946b7eb69de485429", ptr %t40, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !29
  store ptr %t43, ptr %l3, !tbaa !29
  br label %bb2
bb11:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H970bb490312910b3b744570a26468c6c(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1) #0 {
entry:
  %l1 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l10 = alloca i64
  %l17 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l19 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l21 = alloca i1
  %rv = alloca i1
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t6, i32 0, i32 0
  %t9 = load { i64, ptr }, ptr %t8, !tbaa !27
  store { i64, ptr } %t9, ptr %l7, !tbaa !27
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t11 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l1
  %t14 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cstd_2fpair_3aPair_3cI64_2c_20I64__H25550a5aa964c9352053a58344d5fc74(ptr %v0, ptr %t10, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t11)
  store i64 %t14, ptr %l10
  br label %bb1
bb1:
  %t15 = load i64, ptr %l10, !tbaa !24
  %t16 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr ptr, ptr %t17, i64 %t15
  %t19 = load ptr, ptr %t18, !tbaa !39
  store ptr %t19, ptr %l3, !tbaa !29
  br label %bb2
bb2:
  %t21 = load ptr, ptr %l3, !tbaa !29
  %t23 = icmp eq ptr %t21, null
  %t25 = xor i1 %t23, true
  %t27 = xor i1 %t25, true
  br i1 %t27, label %bb3, label %bb4
bb3:
  br label %bb11
bb4:
  br label %bb5
bb5:
  %t29 = load ptr, ptr %l3, !tbaa !29
  %t31 = getelementptr %"std/prelude/map:mapSlot.a04f5d5eeace3a348c0931984fa7d629", ptr %t29, i32 0, i32 0
  %t32 = getelementptr %"std/prelude/map:MapEntry.ecf182cf123eba82aed5d6288e5f1385", ptr %t31, i32 0, i32 0
  %t33 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %t32
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t33, ptr %l17
  %t34 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l1
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t34, ptr %l19
  %t37 = call i1 @olang_2eHelperKind_2eEqual_2estd_2fpair_3aPair_3cI64_2c_20I64_3e(ptr %l17, ptr %l19)
  store i1 %t37, ptr %l21
  br label %bb6
bb6:
  %t38 = load i1, ptr %l21, !tbaa !21
  br i1 %t38, label %bb7, label %bb8
bb7:
  store i1 true, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t40 = load ptr, ptr %l3, !tbaa !29
  %t42 = getelementptr %"std/prelude/map:mapSlot.a04f5d5eeace3a348c0931984fa7d629", ptr %t40, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !29
  store ptr %t43, ptr %l3, !tbaa !29
  br label %bb2
bb11:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i32, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_Hca9d4f63e6a0ec4764c25705e3ecdd1f(ptr %v0, ptr %v1, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1) #0 {
entry:
  %l1 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l10 = alloca i64
  %l17 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l19 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l21 = alloca i1
  %rv = alloca { i32, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t6, i32 0, i32 0
  %t9 = load { i64, ptr }, ptr %t8, !tbaa !27
  store { i64, ptr } %t9, ptr %l7, !tbaa !27
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t11 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l1
  %t14 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cstd_2fpair_3aPair_3cI64_2c_20I64__H25550a5aa964c9352053a58344d5fc74(ptr %v0, ptr %t10, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t11)
  store i64 %t14, ptr %l10
  br label %bb1
bb1:
  %t15 = load i64, ptr %l10, !tbaa !24
  %t16 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr ptr, ptr %t17, i64 %t15
  %t19 = load ptr, ptr %t18, !tbaa !39
  store ptr %t19, ptr %l3, !tbaa !29
  br label %bb2
bb2:
  %t21 = load ptr, ptr %l3, !tbaa !29
  %t23 = icmp eq ptr %t21, null
  %t25 = xor i1 %t23, true
  %t27 = xor i1 %t25, true
  br i1 %t27, label %bb3, label %bb4
bb3:
  br label %bb11
bb4:
  br label %bb5
bb5:
  %t29 = load ptr, ptr %l3, !tbaa !29
  %t31 = getelementptr %"std/prelude/map:mapSlot.a04f5d5eeace3a348c0931984fa7d629", ptr %t29, i32 0, i32 0
  %t32 = getelementptr %"std/prelude/map:MapEntry.ecf182cf123eba82aed5d6288e5f1385", ptr %t31, i32 0, i32 0
  %t33 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %t32
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t33, ptr %l17
  %t34 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l1
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t34, ptr %l19
  %t37 = call i1 @olang_2eHelperKind_2eEqual_2estd_2fpair_3aPair_3cI64_2c_20I64_3e(ptr %l17, ptr %l19)
  store i1 %t37, ptr %l21
  br label %bb6
bb6:
  %t38 = load i1, ptr %l21, !tbaa !21
  br i1 %t38, label %bb7, label %bb8
bb7:
  %t39 = load ptr, ptr %l3, !tbaa !29
  %t41 = getelementptr %"std/prelude/map:mapSlot.a04f5d5eeace3a348c0931984fa7d629", ptr %t39, i32 0, i32 0
  %t42 = getelementptr %"std/prelude/map:MapEntry.ecf182cf123eba82aed5d6288e5f1385", ptr %t41, i32 0, i32 1
  %t43 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t42
  %t45 = insertvalue { i32, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" } zeroinitializer, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t43, 1
  store { i32, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" } %t45, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t46 = load ptr, ptr %l3, !tbaa !29
  %t48 = getelementptr %"std/prelude/map:mapSlot.a04f5d5eeace3a348c0931984fa7d629", ptr %t46, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !29
  store ptr %t49, ptr %l3, !tbaa !29
  br label %bb2
bb11:
  %t52 = insertvalue { i32, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" } zeroinitializer, i32 65536, 0
  store { i32, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" } %t52, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }, ptr %rv
  ret { i32, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" } %rr
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_Hd862b35741eab3a632965773dd6b12ba(ptr %v0, ptr %v1, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, %"compiler/check:roOrigin" %a2) #0 {
entry:
  %l1 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l2 = alloca %"compiler/check:roOrigin"
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca ptr
  %l10 = alloca i64
  %l12 = alloca { i64, ptr }
  %l20 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l22 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l24 = alloca i1
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, ptr %l1
  store %"compiler/check:roOrigin" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load ptr, ptr %l3, !tbaa !29
  %t7 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l1
  %t10 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cstd_2fpair_3aPair_3cI64_2c_20I64__H25550a5aa964c9352053a58344d5fc74(ptr %v0, ptr %t6, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t7)
  store i64 %t10, ptr %l10
  br label %bb1
bb1:
  %t11 = load i64, ptr %l10, !tbaa !24
  store i64 %t11, ptr %l4, !tbaa !24
  %t12 = load ptr, ptr %l3, !tbaa !29
  %t14 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  store { i64, ptr } %t15, ptr %l12, !tbaa !27
  %t16 = load i64, ptr %l4, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  store ptr %t21, ptr %l5, !tbaa !29
  br label %bb2
bb2:
  %t23 = load ptr, ptr %l5, !tbaa !29
  %t25 = icmp eq ptr %t23, null
  %t27 = xor i1 %t25, true
  %t29 = xor i1 %t27, true
  br i1 %t29, label %bb3, label %bb4
bb3:
  br label %bb11
bb4:
  br label %bb5
bb5:
  %t31 = load ptr, ptr %l5, !tbaa !29
  %t33 = getelementptr %"std/prelude/map:mapSlot.fb4da8fc57bf420be68a6f6108589d27", ptr %t31, i32 0, i32 0
  %t34 = getelementptr %"std/prelude/map:MapEntry.cae77de4d581cc3ff23f947d2513f613", ptr %t33, i32 0, i32 0
  %t35 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %t34
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t35, ptr %l20
  %t36 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l1
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t36, ptr %l22
  %t39 = call i1 @olang_2eHelperKind_2eEqual_2estd_2fpair_3aPair_3cI64_2c_20I64_3e(ptr %l20, ptr %l22)
  store i1 %t39, ptr %l24
  br label %bb6
bb6:
  %t40 = load i1, ptr %l24, !tbaa !21
  br i1 %t40, label %bb7, label %bb8
bb7:
  %t41 = load ptr, ptr %l5, !tbaa !29
  %t42 = load %"compiler/check:roOrigin", ptr %l2
  %t45 = getelementptr %"std/prelude/map:mapSlot.fb4da8fc57bf420be68a6f6108589d27", ptr %t41, i32 0, i32 0
  %t46 = getelementptr %"std/prelude/map:MapEntry.cae77de4d581cc3ff23f947d2513f613", ptr %t45, i32 0, i32 1
  store %"compiler/check:roOrigin" %t42, ptr %t46
  br label %ret
bb8:
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t47 = load ptr, ptr %l5, !tbaa !29
  %t49 = getelementptr %"std/prelude/map:mapSlot.fb4da8fc57bf420be68a6f6108589d27", ptr %t47, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !29
  store ptr %t50, ptr %l5, !tbaa !29
  br label %bb2
bb11:
  %t52 = load ptr, ptr %l3, !tbaa !29
  %t53 = load i64, ptr %l4, !tbaa !24
  %t54 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l1
  %t55 = load %"compiler/check:roOrigin", ptr %l2
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cstd_2fpair_3aPair_3cI64_2c_20I64__H5aea25241f96c65f2f55c38f04b7fbef(ptr %v0, ptr %v1, ptr %t52, i64 %t53, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t54, %"compiler/check:roOrigin" %t55)
  br label %bb12
bb12:
  br label %ret
ret:
  ret void
}

define dso_local { i32, %"compiler/check:roOrigin" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_Hfc56ff01c357e6bb827daf7012f18a86(ptr %v0, ptr %v1, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1) #0 {
entry:
  %l1 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l10 = alloca i64
  %l17 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l19 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l21 = alloca i1
  %rv = alloca { i32, %"compiler/check:roOrigin" }
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t6, i32 0, i32 0
  %t9 = load { i64, ptr }, ptr %t8, !tbaa !27
  store { i64, ptr } %t9, ptr %l7, !tbaa !27
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t11 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l1
  %t14 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cstd_2fpair_3aPair_3cI64_2c_20I64__H25550a5aa964c9352053a58344d5fc74(ptr %v0, ptr %t10, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t11)
  store i64 %t14, ptr %l10
  br label %bb1
bb1:
  %t15 = load i64, ptr %l10, !tbaa !24
  %t16 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr ptr, ptr %t17, i64 %t15
  %t19 = load ptr, ptr %t18, !tbaa !39
  store ptr %t19, ptr %l3, !tbaa !29
  br label %bb2
bb2:
  %t21 = load ptr, ptr %l3, !tbaa !29
  %t23 = icmp eq ptr %t21, null
  %t25 = xor i1 %t23, true
  %t27 = xor i1 %t25, true
  br i1 %t27, label %bb3, label %bb4
bb3:
  br label %bb11
bb4:
  br label %bb5
bb5:
  %t29 = load ptr, ptr %l3, !tbaa !29
  %t31 = getelementptr %"std/prelude/map:mapSlot.fb4da8fc57bf420be68a6f6108589d27", ptr %t29, i32 0, i32 0
  %t32 = getelementptr %"std/prelude/map:MapEntry.cae77de4d581cc3ff23f947d2513f613", ptr %t31, i32 0, i32 0
  %t33 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %t32
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t33, ptr %l17
  %t34 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l1
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t34, ptr %l19
  %t37 = call i1 @olang_2eHelperKind_2eEqual_2estd_2fpair_3aPair_3cI64_2c_20I64_3e(ptr %l17, ptr %l19)
  store i1 %t37, ptr %l21
  br label %bb6
bb6:
  %t38 = load i1, ptr %l21, !tbaa !21
  br i1 %t38, label %bb7, label %bb8
bb7:
  %t39 = load ptr, ptr %l3, !tbaa !29
  %t41 = getelementptr %"std/prelude/map:mapSlot.fb4da8fc57bf420be68a6f6108589d27", ptr %t39, i32 0, i32 0
  %t42 = getelementptr %"std/prelude/map:MapEntry.cae77de4d581cc3ff23f947d2513f613", ptr %t41, i32 0, i32 1
  %t43 = load %"compiler/check:roOrigin", ptr %t42
  %t45 = insertvalue { i32, %"compiler/check:roOrigin" } zeroinitializer, %"compiler/check:roOrigin" %t43, 1
  store { i32, %"compiler/check:roOrigin" } %t45, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t46 = load ptr, ptr %l3, !tbaa !29
  %t48 = getelementptr %"std/prelude/map:mapSlot.fb4da8fc57bf420be68a6f6108589d27", ptr %t46, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !29
  store ptr %t49, ptr %l3, !tbaa !29
  br label %bb2
bb11:
  %t52 = insertvalue { i32, %"compiler/check:roOrigin" } zeroinitializer, i32 65536, 0
  store { i32, %"compiler/check:roOrigin" } %t52, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"compiler/check:roOrigin" }, ptr %rv
  ret { i32, %"compiler/check:roOrigin" } %rr
}

define dso_local i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cI64_2c_20compiler_2fcheck_3arawTa_H5fdea02d6cc268318fc11ef68777d551(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %r = tail call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cI64_2c_20Bool_3e_2ebucketOf_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
  ret i64 %r
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cI64_2c_20compiler_2fcheck_3arawTa_Hb7919b3c85db2b170fdb258585e4b1be(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, ptr %a3) #0 {
entry:
  tail call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cI64_2c_20compiler_2ftyped_3aExpr__H6646a6f2a04f565d0bff5df703125aa2(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, ptr %a3)
  ret void
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cI64_2c_20compiler_2fcheck_3arawTa_Hced92ea880e90fb5f4b6a90cea502dc6(ptr %v0, ptr %a0) #0 {
entry:
  tail call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cI64_2c_20compiler_2ftyped_3aExpr__H027e3b5d3e589e6555ba51c13998d337(ptr %v0, ptr %a0)
  ret void
}

define dso_local i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cI64_2c_20compiler_2fdiag_3aWhere__H8662dd0dcc051be5ef1e8f34ff2ada81(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %r = tail call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cI64_2c_20Bool_3e_2ebucketOf_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
  ret i64 %r
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cI64_2c_20compiler_2ftyped_3aContr_H99da597b4067da6fce96bff81dbb1566(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, %"compiler/typed:ContractInfo" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca %"compiler/typed:ContractInfo"
  %l4 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l15 = alloca { i64, ptr }
  %l18 = alloca %"std/prelude/map:mapSlot.0482058481105505dc7df18be1ecde54"
  %l23 = alloca ptr
  %l26 = alloca %"std/prelude/map:MapEntry.30ce370d829aff239a34c06a62e67c2e"
  %l29 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l37 = alloca ptr
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  store %"compiler/typed:ContractInfo" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = load ptr, ptr %l4, !tbaa !29
  %t8 = icmp eq ptr %t6, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  store { i64, ptr } %t13, ptr %l10, !tbaa !27
  %t14 = load i64, ptr %l1, !tbaa !24
  store i64 %t14, ptr %l11, !tbaa !24
  %t15 = load i64, ptr %l2, !tbaa !24
  %t16 = load %"compiler/typed:ContractInfo", ptr %l3
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t17, i32 0, i32 0
  %t20 = load { i64, ptr }, ptr %t19, !tbaa !27
  store { i64, ptr } %t20, ptr %l15, !tbaa !27
  %t21 = load i64, ptr %l1, !tbaa !24
  %t23 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = getelementptr ptr, ptr %t24, i64 %t21
  %t26 = load ptr, ptr %t25, !tbaa !39
  %t30 = call %"std/prelude/map:mapSlot.0482058481105505dc7df18be1ecde54" @std_2fprelude_2fmap_3amapSlot_3cI64_2c_20compiler_2ftyped_3aContractInfo_3e_2ector(ptr %v1, ptr %v0, ptr %v0, i64 %t15, %"compiler/typed:ContractInfo" %t16, ptr %t26)
  store %"std/prelude/map:mapSlot.0482058481105505dc7df18be1ecde54" %t30, ptr %l18
  br label %bb3
bb2:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load ptr, ptr %l4, !tbaa !29
  %t34 = getelementptr %"std/prelude/map:mapSlot.0482058481105505dc7df18be1ecde54", ptr %t32, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t38 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t31, i32 0, i32 2
  store ptr %t35, ptr %t38, !tbaa !29
  %t39 = load ptr, ptr %l4, !tbaa !29
  store ptr %t39, ptr %l23, !tbaa !29
  %t40 = load i64, ptr %l2, !tbaa !24
  %t41 = load %"compiler/typed:ContractInfo", ptr %l3
  %t44 = call %"std/prelude/map:MapEntry.30ce370d829aff239a34c06a62e67c2e" @std_2fprelude_2fmap_3aMapEntry_3cI64_2c_20compiler_2ftyped_3aContractInfo_3e_2ector(ptr %v1, ptr %v0, i64 %t40, %"compiler/typed:ContractInfo" %t41)
  store %"std/prelude/map:MapEntry.30ce370d829aff239a34c06a62e67c2e" %t44, ptr %l26
  br label %bb4
bb3:
  %t45 = load %"std/prelude/map:mapSlot.0482058481105505dc7df18be1ecde54", ptr %l18
  %t46 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 64, i64 8)
  store %"std/prelude/map:mapSlot.0482058481105505dc7df18be1ecde54" %t45, ptr %t46
  %t48 = load i64, ptr %l11, !tbaa !24
  %t49 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !27
  %t51 = getelementptr ptr, ptr %t50, i64 %t48
  store ptr %t46, ptr %t51, !tbaa !39
  br label %bb5
bb4:
  %t52 = load %"std/prelude/map:MapEntry.30ce370d829aff239a34c06a62e67c2e", ptr %l26
  %t53 = load ptr, ptr %l23, !tbaa !29
  %t54 = getelementptr %"std/prelude/map:mapSlot.0482058481105505dc7df18be1ecde54", ptr %t53, i32 0, i32 0
  store %"std/prelude/map:MapEntry.30ce370d829aff239a34c06a62e67c2e" %t52, ptr %t54
  %t55 = load ptr, ptr %l4, !tbaa !29
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t56, i32 0, i32 0
  %t59 = load { i64, ptr }, ptr %t58, !tbaa !27
  store { i64, ptr } %t59, ptr %l29, !tbaa !27
  %t60 = load i64, ptr %l1, !tbaa !24
  %t62 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !27
  %t64 = getelementptr ptr, ptr %t63, i64 %t60
  %t65 = load ptr, ptr %t64, !tbaa !39
  %t68 = getelementptr %"std/prelude/map:mapSlot.0482058481105505dc7df18be1ecde54", ptr %t55, i32 0, i32 1
  store ptr %t65, ptr %t68, !tbaa !29
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t69, i32 0, i32 0
  %t72 = load { i64, ptr }, ptr %t71, !tbaa !27
  store { i64, ptr } %t72, ptr %l33, !tbaa !27
  %t73 = load i64, ptr %l1, !tbaa !24
  %t74 = load ptr, ptr %l4, !tbaa !29
  %t78 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !27
  %t80 = getelementptr ptr, ptr %t79, i64 %t73
  store ptr %t74, ptr %t80, !tbaa !39
  br label %bb5
bb5:
  %t81 = load ptr, ptr %l0, !tbaa !29
  store ptr %t81, ptr %l37, !tbaa !29
  %t82 = load ptr, ptr %l37, !tbaa !29
  %t83 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t82, i32 0, i32 1
  %t84 = load i64, ptr %t83, !tbaa !24
  %t86 = add i64 %t84, 1
  %t88 = load ptr, ptr %l37, !tbaa !29
  %t89 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t88, i32 0, i32 1
  store i64 %t86, ptr %t89, !tbaa !24
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t90, i32 0, i32 1
  %t93 = load i64, ptr %t92, !tbaa !24
  %t95 = mul i64 %t93, 4
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t96, i32 0, i32 0
  %t99 = load { i64, ptr }, ptr %t98, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t99, 0
  %t103 = mul i64 %t101, 3
  %t106 = icmp sgt i64 %t95, %t103
  br i1 %t106, label %bb6, label %bb7
bb6:
  %t108 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cI64_2c_20compiler_2ftyped_3aContr_H20853fbbac28f6a5fef071a48c93be5b(ptr %v0, ptr %t108)
  br label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb9
bb9:
  br label %ret
ret:
  ret void
}

define dso_local i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cI64_2c_20compiler_2ftyped_3aContr_He7dca0e2d2ffdb49c0e59439558235b6(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %r = tail call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cI64_2c_20Bool_3e_2ebucketOf_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
  ret i64 %r
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cI64_2c_20compiler_2ftypes_3aListI_H44346299f9d460ad0f2ba394b0dabb03(ptr %v0, ptr %a0) #0 {
entry:
  tail call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cI64_2c_20compiler_2ftypes_3aDeclI_H4c1de9fecd9c99d5a63a8f7c9df161c3(ptr %v0, ptr %a0)
  ret void
}

define dso_local i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cI64_2c_20compiler_2ftypes_3aListI_Hdcc4798627a202995ecd769b5d324d92(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %r = tail call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cI64_2c_20Bool_3e_2ebucketOf_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
  ret i64 %r
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cI64_2c_20compiler_2ftypes_3aListI_Hf735b9054feec877514a91dd21d03762(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i32 %a3) #0 {
entry:
  tail call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cI64_2c_20compiler_2ftypes_3aDeclI_H9f3979565f0fefdf5266a328cdc0c138(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i32 %a3)
  ret void
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cstd_2fpair_3aPair_3cI64_2c_20I64__H50f712737ee61aad29364fb3fd21f583(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i64
  %l13 = alloca ptr
  %l16 = alloca i64
  %l25 = alloca i64
  %l28 = alloca i64
  %l46 = alloca { i64, ptr }
  %l58 = alloca i64
  %l61 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l1, !tbaa !27
  %t6 = load ptr, ptr %l0, !tbaa !29
  store ptr %t6, ptr %l13, !tbaa !29
  %t7 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  %t11 = mul i64 %t9, 2
  store i64 %t11, ptr %l16, !tbaa !24
  %t12 = load i64, ptr %l16, !tbaa !24
  %t13 = icmp sge i64 %t12, 0
  br i1 %t13, label %bb1, label %bb2
bb1:
  %t15 = load i64, ptr %l16, !tbaa !24
  %t16 = icmp sle i64 %t15, 1152921504606846975
  br i1 %t16, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_b3cca19c3c2efe3_f96c380b9c020d2f)
  unreachable
bb3:
  %t18 = load i64, ptr %l16, !tbaa !24
  %t19 = mul i64 %t18, 8
  %t20 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t19)
  %t21 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t24 = load ptr, ptr %l13, !tbaa !29
  %t25 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t24, i32 0, i32 0
  store { i64, ptr } %t22, ptr %t25, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  %t26 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t26, 0
  store i64 %t28, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t30 = load i64, ptr %l3, !tbaa !24
  %t31 = load i64, ptr %l2, !tbaa !24
  %t34 = icmp sgt i64 %t30, %t31
  br i1 %t34, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_b3cca19c3c2efe3_f96c380b9c020d2f)
  unreachable
bb5:
  %t36 = load i64, ptr %l4, !tbaa !24
  %t38 = icmp sgt i64 %t36, 0
  br i1 %t38, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l25, !tbaa !24
  br label %bb10
bb7:
  %t40 = load i64, ptr %l3, !tbaa !24
  %t41 = load i64, ptr %l2, !tbaa !24
  %t44 = sub i64 %t40, %t41
  %t45 = load i64, ptr %l4, !tbaa !24
  %t48 = add i64 %t44, %t45
  %t50 = sub i64 %t48, 1
  %t51 = load i64, ptr %l4, !tbaa !24
  %t54 = sdiv i64 %t50, %t51
  store i64 %t54, ptr %l28, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb9
bb9:
  %t56 = load i64, ptr %l28, !tbaa !24
  store i64 %t56, ptr %l25, !tbaa !24
  br label %bb10
bb10:
  %t57 = load i64, ptr %l25, !tbaa !24
  store i64 %t57, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb11
bb11:
  %t58 = load i64, ptr %l6, !tbaa !24
  %t59 = load i64, ptr %l5, !tbaa !24
  %t62 = icmp slt i64 %t58, %t59
  %t64 = xor i1 %t62, true
  br i1 %t64, label %bb12, label %bb13
bb12:
  br label %bb23
bb13:
  br label %bb14
bb14:
  %t66 = load i64, ptr %l2, !tbaa !24
  %t67 = load i64, ptr %l6, !tbaa !24
  %t68 = load i64, ptr %l4, !tbaa !24
  %t71 = mul i64 %t67, %t68
  %t74 = add i64 %t66, %t71
  %t76 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t76, ptr %l46, !tbaa !27
  %t79 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = getelementptr ptr, ptr %t80, i64 %t74
  %t82 = load ptr, ptr %t81, !tbaa !39
  store ptr %t82, ptr %l8, !tbaa !29
  br label %bb15
bb15:
  %t84 = load ptr, ptr %l8, !tbaa !29
  %t86 = icmp eq ptr %t84, null
  %t88 = xor i1 %t86, true
  %t90 = xor i1 %t88, true
  br i1 %t90, label %bb16, label %bb17
bb16:
  br label %bb21
bb17:
  br label %bb18
bb18:
  %t92 = load ptr, ptr %l8, !tbaa !29
  %t94 = getelementptr %"std/prelude/map:mapSlot.fb4da8fc57bf420be68a6f6108589d27", ptr %t92, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !29
  store ptr %t95, ptr %l9, !tbaa !29
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t98 = load ptr, ptr %l8, !tbaa !29
  %t100 = getelementptr %"std/prelude/map:mapSlot.fb4da8fc57bf420be68a6f6108589d27", ptr %t98, i32 0, i32 0
  %t101 = getelementptr %"std/prelude/map:MapEntry.cae77de4d581cc3ff23f947d2513f613", ptr %t100, i32 0, i32 0
  %t102 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %t101
  %t105 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cstd_2fpair_3aPair_3cI64_2c_20I64__H25550a5aa964c9352053a58344d5fc74(ptr %v0, ptr %t97, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t102)
  store i64 %t105, ptr %l58
  br label %bb19
bb19:
  %t106 = load i64, ptr %l58, !tbaa !24
  store i64 %t106, ptr %l10, !tbaa !24
  %t107 = load ptr, ptr %l8, !tbaa !29
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t108, i32 0, i32 0
  %t111 = load { i64, ptr }, ptr %t110, !tbaa !27
  store { i64, ptr } %t111, ptr %l61, !tbaa !27
  %t112 = load i64, ptr %l10, !tbaa !24
  %t114 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !27
  %t116 = getelementptr ptr, ptr %t115, i64 %t112
  %t117 = load ptr, ptr %t116, !tbaa !39
  %t120 = getelementptr %"std/prelude/map:mapSlot.fb4da8fc57bf420be68a6f6108589d27", ptr %t107, i32 0, i32 1
  store ptr %t117, ptr %t120, !tbaa !29
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t121, i32 0, i32 0
  %t124 = load { i64, ptr }, ptr %t123, !tbaa !27
  store { i64, ptr } %t124, ptr %l65, !tbaa !27
  %t125 = load i64, ptr %l10, !tbaa !24
  %t126 = load ptr, ptr %l8, !tbaa !29
  %t130 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !27
  %t132 = getelementptr ptr, ptr %t131, i64 %t125
  store ptr %t126, ptr %t132, !tbaa !39
  %t133 = load ptr, ptr %l9, !tbaa !29
  store ptr %t133, ptr %l8, !tbaa !29
  br label %bb20
bb20:
  br label %bb15
bb21:
  br label %bb22
bb22:
  %t135 = load i64, ptr %l6, !tbaa !24
  %t137 = add i64 %t135, 1
  store i64 %t137, ptr %l6, !tbaa !24
  br label %bb11
bb23:
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cstd_2fpair_3aPair_3cI64_2c_20I64__H53bbd9f5fe8f1bd11963185242a67f8c(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i64
  %l13 = alloca ptr
  %l16 = alloca i64
  %l25 = alloca i64
  %l28 = alloca i64
  %l46 = alloca { i64, ptr }
  %l58 = alloca i64
  %l61 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l1, !tbaa !27
  %t6 = load ptr, ptr %l0, !tbaa !29
  store ptr %t6, ptr %l13, !tbaa !29
  %t7 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  %t11 = mul i64 %t9, 2
  store i64 %t11, ptr %l16, !tbaa !24
  %t12 = load i64, ptr %l16, !tbaa !24
  %t13 = icmp sge i64 %t12, 0
  br i1 %t13, label %bb1, label %bb2
bb1:
  %t15 = load i64, ptr %l16, !tbaa !24
  %t16 = icmp sle i64 %t15, 1152921504606846975
  br i1 %t16, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_45f508538682dd99_32966c8d2ce9c445)
  unreachable
bb3:
  %t18 = load i64, ptr %l16, !tbaa !24
  %t19 = mul i64 %t18, 8
  %t20 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t19)
  %t21 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t24 = load ptr, ptr %l13, !tbaa !29
  %t25 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t24, i32 0, i32 0
  store { i64, ptr } %t22, ptr %t25, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  %t26 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t26, 0
  store i64 %t28, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t30 = load i64, ptr %l3, !tbaa !24
  %t31 = load i64, ptr %l2, !tbaa !24
  %t34 = icmp sgt i64 %t30, %t31
  br i1 %t34, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_45f508538682dd99_32966c8d2ce9c445)
  unreachable
bb5:
  %t36 = load i64, ptr %l4, !tbaa !24
  %t38 = icmp sgt i64 %t36, 0
  br i1 %t38, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l25, !tbaa !24
  br label %bb10
bb7:
  %t40 = load i64, ptr %l3, !tbaa !24
  %t41 = load i64, ptr %l2, !tbaa !24
  %t44 = sub i64 %t40, %t41
  %t45 = load i64, ptr %l4, !tbaa !24
  %t48 = add i64 %t44, %t45
  %t50 = sub i64 %t48, 1
  %t51 = load i64, ptr %l4, !tbaa !24
  %t54 = sdiv i64 %t50, %t51
  store i64 %t54, ptr %l28, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb9
bb9:
  %t56 = load i64, ptr %l28, !tbaa !24
  store i64 %t56, ptr %l25, !tbaa !24
  br label %bb10
bb10:
  %t57 = load i64, ptr %l25, !tbaa !24
  store i64 %t57, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb11
bb11:
  %t58 = load i64, ptr %l6, !tbaa !24
  %t59 = load i64, ptr %l5, !tbaa !24
  %t62 = icmp slt i64 %t58, %t59
  %t64 = xor i1 %t62, true
  br i1 %t64, label %bb12, label %bb13
bb12:
  br label %bb23
bb13:
  br label %bb14
bb14:
  %t66 = load i64, ptr %l2, !tbaa !24
  %t67 = load i64, ptr %l6, !tbaa !24
  %t68 = load i64, ptr %l4, !tbaa !24
  %t71 = mul i64 %t67, %t68
  %t74 = add i64 %t66, %t71
  %t76 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t76, ptr %l46, !tbaa !27
  %t79 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = getelementptr ptr, ptr %t80, i64 %t74
  %t82 = load ptr, ptr %t81, !tbaa !39
  store ptr %t82, ptr %l8, !tbaa !29
  br label %bb15
bb15:
  %t84 = load ptr, ptr %l8, !tbaa !29
  %t86 = icmp eq ptr %t84, null
  %t88 = xor i1 %t86, true
  %t90 = xor i1 %t88, true
  br i1 %t90, label %bb16, label %bb17
bb16:
  br label %bb21
bb17:
  br label %bb18
bb18:
  %t92 = load ptr, ptr %l8, !tbaa !29
  %t94 = getelementptr %"std/prelude/map:mapSlot.68a4db19b59c4f3946b7eb69de485429", ptr %t92, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !29
  store ptr %t95, ptr %l9, !tbaa !29
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t98 = load ptr, ptr %l8, !tbaa !29
  %t100 = getelementptr %"std/prelude/map:mapSlot.68a4db19b59c4f3946b7eb69de485429", ptr %t98, i32 0, i32 0
  %t101 = getelementptr %"std/prelude/map:MapEntry.886e108519677d9fd0a73cc9f7e545eb", ptr %t100, i32 0, i32 0
  %t102 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %t101
  %t105 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cstd_2fpair_3aPair_3cI64_2c_20I64__H25550a5aa964c9352053a58344d5fc74(ptr %v0, ptr %t97, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t102)
  store i64 %t105, ptr %l58
  br label %bb19
bb19:
  %t106 = load i64, ptr %l58, !tbaa !24
  store i64 %t106, ptr %l10, !tbaa !24
  %t107 = load ptr, ptr %l8, !tbaa !29
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t108, i32 0, i32 0
  %t111 = load { i64, ptr }, ptr %t110, !tbaa !27
  store { i64, ptr } %t111, ptr %l61, !tbaa !27
  %t112 = load i64, ptr %l10, !tbaa !24
  %t114 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !27
  %t116 = getelementptr ptr, ptr %t115, i64 %t112
  %t117 = load ptr, ptr %t116, !tbaa !39
  %t120 = getelementptr %"std/prelude/map:mapSlot.68a4db19b59c4f3946b7eb69de485429", ptr %t107, i32 0, i32 1
  store ptr %t117, ptr %t120, !tbaa !29
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t121, i32 0, i32 0
  %t124 = load { i64, ptr }, ptr %t123, !tbaa !27
  store { i64, ptr } %t124, ptr %l65, !tbaa !27
  %t125 = load i64, ptr %l10, !tbaa !24
  %t126 = load ptr, ptr %l8, !tbaa !29
  %t130 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !27
  %t132 = getelementptr ptr, ptr %t131, i64 %t125
  store ptr %t126, ptr %t132, !tbaa !39
  %t133 = load ptr, ptr %l9, !tbaa !29
  store ptr %t133, ptr %l8, !tbaa !29
  br label %bb20
bb20:
  br label %bb15
bb21:
  br label %bb22
bb22:
  %t135 = load i64, ptr %l6, !tbaa !24
  %t137 = add i64 %t135, 1
  store i64 %t137, ptr %l6, !tbaa !24
  br label %bb11
bb23:
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cstd_2fpair_3aPair_3cI64_2c_20I64__H5aea25241f96c65f2f55c38f04b7fbef(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a2, %"compiler/check:roOrigin" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l3 = alloca %"compiler/check:roOrigin"
  %l4 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l15 = alloca { i64, ptr }
  %l18 = alloca %"std/prelude/map:mapSlot.fb4da8fc57bf420be68a6f6108589d27"
  %l23 = alloca ptr
  %l26 = alloca %"std/prelude/map:MapEntry.cae77de4d581cc3ff23f947d2513f613"
  %l29 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l37 = alloca ptr
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a2, ptr %l2
  store %"compiler/check:roOrigin" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = load ptr, ptr %l4, !tbaa !29
  %t8 = icmp eq ptr %t6, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  store { i64, ptr } %t13, ptr %l10, !tbaa !27
  %t14 = load i64, ptr %l1, !tbaa !24
  store i64 %t14, ptr %l11, !tbaa !24
  %t15 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l2
  %t16 = load %"compiler/check:roOrigin", ptr %l3
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t17, i32 0, i32 0
  %t20 = load { i64, ptr }, ptr %t19, !tbaa !27
  store { i64, ptr } %t20, ptr %l15, !tbaa !27
  %t21 = load i64, ptr %l1, !tbaa !24
  %t23 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = getelementptr ptr, ptr %t24, i64 %t21
  %t26 = load ptr, ptr %t25, !tbaa !39
  %t30 = call %"std/prelude/map:mapSlot.fb4da8fc57bf420be68a6f6108589d27" @std_2fprelude_2fmap_3amapSlot_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20compiler_2fcheck_3aroOrigin_3e_2ector(ptr %v1, ptr %v0, ptr %v0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t15, %"compiler/check:roOrigin" %t16, ptr %t26)
  store %"std/prelude/map:mapSlot.fb4da8fc57bf420be68a6f6108589d27" %t30, ptr %l18
  br label %bb3
bb2:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load ptr, ptr %l4, !tbaa !29
  %t34 = getelementptr %"std/prelude/map:mapSlot.fb4da8fc57bf420be68a6f6108589d27", ptr %t32, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t38 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t31, i32 0, i32 2
  store ptr %t35, ptr %t38, !tbaa !29
  %t39 = load ptr, ptr %l4, !tbaa !29
  store ptr %t39, ptr %l23, !tbaa !29
  %t40 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l2
  %t41 = load %"compiler/check:roOrigin", ptr %l3
  %t44 = call %"std/prelude/map:MapEntry.cae77de4d581cc3ff23f947d2513f613" @std_2fprelude_2fmap_3aMapEntry_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20compiler_2fcheck_3aroOrigin_3e_2ector(ptr %v1, ptr %v0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t40, %"compiler/check:roOrigin" %t41)
  store %"std/prelude/map:MapEntry.cae77de4d581cc3ff23f947d2513f613" %t44, ptr %l26
  br label %bb4
bb3:
  %t45 = load %"std/prelude/map:mapSlot.fb4da8fc57bf420be68a6f6108589d27", ptr %l18
  %t46 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store %"std/prelude/map:mapSlot.fb4da8fc57bf420be68a6f6108589d27" %t45, ptr %t46
  %t48 = load i64, ptr %l11, !tbaa !24
  %t49 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !27
  %t51 = getelementptr ptr, ptr %t50, i64 %t48
  store ptr %t46, ptr %t51, !tbaa !39
  br label %bb5
bb4:
  %t52 = load %"std/prelude/map:MapEntry.cae77de4d581cc3ff23f947d2513f613", ptr %l26
  %t53 = load ptr, ptr %l23, !tbaa !29
  %t54 = getelementptr %"std/prelude/map:mapSlot.fb4da8fc57bf420be68a6f6108589d27", ptr %t53, i32 0, i32 0
  store %"std/prelude/map:MapEntry.cae77de4d581cc3ff23f947d2513f613" %t52, ptr %t54
  %t55 = load ptr, ptr %l4, !tbaa !29
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t56, i32 0, i32 0
  %t59 = load { i64, ptr }, ptr %t58, !tbaa !27
  store { i64, ptr } %t59, ptr %l29, !tbaa !27
  %t60 = load i64, ptr %l1, !tbaa !24
  %t62 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !27
  %t64 = getelementptr ptr, ptr %t63, i64 %t60
  %t65 = load ptr, ptr %t64, !tbaa !39
  %t68 = getelementptr %"std/prelude/map:mapSlot.fb4da8fc57bf420be68a6f6108589d27", ptr %t55, i32 0, i32 1
  store ptr %t65, ptr %t68, !tbaa !29
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t69, i32 0, i32 0
  %t72 = load { i64, ptr }, ptr %t71, !tbaa !27
  store { i64, ptr } %t72, ptr %l33, !tbaa !27
  %t73 = load i64, ptr %l1, !tbaa !24
  %t74 = load ptr, ptr %l4, !tbaa !29
  %t78 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !27
  %t80 = getelementptr ptr, ptr %t79, i64 %t73
  store ptr %t74, ptr %t80, !tbaa !39
  br label %bb5
bb5:
  %t81 = load ptr, ptr %l0, !tbaa !29
  store ptr %t81, ptr %l37, !tbaa !29
  %t82 = load ptr, ptr %l37, !tbaa !29
  %t83 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t82, i32 0, i32 1
  %t84 = load i64, ptr %t83, !tbaa !24
  %t86 = add i64 %t84, 1
  %t88 = load ptr, ptr %l37, !tbaa !29
  %t89 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t88, i32 0, i32 1
  store i64 %t86, ptr %t89, !tbaa !24
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t90, i32 0, i32 1
  %t93 = load i64, ptr %t92, !tbaa !24
  %t95 = mul i64 %t93, 4
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t96, i32 0, i32 0
  %t99 = load { i64, ptr }, ptr %t98, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t99, 0
  %t103 = mul i64 %t101, 3
  %t106 = icmp sgt i64 %t95, %t103
  br i1 %t106, label %bb6, label %bb7
bb6:
  %t108 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cstd_2fpair_3aPair_3cI64_2c_20I64__H50f712737ee61aad29364fb3fd21f583(ptr %v0, ptr %t108)
  br label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb9
bb9:
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cstd_2fpair_3aPair_3cI64_2c_20I64__H6587130e61ade78d21ab2f88c2eaebaa(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i64
  %l13 = alloca ptr
  %l16 = alloca i64
  %l25 = alloca i64
  %l28 = alloca i64
  %l46 = alloca { i64, ptr }
  %l58 = alloca i64
  %l61 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l1, !tbaa !27
  %t6 = load ptr, ptr %l0, !tbaa !29
  store ptr %t6, ptr %l13, !tbaa !29
  %t7 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  %t11 = mul i64 %t9, 2
  store i64 %t11, ptr %l16, !tbaa !24
  %t12 = load i64, ptr %l16, !tbaa !24
  %t13 = icmp sge i64 %t12, 0
  br i1 %t13, label %bb1, label %bb2
bb1:
  %t15 = load i64, ptr %l16, !tbaa !24
  %t16 = icmp sle i64 %t15, 1152921504606846975
  br i1 %t16, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_e8495525dc2bdb1_7683e0c7bf654c8d)
  unreachable
bb3:
  %t18 = load i64, ptr %l16, !tbaa !24
  %t19 = mul i64 %t18, 8
  %t20 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t19)
  %t21 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t24 = load ptr, ptr %l13, !tbaa !29
  %t25 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t24, i32 0, i32 0
  store { i64, ptr } %t22, ptr %t25, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  %t26 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t26, 0
  store i64 %t28, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t30 = load i64, ptr %l3, !tbaa !24
  %t31 = load i64, ptr %l2, !tbaa !24
  %t34 = icmp sgt i64 %t30, %t31
  br i1 %t34, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_e8495525dc2bdb1_7683e0c7bf654c8d)
  unreachable
bb5:
  %t36 = load i64, ptr %l4, !tbaa !24
  %t38 = icmp sgt i64 %t36, 0
  br i1 %t38, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l25, !tbaa !24
  br label %bb10
bb7:
  %t40 = load i64, ptr %l3, !tbaa !24
  %t41 = load i64, ptr %l2, !tbaa !24
  %t44 = sub i64 %t40, %t41
  %t45 = load i64, ptr %l4, !tbaa !24
  %t48 = add i64 %t44, %t45
  %t50 = sub i64 %t48, 1
  %t51 = load i64, ptr %l4, !tbaa !24
  %t54 = sdiv i64 %t50, %t51
  store i64 %t54, ptr %l28, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb9
bb9:
  %t56 = load i64, ptr %l28, !tbaa !24
  store i64 %t56, ptr %l25, !tbaa !24
  br label %bb10
bb10:
  %t57 = load i64, ptr %l25, !tbaa !24
  store i64 %t57, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb11
bb11:
  %t58 = load i64, ptr %l6, !tbaa !24
  %t59 = load i64, ptr %l5, !tbaa !24
  %t62 = icmp slt i64 %t58, %t59
  %t64 = xor i1 %t62, true
  br i1 %t64, label %bb12, label %bb13
bb12:
  br label %bb23
bb13:
  br label %bb14
bb14:
  %t66 = load i64, ptr %l2, !tbaa !24
  %t67 = load i64, ptr %l6, !tbaa !24
  %t68 = load i64, ptr %l4, !tbaa !24
  %t71 = mul i64 %t67, %t68
  %t74 = add i64 %t66, %t71
  %t76 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t76, ptr %l46, !tbaa !27
  %t79 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = getelementptr ptr, ptr %t80, i64 %t74
  %t82 = load ptr, ptr %t81, !tbaa !39
  store ptr %t82, ptr %l8, !tbaa !29
  br label %bb15
bb15:
  %t84 = load ptr, ptr %l8, !tbaa !29
  %t86 = icmp eq ptr %t84, null
  %t88 = xor i1 %t86, true
  %t90 = xor i1 %t88, true
  br i1 %t90, label %bb16, label %bb17
bb16:
  br label %bb21
bb17:
  br label %bb18
bb18:
  %t92 = load ptr, ptr %l8, !tbaa !29
  %t94 = getelementptr %"std/prelude/map:mapSlot.8d5f4b852d3f9c4d7ccf5e7675d9833d", ptr %t92, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !29
  store ptr %t95, ptr %l9, !tbaa !29
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t98 = load ptr, ptr %l8, !tbaa !29
  %t100 = getelementptr %"std/prelude/map:mapSlot.8d5f4b852d3f9c4d7ccf5e7675d9833d", ptr %t98, i32 0, i32 0
  %t101 = getelementptr %"std/prelude/map:MapEntry.c479befe3d340af6fb5e3e84080d9cfc", ptr %t100, i32 0, i32 0
  %t102 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %t101
  %t105 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cstd_2fpair_3aPair_3cI64_2c_20I64__H25550a5aa964c9352053a58344d5fc74(ptr %v0, ptr %t97, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t102)
  store i64 %t105, ptr %l58
  br label %bb19
bb19:
  %t106 = load i64, ptr %l58, !tbaa !24
  store i64 %t106, ptr %l10, !tbaa !24
  %t107 = load ptr, ptr %l8, !tbaa !29
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t108, i32 0, i32 0
  %t111 = load { i64, ptr }, ptr %t110, !tbaa !27
  store { i64, ptr } %t111, ptr %l61, !tbaa !27
  %t112 = load i64, ptr %l10, !tbaa !24
  %t114 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !27
  %t116 = getelementptr ptr, ptr %t115, i64 %t112
  %t117 = load ptr, ptr %t116, !tbaa !39
  %t120 = getelementptr %"std/prelude/map:mapSlot.8d5f4b852d3f9c4d7ccf5e7675d9833d", ptr %t107, i32 0, i32 1
  store ptr %t117, ptr %t120, !tbaa !29
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t121, i32 0, i32 0
  %t124 = load { i64, ptr }, ptr %t123, !tbaa !27
  store { i64, ptr } %t124, ptr %l65, !tbaa !27
  %t125 = load i64, ptr %l10, !tbaa !24
  %t126 = load ptr, ptr %l8, !tbaa !29
  %t130 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !27
  %t132 = getelementptr ptr, ptr %t131, i64 %t125
  store ptr %t126, ptr %t132, !tbaa !39
  %t133 = load ptr, ptr %l9, !tbaa !29
  store ptr %t133, ptr %l8, !tbaa !29
  br label %bb20
bb20:
  br label %bb15
bb21:
  br label %bb22
bb22:
  %t135 = load i64, ptr %l6, !tbaa !24
  %t137 = add i64 %t135, 1
  store i64 %t137, ptr %l6, !tbaa !24
  br label %bb11
bb23:
  br label %ret
ret:
  ret void
}

@std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cstd_2fpair_3aPair_3cI64_2c_20I64__H65d40e9d5d9c7d43db32c29d0c3a567a = dso_local alias void (ptr, ptr), ptr @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cstd_2fpair_3aPair_3cI64_2c_20I64__H53bbd9f5fe8f1bd11963185242a67f8c
define dso_local i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cstd_2fpair_3aPair_3cI64_2c_20I64__H8d8c97822adaf85517727d8eaf8ab4f5(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1) #0 {
entry:
  %r = tail call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cstd_2fpair_3aPair_3cI64_2c_20I64__H25550a5aa964c9352053a58344d5fc74(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
  ret i64 %r
}

@std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cstd_2fpair_3aPair_3cI64_2c_20I64__H8f2454615ed7d4134bbf6b6b89a13621 = dso_local alias void (ptr, ptr), ptr @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cstd_2fpair_3aPair_3cI64_2c_20I64__H53bbd9f5fe8f1bd11963185242a67f8c
define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cstd_2fpair_3aPair_3cI64_2c_20I64__Ha7ee54d42e4cb7e14b56fc3c6a6b8eb5(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a2, %"compiler/check:fixedInit" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l3 = alloca %"compiler/check:fixedInit"
  %l4 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l15 = alloca { i64, ptr }
  %l18 = alloca %"std/prelude/map:mapSlot.8d5f4b852d3f9c4d7ccf5e7675d9833d"
  %l23 = alloca ptr
  %l26 = alloca %"std/prelude/map:MapEntry.c479befe3d340af6fb5e3e84080d9cfc"
  %l29 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l37 = alloca ptr
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a2, ptr %l2
  store %"compiler/check:fixedInit" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = load ptr, ptr %l4, !tbaa !29
  %t8 = icmp eq ptr %t6, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  store { i64, ptr } %t13, ptr %l10, !tbaa !27
  %t14 = load i64, ptr %l1, !tbaa !24
  store i64 %t14, ptr %l11, !tbaa !24
  %t15 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l2
  %t16 = load %"compiler/check:fixedInit", ptr %l3
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t17, i32 0, i32 0
  %t20 = load { i64, ptr }, ptr %t19, !tbaa !27
  store { i64, ptr } %t20, ptr %l15, !tbaa !27
  %t21 = load i64, ptr %l1, !tbaa !24
  %t23 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = getelementptr ptr, ptr %t24, i64 %t21
  %t26 = load ptr, ptr %t25, !tbaa !39
  %t30 = call %"std/prelude/map:mapSlot.8d5f4b852d3f9c4d7ccf5e7675d9833d" @std_2fprelude_2fmap_3amapSlot_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20compiler_2fcheck_3afixedInit_3e_2ector(ptr %v1, ptr %v0, ptr %v0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t15, %"compiler/check:fixedInit" %t16, ptr %t26)
  store %"std/prelude/map:mapSlot.8d5f4b852d3f9c4d7ccf5e7675d9833d" %t30, ptr %l18
  br label %bb3
bb2:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load ptr, ptr %l4, !tbaa !29
  %t34 = getelementptr %"std/prelude/map:mapSlot.8d5f4b852d3f9c4d7ccf5e7675d9833d", ptr %t32, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t38 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t31, i32 0, i32 2
  store ptr %t35, ptr %t38, !tbaa !29
  %t39 = load ptr, ptr %l4, !tbaa !29
  store ptr %t39, ptr %l23, !tbaa !29
  %t40 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l2
  %t41 = load %"compiler/check:fixedInit", ptr %l3
  %t44 = call %"std/prelude/map:MapEntry.c479befe3d340af6fb5e3e84080d9cfc" @std_2fprelude_2fmap_3aMapEntry_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20compiler_2fcheck_3afixedInit_3e_2ector(ptr %v1, ptr %v0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t40, %"compiler/check:fixedInit" %t41)
  store %"std/prelude/map:MapEntry.c479befe3d340af6fb5e3e84080d9cfc" %t44, ptr %l26
  br label %bb4
bb3:
  %t45 = load %"std/prelude/map:mapSlot.8d5f4b852d3f9c4d7ccf5e7675d9833d", ptr %l18
  %t46 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store %"std/prelude/map:mapSlot.8d5f4b852d3f9c4d7ccf5e7675d9833d" %t45, ptr %t46
  %t48 = load i64, ptr %l11, !tbaa !24
  %t49 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !27
  %t51 = getelementptr ptr, ptr %t50, i64 %t48
  store ptr %t46, ptr %t51, !tbaa !39
  br label %bb5
bb4:
  %t52 = load %"std/prelude/map:MapEntry.c479befe3d340af6fb5e3e84080d9cfc", ptr %l26
  %t53 = load ptr, ptr %l23, !tbaa !29
  %t54 = getelementptr %"std/prelude/map:mapSlot.8d5f4b852d3f9c4d7ccf5e7675d9833d", ptr %t53, i32 0, i32 0
  store %"std/prelude/map:MapEntry.c479befe3d340af6fb5e3e84080d9cfc" %t52, ptr %t54
  %t55 = load ptr, ptr %l4, !tbaa !29
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t56, i32 0, i32 0
  %t59 = load { i64, ptr }, ptr %t58, !tbaa !27
  store { i64, ptr } %t59, ptr %l29, !tbaa !27
  %t60 = load i64, ptr %l1, !tbaa !24
  %t62 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !27
  %t64 = getelementptr ptr, ptr %t63, i64 %t60
  %t65 = load ptr, ptr %t64, !tbaa !39
  %t68 = getelementptr %"std/prelude/map:mapSlot.8d5f4b852d3f9c4d7ccf5e7675d9833d", ptr %t55, i32 0, i32 1
  store ptr %t65, ptr %t68, !tbaa !29
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t69, i32 0, i32 0
  %t72 = load { i64, ptr }, ptr %t71, !tbaa !27
  store { i64, ptr } %t72, ptr %l33, !tbaa !27
  %t73 = load i64, ptr %l1, !tbaa !24
  %t74 = load ptr, ptr %l4, !tbaa !29
  %t78 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !27
  %t80 = getelementptr ptr, ptr %t79, i64 %t73
  store ptr %t74, ptr %t80, !tbaa !39
  br label %bb5
bb5:
  %t81 = load ptr, ptr %l0, !tbaa !29
  store ptr %t81, ptr %l37, !tbaa !29
  %t82 = load ptr, ptr %l37, !tbaa !29
  %t83 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t82, i32 0, i32 1
  %t84 = load i64, ptr %t83, !tbaa !24
  %t86 = add i64 %t84, 1
  %t88 = load ptr, ptr %l37, !tbaa !29
  %t89 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t88, i32 0, i32 1
  store i64 %t86, ptr %t89, !tbaa !24
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t90, i32 0, i32 1
  %t93 = load i64, ptr %t92, !tbaa !24
  %t95 = mul i64 %t93, 4
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t96, i32 0, i32 0
  %t99 = load { i64, ptr }, ptr %t98, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t99, 0
  %t103 = mul i64 %t101, 3
  %t106 = icmp sgt i64 %t95, %t103
  br i1 %t106, label %bb6, label %bb7
bb6:
  %t108 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cstd_2fpair_3aPair_3cI64_2c_20I64__H6587130e61ade78d21ab2f88c2eaebaa(ptr %v0, ptr %t108)
  br label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb9
bb9:
  br label %ret
ret:
  ret void
}

define dso_local i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cstd_2fpair_3aPair_3cI64_2c_20I64__Hab8db8039cd91169374f703fa3a09f09(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1) #0 {
entry:
  %r = tail call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cstd_2fpair_3aPair_3cI64_2c_20I64__H25550a5aa964c9352053a58344d5fc74(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
  ret i64 %r
}

define dso_local i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cstd_2fpair_3aPair_3cI64_2c_20I64__Haf6b8a5a0c941d0f0de2716abddd6d0f(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1) #0 {
entry:
  %r = tail call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cstd_2fpair_3aPair_3cI64_2c_20I64__H25550a5aa964c9352053a58344d5fc74(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
  ret i64 %r
}

define dso_local i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cstd_2fpair_3aPair_3cI64_2c_20I64__Hc3aec1555289c6ef7f7cfe5033df2295(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1) #0 {
entry:
  %r = tail call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cstd_2fpair_3aPair_3cI64_2c_20I64__H25550a5aa964c9352053a58344d5fc74(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
  ret i64 %r
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cstd_2fpair_3aPair_3cI64_2c_20I64__He0a7cf640a184dcf316fbaf0b026b38b(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a2, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l3 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l4 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l15 = alloca { i64, ptr }
  %l18 = alloca %"std/prelude/map:mapSlot.a04f5d5eeace3a348c0931984fa7d629"
  %l23 = alloca ptr
  %l26 = alloca %"std/prelude/map:MapEntry.ecf182cf123eba82aed5d6288e5f1385"
  %l29 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l37 = alloca ptr
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a2, ptr %l2
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = load ptr, ptr %l4, !tbaa !29
  %t8 = icmp eq ptr %t6, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  store { i64, ptr } %t13, ptr %l10, !tbaa !27
  %t14 = load i64, ptr %l1, !tbaa !24
  store i64 %t14, ptr %l11, !tbaa !24
  %t15 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l2
  %t16 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l3
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t17, i32 0, i32 0
  %t20 = load { i64, ptr }, ptr %t19, !tbaa !27
  store { i64, ptr } %t20, ptr %l15, !tbaa !27
  %t21 = load i64, ptr %l1, !tbaa !24
  %t23 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = getelementptr ptr, ptr %t24, i64 %t21
  %t26 = load ptr, ptr %t25, !tbaa !39
  %t30 = call %"std/prelude/map:mapSlot.a04f5d5eeace3a348c0931984fa7d629" @std_2fprelude_2fmap_3amapSlot_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20std_2fprelude_2_Hb83c0b69e22e3a58293f016f45f101c9(ptr %v1, ptr %v0, ptr %v0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t15, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t16, ptr %t26)
  store %"std/prelude/map:mapSlot.a04f5d5eeace3a348c0931984fa7d629" %t30, ptr %l18
  br label %bb3
bb2:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load ptr, ptr %l4, !tbaa !29
  %t34 = getelementptr %"std/prelude/map:mapSlot.a04f5d5eeace3a348c0931984fa7d629", ptr %t32, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t38 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t31, i32 0, i32 2
  store ptr %t35, ptr %t38, !tbaa !29
  %t39 = load ptr, ptr %l4, !tbaa !29
  store ptr %t39, ptr %l23, !tbaa !29
  %t40 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l2
  %t41 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l3
  %t44 = call %"std/prelude/map:MapEntry.ecf182cf123eba82aed5d6288e5f1385" @std_2fprelude_2fmap_3aMapEntry_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20std_2fprelude__H972fbc2a6787a46672b861de27ed2680(ptr %v1, ptr %v0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t40, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t41)
  store %"std/prelude/map:MapEntry.ecf182cf123eba82aed5d6288e5f1385" %t44, ptr %l26
  br label %bb4
bb3:
  %t45 = load %"std/prelude/map:mapSlot.a04f5d5eeace3a348c0931984fa7d629", ptr %l18
  %t46 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"std/prelude/map:mapSlot.a04f5d5eeace3a348c0931984fa7d629" %t45, ptr %t46
  %t48 = load i64, ptr %l11, !tbaa !24
  %t49 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !27
  %t51 = getelementptr ptr, ptr %t50, i64 %t48
  store ptr %t46, ptr %t51, !tbaa !39
  br label %bb5
bb4:
  %t52 = load %"std/prelude/map:MapEntry.ecf182cf123eba82aed5d6288e5f1385", ptr %l26
  %t53 = load ptr, ptr %l23, !tbaa !29
  %t54 = getelementptr %"std/prelude/map:mapSlot.a04f5d5eeace3a348c0931984fa7d629", ptr %t53, i32 0, i32 0
  store %"std/prelude/map:MapEntry.ecf182cf123eba82aed5d6288e5f1385" %t52, ptr %t54
  %t55 = load ptr, ptr %l4, !tbaa !29
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t56, i32 0, i32 0
  %t59 = load { i64, ptr }, ptr %t58, !tbaa !27
  store { i64, ptr } %t59, ptr %l29, !tbaa !27
  %t60 = load i64, ptr %l1, !tbaa !24
  %t62 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !27
  %t64 = getelementptr ptr, ptr %t63, i64 %t60
  %t65 = load ptr, ptr %t64, !tbaa !39
  %t68 = getelementptr %"std/prelude/map:mapSlot.a04f5d5eeace3a348c0931984fa7d629", ptr %t55, i32 0, i32 1
  store ptr %t65, ptr %t68, !tbaa !29
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t69, i32 0, i32 0
  %t72 = load { i64, ptr }, ptr %t71, !tbaa !27
  store { i64, ptr } %t72, ptr %l33, !tbaa !27
  %t73 = load i64, ptr %l1, !tbaa !24
  %t74 = load ptr, ptr %l4, !tbaa !29
  %t78 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !27
  %t80 = getelementptr ptr, ptr %t79, i64 %t73
  store ptr %t74, ptr %t80, !tbaa !39
  br label %bb5
bb5:
  %t81 = load ptr, ptr %l0, !tbaa !29
  store ptr %t81, ptr %l37, !tbaa !29
  %t82 = load ptr, ptr %l37, !tbaa !29
  %t83 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t82, i32 0, i32 1
  %t84 = load i64, ptr %t83, !tbaa !24
  %t86 = add i64 %t84, 1
  %t88 = load ptr, ptr %l37, !tbaa !29
  %t89 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t88, i32 0, i32 1
  store i64 %t86, ptr %t89, !tbaa !24
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t90, i32 0, i32 1
  %t93 = load i64, ptr %t92, !tbaa !24
  %t95 = mul i64 %t93, 4
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50", ptr %t96, i32 0, i32 0
  %t99 = load { i64, ptr }, ptr %t98, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t99, 0
  %t103 = mul i64 %t101, 3
  %t106 = icmp sgt i64 %t95, %t103
  br i1 %t106, label %bb6, label %bb7
bb6:
  %t108 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cstd_2fpair_3aPair_3cI64_2c_20I64__H10a253586b55b0b9df1fc9ef69d3e984(ptr %v0, ptr %t108)
  br label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb9
bb9:
  br label %ret
ret:
  ret void
}

define dso_local %"std/prelude/map:MapEntry.1eb2466213689e002f25e81e83536e78" @std_2fprelude_2fmap_3aMapEntry_3cI64_2c_20compiler_2fcheck_3arawTable_26_3e_2ector(ptr %v0, ptr %v1, i64 %a0, ptr %a1) #0 {
entry:
  %r = tail call %"std/prelude/map:MapEntry.1eb2466213689e002f25e81e83536e78" @std_2fprelude_2fmap_3aMapEntry_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_2ector(ptr %v0, ptr %v1, i64 %a0, ptr %a1)
  ret %"std/prelude/map:MapEntry.1eb2466213689e002f25e81e83536e78" %r
}

define dso_local %"std/prelude/map:MapEntry.c479befe3d340af6fb5e3e84080d9cfc" @std_2fprelude_2fmap_3aMapEntry_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20compiler_2fcheck_3afixedInit_3e_2ector(ptr %v0, ptr %v1, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a0, %"compiler/check:fixedInit" %a1) #0 {
entry:
  %rv = alloca %"std/prelude/map:MapEntry.c479befe3d340af6fb5e3e84080d9cfc"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"std/prelude/map:MapEntry.c479befe3d340af6fb5e3e84080d9cfc" undef, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a0, 0
  %t8 = insertvalue %"std/prelude/map:MapEntry.c479befe3d340af6fb5e3e84080d9cfc" %t6, %"compiler/check:fixedInit" %a1, 1
  store %"std/prelude/map:MapEntry.c479befe3d340af6fb5e3e84080d9cfc" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:MapEntry.c479befe3d340af6fb5e3e84080d9cfc", ptr %rv
  ret %"std/prelude/map:MapEntry.c479befe3d340af6fb5e3e84080d9cfc" %rr
}

define dso_local %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fcheck_3arawTable_26_3e_2ector(ptr %v0) #0 {
entry:
  %r = tail call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20compiler_2fsource_3aNameId_3e_2ector(ptr %v0)
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %r
}

define dso_local %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20compiler_2fcheck_3afixedInit_3e_2ector(ptr %v0) #0 {
entry:
  %r = tail call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20compiler_2fsource_3aNameId_3e_2ector(ptr %v0)
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %r
}

define dso_local %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20compiler_2ftypes_3aListId_3e_2ector(ptr %v0) #0 {
entry:
  %r = tail call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20compiler_2fsource_3aNameId_3e_2ector(ptr %v0)
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %r
}

define dso_local %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20compiler_2ftypes_3aTypeId_3e_2ector(ptr %v0) #0 {
entry:
  %r = tail call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20compiler_2fsource_3aNameId_3e_2ector(ptr %v0)
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %r
}

define dso_local %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20std_2fprelude_2fvec_H2e44743f10bee47c9f5386f757b87bf0(ptr %v0) #0 {
entry:
  %r = tail call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20compiler_2fsource_3aNameId_3e_2ector(ptr %v0)
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %r
}

define dso_local %"std/prelude/map:mapSlot.13b431b0462eb7c9b33f2a6ba793b9e3" @std_2fprelude_2fmap_3amapSlot_3cI64_2c_20compiler_2fcheck_3arawTable_26_3e_2ector(ptr %v0, ptr %v1, ptr %v2, i64 %a0, ptr %a1, ptr %a2) #0 {
entry:
  %r = tail call %"std/prelude/map:mapSlot.13b431b0462eb7c9b33f2a6ba793b9e3" @std_2fprelude_2fmap_3amapSlot_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_2ector(ptr %v0, ptr %v1, ptr %v2, i64 %a0, ptr %a1, ptr %a2)
  ret %"std/prelude/map:mapSlot.13b431b0462eb7c9b33f2a6ba793b9e3" %r
}

define dso_local %"std/prelude/map:mapSlot.8d5f4b852d3f9c4d7ccf5e7675d9833d" @std_2fprelude_2fmap_3amapSlot_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20compiler_2fcheck_3afixedInit_3e_2ector(ptr %v0, ptr %v1, ptr %v2, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a0, %"compiler/check:fixedInit" %a1, ptr %a2) #0 {
entry:
  %l7 = alloca %"std/prelude/map:MapEntry.c479befe3d340af6fb5e3e84080d9cfc"
  %rv = alloca %"std/prelude/map:mapSlot.8d5f4b852d3f9c4d7ccf5e7675d9833d"
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call %"std/prelude/map:MapEntry.c479befe3d340af6fb5e3e84080d9cfc" @std_2fprelude_2fmap_3aMapEntry_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20compiler_2fcheck_3afixedInit_3e_2ector(ptr %v0, ptr %v2, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a0, %"compiler/check:fixedInit" %a1)
  store %"std/prelude/map:MapEntry.c479befe3d340af6fb5e3e84080d9cfc" %t5, ptr %l7
  br label %bb1
bb1:
  %t6 = load %"std/prelude/map:MapEntry.c479befe3d340af6fb5e3e84080d9cfc", ptr %l7
  %t10 = insertvalue %"std/prelude/map:mapSlot.8d5f4b852d3f9c4d7ccf5e7675d9833d" undef, %"std/prelude/map:MapEntry.c479befe3d340af6fb5e3e84080d9cfc" %t6, 0
  %t12 = insertvalue %"std/prelude/map:mapSlot.8d5f4b852d3f9c4d7ccf5e7675d9833d" %t10, ptr %a2, 1
  store %"std/prelude/map:mapSlot.8d5f4b852d3f9c4d7ccf5e7675d9833d" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:mapSlot.8d5f4b852d3f9c4d7ccf5e7675d9833d", ptr %rv
  ret %"std/prelude/map:mapSlot.8d5f4b852d3f9c4d7ccf5e7675d9833d" %rr
}

define dso_local %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50" @std_2fprelude_2fmap_3amapState_3cI64_2c_20compiler_2fdiag_3aWhere_3e_2ector(ptr %v0) #0 {
entry:
  %r = tail call %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50" @std_2fprelude_2fmap_3amapState_3cstd_2fprelude_2ftext_3aString_26_2c_20compiler_2fsource_3aNameId_3e_2ector(ptr %v0)
  ret %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50" %r
}

define dso_local %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50" @std_2fprelude_2fmap_3amapState_3cI64_2c_20compiler_2ftyped_3aContractInfo_3e_2ector(ptr %v0) #0 {
entry:
  %r = tail call %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50" @std_2fprelude_2fmap_3amapState_3cstd_2fprelude_2ftext_3aString_26_2c_20compiler_2fsource_3aNameId_3e_2ector(ptr %v0)
  ret %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50" %r
}

define dso_local %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50" @std_2fprelude_2fmap_3amapState_3cI64_2c_20compiler_2ftypes_3aListId_3e_2ector(ptr %v0) #0 {
entry:
  %r = tail call %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50" @std_2fprelude_2fmap_3amapState_3cstd_2fprelude_2ftext_3aString_26_2c_20compiler_2fsource_3aNameId_3e_2ector(ptr %v0)
  ret %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50" %r
}

define dso_local %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50" @std_2fprelude_2fmap_3amapState_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20compiler_2fcheck_3aroOrigin_3e_2ector(ptr %v0) #0 {
entry:
  %r = tail call %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50" @std_2fprelude_2fmap_3amapState_3cstd_2fprelude_2ftext_3aString_26_2c_20compiler_2fsource_3aNameId_3e_2ector(ptr %v0)
  ret %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50" %r
}

define dso_local %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50" @std_2fprelude_2fmap_3amapState_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20compiler_2fsource_3aNameId_3e_2ector(ptr %v0) #0 {
entry:
  %r = tail call %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50" @std_2fprelude_2fmap_3amapState_3cstd_2fprelude_2ftext_3aString_26_2c_20compiler_2fsource_3aNameId_3e_2ector(ptr %v0)
  ret %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50" %r
}

define dso_local { i32, i128 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseAs_3cU128_3e(ptr %v0, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i1
  %l3 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i128
  %l7 = alloca i128
  %l8 = alloca i128
  %l9 = alloca i128
  %l10 = alloca i128
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i8
  %l16 = alloca i64
  %l17 = alloca i128
  %l22 = alloca { i64, ptr }
  %l26 = alloca i1
  %l27 = alloca { i64, ptr }
  %l30 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l34 = alloca i64
  %l35 = alloca i64
  %l40 = alloca { i64, ptr }
  %l43 = alloca i64
  %l44 = alloca i64
  %l50 = alloca i1
  %l54 = alloca i1
  %l56 = alloca i1
  %l59 = alloca i64
  %l62 = alloca i64
  %l63 = alloca i32
  %l68 = alloca i1
  %l78 = alloca i64
  %l84 = alloca i128
  %l100 = alloca { i64, ptr }
  %l105 = alloca i1
  %l111 = alloca i1
  %l112 = alloca { i64, ptr }
  %l117 = alloca i1
  %l125 = alloca i64
  %l136 = alloca i1
  %l140 = alloca i1
  %l154 = alloca i1
  %l158 = alloca i1
  %rv = alloca { i32, i128 }
  store { i64, ptr } %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t8 = insertvalue { i32, i128 } zeroinitializer, i32 65536, 0
  store { i32, i128 } %t8, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t9 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t9, ptr %l22, !tbaa !27
  %t10 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !27
  %t12 = getelementptr i8, ptr %t11, i64 0
  %t13 = load i8, ptr %t12, !tbaa !32
  %t15 = icmp eq i8 %t13, 45
  store i1 %t15, ptr %l2, !tbaa !21
  %t17 = load i1, ptr %l2, !tbaa !21
  br i1 %t17, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb6
bb5:
  %t19 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t19, ptr %l27, !tbaa !27
  %t20 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr i8, ptr %t21, i64 0
  %t23 = load i8, ptr %t22, !tbaa !32
  %t25 = icmp eq i8 %t23, 43
  store i1 %t25, ptr %l26, !tbaa !21
  br label %bb6
bb6:
  %t27 = load i1, ptr %l26, !tbaa !21
  br i1 %t27, label %bb7, label %bb8
bb7:
  %t28 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t28, ptr %l31, !tbaa !27
  %t29 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t29, 0
  store i64 %t32, ptr %l34, !tbaa !24
  %t33 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t33, 0
  store i64 %t34, ptr %l35, !tbaa !24
  %t35 = icmp sge i64 1, 0
  br i1 %t35, label %bb9, label %bb10
bb8:
  %t37 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t37, ptr %l40, !tbaa !27
  %t38 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t38, 0
  store i64 %t41, ptr %l43, !tbaa !24
  %t42 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t42, 0
  store i64 %t43, ptr %l44, !tbaa !24
  %t44 = icmp sge i64 0, 0
  br i1 %t44, label %bb15, label %bb16
bb9:
  %t46 = load i64, ptr %l34, !tbaa !24
  %t47 = icmp sle i64 1, %t46
  br i1 %t47, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_588409ee20632e7_5b202286b88aa413)
  unreachable
bb11:
  %t49 = load i64, ptr %l34, !tbaa !24
  %t50 = load i64, ptr %l35, !tbaa !24
  %t51 = icmp sle i64 %t49, %t50
  br i1 %t51, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @olang_loc_588409ee20632e7_5b202286b88aa413)
  unreachable
bb13:
  %t53 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !27
  %t55 = load i64, ptr %l34, !tbaa !24
  %t56 = getelementptr i8, ptr %t54, i64 1
  %t57 = sub i64 %t55, 1
  %t58 = insertvalue { i64, ptr } undef, i64 %t57, 0
  %t59 = insertvalue { i64, ptr } %t58, ptr %t56, 1
  store { i64, ptr } %t59, ptr %l30, !tbaa !27
  br label %bb21
bb14:
  call void @__olang_check_failed(ptr @olang_loc_588409ee20632e7_5b202286b88aa413)
  unreachable
bb15:
  %t61 = load i64, ptr %l43, !tbaa !24
  %t62 = icmp sle i64 0, %t61
  br i1 %t62, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_588409ee20632e7_5b202286b88aa413)
  unreachable
bb17:
  %t64 = load i64, ptr %l43, !tbaa !24
  %t65 = load i64, ptr %l44, !tbaa !24
  %t66 = icmp sle i64 %t64, %t65
  br i1 %t66, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_588409ee20632e7_5b202286b88aa413)
  unreachable
bb19:
  %t68 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !27
  %t70 = load i64, ptr %l43, !tbaa !24
  %t71 = getelementptr i8, ptr %t69, i64 0
  %t72 = sub i64 %t70, 0
  %t73 = insertvalue { i64, ptr } undef, i64 %t72, 0
  %t74 = insertvalue { i64, ptr } %t73, ptr %t71, 1
  store { i64, ptr } %t74, ptr %l30, !tbaa !27
  br label %bb21
bb20:
  call void @__olang_check_failed(ptr @olang_loc_588409ee20632e7_5b202286b88aa413)
  unreachable
bb21:
  %t76 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t76, ptr %l3, !tbaa !27
  %t77 = icmp sle i64 16, 8
  br i1 %t77, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l50, !tbaa !21
  br label %bb28
bb23:
  %t79 = load i64, ptr %l1, !tbaa !24
  %t82 = icmp eq i64 %t79, 0
  br i1 %t82, label %bb24, label %bb25
bb24:
  %t84 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t86 = call i1 @std_2fprelude_2ftext_2eisPrefixed(ptr %v0, { i64, ptr } %t84)
  store i1 %t86, ptr %l56
  br label %bb26
bb25:
  store i1 false, ptr %l54, !tbaa !21
  br label %bb27
bb26:
  %t87 = load i1, ptr %l56, !tbaa !21
  store i1 %t87, ptr %l54, !tbaa !21
  br label %bb27
bb27:
  %t88 = load i1, ptr %l54, !tbaa !21
  store i1 %t88, ptr %l50, !tbaa !21
  br label %bb28
bb28:
  %t89 = load i1, ptr %l50, !tbaa !21
  br i1 %t89, label %bb29, label %bb30
bb29:
  %t90 = load i1, ptr %l2, !tbaa !21
  br i1 %t90, label %bb31, label %bb32
bb30:
  br label %bb37
bb31:
  %t93 = insertvalue { i32, i128 } zeroinitializer, i32 65537, 0
  store { i32, i128 } %t93, ptr %rv
  br label %ret
bb32:
  br label %bb33
bb33:
  %t94 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t95 = load i64, ptr %l1, !tbaa !24
  %t98 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseUint(ptr %v0, { i64, ptr } %t94, i64 %t95)
  %t99 = extractvalue { i32, i64 } %t98, 1
  %t100 = extractvalue { i32, i64 } %t98, 0
  store i32 %t100, ptr %l63
  %t101 = icmp ne i32 %t100, 0
  br i1 %t101, label %bb35, label %ok.102
ok.102:
  store i64 %t99, ptr %l62
  br label %bb34
bb34:
  %t103 = load i64, ptr %l62, !tbaa !65
  store i64 %t103, ptr %l59, !tbaa !65
  br label %bb36
bb35:
  %t104 = load i32, ptr %l63, !tbaa !23
  %t105 = lshr i32 %t104, 16
  %t106 = and i32 %t104, 65535
  %t107 = icmp eq i32 %t105, 1
  %t108 = select i1 %t107, i32 1, i32 0
  %t109 = icmp eq i32 %t104, 0
  %t110 = shl i32 %t108, 16
  %t111 = or i32 %t110, %t106
  %t112 = select i1 %t109, i32 0, i32 %t111
  %t114 = insertvalue { i32, i128 } zeroinitializer, i32 %t112, 0
  store { i32, i128 } %t114, ptr %rv
  br label %ret
bb36:
  %t115 = load i64, ptr %l59, !tbaa !65
  %t118 = zext i64 %t115 to i128
  %t120 = insertvalue { i32, i128 } zeroinitializer, i128 %t118, 1
  store { i32, i128 } %t120, ptr %rv
  br label %ret
bb37:
  %t121 = load i1, ptr %l2, !tbaa !21
  br i1 %t121, label %bb38, label %bb39
bb38:
  %t123 = icmp eq i128 0, 0
  store i1 %t123, ptr %l68, !tbaa !21
  br label %bb40
bb39:
  store i1 false, ptr %l68, !tbaa !21
  br label %bb40
bb40:
  %t125 = load i1, ptr %l68, !tbaa !21
  br i1 %t125, label %bb41, label %bb42
bb41:
  %t127 = insertvalue { i32, i128 } zeroinitializer, i32 65537, 0
  store { i32, i128 } %t127, ptr %rv
  br label %ret
bb42:
  br label %bb43
bb43:
  %t128 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t130 = extractvalue { i64, ptr } %t128, 0
  %t132 = icmp eq i64 %t130, 0
  br i1 %t132, label %bb44, label %bb45
bb44:
  %t135 = insertvalue { i32, i128 } zeroinitializer, i32 65537, 0
  store { i32, i128 } %t135, ptr %rv
  br label %ret
bb45:
  br label %bb46
bb46:
  %t136 = load i64, ptr %l1, !tbaa !24
  %t139 = icmp eq i64 %t136, 0
  br i1 %t139, label %bb47, label %bb48
bb47:
  store i64 10, ptr %l78, !tbaa !24
  br label %bb49
bb48:
  %t141 = load i64, ptr %l1, !tbaa !24
  store i64 %t141, ptr %l78, !tbaa !24
  br label %bb49
bb49:
  %t144 = load i64, ptr %l78, !tbaa !24
  store i64 %t144, ptr %l5, !tbaa !24
  %t145 = load i64, ptr %l5, !tbaa !24
  %t147 = sext i64 %t145 to i128
  store i128 %t147, ptr %l6
  %t149 = load i1, ptr %l2, !tbaa !21
  br i1 %t149, label %bb50, label %bb51
bb50:
  store i128 0, ptr %l84
  br label %bb52
bb51:
  %t151 = xor i128 0, -1
  store i128 %t151, ptr %l84
  br label %bb52
bb52:
  %t153 = load i128, ptr %l84
  store i128 %t153, ptr %l7
  %t154 = load i128, ptr %l7
  %t155 = load i128, ptr %l6
  %t158 = udiv i128 %t154, %t155
  store i128 %t158, ptr %l8
  %t160 = load i128, ptr %l7
  %t161 = load i128, ptr %l6
  %t164 = urem i128 %t160, %t161
  store i128 %t164, ptr %l9
  store i128 0, ptr %l10
  %t166 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t166, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t168 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t170 = extractvalue { i64, ptr } %t168, 0
  store i64 %t170, ptr %l13, !tbaa !24
  br label %bb53
bb53:
  %t172 = load i64, ptr %l12, !tbaa !24
  %t173 = load i64, ptr %l13, !tbaa !24
  %t176 = icmp slt i64 %t172, %t173
  %t178 = xor i1 %t176, true
  br i1 %t178, label %bb54, label %bb55
bb54:
  br label %bb98
bb55:
  br label %bb56
bb56:
  %t180 = load i64, ptr %l12, !tbaa !24
  store i64 %t180, ptr %l14, !tbaa !24
  %t182 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t182, ptr %l100, !tbaa !27
  %t183 = load i64, ptr %l12, !tbaa !24
  %t185 = getelementptr { i64, ptr }, ptr %l100, i32 0, i32 1
  %t186 = load ptr, ptr %t185, !tbaa !27
  %t187 = getelementptr i8, ptr %t186, i64 %t183
  %t188 = load i8, ptr %t187, !tbaa !32
  store i8 %t188, ptr %l15, !tbaa !22
  %t190 = load i8, ptr %l15, !tbaa !22
  %t192 = icmp eq i8 %t190, 95
  br i1 %t192, label %bb57, label %bb58
bb57:
  %t194 = load i64, ptr %l1, !tbaa !24
  %t197 = icmp eq i64 %t194, 0
  store i1 %t197, ptr %l105, !tbaa !21
  br label %bb59
bb58:
  store i1 false, ptr %l105, !tbaa !21
  br label %bb59
bb59:
  %t199 = load i1, ptr %l105, !tbaa !21
  br i1 %t199, label %bb60, label %bb61
bb60:
  %t200 = load i64, ptr %l14, !tbaa !24
  %t202 = icmp eq i64 %t200, 0
  br i1 %t202, label %bb62, label %bb63
bb61:
  br label %bb71
bb62:
  store i1 true, ptr %l111, !tbaa !21
  br label %bb64
bb63:
  %t204 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t204, ptr %l112, !tbaa !27
  %t205 = load i64, ptr %l14, !tbaa !24
  %t207 = sub i64 %t205, 1
  %t209 = getelementptr { i64, ptr }, ptr %l112, i32 0, i32 1
  %t210 = load ptr, ptr %t209, !tbaa !27
  %t211 = getelementptr i8, ptr %t210, i64 %t207
  %t212 = load i8, ptr %t211, !tbaa !32
  %t214 = icmp eq i8 %t212, 95
  store i1 %t214, ptr %l111, !tbaa !21
  br label %bb64
bb64:
  %t216 = load i1, ptr %l111, !tbaa !21
  br i1 %t216, label %bb65, label %bb66
bb65:
  store i1 true, ptr %l117, !tbaa !21
  br label %bb67
bb66:
  %t217 = load i64, ptr %l14, !tbaa !24
  %t219 = add i64 %t217, 1
  %t220 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t222 = extractvalue { i64, ptr } %t220, 0
  %t225 = icmp eq i64 %t219, %t222
  store i1 %t225, ptr %l117, !tbaa !21
  br label %bb67
bb67:
  %t227 = load i1, ptr %l117, !tbaa !21
  br i1 %t227, label %bb68, label %bb69
bb68:
  %t229 = insertvalue { i32, i128 } zeroinitializer, i32 65537, 0
  store { i32, i128 } %t229, ptr %rv
  br label %ret
bb69:
  br label %bb70
bb70:
  br label %bb97
bb71:
  %t230 = load i8, ptr %l15, !tbaa !22
  %t232 = call i64 @std_2fprelude_2ftext_2edigitWorth(i8 %t230)
  store i64 %t232, ptr %l125
  br label %bb72
bb72:
  %t233 = load i64, ptr %l125, !tbaa !24
  store i64 %t233, ptr %l16, !tbaa !24
  %t234 = load i64, ptr %l16, !tbaa !24
  %t235 = load i64, ptr %l5, !tbaa !24
  %t238 = icmp sge i64 %t234, %t235
  br i1 %t238, label %bb73, label %bb74
bb73:
  %t241 = insertvalue { i32, i128 } zeroinitializer, i32 65537, 0
  store { i32, i128 } %t241, ptr %rv
  br label %ret
bb74:
  br label %bb75
bb75:
  %t242 = load i64, ptr %l16, !tbaa !24
  %t244 = sext i64 %t242 to i128
  store i128 %t244, ptr %l17
  %t246 = load i1, ptr %l2, !tbaa !21
  br i1 %t246, label %bb76, label %bb77
bb76:
  %t248 = load i128, ptr %l10
  %t249 = load i128, ptr %l8
  %t252 = icmp ult i128 %t248, %t249
  br i1 %t252, label %bb78, label %bb79
bb77:
  %t254 = load i128, ptr %l10
  %t255 = load i128, ptr %l8
  %t258 = icmp ugt i128 %t254, %t255
  br i1 %t258, label %bb87, label %bb88
bb78:
  store i1 true, ptr %l136, !tbaa !21
  br label %bb83
bb79:
  %t260 = load i128, ptr %l10
  %t261 = load i128, ptr %l8
  %t264 = icmp eq i128 %t260, %t261
  br i1 %t264, label %bb80, label %bb81
bb80:
  %t266 = load i128, ptr %l17
  %t268 = sub i128 0, %t266
  %t269 = load i128, ptr %l9
  %t272 = icmp ult i128 %t268, %t269
  store i1 %t272, ptr %l140, !tbaa !21
  br label %bb82
bb81:
  store i1 false, ptr %l140, !tbaa !21
  br label %bb82
bb82:
  %t274 = load i1, ptr %l140, !tbaa !21
  store i1 %t274, ptr %l136, !tbaa !21
  br label %bb83
bb83:
  %t275 = load i1, ptr %l136, !tbaa !21
  br i1 %t275, label %bb84, label %bb85
bb84:
  %t277 = insertvalue { i32, i128 } zeroinitializer, i32 65538, 0
  store { i32, i128 } %t277, ptr %rv
  br label %ret
bb85:
  br label %bb86
bb86:
  %t278 = load i128, ptr %l10
  %t279 = load i128, ptr %l6
  %t282 = mul i128 %t278, %t279
  %t283 = load i128, ptr %l17
  %t286 = sub i128 %t282, %t283
  store i128 %t286, ptr %l10
  br label %bb96
bb87:
  store i1 true, ptr %l154, !tbaa !21
  br label %bb92
bb88:
  %t288 = load i128, ptr %l10
  %t289 = load i128, ptr %l8
  %t292 = icmp eq i128 %t288, %t289
  br i1 %t292, label %bb89, label %bb90
bb89:
  %t294 = load i128, ptr %l17
  %t295 = load i128, ptr %l9
  %t298 = icmp ugt i128 %t294, %t295
  store i1 %t298, ptr %l158, !tbaa !21
  br label %bb91
bb90:
  store i1 false, ptr %l158, !tbaa !21
  br label %bb91
bb91:
  %t300 = load i1, ptr %l158, !tbaa !21
  store i1 %t300, ptr %l154, !tbaa !21
  br label %bb92
bb92:
  %t301 = load i1, ptr %l154, !tbaa !21
  br i1 %t301, label %bb93, label %bb94
bb93:
  %t303 = insertvalue { i32, i128 } zeroinitializer, i32 65538, 0
  store { i32, i128 } %t303, ptr %rv
  br label %ret
bb94:
  br label %bb95
bb95:
  %t304 = load i128, ptr %l10
  %t305 = load i128, ptr %l6
  %t308 = mul i128 %t304, %t305
  %t309 = load i128, ptr %l17
  %t312 = add i128 %t308, %t309
  store i128 %t312, ptr %l10
  br label %bb96
bb96:
  br label %bb97
bb97:
  %t314 = load i64, ptr %l12, !tbaa !24
  %t316 = add i64 %t314, 1
  store i64 %t316, ptr %l12, !tbaa !24
  br label %bb53
bb98:
  %t318 = load i128, ptr %l10
  %t320 = insertvalue { i32, i128 } zeroinitializer, i128 %t318, 1
  store { i32, i128 } %t320, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i128 }, ptr %rv
  ret { i32, i128 } %rr
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fast_3aPattern_26_3e_H19842cc3f9f17801919cd111c108caa0(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  tail call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__Hdba28025cac729fb3c994cc5728b4c22(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
  ret void
}

define dso_local { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2ftyped_3aExpr_26_3e__H6fdae4ec28a8e0f494e79cb375983eb8(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %r = tail call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
  ret { i64, ptr } %r
}

define dso_local { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLast_3cI64_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l8 = alloca { i64, ptr }
  %rv = alloca { i32, i64 }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t4, i32 0, i32 1
  %t7 = load i64, ptr %t6, !tbaa !24
  %t9 = icmp eq i64 %t7, 0
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t12 = insertvalue { i32, i64 } zeroinitializer, i32 65536, 0
  store { i32, i64 } %t12, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t13, i32 0, i32 0
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t18 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t16, i32 0, i32 0
  %t19 = load { i64, ptr }, ptr %t18, !tbaa !27
  store { i64, ptr } %t19, ptr %l8, !tbaa !27
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t20, i32 0, i32 0
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t25 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t23, i32 0, i32 1
  %t26 = load i64, ptr %t25, !tbaa !24
  %t28 = sub i64 %t26, 1
  %t30 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !27
  %t32 = getelementptr i64, ptr %t31, i64 %t28
  %t33 = load i64, ptr %t32, !tbaa !34
  %t35 = insertvalue { i32, i64 } zeroinitializer, i64 %t33, 1
  store { i32, i64 } %t35, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i64 }, ptr %rv
  ret { i32, i64 } %rr
}

define dso_local { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eTakeAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l14 = alloca i1
  %l21 = alloca { i64, ptr }
  %l31 = alloca i64
  %l34 = alloca i64
  %l53 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %l62 = alloca ptr
  %rv = alloca { i32, i64 }
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load i64, ptr %l1, !tbaa !24
  %t8 = icmp slt i64 %t6, 0
  br i1 %t8, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb3
bb2:
  %t10 = load i64, ptr %l1, !tbaa !24
  %t11 = load ptr, ptr %l2, !tbaa !29
  %t13 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t11, i32 0, i32 1
  %t14 = load i64, ptr %t13, !tbaa !24
  %t17 = icmp sge i64 %t10, %t14
  store i1 %t17, ptr %l14, !tbaa !21
  br label %bb3
bb3:
  %t19 = load i1, ptr %l14, !tbaa !21
  br i1 %t19, label %bb4, label %bb5
bb4:
  %t21 = insertvalue { i32, i64 } zeroinitializer, i32 65538, 0
  store { i32, i64 } %t21, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t22 = load ptr, ptr %l2, !tbaa !29
  %t24 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t22, i32 0, i32 0
  %t25 = load { i64, ptr }, ptr %t24, !tbaa !27
  store { i64, ptr } %t25, ptr %l21, !tbaa !27
  %t26 = load i64, ptr %l1, !tbaa !24
  %t28 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = getelementptr i64, ptr %t29, i64 %t26
  %t31 = load i64, ptr %t30, !tbaa !34
  store i64 %t31, ptr %l3, !tbaa !24
  %t33 = load i64, ptr %l1, !tbaa !24
  store i64 %t33, ptr %l4, !tbaa !24
  %t35 = load ptr, ptr %l2, !tbaa !29
  %t37 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t35, i32 0, i32 1
  %t38 = load i64, ptr %t37, !tbaa !24
  %t40 = sub i64 %t38, 1
  store i64 %t40, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t42 = load i64, ptr %l5, !tbaa !24
  %t43 = load i64, ptr %l4, !tbaa !24
  %t46 = icmp sgt i64 %t42, %t43
  br i1 %t46, label %bb7, label %bb8
bb7:
  %t48 = load i64, ptr %l6, !tbaa !24
  %t50 = icmp sgt i64 %t48, 0
  br i1 %t50, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb12
bb9:
  %t52 = load i64, ptr %l5, !tbaa !24
  %t53 = load i64, ptr %l4, !tbaa !24
  %t56 = sub i64 %t52, %t53
  %t57 = load i64, ptr %l6, !tbaa !24
  %t60 = add i64 %t56, %t57
  %t62 = sub i64 %t60, 1
  %t63 = load i64, ptr %l6, !tbaa !24
  %t66 = sdiv i64 %t62, %t63
  store i64 %t66, ptr %l34, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l34, !tbaa !24
  br label %bb11
bb11:
  %t68 = load i64, ptr %l34, !tbaa !24
  store i64 %t68, ptr %l31, !tbaa !24
  br label %bb12
bb12:
  %t69 = load i64, ptr %l31, !tbaa !24
  store i64 %t69, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb13
bb13:
  %t70 = load i64, ptr %l8, !tbaa !24
  %t71 = load i64, ptr %l7, !tbaa !24
  %t74 = icmp slt i64 %t70, %t71
  %t76 = xor i1 %t74, true
  br i1 %t76, label %bb14, label %bb15
bb14:
  br label %bb18
bb15:
  br label %bb16
bb16:
  %t78 = load i64, ptr %l4, !tbaa !24
  %t79 = load i64, ptr %l8, !tbaa !24
  %t80 = load i64, ptr %l6, !tbaa !24
  %t83 = mul i64 %t79, %t80
  %t86 = add i64 %t78, %t83
  store i64 %t86, ptr %l9, !tbaa !24
  %t88 = load ptr, ptr %l2, !tbaa !29
  %t90 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t88, i32 0, i32 0
  %t91 = load { i64, ptr }, ptr %t90, !tbaa !27
  store { i64, ptr } %t91, ptr %l53, !tbaa !27
  %t92 = load i64, ptr %l9, !tbaa !24
  %t93 = load ptr, ptr %l2, !tbaa !29
  %t95 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t93, i32 0, i32 0
  %t96 = load { i64, ptr }, ptr %t95, !tbaa !27
  store { i64, ptr } %t96, ptr %l56, !tbaa !27
  %t97 = load i64, ptr %l9, !tbaa !24
  %t99 = add i64 %t97, 1
  %t101 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !27
  %t103 = getelementptr i64, ptr %t102, i64 %t99
  %t104 = load i64, ptr %t103, !tbaa !34
  %t107 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t108 = load ptr, ptr %t107, !tbaa !27
  %t109 = getelementptr i64, ptr %t108, i64 %t92
  store i64 %t104, ptr %t109, !tbaa !34
  br label %bb17
bb17:
  %t110 = load i64, ptr %l8, !tbaa !24
  %t112 = add i64 %t110, 1
  store i64 %t112, ptr %l8, !tbaa !24
  br label %bb13
bb18:
  %t114 = load ptr, ptr %l2, !tbaa !29
  store ptr %t114, ptr %l62, !tbaa !29
  %t115 = load ptr, ptr %l62, !tbaa !29
  %t116 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t115, i32 0, i32 1
  %t117 = load i64, ptr %t116, !tbaa !24
  %t119 = sub i64 %t117, 1
  %t121 = load ptr, ptr %l62, !tbaa !29
  %t122 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t121, i32 0, i32 1
  store i64 %t119, ptr %t122, !tbaa !24
  %t123 = load i64, ptr %l3, !tbaa !24
  %t125 = insertvalue { i32, i64 } zeroinitializer, i64 %t123, 1
  store { i32, i64 } %t125, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i64 }, ptr %rv
  ret { i32, i64 } %rr
}

define dso_local { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2eToArray_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %r = tail call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aCaseDecl_26_3e_2eToAr_H44f8de0685d71649bf169c234c7a8f4c(ptr %v0, ptr %v1, ptr %a0)
  ret { i64, ptr } %r
}

define dso_local { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPattern_26_3e_2eToArr_H3d785ef7fade1f29078b6e80f1d617ba(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %r = tail call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aCaseDecl_26_3e_2eToAr_H44f8de0685d71649bf169c234c7a8f4c(ptr %v0, ptr %v1, ptr %a0)
  ret { i64, ptr } %r
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aAsk_3e_2ePush_3ccompiler_2fcheck_3aAsk_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/check:Ask" %a1) #0 {
entry:
  %l1 = alloca %"compiler/check:Ask"
  %l2 = alloca ptr
  %l17 = alloca { i64, ptr }
  %l21 = alloca ptr
  store %"compiler/check:Ask" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t6, i32 0, i32 1
  %t9 = load i64, ptr %t8, !tbaa !24
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t18 = icmp eq i64 %t9, %t15
  br i1 %t18, label %bb1, label %bb2
bb1:
  %t20 = load ptr, ptr %l2, !tbaa !29
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 1
  %t24 = load i64, ptr %t23, !tbaa !24
  %t26 = add i64 %t24, 1
  %t27 = load %"compiler/check:Ask", ptr %l1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3ccompiler_2fcheck_3aAsk_3e_2eroom_3ccompiler_2fcheck_3aAsk_3e(ptr %v0, ptr %v1, ptr %t20, i64 %t26, %"compiler/check:Ask" %t27)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t31 = load ptr, ptr %l2, !tbaa !29
  %t33 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t31, i32 0, i32 0
  %t34 = load { i64, ptr }, ptr %t33, !tbaa !27
  store { i64, ptr } %t34, ptr %l17, !tbaa !27
  %t35 = load ptr, ptr %l2, !tbaa !29
  %t37 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t35, i32 0, i32 1
  %t38 = load i64, ptr %t37, !tbaa !24
  %t39 = load %"compiler/check:Ask", ptr %l1
  %t42 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = getelementptr %"compiler/check:Ask", ptr %t43, i64 %t38
  store %"compiler/check:Ask" %t39, ptr %t44
  %t45 = load ptr, ptr %l2, !tbaa !29
  store ptr %t45, ptr %l21, !tbaa !29
  %t46 = load ptr, ptr %l21, !tbaa !29
  %t47 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t46, i32 0, i32 1
  %t48 = load i64, ptr %t47, !tbaa !24
  %t50 = add i64 %t48, 1
  %t52 = load ptr, ptr %l21, !tbaa !29
  %t53 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t52, i32 0, i32 1
  store i64 %t50, ptr %t53, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aAsk_3e_2eTruncate_3ccompiler_2fcheck_3aAsk_3e(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l18 = alloca i64
  %l26 = alloca i64
  %l29 = alloca i64
  %l48 = alloca { i64, ptr }
  %l50 = alloca %"compiler/check:Ask"
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load i64, ptr %l1, !tbaa !24
  %t7 = load ptr, ptr %l2, !tbaa !29
  %t9 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t7, i32 0, i32 1
  %t10 = load i64, ptr %t9, !tbaa !24
  %t13 = icmp sge i64 %t6, %t10
  br i1 %t13, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t15 = load i64, ptr %l1, !tbaa !24
  %t17 = icmp sgt i64 %t15, 0
  br i1 %t17, label %bb4, label %bb5
bb4:
  %t19 = load i64, ptr %l1, !tbaa !24
  store i64 %t19, ptr %l18, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l18, !tbaa !24
  br label %bb6
bb6:
  %t21 = load i64, ptr %l18, !tbaa !24
  store i64 %t21, ptr %l3, !tbaa !24
  %t22 = load i64, ptr %l3, !tbaa !24
  store i64 %t22, ptr %l4, !tbaa !24
  %t24 = load ptr, ptr %l2, !tbaa !29
  %t26 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t24, i32 0, i32 1
  %t27 = load i64, ptr %t26, !tbaa !24
  store i64 %t27, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t29 = load i64, ptr %l5, !tbaa !24
  %t30 = load i64, ptr %l4, !tbaa !24
  %t33 = icmp sgt i64 %t29, %t30
  br i1 %t33, label %bb7, label %bb8
bb7:
  %t35 = load i64, ptr %l6, !tbaa !24
  %t37 = icmp sgt i64 %t35, 0
  br i1 %t37, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l26, !tbaa !24
  br label %bb12
bb9:
  %t39 = load i64, ptr %l5, !tbaa !24
  %t40 = load i64, ptr %l4, !tbaa !24
  %t43 = sub i64 %t39, %t40
  %t44 = load i64, ptr %l6, !tbaa !24
  %t47 = add i64 %t43, %t44
  %t49 = sub i64 %t47, 1
  %t50 = load i64, ptr %l6, !tbaa !24
  %t53 = sdiv i64 %t49, %t50
  store i64 %t53, ptr %l29, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l29, !tbaa !24
  br label %bb11
bb11:
  %t55 = load i64, ptr %l29, !tbaa !24
  store i64 %t55, ptr %l26, !tbaa !24
  br label %bb12
bb12:
  %t56 = load i64, ptr %l26, !tbaa !24
  store i64 %t56, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb13
bb13:
  %t57 = load i64, ptr %l8, !tbaa !24
  %t58 = load i64, ptr %l7, !tbaa !24
  %t61 = icmp slt i64 %t57, %t58
  %t63 = xor i1 %t61, true
  br i1 %t63, label %bb14, label %bb15
bb14:
  br label %bb18
bb15:
  br label %bb16
bb16:
  %t65 = load i64, ptr %l4, !tbaa !24
  %t66 = load i64, ptr %l8, !tbaa !24
  %t67 = load i64, ptr %l6, !tbaa !24
  %t70 = mul i64 %t66, %t67
  %t73 = add i64 %t65, %t70
  %t75 = load ptr, ptr %l2, !tbaa !29
  %t77 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t75, i32 0, i32 0
  %t78 = load { i64, ptr }, ptr %t77, !tbaa !27
  store { i64, ptr } %t78, ptr %l48, !tbaa !27
  %t81 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !27
  %t83 = getelementptr %"compiler/check:Ask", ptr %t82, i64 %t73
  %t84 = load %"compiler/check:Ask", ptr %t83
  store %"compiler/check:Ask" %t84, ptr %l50
  br label %bb17
bb17:
  %t85 = load i64, ptr %l8, !tbaa !24
  %t87 = add i64 %t85, 1
  store i64 %t87, ptr %l8, !tbaa !24
  br label %bb13
bb18:
  %t89 = load ptr, ptr %l2, !tbaa !29
  %t90 = load i64, ptr %l3, !tbaa !24
  %t93 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t89, i32 0, i32 1
  store i64 %t90, ptr %t93, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aAssertAsk_3e_2eSetA_H2f2d9e3b51ec05f25dc2320ca6b31566(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/check:AssertAsk" %a2) #0 {
entry:
  %l5 = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t4, i32 0, i32 0
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  store { i64, ptr } %t7, ptr %l5, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr %"compiler/check:AssertAsk", ptr %t13, i64 %a1
  store %"compiler/check:AssertAsk" %a2, ptr %t14
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aContractAsk_3e_2eAt_H56c1cddaee4bc4aa5c09605de1331e44(ptr %out, ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l4 = alloca { i64, ptr }
  %l6 = alloca %"compiler/check:ContractAsk"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t4, i32 0, i32 0
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  store { i64, ptr } %t7, ptr %l4, !tbaa !27
  %t10 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !27
  %t12 = getelementptr %"compiler/check:ContractAsk", ptr %t11, i64 %a1
  call void @llvm.memmove.p0.p0.i64(ptr %l6, ptr %t12, i64 136, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l6, i64 136, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aContractAsk_3e_2ePu_H286c5e5dcd81788bf1de6ef6fc9774a9(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca %"compiler/check:ContractAsk"
  %l2 = alloca ptr
  %l15 = alloca %"compiler/check:ContractAsk"
  %l17 = alloca { i64, ptr }
  %l20 = alloca %"compiler/check:ContractAsk"
  %l21 = alloca ptr
  %t29 = alloca %"compiler/check:ContractAsk", align 8
  call void @llvm.memmove.p0.p0.i64(ptr %l1, ptr %a1, i64 136, i1 false)
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t6, i32 0, i32 1
  %t9 = load i64, ptr %t8, !tbaa !24
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t18 = icmp eq i64 %t9, %t15
  br i1 %t18, label %bb1, label %bb2
bb1:
  %t20 = load ptr, ptr %l2, !tbaa !29
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 1
  %t24 = load i64, ptr %t23, !tbaa !24
  %t26 = add i64 %t24, 1
  call void @llvm.memmove.p0.p0.i64(ptr %l15, ptr %l1, i64 136, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %t29, ptr %l15, i64 136, i1 false)
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3ccompiler_2fcheck_3aContractAsk_3e_H16179866dea527591a784fab5866e9a3(ptr %v0, ptr %v1, ptr %t20, i64 %t26, ptr %t29)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t30 = load ptr, ptr %l2, !tbaa !29
  %t32 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t30, i32 0, i32 0
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !27
  store { i64, ptr } %t33, ptr %l17, !tbaa !27
  %t34 = load ptr, ptr %l2, !tbaa !29
  %t36 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t34, i32 0, i32 1
  %t37 = load i64, ptr %t36, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %l20, ptr %l1, i64 136, i1 false)
  %t39 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !27
  %t41 = getelementptr %"compiler/check:ContractAsk", ptr %t40, i64 %t37
  call void @llvm.memmove.p0.p0.i64(ptr %t41, ptr %l20, i64 136, i1 false)
  %t42 = load ptr, ptr %l2, !tbaa !29
  store ptr %t42, ptr %l21, !tbaa !29
  %t43 = load ptr, ptr %l21, !tbaa !29
  %t44 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t43, i32 0, i32 1
  %t45 = load i64, ptr %t44, !tbaa !24
  %t47 = add i64 %t45, 1
  %t49 = load ptr, ptr %l21, !tbaa !29
  %t50 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t49, i32 0, i32 1
  store i64 %t47, ptr %t50, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aEmbedAsk_3e_2ePush_3ccompiler_2fcheck_3aEmbedAsk_3e(ptr %v0, ptr %a0, %"compiler/check:EmbedAsk" %a1) #0 {
entry:
  %l1 = alloca %"compiler/check:EmbedAsk"
  %l2 = alloca ptr
  %l17 = alloca { i64, ptr }
  %l21 = alloca ptr
  store %"compiler/check:EmbedAsk" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t6, i32 0, i32 1
  %t9 = load i64, ptr %t8, !tbaa !24
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t18 = icmp eq i64 %t9, %t15
  br i1 %t18, label %bb1, label %bb2
bb1:
  %t20 = load ptr, ptr %l2, !tbaa !29
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 1
  %t24 = load i64, ptr %t23, !tbaa !24
  %t26 = add i64 %t24, 1
  %t27 = load %"compiler/check:EmbedAsk", ptr %l1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3ccompiler_2fcheck_3aEmbedAsk_3e_2e_H0cd9db32fe9336edcb7610499450d519(ptr %v0, ptr %t20, i64 %t26, %"compiler/check:EmbedAsk" %t27)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t31 = load ptr, ptr %l2, !tbaa !29
  %t33 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t31, i32 0, i32 0
  %t34 = load { i64, ptr }, ptr %t33, !tbaa !27
  store { i64, ptr } %t34, ptr %l17, !tbaa !27
  %t35 = load ptr, ptr %l2, !tbaa !29
  %t37 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t35, i32 0, i32 1
  %t38 = load i64, ptr %t37, !tbaa !24
  %t39 = load %"compiler/check:EmbedAsk", ptr %l1
  %t42 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = getelementptr %"compiler/check:EmbedAsk", ptr %t43, i64 %t38
  store %"compiler/check:EmbedAsk" %t39, ptr %t44
  %t45 = load ptr, ptr %l2, !tbaa !29
  store ptr %t45, ptr %l21, !tbaa !29
  %t46 = load ptr, ptr %l21, !tbaa !29
  %t47 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t46, i32 0, i32 1
  %t48 = load i64, ptr %t47, !tbaa !24
  %t50 = add i64 %t48, 1
  %t52 = load ptr, ptr %l21, !tbaa !29
  %t53 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t52, i32 0, i32 1
  store i64 %t50, ptr %t53, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aGap_3e_2ePush_3ccompiler_2fcheck_3aGap_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/check:Gap" %a1) #0 {
entry:
  %l1 = alloca %"compiler/check:Gap"
  %l2 = alloca ptr
  %l17 = alloca { i64, ptr }
  %l21 = alloca ptr
  store %"compiler/check:Gap" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t6, i32 0, i32 1
  %t9 = load i64, ptr %t8, !tbaa !24
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t18 = icmp eq i64 %t9, %t15
  br i1 %t18, label %bb1, label %bb2
bb1:
  %t20 = load ptr, ptr %l2, !tbaa !29
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 1
  %t24 = load i64, ptr %t23, !tbaa !24
  %t26 = add i64 %t24, 1
  %t27 = load %"compiler/check:Gap", ptr %l1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3ccompiler_2fcheck_3aGap_3e_2eroom_3ccompiler_2fcheck_3aGap_3e(ptr %v0, ptr %v1, ptr %t20, i64 %t26, %"compiler/check:Gap" %t27)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t31 = load ptr, ptr %l2, !tbaa !29
  %t33 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t31, i32 0, i32 0
  %t34 = load { i64, ptr }, ptr %t33, !tbaa !27
  store { i64, ptr } %t34, ptr %l17, !tbaa !27
  %t35 = load ptr, ptr %l2, !tbaa !29
  %t37 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t35, i32 0, i32 1
  %t38 = load i64, ptr %t37, !tbaa !24
  %t39 = load %"compiler/check:Gap", ptr %l1
  %t42 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = getelementptr %"compiler/check:Gap", ptr %t43, i64 %t38
  store %"compiler/check:Gap" %t39, ptr %t44
  %t45 = load ptr, ptr %l2, !tbaa !29
  store ptr %t45, ptr %l21, !tbaa !29
  %t46 = load ptr, ptr %l21, !tbaa !29
  %t47 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t46, i32 0, i32 1
  %t48 = load i64, ptr %t47, !tbaa !24
  %t50 = add i64 %t48, 1
  %t52 = load ptr, ptr %l21, !tbaa !29
  %t53 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t52, i32 0, i32 1
  store i64 %t50, ptr %t53, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aGap_3e_2eTruncate_3ccompiler_2fcheck_3aGap_3e(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l18 = alloca i64
  %l26 = alloca i64
  %l29 = alloca i64
  %l48 = alloca { i64, ptr }
  %l50 = alloca %"compiler/check:Gap"
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load i64, ptr %l1, !tbaa !24
  %t7 = load ptr, ptr %l2, !tbaa !29
  %t9 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t7, i32 0, i32 1
  %t10 = load i64, ptr %t9, !tbaa !24
  %t13 = icmp sge i64 %t6, %t10
  br i1 %t13, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t15 = load i64, ptr %l1, !tbaa !24
  %t17 = icmp sgt i64 %t15, 0
  br i1 %t17, label %bb4, label %bb5
bb4:
  %t19 = load i64, ptr %l1, !tbaa !24
  store i64 %t19, ptr %l18, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l18, !tbaa !24
  br label %bb6
bb6:
  %t21 = load i64, ptr %l18, !tbaa !24
  store i64 %t21, ptr %l3, !tbaa !24
  %t22 = load i64, ptr %l3, !tbaa !24
  store i64 %t22, ptr %l4, !tbaa !24
  %t24 = load ptr, ptr %l2, !tbaa !29
  %t26 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t24, i32 0, i32 1
  %t27 = load i64, ptr %t26, !tbaa !24
  store i64 %t27, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t29 = load i64, ptr %l5, !tbaa !24
  %t30 = load i64, ptr %l4, !tbaa !24
  %t33 = icmp sgt i64 %t29, %t30
  br i1 %t33, label %bb7, label %bb8
bb7:
  %t35 = load i64, ptr %l6, !tbaa !24
  %t37 = icmp sgt i64 %t35, 0
  br i1 %t37, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l26, !tbaa !24
  br label %bb12
bb9:
  %t39 = load i64, ptr %l5, !tbaa !24
  %t40 = load i64, ptr %l4, !tbaa !24
  %t43 = sub i64 %t39, %t40
  %t44 = load i64, ptr %l6, !tbaa !24
  %t47 = add i64 %t43, %t44
  %t49 = sub i64 %t47, 1
  %t50 = load i64, ptr %l6, !tbaa !24
  %t53 = sdiv i64 %t49, %t50
  store i64 %t53, ptr %l29, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l29, !tbaa !24
  br label %bb11
bb11:
  %t55 = load i64, ptr %l29, !tbaa !24
  store i64 %t55, ptr %l26, !tbaa !24
  br label %bb12
bb12:
  %t56 = load i64, ptr %l26, !tbaa !24
  store i64 %t56, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb13
bb13:
  %t57 = load i64, ptr %l8, !tbaa !24
  %t58 = load i64, ptr %l7, !tbaa !24
  %t61 = icmp slt i64 %t57, %t58
  %t63 = xor i1 %t61, true
  br i1 %t63, label %bb14, label %bb15
bb14:
  br label %bb18
bb15:
  br label %bb16
bb16:
  %t65 = load i64, ptr %l4, !tbaa !24
  %t66 = load i64, ptr %l8, !tbaa !24
  %t67 = load i64, ptr %l6, !tbaa !24
  %t70 = mul i64 %t66, %t67
  %t73 = add i64 %t65, %t70
  %t75 = load ptr, ptr %l2, !tbaa !29
  %t77 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t75, i32 0, i32 0
  %t78 = load { i64, ptr }, ptr %t77, !tbaa !27
  store { i64, ptr } %t78, ptr %l48, !tbaa !27
  %t81 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !27
  %t83 = getelementptr %"compiler/check:Gap", ptr %t82, i64 %t73
  %t84 = load %"compiler/check:Gap", ptr %t83
  store %"compiler/check:Gap" %t84, ptr %l50
  br label %bb17
bb17:
  %t85 = load i64, ptr %l8, !tbaa !24
  %t87 = add i64 %t85, 1
  store i64 %t87, ptr %l8, !tbaa !24
  br label %bb13
bb18:
  %t89 = load ptr, ptr %l2, !tbaa !29
  %t90 = load i64, ptr %l3, !tbaa !24
  %t93 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t89, i32 0, i32 1
  store i64 %t90, ptr %t93, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aValueAsk_3e_2ePush_3ccompiler_2fcheck_3aValueAsk_3e(ptr %v0, ptr %a0, %"compiler/check:ValueAsk" %a1) #0 {
entry:
  %l1 = alloca %"compiler/check:ValueAsk"
  %l2 = alloca ptr
  %l17 = alloca { i64, ptr }
  %l21 = alloca ptr
  store %"compiler/check:ValueAsk" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t6, i32 0, i32 1
  %t9 = load i64, ptr %t8, !tbaa !24
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t18 = icmp eq i64 %t9, %t15
  br i1 %t18, label %bb1, label %bb2
bb1:
  %t20 = load ptr, ptr %l2, !tbaa !29
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 1
  %t24 = load i64, ptr %t23, !tbaa !24
  %t26 = add i64 %t24, 1
  %t27 = load %"compiler/check:ValueAsk", ptr %l1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3ccompiler_2fcheck_3aValueAsk_3e_2e_Hb56d90bd4965dfe5ab616ef1e71111a0(ptr %v0, ptr %t20, i64 %t26, %"compiler/check:ValueAsk" %t27)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t31 = load ptr, ptr %l2, !tbaa !29
  %t33 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t31, i32 0, i32 0
  %t34 = load { i64, ptr }, ptr %t33, !tbaa !27
  store { i64, ptr } %t34, ptr %l17, !tbaa !27
  %t35 = load ptr, ptr %l2, !tbaa !29
  %t37 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t35, i32 0, i32 1
  %t38 = load i64, ptr %t37, !tbaa !24
  %t39 = load %"compiler/check:ValueAsk", ptr %l1
  %t42 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = getelementptr %"compiler/check:ValueAsk", ptr %t43, i64 %t38
  store %"compiler/check:ValueAsk" %t39, ptr %t44
  %t45 = load ptr, ptr %l2, !tbaa !29
  store ptr %t45, ptr %l21, !tbaa !29
  %t46 = load ptr, ptr %l21, !tbaa !29
  %t47 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t46, i32 0, i32 1
  %t48 = load i64, ptr %t47, !tbaa !24
  %t50 = add i64 %t48, 1
  %t52 = load ptr, ptr %l21, !tbaa !29
  %t53 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t52, i32 0, i32 1
  store i64 %t50, ptr %t53, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aatRec_3e_2ePush_3ccompiler_2fcheck_3aatRec_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/check:atRec" %a1) #0 {
entry:
  %l1 = alloca %"compiler/check:atRec"
  %l2 = alloca ptr
  %l17 = alloca { i64, ptr }
  %l21 = alloca ptr
  store %"compiler/check:atRec" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t6, i32 0, i32 1
  %t9 = load i64, ptr %t8, !tbaa !24
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t18 = icmp eq i64 %t9, %t15
  br i1 %t18, label %bb1, label %bb2
bb1:
  %t20 = load ptr, ptr %l2, !tbaa !29
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 1
  %t24 = load i64, ptr %t23, !tbaa !24
  %t26 = add i64 %t24, 1
  %t27 = load %"compiler/check:atRec", ptr %l1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3ccompiler_2fcheck_3aatRec_3e_2eroom_3ccompiler_2fcheck_3aatRec_3e(ptr %v0, ptr %v1, ptr %t20, i64 %t26, %"compiler/check:atRec" %t27)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t31 = load ptr, ptr %l2, !tbaa !29
  %t33 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t31, i32 0, i32 0
  %t34 = load { i64, ptr }, ptr %t33, !tbaa !27
  store { i64, ptr } %t34, ptr %l17, !tbaa !27
  %t35 = load ptr, ptr %l2, !tbaa !29
  %t37 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t35, i32 0, i32 1
  %t38 = load i64, ptr %t37, !tbaa !24
  %t39 = load %"compiler/check:atRec", ptr %l1
  %t42 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = getelementptr %"compiler/check:atRec", ptr %t43, i64 %t38
  store %"compiler/check:atRec" %t39, ptr %t44
  %t45 = load ptr, ptr %l2, !tbaa !29
  store ptr %t45, ptr %l21, !tbaa !29
  %t46 = load ptr, ptr %l21, !tbaa !29
  %t47 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t46, i32 0, i32 1
  %t48 = load i64, ptr %t47, !tbaa !24
  %t50 = add i64 %t48, 1
  %t52 = load ptr, ptr %l21, !tbaa !29
  %t53 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t52, i32 0, i32 1
  store i64 %t50, ptr %t53, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrBind_3e_2ePush_3ccompiler_2fcheck_3aerrBind_3e(ptr %v0, ptr %a0, %"compiler/check:errBind" %a1) #0 {
entry:
  %l1 = alloca %"compiler/check:errBind"
  %l2 = alloca ptr
  %l17 = alloca { i64, ptr }
  %l21 = alloca ptr
  store %"compiler/check:errBind" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t6, i32 0, i32 1
  %t9 = load i64, ptr %t8, !tbaa !24
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t18 = icmp eq i64 %t9, %t15
  br i1 %t18, label %bb1, label %bb2
bb1:
  %t20 = load ptr, ptr %l2, !tbaa !29
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 1
  %t24 = load i64, ptr %t23, !tbaa !24
  %t26 = add i64 %t24, 1
  %t27 = load %"compiler/check:errBind", ptr %l1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3ccompiler_2fcheck_3aerrBind_3e_2er_H9f3beeaa2b0bc6b319db07b87ddedb31(ptr %v0, ptr %t20, i64 %t26, %"compiler/check:errBind" %t27)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t31 = load ptr, ptr %l2, !tbaa !29
  %t33 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t31, i32 0, i32 0
  %t34 = load { i64, ptr }, ptr %t33, !tbaa !27
  store { i64, ptr } %t34, ptr %l17, !tbaa !27
  %t35 = load ptr, ptr %l2, !tbaa !29
  %t37 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t35, i32 0, i32 1
  %t38 = load i64, ptr %t37, !tbaa !24
  %t39 = load %"compiler/check:errBind", ptr %l1
  %t42 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = getelementptr %"compiler/check:errBind", ptr %t43, i64 %t38
  store %"compiler/check:errBind" %t39, ptr %t44
  %t45 = load ptr, ptr %l2, !tbaa !29
  store ptr %t45, ptr %l21, !tbaa !29
  %t46 = load ptr, ptr %l21, !tbaa !29
  %t47 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t46, i32 0, i32 1
  %t48 = load i64, ptr %t47, !tbaa !24
  %t50 = add i64 %t48, 1
  %t52 = load ptr, ptr %l21, !tbaa !29
  %t53 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t52, i32 0, i32 1
  store i64 %t50, ptr %t53, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrBind_3e_2eTrunca_H5bf147fe04fb910fd8a08f646d33c634(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l18 = alloca i64
  %l26 = alloca i64
  %l29 = alloca i64
  %l48 = alloca { i64, ptr }
  %l50 = alloca %"compiler/check:errBind"
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load i64, ptr %l1, !tbaa !24
  %t7 = load ptr, ptr %l2, !tbaa !29
  %t9 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t7, i32 0, i32 1
  %t10 = load i64, ptr %t9, !tbaa !24
  %t13 = icmp sge i64 %t6, %t10
  br i1 %t13, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t15 = load i64, ptr %l1, !tbaa !24
  %t17 = icmp sgt i64 %t15, 0
  br i1 %t17, label %bb4, label %bb5
bb4:
  %t19 = load i64, ptr %l1, !tbaa !24
  store i64 %t19, ptr %l18, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l18, !tbaa !24
  br label %bb6
bb6:
  %t21 = load i64, ptr %l18, !tbaa !24
  store i64 %t21, ptr %l3, !tbaa !24
  %t22 = load i64, ptr %l3, !tbaa !24
  store i64 %t22, ptr %l4, !tbaa !24
  %t24 = load ptr, ptr %l2, !tbaa !29
  %t26 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t24, i32 0, i32 1
  %t27 = load i64, ptr %t26, !tbaa !24
  store i64 %t27, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t29 = load i64, ptr %l5, !tbaa !24
  %t30 = load i64, ptr %l4, !tbaa !24
  %t33 = icmp sgt i64 %t29, %t30
  br i1 %t33, label %bb7, label %bb8
bb7:
  %t35 = load i64, ptr %l6, !tbaa !24
  %t37 = icmp sgt i64 %t35, 0
  br i1 %t37, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l26, !tbaa !24
  br label %bb12
bb9:
  %t39 = load i64, ptr %l5, !tbaa !24
  %t40 = load i64, ptr %l4, !tbaa !24
  %t43 = sub i64 %t39, %t40
  %t44 = load i64, ptr %l6, !tbaa !24
  %t47 = add i64 %t43, %t44
  %t49 = sub i64 %t47, 1
  %t50 = load i64, ptr %l6, !tbaa !24
  %t53 = sdiv i64 %t49, %t50
  store i64 %t53, ptr %l29, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l29, !tbaa !24
  br label %bb11
bb11:
  %t55 = load i64, ptr %l29, !tbaa !24
  store i64 %t55, ptr %l26, !tbaa !24
  br label %bb12
bb12:
  %t56 = load i64, ptr %l26, !tbaa !24
  store i64 %t56, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb13
bb13:
  %t57 = load i64, ptr %l8, !tbaa !24
  %t58 = load i64, ptr %l7, !tbaa !24
  %t61 = icmp slt i64 %t57, %t58
  %t63 = xor i1 %t61, true
  br i1 %t63, label %bb14, label %bb15
bb14:
  br label %bb18
bb15:
  br label %bb16
bb16:
  %t65 = load i64, ptr %l4, !tbaa !24
  %t66 = load i64, ptr %l8, !tbaa !24
  %t67 = load i64, ptr %l6, !tbaa !24
  %t70 = mul i64 %t66, %t67
  %t73 = add i64 %t65, %t70
  %t75 = load ptr, ptr %l2, !tbaa !29
  %t77 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t75, i32 0, i32 0
  %t78 = load { i64, ptr }, ptr %t77, !tbaa !27
  store { i64, ptr } %t78, ptr %l48, !tbaa !27
  %t81 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !27
  %t83 = getelementptr %"compiler/check:errBind", ptr %t82, i64 %t73
  %t84 = load %"compiler/check:errBind", ptr %t83
  store %"compiler/check:errBind" %t84, ptr %l50
  br label %bb17
bb17:
  %t85 = load i64, ptr %l8, !tbaa !24
  %t87 = add i64 %t85, 1
  store i64 %t87, ptr %l8, !tbaa !24
  br label %bb13
bb18:
  %t89 = load ptr, ptr %l2, !tbaa !29
  %t90 = load i64, ptr %l3, !tbaa !24
  %t93 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t89, i32 0, i32 1
  store i64 %t90, ptr %t93, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local { i32, %"compiler/check:errNarrow" } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrNarrow_3e_2eLast_He310b7451e653469b2155498b3293ff7(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l8 = alloca { i64, ptr }
  %rv = alloca { i32, %"compiler/check:errNarrow" }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t4, i32 0, i32 1
  %t7 = load i64, ptr %t6, !tbaa !24
  %t9 = icmp eq i64 %t7, 0
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t12 = insertvalue { i32, %"compiler/check:errNarrow" } zeroinitializer, i32 65536, 0
  store { i32, %"compiler/check:errNarrow" } %t12, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t13, i32 0, i32 0
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t18 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t16, i32 0, i32 0
  %t19 = load { i64, ptr }, ptr %t18, !tbaa !27
  store { i64, ptr } %t19, ptr %l8, !tbaa !27
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t20, i32 0, i32 0
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t25 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t23, i32 0, i32 1
  %t26 = load i64, ptr %t25, !tbaa !24
  %t28 = sub i64 %t26, 1
  %t30 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !27
  %t32 = getelementptr %"compiler/check:errNarrow", ptr %t31, i64 %t28
  %t33 = load %"compiler/check:errNarrow", ptr %t32
  %t35 = insertvalue { i32, %"compiler/check:errNarrow" } zeroinitializer, %"compiler/check:errNarrow" %t33, 1
  store { i32, %"compiler/check:errNarrow" } %t35, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"compiler/check:errNarrow" }, ptr %rv
  ret { i32, %"compiler/check:errNarrow" } %rr
}

define dso_local i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrNarrow_3e_2eLen__H3cdfcddd9c493bd8bcefc7b766e0438b(ptr %v0, ptr %a0) #0 {
entry:
  %r = tail call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %v0, ptr %a0)
  ret i64 %r
}

define dso_local { i32, %"compiler/check:errNarrow" } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrNarrow_3e_2ePop__He4c3571ab54dd9fc34e0d36cd7afb0ff(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca ptr
  %l8 = alloca ptr
  %l12 = alloca { i64, ptr }
  %rv = alloca { i32, %"compiler/check:errNarrow" }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l1, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t6, i32 0, i32 1
  %t9 = load i64, ptr %t8, !tbaa !24
  %t11 = icmp eq i64 %t9, 0
  br i1 %t11, label %bb1, label %bb2
bb1:
  %t14 = insertvalue { i32, %"compiler/check:errNarrow" } zeroinitializer, i32 65536, 0
  store { i32, %"compiler/check:errNarrow" } %t14, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t15 = load ptr, ptr %l1, !tbaa !29
  store ptr %t15, ptr %l8, !tbaa !29
  %t16 = load ptr, ptr %l8, !tbaa !29
  %t17 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t16, i32 0, i32 1
  %t18 = load i64, ptr %t17, !tbaa !24
  %t20 = sub i64 %t18, 1
  %t22 = load ptr, ptr %l8, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t22, i32 0, i32 1
  store i64 %t20, ptr %t23, !tbaa !24
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t26 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t24, i32 0, i32 0
  %t27 = load { i64, ptr }, ptr %t26, !tbaa !27
  store { i64, ptr } %t27, ptr %l12, !tbaa !27
  %t28 = load ptr, ptr %l1, !tbaa !29
  %t30 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t28, i32 0, i32 1
  %t31 = load i64, ptr %t30, !tbaa !24
  %t33 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = getelementptr %"compiler/check:errNarrow", ptr %t34, i64 %t31
  %t36 = load %"compiler/check:errNarrow", ptr %t35
  %t38 = insertvalue { i32, %"compiler/check:errNarrow" } zeroinitializer, %"compiler/check:errNarrow" %t36, 1
  store { i32, %"compiler/check:errNarrow" } %t38, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"compiler/check:errNarrow" }, ptr %rv
  ret { i32, %"compiler/check:errNarrow" } %rr
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alaneNode_3e_2ePush_3ccompiler_2fcheck_3alaneNode_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/check:laneNode" %a1) #0 {
entry:
  %l1 = alloca %"compiler/check:laneNode"
  %l2 = alloca ptr
  %l17 = alloca { i64, ptr }
  %l21 = alloca ptr
  store %"compiler/check:laneNode" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t6, i32 0, i32 1
  %t9 = load i64, ptr %t8, !tbaa !24
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t18 = icmp eq i64 %t9, %t15
  br i1 %t18, label %bb1, label %bb2
bb1:
  %t20 = load ptr, ptr %l2, !tbaa !29
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 1
  %t24 = load i64, ptr %t23, !tbaa !24
  %t26 = add i64 %t24, 1
  %t27 = load %"compiler/check:laneNode", ptr %l1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3ccompiler_2fcheck_3alaneNode_3e_2e_H1c8c3738d9f3771d0b332589cc5b744e(ptr %v0, ptr %v1, ptr %t20, i64 %t26, %"compiler/check:laneNode" %t27)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t31 = load ptr, ptr %l2, !tbaa !29
  %t33 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t31, i32 0, i32 0
  %t34 = load { i64, ptr }, ptr %t33, !tbaa !27
  store { i64, ptr } %t34, ptr %l17, !tbaa !27
  %t35 = load ptr, ptr %l2, !tbaa !29
  %t37 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t35, i32 0, i32 1
  %t38 = load i64, ptr %t37, !tbaa !24
  %t39 = load %"compiler/check:laneNode", ptr %l1
  %t42 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = getelementptr %"compiler/check:laneNode", ptr %t43, i64 %t38
  store %"compiler/check:laneNode" %t39, ptr %t44
  %t45 = load ptr, ptr %l2, !tbaa !29
  store ptr %t45, ptr %l21, !tbaa !29
  %t46 = load ptr, ptr %l21, !tbaa !29
  %t47 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t46, i32 0, i32 1
  %t48 = load i64, ptr %t47, !tbaa !24
  %t50 = add i64 %t48, 1
  %t52 = load ptr, ptr %l21, !tbaa !29
  %t53 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t52, i32 0, i32 1
  store i64 %t50, ptr %t53, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local { i32, %"compiler/check:narrowed" } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2eLast_3ccompiler_2fcheck_3anarrowed_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l8 = alloca { i64, ptr }
  %rv = alloca { i32, %"compiler/check:narrowed" }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t4, i32 0, i32 1
  %t7 = load i64, ptr %t6, !tbaa !24
  %t9 = icmp eq i64 %t7, 0
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t12 = insertvalue { i32, %"compiler/check:narrowed" } zeroinitializer, i32 65536, 0
  store { i32, %"compiler/check:narrowed" } %t12, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t13, i32 0, i32 0
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t18 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t16, i32 0, i32 0
  %t19 = load { i64, ptr }, ptr %t18, !tbaa !27
  store { i64, ptr } %t19, ptr %l8, !tbaa !27
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t20, i32 0, i32 0
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t25 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t23, i32 0, i32 1
  %t26 = load i64, ptr %t25, !tbaa !24
  %t28 = sub i64 %t26, 1
  %t30 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !27
  %t32 = getelementptr %"compiler/check:narrowed", ptr %t31, i64 %t28
  %t33 = load %"compiler/check:narrowed", ptr %t32
  %t35 = insertvalue { i32, %"compiler/check:narrowed" } zeroinitializer, %"compiler/check:narrowed" %t33, 1
  store { i32, %"compiler/check:narrowed" } %t35, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"compiler/check:narrowed" }, ptr %rv
  ret { i32, %"compiler/check:narrowed" } %rr
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2ePush_3ccompiler_2fcheck_3anarrowed_3e(ptr %v0, ptr %a0, %"compiler/check:narrowed" %a1) #0 {
entry:
  %l1 = alloca %"compiler/check:narrowed"
  %l2 = alloca ptr
  %l17 = alloca { i64, ptr }
  %l21 = alloca ptr
  store %"compiler/check:narrowed" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t6, i32 0, i32 1
  %t9 = load i64, ptr %t8, !tbaa !24
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t18 = icmp eq i64 %t9, %t15
  br i1 %t18, label %bb1, label %bb2
bb1:
  %t20 = load ptr, ptr %l2, !tbaa !29
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 1
  %t24 = load i64, ptr %t23, !tbaa !24
  %t26 = add i64 %t24, 1
  %t27 = load %"compiler/check:narrowed", ptr %l1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3ccompiler_2fcheck_3anarrowed_3e_2e_H1675fd03025bca61f0dd06a2befaac33(ptr %v0, ptr %t20, i64 %t26, %"compiler/check:narrowed" %t27)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t31 = load ptr, ptr %l2, !tbaa !29
  %t33 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t31, i32 0, i32 0
  %t34 = load { i64, ptr }, ptr %t33, !tbaa !27
  store { i64, ptr } %t34, ptr %l17, !tbaa !27
  %t35 = load ptr, ptr %l2, !tbaa !29
  %t37 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t35, i32 0, i32 1
  %t38 = load i64, ptr %t37, !tbaa !24
  %t39 = load %"compiler/check:narrowed", ptr %l1
  %t42 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = getelementptr %"compiler/check:narrowed", ptr %t43, i64 %t38
  store %"compiler/check:narrowed" %t39, ptr %t44
  %t45 = load ptr, ptr %l2, !tbaa !29
  store ptr %t45, ptr %l21, !tbaa !29
  %t46 = load ptr, ptr %l21, !tbaa !29
  %t47 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t46, i32 0, i32 1
  %t48 = load i64, ptr %t47, !tbaa !24
  %t50 = add i64 %t48, 1
  %t52 = load ptr, ptr %l21, !tbaa !29
  %t53 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t52, i32 0, i32 1
  store i64 %t50, ptr %t53, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/check:nullNarrow" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anullNarrow_3e_2eAt__H22e551fb00043bde3f1f8b2c6007f7cb(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l4 = alloca { i64, ptr }
  %rv = alloca %"compiler/check:nullNarrow"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t4, i32 0, i32 0
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  store { i64, ptr } %t7, ptr %l4, !tbaa !27
  %t10 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !27
  %t12 = getelementptr %"compiler/check:nullNarrow", ptr %t11, i64 %a1
  %t13 = load %"compiler/check:nullNarrow", ptr %t12
  store %"compiler/check:nullNarrow" %t13, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:nullNarrow", ptr %rv
  ret %"compiler/check:nullNarrow" %rr
}

define dso_local i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anullNarrow_3e_2eLen_H4b13e48b0a317e727dbe35330ad8712a(ptr %v0, ptr %a0) #0 {
entry:
  %r = tail call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %v0, ptr %a0)
  ret i64 %r
}

define dso_local { i32, %"compiler/check:nullNarrow" } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anullNarrow_3e_2ePop_H59a749d10c64cd066029408cbe89e7b7(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l1 = alloca ptr
  %l8 = alloca ptr
  %l12 = alloca { i64, ptr }
  %rv = alloca { i32, %"compiler/check:nullNarrow" }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l1, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t6, i32 0, i32 1
  %t9 = load i64, ptr %t8, !tbaa !24
  %t11 = icmp eq i64 %t9, 0
  br i1 %t11, label %bb1, label %bb2
bb1:
  %t14 = insertvalue { i32, %"compiler/check:nullNarrow" } zeroinitializer, i32 65536, 0
  store { i32, %"compiler/check:nullNarrow" } %t14, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t15 = load ptr, ptr %l1, !tbaa !29
  store ptr %t15, ptr %l8, !tbaa !29
  %t16 = load ptr, ptr %l8, !tbaa !29
  %t17 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t16, i32 0, i32 1
  %t18 = load i64, ptr %t17, !tbaa !24
  %t20 = sub i64 %t18, 1
  %t22 = load ptr, ptr %l8, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t22, i32 0, i32 1
  store i64 %t20, ptr %t23, !tbaa !24
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t26 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t24, i32 0, i32 0
  %t27 = load { i64, ptr }, ptr %t26, !tbaa !27
  store { i64, ptr } %t27, ptr %l12, !tbaa !27
  %t28 = load ptr, ptr %l1, !tbaa !29
  %t30 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t28, i32 0, i32 1
  %t31 = load i64, ptr %t30, !tbaa !24
  %t33 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = getelementptr %"compiler/check:nullNarrow", ptr %t34, i64 %t31
  %t36 = load %"compiler/check:nullNarrow", ptr %t35
  %t38 = insertvalue { i32, %"compiler/check:nullNarrow" } zeroinitializer, %"compiler/check:nullNarrow" %t36, 1
  store { i32, %"compiler/check:nullNarrow" } %t38, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"compiler/check:nullNarrow" }, ptr %rv
  ret { i32, %"compiler/check:nullNarrow" } %rr
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anullNarrow_3e_2ePus_H6cb9d90d121a5c1d081cb085b656665f(ptr %v0, ptr %v1, ptr %a0, %"compiler/check:nullNarrow" %a1) #0 {
entry:
  %l1 = alloca %"compiler/check:nullNarrow"
  %l2 = alloca ptr
  %l17 = alloca { i64, ptr }
  %l21 = alloca ptr
  store %"compiler/check:nullNarrow" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t6, i32 0, i32 1
  %t9 = load i64, ptr %t8, !tbaa !24
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t18 = icmp eq i64 %t9, %t15
  br i1 %t18, label %bb1, label %bb2
bb1:
  %t20 = load ptr, ptr %l2, !tbaa !29
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 1
  %t24 = load i64, ptr %t23, !tbaa !24
  %t26 = add i64 %t24, 1
  %t27 = load %"compiler/check:nullNarrow", ptr %l1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3ccompiler_2fcheck_3anullNarrow_3e__Hfe323e1d425e9315957739f859be5234(ptr %v0, ptr %v1, ptr %t20, i64 %t26, %"compiler/check:nullNarrow" %t27)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t31 = load ptr, ptr %l2, !tbaa !29
  %t33 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t31, i32 0, i32 0
  %t34 = load { i64, ptr }, ptr %t33, !tbaa !27
  store { i64, ptr } %t34, ptr %l17, !tbaa !27
  %t35 = load ptr, ptr %l2, !tbaa !29
  %t37 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t35, i32 0, i32 1
  %t38 = load i64, ptr %t37, !tbaa !24
  %t39 = load %"compiler/check:nullNarrow", ptr %l1
  %t42 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = getelementptr %"compiler/check:nullNarrow", ptr %t43, i64 %t38
  store %"compiler/check:nullNarrow" %t39, ptr %t44
  %t45 = load ptr, ptr %l2, !tbaa !29
  store ptr %t45, ptr %l21, !tbaa !29
  %t46 = load ptr, ptr %l21, !tbaa !29
  %t47 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t46, i32 0, i32 1
  %t48 = load i64, ptr %t47, !tbaa !24
  %t50 = add i64 %t48, 1
  %t52 = load ptr, ptr %l21, !tbaa !29
  %t53 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t52, i32 0, i32 1
  store i64 %t50, ptr %t53, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anullNarrow_3e_2eTru_Hf06d897493074497da237c73fecd44cc(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l18 = alloca i64
  %l26 = alloca i64
  %l29 = alloca i64
  %l48 = alloca { i64, ptr }
  %l50 = alloca %"compiler/check:nullNarrow"
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load i64, ptr %l1, !tbaa !24
  %t7 = load ptr, ptr %l2, !tbaa !29
  %t9 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t7, i32 0, i32 1
  %t10 = load i64, ptr %t9, !tbaa !24
  %t13 = icmp sge i64 %t6, %t10
  br i1 %t13, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t15 = load i64, ptr %l1, !tbaa !24
  %t17 = icmp sgt i64 %t15, 0
  br i1 %t17, label %bb4, label %bb5
bb4:
  %t19 = load i64, ptr %l1, !tbaa !24
  store i64 %t19, ptr %l18, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l18, !tbaa !24
  br label %bb6
bb6:
  %t21 = load i64, ptr %l18, !tbaa !24
  store i64 %t21, ptr %l3, !tbaa !24
  %t22 = load i64, ptr %l3, !tbaa !24
  store i64 %t22, ptr %l4, !tbaa !24
  %t24 = load ptr, ptr %l2, !tbaa !29
  %t26 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t24, i32 0, i32 1
  %t27 = load i64, ptr %t26, !tbaa !24
  store i64 %t27, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t29 = load i64, ptr %l5, !tbaa !24
  %t30 = load i64, ptr %l4, !tbaa !24
  %t33 = icmp sgt i64 %t29, %t30
  br i1 %t33, label %bb7, label %bb8
bb7:
  %t35 = load i64, ptr %l6, !tbaa !24
  %t37 = icmp sgt i64 %t35, 0
  br i1 %t37, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l26, !tbaa !24
  br label %bb12
bb9:
  %t39 = load i64, ptr %l5, !tbaa !24
  %t40 = load i64, ptr %l4, !tbaa !24
  %t43 = sub i64 %t39, %t40
  %t44 = load i64, ptr %l6, !tbaa !24
  %t47 = add i64 %t43, %t44
  %t49 = sub i64 %t47, 1
  %t50 = load i64, ptr %l6, !tbaa !24
  %t53 = sdiv i64 %t49, %t50
  store i64 %t53, ptr %l29, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l29, !tbaa !24
  br label %bb11
bb11:
  %t55 = load i64, ptr %l29, !tbaa !24
  store i64 %t55, ptr %l26, !tbaa !24
  br label %bb12
bb12:
  %t56 = load i64, ptr %l26, !tbaa !24
  store i64 %t56, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb13
bb13:
  %t57 = load i64, ptr %l8, !tbaa !24
  %t58 = load i64, ptr %l7, !tbaa !24
  %t61 = icmp slt i64 %t57, %t58
  %t63 = xor i1 %t61, true
  br i1 %t63, label %bb14, label %bb15
bb14:
  br label %bb18
bb15:
  br label %bb16
bb16:
  %t65 = load i64, ptr %l4, !tbaa !24
  %t66 = load i64, ptr %l8, !tbaa !24
  %t67 = load i64, ptr %l6, !tbaa !24
  %t70 = mul i64 %t66, %t67
  %t73 = add i64 %t65, %t70
  %t75 = load ptr, ptr %l2, !tbaa !29
  %t77 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t75, i32 0, i32 0
  %t78 = load { i64, ptr }, ptr %t77, !tbaa !27
  store { i64, ptr } %t78, ptr %l48, !tbaa !27
  %t81 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !27
  %t83 = getelementptr %"compiler/check:nullNarrow", ptr %t82, i64 %t73
  %t84 = load %"compiler/check:nullNarrow", ptr %t83
  store %"compiler/check:nullNarrow" %t84, ptr %l50
  br label %bb17
bb17:
  %t85 = load i64, ptr %l8, !tbaa !24
  %t87 = add i64 %t85, 1
  store i64 %t87, ptr %l8, !tbaa !24
  br label %bb13
bb18:
  %t89 = load ptr, ptr %l2, !tbaa !29
  %t90 = load i64, ptr %l3, !tbaa !24
  %t93 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t89, i32 0, i32 1
  store i64 %t90, ptr %t93, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aroArg_3e_2ePush_3ccompiler_2fcheck_3aroArg_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/check:roArg" %a1) #0 {
entry:
  %l1 = alloca %"compiler/check:roArg"
  %l2 = alloca ptr
  %l17 = alloca { i64, ptr }
  %l21 = alloca ptr
  store %"compiler/check:roArg" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t6, i32 0, i32 1
  %t9 = load i64, ptr %t8, !tbaa !24
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t18 = icmp eq i64 %t9, %t15
  br i1 %t18, label %bb1, label %bb2
bb1:
  %t20 = load ptr, ptr %l2, !tbaa !29
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 1
  %t24 = load i64, ptr %t23, !tbaa !24
  %t26 = add i64 %t24, 1
  %t27 = load %"compiler/check:roArg", ptr %l1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3ccompiler_2fcheck_3aroArg_3e_2eroom_3ccompiler_2fcheck_3aroArg_3e(ptr %v0, ptr %v1, ptr %t20, i64 %t26, %"compiler/check:roArg" %t27)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t31 = load ptr, ptr %l2, !tbaa !29
  %t33 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t31, i32 0, i32 0
  %t34 = load { i64, ptr }, ptr %t33, !tbaa !27
  store { i64, ptr } %t34, ptr %l17, !tbaa !27
  %t35 = load ptr, ptr %l2, !tbaa !29
  %t37 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t35, i32 0, i32 1
  %t38 = load i64, ptr %t37, !tbaa !24
  %t39 = load %"compiler/check:roArg", ptr %l1
  %t42 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = getelementptr %"compiler/check:roArg", ptr %t43, i64 %t38
  store %"compiler/check:roArg" %t39, ptr %t44
  %t45 = load ptr, ptr %l2, !tbaa !29
  store ptr %t45, ptr %l21, !tbaa !29
  %t46 = load ptr, ptr %l21, !tbaa !29
  %t47 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t46, i32 0, i32 1
  %t48 = load i64, ptr %t47, !tbaa !24
  %t50 = add i64 %t48, 1
  %t52 = load ptr, ptr %l21, !tbaa !29
  %t53 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t52, i32 0, i32 1
  store i64 %t50, ptr %t53, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aroDeepArg_3e_2eLen__H5c673d8ec2e4412819235760f9452f00(ptr %v0, ptr %a0) #0 {
entry:
  %r = tail call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %v0, ptr %a0)
  ret i64 %r
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aroDeepArg_3e_2ePush_H0e30e0389c54f9bfc05db61d637e277e(ptr %v0, ptr %v1, ptr %a0, %"compiler/check:roDeepArg" %a1) #0 {
entry:
  %l1 = alloca %"compiler/check:roDeepArg"
  %l2 = alloca ptr
  %l17 = alloca { i64, ptr }
  %l21 = alloca ptr
  store %"compiler/check:roDeepArg" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t6, i32 0, i32 1
  %t9 = load i64, ptr %t8, !tbaa !24
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t18 = icmp eq i64 %t9, %t15
  br i1 %t18, label %bb1, label %bb2
bb1:
  %t20 = load ptr, ptr %l2, !tbaa !29
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 1
  %t24 = load i64, ptr %t23, !tbaa !24
  %t26 = add i64 %t24, 1
  %t27 = load %"compiler/check:roDeepArg", ptr %l1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3ccompiler_2fcheck_3aroDeepArg_3e_2_H5df4af53cb0aa34927c4096ccb4f71f7(ptr %v0, ptr %v1, ptr %t20, i64 %t26, %"compiler/check:roDeepArg" %t27)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t31 = load ptr, ptr %l2, !tbaa !29
  %t33 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t31, i32 0, i32 0
  %t34 = load { i64, ptr }, ptr %t33, !tbaa !27
  store { i64, ptr } %t34, ptr %l17, !tbaa !27
  %t35 = load ptr, ptr %l2, !tbaa !29
  %t37 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t35, i32 0, i32 1
  %t38 = load i64, ptr %t37, !tbaa !24
  %t39 = load %"compiler/check:roDeepArg", ptr %l1
  %t42 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = getelementptr %"compiler/check:roDeepArg", ptr %t43, i64 %t38
  store %"compiler/check:roDeepArg" %t39, ptr %t44
  %t45 = load ptr, ptr %l2, !tbaa !29
  store ptr %t45, ptr %l21, !tbaa !29
  %t46 = load ptr, ptr %l21, !tbaa !29
  %t47 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t46, i32 0, i32 1
  %t48 = load i64, ptr %t47, !tbaa !24
  %t50 = add i64 %t48, 1
  %t52 = load ptr, ptr %l21, !tbaa !29
  %t53 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t52, i32 0, i32 1
  store i64 %t50, ptr %t53, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aroFn_3e_2ePush_3ccompiler_2fcheck_3aroFn_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/check:roFn" %a1) #0 {
entry:
  %l1 = alloca %"compiler/check:roFn"
  %l2 = alloca ptr
  %l17 = alloca { i64, ptr }
  %l21 = alloca ptr
  store %"compiler/check:roFn" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t6, i32 0, i32 1
  %t9 = load i64, ptr %t8, !tbaa !24
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t18 = icmp eq i64 %t9, %t15
  br i1 %t18, label %bb1, label %bb2
bb1:
  %t20 = load ptr, ptr %l2, !tbaa !29
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 1
  %t24 = load i64, ptr %t23, !tbaa !24
  %t26 = add i64 %t24, 1
  %t27 = load %"compiler/check:roFn", ptr %l1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3ccompiler_2fcheck_3aroFn_3e_2eroom_3ccompiler_2fcheck_3aroFn_3e(ptr %v0, ptr %v1, ptr %t20, i64 %t26, %"compiler/check:roFn" %t27)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t31 = load ptr, ptr %l2, !tbaa !29
  %t33 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t31, i32 0, i32 0
  %t34 = load { i64, ptr }, ptr %t33, !tbaa !27
  store { i64, ptr } %t34, ptr %l17, !tbaa !27
  %t35 = load ptr, ptr %l2, !tbaa !29
  %t37 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t35, i32 0, i32 1
  %t38 = load i64, ptr %t37, !tbaa !24
  %t39 = load %"compiler/check:roFn", ptr %l1
  %t42 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = getelementptr %"compiler/check:roFn", ptr %t43, i64 %t38
  store %"compiler/check:roFn" %t39, ptr %t44
  %t45 = load ptr, ptr %l2, !tbaa !29
  store ptr %t45, ptr %l21, !tbaa !29
  %t46 = load ptr, ptr %l21, !tbaa !29
  %t47 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t46, i32 0, i32 1
  %t48 = load i64, ptr %t47, !tbaa !24
  %t50 = add i64 %t48, 1
  %t52 = load ptr, ptr %l21, !tbaa !29
  %t53 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t52, i32 0, i32 1
  store i64 %t50, ptr %t53, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3atypeCase_3e_2ePush_3ccompiler_2fcheck_3atypeCase_3e(ptr %v0, ptr %a0, %"compiler/check:typeCase" %a1) #0 {
entry:
  %l1 = alloca %"compiler/check:typeCase"
  %l2 = alloca ptr
  %l17 = alloca { i64, ptr }
  %l21 = alloca ptr
  store %"compiler/check:typeCase" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t6, i32 0, i32 1
  %t9 = load i64, ptr %t8, !tbaa !24
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t18 = icmp eq i64 %t9, %t15
  br i1 %t18, label %bb1, label %bb2
bb1:
  %t20 = load ptr, ptr %l2, !tbaa !29
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 1
  %t24 = load i64, ptr %t23, !tbaa !24
  %t26 = add i64 %t24, 1
  %t27 = load %"compiler/check:typeCase", ptr %l1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3ccompiler_2fcheck_3atypeCase_3e_2e_Ha8f88e37efd08b8919887513d3af4e23(ptr %v0, ptr %t20, i64 %t26, %"compiler/check:typeCase" %t27)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t31 = load ptr, ptr %l2, !tbaa !29
  %t33 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t31, i32 0, i32 0
  %t34 = load { i64, ptr }, ptr %t33, !tbaa !27
  store { i64, ptr } %t34, ptr %l17, !tbaa !27
  %t35 = load ptr, ptr %l2, !tbaa !29
  %t37 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t35, i32 0, i32 1
  %t38 = load i64, ptr %t37, !tbaa !24
  %t39 = load %"compiler/check:typeCase", ptr %l1
  %t42 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = getelementptr %"compiler/check:typeCase", ptr %t43, i64 %t38
  store %"compiler/check:typeCase" %t39, ptr %t44
  %t45 = load ptr, ptr %l2, !tbaa !29
  store ptr %t45, ptr %l21, !tbaa !29
  %t46 = load ptr, ptr %l21, !tbaa !29
  %t47 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t46, i32 0, i32 1
  %t48 = load i64, ptr %t47, !tbaa !24
  %t50 = add i64 %t48, 1
  %t52 = load ptr, ptr %l21, !tbaa !29
  %t53 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t52, i32 0, i32 1
  store i64 %t50, ptr %t53, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aAlt_26_3e_2ePush_3ccompiler_2ftyped_3aAlt_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  tail call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcond_3aGlobal_26_3e_2ePush_3ccompiler_2fcond_3aGlobal_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
  ret void
}

define dso_local { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aAlt_26_3e_2eToArray_3ccompiler_2ftyped_3aAlt_26_3e(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %r = tail call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aCaseDecl_26_3e_2eToAr_H44f8de0685d71649bf169c234c7a8f4c(ptr %v0, ptr %v1, ptr %a0)
  ret { i64, ptr } %r
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aArm_26_3e_2ePush_3ccompiler_2ftyped_3aArm_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  tail call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcond_3aGlobal_26_3e_2ePush_3ccompiler_2fcond_3aGlobal_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
  ret void
}

define dso_local { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aArm_26_3e_2eToArray_3ccompiler_2ftyped_3aArm_26_3e(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %r = tail call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aCaseDecl_26_3e_2eToAr_H44f8de0685d71649bf169c234c7a8f4c(ptr %v0, ptr %v1, ptr %a0)
  ret { i64, ptr } %r
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBind_26_3e_2ePush_3ccompiler_2ftyped_3aBind_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  tail call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcond_3aGlobal_26_3e_2ePush_3ccompiler_2fcond_3aGlobal_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aCapture_26_3e_2ePus_Hdab9bd3c8945274d6e7197d4fb29356b(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  tail call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcond_3aGlobal_26_3e_2ePush_3ccompiler_2fcond_3aGlobal_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
  ret void
}

define dso_local i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aClause_26_3e_2eLen__H4e51b5ca7b68af485b8486164a690a5f(ptr %v0, ptr %a0) #0 {
entry:
  %r = tail call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %v0, ptr %a0)
  ret i64 %r
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aClause_26_3e_2ePush_Hc64f4d0e64077a33423ff9c4e583894f(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  tail call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcond_3aGlobal_26_3e_2ePush_3ccompiler_2fcond_3aGlobal_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
  ret void
}

define dso_local { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eToArra_H50cbff9caa8a2389caf3e92da7e24507(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %r = tail call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aCaseDecl_26_3e_2eToAr_H44f8de0685d71649bf169c234c7a8f4c(ptr %v0, ptr %v1, ptr %a0)
  ret { i64, ptr } %r
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eTrunca_Hdac151ce4e73ec212dc55b02b0b7e7d0(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  tail call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aDecl_26_3e_2eTruncate_3ccompiler_2fast_3aDecl_26_3e(ptr %v0, ptr %a0, i64 %a1)
  ret void
}

define dso_local { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aItem_3e_2eToArray_3ccompiler_2ftyped_3aItem_3e(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l17 = alloca i64
  %l20 = alloca { i64, ptr }
  %l21 = alloca %"compiler/typed:Item"
  %l31 = alloca i64
  %l34 = alloca i64
  %l52 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  %t48 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t4, i32 0, i32 1
  %t7 = load i64, ptr %t6, !tbaa !24
  %t9 = icmp eq i64 %t7, 0
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = icmp sge i64 0, 0
  br i1 %t11, label %bb3, label %bb4
bb2:
  br label %bb7
bb3:
  %t13 = icmp sle i64 0, 576460752303423487
  br i1 %t13, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_aa901beb98c060b_80101196ceb80547)
  unreachable
bb5:
  %t15 = mul i64 0, 16
  %t16 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t15)
  %t17 = insertvalue { i64, ptr } undef, i64 0, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  store { i64, ptr } %t18, ptr %rv
  br label %ret
bb6:
  call void @__olang_check_failed(ptr @olang_loc_aa901beb98c060b_80101196ceb80547)
  unreachable
bb7:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t20, i32 0, i32 0
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t25 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t23, i32 0, i32 1
  %t26 = load i64, ptr %t25, !tbaa !24
  store i64 %t26, ptr %l17, !tbaa !24
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t27, i32 0, i32 0
  %t30 = load ptr, ptr %t29, !tbaa !29
  %t32 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t30, i32 0, i32 0
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !27
  store { i64, ptr } %t33, ptr %l20, !tbaa !27
  %t34 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !27
  %t36 = getelementptr %"compiler/typed:Item", ptr %t35, i64 0
  %t37 = load %"compiler/typed:Item", ptr %t36
  store %"compiler/typed:Item" %t37, ptr %l21
  %t38 = load i64, ptr %l17, !tbaa !24
  %t39 = icmp sge i64 %t38, 0
  br i1 %t39, label %bb8, label %bb9
bb8:
  %t41 = load i64, ptr %l17, !tbaa !24
  %t42 = icmp sle i64 %t41, 576460752303423487
  br i1 %t42, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_f2d634f02e5f6b76_33cef94e1615a252)
  unreachable
bb10:
  %t44 = load i64, ptr %l17, !tbaa !24
  %t45 = mul i64 %t44, 16
  %t46 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t45)
  %t47 = load %"compiler/typed:Item", ptr %l21
  store i64 0, ptr %t48
  br label %fill.49
fill.49:
  %t52 = load i64, ptr %t48
  %t53 = icmp slt i64 %t52, %t44
  br i1 %t53, label %fillb.50, label %filld.51
fillb.50:
  %t54 = getelementptr %"compiler/typed:Item", ptr %t46, i64 %t52
  store %"compiler/typed:Item" %t47, ptr %t54
  %t55 = add i64 %t52, 1
  store i64 %t55, ptr %t48
  br label %fill.49
filld.51:
  %t56 = insertvalue { i64, ptr } undef, i64 %t44, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t46, 1
  store { i64, ptr } %t57, ptr %l1, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t59, i32 0, i32 0
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t62, i32 0, i32 1
  %t65 = load i64, ptr %t64, !tbaa !24
  store i64 %t65, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t67 = load i64, ptr %l3, !tbaa !24
  %t68 = load i64, ptr %l2, !tbaa !24
  %t71 = icmp sgt i64 %t67, %t68
  br i1 %t71, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_f2d634f02e5f6b76_33cef94e1615a252)
  unreachable
bb12:
  %t73 = load i64, ptr %l4, !tbaa !24
  %t75 = icmp sgt i64 %t73, 0
  br i1 %t75, label %bb14, label %bb15
bb13:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb17
bb14:
  %t77 = load i64, ptr %l3, !tbaa !24
  %t78 = load i64, ptr %l2, !tbaa !24
  %t81 = sub i64 %t77, %t78
  %t82 = load i64, ptr %l4, !tbaa !24
  %t85 = add i64 %t81, %t82
  %t87 = sub i64 %t85, 1
  %t88 = load i64, ptr %l4, !tbaa !24
  %t91 = sdiv i64 %t87, %t88
  store i64 %t91, ptr %l34, !tbaa !24
  br label %bb16
bb15:
  store i64 0, ptr %l34, !tbaa !24
  br label %bb16
bb16:
  %t93 = load i64, ptr %l34, !tbaa !24
  store i64 %t93, ptr %l31, !tbaa !24
  br label %bb17
bb17:
  %t94 = load i64, ptr %l31, !tbaa !24
  store i64 %t94, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb18
bb18:
  %t95 = load i64, ptr %l6, !tbaa !24
  %t96 = load i64, ptr %l5, !tbaa !24
  %t99 = icmp slt i64 %t95, %t96
  %t101 = xor i1 %t99, true
  br i1 %t101, label %bb19, label %bb20
bb19:
  br label %bb23
bb20:
  br label %bb21
bb21:
  %t103 = load i64, ptr %l2, !tbaa !24
  %t104 = load i64, ptr %l6, !tbaa !24
  %t105 = load i64, ptr %l4, !tbaa !24
  %t108 = mul i64 %t104, %t105
  %t111 = add i64 %t103, %t108
  store i64 %t111, ptr %l7, !tbaa !24
  %t113 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t113, ptr %l52, !tbaa !27
  %t114 = load i64, ptr %l7, !tbaa !24
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t115, i32 0, i32 0
  %t118 = load ptr, ptr %t117, !tbaa !29
  %t120 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t118, i32 0, i32 0
  %t121 = load { i64, ptr }, ptr %t120, !tbaa !27
  store { i64, ptr } %t121, ptr %l56, !tbaa !27
  %t122 = load i64, ptr %l7, !tbaa !24
  %t124 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !27
  %t126 = getelementptr %"compiler/typed:Item", ptr %t125, i64 %t122
  %t127 = load %"compiler/typed:Item", ptr %t126
  %t130 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !27
  %t132 = getelementptr %"compiler/typed:Item", ptr %t131, i64 %t114
  store %"compiler/typed:Item" %t127, ptr %t132
  br label %bb22
bb22:
  %t133 = load i64, ptr %l6, !tbaa !24
  %t135 = add i64 %t133, 1
  store i64 %t135, ptr %l6, !tbaa !24
  br label %bb18
bb23:
  %t137 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t137, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPiece_26_3e_2ePush_3ccompiler_2ftyped_3aPiece_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  tail call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcond_3aGlobal_26_3e_2ePush_3ccompiler_2fcond_3aGlobal_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeRel_3e_2ePush_3ccompiler_2ftyped_3aScopeRel_3e(ptr %v0, ptr %a0, %"compiler/typed:ScopeRel" %a1) #0 {
entry:
  %l1 = alloca %"compiler/typed:ScopeRel"
  %l2 = alloca ptr
  %l17 = alloca { i64, ptr }
  %l21 = alloca ptr
  store %"compiler/typed:ScopeRel" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t6, i32 0, i32 1
  %t9 = load i64, ptr %t8, !tbaa !24
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t18 = icmp eq i64 %t9, %t15
  br i1 %t18, label %bb1, label %bb2
bb1:
  %t20 = load ptr, ptr %l2, !tbaa !29
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 1
  %t24 = load i64, ptr %t23, !tbaa !24
  %t26 = add i64 %t24, 1
  %t27 = load %"compiler/typed:ScopeRel", ptr %l1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3ccompiler_2ftyped_3aScopeRel_3e_2e_H7acc14a50db40391aeef5484b26a9f8b(ptr %v0, ptr %t20, i64 %t26, %"compiler/typed:ScopeRel" %t27)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t31 = load ptr, ptr %l2, !tbaa !29
  %t33 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t31, i32 0, i32 0
  %t34 = load { i64, ptr }, ptr %t33, !tbaa !27
  store { i64, ptr } %t34, ptr %l17, !tbaa !27
  %t35 = load ptr, ptr %l2, !tbaa !29
  %t37 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t35, i32 0, i32 1
  %t38 = load i64, ptr %t37, !tbaa !24
  %t39 = load %"compiler/typed:ScopeRel", ptr %l1
  %t42 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = getelementptr %"compiler/typed:ScopeRel", ptr %t43, i64 %t38
  store %"compiler/typed:ScopeRel" %t39, ptr %t44
  %t45 = load ptr, ptr %l2, !tbaa !29
  store ptr %t45, ptr %l21, !tbaa !29
  %t46 = load ptr, ptr %l21, !tbaa !29
  %t47 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t46, i32 0, i32 1
  %t48 = load i64, ptr %t47, !tbaa !24
  %t50 = add i64 %t48, 1
  %t52 = load ptr, ptr %l21, !tbaa !29
  %t53 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t52, i32 0, i32 1
  store i64 %t50, ptr %t53, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeRel_3e_2eTrunc_H1d2610c981f12e3f9d35f7bb8d26f2fc(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l18 = alloca i64
  %l26 = alloca i64
  %l29 = alloca i64
  %l48 = alloca { i64, ptr }
  %l50 = alloca %"compiler/typed:ScopeRel"
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load i64, ptr %l1, !tbaa !24
  %t7 = load ptr, ptr %l2, !tbaa !29
  %t9 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t7, i32 0, i32 1
  %t10 = load i64, ptr %t9, !tbaa !24
  %t13 = icmp sge i64 %t6, %t10
  br i1 %t13, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t15 = load i64, ptr %l1, !tbaa !24
  %t17 = icmp sgt i64 %t15, 0
  br i1 %t17, label %bb4, label %bb5
bb4:
  %t19 = load i64, ptr %l1, !tbaa !24
  store i64 %t19, ptr %l18, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l18, !tbaa !24
  br label %bb6
bb6:
  %t21 = load i64, ptr %l18, !tbaa !24
  store i64 %t21, ptr %l3, !tbaa !24
  %t22 = load i64, ptr %l3, !tbaa !24
  store i64 %t22, ptr %l4, !tbaa !24
  %t24 = load ptr, ptr %l2, !tbaa !29
  %t26 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t24, i32 0, i32 1
  %t27 = load i64, ptr %t26, !tbaa !24
  store i64 %t27, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t29 = load i64, ptr %l5, !tbaa !24
  %t30 = load i64, ptr %l4, !tbaa !24
  %t33 = icmp sgt i64 %t29, %t30
  br i1 %t33, label %bb7, label %bb8
bb7:
  %t35 = load i64, ptr %l6, !tbaa !24
  %t37 = icmp sgt i64 %t35, 0
  br i1 %t37, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l26, !tbaa !24
  br label %bb12
bb9:
  %t39 = load i64, ptr %l5, !tbaa !24
  %t40 = load i64, ptr %l4, !tbaa !24
  %t43 = sub i64 %t39, %t40
  %t44 = load i64, ptr %l6, !tbaa !24
  %t47 = add i64 %t43, %t44
  %t49 = sub i64 %t47, 1
  %t50 = load i64, ptr %l6, !tbaa !24
  %t53 = sdiv i64 %t49, %t50
  store i64 %t53, ptr %l29, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l29, !tbaa !24
  br label %bb11
bb11:
  %t55 = load i64, ptr %l29, !tbaa !24
  store i64 %t55, ptr %l26, !tbaa !24
  br label %bb12
bb12:
  %t56 = load i64, ptr %l26, !tbaa !24
  store i64 %t56, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb13
bb13:
  %t57 = load i64, ptr %l8, !tbaa !24
  %t58 = load i64, ptr %l7, !tbaa !24
  %t61 = icmp slt i64 %t57, %t58
  %t63 = xor i1 %t61, true
  br i1 %t63, label %bb14, label %bb15
bb14:
  br label %bb18
bb15:
  br label %bb16
bb16:
  %t65 = load i64, ptr %l4, !tbaa !24
  %t66 = load i64, ptr %l8, !tbaa !24
  %t67 = load i64, ptr %l6, !tbaa !24
  %t70 = mul i64 %t66, %t67
  %t73 = add i64 %t65, %t70
  %t75 = load ptr, ptr %l2, !tbaa !29
  %t77 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t75, i32 0, i32 0
  %t78 = load { i64, ptr }, ptr %t77, !tbaa !27
  store { i64, ptr } %t78, ptr %l48, !tbaa !27
  %t81 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !27
  %t83 = getelementptr %"compiler/typed:ScopeRel", ptr %t82, i64 %t73
  %t84 = load %"compiler/typed:ScopeRel", ptr %t83
  store %"compiler/typed:ScopeRel" %t84, ptr %l50
  br label %bb17
bb17:
  %t85 = load i64, ptr %l8, !tbaa !24
  %t87 = add i64 %t85, 1
  store i64 %t87, ptr %l8, !tbaa !24
  br label %bb13
bb18:
  %t89 = load ptr, ptr %l2, !tbaa !29
  %t90 = load i64, ptr %l3, !tbaa !24
  %t93 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t89, i32 0, i32 1
  store i64 %t90, ptr %t93, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  tail call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcond_3aGlobal_26_3e_2ePush_3ccompiler_2fcond_3aGlobal_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aTaskClause_26_3e_2e_H70975c58788d810dba7712b4ee87a08c(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  tail call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcond_3aGlobal_26_3e_2ePush_3ccompiler_2fcond_3aGlobal_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
  ret void
}

define dso_local { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aTaskClause_26_3e_2e_H788addc5d4e2ce71c84413f6a2c1cfed(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %r = tail call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aCaseDecl_26_3e_2eToAr_H44f8de0685d71649bf169c234c7a8f4c(ptr %v0, ptr %v1, ptr %a0)
  ret { i64, ptr } %r
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eTruncate_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  tail call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eTrunca_H0175749ab7aa0aad23a4aa22bc447819(ptr %v0, ptr %a0, i64 %a1)
  ret void
}

define dso_local i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_H2251bc8fca359ca0394d0bb11af7ba0a(ptr %v0, ptr %a0) #0 {
entry:
  %r = tail call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %v0, ptr %a0)
  ret i64 %r
}

define dso_local i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_3e_Hda4ef06466535e66801340e999dad217(ptr %v0, ptr %a0) #0 {
entry:
  %r = tail call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %v0, ptr %a0)
  ret i64 %r
}

define dso_local %"std/pair:Pair.1eb2466213689e002f25e81e83536e78" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20compiler__H015c7298d54f1d140374736283ef15ae(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/pair:Pair.1eb2466213689e002f25e81e83536e78"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t4, i32 0, i32 0
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  store { i64, ptr } %t7, ptr %l4, !tbaa !27
  %t10 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !27
  %t12 = getelementptr %"std/pair:Pair.1eb2466213689e002f25e81e83536e78", ptr %t11, i64 %a1
  %t13 = load %"std/pair:Pair.1eb2466213689e002f25e81e83536e78", ptr %t12
  store %"std/pair:Pair.1eb2466213689e002f25e81e83536e78" %t13, ptr %rv
  br label %ret
ret:
  %rr = load %"std/pair:Pair.1eb2466213689e002f25e81e83536e78", ptr %rv
  ret %"std/pair:Pair.1eb2466213689e002f25e81e83536e78" %rr
}

define dso_local %"std/pair:Pair.0eea5a06f8f0107e600fd23235f2e98f" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fgeneric_Hb10eca62c04bf212a25728cfc6f83c9c(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/pair:Pair.0eea5a06f8f0107e600fd23235f2e98f"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t4, i32 0, i32 0
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  store { i64, ptr } %t7, ptr %l4, !tbaa !27
  %t10 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !27
  %t12 = getelementptr %"std/pair:Pair.0eea5a06f8f0107e600fd23235f2e98f", ptr %t11, i64 %a1
  %t13 = load %"std/pair:Pair.0eea5a06f8f0107e600fd23235f2e98f", ptr %t12
  store %"std/pair:Pair.0eea5a06f8f0107e600fd23235f2e98f" %t13, ptr %rv
  br label %ret
ret:
  %rr = load %"std/pair:Pair.0eea5a06f8f0107e600fd23235f2e98f", ptr %rv
  ret %"std/pair:Pair.0eea5a06f8f0107e600fd23235f2e98f" %rr
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3ccompiler_2fcheck_3aAsk_3e_2eroom_3ccompiler_2fcheck_3aAsk_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/check:Ask" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l21 = alloca i64
  %l38 = alloca ptr
  %l39 = alloca i64
  %l40 = alloca %"compiler/check:Ask"
  %l51 = alloca i64
  %l54 = alloca i64
  %l72 = alloca { i64, ptr }
  %l74 = alloca { i64, ptr }
  %t71 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t2, i32 0, i32 0
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t10 = icmp sle i64 %t1, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t19 = icmp slt i64 %t17, 4
  br i1 %t19, label %bb4, label %bb5
bb4:
  store i64 8, ptr %l21, !tbaa !24
  br label %bb6
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t28 = mul i64 %t26, 2
  store i64 %t28, ptr %l21, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l21, !tbaa !24
  store i64 %t30, ptr %l3, !tbaa !24
  %t31 = load i64, ptr %l3, !tbaa !24
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  br i1 %t35, label %bb7, label %bb8
bb7:
  %t37 = load i64, ptr %l1, !tbaa !24
  store i64 %t37, ptr %l3, !tbaa !24
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t39 = load i64, ptr %l3, !tbaa !24
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t40, i32 0, i32 2
  %t43 = load i64, ptr %t42, !tbaa !24
  %t46 = icmp slt i64 %t39, %t43
  br i1 %t46, label %bb10, label %bb11
bb10:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t48, i32 0, i32 2
  %t51 = load i64, ptr %t50, !tbaa !24
  store i64 %t51, ptr %l3, !tbaa !24
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t53, i32 0, i32 0
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  store { i64, ptr } %t56, ptr %l4, !tbaa !27
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l38, !tbaa !29
  %t59 = load i64, ptr %l3, !tbaa !24
  store i64 %t59, ptr %l39, !tbaa !24
  store %"compiler/check:Ask" %a2, ptr %l40
  %t61 = load i64, ptr %l39, !tbaa !24
  %t62 = icmp sge i64 %t61, 0
  br i1 %t62, label %bb13, label %bb14
bb13:
  %t64 = load i64, ptr %l39, !tbaa !24
  %t65 = icmp sle i64 %t64, 164703072086692425
  br i1 %t65, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_530ba18c40bfa485_9e285f876d3dfc21)
  unreachable
bb15:
  %t67 = load i64, ptr %l39, !tbaa !24
  %t68 = mul i64 %t67, 56
  %t69 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t68)
  %t70 = load %"compiler/check:Ask", ptr %l40
  store i64 0, ptr %t71
  br label %fill.72
fill.72:
  %t75 = load i64, ptr %t71
  %t76 = icmp slt i64 %t75, %t67
  br i1 %t76, label %fillb.73, label %filld.74
fillb.73:
  %t77 = getelementptr %"compiler/check:Ask", ptr %t69, i64 %t75
  store %"compiler/check:Ask" %t70, ptr %t77
  %t78 = add i64 %t75, 1
  store i64 %t78, ptr %t71
  br label %fill.72
filld.74:
  %t79 = insertvalue { i64, ptr } undef, i64 %t67, 0
  %t80 = insertvalue { i64, ptr } %t79, ptr %t69, 1
  %t82 = load ptr, ptr %l38, !tbaa !29
  %t83 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t82, i32 0, i32 0
  store { i64, ptr } %t80, ptr %t83, !tbaa !27
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t84, i32 0, i32 0
  %t87 = load { i64, ptr }, ptr %t86, !tbaa !27
  store { i64, ptr } %t87, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t89, i32 0, i32 1
  %t92 = load i64, ptr %t91, !tbaa !24
  store i64 %t92, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t94 = load i64, ptr %l7, !tbaa !24
  %t95 = load i64, ptr %l6, !tbaa !24
  %t98 = icmp sgt i64 %t94, %t95
  br i1 %t98, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_530ba18c40bfa485_9e285f876d3dfc21)
  unreachable
bb17:
  %t100 = load i64, ptr %l8, !tbaa !24
  %t102 = icmp sgt i64 %t100, 0
  br i1 %t102, label %bb19, label %bb20
bb18:
  store i64 0, ptr %l51, !tbaa !24
  br label %bb22
bb19:
  %t104 = load i64, ptr %l7, !tbaa !24
  %t105 = load i64, ptr %l6, !tbaa !24
  %t108 = sub i64 %t104, %t105
  %t109 = load i64, ptr %l8, !tbaa !24
  %t112 = add i64 %t108, %t109
  %t114 = sub i64 %t112, 1
  %t115 = load i64, ptr %l8, !tbaa !24
  %t118 = sdiv i64 %t114, %t115
  store i64 %t118, ptr %l54, !tbaa !24
  br label %bb21
bb20:
  store i64 0, ptr %l54, !tbaa !24
  br label %bb21
bb21:
  %t120 = load i64, ptr %l54, !tbaa !24
  store i64 %t120, ptr %l51, !tbaa !24
  br label %bb22
bb22:
  %t121 = load i64, ptr %l51, !tbaa !24
  store i64 %t121, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb23
bb23:
  %t122 = load i64, ptr %l10, !tbaa !24
  %t123 = load i64, ptr %l9, !tbaa !24
  %t126 = icmp slt i64 %t122, %t123
  %t128 = xor i1 %t126, true
  br i1 %t128, label %bb24, label %bb25
bb24:
  br label %bb28
bb25:
  br label %bb26
bb26:
  %t130 = load i64, ptr %l6, !tbaa !24
  %t131 = load i64, ptr %l10, !tbaa !24
  %t132 = load i64, ptr %l8, !tbaa !24
  %t135 = mul i64 %t131, %t132
  %t138 = add i64 %t130, %t135
  store i64 %t138, ptr %l11, !tbaa !24
  %t140 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t140, ptr %l72, !tbaa !27
  %t141 = load i64, ptr %l11, !tbaa !24
  %t142 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t142, ptr %l74, !tbaa !27
  %t143 = load i64, ptr %l11, !tbaa !24
  %t145 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !27
  %t147 = getelementptr %"compiler/check:Ask", ptr %t146, i64 %t143
  %t148 = load %"compiler/check:Ask", ptr %t147
  %t151 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t152 = load ptr, ptr %t151, !tbaa !27
  %t153 = getelementptr %"compiler/check:Ask", ptr %t152, i64 %t141
  store %"compiler/check:Ask" %t148, ptr %t153
  br label %bb27
bb27:
  %t154 = load i64, ptr %l10, !tbaa !24
  %t156 = add i64 %t154, 1
  store i64 %t156, ptr %l10, !tbaa !24
  br label %bb23
bb28:
  %t158 = load { i64, ptr }, ptr %l4, !tbaa !27
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3ccompiler_2fcheck_3aEmbedAsk_3e_2e_H0cd9db32fe9336edcb7610499450d519(ptr %v0, ptr %a0, i64 %a1, %"compiler/check:EmbedAsk" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l21 = alloca i64
  %l38 = alloca ptr
  %l39 = alloca i64
  %l40 = alloca %"compiler/check:EmbedAsk"
  %l51 = alloca i64
  %l54 = alloca i64
  %l72 = alloca { i64, ptr }
  %l74 = alloca { i64, ptr }
  %t71 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t2, i32 0, i32 0
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t10 = icmp sle i64 %t1, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t19 = icmp slt i64 %t17, 4
  br i1 %t19, label %bb4, label %bb5
bb4:
  store i64 8, ptr %l21, !tbaa !24
  br label %bb6
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t28 = mul i64 %t26, 2
  store i64 %t28, ptr %l21, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l21, !tbaa !24
  store i64 %t30, ptr %l3, !tbaa !24
  %t31 = load i64, ptr %l3, !tbaa !24
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  br i1 %t35, label %bb7, label %bb8
bb7:
  %t37 = load i64, ptr %l1, !tbaa !24
  store i64 %t37, ptr %l3, !tbaa !24
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t39 = load i64, ptr %l3, !tbaa !24
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t40, i32 0, i32 2
  %t43 = load i64, ptr %t42, !tbaa !24
  %t46 = icmp slt i64 %t39, %t43
  br i1 %t46, label %bb10, label %bb11
bb10:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t48, i32 0, i32 2
  %t51 = load i64, ptr %t50, !tbaa !24
  store i64 %t51, ptr %l3, !tbaa !24
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t53, i32 0, i32 0
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  store { i64, ptr } %t56, ptr %l4, !tbaa !27
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l38, !tbaa !29
  %t59 = load i64, ptr %l3, !tbaa !24
  store i64 %t59, ptr %l39, !tbaa !24
  store %"compiler/check:EmbedAsk" %a2, ptr %l40
  %t61 = load i64, ptr %l39, !tbaa !24
  %t62 = icmp sge i64 %t61, 0
  br i1 %t62, label %bb13, label %bb14
bb13:
  %t64 = load i64, ptr %l39, !tbaa !24
  %t65 = icmp sle i64 %t64, 384307168202282325
  br i1 %t65, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_e21453debf04748b_2a156cb95fbac447)
  unreachable
bb15:
  %t67 = load i64, ptr %l39, !tbaa !24
  %t68 = mul i64 %t67, 24
  %t69 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t68)
  %t70 = load %"compiler/check:EmbedAsk", ptr %l40
  store i64 0, ptr %t71
  br label %fill.72
fill.72:
  %t75 = load i64, ptr %t71
  %t76 = icmp slt i64 %t75, %t67
  br i1 %t76, label %fillb.73, label %filld.74
fillb.73:
  %t77 = getelementptr %"compiler/check:EmbedAsk", ptr %t69, i64 %t75
  store %"compiler/check:EmbedAsk" %t70, ptr %t77
  %t78 = add i64 %t75, 1
  store i64 %t78, ptr %t71
  br label %fill.72
filld.74:
  %t79 = insertvalue { i64, ptr } undef, i64 %t67, 0
  %t80 = insertvalue { i64, ptr } %t79, ptr %t69, 1
  %t82 = load ptr, ptr %l38, !tbaa !29
  %t83 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t82, i32 0, i32 0
  store { i64, ptr } %t80, ptr %t83, !tbaa !27
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t84, i32 0, i32 0
  %t87 = load { i64, ptr }, ptr %t86, !tbaa !27
  store { i64, ptr } %t87, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t89, i32 0, i32 1
  %t92 = load i64, ptr %t91, !tbaa !24
  store i64 %t92, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t94 = load i64, ptr %l7, !tbaa !24
  %t95 = load i64, ptr %l6, !tbaa !24
  %t98 = icmp sgt i64 %t94, %t95
  br i1 %t98, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_e21453debf04748b_2a156cb95fbac447)
  unreachable
bb17:
  %t100 = load i64, ptr %l8, !tbaa !24
  %t102 = icmp sgt i64 %t100, 0
  br i1 %t102, label %bb19, label %bb20
bb18:
  store i64 0, ptr %l51, !tbaa !24
  br label %bb22
bb19:
  %t104 = load i64, ptr %l7, !tbaa !24
  %t105 = load i64, ptr %l6, !tbaa !24
  %t108 = sub i64 %t104, %t105
  %t109 = load i64, ptr %l8, !tbaa !24
  %t112 = add i64 %t108, %t109
  %t114 = sub i64 %t112, 1
  %t115 = load i64, ptr %l8, !tbaa !24
  %t118 = sdiv i64 %t114, %t115
  store i64 %t118, ptr %l54, !tbaa !24
  br label %bb21
bb20:
  store i64 0, ptr %l54, !tbaa !24
  br label %bb21
bb21:
  %t120 = load i64, ptr %l54, !tbaa !24
  store i64 %t120, ptr %l51, !tbaa !24
  br label %bb22
bb22:
  %t121 = load i64, ptr %l51, !tbaa !24
  store i64 %t121, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb23
bb23:
  %t122 = load i64, ptr %l10, !tbaa !24
  %t123 = load i64, ptr %l9, !tbaa !24
  %t126 = icmp slt i64 %t122, %t123
  %t128 = xor i1 %t126, true
  br i1 %t128, label %bb24, label %bb25
bb24:
  br label %bb28
bb25:
  br label %bb26
bb26:
  %t130 = load i64, ptr %l6, !tbaa !24
  %t131 = load i64, ptr %l10, !tbaa !24
  %t132 = load i64, ptr %l8, !tbaa !24
  %t135 = mul i64 %t131, %t132
  %t138 = add i64 %t130, %t135
  store i64 %t138, ptr %l11, !tbaa !24
  %t140 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t140, ptr %l72, !tbaa !27
  %t141 = load i64, ptr %l11, !tbaa !24
  %t142 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t142, ptr %l74, !tbaa !27
  %t143 = load i64, ptr %l11, !tbaa !24
  %t145 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !27
  %t147 = getelementptr %"compiler/check:EmbedAsk", ptr %t146, i64 %t143
  %t148 = load %"compiler/check:EmbedAsk", ptr %t147
  %t151 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t152 = load ptr, ptr %t151, !tbaa !27
  %t153 = getelementptr %"compiler/check:EmbedAsk", ptr %t152, i64 %t141
  store %"compiler/check:EmbedAsk" %t148, ptr %t153
  br label %bb27
bb27:
  %t154 = load i64, ptr %l10, !tbaa !24
  %t156 = add i64 %t154, 1
  store i64 %t156, ptr %l10, !tbaa !24
  br label %bb23
bb28:
  %t158 = load { i64, ptr }, ptr %l4, !tbaa !27
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3ccompiler_2fcheck_3aGap_3e_2eroom_3ccompiler_2fcheck_3aGap_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/check:Gap" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l21 = alloca i64
  %l38 = alloca ptr
  %l39 = alloca i64
  %l40 = alloca %"compiler/check:Gap"
  %l51 = alloca i64
  %l54 = alloca i64
  %l72 = alloca { i64, ptr }
  %l74 = alloca { i64, ptr }
  %t71 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t2, i32 0, i32 0
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t10 = icmp sle i64 %t1, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t19 = icmp slt i64 %t17, 4
  br i1 %t19, label %bb4, label %bb5
bb4:
  store i64 8, ptr %l21, !tbaa !24
  br label %bb6
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t28 = mul i64 %t26, 2
  store i64 %t28, ptr %l21, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l21, !tbaa !24
  store i64 %t30, ptr %l3, !tbaa !24
  %t31 = load i64, ptr %l3, !tbaa !24
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  br i1 %t35, label %bb7, label %bb8
bb7:
  %t37 = load i64, ptr %l1, !tbaa !24
  store i64 %t37, ptr %l3, !tbaa !24
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t39 = load i64, ptr %l3, !tbaa !24
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t40, i32 0, i32 2
  %t43 = load i64, ptr %t42, !tbaa !24
  %t46 = icmp slt i64 %t39, %t43
  br i1 %t46, label %bb10, label %bb11
bb10:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t48, i32 0, i32 2
  %t51 = load i64, ptr %t50, !tbaa !24
  store i64 %t51, ptr %l3, !tbaa !24
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t53, i32 0, i32 0
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  store { i64, ptr } %t56, ptr %l4, !tbaa !27
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l38, !tbaa !29
  %t59 = load i64, ptr %l3, !tbaa !24
  store i64 %t59, ptr %l39, !tbaa !24
  store %"compiler/check:Gap" %a2, ptr %l40
  %t61 = load i64, ptr %l39, !tbaa !24
  %t62 = icmp sge i64 %t61, 0
  br i1 %t62, label %bb13, label %bb14
bb13:
  %t64 = load i64, ptr %l39, !tbaa !24
  %t65 = icmp sle i64 %t64, 288230376151711743
  br i1 %t65, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_c2290bc0d93d8d47_960808febb9e8c03)
  unreachable
bb15:
  %t67 = load i64, ptr %l39, !tbaa !24
  %t68 = mul i64 %t67, 32
  %t69 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t68)
  %t70 = load %"compiler/check:Gap", ptr %l40
  store i64 0, ptr %t71
  br label %fill.72
fill.72:
  %t75 = load i64, ptr %t71
  %t76 = icmp slt i64 %t75, %t67
  br i1 %t76, label %fillb.73, label %filld.74
fillb.73:
  %t77 = getelementptr %"compiler/check:Gap", ptr %t69, i64 %t75
  store %"compiler/check:Gap" %t70, ptr %t77
  %t78 = add i64 %t75, 1
  store i64 %t78, ptr %t71
  br label %fill.72
filld.74:
  %t79 = insertvalue { i64, ptr } undef, i64 %t67, 0
  %t80 = insertvalue { i64, ptr } %t79, ptr %t69, 1
  %t82 = load ptr, ptr %l38, !tbaa !29
  %t83 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t82, i32 0, i32 0
  store { i64, ptr } %t80, ptr %t83, !tbaa !27
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t84, i32 0, i32 0
  %t87 = load { i64, ptr }, ptr %t86, !tbaa !27
  store { i64, ptr } %t87, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t89, i32 0, i32 1
  %t92 = load i64, ptr %t91, !tbaa !24
  store i64 %t92, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t94 = load i64, ptr %l7, !tbaa !24
  %t95 = load i64, ptr %l6, !tbaa !24
  %t98 = icmp sgt i64 %t94, %t95
  br i1 %t98, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_c2290bc0d93d8d47_960808febb9e8c03)
  unreachable
bb17:
  %t100 = load i64, ptr %l8, !tbaa !24
  %t102 = icmp sgt i64 %t100, 0
  br i1 %t102, label %bb19, label %bb20
bb18:
  store i64 0, ptr %l51, !tbaa !24
  br label %bb22
bb19:
  %t104 = load i64, ptr %l7, !tbaa !24
  %t105 = load i64, ptr %l6, !tbaa !24
  %t108 = sub i64 %t104, %t105
  %t109 = load i64, ptr %l8, !tbaa !24
  %t112 = add i64 %t108, %t109
  %t114 = sub i64 %t112, 1
  %t115 = load i64, ptr %l8, !tbaa !24
  %t118 = sdiv i64 %t114, %t115
  store i64 %t118, ptr %l54, !tbaa !24
  br label %bb21
bb20:
  store i64 0, ptr %l54, !tbaa !24
  br label %bb21
bb21:
  %t120 = load i64, ptr %l54, !tbaa !24
  store i64 %t120, ptr %l51, !tbaa !24
  br label %bb22
bb22:
  %t121 = load i64, ptr %l51, !tbaa !24
  store i64 %t121, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb23
bb23:
  %t122 = load i64, ptr %l10, !tbaa !24
  %t123 = load i64, ptr %l9, !tbaa !24
  %t126 = icmp slt i64 %t122, %t123
  %t128 = xor i1 %t126, true
  br i1 %t128, label %bb24, label %bb25
bb24:
  br label %bb28
bb25:
  br label %bb26
bb26:
  %t130 = load i64, ptr %l6, !tbaa !24
  %t131 = load i64, ptr %l10, !tbaa !24
  %t132 = load i64, ptr %l8, !tbaa !24
  %t135 = mul i64 %t131, %t132
  %t138 = add i64 %t130, %t135
  store i64 %t138, ptr %l11, !tbaa !24
  %t140 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t140, ptr %l72, !tbaa !27
  %t141 = load i64, ptr %l11, !tbaa !24
  %t142 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t142, ptr %l74, !tbaa !27
  %t143 = load i64, ptr %l11, !tbaa !24
  %t145 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !27
  %t147 = getelementptr %"compiler/check:Gap", ptr %t146, i64 %t143
  %t148 = load %"compiler/check:Gap", ptr %t147
  %t151 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t152 = load ptr, ptr %t151, !tbaa !27
  %t153 = getelementptr %"compiler/check:Gap", ptr %t152, i64 %t141
  store %"compiler/check:Gap" %t148, ptr %t153
  br label %bb27
bb27:
  %t154 = load i64, ptr %l10, !tbaa !24
  %t156 = add i64 %t154, 1
  store i64 %t156, ptr %l10, !tbaa !24
  br label %bb23
bb28:
  %t158 = load { i64, ptr }, ptr %l4, !tbaa !27
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3ccompiler_2fcheck_3aValueAsk_3e_2e_Hb56d90bd4965dfe5ab616ef1e71111a0(ptr %v0, ptr %a0, i64 %a1, %"compiler/check:ValueAsk" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l21 = alloca i64
  %l38 = alloca ptr
  %l39 = alloca i64
  %l40 = alloca %"compiler/check:ValueAsk"
  %l51 = alloca i64
  %l54 = alloca i64
  %l72 = alloca { i64, ptr }
  %l74 = alloca { i64, ptr }
  %t71 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t2, i32 0, i32 0
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t10 = icmp sle i64 %t1, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t19 = icmp slt i64 %t17, 4
  br i1 %t19, label %bb4, label %bb5
bb4:
  store i64 8, ptr %l21, !tbaa !24
  br label %bb6
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t28 = mul i64 %t26, 2
  store i64 %t28, ptr %l21, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l21, !tbaa !24
  store i64 %t30, ptr %l3, !tbaa !24
  %t31 = load i64, ptr %l3, !tbaa !24
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  br i1 %t35, label %bb7, label %bb8
bb7:
  %t37 = load i64, ptr %l1, !tbaa !24
  store i64 %t37, ptr %l3, !tbaa !24
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t39 = load i64, ptr %l3, !tbaa !24
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t40, i32 0, i32 2
  %t43 = load i64, ptr %t42, !tbaa !24
  %t46 = icmp slt i64 %t39, %t43
  br i1 %t46, label %bb10, label %bb11
bb10:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t48, i32 0, i32 2
  %t51 = load i64, ptr %t50, !tbaa !24
  store i64 %t51, ptr %l3, !tbaa !24
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t53, i32 0, i32 0
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  store { i64, ptr } %t56, ptr %l4, !tbaa !27
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l38, !tbaa !29
  %t59 = load i64, ptr %l3, !tbaa !24
  store i64 %t59, ptr %l39, !tbaa !24
  store %"compiler/check:ValueAsk" %a2, ptr %l40
  %t61 = load i64, ptr %l39, !tbaa !24
  %t62 = icmp sge i64 %t61, 0
  br i1 %t62, label %bb13, label %bb14
bb13:
  %t64 = load i64, ptr %l39, !tbaa !24
  %t65 = icmp sle i64 %t64, 128102389400760775
  br i1 %t65, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_115385e8fa9135f5_858b7c4a21055d9)
  unreachable
bb15:
  %t67 = load i64, ptr %l39, !tbaa !24
  %t68 = mul i64 %t67, 72
  %t69 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t68)
  %t70 = load %"compiler/check:ValueAsk", ptr %l40
  store i64 0, ptr %t71
  br label %fill.72
fill.72:
  %t75 = load i64, ptr %t71
  %t76 = icmp slt i64 %t75, %t67
  br i1 %t76, label %fillb.73, label %filld.74
fillb.73:
  %t77 = getelementptr %"compiler/check:ValueAsk", ptr %t69, i64 %t75
  store %"compiler/check:ValueAsk" %t70, ptr %t77
  %t78 = add i64 %t75, 1
  store i64 %t78, ptr %t71
  br label %fill.72
filld.74:
  %t79 = insertvalue { i64, ptr } undef, i64 %t67, 0
  %t80 = insertvalue { i64, ptr } %t79, ptr %t69, 1
  %t82 = load ptr, ptr %l38, !tbaa !29
  %t83 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t82, i32 0, i32 0
  store { i64, ptr } %t80, ptr %t83, !tbaa !27
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t84, i32 0, i32 0
  %t87 = load { i64, ptr }, ptr %t86, !tbaa !27
  store { i64, ptr } %t87, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t89, i32 0, i32 1
  %t92 = load i64, ptr %t91, !tbaa !24
  store i64 %t92, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t94 = load i64, ptr %l7, !tbaa !24
  %t95 = load i64, ptr %l6, !tbaa !24
  %t98 = icmp sgt i64 %t94, %t95
  br i1 %t98, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_115385e8fa9135f5_858b7c4a21055d9)
  unreachable
bb17:
  %t100 = load i64, ptr %l8, !tbaa !24
  %t102 = icmp sgt i64 %t100, 0
  br i1 %t102, label %bb19, label %bb20
bb18:
  store i64 0, ptr %l51, !tbaa !24
  br label %bb22
bb19:
  %t104 = load i64, ptr %l7, !tbaa !24
  %t105 = load i64, ptr %l6, !tbaa !24
  %t108 = sub i64 %t104, %t105
  %t109 = load i64, ptr %l8, !tbaa !24
  %t112 = add i64 %t108, %t109
  %t114 = sub i64 %t112, 1
  %t115 = load i64, ptr %l8, !tbaa !24
  %t118 = sdiv i64 %t114, %t115
  store i64 %t118, ptr %l54, !tbaa !24
  br label %bb21
bb20:
  store i64 0, ptr %l54, !tbaa !24
  br label %bb21
bb21:
  %t120 = load i64, ptr %l54, !tbaa !24
  store i64 %t120, ptr %l51, !tbaa !24
  br label %bb22
bb22:
  %t121 = load i64, ptr %l51, !tbaa !24
  store i64 %t121, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb23
bb23:
  %t122 = load i64, ptr %l10, !tbaa !24
  %t123 = load i64, ptr %l9, !tbaa !24
  %t126 = icmp slt i64 %t122, %t123
  %t128 = xor i1 %t126, true
  br i1 %t128, label %bb24, label %bb25
bb24:
  br label %bb28
bb25:
  br label %bb26
bb26:
  %t130 = load i64, ptr %l6, !tbaa !24
  %t131 = load i64, ptr %l10, !tbaa !24
  %t132 = load i64, ptr %l8, !tbaa !24
  %t135 = mul i64 %t131, %t132
  %t138 = add i64 %t130, %t135
  store i64 %t138, ptr %l11, !tbaa !24
  %t140 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t140, ptr %l72, !tbaa !27
  %t141 = load i64, ptr %l11, !tbaa !24
  %t142 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t142, ptr %l74, !tbaa !27
  %t143 = load i64, ptr %l11, !tbaa !24
  %t145 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !27
  %t147 = getelementptr %"compiler/check:ValueAsk", ptr %t146, i64 %t143
  %t148 = load %"compiler/check:ValueAsk", ptr %t147
  %t151 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t152 = load ptr, ptr %t151, !tbaa !27
  %t153 = getelementptr %"compiler/check:ValueAsk", ptr %t152, i64 %t141
  store %"compiler/check:ValueAsk" %t148, ptr %t153
  br label %bb27
bb27:
  %t154 = load i64, ptr %l10, !tbaa !24
  %t156 = add i64 %t154, 1
  store i64 %t156, ptr %l10, !tbaa !24
  br label %bb23
bb28:
  %t158 = load { i64, ptr }, ptr %l4, !tbaa !27
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3ccompiler_2fcheck_3aatRec_3e_2eroom_3ccompiler_2fcheck_3aatRec_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/check:atRec" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l21 = alloca i64
  %l38 = alloca ptr
  %l39 = alloca i64
  %l40 = alloca %"compiler/check:atRec"
  %l51 = alloca i64
  %l54 = alloca i64
  %l72 = alloca { i64, ptr }
  %l74 = alloca { i64, ptr }
  %t71 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t2, i32 0, i32 0
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t10 = icmp sle i64 %t1, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t19 = icmp slt i64 %t17, 4
  br i1 %t19, label %bb4, label %bb5
bb4:
  store i64 8, ptr %l21, !tbaa !24
  br label %bb6
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t28 = mul i64 %t26, 2
  store i64 %t28, ptr %l21, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l21, !tbaa !24
  store i64 %t30, ptr %l3, !tbaa !24
  %t31 = load i64, ptr %l3, !tbaa !24
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  br i1 %t35, label %bb7, label %bb8
bb7:
  %t37 = load i64, ptr %l1, !tbaa !24
  store i64 %t37, ptr %l3, !tbaa !24
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t39 = load i64, ptr %l3, !tbaa !24
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t40, i32 0, i32 2
  %t43 = load i64, ptr %t42, !tbaa !24
  %t46 = icmp slt i64 %t39, %t43
  br i1 %t46, label %bb10, label %bb11
bb10:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t48, i32 0, i32 2
  %t51 = load i64, ptr %t50, !tbaa !24
  store i64 %t51, ptr %l3, !tbaa !24
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t53, i32 0, i32 0
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  store { i64, ptr } %t56, ptr %l4, !tbaa !27
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l38, !tbaa !29
  %t59 = load i64, ptr %l3, !tbaa !24
  store i64 %t59, ptr %l39, !tbaa !24
  store %"compiler/check:atRec" %a2, ptr %l40
  %t61 = load i64, ptr %l39, !tbaa !24
  %t62 = icmp sge i64 %t61, 0
  br i1 %t62, label %bb13, label %bb14
bb13:
  %t64 = load i64, ptr %l39, !tbaa !24
  %t65 = icmp sle i64 %t64, 288230376151711743
  br i1 %t65, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_3971deb537adcc61_49fa7999ff18665d)
  unreachable
bb15:
  %t67 = load i64, ptr %l39, !tbaa !24
  %t68 = mul i64 %t67, 32
  %t69 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t68)
  %t70 = load %"compiler/check:atRec", ptr %l40
  store i64 0, ptr %t71
  br label %fill.72
fill.72:
  %t75 = load i64, ptr %t71
  %t76 = icmp slt i64 %t75, %t67
  br i1 %t76, label %fillb.73, label %filld.74
fillb.73:
  %t77 = getelementptr %"compiler/check:atRec", ptr %t69, i64 %t75
  store %"compiler/check:atRec" %t70, ptr %t77
  %t78 = add i64 %t75, 1
  store i64 %t78, ptr %t71
  br label %fill.72
filld.74:
  %t79 = insertvalue { i64, ptr } undef, i64 %t67, 0
  %t80 = insertvalue { i64, ptr } %t79, ptr %t69, 1
  %t82 = load ptr, ptr %l38, !tbaa !29
  %t83 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t82, i32 0, i32 0
  store { i64, ptr } %t80, ptr %t83, !tbaa !27
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t84, i32 0, i32 0
  %t87 = load { i64, ptr }, ptr %t86, !tbaa !27
  store { i64, ptr } %t87, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t89, i32 0, i32 1
  %t92 = load i64, ptr %t91, !tbaa !24
  store i64 %t92, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t94 = load i64, ptr %l7, !tbaa !24
  %t95 = load i64, ptr %l6, !tbaa !24
  %t98 = icmp sgt i64 %t94, %t95
  br i1 %t98, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_3971deb537adcc61_49fa7999ff18665d)
  unreachable
bb17:
  %t100 = load i64, ptr %l8, !tbaa !24
  %t102 = icmp sgt i64 %t100, 0
  br i1 %t102, label %bb19, label %bb20
bb18:
  store i64 0, ptr %l51, !tbaa !24
  br label %bb22
bb19:
  %t104 = load i64, ptr %l7, !tbaa !24
  %t105 = load i64, ptr %l6, !tbaa !24
  %t108 = sub i64 %t104, %t105
  %t109 = load i64, ptr %l8, !tbaa !24
  %t112 = add i64 %t108, %t109
  %t114 = sub i64 %t112, 1
  %t115 = load i64, ptr %l8, !tbaa !24
  %t118 = sdiv i64 %t114, %t115
  store i64 %t118, ptr %l54, !tbaa !24
  br label %bb21
bb20:
  store i64 0, ptr %l54, !tbaa !24
  br label %bb21
bb21:
  %t120 = load i64, ptr %l54, !tbaa !24
  store i64 %t120, ptr %l51, !tbaa !24
  br label %bb22
bb22:
  %t121 = load i64, ptr %l51, !tbaa !24
  store i64 %t121, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb23
bb23:
  %t122 = load i64, ptr %l10, !tbaa !24
  %t123 = load i64, ptr %l9, !tbaa !24
  %t126 = icmp slt i64 %t122, %t123
  %t128 = xor i1 %t126, true
  br i1 %t128, label %bb24, label %bb25
bb24:
  br label %bb28
bb25:
  br label %bb26
bb26:
  %t130 = load i64, ptr %l6, !tbaa !24
  %t131 = load i64, ptr %l10, !tbaa !24
  %t132 = load i64, ptr %l8, !tbaa !24
  %t135 = mul i64 %t131, %t132
  %t138 = add i64 %t130, %t135
  store i64 %t138, ptr %l11, !tbaa !24
  %t140 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t140, ptr %l72, !tbaa !27
  %t141 = load i64, ptr %l11, !tbaa !24
  %t142 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t142, ptr %l74, !tbaa !27
  %t143 = load i64, ptr %l11, !tbaa !24
  %t145 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !27
  %t147 = getelementptr %"compiler/check:atRec", ptr %t146, i64 %t143
  %t148 = load %"compiler/check:atRec", ptr %t147
  %t151 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t152 = load ptr, ptr %t151, !tbaa !27
  %t153 = getelementptr %"compiler/check:atRec", ptr %t152, i64 %t141
  store %"compiler/check:atRec" %t148, ptr %t153
  br label %bb27
bb27:
  %t154 = load i64, ptr %l10, !tbaa !24
  %t156 = add i64 %t154, 1
  store i64 %t156, ptr %l10, !tbaa !24
  br label %bb23
bb28:
  %t158 = load { i64, ptr }, ptr %l4, !tbaa !27
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3ccompiler_2fcheck_3aerrBind_3e_2er_H9f3beeaa2b0bc6b319db07b87ddedb31(ptr %v0, ptr %a0, i64 %a1, %"compiler/check:errBind" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l21 = alloca i64
  %l38 = alloca ptr
  %l39 = alloca i64
  %l40 = alloca %"compiler/check:errBind"
  %l51 = alloca i64
  %l54 = alloca i64
  %l72 = alloca { i64, ptr }
  %l74 = alloca { i64, ptr }
  %t71 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t2, i32 0, i32 0
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t10 = icmp sle i64 %t1, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t19 = icmp slt i64 %t17, 4
  br i1 %t19, label %bb4, label %bb5
bb4:
  store i64 8, ptr %l21, !tbaa !24
  br label %bb6
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t28 = mul i64 %t26, 2
  store i64 %t28, ptr %l21, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l21, !tbaa !24
  store i64 %t30, ptr %l3, !tbaa !24
  %t31 = load i64, ptr %l3, !tbaa !24
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  br i1 %t35, label %bb7, label %bb8
bb7:
  %t37 = load i64, ptr %l1, !tbaa !24
  store i64 %t37, ptr %l3, !tbaa !24
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t39 = load i64, ptr %l3, !tbaa !24
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t40, i32 0, i32 2
  %t43 = load i64, ptr %t42, !tbaa !24
  %t46 = icmp slt i64 %t39, %t43
  br i1 %t46, label %bb10, label %bb11
bb10:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t48, i32 0, i32 2
  %t51 = load i64, ptr %t50, !tbaa !24
  store i64 %t51, ptr %l3, !tbaa !24
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t53, i32 0, i32 0
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  store { i64, ptr } %t56, ptr %l4, !tbaa !27
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l38, !tbaa !29
  %t59 = load i64, ptr %l3, !tbaa !24
  store i64 %t59, ptr %l39, !tbaa !24
  store %"compiler/check:errBind" %a2, ptr %l40
  %t61 = load i64, ptr %l39, !tbaa !24
  %t62 = icmp sge i64 %t61, 0
  br i1 %t62, label %bb13, label %bb14
bb13:
  %t64 = load i64, ptr %l39, !tbaa !24
  %t65 = icmp sle i64 %t64, 288230376151711743
  br i1 %t65, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_7f438bdc5a5c0271_9c265596c4f6a85d)
  unreachable
bb15:
  %t67 = load i64, ptr %l39, !tbaa !24
  %t68 = mul i64 %t67, 32
  %t69 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t68)
  %t70 = load %"compiler/check:errBind", ptr %l40
  store i64 0, ptr %t71
  br label %fill.72
fill.72:
  %t75 = load i64, ptr %t71
  %t76 = icmp slt i64 %t75, %t67
  br i1 %t76, label %fillb.73, label %filld.74
fillb.73:
  %t77 = getelementptr %"compiler/check:errBind", ptr %t69, i64 %t75
  store %"compiler/check:errBind" %t70, ptr %t77
  %t78 = add i64 %t75, 1
  store i64 %t78, ptr %t71
  br label %fill.72
filld.74:
  %t79 = insertvalue { i64, ptr } undef, i64 %t67, 0
  %t80 = insertvalue { i64, ptr } %t79, ptr %t69, 1
  %t82 = load ptr, ptr %l38, !tbaa !29
  %t83 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t82, i32 0, i32 0
  store { i64, ptr } %t80, ptr %t83, !tbaa !27
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t84, i32 0, i32 0
  %t87 = load { i64, ptr }, ptr %t86, !tbaa !27
  store { i64, ptr } %t87, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t89, i32 0, i32 1
  %t92 = load i64, ptr %t91, !tbaa !24
  store i64 %t92, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t94 = load i64, ptr %l7, !tbaa !24
  %t95 = load i64, ptr %l6, !tbaa !24
  %t98 = icmp sgt i64 %t94, %t95
  br i1 %t98, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_7f438bdc5a5c0271_9c265596c4f6a85d)
  unreachable
bb17:
  %t100 = load i64, ptr %l8, !tbaa !24
  %t102 = icmp sgt i64 %t100, 0
  br i1 %t102, label %bb19, label %bb20
bb18:
  store i64 0, ptr %l51, !tbaa !24
  br label %bb22
bb19:
  %t104 = load i64, ptr %l7, !tbaa !24
  %t105 = load i64, ptr %l6, !tbaa !24
  %t108 = sub i64 %t104, %t105
  %t109 = load i64, ptr %l8, !tbaa !24
  %t112 = add i64 %t108, %t109
  %t114 = sub i64 %t112, 1
  %t115 = load i64, ptr %l8, !tbaa !24
  %t118 = sdiv i64 %t114, %t115
  store i64 %t118, ptr %l54, !tbaa !24
  br label %bb21
bb20:
  store i64 0, ptr %l54, !tbaa !24
  br label %bb21
bb21:
  %t120 = load i64, ptr %l54, !tbaa !24
  store i64 %t120, ptr %l51, !tbaa !24
  br label %bb22
bb22:
  %t121 = load i64, ptr %l51, !tbaa !24
  store i64 %t121, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb23
bb23:
  %t122 = load i64, ptr %l10, !tbaa !24
  %t123 = load i64, ptr %l9, !tbaa !24
  %t126 = icmp slt i64 %t122, %t123
  %t128 = xor i1 %t126, true
  br i1 %t128, label %bb24, label %bb25
bb24:
  br label %bb28
bb25:
  br label %bb26
bb26:
  %t130 = load i64, ptr %l6, !tbaa !24
  %t131 = load i64, ptr %l10, !tbaa !24
  %t132 = load i64, ptr %l8, !tbaa !24
  %t135 = mul i64 %t131, %t132
  %t138 = add i64 %t130, %t135
  store i64 %t138, ptr %l11, !tbaa !24
  %t140 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t140, ptr %l72, !tbaa !27
  %t141 = load i64, ptr %l11, !tbaa !24
  %t142 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t142, ptr %l74, !tbaa !27
  %t143 = load i64, ptr %l11, !tbaa !24
  %t145 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !27
  %t147 = getelementptr %"compiler/check:errBind", ptr %t146, i64 %t143
  %t148 = load %"compiler/check:errBind", ptr %t147
  %t151 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t152 = load ptr, ptr %t151, !tbaa !27
  %t153 = getelementptr %"compiler/check:errBind", ptr %t152, i64 %t141
  store %"compiler/check:errBind" %t148, ptr %t153
  br label %bb27
bb27:
  %t154 = load i64, ptr %l10, !tbaa !24
  %t156 = add i64 %t154, 1
  store i64 %t156, ptr %l10, !tbaa !24
  br label %bb23
bb28:
  %t158 = load { i64, ptr }, ptr %l4, !tbaa !27
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3ccompiler_2fcheck_3aerrNarrow_3e_2_Hfaa600600d2c6cf76b4e37fd58b9a559(ptr %v0, ptr %a0, i64 %a1, %"compiler/check:errNarrow" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l21 = alloca i64
  %l38 = alloca ptr
  %l39 = alloca i64
  %l40 = alloca %"compiler/check:errNarrow"
  %l51 = alloca i64
  %l54 = alloca i64
  %l72 = alloca { i64, ptr }
  %l74 = alloca { i64, ptr }
  %t71 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t2, i32 0, i32 0
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t10 = icmp sle i64 %t1, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t19 = icmp slt i64 %t17, 4
  br i1 %t19, label %bb4, label %bb5
bb4:
  store i64 8, ptr %l21, !tbaa !24
  br label %bb6
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t28 = mul i64 %t26, 2
  store i64 %t28, ptr %l21, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l21, !tbaa !24
  store i64 %t30, ptr %l3, !tbaa !24
  %t31 = load i64, ptr %l3, !tbaa !24
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  br i1 %t35, label %bb7, label %bb8
bb7:
  %t37 = load i64, ptr %l1, !tbaa !24
  store i64 %t37, ptr %l3, !tbaa !24
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t39 = load i64, ptr %l3, !tbaa !24
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t40, i32 0, i32 2
  %t43 = load i64, ptr %t42, !tbaa !24
  %t46 = icmp slt i64 %t39, %t43
  br i1 %t46, label %bb10, label %bb11
bb10:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t48, i32 0, i32 2
  %t51 = load i64, ptr %t50, !tbaa !24
  store i64 %t51, ptr %l3, !tbaa !24
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t53, i32 0, i32 0
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  store { i64, ptr } %t56, ptr %l4, !tbaa !27
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l38, !tbaa !29
  %t59 = load i64, ptr %l3, !tbaa !24
  store i64 %t59, ptr %l39, !tbaa !24
  store %"compiler/check:errNarrow" %a2, ptr %l40
  %t61 = load i64, ptr %l39, !tbaa !24
  %t62 = icmp sge i64 %t61, 0
  br i1 %t62, label %bb13, label %bb14
bb13:
  %t64 = load i64, ptr %l39, !tbaa !24
  %t65 = icmp sle i64 %t64, 384307168202282325
  br i1 %t65, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_496b2f5817ced6f9_10bf9e340b2623d)
  unreachable
bb15:
  %t67 = load i64, ptr %l39, !tbaa !24
  %t68 = mul i64 %t67, 24
  %t69 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t68)
  %t70 = load %"compiler/check:errNarrow", ptr %l40
  store i64 0, ptr %t71
  br label %fill.72
fill.72:
  %t75 = load i64, ptr %t71
  %t76 = icmp slt i64 %t75, %t67
  br i1 %t76, label %fillb.73, label %filld.74
fillb.73:
  %t77 = getelementptr %"compiler/check:errNarrow", ptr %t69, i64 %t75
  store %"compiler/check:errNarrow" %t70, ptr %t77
  %t78 = add i64 %t75, 1
  store i64 %t78, ptr %t71
  br label %fill.72
filld.74:
  %t79 = insertvalue { i64, ptr } undef, i64 %t67, 0
  %t80 = insertvalue { i64, ptr } %t79, ptr %t69, 1
  %t82 = load ptr, ptr %l38, !tbaa !29
  %t83 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t82, i32 0, i32 0
  store { i64, ptr } %t80, ptr %t83, !tbaa !27
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t84, i32 0, i32 0
  %t87 = load { i64, ptr }, ptr %t86, !tbaa !27
  store { i64, ptr } %t87, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t89, i32 0, i32 1
  %t92 = load i64, ptr %t91, !tbaa !24
  store i64 %t92, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t94 = load i64, ptr %l7, !tbaa !24
  %t95 = load i64, ptr %l6, !tbaa !24
  %t98 = icmp sgt i64 %t94, %t95
  br i1 %t98, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_496b2f5817ced6f9_10bf9e340b2623d)
  unreachable
bb17:
  %t100 = load i64, ptr %l8, !tbaa !24
  %t102 = icmp sgt i64 %t100, 0
  br i1 %t102, label %bb19, label %bb20
bb18:
  store i64 0, ptr %l51, !tbaa !24
  br label %bb22
bb19:
  %t104 = load i64, ptr %l7, !tbaa !24
  %t105 = load i64, ptr %l6, !tbaa !24
  %t108 = sub i64 %t104, %t105
  %t109 = load i64, ptr %l8, !tbaa !24
  %t112 = add i64 %t108, %t109
  %t114 = sub i64 %t112, 1
  %t115 = load i64, ptr %l8, !tbaa !24
  %t118 = sdiv i64 %t114, %t115
  store i64 %t118, ptr %l54, !tbaa !24
  br label %bb21
bb20:
  store i64 0, ptr %l54, !tbaa !24
  br label %bb21
bb21:
  %t120 = load i64, ptr %l54, !tbaa !24
  store i64 %t120, ptr %l51, !tbaa !24
  br label %bb22
bb22:
  %t121 = load i64, ptr %l51, !tbaa !24
  store i64 %t121, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb23
bb23:
  %t122 = load i64, ptr %l10, !tbaa !24
  %t123 = load i64, ptr %l9, !tbaa !24
  %t126 = icmp slt i64 %t122, %t123
  %t128 = xor i1 %t126, true
  br i1 %t128, label %bb24, label %bb25
bb24:
  br label %bb28
bb25:
  br label %bb26
bb26:
  %t130 = load i64, ptr %l6, !tbaa !24
  %t131 = load i64, ptr %l10, !tbaa !24
  %t132 = load i64, ptr %l8, !tbaa !24
  %t135 = mul i64 %t131, %t132
  %t138 = add i64 %t130, %t135
  store i64 %t138, ptr %l11, !tbaa !24
  %t140 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t140, ptr %l72, !tbaa !27
  %t141 = load i64, ptr %l11, !tbaa !24
  %t142 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t142, ptr %l74, !tbaa !27
  %t143 = load i64, ptr %l11, !tbaa !24
  %t145 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !27
  %t147 = getelementptr %"compiler/check:errNarrow", ptr %t146, i64 %t143
  %t148 = load %"compiler/check:errNarrow", ptr %t147
  %t151 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t152 = load ptr, ptr %t151, !tbaa !27
  %t153 = getelementptr %"compiler/check:errNarrow", ptr %t152, i64 %t141
  store %"compiler/check:errNarrow" %t148, ptr %t153
  br label %bb27
bb27:
  %t154 = load i64, ptr %l10, !tbaa !24
  %t156 = add i64 %t154, 1
  store i64 %t156, ptr %l10, !tbaa !24
  br label %bb23
bb28:
  %t158 = load { i64, ptr }, ptr %l4, !tbaa !27
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3ccompiler_2fcheck_3anarrowed_3e_2e_H1675fd03025bca61f0dd06a2befaac33(ptr %v0, ptr %a0, i64 %a1, %"compiler/check:narrowed" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l21 = alloca i64
  %l38 = alloca ptr
  %l39 = alloca i64
  %l40 = alloca %"compiler/check:narrowed"
  %l51 = alloca i64
  %l54 = alloca i64
  %l72 = alloca { i64, ptr }
  %l74 = alloca { i64, ptr }
  %t71 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t2, i32 0, i32 0
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t10 = icmp sle i64 %t1, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t19 = icmp slt i64 %t17, 4
  br i1 %t19, label %bb4, label %bb5
bb4:
  store i64 8, ptr %l21, !tbaa !24
  br label %bb6
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t28 = mul i64 %t26, 2
  store i64 %t28, ptr %l21, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l21, !tbaa !24
  store i64 %t30, ptr %l3, !tbaa !24
  %t31 = load i64, ptr %l3, !tbaa !24
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  br i1 %t35, label %bb7, label %bb8
bb7:
  %t37 = load i64, ptr %l1, !tbaa !24
  store i64 %t37, ptr %l3, !tbaa !24
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t39 = load i64, ptr %l3, !tbaa !24
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t40, i32 0, i32 2
  %t43 = load i64, ptr %t42, !tbaa !24
  %t46 = icmp slt i64 %t39, %t43
  br i1 %t46, label %bb10, label %bb11
bb10:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t48, i32 0, i32 2
  %t51 = load i64, ptr %t50, !tbaa !24
  store i64 %t51, ptr %l3, !tbaa !24
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t53, i32 0, i32 0
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  store { i64, ptr } %t56, ptr %l4, !tbaa !27
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l38, !tbaa !29
  %t59 = load i64, ptr %l3, !tbaa !24
  store i64 %t59, ptr %l39, !tbaa !24
  store %"compiler/check:narrowed" %a2, ptr %l40
  %t61 = load i64, ptr %l39, !tbaa !24
  %t62 = icmp sge i64 %t61, 0
  br i1 %t62, label %bb13, label %bb14
bb13:
  %t64 = load i64, ptr %l39, !tbaa !24
  %t65 = icmp sle i64 %t64, 230584300921369395
  br i1 %t65, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_4548956545b549f1_3148bf8c22a7bbcd)
  unreachable
bb15:
  %t67 = load i64, ptr %l39, !tbaa !24
  %t68 = mul i64 %t67, 40
  %t69 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t68)
  %t70 = load %"compiler/check:narrowed", ptr %l40
  store i64 0, ptr %t71
  br label %fill.72
fill.72:
  %t75 = load i64, ptr %t71
  %t76 = icmp slt i64 %t75, %t67
  br i1 %t76, label %fillb.73, label %filld.74
fillb.73:
  %t77 = getelementptr %"compiler/check:narrowed", ptr %t69, i64 %t75
  store %"compiler/check:narrowed" %t70, ptr %t77
  %t78 = add i64 %t75, 1
  store i64 %t78, ptr %t71
  br label %fill.72
filld.74:
  %t79 = insertvalue { i64, ptr } undef, i64 %t67, 0
  %t80 = insertvalue { i64, ptr } %t79, ptr %t69, 1
  %t82 = load ptr, ptr %l38, !tbaa !29
  %t83 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t82, i32 0, i32 0
  store { i64, ptr } %t80, ptr %t83, !tbaa !27
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t84, i32 0, i32 0
  %t87 = load { i64, ptr }, ptr %t86, !tbaa !27
  store { i64, ptr } %t87, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t89, i32 0, i32 1
  %t92 = load i64, ptr %t91, !tbaa !24
  store i64 %t92, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t94 = load i64, ptr %l7, !tbaa !24
  %t95 = load i64, ptr %l6, !tbaa !24
  %t98 = icmp sgt i64 %t94, %t95
  br i1 %t98, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_4548956545b549f1_3148bf8c22a7bbcd)
  unreachable
bb17:
  %t100 = load i64, ptr %l8, !tbaa !24
  %t102 = icmp sgt i64 %t100, 0
  br i1 %t102, label %bb19, label %bb20
bb18:
  store i64 0, ptr %l51, !tbaa !24
  br label %bb22
bb19:
  %t104 = load i64, ptr %l7, !tbaa !24
  %t105 = load i64, ptr %l6, !tbaa !24
  %t108 = sub i64 %t104, %t105
  %t109 = load i64, ptr %l8, !tbaa !24
  %t112 = add i64 %t108, %t109
  %t114 = sub i64 %t112, 1
  %t115 = load i64, ptr %l8, !tbaa !24
  %t118 = sdiv i64 %t114, %t115
  store i64 %t118, ptr %l54, !tbaa !24
  br label %bb21
bb20:
  store i64 0, ptr %l54, !tbaa !24
  br label %bb21
bb21:
  %t120 = load i64, ptr %l54, !tbaa !24
  store i64 %t120, ptr %l51, !tbaa !24
  br label %bb22
bb22:
  %t121 = load i64, ptr %l51, !tbaa !24
  store i64 %t121, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb23
bb23:
  %t122 = load i64, ptr %l10, !tbaa !24
  %t123 = load i64, ptr %l9, !tbaa !24
  %t126 = icmp slt i64 %t122, %t123
  %t128 = xor i1 %t126, true
  br i1 %t128, label %bb24, label %bb25
bb24:
  br label %bb28
bb25:
  br label %bb26
bb26:
  %t130 = load i64, ptr %l6, !tbaa !24
  %t131 = load i64, ptr %l10, !tbaa !24
  %t132 = load i64, ptr %l8, !tbaa !24
  %t135 = mul i64 %t131, %t132
  %t138 = add i64 %t130, %t135
  store i64 %t138, ptr %l11, !tbaa !24
  %t140 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t140, ptr %l72, !tbaa !27
  %t141 = load i64, ptr %l11, !tbaa !24
  %t142 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t142, ptr %l74, !tbaa !27
  %t143 = load i64, ptr %l11, !tbaa !24
  %t145 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !27
  %t147 = getelementptr %"compiler/check:narrowed", ptr %t146, i64 %t143
  %t148 = load %"compiler/check:narrowed", ptr %t147
  %t151 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t152 = load ptr, ptr %t151, !tbaa !27
  %t153 = getelementptr %"compiler/check:narrowed", ptr %t152, i64 %t141
  store %"compiler/check:narrowed" %t148, ptr %t153
  br label %bb27
bb27:
  %t154 = load i64, ptr %l10, !tbaa !24
  %t156 = add i64 %t154, 1
  store i64 %t156, ptr %l10, !tbaa !24
  br label %bb23
bb28:
  %t158 = load { i64, ptr }, ptr %l4, !tbaa !27
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3ccompiler_2fcheck_3anullNarrow_3e__Hfe323e1d425e9315957739f859be5234(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/check:nullNarrow" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l21 = alloca i64
  %l38 = alloca ptr
  %l39 = alloca i64
  %l40 = alloca %"compiler/check:nullNarrow"
  %l51 = alloca i64
  %l54 = alloca i64
  %l72 = alloca { i64, ptr }
  %l74 = alloca { i64, ptr }
  %t71 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t2, i32 0, i32 0
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t10 = icmp sle i64 %t1, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t19 = icmp slt i64 %t17, 4
  br i1 %t19, label %bb4, label %bb5
bb4:
  store i64 8, ptr %l21, !tbaa !24
  br label %bb6
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t28 = mul i64 %t26, 2
  store i64 %t28, ptr %l21, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l21, !tbaa !24
  store i64 %t30, ptr %l3, !tbaa !24
  %t31 = load i64, ptr %l3, !tbaa !24
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  br i1 %t35, label %bb7, label %bb8
bb7:
  %t37 = load i64, ptr %l1, !tbaa !24
  store i64 %t37, ptr %l3, !tbaa !24
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t39 = load i64, ptr %l3, !tbaa !24
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t40, i32 0, i32 2
  %t43 = load i64, ptr %t42, !tbaa !24
  %t46 = icmp slt i64 %t39, %t43
  br i1 %t46, label %bb10, label %bb11
bb10:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t48, i32 0, i32 2
  %t51 = load i64, ptr %t50, !tbaa !24
  store i64 %t51, ptr %l3, !tbaa !24
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t53, i32 0, i32 0
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  store { i64, ptr } %t56, ptr %l4, !tbaa !27
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l38, !tbaa !29
  %t59 = load i64, ptr %l3, !tbaa !24
  store i64 %t59, ptr %l39, !tbaa !24
  store %"compiler/check:nullNarrow" %a2, ptr %l40
  %t61 = load i64, ptr %l39, !tbaa !24
  %t62 = icmp sge i64 %t61, 0
  br i1 %t62, label %bb13, label %bb14
bb13:
  %t64 = load i64, ptr %l39, !tbaa !24
  %t65 = icmp sle i64 %t64, 288230376151711743
  br i1 %t65, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_f729c2216052bfff_50c5b5b011682e5b)
  unreachable
bb15:
  %t67 = load i64, ptr %l39, !tbaa !24
  %t68 = mul i64 %t67, 32
  %t69 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t68)
  %t70 = load %"compiler/check:nullNarrow", ptr %l40
  store i64 0, ptr %t71
  br label %fill.72
fill.72:
  %t75 = load i64, ptr %t71
  %t76 = icmp slt i64 %t75, %t67
  br i1 %t76, label %fillb.73, label %filld.74
fillb.73:
  %t77 = getelementptr %"compiler/check:nullNarrow", ptr %t69, i64 %t75
  store %"compiler/check:nullNarrow" %t70, ptr %t77
  %t78 = add i64 %t75, 1
  store i64 %t78, ptr %t71
  br label %fill.72
filld.74:
  %t79 = insertvalue { i64, ptr } undef, i64 %t67, 0
  %t80 = insertvalue { i64, ptr } %t79, ptr %t69, 1
  %t82 = load ptr, ptr %l38, !tbaa !29
  %t83 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t82, i32 0, i32 0
  store { i64, ptr } %t80, ptr %t83, !tbaa !27
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t84, i32 0, i32 0
  %t87 = load { i64, ptr }, ptr %t86, !tbaa !27
  store { i64, ptr } %t87, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t89, i32 0, i32 1
  %t92 = load i64, ptr %t91, !tbaa !24
  store i64 %t92, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t94 = load i64, ptr %l7, !tbaa !24
  %t95 = load i64, ptr %l6, !tbaa !24
  %t98 = icmp sgt i64 %t94, %t95
  br i1 %t98, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_f729c2216052bfff_50c5b5b011682e5b)
  unreachable
bb17:
  %t100 = load i64, ptr %l8, !tbaa !24
  %t102 = icmp sgt i64 %t100, 0
  br i1 %t102, label %bb19, label %bb20
bb18:
  store i64 0, ptr %l51, !tbaa !24
  br label %bb22
bb19:
  %t104 = load i64, ptr %l7, !tbaa !24
  %t105 = load i64, ptr %l6, !tbaa !24
  %t108 = sub i64 %t104, %t105
  %t109 = load i64, ptr %l8, !tbaa !24
  %t112 = add i64 %t108, %t109
  %t114 = sub i64 %t112, 1
  %t115 = load i64, ptr %l8, !tbaa !24
  %t118 = sdiv i64 %t114, %t115
  store i64 %t118, ptr %l54, !tbaa !24
  br label %bb21
bb20:
  store i64 0, ptr %l54, !tbaa !24
  br label %bb21
bb21:
  %t120 = load i64, ptr %l54, !tbaa !24
  store i64 %t120, ptr %l51, !tbaa !24
  br label %bb22
bb22:
  %t121 = load i64, ptr %l51, !tbaa !24
  store i64 %t121, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb23
bb23:
  %t122 = load i64, ptr %l10, !tbaa !24
  %t123 = load i64, ptr %l9, !tbaa !24
  %t126 = icmp slt i64 %t122, %t123
  %t128 = xor i1 %t126, true
  br i1 %t128, label %bb24, label %bb25
bb24:
  br label %bb28
bb25:
  br label %bb26
bb26:
  %t130 = load i64, ptr %l6, !tbaa !24
  %t131 = load i64, ptr %l10, !tbaa !24
  %t132 = load i64, ptr %l8, !tbaa !24
  %t135 = mul i64 %t131, %t132
  %t138 = add i64 %t130, %t135
  store i64 %t138, ptr %l11, !tbaa !24
  %t140 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t140, ptr %l72, !tbaa !27
  %t141 = load i64, ptr %l11, !tbaa !24
  %t142 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t142, ptr %l74, !tbaa !27
  %t143 = load i64, ptr %l11, !tbaa !24
  %t145 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !27
  %t147 = getelementptr %"compiler/check:nullNarrow", ptr %t146, i64 %t143
  %t148 = load %"compiler/check:nullNarrow", ptr %t147
  %t151 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t152 = load ptr, ptr %t151, !tbaa !27
  %t153 = getelementptr %"compiler/check:nullNarrow", ptr %t152, i64 %t141
  store %"compiler/check:nullNarrow" %t148, ptr %t153
  br label %bb27
bb27:
  %t154 = load i64, ptr %l10, !tbaa !24
  %t156 = add i64 %t154, 1
  store i64 %t156, ptr %l10, !tbaa !24
  br label %bb23
bb28:
  %t158 = load { i64, ptr }, ptr %l4, !tbaa !27
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3ccompiler_2fcheck_3aroArg_3e_2eroom_3ccompiler_2fcheck_3aroArg_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/check:roArg" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l21 = alloca i64
  %l38 = alloca ptr
  %l39 = alloca i64
  %l40 = alloca %"compiler/check:roArg"
  %l51 = alloca i64
  %l54 = alloca i64
  %l72 = alloca { i64, ptr }
  %l74 = alloca { i64, ptr }
  %t71 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t2, i32 0, i32 0
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t10 = icmp sle i64 %t1, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t19 = icmp slt i64 %t17, 4
  br i1 %t19, label %bb4, label %bb5
bb4:
  store i64 8, ptr %l21, !tbaa !24
  br label %bb6
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t28 = mul i64 %t26, 2
  store i64 %t28, ptr %l21, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l21, !tbaa !24
  store i64 %t30, ptr %l3, !tbaa !24
  %t31 = load i64, ptr %l3, !tbaa !24
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  br i1 %t35, label %bb7, label %bb8
bb7:
  %t37 = load i64, ptr %l1, !tbaa !24
  store i64 %t37, ptr %l3, !tbaa !24
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t39 = load i64, ptr %l3, !tbaa !24
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t40, i32 0, i32 2
  %t43 = load i64, ptr %t42, !tbaa !24
  %t46 = icmp slt i64 %t39, %t43
  br i1 %t46, label %bb10, label %bb11
bb10:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t48, i32 0, i32 2
  %t51 = load i64, ptr %t50, !tbaa !24
  store i64 %t51, ptr %l3, !tbaa !24
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t53, i32 0, i32 0
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  store { i64, ptr } %t56, ptr %l4, !tbaa !27
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l38, !tbaa !29
  %t59 = load i64, ptr %l3, !tbaa !24
  store i64 %t59, ptr %l39, !tbaa !24
  store %"compiler/check:roArg" %a2, ptr %l40
  %t61 = load i64, ptr %l39, !tbaa !24
  %t62 = icmp sge i64 %t61, 0
  br i1 %t62, label %bb13, label %bb14
bb13:
  %t64 = load i64, ptr %l39, !tbaa !24
  %t65 = icmp sle i64 %t64, 96076792050570581
  br i1 %t65, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_63217708da431fa9_77859d583dbca135)
  unreachable
bb15:
  %t67 = load i64, ptr %l39, !tbaa !24
  %t68 = mul i64 %t67, 96
  %t69 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t68)
  %t70 = load %"compiler/check:roArg", ptr %l40
  store i64 0, ptr %t71
  br label %fill.72
fill.72:
  %t75 = load i64, ptr %t71
  %t76 = icmp slt i64 %t75, %t67
  br i1 %t76, label %fillb.73, label %filld.74
fillb.73:
  %t77 = getelementptr %"compiler/check:roArg", ptr %t69, i64 %t75
  store %"compiler/check:roArg" %t70, ptr %t77
  %t78 = add i64 %t75, 1
  store i64 %t78, ptr %t71
  br label %fill.72
filld.74:
  %t79 = insertvalue { i64, ptr } undef, i64 %t67, 0
  %t80 = insertvalue { i64, ptr } %t79, ptr %t69, 1
  %t82 = load ptr, ptr %l38, !tbaa !29
  %t83 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t82, i32 0, i32 0
  store { i64, ptr } %t80, ptr %t83, !tbaa !27
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t84, i32 0, i32 0
  %t87 = load { i64, ptr }, ptr %t86, !tbaa !27
  store { i64, ptr } %t87, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t89, i32 0, i32 1
  %t92 = load i64, ptr %t91, !tbaa !24
  store i64 %t92, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t94 = load i64, ptr %l7, !tbaa !24
  %t95 = load i64, ptr %l6, !tbaa !24
  %t98 = icmp sgt i64 %t94, %t95
  br i1 %t98, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_63217708da431fa9_77859d583dbca135)
  unreachable
bb17:
  %t100 = load i64, ptr %l8, !tbaa !24
  %t102 = icmp sgt i64 %t100, 0
  br i1 %t102, label %bb19, label %bb20
bb18:
  store i64 0, ptr %l51, !tbaa !24
  br label %bb22
bb19:
  %t104 = load i64, ptr %l7, !tbaa !24
  %t105 = load i64, ptr %l6, !tbaa !24
  %t108 = sub i64 %t104, %t105
  %t109 = load i64, ptr %l8, !tbaa !24
  %t112 = add i64 %t108, %t109
  %t114 = sub i64 %t112, 1
  %t115 = load i64, ptr %l8, !tbaa !24
  %t118 = sdiv i64 %t114, %t115
  store i64 %t118, ptr %l54, !tbaa !24
  br label %bb21
bb20:
  store i64 0, ptr %l54, !tbaa !24
  br label %bb21
bb21:
  %t120 = load i64, ptr %l54, !tbaa !24
  store i64 %t120, ptr %l51, !tbaa !24
  br label %bb22
bb22:
  %t121 = load i64, ptr %l51, !tbaa !24
  store i64 %t121, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb23
bb23:
  %t122 = load i64, ptr %l10, !tbaa !24
  %t123 = load i64, ptr %l9, !tbaa !24
  %t126 = icmp slt i64 %t122, %t123
  %t128 = xor i1 %t126, true
  br i1 %t128, label %bb24, label %bb25
bb24:
  br label %bb28
bb25:
  br label %bb26
bb26:
  %t130 = load i64, ptr %l6, !tbaa !24
  %t131 = load i64, ptr %l10, !tbaa !24
  %t132 = load i64, ptr %l8, !tbaa !24
  %t135 = mul i64 %t131, %t132
  %t138 = add i64 %t130, %t135
  store i64 %t138, ptr %l11, !tbaa !24
  %t140 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t140, ptr %l72, !tbaa !27
  %t141 = load i64, ptr %l11, !tbaa !24
  %t142 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t142, ptr %l74, !tbaa !27
  %t143 = load i64, ptr %l11, !tbaa !24
  %t145 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !27
  %t147 = getelementptr %"compiler/check:roArg", ptr %t146, i64 %t143
  %t148 = load %"compiler/check:roArg", ptr %t147
  %t151 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t152 = load ptr, ptr %t151, !tbaa !27
  %t153 = getelementptr %"compiler/check:roArg", ptr %t152, i64 %t141
  store %"compiler/check:roArg" %t148, ptr %t153
  br label %bb27
bb27:
  %t154 = load i64, ptr %l10, !tbaa !24
  %t156 = add i64 %t154, 1
  store i64 %t156, ptr %l10, !tbaa !24
  br label %bb23
bb28:
  %t158 = load { i64, ptr }, ptr %l4, !tbaa !27
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3ccompiler_2fcheck_3aroDeepArg_3e_2_H5df4af53cb0aa34927c4096ccb4f71f7(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/check:roDeepArg" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l21 = alloca i64
  %l38 = alloca ptr
  %l39 = alloca i64
  %l40 = alloca %"compiler/check:roDeepArg"
  %l51 = alloca i64
  %l54 = alloca i64
  %l72 = alloca { i64, ptr }
  %l74 = alloca { i64, ptr }
  %t71 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t2, i32 0, i32 0
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t10 = icmp sle i64 %t1, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t19 = icmp slt i64 %t17, 4
  br i1 %t19, label %bb4, label %bb5
bb4:
  store i64 8, ptr %l21, !tbaa !24
  br label %bb6
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t28 = mul i64 %t26, 2
  store i64 %t28, ptr %l21, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l21, !tbaa !24
  store i64 %t30, ptr %l3, !tbaa !24
  %t31 = load i64, ptr %l3, !tbaa !24
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  br i1 %t35, label %bb7, label %bb8
bb7:
  %t37 = load i64, ptr %l1, !tbaa !24
  store i64 %t37, ptr %l3, !tbaa !24
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t39 = load i64, ptr %l3, !tbaa !24
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t40, i32 0, i32 2
  %t43 = load i64, ptr %t42, !tbaa !24
  %t46 = icmp slt i64 %t39, %t43
  br i1 %t46, label %bb10, label %bb11
bb10:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t48, i32 0, i32 2
  %t51 = load i64, ptr %t50, !tbaa !24
  store i64 %t51, ptr %l3, !tbaa !24
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t53, i32 0, i32 0
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  store { i64, ptr } %t56, ptr %l4, !tbaa !27
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l38, !tbaa !29
  %t59 = load i64, ptr %l3, !tbaa !24
  store i64 %t59, ptr %l39, !tbaa !24
  store %"compiler/check:roDeepArg" %a2, ptr %l40
  %t61 = load i64, ptr %l39, !tbaa !24
  %t62 = icmp sge i64 %t61, 0
  br i1 %t62, label %bb13, label %bb14
bb13:
  %t64 = load i64, ptr %l39, !tbaa !24
  %t65 = icmp sle i64 %t64, 288230376151711743
  br i1 %t65, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_abe2958fee383b29_80c71d662d0f1ffd)
  unreachable
bb15:
  %t67 = load i64, ptr %l39, !tbaa !24
  %t68 = mul i64 %t67, 32
  %t69 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t68)
  %t70 = load %"compiler/check:roDeepArg", ptr %l40
  store i64 0, ptr %t71
  br label %fill.72
fill.72:
  %t75 = load i64, ptr %t71
  %t76 = icmp slt i64 %t75, %t67
  br i1 %t76, label %fillb.73, label %filld.74
fillb.73:
  %t77 = getelementptr %"compiler/check:roDeepArg", ptr %t69, i64 %t75
  store %"compiler/check:roDeepArg" %t70, ptr %t77
  %t78 = add i64 %t75, 1
  store i64 %t78, ptr %t71
  br label %fill.72
filld.74:
  %t79 = insertvalue { i64, ptr } undef, i64 %t67, 0
  %t80 = insertvalue { i64, ptr } %t79, ptr %t69, 1
  %t82 = load ptr, ptr %l38, !tbaa !29
  %t83 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t82, i32 0, i32 0
  store { i64, ptr } %t80, ptr %t83, !tbaa !27
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t84, i32 0, i32 0
  %t87 = load { i64, ptr }, ptr %t86, !tbaa !27
  store { i64, ptr } %t87, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t89, i32 0, i32 1
  %t92 = load i64, ptr %t91, !tbaa !24
  store i64 %t92, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t94 = load i64, ptr %l7, !tbaa !24
  %t95 = load i64, ptr %l6, !tbaa !24
  %t98 = icmp sgt i64 %t94, %t95
  br i1 %t98, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_abe2958fee383b29_80c71d662d0f1ffd)
  unreachable
bb17:
  %t100 = load i64, ptr %l8, !tbaa !24
  %t102 = icmp sgt i64 %t100, 0
  br i1 %t102, label %bb19, label %bb20
bb18:
  store i64 0, ptr %l51, !tbaa !24
  br label %bb22
bb19:
  %t104 = load i64, ptr %l7, !tbaa !24
  %t105 = load i64, ptr %l6, !tbaa !24
  %t108 = sub i64 %t104, %t105
  %t109 = load i64, ptr %l8, !tbaa !24
  %t112 = add i64 %t108, %t109
  %t114 = sub i64 %t112, 1
  %t115 = load i64, ptr %l8, !tbaa !24
  %t118 = sdiv i64 %t114, %t115
  store i64 %t118, ptr %l54, !tbaa !24
  br label %bb21
bb20:
  store i64 0, ptr %l54, !tbaa !24
  br label %bb21
bb21:
  %t120 = load i64, ptr %l54, !tbaa !24
  store i64 %t120, ptr %l51, !tbaa !24
  br label %bb22
bb22:
  %t121 = load i64, ptr %l51, !tbaa !24
  store i64 %t121, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb23
bb23:
  %t122 = load i64, ptr %l10, !tbaa !24
  %t123 = load i64, ptr %l9, !tbaa !24
  %t126 = icmp slt i64 %t122, %t123
  %t128 = xor i1 %t126, true
  br i1 %t128, label %bb24, label %bb25
bb24:
  br label %bb28
bb25:
  br label %bb26
bb26:
  %t130 = load i64, ptr %l6, !tbaa !24
  %t131 = load i64, ptr %l10, !tbaa !24
  %t132 = load i64, ptr %l8, !tbaa !24
  %t135 = mul i64 %t131, %t132
  %t138 = add i64 %t130, %t135
  store i64 %t138, ptr %l11, !tbaa !24
  %t140 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t140, ptr %l72, !tbaa !27
  %t141 = load i64, ptr %l11, !tbaa !24
  %t142 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t142, ptr %l74, !tbaa !27
  %t143 = load i64, ptr %l11, !tbaa !24
  %t145 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !27
  %t147 = getelementptr %"compiler/check:roDeepArg", ptr %t146, i64 %t143
  %t148 = load %"compiler/check:roDeepArg", ptr %t147
  %t151 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t152 = load ptr, ptr %t151, !tbaa !27
  %t153 = getelementptr %"compiler/check:roDeepArg", ptr %t152, i64 %t141
  store %"compiler/check:roDeepArg" %t148, ptr %t153
  br label %bb27
bb27:
  %t154 = load i64, ptr %l10, !tbaa !24
  %t156 = add i64 %t154, 1
  store i64 %t156, ptr %l10, !tbaa !24
  br label %bb23
bb28:
  %t158 = load { i64, ptr }, ptr %l4, !tbaa !27
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3ccompiler_2fcheck_3aroFn_3e_2eroom_3ccompiler_2fcheck_3aroFn_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/check:roFn" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l21 = alloca i64
  %l38 = alloca ptr
  %l39 = alloca i64
  %l40 = alloca %"compiler/check:roFn"
  %l51 = alloca i64
  %l54 = alloca i64
  %l72 = alloca { i64, ptr }
  %l74 = alloca { i64, ptr }
  %t71 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t2, i32 0, i32 0
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t10 = icmp sle i64 %t1, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t19 = icmp slt i64 %t17, 4
  br i1 %t19, label %bb4, label %bb5
bb4:
  store i64 8, ptr %l21, !tbaa !24
  br label %bb6
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t28 = mul i64 %t26, 2
  store i64 %t28, ptr %l21, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l21, !tbaa !24
  store i64 %t30, ptr %l3, !tbaa !24
  %t31 = load i64, ptr %l3, !tbaa !24
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  br i1 %t35, label %bb7, label %bb8
bb7:
  %t37 = load i64, ptr %l1, !tbaa !24
  store i64 %t37, ptr %l3, !tbaa !24
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t39 = load i64, ptr %l3, !tbaa !24
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t40, i32 0, i32 2
  %t43 = load i64, ptr %t42, !tbaa !24
  %t46 = icmp slt i64 %t39, %t43
  br i1 %t46, label %bb10, label %bb11
bb10:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t48, i32 0, i32 2
  %t51 = load i64, ptr %t50, !tbaa !24
  store i64 %t51, ptr %l3, !tbaa !24
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t53, i32 0, i32 0
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  store { i64, ptr } %t56, ptr %l4, !tbaa !27
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l38, !tbaa !29
  %t59 = load i64, ptr %l3, !tbaa !24
  store i64 %t59, ptr %l39, !tbaa !24
  store %"compiler/check:roFn" %a2, ptr %l40
  %t61 = load i64, ptr %l39, !tbaa !24
  %t62 = icmp sge i64 %t61, 0
  br i1 %t62, label %bb13, label %bb14
bb13:
  %t64 = load i64, ptr %l39, !tbaa !24
  %t65 = icmp sle i64 %t64, 144115188075855871
  br i1 %t65, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_509ccf3852e61737_83a0d3f1c5189b03)
  unreachable
bb15:
  %t67 = load i64, ptr %l39, !tbaa !24
  %t68 = mul i64 %t67, 64
  %t69 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t68)
  %t70 = load %"compiler/check:roFn", ptr %l40
  store i64 0, ptr %t71
  br label %fill.72
fill.72:
  %t75 = load i64, ptr %t71
  %t76 = icmp slt i64 %t75, %t67
  br i1 %t76, label %fillb.73, label %filld.74
fillb.73:
  %t77 = getelementptr %"compiler/check:roFn", ptr %t69, i64 %t75
  store %"compiler/check:roFn" %t70, ptr %t77
  %t78 = add i64 %t75, 1
  store i64 %t78, ptr %t71
  br label %fill.72
filld.74:
  %t79 = insertvalue { i64, ptr } undef, i64 %t67, 0
  %t80 = insertvalue { i64, ptr } %t79, ptr %t69, 1
  %t82 = load ptr, ptr %l38, !tbaa !29
  %t83 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t82, i32 0, i32 0
  store { i64, ptr } %t80, ptr %t83, !tbaa !27
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t84, i32 0, i32 0
  %t87 = load { i64, ptr }, ptr %t86, !tbaa !27
  store { i64, ptr } %t87, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t89, i32 0, i32 1
  %t92 = load i64, ptr %t91, !tbaa !24
  store i64 %t92, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t94 = load i64, ptr %l7, !tbaa !24
  %t95 = load i64, ptr %l6, !tbaa !24
  %t98 = icmp sgt i64 %t94, %t95
  br i1 %t98, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_509ccf3852e61737_83a0d3f1c5189b03)
  unreachable
bb17:
  %t100 = load i64, ptr %l8, !tbaa !24
  %t102 = icmp sgt i64 %t100, 0
  br i1 %t102, label %bb19, label %bb20
bb18:
  store i64 0, ptr %l51, !tbaa !24
  br label %bb22
bb19:
  %t104 = load i64, ptr %l7, !tbaa !24
  %t105 = load i64, ptr %l6, !tbaa !24
  %t108 = sub i64 %t104, %t105
  %t109 = load i64, ptr %l8, !tbaa !24
  %t112 = add i64 %t108, %t109
  %t114 = sub i64 %t112, 1
  %t115 = load i64, ptr %l8, !tbaa !24
  %t118 = sdiv i64 %t114, %t115
  store i64 %t118, ptr %l54, !tbaa !24
  br label %bb21
bb20:
  store i64 0, ptr %l54, !tbaa !24
  br label %bb21
bb21:
  %t120 = load i64, ptr %l54, !tbaa !24
  store i64 %t120, ptr %l51, !tbaa !24
  br label %bb22
bb22:
  %t121 = load i64, ptr %l51, !tbaa !24
  store i64 %t121, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb23
bb23:
  %t122 = load i64, ptr %l10, !tbaa !24
  %t123 = load i64, ptr %l9, !tbaa !24
  %t126 = icmp slt i64 %t122, %t123
  %t128 = xor i1 %t126, true
  br i1 %t128, label %bb24, label %bb25
bb24:
  br label %bb28
bb25:
  br label %bb26
bb26:
  %t130 = load i64, ptr %l6, !tbaa !24
  %t131 = load i64, ptr %l10, !tbaa !24
  %t132 = load i64, ptr %l8, !tbaa !24
  %t135 = mul i64 %t131, %t132
  %t138 = add i64 %t130, %t135
  store i64 %t138, ptr %l11, !tbaa !24
  %t140 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t140, ptr %l72, !tbaa !27
  %t141 = load i64, ptr %l11, !tbaa !24
  %t142 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t142, ptr %l74, !tbaa !27
  %t143 = load i64, ptr %l11, !tbaa !24
  %t145 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !27
  %t147 = getelementptr %"compiler/check:roFn", ptr %t146, i64 %t143
  %t148 = load %"compiler/check:roFn", ptr %t147
  %t151 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t152 = load ptr, ptr %t151, !tbaa !27
  %t153 = getelementptr %"compiler/check:roFn", ptr %t152, i64 %t141
  store %"compiler/check:roFn" %t148, ptr %t153
  br label %bb27
bb27:
  %t154 = load i64, ptr %l10, !tbaa !24
  %t156 = add i64 %t154, 1
  store i64 %t156, ptr %l10, !tbaa !24
  br label %bb23
bb28:
  %t158 = load { i64, ptr }, ptr %l4, !tbaa !27
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3ccompiler_2ftyped_3aAlt_26_3e_2ero_Hc63741910c02d3393ef4da4ab79c1538(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  tail call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3ccompiler_2fcond_3aGlobal_26_3e_2e_Hb4cb47390ad0ef69ab85fecf589dd168(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3ccompiler_2ftyped_3aArm_26_3e_2ero_H7337e971b7271b55b974a45e0c93c1ec(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  tail call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3ccompiler_2fcond_3aGlobal_26_3e_2e_Hb4cb47390ad0ef69ab85fecf589dd168(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3ccompiler_2ftyped_3aCapture_26_3e__H19baf9b9a700233d97549a6200ada788(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  tail call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3ccompiler_2fcond_3aGlobal_26_3e_2e_Hb4cb47390ad0ef69ab85fecf589dd168(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3ccompiler_2ftyped_3aScopeRel_3e_2e_H7acc14a50db40391aeef5484b26a9f8b(ptr %v0, ptr %a0, i64 %a1, %"compiler/typed:ScopeRel" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l21 = alloca i64
  %l38 = alloca ptr
  %l39 = alloca i64
  %l40 = alloca %"compiler/typed:ScopeRel"
  %l51 = alloca i64
  %l54 = alloca i64
  %l72 = alloca { i64, ptr }
  %l74 = alloca { i64, ptr }
  %t71 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t2, i32 0, i32 0
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t10 = icmp sle i64 %t1, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t19 = icmp slt i64 %t17, 4
  br i1 %t19, label %bb4, label %bb5
bb4:
  store i64 8, ptr %l21, !tbaa !24
  br label %bb6
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t28 = mul i64 %t26, 2
  store i64 %t28, ptr %l21, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l21, !tbaa !24
  store i64 %t30, ptr %l3, !tbaa !24
  %t31 = load i64, ptr %l3, !tbaa !24
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  br i1 %t35, label %bb7, label %bb8
bb7:
  %t37 = load i64, ptr %l1, !tbaa !24
  store i64 %t37, ptr %l3, !tbaa !24
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t39 = load i64, ptr %l3, !tbaa !24
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t40, i32 0, i32 2
  %t43 = load i64, ptr %t42, !tbaa !24
  %t46 = icmp slt i64 %t39, %t43
  br i1 %t46, label %bb10, label %bb11
bb10:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t48, i32 0, i32 2
  %t51 = load i64, ptr %t50, !tbaa !24
  store i64 %t51, ptr %l3, !tbaa !24
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t53, i32 0, i32 0
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  store { i64, ptr } %t56, ptr %l4, !tbaa !27
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l38, !tbaa !29
  %t59 = load i64, ptr %l3, !tbaa !24
  store i64 %t59, ptr %l39, !tbaa !24
  store %"compiler/typed:ScopeRel" %a2, ptr %l40
  %t61 = load i64, ptr %l39, !tbaa !24
  %t62 = icmp sge i64 %t61, 0
  br i1 %t62, label %bb13, label %bb14
bb13:
  %t64 = load i64, ptr %l39, !tbaa !24
  %t65 = icmp sle i64 %t64, 384307168202282325
  br i1 %t65, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_8068eb64e8c18439_2ac1a5a22634b14d)
  unreachable
bb15:
  %t67 = load i64, ptr %l39, !tbaa !24
  %t68 = mul i64 %t67, 24
  %t69 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t68)
  %t70 = load %"compiler/typed:ScopeRel", ptr %l40
  store i64 0, ptr %t71
  br label %fill.72
fill.72:
  %t75 = load i64, ptr %t71
  %t76 = icmp slt i64 %t75, %t67
  br i1 %t76, label %fillb.73, label %filld.74
fillb.73:
  %t77 = getelementptr %"compiler/typed:ScopeRel", ptr %t69, i64 %t75
  store %"compiler/typed:ScopeRel" %t70, ptr %t77
  %t78 = add i64 %t75, 1
  store i64 %t78, ptr %t71
  br label %fill.72
filld.74:
  %t79 = insertvalue { i64, ptr } undef, i64 %t67, 0
  %t80 = insertvalue { i64, ptr } %t79, ptr %t69, 1
  %t82 = load ptr, ptr %l38, !tbaa !29
  %t83 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t82, i32 0, i32 0
  store { i64, ptr } %t80, ptr %t83, !tbaa !27
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t84, i32 0, i32 0
  %t87 = load { i64, ptr }, ptr %t86, !tbaa !27
  store { i64, ptr } %t87, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t89, i32 0, i32 1
  %t92 = load i64, ptr %t91, !tbaa !24
  store i64 %t92, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t94 = load i64, ptr %l7, !tbaa !24
  %t95 = load i64, ptr %l6, !tbaa !24
  %t98 = icmp sgt i64 %t94, %t95
  br i1 %t98, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_8068eb64e8c18439_2ac1a5a22634b14d)
  unreachable
bb17:
  %t100 = load i64, ptr %l8, !tbaa !24
  %t102 = icmp sgt i64 %t100, 0
  br i1 %t102, label %bb19, label %bb20
bb18:
  store i64 0, ptr %l51, !tbaa !24
  br label %bb22
bb19:
  %t104 = load i64, ptr %l7, !tbaa !24
  %t105 = load i64, ptr %l6, !tbaa !24
  %t108 = sub i64 %t104, %t105
  %t109 = load i64, ptr %l8, !tbaa !24
  %t112 = add i64 %t108, %t109
  %t114 = sub i64 %t112, 1
  %t115 = load i64, ptr %l8, !tbaa !24
  %t118 = sdiv i64 %t114, %t115
  store i64 %t118, ptr %l54, !tbaa !24
  br label %bb21
bb20:
  store i64 0, ptr %l54, !tbaa !24
  br label %bb21
bb21:
  %t120 = load i64, ptr %l54, !tbaa !24
  store i64 %t120, ptr %l51, !tbaa !24
  br label %bb22
bb22:
  %t121 = load i64, ptr %l51, !tbaa !24
  store i64 %t121, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb23
bb23:
  %t122 = load i64, ptr %l10, !tbaa !24
  %t123 = load i64, ptr %l9, !tbaa !24
  %t126 = icmp slt i64 %t122, %t123
  %t128 = xor i1 %t126, true
  br i1 %t128, label %bb24, label %bb25
bb24:
  br label %bb28
bb25:
  br label %bb26
bb26:
  %t130 = load i64, ptr %l6, !tbaa !24
  %t131 = load i64, ptr %l10, !tbaa !24
  %t132 = load i64, ptr %l8, !tbaa !24
  %t135 = mul i64 %t131, %t132
  %t138 = add i64 %t130, %t135
  store i64 %t138, ptr %l11, !tbaa !24
  %t140 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t140, ptr %l72, !tbaa !27
  %t141 = load i64, ptr %l11, !tbaa !24
  %t142 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t142, ptr %l74, !tbaa !27
  %t143 = load i64, ptr %l11, !tbaa !24
  %t145 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !27
  %t147 = getelementptr %"compiler/typed:ScopeRel", ptr %t146, i64 %t143
  %t148 = load %"compiler/typed:ScopeRel", ptr %t147
  %t151 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t152 = load ptr, ptr %t151, !tbaa !27
  %t153 = getelementptr %"compiler/typed:ScopeRel", ptr %t152, i64 %t141
  store %"compiler/typed:ScopeRel" %t148, ptr %t153
  br label %bb27
bb27:
  %t154 = load i64, ptr %l10, !tbaa !24
  %t156 = add i64 %t154, 1
  store i64 %t156, ptr %l10, !tbaa !24
  br label %bb23
bb28:
  %t158 = load { i64, ptr }, ptr %l4, !tbaa !27
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3cstd_2fpair_3aPair_3cI64_2c_20comp_Ha5b6aafa72bb4d87bc8b02da8a3f1e36(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"std/pair:Pair.1eb2466213689e002f25e81e83536e78" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l21 = alloca i64
  %l38 = alloca ptr
  %l39 = alloca i64
  %l40 = alloca %"std/pair:Pair.1eb2466213689e002f25e81e83536e78"
  %l51 = alloca i64
  %l54 = alloca i64
  %l72 = alloca { i64, ptr }
  %l74 = alloca { i64, ptr }
  %t71 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t2, i32 0, i32 0
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t10 = icmp sle i64 %t1, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t19 = icmp slt i64 %t17, 4
  br i1 %t19, label %bb4, label %bb5
bb4:
  store i64 8, ptr %l21, !tbaa !24
  br label %bb6
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t28 = mul i64 %t26, 2
  store i64 %t28, ptr %l21, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l21, !tbaa !24
  store i64 %t30, ptr %l3, !tbaa !24
  %t31 = load i64, ptr %l3, !tbaa !24
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  br i1 %t35, label %bb7, label %bb8
bb7:
  %t37 = load i64, ptr %l1, !tbaa !24
  store i64 %t37, ptr %l3, !tbaa !24
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t39 = load i64, ptr %l3, !tbaa !24
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t40, i32 0, i32 2
  %t43 = load i64, ptr %t42, !tbaa !24
  %t46 = icmp slt i64 %t39, %t43
  br i1 %t46, label %bb10, label %bb11
bb10:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t48, i32 0, i32 2
  %t51 = load i64, ptr %t50, !tbaa !24
  store i64 %t51, ptr %l3, !tbaa !24
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t53, i32 0, i32 0
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  store { i64, ptr } %t56, ptr %l4, !tbaa !27
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l38, !tbaa !29
  %t59 = load i64, ptr %l3, !tbaa !24
  store i64 %t59, ptr %l39, !tbaa !24
  store %"std/pair:Pair.1eb2466213689e002f25e81e83536e78" %a2, ptr %l40
  %t61 = load i64, ptr %l39, !tbaa !24
  %t62 = icmp sge i64 %t61, 0
  br i1 %t62, label %bb13, label %bb14
bb13:
  %t64 = load i64, ptr %l39, !tbaa !24
  %t65 = icmp sle i64 %t64, 576460752303423487
  br i1 %t65, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_97d6ab9891a1a2e7_a0781825def5a92b)
  unreachable
bb15:
  %t67 = load i64, ptr %l39, !tbaa !24
  %t68 = mul i64 %t67, 16
  %t69 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t68)
  %t70 = load %"std/pair:Pair.1eb2466213689e002f25e81e83536e78", ptr %l40
  store i64 0, ptr %t71
  br label %fill.72
fill.72:
  %t75 = load i64, ptr %t71
  %t76 = icmp slt i64 %t75, %t67
  br i1 %t76, label %fillb.73, label %filld.74
fillb.73:
  %t77 = getelementptr %"std/pair:Pair.1eb2466213689e002f25e81e83536e78", ptr %t69, i64 %t75
  store %"std/pair:Pair.1eb2466213689e002f25e81e83536e78" %t70, ptr %t77
  %t78 = add i64 %t75, 1
  store i64 %t78, ptr %t71
  br label %fill.72
filld.74:
  %t79 = insertvalue { i64, ptr } undef, i64 %t67, 0
  %t80 = insertvalue { i64, ptr } %t79, ptr %t69, 1
  %t82 = load ptr, ptr %l38, !tbaa !29
  %t83 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t82, i32 0, i32 0
  store { i64, ptr } %t80, ptr %t83, !tbaa !27
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t84, i32 0, i32 0
  %t87 = load { i64, ptr }, ptr %t86, !tbaa !27
  store { i64, ptr } %t87, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t89, i32 0, i32 1
  %t92 = load i64, ptr %t91, !tbaa !24
  store i64 %t92, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t94 = load i64, ptr %l7, !tbaa !24
  %t95 = load i64, ptr %l6, !tbaa !24
  %t98 = icmp sgt i64 %t94, %t95
  br i1 %t98, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_97d6ab9891a1a2e7_a0781825def5a92b)
  unreachable
bb17:
  %t100 = load i64, ptr %l8, !tbaa !24
  %t102 = icmp sgt i64 %t100, 0
  br i1 %t102, label %bb19, label %bb20
bb18:
  store i64 0, ptr %l51, !tbaa !24
  br label %bb22
bb19:
  %t104 = load i64, ptr %l7, !tbaa !24
  %t105 = load i64, ptr %l6, !tbaa !24
  %t108 = sub i64 %t104, %t105
  %t109 = load i64, ptr %l8, !tbaa !24
  %t112 = add i64 %t108, %t109
  %t114 = sub i64 %t112, 1
  %t115 = load i64, ptr %l8, !tbaa !24
  %t118 = sdiv i64 %t114, %t115
  store i64 %t118, ptr %l54, !tbaa !24
  br label %bb21
bb20:
  store i64 0, ptr %l54, !tbaa !24
  br label %bb21
bb21:
  %t120 = load i64, ptr %l54, !tbaa !24
  store i64 %t120, ptr %l51, !tbaa !24
  br label %bb22
bb22:
  %t121 = load i64, ptr %l51, !tbaa !24
  store i64 %t121, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb23
bb23:
  %t122 = load i64, ptr %l10, !tbaa !24
  %t123 = load i64, ptr %l9, !tbaa !24
  %t126 = icmp slt i64 %t122, %t123
  %t128 = xor i1 %t126, true
  br i1 %t128, label %bb24, label %bb25
bb24:
  br label %bb28
bb25:
  br label %bb26
bb26:
  %t130 = load i64, ptr %l6, !tbaa !24
  %t131 = load i64, ptr %l10, !tbaa !24
  %t132 = load i64, ptr %l8, !tbaa !24
  %t135 = mul i64 %t131, %t132
  %t138 = add i64 %t130, %t135
  store i64 %t138, ptr %l11, !tbaa !24
  %t140 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t140, ptr %l72, !tbaa !27
  %t141 = load i64, ptr %l11, !tbaa !24
  %t142 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t142, ptr %l74, !tbaa !27
  %t143 = load i64, ptr %l11, !tbaa !24
  %t145 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !27
  %t147 = getelementptr %"std/pair:Pair.1eb2466213689e002f25e81e83536e78", ptr %t146, i64 %t143
  %t148 = load %"std/pair:Pair.1eb2466213689e002f25e81e83536e78", ptr %t147
  %t151 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t152 = load ptr, ptr %t151, !tbaa !27
  %t153 = getelementptr %"std/pair:Pair.1eb2466213689e002f25e81e83536e78", ptr %t152, i64 %t141
  store %"std/pair:Pair.1eb2466213689e002f25e81e83536e78" %t148, ptr %t153
  br label %bb27
bb27:
  %t154 = load i64, ptr %l10, !tbaa !24
  %t156 = add i64 %t154, 1
  store i64 %t156, ptr %l10, !tbaa !24
  br label %bb23
bb28:
  %t158 = load { i64, ptr }, ptr %l4, !tbaa !27
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3cstd_2fpair_3aPair_3ccompiler_2fge_Hb28020b5ab5ebd850e86f0b7d1d32a6e(ptr %v0, ptr %a0, i64 %a1, %"std/pair:Pair.0eea5a06f8f0107e600fd23235f2e98f" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l21 = alloca i64
  %l38 = alloca ptr
  %l39 = alloca i64
  %l40 = alloca %"std/pair:Pair.0eea5a06f8f0107e600fd23235f2e98f"
  %l51 = alloca i64
  %l54 = alloca i64
  %l72 = alloca { i64, ptr }
  %l74 = alloca { i64, ptr }
  %t71 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t2, i32 0, i32 0
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t10 = icmp sle i64 %t1, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t19 = icmp slt i64 %t17, 4
  br i1 %t19, label %bb4, label %bb5
bb4:
  store i64 8, ptr %l21, !tbaa !24
  br label %bb6
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t28 = mul i64 %t26, 2
  store i64 %t28, ptr %l21, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l21, !tbaa !24
  store i64 %t30, ptr %l3, !tbaa !24
  %t31 = load i64, ptr %l3, !tbaa !24
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  br i1 %t35, label %bb7, label %bb8
bb7:
  %t37 = load i64, ptr %l1, !tbaa !24
  store i64 %t37, ptr %l3, !tbaa !24
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t39 = load i64, ptr %l3, !tbaa !24
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t40, i32 0, i32 2
  %t43 = load i64, ptr %t42, !tbaa !24
  %t46 = icmp slt i64 %t39, %t43
  br i1 %t46, label %bb10, label %bb11
bb10:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t48, i32 0, i32 2
  %t51 = load i64, ptr %t50, !tbaa !24
  store i64 %t51, ptr %l3, !tbaa !24
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t53, i32 0, i32 0
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  store { i64, ptr } %t56, ptr %l4, !tbaa !27
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l38, !tbaa !29
  %t59 = load i64, ptr %l3, !tbaa !24
  store i64 %t59, ptr %l39, !tbaa !24
  store %"std/pair:Pair.0eea5a06f8f0107e600fd23235f2e98f" %a2, ptr %l40
  %t61 = load i64, ptr %l39, !tbaa !24
  %t62 = icmp sge i64 %t61, 0
  br i1 %t62, label %bb13, label %bb14
bb13:
  %t64 = load i64, ptr %l39, !tbaa !24
  %t65 = icmp sle i64 %t64, 288230376151711743
  br i1 %t65, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_85ed6fc19a4613eb_2f88795f71aff89f)
  unreachable
bb15:
  %t67 = load i64, ptr %l39, !tbaa !24
  %t68 = mul i64 %t67, 32
  %t69 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t68)
  %t70 = load %"std/pair:Pair.0eea5a06f8f0107e600fd23235f2e98f", ptr %l40
  store i64 0, ptr %t71
  br label %fill.72
fill.72:
  %t75 = load i64, ptr %t71
  %t76 = icmp slt i64 %t75, %t67
  br i1 %t76, label %fillb.73, label %filld.74
fillb.73:
  %t77 = getelementptr %"std/pair:Pair.0eea5a06f8f0107e600fd23235f2e98f", ptr %t69, i64 %t75
  store %"std/pair:Pair.0eea5a06f8f0107e600fd23235f2e98f" %t70, ptr %t77
  %t78 = add i64 %t75, 1
  store i64 %t78, ptr %t71
  br label %fill.72
filld.74:
  %t79 = insertvalue { i64, ptr } undef, i64 %t67, 0
  %t80 = insertvalue { i64, ptr } %t79, ptr %t69, 1
  %t82 = load ptr, ptr %l38, !tbaa !29
  %t83 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t82, i32 0, i32 0
  store { i64, ptr } %t80, ptr %t83, !tbaa !27
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t84, i32 0, i32 0
  %t87 = load { i64, ptr }, ptr %t86, !tbaa !27
  store { i64, ptr } %t87, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t89, i32 0, i32 1
  %t92 = load i64, ptr %t91, !tbaa !24
  store i64 %t92, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t94 = load i64, ptr %l7, !tbaa !24
  %t95 = load i64, ptr %l6, !tbaa !24
  %t98 = icmp sgt i64 %t94, %t95
  br i1 %t98, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_85ed6fc19a4613eb_2f88795f71aff89f)
  unreachable
bb17:
  %t100 = load i64, ptr %l8, !tbaa !24
  %t102 = icmp sgt i64 %t100, 0
  br i1 %t102, label %bb19, label %bb20
bb18:
  store i64 0, ptr %l51, !tbaa !24
  br label %bb22
bb19:
  %t104 = load i64, ptr %l7, !tbaa !24
  %t105 = load i64, ptr %l6, !tbaa !24
  %t108 = sub i64 %t104, %t105
  %t109 = load i64, ptr %l8, !tbaa !24
  %t112 = add i64 %t108, %t109
  %t114 = sub i64 %t112, 1
  %t115 = load i64, ptr %l8, !tbaa !24
  %t118 = sdiv i64 %t114, %t115
  store i64 %t118, ptr %l54, !tbaa !24
  br label %bb21
bb20:
  store i64 0, ptr %l54, !tbaa !24
  br label %bb21
bb21:
  %t120 = load i64, ptr %l54, !tbaa !24
  store i64 %t120, ptr %l51, !tbaa !24
  br label %bb22
bb22:
  %t121 = load i64, ptr %l51, !tbaa !24
  store i64 %t121, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb23
bb23:
  %t122 = load i64, ptr %l10, !tbaa !24
  %t123 = load i64, ptr %l9, !tbaa !24
  %t126 = icmp slt i64 %t122, %t123
  %t128 = xor i1 %t126, true
  br i1 %t128, label %bb24, label %bb25
bb24:
  br label %bb28
bb25:
  br label %bb26
bb26:
  %t130 = load i64, ptr %l6, !tbaa !24
  %t131 = load i64, ptr %l10, !tbaa !24
  %t132 = load i64, ptr %l8, !tbaa !24
  %t135 = mul i64 %t131, %t132
  %t138 = add i64 %t130, %t135
  store i64 %t138, ptr %l11, !tbaa !24
  %t140 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t140, ptr %l72, !tbaa !27
  %t141 = load i64, ptr %l11, !tbaa !24
  %t142 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t142, ptr %l74, !tbaa !27
  %t143 = load i64, ptr %l11, !tbaa !24
  %t145 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !27
  %t147 = getelementptr %"std/pair:Pair.0eea5a06f8f0107e600fd23235f2e98f", ptr %t146, i64 %t143
  %t148 = load %"std/pair:Pair.0eea5a06f8f0107e600fd23235f2e98f", ptr %t147
  %t151 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t152 = load ptr, ptr %t151, !tbaa !27
  %t153 = getelementptr %"std/pair:Pair.0eea5a06f8f0107e600fd23235f2e98f", ptr %t152, i64 %t141
  store %"std/pair:Pair.0eea5a06f8f0107e600fd23235f2e98f" %t148, ptr %t153
  br label %bb27
bb27:
  %t154 = load i64, ptr %l10, !tbaa !24
  %t156 = add i64 %t154, 1
  store i64 %t156, ptr %l10, !tbaa !24
  br label %bb23
bb28:
  %t158 = load { i64, ptr }, ptr %l4, !tbaa !27
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3cstd_2fpair_3aPair_3ccompiler_2fso_Hddc1a62de6709285050be553b0a219e5(ptr %v0, ptr %a0, i64 %a1, %"std/pair:Pair.91de8c8eb84d52d1e58996aec31d85aa" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l21 = alloca i64
  %l38 = alloca ptr
  %l39 = alloca i64
  %l40 = alloca %"std/pair:Pair.91de8c8eb84d52d1e58996aec31d85aa"
  %l51 = alloca i64
  %l54 = alloca i64
  %l72 = alloca { i64, ptr }
  %l74 = alloca { i64, ptr }
  %t71 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t2, i32 0, i32 0
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t10 = icmp sle i64 %t1, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t19 = icmp slt i64 %t17, 4
  br i1 %t19, label %bb4, label %bb5
bb4:
  store i64 8, ptr %l21, !tbaa !24
  br label %bb6
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t28 = mul i64 %t26, 2
  store i64 %t28, ptr %l21, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l21, !tbaa !24
  store i64 %t30, ptr %l3, !tbaa !24
  %t31 = load i64, ptr %l3, !tbaa !24
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  br i1 %t35, label %bb7, label %bb8
bb7:
  %t37 = load i64, ptr %l1, !tbaa !24
  store i64 %t37, ptr %l3, !tbaa !24
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t39 = load i64, ptr %l3, !tbaa !24
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t40, i32 0, i32 2
  %t43 = load i64, ptr %t42, !tbaa !24
  %t46 = icmp slt i64 %t39, %t43
  br i1 %t46, label %bb10, label %bb11
bb10:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t48, i32 0, i32 2
  %t51 = load i64, ptr %t50, !tbaa !24
  store i64 %t51, ptr %l3, !tbaa !24
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t53, i32 0, i32 0
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  store { i64, ptr } %t56, ptr %l4, !tbaa !27
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l38, !tbaa !29
  %t59 = load i64, ptr %l3, !tbaa !24
  store i64 %t59, ptr %l39, !tbaa !24
  store %"std/pair:Pair.91de8c8eb84d52d1e58996aec31d85aa" %a2, ptr %l40
  %t61 = load i64, ptr %l39, !tbaa !24
  %t62 = icmp sge i64 %t61, 0
  br i1 %t62, label %bb13, label %bb14
bb13:
  %t64 = load i64, ptr %l39, !tbaa !24
  %t65 = icmp sle i64 %t64, 1152921504606846975
  br i1 %t65, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_71ed43b97f093f2f_4c4bfdc242e91c33)
  unreachable
bb15:
  %t67 = load i64, ptr %l39, !tbaa !24
  %t68 = mul i64 %t67, 8
  %t69 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t68)
  %t70 = load %"std/pair:Pair.91de8c8eb84d52d1e58996aec31d85aa", ptr %l40
  store i64 0, ptr %t71
  br label %fill.72
fill.72:
  %t75 = load i64, ptr %t71
  %t76 = icmp slt i64 %t75, %t67
  br i1 %t76, label %fillb.73, label %filld.74
fillb.73:
  %t77 = getelementptr %"std/pair:Pair.91de8c8eb84d52d1e58996aec31d85aa", ptr %t69, i64 %t75
  store %"std/pair:Pair.91de8c8eb84d52d1e58996aec31d85aa" %t70, ptr %t77
  %t78 = add i64 %t75, 1
  store i64 %t78, ptr %t71
  br label %fill.72
filld.74:
  %t79 = insertvalue { i64, ptr } undef, i64 %t67, 0
  %t80 = insertvalue { i64, ptr } %t79, ptr %t69, 1
  %t82 = load ptr, ptr %l38, !tbaa !29
  %t83 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t82, i32 0, i32 0
  store { i64, ptr } %t80, ptr %t83, !tbaa !27
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t84, i32 0, i32 0
  %t87 = load { i64, ptr }, ptr %t86, !tbaa !27
  store { i64, ptr } %t87, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t89, i32 0, i32 1
  %t92 = load i64, ptr %t91, !tbaa !24
  store i64 %t92, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t94 = load i64, ptr %l7, !tbaa !24
  %t95 = load i64, ptr %l6, !tbaa !24
  %t98 = icmp sgt i64 %t94, %t95
  br i1 %t98, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_71ed43b97f093f2f_4c4bfdc242e91c33)
  unreachable
bb17:
  %t100 = load i64, ptr %l8, !tbaa !24
  %t102 = icmp sgt i64 %t100, 0
  br i1 %t102, label %bb19, label %bb20
bb18:
  store i64 0, ptr %l51, !tbaa !24
  br label %bb22
bb19:
  %t104 = load i64, ptr %l7, !tbaa !24
  %t105 = load i64, ptr %l6, !tbaa !24
  %t108 = sub i64 %t104, %t105
  %t109 = load i64, ptr %l8, !tbaa !24
  %t112 = add i64 %t108, %t109
  %t114 = sub i64 %t112, 1
  %t115 = load i64, ptr %l8, !tbaa !24
  %t118 = sdiv i64 %t114, %t115
  store i64 %t118, ptr %l54, !tbaa !24
  br label %bb21
bb20:
  store i64 0, ptr %l54, !tbaa !24
  br label %bb21
bb21:
  %t120 = load i64, ptr %l54, !tbaa !24
  store i64 %t120, ptr %l51, !tbaa !24
  br label %bb22
bb22:
  %t121 = load i64, ptr %l51, !tbaa !24
  store i64 %t121, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb23
bb23:
  %t122 = load i64, ptr %l10, !tbaa !24
  %t123 = load i64, ptr %l9, !tbaa !24
  %t126 = icmp slt i64 %t122, %t123
  %t128 = xor i1 %t126, true
  br i1 %t128, label %bb24, label %bb25
bb24:
  br label %bb28
bb25:
  br label %bb26
bb26:
  %t130 = load i64, ptr %l6, !tbaa !24
  %t131 = load i64, ptr %l10, !tbaa !24
  %t132 = load i64, ptr %l8, !tbaa !24
  %t135 = mul i64 %t131, %t132
  %t138 = add i64 %t130, %t135
  store i64 %t138, ptr %l11, !tbaa !24
  %t140 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t140, ptr %l72, !tbaa !27
  %t141 = load i64, ptr %l11, !tbaa !24
  %t142 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t142, ptr %l74, !tbaa !27
  %t143 = load i64, ptr %l11, !tbaa !24
  %t145 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !27
  %t147 = getelementptr %"std/pair:Pair.91de8c8eb84d52d1e58996aec31d85aa", ptr %t146, i64 %t143
  %t148 = load %"std/pair:Pair.91de8c8eb84d52d1e58996aec31d85aa", ptr %t147
  %t151 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t152 = load ptr, ptr %t151, !tbaa !27
  %t153 = getelementptr %"std/pair:Pair.91de8c8eb84d52d1e58996aec31d85aa", ptr %t152, i64 %t141
  store %"std/pair:Pair.91de8c8eb84d52d1e58996aec31d85aa" %t148, ptr %t153
  br label %bb27
bb27:
  %t154 = load i64, ptr %l10, !tbaa !24
  %t156 = add i64 %t154, 1
  store i64 %t156, ptr %l10, !tbaa !24
  br label %bb23
bb28:
  %t158 = load { i64, ptr }, ptr %l4, !tbaa !27
  br label %ret
ret:
  ret void
}

define dso_local %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fast_3aPattern_26_3e_26_3e_2ector(ptr %v0, i64 %a0) #0 {
entry:
  %r = tail call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString_26_3e_26_3e_2ector(ptr %v0, i64 %a0)
  ret %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %r
}

define dso_local %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aAsk_3e_2ector(ptr %v0, i64 %a0) #0 {
entry:
  %r = tail call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aUnit_3e_2ector(ptr %v0, i64 %a0)
  ret %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %r
}

define dso_local %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aAssertAsk_3e_2ector(ptr %v0, i64 %a0) #0 {
entry:
  %l3 = alloca %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3ccompiler_2fcheck_3aAssertAsk_3e_2ector(ptr %v0, i64 %a0)
  store %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t5 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %t5
  %t8 = insertvalue %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" undef, ptr %t5, 0
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aContractAsk_3e_2ector(ptr %v0, i64 %a0) #0 {
entry:
  %l3 = alloca %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3ccompiler_2fcheck_3aContractAsk_3e_2ector(ptr %v0, i64 %a0)
  store %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t5 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %t5
  %t8 = insertvalue %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" undef, ptr %t5, 0
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aatRec_3e_2ector(ptr %v0, i64 %a0) #0 {
entry:
  %r = tail call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aGap_3e_2ector(ptr %v0, i64 %a0)
  ret %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %r
}

define dso_local %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aroArg_3e_2ector(ptr %v0, i64 %a0) #0 {
entry:
  %l3 = alloca %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3ccompiler_2fcheck_3aroArg_3e_2ector(ptr %v0, i64 %a0)
  store %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t5 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %t5
  %t8 = insertvalue %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" undef, ptr %t5, 0
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aroDeepArg_3e_2ector(ptr %v0, i64 %a0) #0 {
entry:
  %r = tail call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aGap_3e_2ector(ptr %v0, i64 %a0)
  ret %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %r
}

define dso_local %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aroFn_3e_2ector(ptr %v0, i64 %a0) #0 {
entry:
  %r = tail call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fload_3aImport_3e_2ector(ptr %v0, i64 %a0)
  ret %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %r
}

define dso_local %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aArm_26_3e_2ector(ptr %v0, i64 %a0) #0 {
entry:
  %r = tail call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cU64_3e_2ector(ptr %v0, i64 %a0)
  ret %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %r
}

define dso_local %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aCapture_26_3e_2ector(ptr %v0, i64 %a0) #0 {
entry:
  %r = tail call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cU64_3e_2ector(ptr %v0, i64 %a0)
  ret %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %r
}

define dso_local %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPiece_26_3e_2ector(ptr %v0, i64 %a0) #0 {
entry:
  %r = tail call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cU64_3e_2ector(ptr %v0, i64 %a0)
  ret %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %r
}

define dso_local %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ector(ptr %v0, i64 %a0) #0 {
entry:
  %r = tail call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cU64_3e_2ector(ptr %v0, i64 %a0)
  ret %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %r
}

define dso_local %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aTaskClause_26_3e_2ector(ptr %v0, i64 %a0) #0 {
entry:
  %r = tail call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cU64_3e_2ector(ptr %v0, i64 %a0)
  ret %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %r
}

define dso_local %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2ector(ptr %v0, i64 %a0) #0 {
entry:
  %r = tail call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cU64_3e_2ector(ptr %v0, i64 %a0)
  ret %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %r
}

define dso_local %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_3e_2ector(ptr %v0, i64 %a0) #0 {
entry:
  %r = tail call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString_26_3e_26_3e_2ector(ptr %v0, i64 %a0)
  ret %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %r
}

define dso_local %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_3e_2ector(ptr %v0, i64 %a0) #0 {
entry:
  %r = tail call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString_26_3e_26_3e_2ector(ptr %v0, i64 %a0)
  ret %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %r
}

define dso_local %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_2_Hedf46d61a7b7e16110f4585b041de150(ptr %v0, i64 %a0) #0 {
entry:
  %r = tail call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aGap_3e_2ector(ptr %v0, i64 %a0)
  ret %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %r
}

define dso_local %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3cArray_3ccompiler_2ftyped_3aExpr_26_3e_26_3e_2ector(ptr %v0, i64 %a0) #0 {
entry:
  %r = tail call %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3cArray_3cstd_2fprelude_2ftext_3aString_26_3e_26_3e_2ector(ptr %v0, i64 %a0)
  ret %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" %r
}

define dso_local %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3ccompiler_2fcheck_3aEmbedAsk_3e_2ector(ptr %v0, i64 %a0) #0 {
entry:
  %r = tail call %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3ccompiler_2fgeneric_3aOrigin_3e_2ector(ptr %v0, i64 %a0)
  ret %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" %r
}

define dso_local %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3ccompiler_2fcheck_3aGap_3e_2ector(ptr %v0, i64 %a0) #0 {
entry:
  %r = tail call %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3ccompiler_2fscope_3aGap_3e_2ector(ptr %v0, i64 %a0)
  ret %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" %r
}

define dso_local %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3ccompiler_2fcheck_3aValueAsk_3e_2ector(ptr %v0, i64 %a0) #0 {
entry:
  %r = tail call %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3ccompiler_2fdiag_3aItem_3e_2ector(ptr %v0, i64 %a0)
  ret %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" %r
}

define dso_local %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3ccompiler_2fcheck_3aerrBind_3e_2ector(ptr %v0, i64 %a0) #0 {
entry:
  %r = tail call %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3ccompiler_2fscope_3aGap_3e_2ector(ptr %v0, i64 %a0)
  ret %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" %r
}

define dso_local %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3ccompiler_2fcheck_3aerrNarrow_3e_2ector(ptr %v0, i64 %a0) #0 {
entry:
  %r = tail call %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3ccompiler_2fgeneric_3aOrigin_3e_2ector(ptr %v0, i64 %a0)
  ret %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" %r
}

define dso_local %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3ccompiler_2fcheck_3alaneNode_3e_2ector(ptr %v0, i64 %a0) #0 {
entry:
  %r = tail call %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3ccompiler_2fdiag_3arecord_3e_2ector(ptr %v0, i64 %a0)
  ret %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" %r
}

define dso_local %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3ccompiler_2fcheck_3anarrowed_3e_2ector(ptr %v0, i64 %a0) #0 {
entry:
  %r = tail call %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3ccompiler_2fscope_3afnUse_3e_2ector(ptr %v0, i64 %a0)
  ret %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" %r
}

define dso_local %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3ccompiler_2fcheck_3anullNarrow_3e_2ector(ptr %v0, i64 %a0) #0 {
entry:
  %r = tail call %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3ccompiler_2fscope_3aGap_3e_2ector(ptr %v0, i64 %a0)
  ret %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" %r
}

define dso_local %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3ccompiler_2fcheck_3atypeCase_3e_2ector(ptr %v0, i64 %a0) #0 {
entry:
  %r = tail call %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3ccompiler_2fscope_3aGap_3e_2ector(ptr %v0, i64 %a0)
  ret %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" %r
}

define dso_local %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3ccompiler_2ftyped_3aAlt_26_3e_2ector(ptr %v0, i64 %a0) #0 {
entry:
  %r = tail call %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3cU64_3e_2ector(ptr %v0, i64 %a0)
  ret %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" %r
}

define dso_local %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3ccompiler_2ftyped_3aBind_26_3e_2ector(ptr %v0, i64 %a0) #0 {
entry:
  %r = tail call %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3cU64_3e_2ector(ptr %v0, i64 %a0)
  ret %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" %r
}

define dso_local %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3ccompiler_2ftyped_3aClause_26_3e_2ector(ptr %v0, i64 %a0) #0 {
entry:
  %r = tail call %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3cU64_3e_2ector(ptr %v0, i64 %a0)
  ret %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" %r
}

define dso_local %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3cmut_20compiler_2ftyped_3aBody_26_3e_2ector(ptr %v0, i64 %a0) #0 {
entry:
  %r = tail call %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3cU64_3e_2ector(ptr %v0, i64 %a0)
  ret %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" %r
}

define dso_local %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3cstd_2fpair_3aPair_3ccompiler_2fgeneric_3aOrigin_2c_20I64_3e_3e_2ector(ptr %v0, i64 %a0) #0 {
entry:
  %r = tail call %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3ccompiler_2fscope_3aGap_3e_2ector(ptr %v0, i64 %a0)
  ret %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" %r
}

define dso_local %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3cstd_2fpair_3aPair_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_H22ce26aaf83631e2814b013a87627485(ptr %v0, i64 %a0) #0 {
entry:
  %r = tail call %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3ccompiler_2fscope_3aGap_3e_2ector(ptr %v0, i64 %a0)
  ret %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" %r
}

declare void @__olang_check_failed(ptr)
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2estd_2fpair_3aPair_3cI64_2c_20I64_3e(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = getelementptr %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %t1, i32 0, i32 0
  %t3 = load i64, ptr %t2, !tbaa !24
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t5 = getelementptr %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %t4, i32 0, i32 0
  %t6 = load i64, ptr %t5, !tbaa !24
  %t9 = icmp eq i64 %t3, %t6
  br i1 %t9, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb4
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %t11, i32 0, i32 1
  %t13 = load i64, ptr %t12, !tbaa !24
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %t14, i32 0, i32 1
  %t16 = load i64, ptr %t15, !tbaa !24
  %t19 = icmp eq i64 %t13, %t16
  br i1 %t19, label %bb3, label %bb1
bb3:
  br label %bb4
bb4:
  %t21 = load i1, ptr %l2, !tbaa !21
  store i1 %t21, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@olang_loc_f08d1cd84d5664bf_7f8b445f2be8b9e3 = external constant [0 x i8]
@olang_loc_3a71773c68f3d9ea_62ce35ef480fba6e = external constant [0 x i8]
@G_2estd_2flist_2efirstChunk = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\08\00\00\00\00\00\00\00" }>, align 8
@olang_loc_4ecb415fcfbe9b59_88114aadccd2637d = external constant [0 x i8]
@olang_loc_34e5301f43e4e84c_cc350fb9ff4bb650 = external constant [0 x i8]
@olang_loc_58092ffe9980adaf_794c3d04db71ce73 = external constant [0 x i8]
@olang_loc_3c9fcdae779a95da_a192967db0cbff3e = external constant [0 x i8]
@olang_loc_9c26c043f6adbd37_4eba68de8fa37583 = external constant [0 x i8]
@olang_loc_93916db8879de882_a38eb1e37fdd568e = external constant [0 x i8]
@olang_loc_5380aff59a2be5a1_77ecbad11d54d68d = external constant [0 x i8]
declare i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cI64_2c_20Bool_3e_2ebucketOf_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_Hc57530578add1ad359c6d87470cc4752(ptr %v0, ptr %a0, i64 %a1)
declare { i32, ptr } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_H68cd31c3dbcdb47f3349b834dda1e07d(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cI64_2c_20compiler_2fdiag_3aWhere__Ha2beffd59aa8cf27179d2e8906b62049(ptr %v0, ptr %a0, i64 %a1, i64 %a2, { i64, [3 x i64] } %a3)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftypes_3aDeclId_3e__H7ddd7dd10a6733ce5265405d8e7c8faa(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3ccompiler_2fsource_3aNameId_2c_20B_Heab357d0b792d165805bc071c98cf6d1(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cstd_2fpair_3aPair_3cI64_2c_20I64__H25550a5aa964c9352053a58344d5fc74(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cI64_2c_20compiler_2ftyped_3aExpr__H6646a6f2a04f565d0bff5df703125aa2(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, ptr %a3)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cI64_2c_20compiler_2ftyped_3aExpr__H027e3b5d3e589e6555ba51c13998d337(ptr %v0, ptr %a0)
declare %"std/prelude/map:mapSlot.0482058481105505dc7df18be1ecde54" @std_2fprelude_2fmap_3amapSlot_3cI64_2c_20compiler_2ftyped_3aContractInfo_3e_2ector(ptr %v0, ptr %v1, ptr %v2, i64 %a0, %"compiler/typed:ContractInfo" %a1, ptr %a2)
declare %"std/prelude/map:MapEntry.30ce370d829aff239a34c06a62e67c2e" @std_2fprelude_2fmap_3aMapEntry_3cI64_2c_20compiler_2ftyped_3aContractInfo_3e_2ector(ptr %v0, ptr %v1, i64 %a0, %"compiler/typed:ContractInfo" %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cI64_2c_20compiler_2ftyped_3aContr_H20853fbbac28f6a5fef071a48c93be5b(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cI64_2c_20compiler_2ftypes_3aDeclI_H4c1de9fecd9c99d5a63a8f7c9df161c3(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cI64_2c_20compiler_2ftypes_3aDeclI_H9f3979565f0fefdf5266a328cdc0c138(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i32 %a3)
@olang_loc_b3cca19c3c2efe3_f96c380b9c020d2f = external constant [0 x i8]
@olang_loc_45f508538682dd99_32966c8d2ce9c445 = external constant [0 x i8]
declare %"std/prelude/map:mapSlot.fb4da8fc57bf420be68a6f6108589d27" @std_2fprelude_2fmap_3amapSlot_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20compiler_2fcheck_3aroOrigin_3e_2ector(ptr %v0, ptr %v1, ptr %v2, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a0, %"compiler/check:roOrigin" %a1, ptr %a2)
declare %"std/prelude/map:MapEntry.cae77de4d581cc3ff23f947d2513f613" @std_2fprelude_2fmap_3aMapEntry_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20compiler_2fcheck_3aroOrigin_3e_2ector(ptr %v0, ptr %v1, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a0, %"compiler/check:roOrigin" %a1)
@olang_loc_e8495525dc2bdb1_7683e0c7bf654c8d = external constant [0 x i8]
declare %"std/prelude/map:mapSlot.a04f5d5eeace3a348c0931984fa7d629" @std_2fprelude_2fmap_3amapSlot_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20std_2fprelude_2_Hb83c0b69e22e3a58293f016f45f101c9(ptr %v0, ptr %v1, ptr %v2, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a0, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %a1, ptr %a2)
declare %"std/prelude/map:MapEntry.ecf182cf123eba82aed5d6288e5f1385" @std_2fprelude_2fmap_3aMapEntry_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20std_2fprelude__H972fbc2a6787a46672b861de27ed2680(ptr %v0, ptr %v1, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a0, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3amapState_3cstd_2fpair_3aPair_3cI64_2c_20I64__H10a253586b55b0b9df1fc9ef69d3e984(ptr %v0, ptr %a0)
declare %"std/prelude/map:MapEntry.1eb2466213689e002f25e81e83536e78" @std_2fprelude_2fmap_3aMapEntry_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_2ector(ptr %v0, ptr %v1, i64 %a0, ptr %a1)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20compiler_2fsource_3aNameId_3e_2ector(ptr %v0)
declare %"std/prelude/map:mapSlot.13b431b0462eb7c9b33f2a6ba793b9e3" @std_2fprelude_2fmap_3amapSlot_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_2ector(ptr %v0, ptr %v1, ptr %v2, i64 %a0, ptr %a1, ptr %a2)
declare %"std/prelude/map:mapState.57cbc4f4214b93b54249c1f96c98ec50" @std_2fprelude_2fmap_3amapState_3cstd_2fprelude_2ftext_3aString_26_2c_20compiler_2fsource_3aNameId_3e_2ector(ptr %v0)
@olang_loc_588409ee20632e7_5b202286b88aa413 = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2eisPrefixed(ptr %v0, { i64, ptr } %a0)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseUint(ptr %v0, { i64, ptr } %a0, i64 %a1)
declare i64 @std_2fprelude_2ftext_2edigitWorth(i8 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__Hdba28025cac729fb3c994cc5728b4c22(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aCaseDecl_26_3e_2eToAr_H44f8de0685d71649bf169c234c7a8f4c(ptr %v0, ptr %v1, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3ccompiler_2fcheck_3aContractAsk_3e_H16179866dea527591a784fab5866e9a3(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3ccompiler_2fcheck_3alaneNode_3e_2e_H1c8c3738d9f3771d0b332589cc5b744e(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/check:laneNode" %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3ccompiler_2fcheck_3atypeCase_3e_2e_Ha8f88e37efd08b8919887513d3af4e23(ptr %v0, ptr %a0, i64 %a1, %"compiler/check:typeCase" %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcond_3aGlobal_26_3e_2ePush_3ccompiler_2fcond_3aGlobal_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aDecl_26_3e_2eTruncate_3ccompiler_2fast_3aDecl_26_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_aa901beb98c060b_80101196ceb80547 = external constant [0 x i8]
@olang_loc_f2d634f02e5f6b76_33cef94e1615a252 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eTrunca_H0175749ab7aa0aad23a4aa22bc447819(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_530ba18c40bfa485_9e285f876d3dfc21 = external constant [0 x i8]
@olang_loc_e21453debf04748b_2a156cb95fbac447 = external constant [0 x i8]
@olang_loc_c2290bc0d93d8d47_960808febb9e8c03 = external constant [0 x i8]
@olang_loc_115385e8fa9135f5_858b7c4a21055d9 = external constant [0 x i8]
@olang_loc_3971deb537adcc61_49fa7999ff18665d = external constant [0 x i8]
@olang_loc_7f438bdc5a5c0271_9c265596c4f6a85d = external constant [0 x i8]
@olang_loc_496b2f5817ced6f9_10bf9e340b2623d = external constant [0 x i8]
@olang_loc_4548956545b549f1_3148bf8c22a7bbcd = external constant [0 x i8]
@olang_loc_f729c2216052bfff_50c5b5b011682e5b = external constant [0 x i8]
@olang_loc_63217708da431fa9_77859d583dbca135 = external constant [0 x i8]
@olang_loc_abe2958fee383b29_80c71d662d0f1ffd = external constant [0 x i8]
@olang_loc_509ccf3852e61737_83a0d3f1c5189b03 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3ccompiler_2fcond_3aGlobal_26_3e_2e_Hb4cb47390ad0ef69ab85fecf589dd168(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
@olang_loc_8068eb64e8c18439_2ac1a5a22634b14d = external constant [0 x i8]
@olang_loc_97d6ab9891a1a2e7_a0781825def5a92b = external constant [0 x i8]
@olang_loc_85ed6fc19a4613eb_2f88795f71aff89f = external constant [0 x i8]
@olang_loc_71ed43b97f093f2f_4c4bfdc242e91c33 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString_26_3e_26_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aUnit_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3ccompiler_2fcheck_3aAssertAsk_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3ccompiler_2fcheck_3aContractAsk_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aGap_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3ccompiler_2fcheck_3aroArg_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fload_3aImport_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cU64_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3cArray_3cstd_2fprelude_2ftext_3aString_26_3e_26_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3ccompiler_2fgeneric_3aOrigin_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3ccompiler_2fscope_3aGap_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3ccompiler_2fdiag_3aItem_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3ccompiler_2fdiag_3arecord_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3ccompiler_2fscope_3afnUse_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3cU64_3e_2ector(ptr %v0, i64 %a0)

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
