; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

@olang_loc_1b7129720b80e8d6_c3c0d24b42a6a7ea = weak_odr constant [53 x i8] c"std/prelude/vec.olang:36: array length out of range\0A\00"
@olang_loc_2572310ac5a1b257_51d0d8152b54b12b = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: slice bounds out of range\0A\00"
@olang_loc_e8330a265840e63c_944cbbc179c1baf8 = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: slice bounds out of range\0A\00"
