; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

@olang_loc_11342465547203a4_82c88d21d6f2d348 = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: array length out of range\0A\00"
@olang_loc_1b7129720b80e8d6_c3c0d24b42a6a7ea = weak_odr constant [53 x i8] c"std/prelude/vec.olang:36: array length out of range\0A\00"
@olang_loc_b1db83814199a117_fdf79342c192c323 = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: array length out of range\0A\00"
