; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

@olang_loc_1268ae36dcd68536_af203f7780063cda = weak_odr constant [53 x i8] c"std/prelude/vec.olang:53: slice bounds out of range\0A\00"
@olang_loc_31e8a401e6f70816_dfc55569e963031a = weak_odr constant [53 x i8] c"std/prelude/vec.olang:53: slice bounds out of range\0A\00"
