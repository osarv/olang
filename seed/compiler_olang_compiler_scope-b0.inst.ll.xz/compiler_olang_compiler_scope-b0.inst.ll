; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/scope:Placement" = type { i64, i64, i64, i64, { i64, ptr }, i1 }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"std/prelude/map:MapEntry.8d509622153b47f1a5f79c42c8367406" = type { i64, { i64, ptr } }
%"std/prelude/map:MapEntry.eb00e4a6e4307a4e46e40fbcd79d6b4f" = type { i64, i1 }
%"std/prelude/map:MapEntry.e476b05c61172463a7c240e364dbb6d0" = type { i64, i64 }
%"std/prelude/map:MapEntry.e9f7fa267a7f2d248d882fb408477a69" = type { i64, { i64, [2 x i64] } }
%"std/prelude/map:MapEntry.8067410eb7799f1c31299714f5ba653d" = type { i64, %"compiler/scope:fnRecs" }
%"compiler/scope:fnRecs" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"std/prelude/map:MapEntry.46ee6b3e862913b4249ebf99c032c615" = type { i64, %"compiler/scope:fsBody" }
%"compiler/scope:fsBody" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/map:MapEntry.8feeaea6556533d50675c47385c120c2" = type { i64, %"compiler/scope:instTree" }
%"compiler/scope:instTree" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/map:MapEntry.1eb2466213689e002f25e81e83536e78" = type { i64, ptr }
%"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613" = type { i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/map:MapEntry.77d571dcfbd22be90356fe294d3b1a19" = type { %"compiler/scope:verAtom", i64 }
%"compiler/scope:verAtom" = type { i64, i64, i64, i64, i64, i64, i1, i64 }
%"std/prelude/map:MapEntry.2a60b5fdde847676acc31582b777d2c3" = type { i32, { i64, ptr } }
%"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" = type { i64, i64 }
%"std/prelude/map:MapEntry.5d90ea23f235d8870da3668e82c28edd" = type { %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", %"compiler/scope:Placement" }
%"std/prelude/map:MapEntry.39ab5235a9e7cc4d21ab272df52b187f" = type { %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/map:MapEntry.9ce8a46a5d367870e2478b0757bce708" = type { %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", i64 }
%"std/prelude/map:MapEntry.545808996237a863e786f2cb6df7346f" = type { %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", %"compiler/scope:placedRow" }
%"compiler/scope:placedRow" = type { %"compiler/source:Span", i64 }
%"compiler/source:Span" = type { i32, i32 }
%"std/prelude/map:MapEntry.1b1d537c79dee3d5948de1b7c1a79d8b" = type { %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", { i64, [2 x i64] } }
%"std/prelude/map:MapEntry.3418582855447f8ba2b65b4532371b2a" = type { %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", %"compiler/source:Span" }
%"std/prelude/map:MapEntry.adf118859e04490c36a9a3f2e59cf058" = type { %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", { i64, ptr } }
%"std/prelude/map:MapEntry.8c7bad97385adc7a5b41f0343fdc7864" = type { %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", { i64, [1 x i64] } }
%"std/prelude/map:MapEntry.0bcda5c026701d95f15bce76f62e86ad" = type { %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", %"compiler/scope:fnRecs" }
%"std/prelude/map:MapEntry.ecfeec17cdefbac388c52a4a4fc0fb05" = type { %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", i1 }
%"std/prelude/map:MapEntry.b259c967cf16ba62f29f59ede353f7e9" = type { { i64, ptr }, i1 }
%"std/prelude/map:MapEntry.ef37386b9f0625afbaa73bd3cf091381" = type { { i64, ptr }, i64 }
%"std/prelude/map:MapEntry.34f0a853427d04ec822d282fa19767ca" = type { { i64, ptr }, i32 }
%"std/prelude/map:MapEntry.325a673059aaeefabf16a279230523f6" = type { { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64, i32 }
%"compiler/scope:Gap" = type { i64, %"compiler/source:Span", { i64, ptr } }
%"compiler/scope:fsOpen" = type { i32, i1 }
%"compiler/scope:vrRow" = type { i64, i64, { i64, ptr } }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
define dso_local void @std_2fprelude_2farray_2esortByPositions_3ccompiler_2fscope_3aPlacement_2c_20_3f_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1c, ptr %a1e) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { ptr, ptr }
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l26 = alloca i64
  %l45 = alloca i64
  %l46 = alloca i64
  %l57 = alloca i64
  %l60 = alloca i64
  %l69 = alloca i64
  %l72 = alloca i1
  %l82 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %t170 = alloca { { ptr, ptr }, { i64, ptr }, ptr, ptr }, align 8
  store { i64, ptr } %a0, ptr %l0
  %pf1 = insertvalue { ptr, ptr } undef, ptr %a1c, 0
  %pg1 = insertvalue { ptr, ptr } %pf1, ptr %a1e, 1
  store { ptr, ptr } %pg1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l2, !tbaa !24
  %t5 = load i64, ptr %l2, !tbaa !24
  %t6 = load i64, ptr @G_2estd_2fprelude_2farray_2esortRun, !tbaa !24
  %t9 = icmp sle i64 %t5, %t6
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t12 = load i64, ptr %l2, !tbaa !24
  %t13 = load { ptr, ptr }, ptr %l1
  %t17 = extractvalue { ptr, ptr } %t13, 0
  %t18 = extractvalue { ptr, ptr } %t13, 1
  call void @std_2fprelude_2farray_2esortInsertion_3ccompiler_2fscope_3aPlacement_2c_20_3f_3e(ptr %v0, ptr %v1, { i64, ptr } %t11, i64 0, i64 %t12, ptr %t17, ptr %t18)
  br label %bb3
bb2:
  br label %bb5
bb3:
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb5:
  %t19 = load i64, ptr %l2, !tbaa !24
  %t20 = load i64, ptr @G_2estd_2fprelude_2farray_2esortBlock, !tbaa !24
  %t23 = icmp sgt i64 %t19, %t20
  br i1 %t23, label %bb6, label %bb7
bb6:
  %t25 = load i64, ptr @G_2estd_2fprelude_2farray_2esortBlock, !tbaa !24
  store i64 %t25, ptr %l26, !tbaa !24
  br label %bb8
bb7:
  %t27 = load i64, ptr %l2, !tbaa !24
  store i64 %t27, ptr %l26, !tbaa !24
  br label %bb8
bb8:
  %t29 = load i64, ptr %l26, !tbaa !24
  %t30 = icmp sge i64 %t29, 0
  br i1 %t30, label %bb9, label %bb10
bb9:
  %t32 = load i64, ptr %l26, !tbaa !24
  %t33 = icmp sle i64 %t32, 1152921504606846975
  br i1 %t33, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_d722d9d356e51315_f6b57ef284a7b0b9)
  unreachable
bb11:
  %t35 = load i64, ptr %l26, !tbaa !24
  %t36 = mul i64 %t35, 8
  %t37 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t36)
  %t38 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t37, 1
  store { i64, ptr } %t39, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_d722d9d356e51315_f6b57ef284a7b0b9)
  unreachable
bb13:
  store %olang.scope zeroinitializer, ptr %s2
  %t41 = load i64, ptr %l4, !tbaa !24
  %t42 = load i64, ptr %l2, !tbaa !24
  %t45 = icmp slt i64 %t41, %t42
  %t47 = xor i1 %t45, true
  br i1 %t47, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s2)
  br label %bb42
bb15:
  br label %bb16
bb16:
  %t49 = load i64, ptr %l4, !tbaa !24
  %t50 = load i64, ptr @G_2estd_2fprelude_2farray_2esortBlock, !tbaa !24
  %t53 = add i64 %t49, %t50
  store i64 %t53, ptr %l5, !tbaa !24
  %t55 = load i64, ptr %l5, !tbaa !24
  %t56 = load i64, ptr %l2, !tbaa !24
  %t59 = icmp sgt i64 %t55, %t56
  br i1 %t59, label %bb17, label %bb18
bb17:
  %t61 = load i64, ptr %l2, !tbaa !24
  store i64 %t61, ptr %l5, !tbaa !24
  br label %bb19
bb18:
  br label %bb19
bb19:
  %t63 = load i64, ptr %l5, !tbaa !24
  %t64 = load i64, ptr %l4, !tbaa !24
  %t67 = sub i64 %t63, %t64
  store i64 %t67, ptr %l45, !tbaa !24
  %t68 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t68, 0
  store i64 %t69, ptr %l46, !tbaa !24
  %t70 = icmp sge i64 0, 0
  br i1 %t70, label %bb20, label %bb21
bb20:
  %t72 = load i64, ptr %l45, !tbaa !24
  %t73 = icmp sle i64 0, %t72
  br i1 %t73, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_f1b0736c8bbc73d8_d1c24a04e6320604)
  unreachable
bb22:
  %t75 = load i64, ptr %l45, !tbaa !24
  %t76 = load i64, ptr %l46, !tbaa !24
  %t77 = icmp sle i64 %t75, %t76
  br i1 %t77, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_f1b0736c8bbc73d8_d1c24a04e6320604)
  unreachable
bb24:
  %t79 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = load i64, ptr %l45, !tbaa !24
  %t82 = getelementptr i64, ptr %t80, i64 0
  %t83 = sub i64 %t81, 0
  %t84 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t85 = insertvalue { i64, ptr } %t84, ptr %t82, 1
  store { i64, ptr } %t85, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t87 = load i64, ptr %l5, !tbaa !24
  %t88 = load i64, ptr %l4, !tbaa !24
  %t91 = sub i64 %t87, %t88
  store i64 %t91, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t93 = load i64, ptr %l8, !tbaa !24
  %t94 = load i64, ptr %l7, !tbaa !24
  %t97 = icmp sgt i64 %t93, %t94
  br i1 %t97, label %bb26, label %bb27
bb25:
  call void @__olang_check_failed(ptr @olang_loc_f1b0736c8bbc73d8_d1c24a04e6320604)
  unreachable
bb26:
  %t99 = load i64, ptr %l9, !tbaa !24
  %t101 = icmp sgt i64 %t99, 0
  br i1 %t101, label %bb28, label %bb29
bb27:
  store i64 0, ptr %l57, !tbaa !24
  br label %bb31
bb28:
  %t103 = load i64, ptr %l8, !tbaa !24
  %t104 = load i64, ptr %l7, !tbaa !24
  %t107 = sub i64 %t103, %t104
  %t108 = load i64, ptr %l9, !tbaa !24
  %t111 = add i64 %t107, %t108
  %t113 = sub i64 %t111, 1
  %t114 = load i64, ptr %l9, !tbaa !24
  %t117 = sdiv i64 %t113, %t114
  store i64 %t117, ptr %l60, !tbaa !24
  br label %bb30
bb29:
  store i64 0, ptr %l60, !tbaa !24
  br label %bb30
bb30:
  %t119 = load i64, ptr %l60, !tbaa !24
  store i64 %t119, ptr %l57, !tbaa !24
  br label %bb31
bb31:
  %t120 = load i64, ptr %l57, !tbaa !24
  store i64 %t120, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  %t121 = load i64, ptr %l10, !tbaa !24
  %t122 = sub i64 %t121, 1
  store i64 %t122, ptr %l69, !tbaa !24
  %t123 = load i64, ptr %l10, !tbaa !24
  %t124 = icmp slt i64 %t123, 2147483648
  %t125 = load i64, ptr %l11, !tbaa !24
  %t126 = icmp sge i64 %t125, 0
  %t129 = and i1 %t124, %t126
  store i1 %t129, ptr %l72, !tbaa !21
  br label %bb32
bb32:
  %t130 = load i64, ptr %l11, !tbaa !24
  %t131 = load i64, ptr %l10, !tbaa !24
  %t134 = icmp slt i64 %t130, %t131
  %t136 = xor i1 %t134, true
  br i1 %t136, label %bb33, label %bb34
bb33:
  br label %bb37
bb34:
  br label %bb35
bb35:
  %t138 = load i64, ptr %l7, !tbaa !24
  %t139 = load i64, ptr %l11, !tbaa !24
  %t140 = load i64, ptr %l9, !tbaa !24
  %t143 = mul i64 %t139, %t140
  %t146 = add i64 %t138, %t143
  store i64 %t146, ptr %l12, !tbaa !24
  %t148 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t148, ptr %l82, !tbaa !27
  %t149 = load i64, ptr %l12, !tbaa !24
  %t150 = load i64, ptr %l4, !tbaa !24
  %t151 = load i64, ptr %l12, !tbaa !24
  %t154 = add i64 %t150, %t151
  %t157 = getelementptr { i64, ptr }, ptr %l82, i32 0, i32 1
  %t158 = load ptr, ptr %t157, !tbaa !27
  %t159 = getelementptr i64, ptr %t158, i64 %t149
  store i64 %t154, ptr %t159, !tbaa !34
  br label %bb36
bb36:
  %t160 = load i64, ptr %l11, !tbaa !24
  %t163 = add i64 %t160, 1
  store i64 %t163, ptr %l11, !tbaa !24
  br label %bb32
bb37:
  %t165 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t166 = load { ptr, ptr }, ptr %l1
  %t167 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t168 = getelementptr { { ptr, ptr }, { i64, ptr }, ptr, ptr }, ptr null, i32 1
  %t169 = ptrtoint ptr %t168 to i64
  %t171 = getelementptr { { ptr, ptr }, { i64, ptr }, ptr, ptr }, ptr %t170, i32 0, i32 0
  store { ptr, ptr } %t166, ptr %t171, !tbaa !28
  %t173 = getelementptr { { ptr, ptr }, { i64, ptr }, ptr, ptr }, ptr %t170, i32 0, i32 1
  store { i64, ptr } %t167, ptr %t173, !tbaa !28
  call void @__olang_scope_escape(ptr %v1)
  %t175 = call ptr @__olang_scope_hold(ptr %v1)
  %t176 = getelementptr { { ptr, ptr }, { i64, ptr }, ptr, ptr }, ptr %t170, i32 0, i32 2
  store ptr %t175, ptr %t176, !tbaa !28
  call void @__olang_scope_escape(ptr %v0)
  %t177 = call ptr @__olang_scope_hold(ptr %v0)
  %t178 = getelementptr { { ptr, ptr }, { i64, ptr }, ptr, ptr }, ptr %t170, i32 0, i32 3
  store ptr %t177, ptr %t178, !tbaa !28
  %t179 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_0, 0
  %t180 = insertvalue { ptr, ptr } %t179, ptr %t170, 1
  %t183 = extractvalue { ptr, ptr } %t180, 0
  %t184 = extractvalue { ptr, ptr } %t180, 1
  call void @std_2fprelude_2farray_2esortMergeBuffered_3cI64_2c_20_3f_3e_clone1_olang_lambda_17199(ptr %s0, ptr %s2, { i64, ptr } %t165, ptr %t183, ptr %t184)
  br label %bb38
bb38:
  br label %bb39
bb39:
  %t185 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t186 = load i64, ptr %l4, !tbaa !24
  %t187 = load { i64, ptr }, ptr %l6, !tbaa !27
  call void @std_2fprelude_2farray_2esortPermute_3ccompiler_2fscope_3aPlacement_3e(ptr %v0, ptr %s0, { i64, ptr } %t185, i64 %t186, { i64, ptr } %t187)
  br label %bb40
bb40:
  %t191 = load i64, ptr %l5, !tbaa !24
  store i64 %t191, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb41
bb41:
  br label %bb13
bb42:
  %t193 = load i64, ptr @G_2estd_2fprelude_2farray_2esortBlock, !tbaa !24
  store i64 %t193, ptr %l13, !tbaa !24
  br label %bb43
bb43:
  %t195 = load i64, ptr %l13, !tbaa !24
  %t196 = load i64, ptr %l2, !tbaa !24
  %t199 = icmp slt i64 %t195, %t196
  %t201 = xor i1 %t199, true
  br i1 %t201, label %bb44, label %bb45
bb44:
  br label %bb59
bb45:
  br label %bb46
bb46:
  store i64 0, ptr %l4, !tbaa !24
  br label %bb47
bb47:
  %t203 = load i64, ptr %l4, !tbaa !24
  %t204 = load i64, ptr %l13, !tbaa !24
  %t207 = add i64 %t203, %t204
  %t208 = load i64, ptr %l2, !tbaa !24
  %t211 = icmp slt i64 %t207, %t208
  %t213 = xor i1 %t211, true
  br i1 %t213, label %bb48, label %bb49
bb48:
  br label %bb57
bb49:
  br label %bb50
bb50:
  %t215 = load i64, ptr %l4, !tbaa !24
  %t216 = load i64, ptr %l13, !tbaa !24
  %t218 = mul i64 2, %t216
  %t221 = add i64 %t215, %t218
  store i64 %t221, ptr %l14, !tbaa !24
  %t223 = load i64, ptr %l14, !tbaa !24
  %t224 = load i64, ptr %l2, !tbaa !24
  %t227 = icmp sgt i64 %t223, %t224
  br i1 %t227, label %bb51, label %bb52
bb51:
  %t229 = load i64, ptr %l2, !tbaa !24
  store i64 %t229, ptr %l14, !tbaa !24
  br label %bb53
bb52:
  br label %bb53
bb53:
  %t231 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t232 = load i64, ptr %l4, !tbaa !24
  %t233 = load i64, ptr %l4, !tbaa !24
  %t234 = load i64, ptr %l13, !tbaa !24
  %t237 = add i64 %t233, %t234
  %t238 = load i64, ptr %l14, !tbaa !24
  %t239 = load { ptr, ptr }, ptr %l1
  %t245 = extractvalue { ptr, ptr } %t239, 0
  %t246 = extractvalue { ptr, ptr } %t239, 1
  call void @std_2fprelude_2farray_2esortMerge_3ccompiler_2fscope_3aPlacement_2c_20_3f_3e(ptr %v0, ptr %v1, { i64, ptr } %t231, i64 %t232, i64 %t237, i64 %t238, ptr %t245, ptr %t246)
  br label %bb54
bb54:
  br label %bb55
bb55:
  %t247 = load i64, ptr %l14, !tbaa !24
  store i64 %t247, ptr %l4, !tbaa !24
  br label %bb56
bb56:
  br label %bb47
bb57:
  %t249 = load i64, ptr %l13, !tbaa !24
  %t252 = mul i64 %t249, 2
  store i64 %t252, ptr %l13, !tbaa !24
  br label %bb58
bb58:
  br label %bb43
bb59:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2farray_2esortMerge_3ccompiler_2fscope_3aPlacement_2c_20_3f_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i64 %a2, i64 %a3, ptr %a4c, ptr %a4e) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca { ptr, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l39 = alloca i1
  %l41 = alloca { i64, ptr }
  %l44 = alloca %"compiler/scope:Placement"
  %l45 = alloca { i64, ptr }
  %l46 = alloca i64
  %l47 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l51 = alloca %"compiler/scope:Placement"
  %l52 = alloca { i64, ptr }
  %l53 = alloca i64
  %l54 = alloca { i64, ptr }
  %l55 = alloca i1
  %l65 = alloca i64
  %l68 = alloca i64
  %l107 = alloca i1
  %l109 = alloca { i64, ptr }
  %l112 = alloca %"compiler/scope:Placement"
  %l113 = alloca { i64, ptr }
  %l114 = alloca i64
  %l115 = alloca { i64, ptr }
  %l116 = alloca { i64, ptr }
  %l119 = alloca %"compiler/scope:Placement"
  %l120 = alloca { i64, ptr }
  %l121 = alloca i64
  %l122 = alloca { i64, ptr }
  %l123 = alloca i1
  %l166 = alloca i1
  %l168 = alloca { i64, ptr }
  %l173 = alloca %"compiler/scope:Placement"
  %l174 = alloca { i64, ptr }
  %l175 = alloca i64
  %l176 = alloca { i64, ptr }
  %l177 = alloca { i64, ptr }
  %l180 = alloca %"compiler/scope:Placement"
  %l181 = alloca { i64, ptr }
  %l182 = alloca i64
  %l183 = alloca { i64, ptr }
  %l184 = alloca i1
  %l195 = alloca i1
  %l206 = alloca i1
  %l218 = alloca i1
  %s2 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s14 = alloca %olang.scope
  store { i64, ptr } %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i64 %a3, ptr %l3
  %pf4 = insertvalue { ptr, ptr } undef, ptr %a4c, 0
  %pg4 = insertvalue { ptr, ptr } %pf4, ptr %a4e, 1
  store { ptr, ptr } %pg4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l2, !tbaa !24
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = sub i64 %t1, %t2
  %t7 = icmp eq i64 %t5, 1
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = load i64, ptr %l2, !tbaa !24
  store i64 %t9, ptr %l5, !tbaa !24
  %t11 = load i64, ptr %l3, !tbaa !24
  store i64 %t11, ptr %l6, !tbaa !24
  br label %bb3
bb2:
  br label %bb27
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t13 = load i64, ptr %l5, !tbaa !24
  %t14 = load i64, ptr %l6, !tbaa !24
  %t17 = icmp slt i64 %t13, %t14
  %t19 = xor i1 %t17, true
  br i1 %t19, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s2)
  br label %bb13
bb5:
  br label %bb6
bb6:
  %t21 = load i64, ptr %l5, !tbaa !24
  %t22 = load i64, ptr %l6, !tbaa !24
  %t25 = add i64 %t21, %t22
  %t27 = sdiv i64 %t25, 2
  store i64 %t27, ptr %l7, !tbaa !24
  %t29 = load { ptr, ptr }, ptr %l4
  %t30 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t30, ptr %l41, !tbaa !27
  %t31 = load i64, ptr %l7, !tbaa !24
  %t33 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = getelementptr %"compiler/scope:Placement", ptr %t34, i64 %t31
  %t36 = load %"compiler/scope:Placement", ptr %t35
  store %"compiler/scope:Placement" %t36, ptr %l44
  %t38 = getelementptr %"compiler/scope:Placement", ptr %l44, i32 0, i32 4
  %t39 = load { i64, ptr }, ptr %t38, !tbaa !27
  store { i64, ptr } %t39, ptr %l45, !tbaa !27
  %t40 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t40, 0
  store i64 %t41, ptr %l46, !tbaa !24
  %t42 = load i64, ptr %l46, !tbaa !24
  %t43 = mul i64 %t42, 1
  %t44 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t43)
  %t45 = insertvalue { i64, ptr } undef, i64 %t42, 0
  %t46 = insertvalue { i64, ptr } %t45, ptr %t44, 1
  store { i64, ptr } %t46, ptr %l47, !tbaa !27
  %t47 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !27
  %t49 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !27
  %t51 = load i64, ptr %l46, !tbaa !24
  %t52 = mul i64 %t51, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t48, ptr %t50, i64 %t52, i1 false)
  %t53 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t54 = getelementptr %"compiler/scope:Placement", ptr %l44, i32 0, i32 4
  store { i64, ptr } %t53, ptr %t54, !tbaa !27
  %t55 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t55, ptr %l48, !tbaa !27
  %t56 = load i64, ptr %l1, !tbaa !24
  %t58 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = getelementptr %"compiler/scope:Placement", ptr %t59, i64 %t56
  %t61 = load %"compiler/scope:Placement", ptr %t60
  store %"compiler/scope:Placement" %t61, ptr %l51
  %t63 = getelementptr %"compiler/scope:Placement", ptr %l51, i32 0, i32 4
  %t64 = load { i64, ptr }, ptr %t63, !tbaa !27
  store { i64, ptr } %t64, ptr %l52, !tbaa !27
  %t65 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t66 = extractvalue { i64, ptr } %t65, 0
  store i64 %t66, ptr %l53, !tbaa !24
  %t67 = load i64, ptr %l53, !tbaa !24
  %t68 = mul i64 %t67, 1
  %t69 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t68)
  %t70 = insertvalue { i64, ptr } undef, i64 %t67, 0
  %t71 = insertvalue { i64, ptr } %t70, ptr %t69, 1
  store { i64, ptr } %t71, ptr %l54, !tbaa !27
  %t72 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t75 = load ptr, ptr %t74, !tbaa !27
  %t76 = load i64, ptr %l53, !tbaa !24
  %t77 = mul i64 %t76, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t73, ptr %t75, i64 %t77, i1 false)
  %t78 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t79 = getelementptr %"compiler/scope:Placement", ptr %l51, i32 0, i32 4
  store { i64, ptr } %t78, ptr %t79, !tbaa !27
  %t81 = extractvalue { ptr, ptr } %t29, 0
  %t82 = extractvalue { ptr, ptr } %t29, 1
  %t83 = load %"compiler/scope:Placement", ptr %l44
  %t84 = load %"compiler/scope:Placement", ptr %l51
  %t85 = call i1 %t81(ptr %t82, ptr %s2, ptr %s2, %"compiler/scope:Placement" %t83, %"compiler/scope:Placement" %t84)
  store i1 %t85, ptr %l55
  br label %bb7
bb7:
  %t86 = load i1, ptr %l55, !tbaa !21
  store i1 %t86, ptr %l39, !tbaa !21
  br label %bb8
bb8:
  %t87 = load i1, ptr %l39, !tbaa !21
  br i1 %t87, label %bb9, label %bb10
bb9:
  %t88 = load i64, ptr %l7, !tbaa !24
  %t90 = add i64 %t88, 1
  store i64 %t90, ptr %l5, !tbaa !24
  br label %bb11
bb10:
  %t92 = load i64, ptr %l7, !tbaa !24
  store i64 %t92, ptr %l6, !tbaa !24
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s2)
  br label %bb12
bb12:
  br label %bb3
bb13:
  %t94 = load i64, ptr %l1, !tbaa !24
  store i64 %t94, ptr %l8, !tbaa !24
  %t96 = load i64, ptr %l5, !tbaa !24
  %t98 = sub i64 %t96, 1
  store i64 %t98, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t100 = load i64, ptr %l9, !tbaa !24
  %t101 = load i64, ptr %l8, !tbaa !24
  %t104 = icmp sgt i64 %t100, %t101
  br i1 %t104, label %bb14, label %bb15
bb14:
  %t106 = load i64, ptr %l10, !tbaa !24
  %t108 = icmp sgt i64 %t106, 0
  br i1 %t108, label %bb16, label %bb17
bb15:
  store i64 0, ptr %l65, !tbaa !24
  br label %bb19
bb16:
  %t110 = load i64, ptr %l9, !tbaa !24
  %t111 = load i64, ptr %l8, !tbaa !24
  %t114 = sub i64 %t110, %t111
  %t115 = load i64, ptr %l10, !tbaa !24
  %t118 = add i64 %t114, %t115
  %t120 = sub i64 %t118, 1
  %t121 = load i64, ptr %l10, !tbaa !24
  %t124 = sdiv i64 %t120, %t121
  store i64 %t124, ptr %l68, !tbaa !24
  br label %bb18
bb17:
  store i64 0, ptr %l68, !tbaa !24
  br label %bb18
bb18:
  %t126 = load i64, ptr %l68, !tbaa !24
  store i64 %t126, ptr %l65, !tbaa !24
  br label %bb19
bb19:
  %t127 = load i64, ptr %l65, !tbaa !24
  store i64 %t127, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb20
bb20:
  %t128 = load i64, ptr %l12, !tbaa !24
  %t129 = load i64, ptr %l11, !tbaa !24
  %t132 = icmp slt i64 %t128, %t129
  %t134 = xor i1 %t132, true
  br i1 %t134, label %bb21, label %bb22
bb21:
  br label %bb26
bb22:
  br label %bb23
bb23:
  %t136 = load i64, ptr %l8, !tbaa !24
  %t137 = load i64, ptr %l12, !tbaa !24
  %t138 = load i64, ptr %l10, !tbaa !24
  %t141 = mul i64 %t137, %t138
  %t144 = add i64 %t136, %t141
  store i64 %t144, ptr %l13, !tbaa !24
  %t146 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t147 = load i64, ptr %l13, !tbaa !24
  %t148 = load i64, ptr %l13, !tbaa !24
  %t150 = add i64 %t148, 1
  call void @std_2fprelude_2farray_2esortSwap_3ccompiler_2fscope_3aPlacement_3e(ptr %v0, { i64, ptr } %t146, i64 %t147, i64 %t150)
  br label %bb24
bb24:
  br label %bb25
bb25:
  %t154 = load i64, ptr %l12, !tbaa !24
  %t157 = add i64 %t154, 1
  store i64 %t157, ptr %l12, !tbaa !24
  br label %bb20
bb26:
  br label %ret
bb27:
  %t159 = load i64, ptr %l3, !tbaa !24
  %t160 = load i64, ptr %l2, !tbaa !24
  %t163 = sub i64 %t159, %t160
  %t165 = icmp eq i64 %t163, 1
  br i1 %t165, label %bb28, label %bb29
bb28:
  %t167 = load i64, ptr %l1, !tbaa !24
  store i64 %t167, ptr %l14, !tbaa !24
  %t169 = load i64, ptr %l2, !tbaa !24
  store i64 %t169, ptr %l15, !tbaa !24
  br label %bb30
bb29:
  br label %bb48
bb30:
  store %olang.scope zeroinitializer, ptr %s9
  %t171 = load i64, ptr %l14, !tbaa !24
  %t172 = load i64, ptr %l15, !tbaa !24
  %t175 = icmp slt i64 %t171, %t172
  %t177 = xor i1 %t175, true
  br i1 %t177, label %bb31, label %bb32
bb31:
  call void @__olang_scope_close(ptr %s9)
  br label %bb40
bb32:
  br label %bb33
bb33:
  %t179 = load i64, ptr %l14, !tbaa !24
  %t180 = load i64, ptr %l15, !tbaa !24
  %t183 = add i64 %t179, %t180
  %t185 = sdiv i64 %t183, 2
  store i64 %t185, ptr %l16, !tbaa !24
  %t187 = load { ptr, ptr }, ptr %l4
  %t188 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t188, ptr %l109, !tbaa !27
  %t189 = load i64, ptr %l2, !tbaa !24
  %t191 = getelementptr { i64, ptr }, ptr %l109, i32 0, i32 1
  %t192 = load ptr, ptr %t191, !tbaa !27
  %t193 = getelementptr %"compiler/scope:Placement", ptr %t192, i64 %t189
  %t194 = load %"compiler/scope:Placement", ptr %t193
  store %"compiler/scope:Placement" %t194, ptr %l112
  %t196 = getelementptr %"compiler/scope:Placement", ptr %l112, i32 0, i32 4
  %t197 = load { i64, ptr }, ptr %t196, !tbaa !27
  store { i64, ptr } %t197, ptr %l113, !tbaa !27
  %t198 = load { i64, ptr }, ptr %l113, !tbaa !27
  %t199 = extractvalue { i64, ptr } %t198, 0
  store i64 %t199, ptr %l114, !tbaa !24
  %t200 = load i64, ptr %l114, !tbaa !24
  %t201 = mul i64 %t200, 1
  %t202 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t201)
  %t203 = insertvalue { i64, ptr } undef, i64 %t200, 0
  %t204 = insertvalue { i64, ptr } %t203, ptr %t202, 1
  store { i64, ptr } %t204, ptr %l115, !tbaa !27
  %t205 = getelementptr { i64, ptr }, ptr %l115, i32 0, i32 1
  %t206 = load ptr, ptr %t205, !tbaa !27
  %t207 = getelementptr { i64, ptr }, ptr %l113, i32 0, i32 1
  %t208 = load ptr, ptr %t207, !tbaa !27
  %t209 = load i64, ptr %l114, !tbaa !24
  %t210 = mul i64 %t209, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t206, ptr %t208, i64 %t210, i1 false)
  %t211 = load { i64, ptr }, ptr %l115, !tbaa !27
  %t212 = getelementptr %"compiler/scope:Placement", ptr %l112, i32 0, i32 4
  store { i64, ptr } %t211, ptr %t212, !tbaa !27
  %t213 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t213, ptr %l116, !tbaa !27
  %t214 = load i64, ptr %l16, !tbaa !24
  %t216 = getelementptr { i64, ptr }, ptr %l116, i32 0, i32 1
  %t217 = load ptr, ptr %t216, !tbaa !27
  %t218 = getelementptr %"compiler/scope:Placement", ptr %t217, i64 %t214
  %t219 = load %"compiler/scope:Placement", ptr %t218
  store %"compiler/scope:Placement" %t219, ptr %l119
  %t221 = getelementptr %"compiler/scope:Placement", ptr %l119, i32 0, i32 4
  %t222 = load { i64, ptr }, ptr %t221, !tbaa !27
  store { i64, ptr } %t222, ptr %l120, !tbaa !27
  %t223 = load { i64, ptr }, ptr %l120, !tbaa !27
  %t224 = extractvalue { i64, ptr } %t223, 0
  store i64 %t224, ptr %l121, !tbaa !24
  %t225 = load i64, ptr %l121, !tbaa !24
  %t226 = mul i64 %t225, 1
  %t227 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t226)
  %t228 = insertvalue { i64, ptr } undef, i64 %t225, 0
  %t229 = insertvalue { i64, ptr } %t228, ptr %t227, 1
  store { i64, ptr } %t229, ptr %l122, !tbaa !27
  %t230 = getelementptr { i64, ptr }, ptr %l122, i32 0, i32 1
  %t231 = load ptr, ptr %t230, !tbaa !27
  %t232 = getelementptr { i64, ptr }, ptr %l120, i32 0, i32 1
  %t233 = load ptr, ptr %t232, !tbaa !27
  %t234 = load i64, ptr %l121, !tbaa !24
  %t235 = mul i64 %t234, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t231, ptr %t233, i64 %t235, i1 false)
  %t236 = load { i64, ptr }, ptr %l122, !tbaa !27
  %t237 = getelementptr %"compiler/scope:Placement", ptr %l119, i32 0, i32 4
  store { i64, ptr } %t236, ptr %t237, !tbaa !27
  %t239 = extractvalue { ptr, ptr } %t187, 0
  %t240 = extractvalue { ptr, ptr } %t187, 1
  %t241 = load %"compiler/scope:Placement", ptr %l112
  %t242 = load %"compiler/scope:Placement", ptr %l119
  %t243 = call i1 %t239(ptr %t240, ptr %s9, ptr %s9, %"compiler/scope:Placement" %t241, %"compiler/scope:Placement" %t242)
  store i1 %t243, ptr %l123
  br label %bb34
bb34:
  %t244 = load i1, ptr %l123, !tbaa !21
  store i1 %t244, ptr %l107, !tbaa !21
  br label %bb35
bb35:
  %t245 = load i1, ptr %l107, !tbaa !21
  %t246 = xor i1 %t245, true
  br i1 %t246, label %bb36, label %bb37
bb36:
  %t248 = load i64, ptr %l16, !tbaa !24
  %t250 = add i64 %t248, 1
  store i64 %t250, ptr %l14, !tbaa !24
  br label %bb38
bb37:
  %t252 = load i64, ptr %l16, !tbaa !24
  store i64 %t252, ptr %l15, !tbaa !24
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s9)
  br label %bb39
bb39:
  br label %bb30
bb40:
  %t254 = load i64, ptr %l2, !tbaa !24
  store i64 %t254, ptr %l17, !tbaa !24
  br label %bb41
bb41:
  %t256 = load i64, ptr %l17, !tbaa !24
  %t257 = load i64, ptr %l14, !tbaa !24
  %t260 = icmp sgt i64 %t256, %t257
  %t262 = xor i1 %t260, true
  br i1 %t262, label %bb42, label %bb43
bb42:
  br label %bb47
bb43:
  br label %bb44
bb44:
  %t264 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t265 = load i64, ptr %l17, !tbaa !24
  %t266 = load i64, ptr %l17, !tbaa !24
  %t268 = sub i64 %t266, 1
  call void @std_2fprelude_2farray_2esortSwap_3ccompiler_2fscope_3aPlacement_3e(ptr %v0, { i64, ptr } %t264, i64 %t265, i64 %t268)
  br label %bb45
bb45:
  %t272 = load i64, ptr %l17, !tbaa !24
  %t275 = sub i64 %t272, 1
  store i64 %t275, ptr %l17, !tbaa !24
  br label %bb46
bb46:
  br label %bb41
bb47:
  br label %ret
bb48:
  %t277 = load i64, ptr %l1, !tbaa !24
  %t278 = load i64, ptr %l3, !tbaa !24
  %t281 = add i64 %t277, %t278
  %t283 = sdiv i64 %t281, 2
  store i64 %t283, ptr %l18, !tbaa !24
  %t285 = load i64, ptr %l18, !tbaa !24
  %t286 = load i64, ptr %l2, !tbaa !24
  %t289 = add i64 %t285, %t286
  store i64 %t289, ptr %l19, !tbaa !24
  %t291 = load i64, ptr %l1, !tbaa !24
  store i64 %t291, ptr %l20, !tbaa !24
  %t293 = load i64, ptr %l2, !tbaa !24
  store i64 %t293, ptr %l21, !tbaa !24
  %t295 = load i64, ptr %l2, !tbaa !24
  %t296 = load i64, ptr %l18, !tbaa !24
  %t299 = icmp sgt i64 %t295, %t296
  br i1 %t299, label %bb49, label %bb50
bb49:
  %t301 = load i64, ptr %l19, !tbaa !24
  %t302 = load i64, ptr %l3, !tbaa !24
  %t305 = sub i64 %t301, %t302
  store i64 %t305, ptr %l20, !tbaa !24
  %t307 = load i64, ptr %l18, !tbaa !24
  store i64 %t307, ptr %l21, !tbaa !24
  br label %bb51
bb50:
  br label %bb51
bb51:
  %t309 = load i64, ptr %l19, !tbaa !24
  %t311 = sub i64 %t309, 1
  store i64 %t311, ptr %l22, !tbaa !24
  br label %bb52
bb52:
  store %olang.scope zeroinitializer, ptr %s14
  %t313 = load i64, ptr %l20, !tbaa !24
  %t314 = load i64, ptr %l21, !tbaa !24
  %t317 = icmp slt i64 %t313, %t314
  %t319 = xor i1 %t317, true
  br i1 %t319, label %bb53, label %bb54
bb53:
  call void @__olang_scope_close(ptr %s14)
  br label %bb62
bb54:
  br label %bb55
bb55:
  %t321 = load i64, ptr %l20, !tbaa !24
  %t322 = load i64, ptr %l21, !tbaa !24
  %t325 = add i64 %t321, %t322
  %t327 = sdiv i64 %t325, 2
  store i64 %t327, ptr %l23, !tbaa !24
  %t329 = load { ptr, ptr }, ptr %l4
  %t330 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t330, ptr %l168, !tbaa !27
  %t331 = load i64, ptr %l22, !tbaa !24
  %t332 = load i64, ptr %l23, !tbaa !24
  %t335 = sub i64 %t331, %t332
  %t337 = getelementptr { i64, ptr }, ptr %l168, i32 0, i32 1
  %t338 = load ptr, ptr %t337, !tbaa !27
  %t339 = getelementptr %"compiler/scope:Placement", ptr %t338, i64 %t335
  %t340 = load %"compiler/scope:Placement", ptr %t339
  store %"compiler/scope:Placement" %t340, ptr %l173
  %t342 = getelementptr %"compiler/scope:Placement", ptr %l173, i32 0, i32 4
  %t343 = load { i64, ptr }, ptr %t342, !tbaa !27
  store { i64, ptr } %t343, ptr %l174, !tbaa !27
  %t344 = load { i64, ptr }, ptr %l174, !tbaa !27
  %t345 = extractvalue { i64, ptr } %t344, 0
  store i64 %t345, ptr %l175, !tbaa !24
  %t346 = load i64, ptr %l175, !tbaa !24
  %t347 = mul i64 %t346, 1
  %t348 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t347)
  %t349 = insertvalue { i64, ptr } undef, i64 %t346, 0
  %t350 = insertvalue { i64, ptr } %t349, ptr %t348, 1
  store { i64, ptr } %t350, ptr %l176, !tbaa !27
  %t351 = getelementptr { i64, ptr }, ptr %l176, i32 0, i32 1
  %t352 = load ptr, ptr %t351, !tbaa !27
  %t353 = getelementptr { i64, ptr }, ptr %l174, i32 0, i32 1
  %t354 = load ptr, ptr %t353, !tbaa !27
  %t355 = load i64, ptr %l175, !tbaa !24
  %t356 = mul i64 %t355, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t352, ptr %t354, i64 %t356, i1 false)
  %t357 = load { i64, ptr }, ptr %l176, !tbaa !27
  %t358 = getelementptr %"compiler/scope:Placement", ptr %l173, i32 0, i32 4
  store { i64, ptr } %t357, ptr %t358, !tbaa !27
  %t359 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t359, ptr %l177, !tbaa !27
  %t360 = load i64, ptr %l23, !tbaa !24
  %t362 = getelementptr { i64, ptr }, ptr %l177, i32 0, i32 1
  %t363 = load ptr, ptr %t362, !tbaa !27
  %t364 = getelementptr %"compiler/scope:Placement", ptr %t363, i64 %t360
  %t365 = load %"compiler/scope:Placement", ptr %t364
  store %"compiler/scope:Placement" %t365, ptr %l180
  %t367 = getelementptr %"compiler/scope:Placement", ptr %l180, i32 0, i32 4
  %t368 = load { i64, ptr }, ptr %t367, !tbaa !27
  store { i64, ptr } %t368, ptr %l181, !tbaa !27
  %t369 = load { i64, ptr }, ptr %l181, !tbaa !27
  %t370 = extractvalue { i64, ptr } %t369, 0
  store i64 %t370, ptr %l182, !tbaa !24
  %t371 = load i64, ptr %l182, !tbaa !24
  %t372 = mul i64 %t371, 1
  %t373 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t372)
  %t374 = insertvalue { i64, ptr } undef, i64 %t371, 0
  %t375 = insertvalue { i64, ptr } %t374, ptr %t373, 1
  store { i64, ptr } %t375, ptr %l183, !tbaa !27
  %t376 = getelementptr { i64, ptr }, ptr %l183, i32 0, i32 1
  %t377 = load ptr, ptr %t376, !tbaa !27
  %t378 = getelementptr { i64, ptr }, ptr %l181, i32 0, i32 1
  %t379 = load ptr, ptr %t378, !tbaa !27
  %t380 = load i64, ptr %l182, !tbaa !24
  %t381 = mul i64 %t380, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t377, ptr %t379, i64 %t381, i1 false)
  %t382 = load { i64, ptr }, ptr %l183, !tbaa !27
  %t383 = getelementptr %"compiler/scope:Placement", ptr %l180, i32 0, i32 4
  store { i64, ptr } %t382, ptr %t383, !tbaa !27
  %t385 = extractvalue { ptr, ptr } %t329, 0
  %t386 = extractvalue { ptr, ptr } %t329, 1
  %t387 = load %"compiler/scope:Placement", ptr %l173
  %t388 = load %"compiler/scope:Placement", ptr %l180
  %t389 = call i1 %t385(ptr %t386, ptr %s14, ptr %s14, %"compiler/scope:Placement" %t387, %"compiler/scope:Placement" %t388)
  store i1 %t389, ptr %l184
  br label %bb56
bb56:
  %t390 = load i1, ptr %l184, !tbaa !21
  store i1 %t390, ptr %l166, !tbaa !21
  br label %bb57
bb57:
  %t391 = load i1, ptr %l166, !tbaa !21
  %t392 = xor i1 %t391, true
  br i1 %t392, label %bb58, label %bb59
bb58:
  %t394 = load i64, ptr %l23, !tbaa !24
  %t396 = add i64 %t394, 1
  store i64 %t396, ptr %l20, !tbaa !24
  br label %bb60
bb59:
  %t398 = load i64, ptr %l23, !tbaa !24
  store i64 %t398, ptr %l21, !tbaa !24
  br label %bb60
bb60:
  call void @__olang_scope_close(ptr %s14)
  br label %bb61
bb61:
  br label %bb52
bb62:
  %t400 = load i64, ptr %l19, !tbaa !24
  %t401 = load i64, ptr %l20, !tbaa !24
  %t404 = sub i64 %t400, %t401
  store i64 %t404, ptr %l24, !tbaa !24
  %t406 = load i64, ptr %l20, !tbaa !24
  %t407 = load i64, ptr %l2, !tbaa !24
  %t410 = icmp slt i64 %t406, %t407
  br i1 %t410, label %bb63, label %bb64
bb63:
  %t412 = load i64, ptr %l2, !tbaa !24
  %t413 = load i64, ptr %l24, !tbaa !24
  %t416 = icmp slt i64 %t412, %t413
  store i1 %t416, ptr %l195, !tbaa !21
  br label %bb65
bb64:
  store i1 false, ptr %l195, !tbaa !21
  br label %bb65
bb65:
  %t418 = load i1, ptr %l195, !tbaa !21
  br i1 %t418, label %bb66, label %bb67
bb66:
  %t419 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t420 = load i64, ptr %l20, !tbaa !24
  %t421 = load i64, ptr %l2, !tbaa !24
  %t422 = load i64, ptr %l24, !tbaa !24
  call void @std_2fprelude_2farray_2esortRotate_3ccompiler_2fscope_3aPlacement_3e(ptr %v0, { i64, ptr } %t419, i64 %t420, i64 %t421, i64 %t422)
  br label %bb68
bb67:
  br label %bb69
bb68:
  br label %bb69
bb69:
  %t427 = load i64, ptr %l1, !tbaa !24
  %t428 = load i64, ptr %l20, !tbaa !24
  %t431 = icmp slt i64 %t427, %t428
  br i1 %t431, label %bb70, label %bb71
bb70:
  %t433 = load i64, ptr %l20, !tbaa !24
  %t434 = load i64, ptr %l18, !tbaa !24
  %t437 = icmp slt i64 %t433, %t434
  store i1 %t437, ptr %l206, !tbaa !21
  br label %bb72
bb71:
  store i1 false, ptr %l206, !tbaa !21
  br label %bb72
bb72:
  %t439 = load i1, ptr %l206, !tbaa !21
  br i1 %t439, label %bb73, label %bb74
bb73:
  %t440 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t441 = load i64, ptr %l1, !tbaa !24
  %t442 = load i64, ptr %l20, !tbaa !24
  %t443 = load i64, ptr %l18, !tbaa !24
  %t444 = load { ptr, ptr }, ptr %l4
  %t450 = extractvalue { ptr, ptr } %t444, 0
  %t451 = extractvalue { ptr, ptr } %t444, 1
  call void @std_2fprelude_2farray_2esortMerge_3ccompiler_2fscope_3aPlacement_2c_20_3f_3e(ptr %v0, ptr %v1, { i64, ptr } %t440, i64 %t441, i64 %t442, i64 %t443, ptr %t450, ptr %t451)
  br label %bb75
bb74:
  br label %bb77
bb75:
  br label %bb76
bb76:
  br label %bb77
bb77:
  %t452 = load i64, ptr %l18, !tbaa !24
  %t453 = load i64, ptr %l24, !tbaa !24
  %t456 = icmp slt i64 %t452, %t453
  br i1 %t456, label %bb78, label %bb79
bb78:
  %t458 = load i64, ptr %l24, !tbaa !24
  %t459 = load i64, ptr %l3, !tbaa !24
  %t462 = icmp slt i64 %t458, %t459
  store i1 %t462, ptr %l218, !tbaa !21
  br label %bb80
bb79:
  store i1 false, ptr %l218, !tbaa !21
  br label %bb80
bb80:
  %t464 = load i1, ptr %l218, !tbaa !21
  br i1 %t464, label %bb81, label %bb82
bb81:
  %t465 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t466 = load i64, ptr %l18, !tbaa !24
  %t467 = load i64, ptr %l24, !tbaa !24
  %t468 = load i64, ptr %l3, !tbaa !24
  %t469 = load { ptr, ptr }, ptr %l4
  %t475 = extractvalue { ptr, ptr } %t469, 0
  %t476 = extractvalue { ptr, ptr } %t469, 1
  call void @std_2fprelude_2farray_2esortMerge_3ccompiler_2fscope_3aPlacement_2c_20_3f_3e(ptr %v0, ptr %v1, { i64, ptr } %t465, i64 %t466, i64 %t467, i64 %t468, ptr %t475, ptr %t476)
  br label %bb83
bb82:
  br label %bb85
bb83:
  br label %bb84
bb84:
  br label %bb85
bb85:
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2farray_2esortRotate_3ccompiler_2fscope_3aPlacement_3e(ptr %v0, { i64, ptr } %a0, i64 %a1, i64 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l41 = alloca i64
  %l44 = alloca i64
  %l82 = alloca i64
  %l85 = alloca i64
  %l127 = alloca i64
  %l130 = alloca i64
  store { i64, ptr } %a0, ptr %l0
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l2, !tbaa !24
  %t5 = sub i64 %t1, %a1
  store i64 %t5, ptr %l4, !tbaa !24
  %t8 = load i64, ptr %l2, !tbaa !24
  %t11 = sub i64 %a3, %t8
  store i64 %t11, ptr %l5, !tbaa !24
  br label %bb1
bb1:
  %t13 = load i64, ptr %l4, !tbaa !24
  %t14 = load i64, ptr %l5, !tbaa !24
  %t17 = icmp ne i64 %t13, %t14
  %t19 = xor i1 %t17, true
  br i1 %t19, label %bb2, label %bb3
bb2:
  br label %bb35
bb3:
  br label %bb4
bb4:
  %t21 = load i64, ptr %l4, !tbaa !24
  %t22 = load i64, ptr %l5, !tbaa !24
  %t25 = icmp sgt i64 %t21, %t22
  br i1 %t25, label %bb5, label %bb6
bb5:
  store i64 0, ptr %l6, !tbaa !24
  %t27 = load i64, ptr %l5, !tbaa !24
  store i64 %t27, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t29 = load i64, ptr %l7, !tbaa !24
  %t30 = load i64, ptr %l6, !tbaa !24
  %t33 = icmp sgt i64 %t29, %t30
  br i1 %t33, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l12, !tbaa !24
  %t35 = load i64, ptr %l4, !tbaa !24
  store i64 %t35, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t37 = load i64, ptr %l13, !tbaa !24
  %t38 = load i64, ptr %l12, !tbaa !24
  %t41 = icmp sgt i64 %t37, %t38
  br i1 %t41, label %bb20, label %bb21
bb7:
  %t43 = load i64, ptr %l8, !tbaa !24
  %t45 = icmp sgt i64 %t43, 0
  br i1 %t45, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l41, !tbaa !24
  br label %bb12
bb9:
  %t47 = load i64, ptr %l7, !tbaa !24
  %t48 = load i64, ptr %l6, !tbaa !24
  %t51 = sub i64 %t47, %t48
  %t52 = load i64, ptr %l8, !tbaa !24
  %t55 = add i64 %t51, %t52
  %t57 = sub i64 %t55, 1
  %t58 = load i64, ptr %l8, !tbaa !24
  %t61 = sdiv i64 %t57, %t58
  store i64 %t61, ptr %l44, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l44, !tbaa !24
  br label %bb11
bb11:
  %t63 = load i64, ptr %l44, !tbaa !24
  store i64 %t63, ptr %l41, !tbaa !24
  br label %bb12
bb12:
  %t64 = load i64, ptr %l41, !tbaa !24
  store i64 %t64, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb13
bb13:
  %t65 = load i64, ptr %l10, !tbaa !24
  %t66 = load i64, ptr %l9, !tbaa !24
  %t69 = icmp slt i64 %t65, %t66
  %t71 = xor i1 %t69, true
  br i1 %t71, label %bb14, label %bb15
bb14:
  br label %bb19
bb15:
  br label %bb16
bb16:
  %t73 = load i64, ptr %l6, !tbaa !24
  %t74 = load i64, ptr %l10, !tbaa !24
  %t75 = load i64, ptr %l8, !tbaa !24
  %t78 = mul i64 %t74, %t75
  %t81 = add i64 %t73, %t78
  store i64 %t81, ptr %l11, !tbaa !24
  %t83 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t84 = load i64, ptr %l2, !tbaa !24
  %t85 = load i64, ptr %l4, !tbaa !24
  %t88 = sub i64 %t84, %t85
  %t89 = load i64, ptr %l11, !tbaa !24
  %t92 = add i64 %t88, %t89
  %t93 = load i64, ptr %l2, !tbaa !24
  %t94 = load i64, ptr %l11, !tbaa !24
  %t97 = add i64 %t93, %t94
  call void @std_2fprelude_2farray_2esortSwap_3ccompiler_2fscope_3aPlacement_3e(ptr %v0, { i64, ptr } %t83, i64 %t92, i64 %t97)
  br label %bb17
bb17:
  br label %bb18
bb18:
  %t101 = load i64, ptr %l10, !tbaa !24
  %t104 = add i64 %t101, 1
  store i64 %t104, ptr %l10, !tbaa !24
  br label %bb13
bb19:
  %t106 = load i64, ptr %l4, !tbaa !24
  %t108 = load i64, ptr %l5, !tbaa !24
  %t111 = sub i64 %t106, %t108
  store i64 %t111, ptr %l4, !tbaa !24
  br label %bb33
bb20:
  %t113 = load i64, ptr %l14, !tbaa !24
  %t115 = icmp sgt i64 %t113, 0
  br i1 %t115, label %bb22, label %bb23
bb21:
  store i64 0, ptr %l82, !tbaa !24
  br label %bb25
bb22:
  %t117 = load i64, ptr %l13, !tbaa !24
  %t118 = load i64, ptr %l12, !tbaa !24
  %t121 = sub i64 %t117, %t118
  %t122 = load i64, ptr %l14, !tbaa !24
  %t125 = add i64 %t121, %t122
  %t127 = sub i64 %t125, 1
  %t128 = load i64, ptr %l14, !tbaa !24
  %t131 = sdiv i64 %t127, %t128
  store i64 %t131, ptr %l85, !tbaa !24
  br label %bb24
bb23:
  store i64 0, ptr %l85, !tbaa !24
  br label %bb24
bb24:
  %t133 = load i64, ptr %l85, !tbaa !24
  store i64 %t133, ptr %l82, !tbaa !24
  br label %bb25
bb25:
  %t134 = load i64, ptr %l82, !tbaa !24
  store i64 %t134, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb26
bb26:
  %t135 = load i64, ptr %l16, !tbaa !24
  %t136 = load i64, ptr %l15, !tbaa !24
  %t139 = icmp slt i64 %t135, %t136
  %t141 = xor i1 %t139, true
  br i1 %t141, label %bb27, label %bb28
bb27:
  br label %bb32
bb28:
  br label %bb29
bb29:
  %t143 = load i64, ptr %l12, !tbaa !24
  %t144 = load i64, ptr %l16, !tbaa !24
  %t145 = load i64, ptr %l14, !tbaa !24
  %t148 = mul i64 %t144, %t145
  %t151 = add i64 %t143, %t148
  store i64 %t151, ptr %l17, !tbaa !24
  %t153 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t154 = load i64, ptr %l2, !tbaa !24
  %t155 = load i64, ptr %l4, !tbaa !24
  %t158 = sub i64 %t154, %t155
  %t159 = load i64, ptr %l17, !tbaa !24
  %t162 = add i64 %t158, %t159
  %t163 = load i64, ptr %l2, !tbaa !24
  %t164 = load i64, ptr %l5, !tbaa !24
  %t167 = add i64 %t163, %t164
  %t168 = load i64, ptr %l4, !tbaa !24
  %t171 = sub i64 %t167, %t168
  %t172 = load i64, ptr %l17, !tbaa !24
  %t175 = add i64 %t171, %t172
  call void @std_2fprelude_2farray_2esortSwap_3ccompiler_2fscope_3aPlacement_3e(ptr %v0, { i64, ptr } %t153, i64 %t162, i64 %t175)
  br label %bb30
bb30:
  br label %bb31
bb31:
  %t179 = load i64, ptr %l16, !tbaa !24
  %t182 = add i64 %t179, 1
  store i64 %t182, ptr %l16, !tbaa !24
  br label %bb26
bb32:
  %t184 = load i64, ptr %l5, !tbaa !24
  %t186 = load i64, ptr %l4, !tbaa !24
  %t189 = sub i64 %t184, %t186
  store i64 %t189, ptr %l5, !tbaa !24
  br label %bb33
bb33:
  br label %bb34
bb34:
  br label %bb1
bb35:
  store i64 0, ptr %l18, !tbaa !24
  %t191 = load i64, ptr %l4, !tbaa !24
  store i64 %t191, ptr %l19, !tbaa !24
  store i64 1, ptr %l20, !tbaa !24
  %t193 = load i64, ptr %l19, !tbaa !24
  %t194 = load i64, ptr %l18, !tbaa !24
  %t197 = icmp sgt i64 %t193, %t194
  br i1 %t197, label %bb36, label %bb37
bb36:
  %t199 = load i64, ptr %l20, !tbaa !24
  %t201 = icmp sgt i64 %t199, 0
  br i1 %t201, label %bb38, label %bb39
bb37:
  store i64 0, ptr %l127, !tbaa !24
  br label %bb41
bb38:
  %t203 = load i64, ptr %l19, !tbaa !24
  %t204 = load i64, ptr %l18, !tbaa !24
  %t207 = sub i64 %t203, %t204
  %t208 = load i64, ptr %l20, !tbaa !24
  %t211 = add i64 %t207, %t208
  %t213 = sub i64 %t211, 1
  %t214 = load i64, ptr %l20, !tbaa !24
  %t217 = sdiv i64 %t213, %t214
  store i64 %t217, ptr %l130, !tbaa !24
  br label %bb40
bb39:
  store i64 0, ptr %l130, !tbaa !24
  br label %bb40
bb40:
  %t219 = load i64, ptr %l130, !tbaa !24
  store i64 %t219, ptr %l127, !tbaa !24
  br label %bb41
bb41:
  %t220 = load i64, ptr %l127, !tbaa !24
  store i64 %t220, ptr %l21, !tbaa !24
  store i64 0, ptr %l22, !tbaa !24
  br label %bb42
bb42:
  %t221 = load i64, ptr %l22, !tbaa !24
  %t222 = load i64, ptr %l21, !tbaa !24
  %t225 = icmp slt i64 %t221, %t222
  %t227 = xor i1 %t225, true
  br i1 %t227, label %bb43, label %bb44
bb43:
  br label %bb48
bb44:
  br label %bb45
bb45:
  %t229 = load i64, ptr %l18, !tbaa !24
  %t230 = load i64, ptr %l22, !tbaa !24
  %t231 = load i64, ptr %l20, !tbaa !24
  %t234 = mul i64 %t230, %t231
  %t237 = add i64 %t229, %t234
  store i64 %t237, ptr %l23, !tbaa !24
  %t239 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t240 = load i64, ptr %l2, !tbaa !24
  %t241 = load i64, ptr %l4, !tbaa !24
  %t244 = sub i64 %t240, %t241
  %t245 = load i64, ptr %l23, !tbaa !24
  %t248 = add i64 %t244, %t245
  %t249 = load i64, ptr %l2, !tbaa !24
  %t250 = load i64, ptr %l23, !tbaa !24
  %t253 = add i64 %t249, %t250
  call void @std_2fprelude_2farray_2esortSwap_3ccompiler_2fscope_3aPlacement_3e(ptr %v0, { i64, ptr } %t239, i64 %t248, i64 %t253)
  br label %bb46
bb46:
  br label %bb47
bb47:
  %t257 = load i64, ptr %l22, !tbaa !24
  %t260 = add i64 %t257, 1
  store i64 %t260, ptr %l22, !tbaa !24
  br label %bb42
bb48:
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Array_3cI64_3e_3e_2ePut_3cI64_2c_20Array_3cI64_3e_3e(ptr %v0, ptr %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i64
  %l13 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l19 = alloca i64
  %l31 = alloca ptr
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca { i64, ptr }
  %l35 = alloca i64
  %l36 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %t21 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1, i32 0, i32 2
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp eq i64 %t6, 0
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l9, !tbaa !29
  %t11 = call ptr @__olang_region_make_part(ptr %v0)
  %t12 = ptrtoint ptr %t11 to i64
  store i64 %t12, ptr %l10, !tbaa !24
  %t13 = icmp sge i64 8, 0
  br i1 %t13, label %bb3, label %bb4
bb2:
  br label %bb9
bb3:
  %t15 = icmp sle i64 8, 1152921504606846975
  br i1 %t15, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_cb901f43eea5c9a0_3eb2537e81d31bc4)
  unreachable
bb5:
  %t17 = mul i64 8, 8
  %t18 = load i64, ptr %l10
  %t19 = inttoptr i64 %t18 to ptr
  %t20 = call ptr @__olang_held_alloc(ptr %t19, i64 %t17)
  store i64 0, ptr %t21
  br label %fill.22
fill.22:
  %t25 = load i64, ptr %t21
  %t26 = icmp slt i64 %t25, 8
  br i1 %t26, label %fillb.23, label %filld.24
fillb.23:
  %t27 = getelementptr i64, ptr %t20, i64 %t25
  store i64 -1, ptr %t27
  %t28 = add i64 %t25, 1
  store i64 %t28, ptr %t21
  br label %fill.22
filld.24:
  %t29 = insertvalue { i64, ptr } undef, i64 8, 0
  %t30 = insertvalue { i64, ptr } %t29, ptr %t20, 1
  store { i64, ptr } %t30, ptr %l13, !tbaa !27
  %t31 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  %t34 = icmp eq i64 %t32, 0
  br i1 %t34, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_cb901f43eea5c9a0_3eb2537e81d31bc4)
  unreachable
bb7:
  store { i64, ptr } zeroinitializer, ptr %l13, !tbaa !27
  br label %bb8
bb8:
  %t36 = load i64, ptr %l10
  %t37 = inttoptr i64 %t36 to ptr
  %t38 = load { i64, ptr }, ptr %l13
  %t39 = extractvalue { i64, ptr } %t38, 1
  %t40 = call ptr @__olang_region_or(ptr %t39, ptr null)
  %t41 = icmp ne ptr %t40, null
  %t42 = select i1 %t41, ptr %t40, ptr null
  call void @__olang_region_settle_in(ptr %t37, ptr %t42)
  %t43 = load ptr, ptr %l9, !tbaa !29
  %t44 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t43, i32 0, i32 2
  %t45 = load { i64, ptr }, ptr %t44, !tbaa !27
  store { i64, ptr } %t45, ptr %l16, !tbaa !27
  %t46 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t47 = load ptr, ptr %l9, !tbaa !29
  %t48 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t47, i32 0, i32 2
  store { i64, ptr } %t46, ptr %t48, !tbaa !27
  %t49 = load { i64, ptr }, ptr %l16
  %t50 = extractvalue { i64, ptr } %t49, 0
  %t51 = extractvalue { i64, ptr } %t49, 1
  call void @__olang_region_release_part(ptr %t51, i64 %t50)
  store { i64, ptr } zeroinitializer, ptr %l16
  br label %bb9
bb9:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load i64, ptr %l1, !tbaa !24
  %t56 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Array_3cI64_3e_3e_2ebucketOf_3cI64_2c_20Array_3cI64_3e_3e(ptr %v0, ptr %t52, i64 %t53)
  store i64 %t56, ptr %l19
  br label %bb10
bb10:
  %t57 = load i64, ptr %l19, !tbaa !24
  store i64 %t57, ptr %l3, !tbaa !24
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load i64, ptr %l3, !tbaa !24
  %t61 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t58, i32 0, i32 2
  %t63 = getelementptr { i64, ptr }, ptr %t61, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !27
  %t65 = getelementptr i64, ptr %t64, i64 %t59
  %t66 = load i64, ptr %t65, !tbaa !34
  store i64 %t66, ptr %l4, !tbaa !24
  br label %bb11
bb11:
  %t68 = load i64, ptr %l4, !tbaa !24
  %t70 = icmp sge i64 %t68, 0
  %t72 = xor i1 %t70, true
  br i1 %t72, label %bb12, label %bb13
bb12:
  br label %bb21
bb13:
  br label %bb14
bb14:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load i64, ptr %l4, !tbaa !24
  %t77 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t74, i32 0, i32 0
  %t79 = getelementptr { i64, ptr }, ptr %t77, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = getelementptr %"std/prelude/map:MapEntry.8d509622153b47f1a5f79c42c8367406", ptr %t80, i64 %t75
  %t82 = getelementptr %"std/prelude/map:MapEntry.8d509622153b47f1a5f79c42c8367406", ptr %t81, i32 0, i32 0
  %t83 = load i64, ptr %t82, !tbaa !24
  %t84 = load i64, ptr %l1, !tbaa !24
  %t87 = icmp eq i64 %t83, %t84
  br i1 %t87, label %bb15, label %bb16
bb15:
  %t89 = load ptr, ptr %l0, !tbaa !29
  store ptr %t89, ptr %l31, !tbaa !29
  %t90 = load i64, ptr %l4, !tbaa !24
  store i64 %t90, ptr %l32, !tbaa !24
  %t91 = call ptr @__olang_region_make_part(ptr %v0)
  %t92 = ptrtoint ptr %t91 to i64
  store i64 %t92, ptr %l33, !tbaa !24
  %t93 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t93, ptr %l34, !tbaa !27
  %t94 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t95 = extractvalue { i64, ptr } %t94, 0
  store i64 %t95, ptr %l35, !tbaa !24
  %t96 = load i64, ptr %l35, !tbaa !24
  %t97 = mul i64 %t96, 8
  %t98 = load i64, ptr %l33
  %t99 = inttoptr i64 %t98 to ptr
  %t100 = call ptr @__olang_held_alloc(ptr %t99, i64 %t97)
  %t101 = insertvalue { i64, ptr } undef, i64 %t96, 0
  %t102 = insertvalue { i64, ptr } %t101, ptr %t100, 1
  store { i64, ptr } %t102, ptr %l36, !tbaa !27
  %t103 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t104 = load ptr, ptr %t103, !tbaa !27
  %t105 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !27
  %t107 = load i64, ptr %l35, !tbaa !24
  %t108 = mul i64 %t107, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t104, ptr %t106, i64 %t108, i1 false)
  %t109 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t110 = extractvalue { i64, ptr } %t109, 0
  %t112 = icmp eq i64 %t110, 0
  br i1 %t112, label %bb17, label %bb18
bb16:
  br label %bb19
bb17:
  store { i64, ptr } zeroinitializer, ptr %l36, !tbaa !27
  br label %bb18
bb18:
  %t114 = load i64, ptr %l33
  %t115 = inttoptr i64 %t114 to ptr
  %t116 = load { i64, ptr }, ptr %l36
  %t117 = extractvalue { i64, ptr } %t116, 1
  %t118 = call ptr @__olang_region_or(ptr %t117, ptr null)
  %t119 = icmp ne ptr %t118, null
  %t120 = select i1 %t119, ptr %t118, ptr null
  call void @__olang_region_settle_in(ptr %t115, ptr %t120)
  %t121 = load ptr, ptr %l31, !tbaa !29
  %t122 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t121, i32 0, i32 0
  %t123 = load i64, ptr %l32, !tbaa !24
  %t124 = getelementptr { i64, ptr }, ptr %t122, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !27
  %t126 = getelementptr %"std/prelude/map:MapEntry.8d509622153b47f1a5f79c42c8367406", ptr %t125, i64 %t123
  %t127 = getelementptr %"std/prelude/map:MapEntry.8d509622153b47f1a5f79c42c8367406", ptr %t126, i32 0, i32 1
  %t128 = load { i64, ptr }, ptr %t127, !tbaa !27
  store { i64, ptr } %t128, ptr %l39, !tbaa !27
  %t129 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t130 = load ptr, ptr %l31, !tbaa !29
  %t131 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t130, i32 0, i32 0
  %t132 = load i64, ptr %l32, !tbaa !24
  %t133 = getelementptr { i64, ptr }, ptr %t131, i32 0, i32 1
  %t134 = load ptr, ptr %t133, !tbaa !27
  %t135 = getelementptr %"std/prelude/map:MapEntry.8d509622153b47f1a5f79c42c8367406", ptr %t134, i64 %t132
  %t136 = getelementptr %"std/prelude/map:MapEntry.8d509622153b47f1a5f79c42c8367406", ptr %t135, i32 0, i32 1
  store { i64, ptr } %t129, ptr %t136, !tbaa !27
  %t137 = load { i64, ptr }, ptr %l39
  %t138 = extractvalue { i64, ptr } %t137, 0
  %t139 = extractvalue { i64, ptr } %t137, 1
  call void @__olang_region_release_part(ptr %t139, i64 %t138)
  store { i64, ptr } zeroinitializer, ptr %l39
  br label %ret
bb19:
  br label %bb20
bb20:
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t141 = load i64, ptr %l4, !tbaa !24
  %t143 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t140, i32 0, i32 1
  %t145 = getelementptr { i64, ptr }, ptr %t143, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !27
  %t147 = getelementptr i64, ptr %t146, i64 %t141
  %t148 = load i64, ptr %t147, !tbaa !34
  store i64 %t148, ptr %l4, !tbaa !24
  br label %bb11
bb21:
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t151 = load i64, ptr %l3, !tbaa !24
  %t152 = load i64, ptr %l1, !tbaa !24
  %t153 = load { i64, ptr }, ptr %l2, !tbaa !27
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Array_3cI64_3e_3e_2eadd_3cI64_2c_20Array_3cI64_3e_3e(ptr %v0, ptr %t150, i64 %t151, i64 %t152, { i64, ptr } %t153)
  br label %bb22
bb22:
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Array_3cI64_3e_3e_2eroom_3cI64_2c_20Array_3cI64_3e_3e(ptr %v0, ptr %a0) noinline cold #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca { i64, ptr }
  %l5 = alloca i64
  %l7 = alloca { i64, ptr }
  %l9 = alloca i64
  %l14 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l31 = alloca i64
  %l33 = alloca { i64, ptr }
  %l34 = alloca i64
  %l40 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l49 = alloca i64
  %l50 = alloca i64
  %l54 = alloca ptr
  %l55 = alloca { i64, ptr }
  %l57 = alloca i64
  %l58 = alloca i64
  %l64 = alloca i64
  %l65 = alloca i64
  %l66 = alloca { i64, ptr }
  %l68 = alloca { i64, ptr }
  %l71 = alloca i64
  %l77 = alloca { i64, ptr }
  %l85 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp slt i64 %t6, 4
  br i1 %t8, label %bb1, label %bb2
bb1:
  store i64 8, ptr %l14, !tbaa !24
  br label %bb3
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t17 = mul i64 %t15, 2
  store i64 %t17, ptr %l14, !tbaa !24
  br label %bb3
bb3:
  %t19 = load i64, ptr %l14, !tbaa !24
  store i64 %t19, ptr %l1, !tbaa !24
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t20, i32 0, i32 0
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !27
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l21, !tbaa !29
  store { i64, ptr } %t23, ptr %l22, !tbaa !27
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t27, i32 0, i32 3
  %t30 = load i64, ptr %t29, !tbaa !24
  store i64 %t30, ptr %l24, !tbaa !24
  %t31 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  store i64 %t32, ptr %l25, !tbaa !24
  %t33 = icmp sge i64 0, 0
  br i1 %t33, label %bb4, label %bb5
bb4:
  %t35 = load i64, ptr %l24, !tbaa !24
  %t36 = icmp sle i64 0, %t35
  br i1 %t36, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_efc345d8d3eafa86_4789cc625aeb6fb2)
  unreachable
bb6:
  %t38 = load i64, ptr %l24, !tbaa !24
  %t39 = load i64, ptr %l25, !tbaa !24
  %t40 = icmp sle i64 %t38, %t39
  br i1 %t40, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_efc345d8d3eafa86_4789cc625aeb6fb2)
  unreachable
bb8:
  %t42 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = load i64, ptr %l24, !tbaa !24
  %t45 = getelementptr %"std/prelude/map:MapEntry.8d509622153b47f1a5f79c42c8367406", ptr %t43, i64 0
  %t46 = sub i64 %t44, 0
  %t47 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t45, 1
  store { i64, ptr } %t48, ptr %l3, !tbaa !27
  %t50 = load i64, ptr %l1, !tbaa !24
  %t52 = call ptr @__olang_region_make_part(ptr %v0)
  %t53 = ptrtoint ptr %t52 to i64
  store i64 %t53, ptr %l31, !tbaa !24
  %t56 = mul i64 %t50, 24
  %t57 = load i64, ptr %l31
  %t58 = inttoptr i64 %t57 to ptr
  %t59 = call ptr @__olang_scope_alloc_zeroed(ptr %t58, i64 %t56)
  %t60 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t61 = insertvalue { i64, ptr } %t60, ptr %t59, 1
  store { i64, ptr } %t61, ptr %l33, !tbaa !27
  store i64 0, ptr %l34, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_efc345d8d3eafa86_4789cc625aeb6fb2)
  unreachable
bb10:
  %t62 = load i64, ptr %l5, !tbaa !24
  %t63 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t63, 0
  %t68 = icmp slt i64 %t62, %t65
  %t70 = xor i1 %t68, true
  br i1 %t70, label %bb11, label %bb12
bb11:
  br label %bb15
bb12:
  br label %bb13
bb13:
  %t72 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t72, ptr %l40, !tbaa !27
  %t73 = load i64, ptr %l5, !tbaa !24
  %t75 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = getelementptr %"std/prelude/map:MapEntry.8d509622153b47f1a5f79c42c8367406", ptr %t76, i64 %t73
  %t78 = load %"std/prelude/map:MapEntry.8d509622153b47f1a5f79c42c8367406", ptr %t77
  store %"std/prelude/map:MapEntry.8d509622153b47f1a5f79c42c8367406" zeroinitializer, ptr %t77
  %t80 = load i64, ptr %l34, !tbaa !24
  %t81 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !27
  %t83 = getelementptr %"std/prelude/map:MapEntry.8d509622153b47f1a5f79c42c8367406", ptr %t82, i64 %t80
  store %"std/prelude/map:MapEntry.8d509622153b47f1a5f79c42c8367406" %t78, ptr %t83
  %t84 = load i64, ptr %l34, !tbaa !24
  %t85 = add i64 %t84, 1
  store i64 %t85, ptr %l34, !tbaa !24
  br label %bb14
bb14:
  %t86 = load i64, ptr %l5, !tbaa !24
  %t89 = add i64 %t86, 1
  store i64 %t89, ptr %l5, !tbaa !24
  br label %bb10
bb15:
  %t91 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t92 = extractvalue { i64, ptr } %t91, 0
  %t94 = icmp eq i64 %t92, 0
  br i1 %t94, label %bb16, label %bb17
bb16:
  store { i64, ptr } zeroinitializer, ptr %l33, !tbaa !27
  br label %bb17
bb17:
  %t96 = load i64, ptr %l31
  %t97 = inttoptr i64 %t96 to ptr
  %t98 = load { i64, ptr }, ptr %l33
  %t99 = extractvalue { i64, ptr } %t98, 1
  %t100 = call ptr @__olang_region_or(ptr %t99, ptr null)
  %t101 = icmp ne ptr %t100, null
  %t102 = select i1 %t101, ptr %t100, ptr null
  call void @__olang_region_settle_in(ptr %t97, ptr %t102)
  %t103 = load ptr, ptr %l21, !tbaa !29
  %t104 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t103, i32 0, i32 0
  %t105 = load { i64, ptr }, ptr %t104, !tbaa !27
  store { i64, ptr } %t105, ptr %l48, !tbaa !27
  %t106 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t107 = load ptr, ptr %l21, !tbaa !29
  %t108 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t107, i32 0, i32 0
  store { i64, ptr } %t106, ptr %t108, !tbaa !27
  %t109 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t110 = extractvalue { i64, ptr } %t109, 0
  store i64 %t110, ptr %l49, !tbaa !24
  store i64 0, ptr %l50, !tbaa !24
  br label %bb18
bb18:
  %t111 = load i64, ptr %l50, !tbaa !24
  %t112 = load i64, ptr %l49, !tbaa !24
  %t113 = icmp slt i64 %t111, %t112
  br i1 %t113, label %bb19, label %bb20
bb19:
  %t115 = load i64, ptr %l50, !tbaa !24
  %t116 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t117 = load ptr, ptr %t116, !tbaa !27
  %t118 = getelementptr %"std/prelude/map:MapEntry.8d509622153b47f1a5f79c42c8367406", ptr %t117, i64 %t115
  %t119 = getelementptr %"std/prelude/map:MapEntry.8d509622153b47f1a5f79c42c8367406", ptr %t118, i32 0, i32 1
  %t120 = load { i64, ptr }, ptr %t119
  %t121 = extractvalue { i64, ptr } %t120, 0
  %t122 = extractvalue { i64, ptr } %t120, 1
  call void @__olang_region_release_part(ptr %t122, i64 %t121)
  store { i64, ptr } zeroinitializer, ptr %t119
  %t123 = load i64, ptr %l50, !tbaa !24
  %t124 = add i64 %t123, 1
  store i64 %t124, ptr %l50, !tbaa !24
  br label %bb18
bb20:
  %t125 = load { i64, ptr }, ptr %l48
  %t126 = extractvalue { i64, ptr } %t125, 0
  %t127 = extractvalue { i64, ptr } %t125, 1
  call void @__olang_region_release_part(ptr %t127, i64 %t126)
  store { i64, ptr } zeroinitializer, ptr %l48
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t130 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t128, i32 0, i32 1
  %t131 = load { i64, ptr }, ptr %t130, !tbaa !27
  %t133 = load ptr, ptr %l0, !tbaa !29
  store ptr %t133, ptr %l54, !tbaa !29
  store { i64, ptr } %t131, ptr %l55, !tbaa !27
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t137 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t135, i32 0, i32 3
  %t138 = load i64, ptr %t137, !tbaa !24
  store i64 %t138, ptr %l57, !tbaa !24
  %t139 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t140 = extractvalue { i64, ptr } %t139, 0
  store i64 %t140, ptr %l58, !tbaa !24
  %t141 = icmp sge i64 0, 0
  br i1 %t141, label %bb21, label %bb22
bb21:
  %t143 = load i64, ptr %l57, !tbaa !24
  %t144 = icmp sle i64 0, %t143
  br i1 %t144, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_f01abca99f12a563_b260ce0f455ce82f)
  unreachable
bb23:
  %t146 = load i64, ptr %l57, !tbaa !24
  %t147 = load i64, ptr %l58, !tbaa !24
  %t148 = icmp sle i64 %t146, %t147
  br i1 %t148, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_f01abca99f12a563_b260ce0f455ce82f)
  unreachable
bb25:
  %t150 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t151 = load ptr, ptr %t150, !tbaa !27
  %t152 = load i64, ptr %l57, !tbaa !24
  %t153 = getelementptr i64, ptr %t151, i64 0
  %t154 = sub i64 %t152, 0
  %t155 = insertvalue { i64, ptr } undef, i64 %t154, 0
  %t156 = insertvalue { i64, ptr } %t155, ptr %t153, 1
  store { i64, ptr } %t156, ptr %l7, !tbaa !27
  %t158 = load i64, ptr %l1, !tbaa !24
  %t160 = call ptr @__olang_region_make_part(ptr %v0)
  %t161 = ptrtoint ptr %t160 to i64
  store i64 %t161, ptr %l64, !tbaa !24
  store i64 %t158, ptr %l65, !tbaa !24
  %t163 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t165 = load i64, ptr %l65, !tbaa !24
  %t166 = extractvalue { i64, ptr } %t163, 0
  %t167 = mul i64 %t166, 8
  %t168 = mul i64 %t165, 8
  %t169 = extractvalue { i64, ptr } %t163, 1
  %t170 = call ptr @__olang_grow_in_place(ptr %t169, i64 %t167, i64 %t168, i64 %t165)
  %t171 = icmp ne ptr %t170, null
  %t172 = select i1 %t171, i64 %t165, i64 0
  %t173 = insertvalue { i64, ptr } undef, i64 %t172, 0
  %t174 = insertvalue { i64, ptr } %t173, ptr %t170, 1
  store { i64, ptr } %t174, ptr %l68, !tbaa !27
  %t175 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t176 = extractvalue { i64, ptr } %t175, 0
  %t178 = icmp ne i64 %t176, 0
  br i1 %t178, label %bb27, label %bb28
bb26:
  call void @__olang_check_failed(ptr @olang_loc_f01abca99f12a563_b260ce0f455ce82f)
  unreachable
bb27:
  %t180 = load { i64, ptr }, ptr %l68, !tbaa !27
  store { i64, ptr } %t180, ptr %l66, !tbaa !27
  br label %bb29
bb28:
  %t181 = load i64, ptr %l65, !tbaa !24
  %t182 = mul i64 %t181, 8
  %t183 = load i64, ptr %l64
  %t184 = inttoptr i64 %t183 to ptr
  %t185 = call ptr @__olang_held_alloc(ptr %t184, i64 %t182)
  %t186 = insertvalue { i64, ptr } undef, i64 %t181, 0
  %t187 = insertvalue { i64, ptr } %t186, ptr %t185, 1
  store { i64, ptr } %t187, ptr %l66, !tbaa !27
  store i64 0, ptr %l71, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb30
bb29:
  %t188 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t189 = extractvalue { i64, ptr } %t188, 0
  %t191 = icmp eq i64 %t189, 0
  br i1 %t191, label %bb36, label %bb37
bb30:
  %t193 = load i64, ptr %l9, !tbaa !24
  %t194 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t196 = extractvalue { i64, ptr } %t194, 0
  %t199 = icmp slt i64 %t193, %t196
  %t201 = xor i1 %t199, true
  br i1 %t201, label %bb31, label %bb32
bb31:
  br label %bb35
bb32:
  br label %bb33
bb33:
  %t203 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t203, ptr %l77, !tbaa !27
  %t204 = load i64, ptr %l9, !tbaa !24
  %t206 = getelementptr { i64, ptr }, ptr %l77, i32 0, i32 1
  %t207 = load ptr, ptr %t206, !tbaa !27
  %t208 = getelementptr i64, ptr %t207, i64 %t204
  %t209 = load i64, ptr %t208, !tbaa !34
  %t211 = load i64, ptr %l71, !tbaa !24
  %t212 = getelementptr { i64, ptr }, ptr %l66, i32 0, i32 1
  %t213 = load ptr, ptr %t212, !tbaa !27
  %t214 = getelementptr i64, ptr %t213, i64 %t211
  store i64 %t209, ptr %t214, !tbaa !34
  %t215 = load i64, ptr %l71, !tbaa !24
  %t216 = add i64 %t215, 1
  store i64 %t216, ptr %l71, !tbaa !24
  br label %bb34
bb34:
  %t217 = load i64, ptr %l9, !tbaa !24
  %t220 = add i64 %t217, 1
  store i64 %t220, ptr %l9, !tbaa !24
  br label %bb30
bb35:
  br label %bb29
bb36:
  store { i64, ptr } zeroinitializer, ptr %l66, !tbaa !27
  br label %bb37
bb37:
  %t222 = load i64, ptr %l64
  %t223 = inttoptr i64 %t222 to ptr
  %t224 = load { i64, ptr }, ptr %l66
  %t225 = extractvalue { i64, ptr } %t224, 1
  %t226 = call ptr @__olang_region_or(ptr %t225, ptr null)
  %t227 = icmp ne ptr %t226, null
  %t228 = select i1 %t227, ptr %t226, ptr null
  call void @__olang_region_settle_in(ptr %t223, ptr %t228)
  %t229 = load ptr, ptr %l54, !tbaa !29
  %t230 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t229, i32 0, i32 1
  %t231 = load { i64, ptr }, ptr %t230, !tbaa !27
  store { i64, ptr } %t231, ptr %l85, !tbaa !27
  %t232 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t233 = load ptr, ptr %l54, !tbaa !29
  %t234 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t233, i32 0, i32 1
  store { i64, ptr } %t232, ptr %t234, !tbaa !27
  %t235 = load { i64, ptr }, ptr %l85
  %t236 = extractvalue { i64, ptr } %t235, 0
  %t237 = extractvalue { i64, ptr } %t235, 1
  call void @__olang_region_release_part(ptr %t237, i64 %t236)
  store { i64, ptr } zeroinitializer, ptr %l85
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Array_3ccompiler_2ftyped_3aBl_H2003e1165b947ef2f9b081fd0aeb277d(ptr %v0, ptr %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i64
  %l13 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l19 = alloca i64
  %l31 = alloca ptr
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca { i64, ptr }
  %l35 = alloca i64
  %l36 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %t21 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1, i32 0, i32 2
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp eq i64 %t6, 0
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l9, !tbaa !29
  %t11 = call ptr @__olang_region_make_part(ptr %v0)
  %t12 = ptrtoint ptr %t11 to i64
  store i64 %t12, ptr %l10, !tbaa !24
  %t13 = icmp sge i64 8, 0
  br i1 %t13, label %bb3, label %bb4
bb2:
  br label %bb9
bb3:
  %t15 = icmp sle i64 8, 1152921504606846975
  br i1 %t15, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_f6472837ebf15fa0_30dce77208a6bfbc)
  unreachable
bb5:
  %t17 = mul i64 8, 8
  %t18 = load i64, ptr %l10
  %t19 = inttoptr i64 %t18 to ptr
  %t20 = call ptr @__olang_held_alloc(ptr %t19, i64 %t17)
  store i64 0, ptr %t21
  br label %fill.22
fill.22:
  %t25 = load i64, ptr %t21
  %t26 = icmp slt i64 %t25, 8
  br i1 %t26, label %fillb.23, label %filld.24
fillb.23:
  %t27 = getelementptr i64, ptr %t20, i64 %t25
  store i64 -1, ptr %t27
  %t28 = add i64 %t25, 1
  store i64 %t28, ptr %t21
  br label %fill.22
filld.24:
  %t29 = insertvalue { i64, ptr } undef, i64 8, 0
  %t30 = insertvalue { i64, ptr } %t29, ptr %t20, 1
  store { i64, ptr } %t30, ptr %l13, !tbaa !27
  %t31 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  %t34 = icmp eq i64 %t32, 0
  br i1 %t34, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_f6472837ebf15fa0_30dce77208a6bfbc)
  unreachable
bb7:
  store { i64, ptr } zeroinitializer, ptr %l13, !tbaa !27
  br label %bb8
bb8:
  %t36 = load i64, ptr %l10
  %t37 = inttoptr i64 %t36 to ptr
  %t38 = load { i64, ptr }, ptr %l13
  %t39 = extractvalue { i64, ptr } %t38, 1
  %t40 = call ptr @__olang_region_or(ptr %t39, ptr null)
  %t41 = icmp ne ptr %t40, null
  %t42 = select i1 %t41, ptr %t40, ptr null
  call void @__olang_region_settle_in(ptr %t37, ptr %t42)
  %t43 = load ptr, ptr %l9, !tbaa !29
  %t44 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t43, i32 0, i32 2
  %t45 = load { i64, ptr }, ptr %t44, !tbaa !27
  store { i64, ptr } %t45, ptr %l16, !tbaa !27
  %t46 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t47 = load ptr, ptr %l9, !tbaa !29
  %t48 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t47, i32 0, i32 2
  store { i64, ptr } %t46, ptr %t48, !tbaa !27
  %t49 = load { i64, ptr }, ptr %l16
  %t50 = extractvalue { i64, ptr } %t49, 0
  %t51 = extractvalue { i64, ptr } %t49, 1
  call void @__olang_region_release_part(ptr %t51, i64 %t50)
  store { i64, ptr } zeroinitializer, ptr %l16
  br label %bb9
bb9:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load i64, ptr %l1, !tbaa !24
  %t56 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Array_3cI64_3e_3e_2ebucketOf_3cI64_2c_20Array_3cI64_3e_3e(ptr %v0, ptr %t52, i64 %t53)
  store i64 %t56, ptr %l19
  br label %bb10
bb10:
  %t57 = load i64, ptr %l19, !tbaa !24
  store i64 %t57, ptr %l3, !tbaa !24
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load i64, ptr %l3, !tbaa !24
  %t61 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t58, i32 0, i32 2
  %t63 = getelementptr { i64, ptr }, ptr %t61, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !27
  %t65 = getelementptr i64, ptr %t64, i64 %t59
  %t66 = load i64, ptr %t65, !tbaa !34
  store i64 %t66, ptr %l4, !tbaa !24
  br label %bb11
bb11:
  %t68 = load i64, ptr %l4, !tbaa !24
  %t70 = icmp sge i64 %t68, 0
  %t72 = xor i1 %t70, true
  br i1 %t72, label %bb12, label %bb13
bb12:
  br label %bb21
bb13:
  br label %bb14
bb14:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load i64, ptr %l4, !tbaa !24
  %t77 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t74, i32 0, i32 0
  %t79 = getelementptr { i64, ptr }, ptr %t77, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = getelementptr %"std/prelude/map:MapEntry.8d509622153b47f1a5f79c42c8367406", ptr %t80, i64 %t75
  %t82 = getelementptr %"std/prelude/map:MapEntry.8d509622153b47f1a5f79c42c8367406", ptr %t81, i32 0, i32 0
  %t83 = load i64, ptr %t82, !tbaa !24
  %t84 = load i64, ptr %l1, !tbaa !24
  %t87 = icmp eq i64 %t83, %t84
  br i1 %t87, label %bb15, label %bb16
bb15:
  %t89 = load ptr, ptr %l0, !tbaa !29
  store ptr %t89, ptr %l31, !tbaa !29
  %t90 = load i64, ptr %l4, !tbaa !24
  store i64 %t90, ptr %l32, !tbaa !24
  %t91 = call ptr @__olang_region_make_part(ptr %v0)
  %t92 = ptrtoint ptr %t91 to i64
  store i64 %t92, ptr %l33, !tbaa !24
  %t93 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t93, ptr %l34, !tbaa !27
  %t94 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t95 = extractvalue { i64, ptr } %t94, 0
  store i64 %t95, ptr %l35, !tbaa !24
  %t96 = load i64, ptr %l35, !tbaa !24
  %t97 = mul i64 %t96, 4
  %t98 = load i64, ptr %l33
  %t99 = inttoptr i64 %t98 to ptr
  %t100 = call ptr @__olang_held_alloc(ptr %t99, i64 %t97)
  %t101 = insertvalue { i64, ptr } undef, i64 %t96, 0
  %t102 = insertvalue { i64, ptr } %t101, ptr %t100, 1
  store { i64, ptr } %t102, ptr %l36, !tbaa !27
  %t103 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t104 = load ptr, ptr %t103, !tbaa !27
  %t105 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !27
  %t107 = load i64, ptr %l35, !tbaa !24
  %t108 = mul i64 %t107, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t104, ptr %t106, i64 %t108, i1 false)
  %t109 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t110 = extractvalue { i64, ptr } %t109, 0
  %t112 = icmp eq i64 %t110, 0
  br i1 %t112, label %bb17, label %bb18
bb16:
  br label %bb19
bb17:
  store { i64, ptr } zeroinitializer, ptr %l36, !tbaa !27
  br label %bb18
bb18:
  %t114 = load i64, ptr %l33
  %t115 = inttoptr i64 %t114 to ptr
  %t116 = load { i64, ptr }, ptr %l36
  %t117 = extractvalue { i64, ptr } %t116, 1
  %t118 = call ptr @__olang_region_or(ptr %t117, ptr null)
  %t119 = icmp ne ptr %t118, null
  %t120 = select i1 %t119, ptr %t118, ptr null
  call void @__olang_region_settle_in(ptr %t115, ptr %t120)
  %t121 = load ptr, ptr %l31, !tbaa !29
  %t122 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t121, i32 0, i32 0
  %t123 = load i64, ptr %l32, !tbaa !24
  %t124 = getelementptr { i64, ptr }, ptr %t122, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !27
  %t126 = getelementptr %"std/prelude/map:MapEntry.8d509622153b47f1a5f79c42c8367406", ptr %t125, i64 %t123
  %t127 = getelementptr %"std/prelude/map:MapEntry.8d509622153b47f1a5f79c42c8367406", ptr %t126, i32 0, i32 1
  %t128 = load { i64, ptr }, ptr %t127, !tbaa !27
  store { i64, ptr } %t128, ptr %l39, !tbaa !27
  %t129 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t130 = load ptr, ptr %l31, !tbaa !29
  %t131 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t130, i32 0, i32 0
  %t132 = load i64, ptr %l32, !tbaa !24
  %t133 = getelementptr { i64, ptr }, ptr %t131, i32 0, i32 1
  %t134 = load ptr, ptr %t133, !tbaa !27
  %t135 = getelementptr %"std/prelude/map:MapEntry.8d509622153b47f1a5f79c42c8367406", ptr %t134, i64 %t132
  %t136 = getelementptr %"std/prelude/map:MapEntry.8d509622153b47f1a5f79c42c8367406", ptr %t135, i32 0, i32 1
  store { i64, ptr } %t129, ptr %t136, !tbaa !27
  %t137 = load { i64, ptr }, ptr %l39
  %t138 = extractvalue { i64, ptr } %t137, 0
  %t139 = extractvalue { i64, ptr } %t137, 1
  call void @__olang_region_release_part(ptr %t139, i64 %t138)
  store { i64, ptr } zeroinitializer, ptr %l39
  br label %ret
bb19:
  br label %bb20
bb20:
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t141 = load i64, ptr %l4, !tbaa !24
  %t143 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t140, i32 0, i32 1
  %t145 = getelementptr { i64, ptr }, ptr %t143, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !27
  %t147 = getelementptr i64, ptr %t146, i64 %t141
  %t148 = load i64, ptr %t147, !tbaa !34
  store i64 %t148, ptr %l4, !tbaa !24
  br label %bb11
bb21:
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t151 = load i64, ptr %l3, !tbaa !24
  %t152 = load i64, ptr %l1, !tbaa !24
  %t153 = load { i64, ptr }, ptr %l2, !tbaa !27
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Array_3ccompiler_2ftyped_3aBl_H6d0037fa94350b00beccb9ab942eac64(ptr %v0, ptr %t150, i64 %t151, i64 %t152, { i64, ptr } %t153)
  br label %bb22
bb22:
  br label %ret
ret:
  ret void
}

@std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Array_3ccompiler_2ftyped_3aBl_H7ccb72b7985b2d862bf28711ea395672 = dso_local alias void (ptr, ptr), ptr @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Array_3cI64_3e_3e_2eroom_3cI64_2c_20Array_3cI64_3e_3e
define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Array_3ccompiler_2ftyped_3aCa_Hb13711e4351c1f9050a29351fe6711db(ptr %v0, ptr %a0) noinline cold #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l5 = alloca i64
  %l7 = alloca { i64, ptr }
  %l9 = alloca i64
  %l14 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l32 = alloca { i64, ptr }
  %l33 = alloca i64
  %l39 = alloca { i64, ptr }
  %l49 = alloca ptr
  %l50 = alloca { i64, ptr }
  %l52 = alloca i64
  %l53 = alloca i64
  %l59 = alloca i64
  %l60 = alloca i64
  %l61 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %l66 = alloca i64
  %l72 = alloca { i64, ptr }
  %l80 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp slt i64 %t6, 4
  br i1 %t8, label %bb1, label %bb2
bb1:
  store i64 8, ptr %l14, !tbaa !24
  br label %bb3
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t17 = mul i64 %t15, 2
  store i64 %t17, ptr %l14, !tbaa !24
  br label %bb3
bb3:
  %t19 = load i64, ptr %l14, !tbaa !24
  store i64 %t19, ptr %l1, !tbaa !24
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t20, i32 0, i32 0
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !27
  store { i64, ptr } %t23, ptr %l2, !tbaa !27
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l21, !tbaa !29
  %t26 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t26, ptr %l22, !tbaa !27
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t27, i32 0, i32 3
  %t30 = load i64, ptr %t29, !tbaa !24
  store i64 %t30, ptr %l24, !tbaa !24
  %t31 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  store i64 %t32, ptr %l25, !tbaa !24
  %t33 = icmp sge i64 0, 0
  br i1 %t33, label %bb4, label %bb5
bb4:
  %t35 = load i64, ptr %l24, !tbaa !24
  %t36 = icmp sle i64 0, %t35
  br i1 %t36, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_3528876d0c13efc_db479c62e0d308a8)
  unreachable
bb6:
  %t38 = load i64, ptr %l24, !tbaa !24
  %t39 = load i64, ptr %l25, !tbaa !24
  %t40 = icmp sle i64 %t38, %t39
  br i1 %t40, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_3528876d0c13efc_db479c62e0d308a8)
  unreachable
bb8:
  %t42 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = load i64, ptr %l24, !tbaa !24
  %t45 = getelementptr %"std/prelude/map:MapEntry.8d509622153b47f1a5f79c42c8367406", ptr %t43, i64 0
  %t46 = sub i64 %t44, 0
  %t47 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t45, 1
  store { i64, ptr } %t48, ptr %l3, !tbaa !27
  %t50 = load i64, ptr %l1, !tbaa !24
  %t54 = mul i64 %t50, 24
  %t55 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t54)
  %t56 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t55, 1
  store { i64, ptr } %t57, ptr %l32, !tbaa !27
  store i64 0, ptr %l33, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_3528876d0c13efc_db479c62e0d308a8)
  unreachable
bb10:
  %t58 = load i64, ptr %l5, !tbaa !24
  %t59 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t61 = extractvalue { i64, ptr } %t59, 0
  %t64 = icmp slt i64 %t58, %t61
  %t66 = xor i1 %t64, true
  br i1 %t66, label %bb11, label %bb12
bb11:
  br label %bb15
bb12:
  br label %bb13
bb13:
  %t68 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t68, ptr %l39, !tbaa !27
  %t69 = load i64, ptr %l5, !tbaa !24
  %t71 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !27
  %t73 = getelementptr %"std/prelude/map:MapEntry.8d509622153b47f1a5f79c42c8367406", ptr %t72, i64 %t69
  %t74 = load %"std/prelude/map:MapEntry.8d509622153b47f1a5f79c42c8367406", ptr %t73
  store %"std/prelude/map:MapEntry.8d509622153b47f1a5f79c42c8367406" zeroinitializer, ptr %t73
  %t76 = load i64, ptr %l33, !tbaa !24
  %t77 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = getelementptr %"std/prelude/map:MapEntry.8d509622153b47f1a5f79c42c8367406", ptr %t78, i64 %t76
  store %"std/prelude/map:MapEntry.8d509622153b47f1a5f79c42c8367406" %t74, ptr %t79
  %t80 = load i64, ptr %l33, !tbaa !24
  %t81 = add i64 %t80, 1
  store i64 %t81, ptr %l33, !tbaa !24
  br label %bb14
bb14:
  %t82 = load i64, ptr %l5, !tbaa !24
  %t85 = add i64 %t82, 1
  store i64 %t85, ptr %l5, !tbaa !24
  br label %bb10
bb15:
  %t87 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t88 = load ptr, ptr %l21, !tbaa !29
  %t89 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t88, i32 0, i32 0
  store { i64, ptr } %t87, ptr %t89, !tbaa !27
  %t90 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t92, i32 0, i32 1
  %t95 = load { i64, ptr }, ptr %t94, !tbaa !27
  %t97 = load ptr, ptr %l0, !tbaa !29
  store ptr %t97, ptr %l49, !tbaa !29
  store { i64, ptr } %t95, ptr %l50, !tbaa !27
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t99, i32 0, i32 3
  %t102 = load i64, ptr %t101, !tbaa !24
  store i64 %t102, ptr %l52, !tbaa !24
  %t103 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t104 = extractvalue { i64, ptr } %t103, 0
  store i64 %t104, ptr %l53, !tbaa !24
  %t105 = icmp sge i64 0, 0
  br i1 %t105, label %bb16, label %bb17
bb16:
  %t107 = load i64, ptr %l52, !tbaa !24
  %t108 = icmp sle i64 0, %t107
  br i1 %t108, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_cd6172c4357b6ce9_3d4b800321d5e485)
  unreachable
bb18:
  %t110 = load i64, ptr %l52, !tbaa !24
  %t111 = load i64, ptr %l53, !tbaa !24
  %t112 = icmp sle i64 %t110, %t111
  br i1 %t112, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_cd6172c4357b6ce9_3d4b800321d5e485)
  unreachable
bb20:
  %t114 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !27
  %t116 = load i64, ptr %l52, !tbaa !24
  %t117 = getelementptr i64, ptr %t115, i64 0
  %t118 = sub i64 %t116, 0
  %t119 = insertvalue { i64, ptr } undef, i64 %t118, 0
  %t120 = insertvalue { i64, ptr } %t119, ptr %t117, 1
  store { i64, ptr } %t120, ptr %l7, !tbaa !27
  %t122 = load i64, ptr %l1, !tbaa !24
  %t124 = call ptr @__olang_region_make_part(ptr %v0)
  %t125 = ptrtoint ptr %t124 to i64
  store i64 %t125, ptr %l59, !tbaa !24
  store i64 %t122, ptr %l60, !tbaa !24
  %t127 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t129 = load i64, ptr %l60, !tbaa !24
  %t130 = extractvalue { i64, ptr } %t127, 0
  %t131 = mul i64 %t130, 8
  %t132 = mul i64 %t129, 8
  %t133 = extractvalue { i64, ptr } %t127, 1
  %t134 = call ptr @__olang_grow_in_place(ptr %t133, i64 %t131, i64 %t132, i64 %t129)
  %t135 = icmp ne ptr %t134, null
  %t136 = select i1 %t135, i64 %t129, i64 0
  %t137 = insertvalue { i64, ptr } undef, i64 %t136, 0
  %t138 = insertvalue { i64, ptr } %t137, ptr %t134, 1
  store { i64, ptr } %t138, ptr %l63, !tbaa !27
  %t139 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t140 = extractvalue { i64, ptr } %t139, 0
  %t142 = icmp ne i64 %t140, 0
  br i1 %t142, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_cd6172c4357b6ce9_3d4b800321d5e485)
  unreachable
bb22:
  %t144 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t144, ptr %l61, !tbaa !27
  br label %bb24
bb23:
  %t145 = load i64, ptr %l60, !tbaa !24
  %t146 = mul i64 %t145, 8
  %t147 = load i64, ptr %l59
  %t148 = inttoptr i64 %t147 to ptr
  %t149 = call ptr @__olang_held_alloc(ptr %t148, i64 %t146)
  %t150 = insertvalue { i64, ptr } undef, i64 %t145, 0
  %t151 = insertvalue { i64, ptr } %t150, ptr %t149, 1
  store { i64, ptr } %t151, ptr %l61, !tbaa !27
  store i64 0, ptr %l66, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb25
bb24:
  %t152 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t153 = extractvalue { i64, ptr } %t152, 0
  %t155 = icmp eq i64 %t153, 0
  br i1 %t155, label %bb31, label %bb32
bb25:
  %t157 = load i64, ptr %l9, !tbaa !24
  %t158 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t160 = extractvalue { i64, ptr } %t158, 0
  %t163 = icmp slt i64 %t157, %t160
  %t165 = xor i1 %t163, true
  br i1 %t165, label %bb26, label %bb27
bb26:
  br label %bb30
bb27:
  br label %bb28
bb28:
  %t167 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t167, ptr %l72, !tbaa !27
  %t168 = load i64, ptr %l9, !tbaa !24
  %t170 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t171 = load ptr, ptr %t170, !tbaa !27
  %t172 = getelementptr i64, ptr %t171, i64 %t168
  %t173 = load i64, ptr %t172, !tbaa !34
  %t175 = load i64, ptr %l66, !tbaa !24
  %t176 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t177 = load ptr, ptr %t176, !tbaa !27
  %t178 = getelementptr i64, ptr %t177, i64 %t175
  store i64 %t173, ptr %t178, !tbaa !34
  %t179 = load i64, ptr %l66, !tbaa !24
  %t180 = add i64 %t179, 1
  store i64 %t180, ptr %l66, !tbaa !24
  br label %bb29
bb29:
  %t181 = load i64, ptr %l9, !tbaa !24
  %t184 = add i64 %t181, 1
  store i64 %t184, ptr %l9, !tbaa !24
  br label %bb25
bb30:
  br label %bb24
bb31:
  store { i64, ptr } zeroinitializer, ptr %l61, !tbaa !27
  br label %bb32
bb32:
  %t186 = load i64, ptr %l59
  %t187 = inttoptr i64 %t186 to ptr
  %t188 = load { i64, ptr }, ptr %l61
  %t189 = extractvalue { i64, ptr } %t188, 1
  %t190 = call ptr @__olang_region_or(ptr %t189, ptr null)
  %t191 = icmp ne ptr %t190, null
  %t192 = select i1 %t191, ptr %t190, ptr null
  call void @__olang_region_settle_in(ptr %t187, ptr %t192)
  %t193 = load ptr, ptr %l49, !tbaa !29
  %t194 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t193, i32 0, i32 1
  %t195 = load { i64, ptr }, ptr %t194, !tbaa !27
  store { i64, ptr } %t195, ptr %l80, !tbaa !27
  %t196 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t197 = load ptr, ptr %l49, !tbaa !29
  %t198 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t197, i32 0, i32 1
  store { i64, ptr } %t196, ptr %t198, !tbaa !27
  %t199 = load { i64, ptr }, ptr %l80
  %t200 = extractvalue { i64, ptr } %t199, 0
  %t201 = extractvalue { i64, ptr } %t199, 1
  call void @__olang_region_release_part(ptr %t201, i64 %t200)
  store { i64, ptr } zeroinitializer, ptr %l80
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eroom_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0) noinline cold #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l9 = alloca i64
  %l14 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l31 = alloca i64
  %l32 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l37 = alloca i64
  %l43 = alloca { i64, ptr }
  %l53 = alloca ptr
  %l54 = alloca { i64, ptr }
  %l56 = alloca i64
  %l57 = alloca i64
  %l63 = alloca i64
  %l64 = alloca { i64, ptr }
  %l66 = alloca { i64, ptr }
  %l69 = alloca i64
  %l75 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp slt i64 %t6, 4
  br i1 %t8, label %bb1, label %bb2
bb1:
  store i64 8, ptr %l14, !tbaa !24
  br label %bb3
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t17 = mul i64 %t15, 2
  store i64 %t17, ptr %l14, !tbaa !24
  br label %bb3
bb3:
  %t19 = load i64, ptr %l14, !tbaa !24
  store i64 %t19, ptr %l1, !tbaa !24
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t20, i32 0, i32 0
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !27
  store { i64, ptr } %t23, ptr %l2, !tbaa !27
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l21, !tbaa !29
  %t26 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t26, ptr %l22, !tbaa !27
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t27, i32 0, i32 3
  %t30 = load i64, ptr %t29, !tbaa !24
  store i64 %t30, ptr %l24, !tbaa !24
  %t31 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  store i64 %t32, ptr %l25, !tbaa !24
  %t33 = icmp sge i64 0, 0
  br i1 %t33, label %bb4, label %bb5
bb4:
  %t35 = load i64, ptr %l24, !tbaa !24
  %t36 = icmp sle i64 0, %t35
  br i1 %t36, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_1a4d5a334653e862_10d80ed88f47b4fe)
  unreachable
bb6:
  %t38 = load i64, ptr %l24, !tbaa !24
  %t39 = load i64, ptr %l25, !tbaa !24
  %t40 = icmp sle i64 %t38, %t39
  br i1 %t40, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_1a4d5a334653e862_10d80ed88f47b4fe)
  unreachable
bb8:
  %t42 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = load i64, ptr %l24, !tbaa !24
  %t45 = getelementptr %"std/prelude/map:MapEntry.eb00e4a6e4307a4e46e40fbcd79d6b4f", ptr %t43, i64 0
  %t46 = sub i64 %t44, 0
  %t47 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t45, 1
  store { i64, ptr } %t48, ptr %l3, !tbaa !27
  %t50 = load i64, ptr %l1, !tbaa !24
  store i64 %t50, ptr %l31, !tbaa !24
  %t53 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t55 = load i64, ptr %l31, !tbaa !24
  %t56 = extractvalue { i64, ptr } %t53, 0
  %t57 = mul i64 %t56, 16
  %t58 = mul i64 %t55, 16
  %t59 = extractvalue { i64, ptr } %t53, 1
  %t60 = call ptr @__olang_grow_in_place(ptr %t59, i64 %t57, i64 %t58, i64 %t55)
  %t61 = icmp ne ptr %t60, null
  %t62 = select i1 %t61, i64 %t55, i64 0
  %t63 = insertvalue { i64, ptr } undef, i64 %t62, 0
  %t64 = insertvalue { i64, ptr } %t63, ptr %t60, 1
  store { i64, ptr } %t64, ptr %l34, !tbaa !27
  %t65 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t66 = extractvalue { i64, ptr } %t65, 0
  %t68 = icmp ne i64 %t66, 0
  br i1 %t68, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_1a4d5a334653e862_10d80ed88f47b4fe)
  unreachable
bb10:
  %t70 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t70, ptr %l32, !tbaa !27
  br label %bb12
bb11:
  %t71 = load i64, ptr %l31, !tbaa !24
  %t72 = mul i64 %t71, 16
  %t73 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t72)
  %t74 = insertvalue { i64, ptr } undef, i64 %t71, 0
  %t75 = insertvalue { i64, ptr } %t74, ptr %t73, 1
  store { i64, ptr } %t75, ptr %l32, !tbaa !27
  store i64 0, ptr %l37, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb13
bb12:
  %t76 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t77 = load ptr, ptr %l21, !tbaa !29
  %t78 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t77, i32 0, i32 0
  store { i64, ptr } %t76, ptr %t78, !tbaa !27
  %t79 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t81, i32 0, i32 1
  %t84 = load { i64, ptr }, ptr %t83, !tbaa !27
  store { i64, ptr } %t84, ptr %l6, !tbaa !27
  %t86 = load ptr, ptr %l0, !tbaa !29
  store ptr %t86, ptr %l53, !tbaa !29
  %t87 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t87, ptr %l54, !tbaa !27
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t88, i32 0, i32 3
  %t91 = load i64, ptr %t90, !tbaa !24
  store i64 %t91, ptr %l56, !tbaa !24
  %t92 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t93 = extractvalue { i64, ptr } %t92, 0
  store i64 %t93, ptr %l57, !tbaa !24
  %t94 = icmp sge i64 0, 0
  br i1 %t94, label %bb19, label %bb20
bb13:
  %t96 = load i64, ptr %l5, !tbaa !24
  %t97 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t99 = extractvalue { i64, ptr } %t97, 0
  %t102 = icmp slt i64 %t96, %t99
  %t104 = xor i1 %t102, true
  br i1 %t104, label %bb14, label %bb15
bb14:
  br label %bb18
bb15:
  br label %bb16
bb16:
  %t106 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t106, ptr %l43, !tbaa !27
  %t107 = load i64, ptr %l5, !tbaa !24
  %t109 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t110 = load ptr, ptr %t109, !tbaa !27
  %t111 = getelementptr %"std/prelude/map:MapEntry.eb00e4a6e4307a4e46e40fbcd79d6b4f", ptr %t110, i64 %t107
  %t112 = load %"std/prelude/map:MapEntry.eb00e4a6e4307a4e46e40fbcd79d6b4f", ptr %t111
  %t114 = load i64, ptr %l37, !tbaa !24
  %t115 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !27
  %t117 = getelementptr %"std/prelude/map:MapEntry.eb00e4a6e4307a4e46e40fbcd79d6b4f", ptr %t116, i64 %t114
  store %"std/prelude/map:MapEntry.eb00e4a6e4307a4e46e40fbcd79d6b4f" %t112, ptr %t117
  %t118 = load i64, ptr %l37, !tbaa !24
  %t119 = add i64 %t118, 1
  store i64 %t119, ptr %l37, !tbaa !24
  br label %bb17
bb17:
  %t120 = load i64, ptr %l5, !tbaa !24
  %t123 = add i64 %t120, 1
  store i64 %t123, ptr %l5, !tbaa !24
  br label %bb13
bb18:
  br label %bb12
bb19:
  %t125 = load i64, ptr %l56, !tbaa !24
  %t126 = icmp sle i64 0, %t125
  br i1 %t126, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_96fcf0d51cfc1fdf_b5f765173d5e377b)
  unreachable
bb21:
  %t128 = load i64, ptr %l56, !tbaa !24
  %t129 = load i64, ptr %l57, !tbaa !24
  %t130 = icmp sle i64 %t128, %t129
  br i1 %t130, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_96fcf0d51cfc1fdf_b5f765173d5e377b)
  unreachable
bb23:
  %t132 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !27
  %t134 = load i64, ptr %l56, !tbaa !24
  %t135 = getelementptr i64, ptr %t133, i64 0
  %t136 = sub i64 %t134, 0
  %t137 = insertvalue { i64, ptr } undef, i64 %t136, 0
  %t138 = insertvalue { i64, ptr } %t137, ptr %t135, 1
  store { i64, ptr } %t138, ptr %l7, !tbaa !27
  %t140 = load i64, ptr %l1, !tbaa !24
  store i64 %t140, ptr %l63, !tbaa !24
  %t143 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t145 = load i64, ptr %l63, !tbaa !24
  %t146 = extractvalue { i64, ptr } %t143, 0
  %t147 = mul i64 %t146, 8
  %t148 = mul i64 %t145, 8
  %t149 = extractvalue { i64, ptr } %t143, 1
  %t150 = call ptr @__olang_grow_in_place(ptr %t149, i64 %t147, i64 %t148, i64 %t145)
  %t151 = icmp ne ptr %t150, null
  %t152 = select i1 %t151, i64 %t145, i64 0
  %t153 = insertvalue { i64, ptr } undef, i64 %t152, 0
  %t154 = insertvalue { i64, ptr } %t153, ptr %t150, 1
  store { i64, ptr } %t154, ptr %l66, !tbaa !27
  %t155 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t156 = extractvalue { i64, ptr } %t155, 0
  %t158 = icmp ne i64 %t156, 0
  br i1 %t158, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_96fcf0d51cfc1fdf_b5f765173d5e377b)
  unreachable
bb25:
  %t160 = load { i64, ptr }, ptr %l66, !tbaa !27
  store { i64, ptr } %t160, ptr %l64, !tbaa !27
  br label %bb27
bb26:
  %t161 = load i64, ptr %l63, !tbaa !24
  %t162 = mul i64 %t161, 8
  %t163 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t162)
  %t164 = insertvalue { i64, ptr } undef, i64 %t161, 0
  %t165 = insertvalue { i64, ptr } %t164, ptr %t163, 1
  store { i64, ptr } %t165, ptr %l64, !tbaa !27
  store i64 0, ptr %l69, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb28
bb27:
  %t166 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t167 = load ptr, ptr %l53, !tbaa !29
  %t168 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t167, i32 0, i32 1
  store { i64, ptr } %t166, ptr %t168, !tbaa !27
  %t169 = load { i64, ptr }, ptr %l6, !tbaa !27
  br label %ret
bb28:
  %t171 = load i64, ptr %l9, !tbaa !24
  %t172 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t174 = extractvalue { i64, ptr } %t172, 0
  %t177 = icmp slt i64 %t171, %t174
  %t179 = xor i1 %t177, true
  br i1 %t179, label %bb29, label %bb30
bb29:
  br label %bb33
bb30:
  br label %bb31
bb31:
  %t181 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t181, ptr %l75, !tbaa !27
  %t182 = load i64, ptr %l9, !tbaa !24
  %t184 = getelementptr { i64, ptr }, ptr %l75, i32 0, i32 1
  %t185 = load ptr, ptr %t184, !tbaa !27
  %t186 = getelementptr i64, ptr %t185, i64 %t182
  %t187 = load i64, ptr %t186, !tbaa !34
  %t189 = load i64, ptr %l69, !tbaa !24
  %t190 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t191 = load ptr, ptr %t190, !tbaa !27
  %t192 = getelementptr i64, ptr %t191, i64 %t189
  store i64 %t187, ptr %t192, !tbaa !34
  %t193 = load i64, ptr %l69, !tbaa !24
  %t194 = add i64 %t193, 1
  store i64 %t194, ptr %l69, !tbaa !24
  br label %bb32
bb32:
  %t195 = load i64, ptr %l9, !tbaa !24
  %t198 = add i64 %t195, 1
  store i64 %t198, ptr %l9, !tbaa !24
  br label %bb28
bb33:
  br label %bb27
ret:
  ret void
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eroom_3cI64_2c_20I64_3e(ptr %v0, ptr %a0) noinline cold #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l9 = alloca i64
  %l14 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l31 = alloca i64
  %l32 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l37 = alloca i64
  %l43 = alloca { i64, ptr }
  %l53 = alloca ptr
  %l54 = alloca { i64, ptr }
  %l56 = alloca i64
  %l57 = alloca i64
  %l63 = alloca i64
  %l64 = alloca { i64, ptr }
  %l66 = alloca { i64, ptr }
  %l69 = alloca i64
  %l75 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp slt i64 %t6, 4
  br i1 %t8, label %bb1, label %bb2
bb1:
  store i64 8, ptr %l14, !tbaa !24
  br label %bb3
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t17 = mul i64 %t15, 2
  store i64 %t17, ptr %l14, !tbaa !24
  br label %bb3
bb3:
  %t19 = load i64, ptr %l14, !tbaa !24
  store i64 %t19, ptr %l1, !tbaa !24
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t20, i32 0, i32 0
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !27
  store { i64, ptr } %t23, ptr %l2, !tbaa !27
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l21, !tbaa !29
  %t26 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t26, ptr %l22, !tbaa !27
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t27, i32 0, i32 3
  %t30 = load i64, ptr %t29, !tbaa !24
  store i64 %t30, ptr %l24, !tbaa !24
  %t31 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  store i64 %t32, ptr %l25, !tbaa !24
  %t33 = icmp sge i64 0, 0
  br i1 %t33, label %bb4, label %bb5
bb4:
  %t35 = load i64, ptr %l24, !tbaa !24
  %t36 = icmp sle i64 0, %t35
  br i1 %t36, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_6958e5460cd6db86_580233942ca5b42)
  unreachable
bb6:
  %t38 = load i64, ptr %l24, !tbaa !24
  %t39 = load i64, ptr %l25, !tbaa !24
  %t40 = icmp sle i64 %t38, %t39
  br i1 %t40, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_6958e5460cd6db86_580233942ca5b42)
  unreachable
bb8:
  %t42 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = load i64, ptr %l24, !tbaa !24
  %t45 = getelementptr %"std/prelude/map:MapEntry.e476b05c61172463a7c240e364dbb6d0", ptr %t43, i64 0
  %t46 = sub i64 %t44, 0
  %t47 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t45, 1
  store { i64, ptr } %t48, ptr %l3, !tbaa !27
  %t50 = load i64, ptr %l1, !tbaa !24
  store i64 %t50, ptr %l31, !tbaa !24
  %t53 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t55 = load i64, ptr %l31, !tbaa !24
  %t56 = extractvalue { i64, ptr } %t53, 0
  %t57 = mul i64 %t56, 16
  %t58 = mul i64 %t55, 16
  %t59 = extractvalue { i64, ptr } %t53, 1
  %t60 = call ptr @__olang_grow_in_place(ptr %t59, i64 %t57, i64 %t58, i64 %t55)
  %t61 = icmp ne ptr %t60, null
  %t62 = select i1 %t61, i64 %t55, i64 0
  %t63 = insertvalue { i64, ptr } undef, i64 %t62, 0
  %t64 = insertvalue { i64, ptr } %t63, ptr %t60, 1
  store { i64, ptr } %t64, ptr %l34, !tbaa !27
  %t65 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t66 = extractvalue { i64, ptr } %t65, 0
  %t68 = icmp ne i64 %t66, 0
  br i1 %t68, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_6958e5460cd6db86_580233942ca5b42)
  unreachable
bb10:
  %t70 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t70, ptr %l32, !tbaa !27
  br label %bb12
bb11:
  %t71 = load i64, ptr %l31, !tbaa !24
  %t72 = mul i64 %t71, 16
  %t73 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t72)
  %t74 = insertvalue { i64, ptr } undef, i64 %t71, 0
  %t75 = insertvalue { i64, ptr } %t74, ptr %t73, 1
  store { i64, ptr } %t75, ptr %l32, !tbaa !27
  store i64 0, ptr %l37, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb13
bb12:
  %t76 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t77 = load ptr, ptr %l21, !tbaa !29
  %t78 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t77, i32 0, i32 0
  store { i64, ptr } %t76, ptr %t78, !tbaa !27
  %t79 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t81, i32 0, i32 1
  %t84 = load { i64, ptr }, ptr %t83, !tbaa !27
  store { i64, ptr } %t84, ptr %l6, !tbaa !27
  %t86 = load ptr, ptr %l0, !tbaa !29
  store ptr %t86, ptr %l53, !tbaa !29
  %t87 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t87, ptr %l54, !tbaa !27
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t88, i32 0, i32 3
  %t91 = load i64, ptr %t90, !tbaa !24
  store i64 %t91, ptr %l56, !tbaa !24
  %t92 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t93 = extractvalue { i64, ptr } %t92, 0
  store i64 %t93, ptr %l57, !tbaa !24
  %t94 = icmp sge i64 0, 0
  br i1 %t94, label %bb19, label %bb20
bb13:
  %t96 = load i64, ptr %l5, !tbaa !24
  %t97 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t99 = extractvalue { i64, ptr } %t97, 0
  %t102 = icmp slt i64 %t96, %t99
  %t104 = xor i1 %t102, true
  br i1 %t104, label %bb14, label %bb15
bb14:
  br label %bb18
bb15:
  br label %bb16
bb16:
  %t106 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t106, ptr %l43, !tbaa !27
  %t107 = load i64, ptr %l5, !tbaa !24
  %t109 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t110 = load ptr, ptr %t109, !tbaa !27
  %t111 = getelementptr %"std/prelude/map:MapEntry.e476b05c61172463a7c240e364dbb6d0", ptr %t110, i64 %t107
  %t112 = load %"std/prelude/map:MapEntry.e476b05c61172463a7c240e364dbb6d0", ptr %t111
  %t114 = load i64, ptr %l37, !tbaa !24
  %t115 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !27
  %t117 = getelementptr %"std/prelude/map:MapEntry.e476b05c61172463a7c240e364dbb6d0", ptr %t116, i64 %t114
  store %"std/prelude/map:MapEntry.e476b05c61172463a7c240e364dbb6d0" %t112, ptr %t117
  %t118 = load i64, ptr %l37, !tbaa !24
  %t119 = add i64 %t118, 1
  store i64 %t119, ptr %l37, !tbaa !24
  br label %bb17
bb17:
  %t120 = load i64, ptr %l5, !tbaa !24
  %t123 = add i64 %t120, 1
  store i64 %t123, ptr %l5, !tbaa !24
  br label %bb13
bb18:
  br label %bb12
bb19:
  %t125 = load i64, ptr %l56, !tbaa !24
  %t126 = icmp sle i64 0, %t125
  br i1 %t126, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_69b05c16d7fe8663_9b68229f54eb9d3f)
  unreachable
bb21:
  %t128 = load i64, ptr %l56, !tbaa !24
  %t129 = load i64, ptr %l57, !tbaa !24
  %t130 = icmp sle i64 %t128, %t129
  br i1 %t130, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_69b05c16d7fe8663_9b68229f54eb9d3f)
  unreachable
bb23:
  %t132 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !27
  %t134 = load i64, ptr %l56, !tbaa !24
  %t135 = getelementptr i64, ptr %t133, i64 0
  %t136 = sub i64 %t134, 0
  %t137 = insertvalue { i64, ptr } undef, i64 %t136, 0
  %t138 = insertvalue { i64, ptr } %t137, ptr %t135, 1
  store { i64, ptr } %t138, ptr %l7, !tbaa !27
  %t140 = load i64, ptr %l1, !tbaa !24
  store i64 %t140, ptr %l63, !tbaa !24
  %t143 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t145 = load i64, ptr %l63, !tbaa !24
  %t146 = extractvalue { i64, ptr } %t143, 0
  %t147 = mul i64 %t146, 8
  %t148 = mul i64 %t145, 8
  %t149 = extractvalue { i64, ptr } %t143, 1
  %t150 = call ptr @__olang_grow_in_place(ptr %t149, i64 %t147, i64 %t148, i64 %t145)
  %t151 = icmp ne ptr %t150, null
  %t152 = select i1 %t151, i64 %t145, i64 0
  %t153 = insertvalue { i64, ptr } undef, i64 %t152, 0
  %t154 = insertvalue { i64, ptr } %t153, ptr %t150, 1
  store { i64, ptr } %t154, ptr %l66, !tbaa !27
  %t155 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t156 = extractvalue { i64, ptr } %t155, 0
  %t158 = icmp ne i64 %t156, 0
  br i1 %t158, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_69b05c16d7fe8663_9b68229f54eb9d3f)
  unreachable
bb25:
  %t160 = load { i64, ptr }, ptr %l66, !tbaa !27
  store { i64, ptr } %t160, ptr %l64, !tbaa !27
  br label %bb27
bb26:
  %t161 = load i64, ptr %l63, !tbaa !24
  %t162 = mul i64 %t161, 8
  %t163 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t162)
  %t164 = insertvalue { i64, ptr } undef, i64 %t161, 0
  %t165 = insertvalue { i64, ptr } %t164, ptr %t163, 1
  store { i64, ptr } %t165, ptr %l64, !tbaa !27
  store i64 0, ptr %l69, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb28
bb27:
  %t166 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t167 = load ptr, ptr %l53, !tbaa !29
  %t168 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t167, i32 0, i32 1
  store { i64, ptr } %t166, ptr %t168, !tbaa !27
  %t169 = load { i64, ptr }, ptr %l6, !tbaa !27
  br label %ret
bb28:
  %t171 = load i64, ptr %l9, !tbaa !24
  %t172 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t174 = extractvalue { i64, ptr } %t172, 0
  %t177 = icmp slt i64 %t171, %t174
  %t179 = xor i1 %t177, true
  br i1 %t179, label %bb29, label %bb30
bb29:
  br label %bb33
bb30:
  br label %bb31
bb31:
  %t181 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t181, ptr %l75, !tbaa !27
  %t182 = load i64, ptr %l9, !tbaa !24
  %t184 = getelementptr { i64, ptr }, ptr %l75, i32 0, i32 1
  %t185 = load ptr, ptr %t184, !tbaa !27
  %t186 = getelementptr i64, ptr %t185, i64 %t182
  %t187 = load i64, ptr %t186, !tbaa !34
  %t189 = load i64, ptr %l69, !tbaa !24
  %t190 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t191 = load ptr, ptr %t190, !tbaa !27
  %t192 = getelementptr i64, ptr %t191, i64 %t189
  store i64 %t187, ptr %t192, !tbaa !34
  %t193 = load i64, ptr %l69, !tbaa !24
  %t194 = add i64 %t193, 1
  store i64 %t194, ptr %l69, !tbaa !24
  br label %bb32
bb32:
  %t195 = load i64, ptr %l9, !tbaa !24
  %t198 = add i64 %t195, 1
  store i64 %t198, ptr %l9, !tbaa !24
  br label %bb28
bb33:
  br label %bb27
ret:
  ret void
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fscope_3aTerm_3e_2e_H8cb0ac70da098e34c2a0710652a6b80c(ptr %v0, ptr %a0) noinline cold #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l5 = alloca i64
  %l7 = alloca { i64, ptr }
  %l9 = alloca i64
  %l14 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l31 = alloca i64
  %l32 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l37 = alloca i64
  %l43 = alloca { i64, ptr }
  %l53 = alloca ptr
  %l54 = alloca { i64, ptr }
  %l56 = alloca i64
  %l57 = alloca i64
  %l63 = alloca i64
  %l64 = alloca i64
  %l65 = alloca { i64, ptr }
  %l67 = alloca { i64, ptr }
  %l70 = alloca i64
  %l76 = alloca { i64, ptr }
  %l84 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp slt i64 %t6, 4
  br i1 %t8, label %bb1, label %bb2
bb1:
  store i64 8, ptr %l14, !tbaa !24
  br label %bb3
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t17 = mul i64 %t15, 2
  store i64 %t17, ptr %l14, !tbaa !24
  br label %bb3
bb3:
  %t19 = load i64, ptr %l14, !tbaa !24
  store i64 %t19, ptr %l1, !tbaa !24
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t20, i32 0, i32 0
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !27
  store { i64, ptr } %t23, ptr %l2, !tbaa !27
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l21, !tbaa !29
  %t26 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t26, ptr %l22, !tbaa !27
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t27, i32 0, i32 3
  %t30 = load i64, ptr %t29, !tbaa !24
  store i64 %t30, ptr %l24, !tbaa !24
  %t31 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  store i64 %t32, ptr %l25, !tbaa !24
  %t33 = icmp sge i64 0, 0
  br i1 %t33, label %bb4, label %bb5
bb4:
  %t35 = load i64, ptr %l24, !tbaa !24
  %t36 = icmp sle i64 0, %t35
  br i1 %t36, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_942546e0f7a32db8_2fedafd50c7367bc)
  unreachable
bb6:
  %t38 = load i64, ptr %l24, !tbaa !24
  %t39 = load i64, ptr %l25, !tbaa !24
  %t40 = icmp sle i64 %t38, %t39
  br i1 %t40, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_942546e0f7a32db8_2fedafd50c7367bc)
  unreachable
bb8:
  %t42 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = load i64, ptr %l24, !tbaa !24
  %t45 = getelementptr %"std/prelude/map:MapEntry.e9f7fa267a7f2d248d882fb408477a69", ptr %t43, i64 0
  %t46 = sub i64 %t44, 0
  %t47 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t45, 1
  store { i64, ptr } %t48, ptr %l3, !tbaa !27
  %t50 = load i64, ptr %l1, !tbaa !24
  store i64 %t50, ptr %l31, !tbaa !24
  %t53 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t55 = load i64, ptr %l31, !tbaa !24
  %t56 = extractvalue { i64, ptr } %t53, 0
  %t57 = mul i64 %t56, 32
  %t58 = mul i64 %t55, 32
  %t59 = extractvalue { i64, ptr } %t53, 1
  %t60 = call ptr @__olang_grow_in_place(ptr %t59, i64 %t57, i64 %t58, i64 %t55)
  %t61 = icmp ne ptr %t60, null
  %t62 = select i1 %t61, i64 %t55, i64 0
  %t63 = insertvalue { i64, ptr } undef, i64 %t62, 0
  %t64 = insertvalue { i64, ptr } %t63, ptr %t60, 1
  store { i64, ptr } %t64, ptr %l34, !tbaa !27
  %t65 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t66 = extractvalue { i64, ptr } %t65, 0
  %t68 = icmp ne i64 %t66, 0
  br i1 %t68, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_942546e0f7a32db8_2fedafd50c7367bc)
  unreachable
bb10:
  %t70 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t70, ptr %l32, !tbaa !27
  br label %bb12
bb11:
  %t71 = load i64, ptr %l31, !tbaa !24
  %t72 = mul i64 %t71, 32
  %t73 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t72)
  %t74 = insertvalue { i64, ptr } undef, i64 %t71, 0
  %t75 = insertvalue { i64, ptr } %t74, ptr %t73, 1
  store { i64, ptr } %t75, ptr %l32, !tbaa !27
  store i64 0, ptr %l37, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb13
bb12:
  %t76 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t77 = load ptr, ptr %l21, !tbaa !29
  %t78 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t77, i32 0, i32 0
  store { i64, ptr } %t76, ptr %t78, !tbaa !27
  %t79 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t81, i32 0, i32 1
  %t84 = load { i64, ptr }, ptr %t83, !tbaa !27
  %t86 = load ptr, ptr %l0, !tbaa !29
  store ptr %t86, ptr %l53, !tbaa !29
  store { i64, ptr } %t84, ptr %l54, !tbaa !27
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t88, i32 0, i32 3
  %t91 = load i64, ptr %t90, !tbaa !24
  store i64 %t91, ptr %l56, !tbaa !24
  %t92 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t93 = extractvalue { i64, ptr } %t92, 0
  store i64 %t93, ptr %l57, !tbaa !24
  %t94 = icmp sge i64 0, 0
  br i1 %t94, label %bb19, label %bb20
bb13:
  %t96 = load i64, ptr %l5, !tbaa !24
  %t97 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t99 = extractvalue { i64, ptr } %t97, 0
  %t102 = icmp slt i64 %t96, %t99
  %t104 = xor i1 %t102, true
  br i1 %t104, label %bb14, label %bb15
bb14:
  br label %bb18
bb15:
  br label %bb16
bb16:
  %t106 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t106, ptr %l43, !tbaa !27
  %t107 = load i64, ptr %l5, !tbaa !24
  %t109 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t110 = load ptr, ptr %t109, !tbaa !27
  %t111 = getelementptr %"std/prelude/map:MapEntry.e9f7fa267a7f2d248d882fb408477a69", ptr %t110, i64 %t107
  %t112 = load %"std/prelude/map:MapEntry.e9f7fa267a7f2d248d882fb408477a69", ptr %t111
  %t114 = load i64, ptr %l37, !tbaa !24
  %t115 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !27
  %t117 = getelementptr %"std/prelude/map:MapEntry.e9f7fa267a7f2d248d882fb408477a69", ptr %t116, i64 %t114
  store %"std/prelude/map:MapEntry.e9f7fa267a7f2d248d882fb408477a69" %t112, ptr %t117
  %t118 = load i64, ptr %l37, !tbaa !24
  %t119 = add i64 %t118, 1
  store i64 %t119, ptr %l37, !tbaa !24
  br label %bb17
bb17:
  %t120 = load i64, ptr %l5, !tbaa !24
  %t123 = add i64 %t120, 1
  store i64 %t123, ptr %l5, !tbaa !24
  br label %bb13
bb18:
  br label %bb12
bb19:
  %t125 = load i64, ptr %l56, !tbaa !24
  %t126 = icmp sle i64 0, %t125
  br i1 %t126, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_6c0209f6cdc38395_974bf4e768403fa9)
  unreachable
bb21:
  %t128 = load i64, ptr %l56, !tbaa !24
  %t129 = load i64, ptr %l57, !tbaa !24
  %t130 = icmp sle i64 %t128, %t129
  br i1 %t130, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_6c0209f6cdc38395_974bf4e768403fa9)
  unreachable
bb23:
  %t132 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !27
  %t134 = load i64, ptr %l56, !tbaa !24
  %t135 = getelementptr i64, ptr %t133, i64 0
  %t136 = sub i64 %t134, 0
  %t137 = insertvalue { i64, ptr } undef, i64 %t136, 0
  %t138 = insertvalue { i64, ptr } %t137, ptr %t135, 1
  store { i64, ptr } %t138, ptr %l7, !tbaa !27
  %t140 = load i64, ptr %l1, !tbaa !24
  %t142 = call ptr @__olang_region_make_part(ptr %v0)
  %t143 = ptrtoint ptr %t142 to i64
  store i64 %t143, ptr %l63, !tbaa !24
  store i64 %t140, ptr %l64, !tbaa !24
  %t145 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t147 = load i64, ptr %l64, !tbaa !24
  %t148 = extractvalue { i64, ptr } %t145, 0
  %t149 = mul i64 %t148, 8
  %t150 = mul i64 %t147, 8
  %t151 = extractvalue { i64, ptr } %t145, 1
  %t152 = call ptr @__olang_grow_in_place(ptr %t151, i64 %t149, i64 %t150, i64 %t147)
  %t153 = icmp ne ptr %t152, null
  %t154 = select i1 %t153, i64 %t147, i64 0
  %t155 = insertvalue { i64, ptr } undef, i64 %t154, 0
  %t156 = insertvalue { i64, ptr } %t155, ptr %t152, 1
  store { i64, ptr } %t156, ptr %l67, !tbaa !27
  %t157 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t158 = extractvalue { i64, ptr } %t157, 0
  %t160 = icmp ne i64 %t158, 0
  br i1 %t160, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_6c0209f6cdc38395_974bf4e768403fa9)
  unreachable
bb25:
  %t162 = load { i64, ptr }, ptr %l67, !tbaa !27
  store { i64, ptr } %t162, ptr %l65, !tbaa !27
  br label %bb27
bb26:
  %t163 = load i64, ptr %l64, !tbaa !24
  %t164 = mul i64 %t163, 8
  %t165 = load i64, ptr %l63
  %t166 = inttoptr i64 %t165 to ptr
  %t167 = call ptr @__olang_held_alloc(ptr %t166, i64 %t164)
  %t168 = insertvalue { i64, ptr } undef, i64 %t163, 0
  %t169 = insertvalue { i64, ptr } %t168, ptr %t167, 1
  store { i64, ptr } %t169, ptr %l65, !tbaa !27
  store i64 0, ptr %l70, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb28
bb27:
  %t170 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t171 = extractvalue { i64, ptr } %t170, 0
  %t173 = icmp eq i64 %t171, 0
  br i1 %t173, label %bb34, label %bb35
bb28:
  %t175 = load i64, ptr %l9, !tbaa !24
  %t176 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t178 = extractvalue { i64, ptr } %t176, 0
  %t181 = icmp slt i64 %t175, %t178
  %t183 = xor i1 %t181, true
  br i1 %t183, label %bb29, label %bb30
bb29:
  br label %bb33
bb30:
  br label %bb31
bb31:
  %t185 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t185, ptr %l76, !tbaa !27
  %t186 = load i64, ptr %l9, !tbaa !24
  %t188 = getelementptr { i64, ptr }, ptr %l76, i32 0, i32 1
  %t189 = load ptr, ptr %t188, !tbaa !27
  %t190 = getelementptr i64, ptr %t189, i64 %t186
  %t191 = load i64, ptr %t190, !tbaa !34
  %t193 = load i64, ptr %l70, !tbaa !24
  %t194 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t195 = load ptr, ptr %t194, !tbaa !27
  %t196 = getelementptr i64, ptr %t195, i64 %t193
  store i64 %t191, ptr %t196, !tbaa !34
  %t197 = load i64, ptr %l70, !tbaa !24
  %t198 = add i64 %t197, 1
  store i64 %t198, ptr %l70, !tbaa !24
  br label %bb32
bb32:
  %t199 = load i64, ptr %l9, !tbaa !24
  %t202 = add i64 %t199, 1
  store i64 %t202, ptr %l9, !tbaa !24
  br label %bb28
bb33:
  br label %bb27
bb34:
  store { i64, ptr } zeroinitializer, ptr %l65, !tbaa !27
  br label %bb35
bb35:
  %t204 = load i64, ptr %l63
  %t205 = inttoptr i64 %t204 to ptr
  %t206 = load { i64, ptr }, ptr %l65
  %t207 = extractvalue { i64, ptr } %t206, 1
  %t208 = call ptr @__olang_region_or(ptr %t207, ptr null)
  %t209 = icmp ne ptr %t208, null
  %t210 = select i1 %t209, ptr %t208, ptr null
  call void @__olang_region_settle_in(ptr %t205, ptr %t210)
  %t211 = load ptr, ptr %l53, !tbaa !29
  %t212 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t211, i32 0, i32 1
  %t213 = load { i64, ptr }, ptr %t212, !tbaa !27
  store { i64, ptr } %t213, ptr %l84, !tbaa !27
  %t214 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t215 = load ptr, ptr %l53, !tbaa !29
  %t216 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t215, i32 0, i32 1
  store { i64, ptr } %t214, ptr %t216, !tbaa !27
  %t217 = load { i64, ptr }, ptr %l84
  %t218 = extractvalue { i64, ptr } %t217, 0
  %t219 = extractvalue { i64, ptr } %t217, 1
  call void @__olang_region_release_part(ptr %t219, i64 %t218)
  store { i64, ptr } zeroinitializer, ptr %l84
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fscope_3afnRecs_3e__He80baf1b588f50b63954cc685275029f(ptr %v0, ptr %a0) noinline cold #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l9 = alloca i64
  %l14 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l32 = alloca { i64, ptr }
  %l33 = alloca i64
  %l39 = alloca { i64, ptr }
  %l49 = alloca ptr
  %l50 = alloca { i64, ptr }
  %l52 = alloca i64
  %l53 = alloca i64
  %l59 = alloca i64
  %l60 = alloca { i64, ptr }
  %l62 = alloca { i64, ptr }
  %l65 = alloca i64
  %l71 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp slt i64 %t6, 4
  br i1 %t8, label %bb1, label %bb2
bb1:
  store i64 8, ptr %l14, !tbaa !24
  br label %bb3
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t17 = mul i64 %t15, 2
  store i64 %t17, ptr %l14, !tbaa !24
  br label %bb3
bb3:
  %t19 = load i64, ptr %l14, !tbaa !24
  store i64 %t19, ptr %l1, !tbaa !24
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t20, i32 0, i32 0
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !27
  store { i64, ptr } %t23, ptr %l2, !tbaa !27
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l21, !tbaa !29
  %t26 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t26, ptr %l22, !tbaa !27
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t27, i32 0, i32 3
  %t30 = load i64, ptr %t29, !tbaa !24
  store i64 %t30, ptr %l24, !tbaa !24
  %t31 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  store i64 %t32, ptr %l25, !tbaa !24
  %t33 = icmp sge i64 0, 0
  br i1 %t33, label %bb4, label %bb5
bb4:
  %t35 = load i64, ptr %l24, !tbaa !24
  %t36 = icmp sle i64 0, %t35
  br i1 %t36, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_7f58bbce9e95ad79_e8f56ec1072e1d1d)
  unreachable
bb6:
  %t38 = load i64, ptr %l24, !tbaa !24
  %t39 = load i64, ptr %l25, !tbaa !24
  %t40 = icmp sle i64 %t38, %t39
  br i1 %t40, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_7f58bbce9e95ad79_e8f56ec1072e1d1d)
  unreachable
bb8:
  %t42 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = load i64, ptr %l24, !tbaa !24
  %t45 = getelementptr %"std/prelude/map:MapEntry.8067410eb7799f1c31299714f5ba653d", ptr %t43, i64 0
  %t46 = sub i64 %t44, 0
  %t47 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t45, 1
  store { i64, ptr } %t48, ptr %l3, !tbaa !27
  %t50 = load i64, ptr %l1, !tbaa !24
  %t54 = mul i64 %t50, 112
  %t55 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t54)
  %t56 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t55, 1
  store { i64, ptr } %t57, ptr %l32, !tbaa !27
  store i64 0, ptr %l33, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_7f58bbce9e95ad79_e8f56ec1072e1d1d)
  unreachable
bb10:
  %t58 = load i64, ptr %l5, !tbaa !24
  %t59 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t61 = extractvalue { i64, ptr } %t59, 0
  %t64 = icmp slt i64 %t58, %t61
  %t66 = xor i1 %t64, true
  br i1 %t66, label %bb11, label %bb12
bb11:
  br label %bb15
bb12:
  br label %bb13
bb13:
  %t68 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t68, ptr %l39, !tbaa !27
  %t69 = load i64, ptr %l5, !tbaa !24
  %t71 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !27
  %t73 = getelementptr %"std/prelude/map:MapEntry.8067410eb7799f1c31299714f5ba653d", ptr %t72, i64 %t69
  %t74 = load %"std/prelude/map:MapEntry.8067410eb7799f1c31299714f5ba653d", ptr %t73
  store %"std/prelude/map:MapEntry.8067410eb7799f1c31299714f5ba653d" zeroinitializer, ptr %t73
  %t76 = load i64, ptr %l33, !tbaa !24
  %t77 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = getelementptr %"std/prelude/map:MapEntry.8067410eb7799f1c31299714f5ba653d", ptr %t78, i64 %t76
  store %"std/prelude/map:MapEntry.8067410eb7799f1c31299714f5ba653d" %t74, ptr %t79
  %t80 = load i64, ptr %l33, !tbaa !24
  %t81 = add i64 %t80, 1
  store i64 %t81, ptr %l33, !tbaa !24
  br label %bb14
bb14:
  %t82 = load i64, ptr %l5, !tbaa !24
  %t85 = add i64 %t82, 1
  store i64 %t85, ptr %l5, !tbaa !24
  br label %bb10
bb15:
  %t87 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t88 = load ptr, ptr %l21, !tbaa !29
  %t89 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t88, i32 0, i32 0
  store { i64, ptr } %t87, ptr %t89, !tbaa !27
  %t90 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t92, i32 0, i32 1
  %t95 = load { i64, ptr }, ptr %t94, !tbaa !27
  store { i64, ptr } %t95, ptr %l6, !tbaa !27
  %t97 = load ptr, ptr %l0, !tbaa !29
  store ptr %t97, ptr %l49, !tbaa !29
  %t98 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t98, ptr %l50, !tbaa !27
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t99, i32 0, i32 3
  %t102 = load i64, ptr %t101, !tbaa !24
  store i64 %t102, ptr %l52, !tbaa !24
  %t103 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t104 = extractvalue { i64, ptr } %t103, 0
  store i64 %t104, ptr %l53, !tbaa !24
  %t105 = icmp sge i64 0, 0
  br i1 %t105, label %bb16, label %bb17
bb16:
  %t107 = load i64, ptr %l52, !tbaa !24
  %t108 = icmp sle i64 0, %t107
  br i1 %t108, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_d289edfcd51d194c_58000e496e1c51c0)
  unreachable
bb18:
  %t110 = load i64, ptr %l52, !tbaa !24
  %t111 = load i64, ptr %l53, !tbaa !24
  %t112 = icmp sle i64 %t110, %t111
  br i1 %t112, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_d289edfcd51d194c_58000e496e1c51c0)
  unreachable
bb20:
  %t114 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !27
  %t116 = load i64, ptr %l52, !tbaa !24
  %t117 = getelementptr i64, ptr %t115, i64 0
  %t118 = sub i64 %t116, 0
  %t119 = insertvalue { i64, ptr } undef, i64 %t118, 0
  %t120 = insertvalue { i64, ptr } %t119, ptr %t117, 1
  store { i64, ptr } %t120, ptr %l7, !tbaa !27
  %t122 = load i64, ptr %l1, !tbaa !24
  store i64 %t122, ptr %l59, !tbaa !24
  %t125 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t127 = load i64, ptr %l59, !tbaa !24
  %t128 = extractvalue { i64, ptr } %t125, 0
  %t129 = mul i64 %t128, 8
  %t130 = mul i64 %t127, 8
  %t131 = extractvalue { i64, ptr } %t125, 1
  %t132 = call ptr @__olang_grow_in_place(ptr %t131, i64 %t129, i64 %t130, i64 %t127)
  %t133 = icmp ne ptr %t132, null
  %t134 = select i1 %t133, i64 %t127, i64 0
  %t135 = insertvalue { i64, ptr } undef, i64 %t134, 0
  %t136 = insertvalue { i64, ptr } %t135, ptr %t132, 1
  store { i64, ptr } %t136, ptr %l62, !tbaa !27
  %t137 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t138 = extractvalue { i64, ptr } %t137, 0
  %t140 = icmp ne i64 %t138, 0
  br i1 %t140, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_d289edfcd51d194c_58000e496e1c51c0)
  unreachable
bb22:
  %t142 = load { i64, ptr }, ptr %l62, !tbaa !27
  store { i64, ptr } %t142, ptr %l60, !tbaa !27
  br label %bb24
bb23:
  %t143 = load i64, ptr %l59, !tbaa !24
  %t144 = mul i64 %t143, 8
  %t145 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t144)
  %t146 = insertvalue { i64, ptr } undef, i64 %t143, 0
  %t147 = insertvalue { i64, ptr } %t146, ptr %t145, 1
  store { i64, ptr } %t147, ptr %l60, !tbaa !27
  store i64 0, ptr %l65, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb25
bb24:
  %t148 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t149 = load ptr, ptr %l49, !tbaa !29
  %t150 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t149, i32 0, i32 1
  store { i64, ptr } %t148, ptr %t150, !tbaa !27
  %t151 = load { i64, ptr }, ptr %l6, !tbaa !27
  br label %ret
bb25:
  %t153 = load i64, ptr %l9, !tbaa !24
  %t154 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t156 = extractvalue { i64, ptr } %t154, 0
  %t159 = icmp slt i64 %t153, %t156
  %t161 = xor i1 %t159, true
  br i1 %t161, label %bb26, label %bb27
bb26:
  br label %bb30
bb27:
  br label %bb28
bb28:
  %t163 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t163, ptr %l71, !tbaa !27
  %t164 = load i64, ptr %l9, !tbaa !24
  %t166 = getelementptr { i64, ptr }, ptr %l71, i32 0, i32 1
  %t167 = load ptr, ptr %t166, !tbaa !27
  %t168 = getelementptr i64, ptr %t167, i64 %t164
  %t169 = load i64, ptr %t168, !tbaa !34
  %t171 = load i64, ptr %l65, !tbaa !24
  %t172 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t173 = load ptr, ptr %t172, !tbaa !27
  %t174 = getelementptr i64, ptr %t173, i64 %t171
  store i64 %t169, ptr %t174, !tbaa !34
  %t175 = load i64, ptr %l65, !tbaa !24
  %t176 = add i64 %t175, 1
  store i64 %t176, ptr %l65, !tbaa !24
  br label %bb29
bb29:
  %t177 = load i64, ptr %l9, !tbaa !24
  %t180 = add i64 %t177, 1
  store i64 %t180, ptr %l9, !tbaa !24
  br label %bb25
bb30:
  br label %bb24
ret:
  ret void
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fscope_3afsBody_3e__H7085d95bd77331fe367bbd2fd7039738(ptr %v0, ptr %a0) noinline cold #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l5 = alloca i64
  %l7 = alloca { i64, ptr }
  %l9 = alloca i64
  %l14 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l32 = alloca { i64, ptr }
  %l33 = alloca i64
  %l39 = alloca { i64, ptr }
  %l49 = alloca ptr
  %l50 = alloca { i64, ptr }
  %l52 = alloca i64
  %l53 = alloca i64
  %l59 = alloca i64
  %l60 = alloca i64
  %l61 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %l66 = alloca i64
  %l72 = alloca { i64, ptr }
  %l80 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp slt i64 %t6, 4
  br i1 %t8, label %bb1, label %bb2
bb1:
  store i64 8, ptr %l14, !tbaa !24
  br label %bb3
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t17 = mul i64 %t15, 2
  store i64 %t17, ptr %l14, !tbaa !24
  br label %bb3
bb3:
  %t19 = load i64, ptr %l14, !tbaa !24
  store i64 %t19, ptr %l1, !tbaa !24
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t20, i32 0, i32 0
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !27
  store { i64, ptr } %t23, ptr %l2, !tbaa !27
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l21, !tbaa !29
  %t26 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t26, ptr %l22, !tbaa !27
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t27, i32 0, i32 3
  %t30 = load i64, ptr %t29, !tbaa !24
  store i64 %t30, ptr %l24, !tbaa !24
  %t31 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  store i64 %t32, ptr %l25, !tbaa !24
  %t33 = icmp sge i64 0, 0
  br i1 %t33, label %bb4, label %bb5
bb4:
  %t35 = load i64, ptr %l24, !tbaa !24
  %t36 = icmp sle i64 0, %t35
  br i1 %t36, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_8e1720a227959e1e_499b96ad7001723a)
  unreachable
bb6:
  %t38 = load i64, ptr %l24, !tbaa !24
  %t39 = load i64, ptr %l25, !tbaa !24
  %t40 = icmp sle i64 %t38, %t39
  br i1 %t40, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_8e1720a227959e1e_499b96ad7001723a)
  unreachable
bb8:
  %t42 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = load i64, ptr %l24, !tbaa !24
  %t45 = getelementptr %"std/prelude/map:MapEntry.46ee6b3e862913b4249ebf99c032c615", ptr %t43, i64 0
  %t46 = sub i64 %t44, 0
  %t47 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t45, 1
  store { i64, ptr } %t48, ptr %l3, !tbaa !27
  %t50 = load i64, ptr %l1, !tbaa !24
  %t54 = mul i64 %t50, 72
  %t55 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t54)
  %t56 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t55, 1
  store { i64, ptr } %t57, ptr %l32, !tbaa !27
  store i64 0, ptr %l33, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_8e1720a227959e1e_499b96ad7001723a)
  unreachable
bb10:
  %t58 = load i64, ptr %l5, !tbaa !24
  %t59 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t61 = extractvalue { i64, ptr } %t59, 0
  %t64 = icmp slt i64 %t58, %t61
  %t66 = xor i1 %t64, true
  br i1 %t66, label %bb11, label %bb12
bb11:
  br label %bb15
bb12:
  br label %bb13
bb13:
  %t68 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t68, ptr %l39, !tbaa !27
  %t69 = load i64, ptr %l5, !tbaa !24
  %t71 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !27
  %t73 = getelementptr %"std/prelude/map:MapEntry.46ee6b3e862913b4249ebf99c032c615", ptr %t72, i64 %t69
  %t74 = load %"std/prelude/map:MapEntry.46ee6b3e862913b4249ebf99c032c615", ptr %t73
  store %"std/prelude/map:MapEntry.46ee6b3e862913b4249ebf99c032c615" zeroinitializer, ptr %t73
  %t76 = load i64, ptr %l33, !tbaa !24
  %t77 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = getelementptr %"std/prelude/map:MapEntry.46ee6b3e862913b4249ebf99c032c615", ptr %t78, i64 %t76
  store %"std/prelude/map:MapEntry.46ee6b3e862913b4249ebf99c032c615" %t74, ptr %t79
  %t80 = load i64, ptr %l33, !tbaa !24
  %t81 = add i64 %t80, 1
  store i64 %t81, ptr %l33, !tbaa !24
  br label %bb14
bb14:
  %t82 = load i64, ptr %l5, !tbaa !24
  %t85 = add i64 %t82, 1
  store i64 %t85, ptr %l5, !tbaa !24
  br label %bb10
bb15:
  %t87 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t88 = load ptr, ptr %l21, !tbaa !29
  %t89 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t88, i32 0, i32 0
  store { i64, ptr } %t87, ptr %t89, !tbaa !27
  %t90 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t92, i32 0, i32 1
  %t95 = load { i64, ptr }, ptr %t94, !tbaa !27
  %t97 = load ptr, ptr %l0, !tbaa !29
  store ptr %t97, ptr %l49, !tbaa !29
  store { i64, ptr } %t95, ptr %l50, !tbaa !27
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t99, i32 0, i32 3
  %t102 = load i64, ptr %t101, !tbaa !24
  store i64 %t102, ptr %l52, !tbaa !24
  %t103 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t104 = extractvalue { i64, ptr } %t103, 0
  store i64 %t104, ptr %l53, !tbaa !24
  %t105 = icmp sge i64 0, 0
  br i1 %t105, label %bb16, label %bb17
bb16:
  %t107 = load i64, ptr %l52, !tbaa !24
  %t108 = icmp sle i64 0, %t107
  br i1 %t108, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_7640e0166a5bae1b_7c6c5bf7bf0c1517)
  unreachable
bb18:
  %t110 = load i64, ptr %l52, !tbaa !24
  %t111 = load i64, ptr %l53, !tbaa !24
  %t112 = icmp sle i64 %t110, %t111
  br i1 %t112, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_7640e0166a5bae1b_7c6c5bf7bf0c1517)
  unreachable
bb20:
  %t114 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !27
  %t116 = load i64, ptr %l52, !tbaa !24
  %t117 = getelementptr i64, ptr %t115, i64 0
  %t118 = sub i64 %t116, 0
  %t119 = insertvalue { i64, ptr } undef, i64 %t118, 0
  %t120 = insertvalue { i64, ptr } %t119, ptr %t117, 1
  store { i64, ptr } %t120, ptr %l7, !tbaa !27
  %t122 = load i64, ptr %l1, !tbaa !24
  %t124 = call ptr @__olang_region_make_part(ptr %v0)
  %t125 = ptrtoint ptr %t124 to i64
  store i64 %t125, ptr %l59, !tbaa !24
  store i64 %t122, ptr %l60, !tbaa !24
  %t127 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t129 = load i64, ptr %l60, !tbaa !24
  %t130 = extractvalue { i64, ptr } %t127, 0
  %t131 = mul i64 %t130, 8
  %t132 = mul i64 %t129, 8
  %t133 = extractvalue { i64, ptr } %t127, 1
  %t134 = call ptr @__olang_grow_in_place(ptr %t133, i64 %t131, i64 %t132, i64 %t129)
  %t135 = icmp ne ptr %t134, null
  %t136 = select i1 %t135, i64 %t129, i64 0
  %t137 = insertvalue { i64, ptr } undef, i64 %t136, 0
  %t138 = insertvalue { i64, ptr } %t137, ptr %t134, 1
  store { i64, ptr } %t138, ptr %l63, !tbaa !27
  %t139 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t140 = extractvalue { i64, ptr } %t139, 0
  %t142 = icmp ne i64 %t140, 0
  br i1 %t142, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_7640e0166a5bae1b_7c6c5bf7bf0c1517)
  unreachable
bb22:
  %t144 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t144, ptr %l61, !tbaa !27
  br label %bb24
bb23:
  %t145 = load i64, ptr %l60, !tbaa !24
  %t146 = mul i64 %t145, 8
  %t147 = load i64, ptr %l59
  %t148 = inttoptr i64 %t147 to ptr
  %t149 = call ptr @__olang_held_alloc(ptr %t148, i64 %t146)
  %t150 = insertvalue { i64, ptr } undef, i64 %t145, 0
  %t151 = insertvalue { i64, ptr } %t150, ptr %t149, 1
  store { i64, ptr } %t151, ptr %l61, !tbaa !27
  store i64 0, ptr %l66, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb25
bb24:
  %t152 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t153 = extractvalue { i64, ptr } %t152, 0
  %t155 = icmp eq i64 %t153, 0
  br i1 %t155, label %bb31, label %bb32
bb25:
  %t157 = load i64, ptr %l9, !tbaa !24
  %t158 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t160 = extractvalue { i64, ptr } %t158, 0
  %t163 = icmp slt i64 %t157, %t160
  %t165 = xor i1 %t163, true
  br i1 %t165, label %bb26, label %bb27
bb26:
  br label %bb30
bb27:
  br label %bb28
bb28:
  %t167 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t167, ptr %l72, !tbaa !27
  %t168 = load i64, ptr %l9, !tbaa !24
  %t170 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t171 = load ptr, ptr %t170, !tbaa !27
  %t172 = getelementptr i64, ptr %t171, i64 %t168
  %t173 = load i64, ptr %t172, !tbaa !34
  %t175 = load i64, ptr %l66, !tbaa !24
  %t176 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t177 = load ptr, ptr %t176, !tbaa !27
  %t178 = getelementptr i64, ptr %t177, i64 %t175
  store i64 %t173, ptr %t178, !tbaa !34
  %t179 = load i64, ptr %l66, !tbaa !24
  %t180 = add i64 %t179, 1
  store i64 %t180, ptr %l66, !tbaa !24
  br label %bb29
bb29:
  %t181 = load i64, ptr %l9, !tbaa !24
  %t184 = add i64 %t181, 1
  store i64 %t184, ptr %l9, !tbaa !24
  br label %bb25
bb30:
  br label %bb24
bb31:
  store { i64, ptr } zeroinitializer, ptr %l61, !tbaa !27
  br label %bb32
bb32:
  %t186 = load i64, ptr %l59
  %t187 = inttoptr i64 %t186 to ptr
  %t188 = load { i64, ptr }, ptr %l61
  %t189 = extractvalue { i64, ptr } %t188, 1
  %t190 = call ptr @__olang_region_or(ptr %t189, ptr null)
  %t191 = icmp ne ptr %t190, null
  %t192 = select i1 %t191, ptr %t190, ptr null
  call void @__olang_region_settle_in(ptr %t187, ptr %t192)
  %t193 = load ptr, ptr %l49, !tbaa !29
  %t194 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t193, i32 0, i32 1
  %t195 = load { i64, ptr }, ptr %t194, !tbaa !27
  store { i64, ptr } %t195, ptr %l80, !tbaa !27
  %t196 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t197 = load ptr, ptr %l49, !tbaa !29
  %t198 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t197, i32 0, i32 1
  store { i64, ptr } %t196, ptr %t198, !tbaa !27
  %t199 = load { i64, ptr }, ptr %l80
  %t200 = extractvalue { i64, ptr } %t199, 0
  %t201 = extractvalue { i64, ptr } %t199, 1
  call void @__olang_region_release_part(ptr %t201, i64 %t200)
  store { i64, ptr } zeroinitializer, ptr %l80
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fscope_3ainstTree_3_H09e74bdec0a93b685b7d9af6b699aaa3(ptr %v0, ptr %a0) noinline cold #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l9 = alloca i64
  %l14 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l32 = alloca { i64, ptr }
  %l33 = alloca i64
  %l39 = alloca { i64, ptr }
  %l49 = alloca ptr
  %l50 = alloca { i64, ptr }
  %l52 = alloca i64
  %l53 = alloca i64
  %l59 = alloca i64
  %l60 = alloca { i64, ptr }
  %l62 = alloca { i64, ptr }
  %l65 = alloca i64
  %l71 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp slt i64 %t6, 4
  br i1 %t8, label %bb1, label %bb2
bb1:
  store i64 8, ptr %l14, !tbaa !24
  br label %bb3
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t17 = mul i64 %t15, 2
  store i64 %t17, ptr %l14, !tbaa !24
  br label %bb3
bb3:
  %t19 = load i64, ptr %l14, !tbaa !24
  store i64 %t19, ptr %l1, !tbaa !24
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t20, i32 0, i32 0
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !27
  store { i64, ptr } %t23, ptr %l2, !tbaa !27
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l21, !tbaa !29
  %t26 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t26, ptr %l22, !tbaa !27
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t27, i32 0, i32 3
  %t30 = load i64, ptr %t29, !tbaa !24
  store i64 %t30, ptr %l24, !tbaa !24
  %t31 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  store i64 %t32, ptr %l25, !tbaa !24
  %t33 = icmp sge i64 0, 0
  br i1 %t33, label %bb4, label %bb5
bb4:
  %t35 = load i64, ptr %l24, !tbaa !24
  %t36 = icmp sle i64 0, %t35
  br i1 %t36, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_2d5992de5eb5e220_d01bd11e8c84951c)
  unreachable
bb6:
  %t38 = load i64, ptr %l24, !tbaa !24
  %t39 = load i64, ptr %l25, !tbaa !24
  %t40 = icmp sle i64 %t38, %t39
  br i1 %t40, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_2d5992de5eb5e220_d01bd11e8c84951c)
  unreachable
bb8:
  %t42 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = load i64, ptr %l24, !tbaa !24
  %t45 = getelementptr %"std/prelude/map:MapEntry.8feeaea6556533d50675c47385c120c2", ptr %t43, i64 0
  %t46 = sub i64 %t44, 0
  %t47 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t45, 1
  store { i64, ptr } %t48, ptr %l3, !tbaa !27
  %t50 = load i64, ptr %l1, !tbaa !24
  %t54 = mul i64 %t50, 40
  %t55 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t54)
  %t56 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t55, 1
  store { i64, ptr } %t57, ptr %l32, !tbaa !27
  store i64 0, ptr %l33, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_2d5992de5eb5e220_d01bd11e8c84951c)
  unreachable
bb10:
  %t58 = load i64, ptr %l5, !tbaa !24
  %t59 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t61 = extractvalue { i64, ptr } %t59, 0
  %t64 = icmp slt i64 %t58, %t61
  %t66 = xor i1 %t64, true
  br i1 %t66, label %bb11, label %bb12
bb11:
  br label %bb15
bb12:
  br label %bb13
bb13:
  %t68 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t68, ptr %l39, !tbaa !27
  %t69 = load i64, ptr %l5, !tbaa !24
  %t71 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !27
  %t73 = getelementptr %"std/prelude/map:MapEntry.8feeaea6556533d50675c47385c120c2", ptr %t72, i64 %t69
  %t74 = load %"std/prelude/map:MapEntry.8feeaea6556533d50675c47385c120c2", ptr %t73
  store %"std/prelude/map:MapEntry.8feeaea6556533d50675c47385c120c2" zeroinitializer, ptr %t73
  %t76 = load i64, ptr %l33, !tbaa !24
  %t77 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = getelementptr %"std/prelude/map:MapEntry.8feeaea6556533d50675c47385c120c2", ptr %t78, i64 %t76
  store %"std/prelude/map:MapEntry.8feeaea6556533d50675c47385c120c2" %t74, ptr %t79
  %t80 = load i64, ptr %l33, !tbaa !24
  %t81 = add i64 %t80, 1
  store i64 %t81, ptr %l33, !tbaa !24
  br label %bb14
bb14:
  %t82 = load i64, ptr %l5, !tbaa !24
  %t85 = add i64 %t82, 1
  store i64 %t85, ptr %l5, !tbaa !24
  br label %bb10
bb15:
  %t87 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t88 = load ptr, ptr %l21, !tbaa !29
  %t89 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t88, i32 0, i32 0
  store { i64, ptr } %t87, ptr %t89, !tbaa !27
  %t90 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t92, i32 0, i32 1
  %t95 = load { i64, ptr }, ptr %t94, !tbaa !27
  store { i64, ptr } %t95, ptr %l6, !tbaa !27
  %t97 = load ptr, ptr %l0, !tbaa !29
  store ptr %t97, ptr %l49, !tbaa !29
  %t98 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t98, ptr %l50, !tbaa !27
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t99, i32 0, i32 3
  %t102 = load i64, ptr %t101, !tbaa !24
  store i64 %t102, ptr %l52, !tbaa !24
  %t103 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t104 = extractvalue { i64, ptr } %t103, 0
  store i64 %t104, ptr %l53, !tbaa !24
  %t105 = icmp sge i64 0, 0
  br i1 %t105, label %bb16, label %bb17
bb16:
  %t107 = load i64, ptr %l52, !tbaa !24
  %t108 = icmp sle i64 0, %t107
  br i1 %t108, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_3273894d8bafbc7d_5b34b81ebd149289)
  unreachable
bb18:
  %t110 = load i64, ptr %l52, !tbaa !24
  %t111 = load i64, ptr %l53, !tbaa !24
  %t112 = icmp sle i64 %t110, %t111
  br i1 %t112, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_3273894d8bafbc7d_5b34b81ebd149289)
  unreachable
bb20:
  %t114 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !27
  %t116 = load i64, ptr %l52, !tbaa !24
  %t117 = getelementptr i64, ptr %t115, i64 0
  %t118 = sub i64 %t116, 0
  %t119 = insertvalue { i64, ptr } undef, i64 %t118, 0
  %t120 = insertvalue { i64, ptr } %t119, ptr %t117, 1
  store { i64, ptr } %t120, ptr %l7, !tbaa !27
  %t122 = load i64, ptr %l1, !tbaa !24
  store i64 %t122, ptr %l59, !tbaa !24
  %t125 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t127 = load i64, ptr %l59, !tbaa !24
  %t128 = extractvalue { i64, ptr } %t125, 0
  %t129 = mul i64 %t128, 8
  %t130 = mul i64 %t127, 8
  %t131 = extractvalue { i64, ptr } %t125, 1
  %t132 = call ptr @__olang_grow_in_place(ptr %t131, i64 %t129, i64 %t130, i64 %t127)
  %t133 = icmp ne ptr %t132, null
  %t134 = select i1 %t133, i64 %t127, i64 0
  %t135 = insertvalue { i64, ptr } undef, i64 %t134, 0
  %t136 = insertvalue { i64, ptr } %t135, ptr %t132, 1
  store { i64, ptr } %t136, ptr %l62, !tbaa !27
  %t137 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t138 = extractvalue { i64, ptr } %t137, 0
  %t140 = icmp ne i64 %t138, 0
  br i1 %t140, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_3273894d8bafbc7d_5b34b81ebd149289)
  unreachable
bb22:
  %t142 = load { i64, ptr }, ptr %l62, !tbaa !27
  store { i64, ptr } %t142, ptr %l60, !tbaa !27
  br label %bb24
bb23:
  %t143 = load i64, ptr %l59, !tbaa !24
  %t144 = mul i64 %t143, 8
  %t145 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t144)
  %t146 = insertvalue { i64, ptr } undef, i64 %t143, 0
  %t147 = insertvalue { i64, ptr } %t146, ptr %t145, 1
  store { i64, ptr } %t147, ptr %l60, !tbaa !27
  store i64 0, ptr %l65, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb25
bb24:
  %t148 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t149 = load ptr, ptr %l49, !tbaa !29
  %t150 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t149, i32 0, i32 1
  store { i64, ptr } %t148, ptr %t150, !tbaa !27
  %t151 = load { i64, ptr }, ptr %l6, !tbaa !27
  br label %ret
bb25:
  %t153 = load i64, ptr %l9, !tbaa !24
  %t154 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t156 = extractvalue { i64, ptr } %t154, 0
  %t159 = icmp slt i64 %t153, %t156
  %t161 = xor i1 %t159, true
  br i1 %t161, label %bb26, label %bb27
bb26:
  br label %bb30
bb27:
  br label %bb28
bb28:
  %t163 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t163, ptr %l71, !tbaa !27
  %t164 = load i64, ptr %l9, !tbaa !24
  %t166 = getelementptr { i64, ptr }, ptr %l71, i32 0, i32 1
  %t167 = load ptr, ptr %t166, !tbaa !27
  %t168 = getelementptr i64, ptr %t167, i64 %t164
  %t169 = load i64, ptr %t168, !tbaa !34
  %t171 = load i64, ptr %l65, !tbaa !24
  %t172 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t173 = load ptr, ptr %t172, !tbaa !27
  %t174 = getelementptr i64, ptr %t173, i64 %t171
  store i64 %t169, ptr %t174, !tbaa !34
  %t175 = load i64, ptr %l65, !tbaa !24
  %t176 = add i64 %t175, 1
  store i64 %t176, ptr %l65, !tbaa !24
  br label %bb29
bb29:
  %t177 = load i64, ptr %l9, !tbaa !24
  %t180 = add i64 %t177, 1
  store i64 %t180, ptr %l9, !tbaa !24
  br label %bb25
bb30:
  br label %bb24
ret:
  ret void
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_H65d3befeefd610ac34988050904a0f74(ptr %v0, ptr %a0) noinline cold #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l5 = alloca i64
  %l7 = alloca { i64, ptr }
  %l9 = alloca i64
  %l14 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l31 = alloca i64
  %l32 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l37 = alloca i64
  %l43 = alloca { i64, ptr }
  %l53 = alloca ptr
  %l54 = alloca { i64, ptr }
  %l56 = alloca i64
  %l57 = alloca i64
  %l63 = alloca i64
  %l64 = alloca i64
  %l65 = alloca { i64, ptr }
  %l67 = alloca { i64, ptr }
  %l70 = alloca i64
  %l76 = alloca { i64, ptr }
  %l84 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp slt i64 %t6, 4
  br i1 %t8, label %bb1, label %bb2
bb1:
  store i64 8, ptr %l14, !tbaa !24
  br label %bb3
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t17 = mul i64 %t15, 2
  store i64 %t17, ptr %l14, !tbaa !24
  br label %bb3
bb3:
  %t19 = load i64, ptr %l14, !tbaa !24
  store i64 %t19, ptr %l1, !tbaa !24
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t20, i32 0, i32 0
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !27
  store { i64, ptr } %t23, ptr %l2, !tbaa !27
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l21, !tbaa !29
  %t26 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t26, ptr %l22, !tbaa !27
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t27, i32 0, i32 3
  %t30 = load i64, ptr %t29, !tbaa !24
  store i64 %t30, ptr %l24, !tbaa !24
  %t31 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  store i64 %t32, ptr %l25, !tbaa !24
  %t33 = icmp sge i64 0, 0
  br i1 %t33, label %bb4, label %bb5
bb4:
  %t35 = load i64, ptr %l24, !tbaa !24
  %t36 = icmp sle i64 0, %t35
  br i1 %t36, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_cfa5d910a69519b_67e6a2203f5ae367)
  unreachable
bb6:
  %t38 = load i64, ptr %l24, !tbaa !24
  %t39 = load i64, ptr %l25, !tbaa !24
  %t40 = icmp sle i64 %t38, %t39
  br i1 %t40, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_cfa5d910a69519b_67e6a2203f5ae367)
  unreachable
bb8:
  %t42 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = load i64, ptr %l24, !tbaa !24
  %t45 = getelementptr %"std/prelude/map:MapEntry.1eb2466213689e002f25e81e83536e78", ptr %t43, i64 0
  %t46 = sub i64 %t44, 0
  %t47 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t45, 1
  store { i64, ptr } %t48, ptr %l3, !tbaa !27
  %t50 = load i64, ptr %l1, !tbaa !24
  store i64 %t50, ptr %l31, !tbaa !24
  %t53 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t55 = load i64, ptr %l31, !tbaa !24
  %t56 = extractvalue { i64, ptr } %t53, 0
  %t57 = mul i64 %t56, 16
  %t58 = mul i64 %t55, 16
  %t59 = extractvalue { i64, ptr } %t53, 1
  %t60 = call ptr @__olang_grow_in_place(ptr %t59, i64 %t57, i64 %t58, i64 %t55)
  %t61 = icmp ne ptr %t60, null
  %t62 = select i1 %t61, i64 %t55, i64 0
  %t63 = insertvalue { i64, ptr } undef, i64 %t62, 0
  %t64 = insertvalue { i64, ptr } %t63, ptr %t60, 1
  store { i64, ptr } %t64, ptr %l34, !tbaa !27
  %t65 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t66 = extractvalue { i64, ptr } %t65, 0
  %t68 = icmp ne i64 %t66, 0
  br i1 %t68, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_cfa5d910a69519b_67e6a2203f5ae367)
  unreachable
bb10:
  %t70 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t70, ptr %l32, !tbaa !27
  br label %bb12
bb11:
  %t71 = load i64, ptr %l31, !tbaa !24
  %t72 = mul i64 %t71, 16
  %t73 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t72)
  %t74 = insertvalue { i64, ptr } undef, i64 %t71, 0
  %t75 = insertvalue { i64, ptr } %t74, ptr %t73, 1
  store { i64, ptr } %t75, ptr %l32, !tbaa !27
  store i64 0, ptr %l37, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb13
bb12:
  %t76 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t77 = load ptr, ptr %l21, !tbaa !29
  %t78 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t77, i32 0, i32 0
  store { i64, ptr } %t76, ptr %t78, !tbaa !27
  %t79 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t81, i32 0, i32 1
  %t84 = load { i64, ptr }, ptr %t83, !tbaa !27
  %t86 = load ptr, ptr %l0, !tbaa !29
  store ptr %t86, ptr %l53, !tbaa !29
  store { i64, ptr } %t84, ptr %l54, !tbaa !27
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t88, i32 0, i32 3
  %t91 = load i64, ptr %t90, !tbaa !24
  store i64 %t91, ptr %l56, !tbaa !24
  %t92 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t93 = extractvalue { i64, ptr } %t92, 0
  store i64 %t93, ptr %l57, !tbaa !24
  %t94 = icmp sge i64 0, 0
  br i1 %t94, label %bb19, label %bb20
bb13:
  %t96 = load i64, ptr %l5, !tbaa !24
  %t97 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t99 = extractvalue { i64, ptr } %t97, 0
  %t102 = icmp slt i64 %t96, %t99
  %t104 = xor i1 %t102, true
  br i1 %t104, label %bb14, label %bb15
bb14:
  br label %bb18
bb15:
  br label %bb16
bb16:
  %t106 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t106, ptr %l43, !tbaa !27
  %t107 = load i64, ptr %l5, !tbaa !24
  %t109 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t110 = load ptr, ptr %t109, !tbaa !27
  %t111 = getelementptr %"std/prelude/map:MapEntry.1eb2466213689e002f25e81e83536e78", ptr %t110, i64 %t107
  %t112 = load %"std/prelude/map:MapEntry.1eb2466213689e002f25e81e83536e78", ptr %t111
  %t114 = load i64, ptr %l37, !tbaa !24
  %t115 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !27
  %t117 = getelementptr %"std/prelude/map:MapEntry.1eb2466213689e002f25e81e83536e78", ptr %t116, i64 %t114
  store %"std/prelude/map:MapEntry.1eb2466213689e002f25e81e83536e78" %t112, ptr %t117
  %t118 = load i64, ptr %l37, !tbaa !24
  %t119 = add i64 %t118, 1
  store i64 %t119, ptr %l37, !tbaa !24
  br label %bb17
bb17:
  %t120 = load i64, ptr %l5, !tbaa !24
  %t123 = add i64 %t120, 1
  store i64 %t123, ptr %l5, !tbaa !24
  br label %bb13
bb18:
  br label %bb12
bb19:
  %t125 = load i64, ptr %l56, !tbaa !24
  %t126 = icmp sle i64 0, %t125
  br i1 %t126, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_24d09e1cc7a3419e_87b719873437508a)
  unreachable
bb21:
  %t128 = load i64, ptr %l56, !tbaa !24
  %t129 = load i64, ptr %l57, !tbaa !24
  %t130 = icmp sle i64 %t128, %t129
  br i1 %t130, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_24d09e1cc7a3419e_87b719873437508a)
  unreachable
bb23:
  %t132 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !27
  %t134 = load i64, ptr %l56, !tbaa !24
  %t135 = getelementptr i64, ptr %t133, i64 0
  %t136 = sub i64 %t134, 0
  %t137 = insertvalue { i64, ptr } undef, i64 %t136, 0
  %t138 = insertvalue { i64, ptr } %t137, ptr %t135, 1
  store { i64, ptr } %t138, ptr %l7, !tbaa !27
  %t140 = load i64, ptr %l1, !tbaa !24
  %t142 = call ptr @__olang_region_make_part(ptr %v0)
  %t143 = ptrtoint ptr %t142 to i64
  store i64 %t143, ptr %l63, !tbaa !24
  store i64 %t140, ptr %l64, !tbaa !24
  %t145 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t147 = load i64, ptr %l64, !tbaa !24
  %t148 = extractvalue { i64, ptr } %t145, 0
  %t149 = mul i64 %t148, 8
  %t150 = mul i64 %t147, 8
  %t151 = extractvalue { i64, ptr } %t145, 1
  %t152 = call ptr @__olang_grow_in_place(ptr %t151, i64 %t149, i64 %t150, i64 %t147)
  %t153 = icmp ne ptr %t152, null
  %t154 = select i1 %t153, i64 %t147, i64 0
  %t155 = insertvalue { i64, ptr } undef, i64 %t154, 0
  %t156 = insertvalue { i64, ptr } %t155, ptr %t152, 1
  store { i64, ptr } %t156, ptr %l67, !tbaa !27
  %t157 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t158 = extractvalue { i64, ptr } %t157, 0
  %t160 = icmp ne i64 %t158, 0
  br i1 %t160, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_24d09e1cc7a3419e_87b719873437508a)
  unreachable
bb25:
  %t162 = load { i64, ptr }, ptr %l67, !tbaa !27
  store { i64, ptr } %t162, ptr %l65, !tbaa !27
  br label %bb27
bb26:
  %t163 = load i64, ptr %l64, !tbaa !24
  %t164 = mul i64 %t163, 8
  %t165 = load i64, ptr %l63
  %t166 = inttoptr i64 %t165 to ptr
  %t167 = call ptr @__olang_held_alloc(ptr %t166, i64 %t164)
  %t168 = insertvalue { i64, ptr } undef, i64 %t163, 0
  %t169 = insertvalue { i64, ptr } %t168, ptr %t167, 1
  store { i64, ptr } %t169, ptr %l65, !tbaa !27
  store i64 0, ptr %l70, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb28
bb27:
  %t170 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t171 = extractvalue { i64, ptr } %t170, 0
  %t173 = icmp eq i64 %t171, 0
  br i1 %t173, label %bb34, label %bb35
bb28:
  %t175 = load i64, ptr %l9, !tbaa !24
  %t176 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t178 = extractvalue { i64, ptr } %t176, 0
  %t181 = icmp slt i64 %t175, %t178
  %t183 = xor i1 %t181, true
  br i1 %t183, label %bb29, label %bb30
bb29:
  br label %bb33
bb30:
  br label %bb31
bb31:
  %t185 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t185, ptr %l76, !tbaa !27
  %t186 = load i64, ptr %l9, !tbaa !24
  %t188 = getelementptr { i64, ptr }, ptr %l76, i32 0, i32 1
  %t189 = load ptr, ptr %t188, !tbaa !27
  %t190 = getelementptr i64, ptr %t189, i64 %t186
  %t191 = load i64, ptr %t190, !tbaa !34
  %t193 = load i64, ptr %l70, !tbaa !24
  %t194 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t195 = load ptr, ptr %t194, !tbaa !27
  %t196 = getelementptr i64, ptr %t195, i64 %t193
  store i64 %t191, ptr %t196, !tbaa !34
  %t197 = load i64, ptr %l70, !tbaa !24
  %t198 = add i64 %t197, 1
  store i64 %t198, ptr %l70, !tbaa !24
  br label %bb32
bb32:
  %t199 = load i64, ptr %l9, !tbaa !24
  %t202 = add i64 %t199, 1
  store i64 %t202, ptr %l9, !tbaa !24
  br label %bb28
bb33:
  br label %bb27
bb34:
  store { i64, ptr } zeroinitializer, ptr %l65, !tbaa !27
  br label %bb35
bb35:
  %t204 = load i64, ptr %l63
  %t205 = inttoptr i64 %t204 to ptr
  %t206 = load { i64, ptr }, ptr %l65
  %t207 = extractvalue { i64, ptr } %t206, 1
  %t208 = call ptr @__olang_region_or(ptr %t207, ptr null)
  %t209 = icmp ne ptr %t208, null
  %t210 = select i1 %t209, ptr %t208, ptr null
  call void @__olang_region_settle_in(ptr %t205, ptr %t210)
  %t211 = load ptr, ptr %l53, !tbaa !29
  %t212 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t211, i32 0, i32 1
  %t213 = load { i64, ptr }, ptr %t212, !tbaa !27
  store { i64, ptr } %t213, ptr %l84, !tbaa !27
  %t214 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t215 = load ptr, ptr %l53, !tbaa !29
  %t216 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t215, i32 0, i32 1
  store { i64, ptr } %t214, ptr %t216, !tbaa !27
  %t217 = load { i64, ptr }, ptr %l84
  %t218 = extractvalue { i64, ptr } %t217, 0
  %t219 = extractvalue { i64, ptr } %t217, 1
  call void @__olang_region_release_part(ptr %t219, i64 %t218)
  store { i64, ptr } zeroinitializer, ptr %l84
  br label %ret
ret:
  ret void
}

@std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aVersions_2_H67bdfd5895c1c6f4cf875ae628eca69b = dso_local alias void (ptr, ptr), ptr @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_H65d3befeefd610ac34988050904a0f74
define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_H578f6ddf8deeede0d17903533a2e3444(ptr %v0, ptr %a0) noinline cold #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l9 = alloca i64
  %l14 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l31 = alloca i64
  %l32 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l37 = alloca i64
  %l43 = alloca { i64, ptr }
  %l53 = alloca ptr
  %l54 = alloca { i64, ptr }
  %l56 = alloca i64
  %l57 = alloca i64
  %l63 = alloca i64
  %l64 = alloca { i64, ptr }
  %l66 = alloca { i64, ptr }
  %l69 = alloca i64
  %l75 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp slt i64 %t6, 4
  br i1 %t8, label %bb1, label %bb2
bb1:
  store i64 8, ptr %l14, !tbaa !24
  br label %bb3
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t17 = mul i64 %t15, 2
  store i64 %t17, ptr %l14, !tbaa !24
  br label %bb3
bb3:
  %t19 = load i64, ptr %l14, !tbaa !24
  store i64 %t19, ptr %l1, !tbaa !24
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t20, i32 0, i32 0
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !27
  store { i64, ptr } %t23, ptr %l2, !tbaa !27
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l21, !tbaa !29
  %t26 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t26, ptr %l22, !tbaa !27
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t27, i32 0, i32 3
  %t30 = load i64, ptr %t29, !tbaa !24
  store i64 %t30, ptr %l24, !tbaa !24
  %t31 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  store i64 %t32, ptr %l25, !tbaa !24
  %t33 = icmp sge i64 0, 0
  br i1 %t33, label %bb4, label %bb5
bb4:
  %t35 = load i64, ptr %l24, !tbaa !24
  %t36 = icmp sle i64 0, %t35
  br i1 %t36, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_df3b8f0899449cba_3e19093db1eeacce)
  unreachable
bb6:
  %t38 = load i64, ptr %l24, !tbaa !24
  %t39 = load i64, ptr %l25, !tbaa !24
  %t40 = icmp sle i64 %t38, %t39
  br i1 %t40, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_df3b8f0899449cba_3e19093db1eeacce)
  unreachable
bb8:
  %t42 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = load i64, ptr %l24, !tbaa !24
  %t45 = getelementptr %"std/prelude/map:MapEntry.8d509622153b47f1a5f79c42c8367406", ptr %t43, i64 0
  %t46 = sub i64 %t44, 0
  %t47 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t45, 1
  store { i64, ptr } %t48, ptr %l3, !tbaa !27
  %t50 = load i64, ptr %l1, !tbaa !24
  store i64 %t50, ptr %l31, !tbaa !24
  %t53 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t55 = load i64, ptr %l31, !tbaa !24
  %t56 = extractvalue { i64, ptr } %t53, 0
  %t57 = mul i64 %t56, 24
  %t58 = mul i64 %t55, 24
  %t59 = extractvalue { i64, ptr } %t53, 1
  %t60 = call ptr @__olang_grow_in_place(ptr %t59, i64 %t57, i64 %t58, i64 %t55)
  %t61 = icmp ne ptr %t60, null
  %t62 = select i1 %t61, i64 %t55, i64 0
  %t63 = insertvalue { i64, ptr } undef, i64 %t62, 0
  %t64 = insertvalue { i64, ptr } %t63, ptr %t60, 1
  store { i64, ptr } %t64, ptr %l34, !tbaa !27
  %t65 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t66 = extractvalue { i64, ptr } %t65, 0
  %t68 = icmp ne i64 %t66, 0
  br i1 %t68, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_df3b8f0899449cba_3e19093db1eeacce)
  unreachable
bb10:
  %t70 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t70, ptr %l32, !tbaa !27
  br label %bb12
bb11:
  %t71 = load i64, ptr %l31, !tbaa !24
  %t72 = mul i64 %t71, 24
  %t73 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t72)
  %t74 = insertvalue { i64, ptr } undef, i64 %t71, 0
  %t75 = insertvalue { i64, ptr } %t74, ptr %t73, 1
  store { i64, ptr } %t75, ptr %l32, !tbaa !27
  store i64 0, ptr %l37, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb13
bb12:
  %t76 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t77 = load ptr, ptr %l21, !tbaa !29
  %t78 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t77, i32 0, i32 0
  store { i64, ptr } %t76, ptr %t78, !tbaa !27
  %t79 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t81, i32 0, i32 1
  %t84 = load { i64, ptr }, ptr %t83, !tbaa !27
  store { i64, ptr } %t84, ptr %l6, !tbaa !27
  %t86 = load ptr, ptr %l0, !tbaa !29
  store ptr %t86, ptr %l53, !tbaa !29
  %t87 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t87, ptr %l54, !tbaa !27
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t88, i32 0, i32 3
  %t91 = load i64, ptr %t90, !tbaa !24
  store i64 %t91, ptr %l56, !tbaa !24
  %t92 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t93 = extractvalue { i64, ptr } %t92, 0
  store i64 %t93, ptr %l57, !tbaa !24
  %t94 = icmp sge i64 0, 0
  br i1 %t94, label %bb19, label %bb20
bb13:
  %t96 = load i64, ptr %l5, !tbaa !24
  %t97 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t99 = extractvalue { i64, ptr } %t97, 0
  %t102 = icmp slt i64 %t96, %t99
  %t104 = xor i1 %t102, true
  br i1 %t104, label %bb14, label %bb15
bb14:
  br label %bb18
bb15:
  br label %bb16
bb16:
  %t106 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t106, ptr %l43, !tbaa !27
  %t107 = load i64, ptr %l5, !tbaa !24
  %t109 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t110 = load ptr, ptr %t109, !tbaa !27
  %t111 = getelementptr %"std/prelude/map:MapEntry.8d509622153b47f1a5f79c42c8367406", ptr %t110, i64 %t107
  %t112 = load %"std/prelude/map:MapEntry.8d509622153b47f1a5f79c42c8367406", ptr %t111
  %t114 = load i64, ptr %l37, !tbaa !24
  %t115 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !27
  %t117 = getelementptr %"std/prelude/map:MapEntry.8d509622153b47f1a5f79c42c8367406", ptr %t116, i64 %t114
  store %"std/prelude/map:MapEntry.8d509622153b47f1a5f79c42c8367406" %t112, ptr %t117
  %t118 = load i64, ptr %l37, !tbaa !24
  %t119 = add i64 %t118, 1
  store i64 %t119, ptr %l37, !tbaa !24
  br label %bb17
bb17:
  %t120 = load i64, ptr %l5, !tbaa !24
  %t123 = add i64 %t120, 1
  store i64 %t123, ptr %l5, !tbaa !24
  br label %bb13
bb18:
  br label %bb12
bb19:
  %t125 = load i64, ptr %l56, !tbaa !24
  %t126 = icmp sle i64 0, %t125
  br i1 %t126, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_120c5452e84f3f97_763eee1079714acb)
  unreachable
bb21:
  %t128 = load i64, ptr %l56, !tbaa !24
  %t129 = load i64, ptr %l57, !tbaa !24
  %t130 = icmp sle i64 %t128, %t129
  br i1 %t130, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_120c5452e84f3f97_763eee1079714acb)
  unreachable
bb23:
  %t132 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !27
  %t134 = load i64, ptr %l56, !tbaa !24
  %t135 = getelementptr i64, ptr %t133, i64 0
  %t136 = sub i64 %t134, 0
  %t137 = insertvalue { i64, ptr } undef, i64 %t136, 0
  %t138 = insertvalue { i64, ptr } %t137, ptr %t135, 1
  store { i64, ptr } %t138, ptr %l7, !tbaa !27
  %t140 = load i64, ptr %l1, !tbaa !24
  store i64 %t140, ptr %l63, !tbaa !24
  %t143 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t145 = load i64, ptr %l63, !tbaa !24
  %t146 = extractvalue { i64, ptr } %t143, 0
  %t147 = mul i64 %t146, 8
  %t148 = mul i64 %t145, 8
  %t149 = extractvalue { i64, ptr } %t143, 1
  %t150 = call ptr @__olang_grow_in_place(ptr %t149, i64 %t147, i64 %t148, i64 %t145)
  %t151 = icmp ne ptr %t150, null
  %t152 = select i1 %t151, i64 %t145, i64 0
  %t153 = insertvalue { i64, ptr } undef, i64 %t152, 0
  %t154 = insertvalue { i64, ptr } %t153, ptr %t150, 1
  store { i64, ptr } %t154, ptr %l66, !tbaa !27
  %t155 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t156 = extractvalue { i64, ptr } %t155, 0
  %t158 = icmp ne i64 %t156, 0
  br i1 %t158, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_120c5452e84f3f97_763eee1079714acb)
  unreachable
bb25:
  %t160 = load { i64, ptr }, ptr %l66, !tbaa !27
  store { i64, ptr } %t160, ptr %l64, !tbaa !27
  br label %bb27
bb26:
  %t161 = load i64, ptr %l63, !tbaa !24
  %t162 = mul i64 %t161, 8
  %t163 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t162)
  %t164 = insertvalue { i64, ptr } undef, i64 %t161, 0
  %t165 = insertvalue { i64, ptr } %t164, ptr %t163, 1
  store { i64, ptr } %t165, ptr %l64, !tbaa !27
  store i64 0, ptr %l69, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb28
bb27:
  %t166 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t167 = load ptr, ptr %l53, !tbaa !29
  %t168 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t167, i32 0, i32 1
  store { i64, ptr } %t166, ptr %t168, !tbaa !27
  %t169 = load { i64, ptr }, ptr %l6, !tbaa !27
  br label %ret
bb28:
  %t171 = load i64, ptr %l9, !tbaa !24
  %t172 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t174 = extractvalue { i64, ptr } %t172, 0
  %t177 = icmp slt i64 %t171, %t174
  %t179 = xor i1 %t177, true
  br i1 %t179, label %bb29, label %bb30
bb29:
  br label %bb33
bb30:
  br label %bb31
bb31:
  %t181 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t181, ptr %l75, !tbaa !27
  %t182 = load i64, ptr %l9, !tbaa !24
  %t184 = getelementptr { i64, ptr }, ptr %l75, i32 0, i32 1
  %t185 = load ptr, ptr %t184, !tbaa !27
  %t186 = getelementptr i64, ptr %t185, i64 %t182
  %t187 = load i64, ptr %t186, !tbaa !34
  %t189 = load i64, ptr %l69, !tbaa !24
  %t190 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t191 = load ptr, ptr %t190, !tbaa !27
  %t192 = getelementptr i64, ptr %t191, i64 %t189
  store i64 %t187, ptr %t192, !tbaa !34
  %t193 = load i64, ptr %l69, !tbaa !24
  %t194 = add i64 %t193, 1
  store i64 %t194, ptr %l69, !tbaa !24
  br label %bb32
bb32:
  %t195 = load i64, ptr %l9, !tbaa !24
  %t198 = add i64 %t195, 1
  store i64 %t198, ptr %l9, !tbaa !24
  br label %bb28
bb33:
  br label %bb27
ret:
  ret void
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cI_Haa7b37fb55048dd0c74843ff955f57e2(ptr %v0, ptr %a0) noinline cold #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l9 = alloca i64
  %l14 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l32 = alloca { i64, ptr }
  %l33 = alloca i64
  %l39 = alloca { i64, ptr }
  %l49 = alloca ptr
  %l50 = alloca { i64, ptr }
  %l52 = alloca i64
  %l53 = alloca i64
  %l59 = alloca i64
  %l60 = alloca { i64, ptr }
  %l62 = alloca { i64, ptr }
  %l65 = alloca i64
  %l71 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp slt i64 %t6, 4
  br i1 %t8, label %bb1, label %bb2
bb1:
  store i64 8, ptr %l14, !tbaa !24
  br label %bb3
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t17 = mul i64 %t15, 2
  store i64 %t17, ptr %l14, !tbaa !24
  br label %bb3
bb3:
  %t19 = load i64, ptr %l14, !tbaa !24
  store i64 %t19, ptr %l1, !tbaa !24
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t20, i32 0, i32 0
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !27
  store { i64, ptr } %t23, ptr %l2, !tbaa !27
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l21, !tbaa !29
  %t26 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t26, ptr %l22, !tbaa !27
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t27, i32 0, i32 3
  %t30 = load i64, ptr %t29, !tbaa !24
  store i64 %t30, ptr %l24, !tbaa !24
  %t31 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  store i64 %t32, ptr %l25, !tbaa !24
  %t33 = icmp sge i64 0, 0
  br i1 %t33, label %bb4, label %bb5
bb4:
  %t35 = load i64, ptr %l24, !tbaa !24
  %t36 = icmp sle i64 0, %t35
  br i1 %t36, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_4eccde1bb0e637f8_700fb4e34e9e4e0c)
  unreachable
bb6:
  %t38 = load i64, ptr %l24, !tbaa !24
  %t39 = load i64, ptr %l25, !tbaa !24
  %t40 = icmp sle i64 %t38, %t39
  br i1 %t40, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_4eccde1bb0e637f8_700fb4e34e9e4e0c)
  unreachable
bb8:
  %t42 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = load i64, ptr %l24, !tbaa !24
  %t45 = getelementptr %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613", ptr %t43, i64 0
  %t46 = sub i64 %t44, 0
  %t47 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t45, 1
  store { i64, ptr } %t48, ptr %l3, !tbaa !27
  %t50 = load i64, ptr %l1, !tbaa !24
  %t54 = mul i64 %t50, 40
  %t55 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t54)
  %t56 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t55, 1
  store { i64, ptr } %t57, ptr %l32, !tbaa !27
  store i64 0, ptr %l33, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_4eccde1bb0e637f8_700fb4e34e9e4e0c)
  unreachable
bb10:
  %t58 = load i64, ptr %l5, !tbaa !24
  %t59 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t61 = extractvalue { i64, ptr } %t59, 0
  %t64 = icmp slt i64 %t58, %t61
  %t66 = xor i1 %t64, true
  br i1 %t66, label %bb11, label %bb12
bb11:
  br label %bb15
bb12:
  br label %bb13
bb13:
  %t68 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t68, ptr %l39, !tbaa !27
  %t69 = load i64, ptr %l5, !tbaa !24
  %t71 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !27
  %t73 = getelementptr %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613", ptr %t72, i64 %t69
  %t74 = load %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613", ptr %t73
  store %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613" zeroinitializer, ptr %t73
  %t76 = load i64, ptr %l33, !tbaa !24
  %t77 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = getelementptr %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613", ptr %t78, i64 %t76
  store %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613" %t74, ptr %t79
  %t80 = load i64, ptr %l33, !tbaa !24
  %t81 = add i64 %t80, 1
  store i64 %t81, ptr %l33, !tbaa !24
  br label %bb14
bb14:
  %t82 = load i64, ptr %l5, !tbaa !24
  %t85 = add i64 %t82, 1
  store i64 %t85, ptr %l5, !tbaa !24
  br label %bb10
bb15:
  %t87 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t88 = load ptr, ptr %l21, !tbaa !29
  %t89 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t88, i32 0, i32 0
  store { i64, ptr } %t87, ptr %t89, !tbaa !27
  %t90 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t92, i32 0, i32 1
  %t95 = load { i64, ptr }, ptr %t94, !tbaa !27
  store { i64, ptr } %t95, ptr %l6, !tbaa !27
  %t97 = load ptr, ptr %l0, !tbaa !29
  store ptr %t97, ptr %l49, !tbaa !29
  %t98 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t98, ptr %l50, !tbaa !27
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t99, i32 0, i32 3
  %t102 = load i64, ptr %t101, !tbaa !24
  store i64 %t102, ptr %l52, !tbaa !24
  %t103 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t104 = extractvalue { i64, ptr } %t103, 0
  store i64 %t104, ptr %l53, !tbaa !24
  %t105 = icmp sge i64 0, 0
  br i1 %t105, label %bb16, label %bb17
bb16:
  %t107 = load i64, ptr %l52, !tbaa !24
  %t108 = icmp sle i64 0, %t107
  br i1 %t108, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_70c5af7f062357d5_5e76ff2066ccf239)
  unreachable
bb18:
  %t110 = load i64, ptr %l52, !tbaa !24
  %t111 = load i64, ptr %l53, !tbaa !24
  %t112 = icmp sle i64 %t110, %t111
  br i1 %t112, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_70c5af7f062357d5_5e76ff2066ccf239)
  unreachable
bb20:
  %t114 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !27
  %t116 = load i64, ptr %l52, !tbaa !24
  %t117 = getelementptr i64, ptr %t115, i64 0
  %t118 = sub i64 %t116, 0
  %t119 = insertvalue { i64, ptr } undef, i64 %t118, 0
  %t120 = insertvalue { i64, ptr } %t119, ptr %t117, 1
  store { i64, ptr } %t120, ptr %l7, !tbaa !27
  %t122 = load i64, ptr %l1, !tbaa !24
  store i64 %t122, ptr %l59, !tbaa !24
  %t125 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t127 = load i64, ptr %l59, !tbaa !24
  %t128 = extractvalue { i64, ptr } %t125, 0
  %t129 = mul i64 %t128, 8
  %t130 = mul i64 %t127, 8
  %t131 = extractvalue { i64, ptr } %t125, 1
  %t132 = call ptr @__olang_grow_in_place(ptr %t131, i64 %t129, i64 %t130, i64 %t127)
  %t133 = icmp ne ptr %t132, null
  %t134 = select i1 %t133, i64 %t127, i64 0
  %t135 = insertvalue { i64, ptr } undef, i64 %t134, 0
  %t136 = insertvalue { i64, ptr } %t135, ptr %t132, 1
  store { i64, ptr } %t136, ptr %l62, !tbaa !27
  %t137 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t138 = extractvalue { i64, ptr } %t137, 0
  %t140 = icmp ne i64 %t138, 0
  br i1 %t140, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_70c5af7f062357d5_5e76ff2066ccf239)
  unreachable
bb22:
  %t142 = load { i64, ptr }, ptr %l62, !tbaa !27
  store { i64, ptr } %t142, ptr %l60, !tbaa !27
  br label %bb24
bb23:
  %t143 = load i64, ptr %l59, !tbaa !24
  %t144 = mul i64 %t143, 8
  %t145 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t144)
  %t146 = insertvalue { i64, ptr } undef, i64 %t143, 0
  %t147 = insertvalue { i64, ptr } %t146, ptr %t145, 1
  store { i64, ptr } %t147, ptr %l60, !tbaa !27
  store i64 0, ptr %l65, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb25
bb24:
  %t148 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t149 = load ptr, ptr %l49, !tbaa !29
  %t150 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t149, i32 0, i32 1
  store { i64, ptr } %t148, ptr %t150, !tbaa !27
  %t151 = load { i64, ptr }, ptr %l6, !tbaa !27
  br label %ret
bb25:
  %t153 = load i64, ptr %l9, !tbaa !24
  %t154 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t156 = extractvalue { i64, ptr } %t154, 0
  %t159 = icmp slt i64 %t153, %t156
  %t161 = xor i1 %t159, true
  br i1 %t161, label %bb26, label %bb27
bb26:
  br label %bb30
bb27:
  br label %bb28
bb28:
  %t163 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t163, ptr %l71, !tbaa !27
  %t164 = load i64, ptr %l9, !tbaa !24
  %t166 = getelementptr { i64, ptr }, ptr %l71, i32 0, i32 1
  %t167 = load ptr, ptr %t166, !tbaa !27
  %t168 = getelementptr i64, ptr %t167, i64 %t164
  %t169 = load i64, ptr %t168, !tbaa !34
  %t171 = load i64, ptr %l65, !tbaa !24
  %t172 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t173 = load ptr, ptr %t172, !tbaa !27
  %t174 = getelementptr i64, ptr %t173, i64 %t171
  store i64 %t169, ptr %t174, !tbaa !34
  %t175 = load i64, ptr %l65, !tbaa !24
  %t176 = add i64 %t175, 1
  store i64 %t176, ptr %l65, !tbaa !24
  br label %bb29
bb29:
  %t177 = load i64, ptr %l9, !tbaa !24
  %t180 = add i64 %t177, 1
  store i64 %t180, ptr %l9, !tbaa !24
  br label %bb25
bb30:
  br label %bb24
ret:
  ret void
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_Hbbe9f70b7f65eade62601b1ea8bf7ab6(ptr %v0, ptr %a0) noinline cold #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l5 = alloca i64
  %l7 = alloca { i64, ptr }
  %l9 = alloca i64
  %l14 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l32 = alloca { i64, ptr }
  %l33 = alloca i64
  %l39 = alloca { i64, ptr }
  %l49 = alloca ptr
  %l50 = alloca { i64, ptr }
  %l52 = alloca i64
  %l53 = alloca i64
  %l59 = alloca i64
  %l60 = alloca i64
  %l61 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %l66 = alloca i64
  %l72 = alloca { i64, ptr }
  %l80 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp slt i64 %t6, 4
  br i1 %t8, label %bb1, label %bb2
bb1:
  store i64 8, ptr %l14, !tbaa !24
  br label %bb3
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t17 = mul i64 %t15, 2
  store i64 %t17, ptr %l14, !tbaa !24
  br label %bb3
bb3:
  %t19 = load i64, ptr %l14, !tbaa !24
  store i64 %t19, ptr %l1, !tbaa !24
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t20, i32 0, i32 0
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !27
  store { i64, ptr } %t23, ptr %l2, !tbaa !27
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l21, !tbaa !29
  %t26 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t26, ptr %l22, !tbaa !27
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t27, i32 0, i32 3
  %t30 = load i64, ptr %t29, !tbaa !24
  store i64 %t30, ptr %l24, !tbaa !24
  %t31 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  store i64 %t32, ptr %l25, !tbaa !24
  %t33 = icmp sge i64 0, 0
  br i1 %t33, label %bb4, label %bb5
bb4:
  %t35 = load i64, ptr %l24, !tbaa !24
  %t36 = icmp sle i64 0, %t35
  br i1 %t36, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_ce54309ebf43a10c_695faa571e12de08)
  unreachable
bb6:
  %t38 = load i64, ptr %l24, !tbaa !24
  %t39 = load i64, ptr %l25, !tbaa !24
  %t40 = icmp sle i64 %t38, %t39
  br i1 %t40, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_ce54309ebf43a10c_695faa571e12de08)
  unreachable
bb8:
  %t42 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = load i64, ptr %l24, !tbaa !24
  %t45 = getelementptr %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613", ptr %t43, i64 0
  %t46 = sub i64 %t44, 0
  %t47 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t45, 1
  store { i64, ptr } %t48, ptr %l3, !tbaa !27
  %t50 = load i64, ptr %l1, !tbaa !24
  %t54 = mul i64 %t50, 40
  %t55 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t54)
  %t56 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t55, 1
  store { i64, ptr } %t57, ptr %l32, !tbaa !27
  store i64 0, ptr %l33, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_ce54309ebf43a10c_695faa571e12de08)
  unreachable
bb10:
  %t58 = load i64, ptr %l5, !tbaa !24
  %t59 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t61 = extractvalue { i64, ptr } %t59, 0
  %t64 = icmp slt i64 %t58, %t61
  %t66 = xor i1 %t64, true
  br i1 %t66, label %bb11, label %bb12
bb11:
  br label %bb15
bb12:
  br label %bb13
bb13:
  %t68 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t68, ptr %l39, !tbaa !27
  %t69 = load i64, ptr %l5, !tbaa !24
  %t71 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !27
  %t73 = getelementptr %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613", ptr %t72, i64 %t69
  %t74 = load %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613", ptr %t73
  store %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613" zeroinitializer, ptr %t73
  %t76 = load i64, ptr %l33, !tbaa !24
  %t77 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = getelementptr %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613", ptr %t78, i64 %t76
  store %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613" %t74, ptr %t79
  %t80 = load i64, ptr %l33, !tbaa !24
  %t81 = add i64 %t80, 1
  store i64 %t81, ptr %l33, !tbaa !24
  br label %bb14
bb14:
  %t82 = load i64, ptr %l5, !tbaa !24
  %t85 = add i64 %t82, 1
  store i64 %t85, ptr %l5, !tbaa !24
  br label %bb10
bb15:
  %t87 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t88 = load ptr, ptr %l21, !tbaa !29
  %t89 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t88, i32 0, i32 0
  store { i64, ptr } %t87, ptr %t89, !tbaa !27
  %t90 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t92, i32 0, i32 1
  %t95 = load { i64, ptr }, ptr %t94, !tbaa !27
  %t97 = load ptr, ptr %l0, !tbaa !29
  store ptr %t97, ptr %l49, !tbaa !29
  store { i64, ptr } %t95, ptr %l50, !tbaa !27
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t99, i32 0, i32 3
  %t102 = load i64, ptr %t101, !tbaa !24
  store i64 %t102, ptr %l52, !tbaa !24
  %t103 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t104 = extractvalue { i64, ptr } %t103, 0
  store i64 %t104, ptr %l53, !tbaa !24
  %t105 = icmp sge i64 0, 0
  br i1 %t105, label %bb16, label %bb17
bb16:
  %t107 = load i64, ptr %l52, !tbaa !24
  %t108 = icmp sle i64 0, %t107
  br i1 %t108, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_bcbb7adbd7724539_b819b71564b56465)
  unreachable
bb18:
  %t110 = load i64, ptr %l52, !tbaa !24
  %t111 = load i64, ptr %l53, !tbaa !24
  %t112 = icmp sle i64 %t110, %t111
  br i1 %t112, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_bcbb7adbd7724539_b819b71564b56465)
  unreachable
bb20:
  %t114 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !27
  %t116 = load i64, ptr %l52, !tbaa !24
  %t117 = getelementptr i64, ptr %t115, i64 0
  %t118 = sub i64 %t116, 0
  %t119 = insertvalue { i64, ptr } undef, i64 %t118, 0
  %t120 = insertvalue { i64, ptr } %t119, ptr %t117, 1
  store { i64, ptr } %t120, ptr %l7, !tbaa !27
  %t122 = load i64, ptr %l1, !tbaa !24
  %t124 = call ptr @__olang_region_make_part(ptr %v0)
  %t125 = ptrtoint ptr %t124 to i64
  store i64 %t125, ptr %l59, !tbaa !24
  store i64 %t122, ptr %l60, !tbaa !24
  %t127 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t129 = load i64, ptr %l60, !tbaa !24
  %t130 = extractvalue { i64, ptr } %t127, 0
  %t131 = mul i64 %t130, 8
  %t132 = mul i64 %t129, 8
  %t133 = extractvalue { i64, ptr } %t127, 1
  %t134 = call ptr @__olang_grow_in_place(ptr %t133, i64 %t131, i64 %t132, i64 %t129)
  %t135 = icmp ne ptr %t134, null
  %t136 = select i1 %t135, i64 %t129, i64 0
  %t137 = insertvalue { i64, ptr } undef, i64 %t136, 0
  %t138 = insertvalue { i64, ptr } %t137, ptr %t134, 1
  store { i64, ptr } %t138, ptr %l63, !tbaa !27
  %t139 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t140 = extractvalue { i64, ptr } %t139, 0
  %t142 = icmp ne i64 %t140, 0
  br i1 %t142, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_bcbb7adbd7724539_b819b71564b56465)
  unreachable
bb22:
  %t144 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t144, ptr %l61, !tbaa !27
  br label %bb24
bb23:
  %t145 = load i64, ptr %l60, !tbaa !24
  %t146 = mul i64 %t145, 8
  %t147 = load i64, ptr %l59
  %t148 = inttoptr i64 %t147 to ptr
  %t149 = call ptr @__olang_held_alloc(ptr %t148, i64 %t146)
  %t150 = insertvalue { i64, ptr } undef, i64 %t145, 0
  %t151 = insertvalue { i64, ptr } %t150, ptr %t149, 1
  store { i64, ptr } %t151, ptr %l61, !tbaa !27
  store i64 0, ptr %l66, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb25
bb24:
  %t152 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t153 = extractvalue { i64, ptr } %t152, 0
  %t155 = icmp eq i64 %t153, 0
  br i1 %t155, label %bb31, label %bb32
bb25:
  %t157 = load i64, ptr %l9, !tbaa !24
  %t158 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t160 = extractvalue { i64, ptr } %t158, 0
  %t163 = icmp slt i64 %t157, %t160
  %t165 = xor i1 %t163, true
  br i1 %t165, label %bb26, label %bb27
bb26:
  br label %bb30
bb27:
  br label %bb28
bb28:
  %t167 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t167, ptr %l72, !tbaa !27
  %t168 = load i64, ptr %l9, !tbaa !24
  %t170 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t171 = load ptr, ptr %t170, !tbaa !27
  %t172 = getelementptr i64, ptr %t171, i64 %t168
  %t173 = load i64, ptr %t172, !tbaa !34
  %t175 = load i64, ptr %l66, !tbaa !24
  %t176 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t177 = load ptr, ptr %t176, !tbaa !27
  %t178 = getelementptr i64, ptr %t177, i64 %t175
  store i64 %t173, ptr %t178, !tbaa !34
  %t179 = load i64, ptr %l66, !tbaa !24
  %t180 = add i64 %t179, 1
  store i64 %t180, ptr %l66, !tbaa !24
  br label %bb29
bb29:
  %t181 = load i64, ptr %l9, !tbaa !24
  %t184 = add i64 %t181, 1
  store i64 %t184, ptr %l9, !tbaa !24
  br label %bb25
bb30:
  br label %bb24
bb31:
  store { i64, ptr } zeroinitializer, ptr %l61, !tbaa !27
  br label %bb32
bb32:
  %t186 = load i64, ptr %l59
  %t187 = inttoptr i64 %t186 to ptr
  %t188 = load { i64, ptr }, ptr %l61
  %t189 = extractvalue { i64, ptr } %t188, 1
  %t190 = call ptr @__olang_region_or(ptr %t189, ptr null)
  %t191 = icmp ne ptr %t190, null
  %t192 = select i1 %t191, ptr %t190, ptr null
  call void @__olang_region_settle_in(ptr %t187, ptr %t192)
  %t193 = load ptr, ptr %l49, !tbaa !29
  %t194 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t193, i32 0, i32 1
  %t195 = load { i64, ptr }, ptr %t194, !tbaa !27
  store { i64, ptr } %t195, ptr %l80, !tbaa !27
  %t196 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t197 = load ptr, ptr %l49, !tbaa !29
  %t198 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t197, i32 0, i32 1
  store { i64, ptr } %t196, ptr %t198, !tbaa !27
  %t199 = load { i64, ptr }, ptr %l80
  %t200 = extractvalue { i64, ptr } %t199, 0
  %t201 = extractvalue { i64, ptr } %t199, 1
  call void @__olang_region_release_part(ptr %t201, i64 %t200)
  store { i64, ptr } zeroinitializer, ptr %l80
  br label %ret
ret:
  ret void
}

@std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_Hc1846898e32781cea34c9d6ff027be4e = dso_local alias void (ptr, ptr), ptr @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_Hbbe9f70b7f65eade62601b1ea8bf7ab6
@std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_Hc652335d658547e45580fe8b070ba7da = dso_local alias void (ptr, ptr), ptr @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_Hbbe9f70b7f65eade62601b1ea8bf7ab6
define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fscope_3averAtom_2c_20I64_3e_Hc81a30d19ad900e4ade0bdf80bb746a1(ptr %v0, ptr %a0) noinline cold #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca { i64, ptr }
  %l5 = alloca i64
  %l7 = alloca { i64, ptr }
  %l9 = alloca i64
  %l14 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l38 = alloca i64
  %l44 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %l55 = alloca ptr
  %l56 = alloca { i64, ptr }
  %l58 = alloca i64
  %l59 = alloca i64
  %l65 = alloca i64
  %l66 = alloca i64
  %l67 = alloca { i64, ptr }
  %l69 = alloca { i64, ptr }
  %l72 = alloca i64
  %l78 = alloca { i64, ptr }
  %l86 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp slt i64 %t6, 4
  br i1 %t8, label %bb1, label %bb2
bb1:
  store i64 8, ptr %l14, !tbaa !24
  br label %bb3
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t17 = mul i64 %t15, 2
  store i64 %t17, ptr %l14, !tbaa !24
  br label %bb3
bb3:
  %t19 = load i64, ptr %l14, !tbaa !24
  store i64 %t19, ptr %l1, !tbaa !24
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t20, i32 0, i32 0
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !27
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l21, !tbaa !29
  store { i64, ptr } %t23, ptr %l22, !tbaa !27
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t27, i32 0, i32 3
  %t30 = load i64, ptr %t29, !tbaa !24
  store i64 %t30, ptr %l24, !tbaa !24
  %t31 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  store i64 %t32, ptr %l25, !tbaa !24
  %t33 = icmp sge i64 0, 0
  br i1 %t33, label %bb4, label %bb5
bb4:
  %t35 = load i64, ptr %l24, !tbaa !24
  %t36 = icmp sle i64 0, %t35
  br i1 %t36, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_acc92269b5ffdffb_45a05bc66f31af67)
  unreachable
bb6:
  %t38 = load i64, ptr %l24, !tbaa !24
  %t39 = load i64, ptr %l25, !tbaa !24
  %t40 = icmp sle i64 %t38, %t39
  br i1 %t40, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_acc92269b5ffdffb_45a05bc66f31af67)
  unreachable
bb8:
  %t42 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = load i64, ptr %l24, !tbaa !24
  %t45 = getelementptr %"std/prelude/map:MapEntry.77d571dcfbd22be90356fe294d3b1a19", ptr %t43, i64 0
  %t46 = sub i64 %t44, 0
  %t47 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t45, 1
  store { i64, ptr } %t48, ptr %l3, !tbaa !27
  %t50 = load i64, ptr %l1, !tbaa !24
  %t52 = call ptr @__olang_region_make_part(ptr %v0)
  %t53 = ptrtoint ptr %t52 to i64
  store i64 %t53, ptr %l31, !tbaa !24
  store i64 %t50, ptr %l32, !tbaa !24
  %t55 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t57 = load i64, ptr %l32, !tbaa !24
  %t58 = extractvalue { i64, ptr } %t55, 0
  %t59 = mul i64 %t58, 72
  %t60 = mul i64 %t57, 72
  %t61 = extractvalue { i64, ptr } %t55, 1
  %t62 = call ptr @__olang_grow_in_place(ptr %t61, i64 %t59, i64 %t60, i64 %t57)
  %t63 = icmp ne ptr %t62, null
  %t64 = select i1 %t63, i64 %t57, i64 0
  %t65 = insertvalue { i64, ptr } undef, i64 %t64, 0
  %t66 = insertvalue { i64, ptr } %t65, ptr %t62, 1
  store { i64, ptr } %t66, ptr %l35, !tbaa !27
  %t67 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t68 = extractvalue { i64, ptr } %t67, 0
  %t70 = icmp ne i64 %t68, 0
  br i1 %t70, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_acc92269b5ffdffb_45a05bc66f31af67)
  unreachable
bb10:
  %t72 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t72, ptr %l33, !tbaa !27
  br label %bb12
bb11:
  %t73 = load i64, ptr %l32, !tbaa !24
  %t74 = mul i64 %t73, 72
  %t75 = load i64, ptr %l31
  %t76 = inttoptr i64 %t75 to ptr
  %t77 = call ptr @__olang_held_alloc(ptr %t76, i64 %t74)
  %t78 = insertvalue { i64, ptr } undef, i64 %t73, 0
  %t79 = insertvalue { i64, ptr } %t78, ptr %t77, 1
  store { i64, ptr } %t79, ptr %l33, !tbaa !27
  store i64 0, ptr %l38, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb13
bb12:
  %t80 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t81 = extractvalue { i64, ptr } %t80, 0
  %t83 = icmp eq i64 %t81, 0
  br i1 %t83, label %bb19, label %bb20
bb13:
  %t85 = load i64, ptr %l5, !tbaa !24
  %t86 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t88 = extractvalue { i64, ptr } %t86, 0
  %t91 = icmp slt i64 %t85, %t88
  %t93 = xor i1 %t91, true
  br i1 %t93, label %bb14, label %bb15
bb14:
  br label %bb18
bb15:
  br label %bb16
bb16:
  %t95 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t95, ptr %l44, !tbaa !27
  %t96 = load i64, ptr %l5, !tbaa !24
  %t98 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !27
  %t100 = getelementptr %"std/prelude/map:MapEntry.77d571dcfbd22be90356fe294d3b1a19", ptr %t99, i64 %t96
  %t101 = load %"std/prelude/map:MapEntry.77d571dcfbd22be90356fe294d3b1a19", ptr %t100
  %t103 = load i64, ptr %l38, !tbaa !24
  %t104 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !27
  %t106 = getelementptr %"std/prelude/map:MapEntry.77d571dcfbd22be90356fe294d3b1a19", ptr %t105, i64 %t103
  store %"std/prelude/map:MapEntry.77d571dcfbd22be90356fe294d3b1a19" %t101, ptr %t106
  %t107 = load i64, ptr %l38, !tbaa !24
  %t108 = add i64 %t107, 1
  store i64 %t108, ptr %l38, !tbaa !24
  br label %bb17
bb17:
  %t109 = load i64, ptr %l5, !tbaa !24
  %t112 = add i64 %t109, 1
  store i64 %t112, ptr %l5, !tbaa !24
  br label %bb13
bb18:
  br label %bb12
bb19:
  store { i64, ptr } zeroinitializer, ptr %l33, !tbaa !27
  br label %bb20
bb20:
  %t114 = load i64, ptr %l31
  %t115 = inttoptr i64 %t114 to ptr
  %t116 = load { i64, ptr }, ptr %l33
  %t117 = extractvalue { i64, ptr } %t116, 1
  %t118 = call ptr @__olang_region_or(ptr %t117, ptr null)
  %t119 = icmp ne ptr %t118, null
  %t120 = select i1 %t119, ptr %t118, ptr null
  call void @__olang_region_settle_in(ptr %t115, ptr %t120)
  %t121 = load ptr, ptr %l21, !tbaa !29
  %t122 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t121, i32 0, i32 0
  %t123 = load { i64, ptr }, ptr %t122, !tbaa !27
  store { i64, ptr } %t123, ptr %l52, !tbaa !27
  %t124 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t125 = load ptr, ptr %l21, !tbaa !29
  %t126 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t125, i32 0, i32 0
  store { i64, ptr } %t124, ptr %t126, !tbaa !27
  %t127 = load { i64, ptr }, ptr %l52
  %t128 = extractvalue { i64, ptr } %t127, 0
  %t129 = extractvalue { i64, ptr } %t127, 1
  call void @__olang_region_release_part(ptr %t129, i64 %t128)
  store { i64, ptr } zeroinitializer, ptr %l52
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t130, i32 0, i32 1
  %t133 = load { i64, ptr }, ptr %t132, !tbaa !27
  %t135 = load ptr, ptr %l0, !tbaa !29
  store ptr %t135, ptr %l55, !tbaa !29
  store { i64, ptr } %t133, ptr %l56, !tbaa !27
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t139 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t137, i32 0, i32 3
  %t140 = load i64, ptr %t139, !tbaa !24
  store i64 %t140, ptr %l58, !tbaa !24
  %t141 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t142 = extractvalue { i64, ptr } %t141, 0
  store i64 %t142, ptr %l59, !tbaa !24
  %t143 = icmp sge i64 0, 0
  br i1 %t143, label %bb21, label %bb22
bb21:
  %t145 = load i64, ptr %l58, !tbaa !24
  %t146 = icmp sle i64 0, %t145
  br i1 %t146, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_7a9cc2b07e95d7e_6570d32d640e1c8a)
  unreachable
bb23:
  %t148 = load i64, ptr %l58, !tbaa !24
  %t149 = load i64, ptr %l59, !tbaa !24
  %t150 = icmp sle i64 %t148, %t149
  br i1 %t150, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_7a9cc2b07e95d7e_6570d32d640e1c8a)
  unreachable
bb25:
  %t152 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t153 = load ptr, ptr %t152, !tbaa !27
  %t154 = load i64, ptr %l58, !tbaa !24
  %t155 = getelementptr i64, ptr %t153, i64 0
  %t156 = sub i64 %t154, 0
  %t157 = insertvalue { i64, ptr } undef, i64 %t156, 0
  %t158 = insertvalue { i64, ptr } %t157, ptr %t155, 1
  store { i64, ptr } %t158, ptr %l7, !tbaa !27
  %t160 = load i64, ptr %l1, !tbaa !24
  %t162 = call ptr @__olang_region_make_part(ptr %v0)
  %t163 = ptrtoint ptr %t162 to i64
  store i64 %t163, ptr %l65, !tbaa !24
  store i64 %t160, ptr %l66, !tbaa !24
  %t165 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t167 = load i64, ptr %l66, !tbaa !24
  %t168 = extractvalue { i64, ptr } %t165, 0
  %t169 = mul i64 %t168, 8
  %t170 = mul i64 %t167, 8
  %t171 = extractvalue { i64, ptr } %t165, 1
  %t172 = call ptr @__olang_grow_in_place(ptr %t171, i64 %t169, i64 %t170, i64 %t167)
  %t173 = icmp ne ptr %t172, null
  %t174 = select i1 %t173, i64 %t167, i64 0
  %t175 = insertvalue { i64, ptr } undef, i64 %t174, 0
  %t176 = insertvalue { i64, ptr } %t175, ptr %t172, 1
  store { i64, ptr } %t176, ptr %l69, !tbaa !27
  %t177 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t178 = extractvalue { i64, ptr } %t177, 0
  %t180 = icmp ne i64 %t178, 0
  br i1 %t180, label %bb27, label %bb28
bb26:
  call void @__olang_check_failed(ptr @olang_loc_7a9cc2b07e95d7e_6570d32d640e1c8a)
  unreachable
bb27:
  %t182 = load { i64, ptr }, ptr %l69, !tbaa !27
  store { i64, ptr } %t182, ptr %l67, !tbaa !27
  br label %bb29
bb28:
  %t183 = load i64, ptr %l66, !tbaa !24
  %t184 = mul i64 %t183, 8
  %t185 = load i64, ptr %l65
  %t186 = inttoptr i64 %t185 to ptr
  %t187 = call ptr @__olang_held_alloc(ptr %t186, i64 %t184)
  %t188 = insertvalue { i64, ptr } undef, i64 %t183, 0
  %t189 = insertvalue { i64, ptr } %t188, ptr %t187, 1
  store { i64, ptr } %t189, ptr %l67, !tbaa !27
  store i64 0, ptr %l72, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb30
bb29:
  %t190 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t191 = extractvalue { i64, ptr } %t190, 0
  %t193 = icmp eq i64 %t191, 0
  br i1 %t193, label %bb36, label %bb37
bb30:
  %t195 = load i64, ptr %l9, !tbaa !24
  %t196 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t198 = extractvalue { i64, ptr } %t196, 0
  %t201 = icmp slt i64 %t195, %t198
  %t203 = xor i1 %t201, true
  br i1 %t203, label %bb31, label %bb32
bb31:
  br label %bb35
bb32:
  br label %bb33
bb33:
  %t205 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t205, ptr %l78, !tbaa !27
  %t206 = load i64, ptr %l9, !tbaa !24
  %t208 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t209 = load ptr, ptr %t208, !tbaa !27
  %t210 = getelementptr i64, ptr %t209, i64 %t206
  %t211 = load i64, ptr %t210, !tbaa !34
  %t213 = load i64, ptr %l72, !tbaa !24
  %t214 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t215 = load ptr, ptr %t214, !tbaa !27
  %t216 = getelementptr i64, ptr %t215, i64 %t213
  store i64 %t211, ptr %t216, !tbaa !34
  %t217 = load i64, ptr %l72, !tbaa !24
  %t218 = add i64 %t217, 1
  store i64 %t218, ptr %l72, !tbaa !24
  br label %bb34
bb34:
  %t219 = load i64, ptr %l9, !tbaa !24
  %t222 = add i64 %t219, 1
  store i64 %t222, ptr %l9, !tbaa !24
  br label %bb30
bb35:
  br label %bb29
bb36:
  store { i64, ptr } zeroinitializer, ptr %l67, !tbaa !27
  br label %bb37
bb37:
  %t224 = load i64, ptr %l65
  %t225 = inttoptr i64 %t224 to ptr
  %t226 = load { i64, ptr }, ptr %l67
  %t227 = extractvalue { i64, ptr } %t226, 1
  %t228 = call ptr @__olang_region_or(ptr %t227, ptr null)
  %t229 = icmp ne ptr %t228, null
  %t230 = select i1 %t229, ptr %t228, ptr null
  call void @__olang_region_settle_in(ptr %t225, ptr %t230)
  %t231 = load ptr, ptr %l55, !tbaa !29
  %t232 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t231, i32 0, i32 1
  %t233 = load { i64, ptr }, ptr %t232, !tbaa !27
  store { i64, ptr } %t233, ptr %l86, !tbaa !27
  %t234 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t235 = load ptr, ptr %l55, !tbaa !29
  %t236 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t235, i32 0, i32 1
  store { i64, ptr } %t234, ptr %t236, !tbaa !27
  %t237 = load { i64, ptr }, ptr %l86
  %t238 = extractvalue { i64, ptr } %t237, 0
  %t239 = extractvalue { i64, ptr } %t237, 1
  call void @__olang_region_release_part(ptr %t239, i64 %t238)
  store { i64, ptr } zeroinitializer, ptr %l86
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Array_3_H10dc57cef28d9cf434585426eb2f4390(ptr %v0, ptr %a0) noinline cold #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca { i64, ptr }
  %l5 = alloca i64
  %l7 = alloca { i64, ptr }
  %l9 = alloca i64
  %l14 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l31 = alloca i64
  %l33 = alloca { i64, ptr }
  %l34 = alloca i64
  %l40 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l49 = alloca i64
  %l50 = alloca i64
  %l54 = alloca ptr
  %l55 = alloca { i64, ptr }
  %l57 = alloca i64
  %l58 = alloca i64
  %l64 = alloca i64
  %l65 = alloca i64
  %l66 = alloca { i64, ptr }
  %l68 = alloca { i64, ptr }
  %l71 = alloca i64
  %l77 = alloca { i64, ptr }
  %l85 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp slt i64 %t6, 4
  br i1 %t8, label %bb1, label %bb2
bb1:
  store i64 8, ptr %l14, !tbaa !24
  br label %bb3
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t17 = mul i64 %t15, 2
  store i64 %t17, ptr %l14, !tbaa !24
  br label %bb3
bb3:
  %t19 = load i64, ptr %l14, !tbaa !24
  store i64 %t19, ptr %l1, !tbaa !24
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t20, i32 0, i32 0
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !27
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l21, !tbaa !29
  store { i64, ptr } %t23, ptr %l22, !tbaa !27
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t27, i32 0, i32 3
  %t30 = load i64, ptr %t29, !tbaa !24
  store i64 %t30, ptr %l24, !tbaa !24
  %t31 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  store i64 %t32, ptr %l25, !tbaa !24
  %t33 = icmp sge i64 0, 0
  br i1 %t33, label %bb4, label %bb5
bb4:
  %t35 = load i64, ptr %l24, !tbaa !24
  %t36 = icmp sle i64 0, %t35
  br i1 %t36, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_5ad7f35e69ffe522_7a613f9347dd1ffe)
  unreachable
bb6:
  %t38 = load i64, ptr %l24, !tbaa !24
  %t39 = load i64, ptr %l25, !tbaa !24
  %t40 = icmp sle i64 %t38, %t39
  br i1 %t40, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_5ad7f35e69ffe522_7a613f9347dd1ffe)
  unreachable
bb8:
  %t42 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = load i64, ptr %l24, !tbaa !24
  %t45 = getelementptr %"std/prelude/map:MapEntry.2a60b5fdde847676acc31582b777d2c3", ptr %t43, i64 0
  %t46 = sub i64 %t44, 0
  %t47 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t45, 1
  store { i64, ptr } %t48, ptr %l3, !tbaa !27
  %t50 = load i64, ptr %l1, !tbaa !24
  %t52 = call ptr @__olang_region_make_part(ptr %v0)
  %t53 = ptrtoint ptr %t52 to i64
  store i64 %t53, ptr %l31, !tbaa !24
  %t56 = mul i64 %t50, 24
  %t57 = load i64, ptr %l31
  %t58 = inttoptr i64 %t57 to ptr
  %t59 = call ptr @__olang_scope_alloc_zeroed(ptr %t58, i64 %t56)
  %t60 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t61 = insertvalue { i64, ptr } %t60, ptr %t59, 1
  store { i64, ptr } %t61, ptr %l33, !tbaa !27
  store i64 0, ptr %l34, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_5ad7f35e69ffe522_7a613f9347dd1ffe)
  unreachable
bb10:
  %t62 = load i64, ptr %l5, !tbaa !24
  %t63 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t63, 0
  %t68 = icmp slt i64 %t62, %t65
  %t70 = xor i1 %t68, true
  br i1 %t70, label %bb11, label %bb12
bb11:
  br label %bb15
bb12:
  br label %bb13
bb13:
  %t72 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t72, ptr %l40, !tbaa !27
  %t73 = load i64, ptr %l5, !tbaa !24
  %t75 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = getelementptr %"std/prelude/map:MapEntry.2a60b5fdde847676acc31582b777d2c3", ptr %t76, i64 %t73
  %t78 = load %"std/prelude/map:MapEntry.2a60b5fdde847676acc31582b777d2c3", ptr %t77
  store %"std/prelude/map:MapEntry.2a60b5fdde847676acc31582b777d2c3" zeroinitializer, ptr %t77
  %t80 = load i64, ptr %l34, !tbaa !24
  %t81 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !27
  %t83 = getelementptr %"std/prelude/map:MapEntry.2a60b5fdde847676acc31582b777d2c3", ptr %t82, i64 %t80
  store %"std/prelude/map:MapEntry.2a60b5fdde847676acc31582b777d2c3" %t78, ptr %t83
  %t84 = load i64, ptr %l34, !tbaa !24
  %t85 = add i64 %t84, 1
  store i64 %t85, ptr %l34, !tbaa !24
  br label %bb14
bb14:
  %t86 = load i64, ptr %l5, !tbaa !24
  %t89 = add i64 %t86, 1
  store i64 %t89, ptr %l5, !tbaa !24
  br label %bb10
bb15:
  %t91 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t92 = extractvalue { i64, ptr } %t91, 0
  %t94 = icmp eq i64 %t92, 0
  br i1 %t94, label %bb16, label %bb17
bb16:
  store { i64, ptr } zeroinitializer, ptr %l33, !tbaa !27
  br label %bb17
bb17:
  %t96 = load i64, ptr %l31
  %t97 = inttoptr i64 %t96 to ptr
  %t98 = load { i64, ptr }, ptr %l33
  %t99 = extractvalue { i64, ptr } %t98, 1
  %t100 = call ptr @__olang_region_or(ptr %t99, ptr null)
  %t101 = icmp ne ptr %t100, null
  %t102 = select i1 %t101, ptr %t100, ptr null
  call void @__olang_region_settle_in(ptr %t97, ptr %t102)
  %t103 = load ptr, ptr %l21, !tbaa !29
  %t104 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t103, i32 0, i32 0
  %t105 = load { i64, ptr }, ptr %t104, !tbaa !27
  store { i64, ptr } %t105, ptr %l48, !tbaa !27
  %t106 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t107 = load ptr, ptr %l21, !tbaa !29
  %t108 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t107, i32 0, i32 0
  store { i64, ptr } %t106, ptr %t108, !tbaa !27
  %t109 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t110 = extractvalue { i64, ptr } %t109, 0
  store i64 %t110, ptr %l49, !tbaa !24
  store i64 0, ptr %l50, !tbaa !24
  br label %bb18
bb18:
  %t111 = load i64, ptr %l50, !tbaa !24
  %t112 = load i64, ptr %l49, !tbaa !24
  %t113 = icmp slt i64 %t111, %t112
  br i1 %t113, label %bb19, label %bb20
bb19:
  %t115 = load i64, ptr %l50, !tbaa !24
  %t116 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t117 = load ptr, ptr %t116, !tbaa !27
  %t118 = getelementptr %"std/prelude/map:MapEntry.2a60b5fdde847676acc31582b777d2c3", ptr %t117, i64 %t115
  %t119 = getelementptr %"std/prelude/map:MapEntry.2a60b5fdde847676acc31582b777d2c3", ptr %t118, i32 0, i32 1
  %t120 = load { i64, ptr }, ptr %t119
  %t121 = extractvalue { i64, ptr } %t120, 0
  %t122 = extractvalue { i64, ptr } %t120, 1
  call void @__olang_region_release_part(ptr %t122, i64 %t121)
  store { i64, ptr } zeroinitializer, ptr %t119
  %t123 = load i64, ptr %l50, !tbaa !24
  %t124 = add i64 %t123, 1
  store i64 %t124, ptr %l50, !tbaa !24
  br label %bb18
bb20:
  %t125 = load { i64, ptr }, ptr %l48
  %t126 = extractvalue { i64, ptr } %t125, 0
  %t127 = extractvalue { i64, ptr } %t125, 1
  call void @__olang_region_release_part(ptr %t127, i64 %t126)
  store { i64, ptr } zeroinitializer, ptr %l48
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t130 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t128, i32 0, i32 1
  %t131 = load { i64, ptr }, ptr %t130, !tbaa !27
  %t133 = load ptr, ptr %l0, !tbaa !29
  store ptr %t133, ptr %l54, !tbaa !29
  store { i64, ptr } %t131, ptr %l55, !tbaa !27
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t137 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t135, i32 0, i32 3
  %t138 = load i64, ptr %t137, !tbaa !24
  store i64 %t138, ptr %l57, !tbaa !24
  %t139 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t140 = extractvalue { i64, ptr } %t139, 0
  store i64 %t140, ptr %l58, !tbaa !24
  %t141 = icmp sge i64 0, 0
  br i1 %t141, label %bb21, label %bb22
bb21:
  %t143 = load i64, ptr %l57, !tbaa !24
  %t144 = icmp sle i64 0, %t143
  br i1 %t144, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_775db944194a729f_1f8095d1f5f3a27b)
  unreachable
bb23:
  %t146 = load i64, ptr %l57, !tbaa !24
  %t147 = load i64, ptr %l58, !tbaa !24
  %t148 = icmp sle i64 %t146, %t147
  br i1 %t148, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_775db944194a729f_1f8095d1f5f3a27b)
  unreachable
bb25:
  %t150 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t151 = load ptr, ptr %t150, !tbaa !27
  %t152 = load i64, ptr %l57, !tbaa !24
  %t153 = getelementptr i64, ptr %t151, i64 0
  %t154 = sub i64 %t152, 0
  %t155 = insertvalue { i64, ptr } undef, i64 %t154, 0
  %t156 = insertvalue { i64, ptr } %t155, ptr %t153, 1
  store { i64, ptr } %t156, ptr %l7, !tbaa !27
  %t158 = load i64, ptr %l1, !tbaa !24
  %t160 = call ptr @__olang_region_make_part(ptr %v0)
  %t161 = ptrtoint ptr %t160 to i64
  store i64 %t161, ptr %l64, !tbaa !24
  store i64 %t158, ptr %l65, !tbaa !24
  %t163 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t165 = load i64, ptr %l65, !tbaa !24
  %t166 = extractvalue { i64, ptr } %t163, 0
  %t167 = mul i64 %t166, 8
  %t168 = mul i64 %t165, 8
  %t169 = extractvalue { i64, ptr } %t163, 1
  %t170 = call ptr @__olang_grow_in_place(ptr %t169, i64 %t167, i64 %t168, i64 %t165)
  %t171 = icmp ne ptr %t170, null
  %t172 = select i1 %t171, i64 %t165, i64 0
  %t173 = insertvalue { i64, ptr } undef, i64 %t172, 0
  %t174 = insertvalue { i64, ptr } %t173, ptr %t170, 1
  store { i64, ptr } %t174, ptr %l68, !tbaa !27
  %t175 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t176 = extractvalue { i64, ptr } %t175, 0
  %t178 = icmp ne i64 %t176, 0
  br i1 %t178, label %bb27, label %bb28
bb26:
  call void @__olang_check_failed(ptr @olang_loc_775db944194a729f_1f8095d1f5f3a27b)
  unreachable
bb27:
  %t180 = load { i64, ptr }, ptr %l68, !tbaa !27
  store { i64, ptr } %t180, ptr %l66, !tbaa !27
  br label %bb29
bb28:
  %t181 = load i64, ptr %l65, !tbaa !24
  %t182 = mul i64 %t181, 8
  %t183 = load i64, ptr %l64
  %t184 = inttoptr i64 %t183 to ptr
  %t185 = call ptr @__olang_held_alloc(ptr %t184, i64 %t182)
  %t186 = insertvalue { i64, ptr } undef, i64 %t181, 0
  %t187 = insertvalue { i64, ptr } %t186, ptr %t185, 1
  store { i64, ptr } %t187, ptr %l66, !tbaa !27
  store i64 0, ptr %l71, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb30
bb29:
  %t188 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t189 = extractvalue { i64, ptr } %t188, 0
  %t191 = icmp eq i64 %t189, 0
  br i1 %t191, label %bb36, label %bb37
bb30:
  %t193 = load i64, ptr %l9, !tbaa !24
  %t194 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t196 = extractvalue { i64, ptr } %t194, 0
  %t199 = icmp slt i64 %t193, %t196
  %t201 = xor i1 %t199, true
  br i1 %t201, label %bb31, label %bb32
bb31:
  br label %bb35
bb32:
  br label %bb33
bb33:
  %t203 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t203, ptr %l77, !tbaa !27
  %t204 = load i64, ptr %l9, !tbaa !24
  %t206 = getelementptr { i64, ptr }, ptr %l77, i32 0, i32 1
  %t207 = load ptr, ptr %t206, !tbaa !27
  %t208 = getelementptr i64, ptr %t207, i64 %t204
  %t209 = load i64, ptr %t208, !tbaa !34
  %t211 = load i64, ptr %l71, !tbaa !24
  %t212 = getelementptr { i64, ptr }, ptr %l66, i32 0, i32 1
  %t213 = load ptr, ptr %t212, !tbaa !27
  %t214 = getelementptr i64, ptr %t213, i64 %t211
  store i64 %t209, ptr %t214, !tbaa !34
  %t215 = load i64, ptr %l71, !tbaa !24
  %t216 = add i64 %t215, 1
  store i64 %t216, ptr %l71, !tbaa !24
  br label %bb34
bb34:
  %t217 = load i64, ptr %l9, !tbaa !24
  %t220 = add i64 %t217, 1
  store i64 %t220, ptr %l9, !tbaa !24
  br label %bb30
bb35:
  br label %bb29
bb36:
  store { i64, ptr } zeroinitializer, ptr %l66, !tbaa !27
  br label %bb37
bb37:
  %t222 = load i64, ptr %l64
  %t223 = inttoptr i64 %t222 to ptr
  %t224 = load { i64, ptr }, ptr %l66
  %t225 = extractvalue { i64, ptr } %t224, 1
  %t226 = call ptr @__olang_region_or(ptr %t225, ptr null)
  %t227 = icmp ne ptr %t226, null
  %t228 = select i1 %t227, ptr %t226, ptr null
  call void @__olang_region_settle_in(ptr %t223, ptr %t228)
  %t229 = load ptr, ptr %l54, !tbaa !29
  %t230 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t229, i32 0, i32 1
  %t231 = load { i64, ptr }, ptr %t230, !tbaa !27
  store { i64, ptr } %t231, ptr %l85, !tbaa !27
  %t232 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t233 = load ptr, ptr %l54, !tbaa !29
  %t234 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t233, i32 0, i32 1
  store { i64, ptr } %t232, ptr %t234, !tbaa !27
  %t235 = load { i64, ptr }, ptr %l85
  %t236 = extractvalue { i64, ptr } %t235, 0
  %t237 = extractvalue { i64, ptr } %t235, 1
  call void @__olang_region_release_part(ptr %t237, i64 %t236)
  store { i64, ptr } zeroinitializer, ptr %l85
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Array_3_H6f3fa278e197f7d8208807c7c3df5245(ptr %v0, ptr %a0, i32 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i64
  %l13 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l19 = alloca i64
  %l31 = alloca ptr
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca { i64, ptr }
  %l35 = alloca i64
  %l36 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %t21 = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1, i32 0, i32 2
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp eq i64 %t6, 0
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l9, !tbaa !29
  %t11 = call ptr @__olang_region_make_part(ptr %v0)
  %t12 = ptrtoint ptr %t11 to i64
  store i64 %t12, ptr %l10, !tbaa !24
  %t13 = icmp sge i64 8, 0
  br i1 %t13, label %bb3, label %bb4
bb2:
  br label %bb9
bb3:
  %t15 = icmp sle i64 8, 1152921504606846975
  br i1 %t15, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_1bfebcd902ff6bfb_534ec135c8ab703f)
  unreachable
bb5:
  %t17 = mul i64 8, 8
  %t18 = load i64, ptr %l10
  %t19 = inttoptr i64 %t18 to ptr
  %t20 = call ptr @__olang_held_alloc(ptr %t19, i64 %t17)
  store i64 0, ptr %t21
  br label %fill.22
fill.22:
  %t25 = load i64, ptr %t21
  %t26 = icmp slt i64 %t25, 8
  br i1 %t26, label %fillb.23, label %filld.24
fillb.23:
  %t27 = getelementptr i64, ptr %t20, i64 %t25
  store i64 -1, ptr %t27
  %t28 = add i64 %t25, 1
  store i64 %t28, ptr %t21
  br label %fill.22
filld.24:
  %t29 = insertvalue { i64, ptr } undef, i64 8, 0
  %t30 = insertvalue { i64, ptr } %t29, ptr %t20, 1
  store { i64, ptr } %t30, ptr %l13, !tbaa !27
  %t31 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  %t34 = icmp eq i64 %t32, 0
  br i1 %t34, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_1bfebcd902ff6bfb_534ec135c8ab703f)
  unreachable
bb7:
  store { i64, ptr } zeroinitializer, ptr %l13, !tbaa !27
  br label %bb8
bb8:
  %t36 = load i64, ptr %l10
  %t37 = inttoptr i64 %t36 to ptr
  %t38 = load { i64, ptr }, ptr %l13
  %t39 = extractvalue { i64, ptr } %t38, 1
  %t40 = call ptr @__olang_region_or(ptr %t39, ptr null)
  %t41 = icmp ne ptr %t40, null
  %t42 = select i1 %t41, ptr %t40, ptr null
  call void @__olang_region_settle_in(ptr %t37, ptr %t42)
  %t43 = load ptr, ptr %l9, !tbaa !29
  %t44 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t43, i32 0, i32 2
  %t45 = load { i64, ptr }, ptr %t44, !tbaa !27
  store { i64, ptr } %t45, ptr %l16, !tbaa !27
  %t46 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t47 = load ptr, ptr %l9, !tbaa !29
  %t48 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t47, i32 0, i32 2
  store { i64, ptr } %t46, ptr %t48, !tbaa !27
  %t49 = load { i64, ptr }, ptr %l16
  %t50 = extractvalue { i64, ptr } %t49, 0
  %t51 = extractvalue { i64, ptr } %t49, 1
  call void @__olang_region_release_part(ptr %t51, i64 %t50)
  store { i64, ptr } zeroinitializer, ptr %l16
  br label %bb9
bb9:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load i32, ptr %l1, !tbaa !23
  %t56 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H0ad23e78b2b593286f94a0de5701989f(ptr %v0, ptr %t52, i32 %t53)
  store i64 %t56, ptr %l19
  br label %bb10
bb10:
  %t57 = load i64, ptr %l19, !tbaa !24
  store i64 %t57, ptr %l3, !tbaa !24
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load i64, ptr %l3, !tbaa !24
  %t61 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t58, i32 0, i32 2
  %t63 = getelementptr { i64, ptr }, ptr %t61, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !27
  %t65 = getelementptr i64, ptr %t64, i64 %t59
  %t66 = load i64, ptr %t65, !tbaa !34
  store i64 %t66, ptr %l4, !tbaa !24
  br label %bb11
bb11:
  %t68 = load i64, ptr %l4, !tbaa !24
  %t70 = icmp sge i64 %t68, 0
  %t72 = xor i1 %t70, true
  br i1 %t72, label %bb12, label %bb13
bb12:
  br label %bb21
bb13:
  br label %bb14
bb14:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load i64, ptr %l4, !tbaa !24
  %t77 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t74, i32 0, i32 0
  %t79 = getelementptr { i64, ptr }, ptr %t77, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = getelementptr %"std/prelude/map:MapEntry.2a60b5fdde847676acc31582b777d2c3", ptr %t80, i64 %t75
  %t82 = getelementptr %"std/prelude/map:MapEntry.2a60b5fdde847676acc31582b777d2c3", ptr %t81, i32 0, i32 0
  %t83 = load i32, ptr %t82, !tbaa !23
  %t84 = load i32, ptr %l1, !tbaa !23
  %t87 = icmp eq i32 %t83, %t84
  br i1 %t87, label %bb15, label %bb16
bb15:
  %t89 = load ptr, ptr %l0, !tbaa !29
  store ptr %t89, ptr %l31, !tbaa !29
  %t90 = load i64, ptr %l4, !tbaa !24
  store i64 %t90, ptr %l32, !tbaa !24
  %t91 = call ptr @__olang_region_make_part(ptr %v0)
  %t92 = ptrtoint ptr %t91 to i64
  store i64 %t92, ptr %l33, !tbaa !24
  %t93 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t93, ptr %l34, !tbaa !27
  %t94 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t95 = extractvalue { i64, ptr } %t94, 0
  store i64 %t95, ptr %l35, !tbaa !24
  %t96 = load i64, ptr %l35, !tbaa !24
  %t97 = mul i64 %t96, 8
  %t98 = load i64, ptr %l33
  %t99 = inttoptr i64 %t98 to ptr
  %t100 = call ptr @__olang_held_alloc(ptr %t99, i64 %t97)
  %t101 = insertvalue { i64, ptr } undef, i64 %t96, 0
  %t102 = insertvalue { i64, ptr } %t101, ptr %t100, 1
  store { i64, ptr } %t102, ptr %l36, !tbaa !27
  %t103 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t104 = load ptr, ptr %t103, !tbaa !27
  %t105 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !27
  %t107 = load i64, ptr %l35, !tbaa !24
  %t108 = mul i64 %t107, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t104, ptr %t106, i64 %t108, i1 false)
  %t109 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t110 = extractvalue { i64, ptr } %t109, 0
  %t112 = icmp eq i64 %t110, 0
  br i1 %t112, label %bb17, label %bb18
bb16:
  br label %bb19
bb17:
  store { i64, ptr } zeroinitializer, ptr %l36, !tbaa !27
  br label %bb18
bb18:
  %t114 = load i64, ptr %l33
  %t115 = inttoptr i64 %t114 to ptr
  %t116 = load { i64, ptr }, ptr %l36
  %t117 = extractvalue { i64, ptr } %t116, 1
  %t118 = call ptr @__olang_region_or(ptr %t117, ptr null)
  %t119 = icmp ne ptr %t118, null
  %t120 = select i1 %t119, ptr %t118, ptr null
  call void @__olang_region_settle_in(ptr %t115, ptr %t120)
  %t121 = load ptr, ptr %l31, !tbaa !29
  %t122 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t121, i32 0, i32 0
  %t123 = load i64, ptr %l32, !tbaa !24
  %t124 = getelementptr { i64, ptr }, ptr %t122, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !27
  %t126 = getelementptr %"std/prelude/map:MapEntry.2a60b5fdde847676acc31582b777d2c3", ptr %t125, i64 %t123
  %t127 = getelementptr %"std/prelude/map:MapEntry.2a60b5fdde847676acc31582b777d2c3", ptr %t126, i32 0, i32 1
  %t128 = load { i64, ptr }, ptr %t127, !tbaa !27
  store { i64, ptr } %t128, ptr %l39, !tbaa !27
  %t129 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t130 = load ptr, ptr %l31, !tbaa !29
  %t131 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t130, i32 0, i32 0
  %t132 = load i64, ptr %l32, !tbaa !24
  %t133 = getelementptr { i64, ptr }, ptr %t131, i32 0, i32 1
  %t134 = load ptr, ptr %t133, !tbaa !27
  %t135 = getelementptr %"std/prelude/map:MapEntry.2a60b5fdde847676acc31582b777d2c3", ptr %t134, i64 %t132
  %t136 = getelementptr %"std/prelude/map:MapEntry.2a60b5fdde847676acc31582b777d2c3", ptr %t135, i32 0, i32 1
  store { i64, ptr } %t129, ptr %t136, !tbaa !27
  %t137 = load { i64, ptr }, ptr %l39
  %t138 = extractvalue { i64, ptr } %t137, 0
  %t139 = extractvalue { i64, ptr } %t137, 1
  call void @__olang_region_release_part(ptr %t139, i64 %t138)
  store { i64, ptr } zeroinitializer, ptr %l39
  br label %ret
bb19:
  br label %bb20
bb20:
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t141 = load i64, ptr %l4, !tbaa !24
  %t143 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t140, i32 0, i32 1
  %t145 = getelementptr { i64, ptr }, ptr %t143, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !27
  %t147 = getelementptr i64, ptr %t146, i64 %t141
  %t148 = load i64, ptr %t147, !tbaa !34
  store i64 %t148, ptr %l4, !tbaa !24
  br label %bb11
bb21:
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t151 = load i64, ptr %l3, !tbaa !24
  %t152 = load i32, ptr %l1, !tbaa !23
  %t153 = load { i64, ptr }, ptr %l2, !tbaa !27
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Array_3_H78beb88f07a363e6103d3b1ab418f0bc(ptr %v0, ptr %t150, i64 %t151, i32 %t152, { i64, ptr } %t153)
  br label %bb22
bb22:
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Array_3_Hee16dfd5edf49b5442bcfbfeef10930e(ptr %v0, ptr %a0) noinline cold #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca { i64, ptr }
  %l5 = alloca i64
  %l7 = alloca { i64, ptr }
  %l9 = alloca i64
  %l14 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l31 = alloca i64
  %l33 = alloca { i64, ptr }
  %l34 = alloca i64
  %l40 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l51 = alloca ptr
  %l52 = alloca { i64, ptr }
  %l54 = alloca i64
  %l55 = alloca i64
  %l61 = alloca i64
  %l62 = alloca i64
  %l63 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %l68 = alloca i64
  %l74 = alloca { i64, ptr }
  %l82 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp slt i64 %t6, 4
  br i1 %t8, label %bb1, label %bb2
bb1:
  store i64 8, ptr %l14, !tbaa !24
  br label %bb3
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t17 = mul i64 %t15, 2
  store i64 %t17, ptr %l14, !tbaa !24
  br label %bb3
bb3:
  %t19 = load i64, ptr %l14, !tbaa !24
  store i64 %t19, ptr %l1, !tbaa !24
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t20, i32 0, i32 0
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !27
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l21, !tbaa !29
  store { i64, ptr } %t23, ptr %l22, !tbaa !27
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t27, i32 0, i32 3
  %t30 = load i64, ptr %t29, !tbaa !24
  store i64 %t30, ptr %l24, !tbaa !24
  %t31 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  store i64 %t32, ptr %l25, !tbaa !24
  %t33 = icmp sge i64 0, 0
  br i1 %t33, label %bb4, label %bb5
bb4:
  %t35 = load i64, ptr %l24, !tbaa !24
  %t36 = icmp sle i64 0, %t35
  br i1 %t36, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_186fa87127077de0_2ccfdff69ff8a78c)
  unreachable
bb6:
  %t38 = load i64, ptr %l24, !tbaa !24
  %t39 = load i64, ptr %l25, !tbaa !24
  %t40 = icmp sle i64 %t38, %t39
  br i1 %t40, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_186fa87127077de0_2ccfdff69ff8a78c)
  unreachable
bb8:
  %t42 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = load i64, ptr %l24, !tbaa !24
  %t45 = getelementptr %"std/prelude/map:MapEntry.2a60b5fdde847676acc31582b777d2c3", ptr %t43, i64 0
  %t46 = sub i64 %t44, 0
  %t47 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t45, 1
  store { i64, ptr } %t48, ptr %l3, !tbaa !27
  %t50 = load i64, ptr %l1, !tbaa !24
  %t52 = call ptr @__olang_region_make_part(ptr %v0)
  %t53 = ptrtoint ptr %t52 to i64
  store i64 %t53, ptr %l31, !tbaa !24
  %t56 = mul i64 %t50, 24
  %t57 = load i64, ptr %l31
  %t58 = inttoptr i64 %t57 to ptr
  %t59 = call ptr @__olang_scope_alloc_zeroed(ptr %t58, i64 %t56)
  %t60 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t61 = insertvalue { i64, ptr } %t60, ptr %t59, 1
  store { i64, ptr } %t61, ptr %l33, !tbaa !27
  store i64 0, ptr %l34, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_186fa87127077de0_2ccfdff69ff8a78c)
  unreachable
bb10:
  %t62 = load i64, ptr %l5, !tbaa !24
  %t63 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t63, 0
  %t68 = icmp slt i64 %t62, %t65
  %t70 = xor i1 %t68, true
  br i1 %t70, label %bb11, label %bb12
bb11:
  br label %bb15
bb12:
  br label %bb13
bb13:
  %t72 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t72, ptr %l40, !tbaa !27
  %t73 = load i64, ptr %l5, !tbaa !24
  %t75 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = getelementptr %"std/prelude/map:MapEntry.2a60b5fdde847676acc31582b777d2c3", ptr %t76, i64 %t73
  %t78 = load %"std/prelude/map:MapEntry.2a60b5fdde847676acc31582b777d2c3", ptr %t77
  store %"std/prelude/map:MapEntry.2a60b5fdde847676acc31582b777d2c3" zeroinitializer, ptr %t77
  %t80 = load i64, ptr %l34, !tbaa !24
  %t81 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !27
  %t83 = getelementptr %"std/prelude/map:MapEntry.2a60b5fdde847676acc31582b777d2c3", ptr %t82, i64 %t80
  store %"std/prelude/map:MapEntry.2a60b5fdde847676acc31582b777d2c3" %t78, ptr %t83
  %t84 = load i64, ptr %l34, !tbaa !24
  %t85 = add i64 %t84, 1
  store i64 %t85, ptr %l34, !tbaa !24
  br label %bb14
bb14:
  %t86 = load i64, ptr %l5, !tbaa !24
  %t89 = add i64 %t86, 1
  store i64 %t89, ptr %l5, !tbaa !24
  br label %bb10
bb15:
  %t91 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t92 = extractvalue { i64, ptr } %t91, 0
  %t94 = icmp eq i64 %t92, 0
  br i1 %t94, label %bb16, label %bb17
bb16:
  store { i64, ptr } zeroinitializer, ptr %l33, !tbaa !27
  br label %bb17
bb17:
  %t96 = load i64, ptr %l31
  %t97 = inttoptr i64 %t96 to ptr
  %t98 = load { i64, ptr }, ptr %l33
  %t99 = extractvalue { i64, ptr } %t98, 1
  %t100 = call ptr @__olang_region_or(ptr %t99, ptr null)
  %t101 = icmp ne ptr %t100, null
  %t102 = select i1 %t101, ptr %t100, ptr null
  call void @__olang_region_settle_in(ptr %t97, ptr %t102)
  %t103 = load ptr, ptr %l21, !tbaa !29
  %t104 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t103, i32 0, i32 0
  %t105 = load { i64, ptr }, ptr %t104, !tbaa !27
  store { i64, ptr } %t105, ptr %l48, !tbaa !27
  %t106 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t107 = load ptr, ptr %l21, !tbaa !29
  %t108 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t107, i32 0, i32 0
  store { i64, ptr } %t106, ptr %t108, !tbaa !27
  %t109 = load { i64, ptr }, ptr %l48
  %t110 = extractvalue { i64, ptr } %t109, 0
  %t111 = extractvalue { i64, ptr } %t109, 1
  call void @__olang_region_release_part(ptr %t111, i64 %t110)
  store { i64, ptr } zeroinitializer, ptr %l48
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t114 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t112, i32 0, i32 1
  %t115 = load { i64, ptr }, ptr %t114, !tbaa !27
  %t117 = load ptr, ptr %l0, !tbaa !29
  store ptr %t117, ptr %l51, !tbaa !29
  store { i64, ptr } %t115, ptr %l52, !tbaa !27
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t121 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t119, i32 0, i32 3
  %t122 = load i64, ptr %t121, !tbaa !24
  store i64 %t122, ptr %l54, !tbaa !24
  %t123 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t124 = extractvalue { i64, ptr } %t123, 0
  store i64 %t124, ptr %l55, !tbaa !24
  %t125 = icmp sge i64 0, 0
  br i1 %t125, label %bb18, label %bb19
bb18:
  %t127 = load i64, ptr %l54, !tbaa !24
  %t128 = icmp sle i64 0, %t127
  br i1 %t128, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_e00ef57679a22b3d_1b372a33b8274bb9)
  unreachable
bb20:
  %t130 = load i64, ptr %l54, !tbaa !24
  %t131 = load i64, ptr %l55, !tbaa !24
  %t132 = icmp sle i64 %t130, %t131
  br i1 %t132, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_e00ef57679a22b3d_1b372a33b8274bb9)
  unreachable
bb22:
  %t134 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t135 = load ptr, ptr %t134, !tbaa !27
  %t136 = load i64, ptr %l54, !tbaa !24
  %t137 = getelementptr i64, ptr %t135, i64 0
  %t138 = sub i64 %t136, 0
  %t139 = insertvalue { i64, ptr } undef, i64 %t138, 0
  %t140 = insertvalue { i64, ptr } %t139, ptr %t137, 1
  store { i64, ptr } %t140, ptr %l7, !tbaa !27
  %t142 = load i64, ptr %l1, !tbaa !24
  %t144 = call ptr @__olang_region_make_part(ptr %v0)
  %t145 = ptrtoint ptr %t144 to i64
  store i64 %t145, ptr %l61, !tbaa !24
  store i64 %t142, ptr %l62, !tbaa !24
  %t147 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t149 = load i64, ptr %l62, !tbaa !24
  %t150 = extractvalue { i64, ptr } %t147, 0
  %t151 = mul i64 %t150, 8
  %t152 = mul i64 %t149, 8
  %t153 = extractvalue { i64, ptr } %t147, 1
  %t154 = call ptr @__olang_grow_in_place(ptr %t153, i64 %t151, i64 %t152, i64 %t149)
  %t155 = icmp ne ptr %t154, null
  %t156 = select i1 %t155, i64 %t149, i64 0
  %t157 = insertvalue { i64, ptr } undef, i64 %t156, 0
  %t158 = insertvalue { i64, ptr } %t157, ptr %t154, 1
  store { i64, ptr } %t158, ptr %l65, !tbaa !27
  %t159 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t160 = extractvalue { i64, ptr } %t159, 0
  %t162 = icmp ne i64 %t160, 0
  br i1 %t162, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_e00ef57679a22b3d_1b372a33b8274bb9)
  unreachable
bb24:
  %t164 = load { i64, ptr }, ptr %l65, !tbaa !27
  store { i64, ptr } %t164, ptr %l63, !tbaa !27
  br label %bb26
bb25:
  %t165 = load i64, ptr %l62, !tbaa !24
  %t166 = mul i64 %t165, 8
  %t167 = load i64, ptr %l61
  %t168 = inttoptr i64 %t167 to ptr
  %t169 = call ptr @__olang_held_alloc(ptr %t168, i64 %t166)
  %t170 = insertvalue { i64, ptr } undef, i64 %t165, 0
  %t171 = insertvalue { i64, ptr } %t170, ptr %t169, 1
  store { i64, ptr } %t171, ptr %l63, !tbaa !27
  store i64 0, ptr %l68, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb27
bb26:
  %t172 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t173 = extractvalue { i64, ptr } %t172, 0
  %t175 = icmp eq i64 %t173, 0
  br i1 %t175, label %bb33, label %bb34
bb27:
  %t177 = load i64, ptr %l9, !tbaa !24
  %t178 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t180 = extractvalue { i64, ptr } %t178, 0
  %t183 = icmp slt i64 %t177, %t180
  %t185 = xor i1 %t183, true
  br i1 %t185, label %bb28, label %bb29
bb28:
  br label %bb32
bb29:
  br label %bb30
bb30:
  %t187 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t187, ptr %l74, !tbaa !27
  %t188 = load i64, ptr %l9, !tbaa !24
  %t190 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t191 = load ptr, ptr %t190, !tbaa !27
  %t192 = getelementptr i64, ptr %t191, i64 %t188
  %t193 = load i64, ptr %t192, !tbaa !34
  %t195 = load i64, ptr %l68, !tbaa !24
  %t196 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t197 = load ptr, ptr %t196, !tbaa !27
  %t198 = getelementptr i64, ptr %t197, i64 %t195
  store i64 %t193, ptr %t198, !tbaa !34
  %t199 = load i64, ptr %l68, !tbaa !24
  %t200 = add i64 %t199, 1
  store i64 %t200, ptr %l68, !tbaa !24
  br label %bb31
bb31:
  %t201 = load i64, ptr %l9, !tbaa !24
  %t204 = add i64 %t201, 1
  store i64 %t204, ptr %l9, !tbaa !24
  br label %bb27
bb32:
  br label %bb26
bb33:
  store { i64, ptr } zeroinitializer, ptr %l63, !tbaa !27
  br label %bb34
bb34:
  %t206 = load i64, ptr %l61
  %t207 = inttoptr i64 %t206 to ptr
  %t208 = load { i64, ptr }, ptr %l63
  %t209 = extractvalue { i64, ptr } %t208, 1
  %t210 = call ptr @__olang_region_or(ptr %t209, ptr null)
  %t211 = icmp ne ptr %t210, null
  %t212 = select i1 %t211, ptr %t210, ptr null
  call void @__olang_region_settle_in(ptr %t207, ptr %t212)
  %t213 = load ptr, ptr %l51, !tbaa !29
  %t214 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t213, i32 0, i32 1
  %t215 = load { i64, ptr }, ptr %t214, !tbaa !27
  store { i64, ptr } %t215, ptr %l82, !tbaa !27
  %t216 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t217 = load ptr, ptr %l51, !tbaa !29
  %t218 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t217, i32 0, i32 1
  store { i64, ptr } %t216, ptr %t218, !tbaa !27
  %t219 = load { i64, ptr }, ptr %l82
  %t220 = extractvalue { i64, ptr } %t219, 0
  %t221 = extractvalue { i64, ptr } %t219, 1
  call void @__olang_region_release_part(ptr %t221, i64 %t220)
  store { i64, ptr } zeroinitializer, ptr %l82
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H0110f09d6616867ae14b608097fe5c88(ptr %v0, ptr %v1, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, %"compiler/scope:Placement" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l2 = alloca %"compiler/scope:Placement"
  %l3 = alloca i64
  %l4 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i64
  %l13 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l19 = alloca i64
  %l28 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l30 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l32 = alloca i1
  %l36 = alloca %"compiler/scope:Placement"
  %l37 = alloca { i64, ptr }
  %l38 = alloca i64
  %l39 = alloca { i64, ptr }
  %l43 = alloca ptr
  %l44 = alloca i64
  %l45 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l46 = alloca %"compiler/scope:Placement"
  %l48 = alloca %"compiler/scope:Placement"
  %s0 = alloca %olang.scope
  %t21 = alloca i64
  store ptr %a0, ptr %l0
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, ptr %l1
  store %"compiler/scope:Placement" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1, i32 0, i32 2
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp eq i64 %t6, 0
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l9, !tbaa !29
  %t11 = call ptr @__olang_region_make_part(ptr %v0)
  %t12 = ptrtoint ptr %t11 to i64
  store i64 %t12, ptr %l10, !tbaa !24
  %t13 = icmp sge i64 8, 0
  br i1 %t13, label %bb3, label %bb4
bb2:
  br label %bb9
bb3:
  %t15 = icmp sle i64 8, 1152921504606846975
  br i1 %t15, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_eeb9dbebae58ad76_140d94069fd0f1da)
  unreachable
bb5:
  %t17 = mul i64 8, 8
  %t18 = load i64, ptr %l10
  %t19 = inttoptr i64 %t18 to ptr
  %t20 = call ptr @__olang_held_alloc(ptr %t19, i64 %t17)
  store i64 0, ptr %t21
  br label %fill.22
fill.22:
  %t25 = load i64, ptr %t21
  %t26 = icmp slt i64 %t25, 8
  br i1 %t26, label %fillb.23, label %filld.24
fillb.23:
  %t27 = getelementptr i64, ptr %t20, i64 %t25
  store i64 -1, ptr %t27
  %t28 = add i64 %t25, 1
  store i64 %t28, ptr %t21
  br label %fill.22
filld.24:
  %t29 = insertvalue { i64, ptr } undef, i64 8, 0
  %t30 = insertvalue { i64, ptr } %t29, ptr %t20, 1
  store { i64, ptr } %t30, ptr %l13, !tbaa !27
  %t31 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  %t34 = icmp eq i64 %t32, 0
  br i1 %t34, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_eeb9dbebae58ad76_140d94069fd0f1da)
  unreachable
bb7:
  store { i64, ptr } zeroinitializer, ptr %l13, !tbaa !27
  br label %bb8
bb8:
  %t36 = load i64, ptr %l10
  %t37 = inttoptr i64 %t36 to ptr
  %t38 = load { i64, ptr }, ptr %l13
  %t39 = extractvalue { i64, ptr } %t38, 1
  %t40 = call ptr @__olang_region_or(ptr %t39, ptr null)
  %t41 = icmp ne ptr %t40, null
  %t42 = select i1 %t41, ptr %t40, ptr null
  call void @__olang_region_settle_in(ptr %t37, ptr %t42)
  %t43 = load ptr, ptr %l9, !tbaa !29
  %t44 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t43, i32 0, i32 2
  %t45 = load { i64, ptr }, ptr %t44, !tbaa !27
  store { i64, ptr } %t45, ptr %l16, !tbaa !27
  %t46 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t47 = load ptr, ptr %l9, !tbaa !29
  %t48 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t47, i32 0, i32 2
  store { i64, ptr } %t46, ptr %t48, !tbaa !27
  %t49 = load { i64, ptr }, ptr %l16
  %t50 = extractvalue { i64, ptr } %t49, 0
  %t51 = extractvalue { i64, ptr } %t49, 1
  call void @__olang_region_release_part(ptr %t51, i64 %t50)
  store { i64, ptr } zeroinitializer, ptr %l16
  br label %bb9
bb9:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l1
  %t56 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2b299ac8414fe0900d06d94de708c354(ptr %v0, ptr %t52, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t53)
  store i64 %t56, ptr %l19
  br label %bb10
bb10:
  %t57 = load i64, ptr %l19, !tbaa !24
  store i64 %t57, ptr %l3, !tbaa !24
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load i64, ptr %l3, !tbaa !24
  %t61 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t58, i32 0, i32 2
  %t63 = getelementptr { i64, ptr }, ptr %t61, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !27
  %t65 = getelementptr i64, ptr %t64, i64 %t59
  %t66 = load i64, ptr %t65, !tbaa !34
  store i64 %t66, ptr %l4, !tbaa !24
  br label %bb11
bb11:
  %t68 = load i64, ptr %l4, !tbaa !24
  %t70 = icmp sge i64 %t68, 0
  %t72 = xor i1 %t70, true
  br i1 %t72, label %bb12, label %bb13
bb12:
  br label %bb20
bb13:
  br label %bb14
bb14:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load i64, ptr %l4, !tbaa !24
  %t77 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t74, i32 0, i32 0
  %t79 = getelementptr { i64, ptr }, ptr %t77, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = getelementptr %"std/prelude/map:MapEntry.5d90ea23f235d8870da3668e82c28edd", ptr %t80, i64 %t75
  %t82 = getelementptr %"std/prelude/map:MapEntry.5d90ea23f235d8870da3668e82c28edd", ptr %t81, i32 0, i32 0
  %t83 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %t82
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t83, ptr %l28
  %t84 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l1
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t84, ptr %l30
  %t87 = call i1 @olang_2emir_2eHelperKind_2eEqual_2estd_2fpair_3aPair_3cI64_2c_20I64_3e(ptr %l28, ptr %l30)
  store i1 %t87, ptr %l32
  br label %bb15
bb15:
  %t88 = load i1, ptr %l32, !tbaa !21
  br i1 %t88, label %bb16, label %bb17
bb16:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t90 = load i64, ptr %l4, !tbaa !24
  %t91 = load %"compiler/scope:Placement", ptr %l2
  store %"compiler/scope:Placement" %t91, ptr %l36
  %t93 = getelementptr %"compiler/scope:Placement", ptr %l36, i32 0, i32 4
  %t94 = load { i64, ptr }, ptr %t93, !tbaa !27
  store { i64, ptr } %t94, ptr %l37, !tbaa !27
  %t95 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t96 = extractvalue { i64, ptr } %t95, 0
  store i64 %t96, ptr %l38, !tbaa !24
  %t97 = load i64, ptr %l38, !tbaa !24
  %t98 = mul i64 %t97, 1
  %t99 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t98)
  %t100 = insertvalue { i64, ptr } undef, i64 %t97, 0
  %t101 = insertvalue { i64, ptr } %t100, ptr %t99, 1
  store { i64, ptr } %t101, ptr %l39, !tbaa !27
  %t102 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t103 = load ptr, ptr %t102, !tbaa !27
  %t104 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !27
  %t106 = load i64, ptr %l38, !tbaa !24
  %t107 = mul i64 %t106, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t103, ptr %t105, i64 %t107, i1 false)
  %t108 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t109 = getelementptr %"compiler/scope:Placement", ptr %l36, i32 0, i32 4
  store { i64, ptr } %t108, ptr %t109, !tbaa !27
  %t110 = load %"compiler/scope:Placement", ptr %l36
  %t112 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t89, i32 0, i32 0
  %t114 = getelementptr { i64, ptr }, ptr %t112, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !27
  %t116 = getelementptr %"std/prelude/map:MapEntry.5d90ea23f235d8870da3668e82c28edd", ptr %t115, i64 %t90
  %t117 = getelementptr %"std/prelude/map:MapEntry.5d90ea23f235d8870da3668e82c28edd", ptr %t116, i32 0, i32 1
  store %"compiler/scope:Placement" %t110, ptr %t117
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb17:
  br label %bb18
bb18:
  br label %bb19
bb19:
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t119 = load i64, ptr %l4, !tbaa !24
  %t121 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t118, i32 0, i32 1
  %t123 = getelementptr { i64, ptr }, ptr %t121, i32 0, i32 1
  %t124 = load ptr, ptr %t123, !tbaa !27
  %t125 = getelementptr i64, ptr %t124, i64 %t119
  %t126 = load i64, ptr %t125, !tbaa !34
  store i64 %t126, ptr %l4, !tbaa !24
  br label %bb11
bb20:
  %t128 = load ptr, ptr %l0, !tbaa !29
  store ptr %t128, ptr %l43, !tbaa !29
  %t129 = load i64, ptr %l3, !tbaa !24
  store i64 %t129, ptr %l44, !tbaa !24
  %t130 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l1
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t130, ptr %l45
  %t131 = load %"compiler/scope:Placement", ptr %l2
  store %"compiler/scope:Placement" %t131, ptr %l46
  %t133 = call %"compiler/scope:Placement" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fscope_3aPlacement(ptr %s0, ptr %l46)
  store %"compiler/scope:Placement" %t133, ptr %l48
  br label %bb21
bb21:
  %t134 = load ptr, ptr %l43, !tbaa !29
  %t135 = load i64, ptr %l44, !tbaa !24
  %t136 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l45
  %t137 = load %"compiler/scope:Placement", ptr %l48
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H5726a2dd684fb58cbf53a937edd2530b(ptr %v0, ptr %s0, ptr %t134, i64 %t135, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t136, %"compiler/scope:Placement" %t137)
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H0a23192159595270dbd958f231402404(ptr %v0, ptr %a0) noinline cold #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l5 = alloca i64
  %l7 = alloca { i64, ptr }
  %l9 = alloca i64
  %l14 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l32 = alloca { i64, ptr }
  %l33 = alloca i64
  %l39 = alloca { i64, ptr }
  %l49 = alloca ptr
  %l50 = alloca { i64, ptr }
  %l52 = alloca i64
  %l53 = alloca i64
  %l59 = alloca i64
  %l60 = alloca i64
  %l61 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %l66 = alloca i64
  %l72 = alloca { i64, ptr }
  %l80 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp slt i64 %t6, 4
  br i1 %t8, label %bb1, label %bb2
bb1:
  store i64 8, ptr %l14, !tbaa !24
  br label %bb3
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t17 = mul i64 %t15, 2
  store i64 %t17, ptr %l14, !tbaa !24
  br label %bb3
bb3:
  %t19 = load i64, ptr %l14, !tbaa !24
  store i64 %t19, ptr %l1, !tbaa !24
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t20, i32 0, i32 0
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !27
  store { i64, ptr } %t23, ptr %l2, !tbaa !27
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l21, !tbaa !29
  %t26 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t26, ptr %l22, !tbaa !27
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t27, i32 0, i32 3
  %t30 = load i64, ptr %t29, !tbaa !24
  store i64 %t30, ptr %l24, !tbaa !24
  %t31 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  store i64 %t32, ptr %l25, !tbaa !24
  %t33 = icmp sge i64 0, 0
  br i1 %t33, label %bb4, label %bb5
bb4:
  %t35 = load i64, ptr %l24, !tbaa !24
  %t36 = icmp sle i64 0, %t35
  br i1 %t36, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_1a9fa279a31b6314_c50c4801ffbd75a8)
  unreachable
bb6:
  %t38 = load i64, ptr %l24, !tbaa !24
  %t39 = load i64, ptr %l25, !tbaa !24
  %t40 = icmp sle i64 %t38, %t39
  br i1 %t40, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_1a9fa279a31b6314_c50c4801ffbd75a8)
  unreachable
bb8:
  %t42 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = load i64, ptr %l24, !tbaa !24
  %t45 = getelementptr %"std/prelude/map:MapEntry.39ab5235a9e7cc4d21ab272df52b187f", ptr %t43, i64 0
  %t46 = sub i64 %t44, 0
  %t47 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t45, 1
  store { i64, ptr } %t48, ptr %l3, !tbaa !27
  %t50 = load i64, ptr %l1, !tbaa !24
  %t54 = mul i64 %t50, 48
  %t55 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t54)
  %t56 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t55, 1
  store { i64, ptr } %t57, ptr %l32, !tbaa !27
  store i64 0, ptr %l33, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_1a9fa279a31b6314_c50c4801ffbd75a8)
  unreachable
bb10:
  %t58 = load i64, ptr %l5, !tbaa !24
  %t59 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t61 = extractvalue { i64, ptr } %t59, 0
  %t64 = icmp slt i64 %t58, %t61
  %t66 = xor i1 %t64, true
  br i1 %t66, label %bb11, label %bb12
bb11:
  br label %bb15
bb12:
  br label %bb13
bb13:
  %t68 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t68, ptr %l39, !tbaa !27
  %t69 = load i64, ptr %l5, !tbaa !24
  %t71 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !27
  %t73 = getelementptr %"std/prelude/map:MapEntry.39ab5235a9e7cc4d21ab272df52b187f", ptr %t72, i64 %t69
  %t74 = load %"std/prelude/map:MapEntry.39ab5235a9e7cc4d21ab272df52b187f", ptr %t73
  store %"std/prelude/map:MapEntry.39ab5235a9e7cc4d21ab272df52b187f" zeroinitializer, ptr %t73
  %t76 = load i64, ptr %l33, !tbaa !24
  %t77 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = getelementptr %"std/prelude/map:MapEntry.39ab5235a9e7cc4d21ab272df52b187f", ptr %t78, i64 %t76
  store %"std/prelude/map:MapEntry.39ab5235a9e7cc4d21ab272df52b187f" %t74, ptr %t79
  %t80 = load i64, ptr %l33, !tbaa !24
  %t81 = add i64 %t80, 1
  store i64 %t81, ptr %l33, !tbaa !24
  br label %bb14
bb14:
  %t82 = load i64, ptr %l5, !tbaa !24
  %t85 = add i64 %t82, 1
  store i64 %t85, ptr %l5, !tbaa !24
  br label %bb10
bb15:
  %t87 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t88 = load ptr, ptr %l21, !tbaa !29
  %t89 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t88, i32 0, i32 0
  store { i64, ptr } %t87, ptr %t89, !tbaa !27
  %t90 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t92, i32 0, i32 1
  %t95 = load { i64, ptr }, ptr %t94, !tbaa !27
  %t97 = load ptr, ptr %l0, !tbaa !29
  store ptr %t97, ptr %l49, !tbaa !29
  store { i64, ptr } %t95, ptr %l50, !tbaa !27
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t99, i32 0, i32 3
  %t102 = load i64, ptr %t101, !tbaa !24
  store i64 %t102, ptr %l52, !tbaa !24
  %t103 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t104 = extractvalue { i64, ptr } %t103, 0
  store i64 %t104, ptr %l53, !tbaa !24
  %t105 = icmp sge i64 0, 0
  br i1 %t105, label %bb16, label %bb17
bb16:
  %t107 = load i64, ptr %l52, !tbaa !24
  %t108 = icmp sle i64 0, %t107
  br i1 %t108, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_4389c18ddfab6081_27102ba240c05185)
  unreachable
bb18:
  %t110 = load i64, ptr %l52, !tbaa !24
  %t111 = load i64, ptr %l53, !tbaa !24
  %t112 = icmp sle i64 %t110, %t111
  br i1 %t112, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_4389c18ddfab6081_27102ba240c05185)
  unreachable
bb20:
  %t114 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !27
  %t116 = load i64, ptr %l52, !tbaa !24
  %t117 = getelementptr i64, ptr %t115, i64 0
  %t118 = sub i64 %t116, 0
  %t119 = insertvalue { i64, ptr } undef, i64 %t118, 0
  %t120 = insertvalue { i64, ptr } %t119, ptr %t117, 1
  store { i64, ptr } %t120, ptr %l7, !tbaa !27
  %t122 = load i64, ptr %l1, !tbaa !24
  %t124 = call ptr @__olang_region_make_part(ptr %v0)
  %t125 = ptrtoint ptr %t124 to i64
  store i64 %t125, ptr %l59, !tbaa !24
  store i64 %t122, ptr %l60, !tbaa !24
  %t127 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t129 = load i64, ptr %l60, !tbaa !24
  %t130 = extractvalue { i64, ptr } %t127, 0
  %t131 = mul i64 %t130, 8
  %t132 = mul i64 %t129, 8
  %t133 = extractvalue { i64, ptr } %t127, 1
  %t134 = call ptr @__olang_grow_in_place(ptr %t133, i64 %t131, i64 %t132, i64 %t129)
  %t135 = icmp ne ptr %t134, null
  %t136 = select i1 %t135, i64 %t129, i64 0
  %t137 = insertvalue { i64, ptr } undef, i64 %t136, 0
  %t138 = insertvalue { i64, ptr } %t137, ptr %t134, 1
  store { i64, ptr } %t138, ptr %l63, !tbaa !27
  %t139 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t140 = extractvalue { i64, ptr } %t139, 0
  %t142 = icmp ne i64 %t140, 0
  br i1 %t142, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_4389c18ddfab6081_27102ba240c05185)
  unreachable
bb22:
  %t144 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t144, ptr %l61, !tbaa !27
  br label %bb24
bb23:
  %t145 = load i64, ptr %l60, !tbaa !24
  %t146 = mul i64 %t145, 8
  %t147 = load i64, ptr %l59
  %t148 = inttoptr i64 %t147 to ptr
  %t149 = call ptr @__olang_held_alloc(ptr %t148, i64 %t146)
  %t150 = insertvalue { i64, ptr } undef, i64 %t145, 0
  %t151 = insertvalue { i64, ptr } %t150, ptr %t149, 1
  store { i64, ptr } %t151, ptr %l61, !tbaa !27
  store i64 0, ptr %l66, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb25
bb24:
  %t152 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t153 = extractvalue { i64, ptr } %t152, 0
  %t155 = icmp eq i64 %t153, 0
  br i1 %t155, label %bb31, label %bb32
bb25:
  %t157 = load i64, ptr %l9, !tbaa !24
  %t158 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t160 = extractvalue { i64, ptr } %t158, 0
  %t163 = icmp slt i64 %t157, %t160
  %t165 = xor i1 %t163, true
  br i1 %t165, label %bb26, label %bb27
bb26:
  br label %bb30
bb27:
  br label %bb28
bb28:
  %t167 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t167, ptr %l72, !tbaa !27
  %t168 = load i64, ptr %l9, !tbaa !24
  %t170 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t171 = load ptr, ptr %t170, !tbaa !27
  %t172 = getelementptr i64, ptr %t171, i64 %t168
  %t173 = load i64, ptr %t172, !tbaa !34
  %t175 = load i64, ptr %l66, !tbaa !24
  %t176 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t177 = load ptr, ptr %t176, !tbaa !27
  %t178 = getelementptr i64, ptr %t177, i64 %t175
  store i64 %t173, ptr %t178, !tbaa !34
  %t179 = load i64, ptr %l66, !tbaa !24
  %t180 = add i64 %t179, 1
  store i64 %t180, ptr %l66, !tbaa !24
  br label %bb29
bb29:
  %t181 = load i64, ptr %l9, !tbaa !24
  %t184 = add i64 %t181, 1
  store i64 %t184, ptr %l9, !tbaa !24
  br label %bb25
bb30:
  br label %bb24
bb31:
  store { i64, ptr } zeroinitializer, ptr %l61, !tbaa !27
  br label %bb32
bb32:
  %t186 = load i64, ptr %l59
  %t187 = inttoptr i64 %t186 to ptr
  %t188 = load { i64, ptr }, ptr %l61
  %t189 = extractvalue { i64, ptr } %t188, 1
  %t190 = call ptr @__olang_region_or(ptr %t189, ptr null)
  %t191 = icmp ne ptr %t190, null
  %t192 = select i1 %t191, ptr %t190, ptr null
  call void @__olang_region_settle_in(ptr %t187, ptr %t192)
  %t193 = load ptr, ptr %l49, !tbaa !29
  %t194 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t193, i32 0, i32 1
  %t195 = load { i64, ptr }, ptr %t194, !tbaa !27
  store { i64, ptr } %t195, ptr %l80, !tbaa !27
  %t196 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t197 = load ptr, ptr %l49, !tbaa !29
  %t198 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t197, i32 0, i32 1
  store { i64, ptr } %t196, ptr %t198, !tbaa !27
  %t199 = load { i64, ptr }, ptr %l80
  %t200 = extractvalue { i64, ptr } %t199, 0
  %t201 = extractvalue { i64, ptr } %t199, 1
  call void @__olang_region_release_part(ptr %t201, i64 %t200)
  store { i64, ptr } zeroinitializer, ptr %l80
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2b4f7a0691718c24c2513bccb473de6f(ptr %v0, ptr %a0) noinline cold #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca { i64, ptr }
  %l5 = alloca i64
  %l7 = alloca { i64, ptr }
  %l9 = alloca i64
  %l14 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l38 = alloca i64
  %l44 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %l55 = alloca ptr
  %l56 = alloca { i64, ptr }
  %l58 = alloca i64
  %l59 = alloca i64
  %l65 = alloca i64
  %l66 = alloca i64
  %l67 = alloca { i64, ptr }
  %l69 = alloca { i64, ptr }
  %l72 = alloca i64
  %l78 = alloca { i64, ptr }
  %l86 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp slt i64 %t6, 4
  br i1 %t8, label %bb1, label %bb2
bb1:
  store i64 8, ptr %l14, !tbaa !24
  br label %bb3
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t17 = mul i64 %t15, 2
  store i64 %t17, ptr %l14, !tbaa !24
  br label %bb3
bb3:
  %t19 = load i64, ptr %l14, !tbaa !24
  store i64 %t19, ptr %l1, !tbaa !24
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t20, i32 0, i32 0
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !27
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l21, !tbaa !29
  store { i64, ptr } %t23, ptr %l22, !tbaa !27
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t27, i32 0, i32 3
  %t30 = load i64, ptr %t29, !tbaa !24
  store i64 %t30, ptr %l24, !tbaa !24
  %t31 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  store i64 %t32, ptr %l25, !tbaa !24
  %t33 = icmp sge i64 0, 0
  br i1 %t33, label %bb4, label %bb5
bb4:
  %t35 = load i64, ptr %l24, !tbaa !24
  %t36 = icmp sle i64 0, %t35
  br i1 %t36, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_f5147e9cccb71a89_abf62f853b44252d)
  unreachable
bb6:
  %t38 = load i64, ptr %l24, !tbaa !24
  %t39 = load i64, ptr %l25, !tbaa !24
  %t40 = icmp sle i64 %t38, %t39
  br i1 %t40, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_f5147e9cccb71a89_abf62f853b44252d)
  unreachable
bb8:
  %t42 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = load i64, ptr %l24, !tbaa !24
  %t45 = getelementptr %"std/prelude/map:MapEntry.9ce8a46a5d367870e2478b0757bce708", ptr %t43, i64 0
  %t46 = sub i64 %t44, 0
  %t47 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t45, 1
  store { i64, ptr } %t48, ptr %l3, !tbaa !27
  %t50 = load i64, ptr %l1, !tbaa !24
  %t52 = call ptr @__olang_region_make_part(ptr %v0)
  %t53 = ptrtoint ptr %t52 to i64
  store i64 %t53, ptr %l31, !tbaa !24
  store i64 %t50, ptr %l32, !tbaa !24
  %t55 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t57 = load i64, ptr %l32, !tbaa !24
  %t58 = extractvalue { i64, ptr } %t55, 0
  %t59 = mul i64 %t58, 24
  %t60 = mul i64 %t57, 24
  %t61 = extractvalue { i64, ptr } %t55, 1
  %t62 = call ptr @__olang_grow_in_place(ptr %t61, i64 %t59, i64 %t60, i64 %t57)
  %t63 = icmp ne ptr %t62, null
  %t64 = select i1 %t63, i64 %t57, i64 0
  %t65 = insertvalue { i64, ptr } undef, i64 %t64, 0
  %t66 = insertvalue { i64, ptr } %t65, ptr %t62, 1
  store { i64, ptr } %t66, ptr %l35, !tbaa !27
  %t67 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t68 = extractvalue { i64, ptr } %t67, 0
  %t70 = icmp ne i64 %t68, 0
  br i1 %t70, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_f5147e9cccb71a89_abf62f853b44252d)
  unreachable
bb10:
  %t72 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t72, ptr %l33, !tbaa !27
  br label %bb12
bb11:
  %t73 = load i64, ptr %l32, !tbaa !24
  %t74 = mul i64 %t73, 24
  %t75 = load i64, ptr %l31
  %t76 = inttoptr i64 %t75 to ptr
  %t77 = call ptr @__olang_held_alloc(ptr %t76, i64 %t74)
  %t78 = insertvalue { i64, ptr } undef, i64 %t73, 0
  %t79 = insertvalue { i64, ptr } %t78, ptr %t77, 1
  store { i64, ptr } %t79, ptr %l33, !tbaa !27
  store i64 0, ptr %l38, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb13
bb12:
  %t80 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t81 = extractvalue { i64, ptr } %t80, 0
  %t83 = icmp eq i64 %t81, 0
  br i1 %t83, label %bb19, label %bb20
bb13:
  %t85 = load i64, ptr %l5, !tbaa !24
  %t86 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t88 = extractvalue { i64, ptr } %t86, 0
  %t91 = icmp slt i64 %t85, %t88
  %t93 = xor i1 %t91, true
  br i1 %t93, label %bb14, label %bb15
bb14:
  br label %bb18
bb15:
  br label %bb16
bb16:
  %t95 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t95, ptr %l44, !tbaa !27
  %t96 = load i64, ptr %l5, !tbaa !24
  %t98 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !27
  %t100 = getelementptr %"std/prelude/map:MapEntry.9ce8a46a5d367870e2478b0757bce708", ptr %t99, i64 %t96
  %t101 = load %"std/prelude/map:MapEntry.9ce8a46a5d367870e2478b0757bce708", ptr %t100
  %t103 = load i64, ptr %l38, !tbaa !24
  %t104 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !27
  %t106 = getelementptr %"std/prelude/map:MapEntry.9ce8a46a5d367870e2478b0757bce708", ptr %t105, i64 %t103
  store %"std/prelude/map:MapEntry.9ce8a46a5d367870e2478b0757bce708" %t101, ptr %t106
  %t107 = load i64, ptr %l38, !tbaa !24
  %t108 = add i64 %t107, 1
  store i64 %t108, ptr %l38, !tbaa !24
  br label %bb17
bb17:
  %t109 = load i64, ptr %l5, !tbaa !24
  %t112 = add i64 %t109, 1
  store i64 %t112, ptr %l5, !tbaa !24
  br label %bb13
bb18:
  br label %bb12
bb19:
  store { i64, ptr } zeroinitializer, ptr %l33, !tbaa !27
  br label %bb20
bb20:
  %t114 = load i64, ptr %l31
  %t115 = inttoptr i64 %t114 to ptr
  %t116 = load { i64, ptr }, ptr %l33
  %t117 = extractvalue { i64, ptr } %t116, 1
  %t118 = call ptr @__olang_region_or(ptr %t117, ptr null)
  %t119 = icmp ne ptr %t118, null
  %t120 = select i1 %t119, ptr %t118, ptr null
  call void @__olang_region_settle_in(ptr %t115, ptr %t120)
  %t121 = load ptr, ptr %l21, !tbaa !29
  %t122 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t121, i32 0, i32 0
  %t123 = load { i64, ptr }, ptr %t122, !tbaa !27
  store { i64, ptr } %t123, ptr %l52, !tbaa !27
  %t124 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t125 = load ptr, ptr %l21, !tbaa !29
  %t126 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t125, i32 0, i32 0
  store { i64, ptr } %t124, ptr %t126, !tbaa !27
  %t127 = load { i64, ptr }, ptr %l52
  %t128 = extractvalue { i64, ptr } %t127, 0
  %t129 = extractvalue { i64, ptr } %t127, 1
  call void @__olang_region_release_part(ptr %t129, i64 %t128)
  store { i64, ptr } zeroinitializer, ptr %l52
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t130, i32 0, i32 1
  %t133 = load { i64, ptr }, ptr %t132, !tbaa !27
  %t135 = load ptr, ptr %l0, !tbaa !29
  store ptr %t135, ptr %l55, !tbaa !29
  store { i64, ptr } %t133, ptr %l56, !tbaa !27
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t139 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t137, i32 0, i32 3
  %t140 = load i64, ptr %t139, !tbaa !24
  store i64 %t140, ptr %l58, !tbaa !24
  %t141 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t142 = extractvalue { i64, ptr } %t141, 0
  store i64 %t142, ptr %l59, !tbaa !24
  %t143 = icmp sge i64 0, 0
  br i1 %t143, label %bb21, label %bb22
bb21:
  %t145 = load i64, ptr %l58, !tbaa !24
  %t146 = icmp sle i64 0, %t145
  br i1 %t146, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_69fb979c9c271d1c_9f38969fb60f0e50)
  unreachable
bb23:
  %t148 = load i64, ptr %l58, !tbaa !24
  %t149 = load i64, ptr %l59, !tbaa !24
  %t150 = icmp sle i64 %t148, %t149
  br i1 %t150, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_69fb979c9c271d1c_9f38969fb60f0e50)
  unreachable
bb25:
  %t152 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t153 = load ptr, ptr %t152, !tbaa !27
  %t154 = load i64, ptr %l58, !tbaa !24
  %t155 = getelementptr i64, ptr %t153, i64 0
  %t156 = sub i64 %t154, 0
  %t157 = insertvalue { i64, ptr } undef, i64 %t156, 0
  %t158 = insertvalue { i64, ptr } %t157, ptr %t155, 1
  store { i64, ptr } %t158, ptr %l7, !tbaa !27
  %t160 = load i64, ptr %l1, !tbaa !24
  %t162 = call ptr @__olang_region_make_part(ptr %v0)
  %t163 = ptrtoint ptr %t162 to i64
  store i64 %t163, ptr %l65, !tbaa !24
  store i64 %t160, ptr %l66, !tbaa !24
  %t165 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t167 = load i64, ptr %l66, !tbaa !24
  %t168 = extractvalue { i64, ptr } %t165, 0
  %t169 = mul i64 %t168, 8
  %t170 = mul i64 %t167, 8
  %t171 = extractvalue { i64, ptr } %t165, 1
  %t172 = call ptr @__olang_grow_in_place(ptr %t171, i64 %t169, i64 %t170, i64 %t167)
  %t173 = icmp ne ptr %t172, null
  %t174 = select i1 %t173, i64 %t167, i64 0
  %t175 = insertvalue { i64, ptr } undef, i64 %t174, 0
  %t176 = insertvalue { i64, ptr } %t175, ptr %t172, 1
  store { i64, ptr } %t176, ptr %l69, !tbaa !27
  %t177 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t178 = extractvalue { i64, ptr } %t177, 0
  %t180 = icmp ne i64 %t178, 0
  br i1 %t180, label %bb27, label %bb28
bb26:
  call void @__olang_check_failed(ptr @olang_loc_69fb979c9c271d1c_9f38969fb60f0e50)
  unreachable
bb27:
  %t182 = load { i64, ptr }, ptr %l69, !tbaa !27
  store { i64, ptr } %t182, ptr %l67, !tbaa !27
  br label %bb29
bb28:
  %t183 = load i64, ptr %l66, !tbaa !24
  %t184 = mul i64 %t183, 8
  %t185 = load i64, ptr %l65
  %t186 = inttoptr i64 %t185 to ptr
  %t187 = call ptr @__olang_held_alloc(ptr %t186, i64 %t184)
  %t188 = insertvalue { i64, ptr } undef, i64 %t183, 0
  %t189 = insertvalue { i64, ptr } %t188, ptr %t187, 1
  store { i64, ptr } %t189, ptr %l67, !tbaa !27
  store i64 0, ptr %l72, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb30
bb29:
  %t190 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t191 = extractvalue { i64, ptr } %t190, 0
  %t193 = icmp eq i64 %t191, 0
  br i1 %t193, label %bb36, label %bb37
bb30:
  %t195 = load i64, ptr %l9, !tbaa !24
  %t196 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t198 = extractvalue { i64, ptr } %t196, 0
  %t201 = icmp slt i64 %t195, %t198
  %t203 = xor i1 %t201, true
  br i1 %t203, label %bb31, label %bb32
bb31:
  br label %bb35
bb32:
  br label %bb33
bb33:
  %t205 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t205, ptr %l78, !tbaa !27
  %t206 = load i64, ptr %l9, !tbaa !24
  %t208 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t209 = load ptr, ptr %t208, !tbaa !27
  %t210 = getelementptr i64, ptr %t209, i64 %t206
  %t211 = load i64, ptr %t210, !tbaa !34
  %t213 = load i64, ptr %l72, !tbaa !24
  %t214 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t215 = load ptr, ptr %t214, !tbaa !27
  %t216 = getelementptr i64, ptr %t215, i64 %t213
  store i64 %t211, ptr %t216, !tbaa !34
  %t217 = load i64, ptr %l72, !tbaa !24
  %t218 = add i64 %t217, 1
  store i64 %t218, ptr %l72, !tbaa !24
  br label %bb34
bb34:
  %t219 = load i64, ptr %l9, !tbaa !24
  %t222 = add i64 %t219, 1
  store i64 %t222, ptr %l9, !tbaa !24
  br label %bb30
bb35:
  br label %bb29
bb36:
  store { i64, ptr } zeroinitializer, ptr %l67, !tbaa !27
  br label %bb37
bb37:
  %t224 = load i64, ptr %l65
  %t225 = inttoptr i64 %t224 to ptr
  %t226 = load { i64, ptr }, ptr %l67
  %t227 = extractvalue { i64, ptr } %t226, 1
  %t228 = call ptr @__olang_region_or(ptr %t227, ptr null)
  %t229 = icmp ne ptr %t228, null
  %t230 = select i1 %t229, ptr %t228, ptr null
  call void @__olang_region_settle_in(ptr %t225, ptr %t230)
  %t231 = load ptr, ptr %l55, !tbaa !29
  %t232 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t231, i32 0, i32 1
  %t233 = load { i64, ptr }, ptr %t232, !tbaa !27
  store { i64, ptr } %t233, ptr %l86, !tbaa !27
  %t234 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t235 = load ptr, ptr %l55, !tbaa !29
  %t236 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t235, i32 0, i32 1
  store { i64, ptr } %t234, ptr %t236, !tbaa !27
  %t237 = load { i64, ptr }, ptr %l86
  %t238 = extractvalue { i64, ptr } %t237, 0
  %t239 = extractvalue { i64, ptr } %t237, 1
  call void @__olang_region_release_part(ptr %t239, i64 %t238)
  store { i64, ptr } zeroinitializer, ptr %l86
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H330f7a560d59a8d4cd8a08f5192260fe(ptr %v0, ptr %a0) noinline cold #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca { i64, ptr }
  %l5 = alloca i64
  %l7 = alloca { i64, ptr }
  %l9 = alloca i64
  %l14 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l38 = alloca i64
  %l44 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %l55 = alloca ptr
  %l56 = alloca { i64, ptr }
  %l58 = alloca i64
  %l59 = alloca i64
  %l65 = alloca i64
  %l66 = alloca i64
  %l67 = alloca { i64, ptr }
  %l69 = alloca { i64, ptr }
  %l72 = alloca i64
  %l78 = alloca { i64, ptr }
  %l86 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp slt i64 %t6, 4
  br i1 %t8, label %bb1, label %bb2
bb1:
  store i64 8, ptr %l14, !tbaa !24
  br label %bb3
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t17 = mul i64 %t15, 2
  store i64 %t17, ptr %l14, !tbaa !24
  br label %bb3
bb3:
  %t19 = load i64, ptr %l14, !tbaa !24
  store i64 %t19, ptr %l1, !tbaa !24
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t20, i32 0, i32 0
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !27
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l21, !tbaa !29
  store { i64, ptr } %t23, ptr %l22, !tbaa !27
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t27, i32 0, i32 3
  %t30 = load i64, ptr %t29, !tbaa !24
  store i64 %t30, ptr %l24, !tbaa !24
  %t31 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  store i64 %t32, ptr %l25, !tbaa !24
  %t33 = icmp sge i64 0, 0
  br i1 %t33, label %bb4, label %bb5
bb4:
  %t35 = load i64, ptr %l24, !tbaa !24
  %t36 = icmp sle i64 0, %t35
  br i1 %t36, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_845ee880493f49db_8165d66f07a0ab27)
  unreachable
bb6:
  %t38 = load i64, ptr %l24, !tbaa !24
  %t39 = load i64, ptr %l25, !tbaa !24
  %t40 = icmp sle i64 %t38, %t39
  br i1 %t40, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_845ee880493f49db_8165d66f07a0ab27)
  unreachable
bb8:
  %t42 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = load i64, ptr %l24, !tbaa !24
  %t45 = getelementptr %"std/prelude/map:MapEntry.545808996237a863e786f2cb6df7346f", ptr %t43, i64 0
  %t46 = sub i64 %t44, 0
  %t47 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t45, 1
  store { i64, ptr } %t48, ptr %l3, !tbaa !27
  %t50 = load i64, ptr %l1, !tbaa !24
  %t52 = call ptr @__olang_region_make_part(ptr %v0)
  %t53 = ptrtoint ptr %t52 to i64
  store i64 %t53, ptr %l31, !tbaa !24
  store i64 %t50, ptr %l32, !tbaa !24
  %t55 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t57 = load i64, ptr %l32, !tbaa !24
  %t58 = extractvalue { i64, ptr } %t55, 0
  %t59 = mul i64 %t58, 32
  %t60 = mul i64 %t57, 32
  %t61 = extractvalue { i64, ptr } %t55, 1
  %t62 = call ptr @__olang_grow_in_place(ptr %t61, i64 %t59, i64 %t60, i64 %t57)
  %t63 = icmp ne ptr %t62, null
  %t64 = select i1 %t63, i64 %t57, i64 0
  %t65 = insertvalue { i64, ptr } undef, i64 %t64, 0
  %t66 = insertvalue { i64, ptr } %t65, ptr %t62, 1
  store { i64, ptr } %t66, ptr %l35, !tbaa !27
  %t67 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t68 = extractvalue { i64, ptr } %t67, 0
  %t70 = icmp ne i64 %t68, 0
  br i1 %t70, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_845ee880493f49db_8165d66f07a0ab27)
  unreachable
bb10:
  %t72 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t72, ptr %l33, !tbaa !27
  br label %bb12
bb11:
  %t73 = load i64, ptr %l32, !tbaa !24
  %t74 = mul i64 %t73, 32
  %t75 = load i64, ptr %l31
  %t76 = inttoptr i64 %t75 to ptr
  %t77 = call ptr @__olang_held_alloc(ptr %t76, i64 %t74)
  %t78 = insertvalue { i64, ptr } undef, i64 %t73, 0
  %t79 = insertvalue { i64, ptr } %t78, ptr %t77, 1
  store { i64, ptr } %t79, ptr %l33, !tbaa !27
  store i64 0, ptr %l38, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb13
bb12:
  %t80 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t81 = extractvalue { i64, ptr } %t80, 0
  %t83 = icmp eq i64 %t81, 0
  br i1 %t83, label %bb19, label %bb20
bb13:
  %t85 = load i64, ptr %l5, !tbaa !24
  %t86 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t88 = extractvalue { i64, ptr } %t86, 0
  %t91 = icmp slt i64 %t85, %t88
  %t93 = xor i1 %t91, true
  br i1 %t93, label %bb14, label %bb15
bb14:
  br label %bb18
bb15:
  br label %bb16
bb16:
  %t95 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t95, ptr %l44, !tbaa !27
  %t96 = load i64, ptr %l5, !tbaa !24
  %t98 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !27
  %t100 = getelementptr %"std/prelude/map:MapEntry.545808996237a863e786f2cb6df7346f", ptr %t99, i64 %t96
  %t101 = load %"std/prelude/map:MapEntry.545808996237a863e786f2cb6df7346f", ptr %t100
  %t103 = load i64, ptr %l38, !tbaa !24
  %t104 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !27
  %t106 = getelementptr %"std/prelude/map:MapEntry.545808996237a863e786f2cb6df7346f", ptr %t105, i64 %t103
  store %"std/prelude/map:MapEntry.545808996237a863e786f2cb6df7346f" %t101, ptr %t106
  %t107 = load i64, ptr %l38, !tbaa !24
  %t108 = add i64 %t107, 1
  store i64 %t108, ptr %l38, !tbaa !24
  br label %bb17
bb17:
  %t109 = load i64, ptr %l5, !tbaa !24
  %t112 = add i64 %t109, 1
  store i64 %t112, ptr %l5, !tbaa !24
  br label %bb13
bb18:
  br label %bb12
bb19:
  store { i64, ptr } zeroinitializer, ptr %l33, !tbaa !27
  br label %bb20
bb20:
  %t114 = load i64, ptr %l31
  %t115 = inttoptr i64 %t114 to ptr
  %t116 = load { i64, ptr }, ptr %l33
  %t117 = extractvalue { i64, ptr } %t116, 1
  %t118 = call ptr @__olang_region_or(ptr %t117, ptr null)
  %t119 = icmp ne ptr %t118, null
  %t120 = select i1 %t119, ptr %t118, ptr null
  call void @__olang_region_settle_in(ptr %t115, ptr %t120)
  %t121 = load ptr, ptr %l21, !tbaa !29
  %t122 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t121, i32 0, i32 0
  %t123 = load { i64, ptr }, ptr %t122, !tbaa !27
  store { i64, ptr } %t123, ptr %l52, !tbaa !27
  %t124 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t125 = load ptr, ptr %l21, !tbaa !29
  %t126 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t125, i32 0, i32 0
  store { i64, ptr } %t124, ptr %t126, !tbaa !27
  %t127 = load { i64, ptr }, ptr %l52
  %t128 = extractvalue { i64, ptr } %t127, 0
  %t129 = extractvalue { i64, ptr } %t127, 1
  call void @__olang_region_release_part(ptr %t129, i64 %t128)
  store { i64, ptr } zeroinitializer, ptr %l52
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t130, i32 0, i32 1
  %t133 = load { i64, ptr }, ptr %t132, !tbaa !27
  %t135 = load ptr, ptr %l0, !tbaa !29
  store ptr %t135, ptr %l55, !tbaa !29
  store { i64, ptr } %t133, ptr %l56, !tbaa !27
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t139 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t137, i32 0, i32 3
  %t140 = load i64, ptr %t139, !tbaa !24
  store i64 %t140, ptr %l58, !tbaa !24
  %t141 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t142 = extractvalue { i64, ptr } %t141, 0
  store i64 %t142, ptr %l59, !tbaa !24
  %t143 = icmp sge i64 0, 0
  br i1 %t143, label %bb21, label %bb22
bb21:
  %t145 = load i64, ptr %l58, !tbaa !24
  %t146 = icmp sle i64 0, %t145
  br i1 %t146, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_286d44cd953550de_d0d5fc71fd1a284a)
  unreachable
bb23:
  %t148 = load i64, ptr %l58, !tbaa !24
  %t149 = load i64, ptr %l59, !tbaa !24
  %t150 = icmp sle i64 %t148, %t149
  br i1 %t150, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_286d44cd953550de_d0d5fc71fd1a284a)
  unreachable
bb25:
  %t152 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t153 = load ptr, ptr %t152, !tbaa !27
  %t154 = load i64, ptr %l58, !tbaa !24
  %t155 = getelementptr i64, ptr %t153, i64 0
  %t156 = sub i64 %t154, 0
  %t157 = insertvalue { i64, ptr } undef, i64 %t156, 0
  %t158 = insertvalue { i64, ptr } %t157, ptr %t155, 1
  store { i64, ptr } %t158, ptr %l7, !tbaa !27
  %t160 = load i64, ptr %l1, !tbaa !24
  %t162 = call ptr @__olang_region_make_part(ptr %v0)
  %t163 = ptrtoint ptr %t162 to i64
  store i64 %t163, ptr %l65, !tbaa !24
  store i64 %t160, ptr %l66, !tbaa !24
  %t165 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t167 = load i64, ptr %l66, !tbaa !24
  %t168 = extractvalue { i64, ptr } %t165, 0
  %t169 = mul i64 %t168, 8
  %t170 = mul i64 %t167, 8
  %t171 = extractvalue { i64, ptr } %t165, 1
  %t172 = call ptr @__olang_grow_in_place(ptr %t171, i64 %t169, i64 %t170, i64 %t167)
  %t173 = icmp ne ptr %t172, null
  %t174 = select i1 %t173, i64 %t167, i64 0
  %t175 = insertvalue { i64, ptr } undef, i64 %t174, 0
  %t176 = insertvalue { i64, ptr } %t175, ptr %t172, 1
  store { i64, ptr } %t176, ptr %l69, !tbaa !27
  %t177 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t178 = extractvalue { i64, ptr } %t177, 0
  %t180 = icmp ne i64 %t178, 0
  br i1 %t180, label %bb27, label %bb28
bb26:
  call void @__olang_check_failed(ptr @olang_loc_286d44cd953550de_d0d5fc71fd1a284a)
  unreachable
bb27:
  %t182 = load { i64, ptr }, ptr %l69, !tbaa !27
  store { i64, ptr } %t182, ptr %l67, !tbaa !27
  br label %bb29
bb28:
  %t183 = load i64, ptr %l66, !tbaa !24
  %t184 = mul i64 %t183, 8
  %t185 = load i64, ptr %l65
  %t186 = inttoptr i64 %t185 to ptr
  %t187 = call ptr @__olang_held_alloc(ptr %t186, i64 %t184)
  %t188 = insertvalue { i64, ptr } undef, i64 %t183, 0
  %t189 = insertvalue { i64, ptr } %t188, ptr %t187, 1
  store { i64, ptr } %t189, ptr %l67, !tbaa !27
  store i64 0, ptr %l72, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb30
bb29:
  %t190 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t191 = extractvalue { i64, ptr } %t190, 0
  %t193 = icmp eq i64 %t191, 0
  br i1 %t193, label %bb36, label %bb37
bb30:
  %t195 = load i64, ptr %l9, !tbaa !24
  %t196 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t198 = extractvalue { i64, ptr } %t196, 0
  %t201 = icmp slt i64 %t195, %t198
  %t203 = xor i1 %t201, true
  br i1 %t203, label %bb31, label %bb32
bb31:
  br label %bb35
bb32:
  br label %bb33
bb33:
  %t205 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t205, ptr %l78, !tbaa !27
  %t206 = load i64, ptr %l9, !tbaa !24
  %t208 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t209 = load ptr, ptr %t208, !tbaa !27
  %t210 = getelementptr i64, ptr %t209, i64 %t206
  %t211 = load i64, ptr %t210, !tbaa !34
  %t213 = load i64, ptr %l72, !tbaa !24
  %t214 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t215 = load ptr, ptr %t214, !tbaa !27
  %t216 = getelementptr i64, ptr %t215, i64 %t213
  store i64 %t211, ptr %t216, !tbaa !34
  %t217 = load i64, ptr %l72, !tbaa !24
  %t218 = add i64 %t217, 1
  store i64 %t218, ptr %l72, !tbaa !24
  br label %bb34
bb34:
  %t219 = load i64, ptr %l9, !tbaa !24
  %t222 = add i64 %t219, 1
  store i64 %t222, ptr %l9, !tbaa !24
  br label %bb30
bb35:
  br label %bb29
bb36:
  store { i64, ptr } zeroinitializer, ptr %l67, !tbaa !27
  br label %bb37
bb37:
  %t224 = load i64, ptr %l65
  %t225 = inttoptr i64 %t224 to ptr
  %t226 = load { i64, ptr }, ptr %l67
  %t227 = extractvalue { i64, ptr } %t226, 1
  %t228 = call ptr @__olang_region_or(ptr %t227, ptr null)
  %t229 = icmp ne ptr %t228, null
  %t230 = select i1 %t229, ptr %t228, ptr null
  call void @__olang_region_settle_in(ptr %t225, ptr %t230)
  %t231 = load ptr, ptr %l55, !tbaa !29
  %t232 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t231, i32 0, i32 1
  %t233 = load { i64, ptr }, ptr %t232, !tbaa !27
  store { i64, ptr } %t233, ptr %l86, !tbaa !27
  %t234 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t235 = load ptr, ptr %l55, !tbaa !29
  %t236 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t235, i32 0, i32 1
  store { i64, ptr } %t234, ptr %t236, !tbaa !27
  %t237 = load { i64, ptr }, ptr %l86
  %t238 = extractvalue { i64, ptr } %t237, 0
  %t239 = extractvalue { i64, ptr } %t237, 1
  call void @__olang_region_release_part(ptr %t239, i64 %t238)
  store { i64, ptr } zeroinitializer, ptr %l86
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H335f5042d0dc56bacbac76a21761a9ba(ptr %v0, ptr %a0) noinline cold #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l5 = alloca i64
  %l7 = alloca { i64, ptr }
  %l9 = alloca i64
  %l14 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l31 = alloca i64
  %l32 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l37 = alloca i64
  %l43 = alloca { i64, ptr }
  %l53 = alloca ptr
  %l54 = alloca { i64, ptr }
  %l56 = alloca i64
  %l57 = alloca i64
  %l63 = alloca i64
  %l64 = alloca i64
  %l65 = alloca { i64, ptr }
  %l67 = alloca { i64, ptr }
  %l70 = alloca i64
  %l76 = alloca { i64, ptr }
  %l84 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp slt i64 %t6, 4
  br i1 %t8, label %bb1, label %bb2
bb1:
  store i64 8, ptr %l14, !tbaa !24
  br label %bb3
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t17 = mul i64 %t15, 2
  store i64 %t17, ptr %l14, !tbaa !24
  br label %bb3
bb3:
  %t19 = load i64, ptr %l14, !tbaa !24
  store i64 %t19, ptr %l1, !tbaa !24
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t20, i32 0, i32 0
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !27
  store { i64, ptr } %t23, ptr %l2, !tbaa !27
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l21, !tbaa !29
  %t26 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t26, ptr %l22, !tbaa !27
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t27, i32 0, i32 3
  %t30 = load i64, ptr %t29, !tbaa !24
  store i64 %t30, ptr %l24, !tbaa !24
  %t31 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  store i64 %t32, ptr %l25, !tbaa !24
  %t33 = icmp sge i64 0, 0
  br i1 %t33, label %bb4, label %bb5
bb4:
  %t35 = load i64, ptr %l24, !tbaa !24
  %t36 = icmp sle i64 0, %t35
  br i1 %t36, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_774282684c71143f_50171c9d0a1ed80b)
  unreachable
bb6:
  %t38 = load i64, ptr %l24, !tbaa !24
  %t39 = load i64, ptr %l25, !tbaa !24
  %t40 = icmp sle i64 %t38, %t39
  br i1 %t40, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_774282684c71143f_50171c9d0a1ed80b)
  unreachable
bb8:
  %t42 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = load i64, ptr %l24, !tbaa !24
  %t45 = getelementptr %"std/prelude/map:MapEntry.1b1d537c79dee3d5948de1b7c1a79d8b", ptr %t43, i64 0
  %t46 = sub i64 %t44, 0
  %t47 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t45, 1
  store { i64, ptr } %t48, ptr %l3, !tbaa !27
  %t50 = load i64, ptr %l1, !tbaa !24
  store i64 %t50, ptr %l31, !tbaa !24
  %t53 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t55 = load i64, ptr %l31, !tbaa !24
  %t56 = extractvalue { i64, ptr } %t53, 0
  %t57 = mul i64 %t56, 40
  %t58 = mul i64 %t55, 40
  %t59 = extractvalue { i64, ptr } %t53, 1
  %t60 = call ptr @__olang_grow_in_place(ptr %t59, i64 %t57, i64 %t58, i64 %t55)
  %t61 = icmp ne ptr %t60, null
  %t62 = select i1 %t61, i64 %t55, i64 0
  %t63 = insertvalue { i64, ptr } undef, i64 %t62, 0
  %t64 = insertvalue { i64, ptr } %t63, ptr %t60, 1
  store { i64, ptr } %t64, ptr %l34, !tbaa !27
  %t65 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t66 = extractvalue { i64, ptr } %t65, 0
  %t68 = icmp ne i64 %t66, 0
  br i1 %t68, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_774282684c71143f_50171c9d0a1ed80b)
  unreachable
bb10:
  %t70 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t70, ptr %l32, !tbaa !27
  br label %bb12
bb11:
  %t71 = load i64, ptr %l31, !tbaa !24
  %t72 = mul i64 %t71, 40
  %t73 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t72)
  %t74 = insertvalue { i64, ptr } undef, i64 %t71, 0
  %t75 = insertvalue { i64, ptr } %t74, ptr %t73, 1
  store { i64, ptr } %t75, ptr %l32, !tbaa !27
  store i64 0, ptr %l37, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb13
bb12:
  %t76 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t77 = load ptr, ptr %l21, !tbaa !29
  %t78 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t77, i32 0, i32 0
  store { i64, ptr } %t76, ptr %t78, !tbaa !27
  %t79 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t81, i32 0, i32 1
  %t84 = load { i64, ptr }, ptr %t83, !tbaa !27
  %t86 = load ptr, ptr %l0, !tbaa !29
  store ptr %t86, ptr %l53, !tbaa !29
  store { i64, ptr } %t84, ptr %l54, !tbaa !27
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t88, i32 0, i32 3
  %t91 = load i64, ptr %t90, !tbaa !24
  store i64 %t91, ptr %l56, !tbaa !24
  %t92 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t93 = extractvalue { i64, ptr } %t92, 0
  store i64 %t93, ptr %l57, !tbaa !24
  %t94 = icmp sge i64 0, 0
  br i1 %t94, label %bb19, label %bb20
bb13:
  %t96 = load i64, ptr %l5, !tbaa !24
  %t97 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t99 = extractvalue { i64, ptr } %t97, 0
  %t102 = icmp slt i64 %t96, %t99
  %t104 = xor i1 %t102, true
  br i1 %t104, label %bb14, label %bb15
bb14:
  br label %bb18
bb15:
  br label %bb16
bb16:
  %t106 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t106, ptr %l43, !tbaa !27
  %t107 = load i64, ptr %l5, !tbaa !24
  %t109 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t110 = load ptr, ptr %t109, !tbaa !27
  %t111 = getelementptr %"std/prelude/map:MapEntry.1b1d537c79dee3d5948de1b7c1a79d8b", ptr %t110, i64 %t107
  %t112 = load %"std/prelude/map:MapEntry.1b1d537c79dee3d5948de1b7c1a79d8b", ptr %t111
  %t114 = load i64, ptr %l37, !tbaa !24
  %t115 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !27
  %t117 = getelementptr %"std/prelude/map:MapEntry.1b1d537c79dee3d5948de1b7c1a79d8b", ptr %t116, i64 %t114
  store %"std/prelude/map:MapEntry.1b1d537c79dee3d5948de1b7c1a79d8b" %t112, ptr %t117
  %t118 = load i64, ptr %l37, !tbaa !24
  %t119 = add i64 %t118, 1
  store i64 %t119, ptr %l37, !tbaa !24
  br label %bb17
bb17:
  %t120 = load i64, ptr %l5, !tbaa !24
  %t123 = add i64 %t120, 1
  store i64 %t123, ptr %l5, !tbaa !24
  br label %bb13
bb18:
  br label %bb12
bb19:
  %t125 = load i64, ptr %l56, !tbaa !24
  %t126 = icmp sle i64 0, %t125
  br i1 %t126, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_e15a83023a4fd242_c4a6dc6ba0248c0e)
  unreachable
bb21:
  %t128 = load i64, ptr %l56, !tbaa !24
  %t129 = load i64, ptr %l57, !tbaa !24
  %t130 = icmp sle i64 %t128, %t129
  br i1 %t130, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_e15a83023a4fd242_c4a6dc6ba0248c0e)
  unreachable
bb23:
  %t132 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !27
  %t134 = load i64, ptr %l56, !tbaa !24
  %t135 = getelementptr i64, ptr %t133, i64 0
  %t136 = sub i64 %t134, 0
  %t137 = insertvalue { i64, ptr } undef, i64 %t136, 0
  %t138 = insertvalue { i64, ptr } %t137, ptr %t135, 1
  store { i64, ptr } %t138, ptr %l7, !tbaa !27
  %t140 = load i64, ptr %l1, !tbaa !24
  %t142 = call ptr @__olang_region_make_part(ptr %v0)
  %t143 = ptrtoint ptr %t142 to i64
  store i64 %t143, ptr %l63, !tbaa !24
  store i64 %t140, ptr %l64, !tbaa !24
  %t145 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t147 = load i64, ptr %l64, !tbaa !24
  %t148 = extractvalue { i64, ptr } %t145, 0
  %t149 = mul i64 %t148, 8
  %t150 = mul i64 %t147, 8
  %t151 = extractvalue { i64, ptr } %t145, 1
  %t152 = call ptr @__olang_grow_in_place(ptr %t151, i64 %t149, i64 %t150, i64 %t147)
  %t153 = icmp ne ptr %t152, null
  %t154 = select i1 %t153, i64 %t147, i64 0
  %t155 = insertvalue { i64, ptr } undef, i64 %t154, 0
  %t156 = insertvalue { i64, ptr } %t155, ptr %t152, 1
  store { i64, ptr } %t156, ptr %l67, !tbaa !27
  %t157 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t158 = extractvalue { i64, ptr } %t157, 0
  %t160 = icmp ne i64 %t158, 0
  br i1 %t160, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_e15a83023a4fd242_c4a6dc6ba0248c0e)
  unreachable
bb25:
  %t162 = load { i64, ptr }, ptr %l67, !tbaa !27
  store { i64, ptr } %t162, ptr %l65, !tbaa !27
  br label %bb27
bb26:
  %t163 = load i64, ptr %l64, !tbaa !24
  %t164 = mul i64 %t163, 8
  %t165 = load i64, ptr %l63
  %t166 = inttoptr i64 %t165 to ptr
  %t167 = call ptr @__olang_held_alloc(ptr %t166, i64 %t164)
  %t168 = insertvalue { i64, ptr } undef, i64 %t163, 0
  %t169 = insertvalue { i64, ptr } %t168, ptr %t167, 1
  store { i64, ptr } %t169, ptr %l65, !tbaa !27
  store i64 0, ptr %l70, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb28
bb27:
  %t170 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t171 = extractvalue { i64, ptr } %t170, 0
  %t173 = icmp eq i64 %t171, 0
  br i1 %t173, label %bb34, label %bb35
bb28:
  %t175 = load i64, ptr %l9, !tbaa !24
  %t176 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t178 = extractvalue { i64, ptr } %t176, 0
  %t181 = icmp slt i64 %t175, %t178
  %t183 = xor i1 %t181, true
  br i1 %t183, label %bb29, label %bb30
bb29:
  br label %bb33
bb30:
  br label %bb31
bb31:
  %t185 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t185, ptr %l76, !tbaa !27
  %t186 = load i64, ptr %l9, !tbaa !24
  %t188 = getelementptr { i64, ptr }, ptr %l76, i32 0, i32 1
  %t189 = load ptr, ptr %t188, !tbaa !27
  %t190 = getelementptr i64, ptr %t189, i64 %t186
  %t191 = load i64, ptr %t190, !tbaa !34
  %t193 = load i64, ptr %l70, !tbaa !24
  %t194 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t195 = load ptr, ptr %t194, !tbaa !27
  %t196 = getelementptr i64, ptr %t195, i64 %t193
  store i64 %t191, ptr %t196, !tbaa !34
  %t197 = load i64, ptr %l70, !tbaa !24
  %t198 = add i64 %t197, 1
  store i64 %t198, ptr %l70, !tbaa !24
  br label %bb32
bb32:
  %t199 = load i64, ptr %l9, !tbaa !24
  %t202 = add i64 %t199, 1
  store i64 %t202, ptr %l9, !tbaa !24
  br label %bb28
bb33:
  br label %bb27
bb34:
  store { i64, ptr } zeroinitializer, ptr %l65, !tbaa !27
  br label %bb35
bb35:
  %t204 = load i64, ptr %l63
  %t205 = inttoptr i64 %t204 to ptr
  %t206 = load { i64, ptr }, ptr %l65
  %t207 = extractvalue { i64, ptr } %t206, 1
  %t208 = call ptr @__olang_region_or(ptr %t207, ptr null)
  %t209 = icmp ne ptr %t208, null
  %t210 = select i1 %t209, ptr %t208, ptr null
  call void @__olang_region_settle_in(ptr %t205, ptr %t210)
  %t211 = load ptr, ptr %l53, !tbaa !29
  %t212 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t211, i32 0, i32 1
  %t213 = load { i64, ptr }, ptr %t212, !tbaa !27
  store { i64, ptr } %t213, ptr %l84, !tbaa !27
  %t214 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t215 = load ptr, ptr %l53, !tbaa !29
  %t216 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t215, i32 0, i32 1
  store { i64, ptr } %t214, ptr %t216, !tbaa !27
  %t217 = load { i64, ptr }, ptr %l84
  %t218 = extractvalue { i64, ptr } %t217, 0
  %t219 = extractvalue { i64, ptr } %t217, 1
  call void @__olang_region_release_part(ptr %t219, i64 %t218)
  store { i64, ptr } zeroinitializer, ptr %l84
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H3beef3d8eff582ecf24a3e202e619793(ptr %v0, ptr %a0) noinline cold #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca { i64, ptr }
  %l5 = alloca i64
  %l7 = alloca { i64, ptr }
  %l9 = alloca i64
  %l14 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l38 = alloca i64
  %l44 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %l55 = alloca ptr
  %l56 = alloca { i64, ptr }
  %l58 = alloca i64
  %l59 = alloca i64
  %l65 = alloca i64
  %l66 = alloca i64
  %l67 = alloca { i64, ptr }
  %l69 = alloca { i64, ptr }
  %l72 = alloca i64
  %l78 = alloca { i64, ptr }
  %l86 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp slt i64 %t6, 4
  br i1 %t8, label %bb1, label %bb2
bb1:
  store i64 8, ptr %l14, !tbaa !24
  br label %bb3
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t17 = mul i64 %t15, 2
  store i64 %t17, ptr %l14, !tbaa !24
  br label %bb3
bb3:
  %t19 = load i64, ptr %l14, !tbaa !24
  store i64 %t19, ptr %l1, !tbaa !24
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t20, i32 0, i32 0
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !27
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l21, !tbaa !29
  store { i64, ptr } %t23, ptr %l22, !tbaa !27
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t27, i32 0, i32 3
  %t30 = load i64, ptr %t29, !tbaa !24
  store i64 %t30, ptr %l24, !tbaa !24
  %t31 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  store i64 %t32, ptr %l25, !tbaa !24
  %t33 = icmp sge i64 0, 0
  br i1 %t33, label %bb4, label %bb5
bb4:
  %t35 = load i64, ptr %l24, !tbaa !24
  %t36 = icmp sle i64 0, %t35
  br i1 %t36, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_39d4b9cd0aa741ac_83bc004070fe27a0)
  unreachable
bb6:
  %t38 = load i64, ptr %l24, !tbaa !24
  %t39 = load i64, ptr %l25, !tbaa !24
  %t40 = icmp sle i64 %t38, %t39
  br i1 %t40, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_39d4b9cd0aa741ac_83bc004070fe27a0)
  unreachable
bb8:
  %t42 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = load i64, ptr %l24, !tbaa !24
  %t45 = getelementptr %"std/prelude/map:MapEntry.3418582855447f8ba2b65b4532371b2a", ptr %t43, i64 0
  %t46 = sub i64 %t44, 0
  %t47 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t45, 1
  store { i64, ptr } %t48, ptr %l3, !tbaa !27
  %t50 = load i64, ptr %l1, !tbaa !24
  %t52 = call ptr @__olang_region_make_part(ptr %v0)
  %t53 = ptrtoint ptr %t52 to i64
  store i64 %t53, ptr %l31, !tbaa !24
  store i64 %t50, ptr %l32, !tbaa !24
  %t55 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t57 = load i64, ptr %l32, !tbaa !24
  %t58 = extractvalue { i64, ptr } %t55, 0
  %t59 = mul i64 %t58, 24
  %t60 = mul i64 %t57, 24
  %t61 = extractvalue { i64, ptr } %t55, 1
  %t62 = call ptr @__olang_grow_in_place(ptr %t61, i64 %t59, i64 %t60, i64 %t57)
  %t63 = icmp ne ptr %t62, null
  %t64 = select i1 %t63, i64 %t57, i64 0
  %t65 = insertvalue { i64, ptr } undef, i64 %t64, 0
  %t66 = insertvalue { i64, ptr } %t65, ptr %t62, 1
  store { i64, ptr } %t66, ptr %l35, !tbaa !27
  %t67 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t68 = extractvalue { i64, ptr } %t67, 0
  %t70 = icmp ne i64 %t68, 0
  br i1 %t70, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_39d4b9cd0aa741ac_83bc004070fe27a0)
  unreachable
bb10:
  %t72 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t72, ptr %l33, !tbaa !27
  br label %bb12
bb11:
  %t73 = load i64, ptr %l32, !tbaa !24
  %t74 = mul i64 %t73, 24
  %t75 = load i64, ptr %l31
  %t76 = inttoptr i64 %t75 to ptr
  %t77 = call ptr @__olang_held_alloc(ptr %t76, i64 %t74)
  %t78 = insertvalue { i64, ptr } undef, i64 %t73, 0
  %t79 = insertvalue { i64, ptr } %t78, ptr %t77, 1
  store { i64, ptr } %t79, ptr %l33, !tbaa !27
  store i64 0, ptr %l38, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb13
bb12:
  %t80 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t81 = extractvalue { i64, ptr } %t80, 0
  %t83 = icmp eq i64 %t81, 0
  br i1 %t83, label %bb19, label %bb20
bb13:
  %t85 = load i64, ptr %l5, !tbaa !24
  %t86 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t88 = extractvalue { i64, ptr } %t86, 0
  %t91 = icmp slt i64 %t85, %t88
  %t93 = xor i1 %t91, true
  br i1 %t93, label %bb14, label %bb15
bb14:
  br label %bb18
bb15:
  br label %bb16
bb16:
  %t95 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t95, ptr %l44, !tbaa !27
  %t96 = load i64, ptr %l5, !tbaa !24
  %t98 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !27
  %t100 = getelementptr %"std/prelude/map:MapEntry.3418582855447f8ba2b65b4532371b2a", ptr %t99, i64 %t96
  %t101 = load %"std/prelude/map:MapEntry.3418582855447f8ba2b65b4532371b2a", ptr %t100
  %t103 = load i64, ptr %l38, !tbaa !24
  %t104 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !27
  %t106 = getelementptr %"std/prelude/map:MapEntry.3418582855447f8ba2b65b4532371b2a", ptr %t105, i64 %t103
  store %"std/prelude/map:MapEntry.3418582855447f8ba2b65b4532371b2a" %t101, ptr %t106
  %t107 = load i64, ptr %l38, !tbaa !24
  %t108 = add i64 %t107, 1
  store i64 %t108, ptr %l38, !tbaa !24
  br label %bb17
bb17:
  %t109 = load i64, ptr %l5, !tbaa !24
  %t112 = add i64 %t109, 1
  store i64 %t112, ptr %l5, !tbaa !24
  br label %bb13
bb18:
  br label %bb12
bb19:
  store { i64, ptr } zeroinitializer, ptr %l33, !tbaa !27
  br label %bb20
bb20:
  %t114 = load i64, ptr %l31
  %t115 = inttoptr i64 %t114 to ptr
  %t116 = load { i64, ptr }, ptr %l33
  %t117 = extractvalue { i64, ptr } %t116, 1
  %t118 = call ptr @__olang_region_or(ptr %t117, ptr null)
  %t119 = icmp ne ptr %t118, null
  %t120 = select i1 %t119, ptr %t118, ptr null
  call void @__olang_region_settle_in(ptr %t115, ptr %t120)
  %t121 = load ptr, ptr %l21, !tbaa !29
  %t122 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t121, i32 0, i32 0
  %t123 = load { i64, ptr }, ptr %t122, !tbaa !27
  store { i64, ptr } %t123, ptr %l52, !tbaa !27
  %t124 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t125 = load ptr, ptr %l21, !tbaa !29
  %t126 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t125, i32 0, i32 0
  store { i64, ptr } %t124, ptr %t126, !tbaa !27
  %t127 = load { i64, ptr }, ptr %l52
  %t128 = extractvalue { i64, ptr } %t127, 0
  %t129 = extractvalue { i64, ptr } %t127, 1
  call void @__olang_region_release_part(ptr %t129, i64 %t128)
  store { i64, ptr } zeroinitializer, ptr %l52
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t130, i32 0, i32 1
  %t133 = load { i64, ptr }, ptr %t132, !tbaa !27
  %t135 = load ptr, ptr %l0, !tbaa !29
  store ptr %t135, ptr %l55, !tbaa !29
  store { i64, ptr } %t133, ptr %l56, !tbaa !27
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t139 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t137, i32 0, i32 3
  %t140 = load i64, ptr %t139, !tbaa !24
  store i64 %t140, ptr %l58, !tbaa !24
  %t141 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t142 = extractvalue { i64, ptr } %t141, 0
  store i64 %t142, ptr %l59, !tbaa !24
  %t143 = icmp sge i64 0, 0
  br i1 %t143, label %bb21, label %bb22
bb21:
  %t145 = load i64, ptr %l58, !tbaa !24
  %t146 = icmp sle i64 0, %t145
  br i1 %t146, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_fee251769c24e159_88d5f6af9df801fd)
  unreachable
bb23:
  %t148 = load i64, ptr %l58, !tbaa !24
  %t149 = load i64, ptr %l59, !tbaa !24
  %t150 = icmp sle i64 %t148, %t149
  br i1 %t150, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_fee251769c24e159_88d5f6af9df801fd)
  unreachable
bb25:
  %t152 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t153 = load ptr, ptr %t152, !tbaa !27
  %t154 = load i64, ptr %l58, !tbaa !24
  %t155 = getelementptr i64, ptr %t153, i64 0
  %t156 = sub i64 %t154, 0
  %t157 = insertvalue { i64, ptr } undef, i64 %t156, 0
  %t158 = insertvalue { i64, ptr } %t157, ptr %t155, 1
  store { i64, ptr } %t158, ptr %l7, !tbaa !27
  %t160 = load i64, ptr %l1, !tbaa !24
  %t162 = call ptr @__olang_region_make_part(ptr %v0)
  %t163 = ptrtoint ptr %t162 to i64
  store i64 %t163, ptr %l65, !tbaa !24
  store i64 %t160, ptr %l66, !tbaa !24
  %t165 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t167 = load i64, ptr %l66, !tbaa !24
  %t168 = extractvalue { i64, ptr } %t165, 0
  %t169 = mul i64 %t168, 8
  %t170 = mul i64 %t167, 8
  %t171 = extractvalue { i64, ptr } %t165, 1
  %t172 = call ptr @__olang_grow_in_place(ptr %t171, i64 %t169, i64 %t170, i64 %t167)
  %t173 = icmp ne ptr %t172, null
  %t174 = select i1 %t173, i64 %t167, i64 0
  %t175 = insertvalue { i64, ptr } undef, i64 %t174, 0
  %t176 = insertvalue { i64, ptr } %t175, ptr %t172, 1
  store { i64, ptr } %t176, ptr %l69, !tbaa !27
  %t177 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t178 = extractvalue { i64, ptr } %t177, 0
  %t180 = icmp ne i64 %t178, 0
  br i1 %t180, label %bb27, label %bb28
bb26:
  call void @__olang_check_failed(ptr @olang_loc_fee251769c24e159_88d5f6af9df801fd)
  unreachable
bb27:
  %t182 = load { i64, ptr }, ptr %l69, !tbaa !27
  store { i64, ptr } %t182, ptr %l67, !tbaa !27
  br label %bb29
bb28:
  %t183 = load i64, ptr %l66, !tbaa !24
  %t184 = mul i64 %t183, 8
  %t185 = load i64, ptr %l65
  %t186 = inttoptr i64 %t185 to ptr
  %t187 = call ptr @__olang_held_alloc(ptr %t186, i64 %t184)
  %t188 = insertvalue { i64, ptr } undef, i64 %t183, 0
  %t189 = insertvalue { i64, ptr } %t188, ptr %t187, 1
  store { i64, ptr } %t189, ptr %l67, !tbaa !27
  store i64 0, ptr %l72, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb30
bb29:
  %t190 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t191 = extractvalue { i64, ptr } %t190, 0
  %t193 = icmp eq i64 %t191, 0
  br i1 %t193, label %bb36, label %bb37
bb30:
  %t195 = load i64, ptr %l9, !tbaa !24
  %t196 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t198 = extractvalue { i64, ptr } %t196, 0
  %t201 = icmp slt i64 %t195, %t198
  %t203 = xor i1 %t201, true
  br i1 %t203, label %bb31, label %bb32
bb31:
  br label %bb35
bb32:
  br label %bb33
bb33:
  %t205 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t205, ptr %l78, !tbaa !27
  %t206 = load i64, ptr %l9, !tbaa !24
  %t208 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t209 = load ptr, ptr %t208, !tbaa !27
  %t210 = getelementptr i64, ptr %t209, i64 %t206
  %t211 = load i64, ptr %t210, !tbaa !34
  %t213 = load i64, ptr %l72, !tbaa !24
  %t214 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t215 = load ptr, ptr %t214, !tbaa !27
  %t216 = getelementptr i64, ptr %t215, i64 %t213
  store i64 %t211, ptr %t216, !tbaa !34
  %t217 = load i64, ptr %l72, !tbaa !24
  %t218 = add i64 %t217, 1
  store i64 %t218, ptr %l72, !tbaa !24
  br label %bb34
bb34:
  %t219 = load i64, ptr %l9, !tbaa !24
  %t222 = add i64 %t219, 1
  store i64 %t222, ptr %l9, !tbaa !24
  br label %bb30
bb35:
  br label %bb29
bb36:
  store { i64, ptr } zeroinitializer, ptr %l67, !tbaa !27
  br label %bb37
bb37:
  %t224 = load i64, ptr %l65
  %t225 = inttoptr i64 %t224 to ptr
  %t226 = load { i64, ptr }, ptr %l67
  %t227 = extractvalue { i64, ptr } %t226, 1
  %t228 = call ptr @__olang_region_or(ptr %t227, ptr null)
  %t229 = icmp ne ptr %t228, null
  %t230 = select i1 %t229, ptr %t228, ptr null
  call void @__olang_region_settle_in(ptr %t225, ptr %t230)
  %t231 = load ptr, ptr %l55, !tbaa !29
  %t232 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t231, i32 0, i32 1
  %t233 = load { i64, ptr }, ptr %t232, !tbaa !27
  store { i64, ptr } %t233, ptr %l86, !tbaa !27
  %t234 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t235 = load ptr, ptr %l55, !tbaa !29
  %t236 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t235, i32 0, i32 1
  store { i64, ptr } %t234, ptr %t236, !tbaa !27
  %t237 = load { i64, ptr }, ptr %l86
  %t238 = extractvalue { i64, ptr } %t237, 0
  %t239 = extractvalue { i64, ptr } %t237, 1
  call void @__olang_region_release_part(ptr %t239, i64 %t238)
  store { i64, ptr } zeroinitializer, ptr %l86
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H3cf9386e72489334d71359093abeedb1(ptr %v0, ptr %a0) noinline cold #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca { i64, ptr }
  %l5 = alloca i64
  %l7 = alloca { i64, ptr }
  %l9 = alloca i64
  %l14 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l31 = alloca i64
  %l33 = alloca { i64, ptr }
  %l34 = alloca i64
  %l40 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l51 = alloca ptr
  %l52 = alloca { i64, ptr }
  %l54 = alloca i64
  %l55 = alloca i64
  %l61 = alloca i64
  %l62 = alloca i64
  %l63 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %l68 = alloca i64
  %l74 = alloca { i64, ptr }
  %l82 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp slt i64 %t6, 4
  br i1 %t8, label %bb1, label %bb2
bb1:
  store i64 8, ptr %l14, !tbaa !24
  br label %bb3
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t17 = mul i64 %t15, 2
  store i64 %t17, ptr %l14, !tbaa !24
  br label %bb3
bb3:
  %t19 = load i64, ptr %l14, !tbaa !24
  store i64 %t19, ptr %l1, !tbaa !24
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t20, i32 0, i32 0
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !27
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l21, !tbaa !29
  store { i64, ptr } %t23, ptr %l22, !tbaa !27
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t27, i32 0, i32 3
  %t30 = load i64, ptr %t29, !tbaa !24
  store i64 %t30, ptr %l24, !tbaa !24
  %t31 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  store i64 %t32, ptr %l25, !tbaa !24
  %t33 = icmp sge i64 0, 0
  br i1 %t33, label %bb4, label %bb5
bb4:
  %t35 = load i64, ptr %l24, !tbaa !24
  %t36 = icmp sle i64 0, %t35
  br i1 %t36, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_d09d4290b7da555d_4aaf343b9bec4899)
  unreachable
bb6:
  %t38 = load i64, ptr %l24, !tbaa !24
  %t39 = load i64, ptr %l25, !tbaa !24
  %t40 = icmp sle i64 %t38, %t39
  br i1 %t40, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_d09d4290b7da555d_4aaf343b9bec4899)
  unreachable
bb8:
  %t42 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = load i64, ptr %l24, !tbaa !24
  %t45 = getelementptr %"std/prelude/map:MapEntry.5d90ea23f235d8870da3668e82c28edd", ptr %t43, i64 0
  %t46 = sub i64 %t44, 0
  %t47 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t45, 1
  store { i64, ptr } %t48, ptr %l3, !tbaa !27
  %t50 = load i64, ptr %l1, !tbaa !24
  %t52 = call ptr @__olang_region_make_part(ptr %v0)
  %t53 = ptrtoint ptr %t52 to i64
  store i64 %t53, ptr %l31, !tbaa !24
  %t56 = mul i64 %t50, 72
  %t57 = load i64, ptr %l31
  %t58 = inttoptr i64 %t57 to ptr
  %t59 = call ptr @__olang_scope_alloc_zeroed(ptr %t58, i64 %t56)
  %t60 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t61 = insertvalue { i64, ptr } %t60, ptr %t59, 1
  store { i64, ptr } %t61, ptr %l33, !tbaa !27
  store i64 0, ptr %l34, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_d09d4290b7da555d_4aaf343b9bec4899)
  unreachable
bb10:
  %t62 = load i64, ptr %l5, !tbaa !24
  %t63 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t63, 0
  %t68 = icmp slt i64 %t62, %t65
  %t70 = xor i1 %t68, true
  br i1 %t70, label %bb11, label %bb12
bb11:
  br label %bb15
bb12:
  br label %bb13
bb13:
  %t72 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t72, ptr %l40, !tbaa !27
  %t73 = load i64, ptr %l5, !tbaa !24
  %t75 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = getelementptr %"std/prelude/map:MapEntry.5d90ea23f235d8870da3668e82c28edd", ptr %t76, i64 %t73
  %t78 = load %"std/prelude/map:MapEntry.5d90ea23f235d8870da3668e82c28edd", ptr %t77
  store %"std/prelude/map:MapEntry.5d90ea23f235d8870da3668e82c28edd" zeroinitializer, ptr %t77
  %t80 = load i64, ptr %l34, !tbaa !24
  %t81 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !27
  %t83 = getelementptr %"std/prelude/map:MapEntry.5d90ea23f235d8870da3668e82c28edd", ptr %t82, i64 %t80
  store %"std/prelude/map:MapEntry.5d90ea23f235d8870da3668e82c28edd" %t78, ptr %t83
  %t84 = load i64, ptr %l34, !tbaa !24
  %t85 = add i64 %t84, 1
  store i64 %t85, ptr %l34, !tbaa !24
  br label %bb14
bb14:
  %t86 = load i64, ptr %l5, !tbaa !24
  %t89 = add i64 %t86, 1
  store i64 %t89, ptr %l5, !tbaa !24
  br label %bb10
bb15:
  %t91 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t92 = extractvalue { i64, ptr } %t91, 0
  %t94 = icmp eq i64 %t92, 0
  br i1 %t94, label %bb16, label %bb17
bb16:
  store { i64, ptr } zeroinitializer, ptr %l33, !tbaa !27
  br label %bb17
bb17:
  %t96 = load i64, ptr %l31
  %t97 = inttoptr i64 %t96 to ptr
  %t98 = load { i64, ptr }, ptr %l33
  %t99 = extractvalue { i64, ptr } %t98, 1
  %t100 = call ptr @__olang_region_or(ptr %t99, ptr null)
  %t101 = icmp ne ptr %t100, null
  %t102 = select i1 %t101, ptr %t100, ptr null
  call void @__olang_region_settle_in(ptr %t97, ptr %t102)
  %t103 = load ptr, ptr %l21, !tbaa !29
  %t104 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t103, i32 0, i32 0
  %t105 = load { i64, ptr }, ptr %t104, !tbaa !27
  store { i64, ptr } %t105, ptr %l48, !tbaa !27
  %t106 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t107 = load ptr, ptr %l21, !tbaa !29
  %t108 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t107, i32 0, i32 0
  store { i64, ptr } %t106, ptr %t108, !tbaa !27
  %t109 = load { i64, ptr }, ptr %l48
  %t110 = extractvalue { i64, ptr } %t109, 0
  %t111 = extractvalue { i64, ptr } %t109, 1
  call void @__olang_region_release_part(ptr %t111, i64 %t110)
  store { i64, ptr } zeroinitializer, ptr %l48
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t114 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t112, i32 0, i32 1
  %t115 = load { i64, ptr }, ptr %t114, !tbaa !27
  %t117 = load ptr, ptr %l0, !tbaa !29
  store ptr %t117, ptr %l51, !tbaa !29
  store { i64, ptr } %t115, ptr %l52, !tbaa !27
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t121 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t119, i32 0, i32 3
  %t122 = load i64, ptr %t121, !tbaa !24
  store i64 %t122, ptr %l54, !tbaa !24
  %t123 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t124 = extractvalue { i64, ptr } %t123, 0
  store i64 %t124, ptr %l55, !tbaa !24
  %t125 = icmp sge i64 0, 0
  br i1 %t125, label %bb18, label %bb19
bb18:
  %t127 = load i64, ptr %l54, !tbaa !24
  %t128 = icmp sle i64 0, %t127
  br i1 %t128, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_8c25b0a34c040f00_7447c6fffda4a9ec)
  unreachable
bb20:
  %t130 = load i64, ptr %l54, !tbaa !24
  %t131 = load i64, ptr %l55, !tbaa !24
  %t132 = icmp sle i64 %t130, %t131
  br i1 %t132, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_8c25b0a34c040f00_7447c6fffda4a9ec)
  unreachable
bb22:
  %t134 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t135 = load ptr, ptr %t134, !tbaa !27
  %t136 = load i64, ptr %l54, !tbaa !24
  %t137 = getelementptr i64, ptr %t135, i64 0
  %t138 = sub i64 %t136, 0
  %t139 = insertvalue { i64, ptr } undef, i64 %t138, 0
  %t140 = insertvalue { i64, ptr } %t139, ptr %t137, 1
  store { i64, ptr } %t140, ptr %l7, !tbaa !27
  %t142 = load i64, ptr %l1, !tbaa !24
  %t144 = call ptr @__olang_region_make_part(ptr %v0)
  %t145 = ptrtoint ptr %t144 to i64
  store i64 %t145, ptr %l61, !tbaa !24
  store i64 %t142, ptr %l62, !tbaa !24
  %t147 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t149 = load i64, ptr %l62, !tbaa !24
  %t150 = extractvalue { i64, ptr } %t147, 0
  %t151 = mul i64 %t150, 8
  %t152 = mul i64 %t149, 8
  %t153 = extractvalue { i64, ptr } %t147, 1
  %t154 = call ptr @__olang_grow_in_place(ptr %t153, i64 %t151, i64 %t152, i64 %t149)
  %t155 = icmp ne ptr %t154, null
  %t156 = select i1 %t155, i64 %t149, i64 0
  %t157 = insertvalue { i64, ptr } undef, i64 %t156, 0
  %t158 = insertvalue { i64, ptr } %t157, ptr %t154, 1
  store { i64, ptr } %t158, ptr %l65, !tbaa !27
  %t159 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t160 = extractvalue { i64, ptr } %t159, 0
  %t162 = icmp ne i64 %t160, 0
  br i1 %t162, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_8c25b0a34c040f00_7447c6fffda4a9ec)
  unreachable
bb24:
  %t164 = load { i64, ptr }, ptr %l65, !tbaa !27
  store { i64, ptr } %t164, ptr %l63, !tbaa !27
  br label %bb26
bb25:
  %t165 = load i64, ptr %l62, !tbaa !24
  %t166 = mul i64 %t165, 8
  %t167 = load i64, ptr %l61
  %t168 = inttoptr i64 %t167 to ptr
  %t169 = call ptr @__olang_held_alloc(ptr %t168, i64 %t166)
  %t170 = insertvalue { i64, ptr } undef, i64 %t165, 0
  %t171 = insertvalue { i64, ptr } %t170, ptr %t169, 1
  store { i64, ptr } %t171, ptr %l63, !tbaa !27
  store i64 0, ptr %l68, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb27
bb26:
  %t172 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t173 = extractvalue { i64, ptr } %t172, 0
  %t175 = icmp eq i64 %t173, 0
  br i1 %t175, label %bb33, label %bb34
bb27:
  %t177 = load i64, ptr %l9, !tbaa !24
  %t178 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t180 = extractvalue { i64, ptr } %t178, 0
  %t183 = icmp slt i64 %t177, %t180
  %t185 = xor i1 %t183, true
  br i1 %t185, label %bb28, label %bb29
bb28:
  br label %bb32
bb29:
  br label %bb30
bb30:
  %t187 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t187, ptr %l74, !tbaa !27
  %t188 = load i64, ptr %l9, !tbaa !24
  %t190 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t191 = load ptr, ptr %t190, !tbaa !27
  %t192 = getelementptr i64, ptr %t191, i64 %t188
  %t193 = load i64, ptr %t192, !tbaa !34
  %t195 = load i64, ptr %l68, !tbaa !24
  %t196 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t197 = load ptr, ptr %t196, !tbaa !27
  %t198 = getelementptr i64, ptr %t197, i64 %t195
  store i64 %t193, ptr %t198, !tbaa !34
  %t199 = load i64, ptr %l68, !tbaa !24
  %t200 = add i64 %t199, 1
  store i64 %t200, ptr %l68, !tbaa !24
  br label %bb31
bb31:
  %t201 = load i64, ptr %l9, !tbaa !24
  %t204 = add i64 %t201, 1
  store i64 %t204, ptr %l9, !tbaa !24
  br label %bb27
bb32:
  br label %bb26
bb33:
  store { i64, ptr } zeroinitializer, ptr %l63, !tbaa !27
  br label %bb34
bb34:
  %t206 = load i64, ptr %l61
  %t207 = inttoptr i64 %t206 to ptr
  %t208 = load { i64, ptr }, ptr %l63
  %t209 = extractvalue { i64, ptr } %t208, 1
  %t210 = call ptr @__olang_region_or(ptr %t209, ptr null)
  %t211 = icmp ne ptr %t210, null
  %t212 = select i1 %t211, ptr %t210, ptr null
  call void @__olang_region_settle_in(ptr %t207, ptr %t212)
  %t213 = load ptr, ptr %l51, !tbaa !29
  %t214 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t213, i32 0, i32 1
  %t215 = load { i64, ptr }, ptr %t214, !tbaa !27
  store { i64, ptr } %t215, ptr %l82, !tbaa !27
  %t216 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t217 = load ptr, ptr %l51, !tbaa !29
  %t218 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t217, i32 0, i32 1
  store { i64, ptr } %t216, ptr %t218, !tbaa !27
  %t219 = load { i64, ptr }, ptr %l82
  %t220 = extractvalue { i64, ptr } %t219, 0
  %t221 = extractvalue { i64, ptr } %t219, 1
  call void @__olang_region_release_part(ptr %t221, i64 %t220)
  store { i64, ptr } zeroinitializer, ptr %l82
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H58704f470d09c6c466fe07940700ab7b(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i64
  %l13 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l19 = alloca i64
  %l28 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l30 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l32 = alloca i1
  %l33 = alloca ptr
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca { i64, ptr }
  %l37 = alloca i64
  %l38 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %t21 = alloca i64
  store ptr %a0, ptr %l0
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1, i32 0, i32 2
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp eq i64 %t6, 0
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l9, !tbaa !29
  %t11 = call ptr @__olang_region_make_part(ptr %v0)
  %t12 = ptrtoint ptr %t11 to i64
  store i64 %t12, ptr %l10, !tbaa !24
  %t13 = icmp sge i64 8, 0
  br i1 %t13, label %bb3, label %bb4
bb2:
  br label %bb9
bb3:
  %t15 = icmp sle i64 8, 1152921504606846975
  br i1 %t15, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_588616244e83f4d1_f256c997d7540e5d)
  unreachable
bb5:
  %t17 = mul i64 8, 8
  %t18 = load i64, ptr %l10
  %t19 = inttoptr i64 %t18 to ptr
  %t20 = call ptr @__olang_held_alloc(ptr %t19, i64 %t17)
  store i64 0, ptr %t21
  br label %fill.22
fill.22:
  %t25 = load i64, ptr %t21
  %t26 = icmp slt i64 %t25, 8
  br i1 %t26, label %fillb.23, label %filld.24
fillb.23:
  %t27 = getelementptr i64, ptr %t20, i64 %t25
  store i64 -1, ptr %t27
  %t28 = add i64 %t25, 1
  store i64 %t28, ptr %t21
  br label %fill.22
filld.24:
  %t29 = insertvalue { i64, ptr } undef, i64 8, 0
  %t30 = insertvalue { i64, ptr } %t29, ptr %t20, 1
  store { i64, ptr } %t30, ptr %l13, !tbaa !27
  %t31 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  %t34 = icmp eq i64 %t32, 0
  br i1 %t34, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_588616244e83f4d1_f256c997d7540e5d)
  unreachable
bb7:
  store { i64, ptr } zeroinitializer, ptr %l13, !tbaa !27
  br label %bb8
bb8:
  %t36 = load i64, ptr %l10
  %t37 = inttoptr i64 %t36 to ptr
  %t38 = load { i64, ptr }, ptr %l13
  %t39 = extractvalue { i64, ptr } %t38, 1
  %t40 = call ptr @__olang_region_or(ptr %t39, ptr null)
  %t41 = icmp ne ptr %t40, null
  %t42 = select i1 %t41, ptr %t40, ptr null
  call void @__olang_region_settle_in(ptr %t37, ptr %t42)
  %t43 = load ptr, ptr %l9, !tbaa !29
  %t44 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t43, i32 0, i32 2
  %t45 = load { i64, ptr }, ptr %t44, !tbaa !27
  store { i64, ptr } %t45, ptr %l16, !tbaa !27
  %t46 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t47 = load ptr, ptr %l9, !tbaa !29
  %t48 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t47, i32 0, i32 2
  store { i64, ptr } %t46, ptr %t48, !tbaa !27
  %t49 = load { i64, ptr }, ptr %l16
  %t50 = extractvalue { i64, ptr } %t49, 0
  %t51 = extractvalue { i64, ptr } %t49, 1
  call void @__olang_region_release_part(ptr %t51, i64 %t50)
  store { i64, ptr } zeroinitializer, ptr %l16
  br label %bb9
bb9:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l1
  %t56 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2b299ac8414fe0900d06d94de708c354(ptr %v0, ptr %t52, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t53)
  store i64 %t56, ptr %l19
  br label %bb10
bb10:
  %t57 = load i64, ptr %l19, !tbaa !24
  store i64 %t57, ptr %l3, !tbaa !24
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load i64, ptr %l3, !tbaa !24
  %t61 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t58, i32 0, i32 2
  %t63 = getelementptr { i64, ptr }, ptr %t61, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !27
  %t65 = getelementptr i64, ptr %t64, i64 %t59
  %t66 = load i64, ptr %t65, !tbaa !34
  store i64 %t66, ptr %l4, !tbaa !24
  br label %bb11
bb11:
  %t68 = load i64, ptr %l4, !tbaa !24
  %t70 = icmp sge i64 %t68, 0
  %t72 = xor i1 %t70, true
  br i1 %t72, label %bb12, label %bb13
bb12:
  br label %bb22
bb13:
  br label %bb14
bb14:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load i64, ptr %l4, !tbaa !24
  %t77 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t74, i32 0, i32 0
  %t79 = getelementptr { i64, ptr }, ptr %t77, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = getelementptr %"std/prelude/map:MapEntry.adf118859e04490c36a9a3f2e59cf058", ptr %t80, i64 %t75
  %t82 = getelementptr %"std/prelude/map:MapEntry.adf118859e04490c36a9a3f2e59cf058", ptr %t81, i32 0, i32 0
  %t83 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %t82
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t83, ptr %l28
  %t84 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l1
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t84, ptr %l30
  %t87 = call i1 @olang_2emir_2eHelperKind_2eEqual_2estd_2fpair_3aPair_3cI64_2c_20I64_3e(ptr %l28, ptr %l30)
  store i1 %t87, ptr %l32
  br label %bb15
bb15:
  %t88 = load i1, ptr %l32, !tbaa !21
  br i1 %t88, label %bb16, label %bb17
bb16:
  %t89 = load ptr, ptr %l0, !tbaa !29
  store ptr %t89, ptr %l33, !tbaa !29
  %t90 = load i64, ptr %l4, !tbaa !24
  store i64 %t90, ptr %l34, !tbaa !24
  %t91 = call ptr @__olang_region_make_part(ptr %v0)
  %t92 = ptrtoint ptr %t91 to i64
  store i64 %t92, ptr %l35, !tbaa !24
  %t93 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t93, ptr %l36, !tbaa !27
  %t94 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t95 = extractvalue { i64, ptr } %t94, 0
  store i64 %t95, ptr %l37, !tbaa !24
  %t96 = load i64, ptr %l37, !tbaa !24
  %t97 = mul i64 %t96, 8
  %t98 = load i64, ptr %l35
  %t99 = inttoptr i64 %t98 to ptr
  %t100 = call ptr @__olang_held_alloc(ptr %t99, i64 %t97)
  %t101 = insertvalue { i64, ptr } undef, i64 %t96, 0
  %t102 = insertvalue { i64, ptr } %t101, ptr %t100, 1
  store { i64, ptr } %t102, ptr %l38, !tbaa !27
  %t103 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t104 = load ptr, ptr %t103, !tbaa !27
  %t105 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !27
  %t107 = load i64, ptr %l37, !tbaa !24
  %t108 = mul i64 %t107, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t104, ptr %t106, i64 %t108, i1 false)
  %t109 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t110 = extractvalue { i64, ptr } %t109, 0
  %t112 = icmp eq i64 %t110, 0
  br i1 %t112, label %bb18, label %bb19
bb17:
  br label %bb20
bb18:
  store { i64, ptr } zeroinitializer, ptr %l38, !tbaa !27
  br label %bb19
bb19:
  %t114 = load i64, ptr %l35
  %t115 = inttoptr i64 %t114 to ptr
  %t116 = load { i64, ptr }, ptr %l38
  %t117 = extractvalue { i64, ptr } %t116, 1
  %t118 = call ptr @__olang_region_or(ptr %t117, ptr null)
  %t119 = icmp ne ptr %t118, null
  %t120 = select i1 %t119, ptr %t118, ptr null
  call void @__olang_region_settle_in(ptr %t115, ptr %t120)
  %t121 = load ptr, ptr %l33, !tbaa !29
  %t122 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t121, i32 0, i32 0
  %t123 = load i64, ptr %l34, !tbaa !24
  %t124 = getelementptr { i64, ptr }, ptr %t122, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !27
  %t126 = getelementptr %"std/prelude/map:MapEntry.adf118859e04490c36a9a3f2e59cf058", ptr %t125, i64 %t123
  %t127 = getelementptr %"std/prelude/map:MapEntry.adf118859e04490c36a9a3f2e59cf058", ptr %t126, i32 0, i32 1
  %t128 = load { i64, ptr }, ptr %t127, !tbaa !27
  store { i64, ptr } %t128, ptr %l41, !tbaa !27
  %t129 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t130 = load ptr, ptr %l33, !tbaa !29
  %t131 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t130, i32 0, i32 0
  %t132 = load i64, ptr %l34, !tbaa !24
  %t133 = getelementptr { i64, ptr }, ptr %t131, i32 0, i32 1
  %t134 = load ptr, ptr %t133, !tbaa !27
  %t135 = getelementptr %"std/prelude/map:MapEntry.adf118859e04490c36a9a3f2e59cf058", ptr %t134, i64 %t132
  %t136 = getelementptr %"std/prelude/map:MapEntry.adf118859e04490c36a9a3f2e59cf058", ptr %t135, i32 0, i32 1
  store { i64, ptr } %t129, ptr %t136, !tbaa !27
  %t137 = load { i64, ptr }, ptr %l41
  %t138 = extractvalue { i64, ptr } %t137, 0
  %t139 = extractvalue { i64, ptr } %t137, 1
  call void @__olang_region_release_part(ptr %t139, i64 %t138)
  store { i64, ptr } zeroinitializer, ptr %l41
  br label %ret
bb20:
  br label %bb21
bb21:
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t141 = load i64, ptr %l4, !tbaa !24
  %t143 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t140, i32 0, i32 1
  %t145 = getelementptr { i64, ptr }, ptr %t143, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !27
  %t147 = getelementptr i64, ptr %t146, i64 %t141
  %t148 = load i64, ptr %t147, !tbaa !34
  store i64 %t148, ptr %l4, !tbaa !24
  br label %bb11
bb22:
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t151 = load i64, ptr %l3, !tbaa !24
  %t152 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l1
  %t153 = load { i64, ptr }, ptr %l2, !tbaa !27
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H906657e795452d3a9a579308e9320d73(ptr %v0, ptr %t150, i64 %t151, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t152, { i64, ptr } %t153)
  br label %bb23
bb23:
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H797d95f86cc5303879cc3436cfb96ce2(ptr %v0, ptr %a0) noinline cold #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca { i64, ptr }
  %l5 = alloca i64
  %l7 = alloca { i64, ptr }
  %l9 = alloca i64
  %l14 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l31 = alloca i64
  %l33 = alloca { i64, ptr }
  %l34 = alloca i64
  %l40 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l49 = alloca i64
  %l50 = alloca i64
  %l54 = alloca ptr
  %l55 = alloca { i64, ptr }
  %l57 = alloca i64
  %l58 = alloca i64
  %l64 = alloca i64
  %l65 = alloca i64
  %l66 = alloca { i64, ptr }
  %l68 = alloca { i64, ptr }
  %l71 = alloca i64
  %l77 = alloca { i64, ptr }
  %l85 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp slt i64 %t6, 4
  br i1 %t8, label %bb1, label %bb2
bb1:
  store i64 8, ptr %l14, !tbaa !24
  br label %bb3
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t17 = mul i64 %t15, 2
  store i64 %t17, ptr %l14, !tbaa !24
  br label %bb3
bb3:
  %t19 = load i64, ptr %l14, !tbaa !24
  store i64 %t19, ptr %l1, !tbaa !24
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t20, i32 0, i32 0
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !27
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l21, !tbaa !29
  store { i64, ptr } %t23, ptr %l22, !tbaa !27
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t27, i32 0, i32 3
  %t30 = load i64, ptr %t29, !tbaa !24
  store i64 %t30, ptr %l24, !tbaa !24
  %t31 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  store i64 %t32, ptr %l25, !tbaa !24
  %t33 = icmp sge i64 0, 0
  br i1 %t33, label %bb4, label %bb5
bb4:
  %t35 = load i64, ptr %l24, !tbaa !24
  %t36 = icmp sle i64 0, %t35
  br i1 %t36, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_f5387e41aa461073_85329e3d54822a57)
  unreachable
bb6:
  %t38 = load i64, ptr %l24, !tbaa !24
  %t39 = load i64, ptr %l25, !tbaa !24
  %t40 = icmp sle i64 %t38, %t39
  br i1 %t40, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_f5387e41aa461073_85329e3d54822a57)
  unreachable
bb8:
  %t42 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = load i64, ptr %l24, !tbaa !24
  %t45 = getelementptr %"std/prelude/map:MapEntry.adf118859e04490c36a9a3f2e59cf058", ptr %t43, i64 0
  %t46 = sub i64 %t44, 0
  %t47 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t45, 1
  store { i64, ptr } %t48, ptr %l3, !tbaa !27
  %t50 = load i64, ptr %l1, !tbaa !24
  %t52 = call ptr @__olang_region_make_part(ptr %v0)
  %t53 = ptrtoint ptr %t52 to i64
  store i64 %t53, ptr %l31, !tbaa !24
  %t56 = mul i64 %t50, 32
  %t57 = load i64, ptr %l31
  %t58 = inttoptr i64 %t57 to ptr
  %t59 = call ptr @__olang_scope_alloc_zeroed(ptr %t58, i64 %t56)
  %t60 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t61 = insertvalue { i64, ptr } %t60, ptr %t59, 1
  store { i64, ptr } %t61, ptr %l33, !tbaa !27
  store i64 0, ptr %l34, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_f5387e41aa461073_85329e3d54822a57)
  unreachable
bb10:
  %t62 = load i64, ptr %l5, !tbaa !24
  %t63 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t63, 0
  %t68 = icmp slt i64 %t62, %t65
  %t70 = xor i1 %t68, true
  br i1 %t70, label %bb11, label %bb12
bb11:
  br label %bb15
bb12:
  br label %bb13
bb13:
  %t72 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t72, ptr %l40, !tbaa !27
  %t73 = load i64, ptr %l5, !tbaa !24
  %t75 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = getelementptr %"std/prelude/map:MapEntry.adf118859e04490c36a9a3f2e59cf058", ptr %t76, i64 %t73
  %t78 = load %"std/prelude/map:MapEntry.adf118859e04490c36a9a3f2e59cf058", ptr %t77
  store %"std/prelude/map:MapEntry.adf118859e04490c36a9a3f2e59cf058" zeroinitializer, ptr %t77
  %t80 = load i64, ptr %l34, !tbaa !24
  %t81 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !27
  %t83 = getelementptr %"std/prelude/map:MapEntry.adf118859e04490c36a9a3f2e59cf058", ptr %t82, i64 %t80
  store %"std/prelude/map:MapEntry.adf118859e04490c36a9a3f2e59cf058" %t78, ptr %t83
  %t84 = load i64, ptr %l34, !tbaa !24
  %t85 = add i64 %t84, 1
  store i64 %t85, ptr %l34, !tbaa !24
  br label %bb14
bb14:
  %t86 = load i64, ptr %l5, !tbaa !24
  %t89 = add i64 %t86, 1
  store i64 %t89, ptr %l5, !tbaa !24
  br label %bb10
bb15:
  %t91 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t92 = extractvalue { i64, ptr } %t91, 0
  %t94 = icmp eq i64 %t92, 0
  br i1 %t94, label %bb16, label %bb17
bb16:
  store { i64, ptr } zeroinitializer, ptr %l33, !tbaa !27
  br label %bb17
bb17:
  %t96 = load i64, ptr %l31
  %t97 = inttoptr i64 %t96 to ptr
  %t98 = load { i64, ptr }, ptr %l33
  %t99 = extractvalue { i64, ptr } %t98, 1
  %t100 = call ptr @__olang_region_or(ptr %t99, ptr null)
  %t101 = icmp ne ptr %t100, null
  %t102 = select i1 %t101, ptr %t100, ptr null
  call void @__olang_region_settle_in(ptr %t97, ptr %t102)
  %t103 = load ptr, ptr %l21, !tbaa !29
  %t104 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t103, i32 0, i32 0
  %t105 = load { i64, ptr }, ptr %t104, !tbaa !27
  store { i64, ptr } %t105, ptr %l48, !tbaa !27
  %t106 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t107 = load ptr, ptr %l21, !tbaa !29
  %t108 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t107, i32 0, i32 0
  store { i64, ptr } %t106, ptr %t108, !tbaa !27
  %t109 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t110 = extractvalue { i64, ptr } %t109, 0
  store i64 %t110, ptr %l49, !tbaa !24
  store i64 0, ptr %l50, !tbaa !24
  br label %bb18
bb18:
  %t111 = load i64, ptr %l50, !tbaa !24
  %t112 = load i64, ptr %l49, !tbaa !24
  %t113 = icmp slt i64 %t111, %t112
  br i1 %t113, label %bb19, label %bb20
bb19:
  %t115 = load i64, ptr %l50, !tbaa !24
  %t116 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t117 = load ptr, ptr %t116, !tbaa !27
  %t118 = getelementptr %"std/prelude/map:MapEntry.adf118859e04490c36a9a3f2e59cf058", ptr %t117, i64 %t115
  %t119 = getelementptr %"std/prelude/map:MapEntry.adf118859e04490c36a9a3f2e59cf058", ptr %t118, i32 0, i32 1
  %t120 = load { i64, ptr }, ptr %t119
  %t121 = extractvalue { i64, ptr } %t120, 0
  %t122 = extractvalue { i64, ptr } %t120, 1
  call void @__olang_region_release_part(ptr %t122, i64 %t121)
  store { i64, ptr } zeroinitializer, ptr %t119
  %t123 = load i64, ptr %l50, !tbaa !24
  %t124 = add i64 %t123, 1
  store i64 %t124, ptr %l50, !tbaa !24
  br label %bb18
bb20:
  %t125 = load { i64, ptr }, ptr %l48
  %t126 = extractvalue { i64, ptr } %t125, 0
  %t127 = extractvalue { i64, ptr } %t125, 1
  call void @__olang_region_release_part(ptr %t127, i64 %t126)
  store { i64, ptr } zeroinitializer, ptr %l48
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t130 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t128, i32 0, i32 1
  %t131 = load { i64, ptr }, ptr %t130, !tbaa !27
  %t133 = load ptr, ptr %l0, !tbaa !29
  store ptr %t133, ptr %l54, !tbaa !29
  store { i64, ptr } %t131, ptr %l55, !tbaa !27
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t137 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t135, i32 0, i32 3
  %t138 = load i64, ptr %t137, !tbaa !24
  store i64 %t138, ptr %l57, !tbaa !24
  %t139 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t140 = extractvalue { i64, ptr } %t139, 0
  store i64 %t140, ptr %l58, !tbaa !24
  %t141 = icmp sge i64 0, 0
  br i1 %t141, label %bb21, label %bb22
bb21:
  %t143 = load i64, ptr %l57, !tbaa !24
  %t144 = icmp sle i64 0, %t143
  br i1 %t144, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_baf2591500da8816_6821f095f5d7547a)
  unreachable
bb23:
  %t146 = load i64, ptr %l57, !tbaa !24
  %t147 = load i64, ptr %l58, !tbaa !24
  %t148 = icmp sle i64 %t146, %t147
  br i1 %t148, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_baf2591500da8816_6821f095f5d7547a)
  unreachable
bb25:
  %t150 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t151 = load ptr, ptr %t150, !tbaa !27
  %t152 = load i64, ptr %l57, !tbaa !24
  %t153 = getelementptr i64, ptr %t151, i64 0
  %t154 = sub i64 %t152, 0
  %t155 = insertvalue { i64, ptr } undef, i64 %t154, 0
  %t156 = insertvalue { i64, ptr } %t155, ptr %t153, 1
  store { i64, ptr } %t156, ptr %l7, !tbaa !27
  %t158 = load i64, ptr %l1, !tbaa !24
  %t160 = call ptr @__olang_region_make_part(ptr %v0)
  %t161 = ptrtoint ptr %t160 to i64
  store i64 %t161, ptr %l64, !tbaa !24
  store i64 %t158, ptr %l65, !tbaa !24
  %t163 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t165 = load i64, ptr %l65, !tbaa !24
  %t166 = extractvalue { i64, ptr } %t163, 0
  %t167 = mul i64 %t166, 8
  %t168 = mul i64 %t165, 8
  %t169 = extractvalue { i64, ptr } %t163, 1
  %t170 = call ptr @__olang_grow_in_place(ptr %t169, i64 %t167, i64 %t168, i64 %t165)
  %t171 = icmp ne ptr %t170, null
  %t172 = select i1 %t171, i64 %t165, i64 0
  %t173 = insertvalue { i64, ptr } undef, i64 %t172, 0
  %t174 = insertvalue { i64, ptr } %t173, ptr %t170, 1
  store { i64, ptr } %t174, ptr %l68, !tbaa !27
  %t175 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t176 = extractvalue { i64, ptr } %t175, 0
  %t178 = icmp ne i64 %t176, 0
  br i1 %t178, label %bb27, label %bb28
bb26:
  call void @__olang_check_failed(ptr @olang_loc_baf2591500da8816_6821f095f5d7547a)
  unreachable
bb27:
  %t180 = load { i64, ptr }, ptr %l68, !tbaa !27
  store { i64, ptr } %t180, ptr %l66, !tbaa !27
  br label %bb29
bb28:
  %t181 = load i64, ptr %l65, !tbaa !24
  %t182 = mul i64 %t181, 8
  %t183 = load i64, ptr %l64
  %t184 = inttoptr i64 %t183 to ptr
  %t185 = call ptr @__olang_held_alloc(ptr %t184, i64 %t182)
  %t186 = insertvalue { i64, ptr } undef, i64 %t181, 0
  %t187 = insertvalue { i64, ptr } %t186, ptr %t185, 1
  store { i64, ptr } %t187, ptr %l66, !tbaa !27
  store i64 0, ptr %l71, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb30
bb29:
  %t188 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t189 = extractvalue { i64, ptr } %t188, 0
  %t191 = icmp eq i64 %t189, 0
  br i1 %t191, label %bb36, label %bb37
bb30:
  %t193 = load i64, ptr %l9, !tbaa !24
  %t194 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t196 = extractvalue { i64, ptr } %t194, 0
  %t199 = icmp slt i64 %t193, %t196
  %t201 = xor i1 %t199, true
  br i1 %t201, label %bb31, label %bb32
bb31:
  br label %bb35
bb32:
  br label %bb33
bb33:
  %t203 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t203, ptr %l77, !tbaa !27
  %t204 = load i64, ptr %l9, !tbaa !24
  %t206 = getelementptr { i64, ptr }, ptr %l77, i32 0, i32 1
  %t207 = load ptr, ptr %t206, !tbaa !27
  %t208 = getelementptr i64, ptr %t207, i64 %t204
  %t209 = load i64, ptr %t208, !tbaa !34
  %t211 = load i64, ptr %l71, !tbaa !24
  %t212 = getelementptr { i64, ptr }, ptr %l66, i32 0, i32 1
  %t213 = load ptr, ptr %t212, !tbaa !27
  %t214 = getelementptr i64, ptr %t213, i64 %t211
  store i64 %t209, ptr %t214, !tbaa !34
  %t215 = load i64, ptr %l71, !tbaa !24
  %t216 = add i64 %t215, 1
  store i64 %t216, ptr %l71, !tbaa !24
  br label %bb34
bb34:
  %t217 = load i64, ptr %l9, !tbaa !24
  %t220 = add i64 %t217, 1
  store i64 %t220, ptr %l9, !tbaa !24
  br label %bb30
bb35:
  br label %bb29
bb36:
  store { i64, ptr } zeroinitializer, ptr %l66, !tbaa !27
  br label %bb37
bb37:
  %t222 = load i64, ptr %l64
  %t223 = inttoptr i64 %t222 to ptr
  %t224 = load { i64, ptr }, ptr %l66
  %t225 = extractvalue { i64, ptr } %t224, 1
  %t226 = call ptr @__olang_region_or(ptr %t225, ptr null)
  %t227 = icmp ne ptr %t226, null
  %t228 = select i1 %t227, ptr %t226, ptr null
  call void @__olang_region_settle_in(ptr %t223, ptr %t228)
  %t229 = load ptr, ptr %l54, !tbaa !29
  %t230 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t229, i32 0, i32 1
  %t231 = load { i64, ptr }, ptr %t230, !tbaa !27
  store { i64, ptr } %t231, ptr %l85, !tbaa !27
  %t232 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t233 = load ptr, ptr %l54, !tbaa !29
  %t234 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t233, i32 0, i32 1
  store { i64, ptr } %t232, ptr %t234, !tbaa !27
  %t235 = load { i64, ptr }, ptr %l85
  %t236 = extractvalue { i64, ptr } %t235, 0
  %t237 = extractvalue { i64, ptr } %t235, 1
  call void @__olang_region_release_part(ptr %t237, i64 %t236)
  store { i64, ptr } zeroinitializer, ptr %l85
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H82b0519898a45af4725a262dee225dae(ptr %v0, ptr %a0) noinline cold #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l5 = alloca i64
  %l7 = alloca { i64, ptr }
  %l9 = alloca i64
  %l14 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l31 = alloca i64
  %l32 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l37 = alloca i64
  %l43 = alloca { i64, ptr }
  %l53 = alloca ptr
  %l54 = alloca { i64, ptr }
  %l56 = alloca i64
  %l57 = alloca i64
  %l63 = alloca i64
  %l64 = alloca i64
  %l65 = alloca { i64, ptr }
  %l67 = alloca { i64, ptr }
  %l70 = alloca i64
  %l76 = alloca { i64, ptr }
  %l84 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp slt i64 %t6, 4
  br i1 %t8, label %bb1, label %bb2
bb1:
  store i64 8, ptr %l14, !tbaa !24
  br label %bb3
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t17 = mul i64 %t15, 2
  store i64 %t17, ptr %l14, !tbaa !24
  br label %bb3
bb3:
  %t19 = load i64, ptr %l14, !tbaa !24
  store i64 %t19, ptr %l1, !tbaa !24
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t20, i32 0, i32 0
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !27
  store { i64, ptr } %t23, ptr %l2, !tbaa !27
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l21, !tbaa !29
  %t26 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t26, ptr %l22, !tbaa !27
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t27, i32 0, i32 3
  %t30 = load i64, ptr %t29, !tbaa !24
  store i64 %t30, ptr %l24, !tbaa !24
  %t31 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  store i64 %t32, ptr %l25, !tbaa !24
  %t33 = icmp sge i64 0, 0
  br i1 %t33, label %bb4, label %bb5
bb4:
  %t35 = load i64, ptr %l24, !tbaa !24
  %t36 = icmp sle i64 0, %t35
  br i1 %t36, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_bad36ec9740ef4a6_7452059db725b0f2)
  unreachable
bb6:
  %t38 = load i64, ptr %l24, !tbaa !24
  %t39 = load i64, ptr %l25, !tbaa !24
  %t40 = icmp sle i64 %t38, %t39
  br i1 %t40, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_bad36ec9740ef4a6_7452059db725b0f2)
  unreachable
bb8:
  %t42 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = load i64, ptr %l24, !tbaa !24
  %t45 = getelementptr %"std/prelude/map:MapEntry.8c7bad97385adc7a5b41f0343fdc7864", ptr %t43, i64 0
  %t46 = sub i64 %t44, 0
  %t47 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t45, 1
  store { i64, ptr } %t48, ptr %l3, !tbaa !27
  %t50 = load i64, ptr %l1, !tbaa !24
  store i64 %t50, ptr %l31, !tbaa !24
  %t53 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t55 = load i64, ptr %l31, !tbaa !24
  %t56 = extractvalue { i64, ptr } %t53, 0
  %t57 = mul i64 %t56, 32
  %t58 = mul i64 %t55, 32
  %t59 = extractvalue { i64, ptr } %t53, 1
  %t60 = call ptr @__olang_grow_in_place(ptr %t59, i64 %t57, i64 %t58, i64 %t55)
  %t61 = icmp ne ptr %t60, null
  %t62 = select i1 %t61, i64 %t55, i64 0
  %t63 = insertvalue { i64, ptr } undef, i64 %t62, 0
  %t64 = insertvalue { i64, ptr } %t63, ptr %t60, 1
  store { i64, ptr } %t64, ptr %l34, !tbaa !27
  %t65 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t66 = extractvalue { i64, ptr } %t65, 0
  %t68 = icmp ne i64 %t66, 0
  br i1 %t68, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_bad36ec9740ef4a6_7452059db725b0f2)
  unreachable
bb10:
  %t70 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t70, ptr %l32, !tbaa !27
  br label %bb12
bb11:
  %t71 = load i64, ptr %l31, !tbaa !24
  %t72 = mul i64 %t71, 32
  %t73 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t72)
  %t74 = insertvalue { i64, ptr } undef, i64 %t71, 0
  %t75 = insertvalue { i64, ptr } %t74, ptr %t73, 1
  store { i64, ptr } %t75, ptr %l32, !tbaa !27
  store i64 0, ptr %l37, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb13
bb12:
  %t76 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t77 = load ptr, ptr %l21, !tbaa !29
  %t78 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t77, i32 0, i32 0
  store { i64, ptr } %t76, ptr %t78, !tbaa !27
  %t79 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t81, i32 0, i32 1
  %t84 = load { i64, ptr }, ptr %t83, !tbaa !27
  %t86 = load ptr, ptr %l0, !tbaa !29
  store ptr %t86, ptr %l53, !tbaa !29
  store { i64, ptr } %t84, ptr %l54, !tbaa !27
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t88, i32 0, i32 3
  %t91 = load i64, ptr %t90, !tbaa !24
  store i64 %t91, ptr %l56, !tbaa !24
  %t92 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t93 = extractvalue { i64, ptr } %t92, 0
  store i64 %t93, ptr %l57, !tbaa !24
  %t94 = icmp sge i64 0, 0
  br i1 %t94, label %bb19, label %bb20
bb13:
  %t96 = load i64, ptr %l5, !tbaa !24
  %t97 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t99 = extractvalue { i64, ptr } %t97, 0
  %t102 = icmp slt i64 %t96, %t99
  %t104 = xor i1 %t102, true
  br i1 %t104, label %bb14, label %bb15
bb14:
  br label %bb18
bb15:
  br label %bb16
bb16:
  %t106 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t106, ptr %l43, !tbaa !27
  %t107 = load i64, ptr %l5, !tbaa !24
  %t109 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t110 = load ptr, ptr %t109, !tbaa !27
  %t111 = getelementptr %"std/prelude/map:MapEntry.8c7bad97385adc7a5b41f0343fdc7864", ptr %t110, i64 %t107
  %t112 = load %"std/prelude/map:MapEntry.8c7bad97385adc7a5b41f0343fdc7864", ptr %t111
  %t114 = load i64, ptr %l37, !tbaa !24
  %t115 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !27
  %t117 = getelementptr %"std/prelude/map:MapEntry.8c7bad97385adc7a5b41f0343fdc7864", ptr %t116, i64 %t114
  store %"std/prelude/map:MapEntry.8c7bad97385adc7a5b41f0343fdc7864" %t112, ptr %t117
  %t118 = load i64, ptr %l37, !tbaa !24
  %t119 = add i64 %t118, 1
  store i64 %t119, ptr %l37, !tbaa !24
  br label %bb17
bb17:
  %t120 = load i64, ptr %l5, !tbaa !24
  %t123 = add i64 %t120, 1
  store i64 %t123, ptr %l5, !tbaa !24
  br label %bb13
bb18:
  br label %bb12
bb19:
  %t125 = load i64, ptr %l56, !tbaa !24
  %t126 = icmp sle i64 0, %t125
  br i1 %t126, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_a5d08808e6de8d03_28862b30739966f)
  unreachable
bb21:
  %t128 = load i64, ptr %l56, !tbaa !24
  %t129 = load i64, ptr %l57, !tbaa !24
  %t130 = icmp sle i64 %t128, %t129
  br i1 %t130, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_a5d08808e6de8d03_28862b30739966f)
  unreachable
bb23:
  %t132 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !27
  %t134 = load i64, ptr %l56, !tbaa !24
  %t135 = getelementptr i64, ptr %t133, i64 0
  %t136 = sub i64 %t134, 0
  %t137 = insertvalue { i64, ptr } undef, i64 %t136, 0
  %t138 = insertvalue { i64, ptr } %t137, ptr %t135, 1
  store { i64, ptr } %t138, ptr %l7, !tbaa !27
  %t140 = load i64, ptr %l1, !tbaa !24
  %t142 = call ptr @__olang_region_make_part(ptr %v0)
  %t143 = ptrtoint ptr %t142 to i64
  store i64 %t143, ptr %l63, !tbaa !24
  store i64 %t140, ptr %l64, !tbaa !24
  %t145 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t147 = load i64, ptr %l64, !tbaa !24
  %t148 = extractvalue { i64, ptr } %t145, 0
  %t149 = mul i64 %t148, 8
  %t150 = mul i64 %t147, 8
  %t151 = extractvalue { i64, ptr } %t145, 1
  %t152 = call ptr @__olang_grow_in_place(ptr %t151, i64 %t149, i64 %t150, i64 %t147)
  %t153 = icmp ne ptr %t152, null
  %t154 = select i1 %t153, i64 %t147, i64 0
  %t155 = insertvalue { i64, ptr } undef, i64 %t154, 0
  %t156 = insertvalue { i64, ptr } %t155, ptr %t152, 1
  store { i64, ptr } %t156, ptr %l67, !tbaa !27
  %t157 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t158 = extractvalue { i64, ptr } %t157, 0
  %t160 = icmp ne i64 %t158, 0
  br i1 %t160, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_a5d08808e6de8d03_28862b30739966f)
  unreachable
bb25:
  %t162 = load { i64, ptr }, ptr %l67, !tbaa !27
  store { i64, ptr } %t162, ptr %l65, !tbaa !27
  br label %bb27
bb26:
  %t163 = load i64, ptr %l64, !tbaa !24
  %t164 = mul i64 %t163, 8
  %t165 = load i64, ptr %l63
  %t166 = inttoptr i64 %t165 to ptr
  %t167 = call ptr @__olang_held_alloc(ptr %t166, i64 %t164)
  %t168 = insertvalue { i64, ptr } undef, i64 %t163, 0
  %t169 = insertvalue { i64, ptr } %t168, ptr %t167, 1
  store { i64, ptr } %t169, ptr %l65, !tbaa !27
  store i64 0, ptr %l70, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb28
bb27:
  %t170 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t171 = extractvalue { i64, ptr } %t170, 0
  %t173 = icmp eq i64 %t171, 0
  br i1 %t173, label %bb34, label %bb35
bb28:
  %t175 = load i64, ptr %l9, !tbaa !24
  %t176 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t178 = extractvalue { i64, ptr } %t176, 0
  %t181 = icmp slt i64 %t175, %t178
  %t183 = xor i1 %t181, true
  br i1 %t183, label %bb29, label %bb30
bb29:
  br label %bb33
bb30:
  br label %bb31
bb31:
  %t185 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t185, ptr %l76, !tbaa !27
  %t186 = load i64, ptr %l9, !tbaa !24
  %t188 = getelementptr { i64, ptr }, ptr %l76, i32 0, i32 1
  %t189 = load ptr, ptr %t188, !tbaa !27
  %t190 = getelementptr i64, ptr %t189, i64 %t186
  %t191 = load i64, ptr %t190, !tbaa !34
  %t193 = load i64, ptr %l70, !tbaa !24
  %t194 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t195 = load ptr, ptr %t194, !tbaa !27
  %t196 = getelementptr i64, ptr %t195, i64 %t193
  store i64 %t191, ptr %t196, !tbaa !34
  %t197 = load i64, ptr %l70, !tbaa !24
  %t198 = add i64 %t197, 1
  store i64 %t198, ptr %l70, !tbaa !24
  br label %bb32
bb32:
  %t199 = load i64, ptr %l9, !tbaa !24
  %t202 = add i64 %t199, 1
  store i64 %t202, ptr %l9, !tbaa !24
  br label %bb28
bb33:
  br label %bb27
bb34:
  store { i64, ptr } zeroinitializer, ptr %l65, !tbaa !27
  br label %bb35
bb35:
  %t204 = load i64, ptr %l63
  %t205 = inttoptr i64 %t204 to ptr
  %t206 = load { i64, ptr }, ptr %l65
  %t207 = extractvalue { i64, ptr } %t206, 1
  %t208 = call ptr @__olang_region_or(ptr %t207, ptr null)
  %t209 = icmp ne ptr %t208, null
  %t210 = select i1 %t209, ptr %t208, ptr null
  call void @__olang_region_settle_in(ptr %t205, ptr %t210)
  %t211 = load ptr, ptr %l53, !tbaa !29
  %t212 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t211, i32 0, i32 1
  %t213 = load { i64, ptr }, ptr %t212, !tbaa !27
  store { i64, ptr } %t213, ptr %l84, !tbaa !27
  %t214 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t215 = load ptr, ptr %l53, !tbaa !29
  %t216 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t215, i32 0, i32 1
  store { i64, ptr } %t214, ptr %t216, !tbaa !27
  %t217 = load { i64, ptr }, ptr %l84
  %t218 = extractvalue { i64, ptr } %t217, 0
  %t219 = extractvalue { i64, ptr } %t217, 1
  call void @__olang_region_release_part(ptr %t219, i64 %t218)
  store { i64, ptr } zeroinitializer, ptr %l84
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H9f9f84ce166b58669472616a8f24fc59(ptr %v0, ptr %v1, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca i64
  %l4 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i64
  %l13 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l19 = alloca i64
  %l28 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l30 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l32 = alloca i1
  %l33 = alloca ptr
  %l34 = alloca i64
  %l36 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l37 = alloca i64
  %l38 = alloca { i64, ptr }
  %l39 = alloca i64
  %l40 = alloca { i64, ptr }
  %l43 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l47 = alloca ptr
  %l48 = alloca i64
  %l49 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l50 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l52 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %s0 = alloca %olang.scope
  %t21 = alloca i64
  store ptr %a0, ptr %l0
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1, i32 0, i32 2
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp eq i64 %t6, 0
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l9, !tbaa !29
  %t11 = call ptr @__olang_region_make_part(ptr %v0)
  %t12 = ptrtoint ptr %t11 to i64
  store i64 %t12, ptr %l10, !tbaa !24
  %t13 = icmp sge i64 8, 0
  br i1 %t13, label %bb3, label %bb4
bb2:
  br label %bb9
bb3:
  %t15 = icmp sle i64 8, 1152921504606846975
  br i1 %t15, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_4cb2c4a1e0b65f9e_2e4d44f1258f401a)
  unreachable
bb5:
  %t17 = mul i64 8, 8
  %t18 = load i64, ptr %l10
  %t19 = inttoptr i64 %t18 to ptr
  %t20 = call ptr @__olang_held_alloc(ptr %t19, i64 %t17)
  store i64 0, ptr %t21
  br label %fill.22
fill.22:
  %t25 = load i64, ptr %t21
  %t26 = icmp slt i64 %t25, 8
  br i1 %t26, label %fillb.23, label %filld.24
fillb.23:
  %t27 = getelementptr i64, ptr %t20, i64 %t25
  store i64 -1, ptr %t27
  %t28 = add i64 %t25, 1
  store i64 %t28, ptr %t21
  br label %fill.22
filld.24:
  %t29 = insertvalue { i64, ptr } undef, i64 8, 0
  %t30 = insertvalue { i64, ptr } %t29, ptr %t20, 1
  store { i64, ptr } %t30, ptr %l13, !tbaa !27
  %t31 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  %t34 = icmp eq i64 %t32, 0
  br i1 %t34, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_4cb2c4a1e0b65f9e_2e4d44f1258f401a)
  unreachable
bb7:
  store { i64, ptr } zeroinitializer, ptr %l13, !tbaa !27
  br label %bb8
bb8:
  %t36 = load i64, ptr %l10
  %t37 = inttoptr i64 %t36 to ptr
  %t38 = load { i64, ptr }, ptr %l13
  %t39 = extractvalue { i64, ptr } %t38, 1
  %t40 = call ptr @__olang_region_or(ptr %t39, ptr null)
  %t41 = icmp ne ptr %t40, null
  %t42 = select i1 %t41, ptr %t40, ptr null
  call void @__olang_region_settle_in(ptr %t37, ptr %t42)
  %t43 = load ptr, ptr %l9, !tbaa !29
  %t44 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t43, i32 0, i32 2
  %t45 = load { i64, ptr }, ptr %t44, !tbaa !27
  store { i64, ptr } %t45, ptr %l16, !tbaa !27
  %t46 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t47 = load ptr, ptr %l9, !tbaa !29
  %t48 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t47, i32 0, i32 2
  store { i64, ptr } %t46, ptr %t48, !tbaa !27
  %t49 = load { i64, ptr }, ptr %l16
  %t50 = extractvalue { i64, ptr } %t49, 0
  %t51 = extractvalue { i64, ptr } %t49, 1
  call void @__olang_region_release_part(ptr %t51, i64 %t50)
  store { i64, ptr } zeroinitializer, ptr %l16
  br label %bb9
bb9:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l1
  %t56 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2b299ac8414fe0900d06d94de708c354(ptr %v0, ptr %t52, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t53)
  store i64 %t56, ptr %l19
  br label %bb10
bb10:
  %t57 = load i64, ptr %l19, !tbaa !24
  store i64 %t57, ptr %l3, !tbaa !24
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load i64, ptr %l3, !tbaa !24
  %t61 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t58, i32 0, i32 2
  %t63 = getelementptr { i64, ptr }, ptr %t61, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !27
  %t65 = getelementptr i64, ptr %t64, i64 %t59
  %t66 = load i64, ptr %t65, !tbaa !34
  store i64 %t66, ptr %l4, !tbaa !24
  br label %bb11
bb11:
  %t68 = load i64, ptr %l4, !tbaa !24
  %t70 = icmp sge i64 %t68, 0
  %t72 = xor i1 %t70, true
  br i1 %t72, label %bb12, label %bb13
bb12:
  br label %bb22
bb13:
  br label %bb14
bb14:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load i64, ptr %l4, !tbaa !24
  %t77 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t74, i32 0, i32 0
  %t79 = getelementptr { i64, ptr }, ptr %t77, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = getelementptr %"std/prelude/map:MapEntry.39ab5235a9e7cc4d21ab272df52b187f", ptr %t80, i64 %t75
  %t82 = getelementptr %"std/prelude/map:MapEntry.39ab5235a9e7cc4d21ab272df52b187f", ptr %t81, i32 0, i32 0
  %t83 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %t82
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t83, ptr %l28
  %t84 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l1
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t84, ptr %l30
  %t87 = call i1 @olang_2emir_2eHelperKind_2eEqual_2estd_2fpair_3aPair_3cI64_2c_20I64_3e(ptr %l28, ptr %l30)
  store i1 %t87, ptr %l32
  br label %bb15
bb15:
  %t88 = load i1, ptr %l32, !tbaa !21
  br i1 %t88, label %bb16, label %bb17
bb16:
  %t89 = load ptr, ptr %l0, !tbaa !29
  store ptr %t89, ptr %l33, !tbaa !29
  %t90 = load i64, ptr %l4, !tbaa !24
  store i64 %t90, ptr %l34, !tbaa !24
  %t91 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t91, ptr %l36
  %t93 = call ptr @__olang_region_make_part(ptr %v0)
  %t94 = ptrtoint ptr %t93 to i64
  store i64 %t94, ptr %l37, !tbaa !24
  %t95 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l36, i32 0, i32 0
  %t96 = load { i64, ptr }, ptr %t95, !tbaa !27
  store { i64, ptr } %t96, ptr %l38, !tbaa !27
  %t97 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t98 = extractvalue { i64, ptr } %t97, 0
  store i64 %t98, ptr %l39, !tbaa !24
  %t99 = load i64, ptr %l39, !tbaa !24
  %t100 = mul i64 %t99, 64
  %t101 = load i64, ptr %l37
  %t102 = inttoptr i64 %t101 to ptr
  %t103 = call ptr @__olang_held_alloc(ptr %t102, i64 %t100)
  %t104 = insertvalue { i64, ptr } undef, i64 %t99, 0
  %t105 = insertvalue { i64, ptr } %t104, ptr %t103, 1
  store { i64, ptr } %t105, ptr %l40, !tbaa !27
  %t106 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !27
  %t108 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !27
  %t110 = load i64, ptr %l39, !tbaa !24
  %t111 = mul i64 %t110, 64
  call void @llvm.memmove.p0.p0.i64(ptr %t107, ptr %t109, i64 %t111, i1 false)
  %t112 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t113 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l36, i32 0, i32 0
  store { i64, ptr } %t112, ptr %t113, !tbaa !27
  %t114 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l36, i32 0, i32 0
  %t115 = load { i64, ptr }, ptr %t114, !tbaa !27
  %t116 = extractvalue { i64, ptr } %t115, 0
  %t118 = icmp eq i64 %t116, 0
  br i1 %t118, label %bb18, label %bb19
bb17:
  br label %bb20
bb18:
  %t120 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l36, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t120, !tbaa !27
  br label %bb19
bb19:
  %t121 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l36, i32 0, i32 0
  %t122 = load i64, ptr %l37
  %t123 = inttoptr i64 %t122 to ptr
  %t124 = load { i64, ptr }, ptr %t121
  %t125 = extractvalue { i64, ptr } %t124, 1
  %t126 = call ptr @__olang_region_or(ptr %t125, ptr null)
  %t127 = icmp ne ptr %t126, null
  %t128 = select i1 %t127, ptr %t126, ptr null
  call void @__olang_region_settle_in(ptr %t123, ptr %t128)
  %t129 = load ptr, ptr %l33, !tbaa !29
  %t130 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t129, i32 0, i32 0
  %t131 = load i64, ptr %l34, !tbaa !24
  %t132 = getelementptr { i64, ptr }, ptr %t130, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !27
  %t134 = getelementptr %"std/prelude/map:MapEntry.39ab5235a9e7cc4d21ab272df52b187f", ptr %t133, i64 %t131
  %t135 = getelementptr %"std/prelude/map:MapEntry.39ab5235a9e7cc4d21ab272df52b187f", ptr %t134, i32 0, i32 1
  %t136 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t135
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t136, ptr %l43
  %t137 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l36
  %t138 = load ptr, ptr %l33, !tbaa !29
  %t139 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t138, i32 0, i32 0
  %t140 = load i64, ptr %l34, !tbaa !24
  %t141 = getelementptr { i64, ptr }, ptr %t139, i32 0, i32 1
  %t142 = load ptr, ptr %t141, !tbaa !27
  %t143 = getelementptr %"std/prelude/map:MapEntry.39ab5235a9e7cc4d21ab272df52b187f", ptr %t142, i64 %t140
  %t144 = getelementptr %"std/prelude/map:MapEntry.39ab5235a9e7cc4d21ab272df52b187f", ptr %t143, i32 0, i32 1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t137, ptr %t144
  %t145 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l43, i32 0, i32 0
  %t146 = load { i64, ptr }, ptr %t145
  %t147 = extractvalue { i64, ptr } %t146, 0
  %t148 = extractvalue { i64, ptr } %t146, 1
  call void @__olang_region_release_part(ptr %t148, i64 %t147)
  store { i64, ptr } zeroinitializer, ptr %t145
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb20:
  br label %bb21
bb21:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t150 = load i64, ptr %l4, !tbaa !24
  %t152 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t149, i32 0, i32 1
  %t154 = getelementptr { i64, ptr }, ptr %t152, i32 0, i32 1
  %t155 = load ptr, ptr %t154, !tbaa !27
  %t156 = getelementptr i64, ptr %t155, i64 %t150
  %t157 = load i64, ptr %t156, !tbaa !34
  store i64 %t157, ptr %l4, !tbaa !24
  br label %bb11
bb22:
  %t159 = load ptr, ptr %l0, !tbaa !29
  store ptr %t159, ptr %l47, !tbaa !29
  %t160 = load i64, ptr %l3, !tbaa !24
  store i64 %t160, ptr %l48, !tbaa !24
  %t161 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l1
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t161, ptr %l49
  %t162 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t162, ptr %l50
  %t164 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3anote_3e(ptr %s0, ptr %l50)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t164, ptr %l52
  br label %bb23
bb23:
  %t165 = load ptr, ptr %l47, !tbaa !29
  %t166 = load i64, ptr %l48, !tbaa !24
  %t167 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l49
  %t168 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l52
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H453662ae559f86d4d40ba4da3fb4f916(ptr %v0, ptr %s0, ptr %t165, i64 %t166, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t167, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t168)
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_Ha7ec2521d254a46c93deb02fe8d52040(ptr %v0, ptr %a0) noinline cold #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l5 = alloca i64
  %l7 = alloca { i64, ptr }
  %l9 = alloca i64
  %l14 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l32 = alloca { i64, ptr }
  %l33 = alloca i64
  %l39 = alloca { i64, ptr }
  %l49 = alloca ptr
  %l50 = alloca { i64, ptr }
  %l52 = alloca i64
  %l53 = alloca i64
  %l59 = alloca i64
  %l60 = alloca i64
  %l61 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %l66 = alloca i64
  %l72 = alloca { i64, ptr }
  %l80 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp slt i64 %t6, 4
  br i1 %t8, label %bb1, label %bb2
bb1:
  store i64 8, ptr %l14, !tbaa !24
  br label %bb3
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t17 = mul i64 %t15, 2
  store i64 %t17, ptr %l14, !tbaa !24
  br label %bb3
bb3:
  %t19 = load i64, ptr %l14, !tbaa !24
  store i64 %t19, ptr %l1, !tbaa !24
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t20, i32 0, i32 0
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !27
  store { i64, ptr } %t23, ptr %l2, !tbaa !27
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l21, !tbaa !29
  %t26 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t26, ptr %l22, !tbaa !27
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t27, i32 0, i32 3
  %t30 = load i64, ptr %t29, !tbaa !24
  store i64 %t30, ptr %l24, !tbaa !24
  %t31 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  store i64 %t32, ptr %l25, !tbaa !24
  %t33 = icmp sge i64 0, 0
  br i1 %t33, label %bb4, label %bb5
bb4:
  %t35 = load i64, ptr %l24, !tbaa !24
  %t36 = icmp sle i64 0, %t35
  br i1 %t36, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_f648f51cc9ea530b_e9e5817bf319c63f)
  unreachable
bb6:
  %t38 = load i64, ptr %l24, !tbaa !24
  %t39 = load i64, ptr %l25, !tbaa !24
  %t40 = icmp sle i64 %t38, %t39
  br i1 %t40, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_f648f51cc9ea530b_e9e5817bf319c63f)
  unreachable
bb8:
  %t42 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = load i64, ptr %l24, !tbaa !24
  %t45 = getelementptr %"std/prelude/map:MapEntry.0bcda5c026701d95f15bce76f62e86ad", ptr %t43, i64 0
  %t46 = sub i64 %t44, 0
  %t47 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t45, 1
  store { i64, ptr } %t48, ptr %l3, !tbaa !27
  %t50 = load i64, ptr %l1, !tbaa !24
  %t54 = mul i64 %t50, 120
  %t55 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t54)
  %t56 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t55, 1
  store { i64, ptr } %t57, ptr %l32, !tbaa !27
  store i64 0, ptr %l33, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_f648f51cc9ea530b_e9e5817bf319c63f)
  unreachable
bb10:
  %t58 = load i64, ptr %l5, !tbaa !24
  %t59 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t61 = extractvalue { i64, ptr } %t59, 0
  %t64 = icmp slt i64 %t58, %t61
  %t66 = xor i1 %t64, true
  br i1 %t66, label %bb11, label %bb12
bb11:
  br label %bb15
bb12:
  br label %bb13
bb13:
  %t68 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t68, ptr %l39, !tbaa !27
  %t69 = load i64, ptr %l5, !tbaa !24
  %t71 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !27
  %t73 = getelementptr %"std/prelude/map:MapEntry.0bcda5c026701d95f15bce76f62e86ad", ptr %t72, i64 %t69
  %t74 = load %"std/prelude/map:MapEntry.0bcda5c026701d95f15bce76f62e86ad", ptr %t73
  store %"std/prelude/map:MapEntry.0bcda5c026701d95f15bce76f62e86ad" zeroinitializer, ptr %t73
  %t76 = load i64, ptr %l33, !tbaa !24
  %t77 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = getelementptr %"std/prelude/map:MapEntry.0bcda5c026701d95f15bce76f62e86ad", ptr %t78, i64 %t76
  store %"std/prelude/map:MapEntry.0bcda5c026701d95f15bce76f62e86ad" %t74, ptr %t79
  %t80 = load i64, ptr %l33, !tbaa !24
  %t81 = add i64 %t80, 1
  store i64 %t81, ptr %l33, !tbaa !24
  br label %bb14
bb14:
  %t82 = load i64, ptr %l5, !tbaa !24
  %t85 = add i64 %t82, 1
  store i64 %t85, ptr %l5, !tbaa !24
  br label %bb10
bb15:
  %t87 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t88 = load ptr, ptr %l21, !tbaa !29
  %t89 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t88, i32 0, i32 0
  store { i64, ptr } %t87, ptr %t89, !tbaa !27
  %t90 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t92, i32 0, i32 1
  %t95 = load { i64, ptr }, ptr %t94, !tbaa !27
  %t97 = load ptr, ptr %l0, !tbaa !29
  store ptr %t97, ptr %l49, !tbaa !29
  store { i64, ptr } %t95, ptr %l50, !tbaa !27
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t99, i32 0, i32 3
  %t102 = load i64, ptr %t101, !tbaa !24
  store i64 %t102, ptr %l52, !tbaa !24
  %t103 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t104 = extractvalue { i64, ptr } %t103, 0
  store i64 %t104, ptr %l53, !tbaa !24
  %t105 = icmp sge i64 0, 0
  br i1 %t105, label %bb16, label %bb17
bb16:
  %t107 = load i64, ptr %l52, !tbaa !24
  %t108 = icmp sle i64 0, %t107
  br i1 %t108, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_6ad8b4eb5ff0070e_53fd8215e0f88442)
  unreachable
bb18:
  %t110 = load i64, ptr %l52, !tbaa !24
  %t111 = load i64, ptr %l53, !tbaa !24
  %t112 = icmp sle i64 %t110, %t111
  br i1 %t112, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_6ad8b4eb5ff0070e_53fd8215e0f88442)
  unreachable
bb20:
  %t114 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !27
  %t116 = load i64, ptr %l52, !tbaa !24
  %t117 = getelementptr i64, ptr %t115, i64 0
  %t118 = sub i64 %t116, 0
  %t119 = insertvalue { i64, ptr } undef, i64 %t118, 0
  %t120 = insertvalue { i64, ptr } %t119, ptr %t117, 1
  store { i64, ptr } %t120, ptr %l7, !tbaa !27
  %t122 = load i64, ptr %l1, !tbaa !24
  %t124 = call ptr @__olang_region_make_part(ptr %v0)
  %t125 = ptrtoint ptr %t124 to i64
  store i64 %t125, ptr %l59, !tbaa !24
  store i64 %t122, ptr %l60, !tbaa !24
  %t127 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t129 = load i64, ptr %l60, !tbaa !24
  %t130 = extractvalue { i64, ptr } %t127, 0
  %t131 = mul i64 %t130, 8
  %t132 = mul i64 %t129, 8
  %t133 = extractvalue { i64, ptr } %t127, 1
  %t134 = call ptr @__olang_grow_in_place(ptr %t133, i64 %t131, i64 %t132, i64 %t129)
  %t135 = icmp ne ptr %t134, null
  %t136 = select i1 %t135, i64 %t129, i64 0
  %t137 = insertvalue { i64, ptr } undef, i64 %t136, 0
  %t138 = insertvalue { i64, ptr } %t137, ptr %t134, 1
  store { i64, ptr } %t138, ptr %l63, !tbaa !27
  %t139 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t140 = extractvalue { i64, ptr } %t139, 0
  %t142 = icmp ne i64 %t140, 0
  br i1 %t142, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_6ad8b4eb5ff0070e_53fd8215e0f88442)
  unreachable
bb22:
  %t144 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t144, ptr %l61, !tbaa !27
  br label %bb24
bb23:
  %t145 = load i64, ptr %l60, !tbaa !24
  %t146 = mul i64 %t145, 8
  %t147 = load i64, ptr %l59
  %t148 = inttoptr i64 %t147 to ptr
  %t149 = call ptr @__olang_held_alloc(ptr %t148, i64 %t146)
  %t150 = insertvalue { i64, ptr } undef, i64 %t145, 0
  %t151 = insertvalue { i64, ptr } %t150, ptr %t149, 1
  store { i64, ptr } %t151, ptr %l61, !tbaa !27
  store i64 0, ptr %l66, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb25
bb24:
  %t152 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t153 = extractvalue { i64, ptr } %t152, 0
  %t155 = icmp eq i64 %t153, 0
  br i1 %t155, label %bb31, label %bb32
bb25:
  %t157 = load i64, ptr %l9, !tbaa !24
  %t158 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t160 = extractvalue { i64, ptr } %t158, 0
  %t163 = icmp slt i64 %t157, %t160
  %t165 = xor i1 %t163, true
  br i1 %t165, label %bb26, label %bb27
bb26:
  br label %bb30
bb27:
  br label %bb28
bb28:
  %t167 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t167, ptr %l72, !tbaa !27
  %t168 = load i64, ptr %l9, !tbaa !24
  %t170 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t171 = load ptr, ptr %t170, !tbaa !27
  %t172 = getelementptr i64, ptr %t171, i64 %t168
  %t173 = load i64, ptr %t172, !tbaa !34
  %t175 = load i64, ptr %l66, !tbaa !24
  %t176 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t177 = load ptr, ptr %t176, !tbaa !27
  %t178 = getelementptr i64, ptr %t177, i64 %t175
  store i64 %t173, ptr %t178, !tbaa !34
  %t179 = load i64, ptr %l66, !tbaa !24
  %t180 = add i64 %t179, 1
  store i64 %t180, ptr %l66, !tbaa !24
  br label %bb29
bb29:
  %t181 = load i64, ptr %l9, !tbaa !24
  %t184 = add i64 %t181, 1
  store i64 %t184, ptr %l9, !tbaa !24
  br label %bb25
bb30:
  br label %bb24
bb31:
  store { i64, ptr } zeroinitializer, ptr %l61, !tbaa !27
  br label %bb32
bb32:
  %t186 = load i64, ptr %l59
  %t187 = inttoptr i64 %t186 to ptr
  %t188 = load { i64, ptr }, ptr %l61
  %t189 = extractvalue { i64, ptr } %t188, 1
  %t190 = call ptr @__olang_region_or(ptr %t189, ptr null)
  %t191 = icmp ne ptr %t190, null
  %t192 = select i1 %t191, ptr %t190, ptr null
  call void @__olang_region_settle_in(ptr %t187, ptr %t192)
  %t193 = load ptr, ptr %l49, !tbaa !29
  %t194 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t193, i32 0, i32 1
  %t195 = load { i64, ptr }, ptr %t194, !tbaa !27
  store { i64, ptr } %t195, ptr %l80, !tbaa !27
  %t196 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t197 = load ptr, ptr %l49, !tbaa !29
  %t198 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t197, i32 0, i32 1
  store { i64, ptr } %t196, ptr %t198, !tbaa !27
  %t199 = load { i64, ptr }, ptr %l80
  %t200 = extractvalue { i64, ptr } %t199, 0
  %t201 = extractvalue { i64, ptr } %t199, 1
  call void @__olang_region_release_part(ptr %t201, i64 %t200)
  store { i64, ptr } zeroinitializer, ptr %l80
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_Hdc04c06f88166834be95bd4312a12d4b(ptr %v0, ptr %a0) noinline cold #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca { i64, ptr }
  %l5 = alloca i64
  %l7 = alloca { i64, ptr }
  %l9 = alloca i64
  %l14 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l38 = alloca i64
  %l44 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %l55 = alloca ptr
  %l56 = alloca { i64, ptr }
  %l58 = alloca i64
  %l59 = alloca i64
  %l65 = alloca i64
  %l66 = alloca i64
  %l67 = alloca { i64, ptr }
  %l69 = alloca { i64, ptr }
  %l72 = alloca i64
  %l78 = alloca { i64, ptr }
  %l86 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp slt i64 %t6, 4
  br i1 %t8, label %bb1, label %bb2
bb1:
  store i64 8, ptr %l14, !tbaa !24
  br label %bb3
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t17 = mul i64 %t15, 2
  store i64 %t17, ptr %l14, !tbaa !24
  br label %bb3
bb3:
  %t19 = load i64, ptr %l14, !tbaa !24
  store i64 %t19, ptr %l1, !tbaa !24
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t20, i32 0, i32 0
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !27
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l21, !tbaa !29
  store { i64, ptr } %t23, ptr %l22, !tbaa !27
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t27, i32 0, i32 3
  %t30 = load i64, ptr %t29, !tbaa !24
  store i64 %t30, ptr %l24, !tbaa !24
  %t31 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  store i64 %t32, ptr %l25, !tbaa !24
  %t33 = icmp sge i64 0, 0
  br i1 %t33, label %bb4, label %bb5
bb4:
  %t35 = load i64, ptr %l24, !tbaa !24
  %t36 = icmp sle i64 0, %t35
  br i1 %t36, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_d7e3401240abac0_21ebe09f02269f14)
  unreachable
bb6:
  %t38 = load i64, ptr %l24, !tbaa !24
  %t39 = load i64, ptr %l25, !tbaa !24
  %t40 = icmp sle i64 %t38, %t39
  br i1 %t40, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_d7e3401240abac0_21ebe09f02269f14)
  unreachable
bb8:
  %t42 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = load i64, ptr %l24, !tbaa !24
  %t45 = getelementptr %"std/prelude/map:MapEntry.ecfeec17cdefbac388c52a4a4fc0fb05", ptr %t43, i64 0
  %t46 = sub i64 %t44, 0
  %t47 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t45, 1
  store { i64, ptr } %t48, ptr %l3, !tbaa !27
  %t50 = load i64, ptr %l1, !tbaa !24
  %t52 = call ptr @__olang_region_make_part(ptr %v0)
  %t53 = ptrtoint ptr %t52 to i64
  store i64 %t53, ptr %l31, !tbaa !24
  store i64 %t50, ptr %l32, !tbaa !24
  %t55 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t57 = load i64, ptr %l32, !tbaa !24
  %t58 = extractvalue { i64, ptr } %t55, 0
  %t59 = mul i64 %t58, 24
  %t60 = mul i64 %t57, 24
  %t61 = extractvalue { i64, ptr } %t55, 1
  %t62 = call ptr @__olang_grow_in_place(ptr %t61, i64 %t59, i64 %t60, i64 %t57)
  %t63 = icmp ne ptr %t62, null
  %t64 = select i1 %t63, i64 %t57, i64 0
  %t65 = insertvalue { i64, ptr } undef, i64 %t64, 0
  %t66 = insertvalue { i64, ptr } %t65, ptr %t62, 1
  store { i64, ptr } %t66, ptr %l35, !tbaa !27
  %t67 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t68 = extractvalue { i64, ptr } %t67, 0
  %t70 = icmp ne i64 %t68, 0
  br i1 %t70, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_d7e3401240abac0_21ebe09f02269f14)
  unreachable
bb10:
  %t72 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t72, ptr %l33, !tbaa !27
  br label %bb12
bb11:
  %t73 = load i64, ptr %l32, !tbaa !24
  %t74 = mul i64 %t73, 24
  %t75 = load i64, ptr %l31
  %t76 = inttoptr i64 %t75 to ptr
  %t77 = call ptr @__olang_held_alloc(ptr %t76, i64 %t74)
  %t78 = insertvalue { i64, ptr } undef, i64 %t73, 0
  %t79 = insertvalue { i64, ptr } %t78, ptr %t77, 1
  store { i64, ptr } %t79, ptr %l33, !tbaa !27
  store i64 0, ptr %l38, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb13
bb12:
  %t80 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t81 = extractvalue { i64, ptr } %t80, 0
  %t83 = icmp eq i64 %t81, 0
  br i1 %t83, label %bb19, label %bb20
bb13:
  %t85 = load i64, ptr %l5, !tbaa !24
  %t86 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t88 = extractvalue { i64, ptr } %t86, 0
  %t91 = icmp slt i64 %t85, %t88
  %t93 = xor i1 %t91, true
  br i1 %t93, label %bb14, label %bb15
bb14:
  br label %bb18
bb15:
  br label %bb16
bb16:
  %t95 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t95, ptr %l44, !tbaa !27
  %t96 = load i64, ptr %l5, !tbaa !24
  %t98 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !27
  %t100 = getelementptr %"std/prelude/map:MapEntry.ecfeec17cdefbac388c52a4a4fc0fb05", ptr %t99, i64 %t96
  %t101 = load %"std/prelude/map:MapEntry.ecfeec17cdefbac388c52a4a4fc0fb05", ptr %t100
  %t103 = load i64, ptr %l38, !tbaa !24
  %t104 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !27
  %t106 = getelementptr %"std/prelude/map:MapEntry.ecfeec17cdefbac388c52a4a4fc0fb05", ptr %t105, i64 %t103
  store %"std/prelude/map:MapEntry.ecfeec17cdefbac388c52a4a4fc0fb05" %t101, ptr %t106
  %t107 = load i64, ptr %l38, !tbaa !24
  %t108 = add i64 %t107, 1
  store i64 %t108, ptr %l38, !tbaa !24
  br label %bb17
bb17:
  %t109 = load i64, ptr %l5, !tbaa !24
  %t112 = add i64 %t109, 1
  store i64 %t112, ptr %l5, !tbaa !24
  br label %bb13
bb18:
  br label %bb12
bb19:
  store { i64, ptr } zeroinitializer, ptr %l33, !tbaa !27
  br label %bb20
bb20:
  %t114 = load i64, ptr %l31
  %t115 = inttoptr i64 %t114 to ptr
  %t116 = load { i64, ptr }, ptr %l33
  %t117 = extractvalue { i64, ptr } %t116, 1
  %t118 = call ptr @__olang_region_or(ptr %t117, ptr null)
  %t119 = icmp ne ptr %t118, null
  %t120 = select i1 %t119, ptr %t118, ptr null
  call void @__olang_region_settle_in(ptr %t115, ptr %t120)
  %t121 = load ptr, ptr %l21, !tbaa !29
  %t122 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t121, i32 0, i32 0
  %t123 = load { i64, ptr }, ptr %t122, !tbaa !27
  store { i64, ptr } %t123, ptr %l52, !tbaa !27
  %t124 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t125 = load ptr, ptr %l21, !tbaa !29
  %t126 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t125, i32 0, i32 0
  store { i64, ptr } %t124, ptr %t126, !tbaa !27
  %t127 = load { i64, ptr }, ptr %l52
  %t128 = extractvalue { i64, ptr } %t127, 0
  %t129 = extractvalue { i64, ptr } %t127, 1
  call void @__olang_region_release_part(ptr %t129, i64 %t128)
  store { i64, ptr } zeroinitializer, ptr %l52
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t130, i32 0, i32 1
  %t133 = load { i64, ptr }, ptr %t132, !tbaa !27
  %t135 = load ptr, ptr %l0, !tbaa !29
  store ptr %t135, ptr %l55, !tbaa !29
  store { i64, ptr } %t133, ptr %l56, !tbaa !27
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t139 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t137, i32 0, i32 3
  %t140 = load i64, ptr %t139, !tbaa !24
  store i64 %t140, ptr %l58, !tbaa !24
  %t141 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t142 = extractvalue { i64, ptr } %t141, 0
  store i64 %t142, ptr %l59, !tbaa !24
  %t143 = icmp sge i64 0, 0
  br i1 %t143, label %bb21, label %bb22
bb21:
  %t145 = load i64, ptr %l58, !tbaa !24
  %t146 = icmp sle i64 0, %t145
  br i1 %t146, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_9e739478bd1c861d_4ad5ffb33eb69c81)
  unreachable
bb23:
  %t148 = load i64, ptr %l58, !tbaa !24
  %t149 = load i64, ptr %l59, !tbaa !24
  %t150 = icmp sle i64 %t148, %t149
  br i1 %t150, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_9e739478bd1c861d_4ad5ffb33eb69c81)
  unreachable
bb25:
  %t152 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t153 = load ptr, ptr %t152, !tbaa !27
  %t154 = load i64, ptr %l58, !tbaa !24
  %t155 = getelementptr i64, ptr %t153, i64 0
  %t156 = sub i64 %t154, 0
  %t157 = insertvalue { i64, ptr } undef, i64 %t156, 0
  %t158 = insertvalue { i64, ptr } %t157, ptr %t155, 1
  store { i64, ptr } %t158, ptr %l7, !tbaa !27
  %t160 = load i64, ptr %l1, !tbaa !24
  %t162 = call ptr @__olang_region_make_part(ptr %v0)
  %t163 = ptrtoint ptr %t162 to i64
  store i64 %t163, ptr %l65, !tbaa !24
  store i64 %t160, ptr %l66, !tbaa !24
  %t165 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t167 = load i64, ptr %l66, !tbaa !24
  %t168 = extractvalue { i64, ptr } %t165, 0
  %t169 = mul i64 %t168, 8
  %t170 = mul i64 %t167, 8
  %t171 = extractvalue { i64, ptr } %t165, 1
  %t172 = call ptr @__olang_grow_in_place(ptr %t171, i64 %t169, i64 %t170, i64 %t167)
  %t173 = icmp ne ptr %t172, null
  %t174 = select i1 %t173, i64 %t167, i64 0
  %t175 = insertvalue { i64, ptr } undef, i64 %t174, 0
  %t176 = insertvalue { i64, ptr } %t175, ptr %t172, 1
  store { i64, ptr } %t176, ptr %l69, !tbaa !27
  %t177 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t178 = extractvalue { i64, ptr } %t177, 0
  %t180 = icmp ne i64 %t178, 0
  br i1 %t180, label %bb27, label %bb28
bb26:
  call void @__olang_check_failed(ptr @olang_loc_9e739478bd1c861d_4ad5ffb33eb69c81)
  unreachable
bb27:
  %t182 = load { i64, ptr }, ptr %l69, !tbaa !27
  store { i64, ptr } %t182, ptr %l67, !tbaa !27
  br label %bb29
bb28:
  %t183 = load i64, ptr %l66, !tbaa !24
  %t184 = mul i64 %t183, 8
  %t185 = load i64, ptr %l65
  %t186 = inttoptr i64 %t185 to ptr
  %t187 = call ptr @__olang_held_alloc(ptr %t186, i64 %t184)
  %t188 = insertvalue { i64, ptr } undef, i64 %t183, 0
  %t189 = insertvalue { i64, ptr } %t188, ptr %t187, 1
  store { i64, ptr } %t189, ptr %l67, !tbaa !27
  store i64 0, ptr %l72, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb30
bb29:
  %t190 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t191 = extractvalue { i64, ptr } %t190, 0
  %t193 = icmp eq i64 %t191, 0
  br i1 %t193, label %bb36, label %bb37
bb30:
  %t195 = load i64, ptr %l9, !tbaa !24
  %t196 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t198 = extractvalue { i64, ptr } %t196, 0
  %t201 = icmp slt i64 %t195, %t198
  %t203 = xor i1 %t201, true
  br i1 %t203, label %bb31, label %bb32
bb31:
  br label %bb35
bb32:
  br label %bb33
bb33:
  %t205 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t205, ptr %l78, !tbaa !27
  %t206 = load i64, ptr %l9, !tbaa !24
  %t208 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t209 = load ptr, ptr %t208, !tbaa !27
  %t210 = getelementptr i64, ptr %t209, i64 %t206
  %t211 = load i64, ptr %t210, !tbaa !34
  %t213 = load i64, ptr %l72, !tbaa !24
  %t214 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t215 = load ptr, ptr %t214, !tbaa !27
  %t216 = getelementptr i64, ptr %t215, i64 %t213
  store i64 %t211, ptr %t216, !tbaa !34
  %t217 = load i64, ptr %l72, !tbaa !24
  %t218 = add i64 %t217, 1
  store i64 %t218, ptr %l72, !tbaa !24
  br label %bb34
bb34:
  %t219 = load i64, ptr %l9, !tbaa !24
  %t222 = add i64 %t219, 1
  store i64 %t222, ptr %l9, !tbaa !24
  br label %bb30
bb35:
  br label %bb29
bb36:
  store { i64, ptr } zeroinitializer, ptr %l67, !tbaa !27
  br label %bb37
bb37:
  %t224 = load i64, ptr %l65
  %t225 = inttoptr i64 %t224 to ptr
  %t226 = load { i64, ptr }, ptr %l67
  %t227 = extractvalue { i64, ptr } %t226, 1
  %t228 = call ptr @__olang_region_or(ptr %t227, ptr null)
  %t229 = icmp ne ptr %t228, null
  %t230 = select i1 %t229, ptr %t228, ptr null
  call void @__olang_region_settle_in(ptr %t225, ptr %t230)
  %t231 = load ptr, ptr %l55, !tbaa !29
  %t232 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t231, i32 0, i32 1
  %t233 = load { i64, ptr }, ptr %t232, !tbaa !27
  store { i64, ptr } %t233, ptr %l86, !tbaa !27
  %t234 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t235 = load ptr, ptr %l55, !tbaa !29
  %t236 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t235, i32 0, i32 1
  store { i64, ptr } %t234, ptr %t236, !tbaa !27
  %t237 = load { i64, ptr }, ptr %l86
  %t238 = extractvalue { i64, ptr } %t237, 0
  %t239 = extractvalue { i64, ptr } %t237, 1
  call void @__olang_region_release_part(ptr %t239, i64 %t238)
  store { i64, ptr } zeroinitializer, ptr %l86
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_Hf1b08312c9801b2ab1b340dc49fbc612(ptr %v0, ptr %a0) noinline cold #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca { i64, ptr }
  %l5 = alloca i64
  %l7 = alloca { i64, ptr }
  %l9 = alloca i64
  %l14 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l31 = alloca i64
  %l33 = alloca { i64, ptr }
  %l34 = alloca i64
  %l40 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l49 = alloca i64
  %l50 = alloca i64
  %l54 = alloca ptr
  %l55 = alloca { i64, ptr }
  %l57 = alloca i64
  %l58 = alloca i64
  %l64 = alloca i64
  %l65 = alloca i64
  %l66 = alloca { i64, ptr }
  %l68 = alloca { i64, ptr }
  %l71 = alloca i64
  %l77 = alloca { i64, ptr }
  %l85 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp slt i64 %t6, 4
  br i1 %t8, label %bb1, label %bb2
bb1:
  store i64 8, ptr %l14, !tbaa !24
  br label %bb3
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t17 = mul i64 %t15, 2
  store i64 %t17, ptr %l14, !tbaa !24
  br label %bb3
bb3:
  %t19 = load i64, ptr %l14, !tbaa !24
  store i64 %t19, ptr %l1, !tbaa !24
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t20, i32 0, i32 0
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !27
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l21, !tbaa !29
  store { i64, ptr } %t23, ptr %l22, !tbaa !27
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t27, i32 0, i32 3
  %t30 = load i64, ptr %t29, !tbaa !24
  store i64 %t30, ptr %l24, !tbaa !24
  %t31 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  store i64 %t32, ptr %l25, !tbaa !24
  %t33 = icmp sge i64 0, 0
  br i1 %t33, label %bb4, label %bb5
bb4:
  %t35 = load i64, ptr %l24, !tbaa !24
  %t36 = icmp sle i64 0, %t35
  br i1 %t36, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_6819ac57acf012f0_cfcc4d405fca79c)
  unreachable
bb6:
  %t38 = load i64, ptr %l24, !tbaa !24
  %t39 = load i64, ptr %l25, !tbaa !24
  %t40 = icmp sle i64 %t38, %t39
  br i1 %t40, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_6819ac57acf012f0_cfcc4d405fca79c)
  unreachable
bb8:
  %t42 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = load i64, ptr %l24, !tbaa !24
  %t45 = getelementptr %"std/prelude/map:MapEntry.39ab5235a9e7cc4d21ab272df52b187f", ptr %t43, i64 0
  %t46 = sub i64 %t44, 0
  %t47 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t45, 1
  store { i64, ptr } %t48, ptr %l3, !tbaa !27
  %t50 = load i64, ptr %l1, !tbaa !24
  %t52 = call ptr @__olang_region_make_part(ptr %v0)
  %t53 = ptrtoint ptr %t52 to i64
  store i64 %t53, ptr %l31, !tbaa !24
  %t56 = mul i64 %t50, 48
  %t57 = load i64, ptr %l31
  %t58 = inttoptr i64 %t57 to ptr
  %t59 = call ptr @__olang_scope_alloc_zeroed(ptr %t58, i64 %t56)
  %t60 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t61 = insertvalue { i64, ptr } %t60, ptr %t59, 1
  store { i64, ptr } %t61, ptr %l33, !tbaa !27
  store i64 0, ptr %l34, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_6819ac57acf012f0_cfcc4d405fca79c)
  unreachable
bb10:
  %t62 = load i64, ptr %l5, !tbaa !24
  %t63 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t63, 0
  %t68 = icmp slt i64 %t62, %t65
  %t70 = xor i1 %t68, true
  br i1 %t70, label %bb11, label %bb12
bb11:
  br label %bb15
bb12:
  br label %bb13
bb13:
  %t72 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t72, ptr %l40, !tbaa !27
  %t73 = load i64, ptr %l5, !tbaa !24
  %t75 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = getelementptr %"std/prelude/map:MapEntry.39ab5235a9e7cc4d21ab272df52b187f", ptr %t76, i64 %t73
  %t78 = load %"std/prelude/map:MapEntry.39ab5235a9e7cc4d21ab272df52b187f", ptr %t77
  store %"std/prelude/map:MapEntry.39ab5235a9e7cc4d21ab272df52b187f" zeroinitializer, ptr %t77
  %t80 = load i64, ptr %l34, !tbaa !24
  %t81 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !27
  %t83 = getelementptr %"std/prelude/map:MapEntry.39ab5235a9e7cc4d21ab272df52b187f", ptr %t82, i64 %t80
  store %"std/prelude/map:MapEntry.39ab5235a9e7cc4d21ab272df52b187f" %t78, ptr %t83
  %t84 = load i64, ptr %l34, !tbaa !24
  %t85 = add i64 %t84, 1
  store i64 %t85, ptr %l34, !tbaa !24
  br label %bb14
bb14:
  %t86 = load i64, ptr %l5, !tbaa !24
  %t89 = add i64 %t86, 1
  store i64 %t89, ptr %l5, !tbaa !24
  br label %bb10
bb15:
  %t91 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t92 = extractvalue { i64, ptr } %t91, 0
  %t94 = icmp eq i64 %t92, 0
  br i1 %t94, label %bb16, label %bb17
bb16:
  store { i64, ptr } zeroinitializer, ptr %l33, !tbaa !27
  br label %bb17
bb17:
  %t96 = load i64, ptr %l31
  %t97 = inttoptr i64 %t96 to ptr
  %t98 = load { i64, ptr }, ptr %l33
  %t99 = extractvalue { i64, ptr } %t98, 1
  %t100 = call ptr @__olang_region_or(ptr %t99, ptr null)
  %t101 = icmp ne ptr %t100, null
  %t102 = select i1 %t101, ptr %t100, ptr null
  call void @__olang_region_settle_in(ptr %t97, ptr %t102)
  %t103 = load ptr, ptr %l21, !tbaa !29
  %t104 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t103, i32 0, i32 0
  %t105 = load { i64, ptr }, ptr %t104, !tbaa !27
  store { i64, ptr } %t105, ptr %l48, !tbaa !27
  %t106 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t107 = load ptr, ptr %l21, !tbaa !29
  %t108 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t107, i32 0, i32 0
  store { i64, ptr } %t106, ptr %t108, !tbaa !27
  %t109 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t110 = extractvalue { i64, ptr } %t109, 0
  store i64 %t110, ptr %l49, !tbaa !24
  store i64 0, ptr %l50, !tbaa !24
  br label %bb18
bb18:
  %t111 = load i64, ptr %l50, !tbaa !24
  %t112 = load i64, ptr %l49, !tbaa !24
  %t113 = icmp slt i64 %t111, %t112
  br i1 %t113, label %bb19, label %bb20
bb19:
  %t115 = load i64, ptr %l50, !tbaa !24
  %t116 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t117 = load ptr, ptr %t116, !tbaa !27
  %t118 = getelementptr %"std/prelude/map:MapEntry.39ab5235a9e7cc4d21ab272df52b187f", ptr %t117, i64 %t115
  %t119 = getelementptr %"std/prelude/map:MapEntry.39ab5235a9e7cc4d21ab272df52b187f", ptr %t118, i32 0, i32 1
  %t120 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t119, i32 0, i32 0
  %t121 = load { i64, ptr }, ptr %t120
  %t122 = extractvalue { i64, ptr } %t121, 0
  %t123 = extractvalue { i64, ptr } %t121, 1
  call void @__olang_region_release_part(ptr %t123, i64 %t122)
  store { i64, ptr } zeroinitializer, ptr %t120
  %t124 = load i64, ptr %l50, !tbaa !24
  %t125 = add i64 %t124, 1
  store i64 %t125, ptr %l50, !tbaa !24
  br label %bb18
bb20:
  %t126 = load { i64, ptr }, ptr %l48
  %t127 = extractvalue { i64, ptr } %t126, 0
  %t128 = extractvalue { i64, ptr } %t126, 1
  call void @__olang_region_release_part(ptr %t128, i64 %t127)
  store { i64, ptr } zeroinitializer, ptr %l48
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t131 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t129, i32 0, i32 1
  %t132 = load { i64, ptr }, ptr %t131, !tbaa !27
  %t134 = load ptr, ptr %l0, !tbaa !29
  store ptr %t134, ptr %l54, !tbaa !29
  store { i64, ptr } %t132, ptr %l55, !tbaa !27
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t138 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t136, i32 0, i32 3
  %t139 = load i64, ptr %t138, !tbaa !24
  store i64 %t139, ptr %l57, !tbaa !24
  %t140 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t141 = extractvalue { i64, ptr } %t140, 0
  store i64 %t141, ptr %l58, !tbaa !24
  %t142 = icmp sge i64 0, 0
  br i1 %t142, label %bb21, label %bb22
bb21:
  %t144 = load i64, ptr %l57, !tbaa !24
  %t145 = icmp sle i64 0, %t144
  br i1 %t145, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_7f22b794516974cd_9815abd4368ca509)
  unreachable
bb23:
  %t147 = load i64, ptr %l57, !tbaa !24
  %t148 = load i64, ptr %l58, !tbaa !24
  %t149 = icmp sle i64 %t147, %t148
  br i1 %t149, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_7f22b794516974cd_9815abd4368ca509)
  unreachable
bb25:
  %t151 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t152 = load ptr, ptr %t151, !tbaa !27
  %t153 = load i64, ptr %l57, !tbaa !24
  %t154 = getelementptr i64, ptr %t152, i64 0
  %t155 = sub i64 %t153, 0
  %t156 = insertvalue { i64, ptr } undef, i64 %t155, 0
  %t157 = insertvalue { i64, ptr } %t156, ptr %t154, 1
  store { i64, ptr } %t157, ptr %l7, !tbaa !27
  %t159 = load i64, ptr %l1, !tbaa !24
  %t161 = call ptr @__olang_region_make_part(ptr %v0)
  %t162 = ptrtoint ptr %t161 to i64
  store i64 %t162, ptr %l64, !tbaa !24
  store i64 %t159, ptr %l65, !tbaa !24
  %t164 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t166 = load i64, ptr %l65, !tbaa !24
  %t167 = extractvalue { i64, ptr } %t164, 0
  %t168 = mul i64 %t167, 8
  %t169 = mul i64 %t166, 8
  %t170 = extractvalue { i64, ptr } %t164, 1
  %t171 = call ptr @__olang_grow_in_place(ptr %t170, i64 %t168, i64 %t169, i64 %t166)
  %t172 = icmp ne ptr %t171, null
  %t173 = select i1 %t172, i64 %t166, i64 0
  %t174 = insertvalue { i64, ptr } undef, i64 %t173, 0
  %t175 = insertvalue { i64, ptr } %t174, ptr %t171, 1
  store { i64, ptr } %t175, ptr %l68, !tbaa !27
  %t176 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t177 = extractvalue { i64, ptr } %t176, 0
  %t179 = icmp ne i64 %t177, 0
  br i1 %t179, label %bb27, label %bb28
bb26:
  call void @__olang_check_failed(ptr @olang_loc_7f22b794516974cd_9815abd4368ca509)
  unreachable
bb27:
  %t181 = load { i64, ptr }, ptr %l68, !tbaa !27
  store { i64, ptr } %t181, ptr %l66, !tbaa !27
  br label %bb29
bb28:
  %t182 = load i64, ptr %l65, !tbaa !24
  %t183 = mul i64 %t182, 8
  %t184 = load i64, ptr %l64
  %t185 = inttoptr i64 %t184 to ptr
  %t186 = call ptr @__olang_held_alloc(ptr %t185, i64 %t183)
  %t187 = insertvalue { i64, ptr } undef, i64 %t182, 0
  %t188 = insertvalue { i64, ptr } %t187, ptr %t186, 1
  store { i64, ptr } %t188, ptr %l66, !tbaa !27
  store i64 0, ptr %l71, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb30
bb29:
  %t189 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t190 = extractvalue { i64, ptr } %t189, 0
  %t192 = icmp eq i64 %t190, 0
  br i1 %t192, label %bb36, label %bb37
bb30:
  %t194 = load i64, ptr %l9, !tbaa !24
  %t195 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t197 = extractvalue { i64, ptr } %t195, 0
  %t200 = icmp slt i64 %t194, %t197
  %t202 = xor i1 %t200, true
  br i1 %t202, label %bb31, label %bb32
bb31:
  br label %bb35
bb32:
  br label %bb33
bb33:
  %t204 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t204, ptr %l77, !tbaa !27
  %t205 = load i64, ptr %l9, !tbaa !24
  %t207 = getelementptr { i64, ptr }, ptr %l77, i32 0, i32 1
  %t208 = load ptr, ptr %t207, !tbaa !27
  %t209 = getelementptr i64, ptr %t208, i64 %t205
  %t210 = load i64, ptr %t209, !tbaa !34
  %t212 = load i64, ptr %l71, !tbaa !24
  %t213 = getelementptr { i64, ptr }, ptr %l66, i32 0, i32 1
  %t214 = load ptr, ptr %t213, !tbaa !27
  %t215 = getelementptr i64, ptr %t214, i64 %t212
  store i64 %t210, ptr %t215, !tbaa !34
  %t216 = load i64, ptr %l71, !tbaa !24
  %t217 = add i64 %t216, 1
  store i64 %t217, ptr %l71, !tbaa !24
  br label %bb34
bb34:
  %t218 = load i64, ptr %l9, !tbaa !24
  %t221 = add i64 %t218, 1
  store i64 %t221, ptr %l9, !tbaa !24
  br label %bb30
bb35:
  br label %bb29
bb36:
  store { i64, ptr } zeroinitializer, ptr %l66, !tbaa !27
  br label %bb37
bb37:
  %t223 = load i64, ptr %l64
  %t224 = inttoptr i64 %t223 to ptr
  %t225 = load { i64, ptr }, ptr %l66
  %t226 = extractvalue { i64, ptr } %t225, 1
  %t227 = call ptr @__olang_region_or(ptr %t226, ptr null)
  %t228 = icmp ne ptr %t227, null
  %t229 = select i1 %t228, ptr %t227, ptr null
  call void @__olang_region_settle_in(ptr %t224, ptr %t229)
  %t230 = load ptr, ptr %l54, !tbaa !29
  %t231 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t230, i32 0, i32 1
  %t232 = load { i64, ptr }, ptr %t231, !tbaa !27
  store { i64, ptr } %t232, ptr %l85, !tbaa !27
  %t233 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t234 = load ptr, ptr %l54, !tbaa !29
  %t235 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t234, i32 0, i32 1
  store { i64, ptr } %t233, ptr %t235, !tbaa !27
  %t236 = load { i64, ptr }, ptr %l85
  %t237 = extractvalue { i64, ptr } %t236, 0
  %t238 = extractvalue { i64, ptr } %t236, 1
  call void @__olang_region_release_part(ptr %t238, i64 %t237)
  store { i64, ptr } zeroinitializer, ptr %l85
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_2c_20Boo_H8535be735db37b705e6cb6687b9e98ca(ptr %v0, ptr %a0) noinline cold #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca { i64, ptr }
  %l5 = alloca i64
  %l7 = alloca { i64, ptr }
  %l9 = alloca i64
  %l14 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l31 = alloca i64
  %l33 = alloca { i64, ptr }
  %l34 = alloca i64
  %l40 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l51 = alloca ptr
  %l52 = alloca { i64, ptr }
  %l54 = alloca i64
  %l55 = alloca i64
  %l61 = alloca i64
  %l62 = alloca i64
  %l63 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %l68 = alloca i64
  %l74 = alloca { i64, ptr }
  %l82 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp slt i64 %t6, 4
  br i1 %t8, label %bb1, label %bb2
bb1:
  store i64 8, ptr %l14, !tbaa !24
  br label %bb3
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t17 = mul i64 %t15, 2
  store i64 %t17, ptr %l14, !tbaa !24
  br label %bb3
bb3:
  %t19 = load i64, ptr %l14, !tbaa !24
  store i64 %t19, ptr %l1, !tbaa !24
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t20, i32 0, i32 0
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !27
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l21, !tbaa !29
  store { i64, ptr } %t23, ptr %l22, !tbaa !27
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t27, i32 0, i32 3
  %t30 = load i64, ptr %t29, !tbaa !24
  store i64 %t30, ptr %l24, !tbaa !24
  %t31 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  store i64 %t32, ptr %l25, !tbaa !24
  %t33 = icmp sge i64 0, 0
  br i1 %t33, label %bb4, label %bb5
bb4:
  %t35 = load i64, ptr %l24, !tbaa !24
  %t36 = icmp sle i64 0, %t35
  br i1 %t36, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_6fd14cdf40707d56_2f0bca432f63f912)
  unreachable
bb6:
  %t38 = load i64, ptr %l24, !tbaa !24
  %t39 = load i64, ptr %l25, !tbaa !24
  %t40 = icmp sle i64 %t38, %t39
  br i1 %t40, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_6fd14cdf40707d56_2f0bca432f63f912)
  unreachable
bb8:
  %t42 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = load i64, ptr %l24, !tbaa !24
  %t45 = getelementptr %"std/prelude/map:MapEntry.b259c967cf16ba62f29f59ede353f7e9", ptr %t43, i64 0
  %t46 = sub i64 %t44, 0
  %t47 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t45, 1
  store { i64, ptr } %t48, ptr %l3, !tbaa !27
  %t50 = load i64, ptr %l1, !tbaa !24
  %t52 = call ptr @__olang_region_make_part(ptr %v0)
  %t53 = ptrtoint ptr %t52 to i64
  store i64 %t53, ptr %l31, !tbaa !24
  %t56 = mul i64 %t50, 24
  %t57 = load i64, ptr %l31
  %t58 = inttoptr i64 %t57 to ptr
  %t59 = call ptr @__olang_scope_alloc_zeroed(ptr %t58, i64 %t56)
  %t60 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t61 = insertvalue { i64, ptr } %t60, ptr %t59, 1
  store { i64, ptr } %t61, ptr %l33, !tbaa !27
  store i64 0, ptr %l34, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_6fd14cdf40707d56_2f0bca432f63f912)
  unreachable
bb10:
  %t62 = load i64, ptr %l5, !tbaa !24
  %t63 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t63, 0
  %t68 = icmp slt i64 %t62, %t65
  %t70 = xor i1 %t68, true
  br i1 %t70, label %bb11, label %bb12
bb11:
  br label %bb15
bb12:
  br label %bb13
bb13:
  %t72 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t72, ptr %l40, !tbaa !27
  %t73 = load i64, ptr %l5, !tbaa !24
  %t75 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = getelementptr %"std/prelude/map:MapEntry.b259c967cf16ba62f29f59ede353f7e9", ptr %t76, i64 %t73
  %t78 = load %"std/prelude/map:MapEntry.b259c967cf16ba62f29f59ede353f7e9", ptr %t77
  store %"std/prelude/map:MapEntry.b259c967cf16ba62f29f59ede353f7e9" zeroinitializer, ptr %t77
  %t80 = load i64, ptr %l34, !tbaa !24
  %t81 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !27
  %t83 = getelementptr %"std/prelude/map:MapEntry.b259c967cf16ba62f29f59ede353f7e9", ptr %t82, i64 %t80
  store %"std/prelude/map:MapEntry.b259c967cf16ba62f29f59ede353f7e9" %t78, ptr %t83
  %t84 = load i64, ptr %l34, !tbaa !24
  %t85 = add i64 %t84, 1
  store i64 %t85, ptr %l34, !tbaa !24
  br label %bb14
bb14:
  %t86 = load i64, ptr %l5, !tbaa !24
  %t89 = add i64 %t86, 1
  store i64 %t89, ptr %l5, !tbaa !24
  br label %bb10
bb15:
  %t91 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t92 = extractvalue { i64, ptr } %t91, 0
  %t94 = icmp eq i64 %t92, 0
  br i1 %t94, label %bb16, label %bb17
bb16:
  store { i64, ptr } zeroinitializer, ptr %l33, !tbaa !27
  br label %bb17
bb17:
  %t96 = load i64, ptr %l31
  %t97 = inttoptr i64 %t96 to ptr
  %t98 = load { i64, ptr }, ptr %l33
  %t99 = extractvalue { i64, ptr } %t98, 1
  %t100 = call ptr @__olang_region_or(ptr %t99, ptr null)
  %t101 = icmp ne ptr %t100, null
  %t102 = select i1 %t101, ptr %t100, ptr null
  call void @__olang_region_settle_in(ptr %t97, ptr %t102)
  %t103 = load ptr, ptr %l21, !tbaa !29
  %t104 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t103, i32 0, i32 0
  %t105 = load { i64, ptr }, ptr %t104, !tbaa !27
  store { i64, ptr } %t105, ptr %l48, !tbaa !27
  %t106 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t107 = load ptr, ptr %l21, !tbaa !29
  %t108 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t107, i32 0, i32 0
  store { i64, ptr } %t106, ptr %t108, !tbaa !27
  %t109 = load { i64, ptr }, ptr %l48
  %t110 = extractvalue { i64, ptr } %t109, 0
  %t111 = extractvalue { i64, ptr } %t109, 1
  call void @__olang_region_release_part(ptr %t111, i64 %t110)
  store { i64, ptr } zeroinitializer, ptr %l48
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t114 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t112, i32 0, i32 1
  %t115 = load { i64, ptr }, ptr %t114, !tbaa !27
  %t117 = load ptr, ptr %l0, !tbaa !29
  store ptr %t117, ptr %l51, !tbaa !29
  store { i64, ptr } %t115, ptr %l52, !tbaa !27
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t121 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t119, i32 0, i32 3
  %t122 = load i64, ptr %t121, !tbaa !24
  store i64 %t122, ptr %l54, !tbaa !24
  %t123 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t124 = extractvalue { i64, ptr } %t123, 0
  store i64 %t124, ptr %l55, !tbaa !24
  %t125 = icmp sge i64 0, 0
  br i1 %t125, label %bb18, label %bb19
bb18:
  %t127 = load i64, ptr %l54, !tbaa !24
  %t128 = icmp sle i64 0, %t127
  br i1 %t128, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_6f3a6ec21bfbf2b3_3a2c7f61b161530f)
  unreachable
bb20:
  %t130 = load i64, ptr %l54, !tbaa !24
  %t131 = load i64, ptr %l55, !tbaa !24
  %t132 = icmp sle i64 %t130, %t131
  br i1 %t132, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_6f3a6ec21bfbf2b3_3a2c7f61b161530f)
  unreachable
bb22:
  %t134 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t135 = load ptr, ptr %t134, !tbaa !27
  %t136 = load i64, ptr %l54, !tbaa !24
  %t137 = getelementptr i64, ptr %t135, i64 0
  %t138 = sub i64 %t136, 0
  %t139 = insertvalue { i64, ptr } undef, i64 %t138, 0
  %t140 = insertvalue { i64, ptr } %t139, ptr %t137, 1
  store { i64, ptr } %t140, ptr %l7, !tbaa !27
  %t142 = load i64, ptr %l1, !tbaa !24
  %t144 = call ptr @__olang_region_make_part(ptr %v0)
  %t145 = ptrtoint ptr %t144 to i64
  store i64 %t145, ptr %l61, !tbaa !24
  store i64 %t142, ptr %l62, !tbaa !24
  %t147 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t149 = load i64, ptr %l62, !tbaa !24
  %t150 = extractvalue { i64, ptr } %t147, 0
  %t151 = mul i64 %t150, 8
  %t152 = mul i64 %t149, 8
  %t153 = extractvalue { i64, ptr } %t147, 1
  %t154 = call ptr @__olang_grow_in_place(ptr %t153, i64 %t151, i64 %t152, i64 %t149)
  %t155 = icmp ne ptr %t154, null
  %t156 = select i1 %t155, i64 %t149, i64 0
  %t157 = insertvalue { i64, ptr } undef, i64 %t156, 0
  %t158 = insertvalue { i64, ptr } %t157, ptr %t154, 1
  store { i64, ptr } %t158, ptr %l65, !tbaa !27
  %t159 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t160 = extractvalue { i64, ptr } %t159, 0
  %t162 = icmp ne i64 %t160, 0
  br i1 %t162, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_6f3a6ec21bfbf2b3_3a2c7f61b161530f)
  unreachable
bb24:
  %t164 = load { i64, ptr }, ptr %l65, !tbaa !27
  store { i64, ptr } %t164, ptr %l63, !tbaa !27
  br label %bb26
bb25:
  %t165 = load i64, ptr %l62, !tbaa !24
  %t166 = mul i64 %t165, 8
  %t167 = load i64, ptr %l61
  %t168 = inttoptr i64 %t167 to ptr
  %t169 = call ptr @__olang_held_alloc(ptr %t168, i64 %t166)
  %t170 = insertvalue { i64, ptr } undef, i64 %t165, 0
  %t171 = insertvalue { i64, ptr } %t170, ptr %t169, 1
  store { i64, ptr } %t171, ptr %l63, !tbaa !27
  store i64 0, ptr %l68, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb27
bb26:
  %t172 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t173 = extractvalue { i64, ptr } %t172, 0
  %t175 = icmp eq i64 %t173, 0
  br i1 %t175, label %bb33, label %bb34
bb27:
  %t177 = load i64, ptr %l9, !tbaa !24
  %t178 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t180 = extractvalue { i64, ptr } %t178, 0
  %t183 = icmp slt i64 %t177, %t180
  %t185 = xor i1 %t183, true
  br i1 %t185, label %bb28, label %bb29
bb28:
  br label %bb32
bb29:
  br label %bb30
bb30:
  %t187 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t187, ptr %l74, !tbaa !27
  %t188 = load i64, ptr %l9, !tbaa !24
  %t190 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t191 = load ptr, ptr %t190, !tbaa !27
  %t192 = getelementptr i64, ptr %t191, i64 %t188
  %t193 = load i64, ptr %t192, !tbaa !34
  %t195 = load i64, ptr %l68, !tbaa !24
  %t196 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t197 = load ptr, ptr %t196, !tbaa !27
  %t198 = getelementptr i64, ptr %t197, i64 %t195
  store i64 %t193, ptr %t198, !tbaa !34
  %t199 = load i64, ptr %l68, !tbaa !24
  %t200 = add i64 %t199, 1
  store i64 %t200, ptr %l68, !tbaa !24
  br label %bb31
bb31:
  %t201 = load i64, ptr %l9, !tbaa !24
  %t204 = add i64 %t201, 1
  store i64 %t204, ptr %l9, !tbaa !24
  br label %bb27
bb32:
  br label %bb26
bb33:
  store { i64, ptr } zeroinitializer, ptr %l63, !tbaa !27
  br label %bb34
bb34:
  %t206 = load i64, ptr %l61
  %t207 = inttoptr i64 %t206 to ptr
  %t208 = load { i64, ptr }, ptr %l63
  %t209 = extractvalue { i64, ptr } %t208, 1
  %t210 = call ptr @__olang_region_or(ptr %t209, ptr null)
  %t211 = icmp ne ptr %t210, null
  %t212 = select i1 %t211, ptr %t210, ptr null
  call void @__olang_region_settle_in(ptr %t207, ptr %t212)
  %t213 = load ptr, ptr %l51, !tbaa !29
  %t214 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t213, i32 0, i32 1
  %t215 = load { i64, ptr }, ptr %t214, !tbaa !27
  store { i64, ptr } %t215, ptr %l82, !tbaa !27
  %t216 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t217 = load ptr, ptr %l51, !tbaa !29
  %t218 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t217, i32 0, i32 1
  store { i64, ptr } %t216, ptr %t218, !tbaa !27
  %t219 = load { i64, ptr }, ptr %l82
  %t220 = extractvalue { i64, ptr } %t219, 0
  %t221 = extractvalue { i64, ptr } %t219, 1
  call void @__olang_region_release_part(ptr %t221, i64 %t220)
  store { i64, ptr } zeroinitializer, ptr %l82
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_2c_20I64_H74b9f0229dd715100341005d48ea043b(ptr %v0, ptr %a0) noinline cold #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca { i64, ptr }
  %l5 = alloca i64
  %l7 = alloca { i64, ptr }
  %l9 = alloca i64
  %l14 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l31 = alloca i64
  %l33 = alloca { i64, ptr }
  %l34 = alloca i64
  %l40 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l51 = alloca ptr
  %l52 = alloca { i64, ptr }
  %l54 = alloca i64
  %l55 = alloca i64
  %l61 = alloca i64
  %l62 = alloca i64
  %l63 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %l68 = alloca i64
  %l74 = alloca { i64, ptr }
  %l82 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp slt i64 %t6, 4
  br i1 %t8, label %bb1, label %bb2
bb1:
  store i64 8, ptr %l14, !tbaa !24
  br label %bb3
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t17 = mul i64 %t15, 2
  store i64 %t17, ptr %l14, !tbaa !24
  br label %bb3
bb3:
  %t19 = load i64, ptr %l14, !tbaa !24
  store i64 %t19, ptr %l1, !tbaa !24
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t20, i32 0, i32 0
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !27
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l21, !tbaa !29
  store { i64, ptr } %t23, ptr %l22, !tbaa !27
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t27, i32 0, i32 3
  %t30 = load i64, ptr %t29, !tbaa !24
  store i64 %t30, ptr %l24, !tbaa !24
  %t31 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  store i64 %t32, ptr %l25, !tbaa !24
  %t33 = icmp sge i64 0, 0
  br i1 %t33, label %bb4, label %bb5
bb4:
  %t35 = load i64, ptr %l24, !tbaa !24
  %t36 = icmp sle i64 0, %t35
  br i1 %t36, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_ca049a7d99d53f9f_ca8eea9c91e2bc6b)
  unreachable
bb6:
  %t38 = load i64, ptr %l24, !tbaa !24
  %t39 = load i64, ptr %l25, !tbaa !24
  %t40 = icmp sle i64 %t38, %t39
  br i1 %t40, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_ca049a7d99d53f9f_ca8eea9c91e2bc6b)
  unreachable
bb8:
  %t42 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = load i64, ptr %l24, !tbaa !24
  %t45 = getelementptr %"std/prelude/map:MapEntry.ef37386b9f0625afbaa73bd3cf091381", ptr %t43, i64 0
  %t46 = sub i64 %t44, 0
  %t47 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t45, 1
  store { i64, ptr } %t48, ptr %l3, !tbaa !27
  %t50 = load i64, ptr %l1, !tbaa !24
  %t52 = call ptr @__olang_region_make_part(ptr %v0)
  %t53 = ptrtoint ptr %t52 to i64
  store i64 %t53, ptr %l31, !tbaa !24
  %t56 = mul i64 %t50, 24
  %t57 = load i64, ptr %l31
  %t58 = inttoptr i64 %t57 to ptr
  %t59 = call ptr @__olang_scope_alloc_zeroed(ptr %t58, i64 %t56)
  %t60 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t61 = insertvalue { i64, ptr } %t60, ptr %t59, 1
  store { i64, ptr } %t61, ptr %l33, !tbaa !27
  store i64 0, ptr %l34, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_ca049a7d99d53f9f_ca8eea9c91e2bc6b)
  unreachable
bb10:
  %t62 = load i64, ptr %l5, !tbaa !24
  %t63 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t63, 0
  %t68 = icmp slt i64 %t62, %t65
  %t70 = xor i1 %t68, true
  br i1 %t70, label %bb11, label %bb12
bb11:
  br label %bb15
bb12:
  br label %bb13
bb13:
  %t72 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t72, ptr %l40, !tbaa !27
  %t73 = load i64, ptr %l5, !tbaa !24
  %t75 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = getelementptr %"std/prelude/map:MapEntry.ef37386b9f0625afbaa73bd3cf091381", ptr %t76, i64 %t73
  %t78 = load %"std/prelude/map:MapEntry.ef37386b9f0625afbaa73bd3cf091381", ptr %t77
  store %"std/prelude/map:MapEntry.ef37386b9f0625afbaa73bd3cf091381" zeroinitializer, ptr %t77
  %t80 = load i64, ptr %l34, !tbaa !24
  %t81 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !27
  %t83 = getelementptr %"std/prelude/map:MapEntry.ef37386b9f0625afbaa73bd3cf091381", ptr %t82, i64 %t80
  store %"std/prelude/map:MapEntry.ef37386b9f0625afbaa73bd3cf091381" %t78, ptr %t83
  %t84 = load i64, ptr %l34, !tbaa !24
  %t85 = add i64 %t84, 1
  store i64 %t85, ptr %l34, !tbaa !24
  br label %bb14
bb14:
  %t86 = load i64, ptr %l5, !tbaa !24
  %t89 = add i64 %t86, 1
  store i64 %t89, ptr %l5, !tbaa !24
  br label %bb10
bb15:
  %t91 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t92 = extractvalue { i64, ptr } %t91, 0
  %t94 = icmp eq i64 %t92, 0
  br i1 %t94, label %bb16, label %bb17
bb16:
  store { i64, ptr } zeroinitializer, ptr %l33, !tbaa !27
  br label %bb17
bb17:
  %t96 = load i64, ptr %l31
  %t97 = inttoptr i64 %t96 to ptr
  %t98 = load { i64, ptr }, ptr %l33
  %t99 = extractvalue { i64, ptr } %t98, 1
  %t100 = call ptr @__olang_region_or(ptr %t99, ptr null)
  %t101 = icmp ne ptr %t100, null
  %t102 = select i1 %t101, ptr %t100, ptr null
  call void @__olang_region_settle_in(ptr %t97, ptr %t102)
  %t103 = load ptr, ptr %l21, !tbaa !29
  %t104 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t103, i32 0, i32 0
  %t105 = load { i64, ptr }, ptr %t104, !tbaa !27
  store { i64, ptr } %t105, ptr %l48, !tbaa !27
  %t106 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t107 = load ptr, ptr %l21, !tbaa !29
  %t108 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t107, i32 0, i32 0
  store { i64, ptr } %t106, ptr %t108, !tbaa !27
  %t109 = load { i64, ptr }, ptr %l48
  %t110 = extractvalue { i64, ptr } %t109, 0
  %t111 = extractvalue { i64, ptr } %t109, 1
  call void @__olang_region_release_part(ptr %t111, i64 %t110)
  store { i64, ptr } zeroinitializer, ptr %l48
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t114 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t112, i32 0, i32 1
  %t115 = load { i64, ptr }, ptr %t114, !tbaa !27
  %t117 = load ptr, ptr %l0, !tbaa !29
  store ptr %t117, ptr %l51, !tbaa !29
  store { i64, ptr } %t115, ptr %l52, !tbaa !27
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t121 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t119, i32 0, i32 3
  %t122 = load i64, ptr %t121, !tbaa !24
  store i64 %t122, ptr %l54, !tbaa !24
  %t123 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t124 = extractvalue { i64, ptr } %t123, 0
  store i64 %t124, ptr %l55, !tbaa !24
  %t125 = icmp sge i64 0, 0
  br i1 %t125, label %bb18, label %bb19
bb18:
  %t127 = load i64, ptr %l54, !tbaa !24
  %t128 = icmp sle i64 0, %t127
  br i1 %t128, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_ad7ed497ea8ab222_f6572ed697be0e6e)
  unreachable
bb20:
  %t130 = load i64, ptr %l54, !tbaa !24
  %t131 = load i64, ptr %l55, !tbaa !24
  %t132 = icmp sle i64 %t130, %t131
  br i1 %t132, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_ad7ed497ea8ab222_f6572ed697be0e6e)
  unreachable
bb22:
  %t134 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t135 = load ptr, ptr %t134, !tbaa !27
  %t136 = load i64, ptr %l54, !tbaa !24
  %t137 = getelementptr i64, ptr %t135, i64 0
  %t138 = sub i64 %t136, 0
  %t139 = insertvalue { i64, ptr } undef, i64 %t138, 0
  %t140 = insertvalue { i64, ptr } %t139, ptr %t137, 1
  store { i64, ptr } %t140, ptr %l7, !tbaa !27
  %t142 = load i64, ptr %l1, !tbaa !24
  %t144 = call ptr @__olang_region_make_part(ptr %v0)
  %t145 = ptrtoint ptr %t144 to i64
  store i64 %t145, ptr %l61, !tbaa !24
  store i64 %t142, ptr %l62, !tbaa !24
  %t147 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t149 = load i64, ptr %l62, !tbaa !24
  %t150 = extractvalue { i64, ptr } %t147, 0
  %t151 = mul i64 %t150, 8
  %t152 = mul i64 %t149, 8
  %t153 = extractvalue { i64, ptr } %t147, 1
  %t154 = call ptr @__olang_grow_in_place(ptr %t153, i64 %t151, i64 %t152, i64 %t149)
  %t155 = icmp ne ptr %t154, null
  %t156 = select i1 %t155, i64 %t149, i64 0
  %t157 = insertvalue { i64, ptr } undef, i64 %t156, 0
  %t158 = insertvalue { i64, ptr } %t157, ptr %t154, 1
  store { i64, ptr } %t158, ptr %l65, !tbaa !27
  %t159 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t160 = extractvalue { i64, ptr } %t159, 0
  %t162 = icmp ne i64 %t160, 0
  br i1 %t162, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_ad7ed497ea8ab222_f6572ed697be0e6e)
  unreachable
bb24:
  %t164 = load { i64, ptr }, ptr %l65, !tbaa !27
  store { i64, ptr } %t164, ptr %l63, !tbaa !27
  br label %bb26
bb25:
  %t165 = load i64, ptr %l62, !tbaa !24
  %t166 = mul i64 %t165, 8
  %t167 = load i64, ptr %l61
  %t168 = inttoptr i64 %t167 to ptr
  %t169 = call ptr @__olang_held_alloc(ptr %t168, i64 %t166)
  %t170 = insertvalue { i64, ptr } undef, i64 %t165, 0
  %t171 = insertvalue { i64, ptr } %t170, ptr %t169, 1
  store { i64, ptr } %t171, ptr %l63, !tbaa !27
  store i64 0, ptr %l68, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb27
bb26:
  %t172 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t173 = extractvalue { i64, ptr } %t172, 0
  %t175 = icmp eq i64 %t173, 0
  br i1 %t175, label %bb33, label %bb34
bb27:
  %t177 = load i64, ptr %l9, !tbaa !24
  %t178 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t180 = extractvalue { i64, ptr } %t178, 0
  %t183 = icmp slt i64 %t177, %t180
  %t185 = xor i1 %t183, true
  br i1 %t185, label %bb28, label %bb29
bb28:
  br label %bb32
bb29:
  br label %bb30
bb30:
  %t187 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t187, ptr %l74, !tbaa !27
  %t188 = load i64, ptr %l9, !tbaa !24
  %t190 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t191 = load ptr, ptr %t190, !tbaa !27
  %t192 = getelementptr i64, ptr %t191, i64 %t188
  %t193 = load i64, ptr %t192, !tbaa !34
  %t195 = load i64, ptr %l68, !tbaa !24
  %t196 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t197 = load ptr, ptr %t196, !tbaa !27
  %t198 = getelementptr i64, ptr %t197, i64 %t195
  store i64 %t193, ptr %t198, !tbaa !34
  %t199 = load i64, ptr %l68, !tbaa !24
  %t200 = add i64 %t199, 1
  store i64 %t200, ptr %l68, !tbaa !24
  br label %bb31
bb31:
  %t201 = load i64, ptr %l9, !tbaa !24
  %t204 = add i64 %t201, 1
  store i64 %t204, ptr %l9, !tbaa !24
  br label %bb27
bb32:
  br label %bb26
bb33:
  store { i64, ptr } zeroinitializer, ptr %l63, !tbaa !27
  br label %bb34
bb34:
  %t206 = load i64, ptr %l61
  %t207 = inttoptr i64 %t206 to ptr
  %t208 = load { i64, ptr }, ptr %l63
  %t209 = extractvalue { i64, ptr } %t208, 1
  %t210 = call ptr @__olang_region_or(ptr %t209, ptr null)
  %t211 = icmp ne ptr %t210, null
  %t212 = select i1 %t211, ptr %t210, ptr null
  call void @__olang_region_settle_in(ptr %t207, ptr %t212)
  %t213 = load ptr, ptr %l51, !tbaa !29
  %t214 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t213, i32 0, i32 1
  %t215 = load { i64, ptr }, ptr %t214, !tbaa !27
  store { i64, ptr } %t215, ptr %l82, !tbaa !27
  %t216 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t217 = load ptr, ptr %l51, !tbaa !29
  %t218 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t217, i32 0, i32 1
  store { i64, ptr } %t216, ptr %t218, !tbaa !27
  %t219 = load { i64, ptr }, ptr %l82
  %t220 = extractvalue { i64, ptr } %t219, 0
  %t221 = extractvalue { i64, ptr } %t219, 1
  call void @__olang_region_release_part(ptr %t221, i64 %t220)
  store { i64, ptr } zeroinitializer, ptr %l82
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_2c_20com_H7c40584ba86947de526b697d62a7cb6b(ptr %v0, ptr %a0) noinline cold #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca { i64, ptr }
  %l5 = alloca i64
  %l7 = alloca { i64, ptr }
  %l9 = alloca i64
  %l14 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l31 = alloca i64
  %l33 = alloca { i64, ptr }
  %l34 = alloca i64
  %l40 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l51 = alloca ptr
  %l52 = alloca { i64, ptr }
  %l54 = alloca i64
  %l55 = alloca i64
  %l61 = alloca i64
  %l62 = alloca i64
  %l63 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %l68 = alloca i64
  %l74 = alloca { i64, ptr }
  %l82 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp slt i64 %t6, 4
  br i1 %t8, label %bb1, label %bb2
bb1:
  store i64 8, ptr %l14, !tbaa !24
  br label %bb3
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t17 = mul i64 %t15, 2
  store i64 %t17, ptr %l14, !tbaa !24
  br label %bb3
bb3:
  %t19 = load i64, ptr %l14, !tbaa !24
  store i64 %t19, ptr %l1, !tbaa !24
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t20, i32 0, i32 0
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !27
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l21, !tbaa !29
  store { i64, ptr } %t23, ptr %l22, !tbaa !27
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t27, i32 0, i32 3
  %t30 = load i64, ptr %t29, !tbaa !24
  store i64 %t30, ptr %l24, !tbaa !24
  %t31 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  store i64 %t32, ptr %l25, !tbaa !24
  %t33 = icmp sge i64 0, 0
  br i1 %t33, label %bb4, label %bb5
bb4:
  %t35 = load i64, ptr %l24, !tbaa !24
  %t36 = icmp sle i64 0, %t35
  br i1 %t36, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_2894e3ab3f2af7f3_8e483e5495b872bf)
  unreachable
bb6:
  %t38 = load i64, ptr %l24, !tbaa !24
  %t39 = load i64, ptr %l25, !tbaa !24
  %t40 = icmp sle i64 %t38, %t39
  br i1 %t40, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_2894e3ab3f2af7f3_8e483e5495b872bf)
  unreachable
bb8:
  %t42 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = load i64, ptr %l24, !tbaa !24
  %t45 = getelementptr %"std/prelude/map:MapEntry.34f0a853427d04ec822d282fa19767ca", ptr %t43, i64 0
  %t46 = sub i64 %t44, 0
  %t47 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t45, 1
  store { i64, ptr } %t48, ptr %l3, !tbaa !27
  %t50 = load i64, ptr %l1, !tbaa !24
  %t52 = call ptr @__olang_region_make_part(ptr %v0)
  %t53 = ptrtoint ptr %t52 to i64
  store i64 %t53, ptr %l31, !tbaa !24
  %t56 = mul i64 %t50, 24
  %t57 = load i64, ptr %l31
  %t58 = inttoptr i64 %t57 to ptr
  %t59 = call ptr @__olang_scope_alloc_zeroed(ptr %t58, i64 %t56)
  %t60 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t61 = insertvalue { i64, ptr } %t60, ptr %t59, 1
  store { i64, ptr } %t61, ptr %l33, !tbaa !27
  store i64 0, ptr %l34, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_2894e3ab3f2af7f3_8e483e5495b872bf)
  unreachable
bb10:
  %t62 = load i64, ptr %l5, !tbaa !24
  %t63 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t63, 0
  %t68 = icmp slt i64 %t62, %t65
  %t70 = xor i1 %t68, true
  br i1 %t70, label %bb11, label %bb12
bb11:
  br label %bb15
bb12:
  br label %bb13
bb13:
  %t72 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t72, ptr %l40, !tbaa !27
  %t73 = load i64, ptr %l5, !tbaa !24
  %t75 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = getelementptr %"std/prelude/map:MapEntry.34f0a853427d04ec822d282fa19767ca", ptr %t76, i64 %t73
  %t78 = load %"std/prelude/map:MapEntry.34f0a853427d04ec822d282fa19767ca", ptr %t77
  store %"std/prelude/map:MapEntry.34f0a853427d04ec822d282fa19767ca" zeroinitializer, ptr %t77
  %t80 = load i64, ptr %l34, !tbaa !24
  %t81 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !27
  %t83 = getelementptr %"std/prelude/map:MapEntry.34f0a853427d04ec822d282fa19767ca", ptr %t82, i64 %t80
  store %"std/prelude/map:MapEntry.34f0a853427d04ec822d282fa19767ca" %t78, ptr %t83
  %t84 = load i64, ptr %l34, !tbaa !24
  %t85 = add i64 %t84, 1
  store i64 %t85, ptr %l34, !tbaa !24
  br label %bb14
bb14:
  %t86 = load i64, ptr %l5, !tbaa !24
  %t89 = add i64 %t86, 1
  store i64 %t89, ptr %l5, !tbaa !24
  br label %bb10
bb15:
  %t91 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t92 = extractvalue { i64, ptr } %t91, 0
  %t94 = icmp eq i64 %t92, 0
  br i1 %t94, label %bb16, label %bb17
bb16:
  store { i64, ptr } zeroinitializer, ptr %l33, !tbaa !27
  br label %bb17
bb17:
  %t96 = load i64, ptr %l31
  %t97 = inttoptr i64 %t96 to ptr
  %t98 = load { i64, ptr }, ptr %l33
  %t99 = extractvalue { i64, ptr } %t98, 1
  %t100 = call ptr @__olang_region_or(ptr %t99, ptr null)
  %t101 = icmp ne ptr %t100, null
  %t102 = select i1 %t101, ptr %t100, ptr null
  call void @__olang_region_settle_in(ptr %t97, ptr %t102)
  %t103 = load ptr, ptr %l21, !tbaa !29
  %t104 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t103, i32 0, i32 0
  %t105 = load { i64, ptr }, ptr %t104, !tbaa !27
  store { i64, ptr } %t105, ptr %l48, !tbaa !27
  %t106 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t107 = load ptr, ptr %l21, !tbaa !29
  %t108 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t107, i32 0, i32 0
  store { i64, ptr } %t106, ptr %t108, !tbaa !27
  %t109 = load { i64, ptr }, ptr %l48
  %t110 = extractvalue { i64, ptr } %t109, 0
  %t111 = extractvalue { i64, ptr } %t109, 1
  call void @__olang_region_release_part(ptr %t111, i64 %t110)
  store { i64, ptr } zeroinitializer, ptr %l48
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t114 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t112, i32 0, i32 1
  %t115 = load { i64, ptr }, ptr %t114, !tbaa !27
  %t117 = load ptr, ptr %l0, !tbaa !29
  store ptr %t117, ptr %l51, !tbaa !29
  store { i64, ptr } %t115, ptr %l52, !tbaa !27
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t121 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t119, i32 0, i32 3
  %t122 = load i64, ptr %t121, !tbaa !24
  store i64 %t122, ptr %l54, !tbaa !24
  %t123 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t124 = extractvalue { i64, ptr } %t123, 0
  store i64 %t124, ptr %l55, !tbaa !24
  %t125 = icmp sge i64 0, 0
  br i1 %t125, label %bb18, label %bb19
bb18:
  %t127 = load i64, ptr %l54, !tbaa !24
  %t128 = icmp sle i64 0, %t127
  br i1 %t128, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_ee4ebe7e95bf6f96_f8603eee839730c2)
  unreachable
bb20:
  %t130 = load i64, ptr %l54, !tbaa !24
  %t131 = load i64, ptr %l55, !tbaa !24
  %t132 = icmp sle i64 %t130, %t131
  br i1 %t132, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_ee4ebe7e95bf6f96_f8603eee839730c2)
  unreachable
bb22:
  %t134 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t135 = load ptr, ptr %t134, !tbaa !27
  %t136 = load i64, ptr %l54, !tbaa !24
  %t137 = getelementptr i64, ptr %t135, i64 0
  %t138 = sub i64 %t136, 0
  %t139 = insertvalue { i64, ptr } undef, i64 %t138, 0
  %t140 = insertvalue { i64, ptr } %t139, ptr %t137, 1
  store { i64, ptr } %t140, ptr %l7, !tbaa !27
  %t142 = load i64, ptr %l1, !tbaa !24
  %t144 = call ptr @__olang_region_make_part(ptr %v0)
  %t145 = ptrtoint ptr %t144 to i64
  store i64 %t145, ptr %l61, !tbaa !24
  store i64 %t142, ptr %l62, !tbaa !24
  %t147 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t149 = load i64, ptr %l62, !tbaa !24
  %t150 = extractvalue { i64, ptr } %t147, 0
  %t151 = mul i64 %t150, 8
  %t152 = mul i64 %t149, 8
  %t153 = extractvalue { i64, ptr } %t147, 1
  %t154 = call ptr @__olang_grow_in_place(ptr %t153, i64 %t151, i64 %t152, i64 %t149)
  %t155 = icmp ne ptr %t154, null
  %t156 = select i1 %t155, i64 %t149, i64 0
  %t157 = insertvalue { i64, ptr } undef, i64 %t156, 0
  %t158 = insertvalue { i64, ptr } %t157, ptr %t154, 1
  store { i64, ptr } %t158, ptr %l65, !tbaa !27
  %t159 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t160 = extractvalue { i64, ptr } %t159, 0
  %t162 = icmp ne i64 %t160, 0
  br i1 %t162, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_ee4ebe7e95bf6f96_f8603eee839730c2)
  unreachable
bb24:
  %t164 = load { i64, ptr }, ptr %l65, !tbaa !27
  store { i64, ptr } %t164, ptr %l63, !tbaa !27
  br label %bb26
bb25:
  %t165 = load i64, ptr %l62, !tbaa !24
  %t166 = mul i64 %t165, 8
  %t167 = load i64, ptr %l61
  %t168 = inttoptr i64 %t167 to ptr
  %t169 = call ptr @__olang_held_alloc(ptr %t168, i64 %t166)
  %t170 = insertvalue { i64, ptr } undef, i64 %t165, 0
  %t171 = insertvalue { i64, ptr } %t170, ptr %t169, 1
  store { i64, ptr } %t171, ptr %l63, !tbaa !27
  store i64 0, ptr %l68, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb27
bb26:
  %t172 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t173 = extractvalue { i64, ptr } %t172, 0
  %t175 = icmp eq i64 %t173, 0
  br i1 %t175, label %bb33, label %bb34
bb27:
  %t177 = load i64, ptr %l9, !tbaa !24
  %t178 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t180 = extractvalue { i64, ptr } %t178, 0
  %t183 = icmp slt i64 %t177, %t180
  %t185 = xor i1 %t183, true
  br i1 %t185, label %bb28, label %bb29
bb28:
  br label %bb32
bb29:
  br label %bb30
bb30:
  %t187 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t187, ptr %l74, !tbaa !27
  %t188 = load i64, ptr %l9, !tbaa !24
  %t190 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t191 = load ptr, ptr %t190, !tbaa !27
  %t192 = getelementptr i64, ptr %t191, i64 %t188
  %t193 = load i64, ptr %t192, !tbaa !34
  %t195 = load i64, ptr %l68, !tbaa !24
  %t196 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t197 = load ptr, ptr %t196, !tbaa !27
  %t198 = getelementptr i64, ptr %t197, i64 %t195
  store i64 %t193, ptr %t198, !tbaa !34
  %t199 = load i64, ptr %l68, !tbaa !24
  %t200 = add i64 %t199, 1
  store i64 %t200, ptr %l68, !tbaa !24
  br label %bb31
bb31:
  %t201 = load i64, ptr %l9, !tbaa !24
  %t204 = add i64 %t201, 1
  store i64 %t204, ptr %l9, !tbaa !24
  br label %bb27
bb32:
  br label %bb26
bb33:
  store { i64, ptr } zeroinitializer, ptr %l63, !tbaa !27
  br label %bb34
bb34:
  %t206 = load i64, ptr %l61
  %t207 = inttoptr i64 %t206 to ptr
  %t208 = load { i64, ptr }, ptr %l63
  %t209 = extractvalue { i64, ptr } %t208, 1
  %t210 = call ptr @__olang_region_or(ptr %t209, ptr null)
  %t211 = icmp ne ptr %t210, null
  %t212 = select i1 %t211, ptr %t210, ptr null
  call void @__olang_region_settle_in(ptr %t207, ptr %t212)
  %t213 = load ptr, ptr %l51, !tbaa !29
  %t214 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t213, i32 0, i32 1
  %t215 = load { i64, ptr }, ptr %t214, !tbaa !27
  store { i64, ptr } %t215, ptr %l82, !tbaa !27
  %t216 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t217 = load ptr, ptr %l51, !tbaa !29
  %t218 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t217, i32 0, i32 1
  store { i64, ptr } %t216, ptr %t218, !tbaa !27
  %t219 = load { i64, ptr }, ptr %l82
  %t220 = extractvalue { i64, ptr } %t219, 0
  %t221 = extractvalue { i64, ptr } %t219, 1
  call void @__olang_region_release_part(ptr %t221, i64 %t220)
  store { i64, ptr } zeroinitializer, ptr %l82
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_2c_20std_H5fec011c2c89acaab51ee19301103bbb(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca i64
  %l4 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i64
  %l13 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l19 = alloca i64
  %l30 = alloca i1
  %l34 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l35 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca { i64, ptr }
  %l41 = alloca ptr
  %l42 = alloca i64
  %l43 = alloca { i64, ptr }
  %l44 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l46 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %s0 = alloca %olang.scope
  %t21 = alloca i64
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1, i32 0, i32 2
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp eq i64 %t6, 0
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l9, !tbaa !29
  %t11 = call ptr @__olang_region_make_part(ptr %v0)
  %t12 = ptrtoint ptr %t11 to i64
  store i64 %t12, ptr %l10, !tbaa !24
  %t13 = icmp sge i64 8, 0
  br i1 %t13, label %bb3, label %bb4
bb2:
  br label %bb9
bb3:
  %t15 = icmp sle i64 8, 1152921504606846975
  br i1 %t15, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_93f674fca185685e_cd261ae5f7812eaa)
  unreachable
bb5:
  %t17 = mul i64 8, 8
  %t18 = load i64, ptr %l10
  %t19 = inttoptr i64 %t18 to ptr
  %t20 = call ptr @__olang_held_alloc(ptr %t19, i64 %t17)
  store i64 0, ptr %t21
  br label %fill.22
fill.22:
  %t25 = load i64, ptr %t21
  %t26 = icmp slt i64 %t25, 8
  br i1 %t26, label %fillb.23, label %filld.24
fillb.23:
  %t27 = getelementptr i64, ptr %t20, i64 %t25
  store i64 -1, ptr %t27
  %t28 = add i64 %t25, 1
  store i64 %t28, ptr %t21
  br label %fill.22
filld.24:
  %t29 = insertvalue { i64, ptr } undef, i64 8, 0
  %t30 = insertvalue { i64, ptr } %t29, ptr %t20, 1
  store { i64, ptr } %t30, ptr %l13, !tbaa !27
  %t31 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  %t34 = icmp eq i64 %t32, 0
  br i1 %t34, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_93f674fca185685e_cd261ae5f7812eaa)
  unreachable
bb7:
  store { i64, ptr } zeroinitializer, ptr %l13, !tbaa !27
  br label %bb8
bb8:
  %t36 = load i64, ptr %l10
  %t37 = inttoptr i64 %t36 to ptr
  %t38 = load { i64, ptr }, ptr %l13
  %t39 = extractvalue { i64, ptr } %t38, 1
  %t40 = call ptr @__olang_region_or(ptr %t39, ptr null)
  %t41 = icmp ne ptr %t40, null
  %t42 = select i1 %t41, ptr %t40, ptr null
  call void @__olang_region_settle_in(ptr %t37, ptr %t42)
  %t43 = load ptr, ptr %l9, !tbaa !29
  %t44 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t43, i32 0, i32 2
  %t45 = load { i64, ptr }, ptr %t44, !tbaa !27
  store { i64, ptr } %t45, ptr %l16, !tbaa !27
  %t46 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t47 = load ptr, ptr %l9, !tbaa !29
  %t48 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t47, i32 0, i32 2
  store { i64, ptr } %t46, ptr %t48, !tbaa !27
  %t49 = load { i64, ptr }, ptr %l16
  %t50 = extractvalue { i64, ptr } %t49, 0
  %t51 = extractvalue { i64, ptr } %t49, 1
  call void @__olang_region_release_part(ptr %t51, i64 %t50)
  store { i64, ptr } zeroinitializer, ptr %l16
  br label %bb9
bb9:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t56 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_2c_20Boo_He838af28276528f84a686ca3d206b833(ptr %v0, ptr %t52, { i64, ptr } %t53)
  store i64 %t56, ptr %l19
  br label %bb10
bb10:
  %t57 = load i64, ptr %l19, !tbaa !24
  store i64 %t57, ptr %l3, !tbaa !24
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load i64, ptr %l3, !tbaa !24
  %t61 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t58, i32 0, i32 2
  %t63 = getelementptr { i64, ptr }, ptr %t61, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !27
  %t65 = getelementptr i64, ptr %t64, i64 %t59
  %t66 = load i64, ptr %t65, !tbaa !34
  store i64 %t66, ptr %l4, !tbaa !24
  br label %bb11
bb11:
  %t68 = load i64, ptr %l4, !tbaa !24
  %t70 = icmp sge i64 %t68, 0
  %t72 = xor i1 %t70, true
  br i1 %t72, label %bb12, label %bb13
bb12:
  br label %bb20
bb13:
  br label %bb14
bb14:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load i64, ptr %l4, !tbaa !24
  %t77 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t74, i32 0, i32 0
  %t79 = getelementptr { i64, ptr }, ptr %t77, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = getelementptr %"std/prelude/map:MapEntry.325a673059aaeefabf16a279230523f6", ptr %t80, i64 %t75
  %t82 = getelementptr %"std/prelude/map:MapEntry.325a673059aaeefabf16a279230523f6", ptr %t81, i32 0, i32 0
  %t83 = load { i64, ptr }, ptr %t82, !tbaa !27
  %t84 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t87 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t83, { i64, ptr } %t84)
  store i1 %t87, ptr %l30
  br label %bb15
bb15:
  %t88 = load i1, ptr %l30, !tbaa !21
  br i1 %t88, label %bb16, label %bb17
bb16:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t90 = load i64, ptr %l4, !tbaa !24
  %t91 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t91, ptr %l34
  %t93 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l34, i32 0, i32 0
  %t94 = load { i64, ptr }, ptr %t93, !tbaa !27
  store { i64, ptr } %t94, ptr %l35, !tbaa !27
  %t95 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t96 = extractvalue { i64, ptr } %t95, 0
  store i64 %t96, ptr %l36, !tbaa !24
  %t97 = load i64, ptr %l36, !tbaa !24
  %t98 = mul i64 %t97, 8
  %t99 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t98)
  %t100 = insertvalue { i64, ptr } undef, i64 %t97, 0
  %t101 = insertvalue { i64, ptr } %t100, ptr %t99, 1
  store { i64, ptr } %t101, ptr %l37, !tbaa !27
  %t102 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t103 = load ptr, ptr %t102, !tbaa !27
  %t104 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !27
  %t106 = load i64, ptr %l36, !tbaa !24
  %t107 = mul i64 %t106, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t103, ptr %t105, i64 %t107, i1 false)
  %t108 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t109 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l34, i32 0, i32 0
  store { i64, ptr } %t108, ptr %t109, !tbaa !27
  %t110 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l34
  %t112 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t89, i32 0, i32 0
  %t114 = getelementptr { i64, ptr }, ptr %t112, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !27
  %t116 = getelementptr %"std/prelude/map:MapEntry.325a673059aaeefabf16a279230523f6", ptr %t115, i64 %t90
  %t117 = getelementptr %"std/prelude/map:MapEntry.325a673059aaeefabf16a279230523f6", ptr %t116, i32 0, i32 1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t110, ptr %t117
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb17:
  br label %bb18
bb18:
  br label %bb19
bb19:
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t119 = load i64, ptr %l4, !tbaa !24
  %t121 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t118, i32 0, i32 1
  %t123 = getelementptr { i64, ptr }, ptr %t121, i32 0, i32 1
  %t124 = load ptr, ptr %t123, !tbaa !27
  %t125 = getelementptr i64, ptr %t124, i64 %t119
  %t126 = load i64, ptr %t125, !tbaa !34
  store i64 %t126, ptr %l4, !tbaa !24
  br label %bb11
bb20:
  %t128 = load ptr, ptr %l0, !tbaa !29
  store ptr %t128, ptr %l41, !tbaa !29
  %t129 = load i64, ptr %l3, !tbaa !24
  store i64 %t129, ptr %l42, !tbaa !24
  %t130 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t130, ptr %l43, !tbaa !27
  %t131 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t131, ptr %l44
  %t133 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %s0, ptr %l44)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t133, ptr %l46
  br label %bb21
bb21:
  %t134 = load ptr, ptr %l41, !tbaa !29
  %t135 = load i64, ptr %l42, !tbaa !24
  %t136 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t137 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l46
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_2c_20std_Hcceee2791b609c347cb46403ab146074(ptr %v0, ptr %s0, ptr %t134, i64 %t135, { i64, ptr } %t136, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t137)
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_2c_20std_Hb43ef1c360972974a185b6b9d22a2db0(ptr %v0, ptr %a0) noinline cold #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca { i64, ptr }
  %l5 = alloca i64
  %l7 = alloca { i64, ptr }
  %l9 = alloca i64
  %l14 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l31 = alloca i64
  %l33 = alloca { i64, ptr }
  %l34 = alloca i64
  %l40 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l51 = alloca ptr
  %l52 = alloca { i64, ptr }
  %l54 = alloca i64
  %l55 = alloca i64
  %l61 = alloca i64
  %l62 = alloca i64
  %l63 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %l68 = alloca i64
  %l74 = alloca { i64, ptr }
  %l82 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp slt i64 %t6, 4
  br i1 %t8, label %bb1, label %bb2
bb1:
  store i64 8, ptr %l14, !tbaa !24
  br label %bb3
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t17 = mul i64 %t15, 2
  store i64 %t17, ptr %l14, !tbaa !24
  br label %bb3
bb3:
  %t19 = load i64, ptr %l14, !tbaa !24
  store i64 %t19, ptr %l1, !tbaa !24
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t20, i32 0, i32 0
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !27
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l21, !tbaa !29
  store { i64, ptr } %t23, ptr %l22, !tbaa !27
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t27, i32 0, i32 3
  %t30 = load i64, ptr %t29, !tbaa !24
  store i64 %t30, ptr %l24, !tbaa !24
  %t31 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  store i64 %t32, ptr %l25, !tbaa !24
  %t33 = icmp sge i64 0, 0
  br i1 %t33, label %bb4, label %bb5
bb4:
  %t35 = load i64, ptr %l24, !tbaa !24
  %t36 = icmp sle i64 0, %t35
  br i1 %t36, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_efd753ebce06d520_5a29f91d7c8b642c)
  unreachable
bb6:
  %t38 = load i64, ptr %l24, !tbaa !24
  %t39 = load i64, ptr %l25, !tbaa !24
  %t40 = icmp sle i64 %t38, %t39
  br i1 %t40, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_efd753ebce06d520_5a29f91d7c8b642c)
  unreachable
bb8:
  %t42 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = load i64, ptr %l24, !tbaa !24
  %t45 = getelementptr %"std/prelude/map:MapEntry.325a673059aaeefabf16a279230523f6", ptr %t43, i64 0
  %t46 = sub i64 %t44, 0
  %t47 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t45, 1
  store { i64, ptr } %t48, ptr %l3, !tbaa !27
  %t50 = load i64, ptr %l1, !tbaa !24
  %t52 = call ptr @__olang_region_make_part(ptr %v0)
  %t53 = ptrtoint ptr %t52 to i64
  store i64 %t53, ptr %l31, !tbaa !24
  %t56 = mul i64 %t50, 48
  %t57 = load i64, ptr %l31
  %t58 = inttoptr i64 %t57 to ptr
  %t59 = call ptr @__olang_scope_alloc_zeroed(ptr %t58, i64 %t56)
  %t60 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t61 = insertvalue { i64, ptr } %t60, ptr %t59, 1
  store { i64, ptr } %t61, ptr %l33, !tbaa !27
  store i64 0, ptr %l34, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_efd753ebce06d520_5a29f91d7c8b642c)
  unreachable
bb10:
  %t62 = load i64, ptr %l5, !tbaa !24
  %t63 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t63, 0
  %t68 = icmp slt i64 %t62, %t65
  %t70 = xor i1 %t68, true
  br i1 %t70, label %bb11, label %bb12
bb11:
  br label %bb15
bb12:
  br label %bb13
bb13:
  %t72 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t72, ptr %l40, !tbaa !27
  %t73 = load i64, ptr %l5, !tbaa !24
  %t75 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = getelementptr %"std/prelude/map:MapEntry.325a673059aaeefabf16a279230523f6", ptr %t76, i64 %t73
  %t78 = load %"std/prelude/map:MapEntry.325a673059aaeefabf16a279230523f6", ptr %t77
  store %"std/prelude/map:MapEntry.325a673059aaeefabf16a279230523f6" zeroinitializer, ptr %t77
  %t80 = load i64, ptr %l34, !tbaa !24
  %t81 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !27
  %t83 = getelementptr %"std/prelude/map:MapEntry.325a673059aaeefabf16a279230523f6", ptr %t82, i64 %t80
  store %"std/prelude/map:MapEntry.325a673059aaeefabf16a279230523f6" %t78, ptr %t83
  %t84 = load i64, ptr %l34, !tbaa !24
  %t85 = add i64 %t84, 1
  store i64 %t85, ptr %l34, !tbaa !24
  br label %bb14
bb14:
  %t86 = load i64, ptr %l5, !tbaa !24
  %t89 = add i64 %t86, 1
  store i64 %t89, ptr %l5, !tbaa !24
  br label %bb10
bb15:
  %t91 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t92 = extractvalue { i64, ptr } %t91, 0
  %t94 = icmp eq i64 %t92, 0
  br i1 %t94, label %bb16, label %bb17
bb16:
  store { i64, ptr } zeroinitializer, ptr %l33, !tbaa !27
  br label %bb17
bb17:
  %t96 = load i64, ptr %l31
  %t97 = inttoptr i64 %t96 to ptr
  %t98 = load { i64, ptr }, ptr %l33
  %t99 = extractvalue { i64, ptr } %t98, 1
  %t100 = call ptr @__olang_region_or(ptr %t99, ptr null)
  %t101 = icmp ne ptr %t100, null
  %t102 = select i1 %t101, ptr %t100, ptr null
  call void @__olang_region_settle_in(ptr %t97, ptr %t102)
  %t103 = load ptr, ptr %l21, !tbaa !29
  %t104 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t103, i32 0, i32 0
  %t105 = load { i64, ptr }, ptr %t104, !tbaa !27
  store { i64, ptr } %t105, ptr %l48, !tbaa !27
  %t106 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t107 = load ptr, ptr %l21, !tbaa !29
  %t108 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t107, i32 0, i32 0
  store { i64, ptr } %t106, ptr %t108, !tbaa !27
  %t109 = load { i64, ptr }, ptr %l48
  %t110 = extractvalue { i64, ptr } %t109, 0
  %t111 = extractvalue { i64, ptr } %t109, 1
  call void @__olang_region_release_part(ptr %t111, i64 %t110)
  store { i64, ptr } zeroinitializer, ptr %l48
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t114 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t112, i32 0, i32 1
  %t115 = load { i64, ptr }, ptr %t114, !tbaa !27
  %t117 = load ptr, ptr %l0, !tbaa !29
  store ptr %t117, ptr %l51, !tbaa !29
  store { i64, ptr } %t115, ptr %l52, !tbaa !27
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t121 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t119, i32 0, i32 3
  %t122 = load i64, ptr %t121, !tbaa !24
  store i64 %t122, ptr %l54, !tbaa !24
  %t123 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t124 = extractvalue { i64, ptr } %t123, 0
  store i64 %t124, ptr %l55, !tbaa !24
  %t125 = icmp sge i64 0, 0
  br i1 %t125, label %bb18, label %bb19
bb18:
  %t127 = load i64, ptr %l54, !tbaa !24
  %t128 = icmp sle i64 0, %t127
  br i1 %t128, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_f4f14a5afb00af7d_1f3790c70e0903d9)
  unreachable
bb20:
  %t130 = load i64, ptr %l54, !tbaa !24
  %t131 = load i64, ptr %l55, !tbaa !24
  %t132 = icmp sle i64 %t130, %t131
  br i1 %t132, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_f4f14a5afb00af7d_1f3790c70e0903d9)
  unreachable
bb22:
  %t134 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t135 = load ptr, ptr %t134, !tbaa !27
  %t136 = load i64, ptr %l54, !tbaa !24
  %t137 = getelementptr i64, ptr %t135, i64 0
  %t138 = sub i64 %t136, 0
  %t139 = insertvalue { i64, ptr } undef, i64 %t138, 0
  %t140 = insertvalue { i64, ptr } %t139, ptr %t137, 1
  store { i64, ptr } %t140, ptr %l7, !tbaa !27
  %t142 = load i64, ptr %l1, !tbaa !24
  %t144 = call ptr @__olang_region_make_part(ptr %v0)
  %t145 = ptrtoint ptr %t144 to i64
  store i64 %t145, ptr %l61, !tbaa !24
  store i64 %t142, ptr %l62, !tbaa !24
  %t147 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t149 = load i64, ptr %l62, !tbaa !24
  %t150 = extractvalue { i64, ptr } %t147, 0
  %t151 = mul i64 %t150, 8
  %t152 = mul i64 %t149, 8
  %t153 = extractvalue { i64, ptr } %t147, 1
  %t154 = call ptr @__olang_grow_in_place(ptr %t153, i64 %t151, i64 %t152, i64 %t149)
  %t155 = icmp ne ptr %t154, null
  %t156 = select i1 %t155, i64 %t149, i64 0
  %t157 = insertvalue { i64, ptr } undef, i64 %t156, 0
  %t158 = insertvalue { i64, ptr } %t157, ptr %t154, 1
  store { i64, ptr } %t158, ptr %l65, !tbaa !27
  %t159 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t160 = extractvalue { i64, ptr } %t159, 0
  %t162 = icmp ne i64 %t160, 0
  br i1 %t162, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_f4f14a5afb00af7d_1f3790c70e0903d9)
  unreachable
bb24:
  %t164 = load { i64, ptr }, ptr %l65, !tbaa !27
  store { i64, ptr } %t164, ptr %l63, !tbaa !27
  br label %bb26
bb25:
  %t165 = load i64, ptr %l62, !tbaa !24
  %t166 = mul i64 %t165, 8
  %t167 = load i64, ptr %l61
  %t168 = inttoptr i64 %t167 to ptr
  %t169 = call ptr @__olang_held_alloc(ptr %t168, i64 %t166)
  %t170 = insertvalue { i64, ptr } undef, i64 %t165, 0
  %t171 = insertvalue { i64, ptr } %t170, ptr %t169, 1
  store { i64, ptr } %t171, ptr %l63, !tbaa !27
  store i64 0, ptr %l68, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb27
bb26:
  %t172 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t173 = extractvalue { i64, ptr } %t172, 0
  %t175 = icmp eq i64 %t173, 0
  br i1 %t175, label %bb33, label %bb34
bb27:
  %t177 = load i64, ptr %l9, !tbaa !24
  %t178 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t180 = extractvalue { i64, ptr } %t178, 0
  %t183 = icmp slt i64 %t177, %t180
  %t185 = xor i1 %t183, true
  br i1 %t185, label %bb28, label %bb29
bb28:
  br label %bb32
bb29:
  br label %bb30
bb30:
  %t187 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t187, ptr %l74, !tbaa !27
  %t188 = load i64, ptr %l9, !tbaa !24
  %t190 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t191 = load ptr, ptr %t190, !tbaa !27
  %t192 = getelementptr i64, ptr %t191, i64 %t188
  %t193 = load i64, ptr %t192, !tbaa !34
  %t195 = load i64, ptr %l68, !tbaa !24
  %t196 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t197 = load ptr, ptr %t196, !tbaa !27
  %t198 = getelementptr i64, ptr %t197, i64 %t195
  store i64 %t193, ptr %t198, !tbaa !34
  %t199 = load i64, ptr %l68, !tbaa !24
  %t200 = add i64 %t199, 1
  store i64 %t200, ptr %l68, !tbaa !24
  br label %bb31
bb31:
  %t201 = load i64, ptr %l9, !tbaa !24
  %t204 = add i64 %t201, 1
  store i64 %t204, ptr %l9, !tbaa !24
  br label %bb27
bb32:
  br label %bb26
bb33:
  store { i64, ptr } zeroinitializer, ptr %l63, !tbaa !27
  br label %bb34
bb34:
  %t206 = load i64, ptr %l61
  %t207 = inttoptr i64 %t206 to ptr
  %t208 = load { i64, ptr }, ptr %l63
  %t209 = extractvalue { i64, ptr } %t208, 1
  %t210 = call ptr @__olang_region_or(ptr %t209, ptr null)
  %t211 = icmp ne ptr %t210, null
  %t212 = select i1 %t211, ptr %t210, ptr null
  call void @__olang_region_settle_in(ptr %t207, ptr %t212)
  %t213 = load ptr, ptr %l51, !tbaa !29
  %t214 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t213, i32 0, i32 1
  %t215 = load { i64, ptr }, ptr %t214, !tbaa !27
  store { i64, ptr } %t215, ptr %l82, !tbaa !27
  %t216 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t217 = load ptr, ptr %l51, !tbaa !29
  %t218 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t217, i32 0, i32 1
  store { i64, ptr } %t216, ptr %t218, !tbaa !27
  %t219 = load { i64, ptr }, ptr %l82
  %t220 = extractvalue { i64, ptr } %t219, 0
  %t221 = extractvalue { i64, ptr } %t219, 1
  call void @__olang_region_release_part(ptr %t221, i64 %t220)
  store { i64, ptr } zeroinitializer, ptr %l82
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aOrigin_3e_2eroom_3ccompiler_2fgeneric_3aOrigin_3e(ptr %v0, ptr %a0, i64 %a1) noinline cold #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l4 = alloca { i64, ptr }
  %l6 = alloca i64
  %l16 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l50 = alloca i64
  %l56 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t2, i32 0, i32 0
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t10 = icmp sle i64 %t1, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t19 = icmp slt i64 %t17, 4
  br i1 %t19, label %bb4, label %bb5
bb4:
  store i64 8, ptr %l16, !tbaa !24
  br label %bb6
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t28 = mul i64 %t26, 2
  store i64 %t28, ptr %l16, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l16, !tbaa !24
  store i64 %t30, ptr %l2, !tbaa !24
  %t31 = load i64, ptr %l2, !tbaa !24
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  br i1 %t35, label %bb7, label %bb8
bb7:
  %t37 = load i64, ptr %l1, !tbaa !24
  store i64 %t37, ptr %l2, !tbaa !24
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t39 = load i64, ptr %l2, !tbaa !24
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t40, i32 0, i32 2
  %t43 = load i64, ptr %t42, !tbaa !24
  %t46 = icmp slt i64 %t39, %t43
  br i1 %t46, label %bb10, label %bb11
bb10:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t48, i32 0, i32 2
  %t51 = load i64, ptr %t50, !tbaa !24
  store i64 %t51, ptr %l2, !tbaa !24
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t53, i32 0, i32 0
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l33, !tbaa !29
  store { i64, ptr } %t56, ptr %l34, !tbaa !27
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t60, i32 0, i32 1
  %t63 = load i64, ptr %t62, !tbaa !24
  store i64 %t63, ptr %l36, !tbaa !24
  %t64 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t64, 0
  store i64 %t65, ptr %l37, !tbaa !24
  %t66 = icmp sge i64 0, 0
  br i1 %t66, label %bb13, label %bb14
bb13:
  %t68 = load i64, ptr %l36, !tbaa !24
  %t69 = icmp sle i64 0, %t68
  br i1 %t69, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_f2d7fef6be0d2aaa_9057d438a463b76e)
  unreachable
bb15:
  %t71 = load i64, ptr %l36, !tbaa !24
  %t72 = load i64, ptr %l37, !tbaa !24
  %t73 = icmp sle i64 %t71, %t72
  br i1 %t73, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_f2d7fef6be0d2aaa_9057d438a463b76e)
  unreachable
bb17:
  %t75 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = load i64, ptr %l36, !tbaa !24
  %t78 = getelementptr %"compiler/generic:Origin", ptr %t76, i64 0
  %t79 = sub i64 %t77, 0
  %t80 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t78, 1
  store { i64, ptr } %t81, ptr %l4, !tbaa !27
  %t83 = load i64, ptr %l2, !tbaa !24
  %t85 = call ptr @__olang_region_make_part(ptr %v0)
  %t86 = ptrtoint ptr %t85 to i64
  store i64 %t86, ptr %l43, !tbaa !24
  store i64 %t83, ptr %l44, !tbaa !24
  %t88 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t90 = load i64, ptr %l44, !tbaa !24
  %t91 = extractvalue { i64, ptr } %t88, 0
  %t92 = mul i64 %t91, 32
  %t93 = mul i64 %t90, 32
  %t94 = extractvalue { i64, ptr } %t88, 1
  %t95 = call ptr @__olang_grow_in_place(ptr %t94, i64 %t92, i64 %t93, i64 %t90)
  %t96 = icmp ne ptr %t95, null
  %t97 = select i1 %t96, i64 %t90, i64 0
  %t98 = insertvalue { i64, ptr } undef, i64 %t97, 0
  %t99 = insertvalue { i64, ptr } %t98, ptr %t95, 1
  store { i64, ptr } %t99, ptr %l47, !tbaa !27
  %t100 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t100, 0
  %t103 = icmp ne i64 %t101, 0
  br i1 %t103, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_f2d7fef6be0d2aaa_9057d438a463b76e)
  unreachable
bb19:
  %t105 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t105, ptr %l45, !tbaa !27
  br label %bb21
bb20:
  %t106 = load i64, ptr %l44, !tbaa !24
  %t107 = mul i64 %t106, 32
  %t108 = load i64, ptr %l43
  %t109 = inttoptr i64 %t108 to ptr
  %t110 = call ptr @__olang_held_alloc(ptr %t109, i64 %t107)
  %t111 = insertvalue { i64, ptr } undef, i64 %t106, 0
  %t112 = insertvalue { i64, ptr } %t111, ptr %t110, 1
  store { i64, ptr } %t112, ptr %l45, !tbaa !27
  store i64 0, ptr %l50, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb22
bb21:
  %t113 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t113, 0
  %t116 = icmp eq i64 %t114, 0
  br i1 %t116, label %bb28, label %bb29
bb22:
  %t118 = load i64, ptr %l6, !tbaa !24
  %t119 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t121 = extractvalue { i64, ptr } %t119, 0
  %t124 = icmp slt i64 %t118, %t121
  %t126 = xor i1 %t124, true
  br i1 %t126, label %bb23, label %bb24
bb23:
  br label %bb27
bb24:
  br label %bb25
bb25:
  %t128 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t128, ptr %l56, !tbaa !27
  %t129 = load i64, ptr %l6, !tbaa !24
  %t131 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t132 = load ptr, ptr %t131, !tbaa !27
  %t133 = getelementptr %"compiler/generic:Origin", ptr %t132, i64 %t129
  %t134 = load %"compiler/generic:Origin", ptr %t133
  %t136 = load i64, ptr %l50, !tbaa !24
  %t137 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !27
  %t139 = getelementptr %"compiler/generic:Origin", ptr %t138, i64 %t136
  store %"compiler/generic:Origin" %t134, ptr %t139
  %t140 = load i64, ptr %l50, !tbaa !24
  %t141 = add i64 %t140, 1
  store i64 %t141, ptr %l50, !tbaa !24
  br label %bb26
bb26:
  %t142 = load i64, ptr %l6, !tbaa !24
  %t145 = add i64 %t142, 1
  store i64 %t145, ptr %l6, !tbaa !24
  br label %bb22
bb27:
  br label %bb21
bb28:
  store { i64, ptr } zeroinitializer, ptr %l45, !tbaa !27
  br label %bb29
bb29:
  %t147 = load i64, ptr %l43
  %t148 = inttoptr i64 %t147 to ptr
  %t149 = load { i64, ptr }, ptr %l45
  %t150 = extractvalue { i64, ptr } %t149, 1
  %t151 = call ptr @__olang_region_or(ptr %t150, ptr null)
  %t152 = icmp ne ptr %t151, null
  %t153 = select i1 %t152, ptr %t151, ptr null
  call void @__olang_region_settle_in(ptr %t148, ptr %t153)
  %t154 = load ptr, ptr %l33, !tbaa !29
  %t155 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t154, i32 0, i32 0
  %t156 = load { i64, ptr }, ptr %t155, !tbaa !27
  store { i64, ptr } %t156, ptr %l64, !tbaa !27
  %t157 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t158 = load ptr, ptr %l33, !tbaa !29
  %t159 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t158, i32 0, i32 0
  store { i64, ptr } %t157, ptr %t159, !tbaa !27
  %t160 = load { i64, ptr }, ptr %l64
  %t161 = extractvalue { i64, ptr } %t160, 0
  %t162 = extractvalue { i64, ptr } %t160, 1
  call void @__olang_region_release_part(ptr %t162, i64 %t161)
  store { i64, ptr } zeroinitializer, ptr %l64
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aGap_3e_2eroom_3ccompiler_2fscope_3aGap_3e(ptr %v0, ptr %a0, i64 %a1) noinline cold #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l4 = alloca { i64, ptr }
  %l6 = alloca i64
  %l16 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l50 = alloca i64
  %l56 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t2, i32 0, i32 0
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t10 = icmp sle i64 %t1, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t19 = icmp slt i64 %t17, 4
  br i1 %t19, label %bb4, label %bb5
bb4:
  store i64 8, ptr %l16, !tbaa !24
  br label %bb6
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t28 = mul i64 %t26, 2
  store i64 %t28, ptr %l16, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l16, !tbaa !24
  store i64 %t30, ptr %l2, !tbaa !24
  %t31 = load i64, ptr %l2, !tbaa !24
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  br i1 %t35, label %bb7, label %bb8
bb7:
  %t37 = load i64, ptr %l1, !tbaa !24
  store i64 %t37, ptr %l2, !tbaa !24
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t39 = load i64, ptr %l2, !tbaa !24
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t40, i32 0, i32 2
  %t43 = load i64, ptr %t42, !tbaa !24
  %t46 = icmp slt i64 %t39, %t43
  br i1 %t46, label %bb10, label %bb11
bb10:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t48, i32 0, i32 2
  %t51 = load i64, ptr %t50, !tbaa !24
  store i64 %t51, ptr %l2, !tbaa !24
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t53, i32 0, i32 0
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l33, !tbaa !29
  store { i64, ptr } %t56, ptr %l34, !tbaa !27
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t60, i32 0, i32 1
  %t63 = load i64, ptr %t62, !tbaa !24
  store i64 %t63, ptr %l36, !tbaa !24
  %t64 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t64, 0
  store i64 %t65, ptr %l37, !tbaa !24
  %t66 = icmp sge i64 0, 0
  br i1 %t66, label %bb13, label %bb14
bb13:
  %t68 = load i64, ptr %l36, !tbaa !24
  %t69 = icmp sle i64 0, %t68
  br i1 %t69, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_efe79bd589437e16_606b0d04bc3b4b9a)
  unreachable
bb15:
  %t71 = load i64, ptr %l36, !tbaa !24
  %t72 = load i64, ptr %l37, !tbaa !24
  %t73 = icmp sle i64 %t71, %t72
  br i1 %t73, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_efe79bd589437e16_606b0d04bc3b4b9a)
  unreachable
bb17:
  %t75 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = load i64, ptr %l36, !tbaa !24
  %t78 = getelementptr %"compiler/scope:Gap", ptr %t76, i64 0
  %t79 = sub i64 %t77, 0
  %t80 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t78, 1
  store { i64, ptr } %t81, ptr %l4, !tbaa !27
  %t83 = load i64, ptr %l2, !tbaa !24
  %t85 = call ptr @__olang_region_make_part(ptr %v0)
  %t86 = ptrtoint ptr %t85 to i64
  store i64 %t86, ptr %l43, !tbaa !24
  store i64 %t83, ptr %l44, !tbaa !24
  %t88 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t90 = load i64, ptr %l44, !tbaa !24
  %t91 = extractvalue { i64, ptr } %t88, 0
  %t92 = mul i64 %t91, 32
  %t93 = mul i64 %t90, 32
  %t94 = extractvalue { i64, ptr } %t88, 1
  %t95 = call ptr @__olang_grow_in_place(ptr %t94, i64 %t92, i64 %t93, i64 %t90)
  %t96 = icmp ne ptr %t95, null
  %t97 = select i1 %t96, i64 %t90, i64 0
  %t98 = insertvalue { i64, ptr } undef, i64 %t97, 0
  %t99 = insertvalue { i64, ptr } %t98, ptr %t95, 1
  store { i64, ptr } %t99, ptr %l47, !tbaa !27
  %t100 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t100, 0
  %t103 = icmp ne i64 %t101, 0
  br i1 %t103, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_efe79bd589437e16_606b0d04bc3b4b9a)
  unreachable
bb19:
  %t105 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t105, ptr %l45, !tbaa !27
  br label %bb21
bb20:
  %t106 = load i64, ptr %l44, !tbaa !24
  %t107 = mul i64 %t106, 32
  %t108 = load i64, ptr %l43
  %t109 = inttoptr i64 %t108 to ptr
  %t110 = call ptr @__olang_held_alloc(ptr %t109, i64 %t107)
  %t111 = insertvalue { i64, ptr } undef, i64 %t106, 0
  %t112 = insertvalue { i64, ptr } %t111, ptr %t110, 1
  store { i64, ptr } %t112, ptr %l45, !tbaa !27
  store i64 0, ptr %l50, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb22
bb21:
  %t113 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t113, 0
  %t116 = icmp eq i64 %t114, 0
  br i1 %t116, label %bb28, label %bb29
bb22:
  %t118 = load i64, ptr %l6, !tbaa !24
  %t119 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t121 = extractvalue { i64, ptr } %t119, 0
  %t124 = icmp slt i64 %t118, %t121
  %t126 = xor i1 %t124, true
  br i1 %t126, label %bb23, label %bb24
bb23:
  br label %bb27
bb24:
  br label %bb25
bb25:
  %t128 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t128, ptr %l56, !tbaa !27
  %t129 = load i64, ptr %l6, !tbaa !24
  %t131 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t132 = load ptr, ptr %t131, !tbaa !27
  %t133 = getelementptr %"compiler/scope:Gap", ptr %t132, i64 %t129
  %t134 = load %"compiler/scope:Gap", ptr %t133
  %t136 = load i64, ptr %l50, !tbaa !24
  %t137 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !27
  %t139 = getelementptr %"compiler/scope:Gap", ptr %t138, i64 %t136
  store %"compiler/scope:Gap" %t134, ptr %t139
  %t140 = load i64, ptr %l50, !tbaa !24
  %t141 = add i64 %t140, 1
  store i64 %t141, ptr %l50, !tbaa !24
  br label %bb26
bb26:
  %t142 = load i64, ptr %l6, !tbaa !24
  %t145 = add i64 %t142, 1
  store i64 %t145, ptr %l6, !tbaa !24
  br label %bb22
bb27:
  br label %bb21
bb28:
  store { i64, ptr } zeroinitializer, ptr %l45, !tbaa !27
  br label %bb29
bb29:
  %t147 = load i64, ptr %l43
  %t148 = inttoptr i64 %t147 to ptr
  %t149 = load { i64, ptr }, ptr %l45
  %t150 = extractvalue { i64, ptr } %t149, 1
  %t151 = call ptr @__olang_region_or(ptr %t150, ptr null)
  %t152 = icmp ne ptr %t151, null
  %t153 = select i1 %t152, ptr %t151, ptr null
  call void @__olang_region_settle_in(ptr %t148, ptr %t153)
  %t154 = load ptr, ptr %l33, !tbaa !29
  %t155 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t154, i32 0, i32 0
  %t156 = load { i64, ptr }, ptr %t155, !tbaa !27
  store { i64, ptr } %t156, ptr %l64, !tbaa !27
  %t157 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t158 = load ptr, ptr %l33, !tbaa !29
  %t159 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t158, i32 0, i32 0
  store { i64, ptr } %t157, ptr %t159, !tbaa !27
  %t160 = load { i64, ptr }, ptr %l64
  %t161 = extractvalue { i64, ptr } %t160, 0
  %t162 = extractvalue { i64, ptr } %t160, 1
  call void @__olang_region_release_part(ptr %t162, i64 %t161)
  store { i64, ptr } zeroinitializer, ptr %l64
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3afsOpen_3e_2eroom_3ccompiler_2fscope_3afsOpen_3e(ptr %v0, ptr noalias dereferenceable(32) align 8 %a0, i64 %a1) noinline cold #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l4 = alloca { i64, ptr }
  %l6 = alloca i64
  %l16 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l50 = alloca i64
  %l56 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t2, i32 0, i32 0
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t10 = icmp sle i64 %t1, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t19 = icmp slt i64 %t17, 4
  br i1 %t19, label %bb4, label %bb5
bb4:
  store i64 8, ptr %l16, !tbaa !24
  br label %bb6
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t28 = mul i64 %t26, 2
  store i64 %t28, ptr %l16, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l16, !tbaa !24
  store i64 %t30, ptr %l2, !tbaa !24
  %t31 = load i64, ptr %l2, !tbaa !24
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  br i1 %t35, label %bb7, label %bb8
bb7:
  %t37 = load i64, ptr %l1, !tbaa !24
  store i64 %t37, ptr %l2, !tbaa !24
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t39 = load i64, ptr %l2, !tbaa !24
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t40, i32 0, i32 2
  %t43 = load i64, ptr %t42, !tbaa !24
  %t46 = icmp slt i64 %t39, %t43
  br i1 %t46, label %bb10, label %bb11
bb10:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t48, i32 0, i32 2
  %t51 = load i64, ptr %t50, !tbaa !24
  store i64 %t51, ptr %l2, !tbaa !24
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t53, i32 0, i32 0
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l33, !tbaa !29
  store { i64, ptr } %t56, ptr %l34, !tbaa !27
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t60, i32 0, i32 1
  %t63 = load i64, ptr %t62, !tbaa !24
  store i64 %t63, ptr %l36, !tbaa !24
  %t64 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t64, 0
  store i64 %t65, ptr %l37, !tbaa !24
  %t66 = icmp sge i64 0, 0
  br i1 %t66, label %bb13, label %bb14
bb13:
  %t68 = load i64, ptr %l36, !tbaa !24
  %t69 = icmp sle i64 0, %t68
  br i1 %t69, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_e088370f9441903e_306c6e610ec90752)
  unreachable
bb15:
  %t71 = load i64, ptr %l36, !tbaa !24
  %t72 = load i64, ptr %l37, !tbaa !24
  %t73 = icmp sle i64 %t71, %t72
  br i1 %t73, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_e088370f9441903e_306c6e610ec90752)
  unreachable
bb17:
  %t75 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = load i64, ptr %l36, !tbaa !24
  %t78 = getelementptr %"compiler/scope:fsOpen", ptr %t76, i64 0
  %t79 = sub i64 %t77, 0
  %t80 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t78, 1
  store { i64, ptr } %t81, ptr %l4, !tbaa !27
  %t83 = load i64, ptr %l2, !tbaa !24
  %t85 = call ptr @__olang_region_make_part(ptr %v0)
  %t86 = ptrtoint ptr %t85 to i64
  store i64 %t86, ptr %l43, !tbaa !24
  store i64 %t83, ptr %l44, !tbaa !24
  %t88 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t90 = load i64, ptr %l44, !tbaa !24
  %t91 = extractvalue { i64, ptr } %t88, 0
  %t92 = mul i64 %t91, 8
  %t93 = mul i64 %t90, 8
  %t94 = extractvalue { i64, ptr } %t88, 1
  %t95 = call ptr @__olang_grow_in_place(ptr %t94, i64 %t92, i64 %t93, i64 %t90)
  %t96 = icmp ne ptr %t95, null
  %t97 = select i1 %t96, i64 %t90, i64 0
  %t98 = insertvalue { i64, ptr } undef, i64 %t97, 0
  %t99 = insertvalue { i64, ptr } %t98, ptr %t95, 1
  store { i64, ptr } %t99, ptr %l47, !tbaa !27
  %t100 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t100, 0
  %t103 = icmp ne i64 %t101, 0
  br i1 %t103, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_e088370f9441903e_306c6e610ec90752)
  unreachable
bb19:
  %t105 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t105, ptr %l45, !tbaa !27
  br label %bb21
bb20:
  %t106 = load i64, ptr %l44, !tbaa !24
  %t107 = mul i64 %t106, 8
  %t108 = load i64, ptr %l43
  %t109 = inttoptr i64 %t108 to ptr
  %t110 = call ptr @__olang_held_alloc(ptr %t109, i64 %t107)
  %t111 = insertvalue { i64, ptr } undef, i64 %t106, 0
  %t112 = insertvalue { i64, ptr } %t111, ptr %t110, 1
  store { i64, ptr } %t112, ptr %l45, !tbaa !27
  store i64 0, ptr %l50, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb22
bb21:
  %t113 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t113, 0
  %t116 = icmp eq i64 %t114, 0
  br i1 %t116, label %bb28, label %bb29
bb22:
  %t118 = load i64, ptr %l6, !tbaa !24
  %t119 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t121 = extractvalue { i64, ptr } %t119, 0
  %t124 = icmp slt i64 %t118, %t121
  %t126 = xor i1 %t124, true
  br i1 %t126, label %bb23, label %bb24
bb23:
  br label %bb27
bb24:
  br label %bb25
bb25:
  %t128 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t128, ptr %l56, !tbaa !27
  %t129 = load i64, ptr %l6, !tbaa !24
  %t131 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t132 = load ptr, ptr %t131, !tbaa !27
  %t133 = getelementptr %"compiler/scope:fsOpen", ptr %t132, i64 %t129
  %t134 = load %"compiler/scope:fsOpen", ptr %t133
  %t136 = load i64, ptr %l50, !tbaa !24
  %t137 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !27
  %t139 = getelementptr %"compiler/scope:fsOpen", ptr %t138, i64 %t136
  store %"compiler/scope:fsOpen" %t134, ptr %t139
  %t140 = load i64, ptr %l50, !tbaa !24
  %t141 = add i64 %t140, 1
  store i64 %t141, ptr %l50, !tbaa !24
  br label %bb26
bb26:
  %t142 = load i64, ptr %l6, !tbaa !24
  %t145 = add i64 %t142, 1
  store i64 %t145, ptr %l6, !tbaa !24
  br label %bb22
bb27:
  br label %bb21
bb28:
  store { i64, ptr } zeroinitializer, ptr %l45, !tbaa !27
  br label %bb29
bb29:
  %t147 = load i64, ptr %l43
  %t148 = inttoptr i64 %t147 to ptr
  %t149 = load { i64, ptr }, ptr %l45
  %t150 = extractvalue { i64, ptr } %t149, 1
  %t151 = call ptr @__olang_region_or(ptr %t150, ptr null)
  %t152 = icmp ne ptr %t151, null
  %t153 = select i1 %t152, ptr %t151, ptr null
  call void @__olang_region_settle_in(ptr %t148, ptr %t153)
  %t154 = load ptr, ptr %l33, !tbaa !29
  %t155 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t154, i32 0, i32 0
  %t156 = load { i64, ptr }, ptr %t155, !tbaa !27
  store { i64, ptr } %t156, ptr %l64, !tbaa !27
  %t157 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t158 = load ptr, ptr %l33, !tbaa !29
  %t159 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t158, i32 0, i32 0
  store { i64, ptr } %t157, ptr %t159, !tbaa !27
  %t160 = load { i64, ptr }, ptr %l64
  %t161 = extractvalue { i64, ptr } %t160, 0
  %t162 = extractvalue { i64, ptr } %t160, 1
  call void @__olang_region_release_part(ptr %t162, i64 %t161)
  store { i64, ptr } zeroinitializer, ptr %l64
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3averAtom_3e_2eroom_3ccompiler_2fscope_3averAtom_3e(ptr %v0, ptr %a0, i64 %a1) noinline cold #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l4 = alloca { i64, ptr }
  %l6 = alloca i64
  %l16 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l50 = alloca i64
  %l56 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t2, i32 0, i32 0
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t10 = icmp sle i64 %t1, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t19 = icmp slt i64 %t17, 4
  br i1 %t19, label %bb4, label %bb5
bb4:
  store i64 8, ptr %l16, !tbaa !24
  br label %bb6
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t28 = mul i64 %t26, 2
  store i64 %t28, ptr %l16, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l16, !tbaa !24
  store i64 %t30, ptr %l2, !tbaa !24
  %t31 = load i64, ptr %l2, !tbaa !24
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  br i1 %t35, label %bb7, label %bb8
bb7:
  %t37 = load i64, ptr %l1, !tbaa !24
  store i64 %t37, ptr %l2, !tbaa !24
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t39 = load i64, ptr %l2, !tbaa !24
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t40, i32 0, i32 2
  %t43 = load i64, ptr %t42, !tbaa !24
  %t46 = icmp slt i64 %t39, %t43
  br i1 %t46, label %bb10, label %bb11
bb10:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t48, i32 0, i32 2
  %t51 = load i64, ptr %t50, !tbaa !24
  store i64 %t51, ptr %l2, !tbaa !24
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t53, i32 0, i32 0
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l33, !tbaa !29
  store { i64, ptr } %t56, ptr %l34, !tbaa !27
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t60, i32 0, i32 1
  %t63 = load i64, ptr %t62, !tbaa !24
  store i64 %t63, ptr %l36, !tbaa !24
  %t64 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t64, 0
  store i64 %t65, ptr %l37, !tbaa !24
  %t66 = icmp sge i64 0, 0
  br i1 %t66, label %bb13, label %bb14
bb13:
  %t68 = load i64, ptr %l36, !tbaa !24
  %t69 = icmp sle i64 0, %t68
  br i1 %t69, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_d166e06d50506bfe_5f4d94877991b442)
  unreachable
bb15:
  %t71 = load i64, ptr %l36, !tbaa !24
  %t72 = load i64, ptr %l37, !tbaa !24
  %t73 = icmp sle i64 %t71, %t72
  br i1 %t73, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_d166e06d50506bfe_5f4d94877991b442)
  unreachable
bb17:
  %t75 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = load i64, ptr %l36, !tbaa !24
  %t78 = getelementptr %"compiler/scope:verAtom", ptr %t76, i64 0
  %t79 = sub i64 %t77, 0
  %t80 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t78, 1
  store { i64, ptr } %t81, ptr %l4, !tbaa !27
  %t83 = load i64, ptr %l2, !tbaa !24
  %t85 = call ptr @__olang_region_make_part(ptr %v0)
  %t86 = ptrtoint ptr %t85 to i64
  store i64 %t86, ptr %l43, !tbaa !24
  store i64 %t83, ptr %l44, !tbaa !24
  %t88 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t90 = load i64, ptr %l44, !tbaa !24
  %t91 = extractvalue { i64, ptr } %t88, 0
  %t92 = mul i64 %t91, 64
  %t93 = mul i64 %t90, 64
  %t94 = extractvalue { i64, ptr } %t88, 1
  %t95 = call ptr @__olang_grow_in_place(ptr %t94, i64 %t92, i64 %t93, i64 %t90)
  %t96 = icmp ne ptr %t95, null
  %t97 = select i1 %t96, i64 %t90, i64 0
  %t98 = insertvalue { i64, ptr } undef, i64 %t97, 0
  %t99 = insertvalue { i64, ptr } %t98, ptr %t95, 1
  store { i64, ptr } %t99, ptr %l47, !tbaa !27
  %t100 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t100, 0
  %t103 = icmp ne i64 %t101, 0
  br i1 %t103, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_d166e06d50506bfe_5f4d94877991b442)
  unreachable
bb19:
  %t105 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t105, ptr %l45, !tbaa !27
  br label %bb21
bb20:
  %t106 = load i64, ptr %l44, !tbaa !24
  %t107 = mul i64 %t106, 64
  %t108 = load i64, ptr %l43
  %t109 = inttoptr i64 %t108 to ptr
  %t110 = call ptr @__olang_held_alloc(ptr %t109, i64 %t107)
  %t111 = insertvalue { i64, ptr } undef, i64 %t106, 0
  %t112 = insertvalue { i64, ptr } %t111, ptr %t110, 1
  store { i64, ptr } %t112, ptr %l45, !tbaa !27
  store i64 0, ptr %l50, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb22
bb21:
  %t113 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t113, 0
  %t116 = icmp eq i64 %t114, 0
  br i1 %t116, label %bb28, label %bb29
bb22:
  %t118 = load i64, ptr %l6, !tbaa !24
  %t119 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t121 = extractvalue { i64, ptr } %t119, 0
  %t124 = icmp slt i64 %t118, %t121
  %t126 = xor i1 %t124, true
  br i1 %t126, label %bb23, label %bb24
bb23:
  br label %bb27
bb24:
  br label %bb25
bb25:
  %t128 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t128, ptr %l56, !tbaa !27
  %t129 = load i64, ptr %l6, !tbaa !24
  %t131 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t132 = load ptr, ptr %t131, !tbaa !27
  %t133 = getelementptr %"compiler/scope:verAtom", ptr %t132, i64 %t129
  %t134 = load %"compiler/scope:verAtom", ptr %t133
  %t136 = load i64, ptr %l50, !tbaa !24
  %t137 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !27
  %t139 = getelementptr %"compiler/scope:verAtom", ptr %t138, i64 %t136
  store %"compiler/scope:verAtom" %t134, ptr %t139
  %t140 = load i64, ptr %l50, !tbaa !24
  %t141 = add i64 %t140, 1
  store i64 %t141, ptr %l50, !tbaa !24
  br label %bb26
bb26:
  %t142 = load i64, ptr %l6, !tbaa !24
  %t145 = add i64 %t142, 1
  store i64 %t145, ptr %l6, !tbaa !24
  br label %bb22
bb27:
  br label %bb21
bb28:
  store { i64, ptr } zeroinitializer, ptr %l45, !tbaa !27
  br label %bb29
bb29:
  %t147 = load i64, ptr %l43
  %t148 = inttoptr i64 %t147 to ptr
  %t149 = load { i64, ptr }, ptr %l45
  %t150 = extractvalue { i64, ptr } %t149, 1
  %t151 = call ptr @__olang_region_or(ptr %t150, ptr null)
  %t152 = icmp ne ptr %t151, null
  %t153 = select i1 %t152, ptr %t151, ptr null
  call void @__olang_region_settle_in(ptr %t148, ptr %t153)
  %t154 = load ptr, ptr %l33, !tbaa !29
  %t155 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t154, i32 0, i32 0
  %t156 = load { i64, ptr }, ptr %t155, !tbaa !27
  store { i64, ptr } %t156, ptr %l64, !tbaa !27
  %t157 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t158 = load ptr, ptr %l33, !tbaa !29
  %t159 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t158, i32 0, i32 0
  store { i64, ptr } %t157, ptr %t159, !tbaa !27
  %t160 = load { i64, ptr }, ptr %l64
  %t161 = extractvalue { i64, ptr } %t160, 0
  %t162 = extractvalue { i64, ptr } %t160, 1
  call void @__olang_region_release_part(ptr %t162, i64 %t161)
  store { i64, ptr } zeroinitializer, ptr %l64
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3avrRow_3e_2eroom_3ccompiler_2fscope_3avrRow_3e(ptr %v0, ptr %a0, i64 %a1) noinline cold #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l4 = alloca { i64, ptr }
  %l6 = alloca i64
  %l16 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca i64
  %l43 = alloca i64
  %l45 = alloca { i64, ptr }
  %l46 = alloca i64
  %l52 = alloca { i64, ptr }
  %l60 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t2, i32 0, i32 0
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t10 = icmp sle i64 %t1, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t19 = icmp slt i64 %t17, 4
  br i1 %t19, label %bb4, label %bb5
bb4:
  store i64 8, ptr %l16, !tbaa !24
  br label %bb6
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t28 = mul i64 %t26, 2
  store i64 %t28, ptr %l16, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l16, !tbaa !24
  store i64 %t30, ptr %l2, !tbaa !24
  %t31 = load i64, ptr %l2, !tbaa !24
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  br i1 %t35, label %bb7, label %bb8
bb7:
  %t37 = load i64, ptr %l1, !tbaa !24
  store i64 %t37, ptr %l2, !tbaa !24
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t39 = load i64, ptr %l2, !tbaa !24
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t40, i32 0, i32 2
  %t43 = load i64, ptr %t42, !tbaa !24
  %t46 = icmp slt i64 %t39, %t43
  br i1 %t46, label %bb10, label %bb11
bb10:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t48, i32 0, i32 2
  %t51 = load i64, ptr %t50, !tbaa !24
  store i64 %t51, ptr %l2, !tbaa !24
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t53, i32 0, i32 0
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l33, !tbaa !29
  store { i64, ptr } %t56, ptr %l34, !tbaa !27
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t60, i32 0, i32 1
  %t63 = load i64, ptr %t62, !tbaa !24
  store i64 %t63, ptr %l36, !tbaa !24
  %t64 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t64, 0
  store i64 %t65, ptr %l37, !tbaa !24
  %t66 = icmp sge i64 0, 0
  br i1 %t66, label %bb13, label %bb14
bb13:
  %t68 = load i64, ptr %l36, !tbaa !24
  %t69 = icmp sle i64 0, %t68
  br i1 %t69, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_e63925238367d7ee_8208840ac6377ed2)
  unreachable
bb15:
  %t71 = load i64, ptr %l36, !tbaa !24
  %t72 = load i64, ptr %l37, !tbaa !24
  %t73 = icmp sle i64 %t71, %t72
  br i1 %t73, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_e63925238367d7ee_8208840ac6377ed2)
  unreachable
bb17:
  %t75 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = load i64, ptr %l36, !tbaa !24
  %t78 = getelementptr %"compiler/scope:vrRow", ptr %t76, i64 0
  %t79 = sub i64 %t77, 0
  %t80 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t78, 1
  store { i64, ptr } %t81, ptr %l4, !tbaa !27
  %t83 = load i64, ptr %l2, !tbaa !24
  %t85 = call ptr @__olang_region_make_part(ptr %v0)
  %t86 = ptrtoint ptr %t85 to i64
  store i64 %t86, ptr %l43, !tbaa !24
  %t89 = mul i64 %t83, 32
  %t90 = load i64, ptr %l43
  %t91 = inttoptr i64 %t90 to ptr
  %t92 = call ptr @__olang_scope_alloc_zeroed(ptr %t91, i64 %t89)
  %t93 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t94 = insertvalue { i64, ptr } %t93, ptr %t92, 1
  store { i64, ptr } %t94, ptr %l45, !tbaa !27
  store i64 0, ptr %l46, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_e63925238367d7ee_8208840ac6377ed2)
  unreachable
bb19:
  %t95 = load i64, ptr %l6, !tbaa !24
  %t96 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t98 = extractvalue { i64, ptr } %t96, 0
  %t101 = icmp slt i64 %t95, %t98
  %t103 = xor i1 %t101, true
  br i1 %t103, label %bb20, label %bb21
bb20:
  br label %bb24
bb21:
  br label %bb22
bb22:
  %t105 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t105, ptr %l52, !tbaa !27
  %t106 = load i64, ptr %l6, !tbaa !24
  %t108 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !27
  %t110 = getelementptr %"compiler/scope:vrRow", ptr %t109, i64 %t106
  %t111 = load %"compiler/scope:vrRow", ptr %t110
  store %"compiler/scope:vrRow" zeroinitializer, ptr %t110
  %t113 = load i64, ptr %l46, !tbaa !24
  %t114 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !27
  %t116 = getelementptr %"compiler/scope:vrRow", ptr %t115, i64 %t113
  store %"compiler/scope:vrRow" %t111, ptr %t116
  %t117 = load i64, ptr %l46, !tbaa !24
  %t118 = add i64 %t117, 1
  store i64 %t118, ptr %l46, !tbaa !24
  br label %bb23
bb23:
  %t119 = load i64, ptr %l6, !tbaa !24
  %t122 = add i64 %t119, 1
  store i64 %t122, ptr %l6, !tbaa !24
  br label %bb19
bb24:
  %t124 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t125 = extractvalue { i64, ptr } %t124, 0
  %t127 = icmp eq i64 %t125, 0
  br i1 %t127, label %bb25, label %bb26
bb25:
  store { i64, ptr } zeroinitializer, ptr %l45, !tbaa !27
  br label %bb26
bb26:
  %t129 = load i64, ptr %l43
  %t130 = inttoptr i64 %t129 to ptr
  %t131 = load { i64, ptr }, ptr %l45
  %t132 = extractvalue { i64, ptr } %t131, 1
  %t133 = call ptr @__olang_region_or(ptr %t132, ptr null)
  %t134 = icmp ne ptr %t133, null
  %t135 = select i1 %t134, ptr %t133, ptr null
  call void @__olang_region_settle_in(ptr %t130, ptr %t135)
  %t136 = load ptr, ptr %l33, !tbaa !29
  %t137 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t136, i32 0, i32 0
  %t138 = load { i64, ptr }, ptr %t137, !tbaa !27
  store { i64, ptr } %t138, ptr %l60, !tbaa !27
  %t139 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t140 = load ptr, ptr %l33, !tbaa !29
  %t141 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t140, i32 0, i32 0
  store { i64, ptr } %t139, ptr %t141, !tbaa !27
  %t142 = load { i64, ptr }, ptr %l60
  %t143 = extractvalue { i64, ptr } %t142, 0
  %t144 = extractvalue { i64, ptr } %t142, 1
  call void @__olang_region_release_part(ptr %t144, i64 %t143)
  store { i64, ptr } zeroinitializer, ptr %l60
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aStringBuilder_3_H20083f40fdfe1180e8f262726b415108(ptr %v0, ptr %a0, i64 %a1) noinline cold #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l4 = alloca { i64, ptr }
  %l6 = alloca i64
  %l16 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca i64
  %l43 = alloca i64
  %l45 = alloca { i64, ptr }
  %l46 = alloca i64
  %l52 = alloca { i64, ptr }
  %l60 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t2, i32 0, i32 0
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t10 = icmp sle i64 %t1, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t19 = icmp slt i64 %t17, 4
  br i1 %t19, label %bb4, label %bb5
bb4:
  store i64 8, ptr %l16, !tbaa !24
  br label %bb6
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t28 = mul i64 %t26, 2
  store i64 %t28, ptr %l16, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l16, !tbaa !24
  store i64 %t30, ptr %l2, !tbaa !24
  %t31 = load i64, ptr %l2, !tbaa !24
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  br i1 %t35, label %bb7, label %bb8
bb7:
  %t37 = load i64, ptr %l1, !tbaa !24
  store i64 %t37, ptr %l2, !tbaa !24
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t39 = load i64, ptr %l2, !tbaa !24
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t40, i32 0, i32 2
  %t43 = load i64, ptr %t42, !tbaa !24
  %t46 = icmp slt i64 %t39, %t43
  br i1 %t46, label %bb10, label %bb11
bb10:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t48, i32 0, i32 2
  %t51 = load i64, ptr %t50, !tbaa !24
  store i64 %t51, ptr %l2, !tbaa !24
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t53, i32 0, i32 0
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l33, !tbaa !29
  store { i64, ptr } %t56, ptr %l34, !tbaa !27
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t60, i32 0, i32 1
  %t63 = load i64, ptr %t62, !tbaa !24
  store i64 %t63, ptr %l36, !tbaa !24
  %t64 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t64, 0
  store i64 %t65, ptr %l37, !tbaa !24
  %t66 = icmp sge i64 0, 0
  br i1 %t66, label %bb13, label %bb14
bb13:
  %t68 = load i64, ptr %l36, !tbaa !24
  %t69 = icmp sle i64 0, %t68
  br i1 %t69, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_8b7d73b05b3bfe0e_51c60bf7b995a2ba)
  unreachable
bb15:
  %t71 = load i64, ptr %l36, !tbaa !24
  %t72 = load i64, ptr %l37, !tbaa !24
  %t73 = icmp sle i64 %t71, %t72
  br i1 %t73, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_8b7d73b05b3bfe0e_51c60bf7b995a2ba)
  unreachable
bb17:
  %t75 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = load i64, ptr %l36, !tbaa !24
  %t78 = getelementptr %"std/prelude/text:StringBuilder", ptr %t76, i64 0
  %t79 = sub i64 %t77, 0
  %t80 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t78, 1
  store { i64, ptr } %t81, ptr %l4, !tbaa !27
  %t83 = load i64, ptr %l2, !tbaa !24
  %t85 = call ptr @__olang_region_make_part(ptr %v0)
  %t86 = ptrtoint ptr %t85 to i64
  store i64 %t86, ptr %l43, !tbaa !24
  %t89 = mul i64 %t83, 32
  %t90 = load i64, ptr %l43
  %t91 = inttoptr i64 %t90 to ptr
  %t92 = call ptr @__olang_scope_alloc_zeroed(ptr %t91, i64 %t89)
  %t93 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t94 = insertvalue { i64, ptr } %t93, ptr %t92, 1
  store { i64, ptr } %t94, ptr %l45, !tbaa !27
  store i64 0, ptr %l46, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_8b7d73b05b3bfe0e_51c60bf7b995a2ba)
  unreachable
bb19:
  %t95 = load i64, ptr %l6, !tbaa !24
  %t96 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t98 = extractvalue { i64, ptr } %t96, 0
  %t101 = icmp slt i64 %t95, %t98
  %t103 = xor i1 %t101, true
  br i1 %t103, label %bb20, label %bb21
bb20:
  br label %bb24
bb21:
  br label %bb22
bb22:
  %t105 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t105, ptr %l52, !tbaa !27
  %t106 = load i64, ptr %l6, !tbaa !24
  %t108 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !27
  %t110 = getelementptr %"std/prelude/text:StringBuilder", ptr %t109, i64 %t106
  %t111 = load %"std/prelude/text:StringBuilder", ptr %t110
  store %"std/prelude/text:StringBuilder" zeroinitializer, ptr %t110
  %t113 = load i64, ptr %l46, !tbaa !24
  %t114 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !27
  %t116 = getelementptr %"std/prelude/text:StringBuilder", ptr %t115, i64 %t113
  store %"std/prelude/text:StringBuilder" %t111, ptr %t116
  %t117 = load i64, ptr %l46, !tbaa !24
  %t118 = add i64 %t117, 1
  store i64 %t118, ptr %l46, !tbaa !24
  br label %bb23
bb23:
  %t119 = load i64, ptr %l6, !tbaa !24
  %t122 = add i64 %t119, 1
  store i64 %t122, ptr %l6, !tbaa !24
  br label %bb19
bb24:
  %t124 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t125 = extractvalue { i64, ptr } %t124, 0
  %t127 = icmp eq i64 %t125, 0
  br i1 %t127, label %bb25, label %bb26
bb25:
  store { i64, ptr } zeroinitializer, ptr %l45, !tbaa !27
  br label %bb26
bb26:
  %t129 = load i64, ptr %l43
  %t130 = inttoptr i64 %t129 to ptr
  %t131 = load { i64, ptr }, ptr %l45
  %t132 = extractvalue { i64, ptr } %t131, 1
  %t133 = call ptr @__olang_region_or(ptr %t132, ptr null)
  %t134 = icmp ne ptr %t133, null
  %t135 = select i1 %t134, ptr %t133, ptr null
  call void @__olang_region_settle_in(ptr %t130, ptr %t135)
  %t136 = load ptr, ptr %l33, !tbaa !29
  %t137 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t136, i32 0, i32 0
  %t138 = load { i64, ptr }, ptr %t137, !tbaa !27
  store { i64, ptr } %t138, ptr %l60, !tbaa !27
  %t139 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t140 = load ptr, ptr %l33, !tbaa !29
  %t141 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t140, i32 0, i32 0
  store { i64, ptr } %t139, ptr %t141, !tbaa !27
  %t142 = load { i64, ptr }, ptr %l60
  %t143 = extractvalue { i64, ptr } %t142, 0
  %t144 = extractvalue { i64, ptr } %t142, 1
  call void @__olang_region_release_part(ptr %t144, i64 %t143)
  store { i64, ptr } zeroinitializer, ptr %l60
  br label %ret
ret:
  ret void
}

define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %dh = load ptr, ptr %dheadptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  %hasd = icmp ne ptr %dh, null
  %owns = or i1 %hasf, %hasd
  br i1 %owns, label %owned, label %chunks
owned:
  call void @__olang_scope_close_owned(ptr %scope)
  br label %chunks
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare void @__olang_check_failed(ptr) cold noreturn
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
define available_externally void @__olang_scope_escape(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %un = icmp eq ptr %o, null
  br i1 %un, label %claim, label %done
claim:
  %me = load ptr, ptr @__olang_self
  store atomic ptr %me, ptr %op monotonic, align 8
  br label %done
done:
  ret void
}
define available_externally ptr @__olang_scope_hold(ptr %s) alwaysinline {
entry:
  %none = icmp eq ptr %s, null
  br i1 %none, label %plain, label %look
look:
  ; atomic: on a scope that is no stand-in this word is its parts list, which other threads push onto (__olang_scope_part)
  %mp = getelementptr %olang.scope, ptr %s, i32 0, i32 4
  %m = load atomic ptr, ptr %mp monotonic, align 8
  %fresh = icmp eq ptr %m, @__olang_standin_mark
  br i1 %fresh, label %make, label %kept
kept:
  %mi = ptrtoint ptr %m to i64
  %bit = and i64 %mi, 1
  %has = icmp ne i64 %bit, 0
  br i1 %has, label %keeper, label %plain
keeper:
  %ki = and i64 %mi, -2
  %k = inttoptr i64 %ki to ptr
  ret ptr %k
make:
  %f = call ptr @__olang_standin_keeper(ptr %s)
  ret ptr %f
plain:
  ret ptr %s
}
define internal i1 @olang_lambda_0(ptr %env, i64 %a0, i64 %a1) #0 {
entry:
  %l3 = alloca { i64, ptr }
  %l4 = alloca i1
  %l6 = alloca { i64, ptr }
  %l9 = alloca %"compiler/scope:Placement"
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l16 = alloca %"compiler/scope:Placement"
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca { i64, ptr }
  %l20 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  %cp0 = getelementptr { { ptr, ptr }, { i64, ptr }, ptr, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load { ptr, ptr }, ptr %cp0, !tbaa !28
  %cp1 = getelementptr { { ptr, ptr }, { i64, ptr }, ptr, ptr }, ptr %env, i32 0, i32 1
  %cv1 = load { i64, ptr }, ptr %cp1, !tbaa !28
  store { i64, ptr } %cv1, ptr %l3
  %vq0 = getelementptr { { ptr, ptr }, { i64, ptr }, ptr, ptr }, ptr %env, i32 0, i32 2
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  %vq1 = getelementptr { { ptr, ptr }, { i64, ptr }, ptr, ptr }, ptr %env, i32 0, i32 3
  %vr1 = load ptr, ptr %vq1, !tbaa !28
  %vc1 = call ptr @__olang_capture_scope(ptr %vr1)
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t2 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t2, ptr %l6, !tbaa !27
  %t5 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t6 = load ptr, ptr %t5, !tbaa !27
  %t7 = getelementptr %"compiler/scope:Placement", ptr %t6, i64 %a0
  %t8 = load %"compiler/scope:Placement", ptr %t7
  store %"compiler/scope:Placement" %t8, ptr %l9
  %t10 = getelementptr %"compiler/scope:Placement", ptr %l9, i32 0, i32 4
  %t11 = load { i64, ptr }, ptr %t10, !tbaa !27
  store { i64, ptr } %t11, ptr %l10, !tbaa !27
  %t12 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t12, 0
  store i64 %t13, ptr %l11, !tbaa !24
  %t14 = load i64, ptr %l11, !tbaa !24
  %t15 = mul i64 %t14, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t15)
  %t17 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  store { i64, ptr } %t18, ptr %l12, !tbaa !27
  %t19 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !27
  %t21 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = load i64, ptr %l11, !tbaa !24
  %t24 = mul i64 %t23, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t20, ptr %t22, i64 %t24, i1 false)
  %t25 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t26 = getelementptr %"compiler/scope:Placement", ptr %l9, i32 0, i32 4
  store { i64, ptr } %t25, ptr %t26, !tbaa !27
  %t27 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t27, ptr %l13, !tbaa !27
  %t30 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !27
  %t32 = getelementptr %"compiler/scope:Placement", ptr %t31, i64 %a1
  %t33 = load %"compiler/scope:Placement", ptr %t32
  store %"compiler/scope:Placement" %t33, ptr %l16
  %t35 = getelementptr %"compiler/scope:Placement", ptr %l16, i32 0, i32 4
  %t36 = load { i64, ptr }, ptr %t35, !tbaa !27
  store { i64, ptr } %t36, ptr %l17, !tbaa !27
  %t37 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t37, 0
  store i64 %t38, ptr %l18, !tbaa !24
  %t39 = load i64, ptr %l18, !tbaa !24
  %t40 = mul i64 %t39, 1
  %t41 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t40)
  %t42 = insertvalue { i64, ptr } undef, i64 %t39, 0
  %t43 = insertvalue { i64, ptr } %t42, ptr %t41, 1
  store { i64, ptr } %t43, ptr %l19, !tbaa !27
  %t44 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = load i64, ptr %l18, !tbaa !24
  %t49 = mul i64 %t48, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t45, ptr %t47, i64 %t49, i1 false)
  %t50 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t51 = getelementptr %"compiler/scope:Placement", ptr %l16, i32 0, i32 4
  store { i64, ptr } %t50, ptr %t51, !tbaa !27
  %t53 = extractvalue { ptr, ptr } %cv0, 0
  %t54 = extractvalue { ptr, ptr } %cv0, 1
  %t55 = load %"compiler/scope:Placement", ptr %l9
  %t56 = load %"compiler/scope:Placement", ptr %l16
  %t57 = call i1 %t53(ptr %t54, ptr %s0, ptr %s0, %"compiler/scope:Placement" %t55, %"compiler/scope:Placement" %t56)
  store i1 %t57, ptr %l20
  br label %bb1
bb1:
  %t58 = load i1, ptr %l20, !tbaa !21
  store i1 %t58, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  %t59 = load i1, ptr %l4, !tbaa !21
  store i1 %t59, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare ptr @__olang_region_make_part(ptr) noinline
define available_externally noalias ptr @__olang_held_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare ptr @__olang_region_or(ptr, ptr)
declare void @__olang_region_settle_in(ptr, ptr)
declare void @__olang_region_release_part(ptr, i64) noinline
declare ptr @__olang_grow_in_place(ptr, i64, i64, i64) noinline
define linkonce_odr i1 @olang_2emir_2eHelperKind_2eEqual_2estd_2fpair_3aPair_3cI64_2c_20I64_3e(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = getelementptr %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %t1, i32 0, i32 0
  %t3 = load i64, ptr %t2, !tbaa !24
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t5 = getelementptr %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %t4, i32 0, i32 0
  %t6 = load i64, ptr %t5, !tbaa !24
  %t9 = icmp eq i64 %t3, %t6
  br i1 %t9, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb4
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %t11, i32 0, i32 1
  %t13 = load i64, ptr %t12, !tbaa !24
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %t14, i32 0, i32 1
  %t16 = load i64, ptr %t15, !tbaa !24
  %t19 = icmp eq i64 %t13, %t16
  br i1 %t19, label %bb3, label %bb1
bb3:
  br label %bb4
bb4:
  %t21 = load i1, ptr %l2, !tbaa !21
  store i1 %t21, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define linkonce_odr %"compiler/scope:Placement" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fscope_3aPlacement(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/scope:Placement"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"compiler/scope:Placement"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"compiler/scope:Placement", ptr %a0
  store %"compiler/scope:Placement" %t2, ptr %l1
  %t3 = getelementptr %"compiler/scope:Placement", ptr %l1, i32 0, i32 4
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 1
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"compiler/scope:Placement", ptr %l1, i32 0, i32 4
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"compiler/scope:Placement", ptr %l1
  store %"compiler/scope:Placement" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/scope:Placement", ptr %rv
  ret %"compiler/scope:Placement" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3anote_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 64
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 64
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 8
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

declare void @__olang_scope_close_owned(ptr) noinline
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@__olang_self = external thread_local(initialexec) global ptr
@__olang_standin_mark = external global i64
declare ptr @__olang_standin_keeper(ptr) noinline
define available_externally ptr @__olang_capture_scope(ptr %s) alwaysinline {
entry:
  %isprog = icmp eq ptr %s, null
  br i1 %isprog, label %prog, label %mine
prog:
  %p = load ptr, ptr @__olang_prog_scope
  ret ptr %p
mine:
  %m = call ptr @__olang_scope_mine(ptr %s)
  ret ptr %m
}
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
define available_externally noalias ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  %head = load ptr, ptr %scope, !tbaa !59
  %isslot = icmp eq ptr %head, @__olang_slot_chunk
  br i1 %isslot, label %slot, label %plain
slot:
  %s = call ptr @__olang_slot_alloc(ptr %scope, i64 %rawsize)
  ret ptr %s
plain:
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
@__olang_prog_scope = external thread_local(initialexec) global ptr
define available_externally ptr @__olang_scope_mine(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %me = load ptr, ptr @__olang_self
  %own = icmp eq ptr %o, %me
  br i1 %own, label %mine, label %slow
mine:
  ret ptr %s
slow:
  %r = call ptr @__olang_scope_mine_slow(ptr %s)
  ret ptr %r
}
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
@__olang_slot_chunk = external global %olang.chunk
declare noalias ptr @__olang_slot_alloc(ptr, i64) noinline
declare ptr @__olang_scope_mine_slow(ptr) noinline
@G_2estd_2fprelude_2farray_2esortRun = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\18\00\00\00\00\00\00\00" }>, align 8
declare void @std_2fprelude_2farray_2esortInsertion_3ccompiler_2fscope_3aPlacement_2c_20_3f_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i64 %a2, ptr %a3c, ptr %a3e)
@G_2estd_2fprelude_2farray_2esortBlock = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\30\00\00\00\00\00\00" }>, align 8
@olang_loc_d722d9d356e51315_f6b57ef284a7b0b9 = external constant [0 x i8]
@olang_loc_f1b0736c8bbc73d8_d1c24a04e6320604 = external constant [0 x i8]
declare void @std_2fprelude_2farray_2esortMergeBuffered_3cI64_2c_20_3f_3e_clone1_olang_lambda_17199(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1c, ptr %a1e)
declare void @std_2fprelude_2farray_2esortPermute_3ccompiler_2fscope_3aPlacement_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, { i64, ptr } %a2)
declare void @std_2fprelude_2farray_2esortSwap_3ccompiler_2fscope_3aPlacement_3e(ptr %v0, { i64, ptr } %a0, i64 %a1, i64 %a2)
@olang_loc_cb901f43eea5c9a0_3eb2537e81d31bc4 = external constant [0 x i8]
declare i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Array_3cI64_3e_3e_2ebucketOf_3cI64_2c_20Array_3cI64_3e_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Array_3cI64_3e_3e_2eadd_3cI64_2c_20Array_3cI64_3e_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2, { i64, ptr } %a3)
@olang_loc_efc345d8d3eafa86_4789cc625aeb6fb2 = external constant [0 x i8]
@olang_loc_f01abca99f12a563_b260ce0f455ce82f = external constant [0 x i8]
@olang_loc_f6472837ebf15fa0_30dce77208a6bfbc = external constant [0 x i8]
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Array_3ccompiler_2ftyped_3aBl_H6d0037fa94350b00beccb9ab942eac64(ptr %v0, ptr %a0, i64 %a1, i64 %a2, { i64, ptr } %a3)
@olang_loc_3528876d0c13efc_db479c62e0d308a8 = external constant [0 x i8]
@olang_loc_cd6172c4357b6ce9_3d4b800321d5e485 = external constant [0 x i8]
@olang_loc_1a4d5a334653e862_10d80ed88f47b4fe = external constant [0 x i8]
@olang_loc_96fcf0d51cfc1fdf_b5f765173d5e377b = external constant [0 x i8]
@olang_loc_6958e5460cd6db86_580233942ca5b42 = external constant [0 x i8]
@olang_loc_69b05c16d7fe8663_9b68229f54eb9d3f = external constant [0 x i8]
@olang_loc_942546e0f7a32db8_2fedafd50c7367bc = external constant [0 x i8]
@olang_loc_6c0209f6cdc38395_974bf4e768403fa9 = external constant [0 x i8]
@olang_loc_7f58bbce9e95ad79_e8f56ec1072e1d1d = external constant [0 x i8]
@olang_loc_d289edfcd51d194c_58000e496e1c51c0 = external constant [0 x i8]
@olang_loc_8e1720a227959e1e_499b96ad7001723a = external constant [0 x i8]
@olang_loc_7640e0166a5bae1b_7c6c5bf7bf0c1517 = external constant [0 x i8]
@olang_loc_2d5992de5eb5e220_d01bd11e8c84951c = external constant [0 x i8]
@olang_loc_3273894d8bafbc7d_5b34b81ebd149289 = external constant [0 x i8]
@olang_loc_cfa5d910a69519b_67e6a2203f5ae367 = external constant [0 x i8]
@olang_loc_24d09e1cc7a3419e_87b719873437508a = external constant [0 x i8]
@olang_loc_df3b8f0899449cba_3e19093db1eeacce = external constant [0 x i8]
@olang_loc_120c5452e84f3f97_763eee1079714acb = external constant [0 x i8]
@olang_loc_4eccde1bb0e637f8_700fb4e34e9e4e0c = external constant [0 x i8]
@olang_loc_70c5af7f062357d5_5e76ff2066ccf239 = external constant [0 x i8]
@olang_loc_ce54309ebf43a10c_695faa571e12de08 = external constant [0 x i8]
@olang_loc_bcbb7adbd7724539_b819b71564b56465 = external constant [0 x i8]
@olang_loc_acc92269b5ffdffb_45a05bc66f31af67 = external constant [0 x i8]
@olang_loc_7a9cc2b07e95d7e_6570d32d640e1c8a = external constant [0 x i8]
@olang_loc_5ad7f35e69ffe522_7a613f9347dd1ffe = external constant [0 x i8]
@olang_loc_775db944194a729f_1f8095d1f5f3a27b = external constant [0 x i8]
@olang_loc_1bfebcd902ff6bfb_534ec135c8ab703f = external constant [0 x i8]
declare i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H0ad23e78b2b593286f94a0de5701989f(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Array_3_H78beb88f07a363e6103d3b1ab418f0bc(ptr %v0, ptr %a0, i64 %a1, i32 %a2, { i64, ptr } %a3)
@olang_loc_186fa87127077de0_2ccfdff69ff8a78c = external constant [0 x i8]
@olang_loc_e00ef57679a22b3d_1b372a33b8274bb9 = external constant [0 x i8]
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H6b09e5441c2ec01470c60a94adf00ee5(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI32_2c_20I64_3e_2eroom_3cI32_2c_20I64_3e(ptr %v0, ptr %a0)
@olang_loc_eeb9dbebae58ad76_140d94069fd0f1da = external constant [0 x i8]
declare i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2b299ac8414fe0900d06d94de708c354(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H5726a2dd684fb58cbf53a937edd2530b(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a2, %"compiler/scope:Placement" %a3)
@olang_loc_1a9fa279a31b6314_c50c4801ffbd75a8 = external constant [0 x i8]
@olang_loc_4389c18ddfab6081_27102ba240c05185 = external constant [0 x i8]
@olang_loc_f5147e9cccb71a89_abf62f853b44252d = external constant [0 x i8]
@olang_loc_69fb979c9c271d1c_9f38969fb60f0e50 = external constant [0 x i8]
@olang_loc_845ee880493f49db_8165d66f07a0ab27 = external constant [0 x i8]
@olang_loc_286d44cd953550de_d0d5fc71fd1a284a = external constant [0 x i8]
@olang_loc_774282684c71143f_50171c9d0a1ed80b = external constant [0 x i8]
@olang_loc_e15a83023a4fd242_c4a6dc6ba0248c0e = external constant [0 x i8]
@olang_loc_39d4b9cd0aa741ac_83bc004070fe27a0 = external constant [0 x i8]
@olang_loc_fee251769c24e159_88d5f6af9df801fd = external constant [0 x i8]
@olang_loc_d09d4290b7da555d_4aaf343b9bec4899 = external constant [0 x i8]
@olang_loc_8c25b0a34c040f00_7447c6fffda4a9ec = external constant [0 x i8]
@olang_loc_588616244e83f4d1_f256c997d7540e5d = external constant [0 x i8]
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H906657e795452d3a9a579308e9320d73(ptr %v0, ptr %a0, i64 %a1, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a2, { i64, ptr } %a3)
@olang_loc_f5387e41aa461073_85329e3d54822a57 = external constant [0 x i8]
@olang_loc_baf2591500da8816_6821f095f5d7547a = external constant [0 x i8]
@olang_loc_bad36ec9740ef4a6_7452059db725b0f2 = external constant [0 x i8]
@olang_loc_a5d08808e6de8d03_28862b30739966f = external constant [0 x i8]
@olang_loc_4cb2c4a1e0b65f9e_2e4d44f1258f401a = external constant [0 x i8]
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H453662ae559f86d4d40ba4da3fb4f916(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a2, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a3)
@olang_loc_f648f51cc9ea530b_e9e5817bf319c63f = external constant [0 x i8]
@olang_loc_6ad8b4eb5ff0070e_53fd8215e0f88442 = external constant [0 x i8]
@olang_loc_d7e3401240abac0_21ebe09f02269f14 = external constant [0 x i8]
@olang_loc_9e739478bd1c861d_4ad5ffb33eb69c81 = external constant [0 x i8]
@olang_loc_6819ac57acf012f0_cfcc4d405fca79c = external constant [0 x i8]
@olang_loc_7f22b794516974cd_9815abd4368ca509 = external constant [0 x i8]
@olang_loc_6fd14cdf40707d56_2f0bca432f63f912 = external constant [0 x i8]
@olang_loc_6f3a6ec21bfbf2b3_3a2c7f61b161530f = external constant [0 x i8]
@olang_loc_ca049a7d99d53f9f_ca8eea9c91e2bc6b = external constant [0 x i8]
@olang_loc_ad7ed497ea8ab222_f6572ed697be0e6e = external constant [0 x i8]
@olang_loc_2894e3ab3f2af7f3_8e483e5495b872bf = external constant [0 x i8]
@olang_loc_ee4ebe7e95bf6f96_f8603eee839730c2 = external constant [0 x i8]
@olang_loc_93f674fca185685e_cd261ae5f7812eaa = external constant [0 x i8]
declare i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_2c_20Boo_He838af28276528f84a686ca3d206b833(ptr %v0, ptr %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_2c_20std_Hcceee2791b609c347cb46403ab146074(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a3)
@olang_loc_efd753ebce06d520_5a29f91d7c8b642c = external constant [0 x i8]
@olang_loc_f4f14a5afb00af7d_1f3790c70e0903d9 = external constant [0 x i8]
@olang_loc_f2d7fef6be0d2aaa_9057d438a463b76e = external constant [0 x i8]
@olang_loc_efe79bd589437e16_606b0d04bc3b4b9a = external constant [0 x i8]
@olang_loc_e088370f9441903e_306c6e610ec90752 = external constant [0 x i8]
@olang_loc_d166e06d50506bfe_5f4d94877991b442 = external constant [0 x i8]
@olang_loc_e63925238367d7ee_8208840ac6377ed2 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI32_3e_2eroom_3cI32_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fcancel_3awaiter_26_3e_2ero_H6a455c8a57b15c7ee297f354a569a56a(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_8b7d73b05b3bfe0e_51c60bf7b995a2ba = external constant [0 x i8]

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
