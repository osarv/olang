; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

@olang_loc_2637538080546989_dfca52fe716ed845 = weak_odr constant [54 x i8] c"std/prelude/map.olang:122: array length out of range\0A\00"
@olang_loc_2de252d27ebbb1b7_a6355dd3d1252683 = weak_odr constant [54 x i8] c"std/prelude/map.olang:102: slice bounds out of range\0A\00"
@olang_loc_2f85d2be58839c59_bf249b0f29dbe485 = weak_odr constant [54 x i8] c"std/prelude/map.olang:111: array length out of range\0A\00"
@olang_loc_eeb94a7f49ab905a_bb3844945e558e26 = weak_odr constant [54 x i8] c"std/prelude/map.olang:105: slice bounds out of range\0A\00"
