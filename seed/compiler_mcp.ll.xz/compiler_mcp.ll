; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/session:Reader" = type { i32, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1 }
%"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"std/os:Output" = type { i32, { i64, ptr }, { i64, ptr } }
%"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/diag:Item" = type { i1, { i64, ptr }, i64, i64, i64, i64, { i64, ptr } }
%"compiler/session:Positions" = type { { i64, ptr }, i1, { i64, ptr } }
%"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/diag:Diagnostics" = type { i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, [3 x i64] }, { i64, ptr }, { i64, ptr }, i1 }
%"compiler/doc:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/session:Analysis" = type { ptr, ptr, ptr, ptr }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, { i64, ptr } }
%"std/prelude/text:LineIter" = type { { i64, ptr }, i64 }
@G_2ecompiler_2fmcp_2eTools = constant <{ [8 x i8], ptr }> <{ [8 x i8] c"\BF\07\00\00\00\00\00\00", ptr @G_2ecompiler_2fmcp_2eTools.k1 }>, align 8
@G_2ecompiler_2fmcp_2eTools.k1 = internal constant <{ [1983 x i8] }> <{ [1983 x i8] c"\5B\7B\22\6E\61\6D\65\22\3A\22\63\68\65\63\6B\22\2C\22\64\65\73\63\72\69\70\74\69\6F\6E\22\3A\22\43\68\65\63\6B\20\61\6E\20\6F\6C\61\6E\67\20\66\69\6C\65\20\61\73\20\74\68\65\20\63\6F\6D\70\69\6C\65\72\20\64\6F\65\73\20\28\69\74\73\20\70\72\6F\67\72\61\6D\20\6C\6F\61\64\65\64\2C\20\74\79\70\65\2D\63\68\65\63\6B\65\64\2C\20\69\74\73\20\63\6F\6D\70\69\6C\65\2D\74\69\6D\65\20\76\61\6C\75\65\73\20\61\6E\64\20\61\73\73\65\72\74\73\20\64\65\63\69\64\65\64\2C\20\68\65\6C\64\20\74\6F\20\74\68\65\20\73\63\6F\70\65\20\72\75\6C\65\73\29\3A\20\65\76\65\72\79\20\64\69\61\67\6E\6F\73\74\69\63\2C\20\65\61\63\68\20\69\74\73\20\66\69\6C\65\2C\20\6C\69\6E\65\2C\20\63\6F\6C\75\6D\6E\2C\20\72\75\6C\65\20\61\6E\64\20\6D\65\73\73\61\67\65\2C\20\61\6E\64\20\74\68\65\20\63\6F\6D\70\69\6C\65\72\27\73\20\6F\77\6E\20\6F\6E\65\2D\72\6F\77\20\72\65\6E\64\65\72\69\6E\67\2E\20\50\61\73\73\20\74\65\78\74\20\74\6F\20\63\68\65\63\6B\20\75\6E\73\61\76\65\64\20\63\6F\64\65\20\69\6E\20\70\6C\61\63\65\20\6F\66\20\74\68\65\20\66\69\6C\65\27\73\20\63\6F\6E\74\65\6E\74\73\2E\22\2C\22\69\6E\70\75\74\53\63\68\65\6D\61\22\3A\7B\22\74\79\70\65\22\3A\22\6F\62\6A\65\63\74\22\2C\22\70\72\6F\70\65\72\74\69\65\73\22\3A\7B\22\66\69\6C\65\22\3A\7B\22\74\79\70\65\22\3A\22\73\74\72\69\6E\67\22\2C\22\64\65\73\63\72\69\70\74\69\6F\6E\22\3A\22\70\61\74\68\20\6F\66\20\74\68\65\20\2E\6F\6C\61\6E\67\20\66\69\6C\65\2C\20\74\68\65\20\72\6F\6F\74\20\6F\66\20\74\68\65\20\70\72\6F\67\72\61\6D\22\7D\2C\22\74\65\78\74\22\3A\7B\22\74\79\70\65\22\3A\22\73\74\72\69\6E\67\22\2C\22\64\65\73\63\72\69\70\74\69\6F\6E\22\3A\22\74\68\65\20\66\69\6C\65\27\73\20\74\65\78\74\2C\20\69\66\20\6E\6F\74\20\61\73\20\73\61\76\65\64\22\7D\7D\2C\22\72\65\71\75\69\72\65\64\22\3A\5B\22\66\69\6C\65\22\5D\7D\7D\2C\7B\22\6E\61\6D\65\22\3A\22\65\78\70\6C\61\69\6E\22\2C\22\64\65\73\63\72\69\70\74\69\6F\6E\22\3A\22\41\20\74\6F\70\2D\6C\65\76\65\6C\20\69\74\65\6D\20\6F\66\20\61\6E\20\6F\6C\61\6E\67\20\66\69\6C\65\20\61\73\20\74\68\65\20\63\6F\6D\70\69\6C\65\72\20\73\65\65\73\20\69\74\3A\20\61\20\66\75\6E\63\74\69\6F\6E\27\73\20\77\68\6F\6C\65\20\73\69\67\6E\61\74\75\72\65\20\77\69\74\68\20\69\74\73\20\69\6E\66\65\72\72\65\64\20\65\72\72\6F\72\20\73\65\74\20\61\6E\64\20\73\63\6F\70\65\20\6F\62\6C\69\67\61\74\69\6F\6E\73\2C\20\61\20\74\79\70\65\27\73\20\63\6F\6E\73\74\72\75\63\74\6F\72\2C\20\66\69\65\6C\64\73\2C\20\6D\65\74\68\6F\64\73\20\61\6E\64\20\74\72\61\69\74\73\2C\20\61\20\67\6C\6F\62\61\6C\27\73\20\74\79\70\65\20\61\6E\64\20\76\61\6C\75\65\20\2D\20\6F\72\2C\20\67\69\76\65\6E\20\61\20\72\75\6C\65\20\73\75\63\68\20\61\73\20\54\36\62\20\61\6E\64\20\6E\6F\20\66\69\6C\65\2C\20\74\68\61\74\20\72\75\6C\65\20\6F\66\20\74\68\65\20\73\70\65\63\69\66\69\63\61\74\69\6F\6E\2E\22\2C\22\69\6E\70\75\74\53\63\68\65\6D\61\22\3A\7B\22\74\79\70\65\22\3A\22\6F\62\6A\65\63\74\22\2C\22\70\72\6F\70\65\72\74\69\65\73\22\3A\7B\22\66\69\6C\65\22\3A\7B\22\74\79\70\65\22\3A\22\73\74\72\69\6E\67\22\7D\2C\22\6E\61\6D\65\22\3A\7B\22\74\79\70\65\22\3A\22\73\74\72\69\6E\67\22\2C\22\64\65\73\63\72\69\70\74\69\6F\6E\22\3A\22\61\6E\20\69\74\65\6D\2C\20\6F\72\20\54\79\70\65\2E\4D\65\74\68\6F\64\3B\20\6F\72\20\61\20\72\75\6C\65\20\6F\66\20\74\68\65\20\73\70\65\63\69\66\69\63\61\74\69\6F\6E\20\77\68\65\6E\20\66\69\6C\65\20\69\73\20\6C\65\66\74\20\6F\75\74\22\7D\7D\2C\22\72\65\71\75\69\72\65\64\22\3A\5B\22\6E\61\6D\65\22\5D\7D\7D\2C\7B\22\6E\61\6D\65\22\3A\22\64\6F\63\22\2C\22\64\65\73\63\72\69\70\74\69\6F\6E\22\3A\22\54\68\65\20\64\6F\63\75\6D\65\6E\74\61\74\69\6F\6E\20\6F\66\20\61\6E\20\6F\6C\61\6E\67\20\6D\6F\64\75\6C\65\20\28\69\74\73\20\64\6F\63\20\63\6F\6D\6D\65\6E\74\73\20\61\6E\64\20\74\68\65\20\73\69\67\6E\61\74\75\72\65\73\20\6F\66\20\69\74\73\20\65\78\70\6F\72\74\65\64\20\69\74\65\6D\73\29\2C\20\6F\72\20\6F\66\20\6F\6E\65\20\69\74\65\6D\20\6F\66\20\69\74\2E\22\2C\22\69\6E\70\75\74\53\63\68\65\6D\61\22\3A\7B\22\74\79\70\65\22\3A\22\6F\62\6A\65\63\74\22\2C\22\70\72\6F\70\65\72\74\69\65\73\22\3A\7B\22\66\69\6C\65\22\3A\7B\22\74\79\70\65\22\3A\22\73\74\72\69\6E\67\22\2C\22\64\65\73\63\72\69\70\74\69\6F\6E\22\3A\22\61\20\2E\6F\6C\61\6E\67\20\66\69\6C\65\2C\20\6F\72\20\61\20\73\74\64\20\6D\6F\64\75\6C\65\20\61\73\20\73\74\64\2F\6A\73\6F\6E\22\7D\2C\22\6E\61\6D\65\22\3A\7B\22\74\79\70\65\22\3A\22\73\74\72\69\6E\67\22\7D\7D\2C\22\72\65\71\75\69\72\65\64\22\3A\5B\22\66\69\6C\65\22\5D\7D\7D\2C\7B\22\6E\61\6D\65\22\3A\22\66\6F\72\6D\61\74\22\2C\22\64\65\73\63\72\69\70\74\69\6F\6E\22\3A\22\41\6E\20\6F\6C\61\6E\67\20\66\69\6C\65\20\69\6E\20\74\68\65\20\6C\61\6E\67\75\61\67\65\27\73\20\6F\6E\65\20\6C\61\79\6F\75\74\2C\20\61\73\20\6F\6C\61\6E\67\20\66\6F\72\6D\61\74\20\77\72\69\74\65\73\20\69\74\20\2D\20\72\65\74\75\72\6E\65\64\2C\20\74\68\65\20\66\69\6C\65\20\6C\65\66\74\20\75\6E\63\68\61\6E\67\65\64\2E\22\2C\22\69\6E\70\75\74\53\63\68\65\6D\61\22\3A\7B\22\74\79\70\65\22\3A\22\6F\62\6A\65\63\74\22\2C\22\70\72\6F\70\65\72\74\69\65\73\22\3A\7B\22\66\69\6C\65\22\3A\7B\22\74\79\70\65\22\3A\22\73\74\72\69\6E\67\22\7D\2C\22\74\65\78\74\22\3A\7B\22\74\79\70\65\22\3A\22\73\74\72\69\6E\67\22\2C\22\64\65\73\63\72\69\70\74\69\6F\6E\22\3A\22\74\68\65\20\74\65\78\74\20\74\6F\20\66\6F\72\6D\61\74\2C\20\69\66\20\6E\6F\74\20\74\68\65\20\66\69\6C\65\27\73\22\7D\7D\2C\22\72\65\71\75\69\72\65\64\22\3A\5B\22\66\69\6C\65\22\5D\7D\7D\2C\7B\22\6E\61\6D\65\22\3A\22\74\65\73\74\22\2C\22\64\65\73\63\72\69\70\74\69\6F\6E\22\3A\22\52\75\6E\20\61\6E\20\6F\6C\61\6E\67\20\66\69\6C\65\27\73\20\74\65\73\74\20\62\6C\6F\63\6B\73\2C\20\61\73\20\6F\6C\61\6E\67\20\74\65\73\74\20\64\6F\65\73\3A\20\65\61\63\68\20\74\65\73\74\27\73\20\6F\75\74\63\6F\6D\65\20\61\6E\64\20\77\68\61\74\20\74\68\65\20\72\75\6E\20\70\72\69\6E\74\65\64\2E\22\2C\22\69\6E\70\75\74\53\63\68\65\6D\61\22\3A\7B\22\74\79\70\65\22\3A\22\6F\62\6A\65\63\74\22\2C\22\70\72\6F\70\65\72\74\69\65\73\22\3A\7B\22\66\69\6C\65\22\3A\7B\22\74\79\70\65\22\3A\22\73\74\72\69\6E\67\22\7D\7D\2C\22\72\65\71\75\69\72\65\64\22\3A\5B\22\66\69\6C\65\22\5D\7D\7D\5D" }>, align 64
define dso_local i32 @compiler_2fmcp_2eServe(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca %"compiler/session:Reader"
  %l7 = alloca i1
  %l9 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca i32
  %l16 = alloca { i64, ptr }
  %l17 = alloca i1
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  call void @compiler_2fsession_2eIgnoreBrokenPipes()
  br label %bb1
bb1:
  %t1 = call %"compiler/session:Reader" @compiler_2fsession_3aReader_2ector(ptr %v0, i32 0)
  store %"compiler/session:Reader" %t1, ptr %l4
  br label %bb2
bb2:
  %t2 = load %"compiler/session:Reader", ptr %l4
  %t3 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/session:Reader" %t2, ptr %t3
  store ptr %t3, ptr %l2, !tbaa !29
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t7 = call i1 @compiler_2fsession_2ecompiler_2fsession_3aReader_2eFill(ptr %v0, ptr %t5)
  store i1 %t7, ptr %l7
  br label %bb4
bb4:
  %t8 = load i1, ptr %l7, !tbaa !21
  %t9 = xor i1 %t8, true
  br i1 %t9, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s1)
  br label %bb24
bb6:
  br label %bb7
bb7:
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t11 = load ptr, ptr %l2, !tbaa !29
  %t13 = call { i32, { i64, ptr } } @compiler_2fsession_2ecompiler_2fsession_3aReader_2eNextLine(ptr %v0, ptr %s2, ptr %t11)
  %t14 = extractvalue { i32, { i64, ptr } } %t13, 1
  %t15 = extractvalue { i32, { i64, ptr } } %t13, 0
  store i32 %t15, ptr %l12
  %t16 = icmp ne i32 %t15, 0
  br i1 %t16, label %bb10, label %ok.17
ok.17:
  store { i64, ptr } %t14, ptr %l11
  br label %bb9
bb9:
  %t18 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t18, ptr %l9, !tbaa !27
  br label %bb14
bb10:
  %t19 = load i32, ptr %l12, !tbaa !23
  %t20 = ashr i32 %t19, 16
  %t22 = icmp eq i32 %t20, 1
  br i1 %t22, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_b829b1c0f66d39b8_770b54290d51300c)
  unreachable
bb13:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %bb22
bb14:
  %t24 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t24, ptr %l3, !tbaa !27
  %t25 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t27 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %s2, { i64, ptr } %t25)
  store { i64, ptr } %t27, ptr %l16
  br label %bb15
bb15:
  %t28 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t29 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s2, ptr %s2, { i64, ptr } %t28, { i64, ptr } { i64 0, ptr @.d0 })
  store i1 %t29, ptr %l17
  br label %bb16
bb16:
  %t30 = load i1, ptr %l17, !tbaa !21
  br i1 %t30, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s2)
  br label %bb21
bb18:
  br label %bb19
bb19:
  %t31 = load { i64, ptr }, ptr %l3, !tbaa !27
  call void @compiler_2fmcp_2ehandle(ptr %s2, ptr %v0, ptr %v1, { i64, ptr } %t31, ptr %a0, { i64, ptr } %a1)
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s2)
  br label %bb21
bb21:
  br label %bb8
bb22:
  call void @__olang_scope_close(ptr %s1)
  br label %bb23
bb23:
  br label %bb3
bb24:
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fmcp_2eTools_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  %t1 = extractvalue { i64, ptr } { i64 94, ptr @.d1 }, 1
  %t2 = extractvalue { i64, ptr } { i64 94, ptr @.d1 }, 0
  %t3 = extractvalue { i64, ptr } { i64 112, ptr @.d2 }, 1
  %t4 = extractvalue { i64, ptr } { i64 112, ptr @.d2 }, 0
  %t5 = add i64 %t2, %t4
  %t6 = extractvalue { i64, ptr } { i64 112, ptr @.d3 }, 1
  %t7 = extractvalue { i64, ptr } { i64 112, ptr @.d3 }, 0
  %t8 = add i64 %t5, %t7
  %t9 = extractvalue { i64, ptr } { i64 94, ptr @.d4 }, 1
  %t10 = extractvalue { i64, ptr } { i64 94, ptr @.d4 }, 0
  %t11 = add i64 %t8, %t10
  %t12 = extractvalue { i64, ptr } { i64 99, ptr @.d5 }, 1
  %t13 = extractvalue { i64, ptr } { i64 99, ptr @.d5 }, 0
  %t14 = add i64 %t11, %t13
  %t15 = extractvalue { i64, ptr } { i64 73, ptr @.d6 }, 1
  %t16 = extractvalue { i64, ptr } { i64 73, ptr @.d6 }, 0
  %t17 = add i64 %t14, %t16
  %t18 = extractvalue { i64, ptr } { i64 105, ptr @.d7 }, 1
  %t19 = extractvalue { i64, ptr } { i64 105, ptr @.d7 }, 0
  %t20 = add i64 %t17, %t19
  %t21 = extractvalue { i64, ptr } { i64 109, ptr @.d8 }, 1
  %t22 = extractvalue { i64, ptr } { i64 109, ptr @.d8 }, 0
  %t23 = add i64 %t20, %t22
  %t24 = extractvalue { i64, ptr } { i64 109, ptr @.d9 }, 1
  %t25 = extractvalue { i64, ptr } { i64 109, ptr @.d9 }, 0
  %t26 = add i64 %t23, %t25
  %t27 = extractvalue { i64, ptr } { i64 87, ptr @.d10 }, 1
  %t28 = extractvalue { i64, ptr } { i64 87, ptr @.d10 }, 0
  %t29 = add i64 %t26, %t28
  %t30 = extractvalue { i64, ptr } { i64 105, ptr @.d11 }, 1
  %t31 = extractvalue { i64, ptr } { i64 105, ptr @.d11 }, 0
  %t32 = add i64 %t29, %t31
  %t33 = extractvalue { i64, ptr } { i64 22, ptr @.d12 }, 1
  %t34 = extractvalue { i64, ptr } { i64 22, ptr @.d12 }, 0
  %t35 = add i64 %t32, %t34
  %t36 = extractvalue { i64, ptr } { i64 106, ptr @.d13 }, 1
  %t37 = extractvalue { i64, ptr } { i64 106, ptr @.d13 }, 0
  %t38 = add i64 %t35, %t37
  %t39 = extractvalue { i64, ptr } { i64 96, ptr @.d14 }, 1
  %t40 = extractvalue { i64, ptr } { i64 96, ptr @.d14 }, 0
  %t41 = add i64 %t38, %t40
  %t42 = extractvalue { i64, ptr } { i64 92, ptr @.d15 }, 1
  %t43 = extractvalue { i64, ptr } { i64 92, ptr @.d15 }, 0
  %t44 = add i64 %t41, %t43
  %t45 = extractvalue { i64, ptr } { i64 33, ptr @.d16 }, 1
  %t46 = extractvalue { i64, ptr } { i64 33, ptr @.d16 }, 0
  %t47 = add i64 %t44, %t46
  %t48 = extractvalue { i64, ptr } { i64 104, ptr @.d17 }, 1
  %t49 = extractvalue { i64, ptr } { i64 104, ptr @.d17 }, 0
  %t50 = add i64 %t47, %t49
  %t51 = extractvalue { i64, ptr } { i64 96, ptr @.d18 }, 1
  %t52 = extractvalue { i64, ptr } { i64 96, ptr @.d18 }, 0
  %t53 = add i64 %t50, %t52
  %t54 = extractvalue { i64, ptr } { i64 90, ptr @.d19 }, 1
  %t55 = extractvalue { i64, ptr } { i64 90, ptr @.d19 }, 0
  %t56 = add i64 %t53, %t55
  %t57 = extractvalue { i64, ptr } { i64 22, ptr @.d20 }, 1
  %t58 = extractvalue { i64, ptr } { i64 22, ptr @.d20 }, 0
  %t59 = add i64 %t56, %t58
  %t60 = extractvalue { i64, ptr } { i64 103, ptr @.d21 }, 1
  %t61 = extractvalue { i64, ptr } { i64 103, ptr @.d21 }, 0
  %t62 = add i64 %t59, %t61
  %t63 = extractvalue { i64, ptr } { i64 98, ptr @.d22 }, 1
  %t64 = extractvalue { i64, ptr } { i64 98, ptr @.d22 }, 0
  %t65 = add i64 %t62, %t64
  %t66 = extractvalue { i64, ptr } { i64 22, ptr @.d23 }, 1
  %t67 = extractvalue { i64, ptr } { i64 22, ptr @.d23 }, 0
  %t68 = add i64 %t65, %t67
  %t69 = load ptr, ptr @__olang_prog_scope
  %t70 = call ptr @__olang_scope_alloc(ptr %t69, i64 %t68)
  call void @olang_textcopy(ptr %t70, ptr %t1, i64 %t2)
  %t71 = getelementptr i8, ptr %t70, i64 %t2
  call void @olang_textcopy(ptr %t71, ptr %t3, i64 %t4)
  %t72 = getelementptr i8, ptr %t71, i64 %t4
  call void @olang_textcopy(ptr %t72, ptr %t6, i64 %t7)
  %t73 = getelementptr i8, ptr %t72, i64 %t7
  call void @olang_textcopy(ptr %t73, ptr %t9, i64 %t10)
  %t74 = getelementptr i8, ptr %t73, i64 %t10
  call void @olang_textcopy(ptr %t74, ptr %t12, i64 %t13)
  %t75 = getelementptr i8, ptr %t74, i64 %t13
  call void @olang_textcopy(ptr %t75, ptr %t15, i64 %t16)
  %t76 = getelementptr i8, ptr %t75, i64 %t16
  call void @olang_textcopy(ptr %t76, ptr %t18, i64 %t19)
  %t77 = getelementptr i8, ptr %t76, i64 %t19
  call void @olang_textcopy(ptr %t77, ptr %t21, i64 %t22)
  %t78 = getelementptr i8, ptr %t77, i64 %t22
  call void @olang_textcopy(ptr %t78, ptr %t24, i64 %t25)
  %t79 = getelementptr i8, ptr %t78, i64 %t25
  call void @olang_textcopy(ptr %t79, ptr %t27, i64 %t28)
  %t80 = getelementptr i8, ptr %t79, i64 %t28
  call void @olang_textcopy(ptr %t80, ptr %t30, i64 %t31)
  %t81 = getelementptr i8, ptr %t80, i64 %t31
  call void @olang_textcopy(ptr %t81, ptr %t33, i64 %t34)
  %t82 = getelementptr i8, ptr %t81, i64 %t34
  call void @olang_textcopy(ptr %t82, ptr %t36, i64 %t37)
  %t83 = getelementptr i8, ptr %t82, i64 %t37
  call void @olang_textcopy(ptr %t83, ptr %t39, i64 %t40)
  %t84 = getelementptr i8, ptr %t83, i64 %t40
  call void @olang_textcopy(ptr %t84, ptr %t42, i64 %t43)
  %t85 = getelementptr i8, ptr %t84, i64 %t43
  call void @olang_textcopy(ptr %t85, ptr %t45, i64 %t46)
  %t86 = getelementptr i8, ptr %t85, i64 %t46
  call void @olang_textcopy(ptr %t86, ptr %t48, i64 %t49)
  %t87 = getelementptr i8, ptr %t86, i64 %t49
  call void @olang_textcopy(ptr %t87, ptr %t51, i64 %t52)
  %t88 = getelementptr i8, ptr %t87, i64 %t52
  call void @olang_textcopy(ptr %t88, ptr %t54, i64 %t55)
  %t89 = getelementptr i8, ptr %t88, i64 %t55
  call void @olang_textcopy(ptr %t89, ptr %t57, i64 %t58)
  %t90 = getelementptr i8, ptr %t89, i64 %t58
  call void @olang_textcopy(ptr %t90, ptr %t60, i64 %t61)
  %t91 = getelementptr i8, ptr %t90, i64 %t61
  call void @olang_textcopy(ptr %t91, ptr %t63, i64 %t64)
  %t92 = getelementptr i8, ptr %t91, i64 %t64
  call void @olang_textcopy(ptr %t92, ptr %t66, i64 %t67)
  %t93 = insertvalue { i64, ptr } undef, i64 %t68, 0
  %t94 = insertvalue { i64, ptr } %t93, ptr %t70, 1
  %t96 = load ptr, ptr @__olang_prog_scope
  %t97 = extractvalue { i64, ptr } %t94, 0
  %t98 = extractvalue { i64, ptr } %t94, 1
  %t99 = mul i64 %t97, 1
  %t100 = call ptr @__olang_scope_alloc(ptr %t96, i64 %t99)
  call void @llvm.memcpy.p0.p0.i64(ptr %t100, ptr %t98, i64 %t99, i1 false)
  %t101 = insertvalue { i64, ptr } undef, i64 %t97, 0
  %t102 = insertvalue { i64, ptr } %t101, ptr %t100, 1
  store { i64, ptr } %t102, ptr @G_2ecompiler_2fmcp_2eTools, !tbaa !27
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fmcp_2ecall(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, ptr %a1, ptr %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"std/os:Output"
  %l7 = alloca %"std/os:Output"
  %l8 = alloca i1
  %l9 = alloca { i64, ptr }
  %l11 = alloca { { i64, ptr }, i32 }
  %l12 = alloca { i64, ptr }
  %l13 = alloca i32
  %l15 = alloca { i64, ptr }
  %l17 = alloca i1
  %l19 = alloca i1
  %l20 = alloca { i64, ptr }
  %l21 = alloca %"std/os:Output"
  %l24 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca %"std/os:Output"
  %l27 = alloca i32
  %l30 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l38 = alloca i1
  %l39 = alloca i1
  %l41 = alloca i1
  %l43 = alloca { i64, ptr }
  %l44 = alloca %"std/os:Output"
  %l47 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l49 = alloca %"std/os:Output"
  %l50 = alloca i32
  %l53 = alloca { i64, ptr }
  %l60 = alloca { i64, ptr }
  %l62 = alloca i1
  %l64 = alloca i1
  %l66 = alloca i1
  %l68 = alloca i1
  %l70 = alloca i1
  %l72 = alloca i1
  %l74 = alloca i1
  %l79 = alloca { i64, ptr }
  %l81 = alloca i1
  %l85 = alloca { i64, ptr }
  %l86 = alloca ptr
  %l88 = alloca { i64, ptr }
  %l90 = alloca ptr
  %l91 = alloca i32
  %l96 = alloca ptr
  %l97 = alloca i1
  %l102 = alloca { i64, ptr }
  %l104 = alloca { i64, ptr }
  %l112 = alloca { { i64, ptr }, i32 }
  %l113 = alloca { i64, ptr }
  %l114 = alloca i64
  %l115 = alloca { i64, ptr }
  %l123 = alloca { i64, ptr }
  %l124 = alloca { i64, ptr }
  %l125 = alloca i64
  %l126 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t240 = alloca { i64, [2 x i64] }, align 8
  %t273 = alloca { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr }, align 8
  store { i64, ptr } %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = call { i64, ptr } @compiler_2fmcp_2estr(ptr %v1, ptr %s0, ptr %t1, { i64, ptr } { i64 4, ptr @.d24 })
  store { i64, ptr } %t3, ptr %l15
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t4, ptr %l4, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t7 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t5, { i64, ptr } { i64 4, ptr @.d25 })
  store i1 %t7, ptr %l17
  br label %bb2
bb2:
  %t8 = load i1, ptr %l17, !tbaa !21
  br i1 %t8, label %bb3, label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t9 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t11 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s1, { i64, ptr } %t9, { i64, ptr } { i64 0, ptr @.d26 })
  store i1 %t11, ptr %l19
  br label %bb5
bb4:
  br label %bb18
bb5:
  %t12 = load i1, ptr %l19, !tbaa !21
  br i1 %t12, label %bb6, label %bb7
bb6:
  %t13 = call { i64, ptr } @compiler_2fmcp_2etoolError(ptr %v4, ptr %v4, { i64, ptr } { i64 17, ptr @.d27 })
  store { i64, ptr } %t13, ptr %l20
  br label %bb8
bb7:
  br label %bb9
bb8:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t14 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t14, ptr %rv
  br label %ret
bb9:
  %t15 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t16 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t17 = mul i64 3, 16
  %t18 = call ptr @__olang_scope_alloc_zeroed(ptr %s1, i64 %t17)
  %t19 = insertvalue { i64, ptr } undef, i64 3, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  store { i64, ptr } %t20, ptr %l24, !tbaa !27
  %t22 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = getelementptr { i64, ptr }, ptr %t23, i64 0
  store { i64, ptr } %t15, ptr %t24, !tbaa !37
  %t25 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr { i64, ptr }, ptr %t26, i64 1
  store { i64, ptr } { i64 4, ptr @.d28 }, ptr %t27, !tbaa !37
  %t29 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = getelementptr { i64, ptr }, ptr %t30, i64 2
  store { i64, ptr } %t16, ptr %t31, !tbaa !37
  store { i64, ptr } { i64 0, ptr @.d29 }, ptr %l25, !tbaa !27
  %t32 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t33 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t34 = call { i32, %"std/os:Output" } @std_2fos_2eExec(ptr %s1, ptr %s1, ptr %s1, ptr %s1, { i64, ptr } %t32, { i64, ptr } %t33, i1 true, { i64, ptr } { i64 0, ptr @.d30 })
  %t35 = extractvalue { i32, %"std/os:Output" } %t34, 1
  %t36 = extractvalue { i32, %"std/os:Output" } %t34, 0
  store i32 %t36, ptr %l27
  %t37 = icmp ne i32 %t36, 0
  br i1 %t37, label %bb11, label %ok.38
ok.38:
  store %"std/os:Output" %t35, ptr %l26
  br label %bb10
bb10:
  %t39 = load %"std/os:Output", ptr %l26
  store %"std/os:Output" %t39, ptr %l21
  br label %bb16
bb11:
  %t40 = load i32, ptr %l27, !tbaa !23
  %t41 = ashr i32 %t40, 16
  %t43 = icmp eq i32 %t41, 1
  br i1 %t43, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_318d1c2fb8966e8f_49031d4c001ef363)
  unreachable
bb14:
  call void @__olang_ert_req_clear()
  %t45 = call { i64, ptr } @compiler_2fmcp_2etoolError(ptr %v4, ptr %v4, { i64, ptr } { i64 29, ptr @.d31 })
  store { i64, ptr } %t45, ptr %l30
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t46 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t46, ptr %rv
  br label %ret
bb16:
  %t47 = load %"std/os:Output", ptr %l21
  store %"std/os:Output" %t47, ptr %l5
  %t48 = getelementptr %"std/os:Output", ptr %l5, i32 0, i32 1
  %t49 = load { i64, ptr }, ptr %t48, !tbaa !27
  %t50 = getelementptr %"std/os:Output", ptr %l5, i32 0, i32 2
  %t51 = load { i64, ptr }, ptr %t50, !tbaa !27
  %t53 = extractvalue { i64, ptr } %t49, 1
  %t54 = extractvalue { i64, ptr } %t49, 0
  %t56 = extractvalue { i64, ptr } %t51, 1
  %t57 = extractvalue { i64, ptr } %t51, 0
  %t58 = add i64 %t54, %t57
  %t59 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t58)
  call void @olang_textcopy(ptr %t59, ptr %t53, i64 %t54)
  %t60 = getelementptr i8, ptr %t59, i64 %t54
  call void @olang_textcopy(ptr %t60, ptr %t56, i64 %t57)
  %t61 = insertvalue { i64, ptr } undef, i64 %t58, 0
  %t62 = insertvalue { i64, ptr } %t61, ptr %t59, 1
  %t64 = extractvalue { i64, ptr } %t62, 0
  %t65 = extractvalue { i64, ptr } %t62, 1
  %t66 = mul i64 %t64, 1
  %t67 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t66)
  call void @llvm.memcpy.p0.p0.i64(ptr %t67, ptr %t65, i64 %t66, i1 false)
  %t68 = insertvalue { i64, ptr } undef, i64 %t64, 0
  %t69 = insertvalue { i64, ptr } %t68, ptr %t67, 1
  %t70 = getelementptr %"std/os:Output", ptr %l5, i32 0, i32 0
  %t71 = load i32, ptr %t70, !tbaa !23
  %t74 = call { i64, ptr } @compiler_2fmcp_2etestResult(ptr %v4, ptr %v4, { i64, ptr } %t69, i32 %t71)
  store { i64, ptr } %t74, ptr %l36
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t75 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t75, ptr %rv
  br label %ret
bb18:
  %t76 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t78 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t76, { i64, ptr } { i64 7, ptr @.d32 })
  store i1 %t78, ptr %l38
  br label %bb19
bb19:
  %t79 = load i1, ptr %l38, !tbaa !21
  br i1 %t79, label %bb20, label %bb21
bb20:
  %t80 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t82 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t80, { i64, ptr } { i64 0, ptr @.d33 })
  store i1 %t82, ptr %l41
  br label %bb22
bb21:
  store i1 false, ptr %l39, !tbaa !21
  br label %bb23
bb22:
  %t83 = load i1, ptr %l41, !tbaa !21
  store i1 %t83, ptr %l39, !tbaa !21
  br label %bb23
bb23:
  %t84 = load i1, ptr %l39, !tbaa !21
  br i1 %t84, label %bb24, label %bb25
bb24:
  store %olang.scope zeroinitializer, ptr %s5
  %t85 = load ptr, ptr %l1, !tbaa !29
  %t87 = call { i64, ptr } @compiler_2fmcp_2estr(ptr %v1, ptr %s5, ptr %t85, { i64, ptr } { i64 4, ptr @.d34 })
  store { i64, ptr } %t87, ptr %l43
  br label %bb26
bb25:
  br label %bb35
bb26:
  %t88 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t89 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t91 = mul i64 3, 16
  %t92 = call ptr @__olang_scope_alloc_zeroed(ptr %s5, i64 %t91)
  %t93 = insertvalue { i64, ptr } undef, i64 3, 0
  %t94 = insertvalue { i64, ptr } %t93, ptr %t92, 1
  store { i64, ptr } %t94, ptr %l47, !tbaa !27
  %t96 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !27
  %t98 = getelementptr { i64, ptr }, ptr %t97, i64 0
  store { i64, ptr } %t89, ptr %t98, !tbaa !37
  %t99 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !27
  %t101 = getelementptr { i64, ptr }, ptr %t100, i64 1
  store { i64, ptr } { i64 7, ptr @.d35 }, ptr %t101, !tbaa !37
  %t103 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t104 = load ptr, ptr %t103, !tbaa !27
  %t105 = getelementptr { i64, ptr }, ptr %t104, i64 2
  store { i64, ptr } %t88, ptr %t105, !tbaa !37
  store { i64, ptr } { i64 0, ptr @.d36 }, ptr %l48, !tbaa !27
  %t106 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t107 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t108 = call { i32, %"std/os:Output" } @std_2fos_2eExec(ptr %s5, ptr %s5, ptr %s5, ptr %s5, { i64, ptr } %t106, { i64, ptr } %t107, i1 true, { i64, ptr } { i64 0, ptr @.d37 })
  %t109 = extractvalue { i32, %"std/os:Output" } %t108, 1
  %t110 = extractvalue { i32, %"std/os:Output" } %t108, 0
  store i32 %t110, ptr %l50
  %t111 = icmp ne i32 %t110, 0
  br i1 %t111, label %bb28, label %ok.112
ok.112:
  store %"std/os:Output" %t109, ptr %l49
  br label %bb27
bb27:
  %t113 = load %"std/os:Output", ptr %l49
  store %"std/os:Output" %t113, ptr %l44
  br label %bb33
bb28:
  %t114 = load i32, ptr %l50, !tbaa !23
  %t115 = ashr i32 %t114, 16
  %t117 = icmp eq i32 %t115, 1
  br i1 %t117, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  call void @__olang_check_failed(ptr @olang_loc_f9d9ba2b38c78a4e_acdef970c68e1562)
  unreachable
bb31:
  call void @__olang_ert_req_clear()
  %t119 = call { i64, ptr } @compiler_2fmcp_2etoolError(ptr %v4, ptr %v4, { i64, ptr } { i64 29, ptr @.d38 })
  store { i64, ptr } %t119, ptr %l53
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t120 = load { i64, ptr }, ptr %l53, !tbaa !27
  store { i64, ptr } %t120, ptr %rv
  br label %ret
bb33:
  %t121 = load %"std/os:Output", ptr %l44
  store %"std/os:Output" %t121, ptr %l7
  %t122 = getelementptr %"std/os:Output", ptr %l7, i32 0, i32 1
  %t123 = load { i64, ptr }, ptr %t122, !tbaa !27
  %t124 = getelementptr %"std/os:Output", ptr %l7, i32 0, i32 2
  %t125 = load { i64, ptr }, ptr %t124, !tbaa !27
  %t127 = extractvalue { i64, ptr } %t123, 1
  %t128 = extractvalue { i64, ptr } %t123, 0
  %t130 = extractvalue { i64, ptr } %t125, 1
  %t131 = extractvalue { i64, ptr } %t125, 0
  %t132 = add i64 %t128, %t131
  %t133 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t132)
  call void @olang_textcopy(ptr %t133, ptr %t127, i64 %t128)
  %t134 = getelementptr i8, ptr %t133, i64 %t128
  call void @olang_textcopy(ptr %t134, ptr %t130, i64 %t131)
  %t135 = insertvalue { i64, ptr } undef, i64 %t132, 0
  %t136 = insertvalue { i64, ptr } %t135, ptr %t133, 1
  %t138 = extractvalue { i64, ptr } %t136, 0
  %t139 = extractvalue { i64, ptr } %t136, 1
  %t140 = mul i64 %t138, 1
  %t141 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t140)
  call void @llvm.memcpy.p0.p0.i64(ptr %t141, ptr %t139, i64 %t140, i1 false)
  %t142 = insertvalue { i64, ptr } undef, i64 %t138, 0
  %t143 = insertvalue { i64, ptr } %t142, ptr %t141, 1
  %t144 = getelementptr %"std/os:Output", ptr %l7, i32 0, i32 0
  %t145 = load i32, ptr %t144, !tbaa !23
  %t147 = icmp ne i32 %t145, 0
  %t150 = call { i64, ptr } @compiler_2fmcp_2etextResult(ptr %v4, ptr %v4, { i64, ptr } %t143, i1 %t147)
  store { i64, ptr } %t150, ptr %l60
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t151 = load { i64, ptr }, ptr %l60, !tbaa !27
  store { i64, ptr } %t151, ptr %rv
  br label %ret
bb35:
  %t152 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t154 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t152, { i64, ptr } { i64 5, ptr @.d39 })
  store i1 %t154, ptr %l62
  br label %bb36
bb36:
  %t155 = load i1, ptr %l62, !tbaa !21
  %t156 = xor i1 %t155, true
  br i1 %t156, label %bb37, label %bb38
bb37:
  %t158 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t160 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t158, { i64, ptr } { i64 7, ptr @.d40 })
  store i1 %t160, ptr %l66
  br label %bb39
bb38:
  store i1 false, ptr %l64, !tbaa !21
  br label %bb40
bb39:
  %t161 = load i1, ptr %l66, !tbaa !21
  %t162 = xor i1 %t161, true
  store i1 %t162, ptr %l64, !tbaa !21
  br label %bb40
bb40:
  %t164 = load i1, ptr %l64, !tbaa !21
  br i1 %t164, label %bb41, label %bb42
bb41:
  %t165 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t167 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t165, { i64, ptr } { i64 3, ptr @.d41 })
  store i1 %t167, ptr %l70
  br label %bb43
bb42:
  store i1 false, ptr %l68, !tbaa !21
  br label %bb44
bb43:
  %t168 = load i1, ptr %l70, !tbaa !21
  %t169 = xor i1 %t168, true
  store i1 %t169, ptr %l68, !tbaa !21
  br label %bb44
bb44:
  %t171 = load i1, ptr %l68, !tbaa !21
  br i1 %t171, label %bb45, label %bb46
bb45:
  %t172 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t174 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t172, { i64, ptr } { i64 6, ptr @.d42 })
  store i1 %t174, ptr %l74
  br label %bb47
bb46:
  store i1 false, ptr %l72, !tbaa !21
  br label %bb48
bb47:
  %t175 = load i1, ptr %l74, !tbaa !21
  %t176 = xor i1 %t175, true
  store i1 %t176, ptr %l72, !tbaa !21
  br label %bb48
bb48:
  %t178 = load i1, ptr %l72, !tbaa !21
  br i1 %t178, label %bb49, label %bb50
bb49:
  %t179 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t180 = extractvalue { i64, ptr } { i64 8, ptr @.d43 }, 1
  %t181 = extractvalue { i64, ptr } { i64 8, ptr @.d43 }, 0
  %t183 = extractvalue { i64, ptr } %t179, 1
  %t184 = extractvalue { i64, ptr } %t179, 0
  %t185 = add i64 %t181, %t184
  %t186 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t185)
  call void @olang_textcopy(ptr %t186, ptr %t180, i64 %t181)
  %t187 = getelementptr i8, ptr %t186, i64 %t181
  call void @olang_textcopy(ptr %t187, ptr %t183, i64 %t184)
  %t188 = insertvalue { i64, ptr } undef, i64 %t185, 0
  %t189 = insertvalue { i64, ptr } %t188, ptr %t186, 1
  %t191 = extractvalue { i64, ptr } %t189, 0
  %t192 = extractvalue { i64, ptr } %t189, 1
  %t193 = mul i64 %t191, 1
  %t194 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t193)
  call void @llvm.memcpy.p0.p0.i64(ptr %t194, ptr %t192, i64 %t193, i1 false)
  %t195 = insertvalue { i64, ptr } undef, i64 %t191, 0
  %t196 = insertvalue { i64, ptr } %t195, ptr %t194, 1
  %t198 = call { i64, ptr } @compiler_2fmcp_2etoolError(ptr %v4, ptr %v4, { i64, ptr } %t196)
  store { i64, ptr } %t198, ptr %l79
  br label %bb51
bb50:
  br label %bb52
bb51:
  call void @__olang_scope_close(ptr %s0)
  %t199 = load { i64, ptr }, ptr %l79, !tbaa !27
  store { i64, ptr } %t199, ptr %rv
  br label %ret
bb52:
  %t200 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t202 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t200, { i64, ptr } { i64 0, ptr @.d44 })
  store i1 %t202, ptr %l81
  br label %bb53
bb53:
  %t203 = load i1, ptr %l81, !tbaa !21
  br i1 %t203, label %bb54, label %bb55
bb54:
  %t204 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t206 = extractvalue { i64, ptr } %t204, 1
  %t207 = extractvalue { i64, ptr } %t204, 0
  %t208 = extractvalue { i64, ptr } { i64 13, ptr @.d45 }, 1
  %t209 = extractvalue { i64, ptr } { i64 13, ptr @.d45 }, 0
  %t210 = add i64 %t207, %t209
  %t211 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t210)
  call void @olang_textcopy(ptr %t211, ptr %t206, i64 %t207)
  %t212 = getelementptr i8, ptr %t211, i64 %t207
  call void @olang_textcopy(ptr %t212, ptr %t208, i64 %t209)
  %t213 = insertvalue { i64, ptr } undef, i64 %t210, 0
  %t214 = insertvalue { i64, ptr } %t213, ptr %t211, 1
  %t216 = extractvalue { i64, ptr } %t214, 0
  %t217 = extractvalue { i64, ptr } %t214, 1
  %t218 = mul i64 %t216, 1
  %t219 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t218)
  call void @llvm.memcpy.p0.p0.i64(ptr %t219, ptr %t217, i64 %t218, i1 false)
  %t220 = insertvalue { i64, ptr } undef, i64 %t216, 0
  %t221 = insertvalue { i64, ptr } %t220, ptr %t219, 1
  %t223 = call { i64, ptr } @compiler_2fmcp_2etoolError(ptr %v4, ptr %v4, { i64, ptr } %t221)
  store { i64, ptr } %t223, ptr %l85
  br label %bb56
bb55:
  br label %bb57
bb56:
  call void @__olang_scope_close(ptr %s0)
  %t224 = load { i64, ptr }, ptr %l85, !tbaa !27
  store { i64, ptr } %t224, ptr %rv
  br label %ret
bb57:
  %t225 = load ptr, ptr %l1, !tbaa !29
  store { i64, ptr } { i64 4, ptr @.d46 }, ptr %l88, !tbaa !27
  %t226 = load { i64, ptr }, ptr %l88, !tbaa !27
  %t229 = call { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAt_3cstd_2fprelude_2ftext_3aString_3e(ptr %v1, ptr %t225, { i64, ptr } %t226)
  %t230 = extractvalue { i32, ptr } %t229, 1
  %t231 = extractvalue { i32, ptr } %t229, 0
  store i32 %t231, ptr %l91
  %t232 = icmp ne i32 %t231, 0
  br i1 %t232, label %bb59, label %ok.233
ok.233:
  store ptr %t230, ptr %l90
  br label %bb58
bb58:
  %t234 = load ptr, ptr %l90, !tbaa !29
  store ptr %t234, ptr %l86, !tbaa !29
  br label %bb63
bb59:
  %t235 = load i32, ptr %l91, !tbaa !23
  %t236 = ashr i32 %t235, 16
  %t238 = icmp eq i32 %t236, 1
  br i1 %t238, label %bb60, label %bb61
bb60:
  br label %bb62
bb61:
  call void @__olang_check_failed(ptr @olang_loc_167c2e8a866de005_69a10464275f2959)
  unreachable
bb62:
  call void @__olang_ert_req_clear()
  store { i64, [2 x i64] } zeroinitializer, ptr %t240
  %t241 = getelementptr { i64, [2 x i64] }, ptr %t240, i32 0, i32 0
  store i64 0, ptr %t241
  %t242 = load { i64, [2 x i64] }, ptr %t240
  %t244 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 24, i64 8)
  store { i64, [2 x i64] } %t242, ptr %t244
  store ptr %t244, ptr %l86, !tbaa !29
  br label %bb63
bb63:
  %t246 = load ptr, ptr %l86, !tbaa !29
  store ptr %t246, ptr %l96, !tbaa !29
  store i1 false, ptr %l97, !tbaa !21
  %t247 = load ptr, ptr %l96, !tbaa !29
  %t248 = icmp ne ptr %t247, null
  br i1 %t248, label %bb64, label %bb65
bb64:
  %t250 = load ptr, ptr %l96, !tbaa !29
  %t251 = load i64, ptr %t250
  %t253 = icmp eq i64 %t251, 0
  store i1 %t253, ptr %l97, !tbaa !21
  br label %bb65
bb65:
  %t254 = load i1, ptr %l97, !tbaa !21
  %t255 = xor i1 %t254, true
  store i1 %t255, ptr %l8, !tbaa !21
  %t257 = load ptr, ptr %l1, !tbaa !29
  %t259 = call { i64, ptr } @compiler_2fmcp_2estr(ptr %v1, ptr %s0, ptr %t257, { i64, ptr } { i64 4, ptr @.d47 })
  store { i64, ptr } %t259, ptr %l102
  br label %bb66
bb66:
  %t260 = load { i64, ptr }, ptr %l102, !tbaa !27
  store { i64, ptr } %t260, ptr %l9, !tbaa !27
  %t261 = load ptr, ptr %l1, !tbaa !29
  %t263 = call { i64, ptr } @compiler_2fmcp_2estr(ptr %v1, ptr %s0, ptr %t261, { i64, ptr } { i64 4, ptr @.d48 })
  store { i64, ptr } %t263, ptr %l104
  br label %bb67
bb67:
  %t264 = load { i64, ptr }, ptr %l104, !tbaa !27
  %t265 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t266 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t267 = load i1, ptr %l8, !tbaa !21
  %t268 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t271 = getelementptr { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr }, ptr null, i32 1
  %t272 = ptrtoint ptr %t271 to i64
  %t274 = getelementptr { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %t273, i32 0, i32 0
  store { i64, ptr } %t265, ptr %t274, !tbaa !28
  %t276 = getelementptr { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %t273, i32 0, i32 1
  store { i64, ptr } %t266, ptr %t276, !tbaa !28
  %t278 = getelementptr { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %t273, i32 0, i32 2
  store i1 %t267, ptr %t278, !tbaa !28
  %t280 = getelementptr { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %t273, i32 0, i32 3
  store { i64, ptr } %t268, ptr %t280, !tbaa !28
  %t282 = getelementptr { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %t273, i32 0, i32 4
  store { i64, ptr } %t264, ptr %t282, !tbaa !28
  %t284 = getelementptr { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %t273, i32 0, i32 5
  store ptr %a2, ptr %t284, !tbaa !28
  call void @__olang_scope_escape(ptr %v0)
  %t286 = getelementptr { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %t273, i32 0, i32 6
  store ptr %v0, ptr %t286, !tbaa !28
  call void @__olang_scope_escape(ptr %v1)
  %t287 = getelementptr { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %t273, i32 0, i32 7
  store ptr %v1, ptr %t287, !tbaa !28
  call void @__olang_scope_escape(ptr %v1)
  %t288 = getelementptr { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %t273, i32 0, i32 8
  store ptr %v1, ptr %t288, !tbaa !28
  call void @__olang_scope_escape(ptr %v1)
  %t289 = getelementptr { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %t273, i32 0, i32 9
  store ptr %v1, ptr %t289, !tbaa !28
  call void @__olang_scope_escape(ptr %v2)
  %t290 = getelementptr { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %t273, i32 0, i32 10
  store ptr %v2, ptr %t290, !tbaa !28
  %t291 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_49, 0
  %t292 = insertvalue { ptr, ptr } %t291, ptr %t273, 1
  %t294 = extractvalue { ptr, ptr } %t292, 0
  %t295 = extractvalue { ptr, ptr } %t292, 1
  %t296 = call { { i64, ptr }, i32 } @compiler_2fsession_2eChildOutput(ptr %s0, ptr %s0, ptr %t294, ptr %t295)
  store { { i64, ptr }, i32 } %t296, ptr %l112
  br label %bb68
bb68:
  %t297 = load { { i64, ptr }, i32 }, ptr %l112
  store { { i64, ptr }, i32 } %t297, ptr %l11
  %t298 = getelementptr { { i64, ptr }, i32 }, ptr %l11, i32 0, i32 0
  %t299 = load { i64, ptr }, ptr %t298, !tbaa !27
  store { i64, ptr } %t299, ptr %l113, !tbaa !27
  %t300 = load { i64, ptr }, ptr %l113, !tbaa !27
  %t301 = extractvalue { i64, ptr } %t300, 0
  store i64 %t301, ptr %l114, !tbaa !24
  %t302 = load i64, ptr %l114, !tbaa !24
  %t303 = mul i64 %t302, 1
  %t304 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t303)
  %t305 = insertvalue { i64, ptr } undef, i64 %t302, 0
  %t306 = insertvalue { i64, ptr } %t305, ptr %t304, 1
  store { i64, ptr } %t306, ptr %l115, !tbaa !27
  %t307 = getelementptr { i64, ptr }, ptr %l115, i32 0, i32 1
  %t308 = load ptr, ptr %t307, !tbaa !27
  %t309 = getelementptr { i64, ptr }, ptr %l113, i32 0, i32 1
  %t310 = load ptr, ptr %t309, !tbaa !27
  %t311 = load i64, ptr %l114, !tbaa !24
  %t312 = mul i64 %t311, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t308, ptr %t310, i64 %t312, i1 false)
  %t313 = load { i64, ptr }, ptr %l115, !tbaa !27
  store { i64, ptr } %t313, ptr %l12, !tbaa !27
  %t314 = getelementptr { { i64, ptr }, i32 }, ptr %l11, i32 0, i32 1
  %t315 = load i32, ptr %t314, !tbaa !23
  store i32 %t315, ptr %l13, !tbaa !23
  %t317 = load i32, ptr %l13, !tbaa !23
  %t319 = icmp ne i32 %t317, 0
  br i1 %t319, label %bb69, label %bb70
bb69:
  %t321 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t322 = load i32, ptr %l13, !tbaa !23
  %t323 = extractvalue { i64, ptr } { i64 33, ptr @.d50 }, 1
  %t324 = extractvalue { i64, ptr } { i64 33, ptr @.d50 }, 0
  %t326 = extractvalue { i64, ptr } %t321, 1
  %t327 = extractvalue { i64, ptr } %t321, 0
  %t328 = add i64 %t324, %t327
  %t329 = extractvalue { i64, ptr } { i64 9, ptr @.d51 }, 1
  %t330 = extractvalue { i64, ptr } { i64 9, ptr @.d51 }, 0
  %t331 = add i64 %t328, %t330
  %t333 = sext i32 %t322 to i64
  %t334 = call i64 @__olang_fmt_i64(ptr null, i64 %t333)
  %t335 = add i64 %t331, %t334
  %t336 = extractvalue { i64, ptr } { i64 25, ptr @.d52 }, 1
  %t337 = extractvalue { i64, ptr } { i64 25, ptr @.d52 }, 0
  %t338 = add i64 %t335, %t337
  %t339 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t338)
  call void @olang_textcopy(ptr %t339, ptr %t323, i64 %t324)
  %t340 = getelementptr i8, ptr %t339, i64 %t324
  call void @olang_textcopy(ptr %t340, ptr %t326, i64 %t327)
  %t341 = getelementptr i8, ptr %t340, i64 %t327
  call void @olang_textcopy(ptr %t341, ptr %t329, i64 %t330)
  %t342 = getelementptr i8, ptr %t341, i64 %t330
  %t343 = call i64 @__olang_fmt_i64(ptr %t342, i64 %t333)
  %t344 = getelementptr i8, ptr %t342, i64 %t334
  call void @olang_textcopy(ptr %t344, ptr %t336, i64 %t337)
  %t345 = insertvalue { i64, ptr } undef, i64 %t338, 0
  %t346 = insertvalue { i64, ptr } %t345, ptr %t339, 1
  %t348 = extractvalue { i64, ptr } %t346, 0
  %t349 = extractvalue { i64, ptr } %t346, 1
  %t350 = mul i64 %t348, 1
  %t351 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t350)
  call void @llvm.memcpy.p0.p0.i64(ptr %t351, ptr %t349, i64 %t350, i1 false)
  %t352 = insertvalue { i64, ptr } undef, i64 %t348, 0
  %t353 = insertvalue { i64, ptr } %t352, ptr %t351, 1
  %t355 = call { i64, ptr } @compiler_2fmcp_2etoolError(ptr %v4, ptr %v4, { i64, ptr } %t353)
  store { i64, ptr } %t355, ptr %l123
  br label %bb71
bb70:
  br label %bb72
bb71:
  call void @__olang_scope_close(ptr %s0)
  %t356 = load { i64, ptr }, ptr %l123, !tbaa !27
  store { i64, ptr } %t356, ptr %rv
  br label %ret
bb72:
  %t357 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t357, ptr %l124, !tbaa !27
  %t358 = load { i64, ptr }, ptr %l124, !tbaa !27
  %t359 = extractvalue { i64, ptr } %t358, 0
  store i64 %t359, ptr %l125, !tbaa !24
  %t360 = load i64, ptr %l125, !tbaa !24
  %t361 = mul i64 %t360, 1
  %t362 = call ptr @__olang_scope_alloc_zeroed(ptr %v4, i64 %t361)
  %t363 = insertvalue { i64, ptr } undef, i64 %t360, 0
  %t364 = insertvalue { i64, ptr } %t363, ptr %t362, 1
  store { i64, ptr } %t364, ptr %l126, !tbaa !27
  %t365 = getelementptr { i64, ptr }, ptr %l126, i32 0, i32 1
  %t366 = load ptr, ptr %t365, !tbaa !27
  %t367 = getelementptr { i64, ptr }, ptr %l124, i32 0, i32 1
  %t368 = load ptr, ptr %t367, !tbaa !27
  %t369 = load i64, ptr %l125, !tbaa !24
  %t370 = mul i64 %t369, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t366, ptr %t368, i64 %t370, i1 false)
  %t371 = load { i64, ptr }, ptr %l126, !tbaa !27
  store { i64, ptr } %t371, ptr %l124, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t372 = load { i64, ptr }, ptr %l124, !tbaa !27
  store { i64, ptr } %t372, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fmcp_2echeckResult(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l3 = alloca %"std/prelude/text:StringBuilder"
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca %"compiler/diag:Item"
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l19 = alloca %"compiler/diag:Item"
  %l20 = alloca { i64, ptr }
  %l21 = alloca %"std/prelude/text:StringBuilder"
  %l23 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l24 = alloca %"std/prelude/text:StringBuilder"
  %l27 = alloca i64
  %l31 = alloca i64
  %l34 = alloca i64
  %l54 = alloca %"compiler/diag:Item"
  %l70 = alloca i64
  %l74 = alloca i64
  %l77 = alloca i64
  %l97 = alloca %"compiler/diag:Item"
  %l120 = alloca { i64, ptr }
  %l122 = alloca { i64, ptr }
  %l124 = alloca { i64, ptr }
  %l127 = alloca %"std/prelude/text:StringBuilder"
  %l131 = alloca ptr
  %l133 = alloca { i64, ptr }
  %l137 = alloca { i64, ptr }
  %l138 = alloca { i64, ptr }
  %l139 = alloca i64
  %l140 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eItems(ptr %v1, ptr %s0, ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %l23
  br label %bb1
bb1:
  %t4 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l23
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t4, ptr %l2
  %t5 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t5, ptr %l24
  br label %bb2
bb2:
  %t6 = load %"std/prelude/text:StringBuilder", ptr %l24
  store %"std/prelude/text:StringBuilder" %t6, ptr %l3
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l3, { i64, ptr } { i64 16, ptr @.d53 })
  br label %bb3
bb3:
  store i64 0, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  %t9 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3aItem_3e_2eLen_3ccompiler_2fdiag_3aItem_3e(ptr %s0, ptr %l2)
  store i64 %t9, ptr %l27
  br label %bb4
bb4:
  %t10 = load i64, ptr %l27, !tbaa !24
  store i64 %t10, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t11 = load i64, ptr %l6, !tbaa !24
  %t12 = load i64, ptr %l5, !tbaa !24
  %t15 = icmp sgt i64 %t11, %t12
  br i1 %t15, label %bb5, label %bb6
bb5:
  %t17 = load i64, ptr %l7, !tbaa !24
  %t19 = icmp sgt i64 %t17, 0
  br i1 %t19, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb10
bb7:
  %t21 = load i64, ptr %l6, !tbaa !24
  %t22 = load i64, ptr %l5, !tbaa !24
  %t25 = sub i64 %t21, %t22
  %t26 = load i64, ptr %l7, !tbaa !24
  %t29 = add i64 %t25, %t26
  %t31 = sub i64 %t29, 1
  %t32 = load i64, ptr %l7, !tbaa !24
  %t35 = sdiv i64 %t31, %t32
  store i64 %t35, ptr %l34, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l34, !tbaa !24
  br label %bb9
bb9:
  %t37 = load i64, ptr %l34, !tbaa !24
  store i64 %t37, ptr %l31, !tbaa !24
  br label %bb10
bb10:
  %t38 = load i64, ptr %l31, !tbaa !24
  store i64 %t38, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s2
  %t39 = load i64, ptr %l9, !tbaa !24
  %t40 = load i64, ptr %l8, !tbaa !24
  %t43 = icmp slt i64 %t39, %t40
  %t45 = xor i1 %t43, true
  br i1 %t45, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %bb50
bb13:
  br label %bb14
bb14:
  %t47 = load i64, ptr %l5, !tbaa !24
  %t48 = load i64, ptr %l9, !tbaa !24
  %t49 = load i64, ptr %l7, !tbaa !24
  %t52 = mul i64 %t48, %t49
  %t55 = add i64 %t47, %t52
  store i64 %t55, ptr %l10, !tbaa !24
  %t57 = load i64, ptr %l10, !tbaa !24
  %t60 = call %"compiler/diag:Item" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3aItem_3e_2eAt_3ccompiler_2fdiag_3aItem_3e(ptr %s0, ptr %s0, ptr %l2, i64 %t57)
  store %"compiler/diag:Item" %t60, ptr %l54
  br label %bb15
bb15:
  %t61 = load %"compiler/diag:Item", ptr %l54
  store %"compiler/diag:Item" %t61, ptr %l11
  %t62 = getelementptr %"compiler/diag:Item", ptr %l11, i32 0, i32 0
  %t63 = load i1, ptr %t62, !tbaa !21
  %t65 = xor i1 %t63, true
  br i1 %t65, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s2)
  br label %bb49
bb17:
  br label %bb18
bb18:
  %t67 = load i64, ptr %l4, !tbaa !24
  %t69 = icmp sgt i64 %t67, 0
  br i1 %t69, label %bb19, label %bb20
bb19:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l3, i8 44)
  br label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb22
bb22:
  %t72 = load i64, ptr %l4, !tbaa !24
  %t74 = add i64 %t72, 1
  store i64 %t74, ptr %l4, !tbaa !24
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t77 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fmcp_2elocated(ptr %s0, ptr %v0, ptr %v1, ptr %s0, ptr %l3, ptr %t76, ptr %t77, ptr %l11)
  br label %bb23
bb23:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %l3, { i64, ptr } { i64 10, ptr @.d54 })
  br label %bb24
bb24:
  store i64 0, ptr %l12, !tbaa !24
  %t83 = load i64, ptr %l10, !tbaa !24
  %t85 = add i64 %t83, 1
  store i64 %t85, ptr %l13, !tbaa !24
  %t88 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3aItem_3e_2eLen_3ccompiler_2fdiag_3aItem_3e(ptr %s0, ptr %l2)
  store i64 %t88, ptr %l70
  br label %bb25
bb25:
  %t89 = load i64, ptr %l70, !tbaa !24
  store i64 %t89, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t90 = load i64, ptr %l14, !tbaa !24
  %t91 = load i64, ptr %l13, !tbaa !24
  %t94 = icmp sgt i64 %t90, %t91
  br i1 %t94, label %bb26, label %bb27
bb26:
  %t96 = load i64, ptr %l15, !tbaa !24
  %t98 = icmp sgt i64 %t96, 0
  br i1 %t98, label %bb28, label %bb29
bb27:
  store i64 0, ptr %l74, !tbaa !24
  br label %bb31
bb28:
  %t100 = load i64, ptr %l14, !tbaa !24
  %t101 = load i64, ptr %l13, !tbaa !24
  %t104 = sub i64 %t100, %t101
  %t105 = load i64, ptr %l15, !tbaa !24
  %t108 = add i64 %t104, %t105
  %t110 = sub i64 %t108, 1
  %t111 = load i64, ptr %l15, !tbaa !24
  %t114 = sdiv i64 %t110, %t111
  store i64 %t114, ptr %l77, !tbaa !24
  br label %bb30
bb29:
  store i64 0, ptr %l77, !tbaa !24
  br label %bb30
bb30:
  %t116 = load i64, ptr %l77, !tbaa !24
  store i64 %t116, ptr %l74, !tbaa !24
  br label %bb31
bb31:
  %t117 = load i64, ptr %l74, !tbaa !24
  store i64 %t117, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb32
bb32:
  store %olang.scope zeroinitializer, ptr %s6
  %t118 = load i64, ptr %l17, !tbaa !24
  %t119 = load i64, ptr %l16, !tbaa !24
  %t122 = icmp slt i64 %t118, %t119
  %t124 = xor i1 %t122, true
  br i1 %t124, label %bb33, label %bb34
bb33:
  call void @__olang_scope_close(ptr %s6)
  br label %bb47
bb34:
  br label %bb35
bb35:
  %t126 = load i64, ptr %l13, !tbaa !24
  %t127 = load i64, ptr %l17, !tbaa !24
  %t128 = load i64, ptr %l15, !tbaa !24
  %t131 = mul i64 %t127, %t128
  %t134 = add i64 %t126, %t131
  %t139 = call %"compiler/diag:Item" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3aItem_3e_2eAt_3ccompiler_2fdiag_3aItem_3e(ptr %s0, ptr %s0, ptr %l2, i64 %t134)
  store %"compiler/diag:Item" %t139, ptr %l97
  br label %bb36
bb36:
  %t140 = load %"compiler/diag:Item", ptr %l97
  store %"compiler/diag:Item" %t140, ptr %l19
  %t141 = getelementptr %"compiler/diag:Item", ptr %l19, i32 0, i32 0
  %t142 = load i1, ptr %t141, !tbaa !21
  br i1 %t142, label %bb37, label %bb38
bb37:
  call void @__olang_scope_close(ptr %s6)
  br label %bb47
bb38:
  br label %bb39
bb39:
  %t144 = load i64, ptr %l12, !tbaa !24
  %t146 = icmp sgt i64 %t144, 0
  br i1 %t146, label %bb40, label %bb41
bb40:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l3, i8 44)
  br label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb43
bb43:
  %t149 = load i64, ptr %l12, !tbaa !24
  %t151 = add i64 %t149, 1
  store i64 %t151, ptr %l12, !tbaa !24
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t154 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fmcp_2elocated(ptr %s0, ptr %v0, ptr %v1, ptr %s0, ptr %l3, ptr %t153, ptr %t154, ptr %l19)
  br label %bb44
bb44:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l3, i8 125)
  br label %bb45
bb45:
  call void @__olang_scope_close(ptr %s6)
  br label %bb46
bb46:
  %t160 = load i64, ptr %l17, !tbaa !24
  %t162 = add i64 %t160, 1
  store i64 %t162, ptr %l17, !tbaa !24
  br label %bb32
bb47:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %l3, { i64, ptr } { i64 2, ptr @.d55 })
  br label %bb48
bb48:
  call void @__olang_scope_close(ptr %s2)
  br label %bb49
bb49:
  %t165 = load i64, ptr %l9, !tbaa !24
  %t167 = add i64 %t165, 1
  store i64 %t167, ptr %l9, !tbaa !24
  br label %bb11
bb50:
  %t169 = load i64, ptr %l4, !tbaa !24
  %t170 = extractvalue { i64, ptr } { i64 11, ptr @.d56 }, 1
  %t171 = extractvalue { i64, ptr } { i64 11, ptr @.d56 }, 0
  %t173 = call i64 @__olang_fmt_i64(ptr null, i64 %t169)
  %t174 = add i64 %t171, %t173
  %t175 = extractvalue { i64, ptr } { i64 1, ptr @.d57 }, 1
  %t176 = extractvalue { i64, ptr } { i64 1, ptr @.d57 }, 0
  %t177 = add i64 %t174, %t176
  %t178 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t177)
  call void @olang_textcopy(ptr %t178, ptr %t170, i64 %t171)
  %t179 = getelementptr i8, ptr %t178, i64 %t171
  %t180 = call i64 @__olang_fmt_i64(ptr %t179, i64 %t169)
  %t181 = getelementptr i8, ptr %t179, i64 %t173
  call void @olang_textcopy(ptr %t181, ptr %t175, i64 %t176)
  %t182 = insertvalue { i64, ptr } undef, i64 %t177, 0
  %t183 = insertvalue { i64, ptr } %t182, ptr %t178, 1
  %t185 = extractvalue { i64, ptr } %t183, 0
  %t186 = extractvalue { i64, ptr } %t183, 1
  %t187 = mul i64 %t185, 1
  %t188 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t187)
  call void @llvm.memcpy.p0.p0.i64(ptr %t188, ptr %t186, i64 %t187, i1 false)
  %t189 = insertvalue { i64, ptr } undef, i64 %t185, 0
  %t190 = insertvalue { i64, ptr } %t189, ptr %t188, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l3, { i64, ptr } %t190)
  br label %bb51
bb51:
  %t193 = load i64, ptr %l4, !tbaa !24
  %t195 = icmp eq i64 %t193, 0
  br i1 %t195, label %bb52, label %bb53
bb52:
  store { i64, ptr } { i64 9, ptr @.d58 }, ptr %l120, !tbaa !27
  br label %bb56
bb53:
  %t197 = load ptr, ptr %l1, !tbaa !29
  %t199 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eRender(ptr %v1, ptr %s0, ptr %t197)
  store { i64, ptr } %t199, ptr %l122
  br label %bb54
bb54:
  %t200 = load ptr, ptr %l1, !tbaa !29
  %t202 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eSummary(ptr %v1, ptr %s0, ptr %t200)
  store { i64, ptr } %t202, ptr %l124
  br label %bb55
bb55:
  %t203 = load { i64, ptr }, ptr %l122, !tbaa !27
  %t204 = extractvalue { i64, ptr } %t203, 1
  %t205 = extractvalue { i64, ptr } %t203, 0
  %t206 = load { i64, ptr }, ptr %l124, !tbaa !27
  %t207 = extractvalue { i64, ptr } %t206, 1
  %t208 = extractvalue { i64, ptr } %t206, 0
  %t209 = add i64 %t205, %t208
  %t210 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t209)
  call void @olang_textcopy(ptr %t210, ptr %t204, i64 %t205)
  %t211 = getelementptr i8, ptr %t210, i64 %t205
  call void @olang_textcopy(ptr %t211, ptr %t207, i64 %t208)
  %t212 = insertvalue { i64, ptr } undef, i64 %t209, 0
  %t213 = insertvalue { i64, ptr } %t212, ptr %t210, 1
  %t215 = extractvalue { i64, ptr } %t213, 0
  %t216 = extractvalue { i64, ptr } %t213, 1
  %t217 = mul i64 %t215, 1
  %t218 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t217)
  call void @llvm.memcpy.p0.p0.i64(ptr %t218, ptr %t216, i64 %t217, i1 false)
  %t219 = insertvalue { i64, ptr } undef, i64 %t215, 0
  %t220 = insertvalue { i64, ptr } %t219, ptr %t218, 1
  store { i64, ptr } %t220, ptr %l120, !tbaa !27
  br label %bb56
bb56:
  %t222 = load { i64, ptr }, ptr %l120, !tbaa !27
  store { i64, ptr } %t222, ptr %l20, !tbaa !27
  %t223 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t223, ptr %l127
  br label %bb57
bb57:
  %t224 = load %"std/prelude/text:StringBuilder", ptr %l127
  store %"std/prelude/text:StringBuilder" %t224, ptr %l21
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l21, { i64, ptr } { i64 34, ptr @.d59 })
  br label %bb58
bb58:
  %t226 = load { i64, ptr }, ptr %l20, !tbaa !27
  call void @compiler_2fsession_2eJsonStr(ptr %s0, ptr %s0, ptr %l21, { i64, ptr } %t226)
  br label %bb59
bb59:
  store ptr %l21, ptr %l131, !tbaa !29
  %t230 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l3)
  store { i64, ptr } %t230, ptr %l133
  br label %bb60
bb60:
  %t231 = extractvalue { i64, ptr } { i64 23, ptr @.d60 }, 1
  %t232 = extractvalue { i64, ptr } { i64 23, ptr @.d60 }, 0
  %t233 = load { i64, ptr }, ptr %l133, !tbaa !27
  %t234 = extractvalue { i64, ptr } %t233, 1
  %t235 = extractvalue { i64, ptr } %t233, 0
  %t236 = add i64 %t232, %t235
  %t237 = extractvalue { i64, ptr } { i64 17, ptr @.d61 }, 1
  %t238 = extractvalue { i64, ptr } { i64 17, ptr @.d61 }, 0
  %t239 = add i64 %t236, %t238
  %t240 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t239)
  call void @olang_textcopy(ptr %t240, ptr %t231, i64 %t232)
  %t241 = getelementptr i8, ptr %t240, i64 %t232
  call void @olang_textcopy(ptr %t241, ptr %t234, i64 %t235)
  %t242 = getelementptr i8, ptr %t241, i64 %t235
  call void @olang_textcopy(ptr %t242, ptr %t237, i64 %t238)
  %t243 = insertvalue { i64, ptr } undef, i64 %t239, 0
  %t244 = insertvalue { i64, ptr } %t243, ptr %t240, 1
  %t246 = extractvalue { i64, ptr } %t244, 0
  %t247 = extractvalue { i64, ptr } %t244, 1
  %t248 = mul i64 %t246, 1
  %t249 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t248)
  call void @llvm.memcpy.p0.p0.i64(ptr %t249, ptr %t247, i64 %t248, i1 false)
  %t250 = insertvalue { i64, ptr } undef, i64 %t246, 0
  %t251 = insertvalue { i64, ptr } %t250, ptr %t249, 1
  %t252 = load ptr, ptr %l131, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t252, { i64, ptr } %t251)
  br label %bb61
bb61:
  %t255 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l21)
  store { i64, ptr } %t255, ptr %l137
  br label %bb62
bb62:
  %t256 = load { i64, ptr }, ptr %l137, !tbaa !27
  store { i64, ptr } %t256, ptr %l138, !tbaa !27
  %t257 = load { i64, ptr }, ptr %l138, !tbaa !27
  %t258 = extractvalue { i64, ptr } %t257, 0
  store i64 %t258, ptr %l139, !tbaa !24
  %t259 = load i64, ptr %l139, !tbaa !24
  %t260 = mul i64 %t259, 1
  %t261 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t260)
  %t262 = insertvalue { i64, ptr } undef, i64 %t259, 0
  %t263 = insertvalue { i64, ptr } %t262, ptr %t261, 1
  store { i64, ptr } %t263, ptr %l140, !tbaa !27
  %t264 = getelementptr { i64, ptr }, ptr %l140, i32 0, i32 1
  %t265 = load ptr, ptr %t264, !tbaa !27
  %t266 = getelementptr { i64, ptr }, ptr %l138, i32 0, i32 1
  %t267 = load ptr, ptr %t266, !tbaa !27
  %t268 = load i64, ptr %l139, !tbaa !24
  %t269 = mul i64 %t268, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t265, ptr %t267, i64 %t269, i1 false)
  %t270 = load { i64, ptr }, ptr %l140, !tbaa !27
  store { i64, ptr } %t270, ptr %l138, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t271 = load { i64, ptr }, ptr %l138, !tbaa !27
  store { i64, ptr } %t271, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fmcp_2ecompilerUnderTest(ptr %v0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l8 = alloca i1
  %l10 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %s0, ptr %s0, { i64, ptr } { i64 5, ptr @.d62 })
  %t2 = extractvalue { i32, { i64, ptr } } %t1, 1
  %t3 = extractvalue { i32, { i64, ptr } } %t1, 0
  store i32 %t3, ptr %l3
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5
ok.5:
  store { i64, ptr } %t2, ptr %l2
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t6, ptr %l1, !tbaa !27
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr @.d63 }, ptr %l4, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  %t10 = extractvalue { i64, ptr } %t7, 1
  %t11 = mul i64 %t9, 1
  %t12 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t10, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l1, !tbaa !27
  br label %bb4
bb4:
  %t16 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t16, ptr %l0, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t19 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t17, { i64, ptr } { i64 0, ptr @.d64 })
  store i1 %t19, ptr %l8
  br label %bb5
bb5:
  %t20 = load i1, ptr %l8, !tbaa !21
  %t21 = xor i1 %t20, true
  br i1 %t21, label %bb6, label %bb7
bb6:
  %t23 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t23, 1
  %t26 = extractvalue { i64, ptr } %t23, 0
  %t27 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t26)
  call void @olang_textcopy(ptr %t27, ptr %t25, i64 %t26)
  %t28 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t27, 1
  store { i64, ptr } %t29, ptr %l10, !tbaa !27
  br label %bb8
bb7:
  store { i64, ptr } { i64 11, ptr @.d65 }, ptr %l13, !tbaa !27
  %t31 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t31, ptr %l10, !tbaa !27
  br label %bb8
bb8:
  %t33 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t33, 0
  store i64 %t34, ptr %l15, !tbaa !24
  %t35 = load i64, ptr %l15, !tbaa !24
  %t36 = mul i64 %t35, 1
  %t37 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t36)
  %t38 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t37, 1
  store { i64, ptr } %t39, ptr %l16, !tbaa !27
  %t40 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = load i64, ptr %l15, !tbaa !24
  %t45 = mul i64 %t44, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t41, ptr %t43, i64 %t45, i1 false)
  %t46 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t46, ptr %l10, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t47 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t47, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fmcp_2eerrorReply(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %l3 = alloca %"std/prelude/text:StringBuilder"
  %l4 = alloca %"std/prelude/text:StringBuilder"
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l4
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l4
  store %"std/prelude/text:StringBuilder" %t2, ptr %l3
  %t5 = extractvalue { i64, ptr } { i64 22, ptr @.d66 }, 1
  %t6 = extractvalue { i64, ptr } { i64 22, ptr @.d66 }, 0
  %t8 = extractvalue { i64, ptr } %a0, 1
  %t9 = extractvalue { i64, ptr } %a0, 0
  %t10 = add i64 %t6, %t9
  %t11 = extractvalue { i64, ptr } { i64 17, ptr @.d67 }, 1
  %t12 = extractvalue { i64, ptr } { i64 17, ptr @.d67 }, 0
  %t13 = add i64 %t10, %t12
  %t15 = call i64 @__olang_fmt_i64(ptr null, i64 %a1)
  %t16 = add i64 %t13, %t15
  %t17 = extractvalue { i64, ptr } { i64 11, ptr @.d68 }, 1
  %t18 = extractvalue { i64, ptr } { i64 11, ptr @.d68 }, 0
  %t19 = add i64 %t16, %t18
  %t20 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t19)
  call void @olang_textcopy(ptr %t20, ptr %t5, i64 %t6)
  %t21 = getelementptr i8, ptr %t20, i64 %t6
  call void @olang_textcopy(ptr %t21, ptr %t8, i64 %t9)
  %t22 = getelementptr i8, ptr %t21, i64 %t9
  call void @olang_textcopy(ptr %t22, ptr %t11, i64 %t12)
  %t23 = getelementptr i8, ptr %t22, i64 %t12
  %t24 = call i64 @__olang_fmt_i64(ptr %t23, i64 %a1)
  %t25 = getelementptr i8, ptr %t23, i64 %t15
  call void @olang_textcopy(ptr %t25, ptr %t17, i64 %t18)
  %t26 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t20, 1
  %t29 = extractvalue { i64, ptr } %t27, 0
  %t30 = extractvalue { i64, ptr } %t27, 1
  %t31 = mul i64 %t29, 1
  %t32 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t31)
  call void @llvm.memcpy.p0.p0.i64(ptr %t32, ptr %t30, i64 %t31, i1 false)
  %t33 = insertvalue { i64, ptr } undef, i64 %t29, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t32, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l3, { i64, ptr } %t34)
  br label %bb2
bb2:
  call void @compiler_2fsession_2eJsonStr(ptr %s0, ptr %v1, ptr %l3, { i64, ptr } %a2)
  br label %bb3
bb3:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l3, { i64, ptr } { i64 2, ptr @.d69 })
  br label %bb4
bb4:
  %t42 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l3)
  store { i64, ptr } %t42, ptr %l14
  br label %bb5
bb5:
  %t43 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t43, ptr %l15, !tbaa !27
  %t44 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t44, 0
  store i64 %t45, ptr %l16, !tbaa !24
  %t46 = load i64, ptr %l16, !tbaa !24
  %t47 = mul i64 %t46, 1
  %t48 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t47)
  %t49 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t48, 1
  store { i64, ptr } %t50, ptr %l17, !tbaa !27
  %t51 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !27
  %t53 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !27
  %t55 = load i64, ptr %l16, !tbaa !24
  %t56 = mul i64 %t55, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t52, ptr %t54, i64 %t56, i1 false)
  %t57 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t57, ptr %l15, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t58 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t58, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fmcp_2ehandle(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, ptr %a1, { i64, ptr } %a2) #0 {
entry:
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"std/prelude/text:StringBuilder"
  %l8 = alloca { i64, ptr }
  %l10 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca i32
  %l16 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l23 = alloca i1
  %l24 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l29 = alloca ptr
  %l30 = alloca i32
  %l34 = alloca { i64, ptr }
  %l36 = alloca ptr
  %l37 = alloca i32
  %l40 = alloca { i64, ptr }
  %l41 = alloca i32
  %l44 = alloca %"std/prelude/text:StringBuilder"
  %l55 = alloca { i64, ptr }
  %l57 = alloca { i64, ptr }
  %l58 = alloca { i64, ptr }
  %l61 = alloca i1
  %l63 = alloca i1
  %l65 = alloca { i64, ptr }
  %l68 = alloca i1
  %l73 = alloca { i64, ptr }
  %l76 = alloca i1
  %l77 = alloca { i64, ptr }
  %l80 = alloca { i64, ptr }
  %l82 = alloca ptr
  %l83 = alloca i32
  %l87 = alloca { i64, ptr }
  %l89 = alloca ptr
  %l90 = alloca i32
  %l93 = alloca { i64, ptr }
  %l94 = alloca i32
  %l97 = alloca ptr
  %l100 = alloca { i64, ptr }
  %l102 = alloca ptr
  %l103 = alloca i32
  %l107 = alloca { i64, ptr }
  %l109 = alloca ptr
  %l110 = alloca i32
  %l115 = alloca { i64, ptr }
  %l120 = alloca { i64, ptr }
  %l122 = alloca { i64, ptr }
  %l128 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %t266 = alloca { i64, [2 x i64] }, align 8
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call { i32, ptr } @std_2fjson_2eParse(ptr %v0, ptr %s0, ptr %s0, { i64, ptr } %a0, ptr null)
  %t4 = extractvalue { i32, ptr } %t3, 1
  %t5 = extractvalue { i32, ptr } %t3, 0
  store i32 %t5, ptr %l13
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7
ok.7:
  store ptr %t4, ptr %l12
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l12, !tbaa !29
  store ptr %t8, ptr %l10, !tbaa !29
  br label %bb8
bb2:
  %t9 = load i32, ptr %l13, !tbaa !23
  %t10 = ashr i32 %t9, 16
  %t12 = icmp eq i32 %t10, 1
  br i1 %t12, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_check_failed(ptr @olang_loc_4244407816c61fa5_b1d22b5654b5d3d9)
  unreachable
bb5:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s1
  %t14 = call { i64, ptr } @compiler_2fmcp_2eerrorReply(ptr %s1, ptr %s1, ptr %s1, { i64, ptr } { i64 4, ptr @.d70 }, i64 -32700, { i64, ptr } { i64 23, ptr @.d71 })
  store { i64, ptr } %t14, ptr %l16
  br label %bb6
bb6:
  %t15 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t15, 0
  %t17 = extractvalue { i64, ptr } %t15, 1
  %t18 = mul i64 %t16, 1
  %t19 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t18)
  call void @llvm.memcpy.p0.p0.i64(ptr %t19, ptr %t17, i64 %t18, i1 false)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  call void @compiler_2fmcp_2esend(ptr %s1, { i64, ptr } %t21)
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb8:
  %t23 = load ptr, ptr %l10, !tbaa !29
  store ptr %t23, ptr %l3, !tbaa !29
  %t24 = load ptr, ptr %l3, !tbaa !29
  %t26 = call { i64, ptr } @compiler_2fmcp_2estr(ptr %s0, ptr %s0, ptr %t24, { i64, ptr } { i64 6, ptr @.d72 })
  store { i64, ptr } %t26, ptr %l19
  br label %bb9
bb9:
  %t27 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t27, ptr %l4, !tbaa !27
  %t28 = load ptr, ptr %l3, !tbaa !29
  %t30 = call { i64, ptr } @compiler_2fmcp_2eidOf(ptr %s0, ptr %s0, ptr %t28)
  store { i64, ptr } %t30, ptr %l21
  br label %bb10
bb10:
  %t31 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t31, ptr %l5, !tbaa !27
  %t32 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t34 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t32, { i64, ptr } { i64 10, ptr @.d73 })
  store i1 %t34, ptr %l23
  br label %bb11
bb11:
  %t35 = load i1, ptr %l23, !tbaa !21
  br i1 %t35, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t36 = load ptr, ptr %l3, !tbaa !29
  store { i64, ptr } { i64 6, ptr @.d74 }, ptr %l27, !tbaa !27
  %t38 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t41 = call { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAt_3cstd_2fprelude_2ftext_3aString_3e(ptr %s0, ptr %t36, { i64, ptr } %t38)
  %t42 = extractvalue { i32, ptr } %t41, 1
  %t43 = extractvalue { i32, ptr } %t41, 0
  store i32 %t43, ptr %l30
  %t44 = icmp ne i32 %t43, 0
  br i1 %t44, label %bb15, label %ok.45
ok.45:
  store ptr %t42, ptr %l29
  br label %bb14
bb13:
  br label %bb37
bb14:
  %t46 = load ptr, ptr %l29, !tbaa !29
  store { i64, ptr } { i64 15, ptr @.d75 }, ptr %l34, !tbaa !27
  %t47 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t50 = call { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAt_3cstd_2fprelude_2ftext_3aString_3e(ptr %s0, ptr %t46, { i64, ptr } %t47)
  %t51 = extractvalue { i32, ptr } %t50, 1
  %t52 = extractvalue { i32, ptr } %t50, 0
  store i32 %t52, ptr %l37
  %t53 = icmp ne i32 %t52, 0
  br i1 %t53, label %bb20, label %ok.54
ok.54:
  store ptr %t51, ptr %l36
  br label %bb19
bb15:
  %t55 = load i32, ptr %l30, !tbaa !23
  %t56 = ashr i32 %t55, 16
  %t58 = icmp eq i32 %t56, 1
  br i1 %t58, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_49e75dc54fe70574_c2cd19fae9c45a08)
  unreachable
bb18:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 10, ptr @.d76 }, ptr %l24, !tbaa !27
  br label %bb27
bb19:
  %t60 = load ptr, ptr %l36, !tbaa !29
  %t61 = call { i32, { i64, ptr } } @std_2fjson_2estd_2fjson_3aJson_2eAsStr(ptr %s0, ptr %t60)
  %t62 = extractvalue { i32, { i64, ptr } } %t61, 1
  %t63 = extractvalue { i32, { i64, ptr } } %t61, 0
  store i32 %t63, ptr %l41
  %t64 = icmp ne i32 %t63, 0
  br i1 %t64, label %bb24, label %ok.65
ok.65:
  store { i64, ptr } %t62, ptr %l40
  br label %bb23
bb20:
  %t66 = load i32, ptr %l37, !tbaa !23
  %t67 = ashr i32 %t66, 16
  %t69 = icmp eq i32 %t67, 1
  br i1 %t69, label %bb21, label %bb22
bb21:
  br label %bb18
bb22:
  call void @__olang_check_failed(ptr @olang_loc_49e75dc54fe70574_c2cd19fae9c45a08)
  unreachable
bb23:
  %t71 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t71, ptr %l24, !tbaa !27
  br label %bb27
bb24:
  %t72 = load i32, ptr %l41, !tbaa !23
  %t73 = ashr i32 %t72, 16
  %t75 = icmp eq i32 %t73, 1
  br i1 %t75, label %bb25, label %bb26
bb25:
  br label %bb18
bb26:
  call void @__olang_check_failed(ptr @olang_loc_49e75dc54fe70574_c2cd19fae9c45a08)
  unreachable
bb27:
  %t77 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t77, ptr %l6, !tbaa !27
  %t78 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s2)
  store %"std/prelude/text:StringBuilder" %t78, ptr %l44
  br label %bb28
bb28:
  %t79 = load %"std/prelude/text:StringBuilder", ptr %l44
  store %"std/prelude/text:StringBuilder" %t79, ptr %l7
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s2, ptr %s2, ptr %l7, { i64, ptr } { i64 19, ptr @.d77 })
  br label %bb29
bb29:
  %t81 = load { i64, ptr }, ptr %l6, !tbaa !27
  call void @compiler_2fsession_2eJsonStr(ptr %s2, ptr %s0, ptr %l7, { i64, ptr } %t81)
  br label %bb30
bb30:
  %t84 = extractvalue { i64, ptr } { i64 92, ptr @.d78 }, 1
  %t85 = extractvalue { i64, ptr } { i64 92, ptr @.d78 }, 0
  %t86 = extractvalue { i64, ptr } { i64 15, ptr @.d79 }, 1
  %t87 = extractvalue { i64, ptr } { i64 15, ptr @.d79 }, 0
  %t88 = add i64 %t85, %t87
  %t89 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t88)
  call void @olang_textcopy(ptr %t89, ptr %t84, i64 %t85)
  %t90 = getelementptr i8, ptr %t89, i64 %t85
  call void @olang_textcopy(ptr %t90, ptr %t86, i64 %t87)
  %t91 = insertvalue { i64, ptr } undef, i64 %t88, 0
  %t92 = insertvalue { i64, ptr } %t91, ptr %t89, 1
  %t94 = extractvalue { i64, ptr } %t92, 0
  %t95 = extractvalue { i64, ptr } %t92, 1
  %t96 = mul i64 %t94, 1
  %t97 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t96)
  call void @llvm.memcpy.p0.p0.i64(ptr %t97, ptr %t95, i64 %t96, i1 false)
  %t98 = insertvalue { i64, ptr } undef, i64 %t94, 0
  %t99 = insertvalue { i64, ptr } %t98, ptr %t97, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s2, ptr %s2, ptr %l7, { i64, ptr } %t99)
  br label %bb31
bb31:
  %t102 = extractvalue { i64, ptr } { i64 87, ptr @.d80 }, 1
  %t103 = extractvalue { i64, ptr } { i64 87, ptr @.d80 }, 0
  %t104 = extractvalue { i64, ptr } { i64 91, ptr @.d81 }, 1
  %t105 = extractvalue { i64, ptr } { i64 91, ptr @.d81 }, 0
  %t106 = add i64 %t103, %t105
  %t107 = extractvalue { i64, ptr } { i64 18, ptr @.d82 }, 1
  %t108 = extractvalue { i64, ptr } { i64 18, ptr @.d82 }, 0
  %t109 = add i64 %t106, %t108
  %t110 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t109)
  call void @olang_textcopy(ptr %t110, ptr %t102, i64 %t103)
  %t111 = getelementptr i8, ptr %t110, i64 %t103
  call void @olang_textcopy(ptr %t111, ptr %t104, i64 %t105)
  %t112 = getelementptr i8, ptr %t111, i64 %t105
  call void @olang_textcopy(ptr %t112, ptr %t107, i64 %t108)
  %t113 = insertvalue { i64, ptr } undef, i64 %t109, 0
  %t114 = insertvalue { i64, ptr } %t113, ptr %t110, 1
  %t116 = extractvalue { i64, ptr } %t114, 0
  %t117 = extractvalue { i64, ptr } %t114, 1
  %t118 = mul i64 %t116, 1
  %t119 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t118)
  call void @llvm.memcpy.p0.p0.i64(ptr %t119, ptr %t117, i64 %t118, i1 false)
  %t120 = insertvalue { i64, ptr } undef, i64 %t116, 0
  %t121 = insertvalue { i64, ptr } %t120, ptr %t119, 1
  call void @compiler_2fsession_2eJsonStr(ptr %s2, ptr %s2, ptr %l7, { i64, ptr } %t121)
  br label %bb32
bb32:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s2, ptr %l7, i8 125)
  br label %bb33
bb33:
  %t125 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t125, ptr %l55, !tbaa !27
  %t127 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s2, ptr %s2, ptr %l7)
  store { i64, ptr } %t127, ptr %l57
  br label %bb34
bb34:
  %t128 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t129 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t130 = call { i64, ptr } @compiler_2fmcp_2ereply(ptr %s0, ptr %s2, ptr %s2, { i64, ptr } %t128, { i64, ptr } %t129)
  store { i64, ptr } %t130, ptr %l58
  br label %bb35
bb35:
  %t131 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t132 = extractvalue { i64, ptr } %t131, 0
  %t133 = extractvalue { i64, ptr } %t131, 1
  %t134 = mul i64 %t132, 1
  %t135 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t134)
  call void @llvm.memcpy.p0.p0.i64(ptr %t135, ptr %t133, i64 %t134, i1 false)
  %t136 = insertvalue { i64, ptr } undef, i64 %t132, 0
  %t137 = insertvalue { i64, ptr } %t136, ptr %t135, 1
  call void @compiler_2fmcp_2esend(ptr %s2, { i64, ptr } %t137)
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb37:
  %t139 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t141 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t139, { i64, ptr } { i64 0, ptr @.d83 })
  store i1 %t141, ptr %l61
  br label %bb38
bb38:
  %t142 = load i1, ptr %l61, !tbaa !21
  br i1 %t142, label %bb39, label %bb40
bb39:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb40:
  br label %bb41
bb41:
  %t143 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t145 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t143, { i64, ptr } { i64 4, ptr @.d84 })
  store i1 %t145, ptr %l63
  br label %bb42
bb42:
  %t146 = load i1, ptr %l63, !tbaa !21
  br i1 %t146, label %bb43, label %bb44
bb43:
  store %olang.scope zeroinitializer, ptr %s6
  %t147 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t149 = call { i64, ptr } @compiler_2fmcp_2ereply(ptr %s0, ptr %s6, ptr %s6, { i64, ptr } %t147, { i64, ptr } { i64 2, ptr @.d85 })
  store { i64, ptr } %t149, ptr %l65
  br label %bb45
bb44:
  br label %bb47
bb45:
  %t150 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t151 = extractvalue { i64, ptr } %t150, 0
  %t152 = extractvalue { i64, ptr } %t150, 1
  %t153 = mul i64 %t151, 1
  %t154 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t153)
  call void @llvm.memcpy.p0.p0.i64(ptr %t154, ptr %t152, i64 %t153, i1 false)
  %t155 = insertvalue { i64, ptr } undef, i64 %t151, 0
  %t156 = insertvalue { i64, ptr } %t155, ptr %t154, 1
  call void @compiler_2fmcp_2esend(ptr %s6, { i64, ptr } %t156)
  br label %bb46
bb46:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb47:
  %t158 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t160 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t158, { i64, ptr } { i64 10, ptr @.d86 })
  store i1 %t160, ptr %l68
  br label %bb48
bb48:
  %t161 = load i1, ptr %l68, !tbaa !21
  br i1 %t161, label %bb49, label %bb50
bb49:
  store %olang.scope zeroinitializer, ptr %s7
  %t162 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t163 = load { i64, ptr }, ptr @G_2ecompiler_2fmcp_2eTools, !tbaa !27
  %t164 = extractvalue { i64, ptr } { i64 9, ptr @.d87 }, 1
  %t165 = extractvalue { i64, ptr } { i64 9, ptr @.d87 }, 0
  %t167 = extractvalue { i64, ptr } %t163, 1
  %t168 = extractvalue { i64, ptr } %t163, 0
  %t169 = add i64 %t165, %t168
  %t170 = extractvalue { i64, ptr } { i64 1, ptr @.d88 }, 1
  %t171 = extractvalue { i64, ptr } { i64 1, ptr @.d88 }, 0
  %t172 = add i64 %t169, %t171
  %t173 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t172)
  call void @olang_textcopy(ptr %t173, ptr %t164, i64 %t165)
  %t174 = getelementptr i8, ptr %t173, i64 %t165
  call void @olang_textcopy(ptr %t174, ptr %t167, i64 %t168)
  %t175 = getelementptr i8, ptr %t174, i64 %t168
  call void @olang_textcopy(ptr %t175, ptr %t170, i64 %t171)
  %t176 = insertvalue { i64, ptr } undef, i64 %t172, 0
  %t177 = insertvalue { i64, ptr } %t176, ptr %t173, 1
  %t179 = extractvalue { i64, ptr } %t177, 0
  %t180 = extractvalue { i64, ptr } %t177, 1
  %t181 = mul i64 %t179, 1
  %t182 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t181)
  call void @llvm.memcpy.p0.p0.i64(ptr %t182, ptr %t180, i64 %t181, i1 false)
  %t183 = insertvalue { i64, ptr } undef, i64 %t179, 0
  %t184 = insertvalue { i64, ptr } %t183, ptr %t182, 1
  %t187 = call { i64, ptr } @compiler_2fmcp_2ereply(ptr %s0, ptr %s7, ptr %s7, { i64, ptr } %t162, { i64, ptr } %t184)
  store { i64, ptr } %t187, ptr %l73
  br label %bb51
bb50:
  br label %bb53
bb51:
  %t188 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t189 = extractvalue { i64, ptr } %t188, 0
  %t190 = extractvalue { i64, ptr } %t188, 1
  %t191 = mul i64 %t189, 1
  %t192 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t191)
  call void @llvm.memcpy.p0.p0.i64(ptr %t192, ptr %t190, i64 %t191, i1 false)
  %t193 = insertvalue { i64, ptr } undef, i64 %t189, 0
  %t194 = insertvalue { i64, ptr } %t193, ptr %t192, 1
  call void @compiler_2fmcp_2esend(ptr %s7, { i64, ptr } %t194)
  br label %bb52
bb52:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb53:
  %t196 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t198 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t196, { i64, ptr } { i64 10, ptr @.d89 })
  store i1 %t198, ptr %l76
  br label %bb54
bb54:
  %t199 = load i1, ptr %l76, !tbaa !21
  br i1 %t199, label %bb55, label %bb56
bb55:
  store %olang.scope zeroinitializer, ptr %s9
  %t200 = load ptr, ptr %l3, !tbaa !29
  store { i64, ptr } { i64 6, ptr @.d90 }, ptr %l80, !tbaa !27
  %t202 = load { i64, ptr }, ptr %l80, !tbaa !27
  %t205 = call { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAt_3cstd_2fprelude_2ftext_3aString_3e(ptr %s0, ptr %t200, { i64, ptr } %t202)
  %t206 = extractvalue { i32, ptr } %t205, 1
  %t207 = extractvalue { i32, ptr } %t205, 0
  store i32 %t207, ptr %l83
  %t208 = icmp ne i32 %t207, 0
  br i1 %t208, label %bb58, label %ok.209
ok.209:
  store ptr %t206, ptr %l82
  br label %bb57
bb56:
  br label %bb84
bb57:
  %t210 = load ptr, ptr %l82, !tbaa !29
  store { i64, ptr } { i64 4, ptr @.d91 }, ptr %l87, !tbaa !27
  %t211 = load { i64, ptr }, ptr %l87, !tbaa !27
  %t214 = call { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAt_3cstd_2fprelude_2ftext_3aString_3e(ptr %s0, ptr %t210, { i64, ptr } %t211)
  %t215 = extractvalue { i32, ptr } %t214, 1
  %t216 = extractvalue { i32, ptr } %t214, 0
  store i32 %t216, ptr %l90
  %t217 = icmp ne i32 %t216, 0
  br i1 %t217, label %bb63, label %ok.218
ok.218:
  store ptr %t215, ptr %l89
  br label %bb62
bb58:
  %t219 = load i32, ptr %l83, !tbaa !23
  %t220 = ashr i32 %t219, 16
  %t222 = icmp eq i32 %t220, 1
  br i1 %t222, label %bb59, label %bb60
bb59:
  br label %bb61
bb60:
  call void @__olang_check_failed(ptr @olang_loc_818e19382589e4af_9134443e2d759de3)
  unreachable
bb61:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr @.d92 }, ptr %l77, !tbaa !27
  br label %bb70
bb62:
  %t224 = load ptr, ptr %l89, !tbaa !29
  %t225 = call { i32, { i64, ptr } } @std_2fjson_2estd_2fjson_3aJson_2eAsStr(ptr %s0, ptr %t224)
  %t226 = extractvalue { i32, { i64, ptr } } %t225, 1
  %t227 = extractvalue { i32, { i64, ptr } } %t225, 0
  store i32 %t227, ptr %l94
  %t228 = icmp ne i32 %t227, 0
  br i1 %t228, label %bb67, label %ok.229
ok.229:
  store { i64, ptr } %t226, ptr %l93
  br label %bb66
bb63:
  %t230 = load i32, ptr %l90, !tbaa !23
  %t231 = ashr i32 %t230, 16
  %t233 = icmp eq i32 %t231, 1
  br i1 %t233, label %bb64, label %bb65
bb64:
  br label %bb61
bb65:
  call void @__olang_check_failed(ptr @olang_loc_818e19382589e4af_9134443e2d759de3)
  unreachable
bb66:
  %t235 = load { i64, ptr }, ptr %l93, !tbaa !27
  store { i64, ptr } %t235, ptr %l77, !tbaa !27
  br label %bb70
bb67:
  %t236 = load i32, ptr %l94, !tbaa !23
  %t237 = ashr i32 %t236, 16
  %t239 = icmp eq i32 %t237, 1
  br i1 %t239, label %bb68, label %bb69
bb68:
  br label %bb61
bb69:
  call void @__olang_check_failed(ptr @olang_loc_818e19382589e4af_9134443e2d759de3)
  unreachable
bb70:
  %t241 = load { i64, ptr }, ptr %l77, !tbaa !27
  store { i64, ptr } %t241, ptr %l8, !tbaa !27
  %t242 = load ptr, ptr %l3, !tbaa !29
  store { i64, ptr } { i64 6, ptr @.d93 }, ptr %l100, !tbaa !27
  %t244 = load { i64, ptr }, ptr %l100, !tbaa !27
  %t247 = call { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAt_3cstd_2fprelude_2ftext_3aString_3e(ptr %s0, ptr %t242, { i64, ptr } %t244)
  %t248 = extractvalue { i32, ptr } %t247, 1
  %t249 = extractvalue { i32, ptr } %t247, 0
  store i32 %t249, ptr %l103
  %t250 = icmp ne i32 %t249, 0
  br i1 %t250, label %bb72, label %ok.251
ok.251:
  store ptr %t248, ptr %l102
  br label %bb71
bb71:
  %t252 = load ptr, ptr %l102, !tbaa !29
  store { i64, ptr } { i64 9, ptr @.d94 }, ptr %l107, !tbaa !27
  %t253 = load { i64, ptr }, ptr %l107, !tbaa !27
  %t256 = call { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAt_3cstd_2fprelude_2ftext_3aString_3e(ptr %s0, ptr %t252, { i64, ptr } %t253)
  %t257 = extractvalue { i32, ptr } %t256, 1
  %t258 = extractvalue { i32, ptr } %t256, 0
  store i32 %t258, ptr %l110
  %t259 = icmp ne i32 %t258, 0
  br i1 %t259, label %bb77, label %ok.260
ok.260:
  store ptr %t257, ptr %l109
  br label %bb76
bb72:
  %t261 = load i32, ptr %l103, !tbaa !23
  %t262 = ashr i32 %t261, 16
  %t264 = icmp eq i32 %t262, 1
  br i1 %t264, label %bb73, label %bb74
bb73:
  br label %bb75
bb74:
  call void @__olang_check_failed(ptr @olang_loc_bdbef39504843ee_f5102062f3e4bfe2)
  unreachable
bb75:
  call void @__olang_ert_req_clear()
  store { i64, [2 x i64] } zeroinitializer, ptr %t266
  %t267 = getelementptr { i64, [2 x i64] }, ptr %t266, i32 0, i32 0
  store i64 0, ptr %t267
  %t268 = load { i64, [2 x i64] }, ptr %t266
  %t270 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 24, i64 8)
  store { i64, [2 x i64] } %t268, ptr %t270
  store ptr %t270, ptr %l97, !tbaa !29
  br label %bb80
bb76:
  %t272 = load ptr, ptr %l109, !tbaa !29
  store ptr %t272, ptr %l97, !tbaa !29
  br label %bb80
bb77:
  %t273 = load i32, ptr %l110, !tbaa !23
  %t274 = ashr i32 %t273, 16
  %t276 = icmp eq i32 %t274, 1
  br i1 %t276, label %bb78, label %bb79
bb78:
  br label %bb75
bb79:
  call void @__olang_check_failed(ptr @olang_loc_bdbef39504843ee_f5102062f3e4bfe2)
  unreachable
bb80:
  %t278 = load ptr, ptr %l97, !tbaa !29
  %t279 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t279, ptr %l115, !tbaa !27
  %t280 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t288 = call { i64, ptr } @compiler_2fmcp_2ecall(ptr %s0, ptr %s0, ptr %v1, ptr %v2, ptr %s9, { i64, ptr } %t280, ptr %t278, ptr %a1, { i64, ptr } %a2)
  store { i64, ptr } %t288, ptr %l120
  br label %bb81
bb81:
  %t289 = load { i64, ptr }, ptr %l120, !tbaa !27
  %t290 = extractvalue { i64, ptr } %t289, 0
  %t291 = extractvalue { i64, ptr } %t289, 1
  %t292 = mul i64 %t290, 1
  %t293 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t292)
  call void @llvm.memcpy.p0.p0.i64(ptr %t293, ptr %t291, i64 %t292, i1 false)
  %t294 = insertvalue { i64, ptr } undef, i64 %t290, 0
  %t295 = insertvalue { i64, ptr } %t294, ptr %t293, 1
  %t296 = load { i64, ptr }, ptr %l115, !tbaa !27
  %t298 = call { i64, ptr } @compiler_2fmcp_2ereply(ptr %s0, ptr %s9, ptr %s9, { i64, ptr } %t296, { i64, ptr } %t295)
  store { i64, ptr } %t298, ptr %l122
  br label %bb82
bb82:
  %t299 = load { i64, ptr }, ptr %l122, !tbaa !27
  %t300 = extractvalue { i64, ptr } %t299, 0
  %t301 = extractvalue { i64, ptr } %t299, 1
  %t302 = mul i64 %t300, 1
  %t303 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t302)
  call void @llvm.memcpy.p0.p0.i64(ptr %t303, ptr %t301, i64 %t302, i1 false)
  %t304 = insertvalue { i64, ptr } undef, i64 %t300, 0
  %t305 = insertvalue { i64, ptr } %t304, ptr %t303, 1
  call void @compiler_2fmcp_2esend(ptr %s9, { i64, ptr } %t305)
  br label %bb83
bb83:
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb84:
  %t307 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t308 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t309 = extractvalue { i64, ptr } { i64 17, ptr @.d95 }, 1
  %t310 = extractvalue { i64, ptr } { i64 17, ptr @.d95 }, 0
  %t312 = extractvalue { i64, ptr } %t308, 1
  %t313 = extractvalue { i64, ptr } %t308, 0
  %t314 = add i64 %t310, %t313
  %t315 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t314)
  call void @olang_textcopy(ptr %t315, ptr %t309, i64 %t310)
  %t316 = getelementptr i8, ptr %t315, i64 %t310
  call void @olang_textcopy(ptr %t316, ptr %t312, i64 %t313)
  %t317 = insertvalue { i64, ptr } undef, i64 %t314, 0
  %t318 = insertvalue { i64, ptr } %t317, ptr %t315, 1
  %t320 = extractvalue { i64, ptr } %t318, 0
  %t321 = extractvalue { i64, ptr } %t318, 1
  %t322 = mul i64 %t320, 1
  %t323 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t322)
  call void @llvm.memcpy.p0.p0.i64(ptr %t323, ptr %t321, i64 %t322, i1 false)
  %t324 = insertvalue { i64, ptr } undef, i64 %t320, 0
  %t325 = insertvalue { i64, ptr } %t324, ptr %t323, 1
  %t328 = call { i64, ptr } @compiler_2fmcp_2eerrorReply(ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t307, i64 -32601, { i64, ptr } %t325)
  store { i64, ptr } %t328, ptr %l128
  br label %bb85
bb85:
  %t329 = load { i64, ptr }, ptr %l128, !tbaa !27
  %t330 = extractvalue { i64, ptr } %t329, 0
  %t331 = extractvalue { i64, ptr } %t329, 1
  %t332 = mul i64 %t330, 1
  %t333 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t332)
  call void @llvm.memcpy.p0.p0.i64(ptr %t333, ptr %t331, i64 %t332, i1 false)
  %t334 = insertvalue { i64, ptr } undef, i64 %t330, 0
  %t335 = insertvalue { i64, ptr } %t334, ptr %t333, 1
  call void @compiler_2fmcp_2esend(ptr %s0, { i64, ptr } %t335)
  br label %bb86
bb86:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fmcp_2eidOf(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l2 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l6 = alloca ptr
  %l7 = alloca i32
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } { i64 2, ptr @.d96 }, ptr %l4, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t5 = call { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAt_3cstd_2fprelude_2ftext_3aString_3e(ptr %v0, ptr %a0, { i64, ptr } %t2)
  %t6 = extractvalue { i32, ptr } %t5, 1
  %t7 = extractvalue { i32, ptr } %t5, 0
  store i32 %t7, ptr %l7
  %t8 = icmp ne i32 %t7, 0
  br i1 %t8, label %bb2, label %ok.9
ok.9:
  store ptr %t6, ptr %l6
  br label %bb1
bb1:
  %t10 = load ptr, ptr %l6, !tbaa !29
  store ptr %t10, ptr %l2, !tbaa !29
  br label %bb6
bb2:
  %t11 = load i32, ptr %l7, !tbaa !23
  %t12 = ashr i32 %t11, 16
  %t14 = icmp eq i32 %t12, 1
  br i1 %t14, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_check_failed(ptr @olang_loc_5fd9fed611fa4e17_8f5848307df60ca3)
  unreachable
bb5:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr @.d97 }, ptr %l10, !tbaa !27
  %t16 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t16, ptr %l11, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t17, 0
  store i64 %t18, ptr %l12, !tbaa !24
  %t19 = load i64, ptr %l12, !tbaa !24
  %t20 = mul i64 %t19, 1
  %t21 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t20)
  %t22 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t21, 1
  store { i64, ptr } %t23, ptr %l13, !tbaa !27
  %t24 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = load i64, ptr %l12, !tbaa !24
  %t29 = mul i64 %t28, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t25, ptr %t27, i64 %t29, i1 false)
  %t30 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t30, ptr %l11, !tbaa !27
  %t31 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t31, ptr %rv
  br label %ret
bb6:
  %t32 = load ptr, ptr %l2, !tbaa !29
  %t35 = call { i64, ptr } @std_2fjson_2eEncode(ptr %v0, ptr %v1, ptr %v1, ptr %t32, { i64, ptr } { i64 0, ptr @.d98 })
  store { i64, ptr } %t35, ptr %l15
  br label %bb7
bb7:
  %t36 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t36, ptr %l16, !tbaa !27
  %t37 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t37, 0
  store i64 %t38, ptr %l17, !tbaa !24
  %t39 = load i64, ptr %l17, !tbaa !24
  %t40 = mul i64 %t39, 1
  %t41 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t40)
  %t42 = insertvalue { i64, ptr } undef, i64 %t39, 0
  %t43 = insertvalue { i64, ptr } %t42, ptr %t41, 1
  store { i64, ptr } %t43, ptr %l18, !tbaa !27
  %t44 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = load i64, ptr %l17, !tbaa !24
  %t49 = mul i64 %t48, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t45, ptr %t47, i64 %t49, i1 false)
  %t50 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t50, ptr %l16, !tbaa !27
  %t51 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t51, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fmcp_2elocated(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca %"compiler/session:Positions"
  %l5 = alloca { i64, i64 }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca { i64, i64 }
  %l12 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l29 = alloca %"compiler/session:Positions"
  %l33 = alloca { i64, i64 }
  %l36 = alloca ptr
  %l42 = alloca i64
  %l47 = alloca { i64, i64 }
  %l71 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s0, ptr %t1, { i64, ptr } { i64 8, ptr @.d99 })
  br label %bb1
bb1:
  %t3 = load ptr, ptr %l0, !tbaa !29
  store ptr %t3, ptr %l12, !tbaa !29
  %t4 = load ptr, ptr %l3, !tbaa !29
  %t6 = getelementptr %"compiler/diag:Item", ptr %t4, i32 0, i32 2
  %t7 = load i64, ptr %t6, !tbaa !24
  %t9 = icmp sge i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l2, !tbaa !29
  %t12 = load ptr, ptr %l3, !tbaa !29
  %t14 = getelementptr %"compiler/diag:Item", ptr %t12, i32 0, i32 2
  %t15 = load i64, ptr %t14, !tbaa !24
  %t18 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2ePathOf(ptr %v2, ptr %s0, ptr %t11, i64 %t15)
  store { i64, ptr } %t18, ptr %l20
  br label %bb4
bb3:
  store { i64, ptr } { i64 0, ptr @.d100 }, ptr %l16, !tbaa !27
  br label %bb5
bb4:
  %t19 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t19, 0
  %t21 = extractvalue { i64, ptr } %t19, 1
  %t22 = mul i64 %t20, 1
  %t23 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t22)
  call void @llvm.memcpy.p0.p0.i64(ptr %t23, ptr %t21, i64 %t22, i1 false)
  %t24 = insertvalue { i64, ptr } undef, i64 %t20, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t23, 1
  store { i64, ptr } %t25, ptr %l16, !tbaa !27
  br label %bb5
bb5:
  %t27 = load ptr, ptr %l12, !tbaa !29
  %t28 = load { i64, ptr }, ptr %l16, !tbaa !27
  call void @compiler_2fsession_2eJsonStr(ptr %v0, ptr %s0, ptr %t27, { i64, ptr } %t28)
  br label %bb6
bb6:
  %t29 = load ptr, ptr %l3, !tbaa !29
  %t31 = getelementptr %"compiler/diag:Item", ptr %t29, i32 0, i32 3
  %t32 = load i64, ptr %t31, !tbaa !24
  %t34 = icmp sge i64 %t32, 0
  br i1 %t34, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s1
  %t36 = load ptr, ptr %l2, !tbaa !29
  %t37 = load ptr, ptr %l3, !tbaa !29
  %t39 = getelementptr %"compiler/diag:Item", ptr %t37, i32 0, i32 2
  %t40 = load i64, ptr %t39, !tbaa !24
  %t43 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eTextOf(ptr %v2, ptr %t36, i64 %t40)
  store { i64, ptr } %t43, ptr %l28
  br label %bb9
bb8:
  %t44 = load ptr, ptr %l3, !tbaa !29
  %t46 = getelementptr %"compiler/diag:Item", ptr %t44, i32 0, i32 5
  %t47 = load i64, ptr %t46, !tbaa !24
  %t49 = icmp sgt i64 %t47, 0
  br i1 %t49, label %bb17, label %bb18
bb9:
  %t51 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t52 = call %"compiler/session:Positions" @compiler_2fsession_3aPositions_2ector(ptr %v2, ptr %s1, { i64, ptr } %t51, i1 true)
  store %"compiler/session:Positions" %t52, ptr %l29
  br label %bb10
bb10:
  %t53 = load %"compiler/session:Positions", ptr %l29
  store %"compiler/session:Positions" %t53, ptr %l4
  %t54 = load ptr, ptr %l3, !tbaa !29
  %t56 = getelementptr %"compiler/diag:Item", ptr %t54, i32 0, i32 3
  %t57 = load i64, ptr %t56, !tbaa !24
  %t60 = call { i64, i64 } @compiler_2fsession_2ecompiler_2fsession_3aPositions_2ePos(ptr %s1, ptr %l4, i64 %t57)
  store { i64, i64 } %t60, ptr %l33
  br label %bb11
bb11:
  %t61 = load { i64, i64 }, ptr %l33
  store { i64, i64 } %t61, ptr %l5
  %t62 = getelementptr { i64, i64 }, ptr %l5, i32 0, i32 0
  %t63 = load i64, ptr %t62, !tbaa !24
  store i64 %t63, ptr %l6, !tbaa !24
  %t65 = getelementptr { i64, i64 }, ptr %l5, i32 0, i32 1
  %t66 = load i64, ptr %t65, !tbaa !24
  store i64 %t66, ptr %l7, !tbaa !24
  store ptr %l4, ptr %l36, !tbaa !29
  %t68 = load ptr, ptr %l3, !tbaa !29
  %t70 = getelementptr %"compiler/diag:Item", ptr %t68, i32 0, i32 4
  %t71 = load i64, ptr %t70, !tbaa !24
  %t72 = load ptr, ptr %l3, !tbaa !29
  %t74 = getelementptr %"compiler/diag:Item", ptr %t72, i32 0, i32 3
  %t75 = load i64, ptr %t74, !tbaa !24
  %t78 = icmp sgt i64 %t71, %t75
  br i1 %t78, label %bb12, label %bb13
bb12:
  %t80 = load ptr, ptr %l3, !tbaa !29
  %t82 = getelementptr %"compiler/diag:Item", ptr %t80, i32 0, i32 4
  %t83 = load i64, ptr %t82, !tbaa !24
  store i64 %t83, ptr %l42, !tbaa !24
  br label %bb14
bb13:
  %t85 = load ptr, ptr %l3, !tbaa !29
  %t87 = getelementptr %"compiler/diag:Item", ptr %t85, i32 0, i32 3
  %t88 = load i64, ptr %t87, !tbaa !24
  store i64 %t88, ptr %l42, !tbaa !24
  br label %bb14
bb14:
  %t90 = load ptr, ptr %l36, !tbaa !29
  %t91 = load i64, ptr %l42, !tbaa !24
  %t92 = call { i64, i64 } @compiler_2fsession_2ecompiler_2fsession_3aPositions_2ePos(ptr %s1, ptr %t90, i64 %t91)
  store { i64, i64 } %t92, ptr %l47
  br label %bb15
bb15:
  %t93 = load { i64, i64 }, ptr %l47
  store { i64, i64 } %t93, ptr %l8
  %t94 = getelementptr { i64, i64 }, ptr %l8, i32 0, i32 0
  %t95 = load i64, ptr %t94, !tbaa !24
  %t97 = getelementptr { i64, i64 }, ptr %l8, i32 0, i32 1
  %t98 = load i64, ptr %t97, !tbaa !24
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t101 = load i64, ptr %l6, !tbaa !24
  %t103 = add i64 %t101, 1
  %t104 = load i64, ptr %l7, !tbaa !24
  %t106 = add i64 %t104, 1
  %t109 = add i64 %t95, 1
  %t112 = add i64 %t98, 1
  %t113 = extractvalue { i64, ptr } { i64 8, ptr @.d101 }, 1
  %t114 = extractvalue { i64, ptr } { i64 8, ptr @.d101 }, 0
  %t116 = call i64 @__olang_fmt_i64(ptr null, i64 %t103)
  %t117 = add i64 %t114, %t116
  %t118 = extractvalue { i64, ptr } { i64 10, ptr @.d102 }, 1
  %t119 = extractvalue { i64, ptr } { i64 10, ptr @.d102 }, 0
  %t120 = add i64 %t117, %t119
  %t122 = call i64 @__olang_fmt_i64(ptr null, i64 %t106)
  %t123 = add i64 %t120, %t122
  %t124 = extractvalue { i64, ptr } { i64 11, ptr @.d103 }, 1
  %t125 = extractvalue { i64, ptr } { i64 11, ptr @.d103 }, 0
  %t126 = add i64 %t123, %t125
  %t128 = call i64 @__olang_fmt_i64(ptr null, i64 %t109)
  %t129 = add i64 %t126, %t128
  %t130 = extractvalue { i64, ptr } { i64 13, ptr @.d104 }, 1
  %t131 = extractvalue { i64, ptr } { i64 13, ptr @.d104 }, 0
  %t132 = add i64 %t129, %t131
  %t134 = call i64 @__olang_fmt_i64(ptr null, i64 %t112)
  %t135 = add i64 %t132, %t134
  %t136 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t135)
  call void @olang_textcopy(ptr %t136, ptr %t113, i64 %t114)
  %t137 = getelementptr i8, ptr %t136, i64 %t114
  %t138 = call i64 @__olang_fmt_i64(ptr %t137, i64 %t103)
  %t139 = getelementptr i8, ptr %t137, i64 %t116
  call void @olang_textcopy(ptr %t139, ptr %t118, i64 %t119)
  %t140 = getelementptr i8, ptr %t139, i64 %t119
  %t141 = call i64 @__olang_fmt_i64(ptr %t140, i64 %t106)
  %t142 = getelementptr i8, ptr %t140, i64 %t122
  call void @olang_textcopy(ptr %t142, ptr %t124, i64 %t125)
  %t143 = getelementptr i8, ptr %t142, i64 %t125
  %t144 = call i64 @__olang_fmt_i64(ptr %t143, i64 %t109)
  %t145 = getelementptr i8, ptr %t143, i64 %t128
  call void @olang_textcopy(ptr %t145, ptr %t130, i64 %t131)
  %t146 = getelementptr i8, ptr %t145, i64 %t131
  %t147 = call i64 @__olang_fmt_i64(ptr %t146, i64 %t112)
  %t148 = insertvalue { i64, ptr } undef, i64 %t135, 0
  %t149 = insertvalue { i64, ptr } %t148, ptr %t136, 1
  %t151 = extractvalue { i64, ptr } %t149, 0
  %t152 = extractvalue { i64, ptr } %t149, 1
  %t153 = mul i64 %t151, 1
  %t154 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t153)
  call void @llvm.memcpy.p0.p0.i64(ptr %t154, ptr %t152, i64 %t153, i1 false)
  %t155 = insertvalue { i64, ptr } undef, i64 %t151, 0
  %t156 = insertvalue { i64, ptr } %t155, ptr %t154, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s1, ptr %t100, { i64, ptr } %t156)
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s1)
  br label %bb21
bb17:
  store %olang.scope zeroinitializer, ptr %s4
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t160 = load ptr, ptr %l3, !tbaa !29
  %t162 = getelementptr %"compiler/diag:Item", ptr %t160, i32 0, i32 5
  %t163 = load i64, ptr %t162, !tbaa !24
  %t164 = extractvalue { i64, ptr } { i64 8, ptr @.d105 }, 1
  %t165 = extractvalue { i64, ptr } { i64 8, ptr @.d105 }, 0
  %t167 = call i64 @__olang_fmt_i64(ptr null, i64 %t163)
  %t168 = add i64 %t165, %t167
  %t169 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t168)
  call void @olang_textcopy(ptr %t169, ptr %t164, i64 %t165)
  %t170 = getelementptr i8, ptr %t169, i64 %t165
  %t171 = call i64 @__olang_fmt_i64(ptr %t170, i64 %t163)
  %t172 = insertvalue { i64, ptr } undef, i64 %t168, 0
  %t173 = insertvalue { i64, ptr } %t172, ptr %t169, 1
  %t175 = extractvalue { i64, ptr } %t173, 0
  %t176 = extractvalue { i64, ptr } %t173, 1
  %t177 = mul i64 %t175, 1
  %t178 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t177)
  call void @llvm.memcpy.p0.p0.i64(ptr %t178, ptr %t176, i64 %t177, i1 false)
  %t179 = insertvalue { i64, ptr } undef, i64 %t175, 0
  %t180 = insertvalue { i64, ptr } %t179, ptr %t178, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s4, ptr %t159, { i64, ptr } %t180)
  br label %bb19
bb18:
  br label %bb20
bb19:
  call void @__olang_scope_close(ptr %s4)
  br label %bb20
bb20:
  br label %bb21
bb21:
  %t183 = load ptr, ptr %l3, !tbaa !29
  %t185 = getelementptr %"compiler/diag:Item", ptr %t183, i32 0, i32 1
  %t186 = load { i64, ptr }, ptr %t185, !tbaa !27
  %t188 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v3, ptr %s0, { i64, ptr } %t186, { i64, ptr } { i64 0, ptr @.d106 })
  store i1 %t188, ptr %l71
  br label %bb22
bb22:
  %t189 = load i1, ptr %l71, !tbaa !21
  %t190 = xor i1 %t189, true
  br i1 %t190, label %bb23, label %bb24
bb23:
  store %olang.scope zeroinitializer, ptr %s6
  %t192 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s6, ptr %t192, { i64, ptr } { i64 8, ptr @.d107 })
  br label %bb25
bb24:
  br label %bb27
bb25:
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t195 = load ptr, ptr %l3, !tbaa !29
  %t197 = getelementptr %"compiler/diag:Item", ptr %t195, i32 0, i32 1
  %t198 = load { i64, ptr }, ptr %t197, !tbaa !27
  call void @compiler_2fsession_2eJsonStr(ptr %v0, ptr %v3, ptr %t194, { i64, ptr } %t198)
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s6)
  br label %bb27
bb27:
  %t201 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s0, ptr %t201, { i64, ptr } { i64 11, ptr @.d108 })
  br label %bb28
bb28:
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t204 = load ptr, ptr %l3, !tbaa !29
  %t206 = getelementptr %"compiler/diag:Item", ptr %t204, i32 0, i32 6
  %t207 = load { i64, ptr }, ptr %t206, !tbaa !27
  call void @compiler_2fsession_2eJsonStr(ptr %v0, ptr %v3, ptr %t203, { i64, ptr } %t207)
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fmcp_2ereply(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 22, ptr @.d109 }, 1
  %t4 = extractvalue { i64, ptr } { i64 22, ptr @.d109 }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 10, ptr @.d110 }, 1
  %t10 = extractvalue { i64, ptr } { i64 10, ptr @.d110 }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 1, ptr @.d111 }, 1
  %t17 = extractvalue { i64, ptr } { i64 1, ptr @.d111 }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  store { i64, ptr } %t25, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fmcp_2erun(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, { i64, ptr } %a0, { i64, ptr } %a1, i1 %a2, { i64, ptr } %a3, { i64, ptr } %a4, ptr %a5) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i1
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l16 = alloca i1
  %l17 = alloca i1
  %l19 = alloca i1
  %l22 = alloca { i64, ptr }
  %l25 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l27 = alloca ptr
  %l29 = alloca { i64, ptr }
  %l35 = alloca i1
  %l37 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l42 = alloca i32
  %l48 = alloca { i64, ptr }
  %l49 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %l53 = alloca i32
  %l57 = alloca { i64, ptr }
  %l59 = alloca { i64, ptr }
  %l60 = alloca %"compiler/diag:Diagnostics"
  %l66 = alloca ptr
  %l68 = alloca i1
  %l71 = alloca { i64, ptr }
  %l73 = alloca i64
  %l75 = alloca i1
  %l79 = alloca i1
  %l84 = alloca { i64, ptr }
  %l86 = alloca { i64, ptr }
  %l89 = alloca { i64, ptr }
  %l91 = alloca i1
  %l92 = alloca { i64, ptr }
  %l97 = alloca ptr
  %l102 = alloca ptr
  %l112 = alloca { i64, ptr }
  %l113 = alloca i32
  %l120 = alloca { i64, ptr }
  %l122 = alloca { i64, ptr }
  %l124 = alloca i1
  %l126 = alloca { i64, ptr }
  %l131 = alloca ptr
  %l136 = alloca ptr
  %l146 = alloca { i64, ptr }
  %l147 = alloca i32
  %l154 = alloca { i64, ptr }
  %l156 = alloca { i64, ptr }
  %l161 = alloca ptr
  %l166 = alloca ptr
  %l175 = alloca %"compiler/doc:Module"
  %l177 = alloca { i64, ptr }
  %l179 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t142 = alloca %"compiler/diag:Diagnostics", align 8
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store i1 %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t1, ptr %l6, !tbaa !27
  %t3 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t5 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t3, { i64, ptr } { i64 3, ptr @.d112 })
  store i1 %t5, ptr %l16
  br label %bb1
bb1:
  %t6 = load i1, ptr %l16, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  %t7 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t9 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v1, ptr %s0, { i64, ptr } %t7, { i64, ptr } { i64 6, ptr @.d113 })
  store i1 %t9, ptr %l19
  br label %bb4
bb3:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb5
bb4:
  %t10 = load i1, ptr %l19, !tbaa !21
  %t11 = xor i1 %t10, true
  store i1 %t11, ptr %l17, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l17, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s1
  %t14 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t16 = call { i64, ptr } @compiler_2fsession_2eStdModule(ptr %v1, ptr %s1, { i64, ptr } %t14)
  store { i64, ptr } %t16, ptr %l22
  br label %bb8
bb7:
  br label %bb9
bb8:
  %t17 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t17, 1
  %t19 = extractvalue { i64, ptr } %t17, 0
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @olang_textcopy(ptr %t20, ptr %t18, i64 %t19)
  %t21 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t24 = extractvalue { i64, ptr } %t22, 0
  %t25 = extractvalue { i64, ptr } %t22, 1
  %t26 = mul i64 %t24, 1
  %t27 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t26)
  call void @llvm.memcpy.p0.p0.i64(ptr %t27, ptr %t25, i64 %t26, i1 false)
  %t28 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t27, 1
  store { i64, ptr } %t29, ptr %l6, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  br label %bb9
bb9:
  %t31 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t31, ptr %l25
  br label %bb10
bb10:
  %t32 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l25
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t32, ptr %l7
  %t33 = load i1, ptr %l2, !tbaa !21
  br i1 %t33, label %bb11, label %bb12
bb11:
  store ptr %l7, ptr %l27, !tbaa !29
  %t35 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t37 = call { i64, ptr } @compiler_2fsession_2eRealOf(ptr %v1, ptr %s0, { i64, ptr } %t35)
  store { i64, ptr } %t37, ptr %l29
  br label %bb13
bb12:
  br label %bb15
bb13:
  %t38 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t38, 0
  %t40 = extractvalue { i64, ptr } %t38, 1
  %t41 = mul i64 %t39, 1
  %t42 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t41)
  call void @llvm.memcpy.p0.p0.i64(ptr %t42, ptr %t40, i64 %t41, i1 false)
  %t43 = insertvalue { i64, ptr } undef, i64 %t39, 0
  %t44 = insertvalue { i64, ptr } %t43, ptr %t42, 1
  %t45 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t47 = extractvalue { i64, ptr } %t45, 1
  %t48 = extractvalue { i64, ptr } %t45, 0
  %t49 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t48)
  call void @olang_textcopy(ptr %t49, ptr %t47, i64 %t48)
  %t50 = insertvalue { i64, ptr } undef, i64 %t48, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t49, 1
  %t53 = extractvalue { i64, ptr } %t51, 0
  %t54 = extractvalue { i64, ptr } %t51, 1
  %t55 = mul i64 %t53, 1
  %t56 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t55)
  call void @llvm.memcpy.p0.p0.i64(ptr %t56, ptr %t54, i64 %t55, i1 false)
  %t57 = insertvalue { i64, ptr } undef, i64 %t53, 0
  %t58 = insertvalue { i64, ptr } %t57, ptr %t56, 1
  %t59 = load ptr, ptr %l27, !tbaa !29
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6f7a2f8d839c49b6e7a19c287d4b190c(ptr %s0, ptr %s0, ptr %s0, ptr %t59, { i64, ptr } %t44, { i64, ptr } %t58)
  br label %bb14
bb14:
  br label %bb15
bb15:
  %t62 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t64 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t62, { i64, ptr } { i64 6, ptr @.d114 })
  store i1 %t64, ptr %l35
  br label %bb16
bb16:
  %t65 = load i1, ptr %l35, !tbaa !21
  br i1 %t65, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s5
  %t66 = load i1, ptr %l2, !tbaa !21
  br i1 %t66, label %bb19, label %bb20
bb18:
  br label %bb35
bb19:
  %t68 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t68, ptr %l37, !tbaa !27
  br label %bb28
bb20:
  %t70 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t72 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v1, ptr %v2, { i64, ptr } %t70)
  %t73 = extractvalue { i32, { i64, ptr } } %t72, 1
  %t74 = extractvalue { i32, { i64, ptr } } %t72, 0
  store i32 %t74, ptr %l42
  %t75 = icmp ne i32 %t74, 0
  br i1 %t75, label %bb22, label %ok.76
ok.76:
  store { i64, ptr } %t73, ptr %l41
  br label %bb21
bb21:
  %t77 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t77, ptr %l39, !tbaa !27
  br label %bb27
bb22:
  %t78 = load i32, ptr %l42, !tbaa !23
  %t79 = ashr i32 %t78, 16
  %t81 = icmp eq i32 %t79, 1
  br i1 %t81, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_648a8f9a00cb525a_35c2b76f6215b926)
  unreachable
bb25:
  call void @__olang_ert_req_clear()
  %t83 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t84 = extractvalue { i64, ptr } { i64 12, ptr @.d115 }, 1
  %t85 = extractvalue { i64, ptr } { i64 12, ptr @.d115 }, 0
  %t87 = extractvalue { i64, ptr } %t83, 1
  %t88 = extractvalue { i64, ptr } %t83, 0
  %t89 = add i64 %t85, %t88
  %t90 = call ptr @__olang_scope_alloc(ptr %v5, i64 %t89)
  call void @olang_textcopy(ptr %t90, ptr %t84, i64 %t85)
  %t91 = getelementptr i8, ptr %t90, i64 %t85
  call void @olang_textcopy(ptr %t91, ptr %t87, i64 %t88)
  %t92 = insertvalue { i64, ptr } undef, i64 %t89, 0
  %t93 = insertvalue { i64, ptr } %t92, ptr %t90, 1
  %t95 = extractvalue { i64, ptr } %t93, 0
  %t96 = extractvalue { i64, ptr } %t93, 1
  %t97 = mul i64 %t95, 1
  %t98 = call ptr @__olang_scope_alloc(ptr %v5, i64 %t97)
  call void @llvm.memcpy.p0.p0.i64(ptr %t98, ptr %t96, i64 %t97, i1 false)
  %t99 = insertvalue { i64, ptr } undef, i64 %t95, 0
  %t100 = insertvalue { i64, ptr } %t99, ptr %t98, 1
  %t102 = call { i64, ptr } @compiler_2fmcp_2etoolError(ptr %v5, ptr %v5, { i64, ptr } %t100)
  store { i64, ptr } %t102, ptr %l48
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t103 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t103, ptr %rv
  br label %ret
bb27:
  %t104 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t104, ptr %l37, !tbaa !27
  br label %bb28
bb28:
  %t105 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t106 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t110 = call { i32, { i64, ptr } } @compiler_2fsession_2eFormat(ptr %v1, ptr %v2, ptr %s5, { i64, ptr } %t106, { i64, ptr } %t105)
  %t111 = extractvalue { i32, { i64, ptr } } %t110, 1
  %t112 = extractvalue { i32, { i64, ptr } } %t110, 0
  store i32 %t112, ptr %l53
  %t113 = icmp ne i32 %t112, 0
  br i1 %t113, label %bb30, label %ok.114
ok.114:
  store { i64, ptr } %t111, ptr %l52
  br label %bb29
bb29:
  %t115 = load { i64, ptr }, ptr %l52, !tbaa !27
  store { i64, ptr } %t115, ptr %l49, !tbaa !27
  br label %bb33
bb30:
  br label %bb31
bb31:
  call void @__olang_ert_req_clear()
  %t116 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t118 = extractvalue { i64, ptr } %t116, 1
  %t119 = extractvalue { i64, ptr } %t116, 0
  %t120 = extractvalue { i64, ptr } { i64 46, ptr @.d116 }, 1
  %t121 = extractvalue { i64, ptr } { i64 46, ptr @.d116 }, 0
  %t122 = add i64 %t119, %t121
  %t123 = call ptr @__olang_scope_alloc(ptr %v5, i64 %t122)
  call void @olang_textcopy(ptr %t123, ptr %t118, i64 %t119)
  %t124 = getelementptr i8, ptr %t123, i64 %t119
  call void @olang_textcopy(ptr %t124, ptr %t120, i64 %t121)
  %t125 = insertvalue { i64, ptr } undef, i64 %t122, 0
  %t126 = insertvalue { i64, ptr } %t125, ptr %t123, 1
  %t128 = extractvalue { i64, ptr } %t126, 0
  %t129 = extractvalue { i64, ptr } %t126, 1
  %t130 = mul i64 %t128, 1
  %t131 = call ptr @__olang_scope_alloc(ptr %v5, i64 %t130)
  call void @llvm.memcpy.p0.p0.i64(ptr %t131, ptr %t129, i64 %t130, i1 false)
  %t132 = insertvalue { i64, ptr } undef, i64 %t128, 0
  %t133 = insertvalue { i64, ptr } %t132, ptr %t131, 1
  %t135 = call { i64, ptr } @compiler_2fmcp_2etextResult(ptr %v5, ptr %v5, { i64, ptr } %t133, i1 true)
  store { i64, ptr } %t135, ptr %l57
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t136 = load { i64, ptr }, ptr %l57, !tbaa !27
  store { i64, ptr } %t136, ptr %rv
  br label %ret
bb33:
  %t137 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t140 = call { i64, ptr } @compiler_2fmcp_2etextResult(ptr %s5, ptr %v5, { i64, ptr } %t137, i1 false)
  store { i64, ptr } %t140, ptr %l59
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t141 = load { i64, ptr }, ptr %l59, !tbaa !27
  store { i64, ptr } %t141, ptr %rv
  br label %ret
bb35:
  call void @compiler_2fdiag_3aDiagnostics_2ector(ptr %t142, ptr %v4, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l60, ptr %t142, i64 200, i1 false)
  br label %bb36
bb36:
  %t143 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 200, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t143, ptr %l60, i64 200, i1 false)
  store ptr %t143, ptr %l10, !tbaa !29
  %t145 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t147 = load ptr, ptr %l10, !tbaa !29
  %t152 = call ptr @compiler_2fsession_2eAnalyze(ptr %v1, ptr %v4, ptr %s0, { i64, ptr } %t145, ptr %a5, ptr %t147, ptr %l7, i1 true)
  store ptr %t152, ptr %l66
  br label %bb37
bb37:
  %t153 = load ptr, ptr %l66, !tbaa !29
  store ptr %t153, ptr %l11, !tbaa !29
  %t154 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t156 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t154, { i64, ptr } { i64 5, ptr @.d117 })
  store i1 %t156, ptr %l68
  br label %bb38
bb38:
  %t157 = load i1, ptr %l68, !tbaa !21
  br i1 %t157, label %bb39, label %bb40
bb39:
  %t158 = load ptr, ptr %l11, !tbaa !29
  %t159 = load ptr, ptr %l10, !tbaa !29
  %t162 = call { i64, ptr } @compiler_2fmcp_2echeckResult(ptr %v4, ptr %v4, ptr %v5, ptr %t158, ptr %t159)
  store { i64, ptr } %t162, ptr %l71
  br label %bb41
bb40:
  br label %bb42
bb41:
  call void @__olang_scope_close(ptr %s0)
  %t163 = load { i64, ptr }, ptr %l71, !tbaa !27
  store { i64, ptr } %t163, ptr %rv
  br label %ret
bb42:
  %t164 = load ptr, ptr %l10, !tbaa !29
  %t166 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v4, ptr %t164)
  store i64 %t166, ptr %l73
  br label %bb43
bb43:
  %t167 = load i64, ptr %l73, !tbaa !24
  %t168 = icmp sgt i64 %t167, 0
  br i1 %t168, label %bb44, label %bb45
bb44:
  store i1 true, ptr %l75, !tbaa !21
  br label %bb46
bb45:
  %t170 = load ptr, ptr %l11, !tbaa !29
  %t172 = getelementptr %"compiler/session:Analysis", ptr %t170, i32 0, i32 1
  %t173 = load ptr, ptr %t172, !tbaa !29
  %t175 = icmp eq ptr %t173, null
  store i1 %t175, ptr %l75, !tbaa !21
  br label %bb46
bb46:
  %t177 = load i1, ptr %l75, !tbaa !21
  br i1 %t177, label %bb47, label %bb48
bb47:
  store i1 true, ptr %l79, !tbaa !21
  br label %bb49
bb48:
  %t178 = load ptr, ptr %l11, !tbaa !29
  %t180 = getelementptr %"compiler/session:Analysis", ptr %t178, i32 0, i32 2
  %t181 = load ptr, ptr %t180, !tbaa !29
  %t183 = icmp eq ptr %t181, null
  store i1 %t183, ptr %l79, !tbaa !21
  br label %bb49
bb49:
  %t185 = load i1, ptr %l79, !tbaa !21
  br i1 %t185, label %bb50, label %bb51
bb50:
  store %olang.scope zeroinitializer, ptr %s11
  %t186 = load ptr, ptr %l10, !tbaa !29
  %t188 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eRender(ptr %v4, ptr %s11, ptr %t186)
  store { i64, ptr } %t188, ptr %l84
  br label %bb52
bb51:
  br label %bb55
bb52:
  %t189 = load ptr, ptr %l10, !tbaa !29
  %t191 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eSummary(ptr %v4, ptr %s11, ptr %t189)
  store { i64, ptr } %t191, ptr %l86
  br label %bb53
bb53:
  %t192 = load { i64, ptr }, ptr %l84, !tbaa !27
  %t193 = extractvalue { i64, ptr } %t192, 1
  %t194 = extractvalue { i64, ptr } %t192, 0
  %t195 = load { i64, ptr }, ptr %l86, !tbaa !27
  %t196 = extractvalue { i64, ptr } %t195, 1
  %t197 = extractvalue { i64, ptr } %t195, 0
  %t198 = add i64 %t194, %t197
  %t199 = call ptr @__olang_scope_alloc(ptr %v5, i64 %t198)
  call void @olang_textcopy(ptr %t199, ptr %t193, i64 %t194)
  %t200 = getelementptr i8, ptr %t199, i64 %t194
  call void @olang_textcopy(ptr %t200, ptr %t196, i64 %t197)
  %t201 = insertvalue { i64, ptr } undef, i64 %t198, 0
  %t202 = insertvalue { i64, ptr } %t201, ptr %t199, 1
  %t204 = extractvalue { i64, ptr } %t202, 0
  %t205 = extractvalue { i64, ptr } %t202, 1
  %t206 = mul i64 %t204, 1
  %t207 = call ptr @__olang_scope_alloc(ptr %v5, i64 %t206)
  call void @llvm.memcpy.p0.p0.i64(ptr %t207, ptr %t205, i64 %t206, i1 false)
  %t208 = insertvalue { i64, ptr } undef, i64 %t204, 0
  %t209 = insertvalue { i64, ptr } %t208, ptr %t207, 1
  %t211 = call { i64, ptr } @compiler_2fmcp_2etextResult(ptr %v5, ptr %v5, { i64, ptr } %t209, i1 true)
  store { i64, ptr } %t211, ptr %l89
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s0)
  %t212 = load { i64, ptr }, ptr %l89, !tbaa !27
  store { i64, ptr } %t212, ptr %rv
  br label %ret
bb55:
  %t213 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t215 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t213, { i64, ptr } { i64 7, ptr @.d118 })
  store i1 %t215, ptr %l91
  br label %bb56
bb56:
  %t216 = load i1, ptr %l91, !tbaa !21
  br i1 %t216, label %bb57, label %bb58
bb57:
  store %olang.scope zeroinitializer, ptr %s13
  %t217 = load ptr, ptr %l11, !tbaa !29
  %t219 = getelementptr %"compiler/session:Analysis", ptr %t217, i32 0, i32 1
  %t220 = load ptr, ptr %t219, !tbaa !29
  %t222 = icmp eq ptr %t220, null
  br i1 %t222, label %bb59, label %bb60
bb58:
  br label %bb76
bb59:
  call void @__olang_check_failed(ptr @olang_loc_fd6ee713b6cd3a34_3a725fec10b02c40)
  unreachable
bb60:
  br label %bb61
bb61:
  %t224 = load ptr, ptr %l11, !tbaa !29
  %t226 = getelementptr %"compiler/session:Analysis", ptr %t224, i32 0, i32 1
  %t227 = load ptr, ptr %t226, !tbaa !29
  store ptr %t227, ptr %l97, !tbaa !29
  %t228 = load ptr, ptr %l11, !tbaa !29
  %t230 = getelementptr %"compiler/session:Analysis", ptr %t228, i32 0, i32 2
  %t231 = load ptr, ptr %t230, !tbaa !29
  %t233 = icmp eq ptr %t231, null
  br i1 %t233, label %bb62, label %bb63
bb62:
  call void @__olang_check_failed(ptr @olang_loc_fd6ee713b6cd3a34_3a725fec10b02c40)
  unreachable
bb63:
  br label %bb64
bb64:
  %t235 = load ptr, ptr %l11, !tbaa !29
  %t237 = getelementptr %"compiler/session:Analysis", ptr %t235, i32 0, i32 2
  %t238 = load ptr, ptr %t237, !tbaa !29
  store ptr %t238, ptr %l102, !tbaa !29
  %t239 = load ptr, ptr %l11, !tbaa !29
  %t241 = getelementptr %"compiler/session:Analysis", ptr %t239, i32 0, i32 3
  %t242 = load ptr, ptr %t241, !tbaa !29
  %t244 = icmp eq ptr %t242, null
  br i1 %t244, label %bb65, label %bb66
bb65:
  call void @__olang_check_failed(ptr @olang_loc_fd6ee713b6cd3a34_3a725fec10b02c40)
  unreachable
bb66:
  br label %bb67
bb67:
  %t246 = load ptr, ptr %l11, !tbaa !29
  %t248 = getelementptr %"compiler/session:Analysis", ptr %t246, i32 0, i32 3
  %t249 = load ptr, ptr %t248, !tbaa !29
  %t250 = load ptr, ptr %l11, !tbaa !29
  %t252 = getelementptr %"compiler/session:Analysis", ptr %t250, i32 0, i32 0
  %t253 = load ptr, ptr %t252, !tbaa !29
  %t255 = getelementptr %"compiler/load:Loader", ptr %t253, i32 0, i32 7
  %t256 = load i64, ptr %t255, !tbaa !24
  %t257 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t258 = load ptr, ptr %l97, !tbaa !29
  %t259 = load ptr, ptr %l102, !tbaa !29
  %t263 = call { i32, { i64, ptr } } @compiler_2fexplain_2eItem(ptr %v4, ptr %v4, ptr %v4, ptr %v3, ptr %s13, ptr %t258, ptr %t259, ptr %t249, i64 %t256, { i64, ptr } %t257)
  %t264 = extractvalue { i32, { i64, ptr } } %t263, 1
  %t265 = extractvalue { i32, { i64, ptr } } %t263, 0
  store i32 %t265, ptr %l113
  %t266 = icmp ne i32 %t265, 0
  br i1 %t266, label %bb69, label %ok.267
ok.267:
  store { i64, ptr } %t264, ptr %l112
  br label %bb68
bb68:
  %t268 = load { i64, ptr }, ptr %l112, !tbaa !27
  store { i64, ptr } %t268, ptr %l92, !tbaa !27
  br label %bb74
bb69:
  %t269 = load i32, ptr %l113, !tbaa !23
  %t270 = ashr i32 %t269, 16
  %t272 = icmp eq i32 %t270, 1
  br i1 %t272, label %bb70, label %bb71
bb70:
  br label %bb72
bb71:
  call void @__olang_check_failed(ptr @olang_loc_b158e1e8f275dc60_3861351c1a443b8c)
  unreachable
bb72:
  call void @__olang_ert_req_clear()
  %t274 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t275 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t276 = extractvalue { i64, ptr } { i64 1, ptr @.d119 }, 1
  %t277 = extractvalue { i64, ptr } { i64 1, ptr @.d119 }, 0
  %t279 = extractvalue { i64, ptr } %t274, 1
  %t280 = extractvalue { i64, ptr } %t274, 0
  %t281 = add i64 %t277, %t280
  %t282 = extractvalue { i64, ptr } { i64 26, ptr @.d120 }, 1
  %t283 = extractvalue { i64, ptr } { i64 26, ptr @.d120 }, 0
  %t284 = add i64 %t281, %t283
  %t286 = extractvalue { i64, ptr } %t275, 1
  %t287 = extractvalue { i64, ptr } %t275, 0
  %t288 = add i64 %t284, %t287
  %t289 = call ptr @__olang_scope_alloc(ptr %v5, i64 %t288)
  call void @olang_textcopy(ptr %t289, ptr %t276, i64 %t277)
  %t290 = getelementptr i8, ptr %t289, i64 %t277
  call void @olang_textcopy(ptr %t290, ptr %t279, i64 %t280)
  %t291 = getelementptr i8, ptr %t290, i64 %t280
  call void @olang_textcopy(ptr %t291, ptr %t282, i64 %t283)
  %t292 = getelementptr i8, ptr %t291, i64 %t283
  call void @olang_textcopy(ptr %t292, ptr %t286, i64 %t287)
  %t293 = insertvalue { i64, ptr } undef, i64 %t288, 0
  %t294 = insertvalue { i64, ptr } %t293, ptr %t289, 1
  %t296 = extractvalue { i64, ptr } %t294, 0
  %t297 = extractvalue { i64, ptr } %t294, 1
  %t298 = mul i64 %t296, 1
  %t299 = call ptr @__olang_scope_alloc(ptr %v5, i64 %t298)
  call void @llvm.memcpy.p0.p0.i64(ptr %t299, ptr %t297, i64 %t298, i1 false)
  %t300 = insertvalue { i64, ptr } undef, i64 %t296, 0
  %t301 = insertvalue { i64, ptr } %t300, ptr %t299, 1
  %t303 = call { i64, ptr } @compiler_2fmcp_2etextResult(ptr %v5, ptr %v5, { i64, ptr } %t301, i1 true)
  store { i64, ptr } %t303, ptr %l120
  br label %bb73
bb73:
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s0)
  %t304 = load { i64, ptr }, ptr %l120, !tbaa !27
  store { i64, ptr } %t304, ptr %rv
  br label %ret
bb74:
  %t305 = load { i64, ptr }, ptr %l92, !tbaa !27
  %t308 = call { i64, ptr } @compiler_2fmcp_2etextResult(ptr %s13, ptr %v5, { i64, ptr } %t305, i1 false)
  store { i64, ptr } %t308, ptr %l122
  br label %bb75
bb75:
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s0)
  %t309 = load { i64, ptr }, ptr %l122, !tbaa !27
  store { i64, ptr } %t309, ptr %rv
  br label %ret
bb76:
  %t310 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t312 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v3, ptr %s0, { i64, ptr } %t310, { i64, ptr } { i64 0, ptr @.d121 })
  store i1 %t312, ptr %l124
  br label %bb77
bb77:
  %t313 = load i1, ptr %l124, !tbaa !21
  %t314 = xor i1 %t313, true
  br i1 %t314, label %bb78, label %bb79
bb78:
  store %olang.scope zeroinitializer, ptr %s16
  %t316 = load ptr, ptr %l11, !tbaa !29
  %t318 = getelementptr %"compiler/session:Analysis", ptr %t316, i32 0, i32 1
  %t319 = load ptr, ptr %t318, !tbaa !29
  %t321 = icmp eq ptr %t319, null
  br i1 %t321, label %bb80, label %bb81
bb79:
  br label %bb97
bb80:
  call void @__olang_check_failed(ptr @olang_loc_914d84508fdf5042_16c39655cf5e6ae)
  unreachable
bb81:
  br label %bb82
bb82:
  %t323 = load ptr, ptr %l11, !tbaa !29
  %t325 = getelementptr %"compiler/session:Analysis", ptr %t323, i32 0, i32 1
  %t326 = load ptr, ptr %t325, !tbaa !29
  store ptr %t326, ptr %l131, !tbaa !29
  %t327 = load ptr, ptr %l11, !tbaa !29
  %t329 = getelementptr %"compiler/session:Analysis", ptr %t327, i32 0, i32 2
  %t330 = load ptr, ptr %t329, !tbaa !29
  %t332 = icmp eq ptr %t330, null
  br i1 %t332, label %bb83, label %bb84
bb83:
  call void @__olang_check_failed(ptr @olang_loc_914d84508fdf5042_16c39655cf5e6ae)
  unreachable
bb84:
  br label %bb85
bb85:
  %t334 = load ptr, ptr %l11, !tbaa !29
  %t336 = getelementptr %"compiler/session:Analysis", ptr %t334, i32 0, i32 2
  %t337 = load ptr, ptr %t336, !tbaa !29
  store ptr %t337, ptr %l136, !tbaa !29
  %t338 = load ptr, ptr %l11, !tbaa !29
  %t340 = getelementptr %"compiler/session:Analysis", ptr %t338, i32 0, i32 3
  %t341 = load ptr, ptr %t340, !tbaa !29
  %t343 = icmp eq ptr %t341, null
  br i1 %t343, label %bb86, label %bb87
bb86:
  call void @__olang_check_failed(ptr @olang_loc_914d84508fdf5042_16c39655cf5e6ae)
  unreachable
bb87:
  br label %bb88
bb88:
  %t345 = load ptr, ptr %l11, !tbaa !29
  %t347 = getelementptr %"compiler/session:Analysis", ptr %t345, i32 0, i32 3
  %t348 = load ptr, ptr %t347, !tbaa !29
  %t349 = load ptr, ptr %l11, !tbaa !29
  %t351 = getelementptr %"compiler/session:Analysis", ptr %t349, i32 0, i32 0
  %t352 = load ptr, ptr %t351, !tbaa !29
  %t354 = getelementptr %"compiler/load:Loader", ptr %t352, i32 0, i32 7
  %t355 = load i64, ptr %t354, !tbaa !24
  %t356 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t357 = load ptr, ptr %l131, !tbaa !29
  %t358 = load ptr, ptr %l136, !tbaa !29
  %t362 = call { i32, { i64, ptr } } @compiler_2fdoc_2eItemText(ptr %v4, ptr %v4, ptr %v4, ptr %v3, ptr %s16, ptr %t357, ptr %t358, ptr %t348, i64 %t355, { i64, ptr } %t356)
  %t363 = extractvalue { i32, { i64, ptr } } %t362, 1
  %t364 = extractvalue { i32, { i64, ptr } } %t362, 0
  store i32 %t364, ptr %l147
  %t365 = icmp ne i32 %t364, 0
  br i1 %t365, label %bb90, label %ok.366
ok.366:
  store { i64, ptr } %t363, ptr %l146
  br label %bb89
bb89:
  %t367 = load { i64, ptr }, ptr %l146, !tbaa !27
  store { i64, ptr } %t367, ptr %l126, !tbaa !27
  br label %bb95
bb90:
  %t368 = load i32, ptr %l147, !tbaa !23
  %t369 = ashr i32 %t368, 16
  %t371 = icmp eq i32 %t369, 1
  br i1 %t371, label %bb91, label %bb92
bb91:
  br label %bb93
bb92:
  call void @__olang_check_failed(ptr @olang_loc_b3c3e8b04c8f1ad6_228abd84f405fb6a)
  unreachable
bb93:
  call void @__olang_ert_req_clear()
  %t373 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t374 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t375 = extractvalue { i64, ptr } { i64 1, ptr @.d122 }, 1
  %t376 = extractvalue { i64, ptr } { i64 1, ptr @.d122 }, 0
  %t378 = extractvalue { i64, ptr } %t373, 1
  %t379 = extractvalue { i64, ptr } %t373, 0
  %t380 = add i64 %t376, %t379
  %t381 = extractvalue { i64, ptr } { i64 16, ptr @.d123 }, 1
  %t382 = extractvalue { i64, ptr } { i64 16, ptr @.d123 }, 0
  %t383 = add i64 %t380, %t382
  %t385 = extractvalue { i64, ptr } %t374, 1
  %t386 = extractvalue { i64, ptr } %t374, 0
  %t387 = add i64 %t383, %t386
  %t388 = call ptr @__olang_scope_alloc(ptr %v5, i64 %t387)
  call void @olang_textcopy(ptr %t388, ptr %t375, i64 %t376)
  %t389 = getelementptr i8, ptr %t388, i64 %t376
  call void @olang_textcopy(ptr %t389, ptr %t378, i64 %t379)
  %t390 = getelementptr i8, ptr %t389, i64 %t379
  call void @olang_textcopy(ptr %t390, ptr %t381, i64 %t382)
  %t391 = getelementptr i8, ptr %t390, i64 %t382
  call void @olang_textcopy(ptr %t391, ptr %t385, i64 %t386)
  %t392 = insertvalue { i64, ptr } undef, i64 %t387, 0
  %t393 = insertvalue { i64, ptr } %t392, ptr %t388, 1
  %t395 = extractvalue { i64, ptr } %t393, 0
  %t396 = extractvalue { i64, ptr } %t393, 1
  %t397 = mul i64 %t395, 1
  %t398 = call ptr @__olang_scope_alloc(ptr %v5, i64 %t397)
  call void @llvm.memcpy.p0.p0.i64(ptr %t398, ptr %t396, i64 %t397, i1 false)
  %t399 = insertvalue { i64, ptr } undef, i64 %t395, 0
  %t400 = insertvalue { i64, ptr } %t399, ptr %t398, 1
  %t402 = call { i64, ptr } @compiler_2fmcp_2etextResult(ptr %v5, ptr %v5, { i64, ptr } %t400, i1 true)
  store { i64, ptr } %t402, ptr %l154
  br label %bb94
bb94:
  call void @__olang_scope_close(ptr %s16)
  call void @__olang_scope_close(ptr %s0)
  %t403 = load { i64, ptr }, ptr %l154, !tbaa !27
  store { i64, ptr } %t403, ptr %rv
  br label %ret
bb95:
  %t404 = load { i64, ptr }, ptr %l126, !tbaa !27
  %t407 = call { i64, ptr } @compiler_2fmcp_2etextResult(ptr %s16, ptr %v5, { i64, ptr } %t404, i1 false)
  store { i64, ptr } %t407, ptr %l156
  br label %bb96
bb96:
  call void @__olang_scope_close(ptr %s16)
  call void @__olang_scope_close(ptr %s0)
  %t408 = load { i64, ptr }, ptr %l156, !tbaa !27
  store { i64, ptr } %t408, ptr %rv
  br label %ret
bb97:
  %t409 = load ptr, ptr %l11, !tbaa !29
  %t411 = getelementptr %"compiler/session:Analysis", ptr %t409, i32 0, i32 1
  %t412 = load ptr, ptr %t411, !tbaa !29
  %t414 = icmp eq ptr %t412, null
  br i1 %t414, label %bb98, label %bb99
bb98:
  call void @__olang_check_failed(ptr @olang_loc_e5ca324f5b9892b0_241151de3839f804)
  unreachable
bb99:
  br label %bb100
bb100:
  %t416 = load ptr, ptr %l11, !tbaa !29
  %t418 = getelementptr %"compiler/session:Analysis", ptr %t416, i32 0, i32 1
  %t419 = load ptr, ptr %t418, !tbaa !29
  store ptr %t419, ptr %l161, !tbaa !29
  %t420 = load ptr, ptr %l11, !tbaa !29
  %t422 = getelementptr %"compiler/session:Analysis", ptr %t420, i32 0, i32 2
  %t423 = load ptr, ptr %t422, !tbaa !29
  %t425 = icmp eq ptr %t423, null
  br i1 %t425, label %bb101, label %bb102
bb101:
  call void @__olang_check_failed(ptr @olang_loc_e5ca324f5b9892b0_241151de3839f804)
  unreachable
bb102:
  br label %bb103
bb103:
  %t427 = load ptr, ptr %l11, !tbaa !29
  %t429 = getelementptr %"compiler/session:Analysis", ptr %t427, i32 0, i32 2
  %t430 = load ptr, ptr %t429, !tbaa !29
  store ptr %t430, ptr %l166, !tbaa !29
  %t431 = load ptr, ptr %l11, !tbaa !29
  %t433 = getelementptr %"compiler/session:Analysis", ptr %t431, i32 0, i32 3
  %t434 = load ptr, ptr %t433, !tbaa !29
  %t436 = icmp eq ptr %t434, null
  br i1 %t436, label %bb104, label %bb105
bb104:
  call void @__olang_check_failed(ptr @olang_loc_e5ca324f5b9892b0_241151de3839f804)
  unreachable
bb105:
  br label %bb106
bb106:
  %t438 = load ptr, ptr %l11, !tbaa !29
  %t440 = getelementptr %"compiler/session:Analysis", ptr %t438, i32 0, i32 3
  %t441 = load ptr, ptr %t440, !tbaa !29
  %t442 = load ptr, ptr %l11, !tbaa !29
  %t444 = getelementptr %"compiler/session:Analysis", ptr %t442, i32 0, i32 0
  %t445 = load ptr, ptr %t444, !tbaa !29
  %t447 = getelementptr %"compiler/load:Loader", ptr %t445, i32 0, i32 7
  %t448 = load i64, ptr %t447, !tbaa !24
  %t449 = load ptr, ptr %l161, !tbaa !29
  %t450 = load ptr, ptr %l166, !tbaa !29
  %t453 = call %"compiler/doc:Module" @compiler_2fdoc_2eOf(ptr %v4, ptr %v4, ptr %v4, ptr %v5, ptr %t449, ptr %t450, ptr %t441, i64 %t448, i1 false)
  store %"compiler/doc:Module" %t453, ptr %l175
  br label %bb107
bb107:
  %t454 = load %"compiler/doc:Module", ptr %l175
  %t455 = call ptr @__olang_scope_alloc_a(ptr %v5, i64 56, i64 8)
  store %"compiler/doc:Module" %t454, ptr %t455
  %t457 = call { i64, ptr } @compiler_2fdoc_2ecompiler_2fdoc_3aModule_2eText(ptr %v5, ptr %v5, ptr %t455)
  store { i64, ptr } %t457, ptr %l177
  br label %bb108
bb108:
  %t458 = load { i64, ptr }, ptr %l177, !tbaa !27
  %t459 = extractvalue { i64, ptr } %t458, 0
  %t460 = extractvalue { i64, ptr } %t458, 1
  %t461 = mul i64 %t459, 1
  %t462 = call ptr @__olang_scope_alloc(ptr %v5, i64 %t461)
  call void @llvm.memcpy.p0.p0.i64(ptr %t462, ptr %t460, i64 %t461, i1 false)
  %t463 = insertvalue { i64, ptr } undef, i64 %t459, 0
  %t464 = insertvalue { i64, ptr } %t463, ptr %t462, 1
  %t466 = call { i64, ptr } @compiler_2fmcp_2etextResult(ptr %v5, ptr %v5, { i64, ptr } %t464, i1 false)
  store { i64, ptr } %t466, ptr %l179
  br label %bb109
bb109:
  call void @__olang_scope_close(ptr %s0)
  %t467 = load { i64, ptr }, ptr %l179, !tbaa !27
  store { i64, ptr } %t467, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fmcp_2esend(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca i32
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 1, ptr @.d124 }, 1
  %t6 = extractvalue { i64, ptr } { i64 1, ptr @.d124 }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t14 = extractvalue { i64, ptr } %t11, 0
  %t15 = extractvalue { i64, ptr } %t11, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  %t21 = call i32 @std_2fio_2eWrite(ptr %s0, i32 1, { i64, ptr } %t19)
  store i32 %t21, ptr %l5
  %t22 = icmp ne i32 %t21, 0
  br i1 %t22, label %bb2, label %ok.23
ok.23:
  br label %bb1
bb1:
  br label %bb6
bb2:
  %t24 = load i32, ptr %l5, !tbaa !23
  %t25 = ashr i32 %t24, 16
  %t27 = icmp eq i32 %t25, 1
  br i1 %t27, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_check_failed(ptr @olang_loc_9371250ac8a8a79_a56c6b8809127485)
  unreachable
bb5:
  call void @__olang_ert_req_clear()
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fmcp_2estr(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca i32
  %l9 = alloca { i64, ptr }
  %l10 = alloca i32
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAt_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
  %t6 = extractvalue { i32, ptr } %t5, 1
  %t7 = extractvalue { i32, ptr } %t5, 0
  store i32 %t7, ptr %l6
  %t8 = icmp ne i32 %t7, 0
  br i1 %t8, label %bb2, label %ok.9
ok.9:
  store ptr %t6, ptr %l5
  br label %bb1
bb1:
  %t10 = load ptr, ptr %l5, !tbaa !29
  %t11 = call { i32, { i64, ptr } } @std_2fjson_2estd_2fjson_3aJson_2eAsStr(ptr %v0, ptr %t10)
  %t12 = extractvalue { i32, { i64, ptr } } %t11, 1
  %t13 = extractvalue { i32, { i64, ptr } } %t11, 0
  store i32 %t13, ptr %l10
  %t14 = icmp ne i32 %t13, 0
  br i1 %t14, label %bb7, label %ok.15
ok.15:
  store { i64, ptr } %t12, ptr %l9
  br label %bb6
bb2:
  %t16 = load i32, ptr %l6, !tbaa !23
  %t17 = ashr i32 %t16, 16
  %t19 = icmp eq i32 %t17, 1
  br i1 %t19, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_check_failed(ptr @olang_loc_90272fd1f37d718c_b0a06defe4062150)
  unreachable
bb5:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr @.d125 }, ptr %l2, !tbaa !27
  br label %bb10
bb6:
  %t21 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t21, ptr %l2, !tbaa !27
  br label %bb10
bb7:
  %t22 = load i32, ptr %l10, !tbaa !23
  %t23 = ashr i32 %t22, 16
  %t25 = icmp eq i32 %t23, 1
  br i1 %t25, label %bb8, label %bb9
bb8:
  br label %bb5
bb9:
  call void @__olang_check_failed(ptr @olang_loc_90272fd1f37d718c_b0a06defe4062150)
  unreachable
bb10:
  %t27 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t27, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fmcp_2etestResult(ptr %v0, ptr %v1, { i64, ptr } %a0, i32 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca %"std/prelude/text:LineIter"
  %l6 = alloca { i64, ptr }
  %l7 = alloca i1
  %l8 = alloca %"std/prelude/text:StringBuilder"
  %l9 = alloca %"std/prelude/text:StringBuilder"
  %l12 = alloca %"std/prelude/text:LineIter"
  %l13 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca i32
  %l20 = alloca i1
  %l23 = alloca i1
  %l25 = alloca i1
  %l36 = alloca ptr
  %l38 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l42 = alloca i64
  %l43 = alloca i64
  %l48 = alloca { i64, ptr }
  %l51 = alloca i64
  %l52 = alloca i64
  %l57 = alloca ptr
  %l59 = alloca { i64, ptr }
  %l70 = alloca %"std/prelude/text:StringBuilder"
  %l74 = alloca ptr
  %l76 = alloca { i64, ptr }
  %l79 = alloca { i64, ptr }
  %l83 = alloca { i64, ptr }
  %l84 = alloca { i64, ptr }
  %l85 = alloca i64
  %l86 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l9
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l9
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l2, { i64, ptr } { i64 10, ptr @.d126 })
  br label %bb2
bb2:
  store i64 0, ptr %l3, !tbaa !24
  store i64 0, ptr %l4, !tbaa !24
  %t4 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t6 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v0, { i64, ptr } %t4)
  store %"std/prelude/text:LineIter" %t6, ptr %l12
  br label %bb3
bb3:
  %t7 = load %"std/prelude/text:LineIter", ptr %l12
  store %"std/prelude/text:LineIter" %t7, ptr %l5
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t9 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %l5)
  %t10 = extractvalue { i32, { i64, ptr } } %t9, 1
  %t11 = extractvalue { i32, { i64, ptr } } %t9, 0
  store i32 %t11, ptr %l16
  %t12 = icmp ne i32 %t11, 0
  br i1 %t12, label %bb6, label %ok.13
ok.13:
  store { i64, ptr } %t10, ptr %l15
  br label %bb5
bb5:
  %t14 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t14, ptr %l13, !tbaa !27
  br label %bb10
bb6:
  %t15 = load i32, ptr %l16, !tbaa !23
  %t16 = ashr i32 %t15, 16
  %t18 = icmp eq i32 %t16, 1
  br i1 %t18, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_cc8720c802d496e8_1cfdfb6aa0bef724)
  unreachable
bb9:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %bb48
bb10:
  %t20 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t20, ptr %l6, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t23 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s2, { i64, ptr } %t21, { i64, ptr } { i64 5, ptr @.d127 })
  store i1 %t23, ptr %l20
  br label %bb11
bb11:
  %t24 = load i1, ptr %l20, !tbaa !21
  store i1 %t24, ptr %l7, !tbaa !21
  %t25 = load i1, ptr %l7, !tbaa !21
  %t27 = xor i1 %t25, true
  br i1 %t27, label %bb12, label %bb13
bb12:
  %t29 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t31 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s2, { i64, ptr } %t29, { i64, ptr } { i64 7, ptr @.d128 })
  store i1 %t31, ptr %l25
  br label %bb14
bb13:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb15
bb14:
  %t32 = load i1, ptr %l25, !tbaa !21
  %t33 = xor i1 %t32, true
  store i1 %t33, ptr %l23, !tbaa !21
  br label %bb15
bb15:
  %t35 = load i1, ptr %l23, !tbaa !21
  br i1 %t35, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s2)
  br label %bb47
bb17:
  br label %bb18
bb18:
  %t36 = load i64, ptr %l3, !tbaa !24
  %t38 = icmp sgt i64 %t36, 0
  br i1 %t38, label %bb19, label %bb20
bb19:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l2, i8 44)
  br label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb22
bb22:
  %t41 = load i64, ptr %l3, !tbaa !24
  %t43 = add i64 %t41, 1
  store i64 %t43, ptr %l3, !tbaa !24
  %t45 = load i1, ptr %l7, !tbaa !21
  br i1 %t45, label %bb23, label %bb24
bb23:
  %t47 = load i64, ptr %l4, !tbaa !24
  %t49 = add i64 %t47, 1
  store i64 %t49, ptr %l4, !tbaa !24
  br label %bb25
bb24:
  br label %bb25
bb25:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %l2, { i64, ptr } { i64 8, ptr @.d129 })
  br label %bb26
bb26:
  store ptr %l2, ptr %l36, !tbaa !29
  %t52 = load i1, ptr %l7, !tbaa !21
  br i1 %t52, label %bb27, label %bb28
bb27:
  %t54 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t54, ptr %l39, !tbaa !27
  %t55 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t58 = extractvalue { i64, ptr } %t55, 0
  store i64 %t58, ptr %l42, !tbaa !24
  %t59 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t60 = extractvalue { i64, ptr } %t59, 0
  store i64 %t60, ptr %l43, !tbaa !24
  %t61 = icmp sge i64 5, 0
  br i1 %t61, label %bb29, label %bb30
bb28:
  %t63 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t63, ptr %l48, !tbaa !27
  %t64 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t67 = extractvalue { i64, ptr } %t64, 0
  store i64 %t67, ptr %l51, !tbaa !24
  %t68 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t68, 0
  store i64 %t69, ptr %l52, !tbaa !24
  %t70 = icmp sge i64 7, 0
  br i1 %t70, label %bb35, label %bb36
bb29:
  %t72 = load i64, ptr %l42, !tbaa !24
  %t73 = icmp sle i64 5, %t72
  br i1 %t73, label %bb31, label %bb32
bb30:
  call void @__olang_check_failed(ptr @olang_loc_ff5699425ec58672_f160fabafc85af8e)
  unreachable
bb31:
  %t75 = load i64, ptr %l42, !tbaa !24
  %t76 = load i64, ptr %l43, !tbaa !24
  %t77 = icmp sle i64 %t75, %t76
  br i1 %t77, label %bb33, label %bb34
bb32:
  call void @__olang_check_failed(ptr @olang_loc_ff5699425ec58672_f160fabafc85af8e)
  unreachable
bb33:
  %t79 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = load i64, ptr %l42, !tbaa !24
  %t82 = getelementptr i8, ptr %t80, i64 5
  %t83 = sub i64 %t81, 5
  %t84 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t85 = insertvalue { i64, ptr } %t84, ptr %t82, 1
  store { i64, ptr } %t85, ptr %l38, !tbaa !27
  br label %bb41
bb34:
  call void @__olang_check_failed(ptr @olang_loc_ff5699425ec58672_f160fabafc85af8e)
  unreachable
bb35:
  %t87 = load i64, ptr %l51, !tbaa !24
  %t88 = icmp sle i64 7, %t87
  br i1 %t88, label %bb37, label %bb38
bb36:
  call void @__olang_check_failed(ptr @olang_loc_ff5699425ec58672_f160fabafc85af8e)
  unreachable
bb37:
  %t90 = load i64, ptr %l51, !tbaa !24
  %t91 = load i64, ptr %l52, !tbaa !24
  %t92 = icmp sle i64 %t90, %t91
  br i1 %t92, label %bb39, label %bb40
bb38:
  call void @__olang_check_failed(ptr @olang_loc_ff5699425ec58672_f160fabafc85af8e)
  unreachable
bb39:
  %t94 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !27
  %t96 = load i64, ptr %l51, !tbaa !24
  %t97 = getelementptr i8, ptr %t95, i64 7
  %t98 = sub i64 %t96, 7
  %t99 = insertvalue { i64, ptr } undef, i64 %t98, 0
  %t100 = insertvalue { i64, ptr } %t99, ptr %t97, 1
  store { i64, ptr } %t100, ptr %l38, !tbaa !27
  br label %bb41
bb40:
  call void @__olang_check_failed(ptr @olang_loc_ff5699425ec58672_f160fabafc85af8e)
  unreachable
bb41:
  %t102 = load ptr, ptr %l36, !tbaa !29
  %t103 = load { i64, ptr }, ptr %l38, !tbaa !27
  call void @compiler_2fsession_2eJsonStr(ptr %s0, ptr %v0, ptr %t102, { i64, ptr } %t103)
  br label %bb42
bb42:
  store ptr %l2, ptr %l57, !tbaa !29
  %t104 = load i1, ptr %l7, !tbaa !21
  br i1 %t104, label %bb43, label %bb44
bb43:
  store { i64, ptr } { i64 4, ptr @.d130 }, ptr %l59, !tbaa !27
  br label %bb45
bb44:
  store { i64, ptr } { i64 5, ptr @.d131 }, ptr %l59, !tbaa !27
  br label %bb45
bb45:
  %t106 = extractvalue { i64, ptr } { i64 10, ptr @.d132 }, 1
  %t107 = extractvalue { i64, ptr } { i64 10, ptr @.d132 }, 0
  %t108 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t109 = extractvalue { i64, ptr } %t108, 1
  %t110 = extractvalue { i64, ptr } %t108, 0
  %t111 = add i64 %t107, %t110
  %t112 = extractvalue { i64, ptr } { i64 1, ptr @.d133 }, 1
  %t113 = extractvalue { i64, ptr } { i64 1, ptr @.d133 }, 0
  %t114 = add i64 %t111, %t113
  %t115 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t114)
  call void @olang_textcopy(ptr %t115, ptr %t106, i64 %t107)
  %t116 = getelementptr i8, ptr %t115, i64 %t107
  call void @olang_textcopy(ptr %t116, ptr %t109, i64 %t110)
  %t117 = getelementptr i8, ptr %t116, i64 %t110
  call void @olang_textcopy(ptr %t117, ptr %t112, i64 %t113)
  %t118 = insertvalue { i64, ptr } undef, i64 %t114, 0
  %t119 = insertvalue { i64, ptr } %t118, ptr %t115, 1
  %t121 = extractvalue { i64, ptr } %t119, 0
  %t122 = extractvalue { i64, ptr } %t119, 1
  %t123 = mul i64 %t121, 1
  %t124 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t123)
  call void @llvm.memcpy.p0.p0.i64(ptr %t124, ptr %t122, i64 %t123, i1 false)
  %t125 = insertvalue { i64, ptr } undef, i64 %t121, 0
  %t126 = insertvalue { i64, ptr } %t125, ptr %t124, 1
  %t127 = load ptr, ptr %l57, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %t127, { i64, ptr } %t126)
  br label %bb46
bb46:
  call void @__olang_scope_close(ptr %s2)
  br label %bb47
bb47:
  br label %bb4
bb48:
  %t129 = load i64, ptr %l4, !tbaa !24
  %t130 = load i64, ptr %l3, !tbaa !24
  %t131 = load i64, ptr %l4, !tbaa !24
  %t134 = sub i64 %t130, %t131
  %t135 = load i32, ptr %l1, !tbaa !23
  %t136 = extractvalue { i64, ptr } { i64 11, ptr @.d134 }, 1
  %t137 = extractvalue { i64, ptr } { i64 11, ptr @.d134 }, 0
  %t139 = call i64 @__olang_fmt_i64(ptr null, i64 %t129)
  %t140 = add i64 %t137, %t139
  %t141 = extractvalue { i64, ptr } { i64 10, ptr @.d135 }, 1
  %t142 = extractvalue { i64, ptr } { i64 10, ptr @.d135 }, 0
  %t143 = add i64 %t140, %t142
  %t145 = call i64 @__olang_fmt_i64(ptr null, i64 %t134)
  %t146 = add i64 %t143, %t145
  %t147 = extractvalue { i64, ptr } { i64 10, ptr @.d136 }, 1
  %t148 = extractvalue { i64, ptr } { i64 10, ptr @.d136 }, 0
  %t149 = add i64 %t146, %t148
  %t151 = sext i32 %t135 to i64
  %t152 = call i64 @__olang_fmt_i64(ptr null, i64 %t151)
  %t153 = add i64 %t149, %t152
  %t154 = extractvalue { i64, ptr } { i64 1, ptr @.d137 }, 1
  %t155 = extractvalue { i64, ptr } { i64 1, ptr @.d137 }, 0
  %t156 = add i64 %t153, %t155
  %t157 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t156)
  call void @olang_textcopy(ptr %t157, ptr %t136, i64 %t137)
  %t158 = getelementptr i8, ptr %t157, i64 %t137
  %t159 = call i64 @__olang_fmt_i64(ptr %t158, i64 %t129)
  %t160 = getelementptr i8, ptr %t158, i64 %t139
  call void @olang_textcopy(ptr %t160, ptr %t141, i64 %t142)
  %t161 = getelementptr i8, ptr %t160, i64 %t142
  %t162 = call i64 @__olang_fmt_i64(ptr %t161, i64 %t134)
  %t163 = getelementptr i8, ptr %t161, i64 %t145
  call void @olang_textcopy(ptr %t163, ptr %t147, i64 %t148)
  %t164 = getelementptr i8, ptr %t163, i64 %t148
  %t165 = call i64 @__olang_fmt_i64(ptr %t164, i64 %t151)
  %t166 = getelementptr i8, ptr %t164, i64 %t152
  call void @olang_textcopy(ptr %t166, ptr %t154, i64 %t155)
  %t167 = insertvalue { i64, ptr } undef, i64 %t156, 0
  %t168 = insertvalue { i64, ptr } %t167, ptr %t157, 1
  %t170 = extractvalue { i64, ptr } %t168, 0
  %t171 = extractvalue { i64, ptr } %t168, 1
  %t172 = mul i64 %t170, 1
  %t173 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t172)
  call void @llvm.memcpy.p0.p0.i64(ptr %t173, ptr %t171, i64 %t172, i1 false)
  %t174 = insertvalue { i64, ptr } undef, i64 %t170, 0
  %t175 = insertvalue { i64, ptr } %t174, ptr %t173, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l2, { i64, ptr } %t175)
  br label %bb49
bb49:
  %t178 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t178, ptr %l70
  br label %bb50
bb50:
  %t179 = load %"std/prelude/text:StringBuilder", ptr %l70
  store %"std/prelude/text:StringBuilder" %t179, ptr %l8
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l8, { i64, ptr } { i64 34, ptr @.d138 })
  br label %bb51
bb51:
  %t181 = load { i64, ptr }, ptr %l0, !tbaa !27
  call void @compiler_2fsession_2eJsonStr(ptr %s0, ptr %v0, ptr %l8, { i64, ptr } %t181)
  br label %bb52
bb52:
  store ptr %l8, ptr %l74, !tbaa !29
  %t185 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l2)
  store { i64, ptr } %t185, ptr %l76
  br label %bb53
bb53:
  %t186 = load i32, ptr %l1, !tbaa !23
  %t188 = icmp ne i32 %t186, 0
  br i1 %t188, label %bb54, label %bb55
bb54:
  store { i64, ptr } { i64 4, ptr @.d139 }, ptr %l79, !tbaa !27
  br label %bb56
bb55:
  store { i64, ptr } { i64 5, ptr @.d140 }, ptr %l79, !tbaa !27
  br label %bb56
bb56:
  %t190 = extractvalue { i64, ptr } { i64 23, ptr @.d141 }, 1
  %t191 = extractvalue { i64, ptr } { i64 23, ptr @.d141 }, 0
  %t192 = load { i64, ptr }, ptr %l76, !tbaa !27
  %t193 = extractvalue { i64, ptr } %t192, 1
  %t194 = extractvalue { i64, ptr } %t192, 0
  %t195 = add i64 %t191, %t194
  %t196 = extractvalue { i64, ptr } { i64 11, ptr @.d142 }, 1
  %t197 = extractvalue { i64, ptr } { i64 11, ptr @.d142 }, 0
  %t198 = add i64 %t195, %t197
  %t199 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t200 = extractvalue { i64, ptr } %t199, 1
  %t201 = extractvalue { i64, ptr } %t199, 0
  %t202 = add i64 %t198, %t201
  %t203 = extractvalue { i64, ptr } { i64 1, ptr @.d143 }, 1
  %t204 = extractvalue { i64, ptr } { i64 1, ptr @.d143 }, 0
  %t205 = add i64 %t202, %t204
  %t206 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t205)
  call void @olang_textcopy(ptr %t206, ptr %t190, i64 %t191)
  %t207 = getelementptr i8, ptr %t206, i64 %t191
  call void @olang_textcopy(ptr %t207, ptr %t193, i64 %t194)
  %t208 = getelementptr i8, ptr %t207, i64 %t194
  call void @olang_textcopy(ptr %t208, ptr %t196, i64 %t197)
  %t209 = getelementptr i8, ptr %t208, i64 %t197
  call void @olang_textcopy(ptr %t209, ptr %t200, i64 %t201)
  %t210 = getelementptr i8, ptr %t209, i64 %t201
  call void @olang_textcopy(ptr %t210, ptr %t203, i64 %t204)
  %t211 = insertvalue { i64, ptr } undef, i64 %t205, 0
  %t212 = insertvalue { i64, ptr } %t211, ptr %t206, 1
  %t214 = extractvalue { i64, ptr } %t212, 0
  %t215 = extractvalue { i64, ptr } %t212, 1
  %t216 = mul i64 %t214, 1
  %t217 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t216)
  call void @llvm.memcpy.p0.p0.i64(ptr %t217, ptr %t215, i64 %t216, i1 false)
  %t218 = insertvalue { i64, ptr } undef, i64 %t214, 0
  %t219 = insertvalue { i64, ptr } %t218, ptr %t217, 1
  %t220 = load ptr, ptr %l74, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t220, { i64, ptr } %t219)
  br label %bb57
bb57:
  %t223 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l8)
  store { i64, ptr } %t223, ptr %l83
  br label %bb58
bb58:
  %t224 = load { i64, ptr }, ptr %l83, !tbaa !27
  store { i64, ptr } %t224, ptr %l84, !tbaa !27
  %t225 = load { i64, ptr }, ptr %l84, !tbaa !27
  %t226 = extractvalue { i64, ptr } %t225, 0
  store i64 %t226, ptr %l85, !tbaa !24
  %t227 = load i64, ptr %l85, !tbaa !24
  %t228 = mul i64 %t227, 1
  %t229 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t228)
  %t230 = insertvalue { i64, ptr } undef, i64 %t227, 0
  %t231 = insertvalue { i64, ptr } %t230, ptr %t229, 1
  store { i64, ptr } %t231, ptr %l86, !tbaa !27
  %t232 = getelementptr { i64, ptr }, ptr %l86, i32 0, i32 1
  %t233 = load ptr, ptr %t232, !tbaa !27
  %t234 = getelementptr { i64, ptr }, ptr %l84, i32 0, i32 1
  %t235 = load ptr, ptr %t234, !tbaa !27
  %t236 = load i64, ptr %l85, !tbaa !24
  %t237 = mul i64 %t236, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t233, ptr %t235, i64 %t237, i1 false)
  %t238 = load { i64, ptr }, ptr %l86, !tbaa !27
  store { i64, ptr } %t238, ptr %l84, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t239 = load { i64, ptr }, ptr %l84, !tbaa !27
  store { i64, ptr } %t239, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fmcp_2etextResult(ptr %v0, ptr %v1, { i64, ptr } %a0, i1 %a1) #0 {
entry:
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca %"std/prelude/text:StringBuilder"
  %l7 = alloca ptr
  %l9 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l3
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l3
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l2, { i64, ptr } { i64 34, ptr @.d144 })
  br label %bb2
bb2:
  call void @compiler_2fsession_2eJsonStr(ptr %s0, ptr %v0, ptr %l2, { i64, ptr } %a0)
  br label %bb3
bb3:
  store ptr %l2, ptr %l7, !tbaa !29
  br i1 %a1, label %bb4, label %bb5
bb4:
  store { i64, ptr } { i64 4, ptr @.d145 }, ptr %l9, !tbaa !27
  br label %bb6
bb5:
  store { i64, ptr } { i64 5, ptr @.d146 }, ptr %l9, !tbaa !27
  br label %bb6
bb6:
  %t9 = extractvalue { i64, ptr } { i64 13, ptr @.d147 }, 1
  %t10 = extractvalue { i64, ptr } { i64 13, ptr @.d147 }, 0
  %t11 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t11, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = add i64 %t10, %t13
  %t15 = extractvalue { i64, ptr } { i64 1, ptr @.d148 }, 1
  %t16 = extractvalue { i64, ptr } { i64 1, ptr @.d148 }, 0
  %t17 = add i64 %t14, %t16
  %t18 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t17)
  call void @olang_textcopy(ptr %t18, ptr %t9, i64 %t10)
  %t19 = getelementptr i8, ptr %t18, i64 %t10
  call void @olang_textcopy(ptr %t19, ptr %t12, i64 %t13)
  %t20 = getelementptr i8, ptr %t19, i64 %t13
  call void @olang_textcopy(ptr %t20, ptr %t15, i64 %t16)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t18, 1
  %t24 = extractvalue { i64, ptr } %t22, 0
  %t25 = extractvalue { i64, ptr } %t22, 1
  %t26 = mul i64 %t24, 1
  %t27 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t26)
  call void @llvm.memcpy.p0.p0.i64(ptr %t27, ptr %t25, i64 %t26, i1 false)
  %t28 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t27, 1
  %t30 = load ptr, ptr %l7, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t30, { i64, ptr } %t29)
  br label %bb7
bb7:
  %t33 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t33, ptr %l13
  br label %bb8
bb8:
  %t34 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t34, ptr %l14, !tbaa !27
  %t35 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t36 = extractvalue { i64, ptr } %t35, 0
  store i64 %t36, ptr %l15, !tbaa !24
  %t37 = load i64, ptr %l15, !tbaa !24
  %t38 = mul i64 %t37, 1
  %t39 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t38)
  %t40 = insertvalue { i64, ptr } undef, i64 %t37, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t39, 1
  store { i64, ptr } %t41, ptr %l16, !tbaa !27
  %t42 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = load i64, ptr %l15, !tbaa !24
  %t47 = mul i64 %t46, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t43, ptr %t45, i64 %t47, i1 false)
  %t48 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t48, ptr %l14, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t49 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t49, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fmcp_2etoolError(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call { i64, ptr } @compiler_2fmcp_2etextResult(ptr %v0, ptr %v1, { i64, ptr } %a0, i1 true)
  store { i64, ptr } %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t4, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @olang_2einit_2ecompiler_2fmcp() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  call void @compiler_2fmcp_2eTools_2einit()
  br label %bb1
bb1:
  br label %ret
ret:
  ret void
}

declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
chunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare void @__olang_check_failed(ptr)
declare void @__olang_ert_req_clear()
@.d0 = private constant [0 x i8] c""
@.d1 = private constant [94 x i8] c"[{\22name\22:\22check\22,\22description\22:\22Check an olang file as the compiler does (its program loaded, "
@.d2 = private constant [112 x i8] c"type-checked, its compile-time values and asserts decided, held to the scope rules): every diagnostic, each its "
@.d3 = private constant [112 x i8] c"file, line, column, rule and message, and the compiler's own one-row rendering. Pass text to check unsaved code "
@.d4 = private constant [94 x i8] c"in place of the file's contents.\22,\22inputSchema\22:{\22type\22:\22object\22,\22properties\22:{\22file\22:{\22type\22:"
@.d5 = private constant [99 x i8] c"\22string\22,\22description\22:\22path of the .olang file, the root of the program\22},\22text\22:{\22type\22:\22string\22,"
@.d6 = private constant [73 x i8] c"\22description\22:\22the file's text, if not as saved\22}},\22required\22:[\22file\22]}},"
@.d7 = private constant [105 x i8] c"{\22name\22:\22explain\22,\22description\22:\22A top-level item of an olang file as the compiler sees it: a function's "
@.d8 = private constant [109 x i8] c"whole signature with its inferred error set and scope obligations, a type's constructor, fields, methods and "
@.d9 = private constant [109 x i8] c"traits, a global's type and value - or, given a rule such as T6b and no file, that rule of the specification."
@.d10 = private constant [87 x i8] c"\22,\22inputSchema\22:{\22type\22:\22object\22,\22properties\22:{\22file\22:{\22type\22:\22string\22},\22name\22:{\22type\22:"
@.d11 = private constant [105 x i8] c"\22string\22,\22description\22:\22an item, or Type.Method; or a rule of the specification when file is left out\22}},"
@.d12 = private constant [22 x i8] c"\22required\22:[\22name\22]}},"
@.d13 = private constant [106 x i8] c"{\22name\22:\22doc\22,\22description\22:\22The documentation of an olang module (its doc comments and the signatures of "
@.d14 = private constant [96 x i8] c"its exported items), or of one item of it.\22,\22inputSchema\22:{\22type\22:\22object\22,\22properties\22:{\22file\22:"
@.d15 = private constant [92 x i8] c"{\22type\22:\22string\22,\22description\22:\22a .olang file, or a std module as std/json\22},\22name\22:{\22type\22:"
@.d16 = private constant [33 x i8] c"\22string\22}},\22required\22:[\22file\22]}},"
@.d17 = private constant [104 x i8] c"{\22name\22:\22format\22,\22description\22:\22An olang file in the language's one layout, as olang format writes it - "
@.d18 = private constant [96 x i8] c"returned, the file left unchanged.\22,\22inputSchema\22:{\22type\22:\22object\22,\22properties\22:{\22file\22:{\22type\22:"
@.d19 = private constant [90 x i8] c"\22string\22},\22text\22:{\22type\22:\22string\22,\22description\22:\22the text to format, if not the file's\22}},"
@.d20 = private constant [22 x i8] c"\22required\22:[\22file\22]}},"
@.d21 = private constant [103 x i8] c"{\22name\22:\22test\22,\22description\22:\22Run an olang file's test blocks, as olang test does: each test's outcome "
@.d22 = private constant [98 x i8] c"and what the run printed.\22,\22inputSchema\22:{\22type\22:\22object\22,\22properties\22:{\22file\22:{\22type\22:\22string\22}},"
@.d23 = private constant [22 x i8] c"\22required\22:[\22file\22]}}]"
@__olang_prog_scope = external thread_local(initialexec) global ptr
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d24 = private constant [4 x i8] c"file"
@.d25 = private constant [4 x i8] c"test"
@.d26 = private constant [0 x i8] c""
@.d27 = private constant [17 x i8] c"test needs a file"
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@.d28 = private constant [4 x i8] c"test"
@.d29 = private constant [0 x i8] c""
@.d30 = private constant [0 x i8] c""
@.d31 = private constant [29 x i8] c"the compiler could not be run"
@.d32 = private constant [7 x i8] c"explain"
@.d33 = private constant [0 x i8] c""
@.d34 = private constant [4 x i8] c"name"
@.d35 = private constant [7 x i8] c"explain"
@.d36 = private constant [0 x i8] c""
@.d37 = private constant [0 x i8] c""
@.d38 = private constant [29 x i8] c"the compiler could not be run"
@.d39 = private constant [5 x i8] c"check"
@.d40 = private constant [7 x i8] c"explain"
@.d41 = private constant [3 x i8] c"doc"
@.d42 = private constant [6 x i8] c"format"
@.d43 = private constant [8 x i8] c"no tool "
@.d44 = private constant [0 x i8] c""
@.d45 = private constant [13 x i8] c" needs a file"
@.d46 = private constant [4 x i8] c"text"
@.d47 = private constant [4 x i8] c"text"
@.d48 = private constant [4 x i8] c"name"
define available_externally void @__olang_scope_escape(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %un = icmp eq ptr %o, null
  br i1 %un, label %claim, label %done
claim:
  %me = load ptr, ptr @__olang_self
  store atomic ptr %me, ptr %op monotonic, align 8
  br label %done
done:
  ret void
}
define internal { i64, ptr } @olang_lambda_49(ptr %env, ptr %v0) #0 {
entry:
  %l12 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  %cp0 = getelementptr { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load { i64, ptr }, ptr %cp0, !tbaa !28
  %cp1 = getelementptr { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 1
  %cv1 = load { i64, ptr }, ptr %cp1, !tbaa !28
  %cp2 = getelementptr { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 2
  %cv2 = load i1, ptr %cp2, !tbaa !28
  %cp3 = getelementptr { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 3
  %cv3 = load { i64, ptr }, ptr %cp3, !tbaa !28
  %cp4 = getelementptr { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 4
  %cv4 = load { i64, ptr }, ptr %cp4, !tbaa !28
  %cp5 = getelementptr { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 5
  %cv5 = load ptr, ptr %cp5, !tbaa !28
  %vq0 = getelementptr { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 6
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  %vq1 = getelementptr { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 7
  %vr1 = load ptr, ptr %vq1, !tbaa !28
  %vc1 = call ptr @__olang_capture_scope(ptr %vr1)
  %vq2 = getelementptr { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 8
  %vr2 = load ptr, ptr %vq2, !tbaa !28
  %vc2 = call ptr @__olang_capture_scope(ptr %vr2)
  %vq3 = getelementptr { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 9
  %vr3 = load ptr, ptr %vq3, !tbaa !28
  %vc3 = call ptr @__olang_capture_scope(ptr %vr3)
  %vq4 = getelementptr { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 10
  %vr4 = load ptr, ptr %vq4, !tbaa !28
  %vc4 = call ptr @__olang_capture_scope(ptr %vr4)
  br label %start
start:
  br label %bb0
bb0:
  %t13 = call { i64, ptr } @compiler_2fmcp_2erun(ptr %vc0, ptr %vc1, ptr %vc2, ptr %vc3, ptr %vc4, ptr %v0, { i64, ptr } %cv0, { i64, ptr } %cv1, i1 %cv2, { i64, ptr } %cv3, { i64, ptr } %cv4, ptr %cv5)
  store { i64, ptr } %t13, ptr %l12
  br label %bb1
bb1:
  %t14 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t14, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d50 = private constant [33 x i8] c"the compiler ended while running "
@.d51 = private constant [9 x i8] c" (status "
declare i64 @__olang_fmt_i64(ptr, i64)
@.d52 = private constant [25 x i8] c") - a bug in the compiler"
@.d53 = private constant [16 x i8] c"{\22diagnostics\22:["
@.d54 = private constant [10 x i8] c",\22notes\22:["
@.d55 = private constant [2 x i8] c"]}"
@.d56 = private constant [11 x i8] c"],\22errors\22:"
@.d57 = private constant [1 x i8] c"}"
@.d58 = private constant [9 x i8] c"no errors"
@.d59 = private constant [34 x i8] c"{\22content\22:[{\22type\22:\22text\22,\22text\22:"
@.d60 = private constant [23 x i8] c"}],\22structuredContent\22:"
@.d61 = private constant [17 x i8] c",\22isError\22:false}"
@.d62 = private constant [5 x i8] c"OLANG"
@.d63 = private constant [0 x i8] c""
@.d64 = private constant [0 x i8] c""
@.d65 = private constant [11 x i8] c"build/olang"
@.d66 = private constant [22 x i8] c"{\22jsonrpc\22:\222.0\22,\22id\22:"
@.d67 = private constant [17 x i8] c",\22error\22:{\22code\22:"
@.d68 = private constant [11 x i8] c",\22message\22:"
@.d69 = private constant [2 x i8] c"}}"
@.d70 = private constant [4 x i8] c"null"
@.d71 = private constant [23 x i8] c"the message is not JSON"
@.d72 = private constant [6 x i8] c"method"
@.d73 = private constant [10 x i8] c"initialize"
@.d74 = private constant [6 x i8] c"params"
@.d75 = private constant [15 x i8] c"protocolVersion"
@.d76 = private constant [10 x i8] c"2025-06-18"
@.d77 = private constant [19 x i8] c"{\22protocolVersion\22:"
@.d78 = private constant [92 x i8] c",\22capabilities\22:{\22tools\22:{\22listChanged\22:false}},\22serverInfo\22:{\22name\22:\22olang\22,\22version\22:\220\22},"
@.d79 = private constant [15 x i8] c"\22instructions\22:"
@.d80 = private constant [87 x i8] c"Tools for the olang language: check a file's diagnostics, explain an item or a rule, a "
@.d81 = private constant [91 x i8] c"module's documentation, format, and run a file's tests. Paths are relative to the server's "
@.d82 = private constant [18 x i8] c"working directory."
@.d83 = private constant [0 x i8] c""
@.d84 = private constant [4 x i8] c"ping"
@.d85 = private constant [2 x i8] c"{}"
@.d86 = private constant [10 x i8] c"tools/list"
@.d87 = private constant [9 x i8] c"{\22tools\22:"
@.d88 = private constant [1 x i8] c"}"
@.d89 = private constant [10 x i8] c"tools/call"
@.d90 = private constant [6 x i8] c"params"
@.d91 = private constant [4 x i8] c"name"
@.d92 = private constant [0 x i8] c""
@.d93 = private constant [6 x i8] c"params"
@.d94 = private constant [9 x i8] c"arguments"
@.d95 = private constant [17 x i8] c"olang mcp has no "
@.d96 = private constant [2 x i8] c"id"
@.d97 = private constant [0 x i8] c""
@.d98 = private constant [0 x i8] c""
@.d99 = private constant [8 x i8] c"{\22file\22:"
@.d100 = private constant [0 x i8] c""
@.d101 = private constant [8 x i8] c",\22line\22:"
@.d102 = private constant [10 x i8] c",\22column\22:"
@.d103 = private constant [11 x i8] c",\22endLine\22:"
@.d104 = private constant [13 x i8] c",\22endColumn\22:"
@.d105 = private constant [8 x i8] c",\22line\22:"
@.d106 = private constant [0 x i8] c""
@.d107 = private constant [8 x i8] c",\22rule\22:"
@.d108 = private constant [11 x i8] c",\22message\22:"
@.d109 = private constant [22 x i8] c"{\22jsonrpc\22:\222.0\22,\22id\22:"
@.d110 = private constant [10 x i8] c",\22result\22:"
@.d111 = private constant [1 x i8] c"}"
@.d112 = private constant [3 x i8] c"doc"
@.d113 = private constant [6 x i8] c".olang"
@.d114 = private constant [6 x i8] c"format"
@.d115 = private constant [12 x i8] c"cannot read "
@.d116 = private constant [46 x i8] c" does not parse - check it for its diagnostics"
@.d117 = private constant [5 x i8] c"check"
@.d118 = private constant [7 x i8] c"explain"
@.d119 = private constant [1 x i8] c"'"
@.d120 = private constant [26 x i8] c"' is no top-level item of "
@.d121 = private constant [0 x i8] c""
@.d122 = private constant [1 x i8] c"'"
@.d123 = private constant [16 x i8] c"' is no item of "
@.d124 = private constant [1 x i8] c"\0A"
@.d125 = private constant [0 x i8] c""
@.d126 = private constant [10 x i8] c"{\22tests\22:["
@.d127 = private constant [5 x i8] c"ok - "
@.d128 = private constant [7 x i8] c"FAIL - "
@.d129 = private constant [8 x i8] c"{\22name\22:"
@.d130 = private constant [4 x i8] c"true"
@.d131 = private constant [5 x i8] c"false"
@.d132 = private constant [10 x i8] c",\22passed\22:"
@.d133 = private constant [1 x i8] c"}"
@.d134 = private constant [11 x i8] c"],\22passed\22:"
@.d135 = private constant [10 x i8] c",\22failed\22:"
@.d136 = private constant [10 x i8] c",\22status\22:"
@.d137 = private constant [1 x i8] c"}"
@.d138 = private constant [34 x i8] c"{\22content\22:[{\22type\22:\22text\22,\22text\22:"
@.d139 = private constant [4 x i8] c"true"
@.d140 = private constant [5 x i8] c"false"
@.d141 = private constant [23 x i8] c"}],\22structuredContent\22:"
@.d142 = private constant [11 x i8] c",\22isError\22:"
@.d143 = private constant [1 x i8] c"}"
@.d144 = private constant [34 x i8] c"{\22content\22:[{\22type\22:\22text\22,\22text\22:"
@.d145 = private constant [4 x i8] c"true"
@.d146 = private constant [5 x i8] c"false"
@.d147 = private constant [13 x i8] c"}],\22isError\22:"
@.d148 = private constant [1 x i8] c"}"
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@__olang_self = external thread_local(initialexec) global ptr
define available_externally ptr @__olang_capture_scope(ptr %s) alwaysinline {
entry:
  %isprog = icmp eq ptr %s, null
  br i1 %isprog, label %prog, label %mine
prog:
  %p = load ptr, ptr @__olang_prog_scope
  ret ptr %p
mine:
  %m = call ptr @__olang_scope_mine(ptr %s)
  ret ptr %m
}
define available_externally ptr @__olang_scope_mine(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %me = load ptr, ptr @__olang_self
  %own = icmp eq ptr %o, %me
  br i1 %own, label %mine, label %slow
mine:
  ret ptr %s
slow:
  %r = call ptr @__olang_scope_mine_slow(ptr %s)
  ret ptr %r
}
declare ptr @__olang_scope_mine_slow(ptr) noinline
declare void @compiler_2fsession_2eIgnoreBrokenPipes()
declare %"compiler/session:Reader" @compiler_2fsession_3aReader_2ector(ptr %v0, i32 %a0)
declare i1 @compiler_2fsession_2ecompiler_2fsession_3aReader_2eFill(ptr %v0, ptr %a0)
declare { i32, { i64, ptr } } @compiler_2fsession_2ecompiler_2fsession_3aReader_2eNextLine(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_b829b1c0f66d39b8_770b54290d51300c = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, { i64, ptr } %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i32, %"std/os:Output" } @std_2fos_2eExec(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, i1 %a2, { i64, ptr } %a3)
@olang_loc_318d1c2fb8966e8f_49031d4c001ef363 = external constant [0 x i8]
@olang_loc_f9d9ba2b38c78a4e_acdef970c68e1562 = external constant [0 x i8]
declare { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAt_3cstd_2fprelude_2ftext_3aString_3e(ptr %v0, ptr %a0, { i64, ptr } %a1)
@olang_loc_167c2e8a866de005_69a10464275f2959 = external constant [0 x i8]
declare { { i64, ptr }, i32 } @compiler_2fsession_2eChildOutput(ptr %v0, ptr %v1, ptr %a0c, ptr %a0e)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eItems(ptr %v0, ptr %v1, ptr %a0)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3aItem_3e_2eLen_3ccompiler_2fdiag_3aItem_3e(ptr %v0, ptr %a0)
declare %"compiler/diag:Item" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3aItem_3e_2eAt_3ccompiler_2fdiag_3aItem_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eRender(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eSummary(ptr %v0, ptr %v1, ptr %a0)
declare void @compiler_2fsession_2eJsonStr(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, ptr } @std_2fjson_2eParse(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, ptr %a1)
@olang_loc_4244407816c61fa5_b1d22b5654b5d3d9 = external constant [0 x i8]
@olang_loc_49e75dc54fe70574_c2cd19fae9c45a08 = external constant [0 x i8]
declare { i32, { i64, ptr } } @std_2fjson_2estd_2fjson_3aJson_2eAsStr(ptr %v0, ptr %a0)
@olang_loc_818e19382589e4af_9134443e2d759de3 = external constant [0 x i8]
@olang_loc_bdbef39504843ee_f5102062f3e4bfe2 = external constant [0 x i8]
@olang_loc_5fd9fed611fa4e17_8f5848307df60ca3 = external constant [0 x i8]
declare { i64, ptr } @std_2fjson_2eEncode(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2ePathOf(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eTextOf(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/session:Positions" @compiler_2fsession_3aPositions_2ector(ptr %v0, ptr %v1, { i64, ptr } %a0, i1 %a1)
declare { i64, i64 } @compiler_2fsession_2ecompiler_2fsession_3aPositions_2ePos(ptr %v0, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fsession_2eStdModule(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
declare { i64, ptr } @compiler_2fsession_2eRealOf(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6f7a2f8d839c49b6e7a19c287d4b190c(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_648a8f9a00cb525a_35c2b76f6215b926 = external constant [0 x i8]
declare { i32, { i64, ptr } } @compiler_2fsession_2eFormat(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @compiler_2fdiag_3aDiagnostics_2ector(ptr %out, ptr %v0, i1 %a0)
declare ptr @compiler_2fsession_2eAnalyze(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, ptr %a1, ptr %a2, ptr %a3, i1 %a4)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v0, ptr %a0)
@olang_loc_fd6ee713b6cd3a34_3a725fec10b02c40 = external constant [0 x i8]
declare { i32, { i64, ptr } } @compiler_2fexplain_2eItem(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, i64 %a3, { i64, ptr } %a4)
@olang_loc_b158e1e8f275dc60_3861351c1a443b8c = external constant [0 x i8]
@olang_loc_914d84508fdf5042_16c39655cf5e6ae = external constant [0 x i8]
declare { i32, { i64, ptr } } @compiler_2fdoc_2eItemText(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, i64 %a3, { i64, ptr } %a4)
@olang_loc_b3c3e8b04c8f1ad6_228abd84f405fb6a = external constant [0 x i8]
@olang_loc_e5ca324f5b9892b0_241151de3839f804 = external constant [0 x i8]
declare %"compiler/doc:Module" @compiler_2fdoc_2eOf(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, i64 %a3, i1 %a4)
declare { i64, ptr } @compiler_2fdoc_2ecompiler_2fdoc_3aModule_2eText(ptr %v0, ptr %v1, ptr %a0)
declare i32 @std_2fio_2eWrite(ptr %v0, i32 %a0, { i64, ptr } %a1)
@olang_loc_9371250ac8a8a79_a56c6b8809127485 = external constant [0 x i8]
declare { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAt_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_90272fd1f37d718c_b0a06defe4062150 = external constant [0 x i8]
declare %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %a0)
@olang_loc_cc8720c802d496e8_1cfdfb6aa0bef724 = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_ff5699425ec58672_f160fabafc85af8e = external constant [0 x i8]

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
