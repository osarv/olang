; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/session:Reader" = type { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1 }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"std/os:Output" = type { i32, { i64, ptr }, { i64, ptr } }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/diag:Item" = type { i1, { i64, ptr }, i64, i64, i64, i64, { i64, ptr } }
%"compiler/session:Positions" = type { { i64, ptr }, i1, { i64, ptr } }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"compiler/diag:Diagnostics" = type { i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, [3 x i64] }, { i64, ptr }, { i64, ptr }, i1, i1 }
%"compiler/doc:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/session:Analysis" = type { ptr, ptr, ptr, ptr }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/text:LineIter" = type { { i64, ptr }, i64 }
@G_2ecompiler_2fmcp_2eTools = constant <{ [8 x i8], ptr }> <{ [8 x i8] c"\BF\07\00\00\00\00\00\00", ptr @G_2ecompiler_2fmcp_2eTools.k1 }>, align 8
@G_2ecompiler_2fmcp_2eTools.k1 = internal constant <{ [1983 x i8] }> <{ [1983 x i8] c"\5B\7B\22\6E\61\6D\65\22\3A\22\63\68\65\63\6B\22\2C\22\64\65\73\63\72\69\70\74\69\6F\6E\22\3A\22\43\68\65\63\6B\20\61\6E\20\6F\6C\61\6E\67\20\66\69\6C\65\20\61\73\20\74\68\65\20\63\6F\6D\70\69\6C\65\72\20\64\6F\65\73\20\28\69\74\73\20\70\72\6F\67\72\61\6D\20\6C\6F\61\64\65\64\2C\20\74\79\70\65\2D\63\68\65\63\6B\65\64\2C\20\69\74\73\20\63\6F\6D\70\69\6C\65\2D\74\69\6D\65\20\76\61\6C\75\65\73\20\61\6E\64\20\61\73\73\65\72\74\73\20\64\65\63\69\64\65\64\2C\20\68\65\6C\64\20\74\6F\20\74\68\65\20\73\63\6F\70\65\20\72\75\6C\65\73\29\3A\20\65\76\65\72\79\20\64\69\61\67\6E\6F\73\74\69\63\2C\20\65\61\63\68\20\69\74\73\20\66\69\6C\65\2C\20\6C\69\6E\65\2C\20\63\6F\6C\75\6D\6E\2C\20\72\75\6C\65\20\61\6E\64\20\6D\65\73\73\61\67\65\2C\20\61\6E\64\20\74\68\65\20\63\6F\6D\70\69\6C\65\72\27\73\20\6F\77\6E\20\6F\6E\65\2D\72\6F\77\20\72\65\6E\64\65\72\69\6E\67\2E\20\50\61\73\73\20\74\65\78\74\20\74\6F\20\63\68\65\63\6B\20\75\6E\73\61\76\65\64\20\63\6F\64\65\20\69\6E\20\70\6C\61\63\65\20\6F\66\20\74\68\65\20\66\69\6C\65\27\73\20\63\6F\6E\74\65\6E\74\73\2E\22\2C\22\69\6E\70\75\74\53\63\68\65\6D\61\22\3A\7B\22\74\79\70\65\22\3A\22\6F\62\6A\65\63\74\22\2C\22\70\72\6F\70\65\72\74\69\65\73\22\3A\7B\22\66\69\6C\65\22\3A\7B\22\74\79\70\65\22\3A\22\73\74\72\69\6E\67\22\2C\22\64\65\73\63\72\69\70\74\69\6F\6E\22\3A\22\70\61\74\68\20\6F\66\20\74\68\65\20\2E\6F\6C\61\6E\67\20\66\69\6C\65\2C\20\74\68\65\20\72\6F\6F\74\20\6F\66\20\74\68\65\20\70\72\6F\67\72\61\6D\22\7D\2C\22\74\65\78\74\22\3A\7B\22\74\79\70\65\22\3A\22\73\74\72\69\6E\67\22\2C\22\64\65\73\63\72\69\70\74\69\6F\6E\22\3A\22\74\68\65\20\66\69\6C\65\27\73\20\74\65\78\74\2C\20\69\66\20\6E\6F\74\20\61\73\20\73\61\76\65\64\22\7D\7D\2C\22\72\65\71\75\69\72\65\64\22\3A\5B\22\66\69\6C\65\22\5D\7D\7D\2C\7B\22\6E\61\6D\65\22\3A\22\65\78\70\6C\61\69\6E\22\2C\22\64\65\73\63\72\69\70\74\69\6F\6E\22\3A\22\41\20\74\6F\70\2D\6C\65\76\65\6C\20\69\74\65\6D\20\6F\66\20\61\6E\20\6F\6C\61\6E\67\20\66\69\6C\65\20\61\73\20\74\68\65\20\63\6F\6D\70\69\6C\65\72\20\73\65\65\73\20\69\74\3A\20\61\20\66\75\6E\63\74\69\6F\6E\27\73\20\77\68\6F\6C\65\20\73\69\67\6E\61\74\75\72\65\20\77\69\74\68\20\69\74\73\20\69\6E\66\65\72\72\65\64\20\65\72\72\6F\72\20\73\65\74\20\61\6E\64\20\73\63\6F\70\65\20\6F\62\6C\69\67\61\74\69\6F\6E\73\2C\20\61\20\74\79\70\65\27\73\20\63\6F\6E\73\74\72\75\63\74\6F\72\2C\20\66\69\65\6C\64\73\2C\20\6D\65\74\68\6F\64\73\20\61\6E\64\20\74\72\61\69\74\73\2C\20\61\20\67\6C\6F\62\61\6C\27\73\20\74\79\70\65\20\61\6E\64\20\76\61\6C\75\65\20\2D\20\6F\72\2C\20\67\69\76\65\6E\20\61\20\72\75\6C\65\20\73\75\63\68\20\61\73\20\54\36\62\20\61\6E\64\20\6E\6F\20\66\69\6C\65\2C\20\74\68\61\74\20\72\75\6C\65\20\6F\66\20\74\68\65\20\73\70\65\63\69\66\69\63\61\74\69\6F\6E\2E\22\2C\22\69\6E\70\75\74\53\63\68\65\6D\61\22\3A\7B\22\74\79\70\65\22\3A\22\6F\62\6A\65\63\74\22\2C\22\70\72\6F\70\65\72\74\69\65\73\22\3A\7B\22\66\69\6C\65\22\3A\7B\22\74\79\70\65\22\3A\22\73\74\72\69\6E\67\22\7D\2C\22\6E\61\6D\65\22\3A\7B\22\74\79\70\65\22\3A\22\73\74\72\69\6E\67\22\2C\22\64\65\73\63\72\69\70\74\69\6F\6E\22\3A\22\61\6E\20\69\74\65\6D\2C\20\6F\72\20\54\79\70\65\2E\4D\65\74\68\6F\64\3B\20\6F\72\20\61\20\72\75\6C\65\20\6F\66\20\74\68\65\20\73\70\65\63\69\66\69\63\61\74\69\6F\6E\20\77\68\65\6E\20\66\69\6C\65\20\69\73\20\6C\65\66\74\20\6F\75\74\22\7D\7D\2C\22\72\65\71\75\69\72\65\64\22\3A\5B\22\6E\61\6D\65\22\5D\7D\7D\2C\7B\22\6E\61\6D\65\22\3A\22\64\6F\63\22\2C\22\64\65\73\63\72\69\70\74\69\6F\6E\22\3A\22\54\68\65\20\64\6F\63\75\6D\65\6E\74\61\74\69\6F\6E\20\6F\66\20\61\6E\20\6F\6C\61\6E\67\20\6D\6F\64\75\6C\65\20\28\69\74\73\20\64\6F\63\20\63\6F\6D\6D\65\6E\74\73\20\61\6E\64\20\74\68\65\20\73\69\67\6E\61\74\75\72\65\73\20\6F\66\20\69\74\73\20\65\78\70\6F\72\74\65\64\20\69\74\65\6D\73\29\2C\20\6F\72\20\6F\66\20\6F\6E\65\20\69\74\65\6D\20\6F\66\20\69\74\2E\22\2C\22\69\6E\70\75\74\53\63\68\65\6D\61\22\3A\7B\22\74\79\70\65\22\3A\22\6F\62\6A\65\63\74\22\2C\22\70\72\6F\70\65\72\74\69\65\73\22\3A\7B\22\66\69\6C\65\22\3A\7B\22\74\79\70\65\22\3A\22\73\74\72\69\6E\67\22\2C\22\64\65\73\63\72\69\70\74\69\6F\6E\22\3A\22\61\20\2E\6F\6C\61\6E\67\20\66\69\6C\65\2C\20\6F\72\20\61\20\73\74\64\20\6D\6F\64\75\6C\65\20\61\73\20\73\74\64\2F\6A\73\6F\6E\22\7D\2C\22\6E\61\6D\65\22\3A\7B\22\74\79\70\65\22\3A\22\73\74\72\69\6E\67\22\7D\7D\2C\22\72\65\71\75\69\72\65\64\22\3A\5B\22\66\69\6C\65\22\5D\7D\7D\2C\7B\22\6E\61\6D\65\22\3A\22\66\6F\72\6D\61\74\22\2C\22\64\65\73\63\72\69\70\74\69\6F\6E\22\3A\22\41\6E\20\6F\6C\61\6E\67\20\66\69\6C\65\20\69\6E\20\74\68\65\20\6C\61\6E\67\75\61\67\65\27\73\20\6F\6E\65\20\6C\61\79\6F\75\74\2C\20\61\73\20\6F\6C\61\6E\67\20\66\6F\72\6D\61\74\20\77\72\69\74\65\73\20\69\74\20\2D\20\72\65\74\75\72\6E\65\64\2C\20\74\68\65\20\66\69\6C\65\20\6C\65\66\74\20\75\6E\63\68\61\6E\67\65\64\2E\22\2C\22\69\6E\70\75\74\53\63\68\65\6D\61\22\3A\7B\22\74\79\70\65\22\3A\22\6F\62\6A\65\63\74\22\2C\22\70\72\6F\70\65\72\74\69\65\73\22\3A\7B\22\66\69\6C\65\22\3A\7B\22\74\79\70\65\22\3A\22\73\74\72\69\6E\67\22\7D\2C\22\74\65\78\74\22\3A\7B\22\74\79\70\65\22\3A\22\73\74\72\69\6E\67\22\2C\22\64\65\73\63\72\69\70\74\69\6F\6E\22\3A\22\74\68\65\20\74\65\78\74\20\74\6F\20\66\6F\72\6D\61\74\2C\20\69\66\20\6E\6F\74\20\74\68\65\20\66\69\6C\65\27\73\22\7D\7D\2C\22\72\65\71\75\69\72\65\64\22\3A\5B\22\66\69\6C\65\22\5D\7D\7D\2C\7B\22\6E\61\6D\65\22\3A\22\74\65\73\74\22\2C\22\64\65\73\63\72\69\70\74\69\6F\6E\22\3A\22\52\75\6E\20\61\6E\20\6F\6C\61\6E\67\20\66\69\6C\65\27\73\20\74\65\73\74\20\62\6C\6F\63\6B\73\2C\20\61\73\20\6F\6C\61\6E\67\20\74\65\73\74\20\64\6F\65\73\3A\20\65\61\63\68\20\74\65\73\74\27\73\20\6F\75\74\63\6F\6D\65\20\61\6E\64\20\77\68\61\74\20\74\68\65\20\72\75\6E\20\70\72\69\6E\74\65\64\2E\22\2C\22\69\6E\70\75\74\53\63\68\65\6D\61\22\3A\7B\22\74\79\70\65\22\3A\22\6F\62\6A\65\63\74\22\2C\22\70\72\6F\70\65\72\74\69\65\73\22\3A\7B\22\66\69\6C\65\22\3A\7B\22\74\79\70\65\22\3A\22\73\74\72\69\6E\67\22\7D\7D\2C\22\72\65\71\75\69\72\65\64\22\3A\5B\22\66\69\6C\65\22\5D\7D\7D\5D" }>, align 64
define dso_local i32 @compiler_2fmcp_2eServe(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca %"compiler/session:Reader"
  %l7 = alloca i1
  %l9 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca i32
  %l14 = alloca i1
  %l16 = alloca { i64, ptr }
  %l17 = alloca i1
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  call void @compiler_2fsession_2eIgnoreBrokenPipes()
  br label %bb1
bb1:
  %t1 = call %"compiler/session:Reader" @compiler_2fsession_3aReader_2ector(ptr %s0, i32 0)
  store %"compiler/session:Reader" %t1, ptr %l4
  br label %bb2
bb2:
  %t2 = load %"compiler/session:Reader", ptr %l4
  %t3 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 48, i64 8)
  store %"compiler/session:Reader" %t2, ptr %t3
  store ptr %t3, ptr %l2, !tbaa !29
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t7 = call i1 @compiler_2fsession_2ecompiler_2fsession_3aReader_2eFill(ptr %s0, ptr %t5)
  store i1 %t7, ptr %l7
  br label %bb4
bb4:
  %t8 = load i1, ptr %l7, !tbaa !21
  %t9 = xor i1 %t8, true
  br i1 %t9, label %bb5, label %bb6
bb5:
  br label %bb22
bb6:
  br label %bb7
bb7:
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t11 = load ptr, ptr %l2, !tbaa !29
  %t13 = call { i32, { i64, ptr } } @compiler_2fsession_2ecompiler_2fsession_3aReader_2eNextLine(ptr %s0, ptr %s2, ptr %t11)
  %t14 = extractvalue { i32, { i64, ptr } } %t13, 1
  %t15 = extractvalue { i32, { i64, ptr } } %t13, 0
  store i32 %t15, ptr %l12
  %t16 = icmp ne i32 %t15, 0
  br i1 %t16, label %bb10, label %ok.17, !prof !99
ok.17:
  store { i64, ptr } %t14, ptr %l11
  br label %bb9
bb9:
  %t18 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t18, ptr %l9, !tbaa !27
  br label %bb12
bb10:
  %t19 = load i32, ptr %l12, !tbaa !23
  %t20 = ashr i32 %t19, 16
  %t22 = icmp eq i32 %t20, 1
  store i1 %t22, ptr %l14, !tbaa !21
  br label %bb11
bb11:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %bb20
bb12:
  %t23 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t23, ptr %l3, !tbaa !27
  %t24 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t26 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %s2, ptr %s2, { i64, ptr } %t24)
  store { i64, ptr } %t26, ptr %l16
  br label %bb13
bb13:
  %t27 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t28 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s2, ptr %s2, { i64, ptr } %t27, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d0, i32 0, i32 1) })
  store i1 %t28, ptr %l17
  br label %bb14
bb14:
  %t29 = load i1, ptr %l17, !tbaa !21
  br i1 %t29, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb16:
  br label %bb17
bb17:
  %t30 = load { i64, ptr }, ptr %l3, !tbaa !27
  call void @compiler_2fmcp_2ehandle(ptr %s2, ptr %v0, ptr %v1, { i64, ptr } %t30, ptr %a0, { i64, ptr } %a1)
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb19:
  br label %bb8
bb20:
  br label %bb21
bb21:
  br label %bb3
bb22:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2fmcp_2ecall(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, ptr %a1, ptr %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca [3 x { i64, ptr }]
  %l6 = alloca %"std/os:Output"
  %l8 = alloca [3 x { i64, ptr }]
  %l9 = alloca %"std/os:Output"
  %l10 = alloca i1
  %l11 = alloca { i64, ptr }
  %l13 = alloca { { i64, ptr }, i32 }
  %lp14 = alloca ptr
  %l15 = alloca i32
  %l17 = alloca { i64, ptr }
  %l19 = alloca i1
  %l21 = alloca i1
  %l22 = alloca { i64, ptr }
  %l23 = alloca %"std/os:Output"
  %l29 = alloca { i64, ptr }
  %l30 = alloca %"std/os:Output"
  %l31 = alloca i32
  %l33 = alloca i1
  %l34 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l42 = alloca i1
  %l43 = alloca i1
  %l45 = alloca i1
  %l47 = alloca { i64, ptr }
  %l48 = alloca %"std/os:Output"
  %l54 = alloca { i64, ptr }
  %l55 = alloca %"std/os:Output"
  %l56 = alloca i32
  %l58 = alloca i1
  %l59 = alloca { i64, ptr }
  %l66 = alloca { i64, ptr }
  %l68 = alloca i1
  %l70 = alloca i1
  %l72 = alloca i1
  %l74 = alloca i1
  %l76 = alloca i1
  %l78 = alloca i1
  %l80 = alloca i1
  %l85 = alloca { i64, ptr }
  %l87 = alloca i1
  %l91 = alloca { i64, ptr }
  %l92 = alloca ptr
  %l94 = alloca { i64, ptr }
  %l96 = alloca ptr
  %l97 = alloca i32
  %l99 = alloca i1
  %l102 = alloca ptr
  %l103 = alloca i1
  %l108 = alloca { i64, ptr }
  %l110 = alloca { i64, ptr }
  %l118 = alloca { { i64, ptr }, i32 }
  %l119 = alloca { i64, ptr }
  %l120 = alloca i64
  %l121 = alloca { i64, ptr }
  %l129 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t225 = alloca { i64, [2 x i64] }, align 8
  %t258 = alloca { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr }, align 8
  store { i64, ptr } %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = call { i64, ptr } @compiler_2fmcp_2estr(ptr %v1, ptr %v1, ptr %v1, ptr %t1, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d1, i32 0, i32 1) })
  store { i64, ptr } %t3, ptr %l17
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t4, ptr %l4, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t7 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t5, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d2, i32 0, i32 1) })
  store i1 %t7, ptr %l19
  br label %bb2
bb2:
  %t8 = load i1, ptr %l19, !tbaa !21
  br i1 %t8, label %bb3, label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t9 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t11 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s1, { i64, ptr } %t9, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d3, i32 0, i32 1) })
  store i1 %t11, ptr %l21
  br label %bb5
bb4:
  br label %bb16
bb5:
  %t12 = load i1, ptr %l21, !tbaa !21
  br i1 %t12, label %bb6, label %bb7
bb6:
  %t13 = call { i64, ptr } @compiler_2fmcp_2etoolError(ptr %v4, ptr %v4, { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d4, i32 0, i32 1) })
  store { i64, ptr } %t13, ptr %l22
  br label %bb8
bb7:
  br label %bb9
bb8:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t14 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t14, ptr %rv
  br label %ret
bb9:
  %t15 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t16 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t18 = insertvalue [3 x { i64, ptr }] undef, { i64, ptr } %t15, 0
  %t19 = insertvalue [3 x { i64, ptr }] %t18, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d5, i32 0, i32 1) }, 1
  %t21 = insertvalue [3 x { i64, ptr }] %t19, { i64, ptr } %t16, 2
  store [3 x { i64, ptr }] %t21, ptr %l5
  %t24 = insertvalue { i64, ptr } undef, i64 3, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %l5, 1
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d6, i32 0, i32 1) }, ptr %l29, !tbaa !27
  %t27 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t28 = call { i32, %"std/os:Output" } @std_2fos_2eExec(ptr %s1, ptr %s1, ptr %s1, ptr %s1, { i64, ptr } %t25, { i64, ptr } %t27, i1 true, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d7, i32 0, i32 1) })
  %t29 = extractvalue { i32, %"std/os:Output" } %t28, 1
  %t30 = extractvalue { i32, %"std/os:Output" } %t28, 0
  store i32 %t30, ptr %l31
  %t31 = icmp ne i32 %t30, 0
  br i1 %t31, label %bb11, label %ok.32, !prof !99
ok.32:
  store %"std/os:Output" %t29, ptr %l30
  br label %bb10
bb10:
  %t33 = load %"std/os:Output", ptr %l30
  store %"std/os:Output" %t33, ptr %l23
  br label %bb14
bb11:
  %t34 = load i32, ptr %l31, !tbaa !23
  %t35 = ashr i32 %t34, 16
  %t37 = icmp eq i32 %t35, 1
  store i1 %t37, ptr %l33, !tbaa !21
  br label %bb12
bb12:
  call void @__olang_ert_req_clear()
  %t38 = call { i64, ptr } @compiler_2fmcp_2etoolError(ptr %v4, ptr %v4, { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d8, i32 0, i32 1) })
  store { i64, ptr } %t38, ptr %l34
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t39 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t39, ptr %rv
  br label %ret
bb14:
  %t40 = load %"std/os:Output", ptr %l23
  store %"std/os:Output" %t40, ptr %l6
  %t41 = getelementptr %"std/os:Output", ptr %l6, i32 0, i32 1
  %t42 = load { i64, ptr }, ptr %t41, !tbaa !27
  %t43 = getelementptr %"std/os:Output", ptr %l6, i32 0, i32 2
  %t44 = load { i64, ptr }, ptr %t43, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t42, 1
  %t47 = extractvalue { i64, ptr } %t42, 0
  %t49 = extractvalue { i64, ptr } %t44, 1
  %t50 = extractvalue { i64, ptr } %t44, 0
  %t51 = add i64 %t47, %t50
  %t52 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t51)
  call void @olang_textcopy(ptr %t52, ptr %t46, i64 %t47)
  %t53 = getelementptr i8, ptr %t52, i64 %t47
  call void @olang_textcopy(ptr %t53, ptr %t49, i64 %t50)
  %t54 = insertvalue { i64, ptr } undef, i64 %t51, 0
  %t55 = insertvalue { i64, ptr } %t54, ptr %t52, 1
  %t57 = extractvalue { i64, ptr } %t55, 0
  %t58 = extractvalue { i64, ptr } %t55, 1
  %t59 = mul i64 %t57, 1
  %t60 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t59)
  call void @llvm.memcpy.p0.p0.i64(ptr %t60, ptr %t58, i64 %t59, i1 false)
  %t61 = insertvalue { i64, ptr } undef, i64 %t57, 0
  %t62 = insertvalue { i64, ptr } %t61, ptr %t60, 1
  %t63 = getelementptr %"std/os:Output", ptr %l6, i32 0, i32 0
  %t64 = load i32, ptr %t63, !tbaa !23
  %t67 = call { i64, ptr } @compiler_2fmcp_2etestResult(ptr %v4, ptr %v4, { i64, ptr } %t62, i32 %t64)
  store { i64, ptr } %t67, ptr %l40
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t68 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t68, ptr %rv
  br label %ret
bb16:
  %t69 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t71 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t69, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d9, i32 0, i32 1) })
  store i1 %t71, ptr %l42
  br label %bb17
bb17:
  %t72 = load i1, ptr %l42, !tbaa !21
  br i1 %t72, label %bb18, label %bb19
bb18:
  %t73 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t75 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t73, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d10, i32 0, i32 1) })
  store i1 %t75, ptr %l45
  br label %bb20
bb19:
  store i1 false, ptr %l43, !tbaa !21
  br label %bb21
bb20:
  %t76 = load i1, ptr %l45, !tbaa !21
  store i1 %t76, ptr %l43, !tbaa !21
  br label %bb21
bb21:
  %t77 = load i1, ptr %l43, !tbaa !21
  br i1 %t77, label %bb22, label %bb23
bb22:
  store %olang.scope zeroinitializer, ptr %s5
  %t78 = load ptr, ptr %l1, !tbaa !29
  %t80 = call { i64, ptr } @compiler_2fmcp_2estr(ptr %v1, ptr %v1, ptr %v1, ptr %t78, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d11, i32 0, i32 1) })
  store { i64, ptr } %t80, ptr %l47
  br label %bb24
bb23:
  br label %bb31
bb24:
  %t81 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t82 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t85 = insertvalue [3 x { i64, ptr }] undef, { i64, ptr } %t82, 0
  %t86 = insertvalue [3 x { i64, ptr }] %t85, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d12, i32 0, i32 1) }, 1
  %t88 = insertvalue [3 x { i64, ptr }] %t86, { i64, ptr } %t81, 2
  store [3 x { i64, ptr }] %t88, ptr %l8
  %t91 = insertvalue { i64, ptr } undef, i64 3, 0
  %t92 = insertvalue { i64, ptr } %t91, ptr %l8, 1
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d6, i32 0, i32 1) }, ptr %l54, !tbaa !27
  %t94 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t95 = call { i32, %"std/os:Output" } @std_2fos_2eExec(ptr %s5, ptr %s5, ptr %s5, ptr %s5, { i64, ptr } %t92, { i64, ptr } %t94, i1 true, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d7, i32 0, i32 1) })
  %t96 = extractvalue { i32, %"std/os:Output" } %t95, 1
  %t97 = extractvalue { i32, %"std/os:Output" } %t95, 0
  store i32 %t97, ptr %l56
  %t98 = icmp ne i32 %t97, 0
  br i1 %t98, label %bb26, label %ok.99, !prof !99
ok.99:
  store %"std/os:Output" %t96, ptr %l55
  br label %bb25
bb25:
  %t100 = load %"std/os:Output", ptr %l55
  store %"std/os:Output" %t100, ptr %l48
  br label %bb29
bb26:
  %t101 = load i32, ptr %l56, !tbaa !23
  %t102 = ashr i32 %t101, 16
  %t104 = icmp eq i32 %t102, 1
  store i1 %t104, ptr %l58, !tbaa !21
  br label %bb27
bb27:
  call void @__olang_ert_req_clear()
  %t105 = call { i64, ptr } @compiler_2fmcp_2etoolError(ptr %v4, ptr %v4, { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d13, i32 0, i32 1) })
  store { i64, ptr } %t105, ptr %l59
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t106 = load { i64, ptr }, ptr %l59, !tbaa !27
  store { i64, ptr } %t106, ptr %rv
  br label %ret
bb29:
  %t107 = load %"std/os:Output", ptr %l48
  store %"std/os:Output" %t107, ptr %l9
  %t108 = getelementptr %"std/os:Output", ptr %l9, i32 0, i32 1
  %t109 = load { i64, ptr }, ptr %t108, !tbaa !27
  %t110 = getelementptr %"std/os:Output", ptr %l9, i32 0, i32 2
  %t111 = load { i64, ptr }, ptr %t110, !tbaa !27
  %t113 = extractvalue { i64, ptr } %t109, 1
  %t114 = extractvalue { i64, ptr } %t109, 0
  %t116 = extractvalue { i64, ptr } %t111, 1
  %t117 = extractvalue { i64, ptr } %t111, 0
  %t118 = add i64 %t114, %t117
  %t119 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t118)
  call void @olang_textcopy(ptr %t119, ptr %t113, i64 %t114)
  %t120 = getelementptr i8, ptr %t119, i64 %t114
  call void @olang_textcopy(ptr %t120, ptr %t116, i64 %t117)
  %t121 = insertvalue { i64, ptr } undef, i64 %t118, 0
  %t122 = insertvalue { i64, ptr } %t121, ptr %t119, 1
  %t124 = extractvalue { i64, ptr } %t122, 0
  %t125 = extractvalue { i64, ptr } %t122, 1
  %t126 = mul i64 %t124, 1
  %t127 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t126)
  call void @llvm.memcpy.p0.p0.i64(ptr %t127, ptr %t125, i64 %t126, i1 false)
  %t128 = insertvalue { i64, ptr } undef, i64 %t124, 0
  %t129 = insertvalue { i64, ptr } %t128, ptr %t127, 1
  %t130 = getelementptr %"std/os:Output", ptr %l9, i32 0, i32 0
  %t131 = load i32, ptr %t130, !tbaa !23
  %t133 = icmp ne i32 %t131, 0
  %t136 = call { i64, ptr } @compiler_2fmcp_2etextResult(ptr %v4, ptr %v4, { i64, ptr } %t129, i1 %t133)
  store { i64, ptr } %t136, ptr %l66
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t137 = load { i64, ptr }, ptr %l66, !tbaa !27
  store { i64, ptr } %t137, ptr %rv
  br label %ret
bb31:
  %t138 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t140 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t138, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d14, i32 0, i32 1) })
  store i1 %t140, ptr %l68
  br label %bb32
bb32:
  %t141 = load i1, ptr %l68, !tbaa !21
  %t142 = xor i1 %t141, true
  br i1 %t142, label %bb33, label %bb34
bb33:
  %t144 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t146 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t144, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d15, i32 0, i32 1) })
  store i1 %t146, ptr %l72
  br label %bb35
bb34:
  store i1 false, ptr %l70, !tbaa !21
  br label %bb36
bb35:
  %t147 = load i1, ptr %l72, !tbaa !21
  %t148 = xor i1 %t147, true
  store i1 %t148, ptr %l70, !tbaa !21
  br label %bb36
bb36:
  %t150 = load i1, ptr %l70, !tbaa !21
  br i1 %t150, label %bb37, label %bb38
bb37:
  %t151 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t153 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t151, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d16, i32 0, i32 1) })
  store i1 %t153, ptr %l76
  br label %bb39
bb38:
  store i1 false, ptr %l74, !tbaa !21
  br label %bb40
bb39:
  %t154 = load i1, ptr %l76, !tbaa !21
  %t155 = xor i1 %t154, true
  store i1 %t155, ptr %l74, !tbaa !21
  br label %bb40
bb40:
  %t157 = load i1, ptr %l74, !tbaa !21
  br i1 %t157, label %bb41, label %bb42
bb41:
  %t158 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t160 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t158, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d17, i32 0, i32 1) })
  store i1 %t160, ptr %l80
  br label %bb43
bb42:
  store i1 false, ptr %l78, !tbaa !21
  br label %bb44
bb43:
  %t161 = load i1, ptr %l80, !tbaa !21
  %t162 = xor i1 %t161, true
  store i1 %t162, ptr %l78, !tbaa !21
  br label %bb44
bb44:
  %t164 = load i1, ptr %l78, !tbaa !21
  br i1 %t164, label %bb45, label %bb46
bb45:
  %t165 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t166 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d18, i32 0, i32 1) }, 1
  %t167 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d18, i32 0, i32 1) }, 0
  %t169 = extractvalue { i64, ptr } %t165, 1
  %t170 = extractvalue { i64, ptr } %t165, 0
  %t171 = add i64 %t167, %t170
  %t172 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t171)
  call void @olang_textcopy(ptr %t172, ptr %t166, i64 %t167)
  %t173 = getelementptr i8, ptr %t172, i64 %t167
  call void @olang_textcopy(ptr %t173, ptr %t169, i64 %t170)
  %t174 = insertvalue { i64, ptr } undef, i64 %t171, 0
  %t175 = insertvalue { i64, ptr } %t174, ptr %t172, 1
  %t177 = extractvalue { i64, ptr } %t175, 0
  %t178 = extractvalue { i64, ptr } %t175, 1
  %t179 = mul i64 %t177, 1
  %t180 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t179)
  call void @llvm.memcpy.p0.p0.i64(ptr %t180, ptr %t178, i64 %t179, i1 false)
  %t181 = insertvalue { i64, ptr } undef, i64 %t177, 0
  %t182 = insertvalue { i64, ptr } %t181, ptr %t180, 1
  %t184 = call { i64, ptr } @compiler_2fmcp_2etoolError(ptr %v4, ptr %v4, { i64, ptr } %t182)
  store { i64, ptr } %t184, ptr %l85
  br label %bb47
bb46:
  br label %bb48
bb47:
  call void @__olang_scope_close(ptr %s0)
  %t185 = load { i64, ptr }, ptr %l85, !tbaa !27
  store { i64, ptr } %t185, ptr %rv
  br label %ret
bb48:
  %t186 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t188 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t186, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d19, i32 0, i32 1) })
  store i1 %t188, ptr %l87
  br label %bb49
bb49:
  %t189 = load i1, ptr %l87, !tbaa !21
  br i1 %t189, label %bb50, label %bb51
bb50:
  %t190 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t192 = extractvalue { i64, ptr } %t190, 1
  %t193 = extractvalue { i64, ptr } %t190, 0
  %t194 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d20, i32 0, i32 1) }, 1
  %t195 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d20, i32 0, i32 1) }, 0
  %t196 = add i64 %t193, %t195
  %t197 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t196)
  call void @olang_textcopy(ptr %t197, ptr %t192, i64 %t193)
  %t198 = getelementptr i8, ptr %t197, i64 %t193
  call void @olang_textcopy(ptr %t198, ptr %t194, i64 %t195)
  %t199 = insertvalue { i64, ptr } undef, i64 %t196, 0
  %t200 = insertvalue { i64, ptr } %t199, ptr %t197, 1
  %t202 = extractvalue { i64, ptr } %t200, 0
  %t203 = extractvalue { i64, ptr } %t200, 1
  %t204 = mul i64 %t202, 1
  %t205 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t204)
  call void @llvm.memcpy.p0.p0.i64(ptr %t205, ptr %t203, i64 %t204, i1 false)
  %t206 = insertvalue { i64, ptr } undef, i64 %t202, 0
  %t207 = insertvalue { i64, ptr } %t206, ptr %t205, 1
  %t209 = call { i64, ptr } @compiler_2fmcp_2etoolError(ptr %v4, ptr %v4, { i64, ptr } %t207)
  store { i64, ptr } %t209, ptr %l91
  br label %bb52
bb51:
  br label %bb53
bb52:
  call void @__olang_scope_close(ptr %s0)
  %t210 = load { i64, ptr }, ptr %l91, !tbaa !27
  store { i64, ptr } %t210, ptr %rv
  br label %ret
bb53:
  %t211 = load ptr, ptr %l1, !tbaa !29
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d21, i32 0, i32 1) }, ptr %l94, !tbaa !27
  %t212 = load { i64, ptr }, ptr %l94, !tbaa !27
  %t215 = call { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAt_3cstd_2fprelude_2ftext_3aString_3e(ptr %v1, ptr %v1, ptr %t211, { i64, ptr } %t212)
  %t216 = extractvalue { i32, ptr } %t215, 1
  %t217 = extractvalue { i32, ptr } %t215, 0
  store i32 %t217, ptr %l97
  %t218 = icmp ne i32 %t217, 0
  br i1 %t218, label %bb55, label %ok.219, !prof !99
ok.219:
  store ptr %t216, ptr %l96
  br label %bb54
bb54:
  %t220 = load ptr, ptr %l96, !tbaa !29
  store ptr %t220, ptr %l92, !tbaa !29
  br label %bb57
bb55:
  %t221 = load i32, ptr %l97, !tbaa !23
  %t222 = ashr i32 %t221, 16
  %t224 = icmp eq i32 %t222, 1
  store i1 %t224, ptr %l99, !tbaa !21
  br label %bb56
bb56:
  call void @__olang_ert_req_clear()
  store { i64, [2 x i64] } zeroinitializer, ptr %t225
  %t226 = getelementptr { i64, [2 x i64] }, ptr %t225, i32 0, i32 0
  store i64 0, ptr %t226
  %t227 = load { i64, [2 x i64] }, ptr %t225
  %t229 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 24, i64 8)
  store { i64, [2 x i64] } %t227, ptr %t229
  store ptr %t229, ptr %l92, !tbaa !29
  br label %bb57
bb57:
  %t231 = load ptr, ptr %l92, !tbaa !29
  store ptr %t231, ptr %l102, !tbaa !29
  store i1 false, ptr %l103, !tbaa !21
  %t232 = load ptr, ptr %l102, !tbaa !29
  %t233 = icmp ne ptr %t232, null
  br i1 %t233, label %bb58, label %bb59
bb58:
  %t235 = load ptr, ptr %l102, !tbaa !29
  %t236 = load i64, ptr %t235, !range !{i64 0, i64 8}
  %t238 = icmp eq i64 %t236, 0
  store i1 %t238, ptr %l103, !tbaa !21
  br label %bb59
bb59:
  %t239 = load i1, ptr %l103, !tbaa !21
  %t240 = xor i1 %t239, true
  store i1 %t240, ptr %l10, !tbaa !21
  %t242 = load ptr, ptr %l1, !tbaa !29
  %t244 = call { i64, ptr } @compiler_2fmcp_2estr(ptr %v1, ptr %v1, ptr %v1, ptr %t242, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d22, i32 0, i32 1) })
  store { i64, ptr } %t244, ptr %l108
  br label %bb60
bb60:
  %t245 = load { i64, ptr }, ptr %l108, !tbaa !27
  store { i64, ptr } %t245, ptr %l11, !tbaa !27
  %t246 = load ptr, ptr %l1, !tbaa !29
  %t248 = call { i64, ptr } @compiler_2fmcp_2estr(ptr %v1, ptr %v1, ptr %v1, ptr %t246, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d23, i32 0, i32 1) })
  store { i64, ptr } %t248, ptr %l110
  br label %bb61
bb61:
  %t249 = load { i64, ptr }, ptr %l110, !tbaa !27
  %t250 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t251 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t252 = load i1, ptr %l10, !tbaa !21
  %t253 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t256 = getelementptr { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr }, ptr null, i32 1
  %t257 = ptrtoint ptr %t256 to i64
  %t259 = getelementptr { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %t258, i32 0, i32 0
  store { i64, ptr } %t250, ptr %t259, !tbaa !28
  %t261 = getelementptr { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %t258, i32 0, i32 1
  store { i64, ptr } %t251, ptr %t261, !tbaa !28
  %t263 = getelementptr { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %t258, i32 0, i32 2
  store i1 %t252, ptr %t263, !tbaa !28
  %t265 = getelementptr { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %t258, i32 0, i32 3
  store { i64, ptr } %t253, ptr %t265, !tbaa !28
  %t267 = getelementptr { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %t258, i32 0, i32 4
  store { i64, ptr } %t249, ptr %t267, !tbaa !28
  %t269 = getelementptr { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %t258, i32 0, i32 5
  store ptr %a2, ptr %t269, !tbaa !28
  call void @__olang_scope_escape(ptr %v0)
  %t271 = getelementptr { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %t258, i32 0, i32 6
  store ptr %v0, ptr %t271, !tbaa !28
  call void @__olang_scope_escape(ptr %v1)
  %t272 = getelementptr { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %t258, i32 0, i32 7
  store ptr %v1, ptr %t272, !tbaa !28
  call void @__olang_scope_escape(ptr %v1)
  %t273 = getelementptr { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %t258, i32 0, i32 8
  store ptr %v1, ptr %t273, !tbaa !28
  call void @__olang_scope_escape(ptr %v1)
  %t274 = getelementptr { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %t258, i32 0, i32 9
  store ptr %v1, ptr %t274, !tbaa !28
  call void @__olang_scope_escape(ptr %v2)
  %t275 = getelementptr { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %t258, i32 0, i32 10
  store ptr %v2, ptr %t275, !tbaa !28
  %t276 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_24, 0
  %t277 = insertvalue { ptr, ptr } %t276, ptr %t258, 1
  %t279 = extractvalue { ptr, ptr } %t277, 0
  %t280 = extractvalue { ptr, ptr } %t277, 1
  %t281 = call { { i64, ptr }, i32 } @compiler_2fsession_2eChildOutput(ptr %s0, ptr %s0, ptr %t279, ptr %t280)
  store { { i64, ptr }, i32 } %t281, ptr %l118
  br label %bb62
bb62:
  %t282 = load { { i64, ptr }, i32 }, ptr %l118
  store { { i64, ptr }, i32 } %t282, ptr %l13
  %t283 = getelementptr { { i64, ptr }, i32 }, ptr %l13, i32 0, i32 0
  %t284 = load { i64, ptr }, ptr %t283, !tbaa !27
  store { i64, ptr } %t284, ptr %l119, !tbaa !27
  %t285 = load { i64, ptr }, ptr %l119, !tbaa !27
  %t286 = extractvalue { i64, ptr } %t285, 0
  store i64 %t286, ptr %l120, !tbaa !24
  %t287 = load i64, ptr %l120, !tbaa !24
  %t288 = mul i64 %t287, 1
  %t289 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t288)
  %t290 = insertvalue { i64, ptr } undef, i64 %t287, 0
  %t291 = insertvalue { i64, ptr } %t290, ptr %t289, 1
  store { i64, ptr } %t291, ptr %l121, !tbaa !27
  %t292 = getelementptr { i64, ptr }, ptr %l121, i32 0, i32 1
  %t293 = load ptr, ptr %t292, !tbaa !27
  %t294 = getelementptr { i64, ptr }, ptr %l119, i32 0, i32 1
  %t295 = load ptr, ptr %t294, !tbaa !27
  %t296 = load i64, ptr %l120, !tbaa !24
  %t297 = mul i64 %t296, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t293, ptr %t295, i64 %t297, i1 false)
  %t298 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 16, i64 8)
  store ptr %t298, ptr %lp14
  %t299 = load { i64, ptr }, ptr %l121, !tbaa !27
  %t300 = load ptr, ptr %lp14
  store { i64, ptr } %t299, ptr %t300, !tbaa !27
  %t301 = getelementptr { { i64, ptr }, i32 }, ptr %l13, i32 0, i32 1
  %t302 = load i32, ptr %t301, !tbaa !23
  store i32 %t302, ptr %l15, !tbaa !23
  %t304 = load i32, ptr %l15, !tbaa !23
  %t306 = icmp ne i32 %t304, 0
  br i1 %t306, label %bb63, label %bb64
bb63:
  %t308 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t309 = load i32, ptr %l15, !tbaa !23
  %t310 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d25, i32 0, i32 1) }, 1
  %t311 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d25, i32 0, i32 1) }, 0
  %t313 = extractvalue { i64, ptr } %t308, 1
  %t314 = extractvalue { i64, ptr } %t308, 0
  %t315 = add i64 %t311, %t314
  %t316 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d26, i32 0, i32 1) }, 1
  %t317 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d26, i32 0, i32 1) }, 0
  %t318 = add i64 %t315, %t317
  %t320 = sext i32 %t309 to i64
  %t321 = call i64 @__olang_fmt_i64(ptr null, i64 %t320)
  %t322 = add i64 %t318, %t321
  %t323 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d27, i32 0, i32 1) }, 1
  %t324 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d27, i32 0, i32 1) }, 0
  %t325 = add i64 %t322, %t324
  %t326 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t325)
  call void @olang_textcopy(ptr %t326, ptr %t310, i64 %t311)
  %t327 = getelementptr i8, ptr %t326, i64 %t311
  call void @olang_textcopy(ptr %t327, ptr %t313, i64 %t314)
  %t328 = getelementptr i8, ptr %t327, i64 %t314
  call void @olang_textcopy(ptr %t328, ptr %t316, i64 %t317)
  %t329 = getelementptr i8, ptr %t328, i64 %t317
  %t330 = call i64 @__olang_fmt_i64(ptr %t329, i64 %t320)
  %t331 = getelementptr i8, ptr %t329, i64 %t321
  call void @olang_textcopy(ptr %t331, ptr %t323, i64 %t324)
  %t332 = insertvalue { i64, ptr } undef, i64 %t325, 0
  %t333 = insertvalue { i64, ptr } %t332, ptr %t326, 1
  %t335 = extractvalue { i64, ptr } %t333, 0
  %t336 = extractvalue { i64, ptr } %t333, 1
  %t337 = mul i64 %t335, 1
  %t338 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t337)
  call void @llvm.memcpy.p0.p0.i64(ptr %t338, ptr %t336, i64 %t337, i1 false)
  %t339 = insertvalue { i64, ptr } undef, i64 %t335, 0
  %t340 = insertvalue { i64, ptr } %t339, ptr %t338, 1
  %t342 = call { i64, ptr } @compiler_2fmcp_2etoolError(ptr %v4, ptr %v4, { i64, ptr } %t340)
  store { i64, ptr } %t342, ptr %l129
  br label %bb65
bb64:
  br label %bb66
bb65:
  call void @__olang_scope_close(ptr %s0)
  %t343 = load { i64, ptr }, ptr %l129, !tbaa !27
  store { i64, ptr } %t343, ptr %rv
  br label %ret
bb66:
  %t344 = load ptr, ptr %lp14
  %t345 = load { i64, ptr }, ptr %t344, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t345, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fmcp_2echeckResult(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca %"std/prelude/text:StringBuilder"
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca %"compiler/diag:Item"
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l19 = alloca %"compiler/diag:Item"
  %l20 = alloca { i64, ptr }
  %l21 = alloca %"std/prelude/text:StringBuilder"
  %l23 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l24 = alloca %"std/prelude/text:StringBuilder"
  %l27 = alloca i64
  %l31 = alloca i64
  %l34 = alloca i64
  %l54 = alloca %"compiler/diag:Item"
  %l70 = alloca i64
  %l74 = alloca i64
  %l77 = alloca i64
  %l97 = alloca %"compiler/diag:Item"
  %l120 = alloca { i64, ptr }
  %l122 = alloca { i64, ptr }
  %l124 = alloca { i64, ptr }
  %l127 = alloca %"std/prelude/text:StringBuilder"
  %l131 = alloca ptr
  %l133 = alloca { i64, ptr }
  %l137 = alloca { i64, ptr }
  %l138 = alloca { i64, ptr }
  %l139 = alloca i64
  %l140 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eItems(ptr %v1, ptr %s0, ptr %t1)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %l23
  br label %bb1
bb1:
  %t4 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l23
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %l2
  %t5 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t5, ptr %l24
  br label %bb2
bb2:
  %t6 = load %"std/prelude/text:StringBuilder", ptr %l24
  store %"std/prelude/text:StringBuilder" %t6, ptr %l3
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l3, { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d28, i32 0, i32 1) })
  br label %bb3
bb3:
  store i64 0, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  %t9 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3aItem_3e_2eLen_3ccompiler_2fdiag_3aItem_3e(ptr %s0, ptr %l2)
  store i64 %t9, ptr %l27
  br label %bb4
bb4:
  %t10 = load i64, ptr %l27, !tbaa !24
  store i64 %t10, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t11 = load i64, ptr %l6, !tbaa !24
  %t12 = load i64, ptr %l5, !tbaa !24
  %t15 = icmp sgt i64 %t11, %t12
  br i1 %t15, label %bb5, label %bb6
bb5:
  %t17 = load i64, ptr %l7, !tbaa !24
  %t19 = icmp sgt i64 %t17, 0
  br i1 %t19, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb10
bb7:
  %t21 = load i64, ptr %l6, !tbaa !24
  %t22 = load i64, ptr %l5, !tbaa !24
  %t25 = sub i64 %t21, %t22
  %t26 = load i64, ptr %l7, !tbaa !24
  %t29 = add i64 %t25, %t26
  %t31 = sub i64 %t29, 1
  %t32 = load i64, ptr %l7, !tbaa !24
  %t35 = sdiv i64 %t31, %t32
  store i64 %t35, ptr %l34, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l34, !tbaa !24
  br label %bb9
bb9:
  %t37 = load i64, ptr %l34, !tbaa !24
  store i64 %t37, ptr %l31, !tbaa !24
  br label %bb10
bb10:
  %t38 = load i64, ptr %l31, !tbaa !24
  store i64 %t38, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s2
  %t39 = load i64, ptr %l9, !tbaa !24
  %t40 = load i64, ptr %l8, !tbaa !24
  %t43 = icmp slt i64 %t39, %t40
  %t45 = xor i1 %t43, true
  br i1 %t45, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %bb50
bb13:
  br label %bb14
bb14:
  %t47 = load i64, ptr %l5, !tbaa !24
  %t48 = load i64, ptr %l9, !tbaa !24
  %t49 = load i64, ptr %l7, !tbaa !24
  %t52 = mul i64 %t48, %t49
  %t55 = add i64 %t47, %t52
  store i64 %t55, ptr %l10, !tbaa !24
  %t57 = load i64, ptr %l10, !tbaa !24
  %t60 = call %"compiler/diag:Item" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3aItem_3e_2eAt_3ccompiler_2fdiag_3aItem_3e(ptr %s0, ptr %s0, ptr %l2, i64 %t57)
  store %"compiler/diag:Item" %t60, ptr %l54
  br label %bb15
bb15:
  %t61 = load %"compiler/diag:Item", ptr %l54
  store %"compiler/diag:Item" %t61, ptr %l11
  %t62 = getelementptr %"compiler/diag:Item", ptr %l11, i32 0, i32 0
  %t63 = load i1, ptr %t62, !tbaa !21
  %t65 = xor i1 %t63, true
  br i1 %t65, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s2)
  br label %bb49
bb17:
  br label %bb18
bb18:
  %t67 = load i64, ptr %l4, !tbaa !24
  %t69 = icmp sgt i64 %t67, 0
  br i1 %t69, label %bb19, label %bb20
bb19:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l3, i8 44)
  br label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb22
bb22:
  %t72 = load i64, ptr %l4, !tbaa !24
  %t74 = add i64 %t72, 1
  store i64 %t74, ptr %l4, !tbaa !24
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t77 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fmcp_2elocated(ptr %s0, ptr %v0, ptr %v1, ptr %s0, ptr %l3, ptr %t76, ptr %t77, ptr %l11)
  br label %bb23
bb23:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %l3, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d29, i32 0, i32 1) })
  br label %bb24
bb24:
  store i64 0, ptr %l12, !tbaa !24
  %t83 = load i64, ptr %l10, !tbaa !24
  %t85 = add i64 %t83, 1
  store i64 %t85, ptr %l13, !tbaa !24
  %t88 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3aItem_3e_2eLen_3ccompiler_2fdiag_3aItem_3e(ptr %s0, ptr %l2)
  store i64 %t88, ptr %l70
  br label %bb25
bb25:
  %t89 = load i64, ptr %l70, !tbaa !24
  store i64 %t89, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t90 = load i64, ptr %l14, !tbaa !24
  %t91 = load i64, ptr %l13, !tbaa !24
  %t94 = icmp sgt i64 %t90, %t91
  br i1 %t94, label %bb26, label %bb27
bb26:
  %t96 = load i64, ptr %l15, !tbaa !24
  %t98 = icmp sgt i64 %t96, 0
  br i1 %t98, label %bb28, label %bb29
bb27:
  store i64 0, ptr %l74, !tbaa !24
  br label %bb31
bb28:
  %t100 = load i64, ptr %l14, !tbaa !24
  %t101 = load i64, ptr %l13, !tbaa !24
  %t104 = sub i64 %t100, %t101
  %t105 = load i64, ptr %l15, !tbaa !24
  %t108 = add i64 %t104, %t105
  %t110 = sub i64 %t108, 1
  %t111 = load i64, ptr %l15, !tbaa !24
  %t114 = sdiv i64 %t110, %t111
  store i64 %t114, ptr %l77, !tbaa !24
  br label %bb30
bb29:
  store i64 0, ptr %l77, !tbaa !24
  br label %bb30
bb30:
  %t116 = load i64, ptr %l77, !tbaa !24
  store i64 %t116, ptr %l74, !tbaa !24
  br label %bb31
bb31:
  %t117 = load i64, ptr %l74, !tbaa !24
  store i64 %t117, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb32
bb32:
  %t118 = load i64, ptr %l17, !tbaa !24
  %t119 = load i64, ptr %l16, !tbaa !24
  %t122 = icmp slt i64 %t118, %t119
  %t124 = xor i1 %t122, true
  br i1 %t124, label %bb33, label %bb34
bb33:
  br label %bb47
bb34:
  br label %bb35
bb35:
  %t126 = load i64, ptr %l13, !tbaa !24
  %t127 = load i64, ptr %l17, !tbaa !24
  %t128 = load i64, ptr %l15, !tbaa !24
  %t131 = mul i64 %t127, %t128
  %t134 = add i64 %t126, %t131
  %t139 = call %"compiler/diag:Item" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3aItem_3e_2eAt_3ccompiler_2fdiag_3aItem_3e(ptr %s0, ptr %s0, ptr %l2, i64 %t134)
  store %"compiler/diag:Item" %t139, ptr %l97
  br label %bb36
bb36:
  %t140 = load %"compiler/diag:Item", ptr %l97
  store %"compiler/diag:Item" %t140, ptr %l19
  %t141 = getelementptr %"compiler/diag:Item", ptr %l19, i32 0, i32 0
  %t142 = load i1, ptr %t141, !tbaa !21
  br i1 %t142, label %bb37, label %bb38
bb37:
  br label %bb47
bb38:
  br label %bb39
bb39:
  %t144 = load i64, ptr %l12, !tbaa !24
  %t146 = icmp sgt i64 %t144, 0
  br i1 %t146, label %bb40, label %bb41
bb40:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l3, i8 44)
  br label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb43
bb43:
  %t149 = load i64, ptr %l12, !tbaa !24
  %t151 = add i64 %t149, 1
  store i64 %t151, ptr %l12, !tbaa !24
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t154 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fmcp_2elocated(ptr %s0, ptr %v0, ptr %v1, ptr %s0, ptr %l3, ptr %t153, ptr %t154, ptr %l19)
  br label %bb44
bb44:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l3, i8 125)
  br label %bb45
bb45:
  br label %bb46
bb46:
  %t160 = load i64, ptr %l17, !tbaa !24
  %t162 = add i64 %t160, 1
  store i64 %t162, ptr %l17, !tbaa !24
  br label %bb32
bb47:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %l3, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d30, i32 0, i32 1) })
  br label %bb48
bb48:
  call void @__olang_scope_close(ptr %s2)
  br label %bb49
bb49:
  %t165 = load i64, ptr %l9, !tbaa !24
  %t167 = add i64 %t165, 1
  store i64 %t167, ptr %l9, !tbaa !24
  br label %bb11
bb50:
  %t169 = load i64, ptr %l4, !tbaa !24
  %t170 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d31, i32 0, i32 1) }, 1
  %t171 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d31, i32 0, i32 1) }, 0
  %t173 = call i64 @__olang_fmt_i64(ptr null, i64 %t169)
  %t174 = add i64 %t171, %t173
  %t175 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d32, i32 0, i32 1) }, 1
  %t176 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d32, i32 0, i32 1) }, 0
  %t177 = add i64 %t174, %t176
  %t178 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t177)
  call void @olang_textcopy(ptr %t178, ptr %t170, i64 %t171)
  %t179 = getelementptr i8, ptr %t178, i64 %t171
  %t180 = call i64 @__olang_fmt_i64(ptr %t179, i64 %t169)
  %t181 = getelementptr i8, ptr %t179, i64 %t173
  call void @olang_textcopy(ptr %t181, ptr %t175, i64 %t176)
  %t182 = insertvalue { i64, ptr } undef, i64 %t177, 0
  %t183 = insertvalue { i64, ptr } %t182, ptr %t178, 1
  %t185 = extractvalue { i64, ptr } %t183, 0
  %t186 = extractvalue { i64, ptr } %t183, 1
  %t187 = mul i64 %t185, 1
  %t188 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t187)
  call void @llvm.memcpy.p0.p0.i64(ptr %t188, ptr %t186, i64 %t187, i1 false)
  %t189 = insertvalue { i64, ptr } undef, i64 %t185, 0
  %t190 = insertvalue { i64, ptr } %t189, ptr %t188, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l3, { i64, ptr } %t190)
  br label %bb51
bb51:
  %t193 = load i64, ptr %l4, !tbaa !24
  %t195 = icmp eq i64 %t193, 0
  br i1 %t195, label %bb52, label %bb53
bb52:
  store { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d33, i32 0, i32 1) }, ptr %l120, !tbaa !27
  br label %bb56
bb53:
  %t197 = load ptr, ptr %l1, !tbaa !29
  %t199 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eRender(ptr %v1, ptr %s0, ptr %t197)
  store { i64, ptr } %t199, ptr %l122
  br label %bb54
bb54:
  %t200 = load ptr, ptr %l1, !tbaa !29
  %t202 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eSummary(ptr %v1, ptr %s0, ptr %t200)
  store { i64, ptr } %t202, ptr %l124
  br label %bb55
bb55:
  %t203 = load { i64, ptr }, ptr %l122, !tbaa !27
  %t204 = extractvalue { i64, ptr } %t203, 1
  %t205 = extractvalue { i64, ptr } %t203, 0
  %t206 = load { i64, ptr }, ptr %l124, !tbaa !27
  %t207 = extractvalue { i64, ptr } %t206, 1
  %t208 = extractvalue { i64, ptr } %t206, 0
  %t209 = add i64 %t205, %t208
  %t210 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t209)
  call void @olang_textcopy(ptr %t210, ptr %t204, i64 %t205)
  %t211 = getelementptr i8, ptr %t210, i64 %t205
  call void @olang_textcopy(ptr %t211, ptr %t207, i64 %t208)
  %t212 = insertvalue { i64, ptr } undef, i64 %t209, 0
  %t213 = insertvalue { i64, ptr } %t212, ptr %t210, 1
  %t215 = extractvalue { i64, ptr } %t213, 0
  %t216 = extractvalue { i64, ptr } %t213, 1
  %t217 = mul i64 %t215, 1
  %t218 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t217)
  call void @llvm.memcpy.p0.p0.i64(ptr %t218, ptr %t216, i64 %t217, i1 false)
  %t219 = insertvalue { i64, ptr } undef, i64 %t215, 0
  %t220 = insertvalue { i64, ptr } %t219, ptr %t218, 1
  store { i64, ptr } %t220, ptr %l120, !tbaa !27
  br label %bb56
bb56:
  %t222 = load { i64, ptr }, ptr %l120, !tbaa !27
  store { i64, ptr } %t222, ptr %l20, !tbaa !27
  %t223 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t223, ptr %l127
  br label %bb57
bb57:
  %t224 = load %"std/prelude/text:StringBuilder", ptr %l127
  store %"std/prelude/text:StringBuilder" %t224, ptr %l21
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l21, { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d34, i32 0, i32 1) })
  br label %bb58
bb58:
  %t226 = load { i64, ptr }, ptr %l20, !tbaa !27
  call void @compiler_2fsession_2eJsonStr(ptr %s0, ptr %s0, ptr %l21, { i64, ptr } %t226)
  br label %bb59
bb59:
  store ptr %l21, ptr %l131, !tbaa !29
  %t230 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l3)
  store { i64, ptr } %t230, ptr %l133
  br label %bb60
bb60:
  %t231 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d35, i32 0, i32 1) }, 1
  %t232 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d35, i32 0, i32 1) }, 0
  %t233 = load { i64, ptr }, ptr %l133, !tbaa !27
  %t234 = extractvalue { i64, ptr } %t233, 1
  %t235 = extractvalue { i64, ptr } %t233, 0
  %t236 = add i64 %t232, %t235
  %t237 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d36, i32 0, i32 1) }, 1
  %t238 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d36, i32 0, i32 1) }, 0
  %t239 = add i64 %t236, %t238
  %t240 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t239)
  call void @olang_textcopy(ptr %t240, ptr %t231, i64 %t232)
  %t241 = getelementptr i8, ptr %t240, i64 %t232
  call void @olang_textcopy(ptr %t241, ptr %t234, i64 %t235)
  %t242 = getelementptr i8, ptr %t241, i64 %t235
  call void @olang_textcopy(ptr %t242, ptr %t237, i64 %t238)
  %t243 = insertvalue { i64, ptr } undef, i64 %t239, 0
  %t244 = insertvalue { i64, ptr } %t243, ptr %t240, 1
  %t246 = extractvalue { i64, ptr } %t244, 0
  %t247 = extractvalue { i64, ptr } %t244, 1
  %t248 = mul i64 %t246, 1
  %t249 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t248)
  call void @llvm.memcpy.p0.p0.i64(ptr %t249, ptr %t247, i64 %t248, i1 false)
  %t250 = insertvalue { i64, ptr } undef, i64 %t246, 0
  %t251 = insertvalue { i64, ptr } %t250, ptr %t249, 1
  %t252 = load ptr, ptr %l131, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t252, { i64, ptr } %t251)
  br label %bb61
bb61:
  %t255 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l21)
  store { i64, ptr } %t255, ptr %l137
  br label %bb62
bb62:
  %t256 = load { i64, ptr }, ptr %l137, !tbaa !27
  store { i64, ptr } %t256, ptr %l138, !tbaa !27
  %t257 = load { i64, ptr }, ptr %l138, !tbaa !27
  %t258 = extractvalue { i64, ptr } %t257, 0
  store i64 %t258, ptr %l139, !tbaa !24
  %t259 = load i64, ptr %l139, !tbaa !24
  %t260 = mul i64 %t259, 1
  %t261 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t260)
  %t262 = insertvalue { i64, ptr } undef, i64 %t259, 0
  %t263 = insertvalue { i64, ptr } %t262, ptr %t261, 1
  store { i64, ptr } %t263, ptr %l140, !tbaa !27
  %t264 = getelementptr { i64, ptr }, ptr %l140, i32 0, i32 1
  %t265 = load ptr, ptr %t264, !tbaa !27
  %t266 = getelementptr { i64, ptr }, ptr %l138, i32 0, i32 1
  %t267 = load ptr, ptr %t266, !tbaa !27
  %t268 = load i64, ptr %l139, !tbaa !24
  %t269 = mul i64 %t268, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t265, ptr %t267, i64 %t269, i1 false)
  %t270 = load { i64, ptr }, ptr %l140, !tbaa !27
  store { i64, ptr } %t270, ptr %l138, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t271 = load { i64, ptr }, ptr %l138, !tbaa !27
  store { i64, ptr } %t271, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fmcp_2ecompilerUnderTest(ptr %v0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i32
  %l5 = alloca i1
  %l7 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %s0, ptr %s0, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d37, i32 0, i32 1) })
  %t2 = extractvalue { i32, { i64, ptr } } %t1, 1
  %t3 = extractvalue { i32, { i64, ptr } } %t1, 0
  store i32 %t3, ptr %l3
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5, !prof !99
ok.5:
  store { i64, ptr } %t2, ptr %l2
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t6, ptr %l1, !tbaa !27
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d38, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb4
bb4:
  %t7 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t7, ptr %l0, !tbaa !27
  %t8 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t10 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t8, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d39, i32 0, i32 1) })
  store i1 %t10, ptr %l5
  br label %bb5
bb5:
  %t11 = load i1, ptr %l5, !tbaa !21
  %t12 = xor i1 %t11, true
  br i1 %t12, label %bb6, label %bb7
bb6:
  %t14 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t14, 1
  %t17 = extractvalue { i64, ptr } %t14, 0
  %t18 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t17)
  call void @olang_textcopy(ptr %t18, ptr %t16, i64 %t17)
  %t19 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  store { i64, ptr } %t20, ptr %l7, !tbaa !27
  br label %bb8
bb7:
  store { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d40, i32 0, i32 1) }, ptr %l10, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t22, ptr %l7, !tbaa !27
  br label %bb8
bb8:
  %t24 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t24, 0
  store i64 %t25, ptr %l12, !tbaa !24
  %t26 = load i64, ptr %l12, !tbaa !24
  %t27 = mul i64 %t26, 1
  %t28 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t27)
  %t29 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t30 = insertvalue { i64, ptr } %t29, ptr %t28, 1
  store { i64, ptr } %t30, ptr %l13, !tbaa !27
  %t31 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = load i64, ptr %l12, !tbaa !24
  %t36 = mul i64 %t35, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t32, ptr %t34, i64 %t36, i1 false)
  %t37 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t37, ptr %l7, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t38 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t38, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fmcp_2eerrorReply(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %l3 = alloca %"std/prelude/text:StringBuilder"
  %l4 = alloca %"std/prelude/text:StringBuilder"
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l4
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l4
  store %"std/prelude/text:StringBuilder" %t2, ptr %l3
  %t5 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d41, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d41, i32 0, i32 1) }, 0
  %t8 = extractvalue { i64, ptr } %a0, 1
  %t9 = extractvalue { i64, ptr } %a0, 0
  %t10 = add i64 %t6, %t9
  %t11 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d42, i32 0, i32 1) }, 1
  %t12 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d42, i32 0, i32 1) }, 0
  %t13 = add i64 %t10, %t12
  %t15 = call i64 @__olang_fmt_i64(ptr null, i64 %a1)
  %t16 = add i64 %t13, %t15
  %t17 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d43, i32 0, i32 1) }, 1
  %t18 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d43, i32 0, i32 1) }, 0
  %t19 = add i64 %t16, %t18
  %t20 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t19)
  call void @olang_textcopy(ptr %t20, ptr %t5, i64 %t6)
  %t21 = getelementptr i8, ptr %t20, i64 %t6
  call void @olang_textcopy(ptr %t21, ptr %t8, i64 %t9)
  %t22 = getelementptr i8, ptr %t21, i64 %t9
  call void @olang_textcopy(ptr %t22, ptr %t11, i64 %t12)
  %t23 = getelementptr i8, ptr %t22, i64 %t12
  %t24 = call i64 @__olang_fmt_i64(ptr %t23, i64 %a1)
  %t25 = getelementptr i8, ptr %t23, i64 %t15
  call void @olang_textcopy(ptr %t25, ptr %t17, i64 %t18)
  %t26 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t20, 1
  %t29 = extractvalue { i64, ptr } %t27, 0
  %t30 = extractvalue { i64, ptr } %t27, 1
  %t31 = mul i64 %t29, 1
  %t32 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t31)
  call void @llvm.memcpy.p0.p0.i64(ptr %t32, ptr %t30, i64 %t31, i1 false)
  %t33 = insertvalue { i64, ptr } undef, i64 %t29, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t32, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l3, { i64, ptr } %t34)
  br label %bb2
bb2:
  call void @compiler_2fsession_2eJsonStr(ptr %s0, ptr %v1, ptr %l3, { i64, ptr } %a2)
  br label %bb3
bb3:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l3, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d44, i32 0, i32 1) })
  br label %bb4
bb4:
  %t42 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l3)
  store { i64, ptr } %t42, ptr %l14
  br label %bb5
bb5:
  %t43 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t43, ptr %l15, !tbaa !27
  %t44 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t44, 0
  store i64 %t45, ptr %l16, !tbaa !24
  %t46 = load i64, ptr %l16, !tbaa !24
  %t47 = mul i64 %t46, 1
  %t48 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t47)
  %t49 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t48, 1
  store { i64, ptr } %t50, ptr %l17, !tbaa !27
  %t51 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !27
  %t53 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !27
  %t55 = load i64, ptr %l16, !tbaa !24
  %t56 = mul i64 %t55, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t52, ptr %t54, i64 %t56, i1 false)
  %t57 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t57, ptr %l15, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t58 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t58, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fmcp_2ehandle(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, ptr %a1, { i64, ptr } %a2) #0 {
entry:
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"std/prelude/text:StringBuilder"
  %l8 = alloca { i64, ptr }
  %l10 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca i32
  %l15 = alloca i1
  %l16 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l23 = alloca i1
  %l24 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l29 = alloca ptr
  %l30 = alloca i32
  %l32 = alloca i1
  %l34 = alloca { i64, ptr }
  %l36 = alloca ptr
  %l37 = alloca i32
  %l39 = alloca i1
  %l40 = alloca { i64, ptr }
  %l41 = alloca i32
  %l43 = alloca i1
  %l44 = alloca %"std/prelude/text:StringBuilder"
  %l55 = alloca { i64, ptr }
  %l57 = alloca { i64, ptr }
  %l58 = alloca { i64, ptr }
  %l61 = alloca i1
  %l63 = alloca i1
  %l65 = alloca { i64, ptr }
  %l68 = alloca i1
  %l73 = alloca { i64, ptr }
  %l76 = alloca i1
  %l77 = alloca { i64, ptr }
  %l80 = alloca { i64, ptr }
  %l82 = alloca ptr
  %l83 = alloca i32
  %l85 = alloca i1
  %l87 = alloca { i64, ptr }
  %l89 = alloca ptr
  %l90 = alloca i32
  %l92 = alloca i1
  %l93 = alloca { i64, ptr }
  %l94 = alloca i32
  %l96 = alloca i1
  %l97 = alloca ptr
  %l100 = alloca { i64, ptr }
  %l102 = alloca ptr
  %l103 = alloca i32
  %l105 = alloca i1
  %l107 = alloca { i64, ptr }
  %l109 = alloca ptr
  %l110 = alloca i32
  %l112 = alloca i1
  %l115 = alloca { i64, ptr }
  %l120 = alloca { i64, ptr }
  %l122 = alloca { i64, ptr }
  %l128 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %t258 = alloca { i64, [2 x i64] }, align 8
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call { i32, ptr } @std_2fjson_2eParse(ptr %v0, ptr %s0, ptr %s0, { i64, ptr } %a0, ptr null)
  %t4 = extractvalue { i32, ptr } %t3, 1
  %t5 = extractvalue { i32, ptr } %t3, 0
  store i32 %t5, ptr %l13
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store ptr %t4, ptr %l12
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l12, !tbaa !29
  store ptr %t8, ptr %l10, !tbaa !29
  br label %bb6
bb2:
  %t9 = load i32, ptr %l13, !tbaa !23
  %t10 = ashr i32 %t9, 16
  %t12 = icmp eq i32 %t10, 1
  store i1 %t12, ptr %l15, !tbaa !21
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s1
  %t13 = call { i64, ptr } @compiler_2fmcp_2eerrorReply(ptr %s1, ptr %s1, ptr %s1, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d45, i32 0, i32 1) }, i64 -32700, { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d46, i32 0, i32 1) })
  store { i64, ptr } %t13, ptr %l16
  br label %bb4
bb4:
  %t14 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t14, 0
  %t16 = extractvalue { i64, ptr } %t14, 1
  %t17 = mul i64 %t15, 1
  %t18 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t17)
  call void @llvm.memcpy.p0.p0.i64(ptr %t18, ptr %t16, i64 %t17, i1 false)
  %t19 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  call void @compiler_2fmcp_2esend(ptr %s1, { i64, ptr } %t20)
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb6:
  %t22 = load ptr, ptr %l10, !tbaa !29
  store ptr %t22, ptr %l3, !tbaa !29
  %t23 = load ptr, ptr %l3, !tbaa !29
  %t25 = call { i64, ptr } @compiler_2fmcp_2estr(ptr %s0, ptr %s0, ptr %s0, ptr %t23, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d47, i32 0, i32 1) })
  store { i64, ptr } %t25, ptr %l19
  br label %bb7
bb7:
  %t26 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t26, ptr %l4, !tbaa !27
  %t27 = load ptr, ptr %l3, !tbaa !29
  %t29 = call { i64, ptr } @compiler_2fmcp_2eidOf(ptr %s0, ptr %s0, ptr %t27)
  store { i64, ptr } %t29, ptr %l21
  br label %bb8
bb8:
  %t30 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t30, ptr %l5, !tbaa !27
  %t31 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t33 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t31, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d48, i32 0, i32 1) })
  store i1 %t33, ptr %l23
  br label %bb9
bb9:
  %t34 = load i1, ptr %l23, !tbaa !21
  br i1 %t34, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  %t35 = load ptr, ptr %l3, !tbaa !29
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d49, i32 0, i32 1) }, ptr %l27, !tbaa !27
  %t37 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t40 = call { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAt_3cstd_2fprelude_2ftext_3aString_3e(ptr %s0, ptr %s0, ptr %t35, { i64, ptr } %t37)
  %t41 = extractvalue { i32, ptr } %t40, 1
  %t42 = extractvalue { i32, ptr } %t40, 0
  store i32 %t42, ptr %l30
  %t43 = icmp ne i32 %t42, 0
  br i1 %t43, label %bb13, label %ok.44, !prof !99
ok.44:
  store ptr %t41, ptr %l29
  br label %bb12
bb11:
  br label %bb29
bb12:
  %t45 = load ptr, ptr %l29, !tbaa !29
  store { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d50, i32 0, i32 1) }, ptr %l34, !tbaa !27
  %t46 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t49 = call { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAt_3cstd_2fprelude_2ftext_3aString_3e(ptr %s0, ptr %s2, ptr %t45, { i64, ptr } %t46)
  %t50 = extractvalue { i32, ptr } %t49, 1
  %t51 = extractvalue { i32, ptr } %t49, 0
  store i32 %t51, ptr %l37
  %t52 = icmp ne i32 %t51, 0
  br i1 %t52, label %bb16, label %ok.53, !prof !99
ok.53:
  store ptr %t50, ptr %l36
  br label %bb15
bb13:
  %t54 = load i32, ptr %l30, !tbaa !23
  %t55 = ashr i32 %t54, 16
  %t57 = icmp eq i32 %t55, 1
  store i1 %t57, ptr %l32, !tbaa !21
  br label %bb14
bb14:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d51, i32 0, i32 1) }, ptr %l24, !tbaa !27
  br label %bb19
bb15:
  %t58 = load ptr, ptr %l36, !tbaa !29
  %t59 = call { i32, { i64, ptr } } @std_2fjson_2estd_2fjson_3aJson_2eAsStr(ptr %s2, ptr %s2, ptr %t58)
  %t60 = extractvalue { i32, { i64, ptr } } %t59, 1
  %t61 = extractvalue { i32, { i64, ptr } } %t59, 0
  store i32 %t61, ptr %l41
  %t62 = icmp ne i32 %t61, 0
  br i1 %t62, label %bb18, label %ok.63, !prof !99
ok.63:
  store { i64, ptr } %t60, ptr %l40
  br label %bb17
bb16:
  %t64 = load i32, ptr %l37, !tbaa !23
  %t65 = ashr i32 %t64, 16
  %t67 = icmp eq i32 %t65, 1
  store i1 %t67, ptr %l39, !tbaa !21
  br label %bb14
bb17:
  %t68 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t68, ptr %l24, !tbaa !27
  br label %bb19
bb18:
  %t69 = load i32, ptr %l41, !tbaa !23
  %t70 = ashr i32 %t69, 16
  %t72 = icmp eq i32 %t70, 1
  store i1 %t72, ptr %l43, !tbaa !21
  br label %bb14
bb19:
  %t73 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t73, ptr %l6, !tbaa !27
  %t74 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s2)
  store %"std/prelude/text:StringBuilder" %t74, ptr %l44
  br label %bb20
bb20:
  %t75 = load %"std/prelude/text:StringBuilder", ptr %l44
  store %"std/prelude/text:StringBuilder" %t75, ptr %l7
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s2, ptr %s2, ptr %l7, { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d52, i32 0, i32 1) })
  br label %bb21
bb21:
  %t77 = load { i64, ptr }, ptr %l6, !tbaa !27
  call void @compiler_2fsession_2eJsonStr(ptr %s2, ptr %s2, ptr %l7, { i64, ptr } %t77)
  br label %bb22
bb22:
  %t80 = extractvalue { i64, ptr } { i64 92, ptr getelementptr inbounds (<{ i64, [92 x i8] }>, ptr @.d53, i32 0, i32 1) }, 1
  %t81 = extractvalue { i64, ptr } { i64 92, ptr getelementptr inbounds (<{ i64, [92 x i8] }>, ptr @.d53, i32 0, i32 1) }, 0
  %t82 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d54, i32 0, i32 1) }, 1
  %t83 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d54, i32 0, i32 1) }, 0
  %t84 = add i64 %t81, %t83
  %t85 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t84)
  call void @olang_textcopy(ptr %t85, ptr %t80, i64 %t81)
  %t86 = getelementptr i8, ptr %t85, i64 %t81
  call void @olang_textcopy(ptr %t86, ptr %t82, i64 %t83)
  %t87 = insertvalue { i64, ptr } undef, i64 %t84, 0
  %t88 = insertvalue { i64, ptr } %t87, ptr %t85, 1
  %t90 = extractvalue { i64, ptr } %t88, 0
  %t91 = extractvalue { i64, ptr } %t88, 1
  %t92 = mul i64 %t90, 1
  %t93 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t92)
  call void @llvm.memcpy.p0.p0.i64(ptr %t93, ptr %t91, i64 %t92, i1 false)
  %t94 = insertvalue { i64, ptr } undef, i64 %t90, 0
  %t95 = insertvalue { i64, ptr } %t94, ptr %t93, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s2, ptr %s2, ptr %l7, { i64, ptr } %t95)
  br label %bb23
bb23:
  %t98 = extractvalue { i64, ptr } { i64 87, ptr getelementptr inbounds (<{ i64, [87 x i8] }>, ptr @.d55, i32 0, i32 1) }, 1
  %t99 = extractvalue { i64, ptr } { i64 87, ptr getelementptr inbounds (<{ i64, [87 x i8] }>, ptr @.d55, i32 0, i32 1) }, 0
  %t100 = extractvalue { i64, ptr } { i64 91, ptr getelementptr inbounds (<{ i64, [91 x i8] }>, ptr @.d56, i32 0, i32 1) }, 1
  %t101 = extractvalue { i64, ptr } { i64 91, ptr getelementptr inbounds (<{ i64, [91 x i8] }>, ptr @.d56, i32 0, i32 1) }, 0
  %t102 = add i64 %t99, %t101
  %t103 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d57, i32 0, i32 1) }, 1
  %t104 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d57, i32 0, i32 1) }, 0
  %t105 = add i64 %t102, %t104
  %t106 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t105)
  call void @olang_textcopy(ptr %t106, ptr %t98, i64 %t99)
  %t107 = getelementptr i8, ptr %t106, i64 %t99
  call void @olang_textcopy(ptr %t107, ptr %t100, i64 %t101)
  %t108 = getelementptr i8, ptr %t107, i64 %t101
  call void @olang_textcopy(ptr %t108, ptr %t103, i64 %t104)
  %t109 = insertvalue { i64, ptr } undef, i64 %t105, 0
  %t110 = insertvalue { i64, ptr } %t109, ptr %t106, 1
  %t112 = extractvalue { i64, ptr } %t110, 0
  %t113 = extractvalue { i64, ptr } %t110, 1
  %t114 = mul i64 %t112, 1
  %t115 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t114)
  call void @llvm.memcpy.p0.p0.i64(ptr %t115, ptr %t113, i64 %t114, i1 false)
  %t116 = insertvalue { i64, ptr } undef, i64 %t112, 0
  %t117 = insertvalue { i64, ptr } %t116, ptr %t115, 1
  call void @compiler_2fsession_2eJsonStr(ptr %s2, ptr %s2, ptr %l7, { i64, ptr } %t117)
  br label %bb24
bb24:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s2, ptr %l7, i8 125)
  br label %bb25
bb25:
  %t121 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t121, ptr %l55, !tbaa !27
  %t123 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s2, ptr %s2, ptr %l7)
  store { i64, ptr } %t123, ptr %l57
  br label %bb26
bb26:
  %t124 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t125 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t126 = call { i64, ptr } @compiler_2fmcp_2ereply(ptr %s0, ptr %s2, ptr %s2, { i64, ptr } %t124, { i64, ptr } %t125)
  store { i64, ptr } %t126, ptr %l58
  br label %bb27
bb27:
  %t127 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t128 = extractvalue { i64, ptr } %t127, 0
  %t129 = extractvalue { i64, ptr } %t127, 1
  %t130 = mul i64 %t128, 1
  %t131 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t130)
  call void @llvm.memcpy.p0.p0.i64(ptr %t131, ptr %t129, i64 %t130, i1 false)
  %t132 = insertvalue { i64, ptr } undef, i64 %t128, 0
  %t133 = insertvalue { i64, ptr } %t132, ptr %t131, 1
  call void @compiler_2fmcp_2esend(ptr %s2, { i64, ptr } %t133)
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb29:
  %t135 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t137 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t135, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d58, i32 0, i32 1) })
  store i1 %t137, ptr %l61
  br label %bb30
bb30:
  %t138 = load i1, ptr %l61, !tbaa !21
  br i1 %t138, label %bb31, label %bb32
bb31:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb32:
  br label %bb33
bb33:
  %t139 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t141 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t139, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d59, i32 0, i32 1) })
  store i1 %t141, ptr %l63
  br label %bb34
bb34:
  %t142 = load i1, ptr %l63, !tbaa !21
  br i1 %t142, label %bb35, label %bb36
bb35:
  store %olang.scope zeroinitializer, ptr %s6
  %t143 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t145 = call { i64, ptr } @compiler_2fmcp_2ereply(ptr %s0, ptr %s6, ptr %s6, { i64, ptr } %t143, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d60, i32 0, i32 1) })
  store { i64, ptr } %t145, ptr %l65
  br label %bb37
bb36:
  br label %bb39
bb37:
  %t146 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t147 = extractvalue { i64, ptr } %t146, 0
  %t148 = extractvalue { i64, ptr } %t146, 1
  %t149 = mul i64 %t147, 1
  %t150 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t149)
  call void @llvm.memcpy.p0.p0.i64(ptr %t150, ptr %t148, i64 %t149, i1 false)
  %t151 = insertvalue { i64, ptr } undef, i64 %t147, 0
  %t152 = insertvalue { i64, ptr } %t151, ptr %t150, 1
  call void @compiler_2fmcp_2esend(ptr %s6, { i64, ptr } %t152)
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb39:
  %t154 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t156 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t154, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d61, i32 0, i32 1) })
  store i1 %t156, ptr %l68
  br label %bb40
bb40:
  %t157 = load i1, ptr %l68, !tbaa !21
  br i1 %t157, label %bb41, label %bb42
bb41:
  store %olang.scope zeroinitializer, ptr %s7
  %t158 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t159 = load { i64, ptr }, ptr @G_2ecompiler_2fmcp_2eTools, !tbaa !27
  %t160 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d62, i32 0, i32 1) }, 1
  %t161 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d62, i32 0, i32 1) }, 0
  %t163 = extractvalue { i64, ptr } %t159, 1
  %t164 = extractvalue { i64, ptr } %t159, 0
  %t165 = add i64 %t161, %t164
  %t166 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d63, i32 0, i32 1) }, 1
  %t167 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d63, i32 0, i32 1) }, 0
  %t168 = add i64 %t165, %t167
  %t169 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t168)
  call void @olang_textcopy(ptr %t169, ptr %t160, i64 %t161)
  %t170 = getelementptr i8, ptr %t169, i64 %t161
  call void @olang_textcopy(ptr %t170, ptr %t163, i64 %t164)
  %t171 = getelementptr i8, ptr %t170, i64 %t164
  call void @olang_textcopy(ptr %t171, ptr %t166, i64 %t167)
  %t172 = insertvalue { i64, ptr } undef, i64 %t168, 0
  %t173 = insertvalue { i64, ptr } %t172, ptr %t169, 1
  %t175 = extractvalue { i64, ptr } %t173, 0
  %t176 = extractvalue { i64, ptr } %t173, 1
  %t177 = mul i64 %t175, 1
  %t178 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t177)
  call void @llvm.memcpy.p0.p0.i64(ptr %t178, ptr %t176, i64 %t177, i1 false)
  %t179 = insertvalue { i64, ptr } undef, i64 %t175, 0
  %t180 = insertvalue { i64, ptr } %t179, ptr %t178, 1
  %t183 = call { i64, ptr } @compiler_2fmcp_2ereply(ptr %s0, ptr %s7, ptr %s7, { i64, ptr } %t158, { i64, ptr } %t180)
  store { i64, ptr } %t183, ptr %l73
  br label %bb43
bb42:
  br label %bb45
bb43:
  %t184 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t185 = extractvalue { i64, ptr } %t184, 0
  %t186 = extractvalue { i64, ptr } %t184, 1
  %t187 = mul i64 %t185, 1
  %t188 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t187)
  call void @llvm.memcpy.p0.p0.i64(ptr %t188, ptr %t186, i64 %t187, i1 false)
  %t189 = insertvalue { i64, ptr } undef, i64 %t185, 0
  %t190 = insertvalue { i64, ptr } %t189, ptr %t188, 1
  call void @compiler_2fmcp_2esend(ptr %s7, { i64, ptr } %t190)
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb45:
  %t192 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t194 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t192, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d64, i32 0, i32 1) })
  store i1 %t194, ptr %l76
  br label %bb46
bb46:
  %t195 = load i1, ptr %l76, !tbaa !21
  br i1 %t195, label %bb47, label %bb48
bb47:
  store %olang.scope zeroinitializer, ptr %s9
  %t196 = load ptr, ptr %l3, !tbaa !29
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d65, i32 0, i32 1) }, ptr %l80, !tbaa !27
  %t198 = load { i64, ptr }, ptr %l80, !tbaa !27
  %t201 = call { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAt_3cstd_2fprelude_2ftext_3aString_3e(ptr %s0, ptr %s0, ptr %t196, { i64, ptr } %t198)
  %t202 = extractvalue { i32, ptr } %t201, 1
  %t203 = extractvalue { i32, ptr } %t201, 0
  store i32 %t203, ptr %l83
  %t204 = icmp ne i32 %t203, 0
  br i1 %t204, label %bb50, label %ok.205, !prof !99
ok.205:
  store ptr %t202, ptr %l82
  br label %bb49
bb48:
  br label %bb66
bb49:
  %t206 = load ptr, ptr %l82, !tbaa !29
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d66, i32 0, i32 1) }, ptr %l87, !tbaa !27
  %t207 = load { i64, ptr }, ptr %l87, !tbaa !27
  %t210 = call { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAt_3cstd_2fprelude_2ftext_3aString_3e(ptr %s0, ptr %s9, ptr %t206, { i64, ptr } %t207)
  %t211 = extractvalue { i32, ptr } %t210, 1
  %t212 = extractvalue { i32, ptr } %t210, 0
  store i32 %t212, ptr %l90
  %t213 = icmp ne i32 %t212, 0
  br i1 %t213, label %bb53, label %ok.214, !prof !99
ok.214:
  store ptr %t211, ptr %l89
  br label %bb52
bb50:
  %t215 = load i32, ptr %l83, !tbaa !23
  %t216 = ashr i32 %t215, 16
  %t218 = icmp eq i32 %t216, 1
  store i1 %t218, ptr %l85, !tbaa !21
  br label %bb51
bb51:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d67, i32 0, i32 1) }, ptr %l77, !tbaa !27
  br label %bb56
bb52:
  %t219 = load ptr, ptr %l89, !tbaa !29
  %t220 = call { i32, { i64, ptr } } @std_2fjson_2estd_2fjson_3aJson_2eAsStr(ptr %s9, ptr %s9, ptr %t219)
  %t221 = extractvalue { i32, { i64, ptr } } %t220, 1
  %t222 = extractvalue { i32, { i64, ptr } } %t220, 0
  store i32 %t222, ptr %l94
  %t223 = icmp ne i32 %t222, 0
  br i1 %t223, label %bb55, label %ok.224, !prof !99
ok.224:
  store { i64, ptr } %t221, ptr %l93
  br label %bb54
bb53:
  %t225 = load i32, ptr %l90, !tbaa !23
  %t226 = ashr i32 %t225, 16
  %t228 = icmp eq i32 %t226, 1
  store i1 %t228, ptr %l92, !tbaa !21
  br label %bb51
bb54:
  %t229 = load { i64, ptr }, ptr %l93, !tbaa !27
  store { i64, ptr } %t229, ptr %l77, !tbaa !27
  br label %bb56
bb55:
  %t230 = load i32, ptr %l94, !tbaa !23
  %t231 = ashr i32 %t230, 16
  %t233 = icmp eq i32 %t231, 1
  store i1 %t233, ptr %l96, !tbaa !21
  br label %bb51
bb56:
  %t234 = load { i64, ptr }, ptr %l77, !tbaa !27
  store { i64, ptr } %t234, ptr %l8, !tbaa !27
  %t235 = load ptr, ptr %l3, !tbaa !29
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d68, i32 0, i32 1) }, ptr %l100, !tbaa !27
  %t237 = load { i64, ptr }, ptr %l100, !tbaa !27
  %t240 = call { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAt_3cstd_2fprelude_2ftext_3aString_3e(ptr %s0, ptr %s0, ptr %t235, { i64, ptr } %t237)
  %t241 = extractvalue { i32, ptr } %t240, 1
  %t242 = extractvalue { i32, ptr } %t240, 0
  store i32 %t242, ptr %l103
  %t243 = icmp ne i32 %t242, 0
  br i1 %t243, label %bb58, label %ok.244, !prof !99
ok.244:
  store ptr %t241, ptr %l102
  br label %bb57
bb57:
  %t245 = load ptr, ptr %l102, !tbaa !29
  store { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d69, i32 0, i32 1) }, ptr %l107, !tbaa !27
  %t246 = load { i64, ptr }, ptr %l107, !tbaa !27
  %t249 = call { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAt_3cstd_2fprelude_2ftext_3aString_3e(ptr %s0, ptr %s0, ptr %t245, { i64, ptr } %t246)
  %t250 = extractvalue { i32, ptr } %t249, 1
  %t251 = extractvalue { i32, ptr } %t249, 0
  store i32 %t251, ptr %l110
  %t252 = icmp ne i32 %t251, 0
  br i1 %t252, label %bb61, label %ok.253, !prof !99
ok.253:
  store ptr %t250, ptr %l109
  br label %bb60
bb58:
  %t254 = load i32, ptr %l103, !tbaa !23
  %t255 = ashr i32 %t254, 16
  %t257 = icmp eq i32 %t255, 1
  store i1 %t257, ptr %l105, !tbaa !21
  br label %bb59
bb59:
  call void @__olang_ert_req_clear()
  store { i64, [2 x i64] } zeroinitializer, ptr %t258
  %t259 = getelementptr { i64, [2 x i64] }, ptr %t258, i32 0, i32 0
  store i64 0, ptr %t259
  %t260 = load { i64, [2 x i64] }, ptr %t258
  %t262 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 24, i64 8)
  store { i64, [2 x i64] } %t260, ptr %t262
  store ptr %t262, ptr %l97, !tbaa !29
  br label %bb62
bb60:
  %t264 = load ptr, ptr %l109, !tbaa !29
  store ptr %t264, ptr %l97, !tbaa !29
  br label %bb62
bb61:
  %t265 = load i32, ptr %l110, !tbaa !23
  %t266 = ashr i32 %t265, 16
  %t268 = icmp eq i32 %t266, 1
  store i1 %t268, ptr %l112, !tbaa !21
  br label %bb59
bb62:
  %t269 = load ptr, ptr %l97, !tbaa !29
  %t270 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t270, ptr %l115, !tbaa !27
  %t271 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t279 = call { i64, ptr } @compiler_2fmcp_2ecall(ptr %s9, ptr %s0, ptr %v1, ptr %v2, ptr %s9, { i64, ptr } %t271, ptr %t269, ptr %a1, { i64, ptr } %a2)
  store { i64, ptr } %t279, ptr %l120
  br label %bb63
bb63:
  %t280 = load { i64, ptr }, ptr %l120, !tbaa !27
  %t281 = extractvalue { i64, ptr } %t280, 0
  %t282 = extractvalue { i64, ptr } %t280, 1
  %t283 = mul i64 %t281, 1
  %t284 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t283)
  call void @llvm.memcpy.p0.p0.i64(ptr %t284, ptr %t282, i64 %t283, i1 false)
  %t285 = insertvalue { i64, ptr } undef, i64 %t281, 0
  %t286 = insertvalue { i64, ptr } %t285, ptr %t284, 1
  %t287 = load { i64, ptr }, ptr %l115, !tbaa !27
  %t289 = call { i64, ptr } @compiler_2fmcp_2ereply(ptr %s0, ptr %s9, ptr %s9, { i64, ptr } %t287, { i64, ptr } %t286)
  store { i64, ptr } %t289, ptr %l122
  br label %bb64
bb64:
  %t290 = load { i64, ptr }, ptr %l122, !tbaa !27
  %t291 = extractvalue { i64, ptr } %t290, 0
  %t292 = extractvalue { i64, ptr } %t290, 1
  %t293 = mul i64 %t291, 1
  %t294 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t293)
  call void @llvm.memcpy.p0.p0.i64(ptr %t294, ptr %t292, i64 %t293, i1 false)
  %t295 = insertvalue { i64, ptr } undef, i64 %t291, 0
  %t296 = insertvalue { i64, ptr } %t295, ptr %t294, 1
  call void @compiler_2fmcp_2esend(ptr %s9, { i64, ptr } %t296)
  br label %bb65
bb65:
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb66:
  %t298 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t299 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t300 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d70, i32 0, i32 1) }, 1
  %t301 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d70, i32 0, i32 1) }, 0
  %t303 = extractvalue { i64, ptr } %t299, 1
  %t304 = extractvalue { i64, ptr } %t299, 0
  %t305 = add i64 %t301, %t304
  %t306 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t305)
  call void @olang_textcopy(ptr %t306, ptr %t300, i64 %t301)
  %t307 = getelementptr i8, ptr %t306, i64 %t301
  call void @olang_textcopy(ptr %t307, ptr %t303, i64 %t304)
  %t308 = insertvalue { i64, ptr } undef, i64 %t305, 0
  %t309 = insertvalue { i64, ptr } %t308, ptr %t306, 1
  %t311 = extractvalue { i64, ptr } %t309, 0
  %t312 = extractvalue { i64, ptr } %t309, 1
  %t313 = mul i64 %t311, 1
  %t314 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t313)
  call void @llvm.memcpy.p0.p0.i64(ptr %t314, ptr %t312, i64 %t313, i1 false)
  %t315 = insertvalue { i64, ptr } undef, i64 %t311, 0
  %t316 = insertvalue { i64, ptr } %t315, ptr %t314, 1
  %t319 = call { i64, ptr } @compiler_2fmcp_2eerrorReply(ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t298, i64 -32601, { i64, ptr } %t316)
  store { i64, ptr } %t319, ptr %l128
  br label %bb67
bb67:
  %t320 = load { i64, ptr }, ptr %l128, !tbaa !27
  %t321 = extractvalue { i64, ptr } %t320, 0
  %t322 = extractvalue { i64, ptr } %t320, 1
  %t323 = mul i64 %t321, 1
  %t324 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t323)
  call void @llvm.memcpy.p0.p0.i64(ptr %t324, ptr %t322, i64 %t323, i1 false)
  %t325 = insertvalue { i64, ptr } undef, i64 %t321, 0
  %t326 = insertvalue { i64, ptr } %t325, ptr %t324, 1
  call void @compiler_2fmcp_2esend(ptr %s0, { i64, ptr } %t326)
  br label %bb68
bb68:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fmcp_2eidOf(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l2 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l6 = alloca ptr
  %l7 = alloca i32
  %l9 = alloca i1
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d71, i32 0, i32 1) }, ptr %l4, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t5 = call { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAt_3cstd_2fprelude_2ftext_3aString_3e(ptr %v0, ptr %v0, ptr %a0, { i64, ptr } %t2)
  %t6 = extractvalue { i32, ptr } %t5, 1
  %t7 = extractvalue { i32, ptr } %t5, 0
  store i32 %t7, ptr %l7
  %t8 = icmp ne i32 %t7, 0
  br i1 %t8, label %bb2, label %ok.9, !prof !99
ok.9:
  store ptr %t6, ptr %l6
  br label %bb1
bb1:
  %t10 = load ptr, ptr %l6, !tbaa !29
  store ptr %t10, ptr %l2, !tbaa !29
  br label %bb4
bb2:
  %t11 = load i32, ptr %l7, !tbaa !23
  %t12 = ashr i32 %t11, 16
  %t14 = icmp eq i32 %t12, 1
  store i1 %t14, ptr %l9, !tbaa !21
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d72, i32 0, i32 1) }, ptr %l10, !tbaa !27
  %t15 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t15, ptr %l11, !tbaa !27
  %t16 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t16, 0
  store i64 %t17, ptr %l12, !tbaa !24
  %t18 = load i64, ptr %l12, !tbaa !24
  %t19 = mul i64 %t18, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  %t21 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  store { i64, ptr } %t22, ptr %l13, !tbaa !27
  %t23 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = load i64, ptr %l12, !tbaa !24
  %t28 = mul i64 %t27, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t24, ptr %t26, i64 %t28, i1 false)
  %t29 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t29, ptr %l11, !tbaa !27
  %t30 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t30, ptr %rv
  br label %ret
bb4:
  %t31 = load ptr, ptr %l2, !tbaa !29
  %t35 = call { i64, ptr } @std_2fjson_2eEncode_3cstd_2fjson_3aJson_26_3e(ptr %v0, ptr %v1, ptr %v1, ptr %t31, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d73, i32 0, i32 1) }, i32 0)
  store { i64, ptr } %t35, ptr %l16
  br label %bb5
bb5:
  %t36 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t36, ptr %l17, !tbaa !27
  %t37 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t37, 0
  store i64 %t38, ptr %l18, !tbaa !24
  %t39 = load i64, ptr %l18, !tbaa !24
  %t40 = mul i64 %t39, 1
  %t41 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t40)
  %t42 = insertvalue { i64, ptr } undef, i64 %t39, 0
  %t43 = insertvalue { i64, ptr } %t42, ptr %t41, 1
  store { i64, ptr } %t43, ptr %l19, !tbaa !27
  %t44 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = load i64, ptr %l18, !tbaa !24
  %t49 = mul i64 %t48, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t45, ptr %t47, i64 %t49, i1 false)
  %t50 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t50, ptr %l17, !tbaa !27
  %t51 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t51, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fmcp_2elocated(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca %"compiler/session:Positions"
  %l5 = alloca { i64, i64 }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca { i64, i64 }
  %l12 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l29 = alloca %"compiler/session:Positions"
  %l33 = alloca { i64, i64 }
  %l36 = alloca ptr
  %l42 = alloca i64
  %l47 = alloca { i64, i64 }
  %l71 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s0, ptr %t1, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d74, i32 0, i32 1) })
  br label %bb1
bb1:
  %t3 = load ptr, ptr %l0, !tbaa !29
  store ptr %t3, ptr %l12, !tbaa !29
  %t4 = load ptr, ptr %l3, !tbaa !29
  %t6 = getelementptr %"compiler/diag:Item", ptr %t4, i32 0, i32 2
  %t7 = load i64, ptr %t6, !tbaa !24
  %t9 = icmp sge i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l2, !tbaa !29
  %t12 = load ptr, ptr %l3, !tbaa !29
  %t14 = getelementptr %"compiler/diag:Item", ptr %t12, i32 0, i32 2
  %t15 = load i64, ptr %t14, !tbaa !24
  %t18 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2ePathOf(ptr %v2, ptr %s0, ptr %t11, i64 %t15)
  store { i64, ptr } %t18, ptr %l20
  br label %bb4
bb3:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d75, i32 0, i32 1) }, ptr %l16, !tbaa !27
  br label %bb5
bb4:
  %t19 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t19, 0
  %t21 = extractvalue { i64, ptr } %t19, 1
  %t22 = mul i64 %t20, 1
  %t23 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t22)
  call void @llvm.memcpy.p0.p0.i64(ptr %t23, ptr %t21, i64 %t22, i1 false)
  %t24 = insertvalue { i64, ptr } undef, i64 %t20, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t23, 1
  store { i64, ptr } %t25, ptr %l16, !tbaa !27
  br label %bb5
bb5:
  %t27 = load ptr, ptr %l12, !tbaa !29
  %t28 = load { i64, ptr }, ptr %l16, !tbaa !27
  call void @compiler_2fsession_2eJsonStr(ptr %v0, ptr %s0, ptr %t27, { i64, ptr } %t28)
  br label %bb6
bb6:
  %t29 = load ptr, ptr %l3, !tbaa !29
  %t31 = getelementptr %"compiler/diag:Item", ptr %t29, i32 0, i32 3
  %t32 = load i64, ptr %t31, !tbaa !24
  %t34 = icmp sge i64 %t32, 0
  br i1 %t34, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s1
  %t36 = load ptr, ptr %l2, !tbaa !29
  %t37 = load ptr, ptr %l3, !tbaa !29
  %t39 = getelementptr %"compiler/diag:Item", ptr %t37, i32 0, i32 2
  %t40 = load i64, ptr %t39, !tbaa !24
  %t43 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eTextOf(ptr %v2, ptr %v2, ptr %t36, i64 %t40)
  store { i64, ptr } %t43, ptr %l28
  br label %bb9
bb8:
  %t44 = load ptr, ptr %l3, !tbaa !29
  %t46 = getelementptr %"compiler/diag:Item", ptr %t44, i32 0, i32 5
  %t47 = load i64, ptr %t46, !tbaa !24
  %t49 = icmp sgt i64 %t47, 0
  br i1 %t49, label %bb17, label %bb18
bb9:
  %t51 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t52 = call %"compiler/session:Positions" @compiler_2fsession_3aPositions_2ector(ptr %v2, ptr %s1, { i64, ptr } %t51, i1 true)
  store %"compiler/session:Positions" %t52, ptr %l29
  br label %bb10
bb10:
  %t53 = load %"compiler/session:Positions", ptr %l29
  store %"compiler/session:Positions" %t53, ptr %l4
  %t54 = load ptr, ptr %l3, !tbaa !29
  %t56 = getelementptr %"compiler/diag:Item", ptr %t54, i32 0, i32 3
  %t57 = load i64, ptr %t56, !tbaa !24
  %t60 = call { i64, i64 } @compiler_2fsession_2ecompiler_2fsession_3aPositions_2ePos(ptr %s1, ptr %l4, i64 %t57)
  store { i64, i64 } %t60, ptr %l33
  br label %bb11
bb11:
  %t61 = load { i64, i64 }, ptr %l33
  store { i64, i64 } %t61, ptr %l5
  %t62 = getelementptr { i64, i64 }, ptr %l5, i32 0, i32 0
  %t63 = load i64, ptr %t62, !tbaa !24
  store i64 %t63, ptr %l6, !tbaa !24
  %t65 = getelementptr { i64, i64 }, ptr %l5, i32 0, i32 1
  %t66 = load i64, ptr %t65, !tbaa !24
  store i64 %t66, ptr %l7, !tbaa !24
  store ptr %l4, ptr %l36, !tbaa !29
  %t68 = load ptr, ptr %l3, !tbaa !29
  %t70 = getelementptr %"compiler/diag:Item", ptr %t68, i32 0, i32 4
  %t71 = load i64, ptr %t70, !tbaa !24
  %t72 = load ptr, ptr %l3, !tbaa !29
  %t74 = getelementptr %"compiler/diag:Item", ptr %t72, i32 0, i32 3
  %t75 = load i64, ptr %t74, !tbaa !24
  %t78 = icmp sgt i64 %t71, %t75
  br i1 %t78, label %bb12, label %bb13
bb12:
  %t80 = load ptr, ptr %l3, !tbaa !29
  %t82 = getelementptr %"compiler/diag:Item", ptr %t80, i32 0, i32 4
  %t83 = load i64, ptr %t82, !tbaa !24
  store i64 %t83, ptr %l42, !tbaa !24
  br label %bb14
bb13:
  %t85 = load ptr, ptr %l3, !tbaa !29
  %t87 = getelementptr %"compiler/diag:Item", ptr %t85, i32 0, i32 3
  %t88 = load i64, ptr %t87, !tbaa !24
  store i64 %t88, ptr %l42, !tbaa !24
  br label %bb14
bb14:
  %t90 = load ptr, ptr %l36, !tbaa !29
  %t91 = load i64, ptr %l42, !tbaa !24
  %t92 = call { i64, i64 } @compiler_2fsession_2ecompiler_2fsession_3aPositions_2ePos(ptr %s1, ptr %t90, i64 %t91)
  store { i64, i64 } %t92, ptr %l47
  br label %bb15
bb15:
  %t93 = load { i64, i64 }, ptr %l47
  store { i64, i64 } %t93, ptr %l8
  %t94 = getelementptr { i64, i64 }, ptr %l8, i32 0, i32 0
  %t95 = load i64, ptr %t94, !tbaa !24
  %t97 = getelementptr { i64, i64 }, ptr %l8, i32 0, i32 1
  %t98 = load i64, ptr %t97, !tbaa !24
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t101 = load i64, ptr %l6, !tbaa !24
  %t103 = add i64 %t101, 1
  %t104 = load i64, ptr %l7, !tbaa !24
  %t106 = add i64 %t104, 1
  %t109 = add i64 %t95, 1
  %t112 = add i64 %t98, 1
  %t113 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d76, i32 0, i32 1) }, 1
  %t114 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d76, i32 0, i32 1) }, 0
  %t116 = call i64 @__olang_fmt_i64(ptr null, i64 %t103)
  %t117 = add i64 %t114, %t116
  %t118 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d77, i32 0, i32 1) }, 1
  %t119 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d77, i32 0, i32 1) }, 0
  %t120 = add i64 %t117, %t119
  %t122 = call i64 @__olang_fmt_i64(ptr null, i64 %t106)
  %t123 = add i64 %t120, %t122
  %t124 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d78, i32 0, i32 1) }, 1
  %t125 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d78, i32 0, i32 1) }, 0
  %t126 = add i64 %t123, %t125
  %t128 = call i64 @__olang_fmt_i64(ptr null, i64 %t109)
  %t129 = add i64 %t126, %t128
  %t130 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d79, i32 0, i32 1) }, 1
  %t131 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d79, i32 0, i32 1) }, 0
  %t132 = add i64 %t129, %t131
  %t134 = call i64 @__olang_fmt_i64(ptr null, i64 %t112)
  %t135 = add i64 %t132, %t134
  %t136 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t135)
  call void @olang_textcopy(ptr %t136, ptr %t113, i64 %t114)
  %t137 = getelementptr i8, ptr %t136, i64 %t114
  %t138 = call i64 @__olang_fmt_i64(ptr %t137, i64 %t103)
  %t139 = getelementptr i8, ptr %t137, i64 %t116
  call void @olang_textcopy(ptr %t139, ptr %t118, i64 %t119)
  %t140 = getelementptr i8, ptr %t139, i64 %t119
  %t141 = call i64 @__olang_fmt_i64(ptr %t140, i64 %t106)
  %t142 = getelementptr i8, ptr %t140, i64 %t122
  call void @olang_textcopy(ptr %t142, ptr %t124, i64 %t125)
  %t143 = getelementptr i8, ptr %t142, i64 %t125
  %t144 = call i64 @__olang_fmt_i64(ptr %t143, i64 %t109)
  %t145 = getelementptr i8, ptr %t143, i64 %t128
  call void @olang_textcopy(ptr %t145, ptr %t130, i64 %t131)
  %t146 = getelementptr i8, ptr %t145, i64 %t131
  %t147 = call i64 @__olang_fmt_i64(ptr %t146, i64 %t112)
  %t148 = insertvalue { i64, ptr } undef, i64 %t135, 0
  %t149 = insertvalue { i64, ptr } %t148, ptr %t136, 1
  %t151 = extractvalue { i64, ptr } %t149, 0
  %t152 = extractvalue { i64, ptr } %t149, 1
  %t153 = mul i64 %t151, 1
  %t154 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t153)
  call void @llvm.memcpy.p0.p0.i64(ptr %t154, ptr %t152, i64 %t153, i1 false)
  %t155 = insertvalue { i64, ptr } undef, i64 %t151, 0
  %t156 = insertvalue { i64, ptr } %t155, ptr %t154, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s1, ptr %t100, { i64, ptr } %t156)
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s1)
  br label %bb21
bb17:
  store %olang.scope zeroinitializer, ptr %s4
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t160 = load ptr, ptr %l3, !tbaa !29
  %t162 = getelementptr %"compiler/diag:Item", ptr %t160, i32 0, i32 5
  %t163 = load i64, ptr %t162, !tbaa !24
  %t164 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d80, i32 0, i32 1) }, 1
  %t165 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d80, i32 0, i32 1) }, 0
  %t167 = call i64 @__olang_fmt_i64(ptr null, i64 %t163)
  %t168 = add i64 %t165, %t167
  %t169 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t168)
  call void @olang_textcopy(ptr %t169, ptr %t164, i64 %t165)
  %t170 = getelementptr i8, ptr %t169, i64 %t165
  %t171 = call i64 @__olang_fmt_i64(ptr %t170, i64 %t163)
  %t172 = insertvalue { i64, ptr } undef, i64 %t168, 0
  %t173 = insertvalue { i64, ptr } %t172, ptr %t169, 1
  %t175 = extractvalue { i64, ptr } %t173, 0
  %t176 = extractvalue { i64, ptr } %t173, 1
  %t177 = mul i64 %t175, 1
  %t178 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t177)
  call void @llvm.memcpy.p0.p0.i64(ptr %t178, ptr %t176, i64 %t177, i1 false)
  %t179 = insertvalue { i64, ptr } undef, i64 %t175, 0
  %t180 = insertvalue { i64, ptr } %t179, ptr %t178, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s4, ptr %t159, { i64, ptr } %t180)
  br label %bb19
bb18:
  br label %bb20
bb19:
  call void @__olang_scope_close(ptr %s4)
  br label %bb20
bb20:
  br label %bb21
bb21:
  %t183 = load ptr, ptr %l3, !tbaa !29
  %t185 = getelementptr %"compiler/diag:Item", ptr %t183, i32 0, i32 1
  %t186 = load { i64, ptr }, ptr %t185, !tbaa !27
  %t188 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v3, ptr %s0, { i64, ptr } %t186, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d81, i32 0, i32 1) })
  store i1 %t188, ptr %l71
  br label %bb22
bb22:
  %t189 = load i1, ptr %l71, !tbaa !21
  %t190 = xor i1 %t189, true
  br i1 %t190, label %bb23, label %bb24
bb23:
  store %olang.scope zeroinitializer, ptr %s6
  %t192 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s6, ptr %t192, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d82, i32 0, i32 1) })
  br label %bb25
bb24:
  br label %bb27
bb25:
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t195 = load ptr, ptr %l3, !tbaa !29
  %t197 = getelementptr %"compiler/diag:Item", ptr %t195, i32 0, i32 1
  %t198 = load { i64, ptr }, ptr %t197, !tbaa !27
  call void @compiler_2fsession_2eJsonStr(ptr %v0, ptr %v3, ptr %t194, { i64, ptr } %t198)
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s6)
  br label %bb27
bb27:
  %t201 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s0, ptr %t201, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d83, i32 0, i32 1) })
  br label %bb28
bb28:
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t204 = load ptr, ptr %l3, !tbaa !29
  %t206 = getelementptr %"compiler/diag:Item", ptr %t204, i32 0, i32 6
  %t207 = load { i64, ptr }, ptr %t206, !tbaa !27
  call void @compiler_2fsession_2eJsonStr(ptr %v0, ptr %v3, ptr %t203, { i64, ptr } %t207)
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fmcp_2ereply(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d84, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d84, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d85, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d85, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d86, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d86, i32 0, i32 1) }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  store { i64, ptr } %t25, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fmcp_2erun(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, { i64, ptr } %a0, { i64, ptr } %a1, i1 %a2, { i64, ptr } %a3, { i64, ptr } %a4, ptr %a5) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i1
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l16 = alloca i1
  %l17 = alloca i1
  %l19 = alloca i1
  %l22 = alloca { i64, ptr }
  %l25 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l27 = alloca ptr
  %l29 = alloca { i64, ptr }
  %l35 = alloca i1
  %l37 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l42 = alloca i32
  %l44 = alloca i1
  %l48 = alloca { i64, ptr }
  %l49 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %l53 = alloca i32
  %l57 = alloca { i64, ptr }
  %l59 = alloca { i64, ptr }
  %l60 = alloca %"compiler/diag:Diagnostics"
  %l66 = alloca ptr
  %l68 = alloca i1
  %l71 = alloca { i64, ptr }
  %l73 = alloca i64
  %l75 = alloca i1
  %l79 = alloca i1
  %l84 = alloca { i64, ptr }
  %l86 = alloca { i64, ptr }
  %l89 = alloca { i64, ptr }
  %l91 = alloca i1
  %l92 = alloca { i64, ptr }
  %l97 = alloca ptr
  %l102 = alloca ptr
  %l112 = alloca { i64, ptr }
  %l113 = alloca i32
  %l115 = alloca i1
  %l120 = alloca { i64, ptr }
  %l122 = alloca { i64, ptr }
  %l124 = alloca i1
  %l126 = alloca { i64, ptr }
  %l131 = alloca ptr
  %l136 = alloca ptr
  %l146 = alloca { i64, ptr }
  %l147 = alloca i32
  %l149 = alloca i1
  %l154 = alloca { i64, ptr }
  %l156 = alloca { i64, ptr }
  %l161 = alloca ptr
  %l166 = alloca ptr
  %l175 = alloca %"compiler/doc:Module"
  %l177 = alloca { i64, ptr }
  %l179 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t141 = alloca %"compiler/diag:Diagnostics", align 8
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store i1 %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t1, ptr %l6, !tbaa !27
  %t3 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t5 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t3, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d87, i32 0, i32 1) })
  store i1 %t5, ptr %l16
  br label %bb1
bb1:
  %t6 = load i1, ptr %l16, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  %t7 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t9 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v1, ptr %s0, { i64, ptr } %t7, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d88, i32 0, i32 1) })
  store i1 %t9, ptr %l19
  br label %bb4
bb3:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb5
bb4:
  %t10 = load i1, ptr %l19, !tbaa !21
  %t11 = xor i1 %t10, true
  store i1 %t11, ptr %l17, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l17, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s1
  %t14 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t16 = call { i64, ptr } @compiler_2fsession_2eStdModule(ptr %v1, ptr %s1, { i64, ptr } %t14)
  store { i64, ptr } %t16, ptr %l22
  br label %bb8
bb7:
  br label %bb9
bb8:
  %t17 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t17, 1
  %t19 = extractvalue { i64, ptr } %t17, 0
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @olang_textcopy(ptr %t20, ptr %t18, i64 %t19)
  %t21 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t24 = extractvalue { i64, ptr } %t22, 0
  %t25 = extractvalue { i64, ptr } %t22, 1
  %t26 = mul i64 %t24, 1
  %t27 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t26)
  call void @llvm.memcpy.p0.p0.i64(ptr %t27, ptr %t25, i64 %t26, i1 false)
  %t28 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t27, 1
  store { i64, ptr } %t29, ptr %l6, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  br label %bb9
bb9:
  %t31 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t31, ptr %l25
  br label %bb10
bb10:
  %t32 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l25
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t32, ptr %l7
  %t33 = load i1, ptr %l2, !tbaa !21
  br i1 %t33, label %bb11, label %bb12
bb11:
  store ptr %l7, ptr %l27, !tbaa !29
  %t35 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t37 = call { i64, ptr } @compiler_2fsession_2eRealOf(ptr %v1, ptr %s0, { i64, ptr } %t35)
  store { i64, ptr } %t37, ptr %l29
  br label %bb13
bb12:
  br label %bb15
bb13:
  %t38 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t38, 0
  %t40 = extractvalue { i64, ptr } %t38, 1
  %t41 = mul i64 %t39, 1
  %t42 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t41)
  call void @llvm.memcpy.p0.p0.i64(ptr %t42, ptr %t40, i64 %t41, i1 false)
  %t43 = insertvalue { i64, ptr } undef, i64 %t39, 0
  %t44 = insertvalue { i64, ptr } %t43, ptr %t42, 1
  %t45 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t47 = extractvalue { i64, ptr } %t45, 1
  %t48 = extractvalue { i64, ptr } %t45, 0
  %t49 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t48)
  call void @olang_textcopy(ptr %t49, ptr %t47, i64 %t48)
  %t50 = insertvalue { i64, ptr } undef, i64 %t48, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t49, 1
  %t53 = extractvalue { i64, ptr } %t51, 0
  %t54 = extractvalue { i64, ptr } %t51, 1
  %t55 = mul i64 %t53, 1
  %t56 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t55)
  call void @llvm.memcpy.p0.p0.i64(ptr %t56, ptr %t54, i64 %t55, i1 false)
  %t57 = insertvalue { i64, ptr } undef, i64 %t53, 0
  %t58 = insertvalue { i64, ptr } %t57, ptr %t56, 1
  %t59 = load ptr, ptr %l27, !tbaa !29
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6f7a2f8d839c49b6e7a19c287d4b190c(ptr %s0, ptr %s0, ptr %s0, ptr %t59, { i64, ptr } %t44, { i64, ptr } %t58)
  br label %bb14
bb14:
  br label %bb15
bb15:
  %t62 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t64 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t62, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d89, i32 0, i32 1) })
  store i1 %t64, ptr %l35
  br label %bb16
bb16:
  %t65 = load i1, ptr %l35, !tbaa !21
  br i1 %t65, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s5
  %t66 = load i1, ptr %l2, !tbaa !21
  br i1 %t66, label %bb19, label %bb20
bb18:
  br label %bb33
bb19:
  %t68 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t68, ptr %l37, !tbaa !27
  br label %bb26
bb20:
  %t70 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t72 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v1, ptr %v2, { i64, ptr } %t70)
  %t73 = extractvalue { i32, { i64, ptr } } %t72, 1
  %t74 = extractvalue { i32, { i64, ptr } } %t72, 0
  store i32 %t74, ptr %l42
  %t75 = icmp ne i32 %t74, 0
  br i1 %t75, label %bb22, label %ok.76, !prof !99
ok.76:
  store { i64, ptr } %t73, ptr %l41
  br label %bb21
bb21:
  %t77 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t77, ptr %l39, !tbaa !27
  br label %bb25
bb22:
  %t78 = load i32, ptr %l42, !tbaa !23
  %t79 = ashr i32 %t78, 16
  %t81 = icmp eq i32 %t79, 1
  store i1 %t81, ptr %l44, !tbaa !21
  br label %bb23
bb23:
  call void @__olang_ert_req_clear()
  %t82 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t83 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d90, i32 0, i32 1) }, 1
  %t84 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d90, i32 0, i32 1) }, 0
  %t86 = extractvalue { i64, ptr } %t82, 1
  %t87 = extractvalue { i64, ptr } %t82, 0
  %t88 = add i64 %t84, %t87
  %t89 = call ptr @__olang_scope_alloc(ptr %v5, i64 %t88)
  call void @olang_textcopy(ptr %t89, ptr %t83, i64 %t84)
  %t90 = getelementptr i8, ptr %t89, i64 %t84
  call void @olang_textcopy(ptr %t90, ptr %t86, i64 %t87)
  %t91 = insertvalue { i64, ptr } undef, i64 %t88, 0
  %t92 = insertvalue { i64, ptr } %t91, ptr %t89, 1
  %t94 = extractvalue { i64, ptr } %t92, 0
  %t95 = extractvalue { i64, ptr } %t92, 1
  %t96 = mul i64 %t94, 1
  %t97 = call ptr @__olang_scope_alloc(ptr %v5, i64 %t96)
  call void @llvm.memcpy.p0.p0.i64(ptr %t97, ptr %t95, i64 %t96, i1 false)
  %t98 = insertvalue { i64, ptr } undef, i64 %t94, 0
  %t99 = insertvalue { i64, ptr } %t98, ptr %t97, 1
  %t101 = call { i64, ptr } @compiler_2fmcp_2etoolError(ptr %v5, ptr %v5, { i64, ptr } %t99)
  store { i64, ptr } %t101, ptr %l48
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t102 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t102, ptr %rv
  br label %ret
bb25:
  %t103 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t103, ptr %l37, !tbaa !27
  br label %bb26
bb26:
  %t104 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t105 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t109 = call { i32, { i64, ptr } } @compiler_2fsession_2eFormat(ptr %v1, ptr %v2, ptr %s5, { i64, ptr } %t105, { i64, ptr } %t104)
  %t110 = extractvalue { i32, { i64, ptr } } %t109, 1
  %t111 = extractvalue { i32, { i64, ptr } } %t109, 0
  store i32 %t111, ptr %l53
  %t112 = icmp ne i32 %t111, 0
  br i1 %t112, label %bb28, label %ok.113, !prof !99
ok.113:
  store { i64, ptr } %t110, ptr %l52
  br label %bb27
bb27:
  %t114 = load { i64, ptr }, ptr %l52, !tbaa !27
  store { i64, ptr } %t114, ptr %l49, !tbaa !27
  br label %bb31
bb28:
  br label %bb29
bb29:
  call void @__olang_ert_req_clear()
  %t115 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t117 = extractvalue { i64, ptr } %t115, 1
  %t118 = extractvalue { i64, ptr } %t115, 0
  %t119 = extractvalue { i64, ptr } { i64 46, ptr getelementptr inbounds (<{ i64, [46 x i8] }>, ptr @.d91, i32 0, i32 1) }, 1
  %t120 = extractvalue { i64, ptr } { i64 46, ptr getelementptr inbounds (<{ i64, [46 x i8] }>, ptr @.d91, i32 0, i32 1) }, 0
  %t121 = add i64 %t118, %t120
  %t122 = call ptr @__olang_scope_alloc(ptr %v5, i64 %t121)
  call void @olang_textcopy(ptr %t122, ptr %t117, i64 %t118)
  %t123 = getelementptr i8, ptr %t122, i64 %t118
  call void @olang_textcopy(ptr %t123, ptr %t119, i64 %t120)
  %t124 = insertvalue { i64, ptr } undef, i64 %t121, 0
  %t125 = insertvalue { i64, ptr } %t124, ptr %t122, 1
  %t127 = extractvalue { i64, ptr } %t125, 0
  %t128 = extractvalue { i64, ptr } %t125, 1
  %t129 = mul i64 %t127, 1
  %t130 = call ptr @__olang_scope_alloc(ptr %v5, i64 %t129)
  call void @llvm.memcpy.p0.p0.i64(ptr %t130, ptr %t128, i64 %t129, i1 false)
  %t131 = insertvalue { i64, ptr } undef, i64 %t127, 0
  %t132 = insertvalue { i64, ptr } %t131, ptr %t130, 1
  %t134 = call { i64, ptr } @compiler_2fmcp_2etextResult(ptr %v5, ptr %v5, { i64, ptr } %t132, i1 true)
  store { i64, ptr } %t134, ptr %l57
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t135 = load { i64, ptr }, ptr %l57, !tbaa !27
  store { i64, ptr } %t135, ptr %rv
  br label %ret
bb31:
  %t136 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t139 = call { i64, ptr } @compiler_2fmcp_2etextResult(ptr %s5, ptr %v5, { i64, ptr } %t136, i1 false)
  store { i64, ptr } %t139, ptr %l59
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t140 = load { i64, ptr }, ptr %l59, !tbaa !27
  store { i64, ptr } %t140, ptr %rv
  br label %ret
bb33:
  call void @compiler_2fdiag_3aDiagnostics_2ector(ptr %t141, ptr %v4, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l60, ptr %t141, i64 544, i1 false)
  br label %bb34
bb34:
  %t142 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 544, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t142, ptr %l60, i64 544, i1 false)
  store ptr %t142, ptr %l10, !tbaa !29
  %t144 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t146 = load ptr, ptr %l10, !tbaa !29
  %t151 = call ptr @compiler_2fsession_2eAnalyze(ptr %v1, ptr %v4, ptr %v4, ptr %s0, ptr %v4, { i64, ptr } %t144, ptr %a5, ptr %t146, ptr %l7, i1 true)
  store ptr %t151, ptr %l66
  br label %bb35
bb35:
  %t152 = load ptr, ptr %l66, !tbaa !29
  store ptr %t152, ptr %l11, !tbaa !29
  %t153 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t155 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t153, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d92, i32 0, i32 1) })
  store i1 %t155, ptr %l68
  br label %bb36
bb36:
  %t156 = load i1, ptr %l68, !tbaa !21
  br i1 %t156, label %bb37, label %bb38
bb37:
  %t157 = load ptr, ptr %l11, !tbaa !29
  %t158 = load ptr, ptr %l10, !tbaa !29
  %t161 = call { i64, ptr } @compiler_2fmcp_2echeckResult(ptr %v4, ptr %v4, ptr %v5, ptr %t157, ptr %t158)
  store { i64, ptr } %t161, ptr %l71
  br label %bb39
bb38:
  br label %bb40
bb39:
  call void @__olang_scope_close(ptr %s0)
  %t162 = load { i64, ptr }, ptr %l71, !tbaa !27
  store { i64, ptr } %t162, ptr %rv
  br label %ret
bb40:
  %t163 = load ptr, ptr %l10, !tbaa !29
  %t165 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v4, ptr %t163)
  store i64 %t165, ptr %l73
  br label %bb41
bb41:
  %t166 = load i64, ptr %l73, !tbaa !24
  %t167 = icmp sgt i64 %t166, 0
  br i1 %t167, label %bb42, label %bb43
bb42:
  store i1 true, ptr %l75, !tbaa !21
  br label %bb44
bb43:
  %t169 = load ptr, ptr %l11, !tbaa !29
  %t171 = getelementptr %"compiler/session:Analysis", ptr %t169, i32 0, i32 1
  %t172 = load ptr, ptr %t171, !tbaa !29
  %t174 = icmp eq ptr %t172, null
  store i1 %t174, ptr %l75, !tbaa !21
  br label %bb44
bb44:
  %t176 = load i1, ptr %l75, !tbaa !21
  br i1 %t176, label %bb45, label %bb46
bb45:
  store i1 true, ptr %l79, !tbaa !21
  br label %bb47
bb46:
  %t177 = load ptr, ptr %l11, !tbaa !29
  %t179 = getelementptr %"compiler/session:Analysis", ptr %t177, i32 0, i32 2
  %t180 = load ptr, ptr %t179, !tbaa !29
  %t182 = icmp eq ptr %t180, null
  store i1 %t182, ptr %l79, !tbaa !21
  br label %bb47
bb47:
  %t184 = load i1, ptr %l79, !tbaa !21
  br i1 %t184, label %bb48, label %bb49
bb48:
  store %olang.scope zeroinitializer, ptr %s11
  %t185 = load ptr, ptr %l10, !tbaa !29
  %t187 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eRender(ptr %v4, ptr %s11, ptr %t185)
  store { i64, ptr } %t187, ptr %l84
  br label %bb50
bb49:
  br label %bb53
bb50:
  %t188 = load ptr, ptr %l10, !tbaa !29
  %t190 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eSummary(ptr %v4, ptr %s11, ptr %t188)
  store { i64, ptr } %t190, ptr %l86
  br label %bb51
bb51:
  %t191 = load { i64, ptr }, ptr %l84, !tbaa !27
  %t192 = extractvalue { i64, ptr } %t191, 1
  %t193 = extractvalue { i64, ptr } %t191, 0
  %t194 = load { i64, ptr }, ptr %l86, !tbaa !27
  %t195 = extractvalue { i64, ptr } %t194, 1
  %t196 = extractvalue { i64, ptr } %t194, 0
  %t197 = add i64 %t193, %t196
  %t198 = call ptr @__olang_scope_alloc(ptr %v5, i64 %t197)
  call void @olang_textcopy(ptr %t198, ptr %t192, i64 %t193)
  %t199 = getelementptr i8, ptr %t198, i64 %t193
  call void @olang_textcopy(ptr %t199, ptr %t195, i64 %t196)
  %t200 = insertvalue { i64, ptr } undef, i64 %t197, 0
  %t201 = insertvalue { i64, ptr } %t200, ptr %t198, 1
  %t203 = extractvalue { i64, ptr } %t201, 0
  %t204 = extractvalue { i64, ptr } %t201, 1
  %t205 = mul i64 %t203, 1
  %t206 = call ptr @__olang_scope_alloc(ptr %v5, i64 %t205)
  call void @llvm.memcpy.p0.p0.i64(ptr %t206, ptr %t204, i64 %t205, i1 false)
  %t207 = insertvalue { i64, ptr } undef, i64 %t203, 0
  %t208 = insertvalue { i64, ptr } %t207, ptr %t206, 1
  %t210 = call { i64, ptr } @compiler_2fmcp_2etextResult(ptr %v5, ptr %v5, { i64, ptr } %t208, i1 true)
  store { i64, ptr } %t210, ptr %l89
  br label %bb52
bb52:
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s0)
  %t211 = load { i64, ptr }, ptr %l89, !tbaa !27
  store { i64, ptr } %t211, ptr %rv
  br label %ret
bb53:
  %t212 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t214 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t212, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d93, i32 0, i32 1) })
  store i1 %t214, ptr %l91
  br label %bb54
bb54:
  %t215 = load i1, ptr %l91, !tbaa !21
  br i1 %t215, label %bb55, label %bb56
bb55:
  store %olang.scope zeroinitializer, ptr %s13
  %t216 = load ptr, ptr %l11, !tbaa !29
  %t218 = getelementptr %"compiler/session:Analysis", ptr %t216, i32 0, i32 1
  %t219 = load ptr, ptr %t218, !tbaa !29
  %t221 = icmp eq ptr %t219, null
  br i1 %t221, label %bb57, label %bb58
bb56:
  br label %bb72
bb57:
  call void @__olang_check_failed(ptr @olang_loc_308bbd8a0e283fc3_2a8ec4cf6bdf47df)
  unreachable
bb58:
  br label %bb59
bb59:
  %t223 = load ptr, ptr %l11, !tbaa !29
  %t225 = getelementptr %"compiler/session:Analysis", ptr %t223, i32 0, i32 1
  %t226 = load ptr, ptr %t225, !tbaa !29
  store ptr %t226, ptr %l97, !tbaa !29
  %t227 = load ptr, ptr %l11, !tbaa !29
  %t229 = getelementptr %"compiler/session:Analysis", ptr %t227, i32 0, i32 2
  %t230 = load ptr, ptr %t229, !tbaa !29
  %t232 = icmp eq ptr %t230, null
  br i1 %t232, label %bb60, label %bb61
bb60:
  call void @__olang_check_failed(ptr @olang_loc_308bbd8a0e283fc3_2a8ec4cf6bdf47df)
  unreachable
bb61:
  br label %bb62
bb62:
  %t234 = load ptr, ptr %l11, !tbaa !29
  %t236 = getelementptr %"compiler/session:Analysis", ptr %t234, i32 0, i32 2
  %t237 = load ptr, ptr %t236, !tbaa !29
  store ptr %t237, ptr %l102, !tbaa !29
  %t238 = load ptr, ptr %l11, !tbaa !29
  %t240 = getelementptr %"compiler/session:Analysis", ptr %t238, i32 0, i32 3
  %t241 = load ptr, ptr %t240, !tbaa !29
  %t243 = icmp eq ptr %t241, null
  br i1 %t243, label %bb63, label %bb64
bb63:
  call void @__olang_check_failed(ptr @olang_loc_308bbd8a0e283fc3_2a8ec4cf6bdf47df)
  unreachable
bb64:
  br label %bb65
bb65:
  %t245 = load ptr, ptr %l11, !tbaa !29
  %t247 = getelementptr %"compiler/session:Analysis", ptr %t245, i32 0, i32 3
  %t248 = load ptr, ptr %t247, !tbaa !29
  %t249 = load ptr, ptr %l11, !tbaa !29
  %t251 = getelementptr %"compiler/session:Analysis", ptr %t249, i32 0, i32 0
  %t252 = load ptr, ptr %t251, !tbaa !29
  %t254 = getelementptr %"compiler/load:Loader", ptr %t252, i32 0, i32 12
  %t255 = load i64, ptr %t254, !tbaa !24
  %t256 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t257 = load ptr, ptr %l97, !tbaa !29
  %t258 = load ptr, ptr %l102, !tbaa !29
  %t262 = call { i32, { i64, ptr } } @compiler_2fexplain_2eItem(ptr %v4, ptr %v4, ptr %v4, ptr %v3, ptr %s13, ptr %t257, ptr %t258, ptr %t248, i64 %t255, { i64, ptr } %t256)
  %t263 = extractvalue { i32, { i64, ptr } } %t262, 1
  %t264 = extractvalue { i32, { i64, ptr } } %t262, 0
  store i32 %t264, ptr %l113
  %t265 = icmp ne i32 %t264, 0
  br i1 %t265, label %bb67, label %ok.266, !prof !99
ok.266:
  store { i64, ptr } %t263, ptr %l112
  br label %bb66
bb66:
  %t267 = load { i64, ptr }, ptr %l112, !tbaa !27
  store { i64, ptr } %t267, ptr %l92, !tbaa !27
  br label %bb70
bb67:
  %t268 = load i32, ptr %l113, !tbaa !23
  %t269 = ashr i32 %t268, 16
  %t271 = icmp eq i32 %t269, 1
  store i1 %t271, ptr %l115, !tbaa !21
  br label %bb68
bb68:
  call void @__olang_ert_req_clear()
  %t272 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t273 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t274 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d94, i32 0, i32 1) }, 1
  %t275 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d94, i32 0, i32 1) }, 0
  %t277 = extractvalue { i64, ptr } %t272, 1
  %t278 = extractvalue { i64, ptr } %t272, 0
  %t279 = add i64 %t275, %t278
  %t280 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d95, i32 0, i32 1) }, 1
  %t281 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d95, i32 0, i32 1) }, 0
  %t282 = add i64 %t279, %t281
  %t284 = extractvalue { i64, ptr } %t273, 1
  %t285 = extractvalue { i64, ptr } %t273, 0
  %t286 = add i64 %t282, %t285
  %t287 = call ptr @__olang_scope_alloc(ptr %v5, i64 %t286)
  call void @olang_textcopy(ptr %t287, ptr %t274, i64 %t275)
  %t288 = getelementptr i8, ptr %t287, i64 %t275
  call void @olang_textcopy(ptr %t288, ptr %t277, i64 %t278)
  %t289 = getelementptr i8, ptr %t288, i64 %t278
  call void @olang_textcopy(ptr %t289, ptr %t280, i64 %t281)
  %t290 = getelementptr i8, ptr %t289, i64 %t281
  call void @olang_textcopy(ptr %t290, ptr %t284, i64 %t285)
  %t291 = insertvalue { i64, ptr } undef, i64 %t286, 0
  %t292 = insertvalue { i64, ptr } %t291, ptr %t287, 1
  %t294 = extractvalue { i64, ptr } %t292, 0
  %t295 = extractvalue { i64, ptr } %t292, 1
  %t296 = mul i64 %t294, 1
  %t297 = call ptr @__olang_scope_alloc(ptr %v5, i64 %t296)
  call void @llvm.memcpy.p0.p0.i64(ptr %t297, ptr %t295, i64 %t296, i1 false)
  %t298 = insertvalue { i64, ptr } undef, i64 %t294, 0
  %t299 = insertvalue { i64, ptr } %t298, ptr %t297, 1
  %t301 = call { i64, ptr } @compiler_2fmcp_2etextResult(ptr %v5, ptr %v5, { i64, ptr } %t299, i1 true)
  store { i64, ptr } %t301, ptr %l120
  br label %bb69
bb69:
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s0)
  %t302 = load { i64, ptr }, ptr %l120, !tbaa !27
  store { i64, ptr } %t302, ptr %rv
  br label %ret
bb70:
  %t303 = load { i64, ptr }, ptr %l92, !tbaa !27
  %t306 = call { i64, ptr } @compiler_2fmcp_2etextResult(ptr %s13, ptr %v5, { i64, ptr } %t303, i1 false)
  store { i64, ptr } %t306, ptr %l122
  br label %bb71
bb71:
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s0)
  %t307 = load { i64, ptr }, ptr %l122, !tbaa !27
  store { i64, ptr } %t307, ptr %rv
  br label %ret
bb72:
  %t308 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t310 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v3, ptr %s0, { i64, ptr } %t308, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d96, i32 0, i32 1) })
  store i1 %t310, ptr %l124
  br label %bb73
bb73:
  %t311 = load i1, ptr %l124, !tbaa !21
  %t312 = xor i1 %t311, true
  br i1 %t312, label %bb74, label %bb75
bb74:
  store %olang.scope zeroinitializer, ptr %s16
  %t314 = load ptr, ptr %l11, !tbaa !29
  %t316 = getelementptr %"compiler/session:Analysis", ptr %t314, i32 0, i32 1
  %t317 = load ptr, ptr %t316, !tbaa !29
  %t319 = icmp eq ptr %t317, null
  br i1 %t319, label %bb76, label %bb77
bb75:
  br label %bb91
bb76:
  call void @__olang_check_failed(ptr @olang_loc_fd6ee713b6cd3a34_3a725fec10b02c40)
  unreachable
bb77:
  br label %bb78
bb78:
  %t321 = load ptr, ptr %l11, !tbaa !29
  %t323 = getelementptr %"compiler/session:Analysis", ptr %t321, i32 0, i32 1
  %t324 = load ptr, ptr %t323, !tbaa !29
  store ptr %t324, ptr %l131, !tbaa !29
  %t325 = load ptr, ptr %l11, !tbaa !29
  %t327 = getelementptr %"compiler/session:Analysis", ptr %t325, i32 0, i32 2
  %t328 = load ptr, ptr %t327, !tbaa !29
  %t330 = icmp eq ptr %t328, null
  br i1 %t330, label %bb79, label %bb80
bb79:
  call void @__olang_check_failed(ptr @olang_loc_fd6ee713b6cd3a34_3a725fec10b02c40)
  unreachable
bb80:
  br label %bb81
bb81:
  %t332 = load ptr, ptr %l11, !tbaa !29
  %t334 = getelementptr %"compiler/session:Analysis", ptr %t332, i32 0, i32 2
  %t335 = load ptr, ptr %t334, !tbaa !29
  store ptr %t335, ptr %l136, !tbaa !29
  %t336 = load ptr, ptr %l11, !tbaa !29
  %t338 = getelementptr %"compiler/session:Analysis", ptr %t336, i32 0, i32 3
  %t339 = load ptr, ptr %t338, !tbaa !29
  %t341 = icmp eq ptr %t339, null
  br i1 %t341, label %bb82, label %bb83
bb82:
  call void @__olang_check_failed(ptr @olang_loc_fd6ee713b6cd3a34_3a725fec10b02c40)
  unreachable
bb83:
  br label %bb84
bb84:
  %t343 = load ptr, ptr %l11, !tbaa !29
  %t345 = getelementptr %"compiler/session:Analysis", ptr %t343, i32 0, i32 3
  %t346 = load ptr, ptr %t345, !tbaa !29
  %t347 = load ptr, ptr %l11, !tbaa !29
  %t349 = getelementptr %"compiler/session:Analysis", ptr %t347, i32 0, i32 0
  %t350 = load ptr, ptr %t349, !tbaa !29
  %t352 = getelementptr %"compiler/load:Loader", ptr %t350, i32 0, i32 12
  %t353 = load i64, ptr %t352, !tbaa !24
  %t354 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t355 = load ptr, ptr %l131, !tbaa !29
  %t356 = load ptr, ptr %l136, !tbaa !29
  %t360 = call { i32, { i64, ptr } } @compiler_2fdoc_2eItemText(ptr %v4, ptr %v4, ptr %v4, ptr %v3, ptr %s16, ptr %t355, ptr %t356, ptr %t346, i64 %t353, { i64, ptr } %t354)
  %t361 = extractvalue { i32, { i64, ptr } } %t360, 1
  %t362 = extractvalue { i32, { i64, ptr } } %t360, 0
  store i32 %t362, ptr %l147
  %t363 = icmp ne i32 %t362, 0
  br i1 %t363, label %bb86, label %ok.364, !prof !99
ok.364:
  store { i64, ptr } %t361, ptr %l146
  br label %bb85
bb85:
  %t365 = load { i64, ptr }, ptr %l146, !tbaa !27
  store { i64, ptr } %t365, ptr %l126, !tbaa !27
  br label %bb89
bb86:
  %t366 = load i32, ptr %l147, !tbaa !23
  %t367 = ashr i32 %t366, 16
  %t369 = icmp eq i32 %t367, 1
  store i1 %t369, ptr %l149, !tbaa !21
  br label %bb87
bb87:
  call void @__olang_ert_req_clear()
  %t370 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t371 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t372 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d97, i32 0, i32 1) }, 1
  %t373 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d97, i32 0, i32 1) }, 0
  %t375 = extractvalue { i64, ptr } %t370, 1
  %t376 = extractvalue { i64, ptr } %t370, 0
  %t377 = add i64 %t373, %t376
  %t378 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d98, i32 0, i32 1) }, 1
  %t379 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d98, i32 0, i32 1) }, 0
  %t380 = add i64 %t377, %t379
  %t382 = extractvalue { i64, ptr } %t371, 1
  %t383 = extractvalue { i64, ptr } %t371, 0
  %t384 = add i64 %t380, %t383
  %t385 = call ptr @__olang_scope_alloc(ptr %v5, i64 %t384)
  call void @olang_textcopy(ptr %t385, ptr %t372, i64 %t373)
  %t386 = getelementptr i8, ptr %t385, i64 %t373
  call void @olang_textcopy(ptr %t386, ptr %t375, i64 %t376)
  %t387 = getelementptr i8, ptr %t386, i64 %t376
  call void @olang_textcopy(ptr %t387, ptr %t378, i64 %t379)
  %t388 = getelementptr i8, ptr %t387, i64 %t379
  call void @olang_textcopy(ptr %t388, ptr %t382, i64 %t383)
  %t389 = insertvalue { i64, ptr } undef, i64 %t384, 0
  %t390 = insertvalue { i64, ptr } %t389, ptr %t385, 1
  %t392 = extractvalue { i64, ptr } %t390, 0
  %t393 = extractvalue { i64, ptr } %t390, 1
  %t394 = mul i64 %t392, 1
  %t395 = call ptr @__olang_scope_alloc(ptr %v5, i64 %t394)
  call void @llvm.memcpy.p0.p0.i64(ptr %t395, ptr %t393, i64 %t394, i1 false)
  %t396 = insertvalue { i64, ptr } undef, i64 %t392, 0
  %t397 = insertvalue { i64, ptr } %t396, ptr %t395, 1
  %t399 = call { i64, ptr } @compiler_2fmcp_2etextResult(ptr %v5, ptr %v5, { i64, ptr } %t397, i1 true)
  store { i64, ptr } %t399, ptr %l154
  br label %bb88
bb88:
  call void @__olang_scope_close(ptr %s16)
  call void @__olang_scope_close(ptr %s0)
  %t400 = load { i64, ptr }, ptr %l154, !tbaa !27
  store { i64, ptr } %t400, ptr %rv
  br label %ret
bb89:
  %t401 = load { i64, ptr }, ptr %l126, !tbaa !27
  %t404 = call { i64, ptr } @compiler_2fmcp_2etextResult(ptr %s16, ptr %v5, { i64, ptr } %t401, i1 false)
  store { i64, ptr } %t404, ptr %l156
  br label %bb90
bb90:
  call void @__olang_scope_close(ptr %s16)
  call void @__olang_scope_close(ptr %s0)
  %t405 = load { i64, ptr }, ptr %l156, !tbaa !27
  store { i64, ptr } %t405, ptr %rv
  br label %ret
bb91:
  %t406 = load ptr, ptr %l11, !tbaa !29
  %t408 = getelementptr %"compiler/session:Analysis", ptr %t406, i32 0, i32 1
  %t409 = load ptr, ptr %t408, !tbaa !29
  %t411 = icmp eq ptr %t409, null
  br i1 %t411, label %bb92, label %bb93
bb92:
  call void @__olang_check_failed(ptr @olang_loc_bf544a52d5413c29_9c9e72e4a09cc655)
  unreachable
bb93:
  br label %bb94
bb94:
  %t413 = load ptr, ptr %l11, !tbaa !29
  %t415 = getelementptr %"compiler/session:Analysis", ptr %t413, i32 0, i32 1
  %t416 = load ptr, ptr %t415, !tbaa !29
  store ptr %t416, ptr %l161, !tbaa !29
  %t417 = load ptr, ptr %l11, !tbaa !29
  %t419 = getelementptr %"compiler/session:Analysis", ptr %t417, i32 0, i32 2
  %t420 = load ptr, ptr %t419, !tbaa !29
  %t422 = icmp eq ptr %t420, null
  br i1 %t422, label %bb95, label %bb96
bb95:
  call void @__olang_check_failed(ptr @olang_loc_bf544a52d5413c29_9c9e72e4a09cc655)
  unreachable
bb96:
  br label %bb97
bb97:
  %t424 = load ptr, ptr %l11, !tbaa !29
  %t426 = getelementptr %"compiler/session:Analysis", ptr %t424, i32 0, i32 2
  %t427 = load ptr, ptr %t426, !tbaa !29
  store ptr %t427, ptr %l166, !tbaa !29
  %t428 = load ptr, ptr %l11, !tbaa !29
  %t430 = getelementptr %"compiler/session:Analysis", ptr %t428, i32 0, i32 3
  %t431 = load ptr, ptr %t430, !tbaa !29
  %t433 = icmp eq ptr %t431, null
  br i1 %t433, label %bb98, label %bb99
bb98:
  call void @__olang_check_failed(ptr @olang_loc_bf544a52d5413c29_9c9e72e4a09cc655)
  unreachable
bb99:
  br label %bb100
bb100:
  %t435 = load ptr, ptr %l11, !tbaa !29
  %t437 = getelementptr %"compiler/session:Analysis", ptr %t435, i32 0, i32 3
  %t438 = load ptr, ptr %t437, !tbaa !29
  %t439 = load ptr, ptr %l11, !tbaa !29
  %t441 = getelementptr %"compiler/session:Analysis", ptr %t439, i32 0, i32 0
  %t442 = load ptr, ptr %t441, !tbaa !29
  %t444 = getelementptr %"compiler/load:Loader", ptr %t442, i32 0, i32 12
  %t445 = load i64, ptr %t444, !tbaa !24
  %t446 = load ptr, ptr %l161, !tbaa !29
  %t447 = load ptr, ptr %l166, !tbaa !29
  %t450 = call %"compiler/doc:Module" @compiler_2fdoc_2eOf(ptr %v4, ptr %v4, ptr %v4, ptr %v5, ptr %t446, ptr %t447, ptr %t438, i64 %t445, i1 false)
  store %"compiler/doc:Module" %t450, ptr %l175
  br label %bb101
bb101:
  %t451 = load %"compiler/doc:Module", ptr %l175
  %t452 = call ptr @__olang_scope_alloc_a(ptr %v5, i64 80, i64 8)
  store %"compiler/doc:Module" %t451, ptr %t452
  %t454 = call { i64, ptr } @compiler_2fdoc_2ecompiler_2fdoc_3aModule_2eText(ptr %v5, ptr %v5, ptr %t452)
  store { i64, ptr } %t454, ptr %l177
  br label %bb102
bb102:
  %t455 = load { i64, ptr }, ptr %l177, !tbaa !27
  %t456 = extractvalue { i64, ptr } %t455, 0
  %t457 = extractvalue { i64, ptr } %t455, 1
  %t458 = mul i64 %t456, 1
  %t459 = call ptr @__olang_scope_alloc(ptr %v5, i64 %t458)
  call void @llvm.memcpy.p0.p0.i64(ptr %t459, ptr %t457, i64 %t458, i1 false)
  %t460 = insertvalue { i64, ptr } undef, i64 %t456, 0
  %t461 = insertvalue { i64, ptr } %t460, ptr %t459, 1
  %t463 = call { i64, ptr } @compiler_2fmcp_2etextResult(ptr %v5, ptr %v5, { i64, ptr } %t461, i1 false)
  store { i64, ptr } %t463, ptr %l179
  br label %bb103
bb103:
  call void @__olang_scope_close(ptr %s0)
  %t464 = load { i64, ptr }, ptr %l179, !tbaa !27
  store { i64, ptr } %t464, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fmcp_2esend(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l5 = alloca i32
  %l7 = alloca i1
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d99, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d99, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t14 = extractvalue { i64, ptr } %t11, 0
  %t15 = extractvalue { i64, ptr } %t11, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  %t21 = call i32 @std_2fio_2eWrite(ptr %s0, i32 1, { i64, ptr } %t19)
  store i32 %t21, ptr %l5
  %t22 = icmp ne i32 %t21, 0
  br i1 %t22, label %bb2, label %ok.23, !prof !99
ok.23:
  br label %bb1
bb1:
  br label %bb4
bb2:
  %t24 = load i32, ptr %l5, !tbaa !23
  %t25 = ashr i32 %t24, 16
  %t27 = icmp eq i32 %t25, 1
  store i1 %t27, ptr %l7, !tbaa !21
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fmcp_2estr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca i32
  %l8 = alloca i1
  %l9 = alloca { i64, ptr }
  %l10 = alloca i32
  %l12 = alloca i1
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAt_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %v1, ptr %v0, ptr %a0, { i64, ptr } %a1)
  %t6 = extractvalue { i32, ptr } %t5, 1
  %t7 = extractvalue { i32, ptr } %t5, 0
  store i32 %t7, ptr %l6
  %t8 = icmp ne i32 %t7, 0
  br i1 %t8, label %bb2, label %ok.9, !prof !99
ok.9:
  store ptr %t6, ptr %l5
  br label %bb1
bb1:
  %t10 = load ptr, ptr %l5, !tbaa !29
  %t11 = call { i32, { i64, ptr } } @std_2fjson_2estd_2fjson_3aJson_2eAsStr(ptr %v0, ptr %v2, ptr %t10)
  %t12 = extractvalue { i32, { i64, ptr } } %t11, 1
  %t13 = extractvalue { i32, { i64, ptr } } %t11, 0
  store i32 %t13, ptr %l10
  %t14 = icmp ne i32 %t13, 0
  br i1 %t14, label %bb5, label %ok.15, !prof !99
ok.15:
  store { i64, ptr } %t12, ptr %l9
  br label %bb4
bb2:
  %t16 = load i32, ptr %l6, !tbaa !23
  %t17 = ashr i32 %t16, 16
  %t19 = icmp eq i32 %t17, 1
  store i1 %t19, ptr %l8, !tbaa !21
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d100, i32 0, i32 1) }, ptr %l2, !tbaa !27
  br label %bb6
bb4:
  %t20 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t20, ptr %l2, !tbaa !27
  br label %bb6
bb5:
  %t21 = load i32, ptr %l10, !tbaa !23
  %t22 = ashr i32 %t21, 16
  %t24 = icmp eq i32 %t22, 1
  store i1 %t24, ptr %l12, !tbaa !21
  br label %bb3
bb6:
  %t25 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t25, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fmcp_2etestResult(ptr %v0, ptr %v1, { i64, ptr } %a0, i32 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca %"std/prelude/text:LineIter"
  %l6 = alloca { i64, ptr }
  %l7 = alloca i1
  %l8 = alloca %"std/prelude/text:StringBuilder"
  %l9 = alloca %"std/prelude/text:StringBuilder"
  %l12 = alloca %"std/prelude/text:LineIter"
  %l13 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca i32
  %l18 = alloca i1
  %l20 = alloca i1
  %l23 = alloca i1
  %l25 = alloca i1
  %l36 = alloca ptr
  %l38 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l42 = alloca i64
  %l43 = alloca i64
  %l48 = alloca { i64, ptr }
  %l51 = alloca i64
  %l52 = alloca i64
  %l57 = alloca ptr
  %l59 = alloca { i64, ptr }
  %l70 = alloca %"std/prelude/text:StringBuilder"
  %l74 = alloca ptr
  %l76 = alloca { i64, ptr }
  %l79 = alloca { i64, ptr }
  %l83 = alloca { i64, ptr }
  %l84 = alloca { i64, ptr }
  %l85 = alloca i64
  %l86 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l9
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l9
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l2, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d101, i32 0, i32 1) })
  br label %bb2
bb2:
  store i64 0, ptr %l3, !tbaa !24
  store i64 0, ptr %l4, !tbaa !24
  %t4 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t6 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v0, { i64, ptr } %t4)
  store %"std/prelude/text:LineIter" %t6, ptr %l12
  br label %bb3
bb3:
  %t7 = load %"std/prelude/text:LineIter", ptr %l12
  store %"std/prelude/text:LineIter" %t7, ptr %l5
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t9 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %v0, ptr %l5)
  %t10 = extractvalue { i32, { i64, ptr } } %t9, 1
  %t11 = extractvalue { i32, { i64, ptr } } %t9, 0
  store i32 %t11, ptr %l16
  %t12 = icmp ne i32 %t11, 0
  br i1 %t12, label %bb6, label %ok.13, !prof !99
ok.13:
  store { i64, ptr } %t10, ptr %l15
  br label %bb5
bb5:
  %t14 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t14, ptr %l13, !tbaa !27
  br label %bb8
bb6:
  %t15 = load i32, ptr %l16, !tbaa !23
  %t16 = ashr i32 %t15, 16
  %t18 = icmp eq i32 %t16, 1
  store i1 %t18, ptr %l18, !tbaa !21
  br label %bb7
bb7:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %bb46
bb8:
  %t19 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t19, ptr %l6, !tbaa !27
  %t20 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t22 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s2, { i64, ptr } %t20, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d102, i32 0, i32 1) })
  store i1 %t22, ptr %l20
  br label %bb9
bb9:
  %t23 = load i1, ptr %l20, !tbaa !21
  store i1 %t23, ptr %l7, !tbaa !21
  %t24 = load i1, ptr %l7, !tbaa !21
  %t26 = xor i1 %t24, true
  br i1 %t26, label %bb10, label %bb11
bb10:
  %t28 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t30 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s2, { i64, ptr } %t28, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d103, i32 0, i32 1) })
  store i1 %t30, ptr %l25
  br label %bb12
bb11:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb13
bb12:
  %t31 = load i1, ptr %l25, !tbaa !21
  %t32 = xor i1 %t31, true
  store i1 %t32, ptr %l23, !tbaa !21
  br label %bb13
bb13:
  %t34 = load i1, ptr %l23, !tbaa !21
  br i1 %t34, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s2)
  br label %bb45
bb15:
  br label %bb16
bb16:
  %t35 = load i64, ptr %l3, !tbaa !24
  %t37 = icmp sgt i64 %t35, 0
  br i1 %t37, label %bb17, label %bb18
bb17:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l2, i8 44)
  br label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb20
bb20:
  %t40 = load i64, ptr %l3, !tbaa !24
  %t42 = add i64 %t40, 1
  store i64 %t42, ptr %l3, !tbaa !24
  %t44 = load i1, ptr %l7, !tbaa !21
  br i1 %t44, label %bb21, label %bb22
bb21:
  %t46 = load i64, ptr %l4, !tbaa !24
  %t48 = add i64 %t46, 1
  store i64 %t48, ptr %l4, !tbaa !24
  br label %bb23
bb22:
  br label %bb23
bb23:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %l2, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d104, i32 0, i32 1) })
  br label %bb24
bb24:
  store ptr %l2, ptr %l36, !tbaa !29
  %t51 = load i1, ptr %l7, !tbaa !21
  br i1 %t51, label %bb25, label %bb26
bb25:
  %t53 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t53, ptr %l39, !tbaa !27
  %t54 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t57 = extractvalue { i64, ptr } %t54, 0
  store i64 %t57, ptr %l42, !tbaa !24
  %t58 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t59 = extractvalue { i64, ptr } %t58, 0
  store i64 %t59, ptr %l43, !tbaa !24
  %t60 = icmp sge i64 5, 0
  br i1 %t60, label %bb27, label %bb28
bb26:
  %t62 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t62, ptr %l48, !tbaa !27
  %t63 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t66 = extractvalue { i64, ptr } %t63, 0
  store i64 %t66, ptr %l51, !tbaa !24
  %t67 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t68 = extractvalue { i64, ptr } %t67, 0
  store i64 %t68, ptr %l52, !tbaa !24
  %t69 = icmp sge i64 7, 0
  br i1 %t69, label %bb33, label %bb34
bb27:
  %t71 = load i64, ptr %l42, !tbaa !24
  %t72 = icmp sle i64 5, %t71
  br i1 %t72, label %bb29, label %bb30
bb28:
  call void @__olang_check_failed(ptr @olang_loc_8d8cf657aed96bef_7cd13aec667ffb8b)
  unreachable
bb29:
  %t74 = load i64, ptr %l42, !tbaa !24
  %t75 = load i64, ptr %l43, !tbaa !24
  %t76 = icmp sle i64 %t74, %t75
  br i1 %t76, label %bb31, label %bb32
bb30:
  call void @__olang_check_failed(ptr @olang_loc_8d8cf657aed96bef_7cd13aec667ffb8b)
  unreachable
bb31:
  %t78 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !27
  %t80 = load i64, ptr %l42, !tbaa !24
  %t81 = getelementptr i8, ptr %t79, i64 5
  %t82 = sub i64 %t80, 5
  %t83 = insertvalue { i64, ptr } undef, i64 %t82, 0
  %t84 = insertvalue { i64, ptr } %t83, ptr %t81, 1
  store { i64, ptr } %t84, ptr %l38, !tbaa !27
  br label %bb39
bb32:
  call void @__olang_check_failed(ptr @olang_loc_8d8cf657aed96bef_7cd13aec667ffb8b)
  unreachable
bb33:
  %t86 = load i64, ptr %l51, !tbaa !24
  %t87 = icmp sle i64 7, %t86
  br i1 %t87, label %bb35, label %bb36
bb34:
  call void @__olang_check_failed(ptr @olang_loc_8d8cf657aed96bef_7cd13aec667ffb8b)
  unreachable
bb35:
  %t89 = load i64, ptr %l51, !tbaa !24
  %t90 = load i64, ptr %l52, !tbaa !24
  %t91 = icmp sle i64 %t89, %t90
  br i1 %t91, label %bb37, label %bb38
bb36:
  call void @__olang_check_failed(ptr @olang_loc_8d8cf657aed96bef_7cd13aec667ffb8b)
  unreachable
bb37:
  %t93 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !27
  %t95 = load i64, ptr %l51, !tbaa !24
  %t96 = getelementptr i8, ptr %t94, i64 7
  %t97 = sub i64 %t95, 7
  %t98 = insertvalue { i64, ptr } undef, i64 %t97, 0
  %t99 = insertvalue { i64, ptr } %t98, ptr %t96, 1
  store { i64, ptr } %t99, ptr %l38, !tbaa !27
  br label %bb39
bb38:
  call void @__olang_check_failed(ptr @olang_loc_8d8cf657aed96bef_7cd13aec667ffb8b)
  unreachable
bb39:
  %t101 = load ptr, ptr %l36, !tbaa !29
  %t102 = load { i64, ptr }, ptr %l38, !tbaa !27
  call void @compiler_2fsession_2eJsonStr(ptr %s0, ptr %v0, ptr %t101, { i64, ptr } %t102)
  br label %bb40
bb40:
  store ptr %l2, ptr %l57, !tbaa !29
  %t103 = load i1, ptr %l7, !tbaa !21
  br i1 %t103, label %bb41, label %bb42
bb41:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d105, i32 0, i32 1) }, ptr %l59, !tbaa !27
  br label %bb43
bb42:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d106, i32 0, i32 1) }, ptr %l59, !tbaa !27
  br label %bb43
bb43:
  %t105 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d107, i32 0, i32 1) }, 1
  %t106 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d107, i32 0, i32 1) }, 0
  %t107 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t108 = extractvalue { i64, ptr } %t107, 1
  %t109 = extractvalue { i64, ptr } %t107, 0
  %t110 = add i64 %t106, %t109
  %t111 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d108, i32 0, i32 1) }, 1
  %t112 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d108, i32 0, i32 1) }, 0
  %t113 = add i64 %t110, %t112
  %t114 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t113)
  call void @olang_textcopy(ptr %t114, ptr %t105, i64 %t106)
  %t115 = getelementptr i8, ptr %t114, i64 %t106
  call void @olang_textcopy(ptr %t115, ptr %t108, i64 %t109)
  %t116 = getelementptr i8, ptr %t115, i64 %t109
  call void @olang_textcopy(ptr %t116, ptr %t111, i64 %t112)
  %t117 = insertvalue { i64, ptr } undef, i64 %t113, 0
  %t118 = insertvalue { i64, ptr } %t117, ptr %t114, 1
  %t120 = extractvalue { i64, ptr } %t118, 0
  %t121 = extractvalue { i64, ptr } %t118, 1
  %t122 = mul i64 %t120, 1
  %t123 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t122)
  call void @llvm.memcpy.p0.p0.i64(ptr %t123, ptr %t121, i64 %t122, i1 false)
  %t124 = insertvalue { i64, ptr } undef, i64 %t120, 0
  %t125 = insertvalue { i64, ptr } %t124, ptr %t123, 1
  %t126 = load ptr, ptr %l57, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %t126, { i64, ptr } %t125)
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s2)
  br label %bb45
bb45:
  br label %bb4
bb46:
  %t128 = load i64, ptr %l4, !tbaa !24
  %t129 = load i64, ptr %l3, !tbaa !24
  %t130 = load i64, ptr %l4, !tbaa !24
  %t133 = sub i64 %t129, %t130
  %t134 = load i32, ptr %l1, !tbaa !23
  %t135 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d109, i32 0, i32 1) }, 1
  %t136 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d109, i32 0, i32 1) }, 0
  %t138 = call i64 @__olang_fmt_i64(ptr null, i64 %t128)
  %t139 = add i64 %t136, %t138
  %t140 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d110, i32 0, i32 1) }, 1
  %t141 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d110, i32 0, i32 1) }, 0
  %t142 = add i64 %t139, %t141
  %t144 = call i64 @__olang_fmt_i64(ptr null, i64 %t133)
  %t145 = add i64 %t142, %t144
  %t146 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d111, i32 0, i32 1) }, 1
  %t147 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d111, i32 0, i32 1) }, 0
  %t148 = add i64 %t145, %t147
  %t150 = sext i32 %t134 to i64
  %t151 = call i64 @__olang_fmt_i64(ptr null, i64 %t150)
  %t152 = add i64 %t148, %t151
  %t153 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d112, i32 0, i32 1) }, 1
  %t154 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d112, i32 0, i32 1) }, 0
  %t155 = add i64 %t152, %t154
  %t156 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t155)
  call void @olang_textcopy(ptr %t156, ptr %t135, i64 %t136)
  %t157 = getelementptr i8, ptr %t156, i64 %t136
  %t158 = call i64 @__olang_fmt_i64(ptr %t157, i64 %t128)
  %t159 = getelementptr i8, ptr %t157, i64 %t138
  call void @olang_textcopy(ptr %t159, ptr %t140, i64 %t141)
  %t160 = getelementptr i8, ptr %t159, i64 %t141
  %t161 = call i64 @__olang_fmt_i64(ptr %t160, i64 %t133)
  %t162 = getelementptr i8, ptr %t160, i64 %t144
  call void @olang_textcopy(ptr %t162, ptr %t146, i64 %t147)
  %t163 = getelementptr i8, ptr %t162, i64 %t147
  %t164 = call i64 @__olang_fmt_i64(ptr %t163, i64 %t150)
  %t165 = getelementptr i8, ptr %t163, i64 %t151
  call void @olang_textcopy(ptr %t165, ptr %t153, i64 %t154)
  %t166 = insertvalue { i64, ptr } undef, i64 %t155, 0
  %t167 = insertvalue { i64, ptr } %t166, ptr %t156, 1
  %t169 = extractvalue { i64, ptr } %t167, 0
  %t170 = extractvalue { i64, ptr } %t167, 1
  %t171 = mul i64 %t169, 1
  %t172 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t171)
  call void @llvm.memcpy.p0.p0.i64(ptr %t172, ptr %t170, i64 %t171, i1 false)
  %t173 = insertvalue { i64, ptr } undef, i64 %t169, 0
  %t174 = insertvalue { i64, ptr } %t173, ptr %t172, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l2, { i64, ptr } %t174)
  br label %bb47
bb47:
  %t177 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t177, ptr %l70
  br label %bb48
bb48:
  %t178 = load %"std/prelude/text:StringBuilder", ptr %l70
  store %"std/prelude/text:StringBuilder" %t178, ptr %l8
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l8, { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d113, i32 0, i32 1) })
  br label %bb49
bb49:
  %t180 = load { i64, ptr }, ptr %l0, !tbaa !27
  call void @compiler_2fsession_2eJsonStr(ptr %s0, ptr %v0, ptr %l8, { i64, ptr } %t180)
  br label %bb50
bb50:
  store ptr %l8, ptr %l74, !tbaa !29
  %t184 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l2)
  store { i64, ptr } %t184, ptr %l76
  br label %bb51
bb51:
  %t185 = load i32, ptr %l1, !tbaa !23
  %t187 = icmp ne i32 %t185, 0
  br i1 %t187, label %bb52, label %bb53
bb52:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d114, i32 0, i32 1) }, ptr %l79, !tbaa !27
  br label %bb54
bb53:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d115, i32 0, i32 1) }, ptr %l79, !tbaa !27
  br label %bb54
bb54:
  %t189 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d116, i32 0, i32 1) }, 1
  %t190 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d116, i32 0, i32 1) }, 0
  %t191 = load { i64, ptr }, ptr %l76, !tbaa !27
  %t192 = extractvalue { i64, ptr } %t191, 1
  %t193 = extractvalue { i64, ptr } %t191, 0
  %t194 = add i64 %t190, %t193
  %t195 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d117, i32 0, i32 1) }, 1
  %t196 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d117, i32 0, i32 1) }, 0
  %t197 = add i64 %t194, %t196
  %t198 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t199 = extractvalue { i64, ptr } %t198, 1
  %t200 = extractvalue { i64, ptr } %t198, 0
  %t201 = add i64 %t197, %t200
  %t202 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d118, i32 0, i32 1) }, 1
  %t203 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d118, i32 0, i32 1) }, 0
  %t204 = add i64 %t201, %t203
  %t205 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t204)
  call void @olang_textcopy(ptr %t205, ptr %t189, i64 %t190)
  %t206 = getelementptr i8, ptr %t205, i64 %t190
  call void @olang_textcopy(ptr %t206, ptr %t192, i64 %t193)
  %t207 = getelementptr i8, ptr %t206, i64 %t193
  call void @olang_textcopy(ptr %t207, ptr %t195, i64 %t196)
  %t208 = getelementptr i8, ptr %t207, i64 %t196
  call void @olang_textcopy(ptr %t208, ptr %t199, i64 %t200)
  %t209 = getelementptr i8, ptr %t208, i64 %t200
  call void @olang_textcopy(ptr %t209, ptr %t202, i64 %t203)
  %t210 = insertvalue { i64, ptr } undef, i64 %t204, 0
  %t211 = insertvalue { i64, ptr } %t210, ptr %t205, 1
  %t213 = extractvalue { i64, ptr } %t211, 0
  %t214 = extractvalue { i64, ptr } %t211, 1
  %t215 = mul i64 %t213, 1
  %t216 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t215)
  call void @llvm.memcpy.p0.p0.i64(ptr %t216, ptr %t214, i64 %t215, i1 false)
  %t217 = insertvalue { i64, ptr } undef, i64 %t213, 0
  %t218 = insertvalue { i64, ptr } %t217, ptr %t216, 1
  %t219 = load ptr, ptr %l74, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t219, { i64, ptr } %t218)
  br label %bb55
bb55:
  %t222 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l8)
  store { i64, ptr } %t222, ptr %l83
  br label %bb56
bb56:
  %t223 = load { i64, ptr }, ptr %l83, !tbaa !27
  store { i64, ptr } %t223, ptr %l84, !tbaa !27
  %t224 = load { i64, ptr }, ptr %l84, !tbaa !27
  %t225 = extractvalue { i64, ptr } %t224, 0
  store i64 %t225, ptr %l85, !tbaa !24
  %t226 = load i64, ptr %l85, !tbaa !24
  %t227 = mul i64 %t226, 1
  %t228 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t227)
  %t229 = insertvalue { i64, ptr } undef, i64 %t226, 0
  %t230 = insertvalue { i64, ptr } %t229, ptr %t228, 1
  store { i64, ptr } %t230, ptr %l86, !tbaa !27
  %t231 = getelementptr { i64, ptr }, ptr %l86, i32 0, i32 1
  %t232 = load ptr, ptr %t231, !tbaa !27
  %t233 = getelementptr { i64, ptr }, ptr %l84, i32 0, i32 1
  %t234 = load ptr, ptr %t233, !tbaa !27
  %t235 = load i64, ptr %l85, !tbaa !24
  %t236 = mul i64 %t235, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t232, ptr %t234, i64 %t236, i1 false)
  %t237 = load { i64, ptr }, ptr %l86, !tbaa !27
  store { i64, ptr } %t237, ptr %l84, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t238 = load { i64, ptr }, ptr %l84, !tbaa !27
  store { i64, ptr } %t238, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fmcp_2etextResult(ptr %v0, ptr %v1, { i64, ptr } %a0, i1 %a1) #0 {
entry:
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca %"std/prelude/text:StringBuilder"
  %l7 = alloca ptr
  %l9 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l3
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l3
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l2, { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d119, i32 0, i32 1) })
  br label %bb2
bb2:
  call void @compiler_2fsession_2eJsonStr(ptr %s0, ptr %v0, ptr %l2, { i64, ptr } %a0)
  br label %bb3
bb3:
  store ptr %l2, ptr %l7, !tbaa !29
  br i1 %a1, label %bb4, label %bb5
bb4:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d120, i32 0, i32 1) }, ptr %l9, !tbaa !27
  br label %bb6
bb5:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d121, i32 0, i32 1) }, ptr %l9, !tbaa !27
  br label %bb6
bb6:
  %t9 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d122, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d122, i32 0, i32 1) }, 0
  %t11 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t11, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = add i64 %t10, %t13
  %t15 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d123, i32 0, i32 1) }, 1
  %t16 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d123, i32 0, i32 1) }, 0
  %t17 = add i64 %t14, %t16
  %t18 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t17)
  call void @olang_textcopy(ptr %t18, ptr %t9, i64 %t10)
  %t19 = getelementptr i8, ptr %t18, i64 %t10
  call void @olang_textcopy(ptr %t19, ptr %t12, i64 %t13)
  %t20 = getelementptr i8, ptr %t19, i64 %t13
  call void @olang_textcopy(ptr %t20, ptr %t15, i64 %t16)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t18, 1
  %t24 = extractvalue { i64, ptr } %t22, 0
  %t25 = extractvalue { i64, ptr } %t22, 1
  %t26 = mul i64 %t24, 1
  %t27 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t26)
  call void @llvm.memcpy.p0.p0.i64(ptr %t27, ptr %t25, i64 %t26, i1 false)
  %t28 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t27, 1
  %t30 = load ptr, ptr %l7, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t30, { i64, ptr } %t29)
  br label %bb7
bb7:
  %t33 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t33, ptr %l13
  br label %bb8
bb8:
  %t34 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t34, ptr %l14, !tbaa !27
  %t35 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t36 = extractvalue { i64, ptr } %t35, 0
  store i64 %t36, ptr %l15, !tbaa !24
  %t37 = load i64, ptr %l15, !tbaa !24
  %t38 = mul i64 %t37, 1
  %t39 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t38)
  %t40 = insertvalue { i64, ptr } undef, i64 %t37, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t39, 1
  store { i64, ptr } %t41, ptr %l16, !tbaa !27
  %t42 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = load i64, ptr %l15, !tbaa !24
  %t47 = mul i64 %t46, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t43, ptr %t45, i64 %t47, i1 false)
  %t48 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t48, ptr %l14, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t49 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t49, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fmcp_2etoolError(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call { i64, ptr } @compiler_2fmcp_2etextResult(ptr %v0, ptr %v1, { i64, ptr } %a0, i1 true)
  store { i64, ptr } %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t4, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
declare void @__olang_ert_req_clear()
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d0 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d1 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"file" }>, align 8
@.d2 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"test" }>, align 8
@.d3 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d4 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"test needs a file" }>, align 8
@.d5 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"test" }>, align 8
@.d6 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d7 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d8 = private constant <{ i64, [29 x i8] }> <{ i64 0, [29 x i8] c"the compiler could not be run" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d9 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"explain" }>, align 8
@.d10 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d11 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"name" }>, align 8
@.d12 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"explain" }>, align 8
@.d13 = private constant <{ i64, [29 x i8] }> <{ i64 0, [29 x i8] c"the compiler could not be run" }>, align 8
@.d14 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"check" }>, align 8
@.d15 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"explain" }>, align 8
@.d16 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"doc" }>, align 8
@.d17 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"format" }>, align 8
@.d18 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"no tool " }>, align 8
@.d19 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d20 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c" needs a file" }>, align 8
@.d21 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"text" }>, align 8
@.d22 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"text" }>, align 8
@.d23 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"name" }>, align 8
define available_externally void @__olang_scope_escape(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %un = icmp eq ptr %o, null
  br i1 %un, label %claim, label %done
claim:
  %me = load ptr, ptr @__olang_self
  store atomic ptr %me, ptr %op monotonic, align 8
  br label %done
done:
  ret void
}
define internal { i64, ptr } @olang_lambda_24(ptr %env, ptr %v0) #0 {
entry:
  %l12 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  %cp0 = getelementptr { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load { i64, ptr }, ptr %cp0, !tbaa !28
  %cp1 = getelementptr { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 1
  %cv1 = load { i64, ptr }, ptr %cp1, !tbaa !28
  %cp2 = getelementptr { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 2
  %cv2 = load i1, ptr %cp2, !tbaa !28
  %cp3 = getelementptr { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 3
  %cv3 = load { i64, ptr }, ptr %cp3, !tbaa !28
  %cp4 = getelementptr { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 4
  %cv4 = load { i64, ptr }, ptr %cp4, !tbaa !28
  %cp5 = getelementptr { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 5
  %cv5 = load ptr, ptr %cp5, !tbaa !28
  %vq0 = getelementptr { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 6
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  %vq1 = getelementptr { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 7
  %vr1 = load ptr, ptr %vq1, !tbaa !28
  %vc1 = call ptr @__olang_capture_scope(ptr %vr1)
  %vq2 = getelementptr { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 8
  %vr2 = load ptr, ptr %vq2, !tbaa !28
  %vc2 = call ptr @__olang_capture_scope(ptr %vr2)
  %vq3 = getelementptr { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 9
  %vr3 = load ptr, ptr %vq3, !tbaa !28
  %vc3 = call ptr @__olang_capture_scope(ptr %vr3)
  %vq4 = getelementptr { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 10
  %vr4 = load ptr, ptr %vq4, !tbaa !28
  %vc4 = call ptr @__olang_capture_scope(ptr %vr4)
  br label %start
start:
  br label %bb0
bb0:
  %t13 = call { i64, ptr } @compiler_2fmcp_2erun(ptr %vc0, ptr %vc1, ptr %vc2, ptr %vc3, ptr %vc4, ptr %v0, { i64, ptr } %cv0, { i64, ptr } %cv1, i1 %cv2, { i64, ptr } %cv3, { i64, ptr } %cv4, ptr %cv5)
  store { i64, ptr } %t13, ptr %l12
  br label %bb1
bb1:
  %t14 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t14, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d25 = private constant <{ i64, [33 x i8] }> <{ i64 0, [33 x i8] c"the compiler ended while running " }>, align 8
@.d26 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" (status " }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d27 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c") - a bug in the compiler" }>, align 8
@.d28 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"{\22diagnostics\22:[" }>, align 8
@.d29 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c",\22notes\22:[" }>, align 8
@.d30 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"]}" }>, align 8
@.d31 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"],\22errors\22:" }>, align 8
@.d32 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"}" }>, align 8
@.d33 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"no errors" }>, align 8
@.d34 = private constant <{ i64, [34 x i8] }> <{ i64 0, [34 x i8] c"{\22content\22:[{\22type\22:\22text\22,\22text\22:" }>, align 8
@.d35 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"}],\22structuredContent\22:" }>, align 8
@.d36 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c",\22isError\22:false}" }>, align 8
@.d37 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"OLANG" }>, align 8
@.d38 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d39 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d40 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"build/olang" }>, align 8
@.d41 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"{\22jsonrpc\22:\222.0\22,\22id\22:" }>, align 8
@.d42 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c",\22error\22:{\22code\22:" }>, align 8
@.d43 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c",\22message\22:" }>, align 8
@.d44 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"}}" }>, align 8
@.d45 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"null" }>, align 8
@.d46 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"the message is not JSON" }>, align 8
@.d47 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"method" }>, align 8
@.d48 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"initialize" }>, align 8
@.d49 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"params" }>, align 8
@.d50 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"protocolVersion" }>, align 8
@.d51 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"2025-06-18" }>, align 8
@.d52 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"{\22protocolVersion\22:" }>, align 8
@.d53 = private constant <{ i64, [92 x i8] }> <{ i64 0, [92 x i8] c",\22capabilities\22:{\22tools\22:{\22listChanged\22:false}},\22serverInfo\22:{\22name\22:\22olang\22,\22version\22:\220\22}," }>, align 8
@.d54 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"\22instructions\22:" }>, align 8
@.d55 = private constant <{ i64, [87 x i8] }> <{ i64 0, [87 x i8] c"Tools for the olang language: check a file's diagnostics, explain an item or a rule, a " }>, align 8
@.d56 = private constant <{ i64, [91 x i8] }> <{ i64 0, [91 x i8] c"module's documentation, format, and run a file's tests. Paths are relative to the server's " }>, align 8
@.d57 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"working directory." }>, align 8
@.d58 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d59 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"ping" }>, align 8
@.d60 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"{}" }>, align 8
@.d61 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"tools/list" }>, align 8
@.d62 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"{\22tools\22:" }>, align 8
@.d63 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"}" }>, align 8
@.d64 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"tools/call" }>, align 8
@.d65 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"params" }>, align 8
@.d66 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"name" }>, align 8
@.d67 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d68 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"params" }>, align 8
@.d69 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"arguments" }>, align 8
@.d70 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"olang mcp has no " }>, align 8
@.d71 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"id" }>, align 8
@.d72 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d73 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d74 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"{\22file\22:" }>, align 8
@.d75 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d76 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c",\22line\22:" }>, align 8
@.d77 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c",\22column\22:" }>, align 8
@.d78 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c",\22endLine\22:" }>, align 8
@.d79 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c",\22endColumn\22:" }>, align 8
@.d80 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c",\22line\22:" }>, align 8
@.d81 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d82 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c",\22rule\22:" }>, align 8
@.d83 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c",\22message\22:" }>, align 8
@.d84 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"{\22jsonrpc\22:\222.0\22,\22id\22:" }>, align 8
@.d85 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c",\22result\22:" }>, align 8
@.d86 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"}" }>, align 8
@.d87 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"doc" }>, align 8
@.d88 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c".olang" }>, align 8
@.d89 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"format" }>, align 8
@.d90 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"cannot read " }>, align 8
@.d91 = private constant <{ i64, [46 x i8] }> <{ i64 0, [46 x i8] c" does not parse - check it for its diagnostics" }>, align 8
@.d92 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"check" }>, align 8
@.d93 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"explain" }>, align 8
declare void @__olang_check_failed(ptr) cold noreturn
@.d94 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d95 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"' is no top-level item of " }>, align 8
@.d96 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d97 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d98 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"' is no item of " }>, align 8
@.d99 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d100 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d101 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"{\22tests\22:[" }>, align 8
@.d102 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"ok - " }>, align 8
@.d103 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"FAIL - " }>, align 8
@.d104 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"{\22name\22:" }>, align 8
@.d105 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"true" }>, align 8
@.d106 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"false" }>, align 8
@.d107 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c",\22passed\22:" }>, align 8
@.d108 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"}" }>, align 8
@.d109 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"],\22passed\22:" }>, align 8
@.d110 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c",\22failed\22:" }>, align 8
@.d111 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c",\22status\22:" }>, align 8
@.d112 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"}" }>, align 8
@.d113 = private constant <{ i64, [34 x i8] }> <{ i64 0, [34 x i8] c"{\22content\22:[{\22type\22:\22text\22,\22text\22:" }>, align 8
@.d114 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"true" }>, align 8
@.d115 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"false" }>, align 8
@.d116 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"}],\22structuredContent\22:" }>, align 8
@.d117 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c",\22isError\22:" }>, align 8
@.d118 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"}" }>, align 8
@.d119 = private constant <{ i64, [34 x i8] }> <{ i64 0, [34 x i8] c"{\22content\22:[{\22type\22:\22text\22,\22text\22:" }>, align 8
@.d120 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"true" }>, align 8
@.d121 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"false" }>, align 8
@.d122 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"}],\22isError\22:" }>, align 8
@.d123 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"}" }>, align 8
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@__olang_self = external thread_local(initialexec) global ptr
define available_externally ptr @__olang_capture_scope(ptr %s) alwaysinline {
entry:
  %isprog = icmp eq ptr %s, null
  br i1 %isprog, label %prog, label %mine
prog:
  %p = load ptr, ptr @__olang_prog_scope
  ret ptr %p
mine:
  %m = call ptr @__olang_scope_mine(ptr %s)
  ret ptr %m
}
@__olang_prog_scope = external thread_local(initialexec) global ptr
define available_externally ptr @__olang_scope_mine(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %me = load ptr, ptr @__olang_self
  %own = icmp eq ptr %o, %me
  br i1 %own, label %mine, label %slow
mine:
  ret ptr %s
slow:
  %r = call ptr @__olang_scope_mine_slow(ptr %s)
  ret ptr %r
}
declare ptr @__olang_scope_mine_slow(ptr) noinline
declare void @compiler_2fsession_2eIgnoreBrokenPipes()
declare %"compiler/session:Reader" @compiler_2fsession_3aReader_2ector(ptr %v0, i32 %a0)
declare i1 @compiler_2fsession_2ecompiler_2fsession_3aReader_2eFill(ptr %v0, ptr %a0)
declare { i32, { i64, ptr } } @compiler_2fsession_2ecompiler_2fsession_3aReader_2eNextLine(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i32, %"std/os:Output" } @std_2fos_2eExec(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, i1 %a2, { i64, ptr } %a3)
declare { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAt_3cstd_2fprelude_2ftext_3aString_3e(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { { i64, ptr }, i32 } @compiler_2fsession_2eChildOutput(ptr %v0, ptr %v1, ptr %a0c, ptr %a0e)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eItems(ptr %v0, ptr %v1, ptr %a0)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3aItem_3e_2eLen_3ccompiler_2fdiag_3aItem_3e(ptr %v0, ptr %a0)
declare %"compiler/diag:Item" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3aItem_3e_2eAt_3ccompiler_2fdiag_3aItem_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eRender(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eSummary(ptr %v0, ptr %v1, ptr %a0)
declare void @compiler_2fsession_2eJsonStr(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, ptr } @std_2fjson_2eParse(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, ptr %a1)
declare { i32, { i64, ptr } } @std_2fjson_2estd_2fjson_3aJson_2eAsStr(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @std_2fjson_2eEncode_3cstd_2fjson_3aJson_26_3e(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2)
declare { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2ePathOf(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eTextOf(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/session:Positions" @compiler_2fsession_3aPositions_2ector(ptr %v0, ptr %v1, { i64, ptr } %a0, i1 %a1)
declare { i64, i64 } @compiler_2fsession_2ecompiler_2fsession_3aPositions_2ePos(ptr %v0, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fsession_2eStdModule(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
declare { i64, ptr } @compiler_2fsession_2eRealOf(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6f7a2f8d839c49b6e7a19c287d4b190c(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @compiler_2fsession_2eFormat(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @compiler_2fdiag_3aDiagnostics_2ector(ptr %out, ptr %v0, i1 %a0)
declare ptr @compiler_2fsession_2eAnalyze(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, ptr %a1, ptr %a2, ptr %a3, i1 %a4)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v0, ptr %a0)
@olang_loc_308bbd8a0e283fc3_2a8ec4cf6bdf47df = external constant [0 x i8]
declare { i32, { i64, ptr } } @compiler_2fexplain_2eItem(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, i64 %a3, { i64, ptr } %a4)
@olang_loc_fd6ee713b6cd3a34_3a725fec10b02c40 = external constant [0 x i8]
declare { i32, { i64, ptr } } @compiler_2fdoc_2eItemText(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, i64 %a3, { i64, ptr } %a4)
@olang_loc_bf544a52d5413c29_9c9e72e4a09cc655 = external constant [0 x i8]
declare %"compiler/doc:Module" @compiler_2fdoc_2eOf(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, i64 %a3, i1 %a4)
declare { i64, ptr } @compiler_2fdoc_2ecompiler_2fdoc_3aModule_2eText(ptr %v0, ptr %v1, ptr %a0)
declare i32 @std_2fio_2eWrite(ptr %v0, i32 %a0, { i64, ptr } %a1)
declare { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAt_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %v1, ptr %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_8d8cf657aed96bef_7cd13aec667ffb8b = external constant [0 x i8]

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
