; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/emit:Emitter" = type { ptr, ptr, ptr, ptr, i1, i1, i1, i1, { i64, ptr }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, i64, i1, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i64, i64, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, i1, i1, { i64, ptr }, i1, i64, i64, i64, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/generic:AnyTable" = type { i32, i32, i32, i64, %"compiler/source:Span", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/source:Span" = type { i32, i32 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/types:Table" = type { ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1 }
%"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64 }
%"compiler/cabi:Way" = type { i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr } }
%"compiler/lower:Lowerer" = type { ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i32, i32 }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1 }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1, i1 }
%"compiler/cabi:Regs" = type { i64, i64 }
%"compiler/mir:Fn" = type { { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i64 }
%"compiler/emit:fnEm" = type { ptr, ptr, { i64, [2 x i64] }, %"std/prelude/text:StringBuilder", %"std/prelude/text:StringBuilder", %"std/prelude/text:StringBuilder", i64, i64, i64, i32, i1, i1, i1, i1, { i64, ptr }, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, { i64, ptr }, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/text:StringBuilder", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, { i64, ptr } }
%"compiler/ast:TopIf" = type { ptr, ptr, ptr, ptr }
%"compiler/ast:TopBranch" = type { %"compiler/source:Span", { i64, ptr }, i64 }
%"compiler/eval:Image" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/eval:Blob" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce" = type { ptr, i64, ptr, ptr }
%"std/prelude/map:MapEntry.eb00e4a6e4307a4e46e40fbcd79d6b4f" = type { i64, i1 }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, ptr, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/mir:Place" = type { { i64, [2 x i64] }, %"compiler/mir:Range" }
%"compiler/mir:Range" = type { i32, i32 }
%"compiler/mir:BasicBlock" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, [8 x i64] } }
%"compiler/mir:ScopeInfo" = type { i32, i32, i32, %"compiler/source:Span", i32 }
%"compiler/emit:Reused" = type { i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64 }
define dso_local void @compiler_2femit_2ePartSize_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 1048576, ptr @G_2ecompiler_2femit_2ePartSize, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eabiDiffers(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l14 = alloca i1
  %l16 = alloca i1
  %l19 = alloca i32
  %l22 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %a0, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load ptr, ptr %l3, !tbaa !29
  %t7 = load i32, ptr %l1, !tbaa !23
  %t10 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRetLlvm(ptr %v0, ptr %s0, ptr %t6, i32 %t7)
  store { i64, ptr } %t10, ptr %l8
  br label %bb1
bb1:
  %t11 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t11, 0
  %t13 = extractvalue { i64, ptr } %t11, 1
  %t14 = mul i64 %t12, 1
  %t15 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t14)
  call void @llvm.memcpy.p0.p0.i64(ptr %t15, ptr %t13, i64 %t14, i1 false)
  %t16 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t15, 1
  store { i64, ptr } %t17, ptr %l9, !tbaa !27
  %t18 = load ptr, ptr %l3, !tbaa !29
  %t19 = load i32, ptr %l2, !tbaa !23
  %t22 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRetLlvm(ptr %v0, ptr %s0, ptr %t18, i32 %t19)
  store { i64, ptr } %t22, ptr %l12
  br label %bb2
bb2:
  %t23 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t23, 0
  %t25 = extractvalue { i64, ptr } %t23, 1
  %t26 = mul i64 %t24, 1
  %t27 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t26)
  call void @llvm.memcpy.p0.p0.i64(ptr %t27, ptr %t25, i64 %t26, i1 false)
  %t28 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t27, 1
  %t30 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t32 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t30, { i64, ptr } %t29)
  store i1 %t32, ptr %l14
  br label %bb3
bb3:
  %t33 = load i1, ptr %l14, !tbaa !21
  %t34 = xor i1 %t33, true
  br i1 %t34, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb8
bb5:
  %t36 = load ptr, ptr %l3, !tbaa !29
  %t37 = load i32, ptr %l1, !tbaa !23
  %t40 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t36, i32 %t37)
  store i32 %t40, ptr %l19
  br label %bb6
bb6:
  %t41 = load ptr, ptr %l3, !tbaa !29
  %t42 = load i32, ptr %l2, !tbaa !23
  %t45 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t41, i32 %t42)
  store i32 %t45, ptr %l22
  br label %bb7
bb7:
  %t46 = load i32, ptr %l19, !tbaa !23
  %t47 = load i32, ptr %l22, !tbaa !23
  %t48 = icmp ne i32 %t46, %t47
  store i1 %t48, ptr %l16, !tbaa !21
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s0)
  %t50 = load i1, ptr %l16, !tbaa !21
  store i1 %t50, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eanyTable(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %lp2 = alloca ptr
  %l3 = alloca %"compiler/generic:AnyTable"
  %l4 = alloca %"std/prelude/text:StringBuilder"
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca { i64, [2 x i64] }
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l16 = alloca { i64, [2 x i64] }
  %l20 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l26 = alloca i1
  %l32 = alloca %"compiler/generic:AnyTable"
  %l33 = alloca %"std/prelude/text:StringBuilder"
  %l34 = alloca ptr
  %l37 = alloca { i64, ptr }
  %l56 = alloca ptr
  %l59 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %l68 = alloca { i64, ptr }
  %l69 = alloca i32
  %l78 = alloca { i64, ptr }
  %l87 = alloca ptr
  %l90 = alloca { i64, ptr }
  %l99 = alloca i64
  %l102 = alloca ptr
  %l103 = alloca { i64, ptr }
  %l104 = alloca i64
  %l105 = alloca { i64, ptr }
  %l106 = alloca i64
  %l108 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t101 = alloca { i64, [2 x i64] }, align 8
  %t184 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etableName(ptr %v0, ptr %s0, ptr %t1, i64 %t2)
  store { i64, ptr } %t5, ptr %l20
  br label %bb1
bb1:
  %t6 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d0, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d0, i32 0, i32 1) }, 0
  %t8 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t8, 1
  %t10 = extractvalue { i64, ptr } %t8, 0
  %t11 = add i64 %t7, %t10
  %t12 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t11)
  call void @olang_textcopy(ptr %t12, ptr %t6, i64 %t7)
  %t13 = getelementptr i8, ptr %t12, i64 %t7
  call void @olang_textcopy(ptr %t13, ptr %t9, i64 %t10)
  %t14 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t12, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t24 = call { i64, ptr } @compiler_2ftypes_2eSymbol(ptr %v1, ptr %v1, { i64, ptr } %t22)
  store { i64, ptr } %t24, ptr %l23
  br label %bb2
bb2:
  %t25 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t25, ptr %lp2
  %t26 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t27 = load ptr, ptr %lp2
  store { i64, ptr } %t26, ptr %t27, !tbaa !27
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load ptr, ptr %lp2
  %t30 = load { i64, ptr }, ptr %t29, !tbaa !27
  %t33 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ehas(ptr %v0, ptr %v1, ptr %t28, { i64, ptr } %t30)
  store i1 %t33, ptr %l26
  br label %bb3
bb3:
  %t34 = load i1, ptr %l26, !tbaa !21
  br i1 %t34, label %bb4, label %bb5
bb4:
  %t35 = load ptr, ptr %lp2
  %t36 = load { i64, ptr }, ptr %t35, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t36, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/emit:Emitter", ptr %t38, i32 0, i32 0
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t43 = getelementptr %"compiler/generic:Program", ptr %t41, i32 0, i32 40
  %t44 = load i64, ptr %l1, !tbaa !24
  %t47 = call %"compiler/generic:AnyTable" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fgeneric_3aAnyTable_3e_2e_H5e3c685c1de22cee1b092c35d74f13cd(ptr %v0, ptr %v0, ptr %t43, i64 %t44)
  store %"compiler/generic:AnyTable" %t47, ptr %l32
  br label %bb7
bb7:
  %t48 = load %"compiler/generic:AnyTable", ptr %l32
  store %"compiler/generic:AnyTable" %t48, ptr %l3
  %t49 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t49, ptr %l33
  br label %bb8
bb8:
  %t50 = load %"std/prelude/text:StringBuilder", ptr %l33
  store %"std/prelude/text:StringBuilder" %t50, ptr %l4
  store ptr %l4, ptr %l34, !tbaa !29
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/generic:AnyTable", ptr %l3, i32 0, i32 0
  %t53 = load i32, ptr %t52, !tbaa !23
  %t56 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etypeid(ptr %v0, ptr %s0, ptr %t51, i32 %t53)
  store { i64, ptr } %t56, ptr %l37
  br label %bb9
bb9:
  %t57 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d1, i32 0, i32 1) }, 1
  %t58 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d1, i32 0, i32 1) }, 0
  %t59 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t60 = extractvalue { i64, ptr } %t59, 1
  %t61 = extractvalue { i64, ptr } %t59, 0
  %t62 = add i64 %t58, %t61
  %t63 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t62)
  call void @olang_textcopy(ptr %t63, ptr %t57, i64 %t58)
  %t64 = getelementptr i8, ptr %t63, i64 %t58
  call void @olang_textcopy(ptr %t64, ptr %t60, i64 %t61)
  %t65 = insertvalue { i64, ptr } undef, i64 %t62, 0
  %t66 = insertvalue { i64, ptr } %t65, ptr %t63, 1
  %t68 = extractvalue { i64, ptr } %t66, 0
  %t69 = extractvalue { i64, ptr } %t66, 1
  %t70 = mul i64 %t68, 1
  %t71 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t70)
  call void @llvm.memcpy.p0.p0.i64(ptr %t71, ptr %t69, i64 %t70, i1 false)
  %t72 = insertvalue { i64, ptr } undef, i64 %t68, 0
  %t73 = insertvalue { i64, ptr } %t72, ptr %t71, 1
  %t74 = load ptr, ptr %l34, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t74, { i64, ptr } %t73)
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s4
  %t76 = insertvalue [2 x i1] undef, i1 false, 0
  %t77 = insertvalue [2 x i1] %t76, i1 true, 1
  %t79 = call ptr @__olang_scope_alloc_a(ptr %s4, i64 2, i64 8)
  store [2 x i1] %t77, ptr %t79
  store ptr %t79, ptr %l5
  store i64 0, ptr %l6, !tbaa !24
  %t81 = load ptr, ptr %l5
  store i64 2, ptr %l7, !tbaa !24
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s5
  %t84 = load i64, ptr %l6, !tbaa !24
  %t85 = load i64, ptr %l7, !tbaa !24
  %t88 = icmp slt i64 %t84, %t85
  %t90 = xor i1 %t88, true
  br i1 %t90, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s5)
  br label %bb19
bb13:
  br label %bb14
bb14:
  %t92 = load ptr, ptr %l5
  %t93 = load i64, ptr %l6, !tbaa !24
  %t96 = getelementptr [2 x i1], ptr %t92, i64 0, i64 %t93
  %t97 = load i1, ptr %t96, !tbaa !31
  %t99 = load i64, ptr %l1, !tbaa !24
  store { i64, [2 x i64] } zeroinitializer, ptr %t101
  %t102 = getelementptr { i64, [2 x i64] }, ptr %t101, i32 0, i32 0
  store i64 4, ptr %t102
  %t104 = insertvalue { i64, i1 } undef, i64 %t99, 0
  %t106 = insertvalue { i64, i1 } %t104, i1 %t97, 1
  %t107 = getelementptr { i64, [2 x i64] }, ptr %t101, i32 0, i32 1
  store { i64, i1 } %t106, ptr %t107
  %t108 = load { i64, [2 x i64] }, ptr %t101
  store { i64, [2 x i64] } %t108, ptr %l9
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t111 = load { i64, [2 x i64] }, ptr %l9
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2ewant(ptr %v0, ptr %t110, { i64, [2 x i64] } %t111)
  br label %bb15
bb15:
  store ptr %l4, ptr %l56, !tbaa !29
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t115 = load { i64, [2 x i64] }, ptr %l9
  %t118 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2esym(ptr %v0, ptr %s5, ptr %t114, { i64, [2 x i64] } %t115)
  store { i64, ptr } %t118, ptr %l59
  br label %bb16
bb16:
  %t119 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d2, i32 0, i32 1) }, 1
  %t120 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d2, i32 0, i32 1) }, 0
  %t121 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t122 = extractvalue { i64, ptr } %t121, 1
  %t123 = extractvalue { i64, ptr } %t121, 0
  %t124 = add i64 %t120, %t123
  %t125 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t124)
  call void @olang_textcopy(ptr %t125, ptr %t119, i64 %t120)
  %t126 = getelementptr i8, ptr %t125, i64 %t120
  call void @olang_textcopy(ptr %t126, ptr %t122, i64 %t123)
  %t127 = insertvalue { i64, ptr } undef, i64 %t124, 0
  %t128 = insertvalue { i64, ptr } %t127, ptr %t125, 1
  %t130 = extractvalue { i64, ptr } %t128, 0
  %t131 = extractvalue { i64, ptr } %t128, 1
  %t132 = mul i64 %t130, 1
  %t133 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t132)
  call void @llvm.memcpy.p0.p0.i64(ptr %t133, ptr %t131, i64 %t132, i1 false)
  %t134 = insertvalue { i64, ptr } undef, i64 %t130, 0
  %t135 = insertvalue { i64, ptr } %t134, ptr %t133, 1
  %t136 = load ptr, ptr %l56, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s5, ptr %t136, { i64, ptr } %t135)
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s5)
  br label %bb18
bb18:
  %t138 = load i64, ptr %l6, !tbaa !24
  %t140 = add i64 %t138, 1
  store i64 %t140, ptr %l6, !tbaa !24
  br label %bb11
bb19:
  call void @__olang_scope_close(ptr %s4)
  %t142 = getelementptr %"compiler/generic:AnyTable", ptr %l3, i32 0, i32 5
  store ptr %t142, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  br label %bb20
bb20:
  store %olang.scope zeroinitializer, ptr %s9
  %t144 = load ptr, ptr %l10, !tbaa !29
  %t145 = load i64, ptr %l11, !tbaa !24
  %t148 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v0, ptr %t144, i64 %t145)
  %t149 = extractvalue { i32, { i64, ptr } } %t148, 1
  %t150 = extractvalue { i32, { i64, ptr } } %t148, 0
  store i32 %t150, ptr %l69
  %t151 = icmp ne i32 %t150, 0
  br i1 %t151, label %bb22, label %ok.152
ok.152:
  store { i64, ptr } %t149, ptr %l68
  br label %bb21
bb21:
  %t153 = load { i64, ptr }, ptr %l68, !tbaa !27
  store { i64, ptr } %t153, ptr %l65, !tbaa !27
  br label %bb26
bb22:
  %t154 = load i32, ptr %l69, !tbaa !23
  %t155 = ashr i32 %t154, 16
  %t157 = icmp eq i32 %t155, 1
  br i1 %t157, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_bb561cc43498cf8_4d9e3dd6da251fdc)
  unreachable
bb25:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s9)
  br label %bb37
bb26:
  %t159 = load { i64, ptr }, ptr %l65, !tbaa !27
  store { i64, ptr } %t159, ptr %l12, !tbaa !27
  %t160 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t162 = extractvalue { i64, ptr } %t160, 0
  store i64 %t162, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb27
bb27:
  store %olang.scope zeroinitializer, ptr %s10
  %t164 = load i64, ptr %l14, !tbaa !24
  %t165 = load i64, ptr %l13, !tbaa !24
  %t168 = icmp slt i64 %t164, %t165
  %t170 = xor i1 %t168, true
  br i1 %t170, label %bb28, label %bb29
bb28:
  call void @__olang_scope_close(ptr %s10)
  br label %bb35
bb29:
  br label %bb30
bb30:
  %t172 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t172, ptr %l78, !tbaa !27
  %t173 = load i64, ptr %l14, !tbaa !24
  %t175 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t176 = load ptr, ptr %t175, !tbaa !27
  %t177 = getelementptr i64, ptr %t176, i64 %t173
  %t178 = load i64, ptr %t177, !tbaa !34
  %t182 = trunc i64 %t178 to i32
  store { i64, [2 x i64] } zeroinitializer, ptr %t184
  %t185 = getelementptr { i64, [2 x i64] }, ptr %t184, i32 0, i32 0
  store i64 0, ptr %t185
  %t187 = insertvalue { i32 } undef, i32 %t182, 0
  %t188 = getelementptr { i64, [2 x i64] }, ptr %t184, i32 0, i32 1
  store { i32 } %t187, ptr %t188
  %t189 = load { i64, [2 x i64] }, ptr %t184
  store { i64, [2 x i64] } %t189, ptr %l16
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t192 = load { i64, [2 x i64] }, ptr %l16
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2ewant(ptr %v0, ptr %t191, { i64, [2 x i64] } %t192)
  br label %bb31
bb31:
  store ptr %l4, ptr %l87, !tbaa !29
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t196 = load { i64, [2 x i64] }, ptr %l16
  %t199 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2esym(ptr %v0, ptr %s10, ptr %t195, { i64, [2 x i64] } %t196)
  store { i64, ptr } %t199, ptr %l90
  br label %bb32
bb32:
  %t200 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d3, i32 0, i32 1) }, 1
  %t201 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d3, i32 0, i32 1) }, 0
  %t202 = load { i64, ptr }, ptr %l90, !tbaa !27
  %t203 = extractvalue { i64, ptr } %t202, 1
  %t204 = extractvalue { i64, ptr } %t202, 0
  %t205 = add i64 %t201, %t204
  %t206 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t205)
  call void @olang_textcopy(ptr %t206, ptr %t200, i64 %t201)
  %t207 = getelementptr i8, ptr %t206, i64 %t201
  call void @olang_textcopy(ptr %t207, ptr %t203, i64 %t204)
  %t208 = insertvalue { i64, ptr } undef, i64 %t205, 0
  %t209 = insertvalue { i64, ptr } %t208, ptr %t206, 1
  %t211 = extractvalue { i64, ptr } %t209, 0
  %t212 = extractvalue { i64, ptr } %t209, 1
  %t213 = mul i64 %t211, 1
  %t214 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t213)
  call void @llvm.memcpy.p0.p0.i64(ptr %t214, ptr %t212, i64 %t213, i1 false)
  %t215 = insertvalue { i64, ptr } undef, i64 %t211, 0
  %t216 = insertvalue { i64, ptr } %t215, ptr %t214, 1
  %t217 = load ptr, ptr %l87, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s10, ptr %t217, { i64, ptr } %t216)
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s10)
  br label %bb34
bb34:
  %t219 = load i64, ptr %l14, !tbaa !24
  %t221 = add i64 %t219, 1
  store i64 %t221, ptr %l14, !tbaa !24
  br label %bb27
bb35:
  %t223 = load i64, ptr %l11, !tbaa !24
  %t224 = load i64, ptr %l13, !tbaa !24
  %t227 = add i64 %t223, %t224
  store i64 %t227, ptr %l11, !tbaa !24
  call void @__olang_scope_close(ptr %s9)
  br label %bb36
bb36:
  br label %bb20
bb37:
  %t229 = getelementptr %"compiler/generic:AnyTable", ptr %l3, i32 0, i32 5
  %t231 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t229)
  store i64 %t231, ptr %l99
  br label %bb38
bb38:
  %t232 = load i64, ptr @G_2ecompiler_2ftypes_2eAnySlotBase, !tbaa !24
  %t233 = load i64, ptr %l99, !tbaa !24
  %t235 = add i64 %t233, %t232
  %t237 = load ptr, ptr %l0, !tbaa !29
  store ptr %t237, ptr %l102, !tbaa !29
  %t238 = load ptr, ptr %lp2
  %t239 = load { i64, ptr }, ptr %t238, !tbaa !27
  store { i64, ptr } %t239, ptr %l103, !tbaa !27
  %t240 = load i64, ptr @G_2ecompiler_2femit_2eHomeShared, !tbaa !24
  store i64 %t240, ptr %l104, !tbaa !24
  %t241 = load ptr, ptr %lp2
  %t242 = load { i64, ptr }, ptr %t241, !tbaa !27
  store { i64, ptr } %t242, ptr %l105, !tbaa !27
  store i64 %t235, ptr %l106, !tbaa !24
  %t245 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l4)
  store { i64, ptr } %t245, ptr %l108
  br label %bb39
bb39:
  %t246 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d4, i32 0, i32 1) }, 1
  %t247 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d4, i32 0, i32 1) }, 0
  %t248 = load { i64, ptr }, ptr %l105, !tbaa !27
  %t249 = extractvalue { i64, ptr } %t248, 1
  %t250 = extractvalue { i64, ptr } %t248, 0
  %t251 = add i64 %t247, %t250
  %t252 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d5, i32 0, i32 1) }, 1
  %t253 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d5, i32 0, i32 1) }, 0
  %t254 = add i64 %t251, %t253
  %t255 = load i64, ptr %l106, !tbaa !24
  %t256 = call i64 @__olang_fmt_i64(ptr null, i64 %t255)
  %t257 = add i64 %t254, %t256
  %t258 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d6, i32 0, i32 1) }, 1
  %t259 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d6, i32 0, i32 1) }, 0
  %t260 = add i64 %t257, %t259
  %t261 = load { i64, ptr }, ptr %l108, !tbaa !27
  %t262 = extractvalue { i64, ptr } %t261, 1
  %t263 = extractvalue { i64, ptr } %t261, 0
  %t264 = add i64 %t260, %t263
  %t265 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d7, i32 0, i32 1) }, 1
  %t266 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d7, i32 0, i32 1) }, 0
  %t267 = add i64 %t264, %t266
  %t268 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t267)
  call void @olang_textcopy(ptr %t268, ptr %t246, i64 %t247)
  %t269 = getelementptr i8, ptr %t268, i64 %t247
  call void @olang_textcopy(ptr %t269, ptr %t249, i64 %t250)
  %t270 = getelementptr i8, ptr %t269, i64 %t250
  call void @olang_textcopy(ptr %t270, ptr %t252, i64 %t253)
  %t271 = getelementptr i8, ptr %t270, i64 %t253
  %t272 = call i64 @__olang_fmt_i64(ptr %t271, i64 %t255)
  %t273 = getelementptr i8, ptr %t271, i64 %t256
  call void @olang_textcopy(ptr %t273, ptr %t258, i64 %t259)
  %t274 = getelementptr i8, ptr %t273, i64 %t259
  call void @olang_textcopy(ptr %t274, ptr %t262, i64 %t263)
  %t275 = getelementptr i8, ptr %t274, i64 %t263
  call void @olang_textcopy(ptr %t275, ptr %t265, i64 %t266)
  %t276 = insertvalue { i64, ptr } undef, i64 %t267, 0
  %t277 = insertvalue { i64, ptr } %t276, ptr %t268, 1
  %t279 = extractvalue { i64, ptr } %t277, 0
  %t280 = extractvalue { i64, ptr } %t277, 1
  %t281 = mul i64 %t279, 1
  %t282 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t281)
  call void @llvm.memcpy.p0.p0.i64(ptr %t282, ptr %t280, i64 %t281, i1 false)
  %t283 = insertvalue { i64, ptr } undef, i64 %t279, 0
  %t284 = insertvalue { i64, ptr } %t283, ptr %t282, 1
  %t285 = load ptr, ptr %l102, !tbaa !29
  %t286 = load { i64, ptr }, ptr %l103, !tbaa !27
  %t287 = load i64, ptr %l104, !tbaa !24
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eitem(ptr %v0, ptr %v1, ptr %s0, ptr %s0, ptr %t285, { i64, ptr } %t286, i64 %t287, { i64, ptr } %t284, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d8, i32 0, i32 1) })
  br label %bb40
bb40:
  %t289 = load ptr, ptr %lp2
  %t290 = load { i64, ptr }, ptr %t289, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t290, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecHeader(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/cabi:Way"
  %l4 = alloca i32
  %l8 = alloca i32
  %l12 = alloca i1
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca { i64, ptr }
  %l23 = alloca i1
  %l29 = alloca %"compiler/cabi:Way"
  %l31 = alloca { i64, ptr }
  %l35 = alloca i1
  %l37 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l49 = alloca { i64, ptr }
  %l51 = alloca i64
  %l52 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t8 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t4, i32 %a1)
  store i32 %t8, ptr %l8
  br label %bb1
bb1:
  %t9 = load i32, ptr %l8, !tbaa !23
  store i32 %t9, ptr %l2, !tbaa !23
  %t10 = load i32, ptr %l2, !tbaa !23
  %t11 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t14 = icmp eq i32 %t10, %t11
  br i1 %t14, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb4
bb3:
  %t16 = load i32, ptr %l2, !tbaa !23
  %t17 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t20 = icmp eq i32 %t16, %t17
  store i1 %t20, ptr %l12, !tbaa !21
  br label %bb4
bb4:
  %t22 = load i1, ptr %l12, !tbaa !21
  br i1 %t22, label %bb5, label %bb6
bb5:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d9, i32 0, i32 1) }, ptr %l16, !tbaa !27
  %t23 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t23, ptr %l17, !tbaa !27
  %t24 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t24, 0
  store i64 %t25, ptr %l18, !tbaa !24
  %t26 = load i64, ptr %l18, !tbaa !24
  %t27 = mul i64 %t26, 1
  %t28 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t27)
  %t29 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t30 = insertvalue { i64, ptr } %t29, ptr %t28, 1
  store { i64, ptr } %t30, ptr %l19, !tbaa !27
  %t31 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = load i64, ptr %l18, !tbaa !24
  %t36 = mul i64 %t35, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t32, ptr %t34, i64 %t36, i1 false)
  %t37 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t37, ptr %l17, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t38 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t38, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/emit:Emitter", ptr %t39, i32 0, i32 0
  %t42 = load ptr, ptr %t41, !tbaa !29
  %t43 = load i32, ptr %l2, !tbaa !23
  %t46 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLayout(ptr %v0, ptr %t42, i32 %t43)
  store i1 %t46, ptr %l23
  br label %bb8
bb8:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/emit:Emitter", ptr %t47, i32 0, i32 3
  %t50 = load ptr, ptr %t49, !tbaa !29
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/emit:Emitter", ptr %t51, i32 0, i32 45
  %t54 = load { i64, ptr }, ptr %t53, !tbaa !27
  %t55 = load i32, ptr %l2, !tbaa !23
  %t59 = call %"compiler/cabi:Way" @compiler_2fcabi_2eResult(ptr %v0, ptr %v0, ptr %s0, ptr %t50, { i64, ptr } %t54, i32 %t55)
  store %"compiler/cabi:Way" %t59, ptr %l29
  br label %bb9
bb9:
  %t60 = load %"compiler/cabi:Way", ptr %l29
  store %"compiler/cabi:Way" %t60, ptr %l3
  %t61 = getelementptr %"compiler/cabi:Way", ptr %l3, i32 0, i32 0
  %t62 = load i32, ptr %t61
  store i32 %t62, ptr %l4
  %t64 = load i32, ptr %l4
  %t66 = trunc i64 0 to i32
  %t67 = icmp eq i32 %t64, %t66
  br i1 %t67, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb18
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t69 = getelementptr %"compiler/cabi:Way", ptr %l3, i32 0, i32 4
  %t70 = load { i64, ptr }, ptr %t69, !tbaa !27
  %t72 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s2, { i64, ptr } %t70, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d10, i32 0, i32 1) })
  store i1 %t72, ptr %l35
  br label %bb13
bb13:
  %t73 = load i1, ptr %l35, !tbaa !21
  %t74 = xor i1 %t73, true
  br i1 %t74, label %bb14, label %bb15
bb14:
  %t76 = getelementptr %"compiler/cabi:Way", ptr %l3, i32 0, i32 4
  %t77 = load { i64, ptr }, ptr %t76, !tbaa !27
  %t79 = extractvalue { i64, ptr } %t77, 1
  %t80 = extractvalue { i64, ptr } %t77, 0
  %t81 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d11, i32 0, i32 1) }, 1
  %t82 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d11, i32 0, i32 1) }, 0
  %t83 = add i64 %t80, %t82
  %t84 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t83)
  call void @olang_textcopy(ptr %t84, ptr %t79, i64 %t80)
  %t85 = getelementptr i8, ptr %t84, i64 %t80
  call void @olang_textcopy(ptr %t85, ptr %t81, i64 %t82)
  %t86 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t87 = insertvalue { i64, ptr } %t86, ptr %t84, 1
  %t89 = extractvalue { i64, ptr } %t87, 0
  %t90 = extractvalue { i64, ptr } %t87, 1
  %t91 = mul i64 %t89, 1
  %t92 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t91)
  call void @llvm.memcpy.p0.p0.i64(ptr %t92, ptr %t90, i64 %t91, i1 false)
  %t93 = insertvalue { i64, ptr } undef, i64 %t89, 0
  %t94 = insertvalue { i64, ptr } %t93, ptr %t92, 1
  store { i64, ptr } %t94, ptr %l37, !tbaa !27
  br label %bb16
bb15:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d12, i32 0, i32 1) }, ptr %l37, !tbaa !27
  br label %bb16
bb16:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t97 = load i32, ptr %l2, !tbaa !23
  %t100 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %s2, ptr %t96, i32 %t97)
  store { i64, ptr } %t100, ptr %l43
  br label %bb17
bb17:
  %t101 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t102 = extractvalue { i64, ptr } %t101, 1
  %t103 = extractvalue { i64, ptr } %t101, 0
  %t104 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t105 = extractvalue { i64, ptr } %t104, 1
  %t106 = extractvalue { i64, ptr } %t104, 0
  %t107 = add i64 %t103, %t106
  %t108 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t107)
  call void @olang_textcopy(ptr %t108, ptr %t102, i64 %t103)
  %t109 = getelementptr i8, ptr %t108, i64 %t103
  call void @olang_textcopy(ptr %t109, ptr %t105, i64 %t106)
  %t110 = insertvalue { i64, ptr } undef, i64 %t107, 0
  %t111 = insertvalue { i64, ptr } %t110, ptr %t108, 1
  store { i64, ptr } %t111, ptr %l31, !tbaa !27
  call void @__olang_scope_close(ptr %s2)
  br label %bb28
bb18:
  %t113 = load i32, ptr %l4
  %t115 = trunc i64 1 to i32
  %t116 = icmp eq i32 %t113, %t115
  br i1 %t116, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb23
bb21:
  %t119 = call { i64, ptr } @compiler_2fcabi_2ePartsType(ptr %s0, ptr %v1, ptr %l3)
  store { i64, ptr } %t119, ptr %l48
  br label %bb22
bb22:
  %t120 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t120, ptr %l31, !tbaa !27
  br label %bb28
bb23:
  br i1 true, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb27
bb26:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d13, i32 0, i32 1) }, ptr %l49, !tbaa !27
  %t121 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t121, ptr %l31, !tbaa !27
  br label %bb28
bb27:
  call void @__olang_check_failed(ptr @olang_loc_6aada305a3873fb6_c16c54d6f05c33ea)
  unreachable
bb28:
  %t123 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t124 = extractvalue { i64, ptr } %t123, 0
  store i64 %t124, ptr %l51, !tbaa !24
  %t125 = load i64, ptr %l51, !tbaa !24
  %t126 = mul i64 %t125, 1
  %t127 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t126)
  %t128 = insertvalue { i64, ptr } undef, i64 %t125, 0
  %t129 = insertvalue { i64, ptr } %t128, ptr %t127, 1
  store { i64, ptr } %t129, ptr %l52, !tbaa !27
  %t130 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !27
  %t132 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !27
  %t134 = load i64, ptr %l51, !tbaa !24
  %t135 = mul i64 %t134, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t131, ptr %t133, i64 %t135, i1 false)
  %t136 = load { i64, ptr }, ptr %l52, !tbaa !27
  store { i64, ptr } %t136, ptr %l31, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t137 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t137, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecstr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %lp3 = alloca ptr
  %l9 = alloca i1
  %l10 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca i32
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca { i64, ptr }
  %l22 = alloca ptr
  %l25 = alloca ptr
  %l27 = alloca i64
  %l28 = alloca i64
  %l32 = alloca { i64, ptr }
  %l33 = alloca i64
  %l34 = alloca { i64, ptr }
  %l37 = alloca i64
  %l39 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t2 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d14, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d14, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %t1, 1
  %t6 = extractvalue { i64, ptr } %t1, 0
  %t7 = add i64 %t3, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t2, i64 %t3)
  %t9 = getelementptr i8, ptr %t8, i64 %t3
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  store { i64, ptr } %t11, ptr %l2, !tbaa !27
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/emit:Emitter", ptr %t13, i32 0, i32 25
  %t16 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t19 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_He27db0a1785588531472bfd2db42574f(ptr %v0, ptr %s0, ptr %t15, { i64, ptr } %t16)
  store i1 %t19, ptr %l9
  br label %bb1
bb1:
  %t20 = load i1, ptr %l9, !tbaa !21
  br i1 %t20, label %bb2, label %bb3
bb2:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/emit:Emitter", ptr %t21, i32 0, i32 25
  %t24 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t27 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha4444909f5ef14f7626d25b8f59e6ba2(ptr %v0, ptr %s0, ptr %v2, ptr %t23, { i64, ptr } %t24)
  %t28 = extractvalue { i32, { i64, ptr } } %t27, 1
  %t29 = extractvalue { i32, { i64, ptr } } %t27, 0
  store i32 %t29, ptr %l15
  %t30 = icmp ne i32 %t29, 0
  br i1 %t30, label %bb5, label %ok.31
ok.31:
  store { i64, ptr } %t28, ptr %l14
  br label %bb4
bb3:
  br label %bb8
bb4:
  %t32 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t32, ptr %l10, !tbaa !27
  br label %bb7
bb5:
  br label %bb6
bb6:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d15, i32 0, i32 1) }, ptr %l10, !tbaa !27
  br label %bb7
bb7:
  %t33 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t33, ptr %l16, !tbaa !27
  %t34 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t34, 0
  store i64 %t35, ptr %l17, !tbaa !24
  %t36 = load i64, ptr %l17, !tbaa !24
  %t37 = mul i64 %t36, 1
  %t38 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t37)
  %t39 = insertvalue { i64, ptr } undef, i64 %t36, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %t38, 1
  store { i64, ptr } %t40, ptr %l18, !tbaa !27
  %t41 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !27
  %t43 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !27
  %t45 = load i64, ptr %l17, !tbaa !24
  %t46 = mul i64 %t45, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t42, ptr %t44, i64 %t46, i1 false)
  %t47 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t47, ptr %l16, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t48 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t48, ptr %rv
  br label %ret
bb8:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/emit:Emitter", ptr %t49, i32 0, i32 22
  %t52 = load i64, ptr %t51, !tbaa !24
  %t53 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d16, i32 0, i32 1) }, 1
  %t54 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d16, i32 0, i32 1) }, 0
  %t56 = call i64 @__olang_fmt_i64(ptr null, i64 %t52)
  %t57 = add i64 %t54, %t56
  %t58 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t57)
  call void @olang_textcopy(ptr %t58, ptr %t53, i64 %t54)
  %t59 = getelementptr i8, ptr %t58, i64 %t54
  %t60 = call i64 @__olang_fmt_i64(ptr %t59, i64 %t52)
  %t61 = insertvalue { i64, ptr } undef, i64 %t57, 0
  %t62 = insertvalue { i64, ptr } %t61, ptr %t58, 1
  %t63 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t63, ptr %lp3
  %t65 = load ptr, ptr %lp3
  store { i64, ptr } %t62, ptr %t65, !tbaa !27
  %t66 = load ptr, ptr %l0, !tbaa !29
  store ptr %t66, ptr %l22, !tbaa !29
  %t67 = load ptr, ptr %l22, !tbaa !29
  %t68 = getelementptr %"compiler/emit:Emitter", ptr %t67, i32 0, i32 22
  %t69 = load i64, ptr %t68, !tbaa !24
  %t71 = add i64 %t69, 1
  %t73 = load ptr, ptr %l22, !tbaa !29
  %t74 = getelementptr %"compiler/emit:Emitter", ptr %t73, i32 0, i32 22
  store i64 %t71, ptr %t74, !tbaa !24
  %t75 = load ptr, ptr %l0, !tbaa !29
  store ptr %t75, ptr %l25, !tbaa !29
  %t76 = load ptr, ptr %lp3
  %t77 = load { i64, ptr }, ptr %t76, !tbaa !27
  %t79 = extractvalue { i64, ptr } %t77, 0
  store i64 %t79, ptr %l27, !tbaa !24
  %t80 = load ptr, ptr %lp3
  %t81 = load { i64, ptr }, ptr %t80, !tbaa !27
  %t82 = extractvalue { i64, ptr } %t81, 0
  store i64 %t82, ptr %l28, !tbaa !24
  %t83 = icmp sge i64 1, 0
  br i1 %t83, label %bb9, label %bb10
bb9:
  %t85 = load i64, ptr %l27, !tbaa !24
  %t86 = icmp sle i64 1, %t85
  br i1 %t86, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_5836d127b451ff05_764b57a187e296f1)
  unreachable
bb11:
  %t88 = load i64, ptr %l27, !tbaa !24
  %t89 = load i64, ptr %l28, !tbaa !24
  %t90 = icmp sle i64 %t88, %t89
  br i1 %t90, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @olang_loc_5836d127b451ff05_764b57a187e296f1)
  unreachable
bb13:
  %t92 = load ptr, ptr %lp3
  %t93 = getelementptr { i64, ptr }, ptr %t92, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !27
  %t95 = load i64, ptr %l27, !tbaa !24
  %t96 = getelementptr i8, ptr %t94, i64 1
  %t97 = sub i64 %t95, 1
  %t98 = insertvalue { i64, ptr } undef, i64 %t97, 0
  %t99 = insertvalue { i64, ptr } %t98, ptr %t96, 1
  store { i64, ptr } %t99, ptr %l32, !tbaa !27
  %t100 = load i64, ptr @G_2ecompiler_2femit_2eHomeLocal, !tbaa !24
  store i64 %t100, ptr %l33, !tbaa !24
  %t101 = load ptr, ptr %lp3
  %t102 = load { i64, ptr }, ptr %t101, !tbaa !27
  store { i64, ptr } %t102, ptr %l34, !tbaa !27
  %t103 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t105 = extractvalue { i64, ptr } %t103, 0
  %t107 = add i64 %t105, 1
  store i64 %t107, ptr %l37, !tbaa !24
  %t108 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t110 = call { i64, ptr } @compiler_2femit_2eescape(ptr %v1, ptr %s0, { i64, ptr } %t108)
  store { i64, ptr } %t110, ptr %l39
  br label %bb15
bb14:
  call void @__olang_check_failed(ptr @olang_loc_5836d127b451ff05_764b57a187e296f1)
  unreachable
bb15:
  %t111 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t112 = extractvalue { i64, ptr } %t111, 1
  %t113 = extractvalue { i64, ptr } %t111, 0
  %t114 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d17, i32 0, i32 1) }, 1
  %t115 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d17, i32 0, i32 1) }, 0
  %t116 = add i64 %t113, %t115
  %t117 = load i64, ptr %l37, !tbaa !24
  %t118 = call i64 @__olang_fmt_i64(ptr null, i64 %t117)
  %t119 = add i64 %t116, %t118
  %t120 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d18, i32 0, i32 1) }, 1
  %t121 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d18, i32 0, i32 1) }, 0
  %t122 = add i64 %t119, %t121
  %t123 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t124 = extractvalue { i64, ptr } %t123, 1
  %t125 = extractvalue { i64, ptr } %t123, 0
  %t126 = add i64 %t122, %t125
  %t127 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d19, i32 0, i32 1) }, 1
  %t128 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d19, i32 0, i32 1) }, 0
  %t129 = add i64 %t126, %t128
  %t130 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t129)
  call void @olang_textcopy(ptr %t130, ptr %t112, i64 %t113)
  %t131 = getelementptr i8, ptr %t130, i64 %t113
  call void @olang_textcopy(ptr %t131, ptr %t114, i64 %t115)
  %t132 = getelementptr i8, ptr %t131, i64 %t115
  %t133 = call i64 @__olang_fmt_i64(ptr %t132, i64 %t117)
  %t134 = getelementptr i8, ptr %t132, i64 %t118
  call void @olang_textcopy(ptr %t134, ptr %t120, i64 %t121)
  %t135 = getelementptr i8, ptr %t134, i64 %t121
  call void @olang_textcopy(ptr %t135, ptr %t124, i64 %t125)
  %t136 = getelementptr i8, ptr %t135, i64 %t125
  call void @olang_textcopy(ptr %t136, ptr %t127, i64 %t128)
  %t137 = insertvalue { i64, ptr } undef, i64 %t129, 0
  %t138 = insertvalue { i64, ptr } %t137, ptr %t130, 1
  %t140 = extractvalue { i64, ptr } %t138, 0
  %t141 = extractvalue { i64, ptr } %t138, 1
  %t142 = mul i64 %t140, 1
  %t143 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t142)
  call void @llvm.memcpy.p0.p0.i64(ptr %t143, ptr %t141, i64 %t142, i1 false)
  %t144 = insertvalue { i64, ptr } undef, i64 %t140, 0
  %t145 = insertvalue { i64, ptr } %t144, ptr %t143, 1
  %t146 = load ptr, ptr %l25, !tbaa !29
  %t147 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t148 = load i64, ptr %l33, !tbaa !24
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eitem(ptr %v0, ptr %v2, ptr %s0, ptr %s0, ptr %t146, { i64, ptr } %t147, i64 %t148, { i64, ptr } %t145, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d8, i32 0, i32 1) })
  br label %bb16
bb16:
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t152 = getelementptr %"compiler/emit:Emitter", ptr %t150, i32 0, i32 25
  %t153 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t155 = extractvalue { i64, ptr } %t153, 1
  %t156 = extractvalue { i64, ptr } %t153, 0
  %t157 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t156)
  call void @olang_textcopy(ptr %t157, ptr %t155, i64 %t156)
  %t158 = insertvalue { i64, ptr } undef, i64 %t156, 0
  %t159 = insertvalue { i64, ptr } %t158, ptr %t157, 1
  %t161 = extractvalue { i64, ptr } %t159, 0
  %t162 = extractvalue { i64, ptr } %t159, 1
  %t163 = mul i64 %t161, 1
  %t164 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t163)
  call void @llvm.memcpy.p0.p0.i64(ptr %t164, ptr %t162, i64 %t163, i1 false)
  %t165 = insertvalue { i64, ptr } undef, i64 %t161, 0
  %t166 = insertvalue { i64, ptr } %t165, ptr %t164, 1
  %t167 = load ptr, ptr %lp3
  %t168 = load { i64, ptr }, ptr %t167, !tbaa !27
  %t170 = extractvalue { i64, ptr } %t168, 1
  %t171 = extractvalue { i64, ptr } %t168, 0
  %t172 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t171)
  call void @olang_textcopy(ptr %t172, ptr %t170, i64 %t171)
  %t173 = insertvalue { i64, ptr } undef, i64 %t171, 0
  %t174 = insertvalue { i64, ptr } %t173, ptr %t172, 1
  %t176 = extractvalue { i64, ptr } %t174, 0
  %t177 = extractvalue { i64, ptr } %t174, 1
  %t178 = mul i64 %t176, 1
  %t179 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t178)
  call void @llvm.memcpy.p0.p0.i64(ptr %t179, ptr %t177, i64 %t178, i1 false)
  %t180 = insertvalue { i64, ptr } undef, i64 %t176, 0
  %t181 = insertvalue { i64, ptr } %t180, ptr %t179, 1
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6f7a2f8d839c49b6e7a19c287d4b190c(ptr %v0, ptr %v0, ptr %v0, ptr %t152, { i64, ptr } %t166, { i64, ptr } %t181)
  br label %bb17
bb17:
  %t185 = load ptr, ptr %lp3
  %t186 = load { i64, ptr }, ptr %t185, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t186, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgFile(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l8 = alloca i1
  %l9 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i32
  %l16 = alloca i64
  %l24 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l27 = alloca i32
  %l30 = alloca { i64, ptr }
  %l33 = alloca ptr
  %l34 = alloca i64
  %l36 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 54
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %t3, i64 %t4)
  store i1 %t7, ptr %l8
  br label %bb1
bb1:
  %t8 = load i1, ptr %l8, !tbaa !21
  br i1 %t8, label %bb2, label %bb3
bb2:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/emit:Emitter", ptr %t9, i32 0, i32 54
  %t12 = load i64, ptr %l1, !tbaa !24
  %t15 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t11, i64 %t12)
  %t16 = extractvalue { i32, i64 } %t15, 1
  %t17 = extractvalue { i32, i64 } %t15, 0
  store i32 %t17, ptr %l14
  %t18 = icmp ne i32 %t17, 0
  br i1 %t18, label %bb5, label %ok.19
ok.19:
  store i64 %t16, ptr %l13
  br label %bb4
bb3:
  br label %bb8
bb4:
  %t20 = load i64, ptr %l13, !tbaa !24
  store i64 %t20, ptr %l9, !tbaa !24
  br label %bb7
bb5:
  br label %bb6
bb6:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l9, !tbaa !24
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s0)
  %t21 = load i64, ptr %l9, !tbaa !24
  store i64 %t21, ptr %rv
  br label %ret
bb8:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgNew(ptr %v0, ptr %t22)
  store i64 %t24, ptr %l16
  br label %bb9
bb9:
  %t25 = load i64, ptr %l16, !tbaa !24
  store i64 %t25, ptr %l2, !tbaa !24
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/emit:Emitter", ptr %t26, i32 0, i32 54
  %t29 = load i64, ptr %l1, !tbaa !24
  %t30 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t28, i64 %t29, i64 %t30)
  br label %bb10
bb10:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/emit:Emitter", ptr %t34, i32 0, i32 2
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t38 = load i64, ptr %l1, !tbaa !24
  %t41 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2ePathOf(ptr %v0, ptr %s0, ptr %t37, i64 %t38)
  store { i64, ptr } %t41, ptr %l24
  br label %bb11
bb11:
  %t42 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t42, ptr %l3, !tbaa !27
  %t43 = call { i32, { i64, ptr } } @std_2fos_2eCwd(ptr %s0)
  %t44 = extractvalue { i32, { i64, ptr } } %t43, 1
  %t45 = extractvalue { i32, { i64, ptr } } %t43, 0
  store i32 %t45, ptr %l27
  %t46 = icmp ne i32 %t45, 0
  br i1 %t46, label %bb13, label %ok.47
ok.47:
  store { i64, ptr } %t44, ptr %l26
  br label %bb12
bb12:
  %t48 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t48, ptr %l25, !tbaa !27
  br label %bb17
bb13:
  %t49 = load i32, ptr %l27, !tbaa !23
  %t50 = ashr i32 %t49, 16
  %t52 = icmp eq i32 %t50, 1
  br i1 %t52, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_d8b0748be4d5a5b9_c527c32a89be493d)
  unreachable
bb16:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d20, i32 0, i32 1) }, ptr %l30, !tbaa !27
  %t54 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t56 = extractvalue { i64, ptr } %t54, 0
  %t57 = extractvalue { i64, ptr } %t54, 1
  %t58 = mul i64 %t56, 1
  %t59 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t58)
  call void @llvm.memcpy.p0.p0.i64(ptr %t59, ptr %t57, i64 %t58, i1 false)
  %t60 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t61 = insertvalue { i64, ptr } %t60, ptr %t59, 1
  store { i64, ptr } %t61, ptr %l25, !tbaa !27
  br label %bb17
bb17:
  %t63 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t63, ptr %l4, !tbaa !27
  %t64 = load ptr, ptr %l0, !tbaa !29
  store ptr %t64, ptr %l33, !tbaa !29
  %t65 = load i64, ptr %l2, !tbaa !24
  store i64 %t65, ptr %l34, !tbaa !24
  %t66 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t68 = call { i64, ptr } @compiler_2femit_2eescape(ptr %s0, ptr %s0, { i64, ptr } %t66)
  store { i64, ptr } %t68, ptr %l36
  br label %bb18
bb18:
  %t69 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t71 = call { i64, ptr } @compiler_2femit_2eescape(ptr %s0, ptr %s0, { i64, ptr } %t69)
  store { i64, ptr } %t71, ptr %l38
  br label %bb19
bb19:
  %t72 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d21, i32 0, i32 1) }, 1
  %t73 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d21, i32 0, i32 1) }, 0
  %t74 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t75 = extractvalue { i64, ptr } %t74, 1
  %t76 = extractvalue { i64, ptr } %t74, 0
  %t77 = add i64 %t73, %t76
  %t78 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d22, i32 0, i32 1) }, 1
  %t79 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d22, i32 0, i32 1) }, 0
  %t80 = add i64 %t77, %t79
  %t81 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t82 = extractvalue { i64, ptr } %t81, 1
  %t83 = extractvalue { i64, ptr } %t81, 0
  %t84 = add i64 %t80, %t83
  %t85 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d23, i32 0, i32 1) }, 1
  %t86 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d23, i32 0, i32 1) }, 0
  %t87 = add i64 %t84, %t86
  %t88 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t87)
  call void @olang_textcopy(ptr %t88, ptr %t72, i64 %t73)
  %t89 = getelementptr i8, ptr %t88, i64 %t73
  call void @olang_textcopy(ptr %t89, ptr %t75, i64 %t76)
  %t90 = getelementptr i8, ptr %t89, i64 %t76
  call void @olang_textcopy(ptr %t90, ptr %t78, i64 %t79)
  %t91 = getelementptr i8, ptr %t90, i64 %t79
  call void @olang_textcopy(ptr %t91, ptr %t82, i64 %t83)
  %t92 = getelementptr i8, ptr %t91, i64 %t83
  call void @olang_textcopy(ptr %t92, ptr %t85, i64 %t86)
  %t93 = insertvalue { i64, ptr } undef, i64 %t87, 0
  %t94 = insertvalue { i64, ptr } %t93, ptr %t88, 1
  %t96 = extractvalue { i64, ptr } %t94, 0
  %t97 = extractvalue { i64, ptr } %t94, 1
  %t98 = mul i64 %t96, 1
  %t99 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t98)
  call void @llvm.memcpy.p0.p0.i64(ptr %t99, ptr %t97, i64 %t98, i1 false)
  %t100 = insertvalue { i64, ptr } undef, i64 %t96, 0
  %t101 = insertvalue { i64, ptr } %t100, ptr %t99, 1
  %t102 = load ptr, ptr %l33, !tbaa !29
  %t103 = load i64, ptr %l34, !tbaa !24
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgShared(ptr %v0, ptr %s0, ptr %t102, i64 %t103, { i64, ptr } %t101)
  br label %bb20
bb20:
  %t105 = load i64, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t105, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgType(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca %"std/prelude/text:StringBuilder"
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l31 = alloca i64
  %l32 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l34 = alloca %"std/prelude/text:StringBuilder"
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i1
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i64
  %l51 = alloca i64
  %l52 = alloca i64
  %l57 = alloca i32
  %l61 = alloca i1
  %l68 = alloca i1
  %l69 = alloca i64
  %l74 = alloca i64
  %l75 = alloca i32
  %l77 = alloca i64
  %l86 = alloca { i64, ptr }
  %l89 = alloca i1
  %l90 = alloca { i64, ptr }
  %l93 = alloca i1
  %l94 = alloca { i64, ptr }
  %l97 = alloca i64
  %l99 = alloca i1
  %l102 = alloca i1
  %l106 = alloca i64
  %l109 = alloca i64
  %l110 = alloca ptr
  %l111 = alloca i64
  %l114 = alloca { i64, ptr }
  %l124 = alloca i1
  %l125 = alloca i64
  %l130 = alloca i64
  %l131 = alloca i32
  %l134 = alloca i32
  %l139 = alloca i32
  %l142 = alloca { i64, ptr }
  %l144 = alloca i1
  %l146 = alloca ptr
  %l147 = alloca i32
  %l149 = alloca i32
  %l150 = alloca ptr
  %l153 = alloca i32
  %l154 = alloca i32
  %l155 = alloca i64
  %l157 = alloca i64
  %l165 = alloca i64
  %l166 = alloca ptr
  %l167 = alloca i64
  %l170 = alloca { i64, ptr }
  %l183 = alloca i64
  %l187 = alloca i1
  %l190 = alloca i64
  %l196 = alloca i32
  %l198 = alloca ptr
  %l199 = alloca i32
  %l201 = alloca i32
  %l204 = alloca i32
  %l205 = alloca i64
  %l207 = alloca i64
  %l213 = alloca ptr
  %l216 = alloca i32
  %l217 = alloca i64
  %l221 = alloca i64
  %l223 = alloca i64
  %l224 = alloca ptr
  %l225 = alloca i64
  %l226 = alloca ptr
  %l229 = alloca i32
  %l230 = alloca i64
  %l243 = alloca i1
  %l246 = alloca i1
  %l249 = alloca i1
  %l250 = alloca ptr
  %l253 = alloca i32
  %l254 = alloca i32
  %l259 = alloca i64
  %l265 = alloca ptr
  %l269 = alloca i32
  %l272 = alloca i32
  %l275 = alloca i32
  %l276 = alloca { i64, ptr }
  %l281 = alloca { i64, ptr }
  %l284 = alloca { i64, ptr }
  %l285 = alloca %"std/prelude/text:StringBuilder"
  %l291 = alloca i64
  %l294 = alloca i64
  %l314 = alloca { i64, ptr }
  %l317 = alloca i1
  %l319 = alloca { i64, ptr }
  %l322 = alloca i64
  %l326 = alloca i64
  %l328 = alloca i64
  %l329 = alloca ptr
  %l330 = alloca i64
  %l333 = alloca { i64, ptr }
  %l334 = alloca i64
  %l336 = alloca { i64, ptr }
  %l339 = alloca i64
  %l356 = alloca i64
  %l357 = alloca ptr
  %l358 = alloca i64
  %l360 = alloca { i64, ptr }
  %l363 = alloca ptr
  %l364 = alloca i64
  %l367 = alloca { i64, ptr }
  %l369 = alloca { i64, ptr }
  %l377 = alloca i1
  %l380 = alloca i1
  %l381 = alloca ptr
  %l384 = alloca i32
  %l385 = alloca i32
  %l390 = alloca i64
  %l398 = alloca { i64, ptr }
  %l401 = alloca { i64, ptr }
  %l405 = alloca ptr
  %l408 = alloca i32
  %l411 = alloca i32
  %l414 = alloca i32
  %l415 = alloca { i64, ptr }
  %l416 = alloca %"std/prelude/text:StringBuilder"
  %l422 = alloca i64
  %l425 = alloca i64
  %l444 = alloca i64
  %l448 = alloca i1
  %l453 = alloca { i64, ptr }
  %l455 = alloca { i64, ptr }
  %l458 = alloca { i64, ptr }
  %l462 = alloca ptr
  %l463 = alloca i64
  %l465 = alloca { i64, ptr }
  %l479 = alloca i64
  %l480 = alloca ptr
  %l481 = alloca i64
  %l483 = alloca { i64, ptr }
  %l488 = alloca i1
  %l491 = alloca i64
  %l494 = alloca i64
  %l495 = alloca ptr
  %l497 = alloca i32
  %l499 = alloca i32
  %l501 = alloca i32
  %l502 = alloca i64
  %l503 = alloca ptr
  %l504 = alloca i64
  %l507 = alloca { i64, ptr }
  %l509 = alloca { i64, ptr }
  %l511 = alloca i64
  %l521 = alloca i64
  %l524 = alloca i64
  %l526 = alloca i64
  %l532 = alloca ptr
  %l533 = alloca i64
  %l534 = alloca ptr
  %l536 = alloca i32
  %l537 = alloca i64
  %l544 = alloca i64
  %l546 = alloca i64
  %l548 = alloca i64
  %l567 = alloca ptr
  %l568 = alloca i64
  %l571 = alloca { i64, ptr }
  %l573 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %s31 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t6, i32 %a1)
  store i32 %t10, ptr %l57
  br label %bb1
bb1:
  %t11 = load i32, ptr %l57, !tbaa !23
  store i32 %t11, ptr %l3, !tbaa !23
  %t12 = load i32, ptr %l3, !tbaa !23
  %t13 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t16 = icmp sge i32 %t12, %t13
  br i1 %t16, label %bb2, label %bb3
bb2:
  %t18 = load i32, ptr %l3, !tbaa !23
  %t20 = icmp sle i32 %t18, 14
  store i1 %t20, ptr %l61, !tbaa !21
  br label %bb4
bb3:
  store i1 false, ptr %l61, !tbaa !21
  br label %bb4
bb4:
  %t22 = load i1, ptr %l61, !tbaa !21
  br i1 %t22, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/emit:Emitter", ptr %t23, i32 0, i32 55
  %t26 = load i32, ptr %l3, !tbaa !23
  %t28 = sext i32 %t26 to i64
  %t31 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %t25, i64 %t28)
  store i1 %t31, ptr %l68
  br label %bb7
bb6:
  br label %bb42
bb7:
  %t32 = load i1, ptr %l68, !tbaa !21
  br i1 %t32, label %bb8, label %bb9
bb8:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/emit:Emitter", ptr %t33, i32 0, i32 55
  %t36 = load i32, ptr %l3, !tbaa !23
  %t38 = sext i32 %t36 to i64
  %t41 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t35, i64 %t38)
  %t42 = extractvalue { i32, i64 } %t41, 1
  %t43 = extractvalue { i32, i64 } %t41, 0
  store i32 %t43, ptr %l75
  %t44 = icmp ne i32 %t43, 0
  br i1 %t44, label %bb11, label %ok.45
ok.45:
  store i64 %t42, ptr %l74
  br label %bb10
bb9:
  br label %bb14
bb10:
  %t46 = load i64, ptr %l74, !tbaa !24
  store i64 %t46, ptr %l69, !tbaa !24
  br label %bb13
bb11:
  br label %bb12
bb12:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l69, !tbaa !24
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s1)
  %t47 = load i64, ptr %l69, !tbaa !24
  store i64 %t47, ptr %rv
  br label %ret
bb14:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgNew(ptr %v0, ptr %t48)
  store i64 %t50, ptr %l77
  br label %bb15
bb15:
  %t51 = load i64, ptr %l77, !tbaa !24
  store i64 %t51, ptr %l4, !tbaa !24
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/emit:Emitter", ptr %t52, i32 0, i32 55
  %t55 = load i32, ptr %l3, !tbaa !23
  %t57 = sext i32 %t55 to i64
  %t58 = load i64, ptr %l4, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t54, i64 %t57, i64 %t58)
  br label %bb16
bb16:
  %t62 = load i32, ptr %l3, !tbaa !23
  %t63 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t66 = icmp eq i32 %t62, %t63
  br i1 %t66, label %bb17, label %bb18
bb17:
  store { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d24, i32 0, i32 1) }, ptr %l86, !tbaa !27
  br label %bb27
bb18:
  %t68 = load ptr, ptr %l2, !tbaa !29
  %t69 = load i32, ptr %l3, !tbaa !23
  %t72 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t68, i32 %t69)
  store i1 %t72, ptr %l89
  br label %bb19
bb19:
  %t73 = load i1, ptr %l89, !tbaa !21
  br i1 %t73, label %bb20, label %bb21
bb20:
  store { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d25, i32 0, i32 1) }, ptr %l90, !tbaa !27
  br label %bb26
bb21:
  %t74 = load ptr, ptr %l2, !tbaa !29
  %t75 = load i32, ptr %l3, !tbaa !23
  %t78 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %t74, i32 %t75)
  store i1 %t78, ptr %l93
  br label %bb22
bb22:
  %t79 = load i1, ptr %l93, !tbaa !21
  br i1 %t79, label %bb23, label %bb24
bb23:
  store { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d26, i32 0, i32 1) }, ptr %l94, !tbaa !27
  br label %bb25
bb24:
  store { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d27, i32 0, i32 1) }, ptr %l94, !tbaa !27
  br label %bb25
bb25:
  %t80 = load { i64, ptr }, ptr %l94, !tbaa !27
  store { i64, ptr } %t80, ptr %l90, !tbaa !27
  br label %bb26
bb26:
  %t81 = load { i64, ptr }, ptr %l90, !tbaa !27
  store { i64, ptr } %t81, ptr %l86, !tbaa !27
  br label %bb27
bb27:
  %t82 = load { i64, ptr }, ptr %l86, !tbaa !27
  store { i64, ptr } %t82, ptr %l5, !tbaa !27
  %t83 = load ptr, ptr %l2, !tbaa !29
  %t84 = load i32, ptr %l3, !tbaa !23
  %t87 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %t83, i32 %t84)
  store i64 %t87, ptr %l97
  br label %bb28
bb28:
  %t88 = load i64, ptr %l97, !tbaa !24
  %t89 = icmp eq i64 %t88, 8
  br i1 %t89, label %bb29, label %bb30
bb29:
  %t91 = load ptr, ptr %l2, !tbaa !29
  %t92 = load i32, ptr %l3, !tbaa !23
  %t95 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %t91, i32 %t92)
  store i1 %t95, ptr %l102
  br label %bb31
bb30:
  store i1 false, ptr %l99, !tbaa !21
  br label %bb32
bb31:
  %t96 = load i1, ptr %l102, !tbaa !21
  store i1 %t96, ptr %l99, !tbaa !21
  br label %bb32
bb32:
  %t97 = load i1, ptr %l99, !tbaa !21
  br i1 %t97, label %bb33, label %bb34
bb33:
  store { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d28, i32 0, i32 1) }, ptr %l5, !tbaa !27
  br label %bb35
bb34:
  br label %bb35
bb35:
  %t98 = load i32, ptr %l3, !tbaa !23
  %t99 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t102 = icmp eq i32 %t98, %t99
  br i1 %t102, label %bb36, label %bb37
bb36:
  store i64 8, ptr %l106, !tbaa !24
  br label %bb39
bb37:
  %t104 = load ptr, ptr %l2, !tbaa !29
  %t105 = load i32, ptr %l3, !tbaa !23
  %t108 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %t104, i32 %t105)
  store i64 %t108, ptr %l109
  br label %bb38
bb38:
  %t109 = load i64, ptr %l109, !tbaa !24
  store i64 %t109, ptr %l106, !tbaa !24
  br label %bb39
bb39:
  %t110 = load i64, ptr %l106, !tbaa !24
  store i64 %t110, ptr %l6, !tbaa !24
  %t111 = load ptr, ptr %l0, !tbaa !29
  store ptr %t111, ptr %l110, !tbaa !29
  %t112 = load i64, ptr %l4, !tbaa !24
  store i64 %t112, ptr %l111, !tbaa !24
  %t113 = load ptr, ptr %l2, !tbaa !29
  %t114 = load i32, ptr %l3, !tbaa !23
  %t117 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s1, ptr %t113, i32 %t114)
  store { i64, ptr } %t117, ptr %l114
  br label %bb40
bb40:
  %t118 = load i64, ptr %l6, !tbaa !24
  %t119 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t120 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d29, i32 0, i32 1) }, 1
  %t121 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d29, i32 0, i32 1) }, 0
  %t122 = load { i64, ptr }, ptr %l114, !tbaa !27
  %t123 = extractvalue { i64, ptr } %t122, 1
  %t124 = extractvalue { i64, ptr } %t122, 0
  %t125 = add i64 %t121, %t124
  %t126 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d30, i32 0, i32 1) }, 1
  %t127 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d30, i32 0, i32 1) }, 0
  %t128 = add i64 %t125, %t127
  %t130 = call i64 @__olang_fmt_i64(ptr null, i64 %t118)
  %t131 = add i64 %t128, %t130
  %t132 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d31, i32 0, i32 1) }, 1
  %t133 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d31, i32 0, i32 1) }, 0
  %t134 = add i64 %t131, %t133
  %t136 = extractvalue { i64, ptr } %t119, 1
  %t137 = extractvalue { i64, ptr } %t119, 0
  %t138 = add i64 %t134, %t137
  %t139 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d32, i32 0, i32 1) }, 1
  %t140 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d32, i32 0, i32 1) }, 0
  %t141 = add i64 %t138, %t140
  %t142 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t141)
  call void @olang_textcopy(ptr %t142, ptr %t120, i64 %t121)
  %t143 = getelementptr i8, ptr %t142, i64 %t121
  call void @olang_textcopy(ptr %t143, ptr %t123, i64 %t124)
  %t144 = getelementptr i8, ptr %t143, i64 %t124
  call void @olang_textcopy(ptr %t144, ptr %t126, i64 %t127)
  %t145 = getelementptr i8, ptr %t144, i64 %t127
  %t146 = call i64 @__olang_fmt_i64(ptr %t145, i64 %t118)
  %t147 = getelementptr i8, ptr %t145, i64 %t130
  call void @olang_textcopy(ptr %t147, ptr %t132, i64 %t133)
  %t148 = getelementptr i8, ptr %t147, i64 %t133
  call void @olang_textcopy(ptr %t148, ptr %t136, i64 %t137)
  %t149 = getelementptr i8, ptr %t148, i64 %t137
  call void @olang_textcopy(ptr %t149, ptr %t139, i64 %t140)
  %t150 = insertvalue { i64, ptr } undef, i64 %t141, 0
  %t151 = insertvalue { i64, ptr } %t150, ptr %t142, 1
  %t153 = extractvalue { i64, ptr } %t151, 0
  %t154 = extractvalue { i64, ptr } %t151, 1
  %t155 = mul i64 %t153, 1
  %t156 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t155)
  call void @llvm.memcpy.p0.p0.i64(ptr %t156, ptr %t154, i64 %t155, i1 false)
  %t157 = insertvalue { i64, ptr } undef, i64 %t153, 0
  %t158 = insertvalue { i64, ptr } %t157, ptr %t156, 1
  %t159 = load ptr, ptr %l110, !tbaa !29
  %t160 = load i64, ptr %l111, !tbaa !24
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgShared(ptr %v0, ptr %s1, ptr %t159, i64 %t160, { i64, ptr } %t158)
  br label %bb41
bb41:
  %t162 = load i64, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  store i64 %t162, ptr %rv
  br label %ret
bb42:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t166 = getelementptr %"compiler/emit:Emitter", ptr %t164, i32 0, i32 56
  %t167 = load i32, ptr %l3, !tbaa !23
  %t169 = sext i32 %t167 to i64
  %t172 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %t166, i64 %t169)
  store i1 %t172, ptr %l124
  br label %bb43
bb43:
  %t173 = load i1, ptr %l124, !tbaa !21
  br i1 %t173, label %bb44, label %bb45
bb44:
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t176 = getelementptr %"compiler/emit:Emitter", ptr %t174, i32 0, i32 56
  %t177 = load i32, ptr %l3, !tbaa !23
  %t179 = sext i32 %t177 to i64
  %t182 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t176, i64 %t179)
  %t183 = extractvalue { i32, i64 } %t182, 1
  %t184 = extractvalue { i32, i64 } %t182, 0
  store i32 %t184, ptr %l131
  %t185 = icmp ne i32 %t184, 0
  br i1 %t185, label %bb47, label %ok.186
ok.186:
  store i64 %t183, ptr %l130
  br label %bb46
bb45:
  br label %bb50
bb46:
  %t187 = load i64, ptr %l130, !tbaa !24
  store i64 %t187, ptr %l125, !tbaa !24
  br label %bb49
bb47:
  br label %bb48
bb48:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l125, !tbaa !24
  br label %bb49
bb49:
  %t188 = load i64, ptr %l125, !tbaa !24
  store i64 %t188, ptr %rv
  br label %ret
bb50:
  %t189 = load ptr, ptr %l2, !tbaa !29
  %t190 = load i32, ptr %l3, !tbaa !23
  %t193 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t189, i32 %t190)
  store i32 %t193, ptr %l134
  br label %bb51
bb51:
  %t194 = load i32, ptr %l134
  store i32 %t194, ptr %l7
  %t195 = load i32, ptr %l7
  %t197 = trunc i64 20 to i32
  %t198 = icmp eq i32 %t195, %t197
  br i1 %t198, label %bb52, label %bb53
bb52:
  store %olang.scope zeroinitializer, ptr %s6
  %t200 = load ptr, ptr %l2, !tbaa !29
  %t201 = load i32, ptr %l3, !tbaa !23
  %t204 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t200, i32 %t201)
  store i32 %t204, ptr %l139
  br label %bb54
bb53:
  br label %bb71
bb54:
  %t205 = load i32, ptr %l139, !tbaa !23
  store i32 %t205, ptr %l8, !tbaa !23
  %t206 = load ptr, ptr %l0, !tbaa !29
  %t207 = load i32, ptr %l3, !tbaa !23
  %t210 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %s6, ptr %t206, i32 %t207)
  store { i64, ptr } %t210, ptr %l142
  br label %bb55
bb55:
  %t211 = load { i64, ptr }, ptr %l142, !tbaa !27
  %t212 = extractvalue { i64, ptr } %t211, 0
  %t213 = extractvalue { i64, ptr } %t211, 1
  %t214 = mul i64 %t212, 1
  %t215 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t214)
  call void @llvm.memcpy.p0.p0.i64(ptr %t215, ptr %t213, i64 %t214, i1 false)
  %t216 = insertvalue { i64, ptr } undef, i64 %t212, 0
  %t217 = insertvalue { i64, ptr } %t216, ptr %t215, 1
  %t219 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s6, ptr %s6, { i64, ptr } %t217, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d33, i32 0, i32 1) })
  store i1 %t219, ptr %l144
  br label %bb56
bb56:
  %t220 = load i1, ptr %l144, !tbaa !21
  %t221 = xor i1 %t220, true
  br i1 %t221, label %bb57, label %bb58
bb57:
  store %olang.scope zeroinitializer, ptr %s7
  %t223 = load ptr, ptr %l0, !tbaa !29
  store ptr %t223, ptr %l146, !tbaa !29
  %t224 = load i32, ptr %l3, !tbaa !23
  store i32 %t224, ptr %l147, !tbaa !23
  %t225 = load ptr, ptr %l2, !tbaa !29
  %t227 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s7, ptr %t225, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d34, i32 0, i32 1) })
  store i32 %t227, ptr %l149
  br label %bb59
bb58:
  br label %bb63
bb59:
  %t228 = load ptr, ptr %l2, !tbaa !29
  store ptr %t228, ptr %l150, !tbaa !29
  %t229 = load ptr, ptr %l2, !tbaa !29
  %t230 = load i32, ptr %l8, !tbaa !23
  %t233 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t229, i32 %t230)
  store i32 %t233, ptr %l153
  br label %bb60
bb60:
  %t234 = load ptr, ptr %l150, !tbaa !29
  %t235 = load i32, ptr %l153, !tbaa !23
  %t236 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t234, i32 %t235)
  store i32 %t236, ptr %l154
  br label %bb61
bb61:
  %t237 = load ptr, ptr %l146, !tbaa !29
  %t238 = load i32, ptr %l147, !tbaa !23
  %t239 = load i32, ptr %l149, !tbaa !23
  %t240 = load i32, ptr %l154, !tbaa !23
  %t241 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgPair(ptr %v0, ptr %s7, ptr %s7, ptr %t237, i32 %t238, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d35, i32 0, i32 1) }, i32 %t239, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d36, i32 0, i32 1) }, i32 %t240)
  store i64 %t241, ptr %l155
  br label %bb62
bb62:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s6)
  %t242 = load i64, ptr %l155, !tbaa !24
  store i64 %t242, ptr %rv
  br label %ret
bb63:
  %t243 = load ptr, ptr %l0, !tbaa !29
  %t245 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgNew(ptr %v0, ptr %t243)
  store i64 %t245, ptr %l157
  br label %bb64
bb64:
  %t246 = load i64, ptr %l157, !tbaa !24
  store i64 %t246, ptr %l9, !tbaa !24
  %t247 = load ptr, ptr %l0, !tbaa !29
  %t249 = getelementptr %"compiler/emit:Emitter", ptr %t247, i32 0, i32 56
  %t250 = load i32, ptr %l3, !tbaa !23
  %t252 = sext i32 %t250 to i64
  %t253 = load i64, ptr %l9, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t249, i64 %t252, i64 %t253)
  br label %bb65
bb65:
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t258 = load i32, ptr %l8, !tbaa !23
  %t261 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgType(ptr %v0, ptr %t257, i32 %t258)
  store i64 %t261, ptr %l165
  br label %bb66
bb66:
  %t262 = load i64, ptr %l165, !tbaa !24
  store i64 %t262, ptr %l10, !tbaa !24
  %t263 = load ptr, ptr %l0, !tbaa !29
  store ptr %t263, ptr %l166, !tbaa !29
  %t264 = load i64, ptr %l9, !tbaa !24
  store i64 %t264, ptr %l167, !tbaa !24
  %t265 = load i64, ptr %l10, !tbaa !24
  %t267 = icmp sge i64 %t265, 0
  br i1 %t267, label %bb67, label %bb68
bb67:
  %t269 = load i64, ptr %l10, !tbaa !24
  %t270 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d37, i32 0, i32 1) }, 1
  %t271 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d37, i32 0, i32 1) }, 0
  %t273 = call i64 @__olang_fmt_i64(ptr null, i64 %t269)
  %t274 = add i64 %t271, %t273
  %t275 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t274)
  call void @olang_textcopy(ptr %t275, ptr %t270, i64 %t271)
  %t276 = getelementptr i8, ptr %t275, i64 %t271
  %t277 = call i64 @__olang_fmt_i64(ptr %t276, i64 %t269)
  %t278 = insertvalue { i64, ptr } undef, i64 %t274, 0
  %t279 = insertvalue { i64, ptr } %t278, ptr %t275, 1
  %t281 = extractvalue { i64, ptr } %t279, 0
  %t282 = extractvalue { i64, ptr } %t279, 1
  %t283 = mul i64 %t281, 1
  %t284 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t283)
  call void @llvm.memcpy.p0.p0.i64(ptr %t284, ptr %t282, i64 %t283, i1 false)
  %t285 = insertvalue { i64, ptr } undef, i64 %t281, 0
  %t286 = insertvalue { i64, ptr } %t285, ptr %t284, 1
  store { i64, ptr } %t286, ptr %l170, !tbaa !27
  br label %bb69
bb68:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d38, i32 0, i32 1) }, ptr %l170, !tbaa !27
  br label %bb69
bb69:
  %t288 = extractvalue { i64, ptr } { i64 51, ptr getelementptr inbounds (<{ i64, [51 x i8] }>, ptr @.d39, i32 0, i32 1) }, 1
  %t289 = extractvalue { i64, ptr } { i64 51, ptr getelementptr inbounds (<{ i64, [51 x i8] }>, ptr @.d39, i32 0, i32 1) }, 0
  %t290 = load { i64, ptr }, ptr %l170, !tbaa !27
  %t291 = extractvalue { i64, ptr } %t290, 1
  %t292 = extractvalue { i64, ptr } %t290, 0
  %t293 = add i64 %t289, %t292
  %t294 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d40, i32 0, i32 1) }, 1
  %t295 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d40, i32 0, i32 1) }, 0
  %t296 = add i64 %t293, %t295
  %t297 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t296)
  call void @olang_textcopy(ptr %t297, ptr %t288, i64 %t289)
  %t298 = getelementptr i8, ptr %t297, i64 %t289
  call void @olang_textcopy(ptr %t298, ptr %t291, i64 %t292)
  %t299 = getelementptr i8, ptr %t298, i64 %t292
  call void @olang_textcopy(ptr %t299, ptr %t294, i64 %t295)
  %t300 = insertvalue { i64, ptr } undef, i64 %t296, 0
  %t301 = insertvalue { i64, ptr } %t300, ptr %t297, 1
  %t303 = extractvalue { i64, ptr } %t301, 0
  %t304 = extractvalue { i64, ptr } %t301, 1
  %t305 = mul i64 %t303, 1
  %t306 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t305)
  call void @llvm.memcpy.p0.p0.i64(ptr %t306, ptr %t304, i64 %t305, i1 false)
  %t307 = insertvalue { i64, ptr } undef, i64 %t303, 0
  %t308 = insertvalue { i64, ptr } %t307, ptr %t306, 1
  %t309 = load ptr, ptr %l166, !tbaa !29
  %t310 = load i64, ptr %l167, !tbaa !24
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgShared(ptr %v0, ptr %s6, ptr %t309, i64 %t310, { i64, ptr } %t308)
  br label %bb70
bb70:
  %t312 = load i64, ptr %l9, !tbaa !24
  call void @__olang_scope_close(ptr %s6)
  store i64 %t312, ptr %rv
  br label %ret
bb71:
  %t314 = load i32, ptr %l7
  %t316 = trunc i64 21 to i32
  %t317 = icmp eq i32 %t314, %t316
  br i1 %t317, label %bb72, label %bb73
bb72:
  store %olang.scope zeroinitializer, ptr %s10
  %t319 = load ptr, ptr %l0, !tbaa !29
  %t320 = load i32, ptr %l3, !tbaa !23
  %t321 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t322 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t327 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgPair(ptr %v0, ptr %s10, ptr %s10, ptr %t319, i32 %t320, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d41, i32 0, i32 1) }, i32 %t321, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d42, i32 0, i32 1) }, i32 %t322)
  store i64 %t327, ptr %l183
  br label %bb74
bb73:
  br label %bb75
bb74:
  call void @__olang_scope_close(ptr %s10)
  %t328 = load i64, ptr %l183, !tbaa !24
  store i64 %t328, ptr %rv
  br label %ret
bb75:
  %t329 = load ptr, ptr %l0, !tbaa !29
  %t331 = getelementptr %"compiler/emit:Emitter", ptr %t329, i32 0, i32 0
  %t332 = load ptr, ptr %t331, !tbaa !29
  %t333 = load i32, ptr %l3, !tbaa !23
  %t336 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLayout(ptr %v0, ptr %t332, i32 %t333)
  store i1 %t336, ptr %l187
  br label %bb76
bb76:
  %t337 = load ptr, ptr %l2, !tbaa !29
  %t338 = load i32, ptr %l3, !tbaa !23
  %t341 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSize(ptr %v0, ptr %t337, i32 %t338)
  store i64 %t341, ptr %l190
  br label %bb77
bb77:
  %t342 = load i64, ptr %l190, !tbaa !24
  %t343 = mul i64 %t342, 8
  store i64 %t343, ptr %l11, !tbaa !24
  %t345 = load i32, ptr %l7
  %t347 = trunc i64 19 to i32
  %t348 = icmp eq i32 %t345, %t347
  br i1 %t348, label %bb78, label %bb79
bb78:
  store %olang.scope zeroinitializer, ptr %s11
  %t350 = load ptr, ptr %l2, !tbaa !29
  %t351 = load i32, ptr %l3, !tbaa !23
  %t354 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t350, i32 %t351)
  store i32 %t354, ptr %l196
  br label %bb80
bb79:
  br label %bb100
bb80:
  %t355 = load i32, ptr %l196, !tbaa !23
  %t356 = icmp eq i32 %t355, 0
  br i1 %t356, label %bb81, label %bb82
bb81:
  store %olang.scope zeroinitializer, ptr %s12
  %t358 = load ptr, ptr %l0, !tbaa !29
  store ptr %t358, ptr %l198, !tbaa !29
  %t359 = load i32, ptr %l3, !tbaa !23
  store i32 %t359, ptr %l199, !tbaa !23
  %t360 = load ptr, ptr %l2, !tbaa !29
  %t362 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s12, ptr %t360, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d43, i32 0, i32 1) })
  store i32 %t362, ptr %l201
  br label %bb83
bb82:
  br label %bb86
bb83:
  %t363 = load ptr, ptr %l2, !tbaa !29
  %t364 = load i32, ptr %l3, !tbaa !23
  %t367 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t363, i32 %t364)
  store i32 %t367, ptr %l204
  br label %bb84
bb84:
  %t368 = load ptr, ptr %l198, !tbaa !29
  %t369 = load i32, ptr %l199, !tbaa !23
  %t370 = load i32, ptr %l201, !tbaa !23
  %t371 = load i32, ptr %l204, !tbaa !23
  %t372 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgPair(ptr %v0, ptr %s12, ptr %s12, ptr %t368, i32 %t369, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d44, i32 0, i32 1) }, i32 %t370, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d45, i32 0, i32 1) }, i32 %t371)
  store i64 %t372, ptr %l205
  br label %bb85
bb85:
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s11)
  %t373 = load i64, ptr %l205, !tbaa !24
  store i64 %t373, ptr %rv
  br label %ret
bb86:
  %t374 = load ptr, ptr %l0, !tbaa !29
  %t376 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgNew(ptr %v0, ptr %t374)
  store i64 %t376, ptr %l207
  br label %bb87
bb87:
  %t377 = load i64, ptr %l207, !tbaa !24
  store i64 %t377, ptr %l12, !tbaa !24
  %t378 = load ptr, ptr %l0, !tbaa !29
  %t380 = getelementptr %"compiler/emit:Emitter", ptr %t378, i32 0, i32 56
  %t381 = load i32, ptr %l3, !tbaa !23
  %t383 = sext i32 %t381 to i64
  %t384 = load i64, ptr %l12, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t380, i64 %t383, i64 %t384)
  br label %bb88
bb88:
  %t388 = load ptr, ptr %l0, !tbaa !29
  store ptr %t388, ptr %l213, !tbaa !29
  %t389 = load ptr, ptr %l2, !tbaa !29
  %t390 = load i32, ptr %l3, !tbaa !23
  %t393 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t389, i32 %t390)
  store i32 %t393, ptr %l216
  br label %bb89
bb89:
  %t394 = load ptr, ptr %l213, !tbaa !29
  %t395 = load i32, ptr %l216, !tbaa !23
  %t396 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgType(ptr %v0, ptr %t394, i32 %t395)
  store i64 %t396, ptr %l217
  br label %bb90
bb90:
  %t397 = load i64, ptr %l217, !tbaa !24
  store i64 %t397, ptr %l13, !tbaa !24
  %t398 = load i64, ptr %l13, !tbaa !24
  %t400 = icmp slt i64 %t398, 0
  br i1 %t400, label %bb91, label %bb92
bb91:
  %t402 = load ptr, ptr %l0, !tbaa !29
  %t404 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgBytes(ptr %v0, ptr %t402)
  store i64 %t404, ptr %l221
  br label %bb93
bb92:
  br label %bb94
bb93:
  %t405 = load i64, ptr %l221, !tbaa !24
  store i64 %t405, ptr %l13, !tbaa !24
  br label %bb94
bb94:
  %t406 = load ptr, ptr %l0, !tbaa !29
  %t408 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgNew(ptr %v0, ptr %t406)
  store i64 %t408, ptr %l223
  br label %bb95
bb95:
  %t409 = load i64, ptr %l223, !tbaa !24
  store i64 %t409, ptr %l14, !tbaa !24
  %t410 = load ptr, ptr %l0, !tbaa !29
  store ptr %t410, ptr %l224, !tbaa !29
  %t411 = load i64, ptr %l14, !tbaa !24
  store i64 %t411, ptr %l225, !tbaa !24
  %t412 = load ptr, ptr %l2, !tbaa !29
  store ptr %t412, ptr %l226, !tbaa !29
  %t413 = load ptr, ptr %l2, !tbaa !29
  %t414 = load i32, ptr %l3, !tbaa !23
  %t417 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t413, i32 %t414)
  store i32 %t417, ptr %l229
  br label %bb96
bb96:
  %t418 = load ptr, ptr %l226, !tbaa !29
  %t419 = load i32, ptr %l229, !tbaa !23
  %t420 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %t418, i32 %t419)
  store i64 %t420, ptr %l230
  br label %bb97
bb97:
  %t421 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d46, i32 0, i32 1) }, 1
  %t422 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d46, i32 0, i32 1) }, 0
  %t423 = load i64, ptr %l230, !tbaa !24
  %t424 = call i64 @__olang_fmt_i64(ptr null, i64 %t423)
  %t425 = add i64 %t422, %t424
  %t426 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d47, i32 0, i32 1) }, 1
  %t427 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d47, i32 0, i32 1) }, 0
  %t428 = add i64 %t425, %t427
  %t429 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t428)
  call void @olang_textcopy(ptr %t429, ptr %t421, i64 %t422)
  %t430 = getelementptr i8, ptr %t429, i64 %t422
  %t431 = call i64 @__olang_fmt_i64(ptr %t430, i64 %t423)
  %t432 = getelementptr i8, ptr %t430, i64 %t424
  call void @olang_textcopy(ptr %t432, ptr %t426, i64 %t427)
  %t433 = insertvalue { i64, ptr } undef, i64 %t428, 0
  %t434 = insertvalue { i64, ptr } %t433, ptr %t429, 1
  %t436 = extractvalue { i64, ptr } %t434, 0
  %t437 = extractvalue { i64, ptr } %t434, 1
  %t438 = mul i64 %t436, 1
  %t439 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t438)
  call void @llvm.memcpy.p0.p0.i64(ptr %t439, ptr %t437, i64 %t438, i1 false)
  %t440 = insertvalue { i64, ptr } undef, i64 %t436, 0
  %t441 = insertvalue { i64, ptr } %t440, ptr %t439, 1
  %t442 = load ptr, ptr %l224, !tbaa !29
  %t443 = load i64, ptr %l225, !tbaa !24
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgShared(ptr %v0, ptr %s11, ptr %t442, i64 %t443, { i64, ptr } %t441)
  br label %bb98
bb98:
  %t445 = load ptr, ptr %l0, !tbaa !29
  %t446 = load i64, ptr %l12, !tbaa !24
  %t447 = load i64, ptr %l13, !tbaa !24
  %t448 = load i64, ptr %l11, !tbaa !24
  %t449 = load i64, ptr %l14, !tbaa !24
  %t450 = extractvalue { i64, ptr } { i64 52, ptr getelementptr inbounds (<{ i64, [52 x i8] }>, ptr @.d48, i32 0, i32 1) }, 1
  %t451 = extractvalue { i64, ptr } { i64 52, ptr getelementptr inbounds (<{ i64, [52 x i8] }>, ptr @.d48, i32 0, i32 1) }, 0
  %t453 = call i64 @__olang_fmt_i64(ptr null, i64 %t447)
  %t454 = add i64 %t451, %t453
  %t455 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d49, i32 0, i32 1) }, 1
  %t456 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d49, i32 0, i32 1) }, 0
  %t457 = add i64 %t454, %t456
  %t459 = call i64 @__olang_fmt_i64(ptr null, i64 %t448)
  %t460 = add i64 %t457, %t459
  %t461 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d50, i32 0, i32 1) }, 1
  %t462 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d50, i32 0, i32 1) }, 0
  %t463 = add i64 %t460, %t462
  %t465 = call i64 @__olang_fmt_i64(ptr null, i64 %t449)
  %t466 = add i64 %t463, %t465
  %t467 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d51, i32 0, i32 1) }, 1
  %t468 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d51, i32 0, i32 1) }, 0
  %t469 = add i64 %t466, %t468
  %t470 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t469)
  call void @olang_textcopy(ptr %t470, ptr %t450, i64 %t451)
  %t471 = getelementptr i8, ptr %t470, i64 %t451
  %t472 = call i64 @__olang_fmt_i64(ptr %t471, i64 %t447)
  %t473 = getelementptr i8, ptr %t471, i64 %t453
  call void @olang_textcopy(ptr %t473, ptr %t455, i64 %t456)
  %t474 = getelementptr i8, ptr %t473, i64 %t456
  %t475 = call i64 @__olang_fmt_i64(ptr %t474, i64 %t448)
  %t476 = getelementptr i8, ptr %t474, i64 %t459
  call void @olang_textcopy(ptr %t476, ptr %t461, i64 %t462)
  %t477 = getelementptr i8, ptr %t476, i64 %t462
  %t478 = call i64 @__olang_fmt_i64(ptr %t477, i64 %t449)
  %t479 = getelementptr i8, ptr %t477, i64 %t465
  call void @olang_textcopy(ptr %t479, ptr %t467, i64 %t468)
  %t480 = insertvalue { i64, ptr } undef, i64 %t469, 0
  %t481 = insertvalue { i64, ptr } %t480, ptr %t470, 1
  %t483 = extractvalue { i64, ptr } %t481, 0
  %t484 = extractvalue { i64, ptr } %t481, 1
  %t485 = mul i64 %t483, 1
  %t486 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t485)
  call void @llvm.memcpy.p0.p0.i64(ptr %t486, ptr %t484, i64 %t485, i1 false)
  %t487 = insertvalue { i64, ptr } undef, i64 %t483, 0
  %t488 = insertvalue { i64, ptr } %t487, ptr %t486, 1
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgShared(ptr %v0, ptr %s11, ptr %t445, i64 %t446, { i64, ptr } %t488)
  br label %bb99
bb99:
  %t492 = load i64, ptr %l12, !tbaa !24
  call void @__olang_scope_close(ptr %s11)
  store i64 %t492, ptr %rv
  br label %ret
bb100:
  %t494 = load i32, ptr %l7
  %t496 = trunc i64 22 to i32
  %t497 = icmp eq i32 %t494, %t496
  br i1 %t497, label %bb101, label %bb102
bb101:
  store i1 true, ptr %l243, !tbaa !21
  br label %bb103
bb102:
  %t499 = load i32, ptr %l7
  %t501 = trunc i64 23 to i32
  %t502 = icmp eq i32 %t499, %t501
  store i1 %t502, ptr %l243, !tbaa !21
  br label %bb103
bb103:
  %t504 = load i1, ptr %l243, !tbaa !21
  br i1 %t504, label %bb104, label %bb105
bb104:
  store i1 true, ptr %l246, !tbaa !21
  br label %bb111
bb105:
  %t505 = load i32, ptr %l7
  %t507 = trunc i64 18 to i32
  %t508 = icmp eq i32 %t505, %t507
  br i1 %t508, label %bb106, label %bb107
bb106:
  %t510 = load ptr, ptr %l2, !tbaa !29
  store ptr %t510, ptr %l250, !tbaa !29
  %t511 = load ptr, ptr %l2, !tbaa !29
  %t512 = load i32, ptr %l3, !tbaa !23
  %t515 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t511, i32 %t512)
  store i32 %t515, ptr %l253
  br label %bb108
bb107:
  store i1 false, ptr %l249, !tbaa !21
  br label %bb110
bb108:
  %t516 = load ptr, ptr %l250, !tbaa !29
  %t517 = load i32, ptr %l253, !tbaa !23
  %t518 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t516, i32 %t517)
  store i32 %t518, ptr %l254
  br label %bb109
bb109:
  %t519 = load i32, ptr %l254
  %t521 = trunc i64 0 to i32
  %t522 = icmp eq i32 %t519, %t521
  store i1 %t522, ptr %l249, !tbaa !21
  br label %bb110
bb110:
  %t524 = load i1, ptr %l249, !tbaa !21
  store i1 %t524, ptr %l246, !tbaa !21
  br label %bb111
bb111:
  %t525 = load i1, ptr %l246, !tbaa !21
  br i1 %t525, label %bb112, label %bb113
bb112:
  store %olang.scope zeroinitializer, ptr %s16
  %t528 = load ptr, ptr %l0, !tbaa !29
  %t530 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgNew(ptr %v0, ptr %t528)
  store i64 %t530, ptr %l259
  br label %bb114
bb113:
  br label %bb158
bb114:
  %t531 = load i64, ptr %l259, !tbaa !24
  store i64 %t531, ptr %l16, !tbaa !24
  %t532 = load ptr, ptr %l0, !tbaa !29
  %t534 = getelementptr %"compiler/emit:Emitter", ptr %t532, i32 0, i32 56
  %t535 = load i32, ptr %l3, !tbaa !23
  %t537 = sext i32 %t535 to i64
  %t538 = load i64, ptr %l16, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t534, i64 %t537, i64 %t538)
  br label %bb115
bb115:
  %t542 = load ptr, ptr %l2, !tbaa !29
  store ptr %t542, ptr %l265, !tbaa !29
  %t543 = load i32, ptr %l7
  %t545 = trunc i64 18 to i32
  %t546 = icmp eq i32 %t543, %t545
  %t548 = xor i1 %t546, true
  br i1 %t548, label %bb116, label %bb117
bb116:
  %t550 = load ptr, ptr %l2, !tbaa !29
  %t551 = load i32, ptr %l3, !tbaa !23
  %t554 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t550, i32 %t551)
  store i32 %t554, ptr %l272
  br label %bb118
bb117:
  %t555 = load ptr, ptr %l2, !tbaa !29
  %t556 = load i32, ptr %l3, !tbaa !23
  %t559 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t555, i32 %t556)
  store i32 %t559, ptr %l275
  br label %bb119
bb118:
  %t560 = load i32, ptr %l272, !tbaa !23
  store i32 %t560, ptr %l269, !tbaa !23
  br label %bb120
bb119:
  %t561 = load i32, ptr %l275, !tbaa !23
  store i32 %t561, ptr %l269, !tbaa !23
  br label %bb120
bb120:
  %t562 = load ptr, ptr %l265, !tbaa !29
  %t563 = load i32, ptr %l269, !tbaa !23
  %t564 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t562, i32 %t563)
  store { i64, ptr } %t564, ptr %l276
  br label %bb121
bb121:
  %t565 = load { i64, ptr }, ptr %l276, !tbaa !27
  store { i64, ptr } %t565, ptr %l17, !tbaa !27
  %t566 = load ptr, ptr %l0, !tbaa !29
  %t567 = load i32, ptr %l3, !tbaa !23
  %t568 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t570 = extractvalue { i64, ptr } %t568, 0
  %t574 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2efieldNames(ptr %v0, ptr %s16, ptr %t566, i32 %t567, i64 %t570)
  store { i64, ptr } %t574, ptr %l281
  br label %bb122
bb122:
  %t575 = load { i64, ptr }, ptr %l281, !tbaa !27
  store { i64, ptr } %t575, ptr %l18, !tbaa !27
  %t576 = load ptr, ptr %l2, !tbaa !29
  %t577 = load i32, ptr %l3, !tbaa !23
  %t580 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOffsets(ptr %v0, ptr %s16, ptr %t576, i32 %t577)
  store { i64, ptr } %t580, ptr %l284
  br label %bb123
bb123:
  %t581 = load { i64, ptr }, ptr %l284, !tbaa !27
  store { i64, ptr } %t581, ptr %l19, !tbaa !27
  %t582 = call %"std/prelude/text:StringBuilder" @olang_2eHelperKind_2eZero_2estd_2fprelude_2ftext_3aStringBuilder(ptr %s16)
  store %"std/prelude/text:StringBuilder" %t582, ptr %l285
  br label %bb124
bb124:
  %t583 = load %"std/prelude/text:StringBuilder", ptr %l285
  store %"std/prelude/text:StringBuilder" %t583, ptr %l20
  store i64 0, ptr %l21, !tbaa !24
  %t584 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t586 = extractvalue { i64, ptr } %t584, 0
  store i64 %t586, ptr %l22, !tbaa !24
  store i64 1, ptr %l23, !tbaa !24
  %t588 = load i64, ptr %l22, !tbaa !24
  %t589 = load i64, ptr %l21, !tbaa !24
  %t592 = icmp sgt i64 %t588, %t589
  br i1 %t592, label %bb125, label %bb126
bb125:
  %t594 = load i64, ptr %l23, !tbaa !24
  %t596 = icmp sgt i64 %t594, 0
  br i1 %t596, label %bb127, label %bb128
bb126:
  store i64 0, ptr %l291, !tbaa !24
  br label %bb130
bb127:
  %t598 = load i64, ptr %l22, !tbaa !24
  %t599 = load i64, ptr %l21, !tbaa !24
  %t602 = sub i64 %t598, %t599
  %t603 = load i64, ptr %l23, !tbaa !24
  %t606 = add i64 %t602, %t603
  %t608 = sub i64 %t606, 1
  %t609 = load i64, ptr %l23, !tbaa !24
  %t612 = sdiv i64 %t608, %t609
  store i64 %t612, ptr %l294, !tbaa !24
  br label %bb129
bb128:
  store i64 0, ptr %l294, !tbaa !24
  br label %bb129
bb129:
  %t614 = load i64, ptr %l294, !tbaa !24
  store i64 %t614, ptr %l291, !tbaa !24
  br label %bb130
bb130:
  %t615 = load i64, ptr %l291, !tbaa !24
  store i64 %t615, ptr %l24, !tbaa !24
  store i64 0, ptr %l25, !tbaa !24
  br label %bb131
bb131:
  store %olang.scope zeroinitializer, ptr %s18
  %t616 = load i64, ptr %l25, !tbaa !24
  %t617 = load i64, ptr %l24, !tbaa !24
  %t620 = icmp slt i64 %t616, %t617
  %t622 = xor i1 %t620, true
  br i1 %t622, label %bb132, label %bb133
bb132:
  call void @__olang_scope_close(ptr %s18)
  br label %bb151
bb133:
  br label %bb134
bb134:
  %t624 = load i64, ptr %l21, !tbaa !24
  %t625 = load i64, ptr %l25, !tbaa !24
  %t626 = load i64, ptr %l23, !tbaa !24
  %t629 = mul i64 %t625, %t626
  %t632 = add i64 %t624, %t629
  store i64 %t632, ptr %l26, !tbaa !24
  %t634 = load ptr, ptr %l0, !tbaa !29
  %t636 = getelementptr %"compiler/emit:Emitter", ptr %t634, i32 0, i32 0
  %t637 = load ptr, ptr %t636, !tbaa !29
  %t638 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t638, ptr %l314, !tbaa !27
  %t639 = load i64, ptr %l26, !tbaa !24
  %t641 = getelementptr { i64, ptr }, ptr %l314, i32 0, i32 1
  %t642 = load ptr, ptr %t641, !tbaa !27
  %t643 = getelementptr i32, ptr %t642, i64 %t639
  %t644 = load i32, ptr %t643, !tbaa !33
  %t647 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLayout(ptr %v0, ptr %t637, i32 %t644)
  store i1 %t647, ptr %l317
  br label %bb135
bb135:
  %t648 = load ptr, ptr %l0, !tbaa !29
  %t649 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t649, ptr %l319, !tbaa !27
  %t650 = load i64, ptr %l26, !tbaa !24
  %t652 = getelementptr { i64, ptr }, ptr %l319, i32 0, i32 1
  %t653 = load ptr, ptr %t652, !tbaa !27
  %t654 = getelementptr i32, ptr %t653, i64 %t650
  %t655 = load i32, ptr %t654, !tbaa !33
  %t658 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgType(ptr %v0, ptr %t648, i32 %t655)
  store i64 %t658, ptr %l322
  br label %bb136
bb136:
  %t659 = load i64, ptr %l322, !tbaa !24
  store i64 %t659, ptr %l27, !tbaa !24
  %t660 = load i64, ptr %l27, !tbaa !24
  %t662 = icmp slt i64 %t660, 0
  br i1 %t662, label %bb137, label %bb138
bb137:
  %t664 = load ptr, ptr %l0, !tbaa !29
  %t666 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgBytes(ptr %v0, ptr %t664)
  store i64 %t666, ptr %l326
  br label %bb139
bb138:
  br label %bb140
bb139:
  %t667 = load i64, ptr %l326, !tbaa !24
  store i64 %t667, ptr %l27, !tbaa !24
  br label %bb140
bb140:
  %t668 = load ptr, ptr %l0, !tbaa !29
  %t670 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgNew(ptr %v0, ptr %t668)
  store i64 %t670, ptr %l328
  br label %bb141
bb141:
  %t671 = load i64, ptr %l328, !tbaa !24
  store i64 %t671, ptr %l28, !tbaa !24
  %t672 = load ptr, ptr %l0, !tbaa !29
  store ptr %t672, ptr %l329, !tbaa !29
  %t673 = load i64, ptr %l28, !tbaa !24
  store i64 %t673, ptr %l330, !tbaa !24
  %t674 = load i64, ptr %l26, !tbaa !24
  %t676 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t677 = load ptr, ptr %t676, !tbaa !27
  %t678 = getelementptr { i64, ptr }, ptr %t677, i64 %t674
  %t679 = load { i64, ptr }, ptr %t678, !tbaa !37
  %t681 = call { i64, ptr } @compiler_2femit_2eescape(ptr %s16, ptr %s18, { i64, ptr } %t679)
  store { i64, ptr } %t681, ptr %l333
  br label %bb142
bb142:
  %t682 = load i64, ptr %l27, !tbaa !24
  store i64 %t682, ptr %l334, !tbaa !24
  %t683 = load ptr, ptr %l2, !tbaa !29
  %t684 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t684, ptr %l336, !tbaa !27
  %t685 = load i64, ptr %l26, !tbaa !24
  %t687 = getelementptr { i64, ptr }, ptr %l336, i32 0, i32 1
  %t688 = load ptr, ptr %t687, !tbaa !27
  %t689 = getelementptr i32, ptr %t688, i64 %t685
  %t690 = load i32, ptr %t689, !tbaa !33
  %t693 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSize(ptr %v0, ptr %t683, i32 %t690)
  store i64 %t693, ptr %l339
  br label %bb143
bb143:
  %t694 = load i64, ptr %l339, !tbaa !24
  %t695 = mul i64 %t694, 8
  %t696 = load i64, ptr %l26, !tbaa !24
  %t698 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t699 = load ptr, ptr %t698, !tbaa !27
  %t700 = getelementptr i64, ptr %t699, i64 %t696
  %t701 = load i64, ptr %t700, !tbaa !34
  %t703 = mul i64 %t701, 8
  %t704 = extractvalue { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d52, i32 0, i32 1) }, 1
  %t705 = extractvalue { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d52, i32 0, i32 1) }, 0
  %t706 = load { i64, ptr }, ptr %l333, !tbaa !27
  %t707 = extractvalue { i64, ptr } %t706, 1
  %t708 = extractvalue { i64, ptr } %t706, 0
  %t709 = add i64 %t705, %t708
  %t710 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d53, i32 0, i32 1) }, 1
  %t711 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d53, i32 0, i32 1) }, 0
  %t712 = add i64 %t709, %t711
  %t713 = load i64, ptr %l334, !tbaa !24
  %t714 = call i64 @__olang_fmt_i64(ptr null, i64 %t713)
  %t715 = add i64 %t712, %t714
  %t716 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d54, i32 0, i32 1) }, 1
  %t717 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d54, i32 0, i32 1) }, 0
  %t718 = add i64 %t715, %t717
  %t720 = call i64 @__olang_fmt_i64(ptr null, i64 %t695)
  %t721 = add i64 %t718, %t720
  %t722 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d55, i32 0, i32 1) }, 1
  %t723 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d55, i32 0, i32 1) }, 0
  %t724 = add i64 %t721, %t723
  %t726 = call i64 @__olang_fmt_i64(ptr null, i64 %t703)
  %t727 = add i64 %t724, %t726
  %t728 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d56, i32 0, i32 1) }, 1
  %t729 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d56, i32 0, i32 1) }, 0
  %t730 = add i64 %t727, %t729
  %t731 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t730)
  call void @olang_textcopy(ptr %t731, ptr %t704, i64 %t705)
  %t732 = getelementptr i8, ptr %t731, i64 %t705
  call void @olang_textcopy(ptr %t732, ptr %t707, i64 %t708)
  %t733 = getelementptr i8, ptr %t732, i64 %t708
  call void @olang_textcopy(ptr %t733, ptr %t710, i64 %t711)
  %t734 = getelementptr i8, ptr %t733, i64 %t711
  %t735 = call i64 @__olang_fmt_i64(ptr %t734, i64 %t713)
  %t736 = getelementptr i8, ptr %t734, i64 %t714
  call void @olang_textcopy(ptr %t736, ptr %t716, i64 %t717)
  %t737 = getelementptr i8, ptr %t736, i64 %t717
  %t738 = call i64 @__olang_fmt_i64(ptr %t737, i64 %t695)
  %t739 = getelementptr i8, ptr %t737, i64 %t720
  call void @olang_textcopy(ptr %t739, ptr %t722, i64 %t723)
  %t740 = getelementptr i8, ptr %t739, i64 %t723
  %t741 = call i64 @__olang_fmt_i64(ptr %t740, i64 %t703)
  %t742 = getelementptr i8, ptr %t740, i64 %t726
  call void @olang_textcopy(ptr %t742, ptr %t728, i64 %t729)
  %t743 = insertvalue { i64, ptr } undef, i64 %t730, 0
  %t744 = insertvalue { i64, ptr } %t743, ptr %t731, 1
  %t746 = extractvalue { i64, ptr } %t744, 0
  %t747 = extractvalue { i64, ptr } %t744, 1
  %t748 = mul i64 %t746, 1
  %t749 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t748)
  call void @llvm.memcpy.p0.p0.i64(ptr %t749, ptr %t747, i64 %t748, i1 false)
  %t750 = insertvalue { i64, ptr } undef, i64 %t746, 0
  %t751 = insertvalue { i64, ptr } %t750, ptr %t749, 1
  %t752 = load ptr, ptr %l329, !tbaa !29
  %t753 = load i64, ptr %l330, !tbaa !24
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgShared(ptr %v0, ptr %s18, ptr %t752, i64 %t753, { i64, ptr } %t751)
  br label %bb144
bb144:
  %t755 = load i64, ptr %l26, !tbaa !24
  %t757 = icmp sgt i64 %t755, 0
  br i1 %t757, label %bb145, label %bb146
bb145:
  store %olang.scope zeroinitializer, ptr %s21
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s16, ptr %s21, ptr %l20, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d57, i32 0, i32 1) })
  br label %bb147
bb146:
  br label %bb148
bb147:
  call void @__olang_scope_close(ptr %s21)
  br label %bb148
bb148:
  %t760 = load i64, ptr %l28, !tbaa !24
  %t761 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d58, i32 0, i32 1) }, 1
  %t762 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d58, i32 0, i32 1) }, 0
  %t764 = call i64 @__olang_fmt_i64(ptr null, i64 %t760)
  %t765 = add i64 %t762, %t764
  %t766 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t765)
  call void @olang_textcopy(ptr %t766, ptr %t761, i64 %t762)
  %t767 = getelementptr i8, ptr %t766, i64 %t762
  %t768 = call i64 @__olang_fmt_i64(ptr %t767, i64 %t760)
  %t769 = insertvalue { i64, ptr } undef, i64 %t765, 0
  %t770 = insertvalue { i64, ptr } %t769, ptr %t766, 1
  %t772 = extractvalue { i64, ptr } %t770, 0
  %t773 = extractvalue { i64, ptr } %t770, 1
  %t774 = mul i64 %t772, 1
  %t775 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t774)
  call void @llvm.memcpy.p0.p0.i64(ptr %t775, ptr %t773, i64 %t774, i1 false)
  %t776 = insertvalue { i64, ptr } undef, i64 %t772, 0
  %t777 = insertvalue { i64, ptr } %t776, ptr %t775, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s16, ptr %s18, ptr %l20, { i64, ptr } %t777)
  br label %bb149
bb149:
  call void @__olang_scope_close(ptr %s18)
  br label %bb150
bb150:
  %t780 = load i64, ptr %l25, !tbaa !24
  %t782 = add i64 %t780, 1
  store i64 %t782, ptr %l25, !tbaa !24
  br label %bb131
bb151:
  %t784 = load ptr, ptr %l0, !tbaa !29
  %t786 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgNew(ptr %v0, ptr %t784)
  store i64 %t786, ptr %l356
  br label %bb152
bb152:
  %t787 = load i64, ptr %l356, !tbaa !24
  store i64 %t787, ptr %l29, !tbaa !24
  %t788 = load ptr, ptr %l0, !tbaa !29
  store ptr %t788, ptr %l357, !tbaa !29
  %t789 = load i64, ptr %l29, !tbaa !24
  store i64 %t789, ptr %l358, !tbaa !24
  %t791 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s16, ptr %s16, ptr %l20)
  store { i64, ptr } %t791, ptr %l360
  br label %bb153
bb153:
  %t792 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d59, i32 0, i32 1) }, 1
  %t793 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d59, i32 0, i32 1) }, 0
  %t794 = load { i64, ptr }, ptr %l360, !tbaa !27
  %t795 = extractvalue { i64, ptr } %t794, 1
  %t796 = extractvalue { i64, ptr } %t794, 0
  %t797 = add i64 %t793, %t796
  %t798 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d60, i32 0, i32 1) }, 1
  %t799 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d60, i32 0, i32 1) }, 0
  %t800 = add i64 %t797, %t799
  %t801 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t800)
  call void @olang_textcopy(ptr %t801, ptr %t792, i64 %t793)
  %t802 = getelementptr i8, ptr %t801, i64 %t793
  call void @olang_textcopy(ptr %t802, ptr %t795, i64 %t796)
  %t803 = getelementptr i8, ptr %t802, i64 %t796
  call void @olang_textcopy(ptr %t803, ptr %t798, i64 %t799)
  %t804 = insertvalue { i64, ptr } undef, i64 %t800, 0
  %t805 = insertvalue { i64, ptr } %t804, ptr %t801, 1
  %t807 = extractvalue { i64, ptr } %t805, 0
  %t808 = extractvalue { i64, ptr } %t805, 1
  %t809 = mul i64 %t807, 1
  %t810 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t809)
  call void @llvm.memcpy.p0.p0.i64(ptr %t810, ptr %t808, i64 %t809, i1 false)
  %t811 = insertvalue { i64, ptr } undef, i64 %t807, 0
  %t812 = insertvalue { i64, ptr } %t811, ptr %t810, 1
  %t813 = load ptr, ptr %l357, !tbaa !29
  %t814 = load i64, ptr %l358, !tbaa !24
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgShared(ptr %v0, ptr %s16, ptr %t813, i64 %t814, { i64, ptr } %t812)
  br label %bb154
bb154:
  %t816 = load ptr, ptr %l0, !tbaa !29
  store ptr %t816, ptr %l363, !tbaa !29
  %t817 = load i64, ptr %l16, !tbaa !24
  store i64 %t817, ptr %l364, !tbaa !24
  %t818 = load ptr, ptr %l0, !tbaa !29
  %t819 = load i32, ptr %l3, !tbaa !23
  %t822 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgTypeName(ptr %v0, ptr %s16, ptr %t818, i32 %t819)
  store { i64, ptr } %t822, ptr %l367
  br label %bb155
bb155:
  %t823 = load { i64, ptr }, ptr %l367, !tbaa !27
  %t824 = extractvalue { i64, ptr } %t823, 0
  %t825 = extractvalue { i64, ptr } %t823, 1
  %t826 = mul i64 %t824, 1
  %t827 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t826)
  call void @llvm.memcpy.p0.p0.i64(ptr %t827, ptr %t825, i64 %t826, i1 false)
  %t828 = insertvalue { i64, ptr } undef, i64 %t824, 0
  %t829 = insertvalue { i64, ptr } %t828, ptr %t827, 1
  %t831 = call { i64, ptr } @compiler_2femit_2eescape(ptr %s16, ptr %s16, { i64, ptr } %t829)
  store { i64, ptr } %t831, ptr %l369
  br label %bb156
bb156:
  %t832 = load i64, ptr %l11, !tbaa !24
  %t833 = load i64, ptr %l29, !tbaa !24
  %t834 = extractvalue { i64, ptr } { i64 52, ptr getelementptr inbounds (<{ i64, [52 x i8] }>, ptr @.d61, i32 0, i32 1) }, 1
  %t835 = extractvalue { i64, ptr } { i64 52, ptr getelementptr inbounds (<{ i64, [52 x i8] }>, ptr @.d61, i32 0, i32 1) }, 0
  %t836 = load { i64, ptr }, ptr %l369, !tbaa !27
  %t837 = extractvalue { i64, ptr } %t836, 1
  %t838 = extractvalue { i64, ptr } %t836, 0
  %t839 = add i64 %t835, %t838
  %t840 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d62, i32 0, i32 1) }, 1
  %t841 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d62, i32 0, i32 1) }, 0
  %t842 = add i64 %t839, %t841
  %t844 = call i64 @__olang_fmt_i64(ptr null, i64 %t832)
  %t845 = add i64 %t842, %t844
  %t846 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d63, i32 0, i32 1) }, 1
  %t847 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d63, i32 0, i32 1) }, 0
  %t848 = add i64 %t845, %t847
  %t850 = call i64 @__olang_fmt_i64(ptr null, i64 %t833)
  %t851 = add i64 %t848, %t850
  %t852 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d64, i32 0, i32 1) }, 1
  %t853 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d64, i32 0, i32 1) }, 0
  %t854 = add i64 %t851, %t853
  %t855 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t854)
  call void @olang_textcopy(ptr %t855, ptr %t834, i64 %t835)
  %t856 = getelementptr i8, ptr %t855, i64 %t835
  call void @olang_textcopy(ptr %t856, ptr %t837, i64 %t838)
  %t857 = getelementptr i8, ptr %t856, i64 %t838
  call void @olang_textcopy(ptr %t857, ptr %t840, i64 %t841)
  %t858 = getelementptr i8, ptr %t857, i64 %t841
  %t859 = call i64 @__olang_fmt_i64(ptr %t858, i64 %t832)
  %t860 = getelementptr i8, ptr %t858, i64 %t844
  call void @olang_textcopy(ptr %t860, ptr %t846, i64 %t847)
  %t861 = getelementptr i8, ptr %t860, i64 %t847
  %t862 = call i64 @__olang_fmt_i64(ptr %t861, i64 %t833)
  %t863 = getelementptr i8, ptr %t861, i64 %t850
  call void @olang_textcopy(ptr %t863, ptr %t852, i64 %t853)
  %t864 = insertvalue { i64, ptr } undef, i64 %t854, 0
  %t865 = insertvalue { i64, ptr } %t864, ptr %t855, 1
  %t867 = extractvalue { i64, ptr } %t865, 0
  %t868 = extractvalue { i64, ptr } %t865, 1
  %t869 = mul i64 %t867, 1
  %t870 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t869)
  call void @llvm.memcpy.p0.p0.i64(ptr %t870, ptr %t868, i64 %t869, i1 false)
  %t871 = insertvalue { i64, ptr } undef, i64 %t867, 0
  %t872 = insertvalue { i64, ptr } %t871, ptr %t870, 1
  %t873 = load ptr, ptr %l363, !tbaa !29
  %t874 = load i64, ptr %l364, !tbaa !24
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgShared(ptr %v0, ptr %s16, ptr %t873, i64 %t874, { i64, ptr } %t872)
  br label %bb157
bb157:
  %t876 = load i64, ptr %l16, !tbaa !24
  call void @__olang_scope_close(ptr %s16)
  store i64 %t876, ptr %rv
  br label %ret
bb158:
  %t878 = load i32, ptr %l7
  %t880 = trunc i64 24 to i32
  %t881 = icmp eq i32 %t878, %t880
  br i1 %t881, label %bb159, label %bb160
bb159:
  store i1 true, ptr %l377, !tbaa !21
  br label %bb166
bb160:
  %t883 = load i32, ptr %l7
  %t885 = trunc i64 18 to i32
  %t886 = icmp eq i32 %t883, %t885
  br i1 %t886, label %bb161, label %bb162
bb161:
  %t888 = load ptr, ptr %l2, !tbaa !29
  store ptr %t888, ptr %l381, !tbaa !29
  %t889 = load ptr, ptr %l2, !tbaa !29
  %t890 = load i32, ptr %l3, !tbaa !23
  %t893 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t889, i32 %t890)
  store i32 %t893, ptr %l384
  br label %bb163
bb162:
  store i1 false, ptr %l380, !tbaa !21
  br label %bb165
bb163:
  %t894 = load ptr, ptr %l381, !tbaa !29
  %t895 = load i32, ptr %l384, !tbaa !23
  %t896 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t894, i32 %t895)
  store i32 %t896, ptr %l385
  br label %bb164
bb164:
  %t897 = load i32, ptr %l385
  %t899 = trunc i64 1 to i32
  %t900 = icmp eq i32 %t897, %t899
  store i1 %t900, ptr %l380, !tbaa !21
  br label %bb165
bb165:
  %t902 = load i1, ptr %l380, !tbaa !21
  store i1 %t902, ptr %l377, !tbaa !21
  br label %bb166
bb166:
  %t903 = load i1, ptr %l377, !tbaa !21
  br i1 %t903, label %bb167, label %bb168
bb167:
  store %olang.scope zeroinitializer, ptr %s26
  %t906 = load ptr, ptr %l0, !tbaa !29
  %t908 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgNew(ptr %v0, ptr %t906)
  store i64 %t908, ptr %l390
  br label %bb169
bb168:
  br label %bb252
bb169:
  %t909 = load i64, ptr %l390, !tbaa !24
  store i64 %t909, ptr %l31, !tbaa !24
  %t910 = load ptr, ptr %l0, !tbaa !29
  %t912 = getelementptr %"compiler/emit:Emitter", ptr %t910, i32 0, i32 56
  %t913 = load i32, ptr %l3, !tbaa !23
  %t915 = sext i32 %t913 to i64
  %t916 = load i64, ptr %l31, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t912, i64 %t915, i64 %t916)
  br label %bb170
bb170:
  %t920 = load i32, ptr %l7
  %t922 = trunc i64 18 to i32
  %t923 = icmp eq i32 %t920, %t922
  br i1 %t923, label %bb171, label %bb172
bb171:
  %t925 = load ptr, ptr %l2, !tbaa !29
  %t926 = load i32, ptr %l3, !tbaa !23
  %t929 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCaseNames(ptr %v0, ptr %t925, i32 %t926)
  store { i64, ptr } %t929, ptr %l401
  br label %bb173
bb172:
  %t930 = icmp sge i64 0, 0
  br i1 %t930, label %bb174, label %bb175
bb173:
  %t932 = load { i64, ptr }, ptr %l401, !tbaa !27
  store { i64, ptr } %t932, ptr %l398, !tbaa !27
  br label %bb178
bb174:
  %t933 = icmp sle i64 0, 2305843009213693951
  br i1 %t933, label %bb176, label %bb177
bb175:
  call void @__olang_check_failed(ptr @olang_loc_649f734ddce51468_b7eb8be07e4dd31c)
  unreachable
bb176:
  %t935 = mul i64 0, 4
  %t936 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t935)
  %t937 = insertvalue { i64, ptr } undef, i64 0, 0
  %t938 = insertvalue { i64, ptr } %t937, ptr %t936, 1
  store { i64, ptr } %t938, ptr %l398, !tbaa !27
  br label %bb178
bb177:
  call void @__olang_check_failed(ptr @olang_loc_649f734ddce51468_b7eb8be07e4dd31c)
  unreachable
bb178:
  %t940 = load { i64, ptr }, ptr %l398, !tbaa !27
  store { i64, ptr } %t940, ptr %l32, !tbaa !27
  %t941 = load ptr, ptr %l2, !tbaa !29
  store ptr %t941, ptr %l405, !tbaa !29
  %t942 = load i32, ptr %l7
  %t944 = trunc i64 24 to i32
  %t945 = icmp eq i32 %t942, %t944
  br i1 %t945, label %bb179, label %bb180
bb179:
  %t947 = load ptr, ptr %l2, !tbaa !29
  %t948 = load i32, ptr %l3, !tbaa !23
  %t951 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %t947, i32 %t948)
  store i32 %t951, ptr %l411
  br label %bb181
bb180:
  %t952 = load ptr, ptr %l2, !tbaa !29
  %t953 = load i32, ptr %l3, !tbaa !23
  %t956 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t952, i32 %t953)
  store i32 %t956, ptr %l414
  br label %bb182
bb181:
  %t957 = load i32, ptr %l411, !tbaa !23
  store i32 %t957, ptr %l408, !tbaa !23
  br label %bb183
bb182:
  %t958 = load i32, ptr %l414, !tbaa !23
  store i32 %t958, ptr %l408, !tbaa !23
  br label %bb183
bb183:
  %t959 = load ptr, ptr %l405, !tbaa !29
  %t960 = load i32, ptr %l408, !tbaa !23
  %t961 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t959, i32 %t960)
  store { i64, ptr } %t961, ptr %l415
  br label %bb184
bb184:
  %t962 = load { i64, ptr }, ptr %l415, !tbaa !27
  store { i64, ptr } %t962, ptr %l33, !tbaa !27
  %t963 = call %"std/prelude/text:StringBuilder" @olang_2eHelperKind_2eZero_2estd_2fprelude_2ftext_3aStringBuilder(ptr %s26)
  store %"std/prelude/text:StringBuilder" %t963, ptr %l416
  br label %bb185
bb185:
  %t964 = load %"std/prelude/text:StringBuilder", ptr %l416
  store %"std/prelude/text:StringBuilder" %t964, ptr %l34
  store i64 0, ptr %l35, !tbaa !24
  %t965 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t967 = extractvalue { i64, ptr } %t965, 0
  store i64 %t967, ptr %l36, !tbaa !24
  store i64 1, ptr %l37, !tbaa !24
  %t969 = load i64, ptr %l36, !tbaa !24
  %t970 = load i64, ptr %l35, !tbaa !24
  %t973 = icmp sgt i64 %t969, %t970
  br i1 %t973, label %bb186, label %bb187
bb186:
  %t975 = load i64, ptr %l37, !tbaa !24
  %t977 = icmp sgt i64 %t975, 0
  br i1 %t977, label %bb188, label %bb189
bb187:
  store i64 0, ptr %l422, !tbaa !24
  br label %bb191
bb188:
  %t979 = load i64, ptr %l36, !tbaa !24
  %t980 = load i64, ptr %l35, !tbaa !24
  %t983 = sub i64 %t979, %t980
  %t984 = load i64, ptr %l37, !tbaa !24
  %t987 = add i64 %t983, %t984
  %t989 = sub i64 %t987, 1
  %t990 = load i64, ptr %l37, !tbaa !24
  %t993 = sdiv i64 %t989, %t990
  store i64 %t993, ptr %l425, !tbaa !24
  br label %bb190
bb189:
  store i64 0, ptr %l425, !tbaa !24
  br label %bb190
bb190:
  %t995 = load i64, ptr %l425, !tbaa !24
  store i64 %t995, ptr %l422, !tbaa !24
  br label %bb191
bb191:
  %t996 = load i64, ptr %l422, !tbaa !24
  store i64 %t996, ptr %l38, !tbaa !24
  store i64 0, ptr %l39, !tbaa !24
  br label %bb192
bb192:
  store %olang.scope zeroinitializer, ptr %s28
  %t997 = load i64, ptr %l39, !tbaa !24
  %t998 = load i64, ptr %l38, !tbaa !24
  %t1001 = icmp slt i64 %t997, %t998
  %t1003 = xor i1 %t1001, true
  br i1 %t1003, label %bb193, label %bb194
bb193:
  call void @__olang_scope_close(ptr %s28)
  br label %bb212
bb194:
  br label %bb195
bb195:
  %t1005 = load i64, ptr %l35, !tbaa !24
  %t1006 = load i64, ptr %l39, !tbaa !24
  %t1007 = load i64, ptr %l37, !tbaa !24
  %t1010 = mul i64 %t1006, %t1007
  %t1013 = add i64 %t1005, %t1010
  store i64 %t1013, ptr %l40, !tbaa !24
  %t1015 = load ptr, ptr %l0, !tbaa !29
  %t1017 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgNew(ptr %v0, ptr %t1015)
  store i64 %t1017, ptr %l444
  br label %bb196
bb196:
  %t1018 = load i64, ptr %l444, !tbaa !24
  store i64 %t1018, ptr %l41, !tbaa !24
  %t1019 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t1021 = extractvalue { i64, ptr } %t1019, 0
  %t1023 = icmp sgt i64 %t1021, 0
  br i1 %t1023, label %bb197, label %bb198
bb197:
  %t1025 = load i64, ptr %l40, !tbaa !24
  %t1026 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t1028 = extractvalue { i64, ptr } %t1026, 0
  %t1031 = icmp slt i64 %t1025, %t1028
  store i1 %t1031, ptr %l448, !tbaa !21
  br label %bb199
bb198:
  store i1 false, ptr %l448, !tbaa !21
  br label %bb199
bb199:
  %t1033 = load i1, ptr %l448, !tbaa !21
  br i1 %t1033, label %bb200, label %bb201
bb200:
  %t1034 = load ptr, ptr %l0, !tbaa !29
  %t1035 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t1035, ptr %l455, !tbaa !27
  %t1036 = load i64, ptr %l40, !tbaa !24
  %t1038 = getelementptr { i64, ptr }, ptr %l455, i32 0, i32 1
  %t1039 = load ptr, ptr %t1038, !tbaa !27
  %t1040 = getelementptr i32, ptr %t1039, i64 %t1036
  %t1041 = load i32, ptr %t1040, !tbaa !33
  %t1044 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etext(ptr %v0, ptr %t1034, i32 %t1041)
  store { i64, ptr } %t1044, ptr %l458
  br label %bb202
bb201:
  %t1045 = load i64, ptr %l40, !tbaa !24
  %t1047 = call i64 @__olang_fmt_i64(ptr null, i64 %t1045)
  %t1048 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t1047)
  %t1049 = call i64 @__olang_fmt_i64(ptr %t1048, i64 %t1045)
  %t1050 = insertvalue { i64, ptr } undef, i64 %t1047, 0
  %t1051 = insertvalue { i64, ptr } %t1050, ptr %t1048, 1
  %t1053 = extractvalue { i64, ptr } %t1051, 0
  %t1054 = extractvalue { i64, ptr } %t1051, 1
  %t1055 = mul i64 %t1053, 1
  %t1056 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t1055)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1056, ptr %t1054, i64 %t1055, i1 false)
  %t1057 = insertvalue { i64, ptr } undef, i64 %t1053, 0
  %t1058 = insertvalue { i64, ptr } %t1057, ptr %t1056, 1
  store { i64, ptr } %t1058, ptr %l453, !tbaa !27
  br label %bb203
bb202:
  %t1060 = load { i64, ptr }, ptr %l458, !tbaa !27
  store { i64, ptr } %t1060, ptr %l453, !tbaa !27
  br label %bb203
bb203:
  %t1061 = load { i64, ptr }, ptr %l453, !tbaa !27
  %t1062 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1062, ptr %l462, !tbaa !29
  %t1063 = load i64, ptr %l41, !tbaa !24
  store i64 %t1063, ptr %l463, !tbaa !24
  %t1066 = call { i64, ptr } @compiler_2femit_2eescape(ptr %v0, ptr %s28, { i64, ptr } %t1061)
  store { i64, ptr } %t1066, ptr %l465
  br label %bb204
bb204:
  %t1067 = load i64, ptr %l40, !tbaa !24
  %t1068 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d65, i32 0, i32 1) }, 1
  %t1069 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d65, i32 0, i32 1) }, 0
  %t1070 = load { i64, ptr }, ptr %l465, !tbaa !27
  %t1071 = extractvalue { i64, ptr } %t1070, 1
  %t1072 = extractvalue { i64, ptr } %t1070, 0
  %t1073 = add i64 %t1069, %t1072
  %t1074 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d66, i32 0, i32 1) }, 1
  %t1075 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d66, i32 0, i32 1) }, 0
  %t1076 = add i64 %t1073, %t1075
  %t1078 = call i64 @__olang_fmt_i64(ptr null, i64 %t1067)
  %t1079 = add i64 %t1076, %t1078
  %t1080 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d67, i32 0, i32 1) }, 1
  %t1081 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d67, i32 0, i32 1) }, 0
  %t1082 = add i64 %t1079, %t1081
  %t1083 = call ptr @__olang_scope_alloc(ptr %s28, i64 %t1082)
  call void @olang_textcopy(ptr %t1083, ptr %t1068, i64 %t1069)
  %t1084 = getelementptr i8, ptr %t1083, i64 %t1069
  call void @olang_textcopy(ptr %t1084, ptr %t1071, i64 %t1072)
  %t1085 = getelementptr i8, ptr %t1084, i64 %t1072
  call void @olang_textcopy(ptr %t1085, ptr %t1074, i64 %t1075)
  %t1086 = getelementptr i8, ptr %t1085, i64 %t1075
  %t1087 = call i64 @__olang_fmt_i64(ptr %t1086, i64 %t1067)
  %t1088 = getelementptr i8, ptr %t1086, i64 %t1078
  call void @olang_textcopy(ptr %t1088, ptr %t1080, i64 %t1081)
  %t1089 = insertvalue { i64, ptr } undef, i64 %t1082, 0
  %t1090 = insertvalue { i64, ptr } %t1089, ptr %t1083, 1
  %t1092 = extractvalue { i64, ptr } %t1090, 0
  %t1093 = extractvalue { i64, ptr } %t1090, 1
  %t1094 = mul i64 %t1092, 1
  %t1095 = call ptr @__olang_scope_alloc(ptr %s28, i64 %t1094)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1095, ptr %t1093, i64 %t1094, i1 false)
  %t1096 = insertvalue { i64, ptr } undef, i64 %t1092, 0
  %t1097 = insertvalue { i64, ptr } %t1096, ptr %t1095, 1
  %t1098 = load ptr, ptr %l462, !tbaa !29
  %t1099 = load i64, ptr %l463, !tbaa !24
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgShared(ptr %v0, ptr %s28, ptr %t1098, i64 %t1099, { i64, ptr } %t1097)
  br label %bb205
bb205:
  %t1101 = load i64, ptr %l40, !tbaa !24
  %t1103 = icmp sgt i64 %t1101, 0
  br i1 %t1103, label %bb206, label %bb207
bb206:
  store %olang.scope zeroinitializer, ptr %s31
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s26, ptr %s31, ptr %l34, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d68, i32 0, i32 1) })
  br label %bb208
bb207:
  br label %bb209
bb208:
  call void @__olang_scope_close(ptr %s31)
  br label %bb209
bb209:
  %t1106 = load i64, ptr %l41, !tbaa !24
  %t1107 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d69, i32 0, i32 1) }, 1
  %t1108 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d69, i32 0, i32 1) }, 0
  %t1110 = call i64 @__olang_fmt_i64(ptr null, i64 %t1106)
  %t1111 = add i64 %t1108, %t1110
  %t1112 = call ptr @__olang_scope_alloc(ptr %s28, i64 %t1111)
  call void @olang_textcopy(ptr %t1112, ptr %t1107, i64 %t1108)
  %t1113 = getelementptr i8, ptr %t1112, i64 %t1108
  %t1114 = call i64 @__olang_fmt_i64(ptr %t1113, i64 %t1106)
  %t1115 = insertvalue { i64, ptr } undef, i64 %t1111, 0
  %t1116 = insertvalue { i64, ptr } %t1115, ptr %t1112, 1
  %t1118 = extractvalue { i64, ptr } %t1116, 0
  %t1119 = extractvalue { i64, ptr } %t1116, 1
  %t1120 = mul i64 %t1118, 1
  %t1121 = call ptr @__olang_scope_alloc(ptr %s28, i64 %t1120)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1121, ptr %t1119, i64 %t1120, i1 false)
  %t1122 = insertvalue { i64, ptr } undef, i64 %t1118, 0
  %t1123 = insertvalue { i64, ptr } %t1122, ptr %t1121, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s26, ptr %s28, ptr %l34, { i64, ptr } %t1123)
  br label %bb210
bb210:
  call void @__olang_scope_close(ptr %s28)
  br label %bb211
bb211:
  %t1126 = load i64, ptr %l39, !tbaa !24
  %t1128 = add i64 %t1126, 1
  store i64 %t1128, ptr %l39, !tbaa !24
  br label %bb192
bb212:
  %t1130 = load ptr, ptr %l0, !tbaa !29
  %t1132 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgNew(ptr %v0, ptr %t1130)
  store i64 %t1132, ptr %l479
  br label %bb213
bb213:
  %t1133 = load i64, ptr %l479, !tbaa !24
  store i64 %t1133, ptr %l43, !tbaa !24
  %t1134 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1134, ptr %l480, !tbaa !29
  %t1135 = load i64, ptr %l43, !tbaa !24
  store i64 %t1135, ptr %l481, !tbaa !24
  %t1137 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s26, ptr %s26, ptr %l34)
  store { i64, ptr } %t1137, ptr %l483
  br label %bb214
bb214:
  %t1138 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d70, i32 0, i32 1) }, 1
  %t1139 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d70, i32 0, i32 1) }, 0
  %t1140 = load { i64, ptr }, ptr %l483, !tbaa !27
  %t1141 = extractvalue { i64, ptr } %t1140, 1
  %t1142 = extractvalue { i64, ptr } %t1140, 0
  %t1143 = add i64 %t1139, %t1142
  %t1144 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d71, i32 0, i32 1) }, 1
  %t1145 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d71, i32 0, i32 1) }, 0
  %t1146 = add i64 %t1143, %t1145
  %t1147 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t1146)
  call void @olang_textcopy(ptr %t1147, ptr %t1138, i64 %t1139)
  %t1148 = getelementptr i8, ptr %t1147, i64 %t1139
  call void @olang_textcopy(ptr %t1148, ptr %t1141, i64 %t1142)
  %t1149 = getelementptr i8, ptr %t1148, i64 %t1142
  call void @olang_textcopy(ptr %t1149, ptr %t1144, i64 %t1145)
  %t1150 = insertvalue { i64, ptr } undef, i64 %t1146, 0
  %t1151 = insertvalue { i64, ptr } %t1150, ptr %t1147, 1
  %t1153 = extractvalue { i64, ptr } %t1151, 0
  %t1154 = extractvalue { i64, ptr } %t1151, 1
  %t1155 = mul i64 %t1153, 1
  %t1156 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t1155)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1156, ptr %t1154, i64 %t1155, i1 false)
  %t1157 = insertvalue { i64, ptr } undef, i64 %t1153, 0
  %t1158 = insertvalue { i64, ptr } %t1157, ptr %t1156, 1
  %t1159 = load ptr, ptr %l480, !tbaa !29
  %t1160 = load i64, ptr %l481, !tbaa !24
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgShared(ptr %v0, ptr %s26, ptr %t1159, i64 %t1160, { i64, ptr } %t1158)
  br label %bb215
bb215:
  %t1162 = load ptr, ptr %l0, !tbaa !29
  %t1163 = load i32, ptr %l3, !tbaa !23
  %t1166 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eenumWords(ptr %v0, ptr %t1162, i32 %t1163)
  store i1 %t1166, ptr %l488
  br label %bb216
bb216:
  %t1167 = load i1, ptr %l488, !tbaa !21
  store i1 %t1167, ptr %l44, !tbaa !21
  %t1168 = load i1, ptr %l44, !tbaa !21
  %t1170 = xor i1 %t1168, true
  br i1 %t1170, label %bb217, label %bb218
bb217:
  %t1172 = load i64, ptr %l31, !tbaa !24
  store i64 %t1172, ptr %l491, !tbaa !24
  br label %bb220
bb218:
  %t1174 = load ptr, ptr %l0, !tbaa !29
  %t1176 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgNew(ptr %v0, ptr %t1174)
  store i64 %t1176, ptr %l494
  br label %bb219
bb219:
  %t1177 = load i64, ptr %l494, !tbaa !24
  store i64 %t1177, ptr %l491, !tbaa !24
  br label %bb220
bb220:
  %t1178 = load i64, ptr %l491, !tbaa !24
  store i64 %t1178, ptr %l45, !tbaa !24
  %t1179 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1179, ptr %l495, !tbaa !29
  %t1180 = load i1, ptr %l44, !tbaa !21
  br i1 %t1180, label %bb221, label %bb222
bb221:
  %t1182 = load ptr, ptr %l2, !tbaa !29
  %t1184 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s26, ptr %t1182, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d72, i32 0, i32 1) })
  store i32 %t1184, ptr %l499
  br label %bb223
bb222:
  %t1185 = load ptr, ptr %l2, !tbaa !29
  %t1187 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s26, ptr %t1185, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d73, i32 0, i32 1) })
  store i32 %t1187, ptr %l501
  br label %bb224
bb223:
  %t1188 = load i32, ptr %l499, !tbaa !23
  store i32 %t1188, ptr %l497, !tbaa !23
  br label %bb225
bb224:
  %t1189 = load i32, ptr %l501, !tbaa !23
  store i32 %t1189, ptr %l497, !tbaa !23
  br label %bb225
bb225:
  %t1190 = load ptr, ptr %l495, !tbaa !29
  %t1191 = load i32, ptr %l497, !tbaa !23
  %t1192 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgType(ptr %v0, ptr %t1190, i32 %t1191)
  store i64 %t1192, ptr %l502
  br label %bb226
bb226:
  %t1193 = load i64, ptr %l502, !tbaa !24
  store i64 %t1193, ptr %l46, !tbaa !24
  %t1194 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1194, ptr %l503, !tbaa !29
  %t1195 = load i64, ptr %l45, !tbaa !24
  store i64 %t1195, ptr %l504, !tbaa !24
  %t1196 = load ptr, ptr %l0, !tbaa !29
  %t1197 = load i32, ptr %l3, !tbaa !23
  %t1200 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgTypeName(ptr %v0, ptr %s26, ptr %t1196, i32 %t1197)
  store { i64, ptr } %t1200, ptr %l507
  br label %bb227
bb227:
  %t1201 = load { i64, ptr }, ptr %l507, !tbaa !27
  %t1202 = extractvalue { i64, ptr } %t1201, 0
  %t1203 = extractvalue { i64, ptr } %t1201, 1
  %t1204 = mul i64 %t1202, 1
  %t1205 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t1204)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1205, ptr %t1203, i64 %t1204, i1 false)
  %t1206 = insertvalue { i64, ptr } undef, i64 %t1202, 0
  %t1207 = insertvalue { i64, ptr } %t1206, ptr %t1205, 1
  %t1209 = call { i64, ptr } @compiler_2femit_2eescape(ptr %s26, ptr %s26, { i64, ptr } %t1207)
  store { i64, ptr } %t1209, ptr %l509
  br label %bb228
bb228:
  %t1210 = load i1, ptr %l44, !tbaa !21
  br i1 %t1210, label %bb229, label %bb230
bb229:
  store i64 64, ptr %l511, !tbaa !24
  br label %bb231
bb230:
  store i64 32, ptr %l511, !tbaa !24
  br label %bb231
bb231:
  %t1212 = load i64, ptr %l46, !tbaa !24
  %t1213 = load i64, ptr %l43, !tbaa !24
  %t1214 = extractvalue { i64, ptr } { i64 54, ptr getelementptr inbounds (<{ i64, [54 x i8] }>, ptr @.d74, i32 0, i32 1) }, 1
  %t1215 = extractvalue { i64, ptr } { i64 54, ptr getelementptr inbounds (<{ i64, [54 x i8] }>, ptr @.d74, i32 0, i32 1) }, 0
  %t1216 = load { i64, ptr }, ptr %l509, !tbaa !27
  %t1217 = extractvalue { i64, ptr } %t1216, 1
  %t1218 = extractvalue { i64, ptr } %t1216, 0
  %t1219 = add i64 %t1215, %t1218
  %t1220 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d75, i32 0, i32 1) }, 1
  %t1221 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d75, i32 0, i32 1) }, 0
  %t1222 = add i64 %t1219, %t1221
  %t1223 = load i64, ptr %l511, !tbaa !24
  %t1224 = call i64 @__olang_fmt_i64(ptr null, i64 %t1223)
  %t1225 = add i64 %t1222, %t1224
  %t1226 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d76, i32 0, i32 1) }, 1
  %t1227 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d76, i32 0, i32 1) }, 0
  %t1228 = add i64 %t1225, %t1227
  %t1230 = call i64 @__olang_fmt_i64(ptr null, i64 %t1212)
  %t1231 = add i64 %t1228, %t1230
  %t1232 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d77, i32 0, i32 1) }, 1
  %t1233 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d77, i32 0, i32 1) }, 0
  %t1234 = add i64 %t1231, %t1233
  %t1236 = call i64 @__olang_fmt_i64(ptr null, i64 %t1213)
  %t1237 = add i64 %t1234, %t1236
  %t1238 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d78, i32 0, i32 1) }, 1
  %t1239 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d78, i32 0, i32 1) }, 0
  %t1240 = add i64 %t1237, %t1239
  %t1241 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t1240)
  call void @olang_textcopy(ptr %t1241, ptr %t1214, i64 %t1215)
  %t1242 = getelementptr i8, ptr %t1241, i64 %t1215
  call void @olang_textcopy(ptr %t1242, ptr %t1217, i64 %t1218)
  %t1243 = getelementptr i8, ptr %t1242, i64 %t1218
  call void @olang_textcopy(ptr %t1243, ptr %t1220, i64 %t1221)
  %t1244 = getelementptr i8, ptr %t1243, i64 %t1221
  %t1245 = call i64 @__olang_fmt_i64(ptr %t1244, i64 %t1223)
  %t1246 = getelementptr i8, ptr %t1244, i64 %t1224
  call void @olang_textcopy(ptr %t1246, ptr %t1226, i64 %t1227)
  %t1247 = getelementptr i8, ptr %t1246, i64 %t1227
  %t1248 = call i64 @__olang_fmt_i64(ptr %t1247, i64 %t1212)
  %t1249 = getelementptr i8, ptr %t1247, i64 %t1230
  call void @olang_textcopy(ptr %t1249, ptr %t1232, i64 %t1233)
  %t1250 = getelementptr i8, ptr %t1249, i64 %t1233
  %t1251 = call i64 @__olang_fmt_i64(ptr %t1250, i64 %t1213)
  %t1252 = getelementptr i8, ptr %t1250, i64 %t1236
  call void @olang_textcopy(ptr %t1252, ptr %t1238, i64 %t1239)
  %t1253 = insertvalue { i64, ptr } undef, i64 %t1240, 0
  %t1254 = insertvalue { i64, ptr } %t1253, ptr %t1241, 1
  %t1256 = extractvalue { i64, ptr } %t1254, 0
  %t1257 = extractvalue { i64, ptr } %t1254, 1
  %t1258 = mul i64 %t1256, 1
  %t1259 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t1258)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1259, ptr %t1257, i64 %t1258, i1 false)
  %t1260 = insertvalue { i64, ptr } undef, i64 %t1256, 0
  %t1261 = insertvalue { i64, ptr } %t1260, ptr %t1259, 1
  %t1262 = load ptr, ptr %l503, !tbaa !29
  %t1263 = load i64, ptr %l504, !tbaa !24
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgShared(ptr %v0, ptr %s26, ptr %t1262, i64 %t1263, { i64, ptr } %t1261)
  br label %bb232
bb232:
  %t1265 = load i1, ptr %l44, !tbaa !21
  %t1267 = xor i1 %t1265, true
  br i1 %t1267, label %bb233, label %bb234
bb233:
  %t1269 = load i64, ptr %l31, !tbaa !24
  call void @__olang_scope_close(ptr %s26)
  store i64 %t1269, ptr %rv
  br label %ret
bb234:
  br label %bb235
bb235:
  %t1271 = load ptr, ptr %l2, !tbaa !29
  %t1272 = load i32, ptr %l3, !tbaa !23
  %t1275 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePayloadSize(ptr %v0, ptr %t1271, i32 %t1272)
  store i64 %t1275, ptr %l521
  br label %bb236
bb236:
  %t1276 = load i64, ptr %l521, !tbaa !24
  %t1277 = sdiv i64 %t1276, 8
  store i64 %t1277, ptr %l47, !tbaa !24
  %t1279 = load ptr, ptr %l0, !tbaa !29
  %t1281 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgNew(ptr %v0, ptr %t1279)
  store i64 %t1281, ptr %l524
  br label %bb237
bb237:
  %t1282 = load i64, ptr %l524, !tbaa !24
  store i64 %t1282, ptr %l48, !tbaa !24
  %t1283 = load ptr, ptr %l0, !tbaa !29
  %t1285 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgNew(ptr %v0, ptr %t1283)
  store i64 %t1285, ptr %l526
  br label %bb238
bb238:
  %t1286 = load i64, ptr %l526, !tbaa !24
  store i64 %t1286, ptr %l49, !tbaa !24
  %t1287 = load ptr, ptr %l0, !tbaa !29
  %t1288 = load i64, ptr %l49, !tbaa !24
  %t1289 = load i64, ptr %l47, !tbaa !24
  %t1290 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d79, i32 0, i32 1) }, 1
  %t1291 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d79, i32 0, i32 1) }, 0
  %t1293 = call i64 @__olang_fmt_i64(ptr null, i64 %t1289)
  %t1294 = add i64 %t1291, %t1293
  %t1295 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d80, i32 0, i32 1) }, 1
  %t1296 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d80, i32 0, i32 1) }, 0
  %t1297 = add i64 %t1294, %t1296
  %t1298 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t1297)
  call void @olang_textcopy(ptr %t1298, ptr %t1290, i64 %t1291)
  %t1299 = getelementptr i8, ptr %t1298, i64 %t1291
  %t1300 = call i64 @__olang_fmt_i64(ptr %t1299, i64 %t1289)
  %t1301 = getelementptr i8, ptr %t1299, i64 %t1293
  call void @olang_textcopy(ptr %t1301, ptr %t1295, i64 %t1296)
  %t1302 = insertvalue { i64, ptr } undef, i64 %t1297, 0
  %t1303 = insertvalue { i64, ptr } %t1302, ptr %t1298, 1
  %t1305 = extractvalue { i64, ptr } %t1303, 0
  %t1306 = extractvalue { i64, ptr } %t1303, 1
  %t1307 = mul i64 %t1305, 1
  %t1308 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t1307)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1308, ptr %t1306, i64 %t1307, i1 false)
  %t1309 = insertvalue { i64, ptr } undef, i64 %t1305, 0
  %t1310 = insertvalue { i64, ptr } %t1309, ptr %t1308, 1
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgShared(ptr %v0, ptr %s26, ptr %t1287, i64 %t1288, { i64, ptr } %t1310)
  br label %bb239
bb239:
  %t1314 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1314, ptr %l532, !tbaa !29
  %t1315 = load i64, ptr %l48, !tbaa !24
  store i64 %t1315, ptr %l533, !tbaa !24
  %t1316 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1316, ptr %l534, !tbaa !29
  %t1317 = load ptr, ptr %l2, !tbaa !29
  %t1319 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s26, ptr %t1317, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d81, i32 0, i32 1) })
  store i32 %t1319, ptr %l536
  br label %bb240
bb240:
  %t1320 = load ptr, ptr %l534, !tbaa !29
  %t1321 = load i32, ptr %l536, !tbaa !23
  %t1322 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgType(ptr %v0, ptr %t1320, i32 %t1321)
  store i64 %t1322, ptr %l537
  br label %bb241
bb241:
  %t1323 = load i64, ptr %l47, !tbaa !24
  %t1325 = mul i64 %t1323, 64
  %t1326 = load i64, ptr %l49, !tbaa !24
  %t1327 = extractvalue { i64, ptr } { i64 52, ptr getelementptr inbounds (<{ i64, [52 x i8] }>, ptr @.d82, i32 0, i32 1) }, 1
  %t1328 = extractvalue { i64, ptr } { i64 52, ptr getelementptr inbounds (<{ i64, [52 x i8] }>, ptr @.d82, i32 0, i32 1) }, 0
  %t1329 = load i64, ptr %l537, !tbaa !24
  %t1330 = call i64 @__olang_fmt_i64(ptr null, i64 %t1329)
  %t1331 = add i64 %t1328, %t1330
  %t1332 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d83, i32 0, i32 1) }, 1
  %t1333 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d83, i32 0, i32 1) }, 0
  %t1334 = add i64 %t1331, %t1333
  %t1336 = call i64 @__olang_fmt_i64(ptr null, i64 %t1325)
  %t1337 = add i64 %t1334, %t1336
  %t1338 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d84, i32 0, i32 1) }, 1
  %t1339 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d84, i32 0, i32 1) }, 0
  %t1340 = add i64 %t1337, %t1339
  %t1342 = call i64 @__olang_fmt_i64(ptr null, i64 %t1326)
  %t1343 = add i64 %t1340, %t1342
  %t1344 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d85, i32 0, i32 1) }, 1
  %t1345 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d85, i32 0, i32 1) }, 0
  %t1346 = add i64 %t1343, %t1345
  %t1347 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t1346)
  call void @olang_textcopy(ptr %t1347, ptr %t1327, i64 %t1328)
  %t1348 = getelementptr i8, ptr %t1347, i64 %t1328
  %t1349 = call i64 @__olang_fmt_i64(ptr %t1348, i64 %t1329)
  %t1350 = getelementptr i8, ptr %t1348, i64 %t1330
  call void @olang_textcopy(ptr %t1350, ptr %t1332, i64 %t1333)
  %t1351 = getelementptr i8, ptr %t1350, i64 %t1333
  %t1352 = call i64 @__olang_fmt_i64(ptr %t1351, i64 %t1325)
  %t1353 = getelementptr i8, ptr %t1351, i64 %t1336
  call void @olang_textcopy(ptr %t1353, ptr %t1338, i64 %t1339)
  %t1354 = getelementptr i8, ptr %t1353, i64 %t1339
  %t1355 = call i64 @__olang_fmt_i64(ptr %t1354, i64 %t1326)
  %t1356 = getelementptr i8, ptr %t1354, i64 %t1342
  call void @olang_textcopy(ptr %t1356, ptr %t1344, i64 %t1345)
  %t1357 = insertvalue { i64, ptr } undef, i64 %t1346, 0
  %t1358 = insertvalue { i64, ptr } %t1357, ptr %t1347, 1
  %t1360 = extractvalue { i64, ptr } %t1358, 0
  %t1361 = extractvalue { i64, ptr } %t1358, 1
  %t1362 = mul i64 %t1360, 1
  %t1363 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t1362)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1363, ptr %t1361, i64 %t1362, i1 false)
  %t1364 = insertvalue { i64, ptr } undef, i64 %t1360, 0
  %t1365 = insertvalue { i64, ptr } %t1364, ptr %t1363, 1
  %t1366 = load ptr, ptr %l532, !tbaa !29
  %t1367 = load i64, ptr %l533, !tbaa !24
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgShared(ptr %v0, ptr %s26, ptr %t1366, i64 %t1367, { i64, ptr } %t1365)
  br label %bb242
bb242:
  %t1369 = load ptr, ptr %l0, !tbaa !29
  %t1371 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgNew(ptr %v0, ptr %t1369)
  store i64 %t1371, ptr %l544
  br label %bb243
bb243:
  %t1372 = load i64, ptr %l544, !tbaa !24
  store i64 %t1372, ptr %l50, !tbaa !24
  %t1373 = load ptr, ptr %l0, !tbaa !29
  %t1375 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgNew(ptr %v0, ptr %t1373)
  store i64 %t1375, ptr %l546
  br label %bb244
bb244:
  %t1376 = load i64, ptr %l546, !tbaa !24
  store i64 %t1376, ptr %l51, !tbaa !24
  %t1377 = load ptr, ptr %l0, !tbaa !29
  %t1379 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgNew(ptr %v0, ptr %t1377)
  store i64 %t1379, ptr %l548
  br label %bb245
bb245:
  %t1380 = load i64, ptr %l548, !tbaa !24
  store i64 %t1380, ptr %l52, !tbaa !24
  %t1381 = load ptr, ptr %l0, !tbaa !29
  %t1382 = load i64, ptr %l50, !tbaa !24
  %t1383 = load i64, ptr %l45, !tbaa !24
  %t1384 = extractvalue { i64, ptr } { i64 60, ptr getelementptr inbounds (<{ i64, [60 x i8] }>, ptr @.d86, i32 0, i32 1) }, 1
  %t1385 = extractvalue { i64, ptr } { i64 60, ptr getelementptr inbounds (<{ i64, [60 x i8] }>, ptr @.d86, i32 0, i32 1) }, 0
  %t1387 = call i64 @__olang_fmt_i64(ptr null, i64 %t1383)
  %t1388 = add i64 %t1385, %t1387
  %t1389 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d87, i32 0, i32 1) }, 1
  %t1390 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d87, i32 0, i32 1) }, 0
  %t1391 = add i64 %t1388, %t1390
  %t1392 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t1391)
  call void @olang_textcopy(ptr %t1392, ptr %t1384, i64 %t1385)
  %t1393 = getelementptr i8, ptr %t1392, i64 %t1385
  %t1394 = call i64 @__olang_fmt_i64(ptr %t1393, i64 %t1383)
  %t1395 = getelementptr i8, ptr %t1393, i64 %t1387
  call void @olang_textcopy(ptr %t1395, ptr %t1389, i64 %t1390)
  %t1396 = insertvalue { i64, ptr } undef, i64 %t1391, 0
  %t1397 = insertvalue { i64, ptr } %t1396, ptr %t1392, 1
  %t1399 = extractvalue { i64, ptr } %t1397, 0
  %t1400 = extractvalue { i64, ptr } %t1397, 1
  %t1401 = mul i64 %t1399, 1
  %t1402 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t1401)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1402, ptr %t1400, i64 %t1401, i1 false)
  %t1403 = insertvalue { i64, ptr } undef, i64 %t1399, 0
  %t1404 = insertvalue { i64, ptr } %t1403, ptr %t1402, 1
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgShared(ptr %v0, ptr %s26, ptr %t1381, i64 %t1382, { i64, ptr } %t1404)
  br label %bb246
bb246:
  %t1408 = load ptr, ptr %l0, !tbaa !29
  %t1409 = load i64, ptr %l51, !tbaa !24
  %t1410 = load i64, ptr %l48, !tbaa !24
  %t1411 = load i64, ptr %l47, !tbaa !24
  %t1413 = mul i64 %t1411, 64
  %t1414 = extractvalue { i64, ptr } { i64 63, ptr getelementptr inbounds (<{ i64, [63 x i8] }>, ptr @.d88, i32 0, i32 1) }, 1
  %t1415 = extractvalue { i64, ptr } { i64 63, ptr getelementptr inbounds (<{ i64, [63 x i8] }>, ptr @.d88, i32 0, i32 1) }, 0
  %t1417 = call i64 @__olang_fmt_i64(ptr null, i64 %t1410)
  %t1418 = add i64 %t1415, %t1417
  %t1419 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d89, i32 0, i32 1) }, 1
  %t1420 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d89, i32 0, i32 1) }, 0
  %t1421 = add i64 %t1418, %t1420
  %t1423 = call i64 @__olang_fmt_i64(ptr null, i64 %t1413)
  %t1424 = add i64 %t1421, %t1423
  %t1425 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d90, i32 0, i32 1) }, 1
  %t1426 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d90, i32 0, i32 1) }, 0
  %t1427 = add i64 %t1424, %t1426
  %t1428 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t1427)
  call void @olang_textcopy(ptr %t1428, ptr %t1414, i64 %t1415)
  %t1429 = getelementptr i8, ptr %t1428, i64 %t1415
  %t1430 = call i64 @__olang_fmt_i64(ptr %t1429, i64 %t1410)
  %t1431 = getelementptr i8, ptr %t1429, i64 %t1417
  call void @olang_textcopy(ptr %t1431, ptr %t1419, i64 %t1420)
  %t1432 = getelementptr i8, ptr %t1431, i64 %t1420
  %t1433 = call i64 @__olang_fmt_i64(ptr %t1432, i64 %t1413)
  %t1434 = getelementptr i8, ptr %t1432, i64 %t1423
  call void @olang_textcopy(ptr %t1434, ptr %t1425, i64 %t1426)
  %t1435 = insertvalue { i64, ptr } undef, i64 %t1427, 0
  %t1436 = insertvalue { i64, ptr } %t1435, ptr %t1428, 1
  %t1438 = extractvalue { i64, ptr } %t1436, 0
  %t1439 = extractvalue { i64, ptr } %t1436, 1
  %t1440 = mul i64 %t1438, 1
  %t1441 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t1440)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1441, ptr %t1439, i64 %t1440, i1 false)
  %t1442 = insertvalue { i64, ptr } undef, i64 %t1438, 0
  %t1443 = insertvalue { i64, ptr } %t1442, ptr %t1441, 1
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgShared(ptr %v0, ptr %s26, ptr %t1408, i64 %t1409, { i64, ptr } %t1443)
  br label %bb247
bb247:
  %t1447 = load ptr, ptr %l0, !tbaa !29
  %t1448 = load i64, ptr %l52, !tbaa !24
  %t1449 = load i64, ptr %l50, !tbaa !24
  %t1450 = load i64, ptr %l51, !tbaa !24
  %t1451 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d91, i32 0, i32 1) }, 1
  %t1452 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d91, i32 0, i32 1) }, 0
  %t1454 = call i64 @__olang_fmt_i64(ptr null, i64 %t1449)
  %t1455 = add i64 %t1452, %t1454
  %t1456 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d92, i32 0, i32 1) }, 1
  %t1457 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d92, i32 0, i32 1) }, 0
  %t1458 = add i64 %t1455, %t1457
  %t1460 = call i64 @__olang_fmt_i64(ptr null, i64 %t1450)
  %t1461 = add i64 %t1458, %t1460
  %t1462 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d93, i32 0, i32 1) }, 1
  %t1463 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d93, i32 0, i32 1) }, 0
  %t1464 = add i64 %t1461, %t1463
  %t1465 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t1464)
  call void @olang_textcopy(ptr %t1465, ptr %t1451, i64 %t1452)
  %t1466 = getelementptr i8, ptr %t1465, i64 %t1452
  %t1467 = call i64 @__olang_fmt_i64(ptr %t1466, i64 %t1449)
  %t1468 = getelementptr i8, ptr %t1466, i64 %t1454
  call void @olang_textcopy(ptr %t1468, ptr %t1456, i64 %t1457)
  %t1469 = getelementptr i8, ptr %t1468, i64 %t1457
  %t1470 = call i64 @__olang_fmt_i64(ptr %t1469, i64 %t1450)
  %t1471 = getelementptr i8, ptr %t1469, i64 %t1460
  call void @olang_textcopy(ptr %t1471, ptr %t1462, i64 %t1463)
  %t1472 = insertvalue { i64, ptr } undef, i64 %t1464, 0
  %t1473 = insertvalue { i64, ptr } %t1472, ptr %t1465, 1
  %t1475 = extractvalue { i64, ptr } %t1473, 0
  %t1476 = extractvalue { i64, ptr } %t1473, 1
  %t1477 = mul i64 %t1475, 1
  %t1478 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t1477)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1478, ptr %t1476, i64 %t1477, i1 false)
  %t1479 = insertvalue { i64, ptr } undef, i64 %t1475, 0
  %t1480 = insertvalue { i64, ptr } %t1479, ptr %t1478, 1
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgShared(ptr %v0, ptr %s26, ptr %t1447, i64 %t1448, { i64, ptr } %t1480)
  br label %bb248
bb248:
  %t1484 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1484, ptr %l567, !tbaa !29
  %t1485 = load i64, ptr %l31, !tbaa !24
  store i64 %t1485, ptr %l568, !tbaa !24
  %t1486 = load ptr, ptr %l0, !tbaa !29
  %t1487 = load i32, ptr %l3, !tbaa !23
  %t1490 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgTypeName(ptr %v0, ptr %s26, ptr %t1486, i32 %t1487)
  store { i64, ptr } %t1490, ptr %l571
  br label %bb249
bb249:
  %t1491 = load { i64, ptr }, ptr %l571, !tbaa !27
  %t1492 = extractvalue { i64, ptr } %t1491, 0
  %t1493 = extractvalue { i64, ptr } %t1491, 1
  %t1494 = mul i64 %t1492, 1
  %t1495 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t1494)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1495, ptr %t1493, i64 %t1494, i1 false)
  %t1496 = insertvalue { i64, ptr } undef, i64 %t1492, 0
  %t1497 = insertvalue { i64, ptr } %t1496, ptr %t1495, 1
  %t1499 = call { i64, ptr } @compiler_2femit_2eescape(ptr %s26, ptr %s26, { i64, ptr } %t1497)
  store { i64, ptr } %t1499, ptr %l573
  br label %bb250
bb250:
  %t1500 = load i64, ptr %l11, !tbaa !24
  %t1501 = load i64, ptr %l52, !tbaa !24
  %t1502 = extractvalue { i64, ptr } { i64 52, ptr getelementptr inbounds (<{ i64, [52 x i8] }>, ptr @.d94, i32 0, i32 1) }, 1
  %t1503 = extractvalue { i64, ptr } { i64 52, ptr getelementptr inbounds (<{ i64, [52 x i8] }>, ptr @.d94, i32 0, i32 1) }, 0
  %t1504 = load { i64, ptr }, ptr %l573, !tbaa !27
  %t1505 = extractvalue { i64, ptr } %t1504, 1
  %t1506 = extractvalue { i64, ptr } %t1504, 0
  %t1507 = add i64 %t1503, %t1506
  %t1508 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d95, i32 0, i32 1) }, 1
  %t1509 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d95, i32 0, i32 1) }, 0
  %t1510 = add i64 %t1507, %t1509
  %t1512 = call i64 @__olang_fmt_i64(ptr null, i64 %t1500)
  %t1513 = add i64 %t1510, %t1512
  %t1514 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d96, i32 0, i32 1) }, 1
  %t1515 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d96, i32 0, i32 1) }, 0
  %t1516 = add i64 %t1513, %t1515
  %t1518 = call i64 @__olang_fmt_i64(ptr null, i64 %t1501)
  %t1519 = add i64 %t1516, %t1518
  %t1520 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d97, i32 0, i32 1) }, 1
  %t1521 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d97, i32 0, i32 1) }, 0
  %t1522 = add i64 %t1519, %t1521
  %t1523 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t1522)
  call void @olang_textcopy(ptr %t1523, ptr %t1502, i64 %t1503)
  %t1524 = getelementptr i8, ptr %t1523, i64 %t1503
  call void @olang_textcopy(ptr %t1524, ptr %t1505, i64 %t1506)
  %t1525 = getelementptr i8, ptr %t1524, i64 %t1506
  call void @olang_textcopy(ptr %t1525, ptr %t1508, i64 %t1509)
  %t1526 = getelementptr i8, ptr %t1525, i64 %t1509
  %t1527 = call i64 @__olang_fmt_i64(ptr %t1526, i64 %t1500)
  %t1528 = getelementptr i8, ptr %t1526, i64 %t1512
  call void @olang_textcopy(ptr %t1528, ptr %t1514, i64 %t1515)
  %t1529 = getelementptr i8, ptr %t1528, i64 %t1515
  %t1530 = call i64 @__olang_fmt_i64(ptr %t1529, i64 %t1501)
  %t1531 = getelementptr i8, ptr %t1529, i64 %t1518
  call void @olang_textcopy(ptr %t1531, ptr %t1520, i64 %t1521)
  %t1532 = insertvalue { i64, ptr } undef, i64 %t1522, 0
  %t1533 = insertvalue { i64, ptr } %t1532, ptr %t1523, 1
  %t1535 = extractvalue { i64, ptr } %t1533, 0
  %t1536 = extractvalue { i64, ptr } %t1533, 1
  %t1537 = mul i64 %t1535, 1
  %t1538 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t1537)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1538, ptr %t1536, i64 %t1537, i1 false)
  %t1539 = insertvalue { i64, ptr } undef, i64 %t1535, 0
  %t1540 = insertvalue { i64, ptr } %t1539, ptr %t1538, 1
  %t1541 = load ptr, ptr %l567, !tbaa !29
  %t1542 = load i64, ptr %l568, !tbaa !24
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgShared(ptr %v0, ptr %s26, ptr %t1541, i64 %t1542, { i64, ptr } %t1540)
  br label %bb251
bb251:
  %t1544 = load i64, ptr %l31, !tbaa !24
  call void @__olang_scope_close(ptr %s26)
  store i64 %t1544, ptr %rv
  br label %ret
bb252:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eentry(ptr %v0, ptr %v1, ptr %a0, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca %"std/prelude/text:StringBuilder"
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca { i64, [2 x i64] }
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i32
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca { i64, ptr }
  %l37 = alloca %"std/prelude/text:StringBuilder"
  %l45 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l47 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %l51 = alloca i32
  %l60 = alloca { i64, ptr }
  %l66 = alloca i1
  %l68 = alloca ptr
  %l74 = alloca { i64, ptr }
  %l90 = alloca ptr
  %l93 = alloca ptr
  %l96 = alloca i32
  %l97 = alloca { i64, ptr }
  %l101 = alloca ptr
  %l104 = alloca { i64, ptr }
  %l107 = alloca ptr
  %l111 = alloca i64
  %l113 = alloca { i64, ptr }
  %l114 = alloca ptr
  %l117 = alloca { i64, ptr }
  %l124 = alloca { i64, ptr }
  %l125 = alloca { i64, ptr }
  %l126 = alloca i64
  %l127 = alloca { i64, ptr }
  %l128 = alloca ptr
  %l130 = alloca { i64, ptr }
  %l138 = alloca i64
  %l141 = alloca i64
  %l160 = alloca { i64, ptr }
  %l163 = alloca i32
  %l165 = alloca ptr
  %l168 = alloca i32
  %l169 = alloca { i64, ptr }
  %l175 = alloca i64
  %l178 = alloca i64
  %l205 = alloca { i64, ptr }
  %l207 = alloca { i64, ptr }
  %l210 = alloca { i64, ptr }
  %l217 = alloca ptr
  %l218 = alloca i64
  %l219 = alloca i64
  %l222 = alloca { i64, ptr }
  %l227 = alloca { i64, ptr }
  %l229 = alloca i64
  %l240 = alloca i1
  %l245 = alloca ptr
  %l249 = alloca i64
  %l251 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %t79 = alloca { i64, [2 x i64] }, align 8
  %t125 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edefine(ptr %v0, ptr %s0, ptr %s0, ptr %t6, { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d98, i32 0, i32 1) }, { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d99, i32 0, i32 1) })
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edefine(ptr %v0, ptr %s0, ptr %s0, ptr %t8, { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d100, i32 0, i32 1) }, { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d101, i32 0, i32 1) })
  br label %bb2
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %s0, ptr %t10, { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d102, i32 0, i32 1) })
  br label %bb3
bb3:
  %t12 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t12, ptr %l37
  br label %bb4
bb4:
  %t13 = load %"std/prelude/text:StringBuilder", ptr %l37
  store %"std/prelude/text:StringBuilder" %t13, ptr %l4
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l4, { i64, ptr } { i64 51, ptr getelementptr inbounds (<{ i64, [51 x i8] }>, ptr @.d103, i32 0, i32 1) })
  br label %bb5
bb5:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l4, { i64, ptr } { i64 74, ptr getelementptr inbounds (<{ i64, [74 x i8] }>, ptr @.d104, i32 0, i32 1) })
  br label %bb6
bb6:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l4, { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d105, i32 0, i32 1) })
  br label %bb7
bb7:
  %t17 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2esanInit(ptr %v0, ptr %s0, ptr %t17, ptr %l4)
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s1
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t24 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2femit_2ecompiler_2femit_3aEmitter_2eglobalOrder(ptr %v0, ptr %v1, ptr %s1, ptr %t20, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %a1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t24, ptr %l45
  br label %bb9
bb9:
  %t25 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l45
  %t26 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t25, ptr %t26
  store ptr %t26, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  %t28 = load ptr, ptr %l5, !tbaa !29
  %t29 = load i64, ptr %l6, !tbaa !24
  %t32 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %s1, ptr %t28, i64 %t29)
  %t33 = extractvalue { i32, { i64, ptr } } %t32, 1
  %t34 = extractvalue { i32, { i64, ptr } } %t32, 0
  store i32 %t34, ptr %l51
  %t35 = icmp ne i32 %t34, 0
  br i1 %t35, label %bb12, label %ok.36
ok.36:
  store { i64, ptr } %t33, ptr %l50
  br label %bb11
bb11:
  %t37 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t37, ptr %l47, !tbaa !27
  br label %bb16
bb12:
  %t38 = load i32, ptr %l51, !tbaa !23
  %t39 = ashr i32 %t38, 16
  %t41 = icmp eq i32 %t39, 1
  br i1 %t41, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  call void @__olang_check_failed(ptr @olang_loc_4076b09b5c48092e_8975d1b2e9d279c2)
  unreachable
bb15:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %bb30
bb16:
  %t43 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t43, ptr %l7, !tbaa !27
  %t44 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t44, 0
  store i64 %t46, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb17
bb17:
  store %olang.scope zeroinitializer, ptr %s3
  %t48 = load i64, ptr %l9, !tbaa !24
  %t49 = load i64, ptr %l8, !tbaa !24
  %t52 = icmp slt i64 %t48, %t49
  %t54 = xor i1 %t52, true
  br i1 %t54, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s3)
  br label %bb28
bb19:
  br label %bb20
bb20:
  %t56 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t56, ptr %l60, !tbaa !27
  %t57 = load i64, ptr %l9, !tbaa !24
  %t59 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = getelementptr i64, ptr %t60, i64 %t57
  %t62 = load i64, ptr %t61, !tbaa !34
  store i64 %t62, ptr %l10, !tbaa !24
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/emit:Emitter", ptr %t64, i32 0, i32 44
  %t67 = load i64, ptr %l10, !tbaa !24
  %t70 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2feval_3aImage_3e_2e_H901ad831a5883703dcf426ee01511832(ptr %v0, ptr %t66, i64 %t67)
  store i1 %t70, ptr %l66
  br label %bb21
bb21:
  %t71 = load i1, ptr %l66, !tbaa !21
  %t72 = xor i1 %t71, true
  br i1 %t72, label %bb22, label %bb23
bb22:
  store %olang.scope zeroinitializer, ptr %s4
  store ptr %l4, ptr %l68, !tbaa !29
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load i64, ptr %l10, !tbaa !24
  %t77 = trunc i64 %t75 to i32
  store { i64, [2 x i64] } zeroinitializer, ptr %t79
  %t80 = getelementptr { i64, [2 x i64] }, ptr %t79, i32 0, i32 0
  store i64 0, ptr %t80
  %t82 = insertvalue { i32 } undef, i32 %t77, 0
  %t83 = getelementptr { i64, [2 x i64] }, ptr %t79, i32 0, i32 1
  store { i32 } %t82, ptr %t83
  %t84 = load { i64, [2 x i64] }, ptr %t79
  %t87 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2esym(ptr %v0, ptr %s4, ptr %t74, { i64, [2 x i64] } %t84)
  store { i64, ptr } %t87, ptr %l74
  br label %bb24
bb23:
  br label %bb26
bb24:
  %t88 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d106, i32 0, i32 1) }, 1
  %t89 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d106, i32 0, i32 1) }, 0
  %t90 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t91 = extractvalue { i64, ptr } %t90, 1
  %t92 = extractvalue { i64, ptr } %t90, 0
  %t93 = add i64 %t89, %t92
  %t94 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d107, i32 0, i32 1) }, 1
  %t95 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d107, i32 0, i32 1) }, 0
  %t96 = add i64 %t93, %t95
  %t97 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t96)
  call void @olang_textcopy(ptr %t97, ptr %t88, i64 %t89)
  %t98 = getelementptr i8, ptr %t97, i64 %t89
  call void @olang_textcopy(ptr %t98, ptr %t91, i64 %t92)
  %t99 = getelementptr i8, ptr %t98, i64 %t92
  call void @olang_textcopy(ptr %t99, ptr %t94, i64 %t95)
  %t100 = insertvalue { i64, ptr } undef, i64 %t96, 0
  %t101 = insertvalue { i64, ptr } %t100, ptr %t97, 1
  %t103 = extractvalue { i64, ptr } %t101, 0
  %t104 = extractvalue { i64, ptr } %t101, 1
  %t105 = mul i64 %t103, 1
  %t106 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t105)
  call void @llvm.memcpy.p0.p0.i64(ptr %t106, ptr %t104, i64 %t105, i1 false)
  %t107 = insertvalue { i64, ptr } undef, i64 %t103, 0
  %t108 = insertvalue { i64, ptr } %t107, ptr %t106, 1
  %t109 = load ptr, ptr %l68, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s4, ptr %t109, { i64, ptr } %t108)
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s4)
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s3)
  br label %bb27
bb27:
  %t111 = load i64, ptr %l9, !tbaa !24
  %t113 = add i64 %t111, 1
  store i64 %t113, ptr %l9, !tbaa !24
  br label %bb17
bb28:
  %t115 = load i64, ptr %l6, !tbaa !24
  %t116 = load i64, ptr %l8, !tbaa !24
  %t119 = add i64 %t115, %t116
  store i64 %t119, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb29
bb29:
  br label %bb10
bb30:
  call void @__olang_scope_close(ptr %s1)
  %t121 = load i64, ptr %l2, !tbaa !24
  %t123 = trunc i64 %t121 to i32
  store { i64, [2 x i64] } zeroinitializer, ptr %t125
  %t126 = getelementptr { i64, [2 x i64] }, ptr %t125, i32 0, i32 0
  store i64 0, ptr %t126
  %t128 = insertvalue { i32 } undef, i32 %t123, 0
  %t129 = getelementptr { i64, [2 x i64] }, ptr %t125, i32 0, i32 1
  store { i32 } %t128, ptr %t129
  %t130 = load { i64, [2 x i64] }, ptr %t125
  store { i64, [2 x i64] } %t130, ptr %l11
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t134 = getelementptr %"compiler/emit:Emitter", ptr %t132, i32 0, i32 1
  %t135 = load ptr, ptr %t134, !tbaa !29
  %t137 = getelementptr %"compiler/lower:Lowerer", ptr %t135, i32 0, i32 1
  %t138 = load i64, ptr %l2, !tbaa !24
  %t141 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t137, i64 %t138)
  store ptr %t141, ptr %l90
  br label %bb31
bb31:
  %t142 = load ptr, ptr %l90, !tbaa !29
  %t144 = getelementptr %"compiler/typed:Body", ptr %t142, i32 0, i32 2
  %t145 = load i32, ptr %t144, !tbaa !23
  %t147 = load ptr, ptr %l3, !tbaa !29
  store ptr %t147, ptr %l93, !tbaa !29
  %t148 = load ptr, ptr %l3, !tbaa !29
  %t152 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t148, i32 %t145)
  store i32 %t152, ptr %l96
  br label %bb32
bb32:
  %t153 = load ptr, ptr %l93, !tbaa !29
  %t154 = load i32, ptr %l96, !tbaa !23
  %t155 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t153, i32 %t154)
  store { i64, ptr } %t155, ptr %l97
  br label %bb33
bb33:
  %t156 = load { i64, ptr }, ptr %l97, !tbaa !27
  store { i64, ptr } %t156, ptr %l13, !tbaa !27
  %t157 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t159 = extractvalue { i64, ptr } %t157, 0
  %t161 = icmp eq i64 %t159, 0
  br i1 %t161, label %bb34, label %bb35
bb34:
  store %olang.scope zeroinitializer, ptr %s7
  store ptr %l4, ptr %l101, !tbaa !29
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t164 = load { i64, [2 x i64] }, ptr %l11
  %t167 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2esym(ptr %v0, ptr %s7, ptr %t163, { i64, [2 x i64] } %t164)
  store { i64, ptr } %t167, ptr %l104
  br label %bb36
bb35:
  br label %bb40
bb36:
  %t168 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d108, i32 0, i32 1) }, 1
  %t169 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d108, i32 0, i32 1) }, 0
  %t170 = load { i64, ptr }, ptr %l104, !tbaa !27
  %t171 = extractvalue { i64, ptr } %t170, 1
  %t172 = extractvalue { i64, ptr } %t170, 0
  %t173 = add i64 %t169, %t172
  %t174 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d109, i32 0, i32 1) }, 1
  %t175 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d109, i32 0, i32 1) }, 0
  %t176 = add i64 %t173, %t175
  %t177 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t176)
  call void @olang_textcopy(ptr %t177, ptr %t168, i64 %t169)
  %t178 = getelementptr i8, ptr %t177, i64 %t169
  call void @olang_textcopy(ptr %t178, ptr %t171, i64 %t172)
  %t179 = getelementptr i8, ptr %t178, i64 %t172
  call void @olang_textcopy(ptr %t179, ptr %t174, i64 %t175)
  %t180 = insertvalue { i64, ptr } undef, i64 %t176, 0
  %t181 = insertvalue { i64, ptr } %t180, ptr %t177, 1
  %t183 = extractvalue { i64, ptr } %t181, 0
  %t184 = extractvalue { i64, ptr } %t181, 1
  %t185 = mul i64 %t183, 1
  %t186 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t185)
  call void @llvm.memcpy.p0.p0.i64(ptr %t186, ptr %t184, i64 %t185, i1 false)
  %t187 = insertvalue { i64, ptr } undef, i64 %t183, 0
  %t188 = insertvalue { i64, ptr } %t187, ptr %t186, 1
  %t189 = load ptr, ptr %l101, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s7, ptr %t189, { i64, ptr } %t188)
  br label %bb37
bb37:
  %t191 = load ptr, ptr %l0, !tbaa !29
  store ptr %t191, ptr %l107, !tbaa !29
  %t192 = load ptr, ptr %l0, !tbaa !29
  %t194 = getelementptr %"compiler/emit:Emitter", ptr %t192, i32 0, i32 0
  %t195 = load ptr, ptr %t194, !tbaa !29
  %t197 = getelementptr %"compiler/generic:Program", ptr %t195, i32 0, i32 0
  %t198 = load ptr, ptr %t197, !tbaa !29
  %t200 = getelementptr %"compiler/load:Loader", ptr %t198, i32 0, i32 7
  %t201 = load i64, ptr %t200, !tbaa !24
  store i64 %t201, ptr %l111, !tbaa !24
  %t203 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s7, ptr %l4)
  store { i64, ptr } %t203, ptr %l113
  br label %bb38
bb38:
  %t204 = load ptr, ptr %l107, !tbaa !29
  %t205 = load i64, ptr %l111, !tbaa !24
  %t206 = load { i64, ptr }, ptr %l113, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eitem(ptr %v0, ptr %s7, ptr %s7, ptr %s7, ptr %t204, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d110, i32 0, i32 1) }, i64 %t205, { i64, ptr } %t206, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d8, i32 0, i32 1) })
  br label %bb39
bb39:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb40:
  store ptr %l4, ptr %l114, !tbaa !29
  %t207 = load ptr, ptr %l0, !tbaa !29
  %t208 = load { i64, [2 x i64] }, ptr %l11
  %t211 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2esym(ptr %v0, ptr %s0, ptr %t207, { i64, [2 x i64] } %t208)
  store { i64, ptr } %t211, ptr %l117
  br label %bb41
bb41:
  %t212 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d111, i32 0, i32 1) }, 1
  %t213 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d111, i32 0, i32 1) }, 0
  %t214 = load { i64, ptr }, ptr %l117, !tbaa !27
  %t215 = extractvalue { i64, ptr } %t214, 1
  %t216 = extractvalue { i64, ptr } %t214, 0
  %t217 = add i64 %t213, %t216
  %t218 = extractvalue { i64, ptr } { i64 82, ptr getelementptr inbounds (<{ i64, [82 x i8] }>, ptr @.d112, i32 0, i32 1) }, 1
  %t219 = extractvalue { i64, ptr } { i64 82, ptr getelementptr inbounds (<{ i64, [82 x i8] }>, ptr @.d112, i32 0, i32 1) }, 0
  %t220 = add i64 %t217, %t219
  %t221 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t220)
  call void @olang_textcopy(ptr %t221, ptr %t212, i64 %t213)
  %t222 = getelementptr i8, ptr %t221, i64 %t213
  call void @olang_textcopy(ptr %t222, ptr %t215, i64 %t216)
  %t223 = getelementptr i8, ptr %t222, i64 %t216
  call void @olang_textcopy(ptr %t223, ptr %t218, i64 %t219)
  %t224 = insertvalue { i64, ptr } undef, i64 %t220, 0
  %t225 = insertvalue { i64, ptr } %t224, ptr %t221, 1
  %t227 = extractvalue { i64, ptr } %t225, 0
  %t228 = extractvalue { i64, ptr } %t225, 1
  %t229 = mul i64 %t227, 1
  %t230 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t229)
  call void @llvm.memcpy.p0.p0.i64(ptr %t230, ptr %t228, i64 %t229, i1 false)
  %t231 = insertvalue { i64, ptr } undef, i64 %t227, 0
  %t232 = insertvalue { i64, ptr } %t231, ptr %t230, 1
  %t233 = load ptr, ptr %l114, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t233, { i64, ptr } %t232)
  br label %bb42
bb42:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l4, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d113, i32 0, i32 1) })
  br label %bb43
bb43:
  %t236 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s0, ptr %s0, ptr %t236, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d114, i32 0, i32 1) }, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d115, i32 0, i32 1) })
  br label %bb44
bb44:
  %t238 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edefine(ptr %v0, ptr %s0, ptr %s0, ptr %t238, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d116, i32 0, i32 1) }, { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d117, i32 0, i32 1) })
  br label %bb45
bb45:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l4, { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d118, i32 0, i32 1) })
  br label %bb46
bb46:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d119, i32 0, i32 1) }, ptr %l124, !tbaa !27
  %t241 = load { i64, ptr }, ptr %l124, !tbaa !27
  store { i64, ptr } %t241, ptr %l125, !tbaa !27
  %t242 = load { i64, ptr }, ptr %l125, !tbaa !27
  %t243 = extractvalue { i64, ptr } %t242, 0
  store i64 %t243, ptr %l126, !tbaa !24
  %t244 = load i64, ptr %l126, !tbaa !24
  %t245 = mul i64 %t244, 1
  %t246 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t245)
  %t247 = insertvalue { i64, ptr } undef, i64 %t244, 0
  %t248 = insertvalue { i64, ptr } %t247, ptr %t246, 1
  store { i64, ptr } %t248, ptr %l127, !tbaa !27
  %t249 = getelementptr { i64, ptr }, ptr %l127, i32 0, i32 1
  %t250 = load ptr, ptr %t249, !tbaa !27
  %t251 = getelementptr { i64, ptr }, ptr %l125, i32 0, i32 1
  %t252 = load ptr, ptr %t251, !tbaa !27
  %t253 = load i64, ptr %l126, !tbaa !24
  %t254 = mul i64 %t253, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t250, ptr %t252, i64 %t254, i1 false)
  %t255 = load { i64, ptr }, ptr %l127, !tbaa !27
  store { i64, ptr } %t255, ptr %l14, !tbaa !27
  store ptr %l4, ptr %l128, !tbaa !29
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t258 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecstr(ptr %v0, ptr %s0, ptr %s0, ptr %t256, { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d120, i32 0, i32 1) })
  store { i64, ptr } %t258, ptr %l130
  br label %bb47
bb47:
  %t259 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d121, i32 0, i32 1) }, 1
  %t260 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d121, i32 0, i32 1) }, 0
  %t261 = load { i64, ptr }, ptr %l130, !tbaa !27
  %t262 = extractvalue { i64, ptr } %t261, 1
  %t263 = extractvalue { i64, ptr } %t261, 0
  %t264 = add i64 %t260, %t263
  %t265 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d122, i32 0, i32 1) }, 1
  %t266 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d122, i32 0, i32 1) }, 0
  %t267 = add i64 %t264, %t266
  %t268 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t267)
  call void @olang_textcopy(ptr %t268, ptr %t259, i64 %t260)
  %t269 = getelementptr i8, ptr %t268, i64 %t260
  call void @olang_textcopy(ptr %t269, ptr %t262, i64 %t263)
  %t270 = getelementptr i8, ptr %t269, i64 %t263
  call void @olang_textcopy(ptr %t270, ptr %t265, i64 %t266)
  %t271 = insertvalue { i64, ptr } undef, i64 %t267, 0
  %t272 = insertvalue { i64, ptr } %t271, ptr %t268, 1
  %t274 = extractvalue { i64, ptr } %t272, 0
  %t275 = extractvalue { i64, ptr } %t272, 1
  %t276 = mul i64 %t274, 1
  %t277 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t276)
  call void @llvm.memcpy.p0.p0.i64(ptr %t277, ptr %t275, i64 %t276, i1 false)
  %t278 = insertvalue { i64, ptr } undef, i64 %t274, 0
  %t279 = insertvalue { i64, ptr } %t278, ptr %t277, 1
  %t280 = load ptr, ptr %l128, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t280, { i64, ptr } %t279)
  br label %bb48
bb48:
  store i64 0, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  %t282 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t284 = extractvalue { i64, ptr } %t282, 0
  store i64 %t284, ptr %l17, !tbaa !24
  store i64 1, ptr %l18, !tbaa !24
  %t286 = load i64, ptr %l17, !tbaa !24
  %t287 = load i64, ptr %l16, !tbaa !24
  %t290 = icmp sgt i64 %t286, %t287
  br i1 %t290, label %bb49, label %bb50
bb49:
  %t292 = load i64, ptr %l18, !tbaa !24
  %t294 = icmp sgt i64 %t292, 0
  br i1 %t294, label %bb51, label %bb52
bb50:
  store i64 0, ptr %l138, !tbaa !24
  br label %bb54
bb51:
  %t296 = load i64, ptr %l17, !tbaa !24
  %t297 = load i64, ptr %l16, !tbaa !24
  %t300 = sub i64 %t296, %t297
  %t301 = load i64, ptr %l18, !tbaa !24
  %t304 = add i64 %t300, %t301
  %t306 = sub i64 %t304, 1
  %t307 = load i64, ptr %l18, !tbaa !24
  %t310 = sdiv i64 %t306, %t307
  store i64 %t310, ptr %l141, !tbaa !24
  br label %bb53
bb52:
  store i64 0, ptr %l141, !tbaa !24
  br label %bb53
bb53:
  %t312 = load i64, ptr %l141, !tbaa !24
  store i64 %t312, ptr %l138, !tbaa !24
  br label %bb54
bb54:
  %t313 = load i64, ptr %l138, !tbaa !24
  store i64 %t313, ptr %l19, !tbaa !24
  store i64 0, ptr %l20, !tbaa !24
  br label %bb55
bb55:
  store %olang.scope zeroinitializer, ptr %s12
  %t314 = load i64, ptr %l20, !tbaa !24
  %t315 = load i64, ptr %l19, !tbaa !24
  %t318 = icmp slt i64 %t314, %t315
  %t320 = xor i1 %t318, true
  br i1 %t320, label %bb56, label %bb57
bb56:
  call void @__olang_scope_close(ptr %s12)
  br label %bb83
bb57:
  br label %bb58
bb58:
  %t322 = load i64, ptr %l16, !tbaa !24
  %t323 = load i64, ptr %l20, !tbaa !24
  %t324 = load i64, ptr %l18, !tbaa !24
  %t327 = mul i64 %t323, %t324
  %t330 = add i64 %t322, %t327
  store i64 %t330, ptr %l21, !tbaa !24
  %t332 = load ptr, ptr %l3, !tbaa !29
  %t333 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t333, ptr %l160, !tbaa !27
  %t334 = load i64, ptr %l21, !tbaa !24
  %t336 = getelementptr { i64, ptr }, ptr %l160, i32 0, i32 1
  %t337 = load ptr, ptr %t336, !tbaa !27
  %t338 = getelementptr i32, ptr %t337, i64 %t334
  %t339 = load i32, ptr %t338, !tbaa !33
  %t342 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t332, i32 %t339)
  store i32 %t342, ptr %l163
  br label %bb59
bb59:
  %t343 = load i32, ptr %l163, !tbaa !23
  store i32 %t343, ptr %l22, !tbaa !23
  %t344 = load ptr, ptr %l0, !tbaa !29
  %t346 = getelementptr %"compiler/emit:Emitter", ptr %t344, i32 0, i32 0
  %t347 = load ptr, ptr %t346, !tbaa !29
  store ptr %t347, ptr %l165, !tbaa !29
  %t348 = load ptr, ptr %l3, !tbaa !29
  %t349 = load i32, ptr %l22, !tbaa !23
  %t352 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t348, i32 %t349)
  store i32 %t352, ptr %l168
  br label %bb60
bb60:
  %t353 = load ptr, ptr %l165, !tbaa !29
  %t354 = load i32, ptr %l168, !tbaa !23
  %t355 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorWords(ptr %v0, ptr %t353, i32 %t354)
  store { i64, ptr } %t355, ptr %l169
  br label %bb61
bb61:
  %t356 = load { i64, ptr }, ptr %l169, !tbaa !27
  store { i64, ptr } %t356, ptr %l23, !tbaa !27
  store i64 0, ptr %l24, !tbaa !24
  %t357 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t359 = extractvalue { i64, ptr } %t357, 0
  store i64 %t359, ptr %l25, !tbaa !24
  store i64 1, ptr %l26, !tbaa !24
  %t361 = load i64, ptr %l25, !tbaa !24
  %t362 = load i64, ptr %l24, !tbaa !24
  %t365 = icmp sgt i64 %t361, %t362
  br i1 %t365, label %bb62, label %bb63
bb62:
  %t367 = load i64, ptr %l26, !tbaa !24
  %t369 = icmp sgt i64 %t367, 0
  br i1 %t369, label %bb64, label %bb65
bb63:
  store i64 0, ptr %l175, !tbaa !24
  br label %bb67
bb64:
  %t371 = load i64, ptr %l25, !tbaa !24
  %t372 = load i64, ptr %l24, !tbaa !24
  %t375 = sub i64 %t371, %t372
  %t376 = load i64, ptr %l26, !tbaa !24
  %t379 = add i64 %t375, %t376
  %t381 = sub i64 %t379, 1
  %t382 = load i64, ptr %l26, !tbaa !24
  %t385 = sdiv i64 %t381, %t382
  store i64 %t385, ptr %l178, !tbaa !24
  br label %bb66
bb65:
  store i64 0, ptr %l178, !tbaa !24
  br label %bb66
bb66:
  %t387 = load i64, ptr %l178, !tbaa !24
  store i64 %t387, ptr %l175, !tbaa !24
  br label %bb67
bb67:
  %t388 = load i64, ptr %l175, !tbaa !24
  store i64 %t388, ptr %l27, !tbaa !24
  store i64 0, ptr %l28, !tbaa !24
  br label %bb68
bb68:
  store %olang.scope zeroinitializer, ptr %s14
  %t389 = load i64, ptr %l28, !tbaa !24
  %t390 = load i64, ptr %l27, !tbaa !24
  %t393 = icmp slt i64 %t389, %t390
  %t395 = xor i1 %t393, true
  br i1 %t395, label %bb69, label %bb70
bb69:
  call void @__olang_scope_close(ptr %s14)
  br label %bb81
bb70:
  br label %bb71
bb71:
  %t397 = load i64, ptr %l24, !tbaa !24
  %t398 = load i64, ptr %l28, !tbaa !24
  %t399 = load i64, ptr %l26, !tbaa !24
  %t402 = mul i64 %t398, %t399
  %t405 = add i64 %t397, %t402
  store i64 %t405, ptr %l29, !tbaa !24
  %t407 = load i64, ptr %l15, !tbaa !24
  %t409 = add i64 %t407, 1
  store i64 %t409, ptr %l15, !tbaa !24
  %t411 = load i64, ptr %l21, !tbaa !24
  %t413 = add i64 %t411, 1
  %t415 = shl i64 %t413, 16
  %t416 = load i64, ptr %l29, !tbaa !24
  %t419 = or i64 %t415, %t416
  store i64 %t419, ptr %l30, !tbaa !24
  %t421 = load ptr, ptr %l0, !tbaa !29
  %t422 = load i32, ptr %l22, !tbaa !23
  %t425 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eerrName(ptr %v0, ptr %s14, ptr %t421, i32 %t422)
  store { i64, ptr } %t425, ptr %l205
  br label %bb72
bb72:
  %t426 = load ptr, ptr %l0, !tbaa !29
  %t427 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t427, ptr %l207, !tbaa !27
  %t428 = load i64, ptr %l29, !tbaa !24
  %t430 = getelementptr { i64, ptr }, ptr %l207, i32 0, i32 1
  %t431 = load ptr, ptr %t430, !tbaa !27
  %t432 = getelementptr i32, ptr %t431, i64 %t428
  %t433 = load i32, ptr %t432, !tbaa !33
  %t436 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etext(ptr %v0, ptr %t426, i32 %t433)
  store { i64, ptr } %t436, ptr %l210
  br label %bb73
bb73:
  %t437 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d123, i32 0, i32 1) }, 1
  %t438 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d123, i32 0, i32 1) }, 0
  %t439 = load { i64, ptr }, ptr %l205, !tbaa !27
  %t440 = extractvalue { i64, ptr } %t439, 1
  %t441 = extractvalue { i64, ptr } %t439, 0
  %t442 = add i64 %t438, %t441
  %t443 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d124, i32 0, i32 1) }, 1
  %t444 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d124, i32 0, i32 1) }, 0
  %t445 = add i64 %t442, %t444
  %t446 = load { i64, ptr }, ptr %l210, !tbaa !27
  %t447 = extractvalue { i64, ptr } %t446, 1
  %t448 = extractvalue { i64, ptr } %t446, 0
  %t449 = add i64 %t445, %t448
  %t450 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d125, i32 0, i32 1) }, 1
  %t451 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d125, i32 0, i32 1) }, 0
  %t452 = add i64 %t449, %t451
  %t453 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t452)
  call void @olang_textcopy(ptr %t453, ptr %t437, i64 %t438)
  %t454 = getelementptr i8, ptr %t453, i64 %t438
  call void @olang_textcopy(ptr %t454, ptr %t440, i64 %t441)
  %t455 = getelementptr i8, ptr %t454, i64 %t441
  call void @olang_textcopy(ptr %t455, ptr %t443, i64 %t444)
  %t456 = getelementptr i8, ptr %t455, i64 %t444
  call void @olang_textcopy(ptr %t456, ptr %t447, i64 %t448)
  %t457 = getelementptr i8, ptr %t456, i64 %t448
  call void @olang_textcopy(ptr %t457, ptr %t450, i64 %t451)
  %t458 = insertvalue { i64, ptr } undef, i64 %t452, 0
  %t459 = insertvalue { i64, ptr } %t458, ptr %t453, 1
  store { i64, ptr } %t459, ptr %l31, !tbaa !27
  %t461 = load i64, ptr %l15, !tbaa !24
  %t462 = load i64, ptr %l30, !tbaa !24
  %t463 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d126, i32 0, i32 1) }, 1
  %t464 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d126, i32 0, i32 1) }, 0
  %t466 = call i64 @__olang_fmt_i64(ptr null, i64 %t461)
  %t467 = add i64 %t464, %t466
  %t468 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d127, i32 0, i32 1) }, 1
  %t469 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d127, i32 0, i32 1) }, 0
  %t470 = add i64 %t467, %t469
  %t472 = call i64 @__olang_fmt_i64(ptr null, i64 %t462)
  %t473 = add i64 %t470, %t472
  %t474 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d128, i32 0, i32 1) }, 1
  %t475 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d128, i32 0, i32 1) }, 0
  %t476 = add i64 %t473, %t475
  %t477 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t476)
  call void @olang_textcopy(ptr %t477, ptr %t463, i64 %t464)
  %t478 = getelementptr i8, ptr %t477, i64 %t464
  %t479 = call i64 @__olang_fmt_i64(ptr %t478, i64 %t461)
  %t480 = getelementptr i8, ptr %t478, i64 %t466
  call void @olang_textcopy(ptr %t480, ptr %t468, i64 %t469)
  %t481 = getelementptr i8, ptr %t480, i64 %t469
  %t482 = call i64 @__olang_fmt_i64(ptr %t481, i64 %t462)
  %t483 = getelementptr i8, ptr %t481, i64 %t472
  call void @olang_textcopy(ptr %t483, ptr %t474, i64 %t475)
  %t484 = insertvalue { i64, ptr } undef, i64 %t476, 0
  %t485 = insertvalue { i64, ptr } %t484, ptr %t477, 1
  %t487 = extractvalue { i64, ptr } %t485, 0
  %t488 = extractvalue { i64, ptr } %t485, 1
  %t489 = mul i64 %t487, 1
  %t490 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t489)
  call void @llvm.memcpy.p0.p0.i64(ptr %t490, ptr %t488, i64 %t489, i1 false)
  %t491 = insertvalue { i64, ptr } undef, i64 %t487, 0
  %t492 = insertvalue { i64, ptr } %t491, ptr %t490, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s14, ptr %l4, { i64, ptr } %t492)
  br label %bb74
bb74:
  store ptr %l4, ptr %l217, !tbaa !29
  %t495 = load i64, ptr %l15, !tbaa !24
  store i64 %t495, ptr %l218, !tbaa !24
  %t496 = load i64, ptr %l15, !tbaa !24
  store i64 %t496, ptr %l219, !tbaa !24
  %t497 = load ptr, ptr %l0, !tbaa !29
  %t498 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t501 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecstr(ptr %v0, ptr %s14, ptr %s14, ptr %t497, { i64, ptr } %t498)
  store { i64, ptr } %t501, ptr %l222
  br label %bb75
bb75:
  %t502 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t503 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d129, i32 0, i32 1) }, 1
  %t504 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d129, i32 0, i32 1) }, 0
  %t505 = load i64, ptr %l218, !tbaa !24
  %t506 = call i64 @__olang_fmt_i64(ptr null, i64 %t505)
  %t507 = add i64 %t504, %t506
  %t508 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d130, i32 0, i32 1) }, 1
  %t509 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d130, i32 0, i32 1) }, 0
  %t510 = add i64 %t507, %t509
  %t511 = load i64, ptr %l219, !tbaa !24
  %t512 = call i64 @__olang_fmt_i64(ptr null, i64 %t511)
  %t513 = add i64 %t510, %t512
  %t514 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d131, i32 0, i32 1) }, 1
  %t515 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d131, i32 0, i32 1) }, 0
  %t516 = add i64 %t513, %t515
  %t517 = load { i64, ptr }, ptr %l222, !tbaa !27
  %t518 = extractvalue { i64, ptr } %t517, 1
  %t519 = extractvalue { i64, ptr } %t517, 0
  %t520 = add i64 %t516, %t519
  %t521 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d131, i32 0, i32 1) }, 1
  %t522 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d131, i32 0, i32 1) }, 0
  %t523 = add i64 %t520, %t522
  %t525 = extractvalue { i64, ptr } %t502, 1
  %t526 = extractvalue { i64, ptr } %t502, 0
  %t527 = add i64 %t523, %t526
  %t528 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d132, i32 0, i32 1) }, 1
  %t529 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d132, i32 0, i32 1) }, 0
  %t530 = add i64 %t527, %t529
  %t531 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t530)
  call void @olang_textcopy(ptr %t531, ptr %t503, i64 %t504)
  %t532 = getelementptr i8, ptr %t531, i64 %t504
  %t533 = call i64 @__olang_fmt_i64(ptr %t532, i64 %t505)
  %t534 = getelementptr i8, ptr %t532, i64 %t506
  call void @olang_textcopy(ptr %t534, ptr %t508, i64 %t509)
  %t535 = getelementptr i8, ptr %t534, i64 %t509
  %t536 = call i64 @__olang_fmt_i64(ptr %t535, i64 %t511)
  %t537 = getelementptr i8, ptr %t535, i64 %t512
  call void @olang_textcopy(ptr %t537, ptr %t514, i64 %t515)
  %t538 = getelementptr i8, ptr %t537, i64 %t515
  call void @olang_textcopy(ptr %t538, ptr %t518, i64 %t519)
  %t539 = getelementptr i8, ptr %t538, i64 %t519
  call void @olang_textcopy(ptr %t539, ptr %t521, i64 %t522)
  %t540 = getelementptr i8, ptr %t539, i64 %t522
  call void @olang_textcopy(ptr %t540, ptr %t525, i64 %t526)
  %t541 = getelementptr i8, ptr %t540, i64 %t526
  call void @olang_textcopy(ptr %t541, ptr %t528, i64 %t529)
  %t542 = insertvalue { i64, ptr } undef, i64 %t530, 0
  %t543 = insertvalue { i64, ptr } %t542, ptr %t531, 1
  %t545 = extractvalue { i64, ptr } %t543, 0
  %t546 = extractvalue { i64, ptr } %t543, 1
  %t547 = mul i64 %t545, 1
  %t548 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t547)
  call void @llvm.memcpy.p0.p0.i64(ptr %t548, ptr %t546, i64 %t547, i1 false)
  %t549 = insertvalue { i64, ptr } undef, i64 %t545, 0
  %t550 = insertvalue { i64, ptr } %t549, ptr %t548, 1
  %t551 = load ptr, ptr %l217, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s14, ptr %t551, { i64, ptr } %t550)
  br label %bb76
bb76:
  %t553 = load i64, ptr %l15, !tbaa !24
  %t554 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d133, i32 0, i32 1) }, 1
  %t555 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d133, i32 0, i32 1) }, 0
  %t557 = call i64 @__olang_fmt_i64(ptr null, i64 %t553)
  %t558 = add i64 %t555, %t557
  %t559 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t558)
  call void @olang_textcopy(ptr %t559, ptr %t554, i64 %t555)
  %t560 = getelementptr i8, ptr %t559, i64 %t555
  %t561 = call i64 @__olang_fmt_i64(ptr %t560, i64 %t553)
  %t562 = insertvalue { i64, ptr } undef, i64 %t558, 0
  %t563 = insertvalue { i64, ptr } %t562, ptr %t559, 1
  store { i64, ptr } %t563, ptr %l227, !tbaa !27
  %t564 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t565 = extractvalue { i64, ptr } %t564, 0
  %t566 = load { i64, ptr }, ptr %l227, !tbaa !27
  %t567 = extractvalue { i64, ptr } %t566, 0
  store i64 %t567, ptr %l229, !tbaa !24
  %t569 = load i64, ptr %l229, !tbaa !24
  %t570 = icmp eq i64 %t565, %t569
  br i1 %t570, label %bb77, label %bb78
bb77:
  %t572 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t573 = load ptr, ptr %t572, !tbaa !27
  %t574 = getelementptr { i64, ptr }, ptr %l227, i32 0, i32 1
  %t575 = load ptr, ptr %t574, !tbaa !27
  %t576 = load i64, ptr %l229, !tbaa !24
  %t577 = mul i64 %t576, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t573, ptr %t575, i64 %t577, i1 false)
  br label %bb79
bb78:
  %t578 = load { i64, ptr }, ptr %l227, !tbaa !27
  store { i64, ptr } %t578, ptr %l14, !tbaa !27
  br label %bb79
bb79:
  call void @__olang_scope_close(ptr %s14)
  br label %bb80
bb80:
  %t579 = load i64, ptr %l28, !tbaa !24
  %t581 = add i64 %t579, 1
  store i64 %t581, ptr %l28, !tbaa !24
  br label %bb68
bb81:
  call void @__olang_scope_close(ptr %s12)
  br label %bb82
bb82:
  %t583 = load i64, ptr %l20, !tbaa !24
  %t585 = add i64 %t583, 1
  store i64 %t585, ptr %l20, !tbaa !24
  br label %bb55
bb83:
  %t587 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t588 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d134, i32 0, i32 1) }, 1
  %t589 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d134, i32 0, i32 1) }, 0
  %t591 = extractvalue { i64, ptr } %t587, 1
  %t592 = extractvalue { i64, ptr } %t587, 0
  %t593 = add i64 %t589, %t592
  %t594 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d135, i32 0, i32 1) }, 1
  %t595 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d135, i32 0, i32 1) }, 0
  %t596 = add i64 %t593, %t595
  %t597 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t596)
  call void @olang_textcopy(ptr %t597, ptr %t588, i64 %t589)
  %t598 = getelementptr i8, ptr %t597, i64 %t589
  call void @olang_textcopy(ptr %t598, ptr %t591, i64 %t592)
  %t599 = getelementptr i8, ptr %t598, i64 %t592
  call void @olang_textcopy(ptr %t599, ptr %t594, i64 %t595)
  %t600 = insertvalue { i64, ptr } undef, i64 %t596, 0
  %t601 = insertvalue { i64, ptr } %t600, ptr %t597, 1
  %t603 = extractvalue { i64, ptr } %t601, 0
  %t604 = extractvalue { i64, ptr } %t601, 1
  %t605 = mul i64 %t603, 1
  %t606 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t605)
  call void @llvm.memcpy.p0.p0.i64(ptr %t606, ptr %t604, i64 %t605, i1 false)
  %t607 = insertvalue { i64, ptr } undef, i64 %t603, 0
  %t608 = insertvalue { i64, ptr } %t607, ptr %t606, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l4, { i64, ptr } %t608)
  br label %bb84
bb84:
  %t611 = load ptr, ptr %l0, !tbaa !29
  %t613 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2etraced(ptr %v0, ptr %t611)
  store i1 %t613, ptr %l240
  br label %bb85
bb85:
  %t614 = load i1, ptr %l240, !tbaa !21
  br i1 %t614, label %bb86, label %bb87
bb86:
  store %olang.scope zeroinitializer, ptr %s22
  %t615 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s22, ptr %s22, ptr %t615, { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d136, i32 0, i32 1) }, { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d137, i32 0, i32 1) })
  br label %bb88
bb87:
  store %olang.scope zeroinitializer, ptr %s23
  %t617 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s23, ptr %s23, ptr %t617, { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d138, i32 0, i32 1) }, { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d139, i32 0, i32 1) })
  br label %bb90
bb88:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s22, ptr %l4, { i64, ptr } { i64 54, ptr getelementptr inbounds (<{ i64, [54 x i8] }>, ptr @.d140, i32 0, i32 1) })
  br label %bb89
bb89:
  call void @__olang_scope_close(ptr %s22)
  br label %bb92
bb90:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s23, ptr %l4, { i64, ptr } { i64 58, ptr getelementptr inbounds (<{ i64, [58 x i8] }>, ptr @.d141, i32 0, i32 1) })
  br label %bb91
bb91:
  call void @__olang_scope_close(ptr %s23)
  br label %bb92
bb92:
  %t621 = load ptr, ptr %l0, !tbaa !29
  store ptr %t621, ptr %l245, !tbaa !29
  %t622 = load ptr, ptr %l0, !tbaa !29
  %t624 = getelementptr %"compiler/emit:Emitter", ptr %t622, i32 0, i32 0
  %t625 = load ptr, ptr %t624, !tbaa !29
  %t627 = getelementptr %"compiler/generic:Program", ptr %t625, i32 0, i32 0
  %t628 = load ptr, ptr %t627, !tbaa !29
  %t630 = getelementptr %"compiler/load:Loader", ptr %t628, i32 0, i32 7
  %t631 = load i64, ptr %t630, !tbaa !24
  store i64 %t631, ptr %l249, !tbaa !24
  %t633 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l4)
  store { i64, ptr } %t633, ptr %l251
  br label %bb93
bb93:
  %t634 = load ptr, ptr %l245, !tbaa !29
  %t635 = load i64, ptr %l249, !tbaa !24
  %t636 = load { i64, ptr }, ptr %l251, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eitem(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %t634, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d142, i32 0, i32 1) }, i64 %t635, { i64, ptr } %t636, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d8, i32 0, i32 1) })
  br label %bb94
bb94:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eexportArrayResult(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l5 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca i1
  %l11 = alloca i1
  %l14 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  store ptr %t6, ptr %l5, !tbaa !29
  %t7 = load ptr, ptr %l2, !tbaa !29
  %t8 = load i32, ptr %l1, !tbaa !23
  %t11 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t7, i32 %t8)
  store i32 %t11, ptr %l8
  br label %bb1
bb1:
  %t12 = load ptr, ptr %l5, !tbaa !29
  %t13 = load i32, ptr %l8, !tbaa !23
  %t14 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t12, i32 %t13)
  store i1 %t14, ptr %l9
  br label %bb2
bb2:
  %t15 = load i1, ptr %l9, !tbaa !21
  %t16 = xor i1 %t15, true
  br i1 %t16, label %bb3, label %bb4
bb3:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load i32, ptr %l1, !tbaa !23
  %t22 = call i32 @compiler_2femit_2ecompiler_2femit_3aEmitter_2earrayOfE(ptr %v0, ptr %t18, i32 %t19)
  store i32 %t22, ptr %l14
  br label %bb5
bb4:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb6
bb5:
  %t23 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t24 = load i32, ptr %l14, !tbaa !23
  %t26 = icmp ne i32 %t24, %t23
  store i1 %t26, ptr %l11, !tbaa !21
  br label %bb6
bb6:
  %t28 = load i1, ptr %l11, !tbaa !21
  store i1 %t28, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2femit_2ecompiler_2femit_3aEmitter_2eexportBodies(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %lp1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca { i64, [2 x i64] }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l18 = alloca i64
  %l22 = alloca i64
  %l25 = alloca i64
  %l47 = alloca ptr
  %l55 = alloca i64
  %l58 = alloca ptr
  %l61 = alloca i1
  %l66 = alloca ptr
  %l71 = alloca i1
  %l75 = alloca i1
  %l78 = alloca i64
  %s2 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l12
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t2, ptr %lp1
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l12
  %t4 = load ptr, ptr %lp1
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %t4
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/emit:Emitter", ptr %t5, i32 0, i32 0
  %t8 = load ptr, ptr %t7, !tbaa !29
  store ptr %t8, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/emit:Emitter", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = getelementptr %"compiler/lower:Lowerer", ptr %t13, i32 0, i32 1
  %t17 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_Ha6bcf4d517e3d7b46809e1dbf938da91(ptr %v0, ptr %t15)
  store i64 %t17, ptr %l18
  br label %bb2
bb2:
  %t18 = load i64, ptr %l18, !tbaa !24
  store i64 %t18, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t19 = load i64, ptr %l4, !tbaa !24
  %t20 = load i64, ptr %l3, !tbaa !24
  %t23 = icmp sgt i64 %t19, %t20
  br i1 %t23, label %bb3, label %bb4
bb3:
  %t25 = load i64, ptr %l5, !tbaa !24
  %t27 = icmp sgt i64 %t25, 0
  br i1 %t27, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb8
bb5:
  %t29 = load i64, ptr %l4, !tbaa !24
  %t30 = load i64, ptr %l3, !tbaa !24
  %t33 = sub i64 %t29, %t30
  %t34 = load i64, ptr %l5, !tbaa !24
  %t37 = add i64 %t33, %t34
  %t39 = sub i64 %t37, 1
  %t40 = load i64, ptr %l5, !tbaa !24
  %t43 = sdiv i64 %t39, %t40
  store i64 %t43, ptr %l25, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l25, !tbaa !24
  br label %bb7
bb7:
  %t45 = load i64, ptr %l25, !tbaa !24
  store i64 %t45, ptr %l22, !tbaa !24
  br label %bb8
bb8:
  %t46 = load i64, ptr %l22, !tbaa !24
  store i64 %t46, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t47 = load i64, ptr %l7, !tbaa !24
  %t48 = load i64, ptr %l6, !tbaa !24
  %t51 = icmp slt i64 %t47, %t48
  %t53 = xor i1 %t51, true
  br i1 %t53, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb41
bb11:
  br label %bb12
bb12:
  %t55 = load i64, ptr %l3, !tbaa !24
  %t56 = load i64, ptr %l7, !tbaa !24
  %t57 = load i64, ptr %l5, !tbaa !24
  %t60 = mul i64 %t56, %t57
  %t63 = add i64 %t55, %t60
  store i64 %t63, ptr %l8, !tbaa !24
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/emit:Emitter", ptr %t65, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !29
  %t70 = getelementptr %"compiler/lower:Lowerer", ptr %t68, i32 0, i32 1
  %t71 = load i64, ptr %l8, !tbaa !24
  %t74 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t70, i64 %t71)
  store ptr %t74, ptr %l47
  br label %bb13
bb13:
  %t75 = load ptr, ptr %l47, !tbaa !29
  %t77 = getelementptr %"compiler/typed:Body", ptr %t75, i32 0, i32 1
  %t78 = load { i64, [2 x i64] }, ptr %t77
  store { i64, [2 x i64] } %t78, ptr %l9
  %t80 = load { i64, [2 x i64] }, ptr %l9
  %t82 = extractvalue { i64, [2 x i64] } %t80, 0
  %t83 = icmp eq i64 %t82, 0
  br i1 %t83, label %bb14, label %bb15
bb14:
  %t85 = getelementptr { i64, [2 x i64] }, ptr %l9, i32 0, i32 1
  %t86 = getelementptr { i64 }, ptr %t85, i32 0, i32 0
  %t87 = load i64, ptr %t86
  store i64 %t87, ptr %l10, !tbaa !24
  br label %bb16
bb15:
  br label %bb34
bb16:
  %t89 = load ptr, ptr %l2, !tbaa !29
  %t90 = load i64, ptr %l10, !tbaa !24
  %t93 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t89, i64 %t90)
  store i64 %t93, ptr %l55
  br label %bb17
bb17:
  %t94 = load i64, ptr %l55, !tbaa !24
  store i64 %t94, ptr %l11, !tbaa !24
  %t95 = load ptr, ptr %l2, !tbaa !29
  %t96 = load i64, ptr %l11, !tbaa !24
  %t99 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t95, i64 %t96)
  store ptr %t99, ptr %l58
  br label %bb18
bb18:
  %t100 = load ptr, ptr %l58, !tbaa !29
  %t102 = getelementptr %"compiler/ast:Func", ptr %t100, i32 0, i32 7
  %t103 = load i1, ptr %t102, !tbaa !21
  br i1 %t103, label %bb19, label %bb20
bb19:
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr %"compiler/emit:Emitter", ptr %t105, i32 0, i32 1
  %t108 = load ptr, ptr %t107, !tbaa !29
  %t110 = getelementptr %"compiler/lower:Lowerer", ptr %t108, i32 0, i32 1
  %t111 = load i64, ptr %l8, !tbaa !24
  %t114 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t110, i64 %t111)
  store ptr %t114, ptr %l66
  br label %bb21
bb20:
  store i1 false, ptr %l61, !tbaa !21
  br label %bb22
bb21:
  %t115 = load ptr, ptr %l66, !tbaa !29
  %t117 = getelementptr %"compiler/typed:Body", ptr %t115, i32 0, i32 11
  %t118 = load ptr, ptr %t117, !tbaa !29
  %t120 = icmp eq ptr %t118, null
  %t122 = xor i1 %t120, true
  store i1 %t122, ptr %l61, !tbaa !21
  br label %bb22
bb22:
  %t124 = load i1, ptr %l61, !tbaa !21
  br i1 %t124, label %bb23, label %bb24
bb23:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t127 = getelementptr %"compiler/emit:Emitter", ptr %t125, i32 0, i32 38
  %t128 = load i1, ptr %t127, !tbaa !21
  %t130 = xor i1 %t128, true
  br i1 %t130, label %bb25, label %bb26
bb24:
  store i1 false, ptr %l71, !tbaa !21
  br label %bb29
bb25:
  store i1 true, ptr %l75, !tbaa !21
  br label %bb28
bb26:
  %t132 = load ptr, ptr %l2, !tbaa !29
  %t133 = load i64, ptr %l11, !tbaa !24
  %t136 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t132, i64 %t133)
  store i64 %t136, ptr %l78
  br label %bb27
bb27:
  %t137 = load ptr, ptr %l2, !tbaa !29
  %t139 = getelementptr %"compiler/generic:Program", ptr %t137, i32 0, i32 0
  %t140 = load ptr, ptr %t139, !tbaa !29
  %t142 = getelementptr %"compiler/load:Loader", ptr %t140, i32 0, i32 7
  %t143 = load i64, ptr %t142, !tbaa !24
  %t144 = load i64, ptr %l78, !tbaa !24
  %t146 = icmp eq i64 %t144, %t143
  store i1 %t146, ptr %l75, !tbaa !21
  br label %bb28
bb28:
  %t148 = load i1, ptr %l75, !tbaa !21
  store i1 %t148, ptr %l71, !tbaa !21
  br label %bb29
bb29:
  %t149 = load i1, ptr %l71, !tbaa !21
  br i1 %t149, label %bb30, label %bb31
bb30:
  %t150 = load ptr, ptr %lp1
  %t151 = load i64, ptr %l8, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t150, i64 %t151)
  br label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb33
bb33:
  br label %bb39
bb34:
  br i1 true, label %bb35, label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb38
bb37:
  br label %bb39
bb38:
  call void @__olang_check_failed(ptr @olang_loc_70000d3e005ea498_c6a0fd2b538569fc)
  unreachable
bb39:
  call void @__olang_scope_close(ptr %s2)
  br label %bb40
bb40:
  %t154 = load i64, ptr %l7, !tbaa !24
  %t156 = add i64 %t154, 1
  store i64 %t156, ptr %l7, !tbaa !24
  br label %bb9
bb41:
  %t158 = load ptr, ptr %lp1
  %t159 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t158
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t159, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eexportEntry(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca { i64, [2 x i64] }
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i32
  %l10 = alloca { i64, [2 x i64] }
  %l11 = alloca ptr
  %l12 = alloca i32
  %l13 = alloca i1
  %l14 = alloca i1
  %l15 = alloca i1
  %l16 = alloca %"compiler/cabi:Way"
  %l17 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l18 = alloca %"compiler/cabi:Regs"
  %l19 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i32
  %l29 = alloca i32
  %l30 = alloca { i64, ptr }
  %l31 = alloca i32
  %l33 = alloca %"compiler/cabi:Way"
  %l34 = alloca i32
  %l35 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l44 = alloca i32
  %l47 = alloca { i64, ptr }
  %l48 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l49 = alloca { i64, ptr }
  %l50 = alloca i64
  %l51 = alloca i64
  %l52 = alloca i64
  %l53 = alloca i64
  %l54 = alloca i64
  %l55 = alloca i64
  %l56 = alloca ptr
  %l57 = alloca i64
  %l58 = alloca { i64, ptr }
  %l59 = alloca i64
  %l60 = alloca i64
  %l62 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %l64 = alloca %"std/prelude/text:StringBuilder"
  %l65 = alloca ptr
  %l66 = alloca i64
  %l67 = alloca i64
  %l68 = alloca { i64, ptr }
  %l69 = alloca i64
  %l70 = alloca i64
  %l72 = alloca { i64, ptr }
  %l73 = alloca { i64, ptr }
  %l74 = alloca { i64, ptr }
  %l75 = alloca { i64, ptr }
  %l77 = alloca i32
  %l78 = alloca { i64, ptr }
  %l79 = alloca { i64, ptr }
  %l81 = alloca { i64, ptr }
  %l83 = alloca { i64, ptr }
  %l84 = alloca i32
  %l85 = alloca { i64, ptr }
  %l86 = alloca { i64, ptr }
  %l87 = alloca { i64, ptr }
  %l88 = alloca i64
  %l89 = alloca i64
  %l90 = alloca i64
  %l91 = alloca i64
  %l92 = alloca i64
  %l93 = alloca i64
  %l94 = alloca { i64, ptr }
  %l95 = alloca { i64, ptr }
  %l96 = alloca i32
  %l97 = alloca %"std/prelude/text:StringBuilder"
  %l98 = alloca ptr
  %l99 = alloca i64
  %l100 = alloca i64
  %l101 = alloca { i64, ptr }
  %l102 = alloca i64
  %l103 = alloca i64
  %l105 = alloca { i64, ptr }
  %l114 = alloca ptr
  %l122 = alloca i64
  %l123 = alloca ptr
  %l126 = alloca ptr
  %l129 = alloca { i64, ptr }
  %l139 = alloca ptr
  %l140 = alloca { i64, [2 x i64] }
  %l141 = alloca i32
  %l142 = alloca %"compiler/source:Span"
  %l143 = alloca %"compiler/mir:Fn"
  %l146 = alloca %"compiler/emit:fnEm"
  %l150 = alloca i32
  %l154 = alloca i1
  %l161 = alloca i1
  %l162 = alloca ptr
  %l165 = alloca i32
  %l166 = alloca { i64, ptr }
  %l170 = alloca i1
  %l173 = alloca i1
  %l174 = alloca i32
  %l175 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l176 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l177 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l178 = alloca %"compiler/cabi:Way"
  %l180 = alloca i1
  %l183 = alloca i1
  %l190 = alloca %"compiler/cabi:Way"
  %l191 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l192 = alloca %"compiler/cabi:Regs"
  %l195 = alloca ptr
  %l198 = alloca { i64, ptr }
  %l201 = alloca i64
  %l206 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l207 = alloca ptr
  %l210 = alloca i32
  %l211 = alloca { i64, ptr }
  %l214 = alloca { i64, ptr }
  %l220 = alloca i64
  %l223 = alloca i64
  %l241 = alloca { i64, ptr }
  %l246 = alloca i1
  %l249 = alloca i32
  %l254 = alloca i1
  %l255 = alloca ptr
  %l258 = alloca i32
  %l259 = alloca i32
  %l262 = alloca i32
  %l265 = alloca i1
  %l268 = alloca i32
  %l284 = alloca { i64, ptr }
  %l285 = alloca ptr
  %l291 = alloca { i64, ptr }
  %l309 = alloca %"compiler/cabi:Way"
  %l313 = alloca ptr
  %l316 = alloca { i64, ptr }
  %l318 = alloca i1
  %l320 = alloca { i64, ptr }
  %l327 = alloca ptr
  %l330 = alloca { i64, ptr }
  %l336 = alloca ptr
  %l340 = alloca i64
  %l343 = alloca { i64, ptr }
  %l345 = alloca i64
  %l349 = alloca i64
  %l352 = alloca i64
  %l370 = alloca ptr
  %l373 = alloca { i64, ptr }
  %l380 = alloca i64
  %l382 = alloca { i64, ptr }
  %l384 = alloca ptr
  %l385 = alloca { i64, ptr }
  %l388 = alloca i64
  %l391 = alloca { i64, ptr }
  %l392 = alloca ptr
  %l395 = alloca { i64, ptr }
  %l397 = alloca { i64, ptr }
  %l398 = alloca { i64, ptr }
  %l399 = alloca { i64, ptr }
  %l409 = alloca { i64, ptr }
  %l411 = alloca i64
  %l413 = alloca i64
  %l414 = alloca { i64, ptr }
  %l417 = alloca ptr
  %l420 = alloca { i64, ptr }
  %l423 = alloca i64
  %l424 = alloca i64
  %l437 = alloca { i64, ptr }
  %l438 = alloca ptr
  %l439 = alloca { i64, ptr }
  %l440 = alloca { i64, ptr }
  %l443 = alloca i64
  %l448 = alloca ptr
  %l451 = alloca { i64, ptr }
  %l452 = alloca ptr
  %l455 = alloca { i64, ptr }
  %l458 = alloca { i64, ptr }
  %l465 = alloca ptr
  %l466 = alloca ptr
  %l469 = alloca i32
  %l470 = alloca i32
  %l471 = alloca i32
  %l474 = alloca i1
  %l480 = alloca i1
  %l487 = alloca { i64, ptr }
  %l492 = alloca { i64, ptr }
  %l504 = alloca { i64, ptr }
  %l507 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l508 = alloca { i64, ptr }
  %l509 = alloca { i64, ptr }
  %l510 = alloca i64
  %l511 = alloca { i64, ptr }
  %l513 = alloca i1
  %l516 = alloca i1
  %l519 = alloca { i64, ptr }
  %l521 = alloca i64
  %l532 = alloca i64
  %l536 = alloca i64
  %l539 = alloca i64
  %l564 = alloca { i64, ptr }
  %l567 = alloca { i64, ptr }
  %l568 = alloca i32
  %l577 = alloca { i64, ptr }
  %l589 = alloca { i64, ptr }
  %l590 = alloca { i64, ptr }
  %l591 = alloca { i64, ptr }
  %l592 = alloca i64
  %l593 = alloca { i64, ptr }
  %l594 = alloca %"std/prelude/text:StringBuilder"
  %l596 = alloca { i64, ptr }
  %l599 = alloca { i64, ptr }
  %l600 = alloca i32
  %l610 = alloca { i64, ptr }
  %l626 = alloca i1
  %l627 = alloca ptr
  %l630 = alloca { i64, ptr }
  %l632 = alloca { i64, ptr }
  %l635 = alloca ptr
  %l636 = alloca { i64, ptr }
  %l639 = alloca { i64, ptr }
  %l641 = alloca { i64, ptr }
  %l644 = alloca { i64, ptr }
  %l646 = alloca i64
  %l648 = alloca { i64, ptr }
  %l649 = alloca { i64, ptr }
  %l650 = alloca i64
  %l651 = alloca { i64, ptr }
  %l652 = alloca { i64, ptr }
  %l653 = alloca { i64, ptr }
  %l654 = alloca i64
  %l655 = alloca { i64, ptr }
  %l658 = alloca i1
  %l660 = alloca i1
  %l663 = alloca { i64, ptr }
  %l670 = alloca { i64, ptr }
  %l672 = alloca i64
  %l675 = alloca i1
  %l677 = alloca i1
  %l683 = alloca { i64, ptr }
  %l685 = alloca i64
  %l688 = alloca i1
  %l690 = alloca i1
  %l691 = alloca { i64, ptr }
  %l693 = alloca i64
  %l695 = alloca i64
  %l696 = alloca { i64, ptr }
  %l698 = alloca i1
  %l700 = alloca i1
  %l702 = alloca ptr
  %l705 = alloca { i64, ptr }
  %l708 = alloca { i64, ptr }
  %l710 = alloca i64
  %l712 = alloca { i64, ptr }
  %l713 = alloca { i64, ptr }
  %l714 = alloca i64
  %l715 = alloca { i64, ptr }
  %l721 = alloca { i64, ptr }
  %l732 = alloca ptr
  %l734 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l736 = alloca { i64, ptr }
  %l737 = alloca i32
  %l738 = alloca ptr
  %l739 = alloca ptr
  %l740 = alloca { i64, ptr }
  %l743 = alloca i32
  %l745 = alloca { i64, ptr }
  %l755 = alloca { i64, ptr }
  %l760 = alloca { i64, ptr }
  %l765 = alloca { i64, ptr }
  %l771 = alloca { i64, ptr }
  %l776 = alloca { i64, ptr }
  %l782 = alloca { i64, ptr }
  %l784 = alloca i64
  %l786 = alloca ptr
  %l787 = alloca { i64, ptr }
  %l790 = alloca i64
  %l793 = alloca { i64, ptr }
  %l803 = alloca { i64, ptr }
  %l804 = alloca { i64, ptr }
  %l806 = alloca i64
  %l808 = alloca i64
  %l809 = alloca { i64, ptr }
  %l811 = alloca { i64, ptr }
  %l813 = alloca i64
  %l817 = alloca ptr
  %l820 = alloca { i64, ptr }
  %l823 = alloca { i64, ptr }
  %l824 = alloca { i64, ptr }
  %l826 = alloca i64
  %l828 = alloca i64
  %l829 = alloca { i64, ptr }
  %l836 = alloca { i64, ptr }
  %l838 = alloca { i64, ptr }
  %l840 = alloca i64
  %l844 = alloca ptr
  %l848 = alloca i64
  %l851 = alloca { i64, ptr }
  %l852 = alloca ptr
  %l855 = alloca { i64, ptr }
  %l860 = alloca { i64, ptr }
  %l862 = alloca i64
  %l864 = alloca { i64, ptr }
  %l868 = alloca { i64, ptr }
  %l869 = alloca { i64, ptr }
  %l871 = alloca i64
  %l873 = alloca { i64, ptr }
  %l874 = alloca { i64, ptr }
  %l875 = alloca i64
  %l876 = alloca { i64, ptr }
  %l878 = alloca i64
  %l882 = alloca i64
  %l885 = alloca i64
  %l905 = alloca i64
  %l907 = alloca { i64, ptr }
  %l909 = alloca ptr
  %l910 = alloca { i64, ptr }
  %l913 = alloca i64
  %l916 = alloca { i64, ptr }
  %l917 = alloca ptr
  %l918 = alloca { i64, ptr }
  %l919 = alloca { i64, ptr }
  %l922 = alloca { i64, ptr }
  %l923 = alloca ptr
  %l926 = alloca { i64, ptr }
  %l928 = alloca { i64, ptr }
  %l932 = alloca { i64, ptr }
  %l934 = alloca i64
  %l940 = alloca { i64, ptr }
  %l942 = alloca i64
  %l944 = alloca ptr
  %l947 = alloca { i64, ptr }
  %l954 = alloca ptr
  %l956 = alloca i1
  %l958 = alloca { i64, ptr }
  %l962 = alloca { i64, ptr }
  %l963 = alloca { i64, ptr }
  %l964 = alloca i64
  %l965 = alloca { i64, ptr }
  %l967 = alloca { i64, ptr }
  %l968 = alloca { i64, ptr }
  %l970 = alloca i64
  %l972 = alloca i64
  %l973 = alloca { i64, ptr }
  %l975 = alloca { i64, ptr }
  %l976 = alloca { i64, ptr }
  %l978 = alloca i64
  %l980 = alloca i64
  %l981 = alloca { i64, ptr }
  %l984 = alloca { i64, ptr }
  %l988 = alloca i1
  %l990 = alloca { i64, ptr }
  %l996 = alloca { i64, ptr }
  %l1001 = alloca { i64, ptr }
  %l1002 = alloca { i64, ptr }
  %l1005 = alloca i64
  %l1007 = alloca %"std/prelude/text:StringBuilder"
  %l1014 = alloca { i64, ptr }
  %l1017 = alloca { i64, ptr }
  %l1018 = alloca i32
  %l1028 = alloca { i64, ptr }
  %l1044 = alloca ptr
  %l1047 = alloca { i64, ptr }
  %l1048 = alloca ptr
  %l1051 = alloca { i64, ptr }
  %l1053 = alloca ptr
  %l1054 = alloca { i64, ptr }
  %l1057 = alloca i64
  %l1059 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %s33 = alloca %olang.scope
  %s37 = alloca %olang.scope
  %s39 = alloca %olang.scope
  %s51 = alloca %olang.scope
  %s55 = alloca %olang.scope
  %s56 = alloca %olang.scope
  %s59 = alloca %olang.scope
  %s60 = alloca %olang.scope
  %s61 = alloca %olang.scope
  %s63 = alloca %olang.scope
  %s65 = alloca %olang.scope
  %s67 = alloca %olang.scope
  %s71 = alloca %olang.scope
  %s74 = alloca %olang.scope
  %s79 = alloca %olang.scope
  %s88 = alloca %olang.scope
  %s93 = alloca %olang.scope
  %s96 = alloca %olang.scope
  %s98 = alloca %olang.scope
  %s100 = alloca %olang.scope
  %s102 = alloca %olang.scope
  %s104 = alloca %olang.scope
  %s109 = alloca %olang.scope
  %s117 = alloca %olang.scope
  %s124 = alloca %olang.scope
  %s125 = alloca %olang.scope
  %s126 = alloca %olang.scope
  %t71 = alloca { i64, [2 x i64] }, align 8
  %t86 = alloca %"compiler/mir:Fn", align 8
  %t92 = alloca %"compiler/emit:fnEm", align 8
  %t1275 = alloca { i64, [7 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/emit:Emitter", ptr %t6, i32 0, i32 0
  %t9 = load ptr, ptr %t8, !tbaa !29
  store ptr %t9, ptr %l3, !tbaa !29
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/emit:Emitter", ptr %t11, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t16 = getelementptr %"compiler/lower:Lowerer", ptr %t14, i32 0, i32 1
  %t17 = load i64, ptr %l1, !tbaa !24
  %t20 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t16, i64 %t17)
  store ptr %t20, ptr %l114
  br label %bb1
bb1:
  %t21 = load ptr, ptr %l114, !tbaa !29
  store ptr %t21, ptr %l4, !tbaa !29
  store i64 -1, ptr %l5, !tbaa !24
  %t22 = load ptr, ptr %l4, !tbaa !29
  %t24 = getelementptr %"compiler/typed:Body", ptr %t22, i32 0, i32 1
  %t25 = load { i64, [2 x i64] }, ptr %t24
  store { i64, [2 x i64] } %t25, ptr %l6
  %t27 = load { i64, [2 x i64] }, ptr %l6
  %t29 = extractvalue { i64, [2 x i64] } %t27, 0
  %t30 = icmp eq i64 %t29, 0
  br i1 %t30, label %bb2, label %bb3
bb2:
  %t32 = getelementptr { i64, [2 x i64] }, ptr %l6, i32 0, i32 1
  %t33 = getelementptr { i64 }, ptr %t32, i32 0, i32 0
  %t34 = load i64, ptr %t33
  store i64 %t34, ptr %l7, !tbaa !24
  br label %bb4
bb3:
  br label %bb6
bb4:
  %t36 = load ptr, ptr %l3, !tbaa !29
  %t37 = load i64, ptr %l7, !tbaa !24
  %t40 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t36, i64 %t37)
  store i64 %t40, ptr %l122
  br label %bb5
bb5:
  %t41 = load i64, ptr %l122, !tbaa !24
  store i64 %t41, ptr %l5, !tbaa !24
  br label %bb11
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb10:
  call void @__olang_check_failed(ptr @olang_loc_8dd51a70be22f844_db8bd8df095848b0)
  unreachable
bb11:
  %t42 = load ptr, ptr %l0, !tbaa !29
  store ptr %t42, ptr %l123, !tbaa !29
  %t43 = load ptr, ptr %l3, !tbaa !29
  %t44 = load i64, ptr %l5, !tbaa !24
  %t47 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t43, i64 %t44)
  store ptr %t47, ptr %l126
  br label %bb12
bb12:
  %t48 = load ptr, ptr %l126, !tbaa !29
  %t50 = getelementptr %"compiler/ast:Func", ptr %t48, i32 0, i32 2
  %t51 = load i32, ptr %t50, !tbaa !23
  %t52 = load ptr, ptr %l123, !tbaa !29
  %t54 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etext(ptr %v0, ptr %t52, i32 %t51)
  store { i64, ptr } %t54, ptr %l129
  br label %bb13
bb13:
  %t55 = load { i64, ptr }, ptr %l129, !tbaa !27
  %t56 = extractvalue { i64, ptr } %t55, 1
  %t57 = extractvalue { i64, ptr } %t55, 0
  %t58 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t57)
  call void @olang_textcopy(ptr %t58, ptr %t56, i64 %t57)
  %t59 = insertvalue { i64, ptr } undef, i64 %t57, 0
  %t60 = insertvalue { i64, ptr } %t59, ptr %t58, 1
  store { i64, ptr } %t60, ptr %l8, !tbaa !27
  %t62 = load ptr, ptr %l4, !tbaa !29
  %t64 = getelementptr %"compiler/typed:Body", ptr %t62, i32 0, i32 2
  %t65 = load i32, ptr %t64, !tbaa !23
  store i32 %t65, ptr %l9, !tbaa !23
  %t67 = load i64, ptr %l1, !tbaa !24
  %t69 = trunc i64 %t67 to i32
  store { i64, [2 x i64] } zeroinitializer, ptr %t71
  %t72 = getelementptr { i64, [2 x i64] }, ptr %t71, i32 0, i32 0
  store i64 0, ptr %t72
  %t74 = insertvalue { i32 } undef, i32 %t69, 0
  %t75 = getelementptr { i64, [2 x i64] }, ptr %t71, i32 0, i32 1
  store { i32 } %t74, ptr %t75
  %t76 = load { i64, [2 x i64] }, ptr %t71
  store { i64, [2 x i64] } %t76, ptr %l10
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t79 = load { i64, [2 x i64] }, ptr %l10
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2ewant(ptr %v0, ptr %t78, { i64, [2 x i64] } %t79)
  br label %bb14
bb14:
  %t82 = load ptr, ptr %l0, !tbaa !29
  store ptr %t82, ptr %l139, !tbaa !29
  %t83 = load { i64, [2 x i64] }, ptr %l10
  store { i64, [2 x i64] } %t83, ptr %l140
  %t84 = load i32, ptr %l9, !tbaa !23
  store i32 %t84, ptr %l141, !tbaa !23
  %t85 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 0, i32 0)
  store %"compiler/source:Span" %t85, ptr %l142
  br label %bb15
bb15:
  %t87 = load { i64, [2 x i64] }, ptr %l140
  %t88 = load i32, ptr %l141, !tbaa !23
  %t89 = load %"compiler/source:Span", ptr %l142
  call void @compiler_2fmir_3aFn_2ector(ptr %t86, ptr %v0, { i64, [2 x i64] } %t87, i32 %t88, i64 0, %"compiler/source:Span" %t89)
  call void @llvm.memmove.p0.p0.i64(ptr %l143, ptr %t86, i64 232, i1 false)
  br label %bb16
bb16:
  %t90 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 232, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t90, ptr %l143, i64 232, i1 false)
  %t91 = load { i64, [2 x i64] }, ptr %l10
  %t93 = load ptr, ptr %l139, !tbaa !29
  call void @compiler_2femit_3afnEm_2ector(ptr %t92, ptr %v0, ptr %v0, ptr %v0, ptr %t93, ptr %t90, { i64, [2 x i64] } %t91)
  call void @llvm.memmove.p0.p0.i64(ptr %l146, ptr %t92, i64 240, i1 false)
  br label %bb17
bb17:
  %t96 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 240, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t96, ptr %l146, i64 240, i1 false)
  store ptr %t96, ptr %l11, !tbaa !29
  %t98 = load ptr, ptr %l2, !tbaa !29
  %t99 = load i32, ptr %l9, !tbaa !23
  %t102 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t98, i32 %t99)
  store i32 %t102, ptr %l150
  br label %bb18
bb18:
  %t103 = load i32, ptr %l150, !tbaa !23
  store i32 %t103, ptr %l12, !tbaa !23
  %t104 = load i32, ptr %l12, !tbaa !23
  %t105 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t108 = icmp ne i32 %t104, %t105
  br i1 %t108, label %bb19, label %bb20
bb19:
  %t110 = load i32, ptr %l12, !tbaa !23
  %t111 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t114 = icmp ne i32 %t110, %t111
  store i1 %t114, ptr %l154, !tbaa !21
  br label %bb21
bb20:
  store i1 false, ptr %l154, !tbaa !21
  br label %bb21
bb21:
  %t116 = load i1, ptr %l154, !tbaa !21
  store i1 %t116, ptr %l13, !tbaa !21
  %t117 = load i1, ptr %l13, !tbaa !21
  br i1 %t117, label %bb22, label %bb23
bb22:
  %t119 = load ptr, ptr %l3, !tbaa !29
  %t120 = load i32, ptr %l12, !tbaa !23
  %t123 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLayout(ptr %v0, ptr %t119, i32 %t120)
  store i1 %t123, ptr %l161
  br label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb25
bb25:
  %t124 = load ptr, ptr %l2, !tbaa !29
  store ptr %t124, ptr %l162, !tbaa !29
  %t125 = load ptr, ptr %l2, !tbaa !29
  %t126 = load i32, ptr %l9, !tbaa !23
  %t129 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t125, i32 %t126)
  store i32 %t129, ptr %l165
  br label %bb26
bb26:
  %t130 = load ptr, ptr %l162, !tbaa !29
  %t131 = load i32, ptr %l165, !tbaa !23
  %t132 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t130, i32 %t131)
  store { i64, ptr } %t132, ptr %l166
  br label %bb27
bb27:
  %t133 = load { i64, ptr }, ptr %l166, !tbaa !27
  %t134 = extractvalue { i64, ptr } %t133, 0
  %t136 = icmp sgt i64 %t134, 0
  store i1 %t136, ptr %l14, !tbaa !21
  %t138 = load i1, ptr %l13, !tbaa !21
  br i1 %t138, label %bb28, label %bb29
bb28:
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t141 = load i32, ptr %l12, !tbaa !23
  %t144 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eexportArrayResult(ptr %v0, ptr %t140, i32 %t141)
  store i1 %t144, ptr %l173
  br label %bb30
bb29:
  store i1 false, ptr %l170, !tbaa !21
  br label %bb31
bb30:
  %t145 = load i1, ptr %l173, !tbaa !21
  store i1 %t145, ptr %l170, !tbaa !21
  br label %bb31
bb31:
  %t146 = load i1, ptr %l170, !tbaa !21
  store i1 %t146, ptr %l15, !tbaa !21
  store i32 0, ptr %l174
  %t147 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t147, ptr %l175
  br label %bb32
bb32:
  %t148 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %s0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t148, ptr %l176
  br label %bb33
bb33:
  %t149 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %s0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t149, ptr %l177
  br label %bb34
bb34:
  %t150 = load i32, ptr %l174
  %t151 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l175
  %t152 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l176
  %t153 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l177
  %t154 = call %"compiler/cabi:Way" @compiler_2fcabi_3aWay_2ector(ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, i32 %t150, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t151, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t152, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t153, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d143, i32 0, i32 1) })
  store %"compiler/cabi:Way" %t154, ptr %l178
  br label %bb35
bb35:
  %t155 = load %"compiler/cabi:Way", ptr %l178
  store %"compiler/cabi:Way" %t155, ptr %l16
  %t156 = load i1, ptr %l13, !tbaa !21
  br i1 %t156, label %bb36, label %bb37
bb36:
  %t158 = load i1, ptr %l14, !tbaa !21
  %t160 = xor i1 %t158, true
  store i1 %t160, ptr %l180, !tbaa !21
  br label %bb38
bb37:
  store i1 false, ptr %l180, !tbaa !21
  br label %bb38
bb38:
  %t162 = load i1, ptr %l180, !tbaa !21
  br i1 %t162, label %bb39, label %bb40
bb39:
  %t163 = load i1, ptr %l15, !tbaa !21
  %t165 = xor i1 %t163, true
  store i1 %t165, ptr %l183, !tbaa !21
  br label %bb41
bb40:
  store i1 false, ptr %l183, !tbaa !21
  br label %bb41
bb41:
  %t167 = load i1, ptr %l183, !tbaa !21
  br i1 %t167, label %bb42, label %bb43
bb42:
  %t168 = load ptr, ptr %l2, !tbaa !29
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t171 = getelementptr %"compiler/emit:Emitter", ptr %t169, i32 0, i32 45
  %t172 = load { i64, ptr }, ptr %t171, !tbaa !27
  %t173 = load i32, ptr %l12, !tbaa !23
  %t177 = call %"compiler/cabi:Way" @compiler_2fcabi_2eResult(ptr %v0, ptr %v0, ptr %s0, ptr %t168, { i64, ptr } %t172, i32 %t173)
  store %"compiler/cabi:Way" %t177, ptr %l190
  br label %bb44
bb43:
  br label %bb45
bb44:
  %t178 = load %"compiler/cabi:Way", ptr %l190
  store %"compiler/cabi:Way" %t178, ptr %l16
  br label %bb45
bb45:
  %t179 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %s0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t179, ptr %l191
  br label %bb46
bb46:
  %t180 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l191
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t180, ptr %l17
  %t181 = call %"compiler/cabi:Regs" @compiler_2fcabi_3aRegs_2ector(ptr %s0, i64 6, i64 8)
  store %"compiler/cabi:Regs" %t181, ptr %l192
  br label %bb47
bb47:
  %t182 = load %"compiler/cabi:Regs", ptr %l192
  store %"compiler/cabi:Regs" %t182, ptr %l18
  %t183 = getelementptr %"compiler/cabi:Way", ptr %l16, i32 0, i32 0
  %t184 = load i32, ptr %t183
  %t186 = trunc i64 4 to i32
  %t187 = icmp eq i32 %t184, %t186
  br i1 %t187, label %bb48, label %bb49
bb48:
  store %olang.scope zeroinitializer, ptr %s6
  store ptr %l17, ptr %l195, !tbaa !29
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t190 = load i32, ptr %l12, !tbaa !23
  %t193 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %s6, ptr %t189, i32 %t190)
  store { i64, ptr } %t193, ptr %l198
  br label %bb50
bb49:
  br label %bb53
bb50:
  %t194 = load ptr, ptr %l2, !tbaa !29
  %t195 = load i32, ptr %l12, !tbaa !23
  %t198 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAlign(ptr %v0, ptr %t194, i32 %t195)
  store i64 %t198, ptr %l201
  br label %bb51
bb51:
  %t199 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d144, i32 0, i32 1) }, 1
  %t200 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d144, i32 0, i32 1) }, 0
  %t201 = load { i64, ptr }, ptr %l198, !tbaa !27
  %t202 = extractvalue { i64, ptr } %t201, 1
  %t203 = extractvalue { i64, ptr } %t201, 0
  %t204 = add i64 %t200, %t203
  %t205 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d145, i32 0, i32 1) }, 1
  %t206 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d145, i32 0, i32 1) }, 0
  %t207 = add i64 %t204, %t206
  %t208 = load i64, ptr %l201, !tbaa !24
  %t209 = call i64 @__olang_fmt_i64(ptr null, i64 %t208)
  %t210 = add i64 %t207, %t209
  %t211 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d146, i32 0, i32 1) }, 1
  %t212 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d146, i32 0, i32 1) }, 0
  %t213 = add i64 %t210, %t212
  %t214 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t213)
  call void @olang_textcopy(ptr %t214, ptr %t199, i64 %t200)
  %t215 = getelementptr i8, ptr %t214, i64 %t200
  call void @olang_textcopy(ptr %t215, ptr %t202, i64 %t203)
  %t216 = getelementptr i8, ptr %t215, i64 %t203
  call void @olang_textcopy(ptr %t216, ptr %t205, i64 %t206)
  %t217 = getelementptr i8, ptr %t216, i64 %t206
  %t218 = call i64 @__olang_fmt_i64(ptr %t217, i64 %t208)
  %t219 = getelementptr i8, ptr %t217, i64 %t209
  call void @olang_textcopy(ptr %t219, ptr %t211, i64 %t212)
  %t220 = insertvalue { i64, ptr } undef, i64 %t213, 0
  %t221 = insertvalue { i64, ptr } %t220, ptr %t214, 1
  %t223 = extractvalue { i64, ptr } %t221, 0
  %t224 = extractvalue { i64, ptr } %t221, 1
  %t225 = mul i64 %t223, 1
  %t226 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t225)
  call void @llvm.memcpy.p0.p0.i64(ptr %t226, ptr %t224, i64 %t225, i1 false)
  %t227 = insertvalue { i64, ptr } undef, i64 %t223, 0
  %t228 = insertvalue { i64, ptr } %t227, ptr %t226, 1
  %t229 = load ptr, ptr %l195, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %t229, { i64, ptr } %t228)
  br label %bb52
bb52:
  %t231 = getelementptr %"compiler/cabi:Regs", ptr %l18, i32 0, i32 0
  %t232 = load i64, ptr %t231, !tbaa !24
  %t234 = sub i64 %t232, 1
  %t236 = getelementptr %"compiler/cabi:Regs", ptr %l18, i32 0, i32 0
  store i64 %t234, ptr %t236, !tbaa !24
  call void @__olang_scope_close(ptr %s6)
  br label %bb53
bb53:
  %t237 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %s0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t237, ptr %l206
  br label %bb54
bb54:
  %t238 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l206
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t238, ptr %l19
  %t239 = load ptr, ptr %l2, !tbaa !29
  store ptr %t239, ptr %l207, !tbaa !29
  %t240 = load ptr, ptr %l2, !tbaa !29
  %t241 = load i32, ptr %l9, !tbaa !23
  %t244 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t240, i32 %t241)
  store i32 %t244, ptr %l210
  br label %bb55
bb55:
  %t245 = load ptr, ptr %l207, !tbaa !29
  %t246 = load i32, ptr %l210, !tbaa !23
  %t247 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t245, i32 %t246)
  store { i64, ptr } %t247, ptr %l211
  br label %bb56
bb56:
  %t248 = load { i64, ptr }, ptr %l211, !tbaa !27
  store { i64, ptr } %t248, ptr %l20, !tbaa !27
  %t249 = load ptr, ptr %l2, !tbaa !29
  %t250 = load i32, ptr %l9, !tbaa !23
  %t253 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePassing(ptr %v0, ptr %s0, ptr %t249, i32 %t250)
  store { i64, ptr } %t253, ptr %l214
  br label %bb57
bb57:
  %t254 = load { i64, ptr }, ptr %l214, !tbaa !27
  store { i64, ptr } %t254, ptr %l21, !tbaa !27
  store i64 0, ptr %l22, !tbaa !24
  %t255 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t257 = extractvalue { i64, ptr } %t255, 0
  store i64 %t257, ptr %l23, !tbaa !24
  store i64 1, ptr %l24, !tbaa !24
  %t259 = load i64, ptr %l23, !tbaa !24
  %t260 = load i64, ptr %l22, !tbaa !24
  %t263 = icmp sgt i64 %t259, %t260
  br i1 %t263, label %bb58, label %bb59
bb58:
  %t265 = load i64, ptr %l24, !tbaa !24
  %t267 = icmp sgt i64 %t265, 0
  br i1 %t267, label %bb60, label %bb61
bb59:
  store i64 0, ptr %l220, !tbaa !24
  br label %bb63
bb60:
  %t269 = load i64, ptr %l23, !tbaa !24
  %t270 = load i64, ptr %l22, !tbaa !24
  %t273 = sub i64 %t269, %t270
  %t274 = load i64, ptr %l24, !tbaa !24
  %t277 = add i64 %t273, %t274
  %t279 = sub i64 %t277, 1
  %t280 = load i64, ptr %l24, !tbaa !24
  %t283 = sdiv i64 %t279, %t280
  store i64 %t283, ptr %l223, !tbaa !24
  br label %bb62
bb61:
  store i64 0, ptr %l223, !tbaa !24
  br label %bb62
bb62:
  %t285 = load i64, ptr %l223, !tbaa !24
  store i64 %t285, ptr %l220, !tbaa !24
  br label %bb63
bb63:
  %t286 = load i64, ptr %l220, !tbaa !24
  store i64 %t286, ptr %l25, !tbaa !24
  store i64 0, ptr %l26, !tbaa !24
  br label %bb64
bb64:
  store %olang.scope zeroinitializer, ptr %s9
  %t287 = load i64, ptr %l26, !tbaa !24
  %t288 = load i64, ptr %l25, !tbaa !24
  %t291 = icmp slt i64 %t287, %t288
  %t293 = xor i1 %t291, true
  br i1 %t293, label %bb65, label %bb66
bb65:
  call void @__olang_scope_close(ptr %s9)
  br label %bb163
bb66:
  br label %bb67
bb67:
  %t295 = load i64, ptr %l22, !tbaa !24
  %t296 = load i64, ptr %l26, !tbaa !24
  %t297 = load i64, ptr %l24, !tbaa !24
  %t300 = mul i64 %t296, %t297
  %t303 = add i64 %t295, %t300
  store i64 %t303, ptr %l27, !tbaa !24
  %t305 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t305, ptr %l241, !tbaa !27
  %t306 = load i64, ptr %l27, !tbaa !24
  %t308 = getelementptr { i64, ptr }, ptr %l241, i32 0, i32 1
  %t309 = load ptr, ptr %t308, !tbaa !27
  %t310 = getelementptr i32, ptr %t309, i64 %t306
  %t311 = load i32, ptr %t310, !tbaa !33
  store i32 %t311, ptr %l28, !tbaa !23
  %t313 = load ptr, ptr %l3, !tbaa !29
  %t314 = load i32, ptr %l28, !tbaa !23
  %t317 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLayout(ptr %v0, ptr %t313, i32 %t314)
  store i1 %t317, ptr %l246
  br label %bb68
bb68:
  %t318 = load ptr, ptr %l2, !tbaa !29
  %t319 = load i32, ptr %l28, !tbaa !23
  %t322 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t318, i32 %t319)
  store i32 %t322, ptr %l249
  br label %bb69
bb69:
  %t323 = load i32, ptr %l249, !tbaa !23
  store i32 %t323, ptr %l29, !tbaa !23
  %t324 = load i64, ptr %l27, !tbaa !24
  %t325 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d147, i32 0, i32 1) }, 1
  %t326 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d147, i32 0, i32 1) }, 0
  %t328 = call i64 @__olang_fmt_i64(ptr null, i64 %t324)
  %t329 = add i64 %t326, %t328
  %t330 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t329)
  call void @olang_textcopy(ptr %t330, ptr %t325, i64 %t326)
  %t331 = getelementptr i8, ptr %t330, i64 %t326
  %t332 = call i64 @__olang_fmt_i64(ptr %t331, i64 %t324)
  %t333 = insertvalue { i64, ptr } undef, i64 %t329, 0
  %t334 = insertvalue { i64, ptr } %t333, ptr %t330, 1
  store { i64, ptr } %t334, ptr %l30, !tbaa !27
  %t336 = load ptr, ptr %l2, !tbaa !29
  %t337 = load i32, ptr %l29, !tbaa !23
  %t340 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t336, i32 %t337)
  store i1 %t340, ptr %l254
  br label %bb70
bb70:
  %t341 = load i1, ptr %l254, !tbaa !21
  br i1 %t341, label %bb71, label %bb72
bb71:
  %t342 = load ptr, ptr %l2, !tbaa !29
  store ptr %t342, ptr %l255, !tbaa !29
  %t343 = load ptr, ptr %l2, !tbaa !29
  %t344 = load i32, ptr %l29, !tbaa !23
  %t347 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t343, i32 %t344)
  store i32 %t347, ptr %l258
  br label %bb73
bb72:
  br label %bb90
bb73:
  %t348 = load ptr, ptr %l255, !tbaa !29
  %t349 = load i32, ptr %l258, !tbaa !23
  %t350 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t348, i32 %t349)
  store i32 %t350, ptr %l259
  br label %bb74
bb74:
  %t351 = load i32, ptr %l259, !tbaa !23
  store i32 %t351, ptr %l31, !tbaa !23
  %t352 = load ptr, ptr %l2, !tbaa !29
  %t353 = load i32, ptr %l31, !tbaa !23
  %t356 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t352, i32 %t353)
  store i32 %t356, ptr %l262
  br label %bb75
bb75:
  %t357 = load i32, ptr %l262
  %t359 = trunc i64 19 to i32
  %t360 = icmp eq i32 %t357, %t359
  br i1 %t360, label %bb76, label %bb77
bb76:
  %t362 = load ptr, ptr %l2, !tbaa !29
  %t363 = load i32, ptr %l31, !tbaa !23
  %t366 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t362, i32 %t363)
  store i32 %t366, ptr %l268
  br label %bb78
bb77:
  store i1 false, ptr %l265, !tbaa !21
  br label %bb79
bb78:
  %t367 = load i32, ptr %l268, !tbaa !23
  %t368 = icmp eq i32 %t367, 0
  store i1 %t368, ptr %l265, !tbaa !21
  br label %bb79
bb79:
  %t370 = load i1, ptr %l265, !tbaa !21
  br i1 %t370, label %bb80, label %bb81
bb80:
  store %olang.scope zeroinitializer, ptr %s12
  %t371 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t372 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d148, i32 0, i32 1) }, 1
  %t373 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d148, i32 0, i32 1) }, 0
  %t375 = extractvalue { i64, ptr } %t371, 1
  %t376 = extractvalue { i64, ptr } %t371, 0
  %t377 = add i64 %t373, %t376
  %t378 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t377)
  call void @olang_textcopy(ptr %t378, ptr %t372, i64 %t373)
  %t379 = getelementptr i8, ptr %t378, i64 %t373
  call void @olang_textcopy(ptr %t379, ptr %t375, i64 %t376)
  %t380 = insertvalue { i64, ptr } undef, i64 %t377, 0
  %t381 = insertvalue { i64, ptr } %t380, ptr %t378, 1
  %t383 = extractvalue { i64, ptr } %t381, 0
  %t384 = extractvalue { i64, ptr } %t381, 1
  %t385 = mul i64 %t383, 1
  %t386 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t385)
  call void @llvm.memcpy.p0.p0.i64(ptr %t386, ptr %t384, i64 %t385, i1 false)
  %t387 = insertvalue { i64, ptr } undef, i64 %t383, 0
  %t388 = insertvalue { i64, ptr } %t387, ptr %t386, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %l17, { i64, ptr } %t388)
  br label %bb82
bb81:
  %t391 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t392 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d149, i32 0, i32 1) }, 1
  %t393 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d149, i32 0, i32 1) }, 0
  %t395 = extractvalue { i64, ptr } %t391, 1
  %t396 = extractvalue { i64, ptr } %t391, 0
  %t397 = add i64 %t393, %t396
  %t398 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t397)
  call void @olang_textcopy(ptr %t398, ptr %t392, i64 %t393)
  %t399 = getelementptr i8, ptr %t398, i64 %t393
  call void @olang_textcopy(ptr %t399, ptr %t395, i64 %t396)
  %t400 = insertvalue { i64, ptr } undef, i64 %t397, 0
  %t401 = insertvalue { i64, ptr } %t400, ptr %t398, 1
  %t403 = extractvalue { i64, ptr } %t401, 0
  %t404 = extractvalue { i64, ptr } %t401, 1
  %t405 = mul i64 %t403, 1
  %t406 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t405)
  call void @llvm.memcpy.p0.p0.i64(ptr %t406, ptr %t404, i64 %t405, i1 false)
  %t407 = insertvalue { i64, ptr } undef, i64 %t403, 0
  %t408 = insertvalue { i64, ptr } %t407, ptr %t406, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %l17, { i64, ptr } %t408)
  br label %bb87
bb82:
  %t411 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t412 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d150, i32 0, i32 1) }, 1
  %t413 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d150, i32 0, i32 1) }, 0
  %t415 = extractvalue { i64, ptr } %t411, 1
  %t416 = extractvalue { i64, ptr } %t411, 0
  %t417 = add i64 %t413, %t416
  %t418 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d151, i32 0, i32 1) }, 1
  %t419 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d151, i32 0, i32 1) }, 0
  %t420 = add i64 %t417, %t419
  %t421 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t420)
  call void @olang_textcopy(ptr %t421, ptr %t412, i64 %t413)
  %t422 = getelementptr i8, ptr %t421, i64 %t413
  call void @olang_textcopy(ptr %t422, ptr %t415, i64 %t416)
  %t423 = getelementptr i8, ptr %t422, i64 %t416
  call void @olang_textcopy(ptr %t423, ptr %t418, i64 %t419)
  %t424 = insertvalue { i64, ptr } undef, i64 %t420, 0
  %t425 = insertvalue { i64, ptr } %t424, ptr %t421, 1
  %t427 = extractvalue { i64, ptr } %t425, 0
  %t428 = extractvalue { i64, ptr } %t425, 1
  %t429 = mul i64 %t427, 1
  %t430 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t429)
  call void @llvm.memcpy.p0.p0.i64(ptr %t430, ptr %t428, i64 %t429, i1 false)
  %t431 = insertvalue { i64, ptr } undef, i64 %t427, 0
  %t432 = insertvalue { i64, ptr } %t431, ptr %t430, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %l17, { i64, ptr } %t432)
  br label %bb83
bb83:
  %t435 = getelementptr %"compiler/cabi:Regs", ptr %l18, i32 0, i32 0
  %t436 = load i64, ptr %t435, !tbaa !24
  %t438 = sub i64 %t436, 2
  %t440 = getelementptr %"compiler/cabi:Regs", ptr %l18, i32 0, i32 0
  store i64 %t438, ptr %t440, !tbaa !24
  %t441 = load ptr, ptr %l11, !tbaa !29
  %t442 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t443 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d152, i32 0, i32 1) }, 1
  %t444 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d152, i32 0, i32 1) }, 0
  %t446 = extractvalue { i64, ptr } %t442, 1
  %t447 = extractvalue { i64, ptr } %t442, 0
  %t448 = add i64 %t444, %t447
  %t449 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d153, i32 0, i32 1) }, 1
  %t450 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d153, i32 0, i32 1) }, 0
  %t451 = add i64 %t448, %t450
  %t452 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t451)
  call void @olang_textcopy(ptr %t452, ptr %t443, i64 %t444)
  %t453 = getelementptr i8, ptr %t452, i64 %t444
  call void @olang_textcopy(ptr %t453, ptr %t446, i64 %t447)
  %t454 = getelementptr i8, ptr %t453, i64 %t447
  call void @olang_textcopy(ptr %t454, ptr %t449, i64 %t450)
  %t455 = insertvalue { i64, ptr } undef, i64 %t451, 0
  %t456 = insertvalue { i64, ptr } %t455, ptr %t452, 1
  %t458 = extractvalue { i64, ptr } %t456, 0
  %t459 = extractvalue { i64, ptr } %t456, 1
  %t460 = mul i64 %t458, 1
  %t461 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t460)
  call void @llvm.memcpy.p0.p0.i64(ptr %t461, ptr %t459, i64 %t460, i1 false)
  %t462 = insertvalue { i64, ptr } undef, i64 %t458, 0
  %t463 = insertvalue { i64, ptr } %t462, ptr %t461, 1
  %t466 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s12, ptr %s12, ptr %t441, { i64, ptr } %t463)
  store { i64, ptr } %t466, ptr %l284
  br label %bb84
bb84:
  %t467 = load { i64, ptr }, ptr %l284, !tbaa !27
  store ptr %l19, ptr %l285, !tbaa !29
  %t468 = load ptr, ptr %l11, !tbaa !29
  %t470 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t471 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d154, i32 0, i32 1) }, 1
  %t472 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d154, i32 0, i32 1) }, 0
  %t474 = extractvalue { i64, ptr } %t467, 1
  %t475 = extractvalue { i64, ptr } %t467, 0
  %t476 = add i64 %t472, %t475
  %t477 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d155, i32 0, i32 1) }, 1
  %t478 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d155, i32 0, i32 1) }, 0
  %t479 = add i64 %t476, %t478
  %t481 = extractvalue { i64, ptr } %t470, 1
  %t482 = extractvalue { i64, ptr } %t470, 0
  %t483 = add i64 %t479, %t482
  %t484 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d156, i32 0, i32 1) }, 1
  %t485 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d156, i32 0, i32 1) }, 0
  %t486 = add i64 %t483, %t485
  %t487 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t486)
  call void @olang_textcopy(ptr %t487, ptr %t471, i64 %t472)
  %t488 = getelementptr i8, ptr %t487, i64 %t472
  call void @olang_textcopy(ptr %t488, ptr %t474, i64 %t475)
  %t489 = getelementptr i8, ptr %t488, i64 %t475
  call void @olang_textcopy(ptr %t489, ptr %t477, i64 %t478)
  %t490 = getelementptr i8, ptr %t489, i64 %t478
  call void @olang_textcopy(ptr %t490, ptr %t481, i64 %t482)
  %t491 = getelementptr i8, ptr %t490, i64 %t482
  call void @olang_textcopy(ptr %t491, ptr %t484, i64 %t485)
  %t492 = insertvalue { i64, ptr } undef, i64 %t486, 0
  %t493 = insertvalue { i64, ptr } %t492, ptr %t487, 1
  %t495 = extractvalue { i64, ptr } %t493, 0
  %t496 = extractvalue { i64, ptr } %t493, 1
  %t497 = mul i64 %t495, 1
  %t498 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t497)
  call void @llvm.memcpy.p0.p0.i64(ptr %t498, ptr %t496, i64 %t497, i1 false)
  %t499 = insertvalue { i64, ptr } undef, i64 %t495, 0
  %t500 = insertvalue { i64, ptr } %t499, ptr %t498, 1
  %t503 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s12, ptr %s12, ptr %t468, { i64, ptr } %t500)
  store { i64, ptr } %t503, ptr %l291
  br label %bb85
bb85:
  %t504 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d157, i32 0, i32 1) }, 1
  %t505 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d157, i32 0, i32 1) }, 0
  %t506 = load { i64, ptr }, ptr %l291, !tbaa !27
  %t507 = extractvalue { i64, ptr } %t506, 1
  %t508 = extractvalue { i64, ptr } %t506, 0
  %t509 = add i64 %t505, %t508
  %t510 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t509)
  call void @olang_textcopy(ptr %t510, ptr %t504, i64 %t505)
  %t511 = getelementptr i8, ptr %t510, i64 %t505
  call void @olang_textcopy(ptr %t511, ptr %t507, i64 %t508)
  %t512 = insertvalue { i64, ptr } undef, i64 %t509, 0
  %t513 = insertvalue { i64, ptr } %t512, ptr %t510, 1
  %t515 = extractvalue { i64, ptr } %t513, 0
  %t516 = extractvalue { i64, ptr } %t513, 1
  %t517 = mul i64 %t515, 1
  %t518 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t517)
  call void @llvm.memcpy.p0.p0.i64(ptr %t518, ptr %t516, i64 %t517, i1 false)
  %t519 = insertvalue { i64, ptr } undef, i64 %t515, 0
  %t520 = insertvalue { i64, ptr } %t519, ptr %t518, 1
  %t521 = load ptr, ptr %l285, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %t521, { i64, ptr } %t520)
  br label %bb86
bb86:
  call void @__olang_scope_close(ptr %s12)
  br label %bb89
bb87:
  %t523 = getelementptr %"compiler/cabi:Regs", ptr %l18, i32 0, i32 0
  %t524 = load i64, ptr %t523, !tbaa !24
  %t526 = sub i64 %t524, 1
  %t528 = getelementptr %"compiler/cabi:Regs", ptr %l18, i32 0, i32 0
  store i64 %t526, ptr %t528, !tbaa !24
  %t529 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t530 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d158, i32 0, i32 1) }, 1
  %t531 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d158, i32 0, i32 1) }, 0
  %t533 = extractvalue { i64, ptr } %t529, 1
  %t534 = extractvalue { i64, ptr } %t529, 0
  %t535 = add i64 %t531, %t534
  %t536 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t535)
  call void @olang_textcopy(ptr %t536, ptr %t530, i64 %t531)
  %t537 = getelementptr i8, ptr %t536, i64 %t531
  call void @olang_textcopy(ptr %t537, ptr %t533, i64 %t534)
  %t538 = insertvalue { i64, ptr } undef, i64 %t535, 0
  %t539 = insertvalue { i64, ptr } %t538, ptr %t536, 1
  %t541 = extractvalue { i64, ptr } %t539, 0
  %t542 = extractvalue { i64, ptr } %t539, 1
  %t543 = mul i64 %t541, 1
  %t544 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t543)
  call void @llvm.memcpy.p0.p0.i64(ptr %t544, ptr %t542, i64 %t543, i1 false)
  %t545 = insertvalue { i64, ptr } undef, i64 %t541, 0
  %t546 = insertvalue { i64, ptr } %t545, ptr %t544, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %l19, { i64, ptr } %t546)
  br label %bb88
bb88:
  br label %bb89
bb89:
  call void @__olang_scope_close(ptr %s9)
  br label %bb162
bb90:
  %t549 = load ptr, ptr %l2, !tbaa !29
  %t550 = load ptr, ptr %l0, !tbaa !29
  %t552 = getelementptr %"compiler/emit:Emitter", ptr %t550, i32 0, i32 45
  %t553 = load { i64, ptr }, ptr %t552, !tbaa !27
  %t554 = load i32, ptr %l28, !tbaa !23
  %t559 = call %"compiler/cabi:Way" @compiler_2fcabi_2eParam(ptr %v0, ptr %v0, ptr %s0, ptr %s9, ptr %t549, { i64, ptr } %t553, i32 %t554, ptr %l18)
  store %"compiler/cabi:Way" %t559, ptr %l309
  br label %bb91
bb91:
  %t560 = load %"compiler/cabi:Way", ptr %l309
  store %"compiler/cabi:Way" %t560, ptr %l33
  %t561 = getelementptr %"compiler/cabi:Way", ptr %l33, i32 0, i32 0
  %t562 = load i32, ptr %t561
  store i32 %t562, ptr %l34
  %t564 = load i32, ptr %l34
  %t566 = trunc i64 0 to i32
  %t567 = icmp eq i32 %t564, %t566
  br i1 %t567, label %bb92, label %bb93
bb92:
  br label %bb94
bb93:
  br label %bb103
bb94:
  store %olang.scope zeroinitializer, ptr %s21
  store ptr %l17, ptr %l313, !tbaa !29
  %t569 = load ptr, ptr %l0, !tbaa !29
  %t570 = load i32, ptr %l28, !tbaa !23
  %t573 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %s21, ptr %t569, i32 %t570)
  store { i64, ptr } %t573, ptr %l316
  br label %bb95
bb95:
  %t574 = getelementptr %"compiler/cabi:Way", ptr %l33, i32 0, i32 4
  %t575 = load { i64, ptr }, ptr %t574, !tbaa !27
  %t577 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s9, ptr %s21, { i64, ptr } %t575, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d159, i32 0, i32 1) })
  store i1 %t577, ptr %l318
  br label %bb96
bb96:
  %t578 = load i1, ptr %l318, !tbaa !21
  %t579 = xor i1 %t578, true
  br i1 %t579, label %bb97, label %bb98
bb97:
  %t581 = getelementptr %"compiler/cabi:Way", ptr %l33, i32 0, i32 4
  %t582 = load { i64, ptr }, ptr %t581, !tbaa !27
  %t583 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d160, i32 0, i32 1) }, 1
  %t584 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d160, i32 0, i32 1) }, 0
  %t586 = extractvalue { i64, ptr } %t582, 1
  %t587 = extractvalue { i64, ptr } %t582, 0
  %t588 = add i64 %t584, %t587
  %t589 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t588)
  call void @olang_textcopy(ptr %t589, ptr %t583, i64 %t584)
  %t590 = getelementptr i8, ptr %t589, i64 %t584
  call void @olang_textcopy(ptr %t590, ptr %t586, i64 %t587)
  %t591 = insertvalue { i64, ptr } undef, i64 %t588, 0
  %t592 = insertvalue { i64, ptr } %t591, ptr %t589, 1
  %t594 = extractvalue { i64, ptr } %t592, 0
  %t595 = extractvalue { i64, ptr } %t592, 1
  %t596 = mul i64 %t594, 1
  %t597 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t596)
  call void @llvm.memcpy.p0.p0.i64(ptr %t597, ptr %t595, i64 %t596, i1 false)
  %t598 = insertvalue { i64, ptr } undef, i64 %t594, 0
  %t599 = insertvalue { i64, ptr } %t598, ptr %t597, 1
  store { i64, ptr } %t599, ptr %l320, !tbaa !27
  br label %bb99
bb98:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d161, i32 0, i32 1) }, ptr %l320, !tbaa !27
  br label %bb99
bb99:
  %t601 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t602 = load { i64, ptr }, ptr %l316, !tbaa !27
  %t603 = extractvalue { i64, ptr } %t602, 1
  %t604 = extractvalue { i64, ptr } %t602, 0
  %t605 = load { i64, ptr }, ptr %l320, !tbaa !27
  %t606 = extractvalue { i64, ptr } %t605, 1
  %t607 = extractvalue { i64, ptr } %t605, 0
  %t608 = add i64 %t604, %t607
  %t609 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d162, i32 0, i32 1) }, 1
  %t610 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d162, i32 0, i32 1) }, 0
  %t611 = add i64 %t608, %t610
  %t613 = extractvalue { i64, ptr } %t601, 1
  %t614 = extractvalue { i64, ptr } %t601, 0
  %t615 = add i64 %t611, %t614
  %t616 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t615)
  call void @olang_textcopy(ptr %t616, ptr %t603, i64 %t604)
  %t617 = getelementptr i8, ptr %t616, i64 %t604
  call void @olang_textcopy(ptr %t617, ptr %t606, i64 %t607)
  %t618 = getelementptr i8, ptr %t617, i64 %t607
  call void @olang_textcopy(ptr %t618, ptr %t609, i64 %t610)
  %t619 = getelementptr i8, ptr %t618, i64 %t610
  call void @olang_textcopy(ptr %t619, ptr %t613, i64 %t614)
  %t620 = insertvalue { i64, ptr } undef, i64 %t615, 0
  %t621 = insertvalue { i64, ptr } %t620, ptr %t616, 1
  %t623 = extractvalue { i64, ptr } %t621, 0
  %t624 = extractvalue { i64, ptr } %t621, 1
  %t625 = mul i64 %t623, 1
  %t626 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t625)
  call void @llvm.memcpy.p0.p0.i64(ptr %t626, ptr %t624, i64 %t625, i1 false)
  %t627 = insertvalue { i64, ptr } undef, i64 %t623, 0
  %t628 = insertvalue { i64, ptr } %t627, ptr %t626, 1
  %t629 = load ptr, ptr %l313, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %t629, { i64, ptr } %t628)
  br label %bb100
bb100:
  store ptr %l19, ptr %l327, !tbaa !29
  %t631 = load ptr, ptr %l0, !tbaa !29
  %t632 = load i32, ptr %l28, !tbaa !23
  %t635 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %s21, ptr %t631, i32 %t632)
  store { i64, ptr } %t635, ptr %l330
  br label %bb101
bb101:
  %t636 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t637 = load { i64, ptr }, ptr %l330, !tbaa !27
  %t638 = extractvalue { i64, ptr } %t637, 1
  %t639 = extractvalue { i64, ptr } %t637, 0
  %t640 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d163, i32 0, i32 1) }, 1
  %t641 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d163, i32 0, i32 1) }, 0
  %t642 = add i64 %t639, %t641
  %t644 = extractvalue { i64, ptr } %t636, 1
  %t645 = extractvalue { i64, ptr } %t636, 0
  %t646 = add i64 %t642, %t645
  %t647 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t646)
  call void @olang_textcopy(ptr %t647, ptr %t638, i64 %t639)
  %t648 = getelementptr i8, ptr %t647, i64 %t639
  call void @olang_textcopy(ptr %t648, ptr %t640, i64 %t641)
  %t649 = getelementptr i8, ptr %t648, i64 %t641
  call void @olang_textcopy(ptr %t649, ptr %t644, i64 %t645)
  %t650 = insertvalue { i64, ptr } undef, i64 %t646, 0
  %t651 = insertvalue { i64, ptr } %t650, ptr %t647, 1
  %t653 = extractvalue { i64, ptr } %t651, 0
  %t654 = extractvalue { i64, ptr } %t651, 1
  %t655 = mul i64 %t653, 1
  %t656 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t655)
  call void @llvm.memcpy.p0.p0.i64(ptr %t656, ptr %t654, i64 %t655, i1 false)
  %t657 = insertvalue { i64, ptr } undef, i64 %t653, 0
  %t658 = insertvalue { i64, ptr } %t657, ptr %t656, 1
  %t659 = load ptr, ptr %l327, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %t659, { i64, ptr } %t658)
  br label %bb102
bb102:
  call void @__olang_scope_close(ptr %s21)
  call void @__olang_scope_close(ptr %s9)
  br label %bb162
bb103:
  %t661 = load i32, ptr %l34
  %t663 = trunc i64 1 to i32
  %t664 = icmp eq i32 %t661, %t663
  br i1 %t664, label %bb104, label %bb105
bb104:
  br label %bb106
bb105:
  br label %bb136
bb106:
  store %olang.scope zeroinitializer, ptr %s25
  %t666 = load ptr, ptr %l11, !tbaa !29
  store ptr %t666, ptr %l336, !tbaa !29
  %t667 = load ptr, ptr %l2, !tbaa !29
  %t668 = load i32, ptr %l28, !tbaa !23
  %t672 = call i64 @compiler_2fcabi_2eSpan(ptr %v0, ptr %s9, ptr %t667, ptr %l33, i32 %t668)
  store i64 %t672, ptr %l340
  br label %bb107
bb107:
  %t673 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d164, i32 0, i32 1) }, 1
  %t674 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d164, i32 0, i32 1) }, 0
  %t675 = load i64, ptr %l340, !tbaa !24
  %t676 = call i64 @__olang_fmt_i64(ptr null, i64 %t675)
  %t677 = add i64 %t674, %t676
  %t678 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d165, i32 0, i32 1) }, 1
  %t679 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d165, i32 0, i32 1) }, 0
  %t680 = add i64 %t677, %t679
  %t681 = call ptr @__olang_scope_alloc(ptr %s25, i64 %t680)
  call void @olang_textcopy(ptr %t681, ptr %t673, i64 %t674)
  %t682 = getelementptr i8, ptr %t681, i64 %t674
  %t683 = call i64 @__olang_fmt_i64(ptr %t682, i64 %t675)
  %t684 = getelementptr i8, ptr %t682, i64 %t676
  call void @olang_textcopy(ptr %t684, ptr %t678, i64 %t679)
  %t685 = insertvalue { i64, ptr } undef, i64 %t680, 0
  %t686 = insertvalue { i64, ptr } %t685, ptr %t681, 1
  %t688 = extractvalue { i64, ptr } %t686, 0
  %t689 = extractvalue { i64, ptr } %t686, 1
  %t690 = mul i64 %t688, 1
  %t691 = call ptr @__olang_scope_alloc(ptr %s25, i64 %t690)
  call void @llvm.memcpy.p0.p0.i64(ptr %t691, ptr %t689, i64 %t690, i1 false)
  %t692 = insertvalue { i64, ptr } undef, i64 %t688, 0
  %t693 = insertvalue { i64, ptr } %t692, ptr %t691, 1
  %t694 = load ptr, ptr %l336, !tbaa !29
  %t696 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ealloca(ptr %v0, ptr %s25, ptr %s25, ptr %t694, { i64, ptr } %t693, i64 8)
  store { i64, ptr } %t696, ptr %l343
  br label %bb108
bb108:
  %t697 = load { i64, ptr }, ptr %l343, !tbaa !27
  store { i64, ptr } %t697, ptr %l35, !tbaa !27
  store i64 0, ptr %l36, !tbaa !24
  %t698 = getelementptr %"compiler/cabi:Way", ptr %l33, i32 0, i32 1
  %t700 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %s9, ptr %t698)
  store i64 %t700, ptr %l345
  br label %bb109
bb109:
  %t701 = load i64, ptr %l345, !tbaa !24
  store i64 %t701, ptr %l37, !tbaa !24
  store i64 1, ptr %l38, !tbaa !24
  %t702 = load i64, ptr %l37, !tbaa !24
  %t703 = load i64, ptr %l36, !tbaa !24
  %t706 = icmp sgt i64 %t702, %t703
  br i1 %t706, label %bb110, label %bb111
bb110:
  %t708 = load i64, ptr %l38, !tbaa !24
  %t710 = icmp sgt i64 %t708, 0
  br i1 %t710, label %bb112, label %bb113
bb111:
  store i64 0, ptr %l349, !tbaa !24
  br label %bb115
bb112:
  %t712 = load i64, ptr %l37, !tbaa !24
  %t713 = load i64, ptr %l36, !tbaa !24
  %t716 = sub i64 %t712, %t713
  %t717 = load i64, ptr %l38, !tbaa !24
  %t720 = add i64 %t716, %t717
  %t722 = sub i64 %t720, 1
  %t723 = load i64, ptr %l38, !tbaa !24
  %t726 = sdiv i64 %t722, %t723
  store i64 %t726, ptr %l352, !tbaa !24
  br label %bb114
bb113:
  store i64 0, ptr %l352, !tbaa !24
  br label %bb114
bb114:
  %t728 = load i64, ptr %l352, !tbaa !24
  store i64 %t728, ptr %l349, !tbaa !24
  br label %bb115
bb115:
  %t729 = load i64, ptr %l349, !tbaa !24
  store i64 %t729, ptr %l39, !tbaa !24
  store i64 0, ptr %l40, !tbaa !24
  br label %bb116
bb116:
  store %olang.scope zeroinitializer, ptr %s28
  %t730 = load i64, ptr %l40, !tbaa !24
  %t731 = load i64, ptr %l39, !tbaa !24
  %t734 = icmp slt i64 %t730, %t731
  %t736 = xor i1 %t734, true
  br i1 %t736, label %bb117, label %bb118
bb117:
  call void @__olang_scope_close(ptr %s28)
  br label %bb132
bb118:
  br label %bb119
bb119:
  %t738 = load i64, ptr %l36, !tbaa !24
  %t739 = load i64, ptr %l40, !tbaa !24
  %t740 = load i64, ptr %l38, !tbaa !24
  %t743 = mul i64 %t739, %t740
  %t746 = add i64 %t738, %t743
  store i64 %t746, ptr %l41, !tbaa !24
  store ptr %l17, ptr %l370, !tbaa !29
  %t748 = getelementptr %"compiler/cabi:Way", ptr %l33, i32 0, i32 1
  %t749 = load i64, ptr %l41, !tbaa !24
  %t752 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %s9, ptr %s28, ptr %t748, i64 %t749)
  store { i64, ptr } %t752, ptr %l373
  br label %bb120
bb120:
  %t753 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t754 = load i64, ptr %l41, !tbaa !24
  %t755 = load { i64, ptr }, ptr %l373, !tbaa !27
  %t756 = extractvalue { i64, ptr } %t755, 1
  %t757 = extractvalue { i64, ptr } %t755, 0
  %t758 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d166, i32 0, i32 1) }, 1
  %t759 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d166, i32 0, i32 1) }, 0
  %t760 = add i64 %t757, %t759
  %t762 = extractvalue { i64, ptr } %t753, 1
  %t763 = extractvalue { i64, ptr } %t753, 0
  %t764 = add i64 %t760, %t763
  %t765 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d167, i32 0, i32 1) }, 1
  %t766 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d167, i32 0, i32 1) }, 0
  %t767 = add i64 %t764, %t766
  %t769 = call i64 @__olang_fmt_i64(ptr null, i64 %t754)
  %t770 = add i64 %t767, %t769
  %t771 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t770)
  call void @olang_textcopy(ptr %t771, ptr %t756, i64 %t757)
  %t772 = getelementptr i8, ptr %t771, i64 %t757
  call void @olang_textcopy(ptr %t772, ptr %t758, i64 %t759)
  %t773 = getelementptr i8, ptr %t772, i64 %t759
  call void @olang_textcopy(ptr %t773, ptr %t762, i64 %t763)
  %t774 = getelementptr i8, ptr %t773, i64 %t763
  call void @olang_textcopy(ptr %t774, ptr %t765, i64 %t766)
  %t775 = getelementptr i8, ptr %t774, i64 %t766
  %t776 = call i64 @__olang_fmt_i64(ptr %t775, i64 %t754)
  %t777 = insertvalue { i64, ptr } undef, i64 %t770, 0
  %t778 = insertvalue { i64, ptr } %t777, ptr %t771, 1
  %t780 = extractvalue { i64, ptr } %t778, 0
  %t781 = extractvalue { i64, ptr } %t778, 1
  %t782 = mul i64 %t780, 1
  %t783 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t782)
  call void @llvm.memcpy.p0.p0.i64(ptr %t783, ptr %t781, i64 %t782, i1 false)
  %t784 = insertvalue { i64, ptr } undef, i64 %t780, 0
  %t785 = insertvalue { i64, ptr } %t784, ptr %t783, 1
  %t786 = load ptr, ptr %l370, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %t786, { i64, ptr } %t785)
  br label %bb121
bb121:
  %t788 = getelementptr %"compiler/cabi:Way", ptr %l33, i32 0, i32 2
  %t789 = load i64, ptr %l41, !tbaa !24
  %t792 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %s9, ptr %t788, i64 %t789)
  store i64 %t792, ptr %l380
  br label %bb122
bb122:
  %t793 = load i64, ptr %l380, !tbaa !24
  %t794 = icmp eq i64 %t793, 0
  br i1 %t794, label %bb123, label %bb124
bb123:
  %t796 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t796, ptr %l382, !tbaa !27
  br label %bb127
bb124:
  %t798 = load ptr, ptr %l11, !tbaa !29
  store ptr %t798, ptr %l384, !tbaa !29
  %t799 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t799, ptr %l385, !tbaa !27
  %t800 = getelementptr %"compiler/cabi:Way", ptr %l33, i32 0, i32 2
  %t801 = load i64, ptr %l41, !tbaa !24
  %t804 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %s9, ptr %t800, i64 %t801)
  store i64 %t804, ptr %l388
  br label %bb125
bb125:
  %t805 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d168, i32 0, i32 1) }, 1
  %t806 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d168, i32 0, i32 1) }, 0
  %t807 = load { i64, ptr }, ptr %l385, !tbaa !27
  %t808 = extractvalue { i64, ptr } %t807, 1
  %t809 = extractvalue { i64, ptr } %t807, 0
  %t810 = add i64 %t806, %t809
  %t811 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d169, i32 0, i32 1) }, 1
  %t812 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d169, i32 0, i32 1) }, 0
  %t813 = add i64 %t810, %t812
  %t814 = load i64, ptr %l388, !tbaa !24
  %t815 = call i64 @__olang_fmt_i64(ptr null, i64 %t814)
  %t816 = add i64 %t813, %t815
  %t817 = call ptr @__olang_scope_alloc(ptr %s28, i64 %t816)
  call void @olang_textcopy(ptr %t817, ptr %t805, i64 %t806)
  %t818 = getelementptr i8, ptr %t817, i64 %t806
  call void @olang_textcopy(ptr %t818, ptr %t808, i64 %t809)
  %t819 = getelementptr i8, ptr %t818, i64 %t809
  call void @olang_textcopy(ptr %t819, ptr %t811, i64 %t812)
  %t820 = getelementptr i8, ptr %t819, i64 %t812
  %t821 = call i64 @__olang_fmt_i64(ptr %t820, i64 %t814)
  %t822 = insertvalue { i64, ptr } undef, i64 %t816, 0
  %t823 = insertvalue { i64, ptr } %t822, ptr %t817, 1
  %t825 = extractvalue { i64, ptr } %t823, 0
  %t826 = extractvalue { i64, ptr } %t823, 1
  %t827 = mul i64 %t825, 1
  %t828 = call ptr @__olang_scope_alloc(ptr %s28, i64 %t827)
  call void @llvm.memcpy.p0.p0.i64(ptr %t828, ptr %t826, i64 %t827, i1 false)
  %t829 = insertvalue { i64, ptr } undef, i64 %t825, 0
  %t830 = insertvalue { i64, ptr } %t829, ptr %t828, 1
  %t831 = load ptr, ptr %l384, !tbaa !29
  %t833 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s28, ptr %s28, ptr %t831, { i64, ptr } %t830)
  store { i64, ptr } %t833, ptr %l391
  br label %bb126
bb126:
  %t834 = load { i64, ptr }, ptr %l391, !tbaa !27
  store { i64, ptr } %t834, ptr %l382, !tbaa !27
  br label %bb127
bb127:
  %t835 = load { i64, ptr }, ptr %l382, !tbaa !27
  store { i64, ptr } %t835, ptr %l42, !tbaa !27
  %t836 = load ptr, ptr %l11, !tbaa !29
  store ptr %t836, ptr %l392, !tbaa !29
  %t837 = getelementptr %"compiler/cabi:Way", ptr %l33, i32 0, i32 1
  %t838 = load i64, ptr %l41, !tbaa !24
  %t841 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %s9, ptr %s28, ptr %t837, i64 %t838)
  store { i64, ptr } %t841, ptr %l395
  br label %bb128
bb128:
  %t842 = load { i64, ptr }, ptr %l395, !tbaa !27
  store { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d170, i32 0, i32 1) }, ptr %l397, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d171, i32 0, i32 1) }, ptr %l398, !tbaa !27
  %t844 = load { i64, ptr }, ptr %l397, !tbaa !27
  %t845 = load { i64, ptr }, ptr %l398, !tbaa !27
  %t846 = call { i64, ptr } @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eReplace_3cstd_2fprelude_2ftext_3aChar_3e(ptr %s28, ptr %s28, ptr %s28, ptr %s28, { i64, ptr } %t842, { i64, ptr } %t844, { i64, ptr } %t845)
  store { i64, ptr } %t846, ptr %l399
  br label %bb129
bb129:
  %t847 = load { i64, ptr }, ptr %l399, !tbaa !27
  %t849 = extractvalue { i64, ptr } %t847, 0
  %t850 = extractvalue { i64, ptr } %t847, 1
  %t851 = mul i64 %t849, 1
  %t852 = call ptr @__olang_scope_alloc(ptr %s28, i64 %t851)
  call void @llvm.memcpy.p0.p0.i64(ptr %t852, ptr %t850, i64 %t851, i1 false)
  %t853 = insertvalue { i64, ptr } undef, i64 %t849, 0
  %t854 = insertvalue { i64, ptr } %t853, ptr %t852, 1
  %t855 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t856 = load i64, ptr %l41, !tbaa !24
  %t858 = extractvalue { i64, ptr } %t855, 1
  %t859 = extractvalue { i64, ptr } %t855, 0
  %t860 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d172, i32 0, i32 1) }, 1
  %t861 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d172, i32 0, i32 1) }, 0
  %t862 = add i64 %t859, %t861
  %t864 = call i64 @__olang_fmt_i64(ptr null, i64 %t856)
  %t865 = add i64 %t862, %t864
  %t866 = call ptr @__olang_scope_alloc(ptr %s28, i64 %t865)
  call void @olang_textcopy(ptr %t866, ptr %t858, i64 %t859)
  %t867 = getelementptr i8, ptr %t866, i64 %t859
  call void @olang_textcopy(ptr %t867, ptr %t860, i64 %t861)
  %t868 = getelementptr i8, ptr %t867, i64 %t861
  %t869 = call i64 @__olang_fmt_i64(ptr %t868, i64 %t856)
  %t870 = insertvalue { i64, ptr } undef, i64 %t865, 0
  %t871 = insertvalue { i64, ptr } %t870, ptr %t866, 1
  %t873 = extractvalue { i64, ptr } %t871, 0
  %t874 = extractvalue { i64, ptr } %t871, 1
  %t875 = mul i64 %t873, 1
  %t876 = call ptr @__olang_scope_alloc(ptr %s28, i64 %t875)
  call void @llvm.memcpy.p0.p0.i64(ptr %t876, ptr %t874, i64 %t875, i1 false)
  %t877 = insertvalue { i64, ptr } undef, i64 %t873, 0
  %t878 = insertvalue { i64, ptr } %t877, ptr %t876, 1
  %t879 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t880 = load ptr, ptr %l392, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s28, ptr %s28, ptr %s28, ptr %s28, ptr %t880, { i64, ptr } %t854, { i64, ptr } %t878, { i64, ptr } %t879, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d173, i32 0, i32 1) })
  br label %bb130
bb130:
  call void @__olang_scope_close(ptr %s28)
  br label %bb131
bb131:
  %t884 = load i64, ptr %l40, !tbaa !24
  %t886 = add i64 %t884, 1
  store i64 %t886, ptr %l40, !tbaa !24
  br label %bb116
bb132:
  %t888 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t888, ptr %l409, !tbaa !27
  %t889 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t890 = extractvalue { i64, ptr } %t889, 0
  %t891 = load { i64, ptr }, ptr %l409, !tbaa !27
  %t892 = extractvalue { i64, ptr } %t891, 0
  store i64 %t892, ptr %l411, !tbaa !24
  %t894 = load i64, ptr %l411, !tbaa !24
  %t895 = icmp eq i64 %t890, %t894
  br i1 %t895, label %bb133, label %bb134
bb133:
  %t897 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t898 = load ptr, ptr %t897, !tbaa !27
  %t899 = getelementptr { i64, ptr }, ptr %l409, i32 0, i32 1
  %t900 = load ptr, ptr %t899, !tbaa !27
  %t901 = load i64, ptr %l411, !tbaa !24
  %t902 = mul i64 %t901, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t898, ptr %t900, i64 %t902, i1 false)
  br label %bb135
bb134:
  %t903 = load { i64, ptr }, ptr %l409, !tbaa !27
  %t904 = extractvalue { i64, ptr } %t903, 0
  store i64 %t904, ptr %l413, !tbaa !24
  %t905 = load i64, ptr %l413, !tbaa !24
  %t906 = mul i64 %t905, 1
  %t907 = call ptr @__olang_scope_alloc_zeroed(ptr %s9, i64 %t906)
  %t908 = insertvalue { i64, ptr } undef, i64 %t905, 0
  %t909 = insertvalue { i64, ptr } %t908, ptr %t907, 1
  store { i64, ptr } %t909, ptr %l414, !tbaa !27
  %t910 = getelementptr { i64, ptr }, ptr %l414, i32 0, i32 1
  %t911 = load ptr, ptr %t910, !tbaa !27
  %t912 = getelementptr { i64, ptr }, ptr %l409, i32 0, i32 1
  %t913 = load ptr, ptr %t912, !tbaa !27
  %t914 = load i64, ptr %l413, !tbaa !24
  %t915 = mul i64 %t914, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t911, ptr %t913, i64 %t915, i1 false)
  %t916 = load { i64, ptr }, ptr %l414, !tbaa !27
  store { i64, ptr } %t916, ptr %l30, !tbaa !27
  br label %bb135
bb135:
  call void @__olang_scope_close(ptr %s25)
  br label %bb150
bb136:
  %t917 = load i32, ptr %l34
  %t919 = trunc i64 2 to i32
  %t920 = icmp eq i32 %t917, %t919
  br i1 %t920, label %bb137, label %bb138
bb137:
  br label %bb139
bb138:
  br label %bb144
bb139:
  store %olang.scope zeroinitializer, ptr %s33
  store ptr %l17, ptr %l417, !tbaa !29
  %t922 = load ptr, ptr %l0, !tbaa !29
  %t923 = load i32, ptr %l28, !tbaa !23
  %t926 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %s33, ptr %t922, i32 %t923)
  store { i64, ptr } %t926, ptr %l420
  br label %bb140
bb140:
  %t927 = load ptr, ptr %l2, !tbaa !29
  %t928 = load i32, ptr %l28, !tbaa !23
  %t931 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAlign(ptr %v0, ptr %t927, i32 %t928)
  store i64 %t931, ptr %l423
  br label %bb141
bb141:
  %t932 = load i64, ptr %l423, !tbaa !24
  %t933 = call i64 @std_2fprelude_2fnumber_2eI64_2eMax_3cI64_3e(i64 %t932, i64 8)
  store i64 %t933, ptr %l424
  br label %bb142
bb142:
  %t934 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t935 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d174, i32 0, i32 1) }, 1
  %t936 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d174, i32 0, i32 1) }, 0
  %t937 = load { i64, ptr }, ptr %l420, !tbaa !27
  %t938 = extractvalue { i64, ptr } %t937, 1
  %t939 = extractvalue { i64, ptr } %t937, 0
  %t940 = add i64 %t936, %t939
  %t941 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d175, i32 0, i32 1) }, 1
  %t942 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d175, i32 0, i32 1) }, 0
  %t943 = add i64 %t940, %t942
  %t944 = load i64, ptr %l424, !tbaa !24
  %t945 = call i64 @__olang_fmt_i64(ptr null, i64 %t944)
  %t946 = add i64 %t943, %t945
  %t947 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d176, i32 0, i32 1) }, 1
  %t948 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d176, i32 0, i32 1) }, 0
  %t949 = add i64 %t946, %t948
  %t951 = extractvalue { i64, ptr } %t934, 1
  %t952 = extractvalue { i64, ptr } %t934, 0
  %t953 = add i64 %t949, %t952
  %t954 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t953)
  call void @olang_textcopy(ptr %t954, ptr %t935, i64 %t936)
  %t955 = getelementptr i8, ptr %t954, i64 %t936
  call void @olang_textcopy(ptr %t955, ptr %t938, i64 %t939)
  %t956 = getelementptr i8, ptr %t955, i64 %t939
  call void @olang_textcopy(ptr %t956, ptr %t941, i64 %t942)
  %t957 = getelementptr i8, ptr %t956, i64 %t942
  %t958 = call i64 @__olang_fmt_i64(ptr %t957, i64 %t944)
  %t959 = getelementptr i8, ptr %t957, i64 %t945
  call void @olang_textcopy(ptr %t959, ptr %t947, i64 %t948)
  %t960 = getelementptr i8, ptr %t959, i64 %t948
  call void @olang_textcopy(ptr %t960, ptr %t951, i64 %t952)
  %t961 = insertvalue { i64, ptr } undef, i64 %t953, 0
  %t962 = insertvalue { i64, ptr } %t961, ptr %t954, 1
  %t964 = extractvalue { i64, ptr } %t962, 0
  %t965 = extractvalue { i64, ptr } %t962, 1
  %t966 = mul i64 %t964, 1
  %t967 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t966)
  call void @llvm.memcpy.p0.p0.i64(ptr %t967, ptr %t965, i64 %t966, i1 false)
  %t968 = insertvalue { i64, ptr } undef, i64 %t964, 0
  %t969 = insertvalue { i64, ptr } %t968, ptr %t967, 1
  %t970 = load ptr, ptr %l417, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %t970, { i64, ptr } %t969)
  br label %bb143
bb143:
  call void @__olang_scope_close(ptr %s33)
  br label %bb150
bb144:
  br i1 true, label %bb145, label %bb146
bb145:
  br label %bb147
bb146:
  br label %bb149
bb147:
  %t972 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t973 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d177, i32 0, i32 1) }, 1
  %t974 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d177, i32 0, i32 1) }, 0
  %t976 = extractvalue { i64, ptr } %t972, 1
  %t977 = extractvalue { i64, ptr } %t972, 0
  %t978 = add i64 %t974, %t977
  %t979 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t978)
  call void @olang_textcopy(ptr %t979, ptr %t973, i64 %t974)
  %t980 = getelementptr i8, ptr %t979, i64 %t974
  call void @olang_textcopy(ptr %t980, ptr %t976, i64 %t977)
  %t981 = insertvalue { i64, ptr } undef, i64 %t978, 0
  %t982 = insertvalue { i64, ptr } %t981, ptr %t979, 1
  %t984 = extractvalue { i64, ptr } %t982, 0
  %t985 = extractvalue { i64, ptr } %t982, 1
  %t986 = mul i64 %t984, 1
  %t987 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t986)
  call void @llvm.memcpy.p0.p0.i64(ptr %t987, ptr %t985, i64 %t986, i1 false)
  %t988 = insertvalue { i64, ptr } undef, i64 %t984, 0
  %t989 = insertvalue { i64, ptr } %t988, ptr %t987, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %l17, { i64, ptr } %t989)
  br label %bb148
bb148:
  br label %bb150
bb149:
  call void @__olang_check_failed(ptr @olang_loc_ce3f793afe7e8735_eee0e2f7e7e28841)
  unreachable
bb150:
  %t992 = load i64, ptr %l27, !tbaa !24
  %t994 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t995 = load ptr, ptr %t994, !tbaa !27
  %t996 = getelementptr i8, ptr %t995, i64 %t992
  %t997 = load i8, ptr %t996, !tbaa !32
  %t999 = icmp eq i8 %t997, 109
  br i1 %t999, label %bb151, label %bb152
bb151:
  store %olang.scope zeroinitializer, ptr %s37
  %t1001 = load ptr, ptr %l11, !tbaa !29
  %t1002 = load i32, ptr %l28, !tbaa !23
  %t1005 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eslot(ptr %v0, ptr %s37, ptr %t1001, i32 %t1002)
  store { i64, ptr } %t1005, ptr %l437
  br label %bb153
bb152:
  store %olang.scope zeroinitializer, ptr %s39
  store ptr %l19, ptr %l448, !tbaa !29
  %t1006 = load ptr, ptr %l0, !tbaa !29
  %t1007 = load i32, ptr %l28, !tbaa !23
  %t1010 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %s39, ptr %t1006, i32 %t1007)
  store { i64, ptr } %t1010, ptr %l451
  br label %bb157
bb153:
  %t1011 = load { i64, ptr }, ptr %l437, !tbaa !27
  store { i64, ptr } %t1011, ptr %l43, !tbaa !27
  %t1012 = load ptr, ptr %l11, !tbaa !29
  store ptr %t1012, ptr %l438, !tbaa !29
  %t1013 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t1013, ptr %l439, !tbaa !27
  %t1014 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t1014, ptr %l440, !tbaa !27
  %t1015 = load ptr, ptr %l2, !tbaa !29
  %t1016 = load i32, ptr %l28, !tbaa !23
  %t1019 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSize(ptr %v0, ptr %t1015, i32 %t1016)
  store i64 %t1019, ptr %l443
  br label %bb154
bb154:
  %t1020 = load ptr, ptr %l438, !tbaa !29
  %t1021 = load { i64, ptr }, ptr %l439, !tbaa !27
  %t1022 = load { i64, ptr }, ptr %l440, !tbaa !27
  %t1023 = load i64, ptr %l443, !tbaa !24
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ememmove(ptr %v0, ptr %s37, ptr %s9, ptr %t1020, { i64, ptr } %t1021, { i64, ptr } %t1022, i64 %t1023)
  br label %bb155
bb155:
  %t1024 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t1025 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d178, i32 0, i32 1) }, 1
  %t1026 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d178, i32 0, i32 1) }, 0
  %t1028 = extractvalue { i64, ptr } %t1024, 1
  %t1029 = extractvalue { i64, ptr } %t1024, 0
  %t1030 = add i64 %t1026, %t1029
  %t1031 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1030)
  call void @olang_textcopy(ptr %t1031, ptr %t1025, i64 %t1026)
  %t1032 = getelementptr i8, ptr %t1031, i64 %t1026
  call void @olang_textcopy(ptr %t1032, ptr %t1028, i64 %t1029)
  %t1033 = insertvalue { i64, ptr } undef, i64 %t1030, 0
  %t1034 = insertvalue { i64, ptr } %t1033, ptr %t1031, 1
  %t1036 = extractvalue { i64, ptr } %t1034, 0
  %t1037 = extractvalue { i64, ptr } %t1034, 1
  %t1038 = mul i64 %t1036, 1
  %t1039 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1038)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1039, ptr %t1037, i64 %t1038, i1 false)
  %t1040 = insertvalue { i64, ptr } undef, i64 %t1036, 0
  %t1041 = insertvalue { i64, ptr } %t1040, ptr %t1039, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %l19, { i64, ptr } %t1041)
  br label %bb156
bb156:
  call void @__olang_scope_close(ptr %s37)
  br label %bb161
bb157:
  %t1044 = load ptr, ptr %l11, !tbaa !29
  store ptr %t1044, ptr %l452, !tbaa !29
  %t1045 = load ptr, ptr %l0, !tbaa !29
  %t1046 = load i32, ptr %l28, !tbaa !23
  %t1049 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %s39, ptr %t1045, i32 %t1046)
  store { i64, ptr } %t1049, ptr %l455
  br label %bb158
bb158:
  %t1050 = load { i64, ptr }, ptr %l455, !tbaa !27
  %t1051 = extractvalue { i64, ptr } %t1050, 0
  %t1052 = extractvalue { i64, ptr } %t1050, 1
  %t1053 = mul i64 %t1051, 1
  %t1054 = call ptr @__olang_scope_alloc(ptr %s39, i64 %t1053)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1054, ptr %t1052, i64 %t1053, i1 false)
  %t1055 = insertvalue { i64, ptr } undef, i64 %t1051, 0
  %t1056 = insertvalue { i64, ptr } %t1055, ptr %t1054, 1
  %t1057 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t1058 = load ptr, ptr %l452, !tbaa !29
  %t1061 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %s39, ptr %s9, ptr %s39, ptr %s39, ptr %t1058, { i64, ptr } %t1056, { i64, ptr } %t1057, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d179, i32 0, i32 1) })
  store { i64, ptr } %t1061, ptr %l458
  br label %bb159
bb159:
  %t1062 = load { i64, ptr }, ptr %l451, !tbaa !27
  %t1063 = extractvalue { i64, ptr } %t1062, 1
  %t1064 = extractvalue { i64, ptr } %t1062, 0
  %t1065 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d180, i32 0, i32 1) }, 1
  %t1066 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d180, i32 0, i32 1) }, 0
  %t1067 = add i64 %t1064, %t1066
  %t1068 = load { i64, ptr }, ptr %l458, !tbaa !27
  %t1069 = extractvalue { i64, ptr } %t1068, 1
  %t1070 = extractvalue { i64, ptr } %t1068, 0
  %t1071 = add i64 %t1067, %t1070
  %t1072 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1071)
  call void @olang_textcopy(ptr %t1072, ptr %t1063, i64 %t1064)
  %t1073 = getelementptr i8, ptr %t1072, i64 %t1064
  call void @olang_textcopy(ptr %t1073, ptr %t1065, i64 %t1066)
  %t1074 = getelementptr i8, ptr %t1073, i64 %t1066
  call void @olang_textcopy(ptr %t1074, ptr %t1069, i64 %t1070)
  %t1075 = insertvalue { i64, ptr } undef, i64 %t1071, 0
  %t1076 = insertvalue { i64, ptr } %t1075, ptr %t1072, 1
  %t1078 = extractvalue { i64, ptr } %t1076, 0
  %t1079 = extractvalue { i64, ptr } %t1076, 1
  %t1080 = mul i64 %t1078, 1
  %t1081 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1080)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1081, ptr %t1079, i64 %t1080, i1 false)
  %t1082 = insertvalue { i64, ptr } undef, i64 %t1078, 0
  %t1083 = insertvalue { i64, ptr } %t1082, ptr %t1081, 1
  %t1084 = load ptr, ptr %l448, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %t1084, { i64, ptr } %t1083)
  br label %bb160
bb160:
  call void @__olang_scope_close(ptr %s39)
  br label %bb161
bb161:
  call void @__olang_scope_close(ptr %s9)
  br label %bb162
bb162:
  %t1086 = load i64, ptr %l26, !tbaa !24
  %t1088 = add i64 %t1086, 1
  store i64 %t1088, ptr %l26, !tbaa !24
  br label %bb64
bb163:
  %t1090 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t1090, ptr %l44, !tbaa !23
  %t1092 = load i1, ptr %l15, !tbaa !21
  br i1 %t1092, label %bb164, label %bb165
bb164:
  %t1094 = load ptr, ptr %l2, !tbaa !29
  store ptr %t1094, ptr %l465, !tbaa !29
  %t1095 = load ptr, ptr %l2, !tbaa !29
  store ptr %t1095, ptr %l466, !tbaa !29
  %t1096 = load ptr, ptr %l0, !tbaa !29
  %t1097 = load i32, ptr %l12, !tbaa !23
  %t1100 = call i32 @compiler_2femit_2ecompiler_2femit_3aEmitter_2earrayOfE(ptr %v0, ptr %t1096, i32 %t1097)
  store i32 %t1100, ptr %l469
  br label %bb166
bb165:
  %t1101 = load i1, ptr %l14, !tbaa !21
  br i1 %t1101, label %bb176, label %bb177
bb166:
  %t1103 = load ptr, ptr %l466, !tbaa !29
  %t1104 = load i32, ptr %l469, !tbaa !23
  %t1105 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t1103, i32 %t1104)
  store i32 %t1105, ptr %l470
  br label %bb167
bb167:
  %t1106 = load ptr, ptr %l465, !tbaa !29
  %t1107 = load i32, ptr %l470, !tbaa !23
  %t1108 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t1106, i32 %t1107)
  store i32 %t1108, ptr %l471
  br label %bb168
bb168:
  %t1109 = load i32, ptr %l471, !tbaa !23
  store i32 %t1109, ptr %l44, !tbaa !23
  %t1110 = load ptr, ptr %l3, !tbaa !29
  %t1111 = load i32, ptr %l44, !tbaa !23
  %t1114 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLayout(ptr %v0, ptr %t1110, i32 %t1111)
  store i1 %t1114, ptr %l474
  br label %bb169
bb169:
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %l17, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d181, i32 0, i32 1) })
  br label %bb170
bb170:
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %l17, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d182, i32 0, i32 1) })
  br label %bb171
bb171:
  %t1117 = load i1, ptr %l14, !tbaa !21
  br i1 %t1117, label %bb172, label %bb173
bb172:
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %l17, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d183, i32 0, i32 1) })
  br label %bb174
bb173:
  br label %bb175
bb174:
  br label %bb175
bb175:
  br label %bb183
bb176:
  %t1120 = load i1, ptr %l13, !tbaa !21
  store i1 %t1120, ptr %l480, !tbaa !21
  br label %bb178
bb177:
  store i1 false, ptr %l480, !tbaa !21
  br label %bb178
bb178:
  %t1122 = load i1, ptr %l480, !tbaa !21
  br i1 %t1122, label %bb179, label %bb180
bb179:
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %l17, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d184, i32 0, i32 1) })
  br label %bb181
bb180:
  br label %bb182
bb181:
  br label %bb182
bb182:
  br label %bb183
bb183:
  %t1124 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edefine(ptr %v0, ptr %s0, ptr %s0, ptr %t1124, { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d185, i32 0, i32 1) }, { i64, ptr } { i64 61, ptr getelementptr inbounds (<{ i64, [61 x i8] }>, ptr @.d186, i32 0, i32 1) })
  br label %bb184
bb184:
  %t1126 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %s0, ptr %t1126, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d187, i32 0, i32 1) })
  br label %bb185
bb185:
  %t1128 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %s0, ptr %t1128, { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d188, i32 0, i32 1) })
  br label %bb186
bb186:
  %t1130 = load ptr, ptr %l11, !tbaa !29
  %t1132 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t1130, { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d189, i32 0, i32 1) })
  store { i64, ptr } %t1132, ptr %l487
  br label %bb187
bb187:
  %t1133 = load { i64, ptr }, ptr %l487, !tbaa !27
  %t1134 = load ptr, ptr %l11, !tbaa !29
  %t1136 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d190, i32 0, i32 1) }, 1
  %t1137 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d190, i32 0, i32 1) }, 0
  %t1139 = extractvalue { i64, ptr } %t1133, 1
  %t1140 = extractvalue { i64, ptr } %t1133, 0
  %t1141 = add i64 %t1137, %t1140
  %t1142 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d191, i32 0, i32 1) }, 1
  %t1143 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d191, i32 0, i32 1) }, 0
  %t1144 = add i64 %t1141, %t1143
  %t1145 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1144)
  call void @olang_textcopy(ptr %t1145, ptr %t1136, i64 %t1137)
  %t1146 = getelementptr i8, ptr %t1145, i64 %t1137
  call void @olang_textcopy(ptr %t1146, ptr %t1139, i64 %t1140)
  %t1147 = getelementptr i8, ptr %t1146, i64 %t1140
  call void @olang_textcopy(ptr %t1147, ptr %t1142, i64 %t1143)
  %t1148 = insertvalue { i64, ptr } undef, i64 %t1144, 0
  %t1149 = insertvalue { i64, ptr } %t1148, ptr %t1145, 1
  %t1151 = extractvalue { i64, ptr } %t1149, 0
  %t1152 = extractvalue { i64, ptr } %t1149, 1
  %t1153 = mul i64 %t1151, 1
  %t1154 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1153)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1154, ptr %t1152, i64 %t1153, i1 false)
  %t1155 = insertvalue { i64, ptr } undef, i64 %t1151, 0
  %t1156 = insertvalue { i64, ptr } %t1155, ptr %t1154, 1
  %t1159 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t1134, { i64, ptr } %t1156)
  store { i64, ptr } %t1159, ptr %l492
  br label %bb188
bb188:
  %t1160 = load { i64, ptr }, ptr %l492, !tbaa !27
  %t1161 = load ptr, ptr %l11, !tbaa !29
  %t1163 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d192, i32 0, i32 1) }, 1
  %t1164 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d192, i32 0, i32 1) }, 0
  %t1166 = extractvalue { i64, ptr } %t1160, 1
  %t1167 = extractvalue { i64, ptr } %t1160, 0
  %t1168 = add i64 %t1164, %t1167
  %t1169 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d193, i32 0, i32 1) }, 1
  %t1170 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d193, i32 0, i32 1) }, 0
  %t1171 = add i64 %t1168, %t1170
  %t1172 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1171)
  call void @olang_textcopy(ptr %t1172, ptr %t1163, i64 %t1164)
  %t1173 = getelementptr i8, ptr %t1172, i64 %t1164
  call void @olang_textcopy(ptr %t1173, ptr %t1166, i64 %t1167)
  %t1174 = getelementptr i8, ptr %t1173, i64 %t1167
  call void @olang_textcopy(ptr %t1174, ptr %t1169, i64 %t1170)
  %t1175 = insertvalue { i64, ptr } undef, i64 %t1171, 0
  %t1176 = insertvalue { i64, ptr } %t1175, ptr %t1172, 1
  %t1178 = extractvalue { i64, ptr } %t1176, 0
  %t1179 = extractvalue { i64, ptr } %t1176, 1
  %t1180 = mul i64 %t1178, 1
  %t1181 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1180)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1181, ptr %t1179, i64 %t1180, i1 false)
  %t1182 = insertvalue { i64, ptr } undef, i64 %t1178, 0
  %t1183 = insertvalue { i64, ptr } %t1182, ptr %t1181, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s0, ptr %t1161, { i64, ptr } %t1183)
  br label %bb189
bb189:
  %t1186 = load ptr, ptr %l11, !tbaa !29
  %t1188 = getelementptr %"compiler/emit:fnEm", ptr %t1186, i32 0, i32 5
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s0, ptr %t1188, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d194, i32 0, i32 1) })
  br label %bb190
bb190:
  %t1190 = load ptr, ptr %l11, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s0, ptr %t1190, { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d195, i32 0, i32 1) })
  br label %bb191
bb191:
  %t1192 = load ptr, ptr %l11, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s0, ptr %t1192, { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d196, i32 0, i32 1) })
  br label %bb192
bb192:
  %t1194 = load ptr, ptr %l11, !tbaa !29
  %t1196 = getelementptr %"compiler/emit:fnEm", ptr %t1194, i32 0, i32 5
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s0, ptr %t1196, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d197, i32 0, i32 1) })
  br label %bb193
bb193:
  %t1198 = load ptr, ptr %l11, !tbaa !29
  %t1200 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ealloca(ptr %v0, ptr %s0, ptr %s0, ptr %t1198, { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d198, i32 0, i32 1) }, i64 8)
  store { i64, ptr } %t1200, ptr %l504
  br label %bb194
bb194:
  %t1201 = load { i64, ptr }, ptr %l504, !tbaa !27
  store { i64, ptr } %t1201, ptr %l47, !tbaa !27
  %t1202 = load ptr, ptr %l11, !tbaa !29
  %t1203 = load { i64, ptr }, ptr %l47, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %t1202, { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d199, i32 0, i32 1) }, { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d200, i32 0, i32 1) }, { i64, ptr } %t1203, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d173, i32 0, i32 1) })
  br label %bb195
bb195:
  %t1206 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %s0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1206, ptr %l507
  br label %bb196
bb196:
  %t1207 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l507
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1207, ptr %l48
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d201, i32 0, i32 1) }, ptr %l508, !tbaa !27
  %t1208 = load { i64, ptr }, ptr %l508, !tbaa !27
  store { i64, ptr } %t1208, ptr %l509, !tbaa !27
  %t1209 = load { i64, ptr }, ptr %l509, !tbaa !27
  %t1210 = extractvalue { i64, ptr } %t1209, 0
  store i64 %t1210, ptr %l510, !tbaa !24
  %t1211 = load i64, ptr %l510, !tbaa !24
  %t1212 = mul i64 %t1211, 1
  %t1213 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t1212)
  %t1214 = insertvalue { i64, ptr } undef, i64 %t1211, 0
  %t1215 = insertvalue { i64, ptr } %t1214, ptr %t1213, 1
  store { i64, ptr } %t1215, ptr %l511, !tbaa !27
  %t1216 = getelementptr { i64, ptr }, ptr %l511, i32 0, i32 1
  %t1217 = load ptr, ptr %t1216, !tbaa !27
  %t1218 = getelementptr { i64, ptr }, ptr %l509, i32 0, i32 1
  %t1219 = load ptr, ptr %t1218, !tbaa !27
  %t1220 = load i64, ptr %l510, !tbaa !24
  %t1221 = mul i64 %t1220, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1217, ptr %t1219, i64 %t1221, i1 false)
  %t1222 = load { i64, ptr }, ptr %l511, !tbaa !27
  store { i64, ptr } %t1222, ptr %l49, !tbaa !27
  %t1223 = load i1, ptr %l13, !tbaa !21
  br i1 %t1223, label %bb197, label %bb198
bb197:
  %t1225 = load ptr, ptr %l2, !tbaa !29
  %t1226 = load i32, ptr %l12, !tbaa !23
  %t1229 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eViaMemory(ptr %v0, ptr %t1225, i32 %t1226)
  store i1 %t1229, ptr %l516
  br label %bb199
bb198:
  store i1 false, ptr %l513, !tbaa !21
  br label %bb200
bb199:
  %t1230 = load i1, ptr %l516, !tbaa !21
  store i1 %t1230, ptr %l513, !tbaa !21
  br label %bb200
bb200:
  %t1231 = load i1, ptr %l513, !tbaa !21
  br i1 %t1231, label %bb201, label %bb202
bb201:
  %t1232 = load ptr, ptr %l11, !tbaa !29
  %t1233 = load i32, ptr %l12, !tbaa !23
  %t1236 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eslot(ptr %v0, ptr %s0, ptr %t1232, i32 %t1233)
  store { i64, ptr } %t1236, ptr %l519
  br label %bb203
bb202:
  br label %bb208
bb203:
  %t1237 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t1238 = extractvalue { i64, ptr } %t1237, 0
  %t1239 = load { i64, ptr }, ptr %l519, !tbaa !27
  %t1240 = extractvalue { i64, ptr } %t1239, 0
  store i64 %t1240, ptr %l521, !tbaa !24
  %t1242 = load i64, ptr %l521, !tbaa !24
  %t1243 = icmp eq i64 %t1238, %t1242
  br i1 %t1243, label %bb204, label %bb205
bb204:
  %t1245 = getelementptr { i64, ptr }, ptr %l49, i32 0, i32 1
  %t1246 = load ptr, ptr %t1245, !tbaa !27
  %t1247 = getelementptr { i64, ptr }, ptr %l519, i32 0, i32 1
  %t1248 = load ptr, ptr %t1247, !tbaa !27
  %t1249 = load i64, ptr %l521, !tbaa !24
  %t1250 = mul i64 %t1249, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1246, ptr %t1248, i64 %t1250, i1 false)
  br label %bb206
bb205:
  %t1251 = load { i64, ptr }, ptr %l519, !tbaa !27
  store { i64, ptr } %t1251, ptr %l49, !tbaa !27
  br label %bb206
bb206:
  %t1252 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t1253 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d202, i32 0, i32 1) }, 1
  %t1254 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d202, i32 0, i32 1) }, 0
  %t1256 = extractvalue { i64, ptr } %t1252, 1
  %t1257 = extractvalue { i64, ptr } %t1252, 0
  %t1258 = add i64 %t1254, %t1257
  %t1259 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1258)
  call void @olang_textcopy(ptr %t1259, ptr %t1253, i64 %t1254)
  %t1260 = getelementptr i8, ptr %t1259, i64 %t1254
  call void @olang_textcopy(ptr %t1260, ptr %t1256, i64 %t1257)
  %t1261 = insertvalue { i64, ptr } undef, i64 %t1258, 0
  %t1262 = insertvalue { i64, ptr } %t1261, ptr %t1259, 1
  %t1264 = extractvalue { i64, ptr } %t1262, 0
  %t1265 = extractvalue { i64, ptr } %t1262, 1
  %t1266 = mul i64 %t1264, 1
  %t1267 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1266)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1267, ptr %t1265, i64 %t1266, i1 false)
  %t1268 = insertvalue { i64, ptr } undef, i64 %t1264, 0
  %t1269 = insertvalue { i64, ptr } %t1268, ptr %t1267, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %l48, { i64, ptr } %t1269)
  br label %bb207
bb207:
  br label %bb208
bb208:
  store i64 0, ptr %l50, !tbaa !24
  %t1272 = load ptr, ptr %l2, !tbaa !29
  %t1273 = load { i64, [2 x i64] }, ptr %l10
  %t1274 = load i32, ptr %l9, !tbaa !23
  store { i64, [7 x i64] } zeroinitializer, ptr %t1275
  %t1276 = getelementptr { i64, [7 x i64] }, ptr %t1275, i32 0, i32 0
  store i64 0, ptr %t1276
  %t1278 = insertvalue { { i64, [2 x i64] }, i32 } undef, { i64, [2 x i64] } %t1273, 0
  %t1280 = insertvalue { { i64, [2 x i64] }, i32 } %t1278, i32 %t1274, 1
  %t1281 = getelementptr { i64, [7 x i64] }, ptr %t1275, i32 0, i32 1
  store { { i64, [2 x i64] }, i32 } %t1280, ptr %t1281
  %t1282 = load { i64, [7 x i64] }, ptr %t1275
  %t1283 = load i32, ptr %l9, !tbaa !23
  %t1287 = call i64 @compiler_2fmir_2ePassedCount(ptr %v0, ptr %t1272, { i64, [7 x i64] } %t1282, i32 %t1283)
  store i64 %t1287, ptr %l532
  br label %bb209
bb209:
  %t1288 = load i64, ptr %l532, !tbaa !24
  store i64 %t1288, ptr %l51, !tbaa !24
  store i64 1, ptr %l52, !tbaa !24
  %t1289 = load i64, ptr %l51, !tbaa !24
  %t1290 = load i64, ptr %l50, !tbaa !24
  %t1293 = icmp sgt i64 %t1289, %t1290
  br i1 %t1293, label %bb210, label %bb211
bb210:
  %t1295 = load i64, ptr %l52, !tbaa !24
  %t1297 = icmp sgt i64 %t1295, 0
  br i1 %t1297, label %bb212, label %bb213
bb211:
  store i64 0, ptr %l536, !tbaa !24
  br label %bb215
bb212:
  %t1299 = load i64, ptr %l51, !tbaa !24
  %t1300 = load i64, ptr %l50, !tbaa !24
  %t1303 = sub i64 %t1299, %t1300
  %t1304 = load i64, ptr %l52, !tbaa !24
  %t1307 = add i64 %t1303, %t1304
  %t1309 = sub i64 %t1307, 1
  %t1310 = load i64, ptr %l52, !tbaa !24
  %t1313 = sdiv i64 %t1309, %t1310
  store i64 %t1313, ptr %l539, !tbaa !24
  br label %bb214
bb213:
  store i64 0, ptr %l539, !tbaa !24
  br label %bb214
bb214:
  %t1315 = load i64, ptr %l539, !tbaa !24
  store i64 %t1315, ptr %l536, !tbaa !24
  br label %bb215
bb215:
  %t1316 = load i64, ptr %l536, !tbaa !24
  store i64 %t1316, ptr %l53, !tbaa !24
  store i64 0, ptr %l54, !tbaa !24
  br label %bb216
bb216:
  store %olang.scope zeroinitializer, ptr %s51
  %t1317 = load i64, ptr %l54, !tbaa !24
  %t1318 = load i64, ptr %l53, !tbaa !24
  %t1321 = icmp slt i64 %t1317, %t1318
  %t1323 = xor i1 %t1321, true
  br i1 %t1323, label %bb217, label %bb218
bb217:
  call void @__olang_scope_close(ptr %s51)
  br label %bb222
bb218:
  br label %bb219
bb219:
  %t1325 = load i64, ptr %l50, !tbaa !24
  %t1326 = load i64, ptr %l54, !tbaa !24
  %t1327 = load i64, ptr %l52, !tbaa !24
  %t1330 = mul i64 %t1326, %t1327
  %t1333 = add i64 %t1325, %t1330
  store i64 %t1333, ptr %l55, !tbaa !24
  %t1335 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t1336 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d203, i32 0, i32 1) }, 1
  %t1337 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d203, i32 0, i32 1) }, 0
  %t1339 = extractvalue { i64, ptr } %t1335, 1
  %t1340 = extractvalue { i64, ptr } %t1335, 0
  %t1341 = add i64 %t1337, %t1340
  %t1342 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1341)
  call void @olang_textcopy(ptr %t1342, ptr %t1336, i64 %t1337)
  %t1343 = getelementptr i8, ptr %t1342, i64 %t1337
  call void @olang_textcopy(ptr %t1343, ptr %t1339, i64 %t1340)
  %t1344 = insertvalue { i64, ptr } undef, i64 %t1341, 0
  %t1345 = insertvalue { i64, ptr } %t1344, ptr %t1342, 1
  %t1347 = extractvalue { i64, ptr } %t1345, 0
  %t1348 = extractvalue { i64, ptr } %t1345, 1
  %t1349 = mul i64 %t1347, 1
  %t1350 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1349)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1350, ptr %t1348, i64 %t1349, i1 false)
  %t1351 = insertvalue { i64, ptr } undef, i64 %t1347, 0
  %t1352 = insertvalue { i64, ptr } %t1351, ptr %t1350, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %l48, { i64, ptr } %t1352)
  br label %bb220
bb220:
  call void @__olang_scope_close(ptr %s51)
  br label %bb221
bb221:
  %t1355 = load i64, ptr %l54, !tbaa !24
  %t1357 = add i64 %t1355, 1
  store i64 %t1357, ptr %l54, !tbaa !24
  br label %bb216
bb222:
  store ptr %l19, ptr %l56, !tbaa !29
  store i64 0, ptr %l57, !tbaa !24
  br label %bb223
bb223:
  store %olang.scope zeroinitializer, ptr %s55
  %t1360 = load ptr, ptr %l56, !tbaa !29
  %t1361 = load i64, ptr %l57, !tbaa !24
  %t1364 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hfabcb4ab830a5416feda1aea3d8bba10(ptr %s0, ptr %t1360, i64 %t1361)
  %t1365 = extractvalue { i32, { i64, ptr } } %t1364, 1
  %t1366 = extractvalue { i32, { i64, ptr } } %t1364, 0
  store i32 %t1366, ptr %l568
  %t1367 = icmp ne i32 %t1366, 0
  br i1 %t1367, label %bb225, label %ok.1368
ok.1368:
  store { i64, ptr } %t1365, ptr %l567
  br label %bb224
bb224:
  %t1369 = load { i64, ptr }, ptr %l567, !tbaa !27
  store { i64, ptr } %t1369, ptr %l564, !tbaa !27
  br label %bb229
bb225:
  %t1370 = load i32, ptr %l568, !tbaa !23
  %t1371 = ashr i32 %t1370, 16
  %t1373 = icmp eq i32 %t1371, 1
  br i1 %t1373, label %bb226, label %bb227
bb226:
  br label %bb228
bb227:
  call void @__olang_check_failed(ptr @olang_loc_9000b3cdde9de97e_540aa7fc20a2aa2a)
  unreachable
bb228:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s55)
  br label %bb238
bb229:
  %t1375 = load { i64, ptr }, ptr %l564, !tbaa !27
  store { i64, ptr } %t1375, ptr %l58, !tbaa !27
  %t1376 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t1378 = extractvalue { i64, ptr } %t1376, 0
  store i64 %t1378, ptr %l59, !tbaa !24
  store i64 0, ptr %l60, !tbaa !24
  br label %bb230
bb230:
  store %olang.scope zeroinitializer, ptr %s56
  %t1380 = load i64, ptr %l60, !tbaa !24
  %t1381 = load i64, ptr %l59, !tbaa !24
  %t1384 = icmp slt i64 %t1380, %t1381
  %t1386 = xor i1 %t1384, true
  br i1 %t1386, label %bb231, label %bb232
bb231:
  call void @__olang_scope_close(ptr %s56)
  br label %bb236
bb232:
  br label %bb233
bb233:
  %t1388 = load { i64, ptr }, ptr %l58, !tbaa !27
  store { i64, ptr } %t1388, ptr %l577, !tbaa !27
  %t1389 = load i64, ptr %l60, !tbaa !24
  %t1391 = getelementptr { i64, ptr }, ptr %l577, i32 0, i32 1
  %t1392 = load ptr, ptr %t1391, !tbaa !27
  %t1393 = getelementptr { i64, ptr }, ptr %t1392, i64 %t1389
  %t1394 = load { i64, ptr }, ptr %t1393, !tbaa !37
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %l48, { i64, ptr } %t1394)
  br label %bb234
bb234:
  call void @__olang_scope_close(ptr %s56)
  br label %bb235
bb235:
  %t1399 = load i64, ptr %l60, !tbaa !24
  %t1401 = add i64 %t1399, 1
  store i64 %t1401, ptr %l60, !tbaa !24
  br label %bb230
bb236:
  %t1403 = load i64, ptr %l57, !tbaa !24
  %t1404 = load i64, ptr %l59, !tbaa !24
  %t1407 = add i64 %t1403, %t1404
  store i64 %t1407, ptr %l57, !tbaa !24
  call void @__olang_scope_close(ptr %s55)
  br label %bb237
bb237:
  br label %bb223
bb238:
  %t1409 = load ptr, ptr %l2, !tbaa !29
  %t1410 = load i32, ptr %l9, !tbaa !23
  %t1413 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRetLlvm(ptr %v0, ptr %s0, ptr %t1409, i32 %t1410)
  store { i64, ptr } %t1413, ptr %l589
  br label %bb239
bb239:
  %t1414 = load { i64, ptr }, ptr %l589, !tbaa !27
  store { i64, ptr } %t1414, ptr %l62, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d204, i32 0, i32 1) }, ptr %l590, !tbaa !27
  %t1415 = load { i64, ptr }, ptr %l590, !tbaa !27
  store { i64, ptr } %t1415, ptr %l591, !tbaa !27
  %t1416 = load { i64, ptr }, ptr %l591, !tbaa !27
  %t1417 = extractvalue { i64, ptr } %t1416, 0
  store i64 %t1417, ptr %l592, !tbaa !24
  %t1418 = load i64, ptr %l592, !tbaa !24
  %t1419 = mul i64 %t1418, 1
  %t1420 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t1419)
  %t1421 = insertvalue { i64, ptr } undef, i64 %t1418, 0
  %t1422 = insertvalue { i64, ptr } %t1421, ptr %t1420, 1
  store { i64, ptr } %t1422, ptr %l593, !tbaa !27
  %t1423 = getelementptr { i64, ptr }, ptr %l593, i32 0, i32 1
  %t1424 = load ptr, ptr %t1423, !tbaa !27
  %t1425 = getelementptr { i64, ptr }, ptr %l591, i32 0, i32 1
  %t1426 = load ptr, ptr %t1425, !tbaa !27
  %t1427 = load i64, ptr %l592, !tbaa !24
  %t1428 = mul i64 %t1427, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1424, ptr %t1426, i64 %t1428, i1 false)
  %t1429 = load { i64, ptr }, ptr %l593, !tbaa !27
  store { i64, ptr } %t1429, ptr %l63, !tbaa !27
  %t1430 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1430, ptr %l594
  br label %bb240
bb240:
  %t1431 = load %"std/prelude/text:StringBuilder", ptr %l594
  store %"std/prelude/text:StringBuilder" %t1431, ptr %l64
  store ptr %l48, ptr %l65, !tbaa !29
  store i64 0, ptr %l66, !tbaa !24
  store i64 0, ptr %l67, !tbaa !24
  br label %bb241
bb241:
  store %olang.scope zeroinitializer, ptr %s59
  %t1433 = load ptr, ptr %l65, !tbaa !29
  %t1434 = load i64, ptr %l66, !tbaa !24
  %t1437 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hfabcb4ab830a5416feda1aea3d8bba10(ptr %s0, ptr %t1433, i64 %t1434)
  %t1438 = extractvalue { i32, { i64, ptr } } %t1437, 1
  %t1439 = extractvalue { i32, { i64, ptr } } %t1437, 0
  store i32 %t1439, ptr %l600
  %t1440 = icmp ne i32 %t1439, 0
  br i1 %t1440, label %bb243, label %ok.1441
ok.1441:
  store { i64, ptr } %t1438, ptr %l599
  br label %bb242
bb242:
  %t1442 = load { i64, ptr }, ptr %l599, !tbaa !27
  store { i64, ptr } %t1442, ptr %l596, !tbaa !27
  br label %bb247
bb243:
  %t1443 = load i32, ptr %l600, !tbaa !23
  %t1444 = ashr i32 %t1443, 16
  %t1446 = icmp eq i32 %t1444, 1
  br i1 %t1446, label %bb244, label %bb245
bb244:
  br label %bb246
bb245:
  call void @__olang_check_failed(ptr @olang_loc_882423aaa1f01f7f_b9c3af967e36d8eb)
  unreachable
bb246:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s59)
  br label %bb260
bb247:
  %t1448 = load { i64, ptr }, ptr %l596, !tbaa !27
  store { i64, ptr } %t1448, ptr %l68, !tbaa !27
  %t1449 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t1451 = extractvalue { i64, ptr } %t1449, 0
  store i64 %t1451, ptr %l69, !tbaa !24
  store i64 0, ptr %l70, !tbaa !24
  br label %bb248
bb248:
  store %olang.scope zeroinitializer, ptr %s60
  %t1453 = load i64, ptr %l70, !tbaa !24
  %t1454 = load i64, ptr %l69, !tbaa !24
  %t1457 = icmp slt i64 %t1453, %t1454
  %t1459 = xor i1 %t1457, true
  br i1 %t1459, label %bb249, label %bb250
bb249:
  call void @__olang_scope_close(ptr %s60)
  br label %bb258
bb250:
  br label %bb251
bb251:
  %t1461 = load i64, ptr %l67, !tbaa !24
  %t1463 = load { i64, ptr }, ptr %l68, !tbaa !27
  store { i64, ptr } %t1463, ptr %l610, !tbaa !27
  %t1464 = load i64, ptr %l70, !tbaa !24
  %t1466 = getelementptr { i64, ptr }, ptr %l610, i32 0, i32 1
  %t1467 = load ptr, ptr %t1466, !tbaa !27
  %t1468 = getelementptr { i64, ptr }, ptr %t1467, i64 %t1464
  %t1469 = load { i64, ptr }, ptr %t1468, !tbaa !37
  store { i64, ptr } %t1469, ptr %l72, !tbaa !27
  %t1473 = icmp sgt i64 %t1461, 0
  br i1 %t1473, label %bb252, label %bb253
bb252:
  store %olang.scope zeroinitializer, ptr %s61
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s61, ptr %l64, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d205, i32 0, i32 1) })
  br label %bb254
bb253:
  br label %bb255
bb254:
  call void @__olang_scope_close(ptr %s61)
  br label %bb255
bb255:
  %t1476 = load { i64, ptr }, ptr %l72, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l64, { i64, ptr } %t1476)
  br label %bb256
bb256:
  call void @__olang_scope_close(ptr %s60)
  br label %bb257
bb257:
  %t1479 = load i64, ptr %l70, !tbaa !24
  %t1481 = add i64 %t1479, 1
  store i64 %t1481, ptr %l70, !tbaa !24
  %t1483 = load i64, ptr %l67, !tbaa !24
  %t1485 = add i64 %t1483, 1
  store i64 %t1485, ptr %l67, !tbaa !24
  br label %bb248
bb258:
  %t1487 = load i64, ptr %l66, !tbaa !24
  %t1488 = load i64, ptr %l69, !tbaa !24
  %t1491 = add i64 %t1487, %t1488
  store i64 %t1491, ptr %l66, !tbaa !24
  call void @__olang_scope_close(ptr %s59)
  br label %bb259
bb259:
  br label %bb241
bb260:
  %t1493 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t1495 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t1493, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d206, i32 0, i32 1) })
  store i1 %t1495, ptr %l626
  br label %bb261
bb261:
  %t1496 = load i1, ptr %l626, !tbaa !21
  br i1 %t1496, label %bb262, label %bb263
bb262:
  store %olang.scope zeroinitializer, ptr %s63
  %t1497 = load ptr, ptr %l11, !tbaa !29
  store ptr %t1497, ptr %l627, !tbaa !29
  %t1498 = load ptr, ptr %l0, !tbaa !29
  %t1499 = load { i64, [2 x i64] }, ptr %l10
  %t1502 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2esym(ptr %v0, ptr %s63, ptr %t1498, { i64, [2 x i64] } %t1499)
  store { i64, ptr } %t1502, ptr %l630
  br label %bb264
bb263:
  store %olang.scope zeroinitializer, ptr %s65
  %t1503 = load ptr, ptr %l11, !tbaa !29
  store ptr %t1503, ptr %l635, !tbaa !29
  %t1504 = load { i64, ptr }, ptr %l62, !tbaa !27
  store { i64, ptr } %t1504, ptr %l636, !tbaa !27
  %t1505 = load ptr, ptr %l0, !tbaa !29
  %t1506 = load { i64, [2 x i64] }, ptr %l10
  %t1509 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2esym(ptr %v0, ptr %s65, ptr %t1505, { i64, [2 x i64] } %t1506)
  store { i64, ptr } %t1509, ptr %l639
  br label %bb267
bb264:
  %t1511 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s63, ptr %l64)
  store { i64, ptr } %t1511, ptr %l632
  br label %bb265
bb265:
  %t1512 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d207, i32 0, i32 1) }, 1
  %t1513 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d207, i32 0, i32 1) }, 0
  %t1514 = load { i64, ptr }, ptr %l630, !tbaa !27
  %t1515 = extractvalue { i64, ptr } %t1514, 1
  %t1516 = extractvalue { i64, ptr } %t1514, 0
  %t1517 = add i64 %t1513, %t1516
  %t1518 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d208, i32 0, i32 1) }, 1
  %t1519 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d208, i32 0, i32 1) }, 0
  %t1520 = add i64 %t1517, %t1519
  %t1521 = load { i64, ptr }, ptr %l632, !tbaa !27
  %t1522 = extractvalue { i64, ptr } %t1521, 1
  %t1523 = extractvalue { i64, ptr } %t1521, 0
  %t1524 = add i64 %t1520, %t1523
  %t1525 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d209, i32 0, i32 1) }, 1
  %t1526 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d209, i32 0, i32 1) }, 0
  %t1527 = add i64 %t1524, %t1526
  %t1528 = call ptr @__olang_scope_alloc(ptr %s63, i64 %t1527)
  call void @olang_textcopy(ptr %t1528, ptr %t1512, i64 %t1513)
  %t1529 = getelementptr i8, ptr %t1528, i64 %t1513
  call void @olang_textcopy(ptr %t1529, ptr %t1515, i64 %t1516)
  %t1530 = getelementptr i8, ptr %t1529, i64 %t1516
  call void @olang_textcopy(ptr %t1530, ptr %t1518, i64 %t1519)
  %t1531 = getelementptr i8, ptr %t1530, i64 %t1519
  call void @olang_textcopy(ptr %t1531, ptr %t1522, i64 %t1523)
  %t1532 = getelementptr i8, ptr %t1531, i64 %t1523
  call void @olang_textcopy(ptr %t1532, ptr %t1525, i64 %t1526)
  %t1533 = insertvalue { i64, ptr } undef, i64 %t1527, 0
  %t1534 = insertvalue { i64, ptr } %t1533, ptr %t1528, 1
  %t1536 = extractvalue { i64, ptr } %t1534, 0
  %t1537 = extractvalue { i64, ptr } %t1534, 1
  %t1538 = mul i64 %t1536, 1
  %t1539 = call ptr @__olang_scope_alloc(ptr %s63, i64 %t1538)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1539, ptr %t1537, i64 %t1538, i1 false)
  %t1540 = insertvalue { i64, ptr } undef, i64 %t1536, 0
  %t1541 = insertvalue { i64, ptr } %t1540, ptr %t1539, 1
  %t1542 = load ptr, ptr %l627, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s63, ptr %t1542, { i64, ptr } %t1541)
  br label %bb266
bb266:
  call void @__olang_scope_close(ptr %s63)
  br label %bb273
bb267:
  %t1545 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s65, ptr %l64)
  store { i64, ptr } %t1545, ptr %l641
  br label %bb268
bb268:
  %t1546 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d210, i32 0, i32 1) }, 1
  %t1547 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d210, i32 0, i32 1) }, 0
  %t1548 = load { i64, ptr }, ptr %l636, !tbaa !27
  %t1549 = extractvalue { i64, ptr } %t1548, 1
  %t1550 = extractvalue { i64, ptr } %t1548, 0
  %t1551 = add i64 %t1547, %t1550
  %t1552 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d211, i32 0, i32 1) }, 1
  %t1553 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d211, i32 0, i32 1) }, 0
  %t1554 = add i64 %t1551, %t1553
  %t1555 = load { i64, ptr }, ptr %l639, !tbaa !27
  %t1556 = extractvalue { i64, ptr } %t1555, 1
  %t1557 = extractvalue { i64, ptr } %t1555, 0
  %t1558 = add i64 %t1554, %t1557
  %t1559 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d212, i32 0, i32 1) }, 1
  %t1560 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d212, i32 0, i32 1) }, 0
  %t1561 = add i64 %t1558, %t1560
  %t1562 = load { i64, ptr }, ptr %l641, !tbaa !27
  %t1563 = extractvalue { i64, ptr } %t1562, 1
  %t1564 = extractvalue { i64, ptr } %t1562, 0
  %t1565 = add i64 %t1561, %t1564
  %t1566 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d213, i32 0, i32 1) }, 1
  %t1567 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d213, i32 0, i32 1) }, 0
  %t1568 = add i64 %t1565, %t1567
  %t1569 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1568)
  call void @olang_textcopy(ptr %t1569, ptr %t1546, i64 %t1547)
  %t1570 = getelementptr i8, ptr %t1569, i64 %t1547
  call void @olang_textcopy(ptr %t1570, ptr %t1549, i64 %t1550)
  %t1571 = getelementptr i8, ptr %t1570, i64 %t1550
  call void @olang_textcopy(ptr %t1571, ptr %t1552, i64 %t1553)
  %t1572 = getelementptr i8, ptr %t1571, i64 %t1553
  call void @olang_textcopy(ptr %t1572, ptr %t1556, i64 %t1557)
  %t1573 = getelementptr i8, ptr %t1572, i64 %t1557
  call void @olang_textcopy(ptr %t1573, ptr %t1559, i64 %t1560)
  %t1574 = getelementptr i8, ptr %t1573, i64 %t1560
  call void @olang_textcopy(ptr %t1574, ptr %t1563, i64 %t1564)
  %t1575 = getelementptr i8, ptr %t1574, i64 %t1564
  call void @olang_textcopy(ptr %t1575, ptr %t1566, i64 %t1567)
  %t1576 = insertvalue { i64, ptr } undef, i64 %t1568, 0
  %t1577 = insertvalue { i64, ptr } %t1576, ptr %t1569, 1
  %t1579 = extractvalue { i64, ptr } %t1577, 0
  %t1580 = extractvalue { i64, ptr } %t1577, 1
  %t1581 = mul i64 %t1579, 1
  %t1582 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1581)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1582, ptr %t1580, i64 %t1581, i1 false)
  %t1583 = insertvalue { i64, ptr } undef, i64 %t1579, 0
  %t1584 = insertvalue { i64, ptr } %t1583, ptr %t1582, 1
  %t1585 = load ptr, ptr %l635, !tbaa !29
  %t1587 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t1585, { i64, ptr } %t1584)
  store { i64, ptr } %t1587, ptr %l644
  br label %bb269
bb269:
  %t1588 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t1589 = extractvalue { i64, ptr } %t1588, 0
  %t1590 = load { i64, ptr }, ptr %l644, !tbaa !27
  %t1591 = extractvalue { i64, ptr } %t1590, 0
  store i64 %t1591, ptr %l646, !tbaa !24
  %t1593 = load i64, ptr %l646, !tbaa !24
  %t1594 = icmp eq i64 %t1589, %t1593
  br i1 %t1594, label %bb270, label %bb271
bb270:
  %t1596 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t1597 = load ptr, ptr %t1596, !tbaa !27
  %t1598 = getelementptr { i64, ptr }, ptr %l644, i32 0, i32 1
  %t1599 = load ptr, ptr %t1598, !tbaa !27
  %t1600 = load i64, ptr %l646, !tbaa !24
  %t1601 = mul i64 %t1600, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1597, ptr %t1599, i64 %t1601, i1 false)
  br label %bb272
bb271:
  %t1602 = load { i64, ptr }, ptr %l644, !tbaa !27
  store { i64, ptr } %t1602, ptr %l63, !tbaa !27
  br label %bb272
bb272:
  call void @__olang_scope_close(ptr %s65)
  br label %bb273
bb273:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d214, i32 0, i32 1) }, ptr %l648, !tbaa !27
  %t1603 = load { i64, ptr }, ptr %l648, !tbaa !27
  store { i64, ptr } %t1603, ptr %l649, !tbaa !27
  %t1604 = load { i64, ptr }, ptr %l649, !tbaa !27
  %t1605 = extractvalue { i64, ptr } %t1604, 0
  store i64 %t1605, ptr %l650, !tbaa !24
  %t1606 = load i64, ptr %l650, !tbaa !24
  %t1607 = mul i64 %t1606, 1
  %t1608 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t1607)
  %t1609 = insertvalue { i64, ptr } undef, i64 %t1606, 0
  %t1610 = insertvalue { i64, ptr } %t1609, ptr %t1608, 1
  store { i64, ptr } %t1610, ptr %l651, !tbaa !27
  %t1611 = getelementptr { i64, ptr }, ptr %l651, i32 0, i32 1
  %t1612 = load ptr, ptr %t1611, !tbaa !27
  %t1613 = getelementptr { i64, ptr }, ptr %l649, i32 0, i32 1
  %t1614 = load ptr, ptr %t1613, !tbaa !27
  %t1615 = load i64, ptr %l650, !tbaa !24
  %t1616 = mul i64 %t1615, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1612, ptr %t1614, i64 %t1616, i1 false)
  %t1617 = load { i64, ptr }, ptr %l651, !tbaa !27
  store { i64, ptr } %t1617, ptr %l73, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d215, i32 0, i32 1) }, ptr %l652, !tbaa !27
  %t1618 = load { i64, ptr }, ptr %l652, !tbaa !27
  store { i64, ptr } %t1618, ptr %l653, !tbaa !27
  %t1619 = load { i64, ptr }, ptr %l653, !tbaa !27
  %t1620 = extractvalue { i64, ptr } %t1619, 0
  store i64 %t1620, ptr %l654, !tbaa !24
  %t1621 = load i64, ptr %l654, !tbaa !24
  %t1622 = mul i64 %t1621, 1
  %t1623 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t1622)
  %t1624 = insertvalue { i64, ptr } undef, i64 %t1621, 0
  %t1625 = insertvalue { i64, ptr } %t1624, ptr %t1623, 1
  store { i64, ptr } %t1625, ptr %l655, !tbaa !27
  %t1626 = getelementptr { i64, ptr }, ptr %l655, i32 0, i32 1
  %t1627 = load ptr, ptr %t1626, !tbaa !27
  %t1628 = getelementptr { i64, ptr }, ptr %l653, i32 0, i32 1
  %t1629 = load ptr, ptr %t1628, !tbaa !27
  %t1630 = load i64, ptr %l654, !tbaa !24
  %t1631 = mul i64 %t1630, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1627, ptr %t1629, i64 %t1631, i1 false)
  %t1632 = load { i64, ptr }, ptr %l655, !tbaa !27
  store { i64, ptr } %t1632, ptr %l74, !tbaa !27
  %t1633 = load i1, ptr %l14, !tbaa !21
  br i1 %t1633, label %bb274, label %bb275
bb274:
  store %olang.scope zeroinitializer, ptr %s67
  %t1635 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t1637 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s67, { i64, ptr } %t1635, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d216, i32 0, i32 1) })
  store i1 %t1637, ptr %l658
  br label %bb276
bb275:
  store %olang.scope zeroinitializer, ptr %s71
  %t1638 = load i1, ptr %l13, !tbaa !21
  br i1 %t1638, label %bb298, label %bb299
bb276:
  %t1640 = load i1, ptr %l658, !tbaa !21
  %t1641 = xor i1 %t1640, true
  br i1 %t1641, label %bb277, label %bb278
bb277:
  store i1 true, ptr %l660, !tbaa !21
  br label %bb279
bb278:
  %t1643 = load i1, ptr %l13, !tbaa !21
  %t1645 = xor i1 %t1643, true
  store i1 %t1645, ptr %l660, !tbaa !21
  br label %bb279
bb279:
  %t1647 = load i1, ptr %l660, !tbaa !21
  br i1 %t1647, label %bb280, label %bb281
bb280:
  %t1648 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t1648, ptr %l663, !tbaa !27
  br label %bb283
bb281:
  %t1650 = load ptr, ptr %l11, !tbaa !29
  %t1651 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t1652 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t1653 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d217, i32 0, i32 1) }, 1
  %t1654 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d217, i32 0, i32 1) }, 0
  %t1656 = extractvalue { i64, ptr } %t1651, 1
  %t1657 = extractvalue { i64, ptr } %t1651, 0
  %t1658 = add i64 %t1654, %t1657
  %t1659 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d218, i32 0, i32 1) }, 1
  %t1660 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d218, i32 0, i32 1) }, 0
  %t1661 = add i64 %t1658, %t1660
  %t1663 = extractvalue { i64, ptr } %t1652, 1
  %t1664 = extractvalue { i64, ptr } %t1652, 0
  %t1665 = add i64 %t1661, %t1664
  %t1666 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d219, i32 0, i32 1) }, 1
  %t1667 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d219, i32 0, i32 1) }, 0
  %t1668 = add i64 %t1665, %t1667
  %t1669 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1668)
  call void @olang_textcopy(ptr %t1669, ptr %t1653, i64 %t1654)
  %t1670 = getelementptr i8, ptr %t1669, i64 %t1654
  call void @olang_textcopy(ptr %t1670, ptr %t1656, i64 %t1657)
  %t1671 = getelementptr i8, ptr %t1670, i64 %t1657
  call void @olang_textcopy(ptr %t1671, ptr %t1659, i64 %t1660)
  %t1672 = getelementptr i8, ptr %t1671, i64 %t1660
  call void @olang_textcopy(ptr %t1672, ptr %t1663, i64 %t1664)
  %t1673 = getelementptr i8, ptr %t1672, i64 %t1664
  call void @olang_textcopy(ptr %t1673, ptr %t1666, i64 %t1667)
  %t1674 = insertvalue { i64, ptr } undef, i64 %t1668, 0
  %t1675 = insertvalue { i64, ptr } %t1674, ptr %t1669, 1
  %t1677 = extractvalue { i64, ptr } %t1675, 0
  %t1678 = extractvalue { i64, ptr } %t1675, 1
  %t1679 = mul i64 %t1677, 1
  %t1680 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1679)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1680, ptr %t1678, i64 %t1679, i1 false)
  %t1681 = insertvalue { i64, ptr } undef, i64 %t1677, 0
  %t1682 = insertvalue { i64, ptr } %t1681, ptr %t1680, 1
  %t1685 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t1650, { i64, ptr } %t1682)
  store { i64, ptr } %t1685, ptr %l670
  br label %bb282
bb282:
  %t1686 = load { i64, ptr }, ptr %l670, !tbaa !27
  store { i64, ptr } %t1686, ptr %l663, !tbaa !27
  br label %bb283
bb283:
  %t1687 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t1688 = extractvalue { i64, ptr } %t1687, 0
  %t1689 = load { i64, ptr }, ptr %l663, !tbaa !27
  %t1690 = extractvalue { i64, ptr } %t1689, 0
  store i64 %t1690, ptr %l672, !tbaa !24
  %t1692 = load i64, ptr %l672, !tbaa !24
  %t1693 = icmp eq i64 %t1688, %t1692
  br i1 %t1693, label %bb284, label %bb285
bb284:
  %t1695 = getelementptr { i64, ptr }, ptr %l73, i32 0, i32 1
  %t1696 = load ptr, ptr %t1695, !tbaa !27
  %t1697 = getelementptr { i64, ptr }, ptr %l663, i32 0, i32 1
  %t1698 = load ptr, ptr %t1697, !tbaa !27
  %t1699 = load i64, ptr %l672, !tbaa !24
  %t1700 = mul i64 %t1699, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1696, ptr %t1698, i64 %t1700, i1 false)
  br label %bb286
bb285:
  %t1701 = load { i64, ptr }, ptr %l663, !tbaa !27
  store { i64, ptr } %t1701, ptr %l73, !tbaa !27
  br label %bb286
bb286:
  %t1702 = load i1, ptr %l13, !tbaa !21
  br i1 %t1702, label %bb287, label %bb288
bb287:
  %t1704 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t1706 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s67, { i64, ptr } %t1704, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d220, i32 0, i32 1) })
  store i1 %t1706, ptr %l677
  br label %bb289
bb288:
  store i1 false, ptr %l675, !tbaa !21
  br label %bb290
bb289:
  %t1707 = load i1, ptr %l677, !tbaa !21
  store i1 %t1707, ptr %l675, !tbaa !21
  br label %bb290
bb290:
  %t1708 = load i1, ptr %l675, !tbaa !21
  br i1 %t1708, label %bb291, label %bb292
bb291:
  %t1709 = load ptr, ptr %l11, !tbaa !29
  %t1710 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t1711 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t1712 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d221, i32 0, i32 1) }, 1
  %t1713 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d221, i32 0, i32 1) }, 0
  %t1715 = extractvalue { i64, ptr } %t1710, 1
  %t1716 = extractvalue { i64, ptr } %t1710, 0
  %t1717 = add i64 %t1713, %t1716
  %t1718 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d222, i32 0, i32 1) }, 1
  %t1719 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d222, i32 0, i32 1) }, 0
  %t1720 = add i64 %t1717, %t1719
  %t1722 = extractvalue { i64, ptr } %t1711, 1
  %t1723 = extractvalue { i64, ptr } %t1711, 0
  %t1724 = add i64 %t1720, %t1723
  %t1725 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d223, i32 0, i32 1) }, 1
  %t1726 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d223, i32 0, i32 1) }, 0
  %t1727 = add i64 %t1724, %t1726
  %t1728 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1727)
  call void @olang_textcopy(ptr %t1728, ptr %t1712, i64 %t1713)
  %t1729 = getelementptr i8, ptr %t1728, i64 %t1713
  call void @olang_textcopy(ptr %t1729, ptr %t1715, i64 %t1716)
  %t1730 = getelementptr i8, ptr %t1729, i64 %t1716
  call void @olang_textcopy(ptr %t1730, ptr %t1718, i64 %t1719)
  %t1731 = getelementptr i8, ptr %t1730, i64 %t1719
  call void @olang_textcopy(ptr %t1731, ptr %t1722, i64 %t1723)
  %t1732 = getelementptr i8, ptr %t1731, i64 %t1723
  call void @olang_textcopy(ptr %t1732, ptr %t1725, i64 %t1726)
  %t1733 = insertvalue { i64, ptr } undef, i64 %t1727, 0
  %t1734 = insertvalue { i64, ptr } %t1733, ptr %t1728, 1
  %t1736 = extractvalue { i64, ptr } %t1734, 0
  %t1737 = extractvalue { i64, ptr } %t1734, 1
  %t1738 = mul i64 %t1736, 1
  %t1739 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1738)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1739, ptr %t1737, i64 %t1738, i1 false)
  %t1740 = insertvalue { i64, ptr } undef, i64 %t1736, 0
  %t1741 = insertvalue { i64, ptr } %t1740, ptr %t1739, 1
  %t1744 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t1709, { i64, ptr } %t1741)
  store { i64, ptr } %t1744, ptr %l683
  br label %bb293
bb292:
  br label %bb297
bb293:
  %t1745 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t1746 = extractvalue { i64, ptr } %t1745, 0
  %t1747 = load { i64, ptr }, ptr %l683, !tbaa !27
  %t1748 = extractvalue { i64, ptr } %t1747, 0
  store i64 %t1748, ptr %l685, !tbaa !24
  %t1750 = load i64, ptr %l685, !tbaa !24
  %t1751 = icmp eq i64 %t1746, %t1750
  br i1 %t1751, label %bb294, label %bb295
bb294:
  %t1753 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t1754 = load ptr, ptr %t1753, !tbaa !27
  %t1755 = getelementptr { i64, ptr }, ptr %l683, i32 0, i32 1
  %t1756 = load ptr, ptr %t1755, !tbaa !27
  %t1757 = load i64, ptr %l685, !tbaa !24
  %t1758 = mul i64 %t1757, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1754, ptr %t1756, i64 %t1758, i1 false)
  br label %bb296
bb295:
  %t1759 = load { i64, ptr }, ptr %l683, !tbaa !27
  store { i64, ptr } %t1759, ptr %l74, !tbaa !27
  br label %bb296
bb296:
  br label %bb297
bb297:
  call void @__olang_scope_close(ptr %s67)
  br label %bb308
bb298:
  %t1760 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t1762 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s71, { i64, ptr } %t1760, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d224, i32 0, i32 1) })
  store i1 %t1762, ptr %l690
  br label %bb300
bb299:
  store i1 false, ptr %l688, !tbaa !21
  br label %bb301
bb300:
  %t1763 = load i1, ptr %l690, !tbaa !21
  store i1 %t1763, ptr %l688, !tbaa !21
  br label %bb301
bb301:
  %t1764 = load i1, ptr %l688, !tbaa !21
  br i1 %t1764, label %bb302, label %bb303
bb302:
  %t1765 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t1765, ptr %l691, !tbaa !27
  %t1766 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t1767 = extractvalue { i64, ptr } %t1766, 0
  %t1768 = load { i64, ptr }, ptr %l691, !tbaa !27
  %t1769 = extractvalue { i64, ptr } %t1768, 0
  store i64 %t1769, ptr %l693, !tbaa !24
  %t1771 = load i64, ptr %l693, !tbaa !24
  %t1772 = icmp eq i64 %t1767, %t1771
  br i1 %t1772, label %bb304, label %bb305
bb303:
  br label %bb307
bb304:
  %t1774 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t1775 = load ptr, ptr %t1774, !tbaa !27
  %t1776 = getelementptr { i64, ptr }, ptr %l691, i32 0, i32 1
  %t1777 = load ptr, ptr %t1776, !tbaa !27
  %t1778 = load i64, ptr %l693, !tbaa !24
  %t1779 = mul i64 %t1778, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1775, ptr %t1777, i64 %t1779, i1 false)
  br label %bb306
bb305:
  %t1780 = load { i64, ptr }, ptr %l691, !tbaa !27
  %t1781 = extractvalue { i64, ptr } %t1780, 0
  store i64 %t1781, ptr %l695, !tbaa !24
  %t1782 = load i64, ptr %l695, !tbaa !24
  %t1783 = mul i64 %t1782, 1
  %t1784 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t1783)
  %t1785 = insertvalue { i64, ptr } undef, i64 %t1782, 0
  %t1786 = insertvalue { i64, ptr } %t1785, ptr %t1784, 1
  store { i64, ptr } %t1786, ptr %l696, !tbaa !27
  %t1787 = getelementptr { i64, ptr }, ptr %l696, i32 0, i32 1
  %t1788 = load ptr, ptr %t1787, !tbaa !27
  %t1789 = getelementptr { i64, ptr }, ptr %l691, i32 0, i32 1
  %t1790 = load ptr, ptr %t1789, !tbaa !27
  %t1791 = load i64, ptr %l695, !tbaa !24
  %t1792 = mul i64 %t1791, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1788, ptr %t1790, i64 %t1792, i1 false)
  %t1793 = load { i64, ptr }, ptr %l696, !tbaa !27
  store { i64, ptr } %t1793, ptr %l74, !tbaa !27
  br label %bb306
bb306:
  br label %bb307
bb307:
  call void @__olang_scope_close(ptr %s71)
  br label %bb308
bb308:
  %t1794 = load i1, ptr %l13, !tbaa !21
  br i1 %t1794, label %bb309, label %bb310
bb309:
  %t1796 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t1798 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t1796, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d225, i32 0, i32 1) })
  store i1 %t1798, ptr %l700
  br label %bb311
bb310:
  store i1 false, ptr %l698, !tbaa !21
  br label %bb312
bb311:
  %t1799 = load i1, ptr %l700, !tbaa !21
  %t1800 = xor i1 %t1799, true
  store i1 %t1800, ptr %l698, !tbaa !21
  br label %bb312
bb312:
  %t1802 = load i1, ptr %l698, !tbaa !21
  br i1 %t1802, label %bb313, label %bb314
bb313:
  %t1803 = load ptr, ptr %l11, !tbaa !29
  store ptr %t1803, ptr %l702, !tbaa !29
  %t1804 = load ptr, ptr %l0, !tbaa !29
  %t1805 = load i32, ptr %l12, !tbaa !23
  %t1808 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %s0, ptr %t1804, i32 %t1805)
  store { i64, ptr } %t1808, ptr %l705
  br label %bb315
bb314:
  br label %bb320
bb315:
  %t1809 = load { i64, ptr }, ptr %l705, !tbaa !27
  %t1810 = extractvalue { i64, ptr } %t1809, 0
  %t1811 = extractvalue { i64, ptr } %t1809, 1
  %t1812 = mul i64 %t1810, 1
  %t1813 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1812)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1813, ptr %t1811, i64 %t1812, i1 false)
  %t1814 = insertvalue { i64, ptr } undef, i64 %t1810, 0
  %t1815 = insertvalue { i64, ptr } %t1814, ptr %t1813, 1
  %t1816 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t1817 = load ptr, ptr %l702, !tbaa !29
  %t1820 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %t1817, { i64, ptr } %t1815, { i64, ptr } %t1816, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d179, i32 0, i32 1) })
  store { i64, ptr } %t1820, ptr %l708
  br label %bb316
bb316:
  %t1821 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t1822 = extractvalue { i64, ptr } %t1821, 0
  %t1823 = load { i64, ptr }, ptr %l708, !tbaa !27
  %t1824 = extractvalue { i64, ptr } %t1823, 0
  store i64 %t1824, ptr %l710, !tbaa !24
  %t1826 = load i64, ptr %l710, !tbaa !24
  %t1827 = icmp eq i64 %t1822, %t1826
  br i1 %t1827, label %bb317, label %bb318
bb317:
  %t1829 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t1830 = load ptr, ptr %t1829, !tbaa !27
  %t1831 = getelementptr { i64, ptr }, ptr %l708, i32 0, i32 1
  %t1832 = load ptr, ptr %t1831, !tbaa !27
  %t1833 = load i64, ptr %l710, !tbaa !24
  %t1834 = mul i64 %t1833, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1830, ptr %t1832, i64 %t1834, i1 false)
  br label %bb319
bb318:
  %t1835 = load { i64, ptr }, ptr %l708, !tbaa !27
  store { i64, ptr } %t1835, ptr %l74, !tbaa !27
  br label %bb319
bb319:
  br label %bb320
bb320:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d226, i32 0, i32 1) }, ptr %l712, !tbaa !27
  %t1836 = load { i64, ptr }, ptr %l712, !tbaa !27
  store { i64, ptr } %t1836, ptr %l713, !tbaa !27
  %t1837 = load { i64, ptr }, ptr %l713, !tbaa !27
  %t1838 = extractvalue { i64, ptr } %t1837, 0
  store i64 %t1838, ptr %l714, !tbaa !24
  %t1839 = load i64, ptr %l714, !tbaa !24
  %t1840 = mul i64 %t1839, 1
  %t1841 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t1840)
  %t1842 = insertvalue { i64, ptr } undef, i64 %t1839, 0
  %t1843 = insertvalue { i64, ptr } %t1842, ptr %t1841, 1
  store { i64, ptr } %t1843, ptr %l715, !tbaa !27
  %t1844 = getelementptr { i64, ptr }, ptr %l715, i32 0, i32 1
  %t1845 = load ptr, ptr %t1844, !tbaa !27
  %t1846 = getelementptr { i64, ptr }, ptr %l713, i32 0, i32 1
  %t1847 = load ptr, ptr %t1846, !tbaa !27
  %t1848 = load i64, ptr %l714, !tbaa !24
  %t1849 = mul i64 %t1848, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1845, ptr %t1847, i64 %t1849, i1 false)
  %t1850 = load { i64, ptr }, ptr %l715, !tbaa !27
  store { i64, ptr } %t1850, ptr %l75, !tbaa !27
  %t1851 = load i1, ptr %l14, !tbaa !21
  br i1 %t1851, label %bb321, label %bb322
bb321:
  store %olang.scope zeroinitializer, ptr %s74
  %t1853 = load ptr, ptr %l11, !tbaa !29
  %t1854 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t1855 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d227, i32 0, i32 1) }, 1
  %t1856 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d227, i32 0, i32 1) }, 0
  %t1858 = extractvalue { i64, ptr } %t1854, 1
  %t1859 = extractvalue { i64, ptr } %t1854, 0
  %t1860 = add i64 %t1856, %t1859
  %t1861 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d228, i32 0, i32 1) }, 1
  %t1862 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d228, i32 0, i32 1) }, 0
  %t1863 = add i64 %t1860, %t1862
  %t1864 = call ptr @__olang_scope_alloc(ptr %s74, i64 %t1863)
  call void @olang_textcopy(ptr %t1864, ptr %t1855, i64 %t1856)
  %t1865 = getelementptr i8, ptr %t1864, i64 %t1856
  call void @olang_textcopy(ptr %t1865, ptr %t1858, i64 %t1859)
  %t1866 = getelementptr i8, ptr %t1865, i64 %t1859
  call void @olang_textcopy(ptr %t1866, ptr %t1861, i64 %t1862)
  %t1867 = insertvalue { i64, ptr } undef, i64 %t1863, 0
  %t1868 = insertvalue { i64, ptr } %t1867, ptr %t1864, 1
  %t1870 = extractvalue { i64, ptr } %t1868, 0
  %t1871 = extractvalue { i64, ptr } %t1868, 1
  %t1872 = mul i64 %t1870, 1
  %t1873 = call ptr @__olang_scope_alloc(ptr %s74, i64 %t1872)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1873, ptr %t1871, i64 %t1872, i1 false)
  %t1874 = insertvalue { i64, ptr } undef, i64 %t1870, 0
  %t1875 = insertvalue { i64, ptr } %t1874, ptr %t1873, 1
  %t1878 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s74, ptr %s74, ptr %t1853, { i64, ptr } %t1875)
  store { i64, ptr } %t1878, ptr %l721
  br label %bb323
bb322:
  br label %bb334
bb323:
  %t1879 = load { i64, ptr }, ptr %l721, !tbaa !27
  %t1880 = load ptr, ptr %l11, !tbaa !29
  %t1882 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d229, i32 0, i32 1) }, 1
  %t1883 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d229, i32 0, i32 1) }, 0
  %t1885 = extractvalue { i64, ptr } %t1879, 1
  %t1886 = extractvalue { i64, ptr } %t1879, 0
  %t1887 = add i64 %t1883, %t1886
  %t1888 = extractvalue { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d230, i32 0, i32 1) }, 1
  %t1889 = extractvalue { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d230, i32 0, i32 1) }, 0
  %t1890 = add i64 %t1887, %t1889
  %t1891 = call ptr @__olang_scope_alloc(ptr %s74, i64 %t1890)
  call void @olang_textcopy(ptr %t1891, ptr %t1882, i64 %t1883)
  %t1892 = getelementptr i8, ptr %t1891, i64 %t1883
  call void @olang_textcopy(ptr %t1892, ptr %t1885, i64 %t1886)
  %t1893 = getelementptr i8, ptr %t1892, i64 %t1886
  call void @olang_textcopy(ptr %t1893, ptr %t1888, i64 %t1889)
  %t1894 = insertvalue { i64, ptr } undef, i64 %t1890, 0
  %t1895 = insertvalue { i64, ptr } %t1894, ptr %t1891, 1
  %t1897 = extractvalue { i64, ptr } %t1895, 0
  %t1898 = extractvalue { i64, ptr } %t1895, 1
  %t1899 = mul i64 %t1897, 1
  %t1900 = call ptr @__olang_scope_alloc(ptr %s74, i64 %t1899)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1900, ptr %t1898, i64 %t1899, i1 false)
  %t1901 = insertvalue { i64, ptr } undef, i64 %t1897, 0
  %t1902 = insertvalue { i64, ptr } %t1901, ptr %t1900, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s74, ptr %t1880, { i64, ptr } %t1902)
  br label %bb324
bb324:
  %t1905 = load ptr, ptr %l11, !tbaa !29
  %t1907 = getelementptr %"compiler/emit:fnEm", ptr %t1905, i32 0, i32 5
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s74, ptr %t1907, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d231, i32 0, i32 1) })
  br label %bb325
bb325:
  %t1909 = load ptr, ptr %l11, !tbaa !29
  %t1910 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t1911 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d232, i32 0, i32 1) }, 1
  %t1912 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d232, i32 0, i32 1) }, 0
  %t1914 = extractvalue { i64, ptr } %t1910, 1
  %t1915 = extractvalue { i64, ptr } %t1910, 0
  %t1916 = add i64 %t1912, %t1915
  %t1917 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d233, i32 0, i32 1) }, 1
  %t1918 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d233, i32 0, i32 1) }, 0
  %t1919 = add i64 %t1916, %t1918
  %t1920 = call ptr @__olang_scope_alloc(ptr %s74, i64 %t1919)
  call void @olang_textcopy(ptr %t1920, ptr %t1911, i64 %t1912)
  %t1921 = getelementptr i8, ptr %t1920, i64 %t1912
  call void @olang_textcopy(ptr %t1921, ptr %t1914, i64 %t1915)
  %t1922 = getelementptr i8, ptr %t1921, i64 %t1915
  call void @olang_textcopy(ptr %t1922, ptr %t1917, i64 %t1918)
  %t1923 = insertvalue { i64, ptr } undef, i64 %t1919, 0
  %t1924 = insertvalue { i64, ptr } %t1923, ptr %t1920, 1
  %t1926 = extractvalue { i64, ptr } %t1924, 0
  %t1927 = extractvalue { i64, ptr } %t1924, 1
  %t1928 = mul i64 %t1926, 1
  %t1929 = call ptr @__olang_scope_alloc(ptr %s74, i64 %t1928)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1929, ptr %t1927, i64 %t1928, i1 false)
  %t1930 = insertvalue { i64, ptr } undef, i64 %t1926, 0
  %t1931 = insertvalue { i64, ptr } %t1930, ptr %t1929, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s74, ptr %t1909, { i64, ptr } %t1931)
  br label %bb326
bb326:
  %t1934 = load ptr, ptr %l2, !tbaa !29
  store ptr %t1934, ptr %l732, !tbaa !29
  %t1935 = load ptr, ptr %l0, !tbaa !29
  %t1937 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2femit_2ecompiler_2femit_3aEmitter_2eExportErrors(ptr %v0, ptr %s74, ptr %t1935)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1937, ptr %l734
  br label %bb327
bb327:
  %t1938 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l734
  %t1939 = call ptr @__olang_scope_alloc_a(ptr %s74, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1938, ptr %t1939
  %t1941 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eToAr_H9d0f958437b2bc29fe1d416dfb9901d7(ptr %s74, ptr %s74, ptr %t1939)
  store { i64, ptr } %t1941, ptr %l736
  br label %bb328
bb328:
  %t1942 = load ptr, ptr %l732, !tbaa !29
  %t1943 = load { i64, ptr }, ptr %l736, !tbaa !27
  %t1944 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s74, ptr %t1942, { i64, ptr } %t1943)
  store i32 %t1944, ptr %l737
  br label %bb329
bb329:
  %t1945 = load i32, ptr %l737, !tbaa !23
  store i32 %t1945, ptr %l77, !tbaa !23
  %t1946 = load ptr, ptr %l11, !tbaa !29
  store ptr %t1946, ptr %l738, !tbaa !29
  %t1947 = load ptr, ptr %l11, !tbaa !29
  store ptr %t1947, ptr %l739, !tbaa !29
  %t1948 = load { i64, ptr }, ptr %l73, !tbaa !27
  store { i64, ptr } %t1948, ptr %l740, !tbaa !27
  %t1949 = load ptr, ptr %l2, !tbaa !29
  %t1950 = load i32, ptr %l9, !tbaa !23
  %t1953 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t1949, i32 %t1950)
  store i32 %t1953, ptr %l743
  br label %bb330
bb330:
  %t1954 = load i32, ptr %l77, !tbaa !23
  %t1955 = load ptr, ptr %l739, !tbaa !29
  %t1956 = load { i64, ptr }, ptr %l740, !tbaa !27
  %t1957 = load i32, ptr %l743, !tbaa !23
  %t1959 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2erecode(ptr %v0, ptr %s0, ptr %s74, ptr %t1955, { i64, ptr } %t1956, i32 %t1957, i32 %t1954)
  store { i64, ptr } %t1959, ptr %l745
  br label %bb331
bb331:
  %t1960 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d234, i32 0, i32 1) }, 1
  %t1961 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d234, i32 0, i32 1) }, 0
  %t1962 = load { i64, ptr }, ptr %l745, !tbaa !27
  %t1963 = extractvalue { i64, ptr } %t1962, 1
  %t1964 = extractvalue { i64, ptr } %t1962, 0
  %t1965 = add i64 %t1961, %t1964
  %t1966 = call ptr @__olang_scope_alloc(ptr %s74, i64 %t1965)
  call void @olang_textcopy(ptr %t1966, ptr %t1960, i64 %t1961)
  %t1967 = getelementptr i8, ptr %t1966, i64 %t1961
  call void @olang_textcopy(ptr %t1967, ptr %t1963, i64 %t1964)
  %t1968 = insertvalue { i64, ptr } undef, i64 %t1965, 0
  %t1969 = insertvalue { i64, ptr } %t1968, ptr %t1966, 1
  %t1971 = extractvalue { i64, ptr } %t1969, 0
  %t1972 = extractvalue { i64, ptr } %t1969, 1
  %t1973 = mul i64 %t1971, 1
  %t1974 = call ptr @__olang_scope_alloc(ptr %s74, i64 %t1973)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1974, ptr %t1972, i64 %t1973, i1 false)
  %t1975 = insertvalue { i64, ptr } undef, i64 %t1971, 0
  %t1976 = insertvalue { i64, ptr } %t1975, ptr %t1974, 1
  %t1977 = load ptr, ptr %l738, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s74, ptr %t1977, { i64, ptr } %t1976)
  br label %bb332
bb332:
  %t1979 = load ptr, ptr %l11, !tbaa !29
  %t1981 = getelementptr %"compiler/emit:fnEm", ptr %t1979, i32 0, i32 5
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s74, ptr %t1981, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d235, i32 0, i32 1) })
  br label %bb333
bb333:
  call void @__olang_scope_close(ptr %s74)
  br label %bb334
bb334:
  %t1983 = load i1, ptr %l15, !tbaa !21
  br i1 %t1983, label %bb335, label %bb336
bb335:
  store %olang.scope zeroinitializer, ptr %s79
  %t1985 = load ptr, ptr %l11, !tbaa !29
  %t1986 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t1987 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d236, i32 0, i32 1) }, 1
  %t1988 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d236, i32 0, i32 1) }, 0
  %t1990 = extractvalue { i64, ptr } %t1986, 1
  %t1991 = extractvalue { i64, ptr } %t1986, 0
  %t1992 = add i64 %t1988, %t1991
  %t1993 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d237, i32 0, i32 1) }, 1
  %t1994 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d237, i32 0, i32 1) }, 0
  %t1995 = add i64 %t1992, %t1994
  %t1996 = call ptr @__olang_scope_alloc(ptr %s79, i64 %t1995)
  call void @olang_textcopy(ptr %t1996, ptr %t1987, i64 %t1988)
  %t1997 = getelementptr i8, ptr %t1996, i64 %t1988
  call void @olang_textcopy(ptr %t1997, ptr %t1990, i64 %t1991)
  %t1998 = getelementptr i8, ptr %t1997, i64 %t1991
  call void @olang_textcopy(ptr %t1998, ptr %t1993, i64 %t1994)
  %t1999 = insertvalue { i64, ptr } undef, i64 %t1995, 0
  %t2000 = insertvalue { i64, ptr } %t1999, ptr %t1996, 1
  %t2002 = extractvalue { i64, ptr } %t2000, 0
  %t2003 = extractvalue { i64, ptr } %t2000, 1
  %t2004 = mul i64 %t2002, 1
  %t2005 = call ptr @__olang_scope_alloc(ptr %s79, i64 %t2004)
  call void @llvm.memcpy.p0.p0.i64(ptr %t2005, ptr %t2003, i64 %t2004, i1 false)
  %t2006 = insertvalue { i64, ptr } undef, i64 %t2002, 0
  %t2007 = insertvalue { i64, ptr } %t2006, ptr %t2005, 1
  %t2010 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s79, ptr %s79, ptr %t1985, { i64, ptr } %t2007)
  store { i64, ptr } %t2010, ptr %l755
  br label %bb337
bb336:
  %t2011 = load i1, ptr %l14, !tbaa !21
  br i1 %t2011, label %bb360, label %bb361
bb337:
  %t2013 = load { i64, ptr }, ptr %l755, !tbaa !27
  store { i64, ptr } %t2013, ptr %l78, !tbaa !27
  %t2014 = load ptr, ptr %l11, !tbaa !29
  %t2015 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t2016 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d238, i32 0, i32 1) }, 1
  %t2017 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d238, i32 0, i32 1) }, 0
  %t2019 = extractvalue { i64, ptr } %t2015, 1
  %t2020 = extractvalue { i64, ptr } %t2015, 0
  %t2021 = add i64 %t2017, %t2020
  %t2022 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d239, i32 0, i32 1) }, 1
  %t2023 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d239, i32 0, i32 1) }, 0
  %t2024 = add i64 %t2021, %t2023
  %t2025 = call ptr @__olang_scope_alloc(ptr %s79, i64 %t2024)
  call void @olang_textcopy(ptr %t2025, ptr %t2016, i64 %t2017)
  %t2026 = getelementptr i8, ptr %t2025, i64 %t2017
  call void @olang_textcopy(ptr %t2026, ptr %t2019, i64 %t2020)
  %t2027 = getelementptr i8, ptr %t2026, i64 %t2020
  call void @olang_textcopy(ptr %t2027, ptr %t2022, i64 %t2023)
  %t2028 = insertvalue { i64, ptr } undef, i64 %t2024, 0
  %t2029 = insertvalue { i64, ptr } %t2028, ptr %t2025, 1
  %t2031 = extractvalue { i64, ptr } %t2029, 0
  %t2032 = extractvalue { i64, ptr } %t2029, 1
  %t2033 = mul i64 %t2031, 1
  %t2034 = call ptr @__olang_scope_alloc(ptr %s79, i64 %t2033)
  call void @llvm.memcpy.p0.p0.i64(ptr %t2034, ptr %t2032, i64 %t2033, i1 false)
  %t2035 = insertvalue { i64, ptr } undef, i64 %t2031, 0
  %t2036 = insertvalue { i64, ptr } %t2035, ptr %t2034, 1
  %t2039 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s79, ptr %s79, ptr %t2014, { i64, ptr } %t2036)
  store { i64, ptr } %t2039, ptr %l760
  br label %bb338
bb338:
  %t2040 = load { i64, ptr }, ptr %l760, !tbaa !27
  store { i64, ptr } %t2040, ptr %l79, !tbaa !27
  %t2041 = load ptr, ptr %l11, !tbaa !29
  %t2042 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t2043 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d240, i32 0, i32 1) }, 1
  %t2044 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d240, i32 0, i32 1) }, 0
  %t2046 = extractvalue { i64, ptr } %t2042, 1
  %t2047 = extractvalue { i64, ptr } %t2042, 0
  %t2048 = add i64 %t2044, %t2047
  %t2049 = call ptr @__olang_scope_alloc(ptr %s79, i64 %t2048)
  call void @olang_textcopy(ptr %t2049, ptr %t2043, i64 %t2044)
  %t2050 = getelementptr i8, ptr %t2049, i64 %t2044
  call void @olang_textcopy(ptr %t2050, ptr %t2046, i64 %t2047)
  %t2051 = insertvalue { i64, ptr } undef, i64 %t2048, 0
  %t2052 = insertvalue { i64, ptr } %t2051, ptr %t2049, 1
  %t2054 = extractvalue { i64, ptr } %t2052, 0
  %t2055 = extractvalue { i64, ptr } %t2052, 1
  %t2056 = mul i64 %t2054, 1
  %t2057 = call ptr @__olang_scope_alloc(ptr %s79, i64 %t2056)
  call void @llvm.memcpy.p0.p0.i64(ptr %t2057, ptr %t2055, i64 %t2056, i1 false)
  %t2058 = insertvalue { i64, ptr } undef, i64 %t2054, 0
  %t2059 = insertvalue { i64, ptr } %t2058, ptr %t2057, 1
  %t2062 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s79, ptr %s79, ptr %t2041, { i64, ptr } %t2059)
  store { i64, ptr } %t2062, ptr %l765
  br label %bb339
bb339:
  %t2063 = load { i64, ptr }, ptr %l765, !tbaa !27
  %t2064 = load ptr, ptr %l11, !tbaa !29
  %t2066 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t2067 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d241, i32 0, i32 1) }, 1
  %t2068 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d241, i32 0, i32 1) }, 0
  %t2070 = extractvalue { i64, ptr } %t2063, 1
  %t2071 = extractvalue { i64, ptr } %t2063, 0
  %t2072 = add i64 %t2068, %t2071
  %t2073 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d242, i32 0, i32 1) }, 1
  %t2074 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d242, i32 0, i32 1) }, 0
  %t2075 = add i64 %t2072, %t2074
  %t2077 = extractvalue { i64, ptr } %t2066, 1
  %t2078 = extractvalue { i64, ptr } %t2066, 0
  %t2079 = add i64 %t2075, %t2078
  %t2080 = call ptr @__olang_scope_alloc(ptr %s79, i64 %t2079)
  call void @olang_textcopy(ptr %t2080, ptr %t2067, i64 %t2068)
  %t2081 = getelementptr i8, ptr %t2080, i64 %t2068
  call void @olang_textcopy(ptr %t2081, ptr %t2070, i64 %t2071)
  %t2082 = getelementptr i8, ptr %t2081, i64 %t2071
  call void @olang_textcopy(ptr %t2082, ptr %t2073, i64 %t2074)
  %t2083 = getelementptr i8, ptr %t2082, i64 %t2074
  call void @olang_textcopy(ptr %t2083, ptr %t2077, i64 %t2078)
  %t2084 = insertvalue { i64, ptr } undef, i64 %t2079, 0
  %t2085 = insertvalue { i64, ptr } %t2084, ptr %t2080, 1
  %t2087 = extractvalue { i64, ptr } %t2085, 0
  %t2088 = extractvalue { i64, ptr } %t2085, 1
  %t2089 = mul i64 %t2087, 1
  %t2090 = call ptr @__olang_scope_alloc(ptr %s79, i64 %t2089)
  call void @llvm.memcpy.p0.p0.i64(ptr %t2090, ptr %t2088, i64 %t2089, i1 false)
  %t2091 = insertvalue { i64, ptr } undef, i64 %t2087, 0
  %t2092 = insertvalue { i64, ptr } %t2091, ptr %t2090, 1
  %t2095 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s79, ptr %s79, ptr %t2064, { i64, ptr } %t2092)
  store { i64, ptr } %t2095, ptr %l771
  br label %bb340
bb340:
  %t2096 = load { i64, ptr }, ptr %l771, !tbaa !27
  store { i64, ptr } %t2096, ptr %l81, !tbaa !27
  %t2097 = load ptr, ptr %l11, !tbaa !29
  %t2098 = load { i64, ptr }, ptr %l81, !tbaa !27
  %t2099 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d243, i32 0, i32 1) }, 1
  %t2100 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d243, i32 0, i32 1) }, 0
  %t2102 = extractvalue { i64, ptr } %t2098, 1
  %t2103 = extractvalue { i64, ptr } %t2098, 0
  %t2104 = add i64 %t2100, %t2103
  %t2105 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d244, i32 0, i32 1) }, 1
  %t2106 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d244, i32 0, i32 1) }, 0
  %t2107 = add i64 %t2104, %t2106
  %t2108 = call ptr @__olang_scope_alloc(ptr %s79, i64 %t2107)
  call void @olang_textcopy(ptr %t2108, ptr %t2099, i64 %t2100)
  %t2109 = getelementptr i8, ptr %t2108, i64 %t2100
  call void @olang_textcopy(ptr %t2109, ptr %t2102, i64 %t2103)
  %t2110 = getelementptr i8, ptr %t2109, i64 %t2103
  call void @olang_textcopy(ptr %t2110, ptr %t2105, i64 %t2106)
  %t2111 = insertvalue { i64, ptr } undef, i64 %t2107, 0
  %t2112 = insertvalue { i64, ptr } %t2111, ptr %t2108, 1
  %t2114 = extractvalue { i64, ptr } %t2112, 0
  %t2115 = extractvalue { i64, ptr } %t2112, 1
  %t2116 = mul i64 %t2114, 1
  %t2117 = call ptr @__olang_scope_alloc(ptr %s79, i64 %t2116)
  call void @llvm.memcpy.p0.p0.i64(ptr %t2117, ptr %t2115, i64 %t2116, i1 false)
  %t2118 = insertvalue { i64, ptr } undef, i64 %t2114, 0
  %t2119 = insertvalue { i64, ptr } %t2118, ptr %t2117, 1
  %t2122 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s79, ptr %s79, ptr %t2097, { i64, ptr } %t2119)
  store { i64, ptr } %t2122, ptr %l776
  br label %bb341
bb341:
  %t2123 = load { i64, ptr }, ptr %l776, !tbaa !27
  %t2124 = load ptr, ptr %l11, !tbaa !29
  %t2126 = load { i64, ptr }, ptr %l81, !tbaa !27
  %t2127 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d245, i32 0, i32 1) }, 1
  %t2128 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d245, i32 0, i32 1) }, 0
  %t2130 = extractvalue { i64, ptr } %t2123, 1
  %t2131 = extractvalue { i64, ptr } %t2123, 0
  %t2132 = add i64 %t2128, %t2131
  %t2133 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d246, i32 0, i32 1) }, 1
  %t2134 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d246, i32 0, i32 1) }, 0
  %t2135 = add i64 %t2132, %t2134
  %t2137 = extractvalue { i64, ptr } %t2126, 1
  %t2138 = extractvalue { i64, ptr } %t2126, 0
  %t2139 = add i64 %t2135, %t2138
  %t2140 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d247, i32 0, i32 1) }, 1
  %t2141 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d247, i32 0, i32 1) }, 0
  %t2142 = add i64 %t2139, %t2141
  %t2143 = call ptr @__olang_scope_alloc(ptr %s79, i64 %t2142)
  call void @olang_textcopy(ptr %t2143, ptr %t2127, i64 %t2128)
  %t2144 = getelementptr i8, ptr %t2143, i64 %t2128
  call void @olang_textcopy(ptr %t2144, ptr %t2130, i64 %t2131)
  %t2145 = getelementptr i8, ptr %t2144, i64 %t2131
  call void @olang_textcopy(ptr %t2145, ptr %t2133, i64 %t2134)
  %t2146 = getelementptr i8, ptr %t2145, i64 %t2134
  call void @olang_textcopy(ptr %t2146, ptr %t2137, i64 %t2138)
  %t2147 = getelementptr i8, ptr %t2146, i64 %t2138
  call void @olang_textcopy(ptr %t2147, ptr %t2140, i64 %t2141)
  %t2148 = insertvalue { i64, ptr } undef, i64 %t2142, 0
  %t2149 = insertvalue { i64, ptr } %t2148, ptr %t2143, 1
  %t2151 = extractvalue { i64, ptr } %t2149, 0
  %t2152 = extractvalue { i64, ptr } %t2149, 1
  %t2153 = mul i64 %t2151, 1
  %t2154 = call ptr @__olang_scope_alloc(ptr %s79, i64 %t2153)
  call void @llvm.memcpy.p0.p0.i64(ptr %t2154, ptr %t2152, i64 %t2153, i1 false)
  %t2155 = insertvalue { i64, ptr } undef, i64 %t2151, 0
  %t2156 = insertvalue { i64, ptr } %t2155, ptr %t2154, 1
  %t2159 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s79, ptr %s79, ptr %t2124, { i64, ptr } %t2156)
  store { i64, ptr } %t2159, ptr %l782
  br label %bb342
bb342:
  %t2160 = load { i64, ptr }, ptr %l81, !tbaa !27
  %t2161 = extractvalue { i64, ptr } %t2160, 0
  %t2162 = load { i64, ptr }, ptr %l782, !tbaa !27
  %t2163 = extractvalue { i64, ptr } %t2162, 0
  store i64 %t2163, ptr %l784, !tbaa !24
  %t2165 = load i64, ptr %l784, !tbaa !24
  %t2166 = icmp eq i64 %t2161, %t2165
  br i1 %t2166, label %bb343, label %bb344
bb343:
  %t2168 = getelementptr { i64, ptr }, ptr %l81, i32 0, i32 1
  %t2169 = load ptr, ptr %t2168, !tbaa !27
  %t2170 = getelementptr { i64, ptr }, ptr %l782, i32 0, i32 1
  %t2171 = load ptr, ptr %t2170, !tbaa !27
  %t2172 = load i64, ptr %l784, !tbaa !24
  %t2173 = mul i64 %t2172, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t2169, ptr %t2171, i64 %t2173, i1 false)
  br label %bb345
bb344:
  %t2174 = load { i64, ptr }, ptr %l782, !tbaa !27
  store { i64, ptr } %t2174, ptr %l81, !tbaa !27
  br label %bb345
bb345:
  %t2175 = load ptr, ptr %l11, !tbaa !29
  store ptr %t2175, ptr %l786, !tbaa !29
  %t2176 = load { i64, ptr }, ptr %l81, !tbaa !27
  store { i64, ptr } %t2176, ptr %l787, !tbaa !27
  %t2177 = load ptr, ptr %l2, !tbaa !29
  %t2178 = load i32, ptr %l44, !tbaa !23
  %t2181 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSize(ptr %v0, ptr %t2177, i32 %t2178)
  store i64 %t2181, ptr %l790
  br label %bb346
bb346:
  %t2182 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d248, i32 0, i32 1) }, 1
  %t2183 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d248, i32 0, i32 1) }, 0
  %t2184 = load { i64, ptr }, ptr %l787, !tbaa !27
  %t2185 = extractvalue { i64, ptr } %t2184, 1
  %t2186 = extractvalue { i64, ptr } %t2184, 0
  %t2187 = add i64 %t2183, %t2186
  %t2188 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d249, i32 0, i32 1) }, 1
  %t2189 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d249, i32 0, i32 1) }, 0
  %t2190 = add i64 %t2187, %t2189
  %t2191 = load i64, ptr %l790, !tbaa !24
  %t2192 = call i64 @__olang_fmt_i64(ptr null, i64 %t2191)
  %t2193 = add i64 %t2190, %t2192
  %t2194 = call ptr @__olang_scope_alloc(ptr %s79, i64 %t2193)
  call void @olang_textcopy(ptr %t2194, ptr %t2182, i64 %t2183)
  %t2195 = getelementptr i8, ptr %t2194, i64 %t2183
  call void @olang_textcopy(ptr %t2195, ptr %t2185, i64 %t2186)
  %t2196 = getelementptr i8, ptr %t2195, i64 %t2186
  call void @olang_textcopy(ptr %t2196, ptr %t2188, i64 %t2189)
  %t2197 = getelementptr i8, ptr %t2196, i64 %t2189
  %t2198 = call i64 @__olang_fmt_i64(ptr %t2197, i64 %t2191)
  %t2199 = insertvalue { i64, ptr } undef, i64 %t2193, 0
  %t2200 = insertvalue { i64, ptr } %t2199, ptr %t2194, 1
  %t2202 = extractvalue { i64, ptr } %t2200, 0
  %t2203 = extractvalue { i64, ptr } %t2200, 1
  %t2204 = mul i64 %t2202, 1
  %t2205 = call ptr @__olang_scope_alloc(ptr %s79, i64 %t2204)
  call void @llvm.memcpy.p0.p0.i64(ptr %t2205, ptr %t2203, i64 %t2204, i1 false)
  %t2206 = insertvalue { i64, ptr } undef, i64 %t2202, 0
  %t2207 = insertvalue { i64, ptr } %t2206, ptr %t2205, 1
  %t2208 = load ptr, ptr %l786, !tbaa !29
  %t2210 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s79, ptr %s79, ptr %t2208, { i64, ptr } %t2207)
  store { i64, ptr } %t2210, ptr %l793
  br label %bb347
bb347:
  %t2211 = load { i64, ptr }, ptr %l793, !tbaa !27
  store { i64, ptr } %t2211, ptr %l83, !tbaa !27
  %t2212 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s79, ptr %s79, ptr %t2212, { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d250, i32 0, i32 1) }, { i64, ptr } { i64 47, ptr getelementptr inbounds (<{ i64, [47 x i8] }>, ptr @.d251, i32 0, i32 1) })
  br label %bb348
bb348:
  %t2214 = load ptr, ptr %l11, !tbaa !29
  %t2215 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t2216 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t2217 = extractvalue { i64, ptr } { i64 48, ptr getelementptr inbounds (<{ i64, [48 x i8] }>, ptr @.d252, i32 0, i32 1) }, 1
  %t2218 = extractvalue { i64, ptr } { i64 48, ptr getelementptr inbounds (<{ i64, [48 x i8] }>, ptr @.d252, i32 0, i32 1) }, 0
  %t2220 = extractvalue { i64, ptr } %t2215, 1
  %t2221 = extractvalue { i64, ptr } %t2215, 0
  %t2222 = add i64 %t2218, %t2221
  %t2223 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d253, i32 0, i32 1) }, 1
  %t2224 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d253, i32 0, i32 1) }, 0
  %t2225 = add i64 %t2222, %t2224
  %t2227 = extractvalue { i64, ptr } %t2216, 1
  %t2228 = extractvalue { i64, ptr } %t2216, 0
  %t2229 = add i64 %t2225, %t2228
  %t2230 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d254, i32 0, i32 1) }, 1
  %t2231 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d254, i32 0, i32 1) }, 0
  %t2232 = add i64 %t2229, %t2231
  %t2233 = call ptr @__olang_scope_alloc(ptr %s79, i64 %t2232)
  call void @olang_textcopy(ptr %t2233, ptr %t2217, i64 %t2218)
  %t2234 = getelementptr i8, ptr %t2233, i64 %t2218
  call void @olang_textcopy(ptr %t2234, ptr %t2220, i64 %t2221)
  %t2235 = getelementptr i8, ptr %t2234, i64 %t2221
  call void @olang_textcopy(ptr %t2235, ptr %t2223, i64 %t2224)
  %t2236 = getelementptr i8, ptr %t2235, i64 %t2224
  call void @olang_textcopy(ptr %t2236, ptr %t2227, i64 %t2228)
  %t2237 = getelementptr i8, ptr %t2236, i64 %t2228
  call void @olang_textcopy(ptr %t2237, ptr %t2230, i64 %t2231)
  %t2238 = insertvalue { i64, ptr } undef, i64 %t2232, 0
  %t2239 = insertvalue { i64, ptr } %t2238, ptr %t2233, 1
  %t2241 = extractvalue { i64, ptr } %t2239, 0
  %t2242 = extractvalue { i64, ptr } %t2239, 1
  %t2243 = mul i64 %t2241, 1
  %t2244 = call ptr @__olang_scope_alloc(ptr %s79, i64 %t2243)
  call void @llvm.memcpy.p0.p0.i64(ptr %t2244, ptr %t2242, i64 %t2243, i1 false)
  %t2245 = insertvalue { i64, ptr } undef, i64 %t2241, 0
  %t2246 = insertvalue { i64, ptr } %t2245, ptr %t2244, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s79, ptr %t2214, { i64, ptr } %t2246)
  br label %bb349
bb349:
  %t2249 = load i1, ptr %l14, !tbaa !21
  br i1 %t2249, label %bb350, label %bb351
bb350:
  store %olang.scope zeroinitializer, ptr %s88
  %t2251 = load ptr, ptr %l11, !tbaa !29
  %t2252 = load { i64, ptr }, ptr %l78, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s88, ptr %s79, ptr %s88, ptr %s88, ptr %t2251, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d255, i32 0, i32 1) }, { i64, ptr } %t2252, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d256, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d173, i32 0, i32 1) })
  br label %bb352
bb351:
  %t2255 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t2256 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d257, i32 0, i32 1) }, 1
  %t2257 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d257, i32 0, i32 1) }, 0
  %t2259 = extractvalue { i64, ptr } %t2255, 1
  %t2260 = extractvalue { i64, ptr } %t2255, 0
  %t2261 = add i64 %t2257, %t2260
  %t2262 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t2261)
  call void @olang_textcopy(ptr %t2262, ptr %t2256, i64 %t2257)
  %t2263 = getelementptr i8, ptr %t2262, i64 %t2257
  call void @olang_textcopy(ptr %t2263, ptr %t2259, i64 %t2260)
  %t2264 = insertvalue { i64, ptr } undef, i64 %t2261, 0
  %t2265 = insertvalue { i64, ptr } %t2264, ptr %t2262, 1
  store { i64, ptr } %t2265, ptr %l811, !tbaa !27
  %t2266 = load { i64, ptr }, ptr %l75, !tbaa !27
  %t2267 = extractvalue { i64, ptr } %t2266, 0
  %t2268 = load { i64, ptr }, ptr %l811, !tbaa !27
  %t2269 = extractvalue { i64, ptr } %t2268, 0
  store i64 %t2269, ptr %l813, !tbaa !24
  %t2271 = load i64, ptr %l813, !tbaa !24
  %t2272 = icmp eq i64 %t2267, %t2271
  br i1 %t2272, label %bb356, label %bb357
bb352:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d258, i32 0, i32 1) }, ptr %l803, !tbaa !27
  %t2274 = load { i64, ptr }, ptr %l803, !tbaa !27
  store { i64, ptr } %t2274, ptr %l804, !tbaa !27
  %t2275 = load { i64, ptr }, ptr %l75, !tbaa !27
  %t2276 = extractvalue { i64, ptr } %t2275, 0
  %t2277 = load { i64, ptr }, ptr %l804, !tbaa !27
  %t2278 = extractvalue { i64, ptr } %t2277, 0
  store i64 %t2278, ptr %l806, !tbaa !24
  %t2280 = load i64, ptr %l806, !tbaa !24
  %t2281 = icmp eq i64 %t2276, %t2280
  br i1 %t2281, label %bb353, label %bb354
bb353:
  %t2283 = getelementptr { i64, ptr }, ptr %l75, i32 0, i32 1
  %t2284 = load ptr, ptr %t2283, !tbaa !27
  %t2285 = getelementptr { i64, ptr }, ptr %l804, i32 0, i32 1
  %t2286 = load ptr, ptr %t2285, !tbaa !27
  %t2287 = load i64, ptr %l806, !tbaa !24
  %t2288 = mul i64 %t2287, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t2284, ptr %t2286, i64 %t2288, i1 false)
  br label %bb355
bb354:
  %t2289 = load { i64, ptr }, ptr %l804, !tbaa !27
  %t2290 = extractvalue { i64, ptr } %t2289, 0
  store i64 %t2290, ptr %l808, !tbaa !24
  %t2291 = load i64, ptr %l808, !tbaa !24
  %t2292 = mul i64 %t2291, 1
  %t2293 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t2292)
  %t2294 = insertvalue { i64, ptr } undef, i64 %t2291, 0
  %t2295 = insertvalue { i64, ptr } %t2294, ptr %t2293, 1
  store { i64, ptr } %t2295, ptr %l809, !tbaa !27
  %t2296 = getelementptr { i64, ptr }, ptr %l809, i32 0, i32 1
  %t2297 = load ptr, ptr %t2296, !tbaa !27
  %t2298 = getelementptr { i64, ptr }, ptr %l804, i32 0, i32 1
  %t2299 = load ptr, ptr %t2298, !tbaa !27
  %t2300 = load i64, ptr %l808, !tbaa !24
  %t2301 = mul i64 %t2300, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t2297, ptr %t2299, i64 %t2301, i1 false)
  %t2302 = load { i64, ptr }, ptr %l809, !tbaa !27
  store { i64, ptr } %t2302, ptr %l75, !tbaa !27
  br label %bb355
bb355:
  call void @__olang_scope_close(ptr %s88)
  br label %bb359
bb356:
  %t2303 = getelementptr { i64, ptr }, ptr %l75, i32 0, i32 1
  %t2304 = load ptr, ptr %t2303, !tbaa !27
  %t2305 = getelementptr { i64, ptr }, ptr %l811, i32 0, i32 1
  %t2306 = load ptr, ptr %t2305, !tbaa !27
  %t2307 = load i64, ptr %l813, !tbaa !24
  %t2308 = mul i64 %t2307, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t2304, ptr %t2306, i64 %t2308, i1 false)
  br label %bb358
bb357:
  %t2309 = load { i64, ptr }, ptr %l811, !tbaa !27
  store { i64, ptr } %t2309, ptr %l75, !tbaa !27
  br label %bb358
bb358:
  br label %bb359
bb359:
  call void @__olang_scope_close(ptr %s79)
  br label %bb435
bb360:
  %t2310 = load i1, ptr %l13, !tbaa !21
  br i1 %t2310, label %bb362, label %bb363
bb361:
  %t2312 = load i1, ptr %l13, !tbaa !21
  br i1 %t2312, label %bb370, label %bb371
bb362:
  store %olang.scope zeroinitializer, ptr %s93
  %t2314 = load ptr, ptr %l11, !tbaa !29
  store ptr %t2314, ptr %l817, !tbaa !29
  %t2315 = load ptr, ptr %l0, !tbaa !29
  %t2316 = load i32, ptr %l12, !tbaa !23
  %t2319 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %s93, ptr %t2315, i32 %t2316)
  store { i64, ptr } %t2319, ptr %l820
  br label %bb364
bb363:
  br label %bb366
bb364:
  %t2320 = load { i64, ptr }, ptr %l820, !tbaa !27
  %t2321 = extractvalue { i64, ptr } %t2320, 0
  %t2322 = extractvalue { i64, ptr } %t2320, 1
  %t2323 = mul i64 %t2321, 1
  %t2324 = call ptr @__olang_scope_alloc(ptr %s93, i64 %t2323)
  call void @llvm.memcpy.p0.p0.i64(ptr %t2324, ptr %t2322, i64 %t2323, i1 false)
  %t2325 = insertvalue { i64, ptr } undef, i64 %t2321, 0
  %t2326 = insertvalue { i64, ptr } %t2325, ptr %t2324, 1
  %t2327 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t2328 = load ptr, ptr %l817, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s93, ptr %s0, ptr %s93, ptr %s93, ptr %t2328, { i64, ptr } %t2326, { i64, ptr } %t2327, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d259, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d173, i32 0, i32 1) })
  br label %bb365
bb365:
  call void @__olang_scope_close(ptr %s93)
  br label %bb366
bb366:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d260, i32 0, i32 1) }, ptr %l823, !tbaa !27
  %t2331 = load { i64, ptr }, ptr %l823, !tbaa !27
  store { i64, ptr } %t2331, ptr %l824, !tbaa !27
  %t2332 = load { i64, ptr }, ptr %l75, !tbaa !27
  %t2333 = extractvalue { i64, ptr } %t2332, 0
  %t2334 = load { i64, ptr }, ptr %l824, !tbaa !27
  %t2335 = extractvalue { i64, ptr } %t2334, 0
  store i64 %t2335, ptr %l826, !tbaa !24
  %t2337 = load i64, ptr %l826, !tbaa !24
  %t2338 = icmp eq i64 %t2333, %t2337
  br i1 %t2338, label %bb367, label %bb368
bb367:
  %t2340 = getelementptr { i64, ptr }, ptr %l75, i32 0, i32 1
  %t2341 = load ptr, ptr %t2340, !tbaa !27
  %t2342 = getelementptr { i64, ptr }, ptr %l824, i32 0, i32 1
  %t2343 = load ptr, ptr %t2342, !tbaa !27
  %t2344 = load i64, ptr %l826, !tbaa !24
  %t2345 = mul i64 %t2344, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t2341, ptr %t2343, i64 %t2345, i1 false)
  br label %bb369
bb368:
  %t2346 = load { i64, ptr }, ptr %l824, !tbaa !27
  %t2347 = extractvalue { i64, ptr } %t2346, 0
  store i64 %t2347, ptr %l828, !tbaa !24
  %t2348 = load i64, ptr %l828, !tbaa !24
  %t2349 = mul i64 %t2348, 1
  %t2350 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t2349)
  %t2351 = insertvalue { i64, ptr } undef, i64 %t2348, 0
  %t2352 = insertvalue { i64, ptr } %t2351, ptr %t2350, 1
  store { i64, ptr } %t2352, ptr %l829, !tbaa !27
  %t2353 = getelementptr { i64, ptr }, ptr %l829, i32 0, i32 1
  %t2354 = load ptr, ptr %t2353, !tbaa !27
  %t2355 = getelementptr { i64, ptr }, ptr %l824, i32 0, i32 1
  %t2356 = load ptr, ptr %t2355, !tbaa !27
  %t2357 = load i64, ptr %l828, !tbaa !24
  %t2358 = mul i64 %t2357, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t2354, ptr %t2356, i64 %t2358, i1 false)
  %t2359 = load { i64, ptr }, ptr %l829, !tbaa !27
  store { i64, ptr } %t2359, ptr %l75, !tbaa !27
  br label %bb369
bb369:
  br label %bb434
bb370:
  %t2360 = getelementptr %"compiler/cabi:Way", ptr %l16, i32 0, i32 0
  %t2361 = load i32, ptr %t2360
  store i32 %t2361, ptr %l84
  %t2363 = load i32, ptr %l84
  %t2365 = trunc i64 0 to i32
  %t2366 = icmp eq i32 %t2363, %t2365
  br i1 %t2366, label %bb372, label %bb373
bb371:
  br label %bb433
bb372:
  br label %bb374
bb373:
  br label %bb379
bb374:
  store %olang.scope zeroinitializer, ptr %s96
  %t2368 = load ptr, ptr %l0, !tbaa !29
  %t2369 = load i32, ptr %l12, !tbaa !23
  %t2372 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %s96, ptr %t2368, i32 %t2369)
  store { i64, ptr } %t2372, ptr %l836
  br label %bb375
bb375:
  %t2373 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t2374 = load { i64, ptr }, ptr %l836, !tbaa !27
  %t2375 = extractvalue { i64, ptr } %t2374, 1
  %t2376 = extractvalue { i64, ptr } %t2374, 0
  %t2377 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d261, i32 0, i32 1) }, 1
  %t2378 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d261, i32 0, i32 1) }, 0
  %t2379 = add i64 %t2376, %t2378
  %t2381 = extractvalue { i64, ptr } %t2373, 1
  %t2382 = extractvalue { i64, ptr } %t2373, 0
  %t2383 = add i64 %t2379, %t2382
  %t2384 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t2383)
  call void @olang_textcopy(ptr %t2384, ptr %t2375, i64 %t2376)
  %t2385 = getelementptr i8, ptr %t2384, i64 %t2376
  call void @olang_textcopy(ptr %t2385, ptr %t2377, i64 %t2378)
  %t2386 = getelementptr i8, ptr %t2385, i64 %t2378
  call void @olang_textcopy(ptr %t2386, ptr %t2381, i64 %t2382)
  %t2387 = insertvalue { i64, ptr } undef, i64 %t2383, 0
  %t2388 = insertvalue { i64, ptr } %t2387, ptr %t2384, 1
  store { i64, ptr } %t2388, ptr %l838, !tbaa !27
  %t2389 = load { i64, ptr }, ptr %l75, !tbaa !27
  %t2390 = extractvalue { i64, ptr } %t2389, 0
  %t2391 = load { i64, ptr }, ptr %l838, !tbaa !27
  %t2392 = extractvalue { i64, ptr } %t2391, 0
  store i64 %t2392, ptr %l840, !tbaa !24
  %t2394 = load i64, ptr %l840, !tbaa !24
  %t2395 = icmp eq i64 %t2390, %t2394
  br i1 %t2395, label %bb376, label %bb377
bb376:
  %t2397 = getelementptr { i64, ptr }, ptr %l75, i32 0, i32 1
  %t2398 = load ptr, ptr %t2397, !tbaa !27
  %t2399 = getelementptr { i64, ptr }, ptr %l838, i32 0, i32 1
  %t2400 = load ptr, ptr %t2399, !tbaa !27
  %t2401 = load i64, ptr %l840, !tbaa !24
  %t2402 = mul i64 %t2401, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t2398, ptr %t2400, i64 %t2402, i1 false)
  br label %bb378
bb377:
  %t2403 = load { i64, ptr }, ptr %l838, !tbaa !27
  store { i64, ptr } %t2403, ptr %l75, !tbaa !27
  br label %bb378
bb378:
  call void @__olang_scope_close(ptr %s96)
  br label %bb432
bb379:
  %t2404 = load i32, ptr %l84
  %t2406 = trunc i64 1 to i32
  %t2407 = icmp eq i32 %t2404, %t2406
  br i1 %t2407, label %bb380, label %bb381
bb380:
  br label %bb382
bb381:
  br label %bb425
bb382:
  store %olang.scope zeroinitializer, ptr %s98
  %t2409 = load ptr, ptr %l11, !tbaa !29
  store ptr %t2409, ptr %l844, !tbaa !29
  %t2410 = load ptr, ptr %l2, !tbaa !29
  %t2411 = load i32, ptr %l12, !tbaa !23
  %t2415 = call i64 @compiler_2fcabi_2eSpan(ptr %v0, ptr %s0, ptr %t2410, ptr %l16, i32 %t2411)
  store i64 %t2415, ptr %l848
  br label %bb383
bb383:
  %t2416 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d262, i32 0, i32 1) }, 1
  %t2417 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d262, i32 0, i32 1) }, 0
  %t2418 = load i64, ptr %l848, !tbaa !24
  %t2419 = call i64 @__olang_fmt_i64(ptr null, i64 %t2418)
  %t2420 = add i64 %t2417, %t2419
  %t2421 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d263, i32 0, i32 1) }, 1
  %t2422 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d263, i32 0, i32 1) }, 0
  %t2423 = add i64 %t2420, %t2422
  %t2424 = call ptr @__olang_scope_alloc(ptr %s98, i64 %t2423)
  call void @olang_textcopy(ptr %t2424, ptr %t2416, i64 %t2417)
  %t2425 = getelementptr i8, ptr %t2424, i64 %t2417
  %t2426 = call i64 @__olang_fmt_i64(ptr %t2425, i64 %t2418)
  %t2427 = getelementptr i8, ptr %t2425, i64 %t2419
  call void @olang_textcopy(ptr %t2427, ptr %t2421, i64 %t2422)
  %t2428 = insertvalue { i64, ptr } undef, i64 %t2423, 0
  %t2429 = insertvalue { i64, ptr } %t2428, ptr %t2424, 1
  %t2431 = extractvalue { i64, ptr } %t2429, 0
  %t2432 = extractvalue { i64, ptr } %t2429, 1
  %t2433 = mul i64 %t2431, 1
  %t2434 = call ptr @__olang_scope_alloc(ptr %s98, i64 %t2433)
  call void @llvm.memcpy.p0.p0.i64(ptr %t2434, ptr %t2432, i64 %t2433, i1 false)
  %t2435 = insertvalue { i64, ptr } undef, i64 %t2431, 0
  %t2436 = insertvalue { i64, ptr } %t2435, ptr %t2434, 1
  %t2437 = load ptr, ptr %l844, !tbaa !29
  %t2439 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ealloca(ptr %v0, ptr %s98, ptr %s98, ptr %t2437, { i64, ptr } %t2436, i64 8)
  store { i64, ptr } %t2439, ptr %l851
  br label %bb384
bb384:
  %t2440 = load { i64, ptr }, ptr %l851, !tbaa !27
  store { i64, ptr } %t2440, ptr %l85, !tbaa !27
  %t2441 = load ptr, ptr %l11, !tbaa !29
  store ptr %t2441, ptr %l852, !tbaa !29
  %t2442 = load ptr, ptr %l0, !tbaa !29
  %t2443 = load i32, ptr %l12, !tbaa !23
  %t2446 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %s98, ptr %t2442, i32 %t2443)
  store { i64, ptr } %t2446, ptr %l855
  br label %bb385
bb385:
  %t2447 = load { i64, ptr }, ptr %l855, !tbaa !27
  %t2448 = extractvalue { i64, ptr } %t2447, 0
  %t2449 = extractvalue { i64, ptr } %t2447, 1
  %t2450 = mul i64 %t2448, 1
  %t2451 = call ptr @__olang_scope_alloc(ptr %s98, i64 %t2450)
  call void @llvm.memcpy.p0.p0.i64(ptr %t2451, ptr %t2449, i64 %t2450, i1 false)
  %t2452 = insertvalue { i64, ptr } undef, i64 %t2448, 0
  %t2453 = insertvalue { i64, ptr } %t2452, ptr %t2451, 1
  %t2454 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t2455 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t2456 = load ptr, ptr %l852, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s98, ptr %s0, ptr %s98, ptr %s98, ptr %t2456, { i64, ptr } %t2453, { i64, ptr } %t2454, { i64, ptr } %t2455, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d173, i32 0, i32 1) })
  br label %bb386
bb386:
  %t2461 = call { i64, ptr } @compiler_2fcabi_2ePartsType(ptr %s0, ptr %s98, ptr %l16)
  store { i64, ptr } %t2461, ptr %l860
  br label %bb387
bb387:
  %t2462 = load { i64, ptr }, ptr %l860, !tbaa !27
  store { i64, ptr } %t2462, ptr %l86, !tbaa !27
  %t2463 = getelementptr %"compiler/cabi:Way", ptr %l16, i32 0, i32 1
  %t2465 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %s0, ptr %t2463)
  store i64 %t2465, ptr %l862
  br label %bb388
bb388:
  %t2466 = load i64, ptr %l862, !tbaa !24
  %t2467 = icmp eq i64 %t2466, 1
  br i1 %t2467, label %bb389, label %bb390
bb389:
  store %olang.scope zeroinitializer, ptr %s100
  %t2469 = load { i64, ptr }, ptr %l86, !tbaa !27
  store { i64, ptr } %t2469, ptr %l864, !tbaa !27
  %t2470 = load ptr, ptr %l11, !tbaa !29
  %t2471 = load { i64, ptr }, ptr %l86, !tbaa !27
  %t2472 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t2476 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %s98, ptr %s98, ptr %s100, ptr %s100, ptr %t2470, { i64, ptr } %t2471, { i64, ptr } %t2472, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d179, i32 0, i32 1) })
  store { i64, ptr } %t2476, ptr %l868
  br label %bb391
bb390:
  store %olang.scope zeroinitializer, ptr %s102
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d264, i32 0, i32 1) }, ptr %l873, !tbaa !27
  %t2477 = load { i64, ptr }, ptr %l873, !tbaa !27
  store { i64, ptr } %t2477, ptr %l874, !tbaa !27
  %t2478 = load { i64, ptr }, ptr %l874, !tbaa !27
  %t2479 = extractvalue { i64, ptr } %t2478, 0
  store i64 %t2479, ptr %l875, !tbaa !24
  %t2480 = load i64, ptr %l875, !tbaa !24
  %t2481 = mul i64 %t2480, 1
  %t2482 = call ptr @__olang_scope_alloc_zeroed(ptr %s102, i64 %t2481)
  %t2483 = insertvalue { i64, ptr } undef, i64 %t2480, 0
  %t2484 = insertvalue { i64, ptr } %t2483, ptr %t2482, 1
  store { i64, ptr } %t2484, ptr %l876, !tbaa !27
  %t2485 = getelementptr { i64, ptr }, ptr %l876, i32 0, i32 1
  %t2486 = load ptr, ptr %t2485, !tbaa !27
  %t2487 = getelementptr { i64, ptr }, ptr %l874, i32 0, i32 1
  %t2488 = load ptr, ptr %t2487, !tbaa !27
  %t2489 = load i64, ptr %l875, !tbaa !24
  %t2490 = mul i64 %t2489, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t2486, ptr %t2488, i64 %t2490, i1 false)
  %t2491 = load { i64, ptr }, ptr %l876, !tbaa !27
  store { i64, ptr } %t2491, ptr %l87, !tbaa !27
  store i64 0, ptr %l88, !tbaa !24
  %t2492 = getelementptr %"compiler/cabi:Way", ptr %l16, i32 0, i32 1
  %t2494 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %s0, ptr %t2492)
  store i64 %t2494, ptr %l878
  br label %bb395
bb391:
  %t2495 = load { i64, ptr }, ptr %l864, !tbaa !27
  %t2496 = extractvalue { i64, ptr } %t2495, 1
  %t2497 = extractvalue { i64, ptr } %t2495, 0
  %t2498 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d265, i32 0, i32 1) }, 1
  %t2499 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d265, i32 0, i32 1) }, 0
  %t2500 = add i64 %t2497, %t2499
  %t2501 = load { i64, ptr }, ptr %l868, !tbaa !27
  %t2502 = extractvalue { i64, ptr } %t2501, 1
  %t2503 = extractvalue { i64, ptr } %t2501, 0
  %t2504 = add i64 %t2500, %t2503
  %t2505 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t2504)
  call void @olang_textcopy(ptr %t2505, ptr %t2496, i64 %t2497)
  %t2506 = getelementptr i8, ptr %t2505, i64 %t2497
  call void @olang_textcopy(ptr %t2506, ptr %t2498, i64 %t2499)
  %t2507 = getelementptr i8, ptr %t2506, i64 %t2499
  call void @olang_textcopy(ptr %t2507, ptr %t2502, i64 %t2503)
  %t2508 = insertvalue { i64, ptr } undef, i64 %t2504, 0
  %t2509 = insertvalue { i64, ptr } %t2508, ptr %t2505, 1
  store { i64, ptr } %t2509, ptr %l869, !tbaa !27
  %t2510 = load { i64, ptr }, ptr %l75, !tbaa !27
  %t2511 = extractvalue { i64, ptr } %t2510, 0
  %t2512 = load { i64, ptr }, ptr %l869, !tbaa !27
  %t2513 = extractvalue { i64, ptr } %t2512, 0
  store i64 %t2513, ptr %l871, !tbaa !24
  %t2515 = load i64, ptr %l871, !tbaa !24
  %t2516 = icmp eq i64 %t2511, %t2515
  br i1 %t2516, label %bb392, label %bb393
bb392:
  %t2518 = getelementptr { i64, ptr }, ptr %l75, i32 0, i32 1
  %t2519 = load ptr, ptr %t2518, !tbaa !27
  %t2520 = getelementptr { i64, ptr }, ptr %l869, i32 0, i32 1
  %t2521 = load ptr, ptr %t2520, !tbaa !27
  %t2522 = load i64, ptr %l871, !tbaa !24
  %t2523 = mul i64 %t2522, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t2519, ptr %t2521, i64 %t2523, i1 false)
  br label %bb394
bb393:
  %t2524 = load { i64, ptr }, ptr %l869, !tbaa !27
  store { i64, ptr } %t2524, ptr %l75, !tbaa !27
  br label %bb394
bb394:
  call void @__olang_scope_close(ptr %s100)
  br label %bb424
bb395:
  %t2525 = load i64, ptr %l878, !tbaa !24
  store i64 %t2525, ptr %l89, !tbaa !24
  store i64 1, ptr %l90, !tbaa !24
  %t2526 = load i64, ptr %l89, !tbaa !24
  %t2527 = load i64, ptr %l88, !tbaa !24
  %t2530 = icmp sgt i64 %t2526, %t2527
  br i1 %t2530, label %bb396, label %bb397
bb396:
  %t2532 = load i64, ptr %l90, !tbaa !24
  %t2534 = icmp sgt i64 %t2532, 0
  br i1 %t2534, label %bb398, label %bb399
bb397:
  store i64 0, ptr %l882, !tbaa !24
  br label %bb401
bb398:
  %t2536 = load i64, ptr %l89, !tbaa !24
  %t2537 = load i64, ptr %l88, !tbaa !24
  %t2540 = sub i64 %t2536, %t2537
  %t2541 = load i64, ptr %l90, !tbaa !24
  %t2544 = add i64 %t2540, %t2541
  %t2546 = sub i64 %t2544, 1
  %t2547 = load i64, ptr %l90, !tbaa !24
  %t2550 = sdiv i64 %t2546, %t2547
  store i64 %t2550, ptr %l885, !tbaa !24
  br label %bb400
bb399:
  store i64 0, ptr %l885, !tbaa !24
  br label %bb400
bb400:
  %t2552 = load i64, ptr %l885, !tbaa !24
  store i64 %t2552, ptr %l882, !tbaa !24
  br label %bb401
bb401:
  %t2553 = load i64, ptr %l882, !tbaa !24
  store i64 %t2553, ptr %l91, !tbaa !24
  store i64 0, ptr %l92, !tbaa !24
  br label %bb402
bb402:
  store %olang.scope zeroinitializer, ptr %s104
  %t2554 = load i64, ptr %l92, !tbaa !24
  %t2555 = load i64, ptr %l91, !tbaa !24
  %t2558 = icmp slt i64 %t2554, %t2555
  %t2560 = xor i1 %t2558, true
  br i1 %t2560, label %bb403, label %bb404
bb403:
  call void @__olang_scope_close(ptr %s104)
  br label %bb420
bb404:
  br label %bb405
bb405:
  %t2562 = load i64, ptr %l88, !tbaa !24
  %t2563 = load i64, ptr %l92, !tbaa !24
  %t2564 = load i64, ptr %l90, !tbaa !24
  %t2567 = mul i64 %t2563, %t2564
  %t2570 = add i64 %t2562, %t2567
  store i64 %t2570, ptr %l93, !tbaa !24
  %t2572 = getelementptr %"compiler/cabi:Way", ptr %l16, i32 0, i32 2
  %t2573 = load i64, ptr %l93, !tbaa !24
  %t2576 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t2572, i64 %t2573)
  store i64 %t2576, ptr %l905
  br label %bb406
bb406:
  %t2577 = load i64, ptr %l905, !tbaa !24
  %t2578 = icmp eq i64 %t2577, 0
  br i1 %t2578, label %bb407, label %bb408
bb407:
  %t2580 = load { i64, ptr }, ptr %l85, !tbaa !27
  store { i64, ptr } %t2580, ptr %l907, !tbaa !27
  br label %bb411
bb408:
  %t2582 = load ptr, ptr %l11, !tbaa !29
  store ptr %t2582, ptr %l909, !tbaa !29
  %t2583 = load { i64, ptr }, ptr %l85, !tbaa !27
  store { i64, ptr } %t2583, ptr %l910, !tbaa !27
  %t2584 = getelementptr %"compiler/cabi:Way", ptr %l16, i32 0, i32 2
  %t2585 = load i64, ptr %l93, !tbaa !24
  %t2588 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t2584, i64 %t2585)
  store i64 %t2588, ptr %l913
  br label %bb409
bb409:
  %t2589 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d266, i32 0, i32 1) }, 1
  %t2590 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d266, i32 0, i32 1) }, 0
  %t2591 = load { i64, ptr }, ptr %l910, !tbaa !27
  %t2592 = extractvalue { i64, ptr } %t2591, 1
  %t2593 = extractvalue { i64, ptr } %t2591, 0
  %t2594 = add i64 %t2590, %t2593
  %t2595 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d267, i32 0, i32 1) }, 1
  %t2596 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d267, i32 0, i32 1) }, 0
  %t2597 = add i64 %t2594, %t2596
  %t2598 = load i64, ptr %l913, !tbaa !24
  %t2599 = call i64 @__olang_fmt_i64(ptr null, i64 %t2598)
  %t2600 = add i64 %t2597, %t2599
  %t2601 = call ptr @__olang_scope_alloc(ptr %s104, i64 %t2600)
  call void @olang_textcopy(ptr %t2601, ptr %t2589, i64 %t2590)
  %t2602 = getelementptr i8, ptr %t2601, i64 %t2590
  call void @olang_textcopy(ptr %t2602, ptr %t2592, i64 %t2593)
  %t2603 = getelementptr i8, ptr %t2602, i64 %t2593
  call void @olang_textcopy(ptr %t2603, ptr %t2595, i64 %t2596)
  %t2604 = getelementptr i8, ptr %t2603, i64 %t2596
  %t2605 = call i64 @__olang_fmt_i64(ptr %t2604, i64 %t2598)
  %t2606 = insertvalue { i64, ptr } undef, i64 %t2600, 0
  %t2607 = insertvalue { i64, ptr } %t2606, ptr %t2601, 1
  %t2609 = extractvalue { i64, ptr } %t2607, 0
  %t2610 = extractvalue { i64, ptr } %t2607, 1
  %t2611 = mul i64 %t2609, 1
  %t2612 = call ptr @__olang_scope_alloc(ptr %s104, i64 %t2611)
  call void @llvm.memcpy.p0.p0.i64(ptr %t2612, ptr %t2610, i64 %t2611, i1 false)
  %t2613 = insertvalue { i64, ptr } undef, i64 %t2609, 0
  %t2614 = insertvalue { i64, ptr } %t2613, ptr %t2612, 1
  %t2615 = load ptr, ptr %l909, !tbaa !29
  %t2617 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s104, ptr %s104, ptr %t2615, { i64, ptr } %t2614)
  store { i64, ptr } %t2617, ptr %l916
  br label %bb410
bb410:
  %t2618 = load { i64, ptr }, ptr %l916, !tbaa !27
  store { i64, ptr } %t2618, ptr %l907, !tbaa !27
  br label %bb411
bb411:
  %t2619 = load { i64, ptr }, ptr %l907, !tbaa !27
  store { i64, ptr } %t2619, ptr %l94, !tbaa !27
  %t2620 = load ptr, ptr %l11, !tbaa !29
  store ptr %t2620, ptr %l917, !tbaa !29
  %t2621 = load { i64, ptr }, ptr %l86, !tbaa !27
  store { i64, ptr } %t2621, ptr %l918, !tbaa !27
  %t2622 = load { i64, ptr }, ptr %l87, !tbaa !27
  store { i64, ptr } %t2622, ptr %l919, !tbaa !27
  %t2623 = getelementptr %"compiler/cabi:Way", ptr %l16, i32 0, i32 1
  %t2624 = load i64, ptr %l93, !tbaa !24
  %t2627 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %s0, ptr %s104, ptr %t2623, i64 %t2624)
  store { i64, ptr } %t2627, ptr %l922
  br label %bb412
bb412:
  %t2628 = load ptr, ptr %l11, !tbaa !29
  store ptr %t2628, ptr %l923, !tbaa !29
  %t2629 = getelementptr %"compiler/cabi:Way", ptr %l16, i32 0, i32 1
  %t2630 = load i64, ptr %l93, !tbaa !24
  %t2633 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %s0, ptr %s0, ptr %t2629, i64 %t2630)
  store { i64, ptr } %t2633, ptr %l926
  br label %bb413
bb413:
  %t2634 = load { i64, ptr }, ptr %l94, !tbaa !27
  %t2635 = load ptr, ptr %l923, !tbaa !29
  %t2636 = load { i64, ptr }, ptr %l926, !tbaa !27
  %t2638 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %s0, ptr %s104, ptr %s104, ptr %s104, ptr %t2635, { i64, ptr } %t2636, { i64, ptr } %t2634, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d179, i32 0, i32 1) })
  store { i64, ptr } %t2638, ptr %l928
  br label %bb414
bb414:
  %t2639 = load i64, ptr %l93, !tbaa !24
  %t2640 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d268, i32 0, i32 1) }, 1
  %t2641 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d268, i32 0, i32 1) }, 0
  %t2642 = load { i64, ptr }, ptr %l918, !tbaa !27
  %t2643 = extractvalue { i64, ptr } %t2642, 1
  %t2644 = extractvalue { i64, ptr } %t2642, 0
  %t2645 = add i64 %t2641, %t2644
  %t2646 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d269, i32 0, i32 1) }, 1
  %t2647 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d269, i32 0, i32 1) }, 0
  %t2648 = add i64 %t2645, %t2647
  %t2649 = load { i64, ptr }, ptr %l919, !tbaa !27
  %t2650 = extractvalue { i64, ptr } %t2649, 1
  %t2651 = extractvalue { i64, ptr } %t2649, 0
  %t2652 = add i64 %t2648, %t2651
  %t2653 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d270, i32 0, i32 1) }, 1
  %t2654 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d270, i32 0, i32 1) }, 0
  %t2655 = add i64 %t2652, %t2654
  %t2656 = load { i64, ptr }, ptr %l922, !tbaa !27
  %t2657 = extractvalue { i64, ptr } %t2656, 1
  %t2658 = extractvalue { i64, ptr } %t2656, 0
  %t2659 = add i64 %t2655, %t2658
  %t2660 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d269, i32 0, i32 1) }, 1
  %t2661 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d269, i32 0, i32 1) }, 0
  %t2662 = add i64 %t2659, %t2661
  %t2663 = load { i64, ptr }, ptr %l928, !tbaa !27
  %t2664 = extractvalue { i64, ptr } %t2663, 1
  %t2665 = extractvalue { i64, ptr } %t2663, 0
  %t2666 = add i64 %t2662, %t2665
  %t2667 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d270, i32 0, i32 1) }, 1
  %t2668 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d270, i32 0, i32 1) }, 0
  %t2669 = add i64 %t2666, %t2668
  %t2671 = call i64 @__olang_fmt_i64(ptr null, i64 %t2639)
  %t2672 = add i64 %t2669, %t2671
  %t2673 = call ptr @__olang_scope_alloc(ptr %s102, i64 %t2672)
  call void @olang_textcopy(ptr %t2673, ptr %t2640, i64 %t2641)
  %t2674 = getelementptr i8, ptr %t2673, i64 %t2641
  call void @olang_textcopy(ptr %t2674, ptr %t2643, i64 %t2644)
  %t2675 = getelementptr i8, ptr %t2674, i64 %t2644
  call void @olang_textcopy(ptr %t2675, ptr %t2646, i64 %t2647)
  %t2676 = getelementptr i8, ptr %t2675, i64 %t2647
  call void @olang_textcopy(ptr %t2676, ptr %t2650, i64 %t2651)
  %t2677 = getelementptr i8, ptr %t2676, i64 %t2651
  call void @olang_textcopy(ptr %t2677, ptr %t2653, i64 %t2654)
  %t2678 = getelementptr i8, ptr %t2677, i64 %t2654
  call void @olang_textcopy(ptr %t2678, ptr %t2657, i64 %t2658)
  %t2679 = getelementptr i8, ptr %t2678, i64 %t2658
  call void @olang_textcopy(ptr %t2679, ptr %t2660, i64 %t2661)
  %t2680 = getelementptr i8, ptr %t2679, i64 %t2661
  call void @olang_textcopy(ptr %t2680, ptr %t2664, i64 %t2665)
  %t2681 = getelementptr i8, ptr %t2680, i64 %t2665
  call void @olang_textcopy(ptr %t2681, ptr %t2667, i64 %t2668)
  %t2682 = getelementptr i8, ptr %t2681, i64 %t2668
  %t2683 = call i64 @__olang_fmt_i64(ptr %t2682, i64 %t2639)
  %t2684 = insertvalue { i64, ptr } undef, i64 %t2672, 0
  %t2685 = insertvalue { i64, ptr } %t2684, ptr %t2673, 1
  %t2687 = extractvalue { i64, ptr } %t2685, 0
  %t2688 = extractvalue { i64, ptr } %t2685, 1
  %t2689 = mul i64 %t2687, 1
  %t2690 = call ptr @__olang_scope_alloc(ptr %s102, i64 %t2689)
  call void @llvm.memcpy.p0.p0.i64(ptr %t2690, ptr %t2688, i64 %t2689, i1 false)
  %t2691 = insertvalue { i64, ptr } undef, i64 %t2687, 0
  %t2692 = insertvalue { i64, ptr } %t2691, ptr %t2690, 1
  %t2693 = load ptr, ptr %l917, !tbaa !29
  %t2695 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s102, ptr %s102, ptr %t2693, { i64, ptr } %t2692)
  store { i64, ptr } %t2695, ptr %l932
  br label %bb415
bb415:
  %t2696 = load { i64, ptr }, ptr %l87, !tbaa !27
  %t2697 = extractvalue { i64, ptr } %t2696, 0
  %t2698 = load { i64, ptr }, ptr %l932, !tbaa !27
  %t2699 = extractvalue { i64, ptr } %t2698, 0
  store i64 %t2699, ptr %l934, !tbaa !24
  %t2701 = load i64, ptr %l934, !tbaa !24
  %t2702 = icmp eq i64 %t2697, %t2701
  br i1 %t2702, label %bb416, label %bb417
bb416:
  %t2704 = getelementptr { i64, ptr }, ptr %l87, i32 0, i32 1
  %t2705 = load ptr, ptr %t2704, !tbaa !27
  %t2706 = getelementptr { i64, ptr }, ptr %l932, i32 0, i32 1
  %t2707 = load ptr, ptr %t2706, !tbaa !27
  %t2708 = load i64, ptr %l934, !tbaa !24
  %t2709 = mul i64 %t2708, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t2705, ptr %t2707, i64 %t2709, i1 false)
  br label %bb418
bb417:
  %t2710 = load { i64, ptr }, ptr %l932, !tbaa !27
  store { i64, ptr } %t2710, ptr %l87, !tbaa !27
  br label %bb418
bb418:
  call void @__olang_scope_close(ptr %s104)
  br label %bb419
bb419:
  %t2711 = load i64, ptr %l92, !tbaa !24
  %t2713 = add i64 %t2711, 1
  store i64 %t2713, ptr %l92, !tbaa !24
  br label %bb402
bb420:
  %t2715 = load { i64, ptr }, ptr %l86, !tbaa !27
  %t2716 = load { i64, ptr }, ptr %l87, !tbaa !27
  %t2718 = extractvalue { i64, ptr } %t2715, 1
  %t2719 = extractvalue { i64, ptr } %t2715, 0
  %t2720 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d271, i32 0, i32 1) }, 1
  %t2721 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d271, i32 0, i32 1) }, 0
  %t2722 = add i64 %t2719, %t2721
  %t2724 = extractvalue { i64, ptr } %t2716, 1
  %t2725 = extractvalue { i64, ptr } %t2716, 0
  %t2726 = add i64 %t2722, %t2725
  %t2727 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t2726)
  call void @olang_textcopy(ptr %t2727, ptr %t2718, i64 %t2719)
  %t2728 = getelementptr i8, ptr %t2727, i64 %t2719
  call void @olang_textcopy(ptr %t2728, ptr %t2720, i64 %t2721)
  %t2729 = getelementptr i8, ptr %t2728, i64 %t2721
  call void @olang_textcopy(ptr %t2729, ptr %t2724, i64 %t2725)
  %t2730 = insertvalue { i64, ptr } undef, i64 %t2726, 0
  %t2731 = insertvalue { i64, ptr } %t2730, ptr %t2727, 1
  store { i64, ptr } %t2731, ptr %l940, !tbaa !27
  %t2732 = load { i64, ptr }, ptr %l75, !tbaa !27
  %t2733 = extractvalue { i64, ptr } %t2732, 0
  %t2734 = load { i64, ptr }, ptr %l940, !tbaa !27
  %t2735 = extractvalue { i64, ptr } %t2734, 0
  store i64 %t2735, ptr %l942, !tbaa !24
  %t2737 = load i64, ptr %l942, !tbaa !24
  %t2738 = icmp eq i64 %t2733, %t2737
  br i1 %t2738, label %bb421, label %bb422
bb421:
  %t2740 = getelementptr { i64, ptr }, ptr %l75, i32 0, i32 1
  %t2741 = load ptr, ptr %t2740, !tbaa !27
  %t2742 = getelementptr { i64, ptr }, ptr %l940, i32 0, i32 1
  %t2743 = load ptr, ptr %t2742, !tbaa !27
  %t2744 = load i64, ptr %l942, !tbaa !24
  %t2745 = mul i64 %t2744, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t2741, ptr %t2743, i64 %t2745, i1 false)
  br label %bb423
bb422:
  %t2746 = load { i64, ptr }, ptr %l940, !tbaa !27
  store { i64, ptr } %t2746, ptr %l75, !tbaa !27
  br label %bb423
bb423:
  call void @__olang_scope_close(ptr %s102)
  br label %bb424
bb424:
  call void @__olang_scope_close(ptr %s98)
  br label %bb432
bb425:
  br i1 true, label %bb426, label %bb427
bb426:
  br label %bb428
bb427:
  br label %bb431
bb428:
  store %olang.scope zeroinitializer, ptr %s109
  %t2747 = load ptr, ptr %l11, !tbaa !29
  store ptr %t2747, ptr %l944, !tbaa !29
  %t2748 = load ptr, ptr %l0, !tbaa !29
  %t2749 = load i32, ptr %l12, !tbaa !23
  %t2752 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %s109, ptr %t2748, i32 %t2749)
  store { i64, ptr } %t2752, ptr %l947
  br label %bb429
bb429:
  %t2753 = load { i64, ptr }, ptr %l947, !tbaa !27
  %t2754 = extractvalue { i64, ptr } %t2753, 0
  %t2755 = extractvalue { i64, ptr } %t2753, 1
  %t2756 = mul i64 %t2754, 1
  %t2757 = call ptr @__olang_scope_alloc(ptr %s109, i64 %t2756)
  call void @llvm.memcpy.p0.p0.i64(ptr %t2757, ptr %t2755, i64 %t2756, i1 false)
  %t2758 = insertvalue { i64, ptr } undef, i64 %t2754, 0
  %t2759 = insertvalue { i64, ptr } %t2758, ptr %t2757, 1
  %t2760 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t2761 = load ptr, ptr %l944, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s109, ptr %s0, ptr %s109, ptr %s109, ptr %t2761, { i64, ptr } %t2759, { i64, ptr } %t2760, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d272, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d173, i32 0, i32 1) })
  br label %bb430
bb430:
  call void @__olang_scope_close(ptr %s109)
  br label %bb432
bb431:
  call void @__olang_check_failed(ptr @olang_loc_86228246ceb03788_7d79aafe137da84c)
  unreachable
bb432:
  br label %bb433
bb433:
  br label %bb434
bb434:
  br label %bb435
bb435:
  %t2764 = load ptr, ptr %l11, !tbaa !29
  %t2765 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t2766 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d273, i32 0, i32 1) }, 1
  %t2767 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d273, i32 0, i32 1) }, 0
  %t2769 = extractvalue { i64, ptr } %t2765, 1
  %t2770 = extractvalue { i64, ptr } %t2765, 0
  %t2771 = add i64 %t2767, %t2770
  %t2772 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d274, i32 0, i32 1) }, 1
  %t2773 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d274, i32 0, i32 1) }, 0
  %t2774 = add i64 %t2771, %t2773
  %t2775 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t2774)
  call void @olang_textcopy(ptr %t2775, ptr %t2766, i64 %t2767)
  %t2776 = getelementptr i8, ptr %t2775, i64 %t2767
  call void @olang_textcopy(ptr %t2776, ptr %t2769, i64 %t2770)
  %t2777 = getelementptr i8, ptr %t2776, i64 %t2770
  call void @olang_textcopy(ptr %t2777, ptr %t2772, i64 %t2773)
  %t2778 = insertvalue { i64, ptr } undef, i64 %t2774, 0
  %t2779 = insertvalue { i64, ptr } %t2778, ptr %t2775, 1
  %t2781 = extractvalue { i64, ptr } %t2779, 0
  %t2782 = extractvalue { i64, ptr } %t2779, 1
  %t2783 = mul i64 %t2781, 1
  %t2784 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t2783)
  call void @llvm.memcpy.p0.p0.i64(ptr %t2784, ptr %t2782, i64 %t2783, i1 false)
  %t2785 = insertvalue { i64, ptr } undef, i64 %t2781, 0
  %t2786 = insertvalue { i64, ptr } %t2785, ptr %t2784, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s0, ptr %t2764, { i64, ptr } %t2786)
  br label %bb436
bb436:
  %t2789 = load ptr, ptr %l11, !tbaa !29
  store ptr %t2789, ptr %l954, !tbaa !29
  %t2790 = load { i64, ptr }, ptr %l75, !tbaa !27
  %t2792 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t2790, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d275, i32 0, i32 1) })
  store i1 %t2792, ptr %l956
  br label %bb437
bb437:
  %t2793 = load i1, ptr %l956, !tbaa !21
  %t2794 = xor i1 %t2793, true
  br i1 %t2794, label %bb438, label %bb439
bb438:
  %t2796 = load { i64, ptr }, ptr %l75, !tbaa !27
  store { i64, ptr } %t2796, ptr %l958, !tbaa !27
  br label %bb440
bb439:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d276, i32 0, i32 1) }, ptr %l958, !tbaa !27
  br label %bb440
bb440:
  %t2798 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d277, i32 0, i32 1) }, 1
  %t2799 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d277, i32 0, i32 1) }, 0
  %t2800 = load { i64, ptr }, ptr %l958, !tbaa !27
  %t2801 = extractvalue { i64, ptr } %t2800, 1
  %t2802 = extractvalue { i64, ptr } %t2800, 0
  %t2803 = add i64 %t2799, %t2802
  %t2804 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t2803)
  call void @olang_textcopy(ptr %t2804, ptr %t2798, i64 %t2799)
  %t2805 = getelementptr i8, ptr %t2804, i64 %t2799
  call void @olang_textcopy(ptr %t2805, ptr %t2801, i64 %t2802)
  %t2806 = insertvalue { i64, ptr } undef, i64 %t2803, 0
  %t2807 = insertvalue { i64, ptr } %t2806, ptr %t2804, 1
  %t2809 = extractvalue { i64, ptr } %t2807, 0
  %t2810 = extractvalue { i64, ptr } %t2807, 1
  %t2811 = mul i64 %t2809, 1
  %t2812 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t2811)
  call void @llvm.memcpy.p0.p0.i64(ptr %t2812, ptr %t2810, i64 %t2811, i1 false)
  %t2813 = insertvalue { i64, ptr } undef, i64 %t2809, 0
  %t2814 = insertvalue { i64, ptr } %t2813, ptr %t2812, 1
  %t2815 = load ptr, ptr %l954, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s0, ptr %t2815, { i64, ptr } %t2814)
  br label %bb441
bb441:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d278, i32 0, i32 1) }, ptr %l962, !tbaa !27
  %t2817 = load { i64, ptr }, ptr %l962, !tbaa !27
  store { i64, ptr } %t2817, ptr %l963, !tbaa !27
  %t2818 = load { i64, ptr }, ptr %l963, !tbaa !27
  %t2819 = extractvalue { i64, ptr } %t2818, 0
  store i64 %t2819, ptr %l964, !tbaa !24
  %t2820 = load i64, ptr %l964, !tbaa !24
  %t2821 = mul i64 %t2820, 1
  %t2822 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t2821)
  %t2823 = insertvalue { i64, ptr } undef, i64 %t2820, 0
  %t2824 = insertvalue { i64, ptr } %t2823, ptr %t2822, 1
  store { i64, ptr } %t2824, ptr %l965, !tbaa !27
  %t2825 = getelementptr { i64, ptr }, ptr %l965, i32 0, i32 1
  %t2826 = load ptr, ptr %t2825, !tbaa !27
  %t2827 = getelementptr { i64, ptr }, ptr %l963, i32 0, i32 1
  %t2828 = load ptr, ptr %t2827, !tbaa !27
  %t2829 = load i64, ptr %l964, !tbaa !24
  %t2830 = mul i64 %t2829, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t2826, ptr %t2828, i64 %t2830, i1 false)
  %t2831 = load { i64, ptr }, ptr %l965, !tbaa !27
  store { i64, ptr } %t2831, ptr %l95, !tbaa !27
  %t2832 = load i1, ptr %l14, !tbaa !21
  br i1 %t2832, label %bb442, label %bb443
bb442:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d279, i32 0, i32 1) }, ptr %l967, !tbaa !27
  %t2834 = load { i64, ptr }, ptr %l967, !tbaa !27
  store { i64, ptr } %t2834, ptr %l968, !tbaa !27
  %t2835 = load { i64, ptr }, ptr %l95, !tbaa !27
  %t2836 = extractvalue { i64, ptr } %t2835, 0
  %t2837 = load { i64, ptr }, ptr %l968, !tbaa !27
  %t2838 = extractvalue { i64, ptr } %t2837, 0
  store i64 %t2838, ptr %l970, !tbaa !24
  %t2840 = load i64, ptr %l970, !tbaa !24
  %t2841 = icmp eq i64 %t2836, %t2840
  br i1 %t2841, label %bb444, label %bb445
bb443:
  %t2843 = load i1, ptr %l15, !tbaa !21
  br i1 %t2843, label %bb447, label %bb448
bb444:
  %t2845 = getelementptr { i64, ptr }, ptr %l95, i32 0, i32 1
  %t2846 = load ptr, ptr %t2845, !tbaa !27
  %t2847 = getelementptr { i64, ptr }, ptr %l968, i32 0, i32 1
  %t2848 = load ptr, ptr %t2847, !tbaa !27
  %t2849 = load i64, ptr %l970, !tbaa !24
  %t2850 = mul i64 %t2849, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t2846, ptr %t2848, i64 %t2850, i1 false)
  br label %bb446
bb445:
  %t2851 = load { i64, ptr }, ptr %l968, !tbaa !27
  %t2852 = extractvalue { i64, ptr } %t2851, 0
  store i64 %t2852, ptr %l972, !tbaa !24
  %t2853 = load i64, ptr %l972, !tbaa !24
  %t2854 = mul i64 %t2853, 1
  %t2855 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t2854)
  %t2856 = insertvalue { i64, ptr } undef, i64 %t2853, 0
  %t2857 = insertvalue { i64, ptr } %t2856, ptr %t2855, 1
  store { i64, ptr } %t2857, ptr %l973, !tbaa !27
  %t2858 = getelementptr { i64, ptr }, ptr %l973, i32 0, i32 1
  %t2859 = load ptr, ptr %t2858, !tbaa !27
  %t2860 = getelementptr { i64, ptr }, ptr %l968, i32 0, i32 1
  %t2861 = load ptr, ptr %t2860, !tbaa !27
  %t2862 = load i64, ptr %l972, !tbaa !24
  %t2863 = mul i64 %t2862, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t2859, ptr %t2861, i64 %t2863, i1 false)
  %t2864 = load { i64, ptr }, ptr %l973, !tbaa !27
  store { i64, ptr } %t2864, ptr %l95, !tbaa !27
  br label %bb446
bb446:
  br label %bb478
bb447:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d280, i32 0, i32 1) }, ptr %l975, !tbaa !27
  %t2865 = load { i64, ptr }, ptr %l975, !tbaa !27
  store { i64, ptr } %t2865, ptr %l976, !tbaa !27
  %t2866 = load { i64, ptr }, ptr %l95, !tbaa !27
  %t2867 = extractvalue { i64, ptr } %t2866, 0
  %t2868 = load { i64, ptr }, ptr %l976, !tbaa !27
  %t2869 = extractvalue { i64, ptr } %t2868, 0
  store i64 %t2869, ptr %l978, !tbaa !24
  %t2871 = load i64, ptr %l978, !tbaa !24
  %t2872 = icmp eq i64 %t2867, %t2871
  br i1 %t2872, label %bb449, label %bb450
bb448:
  %t2874 = load i1, ptr %l13, !tbaa !21
  br i1 %t2874, label %bb452, label %bb453
bb449:
  %t2876 = getelementptr { i64, ptr }, ptr %l95, i32 0, i32 1
  %t2877 = load ptr, ptr %t2876, !tbaa !27
  %t2878 = getelementptr { i64, ptr }, ptr %l976, i32 0, i32 1
  %t2879 = load ptr, ptr %t2878, !tbaa !27
  %t2880 = load i64, ptr %l978, !tbaa !24
  %t2881 = mul i64 %t2880, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t2877, ptr %t2879, i64 %t2881, i1 false)
  br label %bb451
bb450:
  %t2882 = load { i64, ptr }, ptr %l976, !tbaa !27
  %t2883 = extractvalue { i64, ptr } %t2882, 0
  store i64 %t2883, ptr %l980, !tbaa !24
  %t2884 = load i64, ptr %l980, !tbaa !24
  %t2885 = mul i64 %t2884, 1
  %t2886 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t2885)
  %t2887 = insertvalue { i64, ptr } undef, i64 %t2884, 0
  %t2888 = insertvalue { i64, ptr } %t2887, ptr %t2886, 1
  store { i64, ptr } %t2888, ptr %l981, !tbaa !27
  %t2889 = getelementptr { i64, ptr }, ptr %l981, i32 0, i32 1
  %t2890 = load ptr, ptr %t2889, !tbaa !27
  %t2891 = getelementptr { i64, ptr }, ptr %l976, i32 0, i32 1
  %t2892 = load ptr, ptr %t2891, !tbaa !27
  %t2893 = load i64, ptr %l980, !tbaa !24
  %t2894 = mul i64 %t2893, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t2890, ptr %t2892, i64 %t2894, i1 false)
  %t2895 = load { i64, ptr }, ptr %l981, !tbaa !27
  store { i64, ptr } %t2895, ptr %l95, !tbaa !27
  br label %bb451
bb451:
  br label %bb477
bb452:
  %t2896 = getelementptr %"compiler/cabi:Way", ptr %l16, i32 0, i32 0
  %t2897 = load i32, ptr %t2896
  store i32 %t2897, ptr %l96
  %t2899 = load i32, ptr %l96
  %t2901 = trunc i64 0 to i32
  %t2902 = icmp eq i32 %t2899, %t2901
  br i1 %t2902, label %bb454, label %bb455
bb453:
  br label %bb476
bb454:
  br label %bb456
bb455:
  br label %bb462
bb456:
  store %olang.scope zeroinitializer, ptr %s117
  %t2904 = getelementptr %"compiler/cabi:Way", ptr %l16, i32 0, i32 4
  %t2905 = load { i64, ptr }, ptr %t2904, !tbaa !27
  %t2907 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s117, { i64, ptr } %t2905, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d281, i32 0, i32 1) })
  store i1 %t2907, ptr %l988
  br label %bb457
bb457:
  %t2908 = load i1, ptr %l988, !tbaa !21
  %t2909 = xor i1 %t2908, true
  br i1 %t2909, label %bb458, label %bb459
bb458:
  %t2911 = getelementptr %"compiler/cabi:Way", ptr %l16, i32 0, i32 4
  %t2912 = load { i64, ptr }, ptr %t2911, !tbaa !27
  %t2914 = extractvalue { i64, ptr } %t2912, 1
  %t2915 = extractvalue { i64, ptr } %t2912, 0
  %t2916 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d282, i32 0, i32 1) }, 1
  %t2917 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d282, i32 0, i32 1) }, 0
  %t2918 = add i64 %t2915, %t2917
  %t2919 = call ptr @__olang_scope_alloc(ptr %s117, i64 %t2918)
  call void @olang_textcopy(ptr %t2919, ptr %t2914, i64 %t2915)
  %t2920 = getelementptr i8, ptr %t2919, i64 %t2915
  call void @olang_textcopy(ptr %t2920, ptr %t2916, i64 %t2917)
  %t2921 = insertvalue { i64, ptr } undef, i64 %t2918, 0
  %t2922 = insertvalue { i64, ptr } %t2921, ptr %t2919, 1
  %t2924 = extractvalue { i64, ptr } %t2922, 0
  %t2925 = extractvalue { i64, ptr } %t2922, 1
  %t2926 = mul i64 %t2924, 1
  %t2927 = call ptr @__olang_scope_alloc(ptr %s117, i64 %t2926)
  call void @llvm.memcpy.p0.p0.i64(ptr %t2927, ptr %t2925, i64 %t2926, i1 false)
  %t2928 = insertvalue { i64, ptr } undef, i64 %t2924, 0
  %t2929 = insertvalue { i64, ptr } %t2928, ptr %t2927, 1
  store { i64, ptr } %t2929, ptr %l990, !tbaa !27
  br label %bb460
bb459:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d283, i32 0, i32 1) }, ptr %l990, !tbaa !27
  br label %bb460
bb460:
  %t2931 = load ptr, ptr %l0, !tbaa !29
  %t2932 = load i32, ptr %l12, !tbaa !23
  %t2935 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %s117, ptr %t2931, i32 %t2932)
  store { i64, ptr } %t2935, ptr %l996
  br label %bb461
bb461:
  %t2936 = load { i64, ptr }, ptr %l990, !tbaa !27
  %t2937 = extractvalue { i64, ptr } %t2936, 1
  %t2938 = extractvalue { i64, ptr } %t2936, 0
  %t2939 = load { i64, ptr }, ptr %l996, !tbaa !27
  %t2940 = extractvalue { i64, ptr } %t2939, 1
  %t2941 = extractvalue { i64, ptr } %t2939, 0
  %t2942 = add i64 %t2938, %t2941
  %t2943 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t2942)
  call void @olang_textcopy(ptr %t2943, ptr %t2937, i64 %t2938)
  %t2944 = getelementptr i8, ptr %t2943, i64 %t2938
  call void @olang_textcopy(ptr %t2944, ptr %t2940, i64 %t2941)
  %t2945 = insertvalue { i64, ptr } undef, i64 %t2942, 0
  %t2946 = insertvalue { i64, ptr } %t2945, ptr %t2943, 1
  store { i64, ptr } %t2946, ptr %l984, !tbaa !27
  call void @__olang_scope_close(ptr %s117)
  br label %bb472
bb462:
  %t2948 = load i32, ptr %l96
  %t2950 = trunc i64 1 to i32
  %t2951 = icmp eq i32 %t2948, %t2950
  br i1 %t2951, label %bb463, label %bb464
bb463:
  br label %bb465
bb464:
  br label %bb467
bb465:
  %t2954 = call { i64, ptr } @compiler_2fcabi_2ePartsType(ptr %s0, ptr %s0, ptr %l16)
  store { i64, ptr } %t2954, ptr %l1001
  br label %bb466
bb466:
  %t2955 = load { i64, ptr }, ptr %l1001, !tbaa !27
  store { i64, ptr } %t2955, ptr %l984, !tbaa !27
  br label %bb472
bb467:
  br i1 true, label %bb468, label %bb469
bb468:
  br label %bb470
bb469:
  br label %bb471
bb470:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d284, i32 0, i32 1) }, ptr %l1002, !tbaa !27
  %t2956 = load { i64, ptr }, ptr %l1002, !tbaa !27
  store { i64, ptr } %t2956, ptr %l984, !tbaa !27
  br label %bb472
bb471:
  call void @__olang_check_failed(ptr @olang_loc_752793a239a1b159_2b674a598082827d)
  unreachable
bb472:
  %t2958 = load { i64, ptr }, ptr %l95, !tbaa !27
  %t2959 = extractvalue { i64, ptr } %t2958, 0
  %t2960 = load { i64, ptr }, ptr %l984, !tbaa !27
  %t2961 = extractvalue { i64, ptr } %t2960, 0
  store i64 %t2961, ptr %l1005, !tbaa !24
  %t2963 = load i64, ptr %l1005, !tbaa !24
  %t2964 = icmp eq i64 %t2959, %t2963
  br i1 %t2964, label %bb473, label %bb474
bb473:
  %t2966 = getelementptr { i64, ptr }, ptr %l95, i32 0, i32 1
  %t2967 = load ptr, ptr %t2966, !tbaa !27
  %t2968 = getelementptr { i64, ptr }, ptr %l984, i32 0, i32 1
  %t2969 = load ptr, ptr %t2968, !tbaa !27
  %t2970 = load i64, ptr %l1005, !tbaa !24
  %t2971 = mul i64 %t2970, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t2967, ptr %t2969, i64 %t2971, i1 false)
  br label %bb475
bb474:
  %t2972 = load { i64, ptr }, ptr %l984, !tbaa !27
  store { i64, ptr } %t2972, ptr %l95, !tbaa !27
  br label %bb475
bb475:
  br label %bb476
bb476:
  br label %bb477
bb477:
  br label %bb478
bb478:
  %t2973 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t2973, ptr %l1007
  br label %bb479
bb479:
  %t2974 = load %"std/prelude/text:StringBuilder", ptr %l1007
  store %"std/prelude/text:StringBuilder" %t2974, ptr %l97
  %t2975 = load { i64, ptr }, ptr %l95, !tbaa !27
  %t2976 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t2977 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d285, i32 0, i32 1) }, 1
  %t2978 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d285, i32 0, i32 1) }, 0
  %t2980 = extractvalue { i64, ptr } %t2975, 1
  %t2981 = extractvalue { i64, ptr } %t2975, 0
  %t2982 = add i64 %t2978, %t2981
  %t2983 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d286, i32 0, i32 1) }, 1
  %t2984 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d286, i32 0, i32 1) }, 0
  %t2985 = add i64 %t2982, %t2984
  %t2987 = extractvalue { i64, ptr } %t2976, 1
  %t2988 = extractvalue { i64, ptr } %t2976, 0
  %t2989 = add i64 %t2985, %t2988
  %t2990 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d287, i32 0, i32 1) }, 1
  %t2991 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d287, i32 0, i32 1) }, 0
  %t2992 = add i64 %t2989, %t2991
  %t2993 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t2992)
  call void @olang_textcopy(ptr %t2993, ptr %t2977, i64 %t2978)
  %t2994 = getelementptr i8, ptr %t2993, i64 %t2978
  call void @olang_textcopy(ptr %t2994, ptr %t2980, i64 %t2981)
  %t2995 = getelementptr i8, ptr %t2994, i64 %t2981
  call void @olang_textcopy(ptr %t2995, ptr %t2983, i64 %t2984)
  %t2996 = getelementptr i8, ptr %t2995, i64 %t2984
  call void @olang_textcopy(ptr %t2996, ptr %t2987, i64 %t2988)
  %t2997 = getelementptr i8, ptr %t2996, i64 %t2988
  call void @olang_textcopy(ptr %t2997, ptr %t2990, i64 %t2991)
  %t2998 = insertvalue { i64, ptr } undef, i64 %t2992, 0
  %t2999 = insertvalue { i64, ptr } %t2998, ptr %t2993, 1
  %t3001 = extractvalue { i64, ptr } %t2999, 0
  %t3002 = extractvalue { i64, ptr } %t2999, 1
  %t3003 = mul i64 %t3001, 1
  %t3004 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t3003)
  call void @llvm.memcpy.p0.p0.i64(ptr %t3004, ptr %t3002, i64 %t3003, i1 false)
  %t3005 = insertvalue { i64, ptr } undef, i64 %t3001, 0
  %t3006 = insertvalue { i64, ptr } %t3005, ptr %t3004, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l97, { i64, ptr } %t3006)
  br label %bb480
bb480:
  store ptr %l17, ptr %l98, !tbaa !29
  store i64 0, ptr %l99, !tbaa !24
  store i64 0, ptr %l100, !tbaa !24
  br label %bb481
bb481:
  store %olang.scope zeroinitializer, ptr %s124
  %t3010 = load ptr, ptr %l98, !tbaa !29
  %t3011 = load i64, ptr %l99, !tbaa !24
  %t3014 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hfabcb4ab830a5416feda1aea3d8bba10(ptr %s0, ptr %t3010, i64 %t3011)
  %t3015 = extractvalue { i32, { i64, ptr } } %t3014, 1
  %t3016 = extractvalue { i32, { i64, ptr } } %t3014, 0
  store i32 %t3016, ptr %l1018
  %t3017 = icmp ne i32 %t3016, 0
  br i1 %t3017, label %bb483, label %ok.3018
ok.3018:
  store { i64, ptr } %t3015, ptr %l1017
  br label %bb482
bb482:
  %t3019 = load { i64, ptr }, ptr %l1017, !tbaa !27
  store { i64, ptr } %t3019, ptr %l1014, !tbaa !27
  br label %bb487
bb483:
  %t3020 = load i32, ptr %l1018, !tbaa !23
  %t3021 = ashr i32 %t3020, 16
  %t3023 = icmp eq i32 %t3021, 1
  br i1 %t3023, label %bb484, label %bb485
bb484:
  br label %bb486
bb485:
  call void @__olang_check_failed(ptr @olang_loc_b86588aed8d09d62_e60b6944d2effe6)
  unreachable
bb486:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s124)
  br label %bb500
bb487:
  %t3025 = load { i64, ptr }, ptr %l1014, !tbaa !27
  store { i64, ptr } %t3025, ptr %l101, !tbaa !27
  %t3026 = load { i64, ptr }, ptr %l101, !tbaa !27
  %t3028 = extractvalue { i64, ptr } %t3026, 0
  store i64 %t3028, ptr %l102, !tbaa !24
  store i64 0, ptr %l103, !tbaa !24
  br label %bb488
bb488:
  store %olang.scope zeroinitializer, ptr %s125
  %t3030 = load i64, ptr %l103, !tbaa !24
  %t3031 = load i64, ptr %l102, !tbaa !24
  %t3034 = icmp slt i64 %t3030, %t3031
  %t3036 = xor i1 %t3034, true
  br i1 %t3036, label %bb489, label %bb490
bb489:
  call void @__olang_scope_close(ptr %s125)
  br label %bb498
bb490:
  br label %bb491
bb491:
  %t3038 = load i64, ptr %l100, !tbaa !24
  %t3040 = load { i64, ptr }, ptr %l101, !tbaa !27
  store { i64, ptr } %t3040, ptr %l1028, !tbaa !27
  %t3041 = load i64, ptr %l103, !tbaa !24
  %t3043 = getelementptr { i64, ptr }, ptr %l1028, i32 0, i32 1
  %t3044 = load ptr, ptr %t3043, !tbaa !27
  %t3045 = getelementptr { i64, ptr }, ptr %t3044, i64 %t3041
  %t3046 = load { i64, ptr }, ptr %t3045, !tbaa !37
  store { i64, ptr } %t3046, ptr %l105, !tbaa !27
  %t3050 = icmp sgt i64 %t3038, 0
  br i1 %t3050, label %bb492, label %bb493
bb492:
  store %olang.scope zeroinitializer, ptr %s126
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s126, ptr %l97, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d288, i32 0, i32 1) })
  br label %bb494
bb493:
  br label %bb495
bb494:
  call void @__olang_scope_close(ptr %s126)
  br label %bb495
bb495:
  %t3053 = load { i64, ptr }, ptr %l105, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l97, { i64, ptr } %t3053)
  br label %bb496
bb496:
  call void @__olang_scope_close(ptr %s125)
  br label %bb497
bb497:
  %t3056 = load i64, ptr %l103, !tbaa !24
  %t3058 = add i64 %t3056, 1
  store i64 %t3058, ptr %l103, !tbaa !24
  %t3060 = load i64, ptr %l100, !tbaa !24
  %t3062 = add i64 %t3060, 1
  store i64 %t3062, ptr %l100, !tbaa !24
  br label %bb488
bb498:
  %t3064 = load i64, ptr %l99, !tbaa !24
  %t3065 = load i64, ptr %l102, !tbaa !24
  %t3068 = add i64 %t3064, %t3065
  store i64 %t3068, ptr %l99, !tbaa !24
  call void @__olang_scope_close(ptr %s124)
  br label %bb499
bb499:
  br label %bb481
bb500:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l97, { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d289, i32 0, i32 1) })
  br label %bb501
bb501:
  store ptr %l97, ptr %l1044, !tbaa !29
  %t3071 = load ptr, ptr %l11, !tbaa !29
  %t3073 = getelementptr %"compiler/emit:fnEm", ptr %t3071, i32 0, i32 3
  %t3075 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %s0, ptr %t3073)
  store { i64, ptr } %t3075, ptr %l1047
  br label %bb502
bb502:
  %t3076 = load ptr, ptr %l1044, !tbaa !29
  %t3077 = load { i64, ptr }, ptr %l1047, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t3076, { i64, ptr } %t3077)
  br label %bb503
bb503:
  store ptr %l97, ptr %l1048, !tbaa !29
  %t3078 = load ptr, ptr %l11, !tbaa !29
  %t3080 = getelementptr %"compiler/emit:fnEm", ptr %t3078, i32 0, i32 5
  %t3082 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %s0, ptr %t3080)
  store { i64, ptr } %t3082, ptr %l1051
  br label %bb504
bb504:
  %t3083 = load ptr, ptr %l1048, !tbaa !29
  %t3084 = load { i64, ptr }, ptr %l1051, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t3083, { i64, ptr } %t3084)
  br label %bb505
bb505:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l97, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d290, i32 0, i32 1) })
  br label %bb506
bb506:
  %t3086 = load ptr, ptr %l0, !tbaa !29
  store ptr %t3086, ptr %l1053, !tbaa !29
  %t3087 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t3087, ptr %l1054, !tbaa !27
  %t3088 = load ptr, ptr %l3, !tbaa !29
  %t3090 = getelementptr %"compiler/generic:Program", ptr %t3088, i32 0, i32 0
  %t3091 = load ptr, ptr %t3090, !tbaa !29
  %t3093 = getelementptr %"compiler/load:Loader", ptr %t3091, i32 0, i32 7
  %t3094 = load i64, ptr %t3093, !tbaa !24
  store i64 %t3094, ptr %l1057, !tbaa !24
  %t3096 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l97)
  store { i64, ptr } %t3096, ptr %l1059
  br label %bb507
bb507:
  %t3097 = load ptr, ptr %l1053, !tbaa !29
  %t3098 = load { i64, ptr }, ptr %l1054, !tbaa !27
  %t3099 = load i64, ptr %l1057, !tbaa !24
  %t3100 = load { i64, ptr }, ptr %l1059, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eitem(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %t3097, { i64, ptr } %t3098, i64 %t3099, { i64, ptr } %t3100, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d8, i32 0, i32 1) })
  br label %bb508
bb508:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/source:Span" @compiler_2femit_2ecompiler_2femit_3aEmitter_2efindTest(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca %"compiler/source:Span"
  %l8 = alloca %"compiler/source:Span"
  %l9 = alloca ptr
  %l10 = alloca %"compiler/source:Span"
  %l14 = alloca %"compiler/source:Span"
  %l22 = alloca { i64, ptr }
  %l25 = alloca ptr
  %l26 = alloca i1
  %l33 = alloca %"compiler/source:Span"
  %l35 = alloca %"compiler/source:Span"
  %l37 = alloca i1
  %l39 = alloca ptr
  %l40 = alloca i1
  %l49 = alloca %"compiler/source:Span"
  %l55 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store { i64, ptr } %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t7 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s1, i32 0, i32 0)
  store %"compiler/source:Span" %t7, ptr %l14
  br label %bb3
bb2:
  br label %bb4
bb3:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t8 = load %"compiler/source:Span", ptr %l14
  store %"compiler/source:Span" %t8, ptr %rv
  br label %ret
bb4:
  %t9 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t9, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t11 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t11, 0
  store i64 %t13, ptr %l5, !tbaa !24
  br label %bb5
bb5:
  store %olang.scope zeroinitializer, ptr %s3
  %t15 = load i64, ptr %l4, !tbaa !24
  %t16 = load i64, ptr %l5, !tbaa !24
  %t19 = icmp slt i64 %t15, %t16
  %t21 = xor i1 %t19, true
  br i1 %t21, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s3)
  br label %bb35
bb7:
  br label %bb8
bb8:
  %t23 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t23, ptr %l22, !tbaa !27
  %t24 = load i64, ptr %l4, !tbaa !24
  %t26 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr ptr, ptr %t27, i64 %t24
  %t29 = load ptr, ptr %t28, !tbaa !39
  store ptr %t29, ptr %l6, !tbaa !29
  %t31 = load ptr, ptr %l6, !tbaa !29
  store ptr %t31, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t32 = load ptr, ptr %l25, !tbaa !29
  %t33 = icmp ne ptr %t32, null
  br i1 %t33, label %bb9, label %bb10
bb9:
  %t35 = load ptr, ptr %l25, !tbaa !29
  %t36 = load i64, ptr %t35
  %t38 = icmp eq i64 %t36, 6
  store i1 %t38, ptr %l26, !tbaa !21
  br label %bb10
bb10:
  %t39 = load i1, ptr %l26, !tbaa !21
  br i1 %t39, label %bb11, label %bb12
bb11:
  %t40 = load ptr, ptr %l6, !tbaa !29
  %t42 = getelementptr { i64, [6 x i64] }, ptr %t40, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr } }, ptr %t42, i32 0, i32 0
  %t44 = load %"compiler/source:Span", ptr %t43
  store %"compiler/source:Span" %t44, ptr %l7
  %t46 = load ptr, ptr %l6, !tbaa !29
  %t48 = getelementptr { i64, [6 x i64] }, ptr %t46, i32 0, i32 1
  %t49 = getelementptr { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr } }, ptr %t48, i32 0, i32 1
  %t50 = load %"compiler/source:Span", ptr %t49
  store %"compiler/source:Span" %t50, ptr %l8
  br label %bb13
bb12:
  br label %bb18
bb13:
  %t52 = load %"compiler/source:Span", ptr %l7
  store %"compiler/source:Span" %t52, ptr %l33
  %t53 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t53, ptr %l35
  %t56 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fsource_3aSpan(ptr %l33, ptr %l35)
  store i1 %t56, ptr %l37
  br label %bb14
bb14:
  %t57 = load i1, ptr %l37, !tbaa !21
  br i1 %t57, label %bb15, label %bb16
bb15:
  %t58 = load %"compiler/source:Span", ptr %l8
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/source:Span" %t58, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  br label %bb33
bb18:
  %t60 = load ptr, ptr %l6, !tbaa !29
  store ptr %t60, ptr %l39, !tbaa !29
  store i1 false, ptr %l40, !tbaa !21
  %t61 = load ptr, ptr %l39, !tbaa !29
  %t62 = icmp ne ptr %t61, null
  br i1 %t62, label %bb19, label %bb20
bb19:
  %t64 = load ptr, ptr %l39, !tbaa !29
  %t65 = load i64, ptr %t64
  %t67 = icmp eq i64 %t65, 7
  store i1 %t67, ptr %l40, !tbaa !21
  br label %bb20
bb20:
  %t68 = load i1, ptr %l40, !tbaa !21
  br i1 %t68, label %bb21, label %bb22
bb21:
  %t69 = load ptr, ptr %l6, !tbaa !29
  %t71 = getelementptr { i64, [6 x i64] }, ptr %t69, i32 0, i32 1
  %t72 = getelementptr { %"compiler/source:Span", ptr }, ptr %t71, i32 0, i32 1
  %t73 = load ptr, ptr %t72
  store ptr %t73, ptr %l9, !tbaa !29
  br label %bb23
bb22:
  br label %bb28
bb23:
  %t76 = load ptr, ptr %l9, !tbaa !29
  %t78 = load %"compiler/source:Span", ptr %l2
  %t82 = call %"compiler/source:Span" @compiler_2femit_2ecompiler_2femit_3aEmitter_2efindTestIf(ptr %v0, ptr %v1, ptr %a0, ptr %t76, %"compiler/source:Span" %t78)
  store %"compiler/source:Span" %t82, ptr %l49
  br label %bb24
bb24:
  %t83 = load %"compiler/source:Span", ptr %l49
  store %"compiler/source:Span" %t83, ptr %l10
  %t84 = getelementptr %"compiler/source:Span", ptr %l10, i32 0, i32 1
  %t85 = load i32, ptr %t84, !tbaa !23
  %t87 = icmp sgt i32 %t85, 0
  br i1 %t87, label %bb25, label %bb26
bb25:
  %t89 = load %"compiler/source:Span", ptr %l10
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/source:Span" %t89, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  br label %bb33
bb28:
  br i1 true, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb33
bb32:
  call void @__olang_check_failed(ptr @olang_loc_89b1df4cc9c3ef97_fe8a037694fb6c2b)
  unreachable
bb33:
  call void @__olang_scope_close(ptr %s3)
  br label %bb34
bb34:
  %t91 = load i64, ptr %l4, !tbaa !24
  %t93 = add i64 %t91, 1
  store i64 %t93, ptr %l4, !tbaa !24
  br label %bb5
bb35:
  %t95 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 0, i32 0)
  store %"compiler/source:Span" %t95, ptr %l55
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s0)
  %t96 = load %"compiler/source:Span", ptr %l55
  store %"compiler/source:Span" %t96, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local %"compiler/source:Span" @compiler_2femit_2ecompiler_2femit_3aEmitter_2efindTestIf(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca %"compiler/source:Span"
  %l7 = alloca %"compiler/source:Span"
  %l12 = alloca ptr
  %l21 = alloca %"compiler/source:Span"
  %l29 = alloca ptr
  %l38 = alloca %"compiler/source:Span"
  %l46 = alloca %"compiler/source:Span"
  %s1 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t5 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s1, i32 0, i32 0)
  store %"compiler/source:Span" %t5, ptr %l7
  br label %bb3
bb2:
  br label %bb4
bb3:
  call void @__olang_scope_close(ptr %s1)
  %t6 = load %"compiler/source:Span", ptr %l7
  store %"compiler/source:Span" %t6, ptr %rv
  br label %ret
bb4:
  %t7 = load ptr, ptr %l1, !tbaa !29
  %t9 = getelementptr %"compiler/ast:TopIf", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = icmp eq ptr %t10, null
  %t14 = xor i1 %t12, true
  br i1 %t14, label %bb5, label %bb6
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l12, !tbaa !29
  %t17 = load ptr, ptr %l1, !tbaa !29
  %t19 = getelementptr %"compiler/ast:TopIf", ptr %t17, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t22 = icmp eq ptr %t20, null
  br i1 %t22, label %bb7, label %bb8
bb6:
  br label %bb14
bb7:
  call void @__olang_check_failed(ptr @olang_loc_fc56b98312278d43_1fce42e2bc631e6f)
  unreachable
bb8:
  br label %bb9
bb9:
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t26 = getelementptr %"compiler/ast:TopIf", ptr %t24, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t30 = getelementptr %"compiler/ast:TopBranch", ptr %t27, i32 0, i32 1
  %t31 = load { i64, ptr }, ptr %t30, !tbaa !27
  %t32 = load %"compiler/source:Span", ptr %l2
  %t33 = load ptr, ptr %l12, !tbaa !29
  %t36 = call %"compiler/source:Span" @compiler_2femit_2ecompiler_2femit_3aEmitter_2efindTest(ptr %v0, ptr %v1, ptr %t33, { i64, ptr } %t31, %"compiler/source:Span" %t32)
  store %"compiler/source:Span" %t36, ptr %l21
  br label %bb10
bb10:
  %t37 = load %"compiler/source:Span", ptr %l21
  store %"compiler/source:Span" %t37, ptr %l3
  %t38 = getelementptr %"compiler/source:Span", ptr %l3, i32 0, i32 1
  %t39 = load i32, ptr %t38, !tbaa !23
  %t41 = icmp sgt i32 %t39, 0
  br i1 %t41, label %bb11, label %bb12
bb11:
  %t43 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t43, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  br label %bb14
bb14:
  %t45 = load ptr, ptr %l1, !tbaa !29
  %t47 = getelementptr %"compiler/ast:TopIf", ptr %t45, i32 0, i32 3
  %t48 = load ptr, ptr %t47, !tbaa !29
  %t50 = icmp eq ptr %t48, null
  %t52 = xor i1 %t50, true
  br i1 %t52, label %bb15, label %bb16
bb15:
  %t54 = load ptr, ptr %l0, !tbaa !29
  store ptr %t54, ptr %l29, !tbaa !29
  %t55 = load ptr, ptr %l1, !tbaa !29
  %t57 = getelementptr %"compiler/ast:TopIf", ptr %t55, i32 0, i32 3
  %t58 = load ptr, ptr %t57, !tbaa !29
  %t60 = icmp eq ptr %t58, null
  br i1 %t60, label %bb17, label %bb18
bb16:
  br label %bb24
bb17:
  call void @__olang_check_failed(ptr @olang_loc_c939e30cbacc87b4_9ec3789a05f46010)
  unreachable
bb18:
  br label %bb19
bb19:
  %t62 = load ptr, ptr %l1, !tbaa !29
  %t64 = getelementptr %"compiler/ast:TopIf", ptr %t62, i32 0, i32 3
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t68 = getelementptr %"compiler/ast:TopBranch", ptr %t65, i32 0, i32 1
  %t69 = load { i64, ptr }, ptr %t68, !tbaa !27
  %t70 = load %"compiler/source:Span", ptr %l2
  %t71 = load ptr, ptr %l29, !tbaa !29
  %t74 = call %"compiler/source:Span" @compiler_2femit_2ecompiler_2femit_3aEmitter_2efindTest(ptr %v0, ptr %v1, ptr %t71, { i64, ptr } %t69, %"compiler/source:Span" %t70)
  store %"compiler/source:Span" %t74, ptr %l38
  br label %bb20
bb20:
  %t75 = load %"compiler/source:Span", ptr %l38
  store %"compiler/source:Span" %t75, ptr %l4
  %t76 = getelementptr %"compiler/source:Span", ptr %l4, i32 0, i32 1
  %t77 = load i32, ptr %t76, !tbaa !23
  %t79 = icmp sgt i32 %t77, 0
  br i1 %t79, label %bb21, label %bb22
bb21:
  %t81 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t81, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  br label %bb24
bb24:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load ptr, ptr %l1, !tbaa !29
  %t86 = getelementptr %"compiler/ast:TopIf", ptr %t84, i32 0, i32 2
  %t87 = load ptr, ptr %t86, !tbaa !29
  %t88 = load %"compiler/source:Span", ptr %l2
  %t92 = call %"compiler/source:Span" @compiler_2femit_2ecompiler_2femit_3aEmitter_2efindTestIf(ptr %v0, ptr %v1, ptr %t83, ptr %t87, %"compiler/source:Span" %t88)
  store %"compiler/source:Span" %t92, ptr %l46
  br label %bb25
bb25:
  %t93 = load %"compiler/source:Span", ptr %l46
  store %"compiler/source:Span" %t93, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3aEmitter_2efunction(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [2 x i64] }
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i1
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca ptr
  %l9 = alloca %"std/prelude/text:StringBuilder"
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l13 = alloca ptr
  %l16 = alloca i64
  %l17 = alloca i1
  %l23 = alloca %"compiler/mir:Fn"
  %l27 = alloca { i64, ptr }
  %l30 = alloca i1
  %l35 = alloca i64
  %l36 = alloca ptr
  %l37 = alloca { i64, [2 x i64] }
  %l39 = alloca i32
  %l40 = alloca { i64, ptr }
  %l41 = alloca i64
  %l42 = alloca i1
  %l45 = alloca i64
  %l46 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l52 = alloca i1
  %l56 = alloca { i64, ptr }
  %l60 = alloca { i64, ptr }
  %l65 = alloca i1
  %l67 = alloca i1
  %l69 = alloca ptr
  %l70 = alloca { i64, ptr }
  %l72 = alloca i1
  %l74 = alloca { i64, ptr }
  %l76 = alloca { i64, ptr }
  %l83 = alloca i1
  %l95 = alloca ptr
  %l96 = alloca { i64, [2 x i64] }
  %l98 = alloca i32
  %l99 = alloca { i64, ptr }
  %l100 = alloca i64
  %l101 = alloca i1
  %l102 = alloca { i64, ptr }
  %l105 = alloca { i64, ptr }
  %l111 = alloca %"compiler/emit:fnEm"
  %l128 = alloca ptr
  %l129 = alloca { i64, [2 x i64] }
  %l131 = alloca i32
  %l132 = alloca { i64, ptr }
  %l133 = alloca i64
  %l134 = alloca i1
  %l135 = alloca { i64, ptr }
  %l138 = alloca { i64, ptr }
  %l141 = alloca %"std/prelude/text:StringBuilder"
  %l145 = alloca { i64, ptr }
  %l147 = alloca i64
  %l152 = alloca ptr
  %l155 = alloca i64
  %l156 = alloca i64
  %l169 = alloca ptr
  %l172 = alloca { i64, ptr }
  %l173 = alloca ptr
  %l176 = alloca { i64, ptr }
  %l183 = alloca ptr
  %l186 = alloca { i64, ptr }
  %l188 = alloca ptr
  %l191 = alloca { i64, ptr }
  %l202 = alloca { i64, ptr }
  %l207 = alloca { i64, ptr }
  %l208 = alloca ptr
  %l209 = alloca { i64, [2 x i64] }
  %l211 = alloca i32
  %l212 = alloca { i64, ptr }
  %l213 = alloca i64
  %l214 = alloca i1
  %l215 = alloca { i64, ptr }
  %l217 = alloca { i64, ptr }
  %l220 = alloca i64
  %l221 = alloca { i64, ptr }
  %l225 = alloca ptr
  %l226 = alloca { i64, [2 x i64] }
  %l228 = alloca i32
  %l229 = alloca { i64, ptr }
  %l230 = alloca i64
  %l231 = alloca i1
  %l233 = alloca { i64, ptr }
  %l236 = alloca i64
  %l237 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %t22 = alloca %"compiler/mir:Fn", align 8
  %t272 = alloca %"compiler/emit:fnEm", align 8
  store ptr %a0, ptr %l0
  store { i64, [2 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 61
  store ptr %t3, ptr %l13, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t5 = load { i64, [2 x i64] }, ptr %l1
  %t8 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ehomeOf(ptr %v0, ptr %t4, { i64, [2 x i64] } %t5)
  store i64 %t8, ptr %l16
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l13, !tbaa !29
  %t10 = load i64, ptr %l16, !tbaa !24
  %t11 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %t9, i64 %t10)
  store i1 %t11, ptr %l17
  br label %bb2
bb2:
  %t12 = load i1, ptr %l17, !tbaa !21
  br i1 %t12, label %bb3, label %bb4
bb3:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load { i64, [2 x i64] }, ptr %l1
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclared(ptr %v0, ptr %t13, { i64, [2 x i64] } %t14)
  br label %bb5
bb4:
  br label %bb6
bb5:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb6:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/emit:Emitter", ptr %t17, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t21 = load { i64, [2 x i64] }, ptr %l1
  call void @compiler_2flower_2ecompiler_2flower_3aLowerer_2eLowerKey(ptr %t22, ptr %v0, ptr %v0, ptr %t20, { i64, [2 x i64] } %t21)
  call void @llvm.memmove.p0.p0.i64(ptr %l23, ptr %t22, i64 232, i1 false)
  br label %bb7
bb7:
  %t25 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 232, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t25, ptr %l23, i64 232, i1 false)
  store ptr %t25, ptr %l2, !tbaa !29
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load { i64, [2 x i64] }, ptr %l1
  %t31 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2esym(ptr %v0, ptr %s0, ptr %t27, { i64, [2 x i64] } %t28)
  store { i64, ptr } %t31, ptr %l27
  br label %bb8
bb8:
  %t32 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t32, ptr %l3, !tbaa !27
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load { i64, [2 x i64] }, ptr %l1
  %t37 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ehasEnv(ptr %v0, ptr %t33, { i64, [2 x i64] } %t34)
  store i1 %t37, ptr %l30
  br label %bb9
bb9:
  %t38 = load i1, ptr %l30, !tbaa !21
  store i1 %t38, ptr %l4, !tbaa !21
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load { i64, [2 x i64] }, ptr %l1
  %t41 = load ptr, ptr %l2, !tbaa !29
  %t43 = getelementptr %"compiler/mir:Fn", ptr %t41, i32 0, i32 1
  %t44 = load i32, ptr %t43, !tbaa !23
  %t48 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2epassedOf(ptr %v0, ptr %t39, { i64, [2 x i64] } %t40, i32 %t44)
  store i64 %t48, ptr %l35
  br label %bb10
bb10:
  %t49 = load i64, ptr %l35, !tbaa !24
  store i64 %t49, ptr %l5, !tbaa !24
  %t50 = load ptr, ptr %l0, !tbaa !29
  store ptr %t50, ptr %l36, !tbaa !29
  %t51 = load { i64, [2 x i64] }, ptr %l1
  store { i64, [2 x i64] } %t51, ptr %l37
  %t52 = load ptr, ptr %l2, !tbaa !29
  %t54 = getelementptr %"compiler/mir:Fn", ptr %t52, i32 0, i32 1
  %t55 = load i32, ptr %t54, !tbaa !23
  store i32 %t55, ptr %l39, !tbaa !23
  %t56 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t56, ptr %l40, !tbaa !27
  %t57 = load i64, ptr %l5, !tbaa !24
  store i64 %t57, ptr %l41, !tbaa !24
  %t58 = load i1, ptr %l4, !tbaa !21
  store i1 %t58, ptr %l42, !tbaa !21
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = load { i64, [2 x i64] }, ptr %l1
  %t63 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ehomeOf(ptr %v0, ptr %t59, { i64, [2 x i64] } %t60)
  store i64 %t63, ptr %l45
  br label %bb11
bb11:
  %t64 = load i64, ptr %l45, !tbaa !24
  %t65 = call { i64, ptr } @compiler_2femit_2elinkFor(ptr %s0, i64 %t64)
  store { i64, ptr } %t65, ptr %l46
  br label %bb12
bb12:
  %t66 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t67 = extractvalue { i64, ptr } %t66, 0
  %t68 = extractvalue { i64, ptr } %t66, 1
  %t69 = mul i64 %t67, 1
  %t70 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t69)
  call void @llvm.memcpy.p0.p0.i64(ptr %t70, ptr %t68, i64 %t69, i1 false)
  %t71 = insertvalue { i64, ptr } undef, i64 %t67, 0
  %t72 = insertvalue { i64, ptr } %t71, ptr %t70, 1
  %t73 = load ptr, ptr %l36, !tbaa !29
  %t74 = load { i64, [2 x i64] }, ptr %l37
  %t75 = load i32, ptr %l39, !tbaa !23
  %t76 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t77 = load i64, ptr %l41, !tbaa !24
  %t78 = load i1, ptr %l42, !tbaa !21
  %t80 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eheader(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %t73, { i64, [2 x i64] } %t74, i32 %t75, { i64, ptr } %t76, i64 %t77, i1 %t78, { i64, ptr } %t72)
  store { i64, ptr } %t80, ptr %l48
  br label %bb13
bb13:
  %t81 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t81, ptr %l6, !tbaa !27
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/emit:Emitter", ptr %t82, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !29
  %t87 = getelementptr %"compiler/lower:Lowerer", ptr %t85, i32 0, i32 5
  %t88 = load i1, ptr %t87, !tbaa !21
  br i1 %t88, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l52, !tbaa !21
  br label %bb16
bb15:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/emit:Emitter", ptr %t90, i32 0, i32 7
  %t93 = load i1, ptr %t92, !tbaa !21
  %t95 = xor i1 %t93, true
  store i1 %t95, ptr %l52, !tbaa !21
  br label %bb16
bb16:
  %t97 = load i1, ptr %l52, !tbaa !21
  br i1 %t97, label %bb17, label %bb18
bb17:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d291, i32 0, i32 1) }, ptr %l56, !tbaa !27
  br label %bb20
bb18:
  %t98 = load ptr, ptr %l2, !tbaa !29
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/emit:Emitter", ptr %t99, i32 0, i32 3
  %t102 = load ptr, ptr %t101, !tbaa !29
  %t105 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3aFn_2eVerify(ptr %v0, ptr %v0, ptr %s0, ptr %t98, ptr %t102)
  store { i64, ptr } %t105, ptr %l60
  br label %bb19
bb19:
  %t106 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t107 = extractvalue { i64, ptr } %t106, 0
  %t108 = extractvalue { i64, ptr } %t106, 1
  %t109 = mul i64 %t107, 1
  %t110 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t109)
  call void @llvm.memcpy.p0.p0.i64(ptr %t110, ptr %t108, i64 %t109, i1 false)
  %t111 = insertvalue { i64, ptr } undef, i64 %t107, 0
  %t112 = insertvalue { i64, ptr } %t111, ptr %t110, 1
  store { i64, ptr } %t112, ptr %l56, !tbaa !27
  br label %bb20
bb20:
  %t114 = load { i64, ptr }, ptr %l56, !tbaa !27
  store { i64, ptr } %t114, ptr %l7, !tbaa !27
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"compiler/emit:Emitter", ptr %t115, i32 0, i32 1
  %t118 = load ptr, ptr %t117, !tbaa !29
  %t120 = getelementptr %"compiler/lower:Lowerer", ptr %t118, i32 0, i32 5
  %t121 = load i1, ptr %t120, !tbaa !21
  br i1 %t121, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l65, !tbaa !21
  br label %bb24
bb22:
  %t123 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t125 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t123, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d292, i32 0, i32 1) })
  store i1 %t125, ptr %l67
  br label %bb23
bb23:
  %t126 = load i1, ptr %l67, !tbaa !21
  %t127 = xor i1 %t126, true
  store i1 %t127, ptr %l65, !tbaa !21
  br label %bb24
bb24:
  %t129 = load i1, ptr %l65, !tbaa !21
  br i1 %t129, label %bb25, label %bb26
bb25:
  store %olang.scope zeroinitializer, ptr %s2
  %t130 = load ptr, ptr %l0, !tbaa !29
  store ptr %t130, ptr %l69, !tbaa !29
  %t131 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t131, ptr %l70, !tbaa !27
  %t132 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t134 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s2, { i64, ptr } %t132, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d293, i32 0, i32 1) })
  store i1 %t134, ptr %l72
  br label %bb27
bb26:
  br label %bb41
bb27:
  %t135 = load i1, ptr %l72, !tbaa !21
  %t136 = xor i1 %t135, true
  br i1 %t136, label %bb28, label %bb29
bb28:
  %t138 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t140 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %s0, { i64, ptr } %t138)
  store { i64, ptr } %t140, ptr %l76
  br label %bb30
bb29:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d294, i32 0, i32 1) }, ptr %l74, !tbaa !27
  br label %bb31
bb30:
  %t141 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d295, i32 0, i32 1) }, 1
  %t142 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d295, i32 0, i32 1) }, 0
  %t143 = load { i64, ptr }, ptr %l76, !tbaa !27
  %t144 = extractvalue { i64, ptr } %t143, 1
  %t145 = extractvalue { i64, ptr } %t143, 0
  %t146 = add i64 %t142, %t145
  %t147 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d296, i32 0, i32 1) }, 1
  %t148 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d296, i32 0, i32 1) }, 0
  %t149 = add i64 %t146, %t148
  %t150 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t149)
  call void @olang_textcopy(ptr %t150, ptr %t141, i64 %t142)
  %t151 = getelementptr i8, ptr %t150, i64 %t142
  call void @olang_textcopy(ptr %t151, ptr %t144, i64 %t145)
  %t152 = getelementptr i8, ptr %t151, i64 %t145
  call void @olang_textcopy(ptr %t152, ptr %t147, i64 %t148)
  %t153 = insertvalue { i64, ptr } undef, i64 %t149, 0
  %t154 = insertvalue { i64, ptr } %t153, ptr %t150, 1
  %t156 = extractvalue { i64, ptr } %t154, 0
  %t157 = extractvalue { i64, ptr } %t154, 1
  %t158 = mul i64 %t156, 1
  %t159 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t158)
  call void @llvm.memcpy.p0.p0.i64(ptr %t159, ptr %t157, i64 %t158, i1 false)
  %t160 = insertvalue { i64, ptr } undef, i64 %t156, 0
  %t161 = insertvalue { i64, ptr } %t160, ptr %t159, 1
  store { i64, ptr } %t161, ptr %l74, !tbaa !27
  br label %bb31
bb31:
  %t163 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d297, i32 0, i32 1) }, 1
  %t164 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d297, i32 0, i32 1) }, 0
  %t165 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t166 = extractvalue { i64, ptr } %t165, 1
  %t167 = extractvalue { i64, ptr } %t165, 0
  %t168 = add i64 %t164, %t167
  %t169 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t170 = extractvalue { i64, ptr } %t169, 1
  %t171 = extractvalue { i64, ptr } %t169, 0
  %t172 = add i64 %t168, %t171
  %t173 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t172)
  call void @olang_textcopy(ptr %t173, ptr %t163, i64 %t164)
  %t174 = getelementptr i8, ptr %t173, i64 %t164
  call void @olang_textcopy(ptr %t174, ptr %t166, i64 %t167)
  %t175 = getelementptr i8, ptr %t174, i64 %t167
  call void @olang_textcopy(ptr %t175, ptr %t170, i64 %t171)
  %t176 = insertvalue { i64, ptr } undef, i64 %t172, 0
  %t177 = insertvalue { i64, ptr } %t176, ptr %t173, 1
  %t179 = extractvalue { i64, ptr } %t177, 0
  %t180 = extractvalue { i64, ptr } %t177, 1
  %t181 = mul i64 %t179, 1
  %t182 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t181)
  call void @llvm.memcpy.p0.p0.i64(ptr %t182, ptr %t180, i64 %t181, i1 false)
  %t183 = insertvalue { i64, ptr } undef, i64 %t179, 0
  %t184 = insertvalue { i64, ptr } %t183, ptr %t182, 1
  %t185 = load ptr, ptr %l69, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2egap(ptr %v0, ptr %s2, ptr %t185, { i64, ptr } %t184)
  br label %bb32
bb32:
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t188 = load { i64, [2 x i64] }, ptr %l1
  %t191 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eisGlobalInit(ptr %v0, ptr %t187, { i64, [2 x i64] } %t188)
  store i1 %t191, ptr %l83
  br label %bb33
bb33:
  %t192 = load i1, ptr %l83, !tbaa !21
  br i1 %t192, label %bb34, label %bb35
bb34:
  store %olang.scope zeroinitializer, ptr %s5
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t194 = load { i64, [2 x i64] }, ptr %l1
  %t195 = load ptr, ptr %l2, !tbaa !29
  %t197 = getelementptr %"compiler/mir:Fn", ptr %t195, i32 0, i32 1
  %t198 = load i32, ptr %t197, !tbaa !23
  %t199 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t200 = load i64, ptr %l5, !tbaa !24
  %t201 = load i1, ptr %l4, !tbaa !21
  %t202 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t204 = extractvalue { i64, ptr } %t202, 1
  %t205 = extractvalue { i64, ptr } %t202, 0
  %t206 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d298, i32 0, i32 1) }, 1
  %t207 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d298, i32 0, i32 1) }, 0
  %t208 = add i64 %t205, %t207
  %t209 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t208)
  call void @olang_textcopy(ptr %t209, ptr %t204, i64 %t205)
  %t210 = getelementptr i8, ptr %t209, i64 %t205
  call void @olang_textcopy(ptr %t210, ptr %t206, i64 %t207)
  %t211 = insertvalue { i64, ptr } undef, i64 %t208, 0
  %t212 = insertvalue { i64, ptr } %t211, ptr %t209, 1
  %t214 = extractvalue { i64, ptr } %t212, 0
  %t215 = extractvalue { i64, ptr } %t212, 1
  %t216 = mul i64 %t214, 1
  %t217 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t216)
  call void @llvm.memcpy.p0.p0.i64(ptr %t217, ptr %t215, i64 %t216, i1 false)
  %t218 = insertvalue { i64, ptr } undef, i64 %t214, 0
  %t219 = insertvalue { i64, ptr } %t218, ptr %t217, 1
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2efnItem(ptr %v0, ptr %s0, ptr %s5, ptr %t193, { i64, [2 x i64] } %t194, i32 %t198, { i64, ptr } %t199, i64 %t200, i1 %t201, { i64, ptr } %t219)
  br label %bb36
bb35:
  br label %bb37
bb36:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb37:
  %t227 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %s2, ptr %t227, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d299, i32 0, i32 1) })
  br label %bb38
bb38:
  %t229 = load ptr, ptr %l0, !tbaa !29
  store ptr %t229, ptr %l95, !tbaa !29
  %t230 = load { i64, [2 x i64] }, ptr %l1
  store { i64, [2 x i64] } %t230, ptr %l96
  %t231 = load ptr, ptr %l2, !tbaa !29
  %t233 = getelementptr %"compiler/mir:Fn", ptr %t231, i32 0, i32 1
  %t234 = load i32, ptr %t233, !tbaa !23
  store i32 %t234, ptr %l98, !tbaa !23
  %t235 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t235, ptr %l99, !tbaa !27
  %t236 = load i64, ptr %l5, !tbaa !24
  store i64 %t236, ptr %l100, !tbaa !24
  %t237 = load i1, ptr %l4, !tbaa !21
  store i1 %t237, ptr %l101, !tbaa !21
  %t238 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t238, ptr %l102, !tbaa !27
  %t239 = load ptr, ptr %l0, !tbaa !29
  %t240 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t243 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2estub(ptr %v0, ptr %s2, ptr %s0, ptr %s2, ptr %t239, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d300, i32 0, i32 1) }, { i64, ptr } %t240)
  store { i64, ptr } %t243, ptr %l105
  br label %bb39
bb39:
  %t244 = load { i64, ptr }, ptr %l102, !tbaa !27
  %t245 = extractvalue { i64, ptr } %t244, 1
  %t246 = extractvalue { i64, ptr } %t244, 0
  %t247 = load { i64, ptr }, ptr %l105, !tbaa !27
  %t248 = extractvalue { i64, ptr } %t247, 1
  %t249 = extractvalue { i64, ptr } %t247, 0
  %t250 = add i64 %t246, %t249
  %t251 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t250)
  call void @olang_textcopy(ptr %t251, ptr %t245, i64 %t246)
  %t252 = getelementptr i8, ptr %t251, i64 %t246
  call void @olang_textcopy(ptr %t252, ptr %t248, i64 %t249)
  %t253 = insertvalue { i64, ptr } undef, i64 %t250, 0
  %t254 = insertvalue { i64, ptr } %t253, ptr %t251, 1
  %t256 = extractvalue { i64, ptr } %t254, 0
  %t257 = extractvalue { i64, ptr } %t254, 1
  %t258 = mul i64 %t256, 1
  %t259 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t258)
  call void @llvm.memcpy.p0.p0.i64(ptr %t259, ptr %t257, i64 %t258, i1 false)
  %t260 = insertvalue { i64, ptr } undef, i64 %t256, 0
  %t261 = insertvalue { i64, ptr } %t260, ptr %t259, 1
  %t262 = load ptr, ptr %l95, !tbaa !29
  %t263 = load { i64, [2 x i64] }, ptr %l96
  %t264 = load i32, ptr %l98, !tbaa !23
  %t265 = load { i64, ptr }, ptr %l99, !tbaa !27
  %t266 = load i64, ptr %l100, !tbaa !24
  %t267 = load i1, ptr %l101, !tbaa !21
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2efnItem(ptr %v0, ptr %s0, ptr %s2, ptr %t262, { i64, [2 x i64] } %t263, i32 %t264, { i64, ptr } %t265, i64 %t266, i1 %t267, { i64, ptr } %t261)
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb41:
  %t269 = load ptr, ptr %l0, !tbaa !29
  %t270 = load ptr, ptr %l2, !tbaa !29
  %t271 = load { i64, [2 x i64] }, ptr %l1
  call void @compiler_2femit_3afnEm_2ector(ptr %t272, ptr %v0, ptr %v0, ptr %v0, ptr %t269, ptr %t270, { i64, [2 x i64] } %t271)
  call void @llvm.memmove.p0.p0.i64(ptr %l111, ptr %t272, i64 240, i1 false)
  br label %bb42
bb42:
  %t276 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 240, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t276, ptr %l111, i64 240, i1 false)
  store ptr %t276, ptr %l8, !tbaa !29
  %t278 = load ptr, ptr %l8, !tbaa !29
  %t279 = load i64, ptr %l5, !tbaa !24
  %t282 = getelementptr %"compiler/emit:fnEm", ptr %t278, i32 0, i32 7
  store i64 %t279, ptr %t282, !tbaa !24
  %t283 = load ptr, ptr %l8, !tbaa !29
  %t284 = load i1, ptr %l4, !tbaa !21
  %t287 = getelementptr %"compiler/emit:fnEm", ptr %t283, i32 0, i32 12
  store i1 %t284, ptr %t287, !tbaa !21
  %t288 = load ptr, ptr %l8, !tbaa !29
  %t289 = load ptr, ptr %l2, !tbaa !29
  %t291 = getelementptr %"compiler/mir:Fn", ptr %t289, i32 0, i32 25
  %t292 = load i1, ptr %t291, !tbaa !21
  %t295 = getelementptr %"compiler/emit:fnEm", ptr %t288, i32 0, i32 27
  store i1 %t292, ptr %t295, !tbaa !21
  %t296 = load ptr, ptr %l0, !tbaa !29
  %t298 = getelementptr %"compiler/emit:Emitter", ptr %t296, i32 0, i32 23
  store i1 false, ptr %t298, !tbaa !21
  %t299 = load ptr, ptr %l0, !tbaa !29
  %t301 = getelementptr %"compiler/emit:Emitter", ptr %t299, i32 0, i32 5
  %t302 = load i1, ptr %t301, !tbaa !21
  br i1 %t302, label %bb43, label %bb44
bb43:
  %t304 = load ptr, ptr %l8, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2esubprogram(ptr %v0, ptr %t304)
  br label %bb45
bb44:
  br label %bb46
bb45:
  br label %bb46
bb46:
  %t306 = load ptr, ptr %l8, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2erun(ptr %v0, ptr %t306)
  br label %bb47
bb47:
  %t308 = load ptr, ptr %l0, !tbaa !29
  %t310 = getelementptr %"compiler/emit:Emitter", ptr %t308, i32 0, i32 23
  %t311 = load i1, ptr %t310, !tbaa !21
  br i1 %t311, label %bb48, label %bb49
bb48:
  store %olang.scope zeroinitializer, ptr %s9
  %t313 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %s9, ptr %t313, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d301, i32 0, i32 1) })
  br label %bb50
bb49:
  br label %bb53
bb50:
  %t315 = load ptr, ptr %l0, !tbaa !29
  store ptr %t315, ptr %l128, !tbaa !29
  %t316 = load { i64, [2 x i64] }, ptr %l1
  store { i64, [2 x i64] } %t316, ptr %l129
  %t317 = load ptr, ptr %l2, !tbaa !29
  %t319 = getelementptr %"compiler/mir:Fn", ptr %t317, i32 0, i32 1
  %t320 = load i32, ptr %t319, !tbaa !23
  store i32 %t320, ptr %l131, !tbaa !23
  %t321 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t321, ptr %l132, !tbaa !27
  %t322 = load i64, ptr %l5, !tbaa !24
  store i64 %t322, ptr %l133, !tbaa !24
  %t323 = load i1, ptr %l4, !tbaa !21
  store i1 %t323, ptr %l134, !tbaa !21
  %t324 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t324, ptr %l135, !tbaa !27
  %t325 = load ptr, ptr %l0, !tbaa !29
  %t326 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t329 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2estub(ptr %v0, ptr %s9, ptr %s0, ptr %s9, ptr %t325, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d302, i32 0, i32 1) }, { i64, ptr } %t326)
  store { i64, ptr } %t329, ptr %l138
  br label %bb51
bb51:
  %t330 = load { i64, ptr }, ptr %l135, !tbaa !27
  %t331 = extractvalue { i64, ptr } %t330, 1
  %t332 = extractvalue { i64, ptr } %t330, 0
  %t333 = load { i64, ptr }, ptr %l138, !tbaa !27
  %t334 = extractvalue { i64, ptr } %t333, 1
  %t335 = extractvalue { i64, ptr } %t333, 0
  %t336 = add i64 %t332, %t335
  %t337 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t336)
  call void @olang_textcopy(ptr %t337, ptr %t331, i64 %t332)
  %t338 = getelementptr i8, ptr %t337, i64 %t332
  call void @olang_textcopy(ptr %t338, ptr %t334, i64 %t335)
  %t339 = insertvalue { i64, ptr } undef, i64 %t336, 0
  %t340 = insertvalue { i64, ptr } %t339, ptr %t337, 1
  %t342 = extractvalue { i64, ptr } %t340, 0
  %t343 = extractvalue { i64, ptr } %t340, 1
  %t344 = mul i64 %t342, 1
  %t345 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t344)
  call void @llvm.memcpy.p0.p0.i64(ptr %t345, ptr %t343, i64 %t344, i1 false)
  %t346 = insertvalue { i64, ptr } undef, i64 %t342, 0
  %t347 = insertvalue { i64, ptr } %t346, ptr %t345, 1
  %t348 = load ptr, ptr %l128, !tbaa !29
  %t349 = load { i64, [2 x i64] }, ptr %l129
  %t350 = load i32, ptr %l131, !tbaa !23
  %t351 = load { i64, ptr }, ptr %l132, !tbaa !27
  %t352 = load i64, ptr %l133, !tbaa !24
  %t353 = load i1, ptr %l134, !tbaa !21
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2efnItem(ptr %v0, ptr %s0, ptr %s9, ptr %t348, { i64, [2 x i64] } %t349, i32 %t350, { i64, ptr } %t351, i64 %t352, i1 %t353, { i64, ptr } %t347)
  br label %bb52
bb52:
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb53:
  %t355 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t355, ptr %l141
  br label %bb54
bb54:
  %t356 = load %"std/prelude/text:StringBuilder", ptr %l141
  store %"std/prelude/text:StringBuilder" %t356, ptr %l9
  %t357 = load ptr, ptr %l8, !tbaa !29
  %t359 = getelementptr %"compiler/emit:fnEm", ptr %t357, i32 0, i32 27
  %t360 = load i1, ptr %t359, !tbaa !21
  br i1 %t360, label %bb55, label %bb56
bb55:
  %t362 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t363 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d303, i32 0, i32 1) }, 1
  %t364 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d303, i32 0, i32 1) }, 0
  %t366 = extractvalue { i64, ptr } %t362, 1
  %t367 = extractvalue { i64, ptr } %t362, 0
  %t368 = add i64 %t364, %t367
  %t369 = extractvalue { i64, ptr } { i64 50, ptr getelementptr inbounds (<{ i64, [50 x i8] }>, ptr @.d304, i32 0, i32 1) }, 1
  %t370 = extractvalue { i64, ptr } { i64 50, ptr getelementptr inbounds (<{ i64, [50 x i8] }>, ptr @.d304, i32 0, i32 1) }, 0
  %t371 = add i64 %t368, %t370
  %t372 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t371)
  call void @olang_textcopy(ptr %t372, ptr %t363, i64 %t364)
  %t373 = getelementptr i8, ptr %t372, i64 %t364
  call void @olang_textcopy(ptr %t373, ptr %t366, i64 %t367)
  %t374 = getelementptr i8, ptr %t373, i64 %t367
  call void @olang_textcopy(ptr %t374, ptr %t369, i64 %t370)
  %t375 = insertvalue { i64, ptr } undef, i64 %t371, 0
  %t376 = insertvalue { i64, ptr } %t375, ptr %t372, 1
  store { i64, ptr } %t376, ptr %l145, !tbaa !27
  %t377 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t378 = extractvalue { i64, ptr } %t377, 0
  %t379 = load { i64, ptr }, ptr %l145, !tbaa !27
  %t380 = extractvalue { i64, ptr } %t379, 0
  store i64 %t380, ptr %l147, !tbaa !24
  %t382 = load i64, ptr %l147, !tbaa !24
  %t383 = icmp eq i64 %t378, %t382
  br i1 %t383, label %bb57, label %bb58
bb56:
  br label %bb60
bb57:
  %t385 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t386 = load ptr, ptr %t385, !tbaa !27
  %t387 = getelementptr { i64, ptr }, ptr %l145, i32 0, i32 1
  %t388 = load ptr, ptr %t387, !tbaa !27
  %t389 = load i64, ptr %l147, !tbaa !24
  %t390 = mul i64 %t389, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t386, ptr %t388, i64 %t390, i1 false)
  br label %bb59
bb58:
  %t391 = load { i64, ptr }, ptr %l145, !tbaa !27
  store { i64, ptr } %t391, ptr %l6, !tbaa !27
  br label %bb59
bb59:
  br label %bb60
bb60:
  %t392 = load ptr, ptr %l8, !tbaa !29
  %t394 = getelementptr %"compiler/emit:fnEm", ptr %t392, i32 0, i32 17
  %t395 = load i64, ptr %t394, !tbaa !24
  %t397 = icmp sge i64 %t395, 0
  br i1 %t397, label %bb61, label %bb62
bb61:
  store %olang.scope zeroinitializer, ptr %s13
  store ptr %l9, ptr %l152, !tbaa !29
  %t399 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t401 = extractvalue { i64, ptr } %t399, 0
  %t403 = sub i64 %t401, 2
  store i64 %t403, ptr %l155, !tbaa !24
  %t404 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t405 = extractvalue { i64, ptr } %t404, 0
  store i64 %t405, ptr %l156, !tbaa !24
  %t406 = icmp sge i64 0, 0
  br i1 %t406, label %bb63, label %bb64
bb62:
  %t408 = load { i64, ptr }, ptr %l6, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l9, { i64, ptr } %t408)
  br label %bb71
bb63:
  %t411 = load i64, ptr %l155, !tbaa !24
  %t412 = icmp sle i64 0, %t411
  br i1 %t412, label %bb65, label %bb66
bb64:
  call void @__olang_check_failed(ptr @olang_loc_6b15eaaa16ffdc11_37cb8c68772d91a5)
  unreachable
bb65:
  %t414 = load i64, ptr %l155, !tbaa !24
  %t415 = load i64, ptr %l156, !tbaa !24
  %t416 = icmp sle i64 %t414, %t415
  br i1 %t416, label %bb67, label %bb68
bb66:
  call void @__olang_check_failed(ptr @olang_loc_6b15eaaa16ffdc11_37cb8c68772d91a5)
  unreachable
bb67:
  %t418 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t419 = load ptr, ptr %t418, !tbaa !27
  %t420 = load i64, ptr %l155, !tbaa !24
  %t421 = getelementptr i8, ptr %t419, i64 0
  %t422 = sub i64 %t420, 0
  %t423 = insertvalue { i64, ptr } undef, i64 %t422, 0
  %t424 = insertvalue { i64, ptr } %t423, ptr %t421, 1
  %t425 = load ptr, ptr %l152, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t425, { i64, ptr } %t424)
  br label %bb69
bb68:
  call void @__olang_check_failed(ptr @olang_loc_6b15eaaa16ffdc11_37cb8c68772d91a5)
  unreachable
bb69:
  %t427 = load ptr, ptr %l8, !tbaa !29
  %t429 = getelementptr %"compiler/emit:fnEm", ptr %t427, i32 0, i32 17
  %t430 = load i64, ptr %t429, !tbaa !24
  %t431 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d305, i32 0, i32 1) }, 1
  %t432 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d305, i32 0, i32 1) }, 0
  %t434 = call i64 @__olang_fmt_i64(ptr null, i64 %t430)
  %t435 = add i64 %t432, %t434
  %t436 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d306, i32 0, i32 1) }, 1
  %t437 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d306, i32 0, i32 1) }, 0
  %t438 = add i64 %t435, %t437
  %t439 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t438)
  call void @olang_textcopy(ptr %t439, ptr %t431, i64 %t432)
  %t440 = getelementptr i8, ptr %t439, i64 %t432
  %t441 = call i64 @__olang_fmt_i64(ptr %t440, i64 %t430)
  %t442 = getelementptr i8, ptr %t440, i64 %t434
  call void @olang_textcopy(ptr %t442, ptr %t436, i64 %t437)
  %t443 = insertvalue { i64, ptr } undef, i64 %t438, 0
  %t444 = insertvalue { i64, ptr } %t443, ptr %t439, 1
  %t446 = extractvalue { i64, ptr } %t444, 0
  %t447 = extractvalue { i64, ptr } %t444, 1
  %t448 = mul i64 %t446, 1
  %t449 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t448)
  call void @llvm.memcpy.p0.p0.i64(ptr %t449, ptr %t447, i64 %t448, i1 false)
  %t450 = insertvalue { i64, ptr } undef, i64 %t446, 0
  %t451 = insertvalue { i64, ptr } %t450, ptr %t449, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s13, ptr %l9, { i64, ptr } %t451)
  br label %bb70
bb70:
  call void @__olang_scope_close(ptr %s13)
  br label %bb72
bb71:
  br label %bb72
bb72:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l9, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d307, i32 0, i32 1) })
  br label %bb73
bb73:
  store ptr %l9, ptr %l169, !tbaa !29
  %t455 = load ptr, ptr %l8, !tbaa !29
  %t457 = getelementptr %"compiler/emit:fnEm", ptr %t455, i32 0, i32 3
  %t459 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %s0, ptr %t457)
  store { i64, ptr } %t459, ptr %l172
  br label %bb74
bb74:
  %t460 = load ptr, ptr %l169, !tbaa !29
  %t461 = load { i64, ptr }, ptr %l172, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t460, { i64, ptr } %t461)
  br label %bb75
bb75:
  store ptr %l9, ptr %l173, !tbaa !29
  %t462 = load ptr, ptr %l8, !tbaa !29
  %t464 = getelementptr %"compiler/emit:fnEm", ptr %t462, i32 0, i32 4
  %t466 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %s0, ptr %t464)
  store { i64, ptr } %t466, ptr %l176
  br label %bb76
bb76:
  %t467 = load ptr, ptr %l173, !tbaa !29
  %t468 = load { i64, ptr }, ptr %l176, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t467, { i64, ptr } %t468)
  br label %bb77
bb77:
  %t469 = load ptr, ptr %l8, !tbaa !29
  %t471 = getelementptr %"compiler/emit:fnEm", ptr %t469, i32 0, i32 17
  %t472 = load i64, ptr %t471, !tbaa !24
  %t474 = icmp sge i64 %t472, 0
  br i1 %t474, label %bb78, label %bb79
bb78:
  %t476 = load ptr, ptr %l8, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2edeclareVars(ptr %v0, ptr %s0, ptr %t476, ptr %l9)
  br label %bb80
bb79:
  br label %bb81
bb80:
  br label %bb81
bb81:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l9, { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d308, i32 0, i32 1) })
  br label %bb82
bb82:
  store ptr %l9, ptr %l183, !tbaa !29
  %t480 = load ptr, ptr %l8, !tbaa !29
  %t482 = getelementptr %"compiler/emit:fnEm", ptr %t480, i32 0, i32 5
  %t484 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %s0, ptr %t482)
  store { i64, ptr } %t484, ptr %l186
  br label %bb83
bb83:
  %t485 = load ptr, ptr %l183, !tbaa !29
  %t486 = load { i64, ptr }, ptr %l186, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t485, { i64, ptr } %t486)
  br label %bb84
bb84:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l9, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d309, i32 0, i32 1) })
  br label %bb85
bb85:
  store ptr %l9, ptr %l188, !tbaa !29
  %t488 = load ptr, ptr %l8, !tbaa !29
  %t490 = getelementptr %"compiler/emit:fnEm", ptr %t488, i32 0, i32 20
  %t492 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %s0, ptr %t490)
  store { i64, ptr } %t492, ptr %l191
  br label %bb86
bb86:
  %t493 = load ptr, ptr %l188, !tbaa !29
  %t494 = load { i64, ptr }, ptr %l191, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t493, { i64, ptr } %t494)
  br label %bb87
bb87:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l9, i8 10)
  br label %bb88
bb88:
  %t496 = load ptr, ptr %l8, !tbaa !29
  %t498 = getelementptr %"compiler/emit:fnEm", ptr %t496, i32 0, i32 27
  %t499 = load i1, ptr %t498, !tbaa !21
  br i1 %t499, label %bb89, label %bb90
bb89:
  store %olang.scope zeroinitializer, ptr %s17
  %t501 = load ptr, ptr %l0, !tbaa !29
  %t502 = load { i64, [2 x i64] }, ptr %l1
  %t503 = load ptr, ptr %l2, !tbaa !29
  %t504 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t505 = load i64, ptr %l5, !tbaa !24
  %t506 = load ptr, ptr %l8, !tbaa !29
  %t508 = getelementptr %"compiler/emit:fnEm", ptr %t506, i32 0, i32 28
  %t509 = load { i64, ptr }, ptr %t508, !tbaa !27
  %t516 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2egenNext(ptr %v0, ptr %v0, ptr %s0, ptr %v0, ptr %s17, ptr %t501, { i64, [2 x i64] } %t502, ptr %t503, { i64, ptr } %t504, i64 %t505, { i64, ptr } %t509)
  store { i64, ptr } %t516, ptr %l202
  br label %bb91
bb90:
  br label %bb97
bb91:
  %t517 = load { i64, ptr }, ptr %l202, !tbaa !27
  store { i64, ptr } %t517, ptr %l10, !tbaa !27
  %t518 = load ptr, ptr %l0, !tbaa !29
  %t519 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t520 = load ptr, ptr %l8, !tbaa !29
  %t522 = getelementptr %"compiler/emit:fnEm", ptr %t520, i32 0, i32 28
  %t523 = load { i64, ptr }, ptr %t522, !tbaa !27
  %t527 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2egenDrop(ptr %v0, ptr %s0, ptr %v0, ptr %s17, ptr %t518, { i64, ptr } %t519, { i64, ptr } %t523)
  store { i64, ptr } %t527, ptr %l207
  br label %bb92
bb92:
  %t528 = load { i64, ptr }, ptr %l207, !tbaa !27
  store { i64, ptr } %t528, ptr %l11, !tbaa !27
  %t529 = load ptr, ptr %l0, !tbaa !29
  store ptr %t529, ptr %l208, !tbaa !29
  %t530 = load { i64, [2 x i64] }, ptr %l1
  store { i64, [2 x i64] } %t530, ptr %l209
  %t531 = load ptr, ptr %l2, !tbaa !29
  %t533 = getelementptr %"compiler/mir:Fn", ptr %t531, i32 0, i32 1
  %t534 = load i32, ptr %t533, !tbaa !23
  store i32 %t534, ptr %l211, !tbaa !23
  %t535 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t535, ptr %l212, !tbaa !27
  %t536 = load i64, ptr %l5, !tbaa !24
  store i64 %t536, ptr %l213, !tbaa !24
  %t537 = load i1, ptr %l4, !tbaa !21
  store i1 %t537, ptr %l214, !tbaa !21
  %t538 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t538, ptr %l215, !tbaa !27
  %t540 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s17, ptr %l9)
  store { i64, ptr } %t540, ptr %l217
  br label %bb93
bb93:
  %t541 = load ptr, ptr %l2, !tbaa !29
  %t543 = getelementptr %"compiler/mir:Fn", ptr %t541, i32 0, i32 7
  %t545 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aLocal_3e_2eLen_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %t543)
  store i64 %t545, ptr %l220
  br label %bb94
bb94:
  %t546 = load { i64, ptr }, ptr %l217, !tbaa !27
  %t547 = load i64, ptr %l220, !tbaa !24
  %t548 = call { i64, ptr } @compiler_2femit_2efoldSlots(ptr %s17, ptr %s17, { i64, ptr } %t546, i64 %t547)
  store { i64, ptr } %t548, ptr %l221
  br label %bb95
bb95:
  %t549 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t550 = load { i64, ptr }, ptr %l215, !tbaa !27
  %t551 = extractvalue { i64, ptr } %t550, 1
  %t552 = extractvalue { i64, ptr } %t550, 0
  %t553 = load { i64, ptr }, ptr %l221, !tbaa !27
  %t554 = extractvalue { i64, ptr } %t553, 1
  %t555 = extractvalue { i64, ptr } %t553, 0
  %t556 = add i64 %t552, %t555
  %t558 = extractvalue { i64, ptr } %t549, 1
  %t559 = extractvalue { i64, ptr } %t549, 0
  %t560 = add i64 %t556, %t559
  %t561 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t560)
  call void @olang_textcopy(ptr %t561, ptr %t551, i64 %t552)
  %t562 = getelementptr i8, ptr %t561, i64 %t552
  call void @olang_textcopy(ptr %t562, ptr %t554, i64 %t555)
  %t563 = getelementptr i8, ptr %t562, i64 %t555
  call void @olang_textcopy(ptr %t563, ptr %t558, i64 %t559)
  %t564 = insertvalue { i64, ptr } undef, i64 %t560, 0
  %t565 = insertvalue { i64, ptr } %t564, ptr %t561, 1
  %t567 = extractvalue { i64, ptr } %t565, 0
  %t568 = extractvalue { i64, ptr } %t565, 1
  %t569 = mul i64 %t567, 1
  %t570 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t569)
  call void @llvm.memcpy.p0.p0.i64(ptr %t570, ptr %t568, i64 %t569, i1 false)
  %t571 = insertvalue { i64, ptr } undef, i64 %t567, 0
  %t572 = insertvalue { i64, ptr } %t571, ptr %t570, 1
  %t573 = load ptr, ptr %l208, !tbaa !29
  %t574 = load { i64, [2 x i64] }, ptr %l209
  %t575 = load i32, ptr %l211, !tbaa !23
  %t576 = load { i64, ptr }, ptr %l212, !tbaa !27
  %t577 = load i64, ptr %l213, !tbaa !24
  %t578 = load i1, ptr %l214, !tbaa !21
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2efnItem(ptr %v0, ptr %s0, ptr %s17, ptr %t573, { i64, [2 x i64] } %t574, i32 %t575, { i64, ptr } %t576, i64 %t577, i1 %t578, { i64, ptr } %t572)
  br label %bb96
bb96:
  call void @__olang_scope_close(ptr %s17)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb97:
  %t580 = load ptr, ptr %l0, !tbaa !29
  store ptr %t580, ptr %l225, !tbaa !29
  %t581 = load { i64, [2 x i64] }, ptr %l1
  store { i64, [2 x i64] } %t581, ptr %l226
  %t582 = load ptr, ptr %l2, !tbaa !29
  %t584 = getelementptr %"compiler/mir:Fn", ptr %t582, i32 0, i32 1
  %t585 = load i32, ptr %t584, !tbaa !23
  store i32 %t585, ptr %l228, !tbaa !23
  %t586 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t586, ptr %l229, !tbaa !27
  %t587 = load i64, ptr %l5, !tbaa !24
  store i64 %t587, ptr %l230, !tbaa !24
  %t588 = load i1, ptr %l4, !tbaa !21
  store i1 %t588, ptr %l231, !tbaa !21
  %t590 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l9)
  store { i64, ptr } %t590, ptr %l233
  br label %bb98
bb98:
  %t591 = load ptr, ptr %l2, !tbaa !29
  %t593 = getelementptr %"compiler/mir:Fn", ptr %t591, i32 0, i32 7
  %t595 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aLocal_3e_2eLen_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %t593)
  store i64 %t595, ptr %l236
  br label %bb99
bb99:
  %t596 = load { i64, ptr }, ptr %l233, !tbaa !27
  %t597 = load i64, ptr %l236, !tbaa !24
  %t598 = call { i64, ptr } @compiler_2femit_2efoldSlots(ptr %s0, ptr %s0, { i64, ptr } %t596, i64 %t597)
  store { i64, ptr } %t598, ptr %l237
  br label %bb100
bb100:
  %t599 = load { i64, ptr }, ptr %l237, !tbaa !27
  %t600 = extractvalue { i64, ptr } %t599, 0
  %t601 = extractvalue { i64, ptr } %t599, 1
  %t602 = mul i64 %t600, 1
  %t603 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t602)
  call void @llvm.memcpy.p0.p0.i64(ptr %t603, ptr %t601, i64 %t602, i1 false)
  %t604 = insertvalue { i64, ptr } undef, i64 %t600, 0
  %t605 = insertvalue { i64, ptr } %t604, ptr %t603, 1
  %t606 = load ptr, ptr %l225, !tbaa !29
  %t607 = load { i64, [2 x i64] }, ptr %l226
  %t608 = load i32, ptr %l228, !tbaa !23
  %t609 = load { i64, ptr }, ptr %l229, !tbaa !27
  %t610 = load i64, ptr %l230, !tbaa !24
  %t611 = load i1, ptr %l231, !tbaa !21
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2efnItem(ptr %v0, ptr %s0, ptr %s0, ptr %t606, { i64, [2 x i64] } %t607, i32 %t608, { i64, ptr } %t609, i64 %t610, i1 %t611, { i64, ptr } %t605)
  br label %bb101
bb101:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eglobal(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca %"compiler/eval:Image"
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l18 = alloca i1
  %l24 = alloca i64
  %l27 = alloca i1
  %l31 = alloca i1
  %l32 = alloca %"compiler/eval:Image"
  %l36 = alloca %"compiler/eval:Image"
  %l37 = alloca i32
  %l38 = alloca %"compiler/eval:Image"
  %l42 = alloca { i64, ptr }
  %l43 = alloca i64
  %l45 = alloca i64
  %l46 = alloca i32
  %l47 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i32
  %l53 = alloca i1
  %l57 = alloca { i64, ptr }
  %l58 = alloca { i64, ptr }
  %l60 = alloca i64
  %l62 = alloca i64
  %l63 = alloca i64
  %l72 = alloca i64
  %l74 = alloca i1
  %l76 = alloca %"compiler/eval:Blob"
  %l78 = alloca i64
  %l80 = alloca i1
  %l83 = alloca { i64, ptr }
  %l85 = alloca i64
  %l88 = alloca i64
  %l89 = alloca i64
  %l94 = alloca { i64, ptr }
  %l96 = alloca i64
  %l107 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t3 = load i32, ptr %l2, !tbaa !23
  %t7 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eglobalSym(ptr %v0, ptr %s0, ptr %t1, i64 %t2, i32 %t3)
  store { i64, ptr } %t7, ptr %l15
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t8, ptr %l4, !tbaa !27
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t13 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ehas(ptr %v0, ptr %s0, ptr %t9, { i64, ptr } %t10)
  store i1 %t13, ptr %l18
  br label %bb2
bb2:
  %t14 = load i1, ptr %l18, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t15 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t16 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d310, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d310, i32 0, i32 1) }, 0
  %t19 = extractvalue { i64, ptr } %t15, 1
  %t20 = extractvalue { i64, ptr } %t15, 0
  %t21 = add i64 %t17, %t20
  %t22 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t21)
  call void @olang_textcopy(ptr %t22, ptr %t16, i64 %t17)
  %t23 = getelementptr i8, ptr %t22, i64 %t17
  call void @olang_textcopy(ptr %t23, ptr %t19, i64 %t20)
  %t24 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t22, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t25, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load i64, ptr %l1, !tbaa !24
  %t29 = load i32, ptr %l2, !tbaa !23
  %t33 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eglobalBody(ptr %v0, ptr %t27, i64 %t28, i32 %t29)
  store i64 %t33, ptr %l24
  br label %bb6
bb6:
  %t34 = load i64, ptr %l24, !tbaa !24
  store i64 %t34, ptr %l5, !tbaa !24
  %t35 = load i64, ptr %l5, !tbaa !24
  %t37 = icmp sge i64 %t35, 0
  br i1 %t37, label %bb7, label %bb8
bb7:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/emit:Emitter", ptr %t39, i32 0, i32 44
  %t42 = load i64, ptr %l5, !tbaa !24
  %t45 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2feval_3aImage_3e_2e_H901ad831a5883703dcf426ee01511832(ptr %v0, ptr %t41, i64 %t42)
  store i1 %t45, ptr %l31
  br label %bb9
bb8:
  store i1 false, ptr %l27, !tbaa !21
  br label %bb10
bb9:
  %t46 = load i1, ptr %l31, !tbaa !21
  store i1 %t46, ptr %l27, !tbaa !21
  br label %bb10
bb10:
  %t47 = load i1, ptr %l27, !tbaa !21
  br i1 %t47, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s3
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/emit:Emitter", ptr %t48, i32 0, i32 44
  %t51 = load i64, ptr %l5, !tbaa !24
  %t54 = call { i32, %"compiler/eval:Image" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2feval_3aImage_3e_2e_Hf0a310b4530fd6279fda9cb6330ad681(ptr %v0, ptr %v0, ptr %t50, i64 %t51)
  %t55 = extractvalue { i32, %"compiler/eval:Image" } %t54, 1
  %t56 = extractvalue { i32, %"compiler/eval:Image" } %t54, 0
  store i32 %t56, ptr %l37
  %t57 = icmp ne i32 %t56, 0
  br i1 %t57, label %bb14, label %ok.58
ok.58:
  store %"compiler/eval:Image" %t55, ptr %l36
  br label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s9
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t63 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %s9, ptr %t59, i32 %a3)
  store { i64, ptr } %t63, ptr %l107
  br label %bb61
bb13:
  %t64 = load %"compiler/eval:Image", ptr %l36
  store %"compiler/eval:Image" %t64, ptr %l32
  br label %bb17
bb14:
  br label %bb15
bb15:
  call void @__olang_ert_req_clear()
  %t65 = call %"compiler/eval:Image" @compiler_2feval_3aImage_2ector(ptr %v0)
  store %"compiler/eval:Image" %t65, ptr %l38
  br label %bb16
bb16:
  %t66 = load %"compiler/eval:Image", ptr %l38
  store %"compiler/eval:Image" %t66, ptr %l32
  br label %bb17
bb17:
  %t67 = load %"compiler/eval:Image", ptr %l32
  store %"compiler/eval:Image" %t67, ptr %l6
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t73 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ebakedText(ptr %v0, ptr %s0, ptr %v0, ptr %s3, ptr %t68, { i64, ptr } %t69, ptr %l6)
  store { i64, ptr } %t73, ptr %l42
  br label %bb18
bb18:
  %t74 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t74, ptr %l7, !tbaa !27
  %t75 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t77 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %s3, ptr %s3, { i64, ptr } %t75, { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d311, i32 0, i32 1) })
  %t78 = extractvalue { i32, i64 } %t77, 1
  %t79 = extractvalue { i32, i64 } %t77, 0
  store i32 %t79, ptr %l46
  %t80 = icmp ne i32 %t79, 0
  br i1 %t80, label %bb20, label %ok.81
ok.81:
  store i64 %t78, ptr %l45
  br label %bb19
bb19:
  %t82 = load i64, ptr %l45, !tbaa !24
  store i64 %t82, ptr %l43, !tbaa !24
  br label %bb22
bb20:
  br label %bb21
bb21:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l43, !tbaa !24
  br label %bb22
bb22:
  %t83 = load i64, ptr %l43, !tbaa !24
  store i64 %t83, ptr %l8, !tbaa !24
  %t84 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t86 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %s3, ptr %s3, { i64, ptr } %t84, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d312, i32 0, i32 1) })
  %t87 = extractvalue { i32, i64 } %t86, 1
  %t88 = extractvalue { i32, i64 } %t86, 0
  store i32 %t88, ptr %l50
  %t89 = icmp ne i32 %t88, 0
  br i1 %t89, label %bb24, label %ok.90
ok.90:
  store i64 %t87, ptr %l49
  br label %bb23
bb23:
  %t91 = load i64, ptr %l49, !tbaa !24
  store i64 %t91, ptr %l47, !tbaa !24
  br label %bb26
bb24:
  br label %bb25
bb25:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l47, !tbaa !24
  br label %bb26
bb26:
  %t92 = load i64, ptr %l47, !tbaa !24
  store i64 %t92, ptr %l9, !tbaa !24
  %t93 = load i64, ptr %l8, !tbaa !24
  %t95 = icmp sge i64 %t93, 0
  br i1 %t95, label %bb27, label %bb28
bb27:
  %t97 = load i64, ptr %l9, !tbaa !24
  %t98 = load i64, ptr %l8, !tbaa !24
  %t101 = icmp sgt i64 %t97, %t98
  store i1 %t101, ptr %l53, !tbaa !21
  br label %bb29
bb28:
  store i1 false, ptr %l53, !tbaa !21
  br label %bb29
bb29:
  %t103 = load i1, ptr %l53, !tbaa !21
  br i1 %t103, label %bb30, label %bb31
bb30:
  %t104 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t104, ptr %l58, !tbaa !27
  %t105 = load i64, ptr %l8, !tbaa !24
  %t107 = add i64 %t105, 12
  store i64 %t107, ptr %l60, !tbaa !24
  %t108 = load i64, ptr %l9, !tbaa !24
  %t110 = add i64 %t108, 2
  store i64 %t110, ptr %l62, !tbaa !24
  %t111 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t112 = extractvalue { i64, ptr } %t111, 0
  store i64 %t112, ptr %l63, !tbaa !24
  %t113 = load i64, ptr %l60, !tbaa !24
  %t114 = icmp sge i64 %t113, 0
  br i1 %t114, label %bb32, label %bb33
bb31:
  %t116 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t117 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d313, i32 0, i32 1) }, 1
  %t118 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d313, i32 0, i32 1) }, 0
  %t120 = extractvalue { i64, ptr } %t116, 1
  %t121 = extractvalue { i64, ptr } %t116, 0
  %t122 = add i64 %t118, %t121
  %t123 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d314, i32 0, i32 1) }, 1
  %t124 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d314, i32 0, i32 1) }, 0
  %t125 = add i64 %t122, %t124
  %t126 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t125)
  call void @olang_textcopy(ptr %t126, ptr %t117, i64 %t118)
  %t127 = getelementptr i8, ptr %t126, i64 %t118
  call void @olang_textcopy(ptr %t127, ptr %t120, i64 %t121)
  %t128 = getelementptr i8, ptr %t127, i64 %t121
  call void @olang_textcopy(ptr %t128, ptr %t123, i64 %t124)
  %t129 = insertvalue { i64, ptr } undef, i64 %t125, 0
  %t130 = insertvalue { i64, ptr } %t129, ptr %t126, 1
  store { i64, ptr } %t130, ptr %l57, !tbaa !27
  br label %bb38
bb32:
  %t132 = load i64, ptr %l60, !tbaa !24
  %t133 = load i64, ptr %l62, !tbaa !24
  %t134 = icmp sle i64 %t132, %t133
  br i1 %t134, label %bb34, label %bb35
bb33:
  call void @__olang_check_failed(ptr @olang_loc_67352ecb15e68ba0_c3979b973b302ad4)
  unreachable
bb34:
  %t136 = load i64, ptr %l62, !tbaa !24
  %t137 = load i64, ptr %l63, !tbaa !24
  %t138 = icmp sle i64 %t136, %t137
  br i1 %t138, label %bb36, label %bb37
bb35:
  call void @__olang_check_failed(ptr @olang_loc_67352ecb15e68ba0_c3979b973b302ad4)
  unreachable
bb36:
  %t140 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t141 = load ptr, ptr %t140, !tbaa !27
  %t142 = load i64, ptr %l60, !tbaa !24
  %t143 = load i64, ptr %l62, !tbaa !24
  %t144 = getelementptr i8, ptr %t141, i64 %t142
  %t145 = sub i64 %t143, %t142
  %t146 = insertvalue { i64, ptr } undef, i64 %t145, 0
  %t147 = insertvalue { i64, ptr } %t146, ptr %t144, 1
  %t148 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d315, i32 0, i32 1) }, 1
  %t149 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d315, i32 0, i32 1) }, 0
  %t150 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t151 = extractvalue { i64, ptr } %t150, 1
  %t152 = extractvalue { i64, ptr } %t150, 0
  %t153 = add i64 %t149, %t152
  %t154 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d316, i32 0, i32 1) }, 1
  %t155 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d316, i32 0, i32 1) }, 0
  %t156 = add i64 %t153, %t155
  %t158 = extractvalue { i64, ptr } %t147, 1
  %t159 = extractvalue { i64, ptr } %t147, 0
  %t160 = add i64 %t156, %t159
  %t161 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t160)
  call void @olang_textcopy(ptr %t161, ptr %t148, i64 %t149)
  %t162 = getelementptr i8, ptr %t161, i64 %t149
  call void @olang_textcopy(ptr %t162, ptr %t151, i64 %t152)
  %t163 = getelementptr i8, ptr %t162, i64 %t152
  call void @olang_textcopy(ptr %t163, ptr %t154, i64 %t155)
  %t164 = getelementptr i8, ptr %t163, i64 %t155
  call void @olang_textcopy(ptr %t164, ptr %t158, i64 %t159)
  %t165 = insertvalue { i64, ptr } undef, i64 %t160, 0
  %t166 = insertvalue { i64, ptr } %t165, ptr %t161, 1
  store { i64, ptr } %t166, ptr %l57, !tbaa !27
  br label %bb38
bb37:
  call void @__olang_check_failed(ptr @olang_loc_67352ecb15e68ba0_c3979b973b302ad4)
  unreachable
bb38:
  %t168 = load { i64, ptr }, ptr %l57, !tbaa !27
  store { i64, ptr } %t168, ptr %l10, !tbaa !27
  %t169 = getelementptr %"compiler/eval:Image", ptr %l6, i32 0, i32 0
  %t171 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2feval_3aBlob_3e_2eLen_3ccompiler_2feval_3aBlob_3e(ptr %v0, ptr %t169)
  store i64 %t171, ptr %l72
  br label %bb39
bb39:
  %t172 = load i64, ptr %l72, !tbaa !24
  %t173 = icmp eq i64 %t172, 1
  br i1 %t173, label %bb40, label %bb41
bb40:
  %t175 = getelementptr %"compiler/eval:Image", ptr %l6, i32 0, i32 0
  %t177 = call %"compiler/eval:Blob" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2feval_3aBlob_3e_2eAt_3ccompiler_2feval_3aBlob_3e(ptr %v0, ptr %v0, ptr %t175, i64 0)
  store %"compiler/eval:Blob" %t177, ptr %l76
  br label %bb42
bb41:
  store i1 false, ptr %l74, !tbaa !21
  br label %bb44
bb42:
  %t178 = getelementptr %"compiler/eval:Blob", ptr %l76, i32 0, i32 3
  %t180 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t178)
  store i64 %t180, ptr %l78
  br label %bb43
bb43:
  %t181 = load i64, ptr %l78, !tbaa !24
  %t182 = icmp eq i64 %t181, 0
  store i1 %t182, ptr %l74, !tbaa !21
  br label %bb44
bb44:
  %t184 = load i1, ptr %l74, !tbaa !21
  br i1 %t184, label %bb45, label %bb46
bb45:
  %t185 = load i64, ptr %l8, !tbaa !24
  %t187 = icmp sge i64 %t185, 0
  store i1 %t187, ptr %l80, !tbaa !21
  br label %bb47
bb46:
  store i1 false, ptr %l80, !tbaa !21
  br label %bb47
bb47:
  %t189 = load i1, ptr %l80, !tbaa !21
  br i1 %t189, label %bb48, label %bb49
bb48:
  %t190 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t190, ptr %l83, !tbaa !27
  %t191 = load i64, ptr %l8, !tbaa !24
  %t193 = add i64 %t191, 12
  store i64 %t193, ptr %l85, !tbaa !24
  %t194 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t196 = extractvalue { i64, ptr } %t194, 0
  %t198 = sub i64 %t196, 1
  store i64 %t198, ptr %l88, !tbaa !24
  %t199 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t200 = extractvalue { i64, ptr } %t199, 0
  store i64 %t200, ptr %l89, !tbaa !24
  %t201 = load i64, ptr %l85, !tbaa !24
  %t202 = icmp sge i64 %t201, 0
  br i1 %t202, label %bb50, label %bb51
bb49:
  br label %bb59
bb50:
  %t204 = load i64, ptr %l85, !tbaa !24
  %t205 = load i64, ptr %l88, !tbaa !24
  %t206 = icmp sle i64 %t204, %t205
  br i1 %t206, label %bb52, label %bb53
bb51:
  call void @__olang_check_failed(ptr @olang_loc_6c4f253a42e065fd_ca2f6afe461eeb41)
  unreachable
bb52:
  %t208 = load i64, ptr %l88, !tbaa !24
  %t209 = load i64, ptr %l89, !tbaa !24
  %t210 = icmp sle i64 %t208, %t209
  br i1 %t210, label %bb54, label %bb55
bb53:
  call void @__olang_check_failed(ptr @olang_loc_6c4f253a42e065fd_ca2f6afe461eeb41)
  unreachable
bb54:
  %t212 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t213 = load ptr, ptr %t212, !tbaa !27
  %t214 = load i64, ptr %l85, !tbaa !24
  %t215 = load i64, ptr %l88, !tbaa !24
  %t216 = getelementptr i8, ptr %t213, i64 %t214
  %t217 = sub i64 %t215, %t214
  %t218 = insertvalue { i64, ptr } undef, i64 %t217, 0
  %t219 = insertvalue { i64, ptr } %t218, ptr %t216, 1
  %t220 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d317, i32 0, i32 1) }, 1
  %t221 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d317, i32 0, i32 1) }, 0
  %t222 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t223 = extractvalue { i64, ptr } %t222, 1
  %t224 = extractvalue { i64, ptr } %t222, 0
  %t225 = add i64 %t221, %t224
  %t226 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d318, i32 0, i32 1) }, 1
  %t227 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d318, i32 0, i32 1) }, 0
  %t228 = add i64 %t225, %t227
  %t230 = extractvalue { i64, ptr } %t219, 1
  %t231 = extractvalue { i64, ptr } %t219, 0
  %t232 = add i64 %t228, %t231
  %t233 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t232)
  call void @olang_textcopy(ptr %t233, ptr %t220, i64 %t221)
  %t234 = getelementptr i8, ptr %t233, i64 %t221
  call void @olang_textcopy(ptr %t234, ptr %t223, i64 %t224)
  %t235 = getelementptr i8, ptr %t234, i64 %t224
  call void @olang_textcopy(ptr %t235, ptr %t226, i64 %t227)
  %t236 = getelementptr i8, ptr %t235, i64 %t227
  call void @olang_textcopy(ptr %t236, ptr %t230, i64 %t231)
  %t237 = insertvalue { i64, ptr } undef, i64 %t232, 0
  %t238 = insertvalue { i64, ptr } %t237, ptr %t233, 1
  store { i64, ptr } %t238, ptr %l94, !tbaa !27
  %t239 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t240 = extractvalue { i64, ptr } %t239, 0
  %t241 = load { i64, ptr }, ptr %l94, !tbaa !27
  %t242 = extractvalue { i64, ptr } %t241, 0
  store i64 %t242, ptr %l96, !tbaa !24
  %t244 = load i64, ptr %l96, !tbaa !24
  %t245 = icmp eq i64 %t240, %t244
  br i1 %t245, label %bb56, label %bb57
bb55:
  call void @__olang_check_failed(ptr @olang_loc_6c4f253a42e065fd_ca2f6afe461eeb41)
  unreachable
bb56:
  %t247 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t248 = load ptr, ptr %t247, !tbaa !27
  %t249 = getelementptr { i64, ptr }, ptr %l94, i32 0, i32 1
  %t250 = load ptr, ptr %t249, !tbaa !27
  %t251 = load i64, ptr %l96, !tbaa !24
  %t252 = mul i64 %t251, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t248, ptr %t250, i64 %t252, i1 false)
  br label %bb58
bb57:
  %t253 = load { i64, ptr }, ptr %l94, !tbaa !27
  store { i64, ptr } %t253, ptr %l10, !tbaa !27
  br label %bb58
bb58:
  br label %bb59
bb59:
  %t254 = load ptr, ptr %l0, !tbaa !29
  %t255 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t256 = load i64, ptr %l1, !tbaa !24
  %t257 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t258 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t260 = extractvalue { i64, ptr } %t258, 1
  %t261 = extractvalue { i64, ptr } %t258, 0
  %t262 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d319, i32 0, i32 1) }, 1
  %t263 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d319, i32 0, i32 1) }, 0
  %t264 = add i64 %t261, %t263
  %t265 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t264)
  call void @olang_textcopy(ptr %t265, ptr %t260, i64 %t261)
  %t266 = getelementptr i8, ptr %t265, i64 %t261
  call void @olang_textcopy(ptr %t266, ptr %t262, i64 %t263)
  %t267 = insertvalue { i64, ptr } undef, i64 %t264, 0
  %t268 = insertvalue { i64, ptr } %t267, ptr %t265, 1
  %t270 = extractvalue { i64, ptr } %t268, 0
  %t271 = extractvalue { i64, ptr } %t268, 1
  %t272 = mul i64 %t270, 1
  %t273 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t272)
  call void @llvm.memcpy.p0.p0.i64(ptr %t273, ptr %t271, i64 %t272, i1 false)
  %t274 = insertvalue { i64, ptr } undef, i64 %t270, 0
  %t275 = insertvalue { i64, ptr } %t274, ptr %t273, 1
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eitem(ptr %v0, ptr %s0, ptr %s3, ptr %s3, ptr %t254, { i64, ptr } %t255, i64 %t256, { i64, ptr } %t257, { i64, ptr } %t275)
  br label %bb60
bb60:
  call void @__olang_scope_close(ptr %s3)
  br label %bb63
bb61:
  %t281 = load { i64, ptr }, ptr %l107, !tbaa !27
  store { i64, ptr } %t281, ptr %l11, !tbaa !27
  %t282 = load ptr, ptr %l0, !tbaa !29
  %t283 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t284 = load i64, ptr %l1, !tbaa !24
  %t285 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t286 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t287 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d320, i32 0, i32 1) }, 1
  %t288 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d320, i32 0, i32 1) }, 0
  %t290 = extractvalue { i64, ptr } %t285, 1
  %t291 = extractvalue { i64, ptr } %t285, 0
  %t292 = add i64 %t288, %t291
  %t293 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d321, i32 0, i32 1) }, 1
  %t294 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d321, i32 0, i32 1) }, 0
  %t295 = add i64 %t292, %t294
  %t297 = extractvalue { i64, ptr } %t286, 1
  %t298 = extractvalue { i64, ptr } %t286, 0
  %t299 = add i64 %t295, %t298
  %t300 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d322, i32 0, i32 1) }, 1
  %t301 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d322, i32 0, i32 1) }, 0
  %t302 = add i64 %t299, %t301
  %t303 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t302)
  call void @olang_textcopy(ptr %t303, ptr %t287, i64 %t288)
  %t304 = getelementptr i8, ptr %t303, i64 %t288
  call void @olang_textcopy(ptr %t304, ptr %t290, i64 %t291)
  %t305 = getelementptr i8, ptr %t304, i64 %t291
  call void @olang_textcopy(ptr %t305, ptr %t293, i64 %t294)
  %t306 = getelementptr i8, ptr %t305, i64 %t294
  call void @olang_textcopy(ptr %t306, ptr %t297, i64 %t298)
  %t307 = getelementptr i8, ptr %t306, i64 %t298
  call void @olang_textcopy(ptr %t307, ptr %t300, i64 %t301)
  %t308 = insertvalue { i64, ptr } undef, i64 %t302, 0
  %t309 = insertvalue { i64, ptr } %t308, ptr %t303, 1
  %t311 = extractvalue { i64, ptr } %t309, 0
  %t312 = extractvalue { i64, ptr } %t309, 1
  %t313 = mul i64 %t311, 1
  %t314 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t313)
  call void @llvm.memcpy.p0.p0.i64(ptr %t314, ptr %t312, i64 %t313, i1 false)
  %t315 = insertvalue { i64, ptr } undef, i64 %t311, 0
  %t316 = insertvalue { i64, ptr } %t315, ptr %t314, 1
  %t317 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t318 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t319 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d323, i32 0, i32 1) }, 1
  %t320 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d323, i32 0, i32 1) }, 0
  %t322 = extractvalue { i64, ptr } %t317, 1
  %t323 = extractvalue { i64, ptr } %t317, 0
  %t324 = add i64 %t320, %t323
  %t325 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d324, i32 0, i32 1) }, 1
  %t326 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d324, i32 0, i32 1) }, 0
  %t327 = add i64 %t324, %t326
  %t329 = extractvalue { i64, ptr } %t318, 1
  %t330 = extractvalue { i64, ptr } %t318, 0
  %t331 = add i64 %t327, %t330
  %t332 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d325, i32 0, i32 1) }, 1
  %t333 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d325, i32 0, i32 1) }, 0
  %t334 = add i64 %t331, %t333
  %t335 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t334)
  call void @olang_textcopy(ptr %t335, ptr %t319, i64 %t320)
  %t336 = getelementptr i8, ptr %t335, i64 %t320
  call void @olang_textcopy(ptr %t336, ptr %t322, i64 %t323)
  %t337 = getelementptr i8, ptr %t336, i64 %t323
  call void @olang_textcopy(ptr %t337, ptr %t325, i64 %t326)
  %t338 = getelementptr i8, ptr %t337, i64 %t326
  call void @olang_textcopy(ptr %t338, ptr %t329, i64 %t330)
  %t339 = getelementptr i8, ptr %t338, i64 %t330
  call void @olang_textcopy(ptr %t339, ptr %t332, i64 %t333)
  %t340 = insertvalue { i64, ptr } undef, i64 %t334, 0
  %t341 = insertvalue { i64, ptr } %t340, ptr %t335, 1
  %t343 = extractvalue { i64, ptr } %t341, 0
  %t344 = extractvalue { i64, ptr } %t341, 1
  %t345 = mul i64 %t343, 1
  %t346 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t345)
  call void @llvm.memcpy.p0.p0.i64(ptr %t346, ptr %t344, i64 %t345, i1 false)
  %t347 = insertvalue { i64, ptr } undef, i64 %t343, 0
  %t348 = insertvalue { i64, ptr } %t347, ptr %t346, 1
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eitem(ptr %v0, ptr %s0, ptr %s9, ptr %s9, ptr %t282, { i64, ptr } %t283, i64 %t284, { i64, ptr } %t316, { i64, ptr } %t348)
  br label %bb62
bb62:
  call void @__olang_scope_close(ptr %s9)
  br label %bb63
bb63:
  %t354 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t355 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d326, i32 0, i32 1) }, 1
  %t356 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d326, i32 0, i32 1) }, 0
  %t358 = extractvalue { i64, ptr } %t354, 1
  %t359 = extractvalue { i64, ptr } %t354, 0
  %t360 = add i64 %t356, %t359
  %t361 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t360)
  call void @olang_textcopy(ptr %t361, ptr %t355, i64 %t356)
  %t362 = getelementptr i8, ptr %t361, i64 %t356
  call void @olang_textcopy(ptr %t362, ptr %t358, i64 %t359)
  %t363 = insertvalue { i64, ptr } undef, i64 %t360, 0
  %t364 = insertvalue { i64, ptr } %t363, ptr %t361, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t364, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ehas(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l5 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %a0, i32 0, i32 19
  %t7 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9b83f66eba65594537030636cb0b52b7(ptr %v0, ptr %v1, ptr %t3, { i64, ptr } %a1)
  store i1 %t7, ptr %l5
  br label %bb1
bb1:
  %t8 = load i1, ptr %l5, !tbaa !21
  store i1 %t8, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eisGen(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1) #0 {
entry:
  %l1 = alloca { i64, [2 x i64] }
  %l2 = alloca i32
  %l3 = alloca i1
  %l12 = alloca ptr
  %rv = alloca i1
  store { i64, [2 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [2 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [2 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { i32 }, ptr %t6, i32 0, i32 0
  %t8 = load i32, ptr %t7
  store i32 %t8, ptr %l2, !tbaa !23
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t12 = getelementptr %"compiler/emit:Emitter", ptr %a0, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = getelementptr %"compiler/lower:Lowerer", ptr %t13, i32 0, i32 1
  %t16 = load i32, ptr %l2, !tbaa !23
  %t18 = sext i32 %t16 to i64
  %t21 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t15, i64 %t18)
  store ptr %t21, ptr %l12
  br label %bb4
bb4:
  %t22 = load ptr, ptr %l12, !tbaa !29
  %t24 = getelementptr %"compiler/typed:Body", ptr %t22, i32 0, i32 15
  %t25 = load i1, ptr %t24, !tbaa !21
  store i1 %t25, ptr %l3, !tbaa !21
  br label %bb10
bb5:
  br i1 true, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb9
bb8:
  store i1 false, ptr %l3, !tbaa !21
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_a37d1f87ccda68bc_daadd8872686b520)
  unreachable
bb10:
  %t27 = load i1, ptr %l3, !tbaa !21
  store i1 %t27, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2elocations(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l3 = alloca %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce"
  %l4 = alloca %"std/prelude/map:MapEntry.eb00e4a6e4307a4e46e40fbcd79d6b4f"
  %l5 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"std/prelude/text:StringBuilder"
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l12 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l14 = alloca %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce"
  %l15 = alloca %"std/prelude/map:MapEntry.eb00e4a6e4307a4e46e40fbcd79d6b4f"
  %l17 = alloca %"std/prelude/map:MapEntry.eb00e4a6e4307a4e46e40fbcd79d6b4f"
  %l18 = alloca i32
  %l26 = alloca { i64, ptr }
  %l30 = alloca %"std/prelude/text:StringBuilder"
  %l31 = alloca ptr
  %l33 = alloca { i64, ptr }
  %l42 = alloca { i64, ptr }
  %l45 = alloca ptr
  %l49 = alloca { i64, ptr }
  %l53 = alloca { i64, ptr }
  %l54 = alloca { i64, ptr }
  %l55 = alloca i64
  %l56 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t36 = alloca { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %s0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l12
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l12
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l2
  %t5 = call %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eIter_3cI64_2c_20Bool_3e(ptr %v1, ptr %v1, ptr %a1)
  store %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce" %t5, ptr %l14
  br label %bb2
bb2:
  %t6 = load %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce", ptr %l14
  store %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce" %t6, ptr %l3
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t8 = call { i32, %"std/prelude/map:MapEntry.eb00e4a6e4307a4e46e40fbcd79d6b4f" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3cI64_2c_20Bool_3e_2eNext_3cI64_2c_20Bool_3e(ptr %v1, ptr %l3)
  %t9 = extractvalue { i32, %"std/prelude/map:MapEntry.eb00e4a6e4307a4e46e40fbcd79d6b4f" } %t8, 1
  %t10 = extractvalue { i32, %"std/prelude/map:MapEntry.eb00e4a6e4307a4e46e40fbcd79d6b4f" } %t8, 0
  store i32 %t10, ptr %l18
  %t11 = icmp ne i32 %t10, 0
  br i1 %t11, label %bb5, label %ok.12
ok.12:
  store %"std/prelude/map:MapEntry.eb00e4a6e4307a4e46e40fbcd79d6b4f" %t9, ptr %l17
  br label %bb4
bb4:
  %t13 = load %"std/prelude/map:MapEntry.eb00e4a6e4307a4e46e40fbcd79d6b4f", ptr %l17
  store %"std/prelude/map:MapEntry.eb00e4a6e4307a4e46e40fbcd79d6b4f" %t13, ptr %l15
  br label %bb9
bb5:
  %t14 = load i32, ptr %l18, !tbaa !23
  %t15 = ashr i32 %t14, 16
  %t17 = icmp eq i32 %t15, 1
  br i1 %t17, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_check_failed(ptr @olang_loc_48c777cbd3c6a1a2_6303d50cbcfc1b86)
  unreachable
bb8:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %bb12
bb9:
  %t19 = load %"std/prelude/map:MapEntry.eb00e4a6e4307a4e46e40fbcd79d6b4f", ptr %l15
  store %"std/prelude/map:MapEntry.eb00e4a6e4307a4e46e40fbcd79d6b4f" %t19, ptr %l4
  %t20 = getelementptr %"std/prelude/map:MapEntry.eb00e4a6e4307a4e46e40fbcd79d6b4f", ptr %l4, i32 0, i32 0
  %t21 = load i64, ptr %t20, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l2, i64 %t21)
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb11:
  br label %bb3
bb12:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/emit:Emitter", ptr %t24, i32 0, i32 15
  %t27 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t26
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t27, ptr %l5
  %t30 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eToArray_3cI64_3e(ptr %s0, ptr %s0, ptr %l2)
  store { i64, ptr } %t30, ptr %l26
  br label %bb13
bb13:
  %t31 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t31, ptr %l6, !tbaa !27
  %t32 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t33 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l5
  %t34 = getelementptr { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr }, ptr null, i32 1
  %t35 = ptrtoint ptr %t34 to i64
  %t37 = getelementptr { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr }, ptr %t36, i32 0, i32 0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t33, ptr %t37, !tbaa !28
  call void @__olang_scope_escape(ptr %v0)
  %t39 = getelementptr { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr }, ptr %t36, i32 0, i32 1
  store ptr %v0, ptr %t39, !tbaa !28
  %t40 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_327, 0
  %t41 = insertvalue { ptr, ptr } %t40, ptr %t36, 1
  %t44 = extractvalue { ptr, ptr } %t41, 0
  %t45 = extractvalue { ptr, ptr } %t41, 1
  call void @std_2fprelude_2farray_2eArray_3cI64_3e_2eSort_3cI64_2c_20_3f_3e(ptr %s0, ptr %s0, { i64, ptr } %t32, ptr %t44, ptr %t45)
  br label %bb14
bb14:
  %t46 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t46, ptr %l30
  br label %bb15
bb15:
  %t47 = load %"std/prelude/text:StringBuilder", ptr %l30
  store %"std/prelude/text:StringBuilder" %t47, ptr %l7
  store ptr %l7, ptr %l31, !tbaa !29
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ehead(ptr %v0, ptr %s0, ptr %t48)
  store { i64, ptr } %t50, ptr %l33
  br label %bb16
bb16:
  %t51 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t52 = extractvalue { i64, ptr } %t51, 0
  %t53 = extractvalue { i64, ptr } %t51, 1
  %t54 = mul i64 %t52, 1
  %t55 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t54)
  call void @llvm.memcpy.p0.p0.i64(ptr %t55, ptr %t53, i64 %t54, i1 false)
  %t56 = insertvalue { i64, ptr } undef, i64 %t52, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t55, 1
  %t58 = load ptr, ptr %l31, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t58, { i64, ptr } %t57)
  br label %bb17
bb17:
  %t60 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t60, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t62 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t64 = extractvalue { i64, ptr } %t62, 0
  store i64 %t64, ptr %l10, !tbaa !24
  br label %bb18
bb18:
  store %olang.scope zeroinitializer, ptr %s4
  %t66 = load i64, ptr %l9, !tbaa !24
  %t67 = load i64, ptr %l10, !tbaa !24
  %t70 = icmp slt i64 %t66, %t67
  %t72 = xor i1 %t70, true
  br i1 %t72, label %bb19, label %bb20
bb19:
  call void @__olang_scope_close(ptr %s4)
  br label %bb25
bb20:
  br label %bb21
bb21:
  %t74 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t74, ptr %l42, !tbaa !27
  %t75 = load i64, ptr %l9, !tbaa !24
  %t77 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = getelementptr i64, ptr %t78, i64 %t75
  %t80 = load i64, ptr %t79, !tbaa !34
  store ptr %l7, ptr %l45, !tbaa !29
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/emit:Emitter", ptr %t82, i32 0, i32 16
  %t88 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v0, ptr %t84, i64 %t80)
  store { i64, ptr } %t88, ptr %l49
  br label %bb22
bb22:
  %t89 = load ptr, ptr %l45, !tbaa !29
  %t90 = load { i64, ptr }, ptr %l49, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t89, { i64, ptr } %t90)
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s4)
  br label %bb24
bb24:
  %t91 = load i64, ptr %l9, !tbaa !24
  %t93 = add i64 %t91, 1
  store i64 %t93, ptr %l9, !tbaa !24
  br label %bb18
bb25:
  %t96 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l7)
  store { i64, ptr } %t96, ptr %l53
  br label %bb26
bb26:
  %t97 = load { i64, ptr }, ptr %l53, !tbaa !27
  store { i64, ptr } %t97, ptr %l54, !tbaa !27
  %t98 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t99 = extractvalue { i64, ptr } %t98, 0
  store i64 %t99, ptr %l55, !tbaa !24
  %t100 = load i64, ptr %l55, !tbaa !24
  %t101 = mul i64 %t100, 1
  %t102 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t101)
  %t103 = insertvalue { i64, ptr } undef, i64 %t100, 0
  %t104 = insertvalue { i64, ptr } %t103, ptr %t102, 1
  store { i64, ptr } %t104, ptr %l56, !tbaa !27
  %t105 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !27
  %t107 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t108 = load ptr, ptr %t107, !tbaa !27
  %t109 = load i64, ptr %l55, !tbaa !24
  %t110 = mul i64 %t109, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t106, ptr %t108, i64 %t110, i1 false)
  %t111 = load { i64, ptr }, ptr %l56, !tbaa !27
  store { i64, ptr } %t111, ptr %l54, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t112 = load { i64, ptr }, ptr %l54, !tbaa !27
  store { i64, ptr } %t112, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2epartOf(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l11 = alloca i1
  %l12 = alloca i64
  %l13 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i32
  %l24 = alloca { i64, ptr }
  %l26 = alloca i1
  %l27 = alloca i64
  %l29 = alloca i64
  %l34 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp sle i64 %t1, 1
  br i1 %t3, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  store i64 0, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load i64, ptr %l1, !tbaa !24
  %t10 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ealiased(ptr %v0, ptr %t6, i64 %t7)
  store i1 %t10, ptr %l11
  br label %bb4
bb4:
  %t11 = load i1, ptr %l11, !tbaa !21
  br i1 %t11, label %bb5, label %bb6
bb5:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/emit:Emitter", ptr %t12, i32 0, i32 57
  %t15 = load i64, ptr %l1, !tbaa !24
  %t18 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t14, i64 %t15)
  %t19 = extractvalue { i32, i64 } %t18, 1
  %t20 = extractvalue { i32, i64 } %t18, 0
  store i32 %t20, ptr %l18
  %t21 = icmp ne i32 %t20, 0
  br i1 %t21, label %bb8, label %ok.22
ok.22:
  store i64 %t19, ptr %l17
  br label %bb7
bb6:
  %t23 = load i64, ptr %l1, !tbaa !24
  store i64 %t23, ptr %l12, !tbaa !24
  br label %bb11
bb7:
  %t25 = load i64, ptr %l17, !tbaa !24
  store i64 %t25, ptr %l13, !tbaa !24
  br label %bb10
bb8:
  br label %bb9
bb9:
  call void @__olang_ert_req_clear()
  %t26 = load i64, ptr %l1, !tbaa !24
  store i64 %t26, ptr %l13, !tbaa !24
  br label %bb10
bb10:
  %t28 = load i64, ptr %l13, !tbaa !24
  store i64 %t28, ptr %l12, !tbaa !24
  br label %bb11
bb11:
  %t29 = load i64, ptr %l12, !tbaa !24
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/emit:Emitter", ptr %t30, i32 0, i32 15
  %t36 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v0, ptr %t32, i64 %t29)
  store { i64, ptr } %t36, ptr %l24
  br label %bb12
bb12:
  %t37 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t37, ptr %l4, !tbaa !27
  %t38 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t40 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t38, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d328, i32 0, i32 1) })
  store i1 %t40, ptr %l26
  br label %bb13
bb13:
  %t41 = load i1, ptr %l26, !tbaa !21
  br i1 %t41, label %bb14, label %bb15
bb14:
  store i64 0, ptr %l27, !tbaa !24
  br label %bb17
bb15:
  %t42 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t44 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eHash(ptr %v0, { i64, ptr } %t42)
  store i64 %t44, ptr %l29
  br label %bb16
bb16:
  %t45 = load i64, ptr %l29, !tbaa !24
  store i64 %t45, ptr %l27, !tbaa !24
  br label %bb17
bb17:
  %t46 = load i64, ptr %l2, !tbaa !24
  %t47 = load i64, ptr %l27, !tbaa !24
  %t49 = srem i64 %t47, %t46
  store i64 %t49, ptr %l5, !tbaa !24
  %t51 = load i64, ptr %l5, !tbaa !24
  %t53 = icmp slt i64 %t51, 0
  br i1 %t53, label %bb18, label %bb19
bb18:
  %t55 = load i64, ptr %l5, !tbaa !24
  %t56 = load i64, ptr %l2, !tbaa !24
  %t59 = add i64 %t55, %t56
  store i64 %t59, ptr %l34, !tbaa !24
  br label %bb20
bb19:
  %t61 = load i64, ptr %l5, !tbaa !24
  store i64 %t61, ptr %l34, !tbaa !24
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s0)
  %t63 = load i64, ptr %l34, !tbaa !24
  store i64 %t63, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2epow2(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l8 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t2 = bitcast double 0x3ff0000000000000 to i64
  %t6 = shl i64 %a1, 52
  %t9 = add i64 %t2, %t6
  %t12 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2econstText(ptr %v0, ptr %v1, ptr %a0, i32 14, i64 %t9)
  store { i64, ptr } %t12, ptr %l8
  br label %bb1
bb1:
  %t13 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t13, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3aEmitter_2esignature(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l10 = alloca ptr
  %l13 = alloca i32
  %l14 = alloca i32
  %l20 = alloca i32
  %l24 = alloca i1
  %l31 = alloca i1
  %l32 = alloca ptr
  %l35 = alloca i32
  %l36 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l49 = alloca i1
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  store ptr %t6, ptr %l10, !tbaa !29
  %t7 = load ptr, ptr %l2, !tbaa !29
  %t8 = load i32, ptr %l1, !tbaa !23
  %t11 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t7, i32 %t8)
  store i32 %t11, ptr %l13
  br label %bb1
bb1:
  %t12 = load ptr, ptr %l10, !tbaa !29
  %t13 = load i32, ptr %l13, !tbaa !23
  %t14 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t14, ptr %l14
  br label %bb2
bb2:
  %t15 = load i32, ptr %l14
  %t17 = trunc i64 21 to i32
  %t18 = icmp eq i32 %t15, %t17
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb3, label %bb4
bb3:
  br label %ret
bb4:
  br label %bb5
bb5:
  %t22 = load ptr, ptr %l2, !tbaa !29
  %t23 = load i32, ptr %l1, !tbaa !23
  %t26 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t22, i32 %t23)
  store i32 %t26, ptr %l20
  br label %bb6
bb6:
  %t27 = load i32, ptr %l20, !tbaa !23
  store i32 %t27, ptr %l3, !tbaa !23
  %t28 = load i32, ptr %l3, !tbaa !23
  %t29 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t32 = icmp ne i32 %t28, %t29
  br i1 %t32, label %bb7, label %bb8
bb7:
  %t34 = load i32, ptr %l3, !tbaa !23
  %t35 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t38 = icmp ne i32 %t34, %t35
  store i1 %t38, ptr %l24, !tbaa !21
  br label %bb9
bb8:
  store i1 false, ptr %l24, !tbaa !21
  br label %bb9
bb9:
  %t40 = load i1, ptr %l24, !tbaa !21
  br i1 %t40, label %bb10, label %bb11
bb10:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/emit:Emitter", ptr %t41, i32 0, i32 0
  %t44 = load ptr, ptr %t43, !tbaa !29
  %t45 = load i32, ptr %l3, !tbaa !23
  %t48 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLayout(ptr %v0, ptr %t44, i32 %t45)
  store i1 %t48, ptr %l31
  br label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb13
bb13:
  %t49 = load ptr, ptr %l2, !tbaa !29
  store ptr %t49, ptr %l32, !tbaa !29
  %t50 = load ptr, ptr %l2, !tbaa !29
  %t51 = load i32, ptr %l1, !tbaa !23
  %t54 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t50, i32 %t51)
  store i32 %t54, ptr %l35
  br label %bb14
bb14:
  %t55 = load ptr, ptr %l32, !tbaa !29
  %t56 = load i32, ptr %l35, !tbaa !23
  %t57 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t55, i32 %t56)
  store { i64, ptr } %t57, ptr %l36
  br label %bb15
bb15:
  %t58 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t58, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t59 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t61 = extractvalue { i64, ptr } %t59, 0
  store i64 %t61, ptr %l6, !tbaa !24
  br label %bb16
bb16:
  store %olang.scope zeroinitializer, ptr %s4
  %t63 = load i64, ptr %l5, !tbaa !24
  %t64 = load i64, ptr %l6, !tbaa !24
  %t67 = icmp slt i64 %t63, %t64
  %t69 = xor i1 %t67, true
  br i1 %t69, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s4)
  br label %bb22
bb18:
  br label %bb19
bb19:
  %t71 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t71, ptr %l43, !tbaa !27
  %t72 = load i64, ptr %l5, !tbaa !24
  %t74 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t75 = load ptr, ptr %t74, !tbaa !27
  %t76 = getelementptr i32, ptr %t75, i64 %t72
  %t77 = load i32, ptr %t76, !tbaa !33
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/emit:Emitter", ptr %t79, i32 0, i32 0
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t86 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLayout(ptr %v0, ptr %t82, i32 %t77)
  store i1 %t86, ptr %l49
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s4)
  br label %bb21
bb21:
  %t87 = load i64, ptr %l5, !tbaa !24
  %t89 = add i64 %t87, 1
  store i64 %t89, ptr %l5, !tbaa !24
  br label %bb16
bb22:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2estub(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l9 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t5 = extractvalue { i64, ptr } %a1, 1
  %t6 = extractvalue { i64, ptr } %a1, 0
  %t7 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d329, i32 0, i32 1) }, 1
  %t8 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d329, i32 0, i32 1) }, 0
  %t9 = add i64 %t6, %t8
  %t11 = extractvalue { i64, ptr } %a2, 1
  %t12 = extractvalue { i64, ptr } %a2, 0
  %t13 = add i64 %t9, %t12
  %t14 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d330, i32 0, i32 1) }, 1
  %t15 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d330, i32 0, i32 1) }, 0
  %t16 = add i64 %t13, %t15
  %t17 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t16)
  call void @olang_textcopy(ptr %t17, ptr %t5, i64 %t6)
  %t18 = getelementptr i8, ptr %t17, i64 %t6
  call void @olang_textcopy(ptr %t18, ptr %t7, i64 %t8)
  %t19 = getelementptr i8, ptr %t18, i64 %t8
  call void @olang_textcopy(ptr %t19, ptr %t11, i64 %t12)
  %t20 = getelementptr i8, ptr %t19, i64 %t12
  call void @olang_textcopy(ptr %t20, ptr %t14, i64 %t15)
  %t21 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t17, 1
  %t24 = extractvalue { i64, ptr } %t22, 0
  %t25 = extractvalue { i64, ptr } %t22, 1
  %t26 = mul i64 %t24, 1
  %t27 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t26)
  call void @llvm.memcpy.p0.p0.i64(ptr %t27, ptr %t25, i64 %t26, i1 false)
  %t28 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t27, 1
  %t32 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecstr(ptr %v0, ptr %s0, ptr %s0, ptr %a0, { i64, ptr } %t29)
  store { i64, ptr } %t32, ptr %l9
  br label %bb1
bb1:
  %t33 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t35 = extractvalue { i64, ptr } { i64 45, ptr getelementptr inbounds (<{ i64, [45 x i8] }>, ptr @.d331, i32 0, i32 1) }, 1
  %t36 = extractvalue { i64, ptr } { i64 45, ptr getelementptr inbounds (<{ i64, [45 x i8] }>, ptr @.d331, i32 0, i32 1) }, 0
  %t38 = extractvalue { i64, ptr } %t33, 1
  %t39 = extractvalue { i64, ptr } %t33, 0
  %t40 = add i64 %t36, %t39
  %t41 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d332, i32 0, i32 1) }, 1
  %t42 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d332, i32 0, i32 1) }, 0
  %t43 = add i64 %t40, %t42
  %t44 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t43)
  call void @olang_textcopy(ptr %t44, ptr %t35, i64 %t36)
  %t45 = getelementptr i8, ptr %t44, i64 %t36
  call void @olang_textcopy(ptr %t45, ptr %t38, i64 %t39)
  %t46 = getelementptr i8, ptr %t45, i64 %t39
  call void @olang_textcopy(ptr %t46, ptr %t41, i64 %t42)
  %t47 = insertvalue { i64, ptr } undef, i64 %t43, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t44, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t48, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2esym(ptr %v0, ptr %v1, ptr %a0, { i64, [2 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [2 x i64] }
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i1
  %l12 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l24 = alloca i32
  %l27 = alloca i32
  %l30 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l57 = alloca ptr
  %l62 = alloca { i64, ptr }
  %l68 = alloca { i64, ptr }
  %l71 = alloca { i64, ptr }
  %l74 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.builder
  %s3room = alloca [64 x i8], align 8
  %s4 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, [2 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load { i64, [2 x i64] }, ptr %l1
  %t8 = extractvalue { i64, [2 x i64] } %t6, 0
  %t9 = icmp eq i64 %t8, 0
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t12 = getelementptr { i32 }, ptr %t11, i32 0, i32 0
  %t13 = load i32, ptr %t12
  store i32 %t13, ptr %l3, !tbaa !23
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load i32, ptr %l3, !tbaa !23
  %t18 = sext i32 %t16 to i64
  %t21 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ebodySym(ptr %v0, ptr %v1, ptr %t15, i64 %t18)
  store { i64, ptr } %t21, ptr %l19
  br label %bb4
bb4:
  %t22 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t22, ptr %l12, !tbaa !27
  br label %bb38
bb5:
  %t23 = load { i64, [2 x i64] }, ptr %l1
  %t25 = extractvalue { i64, [2 x i64] } %t23, 0
  %t26 = icmp eq i64 %t25, 2
  br i1 %t26, label %bb6, label %bb7
bb6:
  %t28 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t29 = getelementptr { i32, i32 }, ptr %t28, i32 0, i32 0
  %t30 = load i32, ptr %t29
  store i32 %t30, ptr %l4
  %t32 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t33 = getelementptr { i32, i32 }, ptr %t32, i32 0, i32 1
  %t34 = load i32, ptr %t33
  store i32 %t34, ptr %l5, !tbaa !23
  br label %bb8
bb7:
  br label %bb17
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t36 = load i32, ptr %l4
  store i32 %t36, ptr %l24
  %t37 = load ptr, ptr %l2, !tbaa !29
  %t38 = load i32, ptr %l5, !tbaa !23
  %t41 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eUnnamed(ptr %v0, ptr %t37, i32 %t38)
  store i32 %t41, ptr %l27
  br label %bb9
bb9:
  %t42 = load i32, ptr %l5, !tbaa !23
  %t43 = load i32, ptr %l27, !tbaa !23
  %t45 = icmp eq i32 %t43, %t42
  br i1 %t45, label %bb10, label %bb11
bb10:
  %t47 = load ptr, ptr %l2, !tbaa !29
  %t48 = load i32, ptr %l5, !tbaa !23
  %t51 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s2, ptr %t47, i32 %t48)
  store { i64, ptr } %t51, ptr %l33
  br label %bb12
bb11:
  %t52 = load ptr, ptr %l2, !tbaa !29
  %t53 = load i32, ptr %l5, !tbaa !23
  %t56 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanonNamed(ptr %v0, ptr %s2, ptr %t52, i32 %t53)
  store { i64, ptr } %t56, ptr %l36
  br label %bb13
bb12:
  %t57 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t57, ptr %l30, !tbaa !27
  br label %bb14
bb13:
  %t58 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t58, ptr %l30, !tbaa !27
  br label %bb14
bb14:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s3
  store ptr %s3room, ptr %s3
  %t59 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d333, i32 0, i32 1) }, 1
  %t60 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d333, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t59, i64 %t60)
  call void @olang_2eHelperKind_2eRender_2ecompiler_2fmir_3aHelperKind(ptr %s3, ptr %l24, i64 0)
  br label %bb15
bb15:
  %t62 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d334, i32 0, i32 1) }, 1
  %t63 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d334, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t62, i64 %t63)
  %t64 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t64, 1
  %t66 = extractvalue { i64, ptr } %t64, 0
  call void @__olang_sb_put(ptr %s3, ptr %t65, i64 %t66)
  %t67 = load ptr, ptr %s3
  %t68 = getelementptr %olang.builder, ptr %s3, i32 0, i32 1
  %t69 = load i64, ptr %t68
  %t70 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t69)
  call void @olang_textcopy(ptr %t70, ptr %t67, i64 %t69)
  %t71 = insertvalue { i64, ptr } undef, i64 %t69, 0
  %t72 = insertvalue { i64, ptr } %t71, ptr %t70, 1
  store { i64, ptr } %t72, ptr %l38, !tbaa !27
  %t73 = getelementptr %olang.builder, ptr %s3, i32 0, i32 3
  %t74 = load ptr, ptr %t73
  %t75 = icmp ne ptr %t74, null
  br i1 %t75, label %sbgrew.76, label %sbdone.77
sbgrew.76:
  call void @__olang_sb_done(ptr %s3)
  br label %sbdone.77
sbdone.77:
  %t78 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t79 = extractvalue { i64, ptr } %t78, 0
  %t80 = extractvalue { i64, ptr } %t78, 1
  %t81 = mul i64 %t79, 1
  %t82 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t81)
  call void @llvm.memcpy.p0.p0.i64(ptr %t82, ptr %t80, i64 %t81, i1 false)
  %t83 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t84 = insertvalue { i64, ptr } %t83, ptr %t82, 1
  %t86 = call { i64, ptr } @compiler_2ftypes_2eSymbol(ptr %v1, ptr %v1, { i64, ptr } %t84)
  store { i64, ptr } %t86, ptr %l40
  br label %bb16
bb16:
  %t87 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t87, ptr %l12, !tbaa !27
  call void @__olang_scope_close(ptr %s2)
  br label %bb38
bb17:
  %t88 = load { i64, [2 x i64] }, ptr %l1
  %t90 = extractvalue { i64, [2 x i64] } %t88, 0
  %t91 = icmp eq i64 %t90, 1
  br i1 %t91, label %bb18, label %bb19
bb18:
  %t93 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t94 = getelementptr { i32 }, ptr %t93, i32 0, i32 0
  %t95 = load i32, ptr %t94
  store i32 %t95, ptr %l6, !tbaa !23
  br label %bb20
bb19:
  br label %bb22
bb20:
  store %olang.scope zeroinitializer, ptr %s4
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t98 = load i32, ptr %l6, !tbaa !23
  %t100 = sext i32 %t98 to i64
  %t103 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ebodySym(ptr %v0, ptr %s4, ptr %t97, i64 %t100)
  store { i64, ptr } %t103, ptr %l47
  br label %bb21
bb21:
  %t104 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t105 = extractvalue { i64, ptr } %t104, 1
  %t106 = extractvalue { i64, ptr } %t104, 0
  %t107 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d335, i32 0, i32 1) }, 1
  %t108 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d335, i32 0, i32 1) }, 0
  %t109 = add i64 %t106, %t108
  %t110 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t109)
  call void @olang_textcopy(ptr %t110, ptr %t105, i64 %t106)
  %t111 = getelementptr i8, ptr %t110, i64 %t106
  call void @olang_textcopy(ptr %t111, ptr %t107, i64 %t108)
  %t112 = insertvalue { i64, ptr } undef, i64 %t109, 0
  %t113 = insertvalue { i64, ptr } %t112, ptr %t110, 1
  store { i64, ptr } %t113, ptr %l12, !tbaa !27
  call void @__olang_scope_close(ptr %s4)
  br label %bb38
bb22:
  %t115 = load { i64, [2 x i64] }, ptr %l1
  %t117 = extractvalue { i64, [2 x i64] } %t115, 0
  %t118 = icmp eq i64 %t117, 3
  br i1 %t118, label %bb23, label %bb24
bb23:
  %t120 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t121 = getelementptr { i64 }, ptr %t120, i32 0, i32 0
  %t122 = load i64, ptr %t121
  store i64 %t122, ptr %l7, !tbaa !24
  br label %bb25
bb24:
  br label %bb28
bb25:
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t126 = getelementptr %"compiler/emit:Emitter", ptr %t124, i32 0, i32 0
  %t127 = load ptr, ptr %t126, !tbaa !29
  %t129 = getelementptr %"compiler/generic:Program", ptr %t127, i32 0, i32 0
  %t130 = load ptr, ptr %t129, !tbaa !29
  %t132 = getelementptr %"compiler/load:Loader", ptr %t130, i32 0, i32 5
  %t133 = load i64, ptr %l7, !tbaa !24
  %t136 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t132, i64 %t133)
  store ptr %t136, ptr %l57
  br label %bb26
bb26:
  %t137 = load ptr, ptr %l57, !tbaa !29
  %t139 = getelementptr %"compiler/load:Module", ptr %t137, i32 0, i32 2
  %t140 = load { i64, ptr }, ptr %t139, !tbaa !27
  %t141 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d336, i32 0, i32 1) }, 1
  %t142 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d336, i32 0, i32 1) }, 0
  %t144 = extractvalue { i64, ptr } %t140, 1
  %t145 = extractvalue { i64, ptr } %t140, 0
  %t146 = add i64 %t142, %t145
  %t147 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t146)
  call void @olang_textcopy(ptr %t147, ptr %t141, i64 %t142)
  %t148 = getelementptr i8, ptr %t147, i64 %t142
  call void @olang_textcopy(ptr %t148, ptr %t144, i64 %t145)
  %t149 = insertvalue { i64, ptr } undef, i64 %t146, 0
  %t150 = insertvalue { i64, ptr } %t149, ptr %t147, 1
  %t152 = extractvalue { i64, ptr } %t150, 0
  %t153 = extractvalue { i64, ptr } %t150, 1
  %t154 = mul i64 %t152, 1
  %t155 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t154)
  call void @llvm.memcpy.p0.p0.i64(ptr %t155, ptr %t153, i64 %t154, i1 false)
  %t156 = insertvalue { i64, ptr } undef, i64 %t152, 0
  %t157 = insertvalue { i64, ptr } %t156, ptr %t155, 1
  %t159 = call { i64, ptr } @compiler_2ftypes_2eSymbol(ptr %v1, ptr %v1, { i64, ptr } %t157)
  store { i64, ptr } %t159, ptr %l62
  br label %bb27
bb27:
  %t160 = load { i64, ptr }, ptr %l62, !tbaa !27
  store { i64, ptr } %t160, ptr %l12, !tbaa !27
  br label %bb38
bb28:
  %t161 = load { i64, [2 x i64] }, ptr %l1
  %t163 = extractvalue { i64, [2 x i64] } %t161, 0
  %t164 = icmp eq i64 %t163, 4
  br i1 %t164, label %bb29, label %bb30
bb29:
  %t166 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t167 = getelementptr { i64, i1 }, ptr %t166, i32 0, i32 0
  %t168 = load i64, ptr %t167
  store i64 %t168, ptr %l8, !tbaa !24
  %t170 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t171 = getelementptr { i64, i1 }, ptr %t170, i32 0, i32 1
  %t172 = load i1, ptr %t171
  store i1 %t172, ptr %l9, !tbaa !21
  br label %bb31
bb30:
  br label %bb37
bb31:
  store %olang.scope zeroinitializer, ptr %s8
  %t174 = load i1, ptr %l9, !tbaa !21
  br i1 %t174, label %bb32, label %bb33
bb32:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d337, i32 0, i32 1) }, ptr %l68, !tbaa !27
  br label %bb34
bb33:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d338, i32 0, i32 1) }, ptr %l68, !tbaa !27
  br label %bb34
bb34:
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t177 = load i64, ptr %l8, !tbaa !24
  %t180 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etableName(ptr %v0, ptr %s8, ptr %t176, i64 %t177)
  store { i64, ptr } %t180, ptr %l71
  br label %bb35
bb35:
  %t181 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d339, i32 0, i32 1) }, 1
  %t182 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d339, i32 0, i32 1) }, 0
  %t183 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t184 = extractvalue { i64, ptr } %t183, 1
  %t185 = extractvalue { i64, ptr } %t183, 0
  %t186 = add i64 %t182, %t185
  %t187 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d340, i32 0, i32 1) }, 1
  %t188 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d340, i32 0, i32 1) }, 0
  %t189 = add i64 %t186, %t188
  %t190 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t191 = extractvalue { i64, ptr } %t190, 1
  %t192 = extractvalue { i64, ptr } %t190, 0
  %t193 = add i64 %t189, %t192
  %t194 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t193)
  call void @olang_textcopy(ptr %t194, ptr %t181, i64 %t182)
  %t195 = getelementptr i8, ptr %t194, i64 %t182
  call void @olang_textcopy(ptr %t195, ptr %t184, i64 %t185)
  %t196 = getelementptr i8, ptr %t195, i64 %t185
  call void @olang_textcopy(ptr %t196, ptr %t187, i64 %t188)
  %t197 = getelementptr i8, ptr %t196, i64 %t188
  call void @olang_textcopy(ptr %t197, ptr %t191, i64 %t192)
  %t198 = insertvalue { i64, ptr } undef, i64 %t193, 0
  %t199 = insertvalue { i64, ptr } %t198, ptr %t194, 1
  %t201 = extractvalue { i64, ptr } %t199, 0
  %t202 = extractvalue { i64, ptr } %t199, 1
  %t203 = mul i64 %t201, 1
  %t204 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t203)
  call void @llvm.memcpy.p0.p0.i64(ptr %t204, ptr %t202, i64 %t203, i1 false)
  %t205 = insertvalue { i64, ptr } undef, i64 %t201, 0
  %t206 = insertvalue { i64, ptr } %t205, ptr %t204, 1
  %t208 = call { i64, ptr } @compiler_2ftypes_2eSymbol(ptr %v1, ptr %v1, { i64, ptr } %t206)
  store { i64, ptr } %t208, ptr %l74
  br label %bb36
bb36:
  %t209 = load { i64, ptr }, ptr %l74, !tbaa !27
  store { i64, ptr } %t209, ptr %l12, !tbaa !27
  call void @__olang_scope_close(ptr %s8)
  br label %bb38
bb37:
  call void @__olang_check_failed(ptr @olang_loc_325a0aca37049b03_8faf0435ed6a0227)
  unreachable
bb38:
  %t210 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t210, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etableName(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"compiler/generic:AnyTable"
  %l7 = alloca %"compiler/generic:AnyTable"
  %l10 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 40
  %t10 = call %"compiler/generic:AnyTable" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fgeneric_3aAnyTable_3e_2e_H5e3c685c1de22cee1b092c35d74f13cd(ptr %v0, ptr %v0, ptr %t6, i64 %a1)
  store %"compiler/generic:AnyTable" %t10, ptr %l7
  br label %bb1
bb1:
  %t11 = load %"compiler/generic:AnyTable", ptr %l7
  store %"compiler/generic:AnyTable" %t11, ptr %l2
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/generic:AnyTable", ptr %l2, i32 0, i32 0
  %t14 = load i32, ptr %t13, !tbaa !23
  %t17 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecanonOf(ptr %v0, ptr %s0, ptr %t12, i32 %t14)
  store { i64, ptr } %t17, ptr %l10
  br label %bb2
bb2:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/generic:AnyTable", ptr %l2, i32 0, i32 1
  %t20 = load i32, ptr %t19, !tbaa !23
  %t23 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecanonOf(ptr %v0, ptr %s0, ptr %t18, i32 %t20)
  store { i64, ptr } %t23, ptr %l13
  br label %bb3
bb3:
  %t24 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t24, 1
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t27 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d341, i32 0, i32 1) }, 1
  %t28 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d341, i32 0, i32 1) }, 0
  %t29 = add i64 %t26, %t28
  %t30 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t31 = extractvalue { i64, ptr } %t30, 1
  %t32 = extractvalue { i64, ptr } %t30, 0
  %t33 = add i64 %t29, %t32
  %t34 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t33)
  call void @olang_textcopy(ptr %t34, ptr %t25, i64 %t26)
  %t35 = getelementptr i8, ptr %t34, i64 %t26
  call void @olang_textcopy(ptr %t35, ptr %t27, i64 %t28)
  %t36 = getelementptr i8, ptr %t35, i64 %t28
  call void @olang_textcopy(ptr %t36, ptr %t31, i64 %t32)
  %t37 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t38 = insertvalue { i64, ptr } %t37, ptr %t34, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t38, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3aEmitter_2etextCopy(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca i1
  %l5 = alloca %"std/prelude/text:StringBuilder"
  %l22 = alloca ptr
  %l23 = alloca i64
  %l25 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ehas(ptr %v0, ptr %s0, ptr %t1, { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d342, i32 0, i32 1) })
  store i1 %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load i1, ptr %l3, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  %t5 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s0, ptr %s0, ptr %t5, { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d343, i32 0, i32 1) }, { i64, ptr } { i64 46, ptr getelementptr inbounds (<{ i64, [46 x i8] }>, ptr @.d344, i32 0, i32 1) })
  br label %bb5
bb5:
  %t7 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t7, ptr %l5
  br label %bb6
bb6:
  %t8 = load %"std/prelude/text:StringBuilder", ptr %l5
  store %"std/prelude/text:StringBuilder" %t8, ptr %l1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l1, { i64, ptr } { i64 94, ptr getelementptr inbounds (<{ i64, [94 x i8] }>, ptr @.d345, i32 0, i32 1) })
  br label %bb7
bb7:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l1, { i64, ptr } { i64 66, ptr getelementptr inbounds (<{ i64, [66 x i8] }>, ptr @.d346, i32 0, i32 1) })
  br label %bb8
bb8:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l1, { i64, ptr } { i64 86, ptr getelementptr inbounds (<{ i64, [86 x i8] }>, ptr @.d347, i32 0, i32 1) })
  br label %bb9
bb9:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l1, { i64, ptr } { i64 67, ptr getelementptr inbounds (<{ i64, [67 x i8] }>, ptr @.d348, i32 0, i32 1) })
  br label %bb10
bb10:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l1, { i64, ptr } { i64 103, ptr getelementptr inbounds (<{ i64, [103 x i8] }>, ptr @.d349, i32 0, i32 1) })
  br label %bb11
bb11:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l1, { i64, ptr } { i64 112, ptr getelementptr inbounds (<{ i64, [112 x i8] }>, ptr @.d350, i32 0, i32 1) })
  br label %bb12
bb12:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l1, { i64, ptr } { i64 46, ptr getelementptr inbounds (<{ i64, [46 x i8] }>, ptr @.d351, i32 0, i32 1) })
  br label %bb13
bb13:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l1, { i64, ptr } { i64 67, ptr getelementptr inbounds (<{ i64, [67 x i8] }>, ptr @.d352, i32 0, i32 1) })
  br label %bb14
bb14:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l1, { i64, ptr } { i64 103, ptr getelementptr inbounds (<{ i64, [103 x i8] }>, ptr @.d353, i32 0, i32 1) })
  br label %bb15
bb15:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l1, { i64, ptr } { i64 112, ptr getelementptr inbounds (<{ i64, [112 x i8] }>, ptr @.d354, i32 0, i32 1) })
  br label %bb16
bb16:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l1, { i64, ptr } { i64 46, ptr getelementptr inbounds (<{ i64, [46 x i8] }>, ptr @.d355, i32 0, i32 1) })
  br label %bb17
bb17:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l1, { i64, ptr } { i64 70, ptr getelementptr inbounds (<{ i64, [70 x i8] }>, ptr @.d356, i32 0, i32 1) })
  br label %bb18
bb18:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l1, { i64, ptr } { i64 113, ptr getelementptr inbounds (<{ i64, [113 x i8] }>, ptr @.d357, i32 0, i32 1) })
  br label %bb19
bb19:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l1, { i64, ptr } { i64 115, ptr getelementptr inbounds (<{ i64, [115 x i8] }>, ptr @.d358, i32 0, i32 1) })
  br label %bb20
bb20:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l1, { i64, ptr } { i64 107, ptr getelementptr inbounds (<{ i64, [107 x i8] }>, ptr @.d359, i32 0, i32 1) })
  br label %bb21
bb21:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l1, { i64, ptr } { i64 60, ptr getelementptr inbounds (<{ i64, [60 x i8] }>, ptr @.d360, i32 0, i32 1) })
  br label %bb22
bb22:
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l22, !tbaa !29
  %t26 = load i64, ptr @G_2ecompiler_2femit_2eHomeShared, !tbaa !24
  store i64 %t26, ptr %l23, !tbaa !24
  %t28 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l1)
  store { i64, ptr } %t28, ptr %l25
  br label %bb23
bb23:
  %t29 = load ptr, ptr %l22, !tbaa !29
  %t30 = load i64, ptr %l23, !tbaa !24
  %t31 = load { i64, ptr }, ptr %l25, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eitem(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %t29, { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d361, i32 0, i32 1) }, i64 %t30, { i64, ptr } %t31, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d8, i32 0, i32 1) })
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3aEmitter_2ewantType(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l20 = alloca { i64, ptr }
  %l22 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l24 = alloca i64
  %l28 = alloca i64
  %l31 = alloca i64
  %l51 = alloca i64
  %l53 = alloca i64
  %l55 = alloca ptr
  %l56 = alloca { i64, ptr }
  %l60 = alloca i64
  %l64 = alloca i64
  %l65 = alloca i64
  %l70 = alloca i64
  %l71 = alloca i32
  %l74 = alloca i1
  %l77 = alloca i1
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l3, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v2, ptr %t1, i64 %t2, i1 true)
  br label %bb1
bb1:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t5, i64 %t6)
  br label %bb2
bb2:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/emit:Emitter", ptr %t9, i32 0, i32 42
  %t12 = load i64, ptr %l1, !tbaa !24
  %t15 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v0, ptr %t11, i64 %t12)
  store { i64, ptr } %t15, ptr %l20
  br label %bb3
bb3:
  %t16 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t16, ptr %l4, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2femit_2erefsIn(ptr %v0, ptr %s0, { i64, ptr } %t17)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t19, ptr %l22
  br label %bb4
bb4:
  %t20 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l22
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t20, ptr %l5
  store i64 0, ptr %l6, !tbaa !24
  %t22 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l5)
  store i64 %t22, ptr %l24
  br label %bb5
bb5:
  %t23 = load i64, ptr %l24, !tbaa !24
  store i64 %t23, ptr %l7, !tbaa !24
  store i64 3, ptr %l8, !tbaa !24
  %t24 = load i64, ptr %l7, !tbaa !24
  %t25 = load i64, ptr %l6, !tbaa !24
  %t28 = icmp sgt i64 %t24, %t25
  br i1 %t28, label %bb6, label %bb7
bb6:
  %t30 = load i64, ptr %l8, !tbaa !24
  %t32 = icmp sgt i64 %t30, 0
  br i1 %t32, label %bb8, label %bb9
bb7:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb11
bb8:
  %t34 = load i64, ptr %l7, !tbaa !24
  %t35 = load i64, ptr %l6, !tbaa !24
  %t38 = sub i64 %t34, %t35
  %t39 = load i64, ptr %l8, !tbaa !24
  %t42 = add i64 %t38, %t39
  %t44 = sub i64 %t42, 1
  %t45 = load i64, ptr %l8, !tbaa !24
  %t48 = sdiv i64 %t44, %t45
  store i64 %t48, ptr %l31, !tbaa !24
  br label %bb10
bb9:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb10
bb10:
  %t50 = load i64, ptr %l31, !tbaa !24
  store i64 %t50, ptr %l28, !tbaa !24
  br label %bb11
bb11:
  %t51 = load i64, ptr %l28, !tbaa !24
  store i64 %t51, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t52 = load i64, ptr %l10, !tbaa !24
  %t53 = load i64, ptr %l9, !tbaa !24
  %t56 = icmp slt i64 %t52, %t53
  %t58 = xor i1 %t56, true
  br i1 %t58, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s2)
  br label %bb41
bb14:
  br label %bb15
bb15:
  %t60 = load i64, ptr %l6, !tbaa !24
  %t61 = load i64, ptr %l10, !tbaa !24
  %t62 = load i64, ptr %l8, !tbaa !24
  %t65 = mul i64 %t61, %t62
  %t68 = add i64 %t60, %t65
  store i64 %t68, ptr %l11, !tbaa !24
  %t70 = load i64, ptr %l11, !tbaa !24
  %t73 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l5, i64 %t70)
  store i64 %t73, ptr %l51
  br label %bb16
bb16:
  %t74 = load i64, ptr %l51, !tbaa !24
  %t75 = icmp ne i64 %t74, 1
  br i1 %t75, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s2)
  br label %bb40
bb18:
  br label %bb19
bb19:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/emit:Emitter", ptr %t77, i32 0, i32 43
  store ptr %t79, ptr %l55, !tbaa !29
  %t80 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t80, ptr %l56, !tbaa !27
  %t81 = load i64, ptr %l11, !tbaa !24
  %t83 = add i64 %t81, 1
  %t86 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l5, i64 %t83)
  store i64 %t86, ptr %l60
  br label %bb20
bb20:
  %t87 = load i64, ptr %l11, !tbaa !24
  %t89 = add i64 %t87, 2
  %t92 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l5, i64 %t89)
  store i64 %t92, ptr %l64
  br label %bb21
bb21:
  %t93 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t94 = extractvalue { i64, ptr } %t93, 0
  store i64 %t94, ptr %l65, !tbaa !24
  %t95 = load i64, ptr %l60, !tbaa !24
  %t96 = icmp sge i64 %t95, 0
  br i1 %t96, label %bb22, label %bb23
bb22:
  %t98 = load i64, ptr %l60, !tbaa !24
  %t99 = load i64, ptr %l64, !tbaa !24
  %t100 = icmp sle i64 %t98, %t99
  br i1 %t100, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_6f064da57090b2af_17093dce158f11fb)
  unreachable
bb24:
  %t102 = load i64, ptr %l64, !tbaa !24
  %t103 = load i64, ptr %l65, !tbaa !24
  %t104 = icmp sle i64 %t102, %t103
  br i1 %t104, label %bb26, label %bb27
bb25:
  call void @__olang_check_failed(ptr @olang_loc_6f064da57090b2af_17093dce158f11fb)
  unreachable
bb26:
  %t106 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !27
  %t108 = load i64, ptr %l60, !tbaa !24
  %t109 = load i64, ptr %l64, !tbaa !24
  %t110 = getelementptr i8, ptr %t107, i64 %t108
  %t111 = sub i64 %t109, %t108
  %t112 = insertvalue { i64, ptr } undef, i64 %t111, 0
  %t113 = insertvalue { i64, ptr } %t112, ptr %t110, 1
  %t114 = load ptr, ptr %l55, !tbaa !29
  %t116 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9162e3b7f03fcbf954b681204d5f6cca(ptr %v0, ptr %v0, ptr %t114, { i64, ptr } %t113)
  %t117 = extractvalue { i32, i64 } %t116, 1
  %t118 = extractvalue { i32, i64 } %t116, 0
  store i32 %t118, ptr %l71
  %t119 = icmp ne i32 %t118, 0
  br i1 %t119, label %bb29, label %ok.120
ok.120:
  store i64 %t117, ptr %l70
  br label %bb28
bb27:
  call void @__olang_check_failed(ptr @olang_loc_6f064da57090b2af_17093dce158f11fb)
  unreachable
bb28:
  %t121 = load i64, ptr %l70, !tbaa !24
  store i64 %t121, ptr %l53, !tbaa !24
  br label %bb31
bb29:
  br label %bb30
bb30:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l53, !tbaa !24
  br label %bb31
bb31:
  %t122 = load i64, ptr %l53, !tbaa !24
  store i64 %t122, ptr %l12, !tbaa !24
  %t123 = load i64, ptr %l12, !tbaa !24
  %t125 = icmp sge i64 %t123, 0
  br i1 %t125, label %bb32, label %bb33
bb32:
  %t127 = load ptr, ptr %l3, !tbaa !29
  %t128 = load i64, ptr %l12, !tbaa !24
  %t131 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v2, ptr %t127, i64 %t128)
  store i1 %t131, ptr %l77
  br label %bb34
bb33:
  store i1 false, ptr %l74, !tbaa !21
  br label %bb35
bb34:
  %t132 = load i1, ptr %l77, !tbaa !21
  %t133 = xor i1 %t132, true
  store i1 %t133, ptr %l74, !tbaa !21
  br label %bb35
bb35:
  %t135 = load i1, ptr %l74, !tbaa !21
  br i1 %t135, label %bb36, label %bb37
bb36:
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t137 = load i64, ptr %l12, !tbaa !24
  %t138 = load ptr, ptr %l2, !tbaa !29
  %t139 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2ewantType(ptr %v0, ptr %v1, ptr %v2, ptr %t136, i64 %t137, ptr %t138, ptr %t139)
  br label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb39
bb39:
  call void @__olang_scope_close(ptr %s2)
  br label %bb40
bb40:
  %t144 = load i64, ptr %l10, !tbaa !24
  %t146 = add i64 %t144, 1
  store i64 %t146, ptr %l10, !tbaa !24
  br label %bb12
bb41:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ewrapper(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca %"std/prelude/text:StringBuilder"
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i32
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l33 = alloca { i64, ptr }
  %l35 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i32
  %l40 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i32
  %l46 = alloca i1
  %l50 = alloca { i64, ptr }
  %l51 = alloca { i64, ptr }
  %l52 = alloca i64
  %l53 = alloca { i64, ptr }
  %l54 = alloca { i64, ptr }
  %l55 = alloca i64
  %l56 = alloca i64
  %l61 = alloca { i64, ptr }
  %l65 = alloca i64
  %l66 = alloca i64
  %l67 = alloca i64
  %l72 = alloca { i64, ptr }
  %l73 = alloca i64
  %l76 = alloca i64
  %l77 = alloca i64
  %l82 = alloca %"std/prelude/text:StringBuilder"
  %l83 = alloca ptr
  %l84 = alloca { i64, ptr }
  %l88 = alloca { i64, ptr }
  %l93 = alloca i1
  %l94 = alloca ptr
  %l98 = alloca { i64, ptr }
  %l102 = alloca ptr
  %l103 = alloca { i64, ptr }
  %l107 = alloca { i64, ptr }
  %l113 = alloca { i64, ptr }
  %l114 = alloca { i64, ptr }
  %l115 = alloca i64
  %l116 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 16
  %t4 = load i64, ptr %l2, !tbaa !24
  %t7 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  store { i64, ptr } %t7, ptr %l16
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t8, ptr %l3, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t11 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %s0, { i64, ptr } %t9, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d362, i32 0, i32 1) })
  %t12 = extractvalue { i32, i64 } %t11, 1
  %t13 = extractvalue { i32, i64 } %t11, 0
  store i32 %t13, ptr %l20
  %t14 = icmp ne i32 %t13, 0
  br i1 %t14, label %bb3, label %ok.15
ok.15:
  store i64 %t12, ptr %l19
  br label %bb2
bb2:
  %t16 = load i64, ptr %l19, !tbaa !24
  store i64 %t16, ptr %l17, !tbaa !24
  br label %bb5
bb3:
  br label %bb4
bb4:
  call void @__olang_ert_req_clear()
  %t17 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t17, 0
  store i64 %t19, ptr %l17, !tbaa !24
  br label %bb5
bb5:
  %t21 = load i64, ptr %l17, !tbaa !24
  %t22 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t22, ptr %l23, !tbaa !27
  store i64 %t21, ptr %l24, !tbaa !24
  %t24 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t24, 0
  store i64 %t25, ptr %l25, !tbaa !24
  %t26 = icmp sge i64 0, 0
  br i1 %t26, label %bb6, label %bb7
bb6:
  %t28 = load i64, ptr %l24, !tbaa !24
  %t29 = icmp sle i64 0, %t28
  br i1 %t29, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_f5feee0c0f7dd320_8e2d9d91f1e1268c)
  unreachable
bb8:
  %t31 = load i64, ptr %l24, !tbaa !24
  %t32 = load i64, ptr %l25, !tbaa !24
  %t33 = icmp sle i64 %t31, %t32
  br i1 %t33, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_f5feee0c0f7dd320_8e2d9d91f1e1268c)
  unreachable
bb10:
  %t35 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !27
  %t37 = load i64, ptr %l24, !tbaa !24
  %t38 = getelementptr i8, ptr %t36, i64 0
  %t39 = sub i64 %t37, 0
  %t40 = insertvalue { i64, ptr } undef, i64 %t39, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t38, 1
  store { i64, ptr } %t41, ptr %l5, !tbaa !27
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/emit:Emitter", ptr %t43, i32 0, i32 15
  %t46 = load i64, ptr %l2, !tbaa !24
  %t49 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %s0, ptr %t45, i64 %t46)
  store { i64, ptr } %t49, ptr %l33
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_f5feee0c0f7dd320_8e2d9d91f1e1268c)
  unreachable
bb12:
  %t50 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d363, i32 0, i32 1) }, 1
  %t51 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d363, i32 0, i32 1) }, 0
  %t52 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t53 = extractvalue { i64, ptr } %t52, 1
  %t54 = extractvalue { i64, ptr } %t52, 0
  %t55 = add i64 %t51, %t54
  %t56 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d364, i32 0, i32 1) }, 1
  %t57 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d364, i32 0, i32 1) }, 0
  %t58 = add i64 %t55, %t57
  %t59 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t58)
  call void @olang_textcopy(ptr %t59, ptr %t50, i64 %t51)
  %t60 = getelementptr i8, ptr %t59, i64 %t51
  call void @olang_textcopy(ptr %t60, ptr %t53, i64 %t54)
  %t61 = getelementptr i8, ptr %t60, i64 %t54
  call void @olang_textcopy(ptr %t61, ptr %t56, i64 %t57)
  %t62 = insertvalue { i64, ptr } undef, i64 %t58, 0
  %t63 = insertvalue { i64, ptr } %t62, ptr %t59, 1
  store { i64, ptr } %t63, ptr %l6, !tbaa !27
  %t65 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t66 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t69 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %s0, { i64, ptr } %t65, { i64, ptr } %t66)
  %t70 = extractvalue { i32, i64 } %t69, 1
  %t71 = extractvalue { i32, i64 } %t69, 0
  store i32 %t71, ptr %l39
  %t72 = icmp ne i32 %t71, 0
  br i1 %t72, label %bb14, label %ok.73
ok.73:
  store i64 %t70, ptr %l38
  br label %bb13
bb13:
  %t74 = load i64, ptr %l38, !tbaa !24
  store i64 %t74, ptr %l35, !tbaa !24
  br label %bb16
bb14:
  br label %bb15
bb15:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l35, !tbaa !24
  br label %bb16
bb16:
  %t75 = load i64, ptr %l35, !tbaa !24
  store i64 %t75, ptr %l7, !tbaa !24
  %t76 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t78 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %v0, ptr %s0, { i64, ptr } %t76, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d365, i32 0, i32 1) })
  %t79 = extractvalue { i32, i64 } %t78, 1
  %t80 = extractvalue { i32, i64 } %t78, 0
  store i32 %t80, ptr %l43
  %t81 = icmp ne i32 %t80, 0
  br i1 %t81, label %bb18, label %ok.82
ok.82:
  store i64 %t79, ptr %l42
  br label %bb17
bb17:
  %t83 = load i64, ptr %l42, !tbaa !24
  store i64 %t83, ptr %l40, !tbaa !24
  br label %bb20
bb18:
  br label %bb19
bb19:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l40, !tbaa !24
  br label %bb20
bb20:
  %t84 = load i64, ptr %l40, !tbaa !24
  store i64 %t84, ptr %l8, !tbaa !24
  %t85 = load i64, ptr %l7, !tbaa !24
  %t87 = icmp slt i64 %t85, 0
  br i1 %t87, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l46, !tbaa !21
  br label %bb23
bb22:
  %t89 = load i64, ptr %l8, !tbaa !24
  %t90 = load i64, ptr %l7, !tbaa !24
  %t93 = icmp slt i64 %t89, %t90
  store i1 %t93, ptr %l46, !tbaa !21
  br label %bb23
bb23:
  %t95 = load i1, ptr %l46, !tbaa !21
  br i1 %t95, label %bb24, label %bb25
bb24:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d366, i32 0, i32 1) }, ptr %l50, !tbaa !27
  %t96 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t96, ptr %l51, !tbaa !27
  %t97 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t98 = extractvalue { i64, ptr } %t97, 0
  store i64 %t98, ptr %l52, !tbaa !24
  %t99 = load i64, ptr %l52, !tbaa !24
  %t100 = mul i64 %t99, 1
  %t101 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t100)
  %t102 = insertvalue { i64, ptr } undef, i64 %t99, 0
  %t103 = insertvalue { i64, ptr } %t102, ptr %t101, 1
  store { i64, ptr } %t103, ptr %l53, !tbaa !27
  %t104 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !27
  %t106 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !27
  %t108 = load i64, ptr %l52, !tbaa !24
  %t109 = mul i64 %t108, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t105, ptr %t107, i64 %t109, i1 false)
  %t110 = load { i64, ptr }, ptr %l53, !tbaa !27
  store { i64, ptr } %t110, ptr %l51, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t111 = load { i64, ptr }, ptr %l51, !tbaa !27
  store { i64, ptr } %t111, ptr %rv
  br label %ret
bb25:
  br label %bb26
bb26:
  %t112 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t112, ptr %l54, !tbaa !27
  %t113 = load i64, ptr %l7, !tbaa !24
  store i64 %t113, ptr %l55, !tbaa !24
  %t114 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t115 = extractvalue { i64, ptr } %t114, 0
  store i64 %t115, ptr %l56, !tbaa !24
  %t116 = icmp sge i64 0, 0
  br i1 %t116, label %bb27, label %bb28
bb27:
  %t118 = load i64, ptr %l55, !tbaa !24
  %t119 = icmp sle i64 0, %t118
  br i1 %t119, label %bb29, label %bb30
bb28:
  call void @__olang_check_failed(ptr @olang_loc_fb18e47b3c77ad7d_7c94e7cf0a0fcab9)
  unreachable
bb29:
  %t121 = load i64, ptr %l55, !tbaa !24
  %t122 = load i64, ptr %l56, !tbaa !24
  %t123 = icmp sle i64 %t121, %t122
  br i1 %t123, label %bb31, label %bb32
bb30:
  call void @__olang_check_failed(ptr @olang_loc_fb18e47b3c77ad7d_7c94e7cf0a0fcab9)
  unreachable
bb31:
  %t125 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t126 = load ptr, ptr %t125, !tbaa !27
  %t127 = load i64, ptr %l55, !tbaa !24
  %t128 = getelementptr i8, ptr %t126, i64 0
  %t129 = sub i64 %t127, 0
  %t130 = insertvalue { i64, ptr } undef, i64 %t129, 0
  %t131 = insertvalue { i64, ptr } %t130, ptr %t128, 1
  store { i64, ptr } %t131, ptr %l9, !tbaa !27
  %t133 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t133, ptr %l61, !tbaa !27
  %t134 = load i64, ptr %l7, !tbaa !24
  %t135 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t137 = extractvalue { i64, ptr } %t135, 0
  %t140 = add i64 %t134, %t137
  store i64 %t140, ptr %l65, !tbaa !24
  %t141 = load i64, ptr %l8, !tbaa !24
  store i64 %t141, ptr %l66, !tbaa !24
  %t142 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t143 = extractvalue { i64, ptr } %t142, 0
  store i64 %t143, ptr %l67, !tbaa !24
  %t144 = load i64, ptr %l65, !tbaa !24
  %t145 = icmp sge i64 %t144, 0
  br i1 %t145, label %bb33, label %bb34
bb32:
  call void @__olang_check_failed(ptr @olang_loc_fb18e47b3c77ad7d_7c94e7cf0a0fcab9)
  unreachable
bb33:
  %t147 = load i64, ptr %l65, !tbaa !24
  %t148 = load i64, ptr %l66, !tbaa !24
  %t149 = icmp sle i64 %t147, %t148
  br i1 %t149, label %bb35, label %bb36
bb34:
  call void @__olang_check_failed(ptr @olang_loc_7f6652826e00de1e_418f3021b2f06a1a)
  unreachable
bb35:
  %t151 = load i64, ptr %l66, !tbaa !24
  %t152 = load i64, ptr %l67, !tbaa !24
  %t153 = icmp sle i64 %t151, %t152
  br i1 %t153, label %bb37, label %bb38
bb36:
  call void @__olang_check_failed(ptr @olang_loc_7f6652826e00de1e_418f3021b2f06a1a)
  unreachable
bb37:
  %t155 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t156 = load ptr, ptr %t155, !tbaa !27
  %t157 = load i64, ptr %l65, !tbaa !24
  %t158 = load i64, ptr %l66, !tbaa !24
  %t159 = getelementptr i8, ptr %t156, i64 %t157
  %t160 = sub i64 %t158, %t157
  %t161 = insertvalue { i64, ptr } undef, i64 %t160, 0
  %t162 = insertvalue { i64, ptr } %t161, ptr %t159, 1
  store { i64, ptr } %t162, ptr %l10, !tbaa !27
  %t164 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t164, ptr %l72, !tbaa !27
  %t165 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d367, i32 0, i32 1) }, 0
  store i64 %t165, ptr %l73, !tbaa !24
  %t166 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t168 = extractvalue { i64, ptr } %t166, 0
  %t170 = sub i64 %t168, 1
  store i64 %t170, ptr %l76, !tbaa !24
  %t171 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t172 = extractvalue { i64, ptr } %t171, 0
  store i64 %t172, ptr %l77, !tbaa !24
  %t173 = load i64, ptr %l73, !tbaa !24
  %t174 = icmp sge i64 %t173, 0
  br i1 %t174, label %bb39, label %bb40
bb38:
  call void @__olang_check_failed(ptr @olang_loc_7f6652826e00de1e_418f3021b2f06a1a)
  unreachable
bb39:
  %t176 = load i64, ptr %l73, !tbaa !24
  %t177 = load i64, ptr %l76, !tbaa !24
  %t178 = icmp sle i64 %t176, %t177
  br i1 %t178, label %bb41, label %bb42
bb40:
  call void @__olang_check_failed(ptr @olang_loc_679011f6b0c6ee1b_3818b84a191b3b77)
  unreachable
bb41:
  %t180 = load i64, ptr %l76, !tbaa !24
  %t181 = load i64, ptr %l77, !tbaa !24
  %t182 = icmp sle i64 %t180, %t181
  br i1 %t182, label %bb43, label %bb44
bb42:
  call void @__olang_check_failed(ptr @olang_loc_679011f6b0c6ee1b_3818b84a191b3b77)
  unreachable
bb43:
  %t184 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t185 = load ptr, ptr %t184, !tbaa !27
  %t186 = load i64, ptr %l73, !tbaa !24
  %t187 = load i64, ptr %l76, !tbaa !24
  %t188 = getelementptr i8, ptr %t185, i64 %t186
  %t189 = sub i64 %t187, %t186
  %t190 = insertvalue { i64, ptr } undef, i64 %t189, 0
  %t191 = insertvalue { i64, ptr } %t190, ptr %t188, 1
  store { i64, ptr } %t191, ptr %l11, !tbaa !27
  %t193 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t193, ptr %l82
  br label %bb45
bb44:
  call void @__olang_check_failed(ptr @olang_loc_679011f6b0c6ee1b_3818b84a191b3b77)
  unreachable
bb45:
  %t194 = load %"std/prelude/text:StringBuilder", ptr %l82
  store %"std/prelude/text:StringBuilder" %t194, ptr %l12
  store ptr %l12, ptr %l83, !tbaa !29
  %t195 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t195, ptr %l84, !tbaa !27
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t198 = getelementptr %"compiler/emit:Emitter", ptr %t196, i32 0, i32 15
  %t202 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %s0, ptr %t198, i64 %a1)
  store { i64, ptr } %t202, ptr %l88
  br label %bb46
bb46:
  %t203 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t204 = load { i64, ptr }, ptr %l84, !tbaa !27
  %t205 = extractvalue { i64, ptr } %t204, 1
  %t206 = extractvalue { i64, ptr } %t204, 0
  %t207 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d368, i32 0, i32 1) }, 1
  %t208 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d368, i32 0, i32 1) }, 0
  %t209 = add i64 %t206, %t208
  %t210 = load { i64, ptr }, ptr %l88, !tbaa !27
  %t211 = extractvalue { i64, ptr } %t210, 1
  %t212 = extractvalue { i64, ptr } %t210, 0
  %t213 = add i64 %t209, %t212
  %t214 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d369, i32 0, i32 1) }, 1
  %t215 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d369, i32 0, i32 1) }, 0
  %t216 = add i64 %t213, %t215
  %t218 = extractvalue { i64, ptr } %t203, 1
  %t219 = extractvalue { i64, ptr } %t203, 0
  %t220 = add i64 %t216, %t219
  %t221 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d370, i32 0, i32 1) }, 1
  %t222 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d370, i32 0, i32 1) }, 0
  %t223 = add i64 %t220, %t222
  %t224 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t223)
  call void @olang_textcopy(ptr %t224, ptr %t205, i64 %t206)
  %t225 = getelementptr i8, ptr %t224, i64 %t206
  call void @olang_textcopy(ptr %t225, ptr %t207, i64 %t208)
  %t226 = getelementptr i8, ptr %t225, i64 %t208
  call void @olang_textcopy(ptr %t226, ptr %t211, i64 %t212)
  %t227 = getelementptr i8, ptr %t226, i64 %t212
  call void @olang_textcopy(ptr %t227, ptr %t214, i64 %t215)
  %t228 = getelementptr i8, ptr %t227, i64 %t215
  call void @olang_textcopy(ptr %t228, ptr %t218, i64 %t219)
  %t229 = getelementptr i8, ptr %t228, i64 %t219
  call void @olang_textcopy(ptr %t229, ptr %t221, i64 %t222)
  %t230 = insertvalue { i64, ptr } undef, i64 %t223, 0
  %t231 = insertvalue { i64, ptr } %t230, ptr %t224, 1
  %t233 = extractvalue { i64, ptr } %t231, 0
  %t234 = extractvalue { i64, ptr } %t231, 1
  %t235 = mul i64 %t233, 1
  %t236 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t235)
  call void @llvm.memcpy.p0.p0.i64(ptr %t236, ptr %t234, i64 %t235, i1 false)
  %t237 = insertvalue { i64, ptr } undef, i64 %t233, 0
  %t238 = insertvalue { i64, ptr } %t237, ptr %t236, 1
  %t239 = load ptr, ptr %l83, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t239, { i64, ptr } %t238)
  br label %bb47
bb47:
  %t241 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t243 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t241, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d371, i32 0, i32 1) })
  store i1 %t243, ptr %l93
  br label %bb48
bb48:
  %t244 = load i1, ptr %l93, !tbaa !21
  br i1 %t244, label %bb49, label %bb50
bb49:
  store %olang.scope zeroinitializer, ptr %s4
  store ptr %l12, ptr %l94, !tbaa !29
  %t245 = load ptr, ptr %l0, !tbaa !29
  %t247 = getelementptr %"compiler/emit:Emitter", ptr %t245, i32 0, i32 15
  %t248 = load i64, ptr %l2, !tbaa !24
  %t251 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %s4, ptr %t247, i64 %t248)
  store { i64, ptr } %t251, ptr %l98
  br label %bb51
bb50:
  store %olang.scope zeroinitializer, ptr %s6
  store ptr %l12, ptr %l102, !tbaa !29
  %t252 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t252, ptr %l103, !tbaa !27
  %t253 = load ptr, ptr %l0, !tbaa !29
  %t255 = getelementptr %"compiler/emit:Emitter", ptr %t253, i32 0, i32 15
  %t256 = load i64, ptr %l2, !tbaa !24
  %t259 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %s6, ptr %t255, i64 %t256)
  store { i64, ptr } %t259, ptr %l107
  br label %bb53
bb51:
  %t260 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t261 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d372, i32 0, i32 1) }, 1
  %t262 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d372, i32 0, i32 1) }, 0
  %t263 = load { i64, ptr }, ptr %l98, !tbaa !27
  %t264 = extractvalue { i64, ptr } %t263, 1
  %t265 = extractvalue { i64, ptr } %t263, 0
  %t266 = add i64 %t262, %t265
  %t267 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d373, i32 0, i32 1) }, 1
  %t268 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d373, i32 0, i32 1) }, 0
  %t269 = add i64 %t266, %t268
  %t271 = extractvalue { i64, ptr } %t260, 1
  %t272 = extractvalue { i64, ptr } %t260, 0
  %t273 = add i64 %t269, %t272
  %t274 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d374, i32 0, i32 1) }, 1
  %t275 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d374, i32 0, i32 1) }, 0
  %t276 = add i64 %t273, %t275
  %t277 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t276)
  call void @olang_textcopy(ptr %t277, ptr %t261, i64 %t262)
  %t278 = getelementptr i8, ptr %t277, i64 %t262
  call void @olang_textcopy(ptr %t278, ptr %t264, i64 %t265)
  %t279 = getelementptr i8, ptr %t278, i64 %t265
  call void @olang_textcopy(ptr %t279, ptr %t267, i64 %t268)
  %t280 = getelementptr i8, ptr %t279, i64 %t268
  call void @olang_textcopy(ptr %t280, ptr %t271, i64 %t272)
  %t281 = getelementptr i8, ptr %t280, i64 %t272
  call void @olang_textcopy(ptr %t281, ptr %t274, i64 %t275)
  %t282 = insertvalue { i64, ptr } undef, i64 %t276, 0
  %t283 = insertvalue { i64, ptr } %t282, ptr %t277, 1
  %t285 = extractvalue { i64, ptr } %t283, 0
  %t286 = extractvalue { i64, ptr } %t283, 1
  %t287 = mul i64 %t285, 1
  %t288 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t287)
  call void @llvm.memcpy.p0.p0.i64(ptr %t288, ptr %t286, i64 %t287, i1 false)
  %t289 = insertvalue { i64, ptr } undef, i64 %t285, 0
  %t290 = insertvalue { i64, ptr } %t289, ptr %t288, 1
  %t291 = load ptr, ptr %l94, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s4, ptr %t291, { i64, ptr } %t290)
  br label %bb52
bb52:
  call void @__olang_scope_close(ptr %s4)
  br label %bb55
bb53:
  %t293 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t294 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t295 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d375, i32 0, i32 1) }, 1
  %t296 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d375, i32 0, i32 1) }, 0
  %t297 = load { i64, ptr }, ptr %l103, !tbaa !27
  %t298 = extractvalue { i64, ptr } %t297, 1
  %t299 = extractvalue { i64, ptr } %t297, 0
  %t300 = add i64 %t296, %t299
  %t301 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d376, i32 0, i32 1) }, 1
  %t302 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d376, i32 0, i32 1) }, 0
  %t303 = add i64 %t300, %t302
  %t304 = load { i64, ptr }, ptr %l107, !tbaa !27
  %t305 = extractvalue { i64, ptr } %t304, 1
  %t306 = extractvalue { i64, ptr } %t304, 0
  %t307 = add i64 %t303, %t306
  %t308 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d377, i32 0, i32 1) }, 1
  %t309 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d377, i32 0, i32 1) }, 0
  %t310 = add i64 %t307, %t309
  %t312 = extractvalue { i64, ptr } %t293, 1
  %t313 = extractvalue { i64, ptr } %t293, 0
  %t314 = add i64 %t310, %t313
  %t315 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d378, i32 0, i32 1) }, 1
  %t316 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d378, i32 0, i32 1) }, 0
  %t317 = add i64 %t314, %t316
  %t319 = extractvalue { i64, ptr } %t294, 1
  %t320 = extractvalue { i64, ptr } %t294, 0
  %t321 = add i64 %t317, %t320
  %t322 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d379, i32 0, i32 1) }, 1
  %t323 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d379, i32 0, i32 1) }, 0
  %t324 = add i64 %t321, %t323
  %t325 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t324)
  call void @olang_textcopy(ptr %t325, ptr %t295, i64 %t296)
  %t326 = getelementptr i8, ptr %t325, i64 %t296
  call void @olang_textcopy(ptr %t326, ptr %t298, i64 %t299)
  %t327 = getelementptr i8, ptr %t326, i64 %t299
  call void @olang_textcopy(ptr %t327, ptr %t301, i64 %t302)
  %t328 = getelementptr i8, ptr %t327, i64 %t302
  call void @olang_textcopy(ptr %t328, ptr %t305, i64 %t306)
  %t329 = getelementptr i8, ptr %t328, i64 %t306
  call void @olang_textcopy(ptr %t329, ptr %t308, i64 %t309)
  %t330 = getelementptr i8, ptr %t329, i64 %t309
  call void @olang_textcopy(ptr %t330, ptr %t312, i64 %t313)
  %t331 = getelementptr i8, ptr %t330, i64 %t313
  call void @olang_textcopy(ptr %t331, ptr %t315, i64 %t316)
  %t332 = getelementptr i8, ptr %t331, i64 %t316
  call void @olang_textcopy(ptr %t332, ptr %t319, i64 %t320)
  %t333 = getelementptr i8, ptr %t332, i64 %t320
  call void @olang_textcopy(ptr %t333, ptr %t322, i64 %t323)
  %t334 = insertvalue { i64, ptr } undef, i64 %t324, 0
  %t335 = insertvalue { i64, ptr } %t334, ptr %t325, 1
  %t337 = extractvalue { i64, ptr } %t335, 0
  %t338 = extractvalue { i64, ptr } %t335, 1
  %t339 = mul i64 %t337, 1
  %t340 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t339)
  call void @llvm.memcpy.p0.p0.i64(ptr %t340, ptr %t338, i64 %t339, i1 false)
  %t341 = insertvalue { i64, ptr } undef, i64 %t337, 0
  %t342 = insertvalue { i64, ptr } %t341, ptr %t340, 1
  %t343 = load ptr, ptr %l102, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s6, ptr %t343, { i64, ptr } %t342)
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s6)
  br label %bb55
bb55:
  %t346 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l12)
  store { i64, ptr } %t346, ptr %l113
  br label %bb56
bb56:
  %t347 = load { i64, ptr }, ptr %l113, !tbaa !27
  store { i64, ptr } %t347, ptr %l114, !tbaa !27
  %t348 = load { i64, ptr }, ptr %l114, !tbaa !27
  %t349 = extractvalue { i64, ptr } %t348, 0
  store i64 %t349, ptr %l115, !tbaa !24
  %t350 = load i64, ptr %l115, !tbaa !24
  %t351 = mul i64 %t350, 1
  %t352 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t351)
  %t353 = insertvalue { i64, ptr } undef, i64 %t350, 0
  %t354 = insertvalue { i64, ptr } %t353, ptr %t352, 1
  store { i64, ptr } %t354, ptr %l116, !tbaa !27
  %t355 = getelementptr { i64, ptr }, ptr %l116, i32 0, i32 1
  %t356 = load ptr, ptr %t355, !tbaa !27
  %t357 = getelementptr { i64, ptr }, ptr %l114, i32 0, i32 1
  %t358 = load ptr, ptr %t357, !tbaa !27
  %t359 = load i64, ptr %l115, !tbaa !24
  %t360 = mul i64 %t359, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t356, ptr %t358, i64 %t360, i1 false)
  %t361 = load { i64, ptr }, ptr %l116, !tbaa !27
  store { i64, ptr } %t361, ptr %l114, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t362 = load { i64, ptr }, ptr %l114, !tbaa !27
  store { i64, ptr } %t362, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { { i64, ptr }, i32 } @compiler_2femit_2ecompiler_2femit_3afnEm_2eaddr(ptr %v0, ptr %v1, ptr %a0, %"compiler/mir:Place" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/mir:Place"
  %l2 = alloca ptr
  %lp3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i1
  %l6 = alloca i1
  %l7 = alloca { i64, [2 x i64] }
  %l8 = alloca i32
  %l9 = alloca i64
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca i32
  %l14 = alloca i32
  %l15 = alloca i32
  %l16 = alloca i32
  %l18 = alloca { i64, [1 x i64] }
  %l19 = alloca i32
  %l20 = alloca i64
  %l21 = alloca { i64, ptr }
  %l22 = alloca i32
  %l23 = alloca i32
  %l24 = alloca { i64, ptr }
  %l25 = alloca { { i64, ptr }, i32 }
  %l26 = alloca i64
  %l27 = alloca { { i64, ptr }, i32 }
  %l28 = alloca i32
  %l29 = alloca { i64, ptr }
  %l30 = alloca { i64, ptr }
  %l31 = alloca i64
  %l35 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l37 = alloca i64
  %l38 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l48 = alloca i64
  %l52 = alloca i32
  %l63 = alloca { i64, ptr }
  %l65 = alloca i64
  %l75 = alloca i32
  %l78 = alloca i32
  %l104 = alloca { i64, [1 x i64] }
  %l107 = alloca i32
  %l111 = alloca ptr
  %l114 = alloca i32
  %l115 = alloca { i64, ptr }
  %l116 = alloca ptr
  %l119 = alloca { i64, ptr }
  %l124 = alloca { i64, ptr }
  %l126 = alloca i64
  %l128 = alloca { i64, ptr }
  %l136 = alloca i32
  %l137 = alloca ptr
  %l138 = alloca ptr
  %l141 = alloca { i64, ptr }
  %l142 = alloca { i64, ptr }
  %l145 = alloca { i64, ptr }
  %l146 = alloca { i64, ptr }
  %l150 = alloca { i64, ptr }
  %l152 = alloca { i64, ptr }
  %l155 = alloca { i64, ptr }
  %l158 = alloca i1
  %l159 = alloca ptr
  %l160 = alloca { i64, ptr }
  %l161 = alloca i32
  %l162 = alloca { i64, ptr }
  %l167 = alloca { i64, ptr }
  %l169 = alloca { { i64, ptr }, i32 }
  %l170 = alloca { i64, ptr }
  %l172 = alloca i64
  %l174 = alloca i64
  %l175 = alloca { i64, ptr }
  %l182 = alloca i1
  %l183 = alloca ptr
  %l184 = alloca { i64, ptr }
  %l185 = alloca i32
  %l188 = alloca { i64, ptr }
  %l193 = alloca { i64, ptr }
  %l195 = alloca { { i64, ptr }, i32 }
  %l196 = alloca { i64, ptr }
  %l198 = alloca i64
  %l200 = alloca i64
  %l201 = alloca { i64, ptr }
  %l207 = alloca i32
  %l209 = alloca { i64, ptr }
  %l214 = alloca { i64, ptr }
  %l219 = alloca i1
  %l224 = alloca { i64, ptr }
  %l226 = alloca i64
  %l230 = alloca ptr
  %l233 = alloca { i64, ptr }
  %l237 = alloca { i64, ptr }
  %l239 = alloca i64
  %l242 = alloca ptr
  %l245 = alloca i32
  %l246 = alloca { i64, ptr }
  %l250 = alloca { i64, ptr }
  %l255 = alloca ptr
  %l257 = alloca { i64, ptr }
  %l262 = alloca { i64, ptr }
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %rv = alloca { { i64, ptr }, i32 }
  store ptr %a0, ptr %l0
  store %"compiler/mir:Place" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/emit:Emitter", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l2, !tbaa !29
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d380, i32 0, i32 1) }, ptr %l35, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t9, ptr %l36, !tbaa !27
  %t10 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t10, 0
  store i64 %t11, ptr %l37, !tbaa !24
  %t12 = load i64, ptr %l37, !tbaa !24
  %t13 = mul i64 %t12, 1
  %t14 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t13)
  %t15 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr %t14, 1
  store { i64, ptr } %t16, ptr %l38, !tbaa !27
  %t17 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !27
  %t19 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !27
  %t21 = load i64, ptr %l37, !tbaa !24
  %t22 = mul i64 %t21, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t18, ptr %t20, i64 %t22, i1 false)
  %t23 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t23, ptr %lp3
  %t24 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t25 = load ptr, ptr %lp3
  store { i64, ptr } %t24, ptr %t25, !tbaa !27
  %t26 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t26, ptr %l4, !tbaa !23
  store i1 false, ptr %l5, !tbaa !21
  store i1 false, ptr %l6, !tbaa !21
  %t28 = getelementptr %"compiler/mir:Place", ptr %l1, i32 0, i32 0
  %t29 = load { i64, [2 x i64] }, ptr %t28
  store { i64, [2 x i64] } %t29, ptr %l7
  %t31 = load { i64, [2 x i64] }, ptr %l7
  %t33 = extractvalue { i64, [2 x i64] } %t31, 0
  %t34 = icmp eq i64 %t33, 1
  br i1 %t34, label %bb1, label %bb2
bb1:
  %t36 = getelementptr { i64, [2 x i64] }, ptr %l7, i32 0, i32 1
  %t37 = getelementptr { i32 }, ptr %t36, i32 0, i32 0
  %t38 = load i32, ptr %t37
  store i32 %t38, ptr %l8, !tbaa !23
  br label %bb3
bb2:
  br label %bb9
bb3:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load i32, ptr %l8, !tbaa !23
  %t44 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elocalAt(ptr %v0, ptr %v1, ptr %t40, i32 %t41)
  store { i64, ptr } %t44, ptr %l46
  br label %bb4
bb4:
  %t45 = load ptr, ptr %lp3
  %t46 = load { i64, ptr }, ptr %t45, !tbaa !27
  %t47 = extractvalue { i64, ptr } %t46, 0
  %t48 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t48, 0
  store i64 %t49, ptr %l48, !tbaa !24
  %t51 = load i64, ptr %l48, !tbaa !24
  %t52 = icmp eq i64 %t47, %t51
  br i1 %t52, label %bb5, label %bb6
bb5:
  %t54 = load ptr, ptr %lp3
  %t55 = getelementptr { i64, ptr }, ptr %t54, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !27
  %t57 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !27
  %t59 = load i64, ptr %l48, !tbaa !24
  %t60 = mul i64 %t59, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t56, ptr %t58, i64 %t60, i1 false)
  br label %bb7
bb6:
  %t61 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t62 = load ptr, ptr %lp3
  store { i64, ptr } %t61, ptr %t62, !tbaa !27
  br label %bb7
bb7:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = load i32, ptr %l8, !tbaa !23
  %t67 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2elocalType(ptr %v0, ptr %t63, i32 %t64)
  store i32 %t67, ptr %l52
  br label %bb8
bb8:
  %t68 = load i32, ptr %l52, !tbaa !23
  store i32 %t68, ptr %l4, !tbaa !23
  br label %bb23
bb9:
  %t69 = load { i64, [2 x i64] }, ptr %l7
  %t71 = extractvalue { i64, [2 x i64] } %t69, 0
  %t72 = icmp eq i64 %t71, 2
  br i1 %t72, label %bb10, label %bb11
bb10:
  %t74 = getelementptr { i64, [2 x i64] }, ptr %l7, i32 0, i32 1
  %t75 = getelementptr { i64, i32, i32 }, ptr %t74, i32 0, i32 0
  %t76 = load i64, ptr %t75
  store i64 %t76, ptr %l9, !tbaa !24
  %t78 = getelementptr { i64, [2 x i64] }, ptr %l7, i32 0, i32 1
  %t79 = getelementptr { i64, i32, i32 }, ptr %t78, i32 0, i32 1
  %t80 = load i32, ptr %t79
  store i32 %t80, ptr %l10, !tbaa !23
  %t82 = getelementptr { i64, [2 x i64] }, ptr %l7, i32 0, i32 1
  %t83 = getelementptr { i64, i32, i32 }, ptr %t82, i32 0, i32 2
  %t84 = load i32, ptr %t83
  store i32 %t84, ptr %l11, !tbaa !23
  br label %bb12
bb11:
  br label %bb17
bb12:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/emit:fnEm", ptr %t86, i32 0, i32 0
  %t89 = load ptr, ptr %t88, !tbaa !29
  %t90 = load i64, ptr %l9, !tbaa !24
  %t91 = load i32, ptr %l10, !tbaa !23
  %t92 = load i32, ptr %l11, !tbaa !23
  %t97 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eglobal(ptr %v0, ptr %v1, ptr %t89, i64 %t90, i32 %t91, i32 %t92)
  store { i64, ptr } %t97, ptr %l63
  br label %bb13
bb13:
  %t98 = load ptr, ptr %lp3
  %t99 = load { i64, ptr }, ptr %t98, !tbaa !27
  %t100 = extractvalue { i64, ptr } %t99, 0
  %t101 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t102 = extractvalue { i64, ptr } %t101, 0
  store i64 %t102, ptr %l65, !tbaa !24
  %t104 = load i64, ptr %l65, !tbaa !24
  %t105 = icmp eq i64 %t100, %t104
  br i1 %t105, label %bb14, label %bb15
bb14:
  %t107 = load ptr, ptr %lp3
  %t108 = getelementptr { i64, ptr }, ptr %t107, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !27
  %t110 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !27
  %t112 = load i64, ptr %l65, !tbaa !24
  %t113 = mul i64 %t112, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t109, ptr %t111, i64 %t113, i1 false)
  br label %bb16
bb15:
  %t114 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t115 = load ptr, ptr %lp3
  store { i64, ptr } %t114, ptr %t115, !tbaa !27
  br label %bb16
bb16:
  %t116 = load i32, ptr %l11, !tbaa !23
  store i32 %t116, ptr %l4, !tbaa !23
  br label %bb23
bb17:
  %t118 = load { i64, [2 x i64] }, ptr %l7
  %t120 = extractvalue { i64, [2 x i64] } %t118, 0
  %t121 = icmp eq i64 %t120, 0
  br i1 %t121, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb22
bb20:
  store %olang.scope zeroinitializer, ptr %s3
  %t123 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2egap(ptr %v0, ptr %s3, ptr %t123, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d381, i32 0, i32 1) })
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s3)
  br label %bb23
bb22:
  call void @__olang_check_failed(ptr @olang_loc_a45e6d34f8d75be7_fb9ba052a05cfc3b)
  unreachable
bb23:
  store i32 0, ptr %l12, !tbaa !23
  %t125 = getelementptr %"compiler/mir:Place", ptr %l1, i32 0, i32 1
  %t126 = getelementptr %"compiler/mir:Range", ptr %t125, i32 0, i32 1
  %t127 = load i32, ptr %t126, !tbaa !23
  store i32 %t127, ptr %l13, !tbaa !23
  store i32 1, ptr %l14, !tbaa !23
  %t129 = load i32, ptr %l13, !tbaa !23
  %t130 = load i32, ptr %l12, !tbaa !23
  %t133 = icmp sgt i32 %t129, %t130
  br i1 %t133, label %bb24, label %bb25
bb24:
  %t135 = load i32, ptr %l14, !tbaa !23
  %t137 = icmp sgt i32 %t135, 0
  br i1 %t137, label %bb26, label %bb27
bb25:
  store i32 0, ptr %l75, !tbaa !23
  br label %bb29
bb26:
  %t139 = load i32, ptr %l13, !tbaa !23
  %t140 = load i32, ptr %l12, !tbaa !23
  %t143 = sub i32 %t139, %t140
  %t144 = load i32, ptr %l14, !tbaa !23
  %t147 = add i32 %t143, %t144
  %t149 = sub i32 %t147, 1
  %t150 = load i32, ptr %l14, !tbaa !23
  %t153 = sdiv i32 %t149, %t150
  store i32 %t153, ptr %l78, !tbaa !23
  br label %bb28
bb27:
  store i32 0, ptr %l78, !tbaa !23
  br label %bb28
bb28:
  %t155 = load i32, ptr %l78, !tbaa !23
  store i32 %t155, ptr %l75, !tbaa !23
  br label %bb29
bb29:
  %t156 = load i32, ptr %l75, !tbaa !23
  store i32 %t156, ptr %l15, !tbaa !23
  store i32 0, ptr %l16, !tbaa !23
  br label %bb30
bb30:
  store %olang.scope zeroinitializer, ptr %s5
  %t157 = load i32, ptr %l16, !tbaa !23
  %t158 = load i32, ptr %l15, !tbaa !23
  %t161 = icmp slt i32 %t157, %t158
  %t163 = xor i1 %t161, true
  br i1 %t163, label %bb31, label %bb32
bb31:
  call void @__olang_scope_close(ptr %s5)
  br label %bb118
bb32:
  br label %bb33
bb33:
  %t165 = load i32, ptr %l12, !tbaa !23
  %t166 = load i32, ptr %l16, !tbaa !23
  %t167 = load i32, ptr %l14, !tbaa !23
  %t170 = mul i32 %t166, %t167
  %t173 = add i32 %t165, %t170
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t177 = getelementptr %"compiler/emit:fnEm", ptr %t175, i32 0, i32 1
  %t178 = load ptr, ptr %t177, !tbaa !29
  %t180 = getelementptr %"compiler/mir:Fn", ptr %t178, i32 0, i32 10
  %t181 = getelementptr %"compiler/mir:Place", ptr %l1, i32 0, i32 1
  %t182 = getelementptr %"compiler/mir:Range", ptr %t181, i32 0, i32 0
  %t183 = load i32, ptr %t182, !tbaa !23
  %t185 = sext i32 %t183 to i64
  %t188 = sext i32 %t173 to i64
  %t191 = add i64 %t185, %t188
  %t194 = call { i64, [1 x i64] } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aProj_3e_2eAt_3ccompiler_2fmir_3aProj_3e(ptr %v0, ptr %t180, i64 %t191)
  store { i64, [1 x i64] } %t194, ptr %l104
  br label %bb34
bb34:
  %t195 = load { i64, [1 x i64] }, ptr %l104
  store { i64, [1 x i64] } %t195, ptr %l18
  %t196 = load ptr, ptr %l2, !tbaa !29
  %t197 = load i32, ptr %l4, !tbaa !23
  %t200 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t196, i32 %t197)
  store i32 %t200, ptr %l107
  br label %bb35
bb35:
  %t201 = load i32, ptr %l107, !tbaa !23
  store i32 %t201, ptr %l19, !tbaa !23
  %t202 = load { i64, [1 x i64] }, ptr %l18
  %t204 = extractvalue { i64, [1 x i64] } %t202, 0
  %t205 = icmp eq i64 %t204, 0
  br i1 %t205, label %bb36, label %bb37
bb36:
  %t207 = getelementptr { i64, [1 x i64] }, ptr %l18, i32 0, i32 1
  %t208 = getelementptr { i64 }, ptr %t207, i32 0, i32 0
  %t209 = load i64, ptr %t208
  store i64 %t209, ptr %l20, !tbaa !24
  br label %bb38
bb37:
  br label %bb46
bb38:
  store %olang.scope zeroinitializer, ptr %s6
  %t211 = load ptr, ptr %l2, !tbaa !29
  store ptr %t211, ptr %l111, !tbaa !29
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t213 = load i32, ptr %l19, !tbaa !23
  %t216 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2efieldList(ptr %v0, ptr %t212, i32 %t213)
  store i32 %t216, ptr %l114
  br label %bb39
bb39:
  %t217 = load ptr, ptr %l111, !tbaa !29
  %t218 = load i32, ptr %l114, !tbaa !23
  %t219 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t217, i32 %t218)
  store { i64, ptr } %t219, ptr %l115
  br label %bb40
bb40:
  %t220 = load { i64, ptr }, ptr %l115, !tbaa !27
  store { i64, ptr } %t220, ptr %l21, !tbaa !27
  %t221 = load ptr, ptr %l0, !tbaa !29
  store ptr %t221, ptr %l116, !tbaa !29
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t223 = load i32, ptr %l19, !tbaa !23
  %t226 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s6, ptr %t222, i32 %t223)
  store { i64, ptr } %t226, ptr %l119
  br label %bb41
bb41:
  %t227 = load ptr, ptr %lp3
  %t228 = load { i64, ptr }, ptr %t227, !tbaa !27
  %t229 = load i64, ptr %l20, !tbaa !24
  %t230 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d382, i32 0, i32 1) }, 1
  %t231 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d382, i32 0, i32 1) }, 0
  %t232 = load { i64, ptr }, ptr %l119, !tbaa !27
  %t233 = extractvalue { i64, ptr } %t232, 1
  %t234 = extractvalue { i64, ptr } %t232, 0
  %t235 = add i64 %t231, %t234
  %t236 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d383, i32 0, i32 1) }, 1
  %t237 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d383, i32 0, i32 1) }, 0
  %t238 = add i64 %t235, %t237
  %t240 = extractvalue { i64, ptr } %t228, 1
  %t241 = extractvalue { i64, ptr } %t228, 0
  %t242 = add i64 %t238, %t241
  %t243 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d384, i32 0, i32 1) }, 1
  %t244 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d384, i32 0, i32 1) }, 0
  %t245 = add i64 %t242, %t244
  %t247 = call i64 @__olang_fmt_i64(ptr null, i64 %t229)
  %t248 = add i64 %t245, %t247
  %t249 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t248)
  call void @olang_textcopy(ptr %t249, ptr %t230, i64 %t231)
  %t250 = getelementptr i8, ptr %t249, i64 %t231
  call void @olang_textcopy(ptr %t250, ptr %t233, i64 %t234)
  %t251 = getelementptr i8, ptr %t250, i64 %t234
  call void @olang_textcopy(ptr %t251, ptr %t236, i64 %t237)
  %t252 = getelementptr i8, ptr %t251, i64 %t237
  call void @olang_textcopy(ptr %t252, ptr %t240, i64 %t241)
  %t253 = getelementptr i8, ptr %t252, i64 %t241
  call void @olang_textcopy(ptr %t253, ptr %t243, i64 %t244)
  %t254 = getelementptr i8, ptr %t253, i64 %t244
  %t255 = call i64 @__olang_fmt_i64(ptr %t254, i64 %t229)
  %t256 = insertvalue { i64, ptr } undef, i64 %t248, 0
  %t257 = insertvalue { i64, ptr } %t256, ptr %t249, 1
  %t259 = extractvalue { i64, ptr } %t257, 0
  %t260 = extractvalue { i64, ptr } %t257, 1
  %t261 = mul i64 %t259, 1
  %t262 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t261)
  call void @llvm.memcpy.p0.p0.i64(ptr %t262, ptr %t260, i64 %t261, i1 false)
  %t263 = insertvalue { i64, ptr } undef, i64 %t259, 0
  %t264 = insertvalue { i64, ptr } %t263, ptr %t262, 1
  %t265 = load ptr, ptr %l116, !tbaa !29
  %t267 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v1, ptr %t265, { i64, ptr } %t264)
  store { i64, ptr } %t267, ptr %l124
  br label %bb42
bb42:
  %t268 = load ptr, ptr %lp3
  %t269 = load { i64, ptr }, ptr %t268, !tbaa !27
  %t270 = extractvalue { i64, ptr } %t269, 0
  %t271 = load { i64, ptr }, ptr %l124, !tbaa !27
  %t272 = extractvalue { i64, ptr } %t271, 0
  store i64 %t272, ptr %l126, !tbaa !24
  %t274 = load i64, ptr %l126, !tbaa !24
  %t275 = icmp eq i64 %t270, %t274
  br i1 %t275, label %bb43, label %bb44
bb43:
  %t277 = load ptr, ptr %lp3
  %t278 = getelementptr { i64, ptr }, ptr %t277, i32 0, i32 1
  %t279 = load ptr, ptr %t278, !tbaa !27
  %t280 = getelementptr { i64, ptr }, ptr %l124, i32 0, i32 1
  %t281 = load ptr, ptr %t280, !tbaa !27
  %t282 = load i64, ptr %l126, !tbaa !24
  %t283 = mul i64 %t282, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t279, ptr %t281, i64 %t283, i1 false)
  br label %bb45
bb44:
  %t284 = load { i64, ptr }, ptr %l124, !tbaa !27
  %t285 = load ptr, ptr %lp3
  store { i64, ptr } %t284, ptr %t285, !tbaa !27
  br label %bb45
bb45:
  %t286 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t286, ptr %l128, !tbaa !27
  %t287 = load i64, ptr %l20, !tbaa !24
  %t289 = getelementptr { i64, ptr }, ptr %l128, i32 0, i32 1
  %t290 = load ptr, ptr %t289, !tbaa !27
  %t291 = getelementptr i32, ptr %t290, i64 %t287
  %t292 = load i32, ptr %t291, !tbaa !33
  store i32 %t292, ptr %l4, !tbaa !23
  store i1 false, ptr %l5, !tbaa !21
  call void @__olang_scope_close(ptr %s6)
  br label %bb116
bb46:
  %t294 = load { i64, [1 x i64] }, ptr %l18
  %t296 = extractvalue { i64, [1 x i64] } %t294, 0
  %t297 = icmp eq i64 %t296, 1
  br i1 %t297, label %bb47, label %bb48
bb47:
  %t299 = getelementptr { i64, [1 x i64] }, ptr %l18, i32 0, i32 1
  %t300 = getelementptr { i32 }, ptr %t299, i32 0, i32 0
  %t301 = load i32, ptr %t300
  store i32 %t301, ptr %l22, !tbaa !23
  br label %bb49
bb48:
  br label %bb65
bb49:
  store %olang.scope zeroinitializer, ptr %s8
  %t303 = load ptr, ptr %l0, !tbaa !29
  %t304 = load i32, ptr %l22, !tbaa !23
  %t307 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2elocalType(ptr %v0, ptr %t303, i32 %t304)
  store i32 %t307, ptr %l136
  br label %bb50
bb50:
  %t308 = load i32, ptr %l136, !tbaa !23
  store i32 %t308, ptr %l23, !tbaa !23
  %t309 = load ptr, ptr %l0, !tbaa !29
  store ptr %t309, ptr %l137, !tbaa !29
  %t310 = load ptr, ptr %l0, !tbaa !29
  store ptr %t310, ptr %l138, !tbaa !29
  %t311 = load ptr, ptr %l0, !tbaa !29
  %t312 = load i32, ptr %l23, !tbaa !23
  %t315 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s8, ptr %t311, i32 %t312)
  store { i64, ptr } %t315, ptr %l141
  br label %bb51
bb51:
  %t316 = load { i64, ptr }, ptr %l141, !tbaa !27
  %t317 = extractvalue { i64, ptr } %t316, 0
  %t318 = extractvalue { i64, ptr } %t316, 1
  %t319 = mul i64 %t317, 1
  %t320 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t319)
  call void @llvm.memcpy.p0.p0.i64(ptr %t320, ptr %t318, i64 %t319, i1 false)
  %t321 = insertvalue { i64, ptr } undef, i64 %t317, 0
  %t322 = insertvalue { i64, ptr } %t321, ptr %t320, 1
  store { i64, ptr } %t322, ptr %l142, !tbaa !27
  %t323 = load ptr, ptr %l0, !tbaa !29
  %t324 = load i32, ptr %l22, !tbaa !23
  %t327 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elocalAt(ptr %v0, ptr %s8, ptr %t323, i32 %t324)
  store { i64, ptr } %t327, ptr %l145
  br label %bb52
bb52:
  %t328 = load { i64, ptr }, ptr %l145, !tbaa !27
  %t329 = extractvalue { i64, ptr } %t328, 0
  %t330 = extractvalue { i64, ptr } %t328, 1
  %t331 = mul i64 %t329, 1
  %t332 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t331)
  call void @llvm.memcpy.p0.p0.i64(ptr %t332, ptr %t330, i64 %t331, i1 false)
  %t333 = insertvalue { i64, ptr } undef, i64 %t329, 0
  %t334 = insertvalue { i64, ptr } %t333, ptr %t332, 1
  store { i64, ptr } %t334, ptr %l146, !tbaa !27
  %t335 = load ptr, ptr %l0, !tbaa !29
  %t337 = getelementptr %"compiler/emit:fnEm", ptr %t335, i32 0, i32 0
  %t338 = load ptr, ptr %t337, !tbaa !29
  %t339 = load i32, ptr %l23, !tbaa !23
  %t342 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etbaa(ptr %v0, ptr %s8, ptr %t338, i32 %t339, i1 false)
  store { i64, ptr } %t342, ptr %l150
  br label %bb53
bb53:
  %t343 = load { i64, ptr }, ptr %l150, !tbaa !27
  %t344 = extractvalue { i64, ptr } %t343, 0
  %t345 = extractvalue { i64, ptr } %t343, 1
  %t346 = mul i64 %t344, 1
  %t347 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t346)
  call void @llvm.memcpy.p0.p0.i64(ptr %t347, ptr %t345, i64 %t346, i1 false)
  %t348 = insertvalue { i64, ptr } undef, i64 %t344, 0
  %t349 = insertvalue { i64, ptr } %t348, ptr %t347, 1
  %t350 = load ptr, ptr %l138, !tbaa !29
  %t351 = load { i64, ptr }, ptr %l142, !tbaa !27
  %t352 = load { i64, ptr }, ptr %l146, !tbaa !27
  %t354 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %s8, ptr %s8, ptr %s8, ptr %s8, ptr %t350, { i64, ptr } %t351, { i64, ptr } %t352, { i64, ptr } %t349)
  store { i64, ptr } %t354, ptr %l152
  br label %bb54
bb54:
  %t355 = load { i64, ptr }, ptr %l152, !tbaa !27
  %t356 = extractvalue { i64, ptr } %t355, 0
  %t357 = extractvalue { i64, ptr } %t355, 1
  %t358 = mul i64 %t356, 1
  %t359 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t358)
  call void @llvm.memcpy.p0.p0.i64(ptr %t359, ptr %t357, i64 %t358, i1 false)
  %t360 = insertvalue { i64, ptr } undef, i64 %t356, 0
  %t361 = insertvalue { i64, ptr } %t360, ptr %t359, 1
  %t362 = load i32, ptr %l23, !tbaa !23
  %t363 = load ptr, ptr %l137, !tbaa !29
  %t366 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eindex(ptr %v0, ptr %s8, ptr %s8, ptr %t363, { i64, ptr } %t361, i32 %t362)
  store { i64, ptr } %t366, ptr %l155
  br label %bb55
bb55:
  %t367 = load { i64, ptr }, ptr %l155, !tbaa !27
  store { i64, ptr } %t367, ptr %l24, !tbaa !27
  %t368 = load ptr, ptr %l0, !tbaa !29
  %t369 = load i32, ptr %l4, !tbaa !23
  %t372 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2erunTime(ptr %v0, ptr %t368, i32 %t369)
  store i1 %t372, ptr %l158
  br label %bb56
bb56:
  %t373 = load i1, ptr %l158, !tbaa !21
  br i1 %t373, label %bb57, label %bb58
bb57:
  store i1 false, ptr %l6, !tbaa !21
  br label %bb59
bb58:
  br label %bb59
bb59:
  %t374 = load ptr, ptr %l0, !tbaa !29
  store ptr %t374, ptr %l159, !tbaa !29
  %t375 = load ptr, ptr %lp3
  %t376 = load { i64, ptr }, ptr %t375, !tbaa !27
  store { i64, ptr } %t376, ptr %l160, !tbaa !27
  %t377 = load i32, ptr %l4, !tbaa !23
  store i32 %t377, ptr %l161, !tbaa !23
  %t378 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t378, ptr %l162, !tbaa !27
  %t379 = load ptr, ptr %l0, !tbaa !29
  %t381 = getelementptr %"compiler/emit:fnEm", ptr %t379, i32 0, i32 0
  %t382 = load ptr, ptr %t381, !tbaa !29
  %t383 = load i1, ptr %l5, !tbaa !21
  %t384 = load i1, ptr %l6, !tbaa !21
  %t388 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2edescTag(ptr %v0, ptr %s8, ptr %t382, i1 %t383, i1 %t384)
  store { i64, ptr } %t388, ptr %l167
  br label %bb60
bb60:
  %t389 = load { i64, ptr }, ptr %l167, !tbaa !27
  %t390 = extractvalue { i64, ptr } %t389, 0
  %t391 = extractvalue { i64, ptr } %t389, 1
  %t392 = mul i64 %t390, 1
  %t393 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t392)
  call void @llvm.memcpy.p0.p0.i64(ptr %t393, ptr %t391, i64 %t392, i1 false)
  %t394 = insertvalue { i64, ptr } undef, i64 %t390, 0
  %t395 = insertvalue { i64, ptr } %t394, ptr %t393, 1
  %t396 = load ptr, ptr %l159, !tbaa !29
  %t397 = load { i64, ptr }, ptr %l160, !tbaa !27
  %t398 = load i32, ptr %l161, !tbaa !23
  %t399 = load { i64, ptr }, ptr %l162, !tbaa !27
  %t401 = call { { i64, ptr }, i32 } @compiler_2femit_2ecompiler_2femit_3afnEm_2eelemAt(ptr %v0, ptr %v1, ptr %s8, ptr %s8, ptr %s8, ptr %t396, { i64, ptr } %t397, i32 %t398, { i64, ptr } %t399, { i64, ptr } %t395)
  store { { i64, ptr }, i32 } %t401, ptr %l169
  br label %bb61
bb61:
  %t402 = load { { i64, ptr }, i32 }, ptr %l169
  store { { i64, ptr }, i32 } %t402, ptr %l25
  %t403 = getelementptr { { i64, ptr }, i32 }, ptr %l25, i32 0, i32 0
  %t404 = load { i64, ptr }, ptr %t403, !tbaa !27
  store { i64, ptr } %t404, ptr %l170, !tbaa !27
  %t405 = load ptr, ptr %lp3
  %t406 = load { i64, ptr }, ptr %t405, !tbaa !27
  %t407 = extractvalue { i64, ptr } %t406, 0
  %t408 = load { i64, ptr }, ptr %l170, !tbaa !27
  %t409 = extractvalue { i64, ptr } %t408, 0
  store i64 %t409, ptr %l172, !tbaa !24
  %t411 = load i64, ptr %l172, !tbaa !24
  %t412 = icmp eq i64 %t407, %t411
  br i1 %t412, label %bb62, label %bb63
bb62:
  %t414 = load ptr, ptr %lp3
  %t415 = getelementptr { i64, ptr }, ptr %t414, i32 0, i32 1
  %t416 = load ptr, ptr %t415, !tbaa !27
  %t417 = getelementptr { i64, ptr }, ptr %l170, i32 0, i32 1
  %t418 = load ptr, ptr %t417, !tbaa !27
  %t419 = load i64, ptr %l172, !tbaa !24
  %t420 = mul i64 %t419, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t416, ptr %t418, i64 %t420, i1 false)
  br label %bb64
bb63:
  %t421 = load { i64, ptr }, ptr %l170, !tbaa !27
  %t422 = extractvalue { i64, ptr } %t421, 0
  store i64 %t422, ptr %l174, !tbaa !24
  %t423 = load i64, ptr %l174, !tbaa !24
  %t424 = mul i64 %t423, 1
  %t425 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t424)
  %t426 = insertvalue { i64, ptr } undef, i64 %t423, 0
  %t427 = insertvalue { i64, ptr } %t426, ptr %t425, 1
  store { i64, ptr } %t427, ptr %l175, !tbaa !27
  %t428 = getelementptr { i64, ptr }, ptr %l175, i32 0, i32 1
  %t429 = load ptr, ptr %t428, !tbaa !27
  %t430 = getelementptr { i64, ptr }, ptr %l170, i32 0, i32 1
  %t431 = load ptr, ptr %t430, !tbaa !27
  %t432 = load i64, ptr %l174, !tbaa !24
  %t433 = mul i64 %t432, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t429, ptr %t431, i64 %t433, i1 false)
  %t434 = load { i64, ptr }, ptr %l175, !tbaa !27
  %t435 = load ptr, ptr %lp3
  store { i64, ptr } %t434, ptr %t435, !tbaa !27
  br label %bb64
bb64:
  %t436 = getelementptr { { i64, ptr }, i32 }, ptr %l25, i32 0, i32 1
  %t437 = load i32, ptr %t436, !tbaa !23
  store i32 %t437, ptr %l4, !tbaa !23
  store i1 true, ptr %l5, !tbaa !21
  call void @__olang_scope_close(ptr %s8)
  br label %bb116
bb65:
  %t439 = load { i64, [1 x i64] }, ptr %l18
  %t441 = extractvalue { i64, [1 x i64] } %t439, 0
  %t442 = icmp eq i64 %t441, 2
  br i1 %t442, label %bb66, label %bb67
bb66:
  %t444 = getelementptr { i64, [1 x i64] }, ptr %l18, i32 0, i32 1
  %t445 = getelementptr { i64 }, ptr %t444, i32 0, i32 0
  %t446 = load i64, ptr %t445
  store i64 %t446, ptr %l26, !tbaa !24
  br label %bb68
bb67:
  br label %bb78
bb68:
  store %olang.scope zeroinitializer, ptr %s10
  %t448 = load ptr, ptr %l0, !tbaa !29
  %t449 = load i32, ptr %l4, !tbaa !23
  %t452 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2erunTime(ptr %v0, ptr %t448, i32 %t449)
  store i1 %t452, ptr %l182
  br label %bb69
bb69:
  %t453 = load i1, ptr %l182, !tbaa !21
  br i1 %t453, label %bb70, label %bb71
bb70:
  store i1 false, ptr %l6, !tbaa !21
  br label %bb72
bb71:
  br label %bb72
bb72:
  %t454 = load ptr, ptr %l0, !tbaa !29
  store ptr %t454, ptr %l183, !tbaa !29
  %t455 = load ptr, ptr %lp3
  %t456 = load { i64, ptr }, ptr %t455, !tbaa !27
  store { i64, ptr } %t456, ptr %l184, !tbaa !27
  %t457 = load i32, ptr %l4, !tbaa !23
  store i32 %t457, ptr %l185, !tbaa !23
  %t458 = load i64, ptr %l26, !tbaa !24
  %t460 = call i64 @__olang_fmt_i64(ptr null, i64 %t458)
  %t461 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t460)
  %t462 = call i64 @__olang_fmt_i64(ptr %t461, i64 %t458)
  %t463 = insertvalue { i64, ptr } undef, i64 %t460, 0
  %t464 = insertvalue { i64, ptr } %t463, ptr %t461, 1
  %t466 = extractvalue { i64, ptr } %t464, 0
  %t467 = extractvalue { i64, ptr } %t464, 1
  %t468 = mul i64 %t466, 1
  %t469 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t468)
  call void @llvm.memcpy.p0.p0.i64(ptr %t469, ptr %t467, i64 %t468, i1 false)
  %t470 = insertvalue { i64, ptr } undef, i64 %t466, 0
  %t471 = insertvalue { i64, ptr } %t470, ptr %t469, 1
  store { i64, ptr } %t471, ptr %l188, !tbaa !27
  %t472 = load ptr, ptr %l0, !tbaa !29
  %t474 = getelementptr %"compiler/emit:fnEm", ptr %t472, i32 0, i32 0
  %t475 = load ptr, ptr %t474, !tbaa !29
  %t476 = load i1, ptr %l5, !tbaa !21
  %t477 = load i1, ptr %l6, !tbaa !21
  %t481 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2edescTag(ptr %v0, ptr %s10, ptr %t475, i1 %t476, i1 %t477)
  store { i64, ptr } %t481, ptr %l193
  br label %bb73
bb73:
  %t482 = load { i64, ptr }, ptr %l193, !tbaa !27
  %t483 = extractvalue { i64, ptr } %t482, 0
  %t484 = extractvalue { i64, ptr } %t482, 1
  %t485 = mul i64 %t483, 1
  %t486 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t485)
  call void @llvm.memcpy.p0.p0.i64(ptr %t486, ptr %t484, i64 %t485, i1 false)
  %t487 = insertvalue { i64, ptr } undef, i64 %t483, 0
  %t488 = insertvalue { i64, ptr } %t487, ptr %t486, 1
  %t489 = load ptr, ptr %l183, !tbaa !29
  %t490 = load { i64, ptr }, ptr %l184, !tbaa !27
  %t491 = load i32, ptr %l185, !tbaa !23
  %t492 = load { i64, ptr }, ptr %l188, !tbaa !27
  %t494 = call { { i64, ptr }, i32 } @compiler_2femit_2ecompiler_2femit_3afnEm_2eelemAt(ptr %v0, ptr %v1, ptr %s10, ptr %s10, ptr %s10, ptr %t489, { i64, ptr } %t490, i32 %t491, { i64, ptr } %t492, { i64, ptr } %t488)
  store { { i64, ptr }, i32 } %t494, ptr %l195
  br label %bb74
bb74:
  %t495 = load { { i64, ptr }, i32 }, ptr %l195
  store { { i64, ptr }, i32 } %t495, ptr %l27
  %t496 = getelementptr { { i64, ptr }, i32 }, ptr %l27, i32 0, i32 0
  %t497 = load { i64, ptr }, ptr %t496, !tbaa !27
  store { i64, ptr } %t497, ptr %l196, !tbaa !27
  %t498 = load ptr, ptr %lp3
  %t499 = load { i64, ptr }, ptr %t498, !tbaa !27
  %t500 = extractvalue { i64, ptr } %t499, 0
  %t501 = load { i64, ptr }, ptr %l196, !tbaa !27
  %t502 = extractvalue { i64, ptr } %t501, 0
  store i64 %t502, ptr %l198, !tbaa !24
  %t504 = load i64, ptr %l198, !tbaa !24
  %t505 = icmp eq i64 %t500, %t504
  br i1 %t505, label %bb75, label %bb76
bb75:
  %t507 = load ptr, ptr %lp3
  %t508 = getelementptr { i64, ptr }, ptr %t507, i32 0, i32 1
  %t509 = load ptr, ptr %t508, !tbaa !27
  %t510 = getelementptr { i64, ptr }, ptr %l196, i32 0, i32 1
  %t511 = load ptr, ptr %t510, !tbaa !27
  %t512 = load i64, ptr %l198, !tbaa !24
  %t513 = mul i64 %t512, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t509, ptr %t511, i64 %t513, i1 false)
  br label %bb77
bb76:
  %t514 = load { i64, ptr }, ptr %l196, !tbaa !27
  %t515 = extractvalue { i64, ptr } %t514, 0
  store i64 %t515, ptr %l200, !tbaa !24
  %t516 = load i64, ptr %l200, !tbaa !24
  %t517 = mul i64 %t516, 1
  %t518 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t517)
  %t519 = insertvalue { i64, ptr } undef, i64 %t516, 0
  %t520 = insertvalue { i64, ptr } %t519, ptr %t518, 1
  store { i64, ptr } %t520, ptr %l201, !tbaa !27
  %t521 = getelementptr { i64, ptr }, ptr %l201, i32 0, i32 1
  %t522 = load ptr, ptr %t521, !tbaa !27
  %t523 = getelementptr { i64, ptr }, ptr %l196, i32 0, i32 1
  %t524 = load ptr, ptr %t523, !tbaa !27
  %t525 = load i64, ptr %l200, !tbaa !24
  %t526 = mul i64 %t525, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t522, ptr %t524, i64 %t526, i1 false)
  %t527 = load { i64, ptr }, ptr %l201, !tbaa !27
  %t528 = load ptr, ptr %lp3
  store { i64, ptr } %t527, ptr %t528, !tbaa !27
  br label %bb77
bb77:
  %t529 = getelementptr { { i64, ptr }, i32 }, ptr %l27, i32 0, i32 1
  %t530 = load i32, ptr %t529, !tbaa !23
  store i32 %t530, ptr %l4, !tbaa !23
  store i1 true, ptr %l5, !tbaa !21
  call void @__olang_scope_close(ptr %s10)
  br label %bb116
bb78:
  %t532 = load { i64, [1 x i64] }, ptr %l18
  %t534 = extractvalue { i64, [1 x i64] } %t532, 0
  %t535 = icmp eq i64 %t534, 3
  br i1 %t535, label %bb79, label %bb80
bb79:
  br label %bb81
bb80:
  br label %bb95
bb81:
  store %olang.scope zeroinitializer, ptr %s13
  %t537 = load ptr, ptr %l2, !tbaa !29
  %t538 = load i32, ptr %l19, !tbaa !23
  %t541 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t537, i32 %t538)
  store i32 %t541, ptr %l207
  br label %bb82
bb82:
  %t542 = load i32, ptr %l207, !tbaa !23
  store i32 %t542, ptr %l28, !tbaa !23
  %t543 = load i1, ptr %l6, !tbaa !21
  br i1 %t543, label %bb83, label %bb84
bb83:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d385, i32 0, i32 1) }, ptr %l209, !tbaa !27
  br label %bb86
bb84:
  %t545 = load ptr, ptr %l0, !tbaa !29
  %t547 = getelementptr %"compiler/emit:fnEm", ptr %t545, i32 0, i32 0
  %t548 = load ptr, ptr %t547, !tbaa !29
  %t549 = load i32, ptr %l19, !tbaa !23
  %t550 = load i1, ptr %l5, !tbaa !21
  %t554 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etbaa(ptr %v0, ptr %s13, ptr %t548, i32 %t549, i1 %t550)
  store { i64, ptr } %t554, ptr %l214
  br label %bb85
bb85:
  %t555 = load { i64, ptr }, ptr %l214, !tbaa !27
  %t556 = extractvalue { i64, ptr } %t555, 0
  %t557 = extractvalue { i64, ptr } %t555, 1
  %t558 = mul i64 %t556, 1
  %t559 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t558)
  call void @llvm.memcpy.p0.p0.i64(ptr %t559, ptr %t557, i64 %t558, i1 false)
  %t560 = insertvalue { i64, ptr } undef, i64 %t556, 0
  %t561 = insertvalue { i64, ptr } %t560, ptr %t559, 1
  store { i64, ptr } %t561, ptr %l209, !tbaa !27
  br label %bb86
bb86:
  %t563 = load { i64, ptr }, ptr %l209, !tbaa !27
  store { i64, ptr } %t563, ptr %l29, !tbaa !27
  %t564 = load i32, ptr %l28, !tbaa !23
  store i32 %t564, ptr %l4, !tbaa !23
  %t566 = load ptr, ptr %l0, !tbaa !29
  %t567 = load i32, ptr %l28, !tbaa !23
  %t570 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2erunTime(ptr %v0, ptr %t566, i32 %t567)
  store i1 %t570, ptr %l219
  br label %bb87
bb87:
  %t571 = load i1, ptr %l219, !tbaa !21
  %t572 = xor i1 %t571, true
  br i1 %t572, label %bb88, label %bb89
bb88:
  %t574 = load ptr, ptr %l0, !tbaa !29
  %t575 = load ptr, ptr %lp3
  %t576 = load { i64, ptr }, ptr %t575, !tbaa !27
  %t577 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t581 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %v1, ptr %v1, ptr %s13, ptr %v1, ptr %t574, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d386, i32 0, i32 1) }, { i64, ptr } %t576, { i64, ptr } %t577)
  store { i64, ptr } %t581, ptr %l224
  br label %bb90
bb89:
  br label %bb94
bb90:
  %t582 = load ptr, ptr %lp3
  %t583 = load { i64, ptr }, ptr %t582, !tbaa !27
  %t584 = extractvalue { i64, ptr } %t583, 0
  %t585 = load { i64, ptr }, ptr %l224, !tbaa !27
  %t586 = extractvalue { i64, ptr } %t585, 0
  store i64 %t586, ptr %l226, !tbaa !24
  %t588 = load i64, ptr %l226, !tbaa !24
  %t589 = icmp eq i64 %t584, %t588
  br i1 %t589, label %bb91, label %bb92
bb91:
  %t591 = load ptr, ptr %lp3
  %t592 = getelementptr { i64, ptr }, ptr %t591, i32 0, i32 1
  %t593 = load ptr, ptr %t592, !tbaa !27
  %t594 = getelementptr { i64, ptr }, ptr %l224, i32 0, i32 1
  %t595 = load ptr, ptr %t594, !tbaa !27
  %t596 = load i64, ptr %l226, !tbaa !24
  %t597 = mul i64 %t596, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t593, ptr %t595, i64 %t597, i1 false)
  br label %bb93
bb92:
  %t598 = load { i64, ptr }, ptr %l224, !tbaa !27
  %t599 = load ptr, ptr %lp3
  store { i64, ptr } %t598, ptr %t599, !tbaa !27
  br label %bb93
bb93:
  store i1 false, ptr %l6, !tbaa !21
  store i1 false, ptr %l5, !tbaa !21
  br label %bb94
bb94:
  call void @__olang_scope_close(ptr %s13)
  br label %bb116
bb95:
  %t600 = load { i64, [1 x i64] }, ptr %l18
  %t602 = extractvalue { i64, [1 x i64] } %t600, 0
  %t603 = icmp eq i64 %t602, 4
  br i1 %t603, label %bb96, label %bb97
bb96:
  br label %bb98
bb97:
  br label %bb115
bb98:
  store %olang.scope zeroinitializer, ptr %s15
  %t605 = load ptr, ptr %l0, !tbaa !29
  store ptr %t605, ptr %l230, !tbaa !29
  %t606 = load ptr, ptr %l0, !tbaa !29
  %t607 = load i32, ptr %l19, !tbaa !23
  %t610 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s15, ptr %t606, i32 %t607)
  store { i64, ptr } %t610, ptr %l233
  br label %bb99
bb99:
  %t611 = load ptr, ptr %lp3
  %t612 = load { i64, ptr }, ptr %t611, !tbaa !27
  %t613 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d387, i32 0, i32 1) }, 1
  %t614 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d387, i32 0, i32 1) }, 0
  %t615 = load { i64, ptr }, ptr %l233, !tbaa !27
  %t616 = extractvalue { i64, ptr } %t615, 1
  %t617 = extractvalue { i64, ptr } %t615, 0
  %t618 = add i64 %t614, %t617
  %t619 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d388, i32 0, i32 1) }, 1
  %t620 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d388, i32 0, i32 1) }, 0
  %t621 = add i64 %t618, %t620
  %t623 = extractvalue { i64, ptr } %t612, 1
  %t624 = extractvalue { i64, ptr } %t612, 0
  %t625 = add i64 %t621, %t624
  %t626 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d389, i32 0, i32 1) }, 1
  %t627 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d389, i32 0, i32 1) }, 0
  %t628 = add i64 %t625, %t627
  %t629 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t628)
  call void @olang_textcopy(ptr %t629, ptr %t613, i64 %t614)
  %t630 = getelementptr i8, ptr %t629, i64 %t614
  call void @olang_textcopy(ptr %t630, ptr %t616, i64 %t617)
  %t631 = getelementptr i8, ptr %t630, i64 %t617
  call void @olang_textcopy(ptr %t631, ptr %t619, i64 %t620)
  %t632 = getelementptr i8, ptr %t631, i64 %t620
  call void @olang_textcopy(ptr %t632, ptr %t623, i64 %t624)
  %t633 = getelementptr i8, ptr %t632, i64 %t624
  call void @olang_textcopy(ptr %t633, ptr %t626, i64 %t627)
  %t634 = insertvalue { i64, ptr } undef, i64 %t628, 0
  %t635 = insertvalue { i64, ptr } %t634, ptr %t629, 1
  %t637 = extractvalue { i64, ptr } %t635, 0
  %t638 = extractvalue { i64, ptr } %t635, 1
  %t639 = mul i64 %t637, 1
  %t640 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t639)
  call void @llvm.memcpy.p0.p0.i64(ptr %t640, ptr %t638, i64 %t639, i1 false)
  %t641 = insertvalue { i64, ptr } undef, i64 %t637, 0
  %t642 = insertvalue { i64, ptr } %t641, ptr %t640, 1
  %t643 = load ptr, ptr %l230, !tbaa !29
  %t645 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v1, ptr %t643, { i64, ptr } %t642)
  store { i64, ptr } %t645, ptr %l237
  br label %bb100
bb100:
  %t646 = load ptr, ptr %lp3
  %t647 = load { i64, ptr }, ptr %t646, !tbaa !27
  %t648 = extractvalue { i64, ptr } %t647, 0
  %t649 = load { i64, ptr }, ptr %l237, !tbaa !27
  %t650 = extractvalue { i64, ptr } %t649, 0
  store i64 %t650, ptr %l239, !tbaa !24
  %t652 = load i64, ptr %l239, !tbaa !24
  %t653 = icmp eq i64 %t648, %t652
  br i1 %t653, label %bb101, label %bb102
bb101:
  %t655 = load ptr, ptr %lp3
  %t656 = getelementptr { i64, ptr }, ptr %t655, i32 0, i32 1
  %t657 = load ptr, ptr %t656, !tbaa !27
  %t658 = getelementptr { i64, ptr }, ptr %l237, i32 0, i32 1
  %t659 = load ptr, ptr %t658, !tbaa !27
  %t660 = load i64, ptr %l239, !tbaa !24
  %t661 = mul i64 %t660, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t657, ptr %t659, i64 %t661, i1 false)
  br label %bb103
bb102:
  %t662 = load { i64, ptr }, ptr %l237, !tbaa !27
  %t663 = load ptr, ptr %lp3
  store { i64, ptr } %t662, ptr %t663, !tbaa !27
  br label %bb103
bb103:
  %t664 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t664, ptr %l4, !tbaa !23
  %t666 = load ptr, ptr %l2, !tbaa !29
  store ptr %t666, ptr %l242, !tbaa !29
  %t667 = load ptr, ptr %l0, !tbaa !29
  %t668 = load i32, ptr %l19, !tbaa !23
  %t671 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2ecasesList(ptr %v0, ptr %t667, i32 %t668)
  store i32 %t671, ptr %l245
  br label %bb104
bb104:
  %t672 = load ptr, ptr %l242, !tbaa !29
  %t673 = load i32, ptr %l245, !tbaa !23
  %t674 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t672, i32 %t673)
  store { i64, ptr } %t674, ptr %l246
  br label %bb105
bb105:
  %t675 = load { i64, ptr }, ptr %l246, !tbaa !27
  store { i64, ptr } %t675, ptr %l30, !tbaa !27
  %t676 = load { i64, [1 x i64] }, ptr %l18
  %t678 = extractvalue { i64, [1 x i64] } %t676, 0
  %t679 = icmp eq i64 %t678, 4
  br i1 %t679, label %bb106, label %bb107
bb106:
  %t681 = getelementptr { i64, [1 x i64] }, ptr %l18, i32 0, i32 1
  %t682 = getelementptr { i64 }, ptr %t681, i32 0, i32 0
  %t683 = load i64, ptr %t682
  store i64 %t683, ptr %l31, !tbaa !24
  br label %bb108
bb107:
  br label %bb109
bb108:
  %t685 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t685, ptr %l250, !tbaa !27
  %t686 = load i64, ptr %l31, !tbaa !24
  %t688 = getelementptr { i64, ptr }, ptr %l250, i32 0, i32 1
  %t689 = load ptr, ptr %t688, !tbaa !27
  %t690 = getelementptr i32, ptr %t689, i64 %t686
  %t691 = load i32, ptr %t690, !tbaa !33
  store i32 %t691, ptr %l4, !tbaa !23
  br label %bb114
bb109:
  br i1 true, label %bb110, label %bb111
bb110:
  br label %bb112
bb111:
  br label %bb113
bb112:
  br label %bb114
bb113:
  call void @__olang_check_failed(ptr @olang_loc_f0091f918c975106_bc2d594a86836fba)
  unreachable
bb114:
  store i1 true, ptr %l6, !tbaa !21
  call void @__olang_scope_close(ptr %s15)
  br label %bb116
bb115:
  call void @__olang_check_failed(ptr @olang_loc_44ab2decf02f961d_3f31a3219a480a51)
  unreachable
bb116:
  call void @__olang_scope_close(ptr %s5)
  br label %bb117
bb117:
  %t693 = load i32, ptr %l16, !tbaa !23
  %t695 = add i32 %t693, 1
  store i32 %t695, ptr %l16, !tbaa !23
  br label %bb30
bb118:
  %t697 = load ptr, ptr %l0, !tbaa !29
  store ptr %t697, ptr %l255, !tbaa !29
  %t698 = load i1, ptr %l6, !tbaa !21
  br i1 %t698, label %bb119, label %bb120
bb119:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d390, i32 0, i32 1) }, ptr %l257, !tbaa !27
  br label %bb122
bb120:
  %t700 = load ptr, ptr %l0, !tbaa !29
  %t702 = getelementptr %"compiler/emit:fnEm", ptr %t700, i32 0, i32 0
  %t703 = load ptr, ptr %t702, !tbaa !29
  %t704 = load i32, ptr %l4, !tbaa !23
  %t705 = load i1, ptr %l5, !tbaa !21
  %t709 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etbaa(ptr %v0, ptr %v0, ptr %t703, i32 %t704, i1 %t705)
  store { i64, ptr } %t709, ptr %l262
  br label %bb121
bb121:
  %t710 = load { i64, ptr }, ptr %l262, !tbaa !27
  %t711 = extractvalue { i64, ptr } %t710, 0
  %t712 = extractvalue { i64, ptr } %t710, 1
  %t713 = mul i64 %t711, 1
  %t714 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t713)
  call void @llvm.memcpy.p0.p0.i64(ptr %t714, ptr %t712, i64 %t713, i1 false)
  %t715 = insertvalue { i64, ptr } undef, i64 %t711, 0
  %t716 = insertvalue { i64, ptr } %t715, ptr %t714, 1
  store { i64, ptr } %t716, ptr %l257, !tbaa !27
  br label %bb122
bb122:
  %t718 = load { i64, ptr }, ptr %l257, !tbaa !27
  %t719 = load ptr, ptr %l255, !tbaa !29
  %t720 = getelementptr %"compiler/emit:fnEm", ptr %t719, i32 0, i32 14
  store { i64, ptr } %t718, ptr %t720, !tbaa !27
  %t721 = load ptr, ptr %lp3
  %t722 = load { i64, ptr }, ptr %t721, !tbaa !27
  %t723 = load i32, ptr %l4, !tbaa !23
  %t725 = insertvalue { { i64, ptr }, i32 } undef, { i64, ptr } %t722, 0
  %t727 = insertvalue { { i64, ptr }, i32 } %t725, i32 %t723, 1
  store { { i64, ptr }, i32 } %t727, ptr %rv
  br label %ret
ret:
  %rr = load { { i64, ptr }, i32 }, ptr %rv
  ret { { i64, ptr }, i32 } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ealloca(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %lp3 = alloca ptr
  %l5 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2etmp(ptr %v0, ptr %v2, ptr %t1)
  store { i64, ptr } %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t4, ptr %lp3
  %t5 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t6 = load ptr, ptr %lp3
  store { i64, ptr } %t5, ptr %t6, !tbaa !27
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/emit:fnEm", ptr %t7, i32 0, i32 3
  %t10 = load ptr, ptr %lp3
  %t11 = load { i64, ptr }, ptr %t10, !tbaa !27
  %t13 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d391, i32 0, i32 1) }, 1
  %t14 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d391, i32 0, i32 1) }, 0
  %t16 = extractvalue { i64, ptr } %t11, 1
  %t17 = extractvalue { i64, ptr } %t11, 0
  %t18 = add i64 %t14, %t17
  %t19 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d392, i32 0, i32 1) }, 1
  %t20 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d392, i32 0, i32 1) }, 0
  %t21 = add i64 %t18, %t20
  %t23 = extractvalue { i64, ptr } %a1, 1
  %t24 = extractvalue { i64, ptr } %a1, 0
  %t25 = add i64 %t21, %t24
  %t26 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t25)
  call void @olang_textcopy(ptr %t26, ptr %t13, i64 %t14)
  %t27 = getelementptr i8, ptr %t26, i64 %t14
  call void @olang_textcopy(ptr %t27, ptr %t16, i64 %t17)
  %t28 = getelementptr i8, ptr %t27, i64 %t17
  call void @olang_textcopy(ptr %t28, ptr %t19, i64 %t20)
  %t29 = getelementptr i8, ptr %t28, i64 %t20
  call void @olang_textcopy(ptr %t29, ptr %t23, i64 %t24)
  %t30 = insertvalue { i64, ptr } undef, i64 %t25, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t26, 1
  %t33 = extractvalue { i64, ptr } %t31, 0
  %t34 = extractvalue { i64, ptr } %t31, 1
  %t35 = mul i64 %t33, 1
  %t36 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t35)
  call void @llvm.memcpy.p0.p0.i64(ptr %t36, ptr %t34, i64 %t35, i1 false)
  %t37 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t38 = insertvalue { i64, ptr } %t37, ptr %t36, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s0, ptr %t9, { i64, ptr } %t38)
  br label %bb2
bb2:
  %t41 = load i64, ptr %l2, !tbaa !24
  %t43 = icmp sgt i64 %t41, 0
  br i1 %t43, label %bb3, label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/emit:fnEm", ptr %t45, i32 0, i32 3
  %t48 = load i64, ptr %l2, !tbaa !24
  %t49 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d393, i32 0, i32 1) }, 1
  %t50 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d393, i32 0, i32 1) }, 0
  %t52 = call i64 @__olang_fmt_i64(ptr null, i64 %t48)
  %t53 = add i64 %t50, %t52
  %t54 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t53)
  call void @olang_textcopy(ptr %t54, ptr %t49, i64 %t50)
  %t55 = getelementptr i8, ptr %t54, i64 %t50
  %t56 = call i64 @__olang_fmt_i64(ptr %t55, i64 %t48)
  %t57 = insertvalue { i64, ptr } undef, i64 %t53, 0
  %t58 = insertvalue { i64, ptr } %t57, ptr %t54, 1
  %t60 = extractvalue { i64, ptr } %t58, 0
  %t61 = extractvalue { i64, ptr } %t58, 1
  %t62 = mul i64 %t60, 1
  %t63 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t62)
  call void @llvm.memcpy.p0.p0.i64(ptr %t63, ptr %t61, i64 %t62, i1 false)
  %t64 = insertvalue { i64, ptr } undef, i64 %t60, 0
  %t65 = insertvalue { i64, ptr } %t64, ptr %t63, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s2, ptr %t47, { i64, ptr } %t65)
  br label %bb5
bb4:
  br label %bb6
bb5:
  call void @__olang_scope_close(ptr %s2)
  br label %bb6
bb6:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/emit:fnEm", ptr %t68, i32 0, i32 3
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %t70, i8 10)
  br label %bb7
bb7:
  %t72 = load ptr, ptr %lp3
  %t73 = load { i64, ptr }, ptr %t72, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t73, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ebitcast(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %lp5 = alloca ptr
  %l7 = alloca i1
  %l10 = alloca { i64, ptr }
  %l12 = alloca i1
  %l13 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l27 = alloca i1
  %l28 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d394, i32 0, i32 1) })
  store i1 %t3, ptr %l7
  br label %bb1
bb1:
  %t4 = load i1, ptr %l7, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t6 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t9 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ebf16Bits(ptr %v0, ptr %v1, ptr %v4, ptr %t5, { i64, ptr } %t6, i1 true)
  store { i64, ptr } %t9, ptr %l10
  br label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_scope_close(ptr %s0)
  %t10 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t10, ptr %rv
  br label %ret
bb5:
  %t11 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t13 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v3, ptr %s0, { i64, ptr } %t11, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d395, i32 0, i32 1) })
  store i1 %t13, ptr %l12
  br label %bb6
bb6:
  %t14 = load i1, ptr %l12, !tbaa !21
  br i1 %t14, label %bb7, label %bb8
bb7:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t19 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eopaque16(ptr %v0, ptr %v1, ptr %s0, ptr %t15, { i64, ptr } %t16)
  store { i64, ptr } %t19, ptr %l16
  br label %bb9
bb8:
  %t20 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t20, 1
  %t23 = extractvalue { i64, ptr } %t20, 0
  %t24 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t23)
  call void @olang_textcopy(ptr %t24, ptr %t22, i64 %t23)
  %t25 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t26 = insertvalue { i64, ptr } %t25, ptr %t24, 1
  store { i64, ptr } %t26, ptr %l13, !tbaa !27
  br label %bb10
bb9:
  %t28 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t28, ptr %l13, !tbaa !27
  br label %bb10
bb10:
  %t29 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t33 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t34 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d396, i32 0, i32 1) }, 1
  %t35 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d396, i32 0, i32 1) }, 0
  %t37 = extractvalue { i64, ptr } %t31, 1
  %t38 = extractvalue { i64, ptr } %t31, 0
  %t39 = add i64 %t35, %t38
  %t40 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d397, i32 0, i32 1) }, 1
  %t41 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d397, i32 0, i32 1) }, 0
  %t42 = add i64 %t39, %t41
  %t44 = extractvalue { i64, ptr } %t29, 1
  %t45 = extractvalue { i64, ptr } %t29, 0
  %t46 = add i64 %t42, %t45
  %t47 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d398, i32 0, i32 1) }, 1
  %t48 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d398, i32 0, i32 1) }, 0
  %t49 = add i64 %t46, %t48
  %t51 = extractvalue { i64, ptr } %t33, 1
  %t52 = extractvalue { i64, ptr } %t33, 0
  %t53 = add i64 %t49, %t52
  %t54 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t53)
  call void @olang_textcopy(ptr %t54, ptr %t34, i64 %t35)
  %t55 = getelementptr i8, ptr %t54, i64 %t35
  call void @olang_textcopy(ptr %t55, ptr %t37, i64 %t38)
  %t56 = getelementptr i8, ptr %t55, i64 %t38
  call void @olang_textcopy(ptr %t56, ptr %t40, i64 %t41)
  %t57 = getelementptr i8, ptr %t56, i64 %t41
  call void @olang_textcopy(ptr %t57, ptr %t44, i64 %t45)
  %t58 = getelementptr i8, ptr %t57, i64 %t45
  call void @olang_textcopy(ptr %t58, ptr %t47, i64 %t48)
  %t59 = getelementptr i8, ptr %t58, i64 %t48
  call void @olang_textcopy(ptr %t59, ptr %t51, i64 %t52)
  %t60 = insertvalue { i64, ptr } undef, i64 %t53, 0
  %t61 = insertvalue { i64, ptr } %t60, ptr %t54, 1
  %t63 = extractvalue { i64, ptr } %t61, 0
  %t64 = extractvalue { i64, ptr } %t61, 1
  %t65 = mul i64 %t63, 1
  %t66 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t65)
  call void @llvm.memcpy.p0.p0.i64(ptr %t66, ptr %t64, i64 %t65, i1 false)
  %t67 = insertvalue { i64, ptr } undef, i64 %t63, 0
  %t68 = insertvalue { i64, ptr } %t67, ptr %t66, 1
  %t71 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v4, ptr %v4, ptr %t30, { i64, ptr } %t68)
  store { i64, ptr } %t71, ptr %l25
  br label %bb11
bb11:
  %t72 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 16, i64 8)
  store ptr %t72, ptr %lp5
  %t73 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t74 = load ptr, ptr %lp5
  store { i64, ptr } %t73, ptr %t74, !tbaa !27
  %t75 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t77 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t75, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d399, i32 0, i32 1) })
  store i1 %t77, ptr %l27
  br label %bb12
bb12:
  %t78 = load i1, ptr %l27, !tbaa !21
  br i1 %t78, label %bb13, label %bb14
bb13:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t80 = load ptr, ptr %lp5
  %t81 = load { i64, ptr }, ptr %t80, !tbaa !27
  %t84 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eopaque16(ptr %v0, ptr %v4, ptr %v4, ptr %t79, { i64, ptr } %t81)
  store { i64, ptr } %t84, ptr %l31
  br label %bb15
bb14:
  %t85 = load ptr, ptr %lp5
  %t86 = load { i64, ptr }, ptr %t85, !tbaa !27
  store { i64, ptr } %t86, ptr %l28, !tbaa !27
  br label %bb16
bb15:
  %t88 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t88, ptr %l28, !tbaa !27
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s0)
  %t89 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t89, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3afnEm_2eexit(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, { i64, [4 x i64] } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l3 = alloca { i64, [4 x i64] }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i32
  %l7 = alloca { i64, ptr }
  %l8 = alloca i32
  %l9 = alloca { i64, ptr }
  %l10 = alloca i32
  %l12 = alloca { { i64, ptr }, { i64, ptr } }
  %l15 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l20 = alloca i1
  %l23 = alloca ptr
  %l24 = alloca i32
  %l26 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l35 = alloca i64
  %l36 = alloca { i64, ptr }
  %l42 = alloca { i64, ptr }
  %l44 = alloca i64
  %l50 = alloca ptr
  %l53 = alloca { i64, ptr }
  %l56 = alloca ptr
  %l60 = alloca { i64, ptr }
  %l66 = alloca { i64, ptr }
  %l67 = alloca { i64, ptr }
  %l68 = alloca i64
  %l69 = alloca { i64, ptr }
  %l75 = alloca { i64, ptr }
  %l77 = alloca i64
  %l81 = alloca i1
  %l82 = alloca { i64, ptr }
  %l89 = alloca ptr
  %l90 = alloca { i64, ptr }
  %l96 = alloca { i64, ptr }
  %l104 = alloca ptr
  %l110 = alloca { i64, ptr }
  %l117 = alloca i32
  %l121 = alloca { i64, ptr }
  %l125 = alloca { { i64, ptr }, { i64, ptr } }
  %l126 = alloca { i64, ptr }
  %l127 = alloca i64
  %l128 = alloca { i64, ptr }
  %l129 = alloca { i64, ptr }
  %l130 = alloca i64
  %l131 = alloca { i64, ptr }
  %l135 = alloca { i64, ptr }
  %l136 = alloca ptr
  %l142 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.builder
  %s2room = alloca [64 x i8], align 8
  %s3 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s17 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  store { i64, [4 x i64] } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l2
  %t3 = call { i64, ptr } @compiler_2fmir_2eExitText(ptr %s0, i32 %t1)
  store { i64, ptr } %t3, ptr %l17
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t4, ptr %l4, !tbaa !27
  %t5 = load i32, ptr %l2
  %t7 = trunc i64 0 to i32
  %t8 = icmp eq i32 %t5, %t7
  br i1 %t8, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb4
bb3:
  %t10 = load i32, ptr %l2
  %t12 = trunc i64 1 to i32
  %t13 = icmp eq i32 %t10, %t12
  store i1 %t13, ptr %l20, !tbaa !21
  br label %bb4
bb4:
  %t15 = load i1, ptr %l20, !tbaa !21
  br i1 %t15, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l23, !tbaa !29
  %t17 = load i32, ptr %l2
  store i32 %t17, ptr %l24
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s2
  store ptr %s2room, ptr %s2
  %t18 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d400, i32 0, i32 1) }, 1
  %t19 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d400, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s2, ptr %t18, i64 %t19)
  call void @olang_2eHelperKind_2eRender_2ecompiler_2fmir_3aExitKind(ptr %s2, ptr %l24, i64 0)
  br label %bb7
bb6:
  br label %bb9
bb7:
  %t21 = load ptr, ptr %s2
  %t22 = getelementptr %olang.builder, ptr %s2, i32 0, i32 1
  %t23 = load i64, ptr %t22
  %t24 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t23)
  call void @olang_textcopy(ptr %t24, ptr %t21, i64 %t23)
  %t25 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t26 = insertvalue { i64, ptr } %t25, ptr %t24, 1
  store { i64, ptr } %t26, ptr %l26, !tbaa !27
  %t27 = getelementptr %olang.builder, ptr %s2, i32 0, i32 3
  %t28 = load ptr, ptr %t27
  %t29 = icmp ne ptr %t28, null
  br i1 %t29, label %sbgrew.30, label %sbdone.31
sbgrew.30:
  call void @__olang_sb_done(ptr %s2)
  br label %sbdone.31
sbdone.31:
  %t32 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t33 = extractvalue { i64, ptr } %t32, 0
  %t34 = extractvalue { i64, ptr } %t32, 1
  %t35 = mul i64 %t33, 1
  %t36 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t35)
  call void @llvm.memcpy.p0.p0.i64(ptr %t36, ptr %t34, i64 %t35, i1 false)
  %t37 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t38 = insertvalue { i64, ptr } %t37, ptr %t36, 1
  %t39 = load ptr, ptr %l23, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2egap(ptr %v0, ptr %s1, ptr %t39, { i64, ptr } %t38)
  br label %bb8
bb8:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d401, i32 0, i32 1) }, ptr %l28, !tbaa !27
  %t41 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t41, 0
  %t44 = extractvalue { i64, ptr } %t41, 1
  %t45 = mul i64 %t43, 1
  %t46 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t45)
  call void @llvm.memcpy.p0.p0.i64(ptr %t46, ptr %t44, i64 %t45, i1 false)
  %t47 = insertvalue { i64, ptr } undef, i64 %t43, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t46, 1
  store { i64, ptr } %t48, ptr %l4, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  br label %bb9
bb9:
  %t50 = load i32, ptr %l2
  %t52 = trunc i64 11 to i32
  %t53 = icmp eq i32 %t50, %t52
  br i1 %t53, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s3
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d402, i32 0, i32 1) }, ptr %l33, !tbaa !27
  %t55 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t55, ptr %l34, !tbaa !27
  %t56 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t57 = extractvalue { i64, ptr } %t56, 0
  store i64 %t57, ptr %l35, !tbaa !24
  %t58 = load i64, ptr %l35, !tbaa !24
  %t59 = mul i64 %t58, 1
  %t60 = call ptr @__olang_scope_alloc_zeroed(ptr %s3, i64 %t59)
  %t61 = insertvalue { i64, ptr } undef, i64 %t58, 0
  %t62 = insertvalue { i64, ptr } %t61, ptr %t60, 1
  store { i64, ptr } %t62, ptr %l36, !tbaa !27
  %t63 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !27
  %t65 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !27
  %t67 = load i64, ptr %l35, !tbaa !24
  %t68 = mul i64 %t67, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t64, ptr %t66, i64 %t68, i1 false)
  %t69 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t69, ptr %l5, !tbaa !27
  %t70 = load { i64, [4 x i64] }, ptr %l3
  %t72 = extractvalue { i64, [4 x i64] } %t70, 0
  %t73 = icmp eq i64 %t72, 3
  br i1 %t73, label %bb12, label %bb13
bb11:
  br label %bb32
bb12:
  %t75 = getelementptr { i64, [4 x i64] }, ptr %l3, i32 0, i32 1
  %t76 = getelementptr { i32, i32, i64, %"compiler/source:Span" }, ptr %t75, i32 0, i32 1
  %t77 = load i32, ptr %t76
  store i32 %t77, ptr %l6, !tbaa !23
  br label %bb14
bb13:
  br label %bb19
bb14:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t80 = load i32, ptr %l6, !tbaa !23
  %t83 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2econstText(ptr %v0, ptr %s3, ptr %t79, i32 %t80)
  store { i64, ptr } %t83, ptr %l42
  br label %bb15
bb15:
  %t84 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t85 = extractvalue { i64, ptr } %t84, 0
  %t86 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t87 = extractvalue { i64, ptr } %t86, 0
  store i64 %t87, ptr %l44, !tbaa !24
  %t89 = load i64, ptr %l44, !tbaa !24
  %t90 = icmp eq i64 %t85, %t89
  br i1 %t90, label %bb16, label %bb17
bb16:
  %t92 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !27
  %t94 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !27
  %t96 = load i64, ptr %l44, !tbaa !24
  %t97 = mul i64 %t96, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t93, ptr %t95, i64 %t97, i1 false)
  br label %bb18
bb17:
  %t98 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t98, ptr %l5, !tbaa !27
  br label %bb18
bb18:
  br label %bb24
bb19:
  br i1 true, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_15d05b44c0be072a_cdffff4fd774d83e)
  unreachable
bb24:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/emit:fnEm", ptr %t99, i32 0, i32 0
  %t102 = load ptr, ptr %t101, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s3, ptr %s3, ptr %t102, { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d403, i32 0, i32 1) }, { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d404, i32 0, i32 1) })
  br label %bb25
bb25:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = getelementptr %"compiler/emit:fnEm", ptr %t104, i32 0, i32 0
  %t107 = load ptr, ptr %t106, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s3, ptr %s3, ptr %t107, { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d405, i32 0, i32 1) }, { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d406, i32 0, i32 1) })
  br label %bb26
bb26:
  %t109 = load ptr, ptr %l0, !tbaa !29
  store ptr %t109, ptr %l50, !tbaa !29
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t111 = load %"compiler/source:Span", ptr %l1
  %t114 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elocated(ptr %v0, ptr %s3, ptr %s3, ptr %t110, %"compiler/source:Span" %t111, { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d407, i32 0, i32 1) })
  store { i64, ptr } %t114, ptr %l53
  br label %bb27
bb27:
  %t115 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d408, i32 0, i32 1) }, 1
  %t116 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d408, i32 0, i32 1) }, 0
  %t117 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t118 = extractvalue { i64, ptr } %t117, 1
  %t119 = extractvalue { i64, ptr } %t117, 0
  %t120 = add i64 %t116, %t119
  %t121 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d409, i32 0, i32 1) }, 1
  %t122 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d409, i32 0, i32 1) }, 0
  %t123 = add i64 %t120, %t122
  %t124 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t123)
  call void @olang_textcopy(ptr %t124, ptr %t115, i64 %t116)
  %t125 = getelementptr i8, ptr %t124, i64 %t116
  call void @olang_textcopy(ptr %t125, ptr %t118, i64 %t119)
  %t126 = getelementptr i8, ptr %t125, i64 %t119
  call void @olang_textcopy(ptr %t126, ptr %t121, i64 %t122)
  %t127 = insertvalue { i64, ptr } undef, i64 %t123, 0
  %t128 = insertvalue { i64, ptr } %t127, ptr %t124, 1
  %t130 = extractvalue { i64, ptr } %t128, 0
  %t131 = extractvalue { i64, ptr } %t128, 1
  %t132 = mul i64 %t130, 1
  %t133 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t132)
  call void @llvm.memcpy.p0.p0.i64(ptr %t133, ptr %t131, i64 %t132, i1 false)
  %t134 = insertvalue { i64, ptr } undef, i64 %t130, 0
  %t135 = insertvalue { i64, ptr } %t134, ptr %t133, 1
  %t136 = load ptr, ptr %l50, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s3, ptr %t136, { i64, ptr } %t135)
  br label %bb28
bb28:
  %t138 = load ptr, ptr %l0, !tbaa !29
  store ptr %t138, ptr %l56, !tbaa !29
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t141 = getelementptr %"compiler/emit:fnEm", ptr %t139, i32 0, i32 0
  %t142 = load ptr, ptr %t141, !tbaa !29
  %t143 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t146 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecstr(ptr %v0, ptr %s3, ptr %s3, ptr %t142, { i64, ptr } %t143)
  store { i64, ptr } %t146, ptr %l60
  br label %bb29
bb29:
  %t147 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d410, i32 0, i32 1) }, 1
  %t148 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d410, i32 0, i32 1) }, 0
  %t149 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t150 = extractvalue { i64, ptr } %t149, 1
  %t151 = extractvalue { i64, ptr } %t149, 0
  %t152 = add i64 %t148, %t151
  %t153 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d411, i32 0, i32 1) }, 1
  %t154 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d411, i32 0, i32 1) }, 0
  %t155 = add i64 %t152, %t154
  %t156 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t155)
  call void @olang_textcopy(ptr %t156, ptr %t147, i64 %t148)
  %t157 = getelementptr i8, ptr %t156, i64 %t148
  call void @olang_textcopy(ptr %t157, ptr %t150, i64 %t151)
  %t158 = getelementptr i8, ptr %t157, i64 %t151
  call void @olang_textcopy(ptr %t158, ptr %t153, i64 %t154)
  %t159 = insertvalue { i64, ptr } undef, i64 %t155, 0
  %t160 = insertvalue { i64, ptr } %t159, ptr %t156, 1
  %t162 = extractvalue { i64, ptr } %t160, 0
  %t163 = extractvalue { i64, ptr } %t160, 1
  %t164 = mul i64 %t162, 1
  %t165 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t164)
  call void @llvm.memcpy.p0.p0.i64(ptr %t165, ptr %t163, i64 %t164, i1 false)
  %t166 = insertvalue { i64, ptr } undef, i64 %t162, 0
  %t167 = insertvalue { i64, ptr } %t166, ptr %t165, 1
  %t168 = load ptr, ptr %l56, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s3, ptr %t168, { i64, ptr } %t167)
  br label %bb30
bb30:
  %t170 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s3, ptr %t170, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d412, i32 0, i32 1) })
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb32:
  %t172 = load i32, ptr %l2
  %t174 = trunc i64 10 to i32
  %t175 = icmp eq i32 %t172, %t174
  br i1 %t175, label %bb33, label %bb34
bb33:
  store %olang.scope zeroinitializer, ptr %s8
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d413, i32 0, i32 1) }, ptr %l66, !tbaa !27
  %t177 = load { i64, ptr }, ptr %l66, !tbaa !27
  store { i64, ptr } %t177, ptr %l67, !tbaa !27
  %t178 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t179 = extractvalue { i64, ptr } %t178, 0
  store i64 %t179, ptr %l68, !tbaa !24
  %t180 = load i64, ptr %l68, !tbaa !24
  %t181 = mul i64 %t180, 1
  %t182 = call ptr @__olang_scope_alloc_zeroed(ptr %s8, i64 %t181)
  %t183 = insertvalue { i64, ptr } undef, i64 %t180, 0
  %t184 = insertvalue { i64, ptr } %t183, ptr %t182, 1
  store { i64, ptr } %t184, ptr %l69, !tbaa !27
  %t185 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t186 = load ptr, ptr %t185, !tbaa !27
  %t187 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t188 = load ptr, ptr %t187, !tbaa !27
  %t189 = load i64, ptr %l68, !tbaa !24
  %t190 = mul i64 %t189, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t186, ptr %t188, i64 %t190, i1 false)
  %t191 = load { i64, ptr }, ptr %l69, !tbaa !27
  store { i64, ptr } %t191, ptr %l7, !tbaa !27
  %t192 = load { i64, [4 x i64] }, ptr %l3
  %t194 = extractvalue { i64, [4 x i64] } %t192, 0
  %t195 = icmp eq i64 %t194, 3
  br i1 %t195, label %bb35, label %bb36
bb34:
  br label %bb56
bb35:
  %t197 = getelementptr { i64, [4 x i64] }, ptr %l3, i32 0, i32 1
  %t198 = getelementptr { i32, i32, i64, %"compiler/source:Span" }, ptr %t197, i32 0, i32 1
  %t199 = load i32, ptr %t198
  store i32 %t199, ptr %l8, !tbaa !23
  br label %bb37
bb36:
  br label %bb42
bb37:
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t202 = load i32, ptr %l8, !tbaa !23
  %t205 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2econstText(ptr %v0, ptr %s8, ptr %t201, i32 %t202)
  store { i64, ptr } %t205, ptr %l75
  br label %bb38
bb38:
  %t206 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t207 = extractvalue { i64, ptr } %t206, 0
  %t208 = load { i64, ptr }, ptr %l75, !tbaa !27
  %t209 = extractvalue { i64, ptr } %t208, 0
  store i64 %t209, ptr %l77, !tbaa !24
  %t211 = load i64, ptr %l77, !tbaa !24
  %t212 = icmp eq i64 %t207, %t211
  br i1 %t212, label %bb39, label %bb40
bb39:
  %t214 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t215 = load ptr, ptr %t214, !tbaa !27
  %t216 = getelementptr { i64, ptr }, ptr %l75, i32 0, i32 1
  %t217 = load ptr, ptr %t216, !tbaa !27
  %t218 = load i64, ptr %l77, !tbaa !24
  %t219 = mul i64 %t218, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t215, ptr %t217, i64 %t219, i1 false)
  br label %bb41
bb40:
  %t220 = load { i64, ptr }, ptr %l75, !tbaa !27
  store { i64, ptr } %t220, ptr %l7, !tbaa !27
  br label %bb41
bb41:
  br label %bb47
bb42:
  br i1 true, label %bb43, label %bb44
bb43:
  br label %bb45
bb44:
  br label %bb46
bb45:
  br label %bb47
bb46:
  call void @__olang_check_failed(ptr @olang_loc_7b8962df1e5235eb_6d0c23ccefebcb3f)
  unreachable
bb47:
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t223 = getelementptr %"compiler/emit:fnEm", ptr %t221, i32 0, i32 0
  %t224 = load ptr, ptr %t223, !tbaa !29
  %t226 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2etraced(ptr %v0, ptr %t224)
  store i1 %t226, ptr %l81
  br label %bb48
bb48:
  %t227 = load i1, ptr %l81, !tbaa !21
  br i1 %t227, label %bb49, label %bb50
bb49:
  store { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d414, i32 0, i32 1) }, ptr %l82, !tbaa !27
  br label %bb51
bb50:
  store { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d415, i32 0, i32 1) }, ptr %l82, !tbaa !27
  br label %bb51
bb51:
  %t228 = load { i64, ptr }, ptr %l82, !tbaa !27
  store { i64, ptr } %t228, ptr %l9, !tbaa !27
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t231 = getelementptr %"compiler/emit:fnEm", ptr %t229, i32 0, i32 0
  %t232 = load ptr, ptr %t231, !tbaa !29
  %t233 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t234 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t235 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d416, i32 0, i32 1) }, 1
  %t236 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d416, i32 0, i32 1) }, 0
  %t238 = extractvalue { i64, ptr } %t234, 1
  %t239 = extractvalue { i64, ptr } %t234, 0
  %t240 = add i64 %t236, %t239
  %t241 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d417, i32 0, i32 1) }, 1
  %t242 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d417, i32 0, i32 1) }, 0
  %t243 = add i64 %t240, %t242
  %t244 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t243)
  call void @olang_textcopy(ptr %t244, ptr %t235, i64 %t236)
  %t245 = getelementptr i8, ptr %t244, i64 %t236
  call void @olang_textcopy(ptr %t245, ptr %t238, i64 %t239)
  %t246 = getelementptr i8, ptr %t245, i64 %t239
  call void @olang_textcopy(ptr %t246, ptr %t241, i64 %t242)
  %t247 = insertvalue { i64, ptr } undef, i64 %t243, 0
  %t248 = insertvalue { i64, ptr } %t247, ptr %t244, 1
  %t250 = extractvalue { i64, ptr } %t248, 0
  %t251 = extractvalue { i64, ptr } %t248, 1
  %t252 = mul i64 %t250, 1
  %t253 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t252)
  call void @llvm.memcpy.p0.p0.i64(ptr %t253, ptr %t251, i64 %t252, i1 false)
  %t254 = insertvalue { i64, ptr } undef, i64 %t250, 0
  %t255 = insertvalue { i64, ptr } %t254, ptr %t253, 1
  %t256 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %t256, ptr %s8, ptr %t232, { i64, ptr } %t233, { i64, ptr } %t255)
  br label %bb52
bb52:
  %t260 = load ptr, ptr %l0, !tbaa !29
  store ptr %t260, ptr %l89, !tbaa !29
  %t261 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t261, ptr %l90, !tbaa !27
  %t262 = load ptr, ptr %l0, !tbaa !29
  %t263 = load %"compiler/source:Span", ptr %l1
  %t264 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t265 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d418, i32 0, i32 1) }, 1
  %t266 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d418, i32 0, i32 1) }, 0
  %t268 = extractvalue { i64, ptr } %t264, 1
  %t269 = extractvalue { i64, ptr } %t264, 0
  %t270 = add i64 %t266, %t269
  %t271 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d419, i32 0, i32 1) }, 1
  %t272 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d419, i32 0, i32 1) }, 0
  %t273 = add i64 %t270, %t272
  %t274 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t273)
  call void @olang_textcopy(ptr %t274, ptr %t265, i64 %t266)
  %t275 = getelementptr i8, ptr %t274, i64 %t266
  call void @olang_textcopy(ptr %t275, ptr %t268, i64 %t269)
  %t276 = getelementptr i8, ptr %t275, i64 %t269
  call void @olang_textcopy(ptr %t276, ptr %t271, i64 %t272)
  %t277 = insertvalue { i64, ptr } undef, i64 %t273, 0
  %t278 = insertvalue { i64, ptr } %t277, ptr %t274, 1
  %t280 = extractvalue { i64, ptr } %t278, 0
  %t281 = extractvalue { i64, ptr } %t278, 1
  %t282 = mul i64 %t280, 1
  %t283 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t282)
  call void @llvm.memcpy.p0.p0.i64(ptr %t283, ptr %t281, i64 %t282, i1 false)
  %t284 = insertvalue { i64, ptr } undef, i64 %t280, 0
  %t285 = insertvalue { i64, ptr } %t284, ptr %t283, 1
  %t289 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elocated(ptr %v0, ptr %s8, ptr %s8, ptr %t262, %"compiler/source:Span" %t263, { i64, ptr } %t285)
  store { i64, ptr } %t289, ptr %l96
  br label %bb53
bb53:
  %t290 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d420, i32 0, i32 1) }, 1
  %t291 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d420, i32 0, i32 1) }, 0
  %t292 = load { i64, ptr }, ptr %l90, !tbaa !27
  %t293 = extractvalue { i64, ptr } %t292, 1
  %t294 = extractvalue { i64, ptr } %t292, 0
  %t295 = add i64 %t291, %t294
  %t296 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d421, i32 0, i32 1) }, 1
  %t297 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d421, i32 0, i32 1) }, 0
  %t298 = add i64 %t295, %t297
  %t299 = load { i64, ptr }, ptr %l96, !tbaa !27
  %t300 = extractvalue { i64, ptr } %t299, 1
  %t301 = extractvalue { i64, ptr } %t299, 0
  %t302 = add i64 %t298, %t301
  %t303 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d422, i32 0, i32 1) }, 1
  %t304 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d422, i32 0, i32 1) }, 0
  %t305 = add i64 %t302, %t304
  %t306 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t305)
  call void @olang_textcopy(ptr %t306, ptr %t290, i64 %t291)
  %t307 = getelementptr i8, ptr %t306, i64 %t291
  call void @olang_textcopy(ptr %t307, ptr %t293, i64 %t294)
  %t308 = getelementptr i8, ptr %t307, i64 %t294
  call void @olang_textcopy(ptr %t308, ptr %t296, i64 %t297)
  %t309 = getelementptr i8, ptr %t308, i64 %t297
  call void @olang_textcopy(ptr %t309, ptr %t300, i64 %t301)
  %t310 = getelementptr i8, ptr %t309, i64 %t301
  call void @olang_textcopy(ptr %t310, ptr %t303, i64 %t304)
  %t311 = insertvalue { i64, ptr } undef, i64 %t305, 0
  %t312 = insertvalue { i64, ptr } %t311, ptr %t306, 1
  %t314 = extractvalue { i64, ptr } %t312, 0
  %t315 = extractvalue { i64, ptr } %t312, 1
  %t316 = mul i64 %t314, 1
  %t317 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t316)
  call void @llvm.memcpy.p0.p0.i64(ptr %t317, ptr %t315, i64 %t316, i1 false)
  %t318 = insertvalue { i64, ptr } undef, i64 %t314, 0
  %t319 = insertvalue { i64, ptr } %t318, ptr %t317, 1
  %t320 = load ptr, ptr %l89, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s8, ptr %t320, { i64, ptr } %t319)
  br label %bb54
bb54:
  %t322 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s8, ptr %t322, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d423, i32 0, i32 1) })
  br label %bb55
bb55:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb56:
  %t324 = load { i64, [4 x i64] }, ptr %l3
  %t326 = extractvalue { i64, [4 x i64] } %t324, 0
  %t327 = icmp eq i64 %t326, 0
  br i1 %t327, label %bb57, label %bb58
bb57:
  br label %bb59
bb58:
  br label %bb63
bb59:
  store %olang.scope zeroinitializer, ptr %s14
  %t329 = load ptr, ptr %l0, !tbaa !29
  %t331 = getelementptr %"compiler/emit:fnEm", ptr %t329, i32 0, i32 0
  %t332 = load ptr, ptr %t331, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %s14, ptr %t332, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d424, i32 0, i32 1) })
  br label %bb60
bb60:
  %t334 = load ptr, ptr %l0, !tbaa !29
  store ptr %t334, ptr %l104, !tbaa !29
  %t335 = load ptr, ptr %l0, !tbaa !29
  %t336 = load %"compiler/source:Span", ptr %l1
  %t337 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t338 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d425, i32 0, i32 1) }, 1
  %t339 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d425, i32 0, i32 1) }, 0
  %t341 = extractvalue { i64, ptr } %t337, 1
  %t342 = extractvalue { i64, ptr } %t337, 0
  %t343 = add i64 %t339, %t342
  %t344 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d426, i32 0, i32 1) }, 1
  %t345 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d426, i32 0, i32 1) }, 0
  %t346 = add i64 %t343, %t345
  %t347 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t346)
  call void @olang_textcopy(ptr %t347, ptr %t338, i64 %t339)
  %t348 = getelementptr i8, ptr %t347, i64 %t339
  call void @olang_textcopy(ptr %t348, ptr %t341, i64 %t342)
  %t349 = getelementptr i8, ptr %t348, i64 %t342
  call void @olang_textcopy(ptr %t349, ptr %t344, i64 %t345)
  %t350 = insertvalue { i64, ptr } undef, i64 %t346, 0
  %t351 = insertvalue { i64, ptr } %t350, ptr %t347, 1
  %t353 = extractvalue { i64, ptr } %t351, 0
  %t354 = extractvalue { i64, ptr } %t351, 1
  %t355 = mul i64 %t353, 1
  %t356 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t355)
  call void @llvm.memcpy.p0.p0.i64(ptr %t356, ptr %t354, i64 %t355, i1 false)
  %t357 = insertvalue { i64, ptr } undef, i64 %t353, 0
  %t358 = insertvalue { i64, ptr } %t357, ptr %t356, 1
  %t362 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elocated(ptr %v0, ptr %s14, ptr %s14, ptr %t335, %"compiler/source:Span" %t336, { i64, ptr } %t358)
  store { i64, ptr } %t362, ptr %l110
  br label %bb61
bb61:
  %t363 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d427, i32 0, i32 1) }, 1
  %t364 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d427, i32 0, i32 1) }, 0
  %t365 = load { i64, ptr }, ptr %l110, !tbaa !27
  %t366 = extractvalue { i64, ptr } %t365, 1
  %t367 = extractvalue { i64, ptr } %t365, 0
  %t368 = add i64 %t364, %t367
  %t369 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d428, i32 0, i32 1) }, 1
  %t370 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d428, i32 0, i32 1) }, 0
  %t371 = add i64 %t368, %t370
  %t372 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t371)
  call void @olang_textcopy(ptr %t372, ptr %t363, i64 %t364)
  %t373 = getelementptr i8, ptr %t372, i64 %t364
  call void @olang_textcopy(ptr %t373, ptr %t366, i64 %t367)
  %t374 = getelementptr i8, ptr %t373, i64 %t367
  call void @olang_textcopy(ptr %t374, ptr %t369, i64 %t370)
  %t375 = insertvalue { i64, ptr } undef, i64 %t371, 0
  %t376 = insertvalue { i64, ptr } %t375, ptr %t372, 1
  %t378 = extractvalue { i64, ptr } %t376, 0
  %t379 = extractvalue { i64, ptr } %t376, 1
  %t380 = mul i64 %t378, 1
  %t381 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t380)
  call void @llvm.memcpy.p0.p0.i64(ptr %t381, ptr %t379, i64 %t380, i1 false)
  %t382 = insertvalue { i64, ptr } undef, i64 %t378, 0
  %t383 = insertvalue { i64, ptr } %t382, ptr %t381, 1
  %t384 = load ptr, ptr %l104, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s14, ptr %t384, { i64, ptr } %t383)
  br label %bb62
bb62:
  call void @__olang_scope_close(ptr %s14)
  br label %bb75
bb63:
  br i1 true, label %bb64, label %bb65
bb64:
  br label %bb66
bb65:
  br label %bb74
bb66:
  store %olang.scope zeroinitializer, ptr %s17
  %t386 = load ptr, ptr %l0, !tbaa !29
  %t388 = getelementptr %"compiler/emit:fnEm", ptr %t386, i32 0, i32 0
  %t389 = load ptr, ptr %t388, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %s17, ptr %t389, { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d429, i32 0, i32 1) })
  br label %bb67
bb67:
  %t391 = load ptr, ptr %l0, !tbaa !29
  %t392 = load { i64, [4 x i64] }, ptr %l3
  %t395 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eotype(ptr %v0, ptr %t391, { i64, [4 x i64] } %t392)
  store i32 %t395, ptr %l117
  br label %bb68
bb68:
  %t396 = load i32, ptr %l117, !tbaa !23
  store i32 %t396, ptr %l10, !tbaa !23
  %t397 = load ptr, ptr %l0, !tbaa !29
  %t398 = load { i64, [4 x i64] }, ptr %l3
  %t399 = load i32, ptr %l10, !tbaa !23
  %t403 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s17, ptr %t397, { i64, [4 x i64] } %t398, i32 %t399)
  store { i64, ptr } %t403, ptr %l121
  br label %bb69
bb69:
  %t404 = load { i64, ptr }, ptr %l121, !tbaa !27
  %t405 = load ptr, ptr %l0, !tbaa !29
  %t407 = load i32, ptr %l10, !tbaa !23
  %t411 = call { { i64, ptr }, { i64, ptr } } @compiler_2femit_2ecompiler_2femit_3afnEm_2earrayParts(ptr %v0, ptr %s17, ptr %s17, ptr %t405, { i64, ptr } %t404, i32 %t407)
  store { { i64, ptr }, { i64, ptr } } %t411, ptr %l125
  br label %bb70
bb70:
  %t412 = load { { i64, ptr }, { i64, ptr } }, ptr %l125
  store { { i64, ptr }, { i64, ptr } } %t412, ptr %l12
  %t413 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l12, i32 0, i32 0
  %t414 = load { i64, ptr }, ptr %t413, !tbaa !27
  store { i64, ptr } %t414, ptr %l126, !tbaa !27
  %t415 = load { i64, ptr }, ptr %l126, !tbaa !27
  %t416 = extractvalue { i64, ptr } %t415, 0
  store i64 %t416, ptr %l127, !tbaa !24
  %t417 = load i64, ptr %l127, !tbaa !24
  %t418 = mul i64 %t417, 1
  %t419 = call ptr @__olang_scope_alloc_zeroed(ptr %s17, i64 %t418)
  %t420 = insertvalue { i64, ptr } undef, i64 %t417, 0
  %t421 = insertvalue { i64, ptr } %t420, ptr %t419, 1
  store { i64, ptr } %t421, ptr %l128, !tbaa !27
  %t422 = getelementptr { i64, ptr }, ptr %l128, i32 0, i32 1
  %t423 = load ptr, ptr %t422, !tbaa !27
  %t424 = getelementptr { i64, ptr }, ptr %l126, i32 0, i32 1
  %t425 = load ptr, ptr %t424, !tbaa !27
  %t426 = load i64, ptr %l127, !tbaa !24
  %t427 = mul i64 %t426, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t423, ptr %t425, i64 %t427, i1 false)
  %t428 = load { i64, ptr }, ptr %l128, !tbaa !27
  %t429 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l12, i32 0, i32 1
  %t430 = load { i64, ptr }, ptr %t429, !tbaa !27
  store { i64, ptr } %t430, ptr %l129, !tbaa !27
  %t431 = load { i64, ptr }, ptr %l129, !tbaa !27
  %t432 = extractvalue { i64, ptr } %t431, 0
  store i64 %t432, ptr %l130, !tbaa !24
  %t433 = load i64, ptr %l130, !tbaa !24
  %t434 = mul i64 %t433, 1
  %t435 = call ptr @__olang_scope_alloc_zeroed(ptr %s17, i64 %t434)
  %t436 = insertvalue { i64, ptr } undef, i64 %t433, 0
  %t437 = insertvalue { i64, ptr } %t436, ptr %t435, 1
  store { i64, ptr } %t437, ptr %l131, !tbaa !27
  %t438 = getelementptr { i64, ptr }, ptr %l131, i32 0, i32 1
  %t439 = load ptr, ptr %t438, !tbaa !27
  %t440 = getelementptr { i64, ptr }, ptr %l129, i32 0, i32 1
  %t441 = load ptr, ptr %t440, !tbaa !27
  %t442 = load i64, ptr %l130, !tbaa !24
  %t443 = mul i64 %t442, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t439, ptr %t441, i64 %t443, i1 false)
  %t444 = load { i64, ptr }, ptr %l131, !tbaa !27
  %t445 = load ptr, ptr %l0, !tbaa !29
  %t451 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2epair(ptr %v0, ptr %s17, ptr %s17, ptr %s17, ptr %t445, { i64, ptr } %t444, { i64, ptr } %t428)
  store { i64, ptr } %t451, ptr %l135
  br label %bb71
bb71:
  %t452 = load { i64, ptr }, ptr %l135, !tbaa !27
  store { i64, ptr } %t452, ptr %l15, !tbaa !27
  %t453 = load ptr, ptr %l0, !tbaa !29
  store ptr %t453, ptr %l136, !tbaa !29
  %t454 = load ptr, ptr %l0, !tbaa !29
  %t455 = load %"compiler/source:Span", ptr %l1
  %t456 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t457 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d430, i32 0, i32 1) }, 1
  %t458 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d430, i32 0, i32 1) }, 0
  %t460 = extractvalue { i64, ptr } %t456, 1
  %t461 = extractvalue { i64, ptr } %t456, 0
  %t462 = add i64 %t458, %t461
  %t463 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d431, i32 0, i32 1) }, 1
  %t464 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d431, i32 0, i32 1) }, 0
  %t465 = add i64 %t462, %t464
  %t466 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t465)
  call void @olang_textcopy(ptr %t466, ptr %t457, i64 %t458)
  %t467 = getelementptr i8, ptr %t466, i64 %t458
  call void @olang_textcopy(ptr %t467, ptr %t460, i64 %t461)
  %t468 = getelementptr i8, ptr %t467, i64 %t461
  call void @olang_textcopy(ptr %t468, ptr %t463, i64 %t464)
  %t469 = insertvalue { i64, ptr } undef, i64 %t465, 0
  %t470 = insertvalue { i64, ptr } %t469, ptr %t466, 1
  %t472 = extractvalue { i64, ptr } %t470, 0
  %t473 = extractvalue { i64, ptr } %t470, 1
  %t474 = mul i64 %t472, 1
  %t475 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t474)
  call void @llvm.memcpy.p0.p0.i64(ptr %t475, ptr %t473, i64 %t474, i1 false)
  %t476 = insertvalue { i64, ptr } undef, i64 %t472, 0
  %t477 = insertvalue { i64, ptr } %t476, ptr %t475, 1
  %t481 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elocated(ptr %v0, ptr %s17, ptr %s17, ptr %t454, %"compiler/source:Span" %t455, { i64, ptr } %t477)
  store { i64, ptr } %t481, ptr %l142
  br label %bb72
bb72:
  %t482 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t483 = extractvalue { i64, ptr } { i64 41, ptr getelementptr inbounds (<{ i64, [41 x i8] }>, ptr @.d432, i32 0, i32 1) }, 1
  %t484 = extractvalue { i64, ptr } { i64 41, ptr getelementptr inbounds (<{ i64, [41 x i8] }>, ptr @.d432, i32 0, i32 1) }, 0
  %t485 = load { i64, ptr }, ptr %l142, !tbaa !27
  %t486 = extractvalue { i64, ptr } %t485, 1
  %t487 = extractvalue { i64, ptr } %t485, 0
  %t488 = add i64 %t484, %t487
  %t489 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d433, i32 0, i32 1) }, 1
  %t490 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d433, i32 0, i32 1) }, 0
  %t491 = add i64 %t488, %t490
  %t493 = extractvalue { i64, ptr } %t482, 1
  %t494 = extractvalue { i64, ptr } %t482, 0
  %t495 = add i64 %t491, %t494
  %t496 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d434, i32 0, i32 1) }, 1
  %t497 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d434, i32 0, i32 1) }, 0
  %t498 = add i64 %t495, %t497
  %t499 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t498)
  call void @olang_textcopy(ptr %t499, ptr %t483, i64 %t484)
  %t500 = getelementptr i8, ptr %t499, i64 %t484
  call void @olang_textcopy(ptr %t500, ptr %t486, i64 %t487)
  %t501 = getelementptr i8, ptr %t500, i64 %t487
  call void @olang_textcopy(ptr %t501, ptr %t489, i64 %t490)
  %t502 = getelementptr i8, ptr %t501, i64 %t490
  call void @olang_textcopy(ptr %t502, ptr %t493, i64 %t494)
  %t503 = getelementptr i8, ptr %t502, i64 %t494
  call void @olang_textcopy(ptr %t503, ptr %t496, i64 %t497)
  %t504 = insertvalue { i64, ptr } undef, i64 %t498, 0
  %t505 = insertvalue { i64, ptr } %t504, ptr %t499, 1
  %t507 = extractvalue { i64, ptr } %t505, 0
  %t508 = extractvalue { i64, ptr } %t505, 1
  %t509 = mul i64 %t507, 1
  %t510 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t509)
  call void @llvm.memcpy.p0.p0.i64(ptr %t510, ptr %t508, i64 %t509, i1 false)
  %t511 = insertvalue { i64, ptr } undef, i64 %t507, 0
  %t512 = insertvalue { i64, ptr } %t511, ptr %t510, 1
  %t513 = load ptr, ptr %l136, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s17, ptr %t513, { i64, ptr } %t512)
  br label %bb73
bb73:
  call void @__olang_scope_close(ptr %s17)
  br label %bb75
bb74:
  call void @__olang_check_failed(ptr @olang_loc_9d518c27a973a5b0_d4b76855814c5604)
  unreachable
bb75:
  %t515 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s0, ptr %t515, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d435, i32 0, i32 1) })
  br label %bb76
bb76:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3afnEm_2efindDirect(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca %"compiler/mir:BasicBlock"
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca { i64, [21 x i64] }
  %l16 = alloca i32
  %l17 = alloca i64
  %l18 = alloca { i64, [21 x i64] }
  %l19 = alloca { i64, [15 x i64] }
  %l20 = alloca { i64, [1 x i64] }
  %l21 = alloca i1
  %l22 = alloca { i64, [21 x i64] }
  %l23 = alloca i32
  %l24 = alloca i1
  %l28 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l32 = alloca i32
  %l41 = alloca { i64, ptr }
  %l45 = alloca i64
  %l50 = alloca i64
  %l53 = alloca i64
  %l73 = alloca { i64, [21 x i64] }
  %l74 = alloca { i64, [21 x i64] }
  %l82 = alloca %"compiler/mir:ScopeInfo"
  %l94 = alloca i1
  %l95 = alloca ptr
  %l98 = alloca { i64, [21 x i64] }
  %l101 = alloca i1
  %l111 = alloca { i64, [21 x i64] }
  %l112 = alloca i1
  %l113 = alloca { i64, [21 x i64] }
  %l116 = alloca i1
  %l123 = alloca i1
  %l127 = alloca { i64, [21 x i64] }
  %l128 = alloca i1
  %l129 = alloca { i64, [21 x i64] }
  %l137 = alloca i1
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s10 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/mir:Fn", ptr %t4, i32 0, i32 9
  store ptr %t6, ptr %l1, !tbaa !29
  store i64 0, ptr %l2, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t8 = load ptr, ptr %l1, !tbaa !29
  %t9 = load i64, ptr %l2, !tbaa !24
  %t12 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBasicBlock_3e_2eRu_H05f2a0ad75f6ffeece9ab76b4dcd7cb0(ptr %v0, ptr %t8, i64 %t9)
  %t13 = extractvalue { i32, { i64, ptr } } %t12, 1
  %t14 = extractvalue { i32, { i64, ptr } } %t12, 0
  store i32 %t14, ptr %l32
  %t15 = icmp ne i32 %t14, 0
  br i1 %t15, label %bb3, label %ok.16
ok.16:
  store { i64, ptr } %t13, ptr %l31
  br label %bb2
bb2:
  %t17 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t17, ptr %l28, !tbaa !27
  br label %bb7
bb3:
  %t18 = load i32, ptr %l32, !tbaa !23
  %t19 = ashr i32 %t18, 16
  %t21 = icmp eq i32 %t19, 1
  br i1 %t21, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  call void @__olang_check_failed(ptr @olang_loc_8a0f087481b95ab0_a13f080fe7b316d4)
  unreachable
bb6:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %bb96
bb7:
  %t23 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t23, ptr %l3, !tbaa !27
  %t24 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  store i64 %t26, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t28 = load i64, ptr %l5, !tbaa !24
  %t29 = load i64, ptr %l4, !tbaa !24
  %t32 = icmp slt i64 %t28, %t29
  %t34 = xor i1 %t32, true
  br i1 %t34, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb94
bb10:
  br label %bb11
bb11:
  %t36 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t36, ptr %l41, !tbaa !27
  %t37 = load i64, ptr %l5, !tbaa !24
  %t39 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !27
  %t41 = getelementptr %"compiler/mir:BasicBlock", ptr %t40, i64 %t37
  %t42 = load %"compiler/mir:BasicBlock", ptr %t41
  store %"compiler/mir:BasicBlock" %t42, ptr %l6
  %t44 = getelementptr %"compiler/mir:BasicBlock", ptr %l6, i32 0, i32 0
  %t46 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aStmt_3e_2eLen_3ccompiler_2fmir_3aStmt_3e(ptr %v0, ptr %t44)
  store i64 %t46, ptr %l45
  br label %bb12
bb12:
  %t47 = load i64, ptr %l45, !tbaa !24
  store i64 %t47, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  %t48 = load i64, ptr %l7, !tbaa !24
  store i64 %t48, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t50 = load i64, ptr %l9, !tbaa !24
  %t51 = load i64, ptr %l8, !tbaa !24
  %t54 = icmp sgt i64 %t50, %t51
  br i1 %t54, label %bb13, label %bb14
bb13:
  %t56 = load i64, ptr %l10, !tbaa !24
  %t58 = icmp sgt i64 %t56, 0
  br i1 %t58, label %bb15, label %bb16
bb14:
  store i64 0, ptr %l50, !tbaa !24
  br label %bb18
bb15:
  %t60 = load i64, ptr %l9, !tbaa !24
  %t61 = load i64, ptr %l8, !tbaa !24
  %t64 = sub i64 %t60, %t61
  %t65 = load i64, ptr %l10, !tbaa !24
  %t68 = add i64 %t64, %t65
  %t70 = sub i64 %t68, 1
  %t71 = load i64, ptr %l10, !tbaa !24
  %t74 = sdiv i64 %t70, %t71
  store i64 %t74, ptr %l53, !tbaa !24
  br label %bb17
bb16:
  store i64 0, ptr %l53, !tbaa !24
  br label %bb17
bb17:
  %t76 = load i64, ptr %l53, !tbaa !24
  store i64 %t76, ptr %l50, !tbaa !24
  br label %bb18
bb18:
  %t77 = load i64, ptr %l50, !tbaa !24
  store i64 %t77, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb19
bb19:
  store %olang.scope zeroinitializer, ptr %s5
  %t78 = load i64, ptr %l12, !tbaa !24
  %t79 = load i64, ptr %l11, !tbaa !24
  %t82 = icmp slt i64 %t78, %t79
  %t84 = xor i1 %t82, true
  br i1 %t84, label %bb20, label %bb21
bb20:
  call void @__olang_scope_close(ptr %s5)
  br label %bb92
bb21:
  br label %bb22
bb22:
  %t86 = load i64, ptr %l8, !tbaa !24
  %t87 = load i64, ptr %l12, !tbaa !24
  %t88 = load i64, ptr %l10, !tbaa !24
  %t91 = mul i64 %t87, %t88
  %t94 = add i64 %t86, %t91
  store i64 %t94, ptr %l13, !tbaa !24
  store i64 -1, ptr %l14, !tbaa !24
  %t96 = getelementptr %"compiler/mir:BasicBlock", ptr %l6, i32 0, i32 0
  %t97 = load i64, ptr %l13, !tbaa !24
  %t100 = call { i64, [21 x i64] } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aStmt_3e_2eAt_3ccompiler_2fmir_3aStmt_3e(ptr %v0, ptr %t96, i64 %t97)
  store { i64, [21 x i64] } %t100, ptr %l73
  br label %bb23
bb23:
  call void @llvm.memmove.p0.p0.i64(ptr %l15, ptr %l73, i64 176, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l74, ptr %l15, i64 176, i1 false)
  %t101 = load { i64, [21 x i64] }, ptr %l74
  %t102 = extractvalue { i64, [21 x i64] } %t101, 0
  %t103 = icmp eq i64 %t102, 3
  br i1 %t103, label %bb24, label %bb25
bb24:
  %t105 = getelementptr { i64, [21 x i64] }, ptr %l15, i32 0, i32 1
  %t106 = getelementptr { %"compiler/source:Span", i32 }, ptr %t105, i32 0, i32 1
  %t107 = load i32, ptr %t106
  store i32 %t107, ptr %l16, !tbaa !23
  br label %bb26
bb25:
  br label %bb31
bb26:
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = getelementptr %"compiler/emit:fnEm", ptr %t109, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !29
  %t114 = getelementptr %"compiler/mir:Fn", ptr %t112, i32 0, i32 8
  %t115 = load i32, ptr %l16, !tbaa !23
  %t117 = sext i32 %t115 to i64
  %t120 = call %"compiler/mir:ScopeInfo" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeInfo_3e_2eAt_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %t114, i64 %t117)
  store %"compiler/mir:ScopeInfo" %t120, ptr %l82
  br label %bb27
bb27:
  %t121 = getelementptr %"compiler/mir:ScopeInfo", ptr %l82, i32 0, i32 0
  %t122 = load i32, ptr %t121
  %t124 = trunc i64 6 to i32
  %t125 = icmp eq i32 %t122, %t124
  br i1 %t125, label %bb28, label %bb29
bb28:
  %t127 = load i32, ptr %l16, !tbaa !23
  %t129 = sext i32 %t127 to i64
  store i64 %t129, ptr %l14, !tbaa !24
  br label %bb30
bb29:
  br label %bb30
bb30:
  br label %bb36
bb31:
  br i1 true, label %bb32, label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb36
bb35:
  call void @__olang_check_failed(ptr @olang_loc_9d64128d60439a41_20f9e6973a71ad85)
  unreachable
bb36:
  %t131 = load i64, ptr %l14, !tbaa !24
  %t133 = icmp slt i64 %t131, 0
  br i1 %t133, label %bb37, label %bb38
bb37:
  call void @__olang_scope_close(ptr %s5)
  br label %bb91
bb38:
  br label %bb39
bb39:
  %t135 = load i64, ptr %l13, !tbaa !24
  %t137 = add i64 %t135, 1
  store i64 %t137, ptr %l17, !tbaa !24
  br label %bb40
bb40:
  store %olang.scope zeroinitializer, ptr %s10
  %t139 = load i64, ptr %l17, !tbaa !24
  %t140 = load i64, ptr %l7, !tbaa !24
  %t143 = icmp slt i64 %t139, %t140
  br i1 %t143, label %bb41, label %bb42
bb41:
  %t145 = load ptr, ptr %l0, !tbaa !29
  store ptr %t145, ptr %l95, !tbaa !29
  %t146 = getelementptr %"compiler/mir:BasicBlock", ptr %l6, i32 0, i32 0
  %t147 = load i64, ptr %l17, !tbaa !24
  %t150 = call { i64, [21 x i64] } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aStmt_3e_2eAt_3ccompiler_2fmir_3aStmt_3e(ptr %v0, ptr %t146, i64 %t147)
  store { i64, [21 x i64] } %t150, ptr %l98
  br label %bb43
bb42:
  store i1 false, ptr %l94, !tbaa !21
  br label %bb45
bb43:
  %t151 = load { i64, [21 x i64] }, ptr %l98
  %t152 = call ptr @__olang_scope_alloc_a(ptr %s10, i64 176, i64 8)
  store { i64, [21 x i64] } %t151, ptr %t152
  %t153 = load i64, ptr %l14, !tbaa !24
  %t154 = load ptr, ptr %l95, !tbaa !29
  %t157 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2eplainWrite(ptr %v0, ptr %s10, ptr %t154, ptr %t152, i64 %t153)
  store i1 %t157, ptr %l101
  br label %bb44
bb44:
  %t158 = load i1, ptr %l101, !tbaa !21
  store i1 %t158, ptr %l94, !tbaa !21
  br label %bb45
bb45:
  %t159 = load i1, ptr %l94, !tbaa !21
  %t160 = xor i1 %t159, true
  br i1 %t160, label %bb46, label %bb47
bb46:
  call void @__olang_scope_close(ptr %s10)
  br label %bb50
bb47:
  br label %bb48
bb48:
  %t162 = load i64, ptr %l17, !tbaa !24
  %t164 = add i64 %t162, 1
  store i64 %t164, ptr %l17, !tbaa !24
  call void @__olang_scope_close(ptr %s10)
  br label %bb49
bb49:
  br label %bb40
bb50:
  %t166 = load i64, ptr %l17, !tbaa !24
  %t168 = add i64 %t166, 1
  %t169 = load i64, ptr %l7, !tbaa !24
  %t172 = icmp sge i64 %t168, %t169
  br i1 %t172, label %bb51, label %bb52
bb51:
  call void @__olang_scope_close(ptr %s5)
  br label %bb91
bb52:
  br label %bb53
bb53:
  %t174 = getelementptr %"compiler/mir:BasicBlock", ptr %l6, i32 0, i32 0
  %t175 = load i64, ptr %l17, !tbaa !24
  %t178 = call { i64, [21 x i64] } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aStmt_3e_2eAt_3ccompiler_2fmir_3aStmt_3e(ptr %v0, ptr %t174, i64 %t175)
  store { i64, [21 x i64] } %t178, ptr %l111
  br label %bb54
bb54:
  call void @llvm.memmove.p0.p0.i64(ptr %l18, ptr %l111, i64 176, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l113, ptr %l18, i64 176, i1 false)
  %t179 = load { i64, [21 x i64] }, ptr %l113
  %t180 = extractvalue { i64, [21 x i64] } %t179, 0
  %t181 = icmp eq i64 %t180, 0
  br i1 %t181, label %bb55, label %bb56
bb55:
  %t183 = getelementptr { i64, [21 x i64] }, ptr %l18, i32 0, i32 1
  %t184 = getelementptr { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } }, ptr %t183, i32 0, i32 2
  %t185 = load { i64, [15 x i64] }, ptr %t184
  store { i64, [15 x i64] } %t185, ptr %l19
  br label %bb57
bb56:
  br label %bb68
bb57:
  %t187 = load { i64, [15 x i64] }, ptr %l19
  %t189 = extractvalue { i64, [15 x i64] } %t187, 0
  %t190 = icmp eq i64 %t189, 12
  br i1 %t190, label %bb58, label %bb59
bb58:
  %t192 = getelementptr { i64, [15 x i64] }, ptr %l19, i32 0, i32 1
  %t193 = getelementptr { { i64, [1 x i64] }, { i64, [1 x i64] }, i32 }, ptr %t192, i32 0, i32 0
  %t194 = load { i64, [1 x i64] }, ptr %t193
  store { i64, [1 x i64] } %t194, ptr %l20
  br label %bb60
bb59:
  br label %bb62
bb60:
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t197 = load { i64, [1 x i64] }, ptr %l20
  %t198 = load i64, ptr %l14, !tbaa !24
  %t202 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2erefIs(ptr %v0, ptr %t196, { i64, [1 x i64] } %t197, i64 %t198)
  store i1 %t202, ptr %l123
  br label %bb61
bb61:
  %t203 = load i1, ptr %l123, !tbaa !21
  store i1 %t203, ptr %l116, !tbaa !21
  br label %bb67
bb62:
  br i1 true, label %bb63, label %bb64
bb63:
  br label %bb65
bb64:
  br label %bb66
bb65:
  store i1 false, ptr %l116, !tbaa !21
  br label %bb67
bb66:
  call void @__olang_check_failed(ptr @olang_loc_28dd7919903bc2a_4577237eccb57ce)
  unreachable
bb67:
  %t204 = load i1, ptr %l116, !tbaa !21
  store i1 %t204, ptr %l112, !tbaa !21
  br label %bb73
bb68:
  br i1 true, label %bb69, label %bb70
bb69:
  br label %bb71
bb70:
  br label %bb72
bb71:
  store i1 false, ptr %l112, !tbaa !21
  br label %bb73
bb72:
  call void @__olang_check_failed(ptr @olang_loc_6846df2bf697eaeb_3c0ad43c6c9a3c0f)
  unreachable
bb73:
  %t205 = load i1, ptr %l112, !tbaa !21
  store i1 %t205, ptr %l21, !tbaa !21
  %t206 = getelementptr %"compiler/mir:BasicBlock", ptr %l6, i32 0, i32 0
  %t207 = load i64, ptr %l17, !tbaa !24
  %t209 = add i64 %t207, 1
  %t212 = call { i64, [21 x i64] } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aStmt_3e_2eAt_3ccompiler_2fmir_3aStmt_3e(ptr %v0, ptr %t206, i64 %t209)
  store { i64, [21 x i64] } %t212, ptr %l127
  br label %bb74
bb74:
  call void @llvm.memmove.p0.p0.i64(ptr %l22, ptr %l127, i64 176, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l129, ptr %l22, i64 176, i1 false)
  %t213 = load { i64, [21 x i64] }, ptr %l129
  %t214 = extractvalue { i64, [21 x i64] } %t213, 0
  %t215 = icmp eq i64 %t214, 4
  br i1 %t215, label %bb75, label %bb76
bb75:
  %t217 = getelementptr { i64, [21 x i64] }, ptr %l22, i32 0, i32 1
  %t218 = getelementptr { %"compiler/source:Span", i32 }, ptr %t217, i32 0, i32 1
  %t219 = load i32, ptr %t218
  store i32 %t219, ptr %l23, !tbaa !23
  br label %bb77
bb76:
  br label %bb78
bb77:
  %t221 = load i32, ptr %l23, !tbaa !23
  %t223 = sext i32 %t221 to i64
  %t224 = load i64, ptr %l14, !tbaa !24
  %t227 = icmp eq i64 %t223, %t224
  store i1 %t227, ptr %l128, !tbaa !21
  br label %bb83
bb78:
  br i1 true, label %bb79, label %bb80
bb79:
  br label %bb81
bb80:
  br label %bb82
bb81:
  store i1 false, ptr %l128, !tbaa !21
  br label %bb83
bb82:
  call void @__olang_check_failed(ptr @olang_loc_2bfcda938bdeba4c_88387621cebbefd8)
  unreachable
bb83:
  %t229 = load i1, ptr %l128, !tbaa !21
  store i1 %t229, ptr %l24, !tbaa !21
  %t230 = load i1, ptr %l21, !tbaa !21
  br i1 %t230, label %bb84, label %bb85
bb84:
  %t232 = load i1, ptr %l24, !tbaa !21
  store i1 %t232, ptr %l137, !tbaa !21
  br label %bb86
bb85:
  store i1 false, ptr %l137, !tbaa !21
  br label %bb86
bb86:
  %t234 = load i1, ptr %l137, !tbaa !21
  br i1 %t234, label %bb87, label %bb88
bb87:
  %t235 = load ptr, ptr %l0, !tbaa !29
  %t237 = getelementptr %"compiler/emit:fnEm", ptr %t235, i32 0, i32 23
  %t238 = load i64, ptr %l14, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t237, i64 %t238, i1 true)
  br label %bb89
bb88:
  br label %bb90
bb89:
  br label %bb90
bb90:
  call void @__olang_scope_close(ptr %s5)
  br label %bb91
bb91:
  %t241 = load i64, ptr %l12, !tbaa !24
  %t243 = add i64 %t241, 1
  store i64 %t243, ptr %l12, !tbaa !24
  br label %bb19
bb92:
  call void @__olang_scope_close(ptr %s3)
  br label %bb93
bb93:
  %t245 = load i64, ptr %l5, !tbaa !24
  %t247 = add i64 %t245, 1
  store i64 %t247, ptr %l5, !tbaa !24
  br label %bb8
bb94:
  %t249 = load i64, ptr %l2, !tbaa !24
  %t250 = load i64, ptr %l4, !tbaa !24
  %t253 = add i64 %t249, %t250
  store i64 %t253, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb95
bb95:
  br label %bb1
bb96:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eindex(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca i32
  %l11 = alloca i32
  %l14 = alloca i64
  %l20 = alloca i1
  %l21 = alloca { i64, ptr }
  %l22 = alloca ptr
  %l23 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l30 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/emit:Emitter", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l3, !tbaa !29
  %t9 = load ptr, ptr %l3, !tbaa !29
  %t13 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t9, i32 %a2)
  store i32 %t13, ptr %l11
  br label %bb1
bb1:
  %t14 = load i32, ptr %l11, !tbaa !23
  store i32 %t14, ptr %l4, !tbaa !23
  %t15 = load ptr, ptr %l3, !tbaa !29
  %t16 = load i32, ptr %l4, !tbaa !23
  %t19 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %t15, i32 %t16)
  store i64 %t19, ptr %l14
  br label %bb2
bb2:
  %t20 = load i64, ptr %l14, !tbaa !24
  %t21 = icmp eq i64 %t20, 64
  br i1 %t21, label %bb3, label %bb4
bb3:
  %t23 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t23, 1
  %t26 = extractvalue { i64, ptr } %t23, 0
  %t27 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t26)
  call void @olang_textcopy(ptr %t27, ptr %t25, i64 %t26)
  %t28 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t27, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t29, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t31 = load ptr, ptr %l3, !tbaa !29
  %t32 = load i32, ptr %l4, !tbaa !23
  %t35 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %t31, i32 %t32)
  store i1 %t35, ptr %l20
  br label %bb6
bb6:
  %t36 = load i1, ptr %l20, !tbaa !21
  br i1 %t36, label %bb7, label %bb8
bb7:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d436, i32 0, i32 1) }, ptr %l21, !tbaa !27
  br label %bb9
bb8:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d437, i32 0, i32 1) }, ptr %l21, !tbaa !27
  br label %bb9
bb9:
  %t37 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t38 = load ptr, ptr %l0, !tbaa !29
  store ptr %t38, ptr %l22, !tbaa !29
  store { i64, ptr } %t37, ptr %l23, !tbaa !27
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load i32, ptr %l4, !tbaa !23
  %t44 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s0, ptr %t40, i32 %t41)
  store { i64, ptr } %t44, ptr %l26
  br label %bb10
bb10:
  %t45 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t46 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t47 = extractvalue { i64, ptr } %t46, 1
  %t48 = extractvalue { i64, ptr } %t46, 0
  %t49 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d438, i32 0, i32 1) }, 1
  %t50 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d438, i32 0, i32 1) }, 0
  %t51 = add i64 %t48, %t50
  %t52 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t53 = extractvalue { i64, ptr } %t52, 1
  %t54 = extractvalue { i64, ptr } %t52, 0
  %t55 = add i64 %t51, %t54
  %t56 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d438, i32 0, i32 1) }, 1
  %t57 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d438, i32 0, i32 1) }, 0
  %t58 = add i64 %t55, %t57
  %t60 = extractvalue { i64, ptr } %t45, 1
  %t61 = extractvalue { i64, ptr } %t45, 0
  %t62 = add i64 %t58, %t61
  %t63 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d439, i32 0, i32 1) }, 1
  %t64 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d439, i32 0, i32 1) }, 0
  %t65 = add i64 %t62, %t64
  %t66 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t65)
  call void @olang_textcopy(ptr %t66, ptr %t47, i64 %t48)
  %t67 = getelementptr i8, ptr %t66, i64 %t48
  call void @olang_textcopy(ptr %t67, ptr %t49, i64 %t50)
  %t68 = getelementptr i8, ptr %t67, i64 %t50
  call void @olang_textcopy(ptr %t68, ptr %t53, i64 %t54)
  %t69 = getelementptr i8, ptr %t68, i64 %t54
  call void @olang_textcopy(ptr %t69, ptr %t56, i64 %t57)
  %t70 = getelementptr i8, ptr %t69, i64 %t57
  call void @olang_textcopy(ptr %t70, ptr %t60, i64 %t61)
  %t71 = getelementptr i8, ptr %t70, i64 %t61
  call void @olang_textcopy(ptr %t71, ptr %t63, i64 %t64)
  %t72 = insertvalue { i64, ptr } undef, i64 %t65, 0
  %t73 = insertvalue { i64, ptr } %t72, ptr %t66, 1
  %t75 = extractvalue { i64, ptr } %t73, 0
  %t76 = extractvalue { i64, ptr } %t73, 1
  %t77 = mul i64 %t75, 1
  %t78 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t77)
  call void @llvm.memcpy.p0.p0.i64(ptr %t78, ptr %t76, i64 %t77, i1 false)
  %t79 = insertvalue { i64, ptr } undef, i64 %t75, 0
  %t80 = insertvalue { i64, ptr } %t79, ptr %t78, 1
  %t81 = load ptr, ptr %l22, !tbaa !29
  %t83 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v2, ptr %v2, ptr %t81, { i64, ptr } %t80)
  store { i64, ptr } %t83, ptr %l30
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s0)
  %t84 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t84, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2epair(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d440, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d440, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %a1, 1
  %t7 = extractvalue { i64, ptr } %a1, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d441, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d441, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t12 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t11)
  call void @olang_textcopy(ptr %t12, ptr %t3, i64 %t4)
  %t13 = getelementptr i8, ptr %t12, i64 %t4
  call void @olang_textcopy(ptr %t13, ptr %t6, i64 %t7)
  %t14 = getelementptr i8, ptr %t13, i64 %t7
  call void @olang_textcopy(ptr %t14, ptr %t9, i64 %t10)
  %t15 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr %t12, 1
  %t18 = extractvalue { i64, ptr } %t16, 0
  %t19 = extractvalue { i64, ptr } %t16, 1
  %t20 = mul i64 %t18, 1
  %t21 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t20)
  call void @llvm.memcpy.p0.p0.i64(ptr %t21, ptr %t19, i64 %t20, i1 false)
  %t22 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t21, 1
  %t26 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t1, { i64, ptr } %t23)
  store { i64, ptr } %t26, ptr %l8
  br label %bb1
bb1:
  %t27 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t31 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d442, i32 0, i32 1) }, 1
  %t32 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d442, i32 0, i32 1) }, 0
  %t34 = extractvalue { i64, ptr } %t27, 1
  %t35 = extractvalue { i64, ptr } %t27, 0
  %t36 = add i64 %t32, %t35
  %t37 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d443, i32 0, i32 1) }, 1
  %t38 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d443, i32 0, i32 1) }, 0
  %t39 = add i64 %t36, %t38
  %t41 = extractvalue { i64, ptr } %a2, 1
  %t42 = extractvalue { i64, ptr } %a2, 0
  %t43 = add i64 %t39, %t42
  %t44 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d444, i32 0, i32 1) }, 1
  %t45 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d444, i32 0, i32 1) }, 0
  %t46 = add i64 %t43, %t45
  %t47 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t46)
  call void @olang_textcopy(ptr %t47, ptr %t31, i64 %t32)
  %t48 = getelementptr i8, ptr %t47, i64 %t32
  call void @olang_textcopy(ptr %t48, ptr %t34, i64 %t35)
  %t49 = getelementptr i8, ptr %t48, i64 %t35
  call void @olang_textcopy(ptr %t49, ptr %t37, i64 %t38)
  %t50 = getelementptr i8, ptr %t49, i64 %t38
  call void @olang_textcopy(ptr %t50, ptr %t41, i64 %t42)
  %t51 = getelementptr i8, ptr %t50, i64 %t42
  call void @olang_textcopy(ptr %t51, ptr %t44, i64 %t45)
  %t52 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t53 = insertvalue { i64, ptr } %t52, ptr %t47, 1
  %t55 = extractvalue { i64, ptr } %t53, 0
  %t56 = extractvalue { i64, ptr } %t53, 1
  %t57 = mul i64 %t55, 1
  %t58 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t57)
  call void @llvm.memcpy.p0.p0.i64(ptr %t58, ptr %t56, i64 %t57, i1 false)
  %t59 = insertvalue { i64, ptr } undef, i64 %t55, 0
  %t60 = insertvalue { i64, ptr } %t59, ptr %t58, 1
  %t63 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v3, ptr %v3, ptr %t28, { i64, ptr } %t60)
  store { i64, ptr } %t63, ptr %l14
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  %t64 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t64, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eparts(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, { i64, ptr } %a2, %"compiler/mir:Range" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %lp5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca { i64, ptr }
  %l25 = alloca i64
  %l28 = alloca i64
  %l46 = alloca ptr
  %l50 = alloca { i64, [4 x i64] }
  %l51 = alloca { i64, ptr }
  %l54 = alloca { i64, ptr }
  %l55 = alloca ptr
  %l56 = alloca { i64, ptr }
  %l57 = alloca { i64, ptr }
  %l59 = alloca { i64, ptr }
  %l62 = alloca { i64, ptr }
  %l67 = alloca { i64, ptr }
  %l69 = alloca i64
  %l76 = alloca { i64, ptr }
  %l77 = alloca { i64, ptr }
  %l78 = alloca i64
  %l79 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s0, ptr %t1, i32 %a1)
  store { i64, ptr } %t5, ptr %l15
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t6, ptr %l4, !tbaa !27
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d445, i32 0, i32 1) }, ptr %l16, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t7, ptr %l17, !tbaa !27
  %t8 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t8, 0
  store i64 %t9, ptr %l18, !tbaa !24
  %t10 = load i64, ptr %l18, !tbaa !24
  %t11 = mul i64 %t10, 1
  %t12 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t11)
  %t13 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l19, !tbaa !27
  %t15 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !27
  %t17 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !27
  %t19 = load i64, ptr %l18, !tbaa !24
  %t20 = mul i64 %t19, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t16, ptr %t18, i64 %t20, i1 false)
  %t21 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t21, ptr %lp5
  %t22 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t23 = load ptr, ptr %lp5
  store { i64, ptr } %t22, ptr %t23, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t24 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  store i64 %t26, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t28 = load i64, ptr %l7, !tbaa !24
  %t29 = load i64, ptr %l6, !tbaa !24
  %t32 = icmp sgt i64 %t28, %t29
  br i1 %t32, label %bb2, label %bb3
bb2:
  %t34 = load i64, ptr %l8, !tbaa !24
  %t36 = icmp sgt i64 %t34, 0
  br i1 %t36, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l25, !tbaa !24
  br label %bb7
bb4:
  %t38 = load i64, ptr %l7, !tbaa !24
  %t39 = load i64, ptr %l6, !tbaa !24
  %t42 = sub i64 %t38, %t39
  %t43 = load i64, ptr %l8, !tbaa !24
  %t46 = add i64 %t42, %t43
  %t48 = sub i64 %t46, 1
  %t49 = load i64, ptr %l8, !tbaa !24
  %t52 = sdiv i64 %t48, %t49
  store i64 %t52, ptr %l28, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb6
bb6:
  %t54 = load i64, ptr %l28, !tbaa !24
  store i64 %t54, ptr %l25, !tbaa !24
  br label %bb7
bb7:
  %t55 = load i64, ptr %l25, !tbaa !24
  store i64 %t55, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t56 = load i64, ptr %l10, !tbaa !24
  %t57 = load i64, ptr %l9, !tbaa !24
  %t60 = icmp slt i64 %t56, %t57
  %t62 = xor i1 %t60, true
  br i1 %t62, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb20
bb10:
  br label %bb11
bb11:
  %t64 = load i64, ptr %l6, !tbaa !24
  %t65 = load i64, ptr %l10, !tbaa !24
  %t66 = load i64, ptr %l8, !tbaa !24
  %t69 = mul i64 %t65, %t66
  %t72 = add i64 %t64, %t69
  store i64 %t72, ptr %l11, !tbaa !24
  %t74 = load ptr, ptr %l0, !tbaa !29
  store ptr %t74, ptr %l46, !tbaa !29
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = load i64, ptr %l11, !tbaa !24
  %t81 = call { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %t75, %"compiler/mir:Range" %a3, i64 %t77)
  store { i64, [4 x i64] } %t81, ptr %l50
  br label %bb12
bb12:
  %t82 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t82, ptr %l51, !tbaa !27
  %t83 = load i64, ptr %l11, !tbaa !24
  %t85 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !27
  %t87 = getelementptr i32, ptr %t86, i64 %t83
  %t88 = load i32, ptr %t87, !tbaa !33
  %t89 = load ptr, ptr %l46, !tbaa !29
  %t90 = load { i64, [4 x i64] }, ptr %l50
  %t92 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s2, ptr %t89, { i64, [4 x i64] } %t90, i32 %t88)
  store { i64, ptr } %t92, ptr %l54
  br label %bb13
bb13:
  %t93 = load { i64, ptr }, ptr %l54, !tbaa !27
  store { i64, ptr } %t93, ptr %l12, !tbaa !27
  %t94 = load ptr, ptr %l0, !tbaa !29
  store ptr %t94, ptr %l55, !tbaa !29
  %t95 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t95, ptr %l56, !tbaa !27
  %t96 = load ptr, ptr %lp5
  %t97 = load { i64, ptr }, ptr %t96, !tbaa !27
  store { i64, ptr } %t97, ptr %l57, !tbaa !27
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t99 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t99, ptr %l59, !tbaa !27
  %t100 = load i64, ptr %l11, !tbaa !24
  %t102 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t103 = load ptr, ptr %t102, !tbaa !27
  %t104 = getelementptr i32, ptr %t103, i64 %t100
  %t105 = load i32, ptr %t104, !tbaa !33
  %t108 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s2, ptr %t98, i32 %t105)
  store { i64, ptr } %t108, ptr %l62
  br label %bb14
bb14:
  %t109 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t110 = load i64, ptr %l11, !tbaa !24
  %t111 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d446, i32 0, i32 1) }, 1
  %t112 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d446, i32 0, i32 1) }, 0
  %t113 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t113, 1
  %t115 = extractvalue { i64, ptr } %t113, 0
  %t116 = add i64 %t112, %t115
  %t117 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d447, i32 0, i32 1) }, 1
  %t118 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d447, i32 0, i32 1) }, 0
  %t119 = add i64 %t116, %t118
  %t120 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t121 = extractvalue { i64, ptr } %t120, 1
  %t122 = extractvalue { i64, ptr } %t120, 0
  %t123 = add i64 %t119, %t122
  %t124 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d448, i32 0, i32 1) }, 1
  %t125 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d448, i32 0, i32 1) }, 0
  %t126 = add i64 %t123, %t125
  %t127 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t128 = extractvalue { i64, ptr } %t127, 1
  %t129 = extractvalue { i64, ptr } %t127, 0
  %t130 = add i64 %t126, %t129
  %t131 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d447, i32 0, i32 1) }, 1
  %t132 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d447, i32 0, i32 1) }, 0
  %t133 = add i64 %t130, %t132
  %t135 = extractvalue { i64, ptr } %t109, 1
  %t136 = extractvalue { i64, ptr } %t109, 0
  %t137 = add i64 %t133, %t136
  %t138 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d448, i32 0, i32 1) }, 1
  %t139 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d448, i32 0, i32 1) }, 0
  %t140 = add i64 %t137, %t139
  %t142 = call i64 @__olang_fmt_i64(ptr null, i64 %t110)
  %t143 = add i64 %t140, %t142
  %t144 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t143)
  call void @olang_textcopy(ptr %t144, ptr %t111, i64 %t112)
  %t145 = getelementptr i8, ptr %t144, i64 %t112
  call void @olang_textcopy(ptr %t145, ptr %t114, i64 %t115)
  %t146 = getelementptr i8, ptr %t145, i64 %t115
  call void @olang_textcopy(ptr %t146, ptr %t117, i64 %t118)
  %t147 = getelementptr i8, ptr %t146, i64 %t118
  call void @olang_textcopy(ptr %t147, ptr %t121, i64 %t122)
  %t148 = getelementptr i8, ptr %t147, i64 %t122
  call void @olang_textcopy(ptr %t148, ptr %t124, i64 %t125)
  %t149 = getelementptr i8, ptr %t148, i64 %t125
  call void @olang_textcopy(ptr %t149, ptr %t128, i64 %t129)
  %t150 = getelementptr i8, ptr %t149, i64 %t129
  call void @olang_textcopy(ptr %t150, ptr %t131, i64 %t132)
  %t151 = getelementptr i8, ptr %t150, i64 %t132
  call void @olang_textcopy(ptr %t151, ptr %t135, i64 %t136)
  %t152 = getelementptr i8, ptr %t151, i64 %t136
  call void @olang_textcopy(ptr %t152, ptr %t138, i64 %t139)
  %t153 = getelementptr i8, ptr %t152, i64 %t139
  %t154 = call i64 @__olang_fmt_i64(ptr %t153, i64 %t110)
  %t155 = insertvalue { i64, ptr } undef, i64 %t143, 0
  %t156 = insertvalue { i64, ptr } %t155, ptr %t144, 1
  %t158 = extractvalue { i64, ptr } %t156, 0
  %t159 = extractvalue { i64, ptr } %t156, 1
  %t160 = mul i64 %t158, 1
  %t161 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t160)
  call void @llvm.memcpy.p0.p0.i64(ptr %t161, ptr %t159, i64 %t160, i1 false)
  %t162 = insertvalue { i64, ptr } undef, i64 %t158, 0
  %t163 = insertvalue { i64, ptr } %t162, ptr %t161, 1
  %t164 = load ptr, ptr %l55, !tbaa !29
  %t166 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v2, ptr %v2, ptr %t164, { i64, ptr } %t163)
  store { i64, ptr } %t166, ptr %l67
  br label %bb15
bb15:
  %t167 = load ptr, ptr %lp5
  %t168 = load { i64, ptr }, ptr %t167, !tbaa !27
  %t169 = extractvalue { i64, ptr } %t168, 0
  %t170 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t171 = extractvalue { i64, ptr } %t170, 0
  store i64 %t171, ptr %l69, !tbaa !24
  %t173 = load i64, ptr %l69, !tbaa !24
  %t174 = icmp eq i64 %t169, %t173
  br i1 %t174, label %bb16, label %bb17
bb16:
  %t176 = load ptr, ptr %lp5
  %t177 = getelementptr { i64, ptr }, ptr %t176, i32 0, i32 1
  %t178 = load ptr, ptr %t177, !tbaa !27
  %t179 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t180 = load ptr, ptr %t179, !tbaa !27
  %t181 = load i64, ptr %l69, !tbaa !24
  %t182 = mul i64 %t181, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t178, ptr %t180, i64 %t182, i1 false)
  br label %bb18
bb17:
  %t183 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t184 = load ptr, ptr %lp5
  store { i64, ptr } %t183, ptr %t184, !tbaa !27
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb19:
  %t185 = load i64, ptr %l10, !tbaa !24
  %t187 = add i64 %t185, 1
  store i64 %t187, ptr %l10, !tbaa !24
  br label %bb8
bb20:
  %t189 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t191 = extractvalue { i64, ptr } %t189, 0
  %t193 = icmp eq i64 %t191, 0
  br i1 %t193, label %bb21, label %bb22
bb21:
  store { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d449, i32 0, i32 1) }, ptr %l76, !tbaa !27
  %t195 = load { i64, ptr }, ptr %l76, !tbaa !27
  store { i64, ptr } %t195, ptr %l77, !tbaa !27
  %t196 = load { i64, ptr }, ptr %l77, !tbaa !27
  %t197 = extractvalue { i64, ptr } %t196, 0
  store i64 %t197, ptr %l78, !tbaa !24
  %t198 = load i64, ptr %l78, !tbaa !24
  %t199 = mul i64 %t198, 1
  %t200 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t199)
  %t201 = insertvalue { i64, ptr } undef, i64 %t198, 0
  %t202 = insertvalue { i64, ptr } %t201, ptr %t200, 1
  store { i64, ptr } %t202, ptr %l79, !tbaa !27
  %t203 = getelementptr { i64, ptr }, ptr %l79, i32 0, i32 1
  %t204 = load ptr, ptr %t203, !tbaa !27
  %t205 = getelementptr { i64, ptr }, ptr %l77, i32 0, i32 1
  %t206 = load ptr, ptr %t205, !tbaa !27
  %t207 = load i64, ptr %l78, !tbaa !24
  %t208 = mul i64 %t207, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t204, ptr %t206, i64 %t208, i1 false)
  %t209 = load { i64, ptr }, ptr %l79, !tbaa !27
  store { i64, ptr } %t209, ptr %l77, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t210 = load { i64, ptr }, ptr %l77, !tbaa !27
  store { i64, ptr } %t210, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  %t211 = load ptr, ptr %lp5
  %t212 = load { i64, ptr }, ptr %t211, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t212, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eprogram(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edefine(ptr %v0, ptr %s0, ptr %s0, ptr %t4, { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d450, i32 0, i32 1) }, { i64, ptr } { i64 67, ptr getelementptr inbounds (<{ i64, [67 x i8] }>, ptr @.d451, i32 0, i32 1) })
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %t6, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d452, i32 0, i32 1) }, { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d453, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d179, i32 0, i32 1) })
  store { i64, ptr } %t8, ptr %l4
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  %t9 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t9, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2erecode(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l17 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l37 = alloca i64
  %l38 = alloca { i64, ptr }
  %l44 = alloca i64
  %l47 = alloca i64
  %l68 = alloca { i64, ptr }
  %l71 = alloca i64
  %l78 = alloca { i64, ptr }
  %l85 = alloca { i64, ptr }
  %l87 = alloca i64
  %l95 = alloca { i64, ptr }
  %l96 = alloca ptr
  %l101 = alloca { i64, ptr }
  %l105 = alloca { i64, ptr }
  %l111 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/emit:Emitter", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t13 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t7, i32 %a2)
  store { i64, ptr } %t13, ptr %l24
  br label %bb1
bb1:
  %t14 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t14, ptr %l5, !tbaa !27
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t17 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d454, i32 0, i32 1) }, 1
  %t18 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d454, i32 0, i32 1) }, 0
  %t20 = extractvalue { i64, ptr } %t16, 1
  %t21 = extractvalue { i64, ptr } %t16, 0
  %t22 = add i64 %t18, %t21
  %t23 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d455, i32 0, i32 1) }, 1
  %t24 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d455, i32 0, i32 1) }, 0
  %t25 = add i64 %t22, %t24
  %t26 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t25)
  call void @olang_textcopy(ptr %t26, ptr %t17, i64 %t18)
  %t27 = getelementptr i8, ptr %t26, i64 %t18
  call void @olang_textcopy(ptr %t27, ptr %t20, i64 %t21)
  %t28 = getelementptr i8, ptr %t27, i64 %t21
  call void @olang_textcopy(ptr %t28, ptr %t23, i64 %t24)
  %t29 = insertvalue { i64, ptr } undef, i64 %t25, 0
  %t30 = insertvalue { i64, ptr } %t29, ptr %t26, 1
  %t32 = extractvalue { i64, ptr } %t30, 0
  %t33 = extractvalue { i64, ptr } %t30, 1
  %t34 = mul i64 %t32, 1
  %t35 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t34)
  call void @llvm.memcpy.p0.p0.i64(ptr %t35, ptr %t33, i64 %t34, i1 false)
  %t36 = insertvalue { i64, ptr } undef, i64 %t32, 0
  %t37 = insertvalue { i64, ptr } %t36, ptr %t35, 1
  %t40 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t15, { i64, ptr } %t37)
  store { i64, ptr } %t40, ptr %l29
  br label %bb2
bb2:
  %t41 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t41, ptr %l6, !tbaa !27
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t44 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d456, i32 0, i32 1) }, 1
  %t45 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d456, i32 0, i32 1) }, 0
  %t47 = extractvalue { i64, ptr } %t43, 1
  %t48 = extractvalue { i64, ptr } %t43, 0
  %t49 = add i64 %t45, %t48
  %t50 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d457, i32 0, i32 1) }, 1
  %t51 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d457, i32 0, i32 1) }, 0
  %t52 = add i64 %t49, %t51
  %t53 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t52)
  call void @olang_textcopy(ptr %t53, ptr %t44, i64 %t45)
  %t54 = getelementptr i8, ptr %t53, i64 %t45
  call void @olang_textcopy(ptr %t54, ptr %t47, i64 %t48)
  %t55 = getelementptr i8, ptr %t54, i64 %t48
  call void @olang_textcopy(ptr %t55, ptr %t50, i64 %t51)
  %t56 = insertvalue { i64, ptr } undef, i64 %t52, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t53, 1
  %t59 = extractvalue { i64, ptr } %t57, 0
  %t60 = extractvalue { i64, ptr } %t57, 1
  %t61 = mul i64 %t59, 1
  %t62 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t61)
  call void @llvm.memcpy.p0.p0.i64(ptr %t62, ptr %t60, i64 %t61, i1 false)
  %t63 = insertvalue { i64, ptr } undef, i64 %t59, 0
  %t64 = insertvalue { i64, ptr } %t63, ptr %t62, 1
  %t67 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t42, { i64, ptr } %t64)
  store { i64, ptr } %t67, ptr %l34
  br label %bb3
bb3:
  %t68 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t68, ptr %l7, !tbaa !27
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d458, i32 0, i32 1) }, ptr %l35, !tbaa !27
  %t69 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t69, ptr %l36, !tbaa !27
  %t70 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t71 = extractvalue { i64, ptr } %t70, 0
  store i64 %t71, ptr %l37, !tbaa !24
  %t72 = load i64, ptr %l37, !tbaa !24
  %t73 = mul i64 %t72, 1
  %t74 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t73)
  %t75 = insertvalue { i64, ptr } undef, i64 %t72, 0
  %t76 = insertvalue { i64, ptr } %t75, ptr %t74, 1
  store { i64, ptr } %t76, ptr %l38, !tbaa !27
  %t77 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = load i64, ptr %l37, !tbaa !24
  %t82 = mul i64 %t81, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t78, ptr %t80, i64 %t82, i1 false)
  %t83 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t83, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t84 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t84, 0
  store i64 %t86, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t88 = load i64, ptr %l10, !tbaa !24
  %t89 = load i64, ptr %l9, !tbaa !24
  %t92 = icmp sgt i64 %t88, %t89
  br i1 %t92, label %bb4, label %bb5
bb4:
  %t94 = load i64, ptr %l11, !tbaa !24
  %t96 = icmp sgt i64 %t94, 0
  br i1 %t96, label %bb6, label %bb7
bb5:
  store i64 0, ptr %l44, !tbaa !24
  br label %bb9
bb6:
  %t98 = load i64, ptr %l10, !tbaa !24
  %t99 = load i64, ptr %l9, !tbaa !24
  %t102 = sub i64 %t98, %t99
  %t103 = load i64, ptr %l11, !tbaa !24
  %t106 = add i64 %t102, %t103
  %t108 = sub i64 %t106, 1
  %t109 = load i64, ptr %l11, !tbaa !24
  %t112 = sdiv i64 %t108, %t109
  store i64 %t112, ptr %l47, !tbaa !24
  br label %bb8
bb7:
  store i64 0, ptr %l47, !tbaa !24
  br label %bb8
bb8:
  %t114 = load i64, ptr %l47, !tbaa !24
  store i64 %t114, ptr %l44, !tbaa !24
  br label %bb9
bb9:
  %t115 = load i64, ptr %l44, !tbaa !24
  store i64 %t115, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s4
  %t116 = load i64, ptr %l13, !tbaa !24
  %t117 = load i64, ptr %l12, !tbaa !24
  %t120 = icmp slt i64 %t116, %t117
  %t122 = xor i1 %t120, true
  br i1 %t122, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s4)
  br label %bb21
bb12:
  br label %bb13
bb13:
  %t124 = load i64, ptr %l9, !tbaa !24
  %t125 = load i64, ptr %l13, !tbaa !24
  %t126 = load i64, ptr %l11, !tbaa !24
  %t129 = mul i64 %t125, %t126
  %t132 = add i64 %t124, %t129
  store i64 %t132, ptr %l14, !tbaa !24
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr %"compiler/emit:fnEm", ptr %t134, i32 0, i32 0
  %t137 = load ptr, ptr %t136, !tbaa !29
  %t139 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t139, ptr %l68, !tbaa !27
  %t140 = load i64, ptr %l14, !tbaa !24
  %t142 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t143 = load ptr, ptr %t142, !tbaa !27
  %t144 = getelementptr i32, ptr %t143, i64 %t140
  %t145 = load i32, ptr %t144, !tbaa !33
  %t149 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eposition(ptr %v0, ptr %t137, i32 %a3, i32 %t145)
  store i64 %t149, ptr %l71
  br label %bb14
bb14:
  %t150 = load i64, ptr %l71, !tbaa !24
  store i64 %t150, ptr %l15, !tbaa !24
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t152 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t153 = load i64, ptr %l14, !tbaa !24
  %t155 = add i64 %t153, 1
  %t156 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d459, i32 0, i32 1) }, 1
  %t157 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d459, i32 0, i32 1) }, 0
  %t159 = extractvalue { i64, ptr } %t152, 1
  %t160 = extractvalue { i64, ptr } %t152, 0
  %t161 = add i64 %t157, %t160
  %t162 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d460, i32 0, i32 1) }, 1
  %t163 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d460, i32 0, i32 1) }, 0
  %t164 = add i64 %t161, %t163
  %t166 = call i64 @__olang_fmt_i64(ptr null, i64 %t155)
  %t167 = add i64 %t164, %t166
  %t168 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t167)
  call void @olang_textcopy(ptr %t168, ptr %t156, i64 %t157)
  %t169 = getelementptr i8, ptr %t168, i64 %t157
  call void @olang_textcopy(ptr %t169, ptr %t159, i64 %t160)
  %t170 = getelementptr i8, ptr %t169, i64 %t160
  call void @olang_textcopy(ptr %t170, ptr %t162, i64 %t163)
  %t171 = getelementptr i8, ptr %t170, i64 %t163
  %t172 = call i64 @__olang_fmt_i64(ptr %t171, i64 %t155)
  %t173 = insertvalue { i64, ptr } undef, i64 %t167, 0
  %t174 = insertvalue { i64, ptr } %t173, ptr %t168, 1
  %t176 = extractvalue { i64, ptr } %t174, 0
  %t177 = extractvalue { i64, ptr } %t174, 1
  %t178 = mul i64 %t176, 1
  %t179 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t178)
  call void @llvm.memcpy.p0.p0.i64(ptr %t179, ptr %t177, i64 %t178, i1 false)
  %t180 = insertvalue { i64, ptr } undef, i64 %t176, 0
  %t181 = insertvalue { i64, ptr } %t180, ptr %t179, 1
  %t184 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s4, ptr %s4, ptr %t151, { i64, ptr } %t181)
  store { i64, ptr } %t184, ptr %l78
  br label %bb15
bb15:
  %t185 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t186 = load ptr, ptr %l0, !tbaa !29
  %t188 = load i64, ptr %l15, !tbaa !24
  %t189 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t190 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d461, i32 0, i32 1) }, 1
  %t191 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d461, i32 0, i32 1) }, 0
  %t193 = extractvalue { i64, ptr } %t185, 1
  %t194 = extractvalue { i64, ptr } %t185, 0
  %t195 = add i64 %t191, %t194
  %t196 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d462, i32 0, i32 1) }, 1
  %t197 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d462, i32 0, i32 1) }, 0
  %t198 = add i64 %t195, %t197
  %t200 = call i64 @__olang_fmt_i64(ptr null, i64 %t188)
  %t201 = add i64 %t198, %t200
  %t202 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d462, i32 0, i32 1) }, 1
  %t203 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d462, i32 0, i32 1) }, 0
  %t204 = add i64 %t201, %t203
  %t206 = extractvalue { i64, ptr } %t189, 1
  %t207 = extractvalue { i64, ptr } %t189, 0
  %t208 = add i64 %t204, %t207
  %t209 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t208)
  call void @olang_textcopy(ptr %t209, ptr %t190, i64 %t191)
  %t210 = getelementptr i8, ptr %t209, i64 %t191
  call void @olang_textcopy(ptr %t210, ptr %t193, i64 %t194)
  %t211 = getelementptr i8, ptr %t210, i64 %t194
  call void @olang_textcopy(ptr %t211, ptr %t196, i64 %t197)
  %t212 = getelementptr i8, ptr %t211, i64 %t197
  %t213 = call i64 @__olang_fmt_i64(ptr %t212, i64 %t188)
  %t214 = getelementptr i8, ptr %t212, i64 %t200
  call void @olang_textcopy(ptr %t214, ptr %t202, i64 %t203)
  %t215 = getelementptr i8, ptr %t214, i64 %t203
  call void @olang_textcopy(ptr %t215, ptr %t206, i64 %t207)
  %t216 = insertvalue { i64, ptr } undef, i64 %t208, 0
  %t217 = insertvalue { i64, ptr } %t216, ptr %t209, 1
  %t219 = extractvalue { i64, ptr } %t217, 0
  %t220 = extractvalue { i64, ptr } %t217, 1
  %t221 = mul i64 %t219, 1
  %t222 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t221)
  call void @llvm.memcpy.p0.p0.i64(ptr %t222, ptr %t220, i64 %t221, i1 false)
  %t223 = insertvalue { i64, ptr } undef, i64 %t219, 0
  %t224 = insertvalue { i64, ptr } %t223, ptr %t222, 1
  %t227 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t186, { i64, ptr } %t224)
  store { i64, ptr } %t227, ptr %l85
  br label %bb16
bb16:
  %t228 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t229 = extractvalue { i64, ptr } %t228, 0
  %t230 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t231 = extractvalue { i64, ptr } %t230, 0
  store i64 %t231, ptr %l87, !tbaa !24
  %t233 = load i64, ptr %l87, !tbaa !24
  %t234 = icmp eq i64 %t229, %t233
  br i1 %t234, label %bb17, label %bb18
bb17:
  %t236 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t237 = load ptr, ptr %t236, !tbaa !27
  %t238 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t239 = load ptr, ptr %t238, !tbaa !27
  %t240 = load i64, ptr %l87, !tbaa !24
  %t241 = mul i64 %t240, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t237, ptr %t239, i64 %t241, i1 false)
  br label %bb19
bb18:
  %t242 = load { i64, ptr }, ptr %l85, !tbaa !27
  store { i64, ptr } %t242, ptr %l8, !tbaa !27
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s4)
  br label %bb20
bb20:
  %t243 = load i64, ptr %l13, !tbaa !24
  %t245 = add i64 %t243, 1
  store i64 %t245, ptr %l13, !tbaa !24
  br label %bb10
bb21:
  %t247 = load ptr, ptr %l0, !tbaa !29
  %t248 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t249 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d463, i32 0, i32 1) }, 1
  %t250 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d463, i32 0, i32 1) }, 0
  %t252 = extractvalue { i64, ptr } %t248, 1
  %t253 = extractvalue { i64, ptr } %t248, 0
  %t254 = add i64 %t250, %t253
  %t255 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d464, i32 0, i32 1) }, 1
  %t256 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d464, i32 0, i32 1) }, 0
  %t257 = add i64 %t254, %t256
  %t258 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t257)
  call void @olang_textcopy(ptr %t258, ptr %t249, i64 %t250)
  %t259 = getelementptr i8, ptr %t258, i64 %t250
  call void @olang_textcopy(ptr %t259, ptr %t252, i64 %t253)
  %t260 = getelementptr i8, ptr %t259, i64 %t253
  call void @olang_textcopy(ptr %t260, ptr %t255, i64 %t256)
  %t261 = insertvalue { i64, ptr } undef, i64 %t257, 0
  %t262 = insertvalue { i64, ptr } %t261, ptr %t258, 1
  %t264 = extractvalue { i64, ptr } %t262, 0
  %t265 = extractvalue { i64, ptr } %t262, 1
  %t266 = mul i64 %t264, 1
  %t267 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t266)
  call void @llvm.memcpy.p0.p0.i64(ptr %t267, ptr %t265, i64 %t266, i1 false)
  %t268 = insertvalue { i64, ptr } undef, i64 %t264, 0
  %t269 = insertvalue { i64, ptr } %t268, ptr %t267, 1
  %t272 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t247, { i64, ptr } %t269)
  store { i64, ptr } %t272, ptr %l95
  br label %bb22
bb22:
  %t273 = load { i64, ptr }, ptr %l95, !tbaa !27
  store { i64, ptr } %t273, ptr %l17, !tbaa !27
  %t274 = load ptr, ptr %l0, !tbaa !29
  store ptr %t274, ptr %l96, !tbaa !29
  %t275 = load ptr, ptr %l0, !tbaa !29
  %t276 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t277 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d465, i32 0, i32 1) }, 1
  %t278 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d465, i32 0, i32 1) }, 0
  %t280 = extractvalue { i64, ptr } %t276, 1
  %t281 = extractvalue { i64, ptr } %t276, 0
  %t282 = add i64 %t278, %t281
  %t283 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d466, i32 0, i32 1) }, 1
  %t284 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d466, i32 0, i32 1) }, 0
  %t285 = add i64 %t282, %t284
  %t286 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t285)
  call void @olang_textcopy(ptr %t286, ptr %t277, i64 %t278)
  %t287 = getelementptr i8, ptr %t286, i64 %t278
  call void @olang_textcopy(ptr %t287, ptr %t280, i64 %t281)
  %t288 = getelementptr i8, ptr %t287, i64 %t281
  call void @olang_textcopy(ptr %t288, ptr %t283, i64 %t284)
  %t289 = insertvalue { i64, ptr } undef, i64 %t285, 0
  %t290 = insertvalue { i64, ptr } %t289, ptr %t286, 1
  %t292 = extractvalue { i64, ptr } %t290, 0
  %t293 = extractvalue { i64, ptr } %t290, 1
  %t294 = mul i64 %t292, 1
  %t295 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t294)
  call void @llvm.memcpy.p0.p0.i64(ptr %t295, ptr %t293, i64 %t294, i1 false)
  %t296 = insertvalue { i64, ptr } undef, i64 %t292, 0
  %t297 = insertvalue { i64, ptr } %t296, ptr %t295, 1
  %t300 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t275, { i64, ptr } %t297)
  store { i64, ptr } %t300, ptr %l101
  br label %bb23
bb23:
  %t301 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t302 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d467, i32 0, i32 1) }, 1
  %t303 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d467, i32 0, i32 1) }, 0
  %t304 = load { i64, ptr }, ptr %l101, !tbaa !27
  %t305 = extractvalue { i64, ptr } %t304, 1
  %t306 = extractvalue { i64, ptr } %t304, 0
  %t307 = add i64 %t303, %t306
  %t308 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d468, i32 0, i32 1) }, 1
  %t309 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d468, i32 0, i32 1) }, 0
  %t310 = add i64 %t307, %t309
  %t312 = extractvalue { i64, ptr } %t301, 1
  %t313 = extractvalue { i64, ptr } %t301, 0
  %t314 = add i64 %t310, %t313
  %t315 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t314)
  call void @olang_textcopy(ptr %t315, ptr %t302, i64 %t303)
  %t316 = getelementptr i8, ptr %t315, i64 %t303
  call void @olang_textcopy(ptr %t316, ptr %t305, i64 %t306)
  %t317 = getelementptr i8, ptr %t316, i64 %t306
  call void @olang_textcopy(ptr %t317, ptr %t308, i64 %t309)
  %t318 = getelementptr i8, ptr %t317, i64 %t309
  call void @olang_textcopy(ptr %t318, ptr %t312, i64 %t313)
  %t319 = insertvalue { i64, ptr } undef, i64 %t314, 0
  %t320 = insertvalue { i64, ptr } %t319, ptr %t315, 1
  %t322 = extractvalue { i64, ptr } %t320, 0
  %t323 = extractvalue { i64, ptr } %t320, 1
  %t324 = mul i64 %t322, 1
  %t325 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t324)
  call void @llvm.memcpy.p0.p0.i64(ptr %t325, ptr %t323, i64 %t324, i1 false)
  %t326 = insertvalue { i64, ptr } undef, i64 %t322, 0
  %t327 = insertvalue { i64, ptr } %t326, ptr %t325, 1
  %t328 = load ptr, ptr %l96, !tbaa !29
  %t330 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t328, { i64, ptr } %t327)
  store { i64, ptr } %t330, ptr %l105
  br label %bb24
bb24:
  %t331 = load { i64, ptr }, ptr %l105, !tbaa !27
  %t332 = load ptr, ptr %l0, !tbaa !29
  %t333 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t335 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d469, i32 0, i32 1) }, 1
  %t336 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d469, i32 0, i32 1) }, 0
  %t338 = extractvalue { i64, ptr } %t333, 1
  %t339 = extractvalue { i64, ptr } %t333, 0
  %t340 = add i64 %t336, %t339
  %t341 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d470, i32 0, i32 1) }, 1
  %t342 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d470, i32 0, i32 1) }, 0
  %t343 = add i64 %t340, %t342
  %t345 = extractvalue { i64, ptr } %t331, 1
  %t346 = extractvalue { i64, ptr } %t331, 0
  %t347 = add i64 %t343, %t346
  %t348 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t347)
  call void @olang_textcopy(ptr %t348, ptr %t335, i64 %t336)
  %t349 = getelementptr i8, ptr %t348, i64 %t336
  call void @olang_textcopy(ptr %t349, ptr %t338, i64 %t339)
  %t350 = getelementptr i8, ptr %t349, i64 %t339
  call void @olang_textcopy(ptr %t350, ptr %t341, i64 %t342)
  %t351 = getelementptr i8, ptr %t350, i64 %t342
  call void @olang_textcopy(ptr %t351, ptr %t345, i64 %t346)
  %t352 = insertvalue { i64, ptr } undef, i64 %t347, 0
  %t353 = insertvalue { i64, ptr } %t352, ptr %t348, 1
  %t355 = extractvalue { i64, ptr } %t353, 0
  %t356 = extractvalue { i64, ptr } %t353, 1
  %t357 = mul i64 %t355, 1
  %t358 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t357)
  call void @llvm.memcpy.p0.p0.i64(ptr %t358, ptr %t356, i64 %t357, i1 false)
  %t359 = insertvalue { i64, ptr } undef, i64 %t355, 0
  %t360 = insertvalue { i64, ptr } %t359, ptr %t358, 1
  %t363 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v2, ptr %v2, ptr %t332, { i64, ptr } %t360)
  store { i64, ptr } %t363, ptr %l111
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s0)
  %t364 = load { i64, ptr }, ptr %l111, !tbaa !27
  store { i64, ptr } %t364, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2esrcAddr(ptr %v0, ptr %v1, ptr %a0, { i64, [4 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [4 x i64] }
  %l2 = alloca %"compiler/mir:Place"
  %l3 = alloca { { i64, ptr }, i32 }
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i64
  %l8 = alloca %"compiler/source:Span"
  %l14 = alloca { { i64, ptr }, i32 }
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l35 = alloca i64
  %l36 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, [4 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [4 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [4 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 1
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [4 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { %"compiler/mir:Place" }, ptr %t6, i32 0, i32 0
  %t8 = load %"compiler/mir:Place", ptr %t7
  store %"compiler/mir:Place" %t8, ptr %l2
  br label %bb3
bb2:
  br label %bb5
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load %"compiler/mir:Place", ptr %l2
  %t14 = call { { i64, ptr }, i32 } @compiler_2femit_2ecompiler_2femit_3afnEm_2eaddr(ptr %v0, ptr %s1, ptr %t10, %"compiler/mir:Place" %t11)
  store { { i64, ptr }, i32 } %t14, ptr %l14
  br label %bb4
bb4:
  %t15 = load { { i64, ptr }, i32 }, ptr %l14
  store { { i64, ptr }, i32 } %t15, ptr %l3
  %t16 = getelementptr { { i64, ptr }, i32 }, ptr %l3, i32 0, i32 0
  %t17 = load { i64, ptr }, ptr %t16, !tbaa !27
  store { i64, ptr } %t17, ptr %l15, !tbaa !27
  %t18 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t18, 0
  store i64 %t19, ptr %l16, !tbaa !24
  %t20 = load i64, ptr %l16, !tbaa !24
  %t21 = mul i64 %t20, 1
  %t22 = call ptr @__olang_scope_alloc_zeroed(ptr %s1, i64 %t21)
  %t23 = insertvalue { i64, ptr } undef, i64 %t20, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t22, 1
  store { i64, ptr } %t24, ptr %l17, !tbaa !27
  %t25 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = load i64, ptr %l16, !tbaa !24
  %t30 = mul i64 %t29, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t26, ptr %t28, i64 %t30, i1 false)
  %t31 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t31, ptr %l18, !tbaa !27
  %t33 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t33, 0
  store i64 %t34, ptr %l19, !tbaa !24
  %t35 = load i64, ptr %l19, !tbaa !24
  %t36 = mul i64 %t35, 1
  %t37 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t36)
  %t38 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t37, 1
  store { i64, ptr } %t39, ptr %l20, !tbaa !27
  %t40 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = load i64, ptr %l19, !tbaa !24
  %t45 = mul i64 %t44, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t41, ptr %t43, i64 %t45, i1 false)
  %t46 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t46, ptr %l18, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  %t47 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t47, ptr %rv
  br label %ret
bb5:
  %t48 = load { i64, [4 x i64] }, ptr %l1
  %t50 = extractvalue { i64, [4 x i64] } %t48, 0
  %t51 = icmp eq i64 %t50, 3
  br i1 %t51, label %bb6, label %bb7
bb6:
  %t53 = getelementptr { i64, [4 x i64] }, ptr %l1, i32 0, i32 1
  %t54 = getelementptr { i32, i32, i64, %"compiler/source:Span" }, ptr %t53, i32 0, i32 0
  %t55 = load i32, ptr %t54
  store i32 %t55, ptr %l5, !tbaa !23
  %t57 = getelementptr { i64, [4 x i64] }, ptr %l1, i32 0, i32 1
  %t58 = getelementptr { i32, i32, i64, %"compiler/source:Span" }, ptr %t57, i32 0, i32 1
  %t59 = load i32, ptr %t58
  store i32 %t59, ptr %l6, !tbaa !23
  %t61 = getelementptr { i64, [4 x i64] }, ptr %l1, i32 0, i32 1
  %t62 = getelementptr { i32, i32, i64, %"compiler/source:Span" }, ptr %t61, i32 0, i32 2
  %t63 = load i64, ptr %t62
  store i64 %t63, ptr %l7, !tbaa !24
  %t65 = getelementptr { i64, [4 x i64] }, ptr %l1, i32 0, i32 1
  %t66 = getelementptr { i32, i32, i64, %"compiler/source:Span" }, ptr %t65, i32 0, i32 3
  %t67 = load %"compiler/source:Span", ptr %t66
  store %"compiler/source:Span" %t67, ptr %l8
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load i32, ptr %l5, !tbaa !23
  %t71 = load i32, ptr %l6, !tbaa !23
  %t72 = load i64, ptr %l7, !tbaa !24
  %t73 = load %"compiler/source:Span", ptr %l8
  %t79 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2edata(ptr %v0, ptr %v1, ptr %t69, i32 %t70, i32 %t71, i64 %t72, %"compiler/source:Span" %t73, i1 true)
  store { i64, ptr } %t79, ptr %l32
  br label %bb9
bb9:
  %t80 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t80, ptr %rv
  br label %ret
bb10:
  br i1 true, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d471, i32 0, i32 1) }, ptr %l33, !tbaa !27
  %t81 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t81, ptr %l34, !tbaa !27
  %t82 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t83 = extractvalue { i64, ptr } %t82, 0
  store i64 %t83, ptr %l35, !tbaa !24
  %t84 = load i64, ptr %l35, !tbaa !24
  %t85 = mul i64 %t84, 1
  %t86 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t85)
  %t87 = insertvalue { i64, ptr } undef, i64 %t84, 0
  %t88 = insertvalue { i64, ptr } %t87, ptr %t86, 1
  store { i64, ptr } %t88, ptr %l36, !tbaa !27
  %t89 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t90 = load ptr, ptr %t89, !tbaa !27
  %t91 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !27
  %t93 = load i64, ptr %l35, !tbaa !24
  %t94 = mul i64 %t93, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t90, ptr %t92, i64 %t94, i1 false)
  %t95 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t95, ptr %l34, !tbaa !27
  %t96 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t96, ptr %rv
  br label %ret
bb14:
  call void @__olang_check_failed(ptr @olang_loc_37dcdc821423a995_2a435c3b360fb831)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3afnEm_2esubprogram(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l10 = alloca i1
  %l14 = alloca i1
  %l23 = alloca i64
  %l31 = alloca i64
  %l32 = alloca ptr
  %l34 = alloca i64
  %l36 = alloca ptr
  %l38 = alloca i64
  %l42 = alloca { i64, ptr }
  %l44 = alloca { i64, ptr }
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i64
  %l52 = alloca i64
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l1, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = getelementptr %"compiler/mir:Fn", ptr %t6, i32 0, i32 2
  %t9 = load i64, ptr %t8, !tbaa !24
  %t11 = icmp slt i64 %t9, 0
  br i1 %t11, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb6
bb2:
  %t13 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr %"compiler/mir:Fn", ptr %t13, i32 0, i32 3
  %t16 = getelementptr %"compiler/source:Span", ptr %t15, i32 0, i32 0
  %t17 = load i32, ptr %t16, !tbaa !23
  %t19 = icmp eq i32 %t17, 0
  br i1 %t19, label %bb3, label %bb4
bb3:
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr %"compiler/mir:Fn", ptr %t21, i32 0, i32 3
  %t24 = getelementptr %"compiler/source:Span", ptr %t23, i32 0, i32 1
  %t25 = load i32, ptr %t24, !tbaa !23
  %t27 = icmp eq i32 %t25, 0
  store i1 %t27, ptr %l14, !tbaa !21
  br label %bb5
bb4:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb5
bb5:
  %t29 = load i1, ptr %l14, !tbaa !21
  store i1 %t29, ptr %l10, !tbaa !21
  br label %bb6
bb6:
  %t30 = load i1, ptr %l10, !tbaa !21
  br i1 %t30, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb8:
  br label %bb9
bb9:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/emit:fnEm", ptr %t31, i32 0, i32 0
  %t34 = load ptr, ptr %t33, !tbaa !29
  store ptr %t34, ptr %l2, !tbaa !29
  %t36 = load ptr, ptr %l2, !tbaa !29
  %t37 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr %"compiler/mir:Fn", ptr %t37, i32 0, i32 2
  %t40 = load i64, ptr %t39, !tbaa !24
  %t43 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgFile(ptr %v0, ptr %t36, i64 %t40)
  store i64 %t43, ptr %l23
  br label %bb10
bb10:
  %t44 = load i64, ptr %l23, !tbaa !24
  store i64 %t44, ptr %l3, !tbaa !24
  %t45 = load ptr, ptr %l2, !tbaa !29
  %t47 = getelementptr %"compiler/emit:Emitter", ptr %t45, i32 0, i32 2
  %t48 = load ptr, ptr %t47, !tbaa !29
  %t49 = load ptr, ptr %l1, !tbaa !29
  %t51 = getelementptr %"compiler/mir:Fn", ptr %t49, i32 0, i32 2
  %t52 = load i64, ptr %t51, !tbaa !24
  %t53 = load ptr, ptr %l1, !tbaa !29
  %t55 = getelementptr %"compiler/mir:Fn", ptr %t53, i32 0, i32 3
  %t56 = getelementptr %"compiler/source:Span", ptr %t55, i32 0, i32 0
  %t57 = load i32, ptr %t56, !tbaa !23
  %t59 = sext i32 %t57 to i64
  %t63 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLineAt(ptr %v0, ptr %t48, i64 %t52, i64 %t59)
  store i64 %t63, ptr %l31
  br label %bb11
bb11:
  %t64 = load i64, ptr %l31, !tbaa !24
  store i64 %t64, ptr %l4, !tbaa !24
  %t65 = load ptr, ptr %l0, !tbaa !29
  store ptr %t65, ptr %l32, !tbaa !29
  %t66 = load ptr, ptr %l2, !tbaa !29
  %t68 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgNew(ptr %v0, ptr %t66)
  store i64 %t68, ptr %l34
  br label %bb12
bb12:
  %t69 = load i64, ptr %l34, !tbaa !24
  %t70 = load ptr, ptr %l32, !tbaa !29
  %t71 = getelementptr %"compiler/emit:fnEm", ptr %t70, i32 0, i32 17
  store i64 %t69, ptr %t71, !tbaa !24
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr %"compiler/emit:fnEm", ptr %t72, i32 0, i32 20
  store ptr %t74, ptr %l36, !tbaa !29
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/emit:fnEm", ptr %t75, i32 0, i32 17
  %t78 = load i64, ptr %t77, !tbaa !24
  store i64 %t78, ptr %l38, !tbaa !24
  %t79 = load ptr, ptr %l2, !tbaa !29
  %t80 = load ptr, ptr %l1, !tbaa !29
  %t82 = getelementptr %"compiler/mir:Fn", ptr %t80, i32 0, i32 0
  %t83 = load { i64, [2 x i64] }, ptr %t82
  %t86 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgName(ptr %v0, ptr %s0, ptr %t79, { i64, [2 x i64] } %t83)
  store { i64, ptr } %t86, ptr %l42
  br label %bb13
bb13:
  %t87 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t88 = extractvalue { i64, ptr } %t87, 0
  %t89 = extractvalue { i64, ptr } %t87, 1
  %t90 = mul i64 %t88, 1
  %t91 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t90)
  call void @llvm.memcpy.p0.p0.i64(ptr %t91, ptr %t89, i64 %t90, i1 false)
  %t92 = insertvalue { i64, ptr } undef, i64 %t88, 0
  %t93 = insertvalue { i64, ptr } %t92, ptr %t91, 1
  %t95 = call { i64, ptr } @compiler_2femit_2eescape(ptr %s0, ptr %s0, { i64, ptr } %t93)
  store { i64, ptr } %t95, ptr %l44
  br label %bb14
bb14:
  %t96 = load i64, ptr %l3, !tbaa !24
  store i64 %t96, ptr %l45, !tbaa !24
  %t97 = load i64, ptr %l3, !tbaa !24
  store i64 %t97, ptr %l46, !tbaa !24
  %t98 = load i64, ptr %l4, !tbaa !24
  store i64 %t98, ptr %l47, !tbaa !24
  %t99 = load ptr, ptr %l2, !tbaa !29
  %t101 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgSubTy(ptr %v0, ptr %t99)
  store i64 %t101, ptr %l49
  br label %bb15
bb15:
  %t102 = load i64, ptr %l4, !tbaa !24
  store i64 %t102, ptr %l50, !tbaa !24
  %t103 = load ptr, ptr %l2, !tbaa !29
  %t105 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgCu(ptr %v0, ptr %t103)
  store i64 %t105, ptr %l52
  br label %bb16
bb16:
  %t106 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d472, i32 0, i32 1) }, 1
  %t107 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d472, i32 0, i32 1) }, 0
  %t108 = load i64, ptr %l38, !tbaa !24
  %t109 = call i64 @__olang_fmt_i64(ptr null, i64 %t108)
  %t110 = add i64 %t107, %t109
  %t111 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d473, i32 0, i32 1) }, 1
  %t112 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d473, i32 0, i32 1) }, 0
  %t113 = add i64 %t110, %t112
  %t114 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t115 = extractvalue { i64, ptr } %t114, 1
  %t116 = extractvalue { i64, ptr } %t114, 0
  %t117 = add i64 %t113, %t116
  %t118 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d474, i32 0, i32 1) }, 1
  %t119 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d474, i32 0, i32 1) }, 0
  %t120 = add i64 %t117, %t119
  %t121 = load i64, ptr %l45, !tbaa !24
  %t122 = call i64 @__olang_fmt_i64(ptr null, i64 %t121)
  %t123 = add i64 %t120, %t122
  %t124 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d475, i32 0, i32 1) }, 1
  %t125 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d475, i32 0, i32 1) }, 0
  %t126 = add i64 %t123, %t125
  %t127 = load i64, ptr %l46, !tbaa !24
  %t128 = call i64 @__olang_fmt_i64(ptr null, i64 %t127)
  %t129 = add i64 %t126, %t128
  %t130 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d476, i32 0, i32 1) }, 1
  %t131 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d476, i32 0, i32 1) }, 0
  %t132 = add i64 %t129, %t131
  %t133 = load i64, ptr %l47, !tbaa !24
  %t134 = call i64 @__olang_fmt_i64(ptr null, i64 %t133)
  %t135 = add i64 %t132, %t134
  %t136 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d477, i32 0, i32 1) }, 1
  %t137 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d477, i32 0, i32 1) }, 0
  %t138 = add i64 %t135, %t137
  %t139 = load i64, ptr %l49, !tbaa !24
  %t140 = call i64 @__olang_fmt_i64(ptr null, i64 %t139)
  %t141 = add i64 %t138, %t140
  %t142 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d478, i32 0, i32 1) }, 1
  %t143 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d478, i32 0, i32 1) }, 0
  %t144 = add i64 %t141, %t143
  %t145 = load i64, ptr %l50, !tbaa !24
  %t146 = call i64 @__olang_fmt_i64(ptr null, i64 %t145)
  %t147 = add i64 %t144, %t146
  %t148 = extractvalue { i64, ptr } { i64 38, ptr getelementptr inbounds (<{ i64, [38 x i8] }>, ptr @.d479, i32 0, i32 1) }, 1
  %t149 = extractvalue { i64, ptr } { i64 38, ptr getelementptr inbounds (<{ i64, [38 x i8] }>, ptr @.d479, i32 0, i32 1) }, 0
  %t150 = add i64 %t147, %t149
  %t151 = load i64, ptr %l52, !tbaa !24
  %t152 = call i64 @__olang_fmt_i64(ptr null, i64 %t151)
  %t153 = add i64 %t150, %t152
  %t154 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d480, i32 0, i32 1) }, 1
  %t155 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d480, i32 0, i32 1) }, 0
  %t156 = add i64 %t153, %t155
  %t157 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t156)
  call void @olang_textcopy(ptr %t157, ptr %t106, i64 %t107)
  %t158 = getelementptr i8, ptr %t157, i64 %t107
  %t159 = call i64 @__olang_fmt_i64(ptr %t158, i64 %t108)
  %t160 = getelementptr i8, ptr %t158, i64 %t109
  call void @olang_textcopy(ptr %t160, ptr %t111, i64 %t112)
  %t161 = getelementptr i8, ptr %t160, i64 %t112
  call void @olang_textcopy(ptr %t161, ptr %t115, i64 %t116)
  %t162 = getelementptr i8, ptr %t161, i64 %t116
  call void @olang_textcopy(ptr %t162, ptr %t118, i64 %t119)
  %t163 = getelementptr i8, ptr %t162, i64 %t119
  %t164 = call i64 @__olang_fmt_i64(ptr %t163, i64 %t121)
  %t165 = getelementptr i8, ptr %t163, i64 %t122
  call void @olang_textcopy(ptr %t165, ptr %t124, i64 %t125)
  %t166 = getelementptr i8, ptr %t165, i64 %t125
  %t167 = call i64 @__olang_fmt_i64(ptr %t166, i64 %t127)
  %t168 = getelementptr i8, ptr %t166, i64 %t128
  call void @olang_textcopy(ptr %t168, ptr %t130, i64 %t131)
  %t169 = getelementptr i8, ptr %t168, i64 %t131
  %t170 = call i64 @__olang_fmt_i64(ptr %t169, i64 %t133)
  %t171 = getelementptr i8, ptr %t169, i64 %t134
  call void @olang_textcopy(ptr %t171, ptr %t136, i64 %t137)
  %t172 = getelementptr i8, ptr %t171, i64 %t137
  %t173 = call i64 @__olang_fmt_i64(ptr %t172, i64 %t139)
  %t174 = getelementptr i8, ptr %t172, i64 %t140
  call void @olang_textcopy(ptr %t174, ptr %t142, i64 %t143)
  %t175 = getelementptr i8, ptr %t174, i64 %t143
  %t176 = call i64 @__olang_fmt_i64(ptr %t175, i64 %t145)
  %t177 = getelementptr i8, ptr %t175, i64 %t146
  call void @olang_textcopy(ptr %t177, ptr %t148, i64 %t149)
  %t178 = getelementptr i8, ptr %t177, i64 %t149
  %t179 = call i64 @__olang_fmt_i64(ptr %t178, i64 %t151)
  %t180 = getelementptr i8, ptr %t178, i64 %t152
  call void @olang_textcopy(ptr %t180, ptr %t154, i64 %t155)
  %t181 = insertvalue { i64, ptr } undef, i64 %t156, 0
  %t182 = insertvalue { i64, ptr } %t181, ptr %t157, 1
  %t184 = extractvalue { i64, ptr } %t182, 0
  %t185 = extractvalue { i64, ptr } %t182, 1
  %t186 = mul i64 %t184, 1
  %t187 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t186)
  call void @llvm.memcpy.p0.p0.i64(ptr %t187, ptr %t185, i64 %t186, i1 false)
  %t188 = insertvalue { i64, ptr } undef, i64 %t184, 0
  %t189 = insertvalue { i64, ptr } %t188, ptr %t187, 1
  %t190 = load ptr, ptr %l36, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s0, ptr %t190, { i64, ptr } %t189)
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3afnEm_2etrace(ptr %v0, ptr %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca %"compiler/mir:BasicBlock"
  %l8 = alloca { i64, [8 x i64] }
  %l9 = alloca %"compiler/source:Span"
  %l10 = alloca %"compiler/source:Span"
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l16 = alloca i1
  %l21 = alloca { i64, ptr }
  %l26 = alloca ptr
  %l27 = alloca ptr
  %l28 = alloca %"compiler/source:Span"
  %l32 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l49 = alloca i32
  %l58 = alloca { i64, ptr }
  %l79 = alloca i64
  %l83 = alloca i64
  %l84 = alloca i32
  %l87 = alloca { i64, ptr }
  %l90 = alloca { i64, ptr }
  %l93 = alloca i1
  %l97 = alloca { i64, ptr }
  %l103 = alloca { i64, ptr }
  %l108 = alloca { i64, ptr }
  %l115 = alloca ptr
  %l116 = alloca { i64, ptr }
  %l122 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2etraced(ptr %v0, ptr %t4)
  store i1 %t6, ptr %l16
  br label %bb1
bb1:
  %t7 = load i1, ptr %l16, !tbaa !21
  %t8 = xor i1 %t7, true
  br i1 %t8, label %bb2, label %bb3
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/emit:fnEm", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t14 = load %"compiler/source:Span", ptr %l1
  %t17 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3aFn_2eRaiseText(ptr %v0, ptr %t13, %"compiler/source:Span" %t14)
  store { i64, ptr } %t17, ptr %l21
  br label %bb4
bb3:
  br label %bb12
bb4:
  %t18 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t18, 0
  %t21 = icmp sgt i64 %t19, 0
  br i1 %t21, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s2
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/emit:fnEm", ptr %t23, i32 0, i32 0
  %t26 = load ptr, ptr %t25, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s2, ptr %s2, ptr %t26, { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d481, i32 0, i32 1) }, { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d482, i32 0, i32 1) })
  br label %bb7
bb6:
  br label %bb11
bb7:
  %t28 = load ptr, ptr %l0, !tbaa !29
  store ptr %t28, ptr %l26, !tbaa !29
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l27, !tbaa !29
  %t30 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t30, ptr %l28
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/emit:fnEm", ptr %t31, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t35 = load %"compiler/source:Span", ptr %l1
  %t38 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3aFn_2eRaiseText(ptr %v0, ptr %t34, %"compiler/source:Span" %t35)
  store { i64, ptr } %t38, ptr %l32
  br label %bb8
bb8:
  %t39 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d483, i32 0, i32 1) }, 1
  %t40 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d483, i32 0, i32 1) }, 0
  %t41 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t42 = extractvalue { i64, ptr } %t41, 1
  %t43 = extractvalue { i64, ptr } %t41, 0
  %t44 = add i64 %t40, %t43
  %t45 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d484, i32 0, i32 1) }, 1
  %t46 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d484, i32 0, i32 1) }, 0
  %t47 = add i64 %t44, %t46
  %t48 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t47)
  call void @olang_textcopy(ptr %t48, ptr %t39, i64 %t40)
  %t49 = getelementptr i8, ptr %t48, i64 %t40
  call void @olang_textcopy(ptr %t49, ptr %t42, i64 %t43)
  %t50 = getelementptr i8, ptr %t49, i64 %t43
  call void @olang_textcopy(ptr %t50, ptr %t45, i64 %t46)
  %t51 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t52 = insertvalue { i64, ptr } %t51, ptr %t48, 1
  %t54 = extractvalue { i64, ptr } %t52, 0
  %t55 = extractvalue { i64, ptr } %t52, 1
  %t56 = mul i64 %t54, 1
  %t57 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t56)
  call void @llvm.memcpy.p0.p0.i64(ptr %t57, ptr %t55, i64 %t56, i1 false)
  %t58 = insertvalue { i64, ptr } undef, i64 %t54, 0
  %t59 = insertvalue { i64, ptr } %t58, ptr %t57, 1
  %t60 = load ptr, ptr %l27, !tbaa !29
  %t61 = load %"compiler/source:Span", ptr %l28
  %t63 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elocated(ptr %v0, ptr %s2, ptr %s2, ptr %t60, %"compiler/source:Span" %t61, { i64, ptr } %t59)
  store { i64, ptr } %t63, ptr %l35
  br label %bb9
bb9:
  %t64 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d485, i32 0, i32 1) }, 1
  %t65 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d485, i32 0, i32 1) }, 0
  %t66 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t67 = extractvalue { i64, ptr } %t66, 1
  %t68 = extractvalue { i64, ptr } %t66, 0
  %t69 = add i64 %t65, %t68
  %t70 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d486, i32 0, i32 1) }, 1
  %t71 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d486, i32 0, i32 1) }, 0
  %t72 = add i64 %t69, %t71
  %t73 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t72)
  call void @olang_textcopy(ptr %t73, ptr %t64, i64 %t65)
  %t74 = getelementptr i8, ptr %t73, i64 %t65
  call void @olang_textcopy(ptr %t74, ptr %t67, i64 %t68)
  %t75 = getelementptr i8, ptr %t74, i64 %t68
  call void @olang_textcopy(ptr %t75, ptr %t70, i64 %t71)
  %t76 = insertvalue { i64, ptr } undef, i64 %t72, 0
  %t77 = insertvalue { i64, ptr } %t76, ptr %t73, 1
  %t79 = extractvalue { i64, ptr } %t77, 0
  %t80 = extractvalue { i64, ptr } %t77, 1
  %t81 = mul i64 %t79, 1
  %t82 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t81)
  call void @llvm.memcpy.p0.p0.i64(ptr %t82, ptr %t80, i64 %t81, i1 false)
  %t83 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t84 = insertvalue { i64, ptr } %t83, ptr %t82, 1
  %t85 = load ptr, ptr %l26, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s2, ptr %t85, { i64, ptr } %t84)
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb12:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/emit:fnEm", ptr %t87, i32 0, i32 22
  %t90 = load i1, ptr %t89, !tbaa !21
  %t92 = xor i1 %t90, true
  br i1 %t92, label %bb13, label %bb14
bb13:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/emit:fnEm", ptr %t94, i32 0, i32 22
  store i1 true, ptr %t96, !tbaa !21
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/emit:fnEm", ptr %t97, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !29
  %t102 = getelementptr %"compiler/mir:Fn", ptr %t100, i32 0, i32 9
  store ptr %t102, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb15
bb14:
  br label %bb45
bb15:
  store %olang.scope zeroinitializer, ptr %s7
  %t104 = load ptr, ptr %l2, !tbaa !29
  %t105 = load i64, ptr %l3, !tbaa !24
  %t108 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBasicBlock_3e_2eRu_H05f2a0ad75f6ffeece9ab76b4dcd7cb0(ptr %v0, ptr %t104, i64 %t105)
  %t109 = extractvalue { i32, { i64, ptr } } %t108, 1
  %t110 = extractvalue { i32, { i64, ptr } } %t108, 0
  store i32 %t110, ptr %l49
  %t111 = icmp ne i32 %t110, 0
  br i1 %t111, label %bb17, label %ok.112
ok.112:
  store { i64, ptr } %t109, ptr %l48
  br label %bb16
bb16:
  %t113 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t113, ptr %l45, !tbaa !27
  br label %bb21
bb17:
  %t114 = load i32, ptr %l49, !tbaa !23
  %t115 = ashr i32 %t114, 16
  %t117 = icmp eq i32 %t115, 1
  br i1 %t117, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_2ea555a1037c9329_7e95fb4c4c24cb65)
  unreachable
bb20:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s7)
  br label %bb44
bb21:
  %t119 = load { i64, ptr }, ptr %l45, !tbaa !27
  store { i64, ptr } %t119, ptr %l4, !tbaa !27
  %t120 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t122 = extractvalue { i64, ptr } %t120, 0
  store i64 %t122, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb22
bb22:
  store %olang.scope zeroinitializer, ptr %s8
  %t124 = load i64, ptr %l6, !tbaa !24
  %t125 = load i64, ptr %l5, !tbaa !24
  %t128 = icmp slt i64 %t124, %t125
  %t130 = xor i1 %t128, true
  br i1 %t130, label %bb23, label %bb24
bb23:
  call void @__olang_scope_close(ptr %s8)
  br label %bb42
bb24:
  br label %bb25
bb25:
  %t132 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t132, ptr %l58, !tbaa !27
  %t133 = load i64, ptr %l6, !tbaa !24
  %t135 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t136 = load ptr, ptr %t135, !tbaa !27
  %t137 = getelementptr %"compiler/mir:BasicBlock", ptr %t136, i64 %t133
  %t138 = load %"compiler/mir:BasicBlock", ptr %t137
  store %"compiler/mir:BasicBlock" %t138, ptr %l7
  %t140 = getelementptr %"compiler/mir:BasicBlock", ptr %l7, i32 0, i32 1
  %t141 = load { i64, [8 x i64] }, ptr %t140
  store { i64, [8 x i64] } %t141, ptr %l8
  %t143 = load { i64, [8 x i64] }, ptr %l8
  %t145 = extractvalue { i64, [8 x i64] } %t143, 0
  %t146 = icmp eq i64 %t145, 4
  br i1 %t146, label %bb26, label %bb27
bb26:
  %t148 = getelementptr { i64, [8 x i64] }, ptr %l8, i32 0, i32 1
  %t149 = getelementptr { %"compiler/source:Span", i32 }, ptr %t148, i32 0, i32 0
  %t150 = load %"compiler/source:Span", ptr %t149
  store %"compiler/source:Span" %t150, ptr %l9
  br label %bb28
bb27:
  br label %bb30
bb28:
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t154 = getelementptr %"compiler/emit:fnEm", ptr %t152, i32 0, i32 21
  %t155 = getelementptr %"compiler/source:Span", ptr %l9, i32 0, i32 0
  %t156 = load i32, ptr %t155, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI32_2c_20I64_3e_2ePut_3cI32_2c_20I64_3e(ptr %v0, ptr %t154, i32 %t156, i64 1)
  br label %bb29
bb29:
  br label %bb40
bb30:
  %t159 = load { i64, [8 x i64] }, ptr %l8
  %t161 = extractvalue { i64, [8 x i64] } %t159, 0
  %t162 = icmp eq i64 %t161, 7
  br i1 %t162, label %bb31, label %bb32
bb31:
  %t164 = getelementptr { i64, [8 x i64] }, ptr %l8, i32 0, i32 1
  %t165 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t164, i32 0, i32 0
  %t166 = load %"compiler/source:Span", ptr %t165
  store %"compiler/source:Span" %t166, ptr %l10
  br label %bb33
bb32:
  br label %bb35
bb33:
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t170 = getelementptr %"compiler/emit:fnEm", ptr %t168, i32 0, i32 21
  %t171 = getelementptr %"compiler/source:Span", ptr %l10, i32 0, i32 0
  %t172 = load i32, ptr %t171, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI32_2c_20I64_3e_2ePut_3cI32_2c_20I64_3e(ptr %v0, ptr %t170, i32 %t172, i64 2)
  br label %bb34
bb34:
  br label %bb40
bb35:
  br i1 true, label %bb36, label %bb37
bb36:
  br label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb40
bb39:
  call void @__olang_check_failed(ptr @olang_loc_bf62c1c7e423c058_299389d9c8f1c434)
  unreachable
bb40:
  call void @__olang_scope_close(ptr %s8)
  br label %bb41
bb41:
  %t175 = load i64, ptr %l6, !tbaa !24
  %t177 = add i64 %t175, 1
  store i64 %t177, ptr %l6, !tbaa !24
  br label %bb22
bb42:
  %t179 = load i64, ptr %l3, !tbaa !24
  %t180 = load i64, ptr %l5, !tbaa !24
  %t183 = add i64 %t179, %t180
  store i64 %t183, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s7)
  br label %bb43
bb43:
  br label %bb15
bb44:
  br label %bb45
bb45:
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t187 = getelementptr %"compiler/emit:fnEm", ptr %t185, i32 0, i32 21
  %t188 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t189 = load i32, ptr %t188, !tbaa !23
  %t192 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI32_2c_20I64_3e_2eGet_3cI32_2c_20I64_3e(ptr %v0, ptr %t187, i32 %t189)
  %t193 = extractvalue { i32, i64 } %t192, 1
  %t194 = extractvalue { i32, i64 } %t192, 0
  store i32 %t194, ptr %l84
  %t195 = icmp ne i32 %t194, 0
  br i1 %t195, label %bb47, label %ok.196
ok.196:
  store i64 %t193, ptr %l83
  br label %bb46
bb46:
  %t197 = load i64, ptr %l83, !tbaa !24
  store i64 %t197, ptr %l79, !tbaa !24
  br label %bb49
bb47:
  br label %bb48
bb48:
  call void @__olang_ert_req_clear()
  store i64 0, ptr %l79, !tbaa !24
  br label %bb49
bb49:
  %t198 = load i64, ptr %l79, !tbaa !24
  store i64 %t198, ptr %l11, !tbaa !24
  %t199 = load i64, ptr %l11, !tbaa !24
  %t201 = icmp eq i64 %t199, 1
  br i1 %t201, label %bb50, label %bb51
bb50:
  store { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d487, i32 0, i32 1) }, ptr %l87, !tbaa !27
  br label %bb55
bb51:
  %t203 = load i64, ptr %l11, !tbaa !24
  %t205 = icmp eq i64 %t203, 2
  br i1 %t205, label %bb52, label %bb53
bb52:
  store { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d488, i32 0, i32 1) }, ptr %l90, !tbaa !27
  br label %bb54
bb53:
  store { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d489, i32 0, i32 1) }, ptr %l90, !tbaa !27
  br label %bb54
bb54:
  %t207 = load { i64, ptr }, ptr %l90, !tbaa !27
  store { i64, ptr } %t207, ptr %l87, !tbaa !27
  br label %bb55
bb55:
  %t208 = load { i64, ptr }, ptr %l87, !tbaa !27
  store { i64, ptr } %t208, ptr %l12, !tbaa !27
  %t209 = load i64, ptr %l11, !tbaa !24
  %t211 = icmp eq i64 %t209, 0
  br i1 %t211, label %bb56, label %bb57
bb56:
  %t213 = load ptr, ptr %l0, !tbaa !29
  %t215 = getelementptr %"compiler/emit:fnEm", ptr %t213, i32 0, i32 1
  %t216 = load ptr, ptr %t215, !tbaa !29
  %t217 = load %"compiler/source:Span", ptr %l1
  %t220 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3aFn_2eRaiseText(ptr %v0, ptr %t216, %"compiler/source:Span" %t217)
  store { i64, ptr } %t220, ptr %l97
  br label %bb58
bb57:
  store i1 false, ptr %l93, !tbaa !21
  br label %bb59
bb58:
  %t221 = load { i64, ptr }, ptr %l97, !tbaa !27
  %t222 = extractvalue { i64, ptr } %t221, 0
  %t224 = icmp sgt i64 %t222, 0
  store i1 %t224, ptr %l93, !tbaa !21
  br label %bb59
bb59:
  %t226 = load i1, ptr %l93, !tbaa !21
  br i1 %t226, label %bb60, label %bb61
bb60:
  %t227 = load ptr, ptr %l0, !tbaa !29
  %t229 = getelementptr %"compiler/emit:fnEm", ptr %t227, i32 0, i32 1
  %t230 = load ptr, ptr %t229, !tbaa !29
  %t231 = load %"compiler/source:Span", ptr %l1
  %t234 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3aFn_2eRaiseText(ptr %v0, ptr %t230, %"compiler/source:Span" %t231)
  store { i64, ptr } %t234, ptr %l103
  br label %bb62
bb61:
  br label %bb63
bb62:
  %t235 = load { i64, ptr }, ptr %l103, !tbaa !27
  %t236 = extractvalue { i64, ptr } %t235, 1
  %t237 = extractvalue { i64, ptr } %t235, 0
  %t238 = load ptr, ptr @__olang_prog_scope
  %t239 = call ptr @__olang_scope_alloc(ptr %t238, i64 %t237)
  call void @olang_textcopy(ptr %t239, ptr %t236, i64 %t237)
  %t240 = insertvalue { i64, ptr } undef, i64 %t237, 0
  %t241 = insertvalue { i64, ptr } %t240, ptr %t239, 1
  %t243 = load ptr, ptr @__olang_prog_scope
  %t244 = extractvalue { i64, ptr } %t241, 0
  %t245 = extractvalue { i64, ptr } %t241, 1
  %t246 = mul i64 %t244, 1
  %t247 = call ptr @__olang_scope_alloc(ptr %t243, i64 %t246)
  call void @llvm.memcpy.p0.p0.i64(ptr %t247, ptr %t245, i64 %t246, i1 false)
  %t248 = insertvalue { i64, ptr } undef, i64 %t244, 0
  %t249 = insertvalue { i64, ptr } %t248, ptr %t247, 1
  store { i64, ptr } %t249, ptr %l12, !tbaa !27
  br label %bb63
bb63:
  %t251 = load i64, ptr %l11, !tbaa !24
  %t253 = icmp eq i64 %t251, 1
  br i1 %t253, label %bb64, label %bb65
bb64:
  store { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d490, i32 0, i32 1) }, ptr %l108, !tbaa !27
  br label %bb66
bb65:
  store { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d491, i32 0, i32 1) }, ptr %l108, !tbaa !27
  br label %bb66
bb66:
  %t255 = load { i64, ptr }, ptr %l108, !tbaa !27
  store { i64, ptr } %t255, ptr %l13, !tbaa !27
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t258 = getelementptr %"compiler/emit:fnEm", ptr %t256, i32 0, i32 0
  %t259 = load ptr, ptr %t258, !tbaa !29
  %t260 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t261 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t262 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d492, i32 0, i32 1) }, 1
  %t263 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d492, i32 0, i32 1) }, 0
  %t265 = extractvalue { i64, ptr } %t261, 1
  %t266 = extractvalue { i64, ptr } %t261, 0
  %t267 = add i64 %t263, %t266
  %t268 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d493, i32 0, i32 1) }, 1
  %t269 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d493, i32 0, i32 1) }, 0
  %t270 = add i64 %t267, %t269
  %t271 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t270)
  call void @olang_textcopy(ptr %t271, ptr %t262, i64 %t263)
  %t272 = getelementptr i8, ptr %t271, i64 %t263
  call void @olang_textcopy(ptr %t272, ptr %t265, i64 %t266)
  %t273 = getelementptr i8, ptr %t272, i64 %t266
  call void @olang_textcopy(ptr %t273, ptr %t268, i64 %t269)
  %t274 = insertvalue { i64, ptr } undef, i64 %t270, 0
  %t275 = insertvalue { i64, ptr } %t274, ptr %t271, 1
  %t277 = extractvalue { i64, ptr } %t275, 0
  %t278 = extractvalue { i64, ptr } %t275, 1
  %t279 = mul i64 %t277, 1
  %t280 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t279)
  call void @llvm.memcpy.p0.p0.i64(ptr %t280, ptr %t278, i64 %t279, i1 false)
  %t281 = insertvalue { i64, ptr } undef, i64 %t277, 0
  %t282 = insertvalue { i64, ptr } %t281, ptr %t280, 1
  %t283 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %t283, ptr %s0, ptr %t259, { i64, ptr } %t260, { i64, ptr } %t282)
  br label %bb67
bb67:
  %t287 = load ptr, ptr %l0, !tbaa !29
  store ptr %t287, ptr %l115, !tbaa !29
  %t288 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t288, ptr %l116, !tbaa !27
  %t289 = load ptr, ptr %l0, !tbaa !29
  %t290 = load %"compiler/source:Span", ptr %l1
  %t291 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t292 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d494, i32 0, i32 1) }, 1
  %t293 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d494, i32 0, i32 1) }, 0
  %t295 = extractvalue { i64, ptr } %t291, 1
  %t296 = extractvalue { i64, ptr } %t291, 0
  %t297 = add i64 %t293, %t296
  %t298 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d495, i32 0, i32 1) }, 1
  %t299 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d495, i32 0, i32 1) }, 0
  %t300 = add i64 %t297, %t299
  %t301 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t300)
  call void @olang_textcopy(ptr %t301, ptr %t292, i64 %t293)
  %t302 = getelementptr i8, ptr %t301, i64 %t293
  call void @olang_textcopy(ptr %t302, ptr %t295, i64 %t296)
  %t303 = getelementptr i8, ptr %t302, i64 %t296
  call void @olang_textcopy(ptr %t303, ptr %t298, i64 %t299)
  %t304 = insertvalue { i64, ptr } undef, i64 %t300, 0
  %t305 = insertvalue { i64, ptr } %t304, ptr %t301, 1
  %t307 = extractvalue { i64, ptr } %t305, 0
  %t308 = extractvalue { i64, ptr } %t305, 1
  %t309 = mul i64 %t307, 1
  %t310 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t309)
  call void @llvm.memcpy.p0.p0.i64(ptr %t310, ptr %t308, i64 %t309, i1 false)
  %t311 = insertvalue { i64, ptr } undef, i64 %t307, 0
  %t312 = insertvalue { i64, ptr } %t311, ptr %t310, 1
  %t316 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elocated(ptr %v0, ptr %s0, ptr %s0, ptr %t289, %"compiler/source:Span" %t290, { i64, ptr } %t312)
  store { i64, ptr } %t316, ptr %l122
  br label %bb68
bb68:
  %t317 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d496, i32 0, i32 1) }, 1
  %t318 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d496, i32 0, i32 1) }, 0
  %t319 = load { i64, ptr }, ptr %l116, !tbaa !27
  %t320 = extractvalue { i64, ptr } %t319, 1
  %t321 = extractvalue { i64, ptr } %t319, 0
  %t322 = add i64 %t318, %t321
  %t323 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d497, i32 0, i32 1) }, 1
  %t324 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d497, i32 0, i32 1) }, 0
  %t325 = add i64 %t322, %t324
  %t326 = load { i64, ptr }, ptr %l122, !tbaa !27
  %t327 = extractvalue { i64, ptr } %t326, 1
  %t328 = extractvalue { i64, ptr } %t326, 0
  %t329 = add i64 %t325, %t328
  %t330 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d498, i32 0, i32 1) }, 1
  %t331 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d498, i32 0, i32 1) }, 0
  %t332 = add i64 %t329, %t331
  %t333 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t332)
  call void @olang_textcopy(ptr %t333, ptr %t317, i64 %t318)
  %t334 = getelementptr i8, ptr %t333, i64 %t318
  call void @olang_textcopy(ptr %t334, ptr %t320, i64 %t321)
  %t335 = getelementptr i8, ptr %t334, i64 %t321
  call void @olang_textcopy(ptr %t335, ptr %t323, i64 %t324)
  %t336 = getelementptr i8, ptr %t335, i64 %t324
  call void @olang_textcopy(ptr %t336, ptr %t327, i64 %t328)
  %t337 = getelementptr i8, ptr %t336, i64 %t328
  call void @olang_textcopy(ptr %t337, ptr %t330, i64 %t331)
  %t338 = insertvalue { i64, ptr } undef, i64 %t332, 0
  %t339 = insertvalue { i64, ptr } %t338, ptr %t333, 1
  %t341 = extractvalue { i64, ptr } %t339, 0
  %t342 = extractvalue { i64, ptr } %t339, 1
  %t343 = mul i64 %t341, 1
  %t344 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t343)
  call void @llvm.memcpy.p0.p0.i64(ptr %t344, ptr %t342, i64 %t343, i1 false)
  %t345 = insertvalue { i64, ptr } undef, i64 %t341, 0
  %t346 = insertvalue { i64, ptr } %t345, ptr %t344, 1
  %t347 = load ptr, ptr %l115, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s0, ptr %t347, { i64, ptr } %t346)
  br label %bb69
bb69:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l5 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t8 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %v1, ptr %t4, i32 %a1)
  store { i64, ptr } %t8, ptr %l5
  br label %bb1
bb1:
  %t9 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t9, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3afnEm_2eunwindPop(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d499, i32 0, i32 1) }, 1
  %t5 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d499, i32 0, i32 1) }, 0
  %t7 = sext i32 %a1 to i64
  %t8 = call i64 @__olang_fmt_i64(ptr null, i64 %t7)
  %t9 = add i64 %t5, %t8
  %t10 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d500, i32 0, i32 1) }, 1
  %t11 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d500, i32 0, i32 1) }, 0
  %t12 = add i64 %t9, %t11
  %t13 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t12)
  call void @olang_textcopy(ptr %t13, ptr %t4, i64 %t5)
  %t14 = getelementptr i8, ptr %t13, i64 %t5
  %t15 = call i64 @__olang_fmt_i64(ptr %t14, i64 %t7)
  %t16 = getelementptr i8, ptr %t14, i64 %t8
  call void @olang_textcopy(ptr %t16, ptr %t10, i64 %t11)
  %t17 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t13, 1
  %t20 = extractvalue { i64, ptr } %t18, 0
  %t21 = extractvalue { i64, ptr } %t18, 1
  %t22 = mul i64 %t20, 1
  %t23 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t22)
  call void @llvm.memcpy.p0.p0.i64(ptr %t23, ptr %t21, i64 %t22, i1 false)
  %t24 = insertvalue { i64, ptr } undef, i64 %t20, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t23, 1
  %t28 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t2, { i64, ptr } %t25)
  store { i64, ptr } %t28, ptr %l8
  br label %bb1
bb1:
  %t29 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t29, 0
  %t31 = extractvalue { i64, ptr } %t29, 1
  %t32 = mul i64 %t30, 1
  %t33 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t32)
  call void @llvm.memcpy.p0.p0.i64(ptr %t33, ptr %t31, i64 %t32, i1 false)
  %t34 = insertvalue { i64, ptr } undef, i64 %t30, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t33, 1
  %t36 = load ptr, ptr %l3, !tbaa !29
  %t38 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %t36, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d501, i32 0, i32 1) }, { i64, ptr } %t35, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d179, i32 0, i32 1) })
  store { i64, ptr } %t38, ptr %l10
  br label %bb2
bb2:
  %t39 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t40 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %t40, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d502, i32 0, i32 1) }, { i64, ptr } %t39, { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d503, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d173, i32 0, i32 1) })
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2euseRef(ptr %v0, ptr %v1, ptr %a0, { i64, [1 x i64] } %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [1 x i64] }
  %l3 = alloca i32
  %l7 = alloca { i64, ptr }
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store { i64, [1 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [1 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [1 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [1 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { i32 }, ptr %t6, i32 0, i32 0
  %t8 = load i32, ptr %t7
  store i32 %t8, ptr %l3, !tbaa !23
  br label %bb3
bb2:
  br label %bb4
bb3:
  store { i64, ptr } %a2, ptr %l7, !tbaa !27
  %t11 = load i32, ptr %l3, !tbaa !23
  %t13 = sext i32 %t11 to i64
  %t15 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !27
  %t17 = getelementptr i1, ptr %t16, i64 %t13
  store i1 true, ptr %t17, !tbaa !31
  store i1 false, ptr %rv
  br label %ret
bb4:
  %t19 = load { i64, [1 x i64] }, ptr %l1
  %t21 = extractvalue { i64, [1 x i64] } %t19, 0
  %t22 = icmp eq i64 %t21, 3
  br i1 %t22, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store i1 true, ptr %rv
  br label %ret
bb8:
  br i1 true, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store i1 false, ptr %rv
  br label %ret
bb12:
  call void @__olang_check_failed(ptr @olang_loc_7bc7193ce72d0d52_c947a9f9cc48c9f6)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2ewritesInto(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca %"compiler/mir:BasicBlock"
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca { i64, [21 x i64] }
  %l15 = alloca %"compiler/mir:Place"
  %l16 = alloca { i64, [15 x i64] }
  %l17 = alloca %"compiler/mir:Place"
  %l18 = alloca i32
  %l19 = alloca %"compiler/mir:Place"
  %l20 = alloca i32
  %l21 = alloca %"compiler/mir:Place"
  %l26 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l30 = alloca i32
  %l39 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l47 = alloca i32
  %l56 = alloca { i64, ptr }
  %l58 = alloca { i64, [21 x i64] }
  %l59 = alloca { i64, [21 x i64] }
  %l65 = alloca i1
  %l69 = alloca i1
  %l78 = alloca i1
  %l79 = alloca i1
  %l82 = alloca ptr
  %l87 = alloca i32
  %l88 = alloca i64
  %l100 = alloca i1
  %l101 = alloca i1
  %l104 = alloca ptr
  %l109 = alloca i32
  %l110 = alloca i64
  %l115 = alloca { i64, [21 x i64] }
  %l121 = alloca i1
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t8 = getelementptr %"compiler/mir:Fn", ptr %t4, i32 0, i32 9
  store ptr %t8, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t10 = load ptr, ptr %l3, !tbaa !29
  %t11 = load i64, ptr %l4, !tbaa !24
  %t14 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBasicBlock_3e_2eRu_H05f2a0ad75f6ffeece9ab76b4dcd7cb0(ptr %v0, ptr %t10, i64 %t11)
  %t15 = extractvalue { i32, { i64, ptr } } %t14, 1
  %t16 = extractvalue { i32, { i64, ptr } } %t14, 0
  store i32 %t16, ptr %l30
  %t17 = icmp ne i32 %t16, 0
  br i1 %t17, label %bb3, label %ok.18
ok.18:
  store { i64, ptr } %t15, ptr %l29
  br label %bb2
bb2:
  %t19 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t19, ptr %l26, !tbaa !27
  br label %bb7
bb3:
  %t20 = load i32, ptr %l30, !tbaa !23
  %t21 = ashr i32 %t20, 16
  %t23 = icmp eq i32 %t21, 1
  br i1 %t23, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  call void @__olang_check_failed(ptr @olang_loc_5dfa9b7395be5458_e24cfc313725a25c)
  unreachable
bb6:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %bb85
bb7:
  %t25 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t25, ptr %l5, !tbaa !27
  %t26 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t26, 0
  store i64 %t28, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t30 = load i64, ptr %l7, !tbaa !24
  %t31 = load i64, ptr %l6, !tbaa !24
  %t34 = icmp slt i64 %t30, %t31
  %t36 = xor i1 %t34, true
  br i1 %t36, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb83
bb10:
  br label %bb11
bb11:
  %t38 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t38, ptr %l39, !tbaa !27
  %t39 = load i64, ptr %l7, !tbaa !24
  %t41 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !27
  %t43 = getelementptr %"compiler/mir:BasicBlock", ptr %t42, i64 %t39
  %t44 = load %"compiler/mir:BasicBlock", ptr %t43
  store %"compiler/mir:BasicBlock" %t44, ptr %l8
  %t46 = getelementptr %"compiler/mir:BasicBlock", ptr %l8, i32 0, i32 0
  store ptr %t46, ptr %l9, !tbaa !29
  store i64 0, ptr %l10, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s5
  %t48 = load ptr, ptr %l9, !tbaa !29
  %t49 = load i64, ptr %l10, !tbaa !24
  %t52 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aStmt_3e_2eRunFrom_3ccompiler_2fmir_3aStmt_3e(ptr %v0, ptr %t48, i64 %t49)
  %t53 = extractvalue { i32, { i64, ptr } } %t52, 1
  %t54 = extractvalue { i32, { i64, ptr } } %t52, 0
  store i32 %t54, ptr %l47
  %t55 = icmp ne i32 %t54, 0
  br i1 %t55, label %bb14, label %ok.56
ok.56:
  store { i64, ptr } %t53, ptr %l46
  br label %bb13
bb13:
  %t57 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t57, ptr %l43, !tbaa !27
  br label %bb18
bb14:
  %t58 = load i32, ptr %l47, !tbaa !23
  %t59 = ashr i32 %t58, 16
  %t61 = icmp eq i32 %t59, 1
  br i1 %t61, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  call void @__olang_check_failed(ptr @olang_loc_cd3d2f4cb5172729_796de8126c3e3b8d)
  unreachable
bb17:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s5)
  br label %bb81
bb18:
  %t63 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t63, ptr %l11, !tbaa !27
  %t64 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t66 = extractvalue { i64, ptr } %t64, 0
  store i64 %t66, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb19
bb19:
  store %olang.scope zeroinitializer, ptr %s6
  %t68 = load i64, ptr %l13, !tbaa !24
  %t69 = load i64, ptr %l12, !tbaa !24
  %t72 = icmp slt i64 %t68, %t69
  %t74 = xor i1 %t72, true
  br i1 %t74, label %bb20, label %bb21
bb20:
  call void @__olang_scope_close(ptr %s6)
  br label %bb79
bb21:
  br label %bb22
bb22:
  %t76 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t76, ptr %l56, !tbaa !27
  %t77 = load i64, ptr %l13, !tbaa !24
  %t79 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = getelementptr { i64, [21 x i64] }, ptr %t80, i64 %t77
  call void @llvm.memmove.p0.p0.i64(ptr %l58, ptr %t81, i64 176, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l14, ptr %l58, i64 176, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l59, ptr %l14, i64 176, i1 false)
  %t82 = load { i64, [21 x i64] }, ptr %l59
  %t83 = extractvalue { i64, [21 x i64] } %t82, 0
  %t84 = icmp eq i64 %t83, 0
  br i1 %t84, label %bb23, label %bb24
bb23:
  %t86 = getelementptr { i64, [21 x i64] }, ptr %l14, i32 0, i32 1
  %t87 = getelementptr { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } }, ptr %t86, i32 0, i32 1
  %t88 = load %"compiler/mir:Place", ptr %t87
  store %"compiler/mir:Place" %t88, ptr %l15
  %t90 = getelementptr { i64, [21 x i64] }, ptr %l14, i32 0, i32 1
  %t91 = getelementptr { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } }, ptr %t90, i32 0, i32 2
  %t92 = load { i64, [15 x i64] }, ptr %t91
  store { i64, [15 x i64] } %t92, ptr %l16
  br label %bb25
bb24:
  br label %bb64
bb25:
  %t94 = getelementptr %"compiler/mir:Place", ptr %l15, i32 0, i32 1
  %t95 = getelementptr %"compiler/mir:Range", ptr %t94, i32 0, i32 1
  %t96 = load i32, ptr %t95, !tbaa !23
  %t98 = icmp sgt i32 %t96, 0
  br i1 %t98, label %bb26, label %bb27
bb26:
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t101 = load %"compiler/mir:Place", ptr %l15
  %t102 = load i32, ptr %l1, !tbaa !23
  %t106 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2ebaseIs(ptr %v0, ptr %t100, %"compiler/mir:Place" %t101, i32 %t102)
  store i1 %t106, ptr %l69
  br label %bb28
bb27:
  store i1 false, ptr %l65, !tbaa !21
  br label %bb29
bb28:
  %t107 = load i1, ptr %l69, !tbaa !21
  store i1 %t107, ptr %l65, !tbaa !21
  br label %bb29
bb29:
  %t108 = load i1, ptr %l65, !tbaa !21
  br i1 %t108, label %bb30, label %bb31
bb30:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %rv
  br label %ret
bb31:
  br label %bb32
bb32:
  %t110 = load { i64, [15 x i64] }, ptr %l16
  %t112 = extractvalue { i64, [15 x i64] } %t110, 0
  %t113 = icmp eq i64 %t112, 1
  br i1 %t113, label %bb33, label %bb34
bb33:
  %t115 = getelementptr { i64, [15 x i64] }, ptr %l16, i32 0, i32 1
  %t116 = getelementptr { %"compiler/mir:Place", i32 }, ptr %t115, i32 0, i32 0
  %t117 = load %"compiler/mir:Place", ptr %t116
  store %"compiler/mir:Place" %t117, ptr %l17
  %t119 = getelementptr { i64, [15 x i64] }, ptr %l16, i32 0, i32 1
  %t120 = getelementptr { %"compiler/mir:Place", i32 }, ptr %t119, i32 0, i32 1
  %t121 = load i32, ptr %t120
  store i32 %t121, ptr %l18, !tbaa !23
  br label %bb35
bb34:
  br label %bb45
bb35:
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t124 = load %"compiler/mir:Place", ptr %l17
  %t125 = load i32, ptr %l1, !tbaa !23
  %t129 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2ebaseIs(ptr %v0, ptr %t123, %"compiler/mir:Place" %t124, i32 %t125)
  store i1 %t129, ptr %l78
  br label %bb36
bb36:
  %t130 = load i1, ptr %l78, !tbaa !21
  br i1 %t130, label %bb37, label %bb38
bb37:
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t133 = getelementptr %"compiler/emit:fnEm", ptr %t131, i32 0, i32 0
  %t134 = load ptr, ptr %t133, !tbaa !29
  %t136 = getelementptr %"compiler/emit:Emitter", ptr %t134, i32 0, i32 3
  %t137 = load ptr, ptr %t136, !tbaa !29
  store ptr %t137, ptr %l82, !tbaa !29
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t140 = getelementptr %"compiler/emit:fnEm", ptr %t138, i32 0, i32 0
  %t141 = load ptr, ptr %t140, !tbaa !29
  %t143 = getelementptr %"compiler/emit:Emitter", ptr %t141, i32 0, i32 3
  %t144 = load ptr, ptr %t143, !tbaa !29
  %t145 = load i32, ptr %l18, !tbaa !23
  %t148 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t144, i32 %t145)
  store i32 %t148, ptr %l87
  br label %bb39
bb38:
  store i1 false, ptr %l79, !tbaa !21
  br label %bb41
bb39:
  %t149 = load ptr, ptr %l82, !tbaa !29
  %t150 = load i32, ptr %l87, !tbaa !23
  %t151 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t149, i32 %t150)
  store i64 %t151, ptr %l88
  br label %bb40
bb40:
  %t152 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t153 = load i64, ptr %l88, !tbaa !24
  %t155 = and i64 %t153, %t152
  %t157 = icmp ne i64 %t155, 0
  store i1 %t157, ptr %l79, !tbaa !21
  br label %bb41
bb41:
  %t159 = load i1, ptr %l79, !tbaa !21
  br i1 %t159, label %bb42, label %bb43
bb42:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %rv
  br label %ret
bb43:
  br label %bb44
bb44:
  br label %bb63
bb45:
  %t161 = load { i64, [15 x i64] }, ptr %l16
  %t163 = extractvalue { i64, [15 x i64] } %t161, 0
  %t164 = icmp eq i64 %t163, 9
  br i1 %t164, label %bb46, label %bb47
bb46:
  %t166 = getelementptr { i64, [15 x i64] }, ptr %l16, i32 0, i32 1
  %t167 = getelementptr { %"compiler/mir:Place", { i64, [4 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t166, i32 0, i32 0
  %t168 = load %"compiler/mir:Place", ptr %t167
  store %"compiler/mir:Place" %t168, ptr %l19
  %t170 = getelementptr { i64, [15 x i64] }, ptr %l16, i32 0, i32 1
  %t171 = getelementptr { %"compiler/mir:Place", { i64, [4 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t170, i32 0, i32 3
  %t172 = load i32, ptr %t171
  store i32 %t172, ptr %l20, !tbaa !23
  br label %bb48
bb47:
  br label %bb58
bb48:
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t175 = load %"compiler/mir:Place", ptr %l19
  %t176 = load i32, ptr %l1, !tbaa !23
  %t180 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2ebaseIs(ptr %v0, ptr %t174, %"compiler/mir:Place" %t175, i32 %t176)
  store i1 %t180, ptr %l100
  br label %bb49
bb49:
  %t181 = load i1, ptr %l100, !tbaa !21
  br i1 %t181, label %bb50, label %bb51
bb50:
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t184 = getelementptr %"compiler/emit:fnEm", ptr %t182, i32 0, i32 0
  %t185 = load ptr, ptr %t184, !tbaa !29
  %t187 = getelementptr %"compiler/emit:Emitter", ptr %t185, i32 0, i32 3
  %t188 = load ptr, ptr %t187, !tbaa !29
  store ptr %t188, ptr %l104, !tbaa !29
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t191 = getelementptr %"compiler/emit:fnEm", ptr %t189, i32 0, i32 0
  %t192 = load ptr, ptr %t191, !tbaa !29
  %t194 = getelementptr %"compiler/emit:Emitter", ptr %t192, i32 0, i32 3
  %t195 = load ptr, ptr %t194, !tbaa !29
  %t196 = load i32, ptr %l20, !tbaa !23
  %t199 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t195, i32 %t196)
  store i32 %t199, ptr %l109
  br label %bb52
bb51:
  store i1 false, ptr %l101, !tbaa !21
  br label %bb54
bb52:
  %t200 = load ptr, ptr %l104, !tbaa !29
  %t201 = load i32, ptr %l109, !tbaa !23
  %t202 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t200, i32 %t201)
  store i64 %t202, ptr %l110
  br label %bb53
bb53:
  %t203 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t204 = load i64, ptr %l110, !tbaa !24
  %t206 = and i64 %t204, %t203
  %t208 = icmp ne i64 %t206, 0
  store i1 %t208, ptr %l101, !tbaa !21
  br label %bb54
bb54:
  %t210 = load i1, ptr %l101, !tbaa !21
  br i1 %t210, label %bb55, label %bb56
bb55:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %rv
  br label %ret
bb56:
  br label %bb57
bb57:
  br label %bb63
bb58:
  br i1 true, label %bb59, label %bb60
bb59:
  br label %bb61
bb60:
  br label %bb62
bb61:
  br label %bb63
bb62:
  call void @__olang_check_failed(ptr @olang_loc_aa77627ec6eb5ef2_35c32f6dd172e1f6)
  unreachable
bb63:
  br label %bb77
bb64:
  call void @llvm.memmove.p0.p0.i64(ptr %l115, ptr %l14, i64 176, i1 false)
  %t212 = load { i64, [21 x i64] }, ptr %l115
  %t213 = extractvalue { i64, [21 x i64] } %t212, 0
  %t214 = icmp eq i64 %t213, 10
  br i1 %t214, label %bb65, label %bb66
bb65:
  %t216 = getelementptr { i64, [21 x i64] }, ptr %l14, i32 0, i32 1
  %t217 = getelementptr { %"compiler/source:Span", %"compiler/mir:Place", %"compiler/mir:Place", { i64, [4 x i64] } }, ptr %t216, i32 0, i32 1
  %t218 = load %"compiler/mir:Place", ptr %t217
  store %"compiler/mir:Place" %t218, ptr %l21
  br label %bb67
bb66:
  br label %bb72
bb67:
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t221 = load %"compiler/mir:Place", ptr %l21
  %t222 = load i32, ptr %l1, !tbaa !23
  %t226 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2ebaseIs(ptr %v0, ptr %t220, %"compiler/mir:Place" %t221, i32 %t222)
  store i1 %t226, ptr %l121
  br label %bb68
bb68:
  %t227 = load i1, ptr %l121, !tbaa !21
  br i1 %t227, label %bb69, label %bb70
bb69:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %rv
  br label %ret
bb70:
  br label %bb71
bb71:
  br label %bb77
bb72:
  br i1 true, label %bb73, label %bb74
bb73:
  br label %bb75
bb74:
  br label %bb76
bb75:
  br label %bb77
bb76:
  call void @__olang_check_failed(ptr @olang_loc_adfc2b4e0bd5373_1e3a8de6ffd7da97)
  unreachable
bb77:
  call void @__olang_scope_close(ptr %s6)
  br label %bb78
bb78:
  %t229 = load i64, ptr %l13, !tbaa !24
  %t231 = add i64 %t229, 1
  store i64 %t231, ptr %l13, !tbaa !24
  br label %bb19
bb79:
  %t233 = load i64, ptr %l10, !tbaa !24
  %t234 = load i64, ptr %l12, !tbaa !24
  %t237 = add i64 %t233, %t234
  store i64 %t237, ptr %l10, !tbaa !24
  call void @__olang_scope_close(ptr %s5)
  br label %bb80
bb80:
  br label %bb12
bb81:
  call void @__olang_scope_close(ptr %s3)
  br label %bb82
bb82:
  %t239 = load i64, ptr %l7, !tbaa !24
  %t241 = add i64 %t239, 1
  store i64 %t241, ptr %l7, !tbaa !24
  br label %bb8
bb83:
  %t243 = load i64, ptr %l4, !tbaa !24
  %t244 = load i64, ptr %l6, !tbaa !24
  %t247 = add i64 %t243, %t244
  store i64 %t247, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb84
bb84:
  br label %bb1
bb85:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ehexByte(ptr %v0, i8 %a0) #0 {
entry:
  %l0 = alloca i8
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store i8 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d504, i32 0, i32 1) }, ptr %l2, !tbaa !27
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t1, ptr %l3, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t2, 0
  store i64 %t3, ptr %l4, !tbaa !24
  %t4 = load i64, ptr %l4, !tbaa !24
  %t5 = mul i64 %t4, 1
  %t6 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t5)
  %t7 = insertvalue { i64, ptr } undef, i64 %t4, 0
  %t8 = insertvalue { i64, ptr } %t7, ptr %t6, 1
  store { i64, ptr } %t8, ptr %l5, !tbaa !27
  %t9 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !27
  %t11 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !27
  %t13 = load i64, ptr %l4, !tbaa !24
  %t14 = mul i64 %t13, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t10, ptr %t12, i64 %t14, i1 false)
  %t15 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t15, ptr %l1, !tbaa !27
  %t16 = load i8, ptr %l0, !tbaa !22
  %t18 = lshr i8 %t16, 4
  %t20 = zext i8 %t18 to i64
  %t22 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = getelementptr i8, ptr %t23, i64 %t20
  %t25 = load i8, ptr %t24, !tbaa !32
  %t26 = load i8, ptr %l0, !tbaa !22
  %t28 = and i8 %t26, 15
  %t30 = zext i8 %t28 to i64
  %t32 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !27
  %t34 = getelementptr i8, ptr %t33, i64 %t30
  %t35 = load i8, ptr %t34, !tbaa !32
  %t36 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d505, i32 0, i32 1) }, 1
  %t37 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d505, i32 0, i32 1) }, 0
  %t39 = add i64 %t37, 1
  %t41 = add i64 %t39, 1
  %t42 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t41)
  call void @olang_textcopy(ptr %t42, ptr %t36, i64 %t37)
  %t43 = getelementptr i8, ptr %t42, i64 %t37
  store i8 %t25, ptr %t43
  %t44 = getelementptr i8, ptr %t43, i64 1
  store i8 %t35, ptr %t44
  %t45 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t46 = insertvalue { i64, ptr } %t45, ptr %t42, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t46, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2femit_2ehexDigits_2einit() #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l3 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d506, i32 0, i32 1) }, ptr %l0, !tbaa !27
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l1, !tbaa !27
  %t2 = load { i64, ptr }, ptr @G_2ecompiler_2femit_2ehexDigits, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t2, 0
  %t4 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t4, 0
  store i64 %t5, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = icmp eq i64 %t3, %t7
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = getelementptr { i64, ptr }, ptr @G_2ecompiler_2femit_2ehexDigits, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = load i64, ptr %l3, !tbaa !24
  %t15 = mul i64 %t14, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t11, ptr %t13, i64 %t15, i1 false)
  br label %bb3
bb2:
  %t16 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t16, 0
  store i64 %t17, ptr %l5, !tbaa !24
  %t18 = load i64, ptr %l5, !tbaa !24
  %t19 = mul i64 %t18, 1
  %t20 = load ptr, ptr @__olang_prog_scope
  %t21 = call ptr @__olang_scope_alloc_zeroed(ptr %t20, i64 %t19)
  %t22 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t21, 1
  store { i64, ptr } %t23, ptr %l6, !tbaa !27
  %t24 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = load i64, ptr %l5, !tbaa !24
  %t29 = mul i64 %t28, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t25, ptr %t27, i64 %t29, i1 false)
  %t30 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t30, ptr @G_2ecompiler_2femit_2ehexDigits, !tbaa !27
  br label %bb3
bb3:
  br label %ret
ret:
  ret void
}

define dso_local %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2femit_2emathInexactTable(ptr %v0) #0 {
entry:
  %lp0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l6 = alloca [22 x { i64, ptr }]
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l5
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 8, i64 8)
  store ptr %t2, ptr %lp0
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l5
  %t4 = load ptr, ptr %lp0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %t4
  store %olang.scope zeroinitializer, ptr %s1
  %t5 = getelementptr [22 x { i64, ptr }], ptr %l6, i64 0, i64 0
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d507, i32 0, i32 1) }, ptr %t5
  %t6 = getelementptr [22 x { i64, ptr }], ptr %l6, i64 0, i64 1
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d508, i32 0, i32 1) }, ptr %t6
  %t7 = getelementptr [22 x { i64, ptr }], ptr %l6, i64 0, i64 2
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d509, i32 0, i32 1) }, ptr %t7
  %t8 = getelementptr [22 x { i64, ptr }], ptr %l6, i64 0, i64 3
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d510, i32 0, i32 1) }, ptr %t8
  %t9 = getelementptr [22 x { i64, ptr }], ptr %l6, i64 0, i64 4
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d511, i32 0, i32 1) }, ptr %t9
  %t10 = getelementptr [22 x { i64, ptr }], ptr %l6, i64 0, i64 5
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d512, i32 0, i32 1) }, ptr %t10
  %t11 = getelementptr [22 x { i64, ptr }], ptr %l6, i64 0, i64 6
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d513, i32 0, i32 1) }, ptr %t11
  %t12 = getelementptr [22 x { i64, ptr }], ptr %l6, i64 0, i64 7
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d514, i32 0, i32 1) }, ptr %t12
  %t13 = getelementptr [22 x { i64, ptr }], ptr %l6, i64 0, i64 8
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d515, i32 0, i32 1) }, ptr %t13
  %t14 = getelementptr [22 x { i64, ptr }], ptr %l6, i64 0, i64 9
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d516, i32 0, i32 1) }, ptr %t14
  %t15 = getelementptr [22 x { i64, ptr }], ptr %l6, i64 0, i64 10
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d517, i32 0, i32 1) }, ptr %t15
  %t16 = getelementptr [22 x { i64, ptr }], ptr %l6, i64 0, i64 11
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d518, i32 0, i32 1) }, ptr %t16
  %t17 = getelementptr [22 x { i64, ptr }], ptr %l6, i64 0, i64 12
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d519, i32 0, i32 1) }, ptr %t17
  %t18 = getelementptr [22 x { i64, ptr }], ptr %l6, i64 0, i64 13
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d520, i32 0, i32 1) }, ptr %t18
  %t19 = getelementptr [22 x { i64, ptr }], ptr %l6, i64 0, i64 14
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d521, i32 0, i32 1) }, ptr %t19
  %t20 = getelementptr [22 x { i64, ptr }], ptr %l6, i64 0, i64 15
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d522, i32 0, i32 1) }, ptr %t20
  %t21 = getelementptr [22 x { i64, ptr }], ptr %l6, i64 0, i64 16
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d523, i32 0, i32 1) }, ptr %t21
  %t22 = getelementptr [22 x { i64, ptr }], ptr %l6, i64 0, i64 17
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d524, i32 0, i32 1) }, ptr %t22
  %t23 = getelementptr [22 x { i64, ptr }], ptr %l6, i64 0, i64 18
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d525, i32 0, i32 1) }, ptr %t23
  %t24 = getelementptr [22 x { i64, ptr }], ptr %l6, i64 0, i64 19
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d526, i32 0, i32 1) }, ptr %t24
  %t25 = getelementptr [22 x { i64, ptr }], ptr %l6, i64 0, i64 20
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d527, i32 0, i32 1) }, ptr %t25
  %t26 = getelementptr [22 x { i64, ptr }], ptr %l6, i64 0, i64 21
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d528, i32 0, i32 1) }, ptr %t26
  %t27 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 352, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t27, ptr %l6, i64 352, i1 false)
  store ptr %t27, ptr %l1
  store i64 0, ptr %l2, !tbaa !24
  %t29 = load ptr, ptr %l1
  store i64 22, ptr %l3, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t32 = load i64, ptr %l2, !tbaa !24
  %t33 = load i64, ptr %l3, !tbaa !24
  %t36 = icmp slt i64 %t32, %t33
  %t38 = xor i1 %t36, true
  br i1 %t38, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb9
bb4:
  br label %bb5
bb5:
  %t40 = load ptr, ptr %l1
  %t41 = load i64, ptr %l2, !tbaa !24
  %t44 = getelementptr [22 x { i64, ptr }], ptr %t40, i64 0, i64 %t41
  %t45 = load { i64, ptr }, ptr %t44, !tbaa !37
  store { i64, ptr } %t45, ptr %l4, !tbaa !27
  %t47 = load ptr, ptr %lp0
  %t48 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t49 = load ptr, ptr @__olang_prog_scope
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H2b85ceff512af6e6ca26c554a1c16247(ptr %v0, ptr %t49, ptr %t47, { i64, ptr } %t48, i1 true)
  br label %bb6
bb6:
  %t52 = load ptr, ptr %lp0
  %t53 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t55 = extractvalue { i64, ptr } %t53, 1
  %t56 = extractvalue { i64, ptr } %t53, 0
  %t57 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d529, i32 0, i32 1) }, 1
  %t58 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d529, i32 0, i32 1) }, 0
  %t59 = add i64 %t56, %t58
  %t60 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t59)
  call void @olang_textcopy(ptr %t60, ptr %t55, i64 %t56)
  %t61 = getelementptr i8, ptr %t60, i64 %t56
  call void @olang_textcopy(ptr %t61, ptr %t57, i64 %t58)
  %t62 = insertvalue { i64, ptr } undef, i64 %t59, 0
  %t63 = insertvalue { i64, ptr } %t62, ptr %t60, 1
  %t65 = extractvalue { i64, ptr } %t63, 0
  %t66 = extractvalue { i64, ptr } %t63, 1
  %t67 = mul i64 %t65, 1
  %t68 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t67)
  call void @llvm.memcpy.p0.p0.i64(ptr %t68, ptr %t66, i64 %t67, i1 false)
  %t69 = insertvalue { i64, ptr } undef, i64 %t65, 0
  %t70 = insertvalue { i64, ptr } %t69, ptr %t68, 1
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H2b85ceff512af6e6ca26c554a1c16247(ptr %v0, ptr %v0, ptr %t52, { i64, ptr } %t70, i1 true)
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s2)
  br label %bb8
bb8:
  %t73 = load i64, ptr %l2, !tbaa !24
  %t75 = add i64 %t73, 1
  store i64 %t75, ptr %l2, !tbaa !24
  br label %bb2
bb9:
  call void @__olang_scope_close(ptr %s1)
  %t77 = load ptr, ptr %lp0
  %t78 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t77
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t78, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local i64 @compiler_2femit_2emetaNumber(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca i1
  %l6 = alloca ptr
  %l7 = alloca i64
  %l9 = alloca i64
  %l11 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i32
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %t1, i64 %t2)
  store i1 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i1, ptr %l4, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load ptr, ptr %l0, !tbaa !29
  store ptr %t9, ptr %l6, !tbaa !29
  %t10 = load i64, ptr %l1, !tbaa !24
  store i64 %t10, ptr %l7, !tbaa !24
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eLen_3cI64_2c_20I64_3e(ptr %v0, ptr %t11)
  store i64 %t13, ptr %l9
  br label %bb4
bb3:
  br label %bb6
bb4:
  %t14 = load i64, ptr %l9, !tbaa !24
  %t15 = add i64 1000, %t14
  %t16 = load ptr, ptr %l6, !tbaa !29
  %t17 = load i64, ptr %l7, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t16, i64 %t17, i64 %t15)
  br label %bb5
bb5:
  br label %bb6
bb6:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t20 = load i64, ptr %l1, !tbaa !24
  %t23 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t19, i64 %t20)
  %t24 = extractvalue { i32, i64 } %t23, 1
  %t25 = extractvalue { i32, i64 } %t23, 0
  store i32 %t25, ptr %l15
  %t26 = icmp ne i32 %t25, 0
  br i1 %t26, label %bb8, label %ok.27
ok.27:
  store i64 %t24, ptr %l14
  br label %bb7
bb7:
  %t28 = load i64, ptr %l14, !tbaa !24
  store i64 %t28, ptr %l11, !tbaa !24
  br label %bb10
bb8:
  br label %bb9
bb9:
  call void @__olang_ert_req_clear()
  store i64 0, ptr %l11, !tbaa !24
  br label %bb10
bb10:
  %t29 = load i64, ptr %l11, !tbaa !24
  store i64 %t29, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2femit_2etbaaElem_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  %t1 = insertvalue [15 x i64] undef, i64 0, 0
  %t2 = insertvalue [15 x i64] %t1, i64 0, 1
  %t3 = insertvalue [15 x i64] %t2, i64 31, 2
  %t4 = insertvalue [15 x i64] %t3, i64 81, 3
  %t5 = insertvalue [15 x i64] %t4, i64 82, 4
  %t6 = insertvalue [15 x i64] %t5, i64 33, 5
  %t7 = insertvalue [15 x i64] %t6, i64 34, 6
  %t8 = insertvalue [15 x i64] %t7, i64 32, 7
  %t9 = insertvalue [15 x i64] %t8, i64 83, 8
  %t10 = insertvalue [15 x i64] %t9, i64 84, 9
  %t11 = insertvalue [15 x i64] %t10, i64 85, 10
  %t12 = insertvalue [15 x i64] %t11, i64 86, 11
  %t13 = insertvalue [15 x i64] %t12, i64 87, 12
  %t14 = insertvalue [15 x i64] %t13, i64 35, 13
  %t15 = insertvalue [15 x i64] %t14, i64 36, 14
  store [15 x i64] %t15, ptr @G_2ecompiler_2femit_2etbaaElem
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2femit_2etbaaName_2einit() #0 {
entry:
  %l0 = alloca [15 x { i64, ptr }]
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr [15 x { i64, ptr }], ptr %l0, i64 0, i64 0
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d530, i32 0, i32 1) }, ptr %t1, !tbaa !37
  %t2 = getelementptr [15 x { i64, ptr }], ptr %l0, i64 0, i64 1
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d531, i32 0, i32 1) }, ptr %t2, !tbaa !37
  %t3 = getelementptr [15 x { i64, ptr }], ptr %l0, i64 0, i64 2
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d532, i32 0, i32 1) }, ptr %t3, !tbaa !37
  %t4 = getelementptr [15 x { i64, ptr }], ptr %l0, i64 0, i64 3
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d533, i32 0, i32 1) }, ptr %t4, !tbaa !37
  %t5 = getelementptr [15 x { i64, ptr }], ptr %l0, i64 0, i64 4
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d534, i32 0, i32 1) }, ptr %t5, !tbaa !37
  %t6 = getelementptr [15 x { i64, ptr }], ptr %l0, i64 0, i64 5
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d535, i32 0, i32 1) }, ptr %t6, !tbaa !37
  %t7 = getelementptr [15 x { i64, ptr }], ptr %l0, i64 0, i64 6
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d536, i32 0, i32 1) }, ptr %t7, !tbaa !37
  %t8 = getelementptr [15 x { i64, ptr }], ptr %l0, i64 0, i64 7
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d537, i32 0, i32 1) }, ptr %t8, !tbaa !37
  %t9 = getelementptr [15 x { i64, ptr }], ptr %l0, i64 0, i64 8
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d538, i32 0, i32 1) }, ptr %t9, !tbaa !37
  %t10 = getelementptr [15 x { i64, ptr }], ptr %l0, i64 0, i64 9
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d539, i32 0, i32 1) }, ptr %t10, !tbaa !37
  %t11 = getelementptr [15 x { i64, ptr }], ptr %l0, i64 0, i64 10
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d540, i32 0, i32 1) }, ptr %t11, !tbaa !37
  %t12 = getelementptr [15 x { i64, ptr }], ptr %l0, i64 0, i64 11
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d541, i32 0, i32 1) }, ptr %t12, !tbaa !37
  %t13 = getelementptr [15 x { i64, ptr }], ptr %l0, i64 0, i64 12
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d542, i32 0, i32 1) }, ptr %t13, !tbaa !37
  %t14 = getelementptr [15 x { i64, ptr }], ptr %l0, i64 0, i64 13
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d543, i32 0, i32 1) }, ptr %t14, !tbaa !37
  %t15 = getelementptr [15 x { i64, ptr }], ptr %l0, i64 0, i64 14
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d544, i32 0, i32 1) }, ptr %t15, !tbaa !37
  call void @llvm.memmove.p0.p0.i64(ptr @G_2ecompiler_2femit_2etbaaName, ptr %l0, i64 240, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/emit:Reused" @compiler_2femit_3aReused_2ector(ptr %v0, i64 %a0) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l3 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l4 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l5 = alloca i64
  %l6 = alloca i1
  %l10 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l11 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l12 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l13 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"compiler/emit:Reused"
  br label %start
start:
  br label %bb0
bb0:
  store i64 %a0, ptr %l1, !tbaa !24
  %t3 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %l10
  br label %bb1
bb1:
  %t4 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l10
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t4, ptr %l2
  %t5 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cBool_3e(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t5, ptr %l11
  br label %bb2
bb2:
  %t6 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l11
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t6, ptr %l3
  %t7 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t7, ptr %l12
  br label %bb3
bb3:
  %t8 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l12
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t8, ptr %l4
  store i64 0, ptr %l5, !tbaa !24
  store i1 false, ptr %l6, !tbaa !21
  %t9 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t9, ptr %l13
  br label %bb4
bb4:
  %t10 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l13
  %t11 = load i64, ptr %l1, !tbaa !24
  %t12 = insertvalue %"compiler/emit:Reused" undef, i64 %t11, 0
  %t13 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l2
  %t14 = insertvalue %"compiler/emit:Reused" %t12, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t13, 1
  %t15 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l3
  %t16 = insertvalue %"compiler/emit:Reused" %t14, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t15, 2
  %t17 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l4
  %t18 = insertvalue %"compiler/emit:Reused" %t16, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t17, 3
  %t19 = load i64, ptr %l5, !tbaa !24
  %t20 = insertvalue %"compiler/emit:Reused" %t18, i64 %t19, 4
  %t21 = load i1, ptr %l6, !tbaa !21
  %t22 = insertvalue %"compiler/emit:Reused" %t20, i1 %t21, 5
  %t24 = insertvalue %"compiler/emit:Reused" %t22, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t10, 6
  %t26 = insertvalue %"compiler/emit:Reused" %t24, i64 -1, 7
  store %"compiler/emit:Reused" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/emit:Reused", ptr %rv
  ret %"compiler/emit:Reused" %rr
}

define dso_local void @compiler_2femit_3afnEm_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, [2 x i64] } %a2) #0 {
entry:
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca { i64, [2 x i64] }
  %l6 = alloca %"std/prelude/text:StringBuilder"
  %l7 = alloca %"std/prelude/text:StringBuilder"
  %l8 = alloca %"std/prelude/text:StringBuilder"
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i32
  %l13 = alloca i1
  %l14 = alloca i1
  %l15 = alloca i1
  %l16 = alloca i1
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l20 = alloca i64
  %l21 = alloca { i64, ptr }
  %l22 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l23 = alloca %"std/prelude/text:StringBuilder"
  %l24 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l25 = alloca i1
  %l26 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l27 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l28 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l31 = alloca { i64, ptr }
  %l35 = alloca %"std/prelude/text:StringBuilder"
  %l36 = alloca %"std/prelude/text:StringBuilder"
  %l37 = alloca %"std/prelude/text:StringBuilder"
  %l39 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l40 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l41 = alloca %"std/prelude/text:StringBuilder"
  %l42 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l43 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l44 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l45 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l46 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l47 = alloca %"compiler/emit:fnEm"
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l3, !tbaa !29
  store ptr %a1, ptr %l4, !tbaa !29
  store { i64, [2 x i64] } %a2, ptr %l5
  %t7 = call %"std/prelude/text:StringBuilder" @olang_2eHelperKind_2eZero_2estd_2fprelude_2ftext_3aStringBuilder(ptr %v2)
  store %"std/prelude/text:StringBuilder" %t7, ptr %l35
  br label %bb1
bb1:
  %t8 = load %"std/prelude/text:StringBuilder", ptr %l35
  store %"std/prelude/text:StringBuilder" %t8, ptr %l6
  %t9 = call %"std/prelude/text:StringBuilder" @olang_2eHelperKind_2eZero_2estd_2fprelude_2ftext_3aStringBuilder(ptr %v2)
  store %"std/prelude/text:StringBuilder" %t9, ptr %l36
  br label %bb2
bb2:
  %t10 = load %"std/prelude/text:StringBuilder", ptr %l36
  store %"std/prelude/text:StringBuilder" %t10, ptr %l7
  %t11 = call %"std/prelude/text:StringBuilder" @olang_2eHelperKind_2eZero_2estd_2fprelude_2ftext_3aStringBuilder(ptr %v2)
  store %"std/prelude/text:StringBuilder" %t11, ptr %l37
  br label %bb3
bb3:
  %t12 = load %"std/prelude/text:StringBuilder", ptr %l37
  store %"std/prelude/text:StringBuilder" %t12, ptr %l8
  store i64 0, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  store i64 -1, ptr %l11, !tbaa !24
  %t13 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  store i32 %t13, ptr %l12, !tbaa !23
  store i1 false, ptr %l13, !tbaa !21
  store i1 false, ptr %l14, !tbaa !21
  store i1 false, ptr %l15, !tbaa !21
  store i1 false, ptr %l16, !tbaa !21
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d545, i32 0, i32 1) }, ptr %l17, !tbaa !27
  store i64 0, ptr %l18, !tbaa !24
  %t15 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_Hf48d6d4096e547b8075d5a903caa3d54(ptr %v2)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t15, ptr %l39
  br label %bb4
bb4:
  %t16 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l39
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t16, ptr %l19
  store i64 -1, ptr %l20, !tbaa !24
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d546, i32 0, i32 1) }, ptr %l21, !tbaa !27
  %t17 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v2)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t17, ptr %l40
  br label %bb5
bb5:
  %t18 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l40
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t18, ptr %l22
  %t19 = call %"std/prelude/text:StringBuilder" @olang_2eHelperKind_2eZero_2estd_2fprelude_2ftext_3aStringBuilder(ptr %v2)
  store %"std/prelude/text:StringBuilder" %t19, ptr %l41
  br label %bb6
bb6:
  %t20 = load %"std/prelude/text:StringBuilder", ptr %l41
  store %"std/prelude/text:StringBuilder" %t20, ptr %l23
  %t21 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI32_2c_20I64_3e(ptr %v2)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t21, ptr %l42
  br label %bb7
bb7:
  %t22 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l42
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t22, ptr %l24
  store i1 false, ptr %l25, !tbaa !21
  %t23 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v2)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t23, ptr %l43
  br label %bb8
bb8:
  %t24 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l43
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t24, ptr %l26
  %t25 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v2)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t25, ptr %l44
  br label %bb9
bb9:
  %t26 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l44
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t26, ptr %l27
  %t27 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aWriteKind_3e(ptr %v2)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t27, ptr %l45
  br label %bb10
bb10:
  %t28 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l45
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t28, ptr %l28
  %t29 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aOperand_3e(ptr %v2)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t29, ptr %l46
  br label %bb11
bb11:
  %t30 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l46
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d547, i32 0, i32 1) }, ptr %l31, !tbaa !27
  %t31 = getelementptr %"compiler/emit:fnEm", ptr %l47, i32 0, i32 0
  %t32 = load ptr, ptr %l3, !tbaa !29
  store ptr %t32, ptr %t31, !tbaa !29
  %t33 = getelementptr %"compiler/emit:fnEm", ptr %l47, i32 0, i32 1
  %t34 = load ptr, ptr %l4, !tbaa !29
  store ptr %t34, ptr %t33, !tbaa !29
  %t35 = getelementptr %"compiler/emit:fnEm", ptr %l47, i32 0, i32 2
  %t36 = load { i64, [2 x i64] }, ptr %l5
  store { i64, [2 x i64] } %t36, ptr %t35
  %t37 = getelementptr %"compiler/emit:fnEm", ptr %l47, i32 0, i32 3
  %t38 = load %"std/prelude/text:StringBuilder", ptr %l6
  store %"std/prelude/text:StringBuilder" %t38, ptr %t37
  %t39 = getelementptr %"compiler/emit:fnEm", ptr %l47, i32 0, i32 4
  %t40 = load %"std/prelude/text:StringBuilder", ptr %l7
  store %"std/prelude/text:StringBuilder" %t40, ptr %t39
  %t41 = getelementptr %"compiler/emit:fnEm", ptr %l47, i32 0, i32 5
  %t42 = load %"std/prelude/text:StringBuilder", ptr %l8
  store %"std/prelude/text:StringBuilder" %t42, ptr %t41
  %t43 = getelementptr %"compiler/emit:fnEm", ptr %l47, i32 0, i32 6
  %t44 = load i64, ptr %l9, !tbaa !24
  store i64 %t44, ptr %t43, !tbaa !24
  %t45 = getelementptr %"compiler/emit:fnEm", ptr %l47, i32 0, i32 7
  %t46 = load i64, ptr %l10, !tbaa !24
  store i64 %t46, ptr %t45, !tbaa !24
  %t47 = getelementptr %"compiler/emit:fnEm", ptr %l47, i32 0, i32 8
  %t48 = load i64, ptr %l11, !tbaa !24
  store i64 %t48, ptr %t47, !tbaa !24
  %t49 = getelementptr %"compiler/emit:fnEm", ptr %l47, i32 0, i32 9
  %t50 = load i32, ptr %l12, !tbaa !23
  store i32 %t50, ptr %t49, !tbaa !23
  %t51 = getelementptr %"compiler/emit:fnEm", ptr %l47, i32 0, i32 10
  %t52 = load i1, ptr %l13, !tbaa !21
  store i1 %t52, ptr %t51, !tbaa !21
  %t53 = getelementptr %"compiler/emit:fnEm", ptr %l47, i32 0, i32 11
  %t54 = load i1, ptr %l14, !tbaa !21
  store i1 %t54, ptr %t53, !tbaa !21
  %t55 = getelementptr %"compiler/emit:fnEm", ptr %l47, i32 0, i32 12
  %t56 = load i1, ptr %l15, !tbaa !21
  store i1 %t56, ptr %t55, !tbaa !21
  %t57 = getelementptr %"compiler/emit:fnEm", ptr %l47, i32 0, i32 13
  %t58 = load i1, ptr %l16, !tbaa !21
  store i1 %t58, ptr %t57, !tbaa !21
  %t59 = getelementptr %"compiler/emit:fnEm", ptr %l47, i32 0, i32 14
  %t60 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t60, ptr %t59, !tbaa !27
  %t61 = getelementptr %"compiler/emit:fnEm", ptr %l47, i32 0, i32 15
  %t62 = load i64, ptr %l18, !tbaa !24
  store i64 %t62, ptr %t61, !tbaa !24
  %t63 = getelementptr %"compiler/emit:fnEm", ptr %l47, i32 0, i32 16
  %t64 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l19
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t64, ptr %t63
  %t65 = getelementptr %"compiler/emit:fnEm", ptr %l47, i32 0, i32 17
  %t66 = load i64, ptr %l20, !tbaa !24
  store i64 %t66, ptr %t65, !tbaa !24
  %t67 = getelementptr %"compiler/emit:fnEm", ptr %l47, i32 0, i32 18
  %t68 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t68, ptr %t67, !tbaa !27
  %t69 = getelementptr %"compiler/emit:fnEm", ptr %l47, i32 0, i32 19
  %t70 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l22
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t70, ptr %t69
  %t71 = getelementptr %"compiler/emit:fnEm", ptr %l47, i32 0, i32 20
  %t72 = load %"std/prelude/text:StringBuilder", ptr %l23
  store %"std/prelude/text:StringBuilder" %t72, ptr %t71
  %t73 = getelementptr %"compiler/emit:fnEm", ptr %l47, i32 0, i32 21
  %t74 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l24
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t74, ptr %t73
  %t75 = getelementptr %"compiler/emit:fnEm", ptr %l47, i32 0, i32 22
  %t76 = load i1, ptr %l25, !tbaa !21
  store i1 %t76, ptr %t75, !tbaa !21
  %t77 = getelementptr %"compiler/emit:fnEm", ptr %l47, i32 0, i32 23
  %t78 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l26
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t78, ptr %t77
  %t79 = getelementptr %"compiler/emit:fnEm", ptr %l47, i32 0, i32 24
  %t80 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l27
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t80, ptr %t79
  %t81 = getelementptr %"compiler/emit:fnEm", ptr %l47, i32 0, i32 25
  %t82 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l28
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t82, ptr %t81
  %t83 = getelementptr %"compiler/emit:fnEm", ptr %l47, i32 0, i32 26
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t30, ptr %t83
  %t85 = getelementptr %"compiler/emit:fnEm", ptr %l47, i32 0, i32 27
  store i1 false, ptr %t85, !tbaa !21
  %t87 = getelementptr %"compiler/emit:fnEm", ptr %l47, i32 0, i32 28
  %t88 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t88, ptr %t87, !tbaa !27
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l47, i64 240, i1 false)
  br label %ret
ret:
  ret void
}

define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d0 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"olang.table." }>, align 8
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
@.d1 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"ptr @" }>, align 8
@.d2 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c", ptr @" }>, align 8
declare void @__olang_check_failed(ptr)
declare void @__olang_ert_req_clear()
@.d3 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c", ptr @" }>, align 8
@.d4 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"@" }>, align 8
@.d5 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c" = linkonce_odr constant [" }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d6 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" x ptr] [" }>, align 8
@.d7 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"]\0A" }>, align 8
@.d8 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d9 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"void" }>, align 8
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d10 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d11 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d12 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d13 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"void" }>, align 8
@.d14 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"c:" }>, align 8
@.d15 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d16 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"@.c" }>, align 8
@.d17 = private constant <{ i64, [34 x i8] }> <{ i64 0, [34 x i8] c" = private unnamed_addr constant [" }>, align 8
@.d18 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" x i8] c\22" }>, align 8
@.d19 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"\5C00\22\0A" }>, align 8
@.d20 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d21 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"!DIFile(filename: \22" }>, align 8
@.d22 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"\22, directory: \22" }>, align 8
@.d23 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"\22)" }>, align 8
@.d24 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"DW_ATE_boolean" }>, align 8
@.d25 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"DW_ATE_float" }>, align 8
@.d26 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"DW_ATE_unsigned" }>, align 8
@.d27 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"DW_ATE_signed" }>, align 8
@.d28 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"DW_ATE_unsigned_char" }>, align 8
@.d29 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"!DIBasicType(name: \22" }>, align 8
@.d30 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"\22, size: " }>, align 8
@.d31 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c", encoding: " }>, align 8
@.d32 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d33 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"ptr" }>, align 8
@.d34 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I64" }>, align 8
@.d35 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"len" }>, align 8
@.d36 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"data" }>, align 8
@.d37 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"!" }>, align 8
@.d38 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"null" }>, align 8
@.d39 = private constant <{ i64, [51 x i8] }> <{ i64 0, [51 x i8] c"!DIDerivedType(tag: DW_TAG_pointer_type, baseType: " }>, align 8
@.d40 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c", size: 64)" }>, align 8
@.d41 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"code" }>, align 8
@.d42 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"env" }>, align 8
@.d43 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I64" }>, align 8
@.d44 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"len" }>, align 8
@.d45 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"data" }>, align 8
@.d46 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"!{!DISubrange(count: " }>, align 8
@.d47 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c")}" }>, align 8
@.d48 = private constant <{ i64, [52 x i8] }> <{ i64 0, [52 x i8] c"!DICompositeType(tag: DW_TAG_array_type, baseType: !" }>, align 8
@.d49 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c", size: " }>, align 8
@.d50 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c", elements: !" }>, align 8
@.d51 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
define linkonce_odr %"std/prelude/text:StringBuilder" @olang_2eHelperKind_2eZero_2estd_2fprelude_2ftext_3aStringBuilder(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/text:StringBuilder"
  %rv = alloca %"std/prelude/text:StringBuilder"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l0
  store %"std/prelude/text:StringBuilder" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/text:StringBuilder", ptr %rv
  ret %"std/prelude/text:StringBuilder" %rr
}

@.d52 = private constant <{ i64, [42 x i8] }> <{ i64 0, [42 x i8] c"!DIDerivedType(tag: DW_TAG_member, name: \22" }>, align 8
@.d53 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"\22, baseType: !" }>, align 8
@.d54 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c", size: " }>, align 8
@.d55 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c", offset: " }>, align 8
@.d56 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d57 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d58 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"!" }>, align 8
@.d59 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"!{" }>, align 8
@.d60 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"}" }>, align 8
@.d61 = private constant <{ i64, [52 x i8] }> <{ i64 0, [52 x i8] c"!DICompositeType(tag: DW_TAG_structure_type, name: \22" }>, align 8
@.d62 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"\22, size: " }>, align 8
@.d63 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c", elements: !" }>, align 8
@.d64 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d65 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"!DIEnumerator(name: \22" }>, align 8
@.d66 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"\22, value: " }>, align 8
@.d67 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d68 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d69 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"!" }>, align 8
@.d70 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"!{" }>, align 8
@.d71 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"}" }>, align 8
@.d72 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I64" }>, align 8
@.d73 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I32" }>, align 8
@.d74 = private constant <{ i64, [54 x i8] }> <{ i64 0, [54 x i8] c"!DICompositeType(tag: DW_TAG_enumeration_type, name: \22" }>, align 8
@.d75 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"\22, size: " }>, align 8
@.d76 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c", baseType: !" }>, align 8
@.d77 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c", elements: !" }>, align 8
@.d78 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d79 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"!{!DISubrange(count: " }>, align 8
@.d80 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c")}" }>, align 8
@.d81 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I64" }>, align 8
@.d82 = private constant <{ i64, [52 x i8] }> <{ i64 0, [52 x i8] c"!DICompositeType(tag: DW_TAG_array_type, baseType: !" }>, align 8
@.d83 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c", size: " }>, align 8
@.d84 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c", elements: !" }>, align 8
@.d85 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d86 = private constant <{ i64, [60 x i8] }> <{ i64 0, [60 x i8] c"!DIDerivedType(tag: DW_TAG_member, name: \22case\22, baseType: !" }>, align 8
@.d87 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c", size: 64, offset: 0)" }>, align 8
@.d88 = private constant <{ i64, [63 x i8] }> <{ i64 0, [63 x i8] c"!DIDerivedType(tag: DW_TAG_member, name: \22payload\22, baseType: !" }>, align 8
@.d89 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c", size: " }>, align 8
@.d90 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c", offset: 64)" }>, align 8
@.d91 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"!{!" }>, align 8
@.d92 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", !" }>, align 8
@.d93 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"}" }>, align 8
@.d94 = private constant <{ i64, [52 x i8] }> <{ i64 0, [52 x i8] c"!DICompositeType(tag: DW_TAG_structure_type, name: \22" }>, align 8
@.d95 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"\22, size: " }>, align 8
@.d96 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c", elements: !" }>, align 8
@.d97 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d98 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"__olang_argc" }>, align 8
@.d99 = private constant <{ i64, [35 x i8] }> <{ i64 0, [35 x i8] c"@__olang_argc = external global i32" }>, align 8
@.d100 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"__olang_argv" }>, align 8
@.d101 = private constant <{ i64, [35 x i8] }> <{ i64 0, [35 x i8] c"@__olang_argv = external global ptr" }>, align 8
@.d102 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"__olang_thread_init" }>, align 8
@.d103 = private constant <{ i64, [51 x i8] }> <{ i64 0, [51 x i8] c"define i32 @main(i32 %argc, ptr %argv) #0 {\0Aentry:\0A" }>, align 8
@.d104 = private constant <{ i64, [74 x i8] }> <{ i64 0, [74 x i8] c"  store i32 %argc, ptr @__olang_argc\0A  store ptr %argv, ptr @__olang_argv\0A" }>, align 8
@.d105 = private constant <{ i64, [35 x i8] }> <{ i64 0, [35 x i8] c"  call void @__olang_thread_init()\0A" }>, align 8
@.d106 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"  call void @" }>, align 8
@.d107 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"()\0A" }>, align 8
@.d108 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"  call void @" }>, align 8
@.d109 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"()\0A  ret i32 0\0A}\0A\0A" }>, align 8
@.d110 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"main" }>, align 8
@.d111 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"  %c = call i32 @" }>, align 8
@.d112 = private constant <{ i64, [82 x i8] }> <{ i64 0, [82 x i8] c"()\0A  %bad = icmp ne i32 %c, 0\0A  br i1 %bad, label %err, label %ok\0Aok:\0A  ret i32 0\0A" }>, align 8
@.d113 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"err:\0A" }>, align 8
@.d114 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"fputs" }>, align 8
@.d115 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"i32 @fputs(ptr, ptr)" }>, align 8
@.d116 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"stderr" }>, align 8
@.d117 = private constant <{ i64, [29 x i8] }> <{ i64 0, [29 x i8] c"@stderr = external global ptr" }>, align 8
@.d118 = private constant <{ i64, [29 x i8] }> <{ i64 0, [29 x i8] c"  %s = load ptr, ptr @stderr\0A" }>, align 8
@.d119 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"%m0" }>, align 8
@.d120 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"unhandled error\0A" }>, align 8
@.d121 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c"  %m0 = getelementptr i8, ptr " }>, align 8
@.d122 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c", i64 0\0A" }>, align 8
@.d123 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"unhandled error: " }>, align 8
@.d124 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d125 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d126 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"  %q" }>, align 8
@.d127 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c" = icmp eq i32 %c, " }>, align 8
@.d128 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d129 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"  %m" }>, align 8
@.d130 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c" = select i1 %q" }>, align 8
@.d131 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", ptr " }>, align 8
@.d132 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d133 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"%m" }>, align 8
@.d134 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"  call i32 @fputs(ptr " }>, align 8
@.d135 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c", ptr %s)\0A" }>, align 8
@.d136 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"__olang_ert_print" }>, align 8
@.d137 = private constant <{ i64, [28 x i8] }> <{ i64 0, [28 x i8] c"void @__olang_ert_print(ptr)" }>, align 8
@.d138 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"__olang_ert_req_print" }>, align 8
@.d139 = private constant <{ i64, [32 x i8] }> <{ i64 0, [32 x i8] c"void @__olang_ert_req_print(ptr)" }>, align 8
@.d140 = private constant <{ i64, [54 x i8] }> <{ i64 0, [54 x i8] c"  call void @__olang_ert_print(ptr %s)\0A  ret i32 1\0A}\0A\0A" }>, align 8
@.d141 = private constant <{ i64, [58 x i8] }> <{ i64 0, [58 x i8] c"  call void @__olang_ert_req_print(ptr %s)\0A  ret i32 1\0A}\0A\0A" }>, align 8
@.d142 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"main" }>, align 8
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.d143 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.d144 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"ptr sret(" }>, align 8
@.d145 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c") align " }>, align 8
@.d146 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" %sret" }>, align 8
@.d147 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"%p" }>, align 8
@.d148 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"ptr " }>, align 8
@.d149 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"ptr " }>, align 8
@.d150 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"i64 " }>, align 8
@.d151 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"n" }>, align 8
@.d152 = private constant <{ i64, [36 x i8] }> <{ i64 0, [36 x i8] c"insertvalue { i64, ptr } undef, i64 " }>, align 8
@.d153 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"n, 0" }>, align 8
@.d154 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c"insertvalue { i64, ptr } " }>, align 8
@.d155 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", ptr " }>, align 8
@.d156 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 1" }>, align 8
@.d157 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"{ i64, ptr } " }>, align 8
@.d158 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"ptr " }>, align 8
@.d159 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d160 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d161 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d162 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d163 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d164 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"[" }>, align 8
@.d165 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" x i8]" }>, align 8
@.d166 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d167 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
@.d168 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"getelementptr i8, ptr " }>, align 8
@.d169 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", i64 " }>, align 8
@.d170 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c" alignstack(8)" }>, align 8
@.d171 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d172 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
@.d173 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d174 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"ptr byval(" }>, align 8
@.d175 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c") align " }>, align 8
@.d176 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d177 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"ptr " }>, align 8
@.d178 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"ptr " }>, align 8
@.d179 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d180 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d181 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"ptr %buf" }>, align 8
@.d182 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"i64 %cap" }>, align 8
@.d183 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"ptr %len" }>, align 8
@.d184 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"ptr %res" }>, align 8
@.d185 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"__olang_self" }>, align 8
@.d186 = private constant <{ i64, [61 x i8] }> <{ i64 0, [61 x i8] c"@__olang_self = external thread_local(initialexec) global ptr" }>, align 8
@.d187 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"__olang_thread_enter" }>, align 8
@.d188 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"__olang_scope_close" }>, align 8
@.d189 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c"load ptr, ptr @__olang_self" }>, align 8
@.d190 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"icmp eq ptr " }>, align 8
@.d191 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", null" }>, align 8
@.d192 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"br i1 " }>, align 8
@.d193 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c", label %enter, label %go" }>, align 8
@.d194 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"enter:\0A" }>, align 8
@.d195 = private constant <{ i64, [33 x i8] }> <{ i64 0, [33 x i8] c"call void @__olang_thread_enter()" }>, align 8
@.d196 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"br label %go" }>, align 8
@.d197 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"go:\0A" }>, align 8
@.d198 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"%olang.scope" }>, align 8
@.d199 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"%olang.scope" }>, align 8
@.d200 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"zeroinitializer" }>, align 8
@.d201 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d202 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"ptr " }>, align 8
@.d203 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"ptr " }>, align 8
@.d204 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d205 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d206 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"void" }>, align 8
@.d207 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"call void @" }>, align 8
@.d208 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d209 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d210 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"call " }>, align 8
@.d211 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" @" }>, align 8
@.d212 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d213 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d214 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d215 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d216 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d217 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"extractvalue " }>, align 8
@.d218 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d219 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 0" }>, align 8
@.d220 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d221 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"extractvalue " }>, align 8
@.d222 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d223 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 1" }>, align 8
@.d224 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d225 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d226 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d227 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"icmp ne i32 " }>, align 8
@.d228 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 0" }>, align 8
@.d229 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"br i1 " }>, align 8
@.d230 = private constant <{ i64, [28 x i8] }> <{ i64 0, [28 x i8] c", label %failed, label %done" }>, align 8
@.d231 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"failed:\0A" }>, align 8
@.d232 = private constant <{ i64, [35 x i8] }> <{ i64 0, [35 x i8] c"call void @__olang_scope_close(ptr " }>, align 8
@.d233 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d234 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"ret i32 " }>, align 8
@.d235 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"done:\0A" }>, align 8
@.d236 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"extractvalue { i64, ptr } " }>, align 8
@.d237 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 0" }>, align 8
@.d238 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"extractvalue { i64, ptr } " }>, align 8
@.d239 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 1" }>, align 8
@.d240 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"icmp slt i64 %cap, " }>, align 8
@.d241 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"select i1 " }>, align 8
@.d242 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c", i64 %cap, i64 " }>, align 8
@.d243 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"icmp sgt i64 " }>, align 8
@.d244 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 0" }>, align 8
@.d245 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"select i1 " }>, align 8
@.d246 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", i64 " }>, align 8
@.d247 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c", i64 0" }>, align 8
@.d248 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"mul i64 " }>, align 8
@.d249 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d250 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"llvm.memmove.p0.p0.i64" }>, align 8
@.d251 = private constant <{ i64, [47 x i8] }> <{ i64 0, [47 x i8] c"void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)" }>, align 8
@.d252 = private constant <{ i64, [48 x i8] }> <{ i64 0, [48 x i8] c"call void @llvm.memmove.p0.p0.i64(ptr %buf, ptr " }>, align 8
@.d253 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", i64 " }>, align 8
@.d254 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c", i1 false)" }>, align 8
@.d255 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"i64" }>, align 8
@.d256 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"%len" }>, align 8
@.d257 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"i64 " }>, align 8
@.d258 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"i32 0" }>, align 8
@.d259 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"%res" }>, align 8
@.d260 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"i32 0" }>, align 8
@.d261 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d262 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"[" }>, align 8
@.d263 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" x i8]" }>, align 8
@.d264 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"undef" }>, align 8
@.d265 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d266 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"getelementptr i8, ptr " }>, align 8
@.d267 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", i64 " }>, align 8
@.d268 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"insertvalue " }>, align 8
@.d269 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d270 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d271 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d272 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"%sret" }>, align 8
@.d273 = private constant <{ i64, [35 x i8] }> <{ i64 0, [35 x i8] c"call void @__olang_scope_close(ptr " }>, align 8
@.d274 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d275 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d276 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"void" }>, align 8
@.d277 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"ret " }>, align 8
@.d278 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"void" }>, align 8
@.d279 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"i32" }>, align 8
@.d280 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"i64" }>, align 8
@.d281 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d282 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d283 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d284 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"void" }>, align 8
@.d285 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"define " }>, align 8
@.d286 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" @" }>, align 8
@.d287 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d288 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d289 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c") #0 {\0Aentry:\0A" }>, align 8
@.d290 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"}\0A\0A" }>, align 8
define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fsource_3aSpan(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = getelementptr %"compiler/source:Span", ptr %t1, i32 0, i32 0
  %t3 = load i32, ptr %t2, !tbaa !23
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t5 = getelementptr %"compiler/source:Span", ptr %t4, i32 0, i32 0
  %t6 = load i32, ptr %t5, !tbaa !23
  %t9 = icmp eq i32 %t3, %t6
  br i1 %t9, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb4
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/source:Span", ptr %t11, i32 0, i32 1
  %t13 = load i32, ptr %t12, !tbaa !23
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr %"compiler/source:Span", ptr %t14, i32 0, i32 1
  %t16 = load i32, ptr %t15, !tbaa !23
  %t19 = icmp eq i32 %t13, %t16
  br i1 %t19, label %bb3, label %bb1
bb3:
  br label %bb4
bb4:
  %t21 = load i1, ptr %l2, !tbaa !21
  store i1 %t21, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d291 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d292 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d293 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d294 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d295 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" (" }>, align 8
@.d296 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d297 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"not lowered: " }>, align 8
@.d298 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"entry:\0A  ret void\0A}\0A\0A" }>, align 8
@.d299 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"__olang_check_failed" }>, align 8
@.d300 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"not lowered" }>, align 8
@.d301 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"__olang_check_failed" }>, align 8
@.d302 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"not emitted" }>, align 8
@.d303 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"define internal ptr @" }>, align 8
@.d304 = private constant <{ i64, [50 x i8] }> <{ i64 0, [50 x i8] c".coro(ptr %env, ptr %home) presplitcoroutine #0 {\0A" }>, align 8
@.d305 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" !dbg !" }>, align 8
@.d306 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" {\0A" }>, align 8
@.d307 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"entry:\0A" }>, align 8
@.d308 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"  br label %start\0A" }>, align 8
@.d309 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"}\0A" }>, align 8
@.d310 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"@" }>, align 8
@.d311 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c" = constant " }>, align 8
@.d312 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"}>" }>, align 8
@.d313 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"@" }>, align 8
@.d314 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c" = external global i8" }>, align 8
@.d315 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"@" }>, align 8
@.d316 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c" = external constant " }>, align 8
@.d317 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"@" }>, align 8
@.d318 = private constant <{ i64, [33 x i8] }> <{ i64 0, [33 x i8] c" = available_externally constant " }>, align 8
@.d319 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d320 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"@" }>, align 8
@.d321 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c" = global " }>, align 8
@.d322 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c" zeroinitializer\0A" }>, align 8
@.d323 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"@" }>, align 8
@.d324 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c" = external global " }>, align 8
@.d325 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d326 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"@" }>, align 8
define available_externally void @__olang_scope_escape(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %un = icmp eq ptr %o, null
  br i1 %un, label %claim, label %done
claim:
  %me = load ptr, ptr @__olang_self
  store atomic ptr %me, ptr %op monotonic, align 8
  br label %done
done:
  ret void
}
define internal i1 @olang_lambda_327(ptr %env, i64 %a0, i64 %a1) #0 {
entry:
  %l2 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l5 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i1
  %rv = alloca i1
  %cp0 = getelementptr { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr }, ptr %env, i32 0, i32 0
  %cv0 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %cp0, !tbaa !28
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %cv0, ptr %l2
  %vq0 = getelementptr { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr }, ptr %env, i32 0, i32 1
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  br label %start
start:
  br label %bb0
bb0:
  %t4 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %vc0, ptr %vc0, ptr %l2, i64 %a0)
  store { i64, ptr } %t4, ptr %l5
  br label %bb1
bb1:
  %t8 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %vc0, ptr %vc0, ptr %l2, i64 %a1)
  store { i64, ptr } %t8, ptr %l8
  br label %bb2
bb2:
  %t9 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t10 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t11 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLess(ptr %vc0, ptr %vc0, { i64, ptr } %t9, { i64, ptr } %t10)
  store i1 %t11, ptr %l9
  br label %bb3
bb3:
  %t12 = load i1, ptr %l9, !tbaa !21
  store i1 %t12, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d328 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"G_2e" }>, align 8
@.d329 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c" by the self-hosted compiler: " }>, align 8
@.d330 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d331 = private constant <{ i64, [45 x i8] }> <{ i64 0, [45 x i8] c"entry:\0A  call void @__olang_check_failed(ptr " }>, align 8
@.d332 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c")\0A  unreachable\0A}\0A\0A" }>, align 8
@.d333 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"olang." }>, align 8
declare void @__olang_sb_put(ptr, ptr, i64)
define linkonce_odr void @olang_2eHelperKind_2eRender_2ecompiler_2fmir_3aHelperKind(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load i32, ptr %a0
  %t3 = sext i32 %t2 to i64
  switch i64 %t3, label %bb1 [ i64 0, label %bb2 i64 1, label %bb3 i64 2, label %bb4 i64 3, label %bb5 ]
bb1:
  br label %ret
bb2:
  %t5 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d548, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d548, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t5, i64 %t6)
  br label %bb1
bb3:
  %t7 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d549, i32 0, i32 1) }, 1
  %t8 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d549, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t7, i64 %t8)
  br label %bb1
bb4:
  %t9 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d550, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d550, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t9, i64 %t10)
  br label %bb1
bb5:
  %t11 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d551, i32 0, i32 1) }, 1
  %t12 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d551, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t11, i64 %t12)
  br label %bb1
ret:
  ret void
}

@.d334 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
declare void @__olang_sb_done(ptr)
@.d335 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"_adapter" }>, align 8
@.d336 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"olang.init." }>, align 8
@.d337 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c".top" }>, align 8
@.d338 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d339 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"olang.anyrender" }>, align 8
@.d340 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d341 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"|" }>, align 8
@.d342 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"olang_textcopy" }>, align 8
@.d343 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"llvm.memcpy.p0.p0.i64" }>, align 8
@.d344 = private constant <{ i64, [46 x i8] }> <{ i64 0, [46 x i8] c"void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)" }>, align 8
@.d345 = private constant <{ i64, [94 x i8] }> <{ i64 0, [94 x i8] c"define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {\0Aentry:\0A" }>, align 8
@.d346 = private constant <{ i64, [66 x i8] }> <{ i64 0, [66 x i8] c"  %big = icmp ugt i64 %n, 16\0A  br i1 %big, label %call, label %s8\0A" }>, align 8
@.d347 = private constant <{ i64, [86 x i8] }> <{ i64 0, [86 x i8] c"call:\0A  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)\0A  ret void\0A" }>, align 8
@.d348 = private constant <{ i64, [67 x i8] }> <{ i64 0, [67 x i8] c"s8:\0A  %ge8 = icmp uge i64 %n, 8\0A  br i1 %ge8, label %w8, label %s4\0A" }>, align 8
@.d349 = private constant <{ i64, [103 x i8] }> <{ i64 0, [103 x i8] c"w8:\0A  %e8 = sub i64 %n, 8\0A  %a8 = load i64, ptr %s, align 1\0A  %sb8 = getelementptr i8, ptr %s, i64 %e8\0A" }>, align 8
@.d350 = private constant <{ i64, [112 x i8] }> <{ i64 0, [112 x i8] c"  %b8 = load i64, ptr %sb8, align 1\0A  store i64 %a8, ptr %d, align 1\0A  %db8 = getelementptr i8, ptr %d, i64 %e8\0A" }>, align 8
@.d351 = private constant <{ i64, [46 x i8] }> <{ i64 0, [46 x i8] c"  store i64 %b8, ptr %db8, align 1\0A  ret void\0A" }>, align 8
@.d352 = private constant <{ i64, [67 x i8] }> <{ i64 0, [67 x i8] c"s4:\0A  %ge4 = icmp uge i64 %n, 4\0A  br i1 %ge4, label %w4, label %s1\0A" }>, align 8
@.d353 = private constant <{ i64, [103 x i8] }> <{ i64 0, [103 x i8] c"w4:\0A  %e4 = sub i64 %n, 4\0A  %a4 = load i32, ptr %s, align 1\0A  %sb4 = getelementptr i8, ptr %s, i64 %e4\0A" }>, align 8
@.d354 = private constant <{ i64, [112 x i8] }> <{ i64 0, [112 x i8] c"  %b4 = load i32, ptr %sb4, align 1\0A  store i32 %a4, ptr %d, align 1\0A  %db4 = getelementptr i8, ptr %d, i64 %e4\0A" }>, align 8
@.d355 = private constant <{ i64, [46 x i8] }> <{ i64 0, [46 x i8] c"  store i32 %b4, ptr %db4, align 1\0A  ret void\0A" }>, align 8
@.d356 = private constant <{ i64, [70 x i8] }> <{ i64 0, [70 x i8] c"s1:\0A  %none = icmp eq i64 %n, 0\0A  br i1 %none, label %done, label %w1\0A" }>, align 8
@.d357 = private constant <{ i64, [113 x i8] }> <{ i64 0, [113 x i8] c"w1:\0A  %h = lshr i64 %n, 1\0A  %e1 = sub i64 %n, 1\0A  %a1 = load i8, ptr %s\0A  %sh = getelementptr i8, ptr %s, i64 %h\0A" }>, align 8
@.d358 = private constant <{ i64, [115 x i8] }> <{ i64 0, [115 x i8] c"  %m1 = load i8, ptr %sh\0A  %se = getelementptr i8, ptr %s, i64 %e1\0A  %z1 = load i8, ptr %se\0A  store i8 %a1, ptr %d\0A" }>, align 8
@.d359 = private constant <{ i64, [107 x i8] }> <{ i64 0, [107 x i8] c"  %dh = getelementptr i8, ptr %d, i64 %h\0A  store i8 %m1, ptr %dh\0A  %de = getelementptr i8, ptr %d, i64 %e1\0A" }>, align 8
@.d360 = private constant <{ i64, [60 x i8] }> <{ i64 0, [60 x i8] c"  store i8 %z1, ptr %de\0A  br label %done\0Adone:\0A  ret void\0A}\0A" }>, align 8
@.d361 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"olang_textcopy" }>, align 8
@.d362 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d363 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"@" }>, align 8
@.d364 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d365 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c") #0 {" }>, align 8
@.d366 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d367 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"define dso_local " }>, align 8
@.d368 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"@" }>, align 8
@.d369 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d370 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c") #0 {\0Aentry:\0A" }>, align 8
@.d371 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"void" }>, align 8
@.d372 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"  tail call void @" }>, align 8
@.d373 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d374 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c")\0A  ret void\0A}\0A\0A" }>, align 8
@.d375 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"  %r = tail call " }>, align 8
@.d376 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" @" }>, align 8
@.d377 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d378 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c")\0A  ret " }>, align 8
@.d379 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" %r\0A}\0A\0A" }>, align 8
@.d380 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d381 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"a place with no base" }>, align 8
@.d382 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"getelementptr " }>, align 8
@.d383 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", ptr " }>, align 8
@.d384 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c", i32 0, i32 " }>, align 8
@.d385 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d386 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"ptr" }>, align 8
@.d387 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"getelementptr " }>, align 8
@.d388 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", ptr " }>, align 8
@.d389 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c", i32 0, i32 1" }>, align 8
@.d390 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d391 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"  " }>, align 8
@.d392 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c" = alloca " }>, align 8
@.d393 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c", align " }>, align 8
@.d394 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"bfloat" }>, align 8
@.d395 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"half" }>, align 8
@.d396 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"bitcast " }>, align 8
@.d397 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d398 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" to " }>, align 8
@.d399 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"half" }>, align 8
@.d400 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"an Exit " }>, align 8
define linkonce_odr void @olang_2eHelperKind_2eRender_2ecompiler_2fmir_3aExitKind(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load i32, ptr %a0
  %t3 = sext i32 %t2 to i64
  switch i64 %t3, label %bb1 [ i64 0, label %bb2 i64 1, label %bb3 i64 2, label %bb4 i64 3, label %bb5 i64 4, label %bb6 i64 5, label %bb7 i64 6, label %bb8 i64 7, label %bb9 i64 8, label %bb10 i64 9, label %bb11 i64 10, label %bb12 i64 11, label %bb13 ]
bb1:
  br label %ret
bb2:
  %t5 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d552, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d552, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t5, i64 %t6)
  br label %bb1
bb3:
  %t7 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d553, i32 0, i32 1) }, 1
  %t8 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d553, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t7, i64 %t8)
  br label %bb1
bb4:
  %t9 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d554, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d554, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t9, i64 %t10)
  br label %bb1
bb5:
  %t11 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d555, i32 0, i32 1) }, 1
  %t12 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d555, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t11, i64 %t12)
  br label %bb1
bb6:
  %t13 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d556, i32 0, i32 1) }, 1
  %t14 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d556, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t13, i64 %t14)
  br label %bb1
bb7:
  %t15 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d557, i32 0, i32 1) }, 1
  %t16 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d557, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t15, i64 %t16)
  br label %bb1
bb8:
  %t17 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d558, i32 0, i32 1) }, 1
  %t18 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d558, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t17, i64 %t18)
  br label %bb1
bb9:
  %t19 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d559, i32 0, i32 1) }, 1
  %t20 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d559, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t19, i64 %t20)
  br label %bb1
bb10:
  %t21 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d560, i32 0, i32 1) }, 1
  %t22 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d560, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t21, i64 %t22)
  br label %bb1
bb11:
  %t23 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d561, i32 0, i32 1) }, 1
  %t24 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d561, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t23, i64 %t24)
  br label %bb1
bb12:
  %t25 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d562, i32 0, i32 1) }, 1
  %t26 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d562, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t25, i64 %t26)
  br label %bb1
bb13:
  %t27 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d563, i32 0, i32 1) }, 1
  %t28 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d563, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t27, i64 %t28)
  br label %bb1
ret:
  ret void
}

@.d401 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"ended" }>, align 8
@.d402 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d403 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"__olang_ert_pass" }>, align 8
@.d404 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c"void @__olang_ert_pass(ptr)" }>, align 8
@.d405 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"__olang_test_error" }>, align 8
@.d406 = private constant <{ i64, [29 x i8] }> <{ i64 0, [29 x i8] c"void @__olang_test_error(ptr)" }>, align 8
@.d407 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c": left the test\0A" }>, align 8
@.d408 = private constant <{ i64, [32 x i8] }> <{ i64 0, [32 x i8] c"call void @__olang_ert_pass(ptr " }>, align 8
@.d409 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d410 = private constant <{ i64, [34 x i8] }> <{ i64 0, [34 x i8] c"call void @__olang_test_error(ptr " }>, align 8
@.d411 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d412 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"unreachable" }>, align 8
@.d413 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d414 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"__olang_bang_failed" }>, align 8
@.d415 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c"__olang_bang_failed_plain" }>, align 8
@.d416 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"void @" }>, align 8
@.d417 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"(ptr)" }>, align 8
@__olang_prog_scope = external thread_local(initialexec) global ptr
@.d418 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
@.d419 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d420 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"call void @" }>, align 8
@.d421 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"(ptr " }>, align 8
@.d422 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d423 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"unreachable" }>, align 8
@.d424 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"__olang_check_failed" }>, align 8
@.d425 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
@.d426 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d427 = private constant <{ i64, [36 x i8] }> <{ i64 0, [36 x i8] c"call void @__olang_check_failed(ptr " }>, align 8
@.d428 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d429 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c"__olang_check_failed_text" }>, align 8
@.d430 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
@.d431 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
@.d432 = private constant <{ i64, [41 x i8] }> <{ i64 0, [41 x i8] c"call void @__olang_check_failed_text(ptr " }>, align 8
@.d433 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c", { i64, ptr } " }>, align 8
@.d434 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d435 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"unreachable" }>, align 8
@.d436 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"zext" }>, align 8
@.d437 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"sext" }>, align 8
@.d438 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d439 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" to i64" }>, align 8
@.d440 = private constant <{ i64, [36 x i8] }> <{ i64 0, [36 x i8] c"insertvalue { i64, ptr } undef, i64 " }>, align 8
@.d441 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 0" }>, align 8
@.d442 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c"insertvalue { i64, ptr } " }>, align 8
@.d443 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", ptr " }>, align 8
@.d444 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 1" }>, align 8
@.d445 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"undef" }>, align 8
@.d446 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"insertvalue " }>, align 8
@.d447 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d448 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d449 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"zeroinitializer" }>, align 8
@.d450 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"__olang_prog_scope" }>, align 8
@.d451 = private constant <{ i64, [67 x i8] }> <{ i64 0, [67 x i8] c"@__olang_prog_scope = external thread_local(initialexec) global ptr" }>, align 8
@.d452 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"ptr" }>, align 8
@.d453 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"@__olang_prog_scope" }>, align 8
@.d454 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"lshr i32 " }>, align 8
@.d455 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c", 16" }>, align 8
@.d456 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"and i32 " }>, align 8
@.d457 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c", 65535" }>, align 8
@.d458 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"0" }>, align 8
@.d459 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"icmp eq i32 " }>, align 8
@.d460 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d461 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"select i1 " }>, align 8
@.d462 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", i32 " }>, align 8
@.d463 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"icmp eq i32 " }>, align 8
@.d464 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 0" }>, align 8
@.d465 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"shl i32 " }>, align 8
@.d466 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c", 16" }>, align 8
@.d467 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"or i32 " }>, align 8
@.d468 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d469 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"select i1 " }>, align 8
@.d470 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c", i32 0, i32 " }>, align 8
@.d471 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d472 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"!" }>, align 8
@.d473 = private constant <{ i64, [33 x i8] }> <{ i64 0, [33 x i8] c" = distinct !DISubprogram(name: \22" }>, align 8
@.d474 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"\22, scope: !" }>, align 8
@.d475 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c", file: !" }>, align 8
@.d476 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c", line: " }>, align 8
@.d477 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c", type: !" }>, align 8
@.d478 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c", scopeLine: " }>, align 8
@.d479 = private constant <{ i64, [38 x i8] }> <{ i64 0, [38 x i8] c", spFlags: DISPFlagDefinition, unit: !" }>, align 8
@.d480 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c")\0A" }>, align 8
@.d481 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"__olang_ert_req_set" }>, align 8
@.d482 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c"void @__olang_ert_req_set(ptr)" }>, align 8
@.d483 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
@.d484 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d485 = private constant <{ i64, [35 x i8] }> <{ i64 0, [35 x i8] c"call void @__olang_ert_req_set(ptr " }>, align 8
@.d486 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d487 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"try passed it on" }>, align 8
@.d488 = private constant <{ i64, [40 x i8] }> <{ i64 0, [40 x i8] c"a task failed, and its join passed it on" }>, align 8
@.d489 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"raised here" }>, align 8
@.d490 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"__olang_ert_pass" }>, align 8
@.d491 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"__olang_ert_raise" }>, align 8
@.d492 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"void @" }>, align 8
@.d493 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"(ptr)" }>, align 8
@.d494 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
@.d495 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d496 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"call void @" }>, align 8
@.d497 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"(ptr " }>, align 8
@.d498 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d499 = private constant <{ i64, [35 x i8] }> <{ i64 0, [35 x i8] c"getelementptr %olang.unwind, ptr %u" }>, align 8
@.d500 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c", i32 0, i32 0" }>, align 8
@.d501 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"ptr" }>, align 8
@.d502 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"ptr" }>, align 8
@.d503 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"@__olang_unwind_top" }>, align 8
@.d504 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"0123456789ABCDEF" }>, align 8
@.d505 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\5C" }>, align 8
@.d506 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"0123456789ABCDEF" }>, align 8
define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.d507 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"cbrt" }>, align 8
@.d508 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"exp" }>, align 8
@.d509 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"exp2" }>, align 8
@.d510 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"expm1" }>, align 8
@.d511 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"log" }>, align 8
@.d512 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"log2" }>, align 8
@.d513 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"log10" }>, align 8
@.d514 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"log1p" }>, align 8
@.d515 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"pow" }>, align 8
@.d516 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"hypot" }>, align 8
@.d517 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"sin" }>, align 8
@.d518 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"cos" }>, align 8
@.d519 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"tan" }>, align 8
@.d520 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"asin" }>, align 8
@.d521 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"acos" }>, align 8
@.d522 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"atan" }>, align 8
@.d523 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"atan2" }>, align 8
@.d524 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"sinh" }>, align 8
@.d525 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"cosh" }>, align 8
@.d526 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"tanh" }>, align 8
@.d527 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"erf" }>, align 8
@.d528 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"erfc" }>, align 8
@.d529 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"f" }>, align 8
@.d530 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d531 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d532 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"bool" }>, align 8
@.d533 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"i8" }>, align 8
@.d534 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"i16" }>, align 8
@.d535 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"int32" }>, align 8
@.d536 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"int64" }>, align 8
@.d537 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"byte" }>, align 8
@.d538 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"u16" }>, align 8
@.d539 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"u32" }>, align 8
@.d540 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"u64" }>, align 8
@.d541 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"f16" }>, align 8
@.d542 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"bf16" }>, align 8
@.d543 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"float32" }>, align 8
@.d544 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"float64" }>, align 8
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cBool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cBool_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.d545 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_Hf48d6d4096e547b8075d5a903caa3d54(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.d546 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI32_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI32_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aWriteKind_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fmir_3aWriteKind_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aOperand_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fmir_3aOperand_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.d547 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@__olang_self = external thread_local(initialexec) global ptr
define available_externally ptr @__olang_capture_scope(ptr %s) alwaysinline {
entry:
  %isprog = icmp eq ptr %s, null
  br i1 %isprog, label %prog, label %mine
prog:
  %p = load ptr, ptr @__olang_prog_scope
  ret ptr %p
mine:
  %m = call ptr @__olang_scope_mine(ptr %s)
  ret ptr %m
}
@.d548 = private unnamed_addr constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"HelperKind.Render" }>, align 8
@.d549 = private unnamed_addr constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"HelperKind.Equal" }>, align 8
@.d550 = private unnamed_addr constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"HelperKind.Hash" }>, align 8
@.d551 = private unnamed_addr constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"HelperKind.Zero" }>, align 8
@.d552 = private unnamed_addr constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"ExitKind.Done" }>, align 8
@.d553 = private unnamed_addr constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"ExitKind.Fail" }>, align 8
@.d554 = private unnamed_addr constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"ExitKind.Abort" }>, align 8
@.d555 = private unnamed_addr constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"ExitKind.Unreachable" }>, align 8
@.d556 = private unnamed_addr constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"ExitKind.NullReached" }>, align 8
@.d557 = private unnamed_addr constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"ExitKind.Assert" }>, align 8
@.d558 = private unnamed_addr constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"ExitKind.SliceBounds" }>, align 8
@.d559 = private unnamed_addr constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"ExitKind.ArrayLength" }>, align 8
@.d560 = private unnamed_addr constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"ExitKind.As" }>, align 8
@.d561 = private unnamed_addr constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"ExitKind.FixedLength" }>, align 8
@.d562 = private unnamed_addr constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"ExitKind.Error" }>, align 8
@.d563 = private unnamed_addr constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"ExitKind.Escaped" }>, align 8
define available_externally ptr @__olang_scope_mine(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %me = load ptr, ptr @__olang_self
  %own = icmp eq ptr %o, %me
  br i1 %own, label %mine, label %slow
mine:
  ret ptr %s
slow:
  %r = call ptr @__olang_scope_mine_slow(ptr %s)
  ret ptr %r
}
declare ptr @__olang_scope_mine_slow(ptr) noinline
@G_2ecompiler_2femit_2ePartSize = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\10\00\00\00\00\00" }>, align 8
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRetLlvm(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2eSymbol(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/generic:AnyTable" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fgeneric_3aAnyTable_3e_2e_H5e3c685c1de22cee1b092c35d74f13cd(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etypeid(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2ewant(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_bb561cc43498cf8_4d9e3dd6da251fdc = external constant [0 x i8]
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
@G_2ecompiler_2ftypes_2eAnySlotBase = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2femit_2eHomeShared = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FF\FF\FF\FF\FF\FF\FF\FF" }>, align 8
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eitem(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, i64 %a2, { i64, ptr } %a3, { i64, ptr } %a4)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eVoidT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eNoreturnT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\11\00\00\00" }>, align 8
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLayout(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/cabi:Way" @compiler_2fcabi_2eResult(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fcabi_2ePartsType(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_6aada305a3873fb6_c16c54d6f05c33ea = external constant [0 x i8]
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_He27db0a1785588531472bfd2db42574f(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha4444909f5ef14f7626d25b8f59e6ba2(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
@olang_loc_5836d127b451ff05_764b57a187e296f1 = external constant [0 x i8]
@G_2ecompiler_2femit_2eHomeLocal = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FE\FF\FF\FF\FF\FF\FF\FF" }>, align 8
declare { i64, ptr } @compiler_2femit_2eescape(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6f7a2f8d839c49b6e7a19c287d4b190c(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgNew(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2ePathOf(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i32, { i64, ptr } } @std_2fos_2eCwd(ptr %v0)
@olang_loc_d8b0748be4d5a5b9_c527c32a89be493d = external constant [0 x i8]
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgShared(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eBoolT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgPair(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, { i64, ptr } %a2, i32 %a3, { i64, ptr } %a4, i32 %a5)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSize(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgBytes(ptr %v0, ptr %a0)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2efieldNames(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i64 %a2)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOffsets(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgTypeName(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCaseNames(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_649f734ddce51468_b7eb8be07e4dd31c = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etext(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eenumWords(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePayloadSize(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edefine(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2esanInit(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2femit_2ecompiler_2femit_3aEmitter_2eglobalOrder(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %a1)
@olang_loc_4076b09b5c48092e_8975d1b2e9d279c2 = external constant [0 x i8]
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2feval_3aImage_3e_2e_H901ad831a5883703dcf426ee01511832(ptr %v0, ptr %a0, i64 %a1)
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorWords(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eerrName(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2etraced(ptr %v0, ptr %a0)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2femit_2ecompiler_2femit_3aEmitter_2earrayOfE(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_Ha6bcf4d517e3d7b46809e1dbf938da91(ptr %v0, ptr %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_70000d3e005ea498_c6a0fd2b538569fc = external constant [0 x i8]
@olang_loc_8dd51a70be22f844_db8bd8df095848b0 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare void @compiler_2fmir_3aFn_2ector(ptr %out, ptr %v0, { i64, [2 x i64] } %a0, i32 %a1, i64 %a2, %"compiler/source:Span" %a3)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %v0)
declare %"compiler/cabi:Way" @compiler_2fcabi_3aWay_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, i32 %a0, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %a1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %a2, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %a3, { i64, ptr } %a4)
declare %"compiler/cabi:Regs" @compiler_2fcabi_3aRegs_2ector(ptr %v0, i64 %a0, i64 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAlign(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePassing(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare %"compiler/cabi:Way" @compiler_2fcabi_2eParam(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, i32 %a2, ptr %a3)
declare i64 @compiler_2fcabi_2eSpan(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eReplace_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4)
declare i64 @std_2fprelude_2fnumber_2eI64_2eMax_3cI64_3e(i64 %a0, i64 %a1)
@olang_loc_ce3f793afe7e8735_eee0e2f7e7e28841 = external constant [0 x i8]
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eslot(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2ememmove(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, i64 %a3)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eViaMemory(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fmir_2ePassedCount(ptr %v0, ptr %a0, { i64, [7 x i64] } %a1, i32 %a2)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hfabcb4ab830a5416feda1aea3d8bba10(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_9000b3cdde9de97e_540aa7fc20a2aa2a = external constant [0 x i8]
@olang_loc_882423aaa1f01f7f_b9c3af967e36d8eb = external constant [0 x i8]
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2femit_2ecompiler_2femit_3aEmitter_2eExportErrors(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eToAr_H9d0f958437b2bc29fe1d416dfb9901d7(ptr %v0, ptr %v1, ptr %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_86228246ceb03788_7d79aafe137da84c = external constant [0 x i8]
@olang_loc_752793a239a1b159_2b674a598082827d = external constant [0 x i8]
@olang_loc_b86588aed8d09d62_e60b6944d2effe6 = external constant [0 x i8]
@olang_loc_89b1df4cc9c3ef97_fe8a037694fb6c2b = external constant [0 x i8]
@olang_loc_fc56b98312278d43_1fce42e2bc631e6f = external constant [0 x i8]
@olang_loc_c939e30cbacc87b4_9ec3789a05f46010 = external constant [0 x i8]
declare i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ehomeOf(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclared(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
declare void @compiler_2flower_2ecompiler_2flower_3aLowerer_2eLowerKey(ptr %out, ptr %v0, ptr %v1, ptr %a0, { i64, [2 x i64] } %a1)
declare i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ehasEnv(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
declare i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2epassedOf(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, i32 %a2)
declare { i64, ptr } @compiler_2femit_2elinkFor(ptr %v0, i64 %a0)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eheader(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, [2 x i64] } %a1, i32 %a2, { i64, ptr } %a3, i64 %a4, i1 %a5, { i64, ptr } %a6)
declare { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3aFn_2eVerify(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, { i64, ptr } %a0)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2egap(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eisGlobalInit(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2efnItem(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, [2 x i64] } %a1, i32 %a2, { i64, ptr } %a3, i64 %a4, i1 %a5, { i64, ptr } %a6)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2erun(ptr %v0, ptr %a0)
@olang_loc_6b15eaaa16ffdc11_37cb8c68772d91a5 = external constant [0 x i8]
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2edeclareVars(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2egenNext(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, [2 x i64] } %a1, ptr %a2, { i64, ptr } %a3, i64 %a4, { i64, ptr } %a5)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2egenDrop(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aLocal_3e_2eLen_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2femit_2efoldSlots(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eglobalSym(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2)
declare i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eglobalBody(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare { i32, %"compiler/eval:Image" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2feval_3aImage_3e_2e_Hf0a310b4530fd6279fda9cb6330ad681(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/eval:Image" @compiler_2feval_3aImage_2ector(ptr %v0)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ebakedText(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, ptr %a2)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_67352ecb15e68ba0_c3979b973b302ad4 = external constant [0 x i8]
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2feval_3aBlob_3e_2eLen_3ccompiler_2feval_3aBlob_3e(ptr %v0, ptr %a0)
declare %"compiler/eval:Blob" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2feval_3aBlob_3e_2eAt_3ccompiler_2feval_3aBlob_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_6c4f253a42e065fd_ca2f6afe461eeb41 = external constant [0 x i8]
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9b83f66eba65594537030636cb0b52b7(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_a37d1f87ccda68bc_daadd8872686b520 = external constant [0 x i8]
declare %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eIter_3cI64_2c_20Bool_3e(ptr %v0, ptr %v1, ptr %a0)
declare { i32, %"std/prelude/map:MapEntry.eb00e4a6e4307a4e46e40fbcd79d6b4f" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3cI64_2c_20Bool_3e_2eNext_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0)
@olang_loc_48c777cbd3c6a1a2_6303d50cbcfc1b86 = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eToArray_3cI64_3e(ptr %v0, ptr %v1, ptr %a0)
declare void @std_2fprelude_2farray_2eArray_3cI64_3e_2eSort_3cI64_2c_20_3f_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1c, ptr %a1e)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ehead(ptr %v0, ptr %v1, ptr %a0)
declare i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ealiased(ptr %v0, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eHash(ptr %v0, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2econstText(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i64 %a2)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ebodySym(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eUnnamed(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanonNamed(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_325a0aca37049b03_8faf0435ed6a0227 = external constant [0 x i8]
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecanonOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2femit_2erefsIn(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_6f064da57090b2af_17093dce158f11fb = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9162e3b7f03fcbf954b681204d5f6cca(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_f5feee0c0f7dd320_8e2d9d91f1e1268c = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_fb18e47b3c77ad7d_7c94e7cf0a0fcab9 = external constant [0 x i8]
@olang_loc_7f6652826e00de1e_418f3021b2f06a1a = external constant [0 x i8]
@olang_loc_679011f6b0c6ee1b_3818b84a191b3b77 = external constant [0 x i8]
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elocalAt(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2elocalType(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2egap(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_a45e6d34f8d75be7_fb9ba052a05cfc3b = external constant [0 x i8]
declare { i64, [1 x i64] } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aProj_3e_2eAt_3ccompiler_2fmir_3aProj_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2efieldList(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etbaa(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i1 %a2)
declare i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2erunTime(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2edescTag(ptr %v0, ptr %v1, ptr %a0, i1 %a1, i1 %a2)
declare { { i64, ptr }, i32 } @compiler_2femit_2ecompiler_2femit_3afnEm_2eelemAt(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, i32 %a2, { i64, ptr } %a3, { i64, ptr } %a4)
declare i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2ecasesList(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_f0091f918c975106_bc2d594a86836fba = external constant [0 x i8]
@olang_loc_44ab2decf02f961d_3f31a3219a480a51 = external constant [0 x i8]
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2etmp(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ebf16Bits(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i1 %a2)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eopaque16(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fmir_2eExitText(ptr %v0, i32 %a0)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2econstText(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_15d05b44c0be072a_cdffff4fd774d83e = external constant [0 x i8]
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elocated(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2)
@olang_loc_7b8962df1e5235eb_6d0c23ccefebcb3f = external constant [0 x i8]
declare i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eotype(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %v1, ptr %a0, { i64, [4 x i64] } %a1, i32 %a2)
declare { { i64, ptr }, { i64, ptr } } @compiler_2femit_2ecompiler_2femit_3afnEm_2earrayParts(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2)
@olang_loc_9d518c27a973a5b0_d4b76855814c5604 = external constant [0 x i8]
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBasicBlock_3e_2eRu_H05f2a0ad75f6ffeece9ab76b4dcd7cb0(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_8a0f087481b95ab0_a13f080fe7b316d4 = external constant [0 x i8]
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aStmt_3e_2eLen_3ccompiler_2fmir_3aStmt_3e(ptr %v0, ptr %a0)
declare { i64, [21 x i64] } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aStmt_3e_2eAt_3ccompiler_2fmir_3aStmt_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/mir:ScopeInfo" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeInfo_3e_2eAt_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_9d64128d60439a41_20f9e6973a71ad85 = external constant [0 x i8]
declare i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2eplainWrite(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
declare i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2erefIs(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1, i64 %a2)
@olang_loc_28dd7919903bc2a_4577237eccb57ce = external constant [0 x i8]
@olang_loc_6846df2bf697eaeb_3c0ad43c6c9a3c0f = external constant [0 x i8]
@olang_loc_2bfcda938bdeba4c_88387621cebbefd8 = external constant [0 x i8]
declare { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %a0, %"compiler/mir:Range" %a1, i64 %a2)
declare i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eposition(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2edata(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, i64 %a3, %"compiler/source:Span" %a4, i1 %a5)
@olang_loc_37dcdc821423a995_2a435c3b360fb831 = external constant [0 x i8]
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLineAt(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgName(ptr %v0, ptr %v1, ptr %a0, { i64, [2 x i64] } %a1)
declare i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgSubTy(ptr %v0, ptr %a0)
declare i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgCu(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3aFn_2eRaiseText(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
@olang_loc_2ea555a1037c9329_7e95fb4c4c24cb65 = external constant [0 x i8]
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI32_2c_20I64_3e_2ePut_3cI32_2c_20I64_3e(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
@olang_loc_bf62c1c7e423c058_299389d9c8f1c434 = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI32_2c_20I64_3e_2eGet_3cI32_2c_20I64_3e(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_7bc7193ce72d0d52_c947a9f9cc48c9f6 = external constant [0 x i8]
@olang_loc_5dfa9b7395be5458_e24cfc313725a25c = external constant [0 x i8]
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aStmt_3e_2eRunFrom_3ccompiler_2fmir_3aStmt_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_cd3d2f4cb5172729_796de8126c3e3b8d = external constant [0 x i8]
declare i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2ebaseIs(ptr %v0, ptr %a0, %"compiler/mir:Place" %a1, i32 %a2)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eWritable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@olang_loc_aa77627ec6eb5ef2_35c32f6dd172e1f6 = external constant [0 x i8]
@olang_loc_adfc2b4e0bd5373_1e3a8de6ffd7da97 = external constant [0 x i8]
@G_2ecompiler_2femit_2ehexDigits = external constant <{ [8 x i8], ptr }>
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H2b85ceff512af6e6ca26c554a1c16247(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i1 %a2)
declare i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eLen_3cI64_2c_20I64_3e(ptr %v0, ptr %a0)
@G_2ecompiler_2femit_2etbaaElem = available_externally constant <{ [120 x i8] }> <{ [120 x i8] c"\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\1F\00\00\00\00\00\00\00\51\00\00\00\00\00\00\00\52\00\00\00\00\00\00\00\21\00\00\00\00\00\00\00\22\00\00\00\00\00\00\00\20\00\00\00\00\00\00\00\53\00\00\00\00\00\00\00\54\00\00\00\00\00\00\00\55\00\00\00\00\00\00\00\56\00\00\00\00\00\00\00\57\00\00\00\00\00\00\00\23\00\00\00\00\00\00\00\24\00\00\00\00\00\00\00" }>, align 64
@G_2ecompiler_2femit_2etbaaName = external constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }>
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLess(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cBool_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI32_2c_20I64_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fmir_3aWriteKind_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fmir_3aOperand_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
