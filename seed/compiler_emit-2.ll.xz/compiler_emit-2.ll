; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"compiler/emit:Emitter" = type { ptr, ptr, ptr, ptr, i1, i1, i1, i1, i1, i1, i1, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, i64, i1, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i64, i64, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, { i64, ptr }, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, i1, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, i64, { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64, i64, i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"compiler/lower:Lowerer" = type { ptr, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i32, i32, i64, i64, i64, i64, i64, i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/mir:GenInfo", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64 }
%"compiler/mir:GenInfo" = type { %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i32, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"compiler/facts:Table", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/types:Table" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/facts:Table" = type { %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64 }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64, i32 }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, ptr, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/cabi:Regs" = type { i64, i64 }
%"compiler/cabi:Way" = type { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr } }
%"compiler/lower:Clone" = type { { i64, [2 x i64] }, i64, { i64, [2 x i64] }, i32 }
%"compiler/mir:Fn" = type { { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/text:LineIter" = type { { i64, ptr }, i64 }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1, i1, { i64, ptr }, ptr, i32 }
%"compiler/ast:Sig" = type { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, i1, ptr, i1, i1, { i64, ptr } }
%"compiler/ast:TypeDecl" = type { i32, { i64, ptr }, i1, ptr, { i64, ptr }, i32, i1 }
%"compiler/ast:StructBody" = type { { i64, ptr }, ptr, { i64, ptr }, %"compiler/source:Span", { i64, ptr }, { i64, ptr } }
%"compiler/ast:VarDecl" = type { { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, i1, i1, { i64, ptr }, i1 }
%"compiler/mir:Lvalue" = type { { i64, [2 x i64] }, %"compiler/mir:Range" }
%"compiler/mir:Range" = type { i32, i32 }
%"compiler/emit:fnEm" = type { ptr, ptr, { i64, [2 x i64] }, %"std/prelude/text:StringBuilder", %"std/prelude/text:StringBuilder", %"std/prelude/text:StringBuilder", i64, i64, i64, i32, i1, i1, i1, i1, i1, { i64, ptr }, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/text:StringBuilder", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, { i64, ptr }, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64, i64, i64, { i64, ptr }, i1 }
%"compiler/mir:ScopeInfo" = type { i32, i32, i32, %"compiler/source:Span", i32 }
%"compiler/mir:Task" = type { { i64, [7 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/source:Span", %"compiler/mir:Range" }
%"compiler/mir:TaskClause" = type { %"compiler/mir:Range", i1, { i64, [4 x i64] } }
%"compiler/typed:Item" = type { i32, i64 }
%"compiler/mir:Local" = type { i32, %"compiler/source:Span", i32, i32, { i64, [1 x i64] } }
%"compiler/mir:BasicBlock" = type { %"compiler/mir:StmtList", { i64, [8 x i64] } }
%"compiler/mir:StmtList" = type { { i64, ptr }, i64 }
%"compiler/mir:Case" = type { i64, i32 }
%"compiler/mir:Call" = type { { i64, [7 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Lvalue", i1, i32, i32, i32 }
%"compiler/typed:Block" = type { i32, { i64, ptr } }
%"compiler/emit:cDecls" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/emit:scopeUse" = type { { i64, ptr }, i1 }
define dso_local { i64, ptr } @compiler_2femit_2ecWordName(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca i1
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i8
  %l10 = alloca %"std/prelude/text:StringBuilder"
  %l16 = alloca i64
  %l19 = alloca i64
  %l37 = alloca { i64, ptr }
  %l44 = alloca i1
  %l47 = alloca i1
  %l49 = alloca i1
  %l50 = alloca i1
  %l51 = alloca { i64, ptr }
  %l56 = alloca i1
  %l57 = alloca { i64, ptr }
  %l61 = alloca i1
  %l64 = alloca ptr
  %l66 = alloca i8
  %l70 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l10
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l10
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  store i1 false, ptr %l2, !tbaa !21
  store i64 0, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t7 = load i64, ptr %l4, !tbaa !24
  %t8 = load i64, ptr %l3, !tbaa !24
  %t11 = icmp sgt i64 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load i64, ptr %l5, !tbaa !24
  %t15 = icmp sgt i64 %t13, 0
  br i1 %t15, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l16, !tbaa !24
  br label %bb7
bb4:
  %t17 = load i64, ptr %l4, !tbaa !24
  %t18 = load i64, ptr %l3, !tbaa !24
  %t21 = sub i64 %t17, %t18
  %t22 = load i64, ptr %l5, !tbaa !24
  %t25 = add i64 %t21, %t22
  %t27 = sub i64 %t25, 1
  %t28 = load i64, ptr %l5, !tbaa !24
  %t31 = sdiv i64 %t27, %t28
  store i64 %t31, ptr %l19, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb6
bb6:
  %t33 = load i64, ptr %l19, !tbaa !24
  store i64 %t33, ptr %l16, !tbaa !24
  br label %bb7
bb7:
  %t34 = load i64, ptr %l16, !tbaa !24
  store i64 %t34, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb8
bb8:
  %t35 = load i64, ptr %l7, !tbaa !24
  %t36 = load i64, ptr %l6, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb9, label %bb10
bb9:
  br label %bb37
bb10:
  br label %bb11
bb11:
  %t43 = load i64, ptr %l3, !tbaa !24
  %t44 = load i64, ptr %l7, !tbaa !24
  %t45 = load i64, ptr %l5, !tbaa !24
  %t48 = mul i64 %t44, %t45
  %t51 = add i64 %t43, %t48
  store i64 %t51, ptr %l8, !tbaa !24
  %t53 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t53, ptr %l37, !tbaa !27
  %t54 = load i64, ptr %l8, !tbaa !24
  %t56 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !27
  %t58 = getelementptr i8, ptr %t57, i64 %t54
  %t59 = load i8, ptr %t58, !tbaa !32
  store i8 %t59, ptr %l9, !tbaa !22
  %t61 = load i8, ptr %l9, !tbaa !22
  %t63 = icmp eq i8 %t61, 46
  br i1 %t63, label %bb12, label %bb13
bb12:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 95)
  br label %bb14
bb13:
  br label %bb15
bb14:
  store i1 true, ptr %l2, !tbaa !21
  br label %bb36
bb15:
  %t66 = load i1, ptr %l2, !tbaa !21
  br i1 %t66, label %bb16, label %bb17
bb16:
  %t68 = load i64, ptr %l8, !tbaa !24
  %t70 = icmp sgt i64 %t68, 0
  store i1 %t70, ptr %l44, !tbaa !21
  br label %bb18
bb17:
  store i1 false, ptr %l44, !tbaa !21
  br label %bb18
bb18:
  %t72 = load i1, ptr %l44, !tbaa !21
  br i1 %t72, label %bb19, label %bb20
bb19:
  %t73 = load i8, ptr %l9, !tbaa !22
  %t75 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %t73)
  store i1 %t75, ptr %l49
  br label %bb21
bb20:
  store i1 false, ptr %l47, !tbaa !21
  br label %bb22
bb21:
  %t76 = load i1, ptr %l49, !tbaa !21
  store i1 %t76, ptr %l47, !tbaa !21
  br label %bb22
bb22:
  %t77 = load i1, ptr %l47, !tbaa !21
  br i1 %t77, label %bb23, label %bb24
bb23:
  %t78 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t78, ptr %l51, !tbaa !27
  %t79 = load i64, ptr %l8, !tbaa !24
  %t81 = sub i64 %t79, 1
  %t83 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t84 = load ptr, ptr %t83, !tbaa !27
  %t85 = getelementptr i8, ptr %t84, i64 %t81
  %t86 = load i8, ptr %t85, !tbaa !32
  %t88 = icmp ne i8 %t86, 46
  store i1 %t88, ptr %l50, !tbaa !21
  br label %bb25
bb24:
  store i1 false, ptr %l50, !tbaa !21
  br label %bb25
bb25:
  %t90 = load i1, ptr %l50, !tbaa !21
  br i1 %t90, label %bb26, label %bb27
bb26:
  %t91 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t91, ptr %l57, !tbaa !27
  %t92 = load i64, ptr %l8, !tbaa !24
  %t94 = sub i64 %t92, 1
  %t96 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !27
  %t98 = getelementptr i8, ptr %t97, i64 %t94
  %t99 = load i8, ptr %t98, !tbaa !32
  %t101 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %t99)
  store i1 %t101, ptr %l61
  br label %bb28
bb27:
  store i1 false, ptr %l56, !tbaa !21
  br label %bb29
bb28:
  %t102 = load i1, ptr %l61, !tbaa !21
  %t103 = xor i1 %t102, true
  store i1 %t103, ptr %l56, !tbaa !21
  br label %bb29
bb29:
  %t105 = load i1, ptr %l56, !tbaa !21
  br i1 %t105, label %bb30, label %bb31
bb30:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 95)
  br label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb33
bb33:
  store ptr %l1, ptr %l64, !tbaa !29
  %t107 = load i8, ptr %l9, !tbaa !22
  %t109 = call i8 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eToUpper(i8 %t107)
  store i8 %t109, ptr %l66
  br label %bb34
bb34:
  %t110 = load ptr, ptr %l64, !tbaa !29
  %t111 = load i8, ptr %l66, !tbaa !22
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %t110, i8 %t111)
  br label %bb35
bb35:
  br label %bb36
bb36:
  %t112 = load i64, ptr %l7, !tbaa !24
  %t114 = add i64 %t112, 1
  store i64 %t114, ptr %l7, !tbaa !24
  br label %bb8
bb37:
  %t117 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t117, ptr %l70
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s0)
  %t118 = load { i64, ptr }, ptr %l70, !tbaa !27
  store { i64, ptr } %t118, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ebodySym(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l4 = alloca { i64, [2 x i64] }
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i64
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i32
  %l17 = alloca i64
  %l24 = alloca ptr
  %l27 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %l62 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %l74 = alloca { i64, ptr }
  %l84 = alloca ptr
  %l86 = alloca { i64, ptr }
  %l89 = alloca { i64, ptr }
  %l92 = alloca { i64, ptr }
  %l109 = alloca { i64, ptr }
  %l110 = alloca i32
  %l111 = alloca i64
  %l113 = alloca { i64, ptr }
  %l115 = alloca { i64, ptr }
  %l122 = alloca { i64, ptr }
  %l126 = alloca { i64, ptr }
  %l133 = alloca { i64, ptr }
  %l137 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.builder
  %s18room = alloca [64 x i8], align 8
  %s19 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/emit:Emitter", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = getelementptr %"compiler/lower:Lowerer", ptr %t9, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t13 = load i64, ptr %l1, !tbaa !24
  %t16 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t12, i64 %t13)
  store ptr %t16, ptr %l24
  br label %bb1
bb1:
  %t17 = load ptr, ptr %l24, !tbaa !29
  %t20 = getelementptr %"compiler/typed:Body", ptr %t17, i32 0, i32 1
  %t21 = load { i64, [2 x i64] }, ptr %t20
  store { i64, [2 x i64] } %t21, ptr %l4
  %t23 = load { i64, [2 x i64] }, ptr %l4
  %t25 = extractvalue { i64, [2 x i64] } %t23, 0
  %t26 = icmp eq i64 %t25, 0
  br i1 %t26, label %bb2, label %bb3
bb2:
  %t28 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t29 = getelementptr { i64 }, ptr %t28, i32 0, i32 0
  %t30 = load i64, ptr %t29
  store i64 %t30, ptr %l5, !tbaa !24
  br label %bb4
bb3:
  br label %bb6
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/emit:Emitter", ptr %t32, i32 0, i32 0
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t36 = load i64, ptr %l5, !tbaa !24
  %t39 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceName(ptr %v0, ptr %s1, ptr %t35, i64 %t36)
  store { i64, ptr } %t39, ptr %l34
  br label %bb5
bb5:
  %t40 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t40, 1
  %t42 = extractvalue { i64, ptr } %t40, 0
  %t43 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t42)
  call void @olang_textcopy(ptr %t43, ptr %t41, i64 %t42)
  %t44 = insertvalue { i64, ptr } undef, i64 %t42, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t43, 1
  store { i64, ptr } %t45, ptr %l27, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  br label %bb66
bb6:
  %t47 = load { i64, [2 x i64] }, ptr %l4
  %t49 = extractvalue { i64, [2 x i64] } %t47, 0
  %t50 = icmp eq i64 %t49, 1
  br i1 %t50, label %bb7, label %bb8
bb7:
  %t52 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t53 = getelementptr { i32, i32 }, ptr %t52, i32 0, i32 0
  %t54 = load i32, ptr %t53
  store i32 %t54, ptr %l6, !tbaa !23
  %t56 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t57 = getelementptr { i32, i32 }, ptr %t56, i32 0, i32 1
  %t58 = load i32, ptr %t57
  store i32 %t58, ptr %l7, !tbaa !23
  br label %bb9
bb8:
  br label %bb16
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t60 = load ptr, ptr %l2, !tbaa !29
  %t61 = load i32, ptr %l6, !tbaa !23
  %t63 = inttoptr i64 0 to ptr
  %t66 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s3, ptr %t63, ptr %t60, i32 %t61)
  store { i64, ptr } %t66, ptr %l43
  br label %bb10
bb10:
  %t67 = load i32, ptr %l7, !tbaa !23
  %t69 = icmp eq i32 %t67, 0
  br i1 %t69, label %bb11, label %bb12
bb11:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d0, i32 0, i32 1) }, ptr %l46, !tbaa !27
  br label %bb14
bb12:
  %t71 = load ptr, ptr %l2, !tbaa !29
  %t72 = load i32, ptr %l7, !tbaa !23
  %t74 = inttoptr i64 0 to ptr
  %t77 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanonList(ptr %v0, ptr %s3, ptr %t74, ptr %t71, i32 %t72)
  store { i64, ptr } %t77, ptr %l50
  br label %bb13
bb13:
  %t78 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d1, i32 0, i32 1) }, 1
  %t79 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d1, i32 0, i32 1) }, 0
  %t80 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t81 = extractvalue { i64, ptr } %t80, 1
  %t82 = extractvalue { i64, ptr } %t80, 0
  %t83 = add i64 %t79, %t82
  %t84 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d2, i32 0, i32 1) }, 1
  %t85 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d2, i32 0, i32 1) }, 0
  %t86 = add i64 %t83, %t85
  %t87 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t86)
  call void @olang_textcopy(ptr %t87, ptr %t78, i64 %t79)
  %t88 = getelementptr i8, ptr %t87, i64 %t79
  call void @olang_textcopy(ptr %t88, ptr %t81, i64 %t82)
  %t89 = getelementptr i8, ptr %t88, i64 %t82
  call void @olang_textcopy(ptr %t89, ptr %t84, i64 %t85)
  %t90 = insertvalue { i64, ptr } undef, i64 %t86, 0
  %t91 = insertvalue { i64, ptr } %t90, ptr %t87, 1
  %t93 = extractvalue { i64, ptr } %t91, 0
  %t94 = extractvalue { i64, ptr } %t91, 1
  %t95 = mul i64 %t93, 1
  %t96 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t95)
  call void @llvm.memcpy.p0.p0.i64(ptr %t96, ptr %t94, i64 %t95, i1 false)
  %t97 = insertvalue { i64, ptr } undef, i64 %t93, 0
  %t98 = insertvalue { i64, ptr } %t97, ptr %t96, 1
  store { i64, ptr } %t98, ptr %l46, !tbaa !27
  br label %bb14
bb14:
  %t100 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t100, 1
  %t102 = extractvalue { i64, ptr } %t100, 0
  %t103 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d3, i32 0, i32 1) }, 1
  %t104 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d3, i32 0, i32 1) }, 0
  %t105 = add i64 %t102, %t104
  %t106 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t107 = extractvalue { i64, ptr } %t106, 1
  %t108 = extractvalue { i64, ptr } %t106, 0
  %t109 = add i64 %t105, %t108
  %t110 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t109)
  call void @olang_textcopy(ptr %t110, ptr %t101, i64 %t102)
  %t111 = getelementptr i8, ptr %t110, i64 %t102
  call void @olang_textcopy(ptr %t111, ptr %t103, i64 %t104)
  %t112 = getelementptr i8, ptr %t111, i64 %t104
  call void @olang_textcopy(ptr %t112, ptr %t107, i64 %t108)
  %t113 = insertvalue { i64, ptr } undef, i64 %t109, 0
  %t114 = insertvalue { i64, ptr } %t113, ptr %t110, 1
  %t116 = extractvalue { i64, ptr } %t114, 0
  %t117 = extractvalue { i64, ptr } %t114, 1
  %t118 = mul i64 %t116, 1
  %t119 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t118)
  call void @llvm.memcpy.p0.p0.i64(ptr %t119, ptr %t117, i64 %t118, i1 false)
  %t120 = insertvalue { i64, ptr } undef, i64 %t116, 0
  %t121 = insertvalue { i64, ptr } %t120, ptr %t119, 1
  %t123 = call { i64, ptr } @compiler_2ftypes_2eSymbol(ptr %v1, ptr %v1, { i64, ptr } %t121)
  store { i64, ptr } %t123, ptr %l55
  br label %bb15
bb15:
  %t124 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t124, ptr %l27, !tbaa !27
  call void @__olang_scope_close(ptr %s3)
  br label %bb66
bb16:
  %t125 = load { i64, [2 x i64] }, ptr %l4
  %t127 = extractvalue { i64, [2 x i64] } %t125, 0
  %t128 = icmp eq i64 %t127, 3
  br i1 %t128, label %bb17, label %bb18
bb17:
  %t130 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t131 = getelementptr { i32 }, ptr %t130, i32 0, i32 0
  %t132 = load i32, ptr %t131
  store i32 %t132, ptr %l8, !tbaa !23
  br label %bb19
bb18:
  br label %bb22
bb19:
  store %olang.scope zeroinitializer, ptr %s6
  %t134 = load ptr, ptr %l2, !tbaa !29
  %t135 = load i32, ptr %l8, !tbaa !23
  %t137 = inttoptr i64 0 to ptr
  %t140 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s6, ptr %t137, ptr %t134, i32 %t135)
  store { i64, ptr } %t140, ptr %l62
  br label %bb20
bb20:
  %t141 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t142 = extractvalue { i64, ptr } %t141, 1
  %t143 = extractvalue { i64, ptr } %t141, 0
  %t144 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d4, i32 0, i32 1) }, 1
  %t145 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d4, i32 0, i32 1) }, 0
  %t146 = add i64 %t143, %t145
  %t147 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t146)
  call void @olang_textcopy(ptr %t147, ptr %t142, i64 %t143)
  %t148 = getelementptr i8, ptr %t147, i64 %t143
  call void @olang_textcopy(ptr %t148, ptr %t144, i64 %t145)
  %t149 = insertvalue { i64, ptr } undef, i64 %t146, 0
  %t150 = insertvalue { i64, ptr } %t149, ptr %t147, 1
  %t152 = extractvalue { i64, ptr } %t150, 0
  %t153 = extractvalue { i64, ptr } %t150, 1
  %t154 = mul i64 %t152, 1
  %t155 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t154)
  call void @llvm.memcpy.p0.p0.i64(ptr %t155, ptr %t153, i64 %t154, i1 false)
  %t156 = insertvalue { i64, ptr } undef, i64 %t152, 0
  %t157 = insertvalue { i64, ptr } %t156, ptr %t155, 1
  %t159 = call { i64, ptr } @compiler_2ftypes_2eSymbol(ptr %v1, ptr %v1, { i64, ptr } %t157)
  store { i64, ptr } %t159, ptr %l65
  br label %bb21
bb21:
  %t160 = load { i64, ptr }, ptr %l65, !tbaa !27
  store { i64, ptr } %t160, ptr %l27, !tbaa !27
  call void @__olang_scope_close(ptr %s6)
  br label %bb66
bb22:
  %t161 = load { i64, [2 x i64] }, ptr %l4
  %t163 = extractvalue { i64, [2 x i64] } %t161, 0
  %t164 = icmp eq i64 %t163, 4
  br i1 %t164, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb26
bb25:
  %t166 = load i64, ptr %l1, !tbaa !24
  %t167 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d5, i32 0, i32 1) }, 1
  %t168 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d5, i32 0, i32 1) }, 0
  %t170 = call i64 @__olang_fmt_i64(ptr null, i64 %t166)
  %t171 = add i64 %t168, %t170
  %t172 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t171)
  call void @olang_textcopy(ptr %t172, ptr %t167, i64 %t168)
  %t173 = getelementptr i8, ptr %t172, i64 %t168
  %t174 = call i64 @__olang_fmt_i64(ptr %t173, i64 %t166)
  %t175 = insertvalue { i64, ptr } undef, i64 %t171, 0
  %t176 = insertvalue { i64, ptr } %t175, ptr %t172, 1
  store { i64, ptr } %t176, ptr %l27, !tbaa !27
  br label %bb66
bb26:
  %t178 = load { i64, [2 x i64] }, ptr %l4
  %t180 = extractvalue { i64, [2 x i64] } %t178, 0
  %t181 = icmp eq i64 %t180, 5
  br i1 %t181, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb31
bb29:
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t184 = load i64, ptr %l1, !tbaa !24
  %t187 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etestSym(ptr %v0, ptr %v1, ptr %t183, i64 %t184)
  store { i64, ptr } %t187, ptr %l74
  br label %bb30
bb30:
  %t188 = load { i64, ptr }, ptr %l74, !tbaa !27
  store { i64, ptr } %t188, ptr %l27, !tbaa !27
  br label %bb66
bb31:
  %t189 = load { i64, [2 x i64] }, ptr %l4
  %t191 = extractvalue { i64, [2 x i64] } %t189, 0
  %t192 = icmp eq i64 %t191, 6
  br i1 %t192, label %bb32, label %bb33
bb32:
  %t194 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t195 = getelementptr { i64, i32 }, ptr %t194, i32 0, i32 0
  %t196 = load i64, ptr %t195
  store i64 %t196, ptr %l9, !tbaa !24
  %t198 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t199 = getelementptr { i64, i32 }, ptr %t198, i32 0, i32 1
  %t200 = load i32, ptr %t199
  store i32 %t200, ptr %l10, !tbaa !23
  br label %bb34
bb33:
  br label %bb38
bb34:
  store %olang.scope zeroinitializer, ptr %s11
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t204 = getelementptr %"compiler/emit:Emitter", ptr %t202, i32 0, i32 0
  %t205 = load ptr, ptr %t204, !tbaa !29
  %t207 = getelementptr %"compiler/generic:Program", ptr %t205, i32 0, i32 0
  %t208 = load ptr, ptr %t207, !tbaa !29
  %t210 = getelementptr %"compiler/load:Loader", ptr %t208, i32 0, i32 10
  %t211 = load i64, ptr %l9, !tbaa !24
  %t214 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t210, i64 %t211)
  store ptr %t214, ptr %l84
  br label %bb35
bb35:
  %t215 = load ptr, ptr %l84, !tbaa !29
  %t217 = getelementptr %"compiler/load:Module", ptr %t215, i32 0, i32 2
  %t218 = load { i64, ptr }, ptr %t217, !tbaa !27
  store { i64, ptr } %t218, ptr %l86, !tbaa !27
  %t219 = load ptr, ptr %l0, !tbaa !29
  %t220 = load i32, ptr %l10, !tbaa !23
  %t223 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etext(ptr %v0, ptr %s11, ptr %t219, i32 %t220)
  store { i64, ptr } %t223, ptr %l89
  br label %bb36
bb36:
  %t224 = load { i64, ptr }, ptr %l86, !tbaa !27
  %t225 = extractvalue { i64, ptr } %t224, 1
  %t226 = extractvalue { i64, ptr } %t224, 0
  %t227 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d6, i32 0, i32 1) }, 1
  %t228 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d6, i32 0, i32 1) }, 0
  %t229 = add i64 %t226, %t228
  %t230 = load { i64, ptr }, ptr %l89, !tbaa !27
  %t231 = extractvalue { i64, ptr } %t230, 1
  %t232 = extractvalue { i64, ptr } %t230, 0
  %t233 = add i64 %t229, %t232
  %t234 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d7, i32 0, i32 1) }, 1
  %t235 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d7, i32 0, i32 1) }, 0
  %t236 = add i64 %t233, %t235
  %t237 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t236)
  call void @olang_textcopy(ptr %t237, ptr %t225, i64 %t226)
  %t238 = getelementptr i8, ptr %t237, i64 %t226
  call void @olang_textcopy(ptr %t238, ptr %t227, i64 %t228)
  %t239 = getelementptr i8, ptr %t238, i64 %t228
  call void @olang_textcopy(ptr %t239, ptr %t231, i64 %t232)
  %t240 = getelementptr i8, ptr %t239, i64 %t232
  call void @olang_textcopy(ptr %t240, ptr %t234, i64 %t235)
  %t241 = insertvalue { i64, ptr } undef, i64 %t236, 0
  %t242 = insertvalue { i64, ptr } %t241, ptr %t237, 1
  %t244 = extractvalue { i64, ptr } %t242, 0
  %t245 = extractvalue { i64, ptr } %t242, 1
  %t246 = mul i64 %t244, 1
  %t247 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t246)
  call void @llvm.memcpy.p0.p0.i64(ptr %t247, ptr %t245, i64 %t246, i1 false)
  %t248 = insertvalue { i64, ptr } undef, i64 %t244, 0
  %t249 = insertvalue { i64, ptr } %t248, ptr %t247, 1
  %t251 = call { i64, ptr } @compiler_2ftypes_2eSymbol(ptr %v1, ptr %v1, { i64, ptr } %t249)
  store { i64, ptr } %t251, ptr %l92
  br label %bb37
bb37:
  %t252 = load { i64, ptr }, ptr %l92, !tbaa !27
  store { i64, ptr } %t252, ptr %l27, !tbaa !27
  call void @__olang_scope_close(ptr %s11)
  br label %bb66
bb38:
  %t253 = load { i64, [2 x i64] }, ptr %l4
  %t255 = extractvalue { i64, [2 x i64] } %t253, 0
  %t256 = icmp eq i64 %t255, 2
  br i1 %t256, label %bb39, label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb42
bb41:
  %t258 = load i64, ptr %l1, !tbaa !24
  %t259 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d8, i32 0, i32 1) }, 1
  %t260 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d8, i32 0, i32 1) }, 0
  %t262 = call i64 @__olang_fmt_i64(ptr null, i64 %t258)
  %t263 = add i64 %t260, %t262
  %t264 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t263)
  call void @olang_textcopy(ptr %t264, ptr %t259, i64 %t260)
  %t265 = getelementptr i8, ptr %t264, i64 %t260
  %t266 = call i64 @__olang_fmt_i64(ptr %t265, i64 %t258)
  %t267 = insertvalue { i64, ptr } undef, i64 %t263, 0
  %t268 = insertvalue { i64, ptr } %t267, ptr %t264, 1
  store { i64, ptr } %t268, ptr %l27, !tbaa !27
  br label %bb66
bb42:
  %t270 = load { i64, [2 x i64] }, ptr %l4
  %t272 = extractvalue { i64, [2 x i64] } %t270, 0
  %t273 = icmp eq i64 %t272, 7
  br i1 %t273, label %bb43, label %bb44
bb43:
  br label %bb45
bb44:
  br label %bb46
bb45:
  %t275 = load i64, ptr %l1, !tbaa !24
  %t276 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d9, i32 0, i32 1) }, 1
  %t277 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d9, i32 0, i32 1) }, 0
  %t279 = call i64 @__olang_fmt_i64(ptr null, i64 %t275)
  %t280 = add i64 %t277, %t279
  %t281 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t280)
  call void @olang_textcopy(ptr %t281, ptr %t276, i64 %t277)
  %t282 = getelementptr i8, ptr %t281, i64 %t277
  %t283 = call i64 @__olang_fmt_i64(ptr %t282, i64 %t275)
  %t284 = insertvalue { i64, ptr } undef, i64 %t280, 0
  %t285 = insertvalue { i64, ptr } %t284, ptr %t281, 1
  store { i64, ptr } %t285, ptr %l27, !tbaa !27
  br label %bb66
bb46:
  %t287 = load { i64, [2 x i64] }, ptr %l4
  %t289 = extractvalue { i64, [2 x i64] } %t287, 0
  %t290 = icmp eq i64 %t289, 8
  br i1 %t290, label %bb47, label %bb48
bb47:
  %t292 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t293 = getelementptr { i32, i32, i64 }, ptr %t292, i32 0, i32 0
  %t294 = load i32, ptr %t293
  store i32 %t294, ptr %l11, !tbaa !23
  %t296 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t297 = getelementptr { i32, i32, i64 }, ptr %t296, i32 0, i32 1
  %t298 = load i32, ptr %t297, !range !{i32 0, i32 1}
  store i32 %t298, ptr %l12
  %t300 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t301 = getelementptr { i32, i32, i64 }, ptr %t300, i32 0, i32 2
  %t302 = load i64, ptr %t301
  store i64 %t302, ptr %l13, !tbaa !24
  br label %bb49
bb48:
  br label %bb53
bb49:
  store %olang.scope zeroinitializer, ptr %s17
  %t304 = load ptr, ptr %l0, !tbaa !29
  %t305 = load i32, ptr %l11, !tbaa !23
  %t307 = sext i32 %t305 to i64
  %t310 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ebodySym(ptr %v0, ptr %s17, ptr %t304, i64 %t307)
  store { i64, ptr } %t310, ptr %l109
  br label %bb50
bb50:
  %t311 = load i32, ptr %l12, !range !{i32 0, i32 1}
  store i32 %t311, ptr %l110
  %t312 = load i64, ptr %l13, !tbaa !24
  store i64 %t312, ptr %l111, !tbaa !24
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s18
  store ptr %s18room, ptr %s18
  %t313 = load { i64, ptr }, ptr %l109, !tbaa !27
  %t314 = extractvalue { i64, ptr } %t313, 1
  %t315 = extractvalue { i64, ptr } %t313, 0
  call void @__olang_sb_put(ptr %s18, ptr %t314, i64 %t315)
  %t316 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d10, i32 0, i32 1) }, 1
  %t317 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d10, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s18, ptr %t316, i64 %t317)
  call void @olang_2emir_2eHelperKind_2eRender_2ecompiler_2ftyped_3aContractKind(ptr %s18, ptr %l110, i64 0)
  br label %bb51
bb51:
  %t319 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d11, i32 0, i32 1) }, 1
  %t320 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d11, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s18, ptr %t319, i64 %t320)
  %t321 = load i64, ptr %l111, !tbaa !24
  %t322 = call ptr @__olang_sb_room(ptr %s18, i64 24)
  %t323 = call i64 @__olang_fmt_i64(ptr %t322, i64 %t321)
  call void @__olang_sb_add(ptr %s18, i64 %t323)
  %t324 = load ptr, ptr %s18
  %t325 = getelementptr %olang.builder, ptr %s18, i32 0, i32 1
  %t326 = load i64, ptr %t325
  %t327 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t326)
  call void @olang_textcopy(ptr %t327, ptr %t324, i64 %t326)
  %t328 = insertvalue { i64, ptr } undef, i64 %t326, 0
  %t329 = insertvalue { i64, ptr } %t328, ptr %t327, 1
  store { i64, ptr } %t329, ptr %l113, !tbaa !27
  %t330 = getelementptr %olang.builder, ptr %s18, i32 0, i32 3
  %t331 = load ptr, ptr %t330
  %t332 = icmp ne ptr %t331, null
  br i1 %t332, label %sbgrew.333, label %sbdone.334
sbgrew.333:
  call void @__olang_sb_done(ptr %s18)
  br label %sbdone.334
sbdone.334:
  %t335 = load { i64, ptr }, ptr %l113, !tbaa !27
  %t336 = extractvalue { i64, ptr } %t335, 0
  %t337 = extractvalue { i64, ptr } %t335, 1
  %t338 = mul i64 %t336, 1
  %t339 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t338)
  call void @llvm.memcpy.p0.p0.i64(ptr %t339, ptr %t337, i64 %t338, i1 false)
  %t340 = insertvalue { i64, ptr } undef, i64 %t336, 0
  %t341 = insertvalue { i64, ptr } %t340, ptr %t339, 1
  %t343 = call { i64, ptr } @compiler_2ftypes_2eSymbol(ptr %v1, ptr %v1, { i64, ptr } %t341)
  store { i64, ptr } %t343, ptr %l115
  br label %bb52
bb52:
  %t344 = load { i64, ptr }, ptr %l115, !tbaa !27
  store { i64, ptr } %t344, ptr %l27, !tbaa !27
  call void @__olang_scope_close(ptr %s17)
  br label %bb66
bb53:
  %t345 = load { i64, [2 x i64] }, ptr %l4
  %t347 = extractvalue { i64, [2 x i64] } %t345, 0
  %t348 = icmp eq i64 %t347, 9
  br i1 %t348, label %bb54, label %bb55
bb54:
  %t350 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t351 = getelementptr { i64, i64 }, ptr %t350, i32 0, i32 0
  %t352 = load i64, ptr %t351
  store i64 %t352, ptr %l14, !tbaa !24
  %t354 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t355 = getelementptr { i64, i64 }, ptr %t354, i32 0, i32 1
  %t356 = load i64, ptr %t355
  store i64 %t356, ptr %l15, !tbaa !24
  br label %bb56
bb55:
  br label %bb59
bb56:
  store %olang.scope zeroinitializer, ptr %s19
  %t358 = load ptr, ptr %l0, !tbaa !29
  %t359 = load i64, ptr %l14, !tbaa !24
  %t362 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etableName(ptr %v0, ptr %s19, ptr %t358, i64 %t359)
  store { i64, ptr } %t362, ptr %l122
  br label %bb57
bb57:
  %t363 = load i64, ptr %l15, !tbaa !24
  %t364 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d12, i32 0, i32 1) }, 1
  %t365 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d12, i32 0, i32 1) }, 0
  %t366 = load { i64, ptr }, ptr %l122, !tbaa !27
  %t367 = extractvalue { i64, ptr } %t366, 1
  %t368 = extractvalue { i64, ptr } %t366, 0
  %t369 = add i64 %t365, %t368
  %t370 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d13, i32 0, i32 1) }, 1
  %t371 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d13, i32 0, i32 1) }, 0
  %t372 = add i64 %t369, %t371
  %t374 = call i64 @__olang_fmt_i64(ptr null, i64 %t363)
  %t375 = add i64 %t372, %t374
  %t376 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t375)
  call void @olang_textcopy(ptr %t376, ptr %t364, i64 %t365)
  %t377 = getelementptr i8, ptr %t376, i64 %t365
  call void @olang_textcopy(ptr %t377, ptr %t367, i64 %t368)
  %t378 = getelementptr i8, ptr %t377, i64 %t368
  call void @olang_textcopy(ptr %t378, ptr %t370, i64 %t371)
  %t379 = getelementptr i8, ptr %t378, i64 %t371
  %t380 = call i64 @__olang_fmt_i64(ptr %t379, i64 %t363)
  %t381 = insertvalue { i64, ptr } undef, i64 %t375, 0
  %t382 = insertvalue { i64, ptr } %t381, ptr %t376, 1
  %t384 = extractvalue { i64, ptr } %t382, 0
  %t385 = extractvalue { i64, ptr } %t382, 1
  %t386 = mul i64 %t384, 1
  %t387 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t386)
  call void @llvm.memcpy.p0.p0.i64(ptr %t387, ptr %t385, i64 %t386, i1 false)
  %t388 = insertvalue { i64, ptr } undef, i64 %t384, 0
  %t389 = insertvalue { i64, ptr } %t388, ptr %t387, 1
  %t391 = call { i64, ptr } @compiler_2ftypes_2eSymbol(ptr %v1, ptr %v1, { i64, ptr } %t389)
  store { i64, ptr } %t391, ptr %l126
  br label %bb58
bb58:
  %t392 = load { i64, ptr }, ptr %l126, !tbaa !27
  store { i64, ptr } %t392, ptr %l27, !tbaa !27
  call void @__olang_scope_close(ptr %s19)
  br label %bb66
bb59:
  %t393 = load { i64, [2 x i64] }, ptr %l4
  %t395 = extractvalue { i64, [2 x i64] } %t393, 0
  %t396 = icmp eq i64 %t395, 10
  br i1 %t396, label %bb60, label %bb61
bb60:
  %t398 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t399 = getelementptr { i32, i64 }, ptr %t398, i32 0, i32 0
  %t400 = load i32, ptr %t399
  store i32 %t400, ptr %l16, !tbaa !23
  %t402 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t403 = getelementptr { i32, i64 }, ptr %t402, i32 0, i32 1
  %t404 = load i64, ptr %t403
  store i64 %t404, ptr %l17, !tbaa !24
  br label %bb62
bb61:
  br label %bb65
bb62:
  store %olang.scope zeroinitializer, ptr %s21
  %t406 = load ptr, ptr %l0, !tbaa !29
  %t407 = load i32, ptr %l16, !tbaa !23
  %t410 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecanonOf(ptr %v0, ptr %s21, ptr %t406, i32 %t407)
  store { i64, ptr } %t410, ptr %l133
  br label %bb63
bb63:
  %t411 = load i64, ptr %l17, !tbaa !24
  %t412 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d14, i32 0, i32 1) }, 1
  %t413 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d14, i32 0, i32 1) }, 0
  %t414 = load { i64, ptr }, ptr %l133, !tbaa !27
  %t415 = extractvalue { i64, ptr } %t414, 1
  %t416 = extractvalue { i64, ptr } %t414, 0
  %t417 = add i64 %t413, %t416
  %t418 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 1
  %t419 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 0
  %t420 = add i64 %t417, %t419
  %t422 = call i64 @__olang_fmt_i64(ptr null, i64 %t411)
  %t423 = add i64 %t420, %t422
  %t424 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t423)
  call void @olang_textcopy(ptr %t424, ptr %t412, i64 %t413)
  %t425 = getelementptr i8, ptr %t424, i64 %t413
  call void @olang_textcopy(ptr %t425, ptr %t415, i64 %t416)
  %t426 = getelementptr i8, ptr %t425, i64 %t416
  call void @olang_textcopy(ptr %t426, ptr %t418, i64 %t419)
  %t427 = getelementptr i8, ptr %t426, i64 %t419
  %t428 = call i64 @__olang_fmt_i64(ptr %t427, i64 %t411)
  %t429 = insertvalue { i64, ptr } undef, i64 %t423, 0
  %t430 = insertvalue { i64, ptr } %t429, ptr %t424, 1
  %t432 = extractvalue { i64, ptr } %t430, 0
  %t433 = extractvalue { i64, ptr } %t430, 1
  %t434 = mul i64 %t432, 1
  %t435 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t434)
  call void @llvm.memcpy.p0.p0.i64(ptr %t435, ptr %t433, i64 %t434, i1 false)
  %t436 = insertvalue { i64, ptr } undef, i64 %t432, 0
  %t437 = insertvalue { i64, ptr } %t436, ptr %t435, 1
  %t439 = call { i64, ptr } @compiler_2ftypes_2eSymbol(ptr %v1, ptr %v1, { i64, ptr } %t437)
  store { i64, ptr } %t439, ptr %l137
  br label %bb64
bb64:
  %t440 = load { i64, ptr }, ptr %l137, !tbaa !27
  store { i64, ptr } %t440, ptr %l27, !tbaa !27
  call void @__olang_scope_close(ptr %s21)
  br label %bb66
bb65:
  call void @__olang_check_failed(ptr @olang_loc_de1fe604fb5e87cf_ff4728625cff78d3)
  unreachable
bb66:
  %t441 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t441, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecParamList(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca %"std/prelude/text:StringBuilder"
  %l5 = alloca i1
  %l6 = alloca %"compiler/cabi:Regs"
  %l7 = alloca i32
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i32
  %l14 = alloca %"std/prelude/text:StringBuilder"
  %l15 = alloca %"compiler/cabi:Regs"
  %l18 = alloca i32
  %l22 = alloca i1
  %l26 = alloca i1
  %l30 = alloca i1
  %l31 = alloca i1
  %l38 = alloca %"compiler/cabi:Way"
  %l41 = alloca ptr
  %l44 = alloca { i64, ptr }
  %l47 = alloca i64
  %l52 = alloca ptr
  %l55 = alloca i32
  %l56 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %l69 = alloca ptr
  %l74 = alloca { i64, ptr }
  %l79 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t6, ptr %l14
  br label %bb1
bb1:
  %t7 = load %"std/prelude/text:StringBuilder", ptr %l14
  store %"std/prelude/text:StringBuilder" %t7, ptr %l4
  store i1 true, ptr %l5, !tbaa !21
  %t8 = call %"compiler/cabi:Regs" @compiler_2fcabi_3aRegs_2ector(ptr %s0, i64 6, i64 8)
  store %"compiler/cabi:Regs" %t8, ptr %l15
  br label %bb2
bb2:
  %t9 = load %"compiler/cabi:Regs", ptr %l15
  store %"compiler/cabi:Regs" %t9, ptr %l6
  %t10 = load ptr, ptr %l3, !tbaa !29
  %t11 = load i32, ptr %l1, !tbaa !23
  %t14 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t10, i32 %t11)
  store i32 %t14, ptr %l18
  br label %bb3
bb3:
  %t15 = load i32, ptr %l18, !tbaa !23
  store i32 %t15, ptr %l7, !tbaa !23
  %t16 = load i32, ptr %l7, !tbaa !23
  %t17 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t20 = icmp ne i32 %t16, %t17
  br i1 %t20, label %bb4, label %bb5
bb4:
  %t22 = load i32, ptr %l7, !tbaa !23
  %t23 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t26 = icmp ne i32 %t22, %t23
  store i1 %t26, ptr %l22, !tbaa !21
  br label %bb6
bb5:
  store i1 false, ptr %l22, !tbaa !21
  br label %bb6
bb6:
  %t28 = load i1, ptr %l22, !tbaa !21
  br i1 %t28, label %bb7, label %bb8
bb7:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/emit:Emitter", ptr %t29, i32 0, i32 0
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t33 = load i32, ptr %l7, !tbaa !23
  %t36 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLayout(ptr %v0, ptr %t32, i32 %t33)
  store i1 %t36, ptr %l30
  br label %bb9
bb8:
  store i1 false, ptr %l26, !tbaa !21
  br label %bb10
bb9:
  %t37 = load i1, ptr %l30, !tbaa !21
  store i1 %t37, ptr %l26, !tbaa !21
  br label %bb10
bb10:
  %t38 = load i1, ptr %l26, !tbaa !21
  br i1 %t38, label %bb11, label %bb12
bb11:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/emit:Emitter", ptr %t39, i32 0, i32 3
  %t42 = load ptr, ptr %t41, !tbaa !29
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/emit:Emitter", ptr %t43, i32 0, i32 55
  %t46 = load { i64, ptr }, ptr %t45, !tbaa !27
  %t47 = load i32, ptr %l7, !tbaa !23
  %t49 = inttoptr i64 0 to ptr
  %t53 = call %"compiler/cabi:Way" @compiler_2fcabi_2eWay_2eResult(ptr %v0, ptr %v0, ptr %s0, ptr %t49, ptr %t42, { i64, ptr } %t46, i32 %t47)
  store %"compiler/cabi:Way" %t53, ptr %l38
  br label %bb13
bb12:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb14
bb13:
  %t54 = getelementptr %"compiler/cabi:Way", ptr %l38, i32 0, i32 0
  %t55 = load i32, ptr %t54, !range !{i32 0, i32 5}
  %t57 = trunc i64 4 to i32
  %t58 = icmp eq i32 %t55, %t57
  store i1 %t58, ptr %l31, !tbaa !21
  br label %bb14
bb14:
  %t60 = load i1, ptr %l31, !tbaa !21
  br i1 %t60, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s1
  store ptr %l4, ptr %l41, !tbaa !29
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = load i32, ptr %l7, !tbaa !23
  %t65 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %s1, ptr %t61, i32 %t62)
  store { i64, ptr } %t65, ptr %l44
  br label %bb17
bb16:
  br label %bb20
bb17:
  %t66 = load ptr, ptr %l3, !tbaa !29
  %t67 = load i32, ptr %l7, !tbaa !23
  %t70 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAlign(ptr %v0, ptr %t66, i32 %t67)
  store i64 %t70, ptr %l47
  br label %bb18
bb18:
  %t71 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d16, i32 0, i32 1) }, 1
  %t72 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d16, i32 0, i32 1) }, 0
  %t73 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t74 = extractvalue { i64, ptr } %t73, 1
  %t75 = extractvalue { i64, ptr } %t73, 0
  %t76 = add i64 %t72, %t75
  %t77 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d17, i32 0, i32 1) }, 1
  %t78 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d17, i32 0, i32 1) }, 0
  %t79 = add i64 %t76, %t78
  %t80 = load i64, ptr %l47, !tbaa !24
  %t81 = call i64 @__olang_fmt_i64(ptr null, i64 %t80)
  %t82 = add i64 %t79, %t81
  %t83 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t82)
  call void @olang_textcopy(ptr %t83, ptr %t71, i64 %t72)
  %t84 = getelementptr i8, ptr %t83, i64 %t72
  call void @olang_textcopy(ptr %t84, ptr %t74, i64 %t75)
  %t85 = getelementptr i8, ptr %t84, i64 %t75
  call void @olang_textcopy(ptr %t85, ptr %t77, i64 %t78)
  %t86 = getelementptr i8, ptr %t85, i64 %t78
  %t87 = call i64 @__olang_fmt_i64(ptr %t86, i64 %t80)
  %t88 = insertvalue { i64, ptr } undef, i64 %t82, 0
  %t89 = insertvalue { i64, ptr } %t88, ptr %t83, 1
  %t91 = extractvalue { i64, ptr } %t89, 0
  %t92 = extractvalue { i64, ptr } %t89, 1
  %t93 = mul i64 %t91, 1
  %t94 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t93)
  call void @llvm.memcpy.p0.p0.i64(ptr %t94, ptr %t92, i64 %t93, i1 false)
  %t95 = insertvalue { i64, ptr } undef, i64 %t91, 0
  %t96 = insertvalue { i64, ptr } %t95, ptr %t94, 1
  %t97 = load ptr, ptr %l41, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s1, ptr %t97, { i64, ptr } %t96)
  br label %bb19
bb19:
  store i1 false, ptr %l5, !tbaa !21
  %t99 = getelementptr %"compiler/cabi:Regs", ptr %l6, i32 0, i32 0
  %t100 = load i64, ptr %t99, !tbaa !24
  %t102 = sub i64 %t100, 1
  %t104 = getelementptr %"compiler/cabi:Regs", ptr %l6, i32 0, i32 0
  store i64 %t102, ptr %t104, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb20
bb20:
  %t105 = load ptr, ptr %l3, !tbaa !29
  store ptr %t105, ptr %l52, !tbaa !29
  %t106 = load ptr, ptr %l3, !tbaa !29
  %t107 = load i32, ptr %l1, !tbaa !23
  %t110 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t106, i32 %t107)
  store i32 %t110, ptr %l55
  br label %bb21
bb21:
  %t111 = load ptr, ptr %l52, !tbaa !29
  %t112 = load i32, ptr %l55, !tbaa !23
  %t113 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t111, i32 %t112)
  store { i64, ptr } %t113, ptr %l56
  br label %bb22
bb22:
  %t114 = load { i64, ptr }, ptr %l56, !tbaa !27
  store { i64, ptr } %t114, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t115 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t117 = extractvalue { i64, ptr } %t115, 0
  store i64 %t117, ptr %l10, !tbaa !24
  br label %bb23
bb23:
  store %olang.scope zeroinitializer, ptr %s4
  %t119 = load i64, ptr %l9, !tbaa !24
  %t120 = load i64, ptr %l10, !tbaa !24
  %t123 = icmp slt i64 %t119, %t120
  %t125 = xor i1 %t123, true
  br i1 %t125, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s4)
  br label %bb34
bb25:
  br label %bb26
bb26:
  %t127 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t127, ptr %l63, !tbaa !27
  %t128 = load i64, ptr %l9, !tbaa !24
  %t130 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !27
  %t132 = getelementptr i32, ptr %t131, i64 %t128
  %t133 = load i32, ptr %t132, !tbaa !33
  store i32 %t133, ptr %l11, !tbaa !23
  %t135 = load i1, ptr %l5, !tbaa !21
  %t137 = xor i1 %t135, true
  br i1 %t137, label %bb27, label %bb28
bb27:
  store %olang.scope zeroinitializer, ptr %s5
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s5, ptr %l4, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d18, i32 0, i32 1) })
  br label %bb29
bb28:
  br label %bb30
bb29:
  call void @__olang_scope_close(ptr %s5)
  br label %bb30
bb30:
  store i1 false, ptr %l5, !tbaa !21
  store ptr %l4, ptr %l69, !tbaa !29
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t141 = load i32, ptr %l11, !tbaa !23
  %t147 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecParamSpelled(ptr %v0, ptr %s0, ptr %s4, ptr %t140, i32 %t141, ptr %l6, i1 %a2)
  store { i64, ptr } %t147, ptr %l74
  br label %bb31
bb31:
  %t148 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t149 = extractvalue { i64, ptr } %t148, 0
  %t150 = extractvalue { i64, ptr } %t148, 1
  %t151 = mul i64 %t149, 1
  %t152 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t151)
  call void @llvm.memcpy.p0.p0.i64(ptr %t152, ptr %t150, i64 %t151, i1 false)
  %t153 = insertvalue { i64, ptr } undef, i64 %t149, 0
  %t154 = insertvalue { i64, ptr } %t153, ptr %t152, 1
  %t155 = load ptr, ptr %l69, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s4, ptr %t155, { i64, ptr } %t154)
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s4)
  br label %bb33
bb33:
  %t157 = load i64, ptr %l9, !tbaa !24
  %t159 = add i64 %t157, 1
  store i64 %t159, ptr %l9, !tbaa !24
  br label %bb23
bb34:
  %t162 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l4)
  store { i64, ptr } %t162, ptr %l79
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s0)
  %t163 = load { i64, ptr }, ptr %l79, !tbaa !27
  store { i64, ptr } %t163, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecapVars(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [2 x i64] }
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca { i64, [1 x i64] }
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca { i64, ptr }
  %l19 = alloca ptr
  %l22 = alloca i64
  %l24 = alloca i64
  %l29 = alloca { i64, [1 x i64] }
  %l41 = alloca ptr
  %l43 = alloca ptr
  %l50 = alloca ptr
  %l53 = alloca i32
  %l54 = alloca { i64, ptr }
  %l58 = alloca i1
  %l61 = alloca { i64, ptr }
  %l63 = alloca i1
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store { i64, [2 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load { i64, [2 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [2 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { i32 }, ptr %t6, i32 0, i32 0
  %t8 = load i32, ptr %t7
  store i32 %t8, ptr %l3, !tbaa !23
  br label %bb3
bb2:
  br label %bb16
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/emit:Emitter", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = getelementptr %"compiler/lower:Lowerer", ptr %t13, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t18 = load i32, ptr %l3, !tbaa !23
  %t20 = sext i32 %t18 to i64
  %t23 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t16, i64 %t20)
  store ptr %t23, ptr %l19
  br label %bb4
bb4:
  %t24 = load ptr, ptr %l19, !tbaa !29
  %t26 = getelementptr %"compiler/typed:Body", ptr %t24, i32 0, i32 6
  store ptr %t26, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb5
bb5:
  %t28 = load i64, ptr %l5, !tbaa !24
  store i64 %t28, ptr %l22, !tbaa !24
  %t29 = load ptr, ptr %l4, !tbaa !29
  %t31 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2eLen_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0, ptr %t29)
  store i64 %t31, ptr %l24
  br label %bb6
bb6:
  %t32 = load i64, ptr %l22, !tbaa !24
  %t33 = load i64, ptr %l24, !tbaa !24
  %t34 = icmp slt i64 %t32, %t33
  %t36 = xor i1 %t34, true
  br i1 %t36, label %bb7, label %bb8
bb7:
  br label %bb15
bb8:
  br label %bb9
bb9:
  %t38 = load ptr, ptr %l4, !tbaa !29
  %t39 = load i64, ptr %l5, !tbaa !24
  %t42 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2eAt_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0, ptr %t38, i64 %t39)
  store { i64, [1 x i64] } %t42, ptr %l29
  br label %bb10
bb10:
  %t43 = load { i64, [1 x i64] }, ptr %l29
  store { i64, [1 x i64] } %t43, ptr %l6
  %t44 = load { i64, [1 x i64] }, ptr %l6
  %t46 = extractvalue { i64, [1 x i64] } %t44, 0
  %t47 = icmp eq i64 %t46, 4
  br i1 %t47, label %bb11, label %bb12
bb11:
  %t49 = getelementptr { i64, [1 x i64] }, ptr %l6, i32 0, i32 1
  %t50 = getelementptr { i32 }, ptr %t49, i32 0, i32 0
  %t51 = load i32, ptr %t50
  store i32 %t51, ptr %l7, !tbaa !23
  %t53 = load i64, ptr %l2, !tbaa !24
  %t55 = add i64 %t53, 1
  store i64 %t55, ptr %l2, !tbaa !24
  br label %bb13
bb12:
  br label %bb13
bb13:
  br label %bb14
bb14:
  %t57 = load i64, ptr %l5, !tbaa !24
  %t59 = add i64 %t57, 1
  store i64 %t59, ptr %l5, !tbaa !24
  br label %bb5
bb15:
  br label %bb35
bb16:
  %t61 = load { i64, [2 x i64] }, ptr %l1
  %t63 = extractvalue { i64, [2 x i64] } %t61, 0
  %t64 = icmp eq i64 %t63, 1
  br i1 %t64, label %bb17, label %bb18
bb17:
  %t66 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t67 = getelementptr { i32 }, ptr %t66, i32 0, i32 0
  %t68 = load i32, ptr %t67
  store i32 %t68, ptr %l8, !tbaa !23
  br label %bb19
bb18:
  br label %bb30
bb19:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/emit:Emitter", ptr %t70, i32 0, i32 3
  %t73 = load ptr, ptr %t72, !tbaa !29
  store ptr %t73, ptr %l41, !tbaa !29
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/emit:Emitter", ptr %t74, i32 0, i32 3
  %t77 = load ptr, ptr %t76, !tbaa !29
  store ptr %t77, ptr %l43, !tbaa !29
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/emit:Emitter", ptr %t78, i32 0, i32 1
  %t81 = load ptr, ptr %t80, !tbaa !29
  %t83 = getelementptr %"compiler/lower:Lowerer", ptr %t81, i32 0, i32 1
  %t84 = load ptr, ptr %t83, !tbaa !29
  %t86 = load i32, ptr %l8, !tbaa !23
  %t88 = sext i32 %t86 to i64
  %t91 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t84, i64 %t88)
  store ptr %t91, ptr %l50
  br label %bb20
bb20:
  %t92 = load ptr, ptr %l50, !tbaa !29
  %t94 = getelementptr %"compiler/typed:Body", ptr %t92, i32 0, i32 2
  %t95 = load i32, ptr %t94, !tbaa !23
  %t96 = load ptr, ptr %l43, !tbaa !29
  %t98 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t96, i32 %t95)
  store i32 %t98, ptr %l53
  br label %bb21
bb21:
  %t99 = load ptr, ptr %l41, !tbaa !29
  %t100 = load i32, ptr %l53, !tbaa !23
  %t101 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t99, i32 %t100)
  store { i64, ptr } %t101, ptr %l54
  br label %bb22
bb22:
  %t102 = load { i64, ptr }, ptr %l54, !tbaa !27
  store { i64, ptr } %t102, ptr %l9, !tbaa !27
  %t103 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t105 = extractvalue { i64, ptr } %t103, 0
  %t107 = icmp sgt i64 %t105, 0
  br i1 %t107, label %bb23, label %bb24
bb23:
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = getelementptr %"compiler/emit:Emitter", ptr %t109, i32 0, i32 3
  %t112 = load ptr, ptr %t111, !tbaa !29
  %t113 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t113, ptr %l61, !tbaa !27
  %t114 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !27
  %t116 = getelementptr i32, ptr %t115, i64 0
  %t117 = load i32, ptr %t116, !tbaa !33
  %t120 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %t112, i32 %t117)
  store i1 %t120, ptr %l63
  br label %bb25
bb24:
  store i1 false, ptr %l58, !tbaa !21
  br label %bb26
bb25:
  %t121 = load i1, ptr %l63, !tbaa !21
  store i1 %t121, ptr %l58, !tbaa !21
  br label %bb26
bb26:
  %t122 = load i1, ptr %l58, !tbaa !21
  br i1 %t122, label %bb27, label %bb28
bb27:
  store i64 1, ptr %l2, !tbaa !24
  br label %bb29
bb28:
  br label %bb29
bb29:
  br label %bb35
bb30:
  br i1 true, label %bb31, label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb35
bb34:
  call void @__olang_check_failed(ptr @olang_loc_9506350913203bfc_41d6488afcc367c0)
  unreachable
bb35:
  %t123 = load i64, ptr %l2, !tbaa !24
  store i64 %t123, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecarriesText(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, { i64, ptr } %a2, i32 %a3, { i64, ptr } %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %lp7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l18 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca { i64, ptr }
  %l28 = alloca i64
  %l31 = alloca i64
  %l50 = alloca ptr
  %l52 = alloca { i64, ptr }
  %l55 = alloca i32
  %l56 = alloca i32
  %l60 = alloca i1
  %l75 = alloca i1
  %l78 = alloca { i64, ptr }
  %l80 = alloca i64
  %l92 = alloca { i64, ptr }
  %l94 = alloca i64
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, ptr } %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l5, !tbaa !29
  %t6 = load ptr, ptr %l5, !tbaa !29
  %t10 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t6, i32 %a3)
  store { i64, ptr } %t10, ptr %l18
  br label %bb1
bb1:
  %t11 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t11, ptr %l6, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d19, i32 0, i32 1) }, ptr %l19, !tbaa !27
  %t12 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t12, ptr %l20, !tbaa !27
  %t13 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t13, 0
  store i64 %t14, ptr %l21, !tbaa !24
  %t15 = load i64, ptr %l21, !tbaa !24
  %t16 = mul i64 %t15, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t16)
  %t18 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l22, !tbaa !27
  %t20 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = load i64, ptr %l21, !tbaa !24
  %t25 = mul i64 %t24, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t21, ptr %t23, i64 %t25, i1 false)
  %t26 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 16, i64 8)
  store ptr %t26, ptr %lp7
  %t27 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t28 = load ptr, ptr %lp7
  store { i64, ptr } %t27, ptr %t28, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t29 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t31 = extractvalue { i64, ptr } %t29, 0
  store i64 %t31, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t33 = load i64, ptr %l9, !tbaa !24
  %t34 = load i64, ptr %l8, !tbaa !24
  %t37 = icmp sgt i64 %t33, %t34
  br i1 %t37, label %bb2, label %bb3
bb2:
  %t39 = load i64, ptr %l10, !tbaa !24
  %t41 = icmp sgt i64 %t39, 0
  br i1 %t41, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb7
bb4:
  %t43 = load i64, ptr %l9, !tbaa !24
  %t44 = load i64, ptr %l8, !tbaa !24
  %t47 = sub i64 %t43, %t44
  %t48 = load i64, ptr %l10, !tbaa !24
  %t51 = add i64 %t47, %t48
  %t53 = sub i64 %t51, 1
  %t54 = load i64, ptr %l10, !tbaa !24
  %t57 = sdiv i64 %t53, %t54
  store i64 %t57, ptr %l31, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb6
bb6:
  %t59 = load i64, ptr %l31, !tbaa !24
  store i64 %t59, ptr %l28, !tbaa !24
  br label %bb7
bb7:
  %t60 = load i64, ptr %l28, !tbaa !24
  store i64 %t60, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t61 = load i64, ptr %l12, !tbaa !24
  %t62 = load i64, ptr %l11, !tbaa !24
  %t65 = icmp slt i64 %t61, %t62
  %t67 = xor i1 %t65, true
  br i1 %t67, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb35
bb10:
  br label %bb11
bb11:
  %t69 = load i64, ptr %l8, !tbaa !24
  %t70 = load i64, ptr %l12, !tbaa !24
  %t71 = load i64, ptr %l10, !tbaa !24
  %t74 = mul i64 %t70, %t71
  %t77 = add i64 %t69, %t74
  store i64 %t77, ptr %l13, !tbaa !24
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/emit:Emitter", ptr %t79, i32 0, i32 0
  %t82 = load ptr, ptr %t81, !tbaa !29
  store ptr %t82, ptr %l50, !tbaa !29
  %t83 = load ptr, ptr %l5, !tbaa !29
  %t84 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t84, ptr %l52, !tbaa !27
  %t85 = load i64, ptr %l13, !tbaa !24
  %t87 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !27
  %t89 = getelementptr i32, ptr %t88, i64 %t85
  %t90 = load i32, ptr %t89, !tbaa !33
  %t93 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t83, i32 %t90)
  store i32 %t93, ptr %l55
  br label %bb12
bb12:
  %t94 = load ptr, ptr %l50, !tbaa !29
  %t95 = load i32, ptr %l55, !tbaa !23
  %t96 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePayloadOf(ptr %v0, ptr %t94, i32 %t95)
  store i32 %t96, ptr %l56
  br label %bb13
bb13:
  %t97 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t98 = load i32, ptr %l56, !tbaa !23
  %t100 = icmp eq i32 %t98, %t97
  br i1 %t100, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s2)
  br label %bb34
bb15:
  br label %bb16
bb16:
  %t102 = load ptr, ptr %lp7
  %t103 = load { i64, ptr }, ptr %t102, !tbaa !27
  %t105 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v4, ptr %s2, { i64, ptr } %t103, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d20, i32 0, i32 1) })
  store i1 %t105, ptr %l60
  br label %bb17
bb17:
  %t106 = load i1, ptr %l60, !tbaa !21
  br i1 %t106, label %bb18, label %bb19
bb18:
  store %olang.scope zeroinitializer, ptr %s4
  %t107 = load ptr, ptr %l1, !tbaa !29
  %t108 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t110 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d21, i32 0, i32 1) }, 1
  %t111 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d21, i32 0, i32 1) }, 0
  %t113 = extractvalue { i64, ptr } %t108, 1
  %t114 = extractvalue { i64, ptr } %t108, 0
  %t115 = add i64 %t111, %t114
  %t116 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d22, i32 0, i32 1) }, 1
  %t117 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d22, i32 0, i32 1) }, 0
  %t118 = add i64 %t115, %t117
  %t120 = extractvalue { i64, ptr } %a2, 1
  %t121 = extractvalue { i64, ptr } %a2, 0
  %t122 = add i64 %t118, %t121
  %t123 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d23, i32 0, i32 1) }, 1
  %t124 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d23, i32 0, i32 1) }, 0
  %t125 = add i64 %t122, %t124
  %t126 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t125)
  call void @olang_textcopy(ptr %t126, ptr %t110, i64 %t111)
  %t127 = getelementptr i8, ptr %t126, i64 %t111
  call void @olang_textcopy(ptr %t127, ptr %t113, i64 %t114)
  %t128 = getelementptr i8, ptr %t127, i64 %t114
  call void @olang_textcopy(ptr %t128, ptr %t116, i64 %t117)
  %t129 = getelementptr i8, ptr %t128, i64 %t117
  call void @olang_textcopy(ptr %t129, ptr %t120, i64 %t121)
  %t130 = getelementptr i8, ptr %t129, i64 %t121
  call void @olang_textcopy(ptr %t130, ptr %t123, i64 %t124)
  %t131 = insertvalue { i64, ptr } undef, i64 %t125, 0
  %t132 = insertvalue { i64, ptr } %t131, ptr %t126, 1
  %t134 = extractvalue { i64, ptr } %t132, 0
  %t135 = extractvalue { i64, ptr } %t132, 1
  %t136 = mul i64 %t134, 1
  %t137 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t136)
  call void @llvm.memcpy.p0.p0.i64(ptr %t137, ptr %t135, i64 %t136, i1 false)
  %t138 = insertvalue { i64, ptr } undef, i64 %t134, 0
  %t139 = insertvalue { i64, ptr } %t138, ptr %t137, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s4, ptr %t107, { i64, ptr } %t139)
  br label %bb20
bb19:
  br label %bb21
bb20:
  call void @__olang_scope_close(ptr %s4)
  br label %bb21
bb21:
  %t142 = load ptr, ptr %l1, !tbaa !29
  %t143 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t144 = load i64, ptr %l13, !tbaa !24
  %t145 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t146 = load i64, ptr %l13, !tbaa !24
  %t148 = add i64 %t146, 1
  %t149 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d24, i32 0, i32 1) }, 1
  %t150 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d24, i32 0, i32 1) }, 0
  %t152 = extractvalue { i64, ptr } %t143, 1
  %t153 = extractvalue { i64, ptr } %t143, 0
  %t154 = add i64 %t150, %t153
  %t155 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d25, i32 0, i32 1) }, 1
  %t156 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d25, i32 0, i32 1) }, 0
  %t157 = add i64 %t154, %t156
  %t159 = call i64 @__olang_fmt_i64(ptr null, i64 %t144)
  %t160 = add i64 %t157, %t159
  %t161 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d26, i32 0, i32 1) }, 1
  %t162 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d26, i32 0, i32 1) }, 0
  %t163 = add i64 %t160, %t162
  %t165 = extractvalue { i64, ptr } %t145, 1
  %t166 = extractvalue { i64, ptr } %t145, 0
  %t167 = add i64 %t163, %t166
  %t168 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d27, i32 0, i32 1) }, 1
  %t169 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d27, i32 0, i32 1) }, 0
  %t170 = add i64 %t167, %t169
  %t172 = call i64 @__olang_fmt_i64(ptr null, i64 %t148)
  %t173 = add i64 %t170, %t172
  %t174 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d28, i32 0, i32 1) }, 1
  %t175 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d28, i32 0, i32 1) }, 0
  %t176 = add i64 %t173, %t175
  %t177 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t176)
  call void @olang_textcopy(ptr %t177, ptr %t149, i64 %t150)
  %t178 = getelementptr i8, ptr %t177, i64 %t150
  call void @olang_textcopy(ptr %t178, ptr %t152, i64 %t153)
  %t179 = getelementptr i8, ptr %t178, i64 %t153
  call void @olang_textcopy(ptr %t179, ptr %t155, i64 %t156)
  %t180 = getelementptr i8, ptr %t179, i64 %t156
  %t181 = call i64 @__olang_fmt_i64(ptr %t180, i64 %t144)
  %t182 = getelementptr i8, ptr %t180, i64 %t159
  call void @olang_textcopy(ptr %t182, ptr %t161, i64 %t162)
  %t183 = getelementptr i8, ptr %t182, i64 %t162
  call void @olang_textcopy(ptr %t183, ptr %t165, i64 %t166)
  %t184 = getelementptr i8, ptr %t183, i64 %t166
  call void @olang_textcopy(ptr %t184, ptr %t168, i64 %t169)
  %t185 = getelementptr i8, ptr %t184, i64 %t169
  %t186 = call i64 @__olang_fmt_i64(ptr %t185, i64 %t148)
  %t187 = getelementptr i8, ptr %t185, i64 %t172
  call void @olang_textcopy(ptr %t187, ptr %t174, i64 %t175)
  %t188 = insertvalue { i64, ptr } undef, i64 %t176, 0
  %t189 = insertvalue { i64, ptr } %t188, ptr %t177, 1
  %t191 = extractvalue { i64, ptr } %t189, 0
  %t192 = extractvalue { i64, ptr } %t189, 1
  %t193 = mul i64 %t191, 1
  %t194 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t193)
  call void @llvm.memcpy.p0.p0.i64(ptr %t194, ptr %t192, i64 %t193, i1 false)
  %t195 = insertvalue { i64, ptr } undef, i64 %t191, 0
  %t196 = insertvalue { i64, ptr } %t195, ptr %t194, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s2, ptr %t142, { i64, ptr } %t196)
  br label %bb22
bb22:
  %t199 = load ptr, ptr %lp7
  %t200 = load { i64, ptr }, ptr %t199, !tbaa !27
  %t202 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v4, ptr %s2, { i64, ptr } %t200, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d29, i32 0, i32 1) })
  store i1 %t202, ptr %l75
  br label %bb23
bb23:
  %t203 = load i1, ptr %l75, !tbaa !21
  br i1 %t203, label %bb24, label %bb25
bb24:
  %t204 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t205 = load i64, ptr %l13, !tbaa !24
  %t206 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d30, i32 0, i32 1) }, 1
  %t207 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d30, i32 0, i32 1) }, 0
  %t209 = extractvalue { i64, ptr } %t204, 1
  %t210 = extractvalue { i64, ptr } %t204, 0
  %t211 = add i64 %t207, %t210
  %t212 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d31, i32 0, i32 1) }, 1
  %t213 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d31, i32 0, i32 1) }, 0
  %t214 = add i64 %t211, %t213
  %t216 = call i64 @__olang_fmt_i64(ptr null, i64 %t205)
  %t217 = add i64 %t214, %t216
  %t218 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t217)
  call void @olang_textcopy(ptr %t218, ptr %t206, i64 %t207)
  %t219 = getelementptr i8, ptr %t218, i64 %t207
  call void @olang_textcopy(ptr %t219, ptr %t209, i64 %t210)
  %t220 = getelementptr i8, ptr %t219, i64 %t210
  call void @olang_textcopy(ptr %t220, ptr %t212, i64 %t213)
  %t221 = getelementptr i8, ptr %t220, i64 %t213
  %t222 = call i64 @__olang_fmt_i64(ptr %t221, i64 %t205)
  %t223 = insertvalue { i64, ptr } undef, i64 %t217, 0
  %t224 = insertvalue { i64, ptr } %t223, ptr %t218, 1
  store { i64, ptr } %t224, ptr %l78, !tbaa !27
  %t225 = load ptr, ptr %lp7
  %t226 = load { i64, ptr }, ptr %t225, !tbaa !27
  %t227 = extractvalue { i64, ptr } %t226, 0
  %t228 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t229 = extractvalue { i64, ptr } %t228, 0
  store i64 %t229, ptr %l80, !tbaa !24
  %t231 = load i64, ptr %l80, !tbaa !24
  %t232 = icmp eq i64 %t227, %t231
  br i1 %t232, label %bb26, label %bb27
bb25:
  store %olang.scope zeroinitializer, ptr %s9
  %t234 = load ptr, ptr %l1, !tbaa !29
  %t235 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t236 = load i64, ptr %l13, !tbaa !24
  %t237 = load ptr, ptr %lp7
  %t238 = load { i64, ptr }, ptr %t237, !tbaa !27
  %t239 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t240 = load i64, ptr %l13, !tbaa !24
  %t241 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d32, i32 0, i32 1) }, 1
  %t242 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d32, i32 0, i32 1) }, 0
  %t244 = extractvalue { i64, ptr } %t235, 1
  %t245 = extractvalue { i64, ptr } %t235, 0
  %t246 = add i64 %t242, %t245
  %t247 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d33, i32 0, i32 1) }, 1
  %t248 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d33, i32 0, i32 1) }, 0
  %t249 = add i64 %t246, %t248
  %t251 = call i64 @__olang_fmt_i64(ptr null, i64 %t236)
  %t252 = add i64 %t249, %t251
  %t253 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d34, i32 0, i32 1) }, 1
  %t254 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d34, i32 0, i32 1) }, 0
  %t255 = add i64 %t252, %t254
  %t257 = extractvalue { i64, ptr } %t238, 1
  %t258 = extractvalue { i64, ptr } %t238, 0
  %t259 = add i64 %t255, %t258
  %t260 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d35, i32 0, i32 1) }, 1
  %t261 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d35, i32 0, i32 1) }, 0
  %t262 = add i64 %t259, %t261
  %t264 = extractvalue { i64, ptr } %t239, 1
  %t265 = extractvalue { i64, ptr } %t239, 0
  %t266 = add i64 %t262, %t265
  %t267 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d36, i32 0, i32 1) }, 1
  %t268 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d36, i32 0, i32 1) }, 0
  %t269 = add i64 %t266, %t268
  %t271 = call i64 @__olang_fmt_i64(ptr null, i64 %t240)
  %t272 = add i64 %t269, %t271
  %t273 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d37, i32 0, i32 1) }, 1
  %t274 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d37, i32 0, i32 1) }, 0
  %t275 = add i64 %t272, %t274
  %t276 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t275)
  call void @olang_textcopy(ptr %t276, ptr %t241, i64 %t242)
  %t277 = getelementptr i8, ptr %t276, i64 %t242
  call void @olang_textcopy(ptr %t277, ptr %t244, i64 %t245)
  %t278 = getelementptr i8, ptr %t277, i64 %t245
  call void @olang_textcopy(ptr %t278, ptr %t247, i64 %t248)
  %t279 = getelementptr i8, ptr %t278, i64 %t248
  %t280 = call i64 @__olang_fmt_i64(ptr %t279, i64 %t236)
  %t281 = getelementptr i8, ptr %t279, i64 %t251
  call void @olang_textcopy(ptr %t281, ptr %t253, i64 %t254)
  %t282 = getelementptr i8, ptr %t281, i64 %t254
  call void @olang_textcopy(ptr %t282, ptr %t257, i64 %t258)
  %t283 = getelementptr i8, ptr %t282, i64 %t258
  call void @olang_textcopy(ptr %t283, ptr %t260, i64 %t261)
  %t284 = getelementptr i8, ptr %t283, i64 %t261
  call void @olang_textcopy(ptr %t284, ptr %t264, i64 %t265)
  %t285 = getelementptr i8, ptr %t284, i64 %t265
  call void @olang_textcopy(ptr %t285, ptr %t267, i64 %t268)
  %t286 = getelementptr i8, ptr %t285, i64 %t268
  %t287 = call i64 @__olang_fmt_i64(ptr %t286, i64 %t240)
  %t288 = getelementptr i8, ptr %t286, i64 %t271
  call void @olang_textcopy(ptr %t288, ptr %t273, i64 %t274)
  %t289 = insertvalue { i64, ptr } undef, i64 %t275, 0
  %t290 = insertvalue { i64, ptr } %t289, ptr %t276, 1
  %t292 = extractvalue { i64, ptr } %t290, 0
  %t293 = extractvalue { i64, ptr } %t290, 1
  %t294 = mul i64 %t292, 1
  %t295 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t294)
  call void @llvm.memcpy.p0.p0.i64(ptr %t295, ptr %t293, i64 %t294, i1 false)
  %t296 = insertvalue { i64, ptr } undef, i64 %t292, 0
  %t297 = insertvalue { i64, ptr } %t296, ptr %t295, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s9, ptr %t234, { i64, ptr } %t297)
  br label %bb29
bb26:
  %t300 = load ptr, ptr %lp7
  %t301 = getelementptr { i64, ptr }, ptr %t300, i32 0, i32 1
  %t302 = load ptr, ptr %t301, !tbaa !27
  %t303 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t304 = load ptr, ptr %t303, !tbaa !27
  %t305 = load i64, ptr %l80, !tbaa !24
  %t306 = mul i64 %t305, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t302, ptr %t304, i64 %t306, i1 false)
  br label %bb28
bb27:
  %t307 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t308 = load ptr, ptr %lp7
  store { i64, ptr } %t307, ptr %t308, !tbaa !27
  br label %bb28
bb28:
  br label %bb33
bb29:
  %t309 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t310 = load i64, ptr %l13, !tbaa !24
  %t311 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d38, i32 0, i32 1) }, 1
  %t312 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d38, i32 0, i32 1) }, 0
  %t314 = extractvalue { i64, ptr } %t309, 1
  %t315 = extractvalue { i64, ptr } %t309, 0
  %t316 = add i64 %t312, %t315
  %t317 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d39, i32 0, i32 1) }, 1
  %t318 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d39, i32 0, i32 1) }, 0
  %t319 = add i64 %t316, %t318
  %t321 = call i64 @__olang_fmt_i64(ptr null, i64 %t310)
  %t322 = add i64 %t319, %t321
  %t323 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t322)
  call void @olang_textcopy(ptr %t323, ptr %t311, i64 %t312)
  %t324 = getelementptr i8, ptr %t323, i64 %t312
  call void @olang_textcopy(ptr %t324, ptr %t314, i64 %t315)
  %t325 = getelementptr i8, ptr %t324, i64 %t315
  call void @olang_textcopy(ptr %t325, ptr %t317, i64 %t318)
  %t326 = getelementptr i8, ptr %t325, i64 %t318
  %t327 = call i64 @__olang_fmt_i64(ptr %t326, i64 %t310)
  %t328 = insertvalue { i64, ptr } undef, i64 %t322, 0
  %t329 = insertvalue { i64, ptr } %t328, ptr %t323, 1
  store { i64, ptr } %t329, ptr %l92, !tbaa !27
  %t330 = load ptr, ptr %lp7
  %t331 = load { i64, ptr }, ptr %t330, !tbaa !27
  %t332 = extractvalue { i64, ptr } %t331, 0
  %t333 = load { i64, ptr }, ptr %l92, !tbaa !27
  %t334 = extractvalue { i64, ptr } %t333, 0
  store i64 %t334, ptr %l94, !tbaa !24
  %t336 = load i64, ptr %l94, !tbaa !24
  %t337 = icmp eq i64 %t332, %t336
  br i1 %t337, label %bb30, label %bb31
bb30:
  %t339 = load ptr, ptr %lp7
  %t340 = getelementptr { i64, ptr }, ptr %t339, i32 0, i32 1
  %t341 = load ptr, ptr %t340, !tbaa !27
  %t342 = getelementptr { i64, ptr }, ptr %l92, i32 0, i32 1
  %t343 = load ptr, ptr %t342, !tbaa !27
  %t344 = load i64, ptr %l94, !tbaa !24
  %t345 = mul i64 %t344, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t341, ptr %t343, i64 %t345, i1 false)
  br label %bb32
bb31:
  %t346 = load { i64, ptr }, ptr %l92, !tbaa !27
  %t347 = load ptr, ptr %lp7
  store { i64, ptr } %t346, ptr %t347, !tbaa !27
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s9)
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s2)
  br label %bb34
bb34:
  %t348 = load i64, ptr %l12, !tbaa !24
  %t350 = add i64 %t348, 1
  store i64 %t350, ptr %l12, !tbaa !24
  br label %bb8
bb35:
  %t352 = load ptr, ptr %lp7
  %t353 = load { i64, ptr }, ptr %t352, !tbaa !27
  store { i64, ptr } %t353, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecloneFn(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"compiler/lower:Clone"
  %l3 = alloca { i64, [2 x i64] }
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i1
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l13 = alloca %"compiler/lower:Clone"
  %l18 = alloca ptr
  %l21 = alloca { i64, ptr }
  %l24 = alloca i1
  %l29 = alloca i64
  %l30 = alloca ptr
  %l31 = alloca { i64, [2 x i64] }
  %l33 = alloca i32
  %l34 = alloca { i64, ptr }
  %l35 = alloca i64
  %l36 = alloca i1
  %l38 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l47 = alloca ptr
  %l48 = alloca { i64, [2 x i64] }
  %l50 = alloca i32
  %l51 = alloca { i64, ptr }
  %l52 = alloca i64
  %l53 = alloca i1
  %l54 = alloca { i64, ptr }
  %l57 = alloca { i64, ptr }
  %l68 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/lower:Lowerer", ptr %t4, i32 0, i32 39
  %t7 = load i64, ptr %l1, !tbaa !24
  %t10 = call %"compiler/lower:Clone" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3aClone_3e_2eAt_3ccompiler_2flower_3aClone_3e(ptr %v0, ptr %t6, i64 %t7)
  store %"compiler/lower:Clone" %t10, ptr %l13
  br label %bb1
bb1:
  %t11 = load %"compiler/lower:Clone", ptr %l13
  store %"compiler/lower:Clone" %t11, ptr %l2
  %t12 = getelementptr %"compiler/lower:Clone", ptr %l2, i32 0, i32 0
  %t13 = load { i64, [2 x i64] }, ptr %t12
  store { i64, [2 x i64] } %t13, ptr %l3
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/emit:Emitter", ptr %t15, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !29
  %t19 = load { i64, [2 x i64] }, ptr %l3
  %t22 = call ptr @compiler_2flower_2ecompiler_2flower_3aLowerer_2eLowerKey(ptr %v0, ptr %v0, ptr %t18, { i64, [2 x i64] } %t19)
  store ptr %t22, ptr %l18
  br label %bb2
bb2:
  %t23 = load ptr, ptr %l18, !tbaa !29
  store ptr %t23, ptr %l4, !tbaa !29
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load i64, ptr %l1, !tbaa !24
  %t28 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecloneSym(ptr %v0, ptr %s0, ptr %t24, i64 %t25)
  store { i64, ptr } %t28, ptr %l21
  br label %bb3
bb3:
  %t29 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t29, ptr %l5, !tbaa !27
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load { i64, [2 x i64] }, ptr %l3
  %t34 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ehasEnv(ptr %v0, ptr %t30, { i64, [2 x i64] } %t31)
  store i1 %t34, ptr %l24
  br label %bb4
bb4:
  %t35 = load i1, ptr %l24, !tbaa !21
  store i1 %t35, ptr %l6, !tbaa !21
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load { i64, [2 x i64] }, ptr %l3
  %t38 = load ptr, ptr %l4, !tbaa !29
  %t40 = getelementptr %"compiler/mir:Fn", ptr %t38, i32 0, i32 1
  %t41 = load i32, ptr %t40, !tbaa !23
  %t45 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2epassedOf(ptr %v0, ptr %t36, { i64, [2 x i64] } %t37, i32 %t41)
  store i64 %t45, ptr %l29
  br label %bb5
bb5:
  %t46 = load i64, ptr %l29, !tbaa !24
  store i64 %t46, ptr %l7, !tbaa !24
  %t47 = load ptr, ptr %l0, !tbaa !29
  store ptr %t47, ptr %l30, !tbaa !29
  %t48 = load { i64, [2 x i64] }, ptr %l3
  store { i64, [2 x i64] } %t48, ptr %l31
  %t49 = load ptr, ptr %l4, !tbaa !29
  %t51 = getelementptr %"compiler/mir:Fn", ptr %t49, i32 0, i32 1
  %t52 = load i32, ptr %t51, !tbaa !23
  store i32 %t52, ptr %l33, !tbaa !23
  %t53 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t53, ptr %l34, !tbaa !27
  %t54 = load i64, ptr %l7, !tbaa !24
  store i64 %t54, ptr %l35, !tbaa !24
  %t55 = load i1, ptr %l6, !tbaa !21
  store i1 %t55, ptr %l36, !tbaa !21
  %t56 = load i64, ptr @G_2ecompiler_2femit_2eHomeInst, !tbaa !24
  %t58 = call { i64, ptr } @compiler_2femit_2elinkFor(ptr %s0, i64 %t56)
  store { i64, ptr } %t58, ptr %l38
  br label %bb6
bb6:
  %t59 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t60 = extractvalue { i64, ptr } %t59, 0
  %t61 = extractvalue { i64, ptr } %t59, 1
  %t62 = mul i64 %t60, 1
  %t63 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t62)
  call void @llvm.memcpy.p0.p0.i64(ptr %t63, ptr %t61, i64 %t62, i1 false)
  %t64 = insertvalue { i64, ptr } undef, i64 %t60, 0
  %t65 = insertvalue { i64, ptr } %t64, ptr %t63, 1
  %t66 = load ptr, ptr %l30, !tbaa !29
  %t67 = load { i64, [2 x i64] }, ptr %l31
  %t68 = load i32, ptr %l33, !tbaa !23
  %t69 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t70 = load i64, ptr %l35, !tbaa !24
  %t71 = load i1, ptr %l36, !tbaa !21
  %t73 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eheader(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %t66, { i64, [2 x i64] } %t67, i32 %t68, { i64, ptr } %t69, i64 %t70, i1 %t71, { i64, ptr } %t65, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d40, i32 0, i32 1) })
  store { i64, ptr } %t73, ptr %l40
  br label %bb7
bb7:
  %t74 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t74, ptr %l8, !tbaa !27
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load i64, ptr %l1, !tbaa !24
  %t79 = getelementptr %"compiler/emit:Emitter", ptr %t75, i32 0, i32 51
  store i64 %t76, ptr %t79, !tbaa !24
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/emit:Emitter", ptr %t80, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !29
  %t85 = getelementptr %"compiler/lower:Lowerer", ptr %t83, i32 0, i32 9
  %t86 = load i1, ptr %t85, !tbaa !21
  br i1 %t86, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s1
  %t88 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %s1, ptr %t88, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d41, i32 0, i32 1) })
  br label %bb10
bb9:
  br label %bb13
bb10:
  %t90 = load ptr, ptr %l0, !tbaa !29
  store ptr %t90, ptr %l47, !tbaa !29
  %t91 = load { i64, [2 x i64] }, ptr %l3
  store { i64, [2 x i64] } %t91, ptr %l48
  %t92 = load ptr, ptr %l4, !tbaa !29
  %t94 = getelementptr %"compiler/mir:Fn", ptr %t92, i32 0, i32 1
  %t95 = load i32, ptr %t94, !tbaa !23
  store i32 %t95, ptr %l50, !tbaa !23
  %t96 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t96, ptr %l51, !tbaa !27
  %t97 = load i64, ptr %l7, !tbaa !24
  store i64 %t97, ptr %l52, !tbaa !24
  %t98 = load i1, ptr %l6, !tbaa !21
  store i1 %t98, ptr %l53, !tbaa !21
  %t99 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t99, ptr %l54, !tbaa !27
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t101 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t104 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2estub(ptr %v0, ptr %s1, ptr %s0, ptr %s1, ptr %t100, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d42, i32 0, i32 1) }, { i64, ptr } %t101)
  store { i64, ptr } %t104, ptr %l57
  br label %bb11
bb11:
  %t105 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t106 = extractvalue { i64, ptr } %t105, 1
  %t107 = extractvalue { i64, ptr } %t105, 0
  %t108 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t109 = extractvalue { i64, ptr } %t108, 1
  %t110 = extractvalue { i64, ptr } %t108, 0
  %t111 = add i64 %t107, %t110
  %t112 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t111)
  call void @olang_textcopy(ptr %t112, ptr %t106, i64 %t107)
  %t113 = getelementptr i8, ptr %t112, i64 %t107
  call void @olang_textcopy(ptr %t113, ptr %t109, i64 %t110)
  %t114 = insertvalue { i64, ptr } undef, i64 %t111, 0
  %t115 = insertvalue { i64, ptr } %t114, ptr %t112, 1
  %t117 = extractvalue { i64, ptr } %t115, 0
  %t118 = extractvalue { i64, ptr } %t115, 1
  %t119 = mul i64 %t117, 1
  %t120 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t119)
  call void @llvm.memcpy.p0.p0.i64(ptr %t120, ptr %t118, i64 %t119, i1 false)
  %t121 = insertvalue { i64, ptr } undef, i64 %t117, 0
  %t122 = insertvalue { i64, ptr } %t121, ptr %t120, 1
  %t123 = load ptr, ptr %l47, !tbaa !29
  %t124 = load { i64, [2 x i64] }, ptr %l48
  %t125 = load i32, ptr %l50, !tbaa !23
  %t126 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t127 = load i64, ptr %l52, !tbaa !24
  %t128 = load i1, ptr %l53, !tbaa !21
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2efnItem(ptr %v0, ptr %s0, ptr %s1, ptr %t123, { i64, [2 x i64] } %t124, i32 %t125, { i64, ptr } %t126, i64 %t127, i1 %t128, { i64, ptr } %t122)
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s1)
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr %"compiler/emit:Emitter", ptr %t130, i32 0, i32 51
  store i64 -1, ptr %t132, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb13:
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t134 = load { i64, [2 x i64] }, ptr %l3
  %t135 = load ptr, ptr %l4, !tbaa !29
  %t136 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t137 = load i64, ptr %l7, !tbaa !24
  %t138 = load i1, ptr %l6, !tbaa !21
  %t139 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t147 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ewriteBody(ptr %v0, ptr %v0, ptr %s0, ptr %s0, ptr %t133, { i64, [2 x i64] } %t134, ptr %t135, { i64, ptr } %t136, i64 %t137, i1 %t138, { i64, ptr } %t139, i1 false)
  store i1 %t147, ptr %l68
  br label %bb14
bb14:
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t150 = getelementptr %"compiler/emit:Emitter", ptr %t148, i32 0, i32 51
  store i64 -1, ptr %t150, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecoroDecls(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s0, ptr %s0, ptr %t1, { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d43, i32 0, i32 1) }, { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d44, i32 0, i32 1) })
  br label %bb1
bb1:
  %t3 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s0, ptr %s0, ptr %t3, { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d45, i32 0, i32 1) }, { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d46, i32 0, i32 1) })
  br label %bb2
bb2:
  %t5 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s0, ptr %s0, ptr %t5, { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d47, i32 0, i32 1) }, { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d48, i32 0, i32 1) })
  br label %bb3
bb3:
  %t7 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s0, ptr %s0, ptr %t7, { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d49, i32 0, i32 1) }, { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d50, i32 0, i32 1) })
  br label %bb4
bb4:
  %t9 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s0, ptr %s0, ptr %t9, { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d51, i32 0, i32 1) }, { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d52, i32 0, i32 1) })
  br label %bb5
bb5:
  %t11 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s0, ptr %s0, ptr %t11, { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d53, i32 0, i32 1) }, { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d54, i32 0, i32 1) })
  br label %bb6
bb6:
  %t13 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s0, ptr %s0, ptr %t13, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d55, i32 0, i32 1) }, { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d56, i32 0, i32 1) })
  br label %bb7
bb7:
  %t15 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s0, ptr %s0, ptr %t15, { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d57, i32 0, i32 1) }, { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d58, i32 0, i32 1) })
  br label %bb8
bb8:
  %t17 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s0, ptr %s0, ptr %t17, { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d59, i32 0, i32 1) }, { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d60, i32 0, i32 1) })
  br label %bb9
bb9:
  %t19 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s0, ptr %s0, ptr %t19, { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d61, i32 0, i32 1) }, { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d62, i32 0, i32 1) })
  br label %bb10
bb10:
  %t21 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s0, ptr %s0, ptr %t21, { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d63, i32 0, i32 1) }, { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d64, i32 0, i32 1) })
  br label %bb11
bb11:
  %t23 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s0, ptr %s0, ptr %t23, { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d65, i32 0, i32 1) }, { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d66, i32 0, i32 1) })
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgFunctions(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca %"std/prelude/text:StringBuilder"
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"std/prelude/text:LineIter"
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l16 = alloca { i64, ptr }
  %l17 = alloca i1
  %l21 = alloca %"std/prelude/text:StringBuilder"
  %l22 = alloca %"std/prelude/text:StringBuilder"
  %l23 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l25 = alloca i64
  %l26 = alloca { i64, ptr }
  %l28 = alloca %"std/prelude/text:LineIter"
  %l29 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l32 = alloca i32
  %l34 = alloca i1
  %l36 = alloca i1
  %l37 = alloca i1
  %l39 = alloca i1
  %l40 = alloca i1
  %l43 = alloca { i64, ptr }
  %l44 = alloca i1
  %l46 = alloca i64
  %l48 = alloca i64
  %l49 = alloca i32
  %l50 = alloca i64
  %l52 = alloca i64
  %l53 = alloca i32
  %l56 = alloca i1
  %l60 = alloca { i64, ptr }
  %l62 = alloca i64
  %l63 = alloca i64
  %l64 = alloca i64
  %l70 = alloca i1
  %l71 = alloca { i64, ptr }
  %l73 = alloca i1
  %l74 = alloca { i64, ptr }
  %l75 = alloca ptr
  %l77 = alloca { i64, ptr }
  %l78 = alloca i64
  %l79 = alloca { i64, ptr }
  %l81 = alloca { i64, ptr }
  %l84 = alloca i64
  %l86 = alloca i64
  %l88 = alloca i64
  %l89 = alloca ptr
  %l90 = alloca i64
  %l92 = alloca { i64, ptr }
  %l93 = alloca i64
  %l94 = alloca i64
  %l96 = alloca i64
  %l98 = alloca i64
  %l106 = alloca ptr
  %l107 = alloca { i64, ptr }
  %l110 = alloca i64
  %l111 = alloca i64
  %l120 = alloca { i64, ptr }
  %l122 = alloca i64
  %l125 = alloca i1
  %l126 = alloca { i64, ptr }
  %l127 = alloca { i64, ptr }
  %l129 = alloca i64
  %l131 = alloca i64
  %l132 = alloca { i64, ptr }
  %l134 = alloca i1
  %l136 = alloca i1
  %l139 = alloca { i64, ptr }
  %l140 = alloca i1
  %l141 = alloca i1
  %l144 = alloca { i64, ptr }
  %l145 = alloca i1
  %l157 = alloca i64
  %l161 = alloca ptr
  %l163 = alloca { i64, ptr }
  %l166 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d67, i32 0, i32 1) }, ptr %l16, !tbaa !27
  %t4 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t5 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v1, ptr %s0, { i64, ptr } %t1, { i64, ptr } %t4)
  store i1 %t5, ptr %l17
  br label %bb1
bb1:
  %t6 = load i1, ptr %l17, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 1
  %t12 = extractvalue { i64, ptr } %t9, 0
  %t13 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t12)
  call void @olang_textcopy(ptr %t13, ptr %t11, i64 %t12)
  %t14 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t13, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t15, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t17 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t17, ptr %l21
  br label %bb5
bb5:
  %t18 = load %"std/prelude/text:StringBuilder", ptr %l21
  store %"std/prelude/text:StringBuilder" %t18, ptr %l2
  %t19 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t19, ptr %l22
  br label %bb6
bb6:
  %t20 = load %"std/prelude/text:StringBuilder", ptr %l22
  store %"std/prelude/text:StringBuilder" %t20, ptr %l3
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d68, i32 0, i32 1) }, ptr %l23, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t21, ptr %l24, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t22, 0
  store i64 %t23, ptr %l25, !tbaa !24
  %t24 = load i64, ptr %l25, !tbaa !24
  %t25 = mul i64 %t24, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t25)
  %t27 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  store { i64, ptr } %t28, ptr %l26, !tbaa !27
  %t29 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = load i64, ptr %l25, !tbaa !24
  %t34 = mul i64 %t33, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t30, ptr %t32, i64 %t34, i1 false)
  %t35 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t35, ptr %l4, !tbaa !27
  %t36 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t38 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v1, ptr %v1, { i64, ptr } %t36)
  store %"std/prelude/text:LineIter" %t38, ptr %l28
  br label %bb7
bb7:
  %t39 = load %"std/prelude/text:LineIter", ptr %l28
  store %"std/prelude/text:LineIter" %t39, ptr %l5
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s4
  %t41 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v1, ptr %v1, ptr %l5)
  %t42 = extractvalue { i32, { i64, ptr } } %t41, 1
  %t43 = extractvalue { i32, { i64, ptr } } %t41, 0
  store i32 %t43, ptr %l32
  %t44 = icmp ne i32 %t43, 0
  br i1 %t44, label %bb10, label %ok.45, !prof !99
ok.45:
  store { i64, ptr } %t42, ptr %l31
  br label %bb9
bb9:
  %t46 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t46, ptr %l29, !tbaa !27
  br label %bb12
bb10:
  %t47 = load i32, ptr %l32, !tbaa !23
  %t48 = ashr i32 %t47, 16
  %t50 = icmp eq i32 %t48, 1
  store i1 %t50, ptr %l34, !tbaa !21
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s4)
  br label %bb95
bb12:
  %t51 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t51, ptr %l6, !tbaa !27
  %t52 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t54 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s4, { i64, ptr } %t52, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d69, i32 0, i32 1) })
  store i1 %t54, ptr %l36
  br label %bb13
bb13:
  %t55 = load i1, ptr %l36, !tbaa !21
  br i1 %t55, label %bb14, label %bb15
bb14:
  %t56 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t58 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v1, ptr %s4, { i64, ptr } %t56, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d70, i32 0, i32 1) })
  store i1 %t58, ptr %l39
  br label %bb16
bb15:
  store i1 false, ptr %l37, !tbaa !21
  br label %bb17
bb16:
  %t59 = load i1, ptr %l39, !tbaa !21
  store i1 %t59, ptr %l37, !tbaa !21
  br label %bb17
bb17:
  %t60 = load i1, ptr %l37, !tbaa !21
  br i1 %t60, label %bb18, label %bb19
bb18:
  %t61 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d71, i32 0, i32 1) }, ptr %l43, !tbaa !27
  %t64 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t65 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v1, ptr %s4, { i64, ptr } %t61, { i64, ptr } %t64)
  store i1 %t65, ptr %l44
  br label %bb20
bb19:
  store i1 false, ptr %l40, !tbaa !21
  br label %bb21
bb20:
  %t66 = load i1, ptr %l44, !tbaa !21
  %t67 = xor i1 %t66, true
  store i1 %t67, ptr %l40, !tbaa !21
  br label %bb21
bb21:
  %t69 = load i1, ptr %l40, !tbaa !21
  br i1 %t69, label %bb22, label %bb23
bb22:
  store %olang.scope zeroinitializer, ptr %s5
  %t70 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t72 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v1, ptr %s5, { i64, ptr } %t70, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d72, i32 0, i32 1) })
  %t73 = extractvalue { i32, i64 } %t72, 1
  %t74 = extractvalue { i32, i64 } %t72, 0
  store i32 %t74, ptr %l49
  %t75 = icmp ne i32 %t74, 0
  br i1 %t75, label %bb25, label %ok.76, !prof !99
ok.76:
  store i64 %t73, ptr %l48
  br label %bb24
bb23:
  br label %bb72
bb24:
  %t77 = load i64, ptr %l48, !tbaa !24
  store i64 %t77, ptr %l46, !tbaa !24
  br label %bb27
bb25:
  br label %bb26
bb26:
  store i64 -1, ptr %l46, !tbaa !24
  br label %bb27
bb27:
  %t78 = load i64, ptr %l46, !tbaa !24
  store i64 %t78, ptr %l7, !tbaa !24
  %t79 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t81 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v1, ptr %s5, { i64, ptr } %t79, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d73, i32 0, i32 1) })
  %t82 = extractvalue { i32, i64 } %t81, 1
  %t83 = extractvalue { i32, i64 } %t81, 0
  store i32 %t83, ptr %l53
  %t84 = icmp ne i32 %t83, 0
  br i1 %t84, label %bb29, label %ok.85, !prof !99
ok.85:
  store i64 %t82, ptr %l52
  br label %bb28
bb28:
  %t86 = load i64, ptr %l52, !tbaa !24
  store i64 %t86, ptr %l50, !tbaa !24
  br label %bb31
bb29:
  br label %bb30
bb30:
  store i64 -1, ptr %l50, !tbaa !24
  br label %bb31
bb31:
  %t87 = load i64, ptr %l50, !tbaa !24
  store i64 %t87, ptr %l8, !tbaa !24
  %t88 = load i64, ptr %l7, !tbaa !24
  %t90 = icmp sge i64 %t88, 0
  br i1 %t90, label %bb32, label %bb33
bb32:
  %t92 = load i64, ptr %l8, !tbaa !24
  %t93 = load i64, ptr %l7, !tbaa !24
  %t96 = icmp sgt i64 %t92, %t93
  store i1 %t96, ptr %l56, !tbaa !21
  br label %bb34
bb33:
  store i1 false, ptr %l56, !tbaa !21
  br label %bb34
bb34:
  %t98 = load i1, ptr %l56, !tbaa !21
  br i1 %t98, label %bb35, label %bb36
bb35:
  store %olang.scope zeroinitializer, ptr %s6
  %t99 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t99, ptr %l60, !tbaa !27
  %t100 = load i64, ptr %l7, !tbaa !24
  %t102 = add i64 %t100, 1
  store i64 %t102, ptr %l62, !tbaa !24
  %t103 = load i64, ptr %l8, !tbaa !24
  store i64 %t103, ptr %l63, !tbaa !24
  %t104 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t105 = extractvalue { i64, ptr } %t104, 0
  store i64 %t105, ptr %l64, !tbaa !24
  %t106 = load i64, ptr %l62, !tbaa !24
  %t107 = icmp sge i64 %t106, 0
  br i1 %t107, label %bb37, label %bb38
bb36:
  br label %bb71
bb37:
  %t109 = load i64, ptr %l62, !tbaa !24
  %t110 = load i64, ptr %l63, !tbaa !24
  %t111 = icmp sle i64 %t109, %t110
  br i1 %t111, label %bb39, label %bb40
bb38:
  call void @__olang_check_failed(ptr @olang_loc_b200df0f2ca52fe9_68c86c80ca4bbd4d)
  unreachable
bb39:
  %t113 = load i64, ptr %l63, !tbaa !24
  %t114 = load i64, ptr %l64, !tbaa !24
  %t115 = icmp sle i64 %t113, %t114
  br i1 %t115, label %bb41, label %bb42
bb40:
  call void @__olang_check_failed(ptr @olang_loc_b200df0f2ca52fe9_68c86c80ca4bbd4d)
  unreachable
bb41:
  %t117 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t118 = load ptr, ptr %t117, !tbaa !27
  %t119 = load i64, ptr %l62, !tbaa !24
  %t120 = load i64, ptr %l63, !tbaa !24
  %t121 = getelementptr i8, ptr %t118, i64 %t119
  %t122 = sub i64 %t120, %t119
  %t123 = insertvalue { i64, ptr } undef, i64 %t122, 0
  %t124 = insertvalue { i64, ptr } %t123, ptr %t121, 1
  store { i64, ptr } %t124, ptr %l9, !tbaa !27
  %t126 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t128 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s6, { i64, ptr } %t126, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d74, i32 0, i32 1) })
  store i1 %t128, ptr %l70
  br label %bb43
bb42:
  call void @__olang_check_failed(ptr @olang_loc_b200df0f2ca52fe9_68c86c80ca4bbd4d)
  unreachable
bb43:
  %t129 = load i1, ptr %l70, !tbaa !21
  br i1 %t129, label %bb44, label %bb45
bb44:
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d75, i32 0, i32 1) }, ptr %l71, !tbaa !27
  br label %bb52
bb45:
  %t130 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t132 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s6, { i64, ptr } %t130, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d76, i32 0, i32 1) })
  store i1 %t132, ptr %l73
  br label %bb46
bb46:
  %t133 = load i1, ptr %l73, !tbaa !21
  br i1 %t133, label %bb47, label %bb48
bb47:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d77, i32 0, i32 1) }, ptr %l74, !tbaa !27
  br label %bb51
bb48:
  %t134 = load ptr, ptr %l0, !tbaa !29
  store ptr %t134, ptr %l75, !tbaa !29
  %t135 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t137 = call { i64, ptr } @compiler_2ftypes_2eDemangle(ptr %v1, ptr %s6, { i64, ptr } %t135)
  store { i64, ptr } %t137, ptr %l77
  br label %bb49
bb49:
  %t138 = load { i64, ptr }, ptr %l77, !tbaa !27
  %t139 = extractvalue { i64, ptr } %t138, 0
  store i64 %t139, ptr %l78, !tbaa !24
  %t140 = load i64, ptr %l78, !tbaa !24
  %t141 = mul i64 %t140, 1
  %t142 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t141)
  %t143 = insertvalue { i64, ptr } undef, i64 %t140, 0
  %t144 = insertvalue { i64, ptr } %t143, ptr %t142, 1
  store { i64, ptr } %t144, ptr %l79, !tbaa !27
  %t145 = getelementptr { i64, ptr }, ptr %l79, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !27
  %t147 = getelementptr { i64, ptr }, ptr %l77, i32 0, i32 1
  %t148 = load ptr, ptr %t147, !tbaa !27
  %t149 = load i64, ptr %l78, !tbaa !24
  %t150 = mul i64 %t149, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t146, ptr %t148, i64 %t150, i1 false)
  %t151 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t152 = extractvalue { i64, ptr } %t151, 0
  %t153 = extractvalue { i64, ptr } %t151, 1
  %t154 = mul i64 %t152, 1
  %t155 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t154)
  call void @llvm.memcpy.p0.p0.i64(ptr %t155, ptr %t153, i64 %t154, i1 false)
  %t156 = insertvalue { i64, ptr } undef, i64 %t152, 0
  %t157 = insertvalue { i64, ptr } %t156, ptr %t155, 1
  %t158 = load ptr, ptr %l75, !tbaa !29
  %t160 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ereadableTypes(ptr %v0, ptr %s6, ptr %s6, ptr %t158, { i64, ptr } %t157)
  store { i64, ptr } %t160, ptr %l81
  br label %bb50
bb50:
  %t161 = load { i64, ptr }, ptr %l81, !tbaa !27
  %t162 = extractvalue { i64, ptr } %t161, 0
  %t163 = extractvalue { i64, ptr } %t161, 1
  %t164 = mul i64 %t162, 1
  %t165 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t164)
  call void @llvm.memcpy.p0.p0.i64(ptr %t165, ptr %t163, i64 %t164, i1 false)
  %t166 = insertvalue { i64, ptr } undef, i64 %t162, 0
  %t167 = insertvalue { i64, ptr } %t166, ptr %t165, 1
  store { i64, ptr } %t167, ptr %l74, !tbaa !27
  br label %bb51
bb51:
  %t169 = load { i64, ptr }, ptr %l74, !tbaa !27
  store { i64, ptr } %t169, ptr %l71, !tbaa !27
  br label %bb52
bb52:
  %t170 = load { i64, ptr }, ptr %l71, !tbaa !27
  store { i64, ptr } %t170, ptr %l10, !tbaa !27
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t173 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgGenFile(ptr %v0, ptr %t171)
  store i64 %t173, ptr %l84
  br label %bb53
bb53:
  %t174 = load i64, ptr %l84, !tbaa !24
  store i64 %t174, ptr %l11, !tbaa !24
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t177 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgNew(ptr %v0, ptr %t175)
  store i64 %t177, ptr %l86
  br label %bb54
bb54:
  %t178 = load i64, ptr %l86, !tbaa !24
  store i64 %t178, ptr %l12, !tbaa !24
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t181 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgNew(ptr %v0, ptr %t179)
  store i64 %t181, ptr %l88
  br label %bb55
bb55:
  %t182 = load i64, ptr %l88, !tbaa !24
  store i64 %t182, ptr %l13, !tbaa !24
  store ptr %l3, ptr %l89, !tbaa !29
  %t183 = load i64, ptr %l12, !tbaa !24
  store i64 %t183, ptr %l90, !tbaa !24
  %t184 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t186 = call { i64, ptr } @compiler_2femit_2eescape(ptr %s6, ptr %s6, { i64, ptr } %t184)
  store { i64, ptr } %t186, ptr %l92
  br label %bb56
bb56:
  %t187 = load i64, ptr %l11, !tbaa !24
  store i64 %t187, ptr %l93, !tbaa !24
  %t188 = load i64, ptr %l11, !tbaa !24
  store i64 %t188, ptr %l94, !tbaa !24
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t191 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgSubTy(ptr %v0, ptr %t189)
  store i64 %t191, ptr %l96
  br label %bb57
bb57:
  %t192 = load ptr, ptr %l0, !tbaa !29
  %t194 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgCu(ptr %v0, ptr %t192)
  store i64 %t194, ptr %l98
  br label %bb58
bb58:
  %t195 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d78, i32 0, i32 1) }, 1
  %t196 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d78, i32 0, i32 1) }, 0
  %t197 = load i64, ptr %l90, !tbaa !24
  %t198 = call i64 @__olang_fmt_i64(ptr null, i64 %t197)
  %t199 = add i64 %t196, %t198
  %t200 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d79, i32 0, i32 1) }, 1
  %t201 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d79, i32 0, i32 1) }, 0
  %t202 = add i64 %t199, %t201
  %t203 = load { i64, ptr }, ptr %l92, !tbaa !27
  %t204 = extractvalue { i64, ptr } %t203, 1
  %t205 = extractvalue { i64, ptr } %t203, 0
  %t206 = add i64 %t202, %t205
  %t207 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d80, i32 0, i32 1) }, 1
  %t208 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d80, i32 0, i32 1) }, 0
  %t209 = add i64 %t206, %t208
  %t210 = load i64, ptr %l93, !tbaa !24
  %t211 = call i64 @__olang_fmt_i64(ptr null, i64 %t210)
  %t212 = add i64 %t209, %t211
  %t213 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d81, i32 0, i32 1) }, 1
  %t214 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d81, i32 0, i32 1) }, 0
  %t215 = add i64 %t212, %t214
  %t216 = load i64, ptr %l94, !tbaa !24
  %t217 = call i64 @__olang_fmt_i64(ptr null, i64 %t216)
  %t218 = add i64 %t215, %t217
  %t219 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d82, i32 0, i32 1) }, 1
  %t220 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d82, i32 0, i32 1) }, 0
  %t221 = add i64 %t218, %t220
  %t222 = load i64, ptr %l96, !tbaa !24
  %t223 = call i64 @__olang_fmt_i64(ptr null, i64 %t222)
  %t224 = add i64 %t221, %t223
  %t225 = extractvalue { i64, ptr } { i64 52, ptr getelementptr inbounds (<{ i64, [52 x i8] }>, ptr @.d83, i32 0, i32 1) }, 1
  %t226 = extractvalue { i64, ptr } { i64 52, ptr getelementptr inbounds (<{ i64, [52 x i8] }>, ptr @.d83, i32 0, i32 1) }, 0
  %t227 = add i64 %t224, %t226
  %t228 = load i64, ptr %l98, !tbaa !24
  %t229 = call i64 @__olang_fmt_i64(ptr null, i64 %t228)
  %t230 = add i64 %t227, %t229
  %t231 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d84, i32 0, i32 1) }, 1
  %t232 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d84, i32 0, i32 1) }, 0
  %t233 = add i64 %t230, %t232
  %t234 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t233)
  call void @olang_textcopy(ptr %t234, ptr %t195, i64 %t196)
  %t235 = getelementptr i8, ptr %t234, i64 %t196
  %t236 = call i64 @__olang_fmt_i64(ptr %t235, i64 %t197)
  %t237 = getelementptr i8, ptr %t235, i64 %t198
  call void @olang_textcopy(ptr %t237, ptr %t200, i64 %t201)
  %t238 = getelementptr i8, ptr %t237, i64 %t201
  call void @olang_textcopy(ptr %t238, ptr %t204, i64 %t205)
  %t239 = getelementptr i8, ptr %t238, i64 %t205
  call void @olang_textcopy(ptr %t239, ptr %t207, i64 %t208)
  %t240 = getelementptr i8, ptr %t239, i64 %t208
  %t241 = call i64 @__olang_fmt_i64(ptr %t240, i64 %t210)
  %t242 = getelementptr i8, ptr %t240, i64 %t211
  call void @olang_textcopy(ptr %t242, ptr %t213, i64 %t214)
  %t243 = getelementptr i8, ptr %t242, i64 %t214
  %t244 = call i64 @__olang_fmt_i64(ptr %t243, i64 %t216)
  %t245 = getelementptr i8, ptr %t243, i64 %t217
  call void @olang_textcopy(ptr %t245, ptr %t219, i64 %t220)
  %t246 = getelementptr i8, ptr %t245, i64 %t220
  %t247 = call i64 @__olang_fmt_i64(ptr %t246, i64 %t222)
  %t248 = getelementptr i8, ptr %t246, i64 %t223
  call void @olang_textcopy(ptr %t248, ptr %t225, i64 %t226)
  %t249 = getelementptr i8, ptr %t248, i64 %t226
  %t250 = call i64 @__olang_fmt_i64(ptr %t249, i64 %t228)
  %t251 = getelementptr i8, ptr %t249, i64 %t229
  call void @olang_textcopy(ptr %t251, ptr %t231, i64 %t232)
  %t252 = insertvalue { i64, ptr } undef, i64 %t233, 0
  %t253 = insertvalue { i64, ptr } %t252, ptr %t234, 1
  %t255 = extractvalue { i64, ptr } %t253, 0
  %t256 = extractvalue { i64, ptr } %t253, 1
  %t257 = mul i64 %t255, 1
  %t258 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t257)
  call void @llvm.memcpy.p0.p0.i64(ptr %t258, ptr %t256, i64 %t257, i1 false)
  %t259 = insertvalue { i64, ptr } undef, i64 %t255, 0
  %t260 = insertvalue { i64, ptr } %t259, ptr %t258, 1
  %t261 = load ptr, ptr %l89, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s6, ptr %t261, { i64, ptr } %t260)
  br label %bb59
bb59:
  %t263 = load i64, ptr %l13, !tbaa !24
  %t264 = load i64, ptr %l12, !tbaa !24
  %t265 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d85, i32 0, i32 1) }, 1
  %t266 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d85, i32 0, i32 1) }, 0
  %t268 = call i64 @__olang_fmt_i64(ptr null, i64 %t263)
  %t269 = add i64 %t266, %t268
  %t270 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d86, i32 0, i32 1) }, 1
  %t271 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d86, i32 0, i32 1) }, 0
  %t272 = add i64 %t269, %t271
  %t274 = call i64 @__olang_fmt_i64(ptr null, i64 %t264)
  %t275 = add i64 %t272, %t274
  %t276 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d87, i32 0, i32 1) }, 1
  %t277 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d87, i32 0, i32 1) }, 0
  %t278 = add i64 %t275, %t277
  %t279 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t278)
  call void @olang_textcopy(ptr %t279, ptr %t265, i64 %t266)
  %t280 = getelementptr i8, ptr %t279, i64 %t266
  %t281 = call i64 @__olang_fmt_i64(ptr %t280, i64 %t263)
  %t282 = getelementptr i8, ptr %t280, i64 %t268
  call void @olang_textcopy(ptr %t282, ptr %t270, i64 %t271)
  %t283 = getelementptr i8, ptr %t282, i64 %t271
  %t284 = call i64 @__olang_fmt_i64(ptr %t283, i64 %t264)
  %t285 = getelementptr i8, ptr %t283, i64 %t274
  call void @olang_textcopy(ptr %t285, ptr %t276, i64 %t277)
  %t286 = insertvalue { i64, ptr } undef, i64 %t278, 0
  %t287 = insertvalue { i64, ptr } %t286, ptr %t279, 1
  %t289 = extractvalue { i64, ptr } %t287, 0
  %t290 = extractvalue { i64, ptr } %t287, 1
  %t291 = mul i64 %t289, 1
  %t292 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t291)
  call void @llvm.memcpy.p0.p0.i64(ptr %t292, ptr %t290, i64 %t291, i1 false)
  %t293 = insertvalue { i64, ptr } undef, i64 %t289, 0
  %t294 = insertvalue { i64, ptr } %t293, ptr %t292, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s6, ptr %l3, { i64, ptr } %t294)
  br label %bb60
bb60:
  store ptr %l2, ptr %l106, !tbaa !29
  %t297 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t297, ptr %l107, !tbaa !27
  %t298 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t300 = extractvalue { i64, ptr } %t298, 0
  %t302 = sub i64 %t300, 2
  store i64 %t302, ptr %l110, !tbaa !24
  %t303 = load { i64, ptr }, ptr %l107, !tbaa !27
  %t304 = extractvalue { i64, ptr } %t303, 0
  store i64 %t304, ptr %l111, !tbaa !24
  %t305 = icmp sge i64 0, 0
  br i1 %t305, label %bb61, label %bb62
bb61:
  %t307 = load i64, ptr %l110, !tbaa !24
  %t308 = icmp sle i64 0, %t307
  br i1 %t308, label %bb63, label %bb64
bb62:
  call void @__olang_check_failed(ptr @olang_loc_e7f1f4c1c7eb01fc_51bf614425d25b70)
  unreachable
bb63:
  %t310 = load i64, ptr %l110, !tbaa !24
  %t311 = load i64, ptr %l111, !tbaa !24
  %t312 = icmp sle i64 %t310, %t311
  br i1 %t312, label %bb65, label %bb66
bb64:
  call void @__olang_check_failed(ptr @olang_loc_e7f1f4c1c7eb01fc_51bf614425d25b70)
  unreachable
bb65:
  %t314 = getelementptr { i64, ptr }, ptr %l107, i32 0, i32 1
  %t315 = load ptr, ptr %t314, !tbaa !27
  %t316 = load i64, ptr %l110, !tbaa !24
  %t317 = getelementptr i8, ptr %t315, i64 0
  %t318 = sub i64 %t316, 0
  %t319 = insertvalue { i64, ptr } undef, i64 %t318, 0
  %t320 = insertvalue { i64, ptr } %t319, ptr %t317, 1
  %t321 = load i64, ptr %l12, !tbaa !24
  %t323 = extractvalue { i64, ptr } %t320, 1
  %t324 = extractvalue { i64, ptr } %t320, 0
  %t325 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d88, i32 0, i32 1) }, 1
  %t326 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d88, i32 0, i32 1) }, 0
  %t327 = add i64 %t324, %t326
  %t329 = call i64 @__olang_fmt_i64(ptr null, i64 %t321)
  %t330 = add i64 %t327, %t329
  %t331 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d89, i32 0, i32 1) }, 1
  %t332 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d89, i32 0, i32 1) }, 0
  %t333 = add i64 %t330, %t332
  %t334 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t333)
  call void @olang_textcopy(ptr %t334, ptr %t323, i64 %t324)
  %t335 = getelementptr i8, ptr %t334, i64 %t324
  call void @olang_textcopy(ptr %t335, ptr %t325, i64 %t326)
  %t336 = getelementptr i8, ptr %t335, i64 %t326
  %t337 = call i64 @__olang_fmt_i64(ptr %t336, i64 %t321)
  %t338 = getelementptr i8, ptr %t336, i64 %t329
  call void @olang_textcopy(ptr %t338, ptr %t331, i64 %t332)
  %t339 = insertvalue { i64, ptr } undef, i64 %t333, 0
  %t340 = insertvalue { i64, ptr } %t339, ptr %t334, 1
  %t342 = extractvalue { i64, ptr } %t340, 0
  %t343 = extractvalue { i64, ptr } %t340, 1
  %t344 = mul i64 %t342, 1
  %t345 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t344)
  call void @llvm.memcpy.p0.p0.i64(ptr %t345, ptr %t343, i64 %t344, i1 false)
  %t346 = insertvalue { i64, ptr } undef, i64 %t342, 0
  %t347 = insertvalue { i64, ptr } %t346, ptr %t345, 1
  %t348 = load ptr, ptr %l106, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s6, ptr %t348, { i64, ptr } %t347)
  br label %bb67
bb66:
  call void @__olang_check_failed(ptr @olang_loc_e7f1f4c1c7eb01fc_51bf614425d25b70)
  unreachable
bb67:
  %t350 = load i64, ptr %l13, !tbaa !24
  %t351 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d90, i32 0, i32 1) }, 1
  %t352 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d90, i32 0, i32 1) }, 0
  %t354 = call i64 @__olang_fmt_i64(ptr null, i64 %t350)
  %t355 = add i64 %t352, %t354
  %t356 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t355)
  call void @olang_textcopy(ptr %t356, ptr %t351, i64 %t352)
  %t357 = getelementptr i8, ptr %t356, i64 %t352
  %t358 = call i64 @__olang_fmt_i64(ptr %t357, i64 %t350)
  %t359 = insertvalue { i64, ptr } undef, i64 %t355, 0
  %t360 = insertvalue { i64, ptr } %t359, ptr %t356, 1
  store { i64, ptr } %t360, ptr %l120, !tbaa !27
  %t361 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t362 = extractvalue { i64, ptr } %t361, 0
  %t363 = load { i64, ptr }, ptr %l120, !tbaa !27
  %t364 = extractvalue { i64, ptr } %t363, 0
  store i64 %t364, ptr %l122, !tbaa !24
  %t366 = load i64, ptr %l122, !tbaa !24
  %t367 = icmp eq i64 %t362, %t366
  br i1 %t367, label %bb68, label %bb69
bb68:
  %t369 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t370 = load ptr, ptr %t369, !tbaa !27
  %t371 = getelementptr { i64, ptr }, ptr %l120, i32 0, i32 1
  %t372 = load ptr, ptr %t371, !tbaa !27
  %t373 = load i64, ptr %l122, !tbaa !24
  %t374 = mul i64 %t373, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t370, ptr %t372, i64 %t374, i1 false)
  br label %bb70
bb69:
  %t375 = load { i64, ptr }, ptr %l120, !tbaa !27
  store { i64, ptr } %t375, ptr %l4, !tbaa !27
  br label %bb70
bb70:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s4)
  br label %bb94
bb71:
  call void @__olang_scope_close(ptr %s5)
  br label %bb72
bb72:
  %t376 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t378 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s4, { i64, ptr } %t376, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d91, i32 0, i32 1) })
  store i1 %t378, ptr %l125
  br label %bb73
bb73:
  %t379 = load i1, ptr %l125, !tbaa !21
  br i1 %t379, label %bb74, label %bb75
bb74:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d92, i32 0, i32 1) }, ptr %l126, !tbaa !27
  %t380 = load { i64, ptr }, ptr %l126, !tbaa !27
  store { i64, ptr } %t380, ptr %l127, !tbaa !27
  %t381 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t382 = extractvalue { i64, ptr } %t381, 0
  %t383 = load { i64, ptr }, ptr %l127, !tbaa !27
  %t384 = extractvalue { i64, ptr } %t383, 0
  store i64 %t384, ptr %l129, !tbaa !24
  %t386 = load i64, ptr %l129, !tbaa !24
  %t387 = icmp eq i64 %t382, %t386
  br i1 %t387, label %bb76, label %bb77
bb75:
  br label %bb79
bb76:
  %t389 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t390 = load ptr, ptr %t389, !tbaa !27
  %t391 = getelementptr { i64, ptr }, ptr %l127, i32 0, i32 1
  %t392 = load ptr, ptr %t391, !tbaa !27
  %t393 = load i64, ptr %l129, !tbaa !24
  %t394 = mul i64 %t393, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t390, ptr %t392, i64 %t394, i1 false)
  br label %bb78
bb77:
  %t395 = load { i64, ptr }, ptr %l127, !tbaa !27
  %t396 = extractvalue { i64, ptr } %t395, 0
  store i64 %t396, ptr %l131, !tbaa !24
  %t397 = load i64, ptr %l131, !tbaa !24
  %t398 = mul i64 %t397, 1
  %t399 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t398)
  %t400 = insertvalue { i64, ptr } undef, i64 %t397, 0
  %t401 = insertvalue { i64, ptr } %t400, ptr %t399, 1
  store { i64, ptr } %t401, ptr %l132, !tbaa !27
  %t402 = getelementptr { i64, ptr }, ptr %l132, i32 0, i32 1
  %t403 = load ptr, ptr %t402, !tbaa !27
  %t404 = getelementptr { i64, ptr }, ptr %l127, i32 0, i32 1
  %t405 = load ptr, ptr %t404, !tbaa !27
  %t406 = load i64, ptr %l131, !tbaa !24
  %t407 = mul i64 %t406, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t403, ptr %t405, i64 %t407, i1 false)
  %t408 = load { i64, ptr }, ptr %l132, !tbaa !27
  store { i64, ptr } %t408, ptr %l4, !tbaa !27
  br label %bb78
bb78:
  br label %bb79
bb79:
  %t409 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t411 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s4, { i64, ptr } %t409, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d93, i32 0, i32 1) })
  store i1 %t411, ptr %l134
  br label %bb80
bb80:
  %t412 = load i1, ptr %l134, !tbaa !21
  %t413 = xor i1 %t412, true
  br i1 %t413, label %bb81, label %bb82
bb81:
  %t415 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d94, i32 0, i32 1) }, ptr %l139, !tbaa !27
  %t418 = load { i64, ptr }, ptr %l139, !tbaa !27
  %t419 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v1, ptr %s4, { i64, ptr } %t415, { i64, ptr } %t418)
  store i1 %t419, ptr %l140
  br label %bb83
bb82:
  store i1 false, ptr %l136, !tbaa !21
  br label %bb84
bb83:
  %t420 = load i1, ptr %l140, !tbaa !21
  store i1 %t420, ptr %l136, !tbaa !21
  br label %bb84
bb84:
  %t421 = load i1, ptr %l136, !tbaa !21
  br i1 %t421, label %bb85, label %bb86
bb85:
  %t422 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d95, i32 0, i32 1) }, ptr %l144, !tbaa !27
  %t425 = load { i64, ptr }, ptr %l144, !tbaa !27
  %t426 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v1, ptr %s4, { i64, ptr } %t422, { i64, ptr } %t425)
  store i1 %t426, ptr %l145
  br label %bb87
bb86:
  store i1 false, ptr %l141, !tbaa !21
  br label %bb88
bb87:
  %t427 = load i1, ptr %l145, !tbaa !21
  %t428 = xor i1 %t427, true
  store i1 %t428, ptr %l141, !tbaa !21
  br label %bb88
bb88:
  %t430 = load i1, ptr %l141, !tbaa !21
  br i1 %t430, label %bb89, label %bb90
bb89:
  store %olang.scope zeroinitializer, ptr %s12
  %t431 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t432 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t434 = extractvalue { i64, ptr } %t431, 1
  %t435 = extractvalue { i64, ptr } %t431, 0
  %t437 = extractvalue { i64, ptr } %t432, 1
  %t438 = extractvalue { i64, ptr } %t432, 0
  %t439 = add i64 %t435, %t438
  %t440 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d96, i32 0, i32 1) }, 1
  %t441 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d96, i32 0, i32 1) }, 0
  %t442 = add i64 %t439, %t441
  %t443 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t442)
  call void @olang_textcopy(ptr %t443, ptr %t434, i64 %t435)
  %t444 = getelementptr i8, ptr %t443, i64 %t435
  call void @olang_textcopy(ptr %t444, ptr %t437, i64 %t438)
  %t445 = getelementptr i8, ptr %t444, i64 %t438
  call void @olang_textcopy(ptr %t445, ptr %t440, i64 %t441)
  %t446 = insertvalue { i64, ptr } undef, i64 %t442, 0
  %t447 = insertvalue { i64, ptr } %t446, ptr %t443, 1
  %t449 = extractvalue { i64, ptr } %t447, 0
  %t450 = extractvalue { i64, ptr } %t447, 1
  %t451 = mul i64 %t449, 1
  %t452 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t451)
  call void @llvm.memcpy.p0.p0.i64(ptr %t452, ptr %t450, i64 %t451, i1 false)
  %t453 = insertvalue { i64, ptr } undef, i64 %t449, 0
  %t454 = insertvalue { i64, ptr } %t453, ptr %t452, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s12, ptr %l2, { i64, ptr } %t454)
  br label %bb91
bb90:
  br label %bb92
bb91:
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s4)
  br label %bb94
bb92:
  %t457 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t459 = extractvalue { i64, ptr } %t457, 1
  %t460 = extractvalue { i64, ptr } %t457, 0
  %t461 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d97, i32 0, i32 1) }, 1
  %t462 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d97, i32 0, i32 1) }, 0
  %t463 = add i64 %t460, %t462
  %t464 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t463)
  call void @olang_textcopy(ptr %t464, ptr %t459, i64 %t460)
  %t465 = getelementptr i8, ptr %t464, i64 %t460
  call void @olang_textcopy(ptr %t465, ptr %t461, i64 %t462)
  %t466 = insertvalue { i64, ptr } undef, i64 %t463, 0
  %t467 = insertvalue { i64, ptr } %t466, ptr %t464, 1
  %t469 = extractvalue { i64, ptr } %t467, 0
  %t470 = extractvalue { i64, ptr } %t467, 1
  %t471 = mul i64 %t469, 1
  %t472 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t471)
  call void @llvm.memcpy.p0.p0.i64(ptr %t472, ptr %t470, i64 %t471, i1 false)
  %t473 = insertvalue { i64, ptr } undef, i64 %t469, 0
  %t474 = insertvalue { i64, ptr } %t473, ptr %t472, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s4, ptr %l2, { i64, ptr } %t474)
  br label %bb93
bb93:
  call void @__olang_scope_close(ptr %s4)
  br label %bb94
bb94:
  br label %bb8
bb95:
  %t478 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %s0, ptr %l3)
  store i64 %t478, ptr %l157
  br label %bb96
bb96:
  %t479 = load i64, ptr %l157, !tbaa !24
  %t480 = icmp eq i64 %t479, 0
  br i1 %t480, label %bb97, label %bb98
bb97:
  %t482 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t484 = extractvalue { i64, ptr } %t482, 1
  %t485 = extractvalue { i64, ptr } %t482, 0
  %t486 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t485)
  call void @olang_textcopy(ptr %t486, ptr %t484, i64 %t485)
  %t487 = insertvalue { i64, ptr } undef, i64 %t485, 0
  %t488 = insertvalue { i64, ptr } %t487, ptr %t486, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t488, ptr %rv
  br label %ret
bb98:
  br label %bb99
bb99:
  store ptr %l2, ptr %l161, !tbaa !29
  %t491 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l3)
  store { i64, ptr } %t491, ptr %l163
  br label %bb100
bb100:
  %t492 = load { i64, ptr }, ptr %l163, !tbaa !27
  %t493 = extractvalue { i64, ptr } %t492, 0
  %t494 = extractvalue { i64, ptr } %t492, 1
  %t495 = mul i64 %t493, 1
  %t496 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t495)
  call void @llvm.memcpy.p0.p0.i64(ptr %t496, ptr %t494, i64 %t495, i1 false)
  %t497 = insertvalue { i64, ptr } undef, i64 %t493, 0
  %t498 = insertvalue { i64, ptr } %t497, ptr %t496, 1
  %t499 = load ptr, ptr %l161, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t499, { i64, ptr } %t498)
  br label %bb101
bb101:
  %t502 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l2)
  store { i64, ptr } %t502, ptr %l166
  br label %bb102
bb102:
  call void @__olang_scope_close(ptr %s0)
  %t503 = load { i64, ptr }, ptr %l166, !tbaa !27
  store { i64, ptr } %t503, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eentry(ptr %v0, ptr %v1, ptr %a0, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca %"std/prelude/text:StringBuilder"
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca { i64, [2 x i64] }
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i32
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca { i64, ptr }
  %l34 = alloca %"std/prelude/text:StringBuilder"
  %l45 = alloca ptr
  %l46 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l48 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l49 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l51 = alloca i64
  %l53 = alloca i64
  %l58 = alloca i64
  %l62 = alloca i1
  %l64 = alloca ptr
  %l70 = alloca { i64, ptr }
  %l84 = alloca ptr
  %l87 = alloca ptr
  %l90 = alloca i32
  %l91 = alloca { i64, ptr }
  %l96 = alloca ptr
  %l99 = alloca { i64, ptr }
  %l102 = alloca ptr
  %l106 = alloca i64
  %l108 = alloca { i64, ptr }
  %l110 = alloca ptr
  %l113 = alloca { i64, ptr }
  %l121 = alloca { i64, ptr }
  %l122 = alloca { i64, ptr }
  %l123 = alloca [3 x i8]
  %l126 = alloca ptr
  %l128 = alloca { i64, ptr }
  %l136 = alloca i64
  %l139 = alloca i64
  %l158 = alloca { i64, ptr }
  %l161 = alloca i32
  %l163 = alloca ptr
  %l166 = alloca i32
  %l167 = alloca { i64, ptr }
  %l173 = alloca i64
  %l176 = alloca i64
  %l203 = alloca { i64, ptr }
  %l205 = alloca ptr
  %l208 = alloca i32
  %l210 = alloca { i64, ptr }
  %l217 = alloca ptr
  %l218 = alloca i64
  %l219 = alloca i64
  %l222 = alloca { i64, ptr }
  %l227 = alloca { i64, ptr }
  %l229 = alloca i64
  %l240 = alloca i1
  %l245 = alloca ptr
  %l249 = alloca i64
  %l251 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %t71 = alloca { i64, [2 x i64] }, align 8
  %t111 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edefine(ptr %v0, ptr %s0, ptr %s0, ptr %t6, { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d98, i32 0, i32 1) }, { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d99, i32 0, i32 1) })
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edefine(ptr %v0, ptr %s0, ptr %s0, ptr %t8, { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d100, i32 0, i32 1) }, { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d101, i32 0, i32 1) })
  br label %bb2
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %s0, ptr %t10, { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d102, i32 0, i32 1) })
  br label %bb3
bb3:
  %t12 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t12, ptr %l34
  br label %bb4
bb4:
  %t13 = load %"std/prelude/text:StringBuilder", ptr %l34
  store %"std/prelude/text:StringBuilder" %t13, ptr %l4
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l4, { i64, ptr } { i64 51, ptr getelementptr inbounds (<{ i64, [51 x i8] }>, ptr @.d103, i32 0, i32 1) })
  br label %bb5
bb5:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l4, { i64, ptr } { i64 74, ptr getelementptr inbounds (<{ i64, [74 x i8] }>, ptr @.d104, i32 0, i32 1) })
  br label %bb6
bb6:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l4, { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d105, i32 0, i32 1) })
  br label %bb7
bb7:
  %t17 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2esanInit(ptr %v0, ptr %s0, ptr %t17, ptr %l4)
  br label %bb8
bb8:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/emit:Emitter", ptr %t20, i32 0, i32 6
  %t23 = load i1, ptr %t22, !tbaa !21
  br i1 %t23, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s1
  %t25 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %s1, ptr %t25, { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d106, i32 0, i32 1) })
  br label %bb11
bb10:
  br label %bb14
bb11:
  %t27 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s1, ptr %s1, ptr %t27, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d107, i32 0, i32 1) }, { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d108, i32 0, i32 1) })
  br label %bb12
bb12:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s1, ptr %l4, { i64, ptr } { i64 97, ptr getelementptr inbounds (<{ i64, [97 x i8] }>, ptr @.d109, i32 0, i32 1) })
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s1)
  br label %bb14
bb14:
  store %olang.scope zeroinitializer, ptr %s2
  %t30 = load ptr, ptr %l0, !tbaa !29
  store ptr %t30, ptr %l45, !tbaa !29
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a1, ptr %l46
  %t33 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %s2, ptr %l46)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t33, ptr %l48
  br label %bb15
bb15:
  %t34 = load ptr, ptr %l45, !tbaa !29
  %t35 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l48
  %t36 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2femit_2ecompiler_2femit_3aEmitter_2eglobalOrder(ptr %v0, ptr %s2, ptr %s2, ptr %t34, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t35)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t36, ptr %l49
  br label %bb16
bb16:
  %t37 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l49
  %t38 = call ptr @__olang_scope_alloc_a(ptr %s2, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t37, ptr %t38
  store ptr %t38, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb17
bb17:
  %t40 = load i64, ptr %l6, !tbaa !24
  store i64 %t40, ptr %l51, !tbaa !24
  %t41 = load ptr, ptr %l5, !tbaa !29
  %t43 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s2, ptr %t41)
  store i64 %t43, ptr %l53
  br label %bb18
bb18:
  %t44 = load i64, ptr %l51, !tbaa !24
  %t45 = load i64, ptr %l53, !tbaa !24
  %t46 = icmp slt i64 %t44, %t45
  %t48 = xor i1 %t46, true
  br i1 %t48, label %bb19, label %bb20
bb19:
  br label %bb30
bb20:
  br label %bb21
bb21:
  %t50 = load ptr, ptr %l5, !tbaa !29
  %t51 = load i64, ptr %l6, !tbaa !24
  %t54 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s2, ptr %t50, i64 %t51)
  store i64 %t54, ptr %l58
  br label %bb22
bb22:
  %t55 = load i64, ptr %l58, !tbaa !24
  store i64 %t55, ptr %l7, !tbaa !24
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/emit:Emitter", ptr %t56, i32 0, i32 54
  %t59 = load i64, ptr %l7, !tbaa !24
  %t62 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2feval_3aImage_3e_2e_H901ad831a5883703dcf426ee01511832(ptr %v0, ptr %t58, i64 %t59)
  store i1 %t62, ptr %l62
  br label %bb23
bb23:
  %t63 = load i1, ptr %l62, !tbaa !21
  %t64 = xor i1 %t63, true
  br i1 %t64, label %bb24, label %bb25
bb24:
  store %olang.scope zeroinitializer, ptr %s4
  store ptr %l4, ptr %l64, !tbaa !29
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load i64, ptr %l7, !tbaa !24
  %t69 = trunc i64 %t67 to i32
  store { i64, [2 x i64] } zeroinitializer, ptr %t71
  %t72 = getelementptr { i64, [2 x i64] }, ptr %t71, i32 0, i32 0
  store i64 0, ptr %t72
  %t74 = insertvalue { i32 } undef, i32 %t69, 0
  %t75 = getelementptr { i64, [2 x i64] }, ptr %t71, i32 0, i32 1
  store { i32 } %t74, ptr %t75
  %t76 = load { i64, [2 x i64] }, ptr %t71
  %t79 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2esym(ptr %v0, ptr %s4, ptr %t66, { i64, [2 x i64] } %t76)
  store { i64, ptr } %t79, ptr %l70
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t80 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d110, i32 0, i32 1) }, 1
  %t81 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d110, i32 0, i32 1) }, 0
  %t82 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t83 = extractvalue { i64, ptr } %t82, 1
  %t84 = extractvalue { i64, ptr } %t82, 0
  %t85 = add i64 %t81, %t84
  %t86 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d111, i32 0, i32 1) }, 1
  %t87 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d111, i32 0, i32 1) }, 0
  %t88 = add i64 %t85, %t87
  %t89 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t88)
  call void @olang_textcopy(ptr %t89, ptr %t80, i64 %t81)
  %t90 = getelementptr i8, ptr %t89, i64 %t81
  call void @olang_textcopy(ptr %t90, ptr %t83, i64 %t84)
  %t91 = getelementptr i8, ptr %t90, i64 %t84
  call void @olang_textcopy(ptr %t91, ptr %t86, i64 %t87)
  %t92 = insertvalue { i64, ptr } undef, i64 %t88, 0
  %t93 = insertvalue { i64, ptr } %t92, ptr %t89, 1
  %t95 = extractvalue { i64, ptr } %t93, 0
  %t96 = extractvalue { i64, ptr } %t93, 1
  %t97 = mul i64 %t95, 1
  %t98 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t97)
  call void @llvm.memcpy.p0.p0.i64(ptr %t98, ptr %t96, i64 %t97, i1 false)
  %t99 = insertvalue { i64, ptr } undef, i64 %t95, 0
  %t100 = insertvalue { i64, ptr } %t99, ptr %t98, 1
  %t101 = load ptr, ptr %l64, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s4, ptr %t101, { i64, ptr } %t100)
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s4)
  br label %bb28
bb28:
  br label %bb29
bb29:
  %t103 = load i64, ptr %l6, !tbaa !24
  %t105 = add i64 %t103, 1
  store i64 %t105, ptr %l6, !tbaa !24
  br label %bb17
bb30:
  call void @__olang_scope_close(ptr %s2)
  %t107 = load i64, ptr %l2, !tbaa !24
  %t109 = trunc i64 %t107 to i32
  store { i64, [2 x i64] } zeroinitializer, ptr %t111
  %t112 = getelementptr { i64, [2 x i64] }, ptr %t111, i32 0, i32 0
  store i64 0, ptr %t112
  %t114 = insertvalue { i32 } undef, i32 %t109, 0
  %t115 = getelementptr { i64, [2 x i64] }, ptr %t111, i32 0, i32 1
  store { i32 } %t114, ptr %t115
  %t116 = load { i64, [2 x i64] }, ptr %t111
  store { i64, [2 x i64] } %t116, ptr %l8
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t120 = getelementptr %"compiler/emit:Emitter", ptr %t118, i32 0, i32 1
  %t121 = load ptr, ptr %t120, !tbaa !29
  %t123 = getelementptr %"compiler/lower:Lowerer", ptr %t121, i32 0, i32 1
  %t124 = load ptr, ptr %t123, !tbaa !29
  %t126 = load i64, ptr %l2, !tbaa !24
  %t129 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t124, i64 %t126)
  store ptr %t129, ptr %l84
  br label %bb31
bb31:
  %t130 = load ptr, ptr %l84, !tbaa !29
  %t132 = getelementptr %"compiler/typed:Body", ptr %t130, i32 0, i32 2
  %t133 = load i32, ptr %t132, !tbaa !23
  %t135 = load ptr, ptr %l3, !tbaa !29
  store ptr %t135, ptr %l87, !tbaa !29
  %t136 = load ptr, ptr %l3, !tbaa !29
  %t140 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t136, i32 %t133)
  store i32 %t140, ptr %l90
  br label %bb32
bb32:
  %t141 = load ptr, ptr %l87, !tbaa !29
  %t142 = load i32, ptr %l90, !tbaa !23
  %t143 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t141, i32 %t142)
  store { i64, ptr } %t143, ptr %l91
  br label %bb33
bb33:
  %t144 = load { i64, ptr }, ptr %l91, !tbaa !27
  store { i64, ptr } %t144, ptr %l10, !tbaa !27
  %t145 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %s0, ptr %t145, { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d112, i32 0, i32 1) })
  br label %bb34
bb34:
  %t147 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t149 = extractvalue { i64, ptr } %t147, 0
  %t151 = icmp eq i64 %t149, 0
  br i1 %t151, label %bb35, label %bb36
bb35:
  store %olang.scope zeroinitializer, ptr %s7
  store ptr %l4, ptr %l96, !tbaa !29
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t154 = load { i64, [2 x i64] }, ptr %l8
  %t157 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2esym(ptr %v0, ptr %s7, ptr %t153, { i64, [2 x i64] } %t154)
  store { i64, ptr } %t157, ptr %l99
  br label %bb37
bb36:
  br label %bb41
bb37:
  %t158 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d113, i32 0, i32 1) }, 1
  %t159 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d113, i32 0, i32 1) }, 0
  %t160 = load { i64, ptr }, ptr %l99, !tbaa !27
  %t161 = extractvalue { i64, ptr } %t160, 1
  %t162 = extractvalue { i64, ptr } %t160, 0
  %t163 = add i64 %t159, %t162
  %t164 = extractvalue { i64, ptr } { i64 50, ptr getelementptr inbounds (<{ i64, [50 x i8] }>, ptr @.d114, i32 0, i32 1) }, 1
  %t165 = extractvalue { i64, ptr } { i64 50, ptr getelementptr inbounds (<{ i64, [50 x i8] }>, ptr @.d114, i32 0, i32 1) }, 0
  %t166 = add i64 %t163, %t165
  %t167 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t166)
  call void @olang_textcopy(ptr %t167, ptr %t158, i64 %t159)
  %t168 = getelementptr i8, ptr %t167, i64 %t159
  call void @olang_textcopy(ptr %t168, ptr %t161, i64 %t162)
  %t169 = getelementptr i8, ptr %t168, i64 %t162
  call void @olang_textcopy(ptr %t169, ptr %t164, i64 %t165)
  %t170 = insertvalue { i64, ptr } undef, i64 %t166, 0
  %t171 = insertvalue { i64, ptr } %t170, ptr %t167, 1
  %t173 = extractvalue { i64, ptr } %t171, 0
  %t174 = extractvalue { i64, ptr } %t171, 1
  %t175 = mul i64 %t173, 1
  %t176 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t175)
  call void @llvm.memcpy.p0.p0.i64(ptr %t176, ptr %t174, i64 %t175, i1 false)
  %t177 = insertvalue { i64, ptr } undef, i64 %t173, 0
  %t178 = insertvalue { i64, ptr } %t177, ptr %t176, 1
  %t179 = load ptr, ptr %l96, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s7, ptr %t179, { i64, ptr } %t178)
  br label %bb38
bb38:
  %t181 = load ptr, ptr %l0, !tbaa !29
  store ptr %t181, ptr %l102, !tbaa !29
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t184 = getelementptr %"compiler/emit:Emitter", ptr %t182, i32 0, i32 0
  %t185 = load ptr, ptr %t184, !tbaa !29
  %t187 = getelementptr %"compiler/generic:Program", ptr %t185, i32 0, i32 0
  %t188 = load ptr, ptr %t187, !tbaa !29
  %t190 = getelementptr %"compiler/load:Loader", ptr %t188, i32 0, i32 12
  %t191 = load i64, ptr %t190, !tbaa !24
  store i64 %t191, ptr %l106, !tbaa !24
  %t193 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s7, ptr %l4)
  store { i64, ptr } %t193, ptr %l108
  br label %bb39
bb39:
  %t194 = load { i64, ptr }, ptr %l108, !tbaa !27
  %t195 = extractvalue { i64, ptr } %t194, 0
  %t196 = extractvalue { i64, ptr } %t194, 1
  %t197 = mul i64 %t195, 1
  %t198 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t197)
  call void @llvm.memcpy.p0.p0.i64(ptr %t198, ptr %t196, i64 %t197, i1 false)
  %t199 = insertvalue { i64, ptr } undef, i64 %t195, 0
  %t200 = insertvalue { i64, ptr } %t199, ptr %t198, 1
  %t201 = load ptr, ptr %l102, !tbaa !29
  %t202 = load i64, ptr %l106, !tbaa !24
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eitem(ptr %v0, ptr %s7, ptr %s7, ptr %s7, ptr %t201, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d115, i32 0, i32 1) }, i64 %t202, { i64, ptr } %t200, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d116, i32 0, i32 1) })
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb41:
  store ptr %l4, ptr %l110, !tbaa !29
  %t204 = load ptr, ptr %l0, !tbaa !29
  %t205 = load { i64, [2 x i64] }, ptr %l8
  %t208 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2esym(ptr %v0, ptr %s0, ptr %t204, { i64, [2 x i64] } %t205)
  store { i64, ptr } %t208, ptr %l113
  br label %bb42
bb42:
  %t209 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d117, i32 0, i32 1) }, 1
  %t210 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d117, i32 0, i32 1) }, 0
  %t211 = load { i64, ptr }, ptr %l113, !tbaa !27
  %t212 = extractvalue { i64, ptr } %t211, 1
  %t213 = extractvalue { i64, ptr } %t211, 0
  %t214 = add i64 %t210, %t213
  %t215 = extractvalue { i64, ptr } { i64 70, ptr getelementptr inbounds (<{ i64, [70 x i8] }>, ptr @.d118, i32 0, i32 1) }, 1
  %t216 = extractvalue { i64, ptr } { i64 70, ptr getelementptr inbounds (<{ i64, [70 x i8] }>, ptr @.d118, i32 0, i32 1) }, 0
  %t217 = add i64 %t214, %t216
  %t218 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t217)
  call void @olang_textcopy(ptr %t218, ptr %t209, i64 %t210)
  %t219 = getelementptr i8, ptr %t218, i64 %t210
  call void @olang_textcopy(ptr %t219, ptr %t212, i64 %t213)
  %t220 = getelementptr i8, ptr %t219, i64 %t213
  call void @olang_textcopy(ptr %t220, ptr %t215, i64 %t216)
  %t221 = insertvalue { i64, ptr } undef, i64 %t217, 0
  %t222 = insertvalue { i64, ptr } %t221, ptr %t218, 1
  %t224 = extractvalue { i64, ptr } %t222, 0
  %t225 = extractvalue { i64, ptr } %t222, 1
  %t226 = mul i64 %t224, 1
  %t227 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t226)
  call void @llvm.memcpy.p0.p0.i64(ptr %t227, ptr %t225, i64 %t226, i1 false)
  %t228 = insertvalue { i64, ptr } undef, i64 %t224, 0
  %t229 = insertvalue { i64, ptr } %t228, ptr %t227, 1
  %t230 = load ptr, ptr %l110, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t230, { i64, ptr } %t229)
  br label %bb43
bb43:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l4, { i64, ptr } { i64 44, ptr getelementptr inbounds (<{ i64, [44 x i8] }>, ptr @.d119, i32 0, i32 1) })
  br label %bb44
bb44:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l4, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d120, i32 0, i32 1) })
  br label %bb45
bb45:
  %t234 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s0, ptr %s0, ptr %t234, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d121, i32 0, i32 1) }, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d122, i32 0, i32 1) })
  br label %bb46
bb46:
  %t236 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edefine(ptr %v0, ptr %s0, ptr %s0, ptr %t236, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d123, i32 0, i32 1) }, { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d124, i32 0, i32 1) })
  br label %bb47
bb47:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l4, { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d125, i32 0, i32 1) })
  br label %bb48
bb48:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d126, i32 0, i32 1) }, ptr %l121, !tbaa !27
  %t239 = load { i64, ptr }, ptr %l121, !tbaa !27
  store { i64, ptr } %t239, ptr %l122, !tbaa !27
  %t240 = getelementptr { i64, ptr }, ptr %l122, i32 0, i32 1
  %t241 = load ptr, ptr %t240, !tbaa !27
  %t242 = mul i64 3, 1
  call void @llvm.memmove.p0.p0.i64(ptr %l123, ptr %t241, i64 %t242, i1 false)
  %t244 = insertvalue { i64, ptr } undef, i64 3, 0
  %t245 = insertvalue { i64, ptr } %t244, ptr %l123, 1
  store { i64, ptr } %t245, ptr %l11, !tbaa !27
  store ptr %l4, ptr %l126, !tbaa !29
  %t247 = load ptr, ptr %l0, !tbaa !29
  %t249 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecstr(ptr %v0, ptr %s0, ptr %s0, ptr %t247, { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d127, i32 0, i32 1) })
  store { i64, ptr } %t249, ptr %l128
  br label %bb49
bb49:
  %t250 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d128, i32 0, i32 1) }, 1
  %t251 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d128, i32 0, i32 1) }, 0
  %t252 = load { i64, ptr }, ptr %l128, !tbaa !27
  %t253 = extractvalue { i64, ptr } %t252, 1
  %t254 = extractvalue { i64, ptr } %t252, 0
  %t255 = add i64 %t251, %t254
  %t256 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d129, i32 0, i32 1) }, 1
  %t257 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d129, i32 0, i32 1) }, 0
  %t258 = add i64 %t255, %t257
  %t259 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t258)
  call void @olang_textcopy(ptr %t259, ptr %t250, i64 %t251)
  %t260 = getelementptr i8, ptr %t259, i64 %t251
  call void @olang_textcopy(ptr %t260, ptr %t253, i64 %t254)
  %t261 = getelementptr i8, ptr %t260, i64 %t254
  call void @olang_textcopy(ptr %t261, ptr %t256, i64 %t257)
  %t262 = insertvalue { i64, ptr } undef, i64 %t258, 0
  %t263 = insertvalue { i64, ptr } %t262, ptr %t259, 1
  %t265 = extractvalue { i64, ptr } %t263, 0
  %t266 = extractvalue { i64, ptr } %t263, 1
  %t267 = mul i64 %t265, 1
  %t268 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t267)
  call void @llvm.memcpy.p0.p0.i64(ptr %t268, ptr %t266, i64 %t267, i1 false)
  %t269 = insertvalue { i64, ptr } undef, i64 %t265, 0
  %t270 = insertvalue { i64, ptr } %t269, ptr %t268, 1
  %t271 = load ptr, ptr %l126, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t271, { i64, ptr } %t270)
  br label %bb50
bb50:
  store i64 0, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  %t273 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t275 = extractvalue { i64, ptr } %t273, 0
  store i64 %t275, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t277 = load i64, ptr %l14, !tbaa !24
  %t278 = load i64, ptr %l13, !tbaa !24
  %t281 = icmp sgt i64 %t277, %t278
  br i1 %t281, label %bb51, label %bb52
bb51:
  %t283 = load i64, ptr %l15, !tbaa !24
  %t285 = icmp sgt i64 %t283, 0
  br i1 %t285, label %bb53, label %bb54
bb52:
  store i64 0, ptr %l136, !tbaa !24
  br label %bb56
bb53:
  %t287 = load i64, ptr %l14, !tbaa !24
  %t288 = load i64, ptr %l13, !tbaa !24
  %t291 = sub i64 %t287, %t288
  %t292 = load i64, ptr %l15, !tbaa !24
  %t295 = add i64 %t291, %t292
  %t297 = sub i64 %t295, 1
  %t298 = load i64, ptr %l15, !tbaa !24
  %t301 = sdiv i64 %t297, %t298
  store i64 %t301, ptr %l139, !tbaa !24
  br label %bb55
bb54:
  store i64 0, ptr %l139, !tbaa !24
  br label %bb55
bb55:
  %t303 = load i64, ptr %l139, !tbaa !24
  store i64 %t303, ptr %l136, !tbaa !24
  br label %bb56
bb56:
  %t304 = load i64, ptr %l136, !tbaa !24
  store i64 %t304, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb57
bb57:
  store %olang.scope zeroinitializer, ptr %s12
  %t305 = load i64, ptr %l17, !tbaa !24
  %t306 = load i64, ptr %l16, !tbaa !24
  %t309 = icmp slt i64 %t305, %t306
  %t311 = xor i1 %t309, true
  br i1 %t311, label %bb58, label %bb59
bb58:
  call void @__olang_scope_close(ptr %s12)
  br label %bb86
bb59:
  br label %bb60
bb60:
  %t313 = load i64, ptr %l13, !tbaa !24
  %t314 = load i64, ptr %l17, !tbaa !24
  %t315 = load i64, ptr %l15, !tbaa !24
  %t318 = mul i64 %t314, %t315
  %t321 = add i64 %t313, %t318
  store i64 %t321, ptr %l18, !tbaa !24
  %t323 = load ptr, ptr %l3, !tbaa !29
  %t324 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t324, ptr %l158, !tbaa !27
  %t325 = load i64, ptr %l18, !tbaa !24
  %t327 = getelementptr { i64, ptr }, ptr %l158, i32 0, i32 1
  %t328 = load ptr, ptr %t327, !tbaa !27
  %t329 = getelementptr i32, ptr %t328, i64 %t325
  %t330 = load i32, ptr %t329, !tbaa !33
  %t333 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t323, i32 %t330)
  store i32 %t333, ptr %l161
  br label %bb61
bb61:
  %t334 = load i32, ptr %l161, !tbaa !23
  store i32 %t334, ptr %l19, !tbaa !23
  %t335 = load ptr, ptr %l0, !tbaa !29
  %t337 = getelementptr %"compiler/emit:Emitter", ptr %t335, i32 0, i32 0
  %t338 = load ptr, ptr %t337, !tbaa !29
  store ptr %t338, ptr %l163, !tbaa !29
  %t339 = load ptr, ptr %l3, !tbaa !29
  %t340 = load i32, ptr %l19, !tbaa !23
  %t343 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t339, i32 %t340)
  store i32 %t343, ptr %l166
  br label %bb62
bb62:
  %t344 = load ptr, ptr %l163, !tbaa !29
  %t345 = load i32, ptr %l166, !tbaa !23
  %t346 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorWords(ptr %v0, ptr %s12, ptr %t344, i32 %t345)
  store { i64, ptr } %t346, ptr %l167
  br label %bb63
bb63:
  %t347 = load { i64, ptr }, ptr %l167, !tbaa !27
  store i64 0, ptr %l21, !tbaa !24
  %t350 = extractvalue { i64, ptr } %t347, 0
  store i64 %t350, ptr %l22, !tbaa !24
  store i64 1, ptr %l23, !tbaa !24
  %t352 = load i64, ptr %l22, !tbaa !24
  %t353 = load i64, ptr %l21, !tbaa !24
  %t356 = icmp sgt i64 %t352, %t353
  br i1 %t356, label %bb64, label %bb65
bb64:
  %t358 = load i64, ptr %l23, !tbaa !24
  %t360 = icmp sgt i64 %t358, 0
  br i1 %t360, label %bb66, label %bb67
bb65:
  store i64 0, ptr %l173, !tbaa !24
  br label %bb69
bb66:
  %t362 = load i64, ptr %l22, !tbaa !24
  %t363 = load i64, ptr %l21, !tbaa !24
  %t366 = sub i64 %t362, %t363
  %t367 = load i64, ptr %l23, !tbaa !24
  %t370 = add i64 %t366, %t367
  %t372 = sub i64 %t370, 1
  %t373 = load i64, ptr %l23, !tbaa !24
  %t376 = sdiv i64 %t372, %t373
  store i64 %t376, ptr %l176, !tbaa !24
  br label %bb68
bb67:
  store i64 0, ptr %l176, !tbaa !24
  br label %bb68
bb68:
  %t378 = load i64, ptr %l176, !tbaa !24
  store i64 %t378, ptr %l173, !tbaa !24
  br label %bb69
bb69:
  %t379 = load i64, ptr %l173, !tbaa !24
  store i64 %t379, ptr %l24, !tbaa !24
  store i64 0, ptr %l25, !tbaa !24
  br label %bb70
bb70:
  store %olang.scope zeroinitializer, ptr %s14
  %t380 = load i64, ptr %l25, !tbaa !24
  %t381 = load i64, ptr %l24, !tbaa !24
  %t384 = icmp slt i64 %t380, %t381
  %t386 = xor i1 %t384, true
  br i1 %t386, label %bb71, label %bb72
bb71:
  call void @__olang_scope_close(ptr %s14)
  br label %bb84
bb72:
  br label %bb73
bb73:
  %t388 = load i64, ptr %l21, !tbaa !24
  %t389 = load i64, ptr %l25, !tbaa !24
  %t390 = load i64, ptr %l23, !tbaa !24
  %t393 = mul i64 %t389, %t390
  %t396 = add i64 %t388, %t393
  store i64 %t396, ptr %l26, !tbaa !24
  %t398 = load i64, ptr %l12, !tbaa !24
  %t400 = add i64 %t398, 1
  store i64 %t400, ptr %l12, !tbaa !24
  %t402 = load i64, ptr %l18, !tbaa !24
  %t404 = add i64 %t402, 1
  %t406 = shl i64 %t404, 16
  %t407 = load i64, ptr %l26, !tbaa !24
  %t410 = or i64 %t406, %t407
  store i64 %t410, ptr %l27, !tbaa !24
  %t412 = load ptr, ptr %l0, !tbaa !29
  %t413 = load i32, ptr %l19, !tbaa !23
  %t416 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eerrQualifier(ptr %v0, ptr %s14, ptr %t412, i32 %t413)
  store { i64, ptr } %t416, ptr %l203
  br label %bb74
bb74:
  %t417 = load ptr, ptr %l0, !tbaa !29
  %t419 = getelementptr %"compiler/emit:Emitter", ptr %t417, i32 0, i32 0
  %t420 = load ptr, ptr %t419, !tbaa !29
  store ptr %t420, ptr %l205, !tbaa !29
  %t421 = load ptr, ptr %l3, !tbaa !29
  %t422 = load i32, ptr %l19, !tbaa !23
  %t425 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t421, i32 %t422)
  store i32 %t425, ptr %l208
  br label %bb75
bb75:
  %t426 = load i64, ptr %l26, !tbaa !24
  %t427 = load ptr, ptr %l205, !tbaa !29
  %t428 = load i32, ptr %l208, !tbaa !23
  %t430 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorWordName(ptr %v0, ptr %s14, ptr %t427, i32 %t428, i64 %t426)
  store { i64, ptr } %t430, ptr %l210
  br label %bb76
bb76:
  %t431 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d130, i32 0, i32 1) }, 1
  %t432 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d130, i32 0, i32 1) }, 0
  %t433 = load { i64, ptr }, ptr %l203, !tbaa !27
  %t434 = extractvalue { i64, ptr } %t433, 1
  %t435 = extractvalue { i64, ptr } %t433, 0
  %t436 = add i64 %t432, %t435
  %t437 = load { i64, ptr }, ptr %l210, !tbaa !27
  %t438 = extractvalue { i64, ptr } %t437, 1
  %t439 = extractvalue { i64, ptr } %t437, 0
  %t440 = add i64 %t436, %t439
  %t441 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d131, i32 0, i32 1) }, 1
  %t442 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d131, i32 0, i32 1) }, 0
  %t443 = add i64 %t440, %t442
  %t444 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t443)
  call void @olang_textcopy(ptr %t444, ptr %t431, i64 %t432)
  %t445 = getelementptr i8, ptr %t444, i64 %t432
  call void @olang_textcopy(ptr %t445, ptr %t434, i64 %t435)
  %t446 = getelementptr i8, ptr %t445, i64 %t435
  call void @olang_textcopy(ptr %t446, ptr %t438, i64 %t439)
  %t447 = getelementptr i8, ptr %t446, i64 %t439
  call void @olang_textcopy(ptr %t447, ptr %t441, i64 %t442)
  %t448 = insertvalue { i64, ptr } undef, i64 %t443, 0
  %t449 = insertvalue { i64, ptr } %t448, ptr %t444, 1
  store { i64, ptr } %t449, ptr %l28, !tbaa !27
  %t451 = load i64, ptr %l12, !tbaa !24
  %t452 = load i64, ptr %l27, !tbaa !24
  %t453 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d132, i32 0, i32 1) }, 1
  %t454 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d132, i32 0, i32 1) }, 0
  %t456 = call i64 @__olang_fmt_i64(ptr null, i64 %t451)
  %t457 = add i64 %t454, %t456
  %t458 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d133, i32 0, i32 1) }, 1
  %t459 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d133, i32 0, i32 1) }, 0
  %t460 = add i64 %t457, %t459
  %t462 = call i64 @__olang_fmt_i64(ptr null, i64 %t452)
  %t463 = add i64 %t460, %t462
  %t464 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d134, i32 0, i32 1) }, 1
  %t465 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d134, i32 0, i32 1) }, 0
  %t466 = add i64 %t463, %t465
  %t467 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t466)
  call void @olang_textcopy(ptr %t467, ptr %t453, i64 %t454)
  %t468 = getelementptr i8, ptr %t467, i64 %t454
  %t469 = call i64 @__olang_fmt_i64(ptr %t468, i64 %t451)
  %t470 = getelementptr i8, ptr %t468, i64 %t456
  call void @olang_textcopy(ptr %t470, ptr %t458, i64 %t459)
  %t471 = getelementptr i8, ptr %t470, i64 %t459
  %t472 = call i64 @__olang_fmt_i64(ptr %t471, i64 %t452)
  %t473 = getelementptr i8, ptr %t471, i64 %t462
  call void @olang_textcopy(ptr %t473, ptr %t464, i64 %t465)
  %t474 = insertvalue { i64, ptr } undef, i64 %t466, 0
  %t475 = insertvalue { i64, ptr } %t474, ptr %t467, 1
  %t477 = extractvalue { i64, ptr } %t475, 0
  %t478 = extractvalue { i64, ptr } %t475, 1
  %t479 = mul i64 %t477, 1
  %t480 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t479)
  call void @llvm.memcpy.p0.p0.i64(ptr %t480, ptr %t478, i64 %t479, i1 false)
  %t481 = insertvalue { i64, ptr } undef, i64 %t477, 0
  %t482 = insertvalue { i64, ptr } %t481, ptr %t480, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s14, ptr %l4, { i64, ptr } %t482)
  br label %bb77
bb77:
  store ptr %l4, ptr %l217, !tbaa !29
  %t485 = load i64, ptr %l12, !tbaa !24
  store i64 %t485, ptr %l218, !tbaa !24
  %t486 = load i64, ptr %l12, !tbaa !24
  store i64 %t486, ptr %l219, !tbaa !24
  %t487 = load ptr, ptr %l0, !tbaa !29
  %t488 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t491 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecstr(ptr %v0, ptr %s14, ptr %s14, ptr %t487, { i64, ptr } %t488)
  store { i64, ptr } %t491, ptr %l222
  br label %bb78
bb78:
  %t492 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t493 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d135, i32 0, i32 1) }, 1
  %t494 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d135, i32 0, i32 1) }, 0
  %t495 = load i64, ptr %l218, !tbaa !24
  %t496 = call i64 @__olang_fmt_i64(ptr null, i64 %t495)
  %t497 = add i64 %t494, %t496
  %t498 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d136, i32 0, i32 1) }, 1
  %t499 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d136, i32 0, i32 1) }, 0
  %t500 = add i64 %t497, %t499
  %t501 = load i64, ptr %l219, !tbaa !24
  %t502 = call i64 @__olang_fmt_i64(ptr null, i64 %t501)
  %t503 = add i64 %t500, %t502
  %t504 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d137, i32 0, i32 1) }, 1
  %t505 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d137, i32 0, i32 1) }, 0
  %t506 = add i64 %t503, %t505
  %t507 = load { i64, ptr }, ptr %l222, !tbaa !27
  %t508 = extractvalue { i64, ptr } %t507, 1
  %t509 = extractvalue { i64, ptr } %t507, 0
  %t510 = add i64 %t506, %t509
  %t511 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d137, i32 0, i32 1) }, 1
  %t512 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d137, i32 0, i32 1) }, 0
  %t513 = add i64 %t510, %t512
  %t515 = extractvalue { i64, ptr } %t492, 1
  %t516 = extractvalue { i64, ptr } %t492, 0
  %t517 = add i64 %t513, %t516
  %t518 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d138, i32 0, i32 1) }, 1
  %t519 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d138, i32 0, i32 1) }, 0
  %t520 = add i64 %t517, %t519
  %t521 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t520)
  call void @olang_textcopy(ptr %t521, ptr %t493, i64 %t494)
  %t522 = getelementptr i8, ptr %t521, i64 %t494
  %t523 = call i64 @__olang_fmt_i64(ptr %t522, i64 %t495)
  %t524 = getelementptr i8, ptr %t522, i64 %t496
  call void @olang_textcopy(ptr %t524, ptr %t498, i64 %t499)
  %t525 = getelementptr i8, ptr %t524, i64 %t499
  %t526 = call i64 @__olang_fmt_i64(ptr %t525, i64 %t501)
  %t527 = getelementptr i8, ptr %t525, i64 %t502
  call void @olang_textcopy(ptr %t527, ptr %t504, i64 %t505)
  %t528 = getelementptr i8, ptr %t527, i64 %t505
  call void @olang_textcopy(ptr %t528, ptr %t508, i64 %t509)
  %t529 = getelementptr i8, ptr %t528, i64 %t509
  call void @olang_textcopy(ptr %t529, ptr %t511, i64 %t512)
  %t530 = getelementptr i8, ptr %t529, i64 %t512
  call void @olang_textcopy(ptr %t530, ptr %t515, i64 %t516)
  %t531 = getelementptr i8, ptr %t530, i64 %t516
  call void @olang_textcopy(ptr %t531, ptr %t518, i64 %t519)
  %t532 = insertvalue { i64, ptr } undef, i64 %t520, 0
  %t533 = insertvalue { i64, ptr } %t532, ptr %t521, 1
  %t535 = extractvalue { i64, ptr } %t533, 0
  %t536 = extractvalue { i64, ptr } %t533, 1
  %t537 = mul i64 %t535, 1
  %t538 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t537)
  call void @llvm.memcpy.p0.p0.i64(ptr %t538, ptr %t536, i64 %t537, i1 false)
  %t539 = insertvalue { i64, ptr } undef, i64 %t535, 0
  %t540 = insertvalue { i64, ptr } %t539, ptr %t538, 1
  %t541 = load ptr, ptr %l217, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s14, ptr %t541, { i64, ptr } %t540)
  br label %bb79
bb79:
  %t543 = load i64, ptr %l12, !tbaa !24
  %t544 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d139, i32 0, i32 1) }, 1
  %t545 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d139, i32 0, i32 1) }, 0
  %t547 = call i64 @__olang_fmt_i64(ptr null, i64 %t543)
  %t548 = add i64 %t545, %t547
  %t549 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t548)
  call void @olang_textcopy(ptr %t549, ptr %t544, i64 %t545)
  %t550 = getelementptr i8, ptr %t549, i64 %t545
  %t551 = call i64 @__olang_fmt_i64(ptr %t550, i64 %t543)
  %t552 = insertvalue { i64, ptr } undef, i64 %t548, 0
  %t553 = insertvalue { i64, ptr } %t552, ptr %t549, 1
  store { i64, ptr } %t553, ptr %l227, !tbaa !27
  %t554 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t555 = extractvalue { i64, ptr } %t554, 0
  %t556 = load { i64, ptr }, ptr %l227, !tbaa !27
  %t557 = extractvalue { i64, ptr } %t556, 0
  store i64 %t557, ptr %l229, !tbaa !24
  %t559 = load i64, ptr %l229, !tbaa !24
  %t560 = icmp eq i64 %t555, %t559
  br i1 %t560, label %bb80, label %bb81
bb80:
  %t562 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t563 = load ptr, ptr %t562, !tbaa !27
  %t564 = getelementptr { i64, ptr }, ptr %l227, i32 0, i32 1
  %t565 = load ptr, ptr %t564, !tbaa !27
  %t566 = load i64, ptr %l229, !tbaa !24
  %t567 = mul i64 %t566, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t563, ptr %t565, i64 %t567, i1 false)
  br label %bb82
bb81:
  %t568 = load { i64, ptr }, ptr %l227, !tbaa !27
  store { i64, ptr } %t568, ptr %l11, !tbaa !27
  br label %bb82
bb82:
  call void @__olang_scope_close(ptr %s14)
  br label %bb83
bb83:
  %t569 = load i64, ptr %l25, !tbaa !24
  %t571 = add i64 %t569, 1
  store i64 %t571, ptr %l25, !tbaa !24
  br label %bb70
bb84:
  call void @__olang_scope_close(ptr %s12)
  br label %bb85
bb85:
  %t573 = load i64, ptr %l17, !tbaa !24
  %t575 = add i64 %t573, 1
  store i64 %t575, ptr %l17, !tbaa !24
  br label %bb57
bb86:
  %t577 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t578 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d140, i32 0, i32 1) }, 1
  %t579 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d140, i32 0, i32 1) }, 0
  %t581 = extractvalue { i64, ptr } %t577, 1
  %t582 = extractvalue { i64, ptr } %t577, 0
  %t583 = add i64 %t579, %t582
  %t584 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d141, i32 0, i32 1) }, 1
  %t585 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d141, i32 0, i32 1) }, 0
  %t586 = add i64 %t583, %t585
  %t587 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t586)
  call void @olang_textcopy(ptr %t587, ptr %t578, i64 %t579)
  %t588 = getelementptr i8, ptr %t587, i64 %t579
  call void @olang_textcopy(ptr %t588, ptr %t581, i64 %t582)
  %t589 = getelementptr i8, ptr %t588, i64 %t582
  call void @olang_textcopy(ptr %t589, ptr %t584, i64 %t585)
  %t590 = insertvalue { i64, ptr } undef, i64 %t586, 0
  %t591 = insertvalue { i64, ptr } %t590, ptr %t587, 1
  %t593 = extractvalue { i64, ptr } %t591, 0
  %t594 = extractvalue { i64, ptr } %t591, 1
  %t595 = mul i64 %t593, 1
  %t596 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t595)
  call void @llvm.memcpy.p0.p0.i64(ptr %t596, ptr %t594, i64 %t595, i1 false)
  %t597 = insertvalue { i64, ptr } undef, i64 %t593, 0
  %t598 = insertvalue { i64, ptr } %t597, ptr %t596, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l4, { i64, ptr } %t598)
  br label %bb87
bb87:
  %t601 = load ptr, ptr %l0, !tbaa !29
  %t603 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2etraced(ptr %v0, ptr %t601)
  store i1 %t603, ptr %l240
  br label %bb88
bb88:
  %t604 = load i1, ptr %l240, !tbaa !21
  br i1 %t604, label %bb89, label %bb90
bb89:
  store %olang.scope zeroinitializer, ptr %s22
  %t605 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s22, ptr %s22, ptr %t605, { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d142, i32 0, i32 1) }, { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d143, i32 0, i32 1) })
  br label %bb91
bb90:
  store %olang.scope zeroinitializer, ptr %s23
  %t607 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s23, ptr %s23, ptr %t607, { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d144, i32 0, i32 1) }, { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d145, i32 0, i32 1) })
  br label %bb93
bb91:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s22, ptr %l4, { i64, ptr } { i64 86, ptr getelementptr inbounds (<{ i64, [86 x i8] }>, ptr @.d146, i32 0, i32 1) })
  br label %bb92
bb92:
  call void @__olang_scope_close(ptr %s22)
  br label %bb95
bb93:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s23, ptr %l4, { i64, ptr } { i64 87, ptr getelementptr inbounds (<{ i64, [87 x i8] }>, ptr @.d147, i32 0, i32 1) })
  br label %bb94
bb94:
  call void @__olang_scope_close(ptr %s23)
  br label %bb95
bb95:
  %t611 = load ptr, ptr %l0, !tbaa !29
  store ptr %t611, ptr %l245, !tbaa !29
  %t612 = load ptr, ptr %l0, !tbaa !29
  %t614 = getelementptr %"compiler/emit:Emitter", ptr %t612, i32 0, i32 0
  %t615 = load ptr, ptr %t614, !tbaa !29
  %t617 = getelementptr %"compiler/generic:Program", ptr %t615, i32 0, i32 0
  %t618 = load ptr, ptr %t617, !tbaa !29
  %t620 = getelementptr %"compiler/load:Loader", ptr %t618, i32 0, i32 12
  %t621 = load i64, ptr %t620, !tbaa !24
  store i64 %t621, ptr %l249, !tbaa !24
  %t623 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l4)
  store { i64, ptr } %t623, ptr %l251
  br label %bb96
bb96:
  %t624 = load { i64, ptr }, ptr %l251, !tbaa !27
  %t625 = extractvalue { i64, ptr } %t624, 0
  %t626 = extractvalue { i64, ptr } %t624, 1
  %t627 = mul i64 %t625, 1
  %t628 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t627)
  call void @llvm.memcpy.p0.p0.i64(ptr %t628, ptr %t626, i64 %t627, i1 false)
  %t629 = insertvalue { i64, ptr } undef, i64 %t625, 0
  %t630 = insertvalue { i64, ptr } %t629, ptr %t628, 1
  %t631 = load ptr, ptr %l245, !tbaa !29
  %t632 = load i64, ptr %l249, !tbaa !24
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eitem(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %t631, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d148, i32 0, i32 1) }, i64 %t632, { i64, ptr } %t630, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d116, i32 0, i32 1) })
  br label %bb97
bb97:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eextern(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %lp3 = alloca ptr
  %lp4 = alloca ptr
  %l5 = alloca %"std/prelude/text:StringBuilder"
  %l9 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l15 = alloca i1
  %l19 = alloca i1
  %l21 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l35 = alloca i1
  %l37 = alloca %"std/prelude/text:StringBuilder"
  %l38 = alloca ptr
  %l41 = alloca { i64, ptr }
  %l45 = alloca ptr
  %l46 = alloca ptr
  %l47 = alloca i32
  %l49 = alloca i1
  %l50 = alloca { i64, ptr }
  %l55 = alloca ptr
  %l59 = alloca ptr
  %l61 = alloca ptr
  %l65 = alloca i32
  %l66 = alloca { i64, ptr }
  %l69 = alloca { i64, ptr }
  %l73 = alloca i1
  %l74 = alloca i1
  %l77 = alloca { i64, ptr }
  %l79 = alloca i1
  %l82 = alloca ptr
  %l83 = alloca { i64, ptr }
  %l85 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i64, ptr %l1, !tbaa !24
  %t8 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eExternSymbol(ptr %v0, ptr %v1, ptr %t4, i64 %t5)
  store { i64, ptr } %t8, ptr %l9
  br label %bb1
bb1:
  %t9 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t9, ptr %lp3
  %t10 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t11 = load ptr, ptr %lp3
  store { i64, ptr } %t10, ptr %t11, !tbaa !27
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load ptr, ptr %lp3
  %t14 = load { i64, ptr }, ptr %t13, !tbaa !27
  %t15 = load i32, ptr %l2, !tbaa !23
  %t19 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2emathIntrinsic(ptr %v0, ptr %v1, ptr %v1, ptr %t12, { i64, ptr } %t14, i32 %t15)
  store { i64, ptr } %t19, ptr %l13
  br label %bb2
bb2:
  %t20 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t20, ptr %lp4
  %t21 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t22 = load ptr, ptr %lp4
  store { i64, ptr } %t21, ptr %t22, !tbaa !27
  %t23 = load ptr, ptr %lp4
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  %t26 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t24, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d149, i32 0, i32 1) })
  store i1 %t26, ptr %l15
  br label %bb3
bb3:
  %t27 = load i1, ptr %l15, !tbaa !21
  %t28 = xor i1 %t27, true
  br i1 %t28, label %bb4, label %bb5
bb4:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load ptr, ptr %lp4
  %t32 = load { i64, ptr }, ptr %t31, !tbaa !27
  %t35 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ehas(ptr %v0, ptr %v1, ptr %t30, { i64, ptr } %t32)
  store i1 %t35, ptr %l19
  br label %bb6
bb5:
  br label %bb13
bb6:
  %t36 = load i1, ptr %l19, !tbaa !21
  %t37 = xor i1 %t36, true
  br i1 %t37, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t39 = load ptr, ptr %l0, !tbaa !29
  store ptr %t39, ptr %l21, !tbaa !29
  %t40 = load ptr, ptr %lp4
  %t41 = load { i64, ptr }, ptr %t40, !tbaa !27
  store { i64, ptr } %t41, ptr %l22, !tbaa !27
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load i32, ptr %l2, !tbaa !23
  %t46 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eexternRet(ptr %v0, ptr %s2, ptr %t42, i32 %t43)
  store { i64, ptr } %t46, ptr %l25
  br label %bb9
bb8:
  br label %bb12
bb9:
  %t47 = load ptr, ptr %lp4
  %t48 = load { i64, ptr }, ptr %t47, !tbaa !27
  store { i64, ptr } %t48, ptr %l26, !tbaa !27
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load i32, ptr %l2, !tbaa !23
  %t53 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2emathParams(ptr %v0, ptr %s2, ptr %t49, i32 %t50)
  store { i64, ptr } %t53, ptr %l29
  br label %bb10
bb10:
  %t54 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t55 = extractvalue { i64, ptr } %t54, 1
  %t56 = extractvalue { i64, ptr } %t54, 0
  %t57 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d150, i32 0, i32 1) }, 1
  %t58 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d150, i32 0, i32 1) }, 0
  %t59 = add i64 %t56, %t58
  %t60 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t61 = extractvalue { i64, ptr } %t60, 1
  %t62 = extractvalue { i64, ptr } %t60, 0
  %t63 = add i64 %t59, %t62
  %t64 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d151, i32 0, i32 1) }, 1
  %t65 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d151, i32 0, i32 1) }, 0
  %t66 = add i64 %t63, %t65
  %t67 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t68 = extractvalue { i64, ptr } %t67, 1
  %t69 = extractvalue { i64, ptr } %t67, 0
  %t70 = add i64 %t66, %t69
  %t71 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d152, i32 0, i32 1) }, 1
  %t72 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d152, i32 0, i32 1) }, 0
  %t73 = add i64 %t70, %t72
  %t74 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t73)
  call void @olang_textcopy(ptr %t74, ptr %t55, i64 %t56)
  %t75 = getelementptr i8, ptr %t74, i64 %t56
  call void @olang_textcopy(ptr %t75, ptr %t57, i64 %t58)
  %t76 = getelementptr i8, ptr %t75, i64 %t58
  call void @olang_textcopy(ptr %t76, ptr %t61, i64 %t62)
  %t77 = getelementptr i8, ptr %t76, i64 %t62
  call void @olang_textcopy(ptr %t77, ptr %t64, i64 %t65)
  %t78 = getelementptr i8, ptr %t77, i64 %t65
  call void @olang_textcopy(ptr %t78, ptr %t68, i64 %t69)
  %t79 = getelementptr i8, ptr %t78, i64 %t69
  call void @olang_textcopy(ptr %t79, ptr %t71, i64 %t72)
  %t80 = insertvalue { i64, ptr } undef, i64 %t73, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t74, 1
  %t83 = extractvalue { i64, ptr } %t81, 0
  %t84 = extractvalue { i64, ptr } %t81, 1
  %t85 = mul i64 %t83, 1
  %t86 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t85)
  call void @llvm.memcpy.p0.p0.i64(ptr %t86, ptr %t84, i64 %t85, i1 false)
  %t87 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t88 = insertvalue { i64, ptr } %t87, ptr %t86, 1
  %t89 = load ptr, ptr %l21, !tbaa !29
  %t90 = load { i64, ptr }, ptr %l22, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %v1, ptr %s2, ptr %t89, { i64, ptr } %t90, { i64, ptr } %t88)
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s2)
  br label %bb12
bb12:
  %t92 = load ptr, ptr %lp4
  %t93 = load { i64, ptr }, ptr %t92, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t93, ptr %rv
  br label %ret
bb13:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t96 = load ptr, ptr %lp3
  %t97 = load { i64, ptr }, ptr %t96, !tbaa !27
  %t100 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ehas(ptr %v0, ptr %v1, ptr %t95, { i64, ptr } %t97)
  store i1 %t100, ptr %l35
  br label %bb14
bb14:
  %t101 = load i1, ptr %l35, !tbaa !21
  br i1 %t101, label %bb15, label %bb16
bb15:
  %t102 = load ptr, ptr %lp3
  %t103 = load { i64, ptr }, ptr %t102, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t103, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t105 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t105, ptr %l37
  br label %bb18
bb18:
  %t106 = load %"std/prelude/text:StringBuilder", ptr %l37
  store %"std/prelude/text:StringBuilder" %t106, ptr %l5
  store ptr %l5, ptr %l38, !tbaa !29
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t108 = load i32, ptr %l2, !tbaa !23
  %t111 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecHeader(ptr %v0, ptr %s0, ptr %t107, i32 %t108)
  store { i64, ptr } %t111, ptr %l41
  br label %bb19
bb19:
  %t112 = load ptr, ptr %lp3
  %t113 = load { i64, ptr }, ptr %t112, !tbaa !27
  %t114 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t115 = extractvalue { i64, ptr } %t114, 1
  %t116 = extractvalue { i64, ptr } %t114, 0
  %t117 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d153, i32 0, i32 1) }, 1
  %t118 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d153, i32 0, i32 1) }, 0
  %t119 = add i64 %t116, %t118
  %t121 = extractvalue { i64, ptr } %t113, 1
  %t122 = extractvalue { i64, ptr } %t113, 0
  %t123 = add i64 %t119, %t122
  %t124 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d154, i32 0, i32 1) }, 1
  %t125 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d154, i32 0, i32 1) }, 0
  %t126 = add i64 %t123, %t125
  %t127 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t126)
  call void @olang_textcopy(ptr %t127, ptr %t115, i64 %t116)
  %t128 = getelementptr i8, ptr %t127, i64 %t116
  call void @olang_textcopy(ptr %t128, ptr %t117, i64 %t118)
  %t129 = getelementptr i8, ptr %t128, i64 %t118
  call void @olang_textcopy(ptr %t129, ptr %t121, i64 %t122)
  %t130 = getelementptr i8, ptr %t129, i64 %t122
  call void @olang_textcopy(ptr %t130, ptr %t124, i64 %t125)
  %t131 = insertvalue { i64, ptr } undef, i64 %t126, 0
  %t132 = insertvalue { i64, ptr } %t131, ptr %t127, 1
  %t134 = extractvalue { i64, ptr } %t132, 0
  %t135 = extractvalue { i64, ptr } %t132, 1
  %t136 = mul i64 %t134, 1
  %t137 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t136)
  call void @llvm.memcpy.p0.p0.i64(ptr %t137, ptr %t135, i64 %t136, i1 false)
  %t138 = insertvalue { i64, ptr } undef, i64 %t134, 0
  %t139 = insertvalue { i64, ptr } %t138, ptr %t137, 1
  %t140 = load ptr, ptr %l38, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t140, { i64, ptr } %t139)
  br label %bb20
bb20:
  store ptr %l5, ptr %l45, !tbaa !29
  %t142 = load ptr, ptr %l0, !tbaa !29
  store ptr %t142, ptr %l46, !tbaa !29
  %t143 = load i32, ptr %l2, !tbaa !23
  store i32 %t143, ptr %l47, !tbaa !23
  %t144 = load ptr, ptr %lp3
  %t145 = load { i64, ptr }, ptr %t144, !tbaa !27
  %t147 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s0, { i64, ptr } %t145, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d155, i32 0, i32 1) })
  store i1 %t147, ptr %l49
  br label %bb21
bb21:
  %t148 = load ptr, ptr %l46, !tbaa !29
  %t149 = load i32, ptr %l47, !tbaa !23
  %t150 = load i1, ptr %l49, !tbaa !21
  %t151 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecParamList(ptr %v0, ptr %s0, ptr %t148, i32 %t149, i1 %t150)
  store { i64, ptr } %t151, ptr %l50
  br label %bb22
bb22:
  %t152 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t153 = extractvalue { i64, ptr } %t152, 0
  %t154 = extractvalue { i64, ptr } %t152, 1
  %t155 = mul i64 %t153, 1
  %t156 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t155)
  call void @llvm.memcpy.p0.p0.i64(ptr %t156, ptr %t154, i64 %t155, i1 false)
  %t157 = insertvalue { i64, ptr } undef, i64 %t153, 0
  %t158 = insertvalue { i64, ptr } %t157, ptr %t156, 1
  %t159 = load ptr, ptr %l45, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t159, { i64, ptr } %t158)
  br label %bb23
bb23:
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t163 = getelementptr %"compiler/emit:Emitter", ptr %t161, i32 0, i32 0
  %t164 = load ptr, ptr %t163, !tbaa !29
  %t165 = load i64, ptr %l1, !tbaa !24
  %t168 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %s0, ptr %t164, i64 %t165)
  store ptr %t168, ptr %l55
  br label %bb24
bb24:
  %t169 = load ptr, ptr %l55, !tbaa !29
  %t171 = getelementptr %"compiler/ast:Func", ptr %t169, i32 0, i32 3
  %t172 = load ptr, ptr %t171, !tbaa !29
  %t174 = getelementptr %"compiler/ast:Sig", ptr %t172, i32 0, i32 7
  %t175 = load i1, ptr %t174, !tbaa !21
  br i1 %t175, label %bb25, label %bb26
bb25:
  store %olang.scope zeroinitializer, ptr %s6
  store ptr %l5, ptr %l59, !tbaa !29
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t179 = getelementptr %"compiler/emit:Emitter", ptr %t177, i32 0, i32 3
  %t180 = load ptr, ptr %t179, !tbaa !29
  store ptr %t180, ptr %l61, !tbaa !29
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t183 = getelementptr %"compiler/emit:Emitter", ptr %t181, i32 0, i32 3
  %t184 = load ptr, ptr %t183, !tbaa !29
  %t185 = load i32, ptr %l2, !tbaa !23
  %t188 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t184, i32 %t185)
  store i32 %t188, ptr %l65
  br label %bb27
bb26:
  br label %bb33
bb27:
  %t189 = load ptr, ptr %l61, !tbaa !29
  %t190 = load i32, ptr %l65, !tbaa !23
  %t191 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s6, ptr %t189, i32 %t190)
  store { i64, ptr } %t191, ptr %l66
  br label %bb28
bb28:
  %t192 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t193 = extractvalue { i64, ptr } %t192, 0
  %t195 = icmp sgt i64 %t193, 0
  br i1 %t195, label %bb29, label %bb30
bb29:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d156, i32 0, i32 1) }, ptr %l69, !tbaa !27
  br label %bb31
bb30:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d157, i32 0, i32 1) }, ptr %l69, !tbaa !27
  br label %bb31
bb31:
  %t197 = load ptr, ptr %l59, !tbaa !29
  %t198 = load { i64, ptr }, ptr %l69, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s6, ptr %t197, { i64, ptr } %t198)
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s6)
  br label %bb33
bb33:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l5, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d158, i32 0, i32 1) })
  br label %bb34
bb34:
  %t200 = load ptr, ptr %lp3
  %t201 = load { i64, ptr }, ptr %t200, !tbaa !27
  %t202 = load ptr, ptr @__olang_prog_scope
  %t205 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6b5ccacad8db807339a3579aa8c82ff8(ptr %t202, ptr %v1, ptr @G_2ecompiler_2femit_2emathInexact, { i64, ptr } %t201)
  store i1 %t205, ptr %l73
  br label %bb35
bb35:
  %t206 = load i1, ptr %l73, !tbaa !21
  br i1 %t206, label %bb36, label %bb37
bb36:
  %t207 = load ptr, ptr %l0, !tbaa !29
  %t208 = load i32, ptr %l2, !tbaa !23
  %t211 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2emathParams(ptr %v0, ptr %s0, ptr %t207, i32 %t208)
  store { i64, ptr } %t211, ptr %l77
  br label %bb38
bb37:
  store i1 false, ptr %l74, !tbaa !21
  br label %bb40
bb38:
  %t212 = load { i64, ptr }, ptr %l77, !tbaa !27
  %t213 = extractvalue { i64, ptr } %t212, 0
  %t214 = extractvalue { i64, ptr } %t212, 1
  %t215 = mul i64 %t213, 1
  %t216 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t215)
  call void @llvm.memcpy.p0.p0.i64(ptr %t216, ptr %t214, i64 %t215, i1 false)
  %t217 = insertvalue { i64, ptr } undef, i64 %t213, 0
  %t218 = insertvalue { i64, ptr } %t217, ptr %t216, 1
  %t220 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t218, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d159, i32 0, i32 1) })
  store i1 %t220, ptr %l79
  br label %bb39
bb39:
  %t221 = load i1, ptr %l79, !tbaa !21
  %t222 = xor i1 %t221, true
  store i1 %t222, ptr %l74, !tbaa !21
  br label %bb40
bb40:
  %t224 = load i1, ptr %l74, !tbaa !21
  br i1 %t224, label %bb41, label %bb42
bb41:
  store %olang.scope zeroinitializer, ptr %s7
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s7, ptr %l5, { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d160, i32 0, i32 1) })
  br label %bb43
bb42:
  br label %bb44
bb43:
  call void @__olang_scope_close(ptr %s7)
  br label %bb44
bb44:
  %t226 = load ptr, ptr %l0, !tbaa !29
  store ptr %t226, ptr %l82, !tbaa !29
  %t227 = load ptr, ptr %lp3
  %t228 = load { i64, ptr }, ptr %t227, !tbaa !27
  store { i64, ptr } %t228, ptr %l83, !tbaa !27
  %t230 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l5)
  store { i64, ptr } %t230, ptr %l85
  br label %bb45
bb45:
  %t231 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t232 = extractvalue { i64, ptr } %t231, 0
  %t233 = extractvalue { i64, ptr } %t231, 1
  %t234 = mul i64 %t232, 1
  %t235 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t234)
  call void @llvm.memcpy.p0.p0.i64(ptr %t235, ptr %t233, i64 %t234, i1 false)
  %t236 = insertvalue { i64, ptr } undef, i64 %t232, 0
  %t237 = insertvalue { i64, ptr } %t236, ptr %t235, 1
  %t238 = load ptr, ptr %l82, !tbaa !29
  %t239 = load { i64, ptr }, ptr %l83, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %v1, ptr %s0, ptr %t238, { i64, ptr } %t239, { i64, ptr } %t237)
  br label %bb46
bb46:
  %t241 = load ptr, ptr %lp3
  %t242 = load { i64, ptr }, ptr %t241, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t242, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2efieldNames(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %lp3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca %"compiler/source:Span"
  %l20 = alloca %"compiler/source:Span"
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i32
  %l26 = alloca i64
  %l34 = alloca i64
  %l37 = alloca i64
  %l55 = alloca i64
  %l56 = alloca i64
  %l66 = alloca i32
  %l72 = alloca ptr
  %l76 = alloca i32
  %l77 = alloca ptr
  %l80 = alloca i1
  %l87 = alloca ptr
  %l88 = alloca i1
  %l104 = alloca { i64, ptr }
  %l107 = alloca ptr
  %l108 = alloca i1
  %l112 = alloca i1
  %l134 = alloca { i64, ptr }
  %l140 = alloca i64
  %l141 = alloca i64
  %l145 = alloca { i64, ptr }
  %s13 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t11 = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l2, !tbaa !24
  store i64 %t1, ptr %l26, !tbaa !24
  %t2 = load i64, ptr %l26, !tbaa !24
  %t3 = icmp sge i64 %t2, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i64, ptr %l26, !tbaa !24
  %t6 = icmp sle i64 %t5, 576460752303423487
  br i1 %t6, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_672626b841abebed_e9d6bd273cfd5371)
  unreachable
bb3:
  %t8 = load i64, ptr %l26, !tbaa !24
  %t9 = mul i64 %t8, 16
  %t10 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t9)
  store i64 0, ptr %t11
  br label %fill.12
fill.12:
  %t15 = load i64, ptr %t11
  %t16 = icmp slt i64 %t15, %t8
  br i1 %t16, label %fillb.13, label %filld.14
fillb.13:
  %t17 = getelementptr { i64, ptr }, ptr %t10, i64 %t15
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d161, i32 0, i32 1) }, ptr %t17
  %t18 = add i64 %t15, 1
  store i64 %t18, ptr %t11
  br label %fill.12
filld.14:
  %t19 = insertvalue { i64, ptr } undef, i64 %t8, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t10, 1
  %t21 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t21, ptr %lp3
  %t23 = load ptr, ptr %lp3
  store { i64, ptr } %t20, ptr %t23, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t24 = load i64, ptr %l2, !tbaa !24
  store i64 %t24, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t26 = load i64, ptr %l5, !tbaa !24
  %t27 = load i64, ptr %l4, !tbaa !24
  %t30 = icmp sgt i64 %t26, %t27
  br i1 %t30, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_672626b841abebed_e9d6bd273cfd5371)
  unreachable
bb5:
  %t32 = load i64, ptr %l6, !tbaa !24
  %t34 = icmp sgt i64 %t32, 0
  br i1 %t34, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l34, !tbaa !24
  br label %bb10
bb7:
  %t36 = load i64, ptr %l5, !tbaa !24
  %t37 = load i64, ptr %l4, !tbaa !24
  %t40 = sub i64 %t36, %t37
  %t41 = load i64, ptr %l6, !tbaa !24
  %t44 = add i64 %t40, %t41
  %t46 = sub i64 %t44, 1
  %t47 = load i64, ptr %l6, !tbaa !24
  %t50 = sdiv i64 %t46, %t47
  store i64 %t50, ptr %l37, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l37, !tbaa !24
  br label %bb9
bb9:
  %t52 = load i64, ptr %l37, !tbaa !24
  store i64 %t52, ptr %l34, !tbaa !24
  br label %bb10
bb10:
  %t53 = load i64, ptr %l34, !tbaa !24
  store i64 %t53, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb11
bb11:
  %t54 = load i64, ptr %l8, !tbaa !24
  %t55 = load i64, ptr %l7, !tbaa !24
  %t58 = icmp slt i64 %t54, %t55
  %t60 = xor i1 %t58, true
  br i1 %t60, label %bb12, label %bb13
bb12:
  br label %bb18
bb13:
  br label %bb14
bb14:
  %t62 = load i64, ptr %l4, !tbaa !24
  %t63 = load i64, ptr %l8, !tbaa !24
  %t64 = load i64, ptr %l6, !tbaa !24
  %t67 = mul i64 %t63, %t64
  %t70 = add i64 %t62, %t67
  store i64 %t70, ptr %l9, !tbaa !24
  %t72 = load i64, ptr %l9, !tbaa !24
  store i64 %t72, ptr %l55, !tbaa !24
  %t73 = ptrtoint ptr %v1 to i64
  store i64 %t73, ptr %l56, !tbaa !24
  %t74 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t74, label %bb15, label %bb16
bb15:
  %t76 = call ptr @__olang_region_make(ptr %v1)
  %t77 = ptrtoint ptr %t76 to i64
  store i64 %t77, ptr %l56, !tbaa !24
  br label %bb16
bb16:
  %t78 = load i64, ptr %l9, !tbaa !24
  %t80 = call i64 @__olang_fmt_i64(ptr null, i64 %t78)
  %t81 = load i64, ptr %l56
  %t82 = inttoptr i64 %t81 to ptr
  %t83 = call ptr @__olang_scope_alloc(ptr %t82, i64 %t80)
  %t84 = call i64 @__olang_fmt_i64(ptr %t83, i64 %t78)
  %t85 = insertvalue { i64, ptr } undef, i64 %t80, 0
  %t86 = insertvalue { i64, ptr } %t85, ptr %t83, 1
  %t88 = load i64, ptr %l56
  %t89 = inttoptr i64 %t88 to ptr
  %t90 = extractvalue { i64, ptr } %t86, 0
  %t91 = extractvalue { i64, ptr } %t86, 1
  %t92 = mul i64 %t90, 1
  %t93 = call ptr @__olang_scope_alloc(ptr %t89, i64 %t92)
  call void @llvm.memcpy.p0.p0.i64(ptr %t93, ptr %t91, i64 %t92, i1 false)
  %t94 = insertvalue { i64, ptr } undef, i64 %t90, 0
  %t95 = insertvalue { i64, ptr } %t94, ptr %t93, 1
  %t97 = load ptr, ptr %lp3
  %t98 = load i64, ptr %l55, !tbaa !24
  %t99 = getelementptr { i64, ptr }, ptr %t97, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !27
  %t101 = getelementptr { i64, ptr }, ptr %t100, i64 %t98
  store { i64, ptr } %t95, ptr %t101, !tbaa !37
  br label %bb17
bb17:
  %t102 = load i64, ptr %l8, !tbaa !24
  %t104 = add i64 %t102, 1
  store i64 %t104, ptr %l8, !tbaa !24
  br label %bb11
bb18:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = getelementptr %"compiler/emit:Emitter", ptr %t106, i32 0, i32 3
  %t109 = load ptr, ptr %t108, !tbaa !29
  %t110 = load i32, ptr %l1, !tbaa !23
  %t113 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t109, i32 %t110)
  store i32 %t113, ptr %l66
  br label %bb19
bb19:
  %t114 = load i32, ptr %l66, !range !{i32 0, i32 33}
  %t116 = trunc i64 18 to i32
  %t117 = icmp eq i32 %t114, %t116
  %t119 = xor i1 %t117, true
  br i1 %t119, label %bb20, label %bb21
bb20:
  %t121 = load ptr, ptr %lp3
  %t122 = load { i64, ptr }, ptr %t121, !tbaa !27
  store { i64, ptr } %t122, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t126 = getelementptr %"compiler/emit:Emitter", ptr %t124, i32 0, i32 0
  %t127 = load ptr, ptr %t126, !tbaa !29
  store ptr %t127, ptr %l72, !tbaa !29
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t130 = getelementptr %"compiler/emit:Emitter", ptr %t128, i32 0, i32 3
  %t131 = load ptr, ptr %t130, !tbaa !29
  %t132 = load i32, ptr %l1, !tbaa !23
  %t135 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t131, i32 %t132)
  store i32 %t135, ptr %l76
  br label %bb23
bb23:
  %t136 = load ptr, ptr %l72, !tbaa !29
  %t137 = load i32, ptr %l76, !tbaa !23
  %t138 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %v0, ptr %t136, i32 %t137)
  store ptr %t138, ptr %l77
  br label %bb24
bb24:
  %t139 = load ptr, ptr %l77, !tbaa !29
  store ptr %t139, ptr %l10, !tbaa !29
  %t140 = load ptr, ptr %l10, !tbaa !29
  %t142 = icmp eq ptr %t140, null
  br i1 %t142, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l80, !tbaa !21
  br label %bb27
bb26:
  %t144 = load ptr, ptr %l10, !tbaa !29
  %t146 = getelementptr %"compiler/ast:TypeDecl", ptr %t144, i32 0, i32 3
  %t147 = load ptr, ptr %t146, !tbaa !29
  %t149 = icmp eq ptr %t147, null
  store i1 %t149, ptr %l80, !tbaa !21
  br label %bb27
bb27:
  %t151 = load i1, ptr %l80, !tbaa !21
  br i1 %t151, label %bb28, label %bb29
bb28:
  %t152 = load ptr, ptr %lp3
  %t153 = load { i64, ptr }, ptr %t152, !tbaa !27
  store { i64, ptr } %t153, ptr %rv
  br label %ret
bb29:
  br label %bb30
bb30:
  %t155 = load ptr, ptr %l10, !tbaa !29
  %t157 = getelementptr %"compiler/ast:TypeDecl", ptr %t155, i32 0, i32 3
  %t158 = load ptr, ptr %t157, !tbaa !29
  store ptr %t158, ptr %l11, !tbaa !29
  %t160 = load ptr, ptr %l11, !tbaa !29
  store ptr %t160, ptr %l87, !tbaa !29
  store i1 false, ptr %l88, !tbaa !21
  %t161 = load ptr, ptr %l87, !tbaa !29
  %t162 = icmp ne ptr %t161, null
  br i1 %t162, label %bb31, label %bb32
bb31:
  %t164 = load ptr, ptr %l87, !tbaa !29
  %t165 = load i64, ptr %t164, !range !{i64 0, i64 5}
  %t167 = icmp eq i64 %t165, 0
  store i1 %t167, ptr %l88, !tbaa !21
  br label %bb32
bb32:
  %t168 = load i1, ptr %l88, !tbaa !21
  %t169 = xor i1 %t168, true
  br i1 %t169, label %bb33, label %bb34
bb33:
  %t171 = load ptr, ptr %lp3
  %t172 = load { i64, ptr }, ptr %t171, !tbaa !27
  store { i64, ptr } %t172, ptr %rv
  br label %ret
bb34:
  br label %bb35
bb35:
  %t174 = load ptr, ptr %l11, !tbaa !29
  %t176 = getelementptr { i64, [6 x i64] }, ptr %t174, i32 0, i32 1
  %t177 = getelementptr { ptr }, ptr %t176, i32 0, i32 0
  %t178 = load ptr, ptr %t177
  store i64 0, ptr %l13, !tbaa !24
  %t183 = getelementptr %"compiler/ast:StructBody", ptr %t178, i32 0, i32 2
  %t184 = load { i64, ptr }, ptr %t183, !tbaa !27
  store { i64, ptr } %t184, ptr %l14, !tbaa !27
  store i64 0, ptr %l15, !tbaa !24
  %t186 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t188 = extractvalue { i64, ptr } %t186, 0
  store i64 %t188, ptr %l16, !tbaa !24
  br label %bb36
bb36:
  %t190 = load i64, ptr %l15, !tbaa !24
  %t191 = load i64, ptr %l16, !tbaa !24
  %t194 = icmp slt i64 %t190, %t191
  %t196 = xor i1 %t194, true
  br i1 %t196, label %bb37, label %bb38
bb37:
  br label %bb61
bb38:
  br label %bb39
bb39:
  %t198 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t198, ptr %l104, !tbaa !27
  %t199 = load i64, ptr %l15, !tbaa !24
  %t201 = getelementptr { i64, ptr }, ptr %l104, i32 0, i32 1
  %t202 = load ptr, ptr %t201, !tbaa !27
  %t203 = getelementptr ptr, ptr %t202, i64 %t199
  %t204 = load ptr, ptr %t203, !tbaa !39
  store ptr %t204, ptr %l17, !tbaa !29
  %t206 = load ptr, ptr %l17, !tbaa !29
  store ptr %t206, ptr %l107, !tbaa !29
  store i1 false, ptr %l108, !tbaa !21
  %t207 = load ptr, ptr %l107, !tbaa !29
  %t208 = icmp ne ptr %t207, null
  br i1 %t208, label %bb40, label %bb41
bb40:
  %t210 = load ptr, ptr %l107, !tbaa !29
  %t211 = load i64, ptr %t210, !range !{i64 0, i64 22}
  %t213 = icmp eq i64 %t211, 1
  store i1 %t213, ptr %l108, !tbaa !21
  br label %bb41
bb41:
  %t214 = load i1, ptr %l108, !tbaa !21
  %t215 = xor i1 %t214, true
  br i1 %t215, label %bb42, label %bb43
bb42:
  store i1 true, ptr %l112, !tbaa !21
  br label %bb44
bb43:
  %t217 = load ptr, ptr %l17, !tbaa !29
  %t219 = getelementptr { i64, [4 x i64] }, ptr %t217, i32 0, i32 1
  %t220 = getelementptr { %"compiler/source:Span", ptr }, ptr %t219, i32 0, i32 0
  %t221 = load %"compiler/source:Span", ptr %t220
  store %"compiler/source:Span" %t221, ptr %l18
  %t223 = load ptr, ptr %l17, !tbaa !29
  %t225 = getelementptr { i64, [4 x i64] }, ptr %t223, i32 0, i32 1
  %t226 = getelementptr { %"compiler/source:Span", ptr }, ptr %t225, i32 0, i32 1
  %t227 = load ptr, ptr %t226
  %t232 = getelementptr %"compiler/ast:VarDecl", ptr %t227, i32 0, i32 5
  %t233 = load i1, ptr %t232, !tbaa !21
  %t235 = xor i1 %t233, true
  store i1 %t235, ptr %l112, !tbaa !21
  br label %bb44
bb44:
  %t237 = load i1, ptr %l112, !tbaa !21
  br i1 %t237, label %bb45, label %bb46
bb45:
  br label %bb60
bb46:
  br label %bb47
bb47:
  %t238 = load ptr, ptr %l17, !tbaa !29
  %t240 = getelementptr { i64, [4 x i64] }, ptr %t238, i32 0, i32 1
  %t241 = getelementptr { %"compiler/source:Span", ptr }, ptr %t240, i32 0, i32 0
  %t242 = load %"compiler/source:Span", ptr %t241
  store %"compiler/source:Span" %t242, ptr %l20
  %t244 = load ptr, ptr %l17, !tbaa !29
  %t246 = getelementptr { i64, [4 x i64] }, ptr %t244, i32 0, i32 1
  %t247 = getelementptr { %"compiler/source:Span", ptr }, ptr %t246, i32 0, i32 1
  %t248 = load ptr, ptr %t247
  %t253 = getelementptr %"compiler/ast:VarDecl", ptr %t248, i32 0, i32 0
  %t254 = load { i64, ptr }, ptr %t253, !tbaa !27
  store { i64, ptr } %t254, ptr %l22, !tbaa !27
  store i64 0, ptr %l23, !tbaa !24
  %t256 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t258 = extractvalue { i64, ptr } %t256, 0
  store i64 %t258, ptr %l24, !tbaa !24
  br label %bb48
bb48:
  %t260 = load i64, ptr %l23, !tbaa !24
  %t261 = load i64, ptr %l24, !tbaa !24
  %t264 = icmp slt i64 %t260, %t261
  %t266 = xor i1 %t264, true
  br i1 %t266, label %bb49, label %bb50
bb49:
  br label %bb59
bb50:
  br label %bb51
bb51:
  %t268 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t268, ptr %l134, !tbaa !27
  %t269 = load i64, ptr %l23, !tbaa !24
  %t271 = getelementptr { i64, ptr }, ptr %l134, i32 0, i32 1
  %t272 = load ptr, ptr %t271, !tbaa !27
  %t273 = getelementptr i32, ptr %t272, i64 %t269
  %t274 = load i32, ptr %t273, !tbaa !33
  store i32 %t274, ptr %l25, !tbaa !23
  %t276 = load i64, ptr %l13, !tbaa !24
  %t277 = load i64, ptr %l2, !tbaa !24
  %t280 = icmp slt i64 %t276, %t277
  br i1 %t280, label %bb52, label %bb53
bb52:
  store %olang.scope zeroinitializer, ptr %s13
  %t282 = load i64, ptr %l13, !tbaa !24
  store i64 %t282, ptr %l140, !tbaa !24
  %t283 = ptrtoint ptr %v1 to i64
  store i64 %t283, ptr %l141, !tbaa !24
  %t284 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t284, label %bb54, label %bb55
bb53:
  br label %bb57
bb54:
  %t286 = call ptr @__olang_region_make(ptr %v1)
  %t287 = ptrtoint ptr %t286 to i64
  store i64 %t287, ptr %l141, !tbaa !24
  br label %bb55
bb55:
  %t288 = load ptr, ptr %l0, !tbaa !29
  %t289 = load i32, ptr %l25, !tbaa !23
  %t292 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etext(ptr %v0, ptr %s13, ptr %t288, i32 %t289)
  store { i64, ptr } %t292, ptr %l145
  br label %bb56
bb56:
  %t293 = load { i64, ptr }, ptr %l145, !tbaa !27
  %t294 = extractvalue { i64, ptr } %t293, 1
  %t295 = extractvalue { i64, ptr } %t293, 0
  %t296 = load i64, ptr %l141
  %t297 = inttoptr i64 %t296 to ptr
  %t298 = call ptr @__olang_scope_alloc(ptr %t297, i64 %t295)
  call void @olang_textcopy(ptr %t298, ptr %t294, i64 %t295)
  %t299 = insertvalue { i64, ptr } undef, i64 %t295, 0
  %t300 = insertvalue { i64, ptr } %t299, ptr %t298, 1
  %t302 = load i64, ptr %l141
  %t303 = inttoptr i64 %t302 to ptr
  %t304 = extractvalue { i64, ptr } %t300, 0
  %t305 = extractvalue { i64, ptr } %t300, 1
  %t306 = mul i64 %t304, 1
  %t307 = call ptr @__olang_scope_alloc(ptr %t303, i64 %t306)
  call void @llvm.memcpy.p0.p0.i64(ptr %t307, ptr %t305, i64 %t306, i1 false)
  %t308 = insertvalue { i64, ptr } undef, i64 %t304, 0
  %t309 = insertvalue { i64, ptr } %t308, ptr %t307, 1
  %t311 = load ptr, ptr %lp3
  %t312 = load i64, ptr %l140, !tbaa !24
  %t313 = getelementptr { i64, ptr }, ptr %t311, i32 0, i32 1
  %t314 = load ptr, ptr %t313, !tbaa !27
  %t315 = getelementptr { i64, ptr }, ptr %t314, i64 %t312
  store { i64, ptr } %t309, ptr %t315, !tbaa !37
  call void @__olang_scope_close(ptr %s13)
  br label %bb57
bb57:
  %t316 = load i64, ptr %l13, !tbaa !24
  %t318 = add i64 %t316, 1
  store i64 %t318, ptr %l13, !tbaa !24
  br label %bb58
bb58:
  %t320 = load i64, ptr %l23, !tbaa !24
  %t322 = add i64 %t320, 1
  store i64 %t322, ptr %l23, !tbaa !24
  br label %bb48
bb59:
  br label %bb60
bb60:
  %t324 = load i64, ptr %l15, !tbaa !24
  %t326 = add i64 %t324, 1
  store i64 %t326, ptr %l15, !tbaa !24
  br label %bb36
bb61:
  %t328 = load ptr, ptr %lp3
  %t329 = load { i64, ptr }, ptr %t328, !tbaa !27
  store { i64, ptr } %t329, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3aEmitter_2egap(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l7 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca i64
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/emit:Emitter", ptr %t3, i32 0, i32 12
  %t9 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H0127831368543eff3b7740d7d3240080(ptr %v0, ptr %v1, ptr %t5, { i64, ptr } %t1)
  store i1 %t9, ptr %l7
  br label %bb1
bb1:
  %t10 = load i1, ptr %l7, !tbaa !21
  %t11 = xor i1 %t10, true
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/emit:Emitter", ptr %t13, i32 0, i32 12
  store ptr %t15, ptr %l10, !tbaa !29
  %t16 = ptrtoint ptr %v0 to i64
  store i64 %t16, ptr %l11, !tbaa !24
  %t17 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t17, label %bb4, label %bb5
bb3:
  br label %bb7
bb4:
  %t19 = call ptr @__olang_region_make(ptr %v0)
  %t20 = ptrtoint ptr %t19 to i64
  store i64 %t20, ptr %l11, !tbaa !24
  br label %bb5
bb5:
  %t21 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t21, 1
  %t24 = extractvalue { i64, ptr } %t21, 0
  %t25 = load i64, ptr %l11
  %t26 = inttoptr i64 %t25 to ptr
  %t27 = call ptr @__olang_scope_alloc(ptr %t26, i64 %t24)
  call void @olang_textcopy(ptr %t27, ptr %t23, i64 %t24)
  %t28 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t27, 1
  %t31 = load i64, ptr %l11
  %t32 = inttoptr i64 %t31 to ptr
  %t33 = extractvalue { i64, ptr } %t29, 0
  %t34 = extractvalue { i64, ptr } %t29, 1
  %t35 = mul i64 %t33, 1
  %t36 = call ptr @__olang_scope_alloc(ptr %t32, i64 %t35)
  call void @llvm.memcpy.p0.p0.i64(ptr %t36, ptr %t34, i64 %t35, i1 false)
  %t37 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t38 = insertvalue { i64, ptr } %t37, ptr %t36, 1
  %t39 = load ptr, ptr %l10, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v0, ptr %t39, { i64, ptr } %t38)
  br label %bb6
bb6:
  br label %bb7
bb7:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2egenBufName(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2estableSym(ptr %v0, ptr %s0, ptr %t1, i64 %a1)
  store { i64, ptr } %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/emit:Emitter", ptr %t6, i32 0, i32 3
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t12 = inttoptr i64 0 to ptr
  %t15 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s0, ptr %t12, ptr %t9, i32 %a2)
  store { i64, ptr } %t15, ptr %l10
  br label %bb2
bb2:
  %t16 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d162, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d162, i32 0, i32 1) }, 0
  %t18 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t18, 1
  %t20 = extractvalue { i64, ptr } %t18, 0
  %t21 = add i64 %t17, %t20
  %t22 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d163, i32 0, i32 1) }, 1
  %t23 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d163, i32 0, i32 1) }, 0
  %t24 = add i64 %t21, %t23
  %t25 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t25, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = add i64 %t24, %t27
  %t29 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t28)
  call void @olang_textcopy(ptr %t29, ptr %t16, i64 %t17)
  %t30 = getelementptr i8, ptr %t29, i64 %t17
  call void @olang_textcopy(ptr %t30, ptr %t19, i64 %t20)
  %t31 = getelementptr i8, ptr %t30, i64 %t20
  call void @olang_textcopy(ptr %t31, ptr %t22, i64 %t23)
  %t32 = getelementptr i8, ptr %t31, i64 %t23
  call void @olang_textcopy(ptr %t32, ptr %t26, i64 %t27)
  %t33 = insertvalue { i64, ptr } undef, i64 %t28, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t29, 1
  %t36 = extractvalue { i64, ptr } %t34, 0
  %t37 = extractvalue { i64, ptr } %t34, 1
  %t38 = mul i64 %t36, 1
  %t39 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t38)
  call void @llvm.memcpy.p0.p0.i64(ptr %t39, ptr %t37, i64 %t38, i1 false)
  %t40 = insertvalue { i64, ptr } undef, i64 %t36, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t39, 1
  %t43 = call { i64, ptr } @compiler_2ftypes_2eSymbol(ptr %v1, ptr %v1, { i64, ptr } %t41)
  store { i64, ptr } %t43, ptr %l13
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  %t44 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t44, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2egenBufOn(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l8 = alloca ptr
  %l12 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/emit:Emitter", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = call ptr @compiler_2flower_2ecompiler_2flower_3aLowerer_2eGen(ptr %v0, ptr %v0, ptr %t9)
  store ptr %t11, ptr %l8
  br label %bb1
bb1:
  %t12 = load ptr, ptr %l8, !tbaa !29
  %t14 = load ptr, ptr %l2, !tbaa !29
  %t19 = call i1 @compiler_2fmir_2ecompiler_2fmir_3aGenInfo_2eHasLeaves(ptr %v0, ptr %v0, ptr %t12, ptr %t14, i32 %a1)
  store i1 %t19, ptr %l12
  br label %bb2
bb2:
  %t20 = load i1, ptr %l12, !tbaa !21
  store i1 %t20, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2egenDrop(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca %"std/prelude/text:StringBuilder"
  %l4 = alloca %"std/prelude/text:StringBuilder"
  %l17 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l4
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l4
  store %"std/prelude/text:StringBuilder" %t2, ptr %l3
  %t4 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d164, i32 0, i32 1) }, 1
  %t5 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d164, i32 0, i32 1) }, 0
  %t7 = extractvalue { i64, ptr } %a1, 1
  %t8 = extractvalue { i64, ptr } %a1, 0
  %t9 = add i64 %t5, %t8
  %t10 = extractvalue { i64, ptr } { i64 38, ptr getelementptr inbounds (<{ i64, [38 x i8] }>, ptr @.d165, i32 0, i32 1) }, 1
  %t11 = extractvalue { i64, ptr } { i64 38, ptr getelementptr inbounds (<{ i64, [38 x i8] }>, ptr @.d165, i32 0, i32 1) }, 0
  %t12 = add i64 %t9, %t11
  %t13 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t12)
  call void @olang_textcopy(ptr %t13, ptr %t4, i64 %t5)
  %t14 = getelementptr i8, ptr %t13, i64 %t5
  call void @olang_textcopy(ptr %t14, ptr %t7, i64 %t8)
  %t15 = getelementptr i8, ptr %t14, i64 %t8
  call void @olang_textcopy(ptr %t15, ptr %t10, i64 %t11)
  %t16 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t13, 1
  %t19 = extractvalue { i64, ptr } %t17, 0
  %t20 = extractvalue { i64, ptr } %t17, 1
  %t21 = mul i64 %t19, 1
  %t22 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t21)
  call void @llvm.memcpy.p0.p0.i64(ptr %t22, ptr %t20, i64 %t21, i1 false)
  %t23 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t22, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l3, { i64, ptr } %t24)
  br label %bb2
bb2:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l3, { i64, ptr } { i64 60, ptr getelementptr inbounds (<{ i64, [60 x i8] }>, ptr @.d166, i32 0, i32 1) })
  br label %bb3
bb3:
  %t29 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d167, i32 0, i32 1) }, 1
  %t30 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d167, i32 0, i32 1) }, 0
  %t32 = extractvalue { i64, ptr } %a2, 1
  %t33 = extractvalue { i64, ptr } %a2, 0
  %t34 = add i64 %t30, %t33
  %t35 = extractvalue { i64, ptr } { i64 48, ptr getelementptr inbounds (<{ i64, [48 x i8] }>, ptr @.d168, i32 0, i32 1) }, 1
  %t36 = extractvalue { i64, ptr } { i64 48, ptr getelementptr inbounds (<{ i64, [48 x i8] }>, ptr @.d168, i32 0, i32 1) }, 0
  %t37 = add i64 %t34, %t36
  %t38 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t37)
  call void @olang_textcopy(ptr %t38, ptr %t29, i64 %t30)
  %t39 = getelementptr i8, ptr %t38, i64 %t30
  call void @olang_textcopy(ptr %t39, ptr %t32, i64 %t33)
  %t40 = getelementptr i8, ptr %t39, i64 %t33
  call void @olang_textcopy(ptr %t40, ptr %t35, i64 %t36)
  %t41 = insertvalue { i64, ptr } undef, i64 %t37, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t38, 1
  %t44 = extractvalue { i64, ptr } %t42, 0
  %t45 = extractvalue { i64, ptr } %t42, 1
  %t46 = mul i64 %t44, 1
  %t47 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t46)
  call void @llvm.memcpy.p0.p0.i64(ptr %t47, ptr %t45, i64 %t46, i1 false)
  %t48 = insertvalue { i64, ptr } undef, i64 %t44, 0
  %t49 = insertvalue { i64, ptr } %t48, ptr %t47, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l3, { i64, ptr } %t49)
  br label %bb4
bb4:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l3, { i64, ptr } { i64 104, ptr getelementptr inbounds (<{ i64, [104 x i8] }>, ptr @.d169, i32 0, i32 1) })
  br label %bb5
bb5:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l3, { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d170, i32 0, i32 1) })
  br label %bb6
bb6:
  %t55 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v3, ptr %l3)
  store { i64, ptr } %t55, ptr %l17
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s0)
  %t56 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t56, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2egroupRank(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l4 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i32
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 87
  store ptr %t3, ptr %l4, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t8 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2einstGroupOf(ptr %v0, ptr %t4, i64 %a1)
  store i64 %t8, ptr %l7
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l4, !tbaa !29
  %t10 = load i64, ptr %l7, !tbaa !24
  %t11 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t9, i64 %t10)
  %t12 = extractvalue { i32, i64 } %t11, 1
  %t13 = extractvalue { i32, i64 } %t11, 0
  store i32 %t13, ptr %l9
  %t14 = icmp ne i32 %t13, 0
  br i1 %t14, label %bb3, label %ok.15, !prof !99
ok.15:
  store i64 %t12, ptr %l8
  br label %bb2
bb2:
  %t16 = load i64, ptr %l8, !tbaa !24
  store i64 %t16, ptr %l2, !tbaa !24
  br label %bb5
bb3:
  br label %bb4
bb4:
  store i64 -1, ptr %l2, !tbaa !24
  br label %bb5
bb5:
  %t17 = load i64, ptr %l2, !tbaa !24
  store i64 %t17, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eisGen(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1) #0 {
entry:
  %l1 = alloca { i64, [2 x i64] }
  %l2 = alloca i32
  %l3 = alloca i1
  %l13 = alloca ptr
  %rv = alloca i1
  store { i64, [2 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [2 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [2 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { i32 }, ptr %t6, i32 0, i32 0
  %t8 = load i32, ptr %t7
  store i32 %t8, ptr %l2, !tbaa !23
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t12 = getelementptr %"compiler/emit:Emitter", ptr %a0, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = getelementptr %"compiler/lower:Lowerer", ptr %t13, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t18 = load i32, ptr %l2, !tbaa !23
  %t20 = sext i32 %t18 to i64
  %t23 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t16, i64 %t20)
  store ptr %t23, ptr %l13
  br label %bb4
bb4:
  %t24 = load ptr, ptr %l13, !tbaa !29
  %t26 = getelementptr %"compiler/typed:Body", ptr %t24, i32 0, i32 14
  %t27 = load i1, ptr %t26, !tbaa !21
  store i1 %t27, ptr %l3, !tbaa !21
  br label %bb10
bb5:
  br i1 true, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb9
bb8:
  store i1 false, ptr %l3, !tbaa !21
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_a37d1f87ccda68bc_daadd8872686b520)
  unreachable
bb10:
  %t29 = load i1, ptr %l3, !tbaa !21
  store i1 %t29, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eisLambda(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l8 = alloca ptr
  %l11 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %a0, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/lower:Lowerer", ptr %t4, i32 0, i32 1
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t12 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t7, i64 %a1)
  store ptr %t12, ptr %l8
  br label %bb1
bb1:
  %t13 = load ptr, ptr %l8, !tbaa !29
  %t15 = getelementptr %"compiler/typed:Body", ptr %t13, i32 0, i32 1
  %t16 = load { i64, [2 x i64] }, ptr %t15
  %t20 = extractvalue { i64, [2 x i64] } %t16, 0
  %t21 = icmp eq i64 %t20, 4
  br i1 %t21, label %bb2, label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb5
bb4:
  store i1 true, ptr %l11, !tbaa !21
  br label %bb10
bb5:
  br i1 true, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb9
bb8:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_7f6c4a9881f0c77f_244fd8f3f85b2bab)
  unreachable
bb10:
  %t23 = load i1, ptr %l11, !tbaa !21
  store i1 %t23, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2elocBase(ptr %v0, ptr %v1, ptr %a0, { i64, [2 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [2 x i64] }
  %l2 = alloca i64
  %l3 = alloca i1
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca { i64, [2 x i64] }
  %l9 = alloca i32
  %l22 = alloca i1
  %l25 = alloca i1
  %l29 = alloca { i64, ptr }
  %l35 = alloca ptr
  %l42 = alloca i1
  %l49 = alloca ptr
  %l59 = alloca { i64, ptr }
  %l60 = alloca i64
  %l66 = alloca ptr
  %l70 = alloca i64
  %l72 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, [2 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 -1, ptr %l2, !tbaa !24
  store i1 false, ptr %l3, !tbaa !21
  %t1 = load { i64, [2 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [2 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { i32 }, ptr %t6, i32 0, i32 0
  %t8 = load i32, ptr %t7
  store i32 %t8, ptr %l4, !tbaa !23
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t10 = load i32, ptr %l4, !tbaa !23
  %t12 = sext i32 %t10 to i64
  store i64 %t12, ptr %l2, !tbaa !24
  br label %bb13
bb4:
  %t14 = load { i64, [2 x i64] }, ptr %l1
  %t16 = extractvalue { i64, [2 x i64] } %t14, 0
  %t17 = icmp eq i64 %t16, 1
  br i1 %t17, label %bb5, label %bb6
bb5:
  %t19 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t20 = getelementptr { i32 }, ptr %t19, i32 0, i32 0
  %t21 = load i32, ptr %t20
  store i32 %t21, ptr %l5, !tbaa !23
  br label %bb7
bb6:
  br label %bb8
bb7:
  %t23 = load i32, ptr %l5, !tbaa !23
  %t25 = sext i32 %t23 to i64
  store i64 %t25, ptr %l2, !tbaa !24
  store i1 true, ptr %l3, !tbaa !21
  br label %bb13
bb8:
  br i1 true, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_1cb2b0b1c80ab6bb_ff3b7bcb0dec81bf)
  unreachable
bb13:
  %t27 = load i64, ptr %l2, !tbaa !24
  %t29 = icmp slt i64 %t27, 0
  br i1 %t29, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l22, !tbaa !21
  br label %bb17
bb15:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load i64, ptr %l2, !tbaa !24
  %t35 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eisLambda(ptr %v0, ptr %t31, i64 %t32)
  store i1 %t35, ptr %l25
  br label %bb16
bb16:
  %t36 = load i1, ptr %l25, !tbaa !21
  %t37 = xor i1 %t36, true
  store i1 %t37, ptr %l22, !tbaa !21
  br label %bb17
bb17:
  %t39 = load i1, ptr %l22, !tbaa !21
  br i1 %t39, label %bb18, label %bb19
bb18:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load { i64, [2 x i64] }, ptr %l1
  %t44 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2esym(ptr %v0, ptr %v1, ptr %t40, { i64, [2 x i64] } %t41)
  store { i64, ptr } %t44, ptr %l29
  br label %bb20
bb19:
  br label %bb21
bb20:
  call void @__olang_scope_close(ptr %s0)
  %t45 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t45, ptr %rv
  br label %ret
bb21:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/emit:Emitter", ptr %t46, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t51 = getelementptr %"compiler/lower:Lowerer", ptr %t49, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !29
  %t54 = load i64, ptr %l2, !tbaa !24
  %t57 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t52, i64 %t54)
  store ptr %t57, ptr %l35
  br label %bb22
bb22:
  %t58 = load ptr, ptr %l35, !tbaa !29
  %t60 = getelementptr %"compiler/typed:Body", ptr %t58, i32 0, i32 4
  %t61 = getelementptr %"compiler/source:Span", ptr %t60, i32 0, i32 0
  %t62 = load i32, ptr %t61, !tbaa !23
  %t64 = sext i32 %t62 to i64
  store i64 %t64, ptr %l6, !tbaa !24
  %t66 = load i64, ptr %l2, !tbaa !24
  store i64 %t66, ptr %l7, !tbaa !24
  br label %bb23
bb23:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load i64, ptr %l7, !tbaa !24
  %t72 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eisLambda(ptr %v0, ptr %t68, i64 %t69)
  store i1 %t72, ptr %l42
  br label %bb24
bb24:
  %t73 = load i1, ptr %l42, !tbaa !21
  %t74 = xor i1 %t73, true
  br i1 %t74, label %bb25, label %bb26
bb25:
  br label %bb39
bb26:
  br label %bb27
bb27:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/emit:Emitter", ptr %t76, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !29
  %t81 = getelementptr %"compiler/lower:Lowerer", ptr %t79, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t84 = load i64, ptr %l7, !tbaa !24
  %t87 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t82, i64 %t84)
  store ptr %t87, ptr %l49
  br label %bb28
bb28:
  %t88 = load ptr, ptr %l49, !tbaa !29
  %t90 = getelementptr %"compiler/typed:Body", ptr %t88, i32 0, i32 1
  %t91 = load { i64, [2 x i64] }, ptr %t90
  store { i64, [2 x i64] } %t91, ptr %l8
  %t93 = load { i64, [2 x i64] }, ptr %l8
  %t95 = extractvalue { i64, [2 x i64] } %t93, 0
  %t96 = icmp eq i64 %t95, 4
  br i1 %t96, label %bb29, label %bb30
bb29:
  %t98 = getelementptr { i64, [2 x i64] }, ptr %l8, i32 0, i32 1
  %t99 = getelementptr { i32 }, ptr %t98, i32 0, i32 0
  %t100 = load i32, ptr %t99
  store i32 %t100, ptr %l9, !tbaa !23
  br label %bb31
bb30:
  br label %bb32
bb31:
  %t102 = load i32, ptr %l9, !tbaa !23
  %t104 = sext i32 %t102 to i64
  store i64 %t104, ptr %l7, !tbaa !24
  br label %bb37
bb32:
  br i1 true, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb39
bb36:
  call void @__olang_check_failed(ptr @olang_loc_dd4469a9ae312a3a_602f574df5758ebe)
  unreachable
bb37:
  br label %bb38
bb38:
  br label %bb23
bb39:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t107 = load i64, ptr %l7, !tbaa !24
  %t110 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ebodySym(ptr %v0, ptr %s0, ptr %t106, i64 %t107)
  store { i64, ptr } %t110, ptr %l59
  br label %bb40
bb40:
  %t111 = load i64, ptr %l6, !tbaa !24
  store i64 %t111, ptr %l60, !tbaa !24
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t114 = getelementptr %"compiler/emit:Emitter", ptr %t112, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !29
  %t117 = getelementptr %"compiler/lower:Lowerer", ptr %t115, i32 0, i32 1
  %t118 = load ptr, ptr %t117, !tbaa !29
  %t120 = load i64, ptr %l7, !tbaa !24
  %t123 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t118, i64 %t120)
  store ptr %t123, ptr %l66
  br label %bb41
bb41:
  %t124 = load ptr, ptr %l66, !tbaa !29
  %t126 = getelementptr %"compiler/typed:Body", ptr %t124, i32 0, i32 4
  %t127 = getelementptr %"compiler/source:Span", ptr %t126, i32 0, i32 0
  %t128 = load i32, ptr %t127, !tbaa !23
  %t130 = sext i32 %t128 to i64
  %t131 = load i64, ptr %l60, !tbaa !24
  %t133 = sub i64 %t131, %t130
  store i64 %t133, ptr %l70, !tbaa !24
  %t134 = load i1, ptr %l3, !tbaa !21
  br i1 %t134, label %bb42, label %bb43
bb42:
  store { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d171, i32 0, i32 1) }, ptr %l72, !tbaa !27
  br label %bb44
bb43:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d172, i32 0, i32 1) }, ptr %l72, !tbaa !27
  br label %bb44
bb44:
  %t136 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t137 = extractvalue { i64, ptr } %t136, 1
  %t138 = extractvalue { i64, ptr } %t136, 0
  %t139 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d173, i32 0, i32 1) }, 1
  %t140 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d173, i32 0, i32 1) }, 0
  %t141 = add i64 %t138, %t140
  %t142 = load i64, ptr %l70, !tbaa !24
  %t143 = call i64 @__olang_fmt_i64(ptr null, i64 %t142)
  %t144 = add i64 %t141, %t143
  %t145 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t146 = extractvalue { i64, ptr } %t145, 1
  %t147 = extractvalue { i64, ptr } %t145, 0
  %t148 = add i64 %t144, %t147
  %t149 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t148)
  call void @olang_textcopy(ptr %t149, ptr %t137, i64 %t138)
  %t150 = getelementptr i8, ptr %t149, i64 %t138
  call void @olang_textcopy(ptr %t150, ptr %t139, i64 %t140)
  %t151 = getelementptr i8, ptr %t150, i64 %t140
  %t152 = call i64 @__olang_fmt_i64(ptr %t151, i64 %t142)
  %t153 = getelementptr i8, ptr %t151, i64 %t143
  call void @olang_textcopy(ptr %t153, ptr %t146, i64 %t147)
  %t154 = insertvalue { i64, ptr } undef, i64 %t148, 0
  %t155 = insertvalue { i64, ptr } %t154, ptr %t149, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t155, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2erecodeText(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2, i32 %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l18 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca [1 x i8]
  %l34 = alloca i64
  %l37 = alloca i64
  %l61 = alloca ptr
  %l62 = alloca i64
  %l63 = alloca i64
  %l66 = alloca { i64, ptr }
  %l69 = alloca i64
  %l74 = alloca { i64, ptr }
  %l76 = alloca i64
  %l84 = alloca { i64, ptr }
  %l85 = alloca { i64, ptr }
  %l86 = alloca i64
  %l87 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t10 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t4, i32 %a3)
  store { i64, ptr } %t10, ptr %l18
  br label %bb1
bb1:
  %t11 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t11, ptr %l6, !tbaa !27
  %t12 = load ptr, ptr %l1, !tbaa !29
  %t13 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t14 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t15 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d174, i32 0, i32 1) }, 1
  %t16 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d174, i32 0, i32 1) }, 0
  %t18 = extractvalue { i64, ptr } %t13, 1
  %t19 = extractvalue { i64, ptr } %t13, 0
  %t20 = add i64 %t16, %t19
  %t21 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d175, i32 0, i32 1) }, 1
  %t22 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d175, i32 0, i32 1) }, 0
  %t23 = add i64 %t20, %t22
  %t25 = extractvalue { i64, ptr } %t14, 1
  %t26 = extractvalue { i64, ptr } %t14, 0
  %t27 = add i64 %t23, %t26
  %t28 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d176, i32 0, i32 1) }, 1
  %t29 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d176, i32 0, i32 1) }, 0
  %t30 = add i64 %t27, %t29
  %t31 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t30)
  call void @olang_textcopy(ptr %t31, ptr %t15, i64 %t16)
  %t32 = getelementptr i8, ptr %t31, i64 %t16
  call void @olang_textcopy(ptr %t32, ptr %t18, i64 %t19)
  %t33 = getelementptr i8, ptr %t32, i64 %t19
  call void @olang_textcopy(ptr %t33, ptr %t21, i64 %t22)
  %t34 = getelementptr i8, ptr %t33, i64 %t22
  call void @olang_textcopy(ptr %t34, ptr %t25, i64 %t26)
  %t35 = getelementptr i8, ptr %t34, i64 %t26
  call void @olang_textcopy(ptr %t35, ptr %t28, i64 %t29)
  %t36 = insertvalue { i64, ptr } undef, i64 %t30, 0
  %t37 = insertvalue { i64, ptr } %t36, ptr %t31, 1
  %t39 = extractvalue { i64, ptr } %t37, 0
  %t40 = extractvalue { i64, ptr } %t37, 1
  %t41 = mul i64 %t39, 1
  %t42 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t41)
  call void @llvm.memcpy.p0.p0.i64(ptr %t42, ptr %t40, i64 %t41, i1 false)
  %t43 = insertvalue { i64, ptr } undef, i64 %t39, 0
  %t44 = insertvalue { i64, ptr } %t43, ptr %t42, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s0, ptr %t12, { i64, ptr } %t44)
  br label %bb2
bb2:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d177, i32 0, i32 1) }, ptr %l24, !tbaa !27
  %t47 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t47, ptr %l25, !tbaa !27
  %t48 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = mul i64 1, 1
  call void @llvm.memmove.p0.p0.i64(ptr %l26, ptr %t49, i64 %t50, i1 false)
  %t52 = insertvalue { i64, ptr } undef, i64 1, 0
  %t53 = insertvalue { i64, ptr } %t52, ptr %l26, 1
  store { i64, ptr } %t53, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t55 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t57 = extractvalue { i64, ptr } %t55, 0
  store i64 %t57, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t59 = load i64, ptr %l9, !tbaa !24
  %t60 = load i64, ptr %l8, !tbaa !24
  %t63 = icmp sgt i64 %t59, %t60
  br i1 %t63, label %bb3, label %bb4
bb3:
  %t65 = load i64, ptr %l10, !tbaa !24
  %t67 = icmp sgt i64 %t65, 0
  br i1 %t67, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l34, !tbaa !24
  br label %bb8
bb5:
  %t69 = load i64, ptr %l9, !tbaa !24
  %t70 = load i64, ptr %l8, !tbaa !24
  %t73 = sub i64 %t69, %t70
  %t74 = load i64, ptr %l10, !tbaa !24
  %t77 = add i64 %t73, %t74
  %t79 = sub i64 %t77, 1
  %t80 = load i64, ptr %l10, !tbaa !24
  %t83 = sdiv i64 %t79, %t80
  store i64 %t83, ptr %l37, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l37, !tbaa !24
  br label %bb7
bb7:
  %t85 = load i64, ptr %l37, !tbaa !24
  store i64 %t85, ptr %l34, !tbaa !24
  br label %bb8
bb8:
  %t86 = load i64, ptr %l34, !tbaa !24
  store i64 %t86, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t87 = load i64, ptr %l12, !tbaa !24
  %t88 = load i64, ptr %l11, !tbaa !24
  %t91 = icmp slt i64 %t87, %t88
  %t93 = xor i1 %t91, true
  br i1 %t93, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s3)
  br label %bb20
bb11:
  br label %bb12
bb12:
  %t95 = load i64, ptr %l8, !tbaa !24
  %t96 = load i64, ptr %l12, !tbaa !24
  %t97 = load i64, ptr %l10, !tbaa !24
  %t100 = mul i64 %t96, %t97
  %t103 = add i64 %t95, %t100
  store i64 %t103, ptr %l13, !tbaa !24
  %t105 = load ptr, ptr %l1, !tbaa !29
  %t106 = load i64, ptr %l13, !tbaa !24
  %t107 = load i64, ptr %l13, !tbaa !24
  %t109 = add i64 %t107, 1
  %t110 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d178, i32 0, i32 1) }, 1
  %t111 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d178, i32 0, i32 1) }, 0
  %t113 = call i64 @__olang_fmt_i64(ptr null, i64 %t106)
  %t114 = add i64 %t111, %t113
  %t115 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d179, i32 0, i32 1) }, 1
  %t116 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d179, i32 0, i32 1) }, 0
  %t117 = add i64 %t114, %t116
  %t119 = call i64 @__olang_fmt_i64(ptr null, i64 %t109)
  %t120 = add i64 %t117, %t119
  %t121 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d180, i32 0, i32 1) }, 1
  %t122 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d180, i32 0, i32 1) }, 0
  %t123 = add i64 %t120, %t122
  %t124 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t123)
  call void @olang_textcopy(ptr %t124, ptr %t110, i64 %t111)
  %t125 = getelementptr i8, ptr %t124, i64 %t111
  %t126 = call i64 @__olang_fmt_i64(ptr %t125, i64 %t106)
  %t127 = getelementptr i8, ptr %t125, i64 %t113
  call void @olang_textcopy(ptr %t127, ptr %t115, i64 %t116)
  %t128 = getelementptr i8, ptr %t127, i64 %t116
  %t129 = call i64 @__olang_fmt_i64(ptr %t128, i64 %t109)
  %t130 = getelementptr i8, ptr %t128, i64 %t119
  call void @olang_textcopy(ptr %t130, ptr %t121, i64 %t122)
  %t131 = insertvalue { i64, ptr } undef, i64 %t123, 0
  %t132 = insertvalue { i64, ptr } %t131, ptr %t124, 1
  %t134 = extractvalue { i64, ptr } %t132, 0
  %t135 = extractvalue { i64, ptr } %t132, 1
  %t136 = mul i64 %t134, 1
  %t137 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t136)
  call void @llvm.memcpy.p0.p0.i64(ptr %t137, ptr %t135, i64 %t136, i1 false)
  %t138 = insertvalue { i64, ptr } undef, i64 %t134, 0
  %t139 = insertvalue { i64, ptr } %t138, ptr %t137, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s3, ptr %t105, { i64, ptr } %t139)
  br label %bb13
bb13:
  %t142 = load ptr, ptr %l1, !tbaa !29
  store ptr %t142, ptr %l61, !tbaa !29
  %t143 = load i64, ptr %l13, !tbaa !24
  store i64 %t143, ptr %l62, !tbaa !24
  %t144 = load i64, ptr %l13, !tbaa !24
  store i64 %t144, ptr %l63, !tbaa !24
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t147 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t147, ptr %l66, !tbaa !27
  %t148 = load i64, ptr %l13, !tbaa !24
  %t150 = getelementptr { i64, ptr }, ptr %l66, i32 0, i32 1
  %t151 = load ptr, ptr %t150, !tbaa !27
  %t152 = getelementptr i32, ptr %t151, i64 %t148
  %t153 = load i32, ptr %t152, !tbaa !33
  %t157 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eposition(ptr %v0, ptr %t145, i32 %a4, i32 %t153)
  store i64 %t157, ptr %l69
  br label %bb14
bb14:
  %t158 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t159 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d181, i32 0, i32 1) }, 1
  %t160 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d181, i32 0, i32 1) }, 0
  %t161 = load i64, ptr %l62, !tbaa !24
  %t162 = call i64 @__olang_fmt_i64(ptr null, i64 %t161)
  %t163 = add i64 %t160, %t162
  %t164 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d182, i32 0, i32 1) }, 1
  %t165 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d182, i32 0, i32 1) }, 0
  %t166 = add i64 %t163, %t165
  %t167 = load i64, ptr %l63, !tbaa !24
  %t168 = call i64 @__olang_fmt_i64(ptr null, i64 %t167)
  %t169 = add i64 %t166, %t168
  %t170 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d183, i32 0, i32 1) }, 1
  %t171 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d183, i32 0, i32 1) }, 0
  %t172 = add i64 %t169, %t171
  %t173 = load i64, ptr %l69, !tbaa !24
  %t174 = call i64 @__olang_fmt_i64(ptr null, i64 %t173)
  %t175 = add i64 %t172, %t174
  %t176 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d183, i32 0, i32 1) }, 1
  %t177 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d183, i32 0, i32 1) }, 0
  %t178 = add i64 %t175, %t177
  %t180 = extractvalue { i64, ptr } %t158, 1
  %t181 = extractvalue { i64, ptr } %t158, 0
  %t182 = add i64 %t178, %t181
  %t183 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d184, i32 0, i32 1) }, 1
  %t184 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d184, i32 0, i32 1) }, 0
  %t185 = add i64 %t182, %t184
  %t186 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t185)
  call void @olang_textcopy(ptr %t186, ptr %t159, i64 %t160)
  %t187 = getelementptr i8, ptr %t186, i64 %t160
  %t188 = call i64 @__olang_fmt_i64(ptr %t187, i64 %t161)
  %t189 = getelementptr i8, ptr %t187, i64 %t162
  call void @olang_textcopy(ptr %t189, ptr %t164, i64 %t165)
  %t190 = getelementptr i8, ptr %t189, i64 %t165
  %t191 = call i64 @__olang_fmt_i64(ptr %t190, i64 %t167)
  %t192 = getelementptr i8, ptr %t190, i64 %t168
  call void @olang_textcopy(ptr %t192, ptr %t170, i64 %t171)
  %t193 = getelementptr i8, ptr %t192, i64 %t171
  %t194 = call i64 @__olang_fmt_i64(ptr %t193, i64 %t173)
  %t195 = getelementptr i8, ptr %t193, i64 %t174
  call void @olang_textcopy(ptr %t195, ptr %t176, i64 %t177)
  %t196 = getelementptr i8, ptr %t195, i64 %t177
  call void @olang_textcopy(ptr %t196, ptr %t180, i64 %t181)
  %t197 = getelementptr i8, ptr %t196, i64 %t181
  call void @olang_textcopy(ptr %t197, ptr %t183, i64 %t184)
  %t198 = insertvalue { i64, ptr } undef, i64 %t185, 0
  %t199 = insertvalue { i64, ptr } %t198, ptr %t186, 1
  %t201 = extractvalue { i64, ptr } %t199, 0
  %t202 = extractvalue { i64, ptr } %t199, 1
  %t203 = mul i64 %t201, 1
  %t204 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t203)
  call void @llvm.memcpy.p0.p0.i64(ptr %t204, ptr %t202, i64 %t203, i1 false)
  %t205 = insertvalue { i64, ptr } undef, i64 %t201, 0
  %t206 = insertvalue { i64, ptr } %t205, ptr %t204, 1
  %t207 = load ptr, ptr %l61, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s3, ptr %t207, { i64, ptr } %t206)
  br label %bb15
bb15:
  %t209 = load i64, ptr %l13, !tbaa !24
  %t210 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d185, i32 0, i32 1) }, 1
  %t211 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d185, i32 0, i32 1) }, 0
  %t213 = call i64 @__olang_fmt_i64(ptr null, i64 %t209)
  %t214 = add i64 %t211, %t213
  %t215 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t214)
  call void @olang_textcopy(ptr %t215, ptr %t210, i64 %t211)
  %t216 = getelementptr i8, ptr %t215, i64 %t211
  %t217 = call i64 @__olang_fmt_i64(ptr %t216, i64 %t209)
  %t218 = insertvalue { i64, ptr } undef, i64 %t214, 0
  %t219 = insertvalue { i64, ptr } %t218, ptr %t215, 1
  store { i64, ptr } %t219, ptr %l74, !tbaa !27
  %t220 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t221 = extractvalue { i64, ptr } %t220, 0
  %t222 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t223 = extractvalue { i64, ptr } %t222, 0
  store i64 %t223, ptr %l76, !tbaa !24
  %t225 = load i64, ptr %l76, !tbaa !24
  %t226 = icmp eq i64 %t221, %t225
  br i1 %t226, label %bb16, label %bb17
bb16:
  %t228 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t229 = load ptr, ptr %t228, !tbaa !27
  %t230 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t231 = load ptr, ptr %t230, !tbaa !27
  %t232 = load i64, ptr %l76, !tbaa !24
  %t233 = mul i64 %t232, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t229, ptr %t231, i64 %t233, i1 false)
  br label %bb18
bb17:
  %t234 = load { i64, ptr }, ptr %l74, !tbaa !27
  store { i64, ptr } %t234, ptr %l7, !tbaa !27
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s3)
  br label %bb19
bb19:
  %t235 = load i64, ptr %l12, !tbaa !24
  %t237 = add i64 %t235, 1
  store i64 %t237, ptr %l12, !tbaa !24
  br label %bb9
bb20:
  %t239 = load ptr, ptr %l1, !tbaa !29
  %t240 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t241 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d186, i32 0, i32 1) }, 1
  %t242 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d186, i32 0, i32 1) }, 0
  %t244 = extractvalue { i64, ptr } %t240, 1
  %t245 = extractvalue { i64, ptr } %t240, 0
  %t246 = add i64 %t242, %t245
  %t247 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d187, i32 0, i32 1) }, 1
  %t248 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d187, i32 0, i32 1) }, 0
  %t249 = add i64 %t246, %t248
  %t250 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t249)
  call void @olang_textcopy(ptr %t250, ptr %t241, i64 %t242)
  %t251 = getelementptr i8, ptr %t250, i64 %t242
  call void @olang_textcopy(ptr %t251, ptr %t244, i64 %t245)
  %t252 = getelementptr i8, ptr %t251, i64 %t245
  call void @olang_textcopy(ptr %t252, ptr %t247, i64 %t248)
  %t253 = insertvalue { i64, ptr } undef, i64 %t249, 0
  %t254 = insertvalue { i64, ptr } %t253, ptr %t250, 1
  %t256 = extractvalue { i64, ptr } %t254, 0
  %t257 = extractvalue { i64, ptr } %t254, 1
  %t258 = mul i64 %t256, 1
  %t259 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t258)
  call void @llvm.memcpy.p0.p0.i64(ptr %t259, ptr %t257, i64 %t258, i1 false)
  %t260 = insertvalue { i64, ptr } undef, i64 %t256, 0
  %t261 = insertvalue { i64, ptr } %t260, ptr %t259, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s0, ptr %t239, { i64, ptr } %t261)
  br label %bb21
bb21:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d188, i32 0, i32 1) }, ptr %l84, !tbaa !27
  %t264 = load { i64, ptr }, ptr %l84, !tbaa !27
  store { i64, ptr } %t264, ptr %l85, !tbaa !27
  %t265 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t266 = extractvalue { i64, ptr } %t265, 0
  store i64 %t266, ptr %l86, !tbaa !24
  %t267 = load i64, ptr %l86, !tbaa !24
  %t268 = mul i64 %t267, 1
  %t269 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t268)
  %t270 = insertvalue { i64, ptr } undef, i64 %t267, 0
  %t271 = insertvalue { i64, ptr } %t270, ptr %t269, 1
  store { i64, ptr } %t271, ptr %l87, !tbaa !27
  %t272 = getelementptr { i64, ptr }, ptr %l87, i32 0, i32 1
  %t273 = load ptr, ptr %t272, !tbaa !27
  %t274 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t275 = load ptr, ptr %t274, !tbaa !27
  %t276 = load i64, ptr %l86, !tbaa !24
  %t277 = mul i64 %t276, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t273, ptr %t275, i64 %t277, i1 false)
  %t278 = load { i64, ptr }, ptr %l87, !tbaa !27
  store { i64, ptr } %t278, ptr %l85, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t279 = load { i64, ptr }, ptr %l85, !tbaa !27
  store { i64, ptr } %t279, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2estub(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l9 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t5 = extractvalue { i64, ptr } %a1, 1
  %t6 = extractvalue { i64, ptr } %a1, 0
  %t7 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d189, i32 0, i32 1) }, 1
  %t8 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d189, i32 0, i32 1) }, 0
  %t9 = add i64 %t6, %t8
  %t11 = extractvalue { i64, ptr } %a2, 1
  %t12 = extractvalue { i64, ptr } %a2, 0
  %t13 = add i64 %t9, %t12
  %t14 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d190, i32 0, i32 1) }, 1
  %t15 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d190, i32 0, i32 1) }, 0
  %t16 = add i64 %t13, %t15
  %t17 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t16)
  call void @olang_textcopy(ptr %t17, ptr %t5, i64 %t6)
  %t18 = getelementptr i8, ptr %t17, i64 %t6
  call void @olang_textcopy(ptr %t18, ptr %t7, i64 %t8)
  %t19 = getelementptr i8, ptr %t18, i64 %t8
  call void @olang_textcopy(ptr %t19, ptr %t11, i64 %t12)
  %t20 = getelementptr i8, ptr %t19, i64 %t12
  call void @olang_textcopy(ptr %t20, ptr %t14, i64 %t15)
  %t21 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t17, 1
  %t24 = extractvalue { i64, ptr } %t22, 0
  %t25 = extractvalue { i64, ptr } %t22, 1
  %t26 = mul i64 %t24, 1
  %t27 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t26)
  call void @llvm.memcpy.p0.p0.i64(ptr %t27, ptr %t25, i64 %t26, i1 false)
  %t28 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t27, 1
  %t32 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecstr(ptr %v0, ptr %s0, ptr %s0, ptr %a0, { i64, ptr } %t29)
  store { i64, ptr } %t32, ptr %l9
  br label %bb1
bb1:
  %t33 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t35 = extractvalue { i64, ptr } { i64 45, ptr getelementptr inbounds (<{ i64, [45 x i8] }>, ptr @.d191, i32 0, i32 1) }, 1
  %t36 = extractvalue { i64, ptr } { i64 45, ptr getelementptr inbounds (<{ i64, [45 x i8] }>, ptr @.d191, i32 0, i32 1) }, 0
  %t38 = extractvalue { i64, ptr } %t33, 1
  %t39 = extractvalue { i64, ptr } %t33, 0
  %t40 = add i64 %t36, %t39
  %t41 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d192, i32 0, i32 1) }, 1
  %t42 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d192, i32 0, i32 1) }, 0
  %t43 = add i64 %t40, %t42
  %t44 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t43)
  call void @olang_textcopy(ptr %t44, ptr %t35, i64 %t36)
  %t45 = getelementptr i8, ptr %t44, i64 %t36
  call void @olang_textcopy(ptr %t45, ptr %t38, i64 %t39)
  %t46 = getelementptr i8, ptr %t45, i64 %t39
  call void @olang_textcopy(ptr %t46, ptr %t41, i64 %t42)
  %t47 = insertvalue { i64, ptr } undef, i64 %t43, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t44, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t48, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { { i64, ptr }, i32 } @compiler_2femit_2ecompiler_2femit_3afnEm_2eaddr(ptr %v0, ptr %v1, ptr %a0, %"compiler/mir:Lvalue" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/mir:Lvalue"
  %l2 = alloca ptr
  %lp3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i1
  %l6 = alloca i1
  %l7 = alloca { i64, [2 x i64] }
  %l8 = alloca i32
  %l9 = alloca i64
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca i32
  %l14 = alloca i32
  %l15 = alloca i32
  %l16 = alloca i32
  %l18 = alloca { i64, [1 x i64] }
  %l19 = alloca i32
  %l20 = alloca i64
  %l21 = alloca { i64, ptr }
  %l22 = alloca i32
  %l23 = alloca i32
  %l24 = alloca { i64, ptr }
  %l25 = alloca { { i64, ptr }, i32 }
  %l26 = alloca i64
  %l27 = alloca { { i64, ptr }, i32 }
  %l28 = alloca i32
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l35 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l37 = alloca i64
  %l38 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l48 = alloca i64
  %l52 = alloca i32
  %l63 = alloca { i64, ptr }
  %l65 = alloca i64
  %l75 = alloca i32
  %l78 = alloca i32
  %l104 = alloca { i64, [1 x i64] }
  %l107 = alloca i32
  %l111 = alloca ptr
  %l114 = alloca i32
  %l115 = alloca { i64, ptr }
  %l116 = alloca ptr
  %l119 = alloca { i64, ptr }
  %l124 = alloca { i64, ptr }
  %l126 = alloca i64
  %l128 = alloca { i64, ptr }
  %l136 = alloca i32
  %l137 = alloca ptr
  %l138 = alloca ptr
  %l141 = alloca { i64, ptr }
  %l142 = alloca { i64, ptr }
  %l145 = alloca { i64, ptr }
  %l146 = alloca { i64, ptr }
  %l150 = alloca { i64, ptr }
  %l152 = alloca { i64, ptr }
  %l155 = alloca { i64, ptr }
  %l158 = alloca i1
  %l159 = alloca ptr
  %l160 = alloca { i64, ptr }
  %l161 = alloca i32
  %l162 = alloca { i64, ptr }
  %l167 = alloca { i64, ptr }
  %l169 = alloca { { i64, ptr }, i32 }
  %l170 = alloca { i64, ptr }
  %l172 = alloca i64
  %l174 = alloca i64
  %l175 = alloca { i64, ptr }
  %l182 = alloca i1
  %l183 = alloca ptr
  %l184 = alloca { i64, ptr }
  %l185 = alloca i32
  %l188 = alloca { i64, ptr }
  %l193 = alloca { i64, ptr }
  %l195 = alloca { { i64, ptr }, i32 }
  %l196 = alloca { i64, ptr }
  %l198 = alloca i64
  %l200 = alloca i64
  %l201 = alloca { i64, ptr }
  %l207 = alloca i32
  %l209 = alloca { i64, ptr }
  %l214 = alloca { i64, ptr }
  %l219 = alloca i1
  %l223 = alloca { i64, ptr }
  %l225 = alloca i64
  %l230 = alloca ptr
  %l233 = alloca { i64, ptr }
  %l237 = alloca { i64, ptr }
  %l239 = alloca i64
  %l241 = alloca ptr
  %l244 = alloca i32
  %l245 = alloca { i64, ptr }
  %l246 = alloca { i64, ptr }
  %l251 = alloca ptr
  %l253 = alloca { i64, ptr }
  %l258 = alloca { i64, ptr }
  %l260 = alloca { i64, ptr }
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %rv = alloca { { i64, ptr }, i32 }
  store ptr %a0, ptr %l0
  store %"compiler/mir:Lvalue" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/emit:Emitter", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l2, !tbaa !29
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d193, i32 0, i32 1) }, ptr %l35, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t9, ptr %l36, !tbaa !27
  %t10 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t10, 0
  store i64 %t11, ptr %l37, !tbaa !24
  %t12 = load i64, ptr %l37, !tbaa !24
  %t13 = mul i64 %t12, 1
  %t14 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t13)
  %t15 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr %t14, 1
  store { i64, ptr } %t16, ptr %l38, !tbaa !27
  %t17 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !27
  %t19 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !27
  %t21 = load i64, ptr %l37, !tbaa !24
  %t22 = mul i64 %t21, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t18, ptr %t20, i64 %t22, i1 false)
  %t23 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t23, ptr %lp3
  %t24 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t25 = load ptr, ptr %lp3
  store { i64, ptr } %t24, ptr %t25, !tbaa !27
  %t26 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t26, ptr %l4, !tbaa !23
  store i1 false, ptr %l5, !tbaa !21
  store i1 false, ptr %l6, !tbaa !21
  %t28 = getelementptr %"compiler/mir:Lvalue", ptr %l1, i32 0, i32 0
  %t29 = load { i64, [2 x i64] }, ptr %t28
  store { i64, [2 x i64] } %t29, ptr %l7
  %t31 = load { i64, [2 x i64] }, ptr %l7
  %t33 = extractvalue { i64, [2 x i64] } %t31, 0
  %t34 = icmp eq i64 %t33, 1
  br i1 %t34, label %bb1, label %bb2
bb1:
  %t36 = getelementptr { i64, [2 x i64] }, ptr %l7, i32 0, i32 1
  %t37 = getelementptr { i32 }, ptr %t36, i32 0, i32 0
  %t38 = load i32, ptr %t37
  store i32 %t38, ptr %l8, !tbaa !23
  br label %bb3
bb2:
  br label %bb9
bb3:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load i32, ptr %l8, !tbaa !23
  %t44 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elocalAt(ptr %v0, ptr %v1, ptr %t40, i32 %t41)
  store { i64, ptr } %t44, ptr %l46
  br label %bb4
bb4:
  %t45 = load ptr, ptr %lp3
  %t46 = load { i64, ptr }, ptr %t45, !tbaa !27
  %t47 = extractvalue { i64, ptr } %t46, 0
  %t48 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t48, 0
  store i64 %t49, ptr %l48, !tbaa !24
  %t51 = load i64, ptr %l48, !tbaa !24
  %t52 = icmp eq i64 %t47, %t51
  br i1 %t52, label %bb5, label %bb6
bb5:
  %t54 = load ptr, ptr %lp3
  %t55 = getelementptr { i64, ptr }, ptr %t54, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !27
  %t57 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !27
  %t59 = load i64, ptr %l48, !tbaa !24
  %t60 = mul i64 %t59, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t56, ptr %t58, i64 %t60, i1 false)
  br label %bb7
bb6:
  %t61 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t62 = load ptr, ptr %lp3
  store { i64, ptr } %t61, ptr %t62, !tbaa !27
  br label %bb7
bb7:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = load i32, ptr %l8, !tbaa !23
  %t67 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2elocalType(ptr %v0, ptr %t63, i32 %t64)
  store i32 %t67, ptr %l52
  br label %bb8
bb8:
  %t68 = load i32, ptr %l52, !tbaa !23
  store i32 %t68, ptr %l4, !tbaa !23
  br label %bb23
bb9:
  %t69 = load { i64, [2 x i64] }, ptr %l7
  %t71 = extractvalue { i64, [2 x i64] } %t69, 0
  %t72 = icmp eq i64 %t71, 2
  br i1 %t72, label %bb10, label %bb11
bb10:
  %t74 = getelementptr { i64, [2 x i64] }, ptr %l7, i32 0, i32 1
  %t75 = getelementptr { i64, i32, i32 }, ptr %t74, i32 0, i32 0
  %t76 = load i64, ptr %t75
  store i64 %t76, ptr %l9, !tbaa !24
  %t78 = getelementptr { i64, [2 x i64] }, ptr %l7, i32 0, i32 1
  %t79 = getelementptr { i64, i32, i32 }, ptr %t78, i32 0, i32 1
  %t80 = load i32, ptr %t79
  store i32 %t80, ptr %l10, !tbaa !23
  %t82 = getelementptr { i64, [2 x i64] }, ptr %l7, i32 0, i32 1
  %t83 = getelementptr { i64, i32, i32 }, ptr %t82, i32 0, i32 2
  %t84 = load i32, ptr %t83
  store i32 %t84, ptr %l11, !tbaa !23
  br label %bb12
bb11:
  br label %bb17
bb12:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/emit:fnEm", ptr %t86, i32 0, i32 0
  %t89 = load ptr, ptr %t88, !tbaa !29
  %t90 = load i64, ptr %l9, !tbaa !24
  %t91 = load i32, ptr %l10, !tbaa !23
  %t92 = load i32, ptr %l11, !tbaa !23
  %t97 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eglobal(ptr %v0, ptr %v1, ptr %t89, i64 %t90, i32 %t91, i32 %t92)
  store { i64, ptr } %t97, ptr %l63
  br label %bb13
bb13:
  %t98 = load ptr, ptr %lp3
  %t99 = load { i64, ptr }, ptr %t98, !tbaa !27
  %t100 = extractvalue { i64, ptr } %t99, 0
  %t101 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t102 = extractvalue { i64, ptr } %t101, 0
  store i64 %t102, ptr %l65, !tbaa !24
  %t104 = load i64, ptr %l65, !tbaa !24
  %t105 = icmp eq i64 %t100, %t104
  br i1 %t105, label %bb14, label %bb15
bb14:
  %t107 = load ptr, ptr %lp3
  %t108 = getelementptr { i64, ptr }, ptr %t107, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !27
  %t110 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !27
  %t112 = load i64, ptr %l65, !tbaa !24
  %t113 = mul i64 %t112, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t109, ptr %t111, i64 %t113, i1 false)
  br label %bb16
bb15:
  %t114 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t115 = load ptr, ptr %lp3
  store { i64, ptr } %t114, ptr %t115, !tbaa !27
  br label %bb16
bb16:
  %t116 = load i32, ptr %l11, !tbaa !23
  store i32 %t116, ptr %l4, !tbaa !23
  br label %bb23
bb17:
  %t118 = load { i64, [2 x i64] }, ptr %l7
  %t120 = extractvalue { i64, [2 x i64] } %t118, 0
  %t121 = icmp eq i64 %t120, 0
  br i1 %t121, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb22
bb20:
  store %olang.scope zeroinitializer, ptr %s3
  %t123 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2egap(ptr %v0, ptr %s3, ptr %t123, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d194, i32 0, i32 1) })
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s3)
  br label %bb23
bb22:
  call void @__olang_check_failed(ptr @olang_loc_a45e6d34f8d75be7_fb9ba052a05cfc3b)
  unreachable
bb23:
  store i32 0, ptr %l12, !tbaa !23
  %t125 = getelementptr %"compiler/mir:Lvalue", ptr %l1, i32 0, i32 1
  %t126 = getelementptr %"compiler/mir:Range", ptr %t125, i32 0, i32 1
  %t127 = load i32, ptr %t126, !tbaa !23
  store i32 %t127, ptr %l13, !tbaa !23
  store i32 1, ptr %l14, !tbaa !23
  %t129 = load i32, ptr %l13, !tbaa !23
  %t130 = load i32, ptr %l12, !tbaa !23
  %t133 = icmp sgt i32 %t129, %t130
  br i1 %t133, label %bb24, label %bb25
bb24:
  %t135 = load i32, ptr %l14, !tbaa !23
  %t137 = icmp sgt i32 %t135, 0
  br i1 %t137, label %bb26, label %bb27
bb25:
  store i32 0, ptr %l75, !tbaa !23
  br label %bb29
bb26:
  %t139 = load i32, ptr %l13, !tbaa !23
  %t140 = load i32, ptr %l12, !tbaa !23
  %t143 = sub i32 %t139, %t140
  %t144 = load i32, ptr %l14, !tbaa !23
  %t147 = add i32 %t143, %t144
  %t149 = sub i32 %t147, 1
  %t150 = load i32, ptr %l14, !tbaa !23
  %t153 = sdiv i32 %t149, %t150
  store i32 %t153, ptr %l78, !tbaa !23
  br label %bb28
bb27:
  store i32 0, ptr %l78, !tbaa !23
  br label %bb28
bb28:
  %t155 = load i32, ptr %l78, !tbaa !23
  store i32 %t155, ptr %l75, !tbaa !23
  br label %bb29
bb29:
  %t156 = load i32, ptr %l75, !tbaa !23
  store i32 %t156, ptr %l15, !tbaa !23
  store i32 0, ptr %l16, !tbaa !23
  br label %bb30
bb30:
  %t157 = load i32, ptr %l16, !tbaa !23
  %t158 = load i32, ptr %l15, !tbaa !23
  %t161 = icmp slt i32 %t157, %t158
  %t163 = xor i1 %t161, true
  br i1 %t163, label %bb31, label %bb32
bb31:
  br label %bb109
bb32:
  br label %bb33
bb33:
  %t165 = load i32, ptr %l12, !tbaa !23
  %t166 = load i32, ptr %l16, !tbaa !23
  %t167 = load i32, ptr %l14, !tbaa !23
  %t170 = mul i32 %t166, %t167
  %t173 = add i32 %t165, %t170
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t177 = getelementptr %"compiler/emit:fnEm", ptr %t175, i32 0, i32 1
  %t178 = load ptr, ptr %t177, !tbaa !29
  %t180 = getelementptr %"compiler/mir:Fn", ptr %t178, i32 0, i32 10
  %t181 = getelementptr %"compiler/mir:Lvalue", ptr %l1, i32 0, i32 1
  %t182 = getelementptr %"compiler/mir:Range", ptr %t181, i32 0, i32 0
  %t183 = load i32, ptr %t182, !tbaa !23
  %t185 = sext i32 %t183 to i64
  %t188 = sext i32 %t173 to i64
  %t191 = add i64 %t185, %t188
  %t194 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e_2eAt_3ccompiler_2fmir_3aProj_3e(ptr %v0, ptr %t180, i64 %t191)
  store { i64, [1 x i64] } %t194, ptr %l104
  br label %bb34
bb34:
  %t195 = load { i64, [1 x i64] }, ptr %l104
  store { i64, [1 x i64] } %t195, ptr %l18
  %t196 = load ptr, ptr %l2, !tbaa !29
  %t197 = load i32, ptr %l4, !tbaa !23
  %t200 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t196, i32 %t197)
  store i32 %t200, ptr %l107
  br label %bb35
bb35:
  %t201 = load i32, ptr %l107, !tbaa !23
  store i32 %t201, ptr %l19, !tbaa !23
  %t202 = load { i64, [1 x i64] }, ptr %l18
  %t204 = extractvalue { i64, [1 x i64] } %t202, 0
  %t205 = icmp eq i64 %t204, 0
  br i1 %t205, label %bb36, label %bb37
bb36:
  %t207 = getelementptr { i64, [1 x i64] }, ptr %l18, i32 0, i32 1
  %t208 = getelementptr { i64 }, ptr %t207, i32 0, i32 0
  %t209 = load i64, ptr %t208
  store i64 %t209, ptr %l20, !tbaa !24
  br label %bb38
bb37:
  br label %bb46
bb38:
  store %olang.scope zeroinitializer, ptr %s6
  %t211 = load ptr, ptr %l2, !tbaa !29
  store ptr %t211, ptr %l111, !tbaa !29
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t213 = load i32, ptr %l19, !tbaa !23
  %t216 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2efieldList(ptr %v0, ptr %t212, i32 %t213)
  store i32 %t216, ptr %l114
  br label %bb39
bb39:
  %t217 = load ptr, ptr %l111, !tbaa !29
  %t218 = load i32, ptr %l114, !tbaa !23
  %t219 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t217, i32 %t218)
  store { i64, ptr } %t219, ptr %l115
  br label %bb40
bb40:
  %t220 = load { i64, ptr }, ptr %l115, !tbaa !27
  store { i64, ptr } %t220, ptr %l21, !tbaa !27
  %t221 = load ptr, ptr %l0, !tbaa !29
  store ptr %t221, ptr %l116, !tbaa !29
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t223 = load i32, ptr %l19, !tbaa !23
  %t226 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s6, ptr %t222, i32 %t223)
  store { i64, ptr } %t226, ptr %l119
  br label %bb41
bb41:
  %t227 = load ptr, ptr %lp3
  %t228 = load { i64, ptr }, ptr %t227, !tbaa !27
  %t229 = load i64, ptr %l20, !tbaa !24
  %t230 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d195, i32 0, i32 1) }, 1
  %t231 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d195, i32 0, i32 1) }, 0
  %t232 = load { i64, ptr }, ptr %l119, !tbaa !27
  %t233 = extractvalue { i64, ptr } %t232, 1
  %t234 = extractvalue { i64, ptr } %t232, 0
  %t235 = add i64 %t231, %t234
  %t236 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d196, i32 0, i32 1) }, 1
  %t237 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d196, i32 0, i32 1) }, 0
  %t238 = add i64 %t235, %t237
  %t240 = extractvalue { i64, ptr } %t228, 1
  %t241 = extractvalue { i64, ptr } %t228, 0
  %t242 = add i64 %t238, %t241
  %t243 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d197, i32 0, i32 1) }, 1
  %t244 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d197, i32 0, i32 1) }, 0
  %t245 = add i64 %t242, %t244
  %t247 = call i64 @__olang_fmt_i64(ptr null, i64 %t229)
  %t248 = add i64 %t245, %t247
  %t249 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t248)
  call void @olang_textcopy(ptr %t249, ptr %t230, i64 %t231)
  %t250 = getelementptr i8, ptr %t249, i64 %t231
  call void @olang_textcopy(ptr %t250, ptr %t233, i64 %t234)
  %t251 = getelementptr i8, ptr %t250, i64 %t234
  call void @olang_textcopy(ptr %t251, ptr %t236, i64 %t237)
  %t252 = getelementptr i8, ptr %t251, i64 %t237
  call void @olang_textcopy(ptr %t252, ptr %t240, i64 %t241)
  %t253 = getelementptr i8, ptr %t252, i64 %t241
  call void @olang_textcopy(ptr %t253, ptr %t243, i64 %t244)
  %t254 = getelementptr i8, ptr %t253, i64 %t244
  %t255 = call i64 @__olang_fmt_i64(ptr %t254, i64 %t229)
  %t256 = insertvalue { i64, ptr } undef, i64 %t248, 0
  %t257 = insertvalue { i64, ptr } %t256, ptr %t249, 1
  %t259 = extractvalue { i64, ptr } %t257, 0
  %t260 = extractvalue { i64, ptr } %t257, 1
  %t261 = mul i64 %t259, 1
  %t262 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t261)
  call void @llvm.memcpy.p0.p0.i64(ptr %t262, ptr %t260, i64 %t261, i1 false)
  %t263 = insertvalue { i64, ptr } undef, i64 %t259, 0
  %t264 = insertvalue { i64, ptr } %t263, ptr %t262, 1
  %t265 = load ptr, ptr %l116, !tbaa !29
  %t267 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v1, ptr %t265, { i64, ptr } %t264)
  store { i64, ptr } %t267, ptr %l124
  br label %bb42
bb42:
  %t268 = load ptr, ptr %lp3
  %t269 = load { i64, ptr }, ptr %t268, !tbaa !27
  %t270 = extractvalue { i64, ptr } %t269, 0
  %t271 = load { i64, ptr }, ptr %l124, !tbaa !27
  %t272 = extractvalue { i64, ptr } %t271, 0
  store i64 %t272, ptr %l126, !tbaa !24
  %t274 = load i64, ptr %l126, !tbaa !24
  %t275 = icmp eq i64 %t270, %t274
  br i1 %t275, label %bb43, label %bb44
bb43:
  %t277 = load ptr, ptr %lp3
  %t278 = getelementptr { i64, ptr }, ptr %t277, i32 0, i32 1
  %t279 = load ptr, ptr %t278, !tbaa !27
  %t280 = getelementptr { i64, ptr }, ptr %l124, i32 0, i32 1
  %t281 = load ptr, ptr %t280, !tbaa !27
  %t282 = load i64, ptr %l126, !tbaa !24
  %t283 = mul i64 %t282, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t279, ptr %t281, i64 %t283, i1 false)
  br label %bb45
bb44:
  %t284 = load { i64, ptr }, ptr %l124, !tbaa !27
  %t285 = load ptr, ptr %lp3
  store { i64, ptr } %t284, ptr %t285, !tbaa !27
  br label %bb45
bb45:
  %t286 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t286, ptr %l128, !tbaa !27
  %t287 = load i64, ptr %l20, !tbaa !24
  %t289 = getelementptr { i64, ptr }, ptr %l128, i32 0, i32 1
  %t290 = load ptr, ptr %t289, !tbaa !27
  %t291 = getelementptr i32, ptr %t290, i64 %t287
  %t292 = load i32, ptr %t291, !tbaa !33
  store i32 %t292, ptr %l4, !tbaa !23
  store i1 false, ptr %l5, !tbaa !21
  call void @__olang_scope_close(ptr %s6)
  br label %bb107
bb46:
  %t294 = load { i64, [1 x i64] }, ptr %l18
  %t296 = extractvalue { i64, [1 x i64] } %t294, 0
  %t297 = icmp eq i64 %t296, 1
  br i1 %t297, label %bb47, label %bb48
bb47:
  %t299 = getelementptr { i64, [1 x i64] }, ptr %l18, i32 0, i32 1
  %t300 = getelementptr { i32 }, ptr %t299, i32 0, i32 0
  %t301 = load i32, ptr %t300
  store i32 %t301, ptr %l22, !tbaa !23
  br label %bb49
bb48:
  br label %bb65
bb49:
  store %olang.scope zeroinitializer, ptr %s8
  %t303 = load ptr, ptr %l0, !tbaa !29
  %t304 = load i32, ptr %l22, !tbaa !23
  %t307 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2elocalType(ptr %v0, ptr %t303, i32 %t304)
  store i32 %t307, ptr %l136
  br label %bb50
bb50:
  %t308 = load i32, ptr %l136, !tbaa !23
  store i32 %t308, ptr %l23, !tbaa !23
  %t309 = load ptr, ptr %l0, !tbaa !29
  store ptr %t309, ptr %l137, !tbaa !29
  %t310 = load ptr, ptr %l0, !tbaa !29
  store ptr %t310, ptr %l138, !tbaa !29
  %t311 = load ptr, ptr %l0, !tbaa !29
  %t312 = load i32, ptr %l23, !tbaa !23
  %t315 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s8, ptr %t311, i32 %t312)
  store { i64, ptr } %t315, ptr %l141
  br label %bb51
bb51:
  %t316 = load { i64, ptr }, ptr %l141, !tbaa !27
  %t317 = extractvalue { i64, ptr } %t316, 0
  %t318 = extractvalue { i64, ptr } %t316, 1
  %t319 = mul i64 %t317, 1
  %t320 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t319)
  call void @llvm.memcpy.p0.p0.i64(ptr %t320, ptr %t318, i64 %t319, i1 false)
  %t321 = insertvalue { i64, ptr } undef, i64 %t317, 0
  %t322 = insertvalue { i64, ptr } %t321, ptr %t320, 1
  store { i64, ptr } %t322, ptr %l142, !tbaa !27
  %t323 = load ptr, ptr %l0, !tbaa !29
  %t324 = load i32, ptr %l22, !tbaa !23
  %t327 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elocalAt(ptr %v0, ptr %s8, ptr %t323, i32 %t324)
  store { i64, ptr } %t327, ptr %l145
  br label %bb52
bb52:
  %t328 = load { i64, ptr }, ptr %l145, !tbaa !27
  %t329 = extractvalue { i64, ptr } %t328, 0
  %t330 = extractvalue { i64, ptr } %t328, 1
  %t331 = mul i64 %t329, 1
  %t332 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t331)
  call void @llvm.memcpy.p0.p0.i64(ptr %t332, ptr %t330, i64 %t331, i1 false)
  %t333 = insertvalue { i64, ptr } undef, i64 %t329, 0
  %t334 = insertvalue { i64, ptr } %t333, ptr %t332, 1
  store { i64, ptr } %t334, ptr %l146, !tbaa !27
  %t335 = load ptr, ptr %l0, !tbaa !29
  %t337 = getelementptr %"compiler/emit:fnEm", ptr %t335, i32 0, i32 0
  %t338 = load ptr, ptr %t337, !tbaa !29
  %t339 = load i32, ptr %l23, !tbaa !23
  %t342 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etbaa(ptr %v0, ptr %s8, ptr %t338, i32 %t339, i1 false)
  store { i64, ptr } %t342, ptr %l150
  br label %bb53
bb53:
  %t343 = load { i64, ptr }, ptr %l150, !tbaa !27
  %t344 = extractvalue { i64, ptr } %t343, 0
  %t345 = extractvalue { i64, ptr } %t343, 1
  %t346 = mul i64 %t344, 1
  %t347 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t346)
  call void @llvm.memcpy.p0.p0.i64(ptr %t347, ptr %t345, i64 %t346, i1 false)
  %t348 = insertvalue { i64, ptr } undef, i64 %t344, 0
  %t349 = insertvalue { i64, ptr } %t348, ptr %t347, 1
  %t350 = load ptr, ptr %l138, !tbaa !29
  %t351 = load { i64, ptr }, ptr %l142, !tbaa !27
  %t352 = load { i64, ptr }, ptr %l146, !tbaa !27
  %t354 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %s8, ptr %s8, ptr %s8, ptr %s8, ptr %t350, { i64, ptr } %t351, { i64, ptr } %t352, { i64, ptr } %t349)
  store { i64, ptr } %t354, ptr %l152
  br label %bb54
bb54:
  %t355 = load { i64, ptr }, ptr %l152, !tbaa !27
  %t356 = extractvalue { i64, ptr } %t355, 0
  %t357 = extractvalue { i64, ptr } %t355, 1
  %t358 = mul i64 %t356, 1
  %t359 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t358)
  call void @llvm.memcpy.p0.p0.i64(ptr %t359, ptr %t357, i64 %t358, i1 false)
  %t360 = insertvalue { i64, ptr } undef, i64 %t356, 0
  %t361 = insertvalue { i64, ptr } %t360, ptr %t359, 1
  %t362 = load i32, ptr %l23, !tbaa !23
  %t363 = load ptr, ptr %l137, !tbaa !29
  %t366 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eindex(ptr %v0, ptr %s8, ptr %s8, ptr %t363, { i64, ptr } %t361, i32 %t362)
  store { i64, ptr } %t366, ptr %l155
  br label %bb55
bb55:
  %t367 = load { i64, ptr }, ptr %l155, !tbaa !27
  store { i64, ptr } %t367, ptr %l24, !tbaa !27
  %t368 = load ptr, ptr %l0, !tbaa !29
  %t369 = load i32, ptr %l4, !tbaa !23
  %t372 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2erunTime(ptr %v0, ptr %t368, i32 %t369)
  store i1 %t372, ptr %l158
  br label %bb56
bb56:
  %t373 = load i1, ptr %l158, !tbaa !21
  br i1 %t373, label %bb57, label %bb58
bb57:
  store i1 false, ptr %l6, !tbaa !21
  br label %bb59
bb58:
  br label %bb59
bb59:
  %t374 = load ptr, ptr %l0, !tbaa !29
  store ptr %t374, ptr %l159, !tbaa !29
  %t375 = load ptr, ptr %lp3
  %t376 = load { i64, ptr }, ptr %t375, !tbaa !27
  store { i64, ptr } %t376, ptr %l160, !tbaa !27
  %t377 = load i32, ptr %l4, !tbaa !23
  store i32 %t377, ptr %l161, !tbaa !23
  %t378 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t378, ptr %l162, !tbaa !27
  %t379 = load ptr, ptr %l0, !tbaa !29
  %t381 = getelementptr %"compiler/emit:fnEm", ptr %t379, i32 0, i32 0
  %t382 = load ptr, ptr %t381, !tbaa !29
  %t383 = load i1, ptr %l5, !tbaa !21
  %t384 = load i1, ptr %l6, !tbaa !21
  %t388 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2edescTag(ptr %v0, ptr %s8, ptr %t382, i1 %t383, i1 %t384)
  store { i64, ptr } %t388, ptr %l167
  br label %bb60
bb60:
  %t389 = load { i64, ptr }, ptr %l167, !tbaa !27
  %t390 = extractvalue { i64, ptr } %t389, 0
  %t391 = extractvalue { i64, ptr } %t389, 1
  %t392 = mul i64 %t390, 1
  %t393 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t392)
  call void @llvm.memcpy.p0.p0.i64(ptr %t393, ptr %t391, i64 %t392, i1 false)
  %t394 = insertvalue { i64, ptr } undef, i64 %t390, 0
  %t395 = insertvalue { i64, ptr } %t394, ptr %t393, 1
  %t396 = load ptr, ptr %l159, !tbaa !29
  %t397 = load { i64, ptr }, ptr %l160, !tbaa !27
  %t398 = load i32, ptr %l161, !tbaa !23
  %t399 = load { i64, ptr }, ptr %l162, !tbaa !27
  %t401 = call { { i64, ptr }, i32 } @compiler_2femit_2ecompiler_2femit_3afnEm_2eelemAt(ptr %v0, ptr %v1, ptr %s8, ptr %s8, ptr %s8, ptr %t396, { i64, ptr } %t397, i32 %t398, { i64, ptr } %t399, { i64, ptr } %t395)
  store { { i64, ptr }, i32 } %t401, ptr %l169
  br label %bb61
bb61:
  %t402 = load { { i64, ptr }, i32 }, ptr %l169
  store { { i64, ptr }, i32 } %t402, ptr %l25
  %t403 = getelementptr { { i64, ptr }, i32 }, ptr %l25, i32 0, i32 0
  %t404 = load { i64, ptr }, ptr %t403, !tbaa !27
  store { i64, ptr } %t404, ptr %l170, !tbaa !27
  %t405 = load ptr, ptr %lp3
  %t406 = load { i64, ptr }, ptr %t405, !tbaa !27
  %t407 = extractvalue { i64, ptr } %t406, 0
  %t408 = load { i64, ptr }, ptr %l170, !tbaa !27
  %t409 = extractvalue { i64, ptr } %t408, 0
  store i64 %t409, ptr %l172, !tbaa !24
  %t411 = load i64, ptr %l172, !tbaa !24
  %t412 = icmp eq i64 %t407, %t411
  br i1 %t412, label %bb62, label %bb63
bb62:
  %t414 = load ptr, ptr %lp3
  %t415 = getelementptr { i64, ptr }, ptr %t414, i32 0, i32 1
  %t416 = load ptr, ptr %t415, !tbaa !27
  %t417 = getelementptr { i64, ptr }, ptr %l170, i32 0, i32 1
  %t418 = load ptr, ptr %t417, !tbaa !27
  %t419 = load i64, ptr %l172, !tbaa !24
  %t420 = mul i64 %t419, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t416, ptr %t418, i64 %t420, i1 false)
  br label %bb64
bb63:
  %t421 = load { i64, ptr }, ptr %l170, !tbaa !27
  %t422 = extractvalue { i64, ptr } %t421, 0
  store i64 %t422, ptr %l174, !tbaa !24
  %t423 = load i64, ptr %l174, !tbaa !24
  %t424 = mul i64 %t423, 1
  %t425 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t424)
  %t426 = insertvalue { i64, ptr } undef, i64 %t423, 0
  %t427 = insertvalue { i64, ptr } %t426, ptr %t425, 1
  store { i64, ptr } %t427, ptr %l175, !tbaa !27
  %t428 = getelementptr { i64, ptr }, ptr %l175, i32 0, i32 1
  %t429 = load ptr, ptr %t428, !tbaa !27
  %t430 = getelementptr { i64, ptr }, ptr %l170, i32 0, i32 1
  %t431 = load ptr, ptr %t430, !tbaa !27
  %t432 = load i64, ptr %l174, !tbaa !24
  %t433 = mul i64 %t432, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t429, ptr %t431, i64 %t433, i1 false)
  %t434 = load { i64, ptr }, ptr %l175, !tbaa !27
  %t435 = load ptr, ptr %lp3
  store { i64, ptr } %t434, ptr %t435, !tbaa !27
  br label %bb64
bb64:
  %t436 = getelementptr { { i64, ptr }, i32 }, ptr %l25, i32 0, i32 1
  %t437 = load i32, ptr %t436, !tbaa !23
  store i32 %t437, ptr %l4, !tbaa !23
  store i1 true, ptr %l5, !tbaa !21
  call void @__olang_scope_close(ptr %s8)
  br label %bb107
bb65:
  %t439 = load { i64, [1 x i64] }, ptr %l18
  %t441 = extractvalue { i64, [1 x i64] } %t439, 0
  %t442 = icmp eq i64 %t441, 2
  br i1 %t442, label %bb66, label %bb67
bb66:
  %t444 = getelementptr { i64, [1 x i64] }, ptr %l18, i32 0, i32 1
  %t445 = getelementptr { i64 }, ptr %t444, i32 0, i32 0
  %t446 = load i64, ptr %t445
  store i64 %t446, ptr %l26, !tbaa !24
  br label %bb68
bb67:
  br label %bb78
bb68:
  store %olang.scope zeroinitializer, ptr %s10
  %t448 = load ptr, ptr %l0, !tbaa !29
  %t449 = load i32, ptr %l4, !tbaa !23
  %t452 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2erunTime(ptr %v0, ptr %t448, i32 %t449)
  store i1 %t452, ptr %l182
  br label %bb69
bb69:
  %t453 = load i1, ptr %l182, !tbaa !21
  br i1 %t453, label %bb70, label %bb71
bb70:
  store i1 false, ptr %l6, !tbaa !21
  br label %bb72
bb71:
  br label %bb72
bb72:
  %t454 = load ptr, ptr %l0, !tbaa !29
  store ptr %t454, ptr %l183, !tbaa !29
  %t455 = load ptr, ptr %lp3
  %t456 = load { i64, ptr }, ptr %t455, !tbaa !27
  store { i64, ptr } %t456, ptr %l184, !tbaa !27
  %t457 = load i32, ptr %l4, !tbaa !23
  store i32 %t457, ptr %l185, !tbaa !23
  %t458 = load i64, ptr %l26, !tbaa !24
  %t460 = call i64 @__olang_fmt_i64(ptr null, i64 %t458)
  %t461 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t460)
  %t462 = call i64 @__olang_fmt_i64(ptr %t461, i64 %t458)
  %t463 = insertvalue { i64, ptr } undef, i64 %t460, 0
  %t464 = insertvalue { i64, ptr } %t463, ptr %t461, 1
  %t466 = extractvalue { i64, ptr } %t464, 0
  %t467 = extractvalue { i64, ptr } %t464, 1
  %t468 = mul i64 %t466, 1
  %t469 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t468)
  call void @llvm.memcpy.p0.p0.i64(ptr %t469, ptr %t467, i64 %t468, i1 false)
  %t470 = insertvalue { i64, ptr } undef, i64 %t466, 0
  %t471 = insertvalue { i64, ptr } %t470, ptr %t469, 1
  store { i64, ptr } %t471, ptr %l188, !tbaa !27
  %t472 = load ptr, ptr %l0, !tbaa !29
  %t474 = getelementptr %"compiler/emit:fnEm", ptr %t472, i32 0, i32 0
  %t475 = load ptr, ptr %t474, !tbaa !29
  %t476 = load i1, ptr %l5, !tbaa !21
  %t477 = load i1, ptr %l6, !tbaa !21
  %t481 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2edescTag(ptr %v0, ptr %s10, ptr %t475, i1 %t476, i1 %t477)
  store { i64, ptr } %t481, ptr %l193
  br label %bb73
bb73:
  %t482 = load { i64, ptr }, ptr %l193, !tbaa !27
  %t483 = extractvalue { i64, ptr } %t482, 0
  %t484 = extractvalue { i64, ptr } %t482, 1
  %t485 = mul i64 %t483, 1
  %t486 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t485)
  call void @llvm.memcpy.p0.p0.i64(ptr %t486, ptr %t484, i64 %t485, i1 false)
  %t487 = insertvalue { i64, ptr } undef, i64 %t483, 0
  %t488 = insertvalue { i64, ptr } %t487, ptr %t486, 1
  %t489 = load ptr, ptr %l183, !tbaa !29
  %t490 = load { i64, ptr }, ptr %l184, !tbaa !27
  %t491 = load i32, ptr %l185, !tbaa !23
  %t492 = load { i64, ptr }, ptr %l188, !tbaa !27
  %t494 = call { { i64, ptr }, i32 } @compiler_2femit_2ecompiler_2femit_3afnEm_2eelemAt(ptr %v0, ptr %v1, ptr %s10, ptr %s10, ptr %s10, ptr %t489, { i64, ptr } %t490, i32 %t491, { i64, ptr } %t492, { i64, ptr } %t488)
  store { { i64, ptr }, i32 } %t494, ptr %l195
  br label %bb74
bb74:
  %t495 = load { { i64, ptr }, i32 }, ptr %l195
  store { { i64, ptr }, i32 } %t495, ptr %l27
  %t496 = getelementptr { { i64, ptr }, i32 }, ptr %l27, i32 0, i32 0
  %t497 = load { i64, ptr }, ptr %t496, !tbaa !27
  store { i64, ptr } %t497, ptr %l196, !tbaa !27
  %t498 = load ptr, ptr %lp3
  %t499 = load { i64, ptr }, ptr %t498, !tbaa !27
  %t500 = extractvalue { i64, ptr } %t499, 0
  %t501 = load { i64, ptr }, ptr %l196, !tbaa !27
  %t502 = extractvalue { i64, ptr } %t501, 0
  store i64 %t502, ptr %l198, !tbaa !24
  %t504 = load i64, ptr %l198, !tbaa !24
  %t505 = icmp eq i64 %t500, %t504
  br i1 %t505, label %bb75, label %bb76
bb75:
  %t507 = load ptr, ptr %lp3
  %t508 = getelementptr { i64, ptr }, ptr %t507, i32 0, i32 1
  %t509 = load ptr, ptr %t508, !tbaa !27
  %t510 = getelementptr { i64, ptr }, ptr %l196, i32 0, i32 1
  %t511 = load ptr, ptr %t510, !tbaa !27
  %t512 = load i64, ptr %l198, !tbaa !24
  %t513 = mul i64 %t512, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t509, ptr %t511, i64 %t513, i1 false)
  br label %bb77
bb76:
  %t514 = load { i64, ptr }, ptr %l196, !tbaa !27
  %t515 = extractvalue { i64, ptr } %t514, 0
  store i64 %t515, ptr %l200, !tbaa !24
  %t516 = load i64, ptr %l200, !tbaa !24
  %t517 = mul i64 %t516, 1
  %t518 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t517)
  %t519 = insertvalue { i64, ptr } undef, i64 %t516, 0
  %t520 = insertvalue { i64, ptr } %t519, ptr %t518, 1
  store { i64, ptr } %t520, ptr %l201, !tbaa !27
  %t521 = getelementptr { i64, ptr }, ptr %l201, i32 0, i32 1
  %t522 = load ptr, ptr %t521, !tbaa !27
  %t523 = getelementptr { i64, ptr }, ptr %l196, i32 0, i32 1
  %t524 = load ptr, ptr %t523, !tbaa !27
  %t525 = load i64, ptr %l200, !tbaa !24
  %t526 = mul i64 %t525, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t522, ptr %t524, i64 %t526, i1 false)
  %t527 = load { i64, ptr }, ptr %l201, !tbaa !27
  %t528 = load ptr, ptr %lp3
  store { i64, ptr } %t527, ptr %t528, !tbaa !27
  br label %bb77
bb77:
  %t529 = getelementptr { { i64, ptr }, i32 }, ptr %l27, i32 0, i32 1
  %t530 = load i32, ptr %t529, !tbaa !23
  store i32 %t530, ptr %l4, !tbaa !23
  store i1 true, ptr %l5, !tbaa !21
  call void @__olang_scope_close(ptr %s10)
  br label %bb107
bb78:
  %t532 = load { i64, [1 x i64] }, ptr %l18
  %t534 = extractvalue { i64, [1 x i64] } %t532, 0
  %t535 = icmp eq i64 %t534, 3
  br i1 %t535, label %bb79, label %bb80
bb79:
  br label %bb81
bb80:
  br label %bb95
bb81:
  store %olang.scope zeroinitializer, ptr %s13
  %t537 = load ptr, ptr %l2, !tbaa !29
  %t538 = load i32, ptr %l19, !tbaa !23
  %t541 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t537, i32 %t538)
  store i32 %t541, ptr %l207
  br label %bb82
bb82:
  %t542 = load i32, ptr %l207, !tbaa !23
  store i32 %t542, ptr %l28, !tbaa !23
  %t543 = load i1, ptr %l6, !tbaa !21
  br i1 %t543, label %bb83, label %bb84
bb83:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d198, i32 0, i32 1) }, ptr %l209, !tbaa !27
  br label %bb86
bb84:
  %t545 = load ptr, ptr %l0, !tbaa !29
  %t547 = getelementptr %"compiler/emit:fnEm", ptr %t545, i32 0, i32 0
  %t548 = load ptr, ptr %t547, !tbaa !29
  %t549 = load i32, ptr %l19, !tbaa !23
  %t550 = load i1, ptr %l5, !tbaa !21
  %t554 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etbaa(ptr %v0, ptr %s13, ptr %t548, i32 %t549, i1 %t550)
  store { i64, ptr } %t554, ptr %l214
  br label %bb85
bb85:
  %t555 = load { i64, ptr }, ptr %l214, !tbaa !27
  %t556 = extractvalue { i64, ptr } %t555, 0
  %t557 = extractvalue { i64, ptr } %t555, 1
  %t558 = mul i64 %t556, 1
  %t559 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t558)
  call void @llvm.memcpy.p0.p0.i64(ptr %t559, ptr %t557, i64 %t558, i1 false)
  %t560 = insertvalue { i64, ptr } undef, i64 %t556, 0
  %t561 = insertvalue { i64, ptr } %t560, ptr %t559, 1
  store { i64, ptr } %t561, ptr %l209, !tbaa !27
  br label %bb86
bb86:
  %t563 = load { i64, ptr }, ptr %l209, !tbaa !27
  store { i64, ptr } %t563, ptr %l29, !tbaa !27
  %t564 = load i32, ptr %l28, !tbaa !23
  store i32 %t564, ptr %l4, !tbaa !23
  %t566 = load ptr, ptr %l0, !tbaa !29
  %t567 = load i32, ptr %l28, !tbaa !23
  %t570 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2erunTime(ptr %v0, ptr %t566, i32 %t567)
  store i1 %t570, ptr %l219
  br label %bb87
bb87:
  %t571 = load i1, ptr %l219, !tbaa !21
  br i1 %t571, label %bb88, label %bb89
bb88:
  call void @__olang_scope_close(ptr %s13)
  br label %bb108
bb89:
  br label %bb90
bb90:
  %t572 = load ptr, ptr %l0, !tbaa !29
  %t573 = load ptr, ptr %lp3
  %t574 = load { i64, ptr }, ptr %t573, !tbaa !27
  %t575 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t579 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %v1, ptr %v1, ptr %s13, ptr %v1, ptr %t572, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d199, i32 0, i32 1) }, { i64, ptr } %t574, { i64, ptr } %t575)
  store { i64, ptr } %t579, ptr %l223
  br label %bb91
bb91:
  %t580 = load ptr, ptr %lp3
  %t581 = load { i64, ptr }, ptr %t580, !tbaa !27
  %t582 = extractvalue { i64, ptr } %t581, 0
  %t583 = load { i64, ptr }, ptr %l223, !tbaa !27
  %t584 = extractvalue { i64, ptr } %t583, 0
  store i64 %t584, ptr %l225, !tbaa !24
  %t586 = load i64, ptr %l225, !tbaa !24
  %t587 = icmp eq i64 %t582, %t586
  br i1 %t587, label %bb92, label %bb93
bb92:
  %t589 = load ptr, ptr %lp3
  %t590 = getelementptr { i64, ptr }, ptr %t589, i32 0, i32 1
  %t591 = load ptr, ptr %t590, !tbaa !27
  %t592 = getelementptr { i64, ptr }, ptr %l223, i32 0, i32 1
  %t593 = load ptr, ptr %t592, !tbaa !27
  %t594 = load i64, ptr %l225, !tbaa !24
  %t595 = mul i64 %t594, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t591, ptr %t593, i64 %t595, i1 false)
  br label %bb94
bb93:
  %t596 = load { i64, ptr }, ptr %l223, !tbaa !27
  %t597 = load ptr, ptr %lp3
  store { i64, ptr } %t596, ptr %t597, !tbaa !27
  br label %bb94
bb94:
  store i1 false, ptr %l6, !tbaa !21
  store i1 false, ptr %l5, !tbaa !21
  call void @__olang_scope_close(ptr %s13)
  br label %bb107
bb95:
  %t598 = load { i64, [1 x i64] }, ptr %l18
  %t600 = extractvalue { i64, [1 x i64] } %t598, 0
  %t601 = icmp eq i64 %t600, 4
  br i1 %t601, label %bb96, label %bb97
bb96:
  %t603 = getelementptr { i64, [1 x i64] }, ptr %l18, i32 0, i32 1
  %t604 = getelementptr { i64 }, ptr %t603, i32 0, i32 0
  %t605 = load i64, ptr %t604
  store i64 %t605, ptr %l30, !tbaa !24
  br label %bb98
bb97:
  br label %bb106
bb98:
  store %olang.scope zeroinitializer, ptr %s15
  %t607 = load ptr, ptr %l0, !tbaa !29
  store ptr %t607, ptr %l230, !tbaa !29
  %t608 = load ptr, ptr %l0, !tbaa !29
  %t609 = load i32, ptr %l19, !tbaa !23
  %t612 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s15, ptr %t608, i32 %t609)
  store { i64, ptr } %t612, ptr %l233
  br label %bb99
bb99:
  %t613 = load ptr, ptr %lp3
  %t614 = load { i64, ptr }, ptr %t613, !tbaa !27
  %t615 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d200, i32 0, i32 1) }, 1
  %t616 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d200, i32 0, i32 1) }, 0
  %t617 = load { i64, ptr }, ptr %l233, !tbaa !27
  %t618 = extractvalue { i64, ptr } %t617, 1
  %t619 = extractvalue { i64, ptr } %t617, 0
  %t620 = add i64 %t616, %t619
  %t621 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d201, i32 0, i32 1) }, 1
  %t622 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d201, i32 0, i32 1) }, 0
  %t623 = add i64 %t620, %t622
  %t625 = extractvalue { i64, ptr } %t614, 1
  %t626 = extractvalue { i64, ptr } %t614, 0
  %t627 = add i64 %t623, %t626
  %t628 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d202, i32 0, i32 1) }, 1
  %t629 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d202, i32 0, i32 1) }, 0
  %t630 = add i64 %t627, %t629
  %t631 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t630)
  call void @olang_textcopy(ptr %t631, ptr %t615, i64 %t616)
  %t632 = getelementptr i8, ptr %t631, i64 %t616
  call void @olang_textcopy(ptr %t632, ptr %t618, i64 %t619)
  %t633 = getelementptr i8, ptr %t632, i64 %t619
  call void @olang_textcopy(ptr %t633, ptr %t621, i64 %t622)
  %t634 = getelementptr i8, ptr %t633, i64 %t622
  call void @olang_textcopy(ptr %t634, ptr %t625, i64 %t626)
  %t635 = getelementptr i8, ptr %t634, i64 %t626
  call void @olang_textcopy(ptr %t635, ptr %t628, i64 %t629)
  %t636 = insertvalue { i64, ptr } undef, i64 %t630, 0
  %t637 = insertvalue { i64, ptr } %t636, ptr %t631, 1
  %t639 = extractvalue { i64, ptr } %t637, 0
  %t640 = extractvalue { i64, ptr } %t637, 1
  %t641 = mul i64 %t639, 1
  %t642 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t641)
  call void @llvm.memcpy.p0.p0.i64(ptr %t642, ptr %t640, i64 %t641, i1 false)
  %t643 = insertvalue { i64, ptr } undef, i64 %t639, 0
  %t644 = insertvalue { i64, ptr } %t643, ptr %t642, 1
  %t645 = load ptr, ptr %l230, !tbaa !29
  %t647 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v1, ptr %t645, { i64, ptr } %t644)
  store { i64, ptr } %t647, ptr %l237
  br label %bb100
bb100:
  %t648 = load ptr, ptr %lp3
  %t649 = load { i64, ptr }, ptr %t648, !tbaa !27
  %t650 = extractvalue { i64, ptr } %t649, 0
  %t651 = load { i64, ptr }, ptr %l237, !tbaa !27
  %t652 = extractvalue { i64, ptr } %t651, 0
  store i64 %t652, ptr %l239, !tbaa !24
  %t654 = load i64, ptr %l239, !tbaa !24
  %t655 = icmp eq i64 %t650, %t654
  br i1 %t655, label %bb101, label %bb102
bb101:
  %t657 = load ptr, ptr %lp3
  %t658 = getelementptr { i64, ptr }, ptr %t657, i32 0, i32 1
  %t659 = load ptr, ptr %t658, !tbaa !27
  %t660 = getelementptr { i64, ptr }, ptr %l237, i32 0, i32 1
  %t661 = load ptr, ptr %t660, !tbaa !27
  %t662 = load i64, ptr %l239, !tbaa !24
  %t663 = mul i64 %t662, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t659, ptr %t661, i64 %t663, i1 false)
  br label %bb103
bb102:
  %t664 = load { i64, ptr }, ptr %l237, !tbaa !27
  %t665 = load ptr, ptr %lp3
  store { i64, ptr } %t664, ptr %t665, !tbaa !27
  br label %bb103
bb103:
  %t666 = load ptr, ptr %l2, !tbaa !29
  store ptr %t666, ptr %l241, !tbaa !29
  %t667 = load ptr, ptr %l0, !tbaa !29
  %t668 = load i32, ptr %l19, !tbaa !23
  %t671 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2ecasesList(ptr %v0, ptr %t667, i32 %t668)
  store i32 %t671, ptr %l244
  br label %bb104
bb104:
  %t672 = load ptr, ptr %l241, !tbaa !29
  %t673 = load i32, ptr %l244, !tbaa !23
  %t674 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t672, i32 %t673)
  store { i64, ptr } %t674, ptr %l245
  br label %bb105
bb105:
  %t675 = load { i64, ptr }, ptr %l245, !tbaa !27
  store { i64, ptr } %t675, ptr %l246, !tbaa !27
  %t677 = load i64, ptr %l30, !tbaa !24
  %t679 = getelementptr { i64, ptr }, ptr %l246, i32 0, i32 1
  %t680 = load ptr, ptr %t679, !tbaa !27
  %t681 = getelementptr i32, ptr %t680, i64 %t677
  %t682 = load i32, ptr %t681, !tbaa !33
  store i32 %t682, ptr %l4, !tbaa !23
  store i1 true, ptr %l6, !tbaa !21
  call void @__olang_scope_close(ptr %s15)
  br label %bb107
bb106:
  call void @__olang_check_failed(ptr @olang_loc_f0091f918c975106_bc2d594a86836fba)
  unreachable
bb107:
  br label %bb108
bb108:
  %t684 = load i32, ptr %l16, !tbaa !23
  %t686 = add i32 %t684, 1
  store i32 %t686, ptr %l16, !tbaa !23
  br label %bb30
bb109:
  %t688 = load ptr, ptr %l0, !tbaa !29
  store ptr %t688, ptr %l251, !tbaa !29
  %t689 = load i1, ptr %l6, !tbaa !21
  br i1 %t689, label %bb110, label %bb111
bb110:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d203, i32 0, i32 1) }, ptr %l253, !tbaa !27
  br label %bb113
bb111:
  %t691 = load ptr, ptr %l0, !tbaa !29
  %t693 = getelementptr %"compiler/emit:fnEm", ptr %t691, i32 0, i32 0
  %t694 = load ptr, ptr %t693, !tbaa !29
  %t695 = load i32, ptr %l4, !tbaa !23
  %t696 = load i1, ptr %l5, !tbaa !21
  %t700 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etbaa(ptr %v0, ptr %v0, ptr %t694, i32 %t695, i1 %t696)
  store { i64, ptr } %t700, ptr %l258
  br label %bb112
bb112:
  %t701 = load { i64, ptr }, ptr %l258, !tbaa !27
  %t702 = extractvalue { i64, ptr } %t701, 0
  %t703 = extractvalue { i64, ptr } %t701, 1
  %t704 = mul i64 %t702, 1
  %t705 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t704)
  call void @llvm.memcpy.p0.p0.i64(ptr %t705, ptr %t703, i64 %t704, i1 false)
  %t706 = insertvalue { i64, ptr } undef, i64 %t702, 0
  %t707 = insertvalue { i64, ptr } %t706, ptr %t705, 1
  store { i64, ptr } %t707, ptr %l253, !tbaa !27
  br label %bb113
bb113:
  %t709 = load ptr, ptr %l251, !tbaa !29
  %t710 = getelementptr %"compiler/emit:fnEm", ptr %t709, i32 0, i32 15
  %t711 = load { i64, ptr }, ptr %t710, !tbaa !27
  store { i64, ptr } %t711, ptr %l260, !tbaa !27
  %t712 = load { i64, ptr }, ptr %l253, !tbaa !27
  %t713 = load ptr, ptr %l251, !tbaa !29
  %t714 = getelementptr %"compiler/emit:fnEm", ptr %t713, i32 0, i32 15
  store { i64, ptr } %t712, ptr %t714, !tbaa !27
  %t715 = load i1, ptr @olang_2esole_2ecompiler_2femit_3afnEm_2e15
  br i1 %t715, label %bb114, label %bb115
bb114:
  %t717 = load { i64, ptr }, ptr %l260
  %t718 = extractvalue { i64, ptr } %t717, 1
  call void @__olang_region_release(ptr %t718)
  store { i64, ptr } zeroinitializer, ptr %l260
  br label %bb115
bb115:
  %t719 = load ptr, ptr %lp3
  %t720 = load { i64, ptr }, ptr %t719, !tbaa !27
  %t721 = load i32, ptr %l4, !tbaa !23
  %t723 = insertvalue { { i64, ptr }, i32 } undef, { i64, ptr } %t720, 0
  %t725 = insertvalue { { i64, ptr }, i32 } %t723, i32 %t721, 1
  store { { i64, ptr }, i32 } %t725, ptr %rv
  br label %ret
ret:
  %rr = load { { i64, ptr }, i32 }, ptr %rv
  ret { { i64, ptr }, i32 } %rr
}

define dso_local i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2ealign(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l6 = alloca i1
  %l11 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/emit:Emitter", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t8 = load i32, ptr %l1, !tbaa !23
  %t11 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLayout(ptr %v0, ptr %t7, i32 %t8)
  store i1 %t11, ptr %l6
  br label %bb1
bb1:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/emit:fnEm", ptr %t12, i32 0, i32 0
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = getelementptr %"compiler/emit:Emitter", ptr %t15, i32 0, i32 3
  %t18 = load ptr, ptr %t17, !tbaa !29
  %t19 = load i32, ptr %l1, !tbaa !23
  %t22 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAlign(ptr %v0, ptr %t18, i32 %t19)
  store i64 %t22, ptr %l11
  br label %bb2
bb2:
  %t23 = load i64, ptr %l11, !tbaa !24
  store i64 %t23, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %a0, %"compiler/mir:Range" %a1, i64 %a2) #0 {
entry:
  %l1 = alloca %"compiler/mir:Range"
  %l10 = alloca { i64, [4 x i64] }
  %rv = alloca { i64, [4 x i64] }
  store %"compiler/mir:Range" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %a0, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/mir:Fn", ptr %t4, i32 0, i32 11
  %t7 = getelementptr %"compiler/mir:Range", ptr %l1, i32 0, i32 0
  %t8 = load i32, ptr %t7, !tbaa !23
  %t10 = sext i32 %t8 to i64
  %t14 = add i64 %t10, %a2
  %t17 = call { i64, [4 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2eAt_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %t6, i64 %t14)
  store { i64, [4 x i64] } %t17, ptr %l10
  br label %bb1
bb1:
  %t18 = load { i64, [4 x i64] }, ptr %l10
  store { i64, [4 x i64] } %t18, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2earrayStorage(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, i32 %a3, i1 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l4 = alloca i1
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l10 = alloca i64
  %l14 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store i1 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2ealign(ptr %v0, ptr %t1, i32 %a3)
  store i64 %t5, ptr %l10
  br label %bb1
bb1:
  %t6 = load i64, ptr %l10, !tbaa !24
  store i64 %t6, ptr %l5, !tbaa !24
  %t7 = load i64, ptr %l5, !tbaa !24
  %t9 = icmp sgt i64 %t7, 8
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load i1, ptr %l4, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb3:
  br label %bb9
bb4:
  store { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d204, i32 0, i32 1) }, ptr %l14, !tbaa !27
  br label %bb6
bb5:
  store { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d205, i32 0, i32 1) }, ptr %l14, !tbaa !27
  br label %bb6
bb6:
  %t13 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t13, ptr %l6, !tbaa !27
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/emit:fnEm", ptr %t14, i32 0, i32 0
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t18 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t19 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %t19, ptr %t17, { i64, ptr } %t18)
  br label %bb7
bb7:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t24 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t25 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t26 = load i64, ptr %l5, !tbaa !24
  %t27 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d206, i32 0, i32 1) }, 1
  %t28 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d206, i32 0, i32 1) }, 0
  %t30 = extractvalue { i64, ptr } %t23, 1
  %t31 = extractvalue { i64, ptr } %t23, 0
  %t32 = add i64 %t28, %t31
  %t33 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d207, i32 0, i32 1) }, 1
  %t34 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d207, i32 0, i32 1) }, 0
  %t35 = add i64 %t32, %t34
  %t37 = extractvalue { i64, ptr } %t24, 1
  %t38 = extractvalue { i64, ptr } %t24, 0
  %t39 = add i64 %t35, %t38
  %t40 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d208, i32 0, i32 1) }, 1
  %t41 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d208, i32 0, i32 1) }, 0
  %t42 = add i64 %t39, %t41
  %t44 = extractvalue { i64, ptr } %t25, 1
  %t45 = extractvalue { i64, ptr } %t25, 0
  %t46 = add i64 %t42, %t45
  %t47 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d208, i32 0, i32 1) }, 1
  %t48 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d208, i32 0, i32 1) }, 0
  %t49 = add i64 %t46, %t48
  %t51 = call i64 @__olang_fmt_i64(ptr null, i64 %t26)
  %t52 = add i64 %t49, %t51
  %t53 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d209, i32 0, i32 1) }, 1
  %t54 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d209, i32 0, i32 1) }, 0
  %t55 = add i64 %t52, %t54
  %t56 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t55)
  call void @olang_textcopy(ptr %t56, ptr %t27, i64 %t28)
  %t57 = getelementptr i8, ptr %t56, i64 %t28
  call void @olang_textcopy(ptr %t57, ptr %t30, i64 %t31)
  %t58 = getelementptr i8, ptr %t57, i64 %t31
  call void @olang_textcopy(ptr %t58, ptr %t33, i64 %t34)
  %t59 = getelementptr i8, ptr %t58, i64 %t34
  call void @olang_textcopy(ptr %t59, ptr %t37, i64 %t38)
  %t60 = getelementptr i8, ptr %t59, i64 %t38
  call void @olang_textcopy(ptr %t60, ptr %t40, i64 %t41)
  %t61 = getelementptr i8, ptr %t60, i64 %t41
  call void @olang_textcopy(ptr %t61, ptr %t44, i64 %t45)
  %t62 = getelementptr i8, ptr %t61, i64 %t45
  call void @olang_textcopy(ptr %t62, ptr %t47, i64 %t48)
  %t63 = getelementptr i8, ptr %t62, i64 %t48
  %t64 = call i64 @__olang_fmt_i64(ptr %t63, i64 %t26)
  %t65 = getelementptr i8, ptr %t63, i64 %t51
  call void @olang_textcopy(ptr %t65, ptr %t53, i64 %t54)
  %t66 = insertvalue { i64, ptr } undef, i64 %t55, 0
  %t67 = insertvalue { i64, ptr } %t66, ptr %t56, 1
  %t69 = extractvalue { i64, ptr } %t67, 0
  %t70 = extractvalue { i64, ptr } %t67, 1
  %t71 = mul i64 %t69, 1
  %t72 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t71)
  call void @llvm.memcpy.p0.p0.i64(ptr %t72, ptr %t70, i64 %t71, i1 false)
  %t73 = insertvalue { i64, ptr } undef, i64 %t69, 0
  %t74 = insertvalue { i64, ptr } %t73, ptr %t72, 1
  %t77 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v3, ptr %v3, ptr %t22, { i64, ptr } %t74)
  store { i64, ptr } %t77, ptr %l25
  br label %bb8
bb8:
  %t78 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t78, ptr %rv
  br label %ret
bb9:
  %t79 = load i1, ptr %l4, !tbaa !21
  br i1 %t79, label %bb10, label %bb11
bb10:
  store { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d210, i32 0, i32 1) }, ptr %l27, !tbaa !27
  br label %bb12
bb11:
  store { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d211, i32 0, i32 1) }, ptr %l27, !tbaa !27
  br label %bb12
bb12:
  %t81 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t81, ptr %l7, !tbaa !27
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/emit:fnEm", ptr %t82, i32 0, i32 0
  %t85 = load ptr, ptr %t84, !tbaa !29
  %t86 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t87 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %t87, ptr %t85, { i64, ptr } %t86)
  br label %bb13
bb13:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t91 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t92 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t93 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t94 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d212, i32 0, i32 1) }, 1
  %t95 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d212, i32 0, i32 1) }, 0
  %t97 = extractvalue { i64, ptr } %t91, 1
  %t98 = extractvalue { i64, ptr } %t91, 0
  %t99 = add i64 %t95, %t98
  %t100 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d213, i32 0, i32 1) }, 1
  %t101 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d213, i32 0, i32 1) }, 0
  %t102 = add i64 %t99, %t101
  %t104 = extractvalue { i64, ptr } %t92, 1
  %t105 = extractvalue { i64, ptr } %t92, 0
  %t106 = add i64 %t102, %t105
  %t107 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d214, i32 0, i32 1) }, 1
  %t108 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d214, i32 0, i32 1) }, 0
  %t109 = add i64 %t106, %t108
  %t111 = extractvalue { i64, ptr } %t93, 1
  %t112 = extractvalue { i64, ptr } %t93, 0
  %t113 = add i64 %t109, %t112
  %t114 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d215, i32 0, i32 1) }, 1
  %t115 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d215, i32 0, i32 1) }, 0
  %t116 = add i64 %t113, %t115
  %t117 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t116)
  call void @olang_textcopy(ptr %t117, ptr %t94, i64 %t95)
  %t118 = getelementptr i8, ptr %t117, i64 %t95
  call void @olang_textcopy(ptr %t118, ptr %t97, i64 %t98)
  %t119 = getelementptr i8, ptr %t118, i64 %t98
  call void @olang_textcopy(ptr %t119, ptr %t100, i64 %t101)
  %t120 = getelementptr i8, ptr %t119, i64 %t101
  call void @olang_textcopy(ptr %t120, ptr %t104, i64 %t105)
  %t121 = getelementptr i8, ptr %t120, i64 %t105
  call void @olang_textcopy(ptr %t121, ptr %t107, i64 %t108)
  %t122 = getelementptr i8, ptr %t121, i64 %t108
  call void @olang_textcopy(ptr %t122, ptr %t111, i64 %t112)
  %t123 = getelementptr i8, ptr %t122, i64 %t112
  call void @olang_textcopy(ptr %t123, ptr %t114, i64 %t115)
  %t124 = insertvalue { i64, ptr } undef, i64 %t116, 0
  %t125 = insertvalue { i64, ptr } %t124, ptr %t117, 1
  %t127 = extractvalue { i64, ptr } %t125, 0
  %t128 = extractvalue { i64, ptr } %t125, 1
  %t129 = mul i64 %t127, 1
  %t130 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t129)
  call void @llvm.memcpy.p0.p0.i64(ptr %t130, ptr %t128, i64 %t129, i1 false)
  %t131 = insertvalue { i64, ptr } undef, i64 %t127, 0
  %t132 = insertvalue { i64, ptr } %t131, ptr %t130, 1
  %t135 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v3, ptr %v3, ptr %t90, { i64, ptr } %t132)
  store { i64, ptr } %t135, ptr %l37
  br label %bb14
bb14:
  %t136 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t136, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2easPacked(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l7 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2esize(ptr %v0, ptr %t1, i32 %a2)
  store i64 %t5, ptr %l7
  br label %bb1
bb1:
  %t6 = load i64, ptr %l7, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t9 = icmp eq i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  store { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d216, i32 0, i32 1) }, ptr %l10, !tbaa !27
  %t11 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t11, ptr %l11, !tbaa !27
  %t12 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t12, 0
  store i64 %t13, ptr %l12, !tbaa !24
  %t14 = load i64, ptr %l12, !tbaa !24
  %t15 = mul i64 %t14, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  %t17 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  store { i64, ptr } %t18, ptr %l13, !tbaa !27
  %t19 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !27
  %t21 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = load i64, ptr %l12, !tbaa !24
  %t24 = mul i64 %t23, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t20, ptr %t22, i64 %t24, i1 false)
  %t25 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t25, ptr %l11, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t26 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t26, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load i64, ptr %l3, !tbaa !24
  %t29 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d217, i32 0, i32 1) }, 1
  %t30 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d217, i32 0, i32 1) }, 0
  %t32 = call i64 @__olang_fmt_i64(ptr null, i64 %t28)
  %t33 = add i64 %t30, %t32
  %t34 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d218, i32 0, i32 1) }, 1
  %t35 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d218, i32 0, i32 1) }, 0
  %t36 = add i64 %t33, %t35
  %t37 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t36)
  call void @olang_textcopy(ptr %t37, ptr %t29, i64 %t30)
  %t38 = getelementptr i8, ptr %t37, i64 %t30
  %t39 = call i64 @__olang_fmt_i64(ptr %t38, i64 %t28)
  %t40 = getelementptr i8, ptr %t38, i64 %t32
  call void @olang_textcopy(ptr %t40, ptr %t34, i64 %t35)
  %t41 = insertvalue { i64, ptr } undef, i64 %t36, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t37, 1
  %t44 = extractvalue { i64, ptr } %t42, 0
  %t45 = extractvalue { i64, ptr } %t42, 1
  %t46 = mul i64 %t44, 1
  %t47 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t46)
  call void @llvm.memcpy.p0.p0.i64(ptr %t47, ptr %t45, i64 %t46, i1 false)
  %t48 = insertvalue { i64, ptr } undef, i64 %t44, 0
  %t49 = insertvalue { i64, ptr } %t48, ptr %t47, 1
  %t52 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ealloca(ptr %v0, ptr %s0, ptr %s0, ptr %t27, { i64, ptr } %t49, i64 1)
  store { i64, ptr } %t52, ptr %l18
  br label %bb5
bb5:
  %t53 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t53, ptr %l4, !tbaa !27
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load i64, ptr %l3, !tbaa !24
  %t57 = mul i64 8, %t55
  %t58 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d219, i32 0, i32 1) }, 1
  %t59 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d219, i32 0, i32 1) }, 0
  %t61 = call i64 @__olang_fmt_i64(ptr null, i64 %t57)
  %t62 = add i64 %t59, %t61
  %t63 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t62)
  call void @olang_textcopy(ptr %t63, ptr %t58, i64 %t59)
  %t64 = getelementptr i8, ptr %t63, i64 %t59
  %t65 = call i64 @__olang_fmt_i64(ptr %t64, i64 %t57)
  %t66 = insertvalue { i64, ptr } undef, i64 %t62, 0
  %t67 = insertvalue { i64, ptr } %t66, ptr %t63, 1
  %t69 = extractvalue { i64, ptr } %t67, 0
  %t70 = extractvalue { i64, ptr } %t67, 1
  %t71 = mul i64 %t69, 1
  %t72 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t71)
  call void @llvm.memcpy.p0.p0.i64(ptr %t72, ptr %t70, i64 %t71, i1 false)
  %t73 = insertvalue { i64, ptr } undef, i64 %t69, 0
  %t74 = insertvalue { i64, ptr } %t73, ptr %t72, 1
  %t76 = load { i64, ptr }, ptr %l4, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s0, ptr %v1, ptr %s0, ptr %s0, ptr %t54, { i64, ptr } %t74, { i64, ptr } %a1, { i64, ptr } %t76, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d220, i32 0, i32 1) })
  br label %bb6
bb6:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t82 = load i64, ptr %l3, !tbaa !24
  %t83 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d221, i32 0, i32 1) }, 1
  %t84 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d221, i32 0, i32 1) }, 0
  %t86 = call i64 @__olang_fmt_i64(ptr null, i64 %t82)
  %t87 = add i64 %t84, %t86
  %t88 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d222, i32 0, i32 1) }, 1
  %t89 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d222, i32 0, i32 1) }, 0
  %t90 = add i64 %t87, %t89
  %t91 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t90)
  call void @olang_textcopy(ptr %t91, ptr %t83, i64 %t84)
  %t92 = getelementptr i8, ptr %t91, i64 %t84
  %t93 = call i64 @__olang_fmt_i64(ptr %t92, i64 %t82)
  %t94 = getelementptr i8, ptr %t92, i64 %t86
  call void @olang_textcopy(ptr %t94, ptr %t88, i64 %t89)
  %t95 = insertvalue { i64, ptr } undef, i64 %t90, 0
  %t96 = insertvalue { i64, ptr } %t95, ptr %t91, 1
  %t98 = extractvalue { i64, ptr } %t96, 0
  %t99 = extractvalue { i64, ptr } %t96, 1
  %t100 = mul i64 %t98, 1
  %t101 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t100)
  call void @llvm.memcpy.p0.p0.i64(ptr %t101, ptr %t99, i64 %t100, i1 false)
  %t102 = insertvalue { i64, ptr } undef, i64 %t98, 0
  %t103 = insertvalue { i64, ptr } %t102, ptr %t101, 1
  %t104 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t108 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %v2, ptr %s0, ptr %v2, ptr %v2, ptr %t81, { i64, ptr } %t103, { i64, ptr } %t104, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d223, i32 0, i32 1) })
  store { i64, ptr } %t108, ptr %l31
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s0)
  %t109 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t109, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2ebufferCopy(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l27 = alloca i1
  %l33 = alloca i1
  %l45 = alloca i32
  %l48 = alloca i32
  %l55 = alloca i32
  %l60 = alloca ptr
  %l63 = alloca i32
  %l64 = alloca { i64, ptr }
  %l66 = alloca ptr
  %l69 = alloca i64
  %l70 = alloca { i64, ptr }
  %l72 = alloca i1
  %l73 = alloca i1
  %l75 = alloca i1
  %l76 = alloca { i64, ptr }
  %l78 = alloca i1
  %l79 = alloca i1
  %l81 = alloca i1
  %l82 = alloca { i64, ptr }
  %l84 = alloca i1
  %l90 = alloca { i64, ptr }
  %l91 = alloca ptr
  %l94 = alloca i32
  %l95 = alloca { i64, ptr }
  %l100 = alloca i64
  %l104 = alloca i64
  %l107 = alloca i64
  %l132 = alloca { i64, ptr }
  %l134 = alloca i1
  %l136 = alloca { i64, ptr }
  %l139 = alloca i32
  %l142 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/mir:Fn", ptr %t4, i32 0, i32 0
  %t7 = load { i64, [2 x i64] }, ptr %t6
  store { i64, [2 x i64] } %t7, ptr %l2
  %t9 = load { i64, [2 x i64] }, ptr %l2
  %t11 = extractvalue { i64, [2 x i64] } %t9, 0
  %t12 = icmp eq i64 %t11, 3
  %t14 = xor i1 %t12, true
  br i1 %t14, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb6
bb2:
  %t16 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t17 = getelementptr { i32, i32 }, ptr %t16, i32 0, i32 0
  %t18 = load i32, ptr %t17, !range !{i32 0, i32 8}
  store i32 %t18, ptr %l3
  %t20 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t21 = getelementptr { i32, i32 }, ptr %t20, i32 0, i32 1
  %t22 = load i32, ptr %t21
  store i32 %t22, ptr %l4, !tbaa !23
  %t24 = load i32, ptr %l3, !range !{i32 0, i32 8}
  %t26 = trunc i64 4 to i32
  %t27 = icmp eq i32 %t24, %t26
  %t29 = xor i1 %t27, true
  br i1 %t29, label %bb3, label %bb4
bb3:
  %t31 = load i32, ptr %l3, !range !{i32 0, i32 8}
  %t33 = trunc i64 5 to i32
  %t34 = icmp eq i32 %t31, %t33
  %t36 = xor i1 %t34, true
  store i1 %t36, ptr %l33, !tbaa !21
  br label %bb5
bb4:
  store i1 false, ptr %l33, !tbaa !21
  br label %bb5
bb5:
  %t38 = load i1, ptr %l33, !tbaa !21
  store i1 %t38, ptr %l27, !tbaa !21
  br label %bb6
bb6:
  %t39 = load i1, ptr %l27, !tbaa !21
  br i1 %t39, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t41 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t42 = getelementptr { i32, i32 }, ptr %t41, i32 0, i32 0
  %t43 = load i32, ptr %t42, !range !{i32 0, i32 8}
  store i32 %t43, ptr %l5
  %t45 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t46 = getelementptr { i32, i32 }, ptr %t45, i32 0, i32 1
  %t47 = load i32, ptr %t46
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/emit:fnEm", ptr %t49, i32 0, i32 0
  %t52 = load ptr, ptr %t51, !tbaa !29
  %t54 = getelementptr %"compiler/emit:Emitter", ptr %t52, i32 0, i32 3
  %t55 = load ptr, ptr %t54, !tbaa !29
  store ptr %t55, ptr %l7, !tbaa !29
  %t57 = load ptr, ptr %l7, !tbaa !29
  %t61 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t57, i32 %t47)
  store i32 %t61, ptr %l45
  br label %bb10
bb10:
  %t62 = load i32, ptr %l45, !tbaa !23
  store i32 %t62, ptr %l8, !tbaa !23
  %t63 = load ptr, ptr %l7, !tbaa !29
  %t64 = load i32, ptr %l8, !tbaa !23
  %t67 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t63, i32 %t64)
  store i32 %t67, ptr %l48
  br label %bb11
bb11:
  %t68 = load i32, ptr %l48, !range !{i32 0, i32 33}
  %t70 = trunc i64 18 to i32
  %t71 = icmp eq i32 %t68, %t70
  %t73 = xor i1 %t71, true
  br i1 %t73, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t76 = load ptr, ptr %l7, !tbaa !29
  %t77 = load i32, ptr %l8, !tbaa !23
  %t80 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t76, i32 %t77)
  store i32 %t80, ptr %l55
  br label %bb15
bb15:
  %t81 = load i32, ptr %l55, !tbaa !23
  store i32 %t81, ptr %l9, !tbaa !23
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/emit:fnEm", ptr %t82, i32 0, i32 0
  %t85 = load ptr, ptr %t84, !tbaa !29
  %t87 = getelementptr %"compiler/emit:Emitter", ptr %t85, i32 0, i32 0
  %t88 = load ptr, ptr %t87, !tbaa !29
  %t90 = getelementptr %"compiler/generic:Program", ptr %t88, i32 0, i32 0
  %t91 = load ptr, ptr %t90, !tbaa !29
  %t93 = getelementptr %"compiler/load:Loader", ptr %t91, i32 0, i32 3
  %t94 = load ptr, ptr %t93, !tbaa !29
  store ptr %t94, ptr %l60, !tbaa !29
  %t95 = load ptr, ptr %l7, !tbaa !29
  %t96 = load i32, ptr %l9, !tbaa !23
  %t99 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t95, i32 %t96)
  store i32 %t99, ptr %l63
  br label %bb16
bb16:
  %t100 = load ptr, ptr %l60, !tbaa !29
  %t101 = load i32, ptr %l63, !tbaa !23
  %t102 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v0, ptr %t100, i32 %t101)
  store { i64, ptr } %t102, ptr %l64
  br label %bb17
bb17:
  %t103 = load { i64, ptr }, ptr %l64, !tbaa !27
  store { i64, ptr } %t103, ptr %l10, !tbaa !27
  %t104 = load ptr, ptr %l7, !tbaa !29
  %t106 = getelementptr %"compiler/types:Table", ptr %t104, i32 0, i32 14
  store ptr %t106, ptr %l66, !tbaa !29
  %t107 = load ptr, ptr %l7, !tbaa !29
  %t108 = load i32, ptr %l9, !tbaa !23
  %t111 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t107, i32 %t108)
  store i64 %t111, ptr %l69
  br label %bb18
bb18:
  %t112 = load ptr, ptr %l66, !tbaa !29
  %t113 = load i64, ptr %l69, !tbaa !24
  %t114 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t112, i64 %t113)
  store { i64, ptr } %t114, ptr %l70
  br label %bb19
bb19:
  %t115 = load { i64, ptr }, ptr %l70, !tbaa !27
  store { i64, ptr } %t115, ptr %l11, !tbaa !27
  %t116 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t118 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t116, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d224, i32 0, i32 1) })
  store i1 %t118, ptr %l72
  br label %bb20
bb20:
  %t119 = load i1, ptr %l72, !tbaa !21
  br i1 %t119, label %bb21, label %bb22
bb21:
  %t120 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t122 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t120, { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d225, i32 0, i32 1) })
  store i1 %t122, ptr %l75
  br label %bb23
bb22:
  store i1 false, ptr %l73, !tbaa !21
  br label %bb24
bb23:
  %t123 = load i1, ptr %l75, !tbaa !21
  store i1 %t123, ptr %l73, !tbaa !21
  br label %bb24
bb24:
  %t124 = load i1, ptr %l73, !tbaa !21
  br i1 %t124, label %bb25, label %bb26
bb25:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d226, i32 0, i32 1) }, ptr %l76, !tbaa !27
  br label %bb35
bb26:
  %t125 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t127 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t125, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d227, i32 0, i32 1) })
  store i1 %t127, ptr %l78
  br label %bb27
bb27:
  %t128 = load i1, ptr %l78, !tbaa !21
  br i1 %t128, label %bb28, label %bb29
bb28:
  %t129 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t131 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t129, { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d228, i32 0, i32 1) })
  store i1 %t131, ptr %l81
  br label %bb30
bb29:
  store i1 false, ptr %l79, !tbaa !21
  br label %bb31
bb30:
  %t132 = load i1, ptr %l81, !tbaa !21
  store i1 %t132, ptr %l79, !tbaa !21
  br label %bb31
bb31:
  %t133 = load i1, ptr %l79, !tbaa !21
  br i1 %t133, label %bb32, label %bb33
bb32:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d229, i32 0, i32 1) }, ptr %l82, !tbaa !27
  br label %bb34
bb33:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d230, i32 0, i32 1) }, ptr %l82, !tbaa !27
  br label %bb34
bb34:
  %t134 = load { i64, ptr }, ptr %l82, !tbaa !27
  store { i64, ptr } %t134, ptr %l76, !tbaa !27
  br label %bb35
bb35:
  %t135 = load { i64, ptr }, ptr %l76, !tbaa !27
  store { i64, ptr } %t135, ptr %l12, !tbaa !27
  %t136 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t137 = load ptr, ptr @__olang_prog_scope
  %t139 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %t137, ptr %s0, { i64, ptr } %t136, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d231, i32 0, i32 1) })
  store i1 %t139, ptr %l84
  br label %bb36
bb36:
  %t140 = load i1, ptr %l84, !tbaa !21
  br i1 %t140, label %bb37, label %bb38
bb37:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb38:
  br label %bb39
bb39:
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t144 = getelementptr %"compiler/emit:fnEm", ptr %t142, i32 0, i32 0
  %t145 = load ptr, ptr %t144, !tbaa !29
  %t147 = getelementptr %"compiler/emit:Emitter", ptr %t145, i32 0, i32 0
  %t148 = load ptr, ptr %t147, !tbaa !29
  %t149 = load i32, ptr %l8, !tbaa !23
  %t152 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFieldNames(ptr %v0, ptr %s0, ptr %t148, i32 %t149)
  store { i64, ptr } %t152, ptr %l90
  br label %bb40
bb40:
  %t153 = load { i64, ptr }, ptr %l90, !tbaa !27
  store { i64, ptr } %t153, ptr %l13, !tbaa !27
  %t154 = load ptr, ptr %l7, !tbaa !29
  store ptr %t154, ptr %l91, !tbaa !29
  %t155 = load ptr, ptr %l7, !tbaa !29
  %t156 = load i32, ptr %l8, !tbaa !23
  %t159 = call i32 @compiler_2fmir_2eFieldsOf(ptr %v0, ptr %t155, i32 %t156)
  store i32 %t159, ptr %l94
  br label %bb41
bb41:
  %t160 = load ptr, ptr %l91, !tbaa !29
  %t161 = load i32, ptr %l94, !tbaa !23
  %t162 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t160, i32 %t161)
  store { i64, ptr } %t162, ptr %l95
  br label %bb42
bb42:
  %t163 = load { i64, ptr }, ptr %l95, !tbaa !27
  store { i64, ptr } %t163, ptr %l14, !tbaa !27
  store i64 0, ptr %l15, !tbaa !24
  %t164 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t166 = extractvalue { i64, ptr } %t164, 0
  %t167 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t169 = extractvalue { i64, ptr } %t167, 0
  %t172 = call i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %t166, i64 %t169)
  store i64 %t172, ptr %l100
  br label %bb43
bb43:
  %t173 = load i64, ptr %l100, !tbaa !24
  store i64 %t173, ptr %l16, !tbaa !24
  store i64 1, ptr %l17, !tbaa !24
  %t174 = load i64, ptr %l16, !tbaa !24
  %t175 = load i64, ptr %l15, !tbaa !24
  %t178 = icmp sgt i64 %t174, %t175
  br i1 %t178, label %bb44, label %bb45
bb44:
  %t180 = load i64, ptr %l17, !tbaa !24
  %t182 = icmp sgt i64 %t180, 0
  br i1 %t182, label %bb46, label %bb47
bb45:
  store i64 0, ptr %l104, !tbaa !24
  br label %bb49
bb46:
  %t184 = load i64, ptr %l16, !tbaa !24
  %t185 = load i64, ptr %l15, !tbaa !24
  %t188 = sub i64 %t184, %t185
  %t189 = load i64, ptr %l17, !tbaa !24
  %t192 = add i64 %t188, %t189
  %t194 = sub i64 %t192, 1
  %t195 = load i64, ptr %l17, !tbaa !24
  %t198 = sdiv i64 %t194, %t195
  store i64 %t198, ptr %l107, !tbaa !24
  br label %bb48
bb47:
  store i64 0, ptr %l107, !tbaa !24
  br label %bb48
bb48:
  %t200 = load i64, ptr %l107, !tbaa !24
  store i64 %t200, ptr %l104, !tbaa !24
  br label %bb49
bb49:
  %t201 = load i64, ptr %l104, !tbaa !24
  store i64 %t201, ptr %l18, !tbaa !24
  store i64 0, ptr %l19, !tbaa !24
  br label %bb50
bb50:
  %t202 = load i64, ptr %l19, !tbaa !24
  %t203 = load i64, ptr %l18, !tbaa !24
  %t206 = icmp slt i64 %t202, %t203
  %t208 = xor i1 %t206, true
  br i1 %t208, label %bb51, label %bb52
bb51:
  br label %bb62
bb52:
  br label %bb53
bb53:
  %t210 = load i64, ptr %l15, !tbaa !24
  %t211 = load i64, ptr %l19, !tbaa !24
  %t212 = load i64, ptr %l17, !tbaa !24
  %t215 = mul i64 %t211, %t212
  %t218 = add i64 %t210, %t215
  store i64 %t218, ptr %l20, !tbaa !24
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t222 = getelementptr %"compiler/emit:fnEm", ptr %t220, i32 0, i32 0
  %t223 = load ptr, ptr %t222, !tbaa !29
  %t225 = getelementptr %"compiler/emit:Emitter", ptr %t223, i32 0, i32 0
  %t226 = load ptr, ptr %t225, !tbaa !29
  %t228 = getelementptr %"compiler/generic:Program", ptr %t226, i32 0, i32 0
  %t229 = load ptr, ptr %t228, !tbaa !29
  %t231 = getelementptr %"compiler/load:Loader", ptr %t229, i32 0, i32 3
  %t232 = load ptr, ptr %t231, !tbaa !29
  %t233 = load i64, ptr %l20, !tbaa !24
  %t235 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t236 = load ptr, ptr %t235, !tbaa !27
  %t237 = getelementptr i32, ptr %t236, i64 %t233
  %t238 = load i32, ptr %t237, !tbaa !33
  %t241 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v0, ptr %t232, i32 %t238)
  store { i64, ptr } %t241, ptr %l132
  br label %bb54
bb54:
  %t242 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t243 = load ptr, ptr @__olang_prog_scope
  %t244 = load { i64, ptr }, ptr %l132, !tbaa !27
  %t246 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %t243, { i64, ptr } %t244, { i64, ptr } %t242)
  store i1 %t246, ptr %l134
  br label %bb55
bb55:
  %t247 = load i1, ptr %l134, !tbaa !21
  br i1 %t247, label %bb56, label %bb57
bb56:
  %t248 = load ptr, ptr %l7, !tbaa !29
  %t249 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t249, ptr %l136, !tbaa !27
  %t250 = load i64, ptr %l20, !tbaa !24
  %t252 = getelementptr { i64, ptr }, ptr %l136, i32 0, i32 1
  %t253 = load ptr, ptr %t252, !tbaa !27
  %t254 = getelementptr i32, ptr %t253, i64 %t250
  %t255 = load i32, ptr %t254, !tbaa !33
  %t258 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t248, i32 %t255)
  store i32 %t258, ptr %l139
  br label %bb58
bb57:
  br label %bb60
bb58:
  %t259 = load ptr, ptr %l7, !tbaa !29
  %t263 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t259, i32 %a1)
  store i32 %t263, ptr %l142
  br label %bb59
bb59:
  %t264 = load i32, ptr %l139, !tbaa !23
  %t265 = load i32, ptr %l142, !tbaa !23
  %t266 = icmp eq i32 %t264, %t265
  call void @__olang_scope_close(ptr %s0)
  store i1 %t266, ptr %rv
  br label %ret
bb60:
  br label %bb61
bb61:
  %t268 = load i64, ptr %l19, !tbaa !24
  %t270 = add i64 %t268, 1
  store i64 %t270, ptr %l19, !tbaa !24
  br label %bb50
bb62:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2ebuilderOpened(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i1
  %l14 = alloca %"compiler/mir:ScopeInfo"
  %rv = alloca i64
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [21 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb10
bb5:
  %t18 = getelementptr %"compiler/emit:fnEm", ptr %a0, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = getelementptr %"compiler/mir:Fn", ptr %t19, i32 0, i32 8
  %t22 = load i32, ptr %l2, !tbaa !23
  %t24 = sext i32 %t22 to i64
  %t27 = call %"compiler/mir:ScopeInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeInfo_3e_2eAt_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %t21, i64 %t24)
  store %"compiler/mir:ScopeInfo" %t27, ptr %l14
  br label %bb6
bb6:
  %t28 = getelementptr %"compiler/mir:ScopeInfo", ptr %l14, i32 0, i32 0
  %t29 = load i32, ptr %t28, !range !{i32 0, i32 7}
  %t31 = trunc i64 6 to i32
  %t32 = icmp eq i32 %t29, %t31
  br i1 %t32, label %bb7, label %bb8
bb7:
  %t34 = load i32, ptr %l2, !tbaa !23
  %t36 = sext i32 %t34 to i64
  store i64 %t36, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  br label %bb15
bb10:
  br i1 true, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  call void @__olang_check_failed(ptr @olang_loc_538eacb44f7c8f74_e1c936133deb4fd8)
  unreachable
bb15:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3afnEm_2eclauses(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2, %"compiler/mir:Task" %a3, i32 %a4, i64 %a5, i64 %a6, { i64, ptr } %a7) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca %"compiler/mir:Task"
  %l6 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i32
  %l11 = alloca i64
  %l12 = alloca i32
  %l13 = alloca i32
  %l14 = alloca i32
  %l15 = alloca i32
  %l16 = alloca i32
  %l17 = alloca i32
  %l18 = alloca %"compiler/mir:TaskClause"
  %l19 = alloca { i64, ptr }
  %l20 = alloca i32
  %l21 = alloca i32
  %l22 = alloca i32
  %l23 = alloca i32
  %l24 = alloca i32
  %l25 = alloca i32
  %l26 = alloca %"compiler/typed:Item"
  %l27 = alloca i64
  %l28 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l30 = alloca i32
  %l31 = alloca %"std/prelude/text:StringBuilder"
  %l32 = alloca i32
  %l33 = alloca i1
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l48 = alloca i32
  %l54 = alloca i32
  %l57 = alloca i32
  %l83 = alloca %"compiler/mir:TaskClause"
  %l84 = alloca { i64, ptr }
  %l85 = alloca { i64, ptr }
  %l86 = alloca [4 x i8]
  %l91 = alloca { i64, ptr }
  %l92 = alloca { i64, ptr }
  %l94 = alloca i64
  %l96 = alloca i64
  %l97 = alloca { i64, ptr }
  %l102 = alloca i32
  %l105 = alloca i32
  %l131 = alloca %"compiler/typed:Item"
  %l135 = alloca i64
  %l165 = alloca { i64, ptr }
  %l167 = alloca i64
  %l185 = alloca { i64, ptr }
  %l187 = alloca i1
  %l207 = alloca i32
  %l222 = alloca %"std/prelude/text:StringBuilder"
  %l229 = alloca i32
  %l233 = alloca i1
  %l237 = alloca i1
  %l240 = alloca i1
  %l242 = alloca ptr
  %l243 = alloca i32
  %l246 = alloca { i64, ptr }
  %l257 = alloca i64
  %l261 = alloca i64
  %l264 = alloca i64
  %l298 = alloca { i64, ptr }
  %l299 = alloca { i64, ptr }
  %l300 = alloca { i64, ptr }
  %l301 = alloca i64
  %l302 = alloca { i64, ptr }
  %l304 = alloca i1
  %l305 = alloca ptr
  %l306 = alloca i32
  %l308 = alloca { i64, ptr }
  %l311 = alloca ptr
  %l312 = alloca i32
  %l313 = alloca { i64, ptr }
  %l314 = alloca i32
  %l316 = alloca { i64, ptr }
  %l320 = alloca { i64, ptr }
  %l322 = alloca i64
  %l325 = alloca ptr
  %l326 = alloca i32
  %l329 = alloca { i64, ptr }
  %l334 = alloca { i64, ptr }
  %l336 = alloca i64
  %l339 = alloca i1
  %l341 = alloca i1
  %l346 = alloca ptr
  %l347 = alloca i32
  %l348 = alloca i64
  %l351 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %s31 = alloca %olang.scope
  %s33 = alloca %olang.scope
  %s36 = alloca %olang.scope
  %s39 = alloca %olang.scope
  %s40 = alloca %olang.scope
  %s42 = alloca %olang.scope
  %t851 = alloca { i64, [4 x i64] }, align 8
  %t854 = alloca { i64, [7 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store %"compiler/mir:Task" %a3, ptr %l3
  store i64 %a6, ptr %l6
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l8, !tbaa !29
  %t6 = load ptr, ptr %l8, !tbaa !29
  %t8 = getelementptr %"compiler/emit:Emitter", ptr %t6, i32 0, i32 3
  %t9 = load ptr, ptr %t8, !tbaa !29
  store ptr %t9, ptr %l9, !tbaa !29
  %t11 = load ptr, ptr %l9, !tbaa !29
  %t15 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t11, i32 %a4)
  store i32 %t15, ptr %l48
  br label %bb1
bb1:
  %t16 = load i32, ptr %l48, !tbaa !23
  store i32 %t16, ptr %l10, !tbaa !23
  store i64 %a5, ptr %l11, !tbaa !24
  store i32 0, ptr %l12, !tbaa !23
  %t19 = getelementptr %"compiler/mir:Task", ptr %l3, i32 0, i32 4
  %t20 = getelementptr %"compiler/mir:Range", ptr %t19, i32 0, i32 1
  %t21 = load i32, ptr %t20, !tbaa !23
  store i32 %t21, ptr %l13, !tbaa !23
  store i32 1, ptr %l14, !tbaa !23
  %t23 = load i32, ptr %l13, !tbaa !23
  %t24 = load i32, ptr %l12, !tbaa !23
  %t27 = icmp sgt i32 %t23, %t24
  br i1 %t27, label %bb2, label %bb3
bb2:
  %t29 = load i32, ptr %l14, !tbaa !23
  %t31 = icmp sgt i32 %t29, 0
  br i1 %t31, label %bb4, label %bb5
bb3:
  store i32 0, ptr %l54, !tbaa !23
  br label %bb7
bb4:
  %t33 = load i32, ptr %l13, !tbaa !23
  %t34 = load i32, ptr %l12, !tbaa !23
  %t37 = sub i32 %t33, %t34
  %t38 = load i32, ptr %l14, !tbaa !23
  %t41 = add i32 %t37, %t38
  %t43 = sub i32 %t41, 1
  %t44 = load i32, ptr %l14, !tbaa !23
  %t47 = sdiv i32 %t43, %t44
  store i32 %t47, ptr %l57, !tbaa !23
  br label %bb6
bb5:
  store i32 0, ptr %l57, !tbaa !23
  br label %bb6
bb6:
  %t49 = load i32, ptr %l57, !tbaa !23
  store i32 %t49, ptr %l54, !tbaa !23
  br label %bb7
bb7:
  %t50 = load i32, ptr %l54, !tbaa !23
  store i32 %t50, ptr %l15, !tbaa !23
  store i32 0, ptr %l16, !tbaa !23
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t51 = load i32, ptr %l16, !tbaa !23
  %t52 = load i32, ptr %l15, !tbaa !23
  %t55 = icmp slt i32 %t51, %t52
  %t57 = xor i1 %t55, true
  br i1 %t57, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb126
bb10:
  br label %bb11
bb11:
  %t59 = load i32, ptr %l12, !tbaa !23
  %t60 = load i32, ptr %l16, !tbaa !23
  %t61 = load i32, ptr %l14, !tbaa !23
  %t64 = mul i32 %t60, %t61
  %t67 = add i32 %t59, %t64
  store i32 %t67, ptr %l17, !tbaa !23
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/emit:fnEm", ptr %t69, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !29
  %t74 = getelementptr %"compiler/mir:Fn", ptr %t72, i32 0, i32 17
  %t75 = getelementptr %"compiler/mir:Task", ptr %l3, i32 0, i32 4
  %t76 = getelementptr %"compiler/mir:Range", ptr %t75, i32 0, i32 0
  %t77 = load i32, ptr %t76, !tbaa !23
  %t79 = sext i32 %t77 to i64
  %t80 = load i32, ptr %l17, !tbaa !23
  %t82 = sext i32 %t80 to i64
  %t85 = add i64 %t79, %t82
  %t88 = call %"compiler/mir:TaskClause" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTaskClause_3e_2eAt_3ccompiler_2fmir_3aTaskClause_3e(ptr %v0, ptr %t74, i64 %t85)
  store %"compiler/mir:TaskClause" %t88, ptr %l83
  br label %bb12
bb12:
  %t89 = load %"compiler/mir:TaskClause", ptr %l83
  store %"compiler/mir:TaskClause" %t89, ptr %l18
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d232, i32 0, i32 1) }, ptr %l84, !tbaa !27
  %t90 = load { i64, ptr }, ptr %l84, !tbaa !27
  store { i64, ptr } %t90, ptr %l85, !tbaa !27
  %t91 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !27
  %t93 = mul i64 4, 1
  call void @llvm.memmove.p0.p0.i64(ptr %l86, ptr %t92, i64 %t93, i1 false)
  %t95 = insertvalue { i64, ptr } undef, i64 4, 0
  %t96 = insertvalue { i64, ptr } %t95, ptr %l86, 1
  store { i64, ptr } %t96, ptr %l19, !tbaa !27
  %t98 = getelementptr %"compiler/mir:TaskClause", ptr %l18, i32 0, i32 1
  %t99 = load i1, ptr %t98, !tbaa !21
  %t101 = xor i1 %t99, true
  br i1 %t101, label %bb13, label %bb14
bb13:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d233, i32 0, i32 1) }, ptr %l91, !tbaa !27
  %t103 = load { i64, ptr }, ptr %l91, !tbaa !27
  store { i64, ptr } %t103, ptr %l92, !tbaa !27
  %t104 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t105 = extractvalue { i64, ptr } %t104, 0
  %t106 = load { i64, ptr }, ptr %l92, !tbaa !27
  %t107 = extractvalue { i64, ptr } %t106, 0
  store i64 %t107, ptr %l94, !tbaa !24
  %t109 = load i64, ptr %l94, !tbaa !24
  %t110 = icmp eq i64 %t105, %t109
  br i1 %t110, label %bb15, label %bb16
bb14:
  br label %bb41
bb15:
  %t112 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !27
  %t114 = getelementptr { i64, ptr }, ptr %l92, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !27
  %t116 = load i64, ptr %l94, !tbaa !24
  %t117 = mul i64 %t116, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t113, ptr %t115, i64 %t117, i1 false)
  br label %bb17
bb16:
  %t118 = load { i64, ptr }, ptr %l92, !tbaa !27
  %t119 = extractvalue { i64, ptr } %t118, 0
  store i64 %t119, ptr %l96, !tbaa !24
  %t120 = load i64, ptr %l96, !tbaa !24
  %t121 = mul i64 %t120, 1
  %t122 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t121)
  %t123 = insertvalue { i64, ptr } undef, i64 %t120, 0
  %t124 = insertvalue { i64, ptr } %t123, ptr %t122, 1
  store { i64, ptr } %t124, ptr %l97, !tbaa !27
  %t125 = getelementptr { i64, ptr }, ptr %l97, i32 0, i32 1
  %t126 = load ptr, ptr %t125, !tbaa !27
  %t127 = getelementptr { i64, ptr }, ptr %l92, i32 0, i32 1
  %t128 = load ptr, ptr %t127, !tbaa !27
  %t129 = load i64, ptr %l96, !tbaa !24
  %t130 = mul i64 %t129, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t126, ptr %t128, i64 %t130, i1 false)
  %t131 = load { i64, ptr }, ptr %l97, !tbaa !27
  store { i64, ptr } %t131, ptr %l19, !tbaa !27
  br label %bb17
bb17:
  store i32 0, ptr %l20, !tbaa !23
  %t132 = getelementptr %"compiler/mir:TaskClause", ptr %l18, i32 0, i32 0
  %t133 = getelementptr %"compiler/mir:Range", ptr %t132, i32 0, i32 1
  %t134 = load i32, ptr %t133, !tbaa !23
  store i32 %t134, ptr %l21, !tbaa !23
  store i32 1, ptr %l22, !tbaa !23
  %t136 = load i32, ptr %l21, !tbaa !23
  %t137 = load i32, ptr %l20, !tbaa !23
  %t140 = icmp sgt i32 %t136, %t137
  br i1 %t140, label %bb18, label %bb19
bb18:
  %t142 = load i32, ptr %l22, !tbaa !23
  %t144 = icmp sgt i32 %t142, 0
  br i1 %t144, label %bb20, label %bb21
bb19:
  store i32 0, ptr %l102, !tbaa !23
  br label %bb23
bb20:
  %t146 = load i32, ptr %l21, !tbaa !23
  %t147 = load i32, ptr %l20, !tbaa !23
  %t150 = sub i32 %t146, %t147
  %t151 = load i32, ptr %l22, !tbaa !23
  %t154 = add i32 %t150, %t151
  %t156 = sub i32 %t154, 1
  %t157 = load i32, ptr %l22, !tbaa !23
  %t160 = sdiv i32 %t156, %t157
  store i32 %t160, ptr %l105, !tbaa !23
  br label %bb22
bb21:
  store i32 0, ptr %l105, !tbaa !23
  br label %bb22
bb22:
  %t162 = load i32, ptr %l105, !tbaa !23
  store i32 %t162, ptr %l102, !tbaa !23
  br label %bb23
bb23:
  %t163 = load i32, ptr %l102, !tbaa !23
  store i32 %t163, ptr %l23, !tbaa !23
  store i32 0, ptr %l24, !tbaa !23
  br label %bb24
bb24:
  store %olang.scope zeroinitializer, ptr %s5
  %t164 = load i32, ptr %l24, !tbaa !23
  %t165 = load i32, ptr %l23, !tbaa !23
  %t168 = icmp slt i32 %t164, %t165
  %t170 = xor i1 %t168, true
  br i1 %t170, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s5)
  br label %bb40
bb26:
  br label %bb27
bb27:
  %t172 = load i32, ptr %l20, !tbaa !23
  %t173 = load i32, ptr %l24, !tbaa !23
  %t174 = load i32, ptr %l22, !tbaa !23
  %t177 = mul i32 %t173, %t174
  %t180 = add i32 %t172, %t177
  store i32 %t180, ptr %l25, !tbaa !23
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t184 = getelementptr %"compiler/emit:fnEm", ptr %t182, i32 0, i32 1
  %t185 = load ptr, ptr %t184, !tbaa !29
  %t187 = getelementptr %"compiler/mir:Fn", ptr %t185, i32 0, i32 18
  %t188 = getelementptr %"compiler/mir:TaskClause", ptr %l18, i32 0, i32 0
  %t189 = getelementptr %"compiler/mir:Range", ptr %t188, i32 0, i32 0
  %t190 = load i32, ptr %t189, !tbaa !23
  %t192 = sext i32 %t190 to i64
  %t193 = load i32, ptr %l25, !tbaa !23
  %t195 = sext i32 %t193 to i64
  %t198 = add i64 %t192, %t195
  %t201 = call %"compiler/typed:Item" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aItem_3e_2eAt_3ccompiler_2ftyped_3aItem_3e(ptr %v0, ptr %t187, i64 %t198)
  store %"compiler/typed:Item" %t201, ptr %l131
  br label %bb28
bb28:
  %t202 = load %"compiler/typed:Item", ptr %l131
  store %"compiler/typed:Item" %t202, ptr %l26
  %t203 = load ptr, ptr %l8, !tbaa !29
  %t204 = load i32, ptr %l10, !tbaa !23
  %t205 = getelementptr %"compiler/typed:Item", ptr %l26, i32 0, i32 0
  %t206 = load i32, ptr %t205, !tbaa !23
  %t210 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eposition(ptr %v0, ptr %t203, i32 %t204, i32 %t206)
  store i64 %t210, ptr %l135
  br label %bb29
bb29:
  %t211 = load i64, ptr %l135, !tbaa !24
  store i64 %t211, ptr %l27, !tbaa !24
  %t212 = load i32, ptr %l17, !tbaa !23
  %t213 = load i32, ptr %l25, !tbaa !23
  %t214 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d234, i32 0, i32 1) }, 1
  %t215 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d234, i32 0, i32 1) }, 0
  %t217 = sext i32 %t212 to i64
  %t218 = call i64 @__olang_fmt_i64(ptr null, i64 %t217)
  %t219 = add i64 %t215, %t218
  %t220 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d235, i32 0, i32 1) }, 1
  %t221 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d235, i32 0, i32 1) }, 0
  %t222 = add i64 %t219, %t221
  %t224 = sext i32 %t213 to i64
  %t225 = call i64 @__olang_fmt_i64(ptr null, i64 %t224)
  %t226 = add i64 %t222, %t225
  %t227 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t226)
  call void @olang_textcopy(ptr %t227, ptr %t214, i64 %t215)
  %t228 = getelementptr i8, ptr %t227, i64 %t215
  %t229 = call i64 @__olang_fmt_i64(ptr %t228, i64 %t217)
  %t230 = getelementptr i8, ptr %t228, i64 %t218
  call void @olang_textcopy(ptr %t230, ptr %t220, i64 %t221)
  %t231 = getelementptr i8, ptr %t230, i64 %t221
  %t232 = call i64 @__olang_fmt_i64(ptr %t231, i64 %t224)
  %t233 = insertvalue { i64, ptr } undef, i64 %t226, 0
  %t234 = insertvalue { i64, ptr } %t233, ptr %t227, 1
  store { i64, ptr } %t234, ptr %l28, !tbaa !27
  %t236 = getelementptr %"compiler/typed:Item", ptr %l26, i32 0, i32 1
  %t237 = load i64, ptr %t236, !tbaa !24
  %t239 = icmp slt i64 %t237, 0
  br i1 %t239, label %bb30, label %bb31
bb30:
  store %olang.scope zeroinitializer, ptr %s7
  %t241 = load ptr, ptr %l1, !tbaa !29
  %t242 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t243 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t244 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t245 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t246 = load i64, ptr %l27, !tbaa !24
  %t247 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d236, i32 0, i32 1) }, 1
  %t248 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d236, i32 0, i32 1) }, 0
  %t250 = extractvalue { i64, ptr } %t242, 1
  %t251 = extractvalue { i64, ptr } %t242, 0
  %t252 = add i64 %t248, %t251
  %t253 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d237, i32 0, i32 1) }, 1
  %t254 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d237, i32 0, i32 1) }, 0
  %t255 = add i64 %t252, %t254
  %t257 = extractvalue { i64, ptr } %t243, 1
  %t258 = extractvalue { i64, ptr } %t243, 0
  %t259 = add i64 %t255, %t258
  %t260 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d238, i32 0, i32 1) }, 1
  %t261 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d238, i32 0, i32 1) }, 0
  %t262 = add i64 %t259, %t261
  %t264 = extractvalue { i64, ptr } %t244, 1
  %t265 = extractvalue { i64, ptr } %t244, 0
  %t266 = add i64 %t262, %t265
  %t267 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d239, i32 0, i32 1) }, 1
  %t268 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d239, i32 0, i32 1) }, 0
  %t269 = add i64 %t266, %t268
  %t271 = extractvalue { i64, ptr } %t245, 1
  %t272 = extractvalue { i64, ptr } %t245, 0
  %t273 = add i64 %t269, %t272
  %t274 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d240, i32 0, i32 1) }, 1
  %t275 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d240, i32 0, i32 1) }, 0
  %t276 = add i64 %t273, %t275
  %t278 = call i64 @__olang_fmt_i64(ptr null, i64 %t246)
  %t279 = add i64 %t276, %t278
  %t280 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d241, i32 0, i32 1) }, 1
  %t281 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d241, i32 0, i32 1) }, 0
  %t282 = add i64 %t279, %t281
  %t283 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t282)
  call void @olang_textcopy(ptr %t283, ptr %t247, i64 %t248)
  %t284 = getelementptr i8, ptr %t283, i64 %t248
  call void @olang_textcopy(ptr %t284, ptr %t250, i64 %t251)
  %t285 = getelementptr i8, ptr %t284, i64 %t251
  call void @olang_textcopy(ptr %t285, ptr %t253, i64 %t254)
  %t286 = getelementptr i8, ptr %t285, i64 %t254
  call void @olang_textcopy(ptr %t286, ptr %t257, i64 %t258)
  %t287 = getelementptr i8, ptr %t286, i64 %t258
  call void @olang_textcopy(ptr %t287, ptr %t260, i64 %t261)
  %t288 = getelementptr i8, ptr %t287, i64 %t261
  call void @olang_textcopy(ptr %t288, ptr %t264, i64 %t265)
  %t289 = getelementptr i8, ptr %t288, i64 %t265
  call void @olang_textcopy(ptr %t289, ptr %t267, i64 %t268)
  %t290 = getelementptr i8, ptr %t289, i64 %t268
  call void @olang_textcopy(ptr %t290, ptr %t271, i64 %t272)
  %t291 = getelementptr i8, ptr %t290, i64 %t272
  call void @olang_textcopy(ptr %t291, ptr %t274, i64 %t275)
  %t292 = getelementptr i8, ptr %t291, i64 %t275
  %t293 = call i64 @__olang_fmt_i64(ptr %t292, i64 %t246)
  %t294 = getelementptr i8, ptr %t292, i64 %t278
  call void @olang_textcopy(ptr %t294, ptr %t280, i64 %t281)
  %t295 = insertvalue { i64, ptr } undef, i64 %t282, 0
  %t296 = insertvalue { i64, ptr } %t295, ptr %t283, 1
  %t298 = extractvalue { i64, ptr } %t296, 0
  %t299 = extractvalue { i64, ptr } %t296, 1
  %t300 = mul i64 %t298, 1
  %t301 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t300)
  call void @llvm.memcpy.p0.p0.i64(ptr %t301, ptr %t299, i64 %t300, i1 false)
  %t302 = insertvalue { i64, ptr } undef, i64 %t298, 0
  %t303 = insertvalue { i64, ptr } %t302, ptr %t301, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s7, ptr %t241, { i64, ptr } %t303)
  br label %bb32
bb31:
  store %olang.scope zeroinitializer, ptr %s9
  %t306 = load ptr, ptr %l1, !tbaa !29
  %t307 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t308 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t309 = load i64, ptr %l27, !tbaa !24
  %t311 = shl i64 %t309, 16
  %t312 = getelementptr %"compiler/typed:Item", ptr %l26, i32 0, i32 1
  %t313 = load i64, ptr %t312, !tbaa !24
  %t316 = or i64 %t311, %t313
  %t317 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d242, i32 0, i32 1) }, 1
  %t318 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d242, i32 0, i32 1) }, 0
  %t320 = extractvalue { i64, ptr } %t307, 1
  %t321 = extractvalue { i64, ptr } %t307, 0
  %t322 = add i64 %t318, %t321
  %t323 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d243, i32 0, i32 1) }, 1
  %t324 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d243, i32 0, i32 1) }, 0
  %t325 = add i64 %t322, %t324
  %t327 = extractvalue { i64, ptr } %t308, 1
  %t328 = extractvalue { i64, ptr } %t308, 0
  %t329 = add i64 %t325, %t328
  %t330 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d244, i32 0, i32 1) }, 1
  %t331 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d244, i32 0, i32 1) }, 0
  %t332 = add i64 %t329, %t331
  %t334 = call i64 @__olang_fmt_i64(ptr null, i64 %t316)
  %t335 = add i64 %t332, %t334
  %t336 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d245, i32 0, i32 1) }, 1
  %t337 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d245, i32 0, i32 1) }, 0
  %t338 = add i64 %t335, %t337
  %t339 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t338)
  call void @olang_textcopy(ptr %t339, ptr %t317, i64 %t318)
  %t340 = getelementptr i8, ptr %t339, i64 %t318
  call void @olang_textcopy(ptr %t340, ptr %t320, i64 %t321)
  %t341 = getelementptr i8, ptr %t340, i64 %t321
  call void @olang_textcopy(ptr %t341, ptr %t323, i64 %t324)
  %t342 = getelementptr i8, ptr %t341, i64 %t324
  call void @olang_textcopy(ptr %t342, ptr %t327, i64 %t328)
  %t343 = getelementptr i8, ptr %t342, i64 %t328
  call void @olang_textcopy(ptr %t343, ptr %t330, i64 %t331)
  %t344 = getelementptr i8, ptr %t343, i64 %t331
  %t345 = call i64 @__olang_fmt_i64(ptr %t344, i64 %t316)
  %t346 = getelementptr i8, ptr %t344, i64 %t334
  call void @olang_textcopy(ptr %t346, ptr %t336, i64 %t337)
  %t347 = insertvalue { i64, ptr } undef, i64 %t338, 0
  %t348 = insertvalue { i64, ptr } %t347, ptr %t339, 1
  %t350 = extractvalue { i64, ptr } %t348, 0
  %t351 = extractvalue { i64, ptr } %t348, 1
  %t352 = mul i64 %t350, 1
  %t353 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t352)
  call void @llvm.memcpy.p0.p0.i64(ptr %t353, ptr %t351, i64 %t352, i1 false)
  %t354 = insertvalue { i64, ptr } undef, i64 %t350, 0
  %t355 = insertvalue { i64, ptr } %t354, ptr %t353, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s9, ptr %t306, { i64, ptr } %t355)
  br label %bb33
bb32:
  call void @__olang_scope_close(ptr %s7)
  br label %bb34
bb33:
  call void @__olang_scope_close(ptr %s9)
  br label %bb34
bb34:
  %t358 = load ptr, ptr %l1, !tbaa !29
  %t359 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t360 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t361 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t362 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d246, i32 0, i32 1) }, 1
  %t363 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d246, i32 0, i32 1) }, 0
  %t365 = extractvalue { i64, ptr } %t359, 1
  %t366 = extractvalue { i64, ptr } %t359, 0
  %t367 = add i64 %t363, %t366
  %t368 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d247, i32 0, i32 1) }, 1
  %t369 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d247, i32 0, i32 1) }, 0
  %t370 = add i64 %t367, %t369
  %t372 = extractvalue { i64, ptr } %t360, 1
  %t373 = extractvalue { i64, ptr } %t360, 0
  %t374 = add i64 %t370, %t373
  %t375 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d248, i32 0, i32 1) }, 1
  %t376 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d248, i32 0, i32 1) }, 0
  %t377 = add i64 %t374, %t376
  %t379 = extractvalue { i64, ptr } %t361, 1
  %t380 = extractvalue { i64, ptr } %t361, 0
  %t381 = add i64 %t377, %t380
  %t382 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d249, i32 0, i32 1) }, 1
  %t383 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d249, i32 0, i32 1) }, 0
  %t384 = add i64 %t381, %t383
  %t385 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t384)
  call void @olang_textcopy(ptr %t385, ptr %t362, i64 %t363)
  %t386 = getelementptr i8, ptr %t385, i64 %t363
  call void @olang_textcopy(ptr %t386, ptr %t365, i64 %t366)
  %t387 = getelementptr i8, ptr %t386, i64 %t366
  call void @olang_textcopy(ptr %t387, ptr %t368, i64 %t369)
  %t388 = getelementptr i8, ptr %t387, i64 %t369
  call void @olang_textcopy(ptr %t388, ptr %t372, i64 %t373)
  %t389 = getelementptr i8, ptr %t388, i64 %t373
  call void @olang_textcopy(ptr %t389, ptr %t375, i64 %t376)
  %t390 = getelementptr i8, ptr %t389, i64 %t376
  call void @olang_textcopy(ptr %t390, ptr %t379, i64 %t380)
  %t391 = getelementptr i8, ptr %t390, i64 %t380
  call void @olang_textcopy(ptr %t391, ptr %t382, i64 %t383)
  %t392 = insertvalue { i64, ptr } undef, i64 %t384, 0
  %t393 = insertvalue { i64, ptr } %t392, ptr %t385, 1
  %t395 = extractvalue { i64, ptr } %t393, 0
  %t396 = extractvalue { i64, ptr } %t393, 1
  %t397 = mul i64 %t395, 1
  %t398 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t397)
  call void @llvm.memcpy.p0.p0.i64(ptr %t398, ptr %t396, i64 %t397, i1 false)
  %t399 = insertvalue { i64, ptr } undef, i64 %t395, 0
  %t400 = insertvalue { i64, ptr } %t399, ptr %t398, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s5, ptr %t358, { i64, ptr } %t400)
  br label %bb35
bb35:
  %t403 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t405 = extractvalue { i64, ptr } %t403, 1
  %t406 = extractvalue { i64, ptr } %t403, 0
  %t407 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d250, i32 0, i32 1) }, 1
  %t408 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d250, i32 0, i32 1) }, 0
  %t409 = add i64 %t406, %t408
  %t410 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t409)
  call void @olang_textcopy(ptr %t410, ptr %t405, i64 %t406)
  %t411 = getelementptr i8, ptr %t410, i64 %t406
  call void @olang_textcopy(ptr %t411, ptr %t407, i64 %t408)
  %t412 = insertvalue { i64, ptr } undef, i64 %t409, 0
  %t413 = insertvalue { i64, ptr } %t412, ptr %t410, 1
  store { i64, ptr } %t413, ptr %l165, !tbaa !27
  %t414 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t415 = extractvalue { i64, ptr } %t414, 0
  %t416 = load { i64, ptr }, ptr %l165, !tbaa !27
  %t417 = extractvalue { i64, ptr } %t416, 0
  store i64 %t417, ptr %l167, !tbaa !24
  %t419 = load i64, ptr %l167, !tbaa !24
  %t420 = icmp eq i64 %t415, %t419
  br i1 %t420, label %bb36, label %bb37
bb36:
  %t422 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t423 = load ptr, ptr %t422, !tbaa !27
  %t424 = getelementptr { i64, ptr }, ptr %l165, i32 0, i32 1
  %t425 = load ptr, ptr %t424, !tbaa !27
  %t426 = load i64, ptr %l167, !tbaa !24
  %t427 = mul i64 %t426, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t423, ptr %t425, i64 %t427, i1 false)
  br label %bb38
bb37:
  %t428 = load { i64, ptr }, ptr %l165, !tbaa !27
  store { i64, ptr } %t428, ptr %l19, !tbaa !27
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s5)
  br label %bb39
bb39:
  %t429 = load i32, ptr %l24, !tbaa !23
  %t431 = add i32 %t429, 1
  store i32 %t431, ptr %l24, !tbaa !23
  br label %bb24
bb40:
  br label %bb41
bb41:
  %t433 = load ptr, ptr %l1, !tbaa !29
  %t434 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t435 = load i32, ptr %l17, !tbaa !23
  %t436 = load i32, ptr %l17, !tbaa !23
  %t437 = load i32, ptr %l17, !tbaa !23
  %t438 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d251, i32 0, i32 1) }, 1
  %t439 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d251, i32 0, i32 1) }, 0
  %t441 = extractvalue { i64, ptr } %t434, 1
  %t442 = extractvalue { i64, ptr } %t434, 0
  %t443 = add i64 %t439, %t442
  %t444 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d252, i32 0, i32 1) }, 1
  %t445 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d252, i32 0, i32 1) }, 0
  %t446 = add i64 %t443, %t445
  %t448 = sext i32 %t435 to i64
  %t449 = call i64 @__olang_fmt_i64(ptr null, i64 %t448)
  %t450 = add i64 %t446, %t449
  %t451 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d253, i32 0, i32 1) }, 1
  %t452 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d253, i32 0, i32 1) }, 0
  %t453 = add i64 %t450, %t452
  %t455 = sext i32 %t436 to i64
  %t456 = call i64 @__olang_fmt_i64(ptr null, i64 %t455)
  %t457 = add i64 %t453, %t456
  %t458 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d254, i32 0, i32 1) }, 1
  %t459 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d254, i32 0, i32 1) }, 0
  %t460 = add i64 %t457, %t459
  %t462 = sext i32 %t437 to i64
  %t463 = call i64 @__olang_fmt_i64(ptr null, i64 %t462)
  %t464 = add i64 %t460, %t463
  %t465 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d255, i32 0, i32 1) }, 1
  %t466 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d255, i32 0, i32 1) }, 0
  %t467 = add i64 %t464, %t466
  %t468 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t467)
  call void @olang_textcopy(ptr %t468, ptr %t438, i64 %t439)
  %t469 = getelementptr i8, ptr %t468, i64 %t439
  call void @olang_textcopy(ptr %t469, ptr %t441, i64 %t442)
  %t470 = getelementptr i8, ptr %t469, i64 %t442
  call void @olang_textcopy(ptr %t470, ptr %t444, i64 %t445)
  %t471 = getelementptr i8, ptr %t470, i64 %t445
  %t472 = call i64 @__olang_fmt_i64(ptr %t471, i64 %t448)
  %t473 = getelementptr i8, ptr %t471, i64 %t449
  call void @olang_textcopy(ptr %t473, ptr %t451, i64 %t452)
  %t474 = getelementptr i8, ptr %t473, i64 %t452
  %t475 = call i64 @__olang_fmt_i64(ptr %t474, i64 %t455)
  %t476 = getelementptr i8, ptr %t474, i64 %t456
  call void @olang_textcopy(ptr %t476, ptr %t458, i64 %t459)
  %t477 = getelementptr i8, ptr %t476, i64 %t459
  %t478 = call i64 @__olang_fmt_i64(ptr %t477, i64 %t462)
  %t479 = getelementptr i8, ptr %t477, i64 %t463
  call void @olang_textcopy(ptr %t479, ptr %t465, i64 %t466)
  %t480 = insertvalue { i64, ptr } undef, i64 %t467, 0
  %t481 = insertvalue { i64, ptr } %t480, ptr %t468, 1
  %t483 = extractvalue { i64, ptr } %t481, 0
  %t484 = extractvalue { i64, ptr } %t481, 1
  %t485 = mul i64 %t483, 1
  %t486 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t485)
  call void @llvm.memcpy.p0.p0.i64(ptr %t486, ptr %t484, i64 %t485, i1 false)
  %t487 = insertvalue { i64, ptr } undef, i64 %t483, 0
  %t488 = insertvalue { i64, ptr } %t487, ptr %t486, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s2, ptr %t433, { i64, ptr } %t488)
  br label %bb42
bb42:
  %t491 = load ptr, ptr %l8, !tbaa !29
  %t492 = load ptr, ptr %l1, !tbaa !29
  %t493 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t494 = load i32, ptr %l10, !tbaa !23
  %t495 = load i32, ptr %l17, !tbaa !23
  %t496 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d256, i32 0, i32 1) }, 1
  %t497 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d256, i32 0, i32 1) }, 0
  %t499 = sext i32 %t495 to i64
  %t500 = call i64 @__olang_fmt_i64(ptr null, i64 %t499)
  %t501 = add i64 %t497, %t500
  %t502 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t501)
  call void @olang_textcopy(ptr %t502, ptr %t496, i64 %t497)
  %t503 = getelementptr i8, ptr %t502, i64 %t497
  %t504 = call i64 @__olang_fmt_i64(ptr %t503, i64 %t499)
  %t505 = insertvalue { i64, ptr } undef, i64 %t501, 0
  %t506 = insertvalue { i64, ptr } %t505, ptr %t502, 1
  %t508 = extractvalue { i64, ptr } %t506, 0
  %t509 = extractvalue { i64, ptr } %t506, 1
  %t510 = mul i64 %t508, 1
  %t511 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t510)
  call void @llvm.memcpy.p0.p0.i64(ptr %t511, ptr %t509, i64 %t510, i1 false)
  %t512 = insertvalue { i64, ptr } undef, i64 %t508, 0
  %t513 = insertvalue { i64, ptr } %t512, ptr %t511, 1
  %t519 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecarriesText(ptr %v0, ptr %v1, ptr %v2, ptr %s2, ptr %s2, ptr %t491, ptr %t492, { i64, ptr } %t493, i32 %t494, { i64, ptr } %t513)
  store { i64, ptr } %t519, ptr %l185
  br label %bb43
bb43:
  %t520 = load { i64, ptr }, ptr %l185, !tbaa !27
  store { i64, ptr } %t520, ptr %l29, !tbaa !27
  %t521 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t523 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s2, ptr %s2, { i64, ptr } %t521, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d257, i32 0, i32 1) })
  store i1 %t523, ptr %l187
  br label %bb44
bb44:
  %t524 = load i1, ptr %l187, !tbaa !21
  %t525 = xor i1 %t524, true
  br i1 %t525, label %bb45, label %bb46
bb45:
  store %olang.scope zeroinitializer, ptr %s16
  %t527 = load ptr, ptr %l8, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %s16, ptr %t527, { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d258, i32 0, i32 1) })
  br label %bb47
bb46:
  br label %bb50
bb47:
  %t529 = load ptr, ptr %l1, !tbaa !29
  %t530 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t531 = load i32, ptr %l17, !tbaa !23
  %t532 = load i32, ptr %l17, !tbaa !23
  %t533 = load i32, ptr %l17, !tbaa !23
  %t534 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d259, i32 0, i32 1) }, 1
  %t535 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d259, i32 0, i32 1) }, 0
  %t537 = extractvalue { i64, ptr } %t530, 1
  %t538 = extractvalue { i64, ptr } %t530, 0
  %t539 = add i64 %t535, %t538
  %t540 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d260, i32 0, i32 1) }, 1
  %t541 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d260, i32 0, i32 1) }, 0
  %t542 = add i64 %t539, %t541
  %t544 = sext i32 %t531 to i64
  %t545 = call i64 @__olang_fmt_i64(ptr null, i64 %t544)
  %t546 = add i64 %t542, %t545
  %t547 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d261, i32 0, i32 1) }, 1
  %t548 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d261, i32 0, i32 1) }, 0
  %t549 = add i64 %t546, %t548
  %t551 = sext i32 %t532 to i64
  %t552 = call i64 @__olang_fmt_i64(ptr null, i64 %t551)
  %t553 = add i64 %t549, %t552
  %t554 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d262, i32 0, i32 1) }, 1
  %t555 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d262, i32 0, i32 1) }, 0
  %t556 = add i64 %t553, %t555
  %t558 = sext i32 %t533 to i64
  %t559 = call i64 @__olang_fmt_i64(ptr null, i64 %t558)
  %t560 = add i64 %t556, %t559
  %t561 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d263, i32 0, i32 1) }, 1
  %t562 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d263, i32 0, i32 1) }, 0
  %t563 = add i64 %t560, %t562
  %t564 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t563)
  call void @olang_textcopy(ptr %t564, ptr %t534, i64 %t535)
  %t565 = getelementptr i8, ptr %t564, i64 %t535
  call void @olang_textcopy(ptr %t565, ptr %t537, i64 %t538)
  %t566 = getelementptr i8, ptr %t565, i64 %t538
  call void @olang_textcopy(ptr %t566, ptr %t540, i64 %t541)
  %t567 = getelementptr i8, ptr %t566, i64 %t541
  %t568 = call i64 @__olang_fmt_i64(ptr %t567, i64 %t544)
  %t569 = getelementptr i8, ptr %t567, i64 %t545
  call void @olang_textcopy(ptr %t569, ptr %t547, i64 %t548)
  %t570 = getelementptr i8, ptr %t569, i64 %t548
  %t571 = call i64 @__olang_fmt_i64(ptr %t570, i64 %t551)
  %t572 = getelementptr i8, ptr %t570, i64 %t552
  call void @olang_textcopy(ptr %t572, ptr %t554, i64 %t555)
  %t573 = getelementptr i8, ptr %t572, i64 %t555
  %t574 = call i64 @__olang_fmt_i64(ptr %t573, i64 %t558)
  %t575 = getelementptr i8, ptr %t573, i64 %t559
  call void @olang_textcopy(ptr %t575, ptr %t561, i64 %t562)
  %t576 = insertvalue { i64, ptr } undef, i64 %t563, 0
  %t577 = insertvalue { i64, ptr } %t576, ptr %t564, 1
  %t579 = extractvalue { i64, ptr } %t577, 0
  %t580 = extractvalue { i64, ptr } %t577, 1
  %t581 = mul i64 %t579, 1
  %t582 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t581)
  call void @llvm.memcpy.p0.p0.i64(ptr %t582, ptr %t580, i64 %t581, i1 false)
  %t583 = insertvalue { i64, ptr } undef, i64 %t579, 0
  %t584 = insertvalue { i64, ptr } %t583, ptr %t582, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s16, ptr %t529, { i64, ptr } %t584)
  br label %bb48
bb48:
  %t587 = load ptr, ptr %l1, !tbaa !29
  %t588 = load i32, ptr %l17, !tbaa !23
  %t589 = load i32, ptr %l17, !tbaa !23
  %t590 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d264, i32 0, i32 1) }, 1
  %t591 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d264, i32 0, i32 1) }, 0
  %t593 = sext i32 %t588 to i64
  %t594 = call i64 @__olang_fmt_i64(ptr null, i64 %t593)
  %t595 = add i64 %t591, %t594
  %t596 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d265, i32 0, i32 1) }, 1
  %t597 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d265, i32 0, i32 1) }, 0
  %t598 = add i64 %t595, %t597
  %t600 = sext i32 %t589 to i64
  %t601 = call i64 @__olang_fmt_i64(ptr null, i64 %t600)
  %t602 = add i64 %t598, %t601
  %t603 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d266, i32 0, i32 1) }, 1
  %t604 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d266, i32 0, i32 1) }, 0
  %t605 = add i64 %t602, %t604
  %t606 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t605)
  call void @olang_textcopy(ptr %t606, ptr %t590, i64 %t591)
  %t607 = getelementptr i8, ptr %t606, i64 %t591
  %t608 = call i64 @__olang_fmt_i64(ptr %t607, i64 %t593)
  %t609 = getelementptr i8, ptr %t607, i64 %t594
  call void @olang_textcopy(ptr %t609, ptr %t596, i64 %t597)
  %t610 = getelementptr i8, ptr %t609, i64 %t597
  %t611 = call i64 @__olang_fmt_i64(ptr %t610, i64 %t600)
  %t612 = getelementptr i8, ptr %t610, i64 %t601
  call void @olang_textcopy(ptr %t612, ptr %t603, i64 %t604)
  %t613 = insertvalue { i64, ptr } undef, i64 %t605, 0
  %t614 = insertvalue { i64, ptr } %t613, ptr %t606, 1
  %t616 = extractvalue { i64, ptr } %t614, 0
  %t617 = extractvalue { i64, ptr } %t614, 1
  %t618 = mul i64 %t616, 1
  %t619 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t618)
  call void @llvm.memcpy.p0.p0.i64(ptr %t619, ptr %t617, i64 %t618, i1 false)
  %t620 = insertvalue { i64, ptr } undef, i64 %t616, 0
  %t621 = insertvalue { i64, ptr } %t620, ptr %t619, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s16, ptr %t587, { i64, ptr } %t621)
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s16)
  br label %bb50
bb50:
  %t624 = getelementptr %"compiler/mir:TaskClause", ptr %l18, i32 0, i32 2
  %t625 = load { i64, [4 x i64] }, ptr %t624
  %t627 = extractvalue { i64, [4 x i64] } %t625, 0
  %t628 = icmp eq i64 %t627, 0
  %t630 = xor i1 %t628, true
  br i1 %t630, label %bb51, label %bb52
bb51:
  store %olang.scope zeroinitializer, ptr %s19
  %t632 = load ptr, ptr %l0, !tbaa !29
  %t633 = getelementptr %"compiler/mir:TaskClause", ptr %l18, i32 0, i32 2
  %t634 = load { i64, [4 x i64] }, ptr %t633
  %t637 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eotype(ptr %v0, ptr %t632, { i64, [4 x i64] } %t634)
  store i32 %t637, ptr %l207
  br label %bb53
bb52:
  br label %bb123
bb53:
  %t638 = load i32, ptr %l207, !tbaa !23
  store i32 %t638, ptr %l30, !tbaa !23
  %t639 = load ptr, ptr %l8, !tbaa !29
  %t640 = load i32, ptr %l30, !tbaa !23
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2esignature(ptr %v0, ptr %t639, i32 %t640)
  br label %bb54
bb54:
  %t643 = load ptr, ptr %l1, !tbaa !29
  %t644 = load i32, ptr %l17, !tbaa !23
  %t645 = load i64, ptr %l11, !tbaa !24
  %t646 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d267, i32 0, i32 1) }, 1
  %t647 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d267, i32 0, i32 1) }, 0
  %t649 = sext i32 %t644 to i64
  %t650 = call i64 @__olang_fmt_i64(ptr null, i64 %t649)
  %t651 = add i64 %t647, %t650
  %t652 = extractvalue { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d268, i32 0, i32 1) }, 1
  %t653 = extractvalue { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d268, i32 0, i32 1) }, 0
  %t654 = add i64 %t651, %t653
  %t656 = call i64 @__olang_fmt_i64(ptr null, i64 %t645)
  %t657 = add i64 %t654, %t656
  %t658 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d269, i32 0, i32 1) }, 1
  %t659 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d269, i32 0, i32 1) }, 0
  %t660 = add i64 %t657, %t659
  %t661 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t660)
  call void @olang_textcopy(ptr %t661, ptr %t646, i64 %t647)
  %t662 = getelementptr i8, ptr %t661, i64 %t647
  %t663 = call i64 @__olang_fmt_i64(ptr %t662, i64 %t649)
  %t664 = getelementptr i8, ptr %t662, i64 %t650
  call void @olang_textcopy(ptr %t664, ptr %t652, i64 %t653)
  %t665 = getelementptr i8, ptr %t664, i64 %t653
  %t666 = call i64 @__olang_fmt_i64(ptr %t665, i64 %t645)
  %t667 = getelementptr i8, ptr %t665, i64 %t656
  call void @olang_textcopy(ptr %t667, ptr %t658, i64 %t659)
  %t668 = insertvalue { i64, ptr } undef, i64 %t660, 0
  %t669 = insertvalue { i64, ptr } %t668, ptr %t661, 1
  %t671 = extractvalue { i64, ptr } %t669, 0
  %t672 = extractvalue { i64, ptr } %t669, 1
  %t673 = mul i64 %t671, 1
  %t674 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t673)
  call void @llvm.memcpy.p0.p0.i64(ptr %t674, ptr %t672, i64 %t673, i1 false)
  %t675 = insertvalue { i64, ptr } undef, i64 %t671, 0
  %t676 = insertvalue { i64, ptr } %t675, ptr %t674, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s19, ptr %t643, { i64, ptr } %t676)
  br label %bb55
bb55:
  %t679 = load ptr, ptr %l1, !tbaa !29
  %t680 = load i32, ptr %l17, !tbaa !23
  %t681 = load i32, ptr %l17, !tbaa !23
  %t682 = load i32, ptr %l17, !tbaa !23
  %t683 = load i32, ptr %l17, !tbaa !23
  %t684 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d270, i32 0, i32 1) }, 1
  %t685 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d270, i32 0, i32 1) }, 0
  %t687 = sext i32 %t680 to i64
  %t688 = call i64 @__olang_fmt_i64(ptr null, i64 %t687)
  %t689 = add i64 %t685, %t688
  %t690 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d271, i32 0, i32 1) }, 1
  %t691 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d271, i32 0, i32 1) }, 0
  %t692 = add i64 %t689, %t691
  %t694 = sext i32 %t681 to i64
  %t695 = call i64 @__olang_fmt_i64(ptr null, i64 %t694)
  %t696 = add i64 %t692, %t695
  %t697 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d272, i32 0, i32 1) }, 1
  %t698 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d272, i32 0, i32 1) }, 0
  %t699 = add i64 %t696, %t698
  %t701 = sext i32 %t682 to i64
  %t702 = call i64 @__olang_fmt_i64(ptr null, i64 %t701)
  %t703 = add i64 %t699, %t702
  %t704 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d271, i32 0, i32 1) }, 1
  %t705 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d271, i32 0, i32 1) }, 0
  %t706 = add i64 %t703, %t705
  %t708 = sext i32 %t683 to i64
  %t709 = call i64 @__olang_fmt_i64(ptr null, i64 %t708)
  %t710 = add i64 %t706, %t709
  %t711 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d273, i32 0, i32 1) }, 1
  %t712 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d273, i32 0, i32 1) }, 0
  %t713 = add i64 %t710, %t712
  %t714 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t713)
  call void @olang_textcopy(ptr %t714, ptr %t684, i64 %t685)
  %t715 = getelementptr i8, ptr %t714, i64 %t685
  %t716 = call i64 @__olang_fmt_i64(ptr %t715, i64 %t687)
  %t717 = getelementptr i8, ptr %t715, i64 %t688
  call void @olang_textcopy(ptr %t717, ptr %t690, i64 %t691)
  %t718 = getelementptr i8, ptr %t717, i64 %t691
  %t719 = call i64 @__olang_fmt_i64(ptr %t718, i64 %t694)
  %t720 = getelementptr i8, ptr %t718, i64 %t695
  call void @olang_textcopy(ptr %t720, ptr %t697, i64 %t698)
  %t721 = getelementptr i8, ptr %t720, i64 %t698
  %t722 = call i64 @__olang_fmt_i64(ptr %t721, i64 %t701)
  %t723 = getelementptr i8, ptr %t721, i64 %t702
  call void @olang_textcopy(ptr %t723, ptr %t704, i64 %t705)
  %t724 = getelementptr i8, ptr %t723, i64 %t705
  %t725 = call i64 @__olang_fmt_i64(ptr %t724, i64 %t708)
  %t726 = getelementptr i8, ptr %t724, i64 %t709
  call void @olang_textcopy(ptr %t726, ptr %t711, i64 %t712)
  %t727 = insertvalue { i64, ptr } undef, i64 %t713, 0
  %t728 = insertvalue { i64, ptr } %t727, ptr %t714, 1
  %t730 = extractvalue { i64, ptr } %t728, 0
  %t731 = extractvalue { i64, ptr } %t728, 1
  %t732 = mul i64 %t730, 1
  %t733 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t732)
  call void @llvm.memcpy.p0.p0.i64(ptr %t733, ptr %t731, i64 %t732, i1 false)
  %t734 = insertvalue { i64, ptr } undef, i64 %t730, 0
  %t735 = insertvalue { i64, ptr } %t734, ptr %t733, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s19, ptr %t679, { i64, ptr } %t735)
  br label %bb56
bb56:
  %t738 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s19)
  store %"std/prelude/text:StringBuilder" %t738, ptr %l222
  br label %bb57
bb57:
  %t739 = load %"std/prelude/text:StringBuilder", ptr %l222
  store %"std/prelude/text:StringBuilder" %t739, ptr %l31
  %t740 = load i32, ptr %l17, !tbaa !23
  %t741 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d274, i32 0, i32 1) }, 1
  %t742 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d274, i32 0, i32 1) }, 0
  %t744 = sext i32 %t740 to i64
  %t745 = call i64 @__olang_fmt_i64(ptr null, i64 %t744)
  %t746 = add i64 %t742, %t745
  %t747 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t746)
  call void @olang_textcopy(ptr %t747, ptr %t741, i64 %t742)
  %t748 = getelementptr i8, ptr %t747, i64 %t742
  %t749 = call i64 @__olang_fmt_i64(ptr %t748, i64 %t744)
  %t750 = insertvalue { i64, ptr } undef, i64 %t746, 0
  %t751 = insertvalue { i64, ptr } %t750, ptr %t747, 1
  %t753 = extractvalue { i64, ptr } %t751, 0
  %t754 = extractvalue { i64, ptr } %t751, 1
  %t755 = mul i64 %t753, 1
  %t756 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t755)
  call void @llvm.memcpy.p0.p0.i64(ptr %t756, ptr %t754, i64 %t755, i1 false)
  %t757 = insertvalue { i64, ptr } undef, i64 %t753, 0
  %t758 = insertvalue { i64, ptr } %t757, ptr %t756, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s19, ptr %s19, ptr %l31, { i64, ptr } %t758)
  br label %bb58
bb58:
  %t761 = load ptr, ptr %l9, !tbaa !29
  %t762 = load i32, ptr %l30, !tbaa !23
  %t765 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t761, i32 %t762)
  store i32 %t765, ptr %l229
  br label %bb59
bb59:
  %t766 = load i32, ptr %l229, !tbaa !23
  store i32 %t766, ptr %l32, !tbaa !23
  %t767 = load i32, ptr %l32, !tbaa !23
  %t768 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t771 = icmp ne i32 %t767, %t768
  br i1 %t771, label %bb60, label %bb61
bb60:
  %t773 = load i32, ptr %l32, !tbaa !23
  %t774 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t777 = icmp ne i32 %t773, %t774
  store i1 %t777, ptr %l233, !tbaa !21
  br label %bb62
bb61:
  store i1 false, ptr %l233, !tbaa !21
  br label %bb62
bb62:
  %t779 = load i1, ptr %l233, !tbaa !21
  br i1 %t779, label %bb63, label %bb64
bb63:
  %t780 = load ptr, ptr %l9, !tbaa !29
  %t781 = load i32, ptr %l32, !tbaa !23
  %t784 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eViaMemory(ptr %v0, ptr %t780, i32 %t781)
  store i1 %t784, ptr %l240
  br label %bb65
bb64:
  store i1 false, ptr %l237, !tbaa !21
  br label %bb66
bb65:
  %t785 = load i1, ptr %l240, !tbaa !21
  store i1 %t785, ptr %l237, !tbaa !21
  br label %bb66
bb66:
  %t786 = load i1, ptr %l237, !tbaa !21
  store i1 %t786, ptr %l33, !tbaa !21
  %t787 = load i1, ptr %l33, !tbaa !21
  br i1 %t787, label %bb67, label %bb68
bb67:
  store %olang.scope zeroinitializer, ptr %s23
  %t789 = load ptr, ptr %l1, !tbaa !29
  store ptr %t789, ptr %l242, !tbaa !29
  %t790 = load i32, ptr %l17, !tbaa !23
  store i32 %t790, ptr %l243, !tbaa !23
  %t791 = load ptr, ptr %l8, !tbaa !29
  %t792 = load i32, ptr %l32, !tbaa !23
  %t795 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %s23, ptr %t791, i32 %t792)
  store { i64, ptr } %t795, ptr %l246
  br label %bb69
bb68:
  br label %bb72
bb69:
  %t796 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d275, i32 0, i32 1) }, 1
  %t797 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d275, i32 0, i32 1) }, 0
  %t798 = load i32, ptr %l243, !tbaa !23
  %t799 = sext i32 %t798 to i64
  %t800 = call i64 @__olang_fmt_i64(ptr null, i64 %t799)
  %t801 = add i64 %t797, %t800
  %t802 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d276, i32 0, i32 1) }, 1
  %t803 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d276, i32 0, i32 1) }, 0
  %t804 = add i64 %t801, %t803
  %t805 = load { i64, ptr }, ptr %l246, !tbaa !27
  %t806 = extractvalue { i64, ptr } %t805, 1
  %t807 = extractvalue { i64, ptr } %t805, 0
  %t808 = add i64 %t804, %t807
  %t809 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d277, i32 0, i32 1) }, 1
  %t810 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d277, i32 0, i32 1) }, 0
  %t811 = add i64 %t808, %t810
  %t812 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t811)
  call void @olang_textcopy(ptr %t812, ptr %t796, i64 %t797)
  %t813 = getelementptr i8, ptr %t812, i64 %t797
  %t814 = call i64 @__olang_fmt_i64(ptr %t813, i64 %t799)
  %t815 = getelementptr i8, ptr %t813, i64 %t800
  call void @olang_textcopy(ptr %t815, ptr %t802, i64 %t803)
  %t816 = getelementptr i8, ptr %t815, i64 %t803
  call void @olang_textcopy(ptr %t816, ptr %t806, i64 %t807)
  %t817 = getelementptr i8, ptr %t816, i64 %t807
  call void @olang_textcopy(ptr %t817, ptr %t809, i64 %t810)
  %t818 = insertvalue { i64, ptr } undef, i64 %t811, 0
  %t819 = insertvalue { i64, ptr } %t818, ptr %t812, 1
  %t821 = extractvalue { i64, ptr } %t819, 0
  %t822 = extractvalue { i64, ptr } %t819, 1
  %t823 = mul i64 %t821, 1
  %t824 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t823)
  call void @llvm.memcpy.p0.p0.i64(ptr %t824, ptr %t822, i64 %t823, i1 false)
  %t825 = insertvalue { i64, ptr } undef, i64 %t821, 0
  %t826 = insertvalue { i64, ptr } %t825, ptr %t824, 1
  %t827 = load ptr, ptr %l242, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s23, ptr %t827, { i64, ptr } %t826)
  br label %bb70
bb70:
  %t829 = load i32, ptr %l17, !tbaa !23
  %t830 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d278, i32 0, i32 1) }, 1
  %t831 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d278, i32 0, i32 1) }, 0
  %t833 = sext i32 %t829 to i64
  %t834 = call i64 @__olang_fmt_i64(ptr null, i64 %t833)
  %t835 = add i64 %t831, %t834
  %t836 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t835)
  call void @olang_textcopy(ptr %t836, ptr %t830, i64 %t831)
  %t837 = getelementptr i8, ptr %t836, i64 %t831
  %t838 = call i64 @__olang_fmt_i64(ptr %t837, i64 %t833)
  %t839 = insertvalue { i64, ptr } undef, i64 %t835, 0
  %t840 = insertvalue { i64, ptr } %t839, ptr %t836, 1
  %t842 = extractvalue { i64, ptr } %t840, 0
  %t843 = extractvalue { i64, ptr } %t840, 1
  %t844 = mul i64 %t842, 1
  %t845 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t844)
  call void @llvm.memcpy.p0.p0.i64(ptr %t845, ptr %t843, i64 %t844, i1 false)
  %t846 = insertvalue { i64, ptr } undef, i64 %t842, 0
  %t847 = insertvalue { i64, ptr } %t846, ptr %t845, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s19, ptr %s23, ptr %l31, { i64, ptr } %t847)
  br label %bb71
bb71:
  call void @__olang_scope_close(ptr %s23)
  br label %bb72
bb72:
  store i64 0, ptr %l34, !tbaa !24
  %t850 = load ptr, ptr %l9, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t851
  %t852 = getelementptr { i64, [4 x i64] }, ptr %t851, i32 0, i32 0
  store i64 0, ptr %t852
  %t853 = load { i64, [4 x i64] }, ptr %t851
  store { i64, [7 x i64] } zeroinitializer, ptr %t854
  %t855 = getelementptr { i64, [7 x i64] }, ptr %t854, i32 0, i32 0
  store i64 2, ptr %t855
  %t857 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t853, 0
  %t858 = getelementptr { i64, [7 x i64] }, ptr %t854, i32 0, i32 1
  store { { i64, [4 x i64] } } %t857, ptr %t858
  %t859 = load { i64, [7 x i64] }, ptr %t854
  %t860 = load i32, ptr %l30, !tbaa !23
  %t864 = call i64 @compiler_2fmir_2ePassedCount(ptr %v0, ptr %t850, { i64, [7 x i64] } %t859, i32 %t860)
  store i64 %t864, ptr %l257
  br label %bb73
bb73:
  %t865 = load i64, ptr %l257, !tbaa !24
  store i64 %t865, ptr %l35, !tbaa !24
  store i64 1, ptr %l36, !tbaa !24
  %t866 = load i64, ptr %l35, !tbaa !24
  %t867 = load i64, ptr %l34, !tbaa !24
  %t870 = icmp sgt i64 %t866, %t867
  br i1 %t870, label %bb74, label %bb75
bb74:
  %t872 = load i64, ptr %l36, !tbaa !24
  %t874 = icmp sgt i64 %t872, 0
  br i1 %t874, label %bb76, label %bb77
bb75:
  store i64 0, ptr %l261, !tbaa !24
  br label %bb79
bb76:
  %t876 = load i64, ptr %l35, !tbaa !24
  %t877 = load i64, ptr %l34, !tbaa !24
  %t880 = sub i64 %t876, %t877
  %t881 = load i64, ptr %l36, !tbaa !24
  %t884 = add i64 %t880, %t881
  %t886 = sub i64 %t884, 1
  %t887 = load i64, ptr %l36, !tbaa !24
  %t890 = sdiv i64 %t886, %t887
  store i64 %t890, ptr %l264, !tbaa !24
  br label %bb78
bb77:
  store i64 0, ptr %l264, !tbaa !24
  br label %bb78
bb78:
  %t892 = load i64, ptr %l264, !tbaa !24
  store i64 %t892, ptr %l261, !tbaa !24
  br label %bb79
bb79:
  %t893 = load i64, ptr %l261, !tbaa !24
  store i64 %t893, ptr %l37, !tbaa !24
  store i64 0, ptr %l38, !tbaa !24
  br label %bb80
bb80:
  store %olang.scope zeroinitializer, ptr %s27
  %t894 = load i64, ptr %l38, !tbaa !24
  %t895 = load i64, ptr %l37, !tbaa !24
  %t898 = icmp slt i64 %t894, %t895
  %t900 = xor i1 %t898, true
  br i1 %t900, label %bb81, label %bb82
bb81:
  call void @__olang_scope_close(ptr %s27)
  br label %bb88
bb82:
  br label %bb83
bb83:
  %t902 = load i64, ptr %l34, !tbaa !24
  %t903 = load i64, ptr %l38, !tbaa !24
  %t904 = load i64, ptr %l36, !tbaa !24
  %t907 = mul i64 %t903, %t904
  %t910 = add i64 %t902, %t907
  store i64 %t910, ptr %l39, !tbaa !24
  %t912 = load ptr, ptr %l8, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edefine(ptr %v0, ptr %s27, ptr %s27, ptr %t912, { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d279, i32 0, i32 1) }, { i64, ptr } { i64 67, ptr getelementptr inbounds (<{ i64, [67 x i8] }>, ptr @.d280, i32 0, i32 1) })
  br label %bb84
bb84:
  %t914 = load ptr, ptr %l1, !tbaa !29
  %t915 = load i32, ptr %l17, !tbaa !23
  %t916 = load i64, ptr %l39, !tbaa !24
  %t917 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d281, i32 0, i32 1) }, 1
  %t918 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d281, i32 0, i32 1) }, 0
  %t920 = sext i32 %t915 to i64
  %t921 = call i64 @__olang_fmt_i64(ptr null, i64 %t920)
  %t922 = add i64 %t918, %t921
  %t923 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d282, i32 0, i32 1) }, 1
  %t924 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d282, i32 0, i32 1) }, 0
  %t925 = add i64 %t922, %t924
  %t927 = call i64 @__olang_fmt_i64(ptr null, i64 %t916)
  %t928 = add i64 %t925, %t927
  %t929 = extractvalue { i64, ptr } { i64 37, ptr getelementptr inbounds (<{ i64, [37 x i8] }>, ptr @.d283, i32 0, i32 1) }, 1
  %t930 = extractvalue { i64, ptr } { i64 37, ptr getelementptr inbounds (<{ i64, [37 x i8] }>, ptr @.d283, i32 0, i32 1) }, 0
  %t931 = add i64 %t928, %t930
  %t932 = call ptr @__olang_scope_alloc(ptr %s27, i64 %t931)
  call void @olang_textcopy(ptr %t932, ptr %t917, i64 %t918)
  %t933 = getelementptr i8, ptr %t932, i64 %t918
  %t934 = call i64 @__olang_fmt_i64(ptr %t933, i64 %t920)
  %t935 = getelementptr i8, ptr %t933, i64 %t921
  call void @olang_textcopy(ptr %t935, ptr %t923, i64 %t924)
  %t936 = getelementptr i8, ptr %t935, i64 %t924
  %t937 = call i64 @__olang_fmt_i64(ptr %t936, i64 %t916)
  %t938 = getelementptr i8, ptr %t936, i64 %t927
  call void @olang_textcopy(ptr %t938, ptr %t929, i64 %t930)
  %t939 = insertvalue { i64, ptr } undef, i64 %t931, 0
  %t940 = insertvalue { i64, ptr } %t939, ptr %t932, 1
  %t942 = extractvalue { i64, ptr } %t940, 0
  %t943 = extractvalue { i64, ptr } %t940, 1
  %t944 = mul i64 %t942, 1
  %t945 = call ptr @__olang_scope_alloc(ptr %s27, i64 %t944)
  call void @llvm.memcpy.p0.p0.i64(ptr %t945, ptr %t943, i64 %t944, i1 false)
  %t946 = insertvalue { i64, ptr } undef, i64 %t942, 0
  %t947 = insertvalue { i64, ptr } %t946, ptr %t945, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s27, ptr %t914, { i64, ptr } %t947)
  br label %bb85
bb85:
  %t950 = load i32, ptr %l17, !tbaa !23
  %t951 = load i64, ptr %l39, !tbaa !24
  %t952 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d284, i32 0, i32 1) }, 1
  %t953 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d284, i32 0, i32 1) }, 0
  %t955 = sext i32 %t950 to i64
  %t956 = call i64 @__olang_fmt_i64(ptr null, i64 %t955)
  %t957 = add i64 %t953, %t956
  %t958 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d285, i32 0, i32 1) }, 1
  %t959 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d285, i32 0, i32 1) }, 0
  %t960 = add i64 %t957, %t959
  %t962 = call i64 @__olang_fmt_i64(ptr null, i64 %t951)
  %t963 = add i64 %t960, %t962
  %t964 = call ptr @__olang_scope_alloc(ptr %s27, i64 %t963)
  call void @olang_textcopy(ptr %t964, ptr %t952, i64 %t953)
  %t965 = getelementptr i8, ptr %t964, i64 %t953
  %t966 = call i64 @__olang_fmt_i64(ptr %t965, i64 %t955)
  %t967 = getelementptr i8, ptr %t965, i64 %t956
  call void @olang_textcopy(ptr %t967, ptr %t958, i64 %t959)
  %t968 = getelementptr i8, ptr %t967, i64 %t959
  %t969 = call i64 @__olang_fmt_i64(ptr %t968, i64 %t951)
  %t970 = insertvalue { i64, ptr } undef, i64 %t963, 0
  %t971 = insertvalue { i64, ptr } %t970, ptr %t964, 1
  %t973 = extractvalue { i64, ptr } %t971, 0
  %t974 = extractvalue { i64, ptr } %t971, 1
  %t975 = mul i64 %t973, 1
  %t976 = call ptr @__olang_scope_alloc(ptr %s27, i64 %t975)
  call void @llvm.memcpy.p0.p0.i64(ptr %t976, ptr %t974, i64 %t975, i1 false)
  %t977 = insertvalue { i64, ptr } undef, i64 %t973, 0
  %t978 = insertvalue { i64, ptr } %t977, ptr %t976, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s19, ptr %s27, ptr %l31, { i64, ptr } %t978)
  br label %bb86
bb86:
  call void @__olang_scope_close(ptr %s27)
  br label %bb87
bb87:
  %t981 = load i64, ptr %l38, !tbaa !24
  %t983 = add i64 %t981, 1
  store i64 %t983, ptr %l38, !tbaa !24
  br label %bb80
bb88:
  %t985 = load ptr, ptr %l9, !tbaa !29
  %t986 = load i32, ptr %l30, !tbaa !23
  %t988 = inttoptr i64 0 to ptr
  %t991 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRetLlvm(ptr %v0, ptr %s19, ptr %t988, ptr %t985, i32 %t986)
  store { i64, ptr } %t991, ptr %l298
  br label %bb89
bb89:
  %t992 = load { i64, ptr }, ptr %l298, !tbaa !27
  store { i64, ptr } %t992, ptr %l40, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d286, i32 0, i32 1) }, ptr %l299, !tbaa !27
  %t993 = load { i64, ptr }, ptr %l299, !tbaa !27
  store { i64, ptr } %t993, ptr %l300, !tbaa !27
  %t994 = load { i64, ptr }, ptr %l300, !tbaa !27
  %t995 = extractvalue { i64, ptr } %t994, 0
  store i64 %t995, ptr %l301, !tbaa !24
  %t996 = load i64, ptr %l301, !tbaa !24
  %t997 = mul i64 %t996, 1
  %t998 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t997)
  %t999 = insertvalue { i64, ptr } undef, i64 %t996, 0
  %t1000 = insertvalue { i64, ptr } %t999, ptr %t998, 1
  store { i64, ptr } %t1000, ptr %l302, !tbaa !27
  %t1001 = getelementptr { i64, ptr }, ptr %l302, i32 0, i32 1
  %t1002 = load ptr, ptr %t1001, !tbaa !27
  %t1003 = getelementptr { i64, ptr }, ptr %l300, i32 0, i32 1
  %t1004 = load ptr, ptr %t1003, !tbaa !27
  %t1005 = load i64, ptr %l301, !tbaa !24
  %t1006 = mul i64 %t1005, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1002, ptr %t1004, i64 %t1006, i1 false)
  %t1007 = load { i64, ptr }, ptr %l302, !tbaa !27
  store { i64, ptr } %t1007, ptr %l41, !tbaa !27
  %t1008 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t1010 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s19, ptr %s19, { i64, ptr } %t1008, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d287, i32 0, i32 1) })
  store i1 %t1010, ptr %l304
  br label %bb90
bb90:
  %t1011 = load i1, ptr %l304, !tbaa !21
  br i1 %t1011, label %bb91, label %bb92
bb91:
  store %olang.scope zeroinitializer, ptr %s31
  %t1012 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1012, ptr %l305, !tbaa !29
  %t1013 = load i32, ptr %l17, !tbaa !23
  store i32 %t1013, ptr %l306, !tbaa !23
  %t1015 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s19, ptr %s31, ptr %l31)
  store { i64, ptr } %t1015, ptr %l308
  br label %bb93
bb92:
  store %olang.scope zeroinitializer, ptr %s33
  %t1016 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1016, ptr %l311, !tbaa !29
  %t1017 = load i32, ptr %l17, !tbaa !23
  store i32 %t1017, ptr %l312, !tbaa !23
  %t1018 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t1018, ptr %l313, !tbaa !27
  %t1019 = load i32, ptr %l17, !tbaa !23
  store i32 %t1019, ptr %l314, !tbaa !23
  %t1021 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s19, ptr %s33, ptr %l31)
  store { i64, ptr } %t1021, ptr %l316
  br label %bb95
bb93:
  %t1022 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d288, i32 0, i32 1) }, 1
  %t1023 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d288, i32 0, i32 1) }, 0
  %t1024 = load i32, ptr %l306, !tbaa !23
  %t1025 = sext i32 %t1024 to i64
  %t1026 = call i64 @__olang_fmt_i64(ptr null, i64 %t1025)
  %t1027 = add i64 %t1023, %t1026
  %t1028 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d289, i32 0, i32 1) }, 1
  %t1029 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d289, i32 0, i32 1) }, 0
  %t1030 = add i64 %t1027, %t1029
  %t1031 = load { i64, ptr }, ptr %l308, !tbaa !27
  %t1032 = extractvalue { i64, ptr } %t1031, 1
  %t1033 = extractvalue { i64, ptr } %t1031, 0
  %t1034 = add i64 %t1030, %t1033
  %t1035 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d290, i32 0, i32 1) }, 1
  %t1036 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d290, i32 0, i32 1) }, 0
  %t1037 = add i64 %t1034, %t1036
  %t1038 = call ptr @__olang_scope_alloc(ptr %s31, i64 %t1037)
  call void @olang_textcopy(ptr %t1038, ptr %t1022, i64 %t1023)
  %t1039 = getelementptr i8, ptr %t1038, i64 %t1023
  %t1040 = call i64 @__olang_fmt_i64(ptr %t1039, i64 %t1025)
  %t1041 = getelementptr i8, ptr %t1039, i64 %t1026
  call void @olang_textcopy(ptr %t1041, ptr %t1028, i64 %t1029)
  %t1042 = getelementptr i8, ptr %t1041, i64 %t1029
  call void @olang_textcopy(ptr %t1042, ptr %t1032, i64 %t1033)
  %t1043 = getelementptr i8, ptr %t1042, i64 %t1033
  call void @olang_textcopy(ptr %t1043, ptr %t1035, i64 %t1036)
  %t1044 = insertvalue { i64, ptr } undef, i64 %t1037, 0
  %t1045 = insertvalue { i64, ptr } %t1044, ptr %t1038, 1
  %t1047 = extractvalue { i64, ptr } %t1045, 0
  %t1048 = extractvalue { i64, ptr } %t1045, 1
  %t1049 = mul i64 %t1047, 1
  %t1050 = call ptr @__olang_scope_alloc(ptr %s31, i64 %t1049)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1050, ptr %t1048, i64 %t1049, i1 false)
  %t1051 = insertvalue { i64, ptr } undef, i64 %t1047, 0
  %t1052 = insertvalue { i64, ptr } %t1051, ptr %t1050, 1
  %t1053 = load ptr, ptr %l305, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s31, ptr %t1053, { i64, ptr } %t1052)
  br label %bb94
bb94:
  call void @__olang_scope_close(ptr %s31)
  br label %bb100
bb95:
  %t1055 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d291, i32 0, i32 1) }, 1
  %t1056 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d291, i32 0, i32 1) }, 0
  %t1057 = load i32, ptr %l312, !tbaa !23
  %t1058 = sext i32 %t1057 to i64
  %t1059 = call i64 @__olang_fmt_i64(ptr null, i64 %t1058)
  %t1060 = add i64 %t1056, %t1059
  %t1061 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d292, i32 0, i32 1) }, 1
  %t1062 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d292, i32 0, i32 1) }, 0
  %t1063 = add i64 %t1060, %t1062
  %t1064 = load { i64, ptr }, ptr %l313, !tbaa !27
  %t1065 = extractvalue { i64, ptr } %t1064, 1
  %t1066 = extractvalue { i64, ptr } %t1064, 0
  %t1067 = add i64 %t1063, %t1066
  %t1068 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d293, i32 0, i32 1) }, 1
  %t1069 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d293, i32 0, i32 1) }, 0
  %t1070 = add i64 %t1067, %t1069
  %t1071 = load i32, ptr %l314, !tbaa !23
  %t1072 = sext i32 %t1071 to i64
  %t1073 = call i64 @__olang_fmt_i64(ptr null, i64 %t1072)
  %t1074 = add i64 %t1070, %t1073
  %t1075 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d294, i32 0, i32 1) }, 1
  %t1076 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d294, i32 0, i32 1) }, 0
  %t1077 = add i64 %t1074, %t1076
  %t1078 = load { i64, ptr }, ptr %l316, !tbaa !27
  %t1079 = extractvalue { i64, ptr } %t1078, 1
  %t1080 = extractvalue { i64, ptr } %t1078, 0
  %t1081 = add i64 %t1077, %t1080
  %t1082 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d295, i32 0, i32 1) }, 1
  %t1083 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d295, i32 0, i32 1) }, 0
  %t1084 = add i64 %t1081, %t1083
  %t1085 = call ptr @__olang_scope_alloc(ptr %s33, i64 %t1084)
  call void @olang_textcopy(ptr %t1085, ptr %t1055, i64 %t1056)
  %t1086 = getelementptr i8, ptr %t1085, i64 %t1056
  %t1087 = call i64 @__olang_fmt_i64(ptr %t1086, i64 %t1058)
  %t1088 = getelementptr i8, ptr %t1086, i64 %t1059
  call void @olang_textcopy(ptr %t1088, ptr %t1061, i64 %t1062)
  %t1089 = getelementptr i8, ptr %t1088, i64 %t1062
  call void @olang_textcopy(ptr %t1089, ptr %t1065, i64 %t1066)
  %t1090 = getelementptr i8, ptr %t1089, i64 %t1066
  call void @olang_textcopy(ptr %t1090, ptr %t1068, i64 %t1069)
  %t1091 = getelementptr i8, ptr %t1090, i64 %t1069
  %t1092 = call i64 @__olang_fmt_i64(ptr %t1091, i64 %t1072)
  %t1093 = getelementptr i8, ptr %t1091, i64 %t1073
  call void @olang_textcopy(ptr %t1093, ptr %t1075, i64 %t1076)
  %t1094 = getelementptr i8, ptr %t1093, i64 %t1076
  call void @olang_textcopy(ptr %t1094, ptr %t1079, i64 %t1080)
  %t1095 = getelementptr i8, ptr %t1094, i64 %t1080
  call void @olang_textcopy(ptr %t1095, ptr %t1082, i64 %t1083)
  %t1096 = insertvalue { i64, ptr } undef, i64 %t1084, 0
  %t1097 = insertvalue { i64, ptr } %t1096, ptr %t1085, 1
  %t1099 = extractvalue { i64, ptr } %t1097, 0
  %t1100 = extractvalue { i64, ptr } %t1097, 1
  %t1101 = mul i64 %t1099, 1
  %t1102 = call ptr @__olang_scope_alloc(ptr %s33, i64 %t1101)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1102, ptr %t1100, i64 %t1101, i1 false)
  %t1103 = insertvalue { i64, ptr } undef, i64 %t1099, 0
  %t1104 = insertvalue { i64, ptr } %t1103, ptr %t1102, 1
  %t1105 = load ptr, ptr %l311, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s33, ptr %t1105, { i64, ptr } %t1104)
  br label %bb96
bb96:
  %t1107 = load i32, ptr %l17, !tbaa !23
  %t1108 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d296, i32 0, i32 1) }, 1
  %t1109 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d296, i32 0, i32 1) }, 0
  %t1111 = sext i32 %t1107 to i64
  %t1112 = call i64 @__olang_fmt_i64(ptr null, i64 %t1111)
  %t1113 = add i64 %t1109, %t1112
  %t1114 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t1113)
  call void @olang_textcopy(ptr %t1114, ptr %t1108, i64 %t1109)
  %t1115 = getelementptr i8, ptr %t1114, i64 %t1109
  %t1116 = call i64 @__olang_fmt_i64(ptr %t1115, i64 %t1111)
  %t1117 = insertvalue { i64, ptr } undef, i64 %t1113, 0
  %t1118 = insertvalue { i64, ptr } %t1117, ptr %t1114, 1
  store { i64, ptr } %t1118, ptr %l320, !tbaa !27
  %t1119 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t1120 = extractvalue { i64, ptr } %t1119, 0
  %t1121 = load { i64, ptr }, ptr %l320, !tbaa !27
  %t1122 = extractvalue { i64, ptr } %t1121, 0
  store i64 %t1122, ptr %l322, !tbaa !24
  %t1124 = load i64, ptr %l322, !tbaa !24
  %t1125 = icmp eq i64 %t1120, %t1124
  br i1 %t1125, label %bb97, label %bb98
bb97:
  %t1127 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t1128 = load ptr, ptr %t1127, !tbaa !27
  %t1129 = getelementptr { i64, ptr }, ptr %l320, i32 0, i32 1
  %t1130 = load ptr, ptr %t1129, !tbaa !27
  %t1131 = load i64, ptr %l322, !tbaa !24
  %t1132 = mul i64 %t1131, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1128, ptr %t1130, i64 %t1132, i1 false)
  br label %bb99
bb98:
  %t1133 = load { i64, ptr }, ptr %l320, !tbaa !27
  store { i64, ptr } %t1133, ptr %l41, !tbaa !27
  br label %bb99
bb99:
  call void @__olang_scope_close(ptr %s33)
  br label %bb100
bb100:
  %t1134 = load i1, ptr %l33, !tbaa !21
  br i1 %t1134, label %bb101, label %bb102
bb101:
  store %olang.scope zeroinitializer, ptr %s36
  %t1136 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1136, ptr %l325, !tbaa !29
  %t1137 = load i32, ptr %l17, !tbaa !23
  store i32 %t1137, ptr %l326, !tbaa !23
  %t1138 = load ptr, ptr %l8, !tbaa !29
  %t1139 = load i32, ptr %l32, !tbaa !23
  %t1142 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %s36, ptr %t1138, i32 %t1139)
  store { i64, ptr } %t1142, ptr %l329
  br label %bb103
bb102:
  br label %bb108
bb103:
  %t1143 = load i32, ptr %l17, !tbaa !23
  %t1144 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d297, i32 0, i32 1) }, 1
  %t1145 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d297, i32 0, i32 1) }, 0
  %t1146 = load i32, ptr %l326, !tbaa !23
  %t1147 = sext i32 %t1146 to i64
  %t1148 = call i64 @__olang_fmt_i64(ptr null, i64 %t1147)
  %t1149 = add i64 %t1145, %t1148
  %t1150 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d298, i32 0, i32 1) }, 1
  %t1151 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d298, i32 0, i32 1) }, 0
  %t1152 = add i64 %t1149, %t1151
  %t1153 = load { i64, ptr }, ptr %l329, !tbaa !27
  %t1154 = extractvalue { i64, ptr } %t1153, 1
  %t1155 = extractvalue { i64, ptr } %t1153, 0
  %t1156 = add i64 %t1152, %t1155
  %t1157 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d299, i32 0, i32 1) }, 1
  %t1158 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d299, i32 0, i32 1) }, 0
  %t1159 = add i64 %t1156, %t1158
  %t1161 = sext i32 %t1143 to i64
  %t1162 = call i64 @__olang_fmt_i64(ptr null, i64 %t1161)
  %t1163 = add i64 %t1159, %t1162
  %t1164 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d300, i32 0, i32 1) }, 1
  %t1165 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d300, i32 0, i32 1) }, 0
  %t1166 = add i64 %t1163, %t1165
  %t1167 = call ptr @__olang_scope_alloc(ptr %s36, i64 %t1166)
  call void @olang_textcopy(ptr %t1167, ptr %t1144, i64 %t1145)
  %t1168 = getelementptr i8, ptr %t1167, i64 %t1145
  %t1169 = call i64 @__olang_fmt_i64(ptr %t1168, i64 %t1147)
  %t1170 = getelementptr i8, ptr %t1168, i64 %t1148
  call void @olang_textcopy(ptr %t1170, ptr %t1150, i64 %t1151)
  %t1171 = getelementptr i8, ptr %t1170, i64 %t1151
  call void @olang_textcopy(ptr %t1171, ptr %t1154, i64 %t1155)
  %t1172 = getelementptr i8, ptr %t1171, i64 %t1155
  call void @olang_textcopy(ptr %t1172, ptr %t1157, i64 %t1158)
  %t1173 = getelementptr i8, ptr %t1172, i64 %t1158
  %t1174 = call i64 @__olang_fmt_i64(ptr %t1173, i64 %t1161)
  %t1175 = getelementptr i8, ptr %t1173, i64 %t1162
  call void @olang_textcopy(ptr %t1175, ptr %t1164, i64 %t1165)
  %t1176 = insertvalue { i64, ptr } undef, i64 %t1166, 0
  %t1177 = insertvalue { i64, ptr } %t1176, ptr %t1167, 1
  %t1179 = extractvalue { i64, ptr } %t1177, 0
  %t1180 = extractvalue { i64, ptr } %t1177, 1
  %t1181 = mul i64 %t1179, 1
  %t1182 = call ptr @__olang_scope_alloc(ptr %s36, i64 %t1181)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1182, ptr %t1180, i64 %t1181, i1 false)
  %t1183 = insertvalue { i64, ptr } undef, i64 %t1179, 0
  %t1184 = insertvalue { i64, ptr } %t1183, ptr %t1182, 1
  %t1185 = load ptr, ptr %l325, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s36, ptr %t1185, { i64, ptr } %t1184)
  br label %bb104
bb104:
  %t1187 = load i32, ptr %l17, !tbaa !23
  %t1188 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d301, i32 0, i32 1) }, 1
  %t1189 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d301, i32 0, i32 1) }, 0
  %t1191 = sext i32 %t1187 to i64
  %t1192 = call i64 @__olang_fmt_i64(ptr null, i64 %t1191)
  %t1193 = add i64 %t1189, %t1192
  %t1194 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t1193)
  call void @olang_textcopy(ptr %t1194, ptr %t1188, i64 %t1189)
  %t1195 = getelementptr i8, ptr %t1194, i64 %t1189
  %t1196 = call i64 @__olang_fmt_i64(ptr %t1195, i64 %t1191)
  %t1197 = insertvalue { i64, ptr } undef, i64 %t1193, 0
  %t1198 = insertvalue { i64, ptr } %t1197, ptr %t1194, 1
  store { i64, ptr } %t1198, ptr %l334, !tbaa !27
  %t1199 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t1200 = extractvalue { i64, ptr } %t1199, 0
  %t1201 = load { i64, ptr }, ptr %l334, !tbaa !27
  %t1202 = extractvalue { i64, ptr } %t1201, 0
  store i64 %t1202, ptr %l336, !tbaa !24
  %t1204 = load i64, ptr %l336, !tbaa !24
  %t1205 = icmp eq i64 %t1200, %t1204
  br i1 %t1205, label %bb105, label %bb106
bb105:
  %t1207 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t1208 = load ptr, ptr %t1207, !tbaa !27
  %t1209 = getelementptr { i64, ptr }, ptr %l334, i32 0, i32 1
  %t1210 = load ptr, ptr %t1209, !tbaa !27
  %t1211 = load i64, ptr %l336, !tbaa !24
  %t1212 = mul i64 %t1211, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1208, ptr %t1210, i64 %t1212, i1 false)
  br label %bb107
bb106:
  %t1213 = load { i64, ptr }, ptr %l334, !tbaa !27
  store { i64, ptr } %t1213, ptr %l41, !tbaa !27
  br label %bb107
bb107:
  call void @__olang_scope_close(ptr %s36)
  br label %bb108
bb108:
  %t1214 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t1216 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s19, ptr %s19, { i64, ptr } %t1214, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d302, i32 0, i32 1) })
  store i1 %t1216, ptr %l339
  br label %bb109
bb109:
  %t1217 = load i1, ptr %l339, !tbaa !21
  %t1218 = xor i1 %t1217, true
  br i1 %t1218, label %bb110, label %bb111
bb110:
  %t1220 = getelementptr %"compiler/mir:Task", ptr %l3, i32 0, i32 3
  %t1221 = getelementptr %"compiler/mir:Range", ptr %t1220, i32 0, i32 1
  %t1222 = load i32, ptr %t1221, !tbaa !23
  %t1224 = icmp sgt i32 %t1222, 0
  store i1 %t1224, ptr %l341, !tbaa !21
  br label %bb112
bb111:
  store i1 false, ptr %l341, !tbaa !21
  br label %bb112
bb112:
  %t1226 = load i1, ptr %l341, !tbaa !21
  br i1 %t1226, label %bb113, label %bb114
bb113:
  store %olang.scope zeroinitializer, ptr %s39
  %t1227 = getelementptr %"compiler/mir:Task", ptr %l3, i32 0, i32 3
  %t1228 = getelementptr %"compiler/mir:Range", ptr %t1227, i32 0, i32 1
  %t1229 = load i32, ptr %t1228, !tbaa !23
  %t1231 = icmp eq i32 %t1229, 1
  br i1 %t1231, label %bb115, label %bb116
bb114:
  br label %bb122
bb115:
  store %olang.scope zeroinitializer, ptr %s40
  %t1233 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1233, ptr %l346, !tbaa !29
  %t1234 = load i32, ptr %l17, !tbaa !23
  store i32 %t1234, ptr %l347, !tbaa !23
  %t1235 = load i64, ptr %l6, !tbaa !24
  store i64 %t1235, ptr %l348, !tbaa !24
  %t1236 = load ptr, ptr %l8, !tbaa !29
  %t1237 = load i32, ptr %l32, !tbaa !23
  %t1240 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %s40, ptr %t1236, i32 %t1237)
  store { i64, ptr } %t1240, ptr %l351
  br label %bb117
bb116:
  store %olang.scope zeroinitializer, ptr %s42
  %t1241 = load ptr, ptr %l0, !tbaa !29
  %t1242 = load ptr, ptr %l1, !tbaa !29
  %t1243 = load i32, ptr %l17, !tbaa !23
  %t1245 = sext i32 %t1243 to i64
  %t1246 = call i64 @__olang_fmt_i64(ptr null, i64 %t1245)
  %t1247 = call ptr @__olang_scope_alloc(ptr %s42, i64 %t1246)
  %t1248 = call i64 @__olang_fmt_i64(ptr %t1247, i64 %t1245)
  %t1249 = insertvalue { i64, ptr } undef, i64 %t1246, 0
  %t1250 = insertvalue { i64, ptr } %t1249, ptr %t1247, 1
  %t1252 = extractvalue { i64, ptr } %t1250, 0
  %t1253 = extractvalue { i64, ptr } %t1250, 1
  %t1254 = mul i64 %t1252, 1
  %t1255 = call ptr @__olang_scope_alloc(ptr %s42, i64 %t1254)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1255, ptr %t1253, i64 %t1254, i1 false)
  %t1256 = insertvalue { i64, ptr } undef, i64 %t1252, 0
  %t1257 = insertvalue { i64, ptr } %t1256, ptr %t1255, 1
  %t1258 = load i32, ptr %l32, !tbaa !23
  %t1259 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t1260 = load i64, ptr %l6, !tbaa !24
  %t1261 = getelementptr %"compiler/mir:Task", ptr %l3, i32 0, i32 3
  %t1262 = getelementptr %"compiler/mir:Range", ptr %t1261, i32 0, i32 1
  %t1263 = load i32, ptr %t1262, !tbaa !23
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estoreParts(ptr %v0, ptr %v1, ptr %s42, ptr %s19, ptr %t1241, ptr %t1242, { i64, ptr } %t1257, i32 %t1258, { i64, ptr } %t1259, i64 %t1260, i32 %t1263)
  br label %bb119
bb117:
  %t1271 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t1272 = load i32, ptr %l17, !tbaa !23
  %t1273 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d303, i32 0, i32 1) }, 1
  %t1274 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d303, i32 0, i32 1) }, 0
  %t1275 = load i32, ptr %l347, !tbaa !23
  %t1276 = sext i32 %t1275 to i64
  %t1277 = call i64 @__olang_fmt_i64(ptr null, i64 %t1276)
  %t1278 = add i64 %t1274, %t1277
  %t1279 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d304, i32 0, i32 1) }, 1
  %t1280 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d304, i32 0, i32 1) }, 0
  %t1281 = add i64 %t1278, %t1280
  %t1282 = load i64, ptr %l348, !tbaa !24
  %t1283 = call i64 @__olang_fmt_i64(ptr null, i64 %t1282)
  %t1284 = add i64 %t1281, %t1283
  %t1285 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d305, i32 0, i32 1) }, 1
  %t1286 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d305, i32 0, i32 1) }, 0
  %t1287 = add i64 %t1284, %t1286
  %t1288 = load { i64, ptr }, ptr %l351, !tbaa !27
  %t1289 = extractvalue { i64, ptr } %t1288, 1
  %t1290 = extractvalue { i64, ptr } %t1288, 0
  %t1291 = add i64 %t1287, %t1290
  %t1292 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d306, i32 0, i32 1) }, 1
  %t1293 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d306, i32 0, i32 1) }, 0
  %t1294 = add i64 %t1291, %t1293
  %t1296 = extractvalue { i64, ptr } %t1271, 1
  %t1297 = extractvalue { i64, ptr } %t1271, 0
  %t1298 = add i64 %t1294, %t1297
  %t1299 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d307, i32 0, i32 1) }, 1
  %t1300 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d307, i32 0, i32 1) }, 0
  %t1301 = add i64 %t1298, %t1300
  %t1303 = sext i32 %t1272 to i64
  %t1304 = call i64 @__olang_fmt_i64(ptr null, i64 %t1303)
  %t1305 = add i64 %t1301, %t1304
  %t1306 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d308, i32 0, i32 1) }, 1
  %t1307 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d308, i32 0, i32 1) }, 0
  %t1308 = add i64 %t1305, %t1307
  %t1309 = call ptr @__olang_scope_alloc(ptr %s40, i64 %t1308)
  call void @olang_textcopy(ptr %t1309, ptr %t1273, i64 %t1274)
  %t1310 = getelementptr i8, ptr %t1309, i64 %t1274
  %t1311 = call i64 @__olang_fmt_i64(ptr %t1310, i64 %t1276)
  %t1312 = getelementptr i8, ptr %t1310, i64 %t1277
  call void @olang_textcopy(ptr %t1312, ptr %t1279, i64 %t1280)
  %t1313 = getelementptr i8, ptr %t1312, i64 %t1280
  %t1314 = call i64 @__olang_fmt_i64(ptr %t1313, i64 %t1282)
  %t1315 = getelementptr i8, ptr %t1313, i64 %t1283
  call void @olang_textcopy(ptr %t1315, ptr %t1285, i64 %t1286)
  %t1316 = getelementptr i8, ptr %t1315, i64 %t1286
  call void @olang_textcopy(ptr %t1316, ptr %t1289, i64 %t1290)
  %t1317 = getelementptr i8, ptr %t1316, i64 %t1290
  call void @olang_textcopy(ptr %t1317, ptr %t1292, i64 %t1293)
  %t1318 = getelementptr i8, ptr %t1317, i64 %t1293
  call void @olang_textcopy(ptr %t1318, ptr %t1296, i64 %t1297)
  %t1319 = getelementptr i8, ptr %t1318, i64 %t1297
  call void @olang_textcopy(ptr %t1319, ptr %t1299, i64 %t1300)
  %t1320 = getelementptr i8, ptr %t1319, i64 %t1300
  %t1321 = call i64 @__olang_fmt_i64(ptr %t1320, i64 %t1303)
  %t1322 = getelementptr i8, ptr %t1320, i64 %t1304
  call void @olang_textcopy(ptr %t1322, ptr %t1306, i64 %t1307)
  %t1323 = insertvalue { i64, ptr } undef, i64 %t1308, 0
  %t1324 = insertvalue { i64, ptr } %t1323, ptr %t1309, 1
  %t1326 = extractvalue { i64, ptr } %t1324, 0
  %t1327 = extractvalue { i64, ptr } %t1324, 1
  %t1328 = mul i64 %t1326, 1
  %t1329 = call ptr @__olang_scope_alloc(ptr %s40, i64 %t1328)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1329, ptr %t1327, i64 %t1328, i1 false)
  %t1330 = insertvalue { i64, ptr } undef, i64 %t1326, 0
  %t1331 = insertvalue { i64, ptr } %t1330, ptr %t1329, 1
  %t1332 = load ptr, ptr %l346, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s40, ptr %t1332, { i64, ptr } %t1331)
  br label %bb118
bb118:
  call void @__olang_scope_close(ptr %s40)
  br label %bb120
bb119:
  call void @__olang_scope_close(ptr %s42)
  br label %bb120
bb120:
  %t1334 = load ptr, ptr %l0, !tbaa !29
  %t1335 = load ptr, ptr %l1, !tbaa !29
  %t1336 = load %"compiler/mir:Task", ptr %l3
  %t1337 = load i64, ptr %l6, !tbaa !24
  %t1339 = load i32, ptr %l17, !tbaa !23
  %t1340 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d309, i32 0, i32 1) }, 1
  %t1341 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d309, i32 0, i32 1) }, 0
  %t1343 = sext i32 %t1339 to i64
  %t1344 = call i64 @__olang_fmt_i64(ptr null, i64 %t1343)
  %t1345 = add i64 %t1341, %t1344
  %t1346 = call ptr @__olang_scope_alloc(ptr %s39, i64 %t1345)
  call void @olang_textcopy(ptr %t1346, ptr %t1340, i64 %t1341)
  %t1347 = getelementptr i8, ptr %t1346, i64 %t1341
  %t1348 = call i64 @__olang_fmt_i64(ptr %t1347, i64 %t1343)
  %t1349 = insertvalue { i64, ptr } undef, i64 %t1345, 0
  %t1350 = insertvalue { i64, ptr } %t1349, ptr %t1346, 1
  %t1352 = extractvalue { i64, ptr } %t1350, 0
  %t1353 = extractvalue { i64, ptr } %t1350, 1
  %t1354 = mul i64 %t1352, 1
  %t1355 = call ptr @__olang_scope_alloc(ptr %s39, i64 %t1354)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1355, ptr %t1353, i64 %t1354, i1 false)
  %t1356 = insertvalue { i64, ptr } undef, i64 %t1352, 0
  %t1357 = insertvalue { i64, ptr } %t1356, ptr %t1355, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2etaskFix(ptr %v0, ptr %v1, ptr %v3, ptr %s39, ptr %t1334, ptr %t1335, %"compiler/mir:Task" %t1336, i64 %t1337, { i64, ptr } %a7, { i64, ptr } %t1357)
  br label %bb121
bb121:
  call void @__olang_scope_close(ptr %s39)
  br label %bb122
bb122:
  %t1364 = load i64, ptr %l11, !tbaa !24
  %t1366 = add i64 %t1364, 1
  store i64 %t1366, ptr %l11, !tbaa !24
  call void @__olang_scope_close(ptr %s19)
  br label %bb123
bb123:
  %t1368 = load ptr, ptr %l1, !tbaa !29
  %t1369 = load i32, ptr %l17, !tbaa !23
  %t1370 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d310, i32 0, i32 1) }, 1
  %t1371 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d310, i32 0, i32 1) }, 0
  %t1373 = sext i32 %t1369 to i64
  %t1374 = call i64 @__olang_fmt_i64(ptr null, i64 %t1373)
  %t1375 = add i64 %t1371, %t1374
  %t1376 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d311, i32 0, i32 1) }, 1
  %t1377 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d311, i32 0, i32 1) }, 0
  %t1378 = add i64 %t1375, %t1377
  %t1379 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t1378)
  call void @olang_textcopy(ptr %t1379, ptr %t1370, i64 %t1371)
  %t1380 = getelementptr i8, ptr %t1379, i64 %t1371
  %t1381 = call i64 @__olang_fmt_i64(ptr %t1380, i64 %t1373)
  %t1382 = getelementptr i8, ptr %t1380, i64 %t1374
  call void @olang_textcopy(ptr %t1382, ptr %t1376, i64 %t1377)
  %t1383 = insertvalue { i64, ptr } undef, i64 %t1378, 0
  %t1384 = insertvalue { i64, ptr } %t1383, ptr %t1379, 1
  %t1386 = extractvalue { i64, ptr } %t1384, 0
  %t1387 = extractvalue { i64, ptr } %t1384, 1
  %t1388 = mul i64 %t1386, 1
  %t1389 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t1388)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1389, ptr %t1387, i64 %t1388, i1 false)
  %t1390 = insertvalue { i64, ptr } undef, i64 %t1386, 0
  %t1391 = insertvalue { i64, ptr } %t1390, ptr %t1389, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s2, ptr %t1368, { i64, ptr } %t1391)
  br label %bb124
bb124:
  call void @__olang_scope_close(ptr %s2)
  br label %bb125
bb125:
  %t1394 = load i32, ptr %l16, !tbaa !23
  %t1396 = add i32 %t1394, 1
  store i32 %t1396, ptr %l16, !tbaa !23
  br label %bb8
bb126:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3afnEm_2edeclareVars(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca %"compiler/mir:Local"
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  %l25 = alloca i64
  %l28 = alloca i64
  %l32 = alloca i64
  %l35 = alloca i64
  %l56 = alloca %"compiler/mir:Local"
  %l64 = alloca i1
  %l70 = alloca i1
  %l73 = alloca i1
  %l77 = alloca { i64, ptr }
  %l79 = alloca i1
  %l80 = alloca i1
  %l82 = alloca i1
  %l85 = alloca i64
  %l89 = alloca i64
  %l93 = alloca i64
  %l96 = alloca i64
  %l103 = alloca i64
  %l111 = alloca i64
  %l114 = alloca { i64, ptr }
  %l119 = alloca ptr
  %l120 = alloca i64
  %l122 = alloca { i64, ptr }
  %l132 = alloca ptr
  %l133 = alloca i64
  %l134 = alloca i64
  %l136 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/emit:fnEm", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  store ptr %t9, ptr %l3, !tbaa !29
  %t11 = load ptr, ptr %l2, !tbaa !29
  %t12 = load ptr, ptr %l3, !tbaa !29
  %t14 = getelementptr %"compiler/mir:Fn", ptr %t12, i32 0, i32 2
  %t15 = load i64, ptr %t14, !tbaa !24
  %t18 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgFile(ptr %v0, ptr %t11, i64 %t15)
  store i64 %t18, ptr %l25
  br label %bb1
bb1:
  %t19 = load i64, ptr %l25, !tbaa !24
  store i64 %t19, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  %t20 = load ptr, ptr %l3, !tbaa !29
  %t22 = getelementptr %"compiler/mir:Fn", ptr %t20, i32 0, i32 7
  %t24 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eLen_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %t22)
  store i64 %t24, ptr %l28
  br label %bb2
bb2:
  %t25 = load i64, ptr %l28, !tbaa !24
  store i64 %t25, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t26 = load i64, ptr %l7, !tbaa !24
  %t27 = load i64, ptr %l6, !tbaa !24
  %t30 = icmp sgt i64 %t26, %t27
  br i1 %t30, label %bb3, label %bb4
bb3:
  %t32 = load i64, ptr %l8, !tbaa !24
  %t34 = icmp sgt i64 %t32, 0
  br i1 %t34, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l32, !tbaa !24
  br label %bb8
bb5:
  %t36 = load i64, ptr %l7, !tbaa !24
  %t37 = load i64, ptr %l6, !tbaa !24
  %t40 = sub i64 %t36, %t37
  %t41 = load i64, ptr %l8, !tbaa !24
  %t44 = add i64 %t40, %t41
  %t46 = sub i64 %t44, 1
  %t47 = load i64, ptr %l8, !tbaa !24
  %t50 = sdiv i64 %t46, %t47
  store i64 %t50, ptr %l35, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l35, !tbaa !24
  br label %bb7
bb7:
  %t52 = load i64, ptr %l35, !tbaa !24
  store i64 %t52, ptr %l32, !tbaa !24
  br label %bb8
bb8:
  %t53 = load i64, ptr %l32, !tbaa !24
  store i64 %t53, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t54 = load i64, ptr %l10, !tbaa !24
  %t55 = load i64, ptr %l9, !tbaa !24
  %t58 = icmp slt i64 %t54, %t55
  %t60 = xor i1 %t58, true
  br i1 %t60, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb62
bb11:
  br label %bb12
bb12:
  %t62 = load i64, ptr %l6, !tbaa !24
  %t63 = load i64, ptr %l10, !tbaa !24
  %t64 = load i64, ptr %l8, !tbaa !24
  %t67 = mul i64 %t63, %t64
  %t70 = add i64 %t62, %t67
  store i64 %t70, ptr %l11, !tbaa !24
  %t72 = load ptr, ptr %l3, !tbaa !29
  %t74 = getelementptr %"compiler/mir:Fn", ptr %t72, i32 0, i32 7
  %t75 = load i64, ptr %l11, !tbaa !24
  %t78 = call %"compiler/mir:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %t74, i64 %t75)
  store %"compiler/mir:Local" %t78, ptr %l56
  br label %bb13
bb13:
  %t79 = load %"compiler/mir:Local", ptr %l56
  store %"compiler/mir:Local" %t79, ptr %l12
  %t80 = getelementptr %"compiler/mir:Local", ptr %l12, i32 0, i32 3
  %t81 = load i32, ptr %t80, !range !{i32 0, i32 4}
  %t83 = trunc i64 0 to i32
  %t84 = icmp eq i32 %t81, %t83
  br i1 %t84, label %bb14, label %bb15
bb14:
  %t86 = load i64, ptr %l5, !tbaa !24
  %t88 = add i64 %t86, 1
  store i64 %t88, ptr %l5, !tbaa !24
  br label %bb16
bb15:
  br label %bb16
bb16:
  %t90 = getelementptr %"compiler/mir:Local", ptr %l12, i32 0, i32 3
  %t91 = load i32, ptr %t90, !range !{i32 0, i32 4}
  %t93 = trunc i64 0 to i32
  %t94 = icmp eq i32 %t91, %t93
  %t96 = xor i1 %t94, true
  br i1 %t96, label %bb17, label %bb18
bb17:
  %t98 = getelementptr %"compiler/mir:Local", ptr %l12, i32 0, i32 3
  %t99 = load i32, ptr %t98, !range !{i32 0, i32 4}
  %t101 = trunc i64 2 to i32
  %t102 = icmp eq i32 %t99, %t101
  %t104 = xor i1 %t102, true
  store i1 %t104, ptr %l64, !tbaa !21
  br label %bb19
bb18:
  store i1 false, ptr %l64, !tbaa !21
  br label %bb19
bb19:
  %t106 = load i1, ptr %l64, !tbaa !21
  br i1 %t106, label %bb20, label %bb21
bb20:
  call void @__olang_scope_close(ptr %s2)
  br label %bb61
bb21:
  br label %bb22
bb22:
  %t107 = getelementptr %"compiler/mir:Local", ptr %l12, i32 0, i32 0
  %t108 = load i32, ptr %t107, !tbaa !23
  %t110 = icmp eq i32 %t108, 0
  br i1 %t110, label %bb23, label %bb24
bb23:
  store i1 true, ptr %l70, !tbaa !21
  br label %bb26
bb24:
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr %"compiler/mir:Local", ptr %l12, i32 0, i32 4
  %t114 = load { i64, [1 x i64] }, ptr %t113
  %t117 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2eisFrame(ptr %v0, ptr %t112, { i64, [1 x i64] } %t114)
  store i1 %t117, ptr %l73
  br label %bb25
bb25:
  %t118 = load i1, ptr %l73, !tbaa !21
  %t119 = xor i1 %t118, true
  store i1 %t119, ptr %l70, !tbaa !21
  br label %bb26
bb26:
  %t121 = load i1, ptr %l70, !tbaa !21
  br i1 %t121, label %bb27, label %bb28
bb27:
  call void @__olang_scope_close(ptr %s2)
  br label %bb61
bb28:
  br label %bb29
bb29:
  %t122 = load ptr, ptr %l2, !tbaa !29
  %t123 = getelementptr %"compiler/mir:Local", ptr %l12, i32 0, i32 0
  %t124 = load i32, ptr %t123, !tbaa !23
  %t127 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etext(ptr %v0, ptr %v0, ptr %t122, i32 %t124)
  store { i64, ptr } %t127, ptr %l77
  br label %bb30
bb30:
  %t128 = load { i64, ptr }, ptr %l77, !tbaa !27
  store { i64, ptr } %t128, ptr %l13, !tbaa !27
  %t129 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t131 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t129, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d312, i32 0, i32 1) })
  store i1 %t131, ptr %l79
  br label %bb31
bb31:
  %t132 = load i1, ptr %l79, !tbaa !21
  br i1 %t132, label %bb32, label %bb33
bb32:
  store i1 true, ptr %l80, !tbaa !21
  br label %bb35
bb33:
  %t133 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t135 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s2, { i64, ptr } %t133, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d313, i32 0, i32 1) })
  store i1 %t135, ptr %l82
  br label %bb34
bb34:
  %t136 = load i1, ptr %l82, !tbaa !21
  store i1 %t136, ptr %l80, !tbaa !21
  br label %bb35
bb35:
  %t137 = load i1, ptr %l80, !tbaa !21
  br i1 %t137, label %bb36, label %bb37
bb36:
  call void @__olang_scope_close(ptr %s2)
  br label %bb61
bb37:
  br label %bb38
bb38:
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t139 = getelementptr %"compiler/mir:Local", ptr %l12, i32 0, i32 2
  %t140 = load i32, ptr %t139, !tbaa !23
  %t143 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2esize(ptr %v0, ptr %t138, i32 %t140)
  store i64 %t143, ptr %l85
  br label %bb39
bb39:
  %t144 = load i64, ptr %l85, !tbaa !24
  %t145 = icmp sgt i64 %t144, 65536
  br i1 %t145, label %bb40, label %bb41
bb40:
  call void @__olang_scope_close(ptr %s2)
  br label %bb61
bb41:
  br label %bb42
bb42:
  %t147 = load ptr, ptr %l2, !tbaa !29
  %t148 = getelementptr %"compiler/mir:Local", ptr %l12, i32 0, i32 2
  %t149 = load i32, ptr %t148, !tbaa !23
  %t152 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgType(ptr %v0, ptr %t147, i32 %t149)
  store i64 %t152, ptr %l89
  br label %bb43
bb43:
  %t153 = load i64, ptr %l89, !tbaa !24
  store i64 %t153, ptr %l14, !tbaa !24
  %t154 = load i64, ptr %l14, !tbaa !24
  %t156 = icmp slt i64 %t154, 0
  br i1 %t156, label %bb44, label %bb45
bb44:
  call void @__olang_scope_close(ptr %s2)
  br label %bb61
bb45:
  br label %bb46
bb46:
  %t158 = load ptr, ptr %l2, !tbaa !29
  %t160 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgNew(ptr %v0, ptr %t158)
  store i64 %t160, ptr %l93
  br label %bb47
bb47:
  %t161 = load i64, ptr %l93, !tbaa !24
  store i64 %t161, ptr %l15, !tbaa !24
  %t162 = getelementptr %"compiler/mir:Local", ptr %l12, i32 0, i32 1
  %t163 = getelementptr %"compiler/source:Span", ptr %t162, i32 0, i32 0
  %t164 = load i32, ptr %t163, !tbaa !23
  %t166 = icmp ne i32 %t164, 0
  br i1 %t166, label %bb48, label %bb49
bb48:
  %t168 = load ptr, ptr %l2, !tbaa !29
  %t170 = getelementptr %"compiler/emit:Emitter", ptr %t168, i32 0, i32 2
  %t171 = load ptr, ptr %t170, !tbaa !29
  %t172 = load ptr, ptr %l3, !tbaa !29
  %t174 = getelementptr %"compiler/mir:Fn", ptr %t172, i32 0, i32 2
  %t175 = load i64, ptr %t174, !tbaa !24
  %t176 = getelementptr %"compiler/mir:Local", ptr %l12, i32 0, i32 1
  %t177 = getelementptr %"compiler/source:Span", ptr %t176, i32 0, i32 0
  %t178 = load i32, ptr %t177, !tbaa !23
  %t180 = sext i32 %t178 to i64
  %t184 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLineAt(ptr %v0, ptr %t171, i64 %t175, i64 %t180)
  store i64 %t184, ptr %l103
  br label %bb50
bb49:
  %t185 = load ptr, ptr %l2, !tbaa !29
  %t187 = getelementptr %"compiler/emit:Emitter", ptr %t185, i32 0, i32 2
  %t188 = load ptr, ptr %t187, !tbaa !29
  %t189 = load ptr, ptr %l3, !tbaa !29
  %t191 = getelementptr %"compiler/mir:Fn", ptr %t189, i32 0, i32 2
  %t192 = load i64, ptr %t191, !tbaa !24
  %t193 = load ptr, ptr %l3, !tbaa !29
  %t195 = getelementptr %"compiler/mir:Fn", ptr %t193, i32 0, i32 3
  %t196 = getelementptr %"compiler/source:Span", ptr %t195, i32 0, i32 0
  %t197 = load i32, ptr %t196, !tbaa !23
  %t199 = sext i32 %t197 to i64
  %t203 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLineAt(ptr %v0, ptr %t188, i64 %t192, i64 %t199)
  store i64 %t203, ptr %l111
  br label %bb51
bb50:
  %t204 = load i64, ptr %l103, !tbaa !24
  store i64 %t204, ptr %l96, !tbaa !24
  br label %bb52
bb51:
  %t205 = load i64, ptr %l111, !tbaa !24
  store i64 %t205, ptr %l96, !tbaa !24
  br label %bb52
bb52:
  %t206 = load i64, ptr %l96, !tbaa !24
  store i64 %t206, ptr %l16, !tbaa !24
  %t207 = getelementptr %"compiler/mir:Local", ptr %l12, i32 0, i32 3
  %t208 = load i32, ptr %t207, !range !{i32 0, i32 4}
  %t210 = trunc i64 0 to i32
  %t211 = icmp eq i32 %t208, %t210
  br i1 %t211, label %bb53, label %bb54
bb53:
  %t213 = load i64, ptr %l5, !tbaa !24
  %t214 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d314, i32 0, i32 1) }, 1
  %t215 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d314, i32 0, i32 1) }, 0
  %t217 = call i64 @__olang_fmt_i64(ptr null, i64 %t213)
  %t218 = add i64 %t215, %t217
  %t219 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t218)
  call void @olang_textcopy(ptr %t219, ptr %t214, i64 %t215)
  %t220 = getelementptr i8, ptr %t219, i64 %t215
  %t221 = call i64 @__olang_fmt_i64(ptr %t220, i64 %t213)
  %t222 = insertvalue { i64, ptr } undef, i64 %t218, 0
  %t223 = insertvalue { i64, ptr } %t222, ptr %t219, 1
  %t225 = extractvalue { i64, ptr } %t223, 0
  %t226 = extractvalue { i64, ptr } %t223, 1
  %t227 = mul i64 %t225, 1
  %t228 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t227)
  call void @llvm.memcpy.p0.p0.i64(ptr %t228, ptr %t226, i64 %t227, i1 false)
  %t229 = insertvalue { i64, ptr } undef, i64 %t225, 0
  %t230 = insertvalue { i64, ptr } %t229, ptr %t228, 1
  store { i64, ptr } %t230, ptr %l114, !tbaa !27
  br label %bb55
bb54:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d315, i32 0, i32 1) }, ptr %l114, !tbaa !27
  br label %bb55
bb55:
  %t232 = load { i64, ptr }, ptr %l114, !tbaa !27
  store { i64, ptr } %t232, ptr %l17, !tbaa !27
  %t233 = load ptr, ptr %l0, !tbaa !29
  %t235 = getelementptr %"compiler/emit:fnEm", ptr %t233, i32 0, i32 21
  store ptr %t235, ptr %l119, !tbaa !29
  %t236 = load i64, ptr %l15, !tbaa !24
  store i64 %t236, ptr %l120, !tbaa !24
  %t237 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t239 = call { i64, ptr } @compiler_2femit_2eescape(ptr %v0, ptr %s2, { i64, ptr } %t237)
  store { i64, ptr } %t239, ptr %l122
  br label %bb56
bb56:
  %t240 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t243 = getelementptr %"compiler/emit:fnEm", ptr %t241, i32 0, i32 18
  %t244 = load i64, ptr %t243, !tbaa !24
  %t245 = load i64, ptr %l4, !tbaa !24
  %t246 = load i64, ptr %l16, !tbaa !24
  %t247 = load i64, ptr %l14, !tbaa !24
  %t248 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d316, i32 0, i32 1) }, 1
  %t249 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d316, i32 0, i32 1) }, 0
  %t250 = load i64, ptr %l120, !tbaa !24
  %t251 = call i64 @__olang_fmt_i64(ptr null, i64 %t250)
  %t252 = add i64 %t249, %t251
  %t253 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d317, i32 0, i32 1) }, 1
  %t254 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d317, i32 0, i32 1) }, 0
  %t255 = add i64 %t252, %t254
  %t256 = load { i64, ptr }, ptr %l122, !tbaa !27
  %t257 = extractvalue { i64, ptr } %t256, 1
  %t258 = extractvalue { i64, ptr } %t256, 0
  %t259 = add i64 %t255, %t258
  %t260 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d318, i32 0, i32 1) }, 1
  %t261 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d318, i32 0, i32 1) }, 0
  %t262 = add i64 %t259, %t261
  %t264 = extractvalue { i64, ptr } %t240, 1
  %t265 = extractvalue { i64, ptr } %t240, 0
  %t266 = add i64 %t262, %t265
  %t267 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d319, i32 0, i32 1) }, 1
  %t268 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d319, i32 0, i32 1) }, 0
  %t269 = add i64 %t266, %t268
  %t271 = call i64 @__olang_fmt_i64(ptr null, i64 %t244)
  %t272 = add i64 %t269, %t271
  %t273 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d320, i32 0, i32 1) }, 1
  %t274 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d320, i32 0, i32 1) }, 0
  %t275 = add i64 %t272, %t274
  %t277 = call i64 @__olang_fmt_i64(ptr null, i64 %t245)
  %t278 = add i64 %t275, %t277
  %t279 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d321, i32 0, i32 1) }, 1
  %t280 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d321, i32 0, i32 1) }, 0
  %t281 = add i64 %t278, %t280
  %t283 = call i64 @__olang_fmt_i64(ptr null, i64 %t246)
  %t284 = add i64 %t281, %t283
  %t285 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d322, i32 0, i32 1) }, 1
  %t286 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d322, i32 0, i32 1) }, 0
  %t287 = add i64 %t284, %t286
  %t289 = call i64 @__olang_fmt_i64(ptr null, i64 %t247)
  %t290 = add i64 %t287, %t289
  %t291 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d323, i32 0, i32 1) }, 1
  %t292 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d323, i32 0, i32 1) }, 0
  %t293 = add i64 %t290, %t292
  %t294 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t293)
  call void @olang_textcopy(ptr %t294, ptr %t248, i64 %t249)
  %t295 = getelementptr i8, ptr %t294, i64 %t249
  %t296 = call i64 @__olang_fmt_i64(ptr %t295, i64 %t250)
  %t297 = getelementptr i8, ptr %t295, i64 %t251
  call void @olang_textcopy(ptr %t297, ptr %t253, i64 %t254)
  %t298 = getelementptr i8, ptr %t297, i64 %t254
  call void @olang_textcopy(ptr %t298, ptr %t257, i64 %t258)
  %t299 = getelementptr i8, ptr %t298, i64 %t258
  call void @olang_textcopy(ptr %t299, ptr %t260, i64 %t261)
  %t300 = getelementptr i8, ptr %t299, i64 %t261
  call void @olang_textcopy(ptr %t300, ptr %t264, i64 %t265)
  %t301 = getelementptr i8, ptr %t300, i64 %t265
  call void @olang_textcopy(ptr %t301, ptr %t267, i64 %t268)
  %t302 = getelementptr i8, ptr %t301, i64 %t268
  %t303 = call i64 @__olang_fmt_i64(ptr %t302, i64 %t244)
  %t304 = getelementptr i8, ptr %t302, i64 %t271
  call void @olang_textcopy(ptr %t304, ptr %t273, i64 %t274)
  %t305 = getelementptr i8, ptr %t304, i64 %t274
  %t306 = call i64 @__olang_fmt_i64(ptr %t305, i64 %t245)
  %t307 = getelementptr i8, ptr %t305, i64 %t277
  call void @olang_textcopy(ptr %t307, ptr %t279, i64 %t280)
  %t308 = getelementptr i8, ptr %t307, i64 %t280
  %t309 = call i64 @__olang_fmt_i64(ptr %t308, i64 %t246)
  %t310 = getelementptr i8, ptr %t308, i64 %t283
  call void @olang_textcopy(ptr %t310, ptr %t285, i64 %t286)
  %t311 = getelementptr i8, ptr %t310, i64 %t286
  %t312 = call i64 @__olang_fmt_i64(ptr %t311, i64 %t247)
  %t313 = getelementptr i8, ptr %t311, i64 %t289
  call void @olang_textcopy(ptr %t313, ptr %t291, i64 %t292)
  %t314 = insertvalue { i64, ptr } undef, i64 %t293, 0
  %t315 = insertvalue { i64, ptr } %t314, ptr %t294, 1
  %t317 = extractvalue { i64, ptr } %t315, 0
  %t318 = extractvalue { i64, ptr } %t315, 1
  %t319 = mul i64 %t317, 1
  %t320 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t319)
  call void @llvm.memcpy.p0.p0.i64(ptr %t320, ptr %t318, i64 %t319, i1 false)
  %t321 = insertvalue { i64, ptr } undef, i64 %t317, 0
  %t322 = insertvalue { i64, ptr } %t321, ptr %t320, 1
  %t323 = load ptr, ptr %l119, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s2, ptr %t323, { i64, ptr } %t322)
  br label %bb57
bb57:
  %t325 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s2, ptr %s2, ptr %t325, { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d324, i32 0, i32 1) }, { i64, ptr } { i64 52, ptr getelementptr inbounds (<{ i64, [52 x i8] }>, ptr @.d325, i32 0, i32 1) })
  br label %bb58
bb58:
  store ptr %a1, ptr %l132, !tbaa !29
  %t328 = load i64, ptr %l11, !tbaa !24
  store i64 %t328, ptr %l133, !tbaa !24
  %t329 = load i64, ptr %l15, !tbaa !24
  store i64 %t329, ptr %l134, !tbaa !24
  %t330 = load ptr, ptr %l0, !tbaa !29
  %t332 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2edbgEntry(ptr %v0, ptr %s2, ptr %t330)
  store { i64, ptr } %t332, ptr %l136
  br label %bb59
bb59:
  %t333 = extractvalue { i64, ptr } { i64 45, ptr getelementptr inbounds (<{ i64, [45 x i8] }>, ptr @.d326, i32 0, i32 1) }, 1
  %t334 = extractvalue { i64, ptr } { i64 45, ptr getelementptr inbounds (<{ i64, [45 x i8] }>, ptr @.d326, i32 0, i32 1) }, 0
  %t335 = load i64, ptr %l133, !tbaa !24
  %t336 = call i64 @__olang_fmt_i64(ptr null, i64 %t335)
  %t337 = add i64 %t334, %t336
  %t338 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d327, i32 0, i32 1) }, 1
  %t339 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d327, i32 0, i32 1) }, 0
  %t340 = add i64 %t337, %t339
  %t341 = load i64, ptr %l134, !tbaa !24
  %t342 = call i64 @__olang_fmt_i64(ptr null, i64 %t341)
  %t343 = add i64 %t340, %t342
  %t344 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d328, i32 0, i32 1) }, 1
  %t345 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d328, i32 0, i32 1) }, 0
  %t346 = add i64 %t343, %t345
  %t347 = load { i64, ptr }, ptr %l136, !tbaa !27
  %t348 = extractvalue { i64, ptr } %t347, 1
  %t349 = extractvalue { i64, ptr } %t347, 0
  %t350 = add i64 %t346, %t349
  %t351 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d329, i32 0, i32 1) }, 1
  %t352 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d329, i32 0, i32 1) }, 0
  %t353 = add i64 %t350, %t352
  %t354 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t353)
  call void @olang_textcopy(ptr %t354, ptr %t333, i64 %t334)
  %t355 = getelementptr i8, ptr %t354, i64 %t334
  %t356 = call i64 @__olang_fmt_i64(ptr %t355, i64 %t335)
  %t357 = getelementptr i8, ptr %t355, i64 %t336
  call void @olang_textcopy(ptr %t357, ptr %t338, i64 %t339)
  %t358 = getelementptr i8, ptr %t357, i64 %t339
  %t359 = call i64 @__olang_fmt_i64(ptr %t358, i64 %t341)
  %t360 = getelementptr i8, ptr %t358, i64 %t342
  call void @olang_textcopy(ptr %t360, ptr %t344, i64 %t345)
  %t361 = getelementptr i8, ptr %t360, i64 %t345
  call void @olang_textcopy(ptr %t361, ptr %t348, i64 %t349)
  %t362 = getelementptr i8, ptr %t361, i64 %t349
  call void @olang_textcopy(ptr %t362, ptr %t351, i64 %t352)
  %t363 = insertvalue { i64, ptr } undef, i64 %t353, 0
  %t364 = insertvalue { i64, ptr } %t363, ptr %t354, 1
  %t366 = extractvalue { i64, ptr } %t364, 0
  %t367 = extractvalue { i64, ptr } %t364, 1
  %t368 = mul i64 %t366, 1
  %t369 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t368)
  call void @llvm.memcpy.p0.p0.i64(ptr %t369, ptr %t367, i64 %t368, i1 false)
  %t370 = insertvalue { i64, ptr } undef, i64 %t366, 0
  %t371 = insertvalue { i64, ptr } %t370, ptr %t369, 1
  %t372 = load ptr, ptr %l132, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s2, ptr %t372, { i64, ptr } %t371)
  br label %bb60
bb60:
  call void @__olang_scope_close(ptr %s2)
  br label %bb61
bb61:
  %t374 = load i64, ptr %l10, !tbaa !24
  %t376 = add i64 %t374, 1
  store i64 %t376, ptr %l10, !tbaa !24
  br label %bb9
bb62:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2efloatOverflows(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, i32 %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l17 = alloca i64
  %l24 = alloca { i64, ptr }
  %l26 = alloca i64
  %l30 = alloca i64
  %l31 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l33 = alloca i64
  %l34 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l37 = alloca i64
  %l38 = alloca { i64, ptr }
  %l41 = alloca i1
  %l46 = alloca { i64, ptr }
  %l48 = alloca i64
  %l50 = alloca ptr
  %l51 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %l58 = alloca { i64, ptr }
  %l60 = alloca i64
  %l64 = alloca ptr
  %l65 = alloca { i64, ptr }
  %l76 = alloca { i64, ptr }
  %l79 = alloca { i64, ptr }
  %l81 = alloca i64
  %l83 = alloca ptr
  %l84 = alloca { i64, ptr }
  %l88 = alloca i64
  %l95 = alloca { i64, ptr }
  %l98 = alloca { i64, ptr }
  %l100 = alloca i64
  %l102 = alloca ptr
  %l103 = alloca { i64, ptr }
  %l108 = alloca { i64, ptr }
  %l111 = alloca { i64, ptr }
  %l113 = alloca i64
  %l115 = alloca ptr
  %l121 = alloca { i64, ptr }
  %l124 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store i32 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/emit:Emitter", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l5, !tbaa !29
  %t9 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 1
  %t12 = extractvalue { i64, ptr } %t9, 0
  %t13 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t12)
  call void @olang_textcopy(ptr %t13, ptr %t11, i64 %t12)
  %t14 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t13, 1
  store { i64, ptr } %t15, ptr %l6, !tbaa !27
  %t17 = load ptr, ptr %l5, !tbaa !29
  %t21 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %t17, i32 %a3)
  store i64 %t21, ptr %l17
  br label %bb1
bb1:
  %t22 = load i64, ptr %l17, !tbaa !24
  %t23 = icmp ne i64 %t22, 64
  br i1 %t23, label %bb2, label %bb3
bb2:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t28 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d330, i32 0, i32 1) }, 1
  %t29 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d330, i32 0, i32 1) }, 0
  %t31 = extractvalue { i64, ptr } %a2, 1
  %t32 = extractvalue { i64, ptr } %a2, 0
  %t33 = add i64 %t29, %t32
  %t34 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d331, i32 0, i32 1) }, 1
  %t35 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d331, i32 0, i32 1) }, 0
  %t36 = add i64 %t33, %t35
  %t38 = extractvalue { i64, ptr } %t27, 1
  %t39 = extractvalue { i64, ptr } %t27, 0
  %t40 = add i64 %t36, %t39
  %t41 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d332, i32 0, i32 1) }, 1
  %t42 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d332, i32 0, i32 1) }, 0
  %t43 = add i64 %t40, %t42
  %t44 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t43)
  call void @olang_textcopy(ptr %t44, ptr %t28, i64 %t29)
  %t45 = getelementptr i8, ptr %t44, i64 %t29
  call void @olang_textcopy(ptr %t45, ptr %t31, i64 %t32)
  %t46 = getelementptr i8, ptr %t45, i64 %t32
  call void @olang_textcopy(ptr %t46, ptr %t34, i64 %t35)
  %t47 = getelementptr i8, ptr %t46, i64 %t35
  call void @olang_textcopy(ptr %t47, ptr %t38, i64 %t39)
  %t48 = getelementptr i8, ptr %t47, i64 %t39
  call void @olang_textcopy(ptr %t48, ptr %t41, i64 %t42)
  %t49 = insertvalue { i64, ptr } undef, i64 %t43, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t44, 1
  %t52 = extractvalue { i64, ptr } %t50, 0
  %t53 = extractvalue { i64, ptr } %t50, 1
  %t54 = mul i64 %t52, 1
  %t55 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t54)
  call void @llvm.memcpy.p0.p0.i64(ptr %t55, ptr %t53, i64 %t54, i1 false)
  %t56 = insertvalue { i64, ptr } undef, i64 %t52, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t55, 1
  %t60 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t25, { i64, ptr } %t57)
  store { i64, ptr } %t60, ptr %l24
  br label %bb4
bb3:
  br label %bb8
bb4:
  %t61 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t62 = extractvalue { i64, ptr } %t61, 0
  %t63 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t64 = extractvalue { i64, ptr } %t63, 0
  store i64 %t64, ptr %l26, !tbaa !24
  %t66 = load i64, ptr %l26, !tbaa !24
  %t67 = icmp eq i64 %t62, %t66
  br i1 %t67, label %bb5, label %bb6
bb5:
  %t69 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !27
  %t71 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !27
  %t73 = load i64, ptr %l26, !tbaa !24
  %t74 = mul i64 %t73, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t70, ptr %t72, i64 %t74, i1 false)
  br label %bb7
bb6:
  %t75 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t75, ptr %l6, !tbaa !27
  br label %bb7
bb7:
  br label %bb8
bb8:
  %t76 = load ptr, ptr %l5, !tbaa !29
  %t77 = load i32, ptr %l4, !tbaa !23
  %t80 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %t76, i32 %t77)
  store i64 %t80, ptr %l30
  br label %bb9
bb9:
  %t81 = load i64, ptr %l30, !tbaa !24
  store i64 %t81, ptr %l7, !tbaa !24
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d333, i32 0, i32 1) }, ptr %l31, !tbaa !27
  %t82 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t82, ptr %l32, !tbaa !27
  %t83 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t84 = extractvalue { i64, ptr } %t83, 0
  store i64 %t84, ptr %l33, !tbaa !24
  %t85 = load i64, ptr %l33, !tbaa !24
  %t86 = mul i64 %t85, 1
  %t87 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t86)
  %t88 = insertvalue { i64, ptr } undef, i64 %t85, 0
  %t89 = insertvalue { i64, ptr } %t88, ptr %t87, 1
  store { i64, ptr } %t89, ptr %l34, !tbaa !27
  %t90 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t91 = load ptr, ptr %t90, !tbaa !27
  %t92 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !27
  %t94 = load i64, ptr %l33, !tbaa !24
  %t95 = mul i64 %t94, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t91, ptr %t93, i64 %t95, i1 false)
  %t96 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t96, ptr %l8, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d334, i32 0, i32 1) }, ptr %l35, !tbaa !27
  %t97 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t97, ptr %l36, !tbaa !27
  %t98 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t99 = extractvalue { i64, ptr } %t98, 0
  store i64 %t99, ptr %l37, !tbaa !24
  %t100 = load i64, ptr %l37, !tbaa !24
  %t101 = mul i64 %t100, 1
  %t102 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t101)
  %t103 = insertvalue { i64, ptr } undef, i64 %t100, 0
  %t104 = insertvalue { i64, ptr } %t103, ptr %t102, 1
  store { i64, ptr } %t104, ptr %l38, !tbaa !27
  %t105 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !27
  %t107 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t108 = load ptr, ptr %t107, !tbaa !27
  %t109 = load i64, ptr %l37, !tbaa !24
  %t110 = mul i64 %t109, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t106, ptr %t108, i64 %t110, i1 false)
  %t111 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t111, ptr %l9, !tbaa !27
  %t112 = load ptr, ptr %l5, !tbaa !29
  %t113 = load i32, ptr %l4, !tbaa !23
  %t116 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %t112, i32 %t113)
  store i1 %t116, ptr %l41
  br label %bb10
bb10:
  %t117 = load i1, ptr %l41, !tbaa !21
  br i1 %t117, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s4
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t119 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t120 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d335, i32 0, i32 1) }, 1
  %t121 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d335, i32 0, i32 1) }, 0
  %t123 = extractvalue { i64, ptr } %t119, 1
  %t124 = extractvalue { i64, ptr } %t119, 0
  %t125 = add i64 %t121, %t124
  %t126 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d336, i32 0, i32 1) }, 1
  %t127 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d336, i32 0, i32 1) }, 0
  %t128 = add i64 %t125, %t127
  %t129 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t128)
  call void @olang_textcopy(ptr %t129, ptr %t120, i64 %t121)
  %t130 = getelementptr i8, ptr %t129, i64 %t121
  call void @olang_textcopy(ptr %t130, ptr %t123, i64 %t124)
  %t131 = getelementptr i8, ptr %t130, i64 %t124
  call void @olang_textcopy(ptr %t131, ptr %t126, i64 %t127)
  %t132 = insertvalue { i64, ptr } undef, i64 %t128, 0
  %t133 = insertvalue { i64, ptr } %t132, ptr %t129, 1
  %t135 = extractvalue { i64, ptr } %t133, 0
  %t136 = extractvalue { i64, ptr } %t133, 1
  %t137 = mul i64 %t135, 1
  %t138 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t137)
  call void @llvm.memcpy.p0.p0.i64(ptr %t138, ptr %t136, i64 %t137, i1 false)
  %t139 = insertvalue { i64, ptr } undef, i64 %t135, 0
  %t140 = insertvalue { i64, ptr } %t139, ptr %t138, 1
  %t143 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t118, { i64, ptr } %t140)
  store { i64, ptr } %t143, ptr %l46
  br label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s7
  %t144 = load i64, ptr %l7, !tbaa !24
  %t146 = icmp sgt i64 %t144, 53
  br i1 %t146, label %bb22, label %bb23
bb13:
  %t148 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t149 = extractvalue { i64, ptr } %t148, 0
  %t150 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t151 = extractvalue { i64, ptr } %t150, 0
  store i64 %t151, ptr %l48, !tbaa !24
  %t153 = load i64, ptr %l48, !tbaa !24
  %t154 = icmp eq i64 %t149, %t153
  br i1 %t154, label %bb14, label %bb15
bb14:
  %t156 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t157 = load ptr, ptr %t156, !tbaa !27
  %t158 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t159 = load ptr, ptr %t158, !tbaa !27
  %t160 = load i64, ptr %l48, !tbaa !24
  %t161 = mul i64 %t160, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t157, ptr %t159, i64 %t161, i1 false)
  br label %bb16
bb15:
  %t162 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t162, ptr %l8, !tbaa !27
  br label %bb16
bb16:
  %t163 = load ptr, ptr %l0, !tbaa !29
  store ptr %t163, ptr %l50, !tbaa !29
  %t164 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t164, ptr %l51, !tbaa !27
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t167 = getelementptr %"compiler/emit:fnEm", ptr %t165, i32 0, i32 0
  %t168 = load ptr, ptr %t167, !tbaa !29
  %t169 = load i64, ptr %l7, !tbaa !24
  %t172 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2epow2(ptr %v0, ptr %s4, ptr %t168, i64 %t169)
  store { i64, ptr } %t172, ptr %l55
  br label %bb17
bb17:
  %t173 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d337, i32 0, i32 1) }, 1
  %t174 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d337, i32 0, i32 1) }, 0
  %t175 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t176 = extractvalue { i64, ptr } %t175, 1
  %t177 = extractvalue { i64, ptr } %t175, 0
  %t178 = add i64 %t174, %t177
  %t179 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d338, i32 0, i32 1) }, 1
  %t180 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d338, i32 0, i32 1) }, 0
  %t181 = add i64 %t178, %t180
  %t182 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t183 = extractvalue { i64, ptr } %t182, 1
  %t184 = extractvalue { i64, ptr } %t182, 0
  %t185 = add i64 %t181, %t184
  %t186 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t185)
  call void @olang_textcopy(ptr %t186, ptr %t173, i64 %t174)
  %t187 = getelementptr i8, ptr %t186, i64 %t174
  call void @olang_textcopy(ptr %t187, ptr %t176, i64 %t177)
  %t188 = getelementptr i8, ptr %t187, i64 %t177
  call void @olang_textcopy(ptr %t188, ptr %t179, i64 %t180)
  %t189 = getelementptr i8, ptr %t188, i64 %t180
  call void @olang_textcopy(ptr %t189, ptr %t183, i64 %t184)
  %t190 = insertvalue { i64, ptr } undef, i64 %t185, 0
  %t191 = insertvalue { i64, ptr } %t190, ptr %t186, 1
  %t193 = extractvalue { i64, ptr } %t191, 0
  %t194 = extractvalue { i64, ptr } %t191, 1
  %t195 = mul i64 %t193, 1
  %t196 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t195)
  call void @llvm.memcpy.p0.p0.i64(ptr %t196, ptr %t194, i64 %t195, i1 false)
  %t197 = insertvalue { i64, ptr } undef, i64 %t193, 0
  %t198 = insertvalue { i64, ptr } %t197, ptr %t196, 1
  %t199 = load ptr, ptr %l50, !tbaa !29
  %t201 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t199, { i64, ptr } %t198)
  store { i64, ptr } %t201, ptr %l58
  br label %bb18
bb18:
  %t202 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t203 = extractvalue { i64, ptr } %t202, 0
  %t204 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t205 = extractvalue { i64, ptr } %t204, 0
  store i64 %t205, ptr %l60, !tbaa !24
  %t207 = load i64, ptr %l60, !tbaa !24
  %t208 = icmp eq i64 %t203, %t207
  br i1 %t208, label %bb19, label %bb20
bb19:
  %t210 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t211 = load ptr, ptr %t210, !tbaa !27
  %t212 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t213 = load ptr, ptr %t212, !tbaa !27
  %t214 = load i64, ptr %l60, !tbaa !24
  %t215 = mul i64 %t214, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t211, ptr %t213, i64 %t215, i1 false)
  br label %bb21
bb20:
  %t216 = load { i64, ptr }, ptr %l58, !tbaa !27
  store { i64, ptr } %t216, ptr %l9, !tbaa !27
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s4)
  br label %bb40
bb22:
  store %olang.scope zeroinitializer, ptr %s8
  %t217 = load ptr, ptr %l0, !tbaa !29
  store ptr %t217, ptr %l64, !tbaa !29
  %t218 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t218, ptr %l65, !tbaa !27
  %t219 = load ptr, ptr %l0, !tbaa !29
  %t221 = getelementptr %"compiler/emit:fnEm", ptr %t219, i32 0, i32 0
  %t222 = load ptr, ptr %t221, !tbaa !29
  %t223 = bitcast double 0x3ff0000000000000 to i64
  %t225 = load i64, ptr %l7, !tbaa !24
  %t227 = sub i64 %t225, 1
  %t229 = shl i64 %t227, 52
  %t232 = add i64 %t223, %t229
  %t233 = shl i64 1, 63
  %t236 = or i64 %t232, %t233
  %t239 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2econstText(ptr %v0, ptr %s8, ptr %t222, i32 14, i64 %t236)
  store { i64, ptr } %t239, ptr %l76
  br label %bb24
bb23:
  store %olang.scope zeroinitializer, ptr %s10
  %t240 = load ptr, ptr %l0, !tbaa !29
  store ptr %t240, ptr %l83, !tbaa !29
  %t241 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t241, ptr %l84, !tbaa !27
  %t242 = load ptr, ptr %l0, !tbaa !29
  %t244 = getelementptr %"compiler/emit:fnEm", ptr %t242, i32 0, i32 0
  %t245 = load ptr, ptr %t244, !tbaa !29
  %t246 = load i64, ptr %l7, !tbaa !24
  %t248 = sub i64 %t246, 1
  store i64 %t248, ptr %l88, !tbaa !24
  %t249 = load i64, ptr %l88, !tbaa !24
  %t250 = load i64, ptr %l88, !tbaa !24
  %t251 = shl i64 1, %t250
  %t253 = sitofp i64 %t251 to double
  %t255 = fsub double 0x0000000000000000, %t253
  %t257 = fsub double %t255, 0x3ff0000000000000
  %t259 = bitcast double %t257 to i64
  %t263 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2econstText(ptr %v0, ptr %s10, ptr %t245, i32 14, i64 %t259)
  store { i64, ptr } %t263, ptr %l95
  br label %bb29
bb24:
  %t264 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d339, i32 0, i32 1) }, 1
  %t265 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d339, i32 0, i32 1) }, 0
  %t266 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t267 = extractvalue { i64, ptr } %t266, 1
  %t268 = extractvalue { i64, ptr } %t266, 0
  %t269 = add i64 %t265, %t268
  %t270 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d340, i32 0, i32 1) }, 1
  %t271 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d340, i32 0, i32 1) }, 0
  %t272 = add i64 %t269, %t271
  %t273 = load { i64, ptr }, ptr %l76, !tbaa !27
  %t274 = extractvalue { i64, ptr } %t273, 1
  %t275 = extractvalue { i64, ptr } %t273, 0
  %t276 = add i64 %t272, %t275
  %t277 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t276)
  call void @olang_textcopy(ptr %t277, ptr %t264, i64 %t265)
  %t278 = getelementptr i8, ptr %t277, i64 %t265
  call void @olang_textcopy(ptr %t278, ptr %t267, i64 %t268)
  %t279 = getelementptr i8, ptr %t278, i64 %t268
  call void @olang_textcopy(ptr %t279, ptr %t270, i64 %t271)
  %t280 = getelementptr i8, ptr %t279, i64 %t271
  call void @olang_textcopy(ptr %t280, ptr %t274, i64 %t275)
  %t281 = insertvalue { i64, ptr } undef, i64 %t276, 0
  %t282 = insertvalue { i64, ptr } %t281, ptr %t277, 1
  %t284 = extractvalue { i64, ptr } %t282, 0
  %t285 = extractvalue { i64, ptr } %t282, 1
  %t286 = mul i64 %t284, 1
  %t287 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t286)
  call void @llvm.memcpy.p0.p0.i64(ptr %t287, ptr %t285, i64 %t286, i1 false)
  %t288 = insertvalue { i64, ptr } undef, i64 %t284, 0
  %t289 = insertvalue { i64, ptr } %t288, ptr %t287, 1
  %t290 = load ptr, ptr %l64, !tbaa !29
  %t292 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t290, { i64, ptr } %t289)
  store { i64, ptr } %t292, ptr %l79
  br label %bb25
bb25:
  %t293 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t294 = extractvalue { i64, ptr } %t293, 0
  %t295 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t296 = extractvalue { i64, ptr } %t295, 0
  store i64 %t296, ptr %l81, !tbaa !24
  %t298 = load i64, ptr %l81, !tbaa !24
  %t299 = icmp eq i64 %t294, %t298
  br i1 %t299, label %bb26, label %bb27
bb26:
  %t301 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t302 = load ptr, ptr %t301, !tbaa !27
  %t303 = getelementptr { i64, ptr }, ptr %l79, i32 0, i32 1
  %t304 = load ptr, ptr %t303, !tbaa !27
  %t305 = load i64, ptr %l81, !tbaa !24
  %t306 = mul i64 %t305, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t302, ptr %t304, i64 %t306, i1 false)
  br label %bb28
bb27:
  %t307 = load { i64, ptr }, ptr %l79, !tbaa !27
  store { i64, ptr } %t307, ptr %l8, !tbaa !27
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s8)
  br label %bb34
bb29:
  %t308 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d341, i32 0, i32 1) }, 1
  %t309 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d341, i32 0, i32 1) }, 0
  %t310 = load { i64, ptr }, ptr %l84, !tbaa !27
  %t311 = extractvalue { i64, ptr } %t310, 1
  %t312 = extractvalue { i64, ptr } %t310, 0
  %t313 = add i64 %t309, %t312
  %t314 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d342, i32 0, i32 1) }, 1
  %t315 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d342, i32 0, i32 1) }, 0
  %t316 = add i64 %t313, %t315
  %t317 = load { i64, ptr }, ptr %l95, !tbaa !27
  %t318 = extractvalue { i64, ptr } %t317, 1
  %t319 = extractvalue { i64, ptr } %t317, 0
  %t320 = add i64 %t316, %t319
  %t321 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t320)
  call void @olang_textcopy(ptr %t321, ptr %t308, i64 %t309)
  %t322 = getelementptr i8, ptr %t321, i64 %t309
  call void @olang_textcopy(ptr %t322, ptr %t311, i64 %t312)
  %t323 = getelementptr i8, ptr %t322, i64 %t312
  call void @olang_textcopy(ptr %t323, ptr %t314, i64 %t315)
  %t324 = getelementptr i8, ptr %t323, i64 %t315
  call void @olang_textcopy(ptr %t324, ptr %t318, i64 %t319)
  %t325 = insertvalue { i64, ptr } undef, i64 %t320, 0
  %t326 = insertvalue { i64, ptr } %t325, ptr %t321, 1
  %t328 = extractvalue { i64, ptr } %t326, 0
  %t329 = extractvalue { i64, ptr } %t326, 1
  %t330 = mul i64 %t328, 1
  %t331 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t330)
  call void @llvm.memcpy.p0.p0.i64(ptr %t331, ptr %t329, i64 %t330, i1 false)
  %t332 = insertvalue { i64, ptr } undef, i64 %t328, 0
  %t333 = insertvalue { i64, ptr } %t332, ptr %t331, 1
  %t334 = load ptr, ptr %l83, !tbaa !29
  %t336 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t334, { i64, ptr } %t333)
  store { i64, ptr } %t336, ptr %l98
  br label %bb30
bb30:
  %t337 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t338 = extractvalue { i64, ptr } %t337, 0
  %t339 = load { i64, ptr }, ptr %l98, !tbaa !27
  %t340 = extractvalue { i64, ptr } %t339, 0
  store i64 %t340, ptr %l100, !tbaa !24
  %t342 = load i64, ptr %l100, !tbaa !24
  %t343 = icmp eq i64 %t338, %t342
  br i1 %t343, label %bb31, label %bb32
bb31:
  %t345 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t346 = load ptr, ptr %t345, !tbaa !27
  %t347 = getelementptr { i64, ptr }, ptr %l98, i32 0, i32 1
  %t348 = load ptr, ptr %t347, !tbaa !27
  %t349 = load i64, ptr %l100, !tbaa !24
  %t350 = mul i64 %t349, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t346, ptr %t348, i64 %t350, i1 false)
  br label %bb33
bb32:
  %t351 = load { i64, ptr }, ptr %l98, !tbaa !27
  store { i64, ptr } %t351, ptr %l8, !tbaa !27
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s10)
  br label %bb34
bb34:
  %t352 = load ptr, ptr %l0, !tbaa !29
  store ptr %t352, ptr %l102, !tbaa !29
  %t353 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t353, ptr %l103, !tbaa !27
  %t354 = load ptr, ptr %l0, !tbaa !29
  %t356 = getelementptr %"compiler/emit:fnEm", ptr %t354, i32 0, i32 0
  %t357 = load ptr, ptr %t356, !tbaa !29
  %t358 = load i64, ptr %l7, !tbaa !24
  %t360 = sub i64 %t358, 1
  %t363 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2epow2(ptr %v0, ptr %s7, ptr %t357, i64 %t360)
  store { i64, ptr } %t363, ptr %l108
  br label %bb35
bb35:
  %t364 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d343, i32 0, i32 1) }, 1
  %t365 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d343, i32 0, i32 1) }, 0
  %t366 = load { i64, ptr }, ptr %l103, !tbaa !27
  %t367 = extractvalue { i64, ptr } %t366, 1
  %t368 = extractvalue { i64, ptr } %t366, 0
  %t369 = add i64 %t365, %t368
  %t370 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d344, i32 0, i32 1) }, 1
  %t371 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d344, i32 0, i32 1) }, 0
  %t372 = add i64 %t369, %t371
  %t373 = load { i64, ptr }, ptr %l108, !tbaa !27
  %t374 = extractvalue { i64, ptr } %t373, 1
  %t375 = extractvalue { i64, ptr } %t373, 0
  %t376 = add i64 %t372, %t375
  %t377 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t376)
  call void @olang_textcopy(ptr %t377, ptr %t364, i64 %t365)
  %t378 = getelementptr i8, ptr %t377, i64 %t365
  call void @olang_textcopy(ptr %t378, ptr %t367, i64 %t368)
  %t379 = getelementptr i8, ptr %t378, i64 %t368
  call void @olang_textcopy(ptr %t379, ptr %t370, i64 %t371)
  %t380 = getelementptr i8, ptr %t379, i64 %t371
  call void @olang_textcopy(ptr %t380, ptr %t374, i64 %t375)
  %t381 = insertvalue { i64, ptr } undef, i64 %t376, 0
  %t382 = insertvalue { i64, ptr } %t381, ptr %t377, 1
  %t384 = extractvalue { i64, ptr } %t382, 0
  %t385 = extractvalue { i64, ptr } %t382, 1
  %t386 = mul i64 %t384, 1
  %t387 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t386)
  call void @llvm.memcpy.p0.p0.i64(ptr %t387, ptr %t385, i64 %t386, i1 false)
  %t388 = insertvalue { i64, ptr } undef, i64 %t384, 0
  %t389 = insertvalue { i64, ptr } %t388, ptr %t387, 1
  %t390 = load ptr, ptr %l102, !tbaa !29
  %t392 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t390, { i64, ptr } %t389)
  store { i64, ptr } %t392, ptr %l111
  br label %bb36
bb36:
  %t393 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t394 = extractvalue { i64, ptr } %t393, 0
  %t395 = load { i64, ptr }, ptr %l111, !tbaa !27
  %t396 = extractvalue { i64, ptr } %t395, 0
  store i64 %t396, ptr %l113, !tbaa !24
  %t398 = load i64, ptr %l113, !tbaa !24
  %t399 = icmp eq i64 %t394, %t398
  br i1 %t399, label %bb37, label %bb38
bb37:
  %t401 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t402 = load ptr, ptr %t401, !tbaa !27
  %t403 = getelementptr { i64, ptr }, ptr %l111, i32 0, i32 1
  %t404 = load ptr, ptr %t403, !tbaa !27
  %t405 = load i64, ptr %l113, !tbaa !24
  %t406 = mul i64 %t405, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t402, ptr %t404, i64 %t406, i1 false)
  br label %bb39
bb38:
  %t407 = load { i64, ptr }, ptr %l111, !tbaa !27
  store { i64, ptr } %t407, ptr %l9, !tbaa !27
  br label %bb39
bb39:
  call void @__olang_scope_close(ptr %s7)
  br label %bb40
bb40:
  %t408 = load ptr, ptr %l0, !tbaa !29
  store ptr %t408, ptr %l115, !tbaa !29
  %t409 = load ptr, ptr %l0, !tbaa !29
  %t410 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t411 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t412 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d345, i32 0, i32 1) }, 1
  %t413 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d345, i32 0, i32 1) }, 0
  %t415 = extractvalue { i64, ptr } %t410, 1
  %t416 = extractvalue { i64, ptr } %t410, 0
  %t417 = add i64 %t413, %t416
  %t418 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d346, i32 0, i32 1) }, 1
  %t419 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d346, i32 0, i32 1) }, 0
  %t420 = add i64 %t417, %t419
  %t422 = extractvalue { i64, ptr } %t411, 1
  %t423 = extractvalue { i64, ptr } %t411, 0
  %t424 = add i64 %t420, %t423
  %t425 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t424)
  call void @olang_textcopy(ptr %t425, ptr %t412, i64 %t413)
  %t426 = getelementptr i8, ptr %t425, i64 %t413
  call void @olang_textcopy(ptr %t426, ptr %t415, i64 %t416)
  %t427 = getelementptr i8, ptr %t426, i64 %t416
  call void @olang_textcopy(ptr %t427, ptr %t418, i64 %t419)
  %t428 = getelementptr i8, ptr %t427, i64 %t419
  call void @olang_textcopy(ptr %t428, ptr %t422, i64 %t423)
  %t429 = insertvalue { i64, ptr } undef, i64 %t424, 0
  %t430 = insertvalue { i64, ptr } %t429, ptr %t425, 1
  %t432 = extractvalue { i64, ptr } %t430, 0
  %t433 = extractvalue { i64, ptr } %t430, 1
  %t434 = mul i64 %t432, 1
  %t435 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t434)
  call void @llvm.memcpy.p0.p0.i64(ptr %t435, ptr %t433, i64 %t434, i1 false)
  %t436 = insertvalue { i64, ptr } undef, i64 %t432, 0
  %t437 = insertvalue { i64, ptr } %t436, ptr %t435, 1
  %t440 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t409, { i64, ptr } %t437)
  store { i64, ptr } %t440, ptr %l121
  br label %bb41
bb41:
  %t441 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d347, i32 0, i32 1) }, 1
  %t442 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d347, i32 0, i32 1) }, 0
  %t443 = load { i64, ptr }, ptr %l121, !tbaa !27
  %t444 = extractvalue { i64, ptr } %t443, 1
  %t445 = extractvalue { i64, ptr } %t443, 0
  %t446 = add i64 %t442, %t445
  %t447 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d348, i32 0, i32 1) }, 1
  %t448 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d348, i32 0, i32 1) }, 0
  %t449 = add i64 %t446, %t448
  %t450 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t449)
  call void @olang_textcopy(ptr %t450, ptr %t441, i64 %t442)
  %t451 = getelementptr i8, ptr %t450, i64 %t442
  call void @olang_textcopy(ptr %t451, ptr %t444, i64 %t445)
  %t452 = getelementptr i8, ptr %t451, i64 %t445
  call void @olang_textcopy(ptr %t452, ptr %t447, i64 %t448)
  %t453 = insertvalue { i64, ptr } undef, i64 %t449, 0
  %t454 = insertvalue { i64, ptr } %t453, ptr %t450, 1
  %t456 = extractvalue { i64, ptr } %t454, 0
  %t457 = extractvalue { i64, ptr } %t454, 1
  %t458 = mul i64 %t456, 1
  %t459 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t458)
  call void @llvm.memcpy.p0.p0.i64(ptr %t459, ptr %t457, i64 %t458, i1 false)
  %t460 = insertvalue { i64, ptr } undef, i64 %t456, 0
  %t461 = insertvalue { i64, ptr } %t460, ptr %t459, 1
  %t462 = load ptr, ptr %l115, !tbaa !29
  %t464 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v3, ptr %v3, ptr %t462, { i64, ptr } %t461)
  store { i64, ptr } %t464, ptr %l124
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s0)
  %t465 = load { i64, ptr }, ptr %l124, !tbaa !27
  store { i64, ptr } %t465, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2efresh(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t2, i32 0, i32 6
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = add i64 %t4, 1
  %t8 = load ptr, ptr %l2, !tbaa !29
  %t9 = getelementptr %"compiler/emit:fnEm", ptr %t8, i32 0, i32 6
  store i64 %t6, ptr %t9, !tbaa !24
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/emit:fnEm", ptr %t11, i32 0, i32 6
  %t14 = load i64, ptr %t13, !tbaa !24
  %t16 = extractvalue { i64, ptr } %a1, 1
  %t17 = extractvalue { i64, ptr } %a1, 0
  %t18 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d349, i32 0, i32 1) }, 1
  %t19 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d349, i32 0, i32 1) }, 0
  %t20 = add i64 %t17, %t19
  %t22 = call i64 @__olang_fmt_i64(ptr null, i64 %t14)
  %t23 = add i64 %t20, %t22
  %t24 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t23)
  call void @olang_textcopy(ptr %t24, ptr %t16, i64 %t17)
  %t25 = getelementptr i8, ptr %t24, i64 %t17
  call void @olang_textcopy(ptr %t25, ptr %t18, i64 %t19)
  %t26 = getelementptr i8, ptr %t25, i64 %t19
  %t27 = call i64 @__olang_fmt_i64(ptr %t26, i64 %t14)
  %t28 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t24, 1
  store { i64, ptr } %t29, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3afnEm_2efreshDrops(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca { i64, [2 x i64] }
  %l19 = alloca i64
  %l23 = alloca i64
  %l26 = alloca i64
  %l45 = alloca ptr
  %l48 = alloca i64
  %l52 = alloca i32
  %l57 = alloca %"compiler/mir:Local"
  %l61 = alloca i1
  %l62 = alloca i1
  %l65 = alloca i1
  %l67 = alloca { i64, [2 x i64] }
  %l68 = alloca ptr
  %l69 = alloca i32
  %l70 = alloca i64
  %l75 = alloca i64
  %l76 = alloca i32
  %l77 = alloca { i64, [2 x i64] }
  %l78 = alloca i32
  %l79 = alloca ptr
  %l83 = alloca { i64, ptr }
  %l93 = alloca i1
  %l103 = alloca ptr
  %l107 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/emit:Emitter", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l1, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/emit:fnEm", ptr %t9, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !29
  store ptr %t12, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  %t14 = load ptr, ptr %l2, !tbaa !29
  %t16 = getelementptr %"compiler/mir:Fn", ptr %t14, i32 0, i32 5
  %t18 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eLen_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %t16)
  store i64 %t18, ptr %l19
  br label %bb1
bb1:
  %t19 = load i64, ptr %l19, !tbaa !24
  store i64 %t19, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t20 = load i64, ptr %l4, !tbaa !24
  %t21 = load i64, ptr %l3, !tbaa !24
  %t24 = icmp sgt i64 %t20, %t21
  br i1 %t24, label %bb2, label %bb3
bb2:
  %t26 = load i64, ptr %l5, !tbaa !24
  %t28 = icmp sgt i64 %t26, 0
  br i1 %t28, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb7
bb4:
  %t30 = load i64, ptr %l4, !tbaa !24
  %t31 = load i64, ptr %l3, !tbaa !24
  %t34 = sub i64 %t30, %t31
  %t35 = load i64, ptr %l5, !tbaa !24
  %t38 = add i64 %t34, %t35
  %t40 = sub i64 %t38, 1
  %t41 = load i64, ptr %l5, !tbaa !24
  %t44 = sdiv i64 %t40, %t41
  store i64 %t44, ptr %l26, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l26, !tbaa !24
  br label %bb6
bb6:
  %t46 = load i64, ptr %l26, !tbaa !24
  store i64 %t46, ptr %l23, !tbaa !24
  br label %bb7
bb7:
  %t47 = load i64, ptr %l23, !tbaa !24
  store i64 %t47, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t48 = load i64, ptr %l7, !tbaa !24
  %t49 = load i64, ptr %l6, !tbaa !24
  %t52 = icmp slt i64 %t48, %t49
  %t54 = xor i1 %t52, true
  br i1 %t54, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb43
bb10:
  br label %bb11
bb11:
  %t56 = load i64, ptr %l3, !tbaa !24
  %t57 = load i64, ptr %l7, !tbaa !24
  %t58 = load i64, ptr %l5, !tbaa !24
  %t61 = mul i64 %t57, %t58
  %t64 = add i64 %t56, %t61
  store i64 %t64, ptr %l8, !tbaa !24
  %t66 = load ptr, ptr %l2, !tbaa !29
  %t68 = getelementptr %"compiler/mir:Fn", ptr %t66, i32 0, i32 5
  store ptr %t68, ptr %l45, !tbaa !29
  %t69 = load ptr, ptr %l2, !tbaa !29
  %t71 = getelementptr %"compiler/mir:Fn", ptr %t69, i32 0, i32 5
  %t73 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eLen_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %t71)
  store i64 %t73, ptr %l48
  br label %bb12
bb12:
  %t74 = load i64, ptr %l48, !tbaa !24
  %t75 = sub i64 %t74, 1
  %t76 = load i64, ptr %l8, !tbaa !24
  %t79 = sub i64 %t75, %t76
  %t80 = load ptr, ptr %l45, !tbaa !29
  %t82 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eAt_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %t80, i64 %t79)
  store i32 %t82, ptr %l52
  br label %bb13
bb13:
  %t83 = load i32, ptr %l52, !tbaa !23
  store i32 %t83, ptr %l9, !tbaa !23
  %t84 = load ptr, ptr %l2, !tbaa !29
  %t86 = getelementptr %"compiler/mir:Fn", ptr %t84, i32 0, i32 7
  %t87 = load i32, ptr %l9, !tbaa !23
  %t89 = sext i32 %t87 to i64
  %t92 = call %"compiler/mir:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %t86, i64 %t89)
  store %"compiler/mir:Local" %t92, ptr %l57
  br label %bb14
bb14:
  %t93 = getelementptr %"compiler/mir:Local", ptr %l57, i32 0, i32 2
  %t94 = load i32, ptr %t93, !tbaa !23
  store i32 %t94, ptr %l10, !tbaa !23
  %t96 = load ptr, ptr %l1, !tbaa !29
  %t97 = load i32, ptr %l10, !tbaa !23
  %t100 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t96, i32 %t97)
  store i1 %t100, ptr %l61
  br label %bb15
bb15:
  %t101 = load i1, ptr %l61, !tbaa !21
  br i1 %t101, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l62, !tbaa !21
  br label %bb19
bb17:
  %t102 = load ptr, ptr %l1, !tbaa !29
  %t103 = load i32, ptr %l10, !tbaa !23
  %t106 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNeedsDrop(ptr %v0, ptr %t102, i32 %t103)
  store i1 %t106, ptr %l65
  br label %bb18
bb18:
  %t107 = load i1, ptr %l65, !tbaa !21
  %t108 = xor i1 %t107, true
  store i1 %t108, ptr %l62, !tbaa !21
  br label %bb19
bb19:
  %t110 = load i1, ptr %l62, !tbaa !21
  br i1 %t110, label %bb20, label %bb21
bb20:
  call void @__olang_scope_close(ptr %s2)
  br label %bb42
bb21:
  br label %bb22
bb22:
  %t111 = load ptr, ptr %l1, !tbaa !29
  store ptr %t111, ptr %l68, !tbaa !29
  %t112 = load i32, ptr %l10, !tbaa !23
  store i32 %t112, ptr %l69, !tbaa !23
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t115 = getelementptr %"compiler/emit:fnEm", ptr %t113, i32 0, i32 0
  %t116 = load ptr, ptr %t115, !tbaa !29
  %t118 = getelementptr %"compiler/emit:Emitter", ptr %t116, i32 0, i32 39
  %t119 = load i32, ptr %l10, !tbaa !23
  %t122 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__H165e1ff795edcbb725e28dde18fd1dc2(ptr %v0, ptr %t118, i32 %t119)
  %t123 = extractvalue { i32, i64 } %t122, 1
  %t124 = extractvalue { i32, i64 } %t122, 0
  store i32 %t124, ptr %l76
  %t125 = icmp ne i32 %t124, 0
  br i1 %t125, label %bb24, label %ok.126, !prof !99
ok.126:
  store i64 %t123, ptr %l75
  br label %bb23
bb23:
  %t127 = load i64, ptr %l75, !tbaa !24
  store i64 %t127, ptr %l70, !tbaa !24
  br label %bb26
bb24:
  br label %bb25
bb25:
  store i64 -1, ptr %l70, !tbaa !24
  br label %bb26
bb26:
  %t128 = load ptr, ptr %l68, !tbaa !29
  %t129 = load i32, ptr %l69, !tbaa !23
  %t130 = load i64, ptr %l70, !tbaa !24
  %t131 = call { i32, { i64, [2 x i64] } } @compiler_2fmir_2eFnKey_2eDropFn(ptr %v0, ptr %t128, i32 %t129, i64 %t130)
  %t132 = extractvalue { i32, { i64, [2 x i64] } } %t131, 1
  %t133 = extractvalue { i32, { i64, [2 x i64] } } %t131, 0
  store i32 %t133, ptr %l78
  %t134 = icmp ne i32 %t133, 0
  br i1 %t134, label %bb28, label %ok.135, !prof !99
ok.135:
  store { i64, [2 x i64] } %t132, ptr %l77
  br label %bb27
bb27:
  %t136 = load { i64, [2 x i64] }, ptr %l77
  store { i64, [2 x i64] } %t136, ptr %l67
  br label %bb32
bb28:
  br label %bb29
bb29:
  store %olang.scope zeroinitializer, ptr %s4
  %t137 = load ptr, ptr %l0, !tbaa !29
  store ptr %t137, ptr %l79, !tbaa !29
  %t138 = load ptr, ptr %l1, !tbaa !29
  %t139 = load i32, ptr %l10, !tbaa !23
  %t141 = inttoptr i64 0 to ptr
  %t144 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s4, ptr %t141, ptr %t138, i32 %t139)
  store { i64, ptr } %t144, ptr %l83
  br label %bb30
bb30:
  %t145 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d350, i32 0, i32 1) }, 1
  %t146 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d350, i32 0, i32 1) }, 0
  %t147 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t148 = extractvalue { i64, ptr } %t147, 1
  %t149 = extractvalue { i64, ptr } %t147, 0
  %t150 = add i64 %t146, %t149
  %t151 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t150)
  call void @olang_textcopy(ptr %t151, ptr %t145, i64 %t146)
  %t152 = getelementptr i8, ptr %t151, i64 %t146
  call void @olang_textcopy(ptr %t152, ptr %t148, i64 %t149)
  %t153 = insertvalue { i64, ptr } undef, i64 %t150, 0
  %t154 = insertvalue { i64, ptr } %t153, ptr %t151, 1
  %t156 = extractvalue { i64, ptr } %t154, 0
  %t157 = extractvalue { i64, ptr } %t154, 1
  %t158 = mul i64 %t156, 1
  %t159 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t158)
  call void @llvm.memcpy.p0.p0.i64(ptr %t159, ptr %t157, i64 %t158, i1 false)
  %t160 = insertvalue { i64, ptr } undef, i64 %t156, 0
  %t161 = insertvalue { i64, ptr } %t160, ptr %t159, 1
  %t162 = load ptr, ptr %l79, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2egap(ptr %v0, ptr %s4, ptr %t162, { i64, ptr } %t161)
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb32:
  %t164 = load { i64, [2 x i64] }, ptr %l67
  store { i64, [2 x i64] } %t164, ptr %l11
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t167 = getelementptr %"compiler/emit:fnEm", ptr %t165, i32 0, i32 0
  %t168 = load ptr, ptr %t167, !tbaa !29
  %t169 = load { i64, [2 x i64] }, ptr %l11
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2ewant(ptr %v0, ptr %t168, { i64, [2 x i64] } %t169)
  br label %bb33
bb33:
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t174 = getelementptr %"compiler/emit:fnEm", ptr %t172, i32 0, i32 0
  %t175 = load ptr, ptr %t174, !tbaa !29
  %t177 = getelementptr %"compiler/emit:Emitter", ptr %t175, i32 0, i32 37
  %t178 = load { i64, [2 x i64] }, ptr %l11
  %t181 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e_2e_Hf0a5beca6f8aee4731a76bd327ae0a99(ptr %v0, ptr %t177, { i64, [2 x i64] } %t178)
  store i1 %t181, ptr %l93
  br label %bb34
bb34:
  %t182 = load i1, ptr %l93, !tbaa !21
  %t183 = xor i1 %t182, true
  br i1 %t183, label %bb35, label %bb36
bb35:
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t187 = getelementptr %"compiler/emit:fnEm", ptr %t185, i32 0, i32 0
  %t188 = load ptr, ptr %t187, !tbaa !29
  %t190 = getelementptr %"compiler/emit:Emitter", ptr %t188, i32 0, i32 37
  %t191 = load { i64, [2 x i64] }, ptr %l11
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e_2e_He6968003b8dd5762fa82ec44b4ee1fc9(ptr %v0, ptr %t190, { i64, [2 x i64] } %t191, i1 true)
  br label %bb37
bb36:
  br label %bb39
bb37:
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t196 = getelementptr %"compiler/emit:fnEm", ptr %t194, i32 0, i32 0
  %t197 = load ptr, ptr %t196, !tbaa !29
  %t199 = getelementptr %"compiler/emit:Emitter", ptr %t197, i32 0, i32 36
  %t200 = load { i64, [2 x i64] }, ptr %l11
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFnKey_3e_2ePush_3ccompiler_2fmir_3aFnKey_3e(ptr %v0, ptr %t199, { i64, [2 x i64] } %t200)
  br label %bb38
bb38:
  br label %bb39
bb39:
  %t203 = load ptr, ptr %l0, !tbaa !29
  store ptr %t203, ptr %l103, !tbaa !29
  %t204 = load ptr, ptr %l0, !tbaa !29
  %t206 = getelementptr %"compiler/emit:fnEm", ptr %t204, i32 0, i32 0
  %t207 = load ptr, ptr %t206, !tbaa !29
  %t208 = load { i64, [2 x i64] }, ptr %l11
  %t211 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2esym(ptr %v0, ptr %s2, ptr %t207, { i64, [2 x i64] } %t208)
  store { i64, ptr } %t211, ptr %l107
  br label %bb40
bb40:
  %t212 = load i32, ptr %l9, !tbaa !23
  %t213 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d351, i32 0, i32 1) }, 1
  %t214 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d351, i32 0, i32 1) }, 0
  %t215 = load { i64, ptr }, ptr %l107, !tbaa !27
  %t216 = extractvalue { i64, ptr } %t215, 1
  %t217 = extractvalue { i64, ptr } %t215, 0
  %t218 = add i64 %t214, %t217
  %t219 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d352, i32 0, i32 1) }, 1
  %t220 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d352, i32 0, i32 1) }, 0
  %t221 = add i64 %t218, %t220
  %t223 = sext i32 %t212 to i64
  %t224 = call i64 @__olang_fmt_i64(ptr null, i64 %t223)
  %t225 = add i64 %t221, %t224
  %t226 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d353, i32 0, i32 1) }, 1
  %t227 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d353, i32 0, i32 1) }, 0
  %t228 = add i64 %t225, %t227
  %t229 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t228)
  call void @olang_textcopy(ptr %t229, ptr %t213, i64 %t214)
  %t230 = getelementptr i8, ptr %t229, i64 %t214
  call void @olang_textcopy(ptr %t230, ptr %t216, i64 %t217)
  %t231 = getelementptr i8, ptr %t230, i64 %t217
  call void @olang_textcopy(ptr %t231, ptr %t219, i64 %t220)
  %t232 = getelementptr i8, ptr %t231, i64 %t220
  %t233 = call i64 @__olang_fmt_i64(ptr %t232, i64 %t223)
  %t234 = getelementptr i8, ptr %t232, i64 %t224
  call void @olang_textcopy(ptr %t234, ptr %t226, i64 %t227)
  %t235 = insertvalue { i64, ptr } undef, i64 %t228, 0
  %t236 = insertvalue { i64, ptr } %t235, ptr %t229, 1
  %t238 = extractvalue { i64, ptr } %t236, 0
  %t239 = extractvalue { i64, ptr } %t236, 1
  %t240 = mul i64 %t238, 1
  %t241 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t240)
  call void @llvm.memcpy.p0.p0.i64(ptr %t241, ptr %t239, i64 %t240, i1 false)
  %t242 = insertvalue { i64, ptr } undef, i64 %t238, 0
  %t243 = insertvalue { i64, ptr } %t242, ptr %t241, 1
  %t244 = load ptr, ptr %l103, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s2, ptr %t244, { i64, ptr } %t243)
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s2)
  br label %bb42
bb42:
  %t246 = load i64, ptr %l7, !tbaa !24
  %t248 = add i64 %t246, 1
  store i64 %t248, ptr %l7, !tbaa !24
  br label %bb8
bb43:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3afnEm_2eholdersAt(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2, { i64, ptr } %a3, i1 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l21 = alloca i32
  %l25 = alloca ptr
  %l28 = alloca i1
  %l32 = alloca i32
  %l40 = alloca ptr
  %l41 = alloca ptr
  %l44 = alloca i32
  %l45 = alloca i32
  %l46 = alloca { i64, ptr }
  %l47 = alloca ptr
  %l50 = alloca { i64, ptr }
  %l56 = alloca ptr
  %l59 = alloca { i64, ptr }
  %l67 = alloca i1
  %l68 = alloca ptr
  %l69 = alloca { i64, ptr }
  %l70 = alloca i32
  %l73 = alloca i64
  %l78 = alloca ptr
  %l79 = alloca { i64, ptr }
  %l80 = alloca i32
  %l81 = alloca ptr
  %l86 = alloca { i64, ptr }
  %l88 = alloca { i64, ptr }
  %l93 = alloca i1
  %l94 = alloca ptr
  %l97 = alloca i32
  %l98 = alloca { i64, ptr }
  %l104 = alloca i64
  %l107 = alloca i64
  %l128 = alloca ptr
  %l132 = alloca i1
  %l133 = alloca ptr
  %l134 = alloca ptr
  %l137 = alloca { i64, ptr }
  %l142 = alloca { i64, ptr }
  %l144 = alloca { i64, ptr }
  %l152 = alloca i1
  %l153 = alloca i1
  %l157 = alloca i1
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s14 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/emit:Emitter", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l5, !tbaa !29
  %t9 = load ptr, ptr %l5, !tbaa !29
  %t13 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t9, i32 %a2)
  store i32 %t13, ptr %l21
  br label %bb1
bb1:
  %t14 = load i32, ptr %l21, !tbaa !23
  store i32 %t14, ptr %l6, !tbaa !23
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/emit:fnEm", ptr %t15, i32 0, i32 0
  %t18 = load ptr, ptr %t17, !tbaa !29
  %t20 = getelementptr %"compiler/emit:Emitter", ptr %t18, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t23 = call ptr @compiler_2flower_2ecompiler_2flower_3aLowerer_2eGen(ptr %v0, ptr %v0, ptr %t21)
  store ptr %t23, ptr %l25
  br label %bb2
bb2:
  %t24 = load ptr, ptr %l5, !tbaa !29
  %t25 = load i32, ptr %l6, !tbaa !23
  %t26 = load ptr, ptr %l25, !tbaa !29
  %t29 = call i1 @compiler_2fmir_2ecompiler_2fmir_3aGenInfo_2eHoldsGen(ptr %v0, ptr %v0, ptr %t26, ptr %t24, i32 %t25)
  store i1 %t29, ptr %l28
  br label %bb3
bb3:
  %t30 = load i1, ptr %l28, !tbaa !21
  %t31 = xor i1 %t30, true
  br i1 %t31, label %bb4, label %bb5
bb4:
  br label %ret
bb5:
  br label %bb6
bb6:
  %t33 = load ptr, ptr %l5, !tbaa !29
  %t34 = load i32, ptr %l6, !tbaa !23
  %t37 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t33, i32 %t34)
  store i32 %t37, ptr %l32
  br label %bb7
bb7:
  %t38 = load i32, ptr %l32, !range !{i32 0, i32 33}
  store i32 %t38, ptr %l7
  %t39 = load i32, ptr %l7, !range !{i32 0, i32 33}
  %t41 = trunc i64 20 to i32
  %t42 = icmp eq i32 %t39, %t41
  br i1 %t42, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/emit:fnEm", ptr %t44, i32 0, i32 30
  %t47 = load i1, ptr %t46, !tbaa !21
  br i1 %t47, label %bb10, label %bb11
bb9:
  br label %bb22
bb10:
  store %olang.scope zeroinitializer, ptr %s3
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/emit:fnEm", ptr %t49, i32 0, i32 0
  %t52 = load ptr, ptr %t51, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %s3, ptr %t52, { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d354, i32 0, i32 1) })
  br label %bb12
bb11:
  br label %bb18
bb12:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/emit:fnEm", ptr %t54, i32 0, i32 0
  %t57 = load ptr, ptr %t56, !tbaa !29
  store ptr %t57, ptr %l40, !tbaa !29
  %t58 = load ptr, ptr %l5, !tbaa !29
  store ptr %t58, ptr %l41, !tbaa !29
  %t59 = load ptr, ptr %l5, !tbaa !29
  %t60 = load i32, ptr %l6, !tbaa !23
  %t63 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t59, i32 %t60)
  store i32 %t63, ptr %l44
  br label %bb13
bb13:
  %t64 = load ptr, ptr %l41, !tbaa !29
  %t65 = load i32, ptr %l44, !tbaa !23
  %t66 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t64, i32 %t65)
  store i32 %t66, ptr %l45
  br label %bb14
bb14:
  %t67 = load ptr, ptr %l40, !tbaa !29
  %t68 = load i32, ptr %l45, !tbaa !23
  %t69 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2egenDropFn(ptr %v0, ptr %v0, ptr %t67, i32 %t68)
  store { i64, ptr } %t69, ptr %l46
  br label %bb15
bb15:
  %t70 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t70, ptr %l8, !tbaa !27
  %t71 = load ptr, ptr %l0, !tbaa !29
  store ptr %t71, ptr %l47, !tbaa !29
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t73 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t76 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %s3, ptr %v1, ptr %s3, ptr %s3, ptr %t72, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d355, i32 0, i32 1) }, { i64, ptr } %t73, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d223, i32 0, i32 1) })
  store { i64, ptr } %t76, ptr %l50
  br label %bb16
bb16:
  %t77 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t78 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d356, i32 0, i32 1) }, 1
  %t79 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d356, i32 0, i32 1) }, 0
  %t80 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t81 = extractvalue { i64, ptr } %t80, 1
  %t82 = extractvalue { i64, ptr } %t80, 0
  %t83 = add i64 %t79, %t82
  %t84 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d357, i32 0, i32 1) }, 1
  %t85 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d357, i32 0, i32 1) }, 0
  %t86 = add i64 %t83, %t85
  %t88 = extractvalue { i64, ptr } %t77, 1
  %t89 = extractvalue { i64, ptr } %t77, 0
  %t90 = add i64 %t86, %t89
  %t91 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d358, i32 0, i32 1) }, 1
  %t92 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d358, i32 0, i32 1) }, 0
  %t93 = add i64 %t90, %t92
  %t94 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t93)
  call void @olang_textcopy(ptr %t94, ptr %t78, i64 %t79)
  %t95 = getelementptr i8, ptr %t94, i64 %t79
  call void @olang_textcopy(ptr %t95, ptr %t81, i64 %t82)
  %t96 = getelementptr i8, ptr %t95, i64 %t82
  call void @olang_textcopy(ptr %t96, ptr %t84, i64 %t85)
  %t97 = getelementptr i8, ptr %t96, i64 %t85
  call void @olang_textcopy(ptr %t97, ptr %t88, i64 %t89)
  %t98 = getelementptr i8, ptr %t97, i64 %t89
  call void @olang_textcopy(ptr %t98, ptr %t91, i64 %t92)
  %t99 = insertvalue { i64, ptr } undef, i64 %t93, 0
  %t100 = insertvalue { i64, ptr } %t99, ptr %t94, 1
  %t102 = extractvalue { i64, ptr } %t100, 0
  %t103 = extractvalue { i64, ptr } %t100, 1
  %t104 = mul i64 %t102, 1
  %t105 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t104)
  call void @llvm.memcpy.p0.p0.i64(ptr %t105, ptr %t103, i64 %t104, i1 false)
  %t106 = insertvalue { i64, ptr } undef, i64 %t102, 0
  %t107 = insertvalue { i64, ptr } %t106, ptr %t105, 1
  %t108 = load ptr, ptr %l47, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s3, ptr %t108, { i64, ptr } %t107)
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb18:
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = getelementptr %"compiler/emit:fnEm", ptr %t110, i32 0, i32 0
  %t113 = load ptr, ptr %t112, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %s2, ptr %t113, { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d359, i32 0, i32 1) })
  br label %bb19
bb19:
  %t115 = load ptr, ptr %l0, !tbaa !29
  store ptr %t115, ptr %l56, !tbaa !29
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t117 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t120 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %s2, ptr %v1, ptr %s2, ptr %s2, ptr %t116, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d360, i32 0, i32 1) }, { i64, ptr } %t117, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d223, i32 0, i32 1) })
  store { i64, ptr } %t120, ptr %l59
  br label %bb20
bb20:
  %t121 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t122 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d361, i32 0, i32 1) }, 1
  %t123 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d361, i32 0, i32 1) }, 0
  %t124 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t125 = extractvalue { i64, ptr } %t124, 1
  %t126 = extractvalue { i64, ptr } %t124, 0
  %t127 = add i64 %t123, %t126
  %t128 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d362, i32 0, i32 1) }, 1
  %t129 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d362, i32 0, i32 1) }, 0
  %t130 = add i64 %t127, %t129
  %t132 = extractvalue { i64, ptr } %t121, 1
  %t133 = extractvalue { i64, ptr } %t121, 0
  %t134 = add i64 %t130, %t133
  %t135 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d363, i32 0, i32 1) }, 1
  %t136 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d363, i32 0, i32 1) }, 0
  %t137 = add i64 %t134, %t136
  %t138 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t137)
  call void @olang_textcopy(ptr %t138, ptr %t122, i64 %t123)
  %t139 = getelementptr i8, ptr %t138, i64 %t123
  call void @olang_textcopy(ptr %t139, ptr %t125, i64 %t126)
  %t140 = getelementptr i8, ptr %t139, i64 %t126
  call void @olang_textcopy(ptr %t140, ptr %t128, i64 %t129)
  %t141 = getelementptr i8, ptr %t140, i64 %t129
  call void @olang_textcopy(ptr %t141, ptr %t132, i64 %t133)
  %t142 = getelementptr i8, ptr %t141, i64 %t133
  call void @olang_textcopy(ptr %t142, ptr %t135, i64 %t136)
  %t143 = insertvalue { i64, ptr } undef, i64 %t137, 0
  %t144 = insertvalue { i64, ptr } %t143, ptr %t138, 1
  %t146 = extractvalue { i64, ptr } %t144, 0
  %t147 = extractvalue { i64, ptr } %t144, 1
  %t148 = mul i64 %t146, 1
  %t149 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t148)
  call void @llvm.memcpy.p0.p0.i64(ptr %t149, ptr %t147, i64 %t148, i1 false)
  %t150 = insertvalue { i64, ptr } undef, i64 %t146, 0
  %t151 = insertvalue { i64, ptr } %t150, ptr %t149, 1
  %t152 = load ptr, ptr %l56, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s2, ptr %t152, { i64, ptr } %t151)
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb22:
  %t154 = load i32, ptr %l7, !range !{i32 0, i32 33}
  %t156 = trunc i64 19 to i32
  %t157 = icmp eq i32 %t154, %t156
  br i1 %t157, label %bb23, label %bb24
bb23:
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t160 = load i32, ptr %l6, !tbaa !23
  %t163 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2efixed(ptr %v0, ptr %t159, i32 %t160)
  store i1 %t163, ptr %l67
  br label %bb25
bb24:
  br label %bb37
bb25:
  %t164 = load i1, ptr %l67, !tbaa !21
  br i1 %t164, label %bb26, label %bb27
bb26:
  store %olang.scope zeroinitializer, ptr %s7
  %t165 = load ptr, ptr %l0, !tbaa !29
  store ptr %t165, ptr %l68, !tbaa !29
  %t166 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t166, ptr %l69, !tbaa !27
  %t167 = load i32, ptr %l6, !tbaa !23
  store i32 %t167, ptr %l70, !tbaa !23
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t169 = load i32, ptr %l6, !tbaa !23
  %t172 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2efixedLen(ptr %v0, ptr %t168, i32 %t169)
  store i64 %t172, ptr %l73
  br label %bb28
bb27:
  br i1 %a4, label %bb30, label %bb31
bb28:
  %t175 = load i64, ptr %l73, !tbaa !24
  %t176 = call i64 @__olang_fmt_i64(ptr null, i64 %t175)
  %t177 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t176)
  %t178 = call i64 @__olang_fmt_i64(ptr %t177, i64 %t175)
  %t179 = insertvalue { i64, ptr } undef, i64 %t176, 0
  %t180 = insertvalue { i64, ptr } %t179, ptr %t177, 1
  %t182 = extractvalue { i64, ptr } %t180, 0
  %t183 = extractvalue { i64, ptr } %t180, 1
  %t184 = mul i64 %t182, 1
  %t185 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t184)
  call void @llvm.memcpy.p0.p0.i64(ptr %t185, ptr %t183, i64 %t184, i1 false)
  %t186 = insertvalue { i64, ptr } undef, i64 %t182, 0
  %t187 = insertvalue { i64, ptr } %t186, ptr %t185, 1
  %t188 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t189 = load ptr, ptr %l68, !tbaa !29
  %t190 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t191 = load i32, ptr %l70, !tbaa !23
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2eholdersEach(ptr %v0, ptr %v1, ptr %s7, ptr %v2, ptr %t189, { i64, ptr } %t190, i32 %t191, { i64, ptr } %t187, { i64, ptr } %t188)
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s7)
  br label %bb36
bb30:
  store %olang.scope zeroinitializer, ptr %s10
  %t194 = load ptr, ptr %l0, !tbaa !29
  store ptr %t194, ptr %l78, !tbaa !29
  %t195 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t195, ptr %l79, !tbaa !27
  %t196 = load i32, ptr %l6, !tbaa !23
  store i32 %t196, ptr %l80, !tbaa !23
  %t197 = load ptr, ptr %l0, !tbaa !29
  store ptr %t197, ptr %l81, !tbaa !29
  %t198 = load ptr, ptr %l0, !tbaa !29
  %t199 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t200 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d364, i32 0, i32 1) }, 1
  %t201 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d364, i32 0, i32 1) }, 0
  %t203 = extractvalue { i64, ptr } %t199, 1
  %t204 = extractvalue { i64, ptr } %t199, 0
  %t205 = add i64 %t201, %t204
  %t206 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d365, i32 0, i32 1) }, 1
  %t207 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d365, i32 0, i32 1) }, 0
  %t208 = add i64 %t205, %t207
  %t209 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t208)
  call void @olang_textcopy(ptr %t209, ptr %t200, i64 %t201)
  %t210 = getelementptr i8, ptr %t209, i64 %t201
  call void @olang_textcopy(ptr %t210, ptr %t203, i64 %t204)
  %t211 = getelementptr i8, ptr %t210, i64 %t204
  call void @olang_textcopy(ptr %t211, ptr %t206, i64 %t207)
  %t212 = insertvalue { i64, ptr } undef, i64 %t208, 0
  %t213 = insertvalue { i64, ptr } %t212, ptr %t209, 1
  %t215 = extractvalue { i64, ptr } %t213, 0
  %t216 = extractvalue { i64, ptr } %t213, 1
  %t217 = mul i64 %t215, 1
  %t218 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t217)
  call void @llvm.memcpy.p0.p0.i64(ptr %t218, ptr %t216, i64 %t217, i1 false)
  %t219 = insertvalue { i64, ptr } undef, i64 %t215, 0
  %t220 = insertvalue { i64, ptr } %t219, ptr %t218, 1
  %t223 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s10, ptr %s10, ptr %t198, { i64, ptr } %t220)
  store { i64, ptr } %t223, ptr %l86
  br label %bb32
bb31:
  br label %bb35
bb32:
  %t224 = load { i64, ptr }, ptr %l86, !tbaa !27
  %t225 = extractvalue { i64, ptr } %t224, 0
  %t226 = extractvalue { i64, ptr } %t224, 1
  %t227 = mul i64 %t225, 1
  %t228 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t227)
  call void @llvm.memcpy.p0.p0.i64(ptr %t228, ptr %t226, i64 %t227, i1 false)
  %t229 = insertvalue { i64, ptr } undef, i64 %t225, 0
  %t230 = insertvalue { i64, ptr } %t229, ptr %t228, 1
  %t231 = load ptr, ptr %l81, !tbaa !29
  %t233 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %s10, ptr %s10, ptr %s10, ptr %s10, ptr %t231, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d366, i32 0, i32 1) }, { i64, ptr } %t230, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d223, i32 0, i32 1) })
  store { i64, ptr } %t233, ptr %l88
  br label %bb33
bb33:
  %t234 = load { i64, ptr }, ptr %l88, !tbaa !27
  %t235 = extractvalue { i64, ptr } %t234, 0
  %t236 = extractvalue { i64, ptr } %t234, 1
  %t237 = mul i64 %t235, 1
  %t238 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t237)
  call void @llvm.memcpy.p0.p0.i64(ptr %t238, ptr %t236, i64 %t237, i1 false)
  %t239 = insertvalue { i64, ptr } undef, i64 %t235, 0
  %t240 = insertvalue { i64, ptr } %t239, ptr %t238, 1
  %t241 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t242 = load ptr, ptr %l78, !tbaa !29
  %t243 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t244 = load i32, ptr %l80, !tbaa !23
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2eholdersEach(ptr %v0, ptr %v1, ptr %s10, ptr %v2, ptr %t242, { i64, ptr } %t243, i32 %t244, { i64, ptr } %t240, { i64, ptr } %t241)
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s10)
  br label %bb35
bb35:
  br label %bb36
bb36:
  br label %ret
bb37:
  %t247 = load ptr, ptr %l5, !tbaa !29
  %t248 = load i32, ptr %l6, !tbaa !23
  %t251 = call i1 @compiler_2fmir_2eHasFields(ptr %v0, ptr %t247, i32 %t248)
  store i1 %t251, ptr %l93
  br label %bb38
bb38:
  %t252 = load i1, ptr %l93, !tbaa !21
  br i1 %t252, label %bb39, label %bb40
bb39:
  %t253 = load ptr, ptr %l5, !tbaa !29
  store ptr %t253, ptr %l94, !tbaa !29
  %t254 = load ptr, ptr %l0, !tbaa !29
  %t255 = load i32, ptr %l6, !tbaa !23
  %t258 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2efieldList(ptr %v0, ptr %t254, i32 %t255)
  store i32 %t258, ptr %l97
  br label %bb41
bb40:
  br label %bb63
bb41:
  %t259 = load ptr, ptr %l94, !tbaa !29
  %t260 = load i32, ptr %l97, !tbaa !23
  %t261 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t259, i32 %t260)
  store { i64, ptr } %t261, ptr %l98
  br label %bb42
bb42:
  %t262 = load { i64, ptr }, ptr %l98, !tbaa !27
  store { i64, ptr } %t262, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t263 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t265 = extractvalue { i64, ptr } %t263, 0
  store i64 %t265, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t267 = load i64, ptr %l11, !tbaa !24
  %t268 = load i64, ptr %l10, !tbaa !24
  %t271 = icmp sgt i64 %t267, %t268
  br i1 %t271, label %bb43, label %bb44
bb43:
  %t273 = load i64, ptr %l12, !tbaa !24
  %t275 = icmp sgt i64 %t273, 0
  br i1 %t275, label %bb45, label %bb46
bb44:
  store i64 0, ptr %l104, !tbaa !24
  br label %bb48
bb45:
  %t277 = load i64, ptr %l11, !tbaa !24
  %t278 = load i64, ptr %l10, !tbaa !24
  %t281 = sub i64 %t277, %t278
  %t282 = load i64, ptr %l12, !tbaa !24
  %t285 = add i64 %t281, %t282
  %t287 = sub i64 %t285, 1
  %t288 = load i64, ptr %l12, !tbaa !24
  %t291 = sdiv i64 %t287, %t288
  store i64 %t291, ptr %l107, !tbaa !24
  br label %bb47
bb46:
  store i64 0, ptr %l107, !tbaa !24
  br label %bb47
bb47:
  %t293 = load i64, ptr %l107, !tbaa !24
  store i64 %t293, ptr %l104, !tbaa !24
  br label %bb48
bb48:
  %t294 = load i64, ptr %l104, !tbaa !24
  store i64 %t294, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb49
bb49:
  store %olang.scope zeroinitializer, ptr %s14
  %t295 = load i64, ptr %l14, !tbaa !24
  %t296 = load i64, ptr %l13, !tbaa !24
  %t299 = icmp slt i64 %t295, %t296
  %t301 = xor i1 %t299, true
  br i1 %t301, label %bb50, label %bb51
bb50:
  call void @__olang_scope_close(ptr %s14)
  br label %bb62
bb51:
  br label %bb52
bb52:
  %t303 = load i64, ptr %l10, !tbaa !24
  %t304 = load i64, ptr %l14, !tbaa !24
  %t305 = load i64, ptr %l12, !tbaa !24
  %t308 = mul i64 %t304, %t305
  %t311 = add i64 %t303, %t308
  store i64 %t311, ptr %l15, !tbaa !24
  %t313 = load ptr, ptr %l0, !tbaa !29
  %t315 = getelementptr %"compiler/emit:fnEm", ptr %t313, i32 0, i32 0
  %t316 = load ptr, ptr %t315, !tbaa !29
  %t318 = getelementptr %"compiler/emit:Emitter", ptr %t316, i32 0, i32 1
  %t319 = load ptr, ptr %t318, !tbaa !29
  %t321 = call ptr @compiler_2flower_2ecompiler_2flower_3aLowerer_2eGen(ptr %v0, ptr %v0, ptr %t319)
  store ptr %t321, ptr %l128
  br label %bb53
bb53:
  %t322 = load ptr, ptr %l5, !tbaa !29
  %t323 = load i32, ptr %l6, !tbaa !23
  %t324 = load i64, ptr %l15, !tbaa !24
  %t325 = load ptr, ptr %l128, !tbaa !29
  %t329 = call i1 @compiler_2fmir_2ecompiler_2fmir_3aGenInfo_2eWeakField(ptr %v0, ptr %v0, ptr %t325, ptr %t322, i32 %t323, i64 %t324)
  store i1 %t329, ptr %l132
  br label %bb54
bb54:
  %t330 = load i1, ptr %l132, !tbaa !21
  br i1 %t330, label %bb55, label %bb56
bb55:
  call void @__olang_scope_close(ptr %s14)
  br label %bb61
bb56:
  br label %bb57
bb57:
  %t331 = load ptr, ptr %l0, !tbaa !29
  store ptr %t331, ptr %l133, !tbaa !29
  %t332 = load ptr, ptr %l0, !tbaa !29
  store ptr %t332, ptr %l134, !tbaa !29
  %t333 = load ptr, ptr %l0, !tbaa !29
  %t334 = load i32, ptr %l6, !tbaa !23
  %t337 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s14, ptr %t333, i32 %t334)
  store { i64, ptr } %t337, ptr %l137
  br label %bb58
bb58:
  %t338 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t339 = load i64, ptr %l15, !tbaa !24
  %t340 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d367, i32 0, i32 1) }, 1
  %t341 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d367, i32 0, i32 1) }, 0
  %t342 = load { i64, ptr }, ptr %l137, !tbaa !27
  %t343 = extractvalue { i64, ptr } %t342, 1
  %t344 = extractvalue { i64, ptr } %t342, 0
  %t345 = add i64 %t341, %t344
  %t346 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d368, i32 0, i32 1) }, 1
  %t347 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d368, i32 0, i32 1) }, 0
  %t348 = add i64 %t345, %t347
  %t350 = extractvalue { i64, ptr } %t338, 1
  %t351 = extractvalue { i64, ptr } %t338, 0
  %t352 = add i64 %t348, %t351
  %t353 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d369, i32 0, i32 1) }, 1
  %t354 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d369, i32 0, i32 1) }, 0
  %t355 = add i64 %t352, %t354
  %t357 = call i64 @__olang_fmt_i64(ptr null, i64 %t339)
  %t358 = add i64 %t355, %t357
  %t359 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t358)
  call void @olang_textcopy(ptr %t359, ptr %t340, i64 %t341)
  %t360 = getelementptr i8, ptr %t359, i64 %t341
  call void @olang_textcopy(ptr %t360, ptr %t343, i64 %t344)
  %t361 = getelementptr i8, ptr %t360, i64 %t344
  call void @olang_textcopy(ptr %t361, ptr %t346, i64 %t347)
  %t362 = getelementptr i8, ptr %t361, i64 %t347
  call void @olang_textcopy(ptr %t362, ptr %t350, i64 %t351)
  %t363 = getelementptr i8, ptr %t362, i64 %t351
  call void @olang_textcopy(ptr %t363, ptr %t353, i64 %t354)
  %t364 = getelementptr i8, ptr %t363, i64 %t354
  %t365 = call i64 @__olang_fmt_i64(ptr %t364, i64 %t339)
  %t366 = insertvalue { i64, ptr } undef, i64 %t358, 0
  %t367 = insertvalue { i64, ptr } %t366, ptr %t359, 1
  %t369 = extractvalue { i64, ptr } %t367, 0
  %t370 = extractvalue { i64, ptr } %t367, 1
  %t371 = mul i64 %t369, 1
  %t372 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t371)
  call void @llvm.memcpy.p0.p0.i64(ptr %t372, ptr %t370, i64 %t371, i1 false)
  %t373 = insertvalue { i64, ptr } undef, i64 %t369, 0
  %t374 = insertvalue { i64, ptr } %t373, ptr %t372, 1
  %t375 = load ptr, ptr %l134, !tbaa !29
  %t377 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s14, ptr %s14, ptr %t375, { i64, ptr } %t374)
  store { i64, ptr } %t377, ptr %l142
  br label %bb59
bb59:
  %t378 = load { i64, ptr }, ptr %l142, !tbaa !27
  %t379 = extractvalue { i64, ptr } %t378, 0
  %t380 = extractvalue { i64, ptr } %t378, 1
  %t381 = mul i64 %t379, 1
  %t382 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t381)
  call void @llvm.memcpy.p0.p0.i64(ptr %t382, ptr %t380, i64 %t381, i1 false)
  %t383 = insertvalue { i64, ptr } undef, i64 %t379, 0
  %t384 = insertvalue { i64, ptr } %t383, ptr %t382, 1
  %t385 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t385, ptr %l144, !tbaa !27
  %t386 = load i64, ptr %l15, !tbaa !24
  %t388 = getelementptr { i64, ptr }, ptr %l144, i32 0, i32 1
  %t389 = load ptr, ptr %t388, !tbaa !27
  %t390 = getelementptr i32, ptr %t389, i64 %t386
  %t391 = load i32, ptr %t390, !tbaa !33
  %t392 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t393 = load ptr, ptr %l133, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2eholdersAt(ptr %v0, ptr %s14, ptr %v2, ptr %t393, { i64, ptr } %t384, i32 %t391, { i64, ptr } %t392, i1 false)
  br label %bb60
bb60:
  call void @__olang_scope_close(ptr %s14)
  br label %bb61
bb61:
  %t397 = load i64, ptr %l14, !tbaa !24
  %t399 = add i64 %t397, 1
  store i64 %t399, ptr %l14, !tbaa !24
  br label %bb49
bb62:
  br label %ret
bb63:
  %t401 = load ptr, ptr %l5, !tbaa !29
  %t402 = load i32, ptr %l6, !tbaa !23
  %t405 = call i1 @compiler_2fmir_2eHasCases(ptr %v0, ptr %t401, i32 %t402)
  store i1 %t405, ptr %l152
  br label %bb64
bb64:
  %t406 = load i1, ptr %l152, !tbaa !21
  br i1 %t406, label %bb65, label %bb66
bb65:
  %t407 = load ptr, ptr %l0, !tbaa !29
  %t409 = getelementptr %"compiler/emit:fnEm", ptr %t407, i32 0, i32 0
  %t410 = load ptr, ptr %t409, !tbaa !29
  %t411 = load i32, ptr %l6, !tbaa !23
  %t414 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eenumWords(ptr %v0, ptr %t410, i32 %t411)
  store i1 %t414, ptr %l157
  br label %bb67
bb66:
  store i1 false, ptr %l153, !tbaa !21
  br label %bb68
bb67:
  %t415 = load i1, ptr %l157, !tbaa !21
  store i1 %t415, ptr %l153, !tbaa !21
  br label %bb68
bb68:
  %t416 = load i1, ptr %l153, !tbaa !21
  br i1 %t416, label %bb69, label %bb70
bb69:
  %t417 = load ptr, ptr %l0, !tbaa !29
  %t418 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t419 = load i32, ptr %l6, !tbaa !23
  %t420 = load { i64, ptr }, ptr %l3, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2eholdersCases(ptr %v0, ptr %v1, ptr %v2, ptr %t417, { i64, ptr } %t418, i32 %t419, { i64, ptr } %t420)
  br label %bb71
bb70:
  br label %bb72
bb71:
  br label %bb72
bb72:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3afnEm_2eholdersEach(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, i32 %a2, { i64, ptr } %a3, { i64, ptr } %a4) #0 {
entry:
  %l0 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca { { i64, ptr }, i32 }
  %l16 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l48 = alloca ptr
  %l54 = alloca { i64, ptr }
  %l65 = alloca { { i64, ptr }, i32 }
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2efresh(ptr %v0, ptr %s0, ptr %s0, ptr %t1, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d370, i32 0, i32 1) })
  store { i64, ptr } %t3, ptr %l16
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t4, ptr %l5, !tbaa !27
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2efresh(ptr %v0, ptr %s0, ptr %s0, ptr %t5, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d371, i32 0, i32 1) })
  store { i64, ptr } %t7, ptr %l18
  br label %bb2
bb2:
  %t8 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t8, ptr %l6, !tbaa !27
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2efresh(ptr %v0, ptr %s0, ptr %s0, ptr %t9, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d372, i32 0, i32 1) })
  store { i64, ptr } %t11, ptr %l20
  br label %bb3
bb3:
  %t12 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t12, ptr %l7, !tbaa !27
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2efresh(ptr %v0, ptr %s0, ptr %s0, ptr %t13, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d373, i32 0, i32 1) })
  store { i64, ptr } %t15, ptr %l22
  br label %bb4
bb4:
  %t16 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t16, ptr %l8, !tbaa !27
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2efresh(ptr %v0, ptr %s0, ptr %s0, ptr %t17, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d374, i32 0, i32 1) })
  store { i64, ptr } %t19, ptr %l24
  br label %bb5
bb5:
  %t20 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t20, ptr %l9, !tbaa !27
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t23 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d375, i32 0, i32 1) }, 1
  %t24 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d375, i32 0, i32 1) }, 0
  %t26 = extractvalue { i64, ptr } %t22, 1
  %t27 = extractvalue { i64, ptr } %t22, 0
  %t28 = add i64 %t24, %t27
  %t29 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t28)
  call void @olang_textcopy(ptr %t29, ptr %t23, i64 %t24)
  %t30 = getelementptr i8, ptr %t29, i64 %t24
  call void @olang_textcopy(ptr %t30, ptr %t26, i64 %t27)
  %t31 = insertvalue { i64, ptr } undef, i64 %t28, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t29, 1
  %t34 = extractvalue { i64, ptr } %t32, 0
  %t35 = extractvalue { i64, ptr } %t32, 1
  %t36 = mul i64 %t34, 1
  %t37 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t36)
  call void @llvm.memcpy.p0.p0.i64(ptr %t37, ptr %t35, i64 %t36, i1 false)
  %t38 = insertvalue { i64, ptr } undef, i64 %t34, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t37, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s0, ptr %t21, { i64, ptr } %t39)
  br label %bb6
bb6:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2elabel(ptr %v0, ptr %s0, ptr %t42, { i64, ptr } %t43)
  br label %bb7
bb7:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t48 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d376, i32 0, i32 1) }, 1
  %t49 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d376, i32 0, i32 1) }, 0
  %t51 = extractvalue { i64, ptr } %t47, 1
  %t52 = extractvalue { i64, ptr } %t47, 0
  %t53 = add i64 %t49, %t52
  %t54 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t53)
  call void @olang_textcopy(ptr %t54, ptr %t48, i64 %t49)
  %t55 = getelementptr i8, ptr %t54, i64 %t49
  call void @olang_textcopy(ptr %t55, ptr %t51, i64 %t52)
  %t56 = insertvalue { i64, ptr } undef, i64 %t53, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t54, 1
  %t59 = extractvalue { i64, ptr } %t57, 0
  %t60 = extractvalue { i64, ptr } %t57, 1
  %t61 = mul i64 %t59, 1
  %t62 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t61)
  call void @llvm.memcpy.p0.p0.i64(ptr %t62, ptr %t60, i64 %t61, i1 false)
  %t63 = insertvalue { i64, ptr } undef, i64 %t59, 0
  %t64 = insertvalue { i64, ptr } %t63, ptr %t62, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s0, ptr %t46, { i64, ptr } %t64)
  br label %bb8
bb8:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load { i64, ptr }, ptr %l6, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2elabel(ptr %v0, ptr %s0, ptr %t67, { i64, ptr } %t68)
  br label %bb9
bb9:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2etmp(ptr %v0, ptr %s0, ptr %t71)
  store { i64, ptr } %t73, ptr %l38
  br label %bb10
bb10:
  %t74 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t74, ptr %l10, !tbaa !27
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2etmp(ptr %v0, ptr %s0, ptr %t75)
  store { i64, ptr } %t77, ptr %l40
  br label %bb11
bb11:
  %t78 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t78, ptr %l11, !tbaa !27
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t80 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t81 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t82 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t83 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t85 = extractvalue { i64, ptr } %t80, 1
  %t86 = extractvalue { i64, ptr } %t80, 0
  %t87 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d377, i32 0, i32 1) }, 1
  %t88 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d377, i32 0, i32 1) }, 0
  %t89 = add i64 %t86, %t88
  %t91 = extractvalue { i64, ptr } %t81, 1
  %t92 = extractvalue { i64, ptr } %t81, 0
  %t93 = add i64 %t89, %t92
  %t94 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d378, i32 0, i32 1) }, 1
  %t95 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d378, i32 0, i32 1) }, 0
  %t96 = add i64 %t93, %t95
  %t98 = extractvalue { i64, ptr } %t82, 1
  %t99 = extractvalue { i64, ptr } %t82, 0
  %t100 = add i64 %t96, %t99
  %t101 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d379, i32 0, i32 1) }, 1
  %t102 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d379, i32 0, i32 1) }, 0
  %t103 = add i64 %t100, %t102
  %t105 = extractvalue { i64, ptr } %t83, 1
  %t106 = extractvalue { i64, ptr } %t83, 0
  %t107 = add i64 %t103, %t106
  %t108 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d380, i32 0, i32 1) }, 1
  %t109 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d380, i32 0, i32 1) }, 0
  %t110 = add i64 %t107, %t109
  %t111 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t110)
  call void @olang_textcopy(ptr %t111, ptr %t85, i64 %t86)
  %t112 = getelementptr i8, ptr %t111, i64 %t86
  call void @olang_textcopy(ptr %t112, ptr %t87, i64 %t88)
  %t113 = getelementptr i8, ptr %t112, i64 %t88
  call void @olang_textcopy(ptr %t113, ptr %t91, i64 %t92)
  %t114 = getelementptr i8, ptr %t113, i64 %t92
  call void @olang_textcopy(ptr %t114, ptr %t94, i64 %t95)
  %t115 = getelementptr i8, ptr %t114, i64 %t95
  call void @olang_textcopy(ptr %t115, ptr %t98, i64 %t99)
  %t116 = getelementptr i8, ptr %t115, i64 %t99
  call void @olang_textcopy(ptr %t116, ptr %t101, i64 %t102)
  %t117 = getelementptr i8, ptr %t116, i64 %t102
  call void @olang_textcopy(ptr %t117, ptr %t105, i64 %t106)
  %t118 = getelementptr i8, ptr %t117, i64 %t106
  call void @olang_textcopy(ptr %t118, ptr %t108, i64 %t109)
  %t119 = insertvalue { i64, ptr } undef, i64 %t110, 0
  %t120 = insertvalue { i64, ptr } %t119, ptr %t111, 1
  %t122 = extractvalue { i64, ptr } %t120, 0
  %t123 = extractvalue { i64, ptr } %t120, 1
  %t124 = mul i64 %t122, 1
  %t125 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t124)
  call void @llvm.memcpy.p0.p0.i64(ptr %t125, ptr %t123, i64 %t124, i1 false)
  %t126 = insertvalue { i64, ptr } undef, i64 %t122, 0
  %t127 = insertvalue { i64, ptr } %t126, ptr %t125, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s0, ptr %t79, { i64, ptr } %t127)
  br label %bb12
bb12:
  %t130 = load ptr, ptr %l0, !tbaa !29
  store ptr %t130, ptr %l48, !tbaa !29
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t132 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t134 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d381, i32 0, i32 1) }, 1
  %t135 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d381, i32 0, i32 1) }, 0
  %t137 = extractvalue { i64, ptr } %t132, 1
  %t138 = extractvalue { i64, ptr } %t132, 0
  %t139 = add i64 %t135, %t138
  %t140 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d382, i32 0, i32 1) }, 1
  %t141 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d382, i32 0, i32 1) }, 0
  %t142 = add i64 %t139, %t141
  %t144 = extractvalue { i64, ptr } %a3, 1
  %t145 = extractvalue { i64, ptr } %a3, 0
  %t146 = add i64 %t142, %t145
  %t147 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t146)
  call void @olang_textcopy(ptr %t147, ptr %t134, i64 %t135)
  %t148 = getelementptr i8, ptr %t147, i64 %t135
  call void @olang_textcopy(ptr %t148, ptr %t137, i64 %t138)
  %t149 = getelementptr i8, ptr %t148, i64 %t138
  call void @olang_textcopy(ptr %t149, ptr %t140, i64 %t141)
  %t150 = getelementptr i8, ptr %t149, i64 %t141
  call void @olang_textcopy(ptr %t150, ptr %t144, i64 %t145)
  %t151 = insertvalue { i64, ptr } undef, i64 %t146, 0
  %t152 = insertvalue { i64, ptr } %t151, ptr %t147, 1
  %t154 = extractvalue { i64, ptr } %t152, 0
  %t155 = extractvalue { i64, ptr } %t152, 1
  %t156 = mul i64 %t154, 1
  %t157 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t156)
  call void @llvm.memcpy.p0.p0.i64(ptr %t157, ptr %t155, i64 %t156, i1 false)
  %t158 = insertvalue { i64, ptr } undef, i64 %t154, 0
  %t159 = insertvalue { i64, ptr } %t158, ptr %t157, 1
  %t162 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t131, { i64, ptr } %t159)
  store { i64, ptr } %t162, ptr %l54
  br label %bb13
bb13:
  %t163 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t164 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t165 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d383, i32 0, i32 1) }, 1
  %t166 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d383, i32 0, i32 1) }, 0
  %t167 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t168 = extractvalue { i64, ptr } %t167, 1
  %t169 = extractvalue { i64, ptr } %t167, 0
  %t170 = add i64 %t166, %t169
  %t171 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d384, i32 0, i32 1) }, 1
  %t172 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d384, i32 0, i32 1) }, 0
  %t173 = add i64 %t170, %t172
  %t175 = extractvalue { i64, ptr } %t163, 1
  %t176 = extractvalue { i64, ptr } %t163, 0
  %t177 = add i64 %t173, %t176
  %t178 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d384, i32 0, i32 1) }, 1
  %t179 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d384, i32 0, i32 1) }, 0
  %t180 = add i64 %t177, %t179
  %t182 = extractvalue { i64, ptr } %t164, 1
  %t183 = extractvalue { i64, ptr } %t164, 0
  %t184 = add i64 %t180, %t183
  %t185 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t184)
  call void @olang_textcopy(ptr %t185, ptr %t165, i64 %t166)
  %t186 = getelementptr i8, ptr %t185, i64 %t166
  call void @olang_textcopy(ptr %t186, ptr %t168, i64 %t169)
  %t187 = getelementptr i8, ptr %t186, i64 %t169
  call void @olang_textcopy(ptr %t187, ptr %t171, i64 %t172)
  %t188 = getelementptr i8, ptr %t187, i64 %t172
  call void @olang_textcopy(ptr %t188, ptr %t175, i64 %t176)
  %t189 = getelementptr i8, ptr %t188, i64 %t176
  call void @olang_textcopy(ptr %t189, ptr %t178, i64 %t179)
  %t190 = getelementptr i8, ptr %t189, i64 %t179
  call void @olang_textcopy(ptr %t190, ptr %t182, i64 %t183)
  %t191 = insertvalue { i64, ptr } undef, i64 %t184, 0
  %t192 = insertvalue { i64, ptr } %t191, ptr %t185, 1
  %t194 = extractvalue { i64, ptr } %t192, 0
  %t195 = extractvalue { i64, ptr } %t192, 1
  %t196 = mul i64 %t194, 1
  %t197 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t196)
  call void @llvm.memcpy.p0.p0.i64(ptr %t197, ptr %t195, i64 %t196, i1 false)
  %t198 = insertvalue { i64, ptr } undef, i64 %t194, 0
  %t199 = insertvalue { i64, ptr } %t198, ptr %t197, 1
  %t200 = load ptr, ptr %l48, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s0, ptr %t200, { i64, ptr } %t199)
  br label %bb14
bb14:
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t203 = load { i64, ptr }, ptr %l7, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2elabel(ptr %v0, ptr %s0, ptr %t202, { i64, ptr } %t203)
  br label %bb15
bb15:
  %t206 = load ptr, ptr %l0, !tbaa !29
  %t209 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t214 = call { { i64, ptr }, i32 } @compiler_2femit_2ecompiler_2femit_3afnEm_2eelemAt(ptr %v0, ptr %v1, ptr %s0, ptr %s0, ptr %s0, ptr %t206, { i64, ptr } %a1, i32 %a2, { i64, ptr } %t209, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d385, i32 0, i32 1) })
  store { { i64, ptr }, i32 } %t214, ptr %l65
  br label %bb16
bb16:
  %t215 = load { { i64, ptr }, i32 }, ptr %l65
  store { { i64, ptr }, i32 } %t215, ptr %l12
  %t216 = getelementptr { { i64, ptr }, i32 }, ptr %l12, i32 0, i32 0
  %t217 = load { i64, ptr }, ptr %t216, !tbaa !27
  %t219 = getelementptr { { i64, ptr }, i32 }, ptr %l12, i32 0, i32 1
  %t220 = load i32, ptr %t219, !tbaa !23
  %t222 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2eholdersAt(ptr %v0, ptr %s0, ptr %v3, ptr %t222, { i64, ptr } %t217, i32 %t220, { i64, ptr } %a4, i1 false)
  br label %bb17
bb17:
  %t230 = load ptr, ptr %l0, !tbaa !29
  %t231 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t232 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d386, i32 0, i32 1) }, 1
  %t233 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d386, i32 0, i32 1) }, 0
  %t235 = extractvalue { i64, ptr } %t231, 1
  %t236 = extractvalue { i64, ptr } %t231, 0
  %t237 = add i64 %t233, %t236
  %t238 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t237)
  call void @olang_textcopy(ptr %t238, ptr %t232, i64 %t233)
  %t239 = getelementptr i8, ptr %t238, i64 %t233
  call void @olang_textcopy(ptr %t239, ptr %t235, i64 %t236)
  %t240 = insertvalue { i64, ptr } undef, i64 %t237, 0
  %t241 = insertvalue { i64, ptr } %t240, ptr %t238, 1
  %t243 = extractvalue { i64, ptr } %t241, 0
  %t244 = extractvalue { i64, ptr } %t241, 1
  %t245 = mul i64 %t243, 1
  %t246 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t245)
  call void @llvm.memcpy.p0.p0.i64(ptr %t246, ptr %t244, i64 %t245, i1 false)
  %t247 = insertvalue { i64, ptr } undef, i64 %t243, 0
  %t248 = insertvalue { i64, ptr } %t247, ptr %t246, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s0, ptr %t230, { i64, ptr } %t248)
  br label %bb18
bb18:
  %t251 = load ptr, ptr %l0, !tbaa !29
  %t252 = load { i64, ptr }, ptr %l8, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2elabel(ptr %v0, ptr %s0, ptr %t251, { i64, ptr } %t252)
  br label %bb19
bb19:
  %t255 = load ptr, ptr %l0, !tbaa !29
  %t256 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t257 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t259 = extractvalue { i64, ptr } %t256, 1
  %t260 = extractvalue { i64, ptr } %t256, 0
  %t261 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d387, i32 0, i32 1) }, 1
  %t262 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d387, i32 0, i32 1) }, 0
  %t263 = add i64 %t260, %t262
  %t265 = extractvalue { i64, ptr } %t257, 1
  %t266 = extractvalue { i64, ptr } %t257, 0
  %t267 = add i64 %t263, %t266
  %t268 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d388, i32 0, i32 1) }, 1
  %t269 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d388, i32 0, i32 1) }, 0
  %t270 = add i64 %t267, %t269
  %t271 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t270)
  call void @olang_textcopy(ptr %t271, ptr %t259, i64 %t260)
  %t272 = getelementptr i8, ptr %t271, i64 %t260
  call void @olang_textcopy(ptr %t272, ptr %t261, i64 %t262)
  %t273 = getelementptr i8, ptr %t272, i64 %t262
  call void @olang_textcopy(ptr %t273, ptr %t265, i64 %t266)
  %t274 = getelementptr i8, ptr %t273, i64 %t266
  call void @olang_textcopy(ptr %t274, ptr %t268, i64 %t269)
  %t275 = insertvalue { i64, ptr } undef, i64 %t270, 0
  %t276 = insertvalue { i64, ptr } %t275, ptr %t271, 1
  %t278 = extractvalue { i64, ptr } %t276, 0
  %t279 = extractvalue { i64, ptr } %t276, 1
  %t280 = mul i64 %t278, 1
  %t281 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t280)
  call void @llvm.memcpy.p0.p0.i64(ptr %t281, ptr %t279, i64 %t280, i1 false)
  %t282 = insertvalue { i64, ptr } undef, i64 %t278, 0
  %t283 = insertvalue { i64, ptr } %t282, ptr %t281, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s0, ptr %t255, { i64, ptr } %t283)
  br label %bb20
bb20:
  %t286 = load ptr, ptr %l0, !tbaa !29
  %t287 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t288 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d389, i32 0, i32 1) }, 1
  %t289 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d389, i32 0, i32 1) }, 0
  %t291 = extractvalue { i64, ptr } %t287, 1
  %t292 = extractvalue { i64, ptr } %t287, 0
  %t293 = add i64 %t289, %t292
  %t294 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t293)
  call void @olang_textcopy(ptr %t294, ptr %t288, i64 %t289)
  %t295 = getelementptr i8, ptr %t294, i64 %t289
  call void @olang_textcopy(ptr %t295, ptr %t291, i64 %t292)
  %t296 = insertvalue { i64, ptr } undef, i64 %t293, 0
  %t297 = insertvalue { i64, ptr } %t296, ptr %t294, 1
  %t299 = extractvalue { i64, ptr } %t297, 0
  %t300 = extractvalue { i64, ptr } %t297, 1
  %t301 = mul i64 %t299, 1
  %t302 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t301)
  call void @llvm.memcpy.p0.p0.i64(ptr %t302, ptr %t300, i64 %t301, i1 false)
  %t303 = insertvalue { i64, ptr } undef, i64 %t299, 0
  %t304 = insertvalue { i64, ptr } %t303, ptr %t302, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s0, ptr %t286, { i64, ptr } %t304)
  br label %bb21
bb21:
  %t307 = load ptr, ptr %l0, !tbaa !29
  %t308 = load { i64, ptr }, ptr %l9, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2elabel(ptr %v0, ptr %s0, ptr %t307, { i64, ptr } %t308)
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elocalAt(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l8 = alloca %"compiler/mir:Local"
  %l10 = alloca i1
  %l17 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"compiler/emit:fnEm", ptr %t2, i32 0, i32 1
  %t5 = load ptr, ptr %t4, !tbaa !29
  %t7 = getelementptr %"compiler/mir:Fn", ptr %t5, i32 0, i32 7
  %t8 = load i32, ptr %l1, !tbaa !23
  %t10 = sext i32 %t8 to i64
  %t13 = call %"compiler/mir:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %t7, i64 %t10)
  store %"compiler/mir:Local" %t13, ptr %l8
  br label %bb1
bb1:
  %t14 = getelementptr %"compiler/mir:Local", ptr %l8, i32 0, i32 4
  %t15 = load { i64, [1 x i64] }, ptr %t14
  %t16 = load ptr, ptr %l2, !tbaa !29
  %t18 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2eisFrame(ptr %v0, ptr %t16, { i64, [1 x i64] } %t15)
  store i1 %t18, ptr %l10
  br label %bb2
bb2:
  %t19 = load i1, ptr %l10, !tbaa !21
  br i1 %t19, label %bb3, label %bb4
bb3:
  %t20 = load i32, ptr %l1, !tbaa !23
  %t21 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d390, i32 0, i32 1) }, 1
  %t22 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d390, i32 0, i32 1) }, 0
  %t24 = sext i32 %t20 to i64
  %t25 = call i64 @__olang_fmt_i64(ptr null, i64 %t24)
  %t26 = add i64 %t22, %t25
  %t27 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t26)
  call void @olang_textcopy(ptr %t27, ptr %t21, i64 %t22)
  %t28 = getelementptr i8, ptr %t27, i64 %t22
  %t29 = call i64 @__olang_fmt_i64(ptr %t28, i64 %t24)
  %t30 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t27, 1
  store { i64, ptr } %t31, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load i32, ptr %l1, !tbaa !23
  %t35 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d391, i32 0, i32 1) }, 1
  %t36 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d391, i32 0, i32 1) }, 0
  %t38 = sext i32 %t34 to i64
  %t39 = call i64 @__olang_fmt_i64(ptr null, i64 %t38)
  %t40 = add i64 %t36, %t39
  %t41 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t40)
  call void @olang_textcopy(ptr %t41, ptr %t35, i64 %t36)
  %t42 = getelementptr i8, ptr %t41, i64 %t36
  %t43 = call i64 @__olang_fmt_i64(ptr %t42, i64 %t38)
  %t44 = insertvalue { i64, ptr } undef, i64 %t40, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t41, 1
  %t47 = extractvalue { i64, ptr } %t45, 0
  %t48 = extractvalue { i64, ptr } %t45, 1
  %t49 = mul i64 %t47, 1
  %t50 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t49)
  call void @llvm.memcpy.p0.p0.i64(ptr %t50, ptr %t48, i64 %t49, i1 false)
  %t51 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t52 = insertvalue { i64, ptr } %t51, ptr %t50, 1
  %t55 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %t33, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d392, i32 0, i32 1) }, { i64, ptr } %t52, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d223, i32 0, i32 1) })
  store { i64, ptr } %t55, ptr %l17
  br label %bb6
bb6:
  %t56 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t56, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elocated(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l30 = alloca { i64, ptr }
  %l31 = alloca i32
  %l33 = alloca i1
  %l40 = alloca { i64, ptr }
  %l45 = alloca ptr
  %l51 = alloca i64
  %l52 = alloca i64
  %l53 = alloca i64
  %l54 = alloca i32
  %l55 = alloca { i64, ptr }
  %l57 = alloca i64
  %l58 = alloca i64
  %l59 = alloca i64
  %l60 = alloca i32
  %l61 = alloca { i64, ptr }
  %l66 = alloca i1
  %l68 = alloca { i64, ptr }
  %l71 = alloca i64
  %l73 = alloca { i64, ptr }
  %l83 = alloca ptr
  %l84 = alloca i64
  %l88 = alloca { i64, ptr }
  %l89 = alloca i64
  %s0 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load ptr, ptr %l3, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/emit:fnEm", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/mir:Fn", ptr %t10, i32 0, i32 2
  %t13 = load i64, ptr %t12, !tbaa !24
  %t18 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ewhere(ptr %v0, ptr %s0, ptr %t6, i64 %t13, %"compiler/source:Span" %a1)
  store { i64, ptr } %t18, ptr %l17
  br label %bb1
bb1:
  %t19 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t20 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t20, 1
  %t22 = extractvalue { i64, ptr } %t20, 0
  %t24 = extractvalue { i64, ptr } %t19, 1
  %t25 = extractvalue { i64, ptr } %t19, 0
  %t26 = add i64 %t22, %t25
  %t27 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t26)
  call void @olang_textcopy(ptr %t27, ptr %t21, i64 %t22)
  %t28 = getelementptr i8, ptr %t27, i64 %t22
  call void @olang_textcopy(ptr %t28, ptr %t24, i64 %t25)
  %t29 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t30 = insertvalue { i64, ptr } %t29, ptr %t27, 1
  store { i64, ptr } %t30, ptr %l4, !tbaa !27
  %t32 = load ptr, ptr %l3, !tbaa !29
  %t34 = getelementptr %"compiler/emit:Emitter", ptr %t32, i32 0, i32 84
  %t35 = load i1, ptr %t34, !tbaa !21
  %t37 = xor i1 %t35, true
  br i1 %t37, label %bb2, label %bb3
bb2:
  %t39 = load ptr, ptr %l3, !tbaa !29
  %t40 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t43 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecstr(ptr %v0, ptr %s0, ptr %v2, ptr %t39, { i64, ptr } %t40)
  store { i64, ptr } %t43, ptr %l25
  br label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_scope_close(ptr %s0)
  %t44 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t44, ptr %rv
  br label %ret
bb5:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/emit:fnEm", ptr %t45, i32 0, i32 17
  %t48 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t51 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha4444909f5ef14f7626d25b8f59e6ba2(ptr %v0, ptr %s0, ptr %v0, ptr %t47, { i64, ptr } %t48)
  %t52 = extractvalue { i32, { i64, ptr } } %t51, 1
  %t53 = extractvalue { i32, { i64, ptr } } %t51, 0
  store i32 %t53, ptr %l31
  %t54 = icmp ne i32 %t53, 0
  br i1 %t54, label %bb7, label %ok.55, !prof !99
ok.55:
  store { i64, ptr } %t52, ptr %l30
  br label %bb6
bb6:
  %t56 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t56, ptr %l26, !tbaa !27
  br label %bb9
bb7:
  br label %bb8
bb8:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d393, i32 0, i32 1) }, ptr %l26, !tbaa !27
  br label %bb9
bb9:
  %t57 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t57, ptr %l5, !tbaa !27
  %t58 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t60 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t58, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d394, i32 0, i32 1) })
  store i1 %t60, ptr %l33
  br label %bb10
bb10:
  %t61 = load i1, ptr %l33, !tbaa !21
  %t62 = xor i1 %t61, true
  br i1 %t62, label %bb11, label %bb12
bb11:
  %t64 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t66 = extractvalue { i64, ptr } %t64, 1
  %t67 = extractvalue { i64, ptr } %t64, 0
  %t68 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t67)
  call void @olang_textcopy(ptr %t68, ptr %t66, i64 %t67)
  %t69 = insertvalue { i64, ptr } undef, i64 %t67, 0
  %t70 = insertvalue { i64, ptr } %t69, ptr %t68, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t70, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t72 = load ptr, ptr %l3, !tbaa !29
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/emit:fnEm", ptr %t73, i32 0, i32 2
  %t76 = load { i64, [2 x i64] }, ptr %t75
  %t79 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2elocBase(ptr %v0, ptr %s0, ptr %t72, { i64, [2 x i64] } %t76)
  store { i64, ptr } %t79, ptr %l40
  br label %bb14
bb14:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/emit:fnEm", ptr %t80, i32 0, i32 16
  %t83 = load i64, ptr %t82, !tbaa !24
  %t84 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t85 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t85, 1
  %t87 = extractvalue { i64, ptr } %t85, 0
  %t88 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d395, i32 0, i32 1) }, 1
  %t89 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d395, i32 0, i32 1) }, 0
  %t90 = add i64 %t87, %t89
  %t92 = call i64 @__olang_fmt_i64(ptr null, i64 %t83)
  %t93 = add i64 %t90, %t92
  %t94 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d395, i32 0, i32 1) }, 1
  %t95 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d395, i32 0, i32 1) }, 0
  %t96 = add i64 %t93, %t95
  %t98 = extractvalue { i64, ptr } %t84, 1
  %t99 = extractvalue { i64, ptr } %t84, 0
  %t100 = add i64 %t96, %t99
  %t101 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t100)
  call void @olang_textcopy(ptr %t101, ptr %t86, i64 %t87)
  %t102 = getelementptr i8, ptr %t101, i64 %t87
  call void @olang_textcopy(ptr %t102, ptr %t88, i64 %t89)
  %t103 = getelementptr i8, ptr %t102, i64 %t89
  %t104 = call i64 @__olang_fmt_i64(ptr %t103, i64 %t83)
  %t105 = getelementptr i8, ptr %t103, i64 %t92
  call void @olang_textcopy(ptr %t105, ptr %t94, i64 %t95)
  %t106 = getelementptr i8, ptr %t105, i64 %t95
  call void @olang_textcopy(ptr %t106, ptr %t98, i64 %t99)
  %t107 = insertvalue { i64, ptr } undef, i64 %t100, 0
  %t108 = insertvalue { i64, ptr } %t107, ptr %t101, 1
  store { i64, ptr } %t108, ptr %l6, !tbaa !27
  %t110 = load ptr, ptr %l0, !tbaa !29
  store ptr %t110, ptr %l45, !tbaa !29
  %t111 = load ptr, ptr %l45, !tbaa !29
  %t112 = getelementptr %"compiler/emit:fnEm", ptr %t111, i32 0, i32 16
  %t113 = load i64, ptr %t112, !tbaa !24
  %t115 = add i64 %t113, 1
  %t117 = load ptr, ptr %l45, !tbaa !29
  %t118 = getelementptr %"compiler/emit:fnEm", ptr %t117, i32 0, i32 16
  store i64 %t115, ptr %t118, !tbaa !24
  %t119 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t120 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d396, i32 0, i32 1) }, 1
  %t121 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d396, i32 0, i32 1) }, 0
  %t123 = extractvalue { i64, ptr } %t119, 1
  %t124 = extractvalue { i64, ptr } %t119, 0
  %t125 = add i64 %t121, %t124
  %t126 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t125)
  call void @olang_textcopy(ptr %t126, ptr %t120, i64 %t121)
  %t127 = getelementptr i8, ptr %t126, i64 %t121
  call void @olang_textcopy(ptr %t127, ptr %t123, i64 %t124)
  %t128 = insertvalue { i64, ptr } undef, i64 %t125, 0
  %t129 = insertvalue { i64, ptr } %t128, ptr %t126, 1
  store { i64, ptr } %t129, ptr %l7, !tbaa !27
  %t131 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t133 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eHash(ptr %s0, { i64, ptr } %t131)
  store i64 %t133, ptr %l51
  br label %bb15
bb15:
  %t134 = load i64, ptr %l51, !tbaa !24
  store i64 %t134, ptr %l52, !tbaa !65
  %t135 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s0, i64 16)
  %t136 = extractvalue { i32, i64 } %t135, 1
  %t137 = extractvalue { i32, i64 } %t135, 0
  store i32 %t137, ptr %l54
  %t138 = icmp ne i32 %t137, 0
  br i1 %t138, label %bb17, label %ok.139, !prof !99
ok.139:
  store i64 %t136, ptr %l53
  br label %bb16
bb16:
  %t140 = load i64, ptr %l52, !tbaa !65
  %t141 = load i64, ptr %l53, !tbaa !24
  %t142 = call { i64, ptr } @std_2fprelude_2ftext_2eU64_2eFormat(ptr %s0, i64 %t140, i64 %t141)
  store { i64, ptr } %t142, ptr %l55
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_6a1c0f36bb2af484_15693b919ea68168)
  unreachable
bb18:
  %t143 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t145 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eHash(ptr %s0, { i64, ptr } %t143)
  store i64 %t145, ptr %l57
  br label %bb19
bb19:
  %t146 = load i64, ptr %l57, !tbaa !24
  store i64 %t146, ptr %l58, !tbaa !65
  %t147 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s0, i64 16)
  %t148 = extractvalue { i32, i64 } %t147, 1
  %t149 = extractvalue { i32, i64 } %t147, 0
  store i32 %t149, ptr %l60
  %t150 = icmp ne i32 %t149, 0
  br i1 %t150, label %bb21, label %ok.151, !prof !99
ok.151:
  store i64 %t148, ptr %l59
  br label %bb20
bb20:
  %t152 = load i64, ptr %l58, !tbaa !65
  %t153 = load i64, ptr %l59, !tbaa !24
  %t154 = call { i64, ptr } @std_2fprelude_2ftext_2eU64_2eFormat(ptr %s0, i64 %t152, i64 %t153)
  store { i64, ptr } %t154, ptr %l61
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_6a1c0f36bb2af484_15693b919ea68168)
  unreachable
bb22:
  %t155 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d397, i32 0, i32 1) }, 1
  %t156 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d397, i32 0, i32 1) }, 0
  %t157 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t158 = extractvalue { i64, ptr } %t157, 1
  %t159 = extractvalue { i64, ptr } %t157, 0
  %t160 = add i64 %t156, %t159
  %t161 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d398, i32 0, i32 1) }, 1
  %t162 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d398, i32 0, i32 1) }, 0
  %t163 = add i64 %t160, %t162
  %t164 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t165 = extractvalue { i64, ptr } %t164, 1
  %t166 = extractvalue { i64, ptr } %t164, 0
  %t167 = add i64 %t163, %t166
  %t168 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t167)
  call void @olang_textcopy(ptr %t168, ptr %t155, i64 %t156)
  %t169 = getelementptr i8, ptr %t168, i64 %t156
  call void @olang_textcopy(ptr %t169, ptr %t158, i64 %t159)
  %t170 = getelementptr i8, ptr %t169, i64 %t159
  call void @olang_textcopy(ptr %t170, ptr %t161, i64 %t162)
  %t171 = getelementptr i8, ptr %t170, i64 %t162
  call void @olang_textcopy(ptr %t171, ptr %t165, i64 %t166)
  %t172 = insertvalue { i64, ptr } undef, i64 %t167, 0
  %t173 = insertvalue { i64, ptr } %t172, ptr %t168, 1
  store { i64, ptr } %t173, ptr %l8, !tbaa !27
  %t175 = load ptr, ptr %l3, !tbaa !29
  %t177 = getelementptr %"compiler/emit:Emitter", ptr %t175, i32 0, i32 22
  %t178 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t181 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9b83f66eba65594537030636cb0b52b7(ptr %v0, ptr %s0, ptr %t177, { i64, ptr } %t178)
  store i1 %t181, ptr %l66
  br label %bb23
bb23:
  %t182 = load i1, ptr %l66, !tbaa !21
  %t183 = xor i1 %t182, true
  br i1 %t183, label %bb24, label %bb25
bb24:
  store %olang.scope zeroinitializer, ptr %s8
  %t185 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t185, ptr %l68, !tbaa !27
  %t186 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t188 = extractvalue { i64, ptr } %t186, 0
  %t190 = add i64 %t188, 1
  store i64 %t190, ptr %l71, !tbaa !24
  %t191 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t193 = call { i64, ptr } @compiler_2femit_2eescape(ptr %s0, ptr %s8, { i64, ptr } %t191)
  store { i64, ptr } %t193, ptr %l73
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t194 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d399, i32 0, i32 1) }, 1
  %t195 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d399, i32 0, i32 1) }, 0
  %t196 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t197 = extractvalue { i64, ptr } %t196, 1
  %t198 = extractvalue { i64, ptr } %t196, 0
  %t199 = add i64 %t195, %t198
  %t200 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d400, i32 0, i32 1) }, 1
  %t201 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d400, i32 0, i32 1) }, 0
  %t202 = add i64 %t199, %t201
  %t203 = load i64, ptr %l71, !tbaa !24
  %t204 = call i64 @__olang_fmt_i64(ptr null, i64 %t203)
  %t205 = add i64 %t202, %t204
  %t206 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d401, i32 0, i32 1) }, 1
  %t207 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d401, i32 0, i32 1) }, 0
  %t208 = add i64 %t205, %t207
  %t209 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t210 = extractvalue { i64, ptr } %t209, 1
  %t211 = extractvalue { i64, ptr } %t209, 0
  %t212 = add i64 %t208, %t211
  %t213 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d402, i32 0, i32 1) }, 1
  %t214 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d402, i32 0, i32 1) }, 0
  %t215 = add i64 %t212, %t214
  %t216 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t215)
  call void @olang_textcopy(ptr %t216, ptr %t194, i64 %t195)
  %t217 = getelementptr i8, ptr %t216, i64 %t195
  call void @olang_textcopy(ptr %t217, ptr %t197, i64 %t198)
  %t218 = getelementptr i8, ptr %t217, i64 %t198
  call void @olang_textcopy(ptr %t218, ptr %t200, i64 %t201)
  %t219 = getelementptr i8, ptr %t218, i64 %t201
  %t220 = call i64 @__olang_fmt_i64(ptr %t219, i64 %t203)
  %t221 = getelementptr i8, ptr %t219, i64 %t204
  call void @olang_textcopy(ptr %t221, ptr %t206, i64 %t207)
  %t222 = getelementptr i8, ptr %t221, i64 %t207
  call void @olang_textcopy(ptr %t222, ptr %t210, i64 %t211)
  %t223 = getelementptr i8, ptr %t222, i64 %t211
  call void @olang_textcopy(ptr %t223, ptr %t213, i64 %t214)
  %t224 = insertvalue { i64, ptr } undef, i64 %t215, 0
  %t225 = insertvalue { i64, ptr } %t224, ptr %t216, 1
  %t227 = load ptr, ptr %l3, !tbaa !29
  %t228 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t229 = load i64, ptr @G_2ecompiler_2femit_2eHomeLoc, !tbaa !24
  %t231 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t232 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d403, i32 0, i32 1) }, 1
  %t233 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d403, i32 0, i32 1) }, 0
  %t235 = extractvalue { i64, ptr } %t231, 1
  %t236 = extractvalue { i64, ptr } %t231, 0
  %t237 = add i64 %t233, %t236
  %t238 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d404, i32 0, i32 1) }, 1
  %t239 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d404, i32 0, i32 1) }, 0
  %t240 = add i64 %t237, %t239
  %t241 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t240)
  call void @olang_textcopy(ptr %t241, ptr %t232, i64 %t233)
  %t242 = getelementptr i8, ptr %t241, i64 %t233
  call void @olang_textcopy(ptr %t242, ptr %t235, i64 %t236)
  %t243 = getelementptr i8, ptr %t242, i64 %t236
  call void @olang_textcopy(ptr %t243, ptr %t238, i64 %t239)
  %t244 = insertvalue { i64, ptr } undef, i64 %t240, 0
  %t245 = insertvalue { i64, ptr } %t244, ptr %t241, 1
  %t247 = extractvalue { i64, ptr } %t245, 0
  %t248 = extractvalue { i64, ptr } %t245, 1
  %t249 = mul i64 %t247, 1
  %t250 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t249)
  call void @llvm.memcpy.p0.p0.i64(ptr %t250, ptr %t248, i64 %t249, i1 false)
  %t251 = insertvalue { i64, ptr } undef, i64 %t247, 0
  %t252 = insertvalue { i64, ptr } %t251, ptr %t250, 1
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eitem(ptr %v0, ptr %s0, ptr %s8, ptr %s8, ptr %t227, { i64, ptr } %t228, i64 %t229, { i64, ptr } %t225, { i64, ptr } %t252)
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s8)
  br label %bb28
bb28:
  %t258 = load ptr, ptr %l0, !tbaa !29
  %t260 = getelementptr %"compiler/emit:fnEm", ptr %t258, i32 0, i32 17
  store ptr %t260, ptr %l83, !tbaa !29
  %t261 = ptrtoint ptr %v0 to i64
  store i64 %t261, ptr %l84, !tbaa !24
  %t262 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMapEntry_3cstd_2fprelude_2ftext_3aString_26_2c_20st_Ha3f33385783b00c3f13cf90b683d8670
  br i1 %t262, label %bb29, label %bb30
bb29:
  %t264 = call ptr @__olang_region_make(ptr %v0)
  %t265 = ptrtoint ptr %t264 to i64
  store i64 %t265, ptr %l84, !tbaa !24
  br label %bb30
bb30:
  %t266 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t268 = extractvalue { i64, ptr } %t266, 1
  %t269 = extractvalue { i64, ptr } %t266, 0
  %t270 = load i64, ptr %l84
  %t271 = inttoptr i64 %t270 to ptr
  %t272 = call ptr @__olang_scope_alloc(ptr %t271, i64 %t269)
  call void @olang_textcopy(ptr %t272, ptr %t268, i64 %t269)
  %t273 = insertvalue { i64, ptr } undef, i64 %t269, 0
  %t274 = insertvalue { i64, ptr } %t273, ptr %t272, 1
  %t276 = load i64, ptr %l84
  %t277 = inttoptr i64 %t276 to ptr
  %t278 = extractvalue { i64, ptr } %t274, 0
  %t279 = extractvalue { i64, ptr } %t274, 1
  %t280 = mul i64 %t278, 1
  %t281 = call ptr @__olang_scope_alloc(ptr %t277, i64 %t280)
  call void @llvm.memcpy.p0.p0.i64(ptr %t281, ptr %t279, i64 %t280, i1 false)
  %t282 = insertvalue { i64, ptr } undef, i64 %t278, 0
  %t283 = insertvalue { i64, ptr } %t282, ptr %t281, 1
  store { i64, ptr } %t283, ptr %l88, !tbaa !27
  %t284 = ptrtoint ptr %v0 to i64
  store i64 %t284, ptr %l89, !tbaa !24
  %t285 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMapEntry_3cstd_2fprelude_2ftext_3aString_26_2c_20st_Ha3f33285783aff10f13cf80b683d8c03
  br i1 %t285, label %bb31, label %bb32
bb31:
  %t287 = call ptr @__olang_region_make(ptr %v0)
  %t288 = ptrtoint ptr %t287 to i64
  store i64 %t288, ptr %l89, !tbaa !24
  br label %bb32
bb32:
  %t289 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t290 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d405, i32 0, i32 1) }, 1
  %t291 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d405, i32 0, i32 1) }, 0
  %t293 = extractvalue { i64, ptr } %t289, 1
  %t294 = extractvalue { i64, ptr } %t289, 0
  %t295 = add i64 %t291, %t294
  %t296 = load i64, ptr %l89
  %t297 = inttoptr i64 %t296 to ptr
  %t298 = call ptr @__olang_scope_alloc(ptr %t297, i64 %t295)
  call void @olang_textcopy(ptr %t298, ptr %t290, i64 %t291)
  %t299 = getelementptr i8, ptr %t298, i64 %t291
  call void @olang_textcopy(ptr %t299, ptr %t293, i64 %t294)
  %t300 = insertvalue { i64, ptr } undef, i64 %t295, 0
  %t301 = insertvalue { i64, ptr } %t300, ptr %t298, 1
  %t303 = load i64, ptr %l89
  %t304 = inttoptr i64 %t303 to ptr
  %t305 = extractvalue { i64, ptr } %t301, 0
  %t306 = extractvalue { i64, ptr } %t301, 1
  %t307 = mul i64 %t305, 1
  %t308 = call ptr @__olang_scope_alloc(ptr %t304, i64 %t307)
  call void @llvm.memcpy.p0.p0.i64(ptr %t308, ptr %t306, i64 %t307, i1 false)
  %t309 = insertvalue { i64, ptr } undef, i64 %t305, 0
  %t310 = insertvalue { i64, ptr } %t309, ptr %t308, 1
  %t311 = load ptr, ptr %l83, !tbaa !29
  %t312 = load { i64, ptr }, ptr %l88, !tbaa !27
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6f7a2f8d839c49b6e7a19c287d4b190c(ptr %v0, ptr %v0, ptr %v0, ptr %t311, { i64, ptr } %t312, { i64, ptr } %t310)
  br label %bb33
bb33:
  %t314 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t315 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d406, i32 0, i32 1) }, 1
  %t316 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d406, i32 0, i32 1) }, 0
  %t318 = extractvalue { i64, ptr } %t314, 1
  %t319 = extractvalue { i64, ptr } %t314, 0
  %t320 = add i64 %t316, %t319
  %t321 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t320)
  call void @olang_textcopy(ptr %t321, ptr %t315, i64 %t316)
  %t322 = getelementptr i8, ptr %t321, i64 %t316
  call void @olang_textcopy(ptr %t322, ptr %t318, i64 %t319)
  %t323 = insertvalue { i64, ptr } undef, i64 %t320, 0
  %t324 = insertvalue { i64, ptr } %t323, ptr %t321, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t324, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2enewOnce(ptr %v0, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca i64
  %l6 = alloca i1
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca %"compiler/mir:BasicBlock"
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca { i64, [21 x i64] }
  %l13 = alloca ptr
  %l14 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca i64
  %l19 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l20 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l24 = alloca i64
  %l26 = alloca i64
  %l31 = alloca %"compiler/mir:BasicBlock"
  %l33 = alloca %"compiler/mir:BasicBlock"
  %l35 = alloca i64
  %l37 = alloca i64
  %l42 = alloca { i64, [21 x i64] }
  %l51 = alloca i64
  %l53 = alloca i64
  %l58 = alloca i32
  %l71 = alloca i1
  %l82 = alloca i64
  %l84 = alloca i64
  %l89 = alloca i32
  %l101 = alloca i1
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l19
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l19
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l3
  %t3 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %l20
  br label %bb2
bb2:
  %t4 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l20
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %l4
  store i64 0, ptr %l5, !tbaa !24
  store i1 false, ptr %l6, !tbaa !21
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/emit:fnEm", ptr %t5, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = getelementptr %"compiler/mir:Fn", ptr %t8, i32 0, i32 9
  store ptr %t10, ptr %l7, !tbaa !29
  store i64 0, ptr %l8, !tbaa !24
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t12 = load i64, ptr %l8, !tbaa !24
  store i64 %t12, ptr %l24, !tbaa !24
  %t13 = load ptr, ptr %l7, !tbaa !29
  %t15 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eLen_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, ptr %t13)
  store i64 %t15, ptr %l26
  br label %bb4
bb4:
  %t16 = load i64, ptr %l24, !tbaa !24
  %t17 = load i64, ptr %l26, !tbaa !24
  %t18 = icmp slt i64 %t16, %t17
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s2)
  br label %bb51
bb6:
  br label %bb7
bb7:
  %t22 = load ptr, ptr %l7, !tbaa !29
  %t23 = load i64, ptr %l8, !tbaa !24
  %t26 = call %"compiler/mir:BasicBlock" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eAt_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, ptr %v0, ptr %t22, i64 %t23)
  store %"compiler/mir:BasicBlock" %t26, ptr %l31
  br label %bb8
bb8:
  %t28 = call %"compiler/mir:BasicBlock" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fmir_3aBasicBlock(ptr %s2, ptr %l31)
  store %"compiler/mir:BasicBlock" %t28, ptr %l33
  br label %bb9
bb9:
  %t29 = load %"compiler/mir:BasicBlock", ptr %l33
  store %"compiler/mir:BasicBlock" %t29, ptr %l9
  %t30 = getelementptr %"compiler/mir:BasicBlock", ptr %l9, i32 0, i32 0
  store ptr %t30, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s4
  %t32 = load i64, ptr %l11, !tbaa !24
  store i64 %t32, ptr %l35, !tbaa !24
  %t33 = load ptr, ptr %l10, !tbaa !29
  %t35 = call i64 @compiler_2fmir_2ecompiler_2fmir_3aStmtList_2eLen(ptr %s2, ptr %t33)
  store i64 %t35, ptr %l37
  br label %bb11
bb11:
  %t36 = load i64, ptr %l35, !tbaa !24
  %t37 = load i64, ptr %l37, !tbaa !24
  %t38 = icmp slt i64 %t36, %t37
  %t40 = xor i1 %t38, true
  br i1 %t40, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s4)
  br label %bb35
bb13:
  br label %bb14
bb14:
  %t42 = load ptr, ptr %l10, !tbaa !29
  %t43 = load i64, ptr %l11, !tbaa !24
  %t46 = call { i64, [21 x i64] } @compiler_2fmir_2ecompiler_2fmir_3aStmtList_2eAt(ptr %s2, ptr %t42, i64 %t43)
  store { i64, [21 x i64] } %t46, ptr %l42
  br label %bb15
bb15:
  call void @llvm.memmove.p0.p0.i64(ptr %l12, ptr %l42, i64 176, i1 false)
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eClear_3ccompiler_2fmir_3aLocalId_3e(ptr %s0, ptr %l3)
  br label %bb16
bb16:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eClear_3ccompiler_2fmir_3aLocalId_3e(ptr %s0, ptr %l4)
  br label %bb17
bb17:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/emit:fnEm", ptr %t49, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eMentions(ptr %v0, ptr %s4, ptr %s0, ptr %s0, ptr %t52, ptr %l12, ptr %l3, ptr %l4)
  br label %bb18
bb18:
  store ptr %l3, ptr %l13, !tbaa !29
  store i64 0, ptr %l14, !tbaa !24
  br label %bb19
bb19:
  %t58 = load i64, ptr %l14, !tbaa !24
  store i64 %t58, ptr %l51, !tbaa !24
  %t59 = load ptr, ptr %l13, !tbaa !29
  %t61 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eLen_3ccompiler_2fmir_3aLocalId_3e(ptr %s0, ptr %t59)
  store i64 %t61, ptr %l53
  br label %bb20
bb20:
  %t62 = load i64, ptr %l51, !tbaa !24
  %t63 = load i64, ptr %l53, !tbaa !24
  %t64 = icmp slt i64 %t62, %t63
  %t66 = xor i1 %t64, true
  br i1 %t66, label %bb21, label %bb22
bb21:
  br label %bb29
bb22:
  br label %bb23
bb23:
  %t68 = load ptr, ptr %l13, !tbaa !29
  %t69 = load i64, ptr %l14, !tbaa !24
  %t72 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eAt_3ccompiler_2fmir_3aLocalId_3e(ptr %s0, ptr %t68, i64 %t69)
  store i32 %t72, ptr %l58
  br label %bb24
bb24:
  %t73 = load i32, ptr %l58, !tbaa !23
  %t76 = sext i32 %t73 to i64
  %t77 = load i64, ptr %l1, !tbaa !24
  %t80 = icmp eq i64 %t76, %t77
  br i1 %t80, label %bb25, label %bb26
bb25:
  %t82 = load i64, ptr %l5, !tbaa !24
  %t84 = add i64 %t82, 1
  store i64 %t84, ptr %l5, !tbaa !24
  br label %bb27
bb26:
  br label %bb27
bb27:
  br label %bb28
bb28:
  %t86 = load i64, ptr %l14, !tbaa !24
  %t88 = add i64 %t86, 1
  store i64 %t88, ptr %l14, !tbaa !24
  br label %bb19
bb29:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t91 = load i64, ptr %l1, !tbaa !24
  %t97 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2enewOf(ptr %v0, ptr %s4, ptr %t90, ptr %l12, i64 %t91, i32 %a2)
  store i1 %t97, ptr %l71
  br label %bb30
bb30:
  %t98 = load i1, ptr %l71, !tbaa !21
  br i1 %t98, label %bb31, label %bb32
bb31:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb33
bb32:
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s4)
  br label %bb34
bb34:
  %t99 = load i64, ptr %l11, !tbaa !24
  %t101 = add i64 %t99, 1
  store i64 %t101, ptr %l11, !tbaa !24
  br label %bb10
bb35:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eClear_3ccompiler_2fmir_3aLocalId_3e(ptr %s0, ptr %l3)
  br label %bb36
bb36:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eClear_3ccompiler_2fmir_3aLocalId_3e(ptr %s0, ptr %l4)
  br label %bb37
bb37:
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr %"compiler/emit:fnEm", ptr %t105, i32 0, i32 1
  %t108 = load ptr, ptr %t107, !tbaa !29
  %t109 = getelementptr %"compiler/mir:BasicBlock", ptr %l9, i32 0, i32 1
  %t110 = load { i64, [8 x i64] }, ptr %t109
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eTermMentions(ptr %v0, ptr %s0, ptr %s0, ptr %t108, { i64, [8 x i64] } %t110, ptr %l3, ptr %l4)
  br label %bb38
bb38:
  store ptr %l3, ptr %l16, !tbaa !29
  store i64 0, ptr %l17, !tbaa !24
  br label %bb39
bb39:
  %t116 = load i64, ptr %l17, !tbaa !24
  store i64 %t116, ptr %l82, !tbaa !24
  %t117 = load ptr, ptr %l16, !tbaa !29
  %t119 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eLen_3ccompiler_2fmir_3aLocalId_3e(ptr %s0, ptr %t117)
  store i64 %t119, ptr %l84
  br label %bb40
bb40:
  %t120 = load i64, ptr %l82, !tbaa !24
  %t121 = load i64, ptr %l84, !tbaa !24
  %t122 = icmp slt i64 %t120, %t121
  %t124 = xor i1 %t122, true
  br i1 %t124, label %bb41, label %bb42
bb41:
  br label %bb49
bb42:
  br label %bb43
bb43:
  %t126 = load ptr, ptr %l16, !tbaa !29
  %t127 = load i64, ptr %l17, !tbaa !24
  %t130 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eAt_3ccompiler_2fmir_3aLocalId_3e(ptr %s0, ptr %t126, i64 %t127)
  store i32 %t130, ptr %l89
  br label %bb44
bb44:
  %t131 = load i32, ptr %l89, !tbaa !23
  %t134 = sext i32 %t131 to i64
  %t135 = load i64, ptr %l1, !tbaa !24
  %t138 = icmp eq i64 %t134, %t135
  br i1 %t138, label %bb45, label %bb46
bb45:
  %t140 = load i64, ptr %l5, !tbaa !24
  %t142 = add i64 %t140, 1
  store i64 %t142, ptr %l5, !tbaa !24
  br label %bb47
bb46:
  br label %bb47
bb47:
  br label %bb48
bb48:
  %t144 = load i64, ptr %l17, !tbaa !24
  %t146 = add i64 %t144, 1
  store i64 %t146, ptr %l17, !tbaa !24
  br label %bb39
bb49:
  call void @__olang_scope_close(ptr %s2)
  br label %bb50
bb50:
  %t148 = load i64, ptr %l8, !tbaa !24
  %t150 = add i64 %t148, 1
  store i64 %t150, ptr %l8, !tbaa !24
  br label %bb3
bb51:
  %t152 = load i1, ptr %l6, !tbaa !21
  br i1 %t152, label %bb52, label %bb53
bb52:
  %t154 = load i64, ptr %l5, !tbaa !24
  %t156 = icmp eq i64 %t154, 1
  store i1 %t156, ptr %l101, !tbaa !21
  br label %bb54
bb53:
  store i1 false, ptr %l101, !tbaa !21
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s0)
  %t158 = load i1, ptr %l101, !tbaa !21
  store i1 %t158, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2epadTo(ptr %v0, ptr %a0, { i64, [7 x i64] } %a1) #0 {
entry:
  %l1 = alloca { i64, [7 x i64] }
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca i32
  %l4 = alloca i64
  %l13 = alloca i64
  %rv = alloca i64
  store { i64, [7 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [7 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [7 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { { i64, [2 x i64] }, i32 }, ptr %t6, i32 0, i32 0
  %t8 = load { i64, [2 x i64] }, ptr %t7
  store { i64, [2 x i64] } %t8, ptr %l2
  %t10 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t11 = getelementptr { { i64, [2 x i64] }, i32 }, ptr %t10, i32 0, i32 1
  %t12 = load i32, ptr %t11
  store i32 %t12, ptr %l3, !tbaa !23
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t16 = getelementptr %"compiler/emit:fnEm", ptr %a0, i32 0, i32 0
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t18 = load { i64, [2 x i64] }, ptr %l2
  %t19 = load i32, ptr %l3, !tbaa !23
  %t23 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2epassedOf(ptr %v0, ptr %t17, { i64, [2 x i64] } %t18, i32 %t19)
  store i64 %t23, ptr %l13
  br label %bb4
bb4:
  %t24 = load i64, ptr %l13, !tbaa !24
  store i64 %t24, ptr %l4, !tbaa !24
  br label %bb10
bb5:
  br i1 true, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb9
bb8:
  store i64 0, ptr %l4, !tbaa !24
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_496cd21b134a4626_34cb2ee199c6502a)
  unreachable
bb10:
  %t25 = load i64, ptr %l4, !tbaa !24
  store i64 %t25, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2epair(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d407, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d407, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %a1, 1
  %t7 = extractvalue { i64, ptr } %a1, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d408, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d408, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t12 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t11)
  call void @olang_textcopy(ptr %t12, ptr %t3, i64 %t4)
  %t13 = getelementptr i8, ptr %t12, i64 %t4
  call void @olang_textcopy(ptr %t13, ptr %t6, i64 %t7)
  %t14 = getelementptr i8, ptr %t13, i64 %t7
  call void @olang_textcopy(ptr %t14, ptr %t9, i64 %t10)
  %t15 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr %t12, 1
  %t18 = extractvalue { i64, ptr } %t16, 0
  %t19 = extractvalue { i64, ptr } %t16, 1
  %t20 = mul i64 %t18, 1
  %t21 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t20)
  call void @llvm.memcpy.p0.p0.i64(ptr %t21, ptr %t19, i64 %t20, i1 false)
  %t22 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t21, 1
  %t26 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t1, { i64, ptr } %t23)
  store { i64, ptr } %t26, ptr %l8
  br label %bb1
bb1:
  %t27 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t31 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d409, i32 0, i32 1) }, 1
  %t32 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d409, i32 0, i32 1) }, 0
  %t34 = extractvalue { i64, ptr } %t27, 1
  %t35 = extractvalue { i64, ptr } %t27, 0
  %t36 = add i64 %t32, %t35
  %t37 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d410, i32 0, i32 1) }, 1
  %t38 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d410, i32 0, i32 1) }, 0
  %t39 = add i64 %t36, %t38
  %t41 = extractvalue { i64, ptr } %a2, 1
  %t42 = extractvalue { i64, ptr } %a2, 0
  %t43 = add i64 %t39, %t42
  %t44 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d411, i32 0, i32 1) }, 1
  %t45 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d411, i32 0, i32 1) }, 0
  %t46 = add i64 %t43, %t45
  %t47 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t46)
  call void @olang_textcopy(ptr %t47, ptr %t31, i64 %t32)
  %t48 = getelementptr i8, ptr %t47, i64 %t32
  call void @olang_textcopy(ptr %t48, ptr %t34, i64 %t35)
  %t49 = getelementptr i8, ptr %t48, i64 %t35
  call void @olang_textcopy(ptr %t49, ptr %t37, i64 %t38)
  %t50 = getelementptr i8, ptr %t49, i64 %t38
  call void @olang_textcopy(ptr %t50, ptr %t41, i64 %t42)
  %t51 = getelementptr i8, ptr %t50, i64 %t42
  call void @olang_textcopy(ptr %t51, ptr %t44, i64 %t45)
  %t52 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t53 = insertvalue { i64, ptr } %t52, ptr %t47, 1
  %t55 = extractvalue { i64, ptr } %t53, 0
  %t56 = extractvalue { i64, ptr } %t53, 1
  %t57 = mul i64 %t55, 1
  %t58 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t57)
  call void @llvm.memcpy.p0.p0.i64(ptr %t58, ptr %t56, i64 %t57, i1 false)
  %t59 = insertvalue { i64, ptr } undef, i64 %t55, 0
  %t60 = insertvalue { i64, ptr } %t59, ptr %t58, 1
  %t63 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v3, ptr %v3, ptr %t28, { i64, ptr } %t60)
  store { i64, ptr } %t63, ptr %l14
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  %t64 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t64, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3afnEm_2ereclaim(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1, i32 %a2, %"compiler/mir:Range" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [4 x i64] }
  %l2 = alloca i32
  %l3 = alloca %"compiler/mir:Range"
  %l4 = alloca ptr
  %l5 = alloca { i64, [2 x i64] }
  %l6 = alloca i32
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l17 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l18 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l26 = alloca { i64, [4 x i64] }
  %l27 = alloca i32
  %l28 = alloca i64
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca { i64, [4 x i64] }
  %l37 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca { i64, [4 x i64] }
  %l53 = alloca i64
  %l64 = alloca { i64, ptr }
  %l65 = alloca ptr
  %l66 = alloca { i64, [4 x i64] }
  %l69 = alloca i32
  %l70 = alloca { i64, ptr }
  %l72 = alloca { i64, ptr }
  %l74 = alloca { i64, ptr }
  %l76 = alloca { i64, ptr }
  %l78 = alloca { i64, ptr }
  %l83 = alloca { i64, ptr }
  %l84 = alloca ptr
  %l85 = alloca ptr
  %l90 = alloca { i64, ptr }
  %l94 = alloca { i64, ptr }
  %l101 = alloca ptr
  %l106 = alloca { i64, ptr }
  %l109 = alloca { i64, ptr }
  %l116 = alloca ptr
  %l117 = alloca ptr
  %l122 = alloca { i64, ptr }
  %l125 = alloca { i64, ptr }
  %l132 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l133 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l141 = alloca i64
  %l144 = alloca i64
  %l169 = alloca { i64, [4 x i64] }
  %l170 = alloca ptr
  %l173 = alloca i32
  %l174 = alloca i32
  %l177 = alloca ptr
  %l180 = alloca i1
  %l185 = alloca { i64, ptr }
  %l187 = alloca i1
  %l193 = alloca i64
  %l194 = alloca { i64, ptr }
  %l195 = alloca { i64, ptr }
  %l196 = alloca [4 x i8]
  %l205 = alloca { i64, ptr }
  %l207 = alloca i64
  %l213 = alloca i64
  %l216 = alloca i64
  %l236 = alloca { i64, [4 x i64] }
  %l237 = alloca ptr
  %l238 = alloca ptr
  %l239 = alloca { i64, [4 x i64] }
  %l242 = alloca i32
  %l243 = alloca { i64, ptr }
  %l250 = alloca { i64, ptr }
  %l255 = alloca { i64, ptr }
  %l256 = alloca { i64, ptr }
  %l257 = alloca [4 x i8]
  %l260 = alloca { i64, ptr }
  %l261 = alloca { i64, ptr }
  %l262 = alloca [2 x i8]
  %l267 = alloca i1
  %l270 = alloca i1
  %l272 = alloca i64
  %l279 = alloca { i64, ptr }
  %l281 = alloca i64
  %l287 = alloca i64
  %l290 = alloca i64
  %l310 = alloca { i64, [4 x i64] }
  %l311 = alloca ptr
  %l312 = alloca ptr
  %l313 = alloca { i64, [4 x i64] }
  %l316 = alloca i32
  %l317 = alloca { i64, ptr }
  %l320 = alloca { i64, ptr }
  %l321 = alloca ptr
  %l322 = alloca { i64, ptr }
  %l329 = alloca { i64, ptr }
  %l334 = alloca ptr
  %l335 = alloca ptr
  %l339 = alloca { i64, ptr }
  %l342 = alloca { i64, ptr }
  %l346 = alloca { i64, ptr }
  %l348 = alloca i64
  %l351 = alloca ptr
  %l352 = alloca { i64, ptr }
  %l355 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %s32 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, [4 x i64] } %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/mir:Range" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/emit:fnEm", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = getelementptr %"compiler/mir:Fn", ptr %t9, i32 0, i32 0
  %t12 = load { i64, [2 x i64] }, ptr %t11
  store { i64, [2 x i64] } %t12, ptr %l5
  %t14 = load { i64, [2 x i64] }, ptr %l5
  %t16 = extractvalue { i64, [2 x i64] } %t14, 0
  %t17 = icmp eq i64 %t16, 0
  br i1 %t17, label %bb1, label %bb2
bb1:
  %t19 = getelementptr { i64, [2 x i64] }, ptr %l5, i32 0, i32 1
  %t20 = getelementptr { i32 }, ptr %t19, i32 0, i32 0
  %t21 = load i32, ptr %t20
  store i32 %t21, ptr %l6, !tbaa !23
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t23 = load i32, ptr %l6, !tbaa !23
  %t25 = sext i32 %t23 to i64
  store i64 %t25, ptr %l53, !tbaa !24
  br label %bb9
bb4:
  br i1 true, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store i64 -1, ptr %l53, !tbaa !24
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_768769e499c57657_c453ba5dc43e6f8b)
  unreachable
bb9:
  %t27 = load i64, ptr %l53, !tbaa !24
  store i64 %t27, ptr %l7, !tbaa !24
  %t28 = load i64, ptr %l7, !tbaa !24
  %t30 = icmp slt i64 %t28, 0
  br i1 %t30, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb11:
  br label %bb12
bb12:
  %t32 = load ptr, ptr %l4, !tbaa !29
  %t33 = load i64, ptr %l7, !tbaa !24
  %t34 = load i32, ptr %l2, !tbaa !23
  %t38 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2egenOk(ptr %v0, ptr %s0, ptr %t32, i64 %t33, i32 %t34)
  store { i64, ptr } %t38, ptr %l64
  br label %bb13
bb13:
  %t39 = load { i64, ptr }, ptr %l64, !tbaa !27
  store { i64, ptr } %t39, ptr %l8, !tbaa !27
  %t40 = load ptr, ptr %l0, !tbaa !29
  store ptr %t40, ptr %l65, !tbaa !29
  %t41 = load { i64, [4 x i64] }, ptr %l1
  store { i64, [4 x i64] } %t41, ptr %l66
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load { i64, [4 x i64] }, ptr %l1
  %t46 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eotype(ptr %v0, ptr %t42, { i64, [4 x i64] } %t43)
  store i32 %t46, ptr %l69
  br label %bb14
bb14:
  %t47 = load ptr, ptr %l65, !tbaa !29
  %t48 = load { i64, [4 x i64] }, ptr %l66
  %t49 = load i32, ptr %l69, !tbaa !23
  %t50 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s0, ptr %t47, { i64, [4 x i64] } %t48, i32 %t49)
  store { i64, ptr } %t50, ptr %l70
  br label %bb15
bb15:
  %t51 = load { i64, ptr }, ptr %l70, !tbaa !27
  store { i64, ptr } %t51, ptr %l9, !tbaa !27
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2efresh(ptr %v0, ptr %s0, ptr %s0, ptr %t52, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d412, i32 0, i32 1) })
  store { i64, ptr } %t54, ptr %l72
  br label %bb16
bb16:
  %t55 = load { i64, ptr }, ptr %l72, !tbaa !27
  store { i64, ptr } %t55, ptr %l10, !tbaa !27
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2efresh(ptr %v0, ptr %s0, ptr %s0, ptr %t56, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d413, i32 0, i32 1) })
  store { i64, ptr } %t58, ptr %l74
  br label %bb17
bb17:
  %t59 = load { i64, ptr }, ptr %l74, !tbaa !27
  store { i64, ptr } %t59, ptr %l11, !tbaa !27
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2efresh(ptr %v0, ptr %s0, ptr %s0, ptr %t60, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d414, i32 0, i32 1) })
  store { i64, ptr } %t62, ptr %l76
  br label %bb18
bb18:
  %t63 = load { i64, ptr }, ptr %l76, !tbaa !27
  store { i64, ptr } %t63, ptr %l12, !tbaa !27
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2efresh(ptr %v0, ptr %s0, ptr %s0, ptr %t64, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d415, i32 0, i32 1) })
  store { i64, ptr } %t66, ptr %l78
  br label %bb19
bb19:
  %t67 = load { i64, ptr }, ptr %l78, !tbaa !27
  store { i64, ptr } %t67, ptr %l13, !tbaa !27
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t70 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d416, i32 0, i32 1) }, 1
  %t71 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d416, i32 0, i32 1) }, 0
  %t73 = extractvalue { i64, ptr } %t69, 1
  %t74 = extractvalue { i64, ptr } %t69, 0
  %t75 = add i64 %t71, %t74
  %t76 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d417, i32 0, i32 1) }, 1
  %t77 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d417, i32 0, i32 1) }, 0
  %t78 = add i64 %t75, %t77
  %t79 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t78)
  call void @olang_textcopy(ptr %t79, ptr %t70, i64 %t71)
  %t80 = getelementptr i8, ptr %t79, i64 %t71
  call void @olang_textcopy(ptr %t80, ptr %t73, i64 %t74)
  %t81 = getelementptr i8, ptr %t80, i64 %t74
  call void @olang_textcopy(ptr %t81, ptr %t76, i64 %t77)
  %t82 = insertvalue { i64, ptr } undef, i64 %t78, 0
  %t83 = insertvalue { i64, ptr } %t82, ptr %t79, 1
  %t85 = extractvalue { i64, ptr } %t83, 0
  %t86 = extractvalue { i64, ptr } %t83, 1
  %t87 = mul i64 %t85, 1
  %t88 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t87)
  call void @llvm.memcpy.p0.p0.i64(ptr %t88, ptr %t86, i64 %t87, i1 false)
  %t89 = insertvalue { i64, ptr } undef, i64 %t85, 0
  %t90 = insertvalue { i64, ptr } %t89, ptr %t88, 1
  %t93 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t68, { i64, ptr } %t90)
  store { i64, ptr } %t93, ptr %l83
  br label %bb20
bb20:
  %t94 = load { i64, ptr }, ptr %l83, !tbaa !27
  store { i64, ptr } %t94, ptr %l14, !tbaa !27
  %t95 = load ptr, ptr %l0, !tbaa !29
  store ptr %t95, ptr %l84, !tbaa !29
  %t96 = load ptr, ptr %l0, !tbaa !29
  store ptr %t96, ptr %l85, !tbaa !29
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t98 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t99 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d418, i32 0, i32 1) }, 1
  %t100 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d418, i32 0, i32 1) }, 0
  %t102 = extractvalue { i64, ptr } %t98, 1
  %t103 = extractvalue { i64, ptr } %t98, 0
  %t104 = add i64 %t100, %t103
  %t105 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t104)
  call void @olang_textcopy(ptr %t105, ptr %t99, i64 %t100)
  %t106 = getelementptr i8, ptr %t105, i64 %t100
  call void @olang_textcopy(ptr %t106, ptr %t102, i64 %t103)
  %t107 = insertvalue { i64, ptr } undef, i64 %t104, 0
  %t108 = insertvalue { i64, ptr } %t107, ptr %t105, 1
  %t110 = extractvalue { i64, ptr } %t108, 0
  %t111 = extractvalue { i64, ptr } %t108, 1
  %t112 = mul i64 %t110, 1
  %t113 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t112)
  call void @llvm.memcpy.p0.p0.i64(ptr %t113, ptr %t111, i64 %t112, i1 false)
  %t114 = insertvalue { i64, ptr } undef, i64 %t110, 0
  %t115 = insertvalue { i64, ptr } %t114, ptr %t113, 1
  %t118 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %t97, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d419, i32 0, i32 1) }, { i64, ptr } %t115, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d223, i32 0, i32 1) })
  store { i64, ptr } %t118, ptr %l90
  br label %bb21
bb21:
  %t119 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t120 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d420, i32 0, i32 1) }, 1
  %t121 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d420, i32 0, i32 1) }, 0
  %t122 = load { i64, ptr }, ptr %l90, !tbaa !27
  %t123 = extractvalue { i64, ptr } %t122, 1
  %t124 = extractvalue { i64, ptr } %t122, 0
  %t125 = add i64 %t121, %t124
  %t126 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d421, i32 0, i32 1) }, 1
  %t127 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d421, i32 0, i32 1) }, 0
  %t128 = add i64 %t125, %t127
  %t130 = extractvalue { i64, ptr } %t119, 1
  %t131 = extractvalue { i64, ptr } %t119, 0
  %t132 = add i64 %t128, %t131
  %t133 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t132)
  call void @olang_textcopy(ptr %t133, ptr %t120, i64 %t121)
  %t134 = getelementptr i8, ptr %t133, i64 %t121
  call void @olang_textcopy(ptr %t134, ptr %t123, i64 %t124)
  %t135 = getelementptr i8, ptr %t134, i64 %t124
  call void @olang_textcopy(ptr %t135, ptr %t126, i64 %t127)
  %t136 = getelementptr i8, ptr %t135, i64 %t127
  call void @olang_textcopy(ptr %t136, ptr %t130, i64 %t131)
  %t137 = insertvalue { i64, ptr } undef, i64 %t132, 0
  %t138 = insertvalue { i64, ptr } %t137, ptr %t133, 1
  %t140 = extractvalue { i64, ptr } %t138, 0
  %t141 = extractvalue { i64, ptr } %t138, 1
  %t142 = mul i64 %t140, 1
  %t143 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t142)
  call void @llvm.memcpy.p0.p0.i64(ptr %t143, ptr %t141, i64 %t142, i1 false)
  %t144 = insertvalue { i64, ptr } undef, i64 %t140, 0
  %t145 = insertvalue { i64, ptr } %t144, ptr %t143, 1
  %t146 = load ptr, ptr %l85, !tbaa !29
  %t148 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t146, { i64, ptr } %t145)
  store { i64, ptr } %t148, ptr %l94
  br label %bb22
bb22:
  %t149 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t150 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t151 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d422, i32 0, i32 1) }, 1
  %t152 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d422, i32 0, i32 1) }, 0
  %t153 = load { i64, ptr }, ptr %l94, !tbaa !27
  %t154 = extractvalue { i64, ptr } %t153, 1
  %t155 = extractvalue { i64, ptr } %t153, 0
  %t156 = add i64 %t152, %t155
  %t157 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d423, i32 0, i32 1) }, 1
  %t158 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d423, i32 0, i32 1) }, 0
  %t159 = add i64 %t156, %t158
  %t161 = extractvalue { i64, ptr } %t149, 1
  %t162 = extractvalue { i64, ptr } %t149, 0
  %t163 = add i64 %t159, %t162
  %t164 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d423, i32 0, i32 1) }, 1
  %t165 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d423, i32 0, i32 1) }, 0
  %t166 = add i64 %t163, %t165
  %t168 = extractvalue { i64, ptr } %t150, 1
  %t169 = extractvalue { i64, ptr } %t150, 0
  %t170 = add i64 %t166, %t169
  %t171 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t170)
  call void @olang_textcopy(ptr %t171, ptr %t151, i64 %t152)
  %t172 = getelementptr i8, ptr %t171, i64 %t152
  call void @olang_textcopy(ptr %t172, ptr %t154, i64 %t155)
  %t173 = getelementptr i8, ptr %t172, i64 %t155
  call void @olang_textcopy(ptr %t173, ptr %t157, i64 %t158)
  %t174 = getelementptr i8, ptr %t173, i64 %t158
  call void @olang_textcopy(ptr %t174, ptr %t161, i64 %t162)
  %t175 = getelementptr i8, ptr %t174, i64 %t162
  call void @olang_textcopy(ptr %t175, ptr %t164, i64 %t165)
  %t176 = getelementptr i8, ptr %t175, i64 %t165
  call void @olang_textcopy(ptr %t176, ptr %t168, i64 %t169)
  %t177 = insertvalue { i64, ptr } undef, i64 %t170, 0
  %t178 = insertvalue { i64, ptr } %t177, ptr %t171, 1
  %t180 = extractvalue { i64, ptr } %t178, 0
  %t181 = extractvalue { i64, ptr } %t178, 1
  %t182 = mul i64 %t180, 1
  %t183 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t182)
  call void @llvm.memcpy.p0.p0.i64(ptr %t183, ptr %t181, i64 %t182, i1 false)
  %t184 = insertvalue { i64, ptr } undef, i64 %t180, 0
  %t185 = insertvalue { i64, ptr } %t184, ptr %t183, 1
  %t186 = load ptr, ptr %l84, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s0, ptr %t186, { i64, ptr } %t185)
  br label %bb23
bb23:
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t189 = load { i64, ptr }, ptr %l10, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2elabel(ptr %v0, ptr %s0, ptr %t188, { i64, ptr } %t189)
  br label %bb24
bb24:
  %t192 = load ptr, ptr %l0, !tbaa !29
  store ptr %t192, ptr %l101, !tbaa !29
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t194 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t195 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d424, i32 0, i32 1) }, 1
  %t196 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d424, i32 0, i32 1) }, 0
  %t198 = extractvalue { i64, ptr } %t194, 1
  %t199 = extractvalue { i64, ptr } %t194, 0
  %t200 = add i64 %t196, %t199
  %t201 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d425, i32 0, i32 1) }, 1
  %t202 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d425, i32 0, i32 1) }, 0
  %t203 = add i64 %t200, %t202
  %t204 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t203)
  call void @olang_textcopy(ptr %t204, ptr %t195, i64 %t196)
  %t205 = getelementptr i8, ptr %t204, i64 %t196
  call void @olang_textcopy(ptr %t205, ptr %t198, i64 %t199)
  %t206 = getelementptr i8, ptr %t205, i64 %t199
  call void @olang_textcopy(ptr %t206, ptr %t201, i64 %t202)
  %t207 = insertvalue { i64, ptr } undef, i64 %t203, 0
  %t208 = insertvalue { i64, ptr } %t207, ptr %t204, 1
  %t210 = extractvalue { i64, ptr } %t208, 0
  %t211 = extractvalue { i64, ptr } %t208, 1
  %t212 = mul i64 %t210, 1
  %t213 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t212)
  call void @llvm.memcpy.p0.p0.i64(ptr %t213, ptr %t211, i64 %t212, i1 false)
  %t214 = insertvalue { i64, ptr } undef, i64 %t210, 0
  %t215 = insertvalue { i64, ptr } %t214, ptr %t213, 1
  %t218 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t193, { i64, ptr } %t215)
  store { i64, ptr } %t218, ptr %l106
  br label %bb25
bb25:
  %t219 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d426, i32 0, i32 1) }, 1
  %t220 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d426, i32 0, i32 1) }, 0
  %t221 = load { i64, ptr }, ptr %l106, !tbaa !27
  %t222 = extractvalue { i64, ptr } %t221, 1
  %t223 = extractvalue { i64, ptr } %t221, 0
  %t224 = add i64 %t220, %t223
  %t225 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d427, i32 0, i32 1) }, 1
  %t226 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d427, i32 0, i32 1) }, 0
  %t227 = add i64 %t224, %t226
  %t228 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t227)
  call void @olang_textcopy(ptr %t228, ptr %t219, i64 %t220)
  %t229 = getelementptr i8, ptr %t228, i64 %t220
  call void @olang_textcopy(ptr %t229, ptr %t222, i64 %t223)
  %t230 = getelementptr i8, ptr %t229, i64 %t223
  call void @olang_textcopy(ptr %t230, ptr %t225, i64 %t226)
  %t231 = insertvalue { i64, ptr } undef, i64 %t227, 0
  %t232 = insertvalue { i64, ptr } %t231, ptr %t228, 1
  %t234 = extractvalue { i64, ptr } %t232, 0
  %t235 = extractvalue { i64, ptr } %t232, 1
  %t236 = mul i64 %t234, 1
  %t237 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t236)
  call void @llvm.memcpy.p0.p0.i64(ptr %t237, ptr %t235, i64 %t236, i1 false)
  %t238 = insertvalue { i64, ptr } undef, i64 %t234, 0
  %t239 = insertvalue { i64, ptr } %t238, ptr %t237, 1
  %t240 = load ptr, ptr %l101, !tbaa !29
  %t242 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t240, { i64, ptr } %t239)
  store { i64, ptr } %t242, ptr %l109
  br label %bb26
bb26:
  %t243 = load { i64, ptr }, ptr %l109, !tbaa !27
  store { i64, ptr } %t243, ptr %l15, !tbaa !27
  %t244 = load ptr, ptr %l0, !tbaa !29
  %t245 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t246 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d428, i32 0, i32 1) }, 1
  %t247 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d428, i32 0, i32 1) }, 0
  %t249 = extractvalue { i64, ptr } %t245, 1
  %t250 = extractvalue { i64, ptr } %t245, 0
  %t251 = add i64 %t247, %t250
  %t252 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t251)
  call void @olang_textcopy(ptr %t252, ptr %t246, i64 %t247)
  %t253 = getelementptr i8, ptr %t252, i64 %t247
  call void @olang_textcopy(ptr %t253, ptr %t249, i64 %t250)
  %t254 = insertvalue { i64, ptr } undef, i64 %t251, 0
  %t255 = insertvalue { i64, ptr } %t254, ptr %t252, 1
  %t257 = extractvalue { i64, ptr } %t255, 0
  %t258 = extractvalue { i64, ptr } %t255, 1
  %t259 = mul i64 %t257, 1
  %t260 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t259)
  call void @llvm.memcpy.p0.p0.i64(ptr %t260, ptr %t258, i64 %t259, i1 false)
  %t261 = insertvalue { i64, ptr } undef, i64 %t257, 0
  %t262 = insertvalue { i64, ptr } %t261, ptr %t260, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s0, ptr %t244, { i64, ptr } %t262)
  br label %bb27
bb27:
  %t265 = load ptr, ptr %l0, !tbaa !29
  %t266 = load { i64, ptr }, ptr %l11, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2elabel(ptr %v0, ptr %s0, ptr %t265, { i64, ptr } %t266)
  br label %bb28
bb28:
  %t269 = load ptr, ptr %l0, !tbaa !29
  store ptr %t269, ptr %l116, !tbaa !29
  %t270 = load ptr, ptr %l0, !tbaa !29
  store ptr %t270, ptr %l117, !tbaa !29
  %t271 = load ptr, ptr %l0, !tbaa !29
  %t272 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t273 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d429, i32 0, i32 1) }, 1
  %t274 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d429, i32 0, i32 1) }, 0
  %t276 = extractvalue { i64, ptr } %t272, 1
  %t277 = extractvalue { i64, ptr } %t272, 0
  %t278 = add i64 %t274, %t277
  %t279 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d430, i32 0, i32 1) }, 1
  %t280 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d430, i32 0, i32 1) }, 0
  %t281 = add i64 %t278, %t280
  %t282 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t281)
  call void @olang_textcopy(ptr %t282, ptr %t273, i64 %t274)
  %t283 = getelementptr i8, ptr %t282, i64 %t274
  call void @olang_textcopy(ptr %t283, ptr %t276, i64 %t277)
  %t284 = getelementptr i8, ptr %t283, i64 %t277
  call void @olang_textcopy(ptr %t284, ptr %t279, i64 %t280)
  %t285 = insertvalue { i64, ptr } undef, i64 %t281, 0
  %t286 = insertvalue { i64, ptr } %t285, ptr %t282, 1
  %t288 = extractvalue { i64, ptr } %t286, 0
  %t289 = extractvalue { i64, ptr } %t286, 1
  %t290 = mul i64 %t288, 1
  %t291 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t290)
  call void @llvm.memcpy.p0.p0.i64(ptr %t291, ptr %t289, i64 %t290, i1 false)
  %t292 = insertvalue { i64, ptr } undef, i64 %t288, 0
  %t293 = insertvalue { i64, ptr } %t292, ptr %t291, 1
  %t296 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t271, { i64, ptr } %t293)
  store { i64, ptr } %t296, ptr %l122
  br label %bb29
bb29:
  %t297 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d431, i32 0, i32 1) }, 1
  %t298 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d431, i32 0, i32 1) }, 0
  %t299 = load { i64, ptr }, ptr %l122, !tbaa !27
  %t300 = extractvalue { i64, ptr } %t299, 1
  %t301 = extractvalue { i64, ptr } %t299, 0
  %t302 = add i64 %t298, %t301
  %t303 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d432, i32 0, i32 1) }, 1
  %t304 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d432, i32 0, i32 1) }, 0
  %t305 = add i64 %t302, %t304
  %t306 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t305)
  call void @olang_textcopy(ptr %t306, ptr %t297, i64 %t298)
  %t307 = getelementptr i8, ptr %t306, i64 %t298
  call void @olang_textcopy(ptr %t307, ptr %t300, i64 %t301)
  %t308 = getelementptr i8, ptr %t307, i64 %t301
  call void @olang_textcopy(ptr %t308, ptr %t303, i64 %t304)
  %t309 = insertvalue { i64, ptr } undef, i64 %t305, 0
  %t310 = insertvalue { i64, ptr } %t309, ptr %t306, 1
  %t312 = extractvalue { i64, ptr } %t310, 0
  %t313 = extractvalue { i64, ptr } %t310, 1
  %t314 = mul i64 %t312, 1
  %t315 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t314)
  call void @llvm.memcpy.p0.p0.i64(ptr %t315, ptr %t313, i64 %t314, i1 false)
  %t316 = insertvalue { i64, ptr } undef, i64 %t312, 0
  %t317 = insertvalue { i64, ptr } %t316, ptr %t315, 1
  %t318 = load ptr, ptr %l117, !tbaa !29
  %t320 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t318, { i64, ptr } %t317)
  store { i64, ptr } %t320, ptr %l125
  br label %bb30
bb30:
  %t321 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t322 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t323 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d433, i32 0, i32 1) }, 1
  %t324 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d433, i32 0, i32 1) }, 0
  %t325 = load { i64, ptr }, ptr %l125, !tbaa !27
  %t326 = extractvalue { i64, ptr } %t325, 1
  %t327 = extractvalue { i64, ptr } %t325, 0
  %t328 = add i64 %t324, %t327
  %t329 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d434, i32 0, i32 1) }, 1
  %t330 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d434, i32 0, i32 1) }, 0
  %t331 = add i64 %t328, %t330
  %t333 = extractvalue { i64, ptr } %t321, 1
  %t334 = extractvalue { i64, ptr } %t321, 0
  %t335 = add i64 %t331, %t334
  %t336 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d434, i32 0, i32 1) }, 1
  %t337 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d434, i32 0, i32 1) }, 0
  %t338 = add i64 %t335, %t337
  %t340 = extractvalue { i64, ptr } %t322, 1
  %t341 = extractvalue { i64, ptr } %t322, 0
  %t342 = add i64 %t338, %t341
  %t343 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t342)
  call void @olang_textcopy(ptr %t343, ptr %t323, i64 %t324)
  %t344 = getelementptr i8, ptr %t343, i64 %t324
  call void @olang_textcopy(ptr %t344, ptr %t326, i64 %t327)
  %t345 = getelementptr i8, ptr %t344, i64 %t327
  call void @olang_textcopy(ptr %t345, ptr %t329, i64 %t330)
  %t346 = getelementptr i8, ptr %t345, i64 %t330
  call void @olang_textcopy(ptr %t346, ptr %t333, i64 %t334)
  %t347 = getelementptr i8, ptr %t346, i64 %t334
  call void @olang_textcopy(ptr %t347, ptr %t336, i64 %t337)
  %t348 = getelementptr i8, ptr %t347, i64 %t337
  call void @olang_textcopy(ptr %t348, ptr %t340, i64 %t341)
  %t349 = insertvalue { i64, ptr } undef, i64 %t342, 0
  %t350 = insertvalue { i64, ptr } %t349, ptr %t343, 1
  %t352 = extractvalue { i64, ptr } %t350, 0
  %t353 = extractvalue { i64, ptr } %t350, 1
  %t354 = mul i64 %t352, 1
  %t355 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t354)
  call void @llvm.memcpy.p0.p0.i64(ptr %t355, ptr %t353, i64 %t354, i1 false)
  %t356 = insertvalue { i64, ptr } undef, i64 %t352, 0
  %t357 = insertvalue { i64, ptr } %t356, ptr %t355, 1
  %t358 = load ptr, ptr %l116, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s0, ptr %t358, { i64, ptr } %t357)
  br label %bb31
bb31:
  %t360 = load ptr, ptr %l0, !tbaa !29
  %t361 = load { i64, ptr }, ptr %l12, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2elabel(ptr %v0, ptr %s0, ptr %t360, { i64, ptr } %t361)
  br label %bb32
bb32:
  %t364 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t364, ptr %l132
  br label %bb33
bb33:
  %t365 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l132
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t365, ptr %l16
  %t366 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t366, ptr %l133
  br label %bb34
bb34:
  %t367 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l133
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t367, ptr %l17
  store i1 false, ptr %l18, !tbaa !21
  %t368 = load ptr, ptr %l4, !tbaa !29
  %t370 = getelementptr %"compiler/emit:Emitter", ptr %t368, i32 0, i32 3
  %t371 = load ptr, ptr %t370, !tbaa !29
  store ptr %t371, ptr %l19, !tbaa !29
  store i64 0, ptr %l20, !tbaa !24
  %t373 = getelementptr %"compiler/mir:Range", ptr %l3, i32 0, i32 1
  %t374 = load i32, ptr %t373, !tbaa !23
  %t376 = sext i32 %t374 to i64
  store i64 %t376, ptr %l21, !tbaa !24
  store i64 1, ptr %l22, !tbaa !24
  %t378 = load i64, ptr %l21, !tbaa !24
  %t379 = load i64, ptr %l20, !tbaa !24
  %t382 = icmp sgt i64 %t378, %t379
  br i1 %t382, label %bb35, label %bb36
bb35:
  %t384 = load i64, ptr %l22, !tbaa !24
  %t386 = icmp sgt i64 %t384, 0
  br i1 %t386, label %bb37, label %bb38
bb36:
  store i64 0, ptr %l141, !tbaa !24
  br label %bb40
bb37:
  %t388 = load i64, ptr %l21, !tbaa !24
  %t389 = load i64, ptr %l20, !tbaa !24
  %t392 = sub i64 %t388, %t389
  %t393 = load i64, ptr %l22, !tbaa !24
  %t396 = add i64 %t392, %t393
  %t398 = sub i64 %t396, 1
  %t399 = load i64, ptr %l22, !tbaa !24
  %t402 = sdiv i64 %t398, %t399
  store i64 %t402, ptr %l144, !tbaa !24
  br label %bb39
bb38:
  store i64 0, ptr %l144, !tbaa !24
  br label %bb39
bb39:
  %t404 = load i64, ptr %l144, !tbaa !24
  store i64 %t404, ptr %l141, !tbaa !24
  br label %bb40
bb40:
  %t405 = load i64, ptr %l141, !tbaa !24
  store i64 %t405, ptr %l23, !tbaa !24
  store i64 0, ptr %l24, !tbaa !24
  br label %bb41
bb41:
  %t406 = load i64, ptr %l24, !tbaa !24
  %t407 = load i64, ptr %l23, !tbaa !24
  %t410 = icmp slt i64 %t406, %t407
  %t412 = xor i1 %t410, true
  br i1 %t412, label %bb42, label %bb43
bb42:
  br label %bb61
bb43:
  br label %bb44
bb44:
  %t414 = load i64, ptr %l20, !tbaa !24
  %t415 = load i64, ptr %l24, !tbaa !24
  %t416 = load i64, ptr %l22, !tbaa !24
  %t419 = mul i64 %t415, %t416
  %t422 = add i64 %t414, %t419
  %t424 = load ptr, ptr %l0, !tbaa !29
  %t426 = getelementptr %"compiler/emit:fnEm", ptr %t424, i32 0, i32 1
  %t427 = load ptr, ptr %t426, !tbaa !29
  %t429 = getelementptr %"compiler/mir:Fn", ptr %t427, i32 0, i32 11
  %t430 = getelementptr %"compiler/mir:Range", ptr %l3, i32 0, i32 0
  %t431 = load i32, ptr %t430, !tbaa !23
  %t433 = sext i32 %t431 to i64
  %t437 = add i64 %t433, %t422
  %t440 = call { i64, [4 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2eAt_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %t429, i64 %t437)
  store { i64, [4 x i64] } %t440, ptr %l169
  br label %bb45
bb45:
  %t441 = load { i64, [4 x i64] }, ptr %l169
  store { i64, [4 x i64] } %t441, ptr %l26
  %t442 = load ptr, ptr %l19, !tbaa !29
  store ptr %t442, ptr %l170, !tbaa !29
  %t443 = load ptr, ptr %l0, !tbaa !29
  %t444 = load { i64, [4 x i64] }, ptr %l26
  %t447 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eotype(ptr %v0, ptr %t443, { i64, [4 x i64] } %t444)
  store i32 %t447, ptr %l173
  br label %bb46
bb46:
  %t448 = load ptr, ptr %l170, !tbaa !29
  %t449 = load i32, ptr %l173, !tbaa !23
  %t450 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t448, i32 %t449)
  store i32 %t450, ptr %l174
  br label %bb47
bb47:
  %t451 = load i32, ptr %l174, !tbaa !23
  store i32 %t451, ptr %l27, !tbaa !23
  %t452 = load ptr, ptr %l4, !tbaa !29
  %t454 = getelementptr %"compiler/emit:Emitter", ptr %t452, i32 0, i32 1
  %t455 = load ptr, ptr %t454, !tbaa !29
  %t457 = call ptr @compiler_2flower_2ecompiler_2flower_3aLowerer_2eGen(ptr %v0, ptr %v0, ptr %t455)
  store ptr %t457, ptr %l177
  br label %bb48
bb48:
  %t458 = load ptr, ptr %l19, !tbaa !29
  %t459 = load i32, ptr %l27, !tbaa !23
  %t460 = load ptr, ptr %l177, !tbaa !29
  %t463 = call i1 @compiler_2fmir_2ecompiler_2fmir_3aGenInfo_2eGenRef(ptr %v0, ptr %v0, ptr %t460, ptr %t458, i32 %t459)
  store i1 %t463, ptr %l180
  br label %bb49
bb49:
  %t464 = load i1, ptr %l180, !tbaa !21
  br i1 %t464, label %bb50, label %bb51
bb50:
  %t465 = load { i64, [4 x i64] }, ptr %l26
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2ePush_3ccompiler_2fmir_3aOperand_3e(ptr %s0, ptr %l16, { i64, [4 x i64] } %t465)
  br label %bb52
bb51:
  store %olang.scope zeroinitializer, ptr %s17
  %t468 = load ptr, ptr %l0, !tbaa !29
  %t469 = load i32, ptr %l27, !tbaa !23
  %t472 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s17, ptr %t468, i32 %t469)
  store { i64, ptr } %t472, ptr %l185
  br label %bb53
bb52:
  br label %bb59
bb53:
  %t473 = load { i64, ptr }, ptr %l185, !tbaa !27
  %t474 = extractvalue { i64, ptr } %t473, 0
  %t475 = extractvalue { i64, ptr } %t473, 1
  %t476 = mul i64 %t474, 1
  %t477 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t476)
  call void @llvm.memcpy.p0.p0.i64(ptr %t477, ptr %t475, i64 %t476, i1 false)
  %t478 = insertvalue { i64, ptr } undef, i64 %t474, 0
  %t479 = insertvalue { i64, ptr } %t478, ptr %t477, 1
  %t481 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s17, ptr %s17, { i64, ptr } %t479, { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d435, i32 0, i32 1) })
  store i1 %t481, ptr %l187
  br label %bb54
bb54:
  %t482 = load i1, ptr %l187, !tbaa !21
  br i1 %t482, label %bb55, label %bb56
bb55:
  %t483 = load { i64, [4 x i64] }, ptr %l26
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2ePush_3ccompiler_2fmir_3aOperand_3e(ptr %s0, ptr %l17, { i64, [4 x i64] } %t483)
  br label %bb57
bb56:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb58
bb57:
  br label %bb58
bb58:
  call void @__olang_scope_close(ptr %s17)
  br label %bb59
bb59:
  br label %bb60
bb60:
  %t486 = load i64, ptr %l24, !tbaa !24
  %t488 = add i64 %t486, 1
  store i64 %t488, ptr %l24, !tbaa !24
  br label %bb41
bb61:
  %t491 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2eLen_3ccompiler_2fmir_3aOperand_3e(ptr %s0, ptr %l16)
  store i64 %t491, ptr %l193
  br label %bb62
bb62:
  %t492 = load i64, ptr %l193, !tbaa !24
  store i64 %t492, ptr %l28, !tbaa !24
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d436, i32 0, i32 1) }, ptr %l194, !tbaa !27
  %t493 = load { i64, ptr }, ptr %l194, !tbaa !27
  store { i64, ptr } %t493, ptr %l195, !tbaa !27
  %t494 = getelementptr { i64, ptr }, ptr %l195, i32 0, i32 1
  %t495 = load ptr, ptr %t494, !tbaa !27
  %t496 = mul i64 4, 1
  call void @llvm.memmove.p0.p0.i64(ptr %l196, ptr %t495, i64 %t496, i1 false)
  %t498 = insertvalue { i64, ptr } undef, i64 4, 0
  %t499 = insertvalue { i64, ptr } %t498, ptr %l196, 1
  store { i64, ptr } %t499, ptr %l29, !tbaa !27
  %t501 = load i64, ptr %l28, !tbaa !24
  %t503 = icmp sgt i64 %t501, 0
  br i1 %t503, label %bb63, label %bb64
bb63:
  %t505 = load ptr, ptr %l0, !tbaa !29
  %t506 = load i64, ptr %l28, !tbaa !24
  %t507 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d437, i32 0, i32 1) }, 1
  %t508 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d437, i32 0, i32 1) }, 0
  %t510 = call i64 @__olang_fmt_i64(ptr null, i64 %t506)
  %t511 = add i64 %t508, %t510
  %t512 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d438, i32 0, i32 1) }, 1
  %t513 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d438, i32 0, i32 1) }, 0
  %t514 = add i64 %t511, %t513
  %t515 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t514)
  call void @olang_textcopy(ptr %t515, ptr %t507, i64 %t508)
  %t516 = getelementptr i8, ptr %t515, i64 %t508
  %t517 = call i64 @__olang_fmt_i64(ptr %t516, i64 %t506)
  %t518 = getelementptr i8, ptr %t516, i64 %t510
  call void @olang_textcopy(ptr %t518, ptr %t512, i64 %t513)
  %t519 = insertvalue { i64, ptr } undef, i64 %t514, 0
  %t520 = insertvalue { i64, ptr } %t519, ptr %t515, 1
  %t522 = extractvalue { i64, ptr } %t520, 0
  %t523 = extractvalue { i64, ptr } %t520, 1
  %t524 = mul i64 %t522, 1
  %t525 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t524)
  call void @llvm.memcpy.p0.p0.i64(ptr %t525, ptr %t523, i64 %t524, i1 false)
  %t526 = insertvalue { i64, ptr } undef, i64 %t522, 0
  %t527 = insertvalue { i64, ptr } %t526, ptr %t525, 1
  %t530 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ealloca(ptr %v0, ptr %s0, ptr %s0, ptr %t505, { i64, ptr } %t527, i64 0)
  store { i64, ptr } %t530, ptr %l205
  br label %bb65
bb64:
  br label %bb86
bb65:
  %t531 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t532 = extractvalue { i64, ptr } %t531, 0
  %t533 = load { i64, ptr }, ptr %l205, !tbaa !27
  %t534 = extractvalue { i64, ptr } %t533, 0
  store i64 %t534, ptr %l207, !tbaa !24
  %t536 = load i64, ptr %l207, !tbaa !24
  %t537 = icmp eq i64 %t532, %t536
  br i1 %t537, label %bb66, label %bb67
bb66:
  %t539 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t540 = load ptr, ptr %t539, !tbaa !27
  %t541 = getelementptr { i64, ptr }, ptr %l205, i32 0, i32 1
  %t542 = load ptr, ptr %t541, !tbaa !27
  %t543 = load i64, ptr %l207, !tbaa !24
  %t544 = mul i64 %t543, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t540, ptr %t542, i64 %t544, i1 false)
  br label %bb68
bb67:
  %t545 = load { i64, ptr }, ptr %l205, !tbaa !27
  store { i64, ptr } %t545, ptr %l29, !tbaa !27
  br label %bb68
bb68:
  store i64 0, ptr %l30, !tbaa !24
  %t546 = load i64, ptr %l28, !tbaa !24
  store i64 %t546, ptr %l31, !tbaa !24
  store i64 1, ptr %l32, !tbaa !24
  %t548 = load i64, ptr %l31, !tbaa !24
  %t549 = load i64, ptr %l30, !tbaa !24
  %t552 = icmp sgt i64 %t548, %t549
  br i1 %t552, label %bb69, label %bb70
bb69:
  %t554 = load i64, ptr %l32, !tbaa !24
  %t556 = icmp sgt i64 %t554, 0
  br i1 %t556, label %bb71, label %bb72
bb70:
  store i64 0, ptr %l213, !tbaa !24
  br label %bb74
bb71:
  %t558 = load i64, ptr %l31, !tbaa !24
  %t559 = load i64, ptr %l30, !tbaa !24
  %t562 = sub i64 %t558, %t559
  %t563 = load i64, ptr %l32, !tbaa !24
  %t566 = add i64 %t562, %t563
  %t568 = sub i64 %t566, 1
  %t569 = load i64, ptr %l32, !tbaa !24
  %t572 = sdiv i64 %t568, %t569
  store i64 %t572, ptr %l216, !tbaa !24
  br label %bb73
bb72:
  store i64 0, ptr %l216, !tbaa !24
  br label %bb73
bb73:
  %t574 = load i64, ptr %l216, !tbaa !24
  store i64 %t574, ptr %l213, !tbaa !24
  br label %bb74
bb74:
  %t575 = load i64, ptr %l213, !tbaa !24
  store i64 %t575, ptr %l33, !tbaa !24
  store i64 0, ptr %l34, !tbaa !24
  br label %bb75
bb75:
  store %olang.scope zeroinitializer, ptr %s24
  %t576 = load i64, ptr %l34, !tbaa !24
  %t577 = load i64, ptr %l33, !tbaa !24
  %t580 = icmp slt i64 %t576, %t577
  %t582 = xor i1 %t580, true
  br i1 %t582, label %bb76, label %bb77
bb76:
  call void @__olang_scope_close(ptr %s24)
  br label %bb85
bb77:
  br label %bb78
bb78:
  %t584 = load i64, ptr %l30, !tbaa !24
  %t585 = load i64, ptr %l34, !tbaa !24
  %t586 = load i64, ptr %l32, !tbaa !24
  %t589 = mul i64 %t585, %t586
  %t592 = add i64 %t584, %t589
  store i64 %t592, ptr %l35, !tbaa !24
  %t594 = load i64, ptr %l35, !tbaa !24
  %t597 = call { i64, [4 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2eAt_3ccompiler_2fmir_3aOperand_3e(ptr %s0, ptr %l16, i64 %t594)
  store { i64, [4 x i64] } %t597, ptr %l236
  br label %bb79
bb79:
  %t598 = load { i64, [4 x i64] }, ptr %l236
  store { i64, [4 x i64] } %t598, ptr %l36
  %t599 = load ptr, ptr %l0, !tbaa !29
  store ptr %t599, ptr %l237, !tbaa !29
  %t600 = load ptr, ptr %l0, !tbaa !29
  store ptr %t600, ptr %l238, !tbaa !29
  %t601 = load { i64, [4 x i64] }, ptr %l36
  store { i64, [4 x i64] } %t601, ptr %l239
  %t602 = load ptr, ptr %l0, !tbaa !29
  %t603 = load { i64, [4 x i64] }, ptr %l36
  %t606 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eotype(ptr %v0, ptr %t602, { i64, [4 x i64] } %t603)
  store i32 %t606, ptr %l242
  br label %bb80
bb80:
  %t607 = load ptr, ptr %l238, !tbaa !29
  %t608 = load { i64, [4 x i64] }, ptr %l239
  %t609 = load i32, ptr %l242, !tbaa !23
  %t610 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s24, ptr %t607, { i64, [4 x i64] } %t608, i32 %t609)
  store { i64, ptr } %t610, ptr %l243
  br label %bb81
bb81:
  %t611 = load ptr, ptr %l0, !tbaa !29
  %t612 = load i64, ptr %l28, !tbaa !24
  %t613 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t614 = load i64, ptr %l35, !tbaa !24
  %t615 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d439, i32 0, i32 1) }, 1
  %t616 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d439, i32 0, i32 1) }, 0
  %t618 = call i64 @__olang_fmt_i64(ptr null, i64 %t612)
  %t619 = add i64 %t616, %t618
  %t620 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d440, i32 0, i32 1) }, 1
  %t621 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d440, i32 0, i32 1) }, 0
  %t622 = add i64 %t619, %t621
  %t624 = extractvalue { i64, ptr } %t613, 1
  %t625 = extractvalue { i64, ptr } %t613, 0
  %t626 = add i64 %t622, %t625
  %t627 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d441, i32 0, i32 1) }, 1
  %t628 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d441, i32 0, i32 1) }, 0
  %t629 = add i64 %t626, %t628
  %t631 = call i64 @__olang_fmt_i64(ptr null, i64 %t614)
  %t632 = add i64 %t629, %t631
  %t633 = call ptr @__olang_scope_alloc(ptr %s24, i64 %t632)
  call void @olang_textcopy(ptr %t633, ptr %t615, i64 %t616)
  %t634 = getelementptr i8, ptr %t633, i64 %t616
  %t635 = call i64 @__olang_fmt_i64(ptr %t634, i64 %t612)
  %t636 = getelementptr i8, ptr %t634, i64 %t618
  call void @olang_textcopy(ptr %t636, ptr %t620, i64 %t621)
  %t637 = getelementptr i8, ptr %t636, i64 %t621
  call void @olang_textcopy(ptr %t637, ptr %t624, i64 %t625)
  %t638 = getelementptr i8, ptr %t637, i64 %t625
  call void @olang_textcopy(ptr %t638, ptr %t627, i64 %t628)
  %t639 = getelementptr i8, ptr %t638, i64 %t628
  %t640 = call i64 @__olang_fmt_i64(ptr %t639, i64 %t614)
  %t641 = insertvalue { i64, ptr } undef, i64 %t632, 0
  %t642 = insertvalue { i64, ptr } %t641, ptr %t633, 1
  %t644 = extractvalue { i64, ptr } %t642, 0
  %t645 = extractvalue { i64, ptr } %t642, 1
  %t646 = mul i64 %t644, 1
  %t647 = call ptr @__olang_scope_alloc(ptr %s24, i64 %t646)
  call void @llvm.memcpy.p0.p0.i64(ptr %t647, ptr %t645, i64 %t646, i1 false)
  %t648 = insertvalue { i64, ptr } undef, i64 %t644, 0
  %t649 = insertvalue { i64, ptr } %t648, ptr %t647, 1
  %t652 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s24, ptr %s24, ptr %t611, { i64, ptr } %t649)
  store { i64, ptr } %t652, ptr %l250
  br label %bb82
bb82:
  %t653 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d442, i32 0, i32 1) }, 1
  %t654 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d442, i32 0, i32 1) }, 0
  %t655 = load { i64, ptr }, ptr %l243, !tbaa !27
  %t656 = extractvalue { i64, ptr } %t655, 1
  %t657 = extractvalue { i64, ptr } %t655, 0
  %t658 = add i64 %t654, %t657
  %t659 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d443, i32 0, i32 1) }, 1
  %t660 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d443, i32 0, i32 1) }, 0
  %t661 = add i64 %t658, %t660
  %t662 = load { i64, ptr }, ptr %l250, !tbaa !27
  %t663 = extractvalue { i64, ptr } %t662, 1
  %t664 = extractvalue { i64, ptr } %t662, 0
  %t665 = add i64 %t661, %t664
  %t666 = call ptr @__olang_scope_alloc(ptr %s24, i64 %t665)
  call void @olang_textcopy(ptr %t666, ptr %t653, i64 %t654)
  %t667 = getelementptr i8, ptr %t666, i64 %t654
  call void @olang_textcopy(ptr %t667, ptr %t656, i64 %t657)
  %t668 = getelementptr i8, ptr %t667, i64 %t657
  call void @olang_textcopy(ptr %t668, ptr %t659, i64 %t660)
  %t669 = getelementptr i8, ptr %t668, i64 %t660
  call void @olang_textcopy(ptr %t669, ptr %t663, i64 %t664)
  %t670 = insertvalue { i64, ptr } undef, i64 %t665, 0
  %t671 = insertvalue { i64, ptr } %t670, ptr %t666, 1
  %t673 = extractvalue { i64, ptr } %t671, 0
  %t674 = extractvalue { i64, ptr } %t671, 1
  %t675 = mul i64 %t673, 1
  %t676 = call ptr @__olang_scope_alloc(ptr %s24, i64 %t675)
  call void @llvm.memcpy.p0.p0.i64(ptr %t676, ptr %t674, i64 %t675, i1 false)
  %t677 = insertvalue { i64, ptr } undef, i64 %t673, 0
  %t678 = insertvalue { i64, ptr } %t677, ptr %t676, 1
  %t679 = load ptr, ptr %l237, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s24, ptr %t679, { i64, ptr } %t678)
  br label %bb83
bb83:
  call void @__olang_scope_close(ptr %s24)
  br label %bb84
bb84:
  %t681 = load i64, ptr %l34, !tbaa !24
  %t683 = add i64 %t681, 1
  store i64 %t683, ptr %l34, !tbaa !24
  br label %bb75
bb85:
  br label %bb86
bb86:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d444, i32 0, i32 1) }, ptr %l255, !tbaa !27
  %t685 = load { i64, ptr }, ptr %l255, !tbaa !27
  store { i64, ptr } %t685, ptr %l256, !tbaa !27
  %t686 = getelementptr { i64, ptr }, ptr %l256, i32 0, i32 1
  %t687 = load ptr, ptr %t686, !tbaa !27
  %t688 = mul i64 4, 1
  call void @llvm.memmove.p0.p0.i64(ptr %l257, ptr %t687, i64 %t688, i1 false)
  %t690 = insertvalue { i64, ptr } undef, i64 4, 0
  %t691 = insertvalue { i64, ptr } %t690, ptr %l257, 1
  store { i64, ptr } %t691, ptr %l37, !tbaa !27
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d445, i32 0, i32 1) }, ptr %l260, !tbaa !27
  %t693 = load { i64, ptr }, ptr %l260, !tbaa !27
  store { i64, ptr } %t693, ptr %l261, !tbaa !27
  %t694 = getelementptr { i64, ptr }, ptr %l261, i32 0, i32 1
  %t695 = load ptr, ptr %t694, !tbaa !27
  %t696 = mul i64 2, 1
  call void @llvm.memmove.p0.p0.i64(ptr %l262, ptr %t695, i64 %t696, i1 false)
  %t698 = insertvalue { i64, ptr } undef, i64 2, 0
  %t699 = insertvalue { i64, ptr } %t698, ptr %l262, 1
  store { i64, ptr } %t699, ptr %l38, !tbaa !27
  %t701 = load i1, ptr %l18, !tbaa !21
  %t703 = xor i1 %t701, true
  br i1 %t703, label %bb87, label %bb88
bb87:
  %t705 = load ptr, ptr %l4, !tbaa !29
  %t706 = load i32, ptr %l2, !tbaa !23
  %t709 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2egenBufOn(ptr %v0, ptr %t705, i32 %t706)
  store i1 %t709, ptr %l270
  br label %bb89
bb88:
  store i1 false, ptr %l267, !tbaa !21
  br label %bb90
bb89:
  %t710 = load i1, ptr %l270, !tbaa !21
  store i1 %t710, ptr %l267, !tbaa !21
  br label %bb90
bb90:
  %t711 = load i1, ptr %l267, !tbaa !21
  br i1 %t711, label %bb91, label %bb92
bb91:
  store %olang.scope zeroinitializer, ptr %s28
  %t713 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2eLen_3ccompiler_2fmir_3aOperand_3e(ptr %s0, ptr %l17)
  store i64 %t713, ptr %l272
  br label %bb93
bb92:
  br label %bb125
bb93:
  %t714 = load i64, ptr %l272, !tbaa !24
  store i64 %t714, ptr %l39, !tbaa !24
  %t715 = load i64, ptr %l39, !tbaa !24
  %t717 = icmp sgt i64 %t715, 0
  br i1 %t717, label %bb94, label %bb95
bb94:
  %t719 = load ptr, ptr %l0, !tbaa !29
  %t720 = load i64, ptr %l39, !tbaa !24
  %t721 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d446, i32 0, i32 1) }, 1
  %t722 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d446, i32 0, i32 1) }, 0
  %t724 = call i64 @__olang_fmt_i64(ptr null, i64 %t720)
  %t725 = add i64 %t722, %t724
  %t726 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d447, i32 0, i32 1) }, 1
  %t727 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d447, i32 0, i32 1) }, 0
  %t728 = add i64 %t725, %t727
  %t729 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t728)
  call void @olang_textcopy(ptr %t729, ptr %t721, i64 %t722)
  %t730 = getelementptr i8, ptr %t729, i64 %t722
  %t731 = call i64 @__olang_fmt_i64(ptr %t730, i64 %t720)
  %t732 = getelementptr i8, ptr %t730, i64 %t724
  call void @olang_textcopy(ptr %t732, ptr %t726, i64 %t727)
  %t733 = insertvalue { i64, ptr } undef, i64 %t728, 0
  %t734 = insertvalue { i64, ptr } %t733, ptr %t729, 1
  %t736 = extractvalue { i64, ptr } %t734, 0
  %t737 = extractvalue { i64, ptr } %t734, 1
  %t738 = mul i64 %t736, 1
  %t739 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t738)
  call void @llvm.memcpy.p0.p0.i64(ptr %t739, ptr %t737, i64 %t738, i1 false)
  %t740 = insertvalue { i64, ptr } undef, i64 %t736, 0
  %t741 = insertvalue { i64, ptr } %t740, ptr %t739, 1
  %t744 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ealloca(ptr %v0, ptr %s0, ptr %s0, ptr %t719, { i64, ptr } %t741, i64 0)
  store { i64, ptr } %t744, ptr %l279
  br label %bb96
bb95:
  br label %bb118
bb96:
  %t745 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t746 = extractvalue { i64, ptr } %t745, 0
  %t747 = load { i64, ptr }, ptr %l279, !tbaa !27
  %t748 = extractvalue { i64, ptr } %t747, 0
  store i64 %t748, ptr %l281, !tbaa !24
  %t750 = load i64, ptr %l281, !tbaa !24
  %t751 = icmp eq i64 %t746, %t750
  br i1 %t751, label %bb97, label %bb98
bb97:
  %t753 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t754 = load ptr, ptr %t753, !tbaa !27
  %t755 = getelementptr { i64, ptr }, ptr %l279, i32 0, i32 1
  %t756 = load ptr, ptr %t755, !tbaa !27
  %t757 = load i64, ptr %l281, !tbaa !24
  %t758 = mul i64 %t757, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t754, ptr %t756, i64 %t758, i1 false)
  br label %bb99
bb98:
  %t759 = load { i64, ptr }, ptr %l279, !tbaa !27
  store { i64, ptr } %t759, ptr %l37, !tbaa !27
  br label %bb99
bb99:
  store i64 0, ptr %l40, !tbaa !24
  %t760 = load i64, ptr %l39, !tbaa !24
  store i64 %t760, ptr %l41, !tbaa !24
  store i64 1, ptr %l42, !tbaa !24
  %t762 = load i64, ptr %l41, !tbaa !24
  %t763 = load i64, ptr %l40, !tbaa !24
  %t766 = icmp sgt i64 %t762, %t763
  br i1 %t766, label %bb100, label %bb101
bb100:
  %t768 = load i64, ptr %l42, !tbaa !24
  %t770 = icmp sgt i64 %t768, 0
  br i1 %t770, label %bb102, label %bb103
bb101:
  store i64 0, ptr %l287, !tbaa !24
  br label %bb105
bb102:
  %t772 = load i64, ptr %l41, !tbaa !24
  %t773 = load i64, ptr %l40, !tbaa !24
  %t776 = sub i64 %t772, %t773
  %t777 = load i64, ptr %l42, !tbaa !24
  %t780 = add i64 %t776, %t777
  %t782 = sub i64 %t780, 1
  %t783 = load i64, ptr %l42, !tbaa !24
  %t786 = sdiv i64 %t782, %t783
  store i64 %t786, ptr %l290, !tbaa !24
  br label %bb104
bb103:
  store i64 0, ptr %l290, !tbaa !24
  br label %bb104
bb104:
  %t788 = load i64, ptr %l290, !tbaa !24
  store i64 %t788, ptr %l287, !tbaa !24
  br label %bb105
bb105:
  %t789 = load i64, ptr %l287, !tbaa !24
  store i64 %t789, ptr %l43, !tbaa !24
  store i64 0, ptr %l44, !tbaa !24
  br label %bb106
bb106:
  store %olang.scope zeroinitializer, ptr %s32
  %t790 = load i64, ptr %l44, !tbaa !24
  %t791 = load i64, ptr %l43, !tbaa !24
  %t794 = icmp slt i64 %t790, %t791
  %t796 = xor i1 %t794, true
  br i1 %t796, label %bb107, label %bb108
bb107:
  call void @__olang_scope_close(ptr %s32)
  br label %bb117
bb108:
  br label %bb109
bb109:
  %t798 = load i64, ptr %l40, !tbaa !24
  %t799 = load i64, ptr %l44, !tbaa !24
  %t800 = load i64, ptr %l42, !tbaa !24
  %t803 = mul i64 %t799, %t800
  %t806 = add i64 %t798, %t803
  store i64 %t806, ptr %l45, !tbaa !24
  %t808 = load i64, ptr %l45, !tbaa !24
  %t811 = call { i64, [4 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2eAt_3ccompiler_2fmir_3aOperand_3e(ptr %s0, ptr %l17, i64 %t808)
  store { i64, [4 x i64] } %t811, ptr %l310
  br label %bb110
bb110:
  %t812 = load { i64, [4 x i64] }, ptr %l310
  store { i64, [4 x i64] } %t812, ptr %l46
  %t813 = load ptr, ptr %l0, !tbaa !29
  store ptr %t813, ptr %l311, !tbaa !29
  %t814 = load ptr, ptr %l0, !tbaa !29
  store ptr %t814, ptr %l312, !tbaa !29
  %t815 = load { i64, [4 x i64] }, ptr %l46
  store { i64, [4 x i64] } %t815, ptr %l313
  %t816 = load ptr, ptr %l0, !tbaa !29
  %t817 = load { i64, [4 x i64] }, ptr %l46
  %t820 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eotype(ptr %v0, ptr %t816, { i64, [4 x i64] } %t817)
  store i32 %t820, ptr %l316
  br label %bb111
bb111:
  %t821 = load ptr, ptr %l312, !tbaa !29
  %t822 = load { i64, [4 x i64] }, ptr %l313
  %t823 = load i32, ptr %l316, !tbaa !23
  %t824 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s32, ptr %t821, { i64, [4 x i64] } %t822, i32 %t823)
  store { i64, ptr } %t824, ptr %l317
  br label %bb112
bb112:
  %t825 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d448, i32 0, i32 1) }, 1
  %t826 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d448, i32 0, i32 1) }, 0
  %t827 = load { i64, ptr }, ptr %l317, !tbaa !27
  %t828 = extractvalue { i64, ptr } %t827, 1
  %t829 = extractvalue { i64, ptr } %t827, 0
  %t830 = add i64 %t826, %t829
  %t831 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d449, i32 0, i32 1) }, 1
  %t832 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d449, i32 0, i32 1) }, 0
  %t833 = add i64 %t830, %t832
  %t834 = call ptr @__olang_scope_alloc(ptr %s32, i64 %t833)
  call void @olang_textcopy(ptr %t834, ptr %t825, i64 %t826)
  %t835 = getelementptr i8, ptr %t834, i64 %t826
  call void @olang_textcopy(ptr %t835, ptr %t828, i64 %t829)
  %t836 = getelementptr i8, ptr %t835, i64 %t829
  call void @olang_textcopy(ptr %t836, ptr %t831, i64 %t832)
  %t837 = insertvalue { i64, ptr } undef, i64 %t833, 0
  %t838 = insertvalue { i64, ptr } %t837, ptr %t834, 1
  %t840 = extractvalue { i64, ptr } %t838, 0
  %t841 = extractvalue { i64, ptr } %t838, 1
  %t842 = mul i64 %t840, 1
  %t843 = call ptr @__olang_scope_alloc(ptr %s32, i64 %t842)
  call void @llvm.memcpy.p0.p0.i64(ptr %t843, ptr %t841, i64 %t842, i1 false)
  %t844 = insertvalue { i64, ptr } undef, i64 %t840, 0
  %t845 = insertvalue { i64, ptr } %t844, ptr %t843, 1
  %t846 = load ptr, ptr %l311, !tbaa !29
  %t848 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s32, ptr %s32, ptr %t846, { i64, ptr } %t845)
  store { i64, ptr } %t848, ptr %l320
  br label %bb113
bb113:
  %t849 = load { i64, ptr }, ptr %l320, !tbaa !27
  %t850 = load ptr, ptr %l0, !tbaa !29
  store ptr %t850, ptr %l321, !tbaa !29
  store { i64, ptr } %t849, ptr %l322, !tbaa !27
  %t852 = load ptr, ptr %l0, !tbaa !29
  %t853 = load i64, ptr %l39, !tbaa !24
  %t854 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t855 = load i64, ptr %l45, !tbaa !24
  %t856 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d450, i32 0, i32 1) }, 1
  %t857 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d450, i32 0, i32 1) }, 0
  %t859 = call i64 @__olang_fmt_i64(ptr null, i64 %t853)
  %t860 = add i64 %t857, %t859
  %t861 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d451, i32 0, i32 1) }, 1
  %t862 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d451, i32 0, i32 1) }, 0
  %t863 = add i64 %t860, %t862
  %t865 = extractvalue { i64, ptr } %t854, 1
  %t866 = extractvalue { i64, ptr } %t854, 0
  %t867 = add i64 %t863, %t866
  %t868 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d452, i32 0, i32 1) }, 1
  %t869 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d452, i32 0, i32 1) }, 0
  %t870 = add i64 %t867, %t869
  %t872 = call i64 @__olang_fmt_i64(ptr null, i64 %t855)
  %t873 = add i64 %t870, %t872
  %t874 = call ptr @__olang_scope_alloc(ptr %s32, i64 %t873)
  call void @olang_textcopy(ptr %t874, ptr %t856, i64 %t857)
  %t875 = getelementptr i8, ptr %t874, i64 %t857
  %t876 = call i64 @__olang_fmt_i64(ptr %t875, i64 %t853)
  %t877 = getelementptr i8, ptr %t875, i64 %t859
  call void @olang_textcopy(ptr %t877, ptr %t861, i64 %t862)
  %t878 = getelementptr i8, ptr %t877, i64 %t862
  call void @olang_textcopy(ptr %t878, ptr %t865, i64 %t866)
  %t879 = getelementptr i8, ptr %t878, i64 %t866
  call void @olang_textcopy(ptr %t879, ptr %t868, i64 %t869)
  %t880 = getelementptr i8, ptr %t879, i64 %t869
  %t881 = call i64 @__olang_fmt_i64(ptr %t880, i64 %t855)
  %t882 = insertvalue { i64, ptr } undef, i64 %t873, 0
  %t883 = insertvalue { i64, ptr } %t882, ptr %t874, 1
  %t885 = extractvalue { i64, ptr } %t883, 0
  %t886 = extractvalue { i64, ptr } %t883, 1
  %t887 = mul i64 %t885, 1
  %t888 = call ptr @__olang_scope_alloc(ptr %s32, i64 %t887)
  call void @llvm.memcpy.p0.p0.i64(ptr %t888, ptr %t886, i64 %t887, i1 false)
  %t889 = insertvalue { i64, ptr } undef, i64 %t885, 0
  %t890 = insertvalue { i64, ptr } %t889, ptr %t888, 1
  %t893 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s32, ptr %s32, ptr %t852, { i64, ptr } %t890)
  store { i64, ptr } %t893, ptr %l329
  br label %bb114
bb114:
  %t894 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d453, i32 0, i32 1) }, 1
  %t895 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d453, i32 0, i32 1) }, 0
  %t896 = load { i64, ptr }, ptr %l322, !tbaa !27
  %t897 = extractvalue { i64, ptr } %t896, 1
  %t898 = extractvalue { i64, ptr } %t896, 0
  %t899 = add i64 %t895, %t898
  %t900 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d454, i32 0, i32 1) }, 1
  %t901 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d454, i32 0, i32 1) }, 0
  %t902 = add i64 %t899, %t901
  %t903 = load { i64, ptr }, ptr %l329, !tbaa !27
  %t904 = extractvalue { i64, ptr } %t903, 1
  %t905 = extractvalue { i64, ptr } %t903, 0
  %t906 = add i64 %t902, %t905
  %t907 = call ptr @__olang_scope_alloc(ptr %s32, i64 %t906)
  call void @olang_textcopy(ptr %t907, ptr %t894, i64 %t895)
  %t908 = getelementptr i8, ptr %t907, i64 %t895
  call void @olang_textcopy(ptr %t908, ptr %t897, i64 %t898)
  %t909 = getelementptr i8, ptr %t908, i64 %t898
  call void @olang_textcopy(ptr %t909, ptr %t900, i64 %t901)
  %t910 = getelementptr i8, ptr %t909, i64 %t901
  call void @olang_textcopy(ptr %t910, ptr %t904, i64 %t905)
  %t911 = insertvalue { i64, ptr } undef, i64 %t906, 0
  %t912 = insertvalue { i64, ptr } %t911, ptr %t907, 1
  %t914 = extractvalue { i64, ptr } %t912, 0
  %t915 = extractvalue { i64, ptr } %t912, 1
  %t916 = mul i64 %t914, 1
  %t917 = call ptr @__olang_scope_alloc(ptr %s32, i64 %t916)
  call void @llvm.memcpy.p0.p0.i64(ptr %t917, ptr %t915, i64 %t916, i1 false)
  %t918 = insertvalue { i64, ptr } undef, i64 %t914, 0
  %t919 = insertvalue { i64, ptr } %t918, ptr %t917, 1
  %t920 = load ptr, ptr %l321, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s32, ptr %t920, { i64, ptr } %t919)
  br label %bb115
bb115:
  call void @__olang_scope_close(ptr %s32)
  br label %bb116
bb116:
  %t922 = load i64, ptr %l44, !tbaa !24
  %t924 = add i64 %t922, 1
  store i64 %t924, ptr %l44, !tbaa !24
  br label %bb106
bb117:
  br label %bb118
bb118:
  %t926 = load ptr, ptr %l0, !tbaa !29
  store ptr %t926, ptr %l334, !tbaa !29
  %t927 = load ptr, ptr %l0, !tbaa !29
  store ptr %t927, ptr %l335, !tbaa !29
  %t928 = load ptr, ptr %l4, !tbaa !29
  %t929 = load i64, ptr %l7, !tbaa !24
  %t930 = load i32, ptr %l2, !tbaa !23
  %t934 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2egenBuf(ptr %v0, ptr %s28, ptr %t928, i64 %t929, i32 %t930)
  store { i64, ptr } %t934, ptr %l339
  br label %bb119
bb119:
  %t935 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d455, i32 0, i32 1) }, 1
  %t936 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d455, i32 0, i32 1) }, 0
  %t937 = load { i64, ptr }, ptr %l339, !tbaa !27
  %t938 = extractvalue { i64, ptr } %t937, 1
  %t939 = extractvalue { i64, ptr } %t937, 0
  %t940 = add i64 %t936, %t939
  %t941 = call ptr @__olang_scope_alloc(ptr %s28, i64 %t940)
  call void @olang_textcopy(ptr %t941, ptr %t935, i64 %t936)
  %t942 = getelementptr i8, ptr %t941, i64 %t936
  call void @olang_textcopy(ptr %t942, ptr %t938, i64 %t939)
  %t943 = insertvalue { i64, ptr } undef, i64 %t940, 0
  %t944 = insertvalue { i64, ptr } %t943, ptr %t941, 1
  %t946 = extractvalue { i64, ptr } %t944, 0
  %t947 = extractvalue { i64, ptr } %t944, 1
  %t948 = mul i64 %t946, 1
  %t949 = call ptr @__olang_scope_alloc(ptr %s28, i64 %t948)
  call void @llvm.memcpy.p0.p0.i64(ptr %t949, ptr %t947, i64 %t948, i1 false)
  %t950 = insertvalue { i64, ptr } undef, i64 %t946, 0
  %t951 = insertvalue { i64, ptr } %t950, ptr %t949, 1
  %t952 = load ptr, ptr %l335, !tbaa !29
  %t954 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %s28, ptr %s28, ptr %s28, ptr %s28, ptr %t952, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d456, i32 0, i32 1) }, { i64, ptr } %t951, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d223, i32 0, i32 1) })
  store { i64, ptr } %t954, ptr %l342
  br label %bb120
bb120:
  %t955 = load i64, ptr %l39, !tbaa !24
  %t956 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d457, i32 0, i32 1) }, 1
  %t957 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d457, i32 0, i32 1) }, 0
  %t958 = load { i64, ptr }, ptr %l342, !tbaa !27
  %t959 = extractvalue { i64, ptr } %t958, 1
  %t960 = extractvalue { i64, ptr } %t958, 0
  %t961 = add i64 %t957, %t960
  %t962 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d458, i32 0, i32 1) }, 1
  %t963 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d458, i32 0, i32 1) }, 0
  %t964 = add i64 %t961, %t963
  %t966 = call i64 @__olang_fmt_i64(ptr null, i64 %t955)
  %t967 = add i64 %t964, %t966
  %t968 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d459, i32 0, i32 1) }, 1
  %t969 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d459, i32 0, i32 1) }, 0
  %t970 = add i64 %t967, %t969
  %t971 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t970)
  call void @olang_textcopy(ptr %t971, ptr %t956, i64 %t957)
  %t972 = getelementptr i8, ptr %t971, i64 %t957
  call void @olang_textcopy(ptr %t972, ptr %t959, i64 %t960)
  %t973 = getelementptr i8, ptr %t972, i64 %t960
  call void @olang_textcopy(ptr %t973, ptr %t962, i64 %t963)
  %t974 = getelementptr i8, ptr %t973, i64 %t963
  %t975 = call i64 @__olang_fmt_i64(ptr %t974, i64 %t955)
  %t976 = getelementptr i8, ptr %t974, i64 %t966
  call void @olang_textcopy(ptr %t976, ptr %t968, i64 %t969)
  %t977 = insertvalue { i64, ptr } undef, i64 %t970, 0
  %t978 = insertvalue { i64, ptr } %t977, ptr %t971, 1
  %t980 = extractvalue { i64, ptr } %t978, 0
  %t981 = extractvalue { i64, ptr } %t978, 1
  %t982 = mul i64 %t980, 1
  %t983 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t982)
  call void @llvm.memcpy.p0.p0.i64(ptr %t983, ptr %t981, i64 %t982, i1 false)
  %t984 = insertvalue { i64, ptr } undef, i64 %t980, 0
  %t985 = insertvalue { i64, ptr } %t984, ptr %t983, 1
  %t986 = load ptr, ptr %l334, !tbaa !29
  %t988 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t986, { i64, ptr } %t985)
  store { i64, ptr } %t988, ptr %l346
  br label %bb121
bb121:
  %t989 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t990 = extractvalue { i64, ptr } %t989, 0
  %t991 = load { i64, ptr }, ptr %l346, !tbaa !27
  %t992 = extractvalue { i64, ptr } %t991, 0
  store i64 %t992, ptr %l348, !tbaa !24
  %t994 = load i64, ptr %l348, !tbaa !24
  %t995 = icmp eq i64 %t990, %t994
  br i1 %t995, label %bb122, label %bb123
bb122:
  %t997 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t998 = load ptr, ptr %t997, !tbaa !27
  %t999 = getelementptr { i64, ptr }, ptr %l346, i32 0, i32 1
  %t1000 = load ptr, ptr %t999, !tbaa !27
  %t1001 = load i64, ptr %l348, !tbaa !24
  %t1002 = mul i64 %t1001, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t998, ptr %t1000, i64 %t1002, i1 false)
  br label %bb124
bb123:
  %t1003 = load { i64, ptr }, ptr %l346, !tbaa !27
  store { i64, ptr } %t1003, ptr %l38, !tbaa !27
  br label %bb124
bb124:
  call void @__olang_scope_close(ptr %s28)
  br label %bb125
bb125:
  %t1004 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %s0, ptr %t1004, { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d460, i32 0, i32 1) })
  br label %bb126
bb126:
  %t1006 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1006, ptr %l351, !tbaa !29
  %t1007 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t1007, ptr %l352, !tbaa !27
  %t1008 = load ptr, ptr %l4, !tbaa !29
  %t1009 = load i32, ptr %l2, !tbaa !23
  %t1012 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2egenDropFn(ptr %v0, ptr %v0, ptr %t1008, i32 %t1009)
  store { i64, ptr } %t1012, ptr %l355
  br label %bb127
bb127:
  %t1013 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t1014 = load i64, ptr %l28, !tbaa !24
  %t1015 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t1016 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t1017 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d461, i32 0, i32 1) }, 1
  %t1018 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d461, i32 0, i32 1) }, 0
  %t1019 = load { i64, ptr }, ptr %l352, !tbaa !27
  %t1020 = extractvalue { i64, ptr } %t1019, 1
  %t1021 = extractvalue { i64, ptr } %t1019, 0
  %t1022 = add i64 %t1018, %t1021
  %t1023 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d462, i32 0, i32 1) }, 1
  %t1024 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d462, i32 0, i32 1) }, 0
  %t1025 = add i64 %t1022, %t1024
  %t1026 = load { i64, ptr }, ptr %l355, !tbaa !27
  %t1027 = extractvalue { i64, ptr } %t1026, 1
  %t1028 = extractvalue { i64, ptr } %t1026, 0
  %t1029 = add i64 %t1025, %t1028
  %t1030 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d463, i32 0, i32 1) }, 1
  %t1031 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d463, i32 0, i32 1) }, 0
  %t1032 = add i64 %t1029, %t1031
  %t1034 = extractvalue { i64, ptr } %t1013, 1
  %t1035 = extractvalue { i64, ptr } %t1013, 0
  %t1036 = add i64 %t1032, %t1035
  %t1037 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d464, i32 0, i32 1) }, 1
  %t1038 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d464, i32 0, i32 1) }, 0
  %t1039 = add i64 %t1036, %t1038
  %t1041 = call i64 @__olang_fmt_i64(ptr null, i64 %t1014)
  %t1042 = add i64 %t1039, %t1041
  %t1043 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d463, i32 0, i32 1) }, 1
  %t1044 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d463, i32 0, i32 1) }, 0
  %t1045 = add i64 %t1042, %t1044
  %t1047 = extractvalue { i64, ptr } %t1015, 1
  %t1048 = extractvalue { i64, ptr } %t1015, 0
  %t1049 = add i64 %t1045, %t1048
  %t1050 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d464, i32 0, i32 1) }, 1
  %t1051 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d464, i32 0, i32 1) }, 0
  %t1052 = add i64 %t1049, %t1051
  %t1054 = extractvalue { i64, ptr } %t1016, 1
  %t1055 = extractvalue { i64, ptr } %t1016, 0
  %t1056 = add i64 %t1052, %t1055
  %t1057 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d465, i32 0, i32 1) }, 1
  %t1058 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d465, i32 0, i32 1) }, 0
  %t1059 = add i64 %t1056, %t1058
  %t1060 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1059)
  call void @olang_textcopy(ptr %t1060, ptr %t1017, i64 %t1018)
  %t1061 = getelementptr i8, ptr %t1060, i64 %t1018
  call void @olang_textcopy(ptr %t1061, ptr %t1020, i64 %t1021)
  %t1062 = getelementptr i8, ptr %t1061, i64 %t1021
  call void @olang_textcopy(ptr %t1062, ptr %t1023, i64 %t1024)
  %t1063 = getelementptr i8, ptr %t1062, i64 %t1024
  call void @olang_textcopy(ptr %t1063, ptr %t1027, i64 %t1028)
  %t1064 = getelementptr i8, ptr %t1063, i64 %t1028
  call void @olang_textcopy(ptr %t1064, ptr %t1030, i64 %t1031)
  %t1065 = getelementptr i8, ptr %t1064, i64 %t1031
  call void @olang_textcopy(ptr %t1065, ptr %t1034, i64 %t1035)
  %t1066 = getelementptr i8, ptr %t1065, i64 %t1035
  call void @olang_textcopy(ptr %t1066, ptr %t1037, i64 %t1038)
  %t1067 = getelementptr i8, ptr %t1066, i64 %t1038
  %t1068 = call i64 @__olang_fmt_i64(ptr %t1067, i64 %t1014)
  %t1069 = getelementptr i8, ptr %t1067, i64 %t1041
  call void @olang_textcopy(ptr %t1069, ptr %t1043, i64 %t1044)
  %t1070 = getelementptr i8, ptr %t1069, i64 %t1044
  call void @olang_textcopy(ptr %t1070, ptr %t1047, i64 %t1048)
  %t1071 = getelementptr i8, ptr %t1070, i64 %t1048
  call void @olang_textcopy(ptr %t1071, ptr %t1050, i64 %t1051)
  %t1072 = getelementptr i8, ptr %t1071, i64 %t1051
  call void @olang_textcopy(ptr %t1072, ptr %t1054, i64 %t1055)
  %t1073 = getelementptr i8, ptr %t1072, i64 %t1055
  call void @olang_textcopy(ptr %t1073, ptr %t1057, i64 %t1058)
  %t1074 = insertvalue { i64, ptr } undef, i64 %t1059, 0
  %t1075 = insertvalue { i64, ptr } %t1074, ptr %t1060, 1
  %t1077 = extractvalue { i64, ptr } %t1075, 0
  %t1078 = extractvalue { i64, ptr } %t1075, 1
  %t1079 = mul i64 %t1077, 1
  %t1080 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1079)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1080, ptr %t1078, i64 %t1079, i1 false)
  %t1081 = insertvalue { i64, ptr } undef, i64 %t1077, 0
  %t1082 = insertvalue { i64, ptr } %t1081, ptr %t1080, 1
  %t1083 = load ptr, ptr %l351, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s0, ptr %t1083, { i64, ptr } %t1082)
  br label %bb128
bb128:
  %t1085 = load ptr, ptr %l0, !tbaa !29
  %t1086 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t1087 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d466, i32 0, i32 1) }, 1
  %t1088 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d466, i32 0, i32 1) }, 0
  %t1090 = extractvalue { i64, ptr } %t1086, 1
  %t1091 = extractvalue { i64, ptr } %t1086, 0
  %t1092 = add i64 %t1088, %t1091
  %t1093 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1092)
  call void @olang_textcopy(ptr %t1093, ptr %t1087, i64 %t1088)
  %t1094 = getelementptr i8, ptr %t1093, i64 %t1088
  call void @olang_textcopy(ptr %t1094, ptr %t1090, i64 %t1091)
  %t1095 = insertvalue { i64, ptr } undef, i64 %t1092, 0
  %t1096 = insertvalue { i64, ptr } %t1095, ptr %t1093, 1
  %t1098 = extractvalue { i64, ptr } %t1096, 0
  %t1099 = extractvalue { i64, ptr } %t1096, 1
  %t1100 = mul i64 %t1098, 1
  %t1101 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1100)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1101, ptr %t1099, i64 %t1100, i1 false)
  %t1102 = insertvalue { i64, ptr } undef, i64 %t1098, 0
  %t1103 = insertvalue { i64, ptr } %t1102, ptr %t1101, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s0, ptr %t1085, { i64, ptr } %t1103)
  br label %bb129
bb129:
  %t1106 = load ptr, ptr %l0, !tbaa !29
  %t1107 = load { i64, ptr }, ptr %l13, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2elabel(ptr %v0, ptr %s0, ptr %t1106, { i64, ptr } %t1107)
  br label %bb130
bb130:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3afnEm_2esuspend(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1, i32 %a2, %"compiler/mir:Range" %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [4 x i64] }
  %l3 = alloca %"compiler/mir:Range"
  %l6 = alloca { i64, ptr }
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca i32
  %l14 = alloca i32
  %l16 = alloca { i64, [1 x i64] }
  %l17 = alloca i32
  %l18 = alloca i64
  %l19 = alloca ptr
  %l20 = alloca i64
  %l22 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l36 = alloca ptr
  %l42 = alloca { i64, ptr }
  %l44 = alloca { i64, ptr }
  %l51 = alloca ptr
  %l52 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %l61 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  %l68 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l73 = alloca i32
  %l76 = alloca i32
  %l102 = alloca { i64, [1 x i64] }
  %l111 = alloca i1
  %l113 = alloca i1
  %l117 = alloca i1
  %l119 = alloca i1
  %l124 = alloca %"compiler/mir:ScopeInfo"
  %l136 = alloca i64
  %l138 = alloca i64
  %l143 = alloca i64
  %l151 = alloca { i64, ptr }
  %l153 = alloca { i64, ptr }
  %l155 = alloca { i64, ptr }
  %l166 = alloca ptr
  %l168 = alloca { i64, ptr }
  %l175 = alloca ptr
  %l177 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, [4 x i64] } %a1, ptr %l1
  store %"compiler/mir:Range" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/emit:Emitter", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/emit:fnEm", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = getelementptr %"compiler/mir:Fn", ptr %t13, i32 0, i32 1
  %t16 = load i32, ptr %t15, !tbaa !23
  %t18 = inttoptr i64 0 to ptr
  %t21 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRetLlvm(ptr %v0, ptr %s0, ptr %t18, ptr %t7, i32 %t16)
  store { i64, ptr } %t21, ptr %l33
  br label %bb1
bb1:
  %t22 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t22, ptr %l6, !tbaa !27
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/emit:fnEm", ptr %t23, i32 0, i32 11
  %t26 = load i1, ptr %t25, !tbaa !21
  br i1 %t26, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t28 = load ptr, ptr %l0, !tbaa !29
  store ptr %t28, ptr %l36, !tbaa !29
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/emit:fnEm", ptr %t30, i32 0, i32 29
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !27
  %t34 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d467, i32 0, i32 1) }, 1
  %t35 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d467, i32 0, i32 1) }, 0
  %t37 = extractvalue { i64, ptr } %t33, 1
  %t38 = extractvalue { i64, ptr } %t33, 0
  %t39 = add i64 %t35, %t38
  %t40 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d468, i32 0, i32 1) }, 1
  %t41 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d468, i32 0, i32 1) }, 0
  %t42 = add i64 %t39, %t41
  %t43 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t42)
  call void @olang_textcopy(ptr %t43, ptr %t34, i64 %t35)
  %t44 = getelementptr i8, ptr %t43, i64 %t35
  call void @olang_textcopy(ptr %t44, ptr %t37, i64 %t38)
  %t45 = getelementptr i8, ptr %t44, i64 %t38
  call void @olang_textcopy(ptr %t45, ptr %t40, i64 %t41)
  %t46 = insertvalue { i64, ptr } undef, i64 %t42, 0
  %t47 = insertvalue { i64, ptr } %t46, ptr %t43, 1
  %t49 = extractvalue { i64, ptr } %t47, 0
  %t50 = extractvalue { i64, ptr } %t47, 1
  %t51 = mul i64 %t49, 1
  %t52 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t51)
  call void @llvm.memcpy.p0.p0.i64(ptr %t52, ptr %t50, i64 %t51, i1 false)
  %t53 = insertvalue { i64, ptr } undef, i64 %t49, 0
  %t54 = insertvalue { i64, ptr } %t53, ptr %t52, 1
  %t57 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s1, ptr %s1, ptr %t29, { i64, ptr } %t54)
  store { i64, ptr } %t57, ptr %l42
  br label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s3
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l51, !tbaa !29
  %t59 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t59, ptr %l52, !tbaa !27
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/emit:fnEm", ptr %t61, i32 0, i32 9
  %t64 = load i32, ptr %t63, !tbaa !23
  %t67 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s3, ptr %t60, i32 %t64)
  store { i64, ptr } %t67, ptr %l56
  br label %bb8
bb4:
  %t68 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t68, 0
  %t70 = extractvalue { i64, ptr } %t68, 1
  %t71 = mul i64 %t69, 1
  %t72 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t71)
  call void @llvm.memcpy.p0.p0.i64(ptr %t72, ptr %t70, i64 %t71, i1 false)
  %t73 = insertvalue { i64, ptr } undef, i64 %t69, 0
  %t74 = insertvalue { i64, ptr } %t73, ptr %t72, 1
  %t75 = load ptr, ptr %l36, !tbaa !29
  %t77 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %s1, ptr %s1, ptr %s1, ptr %s1, ptr %t75, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d469, i32 0, i32 1) }, { i64, ptr } %t74, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d223, i32 0, i32 1) })
  store { i64, ptr } %t77, ptr %l44
  br label %bb5
bb5:
  %t78 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/emit:fnEm", ptr %t81, i32 0, i32 9
  %t84 = load i32, ptr %t83, !tbaa !23
  %t85 = load { i64, [4 x i64] }, ptr %l1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2eput(ptr %v0, ptr %s1, ptr %s1, ptr %t79, { i64, ptr } %t78, i32 %t84, { i64, [4 x i64] } %t85, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d470, i32 0, i32 1) })
  br label %bb6
bb6:
  %t90 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s1, ptr %s1, ptr %s1, ptr %s1, ptr %t90, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d471, i32 0, i32 1) }, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d472, i32 0, i32 1) }, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d473, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d220, i32 0, i32 1) })
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s1)
  br label %bb12
bb8:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t93 = load { i64, [4 x i64] }, ptr %l1
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/emit:fnEm", ptr %t94, i32 0, i32 9
  %t97 = load i32, ptr %t96, !tbaa !23
  %t101 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s3, ptr %t92, { i64, [4 x i64] } %t93, i32 %t97)
  store { i64, ptr } %t101, ptr %l61
  br label %bb9
bb9:
  %t102 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d474, i32 0, i32 1) }, 1
  %t103 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d474, i32 0, i32 1) }, 0
  %t104 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t105 = extractvalue { i64, ptr } %t104, 1
  %t106 = extractvalue { i64, ptr } %t104, 0
  %t107 = add i64 %t103, %t106
  %t108 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d475, i32 0, i32 1) }, 1
  %t109 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d475, i32 0, i32 1) }, 0
  %t110 = add i64 %t107, %t109
  %t111 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t112 = extractvalue { i64, ptr } %t111, 1
  %t113 = extractvalue { i64, ptr } %t111, 0
  %t114 = add i64 %t110, %t113
  %t115 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d476, i32 0, i32 1) }, 1
  %t116 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d476, i32 0, i32 1) }, 0
  %t117 = add i64 %t114, %t116
  %t118 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t119 = extractvalue { i64, ptr } %t118, 1
  %t120 = extractvalue { i64, ptr } %t118, 0
  %t121 = add i64 %t117, %t120
  %t122 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d477, i32 0, i32 1) }, 1
  %t123 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d477, i32 0, i32 1) }, 0
  %t124 = add i64 %t121, %t123
  %t125 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t124)
  call void @olang_textcopy(ptr %t125, ptr %t102, i64 %t103)
  %t126 = getelementptr i8, ptr %t125, i64 %t103
  call void @olang_textcopy(ptr %t126, ptr %t105, i64 %t106)
  %t127 = getelementptr i8, ptr %t126, i64 %t106
  call void @olang_textcopy(ptr %t127, ptr %t108, i64 %t109)
  %t128 = getelementptr i8, ptr %t127, i64 %t109
  call void @olang_textcopy(ptr %t128, ptr %t112, i64 %t113)
  %t129 = getelementptr i8, ptr %t128, i64 %t113
  call void @olang_textcopy(ptr %t129, ptr %t115, i64 %t116)
  %t130 = getelementptr i8, ptr %t129, i64 %t116
  call void @olang_textcopy(ptr %t130, ptr %t119, i64 %t120)
  %t131 = getelementptr i8, ptr %t130, i64 %t120
  call void @olang_textcopy(ptr %t131, ptr %t122, i64 %t123)
  %t132 = insertvalue { i64, ptr } undef, i64 %t124, 0
  %t133 = insertvalue { i64, ptr } %t132, ptr %t125, 1
  %t135 = extractvalue { i64, ptr } %t133, 0
  %t136 = extractvalue { i64, ptr } %t133, 1
  %t137 = mul i64 %t135, 1
  %t138 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t137)
  call void @llvm.memcpy.p0.p0.i64(ptr %t138, ptr %t136, i64 %t137, i1 false)
  %t139 = insertvalue { i64, ptr } undef, i64 %t135, 0
  %t140 = insertvalue { i64, ptr } %t139, ptr %t138, 1
  %t141 = load ptr, ptr %l51, !tbaa !29
  %t143 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s3, ptr %s3, ptr %t141, { i64, ptr } %t140)
  store { i64, ptr } %t143, ptr %l64
  br label %bb10
bb10:
  %t144 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t146 = load { i64, ptr }, ptr %l6, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s0, ptr %s3, ptr %s3, ptr %s3, ptr %t145, { i64, ptr } %t146, { i64, ptr } %t144, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d478, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d220, i32 0, i32 1) })
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s3)
  br label %bb12
bb12:
  %t151 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t151, ptr %l68
  br label %bb13
bb13:
  %t152 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l68
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t152, ptr %l9
  store i32 0, ptr %l10, !tbaa !23
  %t153 = getelementptr %"compiler/mir:Range", ptr %l3, i32 0, i32 1
  %t154 = load i32, ptr %t153, !tbaa !23
  store i32 %t154, ptr %l11, !tbaa !23
  store i32 1, ptr %l12, !tbaa !23
  %t156 = load i32, ptr %l11, !tbaa !23
  %t157 = load i32, ptr %l10, !tbaa !23
  %t160 = icmp sgt i32 %t156, %t157
  br i1 %t160, label %bb14, label %bb15
bb14:
  %t162 = load i32, ptr %l12, !tbaa !23
  %t164 = icmp sgt i32 %t162, 0
  br i1 %t164, label %bb16, label %bb17
bb15:
  store i32 0, ptr %l73, !tbaa !23
  br label %bb19
bb16:
  %t166 = load i32, ptr %l11, !tbaa !23
  %t167 = load i32, ptr %l10, !tbaa !23
  %t170 = sub i32 %t166, %t167
  %t171 = load i32, ptr %l12, !tbaa !23
  %t174 = add i32 %t170, %t171
  %t176 = sub i32 %t174, 1
  %t177 = load i32, ptr %l12, !tbaa !23
  %t180 = sdiv i32 %t176, %t177
  store i32 %t180, ptr %l76, !tbaa !23
  br label %bb18
bb17:
  store i32 0, ptr %l76, !tbaa !23
  br label %bb18
bb18:
  %t182 = load i32, ptr %l76, !tbaa !23
  store i32 %t182, ptr %l73, !tbaa !23
  br label %bb19
bb19:
  %t183 = load i32, ptr %l73, !tbaa !23
  store i32 %t183, ptr %l13, !tbaa !23
  store i32 0, ptr %l14, !tbaa !23
  br label %bb20
bb20:
  %t184 = load i32, ptr %l14, !tbaa !23
  %t185 = load i32, ptr %l13, !tbaa !23
  %t188 = icmp slt i32 %t184, %t185
  %t190 = xor i1 %t188, true
  br i1 %t190, label %bb21, label %bb22
bb21:
  br label %bb48
bb22:
  br label %bb23
bb23:
  %t192 = load i32, ptr %l10, !tbaa !23
  %t193 = load i32, ptr %l14, !tbaa !23
  %t194 = load i32, ptr %l12, !tbaa !23
  %t197 = mul i32 %t193, %t194
  %t200 = add i32 %t192, %t197
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t204 = getelementptr %"compiler/emit:fnEm", ptr %t202, i32 0, i32 1
  %t205 = load ptr, ptr %t204, !tbaa !29
  %t207 = getelementptr %"compiler/mir:Fn", ptr %t205, i32 0, i32 12
  %t208 = getelementptr %"compiler/mir:Range", ptr %l3, i32 0, i32 0
  %t209 = load i32, ptr %t208, !tbaa !23
  %t211 = sext i32 %t209 to i64
  %t214 = sext i32 %t200 to i64
  %t217 = add i64 %t211, %t214
  %t220 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e_2eAt_3ccompiler_2fmir_3aScopeRef_3e(ptr %v0, ptr %t207, i64 %t217)
  store { i64, [1 x i64] } %t220, ptr %l102
  br label %bb24
bb24:
  %t221 = load { i64, [1 x i64] }, ptr %l102
  store { i64, [1 x i64] } %t221, ptr %l16
  %t222 = load { i64, [1 x i64] }, ptr %l16
  %t224 = extractvalue { i64, [1 x i64] } %t222, 0
  %t225 = icmp eq i64 %t224, 0
  br i1 %t225, label %bb25, label %bb26
bb25:
  %t227 = getelementptr { i64, [1 x i64] }, ptr %l16, i32 0, i32 1
  %t228 = getelementptr { i32 }, ptr %t227, i32 0, i32 0
  %t229 = load i32, ptr %t228
  store i32 %t229, ptr %l17, !tbaa !23
  br label %bb27
bb26:
  br label %bb41
bb27:
  %t231 = load i32, ptr %l17, !tbaa !23
  %t233 = sext i32 %t231 to i64
  store i64 %t233, ptr %l18, !tbaa !24
  %t235 = load ptr, ptr %l0, !tbaa !29
  %t237 = getelementptr %"compiler/emit:fnEm", ptr %t235, i32 0, i32 25
  %t238 = load i64, ptr %l18, !tbaa !24
  %t241 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t237, i64 %t238)
  store i1 %t241, ptr %l111
  br label %bb28
bb28:
  %t242 = load i1, ptr %l111, !tbaa !21
  %t243 = xor i1 %t242, true
  br i1 %t243, label %bb29, label %bb30
bb29:
  %t245 = load ptr, ptr %l0, !tbaa !29
  %t247 = getelementptr %"compiler/emit:fnEm", ptr %t245, i32 0, i32 24
  %t248 = load i64, ptr %l18, !tbaa !24
  %t251 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t247, i64 %t248)
  store i1 %t251, ptr %l117
  br label %bb31
bb30:
  store i1 false, ptr %l113, !tbaa !21
  br label %bb32
bb31:
  %t252 = load i1, ptr %l117, !tbaa !21
  %t253 = xor i1 %t252, true
  store i1 %t253, ptr %l113, !tbaa !21
  br label %bb32
bb32:
  %t255 = load i1, ptr %l113, !tbaa !21
  br i1 %t255, label %bb33, label %bb34
bb33:
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t258 = getelementptr %"compiler/emit:fnEm", ptr %t256, i32 0, i32 1
  %t259 = load ptr, ptr %t258, !tbaa !29
  %t261 = getelementptr %"compiler/mir:Fn", ptr %t259, i32 0, i32 8
  %t262 = load i64, ptr %l18, !tbaa !24
  %t265 = call %"compiler/mir:ScopeInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeInfo_3e_2eAt_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %t261, i64 %t262)
  store %"compiler/mir:ScopeInfo" %t265, ptr %l124
  br label %bb35
bb34:
  store i1 false, ptr %l119, !tbaa !21
  br label %bb36
bb35:
  %t266 = getelementptr %"compiler/mir:ScopeInfo", ptr %l124, i32 0, i32 0
  %t267 = load i32, ptr %t266, !range !{i32 0, i32 7}
  %t269 = trunc i64 6 to i32
  %t270 = icmp eq i32 %t267, %t269
  %t272 = xor i1 %t270, true
  store i1 %t272, ptr %l119, !tbaa !21
  br label %bb36
bb36:
  %t274 = load i1, ptr %l119, !tbaa !21
  br i1 %t274, label %bb37, label %bb38
bb37:
  %t275 = load i64, ptr %l18, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l9, i64 %t275)
  br label %bb39
bb38:
  br label %bb40
bb39:
  br label %bb40
bb40:
  br label %bb46
bb41:
  br i1 true, label %bb42, label %bb43
bb42:
  br label %bb44
bb43:
  br label %bb45
bb44:
  br label %bb46
bb45:
  call void @__olang_check_failed(ptr @olang_loc_97d51a883f8cc986_4828fb3e43690a82)
  unreachable
bb46:
  br label %bb47
bb47:
  %t278 = load i32, ptr %l14, !tbaa !23
  %t280 = add i32 %t278, 1
  store i32 %t280, ptr %l14, !tbaa !23
  br label %bb20
bb48:
  %t282 = load ptr, ptr %l0, !tbaa !29
  %t284 = getelementptr %"compiler/emit:fnEm", ptr %t282, i32 0, i32 0
  %t285 = load ptr, ptr %t284, !tbaa !29
  %t287 = getelementptr %"compiler/emit:Emitter", ptr %t285, i32 0, i32 4
  %t288 = load i1, ptr %t287, !tbaa !21
  br i1 %t288, label %bb49, label %bb50
bb49:
  store ptr %l9, ptr %l19, !tbaa !29
  store i64 0, ptr %l20, !tbaa !24
  br label %bb51
bb50:
  br label %bb60
bb51:
  %t291 = load i64, ptr %l20, !tbaa !24
  store i64 %t291, ptr %l136, !tbaa !24
  %t292 = load ptr, ptr %l19, !tbaa !29
  %t294 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t292)
  store i64 %t294, ptr %l138
  br label %bb52
bb52:
  %t295 = load i64, ptr %l136, !tbaa !24
  %t296 = load i64, ptr %l138, !tbaa !24
  %t297 = icmp slt i64 %t295, %t296
  %t299 = xor i1 %t297, true
  br i1 %t299, label %bb53, label %bb54
bb53:
  br label %bb59
bb54:
  br label %bb55
bb55:
  %t301 = load ptr, ptr %l19, !tbaa !29
  %t302 = load i64, ptr %l20, !tbaa !24
  %t305 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t301, i64 %t302)
  store i64 %t305, ptr %l143
  br label %bb56
bb56:
  %t306 = load i64, ptr %l143, !tbaa !24
  %t307 = load ptr, ptr %l0, !tbaa !29
  %t310 = trunc i64 %t306 to i32
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2eunwindPop(ptr %v0, ptr %t307, i32 %t310)
  br label %bb57
bb57:
  br label %bb58
bb58:
  %t314 = load i64, ptr %l20, !tbaa !24
  %t316 = add i64 %t314, 1
  store i64 %t316, ptr %l20, !tbaa !24
  br label %bb51
bb59:
  br label %bb60
bb60:
  %t318 = load ptr, ptr %l0, !tbaa !29
  %t320 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t318, { i64, ptr } { i64 48, ptr getelementptr inbounds (<{ i64, [48 x i8] }>, ptr @.d479, i32 0, i32 1) })
  store { i64, ptr } %t320, ptr %l151
  br label %bb61
bb61:
  %t321 = load { i64, ptr }, ptr %l151, !tbaa !27
  store { i64, ptr } %t321, ptr %l22, !tbaa !27
  %t322 = load ptr, ptr %l0, !tbaa !29
  %t324 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2efresh(ptr %v0, ptr %s0, ptr %s0, ptr %t322, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d480, i32 0, i32 1) })
  store { i64, ptr } %t324, ptr %l153
  br label %bb62
bb62:
  %t325 = load { i64, ptr }, ptr %l153, !tbaa !27
  store { i64, ptr } %t325, ptr %l23, !tbaa !27
  %t326 = load ptr, ptr %l0, !tbaa !29
  %t328 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2efresh(ptr %v0, ptr %s0, ptr %s0, ptr %t326, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d481, i32 0, i32 1) })
  store { i64, ptr } %t328, ptr %l155
  br label %bb63
bb63:
  %t329 = load { i64, ptr }, ptr %l155, !tbaa !27
  store { i64, ptr } %t329, ptr %l24, !tbaa !27
  %t330 = load ptr, ptr %l0, !tbaa !29
  %t331 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t332 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t333 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t334 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d482, i32 0, i32 1) }, 1
  %t335 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d482, i32 0, i32 1) }, 0
  %t337 = extractvalue { i64, ptr } %t331, 1
  %t338 = extractvalue { i64, ptr } %t331, 0
  %t339 = add i64 %t335, %t338
  %t340 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d483, i32 0, i32 1) }, 1
  %t341 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d483, i32 0, i32 1) }, 0
  %t342 = add i64 %t339, %t341
  %t344 = extractvalue { i64, ptr } %t332, 1
  %t345 = extractvalue { i64, ptr } %t332, 0
  %t346 = add i64 %t342, %t345
  %t347 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d484, i32 0, i32 1) }, 1
  %t348 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d484, i32 0, i32 1) }, 0
  %t349 = add i64 %t346, %t348
  %t351 = extractvalue { i64, ptr } %t333, 1
  %t352 = extractvalue { i64, ptr } %t333, 0
  %t353 = add i64 %t349, %t352
  %t354 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d485, i32 0, i32 1) }, 1
  %t355 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d485, i32 0, i32 1) }, 0
  %t356 = add i64 %t353, %t355
  %t357 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t356)
  call void @olang_textcopy(ptr %t357, ptr %t334, i64 %t335)
  %t358 = getelementptr i8, ptr %t357, i64 %t335
  call void @olang_textcopy(ptr %t358, ptr %t337, i64 %t338)
  %t359 = getelementptr i8, ptr %t358, i64 %t338
  call void @olang_textcopy(ptr %t359, ptr %t340, i64 %t341)
  %t360 = getelementptr i8, ptr %t359, i64 %t341
  call void @olang_textcopy(ptr %t360, ptr %t344, i64 %t345)
  %t361 = getelementptr i8, ptr %t360, i64 %t345
  call void @olang_textcopy(ptr %t361, ptr %t347, i64 %t348)
  %t362 = getelementptr i8, ptr %t361, i64 %t348
  call void @olang_textcopy(ptr %t362, ptr %t351, i64 %t352)
  %t363 = getelementptr i8, ptr %t362, i64 %t352
  call void @olang_textcopy(ptr %t363, ptr %t354, i64 %t355)
  %t364 = insertvalue { i64, ptr } undef, i64 %t356, 0
  %t365 = insertvalue { i64, ptr } %t364, ptr %t357, 1
  %t367 = extractvalue { i64, ptr } %t365, 0
  %t368 = extractvalue { i64, ptr } %t365, 1
  %t369 = mul i64 %t367, 1
  %t370 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t369)
  call void @llvm.memcpy.p0.p0.i64(ptr %t370, ptr %t368, i64 %t369, i1 false)
  %t371 = insertvalue { i64, ptr } undef, i64 %t367, 0
  %t372 = insertvalue { i64, ptr } %t371, ptr %t370, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s0, ptr %t330, { i64, ptr } %t372)
  br label %bb64
bb64:
  %t375 = load ptr, ptr %l0, !tbaa !29
  %t376 = load { i64, ptr }, ptr %l23, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2elabel(ptr %v0, ptr %s0, ptr %t375, { i64, ptr } %t376)
  br label %bb65
bb65:
  %t379 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2erehold(ptr %v0, ptr %s0, ptr %t379, ptr %l9)
  br label %bb66
bb66:
  %t382 = load ptr, ptr %l0, !tbaa !29
  store ptr %t382, ptr %l166, !tbaa !29
  %t385 = call { i64, ptr } @compiler_2femit_2eblockName(ptr %s0, i32 %a2)
  store { i64, ptr } %t385, ptr %l168
  br label %bb67
bb67:
  %t386 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d486, i32 0, i32 1) }, 1
  %t387 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d486, i32 0, i32 1) }, 0
  %t388 = load { i64, ptr }, ptr %l168, !tbaa !27
  %t389 = extractvalue { i64, ptr } %t388, 1
  %t390 = extractvalue { i64, ptr } %t388, 0
  %t391 = add i64 %t387, %t390
  %t392 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t391)
  call void @olang_textcopy(ptr %t392, ptr %t386, i64 %t387)
  %t393 = getelementptr i8, ptr %t392, i64 %t387
  call void @olang_textcopy(ptr %t393, ptr %t389, i64 %t390)
  %t394 = insertvalue { i64, ptr } undef, i64 %t391, 0
  %t395 = insertvalue { i64, ptr } %t394, ptr %t392, 1
  %t397 = extractvalue { i64, ptr } %t395, 0
  %t398 = extractvalue { i64, ptr } %t395, 1
  %t399 = mul i64 %t397, 1
  %t400 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t399)
  call void @llvm.memcpy.p0.p0.i64(ptr %t400, ptr %t398, i64 %t399, i1 false)
  %t401 = insertvalue { i64, ptr } undef, i64 %t397, 0
  %t402 = insertvalue { i64, ptr } %t401, ptr %t400, 1
  %t403 = load ptr, ptr %l166, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s0, ptr %t403, { i64, ptr } %t402)
  br label %bb68
bb68:
  %t405 = load ptr, ptr %l0, !tbaa !29
  %t406 = load { i64, ptr }, ptr %l24, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2elabel(ptr %v0, ptr %s0, ptr %t405, { i64, ptr } %t406)
  br label %bb69
bb69:
  %t409 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2erehold(ptr %v0, ptr %s0, ptr %t409, ptr %l9)
  br label %bb70
bb70:
  %t412 = load ptr, ptr %l0, !tbaa !29
  store ptr %t412, ptr %l175, !tbaa !29
  %t415 = call { i64, ptr } @compiler_2femit_2eblockName(ptr %s0, i32 %a4)
  store { i64, ptr } %t415, ptr %l177
  br label %bb71
bb71:
  %t416 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d487, i32 0, i32 1) }, 1
  %t417 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d487, i32 0, i32 1) }, 0
  %t418 = load { i64, ptr }, ptr %l177, !tbaa !27
  %t419 = extractvalue { i64, ptr } %t418, 1
  %t420 = extractvalue { i64, ptr } %t418, 0
  %t421 = add i64 %t417, %t420
  %t422 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t421)
  call void @olang_textcopy(ptr %t422, ptr %t416, i64 %t417)
  %t423 = getelementptr i8, ptr %t422, i64 %t417
  call void @olang_textcopy(ptr %t423, ptr %t419, i64 %t420)
  %t424 = insertvalue { i64, ptr } undef, i64 %t421, 0
  %t425 = insertvalue { i64, ptr } %t424, ptr %t422, 1
  %t427 = extractvalue { i64, ptr } %t425, 0
  %t428 = extractvalue { i64, ptr } %t425, 1
  %t429 = mul i64 %t427, 1
  %t430 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t429)
  call void @llvm.memcpy.p0.p0.i64(ptr %t430, ptr %t428, i64 %t429, i1 false)
  %t431 = insertvalue { i64, ptr } undef, i64 %t427, 0
  %t432 = insertvalue { i64, ptr } %t431, ptr %t430, 1
  %t433 = load ptr, ptr %l175, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s0, ptr %t433, { i64, ptr } %t432)
  br label %bb72
bb72:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2etailCopies(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i1
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca { i64, ptr }
  %l23 = alloca i64
  %l27 = alloca i64
  %l30 = alloca i64
  %l52 = alloca %"compiler/mir:BasicBlock"
  %l59 = alloca { i64, ptr }
  %l60 = alloca { i64, ptr }
  %l61 = alloca i64
  %l62 = alloca { i64, ptr }
  %l66 = alloca i64
  %l70 = alloca i64
  %l73 = alloca i64
  %l95 = alloca i1
  %l100 = alloca { i64, [1 x i64] }
  %l107 = alloca { i64, ptr }
  %l108 = alloca { i64, ptr }
  %l109 = alloca i64
  %l110 = alloca { i64, ptr }
  %s3 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 28
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d488, i32 0, i32 1) }, ptr %l16, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t6, ptr %l17, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t7, 0
  store i64 %t8, ptr %l18, !tbaa !24
  %t9 = load i64, ptr %l18, !tbaa !24
  %t10 = mul i64 %t9, 1
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  %t12 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t13 = insertvalue { i64, ptr } %t12, ptr %t11, 1
  store { i64, ptr } %t13, ptr %l19, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = load i64, ptr %l18, !tbaa !24
  %t19 = mul i64 %t18, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t15, ptr %t17, i64 %t19, i1 false)
  %t20 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t20, ptr %l17, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t21, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  store i1 false, ptr %l1, !tbaa !21
  store i64 0, ptr %l2, !tbaa !24
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/emit:fnEm", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/mir:Fn", ptr %t25, i32 0, i32 9
  %t29 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eLen_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, ptr %t27)
  store i64 %t29, ptr %l23
  br label %bb4
bb4:
  %t30 = load i64, ptr %l23, !tbaa !24
  store i64 %t30, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t31 = load i64, ptr %l3, !tbaa !24
  %t32 = load i64, ptr %l2, !tbaa !24
  %t35 = icmp sgt i64 %t31, %t32
  br i1 %t35, label %bb5, label %bb6
bb5:
  %t37 = load i64, ptr %l4, !tbaa !24
  %t39 = icmp sgt i64 %t37, 0
  br i1 %t39, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l27, !tbaa !24
  br label %bb10
bb7:
  %t41 = load i64, ptr %l3, !tbaa !24
  %t42 = load i64, ptr %l2, !tbaa !24
  %t45 = sub i64 %t41, %t42
  %t46 = load i64, ptr %l4, !tbaa !24
  %t49 = add i64 %t45, %t46
  %t51 = sub i64 %t49, 1
  %t52 = load i64, ptr %l4, !tbaa !24
  %t55 = sdiv i64 %t51, %t52
  store i64 %t55, ptr %l30, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l30, !tbaa !24
  br label %bb9
bb9:
  %t57 = load i64, ptr %l30, !tbaa !24
  store i64 %t57, ptr %l27, !tbaa !24
  br label %bb10
bb10:
  %t58 = load i64, ptr %l27, !tbaa !24
  store i64 %t58, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s3
  %t59 = load i64, ptr %l6, !tbaa !24
  %t60 = load i64, ptr %l5, !tbaa !24
  %t63 = icmp slt i64 %t59, %t60
  %t65 = xor i1 %t63, true
  br i1 %t65, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s3)
  br label %bb20
bb13:
  br label %bb14
bb14:
  %t67 = load i64, ptr %l2, !tbaa !24
  %t68 = load i64, ptr %l6, !tbaa !24
  %t69 = load i64, ptr %l4, !tbaa !24
  %t72 = mul i64 %t68, %t69
  %t75 = add i64 %t67, %t72
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/emit:fnEm", ptr %t77, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t82 = getelementptr %"compiler/mir:Fn", ptr %t80, i32 0, i32 9
  %t86 = call %"compiler/mir:BasicBlock" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eAt_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, ptr %s3, ptr %t82, i64 %t75)
  store %"compiler/mir:BasicBlock" %t86, ptr %l52
  br label %bb15
bb15:
  %t87 = getelementptr %"compiler/mir:BasicBlock", ptr %l52, i32 0, i32 1
  %t88 = load { i64, [8 x i64] }, ptr %t87
  %t90 = extractvalue { i64, [8 x i64] } %t88, 0
  %t91 = icmp eq i64 %t90, 6
  br i1 %t91, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l1, !tbaa !21
  br label %bb18
bb17:
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s3)
  br label %bb19
bb19:
  %t93 = load i64, ptr %l6, !tbaa !24
  %t95 = add i64 %t93, 1
  store i64 %t95, ptr %l6, !tbaa !24
  br label %bb11
bb20:
  %t97 = load i1, ptr %l1, !tbaa !21
  %t99 = xor i1 %t97, true
  br i1 %t99, label %bb21, label %bb22
bb21:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d489, i32 0, i32 1) }, ptr %l59, !tbaa !27
  %t101 = load { i64, ptr }, ptr %l59, !tbaa !27
  store { i64, ptr } %t101, ptr %l60, !tbaa !27
  %t102 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t103 = extractvalue { i64, ptr } %t102, 0
  store i64 %t103, ptr %l61, !tbaa !24
  %t104 = load i64, ptr %l61, !tbaa !24
  %t105 = mul i64 %t104, 1
  %t106 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t105)
  %t107 = insertvalue { i64, ptr } undef, i64 %t104, 0
  %t108 = insertvalue { i64, ptr } %t107, ptr %t106, 1
  store { i64, ptr } %t108, ptr %l62, !tbaa !27
  %t109 = getelementptr { i64, ptr }, ptr %l62, i32 0, i32 1
  %t110 = load ptr, ptr %t109, !tbaa !27
  %t111 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !27
  %t113 = load i64, ptr %l61, !tbaa !24
  %t114 = mul i64 %t113, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t110, ptr %t112, i64 %t114, i1 false)
  %t115 = load { i64, ptr }, ptr %l62, !tbaa !27
  store { i64, ptr } %t115, ptr %l60, !tbaa !27
  %t116 = load { i64, ptr }, ptr %l60, !tbaa !27
  store { i64, ptr } %t116, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  store i64 0, ptr %l8, !tbaa !24
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"compiler/emit:fnEm", ptr %t117, i32 0, i32 1
  %t120 = load ptr, ptr %t119, !tbaa !29
  %t122 = getelementptr %"compiler/mir:Fn", ptr %t120, i32 0, i32 6
  %t124 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aVarKind_3e_2eLen_3ccompiler_2fmir_3aVarKind_3e(ptr %v0, ptr %t122)
  store i64 %t124, ptr %l66
  br label %bb24
bb24:
  %t125 = load i64, ptr %l66, !tbaa !24
  store i64 %t125, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t126 = load i64, ptr %l9, !tbaa !24
  %t127 = load i64, ptr %l8, !tbaa !24
  %t130 = icmp sgt i64 %t126, %t127
  br i1 %t130, label %bb25, label %bb26
bb25:
  %t132 = load i64, ptr %l10, !tbaa !24
  %t134 = icmp sgt i64 %t132, 0
  br i1 %t134, label %bb27, label %bb28
bb26:
  store i64 0, ptr %l70, !tbaa !24
  br label %bb30
bb27:
  %t136 = load i64, ptr %l9, !tbaa !24
  %t137 = load i64, ptr %l8, !tbaa !24
  %t140 = sub i64 %t136, %t137
  %t141 = load i64, ptr %l10, !tbaa !24
  %t144 = add i64 %t140, %t141
  %t146 = sub i64 %t144, 1
  %t147 = load i64, ptr %l10, !tbaa !24
  %t150 = sdiv i64 %t146, %t147
  store i64 %t150, ptr %l73, !tbaa !24
  br label %bb29
bb28:
  store i64 0, ptr %l73, !tbaa !24
  br label %bb29
bb29:
  %t152 = load i64, ptr %l73, !tbaa !24
  store i64 %t152, ptr %l70, !tbaa !24
  br label %bb30
bb30:
  %t153 = load i64, ptr %l70, !tbaa !24
  store i64 %t153, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb31
bb31:
  %t154 = load i64, ptr %l12, !tbaa !24
  %t155 = load i64, ptr %l11, !tbaa !24
  %t158 = icmp slt i64 %t154, %t155
  %t160 = xor i1 %t158, true
  br i1 %t160, label %bb32, label %bb33
bb32:
  br label %bb43
bb33:
  br label %bb34
bb34:
  %t162 = load i64, ptr %l8, !tbaa !24
  %t163 = load i64, ptr %l12, !tbaa !24
  %t164 = load i64, ptr %l10, !tbaa !24
  %t167 = mul i64 %t163, %t164
  %t170 = add i64 %t162, %t167
  store i64 %t170, ptr %l13, !tbaa !24
  %t172 = load i64, ptr %l13, !tbaa !24
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t175 = getelementptr %"compiler/emit:fnEm", ptr %t173, i32 0, i32 7
  %t176 = load i64, ptr %t175, !tbaa !24
  %t179 = icmp slt i64 %t172, %t176
  br i1 %t179, label %bb35, label %bb36
bb35:
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t183 = getelementptr %"compiler/emit:fnEm", ptr %t181, i32 0, i32 1
  %t184 = load ptr, ptr %t183, !tbaa !29
  %t186 = getelementptr %"compiler/mir:Fn", ptr %t184, i32 0, i32 6
  %t187 = load i64, ptr %l13, !tbaa !24
  %t190 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aVarKind_3e_2eAt_3ccompiler_2fmir_3aVarKind_3e(ptr %v0, ptr %t186, i64 %t187)
  store { i64, [1 x i64] } %t190, ptr %l100
  br label %bb37
bb36:
  store i1 false, ptr %l95, !tbaa !21
  br label %bb38
bb37:
  %t191 = load { i64, [1 x i64] }, ptr %l100
  %t193 = extractvalue { i64, [1 x i64] } %t191, 0
  %t194 = icmp eq i64 %t193, 1
  store i1 %t194, ptr %l95, !tbaa !21
  br label %bb38
bb38:
  %t196 = load i1, ptr %l95, !tbaa !21
  br i1 %t196, label %bb39, label %bb40
bb39:
  %t197 = load i64, ptr %l13, !tbaa !24
  %t198 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d490, i32 0, i32 1) }, 1
  %t199 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d490, i32 0, i32 1) }, 0
  %t201 = call i64 @__olang_fmt_i64(ptr null, i64 %t197)
  %t202 = add i64 %t199, %t201
  %t203 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t202)
  call void @olang_textcopy(ptr %t203, ptr %t198, i64 %t199)
  %t204 = getelementptr i8, ptr %t203, i64 %t199
  %t205 = call i64 @__olang_fmt_i64(ptr %t204, i64 %t197)
  %t206 = insertvalue { i64, ptr } undef, i64 %t202, 0
  %t207 = insertvalue { i64, ptr } %t206, ptr %t203, 1
  store { i64, ptr } %t207, ptr %rv
  br label %ret
bb40:
  br label %bb41
bb41:
  br label %bb42
bb42:
  %t209 = load i64, ptr %l12, !tbaa !24
  %t211 = add i64 %t209, 1
  store i64 %t211, ptr %l12, !tbaa !24
  br label %bb31
bb43:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d491, i32 0, i32 1) }, ptr %l107, !tbaa !27
  %t213 = load { i64, ptr }, ptr %l107, !tbaa !27
  store { i64, ptr } %t213, ptr %l108, !tbaa !27
  %t214 = load { i64, ptr }, ptr %l108, !tbaa !27
  %t215 = extractvalue { i64, ptr } %t214, 0
  store i64 %t215, ptr %l109, !tbaa !24
  %t216 = load i64, ptr %l109, !tbaa !24
  %t217 = mul i64 %t216, 1
  %t218 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t217)
  %t219 = insertvalue { i64, ptr } undef, i64 %t216, 0
  %t220 = insertvalue { i64, ptr } %t219, ptr %t218, 1
  store { i64, ptr } %t220, ptr %l110, !tbaa !27
  %t221 = getelementptr { i64, ptr }, ptr %l110, i32 0, i32 1
  %t222 = load ptr, ptr %t221, !tbaa !27
  %t223 = getelementptr { i64, ptr }, ptr %l108, i32 0, i32 1
  %t224 = load ptr, ptr %t223, !tbaa !27
  %t225 = load i64, ptr %l109, !tbaa !24
  %t226 = mul i64 %t225, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t222, ptr %t224, i64 %t226, i1 false)
  %t227 = load { i64, ptr }, ptr %l110, !tbaa !27
  store { i64, ptr } %t227, ptr %l108, !tbaa !27
  %t228 = load { i64, ptr }, ptr %l108, !tbaa !27
  store { i64, ptr } %t228, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3afnEm_2etaskEnds(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, ptr } %a2, %"compiler/mir:Task" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca %"compiler/mir:Task"
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca { i64, [4 x i64] }
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l16 = alloca { i64, [4 x i64] }
  %l17 = alloca i32
  %l21 = alloca i1
  %l22 = alloca { i64, ptr }
  %l33 = alloca i64
  %l36 = alloca i64
  %l61 = alloca { i64, [4 x i64] }
  %l66 = alloca { i64, ptr }
  %l67 = alloca { i64, ptr }
  %l68 = alloca i64
  %l69 = alloca { i64, ptr }
  %l78 = alloca { i64, [4 x i64] }
  %l84 = alloca { i64, ptr }
  %l86 = alloca i64
  %l98 = alloca ptr
  %l99 = alloca { i64, ptr }
  %l105 = alloca { i64, ptr }
  %l111 = alloca ptr
  %l112 = alloca { i64, ptr }
  %l115 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store %"compiler/mir:Task" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = load ptr, ptr %l4, !tbaa !29
  %t8 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2etraced(ptr %v0, ptr %t6)
  store i1 %t8, ptr %l21
  br label %bb1
bb1:
  %t9 = load i1, ptr %l21, !tbaa !21
  br i1 %t9, label %bb2, label %bb3
bb2:
  store { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d492, i32 0, i32 1) }, ptr %l22, !tbaa !27
  br label %bb4
bb3:
  store { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d493, i32 0, i32 1) }, ptr %l22, !tbaa !27
  br label %bb4
bb4:
  %t10 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t10, ptr %l5, !tbaa !27
  %t11 = load ptr, ptr %l4, !tbaa !29
  %t12 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t13 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t14 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d494, i32 0, i32 1) }, 1
  %t15 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d494, i32 0, i32 1) }, 0
  %t17 = extractvalue { i64, ptr } %t13, 1
  %t18 = extractvalue { i64, ptr } %t13, 0
  %t19 = add i64 %t15, %t18
  %t20 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d495, i32 0, i32 1) }, 1
  %t21 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d495, i32 0, i32 1) }, 0
  %t22 = add i64 %t19, %t21
  %t23 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t22)
  call void @olang_textcopy(ptr %t23, ptr %t14, i64 %t15)
  %t24 = getelementptr i8, ptr %t23, i64 %t15
  call void @olang_textcopy(ptr %t24, ptr %t17, i64 %t18)
  %t25 = getelementptr i8, ptr %t24, i64 %t18
  call void @olang_textcopy(ptr %t25, ptr %t20, i64 %t21)
  %t26 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t23, 1
  %t29 = extractvalue { i64, ptr } %t27, 0
  %t30 = extractvalue { i64, ptr } %t27, 1
  %t31 = mul i64 %t29, 1
  %t32 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t31)
  call void @llvm.memcpy.p0.p0.i64(ptr %t32, ptr %t30, i64 %t31, i1 false)
  %t33 = insertvalue { i64, ptr } undef, i64 %t29, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t32, 1
  %t35 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %t35, ptr %s0, ptr %t11, { i64, ptr } %t12, { i64, ptr } %t34)
  br label %bb5
bb5:
  store i64 0, ptr %l6, !tbaa !24
  %t39 = getelementptr %"compiler/mir:Task", ptr %l3, i32 0, i32 5
  %t40 = getelementptr %"compiler/mir:Range", ptr %t39, i32 0, i32 1
  %t41 = load i32, ptr %t40, !tbaa !23
  %t43 = sext i32 %t41 to i64
  store i64 %t43, ptr %l7, !tbaa !24
  store i64 2, ptr %l8, !tbaa !24
  %t45 = load i64, ptr %l7, !tbaa !24
  %t46 = load i64, ptr %l6, !tbaa !24
  %t49 = icmp sgt i64 %t45, %t46
  br i1 %t49, label %bb6, label %bb7
bb6:
  %t51 = load i64, ptr %l8, !tbaa !24
  %t53 = icmp sgt i64 %t51, 0
  br i1 %t53, label %bb8, label %bb9
bb7:
  store i64 0, ptr %l33, !tbaa !24
  br label %bb11
bb8:
  %t55 = load i64, ptr %l7, !tbaa !24
  %t56 = load i64, ptr %l6, !tbaa !24
  %t59 = sub i64 %t55, %t56
  %t60 = load i64, ptr %l8, !tbaa !24
  %t63 = add i64 %t59, %t60
  %t65 = sub i64 %t63, 1
  %t66 = load i64, ptr %l8, !tbaa !24
  %t69 = sdiv i64 %t65, %t66
  store i64 %t69, ptr %l36, !tbaa !24
  br label %bb10
bb9:
  store i64 0, ptr %l36, !tbaa !24
  br label %bb10
bb10:
  %t71 = load i64, ptr %l36, !tbaa !24
  store i64 %t71, ptr %l33, !tbaa !24
  br label %bb11
bb11:
  %t72 = load i64, ptr %l33, !tbaa !24
  store i64 %t72, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s3
  %t73 = load i64, ptr %l10, !tbaa !24
  %t74 = load i64, ptr %l9, !tbaa !24
  %t77 = icmp slt i64 %t73, %t74
  %t79 = xor i1 %t77, true
  br i1 %t79, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s3)
  br label %bb44
bb14:
  br label %bb15
bb15:
  %t81 = load i64, ptr %l6, !tbaa !24
  %t82 = load i64, ptr %l10, !tbaa !24
  %t83 = load i64, ptr %l8, !tbaa !24
  %t86 = mul i64 %t82, %t83
  %t89 = add i64 %t81, %t86
  store i64 %t89, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"compiler/emit:fnEm", ptr %t91, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !29
  %t96 = getelementptr %"compiler/mir:Fn", ptr %t94, i32 0, i32 11
  %t97 = getelementptr %"compiler/mir:Task", ptr %l3, i32 0, i32 5
  %t98 = getelementptr %"compiler/mir:Range", ptr %t97, i32 0, i32 0
  %t99 = load i32, ptr %t98, !tbaa !23
  %t101 = sext i32 %t99 to i64
  %t102 = load i64, ptr %l11, !tbaa !24
  %t105 = add i64 %t101, %t102
  %t108 = call { i64, [4 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2eAt_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %t96, i64 %t105)
  store { i64, [4 x i64] } %t108, ptr %l61
  br label %bb16
bb16:
  %t109 = load { i64, [4 x i64] }, ptr %l61
  store { i64, [4 x i64] } %t109, ptr %l13
  %t110 = load { i64, [4 x i64] }, ptr %l13
  %t112 = extractvalue { i64, [4 x i64] } %t110, 0
  %t113 = icmp eq i64 %t112, 2
  br i1 %t113, label %bb17, label %bb18
bb17:
  %t115 = getelementptr { i64, [4 x i64] }, ptr %l13, i32 0, i32 1
  %t116 = getelementptr { i32, i64 }, ptr %t115, i32 0, i32 1
  %t117 = load i64, ptr %t116
  store i64 %t117, ptr %l14, !tbaa !24
  br label %bb19
bb18:
  br label %bb20
bb19:
  %t119 = load i64, ptr %l14, !tbaa !24
  store i64 %t119, ptr %l12, !tbaa !24
  br label %bb25
bb20:
  br i1 true, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_a013fd5d1a1a0ecb_8946a3e4bb7adef)
  unreachable
bb25:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d496, i32 0, i32 1) }, ptr %l66, !tbaa !27
  %t121 = load { i64, ptr }, ptr %l66, !tbaa !27
  store { i64, ptr } %t121, ptr %l67, !tbaa !27
  %t122 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t123 = extractvalue { i64, ptr } %t122, 0
  store i64 %t123, ptr %l68, !tbaa !24
  %t124 = load i64, ptr %l68, !tbaa !24
  %t125 = mul i64 %t124, 1
  %t126 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t125)
  %t127 = insertvalue { i64, ptr } undef, i64 %t124, 0
  %t128 = insertvalue { i64, ptr } %t127, ptr %t126, 1
  store { i64, ptr } %t128, ptr %l69, !tbaa !27
  %t129 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t130 = load ptr, ptr %t129, !tbaa !27
  %t131 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t132 = load ptr, ptr %t131, !tbaa !27
  %t133 = load i64, ptr %l68, !tbaa !24
  %t134 = mul i64 %t133, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t130, ptr %t132, i64 %t134, i1 false)
  %t135 = load { i64, ptr }, ptr %l69, !tbaa !27
  store { i64, ptr } %t135, ptr %l15, !tbaa !27
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t138 = getelementptr %"compiler/emit:fnEm", ptr %t136, i32 0, i32 1
  %t139 = load ptr, ptr %t138, !tbaa !29
  %t141 = getelementptr %"compiler/mir:Fn", ptr %t139, i32 0, i32 11
  %t142 = getelementptr %"compiler/mir:Task", ptr %l3, i32 0, i32 5
  %t143 = getelementptr %"compiler/mir:Range", ptr %t142, i32 0, i32 0
  %t144 = load i32, ptr %t143, !tbaa !23
  %t146 = sext i32 %t144 to i64
  %t147 = load i64, ptr %l11, !tbaa !24
  %t150 = add i64 %t146, %t147
  %t152 = add i64 %t150, 1
  %t155 = call { i64, [4 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2eAt_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %t141, i64 %t152)
  store { i64, [4 x i64] } %t155, ptr %l78
  br label %bb26
bb26:
  %t156 = load { i64, [4 x i64] }, ptr %l78
  store { i64, [4 x i64] } %t156, ptr %l16
  %t157 = load { i64, [4 x i64] }, ptr %l16
  %t159 = extractvalue { i64, [4 x i64] } %t157, 0
  %t160 = icmp eq i64 %t159, 3
  br i1 %t160, label %bb27, label %bb28
bb27:
  %t162 = getelementptr { i64, [4 x i64] }, ptr %l16, i32 0, i32 1
  %t163 = getelementptr { i32, i32, i64, %"compiler/source:Span" }, ptr %t162, i32 0, i32 1
  %t164 = load i32, ptr %t163
  store i32 %t164, ptr %l17, !tbaa !23
  br label %bb29
bb28:
  br label %bb34
bb29:
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t167 = load i32, ptr %l17, !tbaa !23
  %t170 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2econstText(ptr %v0, ptr %s3, ptr %t166, i32 %t167)
  store { i64, ptr } %t170, ptr %l84
  br label %bb30
bb30:
  %t171 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t172 = extractvalue { i64, ptr } %t171, 0
  %t173 = load { i64, ptr }, ptr %l84, !tbaa !27
  %t174 = extractvalue { i64, ptr } %t173, 0
  store i64 %t174, ptr %l86, !tbaa !24
  %t176 = load i64, ptr %l86, !tbaa !24
  %t177 = icmp eq i64 %t172, %t176
  br i1 %t177, label %bb31, label %bb32
bb31:
  %t179 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t180 = load ptr, ptr %t179, !tbaa !27
  %t181 = getelementptr { i64, ptr }, ptr %l84, i32 0, i32 1
  %t182 = load ptr, ptr %t181, !tbaa !27
  %t183 = load i64, ptr %l86, !tbaa !24
  %t184 = mul i64 %t183, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t180, ptr %t182, i64 %t184, i1 false)
  br label %bb33
bb32:
  %t185 = load { i64, ptr }, ptr %l84, !tbaa !27
  store { i64, ptr } %t185, ptr %l15, !tbaa !27
  br label %bb33
bb33:
  br label %bb39
bb34:
  br i1 true, label %bb35, label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb38
bb37:
  br label %bb39
bb38:
  call void @__olang_check_failed(ptr @olang_loc_625291c18633ca8a_b2d4e63a7cb7312e)
  unreachable
bb39:
  %t186 = load ptr, ptr %l1, !tbaa !29
  %t187 = load i64, ptr %l11, !tbaa !24
  %t189 = load i64, ptr %l12, !tbaa !24
  %t190 = load i64, ptr %l11, !tbaa !24
  %t191 = load i64, ptr %l11, !tbaa !24
  %t192 = load i64, ptr %l11, !tbaa !24
  %t193 = load i64, ptr %l11, !tbaa !24
  %t194 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d497, i32 0, i32 1) }, 1
  %t195 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d497, i32 0, i32 1) }, 0
  %t197 = call i64 @__olang_fmt_i64(ptr null, i64 %t187)
  %t198 = add i64 %t195, %t197
  %t199 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d498, i32 0, i32 1) }, 1
  %t200 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d498, i32 0, i32 1) }, 0
  %t201 = add i64 %t198, %t200
  %t203 = extractvalue { i64, ptr } %a2, 1
  %t204 = extractvalue { i64, ptr } %a2, 0
  %t205 = add i64 %t201, %t204
  %t206 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d499, i32 0, i32 1) }, 1
  %t207 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d499, i32 0, i32 1) }, 0
  %t208 = add i64 %t205, %t207
  %t210 = call i64 @__olang_fmt_i64(ptr null, i64 %t189)
  %t211 = add i64 %t208, %t210
  %t212 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d500, i32 0, i32 1) }, 1
  %t213 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d500, i32 0, i32 1) }, 0
  %t214 = add i64 %t211, %t213
  %t216 = call i64 @__olang_fmt_i64(ptr null, i64 %t190)
  %t217 = add i64 %t214, %t216
  %t218 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d501, i32 0, i32 1) }, 1
  %t219 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d501, i32 0, i32 1) }, 0
  %t220 = add i64 %t217, %t219
  %t222 = call i64 @__olang_fmt_i64(ptr null, i64 %t191)
  %t223 = add i64 %t220, %t222
  %t224 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d502, i32 0, i32 1) }, 1
  %t225 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d502, i32 0, i32 1) }, 0
  %t226 = add i64 %t223, %t225
  %t228 = call i64 @__olang_fmt_i64(ptr null, i64 %t192)
  %t229 = add i64 %t226, %t228
  %t230 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d503, i32 0, i32 1) }, 1
  %t231 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d503, i32 0, i32 1) }, 0
  %t232 = add i64 %t229, %t231
  %t234 = call i64 @__olang_fmt_i64(ptr null, i64 %t193)
  %t235 = add i64 %t232, %t234
  %t236 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d504, i32 0, i32 1) }, 1
  %t237 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d504, i32 0, i32 1) }, 0
  %t238 = add i64 %t235, %t237
  %t239 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t238)
  call void @olang_textcopy(ptr %t239, ptr %t194, i64 %t195)
  %t240 = getelementptr i8, ptr %t239, i64 %t195
  %t241 = call i64 @__olang_fmt_i64(ptr %t240, i64 %t187)
  %t242 = getelementptr i8, ptr %t240, i64 %t197
  call void @olang_textcopy(ptr %t242, ptr %t199, i64 %t200)
  %t243 = getelementptr i8, ptr %t242, i64 %t200
  call void @olang_textcopy(ptr %t243, ptr %t203, i64 %t204)
  %t244 = getelementptr i8, ptr %t243, i64 %t204
  call void @olang_textcopy(ptr %t244, ptr %t206, i64 %t207)
  %t245 = getelementptr i8, ptr %t244, i64 %t207
  %t246 = call i64 @__olang_fmt_i64(ptr %t245, i64 %t189)
  %t247 = getelementptr i8, ptr %t245, i64 %t210
  call void @olang_textcopy(ptr %t247, ptr %t212, i64 %t213)
  %t248 = getelementptr i8, ptr %t247, i64 %t213
  %t249 = call i64 @__olang_fmt_i64(ptr %t248, i64 %t190)
  %t250 = getelementptr i8, ptr %t248, i64 %t216
  call void @olang_textcopy(ptr %t250, ptr %t218, i64 %t219)
  %t251 = getelementptr i8, ptr %t250, i64 %t219
  %t252 = call i64 @__olang_fmt_i64(ptr %t251, i64 %t191)
  %t253 = getelementptr i8, ptr %t251, i64 %t222
  call void @olang_textcopy(ptr %t253, ptr %t224, i64 %t225)
  %t254 = getelementptr i8, ptr %t253, i64 %t225
  %t255 = call i64 @__olang_fmt_i64(ptr %t254, i64 %t192)
  %t256 = getelementptr i8, ptr %t254, i64 %t228
  call void @olang_textcopy(ptr %t256, ptr %t230, i64 %t231)
  %t257 = getelementptr i8, ptr %t256, i64 %t231
  %t258 = call i64 @__olang_fmt_i64(ptr %t257, i64 %t193)
  %t259 = getelementptr i8, ptr %t257, i64 %t234
  call void @olang_textcopy(ptr %t259, ptr %t236, i64 %t237)
  %t260 = insertvalue { i64, ptr } undef, i64 %t238, 0
  %t261 = insertvalue { i64, ptr } %t260, ptr %t239, 1
  %t263 = extractvalue { i64, ptr } %t261, 0
  %t264 = extractvalue { i64, ptr } %t261, 1
  %t265 = mul i64 %t263, 1
  %t266 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t265)
  call void @llvm.memcpy.p0.p0.i64(ptr %t266, ptr %t264, i64 %t265, i1 false)
  %t267 = insertvalue { i64, ptr } undef, i64 %t263, 0
  %t268 = insertvalue { i64, ptr } %t267, ptr %t266, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s3, ptr %t186, { i64, ptr } %t268)
  br label %bb40
bb40:
  %t271 = load ptr, ptr %l1, !tbaa !29
  store ptr %t271, ptr %l98, !tbaa !29
  %t272 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t272, ptr %l99, !tbaa !27
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t274 = getelementptr %"compiler/mir:Task", ptr %l3, i32 0, i32 6
  %t275 = load %"compiler/source:Span", ptr %t274
  %t276 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t277 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d505, i32 0, i32 1) }, 1
  %t278 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d505, i32 0, i32 1) }, 0
  %t280 = extractvalue { i64, ptr } %t276, 1
  %t281 = extractvalue { i64, ptr } %t276, 0
  %t282 = add i64 %t278, %t281
  %t283 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d506, i32 0, i32 1) }, 1
  %t284 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d506, i32 0, i32 1) }, 0
  %t285 = add i64 %t282, %t284
  %t286 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t285)
  call void @olang_textcopy(ptr %t286, ptr %t277, i64 %t278)
  %t287 = getelementptr i8, ptr %t286, i64 %t278
  call void @olang_textcopy(ptr %t287, ptr %t280, i64 %t281)
  %t288 = getelementptr i8, ptr %t287, i64 %t281
  call void @olang_textcopy(ptr %t288, ptr %t283, i64 %t284)
  %t289 = insertvalue { i64, ptr } undef, i64 %t285, 0
  %t290 = insertvalue { i64, ptr } %t289, ptr %t286, 1
  %t292 = extractvalue { i64, ptr } %t290, 0
  %t293 = extractvalue { i64, ptr } %t290, 1
  %t294 = mul i64 %t292, 1
  %t295 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t294)
  call void @llvm.memcpy.p0.p0.i64(ptr %t295, ptr %t293, i64 %t294, i1 false)
  %t296 = insertvalue { i64, ptr } undef, i64 %t292, 0
  %t297 = insertvalue { i64, ptr } %t296, ptr %t295, 1
  %t301 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elocated(ptr %v0, ptr %s3, ptr %s3, ptr %t273, %"compiler/source:Span" %t275, { i64, ptr } %t297)
  store { i64, ptr } %t301, ptr %l105
  br label %bb41
bb41:
  %t302 = load i64, ptr %l11, !tbaa !24
  %t303 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d507, i32 0, i32 1) }, 1
  %t304 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d507, i32 0, i32 1) }, 0
  %t305 = load { i64, ptr }, ptr %l99, !tbaa !27
  %t306 = extractvalue { i64, ptr } %t305, 1
  %t307 = extractvalue { i64, ptr } %t305, 0
  %t308 = add i64 %t304, %t307
  %t309 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d508, i32 0, i32 1) }, 1
  %t310 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d508, i32 0, i32 1) }, 0
  %t311 = add i64 %t308, %t310
  %t312 = load { i64, ptr }, ptr %l105, !tbaa !27
  %t313 = extractvalue { i64, ptr } %t312, 1
  %t314 = extractvalue { i64, ptr } %t312, 0
  %t315 = add i64 %t311, %t314
  %t316 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d509, i32 0, i32 1) }, 1
  %t317 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d509, i32 0, i32 1) }, 0
  %t318 = add i64 %t315, %t317
  %t320 = call i64 @__olang_fmt_i64(ptr null, i64 %t302)
  %t321 = add i64 %t318, %t320
  %t322 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d510, i32 0, i32 1) }, 1
  %t323 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d510, i32 0, i32 1) }, 0
  %t324 = add i64 %t321, %t323
  %t325 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t324)
  call void @olang_textcopy(ptr %t325, ptr %t303, i64 %t304)
  %t326 = getelementptr i8, ptr %t325, i64 %t304
  call void @olang_textcopy(ptr %t326, ptr %t306, i64 %t307)
  %t327 = getelementptr i8, ptr %t326, i64 %t307
  call void @olang_textcopy(ptr %t327, ptr %t309, i64 %t310)
  %t328 = getelementptr i8, ptr %t327, i64 %t310
  call void @olang_textcopy(ptr %t328, ptr %t313, i64 %t314)
  %t329 = getelementptr i8, ptr %t328, i64 %t314
  call void @olang_textcopy(ptr %t329, ptr %t316, i64 %t317)
  %t330 = getelementptr i8, ptr %t329, i64 %t317
  %t331 = call i64 @__olang_fmt_i64(ptr %t330, i64 %t302)
  %t332 = getelementptr i8, ptr %t330, i64 %t320
  call void @olang_textcopy(ptr %t332, ptr %t322, i64 %t323)
  %t333 = insertvalue { i64, ptr } undef, i64 %t324, 0
  %t334 = insertvalue { i64, ptr } %t333, ptr %t325, 1
  %t336 = extractvalue { i64, ptr } %t334, 0
  %t337 = extractvalue { i64, ptr } %t334, 1
  %t338 = mul i64 %t336, 1
  %t339 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t338)
  call void @llvm.memcpy.p0.p0.i64(ptr %t339, ptr %t337, i64 %t338, i1 false)
  %t340 = insertvalue { i64, ptr } undef, i64 %t336, 0
  %t341 = insertvalue { i64, ptr } %t340, ptr %t339, 1
  %t342 = load ptr, ptr %l98, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s3, ptr %t342, { i64, ptr } %t341)
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s3)
  br label %bb43
bb43:
  %t344 = load i64, ptr %l10, !tbaa !24
  %t346 = add i64 %t344, 1
  store i64 %t346, ptr %l10, !tbaa !24
  br label %bb12
bb44:
  %t348 = load ptr, ptr %l1, !tbaa !29
  store ptr %t348, ptr %l111, !tbaa !29
  %t349 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t349, ptr %l112, !tbaa !27
  %t350 = load ptr, ptr %l0, !tbaa !29
  %t351 = getelementptr %"compiler/mir:Task", ptr %l3, i32 0, i32 6
  %t352 = load %"compiler/source:Span", ptr %t351
  %t355 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elocated(ptr %v0, ptr %s0, ptr %s0, ptr %t350, %"compiler/source:Span" %t352, { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d511, i32 0, i32 1) })
  store { i64, ptr } %t355, ptr %l115
  br label %bb45
bb45:
  %t356 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d512, i32 0, i32 1) }, 1
  %t357 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d512, i32 0, i32 1) }, 0
  %t358 = load { i64, ptr }, ptr %l112, !tbaa !27
  %t359 = extractvalue { i64, ptr } %t358, 1
  %t360 = extractvalue { i64, ptr } %t358, 0
  %t361 = add i64 %t357, %t360
  %t362 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d513, i32 0, i32 1) }, 1
  %t363 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d513, i32 0, i32 1) }, 0
  %t364 = add i64 %t361, %t363
  %t365 = load { i64, ptr }, ptr %l115, !tbaa !27
  %t366 = extractvalue { i64, ptr } %t365, 1
  %t367 = extractvalue { i64, ptr } %t365, 0
  %t368 = add i64 %t364, %t367
  %t369 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d514, i32 0, i32 1) }, 1
  %t370 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d514, i32 0, i32 1) }, 0
  %t371 = add i64 %t368, %t370
  %t372 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t371)
  call void @olang_textcopy(ptr %t372, ptr %t356, i64 %t357)
  %t373 = getelementptr i8, ptr %t372, i64 %t357
  call void @olang_textcopy(ptr %t373, ptr %t359, i64 %t360)
  %t374 = getelementptr i8, ptr %t373, i64 %t360
  call void @olang_textcopy(ptr %t374, ptr %t362, i64 %t363)
  %t375 = getelementptr i8, ptr %t374, i64 %t363
  call void @olang_textcopy(ptr %t375, ptr %t366, i64 %t367)
  %t376 = getelementptr i8, ptr %t375, i64 %t367
  call void @olang_textcopy(ptr %t376, ptr %t369, i64 %t370)
  %t377 = insertvalue { i64, ptr } undef, i64 %t371, 0
  %t378 = insertvalue { i64, ptr } %t377, ptr %t372, 1
  %t380 = extractvalue { i64, ptr } %t378, 0
  %t381 = extractvalue { i64, ptr } %t378, 1
  %t382 = mul i64 %t380, 1
  %t383 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t382)
  call void @llvm.memcpy.p0.p0.i64(ptr %t383, ptr %t381, i64 %t382, i1 false)
  %t384 = insertvalue { i64, ptr } undef, i64 %t380, 0
  %t385 = insertvalue { i64, ptr } %t384, ptr %t383, 1
  %t386 = load ptr, ptr %l111, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s0, ptr %t386, { i64, ptr } %t385)
  br label %bb46
bb46:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3afnEm_2etaskOld(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/mir:Task" %a2, i64 %a3) #0 {
entry:
  %l2 = alloca %"compiler/mir:Task"
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i32
  %l14 = alloca i32
  %l17 = alloca i32
  %l39 = alloca i1
  %s2 = alloca %olang.scope
  store %"compiler/mir:Task" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store i32 0, ptr %l4, !tbaa !23
  %t1 = getelementptr %"compiler/mir:Task", ptr %l2, i32 0, i32 3
  %t2 = getelementptr %"compiler/mir:Range", ptr %t1, i32 0, i32 1
  %t3 = load i32, ptr %t2, !tbaa !23
  store i32 %t3, ptr %l5, !tbaa !23
  store i32 1, ptr %l6, !tbaa !23
  %t5 = load i32, ptr %l5, !tbaa !23
  %t6 = load i32, ptr %l4, !tbaa !23
  %t9 = icmp sgt i32 %t5, %t6
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load i32, ptr %l6, !tbaa !23
  %t13 = icmp sgt i32 %t11, 0
  br i1 %t13, label %bb3, label %bb4
bb2:
  store i32 0, ptr %l14, !tbaa !23
  br label %bb6
bb3:
  %t15 = load i32, ptr %l5, !tbaa !23
  %t16 = load i32, ptr %l4, !tbaa !23
  %t19 = sub i32 %t15, %t16
  %t20 = load i32, ptr %l6, !tbaa !23
  %t23 = add i32 %t19, %t20
  %t25 = sub i32 %t23, 1
  %t26 = load i32, ptr %l6, !tbaa !23
  %t29 = sdiv i32 %t25, %t26
  store i32 %t29, ptr %l17, !tbaa !23
  br label %bb5
bb4:
  store i32 0, ptr %l17, !tbaa !23
  br label %bb5
bb5:
  %t31 = load i32, ptr %l17, !tbaa !23
  store i32 %t31, ptr %l14, !tbaa !23
  br label %bb6
bb6:
  %t32 = load i32, ptr %l14, !tbaa !23
  store i32 %t32, ptr %l7, !tbaa !23
  store i32 0, ptr %l8, !tbaa !23
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t33 = load i32, ptr %l8, !tbaa !23
  %t34 = load i32, ptr %l7, !tbaa !23
  %t37 = icmp slt i32 %t33, %t34
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb9:
  br label %bb10
bb10:
  %t41 = load i32, ptr %l4, !tbaa !23
  %t42 = load i32, ptr %l8, !tbaa !23
  %t43 = load i32, ptr %l6, !tbaa !23
  %t46 = mul i32 %t42, %t43
  %t49 = add i32 %t41, %t46
  store i32 %t49, ptr %l9, !tbaa !23
  %t52 = load %"compiler/mir:Task", ptr %l2
  %t53 = load i32, ptr %l9, !tbaa !23
  %t55 = sext i32 %t53 to i64
  %t59 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2evalueTarget(ptr %v0, ptr %a0, %"compiler/mir:Task" %t52, i64 %t55)
  store i1 %t59, ptr %l39
  br label %bb11
bb11:
  %t60 = load i1, ptr %l39, !tbaa !21
  %t61 = xor i1 %t60, true
  br i1 %t61, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb13:
  br label %bb14
bb14:
  %t64 = load i32, ptr %l9, !tbaa !23
  %t66 = load i32, ptr %l9, !tbaa !23
  %t68 = sext i32 %t66 to i64
  %t71 = add i64 %a3, %t68
  %t72 = load i32, ptr %l9, !tbaa !23
  %t73 = load i32, ptr %l9, !tbaa !23
  %t74 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d515, i32 0, i32 1) }, 1
  %t75 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d515, i32 0, i32 1) }, 0
  %t77 = sext i32 %t64 to i64
  %t78 = call i64 @__olang_fmt_i64(ptr null, i64 %t77)
  %t79 = add i64 %t75, %t78
  %t80 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d516, i32 0, i32 1) }, 1
  %t81 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d516, i32 0, i32 1) }, 0
  %t82 = add i64 %t79, %t81
  %t84 = call i64 @__olang_fmt_i64(ptr null, i64 %t71)
  %t85 = add i64 %t82, %t84
  %t86 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d517, i32 0, i32 1) }, 1
  %t87 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d517, i32 0, i32 1) }, 0
  %t88 = add i64 %t85, %t87
  %t90 = sext i32 %t72 to i64
  %t91 = call i64 @__olang_fmt_i64(ptr null, i64 %t90)
  %t92 = add i64 %t88, %t91
  %t93 = extractvalue { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d518, i32 0, i32 1) }, 1
  %t94 = extractvalue { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d518, i32 0, i32 1) }, 0
  %t95 = add i64 %t92, %t94
  %t97 = sext i32 %t73 to i64
  %t98 = call i64 @__olang_fmt_i64(ptr null, i64 %t97)
  %t99 = add i64 %t95, %t98
  %t100 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d519, i32 0, i32 1) }, 1
  %t101 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d519, i32 0, i32 1) }, 0
  %t102 = add i64 %t99, %t101
  %t103 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t102)
  call void @olang_textcopy(ptr %t103, ptr %t74, i64 %t75)
  %t104 = getelementptr i8, ptr %t103, i64 %t75
  %t105 = call i64 @__olang_fmt_i64(ptr %t104, i64 %t77)
  %t106 = getelementptr i8, ptr %t104, i64 %t78
  call void @olang_textcopy(ptr %t106, ptr %t80, i64 %t81)
  %t107 = getelementptr i8, ptr %t106, i64 %t81
  %t108 = call i64 @__olang_fmt_i64(ptr %t107, i64 %t71)
  %t109 = getelementptr i8, ptr %t107, i64 %t84
  call void @olang_textcopy(ptr %t109, ptr %t86, i64 %t87)
  %t110 = getelementptr i8, ptr %t109, i64 %t87
  %t111 = call i64 @__olang_fmt_i64(ptr %t110, i64 %t90)
  %t112 = getelementptr i8, ptr %t110, i64 %t91
  call void @olang_textcopy(ptr %t112, ptr %t93, i64 %t94)
  %t113 = getelementptr i8, ptr %t112, i64 %t94
  %t114 = call i64 @__olang_fmt_i64(ptr %t113, i64 %t97)
  %t115 = getelementptr i8, ptr %t113, i64 %t98
  call void @olang_textcopy(ptr %t115, ptr %t100, i64 %t101)
  %t116 = insertvalue { i64, ptr } undef, i64 %t102, 0
  %t117 = insertvalue { i64, ptr } %t116, ptr %t103, 1
  %t119 = extractvalue { i64, ptr } %t117, 0
  %t120 = extractvalue { i64, ptr } %t117, 1
  %t121 = mul i64 %t119, 1
  %t122 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t121)
  call void @llvm.memcpy.p0.p0.i64(ptr %t122, ptr %t120, i64 %t121, i1 false)
  %t123 = insertvalue { i64, ptr } undef, i64 %t119, 0
  %t124 = insertvalue { i64, ptr } %t123, ptr %t122, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s2, ptr %a1, { i64, ptr } %t124)
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb16:
  %t127 = load i32, ptr %l8, !tbaa !23
  %t129 = add i32 %t127, 1
  store i32 %t129, ptr %l8, !tbaa !23
  br label %bb7
bb17:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3afnEm_2eterm(ptr %v0, ptr %a0, { i64, [8 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [8 x i64] }
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca { i64, [4 x i64] }
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca { i64, [4 x i64] }
  %l8 = alloca %"compiler/mir:Range"
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca %"std/prelude/text:StringBuilder"
  %l14 = alloca i32
  %l15 = alloca i32
  %l16 = alloca i32
  %l17 = alloca i32
  %l18 = alloca i32
  %l20 = alloca %"compiler/mir:Case"
  %l21 = alloca i32
  %l22 = alloca i32
  %l23 = alloca { i64, [4 x i64] }
  %l24 = alloca { i64, ptr }
  %l26 = alloca { i64, [4 x i64] }
  %l27 = alloca i32
  %l28 = alloca %"compiler/mir:Range"
  %l29 = alloca i32
  %l30 = alloca %"compiler/source:Span"
  %l31 = alloca { i64, [4 x i64] }
  %l32 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l34 = alloca i32
  %l35 = alloca i32
  %l36 = alloca i32
  %l37 = alloca i32
  %l38 = alloca i1
  %l39 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l42 = alloca %"compiler/source:Span"
  %l43 = alloca i32
  %l44 = alloca { i64, [4 x i64] }
  %l51 = alloca ptr
  %l53 = alloca %"compiler/source:Span"
  %l60 = alloca ptr
  %l62 = alloca { i64, ptr }
  %l70 = alloca ptr
  %l74 = alloca { i64, ptr }
  %l76 = alloca { i64, ptr }
  %l78 = alloca { i64, ptr }
  %l88 = alloca i32
  %l91 = alloca { i64, ptr }
  %l95 = alloca { i64, ptr }
  %l96 = alloca %"std/prelude/text:StringBuilder"
  %l97 = alloca ptr
  %l98 = alloca { i64, ptr }
  %l99 = alloca { i64, ptr }
  %l101 = alloca { i64, ptr }
  %l108 = alloca i32
  %l111 = alloca i32
  %l137 = alloca %"compiler/mir:Case"
  %l138 = alloca ptr
  %l139 = alloca { i64, ptr }
  %l144 = alloca { i64, ptr }
  %l146 = alloca { i64, ptr }
  %l152 = alloca ptr
  %l154 = alloca { i64, ptr }
  %l162 = alloca ptr
  %l168 = alloca %"compiler/mir:Call"
  %l175 = alloca ptr
  %l181 = alloca %"compiler/mir:Call"
  %l190 = alloca { i64, ptr }
  %l207 = alloca ptr
  %l208 = alloca { i64, ptr }
  %l212 = alloca { i64, ptr }
  %l217 = alloca { i64, ptr }
  %l220 = alloca { i64, ptr }
  %l225 = alloca i1
  %l227 = alloca ptr
  %l228 = alloca { i64, ptr }
  %l233 = alloca { i64, ptr }
  %l261 = alloca { i64, ptr }
  %l265 = alloca { i64, ptr }
  %l267 = alloca i1
  %l270 = alloca ptr
  %l271 = alloca { i64, ptr }
  %l277 = alloca { i64, ptr }
  %l289 = alloca i1
  %l295 = alloca ptr
  %l296 = alloca i32
  %l298 = alloca { i64, ptr }
  %l301 = alloca { i64, ptr }
  %l305 = alloca ptr
  %l307 = alloca { i64, ptr }
  %l314 = alloca { i64, ptr }
  %l318 = alloca ptr
  %l319 = alloca { i64, ptr }
  %l322 = alloca { i64, ptr }
  %l328 = alloca { i64, ptr }
  %l329 = alloca ptr
  %l330 = alloca { i64, ptr }
  %l332 = alloca { i64, ptr }
  %l334 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %s29 = alloca %olang.scope
  %s31 = alloca %olang.scope
  %s33 = alloca %olang.scope
  %s35 = alloca %olang.scope
  %s37 = alloca %olang.scope
  %s41 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, [8 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/emit:Emitter", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l2, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/emit:fnEm", ptr %t9, i32 0, i32 18
  %t12 = load i64, ptr %t11, !tbaa !24
  %t14 = icmp sge i64 %t12, 0
  br i1 %t14, label %bb1, label %bb2
bb1:
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l51, !tbaa !29
  %t17 = load { i64, [8 x i64] }, ptr %l1
  %t19 = call %"compiler/source:Span" @compiler_2femit_2etermSpan({ i64, [8 x i64] } %t17)
  store %"compiler/source:Span" %t19, ptr %l53
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t20 = load ptr, ptr %l51, !tbaa !29
  %t21 = load %"compiler/source:Span", ptr %l53
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2elocate(ptr %v0, ptr %t20, %"compiler/source:Span" %t21)
  br label %bb4
bb4:
  br label %bb5
bb5:
  %t22 = load { i64, [8 x i64] }, ptr %l1
  %t24 = extractvalue { i64, [8 x i64] } %t22, 0
  %t25 = icmp eq i64 %t24, 0
  br i1 %t25, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb10
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t27 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s2, ptr %t27, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d520, i32 0, i32 1) })
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb159
bb10:
  %t29 = load { i64, [8 x i64] }, ptr %l1
  %t31 = extractvalue { i64, [8 x i64] } %t29, 0
  %t32 = icmp eq i64 %t31, 1
  br i1 %t32, label %bb11, label %bb12
bb11:
  %t34 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t35 = getelementptr { i32 }, ptr %t34, i32 0, i32 0
  %t36 = load i32, ptr %t35
  store i32 %t36, ptr %l3, !tbaa !23
  br label %bb13
bb12:
  br label %bb16
bb13:
  store %olang.scope zeroinitializer, ptr %s3
  %t38 = load ptr, ptr %l0, !tbaa !29
  store ptr %t38, ptr %l60, !tbaa !29
  %t39 = load i32, ptr %l3, !tbaa !23
  %t41 = call { i64, ptr } @compiler_2femit_2eblockName(ptr %s3, i32 %t39)
  store { i64, ptr } %t41, ptr %l62
  br label %bb14
bb14:
  %t42 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d521, i32 0, i32 1) }, 1
  %t43 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d521, i32 0, i32 1) }, 0
  %t44 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t44, 1
  %t46 = extractvalue { i64, ptr } %t44, 0
  %t47 = add i64 %t43, %t46
  %t48 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t47)
  call void @olang_textcopy(ptr %t48, ptr %t42, i64 %t43)
  %t49 = getelementptr i8, ptr %t48, i64 %t43
  call void @olang_textcopy(ptr %t49, ptr %t45, i64 %t46)
  %t50 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t48, 1
  %t53 = extractvalue { i64, ptr } %t51, 0
  %t54 = extractvalue { i64, ptr } %t51, 1
  %t55 = mul i64 %t53, 1
  %t56 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t55)
  call void @llvm.memcpy.p0.p0.i64(ptr %t56, ptr %t54, i64 %t55, i1 false)
  %t57 = insertvalue { i64, ptr } undef, i64 %t53, 0
  %t58 = insertvalue { i64, ptr } %t57, ptr %t56, 1
  %t59 = load ptr, ptr %l60, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s3, ptr %t59, { i64, ptr } %t58)
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s3)
  br label %bb159
bb16:
  %t61 = load { i64, [8 x i64] }, ptr %l1
  %t63 = extractvalue { i64, [8 x i64] } %t61, 0
  %t64 = icmp eq i64 %t63, 2
  br i1 %t64, label %bb17, label %bb18
bb17:
  %t66 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t67 = getelementptr { { i64, [4 x i64] }, i32, i32 }, ptr %t66, i32 0, i32 0
  %t68 = load { i64, [4 x i64] }, ptr %t67
  store { i64, [4 x i64] } %t68, ptr %l4
  %t70 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t71 = getelementptr { { i64, [4 x i64] }, i32, i32 }, ptr %t70, i32 0, i32 1
  %t72 = load i32, ptr %t71
  store i32 %t72, ptr %l5, !tbaa !23
  %t74 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t75 = getelementptr { { i64, [4 x i64] }, i32, i32 }, ptr %t74, i32 0, i32 2
  %t76 = load i32, ptr %t75
  store i32 %t76, ptr %l6, !tbaa !23
  br label %bb19
bb18:
  br label %bb24
bb19:
  store %olang.scope zeroinitializer, ptr %s5
  %t78 = load ptr, ptr %l0, !tbaa !29
  store ptr %t78, ptr %l70, !tbaa !29
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t80 = load { i64, [4 x i64] }, ptr %l4
  %t81 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t85 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s5, ptr %t79, { i64, [4 x i64] } %t80, i32 %t81)
  store { i64, ptr } %t85, ptr %l74
  br label %bb20
bb20:
  %t86 = load i32, ptr %l5, !tbaa !23
  %t88 = call { i64, ptr } @compiler_2femit_2eblockName(ptr %s5, i32 %t86)
  store { i64, ptr } %t88, ptr %l76
  br label %bb21
bb21:
  %t89 = load i32, ptr %l6, !tbaa !23
  %t91 = call { i64, ptr } @compiler_2femit_2eblockName(ptr %s5, i32 %t89)
  store { i64, ptr } %t91, ptr %l78
  br label %bb22
bb22:
  %t92 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d522, i32 0, i32 1) }, 1
  %t93 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d522, i32 0, i32 1) }, 0
  %t94 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t95 = extractvalue { i64, ptr } %t94, 1
  %t96 = extractvalue { i64, ptr } %t94, 0
  %t97 = add i64 %t93, %t96
  %t98 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d523, i32 0, i32 1) }, 1
  %t99 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d523, i32 0, i32 1) }, 0
  %t100 = add i64 %t97, %t99
  %t101 = load { i64, ptr }, ptr %l76, !tbaa !27
  %t102 = extractvalue { i64, ptr } %t101, 1
  %t103 = extractvalue { i64, ptr } %t101, 0
  %t104 = add i64 %t100, %t103
  %t105 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d523, i32 0, i32 1) }, 1
  %t106 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d523, i32 0, i32 1) }, 0
  %t107 = add i64 %t104, %t106
  %t108 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t109 = extractvalue { i64, ptr } %t108, 1
  %t110 = extractvalue { i64, ptr } %t108, 0
  %t111 = add i64 %t107, %t110
  %t112 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t111)
  call void @olang_textcopy(ptr %t112, ptr %t92, i64 %t93)
  %t113 = getelementptr i8, ptr %t112, i64 %t93
  call void @olang_textcopy(ptr %t113, ptr %t95, i64 %t96)
  %t114 = getelementptr i8, ptr %t113, i64 %t96
  call void @olang_textcopy(ptr %t114, ptr %t98, i64 %t99)
  %t115 = getelementptr i8, ptr %t114, i64 %t99
  call void @olang_textcopy(ptr %t115, ptr %t102, i64 %t103)
  %t116 = getelementptr i8, ptr %t115, i64 %t103
  call void @olang_textcopy(ptr %t116, ptr %t105, i64 %t106)
  %t117 = getelementptr i8, ptr %t116, i64 %t106
  call void @olang_textcopy(ptr %t117, ptr %t109, i64 %t110)
  %t118 = insertvalue { i64, ptr } undef, i64 %t111, 0
  %t119 = insertvalue { i64, ptr } %t118, ptr %t112, 1
  %t121 = extractvalue { i64, ptr } %t119, 0
  %t122 = extractvalue { i64, ptr } %t119, 1
  %t123 = mul i64 %t121, 1
  %t124 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t123)
  call void @llvm.memcpy.p0.p0.i64(ptr %t124, ptr %t122, i64 %t123, i1 false)
  %t125 = insertvalue { i64, ptr } undef, i64 %t121, 0
  %t126 = insertvalue { i64, ptr } %t125, ptr %t124, 1
  %t127 = load ptr, ptr %l70, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s5, ptr %t127, { i64, ptr } %t126)
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s5)
  br label %bb159
bb24:
  %t129 = load { i64, [8 x i64] }, ptr %l1
  %t131 = extractvalue { i64, [8 x i64] } %t129, 0
  %t132 = icmp eq i64 %t131, 3
  br i1 %t132, label %bb25, label %bb26
bb25:
  %t134 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t135 = getelementptr { { i64, [4 x i64] }, %"compiler/mir:Range", i32 }, ptr %t134, i32 0, i32 0
  %t136 = load { i64, [4 x i64] }, ptr %t135
  store { i64, [4 x i64] } %t136, ptr %l7
  %t138 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t139 = getelementptr { { i64, [4 x i64] }, %"compiler/mir:Range", i32 }, ptr %t138, i32 0, i32 1
  %t140 = load %"compiler/mir:Range", ptr %t139
  store %"compiler/mir:Range" %t140, ptr %l8
  %t142 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t143 = getelementptr { { i64, [4 x i64] }, %"compiler/mir:Range", i32 }, ptr %t142, i32 0, i32 2
  %t144 = load i32, ptr %t143
  store i32 %t144, ptr %l9, !tbaa !23
  br label %bb27
bb26:
  br label %bb53
bb27:
  store %olang.scope zeroinitializer, ptr %s7
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t147 = load { i64, [4 x i64] }, ptr %l7
  %t150 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eotype(ptr %v0, ptr %t146, { i64, [4 x i64] } %t147)
  store i32 %t150, ptr %l88
  br label %bb28
bb28:
  %t151 = load i32, ptr %l88, !tbaa !23
  store i32 %t151, ptr %l10, !tbaa !23
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t153 = load i32, ptr %l10, !tbaa !23
  %t156 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s7, ptr %t152, i32 %t153)
  store { i64, ptr } %t156, ptr %l91
  br label %bb29
bb29:
  %t157 = load { i64, ptr }, ptr %l91, !tbaa !27
  store { i64, ptr } %t157, ptr %l11, !tbaa !27
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t159 = load { i64, [4 x i64] }, ptr %l7
  %t160 = load i32, ptr %l10, !tbaa !23
  %t164 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s7, ptr %t158, { i64, [4 x i64] } %t159, i32 %t160)
  store { i64, ptr } %t164, ptr %l95
  br label %bb30
bb30:
  %t165 = load { i64, ptr }, ptr %l95, !tbaa !27
  store { i64, ptr } %t165, ptr %l12, !tbaa !27
  %t166 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s7)
  store %"std/prelude/text:StringBuilder" %t166, ptr %l96
  br label %bb31
bb31:
  %t167 = load %"std/prelude/text:StringBuilder", ptr %l96
  store %"std/prelude/text:StringBuilder" %t167, ptr %l13
  store ptr %l13, ptr %l97, !tbaa !29
  %t168 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t168, ptr %l98, !tbaa !27
  %t169 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t169, ptr %l99, !tbaa !27
  %t170 = load i32, ptr %l9, !tbaa !23
  %t172 = call { i64, ptr } @compiler_2femit_2eblockName(ptr %s7, i32 %t170)
  store { i64, ptr } %t172, ptr %l101
  br label %bb32
bb32:
  %t173 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d524, i32 0, i32 1) }, 1
  %t174 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d524, i32 0, i32 1) }, 0
  %t175 = load { i64, ptr }, ptr %l98, !tbaa !27
  %t176 = extractvalue { i64, ptr } %t175, 1
  %t177 = extractvalue { i64, ptr } %t175, 0
  %t178 = add i64 %t174, %t177
  %t179 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d525, i32 0, i32 1) }, 1
  %t180 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d525, i32 0, i32 1) }, 0
  %t181 = add i64 %t178, %t180
  %t182 = load { i64, ptr }, ptr %l99, !tbaa !27
  %t183 = extractvalue { i64, ptr } %t182, 1
  %t184 = extractvalue { i64, ptr } %t182, 0
  %t185 = add i64 %t181, %t184
  %t186 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d526, i32 0, i32 1) }, 1
  %t187 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d526, i32 0, i32 1) }, 0
  %t188 = add i64 %t185, %t187
  %t189 = load { i64, ptr }, ptr %l101, !tbaa !27
  %t190 = extractvalue { i64, ptr } %t189, 1
  %t191 = extractvalue { i64, ptr } %t189, 0
  %t192 = add i64 %t188, %t191
  %t193 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d527, i32 0, i32 1) }, 1
  %t194 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d527, i32 0, i32 1) }, 0
  %t195 = add i64 %t192, %t194
  %t196 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t195)
  call void @olang_textcopy(ptr %t196, ptr %t173, i64 %t174)
  %t197 = getelementptr i8, ptr %t196, i64 %t174
  call void @olang_textcopy(ptr %t197, ptr %t176, i64 %t177)
  %t198 = getelementptr i8, ptr %t197, i64 %t177
  call void @olang_textcopy(ptr %t198, ptr %t179, i64 %t180)
  %t199 = getelementptr i8, ptr %t198, i64 %t180
  call void @olang_textcopy(ptr %t199, ptr %t183, i64 %t184)
  %t200 = getelementptr i8, ptr %t199, i64 %t184
  call void @olang_textcopy(ptr %t200, ptr %t186, i64 %t187)
  %t201 = getelementptr i8, ptr %t200, i64 %t187
  call void @olang_textcopy(ptr %t201, ptr %t190, i64 %t191)
  %t202 = getelementptr i8, ptr %t201, i64 %t191
  call void @olang_textcopy(ptr %t202, ptr %t193, i64 %t194)
  %t203 = insertvalue { i64, ptr } undef, i64 %t195, 0
  %t204 = insertvalue { i64, ptr } %t203, ptr %t196, 1
  %t206 = extractvalue { i64, ptr } %t204, 0
  %t207 = extractvalue { i64, ptr } %t204, 1
  %t208 = mul i64 %t206, 1
  %t209 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t208)
  call void @llvm.memcpy.p0.p0.i64(ptr %t209, ptr %t207, i64 %t208, i1 false)
  %t210 = insertvalue { i64, ptr } undef, i64 %t206, 0
  %t211 = insertvalue { i64, ptr } %t210, ptr %t209, 1
  %t212 = load ptr, ptr %l97, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s7, ptr %s7, ptr %t212, { i64, ptr } %t211)
  br label %bb33
bb33:
  store i32 0, ptr %l14, !tbaa !23
  %t214 = getelementptr %"compiler/mir:Range", ptr %l8, i32 0, i32 1
  %t215 = load i32, ptr %t214, !tbaa !23
  store i32 %t215, ptr %l15, !tbaa !23
  store i32 1, ptr %l16, !tbaa !23
  %t217 = load i32, ptr %l15, !tbaa !23
  %t218 = load i32, ptr %l14, !tbaa !23
  %t221 = icmp sgt i32 %t217, %t218
  br i1 %t221, label %bb34, label %bb35
bb34:
  %t223 = load i32, ptr %l16, !tbaa !23
  %t225 = icmp sgt i32 %t223, 0
  br i1 %t225, label %bb36, label %bb37
bb35:
  store i32 0, ptr %l108, !tbaa !23
  br label %bb39
bb36:
  %t227 = load i32, ptr %l15, !tbaa !23
  %t228 = load i32, ptr %l14, !tbaa !23
  %t231 = sub i32 %t227, %t228
  %t232 = load i32, ptr %l16, !tbaa !23
  %t235 = add i32 %t231, %t232
  %t237 = sub i32 %t235, 1
  %t238 = load i32, ptr %l16, !tbaa !23
  %t241 = sdiv i32 %t237, %t238
  store i32 %t241, ptr %l111, !tbaa !23
  br label %bb38
bb37:
  store i32 0, ptr %l111, !tbaa !23
  br label %bb38
bb38:
  %t243 = load i32, ptr %l111, !tbaa !23
  store i32 %t243, ptr %l108, !tbaa !23
  br label %bb39
bb39:
  %t244 = load i32, ptr %l108, !tbaa !23
  store i32 %t244, ptr %l17, !tbaa !23
  store i32 0, ptr %l18, !tbaa !23
  br label %bb40
bb40:
  store %olang.scope zeroinitializer, ptr %s10
  %t245 = load i32, ptr %l18, !tbaa !23
  %t246 = load i32, ptr %l17, !tbaa !23
  %t249 = icmp slt i32 %t245, %t246
  %t251 = xor i1 %t249, true
  br i1 %t251, label %bb41, label %bb42
bb41:
  call void @__olang_scope_close(ptr %s10)
  br label %bb49
bb42:
  br label %bb43
bb43:
  %t253 = load i32, ptr %l14, !tbaa !23
  %t254 = load i32, ptr %l18, !tbaa !23
  %t255 = load i32, ptr %l16, !tbaa !23
  %t258 = mul i32 %t254, %t255
  %t261 = add i32 %t253, %t258
  %t263 = load ptr, ptr %l0, !tbaa !29
  %t265 = getelementptr %"compiler/emit:fnEm", ptr %t263, i32 0, i32 1
  %t266 = load ptr, ptr %t265, !tbaa !29
  %t268 = getelementptr %"compiler/mir:Fn", ptr %t266, i32 0, i32 15
  %t269 = getelementptr %"compiler/mir:Range", ptr %l8, i32 0, i32 0
  %t270 = load i32, ptr %t269, !tbaa !23
  %t272 = sext i32 %t270 to i64
  %t275 = sext i32 %t261 to i64
  %t278 = add i64 %t272, %t275
  %t281 = call %"compiler/mir:Case" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCase_3e_2eAt_3ccompiler_2fmir_3aCase_3e(ptr %v0, ptr %t268, i64 %t278)
  store %"compiler/mir:Case" %t281, ptr %l137
  br label %bb44
bb44:
  %t282 = load %"compiler/mir:Case", ptr %l137
  store %"compiler/mir:Case" %t282, ptr %l20
  store ptr %l13, ptr %l138, !tbaa !29
  %t283 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t283, ptr %l139, !tbaa !27
  %t284 = load ptr, ptr %l0, !tbaa !29
  %t286 = getelementptr %"compiler/emit:fnEm", ptr %t284, i32 0, i32 0
  %t287 = load ptr, ptr %t286, !tbaa !29
  %t288 = load i32, ptr %l10, !tbaa !23
  %t289 = getelementptr %"compiler/mir:Case", ptr %l20, i32 0, i32 0
  %t290 = load i64, ptr %t289, !tbaa !24
  %t294 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2econstText(ptr %v0, ptr %s10, ptr %t287, i32 %t288, i64 %t290)
  store { i64, ptr } %t294, ptr %l144
  br label %bb45
bb45:
  %t295 = getelementptr %"compiler/mir:Case", ptr %l20, i32 0, i32 1
  %t296 = load i32, ptr %t295, !tbaa !23
  %t298 = call { i64, ptr } @compiler_2femit_2eblockName(ptr %s10, i32 %t296)
  store { i64, ptr } %t298, ptr %l146
  br label %bb46
bb46:
  %t299 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d528, i32 0, i32 1) }, 1
  %t300 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d528, i32 0, i32 1) }, 0
  %t301 = load { i64, ptr }, ptr %l139, !tbaa !27
  %t302 = extractvalue { i64, ptr } %t301, 1
  %t303 = extractvalue { i64, ptr } %t301, 0
  %t304 = add i64 %t300, %t303
  %t305 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d528, i32 0, i32 1) }, 1
  %t306 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d528, i32 0, i32 1) }, 0
  %t307 = add i64 %t304, %t306
  %t308 = load { i64, ptr }, ptr %l144, !tbaa !27
  %t309 = extractvalue { i64, ptr } %t308, 1
  %t310 = extractvalue { i64, ptr } %t308, 0
  %t311 = add i64 %t307, %t310
  %t312 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d529, i32 0, i32 1) }, 1
  %t313 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d529, i32 0, i32 1) }, 0
  %t314 = add i64 %t311, %t313
  %t315 = load { i64, ptr }, ptr %l146, !tbaa !27
  %t316 = extractvalue { i64, ptr } %t315, 1
  %t317 = extractvalue { i64, ptr } %t315, 0
  %t318 = add i64 %t314, %t317
  %t319 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t318)
  call void @olang_textcopy(ptr %t319, ptr %t299, i64 %t300)
  %t320 = getelementptr i8, ptr %t319, i64 %t300
  call void @olang_textcopy(ptr %t320, ptr %t302, i64 %t303)
  %t321 = getelementptr i8, ptr %t320, i64 %t303
  call void @olang_textcopy(ptr %t321, ptr %t305, i64 %t306)
  %t322 = getelementptr i8, ptr %t321, i64 %t306
  call void @olang_textcopy(ptr %t322, ptr %t309, i64 %t310)
  %t323 = getelementptr i8, ptr %t322, i64 %t310
  call void @olang_textcopy(ptr %t323, ptr %t312, i64 %t313)
  %t324 = getelementptr i8, ptr %t323, i64 %t313
  call void @olang_textcopy(ptr %t324, ptr %t316, i64 %t317)
  %t325 = insertvalue { i64, ptr } undef, i64 %t318, 0
  %t326 = insertvalue { i64, ptr } %t325, ptr %t319, 1
  %t328 = extractvalue { i64, ptr } %t326, 0
  %t329 = extractvalue { i64, ptr } %t326, 1
  %t330 = mul i64 %t328, 1
  %t331 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t330)
  call void @llvm.memcpy.p0.p0.i64(ptr %t331, ptr %t329, i64 %t330, i1 false)
  %t332 = insertvalue { i64, ptr } undef, i64 %t328, 0
  %t333 = insertvalue { i64, ptr } %t332, ptr %t331, 1
  %t334 = load ptr, ptr %l138, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s7, ptr %s10, ptr %t334, { i64, ptr } %t333)
  br label %bb47
bb47:
  call void @__olang_scope_close(ptr %s10)
  br label %bb48
bb48:
  %t336 = load i32, ptr %l18, !tbaa !23
  %t338 = add i32 %t336, 1
  store i32 %t338, ptr %l18, !tbaa !23
  br label %bb40
bb49:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s7, ptr %s7, ptr %l13, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d530, i32 0, i32 1) })
  br label %bb50
bb50:
  %t341 = load ptr, ptr %l0, !tbaa !29
  store ptr %t341, ptr %l152, !tbaa !29
  %t343 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s7, ptr %s7, ptr %l13)
  store { i64, ptr } %t343, ptr %l154
  br label %bb51
bb51:
  %t344 = load { i64, ptr }, ptr %l154, !tbaa !27
  %t345 = extractvalue { i64, ptr } %t344, 0
  %t346 = extractvalue { i64, ptr } %t344, 1
  %t347 = mul i64 %t345, 1
  %t348 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t347)
  call void @llvm.memcpy.p0.p0.i64(ptr %t348, ptr %t346, i64 %t347, i1 false)
  %t349 = insertvalue { i64, ptr } undef, i64 %t345, 0
  %t350 = insertvalue { i64, ptr } %t349, ptr %t348, 1
  %t351 = load ptr, ptr %l152, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s7, ptr %t351, { i64, ptr } %t350)
  br label %bb52
bb52:
  call void @__olang_scope_close(ptr %s7)
  br label %bb159
bb53:
  %t353 = load { i64, [8 x i64] }, ptr %l1
  %t355 = extractvalue { i64, [8 x i64] } %t353, 0
  %t356 = icmp eq i64 %t355, 4
  br i1 %t356, label %bb54, label %bb55
bb54:
  %t358 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t359 = getelementptr { %"compiler/source:Span", i32 }, ptr %t358, i32 0, i32 1
  %t360 = load i32, ptr %t359
  store i32 %t360, ptr %l21, !tbaa !23
  br label %bb56
bb55:
  br label %bb59
bb56:
  %t362 = load ptr, ptr %l0, !tbaa !29
  %t363 = load i32, ptr %l21, !tbaa !23
  %t365 = sext i32 %t363 to i64
  %t368 = getelementptr %"compiler/emit:fnEm", ptr %t362, i32 0, i32 38
  store i64 %t365, ptr %t368, !tbaa !24
  %t369 = load ptr, ptr %l0, !tbaa !29
  store ptr %t369, ptr %l162, !tbaa !29
  %t370 = load ptr, ptr %l0, !tbaa !29
  %t372 = getelementptr %"compiler/emit:fnEm", ptr %t370, i32 0, i32 1
  %t373 = load ptr, ptr %t372, !tbaa !29
  %t375 = getelementptr %"compiler/mir:Fn", ptr %t373, i32 0, i32 14
  %t376 = load i32, ptr %l21, !tbaa !23
  %t378 = sext i32 %t376 to i64
  %t381 = call %"compiler/mir:Call" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e_2eAt_3ccompiler_2fmir_3aCall_3e(ptr %v0, ptr %t375, i64 %t378)
  store %"compiler/mir:Call" %t381, ptr %l168
  br label %bb57
bb57:
  %t382 = load ptr, ptr %l162, !tbaa !29
  %t383 = load %"compiler/mir:Call", ptr %l168
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ecall(ptr %v0, ptr %t382, %"compiler/mir:Call" %t383)
  br label %bb58
bb58:
  br label %bb159
bb59:
  %t384 = load { i64, [8 x i64] }, ptr %l1
  %t386 = extractvalue { i64, [8 x i64] } %t384, 0
  %t387 = icmp eq i64 %t386, 6
  br i1 %t387, label %bb60, label %bb61
bb60:
  %t389 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t390 = getelementptr { %"compiler/source:Span", i32 }, ptr %t389, i32 0, i32 1
  %t391 = load i32, ptr %t390
  store i32 %t391, ptr %l22, !tbaa !23
  br label %bb62
bb61:
  br label %bb65
bb62:
  %t393 = load ptr, ptr %l0, !tbaa !29
  %t394 = load i32, ptr %l22, !tbaa !23
  %t396 = sext i32 %t394 to i64
  %t399 = getelementptr %"compiler/emit:fnEm", ptr %t393, i32 0, i32 38
  store i64 %t396, ptr %t399, !tbaa !24
  %t400 = load ptr, ptr %l0, !tbaa !29
  store ptr %t400, ptr %l175, !tbaa !29
  %t401 = load ptr, ptr %l0, !tbaa !29
  %t403 = getelementptr %"compiler/emit:fnEm", ptr %t401, i32 0, i32 1
  %t404 = load ptr, ptr %t403, !tbaa !29
  %t406 = getelementptr %"compiler/mir:Fn", ptr %t404, i32 0, i32 14
  %t407 = load i32, ptr %l22, !tbaa !23
  %t409 = sext i32 %t407 to i64
  %t412 = call %"compiler/mir:Call" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e_2eAt_3ccompiler_2fmir_3aCall_3e(ptr %v0, ptr %t406, i64 %t409)
  store %"compiler/mir:Call" %t412, ptr %l181
  br label %bb63
bb63:
  %t413 = load ptr, ptr %l175, !tbaa !29
  %t414 = load %"compiler/mir:Call", ptr %l181
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2etailCall(ptr %v0, ptr %t413, %"compiler/mir:Call" %t414)
  br label %bb64
bb64:
  br label %bb159
bb65:
  %t415 = load { i64, [8 x i64] }, ptr %l1
  %t417 = extractvalue { i64, [8 x i64] } %t415, 0
  %t418 = icmp eq i64 %t417, 5
  br i1 %t418, label %bb66, label %bb67
bb66:
  %t420 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t421 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] } }, ptr %t420, i32 0, i32 1
  %t422 = load { i64, [4 x i64] }, ptr %t421
  store { i64, [4 x i64] } %t422, ptr %l23
  br label %bb68
bb67:
  br label %bb96
bb68:
  store %olang.scope zeroinitializer, ptr %s15
  %t424 = load ptr, ptr %l2, !tbaa !29
  %t425 = load ptr, ptr %l0, !tbaa !29
  %t427 = getelementptr %"compiler/emit:fnEm", ptr %t425, i32 0, i32 1
  %t428 = load ptr, ptr %t427, !tbaa !29
  %t430 = getelementptr %"compiler/mir:Fn", ptr %t428, i32 0, i32 1
  %t431 = load i32, ptr %t430, !tbaa !23
  %t433 = inttoptr i64 0 to ptr
  %t436 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRetLlvm(ptr %v0, ptr %s15, ptr %t433, ptr %t424, i32 %t431)
  store { i64, ptr } %t436, ptr %l190
  br label %bb69
bb69:
  %t437 = load { i64, ptr }, ptr %l190, !tbaa !27
  store { i64, ptr } %t437, ptr %l24, !tbaa !27
  %t438 = load ptr, ptr %l0, !tbaa !29
  %t440 = getelementptr %"compiler/emit:fnEm", ptr %t438, i32 0, i32 11
  %t441 = load i1, ptr %t440, !tbaa !21
  br i1 %t441, label %bb70, label %bb71
bb70:
  store %olang.scope zeroinitializer, ptr %s16
  %t443 = load ptr, ptr %l0, !tbaa !29
  %t444 = load ptr, ptr %l0, !tbaa !29
  %t446 = getelementptr %"compiler/emit:fnEm", ptr %t444, i32 0, i32 9
  %t447 = load i32, ptr %t446, !tbaa !23
  %t448 = load { i64, [4 x i64] }, ptr %l23
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2eput(ptr %v0, ptr %s16, ptr %s16, ptr %t443, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d531, i32 0, i32 1) }, i32 %t447, { i64, [4 x i64] } %t448, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d470, i32 0, i32 1) })
  br label %bb72
bb71:
  %t452 = load ptr, ptr %l0, !tbaa !29
  %t454 = getelementptr %"compiler/emit:fnEm", ptr %t452, i32 0, i32 10
  %t455 = load i1, ptr %t454, !tbaa !21
  br i1 %t455, label %bb77, label %bb78
bb72:
  %t457 = load ptr, ptr %l0, !tbaa !29
  %t459 = getelementptr %"compiler/emit:fnEm", ptr %t457, i32 0, i32 10
  %t460 = load i1, ptr %t459, !tbaa !21
  br i1 %t460, label %bb73, label %bb74
bb73:
  store %olang.scope zeroinitializer, ptr %s17
  %t462 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s17, ptr %s17, ptr %s17, ptr %s17, ptr %t462, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d532, i32 0, i32 1) }, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d533, i32 0, i32 1) }, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d534, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d220, i32 0, i32 1) })
  br label %bb75
bb74:
  br label %bb76
bb75:
  call void @__olang_scope_close(ptr %s17)
  br label %bb76
bb76:
  call void @__olang_scope_close(ptr %s16)
  br label %bb94
bb77:
  %t464 = load ptr, ptr %l0, !tbaa !29
  %t466 = getelementptr %"compiler/emit:fnEm", ptr %t464, i32 0, i32 9
  %t467 = load i32, ptr %t466, !tbaa !23
  %t468 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t471 = icmp eq i32 %t467, %t468
  br i1 %t471, label %bb79, label %bb80
bb78:
  store %olang.scope zeroinitializer, ptr %s23
  %t473 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t475 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s15, ptr %s23, { i64, ptr } %t473, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d535, i32 0, i32 1) })
  store i1 %t475, ptr %l225
  br label %bb87
bb79:
  store %olang.scope zeroinitializer, ptr %s20
  %t476 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s20, ptr %s20, ptr %s20, ptr %s20, ptr %t476, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d536, i32 0, i32 1) }, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d537, i32 0, i32 1) }, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d538, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d220, i32 0, i32 1) })
  br label %bb81
bb80:
  store %olang.scope zeroinitializer, ptr %s21
  %t478 = load ptr, ptr %l0, !tbaa !29
  store ptr %t478, ptr %l207, !tbaa !29
  %t479 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t479, ptr %l208, !tbaa !27
  %t480 = load ptr, ptr %l0, !tbaa !29
  %t481 = load ptr, ptr %l0, !tbaa !29
  %t483 = getelementptr %"compiler/emit:fnEm", ptr %t481, i32 0, i32 9
  %t484 = load i32, ptr %t483, !tbaa !23
  %t487 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s21, ptr %t480, i32 %t484)
  store { i64, ptr } %t487, ptr %l212
  br label %bb82
bb81:
  call void @__olang_scope_close(ptr %s20)
  br label %bb86
bb82:
  %t488 = load ptr, ptr %l0, !tbaa !29
  %t489 = load { i64, [4 x i64] }, ptr %l23
  %t490 = load ptr, ptr %l0, !tbaa !29
  %t492 = getelementptr %"compiler/emit:fnEm", ptr %t490, i32 0, i32 9
  %t493 = load i32, ptr %t492, !tbaa !23
  %t497 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s21, ptr %t488, { i64, [4 x i64] } %t489, i32 %t493)
  store { i64, ptr } %t497, ptr %l217
  br label %bb83
bb83:
  %t498 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d539, i32 0, i32 1) }, 1
  %t499 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d539, i32 0, i32 1) }, 0
  %t500 = load { i64, ptr }, ptr %l208, !tbaa !27
  %t501 = extractvalue { i64, ptr } %t500, 1
  %t502 = extractvalue { i64, ptr } %t500, 0
  %t503 = add i64 %t499, %t502
  %t504 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d540, i32 0, i32 1) }, 1
  %t505 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d540, i32 0, i32 1) }, 0
  %t506 = add i64 %t503, %t505
  %t507 = load { i64, ptr }, ptr %l212, !tbaa !27
  %t508 = extractvalue { i64, ptr } %t507, 1
  %t509 = extractvalue { i64, ptr } %t507, 0
  %t510 = add i64 %t506, %t509
  %t511 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d541, i32 0, i32 1) }, 1
  %t512 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d541, i32 0, i32 1) }, 0
  %t513 = add i64 %t510, %t512
  %t514 = load { i64, ptr }, ptr %l217, !tbaa !27
  %t515 = extractvalue { i64, ptr } %t514, 1
  %t516 = extractvalue { i64, ptr } %t514, 0
  %t517 = add i64 %t513, %t516
  %t518 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d542, i32 0, i32 1) }, 1
  %t519 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d542, i32 0, i32 1) }, 0
  %t520 = add i64 %t517, %t519
  %t521 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t520)
  call void @olang_textcopy(ptr %t521, ptr %t498, i64 %t499)
  %t522 = getelementptr i8, ptr %t521, i64 %t499
  call void @olang_textcopy(ptr %t522, ptr %t501, i64 %t502)
  %t523 = getelementptr i8, ptr %t522, i64 %t502
  call void @olang_textcopy(ptr %t523, ptr %t504, i64 %t505)
  %t524 = getelementptr i8, ptr %t523, i64 %t505
  call void @olang_textcopy(ptr %t524, ptr %t508, i64 %t509)
  %t525 = getelementptr i8, ptr %t524, i64 %t509
  call void @olang_textcopy(ptr %t525, ptr %t511, i64 %t512)
  %t526 = getelementptr i8, ptr %t525, i64 %t512
  call void @olang_textcopy(ptr %t526, ptr %t515, i64 %t516)
  %t527 = getelementptr i8, ptr %t526, i64 %t516
  call void @olang_textcopy(ptr %t527, ptr %t518, i64 %t519)
  %t528 = insertvalue { i64, ptr } undef, i64 %t520, 0
  %t529 = insertvalue { i64, ptr } %t528, ptr %t521, 1
  %t531 = extractvalue { i64, ptr } %t529, 0
  %t532 = extractvalue { i64, ptr } %t529, 1
  %t533 = mul i64 %t531, 1
  %t534 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t533)
  call void @llvm.memcpy.p0.p0.i64(ptr %t534, ptr %t532, i64 %t533, i1 false)
  %t535 = insertvalue { i64, ptr } undef, i64 %t531, 0
  %t536 = insertvalue { i64, ptr } %t535, ptr %t534, 1
  %t537 = load ptr, ptr %l207, !tbaa !29
  %t539 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s21, ptr %s21, ptr %t537, { i64, ptr } %t536)
  store { i64, ptr } %t539, ptr %l220
  br label %bb84
bb84:
  %t540 = load { i64, ptr }, ptr %l220, !tbaa !27
  %t541 = load ptr, ptr %l0, !tbaa !29
  %t542 = load { i64, ptr }, ptr %l24, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s15, ptr %s21, ptr %s21, ptr %s21, ptr %t541, { i64, ptr } %t542, { i64, ptr } %t540, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d543, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d220, i32 0, i32 1) })
  br label %bb85
bb85:
  call void @__olang_scope_close(ptr %s21)
  br label %bb86
bb86:
  br label %bb93
bb87:
  %t547 = load i1, ptr %l225, !tbaa !21
  %t548 = xor i1 %t547, true
  br i1 %t548, label %bb88, label %bb89
bb88:
  store %olang.scope zeroinitializer, ptr %s24
  %t550 = load ptr, ptr %l0, !tbaa !29
  store ptr %t550, ptr %l227, !tbaa !29
  %t551 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t551, ptr %l228, !tbaa !27
  %t552 = load ptr, ptr %l0, !tbaa !29
  %t553 = load { i64, [4 x i64] }, ptr %l23
  %t554 = load ptr, ptr %l0, !tbaa !29
  %t556 = getelementptr %"compiler/emit:fnEm", ptr %t554, i32 0, i32 9
  %t557 = load i32, ptr %t556, !tbaa !23
  %t561 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s24, ptr %t552, { i64, [4 x i64] } %t553, i32 %t557)
  store { i64, ptr } %t561, ptr %l233
  br label %bb90
bb89:
  br label %bb92
bb90:
  %t562 = load { i64, ptr }, ptr %l233, !tbaa !27
  %t563 = extractvalue { i64, ptr } %t562, 0
  %t564 = extractvalue { i64, ptr } %t562, 1
  %t565 = mul i64 %t563, 1
  %t566 = call ptr @__olang_scope_alloc(ptr %s24, i64 %t565)
  call void @llvm.memcpy.p0.p0.i64(ptr %t566, ptr %t564, i64 %t565, i1 false)
  %t567 = insertvalue { i64, ptr } undef, i64 %t563, 0
  %t568 = insertvalue { i64, ptr } %t567, ptr %t566, 1
  %t569 = load ptr, ptr %l227, !tbaa !29
  %t570 = load { i64, ptr }, ptr %l228, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s15, ptr %s24, ptr %s24, ptr %s24, ptr %t569, { i64, ptr } %t570, { i64, ptr } %t568, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d544, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d220, i32 0, i32 1) })
  br label %bb91
bb91:
  call void @__olang_scope_close(ptr %s24)
  br label %bb92
bb92:
  call void @__olang_scope_close(ptr %s23)
  br label %bb93
bb93:
  br label %bb94
bb94:
  %t572 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s15, ptr %t572, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d545, i32 0, i32 1) })
  br label %bb95
bb95:
  call void @__olang_scope_close(ptr %s15)
  br label %bb159
bb96:
  %t574 = load { i64, [8 x i64] }, ptr %l1
  %t576 = extractvalue { i64, [8 x i64] } %t574, 0
  %t577 = icmp eq i64 %t576, 11
  br i1 %t577, label %bb97, label %bb98
bb97:
  %t579 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t580 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] }, i32, %"compiler/mir:Range", i32 }, ptr %t579, i32 0, i32 1
  %t581 = load { i64, [4 x i64] }, ptr %t580
  store { i64, [4 x i64] } %t581, ptr %l26
  %t583 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t584 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] }, i32, %"compiler/mir:Range", i32 }, ptr %t583, i32 0, i32 2
  %t585 = load i32, ptr %t584
  store i32 %t585, ptr %l27, !tbaa !23
  %t587 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t588 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] }, i32, %"compiler/mir:Range", i32 }, ptr %t587, i32 0, i32 3
  %t589 = load %"compiler/mir:Range", ptr %t588
  store %"compiler/mir:Range" %t589, ptr %l28
  %t591 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t592 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] }, i32, %"compiler/mir:Range", i32 }, ptr %t591, i32 0, i32 4
  %t593 = load i32, ptr %t592
  store i32 %t593, ptr %l29, !tbaa !23
  br label %bb99
bb98:
  br label %bb101
bb99:
  %t595 = load ptr, ptr %l0, !tbaa !29
  %t596 = load { i64, [4 x i64] }, ptr %l26
  %t597 = load i32, ptr %l27, !tbaa !23
  %t598 = load %"compiler/mir:Range", ptr %l28
  %t599 = load i32, ptr %l29, !tbaa !23
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2esuspend(ptr %v0, ptr %t595, { i64, [4 x i64] } %t596, i32 %t597, %"compiler/mir:Range" %t598, i32 %t599)
  br label %bb100
bb100:
  br label %bb159
bb101:
  %t605 = load { i64, [8 x i64] }, ptr %l1
  %t607 = extractvalue { i64, [8 x i64] } %t605, 0
  %t608 = icmp eq i64 %t607, 12
  br i1 %t608, label %bb102, label %bb103
bb102:
  br label %bb104
bb103:
  br label %bb106
bb104:
  store %olang.scope zeroinitializer, ptr %s26
  %t610 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s26, ptr %t610, { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d546, i32 0, i32 1) })
  br label %bb105
bb105:
  call void @__olang_scope_close(ptr %s26)
  br label %bb159
bb106:
  %t612 = load { i64, [8 x i64] }, ptr %l1
  %t614 = extractvalue { i64, [8 x i64] } %t612, 0
  %t615 = icmp eq i64 %t614, 7
  br i1 %t615, label %bb107, label %bb108
bb107:
  %t617 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t618 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] } }, ptr %t617, i32 0, i32 0
  %t619 = load %"compiler/source:Span", ptr %t618
  store %"compiler/source:Span" %t619, ptr %l30
  %t621 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t622 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] } }, ptr %t621, i32 0, i32 1
  %t623 = load { i64, [4 x i64] }, ptr %t622
  store { i64, [4 x i64] } %t623, ptr %l31
  br label %bb109
bb108:
  br label %bb121
bb109:
  store %olang.scope zeroinitializer, ptr %s27
  %t625 = load ptr, ptr %l0, !tbaa !29
  %t626 = load %"compiler/source:Span", ptr %l30
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2etrace(ptr %v0, ptr %t625, %"compiler/source:Span" %t626)
  br label %bb110
bb110:
  %t629 = load ptr, ptr %l2, !tbaa !29
  %t630 = load ptr, ptr %l0, !tbaa !29
  %t632 = getelementptr %"compiler/emit:fnEm", ptr %t630, i32 0, i32 1
  %t633 = load ptr, ptr %t632, !tbaa !29
  %t635 = getelementptr %"compiler/mir:Fn", ptr %t633, i32 0, i32 1
  %t636 = load i32, ptr %t635, !tbaa !23
  %t638 = inttoptr i64 0 to ptr
  %t641 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRetLlvm(ptr %v0, ptr %s27, ptr %t638, ptr %t629, i32 %t636)
  store { i64, ptr } %t641, ptr %l261
  br label %bb111
bb111:
  %t642 = load { i64, ptr }, ptr %l261, !tbaa !27
  store { i64, ptr } %t642, ptr %l32, !tbaa !27
  %t643 = load ptr, ptr %l0, !tbaa !29
  %t644 = load { i64, [4 x i64] }, ptr %l31
  %t645 = load i32, ptr @G_2ecompiler_2fmir_2eI32T, !tbaa !23
  %t649 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s27, ptr %t643, { i64, [4 x i64] } %t644, i32 %t645)
  store { i64, ptr } %t649, ptr %l265
  br label %bb112
bb112:
  %t650 = load { i64, ptr }, ptr %l265, !tbaa !27
  store { i64, ptr } %t650, ptr %l33, !tbaa !27
  %t651 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t653 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s27, ptr %s27, { i64, ptr } %t651, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d547, i32 0, i32 1) })
  store i1 %t653, ptr %l267
  br label %bb113
bb113:
  %t654 = load i1, ptr %l267, !tbaa !21
  br i1 %t654, label %bb114, label %bb115
bb114:
  store %olang.scope zeroinitializer, ptr %s28
  %t655 = load ptr, ptr %l0, !tbaa !29
  %t656 = load { i64, ptr }, ptr %l33, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s28, ptr %s27, ptr %s28, ptr %s28, ptr %t655, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d548, i32 0, i32 1) }, { i64, ptr } %t656, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d549, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d220, i32 0, i32 1) })
  br label %bb116
bb115:
  store %olang.scope zeroinitializer, ptr %s29
  %t659 = load ptr, ptr %l0, !tbaa !29
  store ptr %t659, ptr %l270, !tbaa !29
  %t660 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t660, ptr %l271, !tbaa !27
  %t661 = load ptr, ptr %l0, !tbaa !29
  %t662 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t663 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t664 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d550, i32 0, i32 1) }, 1
  %t665 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d550, i32 0, i32 1) }, 0
  %t667 = extractvalue { i64, ptr } %t662, 1
  %t668 = extractvalue { i64, ptr } %t662, 0
  %t669 = add i64 %t665, %t668
  %t670 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d551, i32 0, i32 1) }, 1
  %t671 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d551, i32 0, i32 1) }, 0
  %t672 = add i64 %t669, %t671
  %t674 = extractvalue { i64, ptr } %t663, 1
  %t675 = extractvalue { i64, ptr } %t663, 0
  %t676 = add i64 %t672, %t675
  %t677 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d552, i32 0, i32 1) }, 1
  %t678 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d552, i32 0, i32 1) }, 0
  %t679 = add i64 %t676, %t678
  %t680 = call ptr @__olang_scope_alloc(ptr %s29, i64 %t679)
  call void @olang_textcopy(ptr %t680, ptr %t664, i64 %t665)
  %t681 = getelementptr i8, ptr %t680, i64 %t665
  call void @olang_textcopy(ptr %t681, ptr %t667, i64 %t668)
  %t682 = getelementptr i8, ptr %t681, i64 %t668
  call void @olang_textcopy(ptr %t682, ptr %t670, i64 %t671)
  %t683 = getelementptr i8, ptr %t682, i64 %t671
  call void @olang_textcopy(ptr %t683, ptr %t674, i64 %t675)
  %t684 = getelementptr i8, ptr %t683, i64 %t675
  call void @olang_textcopy(ptr %t684, ptr %t677, i64 %t678)
  %t685 = insertvalue { i64, ptr } undef, i64 %t679, 0
  %t686 = insertvalue { i64, ptr } %t685, ptr %t680, 1
  %t688 = extractvalue { i64, ptr } %t686, 0
  %t689 = extractvalue { i64, ptr } %t686, 1
  %t690 = mul i64 %t688, 1
  %t691 = call ptr @__olang_scope_alloc(ptr %s29, i64 %t690)
  call void @llvm.memcpy.p0.p0.i64(ptr %t691, ptr %t689, i64 %t690, i1 false)
  %t692 = insertvalue { i64, ptr } undef, i64 %t688, 0
  %t693 = insertvalue { i64, ptr } %t692, ptr %t691, 1
  %t696 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s29, ptr %s29, ptr %t661, { i64, ptr } %t693)
  store { i64, ptr } %t696, ptr %l277
  br label %bb117
bb116:
  call void @__olang_scope_close(ptr %s28)
  br label %bb119
bb117:
  %t697 = load { i64, ptr }, ptr %l277, !tbaa !27
  %t698 = extractvalue { i64, ptr } %t697, 0
  %t699 = extractvalue { i64, ptr } %t697, 1
  %t700 = mul i64 %t698, 1
  %t701 = call ptr @__olang_scope_alloc(ptr %s29, i64 %t700)
  call void @llvm.memcpy.p0.p0.i64(ptr %t701, ptr %t699, i64 %t700, i1 false)
  %t702 = insertvalue { i64, ptr } undef, i64 %t698, 0
  %t703 = insertvalue { i64, ptr } %t702, ptr %t701, 1
  %t704 = load ptr, ptr %l270, !tbaa !29
  %t705 = load { i64, ptr }, ptr %l271, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s27, ptr %s29, ptr %s29, ptr %s29, ptr %t704, { i64, ptr } %t705, { i64, ptr } %t703, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d553, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d220, i32 0, i32 1) })
  br label %bb118
bb118:
  call void @__olang_scope_close(ptr %s29)
  br label %bb119
bb119:
  %t707 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s27, ptr %t707, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d554, i32 0, i32 1) })
  br label %bb120
bb120:
  call void @__olang_scope_close(ptr %s27)
  br label %bb159
bb121:
  %t709 = load { i64, [8 x i64] }, ptr %l1
  %t711 = extractvalue { i64, [8 x i64] } %t709, 0
  %t712 = icmp eq i64 %t711, 8
  br i1 %t712, label %bb122, label %bb123
bb122:
  %t714 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t715 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t714, i32 0, i32 1
  %t716 = load i32, ptr %t715
  store i32 %t716, ptr %l34, !tbaa !23
  %t718 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t719 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t718, i32 0, i32 2
  %t720 = load i32, ptr %t719
  store i32 %t720, ptr %l35, !tbaa !23
  %t722 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t723 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t722, i32 0, i32 3
  %t724 = load i32, ptr %t723
  store i32 %t724, ptr %l36, !tbaa !23
  %t726 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t727 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t726, i32 0, i32 4
  %t728 = load i32, ptr %t727
  store i32 %t728, ptr %l37, !tbaa !23
  br label %bb124
bb123:
  br label %bb148
bb124:
  store %olang.scope zeroinitializer, ptr %s31
  %t730 = load i32, ptr %l37, !tbaa !23
  %t731 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t734 = icmp ne i32 %t730, %t731
  br i1 %t734, label %bb125, label %bb126
bb125:
  %t736 = load i32, ptr %l37, !tbaa !23
  %t737 = load i32, ptr %l35, !tbaa !23
  %t740 = icmp ne i32 %t736, %t737
  store i1 %t740, ptr %l289, !tbaa !21
  br label %bb127
bb126:
  store i1 false, ptr %l289, !tbaa !21
  br label %bb127
bb127:
  %t742 = load i1, ptr %l289, !tbaa !21
  store i1 %t742, ptr %l38, !tbaa !21
  %t743 = load ptr, ptr %l0, !tbaa !29
  %t745 = getelementptr %"compiler/emit:fnEm", ptr %t743, i32 0, i32 0
  %t746 = load ptr, ptr %t745, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s31, ptr %s31, ptr %t746, { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d555, i32 0, i32 1) }, { i64, ptr } { i64 37, ptr getelementptr inbounds (<{ i64, [37 x i8] }>, ptr @.d556, i32 0, i32 1) })
  br label %bb128
bb128:
  %t748 = load ptr, ptr %l0, !tbaa !29
  store ptr %t748, ptr %l295, !tbaa !29
  %t749 = load i32, ptr %l34, !tbaa !23
  store i32 %t749, ptr %l296, !tbaa !23
  %t750 = load i1, ptr %l38, !tbaa !21
  br i1 %t750, label %bb129, label %bb130
bb129:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d557, i32 0, i32 1) }, ptr %l298, !tbaa !27
  br label %bb131
bb130:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d558, i32 0, i32 1) }, ptr %l298, !tbaa !27
  br label %bb131
bb131:
  %t752 = extractvalue { i64, ptr } { i64 41, ptr getelementptr inbounds (<{ i64, [41 x i8] }>, ptr @.d559, i32 0, i32 1) }, 1
  %t753 = extractvalue { i64, ptr } { i64 41, ptr getelementptr inbounds (<{ i64, [41 x i8] }>, ptr @.d559, i32 0, i32 1) }, 0
  %t754 = load i32, ptr %l296, !tbaa !23
  %t755 = sext i32 %t754 to i64
  %t756 = call i64 @__olang_fmt_i64(ptr null, i64 %t755)
  %t757 = add i64 %t753, %t756
  %t758 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d560, i32 0, i32 1) }, 1
  %t759 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d560, i32 0, i32 1) }, 0
  %t760 = add i64 %t757, %t759
  %t761 = load { i64, ptr }, ptr %l298, !tbaa !27
  %t762 = extractvalue { i64, ptr } %t761, 1
  %t763 = extractvalue { i64, ptr } %t761, 0
  %t764 = add i64 %t760, %t763
  %t765 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d561, i32 0, i32 1) }, 1
  %t766 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d561, i32 0, i32 1) }, 0
  %t767 = add i64 %t764, %t766
  %t768 = call ptr @__olang_scope_alloc(ptr %s31, i64 %t767)
  call void @olang_textcopy(ptr %t768, ptr %t752, i64 %t753)
  %t769 = getelementptr i8, ptr %t768, i64 %t753
  %t770 = call i64 @__olang_fmt_i64(ptr %t769, i64 %t755)
  %t771 = getelementptr i8, ptr %t769, i64 %t756
  call void @olang_textcopy(ptr %t771, ptr %t758, i64 %t759)
  %t772 = getelementptr i8, ptr %t771, i64 %t759
  call void @olang_textcopy(ptr %t772, ptr %t762, i64 %t763)
  %t773 = getelementptr i8, ptr %t772, i64 %t763
  call void @olang_textcopy(ptr %t773, ptr %t765, i64 %t766)
  %t774 = insertvalue { i64, ptr } undef, i64 %t767, 0
  %t775 = insertvalue { i64, ptr } %t774, ptr %t768, 1
  %t777 = extractvalue { i64, ptr } %t775, 0
  %t778 = extractvalue { i64, ptr } %t775, 1
  %t779 = mul i64 %t777, 1
  %t780 = call ptr @__olang_scope_alloc(ptr %s31, i64 %t779)
  call void @llvm.memcpy.p0.p0.i64(ptr %t780, ptr %t778, i64 %t779, i1 false)
  %t781 = insertvalue { i64, ptr } undef, i64 %t777, 0
  %t782 = insertvalue { i64, ptr } %t781, ptr %t780, 1
  %t783 = load ptr, ptr %l295, !tbaa !29
  %t785 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s31, ptr %s31, ptr %t783, { i64, ptr } %t782)
  store { i64, ptr } %t785, ptr %l301
  br label %bb132
bb132:
  %t786 = load { i64, ptr }, ptr %l301, !tbaa !27
  store { i64, ptr } %t786, ptr %l39, !tbaa !27
  %t787 = load i32, ptr %l37, !tbaa !23
  %t788 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t791 = icmp eq i32 %t787, %t788
  br i1 %t791, label %bb133, label %bb134
bb133:
  store %olang.scope zeroinitializer, ptr %s33
  %t793 = load ptr, ptr %l0, !tbaa !29
  store ptr %t793, ptr %l305, !tbaa !29
  %t794 = load i32, ptr %l35, !tbaa !23
  %t796 = call { i64, ptr } @compiler_2femit_2eblockName(ptr %s33, i32 %t794)
  store { i64, ptr } %t796, ptr %l307
  br label %bb135
bb134:
  store %olang.scope zeroinitializer, ptr %s35
  %t797 = load ptr, ptr %l0, !tbaa !29
  %t798 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t799 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d562, i32 0, i32 1) }, 1
  %t800 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d562, i32 0, i32 1) }, 0
  %t802 = extractvalue { i64, ptr } %t798, 1
  %t803 = extractvalue { i64, ptr } %t798, 0
  %t804 = add i64 %t800, %t803
  %t805 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d563, i32 0, i32 1) }, 1
  %t806 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d563, i32 0, i32 1) }, 0
  %t807 = add i64 %t804, %t806
  %t808 = call ptr @__olang_scope_alloc(ptr %s35, i64 %t807)
  call void @olang_textcopy(ptr %t808, ptr %t799, i64 %t800)
  %t809 = getelementptr i8, ptr %t808, i64 %t800
  call void @olang_textcopy(ptr %t809, ptr %t802, i64 %t803)
  %t810 = getelementptr i8, ptr %t809, i64 %t803
  call void @olang_textcopy(ptr %t810, ptr %t805, i64 %t806)
  %t811 = insertvalue { i64, ptr } undef, i64 %t807, 0
  %t812 = insertvalue { i64, ptr } %t811, ptr %t808, 1
  %t814 = extractvalue { i64, ptr } %t812, 0
  %t815 = extractvalue { i64, ptr } %t812, 1
  %t816 = mul i64 %t814, 1
  %t817 = call ptr @__olang_scope_alloc(ptr %s35, i64 %t816)
  call void @llvm.memcpy.p0.p0.i64(ptr %t817, ptr %t815, i64 %t816, i1 false)
  %t818 = insertvalue { i64, ptr } undef, i64 %t814, 0
  %t819 = insertvalue { i64, ptr } %t818, ptr %t817, 1
  %t822 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s35, ptr %s35, ptr %t797, { i64, ptr } %t819)
  store { i64, ptr } %t822, ptr %l314
  br label %bb137
bb135:
  %t823 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d564, i32 0, i32 1) }, 1
  %t824 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d564, i32 0, i32 1) }, 0
  %t825 = load { i64, ptr }, ptr %l307, !tbaa !27
  %t826 = extractvalue { i64, ptr } %t825, 1
  %t827 = extractvalue { i64, ptr } %t825, 0
  %t828 = add i64 %t824, %t827
  %t829 = call ptr @__olang_scope_alloc(ptr %s33, i64 %t828)
  call void @olang_textcopy(ptr %t829, ptr %t823, i64 %t824)
  %t830 = getelementptr i8, ptr %t829, i64 %t824
  call void @olang_textcopy(ptr %t830, ptr %t826, i64 %t827)
  %t831 = insertvalue { i64, ptr } undef, i64 %t828, 0
  %t832 = insertvalue { i64, ptr } %t831, ptr %t829, 1
  %t834 = extractvalue { i64, ptr } %t832, 0
  %t835 = extractvalue { i64, ptr } %t832, 1
  %t836 = mul i64 %t834, 1
  %t837 = call ptr @__olang_scope_alloc(ptr %s33, i64 %t836)
  call void @llvm.memcpy.p0.p0.i64(ptr %t837, ptr %t835, i64 %t836, i1 false)
  %t838 = insertvalue { i64, ptr } undef, i64 %t834, 0
  %t839 = insertvalue { i64, ptr } %t838, ptr %t837, 1
  %t840 = load ptr, ptr %l305, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s33, ptr %t840, { i64, ptr } %t839)
  br label %bb136
bb136:
  call void @__olang_scope_close(ptr %s33)
  br label %bb147
bb137:
  %t842 = load { i64, ptr }, ptr %l314, !tbaa !27
  store { i64, ptr } %t842, ptr %l40, !tbaa !27
  %t843 = load i32, ptr %l36, !tbaa !23
  %t844 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  %t847 = icmp ne i32 %t843, %t844
  br i1 %t847, label %bb138, label %bb139
bb138:
  store %olang.scope zeroinitializer, ptr %s37
  %t849 = load ptr, ptr %l0, !tbaa !29
  store ptr %t849, ptr %l318, !tbaa !29
  %t850 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t850, ptr %l319, !tbaa !27
  %t851 = load ptr, ptr %l0, !tbaa !29
  %t852 = load i32, ptr %l36, !tbaa !23
  %t855 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elocalAt(ptr %v0, ptr %s37, ptr %t851, i32 %t852)
  store { i64, ptr } %t855, ptr %l322
  br label %bb140
bb139:
  br label %bb142
bb140:
  %t856 = load { i64, ptr }, ptr %l322, !tbaa !27
  %t857 = extractvalue { i64, ptr } %t856, 0
  %t858 = extractvalue { i64, ptr } %t856, 1
  %t859 = mul i64 %t857, 1
  %t860 = call ptr @__olang_scope_alloc(ptr %s37, i64 %t859)
  call void @llvm.memcpy.p0.p0.i64(ptr %t860, ptr %t858, i64 %t859, i1 false)
  %t861 = insertvalue { i64, ptr } undef, i64 %t857, 0
  %t862 = insertvalue { i64, ptr } %t861, ptr %t860, 1
  %t863 = load ptr, ptr %l318, !tbaa !29
  %t864 = load { i64, ptr }, ptr %l319, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s37, ptr %s35, ptr %s37, ptr %s37, ptr %t863, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d565, i32 0, i32 1) }, { i64, ptr } %t864, { i64, ptr } %t862, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d220, i32 0, i32 1) })
  br label %bb141
bb141:
  call void @__olang_scope_close(ptr %s37)
  br label %bb142
bb142:
  %t866 = load ptr, ptr %l0, !tbaa !29
  %t867 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t868 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d566, i32 0, i32 1) }, 1
  %t869 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d566, i32 0, i32 1) }, 0
  %t871 = extractvalue { i64, ptr } %t867, 1
  %t872 = extractvalue { i64, ptr } %t867, 0
  %t873 = add i64 %t869, %t872
  %t874 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d567, i32 0, i32 1) }, 1
  %t875 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d567, i32 0, i32 1) }, 0
  %t876 = add i64 %t873, %t875
  %t877 = call ptr @__olang_scope_alloc(ptr %s35, i64 %t876)
  call void @olang_textcopy(ptr %t877, ptr %t868, i64 %t869)
  %t878 = getelementptr i8, ptr %t877, i64 %t869
  call void @olang_textcopy(ptr %t878, ptr %t871, i64 %t872)
  %t879 = getelementptr i8, ptr %t878, i64 %t872
  call void @olang_textcopy(ptr %t879, ptr %t874, i64 %t875)
  %t880 = insertvalue { i64, ptr } undef, i64 %t876, 0
  %t881 = insertvalue { i64, ptr } %t880, ptr %t877, 1
  %t883 = extractvalue { i64, ptr } %t881, 0
  %t884 = extractvalue { i64, ptr } %t881, 1
  %t885 = mul i64 %t883, 1
  %t886 = call ptr @__olang_scope_alloc(ptr %s35, i64 %t885)
  call void @llvm.memcpy.p0.p0.i64(ptr %t886, ptr %t884, i64 %t885, i1 false)
  %t887 = insertvalue { i64, ptr } undef, i64 %t883, 0
  %t888 = insertvalue { i64, ptr } %t887, ptr %t886, 1
  %t891 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s35, ptr %s35, ptr %t866, { i64, ptr } %t888)
  store { i64, ptr } %t891, ptr %l328
  br label %bb143
bb143:
  %t892 = load { i64, ptr }, ptr %l328, !tbaa !27
  %t893 = load ptr, ptr %l0, !tbaa !29
  store ptr %t893, ptr %l329, !tbaa !29
  store { i64, ptr } %t892, ptr %l330, !tbaa !27
  %t895 = load i32, ptr %l37, !tbaa !23
  %t897 = call { i64, ptr } @compiler_2femit_2eblockName(ptr %s35, i32 %t895)
  store { i64, ptr } %t897, ptr %l332
  br label %bb144
bb144:
  %t898 = load i32, ptr %l35, !tbaa !23
  %t900 = call { i64, ptr } @compiler_2femit_2eblockName(ptr %s35, i32 %t898)
  store { i64, ptr } %t900, ptr %l334
  br label %bb145
bb145:
  %t901 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d568, i32 0, i32 1) }, 1
  %t902 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d568, i32 0, i32 1) }, 0
  %t903 = load { i64, ptr }, ptr %l330, !tbaa !27
  %t904 = extractvalue { i64, ptr } %t903, 1
  %t905 = extractvalue { i64, ptr } %t903, 0
  %t906 = add i64 %t902, %t905
  %t907 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d569, i32 0, i32 1) }, 1
  %t908 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d569, i32 0, i32 1) }, 0
  %t909 = add i64 %t906, %t908
  %t910 = load { i64, ptr }, ptr %l332, !tbaa !27
  %t911 = extractvalue { i64, ptr } %t910, 1
  %t912 = extractvalue { i64, ptr } %t910, 0
  %t913 = add i64 %t909, %t912
  %t914 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d569, i32 0, i32 1) }, 1
  %t915 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d569, i32 0, i32 1) }, 0
  %t916 = add i64 %t913, %t915
  %t917 = load { i64, ptr }, ptr %l334, !tbaa !27
  %t918 = extractvalue { i64, ptr } %t917, 1
  %t919 = extractvalue { i64, ptr } %t917, 0
  %t920 = add i64 %t916, %t919
  %t921 = call ptr @__olang_scope_alloc(ptr %s35, i64 %t920)
  call void @olang_textcopy(ptr %t921, ptr %t901, i64 %t902)
  %t922 = getelementptr i8, ptr %t921, i64 %t902
  call void @olang_textcopy(ptr %t922, ptr %t904, i64 %t905)
  %t923 = getelementptr i8, ptr %t922, i64 %t905
  call void @olang_textcopy(ptr %t923, ptr %t907, i64 %t908)
  %t924 = getelementptr i8, ptr %t923, i64 %t908
  call void @olang_textcopy(ptr %t924, ptr %t911, i64 %t912)
  %t925 = getelementptr i8, ptr %t924, i64 %t912
  call void @olang_textcopy(ptr %t925, ptr %t914, i64 %t915)
  %t926 = getelementptr i8, ptr %t925, i64 %t915
  call void @olang_textcopy(ptr %t926, ptr %t918, i64 %t919)
  %t927 = insertvalue { i64, ptr } undef, i64 %t920, 0
  %t928 = insertvalue { i64, ptr } %t927, ptr %t921, 1
  %t930 = extractvalue { i64, ptr } %t928, 0
  %t931 = extractvalue { i64, ptr } %t928, 1
  %t932 = mul i64 %t930, 1
  %t933 = call ptr @__olang_scope_alloc(ptr %s35, i64 %t932)
  call void @llvm.memcpy.p0.p0.i64(ptr %t933, ptr %t931, i64 %t932, i1 false)
  %t934 = insertvalue { i64, ptr } undef, i64 %t930, 0
  %t935 = insertvalue { i64, ptr } %t934, ptr %t933, 1
  %t936 = load ptr, ptr %l329, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s35, ptr %t936, { i64, ptr } %t935)
  br label %bb146
bb146:
  call void @__olang_scope_close(ptr %s35)
  br label %bb147
bb147:
  call void @__olang_scope_close(ptr %s31)
  br label %bb159
bb148:
  %t938 = load { i64, [8 x i64] }, ptr %l1
  %t940 = extractvalue { i64, [8 x i64] } %t938, 0
  %t941 = icmp eq i64 %t940, 9
  br i1 %t941, label %bb149, label %bb150
bb149:
  %t943 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t944 = getelementptr { %"compiler/source:Span", i32, { i64, [4 x i64] } }, ptr %t943, i32 0, i32 0
  %t945 = load %"compiler/source:Span", ptr %t944
  store %"compiler/source:Span" %t945, ptr %l42
  %t947 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t948 = getelementptr { %"compiler/source:Span", i32, { i64, [4 x i64] } }, ptr %t947, i32 0, i32 1
  %t949 = load i32, ptr %t948, !range !{i32 0, i32 16}
  store i32 %t949, ptr %l43
  %t951 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t952 = getelementptr { %"compiler/source:Span", i32, { i64, [4 x i64] } }, ptr %t951, i32 0, i32 2
  %t953 = load { i64, [4 x i64] }, ptr %t952
  store { i64, [4 x i64] } %t953, ptr %l44
  br label %bb151
bb150:
  br label %bb153
bb151:
  %t955 = load ptr, ptr %l0, !tbaa !29
  %t956 = load %"compiler/source:Span", ptr %l42
  %t957 = load i32, ptr %l43, !range !{i32 0, i32 16}
  %t958 = load { i64, [4 x i64] }, ptr %l44
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2eexit(ptr %v0, ptr %t955, %"compiler/source:Span" %t956, i32 %t957, { i64, [4 x i64] } %t958)
  br label %bb152
bb152:
  br label %bb159
bb153:
  %t963 = load { i64, [8 x i64] }, ptr %l1
  %t965 = extractvalue { i64, [8 x i64] } %t963, 0
  %t966 = icmp eq i64 %t965, 10
  br i1 %t966, label %bb154, label %bb155
bb154:
  br label %bb156
bb155:
  br label %bb158
bb156:
  store %olang.scope zeroinitializer, ptr %s41
  %t968 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2egap(ptr %v0, ptr %s41, ptr %t968, { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d570, i32 0, i32 1) })
  br label %bb157
bb157:
  call void @__olang_scope_close(ptr %s41)
  br label %bb159
bb158:
  call void @__olang_check_failed(ptr @olang_loc_7633dd9d24c54174_280dfd74a77e9550)
  unreachable
bb159:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2evalueTarget(ptr %v0, ptr %a0, %"compiler/mir:Task" %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/mir:Task"
  %l3 = alloca ptr
  %l4 = alloca i32
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l20 = alloca %"compiler/mir:Lvalue"
  %l21 = alloca i32
  %l22 = alloca i32
  %l25 = alloca i32
  %l28 = alloca i1
  %l31 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store %"compiler/mir:Task" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/mir:Task", ptr %l1, i32 0, i32 7
  %t2 = getelementptr %"compiler/mir:Range", ptr %t1, i32 0, i32 1
  %t3 = load i32, ptr %t2, !tbaa !23
  %t5 = icmp eq i32 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/emit:fnEm", ptr %t8, i32 0, i32 0
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t13 = getelementptr %"compiler/emit:Emitter", ptr %t11, i32 0, i32 3
  %t14 = load ptr, ptr %t13, !tbaa !29
  store ptr %t14, ptr %l3, !tbaa !29
  %t16 = load ptr, ptr %l3, !tbaa !29
  store ptr %t16, ptr %l11, !tbaa !29
  %t17 = load ptr, ptr %l0, !tbaa !29
  store ptr %t17, ptr %l12, !tbaa !29
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/emit:fnEm", ptr %t18, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t23 = getelementptr %"compiler/mir:Fn", ptr %t21, i32 0, i32 13
  %t24 = getelementptr %"compiler/mir:Task", ptr %l1, i32 0, i32 3
  %t25 = getelementptr %"compiler/mir:Range", ptr %t24, i32 0, i32 0
  %t26 = load i32, ptr %t25, !tbaa !23
  %t28 = sext i32 %t26 to i64
  %t32 = add i64 %t28, %a2
  %t35 = call %"compiler/mir:Lvalue" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLvalue_3e_2eAt_3ccompiler_2fmir_3aLvalue_3e(ptr %v0, ptr %t23, i64 %t32)
  store %"compiler/mir:Lvalue" %t35, ptr %l20
  br label %bb4
bb4:
  %t36 = load ptr, ptr %l12, !tbaa !29
  %t37 = load %"compiler/mir:Lvalue", ptr %l20
  %t38 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eplaceType(ptr %v0, ptr %t36, %"compiler/mir:Lvalue" %t37)
  store i32 %t38, ptr %l21
  br label %bb5
bb5:
  %t39 = load ptr, ptr %l11, !tbaa !29
  %t40 = load i32, ptr %l21, !tbaa !23
  %t41 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t39, i32 %t40)
  store i32 %t41, ptr %l22
  br label %bb6
bb6:
  %t42 = load i32, ptr %l22, !tbaa !23
  store i32 %t42, ptr %l4, !tbaa !23
  %t43 = load ptr, ptr %l3, !tbaa !29
  %t44 = load i32, ptr %l4, !tbaa !23
  %t47 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t43, i32 %t44)
  store i32 %t47, ptr %l25
  br label %bb7
bb7:
  %t48 = load i32, ptr %l25, !range !{i32 0, i32 33}
  %t50 = trunc i64 19 to i32
  %t51 = icmp eq i32 %t48, %t50
  br i1 %t51, label %bb8, label %bb9
bb8:
  %t53 = load ptr, ptr %l3, !tbaa !29
  %t54 = load i32, ptr %l4, !tbaa !23
  %t57 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t53, i32 %t54)
  store i32 %t57, ptr %l31
  br label %bb10
bb9:
  store i1 false, ptr %l28, !tbaa !21
  br label %bb11
bb10:
  %t58 = load i32, ptr %l31, !tbaa !23
  %t59 = icmp eq i32 %t58, 0
  store i1 %t59, ptr %l28, !tbaa !21
  br label %bb11
bb11:
  %t61 = load i1, ptr %l28, !tbaa !21
  store i1 %t61, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ewidenBF16(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %lp6 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l29 = alloca i1
  %l36 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/emit:fnEm", ptr %t3, i32 0, i32 0
  %t6 = load ptr, ptr %t5, !tbaa !29
  %t8 = getelementptr %"compiler/emit:Emitter", ptr %t6, i32 0, i32 63
  %t9 = load i1, ptr %t8, !tbaa !21
  %t13 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ebf16Bits(ptr %v0, ptr %v1, ptr %s0, ptr %t1, { i64, ptr } %a1, i1 %t9)
  store { i64, ptr } %t13, ptr %l12
  br label %bb1
bb1:
  %t14 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d571, i32 0, i32 1) }, 1
  %t18 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d571, i32 0, i32 1) }, 0
  %t20 = extractvalue { i64, ptr } %t14, 1
  %t21 = extractvalue { i64, ptr } %t14, 0
  %t22 = add i64 %t18, %t21
  %t23 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d572, i32 0, i32 1) }, 1
  %t24 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d572, i32 0, i32 1) }, 0
  %t25 = add i64 %t22, %t24
  %t26 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t25)
  call void @olang_textcopy(ptr %t26, ptr %t17, i64 %t18)
  %t27 = getelementptr i8, ptr %t26, i64 %t18
  call void @olang_textcopy(ptr %t27, ptr %t20, i64 %t21)
  %t28 = getelementptr i8, ptr %t27, i64 %t21
  call void @olang_textcopy(ptr %t28, ptr %t23, i64 %t24)
  %t29 = insertvalue { i64, ptr } undef, i64 %t25, 0
  %t30 = insertvalue { i64, ptr } %t29, ptr %t26, 1
  %t32 = extractvalue { i64, ptr } %t30, 0
  %t33 = extractvalue { i64, ptr } %t30, 1
  %t34 = mul i64 %t32, 1
  %t35 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t34)
  call void @llvm.memcpy.p0.p0.i64(ptr %t35, ptr %t33, i64 %t34, i1 false)
  %t36 = insertvalue { i64, ptr } undef, i64 %t32, 0
  %t37 = insertvalue { i64, ptr } %t36, ptr %t35, 1
  %t40 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t15, { i64, ptr } %t37)
  store { i64, ptr } %t40, ptr %l17
  br label %bb2
bb2:
  %t41 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d573, i32 0, i32 1) }, 1
  %t45 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d573, i32 0, i32 1) }, 0
  %t47 = extractvalue { i64, ptr } %t41, 1
  %t48 = extractvalue { i64, ptr } %t41, 0
  %t49 = add i64 %t45, %t48
  %t50 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d574, i32 0, i32 1) }, 1
  %t51 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d574, i32 0, i32 1) }, 0
  %t52 = add i64 %t49, %t51
  %t53 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t52)
  call void @olang_textcopy(ptr %t53, ptr %t44, i64 %t45)
  %t54 = getelementptr i8, ptr %t53, i64 %t45
  call void @olang_textcopy(ptr %t54, ptr %t47, i64 %t48)
  %t55 = getelementptr i8, ptr %t54, i64 %t48
  call void @olang_textcopy(ptr %t55, ptr %t50, i64 %t51)
  %t56 = insertvalue { i64, ptr } undef, i64 %t52, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t53, 1
  %t59 = extractvalue { i64, ptr } %t57, 0
  %t60 = extractvalue { i64, ptr } %t57, 1
  %t61 = mul i64 %t59, 1
  %t62 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t61)
  call void @llvm.memcpy.p0.p0.i64(ptr %t62, ptr %t60, i64 %t61, i1 false)
  %t63 = insertvalue { i64, ptr } undef, i64 %t59, 0
  %t64 = insertvalue { i64, ptr } %t63, ptr %t62, 1
  %t67 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t42, { i64, ptr } %t64)
  store { i64, ptr } %t67, ptr %l22
  br label %bb3
bb3:
  %t68 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d575, i32 0, i32 1) }, 1
  %t72 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d575, i32 0, i32 1) }, 0
  %t74 = extractvalue { i64, ptr } %t68, 1
  %t75 = extractvalue { i64, ptr } %t68, 0
  %t76 = add i64 %t72, %t75
  %t77 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d576, i32 0, i32 1) }, 1
  %t78 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d576, i32 0, i32 1) }, 0
  %t79 = add i64 %t76, %t78
  %t80 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t79)
  call void @olang_textcopy(ptr %t80, ptr %t71, i64 %t72)
  %t81 = getelementptr i8, ptr %t80, i64 %t72
  call void @olang_textcopy(ptr %t81, ptr %t74, i64 %t75)
  %t82 = getelementptr i8, ptr %t81, i64 %t75
  call void @olang_textcopy(ptr %t82, ptr %t77, i64 %t78)
  %t83 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t84 = insertvalue { i64, ptr } %t83, ptr %t80, 1
  %t86 = extractvalue { i64, ptr } %t84, 0
  %t87 = extractvalue { i64, ptr } %t84, 1
  %t88 = mul i64 %t86, 1
  %t89 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t88)
  call void @llvm.memcpy.p0.p0.i64(ptr %t89, ptr %t87, i64 %t88, i1 false)
  %t90 = insertvalue { i64, ptr } undef, i64 %t86, 0
  %t91 = insertvalue { i64, ptr } %t90, ptr %t89, 1
  %t94 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v3, ptr %v3, ptr %t69, { i64, ptr } %t91)
  store { i64, ptr } %t94, ptr %l27
  br label %bb4
bb4:
  %t95 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 16, i64 8)
  store ptr %t95, ptr %lp6
  %t96 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t97 = load ptr, ptr %lp6
  store { i64, ptr } %t96, ptr %t97, !tbaa !27
  %t98 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t100 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t98, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d577, i32 0, i32 1) })
  store i1 %t100, ptr %l29
  br label %bb5
bb5:
  %t101 = load i1, ptr %l29, !tbaa !21
  br i1 %t101, label %bb6, label %bb7
bb6:
  %t102 = load ptr, ptr %lp6
  %t103 = load { i64, ptr }, ptr %t102, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t103, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t106 = load ptr, ptr %lp6
  %t107 = load { i64, ptr }, ptr %t106, !tbaa !27
  %t108 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t109 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d578, i32 0, i32 1) }, 1
  %t110 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d578, i32 0, i32 1) }, 0
  %t112 = extractvalue { i64, ptr } %t107, 1
  %t113 = extractvalue { i64, ptr } %t107, 0
  %t114 = add i64 %t110, %t113
  %t115 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d579, i32 0, i32 1) }, 1
  %t116 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d579, i32 0, i32 1) }, 0
  %t117 = add i64 %t114, %t116
  %t119 = extractvalue { i64, ptr } %t108, 1
  %t120 = extractvalue { i64, ptr } %t108, 0
  %t121 = add i64 %t117, %t120
  %t122 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t121)
  call void @olang_textcopy(ptr %t122, ptr %t109, i64 %t110)
  %t123 = getelementptr i8, ptr %t122, i64 %t110
  call void @olang_textcopy(ptr %t123, ptr %t112, i64 %t113)
  %t124 = getelementptr i8, ptr %t123, i64 %t113
  call void @olang_textcopy(ptr %t124, ptr %t115, i64 %t116)
  %t125 = getelementptr i8, ptr %t124, i64 %t116
  call void @olang_textcopy(ptr %t125, ptr %t119, i64 %t120)
  %t126 = insertvalue { i64, ptr } undef, i64 %t121, 0
  %t127 = insertvalue { i64, ptr } %t126, ptr %t122, 1
  %t129 = extractvalue { i64, ptr } %t127, 0
  %t130 = extractvalue { i64, ptr } %t127, 1
  %t131 = mul i64 %t129, 1
  %t132 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t131)
  call void @llvm.memcpy.p0.p0.i64(ptr %t132, ptr %t130, i64 %t131, i1 false)
  %t133 = insertvalue { i64, ptr } undef, i64 %t129, 0
  %t134 = insertvalue { i64, ptr } %t133, ptr %t132, 1
  %t137 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v3, ptr %v3, ptr %t105, { i64, ptr } %t134)
  store { i64, ptr } %t137, ptr %l36
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s0)
  %t138 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t138, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2edeclaredSymbol(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l17 = alloca i1
  %l18 = alloca { i64, ptr }
  %l21 = alloca i1
  %l25 = alloca { i64, ptr }
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d580, i32 0, i32 1) })
  %t4 = extractvalue { i32, i64 } %t3, 1
  %t5 = extractvalue { i32, i64 } %t3, 0
  store i32 %t5, ptr %l6
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store i64 %t4, ptr %l5
  br label %bb1
bb1:
  %t8 = load i64, ptr %l5, !tbaa !24
  store i64 %t8, ptr %l3, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d581, i32 0, i32 1) }, ptr %l7, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t9, ptr %l8, !tbaa !27
  %t10 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t10, 0
  store i64 %t11, ptr %l9, !tbaa !24
  %t12 = load i64, ptr %l9, !tbaa !24
  %t13 = mul i64 %t12, 1
  %t14 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t13)
  %t15 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr %t14, 1
  store { i64, ptr } %t16, ptr %l10, !tbaa !27
  %t17 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !27
  %t19 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !27
  %t21 = load i64, ptr %l9, !tbaa !24
  %t22 = mul i64 %t21, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t18, ptr %t20, i64 %t22, i1 false)
  %t23 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t23, ptr %l8, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t24 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t24, ptr %rv
  br label %ret
bb4:
  %t25 = load i64, ptr %l3, !tbaa !24
  store i64 %t25, ptr %l1, !tbaa !24
  %t26 = load i64, ptr %l1, !tbaa !24
  %t28 = add i64 %t26, 1
  store i64 %t28, ptr %l2, !tbaa !24
  br label %bb5
bb5:
  %t30 = load i64, ptr %l2, !tbaa !24
  %t31 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t33 = extractvalue { i64, ptr } %t31, 0
  %t36 = icmp slt i64 %t30, %t33
  br i1 %t36, label %bb6, label %bb7
bb6:
  %t38 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t38, ptr %l18, !tbaa !27
  %t39 = load i64, ptr %l2, !tbaa !24
  %t41 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !27
  %t43 = getelementptr i8, ptr %t42, i64 %t39
  %t44 = load i8, ptr %t43, !tbaa !32
  %t46 = call i1 @compiler_2femit_2esymbolChar(i8 %t44)
  store i1 %t46, ptr %l21
  br label %bb8
bb7:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb9
bb8:
  %t47 = load i1, ptr %l21, !tbaa !21
  store i1 %t47, ptr %l17, !tbaa !21
  br label %bb9
bb9:
  %t48 = load i1, ptr %l17, !tbaa !21
  %t49 = xor i1 %t48, true
  br i1 %t49, label %bb10, label %bb11
bb10:
  br label %bb14
bb11:
  br label %bb12
bb12:
  %t51 = load i64, ptr %l2, !tbaa !24
  %t53 = add i64 %t51, 1
  store i64 %t53, ptr %l2, !tbaa !24
  br label %bb13
bb13:
  br label %bb5
bb14:
  %t55 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t55, ptr %l25, !tbaa !27
  %t56 = load i64, ptr %l1, !tbaa !24
  %t58 = add i64 %t56, 1
  store i64 %t58, ptr %l27, !tbaa !24
  %t59 = load i64, ptr %l2, !tbaa !24
  store i64 %t59, ptr %l28, !tbaa !24
  %t60 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t61 = extractvalue { i64, ptr } %t60, 0
  store i64 %t61, ptr %l29, !tbaa !24
  %t62 = load i64, ptr %l27, !tbaa !24
  %t63 = icmp sge i64 %t62, 0
  br i1 %t63, label %bb15, label %bb16
bb15:
  %t65 = load i64, ptr %l27, !tbaa !24
  %t66 = load i64, ptr %l28, !tbaa !24
  %t67 = icmp sle i64 %t65, %t66
  br i1 %t67, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_f695fddd526749db_a8fb91cf3e060dd7)
  unreachable
bb17:
  %t69 = load i64, ptr %l28, !tbaa !24
  %t70 = load i64, ptr %l29, !tbaa !24
  %t71 = icmp sle i64 %t69, %t70
  br i1 %t71, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_f695fddd526749db_a8fb91cf3e060dd7)
  unreachable
bb19:
  %t73 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !27
  %t75 = load i64, ptr %l27, !tbaa !24
  %t76 = load i64, ptr %l28, !tbaa !24
  %t77 = getelementptr i8, ptr %t74, i64 %t75
  %t78 = sub i64 %t76, %t75
  %t79 = insertvalue { i64, ptr } undef, i64 %t78, 0
  %t80 = insertvalue { i64, ptr } %t79, ptr %t77, 1
  %t82 = extractvalue { i64, ptr } %t80, 1
  %t83 = extractvalue { i64, ptr } %t80, 0
  %t84 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t83)
  call void @olang_textcopy(ptr %t84, ptr %t82, i64 %t83)
  %t85 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t86 = insertvalue { i64, ptr } %t85, ptr %t84, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t86, ptr %rv
  br label %ret
bb20:
  call void @__olang_check_failed(ptr @olang_loc_f695fddd526749db_a8fb91cf3e060dd7)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2eescape(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i8
  %l6 = alloca %"std/prelude/text:StringBuilder"
  %l14 = alloca { i64, ptr }
  %l19 = alloca i1
  %l22 = alloca i1
  %l26 = alloca i1
  %l31 = alloca ptr
  %l33 = alloca i8
  %l34 = alloca i64
  %l35 = alloca i32
  %l36 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l6
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l6
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  store { i64, ptr } %a0, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  store i64 %t7, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  %t9 = load i64, ptr %l3, !tbaa !24
  %t10 = load i64, ptr %l4, !tbaa !24
  %t13 = icmp slt i64 %t9, %t10
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb3, label %bb4
bb3:
  br label %bb27
bb4:
  br label %bb5
bb5:
  %t17 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t17, ptr %l14, !tbaa !27
  %t18 = load i64, ptr %l3, !tbaa !24
  %t20 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr i8, ptr %t21, i64 %t18
  %t23 = load i8, ptr %t22, !tbaa !32
  store i8 %t23, ptr %l5, !tbaa !22
  %t25 = load i8, ptr %l5, !tbaa !22
  %t27 = icmp eq i8 %t25, 34
  br i1 %t27, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb8
bb7:
  %t29 = load i8, ptr %l5, !tbaa !22
  %t31 = icmp eq i8 %t29, 92
  store i1 %t31, ptr %l19, !tbaa !21
  br label %bb8
bb8:
  %t33 = load i1, ptr %l19, !tbaa !21
  br i1 %t33, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l22, !tbaa !21
  br label %bb11
bb10:
  %t34 = load i8, ptr %l5, !tbaa !22
  %t37 = icmp ult i8 %t34, 32
  store i1 %t37, ptr %l22, !tbaa !21
  br label %bb11
bb11:
  %t39 = load i1, ptr %l22, !tbaa !21
  br i1 %t39, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb14
bb13:
  %t40 = load i8, ptr %l5, !tbaa !22
  %t43 = icmp ugt i8 %t40, 126
  store i1 %t43, ptr %l26, !tbaa !21
  br label %bb14
bb14:
  %t45 = load i1, ptr %l26, !tbaa !21
  br i1 %t45, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s3
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 92)
  br label %bb17
bb16:
  %t47 = load i8, ptr %l5, !tbaa !22
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 %t47)
  br label %bb24
bb17:
  store ptr %l1, ptr %l31, !tbaa !29
  %t50 = load i8, ptr %l5, !tbaa !22
  store i8 %t50, ptr %l33, !tbaa !22
  %t52 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s3, i64 16)
  %t53 = extractvalue { i32, i64 } %t52, 1
  %t54 = extractvalue { i32, i64 } %t52, 0
  store i32 %t54, ptr %l35
  %t55 = icmp ne i32 %t54, 0
  br i1 %t55, label %bb19, label %ok.56, !prof !99
ok.56:
  store i64 %t53, ptr %l34
  br label %bb18
bb18:
  %t57 = load i8, ptr %l33, !tbaa !22
  %t58 = load i64, ptr %l34, !tbaa !24
  %t59 = call { i64, ptr } @std_2fprelude_2ftext_2eU8_2eFormat(ptr %s3, i8 %t57, i64 %t58)
  store { i64, ptr } %t59, ptr %l36
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_b05c5d37656b7ecf_b2cabd35ece02ebb)
  unreachable
bb20:
  %t60 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t61 = extractvalue { i64, ptr } %t60, 0
  %t62 = extractvalue { i64, ptr } %t60, 1
  %t63 = mul i64 %t61, 1
  %t64 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t63)
  call void @llvm.memcpy.p0.p0.i64(ptr %t64, ptr %t62, i64 %t63, i1 false)
  %t65 = insertvalue { i64, ptr } undef, i64 %t61, 0
  %t66 = insertvalue { i64, ptr } %t65, ptr %t64, 1
  %t68 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadStart(ptr %s3, ptr %s3, { i64, ptr } %t66, i64 2, i8 48)
  store { i64, ptr } %t68, ptr %l38
  br label %bb21
bb21:
  %t69 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t70 = extractvalue { i64, ptr } %t69, 0
  %t71 = extractvalue { i64, ptr } %t69, 1
  %t72 = mul i64 %t70, 1
  %t73 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t72)
  call void @llvm.memcpy.p0.p0.i64(ptr %t73, ptr %t71, i64 %t72, i1 false)
  %t74 = insertvalue { i64, ptr } undef, i64 %t70, 0
  %t75 = insertvalue { i64, ptr } %t74, ptr %t73, 1
  %t77 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eToUpper(ptr %s3, ptr %s3, { i64, ptr } %t75)
  store { i64, ptr } %t77, ptr %l40
  br label %bb22
bb22:
  %t78 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t79 = extractvalue { i64, ptr } %t78, 0
  %t80 = extractvalue { i64, ptr } %t78, 1
  %t81 = mul i64 %t79, 1
  %t82 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t81)
  call void @llvm.memcpy.p0.p0.i64(ptr %t82, ptr %t80, i64 %t81, i1 false)
  %t83 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t84 = insertvalue { i64, ptr } %t83, ptr %t82, 1
  %t85 = load ptr, ptr %l31, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s3, ptr %t85, { i64, ptr } %t84)
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s3)
  br label %bb25
bb24:
  br label %bb25
bb25:
  br label %bb26
bb26:
  %t87 = load i64, ptr %l3, !tbaa !24
  %t89 = add i64 %t87, 1
  store i64 %t89, ptr %l3, !tbaa !24
  br label %bb2
bb27:
  %t92 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t92, ptr %l47
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s0)
  %t93 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t93, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2femit_2egenClass(i64 %a0) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca [7 x i64]
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l20 = alloca i64
  %l23 = alloca i64
  %rv = alloca i64
  store i64 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l0, !tbaa !24
  %t3 = icmp sle i64 %t1, 256
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i64, ptr %l0, !tbaa !24
  %t7 = add i64 %t5, 15
  %t9 = sdiv i64 %t7, 16
  %t11 = sub i64 %t9, 1
  store i64 %t11, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t13 = insertvalue [7 x i64] undef, i64 320, 0
  %t14 = insertvalue [7 x i64] %t13, i64 384, 1
  %t15 = insertvalue [7 x i64] %t14, i64 512, 2
  %t16 = insertvalue [7 x i64] %t15, i64 768, 3
  %t17 = insertvalue [7 x i64] %t16, i64 1024, 4
  %t18 = insertvalue [7 x i64] %t17, i64 1536, 5
  %t19 = insertvalue [7 x i64] %t18, i64 2048, 6
  store [7 x i64] %t19, ptr %l1
  store i64 0, ptr %l2, !tbaa !24
  %t21 = load [7 x i64], ptr %l1
  store i64 7, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t24 = load i64, ptr %l3, !tbaa !24
  %t25 = load i64, ptr %l2, !tbaa !24
  %t28 = icmp sgt i64 %t24, %t25
  br i1 %t28, label %bb4, label %bb5
bb4:
  %t30 = load i64, ptr %l4, !tbaa !24
  %t32 = icmp sgt i64 %t30, 0
  br i1 %t32, label %bb6, label %bb7
bb5:
  store i64 0, ptr %l20, !tbaa !24
  br label %bb9
bb6:
  %t34 = load i64, ptr %l3, !tbaa !24
  %t35 = load i64, ptr %l2, !tbaa !24
  %t38 = sub i64 %t34, %t35
  %t39 = load i64, ptr %l4, !tbaa !24
  %t42 = add i64 %t38, %t39
  %t44 = sub i64 %t42, 1
  %t45 = load i64, ptr %l4, !tbaa !24
  %t48 = sdiv i64 %t44, %t45
  store i64 %t48, ptr %l23, !tbaa !24
  br label %bb8
bb7:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb8
bb8:
  %t50 = load i64, ptr %l23, !tbaa !24
  store i64 %t50, ptr %l20, !tbaa !24
  br label %bb9
bb9:
  %t51 = load i64, ptr %l20, !tbaa !24
  store i64 %t51, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb10
bb10:
  %t52 = load i64, ptr %l6, !tbaa !24
  %t53 = load i64, ptr %l5, !tbaa !24
  %t56 = icmp slt i64 %t52, %t53
  %t58 = xor i1 %t56, true
  br i1 %t58, label %bb11, label %bb12
bb11:
  br label %bb18
bb12:
  br label %bb13
bb13:
  %t60 = load i64, ptr %l2, !tbaa !24
  %t61 = load i64, ptr %l6, !tbaa !24
  %t62 = load i64, ptr %l4, !tbaa !24
  %t65 = mul i64 %t61, %t62
  %t68 = add i64 %t60, %t65
  store i64 %t68, ptr %l7, !tbaa !24
  %t70 = load i64, ptr %l0, !tbaa !24
  %t71 = load i64, ptr %l7, !tbaa !24
  %t73 = getelementptr [7 x i64], ptr %l1, i64 0, i64 %t71
  %t74 = load i64, ptr %t73, !tbaa !34
  %t77 = icmp sle i64 %t70, %t74
  br i1 %t77, label %bb14, label %bb15
bb14:
  %t79 = load i64, ptr %l7, !tbaa !24
  %t81 = add i64 16, %t79
  store i64 %t81, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  br label %bb17
bb17:
  %t83 = load i64, ptr %l6, !tbaa !24
  %t85 = add i64 %t83, 1
  store i64 %t85, ptr %l6, !tbaa !24
  br label %bb10
bb18:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @compiler_2femit_2emathExactTable(ptr %v0) #0 {
entry:
  %lp0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l5 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %s1 = alloca %olang.scope
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l5
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 72, i64 8)
  store ptr %t2, ptr %lp0
  %t3 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l5
  %t4 = load ptr, ptr %lp0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t3, ptr %t4
  store %olang.scope zeroinitializer, ptr %s1
  %t5 = insertvalue [7 x { i64, ptr }] undef, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d582, i32 0, i32 1) }, 0
  %t6 = insertvalue [7 x { i64, ptr }] %t5, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d583, i32 0, i32 1) }, 1
  %t7 = insertvalue [7 x { i64, ptr }] %t6, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d584, i32 0, i32 1) }, 2
  %t8 = insertvalue [7 x { i64, ptr }] %t7, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d585, i32 0, i32 1) }, 3
  %t9 = insertvalue [7 x { i64, ptr }] %t8, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d586, i32 0, i32 1) }, 4
  %t10 = insertvalue [7 x { i64, ptr }] %t9, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d587, i32 0, i32 1) }, 5
  %t11 = insertvalue [7 x { i64, ptr }] %t10, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d588, i32 0, i32 1) }, 6
  %t13 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 112, i64 8)
  store [7 x { i64, ptr }] %t11, ptr %t13
  store ptr %t13, ptr %l1
  store i64 0, ptr %l2, !tbaa !24
  %t15 = load ptr, ptr %l1
  store i64 7, ptr %l3, !tbaa !24
  br label %bb2
bb2:
  %t18 = load i64, ptr %l2, !tbaa !24
  %t19 = load i64, ptr %l3, !tbaa !24
  %t22 = icmp slt i64 %t18, %t19
  %t24 = xor i1 %t22, true
  br i1 %t24, label %bb3, label %bb4
bb3:
  br label %bb8
bb4:
  br label %bb5
bb5:
  %t26 = load ptr, ptr %l1
  %t27 = load i64, ptr %l2, !tbaa !24
  %t30 = getelementptr [7 x { i64, ptr }], ptr %t26, i64 0, i64 %t27
  %t31 = load { i64, ptr }, ptr %t30, !tbaa !37
  %t33 = load ptr, ptr %lp0
  %t35 = load ptr, ptr @__olang_prog_scope
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %v0, ptr %t35, ptr %t33, { i64, ptr } %t31, i64 1)
  br label %bb6
bb6:
  br label %bb7
bb7:
  %t38 = load i64, ptr %l2, !tbaa !24
  %t40 = add i64 %t38, 1
  store i64 %t40, ptr %l2, !tbaa !24
  br label %bb2
bb8:
  call void @__olang_scope_close(ptr %s1)
  %t42 = load ptr, ptr %lp0
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %v0, ptr %v0, ptr %t42, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d589, i32 0, i32 1) }, i64 2)
  br label %bb9
bb9:
  %t44 = load ptr, ptr %lp0
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %v0, ptr %v0, ptr %t44, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d590, i32 0, i32 1) }, i64 3)
  br label %bb10
bb10:
  %t46 = load ptr, ptr %lp0
  %t47 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t46
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t47, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

define dso_local i32 @compiler_2femit_2estoredType(ptr %v0, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca i64
  %l9 = alloca i32
  %l27 = alloca { i64, ptr }
  %l30 = alloca ptr
  %l31 = alloca i1
  %l34 = alloca i1
  %l36 = alloca ptr
  %l37 = alloca i1
  %l52 = alloca i1
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Body", ptr %t1, i32 0, i32 11
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t8, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/typed:Body", ptr %t10, i32 0, i32 11
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = icmp eq ptr %t13, null
  br i1 %t15, label %bb4, label %bb5
bb4:
  call void @__olang_check_failed(ptr @olang_loc_56e40b98d8735a00_a9923da8dafaf70c)
  unreachable
bb5:
  br label %bb6
bb6:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/typed:Body", ptr %t17, i32 0, i32 11
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t23 = getelementptr %"compiler/typed:Block", ptr %t20, i32 0, i32 1
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  store { i64, ptr } %t24, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t26 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t26, 0
  store i64 %t28, ptr %l5, !tbaa !24
  br label %bb7
bb7:
  %t30 = load i64, ptr %l4, !tbaa !24
  %t31 = load i64, ptr %l5, !tbaa !24
  %t34 = icmp slt i64 %t30, %t31
  %t36 = xor i1 %t34, true
  br i1 %t36, label %bb8, label %bb9
bb8:
  br label %bb34
bb9:
  br label %bb10
bb10:
  %t38 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t38, ptr %l27, !tbaa !27
  %t39 = load i64, ptr %l4, !tbaa !24
  %t41 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !27
  %t43 = getelementptr ptr, ptr %t42, i64 %t39
  %t44 = load ptr, ptr %t43, !tbaa !39
  store ptr %t44, ptr %l6, !tbaa !29
  %t46 = load ptr, ptr %l6, !tbaa !29
  store ptr %t46, ptr %l30, !tbaa !29
  store i1 false, ptr %l31, !tbaa !21
  %t47 = load ptr, ptr %l30, !tbaa !29
  %t48 = icmp ne ptr %t47, null
  br i1 %t48, label %bb11, label %bb12
bb11:
  %t50 = load ptr, ptr %l30, !tbaa !29
  %t51 = load i64, ptr %t50, !range !{i64 0, i64 17}
  %t53 = icmp eq i64 %t51, 1
  store i1 %t53, ptr %l31, !tbaa !21
  br label %bb12
bb12:
  %t54 = load i1, ptr %l31, !tbaa !21
  br i1 %t54, label %bb13, label %bb14
bb13:
  %t55 = load ptr, ptr %l6, !tbaa !29
  %t57 = getelementptr { i64, [3 x i64] }, ptr %t55, i32 0, i32 1
  %t58 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t57, i32 0, i32 1
  %t59 = load ptr, ptr %t58
  store ptr %t59, ptr %l36, !tbaa !29
  store i1 false, ptr %l37, !tbaa !21
  %t60 = load ptr, ptr %l36, !tbaa !29
  %t61 = icmp ne ptr %t60, null
  br i1 %t61, label %bb15, label %bb16
bb14:
  store i1 false, ptr %l34, !tbaa !21
  br label %bb17
bb15:
  %t63 = load ptr, ptr %l36, !tbaa !29
  %t64 = load i64, ptr %t63, !range !{i64 0, i64 8}
  %t66 = icmp eq i64 %t64, 1
  store i1 %t66, ptr %l37, !tbaa !21
  br label %bb16
bb16:
  %t67 = load i1, ptr %l37, !tbaa !21
  store i1 %t67, ptr %l34, !tbaa !21
  br label %bb17
bb17:
  %t68 = load i1, ptr %l34, !tbaa !21
  br i1 %t68, label %bb18, label %bb19
bb18:
  %t69 = load ptr, ptr %l6, !tbaa !29
  %t71 = getelementptr { i64, [3 x i64] }, ptr %t69, i32 0, i32 1
  %t72 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t71, i32 0, i32 1
  %t73 = load ptr, ptr %t72
  %t75 = getelementptr { i64, [4 x i64] }, ptr %t73, i32 0, i32 1
  %t76 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t75, i32 0, i32 1
  %t77 = load i32, ptr %t76
  store i32 %t77, ptr %l7, !tbaa !23
  %t79 = load ptr, ptr %l6, !tbaa !29
  %t81 = getelementptr { i64, [3 x i64] }, ptr %t79, i32 0, i32 1
  %t82 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t81, i32 0, i32 1
  %t83 = load ptr, ptr %t82
  %t85 = getelementptr { i64, [4 x i64] }, ptr %t83, i32 0, i32 1
  %t86 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t85, i32 0, i32 2
  %t87 = load i64, ptr %t86
  store i64 %t87, ptr %l8, !tbaa !24
  %t89 = load ptr, ptr %l6, !tbaa !29
  %t91 = getelementptr { i64, [3 x i64] }, ptr %t89, i32 0, i32 1
  %t92 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t91, i32 0, i32 1
  %t93 = load ptr, ptr %t92
  %t95 = getelementptr { i64, [4 x i64] }, ptr %t93, i32 0, i32 1
  %t96 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t95, i32 0, i32 3
  %t97 = load i32, ptr %t96
  store i32 %t97, ptr %l9, !tbaa !23
  br label %bb20
bb19:
  br label %bb27
bb20:
  %t99 = load i64, ptr %l8, !tbaa !24
  %t103 = icmp eq i64 %t99, %a1
  br i1 %t103, label %bb21, label %bb22
bb21:
  %t105 = load i32, ptr %l9, !tbaa !23
  %t109 = icmp eq i32 %t105, %a2
  store i1 %t109, ptr %l52, !tbaa !21
  br label %bb23
bb22:
  store i1 false, ptr %l52, !tbaa !21
  br label %bb23
bb23:
  %t111 = load i1, ptr %l52, !tbaa !21
  br i1 %t111, label %bb24, label %bb25
bb24:
  %t112 = load i32, ptr %l7, !tbaa !23
  store i32 %t112, ptr %rv
  br label %ret
bb25:
  br label %bb26
bb26:
  br label %bb32
bb27:
  br i1 true, label %bb28, label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  call void @__olang_check_failed(ptr @olang_loc_61ee7aad8f880fe6_58c009051e58eda2)
  unreachable
bb32:
  br label %bb33
bb33:
  %t114 = load i64, ptr %l4, !tbaa !24
  %t116 = add i64 %t114, 1
  store i64 %t116, ptr %l4, !tbaa !24
  br label %bb7
bb34:
  %t118 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t118, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local %"compiler/source:Span" @compiler_2femit_2etermSpan({ i64, [8 x i64] } %a0) #0 {
entry:
  %l0 = alloca { i64, [8 x i64] }
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca %"compiler/source:Span"
  %l24 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store { i64, [8 x i64] } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, [8 x i64] }, ptr %l0
  %t3 = extractvalue { i64, [8 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 4
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [8 x i64] }, ptr %l0, i32 0, i32 1
  %t7 = getelementptr { %"compiler/source:Span", i32 }, ptr %t6, i32 0, i32 0
  %t8 = load %"compiler/source:Span", ptr %t7
  store %"compiler/source:Span" %t8, ptr %l1
  br label %bb7
bb2:
  %t10 = load { i64, [8 x i64] }, ptr %l0
  %t12 = extractvalue { i64, [8 x i64] } %t10, 0
  %t13 = icmp eq i64 %t12, 5
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t15 = getelementptr { i64, [8 x i64] }, ptr %l0, i32 0, i32 1
  %t16 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] } }, ptr %t15, i32 0, i32 0
  %t17 = load %"compiler/source:Span", ptr %t16
  store %"compiler/source:Span" %t17, ptr %l1
  br label %bb7
bb4:
  %t19 = load { i64, [8 x i64] }, ptr %l0
  %t21 = extractvalue { i64, [8 x i64] } %t19, 0
  %t22 = icmp eq i64 %t21, 7
  br i1 %t22, label %bb5, label %bb6
bb5:
  %t24 = getelementptr { i64, [8 x i64] }, ptr %l0, i32 0, i32 1
  %t25 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] } }, ptr %t24, i32 0, i32 0
  %t26 = load %"compiler/source:Span", ptr %t25
  store %"compiler/source:Span" %t26, ptr %l1
  br label %bb7
bb6:
  br label %bb8
bb7:
  %t28 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t28, ptr %l3
  br label %bb22
bb8:
  %t30 = load { i64, [8 x i64] }, ptr %l0
  %t32 = extractvalue { i64, [8 x i64] } %t30, 0
  %t33 = icmp eq i64 %t32, 8
  br i1 %t33, label %bb9, label %bb10
bb9:
  %t35 = getelementptr { i64, [8 x i64] }, ptr %l0, i32 0, i32 1
  %t36 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t35, i32 0, i32 0
  %t37 = load %"compiler/source:Span", ptr %t36
  store %"compiler/source:Span" %t37, ptr %l2
  br label %bb15
bb10:
  %t39 = load { i64, [8 x i64] }, ptr %l0
  %t41 = extractvalue { i64, [8 x i64] } %t39, 0
  %t42 = icmp eq i64 %t41, 9
  br i1 %t42, label %bb11, label %bb12
bb11:
  %t44 = getelementptr { i64, [8 x i64] }, ptr %l0, i32 0, i32 1
  %t45 = getelementptr { %"compiler/source:Span", i32, { i64, [4 x i64] } }, ptr %t44, i32 0, i32 0
  %t46 = load %"compiler/source:Span", ptr %t45
  store %"compiler/source:Span" %t46, ptr %l2
  br label %bb15
bb12:
  %t48 = load { i64, [8 x i64] }, ptr %l0
  %t50 = extractvalue { i64, [8 x i64] } %t48, 0
  %t51 = icmp eq i64 %t50, 6
  br i1 %t51, label %bb13, label %bb14
bb13:
  %t53 = getelementptr { i64, [8 x i64] }, ptr %l0, i32 0, i32 1
  %t54 = getelementptr { %"compiler/source:Span", i32 }, ptr %t53, i32 0, i32 0
  %t55 = load %"compiler/source:Span", ptr %t54
  store %"compiler/source:Span" %t55, ptr %l2
  br label %bb15
bb14:
  br label %bb16
bb15:
  %t57 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t57, ptr %l3
  br label %bb22
bb16:
  br i1 true, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t59 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 0, i32 0)
  store %"compiler/source:Span" %t59, ptr %l24
  br label %bb20
bb20:
  %t60 = load %"compiler/source:Span", ptr %l24
  store %"compiler/source:Span" %t60, ptr %l3
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_a69d5bfe0a165b0_62b4fff2e0b246dc)
  unreachable
bb22:
  call void @__olang_scope_close(ptr %s0)
  %t61 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t61, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local void @compiler_2femit_3acDecls_2ector(ptr %out, ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca i64
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca i64
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l11 = alloca i64
  %l13 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l15 = alloca %"compiler/emit:cDecls"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = ptrtoint ptr %v0 to i64
  store i64 %t1, ptr %l3, !tbaa !24
  %t2 = load i1, ptr @olang_2esole_2ecompiler_2femit_3acDecls_2e0
  br i1 %t2, label %bb1, label %bb2
bb1:
  %t4 = call ptr @__olang_region_make(ptr %v0)
  %t5 = ptrtoint ptr %t4 to i64
  store i64 %t5, ptr %l3, !tbaa !24
  br label %bb2
bb2:
  %t6 = load i64, ptr %l3
  %t7 = inttoptr i64 %t6 to ptr
  %t8 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t7, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t8, ptr %l5
  br label %bb3
bb3:
  %t9 = load i1, ptr @olang_2esole_2ecompiler_2femit_3acDecls_2e0
  br i1 %t9, label %bb4, label %bb5
bb4:
  %t11 = load i64, ptr %l3
  %t12 = inttoptr i64 %t11 to ptr
  %t13 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5, i32 0, i32 0
  %t14 = load { i64, ptr }, ptr %t13
  %t15 = extractvalue { i64, ptr } %t14, 1
  %t16 = call ptr @__olang_region_or(ptr %t15, ptr null)
  %t17 = icmp ne ptr %t16, null
  %t18 = select i1 %t17, ptr %t16, ptr null
  %t19 = icmp eq ptr %t18, %t12
  call void @__olang_region_settle(ptr %t12, i1 %t19)
  br label %bb5
bb5:
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %l0
  %t21 = ptrtoint ptr %v0 to i64
  store i64 %t21, ptr %l7, !tbaa !24
  %t22 = load i1, ptr @olang_2esole_2ecompiler_2femit_3acDecls_2e1
  br i1 %t22, label %bb6, label %bb7
bb6:
  %t24 = call ptr @__olang_region_make(ptr %v0)
  %t25 = ptrtoint ptr %t24 to i64
  store i64 %t25, ptr %l7, !tbaa !24
  br label %bb7
bb7:
  %t26 = load i64, ptr %l7
  %t27 = inttoptr i64 %t26 to ptr
  %t28 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t27, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t28, ptr %l9
  br label %bb8
bb8:
  %t29 = load i1, ptr @olang_2esole_2ecompiler_2femit_3acDecls_2e1
  br i1 %t29, label %bb9, label %bb10
bb9:
  %t31 = load i64, ptr %l7
  %t32 = inttoptr i64 %t31 to ptr
  %t33 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l9, i32 0, i32 0
  %t34 = load { i64, ptr }, ptr %t33
  %t35 = extractvalue { i64, ptr } %t34, 1
  %t36 = call ptr @__olang_region_or(ptr %t35, ptr null)
  %t37 = icmp ne ptr %t36, null
  %t38 = select i1 %t37, ptr %t36, ptr null
  %t39 = icmp eq ptr %t38, %t32
  call void @__olang_region_settle(ptr %t32, i1 %t39)
  br label %bb10
bb10:
  %t40 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l9
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t40, ptr %l1
  %t41 = ptrtoint ptr %v0 to i64
  store i64 %t41, ptr %l11, !tbaa !24
  %t42 = load i1, ptr @olang_2esole_2ecompiler_2femit_3acDecls_2e2
  br i1 %t42, label %bb11, label %bb12
bb11:
  %t44 = call ptr @__olang_region_make(ptr %v0)
  %t45 = ptrtoint ptr %t44 to i64
  store i64 %t45, ptr %l11, !tbaa !24
  br label %bb12
bb12:
  %t46 = load i64, ptr %l11
  %t47 = inttoptr i64 %t46 to ptr
  %t48 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e(ptr %t47)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t48, ptr %l13
  br label %bb13
bb13:
  %t49 = load i1, ptr @olang_2esole_2ecompiler_2femit_3acDecls_2e2
  br i1 %t49, label %bb14, label %bb15
bb14:
  %t51 = load i64, ptr %l11
  %t52 = inttoptr i64 %t51 to ptr
  %t53 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l13, i32 0, i32 2
  %t54 = load { i64, ptr }, ptr %t53
  %t55 = extractvalue { i64, ptr } %t54, 1
  %t56 = call ptr @__olang_region_or(ptr %t55, ptr null)
  %t57 = icmp ne ptr %t56, null
  %t58 = select i1 %t57, ptr %t56, ptr null
  %t59 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l13, i32 0, i32 1
  %t60 = load { i64, ptr }, ptr %t59
  %t61 = extractvalue { i64, ptr } %t60, 1
  %t62 = call ptr @__olang_region_or(ptr %t61, ptr null)
  %t63 = icmp ne ptr %t62, null
  %t64 = select i1 %t63, ptr %t62, ptr %t58
  %t65 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l13, i32 0, i32 0
  %t66 = load { i64, ptr }, ptr %t65
  %t67 = extractvalue { i64, ptr } %t66, 1
  %t68 = call ptr @__olang_region_or(ptr %t67, ptr null)
  %t69 = icmp ne ptr %t68, null
  %t70 = select i1 %t69, ptr %t68, ptr %t64
  %t71 = icmp eq ptr %t70, %t52
  call void @__olang_region_settle(ptr %t52, i1 %t71)
  br label %bb15
bb15:
  %t72 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l13
  %t73 = getelementptr %"compiler/emit:cDecls", ptr %l15, i32 0, i32 0
  %t74 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t74, ptr %t73
  %t75 = getelementptr %"compiler/emit:cDecls", ptr %l15, i32 0, i32 1
  %t76 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t76, ptr %t75
  %t77 = getelementptr %"compiler/emit:cDecls", ptr %l15, i32 0, i32 2
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t72, ptr %t77
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l15, i64 136, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/emit:scopeUse" @compiler_2femit_3ascopeUse_2ector(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %rv = alloca %"compiler/emit:scopeUse"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = insertvalue %"compiler/emit:scopeUse" undef, { i64, ptr } %a0, 0
  %t6 = insertvalue %"compiler/emit:scopeUse" %t4, i1 false, 1
  store %"compiler/emit:scopeUse" %t6, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/emit:scopeUse", ptr %rv
  ret %"compiler/emit:scopeUse" %rr
}

define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d0 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d1 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"<" }>, align 8
@.d2 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c">" }>, align 8
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d3 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c".ctor" }>, align 8
@.d4 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c".dtor" }>, align 8
@.d5 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"olang_lambda_" }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d6 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d7 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c".init" }>, align 8
@.d8 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"olang_case_" }>, align 8
@.d9 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"olang_cond_" }>, align 8
declare void @__olang_sb_put(ptr, ptr, i64)
@.d10 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c".contract." }>, align 8
define linkonce_odr void @olang_2emir_2eHelperKind_2eRender_2ecompiler_2ftyped_3aContractKind(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load i32, ptr %a0, !range !{i32 0, i32 1}
  %t3 = sext i32 %t2 to i64
  switch i64 %t3, label %bb1 [ i64 0, label %bb2 ]
bb1:
  br label %ret
bb2:
  %t5 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d591, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d591, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t5, i64 %t6)
  br label %bb1
ret:
  ret void
}

@.d11 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
define available_externally ptr @__olang_sb_room(ptr %sb, i64 %need) alwaysinline {
entry:
  %lenp = getelementptr { ptr, i64, i64, ptr }, ptr %sb, i32 0, i32 1
  %capp = getelementptr { ptr, i64, i64, ptr }, ptr %sb, i32 0, i32 2
  %len = load i64, ptr %lenp
  %cap = load i64, ptr %capp
  %want = add i64 %len, %need
  %fits = icmp ule i64 %want, %cap
  br i1 %fits, label %ok, label %grow
ok:
  %data = load ptr, ptr %sb
  %p = getelementptr i8, ptr %data, i64 %len
  ret ptr %p
grow:
  %g = call ptr @__olang_sb_grow(ptr %sb, i64 %need)
  ret ptr %g
}
declare void @__olang_sb_add(ptr, i64)
declare void @__olang_sb_done(ptr)
@.d12 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"olang.slot." }>, align 8
@.d13 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d14 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"olang.traitslot." }>, align 8
@.d15 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
declare void @__olang_check_failed(ptr) cold noreturn
@.d16 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"ptr sret(" }>, align 8
@.d17 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c") align " }>, align 8
@.d18 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d19 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
@.d20 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d21 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"  %" }>, align 8
@.d22 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"h = lshr i32 " }>, align 8
@.d23 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c", 16\0A" }>, align 8
@.d24 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"  %" }>, align 8
@.d25 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"e" }>, align 8
@.d26 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c" = icmp eq i32 %" }>, align 8
@.d27 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"h, " }>, align 8
@.d28 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d29 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d30 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"%" }>, align 8
@.d31 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"e" }>, align 8
@.d32 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"  %" }>, align 8
@.d33 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"o" }>, align 8
@.d34 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" = or i1 " }>, align 8
@.d35 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", %" }>, align 8
@.d36 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"e" }>, align 8
@.d37 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d38 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"%" }>, align 8
@.d39 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"o" }>, align 8
@.d40 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d41 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"__olang_check_failed" }>, align 8
@.d42 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"not lowered" }>, align 8
@.d43 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"llvm.coro.id" }>, align 8
@.d44 = private constant <{ i64, [39 x i8] }> <{ i64 0, [39 x i8] c"token @llvm.coro.id(i32, ptr, ptr, ptr)" }>, align 8
@.d45 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"llvm.coro.alloc" }>, align 8
@.d46 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"i1 @llvm.coro.alloc(token)" }>, align 8
@.d47 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"llvm.coro.size.i64" }>, align 8
@.d48 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c"i64 @llvm.coro.size.i64()" }>, align 8
@.d49 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"llvm.coro.align.i64" }>, align 8
@.d50 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"i64 @llvm.coro.align.i64()" }>, align 8
@.d51 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"llvm.coro.begin" }>, align 8
@.d52 = private constant <{ i64, [32 x i8] }> <{ i64 0, [32 x i8] c"ptr @llvm.coro.begin(token, ptr)" }>, align 8
@.d53 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"llvm.coro.suspend" }>, align 8
@.d54 = private constant <{ i64, [32 x i8] }> <{ i64 0, [32 x i8] c"i8 @llvm.coro.suspend(token, i1)" }>, align 8
@.d55 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"llvm.coro.end" }>, align 8
@.d56 = private constant <{ i64, [33 x i8] }> <{ i64 0, [33 x i8] c"i1 @llvm.coro.end(ptr, i1, token)" }>, align 8
@.d57 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"llvm.coro.free" }>, align 8
@.d58 = private constant <{ i64, [31 x i8] }> <{ i64 0, [31 x i8] c"ptr @llvm.coro.free(token, ptr)" }>, align 8
@.d59 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"llvm.coro.resume" }>, align 8
@.d60 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c"void @llvm.coro.resume(ptr)" }>, align 8
@.d61 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"llvm.coro.destroy" }>, align 8
@.d62 = private constant <{ i64, [28 x i8] }> <{ i64 0, [28 x i8] c"void @llvm.coro.destroy(ptr)" }>, align 8
@.d63 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"llvm.coro.done" }>, align 8
@.d64 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"i1 @llvm.coro.done(ptr)" }>, align 8
@.d65 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"llvm.coro.promise" }>, align 8
@.d66 = private constant <{ i64, [36 x i8] }> <{ i64 0, [36 x i8] c"ptr @llvm.coro.promise(ptr, i32, i1)" }>, align 8
@.d67 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"define " }>, align 8
@.d68 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d69 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"define " }>, align 8
@.d70 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" {" }>, align 8
@.d71 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"!dbg" }>, align 8
@.d72 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"@" }>, align 8
@.d73 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d74 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"main" }>, align 8
@.d75 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"startup" }>, align 8
@.d76 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"olang_task" }>, align 8
@.d77 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"task" }>, align 8
@.d78 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"!" }>, align 8
@.d79 = private constant <{ i64, [33 x i8] }> <{ i64 0, [33 x i8] c" = distinct !DISubprogram(name: \22" }>, align 8
@.d80 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"\22, scope: !" }>, align 8
@.d81 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c", file: !" }>, align 8
@.d82 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c", line: 0, type: !" }>, align 8
@.d83 = private constant <{ i64, [52 x i8] }> <{ i64 0, [52 x i8] c", scopeLine: 0, spFlags: DISPFlagDefinition, unit: !" }>, align 8
@.d84 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c")\0A" }>, align 8
@.d85 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"!" }>, align 8
@.d86 = private constant <{ i64, [32 x i8] }> <{ i64 0, [32 x i8] c" = !DILocation(line: 0, scope: !" }>, align 8
@.d87 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c")\0A" }>, align 8
@.d88 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" !dbg !" }>, align 8
@.d89 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" {\0A" }>, align 8
@.d90 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c", !dbg !" }>, align 8
@.d91 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"}" }>, align 8
@.d92 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d93 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d94 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"call " }>, align 8
@.d95 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"!dbg" }>, align 8
@.d96 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d97 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d98 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"__olang_argc" }>, align 8
@.d99 = private constant <{ i64, [35 x i8] }> <{ i64 0, [35 x i8] c"@__olang_argc = external global i32" }>, align 8
@.d100 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"__olang_argv" }>, align 8
@.d101 = private constant <{ i64, [35 x i8] }> <{ i64 0, [35 x i8] c"@__olang_argv = external global ptr" }>, align 8
@.d102 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"__olang_thread_init" }>, align 8
@.d103 = private constant <{ i64, [51 x i8] }> <{ i64 0, [51 x i8] c"define i32 @main(i32 %argc, ptr %argv) #0 {\0Aentry:\0A" }>, align 8
@.d104 = private constant <{ i64, [74 x i8] }> <{ i64 0, [74 x i8] c"  store i32 %argc, ptr @__olang_argc\0A  store ptr %argv, ptr @__olang_argv\0A" }>, align 8
@.d105 = private constant <{ i64, [35 x i8] }> <{ i64 0, [35 x i8] c"  call void @__olang_thread_init()\0A" }>, align 8
@.d106 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"__olang_prof_start" }>, align 8
@.d107 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"llvm.frameaddress.p0" }>, align 8
@.d108 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c"ptr @llvm.frameaddress.p0(i32)" }>, align 8
@.d109 = private constant <{ i64, [97 x i8] }> <{ i64 0, [97 x i8] c"  %proftop = call ptr @llvm.frameaddress.p0(i32 0)\0A  call void @__olang_prof_start(ptr %proftop)\0A" }>, align 8
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 8
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

@.d110 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"  call void @" }>, align 8
@.d111 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"()\0A" }>, align 8
@.d112 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"__olang_prog_end" }>, align 8
@.d113 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"  call void @" }>, align 8
@.d114 = private constant <{ i64, [50 x i8] }> <{ i64 0, [50 x i8] c"()\0A  call void @__olang_prog_end()\0A  ret i32 0\0A}\0A\0A" }>, align 8
@.d115 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"main" }>, align 8
@.d116 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d117 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"  %c = call i32 @" }>, align 8
@.d118 = private constant <{ i64, [70 x i8] }> <{ i64 0, [70 x i8] c"()\0A  %bad = icmp ne i32 %c, 0\0A  br i1 %bad, label %err, label %ok\0Aok:\0A" }>, align 8
@.d119 = private constant <{ i64, [44 x i8] }> <{ i64 0, [44 x i8] c"  call void @__olang_prog_end()\0A  ret i32 0\0A" }>, align 8
@.d120 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"err:\0A" }>, align 8
@.d121 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"fputs" }>, align 8
@.d122 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"i32 @fputs(ptr, ptr)" }>, align 8
@.d123 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"stderr" }>, align 8
@.d124 = private constant <{ i64, [29 x i8] }> <{ i64 0, [29 x i8] c"@stderr = external global ptr" }>, align 8
@.d125 = private constant <{ i64, [29 x i8] }> <{ i64 0, [29 x i8] c"  %s = load ptr, ptr @stderr\0A" }>, align 8
@.d126 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"%m0" }>, align 8
@.d127 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"unhandled error\0A" }>, align 8
@.d128 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c"  %m0 = getelementptr i8, ptr " }>, align 8
@.d129 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c", i64 0\0A" }>, align 8
@.d130 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"unhandled error: " }>, align 8
@.d131 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d132 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"  %q" }>, align 8
@.d133 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c" = icmp eq i32 %c, " }>, align 8
@.d134 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d135 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"  %m" }>, align 8
@.d136 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c" = select i1 %q" }>, align 8
@.d137 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", ptr " }>, align 8
@.d138 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d139 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"%m" }>, align 8
@.d140 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"  call i32 @fputs(ptr " }>, align 8
@.d141 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c", ptr %s)\0A" }>, align 8
@.d142 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"__olang_ert_print" }>, align 8
@.d143 = private constant <{ i64, [28 x i8] }> <{ i64 0, [28 x i8] c"void @__olang_ert_print(ptr)" }>, align 8
@.d144 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"__olang_debug_hint" }>, align 8
@.d145 = private constant <{ i64, [29 x i8] }> <{ i64 0, [29 x i8] c"void @__olang_debug_hint(ptr)" }>, align 8
@.d146 = private constant <{ i64, [86 x i8] }> <{ i64 0, [86 x i8] c"  call void @__olang_ert_print(ptr %s)\0A  call void @__olang_prog_end()\0A  ret i32 1\0A}\0A\0A" }>, align 8
@.d147 = private constant <{ i64, [87 x i8] }> <{ i64 0, [87 x i8] c"  call void @__olang_debug_hint(ptr %s)\0A  call void @__olang_prog_end()\0A  ret i32 1\0A}\0A\0A" }>, align 8
@.d148 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"main" }>, align 8
@.d149 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d150 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" @" }>, align 8
@.d151 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d152 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d153 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" @" }>, align 8
@.d154 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d155 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"__olang_" }>, align 8
@.d156 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c", ..." }>, align 8
@.d157 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"..." }>, align 8
@.d158 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@__olang_prog_scope = external thread_local(initialexec) global ptr
@.d159 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d160 = private constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c" nobuiltin memory(write)" }>, align 8
@.d161 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1 = weak hidden constant i1 false
declare ptr @__olang_region_make(ptr) noinline
@.d162 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"olang.genbuf." }>, align 8
@.d163 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d164 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"define internal void @" }>, align 8
@.d165 = private constant <{ i64, [38 x i8] }> <{ i64 0, [38 x i8] c".drop(ptr %h, ptr %scope) #0 {\0Aentry:\0A" }>, align 8
@.d166 = private constant <{ i64, [60 x i8] }> <{ i64 0, [60 x i8] c"  %p = call ptr @llvm.coro.promise(ptr %h, i32 8, i1 false)\0A" }>, align 8
@.d167 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"  %pr = getelementptr " }>, align 8
@.d168 = private constant <{ i64, [48 x i8] }> <{ i64 0, [48 x i8] c", ptr %p, i32 0, i32 1\0A  %r = load i32, ptr %pr\0A" }>, align 8
@.d169 = private constant <{ i64, [104 x i8] }> <{ i64 0, [104 x i8] c"  %idle = icmp eq i32 %r, 0\0A  br i1 %idle, label %d, label %x\0Ad:\0A  call void @llvm.coro.destroy(ptr %h)\0A" }>, align 8
@.d170 = private constant <{ i64, [31 x i8] }> <{ i64 0, [31 x i8] c"  br label %x\0Ax:\0A  ret void\0A}\0A\0A" }>, align 8
@.d171 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"|adapter" }>, align 8
@.d172 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d173 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"|" }>, align 8
@.d174 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"  %rhi = lshr i32 " }>, align 8
@.d175 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c", 16\0A  %rw = and i32 " }>, align 8
@.d176 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c", 65535\0A" }>, align 8
@.d177 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"0" }>, align 8
@.d178 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"  %rh" }>, align 8
@.d179 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c" = icmp eq i32 %rhi, " }>, align 8
@.d180 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d181 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"  %rp" }>, align 8
@.d182 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c" = select i1 %rh" }>, align 8
@.d183 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", i32 " }>, align 8
@.d184 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d185 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"%rp" }>, align 8
@.d186 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"  %rs = shl i32 " }>, align 8
@.d187 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c", 16\0A  %rv2 = or i32 %rs, %rw\0A" }>, align 8
@.d188 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"%rv2" }>, align 8
@.d189 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c" by the self-hosted compiler: " }>, align 8
@.d190 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d191 = private constant <{ i64, [45 x i8] }> <{ i64 0, [45 x i8] c"entry:\0A  call void @__olang_check_failed(ptr " }>, align 8
@.d192 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c")\0A  unreachable\0A}\0A\0A" }>, align 8
@.d193 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d194 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"a place with no base" }>, align 8
@.d195 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"getelementptr " }>, align 8
@.d196 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", ptr " }>, align 8
@.d197 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c", i32 0, i32 " }>, align 8
@.d198 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d199 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"ptr" }>, align 8
@.d200 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"getelementptr " }>, align 8
@.d201 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", ptr " }>, align 8
@.d202 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c", i32 0, i32 1" }>, align 8
@.d203 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler_2femit_3afnEm_2e15 = weak hidden constant i1 false
declare void @__olang_region_release(ptr) noinline
@.d204 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c"__olang_scope_alloc_zeroed_min" }>, align 8
@.d205 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"__olang_scope_alloc_min" }>, align 8
@.d206 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"call ptr @" }>, align 8
@.d207 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"(ptr " }>, align 8
@.d208 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", i64 " }>, align 8
@.d209 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d210 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"__olang_scope_alloc_zeroed" }>, align 8
@.d211 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"__olang_scope_alloc" }>, align 8
@.d212 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"call ptr @" }>, align 8
@.d213 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"(ptr " }>, align 8
@.d214 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", i64 " }>, align 8
@.d215 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d216 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"zeroinitializer" }>, align 8
@.d217 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"[" }>, align 8
@.d218 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" x i8]" }>, align 8
@.d219 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"i" }>, align 8
@.d220 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d221 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"[" }>, align 8
@.d222 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" x i8]" }>, align 8
@.d223 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d224 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Vec" }>, align 8
@.d225 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"std/prelude/vec" }>, align 8
@.d226 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"data" }>, align 8
@.d227 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Map" }>, align 8
@.d228 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"std/prelude/map" }>, align 8
@.d229 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"ents" }>, align 8
@.d230 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d231 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d232 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"true" }>, align 8
@.d233 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"false" }>, align 8
@.d234 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"%k" }>, align 8
@.d235 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
@.d236 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"  " }>, align 8
@.d237 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"h = lshr i32 " }>, align 8
@.d238 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c", 16\0A  " }>, align 8
@.d239 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c" = icmp eq i32 " }>, align 8
@.d240 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"h, " }>, align 8
@.d241 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d242 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"  " }>, align 8
@.d243 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c" = icmp eq i32 " }>, align 8
@.d244 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d245 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d246 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"  " }>, align 8
@.d247 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"o = or i1 " }>, align 8
@.d248 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d249 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d250 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"o" }>, align 8
@.d251 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"  br i1 " }>, align 8
@.d252 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c", label %take" }>, align 8
@.d253 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c", label %pass" }>, align 8
@.d254 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"\0Atake" }>, align 8
@.d255 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c":\0A" }>, align 8
@.d256 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"pt" }>, align 8
@.d257 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d258 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"__olang_errpay_pop" }>, align 8
@.d259 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"  br i1 " }>, align 8
@.d260 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c", label %ptyes" }>, align 8
@.d261 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c", label %ptno" }>, align 8
@.d262 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"\0Aptyes" }>, align 8
@.d263 = private constant <{ i64, [36 x i8] }> <{ i64 0, [36 x i8] c":\0A  call void @__olang_errpay_pop()\0A" }>, align 8
@.d264 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"  br label %ptno" }>, align 8
@.d265 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"\0Aptno" }>, align 8
@.d266 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c":\0A" }>, align 8
@.d267 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"  %hv" }>, align 8
@.d268 = private constant <{ i64, [28 x i8] }> <{ i64 0, [28 x i8] c" = load { ptr, ptr }, ptr %f" }>, align 8
@.d269 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d270 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"  %hc" }>, align 8
@.d271 = private constant <{ i64, [32 x i8] }> <{ i64 0, [32 x i8] c" = extractvalue { ptr, ptr } %hv" }>, align 8
@.d272 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c", 0\0A  %he" }>, align 8
@.d273 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c", 1\0A" }>, align 8
@.d274 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"ptr %he" }>, align 8
@.d275 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"  %ho" }>, align 8
@.d276 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c" = alloca " }>, align 8
@.d277 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d278 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c", ptr %ho" }>, align 8
@.d279 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"__olang_prog_scope" }>, align 8
@.d280 = private constant <{ i64, [67 x i8] }> <{ i64 0, [67 x i8] c"@__olang_prog_scope = external thread_local(initialexec) global ptr" }>, align 8
@.d281 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"  %hs" }>, align 8
@.d282 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
@.d283 = private constant <{ i64, [37 x i8] }> <{ i64 0, [37 x i8] c" = load ptr, ptr @__olang_prog_scope\0A" }>, align 8
@.d284 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c", ptr %hs" }>, align 8
@.d285 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
@.d286 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d287 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"void" }>, align 8
@.d288 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"  call void %hc" }>, align 8
@.d289 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d290 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c")\0A" }>, align 8
@.d291 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"  %hr" }>, align 8
@.d292 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c" = call " }>, align 8
@.d293 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" %hc" }>, align 8
@.d294 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d295 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c")\0A" }>, align 8
@.d296 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"%hr" }>, align 8
@.d297 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"  %hl" }>, align 8
@.d298 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c" = load " }>, align 8
@.d299 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c", ptr %ho" }>, align 8
@.d300 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d301 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"%hl" }>, align 8
@.d302 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d303 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"  %hd" }>, align 8
@.d304 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c" = load ptr, ptr %f" }>, align 8
@.d305 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"\0A  store " }>, align 8
@.d306 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d307 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c", ptr %hd" }>, align 8
@.d308 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d309 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"c" }>, align 8
@.d310 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"  ret ptr null\0Apass" }>, align 8
@.d311 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c":\0A" }>, align 8
@.d312 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d313 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"$" }>, align 8
@.d314 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c", arg: " }>, align 8
@.d315 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d316 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"!" }>, align 8
@.d317 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c" = !DILocalVariable(name: \22" }>, align 8
@.d318 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\22" }>, align 8
@.d319 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c", scope: !" }>, align 8
@.d320 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c", file: !" }>, align 8
@.d321 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c", line: " }>, align 8
@.d322 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c", type: !" }>, align 8
@.d323 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c")\0A" }>, align 8
@.d324 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"llvm.dbg.declare" }>, align 8
@.d325 = private constant <{ i64, [52 x i8] }> <{ i64 0, [52 x i8] c"void @llvm.dbg.declare(metadata, metadata, metadata)" }>, align 8
@.d326 = private constant <{ i64, [45 x i8] }> <{ i64 0, [45 x i8] c"  call void @llvm.dbg.declare(metadata ptr %l" }>, align 8
@.d327 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c", metadata !" }>, align 8
@.d328 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c", metadata !DIExpression())" }>, align 8
@.d329 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d330 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"fpext " }>, align 8
@.d331 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d332 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c" to double" }>, align 8
@.d333 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d334 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d335 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"fcmp ogt double " }>, align 8
@.d336 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", -1.0" }>, align 8
@.d337 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"fcmp olt double " }>, align 8
@.d338 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d339 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"fcmp oge double " }>, align 8
@.d340 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d341 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"fcmp ogt double " }>, align 8
@.d342 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d343 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"fcmp olt double " }>, align 8
@.d344 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d345 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"and i1 " }>, align 8
@.d346 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d347 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"xor i1 " }>, align 8
@.d348 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", true" }>, align 8
@.d349 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d350 = private constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c"a destructor not found: " }>, align 8
@.d351 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"call void @" }>, align 8
@.d352 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"_rt(ptr %l" }>, align 8
@.d353 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c", ptr %home)" }>, align 8
@.d354 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"__olang_gen_let" }>, align 8
@.d355 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"ptr" }>, align 8
@.d356 = private constant <{ i64, [31 x i8] }> <{ i64 0, [31 x i8] c"call void @__olang_gen_let(ptr " }>, align 8
@.d357 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c", ptr @" }>, align 8
@.d358 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c", ptr %keep, i64 %n)" }>, align 8
@.d359 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"__olang_gen_count" }>, align 8
@.d360 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"ptr" }>, align 8
@.d361 = private constant <{ i64, [33 x i8] }> <{ i64 0, [33 x i8] c"call void @__olang_gen_count(ptr " }>, align 8
@.d362 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", i64 " }>, align 8
@.d363 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d364 = private constant <{ i64, [32 x i8] }> <{ i64 0, [32 x i8] c"getelementptr { i64, ptr }, ptr " }>, align 8
@.d365 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c", i32 0, i32 0" }>, align 8
@.d366 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"i64" }>, align 8
@.d367 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"getelementptr " }>, align 8
@.d368 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", ptr " }>, align 8
@.d369 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c", i32 0, i32 " }>, align 8
@.d370 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"gc" }>, align 8
@.d371 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"gc" }>, align 8
@.d372 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"gc" }>, align 8
@.d373 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"gc" }>, align 8
@.d374 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"gc" }>, align 8
@.d375 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"br label %" }>, align 8
@.d376 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"br label %" }>, align 8
@.d377 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c" = phi i64 [ 0, %" }>, align 8
@.d378 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" ], [ " }>, align 8
@.d379 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", %" }>, align 8
@.d380 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" ]" }>, align 8
@.d381 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"icmp slt i64 " }>, align 8
@.d382 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d383 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"br i1 " }>, align 8
@.d384 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c", label %" }>, align 8
@.d385 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d386 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"br label %" }>, align 8
@.d387 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c" = add i64 " }>, align 8
@.d388 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 1" }>, align 8
@.d389 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"br label %" }>, align 8
@.d390 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"%l" }>, align 8
@.d391 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"%lp" }>, align 8
@.d392 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"ptr" }>, align 8
@.d393 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d394 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d395 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"|" }>, align 8
@.d396 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"~" }>, align 8
@.d397 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"olang_loc_" }>, align 8
@.d398 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
@.d399 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"@" }>, align 8
@.d400 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c" = weak_odr constant [" }>, align 8
@.d401 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" x i8] c\22" }>, align 8
@.d402 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"\5C00\22\0A" }>, align 8
@.d403 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"@" }>, align 8
@.d404 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c" = external constant [0 x i8]\0A" }>, align 8
@olang_2esole_2estd_2fprelude_2fmap_3aMapEntry_3cstd_2fprelude_2ftext_3aString_26_2c_20st_Ha3f33385783b00c3f13cf90b683d8670 = weak hidden constant i1 false
@olang_2esole_2estd_2fprelude_2fmap_3aMapEntry_3cstd_2fprelude_2ftext_3aString_26_2c_20st_Ha3f33285783aff10f13cf80b683d8c03 = weak hidden constant i1 false
@.d405 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"@" }>, align 8
@.d406 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"@" }>, align 8
define linkonce_odr %"compiler/mir:BasicBlock" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fmir_3aBasicBlock(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/mir:BasicBlock"
  %l3 = alloca %"compiler/mir:StmtList"
  %rv = alloca %"compiler/mir:BasicBlock"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"compiler/mir:BasicBlock", ptr %a0
  store %"compiler/mir:BasicBlock" %t2, ptr %l1
  %t3 = getelementptr %"compiler/mir:BasicBlock", ptr %l1, i32 0, i32 0
  %t5 = call %"compiler/mir:StmtList" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fmir_3aStmtList(ptr %v0, ptr %t3)
  store %"compiler/mir:StmtList" %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load %"compiler/mir:StmtList", ptr %l3
  %t7 = getelementptr %"compiler/mir:BasicBlock", ptr %l1, i32 0, i32 0
  store %"compiler/mir:StmtList" %t6, ptr %t7
  %t8 = load %"compiler/mir:BasicBlock", ptr %l1
  store %"compiler/mir:BasicBlock" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/mir:BasicBlock", ptr %rv
  ret %"compiler/mir:BasicBlock" %rr
}

@.d407 = private constant <{ i64, [36 x i8] }> <{ i64 0, [36 x i8] c"insertvalue { i64, ptr } undef, i64 " }>, align 8
@.d408 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 0" }>, align 8
@.d409 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c"insertvalue { i64, ptr } " }>, align 8
@.d410 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", ptr " }>, align 8
@.d411 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 1" }>, align 8
@.d412 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"rc" }>, align 8
@.d413 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"rc" }>, align 8
@.d414 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"rc" }>, align 8
@.d415 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"rc" }>, align 8
@.d416 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"icmp ne ptr " }>, align 8
@.d417 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", null" }>, align 8
@.d418 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"@" }>, align 8
@.d419 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"i1" }>, align 8
@.d420 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"and i1 " }>, align 8
@.d421 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d422 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"br i1 " }>, align 8
@.d423 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c", label %" }>, align 8
@.d424 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"getelementptr i8, ptr " }>, align 8
@.d425 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c", i64 -8" }>, align 8
@.d426 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"load atomic i64, ptr " }>, align 8
@.d427 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c" monotonic, align 8" }>, align 8
@.d428 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"br label %" }>, align 8
@.d429 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"and i64 " }>, align 8
@.d430 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c", 196608" }>, align 8
@.d431 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"icmp eq i64 " }>, align 8
@.d432 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 0" }>, align 8
@.d433 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"br i1 " }>, align 8
@.d434 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c", label %" }>, align 8
@.d435 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"{ i64, ptr }" }>, align 8
@.d436 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"null" }>, align 8
@.d437 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"[" }>, align 8
@.d438 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" x ptr]" }>, align 8
@.d439 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"getelementptr [" }>, align 8
@.d440 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c" x ptr], ptr " }>, align 8
@.d441 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c", i64 0, i64 " }>, align 8
@.d442 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"store ptr " }>, align 8
@.d443 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", ptr " }>, align 8
@.d444 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"null" }>, align 8
@.d445 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-1" }>, align 8
@.d446 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"[" }>, align 8
@.d447 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" x ptr]" }>, align 8
@.d448 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"extractvalue { i64, ptr } " }>, align 8
@.d449 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 1" }>, align 8
@.d450 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"getelementptr [" }>, align 8
@.d451 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c" x ptr], ptr " }>, align 8
@.d452 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c", i64 0, i64 " }>, align 8
@.d453 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"store ptr " }>, align 8
@.d454 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", ptr " }>, align 8
@.d455 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"@" }>, align 8
@.d456 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"i1" }>, align 8
@.d457 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"select i1 " }>, align 8
@.d458 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", i64 " }>, align 8
@.d459 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c", i64 -1" }>, align 8
@.d460 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"__olang_gen_reclaim" }>, align 8
@.d461 = private constant <{ i64, [35 x i8] }> <{ i64 0, [35 x i8] c"call void @__olang_gen_reclaim(ptr " }>, align 8
@.d462 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c", ptr @" }>, align 8
@.d463 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", ptr " }>, align 8
@.d464 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", i64 " }>, align 8
@.d465 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d466 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"br label %" }>, align 8
@.d467 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"getelementptr " }>, align 8
@.d468 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c", ptr %prom, i32 0, i32 2" }>, align 8
@.d469 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"ptr" }>, align 8
@.d470 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d471 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"i32" }>, align 8
@.d472 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"0" }>, align 8
@.d473 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"%rv" }>, align 8
@.d474 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"insertvalue " }>, align 8
@.d475 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c" zeroinitializer, " }>, align 8
@.d476 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d477 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 1" }>, align 8
@.d478 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"%rv" }>, align 8
@.d479 = private constant <{ i64, [48 x i8] }> <{ i64 0, [48 x i8] c"call i8 @llvm.coro.suspend(token none, i1 false)" }>, align 8
@.d480 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"gen.res" }>, align 8
@.d481 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"gen.drop" }>, align 8
@.d482 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"switch i8 " }>, align 8
@.d483 = private constant <{ i64, [32 x i8] }> <{ i64 0, [32 x i8] c", label %gen.end [ i8 0, label %" }>, align 8
@.d484 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c" i8 1, label %" }>, align 8
@.d485 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" ]" }>, align 8
@.d486 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"br label %" }>, align 8
@.d487 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"br label %" }>, align 8
@.d488 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d489 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d490 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"%v" }>, align 8
@.d491 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d492 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"__olang_bang_failed" }>, align 8
@.d493 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c"__olang_bang_failed_plain" }>, align 8
@.d494 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"void @" }>, align 8
@.d495 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"(ptr)" }>, align 8
@.d496 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d497 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"  %bq" }>, align 8
@.d498 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c" = icmp eq i32 " }>, align 8
@.d499 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d500 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"\0A  br i1 %bq" }>, align 8
@.d501 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c", label %bang" }>, align 8
@.d502 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c", label %bnext" }>, align 8
@.d503 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"\0Abang" }>, align 8
@.d504 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c":\0A" }>, align 8
@.d505 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
@.d506 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d507 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"  call void @" }>, align 8
@.d508 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"(ptr " }>, align 8
@.d509 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c")\0A  unreachable\0Abnext" }>, align 8
@.d510 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c":\0A" }>, align 8
@.d511 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c": unhandled error\0A" }>, align 8
@.d512 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"  call void @" }>, align 8
@.d513 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"(ptr " }>, align 8
@.d514 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c")\0A  unreachable\0A" }>, align 8
@.d515 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"  %od" }>, align 8
@.d516 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c" = load ptr, ptr %f" }>, align 8
@.d517 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"\0A  %old" }>, align 8
@.d518 = private constant <{ i64, [29 x i8] }> <{ i64 0, [29 x i8] c" = load { i64, ptr }, ptr %od" }>, align 8
@.d519 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d520 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"unreachable" }>, align 8
@.d521 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"br label %" }>, align 8
@.d522 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"br i1 " }>, align 8
@.d523 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c", label %" }>, align 8
@.d524 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"switch " }>, align 8
@.d525 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d526 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c", label %" }>, align 8
@.d527 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" [" }>, align 8
@.d528 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d529 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c", label %" }>, align 8
@.d530 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" ]" }>, align 8
@.d531 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"%out" }>, align 8
@.d532 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"i32" }>, align 8
@.d533 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"0" }>, align 8
@.d534 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"%rv" }>, align 8
@.d535 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"void" }>, align 8
@.d536 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"i32" }>, align 8
@.d537 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"0" }>, align 8
@.d538 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"%rv" }>, align 8
@.d539 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"insertvalue " }>, align 8
@.d540 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c" zeroinitializer, " }>, align 8
@.d541 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d542 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 1" }>, align 8
@.d543 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"%rv" }>, align 8
@.d544 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"%rv" }>, align 8
@.d545 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"br label %ret" }>, align 8
@.d546 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"br label %gen.free" }>, align 8
@.d547 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"i32" }>, align 8
@.d548 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"i32" }>, align 8
@.d549 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"%rv" }>, align 8
@.d550 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"insertvalue " }>, align 8
@.d551 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c" zeroinitializer, i32 " }>, align 8
@.d552 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 0" }>, align 8
@.d553 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"%rv" }>, align 8
@.d554 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"br label %ret" }>, align 8
@.d555 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"__olang_join_tasks_keep" }>, align 8
@.d556 = private constant <{ i64, [37 x i8] }> <{ i64 0, [37 x i8] c"i64 @__olang_join_tasks_keep(ptr, i1)" }>, align 8
@.d557 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"true" }>, align 8
@.d558 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"false" }>, align 8
@.d559 = private constant <{ i64, [41 x i8] }> <{ i64 0, [41 x i8] c"call i64 @__olang_join_tasks_keep(ptr %jh" }>, align 8
@.d560 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c", i1 " }>, align 8
@.d561 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d562 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"trunc i64 " }>, align 8
@.d563 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" to i32" }>, align 8
@.d564 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"br label %" }>, align 8
@.d565 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"i32" }>, align 8
@.d566 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"icmp ne i32 " }>, align 8
@.d567 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 0" }>, align 8
@.d568 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"br i1 " }>, align 8
@.d569 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c", label %" }>, align 8
@.d570 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"a cleanup (interpret's)" }>, align 8
@.d571 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"zext i16 " }>, align 8
@.d572 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" to i32" }>, align 8
@.d573 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"shl i32 " }>, align 8
@.d574 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c", 16" }>, align 8
@.d575 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"bitcast i32 " }>, align 8
@.d576 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" to float" }>, align 8
@.d577 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"float" }>, align 8
@.d578 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"fpext float " }>, align 8
@.d579 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" to " }>, align 8
@.d580 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"@" }>, align 8
@.d581 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@.d582 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"sqrt" }>, align 8
@.d583 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"floor" }>, align 8
@.d584 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"ceil" }>, align 8
@.d585 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"trunc" }>, align 8
@.d586 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"round" }>, align 8
@.d587 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"roundeven" }>, align 8
@.d588 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"fabs" }>, align 8
@.d589 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"copysign" }>, align 8
@.d590 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"fma" }>, align 8
@olang_2esole_2ecompiler_2femit_3acDecls_2e0 = weak hidden constant i1 false
declare ptr @__olang_region_or(ptr, ptr)
declare void @__olang_region_settle(ptr, i1)
@olang_2esole_2ecompiler_2femit_3acDecls_2e1 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2femit_3acDecls_2e2 = weak hidden constant i1 false
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@.d591 = private unnamed_addr constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"typed.ContractKind.Req" }>, align 8
declare ptr @__olang_sb_grow(ptr, i64) noinline
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
define linkonce_odr %"compiler/mir:StmtList" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fmir_3aStmtList(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/mir:StmtList"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"compiler/mir:StmtList"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"compiler/mir:StmtList", ptr %a0
  store %"compiler/mir:StmtList" %t2, ptr %l1
  %t3 = getelementptr %"compiler/mir:StmtList", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 176
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 176
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"compiler/mir:StmtList", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"compiler/mir:StmtList", ptr %l1
  store %"compiler/mir:StmtList" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/mir:StmtList", ptr %rv
  ret %"compiler/mir:StmtList" %rr
}

declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %a0)
declare i8 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eToUpper(i8 %a0)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceName(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanonList(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2eSymbol(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etestSym(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etext(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etableName(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecanonOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_de1fe604fb5e87cf_ff4728625cff78d3 = external constant [0 x i8]
declare %"compiler/cabi:Regs" @compiler_2fcabi_3aRegs_2ector(ptr %v0, i64 %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eVoidT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eNoreturnT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\11\00\00\00" }>, align 8
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLayout(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/cabi:Way" @compiler_2fcabi_2eWay_2eResult(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, i32 %a2)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAlign(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecParamSpelled(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, ptr %a2, i1 %a3)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2eLen_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0, ptr %a0)
declare { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2eAt_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_9506350913203bfc_41d6488afcc367c0 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePayloadOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/lower:Clone" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3aClone_3e_2eAt_3ccompiler_2flower_3aClone_3e(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2flower_2ecompiler_2flower_3aLowerer_2eLowerKey(ptr %v0, ptr %v1, ptr %a0, { i64, [2 x i64] } %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecloneSym(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ehasEnv(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
declare i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2epassedOf(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, i32 %a2)
@G_2ecompiler_2femit_2eHomeInst = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FD\FF\FF\FF\FF\FF\FF\FF" }>, align 8
declare { i64, ptr } @compiler_2femit_2elinkFor(ptr %v0, i64 %a0)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eheader(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, [2 x i64] } %a1, i32 %a2, { i64, ptr } %a3, i64 %a4, i1 %a5, { i64, ptr } %a6, { i64, ptr } %a7)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2efnItem(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, [2 x i64] } %a1, i32 %a2, { i64, ptr } %a3, i64 %a4, i1 %a5, { i64, ptr } %a6)
declare i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ewriteBody(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, [2 x i64] } %a1, ptr %a2, { i64, ptr } %a3, i64 %a4, i1 %a5, { i64, ptr } %a6, i1 %a7)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %v1, ptr %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_b200df0f2ca52fe9_68c86c80ca4bbd4d = external constant [0 x i8]
declare { i64, ptr } @compiler_2ftypes_2eDemangle(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ereadableTypes(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgGenFile(ptr %v0, ptr %a0)
declare i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgNew(ptr %v0, ptr %a0)
declare i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgSubTy(ptr %v0, ptr %a0)
declare i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgCu(ptr %v0, ptr %a0)
@olang_loc_e7f1f4c1c7eb01fc_51bf614425d25b70 = external constant [0 x i8]
declare i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %v0, ptr %a0)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edefine(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2esanInit(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2femit_2ecompiler_2femit_3aEmitter_2eglobalOrder(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2feval_3aImage_3e_2e_H901ad831a5883703dcf426ee01511832(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2esym(ptr %v0, ptr %v1, ptr %a0, { i64, [2 x i64] } %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eitem(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, i64 %a2, { i64, ptr } %a3, { i64, ptr } %a4)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecstr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorWords(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eerrQualifier(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorWordName(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i64 %a2)
declare i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2etraced(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eExternSymbol(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2emathIntrinsic(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2)
declare i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ehas(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eexternRet(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2emathParams(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecHeader(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6b5ccacad8db807339a3579aa8c82ff8(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@G_2ecompiler_2femit_2emathInexact = external constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [24 x i8] }>
@olang_loc_672626b841abebed_e9d6bd273cfd5371 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H0127831368543eff3b7740d7d3240080(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2estableSym(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare ptr @compiler_2flower_2ecompiler_2flower_3aLowerer_2eGen(ptr %v0, ptr %v1, ptr %a0)
declare i1 @compiler_2fmir_2ecompiler_2fmir_3aGenInfo_2eHasLeaves(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2einstGroupOf(ptr %v0, ptr %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_a37d1f87ccda68bc_daadd8872686b520 = external constant [0 x i8]
@olang_loc_7f6c4a9881f0c77f_244fd8f3f85b2bab = external constant [0 x i8]
@olang_loc_1cb2b0b1c80ab6bb_ff3b7bcb0dec81bf = external constant [0 x i8]
@olang_loc_dd4469a9ae312a3a_602f574df5758ebe = external constant [0 x i8]
declare i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eposition(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2elocalType(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eglobal(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2, i32 %a3)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2egap(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_a45e6d34f8d75be7_fb9ba052a05cfc3b = external constant [0 x i8]
declare { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e_2eAt_3ccompiler_2fmir_3aProj_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2efieldList(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etbaa(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i1 %a2)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eindex(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2)
declare i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2erunTime(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2edescTag(ptr %v0, ptr %v1, ptr %a0, i1 %a1, i1 %a2)
declare { { i64, ptr }, i32 } @compiler_2femit_2ecompiler_2femit_3afnEm_2eelemAt(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, i32 %a2, { i64, ptr } %a3, { i64, ptr } %a4)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2ecasesList(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_f0091f918c975106_bc2d594a86836fba = external constant [0 x i8]
declare { i64, [4 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2eAt_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2esize(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ealloca(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i64 %a2)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFieldNames(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i32 @compiler_2fmir_2eFieldsOf(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %a0, i64 %a1)
declare %"compiler/mir:ScopeInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeInfo_3e_2eAt_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_538eacb44f7c8f74_e1c936133deb4fd8 = external constant [0 x i8]
declare %"compiler/mir:TaskClause" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTaskClause_3e_2eAt_3ccompiler_2fmir_3aTaskClause_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/typed:Item" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aItem_3e_2eAt_3ccompiler_2ftyped_3aItem_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eotype(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2esignature(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eViaMemory(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fmir_2ePassedCount(ptr %v0, ptr %a0, { i64, [7 x i64] } %a1, i32 %a2)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRetLlvm(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2estoreParts(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2, i32 %a3, { i64, ptr } %a4, i64 %a5, i32 %a6)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2etaskFix(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, %"compiler/mir:Task" %a2, i64 %a3, { i64, ptr } %a4, { i64, ptr } %a5)
declare i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgFile(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eLen_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %a0)
declare %"compiler/mir:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2eisFrame(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1)
declare i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgType(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLineAt(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2edbgEntry(ptr %v0, ptr %v1, ptr %a0)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2epow2(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2econstText(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i64 %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eLen_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eAt_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNeedsDrop(ptr %v0, ptr %a0, i32 %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__H165e1ff795edcbb725e28dde18fd1dc2(ptr %v0, ptr %a0, i32 %a1)
declare { i32, { i64, [2 x i64] } } @compiler_2fmir_2eFnKey_2eDropFn(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2ewant(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e_2e_Hf0a5beca6f8aee4731a76bd327ae0a99(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e_2e_He6968003b8dd5762fa82ec44b4ee1fc9(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, i1 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFnKey_3e_2ePush_3ccompiler_2fmir_3aFnKey_3e(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @compiler_2fmir_2ecompiler_2fmir_3aGenInfo_2eHoldsGen(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2egenDropFn(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2efixed(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2efixedLen(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fmir_2eHasFields(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fmir_2ecompiler_2fmir_3aGenInfo_2eWeakField(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, i64 %a3)
declare i1 @compiler_2fmir_2eHasCases(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eenumWords(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2eholdersCases(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2, { i64, ptr } %a3)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2elabel(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2etmp(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ewhere(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/source:Span" %a2)
declare { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha4444909f5ef14f7626d25b8f59e6ba2(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eHash(ptr %v0, { i64, ptr } %a0)
declare { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %v0, i64 %a0)
declare { i64, ptr } @std_2fprelude_2ftext_2eU64_2eFormat(ptr %v0, i64 %a0, i64 %a1)
@olang_loc_6a1c0f36bb2af484_15693b919ea68168 = external constant [0 x i8]
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9b83f66eba65594537030636cb0b52b7(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@G_2ecompiler_2femit_2eHomeLoc = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FC\FF\FF\FF\FF\FF\FF\FF" }>, align 8
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6f7a2f8d839c49b6e7a19c287d4b190c(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2ector(ptr %v0, i64 %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eLen_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, ptr %a0)
declare %"compiler/mir:BasicBlock" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eAt_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @compiler_2fmir_2ecompiler_2fmir_3aStmtList_2eLen(ptr %v0, ptr %a0)
declare { i64, [21 x i64] } @compiler_2fmir_2ecompiler_2fmir_3aStmtList_2eAt(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eClear_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %a0)
declare void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eMentions(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, ptr %a3)
declare i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2enewOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2, i32 %a3)
declare void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eTermMentions(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, [8 x i64] } %a1, ptr %a2, ptr %a3)
@olang_loc_496cd21b134a4626_34cb2ee199c6502a = external constant [0 x i8]
@olang_loc_768769e499c57657_c453ba5dc43e6f8b = external constant [0 x i8]
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2egenOk(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %v1, ptr %a0, { i64, [4 x i64] } %a1, i32 %a2)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2ector(ptr %v0, i64 %a0)
declare i1 @compiler_2fmir_2ecompiler_2fmir_3aGenInfo_2eGenRef(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2ePush_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2eLen_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2egenBuf(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2eput(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2, { i64, [4 x i64] } %a3, { i64, ptr } %a4)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e_2eAt_3ccompiler_2fmir_3aScopeRef_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_97d51a883f8cc986_4828fb3e43690a82 = external constant [0 x i8]
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2eunwindPop(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2erehold(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2femit_2eblockName(ptr %v0, i32 %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aVarKind_3e_2eLen_3ccompiler_2fmir_3aVarKind_3e(ptr %v0, ptr %a0)
declare { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aVarKind_3e_2eAt_3ccompiler_2fmir_3aVarKind_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_a013fd5d1a1a0ecb_8946a3e4bb7adef = external constant [0 x i8]
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2econstText(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_625291c18633ca8a_b2d4e63a7cb7312e = external constant [0 x i8]
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2elocate(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
@G_2ecompiler_2ftypes_2eBoolT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
declare %"compiler/mir:Case" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCase_3e_2eAt_3ccompiler_2fmir_3aCase_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/mir:Call" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e_2eAt_3ccompiler_2fmir_3aCall_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2ecall(ptr %v0, ptr %a0, %"compiler/mir:Call" %a1)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2etailCall(ptr %v0, ptr %a0, %"compiler/mir:Call" %a1)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2etrace(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
@G_2ecompiler_2fmir_2eI32T = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\05\00\00\00" }>, align 8
@G_2ecompiler_2fmir_2eNoBlock = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\FF\FF\FF\FF" }>, align 8
@G_2ecompiler_2fmir_2eNoLocal = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\FF\FF\FF\FF" }>, align 8
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2eexit(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, { i64, [4 x i64] } %a3)
@olang_loc_7633dd9d24c54174_280dfd74a77e9550 = external constant [0 x i8]
declare %"compiler/mir:Lvalue" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLvalue_3e_2eAt_3ccompiler_2fmir_3aLvalue_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eplaceType(ptr %v0, ptr %a0, %"compiler/mir:Lvalue" %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ebf16Bits(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i1 %a2)
declare i1 @compiler_2femit_2esymbolChar(i8 %a0)
@olang_loc_f695fddd526749db_a8fb91cf3e060dd7 = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2ftext_2eU8_2eFormat(ptr %v0, i8 %a0, i64 %a1)
@olang_loc_b05c5d37656b7ecf_b2cabd35ece02ebb = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadStart(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i8 %a2)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eToUpper(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2)
@olang_loc_56e40b98d8735a00_a9923da8dafaf70c = external constant [0 x i8]
@olang_loc_61ee7aad8f880fe6_58c009051e58eda2 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
@olang_loc_a69d5bfe0a165b0_62b4fff2e0b246dc = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
