; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/emit:Emitter" = type { ptr, ptr, ptr, ptr, i1, i1, i1, i1, { i64, ptr }, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, i64, i1, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i64, i64, i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, i1, { i64, ptr }, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, i64, { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, i1, i64, i64, i64, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/generic:AnyTable" = type { i32, i32, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/source:Span" = type { i32, i32 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/types:Table" = type { ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64 }
%"compiler/cabi:Way" = type { i32, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr } }
%"compiler/lower:Lowerer" = type { ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i32, i32 }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i32, i1, i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1, i1 }
%"compiler/cabi:Regs" = type { i64, i64 }
%"compiler/mir:Fn" = type { { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/emit:fnEm" = type { ptr, ptr, { i64, [2 x i64] }, %"std/prelude/text:StringBuilder", %"std/prelude/text:StringBuilder", %"std/prelude/text:StringBuilder", i64, i64, i64, i32, i1, i1, i1, i1, { i64, ptr }, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, { i64, ptr }, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/text:StringBuilder", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, { i64, ptr }, i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i64, i64 }
%"compiler/eval:Image" = type { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/eval:Blob" = type { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce" = type { ptr, i64, ptr, ptr }
%"std/prelude/map:MapEntry.eb00e4a6e4307a4e46e40fbcd79d6b4f" = type { i64, i1 }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, ptr, i1, i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, { i64, ptr }, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/mir:Place" = type { { i64, [2 x i64] }, %"compiler/mir:Range" }
%"compiler/mir:Range" = type { i32, i32 }
%"compiler/mir:BasicBlock" = type { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, [8 x i64] } }
%"compiler/mir:ScopeInfo" = type { i32, i32, i32, %"compiler/source:Span", i32 }
%"compiler/emit:Reused" = type { i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64 }
define dso_local void @compiler_2femit_2ePartSize_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 1048576, ptr @G_2ecompiler_2femit_2ePartSize, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eabiDiffers(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l14 = alloca i1
  %l16 = alloca i1
  %l19 = alloca i32
  %l22 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %a0, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load ptr, ptr %l3, !tbaa !29
  %t7 = load i32, ptr %l1, !tbaa !23
  %t10 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRetLlvm(ptr %v0, ptr %s0, ptr %t6, i32 %t7)
  store { i64, ptr } %t10, ptr %l8
  br label %bb1
bb1:
  %t11 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t11, 0
  %t13 = extractvalue { i64, ptr } %t11, 1
  %t14 = mul i64 %t12, 1
  %t15 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t14)
  call void @llvm.memcpy.p0.p0.i64(ptr %t15, ptr %t13, i64 %t14, i1 false)
  %t16 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t15, 1
  store { i64, ptr } %t17, ptr %l9, !tbaa !27
  %t18 = load ptr, ptr %l3, !tbaa !29
  %t19 = load i32, ptr %l2, !tbaa !23
  %t22 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRetLlvm(ptr %v0, ptr %s0, ptr %t18, i32 %t19)
  store { i64, ptr } %t22, ptr %l12
  br label %bb2
bb2:
  %t23 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t23, 0
  %t25 = extractvalue { i64, ptr } %t23, 1
  %t26 = mul i64 %t24, 1
  %t27 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t26)
  call void @llvm.memcpy.p0.p0.i64(ptr %t27, ptr %t25, i64 %t26, i1 false)
  %t28 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t27, 1
  %t30 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t32 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t30, { i64, ptr } %t29)
  store i1 %t32, ptr %l14
  br label %bb3
bb3:
  %t33 = load i1, ptr %l14, !tbaa !21
  %t34 = xor i1 %t33, true
  br i1 %t34, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb8
bb5:
  %t36 = load ptr, ptr %l3, !tbaa !29
  %t37 = load i32, ptr %l1, !tbaa !23
  %t40 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t36, i32 %t37)
  store i32 %t40, ptr %l19
  br label %bb6
bb6:
  %t41 = load ptr, ptr %l3, !tbaa !29
  %t42 = load i32, ptr %l2, !tbaa !23
  %t45 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t41, i32 %t42)
  store i32 %t45, ptr %l22
  br label %bb7
bb7:
  %t46 = load i32, ptr %l19, !tbaa !23
  %t47 = load i32, ptr %l22, !tbaa !23
  %t48 = icmp ne i32 %t46, %t47
  store i1 %t48, ptr %l16, !tbaa !21
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s0)
  %t50 = load i1, ptr %l16, !tbaa !21
  store i1 %t50, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eanyTable(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %lp2 = alloca ptr
  %l3 = alloca %"compiler/generic:AnyTable"
  %l4 = alloca %"std/prelude/text:StringBuilder"
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca { i64, [2 x i64] }
  %l10 = alloca ptr
  %l11 = alloca i64
  %l13 = alloca { i64, [2 x i64] }
  %l17 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l23 = alloca i1
  %l29 = alloca %"compiler/generic:AnyTable"
  %l30 = alloca %"std/prelude/text:StringBuilder"
  %l31 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l53 = alloca ptr
  %l56 = alloca { i64, ptr }
  %l62 = alloca i64
  %l64 = alloca i64
  %l69 = alloca i64
  %l76 = alloca ptr
  %l79 = alloca { i64, ptr }
  %l85 = alloca i64
  %l88 = alloca ptr
  %l89 = alloca { i64, ptr }
  %l90 = alloca i64
  %l91 = alloca { i64, ptr }
  %l92 = alloca i64
  %l94 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t101 = alloca { i64, [2 x i64] }, align 8
  %t164 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etableName(ptr %v0, ptr %s0, ptr %t1, i64 %t2)
  store { i64, ptr } %t5, ptr %l17
  br label %bb1
bb1:
  %t6 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d0, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d0, i32 0, i32 1) }, 0
  %t8 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t8, 1
  %t10 = extractvalue { i64, ptr } %t8, 0
  %t11 = add i64 %t7, %t10
  %t12 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t11)
  call void @olang_textcopy(ptr %t12, ptr %t6, i64 %t7)
  %t13 = getelementptr i8, ptr %t12, i64 %t7
  call void @olang_textcopy(ptr %t13, ptr %t9, i64 %t10)
  %t14 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t12, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t24 = call { i64, ptr } @compiler_2ftypes_2eSymbol(ptr %v1, ptr %v1, { i64, ptr } %t22)
  store { i64, ptr } %t24, ptr %l20
  br label %bb2
bb2:
  %t25 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t25, ptr %lp2
  %t26 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t27 = load ptr, ptr %lp2
  store { i64, ptr } %t26, ptr %t27, !tbaa !27
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load ptr, ptr %lp2
  %t30 = load { i64, ptr }, ptr %t29, !tbaa !27
  %t33 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ehas(ptr %v0, ptr %v1, ptr %t28, { i64, ptr } %t30)
  store i1 %t33, ptr %l23
  br label %bb3
bb3:
  %t34 = load i1, ptr %l23, !tbaa !21
  br i1 %t34, label %bb4, label %bb5
bb4:
  %t35 = load ptr, ptr %lp2
  %t36 = load { i64, ptr }, ptr %t35, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t36, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/emit:Emitter", ptr %t38, i32 0, i32 0
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t43 = getelementptr %"compiler/generic:Program", ptr %t41, i32 0, i32 43
  %t44 = load i64, ptr %l1, !tbaa !24
  %t47 = call %"compiler/generic:AnyTable" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aAnyTable_3e_2eAt__He9601a52fe5cfa5abe1b41d520aed001(ptr %v0, ptr %v0, ptr %t43, i64 %t44)
  store %"compiler/generic:AnyTable" %t47, ptr %l29
  br label %bb7
bb7:
  %t48 = load %"compiler/generic:AnyTable", ptr %l29
  store %"compiler/generic:AnyTable" %t48, ptr %l3
  %t49 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t49, ptr %l30
  br label %bb8
bb8:
  %t50 = load %"std/prelude/text:StringBuilder", ptr %l30
  store %"std/prelude/text:StringBuilder" %t50, ptr %l4
  store ptr %l4, ptr %l31, !tbaa !29
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/generic:AnyTable", ptr %l3, i32 0, i32 0
  %t53 = load i32, ptr %t52, !tbaa !23
  %t56 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etypeid(ptr %v0, ptr %s0, ptr %t51, i32 %t53)
  store { i64, ptr } %t56, ptr %l34
  br label %bb9
bb9:
  %t57 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d1, i32 0, i32 1) }, 1
  %t58 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d1, i32 0, i32 1) }, 0
  %t59 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t60 = extractvalue { i64, ptr } %t59, 1
  %t61 = extractvalue { i64, ptr } %t59, 0
  %t62 = add i64 %t58, %t61
  %t63 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t62)
  call void @olang_textcopy(ptr %t63, ptr %t57, i64 %t58)
  %t64 = getelementptr i8, ptr %t63, i64 %t58
  call void @olang_textcopy(ptr %t64, ptr %t60, i64 %t61)
  %t65 = insertvalue { i64, ptr } undef, i64 %t62, 0
  %t66 = insertvalue { i64, ptr } %t65, ptr %t63, 1
  %t68 = extractvalue { i64, ptr } %t66, 0
  %t69 = extractvalue { i64, ptr } %t66, 1
  %t70 = mul i64 %t68, 1
  %t71 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t70)
  call void @llvm.memcpy.p0.p0.i64(ptr %t71, ptr %t69, i64 %t70, i1 false)
  %t72 = insertvalue { i64, ptr } undef, i64 %t68, 0
  %t73 = insertvalue { i64, ptr } %t72, ptr %t71, 1
  %t74 = load ptr, ptr %l31, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t74, { i64, ptr } %t73)
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s4
  %t76 = insertvalue [2 x i1] undef, i1 false, 0
  %t77 = insertvalue [2 x i1] %t76, i1 true, 1
  %t79 = call ptr @__olang_scope_alloc_a(ptr %s4, i64 2, i64 8)
  store [2 x i1] %t77, ptr %t79
  store ptr %t79, ptr %l5
  store i64 0, ptr %l6, !tbaa !24
  %t81 = load ptr, ptr %l5
  store i64 2, ptr %l7, !tbaa !24
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s5
  %t84 = load i64, ptr %l6, !tbaa !24
  %t85 = load i64, ptr %l7, !tbaa !24
  %t88 = icmp slt i64 %t84, %t85
  %t90 = xor i1 %t88, true
  br i1 %t90, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s5)
  br label %bb19
bb13:
  br label %bb14
bb14:
  %t92 = load ptr, ptr %l5
  %t93 = load i64, ptr %l6, !tbaa !24
  %t96 = getelementptr [2 x i1], ptr %t92, i64 0, i64 %t93
  %t97 = load i1, ptr %t96, !tbaa !31
  %t99 = load i64, ptr %l1, !tbaa !24
  store { i64, [2 x i64] } zeroinitializer, ptr %t101
  %t102 = getelementptr { i64, [2 x i64] }, ptr %t101, i32 0, i32 0
  store i64 4, ptr %t102
  %t104 = insertvalue { i64, i1 } undef, i64 %t99, 0
  %t106 = insertvalue { i64, i1 } %t104, i1 %t97, 1
  %t107 = getelementptr { i64, [2 x i64] }, ptr %t101, i32 0, i32 1
  store { i64, i1 } %t106, ptr %t107
  %t108 = load { i64, [2 x i64] }, ptr %t101
  store { i64, [2 x i64] } %t108, ptr %l9
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t111 = load { i64, [2 x i64] }, ptr %l9
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2ewant(ptr %v0, ptr %t110, { i64, [2 x i64] } %t111)
  br label %bb15
bb15:
  store ptr %l4, ptr %l53, !tbaa !29
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t115 = load { i64, [2 x i64] }, ptr %l9
  %t118 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2esym(ptr %v0, ptr %s5, ptr %t114, { i64, [2 x i64] } %t115)
  store { i64, ptr } %t118, ptr %l56
  br label %bb16
bb16:
  %t119 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d2, i32 0, i32 1) }, 1
  %t120 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d2, i32 0, i32 1) }, 0
  %t121 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t122 = extractvalue { i64, ptr } %t121, 1
  %t123 = extractvalue { i64, ptr } %t121, 0
  %t124 = add i64 %t120, %t123
  %t125 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t124)
  call void @olang_textcopy(ptr %t125, ptr %t119, i64 %t120)
  %t126 = getelementptr i8, ptr %t125, i64 %t120
  call void @olang_textcopy(ptr %t126, ptr %t122, i64 %t123)
  %t127 = insertvalue { i64, ptr } undef, i64 %t124, 0
  %t128 = insertvalue { i64, ptr } %t127, ptr %t125, 1
  %t130 = extractvalue { i64, ptr } %t128, 0
  %t131 = extractvalue { i64, ptr } %t128, 1
  %t132 = mul i64 %t130, 1
  %t133 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t132)
  call void @llvm.memcpy.p0.p0.i64(ptr %t133, ptr %t131, i64 %t132, i1 false)
  %t134 = insertvalue { i64, ptr } undef, i64 %t130, 0
  %t135 = insertvalue { i64, ptr } %t134, ptr %t133, 1
  %t136 = load ptr, ptr %l53, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s5, ptr %t136, { i64, ptr } %t135)
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s5)
  br label %bb18
bb18:
  %t138 = load i64, ptr %l6, !tbaa !24
  %t140 = add i64 %t138, 1
  store i64 %t140, ptr %l6, !tbaa !24
  br label %bb11
bb19:
  call void @__olang_scope_close(ptr %s4)
  %t142 = getelementptr %"compiler/generic:AnyTable", ptr %l3, i32 0, i32 5
  store ptr %t142, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  br label %bb20
bb20:
  store %olang.scope zeroinitializer, ptr %s9
  %t144 = load i64, ptr %l11, !tbaa !24
  store i64 %t144, ptr %l62, !tbaa !24
  %t145 = load ptr, ptr %l10, !tbaa !29
  %t147 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t145)
  store i64 %t147, ptr %l64
  br label %bb21
bb21:
  %t148 = load i64, ptr %l62, !tbaa !24
  %t149 = load i64, ptr %l64, !tbaa !24
  %t150 = icmp slt i64 %t148, %t149
  %t152 = xor i1 %t150, true
  br i1 %t152, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s9)
  br label %bb30
bb23:
  br label %bb24
bb24:
  %t154 = load ptr, ptr %l10, !tbaa !29
  %t155 = load i64, ptr %l11, !tbaa !24
  %t158 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t154, i64 %t155)
  store i64 %t158, ptr %l69
  br label %bb25
bb25:
  %t159 = load i64, ptr %l69, !tbaa !24
  %t162 = trunc i64 %t159 to i32
  store { i64, [2 x i64] } zeroinitializer, ptr %t164
  %t165 = getelementptr { i64, [2 x i64] }, ptr %t164, i32 0, i32 0
  store i64 0, ptr %t165
  %t167 = insertvalue { i32 } undef, i32 %t162, 0
  %t168 = getelementptr { i64, [2 x i64] }, ptr %t164, i32 0, i32 1
  store { i32 } %t167, ptr %t168
  %t169 = load { i64, [2 x i64] }, ptr %t164
  store { i64, [2 x i64] } %t169, ptr %l13
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t172 = load { i64, [2 x i64] }, ptr %l13
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2ewant(ptr %v0, ptr %t171, { i64, [2 x i64] } %t172)
  br label %bb26
bb26:
  store ptr %l4, ptr %l76, !tbaa !29
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t176 = load { i64, [2 x i64] }, ptr %l13
  %t179 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2esym(ptr %v0, ptr %s9, ptr %t175, { i64, [2 x i64] } %t176)
  store { i64, ptr } %t179, ptr %l79
  br label %bb27
bb27:
  %t180 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d3, i32 0, i32 1) }, 1
  %t181 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d3, i32 0, i32 1) }, 0
  %t182 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t183 = extractvalue { i64, ptr } %t182, 1
  %t184 = extractvalue { i64, ptr } %t182, 0
  %t185 = add i64 %t181, %t184
  %t186 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t185)
  call void @olang_textcopy(ptr %t186, ptr %t180, i64 %t181)
  %t187 = getelementptr i8, ptr %t186, i64 %t181
  call void @olang_textcopy(ptr %t187, ptr %t183, i64 %t184)
  %t188 = insertvalue { i64, ptr } undef, i64 %t185, 0
  %t189 = insertvalue { i64, ptr } %t188, ptr %t186, 1
  %t191 = extractvalue { i64, ptr } %t189, 0
  %t192 = extractvalue { i64, ptr } %t189, 1
  %t193 = mul i64 %t191, 1
  %t194 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t193)
  call void @llvm.memcpy.p0.p0.i64(ptr %t194, ptr %t192, i64 %t193, i1 false)
  %t195 = insertvalue { i64, ptr } undef, i64 %t191, 0
  %t196 = insertvalue { i64, ptr } %t195, ptr %t194, 1
  %t197 = load ptr, ptr %l76, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s9, ptr %t197, { i64, ptr } %t196)
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s9)
  br label %bb29
bb29:
  %t199 = load i64, ptr %l11, !tbaa !24
  %t201 = add i64 %t199, 1
  store i64 %t201, ptr %l11, !tbaa !24
  br label %bb20
bb30:
  %t203 = getelementptr %"compiler/generic:AnyTable", ptr %l3, i32 0, i32 5
  %t205 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t203)
  store i64 %t205, ptr %l85
  br label %bb31
bb31:
  %t206 = load i64, ptr @G_2ecompiler_2ftypes_2eAnySlotBase, !tbaa !24
  %t207 = load i64, ptr %l85, !tbaa !24
  %t209 = add i64 %t207, %t206
  %t211 = load ptr, ptr %l0, !tbaa !29
  store ptr %t211, ptr %l88, !tbaa !29
  %t212 = load ptr, ptr %lp2
  %t213 = load { i64, ptr }, ptr %t212, !tbaa !27
  store { i64, ptr } %t213, ptr %l89, !tbaa !27
  %t214 = load i64, ptr @G_2ecompiler_2femit_2eHomeShared, !tbaa !24
  store i64 %t214, ptr %l90, !tbaa !24
  %t215 = load ptr, ptr %lp2
  %t216 = load { i64, ptr }, ptr %t215, !tbaa !27
  store { i64, ptr } %t216, ptr %l91, !tbaa !27
  store i64 %t209, ptr %l92, !tbaa !24
  %t219 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l4)
  store { i64, ptr } %t219, ptr %l94
  br label %bb32
bb32:
  %t220 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d4, i32 0, i32 1) }, 1
  %t221 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d4, i32 0, i32 1) }, 0
  %t222 = load { i64, ptr }, ptr %l91, !tbaa !27
  %t223 = extractvalue { i64, ptr } %t222, 1
  %t224 = extractvalue { i64, ptr } %t222, 0
  %t225 = add i64 %t221, %t224
  %t226 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d5, i32 0, i32 1) }, 1
  %t227 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d5, i32 0, i32 1) }, 0
  %t228 = add i64 %t225, %t227
  %t229 = load i64, ptr %l92, !tbaa !24
  %t230 = call i64 @__olang_fmt_i64(ptr null, i64 %t229)
  %t231 = add i64 %t228, %t230
  %t232 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d6, i32 0, i32 1) }, 1
  %t233 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d6, i32 0, i32 1) }, 0
  %t234 = add i64 %t231, %t233
  %t235 = load { i64, ptr }, ptr %l94, !tbaa !27
  %t236 = extractvalue { i64, ptr } %t235, 1
  %t237 = extractvalue { i64, ptr } %t235, 0
  %t238 = add i64 %t234, %t237
  %t239 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d7, i32 0, i32 1) }, 1
  %t240 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d7, i32 0, i32 1) }, 0
  %t241 = add i64 %t238, %t240
  %t242 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t241)
  call void @olang_textcopy(ptr %t242, ptr %t220, i64 %t221)
  %t243 = getelementptr i8, ptr %t242, i64 %t221
  call void @olang_textcopy(ptr %t243, ptr %t223, i64 %t224)
  %t244 = getelementptr i8, ptr %t243, i64 %t224
  call void @olang_textcopy(ptr %t244, ptr %t226, i64 %t227)
  %t245 = getelementptr i8, ptr %t244, i64 %t227
  %t246 = call i64 @__olang_fmt_i64(ptr %t245, i64 %t229)
  %t247 = getelementptr i8, ptr %t245, i64 %t230
  call void @olang_textcopy(ptr %t247, ptr %t232, i64 %t233)
  %t248 = getelementptr i8, ptr %t247, i64 %t233
  call void @olang_textcopy(ptr %t248, ptr %t236, i64 %t237)
  %t249 = getelementptr i8, ptr %t248, i64 %t237
  call void @olang_textcopy(ptr %t249, ptr %t239, i64 %t240)
  %t250 = insertvalue { i64, ptr } undef, i64 %t241, 0
  %t251 = insertvalue { i64, ptr } %t250, ptr %t242, 1
  %t253 = extractvalue { i64, ptr } %t251, 0
  %t254 = extractvalue { i64, ptr } %t251, 1
  %t255 = mul i64 %t253, 1
  %t256 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t255)
  call void @llvm.memcpy.p0.p0.i64(ptr %t256, ptr %t254, i64 %t255, i1 false)
  %t257 = insertvalue { i64, ptr } undef, i64 %t253, 0
  %t258 = insertvalue { i64, ptr } %t257, ptr %t256, 1
  %t259 = load ptr, ptr %l88, !tbaa !29
  %t260 = load { i64, ptr }, ptr %l89, !tbaa !27
  %t261 = load i64, ptr %l90, !tbaa !24
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eitem(ptr %v0, ptr %v1, ptr %s0, ptr %s0, ptr %t259, { i64, ptr } %t260, i64 %t261, { i64, ptr } %t258, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d8, i32 0, i32 1) })
  br label %bb33
bb33:
  %t263 = load ptr, ptr %lp2
  %t264 = load { i64, ptr }, ptr %t263, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t264, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecHeader(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/cabi:Way"
  %l4 = alloca i32
  %l8 = alloca i32
  %l12 = alloca i1
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca { i64, ptr }
  %l23 = alloca i1
  %l29 = alloca %"compiler/cabi:Way"
  %l31 = alloca { i64, ptr }
  %l35 = alloca i1
  %l37 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l49 = alloca { i64, ptr }
  %l51 = alloca i64
  %l52 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t8 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t4, i32 %a1)
  store i32 %t8, ptr %l8
  br label %bb1
bb1:
  %t9 = load i32, ptr %l8, !tbaa !23
  store i32 %t9, ptr %l2, !tbaa !23
  %t10 = load i32, ptr %l2, !tbaa !23
  %t11 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t14 = icmp eq i32 %t10, %t11
  br i1 %t14, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb4
bb3:
  %t16 = load i32, ptr %l2, !tbaa !23
  %t17 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t20 = icmp eq i32 %t16, %t17
  store i1 %t20, ptr %l12, !tbaa !21
  br label %bb4
bb4:
  %t22 = load i1, ptr %l12, !tbaa !21
  br i1 %t22, label %bb5, label %bb6
bb5:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d9, i32 0, i32 1) }, ptr %l16, !tbaa !27
  %t23 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t23, ptr %l17, !tbaa !27
  %t24 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t24, 0
  store i64 %t25, ptr %l18, !tbaa !24
  %t26 = load i64, ptr %l18, !tbaa !24
  %t27 = mul i64 %t26, 1
  %t28 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t27)
  %t29 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t30 = insertvalue { i64, ptr } %t29, ptr %t28, 1
  store { i64, ptr } %t30, ptr %l19, !tbaa !27
  %t31 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = load i64, ptr %l18, !tbaa !24
  %t36 = mul i64 %t35, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t32, ptr %t34, i64 %t36, i1 false)
  %t37 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t37, ptr %l17, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t38 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t38, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/emit:Emitter", ptr %t39, i32 0, i32 0
  %t42 = load ptr, ptr %t41, !tbaa !29
  %t43 = load i32, ptr %l2, !tbaa !23
  %t46 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLayout(ptr %v0, ptr %t42, i32 %t43)
  store i1 %t46, ptr %l23
  br label %bb8
bb8:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/emit:Emitter", ptr %t47, i32 0, i32 3
  %t50 = load ptr, ptr %t49, !tbaa !29
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/emit:Emitter", ptr %t51, i32 0, i32 45
  %t54 = load { i64, ptr }, ptr %t53, !tbaa !27
  %t55 = load i32, ptr %l2, !tbaa !23
  %t59 = call %"compiler/cabi:Way" @compiler_2fcabi_2eResult(ptr %v0, ptr %v0, ptr %s0, ptr %t50, { i64, ptr } %t54, i32 %t55)
  store %"compiler/cabi:Way" %t59, ptr %l29
  br label %bb9
bb9:
  %t60 = load %"compiler/cabi:Way", ptr %l29
  store %"compiler/cabi:Way" %t60, ptr %l3
  %t61 = getelementptr %"compiler/cabi:Way", ptr %l3, i32 0, i32 0
  %t62 = load i32, ptr %t61
  store i32 %t62, ptr %l4
  %t64 = load i32, ptr %l4
  %t66 = trunc i64 0 to i32
  %t67 = icmp eq i32 %t64, %t66
  br i1 %t67, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb18
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t69 = getelementptr %"compiler/cabi:Way", ptr %l3, i32 0, i32 4
  %t70 = load { i64, ptr }, ptr %t69, !tbaa !27
  %t72 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s2, { i64, ptr } %t70, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d10, i32 0, i32 1) })
  store i1 %t72, ptr %l35
  br label %bb13
bb13:
  %t73 = load i1, ptr %l35, !tbaa !21
  %t74 = xor i1 %t73, true
  br i1 %t74, label %bb14, label %bb15
bb14:
  %t76 = getelementptr %"compiler/cabi:Way", ptr %l3, i32 0, i32 4
  %t77 = load { i64, ptr }, ptr %t76, !tbaa !27
  %t79 = extractvalue { i64, ptr } %t77, 1
  %t80 = extractvalue { i64, ptr } %t77, 0
  %t81 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d11, i32 0, i32 1) }, 1
  %t82 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d11, i32 0, i32 1) }, 0
  %t83 = add i64 %t80, %t82
  %t84 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t83)
  call void @olang_textcopy(ptr %t84, ptr %t79, i64 %t80)
  %t85 = getelementptr i8, ptr %t84, i64 %t80
  call void @olang_textcopy(ptr %t85, ptr %t81, i64 %t82)
  %t86 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t87 = insertvalue { i64, ptr } %t86, ptr %t84, 1
  %t89 = extractvalue { i64, ptr } %t87, 0
  %t90 = extractvalue { i64, ptr } %t87, 1
  %t91 = mul i64 %t89, 1
  %t92 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t91)
  call void @llvm.memcpy.p0.p0.i64(ptr %t92, ptr %t90, i64 %t91, i1 false)
  %t93 = insertvalue { i64, ptr } undef, i64 %t89, 0
  %t94 = insertvalue { i64, ptr } %t93, ptr %t92, 1
  store { i64, ptr } %t94, ptr %l37, !tbaa !27
  br label %bb16
bb15:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d12, i32 0, i32 1) }, ptr %l37, !tbaa !27
  br label %bb16
bb16:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t97 = load i32, ptr %l2, !tbaa !23
  %t100 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %s2, ptr %t96, i32 %t97)
  store { i64, ptr } %t100, ptr %l43
  br label %bb17
bb17:
  %t101 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t102 = extractvalue { i64, ptr } %t101, 1
  %t103 = extractvalue { i64, ptr } %t101, 0
  %t104 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t105 = extractvalue { i64, ptr } %t104, 1
  %t106 = extractvalue { i64, ptr } %t104, 0
  %t107 = add i64 %t103, %t106
  %t108 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t107)
  call void @olang_textcopy(ptr %t108, ptr %t102, i64 %t103)
  %t109 = getelementptr i8, ptr %t108, i64 %t103
  call void @olang_textcopy(ptr %t109, ptr %t105, i64 %t106)
  %t110 = insertvalue { i64, ptr } undef, i64 %t107, 0
  %t111 = insertvalue { i64, ptr } %t110, ptr %t108, 1
  store { i64, ptr } %t111, ptr %l31, !tbaa !27
  call void @__olang_scope_close(ptr %s2)
  br label %bb28
bb18:
  %t113 = load i32, ptr %l4
  %t115 = trunc i64 1 to i32
  %t116 = icmp eq i32 %t113, %t115
  br i1 %t116, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb23
bb21:
  %t119 = call { i64, ptr } @compiler_2fcabi_2ePartsType(ptr %s0, ptr %v1, ptr %l3)
  store { i64, ptr } %t119, ptr %l48
  br label %bb22
bb22:
  %t120 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t120, ptr %l31, !tbaa !27
  br label %bb28
bb23:
  br i1 true, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb27
bb26:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d13, i32 0, i32 1) }, ptr %l49, !tbaa !27
  %t121 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t121, ptr %l31, !tbaa !27
  br label %bb28
bb27:
  call void @__olang_check_failed(ptr @olang_loc_6aada305a3873fb6_c16c54d6f05c33ea)
  unreachable
bb28:
  %t123 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t124 = extractvalue { i64, ptr } %t123, 0
  store i64 %t124, ptr %l51, !tbaa !24
  %t125 = load i64, ptr %l51, !tbaa !24
  %t126 = mul i64 %t125, 1
  %t127 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t126)
  %t128 = insertvalue { i64, ptr } undef, i64 %t125, 0
  %t129 = insertvalue { i64, ptr } %t128, ptr %t127, 1
  store { i64, ptr } %t129, ptr %l52, !tbaa !27
  %t130 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !27
  %t132 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !27
  %t134 = load i64, ptr %l51, !tbaa !24
  %t135 = mul i64 %t134, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t131, ptr %t133, i64 %t135, i1 false)
  %t136 = load { i64, ptr }, ptr %l52, !tbaa !27
  store { i64, ptr } %t136, ptr %l31, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t137 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t137, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecstr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %lp3 = alloca ptr
  %l9 = alloca i1
  %l10 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca i32
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca { i64, ptr }
  %l22 = alloca ptr
  %l25 = alloca ptr
  %l27 = alloca i64
  %l28 = alloca i64
  %l32 = alloca { i64, ptr }
  %l33 = alloca i64
  %l34 = alloca { i64, ptr }
  %l37 = alloca i64
  %l39 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t2 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d14, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d14, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %t1, 1
  %t6 = extractvalue { i64, ptr } %t1, 0
  %t7 = add i64 %t3, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t2, i64 %t3)
  %t9 = getelementptr i8, ptr %t8, i64 %t3
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  store { i64, ptr } %t11, ptr %l2, !tbaa !27
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/emit:Emitter", ptr %t13, i32 0, i32 25
  %t16 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t19 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_He27db0a1785588531472bfd2db42574f(ptr %v0, ptr %s0, ptr %t15, { i64, ptr } %t16)
  store i1 %t19, ptr %l9
  br label %bb1
bb1:
  %t20 = load i1, ptr %l9, !tbaa !21
  br i1 %t20, label %bb2, label %bb3
bb2:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/emit:Emitter", ptr %t21, i32 0, i32 25
  %t24 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t27 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha4444909f5ef14f7626d25b8f59e6ba2(ptr %v0, ptr %s0, ptr %v2, ptr %t23, { i64, ptr } %t24)
  %t28 = extractvalue { i32, { i64, ptr } } %t27, 1
  %t29 = extractvalue { i32, { i64, ptr } } %t27, 0
  store i32 %t29, ptr %l15
  %t30 = icmp ne i32 %t29, 0
  br i1 %t30, label %bb5, label %ok.31
ok.31:
  store { i64, ptr } %t28, ptr %l14
  br label %bb4
bb3:
  br label %bb8
bb4:
  %t32 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t32, ptr %l10, !tbaa !27
  br label %bb7
bb5:
  br label %bb6
bb6:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d15, i32 0, i32 1) }, ptr %l10, !tbaa !27
  br label %bb7
bb7:
  %t33 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t33, ptr %l16, !tbaa !27
  %t34 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t34, 0
  store i64 %t35, ptr %l17, !tbaa !24
  %t36 = load i64, ptr %l17, !tbaa !24
  %t37 = mul i64 %t36, 1
  %t38 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t37)
  %t39 = insertvalue { i64, ptr } undef, i64 %t36, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %t38, 1
  store { i64, ptr } %t40, ptr %l18, !tbaa !27
  %t41 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !27
  %t43 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !27
  %t45 = load i64, ptr %l17, !tbaa !24
  %t46 = mul i64 %t45, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t42, ptr %t44, i64 %t46, i1 false)
  %t47 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t47, ptr %l16, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t48 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t48, ptr %rv
  br label %ret
bb8:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/emit:Emitter", ptr %t49, i32 0, i32 22
  %t52 = load i64, ptr %t51, !tbaa !24
  %t53 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d16, i32 0, i32 1) }, 1
  %t54 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d16, i32 0, i32 1) }, 0
  %t56 = call i64 @__olang_fmt_i64(ptr null, i64 %t52)
  %t57 = add i64 %t54, %t56
  %t58 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t57)
  call void @olang_textcopy(ptr %t58, ptr %t53, i64 %t54)
  %t59 = getelementptr i8, ptr %t58, i64 %t54
  %t60 = call i64 @__olang_fmt_i64(ptr %t59, i64 %t52)
  %t61 = insertvalue { i64, ptr } undef, i64 %t57, 0
  %t62 = insertvalue { i64, ptr } %t61, ptr %t58, 1
  %t63 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t63, ptr %lp3
  %t65 = load ptr, ptr %lp3
  store { i64, ptr } %t62, ptr %t65, !tbaa !27
  %t66 = load ptr, ptr %l0, !tbaa !29
  store ptr %t66, ptr %l22, !tbaa !29
  %t67 = load ptr, ptr %l22, !tbaa !29
  %t68 = getelementptr %"compiler/emit:Emitter", ptr %t67, i32 0, i32 22
  %t69 = load i64, ptr %t68, !tbaa !24
  %t71 = add i64 %t69, 1
  %t73 = load ptr, ptr %l22, !tbaa !29
  %t74 = getelementptr %"compiler/emit:Emitter", ptr %t73, i32 0, i32 22
  store i64 %t71, ptr %t74, !tbaa !24
  %t75 = load ptr, ptr %l0, !tbaa !29
  store ptr %t75, ptr %l25, !tbaa !29
  %t76 = load ptr, ptr %lp3
  %t77 = load { i64, ptr }, ptr %t76, !tbaa !27
  %t79 = extractvalue { i64, ptr } %t77, 0
  store i64 %t79, ptr %l27, !tbaa !24
  %t80 = load ptr, ptr %lp3
  %t81 = load { i64, ptr }, ptr %t80, !tbaa !27
  %t82 = extractvalue { i64, ptr } %t81, 0
  store i64 %t82, ptr %l28, !tbaa !24
  %t83 = icmp sge i64 1, 0
  br i1 %t83, label %bb9, label %bb10
bb9:
  %t85 = load i64, ptr %l27, !tbaa !24
  %t86 = icmp sle i64 1, %t85
  br i1 %t86, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_5836d127b451ff05_764b57a187e296f1)
  unreachable
bb11:
  %t88 = load i64, ptr %l27, !tbaa !24
  %t89 = load i64, ptr %l28, !tbaa !24
  %t90 = icmp sle i64 %t88, %t89
  br i1 %t90, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @olang_loc_5836d127b451ff05_764b57a187e296f1)
  unreachable
bb13:
  %t92 = load ptr, ptr %lp3
  %t93 = getelementptr { i64, ptr }, ptr %t92, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !27
  %t95 = load i64, ptr %l27, !tbaa !24
  %t96 = getelementptr i8, ptr %t94, i64 1
  %t97 = sub i64 %t95, 1
  %t98 = insertvalue { i64, ptr } undef, i64 %t97, 0
  %t99 = insertvalue { i64, ptr } %t98, ptr %t96, 1
  store { i64, ptr } %t99, ptr %l32, !tbaa !27
  %t100 = load i64, ptr @G_2ecompiler_2femit_2eHomeLocal, !tbaa !24
  store i64 %t100, ptr %l33, !tbaa !24
  %t101 = load ptr, ptr %lp3
  %t102 = load { i64, ptr }, ptr %t101, !tbaa !27
  store { i64, ptr } %t102, ptr %l34, !tbaa !27
  %t103 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t105 = extractvalue { i64, ptr } %t103, 0
  %t107 = add i64 %t105, 1
  store i64 %t107, ptr %l37, !tbaa !24
  %t108 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t110 = call { i64, ptr } @compiler_2femit_2eescape(ptr %v1, ptr %s0, { i64, ptr } %t108)
  store { i64, ptr } %t110, ptr %l39
  br label %bb15
bb14:
  call void @__olang_check_failed(ptr @olang_loc_5836d127b451ff05_764b57a187e296f1)
  unreachable
bb15:
  %t111 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t112 = extractvalue { i64, ptr } %t111, 1
  %t113 = extractvalue { i64, ptr } %t111, 0
  %t114 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d17, i32 0, i32 1) }, 1
  %t115 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d17, i32 0, i32 1) }, 0
  %t116 = add i64 %t113, %t115
  %t117 = load i64, ptr %l37, !tbaa !24
  %t118 = call i64 @__olang_fmt_i64(ptr null, i64 %t117)
  %t119 = add i64 %t116, %t118
  %t120 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d18, i32 0, i32 1) }, 1
  %t121 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d18, i32 0, i32 1) }, 0
  %t122 = add i64 %t119, %t121
  %t123 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t124 = extractvalue { i64, ptr } %t123, 1
  %t125 = extractvalue { i64, ptr } %t123, 0
  %t126 = add i64 %t122, %t125
  %t127 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d19, i32 0, i32 1) }, 1
  %t128 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d19, i32 0, i32 1) }, 0
  %t129 = add i64 %t126, %t128
  %t130 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t129)
  call void @olang_textcopy(ptr %t130, ptr %t112, i64 %t113)
  %t131 = getelementptr i8, ptr %t130, i64 %t113
  call void @olang_textcopy(ptr %t131, ptr %t114, i64 %t115)
  %t132 = getelementptr i8, ptr %t131, i64 %t115
  %t133 = call i64 @__olang_fmt_i64(ptr %t132, i64 %t117)
  %t134 = getelementptr i8, ptr %t132, i64 %t118
  call void @olang_textcopy(ptr %t134, ptr %t120, i64 %t121)
  %t135 = getelementptr i8, ptr %t134, i64 %t121
  call void @olang_textcopy(ptr %t135, ptr %t124, i64 %t125)
  %t136 = getelementptr i8, ptr %t135, i64 %t125
  call void @olang_textcopy(ptr %t136, ptr %t127, i64 %t128)
  %t137 = insertvalue { i64, ptr } undef, i64 %t129, 0
  %t138 = insertvalue { i64, ptr } %t137, ptr %t130, 1
  %t140 = extractvalue { i64, ptr } %t138, 0
  %t141 = extractvalue { i64, ptr } %t138, 1
  %t142 = mul i64 %t140, 1
  %t143 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t142)
  call void @llvm.memcpy.p0.p0.i64(ptr %t143, ptr %t141, i64 %t142, i1 false)
  %t144 = insertvalue { i64, ptr } undef, i64 %t140, 0
  %t145 = insertvalue { i64, ptr } %t144, ptr %t143, 1
  %t146 = load ptr, ptr %l25, !tbaa !29
  %t147 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t148 = load i64, ptr %l33, !tbaa !24
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eitem(ptr %v0, ptr %v2, ptr %s0, ptr %s0, ptr %t146, { i64, ptr } %t147, i64 %t148, { i64, ptr } %t145, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d8, i32 0, i32 1) })
  br label %bb16
bb16:
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t152 = getelementptr %"compiler/emit:Emitter", ptr %t150, i32 0, i32 25
  %t153 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t155 = extractvalue { i64, ptr } %t153, 1
  %t156 = extractvalue { i64, ptr } %t153, 0
  %t157 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t156)
  call void @olang_textcopy(ptr %t157, ptr %t155, i64 %t156)
  %t158 = insertvalue { i64, ptr } undef, i64 %t156, 0
  %t159 = insertvalue { i64, ptr } %t158, ptr %t157, 1
  %t161 = extractvalue { i64, ptr } %t159, 0
  %t162 = extractvalue { i64, ptr } %t159, 1
  %t163 = mul i64 %t161, 1
  %t164 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t163)
  call void @llvm.memcpy.p0.p0.i64(ptr %t164, ptr %t162, i64 %t163, i1 false)
  %t165 = insertvalue { i64, ptr } undef, i64 %t161, 0
  %t166 = insertvalue { i64, ptr } %t165, ptr %t164, 1
  %t167 = load ptr, ptr %lp3
  %t168 = load { i64, ptr }, ptr %t167, !tbaa !27
  %t170 = extractvalue { i64, ptr } %t168, 1
  %t171 = extractvalue { i64, ptr } %t168, 0
  %t172 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t171)
  call void @olang_textcopy(ptr %t172, ptr %t170, i64 %t171)
  %t173 = insertvalue { i64, ptr } undef, i64 %t171, 0
  %t174 = insertvalue { i64, ptr } %t173, ptr %t172, 1
  %t176 = extractvalue { i64, ptr } %t174, 0
  %t177 = extractvalue { i64, ptr } %t174, 1
  %t178 = mul i64 %t176, 1
  %t179 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t178)
  call void @llvm.memcpy.p0.p0.i64(ptr %t179, ptr %t177, i64 %t178, i1 false)
  %t180 = insertvalue { i64, ptr } undef, i64 %t176, 0
  %t181 = insertvalue { i64, ptr } %t180, ptr %t179, 1
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6f7a2f8d839c49b6e7a19c287d4b190c(ptr %v0, ptr %v0, ptr %v0, ptr %t152, { i64, ptr } %t166, { i64, ptr } %t181)
  br label %bb17
bb17:
  %t185 = load ptr, ptr %lp3
  %t186 = load { i64, ptr }, ptr %t185, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t186, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgFile(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l8 = alloca i1
  %l9 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i32
  %l16 = alloca i64
  %l24 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l27 = alloca i32
  %l29 = alloca i1
  %l30 = alloca { i64, ptr }
  %l33 = alloca ptr
  %l34 = alloca i64
  %l36 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 60
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %t3, i64 %t4)
  store i1 %t7, ptr %l8
  br label %bb1
bb1:
  %t8 = load i1, ptr %l8, !tbaa !21
  br i1 %t8, label %bb2, label %bb3
bb2:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/emit:Emitter", ptr %t9, i32 0, i32 60
  %t12 = load i64, ptr %l1, !tbaa !24
  %t15 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t11, i64 %t12)
  %t16 = extractvalue { i32, i64 } %t15, 1
  %t17 = extractvalue { i32, i64 } %t15, 0
  store i32 %t17, ptr %l14
  %t18 = icmp ne i32 %t17, 0
  br i1 %t18, label %bb5, label %ok.19
ok.19:
  store i64 %t16, ptr %l13
  br label %bb4
bb3:
  br label %bb8
bb4:
  %t20 = load i64, ptr %l13, !tbaa !24
  store i64 %t20, ptr %l9, !tbaa !24
  br label %bb7
bb5:
  br label %bb6
bb6:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l9, !tbaa !24
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s0)
  %t21 = load i64, ptr %l9, !tbaa !24
  store i64 %t21, ptr %rv
  br label %ret
bb8:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgNew(ptr %v0, ptr %t22)
  store i64 %t24, ptr %l16
  br label %bb9
bb9:
  %t25 = load i64, ptr %l16, !tbaa !24
  store i64 %t25, ptr %l2, !tbaa !24
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/emit:Emitter", ptr %t26, i32 0, i32 60
  %t29 = load i64, ptr %l1, !tbaa !24
  %t30 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t28, i64 %t29, i64 %t30)
  br label %bb10
bb10:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/emit:Emitter", ptr %t34, i32 0, i32 2
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t38 = load i64, ptr %l1, !tbaa !24
  %t41 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2ePathOf(ptr %v0, ptr %s0, ptr %t37, i64 %t38)
  store { i64, ptr } %t41, ptr %l24
  br label %bb11
bb11:
  %t42 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t42, ptr %l3, !tbaa !27
  %t43 = call { i32, { i64, ptr } } @std_2fos_2eCwd(ptr %s0)
  %t44 = extractvalue { i32, { i64, ptr } } %t43, 1
  %t45 = extractvalue { i32, { i64, ptr } } %t43, 0
  store i32 %t45, ptr %l27
  %t46 = icmp ne i32 %t45, 0
  br i1 %t46, label %bb13, label %ok.47
ok.47:
  store { i64, ptr } %t44, ptr %l26
  br label %bb12
bb12:
  %t48 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t48, ptr %l25, !tbaa !27
  br label %bb15
bb13:
  %t49 = load i32, ptr %l27, !tbaa !23
  %t50 = ashr i32 %t49, 16
  %t52 = icmp eq i32 %t50, 1
  store i1 %t52, ptr %l29, !tbaa !21
  br label %bb14
bb14:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d20, i32 0, i32 1) }, ptr %l30, !tbaa !27
  %t53 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t55 = extractvalue { i64, ptr } %t53, 0
  %t56 = extractvalue { i64, ptr } %t53, 1
  %t57 = mul i64 %t55, 1
  %t58 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t57)
  call void @llvm.memcpy.p0.p0.i64(ptr %t58, ptr %t56, i64 %t57, i1 false)
  %t59 = insertvalue { i64, ptr } undef, i64 %t55, 0
  %t60 = insertvalue { i64, ptr } %t59, ptr %t58, 1
  store { i64, ptr } %t60, ptr %l25, !tbaa !27
  br label %bb15
bb15:
  %t62 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t62, ptr %l4, !tbaa !27
  %t63 = load ptr, ptr %l0, !tbaa !29
  store ptr %t63, ptr %l33, !tbaa !29
  %t64 = load i64, ptr %l2, !tbaa !24
  store i64 %t64, ptr %l34, !tbaa !24
  %t65 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t67 = call { i64, ptr } @compiler_2femit_2eescape(ptr %s0, ptr %s0, { i64, ptr } %t65)
  store { i64, ptr } %t67, ptr %l36
  br label %bb16
bb16:
  %t68 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t70 = call { i64, ptr } @compiler_2femit_2eescape(ptr %s0, ptr %s0, { i64, ptr } %t68)
  store { i64, ptr } %t70, ptr %l38
  br label %bb17
bb17:
  %t71 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d21, i32 0, i32 1) }, 1
  %t72 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d21, i32 0, i32 1) }, 0
  %t73 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t74 = extractvalue { i64, ptr } %t73, 1
  %t75 = extractvalue { i64, ptr } %t73, 0
  %t76 = add i64 %t72, %t75
  %t77 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d22, i32 0, i32 1) }, 1
  %t78 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d22, i32 0, i32 1) }, 0
  %t79 = add i64 %t76, %t78
  %t80 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t81 = extractvalue { i64, ptr } %t80, 1
  %t82 = extractvalue { i64, ptr } %t80, 0
  %t83 = add i64 %t79, %t82
  %t84 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d23, i32 0, i32 1) }, 1
  %t85 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d23, i32 0, i32 1) }, 0
  %t86 = add i64 %t83, %t85
  %t87 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t86)
  call void @olang_textcopy(ptr %t87, ptr %t71, i64 %t72)
  %t88 = getelementptr i8, ptr %t87, i64 %t72
  call void @olang_textcopy(ptr %t88, ptr %t74, i64 %t75)
  %t89 = getelementptr i8, ptr %t88, i64 %t75
  call void @olang_textcopy(ptr %t89, ptr %t77, i64 %t78)
  %t90 = getelementptr i8, ptr %t89, i64 %t78
  call void @olang_textcopy(ptr %t90, ptr %t81, i64 %t82)
  %t91 = getelementptr i8, ptr %t90, i64 %t82
  call void @olang_textcopy(ptr %t91, ptr %t84, i64 %t85)
  %t92 = insertvalue { i64, ptr } undef, i64 %t86, 0
  %t93 = insertvalue { i64, ptr } %t92, ptr %t87, 1
  %t95 = extractvalue { i64, ptr } %t93, 0
  %t96 = extractvalue { i64, ptr } %t93, 1
  %t97 = mul i64 %t95, 1
  %t98 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t97)
  call void @llvm.memcpy.p0.p0.i64(ptr %t98, ptr %t96, i64 %t97, i1 false)
  %t99 = insertvalue { i64, ptr } undef, i64 %t95, 0
  %t100 = insertvalue { i64, ptr } %t99, ptr %t98, 1
  %t101 = load ptr, ptr %l33, !tbaa !29
  %t102 = load i64, ptr %l34, !tbaa !24
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgShared(ptr %v0, ptr %s0, ptr %t101, i64 %t102, { i64, ptr } %t100)
  br label %bb18
bb18:
  %t104 = load i64, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t104, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgType(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca %"std/prelude/text:StringBuilder"
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l31 = alloca i64
  %l32 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l34 = alloca %"std/prelude/text:StringBuilder"
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i1
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i64
  %l51 = alloca i64
  %l52 = alloca i64
  %l57 = alloca i32
  %l61 = alloca i1
  %l64 = alloca i1
  %l67 = alloca i32
  %l74 = alloca i1
  %l75 = alloca i64
  %l80 = alloca i64
  %l81 = alloca i32
  %l83 = alloca i64
  %l92 = alloca { i64, ptr }
  %l95 = alloca i1
  %l96 = alloca { i64, ptr }
  %l99 = alloca i1
  %l100 = alloca { i64, ptr }
  %l103 = alloca i64
  %l105 = alloca i1
  %l108 = alloca i1
  %l112 = alloca i64
  %l115 = alloca i64
  %l119 = alloca ptr
  %l120 = alloca i64
  %l123 = alloca { i64, ptr }
  %l133 = alloca i1
  %l134 = alloca i64
  %l139 = alloca i64
  %l140 = alloca i32
  %l143 = alloca i32
  %l148 = alloca i32
  %l151 = alloca { i64, ptr }
  %l153 = alloca i1
  %l155 = alloca ptr
  %l156 = alloca i32
  %l158 = alloca i32
  %l159 = alloca ptr
  %l162 = alloca i32
  %l163 = alloca i32
  %l164 = alloca i64
  %l166 = alloca i64
  %l174 = alloca i64
  %l175 = alloca ptr
  %l176 = alloca i64
  %l179 = alloca { i64, ptr }
  %l192 = alloca i64
  %l196 = alloca i1
  %l199 = alloca i64
  %l205 = alloca i32
  %l207 = alloca ptr
  %l208 = alloca i32
  %l210 = alloca i32
  %l213 = alloca i32
  %l214 = alloca i64
  %l216 = alloca i64
  %l222 = alloca ptr
  %l225 = alloca i32
  %l226 = alloca i64
  %l230 = alloca i64
  %l232 = alloca i64
  %l233 = alloca ptr
  %l234 = alloca i64
  %l235 = alloca ptr
  %l238 = alloca i32
  %l239 = alloca i64
  %l252 = alloca i1
  %l255 = alloca i1
  %l258 = alloca i1
  %l259 = alloca ptr
  %l262 = alloca i32
  %l263 = alloca i32
  %l268 = alloca i64
  %l274 = alloca ptr
  %l278 = alloca i32
  %l281 = alloca i32
  %l284 = alloca i32
  %l285 = alloca { i64, ptr }
  %l290 = alloca { i64, ptr }
  %l293 = alloca { i64, ptr }
  %l294 = alloca %"std/prelude/text:StringBuilder"
  %l300 = alloca i64
  %l303 = alloca i64
  %l323 = alloca { i64, ptr }
  %l326 = alloca i1
  %l328 = alloca { i64, ptr }
  %l331 = alloca i64
  %l335 = alloca i64
  %l337 = alloca i64
  %l338 = alloca ptr
  %l339 = alloca i64
  %l342 = alloca { i64, ptr }
  %l343 = alloca i64
  %l345 = alloca { i64, ptr }
  %l348 = alloca i64
  %l365 = alloca i64
  %l366 = alloca ptr
  %l367 = alloca i64
  %l369 = alloca { i64, ptr }
  %l372 = alloca ptr
  %l373 = alloca i64
  %l376 = alloca { i64, ptr }
  %l378 = alloca { i64, ptr }
  %l386 = alloca i1
  %l389 = alloca i1
  %l390 = alloca ptr
  %l393 = alloca i32
  %l394 = alloca i32
  %l399 = alloca i64
  %l407 = alloca { i64, ptr }
  %l410 = alloca { i64, ptr }
  %l414 = alloca ptr
  %l417 = alloca i32
  %l420 = alloca i32
  %l423 = alloca i32
  %l424 = alloca { i64, ptr }
  %l425 = alloca %"std/prelude/text:StringBuilder"
  %l431 = alloca i64
  %l434 = alloca i64
  %l453 = alloca i64
  %l457 = alloca i1
  %l462 = alloca { i64, ptr }
  %l464 = alloca { i64, ptr }
  %l467 = alloca { i64, ptr }
  %l471 = alloca ptr
  %l472 = alloca i64
  %l474 = alloca { i64, ptr }
  %l488 = alloca i64
  %l489 = alloca ptr
  %l490 = alloca i64
  %l492 = alloca { i64, ptr }
  %l497 = alloca i1
  %l500 = alloca i64
  %l503 = alloca i64
  %l504 = alloca ptr
  %l506 = alloca i32
  %l508 = alloca i32
  %l510 = alloca i32
  %l511 = alloca i64
  %l512 = alloca ptr
  %l513 = alloca i64
  %l516 = alloca { i64, ptr }
  %l518 = alloca { i64, ptr }
  %l520 = alloca i64
  %l530 = alloca i64
  %l533 = alloca i64
  %l535 = alloca i64
  %l541 = alloca ptr
  %l542 = alloca i64
  %l543 = alloca ptr
  %l545 = alloca i32
  %l546 = alloca i64
  %l553 = alloca i64
  %l555 = alloca i64
  %l557 = alloca i64
  %l576 = alloca ptr
  %l577 = alloca i64
  %l580 = alloca { i64, ptr }
  %l582 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %s31 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t6, i32 %a1)
  store i32 %t10, ptr %l57
  br label %bb1
bb1:
  %t11 = load i32, ptr %l57, !tbaa !23
  store i32 %t11, ptr %l3, !tbaa !23
  %t12 = load i32, ptr %l3, !tbaa !23
  %t13 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t16 = icmp sge i32 %t12, %t13
  br i1 %t16, label %bb2, label %bb3
bb2:
  %t18 = load i32, ptr %l3, !tbaa !23
  %t20 = icmp sle i32 %t18, 14
  store i1 %t20, ptr %l61, !tbaa !21
  br label %bb4
bb3:
  store i1 false, ptr %l61, !tbaa !21
  br label %bb4
bb4:
  %t22 = load i1, ptr %l61, !tbaa !21
  br i1 %t22, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l64, !tbaa !21
  br label %bb8
bb6:
  %t23 = load ptr, ptr %l2, !tbaa !29
  %t24 = load i32, ptr %l3, !tbaa !23
  %t27 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t23, i32 %t24)
  store i32 %t27, ptr %l67
  br label %bb7
bb7:
  %t28 = load i32, ptr %l67
  %t30 = trunc i64 31 to i32
  %t31 = icmp eq i32 %t28, %t30
  store i1 %t31, ptr %l64, !tbaa !21
  br label %bb8
bb8:
  %t33 = load i1, ptr %l64, !tbaa !21
  br i1 %t33, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s1
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/emit:Emitter", ptr %t34, i32 0, i32 61
  %t37 = load i32, ptr %l3, !tbaa !23
  %t39 = sext i32 %t37 to i64
  %t42 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %t36, i64 %t39)
  store i1 %t42, ptr %l74
  br label %bb11
bb10:
  br label %bb46
bb11:
  %t43 = load i1, ptr %l74, !tbaa !21
  br i1 %t43, label %bb12, label %bb13
bb12:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/emit:Emitter", ptr %t44, i32 0, i32 61
  %t47 = load i32, ptr %l3, !tbaa !23
  %t49 = sext i32 %t47 to i64
  %t52 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t46, i64 %t49)
  %t53 = extractvalue { i32, i64 } %t52, 1
  %t54 = extractvalue { i32, i64 } %t52, 0
  store i32 %t54, ptr %l81
  %t55 = icmp ne i32 %t54, 0
  br i1 %t55, label %bb15, label %ok.56
ok.56:
  store i64 %t53, ptr %l80
  br label %bb14
bb13:
  br label %bb18
bb14:
  %t57 = load i64, ptr %l80, !tbaa !24
  store i64 %t57, ptr %l75, !tbaa !24
  br label %bb17
bb15:
  br label %bb16
bb16:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l75, !tbaa !24
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s1)
  %t58 = load i64, ptr %l75, !tbaa !24
  store i64 %t58, ptr %rv
  br label %ret
bb18:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgNew(ptr %v0, ptr %t59)
  store i64 %t61, ptr %l83
  br label %bb19
bb19:
  %t62 = load i64, ptr %l83, !tbaa !24
  store i64 %t62, ptr %l4, !tbaa !24
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/emit:Emitter", ptr %t63, i32 0, i32 61
  %t66 = load i32, ptr %l3, !tbaa !23
  %t68 = sext i32 %t66 to i64
  %t69 = load i64, ptr %l4, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t65, i64 %t68, i64 %t69)
  br label %bb20
bb20:
  %t73 = load i32, ptr %l3, !tbaa !23
  %t74 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t77 = icmp eq i32 %t73, %t74
  br i1 %t77, label %bb21, label %bb22
bb21:
  store { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d24, i32 0, i32 1) }, ptr %l92, !tbaa !27
  br label %bb31
bb22:
  %t79 = load ptr, ptr %l2, !tbaa !29
  %t80 = load i32, ptr %l3, !tbaa !23
  %t83 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t79, i32 %t80)
  store i1 %t83, ptr %l95
  br label %bb23
bb23:
  %t84 = load i1, ptr %l95, !tbaa !21
  br i1 %t84, label %bb24, label %bb25
bb24:
  store { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d25, i32 0, i32 1) }, ptr %l96, !tbaa !27
  br label %bb30
bb25:
  %t85 = load ptr, ptr %l2, !tbaa !29
  %t86 = load i32, ptr %l3, !tbaa !23
  %t89 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %t85, i32 %t86)
  store i1 %t89, ptr %l99
  br label %bb26
bb26:
  %t90 = load i1, ptr %l99, !tbaa !21
  br i1 %t90, label %bb27, label %bb28
bb27:
  store { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d26, i32 0, i32 1) }, ptr %l100, !tbaa !27
  br label %bb29
bb28:
  store { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d27, i32 0, i32 1) }, ptr %l100, !tbaa !27
  br label %bb29
bb29:
  %t91 = load { i64, ptr }, ptr %l100, !tbaa !27
  store { i64, ptr } %t91, ptr %l96, !tbaa !27
  br label %bb30
bb30:
  %t92 = load { i64, ptr }, ptr %l96, !tbaa !27
  store { i64, ptr } %t92, ptr %l92, !tbaa !27
  br label %bb31
bb31:
  %t93 = load { i64, ptr }, ptr %l92, !tbaa !27
  store { i64, ptr } %t93, ptr %l5, !tbaa !27
  %t94 = load ptr, ptr %l2, !tbaa !29
  %t95 = load i32, ptr %l3, !tbaa !23
  %t98 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %t94, i32 %t95)
  store i64 %t98, ptr %l103
  br label %bb32
bb32:
  %t99 = load i64, ptr %l103, !tbaa !24
  %t100 = icmp eq i64 %t99, 8
  br i1 %t100, label %bb33, label %bb34
bb33:
  %t102 = load ptr, ptr %l2, !tbaa !29
  %t103 = load i32, ptr %l3, !tbaa !23
  %t106 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %t102, i32 %t103)
  store i1 %t106, ptr %l108
  br label %bb35
bb34:
  store i1 false, ptr %l105, !tbaa !21
  br label %bb36
bb35:
  %t107 = load i1, ptr %l108, !tbaa !21
  store i1 %t107, ptr %l105, !tbaa !21
  br label %bb36
bb36:
  %t108 = load i1, ptr %l105, !tbaa !21
  br i1 %t108, label %bb37, label %bb38
bb37:
  store { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d28, i32 0, i32 1) }, ptr %l5, !tbaa !27
  br label %bb39
bb38:
  br label %bb39
bb39:
  %t109 = load i32, ptr %l3, !tbaa !23
  %t110 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t113 = icmp eq i32 %t109, %t110
  br i1 %t113, label %bb40, label %bb41
bb40:
  store i64 8, ptr %l112, !tbaa !24
  br label %bb43
bb41:
  %t115 = load ptr, ptr %l2, !tbaa !29
  %t116 = load i32, ptr %l3, !tbaa !23
  %t119 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %t115, i32 %t116)
  store i64 %t119, ptr %l115
  br label %bb42
bb42:
  %t120 = load i64, ptr %l115, !tbaa !24
  %t121 = add i64 %t120, 7
  %t123 = sdiv i64 %t121, 8
  %t125 = mul i64 %t123, 8
  store i64 %t125, ptr %l112, !tbaa !24
  br label %bb43
bb43:
  %t127 = load i64, ptr %l112, !tbaa !24
  store i64 %t127, ptr %l6, !tbaa !24
  %t128 = load ptr, ptr %l0, !tbaa !29
  store ptr %t128, ptr %l119, !tbaa !29
  %t129 = load i64, ptr %l4, !tbaa !24
  store i64 %t129, ptr %l120, !tbaa !24
  %t130 = load ptr, ptr %l2, !tbaa !29
  %t131 = load i32, ptr %l3, !tbaa !23
  %t134 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s1, ptr %t130, i32 %t131)
  store { i64, ptr } %t134, ptr %l123
  br label %bb44
bb44:
  %t135 = load i64, ptr %l6, !tbaa !24
  %t136 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t137 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d29, i32 0, i32 1) }, 1
  %t138 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d29, i32 0, i32 1) }, 0
  %t139 = load { i64, ptr }, ptr %l123, !tbaa !27
  %t140 = extractvalue { i64, ptr } %t139, 1
  %t141 = extractvalue { i64, ptr } %t139, 0
  %t142 = add i64 %t138, %t141
  %t143 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d30, i32 0, i32 1) }, 1
  %t144 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d30, i32 0, i32 1) }, 0
  %t145 = add i64 %t142, %t144
  %t147 = call i64 @__olang_fmt_i64(ptr null, i64 %t135)
  %t148 = add i64 %t145, %t147
  %t149 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d31, i32 0, i32 1) }, 1
  %t150 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d31, i32 0, i32 1) }, 0
  %t151 = add i64 %t148, %t150
  %t153 = extractvalue { i64, ptr } %t136, 1
  %t154 = extractvalue { i64, ptr } %t136, 0
  %t155 = add i64 %t151, %t154
  %t156 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d32, i32 0, i32 1) }, 1
  %t157 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d32, i32 0, i32 1) }, 0
  %t158 = add i64 %t155, %t157
  %t159 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t158)
  call void @olang_textcopy(ptr %t159, ptr %t137, i64 %t138)
  %t160 = getelementptr i8, ptr %t159, i64 %t138
  call void @olang_textcopy(ptr %t160, ptr %t140, i64 %t141)
  %t161 = getelementptr i8, ptr %t160, i64 %t141
  call void @olang_textcopy(ptr %t161, ptr %t143, i64 %t144)
  %t162 = getelementptr i8, ptr %t161, i64 %t144
  %t163 = call i64 @__olang_fmt_i64(ptr %t162, i64 %t135)
  %t164 = getelementptr i8, ptr %t162, i64 %t147
  call void @olang_textcopy(ptr %t164, ptr %t149, i64 %t150)
  %t165 = getelementptr i8, ptr %t164, i64 %t150
  call void @olang_textcopy(ptr %t165, ptr %t153, i64 %t154)
  %t166 = getelementptr i8, ptr %t165, i64 %t154
  call void @olang_textcopy(ptr %t166, ptr %t156, i64 %t157)
  %t167 = insertvalue { i64, ptr } undef, i64 %t158, 0
  %t168 = insertvalue { i64, ptr } %t167, ptr %t159, 1
  %t170 = extractvalue { i64, ptr } %t168, 0
  %t171 = extractvalue { i64, ptr } %t168, 1
  %t172 = mul i64 %t170, 1
  %t173 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t172)
  call void @llvm.memcpy.p0.p0.i64(ptr %t173, ptr %t171, i64 %t172, i1 false)
  %t174 = insertvalue { i64, ptr } undef, i64 %t170, 0
  %t175 = insertvalue { i64, ptr } %t174, ptr %t173, 1
  %t176 = load ptr, ptr %l119, !tbaa !29
  %t177 = load i64, ptr %l120, !tbaa !24
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgShared(ptr %v0, ptr %s1, ptr %t176, i64 %t177, { i64, ptr } %t175)
  br label %bb45
bb45:
  %t179 = load i64, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  store i64 %t179, ptr %rv
  br label %ret
bb46:
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t183 = getelementptr %"compiler/emit:Emitter", ptr %t181, i32 0, i32 62
  %t184 = load i32, ptr %l3, !tbaa !23
  %t186 = sext i32 %t184 to i64
  %t189 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %t183, i64 %t186)
  store i1 %t189, ptr %l133
  br label %bb47
bb47:
  %t190 = load i1, ptr %l133, !tbaa !21
  br i1 %t190, label %bb48, label %bb49
bb48:
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t193 = getelementptr %"compiler/emit:Emitter", ptr %t191, i32 0, i32 62
  %t194 = load i32, ptr %l3, !tbaa !23
  %t196 = sext i32 %t194 to i64
  %t199 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t193, i64 %t196)
  %t200 = extractvalue { i32, i64 } %t199, 1
  %t201 = extractvalue { i32, i64 } %t199, 0
  store i32 %t201, ptr %l140
  %t202 = icmp ne i32 %t201, 0
  br i1 %t202, label %bb51, label %ok.203
ok.203:
  store i64 %t200, ptr %l139
  br label %bb50
bb49:
  br label %bb54
bb50:
  %t204 = load i64, ptr %l139, !tbaa !24
  store i64 %t204, ptr %l134, !tbaa !24
  br label %bb53
bb51:
  br label %bb52
bb52:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l134, !tbaa !24
  br label %bb53
bb53:
  %t205 = load i64, ptr %l134, !tbaa !24
  store i64 %t205, ptr %rv
  br label %ret
bb54:
  %t206 = load ptr, ptr %l2, !tbaa !29
  %t207 = load i32, ptr %l3, !tbaa !23
  %t210 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t206, i32 %t207)
  store i32 %t210, ptr %l143
  br label %bb55
bb55:
  %t211 = load i32, ptr %l143
  store i32 %t211, ptr %l7
  %t212 = load i32, ptr %l7
  %t214 = trunc i64 20 to i32
  %t215 = icmp eq i32 %t212, %t214
  br i1 %t215, label %bb56, label %bb57
bb56:
  store %olang.scope zeroinitializer, ptr %s6
  %t217 = load ptr, ptr %l2, !tbaa !29
  %t218 = load i32, ptr %l3, !tbaa !23
  %t221 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t217, i32 %t218)
  store i32 %t221, ptr %l148
  br label %bb58
bb57:
  br label %bb75
bb58:
  %t222 = load i32, ptr %l148, !tbaa !23
  store i32 %t222, ptr %l8, !tbaa !23
  %t223 = load ptr, ptr %l0, !tbaa !29
  %t224 = load i32, ptr %l3, !tbaa !23
  %t227 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %s6, ptr %t223, i32 %t224)
  store { i64, ptr } %t227, ptr %l151
  br label %bb59
bb59:
  %t228 = load { i64, ptr }, ptr %l151, !tbaa !27
  %t229 = extractvalue { i64, ptr } %t228, 0
  %t230 = extractvalue { i64, ptr } %t228, 1
  %t231 = mul i64 %t229, 1
  %t232 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t231)
  call void @llvm.memcpy.p0.p0.i64(ptr %t232, ptr %t230, i64 %t231, i1 false)
  %t233 = insertvalue { i64, ptr } undef, i64 %t229, 0
  %t234 = insertvalue { i64, ptr } %t233, ptr %t232, 1
  %t236 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s6, ptr %s6, { i64, ptr } %t234, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d33, i32 0, i32 1) })
  store i1 %t236, ptr %l153
  br label %bb60
bb60:
  %t237 = load i1, ptr %l153, !tbaa !21
  %t238 = xor i1 %t237, true
  br i1 %t238, label %bb61, label %bb62
bb61:
  store %olang.scope zeroinitializer, ptr %s7
  %t240 = load ptr, ptr %l0, !tbaa !29
  store ptr %t240, ptr %l155, !tbaa !29
  %t241 = load i32, ptr %l3, !tbaa !23
  store i32 %t241, ptr %l156, !tbaa !23
  %t242 = load ptr, ptr %l2, !tbaa !29
  %t244 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s7, ptr %t242, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d34, i32 0, i32 1) })
  store i32 %t244, ptr %l158
  br label %bb63
bb62:
  br label %bb67
bb63:
  %t245 = load ptr, ptr %l2, !tbaa !29
  store ptr %t245, ptr %l159, !tbaa !29
  %t246 = load ptr, ptr %l2, !tbaa !29
  %t247 = load i32, ptr %l8, !tbaa !23
  %t250 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t246, i32 %t247)
  store i32 %t250, ptr %l162
  br label %bb64
bb64:
  %t251 = load ptr, ptr %l159, !tbaa !29
  %t252 = load i32, ptr %l162, !tbaa !23
  %t253 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t251, i32 %t252)
  store i32 %t253, ptr %l163
  br label %bb65
bb65:
  %t254 = load ptr, ptr %l155, !tbaa !29
  %t255 = load i32, ptr %l156, !tbaa !23
  %t256 = load i32, ptr %l158, !tbaa !23
  %t257 = load i32, ptr %l163, !tbaa !23
  %t258 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgPair(ptr %v0, ptr %s7, ptr %s7, ptr %t254, i32 %t255, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d35, i32 0, i32 1) }, i32 %t256, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d36, i32 0, i32 1) }, i32 %t257)
  store i64 %t258, ptr %l164
  br label %bb66
bb66:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s6)
  %t259 = load i64, ptr %l164, !tbaa !24
  store i64 %t259, ptr %rv
  br label %ret
bb67:
  %t260 = load ptr, ptr %l0, !tbaa !29
  %t262 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgNew(ptr %v0, ptr %t260)
  store i64 %t262, ptr %l166
  br label %bb68
bb68:
  %t263 = load i64, ptr %l166, !tbaa !24
  store i64 %t263, ptr %l9, !tbaa !24
  %t264 = load ptr, ptr %l0, !tbaa !29
  %t266 = getelementptr %"compiler/emit:Emitter", ptr %t264, i32 0, i32 62
  %t267 = load i32, ptr %l3, !tbaa !23
  %t269 = sext i32 %t267 to i64
  %t270 = load i64, ptr %l9, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t266, i64 %t269, i64 %t270)
  br label %bb69
bb69:
  %t274 = load ptr, ptr %l0, !tbaa !29
  %t275 = load i32, ptr %l8, !tbaa !23
  %t278 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgType(ptr %v0, ptr %t274, i32 %t275)
  store i64 %t278, ptr %l174
  br label %bb70
bb70:
  %t279 = load i64, ptr %l174, !tbaa !24
  store i64 %t279, ptr %l10, !tbaa !24
  %t280 = load ptr, ptr %l0, !tbaa !29
  store ptr %t280, ptr %l175, !tbaa !29
  %t281 = load i64, ptr %l9, !tbaa !24
  store i64 %t281, ptr %l176, !tbaa !24
  %t282 = load i64, ptr %l10, !tbaa !24
  %t284 = icmp sge i64 %t282, 0
  br i1 %t284, label %bb71, label %bb72
bb71:
  %t286 = load i64, ptr %l10, !tbaa !24
  %t287 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d37, i32 0, i32 1) }, 1
  %t288 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d37, i32 0, i32 1) }, 0
  %t290 = call i64 @__olang_fmt_i64(ptr null, i64 %t286)
  %t291 = add i64 %t288, %t290
  %t292 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t291)
  call void @olang_textcopy(ptr %t292, ptr %t287, i64 %t288)
  %t293 = getelementptr i8, ptr %t292, i64 %t288
  %t294 = call i64 @__olang_fmt_i64(ptr %t293, i64 %t286)
  %t295 = insertvalue { i64, ptr } undef, i64 %t291, 0
  %t296 = insertvalue { i64, ptr } %t295, ptr %t292, 1
  %t298 = extractvalue { i64, ptr } %t296, 0
  %t299 = extractvalue { i64, ptr } %t296, 1
  %t300 = mul i64 %t298, 1
  %t301 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t300)
  call void @llvm.memcpy.p0.p0.i64(ptr %t301, ptr %t299, i64 %t300, i1 false)
  %t302 = insertvalue { i64, ptr } undef, i64 %t298, 0
  %t303 = insertvalue { i64, ptr } %t302, ptr %t301, 1
  store { i64, ptr } %t303, ptr %l179, !tbaa !27
  br label %bb73
bb72:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d38, i32 0, i32 1) }, ptr %l179, !tbaa !27
  br label %bb73
bb73:
  %t305 = extractvalue { i64, ptr } { i64 51, ptr getelementptr inbounds (<{ i64, [51 x i8] }>, ptr @.d39, i32 0, i32 1) }, 1
  %t306 = extractvalue { i64, ptr } { i64 51, ptr getelementptr inbounds (<{ i64, [51 x i8] }>, ptr @.d39, i32 0, i32 1) }, 0
  %t307 = load { i64, ptr }, ptr %l179, !tbaa !27
  %t308 = extractvalue { i64, ptr } %t307, 1
  %t309 = extractvalue { i64, ptr } %t307, 0
  %t310 = add i64 %t306, %t309
  %t311 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d40, i32 0, i32 1) }, 1
  %t312 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d40, i32 0, i32 1) }, 0
  %t313 = add i64 %t310, %t312
  %t314 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t313)
  call void @olang_textcopy(ptr %t314, ptr %t305, i64 %t306)
  %t315 = getelementptr i8, ptr %t314, i64 %t306
  call void @olang_textcopy(ptr %t315, ptr %t308, i64 %t309)
  %t316 = getelementptr i8, ptr %t315, i64 %t309
  call void @olang_textcopy(ptr %t316, ptr %t311, i64 %t312)
  %t317 = insertvalue { i64, ptr } undef, i64 %t313, 0
  %t318 = insertvalue { i64, ptr } %t317, ptr %t314, 1
  %t320 = extractvalue { i64, ptr } %t318, 0
  %t321 = extractvalue { i64, ptr } %t318, 1
  %t322 = mul i64 %t320, 1
  %t323 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t322)
  call void @llvm.memcpy.p0.p0.i64(ptr %t323, ptr %t321, i64 %t322, i1 false)
  %t324 = insertvalue { i64, ptr } undef, i64 %t320, 0
  %t325 = insertvalue { i64, ptr } %t324, ptr %t323, 1
  %t326 = load ptr, ptr %l175, !tbaa !29
  %t327 = load i64, ptr %l176, !tbaa !24
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgShared(ptr %v0, ptr %s6, ptr %t326, i64 %t327, { i64, ptr } %t325)
  br label %bb74
bb74:
  %t329 = load i64, ptr %l9, !tbaa !24
  call void @__olang_scope_close(ptr %s6)
  store i64 %t329, ptr %rv
  br label %ret
bb75:
  %t331 = load i32, ptr %l7
  %t333 = trunc i64 21 to i32
  %t334 = icmp eq i32 %t331, %t333
  br i1 %t334, label %bb76, label %bb77
bb76:
  store %olang.scope zeroinitializer, ptr %s10
  %t336 = load ptr, ptr %l0, !tbaa !29
  %t337 = load i32, ptr %l3, !tbaa !23
  %t338 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t339 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t344 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgPair(ptr %v0, ptr %s10, ptr %s10, ptr %t336, i32 %t337, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d41, i32 0, i32 1) }, i32 %t338, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d42, i32 0, i32 1) }, i32 %t339)
  store i64 %t344, ptr %l192
  br label %bb78
bb77:
  br label %bb79
bb78:
  call void @__olang_scope_close(ptr %s10)
  %t345 = load i64, ptr %l192, !tbaa !24
  store i64 %t345, ptr %rv
  br label %ret
bb79:
  %t346 = load ptr, ptr %l0, !tbaa !29
  %t348 = getelementptr %"compiler/emit:Emitter", ptr %t346, i32 0, i32 0
  %t349 = load ptr, ptr %t348, !tbaa !29
  %t350 = load i32, ptr %l3, !tbaa !23
  %t353 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLayout(ptr %v0, ptr %t349, i32 %t350)
  store i1 %t353, ptr %l196
  br label %bb80
bb80:
  %t354 = load ptr, ptr %l2, !tbaa !29
  %t355 = load i32, ptr %l3, !tbaa !23
  %t358 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSize(ptr %v0, ptr %t354, i32 %t355)
  store i64 %t358, ptr %l199
  br label %bb81
bb81:
  %t359 = load i64, ptr %l199, !tbaa !24
  %t360 = mul i64 %t359, 8
  store i64 %t360, ptr %l11, !tbaa !24
  %t362 = load i32, ptr %l7
  %t364 = trunc i64 19 to i32
  %t365 = icmp eq i32 %t362, %t364
  br i1 %t365, label %bb82, label %bb83
bb82:
  store %olang.scope zeroinitializer, ptr %s11
  %t367 = load ptr, ptr %l2, !tbaa !29
  %t368 = load i32, ptr %l3, !tbaa !23
  %t371 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t367, i32 %t368)
  store i32 %t371, ptr %l205
  br label %bb84
bb83:
  br label %bb104
bb84:
  %t372 = load i32, ptr %l205, !tbaa !23
  %t373 = icmp eq i32 %t372, 0
  br i1 %t373, label %bb85, label %bb86
bb85:
  store %olang.scope zeroinitializer, ptr %s12
  %t375 = load ptr, ptr %l0, !tbaa !29
  store ptr %t375, ptr %l207, !tbaa !29
  %t376 = load i32, ptr %l3, !tbaa !23
  store i32 %t376, ptr %l208, !tbaa !23
  %t377 = load ptr, ptr %l2, !tbaa !29
  %t379 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s12, ptr %t377, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d43, i32 0, i32 1) })
  store i32 %t379, ptr %l210
  br label %bb87
bb86:
  br label %bb90
bb87:
  %t380 = load ptr, ptr %l2, !tbaa !29
  %t381 = load i32, ptr %l3, !tbaa !23
  %t384 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t380, i32 %t381)
  store i32 %t384, ptr %l213
  br label %bb88
bb88:
  %t385 = load ptr, ptr %l207, !tbaa !29
  %t386 = load i32, ptr %l208, !tbaa !23
  %t387 = load i32, ptr %l210, !tbaa !23
  %t388 = load i32, ptr %l213, !tbaa !23
  %t389 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgPair(ptr %v0, ptr %s12, ptr %s12, ptr %t385, i32 %t386, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d44, i32 0, i32 1) }, i32 %t387, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d45, i32 0, i32 1) }, i32 %t388)
  store i64 %t389, ptr %l214
  br label %bb89
bb89:
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s11)
  %t390 = load i64, ptr %l214, !tbaa !24
  store i64 %t390, ptr %rv
  br label %ret
bb90:
  %t391 = load ptr, ptr %l0, !tbaa !29
  %t393 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgNew(ptr %v0, ptr %t391)
  store i64 %t393, ptr %l216
  br label %bb91
bb91:
  %t394 = load i64, ptr %l216, !tbaa !24
  store i64 %t394, ptr %l12, !tbaa !24
  %t395 = load ptr, ptr %l0, !tbaa !29
  %t397 = getelementptr %"compiler/emit:Emitter", ptr %t395, i32 0, i32 62
  %t398 = load i32, ptr %l3, !tbaa !23
  %t400 = sext i32 %t398 to i64
  %t401 = load i64, ptr %l12, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t397, i64 %t400, i64 %t401)
  br label %bb92
bb92:
  %t405 = load ptr, ptr %l0, !tbaa !29
  store ptr %t405, ptr %l222, !tbaa !29
  %t406 = load ptr, ptr %l2, !tbaa !29
  %t407 = load i32, ptr %l3, !tbaa !23
  %t410 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t406, i32 %t407)
  store i32 %t410, ptr %l225
  br label %bb93
bb93:
  %t411 = load ptr, ptr %l222, !tbaa !29
  %t412 = load i32, ptr %l225, !tbaa !23
  %t413 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgType(ptr %v0, ptr %t411, i32 %t412)
  store i64 %t413, ptr %l226
  br label %bb94
bb94:
  %t414 = load i64, ptr %l226, !tbaa !24
  store i64 %t414, ptr %l13, !tbaa !24
  %t415 = load i64, ptr %l13, !tbaa !24
  %t417 = icmp slt i64 %t415, 0
  br i1 %t417, label %bb95, label %bb96
bb95:
  %t419 = load ptr, ptr %l0, !tbaa !29
  %t421 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgBytes(ptr %v0, ptr %t419)
  store i64 %t421, ptr %l230
  br label %bb97
bb96:
  br label %bb98
bb97:
  %t422 = load i64, ptr %l230, !tbaa !24
  store i64 %t422, ptr %l13, !tbaa !24
  br label %bb98
bb98:
  %t423 = load ptr, ptr %l0, !tbaa !29
  %t425 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgNew(ptr %v0, ptr %t423)
  store i64 %t425, ptr %l232
  br label %bb99
bb99:
  %t426 = load i64, ptr %l232, !tbaa !24
  store i64 %t426, ptr %l14, !tbaa !24
  %t427 = load ptr, ptr %l0, !tbaa !29
  store ptr %t427, ptr %l233, !tbaa !29
  %t428 = load i64, ptr %l14, !tbaa !24
  store i64 %t428, ptr %l234, !tbaa !24
  %t429 = load ptr, ptr %l2, !tbaa !29
  store ptr %t429, ptr %l235, !tbaa !29
  %t430 = load ptr, ptr %l2, !tbaa !29
  %t431 = load i32, ptr %l3, !tbaa !23
  %t434 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t430, i32 %t431)
  store i32 %t434, ptr %l238
  br label %bb100
bb100:
  %t435 = load ptr, ptr %l235, !tbaa !29
  %t436 = load i32, ptr %l238, !tbaa !23
  %t437 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %t435, i32 %t436)
  store i64 %t437, ptr %l239
  br label %bb101
bb101:
  %t438 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d46, i32 0, i32 1) }, 1
  %t439 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d46, i32 0, i32 1) }, 0
  %t440 = load i64, ptr %l239, !tbaa !24
  %t441 = call i64 @__olang_fmt_i64(ptr null, i64 %t440)
  %t442 = add i64 %t439, %t441
  %t443 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d47, i32 0, i32 1) }, 1
  %t444 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d47, i32 0, i32 1) }, 0
  %t445 = add i64 %t442, %t444
  %t446 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t445)
  call void @olang_textcopy(ptr %t446, ptr %t438, i64 %t439)
  %t447 = getelementptr i8, ptr %t446, i64 %t439
  %t448 = call i64 @__olang_fmt_i64(ptr %t447, i64 %t440)
  %t449 = getelementptr i8, ptr %t447, i64 %t441
  call void @olang_textcopy(ptr %t449, ptr %t443, i64 %t444)
  %t450 = insertvalue { i64, ptr } undef, i64 %t445, 0
  %t451 = insertvalue { i64, ptr } %t450, ptr %t446, 1
  %t453 = extractvalue { i64, ptr } %t451, 0
  %t454 = extractvalue { i64, ptr } %t451, 1
  %t455 = mul i64 %t453, 1
  %t456 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t455)
  call void @llvm.memcpy.p0.p0.i64(ptr %t456, ptr %t454, i64 %t455, i1 false)
  %t457 = insertvalue { i64, ptr } undef, i64 %t453, 0
  %t458 = insertvalue { i64, ptr } %t457, ptr %t456, 1
  %t459 = load ptr, ptr %l233, !tbaa !29
  %t460 = load i64, ptr %l234, !tbaa !24
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgShared(ptr %v0, ptr %s11, ptr %t459, i64 %t460, { i64, ptr } %t458)
  br label %bb102
bb102:
  %t462 = load ptr, ptr %l0, !tbaa !29
  %t463 = load i64, ptr %l12, !tbaa !24
  %t464 = load i64, ptr %l13, !tbaa !24
  %t465 = load i64, ptr %l11, !tbaa !24
  %t466 = load i64, ptr %l14, !tbaa !24
  %t467 = extractvalue { i64, ptr } { i64 52, ptr getelementptr inbounds (<{ i64, [52 x i8] }>, ptr @.d48, i32 0, i32 1) }, 1
  %t468 = extractvalue { i64, ptr } { i64 52, ptr getelementptr inbounds (<{ i64, [52 x i8] }>, ptr @.d48, i32 0, i32 1) }, 0
  %t470 = call i64 @__olang_fmt_i64(ptr null, i64 %t464)
  %t471 = add i64 %t468, %t470
  %t472 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d49, i32 0, i32 1) }, 1
  %t473 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d49, i32 0, i32 1) }, 0
  %t474 = add i64 %t471, %t473
  %t476 = call i64 @__olang_fmt_i64(ptr null, i64 %t465)
  %t477 = add i64 %t474, %t476
  %t478 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d50, i32 0, i32 1) }, 1
  %t479 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d50, i32 0, i32 1) }, 0
  %t480 = add i64 %t477, %t479
  %t482 = call i64 @__olang_fmt_i64(ptr null, i64 %t466)
  %t483 = add i64 %t480, %t482
  %t484 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d51, i32 0, i32 1) }, 1
  %t485 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d51, i32 0, i32 1) }, 0
  %t486 = add i64 %t483, %t485
  %t487 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t486)
  call void @olang_textcopy(ptr %t487, ptr %t467, i64 %t468)
  %t488 = getelementptr i8, ptr %t487, i64 %t468
  %t489 = call i64 @__olang_fmt_i64(ptr %t488, i64 %t464)
  %t490 = getelementptr i8, ptr %t488, i64 %t470
  call void @olang_textcopy(ptr %t490, ptr %t472, i64 %t473)
  %t491 = getelementptr i8, ptr %t490, i64 %t473
  %t492 = call i64 @__olang_fmt_i64(ptr %t491, i64 %t465)
  %t493 = getelementptr i8, ptr %t491, i64 %t476
  call void @olang_textcopy(ptr %t493, ptr %t478, i64 %t479)
  %t494 = getelementptr i8, ptr %t493, i64 %t479
  %t495 = call i64 @__olang_fmt_i64(ptr %t494, i64 %t466)
  %t496 = getelementptr i8, ptr %t494, i64 %t482
  call void @olang_textcopy(ptr %t496, ptr %t484, i64 %t485)
  %t497 = insertvalue { i64, ptr } undef, i64 %t486, 0
  %t498 = insertvalue { i64, ptr } %t497, ptr %t487, 1
  %t500 = extractvalue { i64, ptr } %t498, 0
  %t501 = extractvalue { i64, ptr } %t498, 1
  %t502 = mul i64 %t500, 1
  %t503 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t502)
  call void @llvm.memcpy.p0.p0.i64(ptr %t503, ptr %t501, i64 %t502, i1 false)
  %t504 = insertvalue { i64, ptr } undef, i64 %t500, 0
  %t505 = insertvalue { i64, ptr } %t504, ptr %t503, 1
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgShared(ptr %v0, ptr %s11, ptr %t462, i64 %t463, { i64, ptr } %t505)
  br label %bb103
bb103:
  %t509 = load i64, ptr %l12, !tbaa !24
  call void @__olang_scope_close(ptr %s11)
  store i64 %t509, ptr %rv
  br label %ret
bb104:
  %t511 = load i32, ptr %l7
  %t513 = trunc i64 22 to i32
  %t514 = icmp eq i32 %t511, %t513
  br i1 %t514, label %bb105, label %bb106
bb105:
  store i1 true, ptr %l252, !tbaa !21
  br label %bb107
bb106:
  %t516 = load i32, ptr %l7
  %t518 = trunc i64 23 to i32
  %t519 = icmp eq i32 %t516, %t518
  store i1 %t519, ptr %l252, !tbaa !21
  br label %bb107
bb107:
  %t521 = load i1, ptr %l252, !tbaa !21
  br i1 %t521, label %bb108, label %bb109
bb108:
  store i1 true, ptr %l255, !tbaa !21
  br label %bb115
bb109:
  %t522 = load i32, ptr %l7
  %t524 = trunc i64 18 to i32
  %t525 = icmp eq i32 %t522, %t524
  br i1 %t525, label %bb110, label %bb111
bb110:
  %t527 = load ptr, ptr %l2, !tbaa !29
  store ptr %t527, ptr %l259, !tbaa !29
  %t528 = load ptr, ptr %l2, !tbaa !29
  %t529 = load i32, ptr %l3, !tbaa !23
  %t532 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t528, i32 %t529)
  store i32 %t532, ptr %l262
  br label %bb112
bb111:
  store i1 false, ptr %l258, !tbaa !21
  br label %bb114
bb112:
  %t533 = load ptr, ptr %l259, !tbaa !29
  %t534 = load i32, ptr %l262, !tbaa !23
  %t535 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t533, i32 %t534)
  store i32 %t535, ptr %l263
  br label %bb113
bb113:
  %t536 = load i32, ptr %l263
  %t538 = trunc i64 0 to i32
  %t539 = icmp eq i32 %t536, %t538
  store i1 %t539, ptr %l258, !tbaa !21
  br label %bb114
bb114:
  %t541 = load i1, ptr %l258, !tbaa !21
  store i1 %t541, ptr %l255, !tbaa !21
  br label %bb115
bb115:
  %t542 = load i1, ptr %l255, !tbaa !21
  br i1 %t542, label %bb116, label %bb117
bb116:
  store %olang.scope zeroinitializer, ptr %s16
  %t545 = load ptr, ptr %l0, !tbaa !29
  %t547 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgNew(ptr %v0, ptr %t545)
  store i64 %t547, ptr %l268
  br label %bb118
bb117:
  br label %bb162
bb118:
  %t548 = load i64, ptr %l268, !tbaa !24
  store i64 %t548, ptr %l16, !tbaa !24
  %t549 = load ptr, ptr %l0, !tbaa !29
  %t551 = getelementptr %"compiler/emit:Emitter", ptr %t549, i32 0, i32 62
  %t552 = load i32, ptr %l3, !tbaa !23
  %t554 = sext i32 %t552 to i64
  %t555 = load i64, ptr %l16, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t551, i64 %t554, i64 %t555)
  br label %bb119
bb119:
  %t559 = load ptr, ptr %l2, !tbaa !29
  store ptr %t559, ptr %l274, !tbaa !29
  %t560 = load i32, ptr %l7
  %t562 = trunc i64 18 to i32
  %t563 = icmp eq i32 %t560, %t562
  %t565 = xor i1 %t563, true
  br i1 %t565, label %bb120, label %bb121
bb120:
  %t567 = load ptr, ptr %l2, !tbaa !29
  %t568 = load i32, ptr %l3, !tbaa !23
  %t571 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t567, i32 %t568)
  store i32 %t571, ptr %l281
  br label %bb122
bb121:
  %t572 = load ptr, ptr %l2, !tbaa !29
  %t573 = load i32, ptr %l3, !tbaa !23
  %t576 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t572, i32 %t573)
  store i32 %t576, ptr %l284
  br label %bb123
bb122:
  %t577 = load i32, ptr %l281, !tbaa !23
  store i32 %t577, ptr %l278, !tbaa !23
  br label %bb124
bb123:
  %t578 = load i32, ptr %l284, !tbaa !23
  store i32 %t578, ptr %l278, !tbaa !23
  br label %bb124
bb124:
  %t579 = load ptr, ptr %l274, !tbaa !29
  %t580 = load i32, ptr %l278, !tbaa !23
  %t581 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t579, i32 %t580)
  store { i64, ptr } %t581, ptr %l285
  br label %bb125
bb125:
  %t582 = load { i64, ptr }, ptr %l285, !tbaa !27
  store { i64, ptr } %t582, ptr %l17, !tbaa !27
  %t583 = load ptr, ptr %l0, !tbaa !29
  %t584 = load i32, ptr %l3, !tbaa !23
  %t585 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t587 = extractvalue { i64, ptr } %t585, 0
  %t591 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2efieldNames(ptr %v0, ptr %s16, ptr %t583, i32 %t584, i64 %t587)
  store { i64, ptr } %t591, ptr %l290
  br label %bb126
bb126:
  %t592 = load { i64, ptr }, ptr %l290, !tbaa !27
  store { i64, ptr } %t592, ptr %l18, !tbaa !27
  %t593 = load ptr, ptr %l2, !tbaa !29
  %t594 = load i32, ptr %l3, !tbaa !23
  %t597 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOffsets(ptr %v0, ptr %s16, ptr %t593, i32 %t594)
  store { i64, ptr } %t597, ptr %l293
  br label %bb127
bb127:
  %t598 = load { i64, ptr }, ptr %l293, !tbaa !27
  store { i64, ptr } %t598, ptr %l19, !tbaa !27
  %t599 = call %"std/prelude/text:StringBuilder" @olang_2eHelperKind_2eZero_2estd_2fprelude_2ftext_3aStringBuilder(ptr %s16)
  store %"std/prelude/text:StringBuilder" %t599, ptr %l294
  br label %bb128
bb128:
  %t600 = load %"std/prelude/text:StringBuilder", ptr %l294
  store %"std/prelude/text:StringBuilder" %t600, ptr %l20
  store i64 0, ptr %l21, !tbaa !24
  %t601 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t603 = extractvalue { i64, ptr } %t601, 0
  store i64 %t603, ptr %l22, !tbaa !24
  store i64 1, ptr %l23, !tbaa !24
  %t605 = load i64, ptr %l22, !tbaa !24
  %t606 = load i64, ptr %l21, !tbaa !24
  %t609 = icmp sgt i64 %t605, %t606
  br i1 %t609, label %bb129, label %bb130
bb129:
  %t611 = load i64, ptr %l23, !tbaa !24
  %t613 = icmp sgt i64 %t611, 0
  br i1 %t613, label %bb131, label %bb132
bb130:
  store i64 0, ptr %l300, !tbaa !24
  br label %bb134
bb131:
  %t615 = load i64, ptr %l22, !tbaa !24
  %t616 = load i64, ptr %l21, !tbaa !24
  %t619 = sub i64 %t615, %t616
  %t620 = load i64, ptr %l23, !tbaa !24
  %t623 = add i64 %t619, %t620
  %t625 = sub i64 %t623, 1
  %t626 = load i64, ptr %l23, !tbaa !24
  %t629 = sdiv i64 %t625, %t626
  store i64 %t629, ptr %l303, !tbaa !24
  br label %bb133
bb132:
  store i64 0, ptr %l303, !tbaa !24
  br label %bb133
bb133:
  %t631 = load i64, ptr %l303, !tbaa !24
  store i64 %t631, ptr %l300, !tbaa !24
  br label %bb134
bb134:
  %t632 = load i64, ptr %l300, !tbaa !24
  store i64 %t632, ptr %l24, !tbaa !24
  store i64 0, ptr %l25, !tbaa !24
  br label %bb135
bb135:
  store %olang.scope zeroinitializer, ptr %s18
  %t633 = load i64, ptr %l25, !tbaa !24
  %t634 = load i64, ptr %l24, !tbaa !24
  %t637 = icmp slt i64 %t633, %t634
  %t639 = xor i1 %t637, true
  br i1 %t639, label %bb136, label %bb137
bb136:
  call void @__olang_scope_close(ptr %s18)
  br label %bb155
bb137:
  br label %bb138
bb138:
  %t641 = load i64, ptr %l21, !tbaa !24
  %t642 = load i64, ptr %l25, !tbaa !24
  %t643 = load i64, ptr %l23, !tbaa !24
  %t646 = mul i64 %t642, %t643
  %t649 = add i64 %t641, %t646
  store i64 %t649, ptr %l26, !tbaa !24
  %t651 = load ptr, ptr %l0, !tbaa !29
  %t653 = getelementptr %"compiler/emit:Emitter", ptr %t651, i32 0, i32 0
  %t654 = load ptr, ptr %t653, !tbaa !29
  %t655 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t655, ptr %l323, !tbaa !27
  %t656 = load i64, ptr %l26, !tbaa !24
  %t658 = getelementptr { i64, ptr }, ptr %l323, i32 0, i32 1
  %t659 = load ptr, ptr %t658, !tbaa !27
  %t660 = getelementptr i32, ptr %t659, i64 %t656
  %t661 = load i32, ptr %t660, !tbaa !33
  %t664 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLayout(ptr %v0, ptr %t654, i32 %t661)
  store i1 %t664, ptr %l326
  br label %bb139
bb139:
  %t665 = load ptr, ptr %l0, !tbaa !29
  %t666 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t666, ptr %l328, !tbaa !27
  %t667 = load i64, ptr %l26, !tbaa !24
  %t669 = getelementptr { i64, ptr }, ptr %l328, i32 0, i32 1
  %t670 = load ptr, ptr %t669, !tbaa !27
  %t671 = getelementptr i32, ptr %t670, i64 %t667
  %t672 = load i32, ptr %t671, !tbaa !33
  %t675 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgType(ptr %v0, ptr %t665, i32 %t672)
  store i64 %t675, ptr %l331
  br label %bb140
bb140:
  %t676 = load i64, ptr %l331, !tbaa !24
  store i64 %t676, ptr %l27, !tbaa !24
  %t677 = load i64, ptr %l27, !tbaa !24
  %t679 = icmp slt i64 %t677, 0
  br i1 %t679, label %bb141, label %bb142
bb141:
  %t681 = load ptr, ptr %l0, !tbaa !29
  %t683 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgBytes(ptr %v0, ptr %t681)
  store i64 %t683, ptr %l335
  br label %bb143
bb142:
  br label %bb144
bb143:
  %t684 = load i64, ptr %l335, !tbaa !24
  store i64 %t684, ptr %l27, !tbaa !24
  br label %bb144
bb144:
  %t685 = load ptr, ptr %l0, !tbaa !29
  %t687 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgNew(ptr %v0, ptr %t685)
  store i64 %t687, ptr %l337
  br label %bb145
bb145:
  %t688 = load i64, ptr %l337, !tbaa !24
  store i64 %t688, ptr %l28, !tbaa !24
  %t689 = load ptr, ptr %l0, !tbaa !29
  store ptr %t689, ptr %l338, !tbaa !29
  %t690 = load i64, ptr %l28, !tbaa !24
  store i64 %t690, ptr %l339, !tbaa !24
  %t691 = load i64, ptr %l26, !tbaa !24
  %t693 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t694 = load ptr, ptr %t693, !tbaa !27
  %t695 = getelementptr { i64, ptr }, ptr %t694, i64 %t691
  %t696 = load { i64, ptr }, ptr %t695, !tbaa !37
  %t698 = call { i64, ptr } @compiler_2femit_2eescape(ptr %s16, ptr %s18, { i64, ptr } %t696)
  store { i64, ptr } %t698, ptr %l342
  br label %bb146
bb146:
  %t699 = load i64, ptr %l27, !tbaa !24
  store i64 %t699, ptr %l343, !tbaa !24
  %t700 = load ptr, ptr %l2, !tbaa !29
  %t701 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t701, ptr %l345, !tbaa !27
  %t702 = load i64, ptr %l26, !tbaa !24
  %t704 = getelementptr { i64, ptr }, ptr %l345, i32 0, i32 1
  %t705 = load ptr, ptr %t704, !tbaa !27
  %t706 = getelementptr i32, ptr %t705, i64 %t702
  %t707 = load i32, ptr %t706, !tbaa !33
  %t710 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSize(ptr %v0, ptr %t700, i32 %t707)
  store i64 %t710, ptr %l348
  br label %bb147
bb147:
  %t711 = load i64, ptr %l348, !tbaa !24
  %t712 = mul i64 %t711, 8
  %t713 = load i64, ptr %l26, !tbaa !24
  %t715 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t716 = load ptr, ptr %t715, !tbaa !27
  %t717 = getelementptr i64, ptr %t716, i64 %t713
  %t718 = load i64, ptr %t717, !tbaa !34
  %t720 = mul i64 %t718, 8
  %t721 = extractvalue { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d52, i32 0, i32 1) }, 1
  %t722 = extractvalue { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d52, i32 0, i32 1) }, 0
  %t723 = load { i64, ptr }, ptr %l342, !tbaa !27
  %t724 = extractvalue { i64, ptr } %t723, 1
  %t725 = extractvalue { i64, ptr } %t723, 0
  %t726 = add i64 %t722, %t725
  %t727 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d53, i32 0, i32 1) }, 1
  %t728 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d53, i32 0, i32 1) }, 0
  %t729 = add i64 %t726, %t728
  %t730 = load i64, ptr %l343, !tbaa !24
  %t731 = call i64 @__olang_fmt_i64(ptr null, i64 %t730)
  %t732 = add i64 %t729, %t731
  %t733 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d54, i32 0, i32 1) }, 1
  %t734 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d54, i32 0, i32 1) }, 0
  %t735 = add i64 %t732, %t734
  %t737 = call i64 @__olang_fmt_i64(ptr null, i64 %t712)
  %t738 = add i64 %t735, %t737
  %t739 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d55, i32 0, i32 1) }, 1
  %t740 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d55, i32 0, i32 1) }, 0
  %t741 = add i64 %t738, %t740
  %t743 = call i64 @__olang_fmt_i64(ptr null, i64 %t720)
  %t744 = add i64 %t741, %t743
  %t745 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d56, i32 0, i32 1) }, 1
  %t746 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d56, i32 0, i32 1) }, 0
  %t747 = add i64 %t744, %t746
  %t748 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t747)
  call void @olang_textcopy(ptr %t748, ptr %t721, i64 %t722)
  %t749 = getelementptr i8, ptr %t748, i64 %t722
  call void @olang_textcopy(ptr %t749, ptr %t724, i64 %t725)
  %t750 = getelementptr i8, ptr %t749, i64 %t725
  call void @olang_textcopy(ptr %t750, ptr %t727, i64 %t728)
  %t751 = getelementptr i8, ptr %t750, i64 %t728
  %t752 = call i64 @__olang_fmt_i64(ptr %t751, i64 %t730)
  %t753 = getelementptr i8, ptr %t751, i64 %t731
  call void @olang_textcopy(ptr %t753, ptr %t733, i64 %t734)
  %t754 = getelementptr i8, ptr %t753, i64 %t734
  %t755 = call i64 @__olang_fmt_i64(ptr %t754, i64 %t712)
  %t756 = getelementptr i8, ptr %t754, i64 %t737
  call void @olang_textcopy(ptr %t756, ptr %t739, i64 %t740)
  %t757 = getelementptr i8, ptr %t756, i64 %t740
  %t758 = call i64 @__olang_fmt_i64(ptr %t757, i64 %t720)
  %t759 = getelementptr i8, ptr %t757, i64 %t743
  call void @olang_textcopy(ptr %t759, ptr %t745, i64 %t746)
  %t760 = insertvalue { i64, ptr } undef, i64 %t747, 0
  %t761 = insertvalue { i64, ptr } %t760, ptr %t748, 1
  %t763 = extractvalue { i64, ptr } %t761, 0
  %t764 = extractvalue { i64, ptr } %t761, 1
  %t765 = mul i64 %t763, 1
  %t766 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t765)
  call void @llvm.memcpy.p0.p0.i64(ptr %t766, ptr %t764, i64 %t765, i1 false)
  %t767 = insertvalue { i64, ptr } undef, i64 %t763, 0
  %t768 = insertvalue { i64, ptr } %t767, ptr %t766, 1
  %t769 = load ptr, ptr %l338, !tbaa !29
  %t770 = load i64, ptr %l339, !tbaa !24
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgShared(ptr %v0, ptr %s18, ptr %t769, i64 %t770, { i64, ptr } %t768)
  br label %bb148
bb148:
  %t772 = load i64, ptr %l26, !tbaa !24
  %t774 = icmp sgt i64 %t772, 0
  br i1 %t774, label %bb149, label %bb150
bb149:
  store %olang.scope zeroinitializer, ptr %s21
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s16, ptr %s21, ptr %l20, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d57, i32 0, i32 1) })
  br label %bb151
bb150:
  br label %bb152
bb151:
  call void @__olang_scope_close(ptr %s21)
  br label %bb152
bb152:
  %t777 = load i64, ptr %l28, !tbaa !24
  %t778 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d58, i32 0, i32 1) }, 1
  %t779 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d58, i32 0, i32 1) }, 0
  %t781 = call i64 @__olang_fmt_i64(ptr null, i64 %t777)
  %t782 = add i64 %t779, %t781
  %t783 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t782)
  call void @olang_textcopy(ptr %t783, ptr %t778, i64 %t779)
  %t784 = getelementptr i8, ptr %t783, i64 %t779
  %t785 = call i64 @__olang_fmt_i64(ptr %t784, i64 %t777)
  %t786 = insertvalue { i64, ptr } undef, i64 %t782, 0
  %t787 = insertvalue { i64, ptr } %t786, ptr %t783, 1
  %t789 = extractvalue { i64, ptr } %t787, 0
  %t790 = extractvalue { i64, ptr } %t787, 1
  %t791 = mul i64 %t789, 1
  %t792 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t791)
  call void @llvm.memcpy.p0.p0.i64(ptr %t792, ptr %t790, i64 %t791, i1 false)
  %t793 = insertvalue { i64, ptr } undef, i64 %t789, 0
  %t794 = insertvalue { i64, ptr } %t793, ptr %t792, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s16, ptr %s18, ptr %l20, { i64, ptr } %t794)
  br label %bb153
bb153:
  call void @__olang_scope_close(ptr %s18)
  br label %bb154
bb154:
  %t797 = load i64, ptr %l25, !tbaa !24
  %t799 = add i64 %t797, 1
  store i64 %t799, ptr %l25, !tbaa !24
  br label %bb135
bb155:
  %t801 = load ptr, ptr %l0, !tbaa !29
  %t803 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgNew(ptr %v0, ptr %t801)
  store i64 %t803, ptr %l365
  br label %bb156
bb156:
  %t804 = load i64, ptr %l365, !tbaa !24
  store i64 %t804, ptr %l29, !tbaa !24
  %t805 = load ptr, ptr %l0, !tbaa !29
  store ptr %t805, ptr %l366, !tbaa !29
  %t806 = load i64, ptr %l29, !tbaa !24
  store i64 %t806, ptr %l367, !tbaa !24
  %t808 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s16, ptr %s16, ptr %l20)
  store { i64, ptr } %t808, ptr %l369
  br label %bb157
bb157:
  %t809 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d59, i32 0, i32 1) }, 1
  %t810 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d59, i32 0, i32 1) }, 0
  %t811 = load { i64, ptr }, ptr %l369, !tbaa !27
  %t812 = extractvalue { i64, ptr } %t811, 1
  %t813 = extractvalue { i64, ptr } %t811, 0
  %t814 = add i64 %t810, %t813
  %t815 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d60, i32 0, i32 1) }, 1
  %t816 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d60, i32 0, i32 1) }, 0
  %t817 = add i64 %t814, %t816
  %t818 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t817)
  call void @olang_textcopy(ptr %t818, ptr %t809, i64 %t810)
  %t819 = getelementptr i8, ptr %t818, i64 %t810
  call void @olang_textcopy(ptr %t819, ptr %t812, i64 %t813)
  %t820 = getelementptr i8, ptr %t819, i64 %t813
  call void @olang_textcopy(ptr %t820, ptr %t815, i64 %t816)
  %t821 = insertvalue { i64, ptr } undef, i64 %t817, 0
  %t822 = insertvalue { i64, ptr } %t821, ptr %t818, 1
  %t824 = extractvalue { i64, ptr } %t822, 0
  %t825 = extractvalue { i64, ptr } %t822, 1
  %t826 = mul i64 %t824, 1
  %t827 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t826)
  call void @llvm.memcpy.p0.p0.i64(ptr %t827, ptr %t825, i64 %t826, i1 false)
  %t828 = insertvalue { i64, ptr } undef, i64 %t824, 0
  %t829 = insertvalue { i64, ptr } %t828, ptr %t827, 1
  %t830 = load ptr, ptr %l366, !tbaa !29
  %t831 = load i64, ptr %l367, !tbaa !24
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgShared(ptr %v0, ptr %s16, ptr %t830, i64 %t831, { i64, ptr } %t829)
  br label %bb158
bb158:
  %t833 = load ptr, ptr %l0, !tbaa !29
  store ptr %t833, ptr %l372, !tbaa !29
  %t834 = load i64, ptr %l16, !tbaa !24
  store i64 %t834, ptr %l373, !tbaa !24
  %t835 = load ptr, ptr %l0, !tbaa !29
  %t836 = load i32, ptr %l3, !tbaa !23
  %t839 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgTypeName(ptr %v0, ptr %s16, ptr %t835, i32 %t836)
  store { i64, ptr } %t839, ptr %l376
  br label %bb159
bb159:
  %t840 = load { i64, ptr }, ptr %l376, !tbaa !27
  %t841 = extractvalue { i64, ptr } %t840, 0
  %t842 = extractvalue { i64, ptr } %t840, 1
  %t843 = mul i64 %t841, 1
  %t844 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t843)
  call void @llvm.memcpy.p0.p0.i64(ptr %t844, ptr %t842, i64 %t843, i1 false)
  %t845 = insertvalue { i64, ptr } undef, i64 %t841, 0
  %t846 = insertvalue { i64, ptr } %t845, ptr %t844, 1
  %t848 = call { i64, ptr } @compiler_2femit_2eescape(ptr %s16, ptr %s16, { i64, ptr } %t846)
  store { i64, ptr } %t848, ptr %l378
  br label %bb160
bb160:
  %t849 = load i64, ptr %l11, !tbaa !24
  %t850 = load i64, ptr %l29, !tbaa !24
  %t851 = extractvalue { i64, ptr } { i64 52, ptr getelementptr inbounds (<{ i64, [52 x i8] }>, ptr @.d61, i32 0, i32 1) }, 1
  %t852 = extractvalue { i64, ptr } { i64 52, ptr getelementptr inbounds (<{ i64, [52 x i8] }>, ptr @.d61, i32 0, i32 1) }, 0
  %t853 = load { i64, ptr }, ptr %l378, !tbaa !27
  %t854 = extractvalue { i64, ptr } %t853, 1
  %t855 = extractvalue { i64, ptr } %t853, 0
  %t856 = add i64 %t852, %t855
  %t857 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d62, i32 0, i32 1) }, 1
  %t858 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d62, i32 0, i32 1) }, 0
  %t859 = add i64 %t856, %t858
  %t861 = call i64 @__olang_fmt_i64(ptr null, i64 %t849)
  %t862 = add i64 %t859, %t861
  %t863 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d63, i32 0, i32 1) }, 1
  %t864 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d63, i32 0, i32 1) }, 0
  %t865 = add i64 %t862, %t864
  %t867 = call i64 @__olang_fmt_i64(ptr null, i64 %t850)
  %t868 = add i64 %t865, %t867
  %t869 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d64, i32 0, i32 1) }, 1
  %t870 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d64, i32 0, i32 1) }, 0
  %t871 = add i64 %t868, %t870
  %t872 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t871)
  call void @olang_textcopy(ptr %t872, ptr %t851, i64 %t852)
  %t873 = getelementptr i8, ptr %t872, i64 %t852
  call void @olang_textcopy(ptr %t873, ptr %t854, i64 %t855)
  %t874 = getelementptr i8, ptr %t873, i64 %t855
  call void @olang_textcopy(ptr %t874, ptr %t857, i64 %t858)
  %t875 = getelementptr i8, ptr %t874, i64 %t858
  %t876 = call i64 @__olang_fmt_i64(ptr %t875, i64 %t849)
  %t877 = getelementptr i8, ptr %t875, i64 %t861
  call void @olang_textcopy(ptr %t877, ptr %t863, i64 %t864)
  %t878 = getelementptr i8, ptr %t877, i64 %t864
  %t879 = call i64 @__olang_fmt_i64(ptr %t878, i64 %t850)
  %t880 = getelementptr i8, ptr %t878, i64 %t867
  call void @olang_textcopy(ptr %t880, ptr %t869, i64 %t870)
  %t881 = insertvalue { i64, ptr } undef, i64 %t871, 0
  %t882 = insertvalue { i64, ptr } %t881, ptr %t872, 1
  %t884 = extractvalue { i64, ptr } %t882, 0
  %t885 = extractvalue { i64, ptr } %t882, 1
  %t886 = mul i64 %t884, 1
  %t887 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t886)
  call void @llvm.memcpy.p0.p0.i64(ptr %t887, ptr %t885, i64 %t886, i1 false)
  %t888 = insertvalue { i64, ptr } undef, i64 %t884, 0
  %t889 = insertvalue { i64, ptr } %t888, ptr %t887, 1
  %t890 = load ptr, ptr %l372, !tbaa !29
  %t891 = load i64, ptr %l373, !tbaa !24
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgShared(ptr %v0, ptr %s16, ptr %t890, i64 %t891, { i64, ptr } %t889)
  br label %bb161
bb161:
  %t893 = load i64, ptr %l16, !tbaa !24
  call void @__olang_scope_close(ptr %s16)
  store i64 %t893, ptr %rv
  br label %ret
bb162:
  %t895 = load i32, ptr %l7
  %t897 = trunc i64 24 to i32
  %t898 = icmp eq i32 %t895, %t897
  br i1 %t898, label %bb163, label %bb164
bb163:
  store i1 true, ptr %l386, !tbaa !21
  br label %bb170
bb164:
  %t900 = load i32, ptr %l7
  %t902 = trunc i64 18 to i32
  %t903 = icmp eq i32 %t900, %t902
  br i1 %t903, label %bb165, label %bb166
bb165:
  %t905 = load ptr, ptr %l2, !tbaa !29
  store ptr %t905, ptr %l390, !tbaa !29
  %t906 = load ptr, ptr %l2, !tbaa !29
  %t907 = load i32, ptr %l3, !tbaa !23
  %t910 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t906, i32 %t907)
  store i32 %t910, ptr %l393
  br label %bb167
bb166:
  store i1 false, ptr %l389, !tbaa !21
  br label %bb169
bb167:
  %t911 = load ptr, ptr %l390, !tbaa !29
  %t912 = load i32, ptr %l393, !tbaa !23
  %t913 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t911, i32 %t912)
  store i32 %t913, ptr %l394
  br label %bb168
bb168:
  %t914 = load i32, ptr %l394
  %t916 = trunc i64 1 to i32
  %t917 = icmp eq i32 %t914, %t916
  store i1 %t917, ptr %l389, !tbaa !21
  br label %bb169
bb169:
  %t919 = load i1, ptr %l389, !tbaa !21
  store i1 %t919, ptr %l386, !tbaa !21
  br label %bb170
bb170:
  %t920 = load i1, ptr %l386, !tbaa !21
  br i1 %t920, label %bb171, label %bb172
bb171:
  store %olang.scope zeroinitializer, ptr %s26
  %t923 = load ptr, ptr %l0, !tbaa !29
  %t925 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgNew(ptr %v0, ptr %t923)
  store i64 %t925, ptr %l399
  br label %bb173
bb172:
  br label %bb256
bb173:
  %t926 = load i64, ptr %l399, !tbaa !24
  store i64 %t926, ptr %l31, !tbaa !24
  %t927 = load ptr, ptr %l0, !tbaa !29
  %t929 = getelementptr %"compiler/emit:Emitter", ptr %t927, i32 0, i32 62
  %t930 = load i32, ptr %l3, !tbaa !23
  %t932 = sext i32 %t930 to i64
  %t933 = load i64, ptr %l31, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t929, i64 %t932, i64 %t933)
  br label %bb174
bb174:
  %t937 = load i32, ptr %l7
  %t939 = trunc i64 18 to i32
  %t940 = icmp eq i32 %t937, %t939
  br i1 %t940, label %bb175, label %bb176
bb175:
  %t942 = load ptr, ptr %l2, !tbaa !29
  %t943 = load i32, ptr %l3, !tbaa !23
  %t946 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCaseNames(ptr %v0, ptr %t942, i32 %t943)
  store { i64, ptr } %t946, ptr %l410
  br label %bb177
bb176:
  %t947 = icmp sge i64 0, 0
  br i1 %t947, label %bb178, label %bb179
bb177:
  %t949 = load { i64, ptr }, ptr %l410, !tbaa !27
  store { i64, ptr } %t949, ptr %l407, !tbaa !27
  br label %bb182
bb178:
  %t950 = icmp sle i64 0, 2305843009213693951
  br i1 %t950, label %bb180, label %bb181
bb179:
  call void @__olang_check_failed(ptr @olang_loc_649f734ddce51468_b7eb8be07e4dd31c)
  unreachable
bb180:
  %t952 = mul i64 0, 4
  %t953 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t952)
  %t954 = insertvalue { i64, ptr } undef, i64 0, 0
  %t955 = insertvalue { i64, ptr } %t954, ptr %t953, 1
  store { i64, ptr } %t955, ptr %l407, !tbaa !27
  br label %bb182
bb181:
  call void @__olang_check_failed(ptr @olang_loc_649f734ddce51468_b7eb8be07e4dd31c)
  unreachable
bb182:
  %t957 = load { i64, ptr }, ptr %l407, !tbaa !27
  store { i64, ptr } %t957, ptr %l32, !tbaa !27
  %t958 = load ptr, ptr %l2, !tbaa !29
  store ptr %t958, ptr %l414, !tbaa !29
  %t959 = load i32, ptr %l7
  %t961 = trunc i64 24 to i32
  %t962 = icmp eq i32 %t959, %t961
  br i1 %t962, label %bb183, label %bb184
bb183:
  %t964 = load ptr, ptr %l2, !tbaa !29
  %t965 = load i32, ptr %l3, !tbaa !23
  %t968 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %t964, i32 %t965)
  store i32 %t968, ptr %l420
  br label %bb185
bb184:
  %t969 = load ptr, ptr %l2, !tbaa !29
  %t970 = load i32, ptr %l3, !tbaa !23
  %t973 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t969, i32 %t970)
  store i32 %t973, ptr %l423
  br label %bb186
bb185:
  %t974 = load i32, ptr %l420, !tbaa !23
  store i32 %t974, ptr %l417, !tbaa !23
  br label %bb187
bb186:
  %t975 = load i32, ptr %l423, !tbaa !23
  store i32 %t975, ptr %l417, !tbaa !23
  br label %bb187
bb187:
  %t976 = load ptr, ptr %l414, !tbaa !29
  %t977 = load i32, ptr %l417, !tbaa !23
  %t978 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t976, i32 %t977)
  store { i64, ptr } %t978, ptr %l424
  br label %bb188
bb188:
  %t979 = load { i64, ptr }, ptr %l424, !tbaa !27
  store { i64, ptr } %t979, ptr %l33, !tbaa !27
  %t980 = call %"std/prelude/text:StringBuilder" @olang_2eHelperKind_2eZero_2estd_2fprelude_2ftext_3aStringBuilder(ptr %s26)
  store %"std/prelude/text:StringBuilder" %t980, ptr %l425
  br label %bb189
bb189:
  %t981 = load %"std/prelude/text:StringBuilder", ptr %l425
  store %"std/prelude/text:StringBuilder" %t981, ptr %l34
  store i64 0, ptr %l35, !tbaa !24
  %t982 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t984 = extractvalue { i64, ptr } %t982, 0
  store i64 %t984, ptr %l36, !tbaa !24
  store i64 1, ptr %l37, !tbaa !24
  %t986 = load i64, ptr %l36, !tbaa !24
  %t987 = load i64, ptr %l35, !tbaa !24
  %t990 = icmp sgt i64 %t986, %t987
  br i1 %t990, label %bb190, label %bb191
bb190:
  %t992 = load i64, ptr %l37, !tbaa !24
  %t994 = icmp sgt i64 %t992, 0
  br i1 %t994, label %bb192, label %bb193
bb191:
  store i64 0, ptr %l431, !tbaa !24
  br label %bb195
bb192:
  %t996 = load i64, ptr %l36, !tbaa !24
  %t997 = load i64, ptr %l35, !tbaa !24
  %t1000 = sub i64 %t996, %t997
  %t1001 = load i64, ptr %l37, !tbaa !24
  %t1004 = add i64 %t1000, %t1001
  %t1006 = sub i64 %t1004, 1
  %t1007 = load i64, ptr %l37, !tbaa !24
  %t1010 = sdiv i64 %t1006, %t1007
  store i64 %t1010, ptr %l434, !tbaa !24
  br label %bb194
bb193:
  store i64 0, ptr %l434, !tbaa !24
  br label %bb194
bb194:
  %t1012 = load i64, ptr %l434, !tbaa !24
  store i64 %t1012, ptr %l431, !tbaa !24
  br label %bb195
bb195:
  %t1013 = load i64, ptr %l431, !tbaa !24
  store i64 %t1013, ptr %l38, !tbaa !24
  store i64 0, ptr %l39, !tbaa !24
  br label %bb196
bb196:
  store %olang.scope zeroinitializer, ptr %s28
  %t1014 = load i64, ptr %l39, !tbaa !24
  %t1015 = load i64, ptr %l38, !tbaa !24
  %t1018 = icmp slt i64 %t1014, %t1015
  %t1020 = xor i1 %t1018, true
  br i1 %t1020, label %bb197, label %bb198
bb197:
  call void @__olang_scope_close(ptr %s28)
  br label %bb216
bb198:
  br label %bb199
bb199:
  %t1022 = load i64, ptr %l35, !tbaa !24
  %t1023 = load i64, ptr %l39, !tbaa !24
  %t1024 = load i64, ptr %l37, !tbaa !24
  %t1027 = mul i64 %t1023, %t1024
  %t1030 = add i64 %t1022, %t1027
  store i64 %t1030, ptr %l40, !tbaa !24
  %t1032 = load ptr, ptr %l0, !tbaa !29
  %t1034 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgNew(ptr %v0, ptr %t1032)
  store i64 %t1034, ptr %l453
  br label %bb200
bb200:
  %t1035 = load i64, ptr %l453, !tbaa !24
  store i64 %t1035, ptr %l41, !tbaa !24
  %t1036 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t1038 = extractvalue { i64, ptr } %t1036, 0
  %t1040 = icmp sgt i64 %t1038, 0
  br i1 %t1040, label %bb201, label %bb202
bb201:
  %t1042 = load i64, ptr %l40, !tbaa !24
  %t1043 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t1045 = extractvalue { i64, ptr } %t1043, 0
  %t1048 = icmp slt i64 %t1042, %t1045
  store i1 %t1048, ptr %l457, !tbaa !21
  br label %bb203
bb202:
  store i1 false, ptr %l457, !tbaa !21
  br label %bb203
bb203:
  %t1050 = load i1, ptr %l457, !tbaa !21
  br i1 %t1050, label %bb204, label %bb205
bb204:
  %t1051 = load ptr, ptr %l0, !tbaa !29
  %t1052 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t1052, ptr %l464, !tbaa !27
  %t1053 = load i64, ptr %l40, !tbaa !24
  %t1055 = getelementptr { i64, ptr }, ptr %l464, i32 0, i32 1
  %t1056 = load ptr, ptr %t1055, !tbaa !27
  %t1057 = getelementptr i32, ptr %t1056, i64 %t1053
  %t1058 = load i32, ptr %t1057, !tbaa !33
  %t1061 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etext(ptr %v0, ptr %t1051, i32 %t1058)
  store { i64, ptr } %t1061, ptr %l467
  br label %bb206
bb205:
  %t1062 = load i64, ptr %l40, !tbaa !24
  %t1064 = call i64 @__olang_fmt_i64(ptr null, i64 %t1062)
  %t1065 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t1064)
  %t1066 = call i64 @__olang_fmt_i64(ptr %t1065, i64 %t1062)
  %t1067 = insertvalue { i64, ptr } undef, i64 %t1064, 0
  %t1068 = insertvalue { i64, ptr } %t1067, ptr %t1065, 1
  %t1070 = extractvalue { i64, ptr } %t1068, 0
  %t1071 = extractvalue { i64, ptr } %t1068, 1
  %t1072 = mul i64 %t1070, 1
  %t1073 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t1072)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1073, ptr %t1071, i64 %t1072, i1 false)
  %t1074 = insertvalue { i64, ptr } undef, i64 %t1070, 0
  %t1075 = insertvalue { i64, ptr } %t1074, ptr %t1073, 1
  store { i64, ptr } %t1075, ptr %l462, !tbaa !27
  br label %bb207
bb206:
  %t1077 = load { i64, ptr }, ptr %l467, !tbaa !27
  store { i64, ptr } %t1077, ptr %l462, !tbaa !27
  br label %bb207
bb207:
  %t1078 = load { i64, ptr }, ptr %l462, !tbaa !27
  %t1079 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1079, ptr %l471, !tbaa !29
  %t1080 = load i64, ptr %l41, !tbaa !24
  store i64 %t1080, ptr %l472, !tbaa !24
  %t1083 = call { i64, ptr } @compiler_2femit_2eescape(ptr %v0, ptr %s28, { i64, ptr } %t1078)
  store { i64, ptr } %t1083, ptr %l474
  br label %bb208
bb208:
  %t1084 = load i64, ptr %l40, !tbaa !24
  %t1085 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d65, i32 0, i32 1) }, 1
  %t1086 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d65, i32 0, i32 1) }, 0
  %t1087 = load { i64, ptr }, ptr %l474, !tbaa !27
  %t1088 = extractvalue { i64, ptr } %t1087, 1
  %t1089 = extractvalue { i64, ptr } %t1087, 0
  %t1090 = add i64 %t1086, %t1089
  %t1091 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d66, i32 0, i32 1) }, 1
  %t1092 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d66, i32 0, i32 1) }, 0
  %t1093 = add i64 %t1090, %t1092
  %t1095 = call i64 @__olang_fmt_i64(ptr null, i64 %t1084)
  %t1096 = add i64 %t1093, %t1095
  %t1097 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d67, i32 0, i32 1) }, 1
  %t1098 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d67, i32 0, i32 1) }, 0
  %t1099 = add i64 %t1096, %t1098
  %t1100 = call ptr @__olang_scope_alloc(ptr %s28, i64 %t1099)
  call void @olang_textcopy(ptr %t1100, ptr %t1085, i64 %t1086)
  %t1101 = getelementptr i8, ptr %t1100, i64 %t1086
  call void @olang_textcopy(ptr %t1101, ptr %t1088, i64 %t1089)
  %t1102 = getelementptr i8, ptr %t1101, i64 %t1089
  call void @olang_textcopy(ptr %t1102, ptr %t1091, i64 %t1092)
  %t1103 = getelementptr i8, ptr %t1102, i64 %t1092
  %t1104 = call i64 @__olang_fmt_i64(ptr %t1103, i64 %t1084)
  %t1105 = getelementptr i8, ptr %t1103, i64 %t1095
  call void @olang_textcopy(ptr %t1105, ptr %t1097, i64 %t1098)
  %t1106 = insertvalue { i64, ptr } undef, i64 %t1099, 0
  %t1107 = insertvalue { i64, ptr } %t1106, ptr %t1100, 1
  %t1109 = extractvalue { i64, ptr } %t1107, 0
  %t1110 = extractvalue { i64, ptr } %t1107, 1
  %t1111 = mul i64 %t1109, 1
  %t1112 = call ptr @__olang_scope_alloc(ptr %s28, i64 %t1111)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1112, ptr %t1110, i64 %t1111, i1 false)
  %t1113 = insertvalue { i64, ptr } undef, i64 %t1109, 0
  %t1114 = insertvalue { i64, ptr } %t1113, ptr %t1112, 1
  %t1115 = load ptr, ptr %l471, !tbaa !29
  %t1116 = load i64, ptr %l472, !tbaa !24
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgShared(ptr %v0, ptr %s28, ptr %t1115, i64 %t1116, { i64, ptr } %t1114)
  br label %bb209
bb209:
  %t1118 = load i64, ptr %l40, !tbaa !24
  %t1120 = icmp sgt i64 %t1118, 0
  br i1 %t1120, label %bb210, label %bb211
bb210:
  store %olang.scope zeroinitializer, ptr %s31
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s26, ptr %s31, ptr %l34, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d68, i32 0, i32 1) })
  br label %bb212
bb211:
  br label %bb213
bb212:
  call void @__olang_scope_close(ptr %s31)
  br label %bb213
bb213:
  %t1123 = load i64, ptr %l41, !tbaa !24
  %t1124 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d69, i32 0, i32 1) }, 1
  %t1125 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d69, i32 0, i32 1) }, 0
  %t1127 = call i64 @__olang_fmt_i64(ptr null, i64 %t1123)
  %t1128 = add i64 %t1125, %t1127
  %t1129 = call ptr @__olang_scope_alloc(ptr %s28, i64 %t1128)
  call void @olang_textcopy(ptr %t1129, ptr %t1124, i64 %t1125)
  %t1130 = getelementptr i8, ptr %t1129, i64 %t1125
  %t1131 = call i64 @__olang_fmt_i64(ptr %t1130, i64 %t1123)
  %t1132 = insertvalue { i64, ptr } undef, i64 %t1128, 0
  %t1133 = insertvalue { i64, ptr } %t1132, ptr %t1129, 1
  %t1135 = extractvalue { i64, ptr } %t1133, 0
  %t1136 = extractvalue { i64, ptr } %t1133, 1
  %t1137 = mul i64 %t1135, 1
  %t1138 = call ptr @__olang_scope_alloc(ptr %s28, i64 %t1137)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1138, ptr %t1136, i64 %t1137, i1 false)
  %t1139 = insertvalue { i64, ptr } undef, i64 %t1135, 0
  %t1140 = insertvalue { i64, ptr } %t1139, ptr %t1138, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s26, ptr %s28, ptr %l34, { i64, ptr } %t1140)
  br label %bb214
bb214:
  call void @__olang_scope_close(ptr %s28)
  br label %bb215
bb215:
  %t1143 = load i64, ptr %l39, !tbaa !24
  %t1145 = add i64 %t1143, 1
  store i64 %t1145, ptr %l39, !tbaa !24
  br label %bb196
bb216:
  %t1147 = load ptr, ptr %l0, !tbaa !29
  %t1149 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgNew(ptr %v0, ptr %t1147)
  store i64 %t1149, ptr %l488
  br label %bb217
bb217:
  %t1150 = load i64, ptr %l488, !tbaa !24
  store i64 %t1150, ptr %l43, !tbaa !24
  %t1151 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1151, ptr %l489, !tbaa !29
  %t1152 = load i64, ptr %l43, !tbaa !24
  store i64 %t1152, ptr %l490, !tbaa !24
  %t1154 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s26, ptr %s26, ptr %l34)
  store { i64, ptr } %t1154, ptr %l492
  br label %bb218
bb218:
  %t1155 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d70, i32 0, i32 1) }, 1
  %t1156 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d70, i32 0, i32 1) }, 0
  %t1157 = load { i64, ptr }, ptr %l492, !tbaa !27
  %t1158 = extractvalue { i64, ptr } %t1157, 1
  %t1159 = extractvalue { i64, ptr } %t1157, 0
  %t1160 = add i64 %t1156, %t1159
  %t1161 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d71, i32 0, i32 1) }, 1
  %t1162 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d71, i32 0, i32 1) }, 0
  %t1163 = add i64 %t1160, %t1162
  %t1164 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t1163)
  call void @olang_textcopy(ptr %t1164, ptr %t1155, i64 %t1156)
  %t1165 = getelementptr i8, ptr %t1164, i64 %t1156
  call void @olang_textcopy(ptr %t1165, ptr %t1158, i64 %t1159)
  %t1166 = getelementptr i8, ptr %t1165, i64 %t1159
  call void @olang_textcopy(ptr %t1166, ptr %t1161, i64 %t1162)
  %t1167 = insertvalue { i64, ptr } undef, i64 %t1163, 0
  %t1168 = insertvalue { i64, ptr } %t1167, ptr %t1164, 1
  %t1170 = extractvalue { i64, ptr } %t1168, 0
  %t1171 = extractvalue { i64, ptr } %t1168, 1
  %t1172 = mul i64 %t1170, 1
  %t1173 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t1172)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1173, ptr %t1171, i64 %t1172, i1 false)
  %t1174 = insertvalue { i64, ptr } undef, i64 %t1170, 0
  %t1175 = insertvalue { i64, ptr } %t1174, ptr %t1173, 1
  %t1176 = load ptr, ptr %l489, !tbaa !29
  %t1177 = load i64, ptr %l490, !tbaa !24
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgShared(ptr %v0, ptr %s26, ptr %t1176, i64 %t1177, { i64, ptr } %t1175)
  br label %bb219
bb219:
  %t1179 = load ptr, ptr %l0, !tbaa !29
  %t1180 = load i32, ptr %l3, !tbaa !23
  %t1183 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eenumWords(ptr %v0, ptr %t1179, i32 %t1180)
  store i1 %t1183, ptr %l497
  br label %bb220
bb220:
  %t1184 = load i1, ptr %l497, !tbaa !21
  store i1 %t1184, ptr %l44, !tbaa !21
  %t1185 = load i1, ptr %l44, !tbaa !21
  %t1187 = xor i1 %t1185, true
  br i1 %t1187, label %bb221, label %bb222
bb221:
  %t1189 = load i64, ptr %l31, !tbaa !24
  store i64 %t1189, ptr %l500, !tbaa !24
  br label %bb224
bb222:
  %t1191 = load ptr, ptr %l0, !tbaa !29
  %t1193 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgNew(ptr %v0, ptr %t1191)
  store i64 %t1193, ptr %l503
  br label %bb223
bb223:
  %t1194 = load i64, ptr %l503, !tbaa !24
  store i64 %t1194, ptr %l500, !tbaa !24
  br label %bb224
bb224:
  %t1195 = load i64, ptr %l500, !tbaa !24
  store i64 %t1195, ptr %l45, !tbaa !24
  %t1196 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1196, ptr %l504, !tbaa !29
  %t1197 = load i1, ptr %l44, !tbaa !21
  br i1 %t1197, label %bb225, label %bb226
bb225:
  %t1199 = load ptr, ptr %l2, !tbaa !29
  %t1201 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s26, ptr %t1199, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d72, i32 0, i32 1) })
  store i32 %t1201, ptr %l508
  br label %bb227
bb226:
  %t1202 = load ptr, ptr %l2, !tbaa !29
  %t1204 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s26, ptr %t1202, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d73, i32 0, i32 1) })
  store i32 %t1204, ptr %l510
  br label %bb228
bb227:
  %t1205 = load i32, ptr %l508, !tbaa !23
  store i32 %t1205, ptr %l506, !tbaa !23
  br label %bb229
bb228:
  %t1206 = load i32, ptr %l510, !tbaa !23
  store i32 %t1206, ptr %l506, !tbaa !23
  br label %bb229
bb229:
  %t1207 = load ptr, ptr %l504, !tbaa !29
  %t1208 = load i32, ptr %l506, !tbaa !23
  %t1209 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgType(ptr %v0, ptr %t1207, i32 %t1208)
  store i64 %t1209, ptr %l511
  br label %bb230
bb230:
  %t1210 = load i64, ptr %l511, !tbaa !24
  store i64 %t1210, ptr %l46, !tbaa !24
  %t1211 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1211, ptr %l512, !tbaa !29
  %t1212 = load i64, ptr %l45, !tbaa !24
  store i64 %t1212, ptr %l513, !tbaa !24
  %t1213 = load ptr, ptr %l0, !tbaa !29
  %t1214 = load i32, ptr %l3, !tbaa !23
  %t1217 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgTypeName(ptr %v0, ptr %s26, ptr %t1213, i32 %t1214)
  store { i64, ptr } %t1217, ptr %l516
  br label %bb231
bb231:
  %t1218 = load { i64, ptr }, ptr %l516, !tbaa !27
  %t1219 = extractvalue { i64, ptr } %t1218, 0
  %t1220 = extractvalue { i64, ptr } %t1218, 1
  %t1221 = mul i64 %t1219, 1
  %t1222 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t1221)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1222, ptr %t1220, i64 %t1221, i1 false)
  %t1223 = insertvalue { i64, ptr } undef, i64 %t1219, 0
  %t1224 = insertvalue { i64, ptr } %t1223, ptr %t1222, 1
  %t1226 = call { i64, ptr } @compiler_2femit_2eescape(ptr %s26, ptr %s26, { i64, ptr } %t1224)
  store { i64, ptr } %t1226, ptr %l518
  br label %bb232
bb232:
  %t1227 = load i1, ptr %l44, !tbaa !21
  br i1 %t1227, label %bb233, label %bb234
bb233:
  store i64 64, ptr %l520, !tbaa !24
  br label %bb235
bb234:
  store i64 32, ptr %l520, !tbaa !24
  br label %bb235
bb235:
  %t1229 = load i64, ptr %l46, !tbaa !24
  %t1230 = load i64, ptr %l43, !tbaa !24
  %t1231 = extractvalue { i64, ptr } { i64 54, ptr getelementptr inbounds (<{ i64, [54 x i8] }>, ptr @.d74, i32 0, i32 1) }, 1
  %t1232 = extractvalue { i64, ptr } { i64 54, ptr getelementptr inbounds (<{ i64, [54 x i8] }>, ptr @.d74, i32 0, i32 1) }, 0
  %t1233 = load { i64, ptr }, ptr %l518, !tbaa !27
  %t1234 = extractvalue { i64, ptr } %t1233, 1
  %t1235 = extractvalue { i64, ptr } %t1233, 0
  %t1236 = add i64 %t1232, %t1235
  %t1237 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d75, i32 0, i32 1) }, 1
  %t1238 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d75, i32 0, i32 1) }, 0
  %t1239 = add i64 %t1236, %t1238
  %t1240 = load i64, ptr %l520, !tbaa !24
  %t1241 = call i64 @__olang_fmt_i64(ptr null, i64 %t1240)
  %t1242 = add i64 %t1239, %t1241
  %t1243 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d76, i32 0, i32 1) }, 1
  %t1244 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d76, i32 0, i32 1) }, 0
  %t1245 = add i64 %t1242, %t1244
  %t1247 = call i64 @__olang_fmt_i64(ptr null, i64 %t1229)
  %t1248 = add i64 %t1245, %t1247
  %t1249 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d77, i32 0, i32 1) }, 1
  %t1250 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d77, i32 0, i32 1) }, 0
  %t1251 = add i64 %t1248, %t1250
  %t1253 = call i64 @__olang_fmt_i64(ptr null, i64 %t1230)
  %t1254 = add i64 %t1251, %t1253
  %t1255 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d78, i32 0, i32 1) }, 1
  %t1256 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d78, i32 0, i32 1) }, 0
  %t1257 = add i64 %t1254, %t1256
  %t1258 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t1257)
  call void @olang_textcopy(ptr %t1258, ptr %t1231, i64 %t1232)
  %t1259 = getelementptr i8, ptr %t1258, i64 %t1232
  call void @olang_textcopy(ptr %t1259, ptr %t1234, i64 %t1235)
  %t1260 = getelementptr i8, ptr %t1259, i64 %t1235
  call void @olang_textcopy(ptr %t1260, ptr %t1237, i64 %t1238)
  %t1261 = getelementptr i8, ptr %t1260, i64 %t1238
  %t1262 = call i64 @__olang_fmt_i64(ptr %t1261, i64 %t1240)
  %t1263 = getelementptr i8, ptr %t1261, i64 %t1241
  call void @olang_textcopy(ptr %t1263, ptr %t1243, i64 %t1244)
  %t1264 = getelementptr i8, ptr %t1263, i64 %t1244
  %t1265 = call i64 @__olang_fmt_i64(ptr %t1264, i64 %t1229)
  %t1266 = getelementptr i8, ptr %t1264, i64 %t1247
  call void @olang_textcopy(ptr %t1266, ptr %t1249, i64 %t1250)
  %t1267 = getelementptr i8, ptr %t1266, i64 %t1250
  %t1268 = call i64 @__olang_fmt_i64(ptr %t1267, i64 %t1230)
  %t1269 = getelementptr i8, ptr %t1267, i64 %t1253
  call void @olang_textcopy(ptr %t1269, ptr %t1255, i64 %t1256)
  %t1270 = insertvalue { i64, ptr } undef, i64 %t1257, 0
  %t1271 = insertvalue { i64, ptr } %t1270, ptr %t1258, 1
  %t1273 = extractvalue { i64, ptr } %t1271, 0
  %t1274 = extractvalue { i64, ptr } %t1271, 1
  %t1275 = mul i64 %t1273, 1
  %t1276 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t1275)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1276, ptr %t1274, i64 %t1275, i1 false)
  %t1277 = insertvalue { i64, ptr } undef, i64 %t1273, 0
  %t1278 = insertvalue { i64, ptr } %t1277, ptr %t1276, 1
  %t1279 = load ptr, ptr %l512, !tbaa !29
  %t1280 = load i64, ptr %l513, !tbaa !24
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgShared(ptr %v0, ptr %s26, ptr %t1279, i64 %t1280, { i64, ptr } %t1278)
  br label %bb236
bb236:
  %t1282 = load i1, ptr %l44, !tbaa !21
  %t1284 = xor i1 %t1282, true
  br i1 %t1284, label %bb237, label %bb238
bb237:
  %t1286 = load i64, ptr %l31, !tbaa !24
  call void @__olang_scope_close(ptr %s26)
  store i64 %t1286, ptr %rv
  br label %ret
bb238:
  br label %bb239
bb239:
  %t1288 = load ptr, ptr %l2, !tbaa !29
  %t1289 = load i32, ptr %l3, !tbaa !23
  %t1292 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePayloadSize(ptr %v0, ptr %t1288, i32 %t1289)
  store i64 %t1292, ptr %l530
  br label %bb240
bb240:
  %t1293 = load i64, ptr %l530, !tbaa !24
  %t1294 = sdiv i64 %t1293, 8
  store i64 %t1294, ptr %l47, !tbaa !24
  %t1296 = load ptr, ptr %l0, !tbaa !29
  %t1298 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgNew(ptr %v0, ptr %t1296)
  store i64 %t1298, ptr %l533
  br label %bb241
bb241:
  %t1299 = load i64, ptr %l533, !tbaa !24
  store i64 %t1299, ptr %l48, !tbaa !24
  %t1300 = load ptr, ptr %l0, !tbaa !29
  %t1302 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgNew(ptr %v0, ptr %t1300)
  store i64 %t1302, ptr %l535
  br label %bb242
bb242:
  %t1303 = load i64, ptr %l535, !tbaa !24
  store i64 %t1303, ptr %l49, !tbaa !24
  %t1304 = load ptr, ptr %l0, !tbaa !29
  %t1305 = load i64, ptr %l49, !tbaa !24
  %t1306 = load i64, ptr %l47, !tbaa !24
  %t1307 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d79, i32 0, i32 1) }, 1
  %t1308 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d79, i32 0, i32 1) }, 0
  %t1310 = call i64 @__olang_fmt_i64(ptr null, i64 %t1306)
  %t1311 = add i64 %t1308, %t1310
  %t1312 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d80, i32 0, i32 1) }, 1
  %t1313 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d80, i32 0, i32 1) }, 0
  %t1314 = add i64 %t1311, %t1313
  %t1315 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t1314)
  call void @olang_textcopy(ptr %t1315, ptr %t1307, i64 %t1308)
  %t1316 = getelementptr i8, ptr %t1315, i64 %t1308
  %t1317 = call i64 @__olang_fmt_i64(ptr %t1316, i64 %t1306)
  %t1318 = getelementptr i8, ptr %t1316, i64 %t1310
  call void @olang_textcopy(ptr %t1318, ptr %t1312, i64 %t1313)
  %t1319 = insertvalue { i64, ptr } undef, i64 %t1314, 0
  %t1320 = insertvalue { i64, ptr } %t1319, ptr %t1315, 1
  %t1322 = extractvalue { i64, ptr } %t1320, 0
  %t1323 = extractvalue { i64, ptr } %t1320, 1
  %t1324 = mul i64 %t1322, 1
  %t1325 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t1324)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1325, ptr %t1323, i64 %t1324, i1 false)
  %t1326 = insertvalue { i64, ptr } undef, i64 %t1322, 0
  %t1327 = insertvalue { i64, ptr } %t1326, ptr %t1325, 1
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgShared(ptr %v0, ptr %s26, ptr %t1304, i64 %t1305, { i64, ptr } %t1327)
  br label %bb243
bb243:
  %t1331 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1331, ptr %l541, !tbaa !29
  %t1332 = load i64, ptr %l48, !tbaa !24
  store i64 %t1332, ptr %l542, !tbaa !24
  %t1333 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1333, ptr %l543, !tbaa !29
  %t1334 = load ptr, ptr %l2, !tbaa !29
  %t1336 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s26, ptr %t1334, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d81, i32 0, i32 1) })
  store i32 %t1336, ptr %l545
  br label %bb244
bb244:
  %t1337 = load ptr, ptr %l543, !tbaa !29
  %t1338 = load i32, ptr %l545, !tbaa !23
  %t1339 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgType(ptr %v0, ptr %t1337, i32 %t1338)
  store i64 %t1339, ptr %l546
  br label %bb245
bb245:
  %t1340 = load i64, ptr %l47, !tbaa !24
  %t1342 = mul i64 %t1340, 64
  %t1343 = load i64, ptr %l49, !tbaa !24
  %t1344 = extractvalue { i64, ptr } { i64 52, ptr getelementptr inbounds (<{ i64, [52 x i8] }>, ptr @.d82, i32 0, i32 1) }, 1
  %t1345 = extractvalue { i64, ptr } { i64 52, ptr getelementptr inbounds (<{ i64, [52 x i8] }>, ptr @.d82, i32 0, i32 1) }, 0
  %t1346 = load i64, ptr %l546, !tbaa !24
  %t1347 = call i64 @__olang_fmt_i64(ptr null, i64 %t1346)
  %t1348 = add i64 %t1345, %t1347
  %t1349 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d83, i32 0, i32 1) }, 1
  %t1350 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d83, i32 0, i32 1) }, 0
  %t1351 = add i64 %t1348, %t1350
  %t1353 = call i64 @__olang_fmt_i64(ptr null, i64 %t1342)
  %t1354 = add i64 %t1351, %t1353
  %t1355 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d84, i32 0, i32 1) }, 1
  %t1356 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d84, i32 0, i32 1) }, 0
  %t1357 = add i64 %t1354, %t1356
  %t1359 = call i64 @__olang_fmt_i64(ptr null, i64 %t1343)
  %t1360 = add i64 %t1357, %t1359
  %t1361 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d85, i32 0, i32 1) }, 1
  %t1362 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d85, i32 0, i32 1) }, 0
  %t1363 = add i64 %t1360, %t1362
  %t1364 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t1363)
  call void @olang_textcopy(ptr %t1364, ptr %t1344, i64 %t1345)
  %t1365 = getelementptr i8, ptr %t1364, i64 %t1345
  %t1366 = call i64 @__olang_fmt_i64(ptr %t1365, i64 %t1346)
  %t1367 = getelementptr i8, ptr %t1365, i64 %t1347
  call void @olang_textcopy(ptr %t1367, ptr %t1349, i64 %t1350)
  %t1368 = getelementptr i8, ptr %t1367, i64 %t1350
  %t1369 = call i64 @__olang_fmt_i64(ptr %t1368, i64 %t1342)
  %t1370 = getelementptr i8, ptr %t1368, i64 %t1353
  call void @olang_textcopy(ptr %t1370, ptr %t1355, i64 %t1356)
  %t1371 = getelementptr i8, ptr %t1370, i64 %t1356
  %t1372 = call i64 @__olang_fmt_i64(ptr %t1371, i64 %t1343)
  %t1373 = getelementptr i8, ptr %t1371, i64 %t1359
  call void @olang_textcopy(ptr %t1373, ptr %t1361, i64 %t1362)
  %t1374 = insertvalue { i64, ptr } undef, i64 %t1363, 0
  %t1375 = insertvalue { i64, ptr } %t1374, ptr %t1364, 1
  %t1377 = extractvalue { i64, ptr } %t1375, 0
  %t1378 = extractvalue { i64, ptr } %t1375, 1
  %t1379 = mul i64 %t1377, 1
  %t1380 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t1379)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1380, ptr %t1378, i64 %t1379, i1 false)
  %t1381 = insertvalue { i64, ptr } undef, i64 %t1377, 0
  %t1382 = insertvalue { i64, ptr } %t1381, ptr %t1380, 1
  %t1383 = load ptr, ptr %l541, !tbaa !29
  %t1384 = load i64, ptr %l542, !tbaa !24
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgShared(ptr %v0, ptr %s26, ptr %t1383, i64 %t1384, { i64, ptr } %t1382)
  br label %bb246
bb246:
  %t1386 = load ptr, ptr %l0, !tbaa !29
  %t1388 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgNew(ptr %v0, ptr %t1386)
  store i64 %t1388, ptr %l553
  br label %bb247
bb247:
  %t1389 = load i64, ptr %l553, !tbaa !24
  store i64 %t1389, ptr %l50, !tbaa !24
  %t1390 = load ptr, ptr %l0, !tbaa !29
  %t1392 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgNew(ptr %v0, ptr %t1390)
  store i64 %t1392, ptr %l555
  br label %bb248
bb248:
  %t1393 = load i64, ptr %l555, !tbaa !24
  store i64 %t1393, ptr %l51, !tbaa !24
  %t1394 = load ptr, ptr %l0, !tbaa !29
  %t1396 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgNew(ptr %v0, ptr %t1394)
  store i64 %t1396, ptr %l557
  br label %bb249
bb249:
  %t1397 = load i64, ptr %l557, !tbaa !24
  store i64 %t1397, ptr %l52, !tbaa !24
  %t1398 = load ptr, ptr %l0, !tbaa !29
  %t1399 = load i64, ptr %l50, !tbaa !24
  %t1400 = load i64, ptr %l45, !tbaa !24
  %t1401 = extractvalue { i64, ptr } { i64 60, ptr getelementptr inbounds (<{ i64, [60 x i8] }>, ptr @.d86, i32 0, i32 1) }, 1
  %t1402 = extractvalue { i64, ptr } { i64 60, ptr getelementptr inbounds (<{ i64, [60 x i8] }>, ptr @.d86, i32 0, i32 1) }, 0
  %t1404 = call i64 @__olang_fmt_i64(ptr null, i64 %t1400)
  %t1405 = add i64 %t1402, %t1404
  %t1406 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d87, i32 0, i32 1) }, 1
  %t1407 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d87, i32 0, i32 1) }, 0
  %t1408 = add i64 %t1405, %t1407
  %t1409 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t1408)
  call void @olang_textcopy(ptr %t1409, ptr %t1401, i64 %t1402)
  %t1410 = getelementptr i8, ptr %t1409, i64 %t1402
  %t1411 = call i64 @__olang_fmt_i64(ptr %t1410, i64 %t1400)
  %t1412 = getelementptr i8, ptr %t1410, i64 %t1404
  call void @olang_textcopy(ptr %t1412, ptr %t1406, i64 %t1407)
  %t1413 = insertvalue { i64, ptr } undef, i64 %t1408, 0
  %t1414 = insertvalue { i64, ptr } %t1413, ptr %t1409, 1
  %t1416 = extractvalue { i64, ptr } %t1414, 0
  %t1417 = extractvalue { i64, ptr } %t1414, 1
  %t1418 = mul i64 %t1416, 1
  %t1419 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t1418)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1419, ptr %t1417, i64 %t1418, i1 false)
  %t1420 = insertvalue { i64, ptr } undef, i64 %t1416, 0
  %t1421 = insertvalue { i64, ptr } %t1420, ptr %t1419, 1
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgShared(ptr %v0, ptr %s26, ptr %t1398, i64 %t1399, { i64, ptr } %t1421)
  br label %bb250
bb250:
  %t1425 = load ptr, ptr %l0, !tbaa !29
  %t1426 = load i64, ptr %l51, !tbaa !24
  %t1427 = load i64, ptr %l48, !tbaa !24
  %t1428 = load i64, ptr %l47, !tbaa !24
  %t1430 = mul i64 %t1428, 64
  %t1431 = extractvalue { i64, ptr } { i64 63, ptr getelementptr inbounds (<{ i64, [63 x i8] }>, ptr @.d88, i32 0, i32 1) }, 1
  %t1432 = extractvalue { i64, ptr } { i64 63, ptr getelementptr inbounds (<{ i64, [63 x i8] }>, ptr @.d88, i32 0, i32 1) }, 0
  %t1434 = call i64 @__olang_fmt_i64(ptr null, i64 %t1427)
  %t1435 = add i64 %t1432, %t1434
  %t1436 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d89, i32 0, i32 1) }, 1
  %t1437 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d89, i32 0, i32 1) }, 0
  %t1438 = add i64 %t1435, %t1437
  %t1440 = call i64 @__olang_fmt_i64(ptr null, i64 %t1430)
  %t1441 = add i64 %t1438, %t1440
  %t1442 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d90, i32 0, i32 1) }, 1
  %t1443 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d90, i32 0, i32 1) }, 0
  %t1444 = add i64 %t1441, %t1443
  %t1445 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t1444)
  call void @olang_textcopy(ptr %t1445, ptr %t1431, i64 %t1432)
  %t1446 = getelementptr i8, ptr %t1445, i64 %t1432
  %t1447 = call i64 @__olang_fmt_i64(ptr %t1446, i64 %t1427)
  %t1448 = getelementptr i8, ptr %t1446, i64 %t1434
  call void @olang_textcopy(ptr %t1448, ptr %t1436, i64 %t1437)
  %t1449 = getelementptr i8, ptr %t1448, i64 %t1437
  %t1450 = call i64 @__olang_fmt_i64(ptr %t1449, i64 %t1430)
  %t1451 = getelementptr i8, ptr %t1449, i64 %t1440
  call void @olang_textcopy(ptr %t1451, ptr %t1442, i64 %t1443)
  %t1452 = insertvalue { i64, ptr } undef, i64 %t1444, 0
  %t1453 = insertvalue { i64, ptr } %t1452, ptr %t1445, 1
  %t1455 = extractvalue { i64, ptr } %t1453, 0
  %t1456 = extractvalue { i64, ptr } %t1453, 1
  %t1457 = mul i64 %t1455, 1
  %t1458 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t1457)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1458, ptr %t1456, i64 %t1457, i1 false)
  %t1459 = insertvalue { i64, ptr } undef, i64 %t1455, 0
  %t1460 = insertvalue { i64, ptr } %t1459, ptr %t1458, 1
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgShared(ptr %v0, ptr %s26, ptr %t1425, i64 %t1426, { i64, ptr } %t1460)
  br label %bb251
bb251:
  %t1464 = load ptr, ptr %l0, !tbaa !29
  %t1465 = load i64, ptr %l52, !tbaa !24
  %t1466 = load i64, ptr %l50, !tbaa !24
  %t1467 = load i64, ptr %l51, !tbaa !24
  %t1468 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d91, i32 0, i32 1) }, 1
  %t1469 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d91, i32 0, i32 1) }, 0
  %t1471 = call i64 @__olang_fmt_i64(ptr null, i64 %t1466)
  %t1472 = add i64 %t1469, %t1471
  %t1473 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d92, i32 0, i32 1) }, 1
  %t1474 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d92, i32 0, i32 1) }, 0
  %t1475 = add i64 %t1472, %t1474
  %t1477 = call i64 @__olang_fmt_i64(ptr null, i64 %t1467)
  %t1478 = add i64 %t1475, %t1477
  %t1479 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d93, i32 0, i32 1) }, 1
  %t1480 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d93, i32 0, i32 1) }, 0
  %t1481 = add i64 %t1478, %t1480
  %t1482 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t1481)
  call void @olang_textcopy(ptr %t1482, ptr %t1468, i64 %t1469)
  %t1483 = getelementptr i8, ptr %t1482, i64 %t1469
  %t1484 = call i64 @__olang_fmt_i64(ptr %t1483, i64 %t1466)
  %t1485 = getelementptr i8, ptr %t1483, i64 %t1471
  call void @olang_textcopy(ptr %t1485, ptr %t1473, i64 %t1474)
  %t1486 = getelementptr i8, ptr %t1485, i64 %t1474
  %t1487 = call i64 @__olang_fmt_i64(ptr %t1486, i64 %t1467)
  %t1488 = getelementptr i8, ptr %t1486, i64 %t1477
  call void @olang_textcopy(ptr %t1488, ptr %t1479, i64 %t1480)
  %t1489 = insertvalue { i64, ptr } undef, i64 %t1481, 0
  %t1490 = insertvalue { i64, ptr } %t1489, ptr %t1482, 1
  %t1492 = extractvalue { i64, ptr } %t1490, 0
  %t1493 = extractvalue { i64, ptr } %t1490, 1
  %t1494 = mul i64 %t1492, 1
  %t1495 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t1494)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1495, ptr %t1493, i64 %t1494, i1 false)
  %t1496 = insertvalue { i64, ptr } undef, i64 %t1492, 0
  %t1497 = insertvalue { i64, ptr } %t1496, ptr %t1495, 1
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgShared(ptr %v0, ptr %s26, ptr %t1464, i64 %t1465, { i64, ptr } %t1497)
  br label %bb252
bb252:
  %t1501 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1501, ptr %l576, !tbaa !29
  %t1502 = load i64, ptr %l31, !tbaa !24
  store i64 %t1502, ptr %l577, !tbaa !24
  %t1503 = load ptr, ptr %l0, !tbaa !29
  %t1504 = load i32, ptr %l3, !tbaa !23
  %t1507 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgTypeName(ptr %v0, ptr %s26, ptr %t1503, i32 %t1504)
  store { i64, ptr } %t1507, ptr %l580
  br label %bb253
bb253:
  %t1508 = load { i64, ptr }, ptr %l580, !tbaa !27
  %t1509 = extractvalue { i64, ptr } %t1508, 0
  %t1510 = extractvalue { i64, ptr } %t1508, 1
  %t1511 = mul i64 %t1509, 1
  %t1512 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t1511)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1512, ptr %t1510, i64 %t1511, i1 false)
  %t1513 = insertvalue { i64, ptr } undef, i64 %t1509, 0
  %t1514 = insertvalue { i64, ptr } %t1513, ptr %t1512, 1
  %t1516 = call { i64, ptr } @compiler_2femit_2eescape(ptr %s26, ptr %s26, { i64, ptr } %t1514)
  store { i64, ptr } %t1516, ptr %l582
  br label %bb254
bb254:
  %t1517 = load i64, ptr %l11, !tbaa !24
  %t1518 = load i64, ptr %l52, !tbaa !24
  %t1519 = extractvalue { i64, ptr } { i64 52, ptr getelementptr inbounds (<{ i64, [52 x i8] }>, ptr @.d94, i32 0, i32 1) }, 1
  %t1520 = extractvalue { i64, ptr } { i64 52, ptr getelementptr inbounds (<{ i64, [52 x i8] }>, ptr @.d94, i32 0, i32 1) }, 0
  %t1521 = load { i64, ptr }, ptr %l582, !tbaa !27
  %t1522 = extractvalue { i64, ptr } %t1521, 1
  %t1523 = extractvalue { i64, ptr } %t1521, 0
  %t1524 = add i64 %t1520, %t1523
  %t1525 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d95, i32 0, i32 1) }, 1
  %t1526 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d95, i32 0, i32 1) }, 0
  %t1527 = add i64 %t1524, %t1526
  %t1529 = call i64 @__olang_fmt_i64(ptr null, i64 %t1517)
  %t1530 = add i64 %t1527, %t1529
  %t1531 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d96, i32 0, i32 1) }, 1
  %t1532 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d96, i32 0, i32 1) }, 0
  %t1533 = add i64 %t1530, %t1532
  %t1535 = call i64 @__olang_fmt_i64(ptr null, i64 %t1518)
  %t1536 = add i64 %t1533, %t1535
  %t1537 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d97, i32 0, i32 1) }, 1
  %t1538 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d97, i32 0, i32 1) }, 0
  %t1539 = add i64 %t1536, %t1538
  %t1540 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t1539)
  call void @olang_textcopy(ptr %t1540, ptr %t1519, i64 %t1520)
  %t1541 = getelementptr i8, ptr %t1540, i64 %t1520
  call void @olang_textcopy(ptr %t1541, ptr %t1522, i64 %t1523)
  %t1542 = getelementptr i8, ptr %t1541, i64 %t1523
  call void @olang_textcopy(ptr %t1542, ptr %t1525, i64 %t1526)
  %t1543 = getelementptr i8, ptr %t1542, i64 %t1526
  %t1544 = call i64 @__olang_fmt_i64(ptr %t1543, i64 %t1517)
  %t1545 = getelementptr i8, ptr %t1543, i64 %t1529
  call void @olang_textcopy(ptr %t1545, ptr %t1531, i64 %t1532)
  %t1546 = getelementptr i8, ptr %t1545, i64 %t1532
  %t1547 = call i64 @__olang_fmt_i64(ptr %t1546, i64 %t1518)
  %t1548 = getelementptr i8, ptr %t1546, i64 %t1535
  call void @olang_textcopy(ptr %t1548, ptr %t1537, i64 %t1538)
  %t1549 = insertvalue { i64, ptr } undef, i64 %t1539, 0
  %t1550 = insertvalue { i64, ptr } %t1549, ptr %t1540, 1
  %t1552 = extractvalue { i64, ptr } %t1550, 0
  %t1553 = extractvalue { i64, ptr } %t1550, 1
  %t1554 = mul i64 %t1552, 1
  %t1555 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t1554)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1555, ptr %t1553, i64 %t1554, i1 false)
  %t1556 = insertvalue { i64, ptr } undef, i64 %t1552, 0
  %t1557 = insertvalue { i64, ptr } %t1556, ptr %t1555, 1
  %t1558 = load ptr, ptr %l576, !tbaa !29
  %t1559 = load i64, ptr %l577, !tbaa !24
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgShared(ptr %v0, ptr %s26, ptr %t1558, i64 %t1559, { i64, ptr } %t1557)
  br label %bb255
bb255:
  %t1561 = load i64, ptr %l31, !tbaa !24
  call void @__olang_scope_close(ptr %s26)
  store i64 %t1561, ptr %rv
  br label %ret
bb256:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eentry(ptr %v0, ptr %v1, ptr %a0, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca %"std/prelude/text:StringBuilder"
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca { i64, [2 x i64] }
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i32
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca { i64, ptr }
  %l34 = alloca %"std/prelude/text:StringBuilder"
  %l42 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l44 = alloca i64
  %l46 = alloca i64
  %l51 = alloca i64
  %l55 = alloca i1
  %l57 = alloca ptr
  %l63 = alloca { i64, ptr }
  %l76 = alloca ptr
  %l79 = alloca ptr
  %l82 = alloca i32
  %l83 = alloca { i64, ptr }
  %l87 = alloca ptr
  %l90 = alloca { i64, ptr }
  %l93 = alloca ptr
  %l97 = alloca i64
  %l99 = alloca { i64, ptr }
  %l100 = alloca ptr
  %l103 = alloca { i64, ptr }
  %l110 = alloca { i64, ptr }
  %l111 = alloca { i64, ptr }
  %l112 = alloca i64
  %l113 = alloca { i64, ptr }
  %l114 = alloca ptr
  %l116 = alloca { i64, ptr }
  %l124 = alloca i64
  %l127 = alloca i64
  %l146 = alloca { i64, ptr }
  %l149 = alloca i32
  %l151 = alloca ptr
  %l154 = alloca i32
  %l155 = alloca { i64, ptr }
  %l161 = alloca i64
  %l164 = alloca i64
  %l191 = alloca { i64, ptr }
  %l193 = alloca { i64, ptr }
  %l196 = alloca { i64, ptr }
  %l203 = alloca ptr
  %l204 = alloca i64
  %l205 = alloca i64
  %l208 = alloca { i64, ptr }
  %l213 = alloca { i64, ptr }
  %l215 = alloca i64
  %l226 = alloca i1
  %l231 = alloca ptr
  %l235 = alloca i64
  %l237 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %t59 = alloca { i64, [2 x i64] }, align 8
  %t99 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edefine(ptr %v0, ptr %s0, ptr %s0, ptr %t6, { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d98, i32 0, i32 1) }, { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d99, i32 0, i32 1) })
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edefine(ptr %v0, ptr %s0, ptr %s0, ptr %t8, { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d100, i32 0, i32 1) }, { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d101, i32 0, i32 1) })
  br label %bb2
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %s0, ptr %t10, { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d102, i32 0, i32 1) })
  br label %bb3
bb3:
  %t12 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t12, ptr %l34
  br label %bb4
bb4:
  %t13 = load %"std/prelude/text:StringBuilder", ptr %l34
  store %"std/prelude/text:StringBuilder" %t13, ptr %l4
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l4, { i64, ptr } { i64 51, ptr getelementptr inbounds (<{ i64, [51 x i8] }>, ptr @.d103, i32 0, i32 1) })
  br label %bb5
bb5:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l4, { i64, ptr } { i64 74, ptr getelementptr inbounds (<{ i64, [74 x i8] }>, ptr @.d104, i32 0, i32 1) })
  br label %bb6
bb6:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l4, { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d105, i32 0, i32 1) })
  br label %bb7
bb7:
  %t17 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2esanInit(ptr %v0, ptr %s0, ptr %t17, ptr %l4)
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s1
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t24 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2femit_2ecompiler_2femit_3aEmitter_2eglobalOrder(ptr %v0, ptr %v1, ptr %s1, ptr %t20, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %a1)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t24, ptr %l42
  br label %bb9
bb9:
  %t25 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l42
  %t26 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 8, i64 8)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t25, ptr %t26
  store ptr %t26, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb10
bb10:
  %t28 = load i64, ptr %l6, !tbaa !24
  store i64 %t28, ptr %l44, !tbaa !24
  %t29 = load ptr, ptr %l5, !tbaa !29
  %t31 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s1, ptr %t29)
  store i64 %t31, ptr %l46
  br label %bb11
bb11:
  %t32 = load i64, ptr %l44, !tbaa !24
  %t33 = load i64, ptr %l46, !tbaa !24
  %t34 = icmp slt i64 %t32, %t33
  %t36 = xor i1 %t34, true
  br i1 %t36, label %bb12, label %bb13
bb12:
  br label %bb23
bb13:
  br label %bb14
bb14:
  %t38 = load ptr, ptr %l5, !tbaa !29
  %t39 = load i64, ptr %l6, !tbaa !24
  %t42 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s1, ptr %t38, i64 %t39)
  store i64 %t42, ptr %l51
  br label %bb15
bb15:
  %t43 = load i64, ptr %l51, !tbaa !24
  store i64 %t43, ptr %l7, !tbaa !24
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/emit:Emitter", ptr %t44, i32 0, i32 44
  %t47 = load i64, ptr %l7, !tbaa !24
  %t50 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2feval_3aImage_3e_2e_H901ad831a5883703dcf426ee01511832(ptr %v0, ptr %t46, i64 %t47)
  store i1 %t50, ptr %l55
  br label %bb16
bb16:
  %t51 = load i1, ptr %l55, !tbaa !21
  %t52 = xor i1 %t51, true
  br i1 %t52, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s3
  store ptr %l4, ptr %l57, !tbaa !29
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load i64, ptr %l7, !tbaa !24
  %t57 = trunc i64 %t55 to i32
  store { i64, [2 x i64] } zeroinitializer, ptr %t59
  %t60 = getelementptr { i64, [2 x i64] }, ptr %t59, i32 0, i32 0
  store i64 0, ptr %t60
  %t62 = insertvalue { i32 } undef, i32 %t57, 0
  %t63 = getelementptr { i64, [2 x i64] }, ptr %t59, i32 0, i32 1
  store { i32 } %t62, ptr %t63
  %t64 = load { i64, [2 x i64] }, ptr %t59
  %t67 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2esym(ptr %v0, ptr %s3, ptr %t54, { i64, [2 x i64] } %t64)
  store { i64, ptr } %t67, ptr %l63
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t68 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d106, i32 0, i32 1) }, 1
  %t69 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d106, i32 0, i32 1) }, 0
  %t70 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t71 = extractvalue { i64, ptr } %t70, 1
  %t72 = extractvalue { i64, ptr } %t70, 0
  %t73 = add i64 %t69, %t72
  %t74 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d107, i32 0, i32 1) }, 1
  %t75 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d107, i32 0, i32 1) }, 0
  %t76 = add i64 %t73, %t75
  %t77 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t76)
  call void @olang_textcopy(ptr %t77, ptr %t68, i64 %t69)
  %t78 = getelementptr i8, ptr %t77, i64 %t69
  call void @olang_textcopy(ptr %t78, ptr %t71, i64 %t72)
  %t79 = getelementptr i8, ptr %t78, i64 %t72
  call void @olang_textcopy(ptr %t79, ptr %t74, i64 %t75)
  %t80 = insertvalue { i64, ptr } undef, i64 %t76, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t77, 1
  %t83 = extractvalue { i64, ptr } %t81, 0
  %t84 = extractvalue { i64, ptr } %t81, 1
  %t85 = mul i64 %t83, 1
  %t86 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t85)
  call void @llvm.memcpy.p0.p0.i64(ptr %t86, ptr %t84, i64 %t85, i1 false)
  %t87 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t88 = insertvalue { i64, ptr } %t87, ptr %t86, 1
  %t89 = load ptr, ptr %l57, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s3, ptr %t89, { i64, ptr } %t88)
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s3)
  br label %bb21
bb21:
  br label %bb22
bb22:
  %t91 = load i64, ptr %l6, !tbaa !24
  %t93 = add i64 %t91, 1
  store i64 %t93, ptr %l6, !tbaa !24
  br label %bb10
bb23:
  call void @__olang_scope_close(ptr %s1)
  %t95 = load i64, ptr %l2, !tbaa !24
  %t97 = trunc i64 %t95 to i32
  store { i64, [2 x i64] } zeroinitializer, ptr %t99
  %t100 = getelementptr { i64, [2 x i64] }, ptr %t99, i32 0, i32 0
  store i64 0, ptr %t100
  %t102 = insertvalue { i32 } undef, i32 %t97, 0
  %t103 = getelementptr { i64, [2 x i64] }, ptr %t99, i32 0, i32 1
  store { i32 } %t102, ptr %t103
  %t104 = load { i64, [2 x i64] }, ptr %t99
  store { i64, [2 x i64] } %t104, ptr %l8
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = getelementptr %"compiler/emit:Emitter", ptr %t106, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !29
  %t111 = getelementptr %"compiler/lower:Lowerer", ptr %t109, i32 0, i32 1
  %t112 = load i64, ptr %l2, !tbaa !24
  %t115 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t111, i64 %t112)
  store ptr %t115, ptr %l76
  br label %bb24
bb24:
  %t116 = load ptr, ptr %l76, !tbaa !29
  %t118 = getelementptr %"compiler/typed:Body", ptr %t116, i32 0, i32 2
  %t119 = load i32, ptr %t118, !tbaa !23
  %t121 = load ptr, ptr %l3, !tbaa !29
  store ptr %t121, ptr %l79, !tbaa !29
  %t122 = load ptr, ptr %l3, !tbaa !29
  %t126 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t122, i32 %t119)
  store i32 %t126, ptr %l82
  br label %bb25
bb25:
  %t127 = load ptr, ptr %l79, !tbaa !29
  %t128 = load i32, ptr %l82, !tbaa !23
  %t129 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t127, i32 %t128)
  store { i64, ptr } %t129, ptr %l83
  br label %bb26
bb26:
  %t130 = load { i64, ptr }, ptr %l83, !tbaa !27
  store { i64, ptr } %t130, ptr %l10, !tbaa !27
  %t131 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t133 = extractvalue { i64, ptr } %t131, 0
  %t135 = icmp eq i64 %t133, 0
  br i1 %t135, label %bb27, label %bb28
bb27:
  store %olang.scope zeroinitializer, ptr %s6
  store ptr %l4, ptr %l87, !tbaa !29
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t138 = load { i64, [2 x i64] }, ptr %l8
  %t141 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2esym(ptr %v0, ptr %s6, ptr %t137, { i64, [2 x i64] } %t138)
  store { i64, ptr } %t141, ptr %l90
  br label %bb29
bb28:
  br label %bb33
bb29:
  %t142 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d108, i32 0, i32 1) }, 1
  %t143 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d108, i32 0, i32 1) }, 0
  %t144 = load { i64, ptr }, ptr %l90, !tbaa !27
  %t145 = extractvalue { i64, ptr } %t144, 1
  %t146 = extractvalue { i64, ptr } %t144, 0
  %t147 = add i64 %t143, %t146
  %t148 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d109, i32 0, i32 1) }, 1
  %t149 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d109, i32 0, i32 1) }, 0
  %t150 = add i64 %t147, %t149
  %t151 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t150)
  call void @olang_textcopy(ptr %t151, ptr %t142, i64 %t143)
  %t152 = getelementptr i8, ptr %t151, i64 %t143
  call void @olang_textcopy(ptr %t152, ptr %t145, i64 %t146)
  %t153 = getelementptr i8, ptr %t152, i64 %t146
  call void @olang_textcopy(ptr %t153, ptr %t148, i64 %t149)
  %t154 = insertvalue { i64, ptr } undef, i64 %t150, 0
  %t155 = insertvalue { i64, ptr } %t154, ptr %t151, 1
  %t157 = extractvalue { i64, ptr } %t155, 0
  %t158 = extractvalue { i64, ptr } %t155, 1
  %t159 = mul i64 %t157, 1
  %t160 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t159)
  call void @llvm.memcpy.p0.p0.i64(ptr %t160, ptr %t158, i64 %t159, i1 false)
  %t161 = insertvalue { i64, ptr } undef, i64 %t157, 0
  %t162 = insertvalue { i64, ptr } %t161, ptr %t160, 1
  %t163 = load ptr, ptr %l87, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s6, ptr %t163, { i64, ptr } %t162)
  br label %bb30
bb30:
  %t165 = load ptr, ptr %l0, !tbaa !29
  store ptr %t165, ptr %l93, !tbaa !29
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t168 = getelementptr %"compiler/emit:Emitter", ptr %t166, i32 0, i32 0
  %t169 = load ptr, ptr %t168, !tbaa !29
  %t171 = getelementptr %"compiler/generic:Program", ptr %t169, i32 0, i32 0
  %t172 = load ptr, ptr %t171, !tbaa !29
  %t174 = getelementptr %"compiler/load:Loader", ptr %t172, i32 0, i32 7
  %t175 = load i64, ptr %t174, !tbaa !24
  store i64 %t175, ptr %l97, !tbaa !24
  %t177 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s6, ptr %l4)
  store { i64, ptr } %t177, ptr %l99
  br label %bb31
bb31:
  %t178 = load ptr, ptr %l93, !tbaa !29
  %t179 = load i64, ptr %l97, !tbaa !24
  %t180 = load { i64, ptr }, ptr %l99, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eitem(ptr %v0, ptr %s6, ptr %s6, ptr %s6, ptr %t178, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d110, i32 0, i32 1) }, i64 %t179, { i64, ptr } %t180, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d8, i32 0, i32 1) })
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb33:
  store ptr %l4, ptr %l100, !tbaa !29
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t182 = load { i64, [2 x i64] }, ptr %l8
  %t185 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2esym(ptr %v0, ptr %s0, ptr %t181, { i64, [2 x i64] } %t182)
  store { i64, ptr } %t185, ptr %l103
  br label %bb34
bb34:
  %t186 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d111, i32 0, i32 1) }, 1
  %t187 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d111, i32 0, i32 1) }, 0
  %t188 = load { i64, ptr }, ptr %l103, !tbaa !27
  %t189 = extractvalue { i64, ptr } %t188, 1
  %t190 = extractvalue { i64, ptr } %t188, 0
  %t191 = add i64 %t187, %t190
  %t192 = extractvalue { i64, ptr } { i64 82, ptr getelementptr inbounds (<{ i64, [82 x i8] }>, ptr @.d112, i32 0, i32 1) }, 1
  %t193 = extractvalue { i64, ptr } { i64 82, ptr getelementptr inbounds (<{ i64, [82 x i8] }>, ptr @.d112, i32 0, i32 1) }, 0
  %t194 = add i64 %t191, %t193
  %t195 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t194)
  call void @olang_textcopy(ptr %t195, ptr %t186, i64 %t187)
  %t196 = getelementptr i8, ptr %t195, i64 %t187
  call void @olang_textcopy(ptr %t196, ptr %t189, i64 %t190)
  %t197 = getelementptr i8, ptr %t196, i64 %t190
  call void @olang_textcopy(ptr %t197, ptr %t192, i64 %t193)
  %t198 = insertvalue { i64, ptr } undef, i64 %t194, 0
  %t199 = insertvalue { i64, ptr } %t198, ptr %t195, 1
  %t201 = extractvalue { i64, ptr } %t199, 0
  %t202 = extractvalue { i64, ptr } %t199, 1
  %t203 = mul i64 %t201, 1
  %t204 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t203)
  call void @llvm.memcpy.p0.p0.i64(ptr %t204, ptr %t202, i64 %t203, i1 false)
  %t205 = insertvalue { i64, ptr } undef, i64 %t201, 0
  %t206 = insertvalue { i64, ptr } %t205, ptr %t204, 1
  %t207 = load ptr, ptr %l100, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t207, { i64, ptr } %t206)
  br label %bb35
bb35:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l4, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d113, i32 0, i32 1) })
  br label %bb36
bb36:
  %t210 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s0, ptr %s0, ptr %t210, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d114, i32 0, i32 1) }, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d115, i32 0, i32 1) })
  br label %bb37
bb37:
  %t212 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edefine(ptr %v0, ptr %s0, ptr %s0, ptr %t212, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d116, i32 0, i32 1) }, { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d117, i32 0, i32 1) })
  br label %bb38
bb38:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l4, { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d118, i32 0, i32 1) })
  br label %bb39
bb39:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d119, i32 0, i32 1) }, ptr %l110, !tbaa !27
  %t215 = load { i64, ptr }, ptr %l110, !tbaa !27
  store { i64, ptr } %t215, ptr %l111, !tbaa !27
  %t216 = load { i64, ptr }, ptr %l111, !tbaa !27
  %t217 = extractvalue { i64, ptr } %t216, 0
  store i64 %t217, ptr %l112, !tbaa !24
  %t218 = load i64, ptr %l112, !tbaa !24
  %t219 = mul i64 %t218, 1
  %t220 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t219)
  %t221 = insertvalue { i64, ptr } undef, i64 %t218, 0
  %t222 = insertvalue { i64, ptr } %t221, ptr %t220, 1
  store { i64, ptr } %t222, ptr %l113, !tbaa !27
  %t223 = getelementptr { i64, ptr }, ptr %l113, i32 0, i32 1
  %t224 = load ptr, ptr %t223, !tbaa !27
  %t225 = getelementptr { i64, ptr }, ptr %l111, i32 0, i32 1
  %t226 = load ptr, ptr %t225, !tbaa !27
  %t227 = load i64, ptr %l112, !tbaa !24
  %t228 = mul i64 %t227, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t224, ptr %t226, i64 %t228, i1 false)
  %t229 = load { i64, ptr }, ptr %l113, !tbaa !27
  store { i64, ptr } %t229, ptr %l11, !tbaa !27
  store ptr %l4, ptr %l114, !tbaa !29
  %t230 = load ptr, ptr %l0, !tbaa !29
  %t232 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecstr(ptr %v0, ptr %s0, ptr %s0, ptr %t230, { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d120, i32 0, i32 1) })
  store { i64, ptr } %t232, ptr %l116
  br label %bb40
bb40:
  %t233 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d121, i32 0, i32 1) }, 1
  %t234 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d121, i32 0, i32 1) }, 0
  %t235 = load { i64, ptr }, ptr %l116, !tbaa !27
  %t236 = extractvalue { i64, ptr } %t235, 1
  %t237 = extractvalue { i64, ptr } %t235, 0
  %t238 = add i64 %t234, %t237
  %t239 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d122, i32 0, i32 1) }, 1
  %t240 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d122, i32 0, i32 1) }, 0
  %t241 = add i64 %t238, %t240
  %t242 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t241)
  call void @olang_textcopy(ptr %t242, ptr %t233, i64 %t234)
  %t243 = getelementptr i8, ptr %t242, i64 %t234
  call void @olang_textcopy(ptr %t243, ptr %t236, i64 %t237)
  %t244 = getelementptr i8, ptr %t243, i64 %t237
  call void @olang_textcopy(ptr %t244, ptr %t239, i64 %t240)
  %t245 = insertvalue { i64, ptr } undef, i64 %t241, 0
  %t246 = insertvalue { i64, ptr } %t245, ptr %t242, 1
  %t248 = extractvalue { i64, ptr } %t246, 0
  %t249 = extractvalue { i64, ptr } %t246, 1
  %t250 = mul i64 %t248, 1
  %t251 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t250)
  call void @llvm.memcpy.p0.p0.i64(ptr %t251, ptr %t249, i64 %t250, i1 false)
  %t252 = insertvalue { i64, ptr } undef, i64 %t248, 0
  %t253 = insertvalue { i64, ptr } %t252, ptr %t251, 1
  %t254 = load ptr, ptr %l114, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t254, { i64, ptr } %t253)
  br label %bb41
bb41:
  store i64 0, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  %t256 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t258 = extractvalue { i64, ptr } %t256, 0
  store i64 %t258, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t260 = load i64, ptr %l14, !tbaa !24
  %t261 = load i64, ptr %l13, !tbaa !24
  %t264 = icmp sgt i64 %t260, %t261
  br i1 %t264, label %bb42, label %bb43
bb42:
  %t266 = load i64, ptr %l15, !tbaa !24
  %t268 = icmp sgt i64 %t266, 0
  br i1 %t268, label %bb44, label %bb45
bb43:
  store i64 0, ptr %l124, !tbaa !24
  br label %bb47
bb44:
  %t270 = load i64, ptr %l14, !tbaa !24
  %t271 = load i64, ptr %l13, !tbaa !24
  %t274 = sub i64 %t270, %t271
  %t275 = load i64, ptr %l15, !tbaa !24
  %t278 = add i64 %t274, %t275
  %t280 = sub i64 %t278, 1
  %t281 = load i64, ptr %l15, !tbaa !24
  %t284 = sdiv i64 %t280, %t281
  store i64 %t284, ptr %l127, !tbaa !24
  br label %bb46
bb45:
  store i64 0, ptr %l127, !tbaa !24
  br label %bb46
bb46:
  %t286 = load i64, ptr %l127, !tbaa !24
  store i64 %t286, ptr %l124, !tbaa !24
  br label %bb47
bb47:
  %t287 = load i64, ptr %l124, !tbaa !24
  store i64 %t287, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb48
bb48:
  %t288 = load i64, ptr %l17, !tbaa !24
  %t289 = load i64, ptr %l16, !tbaa !24
  %t292 = icmp slt i64 %t288, %t289
  %t294 = xor i1 %t292, true
  br i1 %t294, label %bb49, label %bb50
bb49:
  br label %bb76
bb50:
  br label %bb51
bb51:
  %t296 = load i64, ptr %l13, !tbaa !24
  %t297 = load i64, ptr %l17, !tbaa !24
  %t298 = load i64, ptr %l15, !tbaa !24
  %t301 = mul i64 %t297, %t298
  %t304 = add i64 %t296, %t301
  store i64 %t304, ptr %l18, !tbaa !24
  %t306 = load ptr, ptr %l3, !tbaa !29
  %t307 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t307, ptr %l146, !tbaa !27
  %t308 = load i64, ptr %l18, !tbaa !24
  %t310 = getelementptr { i64, ptr }, ptr %l146, i32 0, i32 1
  %t311 = load ptr, ptr %t310, !tbaa !27
  %t312 = getelementptr i32, ptr %t311, i64 %t308
  %t313 = load i32, ptr %t312, !tbaa !33
  %t316 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t306, i32 %t313)
  store i32 %t316, ptr %l149
  br label %bb52
bb52:
  %t317 = load i32, ptr %l149, !tbaa !23
  store i32 %t317, ptr %l19, !tbaa !23
  %t318 = load ptr, ptr %l0, !tbaa !29
  %t320 = getelementptr %"compiler/emit:Emitter", ptr %t318, i32 0, i32 0
  %t321 = load ptr, ptr %t320, !tbaa !29
  store ptr %t321, ptr %l151, !tbaa !29
  %t322 = load ptr, ptr %l3, !tbaa !29
  %t323 = load i32, ptr %l19, !tbaa !23
  %t326 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t322, i32 %t323)
  store i32 %t326, ptr %l154
  br label %bb53
bb53:
  %t327 = load ptr, ptr %l151, !tbaa !29
  %t328 = load i32, ptr %l154, !tbaa !23
  %t329 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorWords(ptr %v0, ptr %t327, i32 %t328)
  store { i64, ptr } %t329, ptr %l155
  br label %bb54
bb54:
  %t330 = load { i64, ptr }, ptr %l155, !tbaa !27
  store { i64, ptr } %t330, ptr %l20, !tbaa !27
  store i64 0, ptr %l21, !tbaa !24
  %t331 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t333 = extractvalue { i64, ptr } %t331, 0
  store i64 %t333, ptr %l22, !tbaa !24
  store i64 1, ptr %l23, !tbaa !24
  %t335 = load i64, ptr %l22, !tbaa !24
  %t336 = load i64, ptr %l21, !tbaa !24
  %t339 = icmp sgt i64 %t335, %t336
  br i1 %t339, label %bb55, label %bb56
bb55:
  %t341 = load i64, ptr %l23, !tbaa !24
  %t343 = icmp sgt i64 %t341, 0
  br i1 %t343, label %bb57, label %bb58
bb56:
  store i64 0, ptr %l161, !tbaa !24
  br label %bb60
bb57:
  %t345 = load i64, ptr %l22, !tbaa !24
  %t346 = load i64, ptr %l21, !tbaa !24
  %t349 = sub i64 %t345, %t346
  %t350 = load i64, ptr %l23, !tbaa !24
  %t353 = add i64 %t349, %t350
  %t355 = sub i64 %t353, 1
  %t356 = load i64, ptr %l23, !tbaa !24
  %t359 = sdiv i64 %t355, %t356
  store i64 %t359, ptr %l164, !tbaa !24
  br label %bb59
bb58:
  store i64 0, ptr %l164, !tbaa !24
  br label %bb59
bb59:
  %t361 = load i64, ptr %l164, !tbaa !24
  store i64 %t361, ptr %l161, !tbaa !24
  br label %bb60
bb60:
  %t362 = load i64, ptr %l161, !tbaa !24
  store i64 %t362, ptr %l24, !tbaa !24
  store i64 0, ptr %l25, !tbaa !24
  br label %bb61
bb61:
  store %olang.scope zeroinitializer, ptr %s13
  %t363 = load i64, ptr %l25, !tbaa !24
  %t364 = load i64, ptr %l24, !tbaa !24
  %t367 = icmp slt i64 %t363, %t364
  %t369 = xor i1 %t367, true
  br i1 %t369, label %bb62, label %bb63
bb62:
  call void @__olang_scope_close(ptr %s13)
  br label %bb74
bb63:
  br label %bb64
bb64:
  %t371 = load i64, ptr %l21, !tbaa !24
  %t372 = load i64, ptr %l25, !tbaa !24
  %t373 = load i64, ptr %l23, !tbaa !24
  %t376 = mul i64 %t372, %t373
  %t379 = add i64 %t371, %t376
  store i64 %t379, ptr %l26, !tbaa !24
  %t381 = load i64, ptr %l12, !tbaa !24
  %t383 = add i64 %t381, 1
  store i64 %t383, ptr %l12, !tbaa !24
  %t385 = load i64, ptr %l18, !tbaa !24
  %t387 = add i64 %t385, 1
  %t389 = shl i64 %t387, 16
  %t390 = load i64, ptr %l26, !tbaa !24
  %t393 = or i64 %t389, %t390
  store i64 %t393, ptr %l27, !tbaa !24
  %t395 = load ptr, ptr %l0, !tbaa !29
  %t396 = load i32, ptr %l19, !tbaa !23
  %t399 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eerrName(ptr %v0, ptr %s13, ptr %t395, i32 %t396)
  store { i64, ptr } %t399, ptr %l191
  br label %bb65
bb65:
  %t400 = load ptr, ptr %l0, !tbaa !29
  %t401 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t401, ptr %l193, !tbaa !27
  %t402 = load i64, ptr %l26, !tbaa !24
  %t404 = getelementptr { i64, ptr }, ptr %l193, i32 0, i32 1
  %t405 = load ptr, ptr %t404, !tbaa !27
  %t406 = getelementptr i32, ptr %t405, i64 %t402
  %t407 = load i32, ptr %t406, !tbaa !33
  %t410 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etext(ptr %v0, ptr %t400, i32 %t407)
  store { i64, ptr } %t410, ptr %l196
  br label %bb66
bb66:
  %t411 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d123, i32 0, i32 1) }, 1
  %t412 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d123, i32 0, i32 1) }, 0
  %t413 = load { i64, ptr }, ptr %l191, !tbaa !27
  %t414 = extractvalue { i64, ptr } %t413, 1
  %t415 = extractvalue { i64, ptr } %t413, 0
  %t416 = add i64 %t412, %t415
  %t417 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d124, i32 0, i32 1) }, 1
  %t418 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d124, i32 0, i32 1) }, 0
  %t419 = add i64 %t416, %t418
  %t420 = load { i64, ptr }, ptr %l196, !tbaa !27
  %t421 = extractvalue { i64, ptr } %t420, 1
  %t422 = extractvalue { i64, ptr } %t420, 0
  %t423 = add i64 %t419, %t422
  %t424 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d125, i32 0, i32 1) }, 1
  %t425 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d125, i32 0, i32 1) }, 0
  %t426 = add i64 %t423, %t425
  %t427 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t426)
  call void @olang_textcopy(ptr %t427, ptr %t411, i64 %t412)
  %t428 = getelementptr i8, ptr %t427, i64 %t412
  call void @olang_textcopy(ptr %t428, ptr %t414, i64 %t415)
  %t429 = getelementptr i8, ptr %t428, i64 %t415
  call void @olang_textcopy(ptr %t429, ptr %t417, i64 %t418)
  %t430 = getelementptr i8, ptr %t429, i64 %t418
  call void @olang_textcopy(ptr %t430, ptr %t421, i64 %t422)
  %t431 = getelementptr i8, ptr %t430, i64 %t422
  call void @olang_textcopy(ptr %t431, ptr %t424, i64 %t425)
  %t432 = insertvalue { i64, ptr } undef, i64 %t426, 0
  %t433 = insertvalue { i64, ptr } %t432, ptr %t427, 1
  store { i64, ptr } %t433, ptr %l28, !tbaa !27
  %t435 = load i64, ptr %l12, !tbaa !24
  %t436 = load i64, ptr %l27, !tbaa !24
  %t437 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d126, i32 0, i32 1) }, 1
  %t438 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d126, i32 0, i32 1) }, 0
  %t440 = call i64 @__olang_fmt_i64(ptr null, i64 %t435)
  %t441 = add i64 %t438, %t440
  %t442 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d127, i32 0, i32 1) }, 1
  %t443 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d127, i32 0, i32 1) }, 0
  %t444 = add i64 %t441, %t443
  %t446 = call i64 @__olang_fmt_i64(ptr null, i64 %t436)
  %t447 = add i64 %t444, %t446
  %t448 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d128, i32 0, i32 1) }, 1
  %t449 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d128, i32 0, i32 1) }, 0
  %t450 = add i64 %t447, %t449
  %t451 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t450)
  call void @olang_textcopy(ptr %t451, ptr %t437, i64 %t438)
  %t452 = getelementptr i8, ptr %t451, i64 %t438
  %t453 = call i64 @__olang_fmt_i64(ptr %t452, i64 %t435)
  %t454 = getelementptr i8, ptr %t452, i64 %t440
  call void @olang_textcopy(ptr %t454, ptr %t442, i64 %t443)
  %t455 = getelementptr i8, ptr %t454, i64 %t443
  %t456 = call i64 @__olang_fmt_i64(ptr %t455, i64 %t436)
  %t457 = getelementptr i8, ptr %t455, i64 %t446
  call void @olang_textcopy(ptr %t457, ptr %t448, i64 %t449)
  %t458 = insertvalue { i64, ptr } undef, i64 %t450, 0
  %t459 = insertvalue { i64, ptr } %t458, ptr %t451, 1
  %t461 = extractvalue { i64, ptr } %t459, 0
  %t462 = extractvalue { i64, ptr } %t459, 1
  %t463 = mul i64 %t461, 1
  %t464 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t463)
  call void @llvm.memcpy.p0.p0.i64(ptr %t464, ptr %t462, i64 %t463, i1 false)
  %t465 = insertvalue { i64, ptr } undef, i64 %t461, 0
  %t466 = insertvalue { i64, ptr } %t465, ptr %t464, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s13, ptr %l4, { i64, ptr } %t466)
  br label %bb67
bb67:
  store ptr %l4, ptr %l203, !tbaa !29
  %t469 = load i64, ptr %l12, !tbaa !24
  store i64 %t469, ptr %l204, !tbaa !24
  %t470 = load i64, ptr %l12, !tbaa !24
  store i64 %t470, ptr %l205, !tbaa !24
  %t471 = load ptr, ptr %l0, !tbaa !29
  %t472 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t475 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecstr(ptr %v0, ptr %s13, ptr %s13, ptr %t471, { i64, ptr } %t472)
  store { i64, ptr } %t475, ptr %l208
  br label %bb68
bb68:
  %t476 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t477 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d129, i32 0, i32 1) }, 1
  %t478 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d129, i32 0, i32 1) }, 0
  %t479 = load i64, ptr %l204, !tbaa !24
  %t480 = call i64 @__olang_fmt_i64(ptr null, i64 %t479)
  %t481 = add i64 %t478, %t480
  %t482 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d130, i32 0, i32 1) }, 1
  %t483 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d130, i32 0, i32 1) }, 0
  %t484 = add i64 %t481, %t483
  %t485 = load i64, ptr %l205, !tbaa !24
  %t486 = call i64 @__olang_fmt_i64(ptr null, i64 %t485)
  %t487 = add i64 %t484, %t486
  %t488 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d131, i32 0, i32 1) }, 1
  %t489 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d131, i32 0, i32 1) }, 0
  %t490 = add i64 %t487, %t489
  %t491 = load { i64, ptr }, ptr %l208, !tbaa !27
  %t492 = extractvalue { i64, ptr } %t491, 1
  %t493 = extractvalue { i64, ptr } %t491, 0
  %t494 = add i64 %t490, %t493
  %t495 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d131, i32 0, i32 1) }, 1
  %t496 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d131, i32 0, i32 1) }, 0
  %t497 = add i64 %t494, %t496
  %t499 = extractvalue { i64, ptr } %t476, 1
  %t500 = extractvalue { i64, ptr } %t476, 0
  %t501 = add i64 %t497, %t500
  %t502 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d132, i32 0, i32 1) }, 1
  %t503 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d132, i32 0, i32 1) }, 0
  %t504 = add i64 %t501, %t503
  %t505 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t504)
  call void @olang_textcopy(ptr %t505, ptr %t477, i64 %t478)
  %t506 = getelementptr i8, ptr %t505, i64 %t478
  %t507 = call i64 @__olang_fmt_i64(ptr %t506, i64 %t479)
  %t508 = getelementptr i8, ptr %t506, i64 %t480
  call void @olang_textcopy(ptr %t508, ptr %t482, i64 %t483)
  %t509 = getelementptr i8, ptr %t508, i64 %t483
  %t510 = call i64 @__olang_fmt_i64(ptr %t509, i64 %t485)
  %t511 = getelementptr i8, ptr %t509, i64 %t486
  call void @olang_textcopy(ptr %t511, ptr %t488, i64 %t489)
  %t512 = getelementptr i8, ptr %t511, i64 %t489
  call void @olang_textcopy(ptr %t512, ptr %t492, i64 %t493)
  %t513 = getelementptr i8, ptr %t512, i64 %t493
  call void @olang_textcopy(ptr %t513, ptr %t495, i64 %t496)
  %t514 = getelementptr i8, ptr %t513, i64 %t496
  call void @olang_textcopy(ptr %t514, ptr %t499, i64 %t500)
  %t515 = getelementptr i8, ptr %t514, i64 %t500
  call void @olang_textcopy(ptr %t515, ptr %t502, i64 %t503)
  %t516 = insertvalue { i64, ptr } undef, i64 %t504, 0
  %t517 = insertvalue { i64, ptr } %t516, ptr %t505, 1
  %t519 = extractvalue { i64, ptr } %t517, 0
  %t520 = extractvalue { i64, ptr } %t517, 1
  %t521 = mul i64 %t519, 1
  %t522 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t521)
  call void @llvm.memcpy.p0.p0.i64(ptr %t522, ptr %t520, i64 %t521, i1 false)
  %t523 = insertvalue { i64, ptr } undef, i64 %t519, 0
  %t524 = insertvalue { i64, ptr } %t523, ptr %t522, 1
  %t525 = load ptr, ptr %l203, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s13, ptr %t525, { i64, ptr } %t524)
  br label %bb69
bb69:
  %t527 = load i64, ptr %l12, !tbaa !24
  %t528 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d133, i32 0, i32 1) }, 1
  %t529 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d133, i32 0, i32 1) }, 0
  %t531 = call i64 @__olang_fmt_i64(ptr null, i64 %t527)
  %t532 = add i64 %t529, %t531
  %t533 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t532)
  call void @olang_textcopy(ptr %t533, ptr %t528, i64 %t529)
  %t534 = getelementptr i8, ptr %t533, i64 %t529
  %t535 = call i64 @__olang_fmt_i64(ptr %t534, i64 %t527)
  %t536 = insertvalue { i64, ptr } undef, i64 %t532, 0
  %t537 = insertvalue { i64, ptr } %t536, ptr %t533, 1
  store { i64, ptr } %t537, ptr %l213, !tbaa !27
  %t538 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t539 = extractvalue { i64, ptr } %t538, 0
  %t540 = load { i64, ptr }, ptr %l213, !tbaa !27
  %t541 = extractvalue { i64, ptr } %t540, 0
  store i64 %t541, ptr %l215, !tbaa !24
  %t543 = load i64, ptr %l215, !tbaa !24
  %t544 = icmp eq i64 %t539, %t543
  br i1 %t544, label %bb70, label %bb71
bb70:
  %t546 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t547 = load ptr, ptr %t546, !tbaa !27
  %t548 = getelementptr { i64, ptr }, ptr %l213, i32 0, i32 1
  %t549 = load ptr, ptr %t548, !tbaa !27
  %t550 = load i64, ptr %l215, !tbaa !24
  %t551 = mul i64 %t550, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t547, ptr %t549, i64 %t551, i1 false)
  br label %bb72
bb71:
  %t552 = load { i64, ptr }, ptr %l213, !tbaa !27
  store { i64, ptr } %t552, ptr %l11, !tbaa !27
  br label %bb72
bb72:
  call void @__olang_scope_close(ptr %s13)
  br label %bb73
bb73:
  %t553 = load i64, ptr %l25, !tbaa !24
  %t555 = add i64 %t553, 1
  store i64 %t555, ptr %l25, !tbaa !24
  br label %bb61
bb74:
  br label %bb75
bb75:
  %t557 = load i64, ptr %l17, !tbaa !24
  %t559 = add i64 %t557, 1
  store i64 %t559, ptr %l17, !tbaa !24
  br label %bb48
bb76:
  %t561 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t562 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d134, i32 0, i32 1) }, 1
  %t563 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d134, i32 0, i32 1) }, 0
  %t565 = extractvalue { i64, ptr } %t561, 1
  %t566 = extractvalue { i64, ptr } %t561, 0
  %t567 = add i64 %t563, %t566
  %t568 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d135, i32 0, i32 1) }, 1
  %t569 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d135, i32 0, i32 1) }, 0
  %t570 = add i64 %t567, %t569
  %t571 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t570)
  call void @olang_textcopy(ptr %t571, ptr %t562, i64 %t563)
  %t572 = getelementptr i8, ptr %t571, i64 %t563
  call void @olang_textcopy(ptr %t572, ptr %t565, i64 %t566)
  %t573 = getelementptr i8, ptr %t572, i64 %t566
  call void @olang_textcopy(ptr %t573, ptr %t568, i64 %t569)
  %t574 = insertvalue { i64, ptr } undef, i64 %t570, 0
  %t575 = insertvalue { i64, ptr } %t574, ptr %t571, 1
  %t577 = extractvalue { i64, ptr } %t575, 0
  %t578 = extractvalue { i64, ptr } %t575, 1
  %t579 = mul i64 %t577, 1
  %t580 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t579)
  call void @llvm.memcpy.p0.p0.i64(ptr %t580, ptr %t578, i64 %t579, i1 false)
  %t581 = insertvalue { i64, ptr } undef, i64 %t577, 0
  %t582 = insertvalue { i64, ptr } %t581, ptr %t580, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l4, { i64, ptr } %t582)
  br label %bb77
bb77:
  %t585 = load ptr, ptr %l0, !tbaa !29
  %t587 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2etraced(ptr %v0, ptr %t585)
  store i1 %t587, ptr %l226
  br label %bb78
bb78:
  %t588 = load i1, ptr %l226, !tbaa !21
  br i1 %t588, label %bb79, label %bb80
bb79:
  store %olang.scope zeroinitializer, ptr %s21
  %t589 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s21, ptr %s21, ptr %t589, { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d136, i32 0, i32 1) }, { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d137, i32 0, i32 1) })
  br label %bb81
bb80:
  store %olang.scope zeroinitializer, ptr %s22
  %t591 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s22, ptr %s22, ptr %t591, { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d138, i32 0, i32 1) }, { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d139, i32 0, i32 1) })
  br label %bb83
bb81:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s21, ptr %l4, { i64, ptr } { i64 54, ptr getelementptr inbounds (<{ i64, [54 x i8] }>, ptr @.d140, i32 0, i32 1) })
  br label %bb82
bb82:
  call void @__olang_scope_close(ptr %s21)
  br label %bb85
bb83:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s22, ptr %l4, { i64, ptr } { i64 58, ptr getelementptr inbounds (<{ i64, [58 x i8] }>, ptr @.d141, i32 0, i32 1) })
  br label %bb84
bb84:
  call void @__olang_scope_close(ptr %s22)
  br label %bb85
bb85:
  %t595 = load ptr, ptr %l0, !tbaa !29
  store ptr %t595, ptr %l231, !tbaa !29
  %t596 = load ptr, ptr %l0, !tbaa !29
  %t598 = getelementptr %"compiler/emit:Emitter", ptr %t596, i32 0, i32 0
  %t599 = load ptr, ptr %t598, !tbaa !29
  %t601 = getelementptr %"compiler/generic:Program", ptr %t599, i32 0, i32 0
  %t602 = load ptr, ptr %t601, !tbaa !29
  %t604 = getelementptr %"compiler/load:Loader", ptr %t602, i32 0, i32 7
  %t605 = load i64, ptr %t604, !tbaa !24
  store i64 %t605, ptr %l235, !tbaa !24
  %t607 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l4)
  store { i64, ptr } %t607, ptr %l237
  br label %bb86
bb86:
  %t608 = load ptr, ptr %l231, !tbaa !29
  %t609 = load i64, ptr %l235, !tbaa !24
  %t610 = load { i64, ptr }, ptr %l237, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eitem(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %t608, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d142, i32 0, i32 1) }, i64 %t609, { i64, ptr } %t610, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d8, i32 0, i32 1) })
  br label %bb87
bb87:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eexportArrayResult(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l5 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca i1
  %l11 = alloca i1
  %l14 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  store ptr %t6, ptr %l5, !tbaa !29
  %t7 = load ptr, ptr %l2, !tbaa !29
  %t8 = load i32, ptr %l1, !tbaa !23
  %t11 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t7, i32 %t8)
  store i32 %t11, ptr %l8
  br label %bb1
bb1:
  %t12 = load ptr, ptr %l5, !tbaa !29
  %t13 = load i32, ptr %l8, !tbaa !23
  %t14 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t12, i32 %t13)
  store i1 %t14, ptr %l9
  br label %bb2
bb2:
  %t15 = load i1, ptr %l9, !tbaa !21
  %t16 = xor i1 %t15, true
  br i1 %t16, label %bb3, label %bb4
bb3:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load i32, ptr %l1, !tbaa !23
  %t22 = call i32 @compiler_2femit_2ecompiler_2femit_3aEmitter_2earrayOfE(ptr %v0, ptr %t18, i32 %t19)
  store i32 %t22, ptr %l14
  br label %bb5
bb4:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb6
bb5:
  %t23 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t24 = load i32, ptr %l14, !tbaa !23
  %t26 = icmp ne i32 %t24, %t23
  store i1 %t26, ptr %l11, !tbaa !21
  br label %bb6
bb6:
  %t28 = load i1, ptr %l11, !tbaa !21
  store i1 %t28, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2femit_2ecompiler_2femit_3aEmitter_2eexportBodies(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %lp1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca { i64, [2 x i64] }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l18 = alloca i64
  %l22 = alloca i64
  %l25 = alloca i64
  %l47 = alloca ptr
  %l55 = alloca i64
  %l58 = alloca ptr
  %l61 = alloca i1
  %l66 = alloca ptr
  %l71 = alloca i1
  %l75 = alloca i1
  %l78 = alloca i64
  %rv = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l12
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t2, ptr %lp1
  %t3 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l12
  %t4 = load ptr, ptr %lp1
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %t4
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/emit:Emitter", ptr %t5, i32 0, i32 0
  %t8 = load ptr, ptr %t7, !tbaa !29
  store ptr %t8, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/emit:Emitter", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = getelementptr %"compiler/lower:Lowerer", ptr %t13, i32 0, i32 1
  %t17 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t15)
  store i64 %t17, ptr %l18
  br label %bb2
bb2:
  %t18 = load i64, ptr %l18, !tbaa !24
  store i64 %t18, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t19 = load i64, ptr %l4, !tbaa !24
  %t20 = load i64, ptr %l3, !tbaa !24
  %t23 = icmp sgt i64 %t19, %t20
  br i1 %t23, label %bb3, label %bb4
bb3:
  %t25 = load i64, ptr %l5, !tbaa !24
  %t27 = icmp sgt i64 %t25, 0
  br i1 %t27, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb8
bb5:
  %t29 = load i64, ptr %l4, !tbaa !24
  %t30 = load i64, ptr %l3, !tbaa !24
  %t33 = sub i64 %t29, %t30
  %t34 = load i64, ptr %l5, !tbaa !24
  %t37 = add i64 %t33, %t34
  %t39 = sub i64 %t37, 1
  %t40 = load i64, ptr %l5, !tbaa !24
  %t43 = sdiv i64 %t39, %t40
  store i64 %t43, ptr %l25, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l25, !tbaa !24
  br label %bb7
bb7:
  %t45 = load i64, ptr %l25, !tbaa !24
  store i64 %t45, ptr %l22, !tbaa !24
  br label %bb8
bb8:
  %t46 = load i64, ptr %l22, !tbaa !24
  store i64 %t46, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb9
bb9:
  %t47 = load i64, ptr %l7, !tbaa !24
  %t48 = load i64, ptr %l6, !tbaa !24
  %t51 = icmp slt i64 %t47, %t48
  %t53 = xor i1 %t51, true
  br i1 %t53, label %bb10, label %bb11
bb10:
  br label %bb41
bb11:
  br label %bb12
bb12:
  %t55 = load i64, ptr %l3, !tbaa !24
  %t56 = load i64, ptr %l7, !tbaa !24
  %t57 = load i64, ptr %l5, !tbaa !24
  %t60 = mul i64 %t56, %t57
  %t63 = add i64 %t55, %t60
  store i64 %t63, ptr %l8, !tbaa !24
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/emit:Emitter", ptr %t65, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !29
  %t70 = getelementptr %"compiler/lower:Lowerer", ptr %t68, i32 0, i32 1
  %t71 = load i64, ptr %l8, !tbaa !24
  %t74 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t70, i64 %t71)
  store ptr %t74, ptr %l47
  br label %bb13
bb13:
  %t75 = load ptr, ptr %l47, !tbaa !29
  %t77 = getelementptr %"compiler/typed:Body", ptr %t75, i32 0, i32 1
  %t78 = load { i64, [2 x i64] }, ptr %t77
  store { i64, [2 x i64] } %t78, ptr %l9
  %t80 = load { i64, [2 x i64] }, ptr %l9
  %t82 = extractvalue { i64, [2 x i64] } %t80, 0
  %t83 = icmp eq i64 %t82, 0
  br i1 %t83, label %bb14, label %bb15
bb14:
  %t85 = getelementptr { i64, [2 x i64] }, ptr %l9, i32 0, i32 1
  %t86 = getelementptr { i64 }, ptr %t85, i32 0, i32 0
  %t87 = load i64, ptr %t86
  store i64 %t87, ptr %l10, !tbaa !24
  br label %bb16
bb15:
  br label %bb34
bb16:
  %t89 = load ptr, ptr %l2, !tbaa !29
  %t90 = load i64, ptr %l10, !tbaa !24
  %t93 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t89, i64 %t90)
  store i64 %t93, ptr %l55
  br label %bb17
bb17:
  %t94 = load i64, ptr %l55, !tbaa !24
  store i64 %t94, ptr %l11, !tbaa !24
  %t95 = load ptr, ptr %l2, !tbaa !29
  %t96 = load i64, ptr %l11, !tbaa !24
  %t99 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t95, i64 %t96)
  store ptr %t99, ptr %l58
  br label %bb18
bb18:
  %t100 = load ptr, ptr %l58, !tbaa !29
  %t102 = getelementptr %"compiler/ast:Func", ptr %t100, i32 0, i32 7
  %t103 = load i1, ptr %t102, !tbaa !21
  br i1 %t103, label %bb19, label %bb20
bb19:
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr %"compiler/emit:Emitter", ptr %t105, i32 0, i32 1
  %t108 = load ptr, ptr %t107, !tbaa !29
  %t110 = getelementptr %"compiler/lower:Lowerer", ptr %t108, i32 0, i32 1
  %t111 = load i64, ptr %l8, !tbaa !24
  %t114 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t110, i64 %t111)
  store ptr %t114, ptr %l66
  br label %bb21
bb20:
  store i1 false, ptr %l61, !tbaa !21
  br label %bb22
bb21:
  %t115 = load ptr, ptr %l66, !tbaa !29
  %t117 = getelementptr %"compiler/typed:Body", ptr %t115, i32 0, i32 11
  %t118 = load ptr, ptr %t117, !tbaa !29
  %t120 = icmp eq ptr %t118, null
  %t122 = xor i1 %t120, true
  store i1 %t122, ptr %l61, !tbaa !21
  br label %bb22
bb22:
  %t124 = load i1, ptr %l61, !tbaa !21
  br i1 %t124, label %bb23, label %bb24
bb23:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t127 = getelementptr %"compiler/emit:Emitter", ptr %t125, i32 0, i32 38
  %t128 = load i1, ptr %t127, !tbaa !21
  %t130 = xor i1 %t128, true
  br i1 %t130, label %bb25, label %bb26
bb24:
  store i1 false, ptr %l71, !tbaa !21
  br label %bb29
bb25:
  store i1 true, ptr %l75, !tbaa !21
  br label %bb28
bb26:
  %t132 = load ptr, ptr %l2, !tbaa !29
  %t133 = load i64, ptr %l11, !tbaa !24
  %t136 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t132, i64 %t133)
  store i64 %t136, ptr %l78
  br label %bb27
bb27:
  %t137 = load ptr, ptr %l2, !tbaa !29
  %t139 = getelementptr %"compiler/generic:Program", ptr %t137, i32 0, i32 0
  %t140 = load ptr, ptr %t139, !tbaa !29
  %t142 = getelementptr %"compiler/load:Loader", ptr %t140, i32 0, i32 7
  %t143 = load i64, ptr %t142, !tbaa !24
  %t144 = load i64, ptr %l78, !tbaa !24
  %t146 = icmp eq i64 %t144, %t143
  store i1 %t146, ptr %l75, !tbaa !21
  br label %bb28
bb28:
  %t148 = load i1, ptr %l75, !tbaa !21
  store i1 %t148, ptr %l71, !tbaa !21
  br label %bb29
bb29:
  %t149 = load i1, ptr %l71, !tbaa !21
  br i1 %t149, label %bb30, label %bb31
bb30:
  %t150 = load ptr, ptr %lp1
  %t151 = load i64, ptr %l8, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t150, i64 %t151)
  br label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb33
bb33:
  br label %bb39
bb34:
  br i1 true, label %bb35, label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb38
bb37:
  br label %bb39
bb38:
  call void @__olang_check_failed(ptr @olang_loc_70000d3e005ea498_c6a0fd2b538569fc)
  unreachable
bb39:
  br label %bb40
bb40:
  %t154 = load i64, ptr %l7, !tbaa !24
  %t156 = add i64 %t154, 1
  store i64 %t156, ptr %l7, !tbaa !24
  br label %bb9
bb41:
  %t158 = load ptr, ptr %lp1
  %t159 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t158
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t159, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eexportEntry(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca { i64, [2 x i64] }
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i32
  %l10 = alloca { i64, [2 x i64] }
  %l11 = alloca ptr
  %l12 = alloca i32
  %l13 = alloca i1
  %l14 = alloca i1
  %l15 = alloca i1
  %l16 = alloca %"compiler/cabi:Way"
  %l17 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l18 = alloca %"compiler/cabi:Regs"
  %l19 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i32
  %l29 = alloca i32
  %l30 = alloca { i64, ptr }
  %l31 = alloca i32
  %l33 = alloca %"compiler/cabi:Way"
  %l34 = alloca i32
  %l35 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l44 = alloca i32
  %l47 = alloca { i64, ptr }
  %l48 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l49 = alloca { i64, ptr }
  %l50 = alloca i64
  %l51 = alloca i64
  %l52 = alloca i64
  %l53 = alloca i64
  %l54 = alloca i64
  %l55 = alloca i64
  %l56 = alloca ptr
  %l57 = alloca i64
  %l59 = alloca { i64, ptr }
  %l60 = alloca { i64, ptr }
  %l61 = alloca %"std/prelude/text:StringBuilder"
  %l62 = alloca ptr
  %l63 = alloca i64
  %l64 = alloca i64
  %l65 = alloca { i64, ptr }
  %l66 = alloca { i64, ptr }
  %l67 = alloca { i64, ptr }
  %l68 = alloca { i64, ptr }
  %l70 = alloca i32
  %l71 = alloca { i64, ptr }
  %l72 = alloca { i64, ptr }
  %l74 = alloca { i64, ptr }
  %l76 = alloca { i64, ptr }
  %l77 = alloca i32
  %l78 = alloca { i64, ptr }
  %l79 = alloca { i64, ptr }
  %l80 = alloca { i64, ptr }
  %l81 = alloca i64
  %l82 = alloca i64
  %l83 = alloca i64
  %l84 = alloca i64
  %l85 = alloca i64
  %l86 = alloca i64
  %l87 = alloca { i64, ptr }
  %l88 = alloca { i64, ptr }
  %l89 = alloca i32
  %l90 = alloca %"std/prelude/text:StringBuilder"
  %l91 = alloca ptr
  %l92 = alloca i64
  %l93 = alloca i64
  %l94 = alloca { i64, ptr }
  %l103 = alloca ptr
  %l111 = alloca i64
  %l112 = alloca ptr
  %l115 = alloca ptr
  %l118 = alloca { i64, ptr }
  %l128 = alloca ptr
  %l129 = alloca { i64, [2 x i64] }
  %l130 = alloca i32
  %l131 = alloca %"compiler/source:Span"
  %l132 = alloca %"compiler/mir:Fn"
  %l135 = alloca %"compiler/emit:fnEm"
  %l139 = alloca i32
  %l143 = alloca i1
  %l150 = alloca i1
  %l151 = alloca ptr
  %l154 = alloca i32
  %l155 = alloca { i64, ptr }
  %l159 = alloca i1
  %l162 = alloca i1
  %l163 = alloca i32
  %l164 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l165 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l166 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l167 = alloca %"compiler/cabi:Way"
  %l169 = alloca i1
  %l172 = alloca i1
  %l179 = alloca %"compiler/cabi:Way"
  %l180 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l181 = alloca %"compiler/cabi:Regs"
  %l184 = alloca ptr
  %l187 = alloca { i64, ptr }
  %l190 = alloca i64
  %l195 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l196 = alloca ptr
  %l199 = alloca i32
  %l200 = alloca { i64, ptr }
  %l203 = alloca { i64, ptr }
  %l209 = alloca i64
  %l212 = alloca i64
  %l230 = alloca { i64, ptr }
  %l235 = alloca i1
  %l238 = alloca i32
  %l243 = alloca i1
  %l244 = alloca ptr
  %l247 = alloca i32
  %l248 = alloca i32
  %l251 = alloca i32
  %l254 = alloca i1
  %l257 = alloca i32
  %l273 = alloca { i64, ptr }
  %l274 = alloca ptr
  %l280 = alloca { i64, ptr }
  %l298 = alloca %"compiler/cabi:Way"
  %l302 = alloca ptr
  %l305 = alloca { i64, ptr }
  %l307 = alloca i1
  %l309 = alloca { i64, ptr }
  %l316 = alloca ptr
  %l319 = alloca { i64, ptr }
  %l325 = alloca ptr
  %l329 = alloca i64
  %l332 = alloca { i64, ptr }
  %l334 = alloca i64
  %l338 = alloca i64
  %l341 = alloca i64
  %l359 = alloca ptr
  %l362 = alloca { i64, ptr }
  %l369 = alloca i64
  %l371 = alloca { i64, ptr }
  %l373 = alloca ptr
  %l374 = alloca { i64, ptr }
  %l377 = alloca i64
  %l380 = alloca { i64, ptr }
  %l381 = alloca ptr
  %l384 = alloca { i64, ptr }
  %l386 = alloca { i64, ptr }
  %l387 = alloca { i64, ptr }
  %l388 = alloca { i64, ptr }
  %l398 = alloca { i64, ptr }
  %l400 = alloca i64
  %l402 = alloca i64
  %l403 = alloca { i64, ptr }
  %l406 = alloca ptr
  %l409 = alloca { i64, ptr }
  %l412 = alloca i64
  %l413 = alloca i64
  %l426 = alloca { i64, ptr }
  %l427 = alloca ptr
  %l428 = alloca { i64, ptr }
  %l429 = alloca { i64, ptr }
  %l432 = alloca i64
  %l437 = alloca ptr
  %l440 = alloca { i64, ptr }
  %l441 = alloca ptr
  %l444 = alloca { i64, ptr }
  %l447 = alloca { i64, ptr }
  %l454 = alloca ptr
  %l455 = alloca ptr
  %l458 = alloca i32
  %l459 = alloca i32
  %l460 = alloca i32
  %l463 = alloca i1
  %l469 = alloca i1
  %l476 = alloca { i64, ptr }
  %l481 = alloca { i64, ptr }
  %l493 = alloca { i64, ptr }
  %l496 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l497 = alloca { i64, ptr }
  %l498 = alloca { i64, ptr }
  %l499 = alloca i64
  %l500 = alloca { i64, ptr }
  %l502 = alloca i1
  %l505 = alloca i1
  %l508 = alloca { i64, ptr }
  %l510 = alloca i64
  %l521 = alloca i64
  %l525 = alloca i64
  %l528 = alloca i64
  %l553 = alloca i64
  %l555 = alloca i64
  %l560 = alloca { i64, ptr }
  %l567 = alloca { i64, ptr }
  %l568 = alloca { i64, ptr }
  %l569 = alloca { i64, ptr }
  %l570 = alloca i64
  %l571 = alloca { i64, ptr }
  %l572 = alloca %"std/prelude/text:StringBuilder"
  %l574 = alloca i64
  %l576 = alloca i64
  %l582 = alloca { i64, ptr }
  %l591 = alloca i1
  %l592 = alloca ptr
  %l595 = alloca { i64, ptr }
  %l597 = alloca { i64, ptr }
  %l600 = alloca ptr
  %l601 = alloca { i64, ptr }
  %l604 = alloca { i64, ptr }
  %l606 = alloca { i64, ptr }
  %l609 = alloca { i64, ptr }
  %l611 = alloca i64
  %l613 = alloca { i64, ptr }
  %l614 = alloca { i64, ptr }
  %l615 = alloca i64
  %l616 = alloca { i64, ptr }
  %l617 = alloca { i64, ptr }
  %l618 = alloca { i64, ptr }
  %l619 = alloca i64
  %l620 = alloca { i64, ptr }
  %l623 = alloca i1
  %l625 = alloca i1
  %l628 = alloca { i64, ptr }
  %l635 = alloca { i64, ptr }
  %l637 = alloca i64
  %l640 = alloca i1
  %l642 = alloca i1
  %l648 = alloca { i64, ptr }
  %l650 = alloca i64
  %l653 = alloca i1
  %l655 = alloca i1
  %l656 = alloca { i64, ptr }
  %l658 = alloca i64
  %l660 = alloca i64
  %l661 = alloca { i64, ptr }
  %l663 = alloca i1
  %l665 = alloca i1
  %l667 = alloca ptr
  %l670 = alloca { i64, ptr }
  %l673 = alloca { i64, ptr }
  %l675 = alloca i64
  %l677 = alloca { i64, ptr }
  %l678 = alloca { i64, ptr }
  %l679 = alloca i64
  %l680 = alloca { i64, ptr }
  %l686 = alloca { i64, ptr }
  %l697 = alloca ptr
  %l699 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l701 = alloca { i64, ptr }
  %l702 = alloca i32
  %l703 = alloca ptr
  %l704 = alloca ptr
  %l705 = alloca { i64, ptr }
  %l708 = alloca i32
  %l710 = alloca { i64, ptr }
  %l720 = alloca { i64, ptr }
  %l725 = alloca { i64, ptr }
  %l730 = alloca { i64, ptr }
  %l736 = alloca { i64, ptr }
  %l741 = alloca { i64, ptr }
  %l747 = alloca { i64, ptr }
  %l749 = alloca i64
  %l751 = alloca ptr
  %l752 = alloca { i64, ptr }
  %l755 = alloca i64
  %l758 = alloca { i64, ptr }
  %l768 = alloca { i64, ptr }
  %l769 = alloca { i64, ptr }
  %l771 = alloca i64
  %l773 = alloca i64
  %l774 = alloca { i64, ptr }
  %l776 = alloca { i64, ptr }
  %l778 = alloca i64
  %l782 = alloca ptr
  %l785 = alloca { i64, ptr }
  %l788 = alloca { i64, ptr }
  %l789 = alloca { i64, ptr }
  %l791 = alloca i64
  %l793 = alloca i64
  %l794 = alloca { i64, ptr }
  %l801 = alloca { i64, ptr }
  %l803 = alloca { i64, ptr }
  %l805 = alloca i64
  %l809 = alloca ptr
  %l813 = alloca i64
  %l816 = alloca { i64, ptr }
  %l817 = alloca ptr
  %l820 = alloca { i64, ptr }
  %l825 = alloca { i64, ptr }
  %l827 = alloca i64
  %l829 = alloca { i64, ptr }
  %l833 = alloca { i64, ptr }
  %l834 = alloca { i64, ptr }
  %l836 = alloca i64
  %l838 = alloca { i64, ptr }
  %l839 = alloca { i64, ptr }
  %l840 = alloca i64
  %l841 = alloca { i64, ptr }
  %l843 = alloca i64
  %l847 = alloca i64
  %l850 = alloca i64
  %l870 = alloca i64
  %l872 = alloca { i64, ptr }
  %l874 = alloca ptr
  %l875 = alloca { i64, ptr }
  %l878 = alloca i64
  %l881 = alloca { i64, ptr }
  %l882 = alloca ptr
  %l883 = alloca { i64, ptr }
  %l884 = alloca { i64, ptr }
  %l887 = alloca { i64, ptr }
  %l888 = alloca ptr
  %l891 = alloca { i64, ptr }
  %l893 = alloca { i64, ptr }
  %l897 = alloca { i64, ptr }
  %l899 = alloca i64
  %l905 = alloca { i64, ptr }
  %l907 = alloca i64
  %l909 = alloca ptr
  %l912 = alloca { i64, ptr }
  %l919 = alloca ptr
  %l921 = alloca i1
  %l923 = alloca { i64, ptr }
  %l927 = alloca { i64, ptr }
  %l928 = alloca { i64, ptr }
  %l929 = alloca i64
  %l930 = alloca { i64, ptr }
  %l932 = alloca { i64, ptr }
  %l933 = alloca { i64, ptr }
  %l935 = alloca i64
  %l937 = alloca i64
  %l938 = alloca { i64, ptr }
  %l940 = alloca { i64, ptr }
  %l941 = alloca { i64, ptr }
  %l943 = alloca i64
  %l945 = alloca i64
  %l946 = alloca { i64, ptr }
  %l949 = alloca { i64, ptr }
  %l953 = alloca i1
  %l955 = alloca { i64, ptr }
  %l961 = alloca { i64, ptr }
  %l966 = alloca { i64, ptr }
  %l967 = alloca { i64, ptr }
  %l970 = alloca i64
  %l972 = alloca %"std/prelude/text:StringBuilder"
  %l979 = alloca i64
  %l981 = alloca i64
  %l987 = alloca { i64, ptr }
  %l996 = alloca ptr
  %l999 = alloca { i64, ptr }
  %l1000 = alloca ptr
  %l1003 = alloca { i64, ptr }
  %l1005 = alloca ptr
  %l1006 = alloca { i64, ptr }
  %l1009 = alloca i64
  %l1011 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %s33 = alloca %olang.scope
  %s37 = alloca %olang.scope
  %s39 = alloca %olang.scope
  %s59 = alloca %olang.scope
  %s61 = alloca %olang.scope
  %s63 = alloca %olang.scope
  %s65 = alloca %olang.scope
  %s69 = alloca %olang.scope
  %s72 = alloca %olang.scope
  %s77 = alloca %olang.scope
  %s86 = alloca %olang.scope
  %s91 = alloca %olang.scope
  %s94 = alloca %olang.scope
  %s96 = alloca %olang.scope
  %s98 = alloca %olang.scope
  %s100 = alloca %olang.scope
  %s102 = alloca %olang.scope
  %s107 = alloca %olang.scope
  %s115 = alloca %olang.scope
  %s123 = alloca %olang.scope
  %t71 = alloca { i64, [2 x i64] }, align 8
  %t86 = alloca %"compiler/mir:Fn", align 8
  %t92 = alloca %"compiler/emit:fnEm", align 8
  %t1275 = alloca { i64, [7 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/emit:Emitter", ptr %t6, i32 0, i32 0
  %t9 = load ptr, ptr %t8, !tbaa !29
  store ptr %t9, ptr %l3, !tbaa !29
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/emit:Emitter", ptr %t11, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t16 = getelementptr %"compiler/lower:Lowerer", ptr %t14, i32 0, i32 1
  %t17 = load i64, ptr %l1, !tbaa !24
  %t20 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t16, i64 %t17)
  store ptr %t20, ptr %l103
  br label %bb1
bb1:
  %t21 = load ptr, ptr %l103, !tbaa !29
  store ptr %t21, ptr %l4, !tbaa !29
  store i64 -1, ptr %l5, !tbaa !24
  %t22 = load ptr, ptr %l4, !tbaa !29
  %t24 = getelementptr %"compiler/typed:Body", ptr %t22, i32 0, i32 1
  %t25 = load { i64, [2 x i64] }, ptr %t24
  store { i64, [2 x i64] } %t25, ptr %l6
  %t27 = load { i64, [2 x i64] }, ptr %l6
  %t29 = extractvalue { i64, [2 x i64] } %t27, 0
  %t30 = icmp eq i64 %t29, 0
  br i1 %t30, label %bb2, label %bb3
bb2:
  %t32 = getelementptr { i64, [2 x i64] }, ptr %l6, i32 0, i32 1
  %t33 = getelementptr { i64 }, ptr %t32, i32 0, i32 0
  %t34 = load i64, ptr %t33
  store i64 %t34, ptr %l7, !tbaa !24
  br label %bb4
bb3:
  br label %bb6
bb4:
  %t36 = load ptr, ptr %l3, !tbaa !29
  %t37 = load i64, ptr %l7, !tbaa !24
  %t40 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t36, i64 %t37)
  store i64 %t40, ptr %l111
  br label %bb5
bb5:
  %t41 = load i64, ptr %l111, !tbaa !24
  store i64 %t41, ptr %l5, !tbaa !24
  br label %bb11
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb10:
  call void @__olang_check_failed(ptr @olang_loc_8dd51a70be22f844_db8bd8df095848b0)
  unreachable
bb11:
  %t42 = load ptr, ptr %l0, !tbaa !29
  store ptr %t42, ptr %l112, !tbaa !29
  %t43 = load ptr, ptr %l3, !tbaa !29
  %t44 = load i64, ptr %l5, !tbaa !24
  %t47 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t43, i64 %t44)
  store ptr %t47, ptr %l115
  br label %bb12
bb12:
  %t48 = load ptr, ptr %l115, !tbaa !29
  %t50 = getelementptr %"compiler/ast:Func", ptr %t48, i32 0, i32 2
  %t51 = load i32, ptr %t50, !tbaa !23
  %t52 = load ptr, ptr %l112, !tbaa !29
  %t54 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etext(ptr %v0, ptr %t52, i32 %t51)
  store { i64, ptr } %t54, ptr %l118
  br label %bb13
bb13:
  %t55 = load { i64, ptr }, ptr %l118, !tbaa !27
  %t56 = extractvalue { i64, ptr } %t55, 1
  %t57 = extractvalue { i64, ptr } %t55, 0
  %t58 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t57)
  call void @olang_textcopy(ptr %t58, ptr %t56, i64 %t57)
  %t59 = insertvalue { i64, ptr } undef, i64 %t57, 0
  %t60 = insertvalue { i64, ptr } %t59, ptr %t58, 1
  store { i64, ptr } %t60, ptr %l8, !tbaa !27
  %t62 = load ptr, ptr %l4, !tbaa !29
  %t64 = getelementptr %"compiler/typed:Body", ptr %t62, i32 0, i32 2
  %t65 = load i32, ptr %t64, !tbaa !23
  store i32 %t65, ptr %l9, !tbaa !23
  %t67 = load i64, ptr %l1, !tbaa !24
  %t69 = trunc i64 %t67 to i32
  store { i64, [2 x i64] } zeroinitializer, ptr %t71
  %t72 = getelementptr { i64, [2 x i64] }, ptr %t71, i32 0, i32 0
  store i64 0, ptr %t72
  %t74 = insertvalue { i32 } undef, i32 %t69, 0
  %t75 = getelementptr { i64, [2 x i64] }, ptr %t71, i32 0, i32 1
  store { i32 } %t74, ptr %t75
  %t76 = load { i64, [2 x i64] }, ptr %t71
  store { i64, [2 x i64] } %t76, ptr %l10
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t79 = load { i64, [2 x i64] }, ptr %l10
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2ewant(ptr %v0, ptr %t78, { i64, [2 x i64] } %t79)
  br label %bb14
bb14:
  %t82 = load ptr, ptr %l0, !tbaa !29
  store ptr %t82, ptr %l128, !tbaa !29
  %t83 = load { i64, [2 x i64] }, ptr %l10
  store { i64, [2 x i64] } %t83, ptr %l129
  %t84 = load i32, ptr %l9, !tbaa !23
  store i32 %t84, ptr %l130, !tbaa !23
  %t85 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 0, i32 0)
  store %"compiler/source:Span" %t85, ptr %l131
  br label %bb15
bb15:
  %t87 = load { i64, [2 x i64] }, ptr %l129
  %t88 = load i32, ptr %l130, !tbaa !23
  %t89 = load %"compiler/source:Span", ptr %l131
  call void @compiler_2fmir_3aFn_2ector(ptr %t86, ptr %v0, { i64, [2 x i64] } %t87, i32 %t88, i64 0, %"compiler/source:Span" %t89)
  call void @llvm.memmove.p0.p0.i64(ptr %l132, ptr %t86, i64 248, i1 false)
  br label %bb16
bb16:
  %t90 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 248, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t90, ptr %l132, i64 248, i1 false)
  %t91 = load { i64, [2 x i64] }, ptr %l10
  %t93 = load ptr, ptr %l128, !tbaa !29
  call void @compiler_2femit_3afnEm_2ector(ptr %t92, ptr %v0, ptr %v0, ptr %v0, ptr %t93, ptr %t90, { i64, [2 x i64] } %t91)
  call void @llvm.memmove.p0.p0.i64(ptr %l135, ptr %t92, i64 296, i1 false)
  br label %bb17
bb17:
  %t96 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 296, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t96, ptr %l135, i64 296, i1 false)
  store ptr %t96, ptr %l11, !tbaa !29
  %t98 = load ptr, ptr %l2, !tbaa !29
  %t99 = load i32, ptr %l9, !tbaa !23
  %t102 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t98, i32 %t99)
  store i32 %t102, ptr %l139
  br label %bb18
bb18:
  %t103 = load i32, ptr %l139, !tbaa !23
  store i32 %t103, ptr %l12, !tbaa !23
  %t104 = load i32, ptr %l12, !tbaa !23
  %t105 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t108 = icmp ne i32 %t104, %t105
  br i1 %t108, label %bb19, label %bb20
bb19:
  %t110 = load i32, ptr %l12, !tbaa !23
  %t111 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t114 = icmp ne i32 %t110, %t111
  store i1 %t114, ptr %l143, !tbaa !21
  br label %bb21
bb20:
  store i1 false, ptr %l143, !tbaa !21
  br label %bb21
bb21:
  %t116 = load i1, ptr %l143, !tbaa !21
  store i1 %t116, ptr %l13, !tbaa !21
  %t117 = load i1, ptr %l13, !tbaa !21
  br i1 %t117, label %bb22, label %bb23
bb22:
  %t119 = load ptr, ptr %l3, !tbaa !29
  %t120 = load i32, ptr %l12, !tbaa !23
  %t123 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLayout(ptr %v0, ptr %t119, i32 %t120)
  store i1 %t123, ptr %l150
  br label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb25
bb25:
  %t124 = load ptr, ptr %l2, !tbaa !29
  store ptr %t124, ptr %l151, !tbaa !29
  %t125 = load ptr, ptr %l2, !tbaa !29
  %t126 = load i32, ptr %l9, !tbaa !23
  %t129 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t125, i32 %t126)
  store i32 %t129, ptr %l154
  br label %bb26
bb26:
  %t130 = load ptr, ptr %l151, !tbaa !29
  %t131 = load i32, ptr %l154, !tbaa !23
  %t132 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t130, i32 %t131)
  store { i64, ptr } %t132, ptr %l155
  br label %bb27
bb27:
  %t133 = load { i64, ptr }, ptr %l155, !tbaa !27
  %t134 = extractvalue { i64, ptr } %t133, 0
  %t136 = icmp sgt i64 %t134, 0
  store i1 %t136, ptr %l14, !tbaa !21
  %t138 = load i1, ptr %l13, !tbaa !21
  br i1 %t138, label %bb28, label %bb29
bb28:
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t141 = load i32, ptr %l12, !tbaa !23
  %t144 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eexportArrayResult(ptr %v0, ptr %t140, i32 %t141)
  store i1 %t144, ptr %l162
  br label %bb30
bb29:
  store i1 false, ptr %l159, !tbaa !21
  br label %bb31
bb30:
  %t145 = load i1, ptr %l162, !tbaa !21
  store i1 %t145, ptr %l159, !tbaa !21
  br label %bb31
bb31:
  %t146 = load i1, ptr %l159, !tbaa !21
  store i1 %t146, ptr %l15, !tbaa !21
  store i32 0, ptr %l163
  %t147 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t147, ptr %l164
  br label %bb32
bb32:
  %t148 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t148, ptr %l165
  br label %bb33
bb33:
  %t149 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t149, ptr %l166
  br label %bb34
bb34:
  %t150 = load i32, ptr %l163
  %t151 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l164
  %t152 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l165
  %t153 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l166
  %t154 = call %"compiler/cabi:Way" @compiler_2fcabi_3aWay_2ector(ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, i32 %t150, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t151, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t152, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t153, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d143, i32 0, i32 1) })
  store %"compiler/cabi:Way" %t154, ptr %l167
  br label %bb35
bb35:
  %t155 = load %"compiler/cabi:Way", ptr %l167
  store %"compiler/cabi:Way" %t155, ptr %l16
  %t156 = load i1, ptr %l13, !tbaa !21
  br i1 %t156, label %bb36, label %bb37
bb36:
  %t158 = load i1, ptr %l14, !tbaa !21
  %t160 = xor i1 %t158, true
  store i1 %t160, ptr %l169, !tbaa !21
  br label %bb38
bb37:
  store i1 false, ptr %l169, !tbaa !21
  br label %bb38
bb38:
  %t162 = load i1, ptr %l169, !tbaa !21
  br i1 %t162, label %bb39, label %bb40
bb39:
  %t163 = load i1, ptr %l15, !tbaa !21
  %t165 = xor i1 %t163, true
  store i1 %t165, ptr %l172, !tbaa !21
  br label %bb41
bb40:
  store i1 false, ptr %l172, !tbaa !21
  br label %bb41
bb41:
  %t167 = load i1, ptr %l172, !tbaa !21
  br i1 %t167, label %bb42, label %bb43
bb42:
  %t168 = load ptr, ptr %l2, !tbaa !29
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t171 = getelementptr %"compiler/emit:Emitter", ptr %t169, i32 0, i32 45
  %t172 = load { i64, ptr }, ptr %t171, !tbaa !27
  %t173 = load i32, ptr %l12, !tbaa !23
  %t177 = call %"compiler/cabi:Way" @compiler_2fcabi_2eResult(ptr %v0, ptr %v0, ptr %s0, ptr %t168, { i64, ptr } %t172, i32 %t173)
  store %"compiler/cabi:Way" %t177, ptr %l179
  br label %bb44
bb43:
  br label %bb45
bb44:
  %t178 = load %"compiler/cabi:Way", ptr %l179
  store %"compiler/cabi:Way" %t178, ptr %l16
  br label %bb45
bb45:
  %t179 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t179, ptr %l180
  br label %bb46
bb46:
  %t180 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l180
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t180, ptr %l17
  %t181 = call %"compiler/cabi:Regs" @compiler_2fcabi_3aRegs_2ector(ptr %s0, i64 6, i64 8)
  store %"compiler/cabi:Regs" %t181, ptr %l181
  br label %bb47
bb47:
  %t182 = load %"compiler/cabi:Regs", ptr %l181
  store %"compiler/cabi:Regs" %t182, ptr %l18
  %t183 = getelementptr %"compiler/cabi:Way", ptr %l16, i32 0, i32 0
  %t184 = load i32, ptr %t183
  %t186 = trunc i64 4 to i32
  %t187 = icmp eq i32 %t184, %t186
  br i1 %t187, label %bb48, label %bb49
bb48:
  store %olang.scope zeroinitializer, ptr %s6
  store ptr %l17, ptr %l184, !tbaa !29
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t190 = load i32, ptr %l12, !tbaa !23
  %t193 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %s6, ptr %t189, i32 %t190)
  store { i64, ptr } %t193, ptr %l187
  br label %bb50
bb49:
  br label %bb53
bb50:
  %t194 = load ptr, ptr %l2, !tbaa !29
  %t195 = load i32, ptr %l12, !tbaa !23
  %t198 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAlign(ptr %v0, ptr %t194, i32 %t195)
  store i64 %t198, ptr %l190
  br label %bb51
bb51:
  %t199 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d144, i32 0, i32 1) }, 1
  %t200 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d144, i32 0, i32 1) }, 0
  %t201 = load { i64, ptr }, ptr %l187, !tbaa !27
  %t202 = extractvalue { i64, ptr } %t201, 1
  %t203 = extractvalue { i64, ptr } %t201, 0
  %t204 = add i64 %t200, %t203
  %t205 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d145, i32 0, i32 1) }, 1
  %t206 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d145, i32 0, i32 1) }, 0
  %t207 = add i64 %t204, %t206
  %t208 = load i64, ptr %l190, !tbaa !24
  %t209 = call i64 @__olang_fmt_i64(ptr null, i64 %t208)
  %t210 = add i64 %t207, %t209
  %t211 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d146, i32 0, i32 1) }, 1
  %t212 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d146, i32 0, i32 1) }, 0
  %t213 = add i64 %t210, %t212
  %t214 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t213)
  call void @olang_textcopy(ptr %t214, ptr %t199, i64 %t200)
  %t215 = getelementptr i8, ptr %t214, i64 %t200
  call void @olang_textcopy(ptr %t215, ptr %t202, i64 %t203)
  %t216 = getelementptr i8, ptr %t215, i64 %t203
  call void @olang_textcopy(ptr %t216, ptr %t205, i64 %t206)
  %t217 = getelementptr i8, ptr %t216, i64 %t206
  %t218 = call i64 @__olang_fmt_i64(ptr %t217, i64 %t208)
  %t219 = getelementptr i8, ptr %t217, i64 %t209
  call void @olang_textcopy(ptr %t219, ptr %t211, i64 %t212)
  %t220 = insertvalue { i64, ptr } undef, i64 %t213, 0
  %t221 = insertvalue { i64, ptr } %t220, ptr %t214, 1
  %t223 = extractvalue { i64, ptr } %t221, 0
  %t224 = extractvalue { i64, ptr } %t221, 1
  %t225 = mul i64 %t223, 1
  %t226 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t225)
  call void @llvm.memcpy.p0.p0.i64(ptr %t226, ptr %t224, i64 %t225, i1 false)
  %t227 = insertvalue { i64, ptr } undef, i64 %t223, 0
  %t228 = insertvalue { i64, ptr } %t227, ptr %t226, 1
  %t229 = load ptr, ptr %l184, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t229, { i64, ptr } %t228)
  br label %bb52
bb52:
  %t231 = getelementptr %"compiler/cabi:Regs", ptr %l18, i32 0, i32 0
  %t232 = load i64, ptr %t231, !tbaa !24
  %t234 = sub i64 %t232, 1
  %t236 = getelementptr %"compiler/cabi:Regs", ptr %l18, i32 0, i32 0
  store i64 %t234, ptr %t236, !tbaa !24
  call void @__olang_scope_close(ptr %s6)
  br label %bb53
bb53:
  %t237 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t237, ptr %l195
  br label %bb54
bb54:
  %t238 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l195
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t238, ptr %l19
  %t239 = load ptr, ptr %l2, !tbaa !29
  store ptr %t239, ptr %l196, !tbaa !29
  %t240 = load ptr, ptr %l2, !tbaa !29
  %t241 = load i32, ptr %l9, !tbaa !23
  %t244 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t240, i32 %t241)
  store i32 %t244, ptr %l199
  br label %bb55
bb55:
  %t245 = load ptr, ptr %l196, !tbaa !29
  %t246 = load i32, ptr %l199, !tbaa !23
  %t247 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t245, i32 %t246)
  store { i64, ptr } %t247, ptr %l200
  br label %bb56
bb56:
  %t248 = load { i64, ptr }, ptr %l200, !tbaa !27
  store { i64, ptr } %t248, ptr %l20, !tbaa !27
  %t249 = load ptr, ptr %l2, !tbaa !29
  %t250 = load i32, ptr %l9, !tbaa !23
  %t253 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePassing(ptr %v0, ptr %s0, ptr %t249, i32 %t250)
  store { i64, ptr } %t253, ptr %l203
  br label %bb57
bb57:
  %t254 = load { i64, ptr }, ptr %l203, !tbaa !27
  store { i64, ptr } %t254, ptr %l21, !tbaa !27
  store i64 0, ptr %l22, !tbaa !24
  %t255 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t257 = extractvalue { i64, ptr } %t255, 0
  store i64 %t257, ptr %l23, !tbaa !24
  store i64 1, ptr %l24, !tbaa !24
  %t259 = load i64, ptr %l23, !tbaa !24
  %t260 = load i64, ptr %l22, !tbaa !24
  %t263 = icmp sgt i64 %t259, %t260
  br i1 %t263, label %bb58, label %bb59
bb58:
  %t265 = load i64, ptr %l24, !tbaa !24
  %t267 = icmp sgt i64 %t265, 0
  br i1 %t267, label %bb60, label %bb61
bb59:
  store i64 0, ptr %l209, !tbaa !24
  br label %bb63
bb60:
  %t269 = load i64, ptr %l23, !tbaa !24
  %t270 = load i64, ptr %l22, !tbaa !24
  %t273 = sub i64 %t269, %t270
  %t274 = load i64, ptr %l24, !tbaa !24
  %t277 = add i64 %t273, %t274
  %t279 = sub i64 %t277, 1
  %t280 = load i64, ptr %l24, !tbaa !24
  %t283 = sdiv i64 %t279, %t280
  store i64 %t283, ptr %l212, !tbaa !24
  br label %bb62
bb61:
  store i64 0, ptr %l212, !tbaa !24
  br label %bb62
bb62:
  %t285 = load i64, ptr %l212, !tbaa !24
  store i64 %t285, ptr %l209, !tbaa !24
  br label %bb63
bb63:
  %t286 = load i64, ptr %l209, !tbaa !24
  store i64 %t286, ptr %l25, !tbaa !24
  store i64 0, ptr %l26, !tbaa !24
  br label %bb64
bb64:
  store %olang.scope zeroinitializer, ptr %s9
  %t287 = load i64, ptr %l26, !tbaa !24
  %t288 = load i64, ptr %l25, !tbaa !24
  %t291 = icmp slt i64 %t287, %t288
  %t293 = xor i1 %t291, true
  br i1 %t293, label %bb65, label %bb66
bb65:
  call void @__olang_scope_close(ptr %s9)
  br label %bb163
bb66:
  br label %bb67
bb67:
  %t295 = load i64, ptr %l22, !tbaa !24
  %t296 = load i64, ptr %l26, !tbaa !24
  %t297 = load i64, ptr %l24, !tbaa !24
  %t300 = mul i64 %t296, %t297
  %t303 = add i64 %t295, %t300
  store i64 %t303, ptr %l27, !tbaa !24
  %t305 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t305, ptr %l230, !tbaa !27
  %t306 = load i64, ptr %l27, !tbaa !24
  %t308 = getelementptr { i64, ptr }, ptr %l230, i32 0, i32 1
  %t309 = load ptr, ptr %t308, !tbaa !27
  %t310 = getelementptr i32, ptr %t309, i64 %t306
  %t311 = load i32, ptr %t310, !tbaa !33
  store i32 %t311, ptr %l28, !tbaa !23
  %t313 = load ptr, ptr %l3, !tbaa !29
  %t314 = load i32, ptr %l28, !tbaa !23
  %t317 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLayout(ptr %v0, ptr %t313, i32 %t314)
  store i1 %t317, ptr %l235
  br label %bb68
bb68:
  %t318 = load ptr, ptr %l2, !tbaa !29
  %t319 = load i32, ptr %l28, !tbaa !23
  %t322 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t318, i32 %t319)
  store i32 %t322, ptr %l238
  br label %bb69
bb69:
  %t323 = load i32, ptr %l238, !tbaa !23
  store i32 %t323, ptr %l29, !tbaa !23
  %t324 = load i64, ptr %l27, !tbaa !24
  %t325 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d147, i32 0, i32 1) }, 1
  %t326 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d147, i32 0, i32 1) }, 0
  %t328 = call i64 @__olang_fmt_i64(ptr null, i64 %t324)
  %t329 = add i64 %t326, %t328
  %t330 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t329)
  call void @olang_textcopy(ptr %t330, ptr %t325, i64 %t326)
  %t331 = getelementptr i8, ptr %t330, i64 %t326
  %t332 = call i64 @__olang_fmt_i64(ptr %t331, i64 %t324)
  %t333 = insertvalue { i64, ptr } undef, i64 %t329, 0
  %t334 = insertvalue { i64, ptr } %t333, ptr %t330, 1
  store { i64, ptr } %t334, ptr %l30, !tbaa !27
  %t336 = load ptr, ptr %l2, !tbaa !29
  %t337 = load i32, ptr %l29, !tbaa !23
  %t340 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t336, i32 %t337)
  store i1 %t340, ptr %l243
  br label %bb70
bb70:
  %t341 = load i1, ptr %l243, !tbaa !21
  br i1 %t341, label %bb71, label %bb72
bb71:
  %t342 = load ptr, ptr %l2, !tbaa !29
  store ptr %t342, ptr %l244, !tbaa !29
  %t343 = load ptr, ptr %l2, !tbaa !29
  %t344 = load i32, ptr %l29, !tbaa !23
  %t347 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t343, i32 %t344)
  store i32 %t347, ptr %l247
  br label %bb73
bb72:
  br label %bb90
bb73:
  %t348 = load ptr, ptr %l244, !tbaa !29
  %t349 = load i32, ptr %l247, !tbaa !23
  %t350 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t348, i32 %t349)
  store i32 %t350, ptr %l248
  br label %bb74
bb74:
  %t351 = load i32, ptr %l248, !tbaa !23
  store i32 %t351, ptr %l31, !tbaa !23
  %t352 = load ptr, ptr %l2, !tbaa !29
  %t353 = load i32, ptr %l31, !tbaa !23
  %t356 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t352, i32 %t353)
  store i32 %t356, ptr %l251
  br label %bb75
bb75:
  %t357 = load i32, ptr %l251
  %t359 = trunc i64 19 to i32
  %t360 = icmp eq i32 %t357, %t359
  br i1 %t360, label %bb76, label %bb77
bb76:
  %t362 = load ptr, ptr %l2, !tbaa !29
  %t363 = load i32, ptr %l31, !tbaa !23
  %t366 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t362, i32 %t363)
  store i32 %t366, ptr %l257
  br label %bb78
bb77:
  store i1 false, ptr %l254, !tbaa !21
  br label %bb79
bb78:
  %t367 = load i32, ptr %l257, !tbaa !23
  %t368 = icmp eq i32 %t367, 0
  store i1 %t368, ptr %l254, !tbaa !21
  br label %bb79
bb79:
  %t370 = load i1, ptr %l254, !tbaa !21
  br i1 %t370, label %bb80, label %bb81
bb80:
  store %olang.scope zeroinitializer, ptr %s12
  %t371 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t372 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d148, i32 0, i32 1) }, 1
  %t373 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d148, i32 0, i32 1) }, 0
  %t375 = extractvalue { i64, ptr } %t371, 1
  %t376 = extractvalue { i64, ptr } %t371, 0
  %t377 = add i64 %t373, %t376
  %t378 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t377)
  call void @olang_textcopy(ptr %t378, ptr %t372, i64 %t373)
  %t379 = getelementptr i8, ptr %t378, i64 %t373
  call void @olang_textcopy(ptr %t379, ptr %t375, i64 %t376)
  %t380 = insertvalue { i64, ptr } undef, i64 %t377, 0
  %t381 = insertvalue { i64, ptr } %t380, ptr %t378, 1
  %t383 = extractvalue { i64, ptr } %t381, 0
  %t384 = extractvalue { i64, ptr } %t381, 1
  %t385 = mul i64 %t383, 1
  %t386 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t385)
  call void @llvm.memcpy.p0.p0.i64(ptr %t386, ptr %t384, i64 %t385, i1 false)
  %t387 = insertvalue { i64, ptr } undef, i64 %t383, 0
  %t388 = insertvalue { i64, ptr } %t387, ptr %t386, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l17, { i64, ptr } %t388)
  br label %bb82
bb81:
  %t391 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t392 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d149, i32 0, i32 1) }, 1
  %t393 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d149, i32 0, i32 1) }, 0
  %t395 = extractvalue { i64, ptr } %t391, 1
  %t396 = extractvalue { i64, ptr } %t391, 0
  %t397 = add i64 %t393, %t396
  %t398 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t397)
  call void @olang_textcopy(ptr %t398, ptr %t392, i64 %t393)
  %t399 = getelementptr i8, ptr %t398, i64 %t393
  call void @olang_textcopy(ptr %t399, ptr %t395, i64 %t396)
  %t400 = insertvalue { i64, ptr } undef, i64 %t397, 0
  %t401 = insertvalue { i64, ptr } %t400, ptr %t398, 1
  %t403 = extractvalue { i64, ptr } %t401, 0
  %t404 = extractvalue { i64, ptr } %t401, 1
  %t405 = mul i64 %t403, 1
  %t406 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t405)
  call void @llvm.memcpy.p0.p0.i64(ptr %t406, ptr %t404, i64 %t405, i1 false)
  %t407 = insertvalue { i64, ptr } undef, i64 %t403, 0
  %t408 = insertvalue { i64, ptr } %t407, ptr %t406, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l17, { i64, ptr } %t408)
  br label %bb87
bb82:
  %t411 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t412 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d150, i32 0, i32 1) }, 1
  %t413 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d150, i32 0, i32 1) }, 0
  %t415 = extractvalue { i64, ptr } %t411, 1
  %t416 = extractvalue { i64, ptr } %t411, 0
  %t417 = add i64 %t413, %t416
  %t418 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d151, i32 0, i32 1) }, 1
  %t419 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d151, i32 0, i32 1) }, 0
  %t420 = add i64 %t417, %t419
  %t421 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t420)
  call void @olang_textcopy(ptr %t421, ptr %t412, i64 %t413)
  %t422 = getelementptr i8, ptr %t421, i64 %t413
  call void @olang_textcopy(ptr %t422, ptr %t415, i64 %t416)
  %t423 = getelementptr i8, ptr %t422, i64 %t416
  call void @olang_textcopy(ptr %t423, ptr %t418, i64 %t419)
  %t424 = insertvalue { i64, ptr } undef, i64 %t420, 0
  %t425 = insertvalue { i64, ptr } %t424, ptr %t421, 1
  %t427 = extractvalue { i64, ptr } %t425, 0
  %t428 = extractvalue { i64, ptr } %t425, 1
  %t429 = mul i64 %t427, 1
  %t430 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t429)
  call void @llvm.memcpy.p0.p0.i64(ptr %t430, ptr %t428, i64 %t429, i1 false)
  %t431 = insertvalue { i64, ptr } undef, i64 %t427, 0
  %t432 = insertvalue { i64, ptr } %t431, ptr %t430, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l17, { i64, ptr } %t432)
  br label %bb83
bb83:
  %t435 = getelementptr %"compiler/cabi:Regs", ptr %l18, i32 0, i32 0
  %t436 = load i64, ptr %t435, !tbaa !24
  %t438 = sub i64 %t436, 2
  %t440 = getelementptr %"compiler/cabi:Regs", ptr %l18, i32 0, i32 0
  store i64 %t438, ptr %t440, !tbaa !24
  %t441 = load ptr, ptr %l11, !tbaa !29
  %t442 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t443 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d152, i32 0, i32 1) }, 1
  %t444 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d152, i32 0, i32 1) }, 0
  %t446 = extractvalue { i64, ptr } %t442, 1
  %t447 = extractvalue { i64, ptr } %t442, 0
  %t448 = add i64 %t444, %t447
  %t449 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d153, i32 0, i32 1) }, 1
  %t450 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d153, i32 0, i32 1) }, 0
  %t451 = add i64 %t448, %t450
  %t452 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t451)
  call void @olang_textcopy(ptr %t452, ptr %t443, i64 %t444)
  %t453 = getelementptr i8, ptr %t452, i64 %t444
  call void @olang_textcopy(ptr %t453, ptr %t446, i64 %t447)
  %t454 = getelementptr i8, ptr %t453, i64 %t447
  call void @olang_textcopy(ptr %t454, ptr %t449, i64 %t450)
  %t455 = insertvalue { i64, ptr } undef, i64 %t451, 0
  %t456 = insertvalue { i64, ptr } %t455, ptr %t452, 1
  %t458 = extractvalue { i64, ptr } %t456, 0
  %t459 = extractvalue { i64, ptr } %t456, 1
  %t460 = mul i64 %t458, 1
  %t461 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t460)
  call void @llvm.memcpy.p0.p0.i64(ptr %t461, ptr %t459, i64 %t460, i1 false)
  %t462 = insertvalue { i64, ptr } undef, i64 %t458, 0
  %t463 = insertvalue { i64, ptr } %t462, ptr %t461, 1
  %t466 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s12, ptr %s12, ptr %t441, { i64, ptr } %t463)
  store { i64, ptr } %t466, ptr %l273
  br label %bb84
bb84:
  %t467 = load { i64, ptr }, ptr %l273, !tbaa !27
  store ptr %l19, ptr %l274, !tbaa !29
  %t468 = load ptr, ptr %l11, !tbaa !29
  %t470 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t471 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d154, i32 0, i32 1) }, 1
  %t472 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d154, i32 0, i32 1) }, 0
  %t474 = extractvalue { i64, ptr } %t467, 1
  %t475 = extractvalue { i64, ptr } %t467, 0
  %t476 = add i64 %t472, %t475
  %t477 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d155, i32 0, i32 1) }, 1
  %t478 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d155, i32 0, i32 1) }, 0
  %t479 = add i64 %t476, %t478
  %t481 = extractvalue { i64, ptr } %t470, 1
  %t482 = extractvalue { i64, ptr } %t470, 0
  %t483 = add i64 %t479, %t482
  %t484 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d156, i32 0, i32 1) }, 1
  %t485 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d156, i32 0, i32 1) }, 0
  %t486 = add i64 %t483, %t485
  %t487 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t486)
  call void @olang_textcopy(ptr %t487, ptr %t471, i64 %t472)
  %t488 = getelementptr i8, ptr %t487, i64 %t472
  call void @olang_textcopy(ptr %t488, ptr %t474, i64 %t475)
  %t489 = getelementptr i8, ptr %t488, i64 %t475
  call void @olang_textcopy(ptr %t489, ptr %t477, i64 %t478)
  %t490 = getelementptr i8, ptr %t489, i64 %t478
  call void @olang_textcopy(ptr %t490, ptr %t481, i64 %t482)
  %t491 = getelementptr i8, ptr %t490, i64 %t482
  call void @olang_textcopy(ptr %t491, ptr %t484, i64 %t485)
  %t492 = insertvalue { i64, ptr } undef, i64 %t486, 0
  %t493 = insertvalue { i64, ptr } %t492, ptr %t487, 1
  %t495 = extractvalue { i64, ptr } %t493, 0
  %t496 = extractvalue { i64, ptr } %t493, 1
  %t497 = mul i64 %t495, 1
  %t498 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t497)
  call void @llvm.memcpy.p0.p0.i64(ptr %t498, ptr %t496, i64 %t497, i1 false)
  %t499 = insertvalue { i64, ptr } undef, i64 %t495, 0
  %t500 = insertvalue { i64, ptr } %t499, ptr %t498, 1
  %t503 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s12, ptr %s12, ptr %t468, { i64, ptr } %t500)
  store { i64, ptr } %t503, ptr %l280
  br label %bb85
bb85:
  %t504 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d157, i32 0, i32 1) }, 1
  %t505 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d157, i32 0, i32 1) }, 0
  %t506 = load { i64, ptr }, ptr %l280, !tbaa !27
  %t507 = extractvalue { i64, ptr } %t506, 1
  %t508 = extractvalue { i64, ptr } %t506, 0
  %t509 = add i64 %t505, %t508
  %t510 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t509)
  call void @olang_textcopy(ptr %t510, ptr %t504, i64 %t505)
  %t511 = getelementptr i8, ptr %t510, i64 %t505
  call void @olang_textcopy(ptr %t511, ptr %t507, i64 %t508)
  %t512 = insertvalue { i64, ptr } undef, i64 %t509, 0
  %t513 = insertvalue { i64, ptr } %t512, ptr %t510, 1
  %t515 = extractvalue { i64, ptr } %t513, 0
  %t516 = extractvalue { i64, ptr } %t513, 1
  %t517 = mul i64 %t515, 1
  %t518 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t517)
  call void @llvm.memcpy.p0.p0.i64(ptr %t518, ptr %t516, i64 %t517, i1 false)
  %t519 = insertvalue { i64, ptr } undef, i64 %t515, 0
  %t520 = insertvalue { i64, ptr } %t519, ptr %t518, 1
  %t521 = load ptr, ptr %l274, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t521, { i64, ptr } %t520)
  br label %bb86
bb86:
  call void @__olang_scope_close(ptr %s12)
  br label %bb89
bb87:
  %t523 = getelementptr %"compiler/cabi:Regs", ptr %l18, i32 0, i32 0
  %t524 = load i64, ptr %t523, !tbaa !24
  %t526 = sub i64 %t524, 1
  %t528 = getelementptr %"compiler/cabi:Regs", ptr %l18, i32 0, i32 0
  store i64 %t526, ptr %t528, !tbaa !24
  %t529 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t530 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d158, i32 0, i32 1) }, 1
  %t531 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d158, i32 0, i32 1) }, 0
  %t533 = extractvalue { i64, ptr } %t529, 1
  %t534 = extractvalue { i64, ptr } %t529, 0
  %t535 = add i64 %t531, %t534
  %t536 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t535)
  call void @olang_textcopy(ptr %t536, ptr %t530, i64 %t531)
  %t537 = getelementptr i8, ptr %t536, i64 %t531
  call void @olang_textcopy(ptr %t537, ptr %t533, i64 %t534)
  %t538 = insertvalue { i64, ptr } undef, i64 %t535, 0
  %t539 = insertvalue { i64, ptr } %t538, ptr %t536, 1
  %t541 = extractvalue { i64, ptr } %t539, 0
  %t542 = extractvalue { i64, ptr } %t539, 1
  %t543 = mul i64 %t541, 1
  %t544 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t543)
  call void @llvm.memcpy.p0.p0.i64(ptr %t544, ptr %t542, i64 %t543, i1 false)
  %t545 = insertvalue { i64, ptr } undef, i64 %t541, 0
  %t546 = insertvalue { i64, ptr } %t545, ptr %t544, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l19, { i64, ptr } %t546)
  br label %bb88
bb88:
  br label %bb89
bb89:
  call void @__olang_scope_close(ptr %s9)
  br label %bb162
bb90:
  %t549 = load ptr, ptr %l2, !tbaa !29
  %t550 = load ptr, ptr %l0, !tbaa !29
  %t552 = getelementptr %"compiler/emit:Emitter", ptr %t550, i32 0, i32 45
  %t553 = load { i64, ptr }, ptr %t552, !tbaa !27
  %t554 = load i32, ptr %l28, !tbaa !23
  %t559 = call %"compiler/cabi:Way" @compiler_2fcabi_2eParam(ptr %v0, ptr %v0, ptr %s0, ptr %s9, ptr %t549, { i64, ptr } %t553, i32 %t554, ptr %l18)
  store %"compiler/cabi:Way" %t559, ptr %l298
  br label %bb91
bb91:
  %t560 = load %"compiler/cabi:Way", ptr %l298
  store %"compiler/cabi:Way" %t560, ptr %l33
  %t561 = getelementptr %"compiler/cabi:Way", ptr %l33, i32 0, i32 0
  %t562 = load i32, ptr %t561
  store i32 %t562, ptr %l34
  %t564 = load i32, ptr %l34
  %t566 = trunc i64 0 to i32
  %t567 = icmp eq i32 %t564, %t566
  br i1 %t567, label %bb92, label %bb93
bb92:
  br label %bb94
bb93:
  br label %bb103
bb94:
  store %olang.scope zeroinitializer, ptr %s21
  store ptr %l17, ptr %l302, !tbaa !29
  %t569 = load ptr, ptr %l0, !tbaa !29
  %t570 = load i32, ptr %l28, !tbaa !23
  %t573 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %s21, ptr %t569, i32 %t570)
  store { i64, ptr } %t573, ptr %l305
  br label %bb95
bb95:
  %t574 = getelementptr %"compiler/cabi:Way", ptr %l33, i32 0, i32 4
  %t575 = load { i64, ptr }, ptr %t574, !tbaa !27
  %t577 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s9, ptr %s21, { i64, ptr } %t575, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d159, i32 0, i32 1) })
  store i1 %t577, ptr %l307
  br label %bb96
bb96:
  %t578 = load i1, ptr %l307, !tbaa !21
  %t579 = xor i1 %t578, true
  br i1 %t579, label %bb97, label %bb98
bb97:
  %t581 = getelementptr %"compiler/cabi:Way", ptr %l33, i32 0, i32 4
  %t582 = load { i64, ptr }, ptr %t581, !tbaa !27
  %t583 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d160, i32 0, i32 1) }, 1
  %t584 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d160, i32 0, i32 1) }, 0
  %t586 = extractvalue { i64, ptr } %t582, 1
  %t587 = extractvalue { i64, ptr } %t582, 0
  %t588 = add i64 %t584, %t587
  %t589 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t588)
  call void @olang_textcopy(ptr %t589, ptr %t583, i64 %t584)
  %t590 = getelementptr i8, ptr %t589, i64 %t584
  call void @olang_textcopy(ptr %t590, ptr %t586, i64 %t587)
  %t591 = insertvalue { i64, ptr } undef, i64 %t588, 0
  %t592 = insertvalue { i64, ptr } %t591, ptr %t589, 1
  %t594 = extractvalue { i64, ptr } %t592, 0
  %t595 = extractvalue { i64, ptr } %t592, 1
  %t596 = mul i64 %t594, 1
  %t597 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t596)
  call void @llvm.memcpy.p0.p0.i64(ptr %t597, ptr %t595, i64 %t596, i1 false)
  %t598 = insertvalue { i64, ptr } undef, i64 %t594, 0
  %t599 = insertvalue { i64, ptr } %t598, ptr %t597, 1
  store { i64, ptr } %t599, ptr %l309, !tbaa !27
  br label %bb99
bb98:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d161, i32 0, i32 1) }, ptr %l309, !tbaa !27
  br label %bb99
bb99:
  %t601 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t602 = load { i64, ptr }, ptr %l305, !tbaa !27
  %t603 = extractvalue { i64, ptr } %t602, 1
  %t604 = extractvalue { i64, ptr } %t602, 0
  %t605 = load { i64, ptr }, ptr %l309, !tbaa !27
  %t606 = extractvalue { i64, ptr } %t605, 1
  %t607 = extractvalue { i64, ptr } %t605, 0
  %t608 = add i64 %t604, %t607
  %t609 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d162, i32 0, i32 1) }, 1
  %t610 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d162, i32 0, i32 1) }, 0
  %t611 = add i64 %t608, %t610
  %t613 = extractvalue { i64, ptr } %t601, 1
  %t614 = extractvalue { i64, ptr } %t601, 0
  %t615 = add i64 %t611, %t614
  %t616 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t615)
  call void @olang_textcopy(ptr %t616, ptr %t603, i64 %t604)
  %t617 = getelementptr i8, ptr %t616, i64 %t604
  call void @olang_textcopy(ptr %t617, ptr %t606, i64 %t607)
  %t618 = getelementptr i8, ptr %t617, i64 %t607
  call void @olang_textcopy(ptr %t618, ptr %t609, i64 %t610)
  %t619 = getelementptr i8, ptr %t618, i64 %t610
  call void @olang_textcopy(ptr %t619, ptr %t613, i64 %t614)
  %t620 = insertvalue { i64, ptr } undef, i64 %t615, 0
  %t621 = insertvalue { i64, ptr } %t620, ptr %t616, 1
  %t623 = extractvalue { i64, ptr } %t621, 0
  %t624 = extractvalue { i64, ptr } %t621, 1
  %t625 = mul i64 %t623, 1
  %t626 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t625)
  call void @llvm.memcpy.p0.p0.i64(ptr %t626, ptr %t624, i64 %t625, i1 false)
  %t627 = insertvalue { i64, ptr } undef, i64 %t623, 0
  %t628 = insertvalue { i64, ptr } %t627, ptr %t626, 1
  %t629 = load ptr, ptr %l302, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t629, { i64, ptr } %t628)
  br label %bb100
bb100:
  store ptr %l19, ptr %l316, !tbaa !29
  %t631 = load ptr, ptr %l0, !tbaa !29
  %t632 = load i32, ptr %l28, !tbaa !23
  %t635 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %s21, ptr %t631, i32 %t632)
  store { i64, ptr } %t635, ptr %l319
  br label %bb101
bb101:
  %t636 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t637 = load { i64, ptr }, ptr %l319, !tbaa !27
  %t638 = extractvalue { i64, ptr } %t637, 1
  %t639 = extractvalue { i64, ptr } %t637, 0
  %t640 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d163, i32 0, i32 1) }, 1
  %t641 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d163, i32 0, i32 1) }, 0
  %t642 = add i64 %t639, %t641
  %t644 = extractvalue { i64, ptr } %t636, 1
  %t645 = extractvalue { i64, ptr } %t636, 0
  %t646 = add i64 %t642, %t645
  %t647 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t646)
  call void @olang_textcopy(ptr %t647, ptr %t638, i64 %t639)
  %t648 = getelementptr i8, ptr %t647, i64 %t639
  call void @olang_textcopy(ptr %t648, ptr %t640, i64 %t641)
  %t649 = getelementptr i8, ptr %t648, i64 %t641
  call void @olang_textcopy(ptr %t649, ptr %t644, i64 %t645)
  %t650 = insertvalue { i64, ptr } undef, i64 %t646, 0
  %t651 = insertvalue { i64, ptr } %t650, ptr %t647, 1
  %t653 = extractvalue { i64, ptr } %t651, 0
  %t654 = extractvalue { i64, ptr } %t651, 1
  %t655 = mul i64 %t653, 1
  %t656 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t655)
  call void @llvm.memcpy.p0.p0.i64(ptr %t656, ptr %t654, i64 %t655, i1 false)
  %t657 = insertvalue { i64, ptr } undef, i64 %t653, 0
  %t658 = insertvalue { i64, ptr } %t657, ptr %t656, 1
  %t659 = load ptr, ptr %l316, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t659, { i64, ptr } %t658)
  br label %bb102
bb102:
  call void @__olang_scope_close(ptr %s21)
  call void @__olang_scope_close(ptr %s9)
  br label %bb162
bb103:
  %t661 = load i32, ptr %l34
  %t663 = trunc i64 1 to i32
  %t664 = icmp eq i32 %t661, %t663
  br i1 %t664, label %bb104, label %bb105
bb104:
  br label %bb106
bb105:
  br label %bb136
bb106:
  store %olang.scope zeroinitializer, ptr %s25
  %t666 = load ptr, ptr %l11, !tbaa !29
  store ptr %t666, ptr %l325, !tbaa !29
  %t667 = load ptr, ptr %l2, !tbaa !29
  %t668 = load i32, ptr %l28, !tbaa !23
  %t672 = call i64 @compiler_2fcabi_2eSpan(ptr %v0, ptr %s9, ptr %t667, ptr %l33, i32 %t668)
  store i64 %t672, ptr %l329
  br label %bb107
bb107:
  %t673 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d164, i32 0, i32 1) }, 1
  %t674 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d164, i32 0, i32 1) }, 0
  %t675 = load i64, ptr %l329, !tbaa !24
  %t676 = call i64 @__olang_fmt_i64(ptr null, i64 %t675)
  %t677 = add i64 %t674, %t676
  %t678 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d165, i32 0, i32 1) }, 1
  %t679 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d165, i32 0, i32 1) }, 0
  %t680 = add i64 %t677, %t679
  %t681 = call ptr @__olang_scope_alloc(ptr %s25, i64 %t680)
  call void @olang_textcopy(ptr %t681, ptr %t673, i64 %t674)
  %t682 = getelementptr i8, ptr %t681, i64 %t674
  %t683 = call i64 @__olang_fmt_i64(ptr %t682, i64 %t675)
  %t684 = getelementptr i8, ptr %t682, i64 %t676
  call void @olang_textcopy(ptr %t684, ptr %t678, i64 %t679)
  %t685 = insertvalue { i64, ptr } undef, i64 %t680, 0
  %t686 = insertvalue { i64, ptr } %t685, ptr %t681, 1
  %t688 = extractvalue { i64, ptr } %t686, 0
  %t689 = extractvalue { i64, ptr } %t686, 1
  %t690 = mul i64 %t688, 1
  %t691 = call ptr @__olang_scope_alloc(ptr %s25, i64 %t690)
  call void @llvm.memcpy.p0.p0.i64(ptr %t691, ptr %t689, i64 %t690, i1 false)
  %t692 = insertvalue { i64, ptr } undef, i64 %t688, 0
  %t693 = insertvalue { i64, ptr } %t692, ptr %t691, 1
  %t694 = load ptr, ptr %l325, !tbaa !29
  %t696 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ealloca(ptr %v0, ptr %s25, ptr %s25, ptr %t694, { i64, ptr } %t693, i64 8)
  store { i64, ptr } %t696, ptr %l332
  br label %bb108
bb108:
  %t697 = load { i64, ptr }, ptr %l332, !tbaa !27
  store { i64, ptr } %t697, ptr %l35, !tbaa !27
  store i64 0, ptr %l36, !tbaa !24
  %t698 = getelementptr %"compiler/cabi:Way", ptr %l33, i32 0, i32 1
  %t700 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s9, ptr %t698)
  store i64 %t700, ptr %l334
  br label %bb109
bb109:
  %t701 = load i64, ptr %l334, !tbaa !24
  store i64 %t701, ptr %l37, !tbaa !24
  store i64 1, ptr %l38, !tbaa !24
  %t702 = load i64, ptr %l37, !tbaa !24
  %t703 = load i64, ptr %l36, !tbaa !24
  %t706 = icmp sgt i64 %t702, %t703
  br i1 %t706, label %bb110, label %bb111
bb110:
  %t708 = load i64, ptr %l38, !tbaa !24
  %t710 = icmp sgt i64 %t708, 0
  br i1 %t710, label %bb112, label %bb113
bb111:
  store i64 0, ptr %l338, !tbaa !24
  br label %bb115
bb112:
  %t712 = load i64, ptr %l37, !tbaa !24
  %t713 = load i64, ptr %l36, !tbaa !24
  %t716 = sub i64 %t712, %t713
  %t717 = load i64, ptr %l38, !tbaa !24
  %t720 = add i64 %t716, %t717
  %t722 = sub i64 %t720, 1
  %t723 = load i64, ptr %l38, !tbaa !24
  %t726 = sdiv i64 %t722, %t723
  store i64 %t726, ptr %l341, !tbaa !24
  br label %bb114
bb113:
  store i64 0, ptr %l341, !tbaa !24
  br label %bb114
bb114:
  %t728 = load i64, ptr %l341, !tbaa !24
  store i64 %t728, ptr %l338, !tbaa !24
  br label %bb115
bb115:
  %t729 = load i64, ptr %l338, !tbaa !24
  store i64 %t729, ptr %l39, !tbaa !24
  store i64 0, ptr %l40, !tbaa !24
  br label %bb116
bb116:
  store %olang.scope zeroinitializer, ptr %s28
  %t730 = load i64, ptr %l40, !tbaa !24
  %t731 = load i64, ptr %l39, !tbaa !24
  %t734 = icmp slt i64 %t730, %t731
  %t736 = xor i1 %t734, true
  br i1 %t736, label %bb117, label %bb118
bb117:
  call void @__olang_scope_close(ptr %s28)
  br label %bb132
bb118:
  br label %bb119
bb119:
  %t738 = load i64, ptr %l36, !tbaa !24
  %t739 = load i64, ptr %l40, !tbaa !24
  %t740 = load i64, ptr %l38, !tbaa !24
  %t743 = mul i64 %t739, %t740
  %t746 = add i64 %t738, %t743
  store i64 %t746, ptr %l41, !tbaa !24
  store ptr %l17, ptr %l359, !tbaa !29
  %t748 = getelementptr %"compiler/cabi:Way", ptr %l33, i32 0, i32 1
  %t749 = load i64, ptr %l41, !tbaa !24
  %t752 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s9, ptr %s28, ptr %t748, i64 %t749)
  store { i64, ptr } %t752, ptr %l362
  br label %bb120
bb120:
  %t753 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t754 = load i64, ptr %l41, !tbaa !24
  %t755 = load { i64, ptr }, ptr %l362, !tbaa !27
  %t756 = extractvalue { i64, ptr } %t755, 1
  %t757 = extractvalue { i64, ptr } %t755, 0
  %t758 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d166, i32 0, i32 1) }, 1
  %t759 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d166, i32 0, i32 1) }, 0
  %t760 = add i64 %t757, %t759
  %t762 = extractvalue { i64, ptr } %t753, 1
  %t763 = extractvalue { i64, ptr } %t753, 0
  %t764 = add i64 %t760, %t763
  %t765 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d167, i32 0, i32 1) }, 1
  %t766 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d167, i32 0, i32 1) }, 0
  %t767 = add i64 %t764, %t766
  %t769 = call i64 @__olang_fmt_i64(ptr null, i64 %t754)
  %t770 = add i64 %t767, %t769
  %t771 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t770)
  call void @olang_textcopy(ptr %t771, ptr %t756, i64 %t757)
  %t772 = getelementptr i8, ptr %t771, i64 %t757
  call void @olang_textcopy(ptr %t772, ptr %t758, i64 %t759)
  %t773 = getelementptr i8, ptr %t772, i64 %t759
  call void @olang_textcopy(ptr %t773, ptr %t762, i64 %t763)
  %t774 = getelementptr i8, ptr %t773, i64 %t763
  call void @olang_textcopy(ptr %t774, ptr %t765, i64 %t766)
  %t775 = getelementptr i8, ptr %t774, i64 %t766
  %t776 = call i64 @__olang_fmt_i64(ptr %t775, i64 %t754)
  %t777 = insertvalue { i64, ptr } undef, i64 %t770, 0
  %t778 = insertvalue { i64, ptr } %t777, ptr %t771, 1
  %t780 = extractvalue { i64, ptr } %t778, 0
  %t781 = extractvalue { i64, ptr } %t778, 1
  %t782 = mul i64 %t780, 1
  %t783 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t782)
  call void @llvm.memcpy.p0.p0.i64(ptr %t783, ptr %t781, i64 %t782, i1 false)
  %t784 = insertvalue { i64, ptr } undef, i64 %t780, 0
  %t785 = insertvalue { i64, ptr } %t784, ptr %t783, 1
  %t786 = load ptr, ptr %l359, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t786, { i64, ptr } %t785)
  br label %bb121
bb121:
  %t788 = getelementptr %"compiler/cabi:Way", ptr %l33, i32 0, i32 2
  %t789 = load i64, ptr %l41, !tbaa !24
  %t792 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s9, ptr %t788, i64 %t789)
  store i64 %t792, ptr %l369
  br label %bb122
bb122:
  %t793 = load i64, ptr %l369, !tbaa !24
  %t794 = icmp eq i64 %t793, 0
  br i1 %t794, label %bb123, label %bb124
bb123:
  %t796 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t796, ptr %l371, !tbaa !27
  br label %bb127
bb124:
  %t798 = load ptr, ptr %l11, !tbaa !29
  store ptr %t798, ptr %l373, !tbaa !29
  %t799 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t799, ptr %l374, !tbaa !27
  %t800 = getelementptr %"compiler/cabi:Way", ptr %l33, i32 0, i32 2
  %t801 = load i64, ptr %l41, !tbaa !24
  %t804 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s9, ptr %t800, i64 %t801)
  store i64 %t804, ptr %l377
  br label %bb125
bb125:
  %t805 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d168, i32 0, i32 1) }, 1
  %t806 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d168, i32 0, i32 1) }, 0
  %t807 = load { i64, ptr }, ptr %l374, !tbaa !27
  %t808 = extractvalue { i64, ptr } %t807, 1
  %t809 = extractvalue { i64, ptr } %t807, 0
  %t810 = add i64 %t806, %t809
  %t811 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d169, i32 0, i32 1) }, 1
  %t812 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d169, i32 0, i32 1) }, 0
  %t813 = add i64 %t810, %t812
  %t814 = load i64, ptr %l377, !tbaa !24
  %t815 = call i64 @__olang_fmt_i64(ptr null, i64 %t814)
  %t816 = add i64 %t813, %t815
  %t817 = call ptr @__olang_scope_alloc(ptr %s28, i64 %t816)
  call void @olang_textcopy(ptr %t817, ptr %t805, i64 %t806)
  %t818 = getelementptr i8, ptr %t817, i64 %t806
  call void @olang_textcopy(ptr %t818, ptr %t808, i64 %t809)
  %t819 = getelementptr i8, ptr %t818, i64 %t809
  call void @olang_textcopy(ptr %t819, ptr %t811, i64 %t812)
  %t820 = getelementptr i8, ptr %t819, i64 %t812
  %t821 = call i64 @__olang_fmt_i64(ptr %t820, i64 %t814)
  %t822 = insertvalue { i64, ptr } undef, i64 %t816, 0
  %t823 = insertvalue { i64, ptr } %t822, ptr %t817, 1
  %t825 = extractvalue { i64, ptr } %t823, 0
  %t826 = extractvalue { i64, ptr } %t823, 1
  %t827 = mul i64 %t825, 1
  %t828 = call ptr @__olang_scope_alloc(ptr %s28, i64 %t827)
  call void @llvm.memcpy.p0.p0.i64(ptr %t828, ptr %t826, i64 %t827, i1 false)
  %t829 = insertvalue { i64, ptr } undef, i64 %t825, 0
  %t830 = insertvalue { i64, ptr } %t829, ptr %t828, 1
  %t831 = load ptr, ptr %l373, !tbaa !29
  %t833 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s28, ptr %s28, ptr %t831, { i64, ptr } %t830)
  store { i64, ptr } %t833, ptr %l380
  br label %bb126
bb126:
  %t834 = load { i64, ptr }, ptr %l380, !tbaa !27
  store { i64, ptr } %t834, ptr %l371, !tbaa !27
  br label %bb127
bb127:
  %t835 = load { i64, ptr }, ptr %l371, !tbaa !27
  store { i64, ptr } %t835, ptr %l42, !tbaa !27
  %t836 = load ptr, ptr %l11, !tbaa !29
  store ptr %t836, ptr %l381, !tbaa !29
  %t837 = getelementptr %"compiler/cabi:Way", ptr %l33, i32 0, i32 1
  %t838 = load i64, ptr %l41, !tbaa !24
  %t841 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s9, ptr %s28, ptr %t837, i64 %t838)
  store { i64, ptr } %t841, ptr %l384
  br label %bb128
bb128:
  %t842 = load { i64, ptr }, ptr %l384, !tbaa !27
  store { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d170, i32 0, i32 1) }, ptr %l386, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d171, i32 0, i32 1) }, ptr %l387, !tbaa !27
  %t844 = load { i64, ptr }, ptr %l386, !tbaa !27
  %t845 = load { i64, ptr }, ptr %l387, !tbaa !27
  %t846 = call { i64, ptr } @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eReplace_3cstd_2fprelude_2ftext_3aChar_3e(ptr %s28, ptr %s28, ptr %s28, ptr %s28, { i64, ptr } %t842, { i64, ptr } %t844, { i64, ptr } %t845)
  store { i64, ptr } %t846, ptr %l388
  br label %bb129
bb129:
  %t847 = load { i64, ptr }, ptr %l388, !tbaa !27
  %t849 = extractvalue { i64, ptr } %t847, 0
  %t850 = extractvalue { i64, ptr } %t847, 1
  %t851 = mul i64 %t849, 1
  %t852 = call ptr @__olang_scope_alloc(ptr %s28, i64 %t851)
  call void @llvm.memcpy.p0.p0.i64(ptr %t852, ptr %t850, i64 %t851, i1 false)
  %t853 = insertvalue { i64, ptr } undef, i64 %t849, 0
  %t854 = insertvalue { i64, ptr } %t853, ptr %t852, 1
  %t855 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t856 = load i64, ptr %l41, !tbaa !24
  %t858 = extractvalue { i64, ptr } %t855, 1
  %t859 = extractvalue { i64, ptr } %t855, 0
  %t860 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d172, i32 0, i32 1) }, 1
  %t861 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d172, i32 0, i32 1) }, 0
  %t862 = add i64 %t859, %t861
  %t864 = call i64 @__olang_fmt_i64(ptr null, i64 %t856)
  %t865 = add i64 %t862, %t864
  %t866 = call ptr @__olang_scope_alloc(ptr %s28, i64 %t865)
  call void @olang_textcopy(ptr %t866, ptr %t858, i64 %t859)
  %t867 = getelementptr i8, ptr %t866, i64 %t859
  call void @olang_textcopy(ptr %t867, ptr %t860, i64 %t861)
  %t868 = getelementptr i8, ptr %t867, i64 %t861
  %t869 = call i64 @__olang_fmt_i64(ptr %t868, i64 %t856)
  %t870 = insertvalue { i64, ptr } undef, i64 %t865, 0
  %t871 = insertvalue { i64, ptr } %t870, ptr %t866, 1
  %t873 = extractvalue { i64, ptr } %t871, 0
  %t874 = extractvalue { i64, ptr } %t871, 1
  %t875 = mul i64 %t873, 1
  %t876 = call ptr @__olang_scope_alloc(ptr %s28, i64 %t875)
  call void @llvm.memcpy.p0.p0.i64(ptr %t876, ptr %t874, i64 %t875, i1 false)
  %t877 = insertvalue { i64, ptr } undef, i64 %t873, 0
  %t878 = insertvalue { i64, ptr } %t877, ptr %t876, 1
  %t879 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t880 = load ptr, ptr %l381, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s28, ptr %s28, ptr %s28, ptr %s28, ptr %t880, { i64, ptr } %t854, { i64, ptr } %t878, { i64, ptr } %t879, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d173, i32 0, i32 1) })
  br label %bb130
bb130:
  call void @__olang_scope_close(ptr %s28)
  br label %bb131
bb131:
  %t884 = load i64, ptr %l40, !tbaa !24
  %t886 = add i64 %t884, 1
  store i64 %t886, ptr %l40, !tbaa !24
  br label %bb116
bb132:
  %t888 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t888, ptr %l398, !tbaa !27
  %t889 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t890 = extractvalue { i64, ptr } %t889, 0
  %t891 = load { i64, ptr }, ptr %l398, !tbaa !27
  %t892 = extractvalue { i64, ptr } %t891, 0
  store i64 %t892, ptr %l400, !tbaa !24
  %t894 = load i64, ptr %l400, !tbaa !24
  %t895 = icmp eq i64 %t890, %t894
  br i1 %t895, label %bb133, label %bb134
bb133:
  %t897 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t898 = load ptr, ptr %t897, !tbaa !27
  %t899 = getelementptr { i64, ptr }, ptr %l398, i32 0, i32 1
  %t900 = load ptr, ptr %t899, !tbaa !27
  %t901 = load i64, ptr %l400, !tbaa !24
  %t902 = mul i64 %t901, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t898, ptr %t900, i64 %t902, i1 false)
  br label %bb135
bb134:
  %t903 = load { i64, ptr }, ptr %l398, !tbaa !27
  %t904 = extractvalue { i64, ptr } %t903, 0
  store i64 %t904, ptr %l402, !tbaa !24
  %t905 = load i64, ptr %l402, !tbaa !24
  %t906 = mul i64 %t905, 1
  %t907 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t906)
  %t908 = insertvalue { i64, ptr } undef, i64 %t905, 0
  %t909 = insertvalue { i64, ptr } %t908, ptr %t907, 1
  store { i64, ptr } %t909, ptr %l403, !tbaa !27
  %t910 = getelementptr { i64, ptr }, ptr %l403, i32 0, i32 1
  %t911 = load ptr, ptr %t910, !tbaa !27
  %t912 = getelementptr { i64, ptr }, ptr %l398, i32 0, i32 1
  %t913 = load ptr, ptr %t912, !tbaa !27
  %t914 = load i64, ptr %l402, !tbaa !24
  %t915 = mul i64 %t914, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t911, ptr %t913, i64 %t915, i1 false)
  %t916 = load { i64, ptr }, ptr %l403, !tbaa !27
  store { i64, ptr } %t916, ptr %l30, !tbaa !27
  br label %bb135
bb135:
  call void @__olang_scope_close(ptr %s25)
  br label %bb150
bb136:
  %t917 = load i32, ptr %l34
  %t919 = trunc i64 2 to i32
  %t920 = icmp eq i32 %t917, %t919
  br i1 %t920, label %bb137, label %bb138
bb137:
  br label %bb139
bb138:
  br label %bb144
bb139:
  store %olang.scope zeroinitializer, ptr %s33
  store ptr %l17, ptr %l406, !tbaa !29
  %t922 = load ptr, ptr %l0, !tbaa !29
  %t923 = load i32, ptr %l28, !tbaa !23
  %t926 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %s33, ptr %t922, i32 %t923)
  store { i64, ptr } %t926, ptr %l409
  br label %bb140
bb140:
  %t927 = load ptr, ptr %l2, !tbaa !29
  %t928 = load i32, ptr %l28, !tbaa !23
  %t931 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAlign(ptr %v0, ptr %t927, i32 %t928)
  store i64 %t931, ptr %l412
  br label %bb141
bb141:
  %t932 = load i64, ptr %l412, !tbaa !24
  %t933 = call i64 @std_2fprelude_2fnumber_2eI64_2eMax_3cI64_3e(i64 %t932, i64 8)
  store i64 %t933, ptr %l413
  br label %bb142
bb142:
  %t934 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t935 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d174, i32 0, i32 1) }, 1
  %t936 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d174, i32 0, i32 1) }, 0
  %t937 = load { i64, ptr }, ptr %l409, !tbaa !27
  %t938 = extractvalue { i64, ptr } %t937, 1
  %t939 = extractvalue { i64, ptr } %t937, 0
  %t940 = add i64 %t936, %t939
  %t941 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d175, i32 0, i32 1) }, 1
  %t942 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d175, i32 0, i32 1) }, 0
  %t943 = add i64 %t940, %t942
  %t944 = load i64, ptr %l413, !tbaa !24
  %t945 = call i64 @__olang_fmt_i64(ptr null, i64 %t944)
  %t946 = add i64 %t943, %t945
  %t947 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d176, i32 0, i32 1) }, 1
  %t948 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d176, i32 0, i32 1) }, 0
  %t949 = add i64 %t946, %t948
  %t951 = extractvalue { i64, ptr } %t934, 1
  %t952 = extractvalue { i64, ptr } %t934, 0
  %t953 = add i64 %t949, %t952
  %t954 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t953)
  call void @olang_textcopy(ptr %t954, ptr %t935, i64 %t936)
  %t955 = getelementptr i8, ptr %t954, i64 %t936
  call void @olang_textcopy(ptr %t955, ptr %t938, i64 %t939)
  %t956 = getelementptr i8, ptr %t955, i64 %t939
  call void @olang_textcopy(ptr %t956, ptr %t941, i64 %t942)
  %t957 = getelementptr i8, ptr %t956, i64 %t942
  %t958 = call i64 @__olang_fmt_i64(ptr %t957, i64 %t944)
  %t959 = getelementptr i8, ptr %t957, i64 %t945
  call void @olang_textcopy(ptr %t959, ptr %t947, i64 %t948)
  %t960 = getelementptr i8, ptr %t959, i64 %t948
  call void @olang_textcopy(ptr %t960, ptr %t951, i64 %t952)
  %t961 = insertvalue { i64, ptr } undef, i64 %t953, 0
  %t962 = insertvalue { i64, ptr } %t961, ptr %t954, 1
  %t964 = extractvalue { i64, ptr } %t962, 0
  %t965 = extractvalue { i64, ptr } %t962, 1
  %t966 = mul i64 %t964, 1
  %t967 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t966)
  call void @llvm.memcpy.p0.p0.i64(ptr %t967, ptr %t965, i64 %t966, i1 false)
  %t968 = insertvalue { i64, ptr } undef, i64 %t964, 0
  %t969 = insertvalue { i64, ptr } %t968, ptr %t967, 1
  %t970 = load ptr, ptr %l406, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t970, { i64, ptr } %t969)
  br label %bb143
bb143:
  call void @__olang_scope_close(ptr %s33)
  br label %bb150
bb144:
  br i1 true, label %bb145, label %bb146
bb145:
  br label %bb147
bb146:
  br label %bb149
bb147:
  %t972 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t973 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d177, i32 0, i32 1) }, 1
  %t974 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d177, i32 0, i32 1) }, 0
  %t976 = extractvalue { i64, ptr } %t972, 1
  %t977 = extractvalue { i64, ptr } %t972, 0
  %t978 = add i64 %t974, %t977
  %t979 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t978)
  call void @olang_textcopy(ptr %t979, ptr %t973, i64 %t974)
  %t980 = getelementptr i8, ptr %t979, i64 %t974
  call void @olang_textcopy(ptr %t980, ptr %t976, i64 %t977)
  %t981 = insertvalue { i64, ptr } undef, i64 %t978, 0
  %t982 = insertvalue { i64, ptr } %t981, ptr %t979, 1
  %t984 = extractvalue { i64, ptr } %t982, 0
  %t985 = extractvalue { i64, ptr } %t982, 1
  %t986 = mul i64 %t984, 1
  %t987 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t986)
  call void @llvm.memcpy.p0.p0.i64(ptr %t987, ptr %t985, i64 %t986, i1 false)
  %t988 = insertvalue { i64, ptr } undef, i64 %t984, 0
  %t989 = insertvalue { i64, ptr } %t988, ptr %t987, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l17, { i64, ptr } %t989)
  br label %bb148
bb148:
  br label %bb150
bb149:
  call void @__olang_check_failed(ptr @olang_loc_ce3f793afe7e8735_eee0e2f7e7e28841)
  unreachable
bb150:
  %t992 = load i64, ptr %l27, !tbaa !24
  %t994 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t995 = load ptr, ptr %t994, !tbaa !27
  %t996 = getelementptr i8, ptr %t995, i64 %t992
  %t997 = load i8, ptr %t996, !tbaa !32
  %t999 = icmp eq i8 %t997, 109
  br i1 %t999, label %bb151, label %bb152
bb151:
  store %olang.scope zeroinitializer, ptr %s37
  %t1001 = load ptr, ptr %l11, !tbaa !29
  %t1002 = load i32, ptr %l28, !tbaa !23
  %t1005 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eslot(ptr %v0, ptr %s37, ptr %t1001, i32 %t1002)
  store { i64, ptr } %t1005, ptr %l426
  br label %bb153
bb152:
  store %olang.scope zeroinitializer, ptr %s39
  store ptr %l19, ptr %l437, !tbaa !29
  %t1006 = load ptr, ptr %l0, !tbaa !29
  %t1007 = load i32, ptr %l28, !tbaa !23
  %t1010 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %s39, ptr %t1006, i32 %t1007)
  store { i64, ptr } %t1010, ptr %l440
  br label %bb157
bb153:
  %t1011 = load { i64, ptr }, ptr %l426, !tbaa !27
  store { i64, ptr } %t1011, ptr %l43, !tbaa !27
  %t1012 = load ptr, ptr %l11, !tbaa !29
  store ptr %t1012, ptr %l427, !tbaa !29
  %t1013 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t1013, ptr %l428, !tbaa !27
  %t1014 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t1014, ptr %l429, !tbaa !27
  %t1015 = load ptr, ptr %l2, !tbaa !29
  %t1016 = load i32, ptr %l28, !tbaa !23
  %t1019 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSize(ptr %v0, ptr %t1015, i32 %t1016)
  store i64 %t1019, ptr %l432
  br label %bb154
bb154:
  %t1020 = load ptr, ptr %l427, !tbaa !29
  %t1021 = load { i64, ptr }, ptr %l428, !tbaa !27
  %t1022 = load { i64, ptr }, ptr %l429, !tbaa !27
  %t1023 = load i64, ptr %l432, !tbaa !24
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ememmove(ptr %v0, ptr %s37, ptr %s9, ptr %t1020, { i64, ptr } %t1021, { i64, ptr } %t1022, i64 %t1023)
  br label %bb155
bb155:
  %t1024 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t1025 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d178, i32 0, i32 1) }, 1
  %t1026 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d178, i32 0, i32 1) }, 0
  %t1028 = extractvalue { i64, ptr } %t1024, 1
  %t1029 = extractvalue { i64, ptr } %t1024, 0
  %t1030 = add i64 %t1026, %t1029
  %t1031 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1030)
  call void @olang_textcopy(ptr %t1031, ptr %t1025, i64 %t1026)
  %t1032 = getelementptr i8, ptr %t1031, i64 %t1026
  call void @olang_textcopy(ptr %t1032, ptr %t1028, i64 %t1029)
  %t1033 = insertvalue { i64, ptr } undef, i64 %t1030, 0
  %t1034 = insertvalue { i64, ptr } %t1033, ptr %t1031, 1
  %t1036 = extractvalue { i64, ptr } %t1034, 0
  %t1037 = extractvalue { i64, ptr } %t1034, 1
  %t1038 = mul i64 %t1036, 1
  %t1039 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1038)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1039, ptr %t1037, i64 %t1038, i1 false)
  %t1040 = insertvalue { i64, ptr } undef, i64 %t1036, 0
  %t1041 = insertvalue { i64, ptr } %t1040, ptr %t1039, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l19, { i64, ptr } %t1041)
  br label %bb156
bb156:
  call void @__olang_scope_close(ptr %s37)
  br label %bb161
bb157:
  %t1044 = load ptr, ptr %l11, !tbaa !29
  store ptr %t1044, ptr %l441, !tbaa !29
  %t1045 = load ptr, ptr %l0, !tbaa !29
  %t1046 = load i32, ptr %l28, !tbaa !23
  %t1049 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %s39, ptr %t1045, i32 %t1046)
  store { i64, ptr } %t1049, ptr %l444
  br label %bb158
bb158:
  %t1050 = load { i64, ptr }, ptr %l444, !tbaa !27
  %t1051 = extractvalue { i64, ptr } %t1050, 0
  %t1052 = extractvalue { i64, ptr } %t1050, 1
  %t1053 = mul i64 %t1051, 1
  %t1054 = call ptr @__olang_scope_alloc(ptr %s39, i64 %t1053)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1054, ptr %t1052, i64 %t1053, i1 false)
  %t1055 = insertvalue { i64, ptr } undef, i64 %t1051, 0
  %t1056 = insertvalue { i64, ptr } %t1055, ptr %t1054, 1
  %t1057 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t1058 = load ptr, ptr %l441, !tbaa !29
  %t1061 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %s39, ptr %s9, ptr %s39, ptr %s39, ptr %t1058, { i64, ptr } %t1056, { i64, ptr } %t1057, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d179, i32 0, i32 1) })
  store { i64, ptr } %t1061, ptr %l447
  br label %bb159
bb159:
  %t1062 = load { i64, ptr }, ptr %l440, !tbaa !27
  %t1063 = extractvalue { i64, ptr } %t1062, 1
  %t1064 = extractvalue { i64, ptr } %t1062, 0
  %t1065 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d180, i32 0, i32 1) }, 1
  %t1066 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d180, i32 0, i32 1) }, 0
  %t1067 = add i64 %t1064, %t1066
  %t1068 = load { i64, ptr }, ptr %l447, !tbaa !27
  %t1069 = extractvalue { i64, ptr } %t1068, 1
  %t1070 = extractvalue { i64, ptr } %t1068, 0
  %t1071 = add i64 %t1067, %t1070
  %t1072 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1071)
  call void @olang_textcopy(ptr %t1072, ptr %t1063, i64 %t1064)
  %t1073 = getelementptr i8, ptr %t1072, i64 %t1064
  call void @olang_textcopy(ptr %t1073, ptr %t1065, i64 %t1066)
  %t1074 = getelementptr i8, ptr %t1073, i64 %t1066
  call void @olang_textcopy(ptr %t1074, ptr %t1069, i64 %t1070)
  %t1075 = insertvalue { i64, ptr } undef, i64 %t1071, 0
  %t1076 = insertvalue { i64, ptr } %t1075, ptr %t1072, 1
  %t1078 = extractvalue { i64, ptr } %t1076, 0
  %t1079 = extractvalue { i64, ptr } %t1076, 1
  %t1080 = mul i64 %t1078, 1
  %t1081 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1080)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1081, ptr %t1079, i64 %t1080, i1 false)
  %t1082 = insertvalue { i64, ptr } undef, i64 %t1078, 0
  %t1083 = insertvalue { i64, ptr } %t1082, ptr %t1081, 1
  %t1084 = load ptr, ptr %l437, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t1084, { i64, ptr } %t1083)
  br label %bb160
bb160:
  call void @__olang_scope_close(ptr %s39)
  br label %bb161
bb161:
  call void @__olang_scope_close(ptr %s9)
  br label %bb162
bb162:
  %t1086 = load i64, ptr %l26, !tbaa !24
  %t1088 = add i64 %t1086, 1
  store i64 %t1088, ptr %l26, !tbaa !24
  br label %bb64
bb163:
  %t1090 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t1090, ptr %l44, !tbaa !23
  %t1092 = load i1, ptr %l15, !tbaa !21
  br i1 %t1092, label %bb164, label %bb165
bb164:
  %t1094 = load ptr, ptr %l2, !tbaa !29
  store ptr %t1094, ptr %l454, !tbaa !29
  %t1095 = load ptr, ptr %l2, !tbaa !29
  store ptr %t1095, ptr %l455, !tbaa !29
  %t1096 = load ptr, ptr %l0, !tbaa !29
  %t1097 = load i32, ptr %l12, !tbaa !23
  %t1100 = call i32 @compiler_2femit_2ecompiler_2femit_3aEmitter_2earrayOfE(ptr %v0, ptr %t1096, i32 %t1097)
  store i32 %t1100, ptr %l458
  br label %bb166
bb165:
  %t1101 = load i1, ptr %l14, !tbaa !21
  br i1 %t1101, label %bb176, label %bb177
bb166:
  %t1103 = load ptr, ptr %l455, !tbaa !29
  %t1104 = load i32, ptr %l458, !tbaa !23
  %t1105 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t1103, i32 %t1104)
  store i32 %t1105, ptr %l459
  br label %bb167
bb167:
  %t1106 = load ptr, ptr %l454, !tbaa !29
  %t1107 = load i32, ptr %l459, !tbaa !23
  %t1108 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t1106, i32 %t1107)
  store i32 %t1108, ptr %l460
  br label %bb168
bb168:
  %t1109 = load i32, ptr %l460, !tbaa !23
  store i32 %t1109, ptr %l44, !tbaa !23
  %t1110 = load ptr, ptr %l3, !tbaa !29
  %t1111 = load i32, ptr %l44, !tbaa !23
  %t1114 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLayout(ptr %v0, ptr %t1110, i32 %t1111)
  store i1 %t1114, ptr %l463
  br label %bb169
bb169:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l17, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d181, i32 0, i32 1) })
  br label %bb170
bb170:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l17, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d182, i32 0, i32 1) })
  br label %bb171
bb171:
  %t1117 = load i1, ptr %l14, !tbaa !21
  br i1 %t1117, label %bb172, label %bb173
bb172:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l17, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d183, i32 0, i32 1) })
  br label %bb174
bb173:
  br label %bb175
bb174:
  br label %bb175
bb175:
  br label %bb183
bb176:
  %t1120 = load i1, ptr %l13, !tbaa !21
  store i1 %t1120, ptr %l469, !tbaa !21
  br label %bb178
bb177:
  store i1 false, ptr %l469, !tbaa !21
  br label %bb178
bb178:
  %t1122 = load i1, ptr %l469, !tbaa !21
  br i1 %t1122, label %bb179, label %bb180
bb179:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l17, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d184, i32 0, i32 1) })
  br label %bb181
bb180:
  br label %bb182
bb181:
  br label %bb182
bb182:
  br label %bb183
bb183:
  %t1124 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edefine(ptr %v0, ptr %s0, ptr %s0, ptr %t1124, { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d185, i32 0, i32 1) }, { i64, ptr } { i64 61, ptr getelementptr inbounds (<{ i64, [61 x i8] }>, ptr @.d186, i32 0, i32 1) })
  br label %bb184
bb184:
  %t1126 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %s0, ptr %t1126, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d187, i32 0, i32 1) })
  br label %bb185
bb185:
  %t1128 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %s0, ptr %t1128, { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d188, i32 0, i32 1) })
  br label %bb186
bb186:
  %t1130 = load ptr, ptr %l11, !tbaa !29
  %t1132 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t1130, { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d189, i32 0, i32 1) })
  store { i64, ptr } %t1132, ptr %l476
  br label %bb187
bb187:
  %t1133 = load { i64, ptr }, ptr %l476, !tbaa !27
  %t1134 = load ptr, ptr %l11, !tbaa !29
  %t1136 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d190, i32 0, i32 1) }, 1
  %t1137 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d190, i32 0, i32 1) }, 0
  %t1139 = extractvalue { i64, ptr } %t1133, 1
  %t1140 = extractvalue { i64, ptr } %t1133, 0
  %t1141 = add i64 %t1137, %t1140
  %t1142 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d191, i32 0, i32 1) }, 1
  %t1143 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d191, i32 0, i32 1) }, 0
  %t1144 = add i64 %t1141, %t1143
  %t1145 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1144)
  call void @olang_textcopy(ptr %t1145, ptr %t1136, i64 %t1137)
  %t1146 = getelementptr i8, ptr %t1145, i64 %t1137
  call void @olang_textcopy(ptr %t1146, ptr %t1139, i64 %t1140)
  %t1147 = getelementptr i8, ptr %t1146, i64 %t1140
  call void @olang_textcopy(ptr %t1147, ptr %t1142, i64 %t1143)
  %t1148 = insertvalue { i64, ptr } undef, i64 %t1144, 0
  %t1149 = insertvalue { i64, ptr } %t1148, ptr %t1145, 1
  %t1151 = extractvalue { i64, ptr } %t1149, 0
  %t1152 = extractvalue { i64, ptr } %t1149, 1
  %t1153 = mul i64 %t1151, 1
  %t1154 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1153)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1154, ptr %t1152, i64 %t1153, i1 false)
  %t1155 = insertvalue { i64, ptr } undef, i64 %t1151, 0
  %t1156 = insertvalue { i64, ptr } %t1155, ptr %t1154, 1
  %t1159 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t1134, { i64, ptr } %t1156)
  store { i64, ptr } %t1159, ptr %l481
  br label %bb188
bb188:
  %t1160 = load { i64, ptr }, ptr %l481, !tbaa !27
  %t1161 = load ptr, ptr %l11, !tbaa !29
  %t1163 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d192, i32 0, i32 1) }, 1
  %t1164 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d192, i32 0, i32 1) }, 0
  %t1166 = extractvalue { i64, ptr } %t1160, 1
  %t1167 = extractvalue { i64, ptr } %t1160, 0
  %t1168 = add i64 %t1164, %t1167
  %t1169 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d193, i32 0, i32 1) }, 1
  %t1170 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d193, i32 0, i32 1) }, 0
  %t1171 = add i64 %t1168, %t1170
  %t1172 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1171)
  call void @olang_textcopy(ptr %t1172, ptr %t1163, i64 %t1164)
  %t1173 = getelementptr i8, ptr %t1172, i64 %t1164
  call void @olang_textcopy(ptr %t1173, ptr %t1166, i64 %t1167)
  %t1174 = getelementptr i8, ptr %t1173, i64 %t1167
  call void @olang_textcopy(ptr %t1174, ptr %t1169, i64 %t1170)
  %t1175 = insertvalue { i64, ptr } undef, i64 %t1171, 0
  %t1176 = insertvalue { i64, ptr } %t1175, ptr %t1172, 1
  %t1178 = extractvalue { i64, ptr } %t1176, 0
  %t1179 = extractvalue { i64, ptr } %t1176, 1
  %t1180 = mul i64 %t1178, 1
  %t1181 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1180)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1181, ptr %t1179, i64 %t1180, i1 false)
  %t1182 = insertvalue { i64, ptr } undef, i64 %t1178, 0
  %t1183 = insertvalue { i64, ptr } %t1182, ptr %t1181, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s0, ptr %t1161, { i64, ptr } %t1183)
  br label %bb189
bb189:
  %t1186 = load ptr, ptr %l11, !tbaa !29
  %t1188 = getelementptr %"compiler/emit:fnEm", ptr %t1186, i32 0, i32 5
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s0, ptr %t1188, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d194, i32 0, i32 1) })
  br label %bb190
bb190:
  %t1190 = load ptr, ptr %l11, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s0, ptr %t1190, { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d195, i32 0, i32 1) })
  br label %bb191
bb191:
  %t1192 = load ptr, ptr %l11, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s0, ptr %t1192, { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d196, i32 0, i32 1) })
  br label %bb192
bb192:
  %t1194 = load ptr, ptr %l11, !tbaa !29
  %t1196 = getelementptr %"compiler/emit:fnEm", ptr %t1194, i32 0, i32 5
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s0, ptr %t1196, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d197, i32 0, i32 1) })
  br label %bb193
bb193:
  %t1198 = load ptr, ptr %l11, !tbaa !29
  %t1200 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ealloca(ptr %v0, ptr %s0, ptr %s0, ptr %t1198, { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d198, i32 0, i32 1) }, i64 8)
  store { i64, ptr } %t1200, ptr %l493
  br label %bb194
bb194:
  %t1201 = load { i64, ptr }, ptr %l493, !tbaa !27
  store { i64, ptr } %t1201, ptr %l47, !tbaa !27
  %t1202 = load ptr, ptr %l11, !tbaa !29
  %t1203 = load { i64, ptr }, ptr %l47, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %t1202, { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d199, i32 0, i32 1) }, { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d200, i32 0, i32 1) }, { i64, ptr } %t1203, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d173, i32 0, i32 1) })
  br label %bb195
bb195:
  %t1206 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t1206, ptr %l496
  br label %bb196
bb196:
  %t1207 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l496
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t1207, ptr %l48
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d201, i32 0, i32 1) }, ptr %l497, !tbaa !27
  %t1208 = load { i64, ptr }, ptr %l497, !tbaa !27
  store { i64, ptr } %t1208, ptr %l498, !tbaa !27
  %t1209 = load { i64, ptr }, ptr %l498, !tbaa !27
  %t1210 = extractvalue { i64, ptr } %t1209, 0
  store i64 %t1210, ptr %l499, !tbaa !24
  %t1211 = load i64, ptr %l499, !tbaa !24
  %t1212 = mul i64 %t1211, 1
  %t1213 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1212)
  %t1214 = insertvalue { i64, ptr } undef, i64 %t1211, 0
  %t1215 = insertvalue { i64, ptr } %t1214, ptr %t1213, 1
  store { i64, ptr } %t1215, ptr %l500, !tbaa !27
  %t1216 = getelementptr { i64, ptr }, ptr %l500, i32 0, i32 1
  %t1217 = load ptr, ptr %t1216, !tbaa !27
  %t1218 = getelementptr { i64, ptr }, ptr %l498, i32 0, i32 1
  %t1219 = load ptr, ptr %t1218, !tbaa !27
  %t1220 = load i64, ptr %l499, !tbaa !24
  %t1221 = mul i64 %t1220, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1217, ptr %t1219, i64 %t1221, i1 false)
  %t1222 = load { i64, ptr }, ptr %l500, !tbaa !27
  store { i64, ptr } %t1222, ptr %l49, !tbaa !27
  %t1223 = load i1, ptr %l13, !tbaa !21
  br i1 %t1223, label %bb197, label %bb198
bb197:
  %t1225 = load ptr, ptr %l2, !tbaa !29
  %t1226 = load i32, ptr %l12, !tbaa !23
  %t1229 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eViaMemory(ptr %v0, ptr %t1225, i32 %t1226)
  store i1 %t1229, ptr %l505
  br label %bb199
bb198:
  store i1 false, ptr %l502, !tbaa !21
  br label %bb200
bb199:
  %t1230 = load i1, ptr %l505, !tbaa !21
  store i1 %t1230, ptr %l502, !tbaa !21
  br label %bb200
bb200:
  %t1231 = load i1, ptr %l502, !tbaa !21
  br i1 %t1231, label %bb201, label %bb202
bb201:
  %t1232 = load ptr, ptr %l11, !tbaa !29
  %t1233 = load i32, ptr %l12, !tbaa !23
  %t1236 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eslot(ptr %v0, ptr %s0, ptr %t1232, i32 %t1233)
  store { i64, ptr } %t1236, ptr %l508
  br label %bb203
bb202:
  br label %bb208
bb203:
  %t1237 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t1238 = extractvalue { i64, ptr } %t1237, 0
  %t1239 = load { i64, ptr }, ptr %l508, !tbaa !27
  %t1240 = extractvalue { i64, ptr } %t1239, 0
  store i64 %t1240, ptr %l510, !tbaa !24
  %t1242 = load i64, ptr %l510, !tbaa !24
  %t1243 = icmp eq i64 %t1238, %t1242
  br i1 %t1243, label %bb204, label %bb205
bb204:
  %t1245 = getelementptr { i64, ptr }, ptr %l49, i32 0, i32 1
  %t1246 = load ptr, ptr %t1245, !tbaa !27
  %t1247 = getelementptr { i64, ptr }, ptr %l508, i32 0, i32 1
  %t1248 = load ptr, ptr %t1247, !tbaa !27
  %t1249 = load i64, ptr %l510, !tbaa !24
  %t1250 = mul i64 %t1249, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1246, ptr %t1248, i64 %t1250, i1 false)
  br label %bb206
bb205:
  %t1251 = load { i64, ptr }, ptr %l508, !tbaa !27
  store { i64, ptr } %t1251, ptr %l49, !tbaa !27
  br label %bb206
bb206:
  %t1252 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t1253 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d202, i32 0, i32 1) }, 1
  %t1254 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d202, i32 0, i32 1) }, 0
  %t1256 = extractvalue { i64, ptr } %t1252, 1
  %t1257 = extractvalue { i64, ptr } %t1252, 0
  %t1258 = add i64 %t1254, %t1257
  %t1259 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1258)
  call void @olang_textcopy(ptr %t1259, ptr %t1253, i64 %t1254)
  %t1260 = getelementptr i8, ptr %t1259, i64 %t1254
  call void @olang_textcopy(ptr %t1260, ptr %t1256, i64 %t1257)
  %t1261 = insertvalue { i64, ptr } undef, i64 %t1258, 0
  %t1262 = insertvalue { i64, ptr } %t1261, ptr %t1259, 1
  %t1264 = extractvalue { i64, ptr } %t1262, 0
  %t1265 = extractvalue { i64, ptr } %t1262, 1
  %t1266 = mul i64 %t1264, 1
  %t1267 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1266)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1267, ptr %t1265, i64 %t1266, i1 false)
  %t1268 = insertvalue { i64, ptr } undef, i64 %t1264, 0
  %t1269 = insertvalue { i64, ptr } %t1268, ptr %t1267, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l48, { i64, ptr } %t1269)
  br label %bb207
bb207:
  br label %bb208
bb208:
  store i64 0, ptr %l50, !tbaa !24
  %t1272 = load ptr, ptr %l2, !tbaa !29
  %t1273 = load { i64, [2 x i64] }, ptr %l10
  %t1274 = load i32, ptr %l9, !tbaa !23
  store { i64, [7 x i64] } zeroinitializer, ptr %t1275
  %t1276 = getelementptr { i64, [7 x i64] }, ptr %t1275, i32 0, i32 0
  store i64 0, ptr %t1276
  %t1278 = insertvalue { { i64, [2 x i64] }, i32 } undef, { i64, [2 x i64] } %t1273, 0
  %t1280 = insertvalue { { i64, [2 x i64] }, i32 } %t1278, i32 %t1274, 1
  %t1281 = getelementptr { i64, [7 x i64] }, ptr %t1275, i32 0, i32 1
  store { { i64, [2 x i64] }, i32 } %t1280, ptr %t1281
  %t1282 = load { i64, [7 x i64] }, ptr %t1275
  %t1283 = load i32, ptr %l9, !tbaa !23
  %t1287 = call i64 @compiler_2fmir_2ePassedCount(ptr %v0, ptr %t1272, { i64, [7 x i64] } %t1282, i32 %t1283)
  store i64 %t1287, ptr %l521
  br label %bb209
bb209:
  %t1288 = load i64, ptr %l521, !tbaa !24
  store i64 %t1288, ptr %l51, !tbaa !24
  store i64 1, ptr %l52, !tbaa !24
  %t1289 = load i64, ptr %l51, !tbaa !24
  %t1290 = load i64, ptr %l50, !tbaa !24
  %t1293 = icmp sgt i64 %t1289, %t1290
  br i1 %t1293, label %bb210, label %bb211
bb210:
  %t1295 = load i64, ptr %l52, !tbaa !24
  %t1297 = icmp sgt i64 %t1295, 0
  br i1 %t1297, label %bb212, label %bb213
bb211:
  store i64 0, ptr %l525, !tbaa !24
  br label %bb215
bb212:
  %t1299 = load i64, ptr %l51, !tbaa !24
  %t1300 = load i64, ptr %l50, !tbaa !24
  %t1303 = sub i64 %t1299, %t1300
  %t1304 = load i64, ptr %l52, !tbaa !24
  %t1307 = add i64 %t1303, %t1304
  %t1309 = sub i64 %t1307, 1
  %t1310 = load i64, ptr %l52, !tbaa !24
  %t1313 = sdiv i64 %t1309, %t1310
  store i64 %t1313, ptr %l528, !tbaa !24
  br label %bb214
bb213:
  store i64 0, ptr %l528, !tbaa !24
  br label %bb214
bb214:
  %t1315 = load i64, ptr %l528, !tbaa !24
  store i64 %t1315, ptr %l525, !tbaa !24
  br label %bb215
bb215:
  %t1316 = load i64, ptr %l525, !tbaa !24
  store i64 %t1316, ptr %l53, !tbaa !24
  store i64 0, ptr %l54, !tbaa !24
  br label %bb216
bb216:
  %t1317 = load i64, ptr %l54, !tbaa !24
  %t1318 = load i64, ptr %l53, !tbaa !24
  %t1321 = icmp slt i64 %t1317, %t1318
  %t1323 = xor i1 %t1321, true
  br i1 %t1323, label %bb217, label %bb218
bb217:
  br label %bb222
bb218:
  br label %bb219
bb219:
  %t1325 = load i64, ptr %l50, !tbaa !24
  %t1326 = load i64, ptr %l54, !tbaa !24
  %t1327 = load i64, ptr %l52, !tbaa !24
  %t1330 = mul i64 %t1326, %t1327
  %t1333 = add i64 %t1325, %t1330
  store i64 %t1333, ptr %l55, !tbaa !24
  %t1335 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t1336 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d203, i32 0, i32 1) }, 1
  %t1337 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d203, i32 0, i32 1) }, 0
  %t1339 = extractvalue { i64, ptr } %t1335, 1
  %t1340 = extractvalue { i64, ptr } %t1335, 0
  %t1341 = add i64 %t1337, %t1340
  %t1342 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1341)
  call void @olang_textcopy(ptr %t1342, ptr %t1336, i64 %t1337)
  %t1343 = getelementptr i8, ptr %t1342, i64 %t1337
  call void @olang_textcopy(ptr %t1343, ptr %t1339, i64 %t1340)
  %t1344 = insertvalue { i64, ptr } undef, i64 %t1341, 0
  %t1345 = insertvalue { i64, ptr } %t1344, ptr %t1342, 1
  %t1347 = extractvalue { i64, ptr } %t1345, 0
  %t1348 = extractvalue { i64, ptr } %t1345, 1
  %t1349 = mul i64 %t1347, 1
  %t1350 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1349)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1350, ptr %t1348, i64 %t1349, i1 false)
  %t1351 = insertvalue { i64, ptr } undef, i64 %t1347, 0
  %t1352 = insertvalue { i64, ptr } %t1351, ptr %t1350, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l48, { i64, ptr } %t1352)
  br label %bb220
bb220:
  br label %bb221
bb221:
  %t1355 = load i64, ptr %l54, !tbaa !24
  %t1357 = add i64 %t1355, 1
  store i64 %t1357, ptr %l54, !tbaa !24
  br label %bb216
bb222:
  store ptr %l19, ptr %l56, !tbaa !29
  store i64 0, ptr %l57, !tbaa !24
  br label %bb223
bb223:
  %t1360 = load i64, ptr %l57, !tbaa !24
  store i64 %t1360, ptr %l553, !tbaa !24
  %t1361 = load ptr, ptr %l56, !tbaa !29
  %t1363 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %t1361)
  store i64 %t1363, ptr %l555
  br label %bb224
bb224:
  %t1364 = load i64, ptr %l553, !tbaa !24
  %t1365 = load i64, ptr %l555, !tbaa !24
  %t1366 = icmp slt i64 %t1364, %t1365
  %t1368 = xor i1 %t1366, true
  br i1 %t1368, label %bb225, label %bb226
bb225:
  br label %bb231
bb226:
  br label %bb227
bb227:
  %t1370 = load ptr, ptr %l56, !tbaa !29
  %t1371 = load i64, ptr %l57, !tbaa !24
  %t1374 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %t1370, i64 %t1371)
  store { i64, ptr } %t1374, ptr %l560
  br label %bb228
bb228:
  %t1375 = load { i64, ptr }, ptr %l560, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l48, { i64, ptr } %t1375)
  br label %bb229
bb229:
  br label %bb230
bb230:
  %t1379 = load i64, ptr %l57, !tbaa !24
  %t1381 = add i64 %t1379, 1
  store i64 %t1381, ptr %l57, !tbaa !24
  br label %bb223
bb231:
  %t1383 = load ptr, ptr %l2, !tbaa !29
  %t1384 = load i32, ptr %l9, !tbaa !23
  %t1387 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRetLlvm(ptr %v0, ptr %s0, ptr %t1383, i32 %t1384)
  store { i64, ptr } %t1387, ptr %l567
  br label %bb232
bb232:
  %t1388 = load { i64, ptr }, ptr %l567, !tbaa !27
  store { i64, ptr } %t1388, ptr %l59, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d204, i32 0, i32 1) }, ptr %l568, !tbaa !27
  %t1389 = load { i64, ptr }, ptr %l568, !tbaa !27
  store { i64, ptr } %t1389, ptr %l569, !tbaa !27
  %t1390 = load { i64, ptr }, ptr %l569, !tbaa !27
  %t1391 = extractvalue { i64, ptr } %t1390, 0
  store i64 %t1391, ptr %l570, !tbaa !24
  %t1392 = load i64, ptr %l570, !tbaa !24
  %t1393 = mul i64 %t1392, 1
  %t1394 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1393)
  %t1395 = insertvalue { i64, ptr } undef, i64 %t1392, 0
  %t1396 = insertvalue { i64, ptr } %t1395, ptr %t1394, 1
  store { i64, ptr } %t1396, ptr %l571, !tbaa !27
  %t1397 = getelementptr { i64, ptr }, ptr %l571, i32 0, i32 1
  %t1398 = load ptr, ptr %t1397, !tbaa !27
  %t1399 = getelementptr { i64, ptr }, ptr %l569, i32 0, i32 1
  %t1400 = load ptr, ptr %t1399, !tbaa !27
  %t1401 = load i64, ptr %l570, !tbaa !24
  %t1402 = mul i64 %t1401, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1398, ptr %t1400, i64 %t1402, i1 false)
  %t1403 = load { i64, ptr }, ptr %l571, !tbaa !27
  store { i64, ptr } %t1403, ptr %l60, !tbaa !27
  %t1404 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1404, ptr %l572
  br label %bb233
bb233:
  %t1405 = load %"std/prelude/text:StringBuilder", ptr %l572
  store %"std/prelude/text:StringBuilder" %t1405, ptr %l61
  store ptr %l48, ptr %l62, !tbaa !29
  store i64 0, ptr %l63, !tbaa !24
  br label %bb234
bb234:
  %t1407 = load i64, ptr %l63, !tbaa !24
  store i64 %t1407, ptr %l574, !tbaa !24
  %t1408 = load ptr, ptr %l62, !tbaa !29
  %t1410 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %t1408)
  store i64 %t1410, ptr %l576
  br label %bb235
bb235:
  %t1411 = load i64, ptr %l574, !tbaa !24
  %t1412 = load i64, ptr %l576, !tbaa !24
  %t1413 = icmp slt i64 %t1411, %t1412
  %t1415 = xor i1 %t1413, true
  br i1 %t1415, label %bb236, label %bb237
bb236:
  br label %bb246
bb237:
  br label %bb238
bb238:
  %t1417 = load i64, ptr %l63, !tbaa !24
  store i64 %t1417, ptr %l64, !tbaa !24
  %t1419 = load ptr, ptr %l62, !tbaa !29
  %t1420 = load i64, ptr %l63, !tbaa !24
  %t1423 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %t1419, i64 %t1420)
  store { i64, ptr } %t1423, ptr %l582
  br label %bb239
bb239:
  %t1424 = load { i64, ptr }, ptr %l582, !tbaa !27
  store { i64, ptr } %t1424, ptr %l65, !tbaa !27
  %t1425 = load i64, ptr %l64, !tbaa !24
  %t1427 = icmp sgt i64 %t1425, 0
  br i1 %t1427, label %bb240, label %bb241
bb240:
  store %olang.scope zeroinitializer, ptr %s59
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s59, ptr %l61, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d205, i32 0, i32 1) })
  br label %bb242
bb241:
  br label %bb243
bb242:
  call void @__olang_scope_close(ptr %s59)
  br label %bb243
bb243:
  %t1430 = load { i64, ptr }, ptr %l65, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l61, { i64, ptr } %t1430)
  br label %bb244
bb244:
  br label %bb245
bb245:
  %t1433 = load i64, ptr %l63, !tbaa !24
  %t1435 = add i64 %t1433, 1
  store i64 %t1435, ptr %l63, !tbaa !24
  br label %bb234
bb246:
  %t1437 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t1439 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t1437, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d206, i32 0, i32 1) })
  store i1 %t1439, ptr %l591
  br label %bb247
bb247:
  %t1440 = load i1, ptr %l591, !tbaa !21
  br i1 %t1440, label %bb248, label %bb249
bb248:
  store %olang.scope zeroinitializer, ptr %s61
  %t1441 = load ptr, ptr %l11, !tbaa !29
  store ptr %t1441, ptr %l592, !tbaa !29
  %t1442 = load ptr, ptr %l0, !tbaa !29
  %t1443 = load { i64, [2 x i64] }, ptr %l10
  %t1446 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2esym(ptr %v0, ptr %s61, ptr %t1442, { i64, [2 x i64] } %t1443)
  store { i64, ptr } %t1446, ptr %l595
  br label %bb250
bb249:
  store %olang.scope zeroinitializer, ptr %s63
  %t1447 = load ptr, ptr %l11, !tbaa !29
  store ptr %t1447, ptr %l600, !tbaa !29
  %t1448 = load { i64, ptr }, ptr %l59, !tbaa !27
  store { i64, ptr } %t1448, ptr %l601, !tbaa !27
  %t1449 = load ptr, ptr %l0, !tbaa !29
  %t1450 = load { i64, [2 x i64] }, ptr %l10
  %t1453 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2esym(ptr %v0, ptr %s63, ptr %t1449, { i64, [2 x i64] } %t1450)
  store { i64, ptr } %t1453, ptr %l604
  br label %bb253
bb250:
  %t1455 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s61, ptr %l61)
  store { i64, ptr } %t1455, ptr %l597
  br label %bb251
bb251:
  %t1456 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d207, i32 0, i32 1) }, 1
  %t1457 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d207, i32 0, i32 1) }, 0
  %t1458 = load { i64, ptr }, ptr %l595, !tbaa !27
  %t1459 = extractvalue { i64, ptr } %t1458, 1
  %t1460 = extractvalue { i64, ptr } %t1458, 0
  %t1461 = add i64 %t1457, %t1460
  %t1462 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d208, i32 0, i32 1) }, 1
  %t1463 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d208, i32 0, i32 1) }, 0
  %t1464 = add i64 %t1461, %t1463
  %t1465 = load { i64, ptr }, ptr %l597, !tbaa !27
  %t1466 = extractvalue { i64, ptr } %t1465, 1
  %t1467 = extractvalue { i64, ptr } %t1465, 0
  %t1468 = add i64 %t1464, %t1467
  %t1469 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d209, i32 0, i32 1) }, 1
  %t1470 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d209, i32 0, i32 1) }, 0
  %t1471 = add i64 %t1468, %t1470
  %t1472 = call ptr @__olang_scope_alloc(ptr %s61, i64 %t1471)
  call void @olang_textcopy(ptr %t1472, ptr %t1456, i64 %t1457)
  %t1473 = getelementptr i8, ptr %t1472, i64 %t1457
  call void @olang_textcopy(ptr %t1473, ptr %t1459, i64 %t1460)
  %t1474 = getelementptr i8, ptr %t1473, i64 %t1460
  call void @olang_textcopy(ptr %t1474, ptr %t1462, i64 %t1463)
  %t1475 = getelementptr i8, ptr %t1474, i64 %t1463
  call void @olang_textcopy(ptr %t1475, ptr %t1466, i64 %t1467)
  %t1476 = getelementptr i8, ptr %t1475, i64 %t1467
  call void @olang_textcopy(ptr %t1476, ptr %t1469, i64 %t1470)
  %t1477 = insertvalue { i64, ptr } undef, i64 %t1471, 0
  %t1478 = insertvalue { i64, ptr } %t1477, ptr %t1472, 1
  %t1480 = extractvalue { i64, ptr } %t1478, 0
  %t1481 = extractvalue { i64, ptr } %t1478, 1
  %t1482 = mul i64 %t1480, 1
  %t1483 = call ptr @__olang_scope_alloc(ptr %s61, i64 %t1482)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1483, ptr %t1481, i64 %t1482, i1 false)
  %t1484 = insertvalue { i64, ptr } undef, i64 %t1480, 0
  %t1485 = insertvalue { i64, ptr } %t1484, ptr %t1483, 1
  %t1486 = load ptr, ptr %l592, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s61, ptr %t1486, { i64, ptr } %t1485)
  br label %bb252
bb252:
  call void @__olang_scope_close(ptr %s61)
  br label %bb259
bb253:
  %t1489 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s63, ptr %l61)
  store { i64, ptr } %t1489, ptr %l606
  br label %bb254
bb254:
  %t1490 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d210, i32 0, i32 1) }, 1
  %t1491 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d210, i32 0, i32 1) }, 0
  %t1492 = load { i64, ptr }, ptr %l601, !tbaa !27
  %t1493 = extractvalue { i64, ptr } %t1492, 1
  %t1494 = extractvalue { i64, ptr } %t1492, 0
  %t1495 = add i64 %t1491, %t1494
  %t1496 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d211, i32 0, i32 1) }, 1
  %t1497 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d211, i32 0, i32 1) }, 0
  %t1498 = add i64 %t1495, %t1497
  %t1499 = load { i64, ptr }, ptr %l604, !tbaa !27
  %t1500 = extractvalue { i64, ptr } %t1499, 1
  %t1501 = extractvalue { i64, ptr } %t1499, 0
  %t1502 = add i64 %t1498, %t1501
  %t1503 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d212, i32 0, i32 1) }, 1
  %t1504 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d212, i32 0, i32 1) }, 0
  %t1505 = add i64 %t1502, %t1504
  %t1506 = load { i64, ptr }, ptr %l606, !tbaa !27
  %t1507 = extractvalue { i64, ptr } %t1506, 1
  %t1508 = extractvalue { i64, ptr } %t1506, 0
  %t1509 = add i64 %t1505, %t1508
  %t1510 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d213, i32 0, i32 1) }, 1
  %t1511 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d213, i32 0, i32 1) }, 0
  %t1512 = add i64 %t1509, %t1511
  %t1513 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1512)
  call void @olang_textcopy(ptr %t1513, ptr %t1490, i64 %t1491)
  %t1514 = getelementptr i8, ptr %t1513, i64 %t1491
  call void @olang_textcopy(ptr %t1514, ptr %t1493, i64 %t1494)
  %t1515 = getelementptr i8, ptr %t1514, i64 %t1494
  call void @olang_textcopy(ptr %t1515, ptr %t1496, i64 %t1497)
  %t1516 = getelementptr i8, ptr %t1515, i64 %t1497
  call void @olang_textcopy(ptr %t1516, ptr %t1500, i64 %t1501)
  %t1517 = getelementptr i8, ptr %t1516, i64 %t1501
  call void @olang_textcopy(ptr %t1517, ptr %t1503, i64 %t1504)
  %t1518 = getelementptr i8, ptr %t1517, i64 %t1504
  call void @olang_textcopy(ptr %t1518, ptr %t1507, i64 %t1508)
  %t1519 = getelementptr i8, ptr %t1518, i64 %t1508
  call void @olang_textcopy(ptr %t1519, ptr %t1510, i64 %t1511)
  %t1520 = insertvalue { i64, ptr } undef, i64 %t1512, 0
  %t1521 = insertvalue { i64, ptr } %t1520, ptr %t1513, 1
  %t1523 = extractvalue { i64, ptr } %t1521, 0
  %t1524 = extractvalue { i64, ptr } %t1521, 1
  %t1525 = mul i64 %t1523, 1
  %t1526 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1525)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1526, ptr %t1524, i64 %t1525, i1 false)
  %t1527 = insertvalue { i64, ptr } undef, i64 %t1523, 0
  %t1528 = insertvalue { i64, ptr } %t1527, ptr %t1526, 1
  %t1529 = load ptr, ptr %l600, !tbaa !29
  %t1531 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t1529, { i64, ptr } %t1528)
  store { i64, ptr } %t1531, ptr %l609
  br label %bb255
bb255:
  %t1532 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t1533 = extractvalue { i64, ptr } %t1532, 0
  %t1534 = load { i64, ptr }, ptr %l609, !tbaa !27
  %t1535 = extractvalue { i64, ptr } %t1534, 0
  store i64 %t1535, ptr %l611, !tbaa !24
  %t1537 = load i64, ptr %l611, !tbaa !24
  %t1538 = icmp eq i64 %t1533, %t1537
  br i1 %t1538, label %bb256, label %bb257
bb256:
  %t1540 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t1541 = load ptr, ptr %t1540, !tbaa !27
  %t1542 = getelementptr { i64, ptr }, ptr %l609, i32 0, i32 1
  %t1543 = load ptr, ptr %t1542, !tbaa !27
  %t1544 = load i64, ptr %l611, !tbaa !24
  %t1545 = mul i64 %t1544, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1541, ptr %t1543, i64 %t1545, i1 false)
  br label %bb258
bb257:
  %t1546 = load { i64, ptr }, ptr %l609, !tbaa !27
  store { i64, ptr } %t1546, ptr %l60, !tbaa !27
  br label %bb258
bb258:
  call void @__olang_scope_close(ptr %s63)
  br label %bb259
bb259:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d214, i32 0, i32 1) }, ptr %l613, !tbaa !27
  %t1547 = load { i64, ptr }, ptr %l613, !tbaa !27
  store { i64, ptr } %t1547, ptr %l614, !tbaa !27
  %t1548 = load { i64, ptr }, ptr %l614, !tbaa !27
  %t1549 = extractvalue { i64, ptr } %t1548, 0
  store i64 %t1549, ptr %l615, !tbaa !24
  %t1550 = load i64, ptr %l615, !tbaa !24
  %t1551 = mul i64 %t1550, 1
  %t1552 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1551)
  %t1553 = insertvalue { i64, ptr } undef, i64 %t1550, 0
  %t1554 = insertvalue { i64, ptr } %t1553, ptr %t1552, 1
  store { i64, ptr } %t1554, ptr %l616, !tbaa !27
  %t1555 = getelementptr { i64, ptr }, ptr %l616, i32 0, i32 1
  %t1556 = load ptr, ptr %t1555, !tbaa !27
  %t1557 = getelementptr { i64, ptr }, ptr %l614, i32 0, i32 1
  %t1558 = load ptr, ptr %t1557, !tbaa !27
  %t1559 = load i64, ptr %l615, !tbaa !24
  %t1560 = mul i64 %t1559, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1556, ptr %t1558, i64 %t1560, i1 false)
  %t1561 = load { i64, ptr }, ptr %l616, !tbaa !27
  store { i64, ptr } %t1561, ptr %l66, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d215, i32 0, i32 1) }, ptr %l617, !tbaa !27
  %t1562 = load { i64, ptr }, ptr %l617, !tbaa !27
  store { i64, ptr } %t1562, ptr %l618, !tbaa !27
  %t1563 = load { i64, ptr }, ptr %l618, !tbaa !27
  %t1564 = extractvalue { i64, ptr } %t1563, 0
  store i64 %t1564, ptr %l619, !tbaa !24
  %t1565 = load i64, ptr %l619, !tbaa !24
  %t1566 = mul i64 %t1565, 1
  %t1567 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1566)
  %t1568 = insertvalue { i64, ptr } undef, i64 %t1565, 0
  %t1569 = insertvalue { i64, ptr } %t1568, ptr %t1567, 1
  store { i64, ptr } %t1569, ptr %l620, !tbaa !27
  %t1570 = getelementptr { i64, ptr }, ptr %l620, i32 0, i32 1
  %t1571 = load ptr, ptr %t1570, !tbaa !27
  %t1572 = getelementptr { i64, ptr }, ptr %l618, i32 0, i32 1
  %t1573 = load ptr, ptr %t1572, !tbaa !27
  %t1574 = load i64, ptr %l619, !tbaa !24
  %t1575 = mul i64 %t1574, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1571, ptr %t1573, i64 %t1575, i1 false)
  %t1576 = load { i64, ptr }, ptr %l620, !tbaa !27
  store { i64, ptr } %t1576, ptr %l67, !tbaa !27
  %t1577 = load i1, ptr %l14, !tbaa !21
  br i1 %t1577, label %bb260, label %bb261
bb260:
  store %olang.scope zeroinitializer, ptr %s65
  %t1579 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t1581 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s65, { i64, ptr } %t1579, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d216, i32 0, i32 1) })
  store i1 %t1581, ptr %l623
  br label %bb262
bb261:
  store %olang.scope zeroinitializer, ptr %s69
  %t1582 = load i1, ptr %l13, !tbaa !21
  br i1 %t1582, label %bb284, label %bb285
bb262:
  %t1584 = load i1, ptr %l623, !tbaa !21
  %t1585 = xor i1 %t1584, true
  br i1 %t1585, label %bb263, label %bb264
bb263:
  store i1 true, ptr %l625, !tbaa !21
  br label %bb265
bb264:
  %t1587 = load i1, ptr %l13, !tbaa !21
  %t1589 = xor i1 %t1587, true
  store i1 %t1589, ptr %l625, !tbaa !21
  br label %bb265
bb265:
  %t1591 = load i1, ptr %l625, !tbaa !21
  br i1 %t1591, label %bb266, label %bb267
bb266:
  %t1592 = load { i64, ptr }, ptr %l60, !tbaa !27
  store { i64, ptr } %t1592, ptr %l628, !tbaa !27
  br label %bb269
bb267:
  %t1594 = load ptr, ptr %l11, !tbaa !29
  %t1595 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t1596 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t1597 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d217, i32 0, i32 1) }, 1
  %t1598 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d217, i32 0, i32 1) }, 0
  %t1600 = extractvalue { i64, ptr } %t1595, 1
  %t1601 = extractvalue { i64, ptr } %t1595, 0
  %t1602 = add i64 %t1598, %t1601
  %t1603 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d218, i32 0, i32 1) }, 1
  %t1604 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d218, i32 0, i32 1) }, 0
  %t1605 = add i64 %t1602, %t1604
  %t1607 = extractvalue { i64, ptr } %t1596, 1
  %t1608 = extractvalue { i64, ptr } %t1596, 0
  %t1609 = add i64 %t1605, %t1608
  %t1610 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d219, i32 0, i32 1) }, 1
  %t1611 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d219, i32 0, i32 1) }, 0
  %t1612 = add i64 %t1609, %t1611
  %t1613 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1612)
  call void @olang_textcopy(ptr %t1613, ptr %t1597, i64 %t1598)
  %t1614 = getelementptr i8, ptr %t1613, i64 %t1598
  call void @olang_textcopy(ptr %t1614, ptr %t1600, i64 %t1601)
  %t1615 = getelementptr i8, ptr %t1614, i64 %t1601
  call void @olang_textcopy(ptr %t1615, ptr %t1603, i64 %t1604)
  %t1616 = getelementptr i8, ptr %t1615, i64 %t1604
  call void @olang_textcopy(ptr %t1616, ptr %t1607, i64 %t1608)
  %t1617 = getelementptr i8, ptr %t1616, i64 %t1608
  call void @olang_textcopy(ptr %t1617, ptr %t1610, i64 %t1611)
  %t1618 = insertvalue { i64, ptr } undef, i64 %t1612, 0
  %t1619 = insertvalue { i64, ptr } %t1618, ptr %t1613, 1
  %t1621 = extractvalue { i64, ptr } %t1619, 0
  %t1622 = extractvalue { i64, ptr } %t1619, 1
  %t1623 = mul i64 %t1621, 1
  %t1624 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1623)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1624, ptr %t1622, i64 %t1623, i1 false)
  %t1625 = insertvalue { i64, ptr } undef, i64 %t1621, 0
  %t1626 = insertvalue { i64, ptr } %t1625, ptr %t1624, 1
  %t1629 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t1594, { i64, ptr } %t1626)
  store { i64, ptr } %t1629, ptr %l635
  br label %bb268
bb268:
  %t1630 = load { i64, ptr }, ptr %l635, !tbaa !27
  store { i64, ptr } %t1630, ptr %l628, !tbaa !27
  br label %bb269
bb269:
  %t1631 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t1632 = extractvalue { i64, ptr } %t1631, 0
  %t1633 = load { i64, ptr }, ptr %l628, !tbaa !27
  %t1634 = extractvalue { i64, ptr } %t1633, 0
  store i64 %t1634, ptr %l637, !tbaa !24
  %t1636 = load i64, ptr %l637, !tbaa !24
  %t1637 = icmp eq i64 %t1632, %t1636
  br i1 %t1637, label %bb270, label %bb271
bb270:
  %t1639 = getelementptr { i64, ptr }, ptr %l66, i32 0, i32 1
  %t1640 = load ptr, ptr %t1639, !tbaa !27
  %t1641 = getelementptr { i64, ptr }, ptr %l628, i32 0, i32 1
  %t1642 = load ptr, ptr %t1641, !tbaa !27
  %t1643 = load i64, ptr %l637, !tbaa !24
  %t1644 = mul i64 %t1643, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1640, ptr %t1642, i64 %t1644, i1 false)
  br label %bb272
bb271:
  %t1645 = load { i64, ptr }, ptr %l628, !tbaa !27
  store { i64, ptr } %t1645, ptr %l66, !tbaa !27
  br label %bb272
bb272:
  %t1646 = load i1, ptr %l13, !tbaa !21
  br i1 %t1646, label %bb273, label %bb274
bb273:
  %t1648 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t1650 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s65, { i64, ptr } %t1648, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d220, i32 0, i32 1) })
  store i1 %t1650, ptr %l642
  br label %bb275
bb274:
  store i1 false, ptr %l640, !tbaa !21
  br label %bb276
bb275:
  %t1651 = load i1, ptr %l642, !tbaa !21
  store i1 %t1651, ptr %l640, !tbaa !21
  br label %bb276
bb276:
  %t1652 = load i1, ptr %l640, !tbaa !21
  br i1 %t1652, label %bb277, label %bb278
bb277:
  %t1653 = load ptr, ptr %l11, !tbaa !29
  %t1654 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t1655 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t1656 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d221, i32 0, i32 1) }, 1
  %t1657 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d221, i32 0, i32 1) }, 0
  %t1659 = extractvalue { i64, ptr } %t1654, 1
  %t1660 = extractvalue { i64, ptr } %t1654, 0
  %t1661 = add i64 %t1657, %t1660
  %t1662 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d222, i32 0, i32 1) }, 1
  %t1663 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d222, i32 0, i32 1) }, 0
  %t1664 = add i64 %t1661, %t1663
  %t1666 = extractvalue { i64, ptr } %t1655, 1
  %t1667 = extractvalue { i64, ptr } %t1655, 0
  %t1668 = add i64 %t1664, %t1667
  %t1669 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d223, i32 0, i32 1) }, 1
  %t1670 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d223, i32 0, i32 1) }, 0
  %t1671 = add i64 %t1668, %t1670
  %t1672 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1671)
  call void @olang_textcopy(ptr %t1672, ptr %t1656, i64 %t1657)
  %t1673 = getelementptr i8, ptr %t1672, i64 %t1657
  call void @olang_textcopy(ptr %t1673, ptr %t1659, i64 %t1660)
  %t1674 = getelementptr i8, ptr %t1673, i64 %t1660
  call void @olang_textcopy(ptr %t1674, ptr %t1662, i64 %t1663)
  %t1675 = getelementptr i8, ptr %t1674, i64 %t1663
  call void @olang_textcopy(ptr %t1675, ptr %t1666, i64 %t1667)
  %t1676 = getelementptr i8, ptr %t1675, i64 %t1667
  call void @olang_textcopy(ptr %t1676, ptr %t1669, i64 %t1670)
  %t1677 = insertvalue { i64, ptr } undef, i64 %t1671, 0
  %t1678 = insertvalue { i64, ptr } %t1677, ptr %t1672, 1
  %t1680 = extractvalue { i64, ptr } %t1678, 0
  %t1681 = extractvalue { i64, ptr } %t1678, 1
  %t1682 = mul i64 %t1680, 1
  %t1683 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1682)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1683, ptr %t1681, i64 %t1682, i1 false)
  %t1684 = insertvalue { i64, ptr } undef, i64 %t1680, 0
  %t1685 = insertvalue { i64, ptr } %t1684, ptr %t1683, 1
  %t1688 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t1653, { i64, ptr } %t1685)
  store { i64, ptr } %t1688, ptr %l648
  br label %bb279
bb278:
  br label %bb283
bb279:
  %t1689 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t1690 = extractvalue { i64, ptr } %t1689, 0
  %t1691 = load { i64, ptr }, ptr %l648, !tbaa !27
  %t1692 = extractvalue { i64, ptr } %t1691, 0
  store i64 %t1692, ptr %l650, !tbaa !24
  %t1694 = load i64, ptr %l650, !tbaa !24
  %t1695 = icmp eq i64 %t1690, %t1694
  br i1 %t1695, label %bb280, label %bb281
bb280:
  %t1697 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t1698 = load ptr, ptr %t1697, !tbaa !27
  %t1699 = getelementptr { i64, ptr }, ptr %l648, i32 0, i32 1
  %t1700 = load ptr, ptr %t1699, !tbaa !27
  %t1701 = load i64, ptr %l650, !tbaa !24
  %t1702 = mul i64 %t1701, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1698, ptr %t1700, i64 %t1702, i1 false)
  br label %bb282
bb281:
  %t1703 = load { i64, ptr }, ptr %l648, !tbaa !27
  store { i64, ptr } %t1703, ptr %l67, !tbaa !27
  br label %bb282
bb282:
  br label %bb283
bb283:
  call void @__olang_scope_close(ptr %s65)
  br label %bb294
bb284:
  %t1704 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t1706 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s69, { i64, ptr } %t1704, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d224, i32 0, i32 1) })
  store i1 %t1706, ptr %l655
  br label %bb286
bb285:
  store i1 false, ptr %l653, !tbaa !21
  br label %bb287
bb286:
  %t1707 = load i1, ptr %l655, !tbaa !21
  store i1 %t1707, ptr %l653, !tbaa !21
  br label %bb287
bb287:
  %t1708 = load i1, ptr %l653, !tbaa !21
  br i1 %t1708, label %bb288, label %bb289
bb288:
  %t1709 = load { i64, ptr }, ptr %l60, !tbaa !27
  store { i64, ptr } %t1709, ptr %l656, !tbaa !27
  %t1710 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t1711 = extractvalue { i64, ptr } %t1710, 0
  %t1712 = load { i64, ptr }, ptr %l656, !tbaa !27
  %t1713 = extractvalue { i64, ptr } %t1712, 0
  store i64 %t1713, ptr %l658, !tbaa !24
  %t1715 = load i64, ptr %l658, !tbaa !24
  %t1716 = icmp eq i64 %t1711, %t1715
  br i1 %t1716, label %bb290, label %bb291
bb289:
  br label %bb293
bb290:
  %t1718 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t1719 = load ptr, ptr %t1718, !tbaa !27
  %t1720 = getelementptr { i64, ptr }, ptr %l656, i32 0, i32 1
  %t1721 = load ptr, ptr %t1720, !tbaa !27
  %t1722 = load i64, ptr %l658, !tbaa !24
  %t1723 = mul i64 %t1722, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1719, ptr %t1721, i64 %t1723, i1 false)
  br label %bb292
bb291:
  %t1724 = load { i64, ptr }, ptr %l656, !tbaa !27
  %t1725 = extractvalue { i64, ptr } %t1724, 0
  store i64 %t1725, ptr %l660, !tbaa !24
  %t1726 = load i64, ptr %l660, !tbaa !24
  %t1727 = mul i64 %t1726, 1
  %t1728 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1727)
  %t1729 = insertvalue { i64, ptr } undef, i64 %t1726, 0
  %t1730 = insertvalue { i64, ptr } %t1729, ptr %t1728, 1
  store { i64, ptr } %t1730, ptr %l661, !tbaa !27
  %t1731 = getelementptr { i64, ptr }, ptr %l661, i32 0, i32 1
  %t1732 = load ptr, ptr %t1731, !tbaa !27
  %t1733 = getelementptr { i64, ptr }, ptr %l656, i32 0, i32 1
  %t1734 = load ptr, ptr %t1733, !tbaa !27
  %t1735 = load i64, ptr %l660, !tbaa !24
  %t1736 = mul i64 %t1735, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1732, ptr %t1734, i64 %t1736, i1 false)
  %t1737 = load { i64, ptr }, ptr %l661, !tbaa !27
  store { i64, ptr } %t1737, ptr %l67, !tbaa !27
  br label %bb292
bb292:
  br label %bb293
bb293:
  call void @__olang_scope_close(ptr %s69)
  br label %bb294
bb294:
  %t1738 = load i1, ptr %l13, !tbaa !21
  br i1 %t1738, label %bb295, label %bb296
bb295:
  %t1740 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t1742 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t1740, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d225, i32 0, i32 1) })
  store i1 %t1742, ptr %l665
  br label %bb297
bb296:
  store i1 false, ptr %l663, !tbaa !21
  br label %bb298
bb297:
  %t1743 = load i1, ptr %l665, !tbaa !21
  %t1744 = xor i1 %t1743, true
  store i1 %t1744, ptr %l663, !tbaa !21
  br label %bb298
bb298:
  %t1746 = load i1, ptr %l663, !tbaa !21
  br i1 %t1746, label %bb299, label %bb300
bb299:
  %t1747 = load ptr, ptr %l11, !tbaa !29
  store ptr %t1747, ptr %l667, !tbaa !29
  %t1748 = load ptr, ptr %l0, !tbaa !29
  %t1749 = load i32, ptr %l12, !tbaa !23
  %t1752 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %s0, ptr %t1748, i32 %t1749)
  store { i64, ptr } %t1752, ptr %l670
  br label %bb301
bb300:
  br label %bb306
bb301:
  %t1753 = load { i64, ptr }, ptr %l670, !tbaa !27
  %t1754 = extractvalue { i64, ptr } %t1753, 0
  %t1755 = extractvalue { i64, ptr } %t1753, 1
  %t1756 = mul i64 %t1754, 1
  %t1757 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1756)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1757, ptr %t1755, i64 %t1756, i1 false)
  %t1758 = insertvalue { i64, ptr } undef, i64 %t1754, 0
  %t1759 = insertvalue { i64, ptr } %t1758, ptr %t1757, 1
  %t1760 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t1761 = load ptr, ptr %l667, !tbaa !29
  %t1764 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %t1761, { i64, ptr } %t1759, { i64, ptr } %t1760, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d179, i32 0, i32 1) })
  store { i64, ptr } %t1764, ptr %l673
  br label %bb302
bb302:
  %t1765 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t1766 = extractvalue { i64, ptr } %t1765, 0
  %t1767 = load { i64, ptr }, ptr %l673, !tbaa !27
  %t1768 = extractvalue { i64, ptr } %t1767, 0
  store i64 %t1768, ptr %l675, !tbaa !24
  %t1770 = load i64, ptr %l675, !tbaa !24
  %t1771 = icmp eq i64 %t1766, %t1770
  br i1 %t1771, label %bb303, label %bb304
bb303:
  %t1773 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t1774 = load ptr, ptr %t1773, !tbaa !27
  %t1775 = getelementptr { i64, ptr }, ptr %l673, i32 0, i32 1
  %t1776 = load ptr, ptr %t1775, !tbaa !27
  %t1777 = load i64, ptr %l675, !tbaa !24
  %t1778 = mul i64 %t1777, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1774, ptr %t1776, i64 %t1778, i1 false)
  br label %bb305
bb304:
  %t1779 = load { i64, ptr }, ptr %l673, !tbaa !27
  store { i64, ptr } %t1779, ptr %l67, !tbaa !27
  br label %bb305
bb305:
  br label %bb306
bb306:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d226, i32 0, i32 1) }, ptr %l677, !tbaa !27
  %t1780 = load { i64, ptr }, ptr %l677, !tbaa !27
  store { i64, ptr } %t1780, ptr %l678, !tbaa !27
  %t1781 = load { i64, ptr }, ptr %l678, !tbaa !27
  %t1782 = extractvalue { i64, ptr } %t1781, 0
  store i64 %t1782, ptr %l679, !tbaa !24
  %t1783 = load i64, ptr %l679, !tbaa !24
  %t1784 = mul i64 %t1783, 1
  %t1785 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1784)
  %t1786 = insertvalue { i64, ptr } undef, i64 %t1783, 0
  %t1787 = insertvalue { i64, ptr } %t1786, ptr %t1785, 1
  store { i64, ptr } %t1787, ptr %l680, !tbaa !27
  %t1788 = getelementptr { i64, ptr }, ptr %l680, i32 0, i32 1
  %t1789 = load ptr, ptr %t1788, !tbaa !27
  %t1790 = getelementptr { i64, ptr }, ptr %l678, i32 0, i32 1
  %t1791 = load ptr, ptr %t1790, !tbaa !27
  %t1792 = load i64, ptr %l679, !tbaa !24
  %t1793 = mul i64 %t1792, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1789, ptr %t1791, i64 %t1793, i1 false)
  %t1794 = load { i64, ptr }, ptr %l680, !tbaa !27
  store { i64, ptr } %t1794, ptr %l68, !tbaa !27
  %t1795 = load i1, ptr %l14, !tbaa !21
  br i1 %t1795, label %bb307, label %bb308
bb307:
  store %olang.scope zeroinitializer, ptr %s72
  %t1797 = load ptr, ptr %l11, !tbaa !29
  %t1798 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t1799 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d227, i32 0, i32 1) }, 1
  %t1800 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d227, i32 0, i32 1) }, 0
  %t1802 = extractvalue { i64, ptr } %t1798, 1
  %t1803 = extractvalue { i64, ptr } %t1798, 0
  %t1804 = add i64 %t1800, %t1803
  %t1805 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d228, i32 0, i32 1) }, 1
  %t1806 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d228, i32 0, i32 1) }, 0
  %t1807 = add i64 %t1804, %t1806
  %t1808 = call ptr @__olang_scope_alloc(ptr %s72, i64 %t1807)
  call void @olang_textcopy(ptr %t1808, ptr %t1799, i64 %t1800)
  %t1809 = getelementptr i8, ptr %t1808, i64 %t1800
  call void @olang_textcopy(ptr %t1809, ptr %t1802, i64 %t1803)
  %t1810 = getelementptr i8, ptr %t1809, i64 %t1803
  call void @olang_textcopy(ptr %t1810, ptr %t1805, i64 %t1806)
  %t1811 = insertvalue { i64, ptr } undef, i64 %t1807, 0
  %t1812 = insertvalue { i64, ptr } %t1811, ptr %t1808, 1
  %t1814 = extractvalue { i64, ptr } %t1812, 0
  %t1815 = extractvalue { i64, ptr } %t1812, 1
  %t1816 = mul i64 %t1814, 1
  %t1817 = call ptr @__olang_scope_alloc(ptr %s72, i64 %t1816)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1817, ptr %t1815, i64 %t1816, i1 false)
  %t1818 = insertvalue { i64, ptr } undef, i64 %t1814, 0
  %t1819 = insertvalue { i64, ptr } %t1818, ptr %t1817, 1
  %t1822 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s72, ptr %s72, ptr %t1797, { i64, ptr } %t1819)
  store { i64, ptr } %t1822, ptr %l686
  br label %bb309
bb308:
  br label %bb320
bb309:
  %t1823 = load { i64, ptr }, ptr %l686, !tbaa !27
  %t1824 = load ptr, ptr %l11, !tbaa !29
  %t1826 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d229, i32 0, i32 1) }, 1
  %t1827 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d229, i32 0, i32 1) }, 0
  %t1829 = extractvalue { i64, ptr } %t1823, 1
  %t1830 = extractvalue { i64, ptr } %t1823, 0
  %t1831 = add i64 %t1827, %t1830
  %t1832 = extractvalue { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d230, i32 0, i32 1) }, 1
  %t1833 = extractvalue { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d230, i32 0, i32 1) }, 0
  %t1834 = add i64 %t1831, %t1833
  %t1835 = call ptr @__olang_scope_alloc(ptr %s72, i64 %t1834)
  call void @olang_textcopy(ptr %t1835, ptr %t1826, i64 %t1827)
  %t1836 = getelementptr i8, ptr %t1835, i64 %t1827
  call void @olang_textcopy(ptr %t1836, ptr %t1829, i64 %t1830)
  %t1837 = getelementptr i8, ptr %t1836, i64 %t1830
  call void @olang_textcopy(ptr %t1837, ptr %t1832, i64 %t1833)
  %t1838 = insertvalue { i64, ptr } undef, i64 %t1834, 0
  %t1839 = insertvalue { i64, ptr } %t1838, ptr %t1835, 1
  %t1841 = extractvalue { i64, ptr } %t1839, 0
  %t1842 = extractvalue { i64, ptr } %t1839, 1
  %t1843 = mul i64 %t1841, 1
  %t1844 = call ptr @__olang_scope_alloc(ptr %s72, i64 %t1843)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1844, ptr %t1842, i64 %t1843, i1 false)
  %t1845 = insertvalue { i64, ptr } undef, i64 %t1841, 0
  %t1846 = insertvalue { i64, ptr } %t1845, ptr %t1844, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s72, ptr %t1824, { i64, ptr } %t1846)
  br label %bb310
bb310:
  %t1849 = load ptr, ptr %l11, !tbaa !29
  %t1851 = getelementptr %"compiler/emit:fnEm", ptr %t1849, i32 0, i32 5
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s72, ptr %t1851, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d231, i32 0, i32 1) })
  br label %bb311
bb311:
  %t1853 = load ptr, ptr %l11, !tbaa !29
  %t1854 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t1855 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d232, i32 0, i32 1) }, 1
  %t1856 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d232, i32 0, i32 1) }, 0
  %t1858 = extractvalue { i64, ptr } %t1854, 1
  %t1859 = extractvalue { i64, ptr } %t1854, 0
  %t1860 = add i64 %t1856, %t1859
  %t1861 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d233, i32 0, i32 1) }, 1
  %t1862 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d233, i32 0, i32 1) }, 0
  %t1863 = add i64 %t1860, %t1862
  %t1864 = call ptr @__olang_scope_alloc(ptr %s72, i64 %t1863)
  call void @olang_textcopy(ptr %t1864, ptr %t1855, i64 %t1856)
  %t1865 = getelementptr i8, ptr %t1864, i64 %t1856
  call void @olang_textcopy(ptr %t1865, ptr %t1858, i64 %t1859)
  %t1866 = getelementptr i8, ptr %t1865, i64 %t1859
  call void @olang_textcopy(ptr %t1866, ptr %t1861, i64 %t1862)
  %t1867 = insertvalue { i64, ptr } undef, i64 %t1863, 0
  %t1868 = insertvalue { i64, ptr } %t1867, ptr %t1864, 1
  %t1870 = extractvalue { i64, ptr } %t1868, 0
  %t1871 = extractvalue { i64, ptr } %t1868, 1
  %t1872 = mul i64 %t1870, 1
  %t1873 = call ptr @__olang_scope_alloc(ptr %s72, i64 %t1872)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1873, ptr %t1871, i64 %t1872, i1 false)
  %t1874 = insertvalue { i64, ptr } undef, i64 %t1870, 0
  %t1875 = insertvalue { i64, ptr } %t1874, ptr %t1873, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s72, ptr %t1853, { i64, ptr } %t1875)
  br label %bb312
bb312:
  %t1878 = load ptr, ptr %l2, !tbaa !29
  store ptr %t1878, ptr %l697, !tbaa !29
  %t1879 = load ptr, ptr %l0, !tbaa !29
  %t1881 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2femit_2ecompiler_2femit_3aEmitter_2eExportErrors(ptr %v0, ptr %s72, ptr %t1879)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t1881, ptr %l699
  br label %bb313
bb313:
  %t1882 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l699
  %t1883 = call ptr @__olang_scope_alloc_a(ptr %s72, i64 8, i64 8)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t1882, ptr %t1883
  %t1885 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eToArray_3ccompiler_2ftypes_3aTypeId_3e(ptr %s72, ptr %s72, ptr %t1883)
  store { i64, ptr } %t1885, ptr %l701
  br label %bb314
bb314:
  %t1886 = load ptr, ptr %l697, !tbaa !29
  %t1887 = load { i64, ptr }, ptr %l701, !tbaa !27
  %t1888 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s72, ptr %t1886, { i64, ptr } %t1887)
  store i32 %t1888, ptr %l702
  br label %bb315
bb315:
  %t1889 = load i32, ptr %l702, !tbaa !23
  store i32 %t1889, ptr %l70, !tbaa !23
  %t1890 = load ptr, ptr %l11, !tbaa !29
  store ptr %t1890, ptr %l703, !tbaa !29
  %t1891 = load ptr, ptr %l11, !tbaa !29
  store ptr %t1891, ptr %l704, !tbaa !29
  %t1892 = load { i64, ptr }, ptr %l66, !tbaa !27
  store { i64, ptr } %t1892, ptr %l705, !tbaa !27
  %t1893 = load ptr, ptr %l2, !tbaa !29
  %t1894 = load i32, ptr %l9, !tbaa !23
  %t1897 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t1893, i32 %t1894)
  store i32 %t1897, ptr %l708
  br label %bb316
bb316:
  %t1898 = load i32, ptr %l70, !tbaa !23
  %t1899 = load ptr, ptr %l704, !tbaa !29
  %t1900 = load { i64, ptr }, ptr %l705, !tbaa !27
  %t1901 = load i32, ptr %l708, !tbaa !23
  %t1903 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2erecode(ptr %v0, ptr %s0, ptr %s72, ptr %t1899, { i64, ptr } %t1900, i32 %t1901, i32 %t1898)
  store { i64, ptr } %t1903, ptr %l710
  br label %bb317
bb317:
  %t1904 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d234, i32 0, i32 1) }, 1
  %t1905 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d234, i32 0, i32 1) }, 0
  %t1906 = load { i64, ptr }, ptr %l710, !tbaa !27
  %t1907 = extractvalue { i64, ptr } %t1906, 1
  %t1908 = extractvalue { i64, ptr } %t1906, 0
  %t1909 = add i64 %t1905, %t1908
  %t1910 = call ptr @__olang_scope_alloc(ptr %s72, i64 %t1909)
  call void @olang_textcopy(ptr %t1910, ptr %t1904, i64 %t1905)
  %t1911 = getelementptr i8, ptr %t1910, i64 %t1905
  call void @olang_textcopy(ptr %t1911, ptr %t1907, i64 %t1908)
  %t1912 = insertvalue { i64, ptr } undef, i64 %t1909, 0
  %t1913 = insertvalue { i64, ptr } %t1912, ptr %t1910, 1
  %t1915 = extractvalue { i64, ptr } %t1913, 0
  %t1916 = extractvalue { i64, ptr } %t1913, 1
  %t1917 = mul i64 %t1915, 1
  %t1918 = call ptr @__olang_scope_alloc(ptr %s72, i64 %t1917)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1918, ptr %t1916, i64 %t1917, i1 false)
  %t1919 = insertvalue { i64, ptr } undef, i64 %t1915, 0
  %t1920 = insertvalue { i64, ptr } %t1919, ptr %t1918, 1
  %t1921 = load ptr, ptr %l703, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s72, ptr %t1921, { i64, ptr } %t1920)
  br label %bb318
bb318:
  %t1923 = load ptr, ptr %l11, !tbaa !29
  %t1925 = getelementptr %"compiler/emit:fnEm", ptr %t1923, i32 0, i32 5
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s72, ptr %t1925, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d235, i32 0, i32 1) })
  br label %bb319
bb319:
  call void @__olang_scope_close(ptr %s72)
  br label %bb320
bb320:
  %t1927 = load i1, ptr %l15, !tbaa !21
  br i1 %t1927, label %bb321, label %bb322
bb321:
  store %olang.scope zeroinitializer, ptr %s77
  %t1929 = load ptr, ptr %l11, !tbaa !29
  %t1930 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t1931 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d236, i32 0, i32 1) }, 1
  %t1932 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d236, i32 0, i32 1) }, 0
  %t1934 = extractvalue { i64, ptr } %t1930, 1
  %t1935 = extractvalue { i64, ptr } %t1930, 0
  %t1936 = add i64 %t1932, %t1935
  %t1937 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d237, i32 0, i32 1) }, 1
  %t1938 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d237, i32 0, i32 1) }, 0
  %t1939 = add i64 %t1936, %t1938
  %t1940 = call ptr @__olang_scope_alloc(ptr %s77, i64 %t1939)
  call void @olang_textcopy(ptr %t1940, ptr %t1931, i64 %t1932)
  %t1941 = getelementptr i8, ptr %t1940, i64 %t1932
  call void @olang_textcopy(ptr %t1941, ptr %t1934, i64 %t1935)
  %t1942 = getelementptr i8, ptr %t1941, i64 %t1935
  call void @olang_textcopy(ptr %t1942, ptr %t1937, i64 %t1938)
  %t1943 = insertvalue { i64, ptr } undef, i64 %t1939, 0
  %t1944 = insertvalue { i64, ptr } %t1943, ptr %t1940, 1
  %t1946 = extractvalue { i64, ptr } %t1944, 0
  %t1947 = extractvalue { i64, ptr } %t1944, 1
  %t1948 = mul i64 %t1946, 1
  %t1949 = call ptr @__olang_scope_alloc(ptr %s77, i64 %t1948)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1949, ptr %t1947, i64 %t1948, i1 false)
  %t1950 = insertvalue { i64, ptr } undef, i64 %t1946, 0
  %t1951 = insertvalue { i64, ptr } %t1950, ptr %t1949, 1
  %t1954 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s77, ptr %s77, ptr %t1929, { i64, ptr } %t1951)
  store { i64, ptr } %t1954, ptr %l720
  br label %bb323
bb322:
  %t1955 = load i1, ptr %l14, !tbaa !21
  br i1 %t1955, label %bb346, label %bb347
bb323:
  %t1957 = load { i64, ptr }, ptr %l720, !tbaa !27
  store { i64, ptr } %t1957, ptr %l71, !tbaa !27
  %t1958 = load ptr, ptr %l11, !tbaa !29
  %t1959 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t1960 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d238, i32 0, i32 1) }, 1
  %t1961 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d238, i32 0, i32 1) }, 0
  %t1963 = extractvalue { i64, ptr } %t1959, 1
  %t1964 = extractvalue { i64, ptr } %t1959, 0
  %t1965 = add i64 %t1961, %t1964
  %t1966 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d239, i32 0, i32 1) }, 1
  %t1967 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d239, i32 0, i32 1) }, 0
  %t1968 = add i64 %t1965, %t1967
  %t1969 = call ptr @__olang_scope_alloc(ptr %s77, i64 %t1968)
  call void @olang_textcopy(ptr %t1969, ptr %t1960, i64 %t1961)
  %t1970 = getelementptr i8, ptr %t1969, i64 %t1961
  call void @olang_textcopy(ptr %t1970, ptr %t1963, i64 %t1964)
  %t1971 = getelementptr i8, ptr %t1970, i64 %t1964
  call void @olang_textcopy(ptr %t1971, ptr %t1966, i64 %t1967)
  %t1972 = insertvalue { i64, ptr } undef, i64 %t1968, 0
  %t1973 = insertvalue { i64, ptr } %t1972, ptr %t1969, 1
  %t1975 = extractvalue { i64, ptr } %t1973, 0
  %t1976 = extractvalue { i64, ptr } %t1973, 1
  %t1977 = mul i64 %t1975, 1
  %t1978 = call ptr @__olang_scope_alloc(ptr %s77, i64 %t1977)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1978, ptr %t1976, i64 %t1977, i1 false)
  %t1979 = insertvalue { i64, ptr } undef, i64 %t1975, 0
  %t1980 = insertvalue { i64, ptr } %t1979, ptr %t1978, 1
  %t1983 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s77, ptr %s77, ptr %t1958, { i64, ptr } %t1980)
  store { i64, ptr } %t1983, ptr %l725
  br label %bb324
bb324:
  %t1984 = load { i64, ptr }, ptr %l725, !tbaa !27
  store { i64, ptr } %t1984, ptr %l72, !tbaa !27
  %t1985 = load ptr, ptr %l11, !tbaa !29
  %t1986 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t1987 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d240, i32 0, i32 1) }, 1
  %t1988 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d240, i32 0, i32 1) }, 0
  %t1990 = extractvalue { i64, ptr } %t1986, 1
  %t1991 = extractvalue { i64, ptr } %t1986, 0
  %t1992 = add i64 %t1988, %t1991
  %t1993 = call ptr @__olang_scope_alloc(ptr %s77, i64 %t1992)
  call void @olang_textcopy(ptr %t1993, ptr %t1987, i64 %t1988)
  %t1994 = getelementptr i8, ptr %t1993, i64 %t1988
  call void @olang_textcopy(ptr %t1994, ptr %t1990, i64 %t1991)
  %t1995 = insertvalue { i64, ptr } undef, i64 %t1992, 0
  %t1996 = insertvalue { i64, ptr } %t1995, ptr %t1993, 1
  %t1998 = extractvalue { i64, ptr } %t1996, 0
  %t1999 = extractvalue { i64, ptr } %t1996, 1
  %t2000 = mul i64 %t1998, 1
  %t2001 = call ptr @__olang_scope_alloc(ptr %s77, i64 %t2000)
  call void @llvm.memcpy.p0.p0.i64(ptr %t2001, ptr %t1999, i64 %t2000, i1 false)
  %t2002 = insertvalue { i64, ptr } undef, i64 %t1998, 0
  %t2003 = insertvalue { i64, ptr } %t2002, ptr %t2001, 1
  %t2006 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s77, ptr %s77, ptr %t1985, { i64, ptr } %t2003)
  store { i64, ptr } %t2006, ptr %l730
  br label %bb325
bb325:
  %t2007 = load { i64, ptr }, ptr %l730, !tbaa !27
  %t2008 = load ptr, ptr %l11, !tbaa !29
  %t2010 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t2011 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d241, i32 0, i32 1) }, 1
  %t2012 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d241, i32 0, i32 1) }, 0
  %t2014 = extractvalue { i64, ptr } %t2007, 1
  %t2015 = extractvalue { i64, ptr } %t2007, 0
  %t2016 = add i64 %t2012, %t2015
  %t2017 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d242, i32 0, i32 1) }, 1
  %t2018 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d242, i32 0, i32 1) }, 0
  %t2019 = add i64 %t2016, %t2018
  %t2021 = extractvalue { i64, ptr } %t2010, 1
  %t2022 = extractvalue { i64, ptr } %t2010, 0
  %t2023 = add i64 %t2019, %t2022
  %t2024 = call ptr @__olang_scope_alloc(ptr %s77, i64 %t2023)
  call void @olang_textcopy(ptr %t2024, ptr %t2011, i64 %t2012)
  %t2025 = getelementptr i8, ptr %t2024, i64 %t2012
  call void @olang_textcopy(ptr %t2025, ptr %t2014, i64 %t2015)
  %t2026 = getelementptr i8, ptr %t2025, i64 %t2015
  call void @olang_textcopy(ptr %t2026, ptr %t2017, i64 %t2018)
  %t2027 = getelementptr i8, ptr %t2026, i64 %t2018
  call void @olang_textcopy(ptr %t2027, ptr %t2021, i64 %t2022)
  %t2028 = insertvalue { i64, ptr } undef, i64 %t2023, 0
  %t2029 = insertvalue { i64, ptr } %t2028, ptr %t2024, 1
  %t2031 = extractvalue { i64, ptr } %t2029, 0
  %t2032 = extractvalue { i64, ptr } %t2029, 1
  %t2033 = mul i64 %t2031, 1
  %t2034 = call ptr @__olang_scope_alloc(ptr %s77, i64 %t2033)
  call void @llvm.memcpy.p0.p0.i64(ptr %t2034, ptr %t2032, i64 %t2033, i1 false)
  %t2035 = insertvalue { i64, ptr } undef, i64 %t2031, 0
  %t2036 = insertvalue { i64, ptr } %t2035, ptr %t2034, 1
  %t2039 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s77, ptr %s77, ptr %t2008, { i64, ptr } %t2036)
  store { i64, ptr } %t2039, ptr %l736
  br label %bb326
bb326:
  %t2040 = load { i64, ptr }, ptr %l736, !tbaa !27
  store { i64, ptr } %t2040, ptr %l74, !tbaa !27
  %t2041 = load ptr, ptr %l11, !tbaa !29
  %t2042 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t2043 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d243, i32 0, i32 1) }, 1
  %t2044 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d243, i32 0, i32 1) }, 0
  %t2046 = extractvalue { i64, ptr } %t2042, 1
  %t2047 = extractvalue { i64, ptr } %t2042, 0
  %t2048 = add i64 %t2044, %t2047
  %t2049 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d244, i32 0, i32 1) }, 1
  %t2050 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d244, i32 0, i32 1) }, 0
  %t2051 = add i64 %t2048, %t2050
  %t2052 = call ptr @__olang_scope_alloc(ptr %s77, i64 %t2051)
  call void @olang_textcopy(ptr %t2052, ptr %t2043, i64 %t2044)
  %t2053 = getelementptr i8, ptr %t2052, i64 %t2044
  call void @olang_textcopy(ptr %t2053, ptr %t2046, i64 %t2047)
  %t2054 = getelementptr i8, ptr %t2053, i64 %t2047
  call void @olang_textcopy(ptr %t2054, ptr %t2049, i64 %t2050)
  %t2055 = insertvalue { i64, ptr } undef, i64 %t2051, 0
  %t2056 = insertvalue { i64, ptr } %t2055, ptr %t2052, 1
  %t2058 = extractvalue { i64, ptr } %t2056, 0
  %t2059 = extractvalue { i64, ptr } %t2056, 1
  %t2060 = mul i64 %t2058, 1
  %t2061 = call ptr @__olang_scope_alloc(ptr %s77, i64 %t2060)
  call void @llvm.memcpy.p0.p0.i64(ptr %t2061, ptr %t2059, i64 %t2060, i1 false)
  %t2062 = insertvalue { i64, ptr } undef, i64 %t2058, 0
  %t2063 = insertvalue { i64, ptr } %t2062, ptr %t2061, 1
  %t2066 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s77, ptr %s77, ptr %t2041, { i64, ptr } %t2063)
  store { i64, ptr } %t2066, ptr %l741
  br label %bb327
bb327:
  %t2067 = load { i64, ptr }, ptr %l741, !tbaa !27
  %t2068 = load ptr, ptr %l11, !tbaa !29
  %t2070 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t2071 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d245, i32 0, i32 1) }, 1
  %t2072 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d245, i32 0, i32 1) }, 0
  %t2074 = extractvalue { i64, ptr } %t2067, 1
  %t2075 = extractvalue { i64, ptr } %t2067, 0
  %t2076 = add i64 %t2072, %t2075
  %t2077 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d246, i32 0, i32 1) }, 1
  %t2078 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d246, i32 0, i32 1) }, 0
  %t2079 = add i64 %t2076, %t2078
  %t2081 = extractvalue { i64, ptr } %t2070, 1
  %t2082 = extractvalue { i64, ptr } %t2070, 0
  %t2083 = add i64 %t2079, %t2082
  %t2084 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d247, i32 0, i32 1) }, 1
  %t2085 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d247, i32 0, i32 1) }, 0
  %t2086 = add i64 %t2083, %t2085
  %t2087 = call ptr @__olang_scope_alloc(ptr %s77, i64 %t2086)
  call void @olang_textcopy(ptr %t2087, ptr %t2071, i64 %t2072)
  %t2088 = getelementptr i8, ptr %t2087, i64 %t2072
  call void @olang_textcopy(ptr %t2088, ptr %t2074, i64 %t2075)
  %t2089 = getelementptr i8, ptr %t2088, i64 %t2075
  call void @olang_textcopy(ptr %t2089, ptr %t2077, i64 %t2078)
  %t2090 = getelementptr i8, ptr %t2089, i64 %t2078
  call void @olang_textcopy(ptr %t2090, ptr %t2081, i64 %t2082)
  %t2091 = getelementptr i8, ptr %t2090, i64 %t2082
  call void @olang_textcopy(ptr %t2091, ptr %t2084, i64 %t2085)
  %t2092 = insertvalue { i64, ptr } undef, i64 %t2086, 0
  %t2093 = insertvalue { i64, ptr } %t2092, ptr %t2087, 1
  %t2095 = extractvalue { i64, ptr } %t2093, 0
  %t2096 = extractvalue { i64, ptr } %t2093, 1
  %t2097 = mul i64 %t2095, 1
  %t2098 = call ptr @__olang_scope_alloc(ptr %s77, i64 %t2097)
  call void @llvm.memcpy.p0.p0.i64(ptr %t2098, ptr %t2096, i64 %t2097, i1 false)
  %t2099 = insertvalue { i64, ptr } undef, i64 %t2095, 0
  %t2100 = insertvalue { i64, ptr } %t2099, ptr %t2098, 1
  %t2103 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s77, ptr %s77, ptr %t2068, { i64, ptr } %t2100)
  store { i64, ptr } %t2103, ptr %l747
  br label %bb328
bb328:
  %t2104 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t2105 = extractvalue { i64, ptr } %t2104, 0
  %t2106 = load { i64, ptr }, ptr %l747, !tbaa !27
  %t2107 = extractvalue { i64, ptr } %t2106, 0
  store i64 %t2107, ptr %l749, !tbaa !24
  %t2109 = load i64, ptr %l749, !tbaa !24
  %t2110 = icmp eq i64 %t2105, %t2109
  br i1 %t2110, label %bb329, label %bb330
bb329:
  %t2112 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t2113 = load ptr, ptr %t2112, !tbaa !27
  %t2114 = getelementptr { i64, ptr }, ptr %l747, i32 0, i32 1
  %t2115 = load ptr, ptr %t2114, !tbaa !27
  %t2116 = load i64, ptr %l749, !tbaa !24
  %t2117 = mul i64 %t2116, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t2113, ptr %t2115, i64 %t2117, i1 false)
  br label %bb331
bb330:
  %t2118 = load { i64, ptr }, ptr %l747, !tbaa !27
  store { i64, ptr } %t2118, ptr %l74, !tbaa !27
  br label %bb331
bb331:
  %t2119 = load ptr, ptr %l11, !tbaa !29
  store ptr %t2119, ptr %l751, !tbaa !29
  %t2120 = load { i64, ptr }, ptr %l74, !tbaa !27
  store { i64, ptr } %t2120, ptr %l752, !tbaa !27
  %t2121 = load ptr, ptr %l2, !tbaa !29
  %t2122 = load i32, ptr %l44, !tbaa !23
  %t2125 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSize(ptr %v0, ptr %t2121, i32 %t2122)
  store i64 %t2125, ptr %l755
  br label %bb332
bb332:
  %t2126 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d248, i32 0, i32 1) }, 1
  %t2127 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d248, i32 0, i32 1) }, 0
  %t2128 = load { i64, ptr }, ptr %l752, !tbaa !27
  %t2129 = extractvalue { i64, ptr } %t2128, 1
  %t2130 = extractvalue { i64, ptr } %t2128, 0
  %t2131 = add i64 %t2127, %t2130
  %t2132 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d249, i32 0, i32 1) }, 1
  %t2133 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d249, i32 0, i32 1) }, 0
  %t2134 = add i64 %t2131, %t2133
  %t2135 = load i64, ptr %l755, !tbaa !24
  %t2136 = call i64 @__olang_fmt_i64(ptr null, i64 %t2135)
  %t2137 = add i64 %t2134, %t2136
  %t2138 = call ptr @__olang_scope_alloc(ptr %s77, i64 %t2137)
  call void @olang_textcopy(ptr %t2138, ptr %t2126, i64 %t2127)
  %t2139 = getelementptr i8, ptr %t2138, i64 %t2127
  call void @olang_textcopy(ptr %t2139, ptr %t2129, i64 %t2130)
  %t2140 = getelementptr i8, ptr %t2139, i64 %t2130
  call void @olang_textcopy(ptr %t2140, ptr %t2132, i64 %t2133)
  %t2141 = getelementptr i8, ptr %t2140, i64 %t2133
  %t2142 = call i64 @__olang_fmt_i64(ptr %t2141, i64 %t2135)
  %t2143 = insertvalue { i64, ptr } undef, i64 %t2137, 0
  %t2144 = insertvalue { i64, ptr } %t2143, ptr %t2138, 1
  %t2146 = extractvalue { i64, ptr } %t2144, 0
  %t2147 = extractvalue { i64, ptr } %t2144, 1
  %t2148 = mul i64 %t2146, 1
  %t2149 = call ptr @__olang_scope_alloc(ptr %s77, i64 %t2148)
  call void @llvm.memcpy.p0.p0.i64(ptr %t2149, ptr %t2147, i64 %t2148, i1 false)
  %t2150 = insertvalue { i64, ptr } undef, i64 %t2146, 0
  %t2151 = insertvalue { i64, ptr } %t2150, ptr %t2149, 1
  %t2152 = load ptr, ptr %l751, !tbaa !29
  %t2154 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s77, ptr %s77, ptr %t2152, { i64, ptr } %t2151)
  store { i64, ptr } %t2154, ptr %l758
  br label %bb333
bb333:
  %t2155 = load { i64, ptr }, ptr %l758, !tbaa !27
  store { i64, ptr } %t2155, ptr %l76, !tbaa !27
  %t2156 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s77, ptr %s77, ptr %t2156, { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d250, i32 0, i32 1) }, { i64, ptr } { i64 47, ptr getelementptr inbounds (<{ i64, [47 x i8] }>, ptr @.d251, i32 0, i32 1) })
  br label %bb334
bb334:
  %t2158 = load ptr, ptr %l11, !tbaa !29
  %t2159 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t2160 = load { i64, ptr }, ptr %l76, !tbaa !27
  %t2161 = extractvalue { i64, ptr } { i64 48, ptr getelementptr inbounds (<{ i64, [48 x i8] }>, ptr @.d252, i32 0, i32 1) }, 1
  %t2162 = extractvalue { i64, ptr } { i64 48, ptr getelementptr inbounds (<{ i64, [48 x i8] }>, ptr @.d252, i32 0, i32 1) }, 0
  %t2164 = extractvalue { i64, ptr } %t2159, 1
  %t2165 = extractvalue { i64, ptr } %t2159, 0
  %t2166 = add i64 %t2162, %t2165
  %t2167 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d253, i32 0, i32 1) }, 1
  %t2168 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d253, i32 0, i32 1) }, 0
  %t2169 = add i64 %t2166, %t2168
  %t2171 = extractvalue { i64, ptr } %t2160, 1
  %t2172 = extractvalue { i64, ptr } %t2160, 0
  %t2173 = add i64 %t2169, %t2172
  %t2174 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d254, i32 0, i32 1) }, 1
  %t2175 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d254, i32 0, i32 1) }, 0
  %t2176 = add i64 %t2173, %t2175
  %t2177 = call ptr @__olang_scope_alloc(ptr %s77, i64 %t2176)
  call void @olang_textcopy(ptr %t2177, ptr %t2161, i64 %t2162)
  %t2178 = getelementptr i8, ptr %t2177, i64 %t2162
  call void @olang_textcopy(ptr %t2178, ptr %t2164, i64 %t2165)
  %t2179 = getelementptr i8, ptr %t2178, i64 %t2165
  call void @olang_textcopy(ptr %t2179, ptr %t2167, i64 %t2168)
  %t2180 = getelementptr i8, ptr %t2179, i64 %t2168
  call void @olang_textcopy(ptr %t2180, ptr %t2171, i64 %t2172)
  %t2181 = getelementptr i8, ptr %t2180, i64 %t2172
  call void @olang_textcopy(ptr %t2181, ptr %t2174, i64 %t2175)
  %t2182 = insertvalue { i64, ptr } undef, i64 %t2176, 0
  %t2183 = insertvalue { i64, ptr } %t2182, ptr %t2177, 1
  %t2185 = extractvalue { i64, ptr } %t2183, 0
  %t2186 = extractvalue { i64, ptr } %t2183, 1
  %t2187 = mul i64 %t2185, 1
  %t2188 = call ptr @__olang_scope_alloc(ptr %s77, i64 %t2187)
  call void @llvm.memcpy.p0.p0.i64(ptr %t2188, ptr %t2186, i64 %t2187, i1 false)
  %t2189 = insertvalue { i64, ptr } undef, i64 %t2185, 0
  %t2190 = insertvalue { i64, ptr } %t2189, ptr %t2188, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s77, ptr %t2158, { i64, ptr } %t2190)
  br label %bb335
bb335:
  %t2193 = load i1, ptr %l14, !tbaa !21
  br i1 %t2193, label %bb336, label %bb337
bb336:
  store %olang.scope zeroinitializer, ptr %s86
  %t2195 = load ptr, ptr %l11, !tbaa !29
  %t2196 = load { i64, ptr }, ptr %l71, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s86, ptr %s77, ptr %s86, ptr %s86, ptr %t2195, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d255, i32 0, i32 1) }, { i64, ptr } %t2196, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d256, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d173, i32 0, i32 1) })
  br label %bb338
bb337:
  %t2199 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t2200 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d257, i32 0, i32 1) }, 1
  %t2201 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d257, i32 0, i32 1) }, 0
  %t2203 = extractvalue { i64, ptr } %t2199, 1
  %t2204 = extractvalue { i64, ptr } %t2199, 0
  %t2205 = add i64 %t2201, %t2204
  %t2206 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t2205)
  call void @olang_textcopy(ptr %t2206, ptr %t2200, i64 %t2201)
  %t2207 = getelementptr i8, ptr %t2206, i64 %t2201
  call void @olang_textcopy(ptr %t2207, ptr %t2203, i64 %t2204)
  %t2208 = insertvalue { i64, ptr } undef, i64 %t2205, 0
  %t2209 = insertvalue { i64, ptr } %t2208, ptr %t2206, 1
  store { i64, ptr } %t2209, ptr %l776, !tbaa !27
  %t2210 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t2211 = extractvalue { i64, ptr } %t2210, 0
  %t2212 = load { i64, ptr }, ptr %l776, !tbaa !27
  %t2213 = extractvalue { i64, ptr } %t2212, 0
  store i64 %t2213, ptr %l778, !tbaa !24
  %t2215 = load i64, ptr %l778, !tbaa !24
  %t2216 = icmp eq i64 %t2211, %t2215
  br i1 %t2216, label %bb342, label %bb343
bb338:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d258, i32 0, i32 1) }, ptr %l768, !tbaa !27
  %t2218 = load { i64, ptr }, ptr %l768, !tbaa !27
  store { i64, ptr } %t2218, ptr %l769, !tbaa !27
  %t2219 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t2220 = extractvalue { i64, ptr } %t2219, 0
  %t2221 = load { i64, ptr }, ptr %l769, !tbaa !27
  %t2222 = extractvalue { i64, ptr } %t2221, 0
  store i64 %t2222, ptr %l771, !tbaa !24
  %t2224 = load i64, ptr %l771, !tbaa !24
  %t2225 = icmp eq i64 %t2220, %t2224
  br i1 %t2225, label %bb339, label %bb340
bb339:
  %t2227 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t2228 = load ptr, ptr %t2227, !tbaa !27
  %t2229 = getelementptr { i64, ptr }, ptr %l769, i32 0, i32 1
  %t2230 = load ptr, ptr %t2229, !tbaa !27
  %t2231 = load i64, ptr %l771, !tbaa !24
  %t2232 = mul i64 %t2231, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t2228, ptr %t2230, i64 %t2232, i1 false)
  br label %bb341
bb340:
  %t2233 = load { i64, ptr }, ptr %l769, !tbaa !27
  %t2234 = extractvalue { i64, ptr } %t2233, 0
  store i64 %t2234, ptr %l773, !tbaa !24
  %t2235 = load i64, ptr %l773, !tbaa !24
  %t2236 = mul i64 %t2235, 1
  %t2237 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t2236)
  %t2238 = insertvalue { i64, ptr } undef, i64 %t2235, 0
  %t2239 = insertvalue { i64, ptr } %t2238, ptr %t2237, 1
  store { i64, ptr } %t2239, ptr %l774, !tbaa !27
  %t2240 = getelementptr { i64, ptr }, ptr %l774, i32 0, i32 1
  %t2241 = load ptr, ptr %t2240, !tbaa !27
  %t2242 = getelementptr { i64, ptr }, ptr %l769, i32 0, i32 1
  %t2243 = load ptr, ptr %t2242, !tbaa !27
  %t2244 = load i64, ptr %l773, !tbaa !24
  %t2245 = mul i64 %t2244, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t2241, ptr %t2243, i64 %t2245, i1 false)
  %t2246 = load { i64, ptr }, ptr %l774, !tbaa !27
  store { i64, ptr } %t2246, ptr %l68, !tbaa !27
  br label %bb341
bb341:
  call void @__olang_scope_close(ptr %s86)
  br label %bb345
bb342:
  %t2247 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t2248 = load ptr, ptr %t2247, !tbaa !27
  %t2249 = getelementptr { i64, ptr }, ptr %l776, i32 0, i32 1
  %t2250 = load ptr, ptr %t2249, !tbaa !27
  %t2251 = load i64, ptr %l778, !tbaa !24
  %t2252 = mul i64 %t2251, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t2248, ptr %t2250, i64 %t2252, i1 false)
  br label %bb344
bb343:
  %t2253 = load { i64, ptr }, ptr %l776, !tbaa !27
  store { i64, ptr } %t2253, ptr %l68, !tbaa !27
  br label %bb344
bb344:
  br label %bb345
bb345:
  call void @__olang_scope_close(ptr %s77)
  br label %bb421
bb346:
  %t2254 = load i1, ptr %l13, !tbaa !21
  br i1 %t2254, label %bb348, label %bb349
bb347:
  %t2256 = load i1, ptr %l13, !tbaa !21
  br i1 %t2256, label %bb356, label %bb357
bb348:
  store %olang.scope zeroinitializer, ptr %s91
  %t2258 = load ptr, ptr %l11, !tbaa !29
  store ptr %t2258, ptr %l782, !tbaa !29
  %t2259 = load ptr, ptr %l0, !tbaa !29
  %t2260 = load i32, ptr %l12, !tbaa !23
  %t2263 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %s91, ptr %t2259, i32 %t2260)
  store { i64, ptr } %t2263, ptr %l785
  br label %bb350
bb349:
  br label %bb352
bb350:
  %t2264 = load { i64, ptr }, ptr %l785, !tbaa !27
  %t2265 = extractvalue { i64, ptr } %t2264, 0
  %t2266 = extractvalue { i64, ptr } %t2264, 1
  %t2267 = mul i64 %t2265, 1
  %t2268 = call ptr @__olang_scope_alloc(ptr %s91, i64 %t2267)
  call void @llvm.memcpy.p0.p0.i64(ptr %t2268, ptr %t2266, i64 %t2267, i1 false)
  %t2269 = insertvalue { i64, ptr } undef, i64 %t2265, 0
  %t2270 = insertvalue { i64, ptr } %t2269, ptr %t2268, 1
  %t2271 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t2272 = load ptr, ptr %l782, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s91, ptr %s0, ptr %s91, ptr %s91, ptr %t2272, { i64, ptr } %t2270, { i64, ptr } %t2271, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d259, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d173, i32 0, i32 1) })
  br label %bb351
bb351:
  call void @__olang_scope_close(ptr %s91)
  br label %bb352
bb352:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d260, i32 0, i32 1) }, ptr %l788, !tbaa !27
  %t2275 = load { i64, ptr }, ptr %l788, !tbaa !27
  store { i64, ptr } %t2275, ptr %l789, !tbaa !27
  %t2276 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t2277 = extractvalue { i64, ptr } %t2276, 0
  %t2278 = load { i64, ptr }, ptr %l789, !tbaa !27
  %t2279 = extractvalue { i64, ptr } %t2278, 0
  store i64 %t2279, ptr %l791, !tbaa !24
  %t2281 = load i64, ptr %l791, !tbaa !24
  %t2282 = icmp eq i64 %t2277, %t2281
  br i1 %t2282, label %bb353, label %bb354
bb353:
  %t2284 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t2285 = load ptr, ptr %t2284, !tbaa !27
  %t2286 = getelementptr { i64, ptr }, ptr %l789, i32 0, i32 1
  %t2287 = load ptr, ptr %t2286, !tbaa !27
  %t2288 = load i64, ptr %l791, !tbaa !24
  %t2289 = mul i64 %t2288, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t2285, ptr %t2287, i64 %t2289, i1 false)
  br label %bb355
bb354:
  %t2290 = load { i64, ptr }, ptr %l789, !tbaa !27
  %t2291 = extractvalue { i64, ptr } %t2290, 0
  store i64 %t2291, ptr %l793, !tbaa !24
  %t2292 = load i64, ptr %l793, !tbaa !24
  %t2293 = mul i64 %t2292, 1
  %t2294 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t2293)
  %t2295 = insertvalue { i64, ptr } undef, i64 %t2292, 0
  %t2296 = insertvalue { i64, ptr } %t2295, ptr %t2294, 1
  store { i64, ptr } %t2296, ptr %l794, !tbaa !27
  %t2297 = getelementptr { i64, ptr }, ptr %l794, i32 0, i32 1
  %t2298 = load ptr, ptr %t2297, !tbaa !27
  %t2299 = getelementptr { i64, ptr }, ptr %l789, i32 0, i32 1
  %t2300 = load ptr, ptr %t2299, !tbaa !27
  %t2301 = load i64, ptr %l793, !tbaa !24
  %t2302 = mul i64 %t2301, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t2298, ptr %t2300, i64 %t2302, i1 false)
  %t2303 = load { i64, ptr }, ptr %l794, !tbaa !27
  store { i64, ptr } %t2303, ptr %l68, !tbaa !27
  br label %bb355
bb355:
  br label %bb420
bb356:
  %t2304 = getelementptr %"compiler/cabi:Way", ptr %l16, i32 0, i32 0
  %t2305 = load i32, ptr %t2304
  store i32 %t2305, ptr %l77
  %t2307 = load i32, ptr %l77
  %t2309 = trunc i64 0 to i32
  %t2310 = icmp eq i32 %t2307, %t2309
  br i1 %t2310, label %bb358, label %bb359
bb357:
  br label %bb419
bb358:
  br label %bb360
bb359:
  br label %bb365
bb360:
  store %olang.scope zeroinitializer, ptr %s94
  %t2312 = load ptr, ptr %l0, !tbaa !29
  %t2313 = load i32, ptr %l12, !tbaa !23
  %t2316 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %s94, ptr %t2312, i32 %t2313)
  store { i64, ptr } %t2316, ptr %l801
  br label %bb361
bb361:
  %t2317 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t2318 = load { i64, ptr }, ptr %l801, !tbaa !27
  %t2319 = extractvalue { i64, ptr } %t2318, 1
  %t2320 = extractvalue { i64, ptr } %t2318, 0
  %t2321 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d261, i32 0, i32 1) }, 1
  %t2322 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d261, i32 0, i32 1) }, 0
  %t2323 = add i64 %t2320, %t2322
  %t2325 = extractvalue { i64, ptr } %t2317, 1
  %t2326 = extractvalue { i64, ptr } %t2317, 0
  %t2327 = add i64 %t2323, %t2326
  %t2328 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t2327)
  call void @olang_textcopy(ptr %t2328, ptr %t2319, i64 %t2320)
  %t2329 = getelementptr i8, ptr %t2328, i64 %t2320
  call void @olang_textcopy(ptr %t2329, ptr %t2321, i64 %t2322)
  %t2330 = getelementptr i8, ptr %t2329, i64 %t2322
  call void @olang_textcopy(ptr %t2330, ptr %t2325, i64 %t2326)
  %t2331 = insertvalue { i64, ptr } undef, i64 %t2327, 0
  %t2332 = insertvalue { i64, ptr } %t2331, ptr %t2328, 1
  store { i64, ptr } %t2332, ptr %l803, !tbaa !27
  %t2333 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t2334 = extractvalue { i64, ptr } %t2333, 0
  %t2335 = load { i64, ptr }, ptr %l803, !tbaa !27
  %t2336 = extractvalue { i64, ptr } %t2335, 0
  store i64 %t2336, ptr %l805, !tbaa !24
  %t2338 = load i64, ptr %l805, !tbaa !24
  %t2339 = icmp eq i64 %t2334, %t2338
  br i1 %t2339, label %bb362, label %bb363
bb362:
  %t2341 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t2342 = load ptr, ptr %t2341, !tbaa !27
  %t2343 = getelementptr { i64, ptr }, ptr %l803, i32 0, i32 1
  %t2344 = load ptr, ptr %t2343, !tbaa !27
  %t2345 = load i64, ptr %l805, !tbaa !24
  %t2346 = mul i64 %t2345, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t2342, ptr %t2344, i64 %t2346, i1 false)
  br label %bb364
bb363:
  %t2347 = load { i64, ptr }, ptr %l803, !tbaa !27
  store { i64, ptr } %t2347, ptr %l68, !tbaa !27
  br label %bb364
bb364:
  call void @__olang_scope_close(ptr %s94)
  br label %bb418
bb365:
  %t2348 = load i32, ptr %l77
  %t2350 = trunc i64 1 to i32
  %t2351 = icmp eq i32 %t2348, %t2350
  br i1 %t2351, label %bb366, label %bb367
bb366:
  br label %bb368
bb367:
  br label %bb411
bb368:
  store %olang.scope zeroinitializer, ptr %s96
  %t2353 = load ptr, ptr %l11, !tbaa !29
  store ptr %t2353, ptr %l809, !tbaa !29
  %t2354 = load ptr, ptr %l2, !tbaa !29
  %t2355 = load i32, ptr %l12, !tbaa !23
  %t2359 = call i64 @compiler_2fcabi_2eSpan(ptr %v0, ptr %s0, ptr %t2354, ptr %l16, i32 %t2355)
  store i64 %t2359, ptr %l813
  br label %bb369
bb369:
  %t2360 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d262, i32 0, i32 1) }, 1
  %t2361 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d262, i32 0, i32 1) }, 0
  %t2362 = load i64, ptr %l813, !tbaa !24
  %t2363 = call i64 @__olang_fmt_i64(ptr null, i64 %t2362)
  %t2364 = add i64 %t2361, %t2363
  %t2365 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d263, i32 0, i32 1) }, 1
  %t2366 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d263, i32 0, i32 1) }, 0
  %t2367 = add i64 %t2364, %t2366
  %t2368 = call ptr @__olang_scope_alloc(ptr %s96, i64 %t2367)
  call void @olang_textcopy(ptr %t2368, ptr %t2360, i64 %t2361)
  %t2369 = getelementptr i8, ptr %t2368, i64 %t2361
  %t2370 = call i64 @__olang_fmt_i64(ptr %t2369, i64 %t2362)
  %t2371 = getelementptr i8, ptr %t2369, i64 %t2363
  call void @olang_textcopy(ptr %t2371, ptr %t2365, i64 %t2366)
  %t2372 = insertvalue { i64, ptr } undef, i64 %t2367, 0
  %t2373 = insertvalue { i64, ptr } %t2372, ptr %t2368, 1
  %t2375 = extractvalue { i64, ptr } %t2373, 0
  %t2376 = extractvalue { i64, ptr } %t2373, 1
  %t2377 = mul i64 %t2375, 1
  %t2378 = call ptr @__olang_scope_alloc(ptr %s96, i64 %t2377)
  call void @llvm.memcpy.p0.p0.i64(ptr %t2378, ptr %t2376, i64 %t2377, i1 false)
  %t2379 = insertvalue { i64, ptr } undef, i64 %t2375, 0
  %t2380 = insertvalue { i64, ptr } %t2379, ptr %t2378, 1
  %t2381 = load ptr, ptr %l809, !tbaa !29
  %t2383 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ealloca(ptr %v0, ptr %s96, ptr %s96, ptr %t2381, { i64, ptr } %t2380, i64 8)
  store { i64, ptr } %t2383, ptr %l816
  br label %bb370
bb370:
  %t2384 = load { i64, ptr }, ptr %l816, !tbaa !27
  store { i64, ptr } %t2384, ptr %l78, !tbaa !27
  %t2385 = load ptr, ptr %l11, !tbaa !29
  store ptr %t2385, ptr %l817, !tbaa !29
  %t2386 = load ptr, ptr %l0, !tbaa !29
  %t2387 = load i32, ptr %l12, !tbaa !23
  %t2390 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %s96, ptr %t2386, i32 %t2387)
  store { i64, ptr } %t2390, ptr %l820
  br label %bb371
bb371:
  %t2391 = load { i64, ptr }, ptr %l820, !tbaa !27
  %t2392 = extractvalue { i64, ptr } %t2391, 0
  %t2393 = extractvalue { i64, ptr } %t2391, 1
  %t2394 = mul i64 %t2392, 1
  %t2395 = call ptr @__olang_scope_alloc(ptr %s96, i64 %t2394)
  call void @llvm.memcpy.p0.p0.i64(ptr %t2395, ptr %t2393, i64 %t2394, i1 false)
  %t2396 = insertvalue { i64, ptr } undef, i64 %t2392, 0
  %t2397 = insertvalue { i64, ptr } %t2396, ptr %t2395, 1
  %t2398 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t2399 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t2400 = load ptr, ptr %l817, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s96, ptr %s0, ptr %s96, ptr %s96, ptr %t2400, { i64, ptr } %t2397, { i64, ptr } %t2398, { i64, ptr } %t2399, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d173, i32 0, i32 1) })
  br label %bb372
bb372:
  %t2405 = call { i64, ptr } @compiler_2fcabi_2ePartsType(ptr %s0, ptr %s96, ptr %l16)
  store { i64, ptr } %t2405, ptr %l825
  br label %bb373
bb373:
  %t2406 = load { i64, ptr }, ptr %l825, !tbaa !27
  store { i64, ptr } %t2406, ptr %l79, !tbaa !27
  %t2407 = getelementptr %"compiler/cabi:Way", ptr %l16, i32 0, i32 1
  %t2409 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %t2407)
  store i64 %t2409, ptr %l827
  br label %bb374
bb374:
  %t2410 = load i64, ptr %l827, !tbaa !24
  %t2411 = icmp eq i64 %t2410, 1
  br i1 %t2411, label %bb375, label %bb376
bb375:
  store %olang.scope zeroinitializer, ptr %s98
  %t2413 = load { i64, ptr }, ptr %l79, !tbaa !27
  store { i64, ptr } %t2413, ptr %l829, !tbaa !27
  %t2414 = load ptr, ptr %l11, !tbaa !29
  %t2415 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t2416 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t2420 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %s96, ptr %s96, ptr %s98, ptr %s98, ptr %t2414, { i64, ptr } %t2415, { i64, ptr } %t2416, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d179, i32 0, i32 1) })
  store { i64, ptr } %t2420, ptr %l833
  br label %bb377
bb376:
  store %olang.scope zeroinitializer, ptr %s100
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d264, i32 0, i32 1) }, ptr %l838, !tbaa !27
  %t2421 = load { i64, ptr }, ptr %l838, !tbaa !27
  store { i64, ptr } %t2421, ptr %l839, !tbaa !27
  %t2422 = load { i64, ptr }, ptr %l839, !tbaa !27
  %t2423 = extractvalue { i64, ptr } %t2422, 0
  store i64 %t2423, ptr %l840, !tbaa !24
  %t2424 = load i64, ptr %l840, !tbaa !24
  %t2425 = mul i64 %t2424, 1
  %t2426 = call ptr @__olang_scope_alloc(ptr %s100, i64 %t2425)
  %t2427 = insertvalue { i64, ptr } undef, i64 %t2424, 0
  %t2428 = insertvalue { i64, ptr } %t2427, ptr %t2426, 1
  store { i64, ptr } %t2428, ptr %l841, !tbaa !27
  %t2429 = getelementptr { i64, ptr }, ptr %l841, i32 0, i32 1
  %t2430 = load ptr, ptr %t2429, !tbaa !27
  %t2431 = getelementptr { i64, ptr }, ptr %l839, i32 0, i32 1
  %t2432 = load ptr, ptr %t2431, !tbaa !27
  %t2433 = load i64, ptr %l840, !tbaa !24
  %t2434 = mul i64 %t2433, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t2430, ptr %t2432, i64 %t2434, i1 false)
  %t2435 = load { i64, ptr }, ptr %l841, !tbaa !27
  store { i64, ptr } %t2435, ptr %l80, !tbaa !27
  store i64 0, ptr %l81, !tbaa !24
  %t2436 = getelementptr %"compiler/cabi:Way", ptr %l16, i32 0, i32 1
  %t2438 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %t2436)
  store i64 %t2438, ptr %l843
  br label %bb381
bb377:
  %t2439 = load { i64, ptr }, ptr %l829, !tbaa !27
  %t2440 = extractvalue { i64, ptr } %t2439, 1
  %t2441 = extractvalue { i64, ptr } %t2439, 0
  %t2442 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d265, i32 0, i32 1) }, 1
  %t2443 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d265, i32 0, i32 1) }, 0
  %t2444 = add i64 %t2441, %t2443
  %t2445 = load { i64, ptr }, ptr %l833, !tbaa !27
  %t2446 = extractvalue { i64, ptr } %t2445, 1
  %t2447 = extractvalue { i64, ptr } %t2445, 0
  %t2448 = add i64 %t2444, %t2447
  %t2449 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t2448)
  call void @olang_textcopy(ptr %t2449, ptr %t2440, i64 %t2441)
  %t2450 = getelementptr i8, ptr %t2449, i64 %t2441
  call void @olang_textcopy(ptr %t2450, ptr %t2442, i64 %t2443)
  %t2451 = getelementptr i8, ptr %t2450, i64 %t2443
  call void @olang_textcopy(ptr %t2451, ptr %t2446, i64 %t2447)
  %t2452 = insertvalue { i64, ptr } undef, i64 %t2448, 0
  %t2453 = insertvalue { i64, ptr } %t2452, ptr %t2449, 1
  store { i64, ptr } %t2453, ptr %l834, !tbaa !27
  %t2454 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t2455 = extractvalue { i64, ptr } %t2454, 0
  %t2456 = load { i64, ptr }, ptr %l834, !tbaa !27
  %t2457 = extractvalue { i64, ptr } %t2456, 0
  store i64 %t2457, ptr %l836, !tbaa !24
  %t2459 = load i64, ptr %l836, !tbaa !24
  %t2460 = icmp eq i64 %t2455, %t2459
  br i1 %t2460, label %bb378, label %bb379
bb378:
  %t2462 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t2463 = load ptr, ptr %t2462, !tbaa !27
  %t2464 = getelementptr { i64, ptr }, ptr %l834, i32 0, i32 1
  %t2465 = load ptr, ptr %t2464, !tbaa !27
  %t2466 = load i64, ptr %l836, !tbaa !24
  %t2467 = mul i64 %t2466, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t2463, ptr %t2465, i64 %t2467, i1 false)
  br label %bb380
bb379:
  %t2468 = load { i64, ptr }, ptr %l834, !tbaa !27
  store { i64, ptr } %t2468, ptr %l68, !tbaa !27
  br label %bb380
bb380:
  call void @__olang_scope_close(ptr %s98)
  br label %bb410
bb381:
  %t2469 = load i64, ptr %l843, !tbaa !24
  store i64 %t2469, ptr %l82, !tbaa !24
  store i64 1, ptr %l83, !tbaa !24
  %t2470 = load i64, ptr %l82, !tbaa !24
  %t2471 = load i64, ptr %l81, !tbaa !24
  %t2474 = icmp sgt i64 %t2470, %t2471
  br i1 %t2474, label %bb382, label %bb383
bb382:
  %t2476 = load i64, ptr %l83, !tbaa !24
  %t2478 = icmp sgt i64 %t2476, 0
  br i1 %t2478, label %bb384, label %bb385
bb383:
  store i64 0, ptr %l847, !tbaa !24
  br label %bb387
bb384:
  %t2480 = load i64, ptr %l82, !tbaa !24
  %t2481 = load i64, ptr %l81, !tbaa !24
  %t2484 = sub i64 %t2480, %t2481
  %t2485 = load i64, ptr %l83, !tbaa !24
  %t2488 = add i64 %t2484, %t2485
  %t2490 = sub i64 %t2488, 1
  %t2491 = load i64, ptr %l83, !tbaa !24
  %t2494 = sdiv i64 %t2490, %t2491
  store i64 %t2494, ptr %l850, !tbaa !24
  br label %bb386
bb385:
  store i64 0, ptr %l850, !tbaa !24
  br label %bb386
bb386:
  %t2496 = load i64, ptr %l850, !tbaa !24
  store i64 %t2496, ptr %l847, !tbaa !24
  br label %bb387
bb387:
  %t2497 = load i64, ptr %l847, !tbaa !24
  store i64 %t2497, ptr %l84, !tbaa !24
  store i64 0, ptr %l85, !tbaa !24
  br label %bb388
bb388:
  store %olang.scope zeroinitializer, ptr %s102
  %t2498 = load i64, ptr %l85, !tbaa !24
  %t2499 = load i64, ptr %l84, !tbaa !24
  %t2502 = icmp slt i64 %t2498, %t2499
  %t2504 = xor i1 %t2502, true
  br i1 %t2504, label %bb389, label %bb390
bb389:
  call void @__olang_scope_close(ptr %s102)
  br label %bb406
bb390:
  br label %bb391
bb391:
  %t2506 = load i64, ptr %l81, !tbaa !24
  %t2507 = load i64, ptr %l85, !tbaa !24
  %t2508 = load i64, ptr %l83, !tbaa !24
  %t2511 = mul i64 %t2507, %t2508
  %t2514 = add i64 %t2506, %t2511
  store i64 %t2514, ptr %l86, !tbaa !24
  %t2516 = getelementptr %"compiler/cabi:Way", ptr %l16, i32 0, i32 2
  %t2517 = load i64, ptr %l86, !tbaa !24
  %t2520 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t2516, i64 %t2517)
  store i64 %t2520, ptr %l870
  br label %bb392
bb392:
  %t2521 = load i64, ptr %l870, !tbaa !24
  %t2522 = icmp eq i64 %t2521, 0
  br i1 %t2522, label %bb393, label %bb394
bb393:
  %t2524 = load { i64, ptr }, ptr %l78, !tbaa !27
  store { i64, ptr } %t2524, ptr %l872, !tbaa !27
  br label %bb397
bb394:
  %t2526 = load ptr, ptr %l11, !tbaa !29
  store ptr %t2526, ptr %l874, !tbaa !29
  %t2527 = load { i64, ptr }, ptr %l78, !tbaa !27
  store { i64, ptr } %t2527, ptr %l875, !tbaa !27
  %t2528 = getelementptr %"compiler/cabi:Way", ptr %l16, i32 0, i32 2
  %t2529 = load i64, ptr %l86, !tbaa !24
  %t2532 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t2528, i64 %t2529)
  store i64 %t2532, ptr %l878
  br label %bb395
bb395:
  %t2533 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d266, i32 0, i32 1) }, 1
  %t2534 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d266, i32 0, i32 1) }, 0
  %t2535 = load { i64, ptr }, ptr %l875, !tbaa !27
  %t2536 = extractvalue { i64, ptr } %t2535, 1
  %t2537 = extractvalue { i64, ptr } %t2535, 0
  %t2538 = add i64 %t2534, %t2537
  %t2539 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d267, i32 0, i32 1) }, 1
  %t2540 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d267, i32 0, i32 1) }, 0
  %t2541 = add i64 %t2538, %t2540
  %t2542 = load i64, ptr %l878, !tbaa !24
  %t2543 = call i64 @__olang_fmt_i64(ptr null, i64 %t2542)
  %t2544 = add i64 %t2541, %t2543
  %t2545 = call ptr @__olang_scope_alloc(ptr %s102, i64 %t2544)
  call void @olang_textcopy(ptr %t2545, ptr %t2533, i64 %t2534)
  %t2546 = getelementptr i8, ptr %t2545, i64 %t2534
  call void @olang_textcopy(ptr %t2546, ptr %t2536, i64 %t2537)
  %t2547 = getelementptr i8, ptr %t2546, i64 %t2537
  call void @olang_textcopy(ptr %t2547, ptr %t2539, i64 %t2540)
  %t2548 = getelementptr i8, ptr %t2547, i64 %t2540
  %t2549 = call i64 @__olang_fmt_i64(ptr %t2548, i64 %t2542)
  %t2550 = insertvalue { i64, ptr } undef, i64 %t2544, 0
  %t2551 = insertvalue { i64, ptr } %t2550, ptr %t2545, 1
  %t2553 = extractvalue { i64, ptr } %t2551, 0
  %t2554 = extractvalue { i64, ptr } %t2551, 1
  %t2555 = mul i64 %t2553, 1
  %t2556 = call ptr @__olang_scope_alloc(ptr %s102, i64 %t2555)
  call void @llvm.memcpy.p0.p0.i64(ptr %t2556, ptr %t2554, i64 %t2555, i1 false)
  %t2557 = insertvalue { i64, ptr } undef, i64 %t2553, 0
  %t2558 = insertvalue { i64, ptr } %t2557, ptr %t2556, 1
  %t2559 = load ptr, ptr %l874, !tbaa !29
  %t2561 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s102, ptr %s102, ptr %t2559, { i64, ptr } %t2558)
  store { i64, ptr } %t2561, ptr %l881
  br label %bb396
bb396:
  %t2562 = load { i64, ptr }, ptr %l881, !tbaa !27
  store { i64, ptr } %t2562, ptr %l872, !tbaa !27
  br label %bb397
bb397:
  %t2563 = load { i64, ptr }, ptr %l872, !tbaa !27
  store { i64, ptr } %t2563, ptr %l87, !tbaa !27
  %t2564 = load ptr, ptr %l11, !tbaa !29
  store ptr %t2564, ptr %l882, !tbaa !29
  %t2565 = load { i64, ptr }, ptr %l79, !tbaa !27
  store { i64, ptr } %t2565, ptr %l883, !tbaa !27
  %t2566 = load { i64, ptr }, ptr %l80, !tbaa !27
  store { i64, ptr } %t2566, ptr %l884, !tbaa !27
  %t2567 = getelementptr %"compiler/cabi:Way", ptr %l16, i32 0, i32 1
  %t2568 = load i64, ptr %l86, !tbaa !24
  %t2571 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s102, ptr %t2567, i64 %t2568)
  store { i64, ptr } %t2571, ptr %l887
  br label %bb398
bb398:
  %t2572 = load ptr, ptr %l11, !tbaa !29
  store ptr %t2572, ptr %l888, !tbaa !29
  %t2573 = getelementptr %"compiler/cabi:Way", ptr %l16, i32 0, i32 1
  %t2574 = load i64, ptr %l86, !tbaa !24
  %t2577 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %t2573, i64 %t2574)
  store { i64, ptr } %t2577, ptr %l891
  br label %bb399
bb399:
  %t2578 = load { i64, ptr }, ptr %l87, !tbaa !27
  %t2579 = load ptr, ptr %l888, !tbaa !29
  %t2580 = load { i64, ptr }, ptr %l891, !tbaa !27
  %t2582 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %s0, ptr %s102, ptr %s102, ptr %s102, ptr %t2579, { i64, ptr } %t2580, { i64, ptr } %t2578, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d179, i32 0, i32 1) })
  store { i64, ptr } %t2582, ptr %l893
  br label %bb400
bb400:
  %t2583 = load i64, ptr %l86, !tbaa !24
  %t2584 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d268, i32 0, i32 1) }, 1
  %t2585 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d268, i32 0, i32 1) }, 0
  %t2586 = load { i64, ptr }, ptr %l883, !tbaa !27
  %t2587 = extractvalue { i64, ptr } %t2586, 1
  %t2588 = extractvalue { i64, ptr } %t2586, 0
  %t2589 = add i64 %t2585, %t2588
  %t2590 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d269, i32 0, i32 1) }, 1
  %t2591 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d269, i32 0, i32 1) }, 0
  %t2592 = add i64 %t2589, %t2591
  %t2593 = load { i64, ptr }, ptr %l884, !tbaa !27
  %t2594 = extractvalue { i64, ptr } %t2593, 1
  %t2595 = extractvalue { i64, ptr } %t2593, 0
  %t2596 = add i64 %t2592, %t2595
  %t2597 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d270, i32 0, i32 1) }, 1
  %t2598 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d270, i32 0, i32 1) }, 0
  %t2599 = add i64 %t2596, %t2598
  %t2600 = load { i64, ptr }, ptr %l887, !tbaa !27
  %t2601 = extractvalue { i64, ptr } %t2600, 1
  %t2602 = extractvalue { i64, ptr } %t2600, 0
  %t2603 = add i64 %t2599, %t2602
  %t2604 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d269, i32 0, i32 1) }, 1
  %t2605 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d269, i32 0, i32 1) }, 0
  %t2606 = add i64 %t2603, %t2605
  %t2607 = load { i64, ptr }, ptr %l893, !tbaa !27
  %t2608 = extractvalue { i64, ptr } %t2607, 1
  %t2609 = extractvalue { i64, ptr } %t2607, 0
  %t2610 = add i64 %t2606, %t2609
  %t2611 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d270, i32 0, i32 1) }, 1
  %t2612 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d270, i32 0, i32 1) }, 0
  %t2613 = add i64 %t2610, %t2612
  %t2615 = call i64 @__olang_fmt_i64(ptr null, i64 %t2583)
  %t2616 = add i64 %t2613, %t2615
  %t2617 = call ptr @__olang_scope_alloc(ptr %s100, i64 %t2616)
  call void @olang_textcopy(ptr %t2617, ptr %t2584, i64 %t2585)
  %t2618 = getelementptr i8, ptr %t2617, i64 %t2585
  call void @olang_textcopy(ptr %t2618, ptr %t2587, i64 %t2588)
  %t2619 = getelementptr i8, ptr %t2618, i64 %t2588
  call void @olang_textcopy(ptr %t2619, ptr %t2590, i64 %t2591)
  %t2620 = getelementptr i8, ptr %t2619, i64 %t2591
  call void @olang_textcopy(ptr %t2620, ptr %t2594, i64 %t2595)
  %t2621 = getelementptr i8, ptr %t2620, i64 %t2595
  call void @olang_textcopy(ptr %t2621, ptr %t2597, i64 %t2598)
  %t2622 = getelementptr i8, ptr %t2621, i64 %t2598
  call void @olang_textcopy(ptr %t2622, ptr %t2601, i64 %t2602)
  %t2623 = getelementptr i8, ptr %t2622, i64 %t2602
  call void @olang_textcopy(ptr %t2623, ptr %t2604, i64 %t2605)
  %t2624 = getelementptr i8, ptr %t2623, i64 %t2605
  call void @olang_textcopy(ptr %t2624, ptr %t2608, i64 %t2609)
  %t2625 = getelementptr i8, ptr %t2624, i64 %t2609
  call void @olang_textcopy(ptr %t2625, ptr %t2611, i64 %t2612)
  %t2626 = getelementptr i8, ptr %t2625, i64 %t2612
  %t2627 = call i64 @__olang_fmt_i64(ptr %t2626, i64 %t2583)
  %t2628 = insertvalue { i64, ptr } undef, i64 %t2616, 0
  %t2629 = insertvalue { i64, ptr } %t2628, ptr %t2617, 1
  %t2631 = extractvalue { i64, ptr } %t2629, 0
  %t2632 = extractvalue { i64, ptr } %t2629, 1
  %t2633 = mul i64 %t2631, 1
  %t2634 = call ptr @__olang_scope_alloc(ptr %s100, i64 %t2633)
  call void @llvm.memcpy.p0.p0.i64(ptr %t2634, ptr %t2632, i64 %t2633, i1 false)
  %t2635 = insertvalue { i64, ptr } undef, i64 %t2631, 0
  %t2636 = insertvalue { i64, ptr } %t2635, ptr %t2634, 1
  %t2637 = load ptr, ptr %l882, !tbaa !29
  %t2639 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s100, ptr %s100, ptr %t2637, { i64, ptr } %t2636)
  store { i64, ptr } %t2639, ptr %l897
  br label %bb401
bb401:
  %t2640 = load { i64, ptr }, ptr %l80, !tbaa !27
  %t2641 = extractvalue { i64, ptr } %t2640, 0
  %t2642 = load { i64, ptr }, ptr %l897, !tbaa !27
  %t2643 = extractvalue { i64, ptr } %t2642, 0
  store i64 %t2643, ptr %l899, !tbaa !24
  %t2645 = load i64, ptr %l899, !tbaa !24
  %t2646 = icmp eq i64 %t2641, %t2645
  br i1 %t2646, label %bb402, label %bb403
bb402:
  %t2648 = getelementptr { i64, ptr }, ptr %l80, i32 0, i32 1
  %t2649 = load ptr, ptr %t2648, !tbaa !27
  %t2650 = getelementptr { i64, ptr }, ptr %l897, i32 0, i32 1
  %t2651 = load ptr, ptr %t2650, !tbaa !27
  %t2652 = load i64, ptr %l899, !tbaa !24
  %t2653 = mul i64 %t2652, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t2649, ptr %t2651, i64 %t2653, i1 false)
  br label %bb404
bb403:
  %t2654 = load { i64, ptr }, ptr %l897, !tbaa !27
  store { i64, ptr } %t2654, ptr %l80, !tbaa !27
  br label %bb404
bb404:
  call void @__olang_scope_close(ptr %s102)
  br label %bb405
bb405:
  %t2655 = load i64, ptr %l85, !tbaa !24
  %t2657 = add i64 %t2655, 1
  store i64 %t2657, ptr %l85, !tbaa !24
  br label %bb388
bb406:
  %t2659 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t2660 = load { i64, ptr }, ptr %l80, !tbaa !27
  %t2662 = extractvalue { i64, ptr } %t2659, 1
  %t2663 = extractvalue { i64, ptr } %t2659, 0
  %t2664 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d271, i32 0, i32 1) }, 1
  %t2665 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d271, i32 0, i32 1) }, 0
  %t2666 = add i64 %t2663, %t2665
  %t2668 = extractvalue { i64, ptr } %t2660, 1
  %t2669 = extractvalue { i64, ptr } %t2660, 0
  %t2670 = add i64 %t2666, %t2669
  %t2671 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t2670)
  call void @olang_textcopy(ptr %t2671, ptr %t2662, i64 %t2663)
  %t2672 = getelementptr i8, ptr %t2671, i64 %t2663
  call void @olang_textcopy(ptr %t2672, ptr %t2664, i64 %t2665)
  %t2673 = getelementptr i8, ptr %t2672, i64 %t2665
  call void @olang_textcopy(ptr %t2673, ptr %t2668, i64 %t2669)
  %t2674 = insertvalue { i64, ptr } undef, i64 %t2670, 0
  %t2675 = insertvalue { i64, ptr } %t2674, ptr %t2671, 1
  store { i64, ptr } %t2675, ptr %l905, !tbaa !27
  %t2676 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t2677 = extractvalue { i64, ptr } %t2676, 0
  %t2678 = load { i64, ptr }, ptr %l905, !tbaa !27
  %t2679 = extractvalue { i64, ptr } %t2678, 0
  store i64 %t2679, ptr %l907, !tbaa !24
  %t2681 = load i64, ptr %l907, !tbaa !24
  %t2682 = icmp eq i64 %t2677, %t2681
  br i1 %t2682, label %bb407, label %bb408
bb407:
  %t2684 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t2685 = load ptr, ptr %t2684, !tbaa !27
  %t2686 = getelementptr { i64, ptr }, ptr %l905, i32 0, i32 1
  %t2687 = load ptr, ptr %t2686, !tbaa !27
  %t2688 = load i64, ptr %l907, !tbaa !24
  %t2689 = mul i64 %t2688, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t2685, ptr %t2687, i64 %t2689, i1 false)
  br label %bb409
bb408:
  %t2690 = load { i64, ptr }, ptr %l905, !tbaa !27
  store { i64, ptr } %t2690, ptr %l68, !tbaa !27
  br label %bb409
bb409:
  call void @__olang_scope_close(ptr %s100)
  br label %bb410
bb410:
  call void @__olang_scope_close(ptr %s96)
  br label %bb418
bb411:
  br i1 true, label %bb412, label %bb413
bb412:
  br label %bb414
bb413:
  br label %bb417
bb414:
  store %olang.scope zeroinitializer, ptr %s107
  %t2691 = load ptr, ptr %l11, !tbaa !29
  store ptr %t2691, ptr %l909, !tbaa !29
  %t2692 = load ptr, ptr %l0, !tbaa !29
  %t2693 = load i32, ptr %l12, !tbaa !23
  %t2696 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %s107, ptr %t2692, i32 %t2693)
  store { i64, ptr } %t2696, ptr %l912
  br label %bb415
bb415:
  %t2697 = load { i64, ptr }, ptr %l912, !tbaa !27
  %t2698 = extractvalue { i64, ptr } %t2697, 0
  %t2699 = extractvalue { i64, ptr } %t2697, 1
  %t2700 = mul i64 %t2698, 1
  %t2701 = call ptr @__olang_scope_alloc(ptr %s107, i64 %t2700)
  call void @llvm.memcpy.p0.p0.i64(ptr %t2701, ptr %t2699, i64 %t2700, i1 false)
  %t2702 = insertvalue { i64, ptr } undef, i64 %t2698, 0
  %t2703 = insertvalue { i64, ptr } %t2702, ptr %t2701, 1
  %t2704 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t2705 = load ptr, ptr %l909, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s107, ptr %s0, ptr %s107, ptr %s107, ptr %t2705, { i64, ptr } %t2703, { i64, ptr } %t2704, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d272, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d173, i32 0, i32 1) })
  br label %bb416
bb416:
  call void @__olang_scope_close(ptr %s107)
  br label %bb418
bb417:
  call void @__olang_check_failed(ptr @olang_loc_9000b3cdde9de97e_540aa7fc20a2aa2a)
  unreachable
bb418:
  br label %bb419
bb419:
  br label %bb420
bb420:
  br label %bb421
bb421:
  %t2708 = load ptr, ptr %l11, !tbaa !29
  %t2709 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t2710 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d273, i32 0, i32 1) }, 1
  %t2711 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d273, i32 0, i32 1) }, 0
  %t2713 = extractvalue { i64, ptr } %t2709, 1
  %t2714 = extractvalue { i64, ptr } %t2709, 0
  %t2715 = add i64 %t2711, %t2714
  %t2716 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d274, i32 0, i32 1) }, 1
  %t2717 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d274, i32 0, i32 1) }, 0
  %t2718 = add i64 %t2715, %t2717
  %t2719 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t2718)
  call void @olang_textcopy(ptr %t2719, ptr %t2710, i64 %t2711)
  %t2720 = getelementptr i8, ptr %t2719, i64 %t2711
  call void @olang_textcopy(ptr %t2720, ptr %t2713, i64 %t2714)
  %t2721 = getelementptr i8, ptr %t2720, i64 %t2714
  call void @olang_textcopy(ptr %t2721, ptr %t2716, i64 %t2717)
  %t2722 = insertvalue { i64, ptr } undef, i64 %t2718, 0
  %t2723 = insertvalue { i64, ptr } %t2722, ptr %t2719, 1
  %t2725 = extractvalue { i64, ptr } %t2723, 0
  %t2726 = extractvalue { i64, ptr } %t2723, 1
  %t2727 = mul i64 %t2725, 1
  %t2728 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t2727)
  call void @llvm.memcpy.p0.p0.i64(ptr %t2728, ptr %t2726, i64 %t2727, i1 false)
  %t2729 = insertvalue { i64, ptr } undef, i64 %t2725, 0
  %t2730 = insertvalue { i64, ptr } %t2729, ptr %t2728, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s0, ptr %t2708, { i64, ptr } %t2730)
  br label %bb422
bb422:
  %t2733 = load ptr, ptr %l11, !tbaa !29
  store ptr %t2733, ptr %l919, !tbaa !29
  %t2734 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t2736 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t2734, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d275, i32 0, i32 1) })
  store i1 %t2736, ptr %l921
  br label %bb423
bb423:
  %t2737 = load i1, ptr %l921, !tbaa !21
  %t2738 = xor i1 %t2737, true
  br i1 %t2738, label %bb424, label %bb425
bb424:
  %t2740 = load { i64, ptr }, ptr %l68, !tbaa !27
  store { i64, ptr } %t2740, ptr %l923, !tbaa !27
  br label %bb426
bb425:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d276, i32 0, i32 1) }, ptr %l923, !tbaa !27
  br label %bb426
bb426:
  %t2742 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d277, i32 0, i32 1) }, 1
  %t2743 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d277, i32 0, i32 1) }, 0
  %t2744 = load { i64, ptr }, ptr %l923, !tbaa !27
  %t2745 = extractvalue { i64, ptr } %t2744, 1
  %t2746 = extractvalue { i64, ptr } %t2744, 0
  %t2747 = add i64 %t2743, %t2746
  %t2748 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t2747)
  call void @olang_textcopy(ptr %t2748, ptr %t2742, i64 %t2743)
  %t2749 = getelementptr i8, ptr %t2748, i64 %t2743
  call void @olang_textcopy(ptr %t2749, ptr %t2745, i64 %t2746)
  %t2750 = insertvalue { i64, ptr } undef, i64 %t2747, 0
  %t2751 = insertvalue { i64, ptr } %t2750, ptr %t2748, 1
  %t2753 = extractvalue { i64, ptr } %t2751, 0
  %t2754 = extractvalue { i64, ptr } %t2751, 1
  %t2755 = mul i64 %t2753, 1
  %t2756 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t2755)
  call void @llvm.memcpy.p0.p0.i64(ptr %t2756, ptr %t2754, i64 %t2755, i1 false)
  %t2757 = insertvalue { i64, ptr } undef, i64 %t2753, 0
  %t2758 = insertvalue { i64, ptr } %t2757, ptr %t2756, 1
  %t2759 = load ptr, ptr %l919, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s0, ptr %t2759, { i64, ptr } %t2758)
  br label %bb427
bb427:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d278, i32 0, i32 1) }, ptr %l927, !tbaa !27
  %t2761 = load { i64, ptr }, ptr %l927, !tbaa !27
  store { i64, ptr } %t2761, ptr %l928, !tbaa !27
  %t2762 = load { i64, ptr }, ptr %l928, !tbaa !27
  %t2763 = extractvalue { i64, ptr } %t2762, 0
  store i64 %t2763, ptr %l929, !tbaa !24
  %t2764 = load i64, ptr %l929, !tbaa !24
  %t2765 = mul i64 %t2764, 1
  %t2766 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t2765)
  %t2767 = insertvalue { i64, ptr } undef, i64 %t2764, 0
  %t2768 = insertvalue { i64, ptr } %t2767, ptr %t2766, 1
  store { i64, ptr } %t2768, ptr %l930, !tbaa !27
  %t2769 = getelementptr { i64, ptr }, ptr %l930, i32 0, i32 1
  %t2770 = load ptr, ptr %t2769, !tbaa !27
  %t2771 = getelementptr { i64, ptr }, ptr %l928, i32 0, i32 1
  %t2772 = load ptr, ptr %t2771, !tbaa !27
  %t2773 = load i64, ptr %l929, !tbaa !24
  %t2774 = mul i64 %t2773, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t2770, ptr %t2772, i64 %t2774, i1 false)
  %t2775 = load { i64, ptr }, ptr %l930, !tbaa !27
  store { i64, ptr } %t2775, ptr %l88, !tbaa !27
  %t2776 = load i1, ptr %l14, !tbaa !21
  br i1 %t2776, label %bb428, label %bb429
bb428:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d279, i32 0, i32 1) }, ptr %l932, !tbaa !27
  %t2778 = load { i64, ptr }, ptr %l932, !tbaa !27
  store { i64, ptr } %t2778, ptr %l933, !tbaa !27
  %t2779 = load { i64, ptr }, ptr %l88, !tbaa !27
  %t2780 = extractvalue { i64, ptr } %t2779, 0
  %t2781 = load { i64, ptr }, ptr %l933, !tbaa !27
  %t2782 = extractvalue { i64, ptr } %t2781, 0
  store i64 %t2782, ptr %l935, !tbaa !24
  %t2784 = load i64, ptr %l935, !tbaa !24
  %t2785 = icmp eq i64 %t2780, %t2784
  br i1 %t2785, label %bb430, label %bb431
bb429:
  %t2787 = load i1, ptr %l15, !tbaa !21
  br i1 %t2787, label %bb433, label %bb434
bb430:
  %t2789 = getelementptr { i64, ptr }, ptr %l88, i32 0, i32 1
  %t2790 = load ptr, ptr %t2789, !tbaa !27
  %t2791 = getelementptr { i64, ptr }, ptr %l933, i32 0, i32 1
  %t2792 = load ptr, ptr %t2791, !tbaa !27
  %t2793 = load i64, ptr %l935, !tbaa !24
  %t2794 = mul i64 %t2793, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t2790, ptr %t2792, i64 %t2794, i1 false)
  br label %bb432
bb431:
  %t2795 = load { i64, ptr }, ptr %l933, !tbaa !27
  %t2796 = extractvalue { i64, ptr } %t2795, 0
  store i64 %t2796, ptr %l937, !tbaa !24
  %t2797 = load i64, ptr %l937, !tbaa !24
  %t2798 = mul i64 %t2797, 1
  %t2799 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t2798)
  %t2800 = insertvalue { i64, ptr } undef, i64 %t2797, 0
  %t2801 = insertvalue { i64, ptr } %t2800, ptr %t2799, 1
  store { i64, ptr } %t2801, ptr %l938, !tbaa !27
  %t2802 = getelementptr { i64, ptr }, ptr %l938, i32 0, i32 1
  %t2803 = load ptr, ptr %t2802, !tbaa !27
  %t2804 = getelementptr { i64, ptr }, ptr %l933, i32 0, i32 1
  %t2805 = load ptr, ptr %t2804, !tbaa !27
  %t2806 = load i64, ptr %l937, !tbaa !24
  %t2807 = mul i64 %t2806, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t2803, ptr %t2805, i64 %t2807, i1 false)
  %t2808 = load { i64, ptr }, ptr %l938, !tbaa !27
  store { i64, ptr } %t2808, ptr %l88, !tbaa !27
  br label %bb432
bb432:
  br label %bb464
bb433:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d280, i32 0, i32 1) }, ptr %l940, !tbaa !27
  %t2809 = load { i64, ptr }, ptr %l940, !tbaa !27
  store { i64, ptr } %t2809, ptr %l941, !tbaa !27
  %t2810 = load { i64, ptr }, ptr %l88, !tbaa !27
  %t2811 = extractvalue { i64, ptr } %t2810, 0
  %t2812 = load { i64, ptr }, ptr %l941, !tbaa !27
  %t2813 = extractvalue { i64, ptr } %t2812, 0
  store i64 %t2813, ptr %l943, !tbaa !24
  %t2815 = load i64, ptr %l943, !tbaa !24
  %t2816 = icmp eq i64 %t2811, %t2815
  br i1 %t2816, label %bb435, label %bb436
bb434:
  %t2818 = load i1, ptr %l13, !tbaa !21
  br i1 %t2818, label %bb438, label %bb439
bb435:
  %t2820 = getelementptr { i64, ptr }, ptr %l88, i32 0, i32 1
  %t2821 = load ptr, ptr %t2820, !tbaa !27
  %t2822 = getelementptr { i64, ptr }, ptr %l941, i32 0, i32 1
  %t2823 = load ptr, ptr %t2822, !tbaa !27
  %t2824 = load i64, ptr %l943, !tbaa !24
  %t2825 = mul i64 %t2824, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t2821, ptr %t2823, i64 %t2825, i1 false)
  br label %bb437
bb436:
  %t2826 = load { i64, ptr }, ptr %l941, !tbaa !27
  %t2827 = extractvalue { i64, ptr } %t2826, 0
  store i64 %t2827, ptr %l945, !tbaa !24
  %t2828 = load i64, ptr %l945, !tbaa !24
  %t2829 = mul i64 %t2828, 1
  %t2830 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t2829)
  %t2831 = insertvalue { i64, ptr } undef, i64 %t2828, 0
  %t2832 = insertvalue { i64, ptr } %t2831, ptr %t2830, 1
  store { i64, ptr } %t2832, ptr %l946, !tbaa !27
  %t2833 = getelementptr { i64, ptr }, ptr %l946, i32 0, i32 1
  %t2834 = load ptr, ptr %t2833, !tbaa !27
  %t2835 = getelementptr { i64, ptr }, ptr %l941, i32 0, i32 1
  %t2836 = load ptr, ptr %t2835, !tbaa !27
  %t2837 = load i64, ptr %l945, !tbaa !24
  %t2838 = mul i64 %t2837, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t2834, ptr %t2836, i64 %t2838, i1 false)
  %t2839 = load { i64, ptr }, ptr %l946, !tbaa !27
  store { i64, ptr } %t2839, ptr %l88, !tbaa !27
  br label %bb437
bb437:
  br label %bb463
bb438:
  %t2840 = getelementptr %"compiler/cabi:Way", ptr %l16, i32 0, i32 0
  %t2841 = load i32, ptr %t2840
  store i32 %t2841, ptr %l89
  %t2843 = load i32, ptr %l89
  %t2845 = trunc i64 0 to i32
  %t2846 = icmp eq i32 %t2843, %t2845
  br i1 %t2846, label %bb440, label %bb441
bb439:
  br label %bb462
bb440:
  br label %bb442
bb441:
  br label %bb448
bb442:
  store %olang.scope zeroinitializer, ptr %s115
  %t2848 = getelementptr %"compiler/cabi:Way", ptr %l16, i32 0, i32 4
  %t2849 = load { i64, ptr }, ptr %t2848, !tbaa !27
  %t2851 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s115, { i64, ptr } %t2849, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d281, i32 0, i32 1) })
  store i1 %t2851, ptr %l953
  br label %bb443
bb443:
  %t2852 = load i1, ptr %l953, !tbaa !21
  %t2853 = xor i1 %t2852, true
  br i1 %t2853, label %bb444, label %bb445
bb444:
  %t2855 = getelementptr %"compiler/cabi:Way", ptr %l16, i32 0, i32 4
  %t2856 = load { i64, ptr }, ptr %t2855, !tbaa !27
  %t2858 = extractvalue { i64, ptr } %t2856, 1
  %t2859 = extractvalue { i64, ptr } %t2856, 0
  %t2860 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d282, i32 0, i32 1) }, 1
  %t2861 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d282, i32 0, i32 1) }, 0
  %t2862 = add i64 %t2859, %t2861
  %t2863 = call ptr @__olang_scope_alloc(ptr %s115, i64 %t2862)
  call void @olang_textcopy(ptr %t2863, ptr %t2858, i64 %t2859)
  %t2864 = getelementptr i8, ptr %t2863, i64 %t2859
  call void @olang_textcopy(ptr %t2864, ptr %t2860, i64 %t2861)
  %t2865 = insertvalue { i64, ptr } undef, i64 %t2862, 0
  %t2866 = insertvalue { i64, ptr } %t2865, ptr %t2863, 1
  %t2868 = extractvalue { i64, ptr } %t2866, 0
  %t2869 = extractvalue { i64, ptr } %t2866, 1
  %t2870 = mul i64 %t2868, 1
  %t2871 = call ptr @__olang_scope_alloc(ptr %s115, i64 %t2870)
  call void @llvm.memcpy.p0.p0.i64(ptr %t2871, ptr %t2869, i64 %t2870, i1 false)
  %t2872 = insertvalue { i64, ptr } undef, i64 %t2868, 0
  %t2873 = insertvalue { i64, ptr } %t2872, ptr %t2871, 1
  store { i64, ptr } %t2873, ptr %l955, !tbaa !27
  br label %bb446
bb445:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d283, i32 0, i32 1) }, ptr %l955, !tbaa !27
  br label %bb446
bb446:
  %t2875 = load ptr, ptr %l0, !tbaa !29
  %t2876 = load i32, ptr %l12, !tbaa !23
  %t2879 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %s115, ptr %t2875, i32 %t2876)
  store { i64, ptr } %t2879, ptr %l961
  br label %bb447
bb447:
  %t2880 = load { i64, ptr }, ptr %l955, !tbaa !27
  %t2881 = extractvalue { i64, ptr } %t2880, 1
  %t2882 = extractvalue { i64, ptr } %t2880, 0
  %t2883 = load { i64, ptr }, ptr %l961, !tbaa !27
  %t2884 = extractvalue { i64, ptr } %t2883, 1
  %t2885 = extractvalue { i64, ptr } %t2883, 0
  %t2886 = add i64 %t2882, %t2885
  %t2887 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t2886)
  call void @olang_textcopy(ptr %t2887, ptr %t2881, i64 %t2882)
  %t2888 = getelementptr i8, ptr %t2887, i64 %t2882
  call void @olang_textcopy(ptr %t2888, ptr %t2884, i64 %t2885)
  %t2889 = insertvalue { i64, ptr } undef, i64 %t2886, 0
  %t2890 = insertvalue { i64, ptr } %t2889, ptr %t2887, 1
  store { i64, ptr } %t2890, ptr %l949, !tbaa !27
  call void @__olang_scope_close(ptr %s115)
  br label %bb458
bb448:
  %t2892 = load i32, ptr %l89
  %t2894 = trunc i64 1 to i32
  %t2895 = icmp eq i32 %t2892, %t2894
  br i1 %t2895, label %bb449, label %bb450
bb449:
  br label %bb451
bb450:
  br label %bb453
bb451:
  %t2898 = call { i64, ptr } @compiler_2fcabi_2ePartsType(ptr %s0, ptr %s0, ptr %l16)
  store { i64, ptr } %t2898, ptr %l966
  br label %bb452
bb452:
  %t2899 = load { i64, ptr }, ptr %l966, !tbaa !27
  store { i64, ptr } %t2899, ptr %l949, !tbaa !27
  br label %bb458
bb453:
  br i1 true, label %bb454, label %bb455
bb454:
  br label %bb456
bb455:
  br label %bb457
bb456:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d284, i32 0, i32 1) }, ptr %l967, !tbaa !27
  %t2900 = load { i64, ptr }, ptr %l967, !tbaa !27
  store { i64, ptr } %t2900, ptr %l949, !tbaa !27
  br label %bb458
bb457:
  call void @__olang_check_failed(ptr @olang_loc_882423aaa1f01f7f_b9c3af967e36d8eb)
  unreachable
bb458:
  %t2902 = load { i64, ptr }, ptr %l88, !tbaa !27
  %t2903 = extractvalue { i64, ptr } %t2902, 0
  %t2904 = load { i64, ptr }, ptr %l949, !tbaa !27
  %t2905 = extractvalue { i64, ptr } %t2904, 0
  store i64 %t2905, ptr %l970, !tbaa !24
  %t2907 = load i64, ptr %l970, !tbaa !24
  %t2908 = icmp eq i64 %t2903, %t2907
  br i1 %t2908, label %bb459, label %bb460
bb459:
  %t2910 = getelementptr { i64, ptr }, ptr %l88, i32 0, i32 1
  %t2911 = load ptr, ptr %t2910, !tbaa !27
  %t2912 = getelementptr { i64, ptr }, ptr %l949, i32 0, i32 1
  %t2913 = load ptr, ptr %t2912, !tbaa !27
  %t2914 = load i64, ptr %l970, !tbaa !24
  %t2915 = mul i64 %t2914, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t2911, ptr %t2913, i64 %t2915, i1 false)
  br label %bb461
bb460:
  %t2916 = load { i64, ptr }, ptr %l949, !tbaa !27
  store { i64, ptr } %t2916, ptr %l88, !tbaa !27
  br label %bb461
bb461:
  br label %bb462
bb462:
  br label %bb463
bb463:
  br label %bb464
bb464:
  %t2917 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t2917, ptr %l972
  br label %bb465
bb465:
  %t2918 = load %"std/prelude/text:StringBuilder", ptr %l972
  store %"std/prelude/text:StringBuilder" %t2918, ptr %l90
  %t2919 = load { i64, ptr }, ptr %l88, !tbaa !27
  %t2920 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t2921 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d285, i32 0, i32 1) }, 1
  %t2922 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d285, i32 0, i32 1) }, 0
  %t2924 = extractvalue { i64, ptr } %t2919, 1
  %t2925 = extractvalue { i64, ptr } %t2919, 0
  %t2926 = add i64 %t2922, %t2925
  %t2927 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d286, i32 0, i32 1) }, 1
  %t2928 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d286, i32 0, i32 1) }, 0
  %t2929 = add i64 %t2926, %t2928
  %t2931 = extractvalue { i64, ptr } %t2920, 1
  %t2932 = extractvalue { i64, ptr } %t2920, 0
  %t2933 = add i64 %t2929, %t2932
  %t2934 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d287, i32 0, i32 1) }, 1
  %t2935 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d287, i32 0, i32 1) }, 0
  %t2936 = add i64 %t2933, %t2935
  %t2937 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t2936)
  call void @olang_textcopy(ptr %t2937, ptr %t2921, i64 %t2922)
  %t2938 = getelementptr i8, ptr %t2937, i64 %t2922
  call void @olang_textcopy(ptr %t2938, ptr %t2924, i64 %t2925)
  %t2939 = getelementptr i8, ptr %t2938, i64 %t2925
  call void @olang_textcopy(ptr %t2939, ptr %t2927, i64 %t2928)
  %t2940 = getelementptr i8, ptr %t2939, i64 %t2928
  call void @olang_textcopy(ptr %t2940, ptr %t2931, i64 %t2932)
  %t2941 = getelementptr i8, ptr %t2940, i64 %t2932
  call void @olang_textcopy(ptr %t2941, ptr %t2934, i64 %t2935)
  %t2942 = insertvalue { i64, ptr } undef, i64 %t2936, 0
  %t2943 = insertvalue { i64, ptr } %t2942, ptr %t2937, 1
  %t2945 = extractvalue { i64, ptr } %t2943, 0
  %t2946 = extractvalue { i64, ptr } %t2943, 1
  %t2947 = mul i64 %t2945, 1
  %t2948 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t2947)
  call void @llvm.memcpy.p0.p0.i64(ptr %t2948, ptr %t2946, i64 %t2947, i1 false)
  %t2949 = insertvalue { i64, ptr } undef, i64 %t2945, 0
  %t2950 = insertvalue { i64, ptr } %t2949, ptr %t2948, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l90, { i64, ptr } %t2950)
  br label %bb466
bb466:
  store ptr %l17, ptr %l91, !tbaa !29
  store i64 0, ptr %l92, !tbaa !24
  br label %bb467
bb467:
  %t2954 = load i64, ptr %l92, !tbaa !24
  store i64 %t2954, ptr %l979, !tbaa !24
  %t2955 = load ptr, ptr %l91, !tbaa !29
  %t2957 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %t2955)
  store i64 %t2957, ptr %l981
  br label %bb468
bb468:
  %t2958 = load i64, ptr %l979, !tbaa !24
  %t2959 = load i64, ptr %l981, !tbaa !24
  %t2960 = icmp slt i64 %t2958, %t2959
  %t2962 = xor i1 %t2960, true
  br i1 %t2962, label %bb469, label %bb470
bb469:
  br label %bb479
bb470:
  br label %bb471
bb471:
  %t2964 = load i64, ptr %l92, !tbaa !24
  store i64 %t2964, ptr %l93, !tbaa !24
  %t2966 = load ptr, ptr %l91, !tbaa !29
  %t2967 = load i64, ptr %l92, !tbaa !24
  %t2970 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %t2966, i64 %t2967)
  store { i64, ptr } %t2970, ptr %l987
  br label %bb472
bb472:
  %t2971 = load { i64, ptr }, ptr %l987, !tbaa !27
  store { i64, ptr } %t2971, ptr %l94, !tbaa !27
  %t2972 = load i64, ptr %l93, !tbaa !24
  %t2974 = icmp sgt i64 %t2972, 0
  br i1 %t2974, label %bb473, label %bb474
bb473:
  store %olang.scope zeroinitializer, ptr %s123
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s123, ptr %l90, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d288, i32 0, i32 1) })
  br label %bb475
bb474:
  br label %bb476
bb475:
  call void @__olang_scope_close(ptr %s123)
  br label %bb476
bb476:
  %t2977 = load { i64, ptr }, ptr %l94, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l90, { i64, ptr } %t2977)
  br label %bb477
bb477:
  br label %bb478
bb478:
  %t2980 = load i64, ptr %l92, !tbaa !24
  %t2982 = add i64 %t2980, 1
  store i64 %t2982, ptr %l92, !tbaa !24
  br label %bb467
bb479:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l90, { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d289, i32 0, i32 1) })
  br label %bb480
bb480:
  store ptr %l90, ptr %l996, !tbaa !29
  %t2985 = load ptr, ptr %l11, !tbaa !29
  %t2987 = getelementptr %"compiler/emit:fnEm", ptr %t2985, i32 0, i32 3
  %t2989 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %s0, ptr %t2987)
  store { i64, ptr } %t2989, ptr %l999
  br label %bb481
bb481:
  %t2990 = load ptr, ptr %l996, !tbaa !29
  %t2991 = load { i64, ptr }, ptr %l999, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t2990, { i64, ptr } %t2991)
  br label %bb482
bb482:
  store ptr %l90, ptr %l1000, !tbaa !29
  %t2992 = load ptr, ptr %l11, !tbaa !29
  %t2994 = getelementptr %"compiler/emit:fnEm", ptr %t2992, i32 0, i32 5
  %t2996 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %s0, ptr %t2994)
  store { i64, ptr } %t2996, ptr %l1003
  br label %bb483
bb483:
  %t2997 = load ptr, ptr %l1000, !tbaa !29
  %t2998 = load { i64, ptr }, ptr %l1003, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t2997, { i64, ptr } %t2998)
  br label %bb484
bb484:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l90, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d290, i32 0, i32 1) })
  br label %bb485
bb485:
  %t3000 = load ptr, ptr %l0, !tbaa !29
  store ptr %t3000, ptr %l1005, !tbaa !29
  %t3001 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t3001, ptr %l1006, !tbaa !27
  %t3002 = load ptr, ptr %l3, !tbaa !29
  %t3004 = getelementptr %"compiler/generic:Program", ptr %t3002, i32 0, i32 0
  %t3005 = load ptr, ptr %t3004, !tbaa !29
  %t3007 = getelementptr %"compiler/load:Loader", ptr %t3005, i32 0, i32 7
  %t3008 = load i64, ptr %t3007, !tbaa !24
  store i64 %t3008, ptr %l1009, !tbaa !24
  %t3010 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l90)
  store { i64, ptr } %t3010, ptr %l1011
  br label %bb486
bb486:
  %t3011 = load ptr, ptr %l1005, !tbaa !29
  %t3012 = load { i64, ptr }, ptr %l1006, !tbaa !27
  %t3013 = load i64, ptr %l1009, !tbaa !24
  %t3014 = load { i64, ptr }, ptr %l1011, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eitem(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %t3011, { i64, ptr } %t3012, i64 %t3013, { i64, ptr } %t3014, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d8, i32 0, i32 1) })
  br label %bb487
bb487:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3aEmitter_2efunction(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [2 x i64] }
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i1
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l9 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca i1
  %l19 = alloca %"compiler/mir:Fn"
  %l23 = alloca { i64, ptr }
  %l26 = alloca i1
  %l31 = alloca i64
  %l32 = alloca ptr
  %l33 = alloca { i64, [2 x i64] }
  %l35 = alloca i32
  %l36 = alloca { i64, ptr }
  %l37 = alloca i64
  %l38 = alloca i1
  %l41 = alloca i64
  %l42 = alloca { i64, ptr }
  %l44 = alloca { i64, ptr }
  %l48 = alloca i1
  %l52 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %l61 = alloca i1
  %l63 = alloca i1
  %l65 = alloca ptr
  %l66 = alloca { i64, ptr }
  %l68 = alloca i1
  %l70 = alloca { i64, ptr }
  %l72 = alloca { i64, ptr }
  %l79 = alloca i1
  %l91 = alloca ptr
  %l92 = alloca { i64, [2 x i64] }
  %l94 = alloca i32
  %l95 = alloca { i64, ptr }
  %l96 = alloca i64
  %l97 = alloca i1
  %l98 = alloca { i64, ptr }
  %l101 = alloca { i64, ptr }
  %l118 = alloca i1
  %l122 = alloca i1
  %l123 = alloca ptr
  %l124 = alloca { i64, [2 x i64] }
  %l125 = alloca ptr
  %l128 = alloca { i64, ptr }
  %l129 = alloca i64
  %l130 = alloca i1
  %l131 = alloca ptr
  %l132 = alloca { i64, [2 x i64] }
  %l134 = alloca i32
  %l137 = alloca { i64, ptr }
  %l138 = alloca i64
  %l139 = alloca i1
  %l142 = alloca i64
  %l143 = alloca { i64, ptr }
  %l145 = alloca { i64, ptr }
  %l147 = alloca i1
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %t22 = alloca %"compiler/mir:Fn", align 8
  store ptr %a0, ptr %l0
  store { i64, [2 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 67
  store ptr %t3, ptr %l9, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t5 = load { i64, [2 x i64] }, ptr %l1
  %t8 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ehomeOf(ptr %v0, ptr %t4, { i64, [2 x i64] } %t5)
  store i64 %t8, ptr %l12
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l9, !tbaa !29
  %t10 = load i64, ptr %l12, !tbaa !24
  %t11 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %t9, i64 %t10)
  store i1 %t11, ptr %l13
  br label %bb2
bb2:
  %t12 = load i1, ptr %l13, !tbaa !21
  br i1 %t12, label %bb3, label %bb4
bb3:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load { i64, [2 x i64] }, ptr %l1
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclared(ptr %v0, ptr %t13, { i64, [2 x i64] } %t14)
  br label %bb5
bb4:
  br label %bb6
bb5:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb6:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/emit:Emitter", ptr %t17, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t21 = load { i64, [2 x i64] }, ptr %l1
  call void @compiler_2flower_2ecompiler_2flower_3aLowerer_2eLowerKey(ptr %t22, ptr %v0, ptr %v0, ptr %t20, { i64, [2 x i64] } %t21)
  call void @llvm.memmove.p0.p0.i64(ptr %l19, ptr %t22, i64 248, i1 false)
  br label %bb7
bb7:
  %t25 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 248, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t25, ptr %l19, i64 248, i1 false)
  store ptr %t25, ptr %l2, !tbaa !29
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load { i64, [2 x i64] }, ptr %l1
  %t31 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2esym(ptr %v0, ptr %s0, ptr %t27, { i64, [2 x i64] } %t28)
  store { i64, ptr } %t31, ptr %l23
  br label %bb8
bb8:
  %t32 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t32, ptr %l3, !tbaa !27
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load { i64, [2 x i64] }, ptr %l1
  %t37 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ehasEnv(ptr %v0, ptr %t33, { i64, [2 x i64] } %t34)
  store i1 %t37, ptr %l26
  br label %bb9
bb9:
  %t38 = load i1, ptr %l26, !tbaa !21
  store i1 %t38, ptr %l4, !tbaa !21
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load { i64, [2 x i64] }, ptr %l1
  %t41 = load ptr, ptr %l2, !tbaa !29
  %t43 = getelementptr %"compiler/mir:Fn", ptr %t41, i32 0, i32 1
  %t44 = load i32, ptr %t43, !tbaa !23
  %t48 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2epassedOf(ptr %v0, ptr %t39, { i64, [2 x i64] } %t40, i32 %t44)
  store i64 %t48, ptr %l31
  br label %bb10
bb10:
  %t49 = load i64, ptr %l31, !tbaa !24
  store i64 %t49, ptr %l5, !tbaa !24
  %t50 = load ptr, ptr %l0, !tbaa !29
  store ptr %t50, ptr %l32, !tbaa !29
  %t51 = load { i64, [2 x i64] }, ptr %l1
  store { i64, [2 x i64] } %t51, ptr %l33
  %t52 = load ptr, ptr %l2, !tbaa !29
  %t54 = getelementptr %"compiler/mir:Fn", ptr %t52, i32 0, i32 1
  %t55 = load i32, ptr %t54, !tbaa !23
  store i32 %t55, ptr %l35, !tbaa !23
  %t56 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t56, ptr %l36, !tbaa !27
  %t57 = load i64, ptr %l5, !tbaa !24
  store i64 %t57, ptr %l37, !tbaa !24
  %t58 = load i1, ptr %l4, !tbaa !21
  store i1 %t58, ptr %l38, !tbaa !21
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = load { i64, [2 x i64] }, ptr %l1
  %t63 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ehomeOf(ptr %v0, ptr %t59, { i64, [2 x i64] } %t60)
  store i64 %t63, ptr %l41
  br label %bb11
bb11:
  %t64 = load i64, ptr %l41, !tbaa !24
  %t65 = call { i64, ptr } @compiler_2femit_2elinkFor(ptr %s0, i64 %t64)
  store { i64, ptr } %t65, ptr %l42
  br label %bb12
bb12:
  %t66 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t67 = extractvalue { i64, ptr } %t66, 0
  %t68 = extractvalue { i64, ptr } %t66, 1
  %t69 = mul i64 %t67, 1
  %t70 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t69)
  call void @llvm.memcpy.p0.p0.i64(ptr %t70, ptr %t68, i64 %t69, i1 false)
  %t71 = insertvalue { i64, ptr } undef, i64 %t67, 0
  %t72 = insertvalue { i64, ptr } %t71, ptr %t70, 1
  %t73 = load ptr, ptr %l32, !tbaa !29
  %t74 = load { i64, [2 x i64] }, ptr %l33
  %t75 = load i32, ptr %l35, !tbaa !23
  %t76 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t77 = load i64, ptr %l37, !tbaa !24
  %t78 = load i1, ptr %l38, !tbaa !21
  %t80 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eheader(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %t73, { i64, [2 x i64] } %t74, i32 %t75, { i64, ptr } %t76, i64 %t77, i1 %t78, { i64, ptr } %t72)
  store { i64, ptr } %t80, ptr %l44
  br label %bb13
bb13:
  %t81 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t81, ptr %l6, !tbaa !27
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/emit:Emitter", ptr %t82, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !29
  %t87 = getelementptr %"compiler/lower:Lowerer", ptr %t85, i32 0, i32 5
  %t88 = load i1, ptr %t87, !tbaa !21
  br i1 %t88, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l48, !tbaa !21
  br label %bb16
bb15:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/emit:Emitter", ptr %t90, i32 0, i32 7
  %t93 = load i1, ptr %t92, !tbaa !21
  %t95 = xor i1 %t93, true
  store i1 %t95, ptr %l48, !tbaa !21
  br label %bb16
bb16:
  %t97 = load i1, ptr %l48, !tbaa !21
  br i1 %t97, label %bb17, label %bb18
bb17:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d291, i32 0, i32 1) }, ptr %l52, !tbaa !27
  br label %bb20
bb18:
  %t98 = load ptr, ptr %l2, !tbaa !29
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/emit:Emitter", ptr %t99, i32 0, i32 3
  %t102 = load ptr, ptr %t101, !tbaa !29
  %t105 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3aFn_2eVerify(ptr %v0, ptr %v0, ptr %s0, ptr %t98, ptr %t102)
  store { i64, ptr } %t105, ptr %l56
  br label %bb19
bb19:
  %t106 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t107 = extractvalue { i64, ptr } %t106, 0
  %t108 = extractvalue { i64, ptr } %t106, 1
  %t109 = mul i64 %t107, 1
  %t110 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t109)
  call void @llvm.memcpy.p0.p0.i64(ptr %t110, ptr %t108, i64 %t109, i1 false)
  %t111 = insertvalue { i64, ptr } undef, i64 %t107, 0
  %t112 = insertvalue { i64, ptr } %t111, ptr %t110, 1
  store { i64, ptr } %t112, ptr %l52, !tbaa !27
  br label %bb20
bb20:
  %t114 = load { i64, ptr }, ptr %l52, !tbaa !27
  store { i64, ptr } %t114, ptr %l7, !tbaa !27
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"compiler/emit:Emitter", ptr %t115, i32 0, i32 1
  %t118 = load ptr, ptr %t117, !tbaa !29
  %t120 = getelementptr %"compiler/lower:Lowerer", ptr %t118, i32 0, i32 5
  %t121 = load i1, ptr %t120, !tbaa !21
  br i1 %t121, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l61, !tbaa !21
  br label %bb24
bb22:
  %t123 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t125 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t123, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d292, i32 0, i32 1) })
  store i1 %t125, ptr %l63
  br label %bb23
bb23:
  %t126 = load i1, ptr %l63, !tbaa !21
  %t127 = xor i1 %t126, true
  store i1 %t127, ptr %l61, !tbaa !21
  br label %bb24
bb24:
  %t129 = load i1, ptr %l61, !tbaa !21
  br i1 %t129, label %bb25, label %bb26
bb25:
  store %olang.scope zeroinitializer, ptr %s2
  %t130 = load ptr, ptr %l0, !tbaa !29
  store ptr %t130, ptr %l65, !tbaa !29
  %t131 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t131, ptr %l66, !tbaa !27
  %t132 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t134 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s2, { i64, ptr } %t132, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d293, i32 0, i32 1) })
  store i1 %t134, ptr %l68
  br label %bb27
bb26:
  br label %bb42
bb27:
  %t135 = load i1, ptr %l68, !tbaa !21
  %t136 = xor i1 %t135, true
  br i1 %t136, label %bb28, label %bb29
bb28:
  %t138 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t140 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %s0, { i64, ptr } %t138)
  store { i64, ptr } %t140, ptr %l72
  br label %bb30
bb29:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d294, i32 0, i32 1) }, ptr %l70, !tbaa !27
  br label %bb31
bb30:
  %t141 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d295, i32 0, i32 1) }, 1
  %t142 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d295, i32 0, i32 1) }, 0
  %t143 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t144 = extractvalue { i64, ptr } %t143, 1
  %t145 = extractvalue { i64, ptr } %t143, 0
  %t146 = add i64 %t142, %t145
  %t147 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d296, i32 0, i32 1) }, 1
  %t148 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d296, i32 0, i32 1) }, 0
  %t149 = add i64 %t146, %t148
  %t150 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t149)
  call void @olang_textcopy(ptr %t150, ptr %t141, i64 %t142)
  %t151 = getelementptr i8, ptr %t150, i64 %t142
  call void @olang_textcopy(ptr %t151, ptr %t144, i64 %t145)
  %t152 = getelementptr i8, ptr %t151, i64 %t145
  call void @olang_textcopy(ptr %t152, ptr %t147, i64 %t148)
  %t153 = insertvalue { i64, ptr } undef, i64 %t149, 0
  %t154 = insertvalue { i64, ptr } %t153, ptr %t150, 1
  %t156 = extractvalue { i64, ptr } %t154, 0
  %t157 = extractvalue { i64, ptr } %t154, 1
  %t158 = mul i64 %t156, 1
  %t159 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t158)
  call void @llvm.memcpy.p0.p0.i64(ptr %t159, ptr %t157, i64 %t158, i1 false)
  %t160 = insertvalue { i64, ptr } undef, i64 %t156, 0
  %t161 = insertvalue { i64, ptr } %t160, ptr %t159, 1
  store { i64, ptr } %t161, ptr %l70, !tbaa !27
  br label %bb31
bb31:
  %t163 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d297, i32 0, i32 1) }, 1
  %t164 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d297, i32 0, i32 1) }, 0
  %t165 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t166 = extractvalue { i64, ptr } %t165, 1
  %t167 = extractvalue { i64, ptr } %t165, 0
  %t168 = add i64 %t164, %t167
  %t169 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t170 = extractvalue { i64, ptr } %t169, 1
  %t171 = extractvalue { i64, ptr } %t169, 0
  %t172 = add i64 %t168, %t171
  %t173 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t172)
  call void @olang_textcopy(ptr %t173, ptr %t163, i64 %t164)
  %t174 = getelementptr i8, ptr %t173, i64 %t164
  call void @olang_textcopy(ptr %t174, ptr %t166, i64 %t167)
  %t175 = getelementptr i8, ptr %t174, i64 %t167
  call void @olang_textcopy(ptr %t175, ptr %t170, i64 %t171)
  %t176 = insertvalue { i64, ptr } undef, i64 %t172, 0
  %t177 = insertvalue { i64, ptr } %t176, ptr %t173, 1
  %t179 = extractvalue { i64, ptr } %t177, 0
  %t180 = extractvalue { i64, ptr } %t177, 1
  %t181 = mul i64 %t179, 1
  %t182 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t181)
  call void @llvm.memcpy.p0.p0.i64(ptr %t182, ptr %t180, i64 %t181, i1 false)
  %t183 = insertvalue { i64, ptr } undef, i64 %t179, 0
  %t184 = insertvalue { i64, ptr } %t183, ptr %t182, 1
  %t185 = load ptr, ptr %l65, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2egap(ptr %v0, ptr %s2, ptr %t185, { i64, ptr } %t184)
  br label %bb32
bb32:
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t188 = load { i64, [2 x i64] }, ptr %l1
  %t191 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eisGlobalInit(ptr %v0, ptr %t187, { i64, [2 x i64] } %t188)
  store i1 %t191, ptr %l79
  br label %bb33
bb33:
  %t192 = load i1, ptr %l79, !tbaa !21
  br i1 %t192, label %bb34, label %bb35
bb34:
  store %olang.scope zeroinitializer, ptr %s5
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t194 = load { i64, [2 x i64] }, ptr %l1
  %t195 = load ptr, ptr %l2, !tbaa !29
  %t197 = getelementptr %"compiler/mir:Fn", ptr %t195, i32 0, i32 1
  %t198 = load i32, ptr %t197, !tbaa !23
  %t199 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t200 = load i64, ptr %l5, !tbaa !24
  %t201 = load i1, ptr %l4, !tbaa !21
  %t202 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t204 = extractvalue { i64, ptr } %t202, 1
  %t205 = extractvalue { i64, ptr } %t202, 0
  %t206 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d298, i32 0, i32 1) }, 1
  %t207 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d298, i32 0, i32 1) }, 0
  %t208 = add i64 %t205, %t207
  %t209 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t208)
  call void @olang_textcopy(ptr %t209, ptr %t204, i64 %t205)
  %t210 = getelementptr i8, ptr %t209, i64 %t205
  call void @olang_textcopy(ptr %t210, ptr %t206, i64 %t207)
  %t211 = insertvalue { i64, ptr } undef, i64 %t208, 0
  %t212 = insertvalue { i64, ptr } %t211, ptr %t209, 1
  %t214 = extractvalue { i64, ptr } %t212, 0
  %t215 = extractvalue { i64, ptr } %t212, 1
  %t216 = mul i64 %t214, 1
  %t217 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t216)
  call void @llvm.memcpy.p0.p0.i64(ptr %t217, ptr %t215, i64 %t216, i1 false)
  %t218 = insertvalue { i64, ptr } undef, i64 %t214, 0
  %t219 = insertvalue { i64, ptr } %t218, ptr %t217, 1
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2efnItem(ptr %v0, ptr %s0, ptr %s5, ptr %t193, { i64, [2 x i64] } %t194, i32 %t198, { i64, ptr } %t199, i64 %t200, i1 %t201, { i64, ptr } %t219)
  br label %bb36
bb35:
  br label %bb37
bb36:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb37:
  %t227 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %s2, ptr %t227, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d299, i32 0, i32 1) })
  br label %bb38
bb38:
  %t229 = load ptr, ptr %l0, !tbaa !29
  store ptr %t229, ptr %l91, !tbaa !29
  %t230 = load { i64, [2 x i64] }, ptr %l1
  store { i64, [2 x i64] } %t230, ptr %l92
  %t231 = load ptr, ptr %l2, !tbaa !29
  %t233 = getelementptr %"compiler/mir:Fn", ptr %t231, i32 0, i32 1
  %t234 = load i32, ptr %t233, !tbaa !23
  store i32 %t234, ptr %l94, !tbaa !23
  %t235 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t235, ptr %l95, !tbaa !27
  %t236 = load i64, ptr %l5, !tbaa !24
  store i64 %t236, ptr %l96, !tbaa !24
  %t237 = load i1, ptr %l4, !tbaa !21
  store i1 %t237, ptr %l97, !tbaa !21
  %t238 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t238, ptr %l98, !tbaa !27
  %t239 = load ptr, ptr %l0, !tbaa !29
  %t240 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t243 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2estub(ptr %v0, ptr %s2, ptr %s0, ptr %s2, ptr %t239, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d300, i32 0, i32 1) }, { i64, ptr } %t240)
  store { i64, ptr } %t243, ptr %l101
  br label %bb39
bb39:
  %t244 = load { i64, ptr }, ptr %l98, !tbaa !27
  %t245 = extractvalue { i64, ptr } %t244, 1
  %t246 = extractvalue { i64, ptr } %t244, 0
  %t247 = load { i64, ptr }, ptr %l101, !tbaa !27
  %t248 = extractvalue { i64, ptr } %t247, 1
  %t249 = extractvalue { i64, ptr } %t247, 0
  %t250 = add i64 %t246, %t249
  %t251 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t250)
  call void @olang_textcopy(ptr %t251, ptr %t245, i64 %t246)
  %t252 = getelementptr i8, ptr %t251, i64 %t246
  call void @olang_textcopy(ptr %t252, ptr %t248, i64 %t249)
  %t253 = insertvalue { i64, ptr } undef, i64 %t250, 0
  %t254 = insertvalue { i64, ptr } %t253, ptr %t251, 1
  %t256 = extractvalue { i64, ptr } %t254, 0
  %t257 = extractvalue { i64, ptr } %t254, 1
  %t258 = mul i64 %t256, 1
  %t259 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t258)
  call void @llvm.memcpy.p0.p0.i64(ptr %t259, ptr %t257, i64 %t258, i1 false)
  %t260 = insertvalue { i64, ptr } undef, i64 %t256, 0
  %t261 = insertvalue { i64, ptr } %t260, ptr %t259, 1
  %t262 = load ptr, ptr %l91, !tbaa !29
  %t263 = load { i64, [2 x i64] }, ptr %l92
  %t264 = load i32, ptr %l94, !tbaa !23
  %t265 = load { i64, ptr }, ptr %l95, !tbaa !27
  %t266 = load i64, ptr %l96, !tbaa !24
  %t267 = load i1, ptr %l97, !tbaa !21
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2efnItem(ptr %v0, ptr %s0, ptr %s2, ptr %t262, { i64, [2 x i64] } %t263, i32 %t264, { i64, ptr } %t265, i64 %t266, i1 %t267, { i64, ptr } %t261)
  br label %bb40
bb40:
  %t269 = load ptr, ptr %l0, !tbaa !29
  %t270 = load { i64, [2 x i64] }, ptr %l1
  %t271 = load ptr, ptr %l2, !tbaa !29
  %t273 = getelementptr %"compiler/mir:Fn", ptr %t271, i32 0, i32 1
  %t274 = load i32, ptr %t273, !tbaa !23
  %t275 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t276 = load i64, ptr %l5, !tbaa !24
  %t277 = load i1, ptr %l4, !tbaa !21
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2ewalkStub(ptr %v0, ptr %s0, ptr %s2, ptr %t269, { i64, [2 x i64] } %t270, i32 %t274, { i64, ptr } %t275, i64 %t276, i1 %t277, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d301, i32 0, i32 1) })
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb42:
  %t284 = load ptr, ptr %l0, !tbaa !29
  %t285 = load { i64, [2 x i64] }, ptr %l1
  %t286 = load ptr, ptr %l2, !tbaa !29
  %t287 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t288 = load i64, ptr %l5, !tbaa !24
  %t289 = load i1, ptr %l4, !tbaa !21
  %t290 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t298 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ewriteBody(ptr %v0, ptr %v0, ptr %s0, ptr %s0, ptr %t284, { i64, [2 x i64] } %t285, ptr %t286, { i64, ptr } %t287, i64 %t288, i1 %t289, { i64, ptr } %t290, i1 false)
  store i1 %t298, ptr %l118
  br label %bb43
bb43:
  %t299 = load i1, ptr %l118, !tbaa !21
  %t300 = xor i1 %t299, true
  br i1 %t300, label %bb44, label %bb45
bb44:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb45:
  br label %bb46
bb46:
  %t302 = load ptr, ptr %l0, !tbaa !29
  %t303 = load { i64, [2 x i64] }, ptr %l1
  %t306 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eisGenFn(ptr %v0, ptr %t302, { i64, [2 x i64] } %t303)
  store i1 %t306, ptr %l122
  br label %bb47
bb47:
  %t307 = load i1, ptr %l122, !tbaa !21
  br i1 %t307, label %bb48, label %bb49
bb48:
  store %olang.scope zeroinitializer, ptr %s9
  %t308 = load ptr, ptr %l0, !tbaa !29
  store ptr %t308, ptr %l123, !tbaa !29
  %t309 = load { i64, [2 x i64] }, ptr %l1
  store { i64, [2 x i64] } %t309, ptr %l124
  %t310 = load ptr, ptr %l2, !tbaa !29
  store ptr %t310, ptr %l125, !tbaa !29
  %t311 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t313 = extractvalue { i64, ptr } %t311, 1
  %t314 = extractvalue { i64, ptr } %t311, 0
  %t315 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d302, i32 0, i32 1) }, 1
  %t316 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d302, i32 0, i32 1) }, 0
  %t317 = add i64 %t314, %t316
  %t318 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t317)
  call void @olang_textcopy(ptr %t318, ptr %t313, i64 %t314)
  %t319 = getelementptr i8, ptr %t318, i64 %t314
  call void @olang_textcopy(ptr %t319, ptr %t315, i64 %t316)
  %t320 = insertvalue { i64, ptr } undef, i64 %t317, 0
  %t321 = insertvalue { i64, ptr } %t320, ptr %t318, 1
  %t323 = extractvalue { i64, ptr } %t321, 0
  %t324 = extractvalue { i64, ptr } %t321, 1
  %t325 = mul i64 %t323, 1
  %t326 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t325)
  call void @llvm.memcpy.p0.p0.i64(ptr %t326, ptr %t324, i64 %t325, i1 false)
  %t327 = insertvalue { i64, ptr } undef, i64 %t323, 0
  %t328 = insertvalue { i64, ptr } %t327, ptr %t326, 1
  store { i64, ptr } %t328, ptr %l128, !tbaa !27
  %t329 = load i64, ptr %l5, !tbaa !24
  store i64 %t329, ptr %l129, !tbaa !24
  %t330 = load i1, ptr %l4, !tbaa !21
  store i1 %t330, ptr %l130, !tbaa !21
  %t331 = load ptr, ptr %l0, !tbaa !29
  store ptr %t331, ptr %l131, !tbaa !29
  %t332 = load { i64, [2 x i64] }, ptr %l1
  store { i64, [2 x i64] } %t332, ptr %l132
  %t333 = load ptr, ptr %l2, !tbaa !29
  %t335 = getelementptr %"compiler/mir:Fn", ptr %t333, i32 0, i32 1
  %t336 = load i32, ptr %t335, !tbaa !23
  store i32 %t336, ptr %l134, !tbaa !23
  %t337 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t339 = extractvalue { i64, ptr } %t337, 1
  %t340 = extractvalue { i64, ptr } %t337, 0
  %t341 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d303, i32 0, i32 1) }, 1
  %t342 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d303, i32 0, i32 1) }, 0
  %t343 = add i64 %t340, %t342
  %t344 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t343)
  call void @olang_textcopy(ptr %t344, ptr %t339, i64 %t340)
  %t345 = getelementptr i8, ptr %t344, i64 %t340
  call void @olang_textcopy(ptr %t345, ptr %t341, i64 %t342)
  %t346 = insertvalue { i64, ptr } undef, i64 %t343, 0
  %t347 = insertvalue { i64, ptr } %t346, ptr %t344, 1
  %t349 = extractvalue { i64, ptr } %t347, 0
  %t350 = extractvalue { i64, ptr } %t347, 1
  %t351 = mul i64 %t349, 1
  %t352 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t351)
  call void @llvm.memcpy.p0.p0.i64(ptr %t352, ptr %t350, i64 %t351, i1 false)
  %t353 = insertvalue { i64, ptr } undef, i64 %t349, 0
  %t354 = insertvalue { i64, ptr } %t353, ptr %t352, 1
  store { i64, ptr } %t354, ptr %l137, !tbaa !27
  %t355 = load i64, ptr %l5, !tbaa !24
  store i64 %t355, ptr %l138, !tbaa !24
  %t356 = load i1, ptr %l4, !tbaa !21
  store i1 %t356, ptr %l139, !tbaa !21
  %t357 = load ptr, ptr %l0, !tbaa !29
  %t358 = load { i64, [2 x i64] }, ptr %l1
  %t361 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ehomeOf(ptr %v0, ptr %t357, { i64, [2 x i64] } %t358)
  store i64 %t361, ptr %l142
  br label %bb50
bb49:
  br label %bb54
bb50:
  %t362 = load i64, ptr %l142, !tbaa !24
  %t363 = call { i64, ptr } @compiler_2femit_2elinkFor(ptr %s9, i64 %t362)
  store { i64, ptr } %t363, ptr %l143
  br label %bb51
bb51:
  %t364 = load { i64, ptr }, ptr %l143, !tbaa !27
  %t365 = extractvalue { i64, ptr } %t364, 0
  %t366 = extractvalue { i64, ptr } %t364, 1
  %t367 = mul i64 %t365, 1
  %t368 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t367)
  call void @llvm.memcpy.p0.p0.i64(ptr %t368, ptr %t366, i64 %t367, i1 false)
  %t369 = insertvalue { i64, ptr } undef, i64 %t365, 0
  %t370 = insertvalue { i64, ptr } %t369, ptr %t368, 1
  %t371 = load ptr, ptr %l131, !tbaa !29
  %t372 = load { i64, [2 x i64] }, ptr %l132
  %t373 = load i32, ptr %l134, !tbaa !23
  %t374 = load { i64, ptr }, ptr %l137, !tbaa !27
  %t375 = load i64, ptr %l138, !tbaa !24
  %t376 = load i1, ptr %l139, !tbaa !21
  %t378 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eheader(ptr %v0, ptr %s9, ptr %s9, ptr %s9, ptr %t371, { i64, [2 x i64] } %t372, i32 %t373, { i64, ptr } %t374, i64 %t375, i1 %t376, { i64, ptr } %t370)
  store { i64, ptr } %t378, ptr %l145
  br label %bb52
bb52:
  %t379 = load { i64, ptr }, ptr %l145, !tbaa !27
  %t380 = extractvalue { i64, ptr } %t379, 0
  %t381 = extractvalue { i64, ptr } %t379, 1
  %t382 = mul i64 %t380, 1
  %t383 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t382)
  call void @llvm.memcpy.p0.p0.i64(ptr %t383, ptr %t381, i64 %t382, i1 false)
  %t384 = insertvalue { i64, ptr } undef, i64 %t380, 0
  %t385 = insertvalue { i64, ptr } %t384, ptr %t383, 1
  %t386 = load ptr, ptr %l123, !tbaa !29
  %t387 = load { i64, [2 x i64] }, ptr %l124
  %t388 = load ptr, ptr %l125, !tbaa !29
  %t389 = load { i64, ptr }, ptr %l128, !tbaa !27
  %t390 = load i64, ptr %l129, !tbaa !24
  %t391 = load i1, ptr %l130, !tbaa !21
  %t393 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ewriteBody(ptr %v0, ptr %v0, ptr %s9, ptr %s9, ptr %t386, { i64, [2 x i64] } %t387, ptr %t388, { i64, ptr } %t389, i64 %t390, i1 %t391, { i64, ptr } %t385, i1 true)
  store i1 %t393, ptr %l147
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s9)
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eglobal(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca %"compiler/eval:Image"
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l18 = alloca i1
  %l24 = alloca i64
  %l27 = alloca i1
  %l31 = alloca i1
  %l32 = alloca %"compiler/eval:Image"
  %l36 = alloca %"compiler/eval:Image"
  %l37 = alloca i32
  %l38 = alloca %"compiler/eval:Image"
  %l42 = alloca { i64, ptr }
  %l43 = alloca i64
  %l45 = alloca i64
  %l46 = alloca i32
  %l47 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i32
  %l53 = alloca i1
  %l57 = alloca { i64, ptr }
  %l58 = alloca { i64, ptr }
  %l60 = alloca i64
  %l62 = alloca i64
  %l63 = alloca i64
  %l72 = alloca i64
  %l74 = alloca i1
  %l76 = alloca %"compiler/eval:Blob"
  %l78 = alloca i64
  %l80 = alloca i1
  %l83 = alloca { i64, ptr }
  %l85 = alloca i64
  %l88 = alloca i64
  %l89 = alloca i64
  %l94 = alloca { i64, ptr }
  %l96 = alloca i64
  %l107 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t3 = load i32, ptr %l2, !tbaa !23
  %t7 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eglobalSym(ptr %v0, ptr %s0, ptr %t1, i64 %t2, i32 %t3)
  store { i64, ptr } %t7, ptr %l15
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t8, ptr %l4, !tbaa !27
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t13 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ehas(ptr %v0, ptr %s0, ptr %t9, { i64, ptr } %t10)
  store i1 %t13, ptr %l18
  br label %bb2
bb2:
  %t14 = load i1, ptr %l18, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t15 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t16 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d304, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d304, i32 0, i32 1) }, 0
  %t19 = extractvalue { i64, ptr } %t15, 1
  %t20 = extractvalue { i64, ptr } %t15, 0
  %t21 = add i64 %t17, %t20
  %t22 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t21)
  call void @olang_textcopy(ptr %t22, ptr %t16, i64 %t17)
  %t23 = getelementptr i8, ptr %t22, i64 %t17
  call void @olang_textcopy(ptr %t23, ptr %t19, i64 %t20)
  %t24 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t22, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t25, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load i64, ptr %l1, !tbaa !24
  %t29 = load i32, ptr %l2, !tbaa !23
  %t33 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eglobalBody(ptr %v0, ptr %t27, i64 %t28, i32 %t29)
  store i64 %t33, ptr %l24
  br label %bb6
bb6:
  %t34 = load i64, ptr %l24, !tbaa !24
  store i64 %t34, ptr %l5, !tbaa !24
  %t35 = load i64, ptr %l5, !tbaa !24
  %t37 = icmp sge i64 %t35, 0
  br i1 %t37, label %bb7, label %bb8
bb7:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/emit:Emitter", ptr %t39, i32 0, i32 44
  %t42 = load i64, ptr %l5, !tbaa !24
  %t45 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2feval_3aImage_3e_2e_H901ad831a5883703dcf426ee01511832(ptr %v0, ptr %t41, i64 %t42)
  store i1 %t45, ptr %l31
  br label %bb9
bb8:
  store i1 false, ptr %l27, !tbaa !21
  br label %bb10
bb9:
  %t46 = load i1, ptr %l31, !tbaa !21
  store i1 %t46, ptr %l27, !tbaa !21
  br label %bb10
bb10:
  %t47 = load i1, ptr %l27, !tbaa !21
  br i1 %t47, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s3
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/emit:Emitter", ptr %t48, i32 0, i32 44
  %t51 = load i64, ptr %l5, !tbaa !24
  %t54 = call { i32, %"compiler/eval:Image" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2feval_3aImage_3e_2e_Hf0a310b4530fd6279fda9cb6330ad681(ptr %v0, ptr %v0, ptr %t50, i64 %t51)
  %t55 = extractvalue { i32, %"compiler/eval:Image" } %t54, 1
  %t56 = extractvalue { i32, %"compiler/eval:Image" } %t54, 0
  store i32 %t56, ptr %l37
  %t57 = icmp ne i32 %t56, 0
  br i1 %t57, label %bb14, label %ok.58
ok.58:
  store %"compiler/eval:Image" %t55, ptr %l36
  br label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s9
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t63 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %s9, ptr %t59, i32 %a3)
  store { i64, ptr } %t63, ptr %l107
  br label %bb61
bb13:
  %t64 = load %"compiler/eval:Image", ptr %l36
  store %"compiler/eval:Image" %t64, ptr %l32
  br label %bb17
bb14:
  br label %bb15
bb15:
  call void @__olang_ert_req_clear()
  %t65 = call %"compiler/eval:Image" @compiler_2feval_3aImage_2ector(ptr %v0)
  store %"compiler/eval:Image" %t65, ptr %l38
  br label %bb16
bb16:
  %t66 = load %"compiler/eval:Image", ptr %l38
  store %"compiler/eval:Image" %t66, ptr %l32
  br label %bb17
bb17:
  %t67 = load %"compiler/eval:Image", ptr %l32
  store %"compiler/eval:Image" %t67, ptr %l6
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t73 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ebakedText(ptr %v0, ptr %s0, ptr %v0, ptr %s3, ptr %t68, { i64, ptr } %t69, ptr %l6)
  store { i64, ptr } %t73, ptr %l42
  br label %bb18
bb18:
  %t74 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t74, ptr %l7, !tbaa !27
  %t75 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t77 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %s3, ptr %s3, { i64, ptr } %t75, { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d305, i32 0, i32 1) })
  %t78 = extractvalue { i32, i64 } %t77, 1
  %t79 = extractvalue { i32, i64 } %t77, 0
  store i32 %t79, ptr %l46
  %t80 = icmp ne i32 %t79, 0
  br i1 %t80, label %bb20, label %ok.81
ok.81:
  store i64 %t78, ptr %l45
  br label %bb19
bb19:
  %t82 = load i64, ptr %l45, !tbaa !24
  store i64 %t82, ptr %l43, !tbaa !24
  br label %bb22
bb20:
  br label %bb21
bb21:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l43, !tbaa !24
  br label %bb22
bb22:
  %t83 = load i64, ptr %l43, !tbaa !24
  store i64 %t83, ptr %l8, !tbaa !24
  %t84 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t86 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %s3, ptr %s3, { i64, ptr } %t84, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d306, i32 0, i32 1) })
  %t87 = extractvalue { i32, i64 } %t86, 1
  %t88 = extractvalue { i32, i64 } %t86, 0
  store i32 %t88, ptr %l50
  %t89 = icmp ne i32 %t88, 0
  br i1 %t89, label %bb24, label %ok.90
ok.90:
  store i64 %t87, ptr %l49
  br label %bb23
bb23:
  %t91 = load i64, ptr %l49, !tbaa !24
  store i64 %t91, ptr %l47, !tbaa !24
  br label %bb26
bb24:
  br label %bb25
bb25:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l47, !tbaa !24
  br label %bb26
bb26:
  %t92 = load i64, ptr %l47, !tbaa !24
  store i64 %t92, ptr %l9, !tbaa !24
  %t93 = load i64, ptr %l8, !tbaa !24
  %t95 = icmp sge i64 %t93, 0
  br i1 %t95, label %bb27, label %bb28
bb27:
  %t97 = load i64, ptr %l9, !tbaa !24
  %t98 = load i64, ptr %l8, !tbaa !24
  %t101 = icmp sgt i64 %t97, %t98
  store i1 %t101, ptr %l53, !tbaa !21
  br label %bb29
bb28:
  store i1 false, ptr %l53, !tbaa !21
  br label %bb29
bb29:
  %t103 = load i1, ptr %l53, !tbaa !21
  br i1 %t103, label %bb30, label %bb31
bb30:
  %t104 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t104, ptr %l58, !tbaa !27
  %t105 = load i64, ptr %l8, !tbaa !24
  %t107 = add i64 %t105, 12
  store i64 %t107, ptr %l60, !tbaa !24
  %t108 = load i64, ptr %l9, !tbaa !24
  %t110 = add i64 %t108, 2
  store i64 %t110, ptr %l62, !tbaa !24
  %t111 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t112 = extractvalue { i64, ptr } %t111, 0
  store i64 %t112, ptr %l63, !tbaa !24
  %t113 = load i64, ptr %l60, !tbaa !24
  %t114 = icmp sge i64 %t113, 0
  br i1 %t114, label %bb32, label %bb33
bb31:
  %t116 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t117 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d307, i32 0, i32 1) }, 1
  %t118 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d307, i32 0, i32 1) }, 0
  %t120 = extractvalue { i64, ptr } %t116, 1
  %t121 = extractvalue { i64, ptr } %t116, 0
  %t122 = add i64 %t118, %t121
  %t123 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d308, i32 0, i32 1) }, 1
  %t124 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d308, i32 0, i32 1) }, 0
  %t125 = add i64 %t122, %t124
  %t126 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t125)
  call void @olang_textcopy(ptr %t126, ptr %t117, i64 %t118)
  %t127 = getelementptr i8, ptr %t126, i64 %t118
  call void @olang_textcopy(ptr %t127, ptr %t120, i64 %t121)
  %t128 = getelementptr i8, ptr %t127, i64 %t121
  call void @olang_textcopy(ptr %t128, ptr %t123, i64 %t124)
  %t129 = insertvalue { i64, ptr } undef, i64 %t125, 0
  %t130 = insertvalue { i64, ptr } %t129, ptr %t126, 1
  store { i64, ptr } %t130, ptr %l57, !tbaa !27
  br label %bb38
bb32:
  %t132 = load i64, ptr %l60, !tbaa !24
  %t133 = load i64, ptr %l62, !tbaa !24
  %t134 = icmp sle i64 %t132, %t133
  br i1 %t134, label %bb34, label %bb35
bb33:
  call void @__olang_check_failed(ptr @olang_loc_67352ecb15e68ba0_c3979b973b302ad4)
  unreachable
bb34:
  %t136 = load i64, ptr %l62, !tbaa !24
  %t137 = load i64, ptr %l63, !tbaa !24
  %t138 = icmp sle i64 %t136, %t137
  br i1 %t138, label %bb36, label %bb37
bb35:
  call void @__olang_check_failed(ptr @olang_loc_67352ecb15e68ba0_c3979b973b302ad4)
  unreachable
bb36:
  %t140 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t141 = load ptr, ptr %t140, !tbaa !27
  %t142 = load i64, ptr %l60, !tbaa !24
  %t143 = load i64, ptr %l62, !tbaa !24
  %t144 = getelementptr i8, ptr %t141, i64 %t142
  %t145 = sub i64 %t143, %t142
  %t146 = insertvalue { i64, ptr } undef, i64 %t145, 0
  %t147 = insertvalue { i64, ptr } %t146, ptr %t144, 1
  %t148 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d309, i32 0, i32 1) }, 1
  %t149 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d309, i32 0, i32 1) }, 0
  %t150 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t151 = extractvalue { i64, ptr } %t150, 1
  %t152 = extractvalue { i64, ptr } %t150, 0
  %t153 = add i64 %t149, %t152
  %t154 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d310, i32 0, i32 1) }, 1
  %t155 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d310, i32 0, i32 1) }, 0
  %t156 = add i64 %t153, %t155
  %t158 = extractvalue { i64, ptr } %t147, 1
  %t159 = extractvalue { i64, ptr } %t147, 0
  %t160 = add i64 %t156, %t159
  %t161 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t160)
  call void @olang_textcopy(ptr %t161, ptr %t148, i64 %t149)
  %t162 = getelementptr i8, ptr %t161, i64 %t149
  call void @olang_textcopy(ptr %t162, ptr %t151, i64 %t152)
  %t163 = getelementptr i8, ptr %t162, i64 %t152
  call void @olang_textcopy(ptr %t163, ptr %t154, i64 %t155)
  %t164 = getelementptr i8, ptr %t163, i64 %t155
  call void @olang_textcopy(ptr %t164, ptr %t158, i64 %t159)
  %t165 = insertvalue { i64, ptr } undef, i64 %t160, 0
  %t166 = insertvalue { i64, ptr } %t165, ptr %t161, 1
  store { i64, ptr } %t166, ptr %l57, !tbaa !27
  br label %bb38
bb37:
  call void @__olang_check_failed(ptr @olang_loc_67352ecb15e68ba0_c3979b973b302ad4)
  unreachable
bb38:
  %t168 = load { i64, ptr }, ptr %l57, !tbaa !27
  store { i64, ptr } %t168, ptr %l10, !tbaa !27
  %t169 = getelementptr %"compiler/eval:Image", ptr %l6, i32 0, i32 0
  %t171 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aBlob_3e_2eLen_3ccompiler_2feval_3aBlob_3e(ptr %v0, ptr %t169)
  store i64 %t171, ptr %l72
  br label %bb39
bb39:
  %t172 = load i64, ptr %l72, !tbaa !24
  %t173 = icmp eq i64 %t172, 1
  br i1 %t173, label %bb40, label %bb41
bb40:
  %t175 = getelementptr %"compiler/eval:Image", ptr %l6, i32 0, i32 0
  %t177 = call %"compiler/eval:Blob" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aBlob_3e_2eAt_3ccompiler_2feval_3aBlob_3e(ptr %v0, ptr %v0, ptr %t175, i64 0)
  store %"compiler/eval:Blob" %t177, ptr %l76
  br label %bb42
bb41:
  store i1 false, ptr %l74, !tbaa !21
  br label %bb44
bb42:
  %t178 = getelementptr %"compiler/eval:Blob", ptr %l76, i32 0, i32 3
  %t180 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t178)
  store i64 %t180, ptr %l78
  br label %bb43
bb43:
  %t181 = load i64, ptr %l78, !tbaa !24
  %t182 = icmp eq i64 %t181, 0
  store i1 %t182, ptr %l74, !tbaa !21
  br label %bb44
bb44:
  %t184 = load i1, ptr %l74, !tbaa !21
  br i1 %t184, label %bb45, label %bb46
bb45:
  %t185 = load i64, ptr %l8, !tbaa !24
  %t187 = icmp sge i64 %t185, 0
  store i1 %t187, ptr %l80, !tbaa !21
  br label %bb47
bb46:
  store i1 false, ptr %l80, !tbaa !21
  br label %bb47
bb47:
  %t189 = load i1, ptr %l80, !tbaa !21
  br i1 %t189, label %bb48, label %bb49
bb48:
  %t190 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t190, ptr %l83, !tbaa !27
  %t191 = load i64, ptr %l8, !tbaa !24
  %t193 = add i64 %t191, 12
  store i64 %t193, ptr %l85, !tbaa !24
  %t194 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t196 = extractvalue { i64, ptr } %t194, 0
  %t198 = sub i64 %t196, 1
  store i64 %t198, ptr %l88, !tbaa !24
  %t199 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t200 = extractvalue { i64, ptr } %t199, 0
  store i64 %t200, ptr %l89, !tbaa !24
  %t201 = load i64, ptr %l85, !tbaa !24
  %t202 = icmp sge i64 %t201, 0
  br i1 %t202, label %bb50, label %bb51
bb49:
  br label %bb59
bb50:
  %t204 = load i64, ptr %l85, !tbaa !24
  %t205 = load i64, ptr %l88, !tbaa !24
  %t206 = icmp sle i64 %t204, %t205
  br i1 %t206, label %bb52, label %bb53
bb51:
  call void @__olang_check_failed(ptr @olang_loc_6c4f253a42e065fd_ca2f6afe461eeb41)
  unreachable
bb52:
  %t208 = load i64, ptr %l88, !tbaa !24
  %t209 = load i64, ptr %l89, !tbaa !24
  %t210 = icmp sle i64 %t208, %t209
  br i1 %t210, label %bb54, label %bb55
bb53:
  call void @__olang_check_failed(ptr @olang_loc_6c4f253a42e065fd_ca2f6afe461eeb41)
  unreachable
bb54:
  %t212 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t213 = load ptr, ptr %t212, !tbaa !27
  %t214 = load i64, ptr %l85, !tbaa !24
  %t215 = load i64, ptr %l88, !tbaa !24
  %t216 = getelementptr i8, ptr %t213, i64 %t214
  %t217 = sub i64 %t215, %t214
  %t218 = insertvalue { i64, ptr } undef, i64 %t217, 0
  %t219 = insertvalue { i64, ptr } %t218, ptr %t216, 1
  %t220 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d311, i32 0, i32 1) }, 1
  %t221 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d311, i32 0, i32 1) }, 0
  %t222 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t223 = extractvalue { i64, ptr } %t222, 1
  %t224 = extractvalue { i64, ptr } %t222, 0
  %t225 = add i64 %t221, %t224
  %t226 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d312, i32 0, i32 1) }, 1
  %t227 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d312, i32 0, i32 1) }, 0
  %t228 = add i64 %t225, %t227
  %t230 = extractvalue { i64, ptr } %t219, 1
  %t231 = extractvalue { i64, ptr } %t219, 0
  %t232 = add i64 %t228, %t231
  %t233 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t232)
  call void @olang_textcopy(ptr %t233, ptr %t220, i64 %t221)
  %t234 = getelementptr i8, ptr %t233, i64 %t221
  call void @olang_textcopy(ptr %t234, ptr %t223, i64 %t224)
  %t235 = getelementptr i8, ptr %t234, i64 %t224
  call void @olang_textcopy(ptr %t235, ptr %t226, i64 %t227)
  %t236 = getelementptr i8, ptr %t235, i64 %t227
  call void @olang_textcopy(ptr %t236, ptr %t230, i64 %t231)
  %t237 = insertvalue { i64, ptr } undef, i64 %t232, 0
  %t238 = insertvalue { i64, ptr } %t237, ptr %t233, 1
  store { i64, ptr } %t238, ptr %l94, !tbaa !27
  %t239 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t240 = extractvalue { i64, ptr } %t239, 0
  %t241 = load { i64, ptr }, ptr %l94, !tbaa !27
  %t242 = extractvalue { i64, ptr } %t241, 0
  store i64 %t242, ptr %l96, !tbaa !24
  %t244 = load i64, ptr %l96, !tbaa !24
  %t245 = icmp eq i64 %t240, %t244
  br i1 %t245, label %bb56, label %bb57
bb55:
  call void @__olang_check_failed(ptr @olang_loc_6c4f253a42e065fd_ca2f6afe461eeb41)
  unreachable
bb56:
  %t247 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t248 = load ptr, ptr %t247, !tbaa !27
  %t249 = getelementptr { i64, ptr }, ptr %l94, i32 0, i32 1
  %t250 = load ptr, ptr %t249, !tbaa !27
  %t251 = load i64, ptr %l96, !tbaa !24
  %t252 = mul i64 %t251, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t248, ptr %t250, i64 %t252, i1 false)
  br label %bb58
bb57:
  %t253 = load { i64, ptr }, ptr %l94, !tbaa !27
  store { i64, ptr } %t253, ptr %l10, !tbaa !27
  br label %bb58
bb58:
  br label %bb59
bb59:
  %t254 = load ptr, ptr %l0, !tbaa !29
  %t255 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t256 = load i64, ptr %l1, !tbaa !24
  %t257 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t258 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t260 = extractvalue { i64, ptr } %t258, 1
  %t261 = extractvalue { i64, ptr } %t258, 0
  %t262 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d313, i32 0, i32 1) }, 1
  %t263 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d313, i32 0, i32 1) }, 0
  %t264 = add i64 %t261, %t263
  %t265 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t264)
  call void @olang_textcopy(ptr %t265, ptr %t260, i64 %t261)
  %t266 = getelementptr i8, ptr %t265, i64 %t261
  call void @olang_textcopy(ptr %t266, ptr %t262, i64 %t263)
  %t267 = insertvalue { i64, ptr } undef, i64 %t264, 0
  %t268 = insertvalue { i64, ptr } %t267, ptr %t265, 1
  %t270 = extractvalue { i64, ptr } %t268, 0
  %t271 = extractvalue { i64, ptr } %t268, 1
  %t272 = mul i64 %t270, 1
  %t273 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t272)
  call void @llvm.memcpy.p0.p0.i64(ptr %t273, ptr %t271, i64 %t272, i1 false)
  %t274 = insertvalue { i64, ptr } undef, i64 %t270, 0
  %t275 = insertvalue { i64, ptr } %t274, ptr %t273, 1
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eitem(ptr %v0, ptr %s0, ptr %s3, ptr %s3, ptr %t254, { i64, ptr } %t255, i64 %t256, { i64, ptr } %t257, { i64, ptr } %t275)
  br label %bb60
bb60:
  call void @__olang_scope_close(ptr %s3)
  br label %bb63
bb61:
  %t281 = load { i64, ptr }, ptr %l107, !tbaa !27
  store { i64, ptr } %t281, ptr %l11, !tbaa !27
  %t282 = load ptr, ptr %l0, !tbaa !29
  %t283 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t284 = load i64, ptr %l1, !tbaa !24
  %t285 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t286 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t287 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d314, i32 0, i32 1) }, 1
  %t288 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d314, i32 0, i32 1) }, 0
  %t290 = extractvalue { i64, ptr } %t285, 1
  %t291 = extractvalue { i64, ptr } %t285, 0
  %t292 = add i64 %t288, %t291
  %t293 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d315, i32 0, i32 1) }, 1
  %t294 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d315, i32 0, i32 1) }, 0
  %t295 = add i64 %t292, %t294
  %t297 = extractvalue { i64, ptr } %t286, 1
  %t298 = extractvalue { i64, ptr } %t286, 0
  %t299 = add i64 %t295, %t298
  %t300 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d316, i32 0, i32 1) }, 1
  %t301 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d316, i32 0, i32 1) }, 0
  %t302 = add i64 %t299, %t301
  %t303 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t302)
  call void @olang_textcopy(ptr %t303, ptr %t287, i64 %t288)
  %t304 = getelementptr i8, ptr %t303, i64 %t288
  call void @olang_textcopy(ptr %t304, ptr %t290, i64 %t291)
  %t305 = getelementptr i8, ptr %t304, i64 %t291
  call void @olang_textcopy(ptr %t305, ptr %t293, i64 %t294)
  %t306 = getelementptr i8, ptr %t305, i64 %t294
  call void @olang_textcopy(ptr %t306, ptr %t297, i64 %t298)
  %t307 = getelementptr i8, ptr %t306, i64 %t298
  call void @olang_textcopy(ptr %t307, ptr %t300, i64 %t301)
  %t308 = insertvalue { i64, ptr } undef, i64 %t302, 0
  %t309 = insertvalue { i64, ptr } %t308, ptr %t303, 1
  %t311 = extractvalue { i64, ptr } %t309, 0
  %t312 = extractvalue { i64, ptr } %t309, 1
  %t313 = mul i64 %t311, 1
  %t314 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t313)
  call void @llvm.memcpy.p0.p0.i64(ptr %t314, ptr %t312, i64 %t313, i1 false)
  %t315 = insertvalue { i64, ptr } undef, i64 %t311, 0
  %t316 = insertvalue { i64, ptr } %t315, ptr %t314, 1
  %t317 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t318 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t319 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d317, i32 0, i32 1) }, 1
  %t320 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d317, i32 0, i32 1) }, 0
  %t322 = extractvalue { i64, ptr } %t317, 1
  %t323 = extractvalue { i64, ptr } %t317, 0
  %t324 = add i64 %t320, %t323
  %t325 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d318, i32 0, i32 1) }, 1
  %t326 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d318, i32 0, i32 1) }, 0
  %t327 = add i64 %t324, %t326
  %t329 = extractvalue { i64, ptr } %t318, 1
  %t330 = extractvalue { i64, ptr } %t318, 0
  %t331 = add i64 %t327, %t330
  %t332 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d319, i32 0, i32 1) }, 1
  %t333 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d319, i32 0, i32 1) }, 0
  %t334 = add i64 %t331, %t333
  %t335 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t334)
  call void @olang_textcopy(ptr %t335, ptr %t319, i64 %t320)
  %t336 = getelementptr i8, ptr %t335, i64 %t320
  call void @olang_textcopy(ptr %t336, ptr %t322, i64 %t323)
  %t337 = getelementptr i8, ptr %t336, i64 %t323
  call void @olang_textcopy(ptr %t337, ptr %t325, i64 %t326)
  %t338 = getelementptr i8, ptr %t337, i64 %t326
  call void @olang_textcopy(ptr %t338, ptr %t329, i64 %t330)
  %t339 = getelementptr i8, ptr %t338, i64 %t330
  call void @olang_textcopy(ptr %t339, ptr %t332, i64 %t333)
  %t340 = insertvalue { i64, ptr } undef, i64 %t334, 0
  %t341 = insertvalue { i64, ptr } %t340, ptr %t335, 1
  %t343 = extractvalue { i64, ptr } %t341, 0
  %t344 = extractvalue { i64, ptr } %t341, 1
  %t345 = mul i64 %t343, 1
  %t346 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t345)
  call void @llvm.memcpy.p0.p0.i64(ptr %t346, ptr %t344, i64 %t345, i1 false)
  %t347 = insertvalue { i64, ptr } undef, i64 %t343, 0
  %t348 = insertvalue { i64, ptr } %t347, ptr %t346, 1
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eitem(ptr %v0, ptr %s0, ptr %s9, ptr %s9, ptr %t282, { i64, ptr } %t283, i64 %t284, { i64, ptr } %t316, { i64, ptr } %t348)
  br label %bb62
bb62:
  call void @__olang_scope_close(ptr %s9)
  br label %bb63
bb63:
  %t354 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t355 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d320, i32 0, i32 1) }, 1
  %t356 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d320, i32 0, i32 1) }, 0
  %t358 = extractvalue { i64, ptr } %t354, 1
  %t359 = extractvalue { i64, ptr } %t354, 0
  %t360 = add i64 %t356, %t359
  %t361 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t360)
  call void @olang_textcopy(ptr %t361, ptr %t355, i64 %t356)
  %t362 = getelementptr i8, ptr %t361, i64 %t356
  call void @olang_textcopy(ptr %t362, ptr %t358, i64 %t359)
  %t363 = insertvalue { i64, ptr } undef, i64 %t360, 0
  %t364 = insertvalue { i64, ptr } %t363, ptr %t361, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t364, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ehas(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l5 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %a0, i32 0, i32 19
  %t7 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9b83f66eba65594537030636cb0b52b7(ptr %v0, ptr %v1, ptr %t3, { i64, ptr } %a1)
  store i1 %t7, ptr %l5
  br label %bb1
bb1:
  %t8 = load i1, ptr %l5, !tbaa !21
  store i1 %t8, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eisGen(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1) #0 {
entry:
  %l1 = alloca { i64, [2 x i64] }
  %l2 = alloca i32
  %l3 = alloca i1
  %l12 = alloca ptr
  %rv = alloca i1
  store { i64, [2 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [2 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [2 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { i32 }, ptr %t6, i32 0, i32 0
  %t8 = load i32, ptr %t7
  store i32 %t8, ptr %l2, !tbaa !23
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t12 = getelementptr %"compiler/emit:Emitter", ptr %a0, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = getelementptr %"compiler/lower:Lowerer", ptr %t13, i32 0, i32 1
  %t16 = load i32, ptr %l2, !tbaa !23
  %t18 = sext i32 %t16 to i64
  %t21 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t15, i64 %t18)
  store ptr %t21, ptr %l12
  br label %bb4
bb4:
  %t22 = load ptr, ptr %l12, !tbaa !29
  %t24 = getelementptr %"compiler/typed:Body", ptr %t22, i32 0, i32 15
  %t25 = load i1, ptr %t24, !tbaa !21
  store i1 %t25, ptr %l3, !tbaa !21
  br label %bb10
bb5:
  br i1 true, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb9
bb8:
  store i1 false, ptr %l3, !tbaa !21
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_a37d1f87ccda68bc_daadd8872686b520)
  unreachable
bb10:
  %t27 = load i1, ptr %l3, !tbaa !21
  store i1 %t27, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eisGenFn(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [2 x i64] }
  %l2 = alloca i32
  %l3 = alloca { i64, [2 x i64] }
  %l4 = alloca i64
  %l5 = alloca i1
  %l14 = alloca ptr
  %l17 = alloca i1
  %l22 = alloca ptr
  %l26 = alloca i64
  %l27 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store { i64, [2 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [2 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [2 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { i32 }, ptr %t6, i32 0, i32 0
  %t8 = load i32, ptr %t7
  store i32 %t8, ptr %l2, !tbaa !23
  br label %bb3
bb2:
  br label %bb16
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/emit:Emitter", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = getelementptr %"compiler/lower:Lowerer", ptr %t13, i32 0, i32 1
  %t16 = load i32, ptr %l2, !tbaa !23
  %t18 = sext i32 %t16 to i64
  %t21 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t15, i64 %t18)
  store ptr %t21, ptr %l14
  br label %bb4
bb4:
  %t22 = load ptr, ptr %l14, !tbaa !29
  %t24 = getelementptr %"compiler/typed:Body", ptr %t22, i32 0, i32 1
  %t25 = load { i64, [2 x i64] }, ptr %t24
  store { i64, [2 x i64] } %t25, ptr %l3
  %t27 = load { i64, [2 x i64] }, ptr %l3
  %t29 = extractvalue { i64, [2 x i64] } %t27, 0
  %t30 = icmp eq i64 %t29, 0
  br i1 %t30, label %bb5, label %bb6
bb5:
  %t32 = getelementptr { i64, [2 x i64] }, ptr %l3, i32 0, i32 1
  %t33 = getelementptr { i64 }, ptr %t32, i32 0, i32 0
  %t34 = load i64, ptr %t33
  store i64 %t34, ptr %l4, !tbaa !24
  br label %bb7
bb6:
  br label %bb10
bb7:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/emit:Emitter", ptr %t36, i32 0, i32 0
  %t39 = load ptr, ptr %t38, !tbaa !29
  store ptr %t39, ptr %l22, !tbaa !29
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/emit:Emitter", ptr %t40, i32 0, i32 0
  %t43 = load ptr, ptr %t42, !tbaa !29
  %t44 = load i64, ptr %l4, !tbaa !24
  %t47 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t43, i64 %t44)
  store i64 %t47, ptr %l26
  br label %bb8
bb8:
  %t48 = load ptr, ptr %l22, !tbaa !29
  %t49 = load i64, ptr %l26, !tbaa !24
  %t50 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsGenerator(ptr %v0, ptr %t48, i64 %t49)
  store i1 %t50, ptr %l27
  br label %bb9
bb9:
  %t51 = load i1, ptr %l27, !tbaa !21
  store i1 %t51, ptr %l17, !tbaa !21
  br label %bb15
bb10:
  br i1 true, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb15
bb14:
  call void @__olang_check_failed(ptr @olang_loc_9224769184a821c8_ff8c445af92d13bc)
  unreachable
bb15:
  %t52 = load i1, ptr %l17, !tbaa !21
  store i1 %t52, ptr %l5, !tbaa !21
  br label %bb21
bb16:
  br i1 true, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  store i1 false, ptr %l5, !tbaa !21
  br label %bb21
bb20:
  call void @__olang_check_failed(ptr @olang_loc_68254245c55f7699_2855b47650ff1f6d)
  unreachable
bb21:
  %t53 = load i1, ptr %l5, !tbaa !21
  store i1 %t53, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2elocations(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l3 = alloca %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce"
  %l4 = alloca %"std/prelude/map:MapEntry.eb00e4a6e4307a4e46e40fbcd79d6b4f"
  %l5 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"std/prelude/text:StringBuilder"
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l12 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l14 = alloca %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce"
  %l15 = alloca %"std/prelude/map:MapEntry.eb00e4a6e4307a4e46e40fbcd79d6b4f"
  %l17 = alloca %"std/prelude/map:MapEntry.eb00e4a6e4307a4e46e40fbcd79d6b4f"
  %l18 = alloca i32
  %l20 = alloca i1
  %l26 = alloca { i64, ptr }
  %l30 = alloca %"std/prelude/text:StringBuilder"
  %l31 = alloca ptr
  %l33 = alloca { i64, ptr }
  %l42 = alloca { i64, ptr }
  %l45 = alloca ptr
  %l49 = alloca { i64, ptr }
  %l53 = alloca { i64, ptr }
  %l54 = alloca { i64, ptr }
  %l55 = alloca i64
  %l56 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t35 = alloca { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l12
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l12
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l2
  %t5 = call %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eIter_3cI64_2c_20Bool_3e(ptr %v1, ptr %v1, ptr %a1)
  store %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce" %t5, ptr %l14
  br label %bb2
bb2:
  %t6 = load %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce", ptr %l14
  store %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce" %t6, ptr %l3
  br label %bb3
bb3:
  %t8 = call { i32, %"std/prelude/map:MapEntry.eb00e4a6e4307a4e46e40fbcd79d6b4f" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3cI64_2c_20Bool_3e_2eNext_3cI64_2c_20Bool_3e(ptr %v1, ptr %l3)
  %t9 = extractvalue { i32, %"std/prelude/map:MapEntry.eb00e4a6e4307a4e46e40fbcd79d6b4f" } %t8, 1
  %t10 = extractvalue { i32, %"std/prelude/map:MapEntry.eb00e4a6e4307a4e46e40fbcd79d6b4f" } %t8, 0
  store i32 %t10, ptr %l18
  %t11 = icmp ne i32 %t10, 0
  br i1 %t11, label %bb5, label %ok.12
ok.12:
  store %"std/prelude/map:MapEntry.eb00e4a6e4307a4e46e40fbcd79d6b4f" %t9, ptr %l17
  br label %bb4
bb4:
  %t13 = load %"std/prelude/map:MapEntry.eb00e4a6e4307a4e46e40fbcd79d6b4f", ptr %l17
  store %"std/prelude/map:MapEntry.eb00e4a6e4307a4e46e40fbcd79d6b4f" %t13, ptr %l15
  br label %bb7
bb5:
  %t14 = load i32, ptr %l18, !tbaa !23
  %t15 = ashr i32 %t14, 16
  %t17 = icmp eq i32 %t15, 1
  store i1 %t17, ptr %l20, !tbaa !21
  br label %bb6
bb6:
  call void @__olang_ert_req_clear()
  br label %bb10
bb7:
  %t18 = load %"std/prelude/map:MapEntry.eb00e4a6e4307a4e46e40fbcd79d6b4f", ptr %l15
  store %"std/prelude/map:MapEntry.eb00e4a6e4307a4e46e40fbcd79d6b4f" %t18, ptr %l4
  %t19 = getelementptr %"std/prelude/map:MapEntry.eb00e4a6e4307a4e46e40fbcd79d6b4f", ptr %l4, i32 0, i32 0
  %t20 = load i64, ptr %t19, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l2, i64 %t20)
  br label %bb8
bb8:
  br label %bb9
bb9:
  br label %bb3
bb10:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/emit:Emitter", ptr %t23, i32 0, i32 15
  %t26 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t25
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t26, ptr %l5
  %t29 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %s0, ptr %s0, ptr %l2)
  store { i64, ptr } %t29, ptr %l26
  br label %bb11
bb11:
  %t30 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t30, ptr %l6, !tbaa !27
  %t31 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t32 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l5
  %t33 = getelementptr { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr }, ptr null, i32 1
  %t34 = ptrtoint ptr %t33 to i64
  %t36 = getelementptr { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr }, ptr %t35, i32 0, i32 0
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t32, ptr %t36, !tbaa !28
  call void @__olang_scope_escape(ptr %v0)
  %t38 = getelementptr { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr }, ptr %t35, i32 0, i32 1
  store ptr %v0, ptr %t38, !tbaa !28
  %t39 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_321, 0
  %t40 = insertvalue { ptr, ptr } %t39, ptr %t35, 1
  %t43 = extractvalue { ptr, ptr } %t40, 0
  %t44 = extractvalue { ptr, ptr } %t40, 1
  call void @std_2fprelude_2farray_2eArray_3cI64_3e_2eSort_3cI64_2c_20_3f_3e(ptr %s0, ptr %s0, { i64, ptr } %t31, ptr %t43, ptr %t44)
  br label %bb12
bb12:
  %t45 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t45, ptr %l30
  br label %bb13
bb13:
  %t46 = load %"std/prelude/text:StringBuilder", ptr %l30
  store %"std/prelude/text:StringBuilder" %t46, ptr %l7
  store ptr %l7, ptr %l31, !tbaa !29
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ehead(ptr %v0, ptr %s0, ptr %t47)
  store { i64, ptr } %t49, ptr %l33
  br label %bb14
bb14:
  %t50 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t51 = extractvalue { i64, ptr } %t50, 0
  %t52 = extractvalue { i64, ptr } %t50, 1
  %t53 = mul i64 %t51, 1
  %t54 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t53)
  call void @llvm.memcpy.p0.p0.i64(ptr %t54, ptr %t52, i64 %t53, i1 false)
  %t55 = insertvalue { i64, ptr } undef, i64 %t51, 0
  %t56 = insertvalue { i64, ptr } %t55, ptr %t54, 1
  %t57 = load ptr, ptr %l31, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t57, { i64, ptr } %t56)
  br label %bb15
bb15:
  %t59 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t59, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t61 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t63 = extractvalue { i64, ptr } %t61, 0
  store i64 %t63, ptr %l10, !tbaa !24
  br label %bb16
bb16:
  %t65 = load i64, ptr %l9, !tbaa !24
  %t66 = load i64, ptr %l10, !tbaa !24
  %t69 = icmp slt i64 %t65, %t66
  %t71 = xor i1 %t69, true
  br i1 %t71, label %bb17, label %bb18
bb17:
  br label %bb23
bb18:
  br label %bb19
bb19:
  %t73 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t73, ptr %l42, !tbaa !27
  %t74 = load i64, ptr %l9, !tbaa !24
  %t76 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !27
  %t78 = getelementptr i64, ptr %t77, i64 %t74
  %t79 = load i64, ptr %t78, !tbaa !34
  store ptr %l7, ptr %l45, !tbaa !29
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/emit:Emitter", ptr %t81, i32 0, i32 16
  %t87 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t83, i64 %t79)
  store { i64, ptr } %t87, ptr %l49
  br label %bb20
bb20:
  %t88 = load ptr, ptr %l45, !tbaa !29
  %t89 = load { i64, ptr }, ptr %l49, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t88, { i64, ptr } %t89)
  br label %bb21
bb21:
  br label %bb22
bb22:
  %t90 = load i64, ptr %l9, !tbaa !24
  %t92 = add i64 %t90, 1
  store i64 %t92, ptr %l9, !tbaa !24
  br label %bb16
bb23:
  %t95 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l7)
  store { i64, ptr } %t95, ptr %l53
  br label %bb24
bb24:
  %t96 = load { i64, ptr }, ptr %l53, !tbaa !27
  store { i64, ptr } %t96, ptr %l54, !tbaa !27
  %t97 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t98 = extractvalue { i64, ptr } %t97, 0
  store i64 %t98, ptr %l55, !tbaa !24
  %t99 = load i64, ptr %l55, !tbaa !24
  %t100 = mul i64 %t99, 1
  %t101 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t100)
  %t102 = insertvalue { i64, ptr } undef, i64 %t99, 0
  %t103 = insertvalue { i64, ptr } %t102, ptr %t101, 1
  store { i64, ptr } %t103, ptr %l56, !tbaa !27
  %t104 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !27
  %t106 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !27
  %t108 = load i64, ptr %l55, !tbaa !24
  %t109 = mul i64 %t108, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t105, ptr %t107, i64 %t109, i1 false)
  %t110 = load { i64, ptr }, ptr %l56, !tbaa !27
  store { i64, ptr } %t110, ptr %l54, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t111 = load { i64, ptr }, ptr %l54, !tbaa !27
  store { i64, ptr } %t111, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2epartOf(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l11 = alloca i1
  %l12 = alloca i64
  %l13 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i32
  %l24 = alloca { i64, ptr }
  %l26 = alloca i1
  %l27 = alloca i64
  %l29 = alloca i64
  %l34 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp sle i64 %t1, 1
  br i1 %t3, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  store i64 0, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load i64, ptr %l1, !tbaa !24
  %t10 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ealiased(ptr %v0, ptr %t6, i64 %t7)
  store i1 %t10, ptr %l11
  br label %bb4
bb4:
  %t11 = load i1, ptr %l11, !tbaa !21
  br i1 %t11, label %bb5, label %bb6
bb5:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/emit:Emitter", ptr %t12, i32 0, i32 63
  %t15 = load i64, ptr %l1, !tbaa !24
  %t18 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t14, i64 %t15)
  %t19 = extractvalue { i32, i64 } %t18, 1
  %t20 = extractvalue { i32, i64 } %t18, 0
  store i32 %t20, ptr %l18
  %t21 = icmp ne i32 %t20, 0
  br i1 %t21, label %bb8, label %ok.22
ok.22:
  store i64 %t19, ptr %l17
  br label %bb7
bb6:
  %t23 = load i64, ptr %l1, !tbaa !24
  store i64 %t23, ptr %l12, !tbaa !24
  br label %bb11
bb7:
  %t25 = load i64, ptr %l17, !tbaa !24
  store i64 %t25, ptr %l13, !tbaa !24
  br label %bb10
bb8:
  br label %bb9
bb9:
  call void @__olang_ert_req_clear()
  %t26 = load i64, ptr %l1, !tbaa !24
  store i64 %t26, ptr %l13, !tbaa !24
  br label %bb10
bb10:
  %t28 = load i64, ptr %l13, !tbaa !24
  store i64 %t28, ptr %l12, !tbaa !24
  br label %bb11
bb11:
  %t29 = load i64, ptr %l12, !tbaa !24
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/emit:Emitter", ptr %t30, i32 0, i32 15
  %t36 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t32, i64 %t29)
  store { i64, ptr } %t36, ptr %l24
  br label %bb12
bb12:
  %t37 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t37, ptr %l4, !tbaa !27
  %t38 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t40 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t38, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d322, i32 0, i32 1) })
  store i1 %t40, ptr %l26
  br label %bb13
bb13:
  %t41 = load i1, ptr %l26, !tbaa !21
  br i1 %t41, label %bb14, label %bb15
bb14:
  store i64 0, ptr %l27, !tbaa !24
  br label %bb17
bb15:
  %t42 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t44 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eHash(ptr %v0, { i64, ptr } %t42)
  store i64 %t44, ptr %l29
  br label %bb16
bb16:
  %t45 = load i64, ptr %l29, !tbaa !24
  store i64 %t45, ptr %l27, !tbaa !24
  br label %bb17
bb17:
  %t46 = load i64, ptr %l2, !tbaa !24
  %t47 = load i64, ptr %l27, !tbaa !24
  %t49 = srem i64 %t47, %t46
  store i64 %t49, ptr %l5, !tbaa !24
  %t51 = load i64, ptr %l5, !tbaa !24
  %t53 = icmp slt i64 %t51, 0
  br i1 %t53, label %bb18, label %bb19
bb18:
  %t55 = load i64, ptr %l5, !tbaa !24
  %t56 = load i64, ptr %l2, !tbaa !24
  %t59 = add i64 %t55, %t56
  store i64 %t59, ptr %l34, !tbaa !24
  br label %bb20
bb19:
  %t61 = load i64, ptr %l5, !tbaa !24
  store i64 %t61, ptr %l34, !tbaa !24
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s0)
  %t63 = load i64, ptr %l34, !tbaa !24
  store i64 %t63, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2epow2(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l8 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t2 = bitcast double 0x3ff0000000000000 to i64
  %t6 = shl i64 %a1, 52
  %t9 = add i64 %t2, %t6
  %t12 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2econstText(ptr %v0, ptr %v1, ptr %a0, i32 14, i64 %t9)
  store { i64, ptr } %t12, ptr %l8
  br label %bb1
bb1:
  %t13 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t13, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3aEmitter_2esignature(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l10 = alloca ptr
  %l13 = alloca i32
  %l14 = alloca i32
  %l20 = alloca i32
  %l24 = alloca i1
  %l31 = alloca i1
  %l32 = alloca ptr
  %l35 = alloca i32
  %l36 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l49 = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  store ptr %t6, ptr %l10, !tbaa !29
  %t7 = load ptr, ptr %l2, !tbaa !29
  %t8 = load i32, ptr %l1, !tbaa !23
  %t11 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t7, i32 %t8)
  store i32 %t11, ptr %l13
  br label %bb1
bb1:
  %t12 = load ptr, ptr %l10, !tbaa !29
  %t13 = load i32, ptr %l13, !tbaa !23
  %t14 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t14, ptr %l14
  br label %bb2
bb2:
  %t15 = load i32, ptr %l14
  %t17 = trunc i64 21 to i32
  %t18 = icmp eq i32 %t15, %t17
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb3, label %bb4
bb3:
  br label %ret
bb4:
  br label %bb5
bb5:
  %t22 = load ptr, ptr %l2, !tbaa !29
  %t23 = load i32, ptr %l1, !tbaa !23
  %t26 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t22, i32 %t23)
  store i32 %t26, ptr %l20
  br label %bb6
bb6:
  %t27 = load i32, ptr %l20, !tbaa !23
  store i32 %t27, ptr %l3, !tbaa !23
  %t28 = load i32, ptr %l3, !tbaa !23
  %t29 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t32 = icmp ne i32 %t28, %t29
  br i1 %t32, label %bb7, label %bb8
bb7:
  %t34 = load i32, ptr %l3, !tbaa !23
  %t35 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t38 = icmp ne i32 %t34, %t35
  store i1 %t38, ptr %l24, !tbaa !21
  br label %bb9
bb8:
  store i1 false, ptr %l24, !tbaa !21
  br label %bb9
bb9:
  %t40 = load i1, ptr %l24, !tbaa !21
  br i1 %t40, label %bb10, label %bb11
bb10:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/emit:Emitter", ptr %t41, i32 0, i32 0
  %t44 = load ptr, ptr %t43, !tbaa !29
  %t45 = load i32, ptr %l3, !tbaa !23
  %t48 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLayout(ptr %v0, ptr %t44, i32 %t45)
  store i1 %t48, ptr %l31
  br label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb13
bb13:
  %t49 = load ptr, ptr %l2, !tbaa !29
  store ptr %t49, ptr %l32, !tbaa !29
  %t50 = load ptr, ptr %l2, !tbaa !29
  %t51 = load i32, ptr %l1, !tbaa !23
  %t54 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t50, i32 %t51)
  store i32 %t54, ptr %l35
  br label %bb14
bb14:
  %t55 = load ptr, ptr %l32, !tbaa !29
  %t56 = load i32, ptr %l35, !tbaa !23
  %t57 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t55, i32 %t56)
  store { i64, ptr } %t57, ptr %l36
  br label %bb15
bb15:
  %t58 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t58, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t59 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t61 = extractvalue { i64, ptr } %t59, 0
  store i64 %t61, ptr %l6, !tbaa !24
  br label %bb16
bb16:
  %t63 = load i64, ptr %l5, !tbaa !24
  %t64 = load i64, ptr %l6, !tbaa !24
  %t67 = icmp slt i64 %t63, %t64
  %t69 = xor i1 %t67, true
  br i1 %t69, label %bb17, label %bb18
bb17:
  br label %bb22
bb18:
  br label %bb19
bb19:
  %t71 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t71, ptr %l43, !tbaa !27
  %t72 = load i64, ptr %l5, !tbaa !24
  %t74 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t75 = load ptr, ptr %t74, !tbaa !27
  %t76 = getelementptr i32, ptr %t75, i64 %t72
  %t77 = load i32, ptr %t76, !tbaa !33
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/emit:Emitter", ptr %t79, i32 0, i32 0
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t86 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLayout(ptr %v0, ptr %t82, i32 %t77)
  store i1 %t86, ptr %l49
  br label %bb20
bb20:
  br label %bb21
bb21:
  %t87 = load i64, ptr %l5, !tbaa !24
  %t89 = add i64 %t87, 1
  store i64 %t89, ptr %l5, !tbaa !24
  br label %bb16
bb22:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2estub(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l9 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t5 = extractvalue { i64, ptr } %a1, 1
  %t6 = extractvalue { i64, ptr } %a1, 0
  %t7 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d323, i32 0, i32 1) }, 1
  %t8 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d323, i32 0, i32 1) }, 0
  %t9 = add i64 %t6, %t8
  %t11 = extractvalue { i64, ptr } %a2, 1
  %t12 = extractvalue { i64, ptr } %a2, 0
  %t13 = add i64 %t9, %t12
  %t14 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d324, i32 0, i32 1) }, 1
  %t15 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d324, i32 0, i32 1) }, 0
  %t16 = add i64 %t13, %t15
  %t17 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t16)
  call void @olang_textcopy(ptr %t17, ptr %t5, i64 %t6)
  %t18 = getelementptr i8, ptr %t17, i64 %t6
  call void @olang_textcopy(ptr %t18, ptr %t7, i64 %t8)
  %t19 = getelementptr i8, ptr %t18, i64 %t8
  call void @olang_textcopy(ptr %t19, ptr %t11, i64 %t12)
  %t20 = getelementptr i8, ptr %t19, i64 %t12
  call void @olang_textcopy(ptr %t20, ptr %t14, i64 %t15)
  %t21 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t17, 1
  %t24 = extractvalue { i64, ptr } %t22, 0
  %t25 = extractvalue { i64, ptr } %t22, 1
  %t26 = mul i64 %t24, 1
  %t27 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t26)
  call void @llvm.memcpy.p0.p0.i64(ptr %t27, ptr %t25, i64 %t26, i1 false)
  %t28 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t27, 1
  %t32 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecstr(ptr %v0, ptr %s0, ptr %s0, ptr %a0, { i64, ptr } %t29)
  store { i64, ptr } %t32, ptr %l9
  br label %bb1
bb1:
  %t33 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t35 = extractvalue { i64, ptr } { i64 45, ptr getelementptr inbounds (<{ i64, [45 x i8] }>, ptr @.d325, i32 0, i32 1) }, 1
  %t36 = extractvalue { i64, ptr } { i64 45, ptr getelementptr inbounds (<{ i64, [45 x i8] }>, ptr @.d325, i32 0, i32 1) }, 0
  %t38 = extractvalue { i64, ptr } %t33, 1
  %t39 = extractvalue { i64, ptr } %t33, 0
  %t40 = add i64 %t36, %t39
  %t41 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d326, i32 0, i32 1) }, 1
  %t42 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d326, i32 0, i32 1) }, 0
  %t43 = add i64 %t40, %t42
  %t44 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t43)
  call void @olang_textcopy(ptr %t44, ptr %t35, i64 %t36)
  %t45 = getelementptr i8, ptr %t44, i64 %t36
  call void @olang_textcopy(ptr %t45, ptr %t38, i64 %t39)
  %t46 = getelementptr i8, ptr %t45, i64 %t39
  call void @olang_textcopy(ptr %t46, ptr %t41, i64 %t42)
  %t47 = insertvalue { i64, ptr } undef, i64 %t43, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t44, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t48, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2esym(ptr %v0, ptr %v1, ptr %a0, { i64, [2 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [2 x i64] }
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i1
  %l12 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l24 = alloca i32
  %l27 = alloca i32
  %l30 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l57 = alloca ptr
  %l62 = alloca { i64, ptr }
  %l68 = alloca { i64, ptr }
  %l71 = alloca { i64, ptr }
  %l74 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.builder
  %s3room = alloca [64 x i8], align 8
  %s4 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, [2 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load { i64, [2 x i64] }, ptr %l1
  %t8 = extractvalue { i64, [2 x i64] } %t6, 0
  %t9 = icmp eq i64 %t8, 0
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t12 = getelementptr { i32 }, ptr %t11, i32 0, i32 0
  %t13 = load i32, ptr %t12
  store i32 %t13, ptr %l3, !tbaa !23
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load i32, ptr %l3, !tbaa !23
  %t18 = sext i32 %t16 to i64
  %t21 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ebodySym(ptr %v0, ptr %v1, ptr %t15, i64 %t18)
  store { i64, ptr } %t21, ptr %l19
  br label %bb4
bb4:
  %t22 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t22, ptr %l12, !tbaa !27
  br label %bb38
bb5:
  %t23 = load { i64, [2 x i64] }, ptr %l1
  %t25 = extractvalue { i64, [2 x i64] } %t23, 0
  %t26 = icmp eq i64 %t25, 2
  br i1 %t26, label %bb6, label %bb7
bb6:
  %t28 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t29 = getelementptr { i32, i32 }, ptr %t28, i32 0, i32 0
  %t30 = load i32, ptr %t29
  store i32 %t30, ptr %l4
  %t32 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t33 = getelementptr { i32, i32 }, ptr %t32, i32 0, i32 1
  %t34 = load i32, ptr %t33
  store i32 %t34, ptr %l5, !tbaa !23
  br label %bb8
bb7:
  br label %bb17
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t36 = load i32, ptr %l4
  store i32 %t36, ptr %l24
  %t37 = load ptr, ptr %l2, !tbaa !29
  %t38 = load i32, ptr %l5, !tbaa !23
  %t41 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eUnnamed(ptr %v0, ptr %t37, i32 %t38)
  store i32 %t41, ptr %l27
  br label %bb9
bb9:
  %t42 = load i32, ptr %l5, !tbaa !23
  %t43 = load i32, ptr %l27, !tbaa !23
  %t45 = icmp eq i32 %t43, %t42
  br i1 %t45, label %bb10, label %bb11
bb10:
  %t47 = load ptr, ptr %l2, !tbaa !29
  %t48 = load i32, ptr %l5, !tbaa !23
  %t51 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s2, ptr %t47, i32 %t48)
  store { i64, ptr } %t51, ptr %l33
  br label %bb12
bb11:
  %t52 = load ptr, ptr %l2, !tbaa !29
  %t53 = load i32, ptr %l5, !tbaa !23
  %t56 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanonNamed(ptr %v0, ptr %s2, ptr %t52, i32 %t53)
  store { i64, ptr } %t56, ptr %l36
  br label %bb13
bb12:
  %t57 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t57, ptr %l30, !tbaa !27
  br label %bb14
bb13:
  %t58 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t58, ptr %l30, !tbaa !27
  br label %bb14
bb14:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s3
  store ptr %s3room, ptr %s3
  %t59 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d327, i32 0, i32 1) }, 1
  %t60 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d327, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t59, i64 %t60)
  call void @olang_2eHelperKind_2eRender_2ecompiler_2fmir_3aHelperKind(ptr %s3, ptr %l24, i64 0)
  br label %bb15
bb15:
  %t62 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d328, i32 0, i32 1) }, 1
  %t63 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d328, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t62, i64 %t63)
  %t64 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t64, 1
  %t66 = extractvalue { i64, ptr } %t64, 0
  call void @__olang_sb_put(ptr %s3, ptr %t65, i64 %t66)
  %t67 = load ptr, ptr %s3
  %t68 = getelementptr %olang.builder, ptr %s3, i32 0, i32 1
  %t69 = load i64, ptr %t68
  %t70 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t69)
  call void @olang_textcopy(ptr %t70, ptr %t67, i64 %t69)
  %t71 = insertvalue { i64, ptr } undef, i64 %t69, 0
  %t72 = insertvalue { i64, ptr } %t71, ptr %t70, 1
  store { i64, ptr } %t72, ptr %l38, !tbaa !27
  %t73 = getelementptr %olang.builder, ptr %s3, i32 0, i32 3
  %t74 = load ptr, ptr %t73
  %t75 = icmp ne ptr %t74, null
  br i1 %t75, label %sbgrew.76, label %sbdone.77
sbgrew.76:
  call void @__olang_sb_done(ptr %s3)
  br label %sbdone.77
sbdone.77:
  %t78 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t79 = extractvalue { i64, ptr } %t78, 0
  %t80 = extractvalue { i64, ptr } %t78, 1
  %t81 = mul i64 %t79, 1
  %t82 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t81)
  call void @llvm.memcpy.p0.p0.i64(ptr %t82, ptr %t80, i64 %t81, i1 false)
  %t83 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t84 = insertvalue { i64, ptr } %t83, ptr %t82, 1
  %t86 = call { i64, ptr } @compiler_2ftypes_2eSymbol(ptr %v1, ptr %v1, { i64, ptr } %t84)
  store { i64, ptr } %t86, ptr %l40
  br label %bb16
bb16:
  %t87 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t87, ptr %l12, !tbaa !27
  call void @__olang_scope_close(ptr %s2)
  br label %bb38
bb17:
  %t88 = load { i64, [2 x i64] }, ptr %l1
  %t90 = extractvalue { i64, [2 x i64] } %t88, 0
  %t91 = icmp eq i64 %t90, 1
  br i1 %t91, label %bb18, label %bb19
bb18:
  %t93 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t94 = getelementptr { i32 }, ptr %t93, i32 0, i32 0
  %t95 = load i32, ptr %t94
  store i32 %t95, ptr %l6, !tbaa !23
  br label %bb20
bb19:
  br label %bb22
bb20:
  store %olang.scope zeroinitializer, ptr %s4
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t98 = load i32, ptr %l6, !tbaa !23
  %t100 = sext i32 %t98 to i64
  %t103 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ebodySym(ptr %v0, ptr %s4, ptr %t97, i64 %t100)
  store { i64, ptr } %t103, ptr %l47
  br label %bb21
bb21:
  %t104 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t105 = extractvalue { i64, ptr } %t104, 1
  %t106 = extractvalue { i64, ptr } %t104, 0
  %t107 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d329, i32 0, i32 1) }, 1
  %t108 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d329, i32 0, i32 1) }, 0
  %t109 = add i64 %t106, %t108
  %t110 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t109)
  call void @olang_textcopy(ptr %t110, ptr %t105, i64 %t106)
  %t111 = getelementptr i8, ptr %t110, i64 %t106
  call void @olang_textcopy(ptr %t111, ptr %t107, i64 %t108)
  %t112 = insertvalue { i64, ptr } undef, i64 %t109, 0
  %t113 = insertvalue { i64, ptr } %t112, ptr %t110, 1
  store { i64, ptr } %t113, ptr %l12, !tbaa !27
  call void @__olang_scope_close(ptr %s4)
  br label %bb38
bb22:
  %t115 = load { i64, [2 x i64] }, ptr %l1
  %t117 = extractvalue { i64, [2 x i64] } %t115, 0
  %t118 = icmp eq i64 %t117, 3
  br i1 %t118, label %bb23, label %bb24
bb23:
  %t120 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t121 = getelementptr { i64 }, ptr %t120, i32 0, i32 0
  %t122 = load i64, ptr %t121
  store i64 %t122, ptr %l7, !tbaa !24
  br label %bb25
bb24:
  br label %bb28
bb25:
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t126 = getelementptr %"compiler/emit:Emitter", ptr %t124, i32 0, i32 0
  %t127 = load ptr, ptr %t126, !tbaa !29
  %t129 = getelementptr %"compiler/generic:Program", ptr %t127, i32 0, i32 0
  %t130 = load ptr, ptr %t129, !tbaa !29
  %t132 = getelementptr %"compiler/load:Loader", ptr %t130, i32 0, i32 5
  %t133 = load i64, ptr %l7, !tbaa !24
  %t136 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t132, i64 %t133)
  store ptr %t136, ptr %l57
  br label %bb26
bb26:
  %t137 = load ptr, ptr %l57, !tbaa !29
  %t139 = getelementptr %"compiler/load:Module", ptr %t137, i32 0, i32 2
  %t140 = load { i64, ptr }, ptr %t139, !tbaa !27
  %t141 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d330, i32 0, i32 1) }, 1
  %t142 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d330, i32 0, i32 1) }, 0
  %t144 = extractvalue { i64, ptr } %t140, 1
  %t145 = extractvalue { i64, ptr } %t140, 0
  %t146 = add i64 %t142, %t145
  %t147 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t146)
  call void @olang_textcopy(ptr %t147, ptr %t141, i64 %t142)
  %t148 = getelementptr i8, ptr %t147, i64 %t142
  call void @olang_textcopy(ptr %t148, ptr %t144, i64 %t145)
  %t149 = insertvalue { i64, ptr } undef, i64 %t146, 0
  %t150 = insertvalue { i64, ptr } %t149, ptr %t147, 1
  %t152 = extractvalue { i64, ptr } %t150, 0
  %t153 = extractvalue { i64, ptr } %t150, 1
  %t154 = mul i64 %t152, 1
  %t155 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t154)
  call void @llvm.memcpy.p0.p0.i64(ptr %t155, ptr %t153, i64 %t154, i1 false)
  %t156 = insertvalue { i64, ptr } undef, i64 %t152, 0
  %t157 = insertvalue { i64, ptr } %t156, ptr %t155, 1
  %t159 = call { i64, ptr } @compiler_2ftypes_2eSymbol(ptr %v1, ptr %v1, { i64, ptr } %t157)
  store { i64, ptr } %t159, ptr %l62
  br label %bb27
bb27:
  %t160 = load { i64, ptr }, ptr %l62, !tbaa !27
  store { i64, ptr } %t160, ptr %l12, !tbaa !27
  br label %bb38
bb28:
  %t161 = load { i64, [2 x i64] }, ptr %l1
  %t163 = extractvalue { i64, [2 x i64] } %t161, 0
  %t164 = icmp eq i64 %t163, 4
  br i1 %t164, label %bb29, label %bb30
bb29:
  %t166 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t167 = getelementptr { i64, i1 }, ptr %t166, i32 0, i32 0
  %t168 = load i64, ptr %t167
  store i64 %t168, ptr %l8, !tbaa !24
  %t170 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t171 = getelementptr { i64, i1 }, ptr %t170, i32 0, i32 1
  %t172 = load i1, ptr %t171
  store i1 %t172, ptr %l9, !tbaa !21
  br label %bb31
bb30:
  br label %bb37
bb31:
  store %olang.scope zeroinitializer, ptr %s8
  %t174 = load i1, ptr %l9, !tbaa !21
  br i1 %t174, label %bb32, label %bb33
bb32:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d331, i32 0, i32 1) }, ptr %l68, !tbaa !27
  br label %bb34
bb33:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d332, i32 0, i32 1) }, ptr %l68, !tbaa !27
  br label %bb34
bb34:
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t177 = load i64, ptr %l8, !tbaa !24
  %t180 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etableName(ptr %v0, ptr %s8, ptr %t176, i64 %t177)
  store { i64, ptr } %t180, ptr %l71
  br label %bb35
bb35:
  %t181 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d333, i32 0, i32 1) }, 1
  %t182 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d333, i32 0, i32 1) }, 0
  %t183 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t184 = extractvalue { i64, ptr } %t183, 1
  %t185 = extractvalue { i64, ptr } %t183, 0
  %t186 = add i64 %t182, %t185
  %t187 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d334, i32 0, i32 1) }, 1
  %t188 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d334, i32 0, i32 1) }, 0
  %t189 = add i64 %t186, %t188
  %t190 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t191 = extractvalue { i64, ptr } %t190, 1
  %t192 = extractvalue { i64, ptr } %t190, 0
  %t193 = add i64 %t189, %t192
  %t194 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t193)
  call void @olang_textcopy(ptr %t194, ptr %t181, i64 %t182)
  %t195 = getelementptr i8, ptr %t194, i64 %t182
  call void @olang_textcopy(ptr %t195, ptr %t184, i64 %t185)
  %t196 = getelementptr i8, ptr %t195, i64 %t185
  call void @olang_textcopy(ptr %t196, ptr %t187, i64 %t188)
  %t197 = getelementptr i8, ptr %t196, i64 %t188
  call void @olang_textcopy(ptr %t197, ptr %t191, i64 %t192)
  %t198 = insertvalue { i64, ptr } undef, i64 %t193, 0
  %t199 = insertvalue { i64, ptr } %t198, ptr %t194, 1
  %t201 = extractvalue { i64, ptr } %t199, 0
  %t202 = extractvalue { i64, ptr } %t199, 1
  %t203 = mul i64 %t201, 1
  %t204 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t203)
  call void @llvm.memcpy.p0.p0.i64(ptr %t204, ptr %t202, i64 %t203, i1 false)
  %t205 = insertvalue { i64, ptr } undef, i64 %t201, 0
  %t206 = insertvalue { i64, ptr } %t205, ptr %t204, 1
  %t208 = call { i64, ptr } @compiler_2ftypes_2eSymbol(ptr %v1, ptr %v1, { i64, ptr } %t206)
  store { i64, ptr } %t208, ptr %l74
  br label %bb36
bb36:
  %t209 = load { i64, ptr }, ptr %l74, !tbaa !27
  store { i64, ptr } %t209, ptr %l12, !tbaa !27
  call void @__olang_scope_close(ptr %s8)
  br label %bb38
bb37:
  call void @__olang_check_failed(ptr @olang_loc_325a0aca37049b03_8faf0435ed6a0227)
  unreachable
bb38:
  %t210 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t210, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etableName(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"compiler/generic:AnyTable"
  %l7 = alloca %"compiler/generic:AnyTable"
  %l10 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 43
  %t10 = call %"compiler/generic:AnyTable" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aAnyTable_3e_2eAt__He9601a52fe5cfa5abe1b41d520aed001(ptr %v0, ptr %v0, ptr %t6, i64 %a1)
  store %"compiler/generic:AnyTable" %t10, ptr %l7
  br label %bb1
bb1:
  %t11 = load %"compiler/generic:AnyTable", ptr %l7
  store %"compiler/generic:AnyTable" %t11, ptr %l2
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/generic:AnyTable", ptr %l2, i32 0, i32 0
  %t14 = load i32, ptr %t13, !tbaa !23
  %t17 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecanonOf(ptr %v0, ptr %s0, ptr %t12, i32 %t14)
  store { i64, ptr } %t17, ptr %l10
  br label %bb2
bb2:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/generic:AnyTable", ptr %l2, i32 0, i32 1
  %t20 = load i32, ptr %t19, !tbaa !23
  %t23 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecanonOf(ptr %v0, ptr %s0, ptr %t18, i32 %t20)
  store { i64, ptr } %t23, ptr %l13
  br label %bb3
bb3:
  %t24 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t24, 1
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t27 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d335, i32 0, i32 1) }, 1
  %t28 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d335, i32 0, i32 1) }, 0
  %t29 = add i64 %t26, %t28
  %t30 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t31 = extractvalue { i64, ptr } %t30, 1
  %t32 = extractvalue { i64, ptr } %t30, 0
  %t33 = add i64 %t29, %t32
  %t34 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t33)
  call void @olang_textcopy(ptr %t34, ptr %t25, i64 %t26)
  %t35 = getelementptr i8, ptr %t34, i64 %t26
  call void @olang_textcopy(ptr %t35, ptr %t27, i64 %t28)
  %t36 = getelementptr i8, ptr %t35, i64 %t28
  call void @olang_textcopy(ptr %t36, ptr %t31, i64 %t32)
  %t37 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t38 = insertvalue { i64, ptr } %t37, ptr %t34, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t38, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3aEmitter_2etextCopy(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca i1
  %l5 = alloca %"std/prelude/text:StringBuilder"
  %l22 = alloca ptr
  %l23 = alloca i64
  %l25 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ehas(ptr %v0, ptr %s0, ptr %t1, { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d336, i32 0, i32 1) })
  store i1 %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load i1, ptr %l3, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  %t5 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s0, ptr %s0, ptr %t5, { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d337, i32 0, i32 1) }, { i64, ptr } { i64 46, ptr getelementptr inbounds (<{ i64, [46 x i8] }>, ptr @.d338, i32 0, i32 1) })
  br label %bb5
bb5:
  %t7 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t7, ptr %l5
  br label %bb6
bb6:
  %t8 = load %"std/prelude/text:StringBuilder", ptr %l5
  store %"std/prelude/text:StringBuilder" %t8, ptr %l1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l1, { i64, ptr } { i64 94, ptr getelementptr inbounds (<{ i64, [94 x i8] }>, ptr @.d339, i32 0, i32 1) })
  br label %bb7
bb7:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l1, { i64, ptr } { i64 66, ptr getelementptr inbounds (<{ i64, [66 x i8] }>, ptr @.d340, i32 0, i32 1) })
  br label %bb8
bb8:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l1, { i64, ptr } { i64 86, ptr getelementptr inbounds (<{ i64, [86 x i8] }>, ptr @.d341, i32 0, i32 1) })
  br label %bb9
bb9:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l1, { i64, ptr } { i64 67, ptr getelementptr inbounds (<{ i64, [67 x i8] }>, ptr @.d342, i32 0, i32 1) })
  br label %bb10
bb10:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l1, { i64, ptr } { i64 103, ptr getelementptr inbounds (<{ i64, [103 x i8] }>, ptr @.d343, i32 0, i32 1) })
  br label %bb11
bb11:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l1, { i64, ptr } { i64 112, ptr getelementptr inbounds (<{ i64, [112 x i8] }>, ptr @.d344, i32 0, i32 1) })
  br label %bb12
bb12:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l1, { i64, ptr } { i64 46, ptr getelementptr inbounds (<{ i64, [46 x i8] }>, ptr @.d345, i32 0, i32 1) })
  br label %bb13
bb13:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l1, { i64, ptr } { i64 67, ptr getelementptr inbounds (<{ i64, [67 x i8] }>, ptr @.d346, i32 0, i32 1) })
  br label %bb14
bb14:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l1, { i64, ptr } { i64 103, ptr getelementptr inbounds (<{ i64, [103 x i8] }>, ptr @.d347, i32 0, i32 1) })
  br label %bb15
bb15:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l1, { i64, ptr } { i64 112, ptr getelementptr inbounds (<{ i64, [112 x i8] }>, ptr @.d348, i32 0, i32 1) })
  br label %bb16
bb16:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l1, { i64, ptr } { i64 46, ptr getelementptr inbounds (<{ i64, [46 x i8] }>, ptr @.d349, i32 0, i32 1) })
  br label %bb17
bb17:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l1, { i64, ptr } { i64 70, ptr getelementptr inbounds (<{ i64, [70 x i8] }>, ptr @.d350, i32 0, i32 1) })
  br label %bb18
bb18:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l1, { i64, ptr } { i64 113, ptr getelementptr inbounds (<{ i64, [113 x i8] }>, ptr @.d351, i32 0, i32 1) })
  br label %bb19
bb19:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l1, { i64, ptr } { i64 115, ptr getelementptr inbounds (<{ i64, [115 x i8] }>, ptr @.d352, i32 0, i32 1) })
  br label %bb20
bb20:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l1, { i64, ptr } { i64 107, ptr getelementptr inbounds (<{ i64, [107 x i8] }>, ptr @.d353, i32 0, i32 1) })
  br label %bb21
bb21:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l1, { i64, ptr } { i64 60, ptr getelementptr inbounds (<{ i64, [60 x i8] }>, ptr @.d354, i32 0, i32 1) })
  br label %bb22
bb22:
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l22, !tbaa !29
  %t26 = load i64, ptr @G_2ecompiler_2femit_2eHomeShared, !tbaa !24
  store i64 %t26, ptr %l23, !tbaa !24
  %t28 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l1)
  store { i64, ptr } %t28, ptr %l25
  br label %bb23
bb23:
  %t29 = load ptr, ptr %l22, !tbaa !29
  %t30 = load i64, ptr %l23, !tbaa !24
  %t31 = load { i64, ptr }, ptr %l25, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eitem(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %t29, { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d355, i32 0, i32 1) }, i64 %t30, { i64, ptr } %t31, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d8, i32 0, i32 1) })
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3aEmitter_2ewalkStub(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, [2 x i64] } %a1, i32 %a2, { i64, ptr } %a3, i64 %a4, i1 %a5, { i64, ptr } %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [2 x i64] }
  %l2 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i1
  %l7 = alloca { i64, ptr }
  %l10 = alloca i1
  %l14 = alloca ptr
  %l15 = alloca { i64, [2 x i64] }
  %l16 = alloca i32
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i1
  %l20 = alloca ptr
  %l21 = alloca { i64, [2 x i64] }
  %l22 = alloca i32
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i1
  %l28 = alloca i64
  %l29 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, [2 x i64] } %a1, ptr %l1
  store i32 %a2, ptr %l2
  store i64 %a4, ptr %l4
  store i1 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load { i64, [2 x i64] }, ptr %l1
  %t5 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eisGenFn(ptr %v0, ptr %t1, { i64, [2 x i64] } %t2)
  store i1 %t5, ptr %l10
  br label %bb1
bb1:
  %t6 = load i1, ptr %l10, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  %t11 = extractvalue { i64, ptr } %a3, 1
  %t12 = extractvalue { i64, ptr } %a3, 0
  %t13 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d356, i32 0, i32 1) }, 1
  %t14 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d356, i32 0, i32 1) }, 0
  %t15 = add i64 %t12, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t11, i64 %t12)
  %t17 = getelementptr i8, ptr %t16, i64 %t12
  call void @olang_textcopy(ptr %t17, ptr %t13, i64 %t14)
  %t18 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t16, 1
  store { i64, ptr } %t19, ptr %l7, !tbaa !27
  %t21 = load ptr, ptr %l0, !tbaa !29
  store ptr %t21, ptr %l14, !tbaa !29
  %t22 = load { i64, [2 x i64] }, ptr %l1
  store { i64, [2 x i64] } %t22, ptr %l15
  %t23 = load i32, ptr %l2, !tbaa !23
  store i32 %t23, ptr %l16, !tbaa !23
  %t24 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t24, ptr %l17, !tbaa !27
  %t25 = load i64, ptr %l4, !tbaa !24
  store i64 %t25, ptr %l18, !tbaa !24
  %t26 = load i1, ptr %l5, !tbaa !21
  store i1 %t26, ptr %l19, !tbaa !21
  %t27 = load ptr, ptr %l0, !tbaa !29
  store ptr %t27, ptr %l20, !tbaa !29
  %t28 = load { i64, [2 x i64] }, ptr %l1
  store { i64, [2 x i64] } %t28, ptr %l21
  %t29 = load i32, ptr %l2, !tbaa !23
  store i32 %t29, ptr %l22, !tbaa !23
  %t30 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t30, ptr %l23, !tbaa !27
  %t31 = load i64, ptr %l4, !tbaa !24
  store i64 %t31, ptr %l24, !tbaa !24
  %t32 = load i1, ptr %l5, !tbaa !21
  store i1 %t32, ptr %l25, !tbaa !21
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load { i64, [2 x i64] }, ptr %l1
  %t37 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ehomeOf(ptr %v0, ptr %t33, { i64, [2 x i64] } %t34)
  store i64 %t37, ptr %l28
  br label %bb5
bb5:
  %t38 = load i64, ptr %l28, !tbaa !24
  %t39 = call { i64, ptr } @compiler_2femit_2elinkFor(ptr %s0, i64 %t38)
  store { i64, ptr } %t39, ptr %l29
  br label %bb6
bb6:
  %t40 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t40, 0
  %t42 = extractvalue { i64, ptr } %t40, 1
  %t43 = mul i64 %t41, 1
  %t44 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t43)
  call void @llvm.memcpy.p0.p0.i64(ptr %t44, ptr %t42, i64 %t43, i1 false)
  %t45 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t46 = insertvalue { i64, ptr } %t45, ptr %t44, 1
  %t47 = load ptr, ptr %l20, !tbaa !29
  %t48 = load { i64, [2 x i64] }, ptr %l21
  %t49 = load i32, ptr %l22, !tbaa !23
  %t50 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t51 = load i64, ptr %l24, !tbaa !24
  %t52 = load i1, ptr %l25, !tbaa !21
  %t54 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eheader(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %t47, { i64, [2 x i64] } %t48, i32 %t49, { i64, ptr } %t50, i64 %t51, i1 %t52, { i64, ptr } %t46)
  store { i64, ptr } %t54, ptr %l31
  br label %bb7
bb7:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t61 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2estub(ptr %v0, ptr %v2, ptr %s0, ptr %s0, ptr %t55, { i64, ptr } %a6, { i64, ptr } %t57)
  store { i64, ptr } %t61, ptr %l35
  br label %bb8
bb8:
  %t62 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t63 = extractvalue { i64, ptr } %t62, 1
  %t64 = extractvalue { i64, ptr } %t62, 0
  %t65 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t66 = extractvalue { i64, ptr } %t65, 1
  %t67 = extractvalue { i64, ptr } %t65, 0
  %t68 = add i64 %t64, %t67
  %t69 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t68)
  call void @olang_textcopy(ptr %t69, ptr %t63, i64 %t64)
  %t70 = getelementptr i8, ptr %t69, i64 %t64
  call void @olang_textcopy(ptr %t70, ptr %t66, i64 %t67)
  %t71 = insertvalue { i64, ptr } undef, i64 %t68, 0
  %t72 = insertvalue { i64, ptr } %t71, ptr %t69, 1
  %t74 = extractvalue { i64, ptr } %t72, 0
  %t75 = extractvalue { i64, ptr } %t72, 1
  %t76 = mul i64 %t74, 1
  %t77 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t76)
  call void @llvm.memcpy.p0.p0.i64(ptr %t77, ptr %t75, i64 %t76, i1 false)
  %t78 = insertvalue { i64, ptr } undef, i64 %t74, 0
  %t79 = insertvalue { i64, ptr } %t78, ptr %t77, 1
  %t80 = load ptr, ptr %l14, !tbaa !29
  %t81 = load { i64, [2 x i64] }, ptr %l15
  %t82 = load i32, ptr %l16, !tbaa !23
  %t83 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t84 = load i64, ptr %l18, !tbaa !24
  %t85 = load i1, ptr %l19, !tbaa !21
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2efnItem(ptr %v0, ptr %s0, ptr %s0, ptr %t80, { i64, [2 x i64] } %t81, i32 %t82, { i64, ptr } %t83, i64 %t84, i1 %t85, { i64, ptr } %t79)
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3aEmitter_2ewantType(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l20 = alloca { i64, ptr }
  %l22 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l24 = alloca i64
  %l28 = alloca i64
  %l31 = alloca i64
  %l51 = alloca i64
  %l53 = alloca i64
  %l55 = alloca ptr
  %l56 = alloca { i64, ptr }
  %l60 = alloca i64
  %l64 = alloca i64
  %l65 = alloca i64
  %l70 = alloca i64
  %l71 = alloca i32
  %l74 = alloca i1
  %l77 = alloca i1
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l3, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v2, ptr %t1, i64 %t2, i1 true)
  br label %bb1
bb1:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t5, i64 %t6)
  br label %bb2
bb2:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/emit:Emitter", ptr %t9, i32 0, i32 42
  %t12 = load i64, ptr %l1, !tbaa !24
  %t15 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t11, i64 %t12)
  store { i64, ptr } %t15, ptr %l20
  br label %bb3
bb3:
  %t16 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t16, ptr %l4, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2femit_2erefsIn(ptr %v0, ptr %s0, { i64, ptr } %t17)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t19, ptr %l22
  br label %bb4
bb4:
  %t20 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l22
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t20, ptr %l5
  store i64 0, ptr %l6, !tbaa !24
  %t22 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l5)
  store i64 %t22, ptr %l24
  br label %bb5
bb5:
  %t23 = load i64, ptr %l24, !tbaa !24
  store i64 %t23, ptr %l7, !tbaa !24
  store i64 3, ptr %l8, !tbaa !24
  %t24 = load i64, ptr %l7, !tbaa !24
  %t25 = load i64, ptr %l6, !tbaa !24
  %t28 = icmp sgt i64 %t24, %t25
  br i1 %t28, label %bb6, label %bb7
bb6:
  %t30 = load i64, ptr %l8, !tbaa !24
  %t32 = icmp sgt i64 %t30, 0
  br i1 %t32, label %bb8, label %bb9
bb7:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb11
bb8:
  %t34 = load i64, ptr %l7, !tbaa !24
  %t35 = load i64, ptr %l6, !tbaa !24
  %t38 = sub i64 %t34, %t35
  %t39 = load i64, ptr %l8, !tbaa !24
  %t42 = add i64 %t38, %t39
  %t44 = sub i64 %t42, 1
  %t45 = load i64, ptr %l8, !tbaa !24
  %t48 = sdiv i64 %t44, %t45
  store i64 %t48, ptr %l31, !tbaa !24
  br label %bb10
bb9:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb10
bb10:
  %t50 = load i64, ptr %l31, !tbaa !24
  store i64 %t50, ptr %l28, !tbaa !24
  br label %bb11
bb11:
  %t51 = load i64, ptr %l28, !tbaa !24
  store i64 %t51, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb12
bb12:
  %t52 = load i64, ptr %l10, !tbaa !24
  %t53 = load i64, ptr %l9, !tbaa !24
  %t56 = icmp slt i64 %t52, %t53
  %t58 = xor i1 %t56, true
  br i1 %t58, label %bb13, label %bb14
bb13:
  br label %bb41
bb14:
  br label %bb15
bb15:
  %t60 = load i64, ptr %l6, !tbaa !24
  %t61 = load i64, ptr %l10, !tbaa !24
  %t62 = load i64, ptr %l8, !tbaa !24
  %t65 = mul i64 %t61, %t62
  %t68 = add i64 %t60, %t65
  store i64 %t68, ptr %l11, !tbaa !24
  %t70 = load i64, ptr %l11, !tbaa !24
  %t73 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l5, i64 %t70)
  store i64 %t73, ptr %l51
  br label %bb16
bb16:
  %t74 = load i64, ptr %l51, !tbaa !24
  %t75 = icmp ne i64 %t74, 1
  br i1 %t75, label %bb17, label %bb18
bb17:
  br label %bb40
bb18:
  br label %bb19
bb19:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/emit:Emitter", ptr %t77, i32 0, i32 43
  store ptr %t79, ptr %l55, !tbaa !29
  %t80 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t80, ptr %l56, !tbaa !27
  %t81 = load i64, ptr %l11, !tbaa !24
  %t83 = add i64 %t81, 1
  %t86 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l5, i64 %t83)
  store i64 %t86, ptr %l60
  br label %bb20
bb20:
  %t87 = load i64, ptr %l11, !tbaa !24
  %t89 = add i64 %t87, 2
  %t92 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l5, i64 %t89)
  store i64 %t92, ptr %l64
  br label %bb21
bb21:
  %t93 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t94 = extractvalue { i64, ptr } %t93, 0
  store i64 %t94, ptr %l65, !tbaa !24
  %t95 = load i64, ptr %l60, !tbaa !24
  %t96 = icmp sge i64 %t95, 0
  br i1 %t96, label %bb22, label %bb23
bb22:
  %t98 = load i64, ptr %l60, !tbaa !24
  %t99 = load i64, ptr %l64, !tbaa !24
  %t100 = icmp sle i64 %t98, %t99
  br i1 %t100, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_6f064da57090b2af_17093dce158f11fb)
  unreachable
bb24:
  %t102 = load i64, ptr %l64, !tbaa !24
  %t103 = load i64, ptr %l65, !tbaa !24
  %t104 = icmp sle i64 %t102, %t103
  br i1 %t104, label %bb26, label %bb27
bb25:
  call void @__olang_check_failed(ptr @olang_loc_6f064da57090b2af_17093dce158f11fb)
  unreachable
bb26:
  %t106 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !27
  %t108 = load i64, ptr %l60, !tbaa !24
  %t109 = load i64, ptr %l64, !tbaa !24
  %t110 = getelementptr i8, ptr %t107, i64 %t108
  %t111 = sub i64 %t109, %t108
  %t112 = insertvalue { i64, ptr } undef, i64 %t111, 0
  %t113 = insertvalue { i64, ptr } %t112, ptr %t110, 1
  %t114 = load ptr, ptr %l55, !tbaa !29
  %t116 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9162e3b7f03fcbf954b681204d5f6cca(ptr %v0, ptr %v0, ptr %t114, { i64, ptr } %t113)
  %t117 = extractvalue { i32, i64 } %t116, 1
  %t118 = extractvalue { i32, i64 } %t116, 0
  store i32 %t118, ptr %l71
  %t119 = icmp ne i32 %t118, 0
  br i1 %t119, label %bb29, label %ok.120
ok.120:
  store i64 %t117, ptr %l70
  br label %bb28
bb27:
  call void @__olang_check_failed(ptr @olang_loc_6f064da57090b2af_17093dce158f11fb)
  unreachable
bb28:
  %t121 = load i64, ptr %l70, !tbaa !24
  store i64 %t121, ptr %l53, !tbaa !24
  br label %bb31
bb29:
  br label %bb30
bb30:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l53, !tbaa !24
  br label %bb31
bb31:
  %t122 = load i64, ptr %l53, !tbaa !24
  store i64 %t122, ptr %l12, !tbaa !24
  %t123 = load i64, ptr %l12, !tbaa !24
  %t125 = icmp sge i64 %t123, 0
  br i1 %t125, label %bb32, label %bb33
bb32:
  %t127 = load ptr, ptr %l3, !tbaa !29
  %t128 = load i64, ptr %l12, !tbaa !24
  %t131 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v2, ptr %t127, i64 %t128)
  store i1 %t131, ptr %l77
  br label %bb34
bb33:
  store i1 false, ptr %l74, !tbaa !21
  br label %bb35
bb34:
  %t132 = load i1, ptr %l77, !tbaa !21
  %t133 = xor i1 %t132, true
  store i1 %t133, ptr %l74, !tbaa !21
  br label %bb35
bb35:
  %t135 = load i1, ptr %l74, !tbaa !21
  br i1 %t135, label %bb36, label %bb37
bb36:
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t137 = load i64, ptr %l12, !tbaa !24
  %t138 = load ptr, ptr %l2, !tbaa !29
  %t139 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2ewantType(ptr %v0, ptr %v1, ptr %v2, ptr %t136, i64 %t137, ptr %t138, ptr %t139)
  br label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb39
bb39:
  br label %bb40
bb40:
  %t144 = load i64, ptr %l10, !tbaa !24
  %t146 = add i64 %t144, 1
  store i64 %t146, ptr %l10, !tbaa !24
  br label %bb12
bb41:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ewrapper(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca %"std/prelude/text:StringBuilder"
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i32
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l33 = alloca { i64, ptr }
  %l35 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i32
  %l40 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i32
  %l46 = alloca i1
  %l50 = alloca { i64, ptr }
  %l51 = alloca { i64, ptr }
  %l52 = alloca i64
  %l53 = alloca { i64, ptr }
  %l54 = alloca { i64, ptr }
  %l55 = alloca i64
  %l56 = alloca i64
  %l61 = alloca { i64, ptr }
  %l65 = alloca i64
  %l66 = alloca i64
  %l67 = alloca i64
  %l72 = alloca { i64, ptr }
  %l73 = alloca i64
  %l76 = alloca i64
  %l77 = alloca i64
  %l82 = alloca %"std/prelude/text:StringBuilder"
  %l83 = alloca ptr
  %l84 = alloca { i64, ptr }
  %l88 = alloca { i64, ptr }
  %l93 = alloca i1
  %l94 = alloca ptr
  %l98 = alloca { i64, ptr }
  %l102 = alloca ptr
  %l103 = alloca { i64, ptr }
  %l107 = alloca { i64, ptr }
  %l113 = alloca { i64, ptr }
  %l114 = alloca { i64, ptr }
  %l115 = alloca i64
  %l116 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 16
  %t4 = load i64, ptr %l2, !tbaa !24
  %t7 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  store { i64, ptr } %t7, ptr %l16
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t8, ptr %l3, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t11 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %s0, { i64, ptr } %t9, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d357, i32 0, i32 1) })
  %t12 = extractvalue { i32, i64 } %t11, 1
  %t13 = extractvalue { i32, i64 } %t11, 0
  store i32 %t13, ptr %l20
  %t14 = icmp ne i32 %t13, 0
  br i1 %t14, label %bb3, label %ok.15
ok.15:
  store i64 %t12, ptr %l19
  br label %bb2
bb2:
  %t16 = load i64, ptr %l19, !tbaa !24
  store i64 %t16, ptr %l17, !tbaa !24
  br label %bb5
bb3:
  br label %bb4
bb4:
  call void @__olang_ert_req_clear()
  %t17 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t17, 0
  store i64 %t19, ptr %l17, !tbaa !24
  br label %bb5
bb5:
  %t21 = load i64, ptr %l17, !tbaa !24
  %t22 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t22, ptr %l23, !tbaa !27
  store i64 %t21, ptr %l24, !tbaa !24
  %t24 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t24, 0
  store i64 %t25, ptr %l25, !tbaa !24
  %t26 = icmp sge i64 0, 0
  br i1 %t26, label %bb6, label %bb7
bb6:
  %t28 = load i64, ptr %l24, !tbaa !24
  %t29 = icmp sle i64 0, %t28
  br i1 %t29, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_f5feee0c0f7dd320_8e2d9d91f1e1268c)
  unreachable
bb8:
  %t31 = load i64, ptr %l24, !tbaa !24
  %t32 = load i64, ptr %l25, !tbaa !24
  %t33 = icmp sle i64 %t31, %t32
  br i1 %t33, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_f5feee0c0f7dd320_8e2d9d91f1e1268c)
  unreachable
bb10:
  %t35 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !27
  %t37 = load i64, ptr %l24, !tbaa !24
  %t38 = getelementptr i8, ptr %t36, i64 0
  %t39 = sub i64 %t37, 0
  %t40 = insertvalue { i64, ptr } undef, i64 %t39, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t38, 1
  store { i64, ptr } %t41, ptr %l5, !tbaa !27
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/emit:Emitter", ptr %t43, i32 0, i32 15
  %t46 = load i64, ptr %l2, !tbaa !24
  %t49 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %s0, ptr %t45, i64 %t46)
  store { i64, ptr } %t49, ptr %l33
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_f5feee0c0f7dd320_8e2d9d91f1e1268c)
  unreachable
bb12:
  %t50 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d358, i32 0, i32 1) }, 1
  %t51 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d358, i32 0, i32 1) }, 0
  %t52 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t53 = extractvalue { i64, ptr } %t52, 1
  %t54 = extractvalue { i64, ptr } %t52, 0
  %t55 = add i64 %t51, %t54
  %t56 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d359, i32 0, i32 1) }, 1
  %t57 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d359, i32 0, i32 1) }, 0
  %t58 = add i64 %t55, %t57
  %t59 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t58)
  call void @olang_textcopy(ptr %t59, ptr %t50, i64 %t51)
  %t60 = getelementptr i8, ptr %t59, i64 %t51
  call void @olang_textcopy(ptr %t60, ptr %t53, i64 %t54)
  %t61 = getelementptr i8, ptr %t60, i64 %t54
  call void @olang_textcopy(ptr %t61, ptr %t56, i64 %t57)
  %t62 = insertvalue { i64, ptr } undef, i64 %t58, 0
  %t63 = insertvalue { i64, ptr } %t62, ptr %t59, 1
  store { i64, ptr } %t63, ptr %l6, !tbaa !27
  %t65 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t66 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t69 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %s0, { i64, ptr } %t65, { i64, ptr } %t66)
  %t70 = extractvalue { i32, i64 } %t69, 1
  %t71 = extractvalue { i32, i64 } %t69, 0
  store i32 %t71, ptr %l39
  %t72 = icmp ne i32 %t71, 0
  br i1 %t72, label %bb14, label %ok.73
ok.73:
  store i64 %t70, ptr %l38
  br label %bb13
bb13:
  %t74 = load i64, ptr %l38, !tbaa !24
  store i64 %t74, ptr %l35, !tbaa !24
  br label %bb16
bb14:
  br label %bb15
bb15:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l35, !tbaa !24
  br label %bb16
bb16:
  %t75 = load i64, ptr %l35, !tbaa !24
  store i64 %t75, ptr %l7, !tbaa !24
  %t76 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t78 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %v0, ptr %s0, { i64, ptr } %t76, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d360, i32 0, i32 1) })
  %t79 = extractvalue { i32, i64 } %t78, 1
  %t80 = extractvalue { i32, i64 } %t78, 0
  store i32 %t80, ptr %l43
  %t81 = icmp ne i32 %t80, 0
  br i1 %t81, label %bb18, label %ok.82
ok.82:
  store i64 %t79, ptr %l42
  br label %bb17
bb17:
  %t83 = load i64, ptr %l42, !tbaa !24
  store i64 %t83, ptr %l40, !tbaa !24
  br label %bb20
bb18:
  br label %bb19
bb19:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l40, !tbaa !24
  br label %bb20
bb20:
  %t84 = load i64, ptr %l40, !tbaa !24
  store i64 %t84, ptr %l8, !tbaa !24
  %t85 = load i64, ptr %l7, !tbaa !24
  %t87 = icmp slt i64 %t85, 0
  br i1 %t87, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l46, !tbaa !21
  br label %bb23
bb22:
  %t89 = load i64, ptr %l8, !tbaa !24
  %t90 = load i64, ptr %l7, !tbaa !24
  %t93 = icmp slt i64 %t89, %t90
  store i1 %t93, ptr %l46, !tbaa !21
  br label %bb23
bb23:
  %t95 = load i1, ptr %l46, !tbaa !21
  br i1 %t95, label %bb24, label %bb25
bb24:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d361, i32 0, i32 1) }, ptr %l50, !tbaa !27
  %t96 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t96, ptr %l51, !tbaa !27
  %t97 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t98 = extractvalue { i64, ptr } %t97, 0
  store i64 %t98, ptr %l52, !tbaa !24
  %t99 = load i64, ptr %l52, !tbaa !24
  %t100 = mul i64 %t99, 1
  %t101 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t100)
  %t102 = insertvalue { i64, ptr } undef, i64 %t99, 0
  %t103 = insertvalue { i64, ptr } %t102, ptr %t101, 1
  store { i64, ptr } %t103, ptr %l53, !tbaa !27
  %t104 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !27
  %t106 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !27
  %t108 = load i64, ptr %l52, !tbaa !24
  %t109 = mul i64 %t108, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t105, ptr %t107, i64 %t109, i1 false)
  %t110 = load { i64, ptr }, ptr %l53, !tbaa !27
  store { i64, ptr } %t110, ptr %l51, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t111 = load { i64, ptr }, ptr %l51, !tbaa !27
  store { i64, ptr } %t111, ptr %rv
  br label %ret
bb25:
  br label %bb26
bb26:
  %t112 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t112, ptr %l54, !tbaa !27
  %t113 = load i64, ptr %l7, !tbaa !24
  store i64 %t113, ptr %l55, !tbaa !24
  %t114 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t115 = extractvalue { i64, ptr } %t114, 0
  store i64 %t115, ptr %l56, !tbaa !24
  %t116 = icmp sge i64 0, 0
  br i1 %t116, label %bb27, label %bb28
bb27:
  %t118 = load i64, ptr %l55, !tbaa !24
  %t119 = icmp sle i64 0, %t118
  br i1 %t119, label %bb29, label %bb30
bb28:
  call void @__olang_check_failed(ptr @olang_loc_fb18e47b3c77ad7d_7c94e7cf0a0fcab9)
  unreachable
bb29:
  %t121 = load i64, ptr %l55, !tbaa !24
  %t122 = load i64, ptr %l56, !tbaa !24
  %t123 = icmp sle i64 %t121, %t122
  br i1 %t123, label %bb31, label %bb32
bb30:
  call void @__olang_check_failed(ptr @olang_loc_fb18e47b3c77ad7d_7c94e7cf0a0fcab9)
  unreachable
bb31:
  %t125 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t126 = load ptr, ptr %t125, !tbaa !27
  %t127 = load i64, ptr %l55, !tbaa !24
  %t128 = getelementptr i8, ptr %t126, i64 0
  %t129 = sub i64 %t127, 0
  %t130 = insertvalue { i64, ptr } undef, i64 %t129, 0
  %t131 = insertvalue { i64, ptr } %t130, ptr %t128, 1
  store { i64, ptr } %t131, ptr %l9, !tbaa !27
  %t133 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t133, ptr %l61, !tbaa !27
  %t134 = load i64, ptr %l7, !tbaa !24
  %t135 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t137 = extractvalue { i64, ptr } %t135, 0
  %t140 = add i64 %t134, %t137
  store i64 %t140, ptr %l65, !tbaa !24
  %t141 = load i64, ptr %l8, !tbaa !24
  store i64 %t141, ptr %l66, !tbaa !24
  %t142 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t143 = extractvalue { i64, ptr } %t142, 0
  store i64 %t143, ptr %l67, !tbaa !24
  %t144 = load i64, ptr %l65, !tbaa !24
  %t145 = icmp sge i64 %t144, 0
  br i1 %t145, label %bb33, label %bb34
bb32:
  call void @__olang_check_failed(ptr @olang_loc_fb18e47b3c77ad7d_7c94e7cf0a0fcab9)
  unreachable
bb33:
  %t147 = load i64, ptr %l65, !tbaa !24
  %t148 = load i64, ptr %l66, !tbaa !24
  %t149 = icmp sle i64 %t147, %t148
  br i1 %t149, label %bb35, label %bb36
bb34:
  call void @__olang_check_failed(ptr @olang_loc_7f6652826e00de1e_418f3021b2f06a1a)
  unreachable
bb35:
  %t151 = load i64, ptr %l66, !tbaa !24
  %t152 = load i64, ptr %l67, !tbaa !24
  %t153 = icmp sle i64 %t151, %t152
  br i1 %t153, label %bb37, label %bb38
bb36:
  call void @__olang_check_failed(ptr @olang_loc_7f6652826e00de1e_418f3021b2f06a1a)
  unreachable
bb37:
  %t155 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t156 = load ptr, ptr %t155, !tbaa !27
  %t157 = load i64, ptr %l65, !tbaa !24
  %t158 = load i64, ptr %l66, !tbaa !24
  %t159 = getelementptr i8, ptr %t156, i64 %t157
  %t160 = sub i64 %t158, %t157
  %t161 = insertvalue { i64, ptr } undef, i64 %t160, 0
  %t162 = insertvalue { i64, ptr } %t161, ptr %t159, 1
  store { i64, ptr } %t162, ptr %l10, !tbaa !27
  %t164 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t164, ptr %l72, !tbaa !27
  %t165 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d362, i32 0, i32 1) }, 0
  store i64 %t165, ptr %l73, !tbaa !24
  %t166 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t168 = extractvalue { i64, ptr } %t166, 0
  %t170 = sub i64 %t168, 1
  store i64 %t170, ptr %l76, !tbaa !24
  %t171 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t172 = extractvalue { i64, ptr } %t171, 0
  store i64 %t172, ptr %l77, !tbaa !24
  %t173 = load i64, ptr %l73, !tbaa !24
  %t174 = icmp sge i64 %t173, 0
  br i1 %t174, label %bb39, label %bb40
bb38:
  call void @__olang_check_failed(ptr @olang_loc_7f6652826e00de1e_418f3021b2f06a1a)
  unreachable
bb39:
  %t176 = load i64, ptr %l73, !tbaa !24
  %t177 = load i64, ptr %l76, !tbaa !24
  %t178 = icmp sle i64 %t176, %t177
  br i1 %t178, label %bb41, label %bb42
bb40:
  call void @__olang_check_failed(ptr @olang_loc_679011f6b0c6ee1b_3818b84a191b3b77)
  unreachable
bb41:
  %t180 = load i64, ptr %l76, !tbaa !24
  %t181 = load i64, ptr %l77, !tbaa !24
  %t182 = icmp sle i64 %t180, %t181
  br i1 %t182, label %bb43, label %bb44
bb42:
  call void @__olang_check_failed(ptr @olang_loc_679011f6b0c6ee1b_3818b84a191b3b77)
  unreachable
bb43:
  %t184 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t185 = load ptr, ptr %t184, !tbaa !27
  %t186 = load i64, ptr %l73, !tbaa !24
  %t187 = load i64, ptr %l76, !tbaa !24
  %t188 = getelementptr i8, ptr %t185, i64 %t186
  %t189 = sub i64 %t187, %t186
  %t190 = insertvalue { i64, ptr } undef, i64 %t189, 0
  %t191 = insertvalue { i64, ptr } %t190, ptr %t188, 1
  store { i64, ptr } %t191, ptr %l11, !tbaa !27
  %t193 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t193, ptr %l82
  br label %bb45
bb44:
  call void @__olang_check_failed(ptr @olang_loc_679011f6b0c6ee1b_3818b84a191b3b77)
  unreachable
bb45:
  %t194 = load %"std/prelude/text:StringBuilder", ptr %l82
  store %"std/prelude/text:StringBuilder" %t194, ptr %l12
  store ptr %l12, ptr %l83, !tbaa !29
  %t195 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t195, ptr %l84, !tbaa !27
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t198 = getelementptr %"compiler/emit:Emitter", ptr %t196, i32 0, i32 15
  %t202 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %s0, ptr %t198, i64 %a1)
  store { i64, ptr } %t202, ptr %l88
  br label %bb46
bb46:
  %t203 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t204 = load { i64, ptr }, ptr %l84, !tbaa !27
  %t205 = extractvalue { i64, ptr } %t204, 1
  %t206 = extractvalue { i64, ptr } %t204, 0
  %t207 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d363, i32 0, i32 1) }, 1
  %t208 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d363, i32 0, i32 1) }, 0
  %t209 = add i64 %t206, %t208
  %t210 = load { i64, ptr }, ptr %l88, !tbaa !27
  %t211 = extractvalue { i64, ptr } %t210, 1
  %t212 = extractvalue { i64, ptr } %t210, 0
  %t213 = add i64 %t209, %t212
  %t214 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d364, i32 0, i32 1) }, 1
  %t215 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d364, i32 0, i32 1) }, 0
  %t216 = add i64 %t213, %t215
  %t218 = extractvalue { i64, ptr } %t203, 1
  %t219 = extractvalue { i64, ptr } %t203, 0
  %t220 = add i64 %t216, %t219
  %t221 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d365, i32 0, i32 1) }, 1
  %t222 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d365, i32 0, i32 1) }, 0
  %t223 = add i64 %t220, %t222
  %t224 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t223)
  call void @olang_textcopy(ptr %t224, ptr %t205, i64 %t206)
  %t225 = getelementptr i8, ptr %t224, i64 %t206
  call void @olang_textcopy(ptr %t225, ptr %t207, i64 %t208)
  %t226 = getelementptr i8, ptr %t225, i64 %t208
  call void @olang_textcopy(ptr %t226, ptr %t211, i64 %t212)
  %t227 = getelementptr i8, ptr %t226, i64 %t212
  call void @olang_textcopy(ptr %t227, ptr %t214, i64 %t215)
  %t228 = getelementptr i8, ptr %t227, i64 %t215
  call void @olang_textcopy(ptr %t228, ptr %t218, i64 %t219)
  %t229 = getelementptr i8, ptr %t228, i64 %t219
  call void @olang_textcopy(ptr %t229, ptr %t221, i64 %t222)
  %t230 = insertvalue { i64, ptr } undef, i64 %t223, 0
  %t231 = insertvalue { i64, ptr } %t230, ptr %t224, 1
  %t233 = extractvalue { i64, ptr } %t231, 0
  %t234 = extractvalue { i64, ptr } %t231, 1
  %t235 = mul i64 %t233, 1
  %t236 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t235)
  call void @llvm.memcpy.p0.p0.i64(ptr %t236, ptr %t234, i64 %t235, i1 false)
  %t237 = insertvalue { i64, ptr } undef, i64 %t233, 0
  %t238 = insertvalue { i64, ptr } %t237, ptr %t236, 1
  %t239 = load ptr, ptr %l83, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t239, { i64, ptr } %t238)
  br label %bb47
bb47:
  %t241 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t243 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t241, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d366, i32 0, i32 1) })
  store i1 %t243, ptr %l93
  br label %bb48
bb48:
  %t244 = load i1, ptr %l93, !tbaa !21
  br i1 %t244, label %bb49, label %bb50
bb49:
  store %olang.scope zeroinitializer, ptr %s4
  store ptr %l12, ptr %l94, !tbaa !29
  %t245 = load ptr, ptr %l0, !tbaa !29
  %t247 = getelementptr %"compiler/emit:Emitter", ptr %t245, i32 0, i32 15
  %t248 = load i64, ptr %l2, !tbaa !24
  %t251 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %s4, ptr %t247, i64 %t248)
  store { i64, ptr } %t251, ptr %l98
  br label %bb51
bb50:
  store %olang.scope zeroinitializer, ptr %s6
  store ptr %l12, ptr %l102, !tbaa !29
  %t252 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t252, ptr %l103, !tbaa !27
  %t253 = load ptr, ptr %l0, !tbaa !29
  %t255 = getelementptr %"compiler/emit:Emitter", ptr %t253, i32 0, i32 15
  %t256 = load i64, ptr %l2, !tbaa !24
  %t259 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %s6, ptr %t255, i64 %t256)
  store { i64, ptr } %t259, ptr %l107
  br label %bb53
bb51:
  %t260 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t261 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d367, i32 0, i32 1) }, 1
  %t262 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d367, i32 0, i32 1) }, 0
  %t263 = load { i64, ptr }, ptr %l98, !tbaa !27
  %t264 = extractvalue { i64, ptr } %t263, 1
  %t265 = extractvalue { i64, ptr } %t263, 0
  %t266 = add i64 %t262, %t265
  %t267 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d368, i32 0, i32 1) }, 1
  %t268 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d368, i32 0, i32 1) }, 0
  %t269 = add i64 %t266, %t268
  %t271 = extractvalue { i64, ptr } %t260, 1
  %t272 = extractvalue { i64, ptr } %t260, 0
  %t273 = add i64 %t269, %t272
  %t274 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d369, i32 0, i32 1) }, 1
  %t275 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d369, i32 0, i32 1) }, 0
  %t276 = add i64 %t273, %t275
  %t277 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t276)
  call void @olang_textcopy(ptr %t277, ptr %t261, i64 %t262)
  %t278 = getelementptr i8, ptr %t277, i64 %t262
  call void @olang_textcopy(ptr %t278, ptr %t264, i64 %t265)
  %t279 = getelementptr i8, ptr %t278, i64 %t265
  call void @olang_textcopy(ptr %t279, ptr %t267, i64 %t268)
  %t280 = getelementptr i8, ptr %t279, i64 %t268
  call void @olang_textcopy(ptr %t280, ptr %t271, i64 %t272)
  %t281 = getelementptr i8, ptr %t280, i64 %t272
  call void @olang_textcopy(ptr %t281, ptr %t274, i64 %t275)
  %t282 = insertvalue { i64, ptr } undef, i64 %t276, 0
  %t283 = insertvalue { i64, ptr } %t282, ptr %t277, 1
  %t285 = extractvalue { i64, ptr } %t283, 0
  %t286 = extractvalue { i64, ptr } %t283, 1
  %t287 = mul i64 %t285, 1
  %t288 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t287)
  call void @llvm.memcpy.p0.p0.i64(ptr %t288, ptr %t286, i64 %t287, i1 false)
  %t289 = insertvalue { i64, ptr } undef, i64 %t285, 0
  %t290 = insertvalue { i64, ptr } %t289, ptr %t288, 1
  %t291 = load ptr, ptr %l94, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s4, ptr %t291, { i64, ptr } %t290)
  br label %bb52
bb52:
  call void @__olang_scope_close(ptr %s4)
  br label %bb55
bb53:
  %t293 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t294 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t295 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d370, i32 0, i32 1) }, 1
  %t296 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d370, i32 0, i32 1) }, 0
  %t297 = load { i64, ptr }, ptr %l103, !tbaa !27
  %t298 = extractvalue { i64, ptr } %t297, 1
  %t299 = extractvalue { i64, ptr } %t297, 0
  %t300 = add i64 %t296, %t299
  %t301 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d371, i32 0, i32 1) }, 1
  %t302 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d371, i32 0, i32 1) }, 0
  %t303 = add i64 %t300, %t302
  %t304 = load { i64, ptr }, ptr %l107, !tbaa !27
  %t305 = extractvalue { i64, ptr } %t304, 1
  %t306 = extractvalue { i64, ptr } %t304, 0
  %t307 = add i64 %t303, %t306
  %t308 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d372, i32 0, i32 1) }, 1
  %t309 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d372, i32 0, i32 1) }, 0
  %t310 = add i64 %t307, %t309
  %t312 = extractvalue { i64, ptr } %t293, 1
  %t313 = extractvalue { i64, ptr } %t293, 0
  %t314 = add i64 %t310, %t313
  %t315 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d373, i32 0, i32 1) }, 1
  %t316 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d373, i32 0, i32 1) }, 0
  %t317 = add i64 %t314, %t316
  %t319 = extractvalue { i64, ptr } %t294, 1
  %t320 = extractvalue { i64, ptr } %t294, 0
  %t321 = add i64 %t317, %t320
  %t322 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d374, i32 0, i32 1) }, 1
  %t323 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d374, i32 0, i32 1) }, 0
  %t324 = add i64 %t321, %t323
  %t325 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t324)
  call void @olang_textcopy(ptr %t325, ptr %t295, i64 %t296)
  %t326 = getelementptr i8, ptr %t325, i64 %t296
  call void @olang_textcopy(ptr %t326, ptr %t298, i64 %t299)
  %t327 = getelementptr i8, ptr %t326, i64 %t299
  call void @olang_textcopy(ptr %t327, ptr %t301, i64 %t302)
  %t328 = getelementptr i8, ptr %t327, i64 %t302
  call void @olang_textcopy(ptr %t328, ptr %t305, i64 %t306)
  %t329 = getelementptr i8, ptr %t328, i64 %t306
  call void @olang_textcopy(ptr %t329, ptr %t308, i64 %t309)
  %t330 = getelementptr i8, ptr %t329, i64 %t309
  call void @olang_textcopy(ptr %t330, ptr %t312, i64 %t313)
  %t331 = getelementptr i8, ptr %t330, i64 %t313
  call void @olang_textcopy(ptr %t331, ptr %t315, i64 %t316)
  %t332 = getelementptr i8, ptr %t331, i64 %t316
  call void @olang_textcopy(ptr %t332, ptr %t319, i64 %t320)
  %t333 = getelementptr i8, ptr %t332, i64 %t320
  call void @olang_textcopy(ptr %t333, ptr %t322, i64 %t323)
  %t334 = insertvalue { i64, ptr } undef, i64 %t324, 0
  %t335 = insertvalue { i64, ptr } %t334, ptr %t325, 1
  %t337 = extractvalue { i64, ptr } %t335, 0
  %t338 = extractvalue { i64, ptr } %t335, 1
  %t339 = mul i64 %t337, 1
  %t340 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t339)
  call void @llvm.memcpy.p0.p0.i64(ptr %t340, ptr %t338, i64 %t339, i1 false)
  %t341 = insertvalue { i64, ptr } undef, i64 %t337, 0
  %t342 = insertvalue { i64, ptr } %t341, ptr %t340, 1
  %t343 = load ptr, ptr %l102, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s6, ptr %t343, { i64, ptr } %t342)
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s6)
  br label %bb55
bb55:
  %t346 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l12)
  store { i64, ptr } %t346, ptr %l113
  br label %bb56
bb56:
  %t347 = load { i64, ptr }, ptr %l113, !tbaa !27
  store { i64, ptr } %t347, ptr %l114, !tbaa !27
  %t348 = load { i64, ptr }, ptr %l114, !tbaa !27
  %t349 = extractvalue { i64, ptr } %t348, 0
  store i64 %t349, ptr %l115, !tbaa !24
  %t350 = load i64, ptr %l115, !tbaa !24
  %t351 = mul i64 %t350, 1
  %t352 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t351)
  %t353 = insertvalue { i64, ptr } undef, i64 %t350, 0
  %t354 = insertvalue { i64, ptr } %t353, ptr %t352, 1
  store { i64, ptr } %t354, ptr %l116, !tbaa !27
  %t355 = getelementptr { i64, ptr }, ptr %l116, i32 0, i32 1
  %t356 = load ptr, ptr %t355, !tbaa !27
  %t357 = getelementptr { i64, ptr }, ptr %l114, i32 0, i32 1
  %t358 = load ptr, ptr %t357, !tbaa !27
  %t359 = load i64, ptr %l115, !tbaa !24
  %t360 = mul i64 %t359, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t356, ptr %t358, i64 %t360, i1 false)
  %t361 = load { i64, ptr }, ptr %l116, !tbaa !27
  store { i64, ptr } %t361, ptr %l114, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t362 = load { i64, ptr }, ptr %l114, !tbaa !27
  store { i64, ptr } %t362, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { { i64, ptr }, i32 } @compiler_2femit_2ecompiler_2femit_3afnEm_2eaddr(ptr %v0, ptr %v1, ptr %a0, %"compiler/mir:Place" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/mir:Place"
  %l2 = alloca ptr
  %lp3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i1
  %l6 = alloca i1
  %l7 = alloca { i64, [2 x i64] }
  %l8 = alloca i32
  %l9 = alloca i64
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca i32
  %l14 = alloca i32
  %l15 = alloca i32
  %l16 = alloca i32
  %l18 = alloca { i64, [1 x i64] }
  %l19 = alloca i32
  %l20 = alloca i64
  %l21 = alloca { i64, ptr }
  %l22 = alloca i32
  %l23 = alloca i32
  %l24 = alloca { i64, ptr }
  %l25 = alloca { { i64, ptr }, i32 }
  %l26 = alloca i64
  %l27 = alloca { { i64, ptr }, i32 }
  %l28 = alloca i32
  %l29 = alloca { i64, ptr }
  %l30 = alloca { i64, ptr }
  %l31 = alloca i64
  %l35 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l37 = alloca i64
  %l38 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l48 = alloca i64
  %l52 = alloca i32
  %l63 = alloca { i64, ptr }
  %l65 = alloca i64
  %l75 = alloca i32
  %l78 = alloca i32
  %l104 = alloca { i64, [1 x i64] }
  %l107 = alloca i32
  %l111 = alloca ptr
  %l114 = alloca i32
  %l115 = alloca { i64, ptr }
  %l116 = alloca ptr
  %l119 = alloca { i64, ptr }
  %l124 = alloca { i64, ptr }
  %l126 = alloca i64
  %l128 = alloca { i64, ptr }
  %l136 = alloca i32
  %l137 = alloca ptr
  %l138 = alloca ptr
  %l141 = alloca { i64, ptr }
  %l142 = alloca { i64, ptr }
  %l145 = alloca { i64, ptr }
  %l146 = alloca { i64, ptr }
  %l150 = alloca { i64, ptr }
  %l152 = alloca { i64, ptr }
  %l155 = alloca { i64, ptr }
  %l158 = alloca i1
  %l159 = alloca ptr
  %l160 = alloca { i64, ptr }
  %l161 = alloca i32
  %l162 = alloca { i64, ptr }
  %l167 = alloca { i64, ptr }
  %l169 = alloca { { i64, ptr }, i32 }
  %l170 = alloca { i64, ptr }
  %l172 = alloca i64
  %l174 = alloca i64
  %l175 = alloca { i64, ptr }
  %l182 = alloca i1
  %l183 = alloca ptr
  %l184 = alloca { i64, ptr }
  %l185 = alloca i32
  %l188 = alloca { i64, ptr }
  %l193 = alloca { i64, ptr }
  %l195 = alloca { { i64, ptr }, i32 }
  %l196 = alloca { i64, ptr }
  %l198 = alloca i64
  %l200 = alloca i64
  %l201 = alloca { i64, ptr }
  %l207 = alloca i32
  %l209 = alloca { i64, ptr }
  %l214 = alloca { i64, ptr }
  %l219 = alloca i1
  %l224 = alloca { i64, ptr }
  %l226 = alloca i64
  %l230 = alloca ptr
  %l233 = alloca { i64, ptr }
  %l237 = alloca { i64, ptr }
  %l239 = alloca i64
  %l242 = alloca ptr
  %l245 = alloca i32
  %l246 = alloca { i64, ptr }
  %l250 = alloca { i64, ptr }
  %l255 = alloca ptr
  %l257 = alloca { i64, ptr }
  %l262 = alloca { i64, ptr }
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %rv = alloca { { i64, ptr }, i32 }
  store ptr %a0, ptr %l0
  store %"compiler/mir:Place" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/emit:Emitter", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l2, !tbaa !29
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d375, i32 0, i32 1) }, ptr %l35, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t9, ptr %l36, !tbaa !27
  %t10 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t10, 0
  store i64 %t11, ptr %l37, !tbaa !24
  %t12 = load i64, ptr %l37, !tbaa !24
  %t13 = mul i64 %t12, 1
  %t14 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t13)
  %t15 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr %t14, 1
  store { i64, ptr } %t16, ptr %l38, !tbaa !27
  %t17 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !27
  %t19 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !27
  %t21 = load i64, ptr %l37, !tbaa !24
  %t22 = mul i64 %t21, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t18, ptr %t20, i64 %t22, i1 false)
  %t23 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t23, ptr %lp3
  %t24 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t25 = load ptr, ptr %lp3
  store { i64, ptr } %t24, ptr %t25, !tbaa !27
  %t26 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t26, ptr %l4, !tbaa !23
  store i1 false, ptr %l5, !tbaa !21
  store i1 false, ptr %l6, !tbaa !21
  %t28 = getelementptr %"compiler/mir:Place", ptr %l1, i32 0, i32 0
  %t29 = load { i64, [2 x i64] }, ptr %t28
  store { i64, [2 x i64] } %t29, ptr %l7
  %t31 = load { i64, [2 x i64] }, ptr %l7
  %t33 = extractvalue { i64, [2 x i64] } %t31, 0
  %t34 = icmp eq i64 %t33, 1
  br i1 %t34, label %bb1, label %bb2
bb1:
  %t36 = getelementptr { i64, [2 x i64] }, ptr %l7, i32 0, i32 1
  %t37 = getelementptr { i32 }, ptr %t36, i32 0, i32 0
  %t38 = load i32, ptr %t37
  store i32 %t38, ptr %l8, !tbaa !23
  br label %bb3
bb2:
  br label %bb9
bb3:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load i32, ptr %l8, !tbaa !23
  %t44 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elocalAt(ptr %v0, ptr %v1, ptr %t40, i32 %t41)
  store { i64, ptr } %t44, ptr %l46
  br label %bb4
bb4:
  %t45 = load ptr, ptr %lp3
  %t46 = load { i64, ptr }, ptr %t45, !tbaa !27
  %t47 = extractvalue { i64, ptr } %t46, 0
  %t48 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t48, 0
  store i64 %t49, ptr %l48, !tbaa !24
  %t51 = load i64, ptr %l48, !tbaa !24
  %t52 = icmp eq i64 %t47, %t51
  br i1 %t52, label %bb5, label %bb6
bb5:
  %t54 = load ptr, ptr %lp3
  %t55 = getelementptr { i64, ptr }, ptr %t54, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !27
  %t57 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !27
  %t59 = load i64, ptr %l48, !tbaa !24
  %t60 = mul i64 %t59, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t56, ptr %t58, i64 %t60, i1 false)
  br label %bb7
bb6:
  %t61 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t62 = load ptr, ptr %lp3
  store { i64, ptr } %t61, ptr %t62, !tbaa !27
  br label %bb7
bb7:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = load i32, ptr %l8, !tbaa !23
  %t67 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2elocalType(ptr %v0, ptr %t63, i32 %t64)
  store i32 %t67, ptr %l52
  br label %bb8
bb8:
  %t68 = load i32, ptr %l52, !tbaa !23
  store i32 %t68, ptr %l4, !tbaa !23
  br label %bb23
bb9:
  %t69 = load { i64, [2 x i64] }, ptr %l7
  %t71 = extractvalue { i64, [2 x i64] } %t69, 0
  %t72 = icmp eq i64 %t71, 2
  br i1 %t72, label %bb10, label %bb11
bb10:
  %t74 = getelementptr { i64, [2 x i64] }, ptr %l7, i32 0, i32 1
  %t75 = getelementptr { i64, i32, i32 }, ptr %t74, i32 0, i32 0
  %t76 = load i64, ptr %t75
  store i64 %t76, ptr %l9, !tbaa !24
  %t78 = getelementptr { i64, [2 x i64] }, ptr %l7, i32 0, i32 1
  %t79 = getelementptr { i64, i32, i32 }, ptr %t78, i32 0, i32 1
  %t80 = load i32, ptr %t79
  store i32 %t80, ptr %l10, !tbaa !23
  %t82 = getelementptr { i64, [2 x i64] }, ptr %l7, i32 0, i32 1
  %t83 = getelementptr { i64, i32, i32 }, ptr %t82, i32 0, i32 2
  %t84 = load i32, ptr %t83
  store i32 %t84, ptr %l11, !tbaa !23
  br label %bb12
bb11:
  br label %bb17
bb12:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/emit:fnEm", ptr %t86, i32 0, i32 0
  %t89 = load ptr, ptr %t88, !tbaa !29
  %t90 = load i64, ptr %l9, !tbaa !24
  %t91 = load i32, ptr %l10, !tbaa !23
  %t92 = load i32, ptr %l11, !tbaa !23
  %t97 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eglobal(ptr %v0, ptr %v1, ptr %t89, i64 %t90, i32 %t91, i32 %t92)
  store { i64, ptr } %t97, ptr %l63
  br label %bb13
bb13:
  %t98 = load ptr, ptr %lp3
  %t99 = load { i64, ptr }, ptr %t98, !tbaa !27
  %t100 = extractvalue { i64, ptr } %t99, 0
  %t101 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t102 = extractvalue { i64, ptr } %t101, 0
  store i64 %t102, ptr %l65, !tbaa !24
  %t104 = load i64, ptr %l65, !tbaa !24
  %t105 = icmp eq i64 %t100, %t104
  br i1 %t105, label %bb14, label %bb15
bb14:
  %t107 = load ptr, ptr %lp3
  %t108 = getelementptr { i64, ptr }, ptr %t107, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !27
  %t110 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !27
  %t112 = load i64, ptr %l65, !tbaa !24
  %t113 = mul i64 %t112, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t109, ptr %t111, i64 %t113, i1 false)
  br label %bb16
bb15:
  %t114 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t115 = load ptr, ptr %lp3
  store { i64, ptr } %t114, ptr %t115, !tbaa !27
  br label %bb16
bb16:
  %t116 = load i32, ptr %l11, !tbaa !23
  store i32 %t116, ptr %l4, !tbaa !23
  br label %bb23
bb17:
  %t118 = load { i64, [2 x i64] }, ptr %l7
  %t120 = extractvalue { i64, [2 x i64] } %t118, 0
  %t121 = icmp eq i64 %t120, 0
  br i1 %t121, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb22
bb20:
  store %olang.scope zeroinitializer, ptr %s3
  %t123 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2egap(ptr %v0, ptr %s3, ptr %t123, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d376, i32 0, i32 1) })
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s3)
  br label %bb23
bb22:
  call void @__olang_check_failed(ptr @olang_loc_a45e6d34f8d75be7_fb9ba052a05cfc3b)
  unreachable
bb23:
  store i32 0, ptr %l12, !tbaa !23
  %t125 = getelementptr %"compiler/mir:Place", ptr %l1, i32 0, i32 1
  %t126 = getelementptr %"compiler/mir:Range", ptr %t125, i32 0, i32 1
  %t127 = load i32, ptr %t126, !tbaa !23
  store i32 %t127, ptr %l13, !tbaa !23
  store i32 1, ptr %l14, !tbaa !23
  %t129 = load i32, ptr %l13, !tbaa !23
  %t130 = load i32, ptr %l12, !tbaa !23
  %t133 = icmp sgt i32 %t129, %t130
  br i1 %t133, label %bb24, label %bb25
bb24:
  %t135 = load i32, ptr %l14, !tbaa !23
  %t137 = icmp sgt i32 %t135, 0
  br i1 %t137, label %bb26, label %bb27
bb25:
  store i32 0, ptr %l75, !tbaa !23
  br label %bb29
bb26:
  %t139 = load i32, ptr %l13, !tbaa !23
  %t140 = load i32, ptr %l12, !tbaa !23
  %t143 = sub i32 %t139, %t140
  %t144 = load i32, ptr %l14, !tbaa !23
  %t147 = add i32 %t143, %t144
  %t149 = sub i32 %t147, 1
  %t150 = load i32, ptr %l14, !tbaa !23
  %t153 = sdiv i32 %t149, %t150
  store i32 %t153, ptr %l78, !tbaa !23
  br label %bb28
bb27:
  store i32 0, ptr %l78, !tbaa !23
  br label %bb28
bb28:
  %t155 = load i32, ptr %l78, !tbaa !23
  store i32 %t155, ptr %l75, !tbaa !23
  br label %bb29
bb29:
  %t156 = load i32, ptr %l75, !tbaa !23
  store i32 %t156, ptr %l15, !tbaa !23
  store i32 0, ptr %l16, !tbaa !23
  br label %bb30
bb30:
  %t157 = load i32, ptr %l16, !tbaa !23
  %t158 = load i32, ptr %l15, !tbaa !23
  %t161 = icmp slt i32 %t157, %t158
  %t163 = xor i1 %t161, true
  br i1 %t163, label %bb31, label %bb32
bb31:
  br label %bb118
bb32:
  br label %bb33
bb33:
  %t165 = load i32, ptr %l12, !tbaa !23
  %t166 = load i32, ptr %l16, !tbaa !23
  %t167 = load i32, ptr %l14, !tbaa !23
  %t170 = mul i32 %t166, %t167
  %t173 = add i32 %t165, %t170
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t177 = getelementptr %"compiler/emit:fnEm", ptr %t175, i32 0, i32 1
  %t178 = load ptr, ptr %t177, !tbaa !29
  %t180 = getelementptr %"compiler/mir:Fn", ptr %t178, i32 0, i32 10
  %t181 = getelementptr %"compiler/mir:Place", ptr %l1, i32 0, i32 1
  %t182 = getelementptr %"compiler/mir:Range", ptr %t181, i32 0, i32 0
  %t183 = load i32, ptr %t182, !tbaa !23
  %t185 = sext i32 %t183 to i64
  %t188 = sext i32 %t173 to i64
  %t191 = add i64 %t185, %t188
  %t194 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e_2eAt_3ccompiler_2fmir_3aProj_3e(ptr %v0, ptr %t180, i64 %t191)
  store { i64, [1 x i64] } %t194, ptr %l104
  br label %bb34
bb34:
  %t195 = load { i64, [1 x i64] }, ptr %l104
  store { i64, [1 x i64] } %t195, ptr %l18
  %t196 = load ptr, ptr %l2, !tbaa !29
  %t197 = load i32, ptr %l4, !tbaa !23
  %t200 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t196, i32 %t197)
  store i32 %t200, ptr %l107
  br label %bb35
bb35:
  %t201 = load i32, ptr %l107, !tbaa !23
  store i32 %t201, ptr %l19, !tbaa !23
  %t202 = load { i64, [1 x i64] }, ptr %l18
  %t204 = extractvalue { i64, [1 x i64] } %t202, 0
  %t205 = icmp eq i64 %t204, 0
  br i1 %t205, label %bb36, label %bb37
bb36:
  %t207 = getelementptr { i64, [1 x i64] }, ptr %l18, i32 0, i32 1
  %t208 = getelementptr { i64 }, ptr %t207, i32 0, i32 0
  %t209 = load i64, ptr %t208
  store i64 %t209, ptr %l20, !tbaa !24
  br label %bb38
bb37:
  br label %bb46
bb38:
  store %olang.scope zeroinitializer, ptr %s6
  %t211 = load ptr, ptr %l2, !tbaa !29
  store ptr %t211, ptr %l111, !tbaa !29
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t213 = load i32, ptr %l19, !tbaa !23
  %t216 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2efieldList(ptr %v0, ptr %t212, i32 %t213)
  store i32 %t216, ptr %l114
  br label %bb39
bb39:
  %t217 = load ptr, ptr %l111, !tbaa !29
  %t218 = load i32, ptr %l114, !tbaa !23
  %t219 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t217, i32 %t218)
  store { i64, ptr } %t219, ptr %l115
  br label %bb40
bb40:
  %t220 = load { i64, ptr }, ptr %l115, !tbaa !27
  store { i64, ptr } %t220, ptr %l21, !tbaa !27
  %t221 = load ptr, ptr %l0, !tbaa !29
  store ptr %t221, ptr %l116, !tbaa !29
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t223 = load i32, ptr %l19, !tbaa !23
  %t226 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s6, ptr %t222, i32 %t223)
  store { i64, ptr } %t226, ptr %l119
  br label %bb41
bb41:
  %t227 = load ptr, ptr %lp3
  %t228 = load { i64, ptr }, ptr %t227, !tbaa !27
  %t229 = load i64, ptr %l20, !tbaa !24
  %t230 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d377, i32 0, i32 1) }, 1
  %t231 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d377, i32 0, i32 1) }, 0
  %t232 = load { i64, ptr }, ptr %l119, !tbaa !27
  %t233 = extractvalue { i64, ptr } %t232, 1
  %t234 = extractvalue { i64, ptr } %t232, 0
  %t235 = add i64 %t231, %t234
  %t236 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d378, i32 0, i32 1) }, 1
  %t237 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d378, i32 0, i32 1) }, 0
  %t238 = add i64 %t235, %t237
  %t240 = extractvalue { i64, ptr } %t228, 1
  %t241 = extractvalue { i64, ptr } %t228, 0
  %t242 = add i64 %t238, %t241
  %t243 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d379, i32 0, i32 1) }, 1
  %t244 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d379, i32 0, i32 1) }, 0
  %t245 = add i64 %t242, %t244
  %t247 = call i64 @__olang_fmt_i64(ptr null, i64 %t229)
  %t248 = add i64 %t245, %t247
  %t249 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t248)
  call void @olang_textcopy(ptr %t249, ptr %t230, i64 %t231)
  %t250 = getelementptr i8, ptr %t249, i64 %t231
  call void @olang_textcopy(ptr %t250, ptr %t233, i64 %t234)
  %t251 = getelementptr i8, ptr %t250, i64 %t234
  call void @olang_textcopy(ptr %t251, ptr %t236, i64 %t237)
  %t252 = getelementptr i8, ptr %t251, i64 %t237
  call void @olang_textcopy(ptr %t252, ptr %t240, i64 %t241)
  %t253 = getelementptr i8, ptr %t252, i64 %t241
  call void @olang_textcopy(ptr %t253, ptr %t243, i64 %t244)
  %t254 = getelementptr i8, ptr %t253, i64 %t244
  %t255 = call i64 @__olang_fmt_i64(ptr %t254, i64 %t229)
  %t256 = insertvalue { i64, ptr } undef, i64 %t248, 0
  %t257 = insertvalue { i64, ptr } %t256, ptr %t249, 1
  %t259 = extractvalue { i64, ptr } %t257, 0
  %t260 = extractvalue { i64, ptr } %t257, 1
  %t261 = mul i64 %t259, 1
  %t262 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t261)
  call void @llvm.memcpy.p0.p0.i64(ptr %t262, ptr %t260, i64 %t261, i1 false)
  %t263 = insertvalue { i64, ptr } undef, i64 %t259, 0
  %t264 = insertvalue { i64, ptr } %t263, ptr %t262, 1
  %t265 = load ptr, ptr %l116, !tbaa !29
  %t267 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v1, ptr %t265, { i64, ptr } %t264)
  store { i64, ptr } %t267, ptr %l124
  br label %bb42
bb42:
  %t268 = load ptr, ptr %lp3
  %t269 = load { i64, ptr }, ptr %t268, !tbaa !27
  %t270 = extractvalue { i64, ptr } %t269, 0
  %t271 = load { i64, ptr }, ptr %l124, !tbaa !27
  %t272 = extractvalue { i64, ptr } %t271, 0
  store i64 %t272, ptr %l126, !tbaa !24
  %t274 = load i64, ptr %l126, !tbaa !24
  %t275 = icmp eq i64 %t270, %t274
  br i1 %t275, label %bb43, label %bb44
bb43:
  %t277 = load ptr, ptr %lp3
  %t278 = getelementptr { i64, ptr }, ptr %t277, i32 0, i32 1
  %t279 = load ptr, ptr %t278, !tbaa !27
  %t280 = getelementptr { i64, ptr }, ptr %l124, i32 0, i32 1
  %t281 = load ptr, ptr %t280, !tbaa !27
  %t282 = load i64, ptr %l126, !tbaa !24
  %t283 = mul i64 %t282, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t279, ptr %t281, i64 %t283, i1 false)
  br label %bb45
bb44:
  %t284 = load { i64, ptr }, ptr %l124, !tbaa !27
  %t285 = load ptr, ptr %lp3
  store { i64, ptr } %t284, ptr %t285, !tbaa !27
  br label %bb45
bb45:
  %t286 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t286, ptr %l128, !tbaa !27
  %t287 = load i64, ptr %l20, !tbaa !24
  %t289 = getelementptr { i64, ptr }, ptr %l128, i32 0, i32 1
  %t290 = load ptr, ptr %t289, !tbaa !27
  %t291 = getelementptr i32, ptr %t290, i64 %t287
  %t292 = load i32, ptr %t291, !tbaa !33
  store i32 %t292, ptr %l4, !tbaa !23
  store i1 false, ptr %l5, !tbaa !21
  call void @__olang_scope_close(ptr %s6)
  br label %bb116
bb46:
  %t294 = load { i64, [1 x i64] }, ptr %l18
  %t296 = extractvalue { i64, [1 x i64] } %t294, 0
  %t297 = icmp eq i64 %t296, 1
  br i1 %t297, label %bb47, label %bb48
bb47:
  %t299 = getelementptr { i64, [1 x i64] }, ptr %l18, i32 0, i32 1
  %t300 = getelementptr { i32 }, ptr %t299, i32 0, i32 0
  %t301 = load i32, ptr %t300
  store i32 %t301, ptr %l22, !tbaa !23
  br label %bb49
bb48:
  br label %bb65
bb49:
  store %olang.scope zeroinitializer, ptr %s8
  %t303 = load ptr, ptr %l0, !tbaa !29
  %t304 = load i32, ptr %l22, !tbaa !23
  %t307 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2elocalType(ptr %v0, ptr %t303, i32 %t304)
  store i32 %t307, ptr %l136
  br label %bb50
bb50:
  %t308 = load i32, ptr %l136, !tbaa !23
  store i32 %t308, ptr %l23, !tbaa !23
  %t309 = load ptr, ptr %l0, !tbaa !29
  store ptr %t309, ptr %l137, !tbaa !29
  %t310 = load ptr, ptr %l0, !tbaa !29
  store ptr %t310, ptr %l138, !tbaa !29
  %t311 = load ptr, ptr %l0, !tbaa !29
  %t312 = load i32, ptr %l23, !tbaa !23
  %t315 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s8, ptr %t311, i32 %t312)
  store { i64, ptr } %t315, ptr %l141
  br label %bb51
bb51:
  %t316 = load { i64, ptr }, ptr %l141, !tbaa !27
  %t317 = extractvalue { i64, ptr } %t316, 0
  %t318 = extractvalue { i64, ptr } %t316, 1
  %t319 = mul i64 %t317, 1
  %t320 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t319)
  call void @llvm.memcpy.p0.p0.i64(ptr %t320, ptr %t318, i64 %t319, i1 false)
  %t321 = insertvalue { i64, ptr } undef, i64 %t317, 0
  %t322 = insertvalue { i64, ptr } %t321, ptr %t320, 1
  store { i64, ptr } %t322, ptr %l142, !tbaa !27
  %t323 = load ptr, ptr %l0, !tbaa !29
  %t324 = load i32, ptr %l22, !tbaa !23
  %t327 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elocalAt(ptr %v0, ptr %s8, ptr %t323, i32 %t324)
  store { i64, ptr } %t327, ptr %l145
  br label %bb52
bb52:
  %t328 = load { i64, ptr }, ptr %l145, !tbaa !27
  %t329 = extractvalue { i64, ptr } %t328, 0
  %t330 = extractvalue { i64, ptr } %t328, 1
  %t331 = mul i64 %t329, 1
  %t332 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t331)
  call void @llvm.memcpy.p0.p0.i64(ptr %t332, ptr %t330, i64 %t331, i1 false)
  %t333 = insertvalue { i64, ptr } undef, i64 %t329, 0
  %t334 = insertvalue { i64, ptr } %t333, ptr %t332, 1
  store { i64, ptr } %t334, ptr %l146, !tbaa !27
  %t335 = load ptr, ptr %l0, !tbaa !29
  %t337 = getelementptr %"compiler/emit:fnEm", ptr %t335, i32 0, i32 0
  %t338 = load ptr, ptr %t337, !tbaa !29
  %t339 = load i32, ptr %l23, !tbaa !23
  %t342 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etbaa(ptr %v0, ptr %s8, ptr %t338, i32 %t339, i1 false)
  store { i64, ptr } %t342, ptr %l150
  br label %bb53
bb53:
  %t343 = load { i64, ptr }, ptr %l150, !tbaa !27
  %t344 = extractvalue { i64, ptr } %t343, 0
  %t345 = extractvalue { i64, ptr } %t343, 1
  %t346 = mul i64 %t344, 1
  %t347 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t346)
  call void @llvm.memcpy.p0.p0.i64(ptr %t347, ptr %t345, i64 %t346, i1 false)
  %t348 = insertvalue { i64, ptr } undef, i64 %t344, 0
  %t349 = insertvalue { i64, ptr } %t348, ptr %t347, 1
  %t350 = load ptr, ptr %l138, !tbaa !29
  %t351 = load { i64, ptr }, ptr %l142, !tbaa !27
  %t352 = load { i64, ptr }, ptr %l146, !tbaa !27
  %t354 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %s8, ptr %s8, ptr %s8, ptr %s8, ptr %t350, { i64, ptr } %t351, { i64, ptr } %t352, { i64, ptr } %t349)
  store { i64, ptr } %t354, ptr %l152
  br label %bb54
bb54:
  %t355 = load { i64, ptr }, ptr %l152, !tbaa !27
  %t356 = extractvalue { i64, ptr } %t355, 0
  %t357 = extractvalue { i64, ptr } %t355, 1
  %t358 = mul i64 %t356, 1
  %t359 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t358)
  call void @llvm.memcpy.p0.p0.i64(ptr %t359, ptr %t357, i64 %t358, i1 false)
  %t360 = insertvalue { i64, ptr } undef, i64 %t356, 0
  %t361 = insertvalue { i64, ptr } %t360, ptr %t359, 1
  %t362 = load i32, ptr %l23, !tbaa !23
  %t363 = load ptr, ptr %l137, !tbaa !29
  %t366 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eindex(ptr %v0, ptr %s8, ptr %s8, ptr %t363, { i64, ptr } %t361, i32 %t362)
  store { i64, ptr } %t366, ptr %l155
  br label %bb55
bb55:
  %t367 = load { i64, ptr }, ptr %l155, !tbaa !27
  store { i64, ptr } %t367, ptr %l24, !tbaa !27
  %t368 = load ptr, ptr %l0, !tbaa !29
  %t369 = load i32, ptr %l4, !tbaa !23
  %t372 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2erunTime(ptr %v0, ptr %t368, i32 %t369)
  store i1 %t372, ptr %l158
  br label %bb56
bb56:
  %t373 = load i1, ptr %l158, !tbaa !21
  br i1 %t373, label %bb57, label %bb58
bb57:
  store i1 false, ptr %l6, !tbaa !21
  br label %bb59
bb58:
  br label %bb59
bb59:
  %t374 = load ptr, ptr %l0, !tbaa !29
  store ptr %t374, ptr %l159, !tbaa !29
  %t375 = load ptr, ptr %lp3
  %t376 = load { i64, ptr }, ptr %t375, !tbaa !27
  store { i64, ptr } %t376, ptr %l160, !tbaa !27
  %t377 = load i32, ptr %l4, !tbaa !23
  store i32 %t377, ptr %l161, !tbaa !23
  %t378 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t378, ptr %l162, !tbaa !27
  %t379 = load ptr, ptr %l0, !tbaa !29
  %t381 = getelementptr %"compiler/emit:fnEm", ptr %t379, i32 0, i32 0
  %t382 = load ptr, ptr %t381, !tbaa !29
  %t383 = load i1, ptr %l5, !tbaa !21
  %t384 = load i1, ptr %l6, !tbaa !21
  %t388 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2edescTag(ptr %v0, ptr %s8, ptr %t382, i1 %t383, i1 %t384)
  store { i64, ptr } %t388, ptr %l167
  br label %bb60
bb60:
  %t389 = load { i64, ptr }, ptr %l167, !tbaa !27
  %t390 = extractvalue { i64, ptr } %t389, 0
  %t391 = extractvalue { i64, ptr } %t389, 1
  %t392 = mul i64 %t390, 1
  %t393 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t392)
  call void @llvm.memcpy.p0.p0.i64(ptr %t393, ptr %t391, i64 %t392, i1 false)
  %t394 = insertvalue { i64, ptr } undef, i64 %t390, 0
  %t395 = insertvalue { i64, ptr } %t394, ptr %t393, 1
  %t396 = load ptr, ptr %l159, !tbaa !29
  %t397 = load { i64, ptr }, ptr %l160, !tbaa !27
  %t398 = load i32, ptr %l161, !tbaa !23
  %t399 = load { i64, ptr }, ptr %l162, !tbaa !27
  %t401 = call { { i64, ptr }, i32 } @compiler_2femit_2ecompiler_2femit_3afnEm_2eelemAt(ptr %v0, ptr %v1, ptr %s8, ptr %s8, ptr %s8, ptr %t396, { i64, ptr } %t397, i32 %t398, { i64, ptr } %t399, { i64, ptr } %t395)
  store { { i64, ptr }, i32 } %t401, ptr %l169
  br label %bb61
bb61:
  %t402 = load { { i64, ptr }, i32 }, ptr %l169
  store { { i64, ptr }, i32 } %t402, ptr %l25
  %t403 = getelementptr { { i64, ptr }, i32 }, ptr %l25, i32 0, i32 0
  %t404 = load { i64, ptr }, ptr %t403, !tbaa !27
  store { i64, ptr } %t404, ptr %l170, !tbaa !27
  %t405 = load ptr, ptr %lp3
  %t406 = load { i64, ptr }, ptr %t405, !tbaa !27
  %t407 = extractvalue { i64, ptr } %t406, 0
  %t408 = load { i64, ptr }, ptr %l170, !tbaa !27
  %t409 = extractvalue { i64, ptr } %t408, 0
  store i64 %t409, ptr %l172, !tbaa !24
  %t411 = load i64, ptr %l172, !tbaa !24
  %t412 = icmp eq i64 %t407, %t411
  br i1 %t412, label %bb62, label %bb63
bb62:
  %t414 = load ptr, ptr %lp3
  %t415 = getelementptr { i64, ptr }, ptr %t414, i32 0, i32 1
  %t416 = load ptr, ptr %t415, !tbaa !27
  %t417 = getelementptr { i64, ptr }, ptr %l170, i32 0, i32 1
  %t418 = load ptr, ptr %t417, !tbaa !27
  %t419 = load i64, ptr %l172, !tbaa !24
  %t420 = mul i64 %t419, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t416, ptr %t418, i64 %t420, i1 false)
  br label %bb64
bb63:
  %t421 = load { i64, ptr }, ptr %l170, !tbaa !27
  %t422 = extractvalue { i64, ptr } %t421, 0
  store i64 %t422, ptr %l174, !tbaa !24
  %t423 = load i64, ptr %l174, !tbaa !24
  %t424 = mul i64 %t423, 1
  %t425 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t424)
  %t426 = insertvalue { i64, ptr } undef, i64 %t423, 0
  %t427 = insertvalue { i64, ptr } %t426, ptr %t425, 1
  store { i64, ptr } %t427, ptr %l175, !tbaa !27
  %t428 = getelementptr { i64, ptr }, ptr %l175, i32 0, i32 1
  %t429 = load ptr, ptr %t428, !tbaa !27
  %t430 = getelementptr { i64, ptr }, ptr %l170, i32 0, i32 1
  %t431 = load ptr, ptr %t430, !tbaa !27
  %t432 = load i64, ptr %l174, !tbaa !24
  %t433 = mul i64 %t432, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t429, ptr %t431, i64 %t433, i1 false)
  %t434 = load { i64, ptr }, ptr %l175, !tbaa !27
  %t435 = load ptr, ptr %lp3
  store { i64, ptr } %t434, ptr %t435, !tbaa !27
  br label %bb64
bb64:
  %t436 = getelementptr { { i64, ptr }, i32 }, ptr %l25, i32 0, i32 1
  %t437 = load i32, ptr %t436, !tbaa !23
  store i32 %t437, ptr %l4, !tbaa !23
  store i1 true, ptr %l5, !tbaa !21
  call void @__olang_scope_close(ptr %s8)
  br label %bb116
bb65:
  %t439 = load { i64, [1 x i64] }, ptr %l18
  %t441 = extractvalue { i64, [1 x i64] } %t439, 0
  %t442 = icmp eq i64 %t441, 2
  br i1 %t442, label %bb66, label %bb67
bb66:
  %t444 = getelementptr { i64, [1 x i64] }, ptr %l18, i32 0, i32 1
  %t445 = getelementptr { i64 }, ptr %t444, i32 0, i32 0
  %t446 = load i64, ptr %t445
  store i64 %t446, ptr %l26, !tbaa !24
  br label %bb68
bb67:
  br label %bb78
bb68:
  store %olang.scope zeroinitializer, ptr %s10
  %t448 = load ptr, ptr %l0, !tbaa !29
  %t449 = load i32, ptr %l4, !tbaa !23
  %t452 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2erunTime(ptr %v0, ptr %t448, i32 %t449)
  store i1 %t452, ptr %l182
  br label %bb69
bb69:
  %t453 = load i1, ptr %l182, !tbaa !21
  br i1 %t453, label %bb70, label %bb71
bb70:
  store i1 false, ptr %l6, !tbaa !21
  br label %bb72
bb71:
  br label %bb72
bb72:
  %t454 = load ptr, ptr %l0, !tbaa !29
  store ptr %t454, ptr %l183, !tbaa !29
  %t455 = load ptr, ptr %lp3
  %t456 = load { i64, ptr }, ptr %t455, !tbaa !27
  store { i64, ptr } %t456, ptr %l184, !tbaa !27
  %t457 = load i32, ptr %l4, !tbaa !23
  store i32 %t457, ptr %l185, !tbaa !23
  %t458 = load i64, ptr %l26, !tbaa !24
  %t460 = call i64 @__olang_fmt_i64(ptr null, i64 %t458)
  %t461 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t460)
  %t462 = call i64 @__olang_fmt_i64(ptr %t461, i64 %t458)
  %t463 = insertvalue { i64, ptr } undef, i64 %t460, 0
  %t464 = insertvalue { i64, ptr } %t463, ptr %t461, 1
  %t466 = extractvalue { i64, ptr } %t464, 0
  %t467 = extractvalue { i64, ptr } %t464, 1
  %t468 = mul i64 %t466, 1
  %t469 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t468)
  call void @llvm.memcpy.p0.p0.i64(ptr %t469, ptr %t467, i64 %t468, i1 false)
  %t470 = insertvalue { i64, ptr } undef, i64 %t466, 0
  %t471 = insertvalue { i64, ptr } %t470, ptr %t469, 1
  store { i64, ptr } %t471, ptr %l188, !tbaa !27
  %t472 = load ptr, ptr %l0, !tbaa !29
  %t474 = getelementptr %"compiler/emit:fnEm", ptr %t472, i32 0, i32 0
  %t475 = load ptr, ptr %t474, !tbaa !29
  %t476 = load i1, ptr %l5, !tbaa !21
  %t477 = load i1, ptr %l6, !tbaa !21
  %t481 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2edescTag(ptr %v0, ptr %s10, ptr %t475, i1 %t476, i1 %t477)
  store { i64, ptr } %t481, ptr %l193
  br label %bb73
bb73:
  %t482 = load { i64, ptr }, ptr %l193, !tbaa !27
  %t483 = extractvalue { i64, ptr } %t482, 0
  %t484 = extractvalue { i64, ptr } %t482, 1
  %t485 = mul i64 %t483, 1
  %t486 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t485)
  call void @llvm.memcpy.p0.p0.i64(ptr %t486, ptr %t484, i64 %t485, i1 false)
  %t487 = insertvalue { i64, ptr } undef, i64 %t483, 0
  %t488 = insertvalue { i64, ptr } %t487, ptr %t486, 1
  %t489 = load ptr, ptr %l183, !tbaa !29
  %t490 = load { i64, ptr }, ptr %l184, !tbaa !27
  %t491 = load i32, ptr %l185, !tbaa !23
  %t492 = load { i64, ptr }, ptr %l188, !tbaa !27
  %t494 = call { { i64, ptr }, i32 } @compiler_2femit_2ecompiler_2femit_3afnEm_2eelemAt(ptr %v0, ptr %v1, ptr %s10, ptr %s10, ptr %s10, ptr %t489, { i64, ptr } %t490, i32 %t491, { i64, ptr } %t492, { i64, ptr } %t488)
  store { { i64, ptr }, i32 } %t494, ptr %l195
  br label %bb74
bb74:
  %t495 = load { { i64, ptr }, i32 }, ptr %l195
  store { { i64, ptr }, i32 } %t495, ptr %l27
  %t496 = getelementptr { { i64, ptr }, i32 }, ptr %l27, i32 0, i32 0
  %t497 = load { i64, ptr }, ptr %t496, !tbaa !27
  store { i64, ptr } %t497, ptr %l196, !tbaa !27
  %t498 = load ptr, ptr %lp3
  %t499 = load { i64, ptr }, ptr %t498, !tbaa !27
  %t500 = extractvalue { i64, ptr } %t499, 0
  %t501 = load { i64, ptr }, ptr %l196, !tbaa !27
  %t502 = extractvalue { i64, ptr } %t501, 0
  store i64 %t502, ptr %l198, !tbaa !24
  %t504 = load i64, ptr %l198, !tbaa !24
  %t505 = icmp eq i64 %t500, %t504
  br i1 %t505, label %bb75, label %bb76
bb75:
  %t507 = load ptr, ptr %lp3
  %t508 = getelementptr { i64, ptr }, ptr %t507, i32 0, i32 1
  %t509 = load ptr, ptr %t508, !tbaa !27
  %t510 = getelementptr { i64, ptr }, ptr %l196, i32 0, i32 1
  %t511 = load ptr, ptr %t510, !tbaa !27
  %t512 = load i64, ptr %l198, !tbaa !24
  %t513 = mul i64 %t512, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t509, ptr %t511, i64 %t513, i1 false)
  br label %bb77
bb76:
  %t514 = load { i64, ptr }, ptr %l196, !tbaa !27
  %t515 = extractvalue { i64, ptr } %t514, 0
  store i64 %t515, ptr %l200, !tbaa !24
  %t516 = load i64, ptr %l200, !tbaa !24
  %t517 = mul i64 %t516, 1
  %t518 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t517)
  %t519 = insertvalue { i64, ptr } undef, i64 %t516, 0
  %t520 = insertvalue { i64, ptr } %t519, ptr %t518, 1
  store { i64, ptr } %t520, ptr %l201, !tbaa !27
  %t521 = getelementptr { i64, ptr }, ptr %l201, i32 0, i32 1
  %t522 = load ptr, ptr %t521, !tbaa !27
  %t523 = getelementptr { i64, ptr }, ptr %l196, i32 0, i32 1
  %t524 = load ptr, ptr %t523, !tbaa !27
  %t525 = load i64, ptr %l200, !tbaa !24
  %t526 = mul i64 %t525, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t522, ptr %t524, i64 %t526, i1 false)
  %t527 = load { i64, ptr }, ptr %l201, !tbaa !27
  %t528 = load ptr, ptr %lp3
  store { i64, ptr } %t527, ptr %t528, !tbaa !27
  br label %bb77
bb77:
  %t529 = getelementptr { { i64, ptr }, i32 }, ptr %l27, i32 0, i32 1
  %t530 = load i32, ptr %t529, !tbaa !23
  store i32 %t530, ptr %l4, !tbaa !23
  store i1 true, ptr %l5, !tbaa !21
  call void @__olang_scope_close(ptr %s10)
  br label %bb116
bb78:
  %t532 = load { i64, [1 x i64] }, ptr %l18
  %t534 = extractvalue { i64, [1 x i64] } %t532, 0
  %t535 = icmp eq i64 %t534, 3
  br i1 %t535, label %bb79, label %bb80
bb79:
  br label %bb81
bb80:
  br label %bb95
bb81:
  store %olang.scope zeroinitializer, ptr %s13
  %t537 = load ptr, ptr %l2, !tbaa !29
  %t538 = load i32, ptr %l19, !tbaa !23
  %t541 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t537, i32 %t538)
  store i32 %t541, ptr %l207
  br label %bb82
bb82:
  %t542 = load i32, ptr %l207, !tbaa !23
  store i32 %t542, ptr %l28, !tbaa !23
  %t543 = load i1, ptr %l6, !tbaa !21
  br i1 %t543, label %bb83, label %bb84
bb83:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d380, i32 0, i32 1) }, ptr %l209, !tbaa !27
  br label %bb86
bb84:
  %t545 = load ptr, ptr %l0, !tbaa !29
  %t547 = getelementptr %"compiler/emit:fnEm", ptr %t545, i32 0, i32 0
  %t548 = load ptr, ptr %t547, !tbaa !29
  %t549 = load i32, ptr %l19, !tbaa !23
  %t550 = load i1, ptr %l5, !tbaa !21
  %t554 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etbaa(ptr %v0, ptr %s13, ptr %t548, i32 %t549, i1 %t550)
  store { i64, ptr } %t554, ptr %l214
  br label %bb85
bb85:
  %t555 = load { i64, ptr }, ptr %l214, !tbaa !27
  %t556 = extractvalue { i64, ptr } %t555, 0
  %t557 = extractvalue { i64, ptr } %t555, 1
  %t558 = mul i64 %t556, 1
  %t559 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t558)
  call void @llvm.memcpy.p0.p0.i64(ptr %t559, ptr %t557, i64 %t558, i1 false)
  %t560 = insertvalue { i64, ptr } undef, i64 %t556, 0
  %t561 = insertvalue { i64, ptr } %t560, ptr %t559, 1
  store { i64, ptr } %t561, ptr %l209, !tbaa !27
  br label %bb86
bb86:
  %t563 = load { i64, ptr }, ptr %l209, !tbaa !27
  store { i64, ptr } %t563, ptr %l29, !tbaa !27
  %t564 = load i32, ptr %l28, !tbaa !23
  store i32 %t564, ptr %l4, !tbaa !23
  %t566 = load ptr, ptr %l0, !tbaa !29
  %t567 = load i32, ptr %l28, !tbaa !23
  %t570 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2erunTime(ptr %v0, ptr %t566, i32 %t567)
  store i1 %t570, ptr %l219
  br label %bb87
bb87:
  %t571 = load i1, ptr %l219, !tbaa !21
  %t572 = xor i1 %t571, true
  br i1 %t572, label %bb88, label %bb89
bb88:
  %t574 = load ptr, ptr %l0, !tbaa !29
  %t575 = load ptr, ptr %lp3
  %t576 = load { i64, ptr }, ptr %t575, !tbaa !27
  %t577 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t581 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %v1, ptr %v1, ptr %s13, ptr %v1, ptr %t574, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d381, i32 0, i32 1) }, { i64, ptr } %t576, { i64, ptr } %t577)
  store { i64, ptr } %t581, ptr %l224
  br label %bb90
bb89:
  br label %bb94
bb90:
  %t582 = load ptr, ptr %lp3
  %t583 = load { i64, ptr }, ptr %t582, !tbaa !27
  %t584 = extractvalue { i64, ptr } %t583, 0
  %t585 = load { i64, ptr }, ptr %l224, !tbaa !27
  %t586 = extractvalue { i64, ptr } %t585, 0
  store i64 %t586, ptr %l226, !tbaa !24
  %t588 = load i64, ptr %l226, !tbaa !24
  %t589 = icmp eq i64 %t584, %t588
  br i1 %t589, label %bb91, label %bb92
bb91:
  %t591 = load ptr, ptr %lp3
  %t592 = getelementptr { i64, ptr }, ptr %t591, i32 0, i32 1
  %t593 = load ptr, ptr %t592, !tbaa !27
  %t594 = getelementptr { i64, ptr }, ptr %l224, i32 0, i32 1
  %t595 = load ptr, ptr %t594, !tbaa !27
  %t596 = load i64, ptr %l226, !tbaa !24
  %t597 = mul i64 %t596, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t593, ptr %t595, i64 %t597, i1 false)
  br label %bb93
bb92:
  %t598 = load { i64, ptr }, ptr %l224, !tbaa !27
  %t599 = load ptr, ptr %lp3
  store { i64, ptr } %t598, ptr %t599, !tbaa !27
  br label %bb93
bb93:
  store i1 false, ptr %l6, !tbaa !21
  store i1 false, ptr %l5, !tbaa !21
  br label %bb94
bb94:
  call void @__olang_scope_close(ptr %s13)
  br label %bb116
bb95:
  %t600 = load { i64, [1 x i64] }, ptr %l18
  %t602 = extractvalue { i64, [1 x i64] } %t600, 0
  %t603 = icmp eq i64 %t602, 4
  br i1 %t603, label %bb96, label %bb97
bb96:
  br label %bb98
bb97:
  br label %bb115
bb98:
  store %olang.scope zeroinitializer, ptr %s15
  %t605 = load ptr, ptr %l0, !tbaa !29
  store ptr %t605, ptr %l230, !tbaa !29
  %t606 = load ptr, ptr %l0, !tbaa !29
  %t607 = load i32, ptr %l19, !tbaa !23
  %t610 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s15, ptr %t606, i32 %t607)
  store { i64, ptr } %t610, ptr %l233
  br label %bb99
bb99:
  %t611 = load ptr, ptr %lp3
  %t612 = load { i64, ptr }, ptr %t611, !tbaa !27
  %t613 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d382, i32 0, i32 1) }, 1
  %t614 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d382, i32 0, i32 1) }, 0
  %t615 = load { i64, ptr }, ptr %l233, !tbaa !27
  %t616 = extractvalue { i64, ptr } %t615, 1
  %t617 = extractvalue { i64, ptr } %t615, 0
  %t618 = add i64 %t614, %t617
  %t619 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d383, i32 0, i32 1) }, 1
  %t620 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d383, i32 0, i32 1) }, 0
  %t621 = add i64 %t618, %t620
  %t623 = extractvalue { i64, ptr } %t612, 1
  %t624 = extractvalue { i64, ptr } %t612, 0
  %t625 = add i64 %t621, %t624
  %t626 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d384, i32 0, i32 1) }, 1
  %t627 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d384, i32 0, i32 1) }, 0
  %t628 = add i64 %t625, %t627
  %t629 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t628)
  call void @olang_textcopy(ptr %t629, ptr %t613, i64 %t614)
  %t630 = getelementptr i8, ptr %t629, i64 %t614
  call void @olang_textcopy(ptr %t630, ptr %t616, i64 %t617)
  %t631 = getelementptr i8, ptr %t630, i64 %t617
  call void @olang_textcopy(ptr %t631, ptr %t619, i64 %t620)
  %t632 = getelementptr i8, ptr %t631, i64 %t620
  call void @olang_textcopy(ptr %t632, ptr %t623, i64 %t624)
  %t633 = getelementptr i8, ptr %t632, i64 %t624
  call void @olang_textcopy(ptr %t633, ptr %t626, i64 %t627)
  %t634 = insertvalue { i64, ptr } undef, i64 %t628, 0
  %t635 = insertvalue { i64, ptr } %t634, ptr %t629, 1
  %t637 = extractvalue { i64, ptr } %t635, 0
  %t638 = extractvalue { i64, ptr } %t635, 1
  %t639 = mul i64 %t637, 1
  %t640 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t639)
  call void @llvm.memcpy.p0.p0.i64(ptr %t640, ptr %t638, i64 %t639, i1 false)
  %t641 = insertvalue { i64, ptr } undef, i64 %t637, 0
  %t642 = insertvalue { i64, ptr } %t641, ptr %t640, 1
  %t643 = load ptr, ptr %l230, !tbaa !29
  %t645 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v1, ptr %t643, { i64, ptr } %t642)
  store { i64, ptr } %t645, ptr %l237
  br label %bb100
bb100:
  %t646 = load ptr, ptr %lp3
  %t647 = load { i64, ptr }, ptr %t646, !tbaa !27
  %t648 = extractvalue { i64, ptr } %t647, 0
  %t649 = load { i64, ptr }, ptr %l237, !tbaa !27
  %t650 = extractvalue { i64, ptr } %t649, 0
  store i64 %t650, ptr %l239, !tbaa !24
  %t652 = load i64, ptr %l239, !tbaa !24
  %t653 = icmp eq i64 %t648, %t652
  br i1 %t653, label %bb101, label %bb102
bb101:
  %t655 = load ptr, ptr %lp3
  %t656 = getelementptr { i64, ptr }, ptr %t655, i32 0, i32 1
  %t657 = load ptr, ptr %t656, !tbaa !27
  %t658 = getelementptr { i64, ptr }, ptr %l237, i32 0, i32 1
  %t659 = load ptr, ptr %t658, !tbaa !27
  %t660 = load i64, ptr %l239, !tbaa !24
  %t661 = mul i64 %t660, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t657, ptr %t659, i64 %t661, i1 false)
  br label %bb103
bb102:
  %t662 = load { i64, ptr }, ptr %l237, !tbaa !27
  %t663 = load ptr, ptr %lp3
  store { i64, ptr } %t662, ptr %t663, !tbaa !27
  br label %bb103
bb103:
  %t664 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t664, ptr %l4, !tbaa !23
  %t666 = load ptr, ptr %l2, !tbaa !29
  store ptr %t666, ptr %l242, !tbaa !29
  %t667 = load ptr, ptr %l0, !tbaa !29
  %t668 = load i32, ptr %l19, !tbaa !23
  %t671 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2ecasesList(ptr %v0, ptr %t667, i32 %t668)
  store i32 %t671, ptr %l245
  br label %bb104
bb104:
  %t672 = load ptr, ptr %l242, !tbaa !29
  %t673 = load i32, ptr %l245, !tbaa !23
  %t674 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t672, i32 %t673)
  store { i64, ptr } %t674, ptr %l246
  br label %bb105
bb105:
  %t675 = load { i64, ptr }, ptr %l246, !tbaa !27
  store { i64, ptr } %t675, ptr %l30, !tbaa !27
  %t676 = load { i64, [1 x i64] }, ptr %l18
  %t678 = extractvalue { i64, [1 x i64] } %t676, 0
  %t679 = icmp eq i64 %t678, 4
  br i1 %t679, label %bb106, label %bb107
bb106:
  %t681 = getelementptr { i64, [1 x i64] }, ptr %l18, i32 0, i32 1
  %t682 = getelementptr { i64 }, ptr %t681, i32 0, i32 0
  %t683 = load i64, ptr %t682
  store i64 %t683, ptr %l31, !tbaa !24
  br label %bb108
bb107:
  br label %bb109
bb108:
  %t685 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t685, ptr %l250, !tbaa !27
  %t686 = load i64, ptr %l31, !tbaa !24
  %t688 = getelementptr { i64, ptr }, ptr %l250, i32 0, i32 1
  %t689 = load ptr, ptr %t688, !tbaa !27
  %t690 = getelementptr i32, ptr %t689, i64 %t686
  %t691 = load i32, ptr %t690, !tbaa !33
  store i32 %t691, ptr %l4, !tbaa !23
  br label %bb114
bb109:
  br i1 true, label %bb110, label %bb111
bb110:
  br label %bb112
bb111:
  br label %bb113
bb112:
  br label %bb114
bb113:
  call void @__olang_check_failed(ptr @olang_loc_f0091f918c975106_bc2d594a86836fba)
  unreachable
bb114:
  store i1 true, ptr %l6, !tbaa !21
  call void @__olang_scope_close(ptr %s15)
  br label %bb116
bb115:
  call void @__olang_check_failed(ptr @olang_loc_44ab2decf02f961d_3f31a3219a480a51)
  unreachable
bb116:
  br label %bb117
bb117:
  %t693 = load i32, ptr %l16, !tbaa !23
  %t695 = add i32 %t693, 1
  store i32 %t695, ptr %l16, !tbaa !23
  br label %bb30
bb118:
  %t697 = load ptr, ptr %l0, !tbaa !29
  store ptr %t697, ptr %l255, !tbaa !29
  %t698 = load i1, ptr %l6, !tbaa !21
  br i1 %t698, label %bb119, label %bb120
bb119:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d385, i32 0, i32 1) }, ptr %l257, !tbaa !27
  br label %bb122
bb120:
  %t700 = load ptr, ptr %l0, !tbaa !29
  %t702 = getelementptr %"compiler/emit:fnEm", ptr %t700, i32 0, i32 0
  %t703 = load ptr, ptr %t702, !tbaa !29
  %t704 = load i32, ptr %l4, !tbaa !23
  %t705 = load i1, ptr %l5, !tbaa !21
  %t709 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etbaa(ptr %v0, ptr %v0, ptr %t703, i32 %t704, i1 %t705)
  store { i64, ptr } %t709, ptr %l262
  br label %bb121
bb121:
  %t710 = load { i64, ptr }, ptr %l262, !tbaa !27
  %t711 = extractvalue { i64, ptr } %t710, 0
  %t712 = extractvalue { i64, ptr } %t710, 1
  %t713 = mul i64 %t711, 1
  %t714 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t713)
  call void @llvm.memcpy.p0.p0.i64(ptr %t714, ptr %t712, i64 %t713, i1 false)
  %t715 = insertvalue { i64, ptr } undef, i64 %t711, 0
  %t716 = insertvalue { i64, ptr } %t715, ptr %t714, 1
  store { i64, ptr } %t716, ptr %l257, !tbaa !27
  br label %bb122
bb122:
  %t718 = load { i64, ptr }, ptr %l257, !tbaa !27
  %t719 = load ptr, ptr %l255, !tbaa !29
  %t720 = getelementptr %"compiler/emit:fnEm", ptr %t719, i32 0, i32 14
  store { i64, ptr } %t718, ptr %t720, !tbaa !27
  %t721 = load ptr, ptr %lp3
  %t722 = load { i64, ptr }, ptr %t721, !tbaa !27
  %t723 = load i32, ptr %l4, !tbaa !23
  %t725 = insertvalue { { i64, ptr }, i32 } undef, { i64, ptr } %t722, 0
  %t727 = insertvalue { { i64, ptr }, i32 } %t725, i32 %t723, 1
  store { { i64, ptr }, i32 } %t727, ptr %rv
  br label %ret
ret:
  %rr = load { { i64, ptr }, i32 }, ptr %rv
  ret { { i64, ptr }, i32 } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ealloca(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %lp3 = alloca ptr
  %l5 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2etmp(ptr %v0, ptr %v2, ptr %t1)
  store { i64, ptr } %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t4, ptr %lp3
  %t5 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t6 = load ptr, ptr %lp3
  store { i64, ptr } %t5, ptr %t6, !tbaa !27
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/emit:fnEm", ptr %t7, i32 0, i32 3
  %t10 = load ptr, ptr %lp3
  %t11 = load { i64, ptr }, ptr %t10, !tbaa !27
  %t13 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d386, i32 0, i32 1) }, 1
  %t14 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d386, i32 0, i32 1) }, 0
  %t16 = extractvalue { i64, ptr } %t11, 1
  %t17 = extractvalue { i64, ptr } %t11, 0
  %t18 = add i64 %t14, %t17
  %t19 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d387, i32 0, i32 1) }, 1
  %t20 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d387, i32 0, i32 1) }, 0
  %t21 = add i64 %t18, %t20
  %t23 = extractvalue { i64, ptr } %a1, 1
  %t24 = extractvalue { i64, ptr } %a1, 0
  %t25 = add i64 %t21, %t24
  %t26 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t25)
  call void @olang_textcopy(ptr %t26, ptr %t13, i64 %t14)
  %t27 = getelementptr i8, ptr %t26, i64 %t14
  call void @olang_textcopy(ptr %t27, ptr %t16, i64 %t17)
  %t28 = getelementptr i8, ptr %t27, i64 %t17
  call void @olang_textcopy(ptr %t28, ptr %t19, i64 %t20)
  %t29 = getelementptr i8, ptr %t28, i64 %t20
  call void @olang_textcopy(ptr %t29, ptr %t23, i64 %t24)
  %t30 = insertvalue { i64, ptr } undef, i64 %t25, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t26, 1
  %t33 = extractvalue { i64, ptr } %t31, 0
  %t34 = extractvalue { i64, ptr } %t31, 1
  %t35 = mul i64 %t33, 1
  %t36 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t35)
  call void @llvm.memcpy.p0.p0.i64(ptr %t36, ptr %t34, i64 %t35, i1 false)
  %t37 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t38 = insertvalue { i64, ptr } %t37, ptr %t36, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s0, ptr %t9, { i64, ptr } %t38)
  br label %bb2
bb2:
  %t41 = load i64, ptr %l2, !tbaa !24
  %t43 = icmp sgt i64 %t41, 0
  br i1 %t43, label %bb3, label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/emit:fnEm", ptr %t45, i32 0, i32 3
  %t48 = load i64, ptr %l2, !tbaa !24
  %t49 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d388, i32 0, i32 1) }, 1
  %t50 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d388, i32 0, i32 1) }, 0
  %t52 = call i64 @__olang_fmt_i64(ptr null, i64 %t48)
  %t53 = add i64 %t50, %t52
  %t54 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t53)
  call void @olang_textcopy(ptr %t54, ptr %t49, i64 %t50)
  %t55 = getelementptr i8, ptr %t54, i64 %t50
  %t56 = call i64 @__olang_fmt_i64(ptr %t55, i64 %t48)
  %t57 = insertvalue { i64, ptr } undef, i64 %t53, 0
  %t58 = insertvalue { i64, ptr } %t57, ptr %t54, 1
  %t60 = extractvalue { i64, ptr } %t58, 0
  %t61 = extractvalue { i64, ptr } %t58, 1
  %t62 = mul i64 %t60, 1
  %t63 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t62)
  call void @llvm.memcpy.p0.p0.i64(ptr %t63, ptr %t61, i64 %t62, i1 false)
  %t64 = insertvalue { i64, ptr } undef, i64 %t60, 0
  %t65 = insertvalue { i64, ptr } %t64, ptr %t63, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s2, ptr %t47, { i64, ptr } %t65)
  br label %bb5
bb4:
  br label %bb6
bb5:
  call void @__olang_scope_close(ptr %s2)
  br label %bb6
bb6:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/emit:fnEm", ptr %t68, i32 0, i32 3
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %t70, i8 10)
  br label %bb7
bb7:
  %t72 = load ptr, ptr %lp3
  %t73 = load { i64, ptr }, ptr %t72, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t73, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2earrayStorage(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, i32 %a3, i1 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l4 = alloca i1
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l10 = alloca i64
  %l14 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store i1 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2ealign(ptr %v0, ptr %t1, i32 %a3)
  store i64 %t5, ptr %l10
  br label %bb1
bb1:
  %t6 = load i64, ptr %l10, !tbaa !24
  store i64 %t6, ptr %l5, !tbaa !24
  %t7 = load i64, ptr %l5, !tbaa !24
  %t9 = icmp sgt i64 %t7, 8
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load i1, ptr %l4, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb3:
  br label %bb9
bb4:
  store { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d389, i32 0, i32 1) }, ptr %l14, !tbaa !27
  br label %bb6
bb5:
  store { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d390, i32 0, i32 1) }, ptr %l14, !tbaa !27
  br label %bb6
bb6:
  %t13 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t13, ptr %l6, !tbaa !27
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/emit:fnEm", ptr %t14, i32 0, i32 0
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t18 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t19 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %t19, ptr %t17, { i64, ptr } %t18)
  br label %bb7
bb7:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t24 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t25 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t26 = load i64, ptr %l5, !tbaa !24
  %t27 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d391, i32 0, i32 1) }, 1
  %t28 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d391, i32 0, i32 1) }, 0
  %t30 = extractvalue { i64, ptr } %t23, 1
  %t31 = extractvalue { i64, ptr } %t23, 0
  %t32 = add i64 %t28, %t31
  %t33 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d392, i32 0, i32 1) }, 1
  %t34 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d392, i32 0, i32 1) }, 0
  %t35 = add i64 %t32, %t34
  %t37 = extractvalue { i64, ptr } %t24, 1
  %t38 = extractvalue { i64, ptr } %t24, 0
  %t39 = add i64 %t35, %t38
  %t40 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d393, i32 0, i32 1) }, 1
  %t41 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d393, i32 0, i32 1) }, 0
  %t42 = add i64 %t39, %t41
  %t44 = extractvalue { i64, ptr } %t25, 1
  %t45 = extractvalue { i64, ptr } %t25, 0
  %t46 = add i64 %t42, %t45
  %t47 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d393, i32 0, i32 1) }, 1
  %t48 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d393, i32 0, i32 1) }, 0
  %t49 = add i64 %t46, %t48
  %t51 = call i64 @__olang_fmt_i64(ptr null, i64 %t26)
  %t52 = add i64 %t49, %t51
  %t53 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d394, i32 0, i32 1) }, 1
  %t54 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d394, i32 0, i32 1) }, 0
  %t55 = add i64 %t52, %t54
  %t56 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t55)
  call void @olang_textcopy(ptr %t56, ptr %t27, i64 %t28)
  %t57 = getelementptr i8, ptr %t56, i64 %t28
  call void @olang_textcopy(ptr %t57, ptr %t30, i64 %t31)
  %t58 = getelementptr i8, ptr %t57, i64 %t31
  call void @olang_textcopy(ptr %t58, ptr %t33, i64 %t34)
  %t59 = getelementptr i8, ptr %t58, i64 %t34
  call void @olang_textcopy(ptr %t59, ptr %t37, i64 %t38)
  %t60 = getelementptr i8, ptr %t59, i64 %t38
  call void @olang_textcopy(ptr %t60, ptr %t40, i64 %t41)
  %t61 = getelementptr i8, ptr %t60, i64 %t41
  call void @olang_textcopy(ptr %t61, ptr %t44, i64 %t45)
  %t62 = getelementptr i8, ptr %t61, i64 %t45
  call void @olang_textcopy(ptr %t62, ptr %t47, i64 %t48)
  %t63 = getelementptr i8, ptr %t62, i64 %t48
  %t64 = call i64 @__olang_fmt_i64(ptr %t63, i64 %t26)
  %t65 = getelementptr i8, ptr %t63, i64 %t51
  call void @olang_textcopy(ptr %t65, ptr %t53, i64 %t54)
  %t66 = insertvalue { i64, ptr } undef, i64 %t55, 0
  %t67 = insertvalue { i64, ptr } %t66, ptr %t56, 1
  %t69 = extractvalue { i64, ptr } %t67, 0
  %t70 = extractvalue { i64, ptr } %t67, 1
  %t71 = mul i64 %t69, 1
  %t72 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t71)
  call void @llvm.memcpy.p0.p0.i64(ptr %t72, ptr %t70, i64 %t71, i1 false)
  %t73 = insertvalue { i64, ptr } undef, i64 %t69, 0
  %t74 = insertvalue { i64, ptr } %t73, ptr %t72, 1
  %t77 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v3, ptr %v3, ptr %t22, { i64, ptr } %t74)
  store { i64, ptr } %t77, ptr %l25
  br label %bb8
bb8:
  %t78 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t78, ptr %rv
  br label %ret
bb9:
  %t79 = load i1, ptr %l4, !tbaa !21
  br i1 %t79, label %bb10, label %bb11
bb10:
  store { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d395, i32 0, i32 1) }, ptr %l27, !tbaa !27
  br label %bb12
bb11:
  store { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d396, i32 0, i32 1) }, ptr %l27, !tbaa !27
  br label %bb12
bb12:
  %t81 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t81, ptr %l7, !tbaa !27
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/emit:fnEm", ptr %t82, i32 0, i32 0
  %t85 = load ptr, ptr %t84, !tbaa !29
  %t86 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t87 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %t87, ptr %t85, { i64, ptr } %t86)
  br label %bb13
bb13:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t91 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t92 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t93 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t94 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d397, i32 0, i32 1) }, 1
  %t95 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d397, i32 0, i32 1) }, 0
  %t97 = extractvalue { i64, ptr } %t91, 1
  %t98 = extractvalue { i64, ptr } %t91, 0
  %t99 = add i64 %t95, %t98
  %t100 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d398, i32 0, i32 1) }, 1
  %t101 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d398, i32 0, i32 1) }, 0
  %t102 = add i64 %t99, %t101
  %t104 = extractvalue { i64, ptr } %t92, 1
  %t105 = extractvalue { i64, ptr } %t92, 0
  %t106 = add i64 %t102, %t105
  %t107 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d399, i32 0, i32 1) }, 1
  %t108 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d399, i32 0, i32 1) }, 0
  %t109 = add i64 %t106, %t108
  %t111 = extractvalue { i64, ptr } %t93, 1
  %t112 = extractvalue { i64, ptr } %t93, 0
  %t113 = add i64 %t109, %t112
  %t114 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d400, i32 0, i32 1) }, 1
  %t115 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d400, i32 0, i32 1) }, 0
  %t116 = add i64 %t113, %t115
  %t117 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t116)
  call void @olang_textcopy(ptr %t117, ptr %t94, i64 %t95)
  %t118 = getelementptr i8, ptr %t117, i64 %t95
  call void @olang_textcopy(ptr %t118, ptr %t97, i64 %t98)
  %t119 = getelementptr i8, ptr %t118, i64 %t98
  call void @olang_textcopy(ptr %t119, ptr %t100, i64 %t101)
  %t120 = getelementptr i8, ptr %t119, i64 %t101
  call void @olang_textcopy(ptr %t120, ptr %t104, i64 %t105)
  %t121 = getelementptr i8, ptr %t120, i64 %t105
  call void @olang_textcopy(ptr %t121, ptr %t107, i64 %t108)
  %t122 = getelementptr i8, ptr %t121, i64 %t108
  call void @olang_textcopy(ptr %t122, ptr %t111, i64 %t112)
  %t123 = getelementptr i8, ptr %t122, i64 %t112
  call void @olang_textcopy(ptr %t123, ptr %t114, i64 %t115)
  %t124 = insertvalue { i64, ptr } undef, i64 %t116, 0
  %t125 = insertvalue { i64, ptr } %t124, ptr %t117, 1
  %t127 = extractvalue { i64, ptr } %t125, 0
  %t128 = extractvalue { i64, ptr } %t125, 1
  %t129 = mul i64 %t127, 1
  %t130 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t129)
  call void @llvm.memcpy.p0.p0.i64(ptr %t130, ptr %t128, i64 %t129, i1 false)
  %t131 = insertvalue { i64, ptr } undef, i64 %t127, 0
  %t132 = insertvalue { i64, ptr } %t131, ptr %t130, 1
  %t135 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v3, ptr %v3, ptr %t90, { i64, ptr } %t132)
  store { i64, ptr } %t135, ptr %l37
  br label %bb14
bb14:
  %t136 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t136, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ebitcast(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %lp5 = alloca ptr
  %l7 = alloca i1
  %l10 = alloca { i64, ptr }
  %l12 = alloca i1
  %l13 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l27 = alloca i1
  %l28 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d401, i32 0, i32 1) })
  store i1 %t3, ptr %l7
  br label %bb1
bb1:
  %t4 = load i1, ptr %l7, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t6 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t9 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ebf16Bits(ptr %v0, ptr %v1, ptr %v4, ptr %t5, { i64, ptr } %t6, i1 true)
  store { i64, ptr } %t9, ptr %l10
  br label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_scope_close(ptr %s0)
  %t10 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t10, ptr %rv
  br label %ret
bb5:
  %t11 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t13 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v3, ptr %s0, { i64, ptr } %t11, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d402, i32 0, i32 1) })
  store i1 %t13, ptr %l12
  br label %bb6
bb6:
  %t14 = load i1, ptr %l12, !tbaa !21
  br i1 %t14, label %bb7, label %bb8
bb7:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t19 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eopaque16(ptr %v0, ptr %v1, ptr %s0, ptr %t15, { i64, ptr } %t16)
  store { i64, ptr } %t19, ptr %l16
  br label %bb9
bb8:
  %t20 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t20, 1
  %t23 = extractvalue { i64, ptr } %t20, 0
  %t24 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t23)
  call void @olang_textcopy(ptr %t24, ptr %t22, i64 %t23)
  %t25 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t26 = insertvalue { i64, ptr } %t25, ptr %t24, 1
  store { i64, ptr } %t26, ptr %l13, !tbaa !27
  br label %bb10
bb9:
  %t28 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t28, ptr %l13, !tbaa !27
  br label %bb10
bb10:
  %t29 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t33 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t34 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d403, i32 0, i32 1) }, 1
  %t35 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d403, i32 0, i32 1) }, 0
  %t37 = extractvalue { i64, ptr } %t31, 1
  %t38 = extractvalue { i64, ptr } %t31, 0
  %t39 = add i64 %t35, %t38
  %t40 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d404, i32 0, i32 1) }, 1
  %t41 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d404, i32 0, i32 1) }, 0
  %t42 = add i64 %t39, %t41
  %t44 = extractvalue { i64, ptr } %t29, 1
  %t45 = extractvalue { i64, ptr } %t29, 0
  %t46 = add i64 %t42, %t45
  %t47 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d405, i32 0, i32 1) }, 1
  %t48 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d405, i32 0, i32 1) }, 0
  %t49 = add i64 %t46, %t48
  %t51 = extractvalue { i64, ptr } %t33, 1
  %t52 = extractvalue { i64, ptr } %t33, 0
  %t53 = add i64 %t49, %t52
  %t54 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t53)
  call void @olang_textcopy(ptr %t54, ptr %t34, i64 %t35)
  %t55 = getelementptr i8, ptr %t54, i64 %t35
  call void @olang_textcopy(ptr %t55, ptr %t37, i64 %t38)
  %t56 = getelementptr i8, ptr %t55, i64 %t38
  call void @olang_textcopy(ptr %t56, ptr %t40, i64 %t41)
  %t57 = getelementptr i8, ptr %t56, i64 %t41
  call void @olang_textcopy(ptr %t57, ptr %t44, i64 %t45)
  %t58 = getelementptr i8, ptr %t57, i64 %t45
  call void @olang_textcopy(ptr %t58, ptr %t47, i64 %t48)
  %t59 = getelementptr i8, ptr %t58, i64 %t48
  call void @olang_textcopy(ptr %t59, ptr %t51, i64 %t52)
  %t60 = insertvalue { i64, ptr } undef, i64 %t53, 0
  %t61 = insertvalue { i64, ptr } %t60, ptr %t54, 1
  %t63 = extractvalue { i64, ptr } %t61, 0
  %t64 = extractvalue { i64, ptr } %t61, 1
  %t65 = mul i64 %t63, 1
  %t66 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t65)
  call void @llvm.memcpy.p0.p0.i64(ptr %t66, ptr %t64, i64 %t65, i1 false)
  %t67 = insertvalue { i64, ptr } undef, i64 %t63, 0
  %t68 = insertvalue { i64, ptr } %t67, ptr %t66, 1
  %t71 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v4, ptr %v4, ptr %t30, { i64, ptr } %t68)
  store { i64, ptr } %t71, ptr %l25
  br label %bb11
bb11:
  %t72 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 16, i64 8)
  store ptr %t72, ptr %lp5
  %t73 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t74 = load ptr, ptr %lp5
  store { i64, ptr } %t73, ptr %t74, !tbaa !27
  %t75 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t77 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t75, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d406, i32 0, i32 1) })
  store i1 %t77, ptr %l27
  br label %bb12
bb12:
  %t78 = load i1, ptr %l27, !tbaa !21
  br i1 %t78, label %bb13, label %bb14
bb13:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t80 = load ptr, ptr %lp5
  %t81 = load { i64, ptr }, ptr %t80, !tbaa !27
  %t84 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eopaque16(ptr %v0, ptr %v4, ptr %v4, ptr %t79, { i64, ptr } %t81)
  store { i64, ptr } %t84, ptr %l31
  br label %bb15
bb14:
  %t85 = load ptr, ptr %lp5
  %t86 = load { i64, ptr }, ptr %t85, !tbaa !27
  store { i64, ptr } %t86, ptr %l28, !tbaa !27
  br label %bb16
bb15:
  %t88 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t88, ptr %l28, !tbaa !27
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s0)
  %t89 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t89, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3afnEm_2eexit(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, { i64, [4 x i64] } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l3 = alloca { i64, [4 x i64] }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i32
  %l7 = alloca { i64, ptr }
  %l8 = alloca i32
  %l9 = alloca { i64, ptr }
  %l10 = alloca i32
  %l12 = alloca { { i64, ptr }, { i64, ptr } }
  %l15 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l20 = alloca i1
  %l23 = alloca ptr
  %l24 = alloca i32
  %l26 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l35 = alloca i64
  %l36 = alloca { i64, ptr }
  %l42 = alloca { i64, ptr }
  %l44 = alloca i64
  %l50 = alloca ptr
  %l53 = alloca { i64, ptr }
  %l56 = alloca ptr
  %l60 = alloca { i64, ptr }
  %l66 = alloca { i64, ptr }
  %l67 = alloca { i64, ptr }
  %l68 = alloca i64
  %l69 = alloca { i64, ptr }
  %l75 = alloca { i64, ptr }
  %l77 = alloca i64
  %l81 = alloca i1
  %l82 = alloca { i64, ptr }
  %l89 = alloca ptr
  %l90 = alloca { i64, ptr }
  %l96 = alloca { i64, ptr }
  %l104 = alloca ptr
  %l110 = alloca { i64, ptr }
  %l117 = alloca i32
  %l121 = alloca { i64, ptr }
  %l125 = alloca { { i64, ptr }, { i64, ptr } }
  %l126 = alloca { i64, ptr }
  %l127 = alloca i64
  %l128 = alloca { i64, ptr }
  %l129 = alloca { i64, ptr }
  %l130 = alloca i64
  %l131 = alloca { i64, ptr }
  %l135 = alloca { i64, ptr }
  %l136 = alloca ptr
  %l142 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.builder
  %s2room = alloca [64 x i8], align 8
  %s3 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s17 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  store { i64, [4 x i64] } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l2
  %t3 = call { i64, ptr } @compiler_2fmir_2eExitText(ptr %s0, i32 %t1)
  store { i64, ptr } %t3, ptr %l17
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t4, ptr %l4, !tbaa !27
  %t5 = load i32, ptr %l2
  %t7 = trunc i64 0 to i32
  %t8 = icmp eq i32 %t5, %t7
  br i1 %t8, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb4
bb3:
  %t10 = load i32, ptr %l2
  %t12 = trunc i64 1 to i32
  %t13 = icmp eq i32 %t10, %t12
  store i1 %t13, ptr %l20, !tbaa !21
  br label %bb4
bb4:
  %t15 = load i1, ptr %l20, !tbaa !21
  br i1 %t15, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l23, !tbaa !29
  %t17 = load i32, ptr %l2
  store i32 %t17, ptr %l24
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s2
  store ptr %s2room, ptr %s2
  %t18 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d407, i32 0, i32 1) }, 1
  %t19 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d407, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s2, ptr %t18, i64 %t19)
  call void @olang_2eHelperKind_2eRender_2ecompiler_2fmir_3aExitKind(ptr %s2, ptr %l24, i64 0)
  br label %bb7
bb6:
  br label %bb9
bb7:
  %t21 = load ptr, ptr %s2
  %t22 = getelementptr %olang.builder, ptr %s2, i32 0, i32 1
  %t23 = load i64, ptr %t22
  %t24 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t23)
  call void @olang_textcopy(ptr %t24, ptr %t21, i64 %t23)
  %t25 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t26 = insertvalue { i64, ptr } %t25, ptr %t24, 1
  store { i64, ptr } %t26, ptr %l26, !tbaa !27
  %t27 = getelementptr %olang.builder, ptr %s2, i32 0, i32 3
  %t28 = load ptr, ptr %t27
  %t29 = icmp ne ptr %t28, null
  br i1 %t29, label %sbgrew.30, label %sbdone.31
sbgrew.30:
  call void @__olang_sb_done(ptr %s2)
  br label %sbdone.31
sbdone.31:
  %t32 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t33 = extractvalue { i64, ptr } %t32, 0
  %t34 = extractvalue { i64, ptr } %t32, 1
  %t35 = mul i64 %t33, 1
  %t36 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t35)
  call void @llvm.memcpy.p0.p0.i64(ptr %t36, ptr %t34, i64 %t35, i1 false)
  %t37 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t38 = insertvalue { i64, ptr } %t37, ptr %t36, 1
  %t39 = load ptr, ptr %l23, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2egap(ptr %v0, ptr %s1, ptr %t39, { i64, ptr } %t38)
  br label %bb8
bb8:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d408, i32 0, i32 1) }, ptr %l28, !tbaa !27
  %t41 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t41, 0
  %t44 = extractvalue { i64, ptr } %t41, 1
  %t45 = mul i64 %t43, 1
  %t46 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t45)
  call void @llvm.memcpy.p0.p0.i64(ptr %t46, ptr %t44, i64 %t45, i1 false)
  %t47 = insertvalue { i64, ptr } undef, i64 %t43, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t46, 1
  store { i64, ptr } %t48, ptr %l4, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  br label %bb9
bb9:
  %t50 = load i32, ptr %l2
  %t52 = trunc i64 14 to i32
  %t53 = icmp eq i32 %t50, %t52
  br i1 %t53, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s3
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d409, i32 0, i32 1) }, ptr %l33, !tbaa !27
  %t55 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t55, ptr %l34, !tbaa !27
  %t56 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t57 = extractvalue { i64, ptr } %t56, 0
  store i64 %t57, ptr %l35, !tbaa !24
  %t58 = load i64, ptr %l35, !tbaa !24
  %t59 = mul i64 %t58, 1
  %t60 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t59)
  %t61 = insertvalue { i64, ptr } undef, i64 %t58, 0
  %t62 = insertvalue { i64, ptr } %t61, ptr %t60, 1
  store { i64, ptr } %t62, ptr %l36, !tbaa !27
  %t63 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !27
  %t65 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !27
  %t67 = load i64, ptr %l35, !tbaa !24
  %t68 = mul i64 %t67, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t64, ptr %t66, i64 %t68, i1 false)
  %t69 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t69, ptr %l5, !tbaa !27
  %t70 = load { i64, [4 x i64] }, ptr %l3
  %t72 = extractvalue { i64, [4 x i64] } %t70, 0
  %t73 = icmp eq i64 %t72, 3
  br i1 %t73, label %bb12, label %bb13
bb11:
  br label %bb32
bb12:
  %t75 = getelementptr { i64, [4 x i64] }, ptr %l3, i32 0, i32 1
  %t76 = getelementptr { i32, i32, i64, %"compiler/source:Span" }, ptr %t75, i32 0, i32 1
  %t77 = load i32, ptr %t76
  store i32 %t77, ptr %l6, !tbaa !23
  br label %bb14
bb13:
  br label %bb19
bb14:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t80 = load i32, ptr %l6, !tbaa !23
  %t83 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2econstText(ptr %v0, ptr %s3, ptr %t79, i32 %t80)
  store { i64, ptr } %t83, ptr %l42
  br label %bb15
bb15:
  %t84 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t85 = extractvalue { i64, ptr } %t84, 0
  %t86 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t87 = extractvalue { i64, ptr } %t86, 0
  store i64 %t87, ptr %l44, !tbaa !24
  %t89 = load i64, ptr %l44, !tbaa !24
  %t90 = icmp eq i64 %t85, %t89
  br i1 %t90, label %bb16, label %bb17
bb16:
  %t92 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !27
  %t94 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !27
  %t96 = load i64, ptr %l44, !tbaa !24
  %t97 = mul i64 %t96, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t93, ptr %t95, i64 %t97, i1 false)
  br label %bb18
bb17:
  %t98 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t98, ptr %l5, !tbaa !27
  br label %bb18
bb18:
  br label %bb24
bb19:
  br i1 true, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_15d05b44c0be072a_cdffff4fd774d83e)
  unreachable
bb24:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/emit:fnEm", ptr %t99, i32 0, i32 0
  %t102 = load ptr, ptr %t101, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s3, ptr %s3, ptr %t102, { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d410, i32 0, i32 1) }, { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d411, i32 0, i32 1) })
  br label %bb25
bb25:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = getelementptr %"compiler/emit:fnEm", ptr %t104, i32 0, i32 0
  %t107 = load ptr, ptr %t106, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s3, ptr %s3, ptr %t107, { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d412, i32 0, i32 1) }, { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d413, i32 0, i32 1) })
  br label %bb26
bb26:
  %t109 = load ptr, ptr %l0, !tbaa !29
  store ptr %t109, ptr %l50, !tbaa !29
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t111 = load %"compiler/source:Span", ptr %l1
  %t114 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elocated(ptr %v0, ptr %s3, ptr %s3, ptr %t110, %"compiler/source:Span" %t111, { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d414, i32 0, i32 1) })
  store { i64, ptr } %t114, ptr %l53
  br label %bb27
bb27:
  %t115 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d415, i32 0, i32 1) }, 1
  %t116 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d415, i32 0, i32 1) }, 0
  %t117 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t118 = extractvalue { i64, ptr } %t117, 1
  %t119 = extractvalue { i64, ptr } %t117, 0
  %t120 = add i64 %t116, %t119
  %t121 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d416, i32 0, i32 1) }, 1
  %t122 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d416, i32 0, i32 1) }, 0
  %t123 = add i64 %t120, %t122
  %t124 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t123)
  call void @olang_textcopy(ptr %t124, ptr %t115, i64 %t116)
  %t125 = getelementptr i8, ptr %t124, i64 %t116
  call void @olang_textcopy(ptr %t125, ptr %t118, i64 %t119)
  %t126 = getelementptr i8, ptr %t125, i64 %t119
  call void @olang_textcopy(ptr %t126, ptr %t121, i64 %t122)
  %t127 = insertvalue { i64, ptr } undef, i64 %t123, 0
  %t128 = insertvalue { i64, ptr } %t127, ptr %t124, 1
  %t130 = extractvalue { i64, ptr } %t128, 0
  %t131 = extractvalue { i64, ptr } %t128, 1
  %t132 = mul i64 %t130, 1
  %t133 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t132)
  call void @llvm.memcpy.p0.p0.i64(ptr %t133, ptr %t131, i64 %t132, i1 false)
  %t134 = insertvalue { i64, ptr } undef, i64 %t130, 0
  %t135 = insertvalue { i64, ptr } %t134, ptr %t133, 1
  %t136 = load ptr, ptr %l50, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s3, ptr %t136, { i64, ptr } %t135)
  br label %bb28
bb28:
  %t138 = load ptr, ptr %l0, !tbaa !29
  store ptr %t138, ptr %l56, !tbaa !29
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t141 = getelementptr %"compiler/emit:fnEm", ptr %t139, i32 0, i32 0
  %t142 = load ptr, ptr %t141, !tbaa !29
  %t143 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t146 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecstr(ptr %v0, ptr %s3, ptr %s3, ptr %t142, { i64, ptr } %t143)
  store { i64, ptr } %t146, ptr %l60
  br label %bb29
bb29:
  %t147 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d417, i32 0, i32 1) }, 1
  %t148 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d417, i32 0, i32 1) }, 0
  %t149 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t150 = extractvalue { i64, ptr } %t149, 1
  %t151 = extractvalue { i64, ptr } %t149, 0
  %t152 = add i64 %t148, %t151
  %t153 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d418, i32 0, i32 1) }, 1
  %t154 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d418, i32 0, i32 1) }, 0
  %t155 = add i64 %t152, %t154
  %t156 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t155)
  call void @olang_textcopy(ptr %t156, ptr %t147, i64 %t148)
  %t157 = getelementptr i8, ptr %t156, i64 %t148
  call void @olang_textcopy(ptr %t157, ptr %t150, i64 %t151)
  %t158 = getelementptr i8, ptr %t157, i64 %t151
  call void @olang_textcopy(ptr %t158, ptr %t153, i64 %t154)
  %t159 = insertvalue { i64, ptr } undef, i64 %t155, 0
  %t160 = insertvalue { i64, ptr } %t159, ptr %t156, 1
  %t162 = extractvalue { i64, ptr } %t160, 0
  %t163 = extractvalue { i64, ptr } %t160, 1
  %t164 = mul i64 %t162, 1
  %t165 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t164)
  call void @llvm.memcpy.p0.p0.i64(ptr %t165, ptr %t163, i64 %t164, i1 false)
  %t166 = insertvalue { i64, ptr } undef, i64 %t162, 0
  %t167 = insertvalue { i64, ptr } %t166, ptr %t165, 1
  %t168 = load ptr, ptr %l56, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s3, ptr %t168, { i64, ptr } %t167)
  br label %bb30
bb30:
  %t170 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s3, ptr %t170, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d419, i32 0, i32 1) })
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb32:
  %t172 = load i32, ptr %l2
  %t174 = trunc i64 13 to i32
  %t175 = icmp eq i32 %t172, %t174
  br i1 %t175, label %bb33, label %bb34
bb33:
  store %olang.scope zeroinitializer, ptr %s8
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d420, i32 0, i32 1) }, ptr %l66, !tbaa !27
  %t177 = load { i64, ptr }, ptr %l66, !tbaa !27
  store { i64, ptr } %t177, ptr %l67, !tbaa !27
  %t178 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t179 = extractvalue { i64, ptr } %t178, 0
  store i64 %t179, ptr %l68, !tbaa !24
  %t180 = load i64, ptr %l68, !tbaa !24
  %t181 = mul i64 %t180, 1
  %t182 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t181)
  %t183 = insertvalue { i64, ptr } undef, i64 %t180, 0
  %t184 = insertvalue { i64, ptr } %t183, ptr %t182, 1
  store { i64, ptr } %t184, ptr %l69, !tbaa !27
  %t185 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t186 = load ptr, ptr %t185, !tbaa !27
  %t187 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t188 = load ptr, ptr %t187, !tbaa !27
  %t189 = load i64, ptr %l68, !tbaa !24
  %t190 = mul i64 %t189, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t186, ptr %t188, i64 %t190, i1 false)
  %t191 = load { i64, ptr }, ptr %l69, !tbaa !27
  store { i64, ptr } %t191, ptr %l7, !tbaa !27
  %t192 = load { i64, [4 x i64] }, ptr %l3
  %t194 = extractvalue { i64, [4 x i64] } %t192, 0
  %t195 = icmp eq i64 %t194, 3
  br i1 %t195, label %bb35, label %bb36
bb34:
  br label %bb56
bb35:
  %t197 = getelementptr { i64, [4 x i64] }, ptr %l3, i32 0, i32 1
  %t198 = getelementptr { i32, i32, i64, %"compiler/source:Span" }, ptr %t197, i32 0, i32 1
  %t199 = load i32, ptr %t198
  store i32 %t199, ptr %l8, !tbaa !23
  br label %bb37
bb36:
  br label %bb42
bb37:
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t202 = load i32, ptr %l8, !tbaa !23
  %t205 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2econstText(ptr %v0, ptr %s8, ptr %t201, i32 %t202)
  store { i64, ptr } %t205, ptr %l75
  br label %bb38
bb38:
  %t206 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t207 = extractvalue { i64, ptr } %t206, 0
  %t208 = load { i64, ptr }, ptr %l75, !tbaa !27
  %t209 = extractvalue { i64, ptr } %t208, 0
  store i64 %t209, ptr %l77, !tbaa !24
  %t211 = load i64, ptr %l77, !tbaa !24
  %t212 = icmp eq i64 %t207, %t211
  br i1 %t212, label %bb39, label %bb40
bb39:
  %t214 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t215 = load ptr, ptr %t214, !tbaa !27
  %t216 = getelementptr { i64, ptr }, ptr %l75, i32 0, i32 1
  %t217 = load ptr, ptr %t216, !tbaa !27
  %t218 = load i64, ptr %l77, !tbaa !24
  %t219 = mul i64 %t218, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t215, ptr %t217, i64 %t219, i1 false)
  br label %bb41
bb40:
  %t220 = load { i64, ptr }, ptr %l75, !tbaa !27
  store { i64, ptr } %t220, ptr %l7, !tbaa !27
  br label %bb41
bb41:
  br label %bb47
bb42:
  br i1 true, label %bb43, label %bb44
bb43:
  br label %bb45
bb44:
  br label %bb46
bb45:
  br label %bb47
bb46:
  call void @__olang_check_failed(ptr @olang_loc_7b8962df1e5235eb_6d0c23ccefebcb3f)
  unreachable
bb47:
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t223 = getelementptr %"compiler/emit:fnEm", ptr %t221, i32 0, i32 0
  %t224 = load ptr, ptr %t223, !tbaa !29
  %t226 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2etraced(ptr %v0, ptr %t224)
  store i1 %t226, ptr %l81
  br label %bb48
bb48:
  %t227 = load i1, ptr %l81, !tbaa !21
  br i1 %t227, label %bb49, label %bb50
bb49:
  store { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d421, i32 0, i32 1) }, ptr %l82, !tbaa !27
  br label %bb51
bb50:
  store { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d422, i32 0, i32 1) }, ptr %l82, !tbaa !27
  br label %bb51
bb51:
  %t228 = load { i64, ptr }, ptr %l82, !tbaa !27
  store { i64, ptr } %t228, ptr %l9, !tbaa !27
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t231 = getelementptr %"compiler/emit:fnEm", ptr %t229, i32 0, i32 0
  %t232 = load ptr, ptr %t231, !tbaa !29
  %t233 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t234 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t235 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d423, i32 0, i32 1) }, 1
  %t236 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d423, i32 0, i32 1) }, 0
  %t238 = extractvalue { i64, ptr } %t234, 1
  %t239 = extractvalue { i64, ptr } %t234, 0
  %t240 = add i64 %t236, %t239
  %t241 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d424, i32 0, i32 1) }, 1
  %t242 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d424, i32 0, i32 1) }, 0
  %t243 = add i64 %t240, %t242
  %t244 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t243)
  call void @olang_textcopy(ptr %t244, ptr %t235, i64 %t236)
  %t245 = getelementptr i8, ptr %t244, i64 %t236
  call void @olang_textcopy(ptr %t245, ptr %t238, i64 %t239)
  %t246 = getelementptr i8, ptr %t245, i64 %t239
  call void @olang_textcopy(ptr %t246, ptr %t241, i64 %t242)
  %t247 = insertvalue { i64, ptr } undef, i64 %t243, 0
  %t248 = insertvalue { i64, ptr } %t247, ptr %t244, 1
  %t250 = extractvalue { i64, ptr } %t248, 0
  %t251 = extractvalue { i64, ptr } %t248, 1
  %t252 = mul i64 %t250, 1
  %t253 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t252)
  call void @llvm.memcpy.p0.p0.i64(ptr %t253, ptr %t251, i64 %t252, i1 false)
  %t254 = insertvalue { i64, ptr } undef, i64 %t250, 0
  %t255 = insertvalue { i64, ptr } %t254, ptr %t253, 1
  %t256 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %t256, ptr %s8, ptr %t232, { i64, ptr } %t233, { i64, ptr } %t255)
  br label %bb52
bb52:
  %t260 = load ptr, ptr %l0, !tbaa !29
  store ptr %t260, ptr %l89, !tbaa !29
  %t261 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t261, ptr %l90, !tbaa !27
  %t262 = load ptr, ptr %l0, !tbaa !29
  %t263 = load %"compiler/source:Span", ptr %l1
  %t264 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t265 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d425, i32 0, i32 1) }, 1
  %t266 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d425, i32 0, i32 1) }, 0
  %t268 = extractvalue { i64, ptr } %t264, 1
  %t269 = extractvalue { i64, ptr } %t264, 0
  %t270 = add i64 %t266, %t269
  %t271 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d426, i32 0, i32 1) }, 1
  %t272 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d426, i32 0, i32 1) }, 0
  %t273 = add i64 %t270, %t272
  %t274 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t273)
  call void @olang_textcopy(ptr %t274, ptr %t265, i64 %t266)
  %t275 = getelementptr i8, ptr %t274, i64 %t266
  call void @olang_textcopy(ptr %t275, ptr %t268, i64 %t269)
  %t276 = getelementptr i8, ptr %t275, i64 %t269
  call void @olang_textcopy(ptr %t276, ptr %t271, i64 %t272)
  %t277 = insertvalue { i64, ptr } undef, i64 %t273, 0
  %t278 = insertvalue { i64, ptr } %t277, ptr %t274, 1
  %t280 = extractvalue { i64, ptr } %t278, 0
  %t281 = extractvalue { i64, ptr } %t278, 1
  %t282 = mul i64 %t280, 1
  %t283 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t282)
  call void @llvm.memcpy.p0.p0.i64(ptr %t283, ptr %t281, i64 %t282, i1 false)
  %t284 = insertvalue { i64, ptr } undef, i64 %t280, 0
  %t285 = insertvalue { i64, ptr } %t284, ptr %t283, 1
  %t289 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elocated(ptr %v0, ptr %s8, ptr %s8, ptr %t262, %"compiler/source:Span" %t263, { i64, ptr } %t285)
  store { i64, ptr } %t289, ptr %l96
  br label %bb53
bb53:
  %t290 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d427, i32 0, i32 1) }, 1
  %t291 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d427, i32 0, i32 1) }, 0
  %t292 = load { i64, ptr }, ptr %l90, !tbaa !27
  %t293 = extractvalue { i64, ptr } %t292, 1
  %t294 = extractvalue { i64, ptr } %t292, 0
  %t295 = add i64 %t291, %t294
  %t296 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d428, i32 0, i32 1) }, 1
  %t297 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d428, i32 0, i32 1) }, 0
  %t298 = add i64 %t295, %t297
  %t299 = load { i64, ptr }, ptr %l96, !tbaa !27
  %t300 = extractvalue { i64, ptr } %t299, 1
  %t301 = extractvalue { i64, ptr } %t299, 0
  %t302 = add i64 %t298, %t301
  %t303 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d429, i32 0, i32 1) }, 1
  %t304 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d429, i32 0, i32 1) }, 0
  %t305 = add i64 %t302, %t304
  %t306 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t305)
  call void @olang_textcopy(ptr %t306, ptr %t290, i64 %t291)
  %t307 = getelementptr i8, ptr %t306, i64 %t291
  call void @olang_textcopy(ptr %t307, ptr %t293, i64 %t294)
  %t308 = getelementptr i8, ptr %t307, i64 %t294
  call void @olang_textcopy(ptr %t308, ptr %t296, i64 %t297)
  %t309 = getelementptr i8, ptr %t308, i64 %t297
  call void @olang_textcopy(ptr %t309, ptr %t300, i64 %t301)
  %t310 = getelementptr i8, ptr %t309, i64 %t301
  call void @olang_textcopy(ptr %t310, ptr %t303, i64 %t304)
  %t311 = insertvalue { i64, ptr } undef, i64 %t305, 0
  %t312 = insertvalue { i64, ptr } %t311, ptr %t306, 1
  %t314 = extractvalue { i64, ptr } %t312, 0
  %t315 = extractvalue { i64, ptr } %t312, 1
  %t316 = mul i64 %t314, 1
  %t317 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t316)
  call void @llvm.memcpy.p0.p0.i64(ptr %t317, ptr %t315, i64 %t316, i1 false)
  %t318 = insertvalue { i64, ptr } undef, i64 %t314, 0
  %t319 = insertvalue { i64, ptr } %t318, ptr %t317, 1
  %t320 = load ptr, ptr %l89, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s8, ptr %t320, { i64, ptr } %t319)
  br label %bb54
bb54:
  %t322 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s8, ptr %t322, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d430, i32 0, i32 1) })
  br label %bb55
bb55:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb56:
  %t324 = load { i64, [4 x i64] }, ptr %l3
  %t326 = extractvalue { i64, [4 x i64] } %t324, 0
  %t327 = icmp eq i64 %t326, 0
  br i1 %t327, label %bb57, label %bb58
bb57:
  br label %bb59
bb58:
  br label %bb63
bb59:
  store %olang.scope zeroinitializer, ptr %s14
  %t329 = load ptr, ptr %l0, !tbaa !29
  %t331 = getelementptr %"compiler/emit:fnEm", ptr %t329, i32 0, i32 0
  %t332 = load ptr, ptr %t331, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %s14, ptr %t332, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d431, i32 0, i32 1) })
  br label %bb60
bb60:
  %t334 = load ptr, ptr %l0, !tbaa !29
  store ptr %t334, ptr %l104, !tbaa !29
  %t335 = load ptr, ptr %l0, !tbaa !29
  %t336 = load %"compiler/source:Span", ptr %l1
  %t337 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t338 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d432, i32 0, i32 1) }, 1
  %t339 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d432, i32 0, i32 1) }, 0
  %t341 = extractvalue { i64, ptr } %t337, 1
  %t342 = extractvalue { i64, ptr } %t337, 0
  %t343 = add i64 %t339, %t342
  %t344 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d433, i32 0, i32 1) }, 1
  %t345 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d433, i32 0, i32 1) }, 0
  %t346 = add i64 %t343, %t345
  %t347 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t346)
  call void @olang_textcopy(ptr %t347, ptr %t338, i64 %t339)
  %t348 = getelementptr i8, ptr %t347, i64 %t339
  call void @olang_textcopy(ptr %t348, ptr %t341, i64 %t342)
  %t349 = getelementptr i8, ptr %t348, i64 %t342
  call void @olang_textcopy(ptr %t349, ptr %t344, i64 %t345)
  %t350 = insertvalue { i64, ptr } undef, i64 %t346, 0
  %t351 = insertvalue { i64, ptr } %t350, ptr %t347, 1
  %t353 = extractvalue { i64, ptr } %t351, 0
  %t354 = extractvalue { i64, ptr } %t351, 1
  %t355 = mul i64 %t353, 1
  %t356 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t355)
  call void @llvm.memcpy.p0.p0.i64(ptr %t356, ptr %t354, i64 %t355, i1 false)
  %t357 = insertvalue { i64, ptr } undef, i64 %t353, 0
  %t358 = insertvalue { i64, ptr } %t357, ptr %t356, 1
  %t362 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elocated(ptr %v0, ptr %s14, ptr %s14, ptr %t335, %"compiler/source:Span" %t336, { i64, ptr } %t358)
  store { i64, ptr } %t362, ptr %l110
  br label %bb61
bb61:
  %t363 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d434, i32 0, i32 1) }, 1
  %t364 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d434, i32 0, i32 1) }, 0
  %t365 = load { i64, ptr }, ptr %l110, !tbaa !27
  %t366 = extractvalue { i64, ptr } %t365, 1
  %t367 = extractvalue { i64, ptr } %t365, 0
  %t368 = add i64 %t364, %t367
  %t369 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d435, i32 0, i32 1) }, 1
  %t370 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d435, i32 0, i32 1) }, 0
  %t371 = add i64 %t368, %t370
  %t372 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t371)
  call void @olang_textcopy(ptr %t372, ptr %t363, i64 %t364)
  %t373 = getelementptr i8, ptr %t372, i64 %t364
  call void @olang_textcopy(ptr %t373, ptr %t366, i64 %t367)
  %t374 = getelementptr i8, ptr %t373, i64 %t367
  call void @olang_textcopy(ptr %t374, ptr %t369, i64 %t370)
  %t375 = insertvalue { i64, ptr } undef, i64 %t371, 0
  %t376 = insertvalue { i64, ptr } %t375, ptr %t372, 1
  %t378 = extractvalue { i64, ptr } %t376, 0
  %t379 = extractvalue { i64, ptr } %t376, 1
  %t380 = mul i64 %t378, 1
  %t381 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t380)
  call void @llvm.memcpy.p0.p0.i64(ptr %t381, ptr %t379, i64 %t380, i1 false)
  %t382 = insertvalue { i64, ptr } undef, i64 %t378, 0
  %t383 = insertvalue { i64, ptr } %t382, ptr %t381, 1
  %t384 = load ptr, ptr %l104, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s14, ptr %t384, { i64, ptr } %t383)
  br label %bb62
bb62:
  call void @__olang_scope_close(ptr %s14)
  br label %bb75
bb63:
  br i1 true, label %bb64, label %bb65
bb64:
  br label %bb66
bb65:
  br label %bb74
bb66:
  store %olang.scope zeroinitializer, ptr %s17
  %t386 = load ptr, ptr %l0, !tbaa !29
  %t388 = getelementptr %"compiler/emit:fnEm", ptr %t386, i32 0, i32 0
  %t389 = load ptr, ptr %t388, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %s17, ptr %t389, { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d436, i32 0, i32 1) })
  br label %bb67
bb67:
  %t391 = load ptr, ptr %l0, !tbaa !29
  %t392 = load { i64, [4 x i64] }, ptr %l3
  %t395 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eotype(ptr %v0, ptr %t391, { i64, [4 x i64] } %t392)
  store i32 %t395, ptr %l117
  br label %bb68
bb68:
  %t396 = load i32, ptr %l117, !tbaa !23
  store i32 %t396, ptr %l10, !tbaa !23
  %t397 = load ptr, ptr %l0, !tbaa !29
  %t398 = load { i64, [4 x i64] }, ptr %l3
  %t399 = load i32, ptr %l10, !tbaa !23
  %t403 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s17, ptr %t397, { i64, [4 x i64] } %t398, i32 %t399)
  store { i64, ptr } %t403, ptr %l121
  br label %bb69
bb69:
  %t404 = load { i64, ptr }, ptr %l121, !tbaa !27
  %t405 = load ptr, ptr %l0, !tbaa !29
  %t407 = load i32, ptr %l10, !tbaa !23
  %t411 = call { { i64, ptr }, { i64, ptr } } @compiler_2femit_2ecompiler_2femit_3afnEm_2earrayParts(ptr %v0, ptr %s17, ptr %s17, ptr %t405, { i64, ptr } %t404, i32 %t407)
  store { { i64, ptr }, { i64, ptr } } %t411, ptr %l125
  br label %bb70
bb70:
  %t412 = load { { i64, ptr }, { i64, ptr } }, ptr %l125
  store { { i64, ptr }, { i64, ptr } } %t412, ptr %l12
  %t413 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l12, i32 0, i32 0
  %t414 = load { i64, ptr }, ptr %t413, !tbaa !27
  store { i64, ptr } %t414, ptr %l126, !tbaa !27
  %t415 = load { i64, ptr }, ptr %l126, !tbaa !27
  %t416 = extractvalue { i64, ptr } %t415, 0
  store i64 %t416, ptr %l127, !tbaa !24
  %t417 = load i64, ptr %l127, !tbaa !24
  %t418 = mul i64 %t417, 1
  %t419 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t418)
  %t420 = insertvalue { i64, ptr } undef, i64 %t417, 0
  %t421 = insertvalue { i64, ptr } %t420, ptr %t419, 1
  store { i64, ptr } %t421, ptr %l128, !tbaa !27
  %t422 = getelementptr { i64, ptr }, ptr %l128, i32 0, i32 1
  %t423 = load ptr, ptr %t422, !tbaa !27
  %t424 = getelementptr { i64, ptr }, ptr %l126, i32 0, i32 1
  %t425 = load ptr, ptr %t424, !tbaa !27
  %t426 = load i64, ptr %l127, !tbaa !24
  %t427 = mul i64 %t426, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t423, ptr %t425, i64 %t427, i1 false)
  %t428 = load { i64, ptr }, ptr %l128, !tbaa !27
  %t429 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l12, i32 0, i32 1
  %t430 = load { i64, ptr }, ptr %t429, !tbaa !27
  store { i64, ptr } %t430, ptr %l129, !tbaa !27
  %t431 = load { i64, ptr }, ptr %l129, !tbaa !27
  %t432 = extractvalue { i64, ptr } %t431, 0
  store i64 %t432, ptr %l130, !tbaa !24
  %t433 = load i64, ptr %l130, !tbaa !24
  %t434 = mul i64 %t433, 1
  %t435 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t434)
  %t436 = insertvalue { i64, ptr } undef, i64 %t433, 0
  %t437 = insertvalue { i64, ptr } %t436, ptr %t435, 1
  store { i64, ptr } %t437, ptr %l131, !tbaa !27
  %t438 = getelementptr { i64, ptr }, ptr %l131, i32 0, i32 1
  %t439 = load ptr, ptr %t438, !tbaa !27
  %t440 = getelementptr { i64, ptr }, ptr %l129, i32 0, i32 1
  %t441 = load ptr, ptr %t440, !tbaa !27
  %t442 = load i64, ptr %l130, !tbaa !24
  %t443 = mul i64 %t442, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t439, ptr %t441, i64 %t443, i1 false)
  %t444 = load { i64, ptr }, ptr %l131, !tbaa !27
  %t445 = load ptr, ptr %l0, !tbaa !29
  %t451 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2epair(ptr %v0, ptr %s17, ptr %s17, ptr %s17, ptr %t445, { i64, ptr } %t444, { i64, ptr } %t428)
  store { i64, ptr } %t451, ptr %l135
  br label %bb71
bb71:
  %t452 = load { i64, ptr }, ptr %l135, !tbaa !27
  store { i64, ptr } %t452, ptr %l15, !tbaa !27
  %t453 = load ptr, ptr %l0, !tbaa !29
  store ptr %t453, ptr %l136, !tbaa !29
  %t454 = load ptr, ptr %l0, !tbaa !29
  %t455 = load %"compiler/source:Span", ptr %l1
  %t456 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t457 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d437, i32 0, i32 1) }, 1
  %t458 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d437, i32 0, i32 1) }, 0
  %t460 = extractvalue { i64, ptr } %t456, 1
  %t461 = extractvalue { i64, ptr } %t456, 0
  %t462 = add i64 %t458, %t461
  %t463 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d438, i32 0, i32 1) }, 1
  %t464 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d438, i32 0, i32 1) }, 0
  %t465 = add i64 %t462, %t464
  %t466 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t465)
  call void @olang_textcopy(ptr %t466, ptr %t457, i64 %t458)
  %t467 = getelementptr i8, ptr %t466, i64 %t458
  call void @olang_textcopy(ptr %t467, ptr %t460, i64 %t461)
  %t468 = getelementptr i8, ptr %t467, i64 %t461
  call void @olang_textcopy(ptr %t468, ptr %t463, i64 %t464)
  %t469 = insertvalue { i64, ptr } undef, i64 %t465, 0
  %t470 = insertvalue { i64, ptr } %t469, ptr %t466, 1
  %t472 = extractvalue { i64, ptr } %t470, 0
  %t473 = extractvalue { i64, ptr } %t470, 1
  %t474 = mul i64 %t472, 1
  %t475 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t474)
  call void @llvm.memcpy.p0.p0.i64(ptr %t475, ptr %t473, i64 %t474, i1 false)
  %t476 = insertvalue { i64, ptr } undef, i64 %t472, 0
  %t477 = insertvalue { i64, ptr } %t476, ptr %t475, 1
  %t481 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elocated(ptr %v0, ptr %s17, ptr %s17, ptr %t454, %"compiler/source:Span" %t455, { i64, ptr } %t477)
  store { i64, ptr } %t481, ptr %l142
  br label %bb72
bb72:
  %t482 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t483 = extractvalue { i64, ptr } { i64 41, ptr getelementptr inbounds (<{ i64, [41 x i8] }>, ptr @.d439, i32 0, i32 1) }, 1
  %t484 = extractvalue { i64, ptr } { i64 41, ptr getelementptr inbounds (<{ i64, [41 x i8] }>, ptr @.d439, i32 0, i32 1) }, 0
  %t485 = load { i64, ptr }, ptr %l142, !tbaa !27
  %t486 = extractvalue { i64, ptr } %t485, 1
  %t487 = extractvalue { i64, ptr } %t485, 0
  %t488 = add i64 %t484, %t487
  %t489 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d440, i32 0, i32 1) }, 1
  %t490 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d440, i32 0, i32 1) }, 0
  %t491 = add i64 %t488, %t490
  %t493 = extractvalue { i64, ptr } %t482, 1
  %t494 = extractvalue { i64, ptr } %t482, 0
  %t495 = add i64 %t491, %t494
  %t496 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d441, i32 0, i32 1) }, 1
  %t497 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d441, i32 0, i32 1) }, 0
  %t498 = add i64 %t495, %t497
  %t499 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t498)
  call void @olang_textcopy(ptr %t499, ptr %t483, i64 %t484)
  %t500 = getelementptr i8, ptr %t499, i64 %t484
  call void @olang_textcopy(ptr %t500, ptr %t486, i64 %t487)
  %t501 = getelementptr i8, ptr %t500, i64 %t487
  call void @olang_textcopy(ptr %t501, ptr %t489, i64 %t490)
  %t502 = getelementptr i8, ptr %t501, i64 %t490
  call void @olang_textcopy(ptr %t502, ptr %t493, i64 %t494)
  %t503 = getelementptr i8, ptr %t502, i64 %t494
  call void @olang_textcopy(ptr %t503, ptr %t496, i64 %t497)
  %t504 = insertvalue { i64, ptr } undef, i64 %t498, 0
  %t505 = insertvalue { i64, ptr } %t504, ptr %t499, 1
  %t507 = extractvalue { i64, ptr } %t505, 0
  %t508 = extractvalue { i64, ptr } %t505, 1
  %t509 = mul i64 %t507, 1
  %t510 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t509)
  call void @llvm.memcpy.p0.p0.i64(ptr %t510, ptr %t508, i64 %t509, i1 false)
  %t511 = insertvalue { i64, ptr } undef, i64 %t507, 0
  %t512 = insertvalue { i64, ptr } %t511, ptr %t510, 1
  %t513 = load ptr, ptr %l136, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s17, ptr %t513, { i64, ptr } %t512)
  br label %bb73
bb73:
  call void @__olang_scope_close(ptr %s17)
  br label %bb75
bb74:
  call void @__olang_check_failed(ptr @olang_loc_9d518c27a973a5b0_d4b76855814c5604)
  unreachable
bb75:
  %t515 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s0, ptr %t515, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d442, i32 0, i32 1) })
  br label %bb76
bb76:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3afnEm_2efindDirect(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca %"compiler/mir:BasicBlock"
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca { i64, [21 x i64] }
  %l13 = alloca i32
  %l14 = alloca i64
  %l15 = alloca { i64, [21 x i64] }
  %l16 = alloca { i64, [15 x i64] }
  %l17 = alloca { i64, [1 x i64] }
  %l18 = alloca i1
  %l19 = alloca { i64, [21 x i64] }
  %l20 = alloca i32
  %l21 = alloca i1
  %l25 = alloca i64
  %l27 = alloca i64
  %l32 = alloca %"compiler/mir:BasicBlock"
  %l34 = alloca i64
  %l39 = alloca i64
  %l42 = alloca i64
  %l62 = alloca { i64, [21 x i64] }
  %l63 = alloca { i64, [21 x i64] }
  %l71 = alloca %"compiler/mir:ScopeInfo"
  %l83 = alloca i1
  %l84 = alloca ptr
  %l87 = alloca { i64, [21 x i64] }
  %l90 = alloca i1
  %l100 = alloca { i64, [21 x i64] }
  %l101 = alloca i1
  %l102 = alloca { i64, [21 x i64] }
  %l105 = alloca i1
  %l112 = alloca i1
  %l116 = alloca { i64, [21 x i64] }
  %l117 = alloca i1
  %l118 = alloca { i64, [21 x i64] }
  %l126 = alloca i1
  %s9 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/mir:Fn", ptr %t4, i32 0, i32 9
  store ptr %t6, ptr %l1, !tbaa !29
  store i64 0, ptr %l2, !tbaa !24
  br label %bb1
bb1:
  %t8 = load i64, ptr %l2, !tbaa !24
  store i64 %t8, ptr %l25, !tbaa !24
  %t9 = load ptr, ptr %l1, !tbaa !29
  %t11 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eLen_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, ptr %t9)
  store i64 %t11, ptr %l27
  br label %bb2
bb2:
  %t12 = load i64, ptr %l25, !tbaa !24
  %t13 = load i64, ptr %l27, !tbaa !24
  %t14 = icmp slt i64 %t12, %t13
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb3, label %bb4
bb3:
  br label %bb89
bb4:
  br label %bb5
bb5:
  %t18 = load ptr, ptr %l1, !tbaa !29
  %t19 = load i64, ptr %l2, !tbaa !24
  %t22 = call %"compiler/mir:BasicBlock" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eAt_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, ptr %v0, ptr %t18, i64 %t19)
  store %"compiler/mir:BasicBlock" %t22, ptr %l32
  br label %bb6
bb6:
  %t23 = load %"compiler/mir:BasicBlock", ptr %l32
  store %"compiler/mir:BasicBlock" %t23, ptr %l3
  %t24 = getelementptr %"compiler/mir:BasicBlock", ptr %l3, i32 0, i32 0
  %t26 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aStmt_3e_2eLen_3ccompiler_2fmir_3aStmt_3e(ptr %v0, ptr %t24)
  store i64 %t26, ptr %l34
  br label %bb7
bb7:
  %t27 = load i64, ptr %l34, !tbaa !24
  store i64 %t27, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  %t28 = load i64, ptr %l4, !tbaa !24
  store i64 %t28, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t30 = load i64, ptr %l6, !tbaa !24
  %t31 = load i64, ptr %l5, !tbaa !24
  %t34 = icmp sgt i64 %t30, %t31
  br i1 %t34, label %bb8, label %bb9
bb8:
  %t36 = load i64, ptr %l7, !tbaa !24
  %t38 = icmp sgt i64 %t36, 0
  br i1 %t38, label %bb10, label %bb11
bb9:
  store i64 0, ptr %l39, !tbaa !24
  br label %bb13
bb10:
  %t40 = load i64, ptr %l6, !tbaa !24
  %t41 = load i64, ptr %l5, !tbaa !24
  %t44 = sub i64 %t40, %t41
  %t45 = load i64, ptr %l7, !tbaa !24
  %t48 = add i64 %t44, %t45
  %t50 = sub i64 %t48, 1
  %t51 = load i64, ptr %l7, !tbaa !24
  %t54 = sdiv i64 %t50, %t51
  store i64 %t54, ptr %l42, !tbaa !24
  br label %bb12
bb11:
  store i64 0, ptr %l42, !tbaa !24
  br label %bb12
bb12:
  %t56 = load i64, ptr %l42, !tbaa !24
  store i64 %t56, ptr %l39, !tbaa !24
  br label %bb13
bb13:
  %t57 = load i64, ptr %l39, !tbaa !24
  store i64 %t57, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb14
bb14:
  %t58 = load i64, ptr %l9, !tbaa !24
  %t59 = load i64, ptr %l8, !tbaa !24
  %t62 = icmp slt i64 %t58, %t59
  %t64 = xor i1 %t62, true
  br i1 %t64, label %bb15, label %bb16
bb15:
  br label %bb87
bb16:
  br label %bb17
bb17:
  %t66 = load i64, ptr %l5, !tbaa !24
  %t67 = load i64, ptr %l9, !tbaa !24
  %t68 = load i64, ptr %l7, !tbaa !24
  %t71 = mul i64 %t67, %t68
  %t74 = add i64 %t66, %t71
  store i64 %t74, ptr %l10, !tbaa !24
  store i64 -1, ptr %l11, !tbaa !24
  %t76 = getelementptr %"compiler/mir:BasicBlock", ptr %l3, i32 0, i32 0
  %t77 = load i64, ptr %l10, !tbaa !24
  %t80 = call { i64, [21 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aStmt_3e_2eAt_3ccompiler_2fmir_3aStmt_3e(ptr %v0, ptr %t76, i64 %t77)
  store { i64, [21 x i64] } %t80, ptr %l62
  br label %bb18
bb18:
  call void @llvm.memmove.p0.p0.i64(ptr %l12, ptr %l62, i64 176, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l63, ptr %l12, i64 176, i1 false)
  %t81 = load { i64, [21 x i64] }, ptr %l63
  %t82 = extractvalue { i64, [21 x i64] } %t81, 0
  %t83 = icmp eq i64 %t82, 3
  br i1 %t83, label %bb19, label %bb20
bb19:
  %t85 = getelementptr { i64, [21 x i64] }, ptr %l12, i32 0, i32 1
  %t86 = getelementptr { %"compiler/source:Span", i32 }, ptr %t85, i32 0, i32 1
  %t87 = load i32, ptr %t86
  store i32 %t87, ptr %l13, !tbaa !23
  br label %bb21
bb20:
  br label %bb26
bb21:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"compiler/emit:fnEm", ptr %t89, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !29
  %t94 = getelementptr %"compiler/mir:Fn", ptr %t92, i32 0, i32 8
  %t95 = load i32, ptr %l13, !tbaa !23
  %t97 = sext i32 %t95 to i64
  %t100 = call %"compiler/mir:ScopeInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeInfo_3e_2eAt_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %t94, i64 %t97)
  store %"compiler/mir:ScopeInfo" %t100, ptr %l71
  br label %bb22
bb22:
  %t101 = getelementptr %"compiler/mir:ScopeInfo", ptr %l71, i32 0, i32 0
  %t102 = load i32, ptr %t101
  %t104 = trunc i64 6 to i32
  %t105 = icmp eq i32 %t102, %t104
  br i1 %t105, label %bb23, label %bb24
bb23:
  %t107 = load i32, ptr %l13, !tbaa !23
  %t109 = sext i32 %t107 to i64
  store i64 %t109, ptr %l11, !tbaa !24
  br label %bb25
bb24:
  br label %bb25
bb25:
  br label %bb31
bb26:
  br i1 true, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb31
bb30:
  call void @__olang_check_failed(ptr @olang_loc_8a0f087481b95ab0_a13f080fe7b316d4)
  unreachable
bb31:
  %t111 = load i64, ptr %l11, !tbaa !24
  %t113 = icmp slt i64 %t111, 0
  br i1 %t113, label %bb32, label %bb33
bb32:
  br label %bb86
bb33:
  br label %bb34
bb34:
  %t115 = load i64, ptr %l10, !tbaa !24
  %t117 = add i64 %t115, 1
  store i64 %t117, ptr %l14, !tbaa !24
  br label %bb35
bb35:
  store %olang.scope zeroinitializer, ptr %s9
  %t119 = load i64, ptr %l14, !tbaa !24
  %t120 = load i64, ptr %l4, !tbaa !24
  %t123 = icmp slt i64 %t119, %t120
  br i1 %t123, label %bb36, label %bb37
bb36:
  %t125 = load ptr, ptr %l0, !tbaa !29
  store ptr %t125, ptr %l84, !tbaa !29
  %t126 = getelementptr %"compiler/mir:BasicBlock", ptr %l3, i32 0, i32 0
  %t127 = load i64, ptr %l14, !tbaa !24
  %t130 = call { i64, [21 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aStmt_3e_2eAt_3ccompiler_2fmir_3aStmt_3e(ptr %v0, ptr %t126, i64 %t127)
  store { i64, [21 x i64] } %t130, ptr %l87
  br label %bb38
bb37:
  store i1 false, ptr %l83, !tbaa !21
  br label %bb40
bb38:
  %t131 = load { i64, [21 x i64] }, ptr %l87
  %t132 = call ptr @__olang_scope_alloc_a(ptr %s9, i64 176, i64 8)
  store { i64, [21 x i64] } %t131, ptr %t132
  %t133 = load i64, ptr %l11, !tbaa !24
  %t134 = load ptr, ptr %l84, !tbaa !29
  %t137 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2eplainWrite(ptr %v0, ptr %s9, ptr %t134, ptr %t132, i64 %t133)
  store i1 %t137, ptr %l90
  br label %bb39
bb39:
  %t138 = load i1, ptr %l90, !tbaa !21
  store i1 %t138, ptr %l83, !tbaa !21
  br label %bb40
bb40:
  %t139 = load i1, ptr %l83, !tbaa !21
  %t140 = xor i1 %t139, true
  br i1 %t140, label %bb41, label %bb42
bb41:
  call void @__olang_scope_close(ptr %s9)
  br label %bb45
bb42:
  br label %bb43
bb43:
  %t142 = load i64, ptr %l14, !tbaa !24
  %t144 = add i64 %t142, 1
  store i64 %t144, ptr %l14, !tbaa !24
  call void @__olang_scope_close(ptr %s9)
  br label %bb44
bb44:
  br label %bb35
bb45:
  %t146 = load i64, ptr %l14, !tbaa !24
  %t148 = add i64 %t146, 1
  %t149 = load i64, ptr %l4, !tbaa !24
  %t152 = icmp sge i64 %t148, %t149
  br i1 %t152, label %bb46, label %bb47
bb46:
  br label %bb86
bb47:
  br label %bb48
bb48:
  %t154 = getelementptr %"compiler/mir:BasicBlock", ptr %l3, i32 0, i32 0
  %t155 = load i64, ptr %l14, !tbaa !24
  %t158 = call { i64, [21 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aStmt_3e_2eAt_3ccompiler_2fmir_3aStmt_3e(ptr %v0, ptr %t154, i64 %t155)
  store { i64, [21 x i64] } %t158, ptr %l100
  br label %bb49
bb49:
  call void @llvm.memmove.p0.p0.i64(ptr %l15, ptr %l100, i64 176, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l102, ptr %l15, i64 176, i1 false)
  %t159 = load { i64, [21 x i64] }, ptr %l102
  %t160 = extractvalue { i64, [21 x i64] } %t159, 0
  %t161 = icmp eq i64 %t160, 0
  br i1 %t161, label %bb50, label %bb51
bb50:
  %t163 = getelementptr { i64, [21 x i64] }, ptr %l15, i32 0, i32 1
  %t164 = getelementptr { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } }, ptr %t163, i32 0, i32 2
  %t165 = load { i64, [15 x i64] }, ptr %t164
  store { i64, [15 x i64] } %t165, ptr %l16
  br label %bb52
bb51:
  br label %bb63
bb52:
  %t167 = load { i64, [15 x i64] }, ptr %l16
  %t169 = extractvalue { i64, [15 x i64] } %t167, 0
  %t170 = icmp eq i64 %t169, 12
  br i1 %t170, label %bb53, label %bb54
bb53:
  %t172 = getelementptr { i64, [15 x i64] }, ptr %l16, i32 0, i32 1
  %t173 = getelementptr { { i64, [1 x i64] }, { i64, [1 x i64] }, i32 }, ptr %t172, i32 0, i32 0
  %t174 = load { i64, [1 x i64] }, ptr %t173
  store { i64, [1 x i64] } %t174, ptr %l17
  br label %bb55
bb54:
  br label %bb57
bb55:
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t177 = load { i64, [1 x i64] }, ptr %l17
  %t178 = load i64, ptr %l11, !tbaa !24
  %t182 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2erefIs(ptr %v0, ptr %t176, { i64, [1 x i64] } %t177, i64 %t178)
  store i1 %t182, ptr %l112
  br label %bb56
bb56:
  %t183 = load i1, ptr %l112, !tbaa !21
  store i1 %t183, ptr %l105, !tbaa !21
  br label %bb62
bb57:
  br i1 true, label %bb58, label %bb59
bb58:
  br label %bb60
bb59:
  br label %bb61
bb60:
  store i1 false, ptr %l105, !tbaa !21
  br label %bb62
bb61:
  call void @__olang_check_failed(ptr @olang_loc_9d64128d60439a41_20f9e6973a71ad85)
  unreachable
bb62:
  %t184 = load i1, ptr %l105, !tbaa !21
  store i1 %t184, ptr %l101, !tbaa !21
  br label %bb68
bb63:
  br i1 true, label %bb64, label %bb65
bb64:
  br label %bb66
bb65:
  br label %bb67
bb66:
  store i1 false, ptr %l101, !tbaa !21
  br label %bb68
bb67:
  call void @__olang_check_failed(ptr @olang_loc_28dd7919903bc2a_4577237eccb57ce)
  unreachable
bb68:
  %t185 = load i1, ptr %l101, !tbaa !21
  store i1 %t185, ptr %l18, !tbaa !21
  %t186 = getelementptr %"compiler/mir:BasicBlock", ptr %l3, i32 0, i32 0
  %t187 = load i64, ptr %l14, !tbaa !24
  %t189 = add i64 %t187, 1
  %t192 = call { i64, [21 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aStmt_3e_2eAt_3ccompiler_2fmir_3aStmt_3e(ptr %v0, ptr %t186, i64 %t189)
  store { i64, [21 x i64] } %t192, ptr %l116
  br label %bb69
bb69:
  call void @llvm.memmove.p0.p0.i64(ptr %l19, ptr %l116, i64 176, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l118, ptr %l19, i64 176, i1 false)
  %t193 = load { i64, [21 x i64] }, ptr %l118
  %t194 = extractvalue { i64, [21 x i64] } %t193, 0
  %t195 = icmp eq i64 %t194, 4
  br i1 %t195, label %bb70, label %bb71
bb70:
  %t197 = getelementptr { i64, [21 x i64] }, ptr %l19, i32 0, i32 1
  %t198 = getelementptr { %"compiler/source:Span", i32 }, ptr %t197, i32 0, i32 1
  %t199 = load i32, ptr %t198
  store i32 %t199, ptr %l20, !tbaa !23
  br label %bb72
bb71:
  br label %bb73
bb72:
  %t201 = load i32, ptr %l20, !tbaa !23
  %t203 = sext i32 %t201 to i64
  %t204 = load i64, ptr %l11, !tbaa !24
  %t207 = icmp eq i64 %t203, %t204
  store i1 %t207, ptr %l117, !tbaa !21
  br label %bb78
bb73:
  br i1 true, label %bb74, label %bb75
bb74:
  br label %bb76
bb75:
  br label %bb77
bb76:
  store i1 false, ptr %l117, !tbaa !21
  br label %bb78
bb77:
  call void @__olang_check_failed(ptr @olang_loc_6846df2bf697eaeb_3c0ad43c6c9a3c0f)
  unreachable
bb78:
  %t209 = load i1, ptr %l117, !tbaa !21
  store i1 %t209, ptr %l21, !tbaa !21
  %t210 = load i1, ptr %l18, !tbaa !21
  br i1 %t210, label %bb79, label %bb80
bb79:
  %t212 = load i1, ptr %l21, !tbaa !21
  store i1 %t212, ptr %l126, !tbaa !21
  br label %bb81
bb80:
  store i1 false, ptr %l126, !tbaa !21
  br label %bb81
bb81:
  %t214 = load i1, ptr %l126, !tbaa !21
  br i1 %t214, label %bb82, label %bb83
bb82:
  %t215 = load ptr, ptr %l0, !tbaa !29
  %t217 = getelementptr %"compiler/emit:fnEm", ptr %t215, i32 0, i32 23
  %t218 = load i64, ptr %l11, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t217, i64 %t218, i1 true)
  br label %bb84
bb83:
  br label %bb85
bb84:
  br label %bb85
bb85:
  br label %bb86
bb86:
  %t221 = load i64, ptr %l9, !tbaa !24
  %t223 = add i64 %t221, 1
  store i64 %t223, ptr %l9, !tbaa !24
  br label %bb14
bb87:
  br label %bb88
bb88:
  %t225 = load i64, ptr %l2, !tbaa !24
  %t227 = add i64 %t225, 1
  store i64 %t227, ptr %l2, !tbaa !24
  br label %bb1
bb89:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eindex(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca i32
  %l11 = alloca i32
  %l14 = alloca i64
  %l20 = alloca i64
  %l22 = alloca ptr
  %l25 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l32 = alloca i1
  %l33 = alloca { i64, ptr }
  %l34 = alloca ptr
  %l35 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l42 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/emit:Emitter", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l3, !tbaa !29
  %t9 = load ptr, ptr %l3, !tbaa !29
  %t13 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t9, i32 %a2)
  store i32 %t13, ptr %l11
  br label %bb1
bb1:
  %t14 = load i32, ptr %l11, !tbaa !23
  store i32 %t14, ptr %l4, !tbaa !23
  %t15 = load ptr, ptr %l3, !tbaa !29
  %t16 = load i32, ptr %l4, !tbaa !23
  %t19 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %t15, i32 %t16)
  store i64 %t19, ptr %l14
  br label %bb2
bb2:
  %t20 = load i64, ptr %l14, !tbaa !24
  %t21 = icmp eq i64 %t20, 64
  br i1 %t21, label %bb3, label %bb4
bb3:
  %t23 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t23, 1
  %t26 = extractvalue { i64, ptr } %t23, 0
  %t27 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t26)
  call void @olang_textcopy(ptr %t27, ptr %t25, i64 %t26)
  %t28 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t27, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t29, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t31 = load ptr, ptr %l3, !tbaa !29
  %t32 = load i32, ptr %l4, !tbaa !23
  %t35 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %t31, i32 %t32)
  store i64 %t35, ptr %l20
  br label %bb6
bb6:
  %t36 = load i64, ptr %l20, !tbaa !24
  %t37 = icmp sgt i64 %t36, 64
  br i1 %t37, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s3
  %t39 = load ptr, ptr %l0, !tbaa !29
  store ptr %t39, ptr %l22, !tbaa !29
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load i32, ptr %l4, !tbaa !23
  %t44 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s3, ptr %t40, i32 %t41)
  store { i64, ptr } %t44, ptr %l25
  br label %bb9
bb8:
  br label %bb11
bb9:
  %t45 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t46 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d443, i32 0, i32 1) }, 1
  %t47 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d443, i32 0, i32 1) }, 0
  %t48 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t48, 1
  %t50 = extractvalue { i64, ptr } %t48, 0
  %t51 = add i64 %t47, %t50
  %t52 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d444, i32 0, i32 1) }, 1
  %t53 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d444, i32 0, i32 1) }, 0
  %t54 = add i64 %t51, %t53
  %t56 = extractvalue { i64, ptr } %t45, 1
  %t57 = extractvalue { i64, ptr } %t45, 0
  %t58 = add i64 %t54, %t57
  %t59 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d445, i32 0, i32 1) }, 1
  %t60 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d445, i32 0, i32 1) }, 0
  %t61 = add i64 %t58, %t60
  %t62 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t61)
  call void @olang_textcopy(ptr %t62, ptr %t46, i64 %t47)
  %t63 = getelementptr i8, ptr %t62, i64 %t47
  call void @olang_textcopy(ptr %t63, ptr %t49, i64 %t50)
  %t64 = getelementptr i8, ptr %t63, i64 %t50
  call void @olang_textcopy(ptr %t64, ptr %t52, i64 %t53)
  %t65 = getelementptr i8, ptr %t64, i64 %t53
  call void @olang_textcopy(ptr %t65, ptr %t56, i64 %t57)
  %t66 = getelementptr i8, ptr %t65, i64 %t57
  call void @olang_textcopy(ptr %t66, ptr %t59, i64 %t60)
  %t67 = insertvalue { i64, ptr } undef, i64 %t61, 0
  %t68 = insertvalue { i64, ptr } %t67, ptr %t62, 1
  %t70 = extractvalue { i64, ptr } %t68, 0
  %t71 = extractvalue { i64, ptr } %t68, 1
  %t72 = mul i64 %t70, 1
  %t73 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t72)
  call void @llvm.memcpy.p0.p0.i64(ptr %t73, ptr %t71, i64 %t72, i1 false)
  %t74 = insertvalue { i64, ptr } undef, i64 %t70, 0
  %t75 = insertvalue { i64, ptr } %t74, ptr %t73, 1
  %t76 = load ptr, ptr %l22, !tbaa !29
  %t78 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v2, ptr %v2, ptr %t76, { i64, ptr } %t75)
  store { i64, ptr } %t78, ptr %l29
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t79 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t79, ptr %rv
  br label %ret
bb11:
  %t80 = load ptr, ptr %l3, !tbaa !29
  %t81 = load i32, ptr %l4, !tbaa !23
  %t84 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %t80, i32 %t81)
  store i1 %t84, ptr %l32
  br label %bb12
bb12:
  %t85 = load i1, ptr %l32, !tbaa !21
  br i1 %t85, label %bb13, label %bb14
bb13:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d446, i32 0, i32 1) }, ptr %l33, !tbaa !27
  br label %bb15
bb14:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d447, i32 0, i32 1) }, ptr %l33, !tbaa !27
  br label %bb15
bb15:
  %t86 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t87 = load ptr, ptr %l0, !tbaa !29
  store ptr %t87, ptr %l34, !tbaa !29
  store { i64, ptr } %t86, ptr %l35, !tbaa !27
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t90 = load i32, ptr %l4, !tbaa !23
  %t93 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s0, ptr %t89, i32 %t90)
  store { i64, ptr } %t93, ptr %l38
  br label %bb16
bb16:
  %t94 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t95 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t96 = extractvalue { i64, ptr } %t95, 1
  %t97 = extractvalue { i64, ptr } %t95, 0
  %t98 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d448, i32 0, i32 1) }, 1
  %t99 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d448, i32 0, i32 1) }, 0
  %t100 = add i64 %t97, %t99
  %t101 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t102 = extractvalue { i64, ptr } %t101, 1
  %t103 = extractvalue { i64, ptr } %t101, 0
  %t104 = add i64 %t100, %t103
  %t105 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d448, i32 0, i32 1) }, 1
  %t106 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d448, i32 0, i32 1) }, 0
  %t107 = add i64 %t104, %t106
  %t109 = extractvalue { i64, ptr } %t94, 1
  %t110 = extractvalue { i64, ptr } %t94, 0
  %t111 = add i64 %t107, %t110
  %t112 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d449, i32 0, i32 1) }, 1
  %t113 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d449, i32 0, i32 1) }, 0
  %t114 = add i64 %t111, %t113
  %t115 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t114)
  call void @olang_textcopy(ptr %t115, ptr %t96, i64 %t97)
  %t116 = getelementptr i8, ptr %t115, i64 %t97
  call void @olang_textcopy(ptr %t116, ptr %t98, i64 %t99)
  %t117 = getelementptr i8, ptr %t116, i64 %t99
  call void @olang_textcopy(ptr %t117, ptr %t102, i64 %t103)
  %t118 = getelementptr i8, ptr %t117, i64 %t103
  call void @olang_textcopy(ptr %t118, ptr %t105, i64 %t106)
  %t119 = getelementptr i8, ptr %t118, i64 %t106
  call void @olang_textcopy(ptr %t119, ptr %t109, i64 %t110)
  %t120 = getelementptr i8, ptr %t119, i64 %t110
  call void @olang_textcopy(ptr %t120, ptr %t112, i64 %t113)
  %t121 = insertvalue { i64, ptr } undef, i64 %t114, 0
  %t122 = insertvalue { i64, ptr } %t121, ptr %t115, 1
  %t124 = extractvalue { i64, ptr } %t122, 0
  %t125 = extractvalue { i64, ptr } %t122, 1
  %t126 = mul i64 %t124, 1
  %t127 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t126)
  call void @llvm.memcpy.p0.p0.i64(ptr %t127, ptr %t125, i64 %t126, i1 false)
  %t128 = insertvalue { i64, ptr } undef, i64 %t124, 0
  %t129 = insertvalue { i64, ptr } %t128, ptr %t127, 1
  %t130 = load ptr, ptr %l34, !tbaa !29
  %t132 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v2, ptr %v2, ptr %t130, { i64, ptr } %t129)
  store { i64, ptr } %t132, ptr %l42
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s0)
  %t133 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t133, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2epair(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d450, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d450, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %a1, 1
  %t7 = extractvalue { i64, ptr } %a1, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d451, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d451, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t12 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t11)
  call void @olang_textcopy(ptr %t12, ptr %t3, i64 %t4)
  %t13 = getelementptr i8, ptr %t12, i64 %t4
  call void @olang_textcopy(ptr %t13, ptr %t6, i64 %t7)
  %t14 = getelementptr i8, ptr %t13, i64 %t7
  call void @olang_textcopy(ptr %t14, ptr %t9, i64 %t10)
  %t15 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr %t12, 1
  %t18 = extractvalue { i64, ptr } %t16, 0
  %t19 = extractvalue { i64, ptr } %t16, 1
  %t20 = mul i64 %t18, 1
  %t21 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t20)
  call void @llvm.memcpy.p0.p0.i64(ptr %t21, ptr %t19, i64 %t20, i1 false)
  %t22 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t21, 1
  %t26 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t1, { i64, ptr } %t23)
  store { i64, ptr } %t26, ptr %l8
  br label %bb1
bb1:
  %t27 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t31 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d452, i32 0, i32 1) }, 1
  %t32 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d452, i32 0, i32 1) }, 0
  %t34 = extractvalue { i64, ptr } %t27, 1
  %t35 = extractvalue { i64, ptr } %t27, 0
  %t36 = add i64 %t32, %t35
  %t37 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d453, i32 0, i32 1) }, 1
  %t38 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d453, i32 0, i32 1) }, 0
  %t39 = add i64 %t36, %t38
  %t41 = extractvalue { i64, ptr } %a2, 1
  %t42 = extractvalue { i64, ptr } %a2, 0
  %t43 = add i64 %t39, %t42
  %t44 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d454, i32 0, i32 1) }, 1
  %t45 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d454, i32 0, i32 1) }, 0
  %t46 = add i64 %t43, %t45
  %t47 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t46)
  call void @olang_textcopy(ptr %t47, ptr %t31, i64 %t32)
  %t48 = getelementptr i8, ptr %t47, i64 %t32
  call void @olang_textcopy(ptr %t48, ptr %t34, i64 %t35)
  %t49 = getelementptr i8, ptr %t48, i64 %t35
  call void @olang_textcopy(ptr %t49, ptr %t37, i64 %t38)
  %t50 = getelementptr i8, ptr %t49, i64 %t38
  call void @olang_textcopy(ptr %t50, ptr %t41, i64 %t42)
  %t51 = getelementptr i8, ptr %t50, i64 %t42
  call void @olang_textcopy(ptr %t51, ptr %t44, i64 %t45)
  %t52 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t53 = insertvalue { i64, ptr } %t52, ptr %t47, 1
  %t55 = extractvalue { i64, ptr } %t53, 0
  %t56 = extractvalue { i64, ptr } %t53, 1
  %t57 = mul i64 %t55, 1
  %t58 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t57)
  call void @llvm.memcpy.p0.p0.i64(ptr %t58, ptr %t56, i64 %t57, i1 false)
  %t59 = insertvalue { i64, ptr } undef, i64 %t55, 0
  %t60 = insertvalue { i64, ptr } %t59, ptr %t58, 1
  %t63 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v3, ptr %v3, ptr %t28, { i64, ptr } %t60)
  store { i64, ptr } %t63, ptr %l14
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  %t64 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t64, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eparts(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, { i64, ptr } %a2, %"compiler/mir:Range" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %lp5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca { i64, ptr }
  %l25 = alloca i64
  %l28 = alloca i64
  %l46 = alloca ptr
  %l50 = alloca { i64, [4 x i64] }
  %l51 = alloca { i64, ptr }
  %l54 = alloca { i64, ptr }
  %l55 = alloca ptr
  %l56 = alloca { i64, ptr }
  %l57 = alloca { i64, ptr }
  %l59 = alloca { i64, ptr }
  %l62 = alloca { i64, ptr }
  %l67 = alloca { i64, ptr }
  %l69 = alloca i64
  %l76 = alloca { i64, ptr }
  %l77 = alloca { i64, ptr }
  %l78 = alloca i64
  %l79 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s0, ptr %t1, i32 %a1)
  store { i64, ptr } %t5, ptr %l15
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t6, ptr %l4, !tbaa !27
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d455, i32 0, i32 1) }, ptr %l16, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t7, ptr %l17, !tbaa !27
  %t8 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t8, 0
  store i64 %t9, ptr %l18, !tbaa !24
  %t10 = load i64, ptr %l18, !tbaa !24
  %t11 = mul i64 %t10, 1
  %t12 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t11)
  %t13 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l19, !tbaa !27
  %t15 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !27
  %t17 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !27
  %t19 = load i64, ptr %l18, !tbaa !24
  %t20 = mul i64 %t19, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t16, ptr %t18, i64 %t20, i1 false)
  %t21 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t21, ptr %lp5
  %t22 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t23 = load ptr, ptr %lp5
  store { i64, ptr } %t22, ptr %t23, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t24 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  store i64 %t26, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t28 = load i64, ptr %l7, !tbaa !24
  %t29 = load i64, ptr %l6, !tbaa !24
  %t32 = icmp sgt i64 %t28, %t29
  br i1 %t32, label %bb2, label %bb3
bb2:
  %t34 = load i64, ptr %l8, !tbaa !24
  %t36 = icmp sgt i64 %t34, 0
  br i1 %t36, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l25, !tbaa !24
  br label %bb7
bb4:
  %t38 = load i64, ptr %l7, !tbaa !24
  %t39 = load i64, ptr %l6, !tbaa !24
  %t42 = sub i64 %t38, %t39
  %t43 = load i64, ptr %l8, !tbaa !24
  %t46 = add i64 %t42, %t43
  %t48 = sub i64 %t46, 1
  %t49 = load i64, ptr %l8, !tbaa !24
  %t52 = sdiv i64 %t48, %t49
  store i64 %t52, ptr %l28, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb6
bb6:
  %t54 = load i64, ptr %l28, !tbaa !24
  store i64 %t54, ptr %l25, !tbaa !24
  br label %bb7
bb7:
  %t55 = load i64, ptr %l25, !tbaa !24
  store i64 %t55, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t56 = load i64, ptr %l10, !tbaa !24
  %t57 = load i64, ptr %l9, !tbaa !24
  %t60 = icmp slt i64 %t56, %t57
  %t62 = xor i1 %t60, true
  br i1 %t62, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb20
bb10:
  br label %bb11
bb11:
  %t64 = load i64, ptr %l6, !tbaa !24
  %t65 = load i64, ptr %l10, !tbaa !24
  %t66 = load i64, ptr %l8, !tbaa !24
  %t69 = mul i64 %t65, %t66
  %t72 = add i64 %t64, %t69
  store i64 %t72, ptr %l11, !tbaa !24
  %t74 = load ptr, ptr %l0, !tbaa !29
  store ptr %t74, ptr %l46, !tbaa !29
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = load i64, ptr %l11, !tbaa !24
  %t81 = call { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %t75, %"compiler/mir:Range" %a3, i64 %t77)
  store { i64, [4 x i64] } %t81, ptr %l50
  br label %bb12
bb12:
  %t82 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t82, ptr %l51, !tbaa !27
  %t83 = load i64, ptr %l11, !tbaa !24
  %t85 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !27
  %t87 = getelementptr i32, ptr %t86, i64 %t83
  %t88 = load i32, ptr %t87, !tbaa !33
  %t89 = load ptr, ptr %l46, !tbaa !29
  %t90 = load { i64, [4 x i64] }, ptr %l50
  %t92 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s2, ptr %t89, { i64, [4 x i64] } %t90, i32 %t88)
  store { i64, ptr } %t92, ptr %l54
  br label %bb13
bb13:
  %t93 = load { i64, ptr }, ptr %l54, !tbaa !27
  store { i64, ptr } %t93, ptr %l12, !tbaa !27
  %t94 = load ptr, ptr %l0, !tbaa !29
  store ptr %t94, ptr %l55, !tbaa !29
  %t95 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t95, ptr %l56, !tbaa !27
  %t96 = load ptr, ptr %lp5
  %t97 = load { i64, ptr }, ptr %t96, !tbaa !27
  store { i64, ptr } %t97, ptr %l57, !tbaa !27
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t99 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t99, ptr %l59, !tbaa !27
  %t100 = load i64, ptr %l11, !tbaa !24
  %t102 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t103 = load ptr, ptr %t102, !tbaa !27
  %t104 = getelementptr i32, ptr %t103, i64 %t100
  %t105 = load i32, ptr %t104, !tbaa !33
  %t108 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s2, ptr %t98, i32 %t105)
  store { i64, ptr } %t108, ptr %l62
  br label %bb14
bb14:
  %t109 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t110 = load i64, ptr %l11, !tbaa !24
  %t111 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d456, i32 0, i32 1) }, 1
  %t112 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d456, i32 0, i32 1) }, 0
  %t113 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t113, 1
  %t115 = extractvalue { i64, ptr } %t113, 0
  %t116 = add i64 %t112, %t115
  %t117 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d457, i32 0, i32 1) }, 1
  %t118 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d457, i32 0, i32 1) }, 0
  %t119 = add i64 %t116, %t118
  %t120 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t121 = extractvalue { i64, ptr } %t120, 1
  %t122 = extractvalue { i64, ptr } %t120, 0
  %t123 = add i64 %t119, %t122
  %t124 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d458, i32 0, i32 1) }, 1
  %t125 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d458, i32 0, i32 1) }, 0
  %t126 = add i64 %t123, %t125
  %t127 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t128 = extractvalue { i64, ptr } %t127, 1
  %t129 = extractvalue { i64, ptr } %t127, 0
  %t130 = add i64 %t126, %t129
  %t131 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d457, i32 0, i32 1) }, 1
  %t132 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d457, i32 0, i32 1) }, 0
  %t133 = add i64 %t130, %t132
  %t135 = extractvalue { i64, ptr } %t109, 1
  %t136 = extractvalue { i64, ptr } %t109, 0
  %t137 = add i64 %t133, %t136
  %t138 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d458, i32 0, i32 1) }, 1
  %t139 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d458, i32 0, i32 1) }, 0
  %t140 = add i64 %t137, %t139
  %t142 = call i64 @__olang_fmt_i64(ptr null, i64 %t110)
  %t143 = add i64 %t140, %t142
  %t144 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t143)
  call void @olang_textcopy(ptr %t144, ptr %t111, i64 %t112)
  %t145 = getelementptr i8, ptr %t144, i64 %t112
  call void @olang_textcopy(ptr %t145, ptr %t114, i64 %t115)
  %t146 = getelementptr i8, ptr %t145, i64 %t115
  call void @olang_textcopy(ptr %t146, ptr %t117, i64 %t118)
  %t147 = getelementptr i8, ptr %t146, i64 %t118
  call void @olang_textcopy(ptr %t147, ptr %t121, i64 %t122)
  %t148 = getelementptr i8, ptr %t147, i64 %t122
  call void @olang_textcopy(ptr %t148, ptr %t124, i64 %t125)
  %t149 = getelementptr i8, ptr %t148, i64 %t125
  call void @olang_textcopy(ptr %t149, ptr %t128, i64 %t129)
  %t150 = getelementptr i8, ptr %t149, i64 %t129
  call void @olang_textcopy(ptr %t150, ptr %t131, i64 %t132)
  %t151 = getelementptr i8, ptr %t150, i64 %t132
  call void @olang_textcopy(ptr %t151, ptr %t135, i64 %t136)
  %t152 = getelementptr i8, ptr %t151, i64 %t136
  call void @olang_textcopy(ptr %t152, ptr %t138, i64 %t139)
  %t153 = getelementptr i8, ptr %t152, i64 %t139
  %t154 = call i64 @__olang_fmt_i64(ptr %t153, i64 %t110)
  %t155 = insertvalue { i64, ptr } undef, i64 %t143, 0
  %t156 = insertvalue { i64, ptr } %t155, ptr %t144, 1
  %t158 = extractvalue { i64, ptr } %t156, 0
  %t159 = extractvalue { i64, ptr } %t156, 1
  %t160 = mul i64 %t158, 1
  %t161 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t160)
  call void @llvm.memcpy.p0.p0.i64(ptr %t161, ptr %t159, i64 %t160, i1 false)
  %t162 = insertvalue { i64, ptr } undef, i64 %t158, 0
  %t163 = insertvalue { i64, ptr } %t162, ptr %t161, 1
  %t164 = load ptr, ptr %l55, !tbaa !29
  %t166 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v2, ptr %v2, ptr %t164, { i64, ptr } %t163)
  store { i64, ptr } %t166, ptr %l67
  br label %bb15
bb15:
  %t167 = load ptr, ptr %lp5
  %t168 = load { i64, ptr }, ptr %t167, !tbaa !27
  %t169 = extractvalue { i64, ptr } %t168, 0
  %t170 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t171 = extractvalue { i64, ptr } %t170, 0
  store i64 %t171, ptr %l69, !tbaa !24
  %t173 = load i64, ptr %l69, !tbaa !24
  %t174 = icmp eq i64 %t169, %t173
  br i1 %t174, label %bb16, label %bb17
bb16:
  %t176 = load ptr, ptr %lp5
  %t177 = getelementptr { i64, ptr }, ptr %t176, i32 0, i32 1
  %t178 = load ptr, ptr %t177, !tbaa !27
  %t179 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t180 = load ptr, ptr %t179, !tbaa !27
  %t181 = load i64, ptr %l69, !tbaa !24
  %t182 = mul i64 %t181, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t178, ptr %t180, i64 %t182, i1 false)
  br label %bb18
bb17:
  %t183 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t184 = load ptr, ptr %lp5
  store { i64, ptr } %t183, ptr %t184, !tbaa !27
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb19:
  %t185 = load i64, ptr %l10, !tbaa !24
  %t187 = add i64 %t185, 1
  store i64 %t187, ptr %l10, !tbaa !24
  br label %bb8
bb20:
  %t189 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t191 = extractvalue { i64, ptr } %t189, 0
  %t193 = icmp eq i64 %t191, 0
  br i1 %t193, label %bb21, label %bb22
bb21:
  store { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d459, i32 0, i32 1) }, ptr %l76, !tbaa !27
  %t195 = load { i64, ptr }, ptr %l76, !tbaa !27
  store { i64, ptr } %t195, ptr %l77, !tbaa !27
  %t196 = load { i64, ptr }, ptr %l77, !tbaa !27
  %t197 = extractvalue { i64, ptr } %t196, 0
  store i64 %t197, ptr %l78, !tbaa !24
  %t198 = load i64, ptr %l78, !tbaa !24
  %t199 = mul i64 %t198, 1
  %t200 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t199)
  %t201 = insertvalue { i64, ptr } undef, i64 %t198, 0
  %t202 = insertvalue { i64, ptr } %t201, ptr %t200, 1
  store { i64, ptr } %t202, ptr %l79, !tbaa !27
  %t203 = getelementptr { i64, ptr }, ptr %l79, i32 0, i32 1
  %t204 = load ptr, ptr %t203, !tbaa !27
  %t205 = getelementptr { i64, ptr }, ptr %l77, i32 0, i32 1
  %t206 = load ptr, ptr %t205, !tbaa !27
  %t207 = load i64, ptr %l78, !tbaa !24
  %t208 = mul i64 %t207, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t204, ptr %t206, i64 %t208, i1 false)
  %t209 = load { i64, ptr }, ptr %l79, !tbaa !27
  store { i64, ptr } %t209, ptr %l77, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t210 = load { i64, ptr }, ptr %l77, !tbaa !27
  store { i64, ptr } %t210, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  %t211 = load ptr, ptr %lp5
  %t212 = load { i64, ptr }, ptr %t211, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t212, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eprogram(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edefine(ptr %v0, ptr %s0, ptr %s0, ptr %t4, { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d460, i32 0, i32 1) }, { i64, ptr } { i64 67, ptr getelementptr inbounds (<{ i64, [67 x i8] }>, ptr @.d461, i32 0, i32 1) })
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %t6, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d462, i32 0, i32 1) }, { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d463, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d179, i32 0, i32 1) })
  store { i64, ptr } %t8, ptr %l4
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  %t9 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t9, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2erecode(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l17 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l37 = alloca i64
  %l38 = alloca { i64, ptr }
  %l44 = alloca i64
  %l47 = alloca i64
  %l68 = alloca { i64, ptr }
  %l71 = alloca i64
  %l78 = alloca { i64, ptr }
  %l85 = alloca { i64, ptr }
  %l87 = alloca i64
  %l95 = alloca { i64, ptr }
  %l96 = alloca ptr
  %l101 = alloca { i64, ptr }
  %l105 = alloca { i64, ptr }
  %l111 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/emit:Emitter", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t13 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t7, i32 %a2)
  store { i64, ptr } %t13, ptr %l24
  br label %bb1
bb1:
  %t14 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t14, ptr %l5, !tbaa !27
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t17 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d464, i32 0, i32 1) }, 1
  %t18 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d464, i32 0, i32 1) }, 0
  %t20 = extractvalue { i64, ptr } %t16, 1
  %t21 = extractvalue { i64, ptr } %t16, 0
  %t22 = add i64 %t18, %t21
  %t23 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d465, i32 0, i32 1) }, 1
  %t24 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d465, i32 0, i32 1) }, 0
  %t25 = add i64 %t22, %t24
  %t26 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t25)
  call void @olang_textcopy(ptr %t26, ptr %t17, i64 %t18)
  %t27 = getelementptr i8, ptr %t26, i64 %t18
  call void @olang_textcopy(ptr %t27, ptr %t20, i64 %t21)
  %t28 = getelementptr i8, ptr %t27, i64 %t21
  call void @olang_textcopy(ptr %t28, ptr %t23, i64 %t24)
  %t29 = insertvalue { i64, ptr } undef, i64 %t25, 0
  %t30 = insertvalue { i64, ptr } %t29, ptr %t26, 1
  %t32 = extractvalue { i64, ptr } %t30, 0
  %t33 = extractvalue { i64, ptr } %t30, 1
  %t34 = mul i64 %t32, 1
  %t35 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t34)
  call void @llvm.memcpy.p0.p0.i64(ptr %t35, ptr %t33, i64 %t34, i1 false)
  %t36 = insertvalue { i64, ptr } undef, i64 %t32, 0
  %t37 = insertvalue { i64, ptr } %t36, ptr %t35, 1
  %t40 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t15, { i64, ptr } %t37)
  store { i64, ptr } %t40, ptr %l29
  br label %bb2
bb2:
  %t41 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t41, ptr %l6, !tbaa !27
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t44 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d466, i32 0, i32 1) }, 1
  %t45 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d466, i32 0, i32 1) }, 0
  %t47 = extractvalue { i64, ptr } %t43, 1
  %t48 = extractvalue { i64, ptr } %t43, 0
  %t49 = add i64 %t45, %t48
  %t50 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d467, i32 0, i32 1) }, 1
  %t51 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d467, i32 0, i32 1) }, 0
  %t52 = add i64 %t49, %t51
  %t53 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t52)
  call void @olang_textcopy(ptr %t53, ptr %t44, i64 %t45)
  %t54 = getelementptr i8, ptr %t53, i64 %t45
  call void @olang_textcopy(ptr %t54, ptr %t47, i64 %t48)
  %t55 = getelementptr i8, ptr %t54, i64 %t48
  call void @olang_textcopy(ptr %t55, ptr %t50, i64 %t51)
  %t56 = insertvalue { i64, ptr } undef, i64 %t52, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t53, 1
  %t59 = extractvalue { i64, ptr } %t57, 0
  %t60 = extractvalue { i64, ptr } %t57, 1
  %t61 = mul i64 %t59, 1
  %t62 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t61)
  call void @llvm.memcpy.p0.p0.i64(ptr %t62, ptr %t60, i64 %t61, i1 false)
  %t63 = insertvalue { i64, ptr } undef, i64 %t59, 0
  %t64 = insertvalue { i64, ptr } %t63, ptr %t62, 1
  %t67 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t42, { i64, ptr } %t64)
  store { i64, ptr } %t67, ptr %l34
  br label %bb3
bb3:
  %t68 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t68, ptr %l7, !tbaa !27
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d468, i32 0, i32 1) }, ptr %l35, !tbaa !27
  %t69 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t69, ptr %l36, !tbaa !27
  %t70 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t71 = extractvalue { i64, ptr } %t70, 0
  store i64 %t71, ptr %l37, !tbaa !24
  %t72 = load i64, ptr %l37, !tbaa !24
  %t73 = mul i64 %t72, 1
  %t74 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t73)
  %t75 = insertvalue { i64, ptr } undef, i64 %t72, 0
  %t76 = insertvalue { i64, ptr } %t75, ptr %t74, 1
  store { i64, ptr } %t76, ptr %l38, !tbaa !27
  %t77 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = load i64, ptr %l37, !tbaa !24
  %t82 = mul i64 %t81, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t78, ptr %t80, i64 %t82, i1 false)
  %t83 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t83, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t84 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t84, 0
  store i64 %t86, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t88 = load i64, ptr %l10, !tbaa !24
  %t89 = load i64, ptr %l9, !tbaa !24
  %t92 = icmp sgt i64 %t88, %t89
  br i1 %t92, label %bb4, label %bb5
bb4:
  %t94 = load i64, ptr %l11, !tbaa !24
  %t96 = icmp sgt i64 %t94, 0
  br i1 %t96, label %bb6, label %bb7
bb5:
  store i64 0, ptr %l44, !tbaa !24
  br label %bb9
bb6:
  %t98 = load i64, ptr %l10, !tbaa !24
  %t99 = load i64, ptr %l9, !tbaa !24
  %t102 = sub i64 %t98, %t99
  %t103 = load i64, ptr %l11, !tbaa !24
  %t106 = add i64 %t102, %t103
  %t108 = sub i64 %t106, 1
  %t109 = load i64, ptr %l11, !tbaa !24
  %t112 = sdiv i64 %t108, %t109
  store i64 %t112, ptr %l47, !tbaa !24
  br label %bb8
bb7:
  store i64 0, ptr %l47, !tbaa !24
  br label %bb8
bb8:
  %t114 = load i64, ptr %l47, !tbaa !24
  store i64 %t114, ptr %l44, !tbaa !24
  br label %bb9
bb9:
  %t115 = load i64, ptr %l44, !tbaa !24
  store i64 %t115, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s4
  %t116 = load i64, ptr %l13, !tbaa !24
  %t117 = load i64, ptr %l12, !tbaa !24
  %t120 = icmp slt i64 %t116, %t117
  %t122 = xor i1 %t120, true
  br i1 %t122, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s4)
  br label %bb21
bb12:
  br label %bb13
bb13:
  %t124 = load i64, ptr %l9, !tbaa !24
  %t125 = load i64, ptr %l13, !tbaa !24
  %t126 = load i64, ptr %l11, !tbaa !24
  %t129 = mul i64 %t125, %t126
  %t132 = add i64 %t124, %t129
  store i64 %t132, ptr %l14, !tbaa !24
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr %"compiler/emit:fnEm", ptr %t134, i32 0, i32 0
  %t137 = load ptr, ptr %t136, !tbaa !29
  %t139 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t139, ptr %l68, !tbaa !27
  %t140 = load i64, ptr %l14, !tbaa !24
  %t142 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t143 = load ptr, ptr %t142, !tbaa !27
  %t144 = getelementptr i32, ptr %t143, i64 %t140
  %t145 = load i32, ptr %t144, !tbaa !33
  %t149 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eposition(ptr %v0, ptr %t137, i32 %a3, i32 %t145)
  store i64 %t149, ptr %l71
  br label %bb14
bb14:
  %t150 = load i64, ptr %l71, !tbaa !24
  store i64 %t150, ptr %l15, !tbaa !24
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t152 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t153 = load i64, ptr %l14, !tbaa !24
  %t155 = add i64 %t153, 1
  %t156 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d469, i32 0, i32 1) }, 1
  %t157 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d469, i32 0, i32 1) }, 0
  %t159 = extractvalue { i64, ptr } %t152, 1
  %t160 = extractvalue { i64, ptr } %t152, 0
  %t161 = add i64 %t157, %t160
  %t162 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d470, i32 0, i32 1) }, 1
  %t163 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d470, i32 0, i32 1) }, 0
  %t164 = add i64 %t161, %t163
  %t166 = call i64 @__olang_fmt_i64(ptr null, i64 %t155)
  %t167 = add i64 %t164, %t166
  %t168 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t167)
  call void @olang_textcopy(ptr %t168, ptr %t156, i64 %t157)
  %t169 = getelementptr i8, ptr %t168, i64 %t157
  call void @olang_textcopy(ptr %t169, ptr %t159, i64 %t160)
  %t170 = getelementptr i8, ptr %t169, i64 %t160
  call void @olang_textcopy(ptr %t170, ptr %t162, i64 %t163)
  %t171 = getelementptr i8, ptr %t170, i64 %t163
  %t172 = call i64 @__olang_fmt_i64(ptr %t171, i64 %t155)
  %t173 = insertvalue { i64, ptr } undef, i64 %t167, 0
  %t174 = insertvalue { i64, ptr } %t173, ptr %t168, 1
  %t176 = extractvalue { i64, ptr } %t174, 0
  %t177 = extractvalue { i64, ptr } %t174, 1
  %t178 = mul i64 %t176, 1
  %t179 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t178)
  call void @llvm.memcpy.p0.p0.i64(ptr %t179, ptr %t177, i64 %t178, i1 false)
  %t180 = insertvalue { i64, ptr } undef, i64 %t176, 0
  %t181 = insertvalue { i64, ptr } %t180, ptr %t179, 1
  %t184 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s4, ptr %s4, ptr %t151, { i64, ptr } %t181)
  store { i64, ptr } %t184, ptr %l78
  br label %bb15
bb15:
  %t185 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t186 = load ptr, ptr %l0, !tbaa !29
  %t188 = load i64, ptr %l15, !tbaa !24
  %t189 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t190 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d471, i32 0, i32 1) }, 1
  %t191 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d471, i32 0, i32 1) }, 0
  %t193 = extractvalue { i64, ptr } %t185, 1
  %t194 = extractvalue { i64, ptr } %t185, 0
  %t195 = add i64 %t191, %t194
  %t196 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d472, i32 0, i32 1) }, 1
  %t197 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d472, i32 0, i32 1) }, 0
  %t198 = add i64 %t195, %t197
  %t200 = call i64 @__olang_fmt_i64(ptr null, i64 %t188)
  %t201 = add i64 %t198, %t200
  %t202 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d472, i32 0, i32 1) }, 1
  %t203 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d472, i32 0, i32 1) }, 0
  %t204 = add i64 %t201, %t203
  %t206 = extractvalue { i64, ptr } %t189, 1
  %t207 = extractvalue { i64, ptr } %t189, 0
  %t208 = add i64 %t204, %t207
  %t209 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t208)
  call void @olang_textcopy(ptr %t209, ptr %t190, i64 %t191)
  %t210 = getelementptr i8, ptr %t209, i64 %t191
  call void @olang_textcopy(ptr %t210, ptr %t193, i64 %t194)
  %t211 = getelementptr i8, ptr %t210, i64 %t194
  call void @olang_textcopy(ptr %t211, ptr %t196, i64 %t197)
  %t212 = getelementptr i8, ptr %t211, i64 %t197
  %t213 = call i64 @__olang_fmt_i64(ptr %t212, i64 %t188)
  %t214 = getelementptr i8, ptr %t212, i64 %t200
  call void @olang_textcopy(ptr %t214, ptr %t202, i64 %t203)
  %t215 = getelementptr i8, ptr %t214, i64 %t203
  call void @olang_textcopy(ptr %t215, ptr %t206, i64 %t207)
  %t216 = insertvalue { i64, ptr } undef, i64 %t208, 0
  %t217 = insertvalue { i64, ptr } %t216, ptr %t209, 1
  %t219 = extractvalue { i64, ptr } %t217, 0
  %t220 = extractvalue { i64, ptr } %t217, 1
  %t221 = mul i64 %t219, 1
  %t222 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t221)
  call void @llvm.memcpy.p0.p0.i64(ptr %t222, ptr %t220, i64 %t221, i1 false)
  %t223 = insertvalue { i64, ptr } undef, i64 %t219, 0
  %t224 = insertvalue { i64, ptr } %t223, ptr %t222, 1
  %t227 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t186, { i64, ptr } %t224)
  store { i64, ptr } %t227, ptr %l85
  br label %bb16
bb16:
  %t228 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t229 = extractvalue { i64, ptr } %t228, 0
  %t230 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t231 = extractvalue { i64, ptr } %t230, 0
  store i64 %t231, ptr %l87, !tbaa !24
  %t233 = load i64, ptr %l87, !tbaa !24
  %t234 = icmp eq i64 %t229, %t233
  br i1 %t234, label %bb17, label %bb18
bb17:
  %t236 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t237 = load ptr, ptr %t236, !tbaa !27
  %t238 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t239 = load ptr, ptr %t238, !tbaa !27
  %t240 = load i64, ptr %l87, !tbaa !24
  %t241 = mul i64 %t240, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t237, ptr %t239, i64 %t241, i1 false)
  br label %bb19
bb18:
  %t242 = load { i64, ptr }, ptr %l85, !tbaa !27
  store { i64, ptr } %t242, ptr %l8, !tbaa !27
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s4)
  br label %bb20
bb20:
  %t243 = load i64, ptr %l13, !tbaa !24
  %t245 = add i64 %t243, 1
  store i64 %t245, ptr %l13, !tbaa !24
  br label %bb10
bb21:
  %t247 = load ptr, ptr %l0, !tbaa !29
  %t248 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t249 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d473, i32 0, i32 1) }, 1
  %t250 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d473, i32 0, i32 1) }, 0
  %t252 = extractvalue { i64, ptr } %t248, 1
  %t253 = extractvalue { i64, ptr } %t248, 0
  %t254 = add i64 %t250, %t253
  %t255 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d474, i32 0, i32 1) }, 1
  %t256 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d474, i32 0, i32 1) }, 0
  %t257 = add i64 %t254, %t256
  %t258 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t257)
  call void @olang_textcopy(ptr %t258, ptr %t249, i64 %t250)
  %t259 = getelementptr i8, ptr %t258, i64 %t250
  call void @olang_textcopy(ptr %t259, ptr %t252, i64 %t253)
  %t260 = getelementptr i8, ptr %t259, i64 %t253
  call void @olang_textcopy(ptr %t260, ptr %t255, i64 %t256)
  %t261 = insertvalue { i64, ptr } undef, i64 %t257, 0
  %t262 = insertvalue { i64, ptr } %t261, ptr %t258, 1
  %t264 = extractvalue { i64, ptr } %t262, 0
  %t265 = extractvalue { i64, ptr } %t262, 1
  %t266 = mul i64 %t264, 1
  %t267 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t266)
  call void @llvm.memcpy.p0.p0.i64(ptr %t267, ptr %t265, i64 %t266, i1 false)
  %t268 = insertvalue { i64, ptr } undef, i64 %t264, 0
  %t269 = insertvalue { i64, ptr } %t268, ptr %t267, 1
  %t272 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t247, { i64, ptr } %t269)
  store { i64, ptr } %t272, ptr %l95
  br label %bb22
bb22:
  %t273 = load { i64, ptr }, ptr %l95, !tbaa !27
  store { i64, ptr } %t273, ptr %l17, !tbaa !27
  %t274 = load ptr, ptr %l0, !tbaa !29
  store ptr %t274, ptr %l96, !tbaa !29
  %t275 = load ptr, ptr %l0, !tbaa !29
  %t276 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t277 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d475, i32 0, i32 1) }, 1
  %t278 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d475, i32 0, i32 1) }, 0
  %t280 = extractvalue { i64, ptr } %t276, 1
  %t281 = extractvalue { i64, ptr } %t276, 0
  %t282 = add i64 %t278, %t281
  %t283 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d476, i32 0, i32 1) }, 1
  %t284 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d476, i32 0, i32 1) }, 0
  %t285 = add i64 %t282, %t284
  %t286 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t285)
  call void @olang_textcopy(ptr %t286, ptr %t277, i64 %t278)
  %t287 = getelementptr i8, ptr %t286, i64 %t278
  call void @olang_textcopy(ptr %t287, ptr %t280, i64 %t281)
  %t288 = getelementptr i8, ptr %t287, i64 %t281
  call void @olang_textcopy(ptr %t288, ptr %t283, i64 %t284)
  %t289 = insertvalue { i64, ptr } undef, i64 %t285, 0
  %t290 = insertvalue { i64, ptr } %t289, ptr %t286, 1
  %t292 = extractvalue { i64, ptr } %t290, 0
  %t293 = extractvalue { i64, ptr } %t290, 1
  %t294 = mul i64 %t292, 1
  %t295 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t294)
  call void @llvm.memcpy.p0.p0.i64(ptr %t295, ptr %t293, i64 %t294, i1 false)
  %t296 = insertvalue { i64, ptr } undef, i64 %t292, 0
  %t297 = insertvalue { i64, ptr } %t296, ptr %t295, 1
  %t300 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t275, { i64, ptr } %t297)
  store { i64, ptr } %t300, ptr %l101
  br label %bb23
bb23:
  %t301 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t302 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d477, i32 0, i32 1) }, 1
  %t303 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d477, i32 0, i32 1) }, 0
  %t304 = load { i64, ptr }, ptr %l101, !tbaa !27
  %t305 = extractvalue { i64, ptr } %t304, 1
  %t306 = extractvalue { i64, ptr } %t304, 0
  %t307 = add i64 %t303, %t306
  %t308 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d478, i32 0, i32 1) }, 1
  %t309 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d478, i32 0, i32 1) }, 0
  %t310 = add i64 %t307, %t309
  %t312 = extractvalue { i64, ptr } %t301, 1
  %t313 = extractvalue { i64, ptr } %t301, 0
  %t314 = add i64 %t310, %t313
  %t315 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t314)
  call void @olang_textcopy(ptr %t315, ptr %t302, i64 %t303)
  %t316 = getelementptr i8, ptr %t315, i64 %t303
  call void @olang_textcopy(ptr %t316, ptr %t305, i64 %t306)
  %t317 = getelementptr i8, ptr %t316, i64 %t306
  call void @olang_textcopy(ptr %t317, ptr %t308, i64 %t309)
  %t318 = getelementptr i8, ptr %t317, i64 %t309
  call void @olang_textcopy(ptr %t318, ptr %t312, i64 %t313)
  %t319 = insertvalue { i64, ptr } undef, i64 %t314, 0
  %t320 = insertvalue { i64, ptr } %t319, ptr %t315, 1
  %t322 = extractvalue { i64, ptr } %t320, 0
  %t323 = extractvalue { i64, ptr } %t320, 1
  %t324 = mul i64 %t322, 1
  %t325 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t324)
  call void @llvm.memcpy.p0.p0.i64(ptr %t325, ptr %t323, i64 %t324, i1 false)
  %t326 = insertvalue { i64, ptr } undef, i64 %t322, 0
  %t327 = insertvalue { i64, ptr } %t326, ptr %t325, 1
  %t328 = load ptr, ptr %l96, !tbaa !29
  %t330 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t328, { i64, ptr } %t327)
  store { i64, ptr } %t330, ptr %l105
  br label %bb24
bb24:
  %t331 = load { i64, ptr }, ptr %l105, !tbaa !27
  %t332 = load ptr, ptr %l0, !tbaa !29
  %t333 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t335 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d479, i32 0, i32 1) }, 1
  %t336 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d479, i32 0, i32 1) }, 0
  %t338 = extractvalue { i64, ptr } %t333, 1
  %t339 = extractvalue { i64, ptr } %t333, 0
  %t340 = add i64 %t336, %t339
  %t341 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d480, i32 0, i32 1) }, 1
  %t342 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d480, i32 0, i32 1) }, 0
  %t343 = add i64 %t340, %t342
  %t345 = extractvalue { i64, ptr } %t331, 1
  %t346 = extractvalue { i64, ptr } %t331, 0
  %t347 = add i64 %t343, %t346
  %t348 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t347)
  call void @olang_textcopy(ptr %t348, ptr %t335, i64 %t336)
  %t349 = getelementptr i8, ptr %t348, i64 %t336
  call void @olang_textcopy(ptr %t349, ptr %t338, i64 %t339)
  %t350 = getelementptr i8, ptr %t349, i64 %t339
  call void @olang_textcopy(ptr %t350, ptr %t341, i64 %t342)
  %t351 = getelementptr i8, ptr %t350, i64 %t342
  call void @olang_textcopy(ptr %t351, ptr %t345, i64 %t346)
  %t352 = insertvalue { i64, ptr } undef, i64 %t347, 0
  %t353 = insertvalue { i64, ptr } %t352, ptr %t348, 1
  %t355 = extractvalue { i64, ptr } %t353, 0
  %t356 = extractvalue { i64, ptr } %t353, 1
  %t357 = mul i64 %t355, 1
  %t358 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t357)
  call void @llvm.memcpy.p0.p0.i64(ptr %t358, ptr %t356, i64 %t357, i1 false)
  %t359 = insertvalue { i64, ptr } undef, i64 %t355, 0
  %t360 = insertvalue { i64, ptr } %t359, ptr %t358, 1
  %t363 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v2, ptr %v2, ptr %t332, { i64, ptr } %t360)
  store { i64, ptr } %t363, ptr %l111
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s0)
  %t364 = load { i64, ptr }, ptr %l111, !tbaa !27
  store { i64, ptr } %t364, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2esrcAddr(ptr %v0, ptr %v1, ptr %a0, { i64, [4 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [4 x i64] }
  %l2 = alloca %"compiler/mir:Place"
  %l3 = alloca { { i64, ptr }, i32 }
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i64
  %l8 = alloca %"compiler/source:Span"
  %l14 = alloca { { i64, ptr }, i32 }
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l35 = alloca i64
  %l36 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, [4 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [4 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [4 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 1
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [4 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { %"compiler/mir:Place" }, ptr %t6, i32 0, i32 0
  %t8 = load %"compiler/mir:Place", ptr %t7
  store %"compiler/mir:Place" %t8, ptr %l2
  br label %bb3
bb2:
  br label %bb5
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load %"compiler/mir:Place", ptr %l2
  %t14 = call { { i64, ptr }, i32 } @compiler_2femit_2ecompiler_2femit_3afnEm_2eaddr(ptr %v0, ptr %s1, ptr %t10, %"compiler/mir:Place" %t11)
  store { { i64, ptr }, i32 } %t14, ptr %l14
  br label %bb4
bb4:
  %t15 = load { { i64, ptr }, i32 }, ptr %l14
  store { { i64, ptr }, i32 } %t15, ptr %l3
  %t16 = getelementptr { { i64, ptr }, i32 }, ptr %l3, i32 0, i32 0
  %t17 = load { i64, ptr }, ptr %t16, !tbaa !27
  store { i64, ptr } %t17, ptr %l15, !tbaa !27
  %t18 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t18, 0
  store i64 %t19, ptr %l16, !tbaa !24
  %t20 = load i64, ptr %l16, !tbaa !24
  %t21 = mul i64 %t20, 1
  %t22 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t21)
  %t23 = insertvalue { i64, ptr } undef, i64 %t20, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t22, 1
  store { i64, ptr } %t24, ptr %l17, !tbaa !27
  %t25 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = load i64, ptr %l16, !tbaa !24
  %t30 = mul i64 %t29, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t26, ptr %t28, i64 %t30, i1 false)
  %t31 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t31, ptr %l18, !tbaa !27
  %t33 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t33, 0
  store i64 %t34, ptr %l19, !tbaa !24
  %t35 = load i64, ptr %l19, !tbaa !24
  %t36 = mul i64 %t35, 1
  %t37 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t36)
  %t38 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t37, 1
  store { i64, ptr } %t39, ptr %l20, !tbaa !27
  %t40 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = load i64, ptr %l19, !tbaa !24
  %t45 = mul i64 %t44, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t41, ptr %t43, i64 %t45, i1 false)
  %t46 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t46, ptr %l18, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  %t47 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t47, ptr %rv
  br label %ret
bb5:
  %t48 = load { i64, [4 x i64] }, ptr %l1
  %t50 = extractvalue { i64, [4 x i64] } %t48, 0
  %t51 = icmp eq i64 %t50, 3
  br i1 %t51, label %bb6, label %bb7
bb6:
  %t53 = getelementptr { i64, [4 x i64] }, ptr %l1, i32 0, i32 1
  %t54 = getelementptr { i32, i32, i64, %"compiler/source:Span" }, ptr %t53, i32 0, i32 0
  %t55 = load i32, ptr %t54
  store i32 %t55, ptr %l5, !tbaa !23
  %t57 = getelementptr { i64, [4 x i64] }, ptr %l1, i32 0, i32 1
  %t58 = getelementptr { i32, i32, i64, %"compiler/source:Span" }, ptr %t57, i32 0, i32 1
  %t59 = load i32, ptr %t58
  store i32 %t59, ptr %l6, !tbaa !23
  %t61 = getelementptr { i64, [4 x i64] }, ptr %l1, i32 0, i32 1
  %t62 = getelementptr { i32, i32, i64, %"compiler/source:Span" }, ptr %t61, i32 0, i32 2
  %t63 = load i64, ptr %t62
  store i64 %t63, ptr %l7, !tbaa !24
  %t65 = getelementptr { i64, [4 x i64] }, ptr %l1, i32 0, i32 1
  %t66 = getelementptr { i32, i32, i64, %"compiler/source:Span" }, ptr %t65, i32 0, i32 3
  %t67 = load %"compiler/source:Span", ptr %t66
  store %"compiler/source:Span" %t67, ptr %l8
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load i32, ptr %l5, !tbaa !23
  %t71 = load i32, ptr %l6, !tbaa !23
  %t72 = load i64, ptr %l7, !tbaa !24
  %t73 = load %"compiler/source:Span", ptr %l8
  %t79 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2edata(ptr %v0, ptr %v1, ptr %t69, i32 %t70, i32 %t71, i64 %t72, %"compiler/source:Span" %t73, i1 true)
  store { i64, ptr } %t79, ptr %l32
  br label %bb9
bb9:
  %t80 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t80, ptr %rv
  br label %ret
bb10:
  br i1 true, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d481, i32 0, i32 1) }, ptr %l33, !tbaa !27
  %t81 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t81, ptr %l34, !tbaa !27
  %t82 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t83 = extractvalue { i64, ptr } %t82, 0
  store i64 %t83, ptr %l35, !tbaa !24
  %t84 = load i64, ptr %l35, !tbaa !24
  %t85 = mul i64 %t84, 1
  %t86 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t85)
  %t87 = insertvalue { i64, ptr } undef, i64 %t84, 0
  %t88 = insertvalue { i64, ptr } %t87, ptr %t86, 1
  store { i64, ptr } %t88, ptr %l36, !tbaa !27
  %t89 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t90 = load ptr, ptr %t89, !tbaa !27
  %t91 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !27
  %t93 = load i64, ptr %l35, !tbaa !24
  %t94 = mul i64 %t93, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t90, ptr %t92, i64 %t94, i1 false)
  %t95 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t95, ptr %l34, !tbaa !27
  %t96 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t96, ptr %rv
  br label %ret
bb14:
  call void @__olang_check_failed(ptr @olang_loc_37dcdc821423a995_2a435c3b360fb831)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3afnEm_2esubprogram(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l10 = alloca i1
  %l14 = alloca i1
  %l23 = alloca i64
  %l31 = alloca i64
  %l32 = alloca ptr
  %l34 = alloca i64
  %l36 = alloca ptr
  %l38 = alloca i64
  %l42 = alloca { i64, ptr }
  %l44 = alloca { i64, ptr }
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i64
  %l52 = alloca i64
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l1, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = getelementptr %"compiler/mir:Fn", ptr %t6, i32 0, i32 2
  %t9 = load i64, ptr %t8, !tbaa !24
  %t11 = icmp slt i64 %t9, 0
  br i1 %t11, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb6
bb2:
  %t13 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr %"compiler/mir:Fn", ptr %t13, i32 0, i32 3
  %t16 = getelementptr %"compiler/source:Span", ptr %t15, i32 0, i32 0
  %t17 = load i32, ptr %t16, !tbaa !23
  %t19 = icmp eq i32 %t17, 0
  br i1 %t19, label %bb3, label %bb4
bb3:
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr %"compiler/mir:Fn", ptr %t21, i32 0, i32 3
  %t24 = getelementptr %"compiler/source:Span", ptr %t23, i32 0, i32 1
  %t25 = load i32, ptr %t24, !tbaa !23
  %t27 = icmp eq i32 %t25, 0
  store i1 %t27, ptr %l14, !tbaa !21
  br label %bb5
bb4:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb5
bb5:
  %t29 = load i1, ptr %l14, !tbaa !21
  store i1 %t29, ptr %l10, !tbaa !21
  br label %bb6
bb6:
  %t30 = load i1, ptr %l10, !tbaa !21
  br i1 %t30, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb8:
  br label %bb9
bb9:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/emit:fnEm", ptr %t31, i32 0, i32 0
  %t34 = load ptr, ptr %t33, !tbaa !29
  store ptr %t34, ptr %l2, !tbaa !29
  %t36 = load ptr, ptr %l2, !tbaa !29
  %t37 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr %"compiler/mir:Fn", ptr %t37, i32 0, i32 2
  %t40 = load i64, ptr %t39, !tbaa !24
  %t43 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgFile(ptr %v0, ptr %t36, i64 %t40)
  store i64 %t43, ptr %l23
  br label %bb10
bb10:
  %t44 = load i64, ptr %l23, !tbaa !24
  store i64 %t44, ptr %l3, !tbaa !24
  %t45 = load ptr, ptr %l2, !tbaa !29
  %t47 = getelementptr %"compiler/emit:Emitter", ptr %t45, i32 0, i32 2
  %t48 = load ptr, ptr %t47, !tbaa !29
  %t49 = load ptr, ptr %l1, !tbaa !29
  %t51 = getelementptr %"compiler/mir:Fn", ptr %t49, i32 0, i32 2
  %t52 = load i64, ptr %t51, !tbaa !24
  %t53 = load ptr, ptr %l1, !tbaa !29
  %t55 = getelementptr %"compiler/mir:Fn", ptr %t53, i32 0, i32 3
  %t56 = getelementptr %"compiler/source:Span", ptr %t55, i32 0, i32 0
  %t57 = load i32, ptr %t56, !tbaa !23
  %t59 = sext i32 %t57 to i64
  %t63 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLineAt(ptr %v0, ptr %t48, i64 %t52, i64 %t59)
  store i64 %t63, ptr %l31
  br label %bb11
bb11:
  %t64 = load i64, ptr %l31, !tbaa !24
  store i64 %t64, ptr %l4, !tbaa !24
  %t65 = load ptr, ptr %l0, !tbaa !29
  store ptr %t65, ptr %l32, !tbaa !29
  %t66 = load ptr, ptr %l2, !tbaa !29
  %t68 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgNew(ptr %v0, ptr %t66)
  store i64 %t68, ptr %l34
  br label %bb12
bb12:
  %t69 = load i64, ptr %l34, !tbaa !24
  %t70 = load ptr, ptr %l32, !tbaa !29
  %t71 = getelementptr %"compiler/emit:fnEm", ptr %t70, i32 0, i32 17
  store i64 %t69, ptr %t71, !tbaa !24
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr %"compiler/emit:fnEm", ptr %t72, i32 0, i32 20
  store ptr %t74, ptr %l36, !tbaa !29
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/emit:fnEm", ptr %t75, i32 0, i32 17
  %t78 = load i64, ptr %t77, !tbaa !24
  store i64 %t78, ptr %l38, !tbaa !24
  %t79 = load ptr, ptr %l2, !tbaa !29
  %t80 = load ptr, ptr %l1, !tbaa !29
  %t82 = getelementptr %"compiler/mir:Fn", ptr %t80, i32 0, i32 0
  %t83 = load { i64, [2 x i64] }, ptr %t82
  %t86 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgName(ptr %v0, ptr %s0, ptr %t79, { i64, [2 x i64] } %t83)
  store { i64, ptr } %t86, ptr %l42
  br label %bb13
bb13:
  %t87 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t88 = extractvalue { i64, ptr } %t87, 0
  %t89 = extractvalue { i64, ptr } %t87, 1
  %t90 = mul i64 %t88, 1
  %t91 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t90)
  call void @llvm.memcpy.p0.p0.i64(ptr %t91, ptr %t89, i64 %t90, i1 false)
  %t92 = insertvalue { i64, ptr } undef, i64 %t88, 0
  %t93 = insertvalue { i64, ptr } %t92, ptr %t91, 1
  %t95 = call { i64, ptr } @compiler_2femit_2eescape(ptr %s0, ptr %s0, { i64, ptr } %t93)
  store { i64, ptr } %t95, ptr %l44
  br label %bb14
bb14:
  %t96 = load i64, ptr %l3, !tbaa !24
  store i64 %t96, ptr %l45, !tbaa !24
  %t97 = load i64, ptr %l3, !tbaa !24
  store i64 %t97, ptr %l46, !tbaa !24
  %t98 = load i64, ptr %l4, !tbaa !24
  store i64 %t98, ptr %l47, !tbaa !24
  %t99 = load ptr, ptr %l2, !tbaa !29
  %t101 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgSubTy(ptr %v0, ptr %t99)
  store i64 %t101, ptr %l49
  br label %bb15
bb15:
  %t102 = load i64, ptr %l4, !tbaa !24
  store i64 %t102, ptr %l50, !tbaa !24
  %t103 = load ptr, ptr %l2, !tbaa !29
  %t105 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgCu(ptr %v0, ptr %t103)
  store i64 %t105, ptr %l52
  br label %bb16
bb16:
  %t106 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d482, i32 0, i32 1) }, 1
  %t107 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d482, i32 0, i32 1) }, 0
  %t108 = load i64, ptr %l38, !tbaa !24
  %t109 = call i64 @__olang_fmt_i64(ptr null, i64 %t108)
  %t110 = add i64 %t107, %t109
  %t111 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d483, i32 0, i32 1) }, 1
  %t112 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d483, i32 0, i32 1) }, 0
  %t113 = add i64 %t110, %t112
  %t114 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t115 = extractvalue { i64, ptr } %t114, 1
  %t116 = extractvalue { i64, ptr } %t114, 0
  %t117 = add i64 %t113, %t116
  %t118 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d484, i32 0, i32 1) }, 1
  %t119 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d484, i32 0, i32 1) }, 0
  %t120 = add i64 %t117, %t119
  %t121 = load i64, ptr %l45, !tbaa !24
  %t122 = call i64 @__olang_fmt_i64(ptr null, i64 %t121)
  %t123 = add i64 %t120, %t122
  %t124 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d485, i32 0, i32 1) }, 1
  %t125 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d485, i32 0, i32 1) }, 0
  %t126 = add i64 %t123, %t125
  %t127 = load i64, ptr %l46, !tbaa !24
  %t128 = call i64 @__olang_fmt_i64(ptr null, i64 %t127)
  %t129 = add i64 %t126, %t128
  %t130 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d486, i32 0, i32 1) }, 1
  %t131 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d486, i32 0, i32 1) }, 0
  %t132 = add i64 %t129, %t131
  %t133 = load i64, ptr %l47, !tbaa !24
  %t134 = call i64 @__olang_fmt_i64(ptr null, i64 %t133)
  %t135 = add i64 %t132, %t134
  %t136 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d487, i32 0, i32 1) }, 1
  %t137 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d487, i32 0, i32 1) }, 0
  %t138 = add i64 %t135, %t137
  %t139 = load i64, ptr %l49, !tbaa !24
  %t140 = call i64 @__olang_fmt_i64(ptr null, i64 %t139)
  %t141 = add i64 %t138, %t140
  %t142 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d488, i32 0, i32 1) }, 1
  %t143 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d488, i32 0, i32 1) }, 0
  %t144 = add i64 %t141, %t143
  %t145 = load i64, ptr %l50, !tbaa !24
  %t146 = call i64 @__olang_fmt_i64(ptr null, i64 %t145)
  %t147 = add i64 %t144, %t146
  %t148 = extractvalue { i64, ptr } { i64 38, ptr getelementptr inbounds (<{ i64, [38 x i8] }>, ptr @.d489, i32 0, i32 1) }, 1
  %t149 = extractvalue { i64, ptr } { i64 38, ptr getelementptr inbounds (<{ i64, [38 x i8] }>, ptr @.d489, i32 0, i32 1) }, 0
  %t150 = add i64 %t147, %t149
  %t151 = load i64, ptr %l52, !tbaa !24
  %t152 = call i64 @__olang_fmt_i64(ptr null, i64 %t151)
  %t153 = add i64 %t150, %t152
  %t154 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d490, i32 0, i32 1) }, 1
  %t155 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d490, i32 0, i32 1) }, 0
  %t156 = add i64 %t153, %t155
  %t157 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t156)
  call void @olang_textcopy(ptr %t157, ptr %t106, i64 %t107)
  %t158 = getelementptr i8, ptr %t157, i64 %t107
  %t159 = call i64 @__olang_fmt_i64(ptr %t158, i64 %t108)
  %t160 = getelementptr i8, ptr %t158, i64 %t109
  call void @olang_textcopy(ptr %t160, ptr %t111, i64 %t112)
  %t161 = getelementptr i8, ptr %t160, i64 %t112
  call void @olang_textcopy(ptr %t161, ptr %t115, i64 %t116)
  %t162 = getelementptr i8, ptr %t161, i64 %t116
  call void @olang_textcopy(ptr %t162, ptr %t118, i64 %t119)
  %t163 = getelementptr i8, ptr %t162, i64 %t119
  %t164 = call i64 @__olang_fmt_i64(ptr %t163, i64 %t121)
  %t165 = getelementptr i8, ptr %t163, i64 %t122
  call void @olang_textcopy(ptr %t165, ptr %t124, i64 %t125)
  %t166 = getelementptr i8, ptr %t165, i64 %t125
  %t167 = call i64 @__olang_fmt_i64(ptr %t166, i64 %t127)
  %t168 = getelementptr i8, ptr %t166, i64 %t128
  call void @olang_textcopy(ptr %t168, ptr %t130, i64 %t131)
  %t169 = getelementptr i8, ptr %t168, i64 %t131
  %t170 = call i64 @__olang_fmt_i64(ptr %t169, i64 %t133)
  %t171 = getelementptr i8, ptr %t169, i64 %t134
  call void @olang_textcopy(ptr %t171, ptr %t136, i64 %t137)
  %t172 = getelementptr i8, ptr %t171, i64 %t137
  %t173 = call i64 @__olang_fmt_i64(ptr %t172, i64 %t139)
  %t174 = getelementptr i8, ptr %t172, i64 %t140
  call void @olang_textcopy(ptr %t174, ptr %t142, i64 %t143)
  %t175 = getelementptr i8, ptr %t174, i64 %t143
  %t176 = call i64 @__olang_fmt_i64(ptr %t175, i64 %t145)
  %t177 = getelementptr i8, ptr %t175, i64 %t146
  call void @olang_textcopy(ptr %t177, ptr %t148, i64 %t149)
  %t178 = getelementptr i8, ptr %t177, i64 %t149
  %t179 = call i64 @__olang_fmt_i64(ptr %t178, i64 %t151)
  %t180 = getelementptr i8, ptr %t178, i64 %t152
  call void @olang_textcopy(ptr %t180, ptr %t154, i64 %t155)
  %t181 = insertvalue { i64, ptr } undef, i64 %t156, 0
  %t182 = insertvalue { i64, ptr } %t181, ptr %t157, 1
  %t184 = extractvalue { i64, ptr } %t182, 0
  %t185 = extractvalue { i64, ptr } %t182, 1
  %t186 = mul i64 %t184, 1
  %t187 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t186)
  call void @llvm.memcpy.p0.p0.i64(ptr %t187, ptr %t185, i64 %t186, i1 false)
  %t188 = insertvalue { i64, ptr } undef, i64 %t184, 0
  %t189 = insertvalue { i64, ptr } %t188, ptr %t187, 1
  %t190 = load ptr, ptr %l36, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s0, ptr %t190, { i64, ptr } %t189)
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3afnEm_2etrace(ptr %v0, ptr %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca %"compiler/mir:BasicBlock"
  %l5 = alloca { i64, [8 x i64] }
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca %"compiler/source:Span"
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l13 = alloca i1
  %l18 = alloca { i64, ptr }
  %l23 = alloca ptr
  %l24 = alloca ptr
  %l25 = alloca %"compiler/source:Span"
  %l29 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l42 = alloca i64
  %l44 = alloca i64
  %l49 = alloca %"compiler/mir:BasicBlock"
  %l65 = alloca i64
  %l69 = alloca i64
  %l70 = alloca i32
  %l73 = alloca { i64, ptr }
  %l76 = alloca { i64, ptr }
  %l79 = alloca i1
  %l83 = alloca { i64, ptr }
  %l89 = alloca { i64, ptr }
  %l94 = alloca { i64, ptr }
  %l101 = alloca ptr
  %l102 = alloca { i64, ptr }
  %l108 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2etraced(ptr %v0, ptr %t4)
  store i1 %t6, ptr %l13
  br label %bb1
bb1:
  %t7 = load i1, ptr %l13, !tbaa !21
  %t8 = xor i1 %t7, true
  br i1 %t8, label %bb2, label %bb3
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/emit:fnEm", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t14 = load %"compiler/source:Span", ptr %l1
  %t17 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3aFn_2eRaiseText(ptr %v0, ptr %t13, %"compiler/source:Span" %t14)
  store { i64, ptr } %t17, ptr %l18
  br label %bb4
bb3:
  br label %bb12
bb4:
  %t18 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t18, 0
  %t21 = icmp sgt i64 %t19, 0
  br i1 %t21, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s2
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/emit:fnEm", ptr %t23, i32 0, i32 0
  %t26 = load ptr, ptr %t25, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s2, ptr %s2, ptr %t26, { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d491, i32 0, i32 1) }, { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d492, i32 0, i32 1) })
  br label %bb7
bb6:
  br label %bb11
bb7:
  %t28 = load ptr, ptr %l0, !tbaa !29
  store ptr %t28, ptr %l23, !tbaa !29
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l24, !tbaa !29
  %t30 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t30, ptr %l25
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/emit:fnEm", ptr %t31, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t35 = load %"compiler/source:Span", ptr %l1
  %t38 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3aFn_2eRaiseText(ptr %v0, ptr %t34, %"compiler/source:Span" %t35)
  store { i64, ptr } %t38, ptr %l29
  br label %bb8
bb8:
  %t39 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d493, i32 0, i32 1) }, 1
  %t40 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d493, i32 0, i32 1) }, 0
  %t41 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t42 = extractvalue { i64, ptr } %t41, 1
  %t43 = extractvalue { i64, ptr } %t41, 0
  %t44 = add i64 %t40, %t43
  %t45 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d494, i32 0, i32 1) }, 1
  %t46 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d494, i32 0, i32 1) }, 0
  %t47 = add i64 %t44, %t46
  %t48 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t47)
  call void @olang_textcopy(ptr %t48, ptr %t39, i64 %t40)
  %t49 = getelementptr i8, ptr %t48, i64 %t40
  call void @olang_textcopy(ptr %t49, ptr %t42, i64 %t43)
  %t50 = getelementptr i8, ptr %t49, i64 %t43
  call void @olang_textcopy(ptr %t50, ptr %t45, i64 %t46)
  %t51 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t52 = insertvalue { i64, ptr } %t51, ptr %t48, 1
  %t54 = extractvalue { i64, ptr } %t52, 0
  %t55 = extractvalue { i64, ptr } %t52, 1
  %t56 = mul i64 %t54, 1
  %t57 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t56)
  call void @llvm.memcpy.p0.p0.i64(ptr %t57, ptr %t55, i64 %t56, i1 false)
  %t58 = insertvalue { i64, ptr } undef, i64 %t54, 0
  %t59 = insertvalue { i64, ptr } %t58, ptr %t57, 1
  %t60 = load ptr, ptr %l24, !tbaa !29
  %t61 = load %"compiler/source:Span", ptr %l25
  %t63 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elocated(ptr %v0, ptr %s2, ptr %s2, ptr %t60, %"compiler/source:Span" %t61, { i64, ptr } %t59)
  store { i64, ptr } %t63, ptr %l32
  br label %bb9
bb9:
  %t64 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d495, i32 0, i32 1) }, 1
  %t65 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d495, i32 0, i32 1) }, 0
  %t66 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t67 = extractvalue { i64, ptr } %t66, 1
  %t68 = extractvalue { i64, ptr } %t66, 0
  %t69 = add i64 %t65, %t68
  %t70 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d496, i32 0, i32 1) }, 1
  %t71 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d496, i32 0, i32 1) }, 0
  %t72 = add i64 %t69, %t71
  %t73 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t72)
  call void @olang_textcopy(ptr %t73, ptr %t64, i64 %t65)
  %t74 = getelementptr i8, ptr %t73, i64 %t65
  call void @olang_textcopy(ptr %t74, ptr %t67, i64 %t68)
  %t75 = getelementptr i8, ptr %t74, i64 %t68
  call void @olang_textcopy(ptr %t75, ptr %t70, i64 %t71)
  %t76 = insertvalue { i64, ptr } undef, i64 %t72, 0
  %t77 = insertvalue { i64, ptr } %t76, ptr %t73, 1
  %t79 = extractvalue { i64, ptr } %t77, 0
  %t80 = extractvalue { i64, ptr } %t77, 1
  %t81 = mul i64 %t79, 1
  %t82 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t81)
  call void @llvm.memcpy.p0.p0.i64(ptr %t82, ptr %t80, i64 %t81, i1 false)
  %t83 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t84 = insertvalue { i64, ptr } %t83, ptr %t82, 1
  %t85 = load ptr, ptr %l23, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s2, ptr %t85, { i64, ptr } %t84)
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb12:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/emit:fnEm", ptr %t87, i32 0, i32 22
  %t90 = load i1, ptr %t89, !tbaa !21
  %t92 = xor i1 %t90, true
  br i1 %t92, label %bb13, label %bb14
bb13:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/emit:fnEm", ptr %t94, i32 0, i32 22
  store i1 true, ptr %t96, !tbaa !21
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/emit:fnEm", ptr %t97, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !29
  %t102 = getelementptr %"compiler/mir:Fn", ptr %t100, i32 0, i32 9
  store ptr %t102, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb15
bb14:
  br label %bb38
bb15:
  %t104 = load i64, ptr %l3, !tbaa !24
  store i64 %t104, ptr %l42, !tbaa !24
  %t105 = load ptr, ptr %l2, !tbaa !29
  %t107 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eLen_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, ptr %t105)
  store i64 %t107, ptr %l44
  br label %bb16
bb16:
  %t108 = load i64, ptr %l42, !tbaa !24
  %t109 = load i64, ptr %l44, !tbaa !24
  %t110 = icmp slt i64 %t108, %t109
  %t112 = xor i1 %t110, true
  br i1 %t112, label %bb17, label %bb18
bb17:
  br label %bb37
bb18:
  br label %bb19
bb19:
  %t114 = load ptr, ptr %l2, !tbaa !29
  %t115 = load i64, ptr %l3, !tbaa !24
  %t118 = call %"compiler/mir:BasicBlock" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eAt_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, ptr %v0, ptr %t114, i64 %t115)
  store %"compiler/mir:BasicBlock" %t118, ptr %l49
  br label %bb20
bb20:
  %t119 = load %"compiler/mir:BasicBlock", ptr %l49
  store %"compiler/mir:BasicBlock" %t119, ptr %l4
  %t120 = getelementptr %"compiler/mir:BasicBlock", ptr %l4, i32 0, i32 1
  %t121 = load { i64, [8 x i64] }, ptr %t120
  store { i64, [8 x i64] } %t121, ptr %l5
  %t123 = load { i64, [8 x i64] }, ptr %l5
  %t125 = extractvalue { i64, [8 x i64] } %t123, 0
  %t126 = icmp eq i64 %t125, 4
  br i1 %t126, label %bb21, label %bb22
bb21:
  %t128 = getelementptr { i64, [8 x i64] }, ptr %l5, i32 0, i32 1
  %t129 = getelementptr { %"compiler/source:Span", i32 }, ptr %t128, i32 0, i32 0
  %t130 = load %"compiler/source:Span", ptr %t129
  store %"compiler/source:Span" %t130, ptr %l6
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t134 = getelementptr %"compiler/emit:fnEm", ptr %t132, i32 0, i32 21
  %t135 = getelementptr %"compiler/source:Span", ptr %l6, i32 0, i32 0
  %t136 = load i32, ptr %t135, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI32_2c_20I64_3e_2ePut_3cI32_2c_20I64_3e(ptr %v0, ptr %t134, i32 %t136, i64 1)
  br label %bb24
bb24:
  br label %bb35
bb25:
  %t139 = load { i64, [8 x i64] }, ptr %l5
  %t141 = extractvalue { i64, [8 x i64] } %t139, 0
  %t142 = icmp eq i64 %t141, 7
  br i1 %t142, label %bb26, label %bb27
bb26:
  %t144 = getelementptr { i64, [8 x i64] }, ptr %l5, i32 0, i32 1
  %t145 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t144, i32 0, i32 0
  %t146 = load %"compiler/source:Span", ptr %t145
  store %"compiler/source:Span" %t146, ptr %l7
  br label %bb28
bb27:
  br label %bb30
bb28:
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t150 = getelementptr %"compiler/emit:fnEm", ptr %t148, i32 0, i32 21
  %t151 = getelementptr %"compiler/source:Span", ptr %l7, i32 0, i32 0
  %t152 = load i32, ptr %t151, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI32_2c_20I64_3e_2ePut_3cI32_2c_20I64_3e(ptr %v0, ptr %t150, i32 %t152, i64 2)
  br label %bb29
bb29:
  br label %bb35
bb30:
  br i1 true, label %bb31, label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb35
bb34:
  call void @__olang_check_failed(ptr @olang_loc_2ea555a1037c9329_7e95fb4c4c24cb65)
  unreachable
bb35:
  br label %bb36
bb36:
  %t155 = load i64, ptr %l3, !tbaa !24
  %t157 = add i64 %t155, 1
  store i64 %t157, ptr %l3, !tbaa !24
  br label %bb15
bb37:
  br label %bb38
bb38:
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t161 = getelementptr %"compiler/emit:fnEm", ptr %t159, i32 0, i32 21
  %t162 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t163 = load i32, ptr %t162, !tbaa !23
  %t166 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI32_2c_20I64_3e_2eGet_3cI32_2c_20I64_3e(ptr %v0, ptr %t161, i32 %t163)
  %t167 = extractvalue { i32, i64 } %t166, 1
  %t168 = extractvalue { i32, i64 } %t166, 0
  store i32 %t168, ptr %l70
  %t169 = icmp ne i32 %t168, 0
  br i1 %t169, label %bb40, label %ok.170
ok.170:
  store i64 %t167, ptr %l69
  br label %bb39
bb39:
  %t171 = load i64, ptr %l69, !tbaa !24
  store i64 %t171, ptr %l65, !tbaa !24
  br label %bb42
bb40:
  br label %bb41
bb41:
  call void @__olang_ert_req_clear()
  store i64 0, ptr %l65, !tbaa !24
  br label %bb42
bb42:
  %t172 = load i64, ptr %l65, !tbaa !24
  store i64 %t172, ptr %l8, !tbaa !24
  %t173 = load i64, ptr %l8, !tbaa !24
  %t175 = icmp eq i64 %t173, 1
  br i1 %t175, label %bb43, label %bb44
bb43:
  store { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d497, i32 0, i32 1) }, ptr %l73, !tbaa !27
  br label %bb48
bb44:
  %t177 = load i64, ptr %l8, !tbaa !24
  %t179 = icmp eq i64 %t177, 2
  br i1 %t179, label %bb45, label %bb46
bb45:
  store { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d498, i32 0, i32 1) }, ptr %l76, !tbaa !27
  br label %bb47
bb46:
  store { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d499, i32 0, i32 1) }, ptr %l76, !tbaa !27
  br label %bb47
bb47:
  %t181 = load { i64, ptr }, ptr %l76, !tbaa !27
  store { i64, ptr } %t181, ptr %l73, !tbaa !27
  br label %bb48
bb48:
  %t182 = load { i64, ptr }, ptr %l73, !tbaa !27
  store { i64, ptr } %t182, ptr %l9, !tbaa !27
  %t183 = load i64, ptr %l8, !tbaa !24
  %t185 = icmp eq i64 %t183, 0
  br i1 %t185, label %bb49, label %bb50
bb49:
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t189 = getelementptr %"compiler/emit:fnEm", ptr %t187, i32 0, i32 1
  %t190 = load ptr, ptr %t189, !tbaa !29
  %t191 = load %"compiler/source:Span", ptr %l1
  %t194 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3aFn_2eRaiseText(ptr %v0, ptr %t190, %"compiler/source:Span" %t191)
  store { i64, ptr } %t194, ptr %l83
  br label %bb51
bb50:
  store i1 false, ptr %l79, !tbaa !21
  br label %bb52
bb51:
  %t195 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t196 = extractvalue { i64, ptr } %t195, 0
  %t198 = icmp sgt i64 %t196, 0
  store i1 %t198, ptr %l79, !tbaa !21
  br label %bb52
bb52:
  %t200 = load i1, ptr %l79, !tbaa !21
  br i1 %t200, label %bb53, label %bb54
bb53:
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t203 = getelementptr %"compiler/emit:fnEm", ptr %t201, i32 0, i32 1
  %t204 = load ptr, ptr %t203, !tbaa !29
  %t205 = load %"compiler/source:Span", ptr %l1
  %t208 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3aFn_2eRaiseText(ptr %v0, ptr %t204, %"compiler/source:Span" %t205)
  store { i64, ptr } %t208, ptr %l89
  br label %bb55
bb54:
  br label %bb56
bb55:
  %t209 = load { i64, ptr }, ptr %l89, !tbaa !27
  %t210 = extractvalue { i64, ptr } %t209, 1
  %t211 = extractvalue { i64, ptr } %t209, 0
  %t212 = load ptr, ptr @__olang_prog_scope
  %t213 = call ptr @__olang_scope_alloc(ptr %t212, i64 %t211)
  call void @olang_textcopy(ptr %t213, ptr %t210, i64 %t211)
  %t214 = insertvalue { i64, ptr } undef, i64 %t211, 0
  %t215 = insertvalue { i64, ptr } %t214, ptr %t213, 1
  %t217 = load ptr, ptr @__olang_prog_scope
  %t218 = extractvalue { i64, ptr } %t215, 0
  %t219 = extractvalue { i64, ptr } %t215, 1
  %t220 = mul i64 %t218, 1
  %t221 = call ptr @__olang_scope_alloc(ptr %t217, i64 %t220)
  call void @llvm.memcpy.p0.p0.i64(ptr %t221, ptr %t219, i64 %t220, i1 false)
  %t222 = insertvalue { i64, ptr } undef, i64 %t218, 0
  %t223 = insertvalue { i64, ptr } %t222, ptr %t221, 1
  store { i64, ptr } %t223, ptr %l9, !tbaa !27
  br label %bb56
bb56:
  %t225 = load i64, ptr %l8, !tbaa !24
  %t227 = icmp eq i64 %t225, 1
  br i1 %t227, label %bb57, label %bb58
bb57:
  store { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d500, i32 0, i32 1) }, ptr %l94, !tbaa !27
  br label %bb59
bb58:
  store { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d501, i32 0, i32 1) }, ptr %l94, !tbaa !27
  br label %bb59
bb59:
  %t229 = load { i64, ptr }, ptr %l94, !tbaa !27
  store { i64, ptr } %t229, ptr %l10, !tbaa !27
  %t230 = load ptr, ptr %l0, !tbaa !29
  %t232 = getelementptr %"compiler/emit:fnEm", ptr %t230, i32 0, i32 0
  %t233 = load ptr, ptr %t232, !tbaa !29
  %t234 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t235 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t236 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d502, i32 0, i32 1) }, 1
  %t237 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d502, i32 0, i32 1) }, 0
  %t239 = extractvalue { i64, ptr } %t235, 1
  %t240 = extractvalue { i64, ptr } %t235, 0
  %t241 = add i64 %t237, %t240
  %t242 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d503, i32 0, i32 1) }, 1
  %t243 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d503, i32 0, i32 1) }, 0
  %t244 = add i64 %t241, %t243
  %t245 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t244)
  call void @olang_textcopy(ptr %t245, ptr %t236, i64 %t237)
  %t246 = getelementptr i8, ptr %t245, i64 %t237
  call void @olang_textcopy(ptr %t246, ptr %t239, i64 %t240)
  %t247 = getelementptr i8, ptr %t246, i64 %t240
  call void @olang_textcopy(ptr %t247, ptr %t242, i64 %t243)
  %t248 = insertvalue { i64, ptr } undef, i64 %t244, 0
  %t249 = insertvalue { i64, ptr } %t248, ptr %t245, 1
  %t251 = extractvalue { i64, ptr } %t249, 0
  %t252 = extractvalue { i64, ptr } %t249, 1
  %t253 = mul i64 %t251, 1
  %t254 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t253)
  call void @llvm.memcpy.p0.p0.i64(ptr %t254, ptr %t252, i64 %t253, i1 false)
  %t255 = insertvalue { i64, ptr } undef, i64 %t251, 0
  %t256 = insertvalue { i64, ptr } %t255, ptr %t254, 1
  %t257 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %t257, ptr %s0, ptr %t233, { i64, ptr } %t234, { i64, ptr } %t256)
  br label %bb60
bb60:
  %t261 = load ptr, ptr %l0, !tbaa !29
  store ptr %t261, ptr %l101, !tbaa !29
  %t262 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t262, ptr %l102, !tbaa !27
  %t263 = load ptr, ptr %l0, !tbaa !29
  %t264 = load %"compiler/source:Span", ptr %l1
  %t265 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t266 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d504, i32 0, i32 1) }, 1
  %t267 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d504, i32 0, i32 1) }, 0
  %t269 = extractvalue { i64, ptr } %t265, 1
  %t270 = extractvalue { i64, ptr } %t265, 0
  %t271 = add i64 %t267, %t270
  %t272 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d505, i32 0, i32 1) }, 1
  %t273 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d505, i32 0, i32 1) }, 0
  %t274 = add i64 %t271, %t273
  %t275 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t274)
  call void @olang_textcopy(ptr %t275, ptr %t266, i64 %t267)
  %t276 = getelementptr i8, ptr %t275, i64 %t267
  call void @olang_textcopy(ptr %t276, ptr %t269, i64 %t270)
  %t277 = getelementptr i8, ptr %t276, i64 %t270
  call void @olang_textcopy(ptr %t277, ptr %t272, i64 %t273)
  %t278 = insertvalue { i64, ptr } undef, i64 %t274, 0
  %t279 = insertvalue { i64, ptr } %t278, ptr %t275, 1
  %t281 = extractvalue { i64, ptr } %t279, 0
  %t282 = extractvalue { i64, ptr } %t279, 1
  %t283 = mul i64 %t281, 1
  %t284 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t283)
  call void @llvm.memcpy.p0.p0.i64(ptr %t284, ptr %t282, i64 %t283, i1 false)
  %t285 = insertvalue { i64, ptr } undef, i64 %t281, 0
  %t286 = insertvalue { i64, ptr } %t285, ptr %t284, 1
  %t290 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elocated(ptr %v0, ptr %s0, ptr %s0, ptr %t263, %"compiler/source:Span" %t264, { i64, ptr } %t286)
  store { i64, ptr } %t290, ptr %l108
  br label %bb61
bb61:
  %t291 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d506, i32 0, i32 1) }, 1
  %t292 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d506, i32 0, i32 1) }, 0
  %t293 = load { i64, ptr }, ptr %l102, !tbaa !27
  %t294 = extractvalue { i64, ptr } %t293, 1
  %t295 = extractvalue { i64, ptr } %t293, 0
  %t296 = add i64 %t292, %t295
  %t297 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d507, i32 0, i32 1) }, 1
  %t298 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d507, i32 0, i32 1) }, 0
  %t299 = add i64 %t296, %t298
  %t300 = load { i64, ptr }, ptr %l108, !tbaa !27
  %t301 = extractvalue { i64, ptr } %t300, 1
  %t302 = extractvalue { i64, ptr } %t300, 0
  %t303 = add i64 %t299, %t302
  %t304 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d508, i32 0, i32 1) }, 1
  %t305 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d508, i32 0, i32 1) }, 0
  %t306 = add i64 %t303, %t305
  %t307 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t306)
  call void @olang_textcopy(ptr %t307, ptr %t291, i64 %t292)
  %t308 = getelementptr i8, ptr %t307, i64 %t292
  call void @olang_textcopy(ptr %t308, ptr %t294, i64 %t295)
  %t309 = getelementptr i8, ptr %t308, i64 %t295
  call void @olang_textcopy(ptr %t309, ptr %t297, i64 %t298)
  %t310 = getelementptr i8, ptr %t309, i64 %t298
  call void @olang_textcopy(ptr %t310, ptr %t301, i64 %t302)
  %t311 = getelementptr i8, ptr %t310, i64 %t302
  call void @olang_textcopy(ptr %t311, ptr %t304, i64 %t305)
  %t312 = insertvalue { i64, ptr } undef, i64 %t306, 0
  %t313 = insertvalue { i64, ptr } %t312, ptr %t307, 1
  %t315 = extractvalue { i64, ptr } %t313, 0
  %t316 = extractvalue { i64, ptr } %t313, 1
  %t317 = mul i64 %t315, 1
  %t318 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t317)
  call void @llvm.memcpy.p0.p0.i64(ptr %t318, ptr %t316, i64 %t317, i1 false)
  %t319 = insertvalue { i64, ptr } undef, i64 %t315, 0
  %t320 = insertvalue { i64, ptr } %t319, ptr %t318, 1
  %t321 = load ptr, ptr %l101, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s0, ptr %t321, { i64, ptr } %t320)
  br label %bb62
bb62:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l5 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t8 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %v1, ptr %t4, i32 %a1)
  store { i64, ptr } %t8, ptr %l5
  br label %bb1
bb1:
  %t9 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t9, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3afnEm_2eunwindPop(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d509, i32 0, i32 1) }, 1
  %t5 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d509, i32 0, i32 1) }, 0
  %t7 = sext i32 %a1 to i64
  %t8 = call i64 @__olang_fmt_i64(ptr null, i64 %t7)
  %t9 = add i64 %t5, %t8
  %t10 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d510, i32 0, i32 1) }, 1
  %t11 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d510, i32 0, i32 1) }, 0
  %t12 = add i64 %t9, %t11
  %t13 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t12)
  call void @olang_textcopy(ptr %t13, ptr %t4, i64 %t5)
  %t14 = getelementptr i8, ptr %t13, i64 %t5
  %t15 = call i64 @__olang_fmt_i64(ptr %t14, i64 %t7)
  %t16 = getelementptr i8, ptr %t14, i64 %t8
  call void @olang_textcopy(ptr %t16, ptr %t10, i64 %t11)
  %t17 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t13, 1
  %t20 = extractvalue { i64, ptr } %t18, 0
  %t21 = extractvalue { i64, ptr } %t18, 1
  %t22 = mul i64 %t20, 1
  %t23 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t22)
  call void @llvm.memcpy.p0.p0.i64(ptr %t23, ptr %t21, i64 %t22, i1 false)
  %t24 = insertvalue { i64, ptr } undef, i64 %t20, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t23, 1
  %t28 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t2, { i64, ptr } %t25)
  store { i64, ptr } %t28, ptr %l8
  br label %bb1
bb1:
  %t29 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t29, 0
  %t31 = extractvalue { i64, ptr } %t29, 1
  %t32 = mul i64 %t30, 1
  %t33 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t32)
  call void @llvm.memcpy.p0.p0.i64(ptr %t33, ptr %t31, i64 %t32, i1 false)
  %t34 = insertvalue { i64, ptr } undef, i64 %t30, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t33, 1
  %t36 = load ptr, ptr %l3, !tbaa !29
  %t38 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %t36, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d511, i32 0, i32 1) }, { i64, ptr } %t35, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d179, i32 0, i32 1) })
  store { i64, ptr } %t38, ptr %l10
  br label %bb2
bb2:
  %t39 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t40 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %t40, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d512, i32 0, i32 1) }, { i64, ptr } %t39, { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d513, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d173, i32 0, i32 1) })
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2euseRef(ptr %v0, ptr %v1, ptr %a0, { i64, [1 x i64] } %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [1 x i64] }
  %l3 = alloca i32
  %l7 = alloca { i64, ptr }
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store { i64, [1 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [1 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [1 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [1 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { i32 }, ptr %t6, i32 0, i32 0
  %t8 = load i32, ptr %t7
  store i32 %t8, ptr %l3, !tbaa !23
  br label %bb3
bb2:
  br label %bb4
bb3:
  store { i64, ptr } %a2, ptr %l7, !tbaa !27
  %t11 = load i32, ptr %l3, !tbaa !23
  %t13 = sext i32 %t11 to i64
  %t15 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !27
  %t17 = getelementptr i1, ptr %t16, i64 %t13
  store i1 true, ptr %t17, !tbaa !31
  store i1 false, ptr %rv
  br label %ret
bb4:
  %t19 = load { i64, [1 x i64] }, ptr %l1
  %t21 = extractvalue { i64, [1 x i64] } %t19, 0
  %t22 = icmp eq i64 %t21, 3
  br i1 %t22, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store i1 true, ptr %rv
  br label %ret
bb8:
  br i1 true, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store i1 false, ptr %rv
  br label %ret
bb12:
  call void @__olang_check_failed(ptr @olang_loc_7bc7193ce72d0d52_c947a9f9cc48c9f6)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2ewalkKey(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t3 = shl i64 %a1, 20
  %t6 = and i64 %a2, 1048575
  %t9 = or i64 %t3, %t6
  store i64 %t9, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2ewritesInto(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca %"compiler/mir:BasicBlock"
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca { i64, [21 x i64] }
  %l9 = alloca %"compiler/mir:Place"
  %l10 = alloca { i64, [15 x i64] }
  %l11 = alloca %"compiler/mir:Place"
  %l12 = alloca i32
  %l13 = alloca %"compiler/mir:Place"
  %l14 = alloca i32
  %l15 = alloca %"compiler/mir:Place"
  %l20 = alloca i64
  %l22 = alloca i64
  %l27 = alloca %"compiler/mir:BasicBlock"
  %l29 = alloca i64
  %l31 = alloca i64
  %l36 = alloca { i64, [21 x i64] }
  %l37 = alloca { i64, [21 x i64] }
  %l43 = alloca i1
  %l47 = alloca i1
  %l56 = alloca i1
  %l57 = alloca i1
  %l60 = alloca ptr
  %l65 = alloca i32
  %l66 = alloca i64
  %l78 = alloca i1
  %l79 = alloca i1
  %l82 = alloca ptr
  %l87 = alloca i32
  %l88 = alloca i64
  %l93 = alloca { i64, [21 x i64] }
  %l99 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t8 = getelementptr %"compiler/mir:Fn", ptr %t4, i32 0, i32 9
  store ptr %t8, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t10 = load i64, ptr %l4, !tbaa !24
  store i64 %t10, ptr %l20, !tbaa !24
  %t11 = load ptr, ptr %l3, !tbaa !29
  %t13 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eLen_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, ptr %t11)
  store i64 %t13, ptr %l22
  br label %bb2
bb2:
  %t14 = load i64, ptr %l20, !tbaa !24
  %t15 = load i64, ptr %l22, !tbaa !24
  %t16 = icmp slt i64 %t14, %t15
  %t18 = xor i1 %t16, true
  br i1 %t18, label %bb3, label %bb4
bb3:
  br label %bb71
bb4:
  br label %bb5
bb5:
  %t20 = load ptr, ptr %l3, !tbaa !29
  %t21 = load i64, ptr %l4, !tbaa !24
  %t24 = call %"compiler/mir:BasicBlock" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eAt_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, ptr %v0, ptr %t20, i64 %t21)
  store %"compiler/mir:BasicBlock" %t24, ptr %l27
  br label %bb6
bb6:
  %t25 = load %"compiler/mir:BasicBlock", ptr %l27
  store %"compiler/mir:BasicBlock" %t25, ptr %l5
  %t26 = getelementptr %"compiler/mir:BasicBlock", ptr %l5, i32 0, i32 0
  store ptr %t26, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  br label %bb7
bb7:
  %t28 = load i64, ptr %l7, !tbaa !24
  store i64 %t28, ptr %l29, !tbaa !24
  %t29 = load ptr, ptr %l6, !tbaa !29
  %t31 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aStmt_3e_2eLen_3ccompiler_2fmir_3aStmt_3e(ptr %v0, ptr %t29)
  store i64 %t31, ptr %l31
  br label %bb8
bb8:
  %t32 = load i64, ptr %l29, !tbaa !24
  %t33 = load i64, ptr %l31, !tbaa !24
  %t34 = icmp slt i64 %t32, %t33
  %t36 = xor i1 %t34, true
  br i1 %t36, label %bb9, label %bb10
bb9:
  br label %bb69
bb10:
  br label %bb11
bb11:
  %t38 = load ptr, ptr %l6, !tbaa !29
  %t39 = load i64, ptr %l7, !tbaa !24
  %t42 = call { i64, [21 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aStmt_3e_2eAt_3ccompiler_2fmir_3aStmt_3e(ptr %v0, ptr %t38, i64 %t39)
  store { i64, [21 x i64] } %t42, ptr %l36
  br label %bb12
bb12:
  call void @llvm.memmove.p0.p0.i64(ptr %l8, ptr %l36, i64 176, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l37, ptr %l8, i64 176, i1 false)
  %t43 = load { i64, [21 x i64] }, ptr %l37
  %t44 = extractvalue { i64, [21 x i64] } %t43, 0
  %t45 = icmp eq i64 %t44, 0
  br i1 %t45, label %bb13, label %bb14
bb13:
  %t47 = getelementptr { i64, [21 x i64] }, ptr %l8, i32 0, i32 1
  %t48 = getelementptr { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } }, ptr %t47, i32 0, i32 1
  %t49 = load %"compiler/mir:Place", ptr %t48
  store %"compiler/mir:Place" %t49, ptr %l9
  %t51 = getelementptr { i64, [21 x i64] }, ptr %l8, i32 0, i32 1
  %t52 = getelementptr { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } }, ptr %t51, i32 0, i32 2
  %t53 = load { i64, [15 x i64] }, ptr %t52
  store { i64, [15 x i64] } %t53, ptr %l10
  br label %bb15
bb14:
  br label %bb54
bb15:
  %t55 = getelementptr %"compiler/mir:Place", ptr %l9, i32 0, i32 1
  %t56 = getelementptr %"compiler/mir:Range", ptr %t55, i32 0, i32 1
  %t57 = load i32, ptr %t56, !tbaa !23
  %t59 = icmp sgt i32 %t57, 0
  br i1 %t59, label %bb16, label %bb17
bb16:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = load %"compiler/mir:Place", ptr %l9
  %t63 = load i32, ptr %l1, !tbaa !23
  %t67 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2ebaseIs(ptr %v0, ptr %t61, %"compiler/mir:Place" %t62, i32 %t63)
  store i1 %t67, ptr %l47
  br label %bb18
bb17:
  store i1 false, ptr %l43, !tbaa !21
  br label %bb19
bb18:
  %t68 = load i1, ptr %l47, !tbaa !21
  store i1 %t68, ptr %l43, !tbaa !21
  br label %bb19
bb19:
  %t69 = load i1, ptr %l43, !tbaa !21
  br i1 %t69, label %bb20, label %bb21
bb20:
  store i1 true, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  %t71 = load { i64, [15 x i64] }, ptr %l10
  %t73 = extractvalue { i64, [15 x i64] } %t71, 0
  %t74 = icmp eq i64 %t73, 1
  br i1 %t74, label %bb23, label %bb24
bb23:
  %t76 = getelementptr { i64, [15 x i64] }, ptr %l10, i32 0, i32 1
  %t77 = getelementptr { %"compiler/mir:Place", i32 }, ptr %t76, i32 0, i32 0
  %t78 = load %"compiler/mir:Place", ptr %t77
  store %"compiler/mir:Place" %t78, ptr %l11
  %t80 = getelementptr { i64, [15 x i64] }, ptr %l10, i32 0, i32 1
  %t81 = getelementptr { %"compiler/mir:Place", i32 }, ptr %t80, i32 0, i32 1
  %t82 = load i32, ptr %t81
  store i32 %t82, ptr %l12, !tbaa !23
  br label %bb25
bb24:
  br label %bb35
bb25:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t85 = load %"compiler/mir:Place", ptr %l11
  %t86 = load i32, ptr %l1, !tbaa !23
  %t90 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2ebaseIs(ptr %v0, ptr %t84, %"compiler/mir:Place" %t85, i32 %t86)
  store i1 %t90, ptr %l56
  br label %bb26
bb26:
  %t91 = load i1, ptr %l56, !tbaa !21
  br i1 %t91, label %bb27, label %bb28
bb27:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/emit:fnEm", ptr %t92, i32 0, i32 0
  %t95 = load ptr, ptr %t94, !tbaa !29
  %t97 = getelementptr %"compiler/emit:Emitter", ptr %t95, i32 0, i32 3
  %t98 = load ptr, ptr %t97, !tbaa !29
  store ptr %t98, ptr %l60, !tbaa !29
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/emit:fnEm", ptr %t99, i32 0, i32 0
  %t102 = load ptr, ptr %t101, !tbaa !29
  %t104 = getelementptr %"compiler/emit:Emitter", ptr %t102, i32 0, i32 3
  %t105 = load ptr, ptr %t104, !tbaa !29
  %t106 = load i32, ptr %l12, !tbaa !23
  %t109 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t105, i32 %t106)
  store i32 %t109, ptr %l65
  br label %bb29
bb28:
  store i1 false, ptr %l57, !tbaa !21
  br label %bb31
bb29:
  %t110 = load ptr, ptr %l60, !tbaa !29
  %t111 = load i32, ptr %l65, !tbaa !23
  %t112 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t110, i32 %t111)
  store i64 %t112, ptr %l66
  br label %bb30
bb30:
  %t113 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t114 = load i64, ptr %l66, !tbaa !24
  %t116 = and i64 %t114, %t113
  %t118 = icmp ne i64 %t116, 0
  store i1 %t118, ptr %l57, !tbaa !21
  br label %bb31
bb31:
  %t120 = load i1, ptr %l57, !tbaa !21
  br i1 %t120, label %bb32, label %bb33
bb32:
  store i1 true, ptr %rv
  br label %ret
bb33:
  br label %bb34
bb34:
  br label %bb53
bb35:
  %t122 = load { i64, [15 x i64] }, ptr %l10
  %t124 = extractvalue { i64, [15 x i64] } %t122, 0
  %t125 = icmp eq i64 %t124, 9
  br i1 %t125, label %bb36, label %bb37
bb36:
  %t127 = getelementptr { i64, [15 x i64] }, ptr %l10, i32 0, i32 1
  %t128 = getelementptr { %"compiler/mir:Place", { i64, [4 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t127, i32 0, i32 0
  %t129 = load %"compiler/mir:Place", ptr %t128
  store %"compiler/mir:Place" %t129, ptr %l13
  %t131 = getelementptr { i64, [15 x i64] }, ptr %l10, i32 0, i32 1
  %t132 = getelementptr { %"compiler/mir:Place", { i64, [4 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t131, i32 0, i32 3
  %t133 = load i32, ptr %t132
  store i32 %t133, ptr %l14, !tbaa !23
  br label %bb38
bb37:
  br label %bb48
bb38:
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t136 = load %"compiler/mir:Place", ptr %l13
  %t137 = load i32, ptr %l1, !tbaa !23
  %t141 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2ebaseIs(ptr %v0, ptr %t135, %"compiler/mir:Place" %t136, i32 %t137)
  store i1 %t141, ptr %l78
  br label %bb39
bb39:
  %t142 = load i1, ptr %l78, !tbaa !21
  br i1 %t142, label %bb40, label %bb41
bb40:
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t145 = getelementptr %"compiler/emit:fnEm", ptr %t143, i32 0, i32 0
  %t146 = load ptr, ptr %t145, !tbaa !29
  %t148 = getelementptr %"compiler/emit:Emitter", ptr %t146, i32 0, i32 3
  %t149 = load ptr, ptr %t148, !tbaa !29
  store ptr %t149, ptr %l82, !tbaa !29
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t152 = getelementptr %"compiler/emit:fnEm", ptr %t150, i32 0, i32 0
  %t153 = load ptr, ptr %t152, !tbaa !29
  %t155 = getelementptr %"compiler/emit:Emitter", ptr %t153, i32 0, i32 3
  %t156 = load ptr, ptr %t155, !tbaa !29
  %t157 = load i32, ptr %l14, !tbaa !23
  %t160 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t156, i32 %t157)
  store i32 %t160, ptr %l87
  br label %bb42
bb41:
  store i1 false, ptr %l79, !tbaa !21
  br label %bb44
bb42:
  %t161 = load ptr, ptr %l82, !tbaa !29
  %t162 = load i32, ptr %l87, !tbaa !23
  %t163 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t161, i32 %t162)
  store i64 %t163, ptr %l88
  br label %bb43
bb43:
  %t164 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t165 = load i64, ptr %l88, !tbaa !24
  %t167 = and i64 %t165, %t164
  %t169 = icmp ne i64 %t167, 0
  store i1 %t169, ptr %l79, !tbaa !21
  br label %bb44
bb44:
  %t171 = load i1, ptr %l79, !tbaa !21
  br i1 %t171, label %bb45, label %bb46
bb45:
  store i1 true, ptr %rv
  br label %ret
bb46:
  br label %bb47
bb47:
  br label %bb53
bb48:
  br i1 true, label %bb49, label %bb50
bb49:
  br label %bb51
bb50:
  br label %bb52
bb51:
  br label %bb53
bb52:
  call void @__olang_check_failed(ptr @olang_loc_5dfa9b7395be5458_e24cfc313725a25c)
  unreachable
bb53:
  br label %bb67
bb54:
  call void @llvm.memmove.p0.p0.i64(ptr %l93, ptr %l8, i64 176, i1 false)
  %t173 = load { i64, [21 x i64] }, ptr %l93
  %t174 = extractvalue { i64, [21 x i64] } %t173, 0
  %t175 = icmp eq i64 %t174, 10
  br i1 %t175, label %bb55, label %bb56
bb55:
  %t177 = getelementptr { i64, [21 x i64] }, ptr %l8, i32 0, i32 1
  %t178 = getelementptr { %"compiler/source:Span", %"compiler/mir:Place", %"compiler/mir:Place", { i64, [4 x i64] } }, ptr %t177, i32 0, i32 1
  %t179 = load %"compiler/mir:Place", ptr %t178
  store %"compiler/mir:Place" %t179, ptr %l15
  br label %bb57
bb56:
  br label %bb62
bb57:
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t182 = load %"compiler/mir:Place", ptr %l15
  %t183 = load i32, ptr %l1, !tbaa !23
  %t187 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2ebaseIs(ptr %v0, ptr %t181, %"compiler/mir:Place" %t182, i32 %t183)
  store i1 %t187, ptr %l99
  br label %bb58
bb58:
  %t188 = load i1, ptr %l99, !tbaa !21
  br i1 %t188, label %bb59, label %bb60
bb59:
  store i1 true, ptr %rv
  br label %ret
bb60:
  br label %bb61
bb61:
  br label %bb67
bb62:
  br i1 true, label %bb63, label %bb64
bb63:
  br label %bb65
bb64:
  br label %bb66
bb65:
  br label %bb67
bb66:
  call void @__olang_check_failed(ptr @olang_loc_cd3d2f4cb5172729_796de8126c3e3b8d)
  unreachable
bb67:
  br label %bb68
bb68:
  %t190 = load i64, ptr %l7, !tbaa !24
  %t192 = add i64 %t190, 1
  store i64 %t192, ptr %l7, !tbaa !24
  br label %bb7
bb69:
  br label %bb70
bb70:
  %t194 = load i64, ptr %l4, !tbaa !24
  %t196 = add i64 %t194, 1
  store i64 %t196, ptr %l4, !tbaa !24
  br label %bb1
bb71:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ehexByte(ptr %v0, i8 %a0) #0 {
entry:
  %l0 = alloca i8
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store i8 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d514, i32 0, i32 1) }, ptr %l2, !tbaa !27
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t1, ptr %l3, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t2, 0
  store i64 %t3, ptr %l4, !tbaa !24
  %t4 = load i64, ptr %l4, !tbaa !24
  %t5 = mul i64 %t4, 1
  %t6 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t5)
  %t7 = insertvalue { i64, ptr } undef, i64 %t4, 0
  %t8 = insertvalue { i64, ptr } %t7, ptr %t6, 1
  store { i64, ptr } %t8, ptr %l5, !tbaa !27
  %t9 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !27
  %t11 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !27
  %t13 = load i64, ptr %l4, !tbaa !24
  %t14 = mul i64 %t13, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t10, ptr %t12, i64 %t14, i1 false)
  %t15 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t15, ptr %l1, !tbaa !27
  %t16 = load i8, ptr %l0, !tbaa !22
  %t18 = lshr i8 %t16, 4
  %t20 = zext i8 %t18 to i64
  %t22 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = getelementptr i8, ptr %t23, i64 %t20
  %t25 = load i8, ptr %t24, !tbaa !32
  %t26 = load i8, ptr %l0, !tbaa !22
  %t28 = and i8 %t26, 15
  %t30 = zext i8 %t28 to i64
  %t32 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !27
  %t34 = getelementptr i8, ptr %t33, i64 %t30
  %t35 = load i8, ptr %t34, !tbaa !32
  %t36 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d515, i32 0, i32 1) }, 1
  %t37 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d515, i32 0, i32 1) }, 0
  %t39 = add i64 %t37, 1
  %t41 = add i64 %t39, 1
  %t42 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t41)
  call void @olang_textcopy(ptr %t42, ptr %t36, i64 %t37)
  %t43 = getelementptr i8, ptr %t42, i64 %t37
  store i8 %t25, ptr %t43
  %t44 = getelementptr i8, ptr %t43, i64 1
  store i8 %t35, ptr %t44
  %t45 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t46 = insertvalue { i64, ptr } %t45, ptr %t42, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t46, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2femit_2ehexDigits_2einit() #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l3 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d516, i32 0, i32 1) }, ptr %l0, !tbaa !27
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l1, !tbaa !27
  %t2 = load { i64, ptr }, ptr @G_2ecompiler_2femit_2ehexDigits, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t2, 0
  %t4 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t4, 0
  store i64 %t5, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = icmp eq i64 %t3, %t7
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = getelementptr { i64, ptr }, ptr @G_2ecompiler_2femit_2ehexDigits, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = load i64, ptr %l3, !tbaa !24
  %t15 = mul i64 %t14, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t11, ptr %t13, i64 %t15, i1 false)
  br label %bb3
bb2:
  %t16 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t16, 0
  store i64 %t17, ptr %l5, !tbaa !24
  %t18 = load i64, ptr %l5, !tbaa !24
  %t19 = mul i64 %t18, 1
  %t20 = load ptr, ptr @__olang_prog_scope
  %t21 = call ptr @__olang_scope_alloc(ptr %t20, i64 %t19)
  %t22 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t21, 1
  store { i64, ptr } %t23, ptr %l6, !tbaa !27
  %t24 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = load i64, ptr %l5, !tbaa !24
  %t29 = mul i64 %t28, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t25, ptr %t27, i64 %t29, i1 false)
  %t30 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t30, ptr @G_2ecompiler_2femit_2ehexDigits, !tbaa !27
  br label %bb3
bb3:
  br label %ret
ret:
  ret void
}

define dso_local %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2femit_2emathInexactTable(ptr %v0) #0 {
entry:
  %lp0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l6 = alloca [22 x { i64, ptr }]
  %s1 = alloca %olang.scope
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l5
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 8, i64 8)
  store ptr %t2, ptr %lp0
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l5
  %t4 = load ptr, ptr %lp0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %t4
  store %olang.scope zeroinitializer, ptr %s1
  %t5 = getelementptr [22 x { i64, ptr }], ptr %l6, i64 0, i64 0
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d517, i32 0, i32 1) }, ptr %t5
  %t6 = getelementptr [22 x { i64, ptr }], ptr %l6, i64 0, i64 1
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d518, i32 0, i32 1) }, ptr %t6
  %t7 = getelementptr [22 x { i64, ptr }], ptr %l6, i64 0, i64 2
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d519, i32 0, i32 1) }, ptr %t7
  %t8 = getelementptr [22 x { i64, ptr }], ptr %l6, i64 0, i64 3
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d520, i32 0, i32 1) }, ptr %t8
  %t9 = getelementptr [22 x { i64, ptr }], ptr %l6, i64 0, i64 4
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d521, i32 0, i32 1) }, ptr %t9
  %t10 = getelementptr [22 x { i64, ptr }], ptr %l6, i64 0, i64 5
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d522, i32 0, i32 1) }, ptr %t10
  %t11 = getelementptr [22 x { i64, ptr }], ptr %l6, i64 0, i64 6
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d523, i32 0, i32 1) }, ptr %t11
  %t12 = getelementptr [22 x { i64, ptr }], ptr %l6, i64 0, i64 7
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d524, i32 0, i32 1) }, ptr %t12
  %t13 = getelementptr [22 x { i64, ptr }], ptr %l6, i64 0, i64 8
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d525, i32 0, i32 1) }, ptr %t13
  %t14 = getelementptr [22 x { i64, ptr }], ptr %l6, i64 0, i64 9
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d526, i32 0, i32 1) }, ptr %t14
  %t15 = getelementptr [22 x { i64, ptr }], ptr %l6, i64 0, i64 10
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d527, i32 0, i32 1) }, ptr %t15
  %t16 = getelementptr [22 x { i64, ptr }], ptr %l6, i64 0, i64 11
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d528, i32 0, i32 1) }, ptr %t16
  %t17 = getelementptr [22 x { i64, ptr }], ptr %l6, i64 0, i64 12
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d529, i32 0, i32 1) }, ptr %t17
  %t18 = getelementptr [22 x { i64, ptr }], ptr %l6, i64 0, i64 13
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d530, i32 0, i32 1) }, ptr %t18
  %t19 = getelementptr [22 x { i64, ptr }], ptr %l6, i64 0, i64 14
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d531, i32 0, i32 1) }, ptr %t19
  %t20 = getelementptr [22 x { i64, ptr }], ptr %l6, i64 0, i64 15
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d532, i32 0, i32 1) }, ptr %t20
  %t21 = getelementptr [22 x { i64, ptr }], ptr %l6, i64 0, i64 16
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d533, i32 0, i32 1) }, ptr %t21
  %t22 = getelementptr [22 x { i64, ptr }], ptr %l6, i64 0, i64 17
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d534, i32 0, i32 1) }, ptr %t22
  %t23 = getelementptr [22 x { i64, ptr }], ptr %l6, i64 0, i64 18
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d535, i32 0, i32 1) }, ptr %t23
  %t24 = getelementptr [22 x { i64, ptr }], ptr %l6, i64 0, i64 19
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d536, i32 0, i32 1) }, ptr %t24
  %t25 = getelementptr [22 x { i64, ptr }], ptr %l6, i64 0, i64 20
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d537, i32 0, i32 1) }, ptr %t25
  %t26 = getelementptr [22 x { i64, ptr }], ptr %l6, i64 0, i64 21
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d538, i32 0, i32 1) }, ptr %t26
  %t27 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 352, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t27, ptr %l6, i64 352, i1 false)
  store ptr %t27, ptr %l1
  store i64 0, ptr %l2, !tbaa !24
  %t29 = load ptr, ptr %l1
  store i64 22, ptr %l3, !tbaa !24
  br label %bb2
bb2:
  %t32 = load i64, ptr %l2, !tbaa !24
  %t33 = load i64, ptr %l3, !tbaa !24
  %t36 = icmp slt i64 %t32, %t33
  %t38 = xor i1 %t36, true
  br i1 %t38, label %bb3, label %bb4
bb3:
  br label %bb9
bb4:
  br label %bb5
bb5:
  %t40 = load ptr, ptr %l1
  %t41 = load i64, ptr %l2, !tbaa !24
  %t44 = getelementptr [22 x { i64, ptr }], ptr %t40, i64 0, i64 %t41
  %t45 = load { i64, ptr }, ptr %t44, !tbaa !37
  store { i64, ptr } %t45, ptr %l4, !tbaa !27
  %t47 = load ptr, ptr %lp0
  %t48 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t49 = load ptr, ptr @__olang_prog_scope
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H2b85ceff512af6e6ca26c554a1c16247(ptr %v0, ptr %t49, ptr %t47, { i64, ptr } %t48, i1 true)
  br label %bb6
bb6:
  %t52 = load ptr, ptr %lp0
  %t53 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t55 = extractvalue { i64, ptr } %t53, 1
  %t56 = extractvalue { i64, ptr } %t53, 0
  %t57 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d539, i32 0, i32 1) }, 1
  %t58 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d539, i32 0, i32 1) }, 0
  %t59 = add i64 %t56, %t58
  %t60 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t59)
  call void @olang_textcopy(ptr %t60, ptr %t55, i64 %t56)
  %t61 = getelementptr i8, ptr %t60, i64 %t56
  call void @olang_textcopy(ptr %t61, ptr %t57, i64 %t58)
  %t62 = insertvalue { i64, ptr } undef, i64 %t59, 0
  %t63 = insertvalue { i64, ptr } %t62, ptr %t60, 1
  %t65 = extractvalue { i64, ptr } %t63, 0
  %t66 = extractvalue { i64, ptr } %t63, 1
  %t67 = mul i64 %t65, 1
  %t68 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t67)
  call void @llvm.memcpy.p0.p0.i64(ptr %t68, ptr %t66, i64 %t67, i1 false)
  %t69 = insertvalue { i64, ptr } undef, i64 %t65, 0
  %t70 = insertvalue { i64, ptr } %t69, ptr %t68, 1
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H2b85ceff512af6e6ca26c554a1c16247(ptr %v0, ptr %v0, ptr %t52, { i64, ptr } %t70, i1 true)
  br label %bb7
bb7:
  br label %bb8
bb8:
  %t73 = load i64, ptr %l2, !tbaa !24
  %t75 = add i64 %t73, 1
  store i64 %t75, ptr %l2, !tbaa !24
  br label %bb2
bb9:
  call void @__olang_scope_close(ptr %s1)
  %t77 = load ptr, ptr %lp0
  %t78 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t77
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t78, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local i64 @compiler_2femit_2emetaNumber(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca i1
  %l6 = alloca ptr
  %l7 = alloca i64
  %l9 = alloca i64
  %l11 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i32
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %t1, i64 %t2)
  store i1 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i1, ptr %l4, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load ptr, ptr %l0, !tbaa !29
  store ptr %t9, ptr %l6, !tbaa !29
  %t10 = load i64, ptr %l1, !tbaa !24
  store i64 %t10, ptr %l7, !tbaa !24
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eLen_3cI64_2c_20I64_3e(ptr %v0, ptr %t11)
  store i64 %t13, ptr %l9
  br label %bb4
bb3:
  br label %bb6
bb4:
  %t14 = load i64, ptr %l9, !tbaa !24
  %t15 = add i64 1000, %t14
  %t16 = load ptr, ptr %l6, !tbaa !29
  %t17 = load i64, ptr %l7, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t16, i64 %t17, i64 %t15)
  br label %bb5
bb5:
  br label %bb6
bb6:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t20 = load i64, ptr %l1, !tbaa !24
  %t23 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t19, i64 %t20)
  %t24 = extractvalue { i32, i64 } %t23, 1
  %t25 = extractvalue { i32, i64 } %t23, 0
  store i32 %t25, ptr %l15
  %t26 = icmp ne i32 %t25, 0
  br i1 %t26, label %bb8, label %ok.27
ok.27:
  store i64 %t24, ptr %l14
  br label %bb7
bb7:
  %t28 = load i64, ptr %l14, !tbaa !24
  store i64 %t28, ptr %l11, !tbaa !24
  br label %bb10
bb8:
  br label %bb9
bb9:
  call void @__olang_ert_req_clear()
  store i64 0, ptr %l11, !tbaa !24
  br label %bb10
bb10:
  %t29 = load i64, ptr %l11, !tbaa !24
  store i64 %t29, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2femit_2etbaaElem_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  %t1 = insertvalue [15 x i64] undef, i64 0, 0
  %t2 = insertvalue [15 x i64] %t1, i64 0, 1
  %t3 = insertvalue [15 x i64] %t2, i64 31, 2
  %t4 = insertvalue [15 x i64] %t3, i64 81, 3
  %t5 = insertvalue [15 x i64] %t4, i64 82, 4
  %t6 = insertvalue [15 x i64] %t5, i64 33, 5
  %t7 = insertvalue [15 x i64] %t6, i64 34, 6
  %t8 = insertvalue [15 x i64] %t7, i64 32, 7
  %t9 = insertvalue [15 x i64] %t8, i64 83, 8
  %t10 = insertvalue [15 x i64] %t9, i64 84, 9
  %t11 = insertvalue [15 x i64] %t10, i64 85, 10
  %t12 = insertvalue [15 x i64] %t11, i64 86, 11
  %t13 = insertvalue [15 x i64] %t12, i64 87, 12
  %t14 = insertvalue [15 x i64] %t13, i64 35, 13
  %t15 = insertvalue [15 x i64] %t14, i64 36, 14
  store [15 x i64] %t15, ptr @G_2ecompiler_2femit_2etbaaElem
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2femit_2etbaaName_2einit() #0 {
entry:
  %l0 = alloca [15 x { i64, ptr }]
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr [15 x { i64, ptr }], ptr %l0, i64 0, i64 0
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d540, i32 0, i32 1) }, ptr %t1, !tbaa !37
  %t2 = getelementptr [15 x { i64, ptr }], ptr %l0, i64 0, i64 1
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d541, i32 0, i32 1) }, ptr %t2, !tbaa !37
  %t3 = getelementptr [15 x { i64, ptr }], ptr %l0, i64 0, i64 2
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d542, i32 0, i32 1) }, ptr %t3, !tbaa !37
  %t4 = getelementptr [15 x { i64, ptr }], ptr %l0, i64 0, i64 3
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d543, i32 0, i32 1) }, ptr %t4, !tbaa !37
  %t5 = getelementptr [15 x { i64, ptr }], ptr %l0, i64 0, i64 4
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d544, i32 0, i32 1) }, ptr %t5, !tbaa !37
  %t6 = getelementptr [15 x { i64, ptr }], ptr %l0, i64 0, i64 5
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d545, i32 0, i32 1) }, ptr %t6, !tbaa !37
  %t7 = getelementptr [15 x { i64, ptr }], ptr %l0, i64 0, i64 6
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d546, i32 0, i32 1) }, ptr %t7, !tbaa !37
  %t8 = getelementptr [15 x { i64, ptr }], ptr %l0, i64 0, i64 7
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d547, i32 0, i32 1) }, ptr %t8, !tbaa !37
  %t9 = getelementptr [15 x { i64, ptr }], ptr %l0, i64 0, i64 8
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d548, i32 0, i32 1) }, ptr %t9, !tbaa !37
  %t10 = getelementptr [15 x { i64, ptr }], ptr %l0, i64 0, i64 9
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d549, i32 0, i32 1) }, ptr %t10, !tbaa !37
  %t11 = getelementptr [15 x { i64, ptr }], ptr %l0, i64 0, i64 10
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d550, i32 0, i32 1) }, ptr %t11, !tbaa !37
  %t12 = getelementptr [15 x { i64, ptr }], ptr %l0, i64 0, i64 11
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d551, i32 0, i32 1) }, ptr %t12, !tbaa !37
  %t13 = getelementptr [15 x { i64, ptr }], ptr %l0, i64 0, i64 12
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d552, i32 0, i32 1) }, ptr %t13, !tbaa !37
  %t14 = getelementptr [15 x { i64, ptr }], ptr %l0, i64 0, i64 13
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d553, i32 0, i32 1) }, ptr %t14, !tbaa !37
  %t15 = getelementptr [15 x { i64, ptr }], ptr %l0, i64 0, i64 14
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d554, i32 0, i32 1) }, ptr %t15, !tbaa !37
  call void @llvm.memmove.p0.p0.i64(ptr @G_2ecompiler_2femit_2etbaaName, ptr %l0, i64 240, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/emit:Reused" @compiler_2femit_3aReused_2ector(ptr %v0, i64 %a0) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l3 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l4 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l5 = alloca i64
  %l6 = alloca i1
  %l10 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l11 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l12 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l13 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"compiler/emit:Reused"
  br label %start
start:
  br label %bb0
bb0:
  store i64 %a0, ptr %l1, !tbaa !24
  %t3 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %l10
  br label %bb1
bb1:
  %t4 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l10
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t4, ptr %l2
  %t5 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t5, ptr %l11
  br label %bb2
bb2:
  %t6 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l11
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t6, ptr %l3
  %t7 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t7, ptr %l12
  br label %bb3
bb3:
  %t8 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l12
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t8, ptr %l4
  store i64 0, ptr %l5, !tbaa !24
  store i1 false, ptr %l6, !tbaa !21
  %t9 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t9, ptr %l13
  br label %bb4
bb4:
  %t10 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l13
  %t11 = load i64, ptr %l1, !tbaa !24
  %t12 = insertvalue %"compiler/emit:Reused" undef, i64 %t11, 0
  %t13 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l2
  %t14 = insertvalue %"compiler/emit:Reused" %t12, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t13, 1
  %t15 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l3
  %t16 = insertvalue %"compiler/emit:Reused" %t14, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t15, 2
  %t17 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l4
  %t18 = insertvalue %"compiler/emit:Reused" %t16, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t17, 3
  %t19 = load i64, ptr %l5, !tbaa !24
  %t20 = insertvalue %"compiler/emit:Reused" %t18, i64 %t19, 4
  %t21 = load i1, ptr %l6, !tbaa !21
  %t22 = insertvalue %"compiler/emit:Reused" %t20, i1 %t21, 5
  %t24 = insertvalue %"compiler/emit:Reused" %t22, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t10, 6
  %t26 = insertvalue %"compiler/emit:Reused" %t24, i64 -1, 7
  store %"compiler/emit:Reused" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/emit:Reused", ptr %rv
  ret %"compiler/emit:Reused" %rr
}

define dso_local void @compiler_2femit_3afnEm_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, [2 x i64] } %a2) #0 {
entry:
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca { i64, [2 x i64] }
  %l6 = alloca %"std/prelude/text:StringBuilder"
  %l7 = alloca %"std/prelude/text:StringBuilder"
  %l8 = alloca %"std/prelude/text:StringBuilder"
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i32
  %l13 = alloca i1
  %l14 = alloca i1
  %l15 = alloca i1
  %l16 = alloca i1
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l20 = alloca i64
  %l21 = alloca { i64, ptr }
  %l22 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l23 = alloca %"std/prelude/text:StringBuilder"
  %l24 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l25 = alloca i1
  %l26 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l27 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l28 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l29 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l30 = alloca i1
  %l31 = alloca { i64, ptr }
  %l32 = alloca i1
  %l33 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l34 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l42 = alloca %"std/prelude/text:StringBuilder"
  %l43 = alloca %"std/prelude/text:StringBuilder"
  %l44 = alloca %"std/prelude/text:StringBuilder"
  %l46 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l47 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l48 = alloca %"std/prelude/text:StringBuilder"
  %l49 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l50 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l51 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l52 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l53 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l54 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l55 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l56 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l57 = alloca %"compiler/emit:fnEm"
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l3, !tbaa !29
  store ptr %a1, ptr %l4, !tbaa !29
  store { i64, [2 x i64] } %a2, ptr %l5
  %t7 = call %"std/prelude/text:StringBuilder" @olang_2eHelperKind_2eZero_2estd_2fprelude_2ftext_3aStringBuilder(ptr %v2)
  store %"std/prelude/text:StringBuilder" %t7, ptr %l42
  br label %bb1
bb1:
  %t8 = load %"std/prelude/text:StringBuilder", ptr %l42
  store %"std/prelude/text:StringBuilder" %t8, ptr %l6
  %t9 = call %"std/prelude/text:StringBuilder" @olang_2eHelperKind_2eZero_2estd_2fprelude_2ftext_3aStringBuilder(ptr %v2)
  store %"std/prelude/text:StringBuilder" %t9, ptr %l43
  br label %bb2
bb2:
  %t10 = load %"std/prelude/text:StringBuilder", ptr %l43
  store %"std/prelude/text:StringBuilder" %t10, ptr %l7
  %t11 = call %"std/prelude/text:StringBuilder" @olang_2eHelperKind_2eZero_2estd_2fprelude_2ftext_3aStringBuilder(ptr %v2)
  store %"std/prelude/text:StringBuilder" %t11, ptr %l44
  br label %bb3
bb3:
  %t12 = load %"std/prelude/text:StringBuilder", ptr %l44
  store %"std/prelude/text:StringBuilder" %t12, ptr %l8
  store i64 0, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  store i64 -1, ptr %l11, !tbaa !24
  %t13 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  store i32 %t13, ptr %l12, !tbaa !23
  store i1 false, ptr %l13, !tbaa !21
  store i1 false, ptr %l14, !tbaa !21
  store i1 false, ptr %l15, !tbaa !21
  store i1 false, ptr %l16, !tbaa !21
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d555, i32 0, i32 1) }, ptr %l17, !tbaa !27
  store i64 0, ptr %l18, !tbaa !24
  %t15 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_Hf48d6d4096e547b8075d5a903caa3d54(ptr %v2)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t15, ptr %l46
  br label %bb4
bb4:
  %t16 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l46
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t16, ptr %l19
  store i64 -1, ptr %l20, !tbaa !24
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d556, i32 0, i32 1) }, ptr %l21, !tbaa !27
  %t17 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v2)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t17, ptr %l47
  br label %bb5
bb5:
  %t18 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l47
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t18, ptr %l22
  %t19 = call %"std/prelude/text:StringBuilder" @olang_2eHelperKind_2eZero_2estd_2fprelude_2ftext_3aStringBuilder(ptr %v2)
  store %"std/prelude/text:StringBuilder" %t19, ptr %l48
  br label %bb6
bb6:
  %t20 = load %"std/prelude/text:StringBuilder", ptr %l48
  store %"std/prelude/text:StringBuilder" %t20, ptr %l23
  %t21 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI32_2c_20I64_3e(ptr %v2)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t21, ptr %l49
  br label %bb7
bb7:
  %t22 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l49
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t22, ptr %l24
  store i1 false, ptr %l25, !tbaa !21
  %t23 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v2)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t23, ptr %l50
  br label %bb8
bb8:
  %t24 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l50
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t24, ptr %l26
  %t25 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v2)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t25, ptr %l51
  br label %bb9
bb9:
  %t26 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l51
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t26, ptr %l27
  %t27 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aWriteKind_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t27, ptr %l52
  br label %bb10
bb10:
  %t28 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l52
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t28, ptr %l28
  %t29 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t29, ptr %l53
  br label %bb11
bb11:
  %t30 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l53
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t30, ptr %l29
  store i1 false, ptr %l30, !tbaa !21
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d557, i32 0, i32 1) }, ptr %l31, !tbaa !27
  store i1 false, ptr %l32, !tbaa !21
  %t31 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v2)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t31, ptr %l54
  br label %bb12
bb12:
  %t32 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l54
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t32, ptr %l33
  %t33 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v2)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t33, ptr %l55
  br label %bb13
bb13:
  %t34 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l55
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t34, ptr %l34
  %t35 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v2)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t35, ptr %l56
  br label %bb14
bb14:
  %t36 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l56
  %t37 = getelementptr %"compiler/emit:fnEm", ptr %l57, i32 0, i32 0
  %t38 = load ptr, ptr %l3, !tbaa !29
  store ptr %t38, ptr %t37, !tbaa !29
  %t39 = getelementptr %"compiler/emit:fnEm", ptr %l57, i32 0, i32 1
  %t40 = load ptr, ptr %l4, !tbaa !29
  store ptr %t40, ptr %t39, !tbaa !29
  %t41 = getelementptr %"compiler/emit:fnEm", ptr %l57, i32 0, i32 2
  %t42 = load { i64, [2 x i64] }, ptr %l5
  store { i64, [2 x i64] } %t42, ptr %t41
  %t43 = getelementptr %"compiler/emit:fnEm", ptr %l57, i32 0, i32 3
  %t44 = load %"std/prelude/text:StringBuilder", ptr %l6
  store %"std/prelude/text:StringBuilder" %t44, ptr %t43
  %t45 = getelementptr %"compiler/emit:fnEm", ptr %l57, i32 0, i32 4
  %t46 = load %"std/prelude/text:StringBuilder", ptr %l7
  store %"std/prelude/text:StringBuilder" %t46, ptr %t45
  %t47 = getelementptr %"compiler/emit:fnEm", ptr %l57, i32 0, i32 5
  %t48 = load %"std/prelude/text:StringBuilder", ptr %l8
  store %"std/prelude/text:StringBuilder" %t48, ptr %t47
  %t49 = getelementptr %"compiler/emit:fnEm", ptr %l57, i32 0, i32 6
  %t50 = load i64, ptr %l9, !tbaa !24
  store i64 %t50, ptr %t49, !tbaa !24
  %t51 = getelementptr %"compiler/emit:fnEm", ptr %l57, i32 0, i32 7
  %t52 = load i64, ptr %l10, !tbaa !24
  store i64 %t52, ptr %t51, !tbaa !24
  %t53 = getelementptr %"compiler/emit:fnEm", ptr %l57, i32 0, i32 8
  %t54 = load i64, ptr %l11, !tbaa !24
  store i64 %t54, ptr %t53, !tbaa !24
  %t55 = getelementptr %"compiler/emit:fnEm", ptr %l57, i32 0, i32 9
  %t56 = load i32, ptr %l12, !tbaa !23
  store i32 %t56, ptr %t55, !tbaa !23
  %t57 = getelementptr %"compiler/emit:fnEm", ptr %l57, i32 0, i32 10
  %t58 = load i1, ptr %l13, !tbaa !21
  store i1 %t58, ptr %t57, !tbaa !21
  %t59 = getelementptr %"compiler/emit:fnEm", ptr %l57, i32 0, i32 11
  %t60 = load i1, ptr %l14, !tbaa !21
  store i1 %t60, ptr %t59, !tbaa !21
  %t61 = getelementptr %"compiler/emit:fnEm", ptr %l57, i32 0, i32 12
  %t62 = load i1, ptr %l15, !tbaa !21
  store i1 %t62, ptr %t61, !tbaa !21
  %t63 = getelementptr %"compiler/emit:fnEm", ptr %l57, i32 0, i32 13
  %t64 = load i1, ptr %l16, !tbaa !21
  store i1 %t64, ptr %t63, !tbaa !21
  %t65 = getelementptr %"compiler/emit:fnEm", ptr %l57, i32 0, i32 14
  %t66 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t66, ptr %t65, !tbaa !27
  %t67 = getelementptr %"compiler/emit:fnEm", ptr %l57, i32 0, i32 15
  %t68 = load i64, ptr %l18, !tbaa !24
  store i64 %t68, ptr %t67, !tbaa !24
  %t69 = getelementptr %"compiler/emit:fnEm", ptr %l57, i32 0, i32 16
  %t70 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l19
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t70, ptr %t69
  %t71 = getelementptr %"compiler/emit:fnEm", ptr %l57, i32 0, i32 17
  %t72 = load i64, ptr %l20, !tbaa !24
  store i64 %t72, ptr %t71, !tbaa !24
  %t73 = getelementptr %"compiler/emit:fnEm", ptr %l57, i32 0, i32 18
  %t74 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t74, ptr %t73, !tbaa !27
  %t75 = getelementptr %"compiler/emit:fnEm", ptr %l57, i32 0, i32 19
  %t76 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l22
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t76, ptr %t75
  %t77 = getelementptr %"compiler/emit:fnEm", ptr %l57, i32 0, i32 20
  %t78 = load %"std/prelude/text:StringBuilder", ptr %l23
  store %"std/prelude/text:StringBuilder" %t78, ptr %t77
  %t79 = getelementptr %"compiler/emit:fnEm", ptr %l57, i32 0, i32 21
  %t80 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l24
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t80, ptr %t79
  %t81 = getelementptr %"compiler/emit:fnEm", ptr %l57, i32 0, i32 22
  %t82 = load i1, ptr %l25, !tbaa !21
  store i1 %t82, ptr %t81, !tbaa !21
  %t83 = getelementptr %"compiler/emit:fnEm", ptr %l57, i32 0, i32 23
  %t84 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l26
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t84, ptr %t83
  %t85 = getelementptr %"compiler/emit:fnEm", ptr %l57, i32 0, i32 24
  %t86 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l27
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t86, ptr %t85
  %t87 = getelementptr %"compiler/emit:fnEm", ptr %l57, i32 0, i32 25
  %t88 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l28
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t88, ptr %t87
  %t89 = getelementptr %"compiler/emit:fnEm", ptr %l57, i32 0, i32 26
  %t90 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l29
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t90, ptr %t89
  %t91 = getelementptr %"compiler/emit:fnEm", ptr %l57, i32 0, i32 27
  %t92 = load i1, ptr %l30, !tbaa !21
  store i1 %t92, ptr %t91, !tbaa !21
  %t93 = getelementptr %"compiler/emit:fnEm", ptr %l57, i32 0, i32 28
  %t94 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t94, ptr %t93, !tbaa !27
  %t95 = getelementptr %"compiler/emit:fnEm", ptr %l57, i32 0, i32 29
  %t96 = load i1, ptr %l32, !tbaa !21
  store i1 %t96, ptr %t95, !tbaa !21
  %t97 = getelementptr %"compiler/emit:fnEm", ptr %l57, i32 0, i32 30
  %t98 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l33
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t98, ptr %t97
  %t99 = getelementptr %"compiler/emit:fnEm", ptr %l57, i32 0, i32 31
  %t100 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l34
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t100, ptr %t99
  %t101 = getelementptr %"compiler/emit:fnEm", ptr %l57, i32 0, i32 32
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t36, ptr %t101
  %t103 = getelementptr %"compiler/emit:fnEm", ptr %l57, i32 0, i32 33
  store i64 0, ptr %t103, !tbaa !24
  %t105 = getelementptr %"compiler/emit:fnEm", ptr %l57, i32 0, i32 34
  store i64 0, ptr %t105, !tbaa !24
  %t107 = getelementptr %"compiler/emit:fnEm", ptr %l57, i32 0, i32 35
  store i64 -1, ptr %t107, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l57, i64 296, i1 false)
  br label %ret
ret:
  ret void
}

define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d0 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"olang.table." }>, align 8
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
@.d1 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"ptr @" }>, align 8
@.d2 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c", ptr @" }>, align 8
@.d3 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c", ptr @" }>, align 8
@.d4 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"@" }>, align 8
@.d5 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c" = linkonce_odr constant [" }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d6 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" x ptr] [" }>, align 8
@.d7 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"]\0A" }>, align 8
@.d8 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d9 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"void" }>, align 8
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d10 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d11 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d12 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d13 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"void" }>, align 8
declare void @__olang_check_failed(ptr)
@.d14 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"c:" }>, align 8
declare void @__olang_ert_req_clear()
@.d15 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d16 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"@.c" }>, align 8
@.d17 = private constant <{ i64, [34 x i8] }> <{ i64 0, [34 x i8] c" = private unnamed_addr constant [" }>, align 8
@.d18 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" x i8] c\22" }>, align 8
@.d19 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"\5C00\22\0A" }>, align 8
@.d20 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d21 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"!DIFile(filename: \22" }>, align 8
@.d22 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"\22, directory: \22" }>, align 8
@.d23 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"\22)" }>, align 8
@.d24 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"DW_ATE_boolean" }>, align 8
@.d25 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"DW_ATE_float" }>, align 8
@.d26 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"DW_ATE_unsigned" }>, align 8
@.d27 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"DW_ATE_signed" }>, align 8
@.d28 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"DW_ATE_unsigned_char" }>, align 8
@.d29 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"!DIBasicType(name: \22" }>, align 8
@.d30 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"\22, size: " }>, align 8
@.d31 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c", encoding: " }>, align 8
@.d32 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d33 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"ptr" }>, align 8
@.d34 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I64" }>, align 8
@.d35 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"len" }>, align 8
@.d36 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"data" }>, align 8
@.d37 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"!" }>, align 8
@.d38 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"null" }>, align 8
@.d39 = private constant <{ i64, [51 x i8] }> <{ i64 0, [51 x i8] c"!DIDerivedType(tag: DW_TAG_pointer_type, baseType: " }>, align 8
@.d40 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c", size: 64)" }>, align 8
@.d41 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"code" }>, align 8
@.d42 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"env" }>, align 8
@.d43 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I64" }>, align 8
@.d44 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"len" }>, align 8
@.d45 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"data" }>, align 8
@.d46 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"!{!DISubrange(count: " }>, align 8
@.d47 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c")}" }>, align 8
@.d48 = private constant <{ i64, [52 x i8] }> <{ i64 0, [52 x i8] c"!DICompositeType(tag: DW_TAG_array_type, baseType: !" }>, align 8
@.d49 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c", size: " }>, align 8
@.d50 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c", elements: !" }>, align 8
@.d51 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
define linkonce_odr %"std/prelude/text:StringBuilder" @olang_2eHelperKind_2eZero_2estd_2fprelude_2ftext_3aStringBuilder(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/text:StringBuilder"
  %rv = alloca %"std/prelude/text:StringBuilder"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l0
  store %"std/prelude/text:StringBuilder" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/text:StringBuilder", ptr %rv
  ret %"std/prelude/text:StringBuilder" %rr
}

@.d52 = private constant <{ i64, [42 x i8] }> <{ i64 0, [42 x i8] c"!DIDerivedType(tag: DW_TAG_member, name: \22" }>, align 8
@.d53 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"\22, baseType: !" }>, align 8
@.d54 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c", size: " }>, align 8
@.d55 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c", offset: " }>, align 8
@.d56 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d57 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d58 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"!" }>, align 8
@.d59 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"!{" }>, align 8
@.d60 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"}" }>, align 8
@.d61 = private constant <{ i64, [52 x i8] }> <{ i64 0, [52 x i8] c"!DICompositeType(tag: DW_TAG_structure_type, name: \22" }>, align 8
@.d62 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"\22, size: " }>, align 8
@.d63 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c", elements: !" }>, align 8
@.d64 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@.d65 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"!DIEnumerator(name: \22" }>, align 8
@.d66 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"\22, value: " }>, align 8
@.d67 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d68 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d69 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"!" }>, align 8
@.d70 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"!{" }>, align 8
@.d71 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"}" }>, align 8
@.d72 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I64" }>, align 8
@.d73 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I32" }>, align 8
@.d74 = private constant <{ i64, [54 x i8] }> <{ i64 0, [54 x i8] c"!DICompositeType(tag: DW_TAG_enumeration_type, name: \22" }>, align 8
@.d75 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"\22, size: " }>, align 8
@.d76 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c", baseType: !" }>, align 8
@.d77 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c", elements: !" }>, align 8
@.d78 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d79 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"!{!DISubrange(count: " }>, align 8
@.d80 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c")}" }>, align 8
@.d81 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I64" }>, align 8
@.d82 = private constant <{ i64, [52 x i8] }> <{ i64 0, [52 x i8] c"!DICompositeType(tag: DW_TAG_array_type, baseType: !" }>, align 8
@.d83 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c", size: " }>, align 8
@.d84 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c", elements: !" }>, align 8
@.d85 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d86 = private constant <{ i64, [60 x i8] }> <{ i64 0, [60 x i8] c"!DIDerivedType(tag: DW_TAG_member, name: \22case\22, baseType: !" }>, align 8
@.d87 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c", size: 64, offset: 0)" }>, align 8
@.d88 = private constant <{ i64, [63 x i8] }> <{ i64 0, [63 x i8] c"!DIDerivedType(tag: DW_TAG_member, name: \22payload\22, baseType: !" }>, align 8
@.d89 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c", size: " }>, align 8
@.d90 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c", offset: 64)" }>, align 8
@.d91 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"!{!" }>, align 8
@.d92 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", !" }>, align 8
@.d93 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"}" }>, align 8
@.d94 = private constant <{ i64, [52 x i8] }> <{ i64 0, [52 x i8] c"!DICompositeType(tag: DW_TAG_structure_type, name: \22" }>, align 8
@.d95 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"\22, size: " }>, align 8
@.d96 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c", elements: !" }>, align 8
@.d97 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d98 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"__olang_argc" }>, align 8
@.d99 = private constant <{ i64, [35 x i8] }> <{ i64 0, [35 x i8] c"@__olang_argc = external global i32" }>, align 8
@.d100 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"__olang_argv" }>, align 8
@.d101 = private constant <{ i64, [35 x i8] }> <{ i64 0, [35 x i8] c"@__olang_argv = external global ptr" }>, align 8
@.d102 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"__olang_thread_init" }>, align 8
@.d103 = private constant <{ i64, [51 x i8] }> <{ i64 0, [51 x i8] c"define i32 @main(i32 %argc, ptr %argv) #0 {\0Aentry:\0A" }>, align 8
@.d104 = private constant <{ i64, [74 x i8] }> <{ i64 0, [74 x i8] c"  store i32 %argc, ptr @__olang_argc\0A  store ptr %argv, ptr @__olang_argv\0A" }>, align 8
@.d105 = private constant <{ i64, [35 x i8] }> <{ i64 0, [35 x i8] c"  call void @__olang_thread_init()\0A" }>, align 8
@.d106 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"  call void @" }>, align 8
@.d107 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"()\0A" }>, align 8
@.d108 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"  call void @" }>, align 8
@.d109 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"()\0A  ret i32 0\0A}\0A\0A" }>, align 8
@.d110 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"main" }>, align 8
@.d111 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"  %c = call i32 @" }>, align 8
@.d112 = private constant <{ i64, [82 x i8] }> <{ i64 0, [82 x i8] c"()\0A  %bad = icmp ne i32 %c, 0\0A  br i1 %bad, label %err, label %ok\0Aok:\0A  ret i32 0\0A" }>, align 8
@.d113 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"err:\0A" }>, align 8
@.d114 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"fputs" }>, align 8
@.d115 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"i32 @fputs(ptr, ptr)" }>, align 8
@.d116 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"stderr" }>, align 8
@.d117 = private constant <{ i64, [29 x i8] }> <{ i64 0, [29 x i8] c"@stderr = external global ptr" }>, align 8
@.d118 = private constant <{ i64, [29 x i8] }> <{ i64 0, [29 x i8] c"  %s = load ptr, ptr @stderr\0A" }>, align 8
@.d119 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"%m0" }>, align 8
@.d120 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"unhandled error\0A" }>, align 8
@.d121 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c"  %m0 = getelementptr i8, ptr " }>, align 8
@.d122 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c", i64 0\0A" }>, align 8
@.d123 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"unhandled error: " }>, align 8
@.d124 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d125 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d126 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"  %q" }>, align 8
@.d127 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c" = icmp eq i32 %c, " }>, align 8
@.d128 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d129 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"  %m" }>, align 8
@.d130 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c" = select i1 %q" }>, align 8
@.d131 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", ptr " }>, align 8
@.d132 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d133 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"%m" }>, align 8
@.d134 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"  call i32 @fputs(ptr " }>, align 8
@.d135 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c", ptr %s)\0A" }>, align 8
@.d136 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"__olang_ert_print" }>, align 8
@.d137 = private constant <{ i64, [28 x i8] }> <{ i64 0, [28 x i8] c"void @__olang_ert_print(ptr)" }>, align 8
@.d138 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"__olang_ert_req_print" }>, align 8
@.d139 = private constant <{ i64, [32 x i8] }> <{ i64 0, [32 x i8] c"void @__olang_ert_req_print(ptr)" }>, align 8
@.d140 = private constant <{ i64, [54 x i8] }> <{ i64 0, [54 x i8] c"  call void @__olang_ert_print(ptr %s)\0A  ret i32 1\0A}\0A\0A" }>, align 8
@.d141 = private constant <{ i64, [58 x i8] }> <{ i64 0, [58 x i8] c"  call void @__olang_ert_req_print(ptr %s)\0A  ret i32 1\0A}\0A\0A" }>, align 8
@.d142 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"main" }>, align 8
@.d143 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d144 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"ptr sret(" }>, align 8
@.d145 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c") align " }>, align 8
@.d146 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" %sret" }>, align 8
@.d147 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"%p" }>, align 8
@.d148 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"ptr " }>, align 8
@.d149 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"ptr " }>, align 8
@.d150 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"i64 " }>, align 8
@.d151 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"n" }>, align 8
@.d152 = private constant <{ i64, [36 x i8] }> <{ i64 0, [36 x i8] c"insertvalue { i64, ptr } undef, i64 " }>, align 8
@.d153 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"n, 0" }>, align 8
@.d154 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c"insertvalue { i64, ptr } " }>, align 8
@.d155 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", ptr " }>, align 8
@.d156 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 1" }>, align 8
@.d157 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"{ i64, ptr } " }>, align 8
@.d158 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"ptr " }>, align 8
@.d159 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d160 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d161 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d162 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d163 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d164 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"[" }>, align 8
@.d165 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" x i8]" }>, align 8
@.d166 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d167 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
@.d168 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"getelementptr i8, ptr " }>, align 8
@.d169 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", i64 " }>, align 8
@.d170 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c" alignstack(8)" }>, align 8
@.d171 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d172 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
@.d173 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d174 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"ptr byval(" }>, align 8
@.d175 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c") align " }>, align 8
@.d176 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d177 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"ptr " }>, align 8
@.d178 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"ptr " }>, align 8
@.d179 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d180 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d181 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"ptr %buf" }>, align 8
@.d182 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"i64 %cap" }>, align 8
@.d183 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"ptr %len" }>, align 8
@.d184 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"ptr %res" }>, align 8
@.d185 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"__olang_self" }>, align 8
@.d186 = private constant <{ i64, [61 x i8] }> <{ i64 0, [61 x i8] c"@__olang_self = external thread_local(initialexec) global ptr" }>, align 8
@.d187 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"__olang_thread_enter" }>, align 8
@.d188 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"__olang_scope_close" }>, align 8
@.d189 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c"load ptr, ptr @__olang_self" }>, align 8
@.d190 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"icmp eq ptr " }>, align 8
@.d191 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", null" }>, align 8
@.d192 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"br i1 " }>, align 8
@.d193 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c", label %enter, label %go" }>, align 8
@.d194 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"enter:\0A" }>, align 8
@.d195 = private constant <{ i64, [33 x i8] }> <{ i64 0, [33 x i8] c"call void @__olang_thread_enter()" }>, align 8
@.d196 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"br label %go" }>, align 8
@.d197 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"go:\0A" }>, align 8
@.d198 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"%olang.scope" }>, align 8
@.d199 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"%olang.scope" }>, align 8
@.d200 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"zeroinitializer" }>, align 8
@.d201 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d202 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"ptr " }>, align 8
@.d203 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"ptr " }>, align 8
@.d204 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d205 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d206 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"void" }>, align 8
@.d207 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"call void @" }>, align 8
@.d208 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d209 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d210 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"call " }>, align 8
@.d211 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" @" }>, align 8
@.d212 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d213 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d214 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d215 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d216 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d217 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"extractvalue " }>, align 8
@.d218 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d219 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 0" }>, align 8
@.d220 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d221 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"extractvalue " }>, align 8
@.d222 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d223 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 1" }>, align 8
@.d224 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d225 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d226 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d227 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"icmp ne i32 " }>, align 8
@.d228 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 0" }>, align 8
@.d229 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"br i1 " }>, align 8
@.d230 = private constant <{ i64, [28 x i8] }> <{ i64 0, [28 x i8] c", label %failed, label %done" }>, align 8
@.d231 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"failed:\0A" }>, align 8
@.d232 = private constant <{ i64, [35 x i8] }> <{ i64 0, [35 x i8] c"call void @__olang_scope_close(ptr " }>, align 8
@.d233 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d234 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"ret i32 " }>, align 8
@.d235 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"done:\0A" }>, align 8
@.d236 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"extractvalue { i64, ptr } " }>, align 8
@.d237 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 0" }>, align 8
@.d238 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"extractvalue { i64, ptr } " }>, align 8
@.d239 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 1" }>, align 8
@.d240 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"icmp slt i64 %cap, " }>, align 8
@.d241 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"select i1 " }>, align 8
@.d242 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c", i64 %cap, i64 " }>, align 8
@.d243 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"icmp sgt i64 " }>, align 8
@.d244 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 0" }>, align 8
@.d245 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"select i1 " }>, align 8
@.d246 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", i64 " }>, align 8
@.d247 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c", i64 0" }>, align 8
@.d248 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"mul i64 " }>, align 8
@.d249 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d250 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"llvm.memmove.p0.p0.i64" }>, align 8
@.d251 = private constant <{ i64, [47 x i8] }> <{ i64 0, [47 x i8] c"void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)" }>, align 8
@.d252 = private constant <{ i64, [48 x i8] }> <{ i64 0, [48 x i8] c"call void @llvm.memmove.p0.p0.i64(ptr %buf, ptr " }>, align 8
@.d253 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", i64 " }>, align 8
@.d254 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c", i1 false)" }>, align 8
@.d255 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"i64" }>, align 8
@.d256 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"%len" }>, align 8
@.d257 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"i64 " }>, align 8
@.d258 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"i32 0" }>, align 8
@.d259 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"%res" }>, align 8
@.d260 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"i32 0" }>, align 8
@.d261 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d262 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"[" }>, align 8
@.d263 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" x i8]" }>, align 8
@.d264 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"undef" }>, align 8
@.d265 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d266 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"getelementptr i8, ptr " }>, align 8
@.d267 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", i64 " }>, align 8
@.d268 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"insertvalue " }>, align 8
@.d269 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d270 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d271 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d272 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"%sret" }>, align 8
@.d273 = private constant <{ i64, [35 x i8] }> <{ i64 0, [35 x i8] c"call void @__olang_scope_close(ptr " }>, align 8
@.d274 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d275 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d276 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"void" }>, align 8
@.d277 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"ret " }>, align 8
@.d278 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"void" }>, align 8
@.d279 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"i32" }>, align 8
@.d280 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"i64" }>, align 8
@.d281 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d282 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d283 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d284 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"void" }>, align 8
@.d285 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"define " }>, align 8
@.d286 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" @" }>, align 8
@.d287 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d288 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d289 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c") #0 {\0Aentry:\0A" }>, align 8
@.d290 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"}\0A\0A" }>, align 8
@.d291 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d292 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d293 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d294 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d295 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" (" }>, align 8
@.d296 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d297 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"not lowered: " }>, align 8
@.d298 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"entry:\0A  ret void\0A}\0A\0A" }>, align 8
@.d299 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"__olang_check_failed" }>, align 8
@.d300 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"not lowered" }>, align 8
@.d301 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"not lowered" }>, align 8
@.d302 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c".walk" }>, align 8
@.d303 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c".walk" }>, align 8
@.d304 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"@" }>, align 8
@.d305 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c" = constant " }>, align 8
@.d306 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"}>" }>, align 8
@.d307 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"@" }>, align 8
@.d308 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c" = external global i8" }>, align 8
@.d309 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"@" }>, align 8
@.d310 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c" = external constant " }>, align 8
@.d311 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"@" }>, align 8
@.d312 = private constant <{ i64, [33 x i8] }> <{ i64 0, [33 x i8] c" = available_externally constant " }>, align 8
@.d313 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d314 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"@" }>, align 8
@.d315 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c" = global " }>, align 8
@.d316 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c" zeroinitializer\0A" }>, align 8
@.d317 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"@" }>, align 8
@.d318 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c" = external global " }>, align 8
@.d319 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d320 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"@" }>, align 8
define available_externally void @__olang_scope_escape(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %un = icmp eq ptr %o, null
  br i1 %un, label %claim, label %done
claim:
  %me = load ptr, ptr @__olang_self
  store atomic ptr %me, ptr %op monotonic, align 8
  br label %done
done:
  ret void
}
define internal i1 @olang_lambda_321(ptr %env, i64 %a0, i64 %a1) #0 {
entry:
  %l2 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l5 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i1
  %rv = alloca i1
  %cp0 = getelementptr { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr }, ptr %env, i32 0, i32 0
  %cv0 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %cp0, !tbaa !28
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %cv0, ptr %l2
  %vq0 = getelementptr { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr }, ptr %env, i32 0, i32 1
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  br label %start
start:
  br label %bb0
bb0:
  %t4 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %vc0, ptr %vc0, ptr %l2, i64 %a0)
  store { i64, ptr } %t4, ptr %l5
  br label %bb1
bb1:
  %t8 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %vc0, ptr %vc0, ptr %l2, i64 %a1)
  store { i64, ptr } %t8, ptr %l8
  br label %bb2
bb2:
  %t9 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t10 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t11 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLess(ptr %vc0, ptr %vc0, { i64, ptr } %t9, { i64, ptr } %t10)
  store i1 %t11, ptr %l9
  br label %bb3
bb3:
  %t12 = load i1, ptr %l9, !tbaa !21
  store i1 %t12, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d322 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"G_2e" }>, align 8
@.d323 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c" by the self-hosted compiler: " }>, align 8
@.d324 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d325 = private constant <{ i64, [45 x i8] }> <{ i64 0, [45 x i8] c"entry:\0A  call void @__olang_check_failed(ptr " }>, align 8
@.d326 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c")\0A  unreachable\0A}\0A\0A" }>, align 8
@.d327 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"olang." }>, align 8
declare void @__olang_sb_put(ptr, ptr, i64)
define linkonce_odr void @olang_2eHelperKind_2eRender_2ecompiler_2fmir_3aHelperKind(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load i32, ptr %a0
  %t3 = sext i32 %t2 to i64
  switch i64 %t3, label %bb1 [ i64 0, label %bb2 i64 1, label %bb3 i64 2, label %bb4 i64 3, label %bb5 ]
bb1:
  br label %ret
bb2:
  %t5 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d558, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d558, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t5, i64 %t6)
  br label %bb1
bb3:
  %t7 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d559, i32 0, i32 1) }, 1
  %t8 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d559, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t7, i64 %t8)
  br label %bb1
bb4:
  %t9 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d560, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d560, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t9, i64 %t10)
  br label %bb1
bb5:
  %t11 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d561, i32 0, i32 1) }, 1
  %t12 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d561, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t11, i64 %t12)
  br label %bb1
ret:
  ret void
}

@.d328 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
declare void @__olang_sb_done(ptr)
@.d329 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"_adapter" }>, align 8
@.d330 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"olang.init." }>, align 8
@.d331 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c".top" }>, align 8
@.d332 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d333 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"olang.anyrender" }>, align 8
@.d334 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d335 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"|" }>, align 8
@.d336 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"olang_textcopy" }>, align 8
@.d337 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"llvm.memcpy.p0.p0.i64" }>, align 8
@.d338 = private constant <{ i64, [46 x i8] }> <{ i64 0, [46 x i8] c"void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)" }>, align 8
@.d339 = private constant <{ i64, [94 x i8] }> <{ i64 0, [94 x i8] c"define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {\0Aentry:\0A" }>, align 8
@.d340 = private constant <{ i64, [66 x i8] }> <{ i64 0, [66 x i8] c"  %big = icmp ugt i64 %n, 16\0A  br i1 %big, label %call, label %s8\0A" }>, align 8
@.d341 = private constant <{ i64, [86 x i8] }> <{ i64 0, [86 x i8] c"call:\0A  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)\0A  ret void\0A" }>, align 8
@.d342 = private constant <{ i64, [67 x i8] }> <{ i64 0, [67 x i8] c"s8:\0A  %ge8 = icmp uge i64 %n, 8\0A  br i1 %ge8, label %w8, label %s4\0A" }>, align 8
@.d343 = private constant <{ i64, [103 x i8] }> <{ i64 0, [103 x i8] c"w8:\0A  %e8 = sub i64 %n, 8\0A  %a8 = load i64, ptr %s, align 1\0A  %sb8 = getelementptr i8, ptr %s, i64 %e8\0A" }>, align 8
@.d344 = private constant <{ i64, [112 x i8] }> <{ i64 0, [112 x i8] c"  %b8 = load i64, ptr %sb8, align 1\0A  store i64 %a8, ptr %d, align 1\0A  %db8 = getelementptr i8, ptr %d, i64 %e8\0A" }>, align 8
@.d345 = private constant <{ i64, [46 x i8] }> <{ i64 0, [46 x i8] c"  store i64 %b8, ptr %db8, align 1\0A  ret void\0A" }>, align 8
@.d346 = private constant <{ i64, [67 x i8] }> <{ i64 0, [67 x i8] c"s4:\0A  %ge4 = icmp uge i64 %n, 4\0A  br i1 %ge4, label %w4, label %s1\0A" }>, align 8
@.d347 = private constant <{ i64, [103 x i8] }> <{ i64 0, [103 x i8] c"w4:\0A  %e4 = sub i64 %n, 4\0A  %a4 = load i32, ptr %s, align 1\0A  %sb4 = getelementptr i8, ptr %s, i64 %e4\0A" }>, align 8
@.d348 = private constant <{ i64, [112 x i8] }> <{ i64 0, [112 x i8] c"  %b4 = load i32, ptr %sb4, align 1\0A  store i32 %a4, ptr %d, align 1\0A  %db4 = getelementptr i8, ptr %d, i64 %e4\0A" }>, align 8
@.d349 = private constant <{ i64, [46 x i8] }> <{ i64 0, [46 x i8] c"  store i32 %b4, ptr %db4, align 1\0A  ret void\0A" }>, align 8
@.d350 = private constant <{ i64, [70 x i8] }> <{ i64 0, [70 x i8] c"s1:\0A  %none = icmp eq i64 %n, 0\0A  br i1 %none, label %done, label %w1\0A" }>, align 8
@.d351 = private constant <{ i64, [113 x i8] }> <{ i64 0, [113 x i8] c"w1:\0A  %h = lshr i64 %n, 1\0A  %e1 = sub i64 %n, 1\0A  %a1 = load i8, ptr %s\0A  %sh = getelementptr i8, ptr %s, i64 %h\0A" }>, align 8
@.d352 = private constant <{ i64, [115 x i8] }> <{ i64 0, [115 x i8] c"  %m1 = load i8, ptr %sh\0A  %se = getelementptr i8, ptr %s, i64 %e1\0A  %z1 = load i8, ptr %se\0A  store i8 %a1, ptr %d\0A" }>, align 8
@.d353 = private constant <{ i64, [107 x i8] }> <{ i64 0, [107 x i8] c"  %dh = getelementptr i8, ptr %d, i64 %h\0A  store i8 %m1, ptr %dh\0A  %de = getelementptr i8, ptr %d, i64 %e1\0A" }>, align 8
@.d354 = private constant <{ i64, [60 x i8] }> <{ i64 0, [60 x i8] c"  store i8 %z1, ptr %de\0A  br label %done\0Adone:\0A  ret void\0A}\0A" }>, align 8
@.d355 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"olang_textcopy" }>, align 8
@.d356 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c".walk" }>, align 8
@.d357 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d358 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"@" }>, align 8
@.d359 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d360 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c") #0 {" }>, align 8
@.d361 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d362 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"define dso_local " }>, align 8
@.d363 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"@" }>, align 8
@.d364 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d365 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c") #0 {\0Aentry:\0A" }>, align 8
@.d366 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"void" }>, align 8
@.d367 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"  tail call void @" }>, align 8
@.d368 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d369 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c")\0A  ret void\0A}\0A\0A" }>, align 8
@.d370 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"  %r = tail call " }>, align 8
@.d371 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" @" }>, align 8
@.d372 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d373 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c")\0A  ret " }>, align 8
@.d374 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" %r\0A}\0A\0A" }>, align 8
@.d375 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d376 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"a place with no base" }>, align 8
@.d377 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"getelementptr " }>, align 8
@.d378 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", ptr " }>, align 8
@.d379 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c", i32 0, i32 " }>, align 8
@.d380 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d381 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"ptr" }>, align 8
@.d382 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"getelementptr " }>, align 8
@.d383 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", ptr " }>, align 8
@.d384 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c", i32 0, i32 1" }>, align 8
@.d385 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d386 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"  " }>, align 8
@.d387 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c" = alloca " }>, align 8
@.d388 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c", align " }>, align 8
@.d389 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c"__olang_scope_alloc_zeroed_min" }>, align 8
@.d390 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"__olang_scope_alloc_min" }>, align 8
@__olang_prog_scope = external thread_local(initialexec) global ptr
@.d391 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"call ptr @" }>, align 8
@.d392 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"(ptr " }>, align 8
@.d393 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", i64 " }>, align 8
@.d394 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d395 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"__olang_scope_alloc_zeroed" }>, align 8
@.d396 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"__olang_scope_alloc" }>, align 8
@.d397 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"call ptr @" }>, align 8
@.d398 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"(ptr " }>, align 8
@.d399 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", i64 " }>, align 8
@.d400 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d401 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"bfloat" }>, align 8
@.d402 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"half" }>, align 8
@.d403 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"bitcast " }>, align 8
@.d404 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d405 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" to " }>, align 8
@.d406 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"half" }>, align 8
@.d407 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"an Exit " }>, align 8
define linkonce_odr void @olang_2eHelperKind_2eRender_2ecompiler_2fmir_3aExitKind(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load i32, ptr %a0
  %t3 = sext i32 %t2 to i64
  switch i64 %t3, label %bb1 [ i64 0, label %bb2 i64 1, label %bb3 i64 2, label %bb4 i64 3, label %bb5 i64 4, label %bb6 i64 5, label %bb7 i64 6, label %bb8 i64 7, label %bb9 i64 8, label %bb10 i64 9, label %bb11 i64 10, label %bb12 i64 11, label %bb13 i64 12, label %bb14 i64 13, label %bb15 i64 14, label %bb16 ]
bb1:
  br label %ret
bb2:
  %t5 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d562, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d562, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t5, i64 %t6)
  br label %bb1
bb3:
  %t7 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d563, i32 0, i32 1) }, 1
  %t8 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d563, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t7, i64 %t8)
  br label %bb1
bb4:
  %t9 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d564, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d564, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t9, i64 %t10)
  br label %bb1
bb5:
  %t11 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d565, i32 0, i32 1) }, 1
  %t12 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d565, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t11, i64 %t12)
  br label %bb1
bb6:
  %t13 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d566, i32 0, i32 1) }, 1
  %t14 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d566, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t13, i64 %t14)
  br label %bb1
bb7:
  %t15 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d567, i32 0, i32 1) }, 1
  %t16 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d567, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t15, i64 %t16)
  br label %bb1
bb8:
  %t17 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d568, i32 0, i32 1) }, 1
  %t18 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d568, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t17, i64 %t18)
  br label %bb1
bb9:
  %t19 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d569, i32 0, i32 1) }, 1
  %t20 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d569, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t19, i64 %t20)
  br label %bb1
bb10:
  %t21 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d570, i32 0, i32 1) }, 1
  %t22 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d570, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t21, i64 %t22)
  br label %bb1
bb11:
  %t23 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d571, i32 0, i32 1) }, 1
  %t24 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d571, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t23, i64 %t24)
  br label %bb1
bb12:
  %t25 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d572, i32 0, i32 1) }, 1
  %t26 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d572, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t25, i64 %t26)
  br label %bb1
bb13:
  %t27 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d573, i32 0, i32 1) }, 1
  %t28 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d573, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t27, i64 %t28)
  br label %bb1
bb14:
  %t29 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d574, i32 0, i32 1) }, 1
  %t30 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d574, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t29, i64 %t30)
  br label %bb1
bb15:
  %t31 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d575, i32 0, i32 1) }, 1
  %t32 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d575, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t31, i64 %t32)
  br label %bb1
bb16:
  %t33 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d576, i32 0, i32 1) }, 1
  %t34 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d576, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t33, i64 %t34)
  br label %bb1
ret:
  ret void
}

@.d408 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"ended" }>, align 8
@.d409 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d410 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"__olang_ert_pass" }>, align 8
@.d411 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c"void @__olang_ert_pass(ptr)" }>, align 8
@.d412 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"__olang_test_error" }>, align 8
@.d413 = private constant <{ i64, [29 x i8] }> <{ i64 0, [29 x i8] c"void @__olang_test_error(ptr)" }>, align 8
@.d414 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c": left the test\0A" }>, align 8
@.d415 = private constant <{ i64, [32 x i8] }> <{ i64 0, [32 x i8] c"call void @__olang_ert_pass(ptr " }>, align 8
@.d416 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d417 = private constant <{ i64, [34 x i8] }> <{ i64 0, [34 x i8] c"call void @__olang_test_error(ptr " }>, align 8
@.d418 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d419 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"unreachable" }>, align 8
@.d420 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d421 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"__olang_bang_failed" }>, align 8
@.d422 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c"__olang_bang_failed_plain" }>, align 8
@.d423 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"void @" }>, align 8
@.d424 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"(ptr)" }>, align 8
@.d425 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
@.d426 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d427 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"call void @" }>, align 8
@.d428 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"(ptr " }>, align 8
@.d429 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d430 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"unreachable" }>, align 8
@.d431 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"__olang_check_failed" }>, align 8
@.d432 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
@.d433 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d434 = private constant <{ i64, [36 x i8] }> <{ i64 0, [36 x i8] c"call void @__olang_check_failed(ptr " }>, align 8
@.d435 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d436 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c"__olang_check_failed_text" }>, align 8
@.d437 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
@.d438 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
@.d439 = private constant <{ i64, [41 x i8] }> <{ i64 0, [41 x i8] c"call void @__olang_check_failed_text(ptr " }>, align 8
@.d440 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c", { i64, ptr } " }>, align 8
@.d441 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d442 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"unreachable" }>, align 8
@.d443 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"trunc " }>, align 8
@.d444 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d445 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" to i64" }>, align 8
@.d446 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"zext" }>, align 8
@.d447 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"sext" }>, align 8
@.d448 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d449 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" to i64" }>, align 8
@.d450 = private constant <{ i64, [36 x i8] }> <{ i64 0, [36 x i8] c"insertvalue { i64, ptr } undef, i64 " }>, align 8
@.d451 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 0" }>, align 8
@.d452 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c"insertvalue { i64, ptr } " }>, align 8
@.d453 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", ptr " }>, align 8
@.d454 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 1" }>, align 8
@.d455 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"undef" }>, align 8
@.d456 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"insertvalue " }>, align 8
@.d457 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d458 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d459 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"zeroinitializer" }>, align 8
@.d460 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"__olang_prog_scope" }>, align 8
@.d461 = private constant <{ i64, [67 x i8] }> <{ i64 0, [67 x i8] c"@__olang_prog_scope = external thread_local(initialexec) global ptr" }>, align 8
@.d462 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"ptr" }>, align 8
@.d463 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"@__olang_prog_scope" }>, align 8
@.d464 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"lshr i32 " }>, align 8
@.d465 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c", 16" }>, align 8
@.d466 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"and i32 " }>, align 8
@.d467 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c", 65535" }>, align 8
@.d468 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"0" }>, align 8
@.d469 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"icmp eq i32 " }>, align 8
@.d470 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d471 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"select i1 " }>, align 8
@.d472 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", i32 " }>, align 8
@.d473 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"icmp eq i32 " }>, align 8
@.d474 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 0" }>, align 8
@.d475 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"shl i32 " }>, align 8
@.d476 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c", 16" }>, align 8
@.d477 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"or i32 " }>, align 8
@.d478 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d479 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"select i1 " }>, align 8
@.d480 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c", i32 0, i32 " }>, align 8
@.d481 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d482 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"!" }>, align 8
@.d483 = private constant <{ i64, [33 x i8] }> <{ i64 0, [33 x i8] c" = distinct !DISubprogram(name: \22" }>, align 8
@.d484 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"\22, scope: !" }>, align 8
@.d485 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c", file: !" }>, align 8
@.d486 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c", line: " }>, align 8
@.d487 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c", type: !" }>, align 8
@.d488 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c", scopeLine: " }>, align 8
@.d489 = private constant <{ i64, [38 x i8] }> <{ i64 0, [38 x i8] c", spFlags: DISPFlagDefinition, unit: !" }>, align 8
@.d490 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c")\0A" }>, align 8
@.d491 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"__olang_ert_req_set" }>, align 8
@.d492 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c"void @__olang_ert_req_set(ptr)" }>, align 8
@.d493 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
@.d494 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d495 = private constant <{ i64, [35 x i8] }> <{ i64 0, [35 x i8] c"call void @__olang_ert_req_set(ptr " }>, align 8
@.d496 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d497 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"try passed it on" }>, align 8
@.d498 = private constant <{ i64, [40 x i8] }> <{ i64 0, [40 x i8] c"a task failed, and its join passed it on" }>, align 8
@.d499 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"raised here" }>, align 8
@.d500 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"__olang_ert_pass" }>, align 8
@.d501 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"__olang_ert_raise" }>, align 8
@.d502 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"void @" }>, align 8
@.d503 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"(ptr)" }>, align 8
@.d504 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
@.d505 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d506 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"call void @" }>, align 8
@.d507 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"(ptr " }>, align 8
@.d508 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d509 = private constant <{ i64, [35 x i8] }> <{ i64 0, [35 x i8] c"getelementptr %olang.unwind, ptr %u" }>, align 8
@.d510 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c", i32 0, i32 0" }>, align 8
@.d511 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"ptr" }>, align 8
@.d512 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"ptr" }>, align 8
@.d513 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"@__olang_unwind_top" }>, align 8
@.d514 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"0123456789ABCDEF" }>, align 8
@.d515 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\5C" }>, align 8
@.d516 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"0123456789ABCDEF" }>, align 8
define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.d517 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"cbrt" }>, align 8
@.d518 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"exp" }>, align 8
@.d519 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"exp2" }>, align 8
@.d520 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"expm1" }>, align 8
@.d521 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"log" }>, align 8
@.d522 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"log2" }>, align 8
@.d523 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"log10" }>, align 8
@.d524 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"log1p" }>, align 8
@.d525 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"pow" }>, align 8
@.d526 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"hypot" }>, align 8
@.d527 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"sin" }>, align 8
@.d528 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"cos" }>, align 8
@.d529 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"tan" }>, align 8
@.d530 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"asin" }>, align 8
@.d531 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"acos" }>, align 8
@.d532 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"atan" }>, align 8
@.d533 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"atan2" }>, align 8
@.d534 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"sinh" }>, align 8
@.d535 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"cosh" }>, align 8
@.d536 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"tanh" }>, align 8
@.d537 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"erf" }>, align 8
@.d538 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"erfc" }>, align 8
@.d539 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"f" }>, align 8
@.d540 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d541 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d542 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"bool" }>, align 8
@.d543 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"i8" }>, align 8
@.d544 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"i16" }>, align 8
@.d545 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"int32" }>, align 8
@.d546 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"int64" }>, align 8
@.d547 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"byte" }>, align 8
@.d548 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"u16" }>, align 8
@.d549 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"u32" }>, align 8
@.d550 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"u64" }>, align 8
@.d551 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"f16" }>, align 8
@.d552 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"bf16" }>, align 8
@.d553 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"float32" }>, align 8
@.d554 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"float64" }>, align 8
@.d555 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_Hf48d6d4096e547b8075d5a903caa3d54(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.d556 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI32_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI32_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.d557 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@__olang_self = external thread_local(initialexec) global ptr
define available_externally ptr @__olang_capture_scope(ptr %s) alwaysinline {
entry:
  %isprog = icmp eq ptr %s, null
  br i1 %isprog, label %prog, label %mine
prog:
  %p = load ptr, ptr @__olang_prog_scope
  ret ptr %p
mine:
  %m = call ptr @__olang_scope_mine(ptr %s)
  ret ptr %m
}
@.d558 = private unnamed_addr constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"HelperKind.Render" }>, align 8
@.d559 = private unnamed_addr constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"HelperKind.Equal" }>, align 8
@.d560 = private unnamed_addr constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"HelperKind.Hash" }>, align 8
@.d561 = private unnamed_addr constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"HelperKind.Zero" }>, align 8
@.d562 = private unnamed_addr constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"ExitKind.Done" }>, align 8
@.d563 = private unnamed_addr constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"ExitKind.Fail" }>, align 8
@.d564 = private unnamed_addr constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"ExitKind.Abort" }>, align 8
@.d565 = private unnamed_addr constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"ExitKind.Unreachable" }>, align 8
@.d566 = private unnamed_addr constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"ExitKind.NullReached" }>, align 8
@.d567 = private unnamed_addr constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"ExitKind.NullError" }>, align 8
@.d568 = private unnamed_addr constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"ExitKind.Assert" }>, align 8
@.d569 = private unnamed_addr constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"ExitKind.SliceBounds" }>, align 8
@.d570 = private unnamed_addr constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"ExitKind.ArrayLength" }>, align 8
@.d571 = private unnamed_addr constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"ExitKind.As" }>, align 8
@.d572 = private unnamed_addr constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"ExitKind.FixedLength" }>, align 8
@.d573 = private unnamed_addr constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"ExitKind.LaneLength" }>, align 8
@.d574 = private unnamed_addr constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"ExitKind.GenRunning" }>, align 8
@.d575 = private unnamed_addr constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"ExitKind.Error" }>, align 8
@.d576 = private unnamed_addr constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"ExitKind.Escaped" }>, align 8
define available_externally ptr @__olang_scope_mine(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %me = load ptr, ptr @__olang_self
  %own = icmp eq ptr %o, %me
  br i1 %own, label %mine, label %slow
mine:
  ret ptr %s
slow:
  %r = call ptr @__olang_scope_mine_slow(ptr %s)
  ret ptr %r
}
declare ptr @__olang_scope_mine_slow(ptr) noinline
@G_2ecompiler_2femit_2ePartSize = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\10\00\00\00\00\00" }>, align 8
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRetLlvm(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2eSymbol(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/generic:AnyTable" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aAnyTable_3e_2eAt__He9601a52fe5cfa5abe1b41d520aed001(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etypeid(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2ewant(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2ftypes_2eAnySlotBase = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2femit_2eHomeShared = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FF\FF\FF\FF\FF\FF\FF\FF" }>, align 8
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eitem(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, i64 %a2, { i64, ptr } %a3, { i64, ptr } %a4)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eVoidT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eNoreturnT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\11\00\00\00" }>, align 8
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLayout(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/cabi:Way" @compiler_2fcabi_2eResult(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fcabi_2ePartsType(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_6aada305a3873fb6_c16c54d6f05c33ea = external constant [0 x i8]
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_He27db0a1785588531472bfd2db42574f(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha4444909f5ef14f7626d25b8f59e6ba2(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
@olang_loc_5836d127b451ff05_764b57a187e296f1 = external constant [0 x i8]
@G_2ecompiler_2femit_2eHomeLocal = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FE\FF\FF\FF\FF\FF\FF\FF" }>, align 8
declare { i64, ptr } @compiler_2femit_2eescape(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6f7a2f8d839c49b6e7a19c287d4b190c(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgNew(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2ePathOf(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i32, { i64, ptr } } @std_2fos_2eCwd(ptr %v0)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgShared(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eBoolT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgPair(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, { i64, ptr } %a2, i32 %a3, { i64, ptr } %a4, i32 %a5)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSize(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgBytes(ptr %v0, ptr %a0)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2efieldNames(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i64 %a2)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOffsets(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgTypeName(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCaseNames(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_649f734ddce51468_b7eb8be07e4dd31c = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etext(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eenumWords(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePayloadSize(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edefine(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2esanInit(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2femit_2ecompiler_2femit_3aEmitter_2eglobalOrder(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2feval_3aImage_3e_2e_H901ad831a5883703dcf426ee01511832(ptr %v0, ptr %a0, i64 %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorWords(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eerrName(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2etraced(ptr %v0, ptr %a0)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2femit_2ecompiler_2femit_3aEmitter_2earrayOfE(ptr %v0, ptr %a0, i32 %a1)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_70000d3e005ea498_c6a0fd2b538569fc = external constant [0 x i8]
@olang_loc_8dd51a70be22f844_db8bd8df095848b0 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare void @compiler_2fmir_3aFn_2ector(ptr %out, ptr %v0, { i64, [2 x i64] } %a0, i32 %a1, i64 %a2, %"compiler/source:Span" %a3)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 %a0)
declare %"compiler/cabi:Way" @compiler_2fcabi_3aWay_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, i32 %a0, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %a1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %a2, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %a3, { i64, ptr } %a4)
declare %"compiler/cabi:Regs" @compiler_2fcabi_3aRegs_2ector(ptr %v0, i64 %a0, i64 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAlign(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePassing(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare %"compiler/cabi:Way" @compiler_2fcabi_2eParam(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, i32 %a2, ptr %a3)
declare i64 @compiler_2fcabi_2eSpan(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eReplace_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4)
declare i64 @std_2fprelude_2fnumber_2eI64_2eMax_3cI64_3e(i64 %a0, i64 %a1)
@olang_loc_ce3f793afe7e8735_eee0e2f7e7e28841 = external constant [0 x i8]
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eslot(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2ememmove(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, i64 %a3)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eViaMemory(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fmir_2ePassedCount(ptr %v0, ptr %a0, { i64, [7 x i64] } %a1, i32 %a2)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2femit_2ecompiler_2femit_3aEmitter_2eExportErrors(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eToArray_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %v1, ptr %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_9000b3cdde9de97e_540aa7fc20a2aa2a = external constant [0 x i8]
@olang_loc_882423aaa1f01f7f_b9c3af967e36d8eb = external constant [0 x i8]
declare i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ehomeOf(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclared(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
declare void @compiler_2flower_2ecompiler_2flower_3aLowerer_2eLowerKey(ptr %out, ptr %v0, ptr %v1, ptr %a0, { i64, [2 x i64] } %a1)
declare i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ehasEnv(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
declare i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2epassedOf(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, i32 %a2)
declare { i64, ptr } @compiler_2femit_2elinkFor(ptr %v0, i64 %a0)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eheader(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, [2 x i64] } %a1, i32 %a2, { i64, ptr } %a3, i64 %a4, i1 %a5, { i64, ptr } %a6)
declare { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3aFn_2eVerify(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, { i64, ptr } %a0)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2egap(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eisGlobalInit(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2efnItem(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, [2 x i64] } %a1, i32 %a2, { i64, ptr } %a3, i64 %a4, i1 %a5, { i64, ptr } %a6)
declare i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ewriteBody(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, [2 x i64] } %a1, ptr %a2, { i64, ptr } %a3, i64 %a4, i1 %a5, { i64, ptr } %a6, i1 %a7)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eglobalSym(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2)
declare i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eglobalBody(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare { i32, %"compiler/eval:Image" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2feval_3aImage_3e_2e_Hf0a310b4530fd6279fda9cb6330ad681(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/eval:Image" @compiler_2feval_3aImage_2ector(ptr %v0)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ebakedText(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, ptr %a2)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_67352ecb15e68ba0_c3979b973b302ad4 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aBlob_3e_2eLen_3ccompiler_2feval_3aBlob_3e(ptr %v0, ptr %a0)
declare %"compiler/eval:Blob" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aBlob_3e_2eAt_3ccompiler_2feval_3aBlob_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_6c4f253a42e065fd_ca2f6afe461eeb41 = external constant [0 x i8]
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9b83f66eba65594537030636cb0b52b7(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_a37d1f87ccda68bc_daadd8872686b520 = external constant [0 x i8]
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsGenerator(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_9224769184a821c8_ff8c445af92d13bc = external constant [0 x i8]
@olang_loc_68254245c55f7699_2855b47650ff1f6d = external constant [0 x i8]
declare %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eIter_3cI64_2c_20Bool_3e(ptr %v0, ptr %v1, ptr %a0)
declare { i32, %"std/prelude/map:MapEntry.eb00e4a6e4307a4e46e40fbcd79d6b4f" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3cI64_2c_20Bool_3e_2eNext_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %v0, ptr %v1, ptr %a0)
declare void @std_2fprelude_2farray_2eArray_3cI64_3e_2eSort_3cI64_2c_20_3f_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1c, ptr %a1e)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ehead(ptr %v0, ptr %v1, ptr %a0)
declare i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ealiased(ptr %v0, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eHash(ptr %v0, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2econstText(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i64 %a2)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ebodySym(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eUnnamed(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanonNamed(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_325a0aca37049b03_8faf0435ed6a0227 = external constant [0 x i8]
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecanonOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2femit_2erefsIn(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_6f064da57090b2af_17093dce158f11fb = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9162e3b7f03fcbf954b681204d5f6cca(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_f5feee0c0f7dd320_8e2d9d91f1e1268c = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_fb18e47b3c77ad7d_7c94e7cf0a0fcab9 = external constant [0 x i8]
@olang_loc_7f6652826e00de1e_418f3021b2f06a1a = external constant [0 x i8]
@olang_loc_679011f6b0c6ee1b_3818b84a191b3b77 = external constant [0 x i8]
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elocalAt(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2elocalType(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2egap(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_a45e6d34f8d75be7_fb9ba052a05cfc3b = external constant [0 x i8]
declare { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e_2eAt_3ccompiler_2fmir_3aProj_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2efieldList(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etbaa(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i1 %a2)
declare i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2erunTime(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2edescTag(ptr %v0, ptr %v1, ptr %a0, i1 %a1, i1 %a2)
declare { { i64, ptr }, i32 } @compiler_2femit_2ecompiler_2femit_3afnEm_2eelemAt(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, i32 %a2, { i64, ptr } %a3, { i64, ptr } %a4)
declare i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2ecasesList(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_f0091f918c975106_bc2d594a86836fba = external constant [0 x i8]
@olang_loc_44ab2decf02f961d_3f31a3219a480a51 = external constant [0 x i8]
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2etmp(ptr %v0, ptr %v1, ptr %a0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2ealign(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ebf16Bits(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i1 %a2)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eopaque16(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fmir_2eExitText(ptr %v0, i32 %a0)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2econstText(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_15d05b44c0be072a_cdffff4fd774d83e = external constant [0 x i8]
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elocated(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2)
@olang_loc_7b8962df1e5235eb_6d0c23ccefebcb3f = external constant [0 x i8]
declare i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eotype(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %v1, ptr %a0, { i64, [4 x i64] } %a1, i32 %a2)
declare { { i64, ptr }, { i64, ptr } } @compiler_2femit_2ecompiler_2femit_3afnEm_2earrayParts(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2)
@olang_loc_9d518c27a973a5b0_d4b76855814c5604 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eLen_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, ptr %a0)
declare %"compiler/mir:BasicBlock" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eAt_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aStmt_3e_2eLen_3ccompiler_2fmir_3aStmt_3e(ptr %v0, ptr %a0)
declare { i64, [21 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aStmt_3e_2eAt_3ccompiler_2fmir_3aStmt_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/mir:ScopeInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeInfo_3e_2eAt_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_8a0f087481b95ab0_a13f080fe7b316d4 = external constant [0 x i8]
declare i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2eplainWrite(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
declare i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2erefIs(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1, i64 %a2)
@olang_loc_9d64128d60439a41_20f9e6973a71ad85 = external constant [0 x i8]
@olang_loc_28dd7919903bc2a_4577237eccb57ce = external constant [0 x i8]
@olang_loc_6846df2bf697eaeb_3c0ad43c6c9a3c0f = external constant [0 x i8]
declare { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %a0, %"compiler/mir:Range" %a1, i64 %a2)
declare i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eposition(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2edata(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, i64 %a3, %"compiler/source:Span" %a4, i1 %a5)
@olang_loc_37dcdc821423a995_2a435c3b360fb831 = external constant [0 x i8]
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLineAt(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgName(ptr %v0, ptr %v1, ptr %a0, { i64, [2 x i64] } %a1)
declare i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgSubTy(ptr %v0, ptr %a0)
declare i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgCu(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3aFn_2eRaiseText(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI32_2c_20I64_3e_2ePut_3cI32_2c_20I64_3e(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
@olang_loc_2ea555a1037c9329_7e95fb4c4c24cb65 = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI32_2c_20I64_3e_2eGet_3cI32_2c_20I64_3e(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_7bc7193ce72d0d52_c947a9f9cc48c9f6 = external constant [0 x i8]
declare i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2ebaseIs(ptr %v0, ptr %a0, %"compiler/mir:Place" %a1, i32 %a2)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eWritable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@olang_loc_5dfa9b7395be5458_e24cfc313725a25c = external constant [0 x i8]
@olang_loc_cd3d2f4cb5172729_796de8126c3e3b8d = external constant [0 x i8]
@G_2ecompiler_2femit_2ehexDigits = external constant <{ [8 x i8], ptr }>
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H2b85ceff512af6e6ca26c554a1c16247(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i1 %a2)
declare i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eLen_3cI64_2c_20I64_3e(ptr %v0, ptr %a0)
@G_2ecompiler_2femit_2etbaaElem = available_externally constant <{ [120 x i8] }> <{ [120 x i8] c"\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\1F\00\00\00\00\00\00\00\51\00\00\00\00\00\00\00\52\00\00\00\00\00\00\00\21\00\00\00\00\00\00\00\22\00\00\00\00\00\00\00\20\00\00\00\00\00\00\00\53\00\00\00\00\00\00\00\54\00\00\00\00\00\00\00\55\00\00\00\00\00\00\00\56\00\00\00\00\00\00\00\57\00\00\00\00\00\00\00\23\00\00\00\00\00\00\00\24\00\00\00\00\00\00\00" }>, align 64
@G_2ecompiler_2femit_2etbaaName = external constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }>
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aWriteKind_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2ector(ptr %v0, i64 %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLess(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI32_2c_20I64_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
