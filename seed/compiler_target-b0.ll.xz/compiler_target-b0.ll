; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/os:Output" = type { i32, { i64, ptr }, { i64, ptr } }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"compiler/target:Target" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i1, i1, i1, i1, i64, { i64, ptr } }
%"compiler/diagmsg:Msg" = type { i32, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"std/prelude/text:LineIter" = type { { i64, ptr }, i64 }
%"std/os:FileInfo" = type { i32, i64, i64 }
define dso_local { i32, %"std/os:Output" } @compiler_2ftarget_2eClangSays(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1, i1 %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca %"std/os:Output"
  %l7 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l12 = alloca i1
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i32
  %l21 = alloca { i64, ptr }
  %l25 = alloca i1
  %l27 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l30 = alloca i32
  %l38 = alloca i1
  %l41 = alloca i1
  %l42 = alloca i64
  %l44 = alloca { i64, ptr }
  %l46 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i64
  %l57 = alloca %"std/os:Output"
  %l58 = alloca %"std/os:Output"
  %l62 = alloca %"std/os:Output"
  %l63 = alloca i32
  %l67 = alloca i1
  %l69 = alloca i1
  %l71 = alloca i1
  %l73 = alloca { i64, ptr }
  %l75 = alloca i32
  %l77 = alloca i1
  %l81 = alloca { i64, ptr }
  %l82 = alloca i32
  %l90 = alloca i32
  %l92 = alloca i1
  %l98 = alloca i32
  %l100 = alloca i1
  %l104 = alloca i32
  %l106 = alloca i1
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca { i32, %"std/os:Output" }
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t5 = call { i64, ptr } @compiler_2ftarget_2eprobeKey(ptr %v0, ptr %v1, ptr %s0, { i64, ptr } %t1, { i64, ptr } %t2)
  store { i64, ptr } %t5, ptr %l10
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t6, ptr %l3, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t9 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t7, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d0, i32 0, i32 1) })
  store i1 %t9, ptr %l12
  br label %bb2
bb2:
  %t10 = load i1, ptr %l12, !tbaa !21
  %t11 = xor i1 %t10, true
  br i1 %t11, label %bb3, label %bb4
bb3:
  %t13 = call { i64, ptr } @compiler_2ftarget_2eprobeDir(ptr %s0)
  store { i64, ptr } %t13, ptr %l15
  br label %bb5
bb4:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d1, i32 0, i32 1) }, ptr %l14, !tbaa !27
  br label %bb10
bb5:
  %t14 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t16 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eHash(ptr %s0, { i64, ptr } %t14)
  store i64 %t16, ptr %l17
  br label %bb6
bb6:
  %t17 = load i64, ptr %l17, !tbaa !24
  store i64 %t17, ptr %l18, !tbaa !65
  %t18 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s0, i64 16)
  %t19 = extractvalue { i32, i64 } %t18, 1
  %t20 = extractvalue { i32, i64 } %t18, 0
  store i32 %t20, ptr %l20
  %t21 = icmp ne i32 %t20, 0
  br i1 %t21, label %bb8, label %ok.22, !prof !99
ok.22:
  store i64 %t19, ptr %l19
  br label %bb7
bb7:
  %t23 = load i64, ptr %l18, !tbaa !65
  %t24 = load i64, ptr %l19, !tbaa !24
  %t25 = call { i64, ptr } @std_2fprelude_2ftext_2eU64_2eFormat(ptr %s0, i64 %t23, i64 %t24)
  store { i64, ptr } %t25, ptr %l21
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_def72623566706b3_6d1f4e2e8af6f867)
  unreachable
bb9:
  %t26 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t27 = extractvalue { i64, ptr } %t26, 1
  %t28 = extractvalue { i64, ptr } %t26, 0
  %t29 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d2, i32 0, i32 1) }, 1
  %t30 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d2, i32 0, i32 1) }, 0
  %t31 = add i64 %t28, %t30
  %t32 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t33 = extractvalue { i64, ptr } %t32, 1
  %t34 = extractvalue { i64, ptr } %t32, 0
  %t35 = add i64 %t31, %t34
  %t36 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t35)
  call void @olang_textcopy(ptr %t36, ptr %t27, i64 %t28)
  %t37 = getelementptr i8, ptr %t36, i64 %t28
  call void @olang_textcopy(ptr %t37, ptr %t29, i64 %t30)
  %t38 = getelementptr i8, ptr %t37, i64 %t30
  call void @olang_textcopy(ptr %t38, ptr %t33, i64 %t34)
  %t39 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %t36, 1
  store { i64, ptr } %t40, ptr %l14, !tbaa !27
  br label %bb10
bb10:
  %t43 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t43, ptr %l4, !tbaa !27
  %t44 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t46 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t44, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d3, i32 0, i32 1) })
  store i1 %t46, ptr %l25
  br label %bb11
bb11:
  %t47 = load i1, ptr %l25, !tbaa !21
  %t48 = xor i1 %t47, true
  br i1 %t48, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t50 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t52 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %s0, ptr %s2, { i64, ptr } %t50)
  %t53 = extractvalue { i32, { i64, ptr } } %t52, 1
  %t54 = extractvalue { i32, { i64, ptr } } %t52, 0
  store i32 %t54, ptr %l30
  %t55 = icmp ne i32 %t54, 0
  br i1 %t55, label %bb15, label %ok.56, !prof !99
ok.56:
  store { i64, ptr } %t53, ptr %l29
  br label %bb14
bb13:
  br label %bb36
bb14:
  %t57 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t57, ptr %l27, !tbaa !27
  br label %bb19
bb15:
  %t58 = load i32, ptr %l30, !tbaa !23
  %t59 = ashr i32 %t58, 16
  %t61 = icmp eq i32 %t59, 1
  br i1 %t61, label %bb16, label %bb17
bb16:
  call void @__olang_errpay_pop()
  br label %bb17
bb17:
  br label %bb18
bb18:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d4, i32 0, i32 1) }, ptr %l27, !tbaa !27
  br label %bb19
bb19:
  %t63 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t63, ptr %l5, !tbaa !27
  %t64 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t66 = extractvalue { i64, ptr } %t64, 0
  %t67 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t67, 0
  %t72 = icmp sgt i64 %t66, %t69
  br i1 %t72, label %bb20, label %bb21
bb20:
  %t74 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t75 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t78 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s2, ptr %s0, { i64, ptr } %t74, { i64, ptr } %t75)
  store i1 %t78, ptr %l41
  br label %bb22
bb21:
  store i1 false, ptr %l38, !tbaa !21
  br label %bb23
bb22:
  %t79 = load i1, ptr %l41, !tbaa !21
  store i1 %t79, ptr %l38, !tbaa !21
  br label %bb23
bb23:
  %t80 = load i1, ptr %l38, !tbaa !21
  br i1 %t80, label %bb24, label %bb25
bb24:
  %t81 = call ptr @__olang_scope_hold(ptr %v2)
  %t82 = ptrtoint ptr %t81 to i64
  store i64 %t82, ptr %l42, !tbaa !24
  %t83 = load i1, ptr @olang_2esole_2estd_2fos_3aOutput_2e1
  br i1 %t83, label %bb26, label %bb27
bb25:
  br label %bb35
bb26:
  %t85 = call ptr @__olang_region_make(ptr %v2)
  %t86 = ptrtoint ptr %t85 to i64
  store i64 %t86, ptr %l42, !tbaa !24
  br label %bb27
bb27:
  %t87 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t87, ptr %l44, !tbaa !27
  %t88 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t90 = extractvalue { i64, ptr } %t88, 0
  store i64 %t90, ptr %l46, !tbaa !24
  %t91 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t94 = extractvalue { i64, ptr } %t91, 0
  store i64 %t94, ptr %l49, !tbaa !24
  %t95 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t96 = extractvalue { i64, ptr } %t95, 0
  store i64 %t96, ptr %l50, !tbaa !24
  %t97 = load i64, ptr %l46, !tbaa !24
  %t98 = icmp sge i64 %t97, 0
  br i1 %t98, label %bb28, label %bb29
bb28:
  %t100 = load i64, ptr %l46, !tbaa !24
  %t101 = load i64, ptr %l49, !tbaa !24
  %t102 = icmp sle i64 %t100, %t101
  br i1 %t102, label %bb30, label %bb31
bb29:
  call void @__olang_check_failed(ptr @olang_loc_47a0ad7bede37e81_52b343d343663485)
  unreachable
bb30:
  %t104 = load i64, ptr %l49, !tbaa !24
  %t105 = load i64, ptr %l50, !tbaa !24
  %t106 = icmp sle i64 %t104, %t105
  br i1 %t106, label %bb32, label %bb33
bb31:
  call void @__olang_check_failed(ptr @olang_loc_47a0ad7bede37e81_52b343d343663485)
  unreachable
bb32:
  %t108 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !27
  %t110 = load i64, ptr %l46, !tbaa !24
  %t111 = load i64, ptr %l49, !tbaa !24
  %t112 = getelementptr i8, ptr %t109, i64 %t110
  %t113 = sub i64 %t111, %t110
  %t114 = insertvalue { i64, ptr } undef, i64 %t113, 0
  %t115 = insertvalue { i64, ptr } %t114, ptr %t112, 1
  %t117 = extractvalue { i64, ptr } %t115, 1
  %t118 = extractvalue { i64, ptr } %t115, 0
  %t119 = load i64, ptr %l42
  %t120 = inttoptr i64 %t119 to ptr
  %t121 = call ptr @__olang_held_alloc(ptr %t120, i64 %t118)
  call void @olang_textcopy(ptr %t121, ptr %t117, i64 %t118)
  %t122 = insertvalue { i64, ptr } undef, i64 %t118, 0
  %t123 = insertvalue { i64, ptr } %t122, ptr %t121, 1
  %t126 = call %"std/os:Output" @std_2fos_3aOutput_2ector(ptr %v2, ptr %v2, ptr %v2, i32 0, { i64, ptr } %t123, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d5, i32 0, i32 1) })
  store %"std/os:Output" %t126, ptr %l57
  br label %bb34
bb33:
  call void @__olang_check_failed(ptr @olang_loc_47a0ad7bede37e81_52b343d343663485)
  unreachable
bb34:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t127 = load %"std/os:Output", ptr %l57
  %t128 = insertvalue { i32, %"std/os:Output" } zeroinitializer, %"std/os:Output" %t127, 1
  store { i32, %"std/os:Output" } %t128, ptr %rv
  br label %ret
bb35:
  call void @__olang_scope_close(ptr %s2)
  br label %bb36
bb36:
  %t129 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t130 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t134 = call { i32, %"std/os:Output" } @std_2fos_2eOutput_2eExec(ptr %v0, ptr %v1, ptr %s0, ptr %v2, { i64, ptr } %t129, { i64, ptr } %t130, i1 true, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d6, i32 0, i32 1) })
  %t135 = extractvalue { i32, %"std/os:Output" } %t134, 1
  %t136 = extractvalue { i32, %"std/os:Output" } %t134, 0
  store i32 %t136, ptr %l63
  %t137 = icmp ne i32 %t136, 0
  br i1 %t137, label %bb38, label %ok.138, !prof !99
ok.138:
  store %"std/os:Output" %t135, ptr %l62
  br label %bb37
bb37:
  %t139 = load %"std/os:Output", ptr %l62
  store %"std/os:Output" %t139, ptr %l58
  br label %bb39
bb38:
  %t140 = load i32, ptr %l63, !tbaa !23
  %t141 = lshr i32 %t140, 16
  %t142 = and i32 %t140, 65535
  %t143 = icmp eq i32 %t141, 1
  %t144 = select i1 %t143, i32 1, i32 0
  %t145 = icmp eq i32 %t140, 0
  %t146 = shl i32 %t144, 16
  %t147 = or i32 %t146, %t142
  %t148 = select i1 %t145, i32 0, i32 %t147
  call void @__olang_scope_close(ptr %s0)
  %t150 = insertvalue { i32, %"std/os:Output" } zeroinitializer, i32 %t148, 0
  store { i32, %"std/os:Output" } %t150, ptr %rv
  br label %ret
bb39:
  %t151 = load %"std/os:Output", ptr %l58
  store %"std/os:Output" %t151, ptr %l6
  %t152 = getelementptr %"std/os:Output", ptr %l6, i32 0, i32 0
  %t153 = load i32, ptr %t152, !tbaa !23
  %t155 = icmp eq i32 %t153, 0
  br i1 %t155, label %bb40, label %bb41
bb40:
  %t157 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t159 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t157, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d7, i32 0, i32 1) })
  store i1 %t159, ptr %l69
  br label %bb42
bb41:
  store i1 false, ptr %l67, !tbaa !21
  br label %bb43
bb42:
  %t160 = load i1, ptr %l69, !tbaa !21
  %t161 = xor i1 %t160, true
  store i1 %t161, ptr %l67, !tbaa !21
  br label %bb43
bb43:
  %t163 = load i1, ptr %l67, !tbaa !21
  br i1 %t163, label %bb44, label %bb45
bb44:
  store i1 %a2, ptr %l71, !tbaa !21
  br label %bb46
bb45:
  store i1 false, ptr %l71, !tbaa !21
  br label %bb46
bb46:
  %t166 = load i1, ptr %l71, !tbaa !21
  br i1 %t166, label %bb47, label %bb48
bb47:
  store %olang.scope zeroinitializer, ptr %s5
  %t167 = call { i64, ptr } @compiler_2ftarget_2eprobeDir(ptr %s5)
  store { i64, ptr } %t167, ptr %l73
  br label %bb49
bb48:
  br label %bb75
bb49:
  %t168 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t170 = call i32 @std_2fos_2eMkDirAll(ptr %s5, { i64, ptr } %t168)
  store i32 %t170, ptr %l75
  %t171 = icmp ne i32 %t170, 0
  br i1 %t171, label %bb51, label %ok.172, !prof !99
ok.172:
  br label %bb50
bb50:
  br label %bb55
bb51:
  %t173 = load i32, ptr %l75, !tbaa !23
  %t174 = ashr i32 %t173, 16
  %t176 = icmp eq i32 %t174, 1
  store i1 %t176, ptr %l77, !tbaa !21
  %t177 = load i32, ptr %l75, !tbaa !23
  %t178 = ashr i32 %t177, 16
  %t180 = icmp eq i32 %t178, 1
  br i1 %t180, label %bb52, label %bb53
bb52:
  call void @__olang_errpay_pop()
  br label %bb53
bb53:
  br label %bb54
bb54:
  %t182 = load %"std/os:Output", ptr %l6
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t184 = insertvalue { i32, %"std/os:Output" } zeroinitializer, %"std/os:Output" %t182, 1
  store { i32, %"std/os:Output" } %t184, ptr %rv
  br label %ret
bb55:
  %t185 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t185, ptr %l81, !tbaa !27
  %t186 = call i32 @getpid()
  store i32 %t186, ptr %l82
  br label %bb56
bb56:
  %t187 = load { i64, ptr }, ptr %l81, !tbaa !27
  %t188 = extractvalue { i64, ptr } %t187, 1
  %t189 = extractvalue { i64, ptr } %t187, 0
  %t190 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d8, i32 0, i32 1) }, 1
  %t191 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d8, i32 0, i32 1) }, 0
  %t192 = add i64 %t189, %t191
  %t193 = load i32, ptr %l82, !tbaa !23
  %t194 = sext i32 %t193 to i64
  %t195 = call i64 @__olang_fmt_i64(ptr null, i64 %t194)
  %t196 = add i64 %t192, %t195
  %t197 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d9, i32 0, i32 1) }, 1
  %t198 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d9, i32 0, i32 1) }, 0
  %t199 = add i64 %t196, %t198
  %t200 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t199)
  call void @olang_textcopy(ptr %t200, ptr %t188, i64 %t189)
  %t201 = getelementptr i8, ptr %t200, i64 %t189
  call void @olang_textcopy(ptr %t201, ptr %t190, i64 %t191)
  %t202 = getelementptr i8, ptr %t201, i64 %t191
  %t203 = call i64 @__olang_fmt_i64(ptr %t202, i64 %t194)
  %t204 = getelementptr i8, ptr %t202, i64 %t195
  call void @olang_textcopy(ptr %t204, ptr %t197, i64 %t198)
  %t205 = insertvalue { i64, ptr } undef, i64 %t199, 0
  %t206 = insertvalue { i64, ptr } %t205, ptr %t200, 1
  store { i64, ptr } %t206, ptr %l7, !tbaa !27
  %t208 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t209 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t210 = getelementptr %"std/os:Output", ptr %l6, i32 0, i32 1
  %t211 = load { i64, ptr }, ptr %t210, !tbaa !27
  %t213 = extractvalue { i64, ptr } %t209, 1
  %t214 = extractvalue { i64, ptr } %t209, 0
  %t216 = extractvalue { i64, ptr } %t211, 1
  %t217 = extractvalue { i64, ptr } %t211, 0
  %t218 = add i64 %t214, %t217
  %t219 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t218)
  call void @olang_textcopy(ptr %t219, ptr %t213, i64 %t214)
  %t220 = getelementptr i8, ptr %t219, i64 %t214
  call void @olang_textcopy(ptr %t220, ptr %t216, i64 %t217)
  %t221 = insertvalue { i64, ptr } undef, i64 %t218, 0
  %t222 = insertvalue { i64, ptr } %t221, ptr %t219, 1
  %t225 = extractvalue { i64, ptr } %t222, 0
  %t226 = extractvalue { i64, ptr } %t222, 1
  %t227 = mul i64 %t225, 1
  %t228 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t227)
  call void @llvm.memcpy.p0.p0.i64(ptr %t228, ptr %t226, i64 %t227, i1 false)
  %t229 = insertvalue { i64, ptr } undef, i64 %t225, 0
  %t230 = insertvalue { i64, ptr } %t229, ptr %t228, 1
  %t233 = call i32 @std_2fos_2eWriteFile(ptr %s5, ptr %s5, { i64, ptr } %t208, { i64, ptr } %t230)
  store i32 %t233, ptr %l90
  %t234 = icmp ne i32 %t233, 0
  br i1 %t234, label %bb58, label %ok.235, !prof !99
ok.235:
  br label %bb57
bb57:
  br label %bb62
bb58:
  %t236 = load i32, ptr %l90, !tbaa !23
  %t237 = ashr i32 %t236, 16
  %t239 = icmp eq i32 %t237, 1
  store i1 %t239, ptr %l92, !tbaa !21
  %t240 = load i32, ptr %l90, !tbaa !23
  %t241 = ashr i32 %t240, 16
  %t243 = icmp eq i32 %t241, 1
  br i1 %t243, label %bb59, label %bb60
bb59:
  call void @__olang_errpay_pop()
  br label %bb60
bb60:
  br label %bb61
bb61:
  %t245 = load %"std/os:Output", ptr %l6
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t247 = insertvalue { i32, %"std/os:Output" } zeroinitializer, %"std/os:Output" %t245, 1
  store { i32, %"std/os:Output" } %t247, ptr %rv
  br label %ret
bb62:
  %t248 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t249 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t252 = call i32 @std_2fos_2eRename(ptr %s5, ptr %s0, { i64, ptr } %t248, { i64, ptr } %t249)
  store i32 %t252, ptr %l98
  %t253 = icmp ne i32 %t252, 0
  br i1 %t253, label %bb64, label %ok.254, !prof !99
ok.254:
  br label %bb63
bb63:
  br label %bb74
bb64:
  %t255 = load i32, ptr %l98, !tbaa !23
  %t256 = ashr i32 %t255, 16
  %t258 = icmp eq i32 %t256, 1
  store i1 %t258, ptr %l100, !tbaa !21
  %t259 = load i32, ptr %l98, !tbaa !23
  %t260 = ashr i32 %t259, 16
  %t262 = icmp eq i32 %t260, 1
  br i1 %t262, label %bb65, label %bb66
bb65:
  call void @__olang_errpay_pop()
  br label %bb66
bb66:
  br label %bb67
bb67:
  %t264 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t266 = call i32 @std_2fos_2eRemove(ptr %s5, { i64, ptr } %t264)
  store i32 %t266, ptr %l104
  %t267 = icmp ne i32 %t266, 0
  br i1 %t267, label %bb69, label %ok.268, !prof !99
ok.268:
  br label %bb68
bb68:
  br label %bb73
bb69:
  %t269 = load i32, ptr %l104, !tbaa !23
  %t270 = ashr i32 %t269, 16
  %t272 = icmp eq i32 %t270, 1
  store i1 %t272, ptr %l106, !tbaa !21
  %t273 = load i32, ptr %l104, !tbaa !23
  %t274 = ashr i32 %t273, 16
  %t276 = icmp eq i32 %t274, 1
  br i1 %t276, label %bb70, label %bb71
bb70:
  call void @__olang_errpay_pop()
  br label %bb71
bb71:
  br label %bb72
bb72:
  br label %bb73
bb73:
  br label %bb74
bb74:
  call void @__olang_scope_close(ptr %s5)
  br label %bb75
bb75:
  %t278 = load %"std/os:Output", ptr %l6
  call void @__olang_scope_close(ptr %s0)
  %t280 = insertvalue { i32, %"std/os:Output" } zeroinitializer, %"std/os:Output" %t278, 1
  store { i32, %"std/os:Output" } %t280, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"std/os:Output" }, ptr %rv
  ret { i32, %"std/os:Output" } %rr
}

define dso_local { i64, ptr } @compiler_2ftarget_2eFindClang(ptr %v0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i32
  %l14 = alloca i1
  %l17 = alloca i1
  %l18 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l27 = alloca i32
  %l30 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i32
  %l36 = alloca { i64, ptr }
  %l37 = alloca i64
  %l38 = alloca i64
  %l48 = alloca i32
  %l62 = alloca i1
  %l68 = alloca { i64, ptr }
  %l69 = alloca { i64, ptr }
  %l70 = alloca i64
  %l71 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %s0, ptr %s0, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d10, i32 0, i32 1) })
  %t2 = extractvalue { i32, { i64, ptr } } %t1, 1
  %t3 = extractvalue { i32, { i64, ptr } } %t1, 0
  store i32 %t3, ptr %l10
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5, !prof !99
ok.5:
  store { i64, ptr } %t2, ptr %l9
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t6, ptr %l8, !tbaa !27
  br label %bb6
bb2:
  %t7 = load i32, ptr %l10, !tbaa !23
  %t8 = ashr i32 %t7, 16
  %t10 = icmp eq i32 %t8, 1
  br i1 %t10, label %bb3, label %bb4
bb3:
  call void @__olang_errpay_pop()
  br label %bb4
bb4:
  br label %bb5
bb5:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d11, i32 0, i32 1) }, ptr %l8, !tbaa !27
  br label %bb6
bb6:
  %t12 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t12, ptr %l0, !tbaa !27
  %t13 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t15 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t13, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d12, i32 0, i32 1) })
  store i1 %t15, ptr %l14
  br label %bb7
bb7:
  %t16 = load i1, ptr %l14, !tbaa !21
  %t17 = xor i1 %t16, true
  br i1 %t17, label %bb8, label %bb9
bb8:
  %t19 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t21 = call i1 @compiler_2ftarget_2eexecutable(ptr %s0, { i64, ptr } %t19)
  store i1 %t21, ptr %l17
  br label %bb10
bb9:
  br label %bb14
bb10:
  %t22 = load i1, ptr %l17, !tbaa !21
  br i1 %t22, label %bb11, label %bb12
bb11:
  %t23 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t23, 1
  %t26 = extractvalue { i64, ptr } %t23, 0
  %t27 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t26)
  call void @olang_textcopy(ptr %t27, ptr %t25, i64 %t26)
  %t28 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t27, 1
  store { i64, ptr } %t29, ptr %l18, !tbaa !27
  br label %bb13
bb12:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d13, i32 0, i32 1) }, ptr %l21, !tbaa !27
  %t31 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t31, ptr %l18, !tbaa !27
  br label %bb13
bb13:
  %t33 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t33, 0
  store i64 %t34, ptr %l23, !tbaa !24
  %t35 = load i64, ptr %l23, !tbaa !24
  %t36 = mul i64 %t35, 1
  %t37 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t36)
  %t38 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t37, 1
  store { i64, ptr } %t39, ptr %l24, !tbaa !27
  %t40 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = load i64, ptr %l23, !tbaa !24
  %t45 = mul i64 %t44, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t41, ptr %t43, i64 %t45, i1 false)
  %t46 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t46, ptr %l18, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t47 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t47, ptr %rv
  br label %ret
bb14:
  %t48 = call { i32, { i64, ptr } } @std_2fos_2eReadLink(ptr %s0, ptr %s0, { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d14, i32 0, i32 1) })
  %t49 = extractvalue { i32, { i64, ptr } } %t48, 1
  %t50 = extractvalue { i32, { i64, ptr } } %t48, 0
  store i32 %t50, ptr %l27
  %t51 = icmp ne i32 %t50, 0
  br i1 %t51, label %bb16, label %ok.52, !prof !99
ok.52:
  store { i64, ptr } %t49, ptr %l26
  br label %bb15
bb15:
  %t53 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t53, ptr %l25, !tbaa !27
  br label %bb20
bb16:
  %t54 = load i32, ptr %l27, !tbaa !23
  %t55 = ashr i32 %t54, 16
  %t57 = icmp eq i32 %t55, 1
  br i1 %t57, label %bb17, label %bb18
bb17:
  call void @__olang_errpay_pop()
  br label %bb18
bb18:
  br label %bb19
bb19:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d15, i32 0, i32 1) }, ptr %l25, !tbaa !27
  br label %bb20
bb20:
  %t59 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t59, ptr %l1, !tbaa !27
  %t60 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t62 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %s0, ptr %s0, { i64, ptr } %t60, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d16, i32 0, i32 1) })
  %t63 = extractvalue { i32, i64 } %t62, 1
  %t64 = extractvalue { i32, i64 } %t62, 0
  store i32 %t64, ptr %l33
  %t65 = icmp ne i32 %t64, 0
  br i1 %t65, label %bb22, label %ok.66, !prof !99
ok.66:
  store i64 %t63, ptr %l32
  br label %bb21
bb21:
  %t67 = load i64, ptr %l32, !tbaa !24
  store i64 %t67, ptr %l30, !tbaa !24
  br label %bb24
bb22:
  br label %bb23
bb23:
  store i64 -1, ptr %l30, !tbaa !24
  br label %bb24
bb24:
  %t68 = load i64, ptr %l30, !tbaa !24
  store i64 %t68, ptr %l2, !tbaa !24
  %t69 = load i64, ptr %l2, !tbaa !24
  %t71 = icmp sge i64 %t69, 0
  br i1 %t71, label %bb25, label %bb26
bb25:
  store %olang.scope zeroinitializer, ptr %s3
  %t73 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t73, ptr %l36, !tbaa !27
  %t74 = load i64, ptr %l2, !tbaa !24
  store i64 %t74, ptr %l37, !tbaa !24
  %t75 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t76 = extractvalue { i64, ptr } %t75, 0
  store i64 %t76, ptr %l38, !tbaa !24
  %t77 = icmp sge i64 0, 0
  br i1 %t77, label %bb27, label %bb28
bb26:
  br label %bb37
bb27:
  %t79 = load i64, ptr %l37, !tbaa !24
  %t80 = icmp sle i64 0, %t79
  br i1 %t80, label %bb29, label %bb30
bb28:
  call void @__olang_check_failed(ptr @olang_loc_5d60638bbee689af_7a012b3f353868cb)
  unreachable
bb29:
  %t82 = load i64, ptr %l37, !tbaa !24
  %t83 = load i64, ptr %l38, !tbaa !24
  %t84 = icmp sle i64 %t82, %t83
  br i1 %t84, label %bb31, label %bb32
bb30:
  call void @__olang_check_failed(ptr @olang_loc_5d60638bbee689af_7a012b3f353868cb)
  unreachable
bb31:
  %t86 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t87 = load ptr, ptr %t86, !tbaa !27
  %t88 = load i64, ptr %l37, !tbaa !24
  %t89 = getelementptr i8, ptr %t87, i64 0
  %t90 = sub i64 %t88, 0
  %t91 = insertvalue { i64, ptr } undef, i64 %t90, 0
  %t92 = insertvalue { i64, ptr } %t91, ptr %t89, 1
  %t94 = extractvalue { i64, ptr } %t92, 1
  %t95 = extractvalue { i64, ptr } %t92, 0
  %t96 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d17, i32 0, i32 1) }, 1
  %t97 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d17, i32 0, i32 1) }, 0
  %t98 = add i64 %t95, %t97
  %t99 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t98)
  call void @olang_textcopy(ptr %t99, ptr %t94, i64 %t95)
  %t100 = getelementptr i8, ptr %t99, i64 %t95
  call void @olang_textcopy(ptr %t100, ptr %t96, i64 %t97)
  %t101 = insertvalue { i64, ptr } undef, i64 %t98, 0
  %t102 = insertvalue { i64, ptr } %t101, ptr %t99, 1
  store { i64, ptr } %t102, ptr %l3, !tbaa !27
  %t104 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t106 = extractvalue { i64, ptr } %t104, 1
  %t107 = extractvalue { i64, ptr } %t104, 0
  %t108 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d18, i32 0, i32 1) }, 1
  %t109 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d18, i32 0, i32 1) }, 0
  %t110 = add i64 %t107, %t109
  %t111 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t110)
  call void @olang_textcopy(ptr %t111, ptr %t106, i64 %t107)
  %t112 = getelementptr i8, ptr %t111, i64 %t107
  call void @olang_textcopy(ptr %t112, ptr %t108, i64 %t109)
  %t113 = insertvalue { i64, ptr } undef, i64 %t110, 0
  %t114 = insertvalue { i64, ptr } %t113, ptr %t111, 1
  %t116 = load i32, ptr @G_2e_3cunistd_2eh_3e_2eX__OK, !tbaa !23
  %t118 = extractvalue { i64, ptr } %t114, 1
  %t119 = extractvalue { i64, ptr } %t114, 0
  %t121 = call i32 @access(ptr %t118, i32 %t116)
  store i32 %t121, ptr %l48
  br label %bb33
bb32:
  call void @__olang_check_failed(ptr @olang_loc_5d60638bbee689af_7a012b3f353868cb)
  unreachable
bb33:
  %t122 = load i32, ptr %l48, !tbaa !23
  %t123 = icmp eq i32 %t122, 0
  br i1 %t123, label %bb34, label %bb35
bb34:
  %t125 = load { i64, ptr }, ptr %l3, !tbaa !27
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t125, ptr %rv
  br label %ret
bb35:
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s3)
  br label %bb37
bb37:
  store ptr @G_2ecompiler_2ftarget_2eClangs, ptr %l4
  store i64 0, ptr %l5, !tbaa !24
  %t128 = load ptr, ptr %l4
  store i64 4, ptr %l6, !tbaa !24
  br label %bb38
bb38:
  %t131 = load i64, ptr %l5, !tbaa !24
  %t132 = load i64, ptr %l6, !tbaa !24
  %t135 = icmp slt i64 %t131, %t132
  %t137 = xor i1 %t135, true
  br i1 %t137, label %bb39, label %bb40
bb39:
  br label %bb47
bb40:
  br label %bb41
bb41:
  %t139 = load ptr, ptr %l4
  %t140 = load i64, ptr %l5, !tbaa !24
  %t143 = getelementptr [4 x { i64, ptr }], ptr %t139, i64 0, i64 %t140
  %t144 = load { i64, ptr }, ptr %t143, !tbaa !37
  store { i64, ptr } %t144, ptr %l7, !tbaa !27
  %t146 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t147 = load ptr, ptr @__olang_prog_scope
  %t149 = call i1 @compiler_2ftarget_2eexecutable(ptr %t147, { i64, ptr } %t146)
  store i1 %t149, ptr %l62
  br label %bb42
bb42:
  %t150 = load i1, ptr %l62, !tbaa !21
  br i1 %t150, label %bb43, label %bb44
bb43:
  %t151 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t153 = extractvalue { i64, ptr } %t151, 1
  %t154 = extractvalue { i64, ptr } %t151, 0
  %t155 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t154)
  call void @olang_textcopy(ptr %t155, ptr %t153, i64 %t154)
  %t156 = insertvalue { i64, ptr } undef, i64 %t154, 0
  %t157 = insertvalue { i64, ptr } %t156, ptr %t155, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t157, ptr %rv
  br label %ret
bb44:
  br label %bb45
bb45:
  br label %bb46
bb46:
  %t159 = load i64, ptr %l5, !tbaa !24
  %t162 = add i64 %t159, 1
  store i64 %t162, ptr %l5, !tbaa !24
  br label %bb38
bb47:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d19, i32 0, i32 1) }, ptr %l68, !tbaa !27
  %t164 = load { i64, ptr }, ptr %l68, !tbaa !27
  store { i64, ptr } %t164, ptr %l69, !tbaa !27
  %t165 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t166 = extractvalue { i64, ptr } %t165, 0
  store i64 %t166, ptr %l70, !tbaa !24
  %t167 = load i64, ptr %l70, !tbaa !24
  %t168 = mul i64 %t167, 1
  %t169 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t168)
  %t170 = insertvalue { i64, ptr } undef, i64 %t167, 0
  %t171 = insertvalue { i64, ptr } %t170, ptr %t169, 1
  store { i64, ptr } %t171, ptr %l71, !tbaa !27
  %t172 = getelementptr { i64, ptr }, ptr %l71, i32 0, i32 1
  %t173 = load ptr, ptr %t172, !tbaa !27
  %t174 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t175 = load ptr, ptr %t174, !tbaa !27
  %t176 = load i64, ptr %l70, !tbaa !24
  %t177 = mul i64 %t176, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t173, ptr %t175, i64 %t177, i1 false)
  %t178 = load { i64, ptr }, ptr %l71, !tbaa !27
  store { i64, ptr } %t178, ptr %l69, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t179 = load { i64, ptr }, ptr %l69, !tbaa !27
  store { i64, ptr } %t179, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2ftarget_2eHasFeature(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l23 = alloca i1
  %l24 = alloca { i64, ptr }
  %l27 = alloca i1
  %l28 = alloca { i64, ptr }
  %l31 = alloca i64
  %l32 = alloca i64
  %l38 = alloca i1
  %s1 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s1
  %t3 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %v0, ptr %s1, ptr %s1, { i64, ptr } %a0, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d20, i32 0, i32 1) })
  store { i64, ptr } %t3, ptr %l7
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  store i64 %t7, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  %t9 = load i64, ptr %l3, !tbaa !24
  %t10 = load i64, ptr %l4, !tbaa !24
  %t13 = icmp slt i64 %t9, %t10
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb3, label %bb4
bb3:
  br label %bb23
bb4:
  br label %bb5
bb5:
  %t17 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t17, ptr %l14, !tbaa !27
  %t18 = load i64, ptr %l3, !tbaa !24
  %t20 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr { i64, ptr }, ptr %t21, i64 %t18
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !37
  store { i64, ptr } %t23, ptr %l5, !tbaa !27
  %t25 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t28, 0
  %t32 = add i64 %t30, 1
  %t35 = icmp eq i64 %t27, %t32
  br i1 %t35, label %bb6, label %bb7
bb6:
  %t37 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t37, ptr %l24, !tbaa !27
  %t38 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !27
  %t40 = getelementptr i8, ptr %t39, i64 0
  %t41 = load i8, ptr %t40, !tbaa !32
  %t43 = icmp eq i8 %t41, 43
  store i1 %t43, ptr %l23, !tbaa !21
  br label %bb8
bb7:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb8
bb8:
  %t45 = load i1, ptr %l23, !tbaa !21
  br i1 %t45, label %bb9, label %bb10
bb9:
  %t46 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t46, ptr %l28, !tbaa !27
  %t47 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t47, 0
  store i64 %t50, ptr %l31, !tbaa !24
  %t51 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t52 = extractvalue { i64, ptr } %t51, 0
  store i64 %t52, ptr %l32, !tbaa !24
  %t53 = icmp sge i64 1, 0
  br i1 %t53, label %bb11, label %bb12
bb10:
  store i1 false, ptr %l27, !tbaa !21
  br label %bb18
bb11:
  %t55 = load i64, ptr %l31, !tbaa !24
  %t56 = icmp sle i64 1, %t55
  br i1 %t56, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @olang_loc_7d2dbc1a64f072ad_c547ba7f55386c9)
  unreachable
bb13:
  %t58 = load i64, ptr %l31, !tbaa !24
  %t59 = load i64, ptr %l32, !tbaa !24
  %t60 = icmp sle i64 %t58, %t59
  br i1 %t60, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_7d2dbc1a64f072ad_c547ba7f55386c9)
  unreachable
bb15:
  %t62 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !27
  %t64 = load i64, ptr %l31, !tbaa !24
  %t65 = getelementptr i8, ptr %t63, i64 1
  %t66 = sub i64 %t64, 1
  %t67 = insertvalue { i64, ptr } undef, i64 %t66, 0
  %t68 = insertvalue { i64, ptr } %t67, ptr %t65, 1
  %t69 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t72 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s1, ptr %v1, { i64, ptr } %t68, { i64, ptr } %t69)
  store i1 %t72, ptr %l38
  br label %bb17
bb16:
  call void @__olang_check_failed(ptr @olang_loc_7d2dbc1a64f072ad_c547ba7f55386c9)
  unreachable
bb17:
  %t73 = load i1, ptr %l38, !tbaa !21
  store i1 %t73, ptr %l27, !tbaa !21
  br label %bb18
bb18:
  %t74 = load i1, ptr %l27, !tbaa !21
  br i1 %t74, label %bb19, label %bb20
bb19:
  call void @__olang_scope_close(ptr %s1)
  store i1 true, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  br label %bb22
bb22:
  %t76 = load i64, ptr %l3, !tbaa !24
  %t79 = add i64 %t76, 1
  store i64 %t79, ptr %l3, !tbaa !24
  br label %bb2
bb23:
  call void @__olang_scope_close(ptr %s1)
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftarget_2eHasRaceRuntime(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca %"std/os:Output"
  %l5 = alloca i1
  %l9 = alloca %"std/os:Output"
  %l10 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l20 = alloca { i64, ptr }
  %l21 = alloca %"std/os:Output"
  %l22 = alloca i32
  %l24 = alloca i1
  %l30 = alloca i1
  %l33 = alloca { i64, ptr }
  %l34 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d21, i32 0, i32 1) })
  store i1 %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load i1, ptr %l5, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t7 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d22, i32 0, i32 1) }, 1
  %t8 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d22, i32 0, i32 1) }, 0
  %t10 = extractvalue { i64, ptr } %a1, 1
  %t11 = extractvalue { i64, ptr } %a1, 0
  %t12 = add i64 %t8, %t11
  %t13 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d23, i32 0, i32 1) }, 1
  %t14 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d23, i32 0, i32 1) }, 0
  %t15 = add i64 %t12, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t7, i64 %t8)
  %t17 = getelementptr i8, ptr %t16, i64 %t8
  call void @olang_textcopy(ptr %t17, ptr %t10, i64 %t11)
  %t18 = getelementptr i8, ptr %t17, i64 %t11
  call void @olang_textcopy(ptr %t18, ptr %t13, i64 %t14)
  %t19 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t16, 1
  store { i64, ptr } %t20, ptr %l2, !tbaa !27
  %t22 = call ptr @__olang_scope_hold(ptr %s0)
  %t23 = ptrtoint ptr %t22 to i64
  store i64 %t23, ptr %l10, !tbaa !24
  %t24 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_2c_202_3e_2e_2d1
  br i1 %t24, label %bb5, label %bb6
bb5:
  %t26 = call ptr @__olang_region_make(ptr %s0)
  %t27 = ptrtoint ptr %t26 to i64
  store i64 %t27, ptr %l10, !tbaa !24
  br label %bb6
bb6:
  %t28 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t28, 1
  %t31 = extractvalue { i64, ptr } %t28, 0
  %t32 = load i64, ptr %l10
  %t33 = inttoptr i64 %t32 to ptr
  %t34 = call ptr @__olang_held_alloc(ptr %t33, i64 %t31)
  call void @olang_textcopy(ptr %t34, ptr %t30, i64 %t31)
  %t35 = insertvalue { i64, ptr } undef, i64 %t31, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr %t34, 1
  store { i64, ptr } %t36, ptr %l14, !tbaa !27
  %t38 = call ptr @__olang_scope_hold(ptr %s0)
  %t39 = ptrtoint ptr %t38 to i64
  store i64 %t39, ptr %l15, !tbaa !24
  %t40 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_2c_202_3e_2e_2d1
  br i1 %t40, label %bb7, label %bb8
bb7:
  %t42 = call ptr @__olang_region_make(ptr %s0)
  %t43 = ptrtoint ptr %t42 to i64
  store i64 %t43, ptr %l15, !tbaa !24
  br label %bb8
bb8:
  %t44 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t45 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d24, i32 0, i32 1) }, 1
  %t46 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d24, i32 0, i32 1) }, 0
  %t48 = extractvalue { i64, ptr } %t44, 1
  %t49 = extractvalue { i64, ptr } %t44, 0
  %t50 = add i64 %t46, %t49
  %t51 = load i64, ptr %l15
  %t52 = inttoptr i64 %t51 to ptr
  %t53 = call ptr @__olang_held_alloc(ptr %t52, i64 %t50)
  call void @olang_textcopy(ptr %t53, ptr %t45, i64 %t46)
  %t54 = getelementptr i8, ptr %t53, i64 %t46
  call void @olang_textcopy(ptr %t54, ptr %t48, i64 %t49)
  %t55 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t56 = insertvalue { i64, ptr } %t55, ptr %t53, 1
  %t58 = mul i64 2, 16
  %t59 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t58)
  %t60 = insertvalue { i64, ptr } undef, i64 2, 0
  %t61 = insertvalue { i64, ptr } %t60, ptr %t59, 1
  store { i64, ptr } %t61, ptr %l20, !tbaa !27
  %t62 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t63 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !27
  %t65 = getelementptr { i64, ptr }, ptr %t64, i64 0
  store { i64, ptr } %t62, ptr %t65, !tbaa !37
  %t67 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !27
  %t69 = getelementptr { i64, ptr }, ptr %t68, i64 1
  store { i64, ptr } %t56, ptr %t69, !tbaa !37
  %t70 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t71 = call { i32, %"std/os:Output" } @compiler_2ftarget_2eClangSays(ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t70, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d25, i32 0, i32 1) }, i1 false)
  %t72 = extractvalue { i32, %"std/os:Output" } %t71, 1
  %t73 = extractvalue { i32, %"std/os:Output" } %t71, 0
  store i32 %t73, ptr %l22
  %t74 = icmp ne i32 %t73, 0
  br i1 %t74, label %bb10, label %ok.75, !prof !99
ok.75:
  store %"std/os:Output" %t72, ptr %l21
  br label %bb9
bb9:
  %t76 = load %"std/os:Output", ptr %l21
  store %"std/os:Output" %t76, ptr %l9
  br label %bb14
bb10:
  %t77 = load i32, ptr %l22, !tbaa !23
  %t78 = ashr i32 %t77, 16
  %t80 = icmp eq i32 %t78, 1
  store i1 %t80, ptr %l24, !tbaa !21
  %t81 = load i32, ptr %l22, !tbaa !23
  %t82 = ashr i32 %t81, 16
  %t84 = icmp eq i32 %t82, 1
  br i1 %t84, label %bb11, label %bb12
bb11:
  call void @__olang_errpay_pop()
  br label %bb12
bb12:
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb14:
  %t87 = load %"std/os:Output", ptr %l9
  store %"std/os:Output" %t87, ptr %l3
  %t88 = getelementptr %"std/os:Output", ptr %l3, i32 0, i32 0
  %t89 = load i32, ptr %t88, !tbaa !23
  %t91 = icmp eq i32 %t89, 0
  br i1 %t91, label %bb15, label %bb16
bb15:
  %t93 = getelementptr %"std/os:Output", ptr %l3, i32 0, i32 1
  %t94 = load { i64, ptr }, ptr %t93, !tbaa !27
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d26, i32 0, i32 1) }, ptr %l33, !tbaa !27
  %t97 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t98 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %s0, ptr %s0, { i64, ptr } %t94, { i64, ptr } %t97)
  store i1 %t98, ptr %l34
  br label %bb17
bb16:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb18
bb17:
  %t99 = load i1, ptr %l34, !tbaa !21
  store i1 %t99, ptr %l30, !tbaa !21
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s0)
  %t100 = load i1, ptr %l30, !tbaa !21
  store i1 %t100, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2ftarget_2eNdkClang(ptr %v0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l4 = alloca { i64, ptr }
  %lp5 = alloca ptr
  %l17 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca i32
  %l24 = alloca i1
  %l28 = alloca i1
  %l33 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l35 = alloca i64
  %l36 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s1
  %t1 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d27, i32 0, i32 1) }, 0
  %t2 = insertvalue [2 x { i64, ptr }] %t1, { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d28, i32 0, i32 1) }, 1
  %t4 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 32, i64 8)
  store [2 x { i64, ptr }] %t2, ptr %t4
  store ptr %t4, ptr %l0
  store i64 0, ptr %l1, !tbaa !24
  %t6 = load ptr, ptr %l0
  store i64 2, ptr %l2, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t9 = load i64, ptr %l1, !tbaa !24
  %t10 = load i64, ptr %l2, !tbaa !24
  %t13 = icmp slt i64 %t9, %t10
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb20
bb3:
  br label %bb4
bb4:
  %t17 = load ptr, ptr %l0
  %t18 = load i64, ptr %l1, !tbaa !24
  %t21 = getelementptr [2 x { i64, ptr }], ptr %t17, i64 0, i64 %t18
  %t22 = load { i64, ptr }, ptr %t21, !tbaa !37
  %t25 = load ptr, ptr @__olang_prog_scope
  %t27 = call { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %t25, ptr %s2, { i64, ptr } %t22)
  %t28 = extractvalue { i32, { i64, ptr } } %t27, 1
  %t29 = extractvalue { i32, { i64, ptr } } %t27, 0
  store i32 %t29, ptr %l20
  %t30 = icmp ne i32 %t29, 0
  br i1 %t30, label %bb6, label %ok.31, !prof !99
ok.31:
  store { i64, ptr } %t28, ptr %l19
  br label %bb5
bb5:
  %t32 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t32, ptr %l17, !tbaa !27
  br label %bb10
bb6:
  %t33 = load i32, ptr %l20, !tbaa !23
  %t34 = ashr i32 %t33, 16
  %t36 = icmp eq i32 %t34, 1
  br i1 %t36, label %bb7, label %bb8
bb7:
  call void @__olang_errpay_pop()
  br label %bb8
bb8:
  br label %bb9
bb9:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d29, i32 0, i32 1) }, ptr %l17, !tbaa !27
  br label %bb10
bb10:
  %t38 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t38, ptr %l4, !tbaa !27
  %t39 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t41 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s2, ptr %s2, { i64, ptr } %t39, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d30, i32 0, i32 1) })
  store i1 %t41, ptr %l24
  br label %bb11
bb11:
  %t42 = load i1, ptr %l24, !tbaa !21
  br i1 %t42, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb13:
  br label %bb14
bb14:
  %t43 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t43, 1
  %t46 = extractvalue { i64, ptr } %t43, 0
  %t47 = extractvalue { i64, ptr } { i64 48, ptr getelementptr inbounds (<{ i64, [48 x i8] }>, ptr @.d31, i32 0, i32 1) }, 1
  %t48 = extractvalue { i64, ptr } { i64 48, ptr getelementptr inbounds (<{ i64, [48 x i8] }>, ptr @.d31, i32 0, i32 1) }, 0
  %t49 = add i64 %t46, %t48
  %t50 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t49)
  call void @olang_textcopy(ptr %t50, ptr %t45, i64 %t46)
  %t51 = getelementptr i8, ptr %t50, i64 %t46
  call void @olang_textcopy(ptr %t51, ptr %t47, i64 %t48)
  %t52 = insertvalue { i64, ptr } undef, i64 %t49, 0
  %t53 = insertvalue { i64, ptr } %t52, ptr %t50, 1
  %t54 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store ptr %t54, ptr %lp5
  %t56 = load ptr, ptr %lp5
  store { i64, ptr } %t53, ptr %t56, !tbaa !27
  %t57 = load ptr, ptr %lp5
  %t58 = load { i64, ptr }, ptr %t57, !tbaa !27
  %t60 = call i1 @compiler_2ftarget_2eexecutable(ptr %v0, { i64, ptr } %t58)
  store i1 %t60, ptr %l28
  br label %bb15
bb15:
  %t61 = load i1, ptr %l28, !tbaa !21
  br i1 %t61, label %bb16, label %bb17
bb16:
  %t62 = load ptr, ptr %lp5
  %t63 = load { i64, ptr }, ptr %t62, !tbaa !27
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  store { i64, ptr } %t63, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb19:
  %t65 = load i64, ptr %l1, !tbaa !24
  %t68 = add i64 %t65, 1
  store i64 %t68, ptr %l1, !tbaa !24
  br label %bb1
bb20:
  call void @__olang_scope_close(ptr %s1)
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d32, i32 0, i32 1) }, ptr %l33, !tbaa !27
  %t70 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t70, ptr %l34, !tbaa !27
  %t71 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t72 = extractvalue { i64, ptr } %t71, 0
  store i64 %t72, ptr %l35, !tbaa !24
  %t73 = load i64, ptr %l35, !tbaa !24
  %t74 = mul i64 %t73, 1
  %t75 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t74)
  %t76 = insertvalue { i64, ptr } undef, i64 %t73, 0
  %t77 = insertvalue { i64, ptr } %t76, ptr %t75, 1
  store { i64, ptr } %t77, ptr %l36, !tbaa !27
  %t78 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !27
  %t80 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t81 = load ptr, ptr %t80, !tbaa !27
  %t82 = load i64, ptr %l35, !tbaa !24
  %t83 = mul i64 %t82, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t79, ptr %t81, i64 %t83, i1 false)
  %t84 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t84, ptr %l34, !tbaa !27
  %t85 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t85, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2ftarget_2eStripUnsafe(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l6 = alloca { i64, ptr }
  %l10 = alloca i1
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca %"std/prelude/text:StringBuilder"
  %l17 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l34 = alloca i1
  %l35 = alloca { i64, ptr }
  %l38 = alloca i1
  %l39 = alloca { i64, ptr }
  %l42 = alloca i64
  %l43 = alloca i64
  %l51 = alloca i1
  %l54 = alloca ptr
  %l55 = alloca { i64, ptr }
  %l58 = alloca i64
  %l59 = alloca i64
  %l70 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d33, i32 0, i32 1) })
  store i1 %t3, ptr %l10
  br label %bb1
bb1:
  %t4 = load i1, ptr %l10, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d34, i32 0, i32 1) }, ptr %l11, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t5, ptr %l12, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t6, 0
  store i64 %t7, ptr %l13, !tbaa !24
  %t8 = load i64, ptr %l13, !tbaa !24
  %t9 = mul i64 %t8, 1
  %t10 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t9)
  %t11 = insertvalue { i64, ptr } undef, i64 %t8, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l14, !tbaa !27
  %t13 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !27
  %t15 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !27
  %t17 = load i64, ptr %l13, !tbaa !24
  %t18 = mul i64 %t17, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t14, ptr %t16, i64 %t18, i1 false)
  %t19 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t19, ptr %l12, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t20 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t20, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t21 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t21, ptr %l15
  br label %bb5
bb5:
  %t22 = load %"std/prelude/text:StringBuilder", ptr %l15
  store %"std/prelude/text:StringBuilder" %t22, ptr %l1
  store %olang.scope zeroinitializer, ptr %s2
  %t23 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t25 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %v0, ptr %s2, ptr %s2, { i64, ptr } %t23, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d35, i32 0, i32 1) })
  store { i64, ptr } %t25, ptr %l17
  br label %bb6
bb6:
  %t26 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t26, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t27 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t27, 0
  store i64 %t29, ptr %l4, !tbaa !24
  br label %bb7
bb7:
  %t31 = load i64, ptr %l3, !tbaa !24
  %t32 = load i64, ptr %l4, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  %t37 = xor i1 %t35, true
  br i1 %t37, label %bb8, label %bb9
bb8:
  br label %bb41
bb9:
  br label %bb10
bb10:
  %t39 = load i64, ptr %l3, !tbaa !24
  %t41 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t41, ptr %l25, !tbaa !27
  %t42 = load i64, ptr %l3, !tbaa !24
  %t44 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %t45, i64 %t42
  %t47 = load { i64, ptr }, ptr %t46, !tbaa !37
  store { i64, ptr } %t47, ptr %l6, !tbaa !27
  %t51 = icmp sgt i64 %t39, 0
  br i1 %t51, label %bb11, label %bb12
bb11:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 44)
  br label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb14
bb14:
  %t54 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t56 = extractvalue { i64, ptr } %t54, 0
  %t58 = icmp sgt i64 %t56, 1
  br i1 %t58, label %bb15, label %bb16
bb15:
  %t60 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t60, ptr %l35, !tbaa !27
  %t61 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !27
  %t63 = getelementptr i8, ptr %t62, i64 0
  %t64 = load i8, ptr %t63, !tbaa !32
  %t66 = icmp eq i8 %t64, 43
  store i1 %t66, ptr %l34, !tbaa !21
  br label %bb17
bb16:
  store i1 false, ptr %l34, !tbaa !21
  br label %bb17
bb17:
  %t68 = load i1, ptr %l34, !tbaa !21
  br i1 %t68, label %bb18, label %bb19
bb18:
  %t69 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t69, ptr %l39, !tbaa !27
  %t70 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t73 = extractvalue { i64, ptr } %t70, 0
  store i64 %t73, ptr %l42, !tbaa !24
  %t74 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t75 = extractvalue { i64, ptr } %t74, 0
  store i64 %t75, ptr %l43, !tbaa !24
  %t76 = icmp sge i64 1, 0
  br i1 %t76, label %bb20, label %bb21
bb19:
  store i1 false, ptr %l38, !tbaa !21
  br label %bb27
bb20:
  %t78 = load i64, ptr %l42, !tbaa !24
  %t79 = icmp sle i64 1, %t78
  br i1 %t79, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_4b3e93141bb855fb_750a01d3487f499f)
  unreachable
bb22:
  %t81 = load i64, ptr %l42, !tbaa !24
  %t82 = load i64, ptr %l43, !tbaa !24
  %t83 = icmp sle i64 %t81, %t82
  br i1 %t83, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_4b3e93141bb855fb_750a01d3487f499f)
  unreachable
bb24:
  %t85 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !27
  %t87 = load i64, ptr %l42, !tbaa !24
  %t88 = getelementptr i8, ptr %t86, i64 1
  %t89 = sub i64 %t87, 1
  %t90 = insertvalue { i64, ptr } undef, i64 %t89, 0
  %t91 = insertvalue { i64, ptr } %t90, ptr %t88, 1
  %t94 = insertvalue { i64, ptr } undef, i64 2, 0
  %t95 = insertvalue { i64, ptr } %t94, ptr @G_2ecompiler_2ftarget_2eIeeeUnsafe, 1
  %t97 = load ptr, ptr @__olang_prog_scope
  %t100 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2eHas_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t97, ptr %s2, { i64, ptr } %t95, { i64, ptr } %t91)
  store i1 %t100, ptr %l51
  br label %bb26
bb25:
  call void @__olang_check_failed(ptr @olang_loc_4b3e93141bb855fb_750a01d3487f499f)
  unreachable
bb26:
  %t101 = load i1, ptr %l51, !tbaa !21
  store i1 %t101, ptr %l38, !tbaa !21
  br label %bb27
bb27:
  %t102 = load i1, ptr %l38, !tbaa !21
  br i1 %t102, label %bb28, label %bb29
bb28:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 45)
  br label %bb30
bb29:
  %t106 = load { i64, ptr }, ptr %l6, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %l1, { i64, ptr } %t106)
  br label %bb38
bb30:
  store ptr %l1, ptr %l54, !tbaa !29
  %t109 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t109, ptr %l55, !tbaa !27
  %t110 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t113 = extractvalue { i64, ptr } %t110, 0
  store i64 %t113, ptr %l58, !tbaa !24
  %t114 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t115 = extractvalue { i64, ptr } %t114, 0
  store i64 %t115, ptr %l59, !tbaa !24
  %t116 = icmp sge i64 1, 0
  br i1 %t116, label %bb31, label %bb32
bb31:
  %t118 = load i64, ptr %l58, !tbaa !24
  %t119 = icmp sle i64 1, %t118
  br i1 %t119, label %bb33, label %bb34
bb32:
  call void @__olang_check_failed(ptr @olang_loc_a61f3cd56da1d37e_58843bed9934bc22)
  unreachable
bb33:
  %t121 = load i64, ptr %l58, !tbaa !24
  %t122 = load i64, ptr %l59, !tbaa !24
  %t123 = icmp sle i64 %t121, %t122
  br i1 %t123, label %bb35, label %bb36
bb34:
  call void @__olang_check_failed(ptr @olang_loc_a61f3cd56da1d37e_58843bed9934bc22)
  unreachable
bb35:
  %t125 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t126 = load ptr, ptr %t125, !tbaa !27
  %t127 = load i64, ptr %l58, !tbaa !24
  %t128 = getelementptr i8, ptr %t126, i64 1
  %t129 = sub i64 %t127, 1
  %t130 = insertvalue { i64, ptr } undef, i64 %t129, 0
  %t131 = insertvalue { i64, ptr } %t130, ptr %t128, 1
  %t132 = load ptr, ptr %l54, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %t132, { i64, ptr } %t131)
  br label %bb37
bb36:
  call void @__olang_check_failed(ptr @olang_loc_a61f3cd56da1d37e_58843bed9934bc22)
  unreachable
bb37:
  br label %bb39
bb38:
  br label %bb39
bb39:
  br label %bb40
bb40:
  %t134 = load i64, ptr %l3, !tbaa !24
  %t137 = add i64 %t134, 1
  store i64 %t137, ptr %l3, !tbaa !24
  br label %bb7
bb41:
  call void @__olang_scope_close(ptr %s2)
  %t140 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t140, ptr %l70
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s0)
  %t141 = load { i64, ptr }, ptr %l70, !tbaa !27
  store { i64, ptr } %t141, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2ftarget_2eTarget_2eResolveOn(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, { i64, ptr } %a0, { i64, ptr } %a1, i1 %a2, { i64, ptr } %a3, { i64, ptr } %a4, ptr %a5, { i64, ptr } %a6) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca i1
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %lp7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i1
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l15 = alloca { i64, ptr }
  %l16 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l17 = alloca ptr
  %l18 = alloca i64
  %l19 = alloca i64
  %lp21 = alloca ptr
  %l22 = alloca %"compiler/target:Target"
  %l24 = alloca { i64, ptr }
  %l27 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i32
  %l34 = alloca { i64, ptr }
  %l35 = alloca i64
  %l36 = alloca i64
  %l41 = alloca i64
  %l44 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i32
  %l51 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %l53 = alloca i64
  %l54 = alloca i64
  %l68 = alloca { i64, ptr }
  %l69 = alloca { i64, ptr }
  %l71 = alloca i64
  %l74 = alloca i64
  %l75 = alloca i64
  %l83 = alloca i64
  %l88 = alloca i1
  %l90 = alloca ptr
  %l92 = alloca %"compiler/diagmsg:Msg"
  %l93 = alloca i32
  %l98 = alloca ptr
  %l100 = alloca %"compiler/diagmsg:Msg"
  %l101 = alloca i32
  %l103 = alloca i64
  %l105 = alloca i64
  %l106 = alloca i32
  %l107 = alloca { i64, ptr }
  %l108 = alloca i64
  %l109 = alloca i64
  %l117 = alloca { i64, ptr }
  %l119 = alloca { i64, ptr }
  %l121 = alloca i1
  %l124 = alloca i1
  %l126 = alloca ptr
  %l128 = alloca %"compiler/diagmsg:Msg"
  %l129 = alloca i32
  %l131 = alloca { i64, ptr }
  %l136 = alloca i1
  %l138 = alloca i1
  %l140 = alloca ptr
  %l142 = alloca %"compiler/diagmsg:Msg"
  %l143 = alloca i32
  %l146 = alloca i1
  %l148 = alloca i1
  %l149 = alloca i1
  %l152 = alloca { i64, ptr }
  %l153 = alloca i1
  %l154 = alloca ptr
  %l156 = alloca %"compiler/diagmsg:Msg"
  %l157 = alloca i32
  %l161 = alloca { i64, ptr }
  %l162 = alloca i1
  %l163 = alloca i1
  %l166 = alloca { i64, ptr }
  %l167 = alloca i1
  %l168 = alloca i1
  %l171 = alloca { i64, ptr }
  %l172 = alloca i1
  %l173 = alloca ptr
  %l175 = alloca %"compiler/diagmsg:Msg"
  %l176 = alloca i32
  %l180 = alloca { i64, ptr }
  %l181 = alloca i1
  %l182 = alloca i1
  %l184 = alloca i1
  %l185 = alloca ptr
  %l187 = alloca %"compiler/diagmsg:Msg"
  %l188 = alloca i32
  %l191 = alloca i64
  %l194 = alloca ptr
  %l196 = alloca %"compiler/diagmsg:Msg"
  %l197 = alloca i32
  %l199 = alloca i64
  %l205 = alloca { i64, ptr }
  %l210 = alloca i1
  %l212 = alloca i1
  %l214 = alloca i1
  %l216 = alloca i1
  %l218 = alloca i1
  %l220 = alloca { i64, ptr }
  %l222 = alloca i1
  %l224 = alloca i1
  %l234 = alloca i1
  %l235 = alloca { i64, ptr }
  %l237 = alloca i1
  %l238 = alloca i1
  %l240 = alloca ptr
  %l242 = alloca %"compiler/diagmsg:Msg"
  %l243 = alloca i32
  %l246 = alloca i1
  %l248 = alloca ptr
  %l250 = alloca %"compiler/diagmsg:Msg"
  %l251 = alloca i32
  %l254 = alloca i1
  %l256 = alloca i1
  %l258 = alloca ptr
  %l261 = alloca %"compiler/diagmsg:Msg"
  %l262 = alloca i32
  %l265 = alloca i1
  %l266 = alloca i64
  %l268 = alloca { i64, ptr }
  %l270 = alloca { i64, ptr }
  %l273 = alloca i1
  %l274 = alloca ptr
  %l276 = alloca %"compiler/diagmsg:Msg"
  %l277 = alloca i32
  %l280 = alloca i1
  %l282 = alloca { i64, ptr }
  %l285 = alloca { i64, ptr }
  %l287 = alloca i1
  %l290 = alloca i1
  %l291 = alloca ptr
  %l292 = alloca { i64, ptr }
  %l293 = alloca { i64, ptr }
  %l296 = alloca i1
  %l298 = alloca ptr
  %l300 = alloca %"compiler/diagmsg:Msg"
  %l301 = alloca i32
  %l303 = alloca %"compiler/target:Target"
  %l304 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l306 = alloca { i64, ptr }
  %l308 = alloca { i64, ptr }
  %l310 = alloca i1
  %l312 = alloca ptr
  %l313 = alloca i64
  %l319 = alloca ptr
  %l320 = alloca i64
  %l343 = alloca %"std/os:Output"
  %l345 = alloca { i64, ptr }
  %l348 = alloca %"std/os:Output"
  %l349 = alloca i32
  %l351 = alloca i1
  %l354 = alloca ptr
  %l356 = alloca %"compiler/diagmsg:Msg"
  %l357 = alloca i32
  %l361 = alloca ptr
  %l363 = alloca %"compiler/diagmsg:Msg"
  %l364 = alloca i32
  %l368 = alloca i32
  %l372 = alloca ptr
  %l374 = alloca %"compiler/diagmsg:Msg"
  %l375 = alloca i32
  %l377 = alloca ptr
  %l379 = alloca %"compiler/diagmsg:Msg"
  %l380 = alloca i32
  %l383 = alloca i1
  %l384 = alloca { i64, ptr }
  %l387 = alloca i1
  %l389 = alloca ptr
  %l391 = alloca %"compiler/diagmsg:Msg"
  %l392 = alloca i32
  %l394 = alloca i64
  %l401 = alloca { i64, ptr }
  %l403 = alloca %"compiler/target:Target"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %s29 = alloca %olang.scope
  %s35 = alloca %olang.scope
  %rv = alloca i32
  %t1 = alloca %"compiler/target:Target", align 8
  store { i64, ptr } %a0, ptr %l0
  store i1 %a2, ptr %l2
  store { i64, ptr } %a4, ptr %l4
  store ptr %a5, ptr %l5
  store { i64, ptr } %a6, ptr %l6
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  call void @compiler_2ftarget_3aTarget_2ector(ptr %t1, ptr %v6)
  call void @llvm.memmove.p0.p0.i64(ptr %l22, ptr %t1, i64 152, i1 false)
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v6, i64 152, i64 8)
  store ptr %t2, ptr %lp7
  %t3 = load ptr, ptr %lp7
  call void @llvm.memmove.p0.p0.i64(ptr %t3, ptr %l22, i64 152, i1 false)
  %t4 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t5 = load ptr, ptr %lp7
  %t6 = getelementptr %"compiler/target:Target", ptr %t5, i32 0, i32 0
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  store { i64, ptr } %t7, ptr %l24, !tbaa !27
  %t9 = load ptr, ptr %lp7
  %t10 = getelementptr %"compiler/target:Target", ptr %t9, i32 0, i32 0
  store { i64, ptr } %t4, ptr %t10, !tbaa !27
  %t11 = load i1, ptr @olang_2esole_2ecompiler_2ftarget_3aTarget_2e0
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load { i64, ptr }, ptr %l24
  %t14 = extractvalue { i64, ptr } %t13, 1
  call void @__olang_region_release(ptr %t14)
  store { i64, ptr } zeroinitializer, ptr %l24
  br label %bb3
bb3:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d36, i32 0, i32 1) }, ptr %l8, !tbaa !27
  %t15 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t15, ptr %l9, !tbaa !27
  store i1 true, ptr %l10, !tbaa !21
  store i64 -1, ptr %l11, !tbaa !24
  %t17 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t20 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %v0, { i64, ptr } %t17, i8 45)
  %t21 = extractvalue { i32, i64 } %t20, 1
  %t22 = extractvalue { i32, i64 } %t20, 0
  store i32 %t22, ptr %l31
  %t23 = icmp ne i32 %t22, 0
  br i1 %t23, label %bb5, label %ok.24, !prof !99
ok.24:
  store i64 %t21, ptr %l30
  br label %bb4
bb4:
  %t25 = load i64, ptr %l30, !tbaa !24
  store i64 %t25, ptr %l27, !tbaa !24
  br label %bb7
bb5:
  br label %bb6
bb6:
  store i64 -1, ptr %l27, !tbaa !24
  br label %bb7
bb7:
  %t26 = load i64, ptr %l27, !tbaa !24
  store i64 %t26, ptr %l12, !tbaa !24
  %t27 = load i64, ptr %l12, !tbaa !24
  %t29 = icmp sge i64 %t27, 0
  br i1 %t29, label %bb8, label %bb9
bb8:
  %t31 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t31, ptr %l34, !tbaa !27
  %t32 = load i64, ptr %l12, !tbaa !24
  store i64 %t32, ptr %l35, !tbaa !24
  %t33 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t33, 0
  store i64 %t34, ptr %l36, !tbaa !24
  %t35 = icmp sge i64 0, 0
  br i1 %t35, label %bb10, label %bb11
bb9:
  br label %bb17
bb10:
  %t37 = load i64, ptr %l35, !tbaa !24
  %t38 = icmp sle i64 0, %t37
  br i1 %t38, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_5afbe203adc8766f_c0acc38cff9c62b)
  unreachable
bb12:
  %t40 = load i64, ptr %l35, !tbaa !24
  %t41 = load i64, ptr %l36, !tbaa !24
  %t42 = icmp sle i64 %t40, %t41
  br i1 %t42, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_5afbe203adc8766f_c0acc38cff9c62b)
  unreachable
bb14:
  %t44 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = load i64, ptr %l35, !tbaa !24
  %t47 = getelementptr i8, ptr %t45, i64 0
  %t48 = sub i64 %t46, 0
  %t49 = insertvalue { i64, ptr } undef, i64 %t48, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t47, 1
  %t52 = call i64 @compiler_2ftarget_2earchIndex(ptr %v0, { i64, ptr } %t50)
  store i64 %t52, ptr %l41
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_5afbe203adc8766f_c0acc38cff9c62b)
  unreachable
bb16:
  %t53 = load i64, ptr %l41, !tbaa !24
  store i64 %t53, ptr %l11, !tbaa !24
  br label %bb17
bb17:
  %t54 = load i64, ptr %l11, !tbaa !24
  %t56 = icmp sge i64 %t54, 0
  br i1 %t56, label %bb18, label %bb19
bb18:
  store %olang.scope zeroinitializer, ptr %s2
  %t58 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t61 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %v0, { i64, ptr } %t58, i8 58)
  %t62 = extractvalue { i32, i64 } %t61, 1
  %t63 = extractvalue { i32, i64 } %t61, 0
  store i32 %t63, ptr %l48
  %t64 = icmp ne i32 %t63, 0
  br i1 %t64, label %bb21, label %ok.65, !prof !99
ok.65:
  store i64 %t62, ptr %l47
  br label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s16
  %t66 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d37, i32 0, i32 1) }, ptr %l161, !tbaa !27
  %t69 = load { i64, ptr }, ptr %l161, !tbaa !27
  %t70 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %s16, { i64, ptr } %t66, { i64, ptr } %t69)
  store i1 %t70, ptr %l162
  br label %bb113
bb20:
  %t71 = load i64, ptr %l47, !tbaa !24
  store i64 %t71, ptr %l44, !tbaa !24
  br label %bb23
bb21:
  br label %bb22
bb22:
  store i64 -1, ptr %l44, !tbaa !24
  br label %bb23
bb23:
  %t72 = load i64, ptr %l44, !tbaa !24
  store i64 %t72, ptr %l13, !tbaa !24
  %t73 = load i64, ptr %l13, !tbaa !24
  %t75 = icmp sge i64 %t73, 0
  br i1 %t75, label %bb24, label %bb25
bb24:
  %t77 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t77, ptr %l52, !tbaa !27
  %t78 = load i64, ptr %l13, !tbaa !24
  store i64 %t78, ptr %l53, !tbaa !24
  %t79 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t80 = extractvalue { i64, ptr } %t79, 0
  store i64 %t80, ptr %l54, !tbaa !24
  %t81 = icmp sge i64 0, 0
  br i1 %t81, label %bb26, label %bb27
bb25:
  %t83 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t85 = extractvalue { i64, ptr } %t83, 1
  %t86 = extractvalue { i64, ptr } %t83, 0
  %t87 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t86)
  call void @olang_textcopy(ptr %t87, ptr %t85, i64 %t86)
  %t88 = insertvalue { i64, ptr } undef, i64 %t86, 0
  %t89 = insertvalue { i64, ptr } %t88, ptr %t87, 1
  store { i64, ptr } %t89, ptr %l51, !tbaa !27
  br label %bb32
bb26:
  %t92 = load i64, ptr %l53, !tbaa !24
  %t93 = icmp sle i64 0, %t92
  br i1 %t93, label %bb28, label %bb29
bb27:
  call void @__olang_check_failed(ptr @olang_loc_ccc584ee5db490f2_f240216cb9bcdd2e)
  unreachable
bb28:
  %t95 = load i64, ptr %l53, !tbaa !24
  %t96 = load i64, ptr %l54, !tbaa !24
  %t97 = icmp sle i64 %t95, %t96
  br i1 %t97, label %bb30, label %bb31
bb29:
  call void @__olang_check_failed(ptr @olang_loc_ccc584ee5db490f2_f240216cb9bcdd2e)
  unreachable
bb30:
  %t99 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !27
  %t101 = load i64, ptr %l53, !tbaa !24
  %t102 = getelementptr i8, ptr %t100, i64 0
  %t103 = sub i64 %t101, 0
  %t104 = insertvalue { i64, ptr } undef, i64 %t103, 0
  %t105 = insertvalue { i64, ptr } %t104, ptr %t102, 1
  %t107 = extractvalue { i64, ptr } %t105, 1
  %t108 = extractvalue { i64, ptr } %t105, 0
  %t109 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t108)
  call void @olang_textcopy(ptr %t109, ptr %t107, i64 %t108)
  %t110 = insertvalue { i64, ptr } undef, i64 %t108, 0
  %t111 = insertvalue { i64, ptr } %t110, ptr %t109, 1
  store { i64, ptr } %t111, ptr %l51, !tbaa !27
  br label %bb32
bb31:
  call void @__olang_check_failed(ptr @olang_loc_ccc584ee5db490f2_f240216cb9bcdd2e)
  unreachable
bb32:
  %t114 = load { i64, ptr }, ptr %l51, !tbaa !27
  store { i64, ptr } %t114, ptr %l8, !tbaa !27
  %t115 = load i64, ptr %l13, !tbaa !24
  %t117 = icmp sge i64 %t115, 0
  store i1 %t117, ptr %l10, !tbaa !21
  %t119 = load i64, ptr %l13, !tbaa !24
  %t121 = icmp sge i64 %t119, 0
  br i1 %t121, label %bb33, label %bb34
bb33:
  %t123 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t123, ptr %l69, !tbaa !27
  %t124 = load i64, ptr %l13, !tbaa !24
  %t126 = add i64 %t124, 1
  store i64 %t126, ptr %l71, !tbaa !24
  %t127 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t130 = extractvalue { i64, ptr } %t127, 0
  store i64 %t130, ptr %l74, !tbaa !24
  %t131 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t132 = extractvalue { i64, ptr } %t131, 0
  store i64 %t132, ptr %l75, !tbaa !24
  %t133 = load i64, ptr %l71, !tbaa !24
  %t134 = icmp sge i64 %t133, 0
  br i1 %t134, label %bb35, label %bb36
bb34:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d38, i32 0, i32 1) }, ptr %l68, !tbaa !27
  br label %bb41
bb35:
  %t136 = load i64, ptr %l71, !tbaa !24
  %t137 = load i64, ptr %l74, !tbaa !24
  %t138 = icmp sle i64 %t136, %t137
  br i1 %t138, label %bb37, label %bb38
bb36:
  call void @__olang_check_failed(ptr @olang_loc_8b94dd4b00821371_32c50240ce2e918d)
  unreachable
bb37:
  %t140 = load i64, ptr %l74, !tbaa !24
  %t141 = load i64, ptr %l75, !tbaa !24
  %t142 = icmp sle i64 %t140, %t141
  br i1 %t142, label %bb39, label %bb40
bb38:
  call void @__olang_check_failed(ptr @olang_loc_8b94dd4b00821371_32c50240ce2e918d)
  unreachable
bb39:
  %t144 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t145 = load ptr, ptr %t144, !tbaa !27
  %t146 = load i64, ptr %l71, !tbaa !24
  %t147 = load i64, ptr %l74, !tbaa !24
  %t148 = getelementptr i8, ptr %t145, i64 %t146
  %t149 = sub i64 %t147, %t146
  %t150 = insertvalue { i64, ptr } undef, i64 %t149, 0
  %t151 = insertvalue { i64, ptr } %t150, ptr %t148, 1
  %t153 = extractvalue { i64, ptr } %t151, 1
  %t154 = extractvalue { i64, ptr } %t151, 0
  %t155 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t154)
  call void @olang_textcopy(ptr %t155, ptr %t153, i64 %t154)
  %t156 = insertvalue { i64, ptr } undef, i64 %t154, 0
  %t157 = insertvalue { i64, ptr } %t156, ptr %t155, 1
  store { i64, ptr } %t157, ptr %l68, !tbaa !27
  br label %bb41
bb40:
  call void @__olang_check_failed(ptr @olang_loc_8b94dd4b00821371_32c50240ce2e918d)
  unreachable
bb41:
  %t160 = load { i64, ptr }, ptr %l68, !tbaa !27
  store { i64, ptr } %t160, ptr %l9, !tbaa !27
  %t161 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t163 = call i64 @compiler_2ftarget_2eandroidLevel(ptr %s0, { i64, ptr } %t161)
  store i64 %t163, ptr %l83
  br label %bb42
bb42:
  %t164 = load i64, ptr %l83, !tbaa !24
  %t165 = load ptr, ptr %lp7
  %t166 = getelementptr %"compiler/target:Target", ptr %t165, i32 0, i32 12
  store i64 %t164, ptr %t166, !tbaa !24
  %t167 = load ptr, ptr %lp7
  %t168 = getelementptr %"compiler/target:Target", ptr %t167, i32 0, i32 12
  %t169 = load i64, ptr %t168, !tbaa !24
  %t171 = icmp ne i64 %t169, 0
  br i1 %t171, label %bb43, label %bb44
bb43:
  store %olang.scope zeroinitializer, ptr %s6
  %t173 = load i64, ptr %l11, !tbaa !24
  %t175 = getelementptr [2 x { i64, ptr }], ptr @G_2ecompiler_2ftarget_2eArchs, i64 0, i64 %t173
  %t176 = load { i64, ptr }, ptr %t175, !tbaa !37
  %t177 = load ptr, ptr @__olang_prog_scope
  %t179 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %t177, ptr %s6, { i64, ptr } %t176, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d39, i32 0, i32 1) })
  store i1 %t179, ptr %l88
  br label %bb45
bb44:
  %t180 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t180, ptr %l119, !tbaa !27
  %t181 = load { i64, ptr }, ptr %l119, !tbaa !27
  %t182 = extractvalue { i64, ptr } %t181, 1
  %t183 = call ptr @__olang_scope_of(ptr %t182, ptr null)
  %t184 = call ptr @__olang_scope_hold(ptr %t183)
  %t185 = ptrtoint ptr %t184 to i64
  %t187 = inttoptr i64 %t185 to ptr
  %t188 = load { i64, ptr }, ptr %l119, !tbaa !27
  %t189 = call i1 @compiler_2ftarget_2ewindowsTriple(ptr %t187, { i64, ptr } %t188)
  store i1 %t189, ptr %l121
  br label %bb72
bb45:
  %t190 = load i1, ptr %l88, !tbaa !21
  %t191 = xor i1 %t190, true
  br i1 %t191, label %bb46, label %bb47
bb46:
  %t193 = load ptr, ptr %l5, !tbaa !29
  store ptr %t193, ptr %l90, !tbaa !29
  %t194 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t196 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTargetUnsupported(ptr %v0, ptr %v4, { i64, ptr } %t194)
  store %"compiler/diagmsg:Msg" %t196, ptr %l92
  br label %bb48
bb47:
  br label %bb52
bb48:
  %t197 = load ptr, ptr %l90, !tbaa !29
  %t198 = load %"compiler/diagmsg:Msg", ptr %l92
  %t199 = call i32 @compiler_2ftarget_2erefuse(ptr %v4, ptr %v4, ptr %t197, %"compiler/diagmsg:Msg" %t198)
  store i32 %t199, ptr %l93
  %t200 = icmp ne i32 %t199, 0
  br i1 %t200, label %bb50, label %ok.201, !prof !99
ok.201:
  br label %bb49
bb49:
  br label %bb51
bb50:
  %t202 = load i32, ptr %l93, !tbaa !23
  %t203 = lshr i32 %t202, 16
  %t204 = and i32 %t202, 65535
  %t205 = icmp eq i32 %t203, 1
  %t206 = select i1 %t205, i32 1, i32 0
  %t207 = icmp eq i32 %t202, 0
  %t208 = shl i32 %t206, 16
  %t209 = or i32 %t208, %t204
  %t210 = select i1 %t207, i32 0, i32 %t209
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store i32 %t210, ptr %rv
  br label %ret
bb51:
  br label %bb52
bb52:
  %t212 = load ptr, ptr %lp7
  %t213 = getelementptr %"compiler/target:Target", ptr %t212, i32 0, i32 12
  %t214 = load i64, ptr %t213, !tbaa !24
  %t215 = load i64, ptr @G_2ecompiler_2ftarget_2eAndroidApi, !tbaa !24
  %t218 = icmp slt i64 %t214, %t215
  br i1 %t218, label %bb53, label %bb54
bb53:
  %t220 = load ptr, ptr %l5, !tbaa !29
  store ptr %t220, ptr %l98, !tbaa !29
  %t221 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t223 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTargetAndroidApi(ptr %v0, ptr %v4, { i64, ptr } %t221)
  store %"compiler/diagmsg:Msg" %t223, ptr %l100
  br label %bb55
bb54:
  br label %bb59
bb55:
  %t224 = load ptr, ptr %l98, !tbaa !29
  %t225 = load %"compiler/diagmsg:Msg", ptr %l100
  %t226 = call i32 @compiler_2ftarget_2erefuse(ptr %v4, ptr %v4, ptr %t224, %"compiler/diagmsg:Msg" %t225)
  store i32 %t226, ptr %l101
  %t227 = icmp ne i32 %t226, 0
  br i1 %t227, label %bb57, label %ok.228, !prof !99
ok.228:
  br label %bb56
bb56:
  br label %bb58
bb57:
  %t229 = load i32, ptr %l101, !tbaa !23
  %t230 = lshr i32 %t229, 16
  %t231 = and i32 %t229, 65535
  %t232 = icmp eq i32 %t230, 1
  %t233 = select i1 %t232, i32 1, i32 0
  %t234 = icmp eq i32 %t229, 0
  %t235 = shl i32 %t233, 16
  %t236 = or i32 %t235, %t231
  %t237 = select i1 %t234, i32 0, i32 %t236
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store i32 %t237, ptr %rv
  br label %ret
bb58:
  br label %bb59
bb59:
  %t239 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t241 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %s0, ptr %s6, { i64, ptr } %t239, { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d40, i32 0, i32 1) })
  %t242 = extractvalue { i32, i64 } %t241, 1
  %t243 = extractvalue { i32, i64 } %t241, 0
  store i32 %t243, ptr %l106
  %t244 = icmp ne i32 %t243, 0
  br i1 %t244, label %bb61, label %ok.245, !prof !99
ok.245:
  store i64 %t242, ptr %l105
  br label %bb60
bb60:
  %t246 = load i64, ptr %l105, !tbaa !24
  store i64 %t246, ptr %l103, !tbaa !24
  br label %bb63
bb61:
  br label %bb62
bb62:
  store i64 0, ptr %l103, !tbaa !24
  br label %bb63
bb63:
  %t247 = load i64, ptr %l103, !tbaa !24
  %t248 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t248, ptr %l107, !tbaa !27
  store i64 %t247, ptr %l108, !tbaa !24
  %t250 = load { i64, ptr }, ptr %l107, !tbaa !27
  %t251 = extractvalue { i64, ptr } %t250, 0
  store i64 %t251, ptr %l109, !tbaa !24
  %t252 = icmp sge i64 0, 0
  br i1 %t252, label %bb64, label %bb65
bb64:
  %t254 = load i64, ptr %l108, !tbaa !24
  %t255 = icmp sle i64 0, %t254
  br i1 %t255, label %bb66, label %bb67
bb65:
  call void @__olang_check_failed(ptr @olang_loc_d5ce9bb3e7f57104_9ca6c947c8d4a4b0)
  unreachable
bb66:
  %t257 = load i64, ptr %l108, !tbaa !24
  %t258 = load i64, ptr %l109, !tbaa !24
  %t259 = icmp sle i64 %t257, %t258
  br i1 %t259, label %bb68, label %bb69
bb67:
  call void @__olang_check_failed(ptr @olang_loc_d5ce9bb3e7f57104_9ca6c947c8d4a4b0)
  unreachable
bb68:
  %t261 = getelementptr { i64, ptr }, ptr %l107, i32 0, i32 1
  %t262 = load ptr, ptr %t261, !tbaa !27
  %t263 = load i64, ptr %l108, !tbaa !24
  %t264 = getelementptr i8, ptr %t262, i64 0
  %t265 = sub i64 %t263, 0
  %t266 = insertvalue { i64, ptr } undef, i64 %t265, 0
  %t267 = insertvalue { i64, ptr } %t266, ptr %t264, 1
  %t268 = load ptr, ptr %lp7
  %t269 = getelementptr %"compiler/target:Target", ptr %t268, i32 0, i32 12
  %t270 = load i64, ptr %t269, !tbaa !24
  %t272 = extractvalue { i64, ptr } %t267, 1
  %t273 = extractvalue { i64, ptr } %t267, 0
  %t274 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d41, i32 0, i32 1) }, 1
  %t275 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d41, i32 0, i32 1) }, 0
  %t276 = add i64 %t273, %t275
  %t278 = call i64 @__olang_fmt_i64(ptr null, i64 %t270)
  %t279 = add i64 %t276, %t278
  %t280 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t279)
  call void @olang_textcopy(ptr %t280, ptr %t272, i64 %t273)
  %t281 = getelementptr i8, ptr %t280, i64 %t273
  call void @olang_textcopy(ptr %t281, ptr %t274, i64 %t275)
  %t282 = getelementptr i8, ptr %t281, i64 %t275
  %t283 = call i64 @__olang_fmt_i64(ptr %t282, i64 %t270)
  %t284 = insertvalue { i64, ptr } undef, i64 %t279, 0
  %t285 = insertvalue { i64, ptr } %t284, ptr %t280, 1
  store { i64, ptr } %t285, ptr %l8, !tbaa !27
  %t288 = load ptr, ptr %lp7
  %t289 = getelementptr %"compiler/target:Target", ptr %t288, i32 0, i32 3
  %t290 = load { i64, ptr }, ptr %t289, !tbaa !27
  store { i64, ptr } %t290, ptr %l117, !tbaa !27
  %t291 = load ptr, ptr %lp7
  %t292 = getelementptr %"compiler/target:Target", ptr %t291, i32 0, i32 3
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d42, i32 0, i32 1) }, ptr %t292, !tbaa !27
  %t293 = load i1, ptr @olang_2esole_2ecompiler_2ftarget_3aTarget_2e3
  br i1 %t293, label %bb70, label %bb71
bb69:
  call void @__olang_check_failed(ptr @olang_loc_d5ce9bb3e7f57104_9ca6c947c8d4a4b0)
  unreachable
bb70:
  %t295 = load { i64, ptr }, ptr %l117
  %t296 = extractvalue { i64, ptr } %t295, 1
  call void @__olang_region_release(ptr %t296)
  store { i64, ptr } zeroinitializer, ptr %l117
  br label %bb71
bb71:
  call void @__olang_scope_close(ptr %s6)
  br label %bb97
bb72:
  %t297 = load i1, ptr %l121, !tbaa !21
  br i1 %t297, label %bb73, label %bb74
bb73:
  store %olang.scope zeroinitializer, ptr %s11
  %t298 = load i64, ptr %l11, !tbaa !24
  %t300 = getelementptr [2 x { i64, ptr }], ptr @G_2ecompiler_2ftarget_2eArchs, i64 0, i64 %t298
  %t301 = load { i64, ptr }, ptr %t300, !tbaa !37
  %t302 = load ptr, ptr @__olang_prog_scope
  %t304 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %t302, ptr %s11, { i64, ptr } %t301, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d43, i32 0, i32 1) })
  store i1 %t304, ptr %l124
  br label %bb75
bb74:
  store %olang.scope zeroinitializer, ptr %s13
  %t305 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t307 = extractvalue { i64, ptr } %t305, 0
  %t309 = icmp sgt i64 %t307, 10
  br i1 %t309, label %bb85, label %bb86
bb75:
  %t311 = load i1, ptr %l124, !tbaa !21
  %t312 = xor i1 %t311, true
  br i1 %t312, label %bb76, label %bb77
bb76:
  %t314 = load ptr, ptr %l5, !tbaa !29
  store ptr %t314, ptr %l126, !tbaa !29
  %t315 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t317 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTargetUnsupported(ptr %v0, ptr %v4, { i64, ptr } %t315)
  store %"compiler/diagmsg:Msg" %t317, ptr %l128
  br label %bb78
bb77:
  br label %bb82
bb78:
  %t318 = load ptr, ptr %l126, !tbaa !29
  %t319 = load %"compiler/diagmsg:Msg", ptr %l128
  %t320 = call i32 @compiler_2ftarget_2erefuse(ptr %v4, ptr %v4, ptr %t318, %"compiler/diagmsg:Msg" %t319)
  store i32 %t320, ptr %l129
  %t321 = icmp ne i32 %t320, 0
  br i1 %t321, label %bb80, label %ok.322, !prof !99
ok.322:
  br label %bb79
bb79:
  br label %bb81
bb80:
  %t323 = load i32, ptr %l129, !tbaa !23
  %t324 = lshr i32 %t323, 16
  %t325 = and i32 %t323, 65535
  %t326 = icmp eq i32 %t324, 1
  %t327 = select i1 %t326, i32 1, i32 0
  %t328 = icmp eq i32 %t323, 0
  %t329 = shl i32 %t327, 16
  %t330 = or i32 %t329, %t325
  %t331 = select i1 %t328, i32 0, i32 %t330
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store i32 %t331, ptr %rv
  br label %ret
bb81:
  br label %bb82
bb82:
  store { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d44, i32 0, i32 1) }, ptr %l8, !tbaa !27
  %t333 = load ptr, ptr %lp7
  %t334 = getelementptr %"compiler/target:Target", ptr %t333, i32 0, i32 3
  %t335 = load { i64, ptr }, ptr %t334, !tbaa !27
  store { i64, ptr } %t335, ptr %l131, !tbaa !27
  %t336 = load ptr, ptr %lp7
  %t337 = getelementptr %"compiler/target:Target", ptr %t336, i32 0, i32 3
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d45, i32 0, i32 1) }, ptr %t337, !tbaa !27
  %t338 = load i1, ptr @olang_2esole_2ecompiler_2ftarget_3aTarget_2e3
  br i1 %t338, label %bb83, label %bb84
bb83:
  %t340 = load { i64, ptr }, ptr %l131
  %t341 = extractvalue { i64, ptr } %t340, 1
  call void @__olang_region_release(ptr %t341)
  store { i64, ptr } zeroinitializer, ptr %l131
  br label %bb84
bb84:
  call void @__olang_scope_close(ptr %s11)
  br label %bb96
bb85:
  %t342 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t344 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %s0, ptr %s13, { i64, ptr } %t342, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d46, i32 0, i32 1) })
  store i1 %t344, ptr %l138
  br label %bb87
bb86:
  store i1 false, ptr %l136, !tbaa !21
  br label %bb88
bb87:
  %t345 = load i1, ptr %l138, !tbaa !21
  store i1 %t345, ptr %l136, !tbaa !21
  br label %bb88
bb88:
  %t346 = load i1, ptr %l136, !tbaa !21
  %t347 = xor i1 %t346, true
  br i1 %t347, label %bb89, label %bb90
bb89:
  %t349 = load ptr, ptr %l5, !tbaa !29
  store ptr %t349, ptr %l140, !tbaa !29
  %t350 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t352 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTargetUnsupported(ptr %v0, ptr %v4, { i64, ptr } %t350)
  store %"compiler/diagmsg:Msg" %t352, ptr %l142
  br label %bb91
bb90:
  br label %bb95
bb91:
  %t353 = load ptr, ptr %l140, !tbaa !29
  %t354 = load %"compiler/diagmsg:Msg", ptr %l142
  %t355 = call i32 @compiler_2ftarget_2erefuse(ptr %v4, ptr %v4, ptr %t353, %"compiler/diagmsg:Msg" %t354)
  store i32 %t355, ptr %l143
  %t356 = icmp ne i32 %t355, 0
  br i1 %t356, label %bb93, label %ok.357, !prof !99
ok.357:
  br label %bb92
bb92:
  br label %bb94
bb93:
  %t358 = load i32, ptr %l143, !tbaa !23
  %t359 = lshr i32 %t358, 16
  %t360 = and i32 %t358, 65535
  %t361 = icmp eq i32 %t359, 1
  %t362 = select i1 %t361, i32 1, i32 0
  %t363 = icmp eq i32 %t358, 0
  %t364 = shl i32 %t362, 16
  %t365 = or i32 %t364, %t360
  %t366 = select i1 %t363, i32 0, i32 %t365
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store i32 %t366, ptr %rv
  br label %ret
bb94:
  br label %bb95
bb95:
  call void @__olang_scope_close(ptr %s13)
  br label %bb96
bb96:
  br label %bb97
bb97:
  %t368 = load i1, ptr %l10, !tbaa !21
  br i1 %t368, label %bb98, label %bb99
bb98:
  %t370 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t372 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s2, { i64, ptr } %t370, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d47, i32 0, i32 1) })
  store i1 %t372, ptr %l148
  br label %bb100
bb99:
  store i1 false, ptr %l146, !tbaa !21
  br label %bb105
bb100:
  %t373 = load i1, ptr %l148, !tbaa !21
  br i1 %t373, label %bb101, label %bb102
bb101:
  store i1 true, ptr %l149, !tbaa !21
  br label %bb104
bb102:
  %t374 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d48, i32 0, i32 1) }, ptr %l152, !tbaa !27
  %t377 = load { i64, ptr }, ptr %l152, !tbaa !27
  %t378 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %s0, ptr %s2, { i64, ptr } %t374, { i64, ptr } %t377)
  store i1 %t378, ptr %l153
  br label %bb103
bb103:
  %t379 = load i1, ptr %l153, !tbaa !21
  store i1 %t379, ptr %l149, !tbaa !21
  br label %bb104
bb104:
  %t380 = load i1, ptr %l149, !tbaa !21
  store i1 %t380, ptr %l146, !tbaa !21
  br label %bb105
bb105:
  %t381 = load i1, ptr %l146, !tbaa !21
  br i1 %t381, label %bb106, label %bb107
bb106:
  %t382 = load ptr, ptr %l5, !tbaa !29
  store ptr %t382, ptr %l154, !tbaa !29
  %t383 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t385 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTargetUnknown(ptr %v0, ptr %v4, { i64, ptr } %t383)
  store %"compiler/diagmsg:Msg" %t385, ptr %l156
  br label %bb108
bb107:
  br label %bb112
bb108:
  %t386 = load ptr, ptr %l154, !tbaa !29
  %t387 = load %"compiler/diagmsg:Msg", ptr %l156
  %t388 = call i32 @compiler_2ftarget_2erefuse(ptr %v4, ptr %v4, ptr %t386, %"compiler/diagmsg:Msg" %t387)
  store i32 %t388, ptr %l157
  %t389 = icmp ne i32 %t388, 0
  br i1 %t389, label %bb110, label %ok.390, !prof !99
ok.390:
  br label %bb109
bb109:
  br label %bb111
bb110:
  %t391 = load i32, ptr %l157, !tbaa !23
  %t392 = lshr i32 %t391, 16
  %t393 = and i32 %t391, 65535
  %t394 = icmp eq i32 %t392, 1
  %t395 = select i1 %t394, i32 1, i32 0
  %t396 = icmp eq i32 %t391, 0
  %t397 = shl i32 %t395, 16
  %t398 = or i32 %t397, %t393
  %t399 = select i1 %t396, i32 0, i32 %t398
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store i32 %t399, ptr %rv
  br label %ret
bb111:
  br label %bb112
bb112:
  call void @__olang_scope_close(ptr %s2)
  br label %bb149
bb113:
  %t401 = load i1, ptr %l162, !tbaa !21
  br i1 %t401, label %bb114, label %bb115
bb114:
  store i1 true, ptr %l163, !tbaa !21
  br label %bb117
bb115:
  %t402 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d49, i32 0, i32 1) }, ptr %l166, !tbaa !27
  %t405 = load { i64, ptr }, ptr %l166, !tbaa !27
  %t406 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %s16, { i64, ptr } %t402, { i64, ptr } %t405)
  store i1 %t406, ptr %l167
  br label %bb116
bb116:
  %t407 = load i1, ptr %l167, !tbaa !21
  store i1 %t407, ptr %l163, !tbaa !21
  br label %bb117
bb117:
  %t408 = load i1, ptr %l163, !tbaa !21
  br i1 %t408, label %bb118, label %bb119
bb118:
  store i1 true, ptr %l168, !tbaa !21
  br label %bb121
bb119:
  %t409 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d50, i32 0, i32 1) }, ptr %l171, !tbaa !27
  %t412 = load { i64, ptr }, ptr %l171, !tbaa !27
  %t413 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %s16, { i64, ptr } %t409, { i64, ptr } %t412)
  store i1 %t413, ptr %l172
  br label %bb120
bb120:
  %t414 = load i1, ptr %l172, !tbaa !21
  store i1 %t414, ptr %l168, !tbaa !21
  br label %bb121
bb121:
  %t415 = load i1, ptr %l168, !tbaa !21
  br i1 %t415, label %bb122, label %bb123
bb122:
  %t416 = load ptr, ptr %l5, !tbaa !29
  store ptr %t416, ptr %l173, !tbaa !29
  %t417 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t419 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTargetUnsupported(ptr %v0, ptr %v4, { i64, ptr } %t417)
  store %"compiler/diagmsg:Msg" %t419, ptr %l175
  br label %bb124
bb123:
  br label %bb128
bb124:
  %t420 = load ptr, ptr %l173, !tbaa !29
  %t421 = load %"compiler/diagmsg:Msg", ptr %l175
  %t422 = call i32 @compiler_2ftarget_2erefuse(ptr %v4, ptr %v4, ptr %t420, %"compiler/diagmsg:Msg" %t421)
  store i32 %t422, ptr %l176
  %t423 = icmp ne i32 %t422, 0
  br i1 %t423, label %bb126, label %ok.424, !prof !99
ok.424:
  br label %bb125
bb125:
  br label %bb127
bb126:
  %t425 = load i32, ptr %l176, !tbaa !23
  %t426 = lshr i32 %t425, 16
  %t427 = and i32 %t425, 65535
  %t428 = icmp eq i32 %t426, 1
  %t429 = select i1 %t428, i32 1, i32 0
  %t430 = icmp eq i32 %t425, 0
  %t431 = shl i32 %t429, 16
  %t432 = or i32 %t431, %t427
  %t433 = select i1 %t430, i32 0, i32 %t432
  call void @__olang_scope_close(ptr %s16)
  call void @__olang_scope_close(ptr %s0)
  store i32 %t433, ptr %rv
  br label %ret
bb127:
  br label %bb128
bb128:
  %t435 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d51, i32 0, i32 1) }, ptr %l180, !tbaa !27
  %t438 = load { i64, ptr }, ptr %l180, !tbaa !27
  %t439 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %s16, { i64, ptr } %t435, { i64, ptr } %t438)
  store i1 %t439, ptr %l181
  br label %bb129
bb129:
  %t440 = load i1, ptr %l181, !tbaa !21
  br i1 %t440, label %bb130, label %bb131
bb130:
  store i1 true, ptr %l182, !tbaa !21
  br label %bb133
bb131:
  %t441 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t443 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s16, { i64, ptr } %t441, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d52, i32 0, i32 1) })
  store i1 %t443, ptr %l184
  br label %bb132
bb132:
  %t444 = load i1, ptr %l184, !tbaa !21
  store i1 %t444, ptr %l182, !tbaa !21
  br label %bb133
bb133:
  %t445 = load i1, ptr %l182, !tbaa !21
  br i1 %t445, label %bb134, label %bb135
bb134:
  %t446 = load ptr, ptr %l5, !tbaa !29
  store ptr %t446, ptr %l185, !tbaa !29
  %t447 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t449 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTargetUnknown(ptr %v0, ptr %v4, { i64, ptr } %t447)
  store %"compiler/diagmsg:Msg" %t449, ptr %l187
  br label %bb136
bb135:
  br label %bb140
bb136:
  %t450 = load ptr, ptr %l185, !tbaa !29
  %t451 = load %"compiler/diagmsg:Msg", ptr %l187
  %t452 = call i32 @compiler_2ftarget_2erefuse(ptr %v4, ptr %v4, ptr %t450, %"compiler/diagmsg:Msg" %t451)
  store i32 %t452, ptr %l188
  %t453 = icmp ne i32 %t452, 0
  br i1 %t453, label %bb138, label %ok.454, !prof !99
ok.454:
  br label %bb137
bb137:
  br label %bb139
bb138:
  %t455 = load i32, ptr %l188, !tbaa !23
  %t456 = lshr i32 %t455, 16
  %t457 = and i32 %t455, 65535
  %t458 = icmp eq i32 %t456, 1
  %t459 = select i1 %t458, i32 1, i32 0
  %t460 = icmp eq i32 %t455, 0
  %t461 = shl i32 %t459, 16
  %t462 = or i32 %t461, %t457
  %t463 = select i1 %t460, i32 0, i32 %t462
  call void @__olang_scope_close(ptr %s16)
  call void @__olang_scope_close(ptr %s0)
  store i32 %t463, ptr %rv
  br label %ret
bb139:
  br label %bb140
bb140:
  %t465 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t467 = call i64 @compiler_2ftarget_2earchIndex(ptr %v3, { i64, ptr } %t465)
  store i64 %t467, ptr %l191
  br label %bb141
bb141:
  %t468 = load i64, ptr %l191, !tbaa !24
  store i64 %t468, ptr %l11, !tbaa !24
  %t469 = load i64, ptr %l11, !tbaa !24
  %t471 = icmp slt i64 %t469, 0
  br i1 %t471, label %bb142, label %bb143
bb142:
  %t473 = load ptr, ptr %l5, !tbaa !29
  store ptr %t473, ptr %l194, !tbaa !29
  %t474 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t476 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTargetUnsupported(ptr %v3, ptr %v4, { i64, ptr } %t474)
  store %"compiler/diagmsg:Msg" %t476, ptr %l196
  br label %bb144
bb143:
  br label %bb148
bb144:
  %t477 = load ptr, ptr %l194, !tbaa !29
  %t478 = load %"compiler/diagmsg:Msg", ptr %l196
  %t479 = call i32 @compiler_2ftarget_2erefuse(ptr %v4, ptr %v4, ptr %t477, %"compiler/diagmsg:Msg" %t478)
  store i32 %t479, ptr %l197
  %t480 = icmp ne i32 %t479, 0
  br i1 %t480, label %bb146, label %ok.481, !prof !99
ok.481:
  br label %bb145
bb145:
  br label %bb147
bb146:
  %t482 = load i32, ptr %l197, !tbaa !23
  %t483 = lshr i32 %t482, 16
  %t484 = and i32 %t482, 65535
  %t485 = icmp eq i32 %t483, 1
  %t486 = select i1 %t485, i32 1, i32 0
  %t487 = icmp eq i32 %t482, 0
  %t488 = shl i32 %t486, 16
  %t489 = or i32 %t488, %t484
  %t490 = select i1 %t487, i32 0, i32 %t489
  call void @__olang_scope_close(ptr %s16)
  call void @__olang_scope_close(ptr %s0)
  store i32 %t490, ptr %rv
  br label %ret
bb147:
  br label %bb148
bb148:
  call void @__olang_scope_close(ptr %s16)
  br label %bb149
bb149:
  %t492 = call ptr @__olang_scope_hold(ptr %v6)
  %t493 = ptrtoint ptr %t492 to i64
  store i64 %t493, ptr %l199, !tbaa !24
  %t494 = load i1, ptr @olang_2esole_2ecompiler_2ftarget_3aTarget_2e2
  br i1 %t494, label %bb150, label %bb151
bb150:
  %t496 = call ptr @__olang_region_make(ptr %v6)
  %t497 = ptrtoint ptr %t496 to i64
  store i64 %t497, ptr %l199, !tbaa !24
  br label %bb151
bb151:
  %t498 = load i64, ptr %l11, !tbaa !24
  %t500 = getelementptr [2 x { i64, ptr }], ptr @G_2ecompiler_2ftarget_2eArchs, i64 0, i64 %t498
  %t501 = load { i64, ptr }, ptr %t500, !tbaa !37
  %t503 = extractvalue { i64, ptr } %t501, 1
  %t504 = extractvalue { i64, ptr } %t501, 0
  %t505 = load i64, ptr %l199
  %t506 = inttoptr i64 %t505 to ptr
  %t507 = call ptr @__olang_held_alloc(ptr %t506, i64 %t504)
  call void @olang_textcopy(ptr %t507, ptr %t503, i64 %t504)
  %t508 = insertvalue { i64, ptr } undef, i64 %t504, 0
  %t509 = insertvalue { i64, ptr } %t508, ptr %t507, 1
  %t511 = load ptr, ptr %lp7
  %t512 = getelementptr %"compiler/target:Target", ptr %t511, i32 0, i32 2
  %t513 = load { i64, ptr }, ptr %t512, !tbaa !27
  store { i64, ptr } %t513, ptr %l205, !tbaa !27
  %t515 = load ptr, ptr %lp7
  %t516 = getelementptr %"compiler/target:Target", ptr %t515, i32 0, i32 2
  store { i64, ptr } %t509, ptr %t516, !tbaa !27
  %t517 = load i1, ptr @olang_2esole_2ecompiler_2ftarget_3aTarget_2e2
  br i1 %t517, label %bb152, label %bb153
bb152:
  %t519 = load { i64, ptr }, ptr %l205
  %t520 = extractvalue { i64, ptr } %t519, 1
  call void @__olang_region_release(ptr %t520)
  store { i64, ptr } zeroinitializer, ptr %l205
  br label %bb153
bb153:
  %t521 = load i64, ptr %l11, !tbaa !24
  %t523 = getelementptr [2 x { i64, ptr }], ptr @G_2ecompiler_2ftarget_2eArchs, i64 0, i64 %t521
  %t524 = load { i64, ptr }, ptr %t523, !tbaa !37
  %t525 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t526 = load ptr, ptr @__olang_prog_scope
  %t529 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %t526, ptr %v3, { i64, ptr } %t524, { i64, ptr } %t525)
  store i1 %t529, ptr %l210
  br label %bb154
bb154:
  %t530 = load i1, ptr %l210, !tbaa !21
  %t531 = xor i1 %t530, true
  br i1 %t531, label %bb155, label %bb156
bb155:
  store i1 true, ptr %l212, !tbaa !21
  br label %bb158
bb156:
  %t535 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %a3, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d53, i32 0, i32 1) })
  store i1 %t535, ptr %l214
  br label %bb157
bb157:
  %t536 = load i1, ptr %l214, !tbaa !21
  %t537 = xor i1 %t536, true
  store i1 %t537, ptr %l212, !tbaa !21
  br label %bb158
bb158:
  %t539 = load i1, ptr %l212, !tbaa !21
  br i1 %t539, label %bb159, label %bb160
bb159:
  store i1 true, ptr %l216, !tbaa !21
  br label %bb162
bb160:
  %t540 = load ptr, ptr %lp7
  %t541 = getelementptr %"compiler/target:Target", ptr %t540, i32 0, i32 3
  %t542 = load { i64, ptr }, ptr %t541, !tbaa !27
  %t544 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v6, ptr %s0, { i64, ptr } %t542, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d54, i32 0, i32 1) })
  store i1 %t544, ptr %l218
  br label %bb161
bb161:
  %t545 = load i1, ptr %l218, !tbaa !21
  %t546 = xor i1 %t545, true
  store i1 %t546, ptr %l216, !tbaa !21
  br label %bb162
bb162:
  %t548 = load i1, ptr %l216, !tbaa !21
  %t549 = load ptr, ptr %lp7
  %t550 = getelementptr %"compiler/target:Target", ptr %t549, i32 0, i32 9
  store i1 %t548, ptr %t550, !tbaa !21
  %t551 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t551, ptr %l220, !tbaa !27
  %t552 = load { i64, ptr }, ptr %l220, !tbaa !27
  %t553 = extractvalue { i64, ptr } %t552, 1
  %t554 = call ptr @__olang_scope_of(ptr %t553, ptr null)
  %t555 = call ptr @__olang_scope_hold(ptr %t554)
  %t556 = ptrtoint ptr %t555 to i64
  %t558 = inttoptr i64 %t556 to ptr
  %t559 = load { i64, ptr }, ptr %l220, !tbaa !27
  %t560 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %t558, ptr %s0, { i64, ptr } %t559, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d55, i32 0, i32 1) })
  store i1 %t560, ptr %l222
  br label %bb163
bb163:
  %t561 = load i1, ptr %l222, !tbaa !21
  %t562 = xor i1 %t561, true
  br i1 %t562, label %bb164, label %bb165
bb164:
  %t564 = load ptr, ptr %lp7
  %t565 = getelementptr %"compiler/target:Target", ptr %t564, i32 0, i32 9
  %t566 = load i1, ptr %t565, !tbaa !21
  %t568 = xor i1 %t566, true
  store i1 %t568, ptr %l224, !tbaa !21
  br label %bb166
bb165:
  store i1 false, ptr %l224, !tbaa !21
  br label %bb166
bb166:
  %t570 = load i1, ptr %l224, !tbaa !21
  br i1 %t570, label %bb167, label %bb168
bb167:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d56, i32 0, i32 1) }, ptr %l8, !tbaa !27
  %t571 = load i1, ptr %l10, !tbaa !21
  %t573 = xor i1 %t571, true
  br i1 %t573, label %bb169, label %bb170
bb168:
  br label %bb172
bb169:
  %t575 = load i64, ptr %l11, !tbaa !24
  %t577 = getelementptr [2 x { i64, ptr }], ptr @G_2ecompiler_2ftarget_2eArchDefaultCpus, i64 0, i64 %t575
  %t578 = load { i64, ptr }, ptr %t577, !tbaa !37
  %t580 = extractvalue { i64, ptr } %t578, 1
  %t581 = extractvalue { i64, ptr } %t578, 0
  %t582 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t581)
  call void @olang_textcopy(ptr %t582, ptr %t580, i64 %t581)
  %t583 = insertvalue { i64, ptr } undef, i64 %t581, 0
  %t584 = insertvalue { i64, ptr } %t583, ptr %t582, 1
  store { i64, ptr } %t584, ptr %l9, !tbaa !27
  store i1 true, ptr %l10, !tbaa !21
  br label %bb171
bb170:
  br label %bb171
bb171:
  br label %bb172
bb172:
  %t587 = load i1, ptr %l10, !tbaa !21
  br i1 %t587, label %bb173, label %bb174
bb173:
  %t589 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t589, ptr %l235, !tbaa !27
  %t590 = load { i64, ptr }, ptr %l235, !tbaa !27
  %t591 = extractvalue { i64, ptr } %t590, 1
  %t592 = call ptr @__olang_scope_of(ptr %t591, ptr null)
  %t593 = call ptr @__olang_scope_hold(ptr %t592)
  %t594 = ptrtoint ptr %t593 to i64
  %t596 = inttoptr i64 %t594 to ptr
  %t597 = load { i64, ptr }, ptr %l235, !tbaa !27
  %t598 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %t596, ptr %s0, { i64, ptr } %t597, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d57, i32 0, i32 1) })
  store i1 %t598, ptr %l237
  br label %bb175
bb174:
  store i1 false, ptr %l234, !tbaa !21
  br label %bb176
bb175:
  %t599 = load i1, ptr %l237, !tbaa !21
  store i1 %t599, ptr %l234, !tbaa !21
  br label %bb176
bb176:
  %t600 = load i1, ptr %l234, !tbaa !21
  br i1 %t600, label %bb177, label %bb178
bb177:
  %t601 = load ptr, ptr %lp7
  %t602 = getelementptr %"compiler/target:Target", ptr %t601, i32 0, i32 9
  %t603 = load i1, ptr %t602, !tbaa !21
  store i1 %t603, ptr %l238, !tbaa !21
  br label %bb179
bb178:
  store i1 false, ptr %l238, !tbaa !21
  br label %bb179
bb179:
  %t605 = load i1, ptr %l238, !tbaa !21
  br i1 %t605, label %bb180, label %bb181
bb180:
  %t606 = load ptr, ptr %l5, !tbaa !29
  store ptr %t606, ptr %l240, !tbaa !29
  %t607 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t609 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTargetNativeForeign(ptr %v0, ptr %v4, { i64, ptr } %t607)
  store %"compiler/diagmsg:Msg" %t609, ptr %l242
  br label %bb182
bb181:
  br label %bb186
bb182:
  %t610 = load ptr, ptr %l240, !tbaa !29
  %t611 = load %"compiler/diagmsg:Msg", ptr %l242
  %t612 = call i32 @compiler_2ftarget_2erefuse(ptr %v4, ptr %v4, ptr %t610, %"compiler/diagmsg:Msg" %t611)
  store i32 %t612, ptr %l243
  %t613 = icmp ne i32 %t612, 0
  br i1 %t613, label %bb184, label %ok.614, !prof !99
ok.614:
  br label %bb183
bb183:
  br label %bb185
bb184:
  %t615 = load i32, ptr %l243, !tbaa !23
  %t616 = lshr i32 %t615, 16
  %t617 = and i32 %t615, 65535
  %t618 = icmp eq i32 %t616, 1
  %t619 = select i1 %t618, i32 1, i32 0
  %t620 = icmp eq i32 %t615, 0
  %t621 = shl i32 %t619, 16
  %t622 = or i32 %t621, %t617
  %t623 = select i1 %t620, i32 0, i32 %t622
  call void @__olang_scope_close(ptr %s0)
  store i32 %t623, ptr %rv
  br label %ret
bb185:
  br label %bb186
bb186:
  %t625 = load ptr, ptr %lp7
  %t626 = getelementptr %"compiler/target:Target", ptr %t625, i32 0, i32 9
  %t627 = load i1, ptr %t626, !tbaa !21
  br i1 %t627, label %bb187, label %bb188
bb187:
  %t629 = load i1, ptr %l2, !tbaa !21
  store i1 %t629, ptr %l246, !tbaa !21
  br label %bb189
bb188:
  store i1 false, ptr %l246, !tbaa !21
  br label %bb189
bb189:
  %t631 = load i1, ptr %l246, !tbaa !21
  br i1 %t631, label %bb190, label %bb191
bb190:
  store %olang.scope zeroinitializer, ptr %s25
  %t632 = load ptr, ptr %l5, !tbaa !29
  store ptr %t632, ptr %l248, !tbaa !29
  %t633 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t635 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTargetForeignMode(ptr %s25, ptr %v0, ptr %v4, { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d58, i32 0, i32 1) }, { i64, ptr } %t633)
  store %"compiler/diagmsg:Msg" %t635, ptr %l250
  br label %bb192
bb191:
  br label %bb196
bb192:
  %t636 = load ptr, ptr %l248, !tbaa !29
  %t637 = load %"compiler/diagmsg:Msg", ptr %l250
  %t638 = call i32 @compiler_2ftarget_2erefuse(ptr %v4, ptr %v4, ptr %t636, %"compiler/diagmsg:Msg" %t637)
  store i32 %t638, ptr %l251
  %t639 = icmp ne i32 %t638, 0
  br i1 %t639, label %bb194, label %ok.640, !prof !99
ok.640:
  br label %bb193
bb193:
  br label %bb195
bb194:
  %t641 = load i32, ptr %l251, !tbaa !23
  %t642 = lshr i32 %t641, 16
  %t643 = and i32 %t641, 65535
  %t644 = icmp eq i32 %t642, 1
  %t645 = select i1 %t644, i32 1, i32 0
  %t646 = icmp eq i32 %t641, 0
  %t647 = shl i32 %t645, 16
  %t648 = or i32 %t647, %t643
  %t649 = select i1 %t646, i32 0, i32 %t648
  call void @__olang_scope_close(ptr %s25)
  call void @__olang_scope_close(ptr %s0)
  store i32 %t649, ptr %rv
  br label %ret
bb195:
  call void @__olang_scope_close(ptr %s25)
  br label %bb196
bb196:
  %t651 = load ptr, ptr %lp7
  %t652 = getelementptr %"compiler/target:Target", ptr %t651, i32 0, i32 9
  %t653 = load i1, ptr %t652, !tbaa !21
  br i1 %t653, label %bb197, label %bb198
bb197:
  %t655 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t657 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v5, ptr %s0, { i64, ptr } %t655, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d59, i32 0, i32 1) })
  store i1 %t657, ptr %l256
  br label %bb199
bb198:
  store i1 false, ptr %l254, !tbaa !21
  br label %bb200
bb199:
  %t658 = load i1, ptr %l256, !tbaa !21
  %t659 = xor i1 %t658, true
  store i1 %t659, ptr %l254, !tbaa !21
  br label %bb200
bb200:
  %t661 = load i1, ptr %l254, !tbaa !21
  br i1 %t661, label %bb201, label %bb202
bb201:
  %t662 = load ptr, ptr %l5, !tbaa !29
  store ptr %t662, ptr %l258, !tbaa !29
  %t663 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t664 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t667 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTargetForeignMode(ptr %v5, ptr %v0, ptr %v4, { i64, ptr } %t663, { i64, ptr } %t664)
  store %"compiler/diagmsg:Msg" %t667, ptr %l261
  br label %bb203
bb202:
  br label %bb207
bb203:
  %t668 = load ptr, ptr %l258, !tbaa !29
  %t669 = load %"compiler/diagmsg:Msg", ptr %l261
  %t670 = call i32 @compiler_2ftarget_2erefuse(ptr %v4, ptr %v4, ptr %t668, %"compiler/diagmsg:Msg" %t669)
  store i32 %t670, ptr %l262
  %t671 = icmp ne i32 %t670, 0
  br i1 %t671, label %bb205, label %ok.672, !prof !99
ok.672:
  br label %bb204
bb204:
  br label %bb206
bb205:
  %t673 = load i32, ptr %l262, !tbaa !23
  %t674 = lshr i32 %t673, 16
  %t675 = and i32 %t673, 65535
  %t676 = icmp eq i32 %t674, 1
  %t677 = select i1 %t676, i32 1, i32 0
  %t678 = icmp eq i32 %t673, 0
  %t679 = shl i32 %t677, 16
  %t680 = or i32 %t679, %t675
  %t681 = select i1 %t678, i32 0, i32 %t680
  call void @__olang_scope_close(ptr %s0)
  store i32 %t681, ptr %rv
  br label %ret
bb206:
  br label %bb207
bb207:
  %t683 = load ptr, ptr %lp7
  %t684 = getelementptr %"compiler/target:Target", ptr %t683, i32 0, i32 3
  %t685 = load { i64, ptr }, ptr %t684, !tbaa !27
  %t687 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v6, ptr %s0, { i64, ptr } %t685, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d60, i32 0, i32 1) })
  store i1 %t687, ptr %l265
  br label %bb208
bb208:
  %t688 = load i1, ptr %l265, !tbaa !21
  br i1 %t688, label %bb209, label %bb210
bb209:
  store %olang.scope zeroinitializer, ptr %s27
  %t689 = call ptr @__olang_scope_hold(ptr %v6)
  %t690 = ptrtoint ptr %t689 to i64
  store i64 %t690, ptr %l266, !tbaa !24
  %t691 = load i1, ptr @olang_2esole_2ecompiler_2ftarget_3aTarget_2e13
  br i1 %t691, label %bb211, label %bb212
bb210:
  br label %bb224
bb211:
  %t693 = call ptr @__olang_region_make(ptr %v6)
  %t694 = ptrtoint ptr %t693 to i64
  store i64 %t694, ptr %l266, !tbaa !24
  br label %bb212
bb212:
  %t695 = load i64, ptr %l266
  %t696 = inttoptr i64 %t695 to ptr
  %t697 = call { i64, ptr } @compiler_2ftarget_2eNdkClang(ptr %t696)
  store { i64, ptr } %t697, ptr %l268
  br label %bb213
bb213:
  %t698 = load { i64, ptr }, ptr %l268, !tbaa !27
  %t699 = load i64, ptr %l266
  %t700 = inttoptr i64 %t699 to ptr
  %t701 = extractvalue { i64, ptr } %t698, 0
  %t702 = extractvalue { i64, ptr } %t698, 1
  %t703 = mul i64 %t701, 1
  %t704 = call ptr @__olang_held_alloc(ptr %t700, i64 %t703)
  call void @llvm.memcpy.p0.p0.i64(ptr %t704, ptr %t702, i64 %t703, i1 false)
  %t705 = insertvalue { i64, ptr } undef, i64 %t701, 0
  %t706 = insertvalue { i64, ptr } %t705, ptr %t704, 1
  %t707 = load ptr, ptr %lp7
  %t708 = getelementptr %"compiler/target:Target", ptr %t707, i32 0, i32 13
  %t709 = load { i64, ptr }, ptr %t708, !tbaa !27
  store { i64, ptr } %t709, ptr %l270, !tbaa !27
  %t711 = load ptr, ptr %lp7
  %t712 = getelementptr %"compiler/target:Target", ptr %t711, i32 0, i32 13
  store { i64, ptr } %t706, ptr %t712, !tbaa !27
  %t713 = load i1, ptr @olang_2esole_2ecompiler_2ftarget_3aTarget_2e13
  br i1 %t713, label %bb214, label %bb215
bb214:
  %t715 = load { i64, ptr }, ptr %l270
  %t716 = extractvalue { i64, ptr } %t715, 1
  call void @__olang_region_release(ptr %t716)
  store { i64, ptr } zeroinitializer, ptr %l270
  br label %bb215
bb215:
  %t717 = load ptr, ptr %lp7
  %t718 = getelementptr %"compiler/target:Target", ptr %t717, i32 0, i32 13
  %t719 = load { i64, ptr }, ptr %t718, !tbaa !27
  %t721 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v6, ptr %s27, { i64, ptr } %t719, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d61, i32 0, i32 1) })
  store i1 %t721, ptr %l273
  br label %bb216
bb216:
  %t722 = load i1, ptr %l273, !tbaa !21
  br i1 %t722, label %bb217, label %bb218
bb217:
  %t723 = load ptr, ptr %l5, !tbaa !29
  store ptr %t723, ptr %l274, !tbaa !29
  %t724 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t726 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTargetNoNdk(ptr %v0, ptr %v4, { i64, ptr } %t724)
  store %"compiler/diagmsg:Msg" %t726, ptr %l276
  br label %bb219
bb218:
  br label %bb223
bb219:
  %t727 = load ptr, ptr %l274, !tbaa !29
  %t728 = load %"compiler/diagmsg:Msg", ptr %l276
  %t729 = call i32 @compiler_2ftarget_2erefuse(ptr %v4, ptr %v4, ptr %t727, %"compiler/diagmsg:Msg" %t728)
  store i32 %t729, ptr %l277
  %t730 = icmp ne i32 %t729, 0
  br i1 %t730, label %bb221, label %ok.731, !prof !99
ok.731:
  br label %bb220
bb220:
  br label %bb222
bb221:
  %t732 = load i32, ptr %l277, !tbaa !23
  %t733 = lshr i32 %t732, 16
  %t734 = and i32 %t732, 65535
  %t735 = icmp eq i32 %t733, 1
  %t736 = select i1 %t735, i32 1, i32 0
  %t737 = icmp eq i32 %t732, 0
  %t738 = shl i32 %t736, 16
  %t739 = or i32 %t738, %t734
  %t740 = select i1 %t737, i32 0, i32 %t739
  call void @__olang_scope_close(ptr %s27)
  call void @__olang_scope_close(ptr %s0)
  store i32 %t740, ptr %rv
  br label %ret
bb222:
  br label %bb223
bb223:
  call void @__olang_scope_close(ptr %s27)
  br label %bb224
bb224:
  %t742 = load ptr, ptr %lp7
  %t743 = getelementptr %"compiler/target:Target", ptr %t742, i32 0, i32 13
  %t744 = load { i64, ptr }, ptr %t743, !tbaa !27
  %t746 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v6, ptr %s0, { i64, ptr } %t744, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d62, i32 0, i32 1) })
  store i1 %t746, ptr %l280
  br label %bb225
bb225:
  %t747 = load i1, ptr %l280, !tbaa !21
  %t748 = xor i1 %t747, true
  br i1 %t748, label %bb226, label %bb227
bb226:
  %t750 = load ptr, ptr %lp7
  %t751 = getelementptr %"compiler/target:Target", ptr %t750, i32 0, i32 13
  %t752 = load { i64, ptr }, ptr %t751, !tbaa !27
  store { i64, ptr } %t752, ptr %l282, !tbaa !27
  br label %bb228
bb227:
  store { i64, ptr } %a1, ptr %l282, !tbaa !27
  br label %bb228
bb228:
  %t756 = load { i64, ptr }, ptr %l282, !tbaa !27
  store { i64, ptr } %t756, ptr %l15, !tbaa !27
  %t757 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t757, ptr %l285, !tbaa !27
  %t758 = load { i64, ptr }, ptr %l285, !tbaa !27
  %t759 = extractvalue { i64, ptr } %t758, 1
  %t760 = call ptr @__olang_scope_of(ptr %t759, ptr null)
  %t761 = call ptr @__olang_scope_hold(ptr %t760)
  %t762 = ptrtoint ptr %t761 to i64
  %t764 = inttoptr i64 %t762 to ptr
  %t765 = load { i64, ptr }, ptr %l285, !tbaa !27
  %t766 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %t764, ptr %s0, { i64, ptr } %t765, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d63, i32 0, i32 1) })
  store i1 %t766, ptr %l287
  br label %bb229
bb229:
  %t767 = load i1, ptr %l287, !tbaa !21
  br i1 %t767, label %bb230, label %bb231
bb230:
  store %olang.scope zeroinitializer, ptr %s29
  %t768 = load i1, ptr %l2, !tbaa !21
  %t770 = xor i1 %t768, true
  br i1 %t770, label %bb232, label %bb233
bb231:
  br label %bb244
bb232:
  store i1 true, ptr %l290, !tbaa !21
  br label %bb236
bb233:
  %t772 = load ptr, ptr %lp7
  store ptr %t772, ptr %l291, !tbaa !29
  %t773 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t773, ptr %l292, !tbaa !27
  %t774 = call { i64, ptr } @compiler_2ftarget_2ecpuFlags(ptr %s29)
  store { i64, ptr } %t774, ptr %l293
  br label %bb234
bb234:
  %t775 = load { i64, ptr }, ptr %l293, !tbaa !27
  %t776 = load { i64, ptr }, ptr %l292, !tbaa !27
  %t777 = extractvalue { i64, ptr } %t776, 1
  %t778 = call ptr @__olang_scope_of(ptr %t777, ptr null)
  %t779 = call ptr @__olang_scope_hold(ptr %t778)
  %t780 = ptrtoint ptr %t779 to i64
  %t782 = inttoptr i64 %t780 to ptr
  %t783 = load ptr, ptr %l291, !tbaa !29
  %t784 = load { i64, ptr }, ptr %l292, !tbaa !27
  %t786 = call i1 @compiler_2ftarget_2ecompiler_2ftarget_3aTarget_2ewithoutClang(ptr %v6, ptr %t782, ptr %s29, ptr %t783, { i64, ptr } %t784, { i64, ptr } %t775)
  store i1 %t786, ptr %l296
  br label %bb235
bb235:
  %t787 = load i1, ptr %l296, !tbaa !21
  %t788 = xor i1 %t787, true
  store i1 %t788, ptr %l290, !tbaa !21
  br label %bb236
bb236:
  %t790 = load i1, ptr %l290, !tbaa !21
  br i1 %t790, label %bb237, label %bb238
bb237:
  %t791 = load ptr, ptr %l5, !tbaa !29
  store ptr %t791, ptr %l298, !tbaa !29
  %t792 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t794 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTargetNoClang(ptr %v0, ptr %v4, { i64, ptr } %t792)
  store %"compiler/diagmsg:Msg" %t794, ptr %l300
  br label %bb239
bb238:
  br label %bb243
bb239:
  %t795 = load ptr, ptr %l298, !tbaa !29
  %t796 = load %"compiler/diagmsg:Msg", ptr %l300
  %t797 = call i32 @compiler_2ftarget_2erefuse(ptr %v4, ptr %v4, ptr %t795, %"compiler/diagmsg:Msg" %t796)
  store i32 %t797, ptr %l301
  %t798 = icmp ne i32 %t797, 0
  br i1 %t798, label %bb241, label %ok.799, !prof !99
ok.799:
  br label %bb240
bb240:
  br label %bb242
bb241:
  %t800 = load i32, ptr %l301, !tbaa !23
  %t801 = lshr i32 %t800, 16
  %t802 = and i32 %t800, 65535
  %t803 = icmp eq i32 %t801, 1
  %t804 = select i1 %t803, i32 1, i32 0
  %t805 = icmp eq i32 %t800, 0
  %t806 = shl i32 %t804, 16
  %t807 = or i32 %t806, %t802
  %t808 = select i1 %t805, i32 0, i32 %t807
  call void @__olang_scope_close(ptr %s29)
  call void @__olang_scope_close(ptr %s0)
  store i32 %t808, ptr %rv
  br label %ret
bb242:
  br label %bb243
bb243:
  %t810 = load ptr, ptr %lp7
  call void @llvm.memmove.p0.p0.i64(ptr %l303, ptr %t810, i64 152, i1 false)
  call void @__olang_scope_close(ptr %s29)
  call void @__olang_scope_close(ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l303, i64 152, i1 false)
  store i32 0, ptr %rv
  br label %ret
bb244:
  %t811 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t811, ptr %l304
  br label %bb245
bb245:
  %t812 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l304
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t812, ptr %l16
  %t813 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t813, ptr %l306, !tbaa !27
  %t814 = load { i64, ptr }, ptr %l306, !tbaa !27
  %t815 = extractvalue { i64, ptr } %t814, 1
  %t816 = call ptr @__olang_scope_of(ptr %t815, ptr null)
  %t817 = call ptr @__olang_scope_hold(ptr %t816)
  %t818 = ptrtoint ptr %t817 to i64
  %t820 = inttoptr i64 %t818 to ptr
  %t822 = load { i64, ptr }, ptr %l306, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %t820, ptr %l16, { i64, ptr } %t822)
  br label %bb246
bb246:
  %t823 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t823, ptr %l308, !tbaa !27
  %t824 = load { i64, ptr }, ptr %l308, !tbaa !27
  %t825 = extractvalue { i64, ptr } %t824, 1
  %t826 = call ptr @__olang_scope_of(ptr %t825, ptr null)
  %t827 = call ptr @__olang_scope_hold(ptr %t826)
  %t828 = ptrtoint ptr %t827 to i64
  %t830 = inttoptr i64 %t828 to ptr
  %t831 = load { i64, ptr }, ptr %l308, !tbaa !27
  %t832 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %t830, ptr %s0, { i64, ptr } %t831, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d64, i32 0, i32 1) })
  store i1 %t832, ptr %l310
  br label %bb247
bb247:
  %t833 = load i1, ptr %l310, !tbaa !21
  %t834 = xor i1 %t833, true
  br i1 %t834, label %bb248, label %bb249
bb248:
  store ptr %l16, ptr %l312, !tbaa !29
  %t836 = call ptr @__olang_scope_hold(ptr %s0)
  %t837 = ptrtoint ptr %t836 to i64
  store i64 %t837, ptr %l313, !tbaa !24
  %t838 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t838, label %bb250, label %bb251
bb249:
  br label %bb253
bb250:
  %t840 = call ptr @__olang_region_make(ptr %s0)
  %t841 = ptrtoint ptr %t840 to i64
  store i64 %t841, ptr %l313, !tbaa !24
  br label %bb251
bb251:
  %t842 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t843 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d65, i32 0, i32 1) }, 1
  %t844 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d65, i32 0, i32 1) }, 0
  %t846 = extractvalue { i64, ptr } %t842, 1
  %t847 = extractvalue { i64, ptr } %t842, 0
  %t848 = add i64 %t844, %t847
  %t849 = load i64, ptr %l313
  %t850 = inttoptr i64 %t849 to ptr
  %t851 = call ptr @__olang_held_alloc(ptr %t850, i64 %t848)
  call void @olang_textcopy(ptr %t851, ptr %t843, i64 %t844)
  %t852 = getelementptr i8, ptr %t851, i64 %t844
  call void @olang_textcopy(ptr %t852, ptr %t846, i64 %t847)
  %t853 = insertvalue { i64, ptr } undef, i64 %t848, 0
  %t854 = insertvalue { i64, ptr } %t853, ptr %t851, 1
  %t856 = load ptr, ptr %l312, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t856, { i64, ptr } %t854)
  br label %bb252
bb252:
  br label %bb253
bb253:
  %t858 = load i1, ptr %l10, !tbaa !21
  br i1 %t858, label %bb254, label %bb255
bb254:
  store ptr %l16, ptr %l319, !tbaa !29
  %t860 = call ptr @__olang_scope_hold(ptr %s0)
  %t861 = ptrtoint ptr %t860 to i64
  store i64 %t861, ptr %l320, !tbaa !24
  %t862 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t862, label %bb256, label %bb257
bb255:
  br label %bb259
bb256:
  %t864 = call ptr @__olang_region_make(ptr %s0)
  %t865 = ptrtoint ptr %t864 to i64
  store i64 %t865, ptr %l320, !tbaa !24
  br label %bb257
bb257:
  %t866 = load i64, ptr %l11, !tbaa !24
  %t868 = getelementptr [2 x { i64, ptr }], ptr @G_2ecompiler_2ftarget_2eArchCpuFlags, i64 0, i64 %t866
  %t869 = load { i64, ptr }, ptr %t868, !tbaa !37
  %t870 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t872 = extractvalue { i64, ptr } %t869, 1
  %t873 = extractvalue { i64, ptr } %t869, 0
  %t875 = extractvalue { i64, ptr } %t870, 1
  %t876 = extractvalue { i64, ptr } %t870, 0
  %t877 = add i64 %t873, %t876
  %t878 = load i64, ptr %l320
  %t879 = inttoptr i64 %t878 to ptr
  %t880 = call ptr @__olang_held_alloc(ptr %t879, i64 %t877)
  call void @olang_textcopy(ptr %t880, ptr %t872, i64 %t873)
  %t881 = getelementptr i8, ptr %t880, i64 %t873
  call void @olang_textcopy(ptr %t881, ptr %t875, i64 %t876)
  %t882 = insertvalue { i64, ptr } undef, i64 %t877, 0
  %t883 = insertvalue { i64, ptr } %t882, ptr %t880, 1
  %t885 = load ptr, ptr %l319, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t885, { i64, ptr } %t883)
  br label %bb258
bb258:
  br label %bb259
bb259:
  store %olang.scope zeroinitializer, ptr %s35
  %t887 = insertvalue [7 x { i64, ptr }] undef, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d66, i32 0, i32 1) }, 0
  %t888 = insertvalue [7 x { i64, ptr }] %t887, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d67, i32 0, i32 1) }, 1
  %t889 = insertvalue [7 x { i64, ptr }] %t888, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d68, i32 0, i32 1) }, 2
  %t890 = insertvalue [7 x { i64, ptr }] %t889, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d69, i32 0, i32 1) }, 3
  %t891 = insertvalue [7 x { i64, ptr }] %t890, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d70, i32 0, i32 1) }, 4
  %t892 = insertvalue [7 x { i64, ptr }] %t891, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d71, i32 0, i32 1) }, 5
  %t893 = insertvalue [7 x { i64, ptr }] %t892, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d72, i32 0, i32 1) }, 6
  %t895 = call ptr @__olang_scope_alloc_a(ptr %s35, i64 112, i64 8)
  store [7 x { i64, ptr }] %t893, ptr %t895
  store ptr %t895, ptr %l17
  store i64 0, ptr %l18, !tbaa !24
  %t897 = load ptr, ptr %l17
  store i64 7, ptr %l19, !tbaa !24
  br label %bb260
bb260:
  %t900 = load i64, ptr %l18, !tbaa !24
  %t901 = load i64, ptr %l19, !tbaa !24
  %t904 = icmp slt i64 %t900, %t901
  %t906 = xor i1 %t904, true
  br i1 %t906, label %bb261, label %bb262
bb261:
  br label %bb266
bb262:
  br label %bb263
bb263:
  %t908 = load ptr, ptr %l17
  %t909 = load i64, ptr %l18, !tbaa !24
  %t912 = getelementptr [7 x { i64, ptr }], ptr %t908, i64 0, i64 %t909
  %t913 = load { i64, ptr }, ptr %t912, !tbaa !37
  %t916 = load ptr, ptr @__olang_prog_scope
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %t916, ptr %l16, { i64, ptr } %t913)
  br label %bb264
bb264:
  br label %bb265
bb265:
  %t919 = load i64, ptr %l18, !tbaa !24
  %t922 = add i64 %t919, 1
  store i64 %t922, ptr %l18, !tbaa !24
  br label %bb260
bb266:
  call void @__olang_scope_close(ptr %s35)
  %t925 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %s0, ptr %s0, ptr %l16)
  store { i64, ptr } %t925, ptr %l345
  br label %bb267
bb267:
  %t926 = load i1, ptr %l2, !tbaa !21
  %t928 = xor i1 %t926, true
  %t929 = load { i64, ptr }, ptr %l345, !tbaa !27
  %t931 = call { i32, %"std/os:Output" } @compiler_2ftarget_2eClangSays(ptr %s0, ptr %s0, ptr %v6, { i64, ptr } %t929, { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d73, i32 0, i32 1) }, i1 %t928)
  %t932 = extractvalue { i32, %"std/os:Output" } %t931, 1
  %t933 = extractvalue { i32, %"std/os:Output" } %t931, 0
  store i32 %t933, ptr %l349
  %t934 = icmp ne i32 %t933, 0
  br i1 %t934, label %bb269, label %ok.935, !prof !99
ok.935:
  store %"std/os:Output" %t932, ptr %l348
  br label %bb268
bb268:
  %t936 = load %"std/os:Output", ptr %l348
  store %"std/os:Output" %t936, ptr %l343
  br label %bb277
bb269:
  %t937 = load i32, ptr %l349, !tbaa !23
  %t938 = ashr i32 %t937, 16
  %t940 = icmp eq i32 %t938, 1
  store i1 %t940, ptr %l351, !tbaa !21
  %t941 = load i32, ptr %l349, !tbaa !23
  %t942 = ashr i32 %t941, 16
  %t944 = icmp eq i32 %t942, 1
  br i1 %t944, label %bb270, label %bb271
bb270:
  call void @__olang_errpay_pop()
  br label %bb271
bb271:
  br label %bb272
bb272:
  %t946 = load ptr, ptr %l5, !tbaa !29
  store ptr %t946, ptr %l354, !tbaa !29
  %t947 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t949 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTargetUnknown(ptr %v0, ptr %v4, { i64, ptr } %t947)
  store %"compiler/diagmsg:Msg" %t949, ptr %l356
  br label %bb273
bb273:
  %t950 = load ptr, ptr %l354, !tbaa !29
  %t951 = load %"compiler/diagmsg:Msg", ptr %l356
  %t952 = call i32 @compiler_2ftarget_2erefuse(ptr %v4, ptr %v4, ptr %t950, %"compiler/diagmsg:Msg" %t951)
  store i32 %t952, ptr %l357
  %t953 = icmp ne i32 %t952, 0
  br i1 %t953, label %bb275, label %ok.954, !prof !99
ok.954:
  br label %bb274
bb274:
  br label %bb276
bb275:
  %t955 = load i32, ptr %l357, !tbaa !23
  %t956 = lshr i32 %t955, 16
  %t957 = and i32 %t955, 65535
  %t958 = icmp eq i32 %t956, 1
  %t959 = select i1 %t958, i32 1, i32 0
  %t960 = icmp eq i32 %t955, 0
  %t961 = shl i32 %t959, 16
  %t962 = or i32 %t961, %t957
  %t963 = select i1 %t960, i32 0, i32 %t962
  call void @__olang_scope_close(ptr %s0)
  store i32 %t963, ptr %rv
  br label %ret
bb276:
  call void @__olang_check_failed(ptr @olang_loc_ec0ce4f0f9f205a4_65ae5627b8a19708)
  unreachable
bb277:
  %t965 = call ptr @__olang_scope_alloc_a(ptr %v6, i64 40, i64 8)
  store ptr %t965, ptr %lp21
  %t966 = load %"std/os:Output", ptr %l343
  %t967 = load ptr, ptr %lp21
  store %"std/os:Output" %t966, ptr %t967
  %t968 = load ptr, ptr %lp21
  %t969 = getelementptr %"std/os:Output", ptr %t968, i32 0, i32 0
  %t970 = load i32, ptr %t969, !tbaa !23
  %t972 = icmp ne i32 %t970, 0
  br i1 %t972, label %bb278, label %bb279
bb278:
  %t974 = load ptr, ptr %l5, !tbaa !29
  store ptr %t974, ptr %l361, !tbaa !29
  %t975 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t977 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTargetUnknown(ptr %v0, ptr %v4, { i64, ptr } %t975)
  store %"compiler/diagmsg:Msg" %t977, ptr %l363
  br label %bb280
bb279:
  br label %bb284
bb280:
  %t978 = load ptr, ptr %l361, !tbaa !29
  %t979 = load %"compiler/diagmsg:Msg", ptr %l363
  %t980 = call i32 @compiler_2ftarget_2erefuse(ptr %v4, ptr %v4, ptr %t978, %"compiler/diagmsg:Msg" %t979)
  store i32 %t980, ptr %l364
  %t981 = icmp ne i32 %t980, 0
  br i1 %t981, label %bb282, label %ok.982, !prof !99
ok.982:
  br label %bb281
bb281:
  br label %bb283
bb282:
  %t983 = load i32, ptr %l364, !tbaa !23
  %t984 = lshr i32 %t983, 16
  %t985 = and i32 %t983, 65535
  %t986 = icmp eq i32 %t984, 1
  %t987 = select i1 %t986, i32 1, i32 0
  %t988 = icmp eq i32 %t983, 0
  %t989 = shl i32 %t987, 16
  %t990 = or i32 %t989, %t985
  %t991 = select i1 %t988, i32 0, i32 %t990
  call void @__olang_scope_close(ptr %s0)
  store i32 %t991, ptr %rv
  br label %ret
bb283:
  br label %bb284
bb284:
  %t993 = load ptr, ptr %lp7
  %t994 = load ptr, ptr %lp21
  %t995 = getelementptr %"std/os:Output", ptr %t994, i32 0, i32 1
  %t996 = load { i64, ptr }, ptr %t995, !tbaa !27
  %t999 = call i32 @compiler_2ftarget_2ecompiler_2ftarget_3aTarget_2eFromProbe(ptr %v6, ptr %v6, ptr %t993, { i64, ptr } %t996)
  store i32 %t999, ptr %l368
  %t1000 = icmp ne i32 %t999, 0
  br i1 %t1000, label %bb286, label %ok.1001, !prof !99
ok.1001:
  br label %bb285
bb285:
  br label %bb301
bb286:
  %t1002 = load i32, ptr %l368, !tbaa !23
  %t1003 = icmp eq i32 %t1002, 65536
  br i1 %t1003, label %bb287, label %bb288
bb287:
  br label %bb289
bb288:
  %t1005 = load i32, ptr %l368, !tbaa !23
  %t1006 = icmp eq i32 %t1005, 65537
  br i1 %t1006, label %bb290, label %bb291
bb289:
  %t1008 = load ptr, ptr %l5, !tbaa !29
  store ptr %t1008, ptr %l372, !tbaa !29
  %t1009 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t1011 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTargetUnknown(ptr %v0, ptr %v4, { i64, ptr } %t1009)
  store %"compiler/diagmsg:Msg" %t1011, ptr %l374
  br label %bb293
bb290:
  br label %bb292
bb291:
  %t1012 = load i32, ptr %l368, !tbaa !23
  %t1013 = lshr i32 %t1012, 16
  %t1014 = and i32 %t1012, 65535
  %t1015 = icmp eq i32 %t1013, 1
  %t1016 = select i1 %t1015, i32 0, i32 0
  %t1017 = icmp eq i32 %t1012, 0
  %t1018 = shl i32 %t1016, 16
  %t1019 = or i32 %t1018, %t1014
  %t1020 = select i1 %t1017, i32 0, i32 %t1019
  call void @__olang_scope_close(ptr %s0)
  store i32 %t1020, ptr %rv
  br label %ret
bb292:
  %t1022 = load ptr, ptr %l5, !tbaa !29
  store ptr %t1022, ptr %l377, !tbaa !29
  %t1023 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t1025 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTargetUnsupported(ptr %v0, ptr %v4, { i64, ptr } %t1023)
  store %"compiler/diagmsg:Msg" %t1025, ptr %l379
  br label %bb297
bb293:
  %t1026 = load ptr, ptr %l372, !tbaa !29
  %t1027 = load %"compiler/diagmsg:Msg", ptr %l374
  %t1028 = call i32 @compiler_2ftarget_2erefuse(ptr %v4, ptr %v4, ptr %t1026, %"compiler/diagmsg:Msg" %t1027)
  store i32 %t1028, ptr %l375
  %t1029 = icmp ne i32 %t1028, 0
  br i1 %t1029, label %bb295, label %ok.1030, !prof !99
ok.1030:
  br label %bb294
bb294:
  br label %bb296
bb295:
  %t1031 = load i32, ptr %l375, !tbaa !23
  %t1032 = lshr i32 %t1031, 16
  %t1033 = and i32 %t1031, 65535
  %t1034 = icmp eq i32 %t1032, 1
  %t1035 = select i1 %t1034, i32 1, i32 0
  %t1036 = icmp eq i32 %t1031, 0
  %t1037 = shl i32 %t1035, 16
  %t1038 = or i32 %t1037, %t1033
  %t1039 = select i1 %t1036, i32 0, i32 %t1038
  call void @__olang_scope_close(ptr %s0)
  store i32 %t1039, ptr %rv
  br label %ret
bb296:
  br label %bb301
bb297:
  %t1041 = load ptr, ptr %l377, !tbaa !29
  %t1042 = load %"compiler/diagmsg:Msg", ptr %l379
  %t1043 = call i32 @compiler_2ftarget_2erefuse(ptr %v4, ptr %v4, ptr %t1041, %"compiler/diagmsg:Msg" %t1042)
  store i32 %t1043, ptr %l380
  %t1044 = icmp ne i32 %t1043, 0
  br i1 %t1044, label %bb299, label %ok.1045, !prof !99
ok.1045:
  br label %bb298
bb298:
  br label %bb300
bb299:
  %t1046 = load i32, ptr %l380, !tbaa !23
  %t1047 = lshr i32 %t1046, 16
  %t1048 = and i32 %t1046, 65535
  %t1049 = icmp eq i32 %t1047, 1
  %t1050 = select i1 %t1049, i32 1, i32 0
  %t1051 = icmp eq i32 %t1046, 0
  %t1052 = shl i32 %t1050, 16
  %t1053 = or i32 %t1052, %t1048
  %t1054 = select i1 %t1051, i32 0, i32 %t1053
  call void @__olang_scope_close(ptr %s0)
  store i32 %t1054, ptr %rv
  br label %ret
bb300:
  br label %bb301
bb301:
  %t1056 = load ptr, ptr %lp7
  %t1057 = getelementptr %"compiler/target:Target", ptr %t1056, i32 0, i32 9
  %t1058 = load i1, ptr %t1057, !tbaa !21
  br i1 %t1058, label %bb302, label %bb303
bb302:
  %t1060 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t1060, ptr %l384, !tbaa !27
  %t1061 = load ptr, ptr %lp7
  %t1062 = getelementptr %"compiler/target:Target", ptr %t1061, i32 0, i32 1
  %t1063 = load { i64, ptr }, ptr %t1062, !tbaa !27
  %t1064 = load { i64, ptr }, ptr %l384, !tbaa !27
  %t1065 = extractvalue { i64, ptr } %t1064, 1
  %t1066 = call ptr @__olang_scope_of(ptr %t1065, ptr null)
  %t1067 = call ptr @__olang_scope_hold(ptr %t1066)
  %t1068 = ptrtoint ptr %t1067 to i64
  %t1070 = inttoptr i64 %t1068 to ptr
  %t1071 = load { i64, ptr }, ptr %l384, !tbaa !27
  %t1073 = call i1 @compiler_2ftarget_2ecanCompileBf16(ptr %t1070, ptr %v6, { i64, ptr } %t1071, { i64, ptr } %t1063)
  store i1 %t1073, ptr %l387
  br label %bb304
bb303:
  store i1 false, ptr %l383, !tbaa !21
  br label %bb305
bb304:
  %t1074 = load i1, ptr %l387, !tbaa !21
  %t1075 = xor i1 %t1074, true
  store i1 %t1075, ptr %l383, !tbaa !21
  br label %bb305
bb305:
  %t1077 = load i1, ptr %l383, !tbaa !21
  br i1 %t1077, label %bb306, label %bb307
bb306:
  %t1078 = load ptr, ptr %l5, !tbaa !29
  store ptr %t1078, ptr %l389, !tbaa !29
  %t1079 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t1081 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTargetNoBackend(ptr %v0, ptr %v4, { i64, ptr } %t1079)
  store %"compiler/diagmsg:Msg" %t1081, ptr %l391
  br label %bb308
bb307:
  br label %bb312
bb308:
  %t1082 = load ptr, ptr %l389, !tbaa !29
  %t1083 = load %"compiler/diagmsg:Msg", ptr %l391
  %t1084 = call i32 @compiler_2ftarget_2erefuse(ptr %v4, ptr %v4, ptr %t1082, %"compiler/diagmsg:Msg" %t1083)
  store i32 %t1084, ptr %l392
  %t1085 = icmp ne i32 %t1084, 0
  br i1 %t1085, label %bb310, label %ok.1086, !prof !99
ok.1086:
  br label %bb309
bb309:
  br label %bb311
bb310:
  %t1087 = load i32, ptr %l392, !tbaa !23
  %t1088 = lshr i32 %t1087, 16
  %t1089 = and i32 %t1087, 65535
  %t1090 = icmp eq i32 %t1088, 1
  %t1091 = select i1 %t1090, i32 1, i32 0
  %t1092 = icmp eq i32 %t1087, 0
  %t1093 = shl i32 %t1091, 16
  %t1094 = or i32 %t1093, %t1089
  %t1095 = select i1 %t1092, i32 0, i32 %t1094
  call void @__olang_scope_close(ptr %s0)
  store i32 %t1095, ptr %rv
  br label %ret
bb311:
  br label %bb312
bb312:
  %t1097 = call ptr @__olang_scope_hold(ptr %v6)
  %t1098 = ptrtoint ptr %t1097 to i64
  store i64 %t1098, ptr %l394, !tbaa !24
  %t1099 = load i1, ptr @olang_2esole_2ecompiler_2ftarget_3aTarget_2e6
  br i1 %t1099, label %bb313, label %bb314
bb313:
  %t1101 = call ptr @__olang_region_make(ptr %v6)
  %t1102 = ptrtoint ptr %t1101 to i64
  store i64 %t1102, ptr %l394, !tbaa !24
  br label %bb314
bb314:
  %t1103 = load i64, ptr %l11, !tbaa !24
  %t1105 = getelementptr [2 x { i64, ptr }], ptr @G_2ecompiler_2ftarget_2eArchCpuFlags, i64 0, i64 %t1103
  %t1106 = load { i64, ptr }, ptr %t1105, !tbaa !37
  %t1107 = load ptr, ptr %lp7
  %t1108 = getelementptr %"compiler/target:Target", ptr %t1107, i32 0, i32 4
  %t1109 = load { i64, ptr }, ptr %t1108, !tbaa !27
  %t1111 = extractvalue { i64, ptr } %t1106, 1
  %t1112 = extractvalue { i64, ptr } %t1106, 0
  %t1114 = extractvalue { i64, ptr } %t1109, 1
  %t1115 = extractvalue { i64, ptr } %t1109, 0
  %t1116 = add i64 %t1112, %t1115
  %t1117 = load i64, ptr %l394
  %t1118 = inttoptr i64 %t1117 to ptr
  %t1119 = call ptr @__olang_held_alloc(ptr %t1118, i64 %t1116)
  call void @olang_textcopy(ptr %t1119, ptr %t1111, i64 %t1112)
  %t1120 = getelementptr i8, ptr %t1119, i64 %t1112
  call void @olang_textcopy(ptr %t1120, ptr %t1114, i64 %t1115)
  %t1121 = insertvalue { i64, ptr } undef, i64 %t1116, 0
  %t1122 = insertvalue { i64, ptr } %t1121, ptr %t1119, 1
  %t1124 = load ptr, ptr %lp7
  %t1125 = getelementptr %"compiler/target:Target", ptr %t1124, i32 0, i32 6
  %t1126 = load { i64, ptr }, ptr %t1125, !tbaa !27
  store { i64, ptr } %t1126, ptr %l401, !tbaa !27
  %t1128 = load ptr, ptr %lp7
  %t1129 = getelementptr %"compiler/target:Target", ptr %t1128, i32 0, i32 6
  store { i64, ptr } %t1122, ptr %t1129, !tbaa !27
  %t1130 = load i1, ptr @olang_2esole_2ecompiler_2ftarget_3aTarget_2e6
  br i1 %t1130, label %bb315, label %bb316
bb315:
  %t1132 = load { i64, ptr }, ptr %l401
  %t1133 = extractvalue { i64, ptr } %t1132, 1
  call void @__olang_region_release(ptr %t1133)
  store { i64, ptr } zeroinitializer, ptr %l401
  br label %bb316
bb316:
  %t1134 = load ptr, ptr %lp7
  call void @llvm.memmove.p0.p0.i64(ptr %l403, ptr %t1134, i64 152, i1 false)
  call void @__olang_scope_close(ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l403, i64 152, i1 false)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i64 @compiler_2ftarget_2eX86Level(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l23 = alloca { i64, ptr }
  %l30 = alloca { i64, ptr }
  %l39 = alloca i1
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store i64 1, ptr %l1, !tbaa !24
  store ptr @G_2ecompiler_2ftarget_2eLevelFlags, ptr %l2
  store i64 0, ptr %l3, !tbaa !24
  %t2 = load ptr, ptr %l2
  store i64 3, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t5 = load i64, ptr %l3, !tbaa !24
  %t6 = load i64, ptr %l4, !tbaa !24
  %t9 = icmp slt i64 %t5, %t6
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb2, label %bb3
bb2:
  br label %bb17
bb3:
  br label %bb4
bb4:
  %t13 = load i64, ptr %l3, !tbaa !24
  store i64 %t13, ptr %l5, !tbaa !24
  %t15 = load ptr, ptr %l2
  %t16 = load i64, ptr %l3, !tbaa !24
  %t19 = getelementptr [3 x { i64, ptr }], ptr %t15, i64 0, i64 %t16
  %t20 = load { i64, ptr }, ptr %t19, !tbaa !37
  store %olang.scope zeroinitializer, ptr %s3
  %t23 = load ptr, ptr @__olang_prog_scope
  %t25 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %t23, ptr %s3, ptr %s3, { i64, ptr } %t20, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d74, i32 0, i32 1) })
  store { i64, ptr } %t25, ptr %l23
  br label %bb5
bb5:
  %t26 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t26, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t27 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t27, 0
  store i64 %t29, ptr %l9, !tbaa !24
  br label %bb6
bb6:
  store %olang.scope zeroinitializer, ptr %s4
  %t31 = load i64, ptr %l8, !tbaa !24
  %t32 = load i64, ptr %l9, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  %t37 = xor i1 %t35, true
  br i1 %t37, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s4)
  br label %bb15
bb8:
  br label %bb9
bb9:
  %t39 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t39, ptr %l30, !tbaa !27
  %t40 = load i64, ptr %l8, !tbaa !24
  %t42 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = getelementptr { i64, ptr }, ptr %t43, i64 %t40
  %t45 = load { i64, ptr }, ptr %t44, !tbaa !37
  %t50 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d75, i32 0, i32 1) }, 1
  %t51 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d75, i32 0, i32 1) }, 0
  %t53 = extractvalue { i64, ptr } %t45, 1
  %t54 = extractvalue { i64, ptr } %t45, 0
  %t55 = add i64 %t51, %t54
  %t56 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d76, i32 0, i32 1) }, 1
  %t57 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d76, i32 0, i32 1) }, 0
  %t58 = add i64 %t55, %t57
  %t59 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t58)
  call void @olang_textcopy(ptr %t59, ptr %t50, i64 %t51)
  %t60 = getelementptr i8, ptr %t59, i64 %t51
  call void @olang_textcopy(ptr %t60, ptr %t53, i64 %t54)
  %t61 = getelementptr i8, ptr %t60, i64 %t54
  call void @olang_textcopy(ptr %t61, ptr %t56, i64 %t57)
  %t62 = insertvalue { i64, ptr } undef, i64 %t58, 0
  %t63 = insertvalue { i64, ptr } %t62, ptr %t59, 1
  %t66 = extractvalue { i64, ptr } %t63, 0
  %t67 = extractvalue { i64, ptr } %t63, 1
  %t68 = mul i64 %t66, 1
  %t69 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t68)
  call void @llvm.memcpy.p0.p0.i64(ptr %t69, ptr %t67, i64 %t68, i1 false)
  %t70 = insertvalue { i64, ptr } undef, i64 %t66, 0
  %t71 = insertvalue { i64, ptr } %t70, ptr %t69, 1
  %t74 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %s4, { i64, ptr } %a0, { i64, ptr } %t71)
  store i1 %t74, ptr %l39
  br label %bb10
bb10:
  %t75 = load i1, ptr %l39, !tbaa !21
  %t76 = xor i1 %t75, true
  br i1 %t76, label %bb11, label %bb12
bb11:
  %t78 = load i64, ptr %l1, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  store i64 %t78, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s4)
  br label %bb14
bb14:
  %t80 = load i64, ptr %l8, !tbaa !24
  %t83 = add i64 %t80, 1
  store i64 %t83, ptr %l8, !tbaa !24
  br label %bb6
bb15:
  call void @__olang_scope_close(ptr %s3)
  %t85 = load i64, ptr %l5, !tbaa !24
  %t87 = add i64 %t85, 2
  store i64 %t87, ptr %l1, !tbaa !24
  br label %bb16
bb16:
  %t89 = load i64, ptr %l3, !tbaa !24
  %t92 = add i64 %t89, 1
  store i64 %t92, ptr %l3, !tbaa !24
  br label %bb1
bb17:
  %t94 = load i64, ptr %l1, !tbaa !24
  store i64 %t94, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2ftarget_2eandroidLevel(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i8
  %l8 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i32
  %l15 = alloca { i64, ptr }
  %l17 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l27 = alloca i1
  %l32 = alloca i64
  %l35 = alloca i1
  %l40 = alloca { i64, ptr }
  %l45 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d77, i32 0, i32 1) })
  %t4 = extractvalue { i32, i64 } %t3, 1
  %t5 = extractvalue { i32, i64 } %t3, 0
  store i32 %t5, ptr %l11
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store i64 %t4, ptr %l10
  br label %bb1
bb1:
  %t8 = load i64, ptr %l10, !tbaa !24
  store i64 %t8, ptr %l8, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  store i64 -1, ptr %l8, !tbaa !24
  br label %bb4
bb4:
  %t9 = load i64, ptr %l8, !tbaa !24
  store i64 %t9, ptr %l1, !tbaa !24
  %t10 = load i64, ptr %l1, !tbaa !24
  %t12 = icmp slt i64 %t10, 0
  br i1 %t12, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s0)
  store i64 0, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t15 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t15, ptr %l15, !tbaa !27
  %t16 = load i64, ptr %l1, !tbaa !24
  %t18 = add i64 %t16, 14
  store i64 %t18, ptr %l17, !tbaa !24
  %t19 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t19, 0
  store i64 %t22, ptr %l20, !tbaa !24
  %t23 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t23, 0
  store i64 %t24, ptr %l21, !tbaa !24
  %t25 = load i64, ptr %l17, !tbaa !24
  %t26 = icmp sge i64 %t25, 0
  br i1 %t26, label %bb8, label %bb9
bb8:
  %t28 = load i64, ptr %l17, !tbaa !24
  %t29 = load i64, ptr %l20, !tbaa !24
  %t30 = icmp sle i64 %t28, %t29
  br i1 %t30, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_7532b0a1705d3da_dcb5e502962dad76)
  unreachable
bb10:
  %t32 = load i64, ptr %l20, !tbaa !24
  %t33 = load i64, ptr %l21, !tbaa !24
  %t34 = icmp sle i64 %t32, %t33
  br i1 %t34, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_7532b0a1705d3da_dcb5e502962dad76)
  unreachable
bb12:
  %t36 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = load i64, ptr %l17, !tbaa !24
  %t39 = load i64, ptr %l20, !tbaa !24
  %t40 = getelementptr i8, ptr %t37, i64 %t38
  %t41 = sub i64 %t39, %t38
  %t42 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t43 = insertvalue { i64, ptr } %t42, ptr %t40, 1
  store { i64, ptr } %t43, ptr %l2, !tbaa !27
  %t45 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t47 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t45, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d78, i32 0, i32 1) })
  store i1 %t47, ptr %l27
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_7532b0a1705d3da_dcb5e502962dad76)
  unreachable
bb14:
  %t48 = load i1, ptr %l27, !tbaa !21
  br i1 %t48, label %bb15, label %bb16
bb15:
  %t49 = load i64, ptr @G_2ecompiler_2ftarget_2eAndroidApi, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t49, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  store i64 0, ptr %l3, !tbaa !24
  %t51 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t51, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t53 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t55 = extractvalue { i64, ptr } %t53, 0
  store i64 %t55, ptr %l6, !tbaa !24
  %t57 = load i64, ptr %l6, !tbaa !24
  %t58 = sub i64 %t57, 1
  store i64 %t58, ptr %l32, !tbaa !24
  %t59 = load i64, ptr %l6, !tbaa !24
  %t60 = icmp slt i64 %t59, 2147483648
  %t61 = load i64, ptr %l5, !tbaa !24
  %t62 = icmp sge i64 %t61, 0
  %t65 = and i1 %t60, %t62
  store i1 %t65, ptr %l35, !tbaa !21
  br label %bb18
bb18:
  %t66 = load i64, ptr %l5, !tbaa !24
  %t67 = load i64, ptr %l6, !tbaa !24
  %t70 = icmp slt i64 %t66, %t67
  %t72 = xor i1 %t70, true
  br i1 %t72, label %bb19, label %bb20
bb19:
  br label %bb29
bb20:
  br label %bb21
bb21:
  %t74 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t74, ptr %l40, !tbaa !27
  %t75 = load i64, ptr %l5, !tbaa !24
  %t77 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = getelementptr i8, ptr %t78, i64 %t75
  %t80 = load i8, ptr %t79, !tbaa !32
  store i8 %t80, ptr %l7, !tbaa !22
  %t82 = load i8, ptr %l7, !tbaa !22
  %t84 = icmp ult i8 %t82, 48
  br i1 %t84, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l45, !tbaa !21
  br label %bb24
bb23:
  %t86 = load i8, ptr %l7, !tbaa !22
  %t88 = icmp ugt i8 %t86, 57
  store i1 %t88, ptr %l45, !tbaa !21
  br label %bb24
bb24:
  %t90 = load i1, ptr %l45, !tbaa !21
  br i1 %t90, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  %t92 = load i64, ptr %l3, !tbaa !24
  %t95 = mul i64 %t92, 10
  %t96 = load i8, ptr %l7, !tbaa !22
  %t98 = sub i8 %t96, 48
  %t100 = zext i8 %t98 to i64
  %t103 = add i64 %t95, %t100
  store i64 %t103, ptr %l3, !tbaa !24
  br label %bb28
bb28:
  %t105 = load i64, ptr %l5, !tbaa !24
  %t108 = add i64 %t105, 1
  store i64 %t108, ptr %l5, !tbaa !24
  br label %bb18
bb29:
  %t110 = load i64, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t110, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2ftarget_2earchIndex(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l19 = alloca i1
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store ptr @G_2ecompiler_2ftarget_2eArchs, ptr %l1
  store i64 0, ptr %l2, !tbaa !24
  %t2 = load ptr, ptr %l1
  store i64 2, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t5 = load i64, ptr %l2, !tbaa !24
  %t6 = load i64, ptr %l3, !tbaa !24
  %t9 = icmp slt i64 %t5, %t6
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb2, label %bb3
bb2:
  br label %bb10
bb3:
  br label %bb4
bb4:
  %t13 = load i64, ptr %l2, !tbaa !24
  store i64 %t13, ptr %l4, !tbaa !24
  %t15 = load ptr, ptr %l1
  %t16 = load i64, ptr %l2, !tbaa !24
  %t19 = getelementptr [2 x { i64, ptr }], ptr %t15, i64 0, i64 %t16
  %t20 = load { i64, ptr }, ptr %t19, !tbaa !37
  %t24 = load ptr, ptr @__olang_prog_scope
  %t27 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %t24, ptr %v0, { i64, ptr } %t20, { i64, ptr } %a0)
  store i1 %t27, ptr %l19
  br label %bb5
bb5:
  %t28 = load i1, ptr %l19, !tbaa !21
  br i1 %t28, label %bb6, label %bb7
bb6:
  %t29 = load i64, ptr %l4, !tbaa !24
  store i64 %t29, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t31 = load i64, ptr %l2, !tbaa !24
  %t34 = add i64 %t31, 1
  store i64 %t34, ptr %l2, !tbaa !24
  br label %bb1
bb10:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2ftarget_2eattrValue(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d79, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d79, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %a1, 1
  %t7 = extractvalue { i64, ptr } %a1, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d80, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d80, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t12 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t11)
  call void @olang_textcopy(ptr %t12, ptr %t3, i64 %t4)
  %t13 = getelementptr i8, ptr %t12, i64 %t4
  call void @olang_textcopy(ptr %t13, ptr %t6, i64 %t7)
  %t14 = getelementptr i8, ptr %t13, i64 %t7
  call void @olang_textcopy(ptr %t14, ptr %t9, i64 %t10)
  %t15 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr %t12, 1
  %t20 = call { i32, { i64, ptr } } @compiler_2ftarget_2efield(ptr %v0, ptr %s0, ptr %v2, { i64, ptr } %a0, { i64, ptr } %t16)
  %t21 = extractvalue { i32, { i64, ptr } } %t20, 1
  %t22 = extractvalue { i32, { i64, ptr } } %t20, 0
  store i32 %t22, ptr %l8
  %t23 = icmp ne i32 %t22, 0
  br i1 %t23, label %bb2, label %ok.24, !prof !99
ok.24:
  store { i64, ptr } %t21, ptr %l7
  br label %bb1
bb1:
  %t25 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t25, ptr %l2, !tbaa !27
  br label %bb3
bb2:
  %t26 = load i32, ptr %l8, !tbaa !23
  %t27 = lshr i32 %t26, 16
  %t28 = and i32 %t26, 65535
  %t29 = icmp eq i32 %t27, 1
  %t30 = select i1 %t29, i32 1, i32 0
  %t31 = icmp eq i32 %t26, 0
  %t32 = shl i32 %t30, 16
  %t33 = or i32 %t32, %t28
  %t34 = select i1 %t31, i32 0, i32 %t33
  call void @__olang_scope_close(ptr %s0)
  %t36 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t34, 0
  store { i32, { i64, ptr } } %t36, ptr %rv
  br label %ret
bb3:
  call void @__olang_scope_close(ptr %s0)
  %t37 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t38 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t37, 1
  store { i32, { i64, ptr } } %t38, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local i1 @compiler_2ftarget_2ecanCompileBf16(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca [9 x { i64, ptr }]
  %l4 = alloca %"std/os:Output"
  %l6 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l16 = alloca [9 x { i64, ptr }]
  %l17 = alloca %"std/os:Output"
  %l21 = alloca %"std/os:Output"
  %l22 = alloca i32
  %l24 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = extractvalue { i64, ptr } { i64 88, ptr getelementptr inbounds (<{ i64, [88 x i8] }>, ptr @.d81, i32 0, i32 1) }, 1
  %t2 = extractvalue { i64, ptr } { i64 88, ptr getelementptr inbounds (<{ i64, [88 x i8] }>, ptr @.d81, i32 0, i32 1) }, 0
  %t3 = extractvalue { i64, ptr } { i64 49, ptr getelementptr inbounds (<{ i64, [49 x i8] }>, ptr @.d82, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 49, ptr getelementptr inbounds (<{ i64, [49 x i8] }>, ptr @.d82, i32 0, i32 1) }, 0
  %t5 = add i64 %t2, %t4
  %t6 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t5)
  call void @olang_textcopy(ptr %t6, ptr %t1, i64 %t2)
  %t7 = getelementptr i8, ptr %t6, i64 %t2
  call void @olang_textcopy(ptr %t7, ptr %t3, i64 %t4)
  %t8 = insertvalue { i64, ptr } undef, i64 %t5, 0
  %t9 = insertvalue { i64, ptr } %t8, ptr %t6, 1
  store { i64, ptr } %t9, ptr %l2, !tbaa !27
  %t11 = call ptr @__olang_scope_hold(ptr %s0)
  %t12 = ptrtoint ptr %t11 to i64
  store i64 %t12, ptr %l6, !tbaa !24
  %t13 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_2c_209_3e_2e_2d1
  br i1 %t13, label %bb1, label %bb2
bb1:
  %t15 = call ptr @__olang_region_make(ptr %s0)
  %t16 = ptrtoint ptr %t15 to i64
  store i64 %t16, ptr %l6, !tbaa !24
  br label %bb2
bb2:
  %t19 = extractvalue { i64, ptr } %a0, 1
  %t20 = extractvalue { i64, ptr } %a0, 0
  %t21 = load i64, ptr %l6
  %t22 = inttoptr i64 %t21 to ptr
  %t23 = call ptr @__olang_held_alloc(ptr %t22, i64 %t20)
  call void @olang_textcopy(ptr %t23, ptr %t19, i64 %t20)
  %t24 = insertvalue { i64, ptr } undef, i64 %t20, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t23, 1
  store { i64, ptr } %t25, ptr %l10, !tbaa !27
  %t27 = call ptr @__olang_scope_hold(ptr %s0)
  %t28 = ptrtoint ptr %t27 to i64
  store i64 %t28, ptr %l11, !tbaa !24
  %t29 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_2c_209_3e_2e_2d1
  br i1 %t29, label %bb3, label %bb4
bb3:
  %t31 = call ptr @__olang_region_make(ptr %s0)
  %t32 = ptrtoint ptr %t31 to i64
  store i64 %t32, ptr %l11, !tbaa !24
  br label %bb4
bb4:
  %t34 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d83, i32 0, i32 1) }, 1
  %t35 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d83, i32 0, i32 1) }, 0
  %t37 = extractvalue { i64, ptr } %a1, 1
  %t38 = extractvalue { i64, ptr } %a1, 0
  %t39 = add i64 %t35, %t38
  %t40 = load i64, ptr %l11
  %t41 = inttoptr i64 %t40 to ptr
  %t42 = call ptr @__olang_held_alloc(ptr %t41, i64 %t39)
  call void @olang_textcopy(ptr %t42, ptr %t34, i64 %t35)
  %t43 = getelementptr i8, ptr %t42, i64 %t35
  call void @olang_textcopy(ptr %t43, ptr %t37, i64 %t38)
  %t44 = insertvalue { i64, ptr } undef, i64 %t39, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t42, 1
  %t47 = getelementptr [9 x { i64, ptr }], ptr %l16, i64 0, i64 0
  %t48 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t48, ptr %t47, !tbaa !37
  %t49 = getelementptr [9 x { i64, ptr }], ptr %l16, i64 0, i64 1
  store { i64, ptr } %t45, ptr %t49, !tbaa !37
  %t51 = getelementptr [9 x { i64, ptr }], ptr %l16, i64 0, i64 2
  store { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d84, i32 0, i32 1) }, ptr %t51, !tbaa !37
  %t52 = getelementptr [9 x { i64, ptr }], ptr %l16, i64 0, i64 3
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d85, i32 0, i32 1) }, ptr %t52, !tbaa !37
  %t53 = getelementptr [9 x { i64, ptr }], ptr %l16, i64 0, i64 4
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d86, i32 0, i32 1) }, ptr %t53, !tbaa !37
  %t54 = getelementptr [9 x { i64, ptr }], ptr %l16, i64 0, i64 5
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d87, i32 0, i32 1) }, ptr %t54, !tbaa !37
  %t55 = getelementptr [9 x { i64, ptr }], ptr %l16, i64 0, i64 6
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d88, i32 0, i32 1) }, ptr %t55, !tbaa !37
  %t56 = getelementptr [9 x { i64, ptr }], ptr %l16, i64 0, i64 7
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d89, i32 0, i32 1) }, ptr %t56, !tbaa !37
  %t57 = getelementptr [9 x { i64, ptr }], ptr %l16, i64 0, i64 8
  store { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d90, i32 0, i32 1) }, ptr %t57, !tbaa !37
  call void @llvm.memmove.p0.p0.i64(ptr %l3, ptr %l16, i64 144, i1 false)
  %t59 = insertvalue { i64, ptr } undef, i64 9, 0
  %t60 = insertvalue { i64, ptr } %t59, ptr %l3, 1
  %t61 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t64 = call { i32, %"std/os:Output" } @std_2fos_2eOutput_2eExec(ptr %s0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t60, { i64, ptr } %t61, i1 true, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d6, i32 0, i32 1) })
  %t65 = extractvalue { i32, %"std/os:Output" } %t64, 1
  %t66 = extractvalue { i32, %"std/os:Output" } %t64, 0
  store i32 %t66, ptr %l22
  %t67 = icmp ne i32 %t66, 0
  br i1 %t67, label %bb6, label %ok.68, !prof !99
ok.68:
  store %"std/os:Output" %t65, ptr %l21
  br label %bb5
bb5:
  %t69 = load %"std/os:Output", ptr %l21
  store %"std/os:Output" %t69, ptr %l17
  br label %bb10
bb6:
  %t70 = load i32, ptr %l22, !tbaa !23
  %t71 = ashr i32 %t70, 16
  %t73 = icmp eq i32 %t71, 1
  store i1 %t73, ptr %l24, !tbaa !21
  %t74 = load i32, ptr %l22, !tbaa !23
  %t75 = ashr i32 %t74, 16
  %t77 = icmp eq i32 %t75, 1
  br i1 %t77, label %bb7, label %bb8
bb7:
  call void @__olang_errpay_pop()
  br label %bb8
bb8:
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb10:
  %t80 = load %"std/os:Output", ptr %l17
  store %"std/os:Output" %t80, ptr %l4
  %t81 = getelementptr %"std/os:Output", ptr %l4, i32 0, i32 0
  %t82 = load i32, ptr %t81, !tbaa !23
  %t84 = icmp eq i32 %t82, 0
  call void @__olang_scope_close(ptr %s0)
  store i1 %t84, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2ftarget_2ecompiler_2ftarget_3aTarget_2eFromProbe(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i32
  %l20 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l23 = alloca i32
  %l25 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i32
  %l30 = alloca i64
  %l31 = alloca { i64, ptr }
  %l32 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i32
  %l48 = alloca { i64, ptr }
  %l49 = alloca i64
  %l52 = alloca i64
  %l53 = alloca i64
  %l61 = alloca i1
  %l62 = alloca { i64, ptr }
  %l65 = alloca i1
  %l68 = alloca { i64, ptr }
  %l69 = alloca i1
  %l70 = alloca i1
  %l73 = alloca { i64, ptr }
  %l74 = alloca i1
  %l76 = alloca ptr
  %l78 = alloca { i64, ptr }
  %l80 = alloca ptr
  %l81 = alloca i64
  %l83 = alloca { i64, ptr }
  %l85 = alloca { i64, ptr }
  %l86 = alloca i32
  %l90 = alloca { i64, ptr }
  %l92 = alloca { i64, ptr }
  %l94 = alloca { i64, ptr }
  %l95 = alloca i32
  %l97 = alloca { i64, ptr }
  %l98 = alloca ptr
  %l100 = alloca i1
  %l101 = alloca ptr
  %l103 = alloca i1
  %l104 = alloca i1
  %l106 = alloca i1
  %l109 = alloca i1
  %l110 = alloca ptr
  %l112 = alloca i1
  %l113 = alloca i64
  %l115 = alloca ptr
  %l117 = alloca i1
  %l118 = alloca i64
  %l120 = alloca i1
  %l121 = alloca i64
  %l122 = alloca ptr
  %l124 = alloca i1
  %l125 = alloca i1
  %l127 = alloca i1
  %l128 = alloca { i64, ptr }
  %l130 = alloca { i64, ptr }
  %l131 = alloca i32
  %l133 = alloca i1
  %l135 = alloca { i64, ptr }
  %l139 = alloca i64
  %l141 = alloca i64
  %l142 = alloca i32
  %l145 = alloca i64
  %l146 = alloca { i64, ptr }
  %l147 = alloca i64
  %l150 = alloca i64
  %l151 = alloca i64
  %l157 = alloca i64
  %l158 = alloca i32
  %l161 = alloca { i64, ptr }
  %l162 = alloca i64
  %l166 = alloca i64
  %l167 = alloca i64
  %l177 = alloca i64
  %l180 = alloca ptr
  %l181 = alloca i64
  %l191 = alloca { i64, ptr }
  %l195 = alloca i1
  %l196 = alloca ptr
  %l197 = alloca i64
  %l204 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = call { i32, { i64, ptr } } @compiler_2ftarget_2efield(ptr %v1, ptr %s0, ptr %v1, { i64, ptr } %t1, { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d91, i32 0, i32 1) })
  %t4 = extractvalue { i32, { i64, ptr } } %t3, 1
  %t5 = extractvalue { i32, { i64, ptr } } %t3, 0
  store i32 %t5, ptr %l18
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store { i64, ptr } %t4, ptr %l17
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t8, ptr %l15, !tbaa !27
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb4:
  %t10 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t10, ptr %l2, !tbaa !27
  %t11 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t13 = call { i32, { i64, ptr } } @compiler_2ftarget_2efield(ptr %v1, ptr %s0, ptr %v1, { i64, ptr } %t11, { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d92, i32 0, i32 1) })
  %t14 = extractvalue { i32, { i64, ptr } } %t13, 1
  %t15 = extractvalue { i32, { i64, ptr } } %t13, 0
  store i32 %t15, ptr %l23
  %t16 = icmp ne i32 %t15, 0
  br i1 %t16, label %bb6, label %ok.17, !prof !99
ok.17:
  store { i64, ptr } %t14, ptr %l22
  br label %bb5
bb5:
  %t18 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t18, ptr %l20, !tbaa !27
  br label %bb8
bb6:
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb8:
  %t20 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t20, ptr %l3, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t23 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v1, ptr %s0, { i64, ptr } %t21, { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d93, i32 0, i32 1) })
  %t24 = extractvalue { i32, i64 } %t23, 1
  %t25 = extractvalue { i32, i64 } %t23, 0
  store i32 %t25, ptr %l28
  %t26 = icmp ne i32 %t25, 0
  br i1 %t26, label %bb10, label %ok.27, !prof !99
ok.27:
  store i64 %t24, ptr %l27
  br label %bb9
bb9:
  %t28 = load i64, ptr %l27, !tbaa !24
  store i64 %t28, ptr %l25, !tbaa !24
  br label %bb12
bb10:
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb12:
  %t30 = load i64, ptr %l25, !tbaa !24
  store i64 %t30, ptr %l4, !tbaa !24
  %t31 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t31, ptr %l31, !tbaa !27
  %t32 = load i64, ptr %l4, !tbaa !24
  store i64 %t32, ptr %l32, !tbaa !24
  %t33 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t36 = extractvalue { i64, ptr } %t33, 0
  store i64 %t36, ptr %l35, !tbaa !24
  %t37 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t37, 0
  store i64 %t38, ptr %l36, !tbaa !24
  %t39 = load i64, ptr %l32, !tbaa !24
  %t40 = icmp sge i64 %t39, 0
  br i1 %t40, label %bb13, label %bb14
bb13:
  %t42 = load i64, ptr %l32, !tbaa !24
  %t43 = load i64, ptr %l35, !tbaa !24
  %t44 = icmp sle i64 %t42, %t43
  br i1 %t44, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_2b3d593c994025a_f25bcfc8e3895e8e)
  unreachable
bb15:
  %t46 = load i64, ptr %l35, !tbaa !24
  %t47 = load i64, ptr %l36, !tbaa !24
  %t48 = icmp sle i64 %t46, %t47
  br i1 %t48, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_2b3d593c994025a_f25bcfc8e3895e8e)
  unreachable
bb17:
  %t50 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !27
  %t52 = load i64, ptr %l32, !tbaa !24
  %t53 = load i64, ptr %l35, !tbaa !24
  %t54 = getelementptr i8, ptr %t51, i64 %t52
  %t55 = sub i64 %t53, %t52
  %t56 = insertvalue { i64, ptr } undef, i64 %t55, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t54, 1
  %t60 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %v1, { i64, ptr } %t57, i8 10)
  %t61 = extractvalue { i32, i64 } %t60, 1
  %t62 = extractvalue { i32, i64 } %t60, 0
  store i32 %t62, ptr %l43
  %t63 = icmp ne i32 %t62, 0
  br i1 %t63, label %bb20, label %ok.64, !prof !99
ok.64:
  store i64 %t61, ptr %l42
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_2b3d593c994025a_f25bcfc8e3895e8e)
  unreachable
bb19:
  %t65 = load i64, ptr %l42, !tbaa !24
  store i64 %t65, ptr %l30, !tbaa !24
  br label %bb22
bb20:
  br label %bb21
bb21:
  %t66 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t68 = extractvalue { i64, ptr } %t66, 0
  %t69 = load i64, ptr %l4, !tbaa !24
  %t72 = sub i64 %t68, %t69
  store i64 %t72, ptr %l30, !tbaa !24
  br label %bb22
bb22:
  %t74 = load i64, ptr %l30, !tbaa !24
  %t75 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t75, ptr %l48, !tbaa !27
  %t76 = load i64, ptr %l4, !tbaa !24
  store i64 %t76, ptr %l49, !tbaa !24
  %t77 = load i64, ptr %l4, !tbaa !24
  %t81 = add i64 %t77, %t74
  store i64 %t81, ptr %l52, !tbaa !24
  %t82 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t83 = extractvalue { i64, ptr } %t82, 0
  store i64 %t83, ptr %l53, !tbaa !24
  %t84 = load i64, ptr %l49, !tbaa !24
  %t85 = icmp sge i64 %t84, 0
  br i1 %t85, label %bb23, label %bb24
bb23:
  %t87 = load i64, ptr %l49, !tbaa !24
  %t88 = load i64, ptr %l52, !tbaa !24
  %t89 = icmp sle i64 %t87, %t88
  br i1 %t89, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_41dcdde6fea423b7_7dcc0ffa4d83aa8b)
  unreachable
bb25:
  %t91 = load i64, ptr %l52, !tbaa !24
  %t92 = load i64, ptr %l53, !tbaa !24
  %t93 = icmp sle i64 %t91, %t92
  br i1 %t93, label %bb27, label %bb28
bb26:
  call void @__olang_check_failed(ptr @olang_loc_41dcdde6fea423b7_7dcc0ffa4d83aa8b)
  unreachable
bb27:
  %t95 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !27
  %t97 = load i64, ptr %l49, !tbaa !24
  %t98 = load i64, ptr %l52, !tbaa !24
  %t99 = getelementptr i8, ptr %t96, i64 %t97
  %t100 = sub i64 %t98, %t97
  %t101 = insertvalue { i64, ptr } undef, i64 %t100, 0
  %t102 = insertvalue { i64, ptr } %t101, ptr %t99, 1
  store { i64, ptr } %t102, ptr %l6, !tbaa !27
  %t104 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t106 = extractvalue { i64, ptr } %t104, 0
  %t108 = icmp eq i64 %t106, 0
  br i1 %t108, label %bb29, label %bb30
bb28:
  call void @__olang_check_failed(ptr @olang_loc_41dcdde6fea423b7_7dcc0ffa4d83aa8b)
  unreachable
bb29:
  store i1 true, ptr %l61, !tbaa !21
  br label %bb31
bb30:
  %t110 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t110, ptr %l62, !tbaa !27
  %t111 = getelementptr { i64, ptr }, ptr %l62, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !27
  %t113 = getelementptr i8, ptr %t112, i64 0
  %t114 = load i8, ptr %t113, !tbaa !32
  %t116 = icmp ne i8 %t114, 101
  store i1 %t116, ptr %l61, !tbaa !21
  br label %bb31
bb31:
  %t118 = load i1, ptr %l61, !tbaa !21
  br i1 %t118, label %bb32, label %bb33
bb32:
  store i1 true, ptr %l65, !tbaa !21
  br label %bb35
bb33:
  %t119 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d94, i32 0, i32 1) }, ptr %l68, !tbaa !27
  %t122 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t123 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v1, ptr %s0, { i64, ptr } %t119, { i64, ptr } %t122)
  store i1 %t123, ptr %l69
  br label %bb34
bb34:
  %t124 = load i1, ptr %l69, !tbaa !21
  store i1 %t124, ptr %l65, !tbaa !21
  br label %bb35
bb35:
  %t125 = load i1, ptr %l65, !tbaa !21
  br i1 %t125, label %bb36, label %bb37
bb36:
  store i1 true, ptr %l70, !tbaa !21
  br label %bb39
bb37:
  %t126 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d95, i32 0, i32 1) }, ptr %l73, !tbaa !27
  %t129 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t130 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v1, ptr %s0, { i64, ptr } %t126, { i64, ptr } %t129)
  store i1 %t130, ptr %l74
  br label %bb38
bb38:
  %t131 = load i1, ptr %l74, !tbaa !21
  store i1 %t131, ptr %l70, !tbaa !21
  br label %bb39
bb39:
  %t132 = load i1, ptr %l70, !tbaa !21
  br i1 %t132, label %bb40, label %bb41
bb40:
  call void @__olang_scope_close(ptr %s0)
  store i32 65537, ptr %rv
  br label %ret
bb41:
  br label %bb42
bb42:
  %t134 = load ptr, ptr %l0, !tbaa !29
  store ptr %t134, ptr %l76, !tbaa !29
  %t135 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t136 = load ptr, ptr %l76, !tbaa !29
  %t137 = getelementptr %"compiler/target:Target", ptr %t136, i32 0, i32 1
  %t138 = load { i64, ptr }, ptr %t137, !tbaa !27
  store { i64, ptr } %t138, ptr %l78, !tbaa !27
  %t140 = load ptr, ptr %l76, !tbaa !29
  %t141 = getelementptr %"compiler/target:Target", ptr %t140, i32 0, i32 1
  store { i64, ptr } %t135, ptr %t141, !tbaa !27
  %t142 = load i1, ptr @olang_2esole_2ecompiler_2ftarget_3aTarget_2e1
  br i1 %t142, label %bb43, label %bb44
bb43:
  %t144 = load { i64, ptr }, ptr %l78
  %t145 = extractvalue { i64, ptr } %t144, 1
  call void @__olang_region_release(ptr %t145)
  store { i64, ptr } zeroinitializer, ptr %l78
  br label %bb44
bb44:
  %t146 = load ptr, ptr %l0, !tbaa !29
  store ptr %t146, ptr %l80, !tbaa !29
  %t147 = call ptr @__olang_scope_hold(ptr %v0)
  %t148 = ptrtoint ptr %t147 to i64
  store i64 %t148, ptr %l81, !tbaa !24
  %t149 = load i1, ptr @olang_2esole_2ecompiler_2ftarget_3aTarget_2e4
  br i1 %t149, label %bb45, label %bb46
bb45:
  %t151 = call ptr @__olang_region_make(ptr %v0)
  %t152 = ptrtoint ptr %t151 to i64
  store i64 %t152, ptr %l81, !tbaa !24
  br label %bb46
bb46:
  %t153 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t155 = call { i32, { i64, ptr } } @compiler_2ftarget_2eattrValue(ptr %v1, ptr %s0, ptr %s0, { i64, ptr } %t153, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d96, i32 0, i32 1) })
  %t156 = extractvalue { i32, { i64, ptr } } %t155, 1
  %t157 = extractvalue { i32, { i64, ptr } } %t155, 0
  store i32 %t157, ptr %l86
  %t158 = icmp ne i32 %t157, 0
  br i1 %t158, label %bb48, label %ok.159, !prof !99
ok.159:
  store { i64, ptr } %t156, ptr %l85
  br label %bb47
bb47:
  %t160 = load { i64, ptr }, ptr %l85, !tbaa !27
  store { i64, ptr } %t160, ptr %l83, !tbaa !27
  br label %bb50
bb48:
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb50:
  %t162 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t163 = extractvalue { i64, ptr } %t162, 1
  %t164 = extractvalue { i64, ptr } %t162, 0
  %t165 = load i64, ptr %l81
  %t166 = inttoptr i64 %t165 to ptr
  %t167 = call ptr @__olang_held_alloc(ptr %t166, i64 %t164)
  call void @olang_textcopy(ptr %t167, ptr %t163, i64 %t164)
  %t168 = insertvalue { i64, ptr } undef, i64 %t164, 0
  %t169 = insertvalue { i64, ptr } %t168, ptr %t167, 1
  %t171 = load ptr, ptr %l80, !tbaa !29
  %t172 = getelementptr %"compiler/target:Target", ptr %t171, i32 0, i32 4
  %t173 = load { i64, ptr }, ptr %t172, !tbaa !27
  store { i64, ptr } %t173, ptr %l90, !tbaa !27
  %t175 = load ptr, ptr %l80, !tbaa !29
  %t176 = getelementptr %"compiler/target:Target", ptr %t175, i32 0, i32 4
  store { i64, ptr } %t169, ptr %t176, !tbaa !27
  %t177 = load i1, ptr @olang_2esole_2ecompiler_2ftarget_3aTarget_2e4
  br i1 %t177, label %bb51, label %bb52
bb51:
  %t179 = load { i64, ptr }, ptr %l90
  %t180 = extractvalue { i64, ptr } %t179, 1
  call void @__olang_region_release(ptr %t180)
  store { i64, ptr } zeroinitializer, ptr %l90
  br label %bb52
bb52:
  %t181 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t183 = call { i32, { i64, ptr } } @compiler_2ftarget_2eattrValue(ptr %v1, ptr %s0, ptr %v1, { i64, ptr } %t181, { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d97, i32 0, i32 1) })
  %t184 = extractvalue { i32, { i64, ptr } } %t183, 1
  %t185 = extractvalue { i32, { i64, ptr } } %t183, 0
  store i32 %t185, ptr %l95
  %t186 = icmp ne i32 %t185, 0
  br i1 %t186, label %bb54, label %ok.187, !prof !99
ok.187:
  store { i64, ptr } %t184, ptr %l94
  br label %bb53
bb53:
  %t188 = load { i64, ptr }, ptr %l94, !tbaa !27
  store { i64, ptr } %t188, ptr %l92, !tbaa !27
  br label %bb56
bb54:
  br label %bb55
bb55:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d98, i32 0, i32 1) }, ptr %l92, !tbaa !27
  br label %bb56
bb56:
  %t189 = load { i64, ptr }, ptr %l92, !tbaa !27
  store { i64, ptr } %t189, ptr %l7, !tbaa !27
  %t190 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t192 = call { i64, ptr } @compiler_2ftarget_2eStripUnsafe(ptr %v1, ptr %s0, { i64, ptr } %t190)
  store { i64, ptr } %t192, ptr %l97
  br label %bb57
bb57:
  %t193 = load { i64, ptr }, ptr %l97, !tbaa !27
  store { i64, ptr } %t193, ptr %l8, !tbaa !27
  %t194 = load ptr, ptr %l0, !tbaa !29
  store ptr %t194, ptr %l98, !tbaa !29
  %t195 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t197 = call i1 @compiler_2ftarget_2eHasFeature(ptr %v1, ptr %s0, { i64, ptr } %t195, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d99, i32 0, i32 1) })
  store i1 %t197, ptr %l100
  br label %bb58
bb58:
  %t198 = load i1, ptr %l100, !tbaa !21
  %t199 = load ptr, ptr %l98, !tbaa !29
  %t200 = getelementptr %"compiler/target:Target", ptr %t199, i32 0, i32 10
  store i1 %t198, ptr %t200, !tbaa !21
  %t201 = load ptr, ptr %l0, !tbaa !29
  store ptr %t201, ptr %l101, !tbaa !29
  %t202 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t204 = call i1 @compiler_2ftarget_2eHasFeature(ptr %v1, ptr %s0, { i64, ptr } %t202, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d100, i32 0, i32 1) })
  store i1 %t204, ptr %l103
  br label %bb59
bb59:
  %t205 = load i1, ptr %l103, !tbaa !21
  br i1 %t205, label %bb60, label %bb61
bb60:
  %t206 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t208 = call i1 @compiler_2ftarget_2eHasFeature(ptr %v1, ptr %s0, { i64, ptr } %t206, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d101, i32 0, i32 1) })
  store i1 %t208, ptr %l106
  br label %bb62
bb61:
  store i1 false, ptr %l104, !tbaa !21
  br label %bb63
bb62:
  %t209 = load i1, ptr %l106, !tbaa !21
  store i1 %t209, ptr %l104, !tbaa !21
  br label %bb63
bb63:
  %t210 = load i1, ptr %l104, !tbaa !21
  %t211 = load ptr, ptr %l101, !tbaa !29
  %t212 = getelementptr %"compiler/target:Target", ptr %t211, i32 0, i32 11
  store i1 %t210, ptr %t212, !tbaa !21
  %t213 = load ptr, ptr %l0, !tbaa !29
  %t215 = getelementptr %"compiler/target:Target", ptr %t213, i32 0, i32 2
  %t216 = load { i64, ptr }, ptr %t215, !tbaa !27
  %t218 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t216, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d102, i32 0, i32 1) })
  store i1 %t218, ptr %l109
  br label %bb64
bb64:
  %t219 = load i1, ptr %l109, !tbaa !21
  br i1 %t219, label %bb65, label %bb66
bb65:
  store %olang.scope zeroinitializer, ptr %s7
  %t220 = load ptr, ptr %l0, !tbaa !29
  store ptr %t220, ptr %l110, !tbaa !29
  %t221 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t223 = call i1 @compiler_2ftarget_2eHasFeature(ptr %s0, ptr %s7, { i64, ptr } %t221, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d103, i32 0, i32 1) })
  store i1 %t223, ptr %l112
  br label %bb67
bb66:
  store %olang.scope zeroinitializer, ptr %s8
  %t224 = load ptr, ptr %l0, !tbaa !29
  store ptr %t224, ptr %l115, !tbaa !29
  %t225 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t227 = call i1 @compiler_2ftarget_2eHasFeature(ptr %s0, ptr %s8, { i64, ptr } %t225, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d104, i32 0, i32 1) })
  store i1 %t227, ptr %l117
  br label %bb71
bb67:
  %t228 = load i1, ptr %l112, !tbaa !21
  br i1 %t228, label %bb68, label %bb69
bb68:
  store i64 128, ptr %l113, !tbaa !24
  br label %bb70
bb69:
  store i64 0, ptr %l113, !tbaa !24
  br label %bb70
bb70:
  %t229 = load i64, ptr %l113, !tbaa !24
  %t230 = load ptr, ptr %l110, !tbaa !29
  %t231 = getelementptr %"compiler/target:Target", ptr %t230, i32 0, i32 7
  store i64 %t229, ptr %t231, !tbaa !24
  %t232 = load ptr, ptr %l0, !tbaa !29
  %t234 = getelementptr %"compiler/target:Target", ptr %t232, i32 0, i32 8
  store i1 true, ptr %t234, !tbaa !21
  call void @__olang_scope_close(ptr %s7)
  br label %bb84
bb71:
  %t235 = load i1, ptr %l117, !tbaa !21
  br i1 %t235, label %bb72, label %bb73
bb72:
  store i64 512, ptr %l118, !tbaa !24
  br label %bb78
bb73:
  %t236 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t238 = call i1 @compiler_2ftarget_2eHasFeature(ptr %s0, ptr %s8, { i64, ptr } %t236, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d105, i32 0, i32 1) })
  store i1 %t238, ptr %l120
  br label %bb74
bb74:
  %t239 = load i1, ptr %l120, !tbaa !21
  br i1 %t239, label %bb75, label %bb76
bb75:
  store i64 256, ptr %l121, !tbaa !24
  br label %bb77
bb76:
  store i64 128, ptr %l121, !tbaa !24
  br label %bb77
bb77:
  %t240 = load i64, ptr %l121, !tbaa !24
  store i64 %t240, ptr %l118, !tbaa !24
  br label %bb78
bb78:
  %t241 = load i64, ptr %l118, !tbaa !24
  %t242 = load ptr, ptr %l115, !tbaa !29
  %t243 = getelementptr %"compiler/target:Target", ptr %t242, i32 0, i32 7
  store i64 %t241, ptr %t243, !tbaa !24
  %t244 = load ptr, ptr %l0, !tbaa !29
  store ptr %t244, ptr %l122, !tbaa !29
  %t245 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t247 = call i1 @compiler_2ftarget_2eHasFeature(ptr %s0, ptr %s8, { i64, ptr } %t245, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d106, i32 0, i32 1) })
  store i1 %t247, ptr %l124
  br label %bb79
bb79:
  %t248 = load i1, ptr %l124, !tbaa !21
  br i1 %t248, label %bb80, label %bb81
bb80:
  store i1 true, ptr %l125, !tbaa !21
  br label %bb83
bb81:
  %t249 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t251 = call i1 @compiler_2ftarget_2eHasFeature(ptr %s0, ptr %s8, { i64, ptr } %t249, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d107, i32 0, i32 1) })
  store i1 %t251, ptr %l127
  br label %bb82
bb82:
  %t252 = load i1, ptr %l127, !tbaa !21
  store i1 %t252, ptr %l125, !tbaa !21
  br label %bb83
bb83:
  %t253 = load i1, ptr %l125, !tbaa !21
  %t254 = load ptr, ptr %l122, !tbaa !29
  %t255 = getelementptr %"compiler/target:Target", ptr %t254, i32 0, i32 8
  store i1 %t253, ptr %t255, !tbaa !21
  call void @__olang_scope_close(ptr %s8)
  br label %bb84
bb84:
  %t256 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t258 = call { i32, { i64, ptr } } @compiler_2ftarget_2eattrValue(ptr %v1, ptr %s0, ptr %v1, { i64, ptr } %t256, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d108, i32 0, i32 1) })
  %t259 = extractvalue { i32, { i64, ptr } } %t258, 1
  %t260 = extractvalue { i32, { i64, ptr } } %t258, 0
  store i32 %t260, ptr %l131
  %t261 = icmp ne i32 %t260, 0
  br i1 %t261, label %bb86, label %ok.262, !prof !99
ok.262:
  store { i64, ptr } %t259, ptr %l130
  br label %bb85
bb85:
  %t263 = load { i64, ptr }, ptr %l130, !tbaa !27
  store { i64, ptr } %t263, ptr %l128, !tbaa !27
  br label %bb88
bb86:
  br label %bb87
bb87:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d109, i32 0, i32 1) }, ptr %l128, !tbaa !27
  br label %bb88
bb88:
  %t264 = load { i64, ptr }, ptr %l128, !tbaa !27
  store { i64, ptr } %t264, ptr %l9, !tbaa !27
  %t265 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t267 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t265, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d110, i32 0, i32 1) })
  store i1 %t267, ptr %l133
  br label %bb89
bb89:
  %t268 = load i1, ptr %l133, !tbaa !21
  %t269 = xor i1 %t268, true
  br i1 %t269, label %bb90, label %bb91
bb90:
  %t271 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t272 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d111, i32 0, i32 1) }, 1
  %t273 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d111, i32 0, i32 1) }, 0
  %t275 = extractvalue { i64, ptr } %t271, 1
  %t276 = extractvalue { i64, ptr } %t271, 0
  %t277 = add i64 %t273, %t276
  %t278 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d112, i32 0, i32 1) }, 1
  %t279 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d112, i32 0, i32 1) }, 0
  %t280 = add i64 %t277, %t279
  %t281 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t280)
  call void @olang_textcopy(ptr %t281, ptr %t272, i64 %t273)
  %t282 = getelementptr i8, ptr %t281, i64 %t273
  call void @olang_textcopy(ptr %t282, ptr %t275, i64 %t276)
  %t283 = getelementptr i8, ptr %t282, i64 %t276
  call void @olang_textcopy(ptr %t283, ptr %t278, i64 %t279)
  %t284 = insertvalue { i64, ptr } undef, i64 %t280, 0
  %t285 = insertvalue { i64, ptr } %t284, ptr %t281, 1
  store { i64, ptr } %t285, ptr %l135, !tbaa !27
  br label %bb92
bb91:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d113, i32 0, i32 1) }, ptr %l135, !tbaa !27
  br label %bb92
bb92:
  %t288 = load { i64, ptr }, ptr %l135, !tbaa !27
  store { i64, ptr } %t288, ptr %l10, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d114, i32 0, i32 1) }, ptr %l11, !tbaa !27
  %t289 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t291 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v1, ptr %s0, { i64, ptr } %t289, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d115, i32 0, i32 1) })
  %t292 = extractvalue { i32, i64 } %t291, 1
  %t293 = extractvalue { i32, i64 } %t291, 0
  store i32 %t293, ptr %l142
  %t294 = icmp ne i32 %t293, 0
  br i1 %t294, label %bb94, label %ok.295, !prof !99
ok.295:
  store i64 %t292, ptr %l141
  br label %bb93
bb93:
  %t296 = load i64, ptr %l141, !tbaa !24
  store i64 %t296, ptr %l139, !tbaa !24
  br label %bb96
bb94:
  br label %bb95
bb95:
  store i64 -1, ptr %l139, !tbaa !24
  br label %bb96
bb96:
  %t297 = load i64, ptr %l139, !tbaa !24
  store i64 %t297, ptr %l12, !tbaa !24
  %t298 = load i64, ptr %l12, !tbaa !24
  %t300 = icmp sge i64 %t298, 0
  br i1 %t300, label %bb97, label %bb98
bb97:
  %t302 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t302, ptr %l146, !tbaa !27
  %t303 = load i64, ptr %l12, !tbaa !24
  store i64 %t303, ptr %l147, !tbaa !24
  %t304 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t307 = extractvalue { i64, ptr } %t304, 0
  store i64 %t307, ptr %l150, !tbaa !24
  %t308 = load { i64, ptr }, ptr %l146, !tbaa !27
  %t309 = extractvalue { i64, ptr } %t308, 0
  store i64 %t309, ptr %l151, !tbaa !24
  %t310 = load i64, ptr %l147, !tbaa !24
  %t311 = icmp sge i64 %t310, 0
  br i1 %t311, label %bb99, label %bb100
bb98:
  br label %bb118
bb99:
  %t313 = load i64, ptr %l147, !tbaa !24
  %t314 = load i64, ptr %l150, !tbaa !24
  %t315 = icmp sle i64 %t313, %t314
  br i1 %t315, label %bb101, label %bb102
bb100:
  call void @__olang_check_failed(ptr @olang_loc_e010b40d861556cc_7cbd713015487310)
  unreachable
bb101:
  %t317 = load i64, ptr %l150, !tbaa !24
  %t318 = load i64, ptr %l151, !tbaa !24
  %t319 = icmp sle i64 %t317, %t318
  br i1 %t319, label %bb103, label %bb104
bb102:
  call void @__olang_check_failed(ptr @olang_loc_e010b40d861556cc_7cbd713015487310)
  unreachable
bb103:
  %t321 = getelementptr { i64, ptr }, ptr %l146, i32 0, i32 1
  %t322 = load ptr, ptr %t321, !tbaa !27
  %t323 = load i64, ptr %l147, !tbaa !24
  %t324 = load i64, ptr %l150, !tbaa !24
  %t325 = getelementptr i8, ptr %t322, i64 %t323
  %t326 = sub i64 %t324, %t323
  %t327 = insertvalue { i64, ptr } undef, i64 %t326, 0
  %t328 = insertvalue { i64, ptr } %t327, ptr %t325, 1
  %t331 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %v1, { i64, ptr } %t328, i8 41)
  %t332 = extractvalue { i32, i64 } %t331, 1
  %t333 = extractvalue { i32, i64 } %t331, 0
  store i32 %t333, ptr %l158
  %t334 = icmp ne i32 %t333, 0
  br i1 %t334, label %bb106, label %ok.335, !prof !99
ok.335:
  store i64 %t332, ptr %l157
  br label %bb105
bb104:
  call void @__olang_check_failed(ptr @olang_loc_e010b40d861556cc_7cbd713015487310)
  unreachable
bb105:
  %t336 = load i64, ptr %l157, !tbaa !24
  store i64 %t336, ptr %l145, !tbaa !24
  br label %bb108
bb106:
  br label %bb107
bb107:
  store i64 -1, ptr %l145, !tbaa !24
  br label %bb108
bb108:
  %t337 = load i64, ptr %l145, !tbaa !24
  store i64 %t337, ptr %l13, !tbaa !24
  %t338 = load i64, ptr %l13, !tbaa !24
  %t340 = icmp sge i64 %t338, 0
  br i1 %t340, label %bb109, label %bb110
bb109:
  %t342 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t342, ptr %l161, !tbaa !27
  %t343 = load i64, ptr %l12, !tbaa !24
  store i64 %t343, ptr %l162, !tbaa !24
  %t344 = load i64, ptr %l12, !tbaa !24
  %t345 = load i64, ptr %l13, !tbaa !24
  %t348 = add i64 %t344, %t345
  %t350 = add i64 %t348, 1
  store i64 %t350, ptr %l166, !tbaa !24
  %t351 = load { i64, ptr }, ptr %l161, !tbaa !27
  %t352 = extractvalue { i64, ptr } %t351, 0
  store i64 %t352, ptr %l167, !tbaa !24
  %t353 = load i64, ptr %l162, !tbaa !24
  %t354 = icmp sge i64 %t353, 0
  br i1 %t354, label %bb111, label %bb112
bb110:
  br label %bb117
bb111:
  %t356 = load i64, ptr %l162, !tbaa !24
  %t357 = load i64, ptr %l166, !tbaa !24
  %t358 = icmp sle i64 %t356, %t357
  br i1 %t358, label %bb113, label %bb114
bb112:
  call void @__olang_check_failed(ptr @olang_loc_8cdf81df4f8deaf9_3f7b7447e7e110ed)
  unreachable
bb113:
  %t360 = load i64, ptr %l166, !tbaa !24
  %t361 = load i64, ptr %l167, !tbaa !24
  %t362 = icmp sle i64 %t360, %t361
  br i1 %t362, label %bb115, label %bb116
bb114:
  call void @__olang_check_failed(ptr @olang_loc_8cdf81df4f8deaf9_3f7b7447e7e110ed)
  unreachable
bb115:
  %t364 = getelementptr { i64, ptr }, ptr %l161, i32 0, i32 1
  %t365 = load ptr, ptr %t364, !tbaa !27
  %t366 = load i64, ptr %l162, !tbaa !24
  %t367 = load i64, ptr %l166, !tbaa !24
  %t368 = getelementptr i8, ptr %t365, i64 %t366
  %t369 = sub i64 %t367, %t366
  %t370 = insertvalue { i64, ptr } undef, i64 %t369, 0
  %t371 = insertvalue { i64, ptr } %t370, ptr %t368, 1
  %t372 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d116, i32 0, i32 1) }, 1
  %t373 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d116, i32 0, i32 1) }, 0
  %t375 = extractvalue { i64, ptr } %t371, 1
  %t376 = extractvalue { i64, ptr } %t371, 0
  %t377 = add i64 %t373, %t376
  %t378 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t377)
  call void @olang_textcopy(ptr %t378, ptr %t372, i64 %t373)
  %t379 = getelementptr i8, ptr %t378, i64 %t373
  call void @olang_textcopy(ptr %t379, ptr %t375, i64 %t376)
  %t380 = insertvalue { i64, ptr } undef, i64 %t377, 0
  %t381 = insertvalue { i64, ptr } %t380, ptr %t378, 1
  store { i64, ptr } %t381, ptr %l11, !tbaa !27
  br label %bb117
bb116:
  call void @__olang_check_failed(ptr @olang_loc_8cdf81df4f8deaf9_3f7b7447e7e110ed)
  unreachable
bb117:
  br label %bb118
bb118:
  %t384 = load ptr, ptr %l0, !tbaa !29
  %t386 = getelementptr %"compiler/target:Target", ptr %t384, i32 0, i32 7
  %t387 = load i64, ptr %t386, !tbaa !24
  %t389 = icmp sgt i64 %t387, 0
  br i1 %t389, label %bb119, label %bb120
bb119:
  %t391 = load ptr, ptr %l0, !tbaa !29
  %t393 = getelementptr %"compiler/target:Target", ptr %t391, i32 0, i32 7
  %t394 = load i64, ptr %t393, !tbaa !24
  store i64 %t394, ptr %l177, !tbaa !24
  br label %bb121
bb120:
  store i64 128, ptr %l177, !tbaa !24
  br label %bb121
bb121:
  %t396 = load i64, ptr %l177, !tbaa !24
  store i64 %t396, ptr %l14, !tbaa !24
  %t397 = load ptr, ptr %l0, !tbaa !29
  store ptr %t397, ptr %l180, !tbaa !29
  %t398 = call ptr @__olang_scope_hold(ptr %v0)
  %t399 = ptrtoint ptr %t398 to i64
  store i64 %t399, ptr %l181, !tbaa !24
  %t400 = load i1, ptr @olang_2esole_2ecompiler_2ftarget_3aTarget_2e5
  br i1 %t400, label %bb122, label %bb123
bb122:
  %t402 = call ptr @__olang_region_make(ptr %v0)
  %t403 = ptrtoint ptr %t402 to i64
  store i64 %t403, ptr %l181, !tbaa !24
  br label %bb123
bb123:
  %t404 = load ptr, ptr %l0, !tbaa !29
  %t406 = getelementptr %"compiler/target:Target", ptr %t404, i32 0, i32 4
  %t407 = load { i64, ptr }, ptr %t406, !tbaa !27
  %t408 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t409 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t410 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t411 = load i64, ptr %l14, !tbaa !24
  %t412 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d117, i32 0, i32 1) }, 1
  %t413 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d117, i32 0, i32 1) }, 0
  %t415 = extractvalue { i64, ptr } %t407, 1
  %t416 = extractvalue { i64, ptr } %t407, 0
  %t417 = add i64 %t413, %t416
  %t418 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d118, i32 0, i32 1) }, 1
  %t419 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d118, i32 0, i32 1) }, 0
  %t420 = add i64 %t417, %t419
  %t422 = extractvalue { i64, ptr } %t408, 1
  %t423 = extractvalue { i64, ptr } %t408, 0
  %t424 = add i64 %t420, %t423
  %t425 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d119, i32 0, i32 1) }, 1
  %t426 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d119, i32 0, i32 1) }, 0
  %t427 = add i64 %t424, %t426
  %t429 = extractvalue { i64, ptr } %t409, 1
  %t430 = extractvalue { i64, ptr } %t409, 0
  %t431 = add i64 %t427, %t430
  %t433 = extractvalue { i64, ptr } %t410, 1
  %t434 = extractvalue { i64, ptr } %t410, 0
  %t435 = add i64 %t431, %t434
  %t436 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d120, i32 0, i32 1) }, 1
  %t437 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d120, i32 0, i32 1) }, 0
  %t438 = add i64 %t435, %t437
  %t440 = call i64 @__olang_fmt_i64(ptr null, i64 %t411)
  %t441 = add i64 %t438, %t440
  %t442 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d119, i32 0, i32 1) }, 1
  %t443 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d119, i32 0, i32 1) }, 0
  %t444 = add i64 %t441, %t443
  %t445 = load i64, ptr %l181
  %t446 = inttoptr i64 %t445 to ptr
  %t447 = call ptr @__olang_held_alloc(ptr %t446, i64 %t444)
  call void @olang_textcopy(ptr %t447, ptr %t412, i64 %t413)
  %t448 = getelementptr i8, ptr %t447, i64 %t413
  call void @olang_textcopy(ptr %t448, ptr %t415, i64 %t416)
  %t449 = getelementptr i8, ptr %t448, i64 %t416
  call void @olang_textcopy(ptr %t449, ptr %t418, i64 %t419)
  %t450 = getelementptr i8, ptr %t449, i64 %t419
  call void @olang_textcopy(ptr %t450, ptr %t422, i64 %t423)
  %t451 = getelementptr i8, ptr %t450, i64 %t423
  call void @olang_textcopy(ptr %t451, ptr %t425, i64 %t426)
  %t452 = getelementptr i8, ptr %t451, i64 %t426
  call void @olang_textcopy(ptr %t452, ptr %t429, i64 %t430)
  %t453 = getelementptr i8, ptr %t452, i64 %t430
  call void @olang_textcopy(ptr %t453, ptr %t433, i64 %t434)
  %t454 = getelementptr i8, ptr %t453, i64 %t434
  call void @olang_textcopy(ptr %t454, ptr %t436, i64 %t437)
  %t455 = getelementptr i8, ptr %t454, i64 %t437
  %t456 = call i64 @__olang_fmt_i64(ptr %t455, i64 %t411)
  %t457 = getelementptr i8, ptr %t455, i64 %t440
  call void @olang_textcopy(ptr %t457, ptr %t442, i64 %t443)
  %t458 = insertvalue { i64, ptr } undef, i64 %t444, 0
  %t459 = insertvalue { i64, ptr } %t458, ptr %t447, 1
  %t461 = load ptr, ptr %l180, !tbaa !29
  %t462 = getelementptr %"compiler/target:Target", ptr %t461, i32 0, i32 5
  %t463 = load { i64, ptr }, ptr %t462, !tbaa !27
  store { i64, ptr } %t463, ptr %l191, !tbaa !27
  %t465 = load ptr, ptr %l180, !tbaa !29
  %t466 = getelementptr %"compiler/target:Target", ptr %t465, i32 0, i32 5
  store { i64, ptr } %t459, ptr %t466, !tbaa !27
  %t467 = load i1, ptr @olang_2esole_2ecompiler_2ftarget_3aTarget_2e5
  br i1 %t467, label %bb124, label %bb125
bb124:
  %t469 = load { i64, ptr }, ptr %l191
  %t470 = extractvalue { i64, ptr } %t469, 1
  call void @__olang_region_release(ptr %t470)
  store { i64, ptr } zeroinitializer, ptr %l191
  br label %bb125
bb125:
  %t471 = load ptr, ptr %l0, !tbaa !29
  %t473 = getelementptr %"compiler/target:Target", ptr %t471, i32 0, i32 2
  %t474 = load { i64, ptr }, ptr %t473, !tbaa !27
  %t476 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t474, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d121, i32 0, i32 1) })
  store i1 %t476, ptr %l195
  br label %bb126
bb126:
  %t477 = load i1, ptr %l195, !tbaa !21
  br i1 %t477, label %bb127, label %bb128
bb127:
  %t478 = load ptr, ptr %l0, !tbaa !29
  store ptr %t478, ptr %l196, !tbaa !29
  %t479 = call ptr @__olang_scope_hold(ptr %v0)
  %t480 = ptrtoint ptr %t479 to i64
  store i64 %t480, ptr %l197, !tbaa !24
  %t481 = load i1, ptr @olang_2esole_2ecompiler_2ftarget_3aTarget_2e5
  br i1 %t481, label %bb129, label %bb130
bb128:
  br label %bb133
bb129:
  %t483 = call ptr @__olang_region_make(ptr %v0)
  %t484 = ptrtoint ptr %t483 to i64
  store i64 %t484, ptr %l197, !tbaa !24
  br label %bb130
bb130:
  %t485 = load ptr, ptr %l0, !tbaa !29
  %t487 = getelementptr %"compiler/target:Target", ptr %t485, i32 0, i32 5
  %t488 = load { i64, ptr }, ptr %t487, !tbaa !27
  %t489 = load { i64, ptr }, ptr @G_2ecompiler_2ftarget_2eBranchProtection, !tbaa !27
  %t491 = extractvalue { i64, ptr } %t488, 1
  %t492 = extractvalue { i64, ptr } %t488, 0
  %t494 = extractvalue { i64, ptr } %t489, 1
  %t495 = extractvalue { i64, ptr } %t489, 0
  %t496 = add i64 %t492, %t495
  %t497 = load i64, ptr %l197
  %t498 = inttoptr i64 %t497 to ptr
  %t499 = call ptr @__olang_held_alloc(ptr %t498, i64 %t496)
  call void @olang_textcopy(ptr %t499, ptr %t491, i64 %t492)
  %t500 = getelementptr i8, ptr %t499, i64 %t492
  call void @olang_textcopy(ptr %t500, ptr %t494, i64 %t495)
  %t501 = insertvalue { i64, ptr } undef, i64 %t496, 0
  %t502 = insertvalue { i64, ptr } %t501, ptr %t499, 1
  %t504 = load ptr, ptr %l196, !tbaa !29
  %t505 = getelementptr %"compiler/target:Target", ptr %t504, i32 0, i32 5
  %t506 = load { i64, ptr }, ptr %t505, !tbaa !27
  store { i64, ptr } %t506, ptr %l204, !tbaa !27
  %t508 = load ptr, ptr %l196, !tbaa !29
  %t509 = getelementptr %"compiler/target:Target", ptr %t508, i32 0, i32 5
  store { i64, ptr } %t502, ptr %t509, !tbaa !27
  %t510 = load i1, ptr @olang_2esole_2ecompiler_2ftarget_3aTarget_2e5
  br i1 %t510, label %bb131, label %bb132
bb131:
  %t512 = load { i64, ptr }, ptr %l204
  %t513 = extractvalue { i64, ptr } %t512, 1
  call void @__olang_region_release(ptr %t513)
  store { i64, ptr } zeroinitializer, ptr %l204
  br label %bb132
bb132:
  br label %bb133
bb133:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2ftarget_2ecompiler_2ftarget_3aTarget_2eRunner(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %lp1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca i64
  %lp11 = alloca ptr
  %lp12 = alloca ptr
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l18 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l24 = alloca i32
  %l28 = alloca i1
  %l31 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l42 = alloca i1
  %l50 = alloca i64
  %l52 = alloca i1
  %l54 = alloca { i64, ptr }
  %l55 = alloca i1
  %l58 = alloca ptr
  %l59 = alloca i64
  %l62 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %l66 = alloca { i64, ptr }
  %l67 = alloca { i64, ptr }
  %l68 = alloca i64
  %l69 = alloca { i64, ptr }
  %l72 = alloca i1
  %l73 = alloca { i64, ptr }
  %l74 = alloca { i64, ptr }
  %l75 = alloca i32
  %l77 = alloca i64
  %l82 = alloca { i64, ptr }
  %l83 = alloca i64
  %l101 = alloca { i64, ptr }
  %l103 = alloca i1
  %l108 = alloca i1
  %l110 = alloca { i64, ptr }
  %l111 = alloca { i64, ptr }
  %l112 = alloca i64
  %l113 = alloca { i64, ptr }
  %l114 = alloca { i64, ptr }
  %l116 = alloca i1
  %l117 = alloca i1
  %l122 = alloca i1
  %l123 = alloca i64
  %l127 = alloca { i64, ptr }
  %l131 = alloca { i64, ptr }
  %l134 = alloca i1
  %l140 = alloca { i64, ptr }
  %l141 = alloca { i64, ptr }
  %l142 = alloca i64
  %l143 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l13
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store ptr %t2, ptr %lp1
  %t3 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l13
  %t4 = load ptr, ptr %lp1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %t4
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/target:Target", ptr %t5, i32 0, i32 9
  %t8 = load i1, ptr %t7, !tbaa !21
  %t10 = xor i1 %t8, true
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load ptr, ptr %lp1
  %t14 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %v1, ptr %v1, ptr %t12)
  store { i64, ptr } %t14, ptr %l18
  br label %bb4
bb3:
  br label %bb5
bb4:
  %t15 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t15, ptr %l19, !tbaa !27
  %t16 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t16, 0
  store i64 %t17, ptr %l20, !tbaa !24
  %t18 = load i64, ptr %l20, !tbaa !24
  %t19 = mul i64 %t18, 16
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  %t21 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  store { i64, ptr } %t22, ptr %l21, !tbaa !27
  %t23 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = load i64, ptr %l20, !tbaa !24
  %t28 = mul i64 %t27, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t24, ptr %t26, i64 %t28, i1 false)
  %t29 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t29, ptr %l19, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t30 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t31 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t30, 1
  store { i32, { i64, ptr } } %t31, ptr %rv
  br label %ret
bb5:
  %t32 = call { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %s0, ptr %v1, { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d122, i32 0, i32 1) })
  %t33 = extractvalue { i32, { i64, ptr } } %t32, 1
  %t34 = extractvalue { i32, { i64, ptr } } %t32, 0
  store i32 %t34, ptr %l24
  %t35 = icmp ne i32 %t34, 0
  br i1 %t35, label %bb7, label %ok.36, !prof !99
ok.36:
  store { i64, ptr } %t33, ptr %l23
  br label %bb6
bb6:
  %t37 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t37, ptr %l22, !tbaa !27
  br label %bb11
bb7:
  %t38 = load i32, ptr %l24, !tbaa !23
  %t39 = ashr i32 %t38, 16
  %t41 = icmp eq i32 %t39, 1
  br i1 %t41, label %bb8, label %bb9
bb8:
  call void @__olang_errpay_pop()
  br label %bb9
bb9:
  br label %bb10
bb10:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d123, i32 0, i32 1) }, ptr %l22, !tbaa !27
  br label %bb11
bb11:
  %t43 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t43, ptr %l2, !tbaa !27
  %t44 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t46 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t44, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d124, i32 0, i32 1) })
  store i1 %t46, ptr %l28
  br label %bb12
bb12:
  %t47 = load i1, ptr %l28, !tbaa !21
  %t48 = xor i1 %t47, true
  br i1 %t48, label %bb13, label %bb14
bb13:
  store %olang.scope zeroinitializer, ptr %s3
  %t50 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t52 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %v1, ptr %s3, ptr %v1, { i64, ptr } %t50, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d125, i32 0, i32 1) })
  store { i64, ptr } %t52, ptr %l31
  br label %bb15
bb14:
  br label %bb42
bb15:
  %t53 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t53, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t54 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t56 = extractvalue { i64, ptr } %t54, 0
  store i64 %t56, ptr %l5, !tbaa !24
  br label %bb16
bb16:
  store %olang.scope zeroinitializer, ptr %s4
  %t58 = load i64, ptr %l4, !tbaa !24
  %t59 = load i64, ptr %l5, !tbaa !24
  %t62 = icmp slt i64 %t58, %t59
  %t64 = xor i1 %t62, true
  br i1 %t64, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s4)
  br label %bb26
bb18:
  br label %bb19
bb19:
  %t66 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t66, ptr %l38, !tbaa !27
  %t67 = load i64, ptr %l4, !tbaa !24
  %t69 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !27
  %t71 = getelementptr { i64, ptr }, ptr %t70, i64 %t67
  %t72 = load { i64, ptr }, ptr %t71, !tbaa !37
  store { i64, ptr } %t72, ptr %l6, !tbaa !27
  %t74 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t76 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s4, { i64, ptr } %t74, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d126, i32 0, i32 1) })
  store i1 %t76, ptr %l42
  br label %bb20
bb20:
  %t77 = load i1, ptr %l42, !tbaa !21
  %t78 = xor i1 %t77, true
  br i1 %t78, label %bb21, label %bb22
bb21:
  %t80 = load ptr, ptr %lp1
  %t81 = load { i64, ptr }, ptr %l6, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t80, { i64, ptr } %t81)
  br label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s4)
  br label %bb25
bb25:
  %t84 = load i64, ptr %l4, !tbaa !24
  %t87 = add i64 %t84, 1
  store i64 %t87, ptr %l4, !tbaa !24
  br label %bb16
bb26:
  call void @__olang_scope_close(ptr %s3)
  %t89 = load ptr, ptr %lp1
  %t91 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v1, ptr %t89)
  store i64 %t91, ptr %l50
  br label %bb27
bb27:
  %t92 = load i64, ptr %l50, !tbaa !24
  %t93 = icmp eq i64 %t92, 0
  br i1 %t93, label %bb28, label %bb29
bb28:
  store i1 true, ptr %l52, !tbaa !21
  br label %bb32
bb29:
  %t95 = load ptr, ptr %lp1
  %t97 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v1, ptr %v1, ptr %t95, i64 0)
  store { i64, ptr } %t97, ptr %l54
  br label %bb30
bb30:
  %t98 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t99 = call i1 @compiler_2ftarget_2eexecutable(ptr %v1, { i64, ptr } %t98)
  store i1 %t99, ptr %l55
  br label %bb31
bb31:
  %t100 = load i1, ptr %l55, !tbaa !21
  %t101 = xor i1 %t100, true
  store i1 %t101, ptr %l52, !tbaa !21
  br label %bb32
bb32:
  %t103 = load i1, ptr %l52, !tbaa !21
  br i1 %t103, label %bb33, label %bb34
bb33:
  call void @__olang_scope_close(ptr %s0)
  %t105 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t105, ptr %rv
  br label %ret
bb34:
  br label %bb35
bb35:
  %t106 = load ptr, ptr %lp1
  store ptr %t106, ptr %l58, !tbaa !29
  %t107 = call ptr @__olang_scope_hold(ptr %v1)
  %t108 = ptrtoint ptr %t107 to i64
  store i64 %t108, ptr %l59, !tbaa !24
  %t109 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t109, label %bb36, label %bb37
bb36:
  %t111 = call ptr @__olang_region_make(ptr %v1)
  %t112 = ptrtoint ptr %t111 to i64
  store i64 %t112, ptr %l59, !tbaa !24
  br label %bb37
bb37:
  %t113 = load ptr, ptr %lp1
  %t115 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v1, ptr %v1, ptr %t113, i64 0)
  store { i64, ptr } %t115, ptr %l62
  br label %bb38
bb38:
  %t116 = load i64, ptr %l59
  %t117 = inttoptr i64 %t116 to ptr
  %t118 = load i64, ptr %l59
  %t119 = inttoptr i64 %t118 to ptr
  %t120 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t121 = call { i64, ptr } @compiler_2ftarget_2ewhereIs(ptr %t117, ptr %t119, { i64, ptr } %t120)
  store { i64, ptr } %t121, ptr %l63
  br label %bb39
bb39:
  %t122 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t123 = load i64, ptr %l59
  %t124 = inttoptr i64 %t123 to ptr
  %t125 = extractvalue { i64, ptr } %t122, 0
  %t126 = extractvalue { i64, ptr } %t122, 1
  %t127 = mul i64 %t125, 1
  %t128 = call ptr @__olang_held_alloc(ptr %t124, i64 %t127)
  call void @llvm.memcpy.p0.p0.i64(ptr %t128, ptr %t126, i64 %t127, i1 false)
  %t129 = insertvalue { i64, ptr } undef, i64 %t125, 0
  %t130 = insertvalue { i64, ptr } %t129, ptr %t128, 1
  %t131 = load ptr, ptr %l58, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_Haae4fbc3ba15583a49040d883d2248d1(ptr %v1, ptr %v1, ptr %t131, i64 0, { i64, ptr } %t130)
  br label %bb40
bb40:
  %t133 = load ptr, ptr %lp1
  %t135 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %v1, ptr %v1, ptr %t133)
  store { i64, ptr } %t135, ptr %l66
  br label %bb41
bb41:
  %t136 = load { i64, ptr }, ptr %l66, !tbaa !27
  store { i64, ptr } %t136, ptr %l67, !tbaa !27
  %t137 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t138 = extractvalue { i64, ptr } %t137, 0
  store i64 %t138, ptr %l68, !tbaa !24
  %t139 = load i64, ptr %l68, !tbaa !24
  %t140 = mul i64 %t139, 16
  %t141 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t140)
  %t142 = insertvalue { i64, ptr } undef, i64 %t139, 0
  %t143 = insertvalue { i64, ptr } %t142, ptr %t141, 1
  store { i64, ptr } %t143, ptr %l69, !tbaa !27
  %t144 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t145 = load ptr, ptr %t144, !tbaa !27
  %t146 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t147 = load ptr, ptr %t146, !tbaa !27
  %t148 = load i64, ptr %l68, !tbaa !24
  %t149 = mul i64 %t148, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t145, ptr %t147, i64 %t149, i1 false)
  %t150 = load { i64, ptr }, ptr %l69, !tbaa !27
  store { i64, ptr } %t150, ptr %l67, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t151 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t152 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t151, 1
  store { i32, { i64, ptr } } %t152, ptr %rv
  br label %ret
bb42:
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t155 = getelementptr %"compiler/target:Target", ptr %t153, i32 0, i32 3
  %t156 = load { i64, ptr }, ptr %t155, !tbaa !27
  %t158 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t156, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d127, i32 0, i32 1) })
  store i1 %t158, ptr %l72
  br label %bb43
bb43:
  %t159 = load i1, ptr %l72, !tbaa !21
  br i1 %t159, label %bb44, label %bb45
bb44:
  %t160 = call { i32, { i64, ptr } } @compiler_2ftarget_2ewine(ptr %v1)
  %t161 = extractvalue { i32, { i64, ptr } } %t160, 1
  %t162 = extractvalue { i32, { i64, ptr } } %t160, 0
  store i32 %t162, ptr %l75
  %t163 = icmp ne i32 %t162, 0
  br i1 %t163, label %bb47, label %ok.164, !prof !99
ok.164:
  store { i64, ptr } %t161, ptr %l74
  br label %bb46
bb45:
  br label %bb49
bb46:
  %t165 = load { i64, ptr }, ptr %l74, !tbaa !27
  store { i64, ptr } %t165, ptr %l73, !tbaa !27
  br label %bb48
bb47:
  %t166 = load i32, ptr %l75, !tbaa !23
  %t167 = lshr i32 %t166, 16
  %t168 = and i32 %t166, 65535
  %t169 = icmp eq i32 %t167, 1
  %t170 = select i1 %t169, i32 1, i32 0
  %t171 = icmp eq i32 %t166, 0
  %t172 = shl i32 %t170, 16
  %t173 = or i32 %t172, %t168
  %t174 = select i1 %t171, i32 0, i32 %t173
  call void @__olang_scope_close(ptr %s0)
  %t176 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t174, 0
  store { i32, { i64, ptr } } %t176, ptr %rv
  br label %ret
bb48:
  call void @__olang_scope_close(ptr %s0)
  %t177 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t178 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t177, 1
  store { i32, { i64, ptr } } %t178, ptr %rv
  br label %ret
bb49:
  store %olang.scope zeroinitializer, ptr %s9
  %t179 = call ptr @__olang_scope_hold(ptr %s9)
  %t180 = ptrtoint ptr %t179 to i64
  store i64 %t180, ptr %l77, !tbaa !24
  %t181 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_2c_202_3e_2e_2d1
  br i1 %t181, label %bb50, label %bb51
bb50:
  %t183 = call ptr @__olang_region_make(ptr %s9)
  %t184 = ptrtoint ptr %t183 to i64
  store i64 %t184, ptr %l77, !tbaa !24
  br label %bb51
bb51:
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t187 = getelementptr %"compiler/target:Target", ptr %t185, i32 0, i32 2
  %t188 = load { i64, ptr }, ptr %t187, !tbaa !27
  %t189 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d128, i32 0, i32 1) }, 1
  %t190 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d128, i32 0, i32 1) }, 0
  %t192 = extractvalue { i64, ptr } %t188, 1
  %t193 = extractvalue { i64, ptr } %t188, 0
  %t194 = add i64 %t190, %t193
  %t195 = load i64, ptr %l77
  %t196 = inttoptr i64 %t195 to ptr
  %t197 = call ptr @__olang_held_alloc(ptr %t196, i64 %t194)
  call void @olang_textcopy(ptr %t197, ptr %t189, i64 %t190)
  %t198 = getelementptr i8, ptr %t197, i64 %t190
  call void @olang_textcopy(ptr %t198, ptr %t192, i64 %t193)
  %t199 = insertvalue { i64, ptr } undef, i64 %t194, 0
  %t200 = insertvalue { i64, ptr } %t199, ptr %t197, 1
  store { i64, ptr } %t200, ptr %l82, !tbaa !27
  %t202 = call ptr @__olang_scope_hold(ptr %s9)
  %t203 = ptrtoint ptr %t202 to i64
  store i64 %t203, ptr %l83, !tbaa !24
  %t204 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_2c_202_3e_2e_2d1
  br i1 %t204, label %bb52, label %bb53
bb52:
  %t206 = call ptr @__olang_region_make(ptr %s9)
  %t207 = ptrtoint ptr %t206 to i64
  store i64 %t207, ptr %l83, !tbaa !24
  br label %bb53
bb53:
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t210 = getelementptr %"compiler/target:Target", ptr %t208, i32 0, i32 2
  %t211 = load { i64, ptr }, ptr %t210, !tbaa !27
  %t212 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d129, i32 0, i32 1) }, 1
  %t213 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d129, i32 0, i32 1) }, 0
  %t215 = extractvalue { i64, ptr } %t211, 1
  %t216 = extractvalue { i64, ptr } %t211, 0
  %t217 = add i64 %t213, %t216
  %t218 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d130, i32 0, i32 1) }, 1
  %t219 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d130, i32 0, i32 1) }, 0
  %t220 = add i64 %t217, %t219
  %t221 = load i64, ptr %l83
  %t222 = inttoptr i64 %t221 to ptr
  %t223 = call ptr @__olang_held_alloc(ptr %t222, i64 %t220)
  call void @olang_textcopy(ptr %t223, ptr %t212, i64 %t213)
  %t224 = getelementptr i8, ptr %t223, i64 %t213
  call void @olang_textcopy(ptr %t224, ptr %t215, i64 %t216)
  %t225 = getelementptr i8, ptr %t224, i64 %t216
  call void @olang_textcopy(ptr %t225, ptr %t218, i64 %t219)
  %t226 = insertvalue { i64, ptr } undef, i64 %t220, 0
  %t227 = insertvalue { i64, ptr } %t226, ptr %t223, 1
  %t229 = load { i64, ptr }, ptr %l82, !tbaa !27
  %t230 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } %t229, 0
  %t232 = insertvalue [2 x { i64, ptr }] %t230, { i64, ptr } %t227, 1
  %t234 = call ptr @__olang_scope_alloc_a(ptr %s9, i64 32, i64 8)
  store [2 x { i64, ptr }] %t232, ptr %t234
  store ptr %t234, ptr %l7
  store i64 0, ptr %l8, !tbaa !24
  %t236 = load ptr, ptr %l7
  store i64 2, ptr %l9, !tbaa !24
  br label %bb54
bb54:
  store %olang.scope zeroinitializer, ptr %s12
  %t239 = load i64, ptr %l8, !tbaa !24
  %t240 = load i64, ptr %l9, !tbaa !24
  %t243 = icmp slt i64 %t239, %t240
  %t245 = xor i1 %t243, true
  br i1 %t245, label %bb55, label %bb56
bb55:
  call void @__olang_scope_close(ptr %s12)
  br label %bb94
bb56:
  br label %bb57
bb57:
  %t247 = load ptr, ptr %l7
  %t248 = load i64, ptr %l8, !tbaa !24
  %t251 = getelementptr [2 x { i64, ptr }], ptr %t247, i64 0, i64 %t248
  %t252 = load { i64, ptr }, ptr %t251, !tbaa !37
  %t256 = call { i64, ptr } @compiler_2ftarget_2ewhereIs(ptr %s9, ptr %v1, { i64, ptr } %t252)
  store { i64, ptr } %t256, ptr %l101
  br label %bb58
bb58:
  %t257 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t257, ptr %lp11
  %t258 = load { i64, ptr }, ptr %l101, !tbaa !27
  %t259 = load ptr, ptr %lp11
  store { i64, ptr } %t258, ptr %t259, !tbaa !27
  %t260 = load ptr, ptr %lp11
  %t261 = load { i64, ptr }, ptr %t260, !tbaa !27
  %t263 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s12, { i64, ptr } %t261, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d131, i32 0, i32 1) })
  store i1 %t263, ptr %l103
  br label %bb59
bb59:
  %t264 = load i1, ptr %l103, !tbaa !21
  br i1 %t264, label %bb60, label %bb61
bb60:
  call void @__olang_scope_close(ptr %s12)
  br label %bb93
bb61:
  br label %bb62
bb62:
  %t265 = load ptr, ptr %lp1
  %t266 = load ptr, ptr %lp11
  %t267 = load { i64, ptr }, ptr %t266, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t265, { i64, ptr } %t267)
  br label %bb63
bb63:
  %t270 = load ptr, ptr %l0, !tbaa !29
  %t272 = getelementptr %"compiler/target:Target", ptr %t270, i32 0, i32 3
  %t273 = load { i64, ptr }, ptr %t272, !tbaa !27
  %t275 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s12, { i64, ptr } %t273, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d132, i32 0, i32 1) })
  store i1 %t275, ptr %l108
  br label %bb64
bb64:
  %t276 = load i1, ptr %l108, !tbaa !21
  br i1 %t276, label %bb65, label %bb66
bb65:
  %t277 = load ptr, ptr %lp1
  %t279 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %v1, ptr %v1, ptr %t277)
  store { i64, ptr } %t279, ptr %l110
  br label %bb67
bb66:
  br label %bb68
bb67:
  %t280 = load { i64, ptr }, ptr %l110, !tbaa !27
  store { i64, ptr } %t280, ptr %l111, !tbaa !27
  %t281 = load { i64, ptr }, ptr %l111, !tbaa !27
  %t282 = extractvalue { i64, ptr } %t281, 0
  store i64 %t282, ptr %l112, !tbaa !24
  %t283 = load i64, ptr %l112, !tbaa !24
  %t284 = mul i64 %t283, 16
  %t285 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t284)
  %t286 = insertvalue { i64, ptr } undef, i64 %t283, 0
  %t287 = insertvalue { i64, ptr } %t286, ptr %t285, 1
  store { i64, ptr } %t287, ptr %l113, !tbaa !27
  %t288 = getelementptr { i64, ptr }, ptr %l113, i32 0, i32 1
  %t289 = load ptr, ptr %t288, !tbaa !27
  %t290 = getelementptr { i64, ptr }, ptr %l111, i32 0, i32 1
  %t291 = load ptr, ptr %t290, !tbaa !27
  %t292 = load i64, ptr %l112, !tbaa !24
  %t293 = mul i64 %t292, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t289, ptr %t291, i64 %t293, i1 false)
  %t294 = load { i64, ptr }, ptr %l113, !tbaa !27
  store { i64, ptr } %t294, ptr %l111, !tbaa !27
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s0)
  %t295 = load { i64, ptr }, ptr %l111, !tbaa !27
  %t296 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t295, 1
  store { i32, { i64, ptr } } %t296, ptr %rv
  br label %ret
bb68:
  %t297 = call { i64, ptr } @compiler_2ftarget_2eSysroot(ptr %v1)
  store { i64, ptr } %t297, ptr %l114
  br label %bb69
bb69:
  %t298 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t298, ptr %lp12
  %t299 = load { i64, ptr }, ptr %l114, !tbaa !27
  %t300 = load ptr, ptr %lp12
  store { i64, ptr } %t299, ptr %t300, !tbaa !27
  %t301 = load ptr, ptr %lp12
  %t302 = load { i64, ptr }, ptr %t301, !tbaa !27
  %t304 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s12, { i64, ptr } %t302, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d133, i32 0, i32 1) })
  store i1 %t304, ptr %l116
  br label %bb70
bb70:
  %t305 = load i1, ptr %l116, !tbaa !21
  br i1 %t305, label %bb71, label %bb72
bb71:
  %t306 = load ptr, ptr %l0, !tbaa !29
  %t308 = getelementptr %"compiler/target:Target", ptr %t306, i32 0, i32 2
  %t309 = load { i64, ptr }, ptr %t308, !tbaa !27
  %t310 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d134, i32 0, i32 1) }, 1
  %t311 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d134, i32 0, i32 1) }, 0
  %t313 = extractvalue { i64, ptr } %t309, 1
  %t314 = extractvalue { i64, ptr } %t309, 0
  %t315 = add i64 %t311, %t314
  %t316 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d135, i32 0, i32 1) }, 1
  %t317 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d135, i32 0, i32 1) }, 0
  %t318 = add i64 %t315, %t317
  %t319 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t318)
  call void @olang_textcopy(ptr %t319, ptr %t310, i64 %t311)
  %t320 = getelementptr i8, ptr %t319, i64 %t311
  call void @olang_textcopy(ptr %t320, ptr %t313, i64 %t314)
  %t321 = getelementptr i8, ptr %t320, i64 %t314
  call void @olang_textcopy(ptr %t321, ptr %t316, i64 %t317)
  %t322 = insertvalue { i64, ptr } undef, i64 %t318, 0
  %t323 = insertvalue { i64, ptr } %t322, ptr %t319, 1
  %t326 = call i1 @std_2fos_2eIsDir(ptr %s12, { i64, ptr } %t323)
  store i1 %t326, ptr %l122
  br label %bb73
bb72:
  store i1 false, ptr %l117, !tbaa !21
  br label %bb74
bb73:
  %t327 = load i1, ptr %l122, !tbaa !21
  store i1 %t327, ptr %l117, !tbaa !21
  br label %bb74
bb74:
  %t328 = load i1, ptr %l117, !tbaa !21
  br i1 %t328, label %bb75, label %bb76
bb75:
  %t329 = call ptr @__olang_scope_hold(ptr %v1)
  %t330 = ptrtoint ptr %t329 to i64
  store i64 %t330, ptr %l123, !tbaa !24
  %t331 = load i1, ptr @olang_2esole_2ecompiler__2ftarget__2ecompiler__2ftarget__3aTarget__2eRunner_2elocal_2e12
  br i1 %t331, label %bb77, label %bb78
bb76:
  br label %bb85
bb77:
  %t333 = call ptr @__olang_region_make(ptr %v1)
  %t334 = ptrtoint ptr %t333 to i64
  store i64 %t334, ptr %l123, !tbaa !24
  br label %bb78
bb78:
  %t335 = load ptr, ptr %l0, !tbaa !29
  %t337 = getelementptr %"compiler/target:Target", ptr %t335, i32 0, i32 2
  %t338 = load { i64, ptr }, ptr %t337, !tbaa !27
  %t339 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d136, i32 0, i32 1) }, 1
  %t340 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d136, i32 0, i32 1) }, 0
  %t342 = extractvalue { i64, ptr } %t338, 1
  %t343 = extractvalue { i64, ptr } %t338, 0
  %t344 = add i64 %t340, %t343
  %t345 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d137, i32 0, i32 1) }, 1
  %t346 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d137, i32 0, i32 1) }, 0
  %t347 = add i64 %t344, %t346
  %t348 = load i64, ptr %l123
  %t349 = inttoptr i64 %t348 to ptr
  %t350 = call ptr @__olang_held_alloc(ptr %t349, i64 %t347)
  call void @olang_textcopy(ptr %t350, ptr %t339, i64 %t340)
  %t351 = getelementptr i8, ptr %t350, i64 %t340
  call void @olang_textcopy(ptr %t351, ptr %t342, i64 %t343)
  %t352 = getelementptr i8, ptr %t351, i64 %t343
  call void @olang_textcopy(ptr %t352, ptr %t345, i64 %t346)
  %t353 = insertvalue { i64, ptr } undef, i64 %t347, 0
  %t354 = insertvalue { i64, ptr } %t353, ptr %t350, 1
  store { i64, ptr } %t354, ptr %l127, !tbaa !27
  %t355 = load i1, ptr @olang_2esole_2ecompiler__2ftarget__2ecompiler__2ftarget__3aTarget__2eRunner_2elocal_2e12
  br i1 %t355, label %bb79, label %bb80
bb79:
  %t357 = load { i64, ptr }, ptr %l127, !tbaa !27
  %t358 = extractvalue { i64, ptr } %t357, 0
  %t360 = icmp eq i64 %t358, 0
  br i1 %t360, label %bb81, label %bb82
bb80:
  %t362 = load ptr, ptr %lp12
  %t363 = load { i64, ptr }, ptr %t362, !tbaa !27
  store { i64, ptr } %t363, ptr %l131, !tbaa !27
  %t364 = load { i64, ptr }, ptr %l127, !tbaa !27
  %t365 = load ptr, ptr %lp12
  store { i64, ptr } %t364, ptr %t365, !tbaa !27
  %t366 = load i1, ptr @olang_2esole_2ecompiler__2ftarget__2ecompiler__2ftarget__3aTarget__2eRunner_2elocal_2e12
  br i1 %t366, label %bb83, label %bb84
bb81:
  store { i64, ptr } zeroinitializer, ptr %l127, !tbaa !27
  br label %bb82
bb82:
  %t368 = load i64, ptr %l123
  %t369 = inttoptr i64 %t368 to ptr
  %t370 = load { i64, ptr }, ptr %l127
  %t371 = extractvalue { i64, ptr } %t370, 1
  %t372 = call ptr @__olang_region_or(ptr %t371, ptr null)
  %t373 = icmp ne ptr %t372, null
  %t374 = select i1 %t373, ptr %t372, ptr null
  call void @__olang_region_settle_in(ptr %t369, ptr %t374)
  br label %bb80
bb83:
  %t375 = load { i64, ptr }, ptr %l131
  %t376 = extractvalue { i64, ptr } %t375, 1
  call void @__olang_region_release(ptr %t376)
  store { i64, ptr } zeroinitializer, ptr %l131
  br label %bb84
bb84:
  br label %bb85
bb85:
  %t377 = load ptr, ptr %lp12
  %t378 = load { i64, ptr }, ptr %t377, !tbaa !27
  %t380 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s12, { i64, ptr } %t378, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d138, i32 0, i32 1) })
  store i1 %t380, ptr %l134
  br label %bb86
bb86:
  %t381 = load i1, ptr %l134, !tbaa !21
  %t382 = xor i1 %t381, true
  br i1 %t382, label %bb87, label %bb88
bb87:
  %t384 = load ptr, ptr %lp1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t384, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d139, i32 0, i32 1) })
  br label %bb89
bb88:
  br label %bb91
bb89:
  %t386 = load ptr, ptr %lp1
  %t387 = load ptr, ptr %lp12
  %t388 = load { i64, ptr }, ptr %t387, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t386, { i64, ptr } %t388)
  br label %bb90
bb90:
  br label %bb91
bb91:
  %t391 = load ptr, ptr %lp1
  %t393 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %v1, ptr %v1, ptr %t391)
  store { i64, ptr } %t393, ptr %l140
  br label %bb92
bb92:
  %t394 = load { i64, ptr }, ptr %l140, !tbaa !27
  store { i64, ptr } %t394, ptr %l141, !tbaa !27
  %t395 = load { i64, ptr }, ptr %l141, !tbaa !27
  %t396 = extractvalue { i64, ptr } %t395, 0
  store i64 %t396, ptr %l142, !tbaa !24
  %t397 = load i64, ptr %l142, !tbaa !24
  %t398 = mul i64 %t397, 16
  %t399 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t398)
  %t400 = insertvalue { i64, ptr } undef, i64 %t397, 0
  %t401 = insertvalue { i64, ptr } %t400, ptr %t399, 1
  store { i64, ptr } %t401, ptr %l143, !tbaa !27
  %t402 = getelementptr { i64, ptr }, ptr %l143, i32 0, i32 1
  %t403 = load ptr, ptr %t402, !tbaa !27
  %t404 = getelementptr { i64, ptr }, ptr %l141, i32 0, i32 1
  %t405 = load ptr, ptr %t404, !tbaa !27
  %t406 = load i64, ptr %l142, !tbaa !24
  %t407 = mul i64 %t406, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t403, ptr %t405, i64 %t407, i1 false)
  %t408 = load { i64, ptr }, ptr %l143, !tbaa !27
  store { i64, ptr } %t408, ptr %l141, !tbaa !27
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s0)
  %t409 = load { i64, ptr }, ptr %l141, !tbaa !27
  %t410 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t409, 1
  store { i32, { i64, ptr } } %t410, ptr %rv
  br label %ret
bb93:
  %t411 = load i64, ptr %l8, !tbaa !24
  %t414 = add i64 %t411, 1
  store i64 %t414, ptr %l8, !tbaa !24
  br label %bb54
bb94:
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s0)
  %t417 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t417, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local i1 @compiler_2ftarget_2ecompiler_2ftarget_3aTarget_2ewithoutClang(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i64
  %l11 = alloca { i64, ptr }
  %l15 = alloca i1
  %l17 = alloca i1
  %l19 = alloca i1
  %l21 = alloca i1
  %l24 = alloca ptr
  %l25 = alloca { i64, ptr }
  %l30 = alloca i64
  %l32 = alloca i1
  %l34 = alloca i1
  %l36 = alloca i1
  %l38 = alloca i1
  %l40 = alloca i1
  %l42 = alloca i64
  %l46 = alloca ptr
  %l49 = alloca { i64, ptr }
  %l53 = alloca { i64, ptr }
  %l55 = alloca ptr
  %l58 = alloca i64
  %l61 = alloca i64
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  %t2 = call ptr @__olang_scope_hold(ptr %v0)
  %t3 = ptrtoint ptr %t2 to i64
  store i64 %t3, ptr %l5, !tbaa !24
  %t4 = load i1, ptr @olang_2esole_2ecompiler_2ftarget_3aTarget_2e1
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = call ptr @__olang_region_make(ptr %v0)
  %t7 = ptrtoint ptr %t6 to i64
  store i64 %t7, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/target:Target", ptr %t8, i32 0, i32 2
  %t11 = load { i64, ptr }, ptr %t10, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t11, 1
  %t14 = extractvalue { i64, ptr } %t11, 0
  %t15 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d140, i32 0, i32 1) }, 1
  %t16 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d140, i32 0, i32 1) }, 0
  %t17 = add i64 %t14, %t16
  %t18 = load i64, ptr %l5
  %t19 = inttoptr i64 %t18 to ptr
  %t20 = call ptr @__olang_held_alloc(ptr %t19, i64 %t17)
  call void @olang_textcopy(ptr %t20, ptr %t13, i64 %t14)
  %t21 = getelementptr i8, ptr %t20, i64 %t14
  call void @olang_textcopy(ptr %t21, ptr %t15, i64 %t16)
  %t22 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t20, 1
  %t25 = load ptr, ptr %l4, !tbaa !29
  %t26 = getelementptr %"compiler/target:Target", ptr %t25, i32 0, i32 1
  %t27 = load { i64, ptr }, ptr %t26, !tbaa !27
  store { i64, ptr } %t27, ptr %l11, !tbaa !27
  %t29 = load ptr, ptr %l4, !tbaa !29
  %t30 = getelementptr %"compiler/target:Target", ptr %t29, i32 0, i32 1
  store { i64, ptr } %t23, ptr %t30, !tbaa !27
  %t31 = load i1, ptr @olang_2esole_2ecompiler_2ftarget_3aTarget_2e1
  br i1 %t31, label %bb3, label %bb4
bb3:
  %t33 = load { i64, ptr }, ptr %l11
  %t34 = extractvalue { i64, ptr } %t33, 1
  call void @__olang_region_release(ptr %t34)
  store { i64, ptr } zeroinitializer, ptr %l11
  br label %bb4
bb4:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/target:Target", ptr %t35, i32 0, i32 2
  %t38 = load { i64, ptr }, ptr %t37, !tbaa !27
  %t40 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t38, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d141, i32 0, i32 1) })
  store i1 %t40, ptr %l15
  br label %bb5
bb5:
  %t41 = load i1, ptr %l15, !tbaa !21
  br i1 %t41, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s2
  %t42 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t44 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s2, { i64, ptr } %t42, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d142, i32 0, i32 1) })
  store i1 %t44, ptr %l17
  br label %bb8
bb7:
  br label %bb18
bb8:
  %t45 = load i1, ptr %l17, !tbaa !21
  %t46 = xor i1 %t45, true
  br i1 %t46, label %bb9, label %bb10
bb9:
  %t48 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t50 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s2, { i64, ptr } %t48, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d143, i32 0, i32 1) })
  store i1 %t50, ptr %l21
  br label %bb11
bb10:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb12
bb11:
  %t51 = load i1, ptr %l21, !tbaa !21
  %t52 = xor i1 %t51, true
  store i1 %t52, ptr %l19, !tbaa !21
  br label %bb12
bb12:
  %t54 = load i1, ptr %l19, !tbaa !21
  br i1 %t54, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t56 = load ptr, ptr %l0, !tbaa !29
  store ptr %t56, ptr %l24, !tbaa !29
  %t57 = load ptr, ptr %l24, !tbaa !29
  %t58 = getelementptr %"compiler/target:Target", ptr %t57, i32 0, i32 4
  %t59 = load { i64, ptr }, ptr %t58, !tbaa !27
  store { i64, ptr } %t59, ptr %l25, !tbaa !27
  %t60 = load ptr, ptr %l24, !tbaa !29
  %t61 = getelementptr %"compiler/target:Target", ptr %t60, i32 0, i32 4
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d144, i32 0, i32 1) }, ptr %t61, !tbaa !27
  %t62 = load i1, ptr @olang_2esole_2ecompiler_2ftarget_3aTarget_2e4
  br i1 %t62, label %bb16, label %bb17
bb16:
  %t64 = load { i64, ptr }, ptr %l25
  %t65 = extractvalue { i64, ptr } %t64, 1
  call void @__olang_region_release(ptr %t65)
  store { i64, ptr } zeroinitializer, ptr %l25
  br label %bb17
bb17:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/target:Target", ptr %t66, i32 0, i32 7
  store i64 128, ptr %t68, !tbaa !24
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/target:Target", ptr %t69, i32 0, i32 8
  store i1 true, ptr %t71, !tbaa !21
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb18:
  %t73 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t75 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t73, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d145, i32 0, i32 1) })
  store i1 %t75, ptr %l32
  br label %bb19
bb19:
  %t76 = load i1, ptr %l32, !tbaa !21
  br i1 %t76, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb23
bb22:
  store i64 1, ptr %l30, !tbaa !24
  br label %bb49
bb23:
  %t77 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t79 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t77, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d146, i32 0, i32 1) })
  store i1 %t79, ptr %l34
  br label %bb24
bb24:
  %t80 = load i1, ptr %l34, !tbaa !21
  br i1 %t80, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  store i64 2, ptr %l30, !tbaa !24
  br label %bb49
bb28:
  %t81 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t83 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t81, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d147, i32 0, i32 1) })
  store i1 %t83, ptr %l36
  br label %bb29
bb29:
  %t84 = load i1, ptr %l36, !tbaa !21
  br i1 %t84, label %bb30, label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb33
bb32:
  store i64 3, ptr %l30, !tbaa !24
  br label %bb49
bb33:
  %t85 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t87 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t85, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d148, i32 0, i32 1) })
  store i1 %t87, ptr %l38
  br label %bb34
bb34:
  %t88 = load i1, ptr %l38, !tbaa !21
  br i1 %t88, label %bb35, label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb38
bb37:
  store i64 4, ptr %l30, !tbaa !24
  br label %bb49
bb38:
  %t89 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t91 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t89, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d149, i32 0, i32 1) })
  store i1 %t91, ptr %l40
  br label %bb39
bb39:
  %t92 = load i1, ptr %l40, !tbaa !21
  br i1 %t92, label %bb40, label %bb41
bb40:
  br label %bb42
bb41:
  br label %bb44
bb42:
  %t95 = call i64 @compiler_2ftarget_2eX86Level(ptr %v2, { i64, ptr } %a2)
  store i64 %t95, ptr %l42
  br label %bb43
bb43:
  %t96 = load i64, ptr %l42, !tbaa !24
  store i64 %t96, ptr %l30, !tbaa !24
  br label %bb49
bb44:
  br i1 true, label %bb45, label %bb46
bb45:
  br label %bb47
bb46:
  br label %bb48
bb47:
  store i64 0, ptr %l30, !tbaa !24
  br label %bb49
bb48:
  call void @__olang_check_failed(ptr @olang_loc_85332b5eb98b88c2_ab57175d397d1606)
  unreachable
bb49:
  %t97 = load i64, ptr %l30, !tbaa !24
  store i64 %t97, ptr %l3, !tbaa !24
  %t98 = load i64, ptr %l3, !tbaa !24
  %t100 = icmp eq i64 %t98, 0
  br i1 %t100, label %bb50, label %bb51
bb50:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb51:
  br label %bb52
bb52:
  %t103 = load ptr, ptr %l0, !tbaa !29
  store ptr %t103, ptr %l46, !tbaa !29
  %t104 = load i64, ptr %l3, !tbaa !24
  %t106 = icmp eq i64 %t104, 1
  br i1 %t106, label %bb53, label %bb54
bb53:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d150, i32 0, i32 1) }, ptr %l49, !tbaa !27
  br label %bb55
bb54:
  %t108 = load i64, ptr %l3, !tbaa !24
  %t109 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d151, i32 0, i32 1) }, 1
  %t110 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d151, i32 0, i32 1) }, 0
  %t112 = call i64 @__olang_fmt_i64(ptr null, i64 %t108)
  %t113 = add i64 %t110, %t112
  %t114 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t113)
  call void @olang_textcopy(ptr %t114, ptr %t109, i64 %t110)
  %t115 = getelementptr i8, ptr %t114, i64 %t110
  %t116 = call i64 @__olang_fmt_i64(ptr %t115, i64 %t108)
  %t117 = insertvalue { i64, ptr } undef, i64 %t113, 0
  %t118 = insertvalue { i64, ptr } %t117, ptr %t114, 1
  store { i64, ptr } %t118, ptr %l49, !tbaa !27
  br label %bb55
bb55:
  %t121 = load ptr, ptr %l46, !tbaa !29
  %t122 = getelementptr %"compiler/target:Target", ptr %t121, i32 0, i32 4
  %t123 = load { i64, ptr }, ptr %t122, !tbaa !27
  store { i64, ptr } %t123, ptr %l53, !tbaa !27
  %t124 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t125 = load ptr, ptr %l46, !tbaa !29
  %t126 = getelementptr %"compiler/target:Target", ptr %t125, i32 0, i32 4
  store { i64, ptr } %t124, ptr %t126, !tbaa !27
  %t127 = load i1, ptr @olang_2esole_2ecompiler_2ftarget_3aTarget_2e4
  br i1 %t127, label %bb56, label %bb57
bb56:
  %t129 = load { i64, ptr }, ptr %l53
  %t130 = extractvalue { i64, ptr } %t129, 1
  call void @__olang_region_release(ptr %t130)
  store { i64, ptr } zeroinitializer, ptr %l53
  br label %bb57
bb57:
  %t131 = load ptr, ptr %l0, !tbaa !29
  store ptr %t131, ptr %l55, !tbaa !29
  %t132 = load i64, ptr %l3, !tbaa !24
  %t134 = icmp eq i64 %t132, 4
  br i1 %t134, label %bb58, label %bb59
bb58:
  store i64 512, ptr %l58, !tbaa !24
  br label %bb63
bb59:
  %t136 = load i64, ptr %l3, !tbaa !24
  %t138 = icmp eq i64 %t136, 3
  br i1 %t138, label %bb60, label %bb61
bb60:
  store i64 256, ptr %l61, !tbaa !24
  br label %bb62
bb61:
  store i64 128, ptr %l61, !tbaa !24
  br label %bb62
bb62:
  %t140 = load i64, ptr %l61, !tbaa !24
  store i64 %t140, ptr %l58, !tbaa !24
  br label %bb63
bb63:
  %t141 = load i64, ptr %l58, !tbaa !24
  %t142 = load ptr, ptr %l55, !tbaa !29
  %t143 = getelementptr %"compiler/target:Target", ptr %t142, i32 0, i32 7
  store i64 %t141, ptr %t143, !tbaa !24
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t145 = load i64, ptr %l3, !tbaa !24
  %t147 = icmp sge i64 %t145, 3
  %t150 = getelementptr %"compiler/target:Target", ptr %t144, i32 0, i32 8
  store i1 %t147, ptr %t150, !tbaa !21
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2ftarget_2ecpuFlags(ptr %v0) #0 {
entry:
  %l1 = alloca %"std/prelude/text:LineIter"
  %l2 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i32
  %l8 = alloca i1
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca { i64, ptr }
  %l16 = alloca %"std/prelude/text:LineIter"
  %l17 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca i32
  %l22 = alloca i1
  %l24 = alloca i1
  %l25 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i32
  %l30 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l32 = alloca i64
  %l33 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l36 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l45 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l49 = alloca i64
  %l50 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %s0, ptr %s0, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d152, i32 0, i32 1) })
  %t2 = extractvalue { i32, { i64, ptr } } %t1, 1
  %t3 = extractvalue { i32, { i64, ptr } } %t1, 0
  store i32 %t3, ptr %l6
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5, !prof !99
ok.5:
  store { i64, ptr } %t2, ptr %l5
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t6, ptr %l4, !tbaa !27
  br label %bb6
bb2:
  %t7 = load i32, ptr %l6, !tbaa !23
  %t8 = ashr i32 %t7, 16
  %t10 = icmp eq i32 %t8, 1
  store i1 %t10, ptr %l8, !tbaa !21
  %t11 = load i32, ptr %l6, !tbaa !23
  %t12 = ashr i32 %t11, 16
  %t14 = icmp eq i32 %t12, 1
  br i1 %t14, label %bb3, label %bb4
bb3:
  call void @__olang_errpay_pop()
  br label %bb4
bb4:
  br label %bb5
bb5:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d153, i32 0, i32 1) }, ptr %l11, !tbaa !27
  %t16 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t16, ptr %l12, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t17, 0
  store i64 %t18, ptr %l13, !tbaa !24
  %t19 = load i64, ptr %l13, !tbaa !24
  %t20 = mul i64 %t19, 1
  %t21 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t20)
  %t22 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t21, 1
  store { i64, ptr } %t23, ptr %l14, !tbaa !27
  %t24 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = load i64, ptr %l13, !tbaa !24
  %t29 = mul i64 %t28, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t25, ptr %t27, i64 %t29, i1 false)
  %t30 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t30, ptr %l12, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t31 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t31, ptr %rv
  br label %ret
bb6:
  %t32 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t35 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %s0, ptr %s0, { i64, ptr } %t32)
  store %"std/prelude/text:LineIter" %t35, ptr %l16
  br label %bb7
bb7:
  %t36 = load %"std/prelude/text:LineIter", ptr %l16
  store %"std/prelude/text:LineIter" %t36, ptr %l1
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t38 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %s0, ptr %s0, ptr %l1)
  %t39 = extractvalue { i32, { i64, ptr } } %t38, 1
  %t40 = extractvalue { i32, { i64, ptr } } %t38, 0
  store i32 %t40, ptr %l20
  %t41 = icmp ne i32 %t40, 0
  br i1 %t41, label %bb10, label %ok.42, !prof !99
ok.42:
  store { i64, ptr } %t39, ptr %l19
  br label %bb9
bb9:
  %t43 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t43, ptr %l17, !tbaa !27
  br label %bb12
bb10:
  %t44 = load i32, ptr %l20, !tbaa !23
  %t45 = ashr i32 %t44, 16
  %t47 = icmp eq i32 %t45, 1
  store i1 %t47, ptr %l22, !tbaa !21
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s3)
  br label %bb29
bb12:
  %t48 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t48, ptr %l2, !tbaa !27
  %t49 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t51 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s3, { i64, ptr } %t49, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d154, i32 0, i32 1) })
  store i1 %t51, ptr %l24
  br label %bb13
bb13:
  %t52 = load i1, ptr %l24, !tbaa !21
  br i1 %t52, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s4
  %t53 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t56 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %s0, { i64, ptr } %t53, i8 58)
  %t57 = extractvalue { i32, i64 } %t56, 1
  %t58 = extractvalue { i32, i64 } %t56, 0
  store i32 %t58, ptr %l29
  %t59 = icmp ne i32 %t58, 0
  br i1 %t59, label %bb17, label %ok.60, !prof !99
ok.60:
  store i64 %t57, ptr %l28
  br label %bb16
bb15:
  br label %bb27
bb16:
  %t61 = load i64, ptr %l28, !tbaa !24
  store i64 %t61, ptr %l25, !tbaa !24
  br label %bb19
bb17:
  br label %bb18
bb18:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d155, i32 0, i32 1) }, ptr %l30, !tbaa !27
  %t62 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t62, ptr %l31, !tbaa !27
  %t63 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t64 = extractvalue { i64, ptr } %t63, 0
  store i64 %t64, ptr %l32, !tbaa !24
  %t65 = load i64, ptr %l32, !tbaa !24
  %t66 = mul i64 %t65, 1
  %t67 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t66)
  %t68 = insertvalue { i64, ptr } undef, i64 %t65, 0
  %t69 = insertvalue { i64, ptr } %t68, ptr %t67, 1
  store { i64, ptr } %t69, ptr %l33, !tbaa !27
  %t70 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !27
  %t72 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = load i64, ptr %l32, !tbaa !24
  %t75 = mul i64 %t74, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t71, ptr %t73, i64 %t75, i1 false)
  %t76 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t76, ptr %l31, !tbaa !27
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t77 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t77, ptr %rv
  br label %ret
bb19:
  %t78 = load i64, ptr %l25, !tbaa !24
  %t79 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t79, ptr %l34, !tbaa !27
  %t82 = add i64 %t78, 1
  store i64 %t82, ptr %l36, !tbaa !24
  %t83 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t83, 0
  store i64 %t86, ptr %l39, !tbaa !24
  %t87 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t88 = extractvalue { i64, ptr } %t87, 0
  store i64 %t88, ptr %l40, !tbaa !24
  %t89 = load i64, ptr %l36, !tbaa !24
  %t90 = icmp sge i64 %t89, 0
  br i1 %t90, label %bb20, label %bb21
bb20:
  %t92 = load i64, ptr %l36, !tbaa !24
  %t93 = load i64, ptr %l39, !tbaa !24
  %t94 = icmp sle i64 %t92, %t93
  br i1 %t94, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_85ddc375a30bdeb4_680b0f1997dc0f98)
  unreachable
bb22:
  %t96 = load i64, ptr %l39, !tbaa !24
  %t97 = load i64, ptr %l40, !tbaa !24
  %t98 = icmp sle i64 %t96, %t97
  br i1 %t98, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_85ddc375a30bdeb4_680b0f1997dc0f98)
  unreachable
bb24:
  %t100 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !27
  %t102 = load i64, ptr %l36, !tbaa !24
  %t103 = load i64, ptr %l39, !tbaa !24
  %t104 = getelementptr i8, ptr %t101, i64 %t102
  %t105 = sub i64 %t103, %t102
  %t106 = insertvalue { i64, ptr } undef, i64 %t105, 0
  %t107 = insertvalue { i64, ptr } %t106, ptr %t104, 1
  %t109 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %s0, ptr %s4, { i64, ptr } %t107)
  store { i64, ptr } %t109, ptr %l45
  br label %bb26
bb25:
  call void @__olang_check_failed(ptr @olang_loc_85ddc375a30bdeb4_680b0f1997dc0f98)
  unreachable
bb26:
  %t110 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d156, i32 0, i32 1) }, 1
  %t111 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d156, i32 0, i32 1) }, 0
  %t112 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t113 = extractvalue { i64, ptr } %t112, 1
  %t114 = extractvalue { i64, ptr } %t112, 0
  %t115 = add i64 %t111, %t114
  %t116 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d157, i32 0, i32 1) }, 1
  %t117 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d157, i32 0, i32 1) }, 0
  %t118 = add i64 %t115, %t117
  %t119 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t118)
  call void @olang_textcopy(ptr %t119, ptr %t110, i64 %t111)
  %t120 = getelementptr i8, ptr %t119, i64 %t111
  call void @olang_textcopy(ptr %t120, ptr %t113, i64 %t114)
  %t121 = getelementptr i8, ptr %t120, i64 %t114
  call void @olang_textcopy(ptr %t121, ptr %t116, i64 %t117)
  %t122 = insertvalue { i64, ptr } undef, i64 %t118, 0
  %t123 = insertvalue { i64, ptr } %t122, ptr %t119, 1
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t123, ptr %rv
  br label %ret
bb27:
  call void @__olang_scope_close(ptr %s3)
  br label %bb28
bb28:
  br label %bb8
bb29:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d158, i32 0, i32 1) }, ptr %l47, !tbaa !27
  %t125 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t125, ptr %l48, !tbaa !27
  %t126 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t127 = extractvalue { i64, ptr } %t126, 0
  store i64 %t127, ptr %l49, !tbaa !24
  %t128 = load i64, ptr %l49, !tbaa !24
  %t129 = mul i64 %t128, 1
  %t130 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t129)
  %t131 = insertvalue { i64, ptr } undef, i64 %t128, 0
  %t132 = insertvalue { i64, ptr } %t131, ptr %t130, 1
  store { i64, ptr } %t132, ptr %l50, !tbaa !27
  %t133 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t134 = load ptr, ptr %t133, !tbaa !27
  %t135 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t136 = load ptr, ptr %t135, !tbaa !27
  %t137 = load i64, ptr %l49, !tbaa !24
  %t138 = mul i64 %t137, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t134, ptr %t136, i64 %t138, i1 false)
  %t139 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t139, ptr %l48, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t140 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t140, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2ftarget_2ecpuModel(ptr %v0) #0 {
entry:
  %l1 = alloca %"std/prelude/text:LineIter"
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i32
  %l7 = alloca i1
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l15 = alloca %"std/prelude/text:LineIter"
  %l16 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca i32
  %l21 = alloca i1
  %l23 = alloca i1
  %l26 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l28 = alloca i64
  %l29 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %s0, ptr %s0, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d159, i32 0, i32 1) })
  %t2 = extractvalue { i32, { i64, ptr } } %t1, 1
  %t3 = extractvalue { i32, { i64, ptr } } %t1, 0
  store i32 %t3, ptr %l5
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5, !prof !99
ok.5:
  store { i64, ptr } %t2, ptr %l4
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t6, ptr %l3, !tbaa !27
  br label %bb6
bb2:
  %t7 = load i32, ptr %l5, !tbaa !23
  %t8 = ashr i32 %t7, 16
  %t10 = icmp eq i32 %t8, 1
  store i1 %t10, ptr %l7, !tbaa !21
  %t11 = load i32, ptr %l5, !tbaa !23
  %t12 = ashr i32 %t11, 16
  %t14 = icmp eq i32 %t12, 1
  br i1 %t14, label %bb3, label %bb4
bb3:
  call void @__olang_errpay_pop()
  br label %bb4
bb4:
  br label %bb5
bb5:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d160, i32 0, i32 1) }, ptr %l10, !tbaa !27
  %t16 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t16, ptr %l11, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t17, 0
  store i64 %t18, ptr %l12, !tbaa !24
  %t19 = load i64, ptr %l12, !tbaa !24
  %t20 = mul i64 %t19, 1
  %t21 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t20)
  %t22 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t21, 1
  store { i64, ptr } %t23, ptr %l13, !tbaa !27
  %t24 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = load i64, ptr %l12, !tbaa !24
  %t29 = mul i64 %t28, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t25, ptr %t27, i64 %t29, i1 false)
  %t30 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t30, ptr %l11, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t31 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t31, ptr %rv
  br label %ret
bb6:
  %t32 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t35 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %s0, ptr %s0, { i64, ptr } %t32)
  store %"std/prelude/text:LineIter" %t35, ptr %l15
  br label %bb7
bb7:
  %t36 = load %"std/prelude/text:LineIter", ptr %l15
  store %"std/prelude/text:LineIter" %t36, ptr %l1
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t38 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %s0, ptr %s0, ptr %l1)
  %t39 = extractvalue { i32, { i64, ptr } } %t38, 1
  %t40 = extractvalue { i32, { i64, ptr } } %t38, 0
  store i32 %t40, ptr %l19
  %t41 = icmp ne i32 %t40, 0
  br i1 %t41, label %bb10, label %ok.42, !prof !99
ok.42:
  store { i64, ptr } %t39, ptr %l18
  br label %bb9
bb9:
  %t43 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t43, ptr %l16, !tbaa !27
  br label %bb12
bb10:
  %t44 = load i32, ptr %l19, !tbaa !23
  %t45 = ashr i32 %t44, 16
  %t47 = icmp eq i32 %t45, 1
  store i1 %t47, ptr %l21, !tbaa !21
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s3)
  br label %bb18
bb12:
  %t48 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t48, ptr %l2, !tbaa !27
  %t49 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t51 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s3, { i64, ptr } %t49, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d161, i32 0, i32 1) })
  store i1 %t51, ptr %l23
  br label %bb13
bb13:
  %t52 = load i1, ptr %l23, !tbaa !21
  br i1 %t52, label %bb14, label %bb15
bb14:
  %t53 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t55 = extractvalue { i64, ptr } %t53, 1
  %t56 = extractvalue { i64, ptr } %t53, 0
  %t57 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t56)
  call void @olang_textcopy(ptr %t57, ptr %t55, i64 %t56)
  %t58 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t59 = insertvalue { i64, ptr } %t58, ptr %t57, 1
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t59, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s3)
  br label %bb17
bb17:
  br label %bb8
bb18:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d162, i32 0, i32 1) }, ptr %l26, !tbaa !27
  %t61 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t61, ptr %l27, !tbaa !27
  %t62 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t63 = extractvalue { i64, ptr } %t62, 0
  store i64 %t63, ptr %l28, !tbaa !24
  %t64 = load i64, ptr %l28, !tbaa !24
  %t65 = mul i64 %t64, 1
  %t66 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t65)
  %t67 = insertvalue { i64, ptr } undef, i64 %t64, 0
  %t68 = insertvalue { i64, ptr } %t67, ptr %t66, 1
  store { i64, ptr } %t68, ptr %l29, !tbaa !27
  %t69 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !27
  %t71 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !27
  %t73 = load i64, ptr %l28, !tbaa !24
  %t74 = mul i64 %t73, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t70, ptr %t72, i64 %t74, i1 false)
  %t75 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t75, ptr %l27, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t76 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t76, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2ftarget_2efield(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l3 = alloca i64
  %l5 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i32
  %l15 = alloca i64
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i32
  %l30 = alloca { i64, ptr }
  %l31 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %rv = alloca { i32, { i64, ptr } }
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t5 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v1, { i64, ptr } %t1, { i64, ptr } %t2)
  %t6 = extractvalue { i32, i64 } %t5, 1
  %t7 = extractvalue { i32, i64 } %t5, 0
  store i32 %t7, ptr %l9
  %t8 = icmp ne i32 %t7, 0
  br i1 %t8, label %bb2, label %ok.9, !prof !99
ok.9:
  store i64 %t6, ptr %l8
  br label %bb1
bb1:
  %t10 = load i64, ptr %l8, !tbaa !24
  store i64 %t10, ptr %l5, !tbaa !24
  br label %bb3
bb2:
  %t11 = load i32, ptr %l9, !tbaa !23
  %t12 = lshr i32 %t11, 16
  %t13 = and i32 %t11, 65535
  %t14 = icmp eq i32 %t12, 1
  %t15 = select i1 %t14, i32 1, i32 0
  %t16 = icmp eq i32 %t11, 0
  %t17 = shl i32 %t15, 16
  %t18 = or i32 %t17, %t13
  %t19 = select i1 %t16, i32 0, i32 %t18
  %t21 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t19, 0
  store { i32, { i64, ptr } } %t21, ptr %rv
  br label %ret
bb3:
  %t22 = load i64, ptr %l5, !tbaa !24
  %t24 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t29 = add i64 %t22, %t26
  store i64 %t29, ptr %l3, !tbaa !24
  %t31 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t31, ptr %l16, !tbaa !27
  %t32 = load i64, ptr %l3, !tbaa !24
  store i64 %t32, ptr %l17, !tbaa !24
  %t33 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t36 = extractvalue { i64, ptr } %t33, 0
  store i64 %t36, ptr %l20, !tbaa !24
  %t37 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t37, 0
  store i64 %t38, ptr %l21, !tbaa !24
  %t39 = load i64, ptr %l17, !tbaa !24
  %t40 = icmp sge i64 %t39, 0
  br i1 %t40, label %bb4, label %bb5
bb4:
  %t42 = load i64, ptr %l17, !tbaa !24
  %t43 = load i64, ptr %l20, !tbaa !24
  %t44 = icmp sle i64 %t42, %t43
  br i1 %t44, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_1252e266118faa7_9a8543fc9009ce13)
  unreachable
bb6:
  %t46 = load i64, ptr %l20, !tbaa !24
  %t47 = load i64, ptr %l21, !tbaa !24
  %t48 = icmp sle i64 %t46, %t47
  br i1 %t48, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_1252e266118faa7_9a8543fc9009ce13)
  unreachable
bb8:
  %t50 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !27
  %t52 = load i64, ptr %l17, !tbaa !24
  %t53 = load i64, ptr %l20, !tbaa !24
  %t54 = getelementptr i8, ptr %t51, i64 %t52
  %t55 = sub i64 %t53, %t52
  %t56 = insertvalue { i64, ptr } undef, i64 %t55, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t54, 1
  %t60 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %v0, { i64, ptr } %t57, i8 34)
  %t61 = extractvalue { i32, i64 } %t60, 1
  %t62 = extractvalue { i32, i64 } %t60, 0
  store i32 %t62, ptr %l28
  %t63 = icmp ne i32 %t62, 0
  br i1 %t63, label %bb11, label %ok.64, !prof !99
ok.64:
  store i64 %t61, ptr %l27
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_1252e266118faa7_9a8543fc9009ce13)
  unreachable
bb10:
  %t65 = load i64, ptr %l27, !tbaa !24
  store i64 %t65, ptr %l15, !tbaa !24
  br label %bb12
bb11:
  %t66 = load i32, ptr %l28, !tbaa !23
  %t67 = lshr i32 %t66, 16
  %t68 = and i32 %t66, 65535
  %t69 = icmp eq i32 %t67, 1
  %t70 = select i1 %t69, i32 1, i32 0
  %t71 = icmp eq i32 %t66, 0
  %t72 = shl i32 %t70, 16
  %t73 = or i32 %t72, %t68
  %t74 = select i1 %t71, i32 0, i32 %t73
  %t76 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t74, 0
  store { i32, { i64, ptr } } %t76, ptr %rv
  br label %ret
bb12:
  %t77 = load i64, ptr %l15, !tbaa !24
  %t78 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t78, ptr %l30, !tbaa !27
  %t79 = load i64, ptr %l3, !tbaa !24
  store i64 %t79, ptr %l31, !tbaa !24
  %t80 = load i64, ptr %l3, !tbaa !24
  %t84 = add i64 %t80, %t77
  store i64 %t84, ptr %l34, !tbaa !24
  %t85 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t85, 0
  store i64 %t86, ptr %l35, !tbaa !24
  %t87 = load i64, ptr %l31, !tbaa !24
  %t88 = icmp sge i64 %t87, 0
  br i1 %t88, label %bb13, label %bb14
bb13:
  %t90 = load i64, ptr %l31, !tbaa !24
  %t91 = load i64, ptr %l34, !tbaa !24
  %t92 = icmp sle i64 %t90, %t91
  br i1 %t92, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_50955429569277ca_9a744de1378669b6)
  unreachable
bb15:
  %t94 = load i64, ptr %l34, !tbaa !24
  %t95 = load i64, ptr %l35, !tbaa !24
  %t96 = icmp sle i64 %t94, %t95
  br i1 %t96, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_50955429569277ca_9a744de1378669b6)
  unreachable
bb17:
  %t98 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !27
  %t100 = load i64, ptr %l31, !tbaa !24
  %t101 = load i64, ptr %l34, !tbaa !24
  %t102 = getelementptr i8, ptr %t99, i64 %t100
  %t103 = sub i64 %t101, %t100
  %t104 = insertvalue { i64, ptr } undef, i64 %t103, 0
  %t105 = insertvalue { i64, ptr } %t104, ptr %t102, 1
  %t107 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t105, 1
  store { i32, { i64, ptr } } %t107, ptr %rv
  br label %ret
bb18:
  call void @__olang_check_failed(ptr @olang_loc_50955429569277ca_9a744de1378669b6)
  unreachable
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i64, ptr } @compiler_2ftarget_2eprobeDir(ptr %v0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i32
  %l8 = alloca i1
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %s0, ptr %s0, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d163, i32 0, i32 1) })
  %t2 = extractvalue { i32, { i64, ptr } } %t1, 1
  %t3 = extractvalue { i32, { i64, ptr } } %t1, 0
  store i32 %t3, ptr %l4
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5, !prof !99
ok.5:
  store { i64, ptr } %t2, ptr %l3
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t6, ptr %l2, !tbaa !27
  br label %bb6
bb2:
  %t7 = load i32, ptr %l4, !tbaa !23
  %t8 = ashr i32 %t7, 16
  %t10 = icmp eq i32 %t8, 1
  br i1 %t10, label %bb3, label %bb4
bb3:
  call void @__olang_errpay_pop()
  br label %bb4
bb4:
  br label %bb5
bb5:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d164, i32 0, i32 1) }, ptr %l2, !tbaa !27
  br label %bb6
bb6:
  %t12 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t12, ptr %l0, !tbaa !27
  %t13 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t15 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t13, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d165, i32 0, i32 1) })
  store i1 %t15, ptr %l8
  br label %bb7
bb7:
  %t16 = load i1, ptr %l8, !tbaa !21
  %t17 = xor i1 %t16, true
  br i1 %t17, label %bb8, label %bb9
bb8:
  %t19 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t19, 1
  %t22 = extractvalue { i64, ptr } %t19, 0
  %t23 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d166, i32 0, i32 1) }, 1
  %t24 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d166, i32 0, i32 1) }, 0
  %t25 = add i64 %t22, %t24
  %t26 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t25)
  call void @olang_textcopy(ptr %t26, ptr %t21, i64 %t22)
  %t27 = getelementptr i8, ptr %t26, i64 %t22
  call void @olang_textcopy(ptr %t27, ptr %t23, i64 %t24)
  %t28 = insertvalue { i64, ptr } undef, i64 %t25, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t26, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t29, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t31 = call { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %s0, ptr %s0, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d167, i32 0, i32 1) })
  %t32 = extractvalue { i32, { i64, ptr } } %t31, 1
  %t33 = extractvalue { i32, { i64, ptr } } %t31, 0
  store i32 %t33, ptr %l14
  %t34 = icmp ne i32 %t33, 0
  br i1 %t34, label %bb12, label %ok.35, !prof !99
ok.35:
  store { i64, ptr } %t32, ptr %l13
  br label %bb11
bb11:
  %t36 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t36, ptr %l12, !tbaa !27
  br label %bb16
bb12:
  %t37 = load i32, ptr %l14, !tbaa !23
  %t38 = ashr i32 %t37, 16
  %t40 = icmp eq i32 %t38, 1
  br i1 %t40, label %bb13, label %bb14
bb13:
  call void @__olang_errpay_pop()
  br label %bb14
bb14:
  br label %bb15
bb15:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d168, i32 0, i32 1) }, ptr %l12, !tbaa !27
  br label %bb16
bb16:
  %t42 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t42, 1
  %t46 = extractvalue { i64, ptr } %t42, 0
  %t47 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d169, i32 0, i32 1) }, 1
  %t48 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d169, i32 0, i32 1) }, 0
  %t49 = add i64 %t46, %t48
  %t50 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t49)
  call void @olang_textcopy(ptr %t50, ptr %t45, i64 %t46)
  %t51 = getelementptr i8, ptr %t50, i64 %t46
  call void @olang_textcopy(ptr %t51, ptr %t47, i64 %t48)
  %t52 = insertvalue { i64, ptr } undef, i64 %t49, 0
  %t53 = insertvalue { i64, ptr } %t52, ptr %t50, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t53, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2ftarget_2eprobeKey(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca %"std/os:FileInfo"
  %l5 = alloca %"std/prelude/text:StringBuilder"
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l21 = alloca i1
  %l22 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l29 = alloca i32
  %l32 = alloca %"std/os:FileInfo"
  %l34 = alloca %"std/os:FileInfo"
  %l35 = alloca i32
  %l37 = alloca i1
  %l40 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l42 = alloca i64
  %l43 = alloca { i64, ptr }
  %l44 = alloca %"std/prelude/text:StringBuilder"
  %l51 = alloca { i64, ptr }
  %l54 = alloca i64
  %l55 = alloca i64
  %l66 = alloca { i64, ptr }
  %l76 = alloca ptr
  %l78 = alloca i64
  %l79 = alloca { i64, ptr }
  %l80 = alloca { i64, ptr }
  %l81 = alloca { i64, ptr }
  %l85 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d170, i32 0, i32 1) }, ptr %l13, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t7, ptr %l14, !tbaa !27
  %t8 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t8, 0
  store i64 %t9, ptr %l15, !tbaa !24
  %t10 = load i64, ptr %l15, !tbaa !24
  %t11 = mul i64 %t10, 1
  %t12 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t11)
  %t13 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l16, !tbaa !27
  %t15 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !27
  %t17 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !27
  %t19 = load i64, ptr %l15, !tbaa !24
  %t20 = mul i64 %t19, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t16, ptr %t18, i64 %t20, i1 false)
  %t21 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t21, ptr %l14, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t22 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t22, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t23 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t23, ptr %l17, !tbaa !27
  %t24 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr { i64, ptr }, ptr %t25, i64 0
  %t27 = load { i64, ptr }, ptr %t26, !tbaa !37
  %t29 = call { i64, ptr } @compiler_2ftarget_2ewhereIs(ptr %v0, ptr %s0, { i64, ptr } %t27)
  store { i64, ptr } %t29, ptr %l19
  br label %bb4
bb4:
  %t30 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t30, ptr %l2, !tbaa !27
  %t31 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t33 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t31, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d171, i32 0, i32 1) })
  store i1 %t33, ptr %l21
  br label %bb5
bb5:
  %t34 = load i1, ptr %l21, !tbaa !21
  br i1 %t34, label %bb6, label %bb7
bb6:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d172, i32 0, i32 1) }, ptr %l22, !tbaa !27
  %t35 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t35, ptr %l23, !tbaa !27
  %t36 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t36, 0
  store i64 %t37, ptr %l24, !tbaa !24
  %t38 = load i64, ptr %l24, !tbaa !24
  %t39 = mul i64 %t38, 1
  %t40 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t39)
  %t41 = insertvalue { i64, ptr } undef, i64 %t38, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t40, 1
  store { i64, ptr } %t42, ptr %l25, !tbaa !27
  %t43 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !27
  %t45 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !27
  %t47 = load i64, ptr %l24, !tbaa !24
  %t48 = mul i64 %t47, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t44, ptr %t46, i64 %t48, i1 false)
  %t49 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t49, ptr %l23, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t50 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t50, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t51 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t53 = call { i32, { i64, ptr } } @std_2fos_2eRealPath(ptr %s0, ptr %s0, { i64, ptr } %t51)
  %t54 = extractvalue { i32, { i64, ptr } } %t53, 1
  %t55 = extractvalue { i32, { i64, ptr } } %t53, 0
  store i32 %t55, ptr %l29
  %t56 = icmp ne i32 %t55, 0
  br i1 %t56, label %bb10, label %ok.57, !prof !99
ok.57:
  store { i64, ptr } %t54, ptr %l28
  br label %bb9
bb9:
  %t58 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t58, ptr %l26, !tbaa !27
  br label %bb14
bb10:
  %t59 = load i32, ptr %l29, !tbaa !23
  %t60 = ashr i32 %t59, 16
  %t62 = icmp eq i32 %t60, 1
  br i1 %t62, label %bb11, label %bb12
bb11:
  call void @__olang_errpay_pop()
  br label %bb12
bb12:
  br label %bb13
bb13:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d173, i32 0, i32 1) }, ptr %l26, !tbaa !27
  br label %bb14
bb14:
  %t64 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t64, ptr %l3, !tbaa !27
  %t65 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t67 = call { i32, %"std/os:FileInfo" } @std_2fos_2eFileInfo_2eStat(ptr %s0, { i64, ptr } %t65)
  %t68 = extractvalue { i32, %"std/os:FileInfo" } %t67, 1
  %t69 = extractvalue { i32, %"std/os:FileInfo" } %t67, 0
  store i32 %t69, ptr %l35
  %t70 = icmp ne i32 %t69, 0
  br i1 %t70, label %bb16, label %ok.71, !prof !99
ok.71:
  store %"std/os:FileInfo" %t68, ptr %l34
  br label %bb15
bb15:
  %t72 = load %"std/os:FileInfo", ptr %l34
  store %"std/os:FileInfo" %t72, ptr %l32
  br label %bb20
bb16:
  %t73 = load i32, ptr %l35, !tbaa !23
  %t74 = ashr i32 %t73, 16
  %t76 = icmp eq i32 %t74, 1
  store i1 %t76, ptr %l37, !tbaa !21
  %t77 = load i32, ptr %l35, !tbaa !23
  %t78 = ashr i32 %t77, 16
  %t80 = icmp eq i32 %t78, 1
  br i1 %t80, label %bb17, label %bb18
bb17:
  call void @__olang_errpay_pop()
  br label %bb18
bb18:
  br label %bb19
bb19:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d174, i32 0, i32 1) }, ptr %l40, !tbaa !27
  %t82 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t82, ptr %l41, !tbaa !27
  %t83 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t84 = extractvalue { i64, ptr } %t83, 0
  store i64 %t84, ptr %l42, !tbaa !24
  %t85 = load i64, ptr %l42, !tbaa !24
  %t86 = mul i64 %t85, 1
  %t87 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t86)
  %t88 = insertvalue { i64, ptr } undef, i64 %t85, 0
  %t89 = insertvalue { i64, ptr } %t88, ptr %t87, 1
  store { i64, ptr } %t89, ptr %l43, !tbaa !27
  %t90 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t91 = load ptr, ptr %t90, !tbaa !27
  %t92 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !27
  %t94 = load i64, ptr %l42, !tbaa !24
  %t95 = mul i64 %t94, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t91, ptr %t93, i64 %t95, i1 false)
  %t96 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t96, ptr %l41, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t97 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t97, ptr %rv
  br label %ret
bb20:
  %t98 = load %"std/os:FileInfo", ptr %l32
  store %"std/os:FileInfo" %t98, ptr %l4
  %t99 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t99, ptr %l44
  br label %bb21
bb21:
  %t100 = load %"std/prelude/text:StringBuilder", ptr %l44
  store %"std/prelude/text:StringBuilder" %t100, ptr %l5
  %t101 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t102 = getelementptr %"std/os:FileInfo", ptr %l4, i32 0, i32 1
  %t103 = load i64, ptr %t102, !tbaa !24
  %t104 = getelementptr %"std/os:FileInfo", ptr %l4, i32 0, i32 2
  %t105 = load i64, ptr %t104, !tbaa !24
  %t106 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d175, i32 0, i32 1) }, 1
  %t107 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d175, i32 0, i32 1) }, 0
  %t109 = extractvalue { i64, ptr } %t101, 1
  %t110 = extractvalue { i64, ptr } %t101, 0
  %t111 = add i64 %t107, %t110
  %t112 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d176, i32 0, i32 1) }, 1
  %t113 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d176, i32 0, i32 1) }, 0
  %t114 = add i64 %t111, %t113
  %t116 = call i64 @__olang_fmt_i64(ptr null, i64 %t103)
  %t117 = add i64 %t114, %t116
  %t118 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d176, i32 0, i32 1) }, 1
  %t119 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d176, i32 0, i32 1) }, 0
  %t120 = add i64 %t117, %t119
  %t122 = call i64 @__olang_fmt_i64(ptr null, i64 %t105)
  %t123 = add i64 %t120, %t122
  %t124 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d177, i32 0, i32 1) }, 1
  %t125 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d177, i32 0, i32 1) }, 0
  %t126 = add i64 %t123, %t125
  %t127 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t126)
  call void @olang_textcopy(ptr %t127, ptr %t106, i64 %t107)
  %t128 = getelementptr i8, ptr %t127, i64 %t107
  call void @olang_textcopy(ptr %t128, ptr %t109, i64 %t110)
  %t129 = getelementptr i8, ptr %t128, i64 %t110
  call void @olang_textcopy(ptr %t129, ptr %t112, i64 %t113)
  %t130 = getelementptr i8, ptr %t129, i64 %t113
  %t131 = call i64 @__olang_fmt_i64(ptr %t130, i64 %t103)
  %t132 = getelementptr i8, ptr %t130, i64 %t116
  call void @olang_textcopy(ptr %t132, ptr %t118, i64 %t119)
  %t133 = getelementptr i8, ptr %t132, i64 %t119
  %t134 = call i64 @__olang_fmt_i64(ptr %t133, i64 %t105)
  %t135 = getelementptr i8, ptr %t133, i64 %t122
  call void @olang_textcopy(ptr %t135, ptr %t124, i64 %t125)
  %t136 = insertvalue { i64, ptr } undef, i64 %t126, 0
  %t137 = insertvalue { i64, ptr } %t136, ptr %t127, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l5, { i64, ptr } %t137)
  br label %bb22
bb22:
  %t141 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t141, ptr %l51, !tbaa !27
  %t142 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t145 = extractvalue { i64, ptr } %t142, 0
  store i64 %t145, ptr %l54, !tbaa !24
  %t146 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t147 = extractvalue { i64, ptr } %t146, 0
  store i64 %t147, ptr %l55, !tbaa !24
  %t148 = icmp sge i64 1, 0
  br i1 %t148, label %bb23, label %bb24
bb23:
  %t150 = load i64, ptr %l54, !tbaa !24
  %t151 = icmp sle i64 1, %t150
  br i1 %t151, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_1bb6927ebf4fa198_42e84c5a8eaa23b4)
  unreachable
bb25:
  %t153 = load i64, ptr %l54, !tbaa !24
  %t154 = load i64, ptr %l55, !tbaa !24
  %t155 = icmp sle i64 %t153, %t154
  br i1 %t155, label %bb27, label %bb28
bb26:
  call void @__olang_check_failed(ptr @olang_loc_1bb6927ebf4fa198_42e84c5a8eaa23b4)
  unreachable
bb27:
  %t157 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t158 = load ptr, ptr %t157, !tbaa !27
  %t159 = load i64, ptr %l54, !tbaa !24
  %t160 = getelementptr { i64, ptr }, ptr %t158, i64 1
  %t161 = sub i64 %t159, 1
  %t162 = insertvalue { i64, ptr } undef, i64 %t161, 0
  %t163 = insertvalue { i64, ptr } %t162, ptr %t160, 1
  store { i64, ptr } %t163, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t165 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t167 = extractvalue { i64, ptr } %t165, 0
  store i64 %t167, ptr %l8, !tbaa !24
  br label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_1bb6927ebf4fa198_42e84c5a8eaa23b4)
  unreachable
bb29:
  store %olang.scope zeroinitializer, ptr %s6
  %t169 = load i64, ptr %l7, !tbaa !24
  %t170 = load i64, ptr %l8, !tbaa !24
  %t173 = icmp slt i64 %t169, %t170
  %t175 = xor i1 %t173, true
  br i1 %t175, label %bb30, label %bb31
bb30:
  call void @__olang_scope_close(ptr %s6)
  br label %bb35
bb31:
  br label %bb32
bb32:
  %t177 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t177, ptr %l66, !tbaa !27
  %t178 = load i64, ptr %l7, !tbaa !24
  %t180 = getelementptr { i64, ptr }, ptr %l66, i32 0, i32 1
  %t181 = load ptr, ptr %t180, !tbaa !27
  %t182 = getelementptr { i64, ptr }, ptr %t181, i64 %t178
  %t183 = load { i64, ptr }, ptr %t182, !tbaa !37
  %t187 = extractvalue { i64, ptr } %t183, 1
  %t188 = extractvalue { i64, ptr } %t183, 0
  %t189 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d178, i32 0, i32 1) }, 1
  %t190 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d178, i32 0, i32 1) }, 0
  %t191 = add i64 %t188, %t190
  %t192 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t191)
  call void @olang_textcopy(ptr %t192, ptr %t187, i64 %t188)
  %t193 = getelementptr i8, ptr %t192, i64 %t188
  call void @olang_textcopy(ptr %t193, ptr %t189, i64 %t190)
  %t194 = insertvalue { i64, ptr } undef, i64 %t191, 0
  %t195 = insertvalue { i64, ptr } %t194, ptr %t192, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s6, ptr %l5, { i64, ptr } %t195)
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s6)
  br label %bb34
bb34:
  %t199 = load i64, ptr %l7, !tbaa !24
  %t202 = add i64 %t199, 1
  store i64 %t202, ptr %l7, !tbaa !24
  br label %bb29
bb35:
  store ptr %l5, ptr %l76, !tbaa !29
  %t204 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t206 = extractvalue { i64, ptr } %t204, 0
  store i64 %t206, ptr %l78, !tbaa !24
  %t207 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t207, ptr %l79, !tbaa !27
  %t208 = call { i64, ptr } @compiler_2ftarget_2ecpuModel(ptr %s0)
  store { i64, ptr } %t208, ptr %l80
  br label %bb36
bb36:
  %t209 = call { i64, ptr } @compiler_2ftarget_2ecpuFlags(ptr %s0)
  store { i64, ptr } %t209, ptr %l81
  br label %bb37
bb37:
  %t210 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d179, i32 0, i32 1) }, 1
  %t211 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d179, i32 0, i32 1) }, 0
  %t212 = load i64, ptr %l78, !tbaa !24
  %t213 = call i64 @__olang_fmt_i64(ptr null, i64 %t212)
  %t214 = add i64 %t211, %t213
  %t215 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d180, i32 0, i32 1) }, 1
  %t216 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d180, i32 0, i32 1) }, 0
  %t217 = add i64 %t214, %t216
  %t218 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t219 = extractvalue { i64, ptr } %t218, 1
  %t220 = extractvalue { i64, ptr } %t218, 0
  %t221 = add i64 %t217, %t220
  %t222 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d180, i32 0, i32 1) }, 1
  %t223 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d180, i32 0, i32 1) }, 0
  %t224 = add i64 %t221, %t223
  %t225 = load { i64, ptr }, ptr %l80, !tbaa !27
  %t226 = extractvalue { i64, ptr } %t225, 1
  %t227 = extractvalue { i64, ptr } %t225, 0
  %t228 = add i64 %t224, %t227
  %t229 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d180, i32 0, i32 1) }, 1
  %t230 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d180, i32 0, i32 1) }, 0
  %t231 = add i64 %t228, %t230
  %t232 = load { i64, ptr }, ptr %l81, !tbaa !27
  %t233 = extractvalue { i64, ptr } %t232, 1
  %t234 = extractvalue { i64, ptr } %t232, 0
  %t235 = add i64 %t231, %t234
  %t236 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d181, i32 0, i32 1) }, 1
  %t237 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d181, i32 0, i32 1) }, 0
  %t238 = add i64 %t235, %t237
  %t239 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t238)
  call void @olang_textcopy(ptr %t239, ptr %t210, i64 %t211)
  %t240 = getelementptr i8, ptr %t239, i64 %t211
  %t241 = call i64 @__olang_fmt_i64(ptr %t240, i64 %t212)
  %t242 = getelementptr i8, ptr %t240, i64 %t213
  call void @olang_textcopy(ptr %t242, ptr %t215, i64 %t216)
  %t243 = getelementptr i8, ptr %t242, i64 %t216
  call void @olang_textcopy(ptr %t243, ptr %t219, i64 %t220)
  %t244 = getelementptr i8, ptr %t243, i64 %t220
  call void @olang_textcopy(ptr %t244, ptr %t222, i64 %t223)
  %t245 = getelementptr i8, ptr %t244, i64 %t223
  call void @olang_textcopy(ptr %t245, ptr %t226, i64 %t227)
  %t246 = getelementptr i8, ptr %t245, i64 %t227
  call void @olang_textcopy(ptr %t246, ptr %t229, i64 %t230)
  %t247 = getelementptr i8, ptr %t246, i64 %t230
  call void @olang_textcopy(ptr %t247, ptr %t233, i64 %t234)
  %t248 = getelementptr i8, ptr %t247, i64 %t234
  call void @olang_textcopy(ptr %t248, ptr %t236, i64 %t237)
  %t249 = insertvalue { i64, ptr } undef, i64 %t238, 0
  %t250 = insertvalue { i64, ptr } %t249, ptr %t239, 1
  %t252 = load ptr, ptr %l76, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t252, { i64, ptr } %t250)
  br label %bb38
bb38:
  %t255 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l5)
  store { i64, ptr } %t255, ptr %l85
  br label %bb39
bb39:
  call void @__olang_scope_close(ptr %s0)
  %t256 = load { i64, ptr }, ptr %l85, !tbaa !27
  store { i64, ptr } %t256, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2ftarget_2erefuse(ptr %v0, ptr %v1, ptr %a0, %"compiler/diagmsg:Msg" %a1) #0 {
entry:
  %l5 = alloca i64
  %rv = alloca i32
  %t2 = alloca { i64, [3 x i64] }, align 8
  br label %start
start:
  br label %bb0
bb0:
  store { i64, [3 x i64] } zeroinitializer, ptr %t2
  %t3 = getelementptr { i64, [3 x i64] }, ptr %t2, i32 0, i32 0
  store i64 0, ptr %t3
  %t4 = load { i64, [3 x i64] }, ptr %t2
  %t9 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %t4, %"compiler/diagmsg:Msg" %a1)
  store i64 %t9, ptr %l5
  br label %bb1
bb1:
  store i32 65536, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2ftarget_2ewhereIs(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca i1
  %l16 = alloca i32
  %l18 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l27 = alloca i32
  %l31 = alloca i1
  %l33 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l47 = alloca i1
  %l49 = alloca { i64, ptr }
  %l59 = alloca i32
  %l65 = alloca { i64, ptr }
  %l66 = alloca { i64, ptr }
  %l67 = alloca i64
  %l68 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d182, i32 0, i32 1) }, ptr %l10, !tbaa !27
  %t4 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t5 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } %t4)
  store i1 %t5, ptr %l11
  br label %bb1
bb1:
  %t6 = load i1, ptr %l11, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 1
  %t10 = extractvalue { i64, ptr } %t7, 0
  %t11 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d183, i32 0, i32 1) }, 1
  %t12 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d183, i32 0, i32 1) }, 0
  %t13 = add i64 %t10, %t12
  %t14 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t13)
  call void @olang_textcopy(ptr %t14, ptr %t9, i64 %t10)
  %t15 = getelementptr i8, ptr %t14, i64 %t10
  call void @olang_textcopy(ptr %t15, ptr %t11, i64 %t12)
  %t16 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t14, 1
  %t19 = load i32, ptr @G_2e_3cunistd_2eh_3e_2eX__OK, !tbaa !23
  %t21 = extractvalue { i64, ptr } %t17, 1
  %t22 = extractvalue { i64, ptr } %t17, 0
  %t24 = call i32 @access(ptr %t21, i32 %t19)
  store i32 %t24, ptr %l16
  br label %bb4
bb3:
  br label %bb8
bb4:
  %t25 = load i32, ptr %l16, !tbaa !23
  %t26 = icmp eq i32 %t25, 0
  br i1 %t26, label %bb5, label %bb6
bb5:
  %t28 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t28, 1
  %t31 = extractvalue { i64, ptr } %t28, 0
  %t32 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t31)
  call void @olang_textcopy(ptr %t32, ptr %t30, i64 %t31)
  %t33 = insertvalue { i64, ptr } undef, i64 %t31, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t32, 1
  store { i64, ptr } %t34, ptr %l18, !tbaa !27
  br label %bb7
bb6:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d184, i32 0, i32 1) }, ptr %l21, !tbaa !27
  %t36 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t36, ptr %l18, !tbaa !27
  br label %bb7
bb7:
  %t38 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t38, 0
  store i64 %t39, ptr %l23, !tbaa !24
  %t40 = load i64, ptr %l23, !tbaa !24
  %t41 = mul i64 %t40, 1
  %t42 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t41)
  %t43 = insertvalue { i64, ptr } undef, i64 %t40, 0
  %t44 = insertvalue { i64, ptr } %t43, ptr %t42, 1
  store { i64, ptr } %t44, ptr %l24, !tbaa !27
  %t45 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !27
  %t47 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !27
  %t49 = load i64, ptr %l23, !tbaa !24
  %t50 = mul i64 %t49, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t46, ptr %t48, i64 %t50, i1 false)
  %t51 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t51, ptr %l18, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t52 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t52, ptr %rv
  br label %ret
bb8:
  %t53 = call { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %s0, ptr %s0, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d185, i32 0, i32 1) })
  %t54 = extractvalue { i32, { i64, ptr } } %t53, 1
  %t55 = extractvalue { i32, { i64, ptr } } %t53, 0
  store i32 %t55, ptr %l27
  %t56 = icmp ne i32 %t55, 0
  br i1 %t56, label %bb10, label %ok.57, !prof !99
ok.57:
  store { i64, ptr } %t54, ptr %l26
  br label %bb9
bb9:
  %t58 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t58, ptr %l25, !tbaa !27
  br label %bb14
bb10:
  %t59 = load i32, ptr %l27, !tbaa !23
  %t60 = ashr i32 %t59, 16
  %t62 = icmp eq i32 %t60, 1
  br i1 %t62, label %bb11, label %bb12
bb11:
  call void @__olang_errpay_pop()
  br label %bb12
bb12:
  br label %bb13
bb13:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d186, i32 0, i32 1) }, ptr %l25, !tbaa !27
  br label %bb14
bb14:
  %t64 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t64, ptr %l1, !tbaa !27
  %t65 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t67 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t65, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d187, i32 0, i32 1) })
  store i1 %t67, ptr %l31
  br label %bb15
bb15:
  %t68 = load i1, ptr %l31, !tbaa !21
  %t69 = xor i1 %t68, true
  br i1 %t69, label %bb16, label %bb17
bb16:
  %t71 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t71, ptr %l33, !tbaa !27
  br label %bb18
bb17:
  store { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d188, i32 0, i32 1) }, ptr %l33, !tbaa !27
  br label %bb18
bb18:
  %t73 = load { i64, ptr }, ptr %l33, !tbaa !27
  store %olang.scope zeroinitializer, ptr %s4
  %t76 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %s0, ptr %s4, ptr %s4, { i64, ptr } %t73, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d189, i32 0, i32 1) })
  store { i64, ptr } %t76, ptr %l36
  br label %bb19
bb19:
  %t77 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t77, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t78 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t80 = extractvalue { i64, ptr } %t78, 0
  store i64 %t80, ptr %l5, !tbaa !24
  br label %bb20
bb20:
  store %olang.scope zeroinitializer, ptr %s5
  %t82 = load i64, ptr %l4, !tbaa !24
  %t83 = load i64, ptr %l5, !tbaa !24
  %t86 = icmp slt i64 %t82, %t83
  %t88 = xor i1 %t86, true
  br i1 %t88, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s5)
  br label %bb33
bb22:
  br label %bb23
bb23:
  %t90 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t90, ptr %l43, !tbaa !27
  %t91 = load i64, ptr %l4, !tbaa !24
  %t93 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !27
  %t95 = getelementptr { i64, ptr }, ptr %t94, i64 %t91
  %t96 = load { i64, ptr }, ptr %t95, !tbaa !37
  store { i64, ptr } %t96, ptr %l6, !tbaa !27
  %t98 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t100 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s4, ptr %s5, { i64, ptr } %t98, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d190, i32 0, i32 1) })
  store i1 %t100, ptr %l47
  br label %bb24
bb24:
  %t101 = load i1, ptr %l47, !tbaa !21
  %t102 = xor i1 %t101, true
  br i1 %t102, label %bb25, label %bb26
bb25:
  %t104 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t105 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t107 = extractvalue { i64, ptr } %t104, 1
  %t108 = extractvalue { i64, ptr } %t104, 0
  %t109 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d191, i32 0, i32 1) }, 1
  %t110 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d191, i32 0, i32 1) }, 0
  %t111 = add i64 %t108, %t110
  %t113 = extractvalue { i64, ptr } %t105, 1
  %t114 = extractvalue { i64, ptr } %t105, 0
  %t115 = add i64 %t111, %t114
  %t116 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t115)
  call void @olang_textcopy(ptr %t116, ptr %t107, i64 %t108)
  %t117 = getelementptr i8, ptr %t116, i64 %t108
  call void @olang_textcopy(ptr %t117, ptr %t109, i64 %t110)
  %t118 = getelementptr i8, ptr %t117, i64 %t110
  call void @olang_textcopy(ptr %t118, ptr %t113, i64 %t114)
  %t119 = insertvalue { i64, ptr } undef, i64 %t115, 0
  %t120 = insertvalue { i64, ptr } %t119, ptr %t116, 1
  store { i64, ptr } %t120, ptr %l49, !tbaa !27
  br label %bb27
bb26:
  %t122 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t124 = extractvalue { i64, ptr } %t122, 1
  %t125 = extractvalue { i64, ptr } %t122, 0
  %t126 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t125)
  call void @olang_textcopy(ptr %t126, ptr %t124, i64 %t125)
  %t127 = insertvalue { i64, ptr } undef, i64 %t125, 0
  %t128 = insertvalue { i64, ptr } %t127, ptr %t126, 1
  store { i64, ptr } %t128, ptr %l49, !tbaa !27
  br label %bb27
bb27:
  %t130 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t130, ptr %l7, !tbaa !27
  %t131 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t133 = extractvalue { i64, ptr } %t131, 1
  %t134 = extractvalue { i64, ptr } %t131, 0
  %t135 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d192, i32 0, i32 1) }, 1
  %t136 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d192, i32 0, i32 1) }, 0
  %t137 = add i64 %t134, %t136
  %t138 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t137)
  call void @olang_textcopy(ptr %t138, ptr %t133, i64 %t134)
  %t139 = getelementptr i8, ptr %t138, i64 %t134
  call void @olang_textcopy(ptr %t139, ptr %t135, i64 %t136)
  %t140 = insertvalue { i64, ptr } undef, i64 %t137, 0
  %t141 = insertvalue { i64, ptr } %t140, ptr %t138, 1
  %t143 = load i32, ptr @G_2e_3cunistd_2eh_3e_2eX__OK, !tbaa !23
  %t145 = extractvalue { i64, ptr } %t141, 1
  %t146 = extractvalue { i64, ptr } %t141, 0
  %t148 = call i32 @access(ptr %t145, i32 %t143)
  store i32 %t148, ptr %l59
  br label %bb28
bb28:
  %t149 = load i32, ptr %l59, !tbaa !23
  %t150 = icmp eq i32 %t149, 0
  br i1 %t150, label %bb29, label %bb30
bb29:
  %t152 = load { i64, ptr }, ptr %l7, !tbaa !27
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t152, ptr %rv
  br label %ret
bb30:
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s5)
  br label %bb32
bb32:
  %t154 = load i64, ptr %l4, !tbaa !24
  %t157 = add i64 %t154, 1
  store i64 %t157, ptr %l4, !tbaa !24
  br label %bb20
bb33:
  call void @__olang_scope_close(ptr %s4)
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d193, i32 0, i32 1) }, ptr %l65, !tbaa !27
  %t159 = load { i64, ptr }, ptr %l65, !tbaa !27
  store { i64, ptr } %t159, ptr %l66, !tbaa !27
  %t160 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t161 = extractvalue { i64, ptr } %t160, 0
  store i64 %t161, ptr %l67, !tbaa !24
  %t162 = load i64, ptr %l67, !tbaa !24
  %t163 = mul i64 %t162, 1
  %t164 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t163)
  %t165 = insertvalue { i64, ptr } undef, i64 %t162, 0
  %t166 = insertvalue { i64, ptr } %t165, ptr %t164, 1
  store { i64, ptr } %t166, ptr %l68, !tbaa !27
  %t167 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t168 = load ptr, ptr %t167, !tbaa !27
  %t169 = getelementptr { i64, ptr }, ptr %l66, i32 0, i32 1
  %t170 = load ptr, ptr %t169, !tbaa !27
  %t171 = load i64, ptr %l67, !tbaa !24
  %t172 = mul i64 %t171, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t168, ptr %t170, i64 %t172, i1 false)
  %t173 = load { i64, ptr }, ptr %l68, !tbaa !27
  store { i64, ptr } %t173, ptr %l66, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t174 = load { i64, ptr }, ptr %l66, !tbaa !27
  store { i64, ptr } %t174, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2ftarget_2ewindowsTriple(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca i1
  %l3 = alloca i1
  %l5 = alloca i1
  %l6 = alloca i1
  %l8 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d194, i32 0, i32 1) })
  store i1 %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load i1, ptr %l2, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb5
bb3:
  %t5 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t7 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %s0, { i64, ptr } %t5, { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d195, i32 0, i32 1) })
  store i1 %t7, ptr %l5
  br label %bb4
bb4:
  %t8 = load i1, ptr %l5, !tbaa !21
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb5
bb5:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb9
bb7:
  %t10 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t12 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %s0, { i64, ptr } %t10, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d196, i32 0, i32 1) })
  store i1 %t12, ptr %l8
  br label %bb8
bb8:
  %t13 = load i1, ptr %l8, !tbaa !21
  store i1 %t13, ptr %l6, !tbaa !21
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s0)
  %t14 = load i1, ptr %l6, !tbaa !21
  store i1 %t14, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2ftarget_2ewine(ptr %v0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %lp4 = alloca ptr
  %lp5 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l20 = alloca i1
  %l21 = alloca { i64, ptr }
  %l23 = alloca i1
  %l25 = alloca [1 x { i64, ptr }]
  %l26 = alloca { i64, ptr }
  %l29 = alloca [3 x { i64, ptr }]
  %l30 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s1
  %t1 = insertvalue [3 x { i64, ptr }] undef, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d197, i32 0, i32 1) }, 0
  %t2 = insertvalue [3 x { i64, ptr }] %t1, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d198, i32 0, i32 1) }, 1
  %t3 = insertvalue [3 x { i64, ptr }] %t2, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d199, i32 0, i32 1) }, 2
  %t5 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 48, i64 8)
  store [3 x { i64, ptr }] %t3, ptr %t5
  store ptr %t5, ptr %l0
  store i64 0, ptr %l1, !tbaa !24
  %t7 = load ptr, ptr %l0
  store i64 3, ptr %l2, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t10 = load i64, ptr %l1, !tbaa !24
  %t11 = load i64, ptr %l2, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb3:
  br label %bb4
bb4:
  %t18 = load ptr, ptr %l0
  %t19 = load i64, ptr %l1, !tbaa !24
  %t22 = getelementptr [3 x { i64, ptr }], ptr %t18, i64 0, i64 %t19
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !37
  %t26 = load ptr, ptr @__olang_prog_scope
  %t28 = call { i64, ptr } @compiler_2ftarget_2ewhereIs(ptr %t26, ptr %v0, { i64, ptr } %t23)
  store { i64, ptr } %t28, ptr %l18
  br label %bb5
bb5:
  %t29 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store ptr %t29, ptr %lp4
  %t30 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t31 = load ptr, ptr %lp4
  store { i64, ptr } %t30, ptr %t31, !tbaa !27
  %t32 = load ptr, ptr %lp4
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !27
  %t35 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t33, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d200, i32 0, i32 1) })
  store i1 %t35, ptr %l20
  br label %bb6
bb6:
  %t36 = load i1, ptr %l20, !tbaa !21
  br i1 %t36, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s2)
  br label %bb15
bb8:
  br label %bb9
bb9:
  %t37 = call { i64, ptr } @compiler_2ftarget_2ewhereIs(ptr %s2, ptr %v0, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d201, i32 0, i32 1) })
  store { i64, ptr } %t37, ptr %l21
  br label %bb10
bb10:
  %t38 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store ptr %t38, ptr %lp5
  %t39 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t40 = load ptr, ptr %lp5
  store { i64, ptr } %t39, ptr %t40, !tbaa !27
  %t41 = load ptr, ptr %lp5
  %t42 = load { i64, ptr }, ptr %t41, !tbaa !27
  %t44 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t42, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d202, i32 0, i32 1) })
  store i1 %t44, ptr %l23
  br label %bb11
bb11:
  %t45 = load i1, ptr %l23, !tbaa !21
  br i1 %t45, label %bb12, label %bb13
bb12:
  %t46 = load ptr, ptr %lp4
  %t47 = load { i64, ptr }, ptr %t46, !tbaa !27
  %t49 = insertvalue [1 x { i64, ptr }] undef, { i64, ptr } %t47, 0
  store [1 x { i64, ptr }] %t49, ptr %l25
  %t50 = mul i64 1, 16
  %t51 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t50)
  %t52 = insertvalue { i64, ptr } undef, i64 1, 0
  %t53 = insertvalue { i64, ptr } %t52, ptr %t51, 1
  store { i64, ptr } %t53, ptr %l26, !tbaa !27
  %t54 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = mul i64 1, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t55, ptr %l25, i64 %t56, i1 false)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  %t57 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t58 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t57, 1
  store { i32, { i64, ptr } } %t58, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t59 = load ptr, ptr %lp5
  %t60 = load { i64, ptr }, ptr %t59, !tbaa !27
  %t61 = load ptr, ptr %lp4
  %t62 = load { i64, ptr }, ptr %t61, !tbaa !27
  %t64 = insertvalue [3 x { i64, ptr }] undef, { i64, ptr } %t60, 0
  %t65 = insertvalue [3 x { i64, ptr }] %t64, { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d203, i32 0, i32 1) }, 1
  %t67 = insertvalue [3 x { i64, ptr }] %t65, { i64, ptr } %t62, 2
  store [3 x { i64, ptr }] %t67, ptr %l29
  %t68 = mul i64 3, 16
  %t69 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t68)
  %t70 = insertvalue { i64, ptr } undef, i64 3, 0
  %t71 = insertvalue { i64, ptr } %t70, ptr %t69, 1
  store { i64, ptr } %t71, ptr %l30, !tbaa !27
  %t72 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = mul i64 3, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t73, ptr %l29, i64 %t74, i1 false)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  %t75 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t76 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t75, 1
  store { i32, { i64, ptr } } %t76, ptr %rv
  br label %ret
bb15:
  %t77 = load i64, ptr %l1, !tbaa !24
  %t80 = add i64 %t77, 1
  store i64 %t80, ptr %l1, !tbaa !24
  br label %bb1
bb16:
  call void @__olang_scope_close(ptr %s1)
  %t83 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t83, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

@.d0 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d1 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare void @__olang_check_failed(ptr) cold noreturn
@.d2 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d3 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare void @__olang_errpay_pop()
@.d4 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define available_externally ptr @__olang_scope_hold(ptr %s) alwaysinline {
entry:
  %none = icmp eq ptr %s, null
  br i1 %none, label %plain, label %look
look:
  ; atomic: on a scope that is no stand-in this word is its parts list, which other threads push onto (__olang_scope_part)
  %mp = getelementptr %olang.scope, ptr %s, i32 0, i32 4
  %m = load atomic ptr, ptr %mp monotonic, align 8
  %fresh = icmp eq ptr %m, @__olang_standin_mark
  br i1 %fresh, label %make, label %kept
kept:
  %mi = ptrtoint ptr %m to i64
  %bit = and i64 %mi, 1
  %has = icmp ne i64 %bit, 0
  br i1 %has, label %keeper, label %plain
keeper:
  %ki = and i64 %mi, -2
  %k = inttoptr i64 %ki to ptr
  ret ptr %k
make:
  %f = call ptr @__olang_standin_keeper(ptr %s)
  ret ptr %f
plain:
  ret ptr %s
}
@olang_2esole_2estd_2fos_3aOutput_2e1 = weak hidden constant i1 false
declare ptr @__olang_region_make(ptr) noinline
define available_externally noalias ptr @__olang_held_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
@.d5 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %dh = load ptr, ptr %dheadptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  %hasd = icmp ne ptr %dh, null
  %owns = or i1 %hasf, %hasd
  br i1 %owns, label %owned, label %chunks
owned:
  call void @__olang_scope_close_owned(ptr %scope)
  br label %chunks
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d6 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d7 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare i32 @getpid()
@.d8 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d9 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c".tmp" }>, align 8
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d10 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"OLANG_CLANG" }>, align 8
@.d11 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d12 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d13 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d14 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"/proc/self/exe" }>, align 8
@.d15 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d16 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d17 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"/../llvm/bin/clang" }>, align 8
@.d18 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\00" }>, align 8
declare i32 @access(ptr, i32)
@__olang_prog_scope = external thread_local(initialexec) global ptr
@.d19 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d20 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"," }>, align 8
@.d21 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d22 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"libclang_rt.tsan-" }>, align 8
@.d23 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c".a" }>, align 8
@olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_2c_202_3e_2e_2d1 = weak hidden constant i1 false
@.d24 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"-print-file-name=" }>, align 8
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@.d25 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d26 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d27 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"ANDROID_NDK_HOME" }>, align 8
@.d28 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"ANDROID_NDK_ROOT" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
@.d29 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d30 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d31 = private constant <{ i64, [48 x i8] }> <{ i64 0, [48 x i8] c"/toolchains/llvm/prebuilt/linux-x86_64/bin/clang" }>, align 8
@.d32 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d33 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d34 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d35 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"," }>, align 8
@olang_2esole_2ecompiler_2ftarget_3aTarget_2e0 = weak hidden constant i1 false
declare void @__olang_region_release(ptr) noinline
@.d36 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d37 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"-linux" }>, align 8
@.d38 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d39 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"aarch64" }>, align 8
declare ptr @__olang_scope_of(ptr, ptr) noinline
@.d40 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"-linux-android" }>, align 8
@.d41 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"-linux-android" }>, align 8
@.d42 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"android" }>, align 8
@olang_2esole_2ecompiler_2ftarget_3aTarget_2e3 = weak hidden constant i1 false
@.d43 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"x86_64" }>, align 8
@.d44 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"x86_64-w64-windows-gnu" }>, align 8
@.d45 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"windows" }>, align 8
@.d46 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"-linux-gnu" }>, align 8
@.d47 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d48 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
@.d49 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"-apple" }>, align 8
@.d50 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"-windows" }>, align 8
@.d51 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
@.d52 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler_2ftarget_3aTarget_2e2 = weak hidden constant i1 false
@.d53 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"linux" }>, align 8
@.d54 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"linux" }>, align 8
@.d55 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d56 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d57 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"native" }>, align 8
@.d58 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"scripting mode" }>, align 8
@.d59 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d60 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"android" }>, align 8
@olang_2esole_2ecompiler_2ftarget_3aTarget_2e13 = weak hidden constant i1 false
@.d61 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d62 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d63 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d64 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1 = weak hidden constant i1 false
@.d65 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"--target=" }>, align 8
@.d66 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-S" }>, align 8
@.d67 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"-emit-llvm" }>, align 8
@.d68 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-o" }>, align 8
@.d69 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"-" }>, align 8
@.d70 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-x" }>, align 8
@.d71 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"c" }>, align 8
@.d72 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"-" }>, align 8
@.d73 = private constant <{ i64, [34 x i8] }> <{ i64 0, [34 x i8] c"void olang_target_probe(void) { }\0A" }>, align 8
@olang_2esole_2ecompiler_2ftarget_3aTarget_2e6 = weak hidden constant i1 false
@.d74 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d75 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d76 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d77 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"-linux-android" }>, align 8
@.d78 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d79 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\22" }>, align 8
@.d80 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"\22=\22" }>, align 8
@.d81 = private constant <{ i64, [88 x i8] }> <{ i64 0, [88 x i8] c"define float @f(float %x) {\0A  %b = fptrunc float %x to bfloat\0A  %c = fadd bfloat %b, %b\0A" }>, align 8
@.d82 = private constant <{ i64, [49 x i8] }> <{ i64 0, [49 x i8] c"  %r = fpext bfloat %c to float\0A  ret float %r\0A}\0A" }>, align 8
@olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_2c_209_3e_2e_2d1 = weak hidden constant i1 false
@.d83 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"--target=" }>, align 8
@.d84 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"-fno-crash-diagnostics" }>, align 8
@.d85 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-c" }>, align 8
@.d86 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-x" }>, align 8
@.d87 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"ir" }>, align 8
@.d88 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"-" }>, align 8
@.d89 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-o" }>, align 8
@.d90 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"/dev/null" }>, align 8
@.d91 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"target triple = \22" }>, align 8
@.d92 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"target datalayout = \22" }>, align 8
@.d93 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"attributes #0 = {" }>, align 8
@.d94 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"-p:32" }>, align 8
@.d95 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"-p:16" }>, align 8
@olang_2esole_2ecompiler_2ftarget_3aTarget_2e1 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftarget_3aTarget_2e4 = weak hidden constant i1 false
@.d96 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"target-cpu" }>, align 8
@.d97 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"target-features" }>, align 8
@.d98 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d99 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"avx512bf16" }>, align 8
@.d100 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"amx-bf16" }>, align 8
@.d101 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"amx-tile" }>, align 8
@.d102 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"aarch64" }>, align 8
@.d103 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"neon" }>, align 8
@.d104 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"avx512f" }>, align 8
@.d105 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"avx" }>, align 8
@.d106 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"fma" }>, align 8
@.d107 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"fma4" }>, align 8
@.d108 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"tune-cpu" }>, align 8
@.d109 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d110 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d111 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c" \22tune-cpu\22=\22" }>, align 8
@.d112 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\22" }>, align 8
@.d113 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d114 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d115 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"vscale_range(" }>, align 8
@.d116 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@olang_2esole_2ecompiler_2ftarget_3aTarget_2e5 = weak hidden constant i1 false
@.d117 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"\22target-cpu\22=\22" }>, align 8
@.d118 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"\22 \22target-features\22=\22" }>, align 8
@.d119 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\22" }>, align 8
@.d120 = private constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c" \22prefer-vector-width\22=\22" }>, align 8
@.d121 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"aarch64" }>, align 8
@.d122 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"OLANG_EMULATOR" }>, align 8
@.d123 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d124 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d125 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d126 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d127 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"windows" }>, align 8
@.d128 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"qemu-" }>, align 8
@.d129 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"qemu-" }>, align 8
@.d130 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"-static" }>, align 8
@.d131 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d132 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"android" }>, align 8
@.d133 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d134 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"/usr/" }>, align 8
@.d135 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"-linux-gnu" }>, align 8
@olang_2esole_2ecompiler__2ftarget__2ecompiler__2ftarget__3aTarget__2eRunner_2elocal_2e12 = weak hidden constant i1 false
@.d136 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"/usr/" }>, align 8
@.d137 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"-linux-gnu" }>, align 8
declare ptr @__olang_region_or(ptr, ptr)
declare void @__olang_region_settle_in(ptr, ptr)
@.d138 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d139 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-L" }>, align 8
@.d140 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"-unknown-linux-gnu" }>, align 8
@.d141 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"aarch64" }>, align 8
@.d142 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"native" }>, align 8
@.d143 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"generic" }>, align 8
@.d144 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"generic" }>, align 8
@.d145 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"x86-64" }>, align 8
@.d146 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"x86-64-v2" }>, align 8
@.d147 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"x86-64-v3" }>, align 8
@.d148 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"x86-64-v4" }>, align 8
@.d149 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"native" }>, align 8
@.d150 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"x86-64" }>, align 8
@.d151 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"x86-64-v" }>, align 8
@.d152 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"/proc/cpuinfo" }>, align 8
@.d153 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d154 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"flags" }>, align 8
@.d155 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d156 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d157 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d158 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d159 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"/proc/cpuinfo" }>, align 8
@.d160 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d161 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"model name" }>, align 8
@.d162 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d163 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"OLANG_CACHE" }>, align 8
@.d164 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d165 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d166 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"/probe" }>, align 8
@.d167 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"HOME" }>, align 8
@.d168 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d169 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"/.cache/olang/probe" }>, align 8
@.d170 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d171 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d172 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d173 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d174 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d175 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"olang probe 1\0A" }>, align 8
@.d176 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d177 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d178 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d179 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"input " }>, align 8
@.d180 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d181 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"\0A=====\0A" }>, align 8
@.d182 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d183 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\00" }>, align 8
@.d184 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d185 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"PATH" }>, align 8
@.d186 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d187 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d188 = private constant <{ i64, [28 x i8] }> <{ i64 0, [28 x i8] c"/usr/local/bin:/usr/bin:/bin" }>, align 8
@.d189 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
@.d190 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d191 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d192 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\00" }>, align 8
@.d193 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d194 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"-windows" }>, align 8
@.d195 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"-windows-gnu" }>, align 8
@.d196 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"-mingw32" }>, align 8
@.d197 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"wine64" }>, align 8
@.d198 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"/usr/lib/wine/wine64" }>, align 8
@.d199 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"wine" }>, align 8
@.d200 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d201 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"env" }>, align 8
@.d202 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d203 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"WINEDEBUG=-all" }>, align 8
@__olang_standin_mark = external global i64
declare ptr @__olang_standin_keeper(ptr) noinline
define available_externally noalias ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  %head = load ptr, ptr %scope, !tbaa !59
  %isslot = icmp eq ptr %head, @__olang_slot_chunk
  br i1 %isslot, label %slot, label %plain
slot:
  %s = call ptr @__olang_slot_alloc(ptr %scope, i64 %rawsize)
  ret ptr %s
plain:
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @__olang_scope_close_owned(ptr) noinline
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
@__olang_slot_chunk = external global %olang.chunk
declare noalias ptr @__olang_slot_alloc(ptr, i64) noinline
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eHash(ptr %v0, { i64, ptr } %a0)
declare { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %v0, i64 %a0)
declare { i64, ptr } @std_2fprelude_2ftext_2eU64_2eFormat(ptr %v0, i64 %a0, i64 %a1)
@olang_loc_def72623566706b3_6d1f4e2e8af6f867 = external constant [0 x i8]
declare { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_47a0ad7bede37e81_52b343d343663485 = external constant [0 x i8]
declare %"std/os:Output" @std_2fos_3aOutput_2ector(ptr %v0, ptr %v1, ptr %v2, i32 %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare { i32, %"std/os:Output" } @std_2fos_2eOutput_2eExec(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, i1 %a2, { i64, ptr } %a3)
declare i32 @std_2fos_2eMkDirAll(ptr %v0, { i64, ptr } %a0)
declare i32 @std_2fos_2eWriteFile(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i32 @std_2fos_2eRename(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i32 @std_2fos_2eRemove(ptr %v0, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @compiler_2ftarget_2eexecutable(ptr %v0, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fos_2eReadLink(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_5d60638bbee689af_7a012b3f353868cb = external constant [0 x i8]
@G_2e_3cunistd_2eh_3e_2eX__OK = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
@G_2ecompiler_2ftarget_2eClangs = external constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }>
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_7d2dbc1a64f072ad_c547ba7f55386c9 = external constant [0 x i8]
declare i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
@olang_loc_4b3e93141bb855fb_750a01d3487f499f = external constant [0 x i8]
@G_2ecompiler_2ftarget_2eIeeeUnsafe = external constant <{ [8 x i8], ptr, [8 x i8], ptr }>
declare i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2eHas_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_a61f3cd56da1d37e_58843bed9934bc22 = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare void @compiler_2ftarget_3aTarget_2ector(ptr %out, ptr %v0)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %v0, { i64, ptr } %a0, i8 %a1)
@olang_loc_5afbe203adc8766f_c0acc38cff9c62b = external constant [0 x i8]
@olang_loc_ccc584ee5db490f2_f240216cb9bcdd2e = external constant [0 x i8]
@olang_loc_8b94dd4b00821371_32c50240ce2e918d = external constant [0 x i8]
@G_2ecompiler_2ftarget_2eArchs = external constant <{ [8 x i8], ptr, [8 x i8], ptr }>
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTargetUnsupported(ptr %v0, ptr %v1, { i64, ptr } %a0)
@G_2ecompiler_2ftarget_2eAndroidApi = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\1D\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTargetAndroidApi(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_d5ce9bb3e7f57104_9ca6c947c8d4a4b0 = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTargetUnknown(ptr %v0, ptr %v1, { i64, ptr } %a0)
@G_2ecompiler_2ftarget_2eArchDefaultCpus = external constant <{ [8 x i8], ptr, [8 x i8], ptr }>
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTargetNativeForeign(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTargetForeignMode(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTargetNoNdk(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTargetNoClang(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@G_2ecompiler_2ftarget_2eArchCpuFlags = external constant <{ [8 x i8], ptr, [8 x i8], ptr }>
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_ec0ce4f0f9f205a4_65ae5627b8a19708 = external constant [0 x i8]
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTargetNoBackend(ptr %v0, ptr %v1, { i64, ptr } %a0)
@G_2ecompiler_2ftarget_2eLevelFlags = external constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }>
@olang_loc_7532b0a1705d3da_dcb5e502962dad76 = external constant [0 x i8]
@olang_loc_2b3d593c994025a_f25bcfc8e3895e8e = external constant [0 x i8]
@olang_loc_41dcdde6fea423b7_7dcc0ffa4d83aa8b = external constant [0 x i8]
@olang_loc_e010b40d861556cc_7cbd713015487310 = external constant [0 x i8]
@olang_loc_8cdf81df4f8deaf9_3f7b7447e7e110ed = external constant [0 x i8]
@G_2ecompiler_2ftarget_2eBranchProtection = external constant <{ [8 x i8], ptr }>
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_Haae4fbc3ba15583a49040d883d2248d1(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2)
declare { i64, ptr } @compiler_2ftarget_2eSysroot(ptr %v0)
declare i1 @std_2fos_2eIsDir(ptr %v0, { i64, ptr } %a0)
@olang_loc_85332b5eb98b88c2_ab57175d397d1606 = external constant [0 x i8]
declare %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_85ddc375a30bdeb4_680b0f1997dc0f98 = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_1252e266118faa7_9a8543fc9009ce13 = external constant [0 x i8]
@olang_loc_50955429569277ca_9a744de1378669b6 = external constant [0 x i8]
declare { i32, { i64, ptr } } @std_2fos_2eRealPath(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, %"std/os:FileInfo" } @std_2fos_2eFileInfo_2eStat(ptr %v0, { i64, ptr } %a0)
@olang_loc_1bb6927ebf4fa198_42e84c5a8eaa23b4 = external constant [0 x i8]
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/diagmsg:Msg" %a2)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
